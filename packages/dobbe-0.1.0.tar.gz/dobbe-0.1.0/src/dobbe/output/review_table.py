"""Rich table formatter for PR review digest."""

from __future__ import annotations

from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from dobbe.models.review import ReviewDigest
from dobbe.models.shared import Severity
from dobbe.output.helpers import SEVERITY_COLORS, severity_badge as _severity_badge
from dobbe.output.table import _highlight_code_refs


def _recommendation_style(rec: str) -> Text:
    styles = {
        "approve": "bold green",
        "request_changes": "bold red",
        "needs_discussion": "bold yellow",
    }
    style = styles.get(rec, "")
    label = rec.replace("_", " ").title() if rec else ""
    return Text(label, style=style)


def render_digest(digest: ReviewDigest, console: Console | None = None, verbose: bool = False) -> None:
    """Render a ReviewDigest as a rich table to the terminal."""
    if console is None:
        console = Console()

    # Header
    stale_count = len(digest.stale_prs)
    header_parts = [
        f"PRs: {digest.total_prs}",
        f"Critical: {digest.critical_count}",
        f"Stale: {stale_count}",
    ]
    if digest.repos_scanned:
        header_parts.insert(0, f"Repos: {len(digest.repos_scanned)}")
    console.print(Panel(" | ".join(header_parts), title="dobbe review digest", style="bold"))

    # Errors
    for error in digest.errors:
        console.print(f"[bold red]Error:[/bold red] {escape(error)}")

    if not digest.results:
        console.print("[dim]No open PRs found awaiting review.[/dim]")
        return

    # Main table
    table = Table(show_header=True, header_style="bold", pad_edge=False, box=None)
    table.add_column("#", style="dim", width=6)
    table.add_column("Repo", min_width=12, no_wrap=True)
    table.add_column("PR", ratio=2, no_wrap=True, overflow="ellipsis")
    table.add_column("Author", width=12, no_wrap=True)
    if verbose:
        table.add_column("+/-", width=10)
        table.add_column("Files", width=6)
    table.add_column("Risk", width=10)
    table.add_column("Age", width=6)
    table.add_column("Time", width=8)
    table.add_column("Recommendation", min_width=16, no_wrap=True)

    # Group results by repo for visual separation
    from collections import OrderedDict
    repo_groups: OrderedDict[str, list] = OrderedDict()
    for result in digest.results:
        repo_groups.setdefault(result.pr.repo, []).append(result)

    for repo_name, repo_results in repo_groups.items():
        if len(repo_groups) > 1:
            critical_in_group = sum(1 for r in repo_results if r.risk_level == Severity.CRITICAL)
            group_label = f"{repo_name} ({len(repo_results)} PRs"
            if critical_in_group:
                group_label += f", {critical_in_group} critical"
            group_label += ")"
            console.print(Rule(group_label, style="dim"))

        for result in repo_results:
            pr = result.pr
            age_str = f"{pr.age_days}d"
            if pr.age_days >= digest.stale_days:
                age_text = Text(age_str, style="bold red")
            else:
                age_text = Text(age_str)

            title_display = pr.title if verbose else pr.title[:35] + ("..." if len(pr.title) > 35 else "")

            row: list = [
                str(pr.pr_number),
                pr.repo,
                title_display,
                pr.author,
            ]
            if verbose:
                diff_stat = f"+{pr.additions}/-{pr.deletions}"
                row.append(diff_stat)
                row.append(str(pr.changed_files))
            row.extend([
                _severity_badge(result.risk_level),
                age_text,
                result.estimated_review_time or "-",
                _recommendation_style(result.approval_recommendation),
            ])

            table.add_row(*row)

        # Show concerns/recommendations after each repo group
        for result in repo_results:
            if verbose:
                if result.recommendations:
                    rec_text = "  └ Recommendations: " + "  ".join(
                        f"{i}) {escape(r)}" for i, r in enumerate(result.recommendations, 1)
                    )
                    console.print(f"[dim]{rec_text}[/dim]")
                for concern in result.concerns:
                    loc = ""
                    if concern.file_path:
                        loc = f" @ {concern.file_path}"
                        if concern.line_number is not None:
                            loc += f":{concern.line_number}"
                    suggestion_text = f" - {_highlight_code_refs(escape(concern.suggestion))}" if concern.suggestion else ""
                    console.print(f"[dim]  └ Concern: {concern.category.value}{loc}: {_highlight_code_refs(escape(concern.description))}{suggestion_text}[/dim]")
            else:
                if result.risk_level in (Severity.CRITICAL, Severity.HIGH) and result.concerns:
                    top_concern = result.concerns[0]
                    concern_text = f"  └ {top_concern.category.value}: {escape(top_concern.description[:60])}"
                    console.print(f"[dim]{concern_text}[/dim]")

    console.print(table)

    # Summary
    console.print()
    stats = digest.stats_by_risk
    parts = []
    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
        count = stats.get(sev, 0)
        if count > 0:
            style = SEVERITY_COLORS[sev]
            parts.append(f"[{style}]{count} {sev.value}[/{style}]")

    summary_line = f"[bold]Summary:[/bold] {digest.total_prs} PRs reviewed"
    if stale_count:
        summary_line += f", {stale_count} stale"
    if parts:
        summary_line += " - " + ", ".join(parts)

    console.print(Panel(summary_line, style="bold"))
