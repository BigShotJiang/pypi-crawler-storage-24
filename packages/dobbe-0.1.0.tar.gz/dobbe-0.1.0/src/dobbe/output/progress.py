"""Multi-phase live progress display for long-running operations."""

from __future__ import annotations

from typing import Protocol

from rich.console import Console
from rich.live import Live
from rich.markup import escape
from rich.table import Table
from rich.text import Text


class ProgressCallback(Protocol):
    """Callback protocol emitted by pipelines to report progress."""

    def __call__(
        self,
        *,
        phase: str,
        detail: str = "",
        completed: int | None = None,
        total: int | None = None,
        phase_number: int | None = None,
        total_phases: int | None = None,
        repo: str = "",
        repo_status: str = "",
    ) -> None: ...


class LiveProgress:
    """Rich-based multi-phase progress display.

    Usage::

        with LiveProgress(console=console, title="dobbe review digest") as lp:
            lp.update(phase="Fetching PRs", detail="org/repo", completed=1, total=3)
    """

    def __init__(self, console: Console | None = None, title: str = "") -> None:
        self._console = console or Console()
        self._title = title
        self._phase = ""
        self._phase_number = 0
        self._total_phases = 0
        self._detail = ""
        self._completed = 0
        self._total = 0
        self._repo_statuses: dict[str, str] = {}
        self._live: Live | None = None

    def _build_table(self) -> Table:
        table = Table(show_header=False, box=None, pad_edge=False, show_edge=False)
        table.add_column(ratio=1)

        # Title + phase line
        phase_info = self._phase
        if self._total_phases > 0:
            phase_info = f"Phase {self._phase_number}/{self._total_phases}: {self._phase}"
        title_line = Text()
        if self._title:
            title_line.append(f" {self._title}\n", style="bold")
        title_line.append(f" {phase_info}", style="bold cyan")
        table.add_row(title_line)

        # Per-repo statuses
        if self._repo_statuses:
            table.add_row(Text(""))
            for repo, status in self._repo_statuses.items():
                if status.startswith("done"):
                    icon = "[bold green]\u2713[/bold green]"
                    style = "dim"
                elif status.startswith("waiting"):
                    icon = "[dim]\u00b7[/dim]"
                    style = "dim"
                else:
                    icon = "[cyan]\u2847[/cyan]"
                    style = ""
                table.add_row(Text.from_markup(f"  {icon} {escape(repo)}  {escape(status)}", style=style))

        # Progress counter
        if self._total > 0:
            table.add_row(Text(""))
            table.add_row(Text(f" Progress: {self._completed}/{self._total}", style="bold"))

        return table

    def update(
        self,
        *,
        phase: str = "",
        detail: str = "",
        completed: int | None = None,
        total: int | None = None,
        phase_number: int | None = None,
        total_phases: int | None = None,
        repo: str = "",
        repo_status: str = "",
    ) -> None:
        """Update the display with new progress info."""
        if phase:
            self._phase = phase
        if detail:
            self._detail = detail
        if completed is not None:
            self._completed = completed
        if total is not None:
            self._total = total
        if phase_number is not None:
            self._phase_number = phase_number
        if total_phases is not None:
            self._total_phases = total_phases
        if repo:
            self._repo_statuses[repo] = repo_status or detail

        if self._live:
            self._live.update(self._build_table())

    def callback(
        self,
        *,
        phase: str,
        detail: str = "",
        completed: int | None = None,
        total: int | None = None,
        phase_number: int | None = None,
        total_phases: int | None = None,
        repo: str = "",
        repo_status: str = "",
    ) -> None:
        """ProgressCallback-compatible method for passing to pipelines."""
        self.update(
            phase=phase,
            detail=detail,
            completed=completed,
            total=total,
            phase_number=phase_number,
            total_phases=total_phases,
            repo=repo,
            repo_status=repo_status,
        )

    def __enter__(self) -> LiveProgress:
        self._live = Live(
            self._build_table(),
            console=self._console,
            refresh_per_second=4,
            transient=True,
        )
        self._live.__enter__()
        return self

    def __exit__(self, *args) -> None:
        if self._live:
            self._live.__exit__(*args)
            self._live = None
