"""Markdown output formatter for PR review digest."""

from __future__ import annotations

from dobbe.models.review import ReviewDigest
from dobbe.models.shared import SEVERITY_EMOJI, Severity
from dobbe.output.helpers import sanitize_md_cell as _sanitize_md_cell


def render_digest(digest: ReviewDigest, verbose: bool = False) -> str:
    """Render a ReviewDigest as a Markdown string."""
    lines: list[str] = []

    # Title
    lines.append("# PR Review Digest")
    lines.append("")
    lines.append(f"**Date:** {digest.timestamp.strftime('%Y-%m-%d %H:%M')}")
    if digest.repos_scanned:
        lines.append(f"**Repos scanned:** {', '.join(digest.repos_scanned)}")
    if digest.reviewers:
        lines.append(f"**Reviewers:** {', '.join(digest.reviewers)}")
    lines.append(f"**Total PRs:** {digest.total_prs}")
    lines.append(f"**Critical:** {digest.critical_count} | **Stale:** {len(digest.stale_prs)}")
    lines.append("")

    # Errors (shown before results so they're visible even with no PRs)
    if digest.errors:
        lines.append("## Errors")
        lines.append("")
        for error in digest.errors:
            lines.append(f"- {error}")
        lines.append("")

    if not digest.results:
        lines.append("No open PRs found awaiting review.")
        lines.append("")
        return "\n".join(lines)

    # Group by risk level
    for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
        relevant = [r for r in digest.results if r.risk_level == severity]
        if not relevant:
            continue

        emoji = SEVERITY_EMOJI.get(severity, "")
        lines.append(f"## {emoji} {severity.value.title()} Risk")
        lines.append("")
        if verbose:
            lines.append("| # | Repo | Title | Author | +/- | Files | Age | Time | Recommendation |")
            lines.append("|---|------|-------|--------|-----|-------|-----|------|----------------|")
        else:
            lines.append("| # | Repo | Title | Author | Age | Time | Recommendation |")
            lines.append("|---|------|-------|--------|-----|------|----------------|")

        for result in relevant:
            pr = result.pr
            age = f"{pr.age_days}d"
            rec = result.approval_recommendation.replace("_", " ").title() if result.approval_recommendation else "-"
            time_est = result.estimated_review_time or "-"
            if verbose:
                diff_stat = f"+{pr.additions}/-{pr.deletions}"
                lines.append(
                    f"| {pr.pr_number} | {pr.repo} | {_sanitize_md_cell(pr.title)} | {pr.author} | "
                    f"{diff_stat} | {pr.changed_files} | {age} | {time_est} | {rec} |"
                )
            else:
                lines.append(
                    f"| {pr.pr_number} | {pr.repo} | {_sanitize_md_cell(pr.title)} | {pr.author} | "
                    f"{age} | {time_est} | {rec} |"
                )

        lines.append("")

        # Show concerns + recommendations
        show_concerns = verbose or severity in (Severity.CRITICAL, Severity.HIGH)
        if show_concerns:
            for result in relevant:
                if result.concerns or (verbose and result.recommendations):
                    lines.append(f"### PR #{result.pr.pr_number}: {result.pr.title}")
                    lines.append("")
                    if verbose and result.recommendations:
                        lines.append("**Recommendations:**")
                        for rec_item in result.recommendations:
                            lines.append(f"- {_sanitize_md_cell(rec_item)}")
                        lines.append("")
                    for concern in result.concerns:
                        file_ref = f" (`{concern.file_path}`)" if concern.file_path else ""
                        lines.append(f"- **{concern.category.value}** ({concern.severity.value}): {_sanitize_md_cell(concern.description)}{file_ref}")
                        if concern.suggestion:
                            lines.append(f"  - *Suggestion:* {concern.suggestion}")
                    lines.append("")

    # Summary
    lines.append("---")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    stats = digest.stats_by_risk
    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
        count = stats.get(sev, 0)
        if count > 0:
            emoji = SEVERITY_EMOJI.get(sev, "")
            lines.append(f"- {emoji} **{sev.value.title()}:** {count}")

    lines.append("")
    stale_count = len(digest.stale_prs)
    lines.append(f"**Total:** {digest.total_prs} PRs - {digest.critical_count} critical, {stale_count} stale")
    lines.append("")

    return "\n".join(lines)
