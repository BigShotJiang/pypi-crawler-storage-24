"""JSON output formatter."""

from __future__ import annotations

from dobbe.models.alert import ScanReport


def render_report(report: ScanReport) -> str:
    """Render a ScanReport as a JSON string."""
    return report.model_dump_json(indent=2)


def render_report_to_file(report: ScanReport, path: str) -> None:
    """Write a ScanReport to a JSON file."""
    with open(path, "w") as f:
        f.write(render_report(report))
