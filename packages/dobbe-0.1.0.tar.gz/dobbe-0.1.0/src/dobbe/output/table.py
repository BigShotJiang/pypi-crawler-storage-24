"""Rich table formatter for terminal output."""

from __future__ import annotations

from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from dobbe.models.alert import ScanReport, Severity
from dobbe.output.helpers import SEVERITY_COLORS, severity_badge as _severity_badge

_CODE_REF_PATTERN = None  # lazy compile


def _highlight_code_refs(text: str) -> str:
    """Wrap file:line references in Rich markup for highlighting."""
    import re
    global _CODE_REF_PATTERN
    if _CODE_REF_PATTERN is None:
        _CODE_REF_PATTERN = re.compile(r"(\b[\w/.-]+\.\w+:\d+\b)")
    return _CODE_REF_PATTERN.sub(r"[bold cyan]\1[/bold cyan]", text)


def render_report(report: ScanReport, console: Console | None = None, verbose: bool = False) -> None:
    """Render a ScanReport as a rich table to the terminal."""
    if console is None:
        console = Console()

    # Header
    header_parts = []
    if report.org:
        header_parts.append(f"Org: {report.org}")
    header_parts.append(f"Repos scanned: {len(report.repos)}")
    header_parts.append(f"Total alerts: {report.total_alerts}")
    console.print(Panel(" | ".join(header_parts), title="dobbe vulnerability scan", style="bold"))

    if not report.repos:
        console.print("[dim]No repositories scanned.[/dim]")
        return

    for repo_result in report.repos:
        if repo_result.error:
            console.print(f"\n[bold red]Error scanning {repo_result.repo}:[/bold red] {escape(repo_result.error)}")
            continue

        # Repo header
        access_icon = "📁" if repo_result.access_mode.value == "local" else "☁️"
        console.print(
            f"\n[bold]{repo_result.repo}[/bold] {access_icon} "
            f"({repo_result.total_alerts} alerts, "
            f"{repo_result.affected_count} affected, "
            f"{repo_result.safe_to_ignore_count} safe to ignore)"
        )

        if not repo_result.groups:
            console.print("  [dim]No alerts found.[/dim]")
            continue

        # Table per repo
        table = Table(show_header=True, header_style="bold", pad_edge=False, box=None)
        table.add_column("#", style="dim", width=5)
        table.add_column("Package", min_width=12, no_wrap=True)
        table.add_column("Severity", width=10)
        table.add_column("Risk", width=10)
        if verbose:
            table.add_column("CVE", min_width=14, no_wrap=True)
            table.add_column("Upgrade", min_width=14, no_wrap=True)
        table.add_column("Affected?", width=10)
        table.add_column("Summary", ratio=3, no_wrap=True, overflow="ellipsis")
        table.add_column("Action", ratio=2, no_wrap=True, overflow="ellipsis")

        for group in repo_result.groups:
            for i, alert in enumerate(group.alerts):
                affected_text = Text("YES", style="bold red") if alert.affected else Text("no", style="green")
                if verbose:
                    cve = alert.cve_id or "-"
                    upgrade = f"{group.current_version} → {group.target_version}" if group.target_version else group.current_version
                    table.add_row(
                        str(alert.alert_number),
                        alert.package_name,
                        _severity_badge(alert.severity),
                        _severity_badge(alert.risk_level),
                        cve,
                        upgrade,
                        affected_text,
                        alert.summary,
                        alert.recommended_action,
                    )
                else:
                    table.add_row(
                        str(alert.alert_number),
                        alert.package_name,
                        _severity_badge(alert.severity),
                        _severity_badge(alert.risk_level),
                        affected_text,
                        alert.summary[:60] + ("..." if len(alert.summary) > 60 else ""),
                        alert.recommended_action[:40] + ("..." if len(alert.recommended_action) > 40 else ""),
                    )

        console.print(table)

        # Verbose: show evidence detail rows with code reference highlighting
        if verbose:
            for group in repo_result.groups:
                for alert in group.alerts:
                    if alert.evidence:
                        highlighted = _highlight_code_refs(escape(alert.evidence))
                        console.print(f"  [dim]└ Evidence ({alert.package_name} #{alert.alert_number}): {highlighted}[/dim]")

    # Summary
    console.print()
    stats = report.stats_by_severity
    parts = []
    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
        count = stats.get(sev, 0)
        if count > 0:
            style = SEVERITY_COLORS[sev]
            parts.append(f"[{style}]{count} {sev.value}[/{style}]")

    summary_line = (
        f"[bold]Summary:[/bold] {report.total_alerts} alerts triaged: "
        f"{report.total_affected} affected, {report.total_safe_to_ignore} safe to ignore"
    )
    if parts:
        summary_line += " - " + ", ".join(parts)

    console.print(Panel(summary_line, style="bold"))
