"""Markdown output formatter."""

from __future__ import annotations

from dobbe.models.alert import ScanReport, Severity
from dobbe.models.shared import SEVERITY_EMOJI
from dobbe.output.helpers import sanitize_md_cell as _sanitize_md_cell


def render_report(report: ScanReport, verbose: bool = False) -> str:
    """Render a ScanReport as a Markdown string."""
    lines: list[str] = []

    # Title
    lines.append("# Vulnerability Scan Report")
    lines.append("")
    lines.append(f"**Date:** {report.timestamp.strftime('%Y-%m-%d %H:%M')}")
    if report.org:
        lines.append(f"**Organization:** {report.org}")
    lines.append(f"**Repos scanned:** {len(report.repos)}")
    lines.append(f"**Total alerts:** {report.total_alerts}")
    lines.append(f"**Affected:** {report.total_affected} | **Safe to ignore:** {report.total_safe_to_ignore}")
    lines.append("")

    if report.severity_filter:
        lines.append(f"**Severity filter:** {', '.join(s.value for s in report.severity_filter)}")
        lines.append("")

    # Available MCPs
    if report.available_mcps:
        mcp_status = ", ".join(
            f"{name} {'✓' if avail else '✗'}" for name, avail in report.available_mcps.items()
        )
        lines.append(f"**Integrations:** {mcp_status}")
        lines.append("")

    for repo_result in report.repos:
        lines.append(f"## {repo_result.repo}")
        lines.append("")

        if repo_result.error:
            lines.append(f"> **Error:** {repo_result.error}")
            lines.append("")
            continue

        access_label = "local" if repo_result.access_mode.value == "local" else "remote (GitHub MCP)"
        lines.append(f"*Access: {access_label} | Alerts: {repo_result.total_alerts} | Affected: {repo_result.affected_count}*")
        lines.append("")

        if not repo_result.groups:
            lines.append("No alerts found.")
            lines.append("")
            continue

        # Group by risk level for readability
        for severity in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
            relevant_alerts = [
                (group, alert)
                for group in repo_result.groups
                for alert in group.alerts
                if alert.risk_level == severity
            ]
            if not relevant_alerts:
                continue

            emoji = SEVERITY_EMOJI.get(severity, "")
            lines.append(f"### {emoji} {severity.value.title()} Risk")
            lines.append("")
            lines.append("| # | Package | CVE | Affected | Summary | Action |")
            lines.append("|---|---------|-----|----------|---------|--------|")

            for group, alert in relevant_alerts:
                affected = "**YES**" if alert.affected else "no"
                cve = alert.cve_id or "-"
                lines.append(
                    f"| {alert.alert_number} | {_sanitize_md_cell(alert.package_name)} | {cve} | "
                    f"{affected} | {_sanitize_md_cell(alert.summary)} | {_sanitize_md_cell(alert.recommended_action)} |"
                )

            lines.append("")

            # Verbose: evidence and upgrade paths
            if verbose:
                for group, alert in relevant_alerts:
                    details: list[str] = []
                    if group.target_version:
                        details.append(f"Upgrade: {group.current_version} → {group.target_version}")
                    if alert.evidence:
                        details.append(f"Evidence: {_sanitize_md_cell(alert.evidence)}")
                    if details:
                        lines.append(f"> **{alert.package_name} #{alert.alert_number}:** {' | '.join(details)}")
                lines.append("")

    # Summary
    lines.append("---")
    lines.append("")
    lines.append("## Summary")
    lines.append("")
    stats = report.stats_by_severity
    for sev in [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]:
        count = stats.get(sev, 0)
        if count > 0:
            emoji = SEVERITY_EMOJI.get(sev, "")
            lines.append(f"- {emoji} **{sev.value.title()}:** {count}")

    lines.append("")
    lines.append(f"**Total:** {report.total_alerts} alerts - {report.total_affected} need attention, {report.total_safe_to_ignore} safe to ignore")
    lines.append("")

    return "\n".join(lines)
