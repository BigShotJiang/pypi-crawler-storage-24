"""Rich table formatter for review post results."""

from __future__ import annotations

from collections import OrderedDict

from rich.console import Console
from rich.markup import escape
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from dobbe.models.review import ReviewPostReport
from dobbe.models.shared import Severity
from dobbe.output.helpers import SEVERITY_COLORS, severity_badge as _severity_badge


def _status_text(result) -> Text:
    if result.posted:
        return Text("Posted", style="bold green")
    if result.error:
        return Text("Failed", style="bold red")
    if result.skipped_reason:
        return Text("Skipped", style="bold yellow")
    return Text("-")


def render_post_report(report: ReviewPostReport, console: Console | None = None, verbose: bool = False) -> None:
    """Render a ReviewPostReport as a rich table to the terminal."""
    if console is None:
        console = Console()

    # Header
    header_parts = [
        f"Posted: {report.total_posted}",
        f"Skipped: {report.total_skipped}",
        f"Failed: {report.total_failed}",
    ]
    title = "dobbe review post"
    if report.dry_run:
        title += " (DRY RUN)"
    console.print(Panel(" | ".join(header_parts), title=title, style="bold"))

    # Errors
    for error in report.errors:
        console.print(f"[bold red]Error:[/bold red] {escape(error)}")

    if not report.results:
        console.print("[dim]No PRs to review.[/dim]")
        return

    # Main table
    table = Table(show_header=True, header_style="bold", pad_edge=False, box=None)
    table.add_column("#", style="dim", width=6)
    table.add_column("Repo", min_width=12, no_wrap=True)
    table.add_column("PR", ratio=2, no_wrap=True, overflow="ellipsis")
    table.add_column("Risk", width=10)
    table.add_column("Status", width=10)
    table.add_column("Details", ratio=3, no_wrap=True, overflow="ellipsis")

    # Group results by repo for visual separation
    repo_groups: OrderedDict[str, list] = OrderedDict()
    for result in report.results:
        repo_groups.setdefault(result.pr.repo, []).append(result)

    for repo_name, repo_results in repo_groups.items():
        if len(repo_groups) > 1:
            console.print(Rule(f"{repo_name} ({len(repo_results)} PRs)", style="dim"))

        for result in repo_results:
            pr = result.pr
            title_display = pr.title if verbose else pr.title[:35] + ("..." if len(pr.title) > 35 else "")

            # Details column
            if result.posted:
                details = result.review_url
            elif result.error:
                details = escape(result.error)
            elif result.skipped_reason:
                details = result.skipped_reason
                if report.dry_run:
                    inline_count = sum(
                        1 for c in result.review.concerns
                        if c.file_path and c.line_number is not None
                    )
                    details = f"{result.skipped_reason} ({inline_count} inline comment(s))"
            else:
                details = ""

            table.add_row(
                str(pr.pr_number),
                pr.repo,
                title_display,
                _severity_badge(result.review.risk_level),
                _status_text(result),
                details,
            )

            # Verbose: show concern details with file:line and suggestion
            if verbose:
                for concern in result.review.concerns:
                    loc = ""
                    if concern.file_path:
                        loc = f"{concern.file_path}"
                        if concern.line_number is not None:
                            loc += f":{concern.line_number}"
                    suggestion = f" - {escape(concern.suggestion)}" if concern.suggestion else ""
                    console.print(f"[dim]  └ {concern.category.value} @ {loc}: {escape(concern.description)}{suggestion}[/dim]")

    console.print(table)
