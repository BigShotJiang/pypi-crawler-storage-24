"""Markdown output formatter for review post results."""

from __future__ import annotations

from dobbe.core.github_review import build_review_body
from dobbe.models.review import ReviewPostReport
from dobbe.models.shared import SEVERITY_EMOJI, Severity
from dobbe.output.helpers import sanitize_md_cell as _sanitize_md_cell


def render_post_report(report: ReviewPostReport, verbose: bool = False) -> str:
    """Render a ReviewPostReport as a Markdown string."""
    lines: list[str] = []

    # Title
    title = "# dobbe review post"
    if report.dry_run:
        title += " (DRY RUN)"
    lines.append(title)
    lines.append("")
    lines.append(f"**Date:** {report.timestamp.strftime('%Y-%m-%d %H:%M')}")
    if report.repos_scanned:
        lines.append(f"**Repos:** {', '.join(report.repos_scanned)}")
    lines.append(
        f"**Posted:** {report.total_posted} | "
        f"**Skipped:** {report.total_skipped} | "
        f"**Failed:** {report.total_failed}"
    )
    lines.append("")

    # Errors
    if report.errors:
        lines.append("## Errors")
        lines.append("")
        for error in report.errors:
            lines.append(f"- {error}")
        lines.append("")

    if not report.results:
        lines.append("No PRs to review.")
        lines.append("")
        return "\n".join(lines)

    # Results table
    lines.append("## Results")
    lines.append("")
    lines.append("| # | Repo | PR | Risk | Status | Details |")
    lines.append("|---|------|-----|------|--------|---------|")

    for result in report.results:
        pr = result.pr
        emoji = SEVERITY_EMOJI.get(result.review.risk_level, "")
        risk = f"{emoji} {result.review.risk_level.value.title()}"

        if result.posted:
            status = "Posted"
            details = f"[Review]({result.review_url})" if result.review_url else "Posted"
        elif result.error:
            status = "Failed"
            details = result.error
        elif result.skipped_reason:
            status = "Skipped"
            details = result.skipped_reason
        else:
            status = "-"
            details = ""

        lines.append(
            f"| {pr.pr_number} | {pr.repo} | {_sanitize_md_cell(pr.title)} | {risk} | {status} | {_sanitize_md_cell(details)} |"
        )

    lines.append("")

    # Dry-run preview
    if report.dry_run:
        for result in report.results:
            if result.review.summary:
                lines.append(f"### PR #{result.pr.pr_number}: {result.pr.title}")
                lines.append("")
                lines.append("**Review body preview:**")
                lines.append("")
                lines.append(build_review_body(result.review))
                lines.append("")

                inline_comments = [
                    c for c in result.review.concerns
                    if c.file_path and c.line_number is not None
                ]
                if inline_comments:
                    lines.append(f"**Inline comments ({len(inline_comments)}):**")
                    lines.append("")
                    for concern in inline_comments:
                        lines.append(
                            f"- `{concern.file_path}:{concern.line_number}` - "
                            f"{concern.description}"
                        )
                    lines.append("")

    return "\n".join(lines)
