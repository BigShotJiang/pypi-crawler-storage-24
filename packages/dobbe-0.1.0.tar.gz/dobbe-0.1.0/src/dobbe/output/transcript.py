"""Conversation log renderer - terminal, PR body, and transcript file."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from dobbe.models.resolve import AgentMessage, ConversationLog, ResolveReport


def render_live_message(msg: AgentMessage, console: Console | None = None) -> None:
    """Render a single agent message to the terminal as a Rich Panel."""
    if console is None:
        console = Console()

    title_parts = [f"{msg.icon} {msg.agent.upper()}"]
    if msg.iteration is not None:
        title_parts.append(f"[iteration {msg.iteration}]")
    title = " ".join(title_parts)

    content = Text(msg.summary)
    console.print(Panel(content, title=title, title_align="left", border_style="dim"))


def render_pr_body(report: ResolveReport) -> str:
    """Render the conversation log as a PR description in markdown."""
    lines: list[str] = []

    lines.append("## Summary")
    if report.summary:
        lines.append(report.summary)
    else:
        status = "converged" if report.converged else "did not converge"
        lines.append(
            f"Automated vulnerability resolution ({status} "
            f"in {report.iteration_count} iteration(s))."
        )
    lines.append("")

    lines.append("## Agent Resolution Process")
    lines.append("")
    for msg in report.conversation.messages:
        iter_tag = ""
        if msg.iteration is not None:
            iter_tag = f" (attempt {msg.iteration})"
        lines.append(f"**{msg.icon} {msg.agent.capitalize()}{iter_tag}** - {msg.summary}")
        if msg.details:
            lines.append(f"> {msg.details}")
        lines.append("")

    # Changes section
    if report.iterations:
        last_iter = report.iterations[-1]
        if last_iter.fix_result.fixes:
            lines.append("## Changes")
            for fix in last_iter.fix_result.fixes:
                lines.append(
                    f"- {fix.package_name}: {fix.old_version} → {fix.new_version} "
                    f"({len(fix.alerts_addressed)} CVE(s) fixed)"
                )
            lines.append("")

        if last_iter.fix_result.skipped:
            lines.append("## Deferred")
            for skip in last_iter.fix_result.skipped:
                lines.append(f"- {skip.package_name}: {skip.reason}")
            lines.append("")

    return "\n".join(lines)


def render_transcript(report: ResolveReport) -> str:
    """Render a full transcript for saving to a file."""
    lines: list[str] = []

    lines.append(f"# Vulnerability Resolution Transcript - {report.repo}")
    lines.append("")
    lines.append(f"- **Converged:** {report.converged}")
    lines.append(f"- **Iterations:** {report.iteration_count}/{report.max_iterations}")
    lines.append(f"- **Branch:** {report.final_branch}")
    if report.pr_url:
        lines.append(f"- **PR:** {report.pr_url}")
    lines.append("")

    lines.append("## Conversation Thread")
    lines.append("")
    for msg in report.conversation.messages:
        ts = msg.timestamp.strftime("%H:%M:%S")
        iter_tag = ""
        if msg.iteration is not None:
            iter_tag = f" [iteration {msg.iteration}]"
        lines.append(f"### {msg.icon} {msg.agent.upper()}{iter_tag} ({ts})")
        lines.append("")
        lines.append(msg.summary)
        if msg.details:
            lines.append("")
            lines.append("<details>")
            lines.append("<summary>Full response</summary>")
            lines.append("")
            lines.append("```")
            lines.append(msg.details)
            lines.append("```")
            lines.append("")
            lines.append("</details>")
        lines.append("")

    if report.summary:
        lines.append("## Final Summary")
        lines.append("")
        lines.append(report.summary)
        lines.append("")

    return "\n".join(lines)
