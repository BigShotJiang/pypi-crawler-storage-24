"""Prompt templates for Claude Code subprocess calls."""

from __future__ import annotations

SCAN_PROMPT_TEMPLATE = """\
You are a security engineer triaging Dependabot vulnerability alerts for the repository "{repo}".

## Task
1. Fetch all open Dependabot vulnerability alerts for the repository "{repo}"{severity_clause}.
2. For each alert:
   a. Read the CVE/GHSA description and severity.
   b. Search the codebase to determine if the vulnerable code path is actually used.
   c. Assess the real risk level.
   d. Recommend an action.
3. Group alerts by package (one upgrade can fix multiple CVEs).
4. Return your analysis as structured JSON.

## How to fetch alerts
{fetch_instructions}

## How to check code usage
{code_instructions}

## Output format
Return ONLY a JSON object (no markdown fences, no extra text) with this exact structure:
{{
  "groups": [
    {{
      "package_name": "package-name",
      "package_ecosystem": "pip|npm|etc",
      "current_version": "1.2.3",
      "target_version": "1.2.4 or null if no fix available",
      "alerts": [
        {{
          "alert_number": 1,
          "cve_id": "CVE-2024-XXXX or null",
          "package_name": "package-name",
          "severity": "critical|high|medium|low",
          "summary": "Plain English description of the vulnerability",
          "affected": true,
          "evidence": "Found usage of vulnerable function X in file Y at line Z",
          "risk_level": "critical|high|medium|low",
          "recommended_action": "Upgrade to version X.Y.Z"
        }}
      ]
    }}
  ]
}}

Be thorough in your code search. Look for imports, function calls, and transitive dependencies.
If you cannot determine usage, err on the side of caution and mark as affected.
"""

NOTIFY_SLACK_TEMPLATE = """\
Post the following vulnerability scan report to the Slack channel "{channel}".

Format it as a clear, readable Slack message with:
- A header summarizing the scan (repo/org, date, total alerts)
- A section for each risk level (critical first, then high, medium, low)
- For each alert group: package name, number of CVEs, whether code is affected, and recommended action
- A summary line at the bottom with totals

Here is the report data:
{report_json}
"""

NOTIFY_JIRA_TEMPLATE = """\
Create Jira tickets for the following vulnerability findings that require action.

Only create tickets for alerts marked as "affected: true" with risk_level "critical" or "high".
Group by package so each ticket covers one upgrade.

For each ticket:
- Title: "[Security] Upgrade {{package}} to {{version}} - {{count}} CVEs"
- Description: List each CVE, its severity, and where the vulnerable code is used
- Priority: Critical for critical risk, High for high risk
- Labels: security, dependabot, dobbe

Report data:
{report_json}
"""


def build_scan_prompt(
    repo: str,
    severity_filter: list[str] | None = None,
    available_mcps: dict[str, bool] | None = None,
    access_mode: str = "remote",
    local_path: str | None = None,
) -> str:
    """Build the prompt for scanning a repository's Dependabot alerts."""
    if available_mcps is None:
        available_mcps = {}

    # Severity filter clause
    severity_clause = ""
    if severity_filter:
        severity_clause = f" Filter to only {', '.join(severity_filter)} severity alerts."

    # Fetch instructions - depends on whether GitHub MCP is available
    if available_mcps.get("github"):
        fetch_instructions = (
            f'Use the GitHub MCP tools to list Dependabot alerts for "{repo}". '
            "Call the appropriate GitHub MCP function to get vulnerability alerts. "
            "If there's no specific Dependabot tool, use the GitHub API via MCP: "
            f"GET /repos/{repo}/dependabot/alerts?state=open"
        )
    else:
        fetch_instructions = (
            "Use the Bash tool to run:\n"
            f"  gh api /repos/{repo}/dependabot/alerts?state=open --paginate\n"
            "This requires the GitHub CLI (gh) to be installed and authenticated."
        )

    # Code inspection instructions - depends on local vs remote access
    if access_mode == "local" and local_path:
        code_instructions = (
            f'The repository is cloned locally at "{local_path}". '
            "Use the Grep tool to search for imports and usage of vulnerable packages. "
            "Use the Read tool to examine specific files for vulnerable code patterns. "
            "Use the Glob tool to find relevant files (e.g., requirements.txt, package.json, "
            "source files that import the vulnerable package)."
        )
    else:
        if available_mcps.get("github"):
            code_instructions = (
                f"The repository is not cloned locally. Use GitHub MCP to read files from "
                f'"{repo}" to check for usage of vulnerable packages. '
                "Look at dependency files (requirements.txt, package.json, etc.) and search "
                "source files for imports of vulnerable packages."
            )
        else:
            code_instructions = (
                f"The repository is not cloned locally. Use the Bash tool to read files via "
                f"the GitHub API:\n"
                f"  gh api /repos/{repo}/contents/{{path}} --jq '.content' | base64 -d\n"
                "Check dependency files and source files for usage of vulnerable packages."
            )

    return SCAN_PROMPT_TEMPLATE.format(
        repo=repo,
        severity_clause=severity_clause,
        fetch_instructions=fetch_instructions,
        code_instructions=code_instructions,
    )


FIX_PROMPT_TEMPLATE = """\
You are a dependency upgrade agent for the repository at "{local_path}".

## Task
Apply the following vulnerability fixes by modifying dependency files. For each fix:
1. Find the dependency file (requirements.txt, package.json, pyproject.toml, etc.)
2. Update the version constraint to include the target version
3. If a lockfile exists (package-lock.json, poetry.lock, etc.), update it by running the appropriate install command

## Vulnerabilities to fix
{scan_summary}

## Rules
- Only bump to the PATCH or MINOR version that fixes the CVE. Do NOT jump to a new major version.
- If no safe minor/patch fix exists, SKIP the package and explain why.
- After editing files, run the package manager install/lock command to regenerate lockfiles.
- Do NOT modify application source code - only dependency specification files.

{feedback_section}

## Output format
Return ONLY a JSON object (no markdown fences, no extra text) with this structure:
{{
  "fixes": [
    {{
      "package_name": "package-name",
      "file_modified": "requirements.txt",
      "old_version": "1.2.3",
      "new_version": "1.2.4",
      "alerts_addressed": [1, 2],
      "status": "applied"
    }}
  ],
  "skipped": [
    {{
      "package_name": "package-name",
      "reason": "No patch available - requires major version bump",
      "alerts_skipped": [3]
    }}
  ],
  "diff_summary": "Brief description of all changes made"
}}
"""

VERIFY_PROMPT_TEMPLATE = """\
You are a verification agent reviewing dependency upgrades in the repository at "{local_path}".

## Task
Review the changes made on branch "{branch}" compared to "{base_branch}" and verify they are safe.

## Steps
1. Run `git diff {base_branch}...{branch}` to see all changes.
2. For each modified dependency, check if the new version introduces breaking changes:
   - Read the package changelog or release notes if accessible
   - Look for API changes that affect the codebase
3. Run the project's test suite:
   - Python: `python -m pytest` or check for a test script
   - Node: `npm test` or `yarn test`
   - If no test command is found, note this as a limitation
4. Check lockfile consistency (no conflicting versions, lockfile matches spec).

## Output format
Return ONLY a JSON object (no markdown fences, no extra text) with this structure:
{{
  "passed": true,
  "issues": [
    {{
      "category": "test_failure|breaking_change|lockfile_inconsistency|dependency_conflict|other",
      "severity": "critical|high|medium|low",
      "description": "What went wrong",
      "suggestion": "How to fix it"
    }}
  ],
  "test_output": "Summary of test run output",
  "feedback": "If issues found, concise instructions for the fix agent to resolve them"
}}

Set "passed" to true ONLY if: all tests pass, no breaking changes found, and lockfile is consistent.
If ANY issue is found, set "passed" to false and provide clear feedback.
"""

REPORT_PROMPT_TEMPLATE = """\
You are a reporting agent summarizing a vulnerability resolution pipeline run.

## Pipeline Data
Repository: {repo}
Iterations: {iteration_count}
Converged: {converged}

## Scan Summary
{scan_summary}

## Iteration Details
{iteration_details}

## Task
Write a concise executive summary covering:
1. What was fixed (packages, versions, CVE counts)
2. What was skipped and why
3. Verification results (passed/failed, issues found)
4. Risk assessment (low/medium/high) for merging these changes
5. Recommended next steps

Return ONLY a plain text summary (no JSON, no markdown fences). Keep it under 500 words.
"""


def build_fix_prompt(
    local_path: str,
    scan_summary: str,
    feedback: str = "",
) -> str:
    """Build the prompt for the fix agent."""
    feedback_section = ""
    if feedback:
        feedback_section = (
            "## Previous Attempt Feedback\n"
            "The verify agent found issues with your previous fix. "
            "Address the following before applying fixes:\n\n"
            f"{feedback}\n"
        )

    return FIX_PROMPT_TEMPLATE.format(
        local_path=local_path,
        scan_summary=scan_summary,
        feedback_section=feedback_section,
    )


def build_verify_prompt(
    local_path: str,
    branch: str,
    base_branch: str,
) -> str:
    """Build the prompt for the verify agent."""
    return VERIFY_PROMPT_TEMPLATE.format(
        local_path=local_path,
        branch=branch,
        base_branch=base_branch,
    )


def build_report_prompt(
    repo: str,
    scan_summary: str,
    iteration_count: int,
    converged: bool,
    iteration_details: str,
) -> str:
    """Build the prompt for the report agent."""
    return REPORT_PROMPT_TEMPLATE.format(
        repo=repo,
        scan_summary=scan_summary,
        iteration_count=iteration_count,
        converged=converged,
        iteration_details=iteration_details,
    )


PR_DISCOVERY_PROMPT_TEMPLATE = """\
You are a PR review assistant. Find all open pull requests for the repository "{repo}" \
where the following reviewers are requested: {reviewers}.

## How to fetch PRs
{fetch_instructions}

## Output format
Return ONLY a JSON object (no markdown fences, no extra text) with this structure:
{{
  "prs": [
    {{
      "repo": "{repo}",
      "pr_number": 123,
      "title": "PR title",
      "author": "username",
      "url": "https://github.com/{repo}/pull/123",
      "created_at": "2024-01-15T10:30:00Z",
      "updated_at": "2024-01-16T12:00:00Z",
      "additions": 50,
      "deletions": 10,
      "changed_files": 3,
      "draft": false,
      "description": "PR body/description text",
      "labels": ["label1"]
    }}
  ]
}}

Include all open PRs awaiting review. If no PRs are found, return {{"prs": []}}.
"""

PR_REVIEW_PROMPT_TEMPLATE = """\
You are a senior engineer performing a thorough code review of PR #{pr_number} in "{repo}".

**Title:** {title}
**Author:** {author}
**Description:** {description}

## Task
1. Fetch the PR diff using the available tools.
{diff_instructions}
2. Read related source files for context (test files, imports, dependent modules).
3. Analyze the changes for:
   - **Security:** injection, auth issues, secrets, unsafe operations
   - **Test coverage:** are changes tested? are tests meaningful?
   - **Breaking changes:** API changes, removed exports, changed behavior
   - **Code quality:** naming, duplication, error handling, readability
   - **Complexity:** large functions, deep nesting, unclear logic
4. Provide a risk assessment and review recommendation.

If the diff is too large to fully analyze, note this in the summary and focus on the highest-risk files.

## Output format
Return ONLY a JSON object (no markdown fences, no extra text) with this structure:
{{
  "risk_level": "critical|high|medium|low",
  "summary": "Brief summary of the PR and its quality",
  "concerns": [
    {{
      "category": "security|test_coverage|breaking_change|code_quality|complexity",
      "severity": "critical|high|medium|low",
      "description": "What the concern is",
      "file_path": "path/to/file.py",
      "line_number": 42,
      "suggestion": "How to address it"
    }}
  ],
  "recommendations": ["List of actionable review comments"],
  "note": "line_number should be the line in the NEW version of the file. Use null if not tied to a specific line.",
  "estimated_review_time": "15 min",
  "approval_recommendation": "approve|request_changes|needs_discussion"
}}
"""

REVIEW_NOTIFY_SLACK_TEMPLATE = """\
Post the following PR review digest to the Slack channel "{channel}".

Format it as a clear, readable Slack message with:
- A header summarizing the digest (repos scanned, total PRs, critical count)
- A section for each risk level (critical first, then high, medium, low)
- For each PR: repo, PR number, title, author, risk level, and top concern
- A summary line at the bottom with stale PR count

Here is the digest data:
{digest_json}
"""


def build_pr_discovery_prompt(
    repo: str,
    reviewers: list[str],
    available_mcps: dict[str, bool] | None = None,
) -> str:
    """Build the prompt for discovering open PRs in a repository."""
    if available_mcps is None:
        available_mcps = {}

    reviewers_str = ", ".join(reviewers)

    if available_mcps.get("github"):
        fetch_instructions = (
            f"Use the GitHub MCP tools to search for open pull requests in \"{repo}\" "
            f"where the requested reviewers include: {reviewers_str}. "
            "Retrieve PR metadata including number, title, author, dates, additions, "
            "deletions, changed_files, draft status, and body."
        )
    else:
        reviewer_flags = " ".join(f"--reviewer {r}" for r in reviewers if r != "@me")
        if "@me" in reviewers:
            reviewer_flags = "--reviewer @me" + (f" {reviewer_flags}" if reviewer_flags else "")
        if not reviewer_flags:
            reviewer_flags = "--reviewer @me"
        fetch_instructions = (
            "Use the Bash tool to run:\n"
            f"  gh pr list --repo {repo} {reviewer_flags} --state open "
            f"--json number,title,author,url,createdAt,updatedAt,additions,deletions,changedFiles,isDraft,body,labels\n"
            "This requires the GitHub CLI (gh) to be installed and authenticated."
        )

    return PR_DISCOVERY_PROMPT_TEMPLATE.format(
        repo=repo,
        reviewers=reviewers_str,
        fetch_instructions=fetch_instructions,
    )


def build_pr_review_prompt(
    repo: str,
    pr_number: int,
    title: str,
    author: str,
    description: str = "",
    available_mcps: dict[str, bool] | None = None,
    diff_content: str | None = None,
) -> str:
    """Build the prompt for deep review of a single PR."""
    if available_mcps is None:
        available_mcps = {}

    if diff_content:
        diff_instructions = (
            "   Review the PR diff provided below.\n"
            f"   <diff>\n{diff_content}\n   </diff>"
        )
    elif available_mcps.get("github"):
        diff_instructions = (
            f"   Use the GitHub MCP tools to fetch the diff for PR #{pr_number} "
            f"in \"{repo}\". Also read relevant source files for context."
        )
    else:
        diff_instructions = (
            "   Use the Bash tool to run:\n"
            f"     gh pr diff {pr_number} --repo {repo}\n"
            "   to get the full diff. Use gh api to read related files if needed."
        )

    return PR_REVIEW_PROMPT_TEMPLATE.format(
        repo=repo,
        pr_number=pr_number,
        title=title,
        author=author,
        description=description or "(no description)",
        diff_instructions=diff_instructions,
    )


def build_review_notify_prompt(
    digest_json: str,
    channel: str,
) -> str:
    """Build a prompt for posting a review digest to Slack."""
    return REVIEW_NOTIFY_SLACK_TEMPLATE.format(
        channel=channel,
        digest_json=digest_json,
    )


def build_notify_prompt(
    report_json: str,
    channel: str = "",
    platform: str = "slack",
) -> str:
    """Build a prompt for posting results to a notification platform."""
    if platform == "slack":
        return NOTIFY_SLACK_TEMPLATE.format(channel=channel, report_json=report_json)
    elif platform == "jira":
        return NOTIFY_JIRA_TEMPLATE.format(report_json=report_json)
    else:
        raise ValueError(f"Unknown notification platform: {platform}")
