"""Read and write dobbe configuration from ~/.dobbe/config.toml."""

from __future__ import annotations

import copy
import sys
from pathlib import Path
from typing import Any

import tomli_w

if sys.version_info >= (3, 12):
    import tomllib
else:
    import tomli as tomllib


CONFIG_DIR = Path.home() / ".dobbe"
CONFIG_FILE = CONFIG_DIR / "config.toml"
SCHEDULES_FILE = CONFIG_DIR / "schedules.toml"
LOGS_DIR = CONFIG_DIR / "logs" / "schedules"
LOCKS_DIR = CONFIG_DIR / "locks"

DEFAULT_CONFIG: dict[str, Any] = {
    "general": {
        "default_org": "",
        "default_format": "table",
        "default_severity": "critical,high",
    },
    "notifications": {
        "slack_channel": "",
    },
    "repos": {
        "local_paths": [],
    },
}


def ensure_config_dir() -> Path:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    return CONFIG_DIR


_config_cache: dict[str, Any] | None = None


def load_config() -> dict[str, Any]:
    global _config_cache
    if _config_cache is not None:
        return copy.deepcopy(_config_cache)
    if not CONFIG_FILE.exists():
        result = copy.deepcopy(DEFAULT_CONFIG)
    else:
        try:
            raw = CONFIG_FILE.read_bytes()
            result = tomllib.loads(raw.decode())
        except (UnicodeDecodeError, tomllib.TOMLDecodeError, IsADirectoryError, PermissionError) as e:
            from rich.console import Console as _Console
            _Console(stderr=True).print(
                f"[yellow]Warning: config file is corrupted ({e}), using defaults.[/yellow]"
            )
            result = copy.deepcopy(DEFAULT_CONFIG)
    _config_cache = result
    return copy.deepcopy(result)


def invalidate_config_cache() -> None:
    """Clear the config cache. Called automatically by save_config()."""
    global _config_cache
    _config_cache = None


def save_config(config: dict[str, Any]) -> Path:
    invalidate_config_cache()
    ensure_config_dir()
    CONFIG_FILE.write_bytes(tomli_w.dumps(config).encode())
    return CONFIG_FILE


def get_default_org(config: dict[str, Any] | None = None) -> str:
    if config is None:
        config = load_config()
    return config.get("general", {}).get("default_org", "")


def get_default_format(config: dict[str, Any] | None = None) -> str:
    if config is None:
        config = load_config()
    return config.get("general", {}).get("default_format", "table")


def get_default_severity(config: dict[str, Any] | None = None) -> list[str]:
    if config is None:
        config = load_config()
    raw = config.get("general", {}).get("default_severity", "critical,high")
    if not isinstance(raw, str):
        return [s.strip() for s in "critical,high".split(",")]
    return [s.strip() for s in raw.split(",") if s.strip()]


def get_local_paths(config: dict[str, Any] | None = None) -> list[str]:
    if config is None:
        config = load_config()
    return config.get("repos", {}).get("local_paths", [])


def get_slack_channel(config: dict[str, Any] | None = None) -> str:
    if config is None:
        config = load_config()
    return config.get("notifications", {}).get("slack_channel", "")


def get_review_watch_repos(config: dict[str, Any] | None = None) -> list[str]:
    if config is None:
        config = load_config()
    return config.get("review", {}).get("watch_repos", [])


def get_review_reviewers(config: dict[str, Any] | None = None) -> list[str]:
    if config is None:
        config = load_config()
    return config.get("review", {}).get("reviewers", ["@me"])


def get_review_stale_days(config: dict[str, Any] | None = None) -> int:
    if config is None:
        config = load_config()
    return config.get("review", {}).get("stale_days", 7)


def get_review_skip_labels(config: dict[str, Any] | None = None) -> list[str]:
    if config is None:
        config = load_config()
    return config.get("review", {}).get("skip_labels", [])


def get_review_skip_authors(config: dict[str, Any] | None = None) -> list[str]:
    if config is None:
        config = load_config()
    return config.get("review", {}).get("skip_authors", [])


def get_review_max_diff_lines(config: dict[str, Any] | None = None) -> int:
    if config is None:
        config = load_config()
    return config.get("review", {}).get("max_diff_lines", 2000)
