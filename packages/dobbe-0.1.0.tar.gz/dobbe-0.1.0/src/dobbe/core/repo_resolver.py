"""Resolve how to access a repository - local clone or remote via GitHub MCP."""

from __future__ import annotations

from pathlib import Path

from dobbe.core.config_manager import get_local_paths, load_config
from dobbe.models.alert import AccessMode

# Common directories where developers keep project clones
COMMON_PROJECT_DIRS = [
    Path.home() / "projects",
    Path.home() / "Projects",
    Path.home() / "Desktop" / "Projects",
    Path.home() / "Desktop" / "projects",
    Path.home() / "code",
    Path.home() / "Code",
    Path.home() / "src",
    Path.home() / "repos",
    Path.home() / "dev",
    Path.home() / "workspace",
    Path.home() / "Developer",
]


def _extract_repo_name(repo_slug: str) -> str:
    """Extract the repo name from an org/repo slug."""
    return repo_slug.split("/")[-1]


def _find_in_configured_paths(repo_slug: str, config: dict | None = None) -> Path | None:
    """Check configured local_paths for a matching clone."""
    if config is None:
        config = load_config()
    local_paths = get_local_paths(config)
    repo_name = _extract_repo_name(repo_slug)

    for path_str in local_paths:
        path = Path(path_str)
        if path.exists() and path.is_dir():
            # Check if this path IS the repo (directory name matches)
            if path.name == repo_name and (path / ".git").exists():
                return path
            # Check if the repo is a subdirectory
            candidate = path / repo_name
            if candidate.exists() and (candidate / ".git").exists():
                return candidate

    return None


def _scan_common_directories(repo_slug: str) -> Path | None:
    """Scan common project directories for a matching clone."""
    repo_name = _extract_repo_name(repo_slug)

    for base_dir in COMMON_PROJECT_DIRS:
        if not base_dir.exists():
            continue
        candidate = base_dir / repo_name
        if candidate.exists() and (candidate / ".git").exists():
            return candidate

    # Also check cwd and its parent
    cwd = Path.cwd()
    if cwd.name == repo_name and (cwd / ".git").exists():
        return cwd
    candidate = cwd / repo_name
    if candidate.exists() and (candidate / ".git").exists():
        return candidate

    return None


def resolve_repo(repo_slug: str, config: dict | None = None) -> tuple[AccessMode, Path | None]:
    """Determine how to access a repository.

    Returns:
        (AccessMode.LOCAL, path) if a local clone is found
        (AccessMode.REMOTE, None) if no local clone - Claude will use GitHub MCP
    """
    # 1. Check configured paths first
    local = _find_in_configured_paths(repo_slug, config)
    if local:
        return AccessMode.LOCAL, local

    # 2. Scan common directories
    local = _scan_common_directories(repo_slug)
    if local:
        return AccessMode.LOCAL, local

    # 3. Fall back to remote
    return AccessMode.REMOTE, None


def resolve_repos(
    repo_slugs: list[str], config: dict | None = None
) -> dict[str, tuple[AccessMode, Path | None]]:
    """Resolve access mode for multiple repositories.

    Pre-scans common project directories once instead of per-repo,
    avoiding redundant filesystem checks when resolving many repos.
    """
    if config is None:
        config = load_config()

    if not repo_slugs:
        return {}

    # Pre-scan: build {dir_name: path} for git repos in common directories
    scanned_repos: dict[str, Path] = {}
    for base_dir in COMMON_PROJECT_DIRS:
        if not base_dir.exists():
            continue
        try:
            for child in base_dir.iterdir():
                if child.is_dir() and (child / ".git").exists():
                    scanned_repos.setdefault(child.name, child)
        except OSError:
            continue

    # Also check cwd and its children
    cwd = Path.cwd()
    if (cwd / ".git").exists():
        scanned_repos.setdefault(cwd.name, cwd)
    try:
        for child in cwd.iterdir():
            if child.is_dir() and (child / ".git").exists():
                scanned_repos.setdefault(child.name, child)
    except OSError:
        pass

    results: dict[str, tuple[AccessMode, Path | None]] = {}
    for slug in repo_slugs:
        # 1. Check configured paths first
        local = _find_in_configured_paths(slug, config)
        if local:
            results[slug] = (AccessMode.LOCAL, local)
            continue

        # 2. Check pre-scanned common directories
        repo_name = _extract_repo_name(slug)
        if repo_name in scanned_repos:
            results[slug] = (AccessMode.LOCAL, scanned_repos[repo_name])
            continue

        # 3. Fall back to remote
        results[slug] = (AccessMode.REMOTE, None)

    return results
