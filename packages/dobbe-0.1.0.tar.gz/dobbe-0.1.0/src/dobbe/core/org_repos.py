"""Repository listing via Claude - org and user scopes."""

from __future__ import annotations

import json

from dobbe.core.claude import ask_claude, build_allowed_tools


class OrgListError(Exception):
    """Raised when repo listing fails."""


def _parse_repo_list(result_text: str) -> list[str]:
    """Extract a JSON array of repo slugs from Claude's response."""
    text = result_text.strip()
    start = text.find("[")
    end = text.rfind("]") + 1
    if start < 0 or end <= start:
        raise OrgListError("Could not parse repo list from Claude's response.")

    try:
        repos: list[str] = json.loads(text[start:end])
    except json.JSONDecodeError:
        raise OrgListError("Could not parse repo list.")

    return repos


def _build_filter_clauses(skip_forks: bool, skip_archived: bool) -> str:
    """Build filter instruction clauses for the prompt."""
    parts: list[str] = []
    if skip_forks:
        parts.append("Exclude forked repositories.")
    if skip_archived:
        parts.append("Exclude archived repositories.")
    return " ".join(parts)


def list_org_repos(
    org: str,
    available_mcps: dict[str, bool],
    timeout: int = 120,
    skip_forks: bool = True,
    skip_archived: bool = True,
) -> list[str]:
    """Ask Claude to list repos with Dependabot alerts for a GitHub org.

    Returns list of repo slugs (e.g. ["org/repo1", "org/repo2"]).
    Raises OrgListError on failure.
    """
    filter_clauses = _build_filter_clauses(skip_forks, skip_archived)
    prompt = (
        f"List all repositories in the GitHub organization '{org}' "
        f"that have Dependabot alerts enabled. "
        f"{filter_clauses} "
        f'Return ONLY a JSON array of repo slugs like ["org/repo1", "org/repo2"]. '
        f"No other text."
    ).strip()

    result = ask_claude(
        prompt=prompt,
        tools=build_allowed_tools(available_mcps=available_mcps),
        timeout=timeout,
    )

    if not result.success:
        raise OrgListError(result.error)

    return _parse_repo_list(result.text)


def list_user_repos(
    user: str,
    available_mcps: dict[str, bool],
    timeout: int = 120,
    skip_forks: bool = True,
    skip_archived: bool = True,
) -> list[str]:
    """Ask Claude to list repos with Dependabot alerts for a GitHub user.

    Returns list of repo slugs (e.g. ["user/repo1", "user/repo2"]).
    Raises OrgListError on failure.
    """
    filter_clauses = _build_filter_clauses(skip_forks, skip_archived)
    prompt = (
        f"List all repositories owned by the GitHub user '{user}' "
        f"that have open Dependabot alerts. "
        f"Use `gh api '/users/{user}/repos?type=owner&per_page=100' --paginate`. "
        f"{filter_clauses} "
        f'Return ONLY a JSON array of repo slugs like ["{user}/repo1", "{user}/repo2"]. '
        f"No other text."
    ).strip()

    result = ask_claude(
        prompt=prompt,
        tools=build_allowed_tools(available_mcps=available_mcps),
        timeout=timeout,
    )

    if not result.success:
        raise OrgListError(result.error)

    return _parse_repo_list(result.text)


def list_repos(
    owner: str,
    available_mcps: dict[str, bool],
    is_user: bool = False,
    **kwargs: object,
) -> list[str]:
    """Convenience dispatcher - calls list_user_repos or list_org_repos."""
    if is_user:
        return list_user_repos(owner, available_mcps, **kwargs)  # type: ignore[arg-type]
    return list_org_repos(owner, available_mcps, **kwargs)  # type: ignore[arg-type]
