"""Internal state tracking for dobbe (~/.dobbe/state.toml)."""

from __future__ import annotations

import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import tomli_w

if sys.version_info >= (3, 12):
    import tomllib
else:
    import tomli as tomllib

from dobbe.core.config_manager import CONFIG_DIR


STATE_FILE = CONFIG_DIR / "state.toml"


def load_state() -> dict[str, Any]:
    """Load internal state. Returns empty dict if file is missing or corrupted."""
    try:
        return tomllib.loads(STATE_FILE.read_bytes().decode())
    except FileNotFoundError:
        return {}
    except (UnicodeDecodeError, tomllib.TOMLDecodeError, PermissionError):
        return {}


def save_state(state: dict[str, Any]) -> None:
    """Persist internal state to disk. Silently ignores write failures."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        if STATE_FILE.is_symlink():
            STATE_FILE.unlink()
        STATE_FILE.write_bytes(tomli_w.dumps(state).encode())
    except (PermissionError, OSError):
        pass


def increment_run_count() -> int:
    """Bump runs_since_setup and return the new count."""
    state = load_state()
    count = state.get("runs_since_setup", 0) + 1
    state["runs_since_setup"] = count
    save_state(state)
    return count


def mark_setup_complete() -> None:
    """Record that setup finished - resets run counter."""
    state = load_state()
    state["runs_since_setup"] = 0
    state["setup_completed_at"] = datetime.now(timezone.utc).isoformat()
    save_state(state)


def get_run_count() -> int:
    """Return current runs_since_setup (0 if never set)."""
    return load_state().get("runs_since_setup", 0)
