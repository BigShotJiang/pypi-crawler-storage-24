"""Batch resolve orchestrator - runs pipeline across multiple repos sequentially."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable

from dobbe.core.pipeline import PipelineConfig, run_pipeline
from dobbe.models.resolve import AgentMessage, ResolveReport

logger = logging.getLogger(__name__)


@dataclass
class BatchResolveConfig:
    """Configuration for batch resolve across multiple repos."""

    repos: list[str]
    severity_filter: list[str] = field(default_factory=lambda: ["critical", "high"])
    available_mcps: dict[str, bool] = field(default_factory=dict)
    max_iterations: int = 3
    base_branch: str = "main"
    dry_run: bool = False
    skip_verify: bool = False
    no_pr: bool = False
    timeout_per_step: int = 600
    scan_overrides: dict[str, str] = field(default_factory=dict)


def run_batch_resolve(
    cfg: BatchResolveConfig,
    on_repo_start: Callable[[str, int, int], None] | None = None,
    on_repo_done: Callable[[str, ResolveReport], None] | None = None,
    callbacks: Callable[[AgentMessage], None] | None = None,
) -> list[ResolveReport]:
    """Run resolve pipeline for each repo sequentially.

    Args:
        cfg: Batch configuration.
        on_repo_start: Called with (repo, index, total) before each repo.
        on_repo_done: Called with (repo, report) after each repo.
        callbacks: Forwarded to each pipeline for live agent messages.

    Returns:
        List of ResolveReport, one per repo (failed repos get error reports).
    """
    reports: list[ResolveReport] = []
    total = len(cfg.repos)

    for i, repo in enumerate(cfg.repos):
        if on_repo_start:
            on_repo_start(repo, i + 1, total)

        try:
            pipeline_cfg = PipelineConfig(
                repo=repo,
                severity_filter=cfg.severity_filter,
                available_mcps=cfg.available_mcps,
                max_iterations=cfg.max_iterations,
                base_branch=cfg.base_branch,
                dry_run=cfg.dry_run,
                skip_verify=cfg.skip_verify,
                no_pr=cfg.no_pr,
                timeout_per_step=cfg.timeout_per_step,
                scan_summary_override=cfg.scan_overrides.get(repo),
            )
            report = run_pipeline(pipeline_cfg, callbacks=callbacks)
        except Exception as exc:
            logger.warning("Pipeline failed for %s: %s", repo, exc)
            report = ResolveReport(
                repo=repo,
                scan_summary=f"Pipeline error: {exc}",
                max_iterations=cfg.max_iterations,
            )

        reports.append(report)

        if on_repo_done:
            on_repo_done(repo, report)

    return reports
