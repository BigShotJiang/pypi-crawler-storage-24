"""First-run detection, interactive setup prompt, and post-run tips."""

from __future__ import annotations

import os

import click
import typer
from rich.console import Console

from dobbe.core.config_manager import CONFIG_FILE
from dobbe.core.state_manager import get_run_count

console = Console()

_prompted_this_session: bool = False

# Commands that should never trigger the first-run prompt
SETUP_EXEMPT = {"setup", "doctor"}

TIPS = [
    "Tip: Run [bold]dobbe doctor[/bold] to check your environment health.",
    "Tip: Use [bold]dobbe schedule add[/bold] to automate recurring scans.",
    "Tip: Add [bold]--verbose[/bold] (-V) to see evidence and upgrade paths.",
]


def invalidate_first_run_flag() -> None:
    """Reset session guard - for testing only."""
    global _prompted_this_session
    _prompted_this_session = False


def should_prompt_setup(command_name: str | None, quiet: bool) -> bool:
    """Return True if we should offer the setup wizard."""
    if quiet:
        return False
    if os.environ.get("CI"):
        return False
    if _prompted_this_session:
        return False
    if command_name in SETUP_EXEMPT:
        return False
    if CONFIG_FILE.exists():
        return False
    return True


def prompt_and_run_setup() -> bool:
    """Ask user whether to run setup now. Returns True if setup was run."""
    global _prompted_this_session
    _prompted_this_session = True

    try:
        console.print(
            "\n[bold]Welcome to dobbe![/bold] It looks like this is your first run."
        )
        run_now = typer.confirm(
            "No configuration found. Run setup wizard now?", default=False
        )
    except (EOFError, KeyboardInterrupt, click.exceptions.Abort):
        # Non-interactive context (piped input, --help, etc.)
        return False

    if not run_now:
        console.print(
            "Skipped. Run [bold]dobbe setup[/bold] when you're ready, "
            "or use [bold]--repo[/bold] to get started immediately.\n"
        )
        return False

    from dobbe.commands.setup import run_setup_wizard

    try:
        run_setup_wizard()
    except (typer.Exit, SystemExit):
        console.print("\n[yellow]Setup did not complete. Continuing without configuration.[/yellow]\n")
        return False
    return True


def maybe_show_tip(quiet: bool) -> None:
    """Show a rotating tip for the first 3 runs after setup."""
    if quiet:
        return
    if os.environ.get("CI"):
        return
    count = get_run_count()
    if 1 <= count <= len(TIPS):
        console.print(f"\n[dim]{TIPS[count - 1]}[/dim]")
