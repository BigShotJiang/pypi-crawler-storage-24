"""Claude Code subprocess wrapper - invokes `claude -p` for AI calls."""

from __future__ import annotations

import asyncio
import json
import shutil
import subprocess
import time
from dataclasses import dataclass

from dobbe.core.mcp_discovery import get_mcp_tool_prefix


@dataclass
class ClaudeResult:
    """Result from a Claude Code subprocess call."""

    success: bool
    text: str = ""
    raw_json: dict | None = None
    error: str = ""


# Base tools always available to Claude
BASE_TOOLS = ["Bash", "Read", "Grep", "Glob"]

# Agent-specific tool sets for the resolve pipeline
FIX_TOOLS = BASE_TOOLS + ["Edit", "Write"]
VERIFY_TOOLS = list(BASE_TOOLS)  # read-only + Bash for tests
REPORT_TOOLS = ["Read"]

DEFAULT_TIMEOUT = 300  # 5 minutes per call
RETRY_BACKOFF_BASE = 2  # exponential backoff base in seconds


def _extract_text_from_parsed(parsed: dict | str) -> str:
    """Extract text content from parsed Claude JSON output."""
    if isinstance(parsed, str):
        return parsed
    if isinstance(parsed, dict):
        text = parsed.get("result", parsed.get("text", ""))
        if not text and "content" in parsed:
            content = parsed["content"]
            if isinstance(content, list):
                text = "\n".join(
                    block.get("text", "") for block in content if block.get("type") == "text"
                )
            elif isinstance(content, str):
                text = content
        return text
    return ""


def build_agent_tools(
    role: str,
    available_mcps: dict[str, bool] | None = None,
) -> list[str]:
    """Build tool list for a specific pipeline agent role.

    Args:
        role: One of "scan", "fix", "verify", "report".
        available_mcps: MCP availability map.

    Returns:
        List of allowed tool names/patterns.
    """
    tool_map = {
        "scan": list(BASE_TOOLS),
        "fix": list(FIX_TOOLS),
        "verify": list(VERIFY_TOOLS),
        "report": list(REPORT_TOOLS),
    }
    tools = tool_map.get(role, list(BASE_TOOLS))

    if available_mcps:
        for mcp_name, available in available_mcps.items():
            if available:
                prefix = get_mcp_tool_prefix(mcp_name)
                if role in ("scan", "fix") or (role == "verify" and mcp_name == "github"):
                    tools.append(prefix)

    return tools


def _find_claude_binary() -> str | None:
    """Find the claude binary on the system."""
    return shutil.which("claude")


def is_claude_installed() -> bool:
    """Check if Claude Code CLI is installed."""
    return _find_claude_binary() is not None


def check_claude_auth() -> tuple[bool, str]:
    """Check if Claude Code is authenticated (logged in with Max subscription).

    Returns (success, message).
    """
    binary = _find_claude_binary()
    if not binary:
        return False, "Claude Code CLI is not installed. Install it from https://claude.ai/download"

    try:
        result = subprocess.run(
            [binary, "-p", "Reply with just the word OK", "--output-format", "json"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            return True, "Claude Code is installed and authenticated."
        return False, f"Claude Code returned an error: {result.stderr.strip()}"
    except subprocess.TimeoutExpired:
        return False, "Claude Code timed out - it may not be logged in."
    except OSError as e:
        return False, f"Failed to run Claude Code: {e}"


def build_allowed_tools(
    available_mcps: dict[str, bool] | None = None,
    access_mode: str = "local",
    extra_tools: list[str] | None = None,
) -> list[str]:
    """Build the --allowedTools list based on context."""
    tools = list(BASE_TOOLS)

    if available_mcps:
        for mcp_name, available in available_mcps.items():
            if available:
                tools.append(get_mcp_tool_prefix(mcp_name))

    if extra_tools:
        tools.extend(extra_tools)

    return tools


def ask_claude(
    prompt: str,
    tools: list[str] | None = None,
    cwd: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
    max_retries: int = 2,
) -> ClaudeResult:
    """Invoke Claude Code via subprocess.

    Args:
        prompt: The prompt to send to Claude.
        tools: List of allowed tools (glob patterns). If None, uses BASE_TOOLS.
        cwd: Working directory for the subprocess.
        timeout: Timeout in seconds.
        max_retries: Number of retries on transient failures (timeout, non-zero exit).

    Returns:
        ClaudeResult with the response.
    """
    binary = _find_claude_binary()
    if not binary:
        return ClaudeResult(
            success=False,
            error="Claude Code CLI is not installed.",
        )

    if tools is None:
        tools = list(BASE_TOOLS)

    cmd = [
        binary,
        "-p",
        prompt,
        "--allowedTools",
        ",".join(tools),
        "--output-format",
        "json",
    ]

    last_error = ""
    for attempt in range(max_retries + 1):
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )
        except subprocess.TimeoutExpired:
            last_error = f"Claude Code timed out after {timeout}s."
            if attempt < max_retries:
                time.sleep(RETRY_BACKOFF_BASE ** attempt)
                continue
            return ClaudeResult(success=False, error=last_error)
        except OSError as e:
            return ClaudeResult(success=False, error=f"Failed to run Claude Code: {e}")

        if result.returncode != 0:
            last_error = f"Claude Code exited with code {result.returncode}: {result.stderr.strip()}"
            if attempt < max_retries:
                time.sleep(RETRY_BACKOFF_BASE ** attempt)
                continue
            return ClaudeResult(success=False, error=last_error)

        # Parse JSON output
        try:
            parsed = json.loads(result.stdout)
        except json.JSONDecodeError:
            # If JSON parsing fails, treat stdout as raw text
            return ClaudeResult(success=True, text=result.stdout.strip())

        text = _extract_text_from_parsed(parsed)
        return ClaudeResult(success=True, text=text, raw_json=parsed)

    # Should not be reached, but safety net
    return ClaudeResult(success=False, error=last_error)


async def ask_claude_async(
    prompt: str,
    tools: list[str] | None = None,
    cwd: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
    max_retries: int = 2,
) -> ClaudeResult:
    """Async version of ask_claude for parallel execution."""
    binary = _find_claude_binary()
    if not binary:
        return ClaudeResult(success=False, error="Claude Code CLI is not installed.")

    if tools is None:
        tools = list(BASE_TOOLS)

    cmd = [
        binary,
        "-p",
        prompt,
        "--allowedTools",
        ",".join(tools),
        "--output-format",
        "json",
    ]

    last_error = ""
    for attempt in range(max_retries + 1):
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=cwd,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            proc.kill()
            await proc.wait()
            last_error = f"Claude Code timed out after {timeout}s."
            if attempt < max_retries:
                await asyncio.sleep(RETRY_BACKOFF_BASE ** attempt)
                continue
            return ClaudeResult(success=False, error=last_error)
        except OSError as e:
            return ClaudeResult(success=False, error=f"Failed to run Claude Code: {e}")

        stdout_str = stdout.decode() if stdout else ""
        stderr_str = stderr.decode() if stderr else ""

        if proc.returncode != 0:
            last_error = f"Claude Code exited with code {proc.returncode}: {stderr_str.strip()}"
            if attempt < max_retries:
                await asyncio.sleep(RETRY_BACKOFF_BASE ** attempt)
                continue
            return ClaudeResult(success=False, error=last_error)

        try:
            parsed = json.loads(stdout_str)
        except json.JSONDecodeError:
            return ClaudeResult(success=True, text=stdout_str.strip())

        text = _extract_text_from_parsed(parsed)
        return ClaudeResult(success=True, text=text, raw_json=parsed)

    # Should not be reached, but safety net
    return ClaudeResult(success=False, error=last_error)
