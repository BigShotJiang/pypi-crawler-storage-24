"""Discover available MCP servers from Claude Code configuration."""

from __future__ import annotations

import json
from pathlib import Path

from rich.console import Console

_console = Console(stderr=True)

# Well-known cloud MCP server identifiers (tied to Claude account, not local config)
CLOUD_MCP_PATTERNS: dict[str, list[str]] = {
    "atlassian": ["atlassian", "jira", "confluence"],
    "slack": ["slack"],
    "sentry": ["sentry"],
    "figma": ["figma"],
}

# MCP servers we care about for dobbe features
KNOWN_MCPS = ["github", "slack", "atlassian", "sentry", "figma"]


def _read_claude_settings() -> dict:
    """Read ~/.claude/settings.json if it exists."""
    settings_path = Path.home() / ".claude" / "settings.json"
    if not settings_path.exists():
        return {}
    try:
        return json.loads(settings_path.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _read_project_settings() -> dict:
    """Read .claude/settings.json in the current project if it exists."""
    project_settings = Path.cwd() / ".claude" / "settings.json"
    if not project_settings.exists():
        return {}
    try:
        return json.loads(project_settings.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def _find_mcp_servers_in_settings(settings: dict) -> dict[str, dict]:
    """Extract MCP server definitions from settings."""
    servers: dict[str, dict] = {}
    # mcpServers is a dict of server_name -> server_config
    mcp_servers = settings.get("mcpServers", {})
    for name, config in mcp_servers.items():
        if isinstance(config, dict):
            servers[name.lower()] = config
    return servers


def _find_enabled_plugins(settings: dict) -> list[str]:
    """Extract enabled plugin names from settings."""
    return settings.get("enabledPlugins", [])


def _classify_mcp(name: str, config: dict) -> str | None:
    """Try to classify an MCP server into a known category."""
    name_lower = name.lower()

    # Check name against cloud MCP patterns
    for category, patterns in CLOUD_MCP_PATTERNS.items():
        for pattern in patterns:
            if pattern in name_lower:
                return category

    # Check name for "github" (not a cloud MCP, but a common local MCP server)
    if "github" in name_lower:
        return "github"

    # Check command/args for hints
    command = config.get("command", "")
    args = " ".join(str(a) for a in config.get("args", []))
    combined = f"{command} {args}".lower()

    if "github" in combined:
        return "github"
    if "slack" in combined:
        return "slack"
    if "sentry" in combined:
        return "sentry"
    if "jira" in combined or "atlassian" in combined:
        return "atlassian"
    if "figma" in combined:
        return "figma"

    return None


_mcp_cache: dict[str, bool] | None = None


def invalidate_mcp_cache() -> None:
    """Clear the MCP discovery cache."""
    global _mcp_cache
    _mcp_cache = None


def discover_mcps() -> dict[str, bool]:
    """Discover which MCP servers are available.

    Returns a dict mapping known MCP names to availability.
    Example: {"github": True, "slack": True, "atlassian": False, "sentry": False, "figma": False}
    """
    global _mcp_cache
    if _mcp_cache is not None:
        return dict(_mcp_cache)

    result = {name: False for name in KNOWN_MCPS}

    try:
        # Check user-level settings
        user_settings = _read_claude_settings()
        user_servers = _find_mcp_servers_in_settings(user_settings)

        # Check project-level settings
        project_settings = _read_project_settings()
        project_servers = _find_mcp_servers_in_settings(project_settings)

        # Merge all found servers
        all_servers = {**user_servers, **project_servers}

        for name, config in all_servers.items():
            category = _classify_mcp(name, config)
            if category and category in result:
                result[category] = True

        # Check enabled plugins for cloud MCPs
        plugins = _find_enabled_plugins(user_settings)
        for plugin in plugins:
            plugin_lower = plugin.lower()
            for category, patterns in CLOUD_MCP_PATTERNS.items():
                for pattern in patterns:
                    if pattern in plugin_lower:
                        result[category] = True

        # Also check if cloud MCPs are referenced in plugin names like "claude_ai_Slack"
        for plugin in plugins:
            if "slack" in plugin.lower():
                result["slack"] = True
            if "atlassian" in plugin.lower() or "jira" in plugin.lower():
                result["atlassian"] = True
            if "sentry" in plugin.lower():
                result["sentry"] = True
            if "figma" in plugin.lower():
                result["figma"] = True
    except Exception as e:
        _console.print(f"[dim]MCP discovery warning: {e}[/dim]")
        _mcp_cache = result
        return dict(result)

    _mcp_cache = result
    return dict(result)


def get_mcp_tool_prefix(mcp_name: str) -> str:
    """Get the tool prefix pattern for a given MCP.

    Returns the --allowedTools glob pattern for this MCP.
    """
    prefixes = {
        "github": "mcp__github__*",
        "slack": "mcp__claude_ai_Slack__*",
        "atlassian": "mcp__claude_ai_Atlassian__*",
        "sentry": "mcp__claude_ai_Sentry__*",
        "figma": "mcp__claude_ai_Figma__*",
    }
    return prefixes.get(mcp_name, f"mcp__{mcp_name}__*")
