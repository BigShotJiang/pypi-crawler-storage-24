"""Notification dispatch - Slack, Jira, etc."""

from __future__ import annotations

from rich.console import Console

from dobbe.core.claude import ask_claude, build_allowed_tools
from dobbe.core.config_manager import get_slack_channel
from dobbe.core.prompts import build_notify_prompt


def send_notification(
    report_json: str,
    platform: str,
    channel: str | None,
    available_mcps: dict[str, bool],
    config: dict,
    console: Console,
) -> None:
    """Send a scan report to a notification platform (Slack or Jira)."""
    if platform == "slack":
        if not available_mcps.get("slack"):
            console.print("[bold red]Error:[/bold red] Slack MCP not available. Cannot send notification.")
            return
        target_channel = channel or get_slack_channel(config)
        if not target_channel:
            console.print("[bold red]Error:[/bold red] No Slack channel specified. Use --channel or configure in dobbe setup.")
            return

        console.print(f"\n[bold]Sending report to Slack channel {target_channel}...[/bold]")
        prompt = build_notify_prompt(report_json, channel=target_channel, platform="slack")
        tools = build_allowed_tools(available_mcps=available_mcps)

        result = ask_claude(prompt=prompt, tools=tools, timeout=120)
        if result.success:
            console.print(f"[bold green]✓[/bold green] Report posted to {target_channel}")
        else:
            console.print(f"[bold red]✗[/bold red] Failed to post to Slack: {result.error}")

    elif platform == "jira":
        if not available_mcps.get("atlassian"):
            console.print("[bold red]Error:[/bold red] Atlassian MCP not available. Cannot create Jira tickets.")
            return

        console.print("\n[bold]Creating Jira tickets for affected vulnerabilities...[/bold]")
        prompt = build_notify_prompt(report_json, platform="jira")
        tools = build_allowed_tools(available_mcps=available_mcps)

        result = ask_claude(prompt=prompt, tools=tools, timeout=120)
        if result.success:
            console.print("[bold green]✓[/bold green] Jira tickets created.")
        else:
            console.print(f"[bold red]✗[/bold red] Failed to create Jira tickets: {result.error}")

    else:
        console.print(f"[bold red]Error:[/bold red] Unknown notification platform: {platform}")
