"""Core scheduler logic - load/save schedules, overdue detection, execution, locking, logs."""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys
from datetime import datetime, timedelta
from pathlib import Path

import tomli_w

if sys.version_info >= (3, 12):
    import tomllib
else:
    import tomli as tomllib

from dobbe.core.config_manager import CONFIG_DIR, LOCKS_DIR, LOGS_DIR, SCHEDULES_FILE
from dobbe.models.schedule import (
    INTERVAL_DELTAS,
    CheckResult,
    RunLog,
    RunStatus,
    Schedule,
    ScheduleInterval,
)

GRACE_PERIOD = timedelta(minutes=5)
STALE_LOCK_HOURS = 2
MAX_LOGS_PER_SCHEDULE = 50


# ---------------------------------------------------------------------------
# Schedule persistence
# ---------------------------------------------------------------------------


def load_schedules() -> dict[str, Schedule]:
    """Read schedules from TOML file. Returns empty dict if file doesn't exist or is corrupt."""
    if not SCHEDULES_FILE.exists():
        return {}
    try:
        raw = SCHEDULES_FILE.read_bytes()
        data = tomllib.loads(raw.decode())
        schedules: dict[str, Schedule] = {}
        for name, entry in data.items():
            if not isinstance(entry, dict):
                continue
            fields = dict(entry)  # copy to avoid mutating parsed TOML
            fields["name"] = name
            # Parse interval enum
            fields["interval"] = ScheduleInterval(fields["interval"])
            # Parse datetimes from ISO strings
            if fields.get("last_run"):
                fields["last_run"] = datetime.fromisoformat(fields["last_run"])
            if fields.get("created_at"):
                fields["created_at"] = datetime.fromisoformat(fields["created_at"])
            schedules[name] = Schedule(**fields)
        return schedules
    except (UnicodeDecodeError, tomllib.TOMLDecodeError, ValueError, TypeError, KeyError) as e:
        from rich.console import Console as _Console
        _Console(stderr=True).print(
            f"[yellow]Warning: schedules file is corrupted ({e}), returning empty.[/yellow]"
        )
        return {}


def save_schedules(schedules: dict[str, Schedule]) -> None:
    """Serialize schedules to TOML with ISO datetimes."""
    SCHEDULES_FILE.parent.mkdir(parents=True, exist_ok=True)
    data: dict[str, dict] = {}
    for name, sched in schedules.items():
        entry: dict = {
            "command": sched.command,
            "args": sched.args,
            "interval": sched.interval.value,
            "enabled": sched.enabled,
        }
        if sched.last_run is not None:
            entry["last_run"] = sched.last_run.isoformat()
        if sched.created_at is not None:
            entry["created_at"] = sched.created_at.isoformat()
        data[name] = entry
    SCHEDULES_FILE.write_bytes(tomli_w.dumps(data).encode())


def _sanitize_schedule_name(name: str) -> None:
    """Raise ValueError if name contains path traversal characters."""
    if any(c in name for c in ("/", "\\", "\x00")) or ".." in name:
        raise ValueError(f"Invalid schedule name: {name!r}")


def add_schedule(schedule: Schedule) -> None:
    """Add a new schedule. Raises ValueError if name already exists."""
    _sanitize_schedule_name(schedule.name)
    schedules = load_schedules()
    if schedule.name in schedules:
        msg = f"Schedule '{schedule.name}' already exists"
        raise ValueError(msg)
    schedules[schedule.name] = schedule
    save_schedules(schedules)


def remove_schedule(name: str) -> None:
    """Remove a schedule by name. Raises KeyError if not found."""
    schedules = load_schedules()
    if name not in schedules:
        msg = f"Schedule '{name}' not found"
        raise KeyError(msg)
    del schedules[name]
    save_schedules(schedules)


# ---------------------------------------------------------------------------
# Overdue detection
# ---------------------------------------------------------------------------


def find_overdue(schedules: dict[str, Schedule], now: datetime | None = None) -> list[Schedule]:
    """Return enabled schedules that are overdue (binary - at most 1 catch-up run each)."""
    if now is None:
        now = datetime.now()
    overdue: list[Schedule] = []
    for sched in schedules.values():
        if not sched.enabled:
            continue
        delta = INTERVAL_DELTAS[sched.interval]
        if sched.last_run is None:
            overdue.append(sched)
        elif now - sched.last_run > delta + GRACE_PERIOD:
            overdue.append(sched)
    return overdue


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------


def execute_schedule(schedule: Schedule, timeout: int = 1800, _skip_persist: bool = False) -> RunLog:
    """Run a scheduled command via subprocess. Updates last_run unless _skip_persist is True."""
    cmd_parts = [sys.executable, "-m", "dobbe"]
    try:
        cmd_parts.extend(shlex.split(schedule.command))
    except ValueError:
        cmd_parts.extend(schedule.command.split())
    if schedule.args:
        try:
            cmd_parts.extend(shlex.split(schedule.args))
        except ValueError:
            cmd_parts.extend(schedule.args.split())

    started_at = datetime.now()
    status = RunStatus.SUCCESS
    exit_code = 0
    error = ""
    summary = ""

    try:
        result = subprocess.run(
            cmd_parts,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        exit_code = result.returncode
        if exit_code != 0:
            status = RunStatus.FAILED
            error = result.stderr[:500] if result.stderr else ""
            summary = f"Exit code {exit_code}"
        else:
            # Grab last non-empty line of stdout as summary
            lines = [line for line in result.stdout.strip().splitlines() if line.strip()]
            summary = lines[-1][:200] if lines else "Completed"
    except subprocess.TimeoutExpired:
        status = RunStatus.TIMEOUT
        exit_code = -1
        error = f"Timed out after {timeout}s"
        summary = "Timeout"
    except (OSError, FileNotFoundError) as e:
        status = RunStatus.FAILED
        exit_code = -1
        error = f"Failed to execute: {e}"
        summary = "Execution error"

    finished_at = datetime.now()
    duration = (finished_at - started_at).total_seconds()

    # Update last_run to prevent infinite retry loops (unless caller batches)
    if not _skip_persist:
        _update_last_run(schedule.name, started_at)

    log = RunLog(
        schedule_name=schedule.name,
        started_at=started_at,
        finished_at=finished_at,
        status=status,
        duration_seconds=duration,
        exit_code=exit_code,
        summary=summary,
        error=error,
        command=schedule.command,
        args=schedule.args,
    )
    save_run_log(log)
    return log


def _update_last_run(name: str, timestamp: datetime) -> None:
    """Update last_run for a schedule in the TOML file."""
    schedules = load_schedules()
    if name in schedules:
        schedules[name].last_run = timestamp
        save_schedules(schedules)


# ---------------------------------------------------------------------------
# Locking - directory-based, cross-platform
# ---------------------------------------------------------------------------


def acquire_lock(name: str) -> Path | None:
    """Acquire a lock by creating a directory. Returns lock path on success, None if held."""
    lock_dir = LOCKS_DIR / f"{name}.lock"
    try:
        lock_dir.mkdir(parents=True, exist_ok=False)
    except FileExistsError:
        # Check for stale lock
        if _is_stale_lock(lock_dir):
            release_lock(name)
            try:
                lock_dir.mkdir(parents=True, exist_ok=False)
            except FileExistsError:
                return None
        else:
            return None
    # Write PID for stale detection
    pid_file = lock_dir / "pid"
    pid_file.write_text(str(os.getpid()))
    return lock_dir


def release_lock(name: str) -> None:
    """Release a lock by removing the directory."""
    lock_dir = LOCKS_DIR / f"{name}.lock"
    if lock_dir.exists():
        pid_file = lock_dir / "pid"
        if pid_file.exists():
            pid_file.unlink()
        try:
            lock_dir.rmdir()
        except OSError:
            pass


def _is_stale_lock(lock_dir: Path) -> bool:
    """Check if a lock is stale (dead process or too old)."""
    pid_file = lock_dir / "pid"
    if not pid_file.exists():
        return True

    # Check age - locks older than STALE_LOCK_HOURS are unconditionally stale
    try:
        lock_age = datetime.now() - datetime.fromtimestamp(pid_file.stat().st_mtime)
        if lock_age > timedelta(hours=STALE_LOCK_HOURS):
            return True
    except OSError:
        return True

    # Check if PID is alive
    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, 0)  # Signal 0 = check existence
        return False  # Process is alive
    except (ValueError, OSError, ProcessLookupError):
        return True


# ---------------------------------------------------------------------------
# Execution logging
# ---------------------------------------------------------------------------


def save_run_log(log: RunLog) -> Path:
    """Write a run log to JSON and prune old entries."""
    _sanitize_schedule_name(log.schedule_name)
    log_dir = LOGS_DIR / log.schedule_name
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp_str = log.started_at.strftime("%Y%m%dT%H%M%S_%f")
    log_file = log_dir / f"{timestamp_str}.json"
    log_file.write_text(log.model_dump_json(indent=2))
    _prune_logs(log_dir)
    return log_file


def load_run_logs(name: str, limit: int = 20) -> list[RunLog]:
    """Load recent run logs for a schedule, newest first."""
    log_dir = LOGS_DIR / name
    if not log_dir.exists():
        return []
    files = sorted(log_dir.glob("*.json"), reverse=True)[:limit]
    logs: list[RunLog] = []
    for f in files:
        try:
            data = json.loads(f.read_text())
            logs.append(RunLog(**data))
        except (json.JSONDecodeError, ValueError):
            continue
    return logs


def _prune_logs(log_dir: Path) -> None:
    """Keep only the most recent MAX_LOGS_PER_SCHEDULE log files."""
    files = list(log_dir.glob("*.json"))
    if len(files) <= MAX_LOGS_PER_SCHEDULE:
        return
    files.sort(reverse=True)
    for f in files[MAX_LOGS_PER_SCHEDULE:]:
        f.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# Check orchestration
# ---------------------------------------------------------------------------


def run_check(dry_run: bool = False) -> CheckResult:
    """Main check entrypoint: find overdue schedules and execute them."""
    lock = acquire_lock("_schedule_check")
    if lock is None:
        return CheckResult(schedules_checked=0, schedules_run=0)

    try:
        schedules = load_schedules()
        overdue = find_overdue(schedules)
        result = CheckResult(
            schedules_checked=len(schedules),
            schedules_run=0,
        )

        if dry_run:
            result.schedules_run = len(overdue)
            return result

        for sched in overdue:
            per_lock = acquire_lock(sched.name)
            if per_lock is None:
                continue
            try:
                log = execute_schedule(sched, _skip_persist=True)
                schedules[sched.name].last_run = log.started_at
                result.results.append(log)
                result.schedules_run += 1
            except Exception as e:
                error_log = RunLog(
                    schedule_name=sched.name,
                    started_at=datetime.now(),
                    finished_at=datetime.now(),
                    status=RunStatus.FAILED,
                    duration_seconds=0,
                    exit_code=-1,
                    summary="Internal error",
                    error=str(e),
                    command=sched.command,
                    args=sched.args,
                )
                result.results.append(error_log)
                continue
            finally:
                release_lock(sched.name)

        # Batch save all last_run updates
        if result.schedules_run > 0:
            save_schedules(schedules)

        return result
    finally:
        release_lock("_schedule_check")


# ---------------------------------------------------------------------------
# Shell / login hook installation
# ---------------------------------------------------------------------------

DOBBE_HOOK_START = "# dobbe scheduler hook start"
DOBBE_HOOK_END = "# dobbe scheduler hook end"

SHELL_HOOKS = {
    "zsh": (
        f"{DOBBE_HOOK_START}\ncommand -v dobbe >/dev/null 2>&1 && dobbe schedule check --quiet &\n{DOBBE_HOOK_END}\n",
        ".zshrc",
    ),
    "bash": (
        f"{DOBBE_HOOK_START}\ncommand -v dobbe >/dev/null 2>&1 && dobbe schedule check --quiet &\n{DOBBE_HOOK_END}\n",
        ".bashrc",
    ),
    "fish": (
        f"{DOBBE_HOOK_START}\ncommand -q dobbe; and dobbe schedule check --quiet &\n{DOBBE_HOOK_END}\n",
        "config.fish",
    ),
}


def detect_shell() -> str:
    """Detect current shell from $SHELL."""
    shell_path = os.environ.get("SHELL", "")
    if shell_path:
        shell_name = Path(shell_path).name
        for name in ("zsh", "bash", "fish"):
            if shell_name == name:
                return name
    return "zsh"  # Default fallback


def get_shell_hook_info(shell: str | None = None) -> tuple[str, Path]:
    """Return (hook_text, profile_path) for the given shell."""
    if shell is None:
        shell = detect_shell()
    hook_text, profile_name = SHELL_HOOKS.get(shell, SHELL_HOOKS["zsh"])
    if shell == "fish":
        profile_path = Path.home() / ".config" / "fish" / profile_name
    else:
        profile_path = Path.home() / profile_name
    return hook_text, profile_path


def install_shell_hook(shell: str | None = None) -> tuple[bool, str]:
    """Install the shell hook. Returns (success, message)."""
    hook_text, profile_path = get_shell_hook_info(shell)

    if profile_path.exists():
        content = profile_path.read_text()
        # Detect both old ("# dobbe scheduler hook") and new start/end markers
        if "# dobbe scheduler hook" in content:
            return False, f"Hook already installed in {profile_path}"
    else:
        content = ""

    profile_path.parent.mkdir(parents=True, exist_ok=True)
    with profile_path.open("a") as f:
        f.write(f"\n{hook_text}")

    return True, f"Hook installed in {profile_path}"


def uninstall_shell_hook(shell: str | None = None) -> tuple[bool, str]:
    """Remove the shell hook. Returns (success, message)."""
    _hook_text, profile_path = get_shell_hook_info(shell)

    if not profile_path.exists():
        return False, f"Profile not found: {profile_path}"

    content = profile_path.read_text()
    if "# dobbe scheduler hook" not in content:
        return False, f"No dobbe hook found in {profile_path}"

    # Remove hook lines (supports both start/end markers and legacy single-marker format)
    lines = content.splitlines(keepends=True)
    new_lines: list[str] = []
    inside_block = False
    skip_next = False
    for line in lines:
        if DOBBE_HOOK_START in line:
            inside_block = True
            continue
        if inside_block and DOBBE_HOOK_END in line:
            inside_block = False
            continue
        if inside_block:
            continue
        # Legacy format: single marker line followed by one command line
        if "# dobbe scheduler hook" in line and DOBBE_HOOK_START not in line:
            skip_next = True
            continue
        if skip_next:
            skip_next = False
            continue
        new_lines.append(line)

    profile_path.write_text("".join(new_lines))
    return True, f"Hook removed from {profile_path}"


def install_login_hook() -> tuple[bool, str]:
    """Install an OS-native login hook (launchd/systemd/schtasks)."""
    if sys.platform == "darwin":
        return _install_launchd()
    elif sys.platform == "linux":
        return _install_systemd()
    elif sys.platform == "win32":
        return _install_schtasks()
    return False, f"Unsupported platform: {sys.platform}"


def uninstall_login_hook() -> tuple[bool, str]:
    """Remove the OS-native login hook."""
    if sys.platform == "darwin":
        return _uninstall_launchd()
    elif sys.platform == "linux":
        return _uninstall_systemd()
    elif sys.platform == "win32":
        return _uninstall_schtasks()
    return False, f"Unsupported platform: {sys.platform}"


# --- macOS launchd ---

_PLIST_LABEL = "com.dobbe.schedule"


def _launchd_plist_path() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"{_PLIST_LABEL}.plist"


def _install_launchd() -> tuple[bool, str]:
    plist_path = _launchd_plist_path()
    if plist_path.exists():
        return False, f"LaunchAgent already exists: {plist_path}"

    dobbe_cmd = _find_dobbe_executable()
    program_args = dobbe_cmd + ["schedule", "check", "--quiet"]
    from xml.sax.saxutils import escape as xml_escape
    args_xml = "\n".join(f"        <string>{xml_escape(part)}</string>" for part in program_args)
    plist_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>{_PLIST_LABEL}</string>
    <key>ProgramArguments</key>
    <array>
{args_xml}
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>StartInterval</key>
    <integer>3600</integer>
    <key>StandardOutPath</key>
    <string>{CONFIG_DIR / "logs" / "schedule.log"}</string>
    <key>StandardErrorPath</key>
    <string>{CONFIG_DIR / "logs" / "schedule.err"}</string>
</dict>
</plist>"""

    plist_path.parent.mkdir(parents=True, exist_ok=True)
    plist_path.write_text(plist_content)
    try:
        subprocess.run(["launchctl", "load", str(plist_path)], check=True)
    except (subprocess.CalledProcessError, OSError, FileNotFoundError) as e:
        return False, f"Failed to load LaunchAgent: {e}"
    return True, f"LaunchAgent installed: {plist_path}"


def _uninstall_launchd() -> tuple[bool, str]:
    plist_path = _launchd_plist_path()
    if not plist_path.exists():
        return False, "LaunchAgent not found"
    subprocess.run(["launchctl", "unload", str(plist_path)], check=False)
    plist_path.unlink()
    return True, "LaunchAgent removed"


# --- Linux systemd ---

_SYSTEMD_SERVICE = "dobbe-schedule"


def _systemd_dir() -> Path:
    return Path.home() / ".config" / "systemd" / "user"


def _install_systemd() -> tuple[bool, str]:
    sd_dir = _systemd_dir()
    service_path = sd_dir / f"{_SYSTEMD_SERVICE}.service"
    timer_path = sd_dir / f"{_SYSTEMD_SERVICE}.timer"

    if service_path.exists():
        return False, f"Systemd service already exists: {service_path}"

    dobbe_cmd = _find_dobbe_executable()
    exec_start = " ".join(dobbe_cmd + ["schedule", "check", "--quiet"])
    service_content = f"""[Unit]
Description=dobbe schedule check

[Service]
Type=oneshot
ExecStart={exec_start}
"""
    timer_content = f"""[Unit]
Description=dobbe schedule check timer

[Timer]
OnBootSec=5min
OnUnitActiveSec=1h
Persistent=true

[Install]
WantedBy=timers.target
"""

    sd_dir.mkdir(parents=True, exist_ok=True)
    service_path.write_text(service_content)
    timer_path.write_text(timer_content)
    try:
        subprocess.run(
            ["systemctl", "--user", "enable", "--now", f"{_SYSTEMD_SERVICE}.timer"],
            check=True,
        )
    except subprocess.CalledProcessError as e:
        return False, f"Failed to enable systemd timer: {e}"
    return True, f"Systemd timer installed: {timer_path}"


def _uninstall_systemd() -> tuple[bool, str]:
    sd_dir = _systemd_dir()
    service_path = sd_dir / f"{_SYSTEMD_SERVICE}.service"
    timer_path = sd_dir / f"{_SYSTEMD_SERVICE}.timer"

    if not service_path.exists() and not timer_path.exists():
        return False, "Systemd service not found"

    subprocess.run(
        ["systemctl", "--user", "disable", "--now", f"{_SYSTEMD_SERVICE}.timer"],
        check=False,
    )
    if service_path.exists():
        service_path.unlink()
    if timer_path.exists():
        timer_path.unlink()
    return True, "Systemd timer removed"


# --- Windows schtasks ---

_TASK_NAME = "dobbe-schedule"


def _install_schtasks() -> tuple[bool, str]:
    dobbe_cmd = _find_dobbe_executable()
    cmd_str = " ".join(dobbe_cmd + ["schedule", "check", "--quiet"])
    try:
        subprocess.run(
            [
                "schtasks", "/create",
                "/sc", "ONLOGON",
                "/tn", _TASK_NAME,
                "/tr", cmd_str,
                "/f",
            ],
            check=True,
        )
    except subprocess.CalledProcessError as e:
        return False, f"Failed to create Windows task: {e}"
    return True, f"Windows task '{_TASK_NAME}' created"


def _uninstall_schtasks() -> tuple[bool, str]:
    try:
        subprocess.run(
            ["schtasks", "/delete", "/tn", _TASK_NAME, "/f"],
            check=True,
        )
    except subprocess.CalledProcessError as e:
        return False, f"Failed to delete Windows task: {e}"
    return True, f"Windows task '{_TASK_NAME}' removed"


# --- Helpers ---


def _find_dobbe_executable() -> list[str]:
    """Find the dobbe executable, returning command parts as a list."""
    path = shutil.which("dobbe")
    if path:
        return [path]
    # Fallback to python -m dobbe style
    return [sys.executable, "-m", "dobbe"]
