"""PR review digest pipeline - fetch → analyze → prioritize."""

from __future__ import annotations

import asyncio

from rich.console import Console

from dobbe.core.claude import ask_claude_async, build_allowed_tools
from dobbe.core.github_review import (
    build_review_payload,
    check_existing_review,
    fetch_pr_diff,
    fetch_pr_metadata,
    get_pr_head_sha,
    post_review,
)
from dobbe.core.prompts import build_pr_discovery_prompt, build_pr_review_prompt
from dobbe.core.response_parser import parse_pr_list_response, parse_review_response
from dobbe.models.review import (
    PRInfo,
    PRReviewResult,
    PostResult,
    ReviewDigest,
    ReviewPostReport,
)
from dobbe.models.shared import Severity

_console = Console(stderr=True)

# Callback type for progress reporting - matches LiveProgress.callback signature.
from dobbe.output.progress import ProgressCallback as _ProgressCallback

SEVERITY_ORDER = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]


async def _fetch_prs_for_repo(
    repo: str,
    reviewers: list[str],
    available_mcps: dict[str, bool],
    semaphore: asyncio.Semaphore,
) -> tuple[list[PRInfo], str | None]:
    """Fetch open PRs for a single repo. Returns (prs, error)."""
    async with semaphore:
        prompt = build_pr_discovery_prompt(repo, reviewers, available_mcps)
        tools = build_allowed_tools(available_mcps=available_mcps)
        result = await ask_claude_async(prompt=prompt, tools=tools, timeout=120)

        if not result.success:
            return [], f"Failed to fetch PRs for {repo}: {result.error}"

        prs = parse_pr_list_response(result.text, repo)
        return prs, None


async def _analyze_pr(
    pr: PRInfo,
    available_mcps: dict[str, bool],
    semaphore: asyncio.Semaphore,
    diff_content: str | None = None,
) -> PRReviewResult:
    """Analyze a single PR with Claude. Returns PRReviewResult."""
    async with semaphore:
        prompt = build_pr_review_prompt(
            repo=pr.repo,
            pr_number=pr.pr_number,
            title=pr.title,
            author=pr.author,
            description=pr.description,
            available_mcps=available_mcps,
            diff_content=diff_content,
        )
        tools = build_allowed_tools(available_mcps=available_mcps)
        result = await ask_claude_async(prompt=prompt, tools=tools, timeout=300)

        if not result.success:
            return PRReviewResult(
                pr=pr,
                risk_level=Severity.MEDIUM,
                summary="",
                analysis_error=f"Claude analysis failed: {result.error}",
            )

        return parse_review_response(result.text, pr)


def _prioritize_results(results: list[PRReviewResult]) -> list[PRReviewResult]:
    """Sort results by risk level (critical first), then by age (oldest first)."""
    def sort_key(r: PRReviewResult) -> tuple[int, int]:
        risk_order = SEVERITY_ORDER.index(r.risk_level) if r.risk_level in SEVERITY_ORDER else 3
        return (risk_order, -r.pr.age_days)

    return sorted(results, key=sort_key)


def _filter_prs(
    prs: list[PRInfo],
    skip_labels: list[str] | None = None,
    skip_authors: list[str] | None = None,
    skip_drafts: bool = True,
) -> list[PRInfo]:
    """Filter PRs by labels, authors, and draft status."""
    lower_skip_labels = {sl.lower() for sl in skip_labels} if skip_labels else set()
    lower_skip_authors = {a.lower() for a in skip_authors} if skip_authors else set()

    result: list[PRInfo] = []
    for pr in prs:
        if skip_drafts and pr.draft:
            continue
        if lower_skip_labels:
            if any(lbl.lower() in lower_skip_labels for lbl in pr.labels):
                continue
        if lower_skip_authors:
            if pr.author.lower() in lower_skip_authors:
                continue
        result.append(pr)
    return result


async def _fetch_diff_for_pr(
    pr: PRInfo,
    max_diff_lines: int,
    semaphore: asyncio.Semaphore,
) -> str | None:
    """Pre-fetch diff. Returns diff text or None on failure (fallback: Claude fetches it)."""
    async with semaphore:
        diff, error = await asyncio.to_thread(
            fetch_pr_diff, pr.repo, pr.pr_number, max_diff_lines
        )
        if error:
            _console.print(f"[dim]Warning: {error}[/dim]")
            return None
        return diff if diff else None


async def run_review_digest(
    repos: list[str],
    reviewers: list[str],
    available_mcps: dict[str, bool],
    stale_days: int = 7,
    max_concurrent: int = 5,
    skip_labels: list[str] | None = None,
    skip_authors: list[str] | None = None,
    max_diff_lines: int = 2000,
    on_progress: _ProgressCallback | None = None,
) -> ReviewDigest:
    """Run the full PR review digest pipeline.

    Phases:
      1. Fetch - discover open PRs across repos (parallel)
      2. Filter - remove PRs matching skip criteria
      3. Pre-fetch diffs - get diffs for each PR (parallel)
      4. Analyze - deep review each PR with Claude (parallel)
      5. Prioritize - sort by risk and age
    """
    semaphore = asyncio.Semaphore(max_concurrent)
    errors: list[str] = []

    def _emit(phase: str, detail: str = "", completed: int | None = None, total: int | None = None,
              phase_number: int | None = None, repo: str = "", repo_status: str = "") -> None:
        if on_progress:
            try:
                on_progress(
                    phase=phase, detail=detail, completed=completed, total=total,
                    phase_number=phase_number, total_phases=5,
                    repo=repo, repo_status=repo_status,
                )
            except Exception:
                pass

    # --- Phase 1: Fetch PRs ---
    _emit(phase="Fetching PRs", phase_number=1, total=len(repos))
    for r in repos:
        _emit(phase="Fetching PRs", repo=r, repo_status="waiting")

    fetch_tasks = [
        _fetch_prs_for_repo(repo, reviewers, available_mcps, semaphore)
        for repo in repos
    ]
    fetch_results = await asyncio.gather(*fetch_tasks, return_exceptions=True)

    all_prs: list[PRInfo] = []
    for i, result in enumerate(fetch_results):
        if isinstance(result, BaseException):
            errors.append(f"Fetch failed: {result}")
            _emit(phase="Fetching PRs", repo=repos[i], repo_status="done (error)", completed=i + 1)
            continue
        prs, error = result
        if error:
            errors.append(error)
        all_prs.extend(prs)
        _emit(phase="Fetching PRs", repo=repos[i], repo_status=f"done ({len(prs)} PRs)", completed=i + 1)

    # --- Phase 2: Filter ---
    _emit(phase="Filtering PRs", phase_number=2, detail=f"{len(all_prs)} PRs")
    if skip_labels or skip_authors:
        all_prs = _filter_prs(all_prs, skip_labels, skip_authors, skip_drafts=False)
    _emit(phase="Filtering PRs", detail=f"{len(all_prs)} PRs after filter")

    # --- Phase 3: Pre-fetch diffs ---
    _emit(phase="Pre-fetching diffs", phase_number=3, total=len(all_prs))
    diff_tasks = [
        _fetch_diff_for_pr(pr, max_diff_lines, semaphore)
        for pr in all_prs
    ]
    diffs: list[str | None] = []
    if diff_tasks:
        raw_diffs = await asyncio.gather(*diff_tasks, return_exceptions=True)
        diffs = [None if isinstance(d, BaseException) else d for d in raw_diffs]
    _emit(phase="Pre-fetching diffs", completed=len(all_prs))

    # --- Phase 4: Analyze PRs ---
    _emit(phase="Analyzing PRs", phase_number=4, total=len(all_prs))
    analyze_tasks = [
        _analyze_pr(pr, available_mcps, semaphore, diff_content=diff)
        for pr, diff in zip(all_prs, diffs)
    ]
    results: list[PRReviewResult] = []
    if analyze_tasks:
        raw_results = await asyncio.gather(*analyze_tasks, return_exceptions=True)
        for idx, (pr, r) in enumerate(zip(all_prs, raw_results)):
            if isinstance(r, BaseException):
                results.append(PRReviewResult(
                    pr=pr,
                    risk_level=Severity.MEDIUM,
                    summary="",
                    analysis_error=f"Analysis failed: {r}",
                ))
            else:
                results.append(r)
            _emit(
                phase="Analyzing PRs", completed=idx + 1,
                repo=pr.repo, repo_status=f"analyzed PR #{pr.pr_number}",
            )

    # --- Phase 5: Prioritize ---
    _emit(phase="Prioritizing results", phase_number=5)
    results = _prioritize_results(results)

    return ReviewDigest(
        reviewers=reviewers,
        repos_scanned=repos,
        results=results,
        stale_days=stale_days,
        errors=errors,
    )


async def _fetch_single_pr(
    repo: str,
    pr_number: int,
    semaphore: asyncio.Semaphore,
) -> tuple[PRInfo | None, str | None]:
    """Fetch metadata for a specific PR via direct gh api call."""
    async with semaphore:
        return await asyncio.to_thread(fetch_pr_metadata, repo, pr_number)


async def run_review_post(
    repos: list[str],
    pr_number: int | None,
    reviewers: list[str],
    available_mcps: dict[str, bool],
    dry_run: bool = False,
    max_concurrent: int = 5,
    skip_labels: list[str] | None = None,
    skip_authors: list[str] | None = None,
    max_diff_lines: int = 2000,
    on_progress: _ProgressCallback | None = None,
) -> ReviewPostReport:
    """Run the review post pipeline - analyze PRs and post reviews to GitHub.

    If pr_number is set, review a single PR. If None, review all open PRs.
    """
    semaphore = asyncio.Semaphore(max_concurrent)
    errors: list[str] = []
    post_results: list[PostResult] = []

    def _emit(phase: str, detail: str = "", completed: int | None = None, total: int | None = None,
              phase_number: int | None = None, repo: str = "", repo_status: str = "") -> None:
        if on_progress:
            try:
                on_progress(
                    phase=phase, detail=detail, completed=completed, total=total,
                    phase_number=phase_number, total_phases=5,
                    repo=repo, repo_status=repo_status,
                )
            except Exception:
                pass

    # --- Phase 1: Discover PRs ---
    _emit(phase="Discovering PRs", phase_number=1)
    all_prs: list[PRInfo] = []
    if pr_number is not None:
        # Single PR mode - direct API, no Claude needed
        pr_info, error = await _fetch_single_pr(repos[0], pr_number, semaphore)
        if error:
            errors.append(error)
        if pr_info:
            all_prs.append(pr_info)
    else:
        # All PRs mode
        fetch_tasks = [
            _fetch_prs_for_repo(repo, reviewers, available_mcps, semaphore)
            for repo in repos
        ]
        fetch_results = await asyncio.gather(*fetch_tasks, return_exceptions=True)
        for result in fetch_results:
            if isinstance(result, BaseException):
                errors.append(f"Fetch failed: {result}")
                continue
            prs, error = result
            if error:
                errors.append(error)
            all_prs.extend(prs)

    # --- Phase 2: Filter ---
    _emit(phase="Filtering PRs", phase_number=2, detail=f"{len(all_prs)} PRs")
    all_prs = _filter_prs(all_prs, skip_labels, skip_authors, skip_drafts=(pr_number is None))
    _emit(phase="Filtering PRs", detail=f"{len(all_prs)} PRs after filter")

    # --- Phase 3: Pre-fetch diffs ---
    _emit(phase="Pre-fetching diffs", phase_number=3, total=len(all_prs))
    diff_tasks = [
        _fetch_diff_for_pr(pr, max_diff_lines, semaphore)
        for pr in all_prs
    ]
    diffs: list[str | None] = []
    if diff_tasks:
        raw_diffs = await asyncio.gather(*diff_tasks, return_exceptions=True)
        diffs = [None if isinstance(d, BaseException) else d for d in raw_diffs]
    _emit(phase="Pre-fetching diffs", completed=len(all_prs))

    # --- Phase 4: Analyze PRs ---
    _emit(phase="Analyzing PRs", phase_number=4, total=len(all_prs))
    analyze_tasks = [
        _analyze_pr(pr, available_mcps, semaphore, diff_content=diff)
        for pr, diff in zip(all_prs, diffs)
    ]
    reviews: list[PRReviewResult] = []
    if analyze_tasks:
        raw_results = await asyncio.gather(*analyze_tasks, return_exceptions=True)
        for idx, (pr, r) in enumerate(zip(all_prs, raw_results)):
            if isinstance(r, BaseException):
                reviews.append(PRReviewResult(
                    pr=pr,
                    risk_level=Severity.MEDIUM,
                    summary="",
                    analysis_error=f"Analysis failed: {r}",
                ))
            else:
                reviews.append(r)
            _emit(phase="Analyzing PRs", completed=idx + 1,
                  repo=pr.repo, repo_status=f"analyzed PR #{pr.pr_number}")

    # --- Phase 5: Dedup + Post ---
    _emit(phase="Posting reviews", phase_number=5, total=len(reviews))
    # Phase 5a: Parallel dedup checks (non-blocking via asyncio.to_thread)
    async def _check_dedup(
        review: PRReviewResult,
    ) -> tuple[str | None, str | None]:
        """Returns (head_sha, skip_reason)."""
        pr = review.pr
        head_sha = await asyncio.to_thread(get_pr_head_sha, pr.repo, pr.pr_number)
        if head_sha and await asyncio.to_thread(
            check_existing_review, pr.repo, pr.pr_number, head_sha
        ):
            return head_sha, f"already reviewed at commit {head_sha[:7]}"
        return head_sha, None

    dedup_map: dict[int, tuple[str | None, str | None]] = {}
    dedup_indices = [i for i, r in enumerate(reviews) if not r.analysis_error]
    if dedup_indices:
        dedup_results = await asyncio.gather(
            *[_check_dedup(reviews[i]) for i in dedup_indices],
            return_exceptions=True,
        )
        for idx, result in zip(dedup_indices, dedup_results):
            if isinstance(result, BaseException):
                dedup_map[idx] = (None, None)
            else:
                dedup_map[idx] = result

    # Phase 5b: Sequential post
    for i, review in enumerate(reviews):
        pr = review.pr

        if review.analysis_error:
            post_results.append(PostResult(
                pr=pr,
                review=review,
                error=f"Analysis failed: {review.analysis_error}",
            ))
            continue

        head_sha, skip_reason = dedup_map.get(i, (None, None))
        if skip_reason:
            post_results.append(PostResult(
                pr=pr,
                review=review,
                skipped_reason=skip_reason,
            ))
            continue

        payload = build_review_payload(review)

        if dry_run:
            post_results.append(PostResult(
                pr=pr,
                review=review,
                posted=False,
                skipped_reason="dry run",
            ))
            continue

        success, url_or_error = await asyncio.to_thread(
            post_review, pr.repo, pr.pr_number, payload
        )
        if success:
            post_results.append(PostResult(
                pr=pr,
                review=review,
                posted=True,
                review_url=url_or_error,
            ))
        else:
            post_results.append(PostResult(
                pr=pr,
                review=review,
                error=url_or_error,
            ))

    return ReviewPostReport(
        repos_scanned=repos,
        results=post_results,
        errors=errors,
        dry_run=dry_run,
    )
