"""Pipeline orchestrator - scan → fix → verify → report."""

from __future__ import annotations

import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


class GitError(RuntimeError):
    """Raised when a git operation fails unexpectedly."""

from dobbe.core.claude import ask_claude, build_agent_tools
from dobbe.core.prompts import (
    build_fix_prompt,
    build_report_prompt,
    build_scan_prompt,
    build_verify_prompt,
)
from dobbe.core.response_parser import (
    parse_fix_response,
    parse_triage_response,
    parse_verify_response,
)
from dobbe.models.alert import RepoResult
from dobbe.models.resolve import (
    AgentMessage,
    ConversationLog,
    FixResult,
    PipelineIteration,
    ResolveReport,
    VerifyResult,
)


@dataclass
class PipelineConfig:
    """Configuration for the resolve pipeline."""

    repo: str
    local_path: str | None = None
    severity_filter: list[str] = field(default_factory=lambda: ["critical", "high"])
    available_mcps: dict[str, bool] = field(default_factory=dict)
    max_iterations: int = 3
    branch_name: str | None = None
    base_branch: str = "main"
    dry_run: bool = False
    skip_verify: bool = False
    no_pr: bool = False
    timeout_per_step: int = 600
    scan_summary_override: str | None = None


def _run_git(args: list[str], cwd: str) -> subprocess.CompletedProcess[str]:
    """Run a git command and return the result."""
    try:
        return subprocess.run(
            ["git"] + args,
            capture_output=True,
            text=True,
            cwd=cwd,
            timeout=60,
        )
    except subprocess.TimeoutExpired:
        return subprocess.CompletedProcess(
            args=["git"] + args,
            returncode=-1,
            stdout="",
            stderr="git command timed out after 60s",
        )


def _run_git_checked(args: list[str], cwd: str) -> subprocess.CompletedProcess[str]:
    """Run a git command; raise GitError on non-zero exit."""
    result = _run_git(args, cwd)
    if result.returncode != 0:
        cmd_str = " ".join(["git"] + args)
        raise GitError(f"`{cmd_str}` failed (rc={result.returncode}): {result.stderr.strip()}")
    return result


def _ensure_local_clone(cfg: PipelineConfig) -> tuple[str, bool]:
    """Ensure the repo is available locally; clone to tempdir if needed.

    Returns (local_path, is_tempdir).
    """
    if cfg.local_path:
        path = Path(cfg.local_path)
        if path.exists() and (path / ".git").exists():
            return str(path), False

    tmpdir = tempfile.mkdtemp(prefix="dobbe-")
    url = f"https://github.com/{cfg.repo}.git"
    try:
        result = subprocess.run(
            ["git", "clone", "--depth", "1", url, tmpdir],
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.TimeoutExpired:
        shutil.rmtree(tmpdir, ignore_errors=True)
        raise RuntimeError(f"Clone of {cfg.repo} timed out after 120s")
    if result.returncode != 0:
        shutil.rmtree(tmpdir, ignore_errors=True)
        raise RuntimeError(f"Failed to clone {cfg.repo}: {result.stderr.strip()}")
    return tmpdir, True


def _setup_branch(local_path: str, branch_name: str, base_branch: str) -> None:
    """Create and checkout a new branch from base."""
    _run_git_checked(["checkout", base_branch], cwd=local_path)
    _run_git_checked(["checkout", "-b", branch_name], cwd=local_path)


def _commit_fixes(local_path: str, message: str) -> bool:
    """Stage all changes and commit. Returns True if commit was created."""
    _run_git(["add", "-A"], cwd=local_path)
    result = _run_git(["diff", "--cached", "--quiet"], cwd=local_path)
    if result.returncode == 0:
        return False  # nothing staged
    _run_git_checked(["commit", "-m", message], cwd=local_path)
    return True


def _revert_to_base(local_path: str, base_branch: str, branch_name: str) -> None:
    """Reset branch to base (clean slate between retries)."""
    _run_git_checked(["reset", "--hard", base_branch], cwd=local_path)


def _create_pr(local_path: str, branch_name: str, title: str, body: str) -> str:
    """Create a PR via gh CLI. Returns PR URL or empty string on failure."""
    if not shutil.which("gh"):
        return ""
    _run_git(["push", "-u", "origin", branch_name], cwd=local_path)
    try:
        result = subprocess.run(
            [
                "gh", "pr", "create",
                "--title", title,
                "--body", body,
                "--head", branch_name,
            ],
            capture_output=True,
            text=True,
            cwd=local_path,
            timeout=60,
        )
    except OSError:
        return ""
    if result.returncode == 0:
        return result.stdout.strip()
    return ""


def _build_scan_summary(scan_text: str, repo: str) -> str:
    """Extract a human-readable scan summary from the triage result."""
    repo_result = parse_triage_response(scan_text, repo)
    if repo_result.error:
        return f"Scan error: {repo_result.error}"

    parts: list[str] = []
    parts.append(f"Found {repo_result.total_alerts} alerts across {len(repo_result.groups)} package groups.")
    for group in repo_result.groups:
        alert_nums = [str(a.alert_number) for a in group.alerts]
        version_info = ""
        if group.target_version:
            version_info = f" (upgrade {group.current_version} → {group.target_version})"
        parts.append(
            f"- {group.package_name}: {len(group.alerts)} alert(s) [#{', #'.join(alert_nums)}]{version_info}"
        )
    return "\n".join(parts)


def scan_summary_from_repo_result(repo_result: RepoResult) -> str:
    """Convert a RepoResult to the same summary string as _build_scan_summary.

    Used by --from-scan to produce a scan_summary without running the scan agent.
    """
    if repo_result.error:
        return f"Scan error: {repo_result.error}"

    parts: list[str] = []
    parts.append(f"Found {repo_result.total_alerts} alerts across {len(repo_result.groups)} package groups.")
    for group in repo_result.groups:
        alert_nums = [str(a.alert_number) for a in group.alerts]
        version_info = ""
        if group.target_version:
            version_info = f" (upgrade {group.current_version} → {group.target_version})"
        parts.append(
            f"- {group.package_name}: {len(group.alerts)} alert(s) [#{', #'.join(alert_nums)}]{version_info}"
        )
    return "\n".join(parts)


def _build_iteration_details(iterations: list[PipelineIteration]) -> str:
    """Build a text summary of all iterations for the report agent."""
    parts: list[str] = []
    for it in iterations:
        parts.append(f"### Iteration {it.iteration}")
        fr = it.fix_result
        parts.append(f"Fixes applied: {len(fr.fixes)}, Skipped: {len(fr.skipped)}")
        if fr.diff_summary:
            parts.append(f"Diff: {fr.diff_summary}")
        if it.verify_result:
            vr = it.verify_result
            status = "PASSED" if vr.passed else "FAILED"
            parts.append(f"Verification: {status}")
            if vr.issues:
                for issue in vr.issues:
                    parts.append(f"  - [{issue.category.value}] {issue.description}")
            if vr.feedback:
                parts.append(f"Feedback: {vr.feedback}")
        parts.append("")
    return "\n".join(parts)


def run_pipeline(
    cfg: PipelineConfig,
    callbacks: Callable[[AgentMessage], None] | None = None,
) -> ResolveReport:
    """Execute the full scan → fix → verify → report pipeline.

    Args:
        cfg: Pipeline configuration.
        callbacks: Optional callback invoked for each agent message.

    Returns:
        ResolveReport with the full results.
    """
    log = ConversationLog()

    def _emit(agent: str, icon: str, summary: str, details: str | None = None, iteration: int | None = None) -> None:
        msg = log.add(agent=agent, icon=icon, summary=summary, details=details, iteration=iteration)
        if callbacks:
            callbacks(msg)

    # 1. Ensure local clone
    local_path, is_tempdir = _ensure_local_clone(cfg)

    try:
        _emit("orchestrator", "\u2699\ufe0f", f"Repository ready at {local_path}")

        # 2. Setup branch
        branch_name = cfg.branch_name or f"dobbe/fix-vulns-{cfg.repo.replace('/', '-')}"
        try:
            _setup_branch(local_path, branch_name, cfg.base_branch)
        except GitError as e:
            _emit("orchestrator", "\u2699\ufe0f", f"Branch setup failed: {e}")
            return ResolveReport(
                repo=cfg.repo,
                scan_summary=f"Branch setup failed: {e}",
                final_branch=branch_name,
                conversation=log,
                max_iterations=cfg.max_iterations,
            )
        _emit("orchestrator", "\u2699\ufe0f", f"Created branch {branch_name} from {cfg.base_branch}")

        # Pre-flight: warn if gh is missing and PR creation is expected
        if not cfg.no_pr and not shutil.which("gh"):
            _emit("orchestrator", "\u2699\ufe0f", "gh CLI not found \u2014 PR creation will be skipped")

        # 3. Scan
        if cfg.scan_summary_override:
            scan_summary = cfg.scan_summary_override
            _emit("scan", "\U0001f50d", f"Using pre-computed scan: {scan_summary[:120]}")
        else:
            scan_prompt = build_scan_prompt(
                repo=cfg.repo,
                severity_filter=cfg.severity_filter if cfg.severity_filter else None,
                available_mcps=cfg.available_mcps,
                access_mode="local",
                local_path=local_path,
            )
            scan_tools = build_agent_tools("scan", cfg.available_mcps)
            scan_result = ask_claude(prompt=scan_prompt, tools=scan_tools, cwd=local_path, timeout=cfg.timeout_per_step)

            if not scan_result.success:
                _emit("scan", "\U0001f50d", f"Scan failed: {scan_result.error}")
                return ResolveReport(
                    repo=cfg.repo,
                    scan_summary=scan_result.error,
                    final_branch=branch_name,
                    conversation=log,
                    max_iterations=cfg.max_iterations,
                )

            scan_summary = _build_scan_summary(scan_result.text, cfg.repo)
            _emit("scan", "\U0001f50d", scan_summary, details=scan_result.text)

        if cfg.dry_run:
            _emit("orchestrator", "\u2699\ufe0f", "Dry run \u2014 stopping after scan.")
            return ResolveReport(
                repo=cfg.repo,
                scan_summary=scan_summary,
                final_branch=branch_name,
                conversation=log,
                max_iterations=cfg.max_iterations,
            )

        # 4. Fix-verify loop
        iterations: list[PipelineIteration] = []
        converged = False
        feedback = ""

        for i in range(1, cfg.max_iterations + 1):
            # Fix agent
            fix_prompt = build_fix_prompt(
                local_path=local_path,
                scan_summary=scan_summary,
                feedback=feedback,
            )
            fix_tools = build_agent_tools("fix", cfg.available_mcps)
            fix_result_raw = ask_claude(prompt=fix_prompt, tools=fix_tools, cwd=local_path, timeout=cfg.timeout_per_step)

            if not fix_result_raw.success:
                fix_result = FixResult(repo=cfg.repo, branch=branch_name, base_branch=cfg.base_branch)
                _emit("fix", "\U0001f527", f"Fix failed: {fix_result_raw.error}", iteration=i)
            else:
                fix_result = parse_fix_response(fix_result_raw.text, cfg.repo, branch_name, cfg.base_branch)
                fix_summary_parts = []
                for f in fix_result.fixes:
                    fix_summary_parts.append(f"\u2713 {f.package_name} {f.old_version} \u2192 {f.new_version} in {f.file_modified}")
                for s in fix_result.skipped:
                    fix_summary_parts.append(f"\u2717 {s.package_name}: {s.reason}")
                fix_summary = "\n".join(fix_summary_parts) or "No changes made"
                _emit("fix", "\U0001f527", fix_summary, details=fix_result_raw.text, iteration=i)

            # Commit
            committed = _commit_fixes(local_path, f"dobbe: fix vulnerabilities (iteration {i})")

            # Verify agent
            verify_result: VerifyResult | None = None
            if cfg.skip_verify:
                converged = True
                _emit("verify", "\u2705", "Verification skipped (--skip-verify)", iteration=i)
            elif committed:
                verify_prompt = build_verify_prompt(
                    local_path=local_path,
                    branch=branch_name,
                    base_branch=cfg.base_branch,
                )
                verify_tools = build_agent_tools("verify", cfg.available_mcps)
                verify_result_raw = ask_claude(
                    prompt=verify_prompt, tools=verify_tools, cwd=local_path, timeout=cfg.timeout_per_step,
                )

                if not verify_result_raw.success:
                    verify_result = VerifyResult(passed=False, feedback=f"Verify agent error: {verify_result_raw.error}")
                    _emit("verify", "\u2705", f"Verify failed: {verify_result_raw.error}", iteration=i)
                else:
                    verify_result = parse_verify_response(verify_result_raw.text, cfg.repo)
                    if verify_result.passed:
                        _emit("verify", "\u2705", "ALL CLEAR \u2014 tests pass, no breaking changes", iteration=i)
                        converged = True
                    else:
                        issue_lines = [f"  {iss.description}" for iss in verify_result.issues]
                        _emit(
                            "verify", "\u2705",
                            "ISSUES FOUND\n" + "\n".join(issue_lines) + f"\n\u2192 Feedback: {verify_result.feedback}",
                            details=verify_result_raw.text,
                            iteration=i,
                        )
                        feedback = verify_result.feedback
            else:
                _emit("verify", "\u2705", "No changes to verify", iteration=i)
                converged = True

            iterations.append(PipelineIteration(iteration=i, fix_result=fix_result, verify_result=verify_result))

            if converged:
                break

            # Revert for next iteration
            try:
                _revert_to_base(local_path, cfg.base_branch, branch_name)
            except GitError as e:
                _emit("orchestrator", "\u2699\ufe0f", f"Revert failed: {e}")
                break

        # 5. Report agent
        iteration_details = _build_iteration_details(iterations)
        report_prompt = build_report_prompt(
            repo=cfg.repo,
            scan_summary=scan_summary,
            iteration_count=len(iterations),
            converged=converged,
            iteration_details=iteration_details,
        )
        report_tools = build_agent_tools("report", cfg.available_mcps)
        report_result = ask_claude(prompt=report_prompt, tools=report_tools, cwd=local_path, timeout=cfg.timeout_per_step)

        summary = ""
        if report_result.success:
            summary = report_result.text
            _emit("report", "\U0001f4dd", summary[:200])
        else:
            _emit("report", "\U0001f4dd", f"Report generation failed: {report_result.error}")

        # 6. Create PR
        pr_url = ""
        if converged and not cfg.no_pr:
            from dobbe.output.transcript import render_pr_body

            pr_body = render_pr_body(
                ResolveReport(
                    repo=cfg.repo,
                    scan_summary=scan_summary,
                    iterations=iterations,
                    converged=converged,
                    max_iterations=cfg.max_iterations,
                    final_branch=branch_name,
                    summary=summary,
                    conversation=log,
                )
            )
            pr_url = _create_pr(
                local_path,
                branch_name,
                f"fix: resolve {len(iterations[-1].fix_result.fixes)} vulnerable dependencies",
                pr_body,
            )
            if pr_url:
                _emit("orchestrator", "\u2699\ufe0f", f"PR created: {pr_url}")
            else:
                _emit("orchestrator", "\u2699\ufe0f", "PR creation failed or skipped")

        return ResolveReport(
            repo=cfg.repo,
            scan_summary=scan_summary,
            iterations=iterations,
            converged=converged,
            max_iterations=cfg.max_iterations,
            final_branch=branch_name,
            pr_url=pr_url,
            summary=summary,
            conversation=log,
        )
    finally:
        if is_tempdir:
            shutil.rmtree(local_path, ignore_errors=True)
