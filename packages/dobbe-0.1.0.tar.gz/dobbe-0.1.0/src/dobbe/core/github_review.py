"""GitHub review posting - build payloads, dedup, post via gh API."""

from __future__ import annotations

import json
import subprocess

from dobbe.core.response_parser import parse_datetime, parse_labels
from dobbe.models.review import PRInfo, PRReviewResult, ReviewConcern
from dobbe.models.shared import SEVERITY_EMOJI, Severity

DOBBE_REVIEW_MARKER = "## dobbe AI Review"


def build_review_body(review: PRReviewResult) -> str:
    """Build the markdown body for the top-level review comment."""
    lines: list[str] = []

    emoji = SEVERITY_EMOJI.get(review.risk_level, "")
    lines.append(DOBBE_REVIEW_MARKER)
    lines.append("")
    lines.append(
        f"**Risk Level:** {emoji} {review.risk_level.value.upper()} | "
        f"**Recommendation:** {review.approval_recommendation.replace('_', ' ').title()}"
    )
    lines.append("")
    lines.append("### Summary")
    lines.append("")
    lines.append(review.summary)
    lines.append("")

    # Concerns section
    high_concerns = [
        c for c in review.concerns if c.severity in (Severity.CRITICAL, Severity.HIGH)
    ]
    if high_concerns:
        lines.append("### Concerns")
        lines.append("")
        for concern in high_concerns:
            file_ref = f" (`{concern.file_path}`)" if concern.file_path else ""
            lines.append(
                f"- **{concern.category.value}** ({concern.severity.value}): "
                f"{concern.description}{file_ref}"
            )
            if concern.suggestion:
                lines.append(f"  - *Suggestion:* {concern.suggestion}")
        lines.append("")

    # Recommendations
    if review.recommendations:
        lines.append("### Recommendations")
        lines.append("")
        for rec in review.recommendations:
            lines.append(f"- {rec}")
        lines.append("")

    return "\n".join(lines)


def build_inline_comment(concern: ReviewConcern, path_override: str = "") -> dict | None:
    """Build an inline comment dict for the GitHub API.

    Returns None if concern lacks file_path or line_number.
    Uses 'line' + 'side: RIGHT' (file-relative, not diff-relative).
    """
    file_path = path_override or concern.file_path
    if not file_path or concern.line_number is None:
        return None

    body = f"**{concern.category.value}** ({concern.severity.value}): {concern.description}"
    if concern.suggestion:
        body += f"\n\n*Suggestion:* {concern.suggestion}"

    return {
        "path": file_path,
        "line": concern.line_number,
        "side": "RIGHT",
        "body": body,
    }


def build_review_payload(review: PRReviewResult) -> dict:
    """Build full GitHub API payload for posting a review."""
    body = build_review_body(review)
    comments: list[dict] = []

    for concern in review.concerns:
        comment = build_inline_comment(concern)
        if comment is not None:
            comments.append(comment)

    return {
        "body": body,
        "event": "COMMENT",
        "comments": comments,
    }


def _run_gh(args: list[str], input_data: str | None = None) -> tuple[bool, str]:
    """Run a gh CLI command. Returns (success, stdout_or_error)."""
    try:
        result = subprocess.run(
            ["gh"] + args,
            capture_output=True,
            text=True,
            timeout=30,
            input=input_data,
        )
        if result.returncode != 0:
            return False, result.stderr.strip() or f"gh exited with code {result.returncode}"
        return True, result.stdout.strip()
    except FileNotFoundError:
        return False, "gh CLI is not installed"
    except subprocess.TimeoutExpired:
        return False, "gh command timed out"


def get_pr_head_sha(repo: str, pr_number: int) -> str | None:
    """Get HEAD SHA of a PR via gh api."""
    success, output = _run_gh([
        "api", f"repos/{repo}/pulls/{pr_number}", "--jq", ".head.sha",
    ])
    if success and output:
        return output.strip()
    return None


def check_existing_review(repo: str, pr_number: int, head_sha: str) -> bool:
    """Check if dobbe already reviewed at this HEAD.

    Looks for body containing DOBBE_REVIEW_MARKER + commit_id matching head_sha.
    """
    success, output = _run_gh([
        "api", f"repos/{repo}/pulls/{pr_number}/reviews",
    ])
    if not success:
        return False

    try:
        reviews = json.loads(output)
    except json.JSONDecodeError:
        return False

    if not isinstance(reviews, list):
        return False

    for review in reviews:
        if not isinstance(review, dict):
            continue
        body = review.get("body", "")
        commit_id = review.get("commit_id", "")
        if DOBBE_REVIEW_MARKER in body and commit_id == head_sha:
            return True

    return False


def post_review(repo: str, pr_number: int, payload: dict) -> tuple[bool, str]:
    """Post review via gh api. Returns (success, review_url_or_error)."""
    payload_json = json.dumps(payload)
    success, output = _run_gh(
        ["api", f"repos/{repo}/pulls/{pr_number}/reviews", "--method", "POST", "--input", "-"],
        input_data=payload_json,
    )

    if not success:
        return False, output

    # Extract review URL from response
    try:
        response = json.loads(output)
        html_url = response.get("html_url", "")
        if html_url:
            return True, html_url
        # Fallback: construct URL
        review_id = response.get("id", "")
        if review_id:
            return True, f"https://github.com/{repo}/pull/{pr_number}#pullrequestreview-{review_id}"
    except json.JSONDecodeError:
        pass

    return True, f"https://github.com/{repo}/pull/{pr_number}"


def fetch_pr_metadata(repo: str, pr_number: int) -> tuple[PRInfo | None, str | None]:
    """Fetch PR metadata directly via gh api. Returns (pr_info, error)."""
    success, output = _run_gh(["api", f"repos/{repo}/pulls/{pr_number}"])
    if not success:
        return None, f"Failed to fetch PR #{pr_number}: {output}"
    try:
        data = json.loads(output)
    except json.JSONDecodeError:
        return None, f"Invalid JSON for PR #{pr_number}"

    labels = parse_labels(data.get("labels", []))

    user = data.get("user", {}) or {}
    author = user.get("login", "") if isinstance(user, dict) else ""

    pr_info = PRInfo(
        repo=repo,
        pr_number=data.get("number", pr_number),
        title=data.get("title", ""),
        author=author,
        url=data.get("html_url", f"https://github.com/{repo}/pull/{pr_number}"),
        created_at=parse_datetime(data.get("created_at")),
        updated_at=parse_datetime(data.get("updated_at")),
        additions=data.get("additions", 0),
        deletions=data.get("deletions", 0),
        changed_files=data.get("changed_files", 0),
        draft=data.get("draft", False),
        description=data.get("body", "") or "",
        labels=labels,
    )
    return pr_info, None


def fetch_pr_diff(repo: str, pr_number: int, max_lines: int = 2000) -> tuple[str, str | None]:
    """Fetch PR diff via gh CLI. Returns (diff_text, error).

    Truncates to max_lines. Returns empty string + error on failure.
    """
    success, output = _run_gh(["pr", "diff", str(pr_number), "--repo", repo])
    if not success:
        return "", f"Failed to fetch diff: {output}"
    lines = output.split("\n")
    if len(lines) > max_lines:
        truncated = "\n".join(lines[:max_lines])
        truncated += f"\n\n... (truncated: {len(lines)} lines, showing first {max_lines})"
        return truncated, None
    return output, None
