"""Generic JSON extraction and vuln-specific response parsing."""

from __future__ import annotations

import json
from datetime import datetime

from rich.console import Console

from dobbe.models.alert import AccessMode, AlertGroup, RepoResult, TriageResult
from dobbe.models.resolve import (
    FixAction,
    FixResult,
    SkippedFix,
    VerifyIssue,
    VerifyResult,
)
from dobbe.models.review import PRInfo, PRReviewResult, ReviewConcern
from dobbe.models.shared import FixStatus, ReviewCategory, Severity, VerifyCategory

_console = Console(stderr=True)


def extract_json_from_response(text: str) -> dict | None:
    """Extract a JSON object from Claude's response text.

    Handles markdown code fences, preamble text, etc.
    Returns parsed dict or None if no valid JSON object found.
    """
    if not text:
        return None
    cleaned = text.strip()

    # Try to extract from markdown fences
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        json_lines: list[str] = []
        in_fence = False
        for line in lines:
            if line.strip().startswith("```") and not in_fence:
                in_fence = True
                continue
            elif line.strip() == "```" and in_fence:
                break
            elif in_fence:
                json_lines.append(line)
        cleaned = "\n".join(json_lines)

    try:
        data = json.loads(cleaned)
        if isinstance(data, dict):
            return data
    except json.JSONDecodeError:
        pass

    # Try to find JSON object in the raw text
    start = text.find("{")
    end = text.rfind("}") + 1
    if start >= 0 and end > start:
        try:
            data = json.loads(text[start:end])
            if isinstance(data, dict):
                return data
        except json.JSONDecodeError:
            pass

    return None


def parse_triage_response(text: str, repo: str) -> RepoResult:
    """Parse Claude's triage JSON response into a RepoResult."""
    data = extract_json_from_response(text)

    if data is None:
        # Differentiate error message based on whether braces were present
        start = text.find("{")
        end = text.rfind("}") + 1
        if start >= 0 and end > start:
            return RepoResult(
                repo=repo,
                access_mode=AccessMode.REMOTE,
                error=f"Failed to parse Claude's response as JSON. Raw response: {text[:200]}...",
            )
        return RepoResult(
            repo=repo,
            access_mode=AccessMode.REMOTE,
            error=f"No JSON found in Claude's response. Raw response: {text[:200]}...",
        )

    # Parse groups
    groups: list[AlertGroup] = []
    for group_data in data.get("groups") or []:
        if not isinstance(group_data, dict):
            _console.print("[dim]Warning: skipping non-dict group entry[/dim]")
            continue
        alerts: list[TriageResult] = []
        for alert_data in group_data.get("alerts") or []:
            try:
                alerts.append(TriageResult(**alert_data))
            except (TypeError, ValueError, KeyError) as e:
                _console.print(f"[dim]Warning: skipping malformed alert: {e}[/dim]")
                continue

        if alerts:
            groups.append(
                AlertGroup(
                    package_name=group_data.get("package_name", "unknown"),
                    package_ecosystem=group_data.get("package_ecosystem", ""),
                    current_version=group_data.get("current_version", ""),
                    target_version=group_data.get("target_version"),
                    alerts=alerts,
                )
            )

    return RepoResult(repo=repo, access_mode=AccessMode.REMOTE, groups=groups)


def parse_fix_response(text: str, repo: str, branch: str, base_branch: str) -> FixResult:
    """Parse the fix agent's JSON response into a FixResult."""
    data = extract_json_from_response(text)

    if data is None:
        return FixResult(
            repo=repo,
            branch=branch,
            base_branch=base_branch,
            raw_response=text[:500],
        )

    fixes: list[FixAction] = []
    for fix_data in data.get("fixes") or []:
        try:
            status = fix_data.get("status", "applied")
            try:
                status = FixStatus(status)
            except ValueError:
                status = FixStatus.APPLIED
            fixes.append(
                FixAction(
                    package_name=fix_data.get("package_name", "unknown"),
                    file_modified=fix_data.get("file_modified", ""),
                    old_version=fix_data.get("old_version", ""),
                    new_version=fix_data.get("new_version", ""),
                    alerts_addressed=fix_data.get("alerts_addressed") or [],
                    status=status,
                )
            )
        except (TypeError, ValueError, KeyError, AttributeError) as e:
            _console.print(f"[dim]Warning: skipping malformed fix entry: {e}[/dim]")
            continue

    skipped: list[SkippedFix] = []
    for skip_data in data.get("skipped") or []:
        try:
            skipped.append(
                SkippedFix(
                    package_name=skip_data.get("package_name", "unknown"),
                    reason=skip_data.get("reason", ""),
                    alerts_skipped=skip_data.get("alerts_skipped") or [],
                )
            )
        except (TypeError, ValueError, KeyError, AttributeError) as e:
            _console.print(f"[dim]Warning: skipping malformed skip entry: {e}[/dim]")
            continue

    return FixResult(
        repo=repo,
        branch=branch,
        base_branch=base_branch,
        fixes=fixes,
        skipped=skipped,
        diff_summary=data.get("diff_summary", ""),
        raw_response=text[:500],
    )


def parse_verify_response(text: str, repo: str) -> VerifyResult:
    """Parse the verify agent's JSON response into a VerifyResult."""
    data = extract_json_from_response(text)

    if data is None:
        return VerifyResult(
            passed=False,
            feedback="Failed to parse verification response.",
            raw_response=text[:500],
        )

    issues: list[VerifyIssue] = []
    for issue_data in data.get("issues") or []:
        try:
            category = issue_data.get("category", "other")
            try:
                category = VerifyCategory(category)
            except ValueError:
                category = VerifyCategory.OTHER
            severity = issue_data.get("severity", "medium")
            try:
                severity = Severity(severity)
            except ValueError:
                severity = Severity.MEDIUM
            issues.append(
                VerifyIssue(
                    category=category,
                    severity=severity,
                    description=issue_data.get("description", ""),
                    suggestion=issue_data.get("suggestion", ""),
                )
            )
        except (TypeError, ValueError, KeyError, AttributeError) as e:
            _console.print(f"[dim]Warning: skipping malformed verify issue: {e}[/dim]")
            continue

    passed = data.get("passed", False)
    if isinstance(passed, str):
        passed = passed.lower() not in ("false", "no", "0", "")

    return VerifyResult(
        passed=bool(passed),
        issues=issues,
        test_output=data.get("test_output", ""),
        feedback=data.get("feedback", ""),
        raw_response=text[:500],
    )


def _extract_json_array_from_response(text: str) -> list | None:
    """Extract a JSON array from Claude's response text.

    Handles markdown code fences and preamble text.
    Returns parsed list or None.
    """
    cleaned = text.strip()

    # Try markdown fences
    if cleaned.startswith("```"):
        lines = cleaned.split("\n")
        json_lines: list[str] = []
        in_fence = False
        for line in lines:
            if line.strip().startswith("```") and not in_fence:
                in_fence = True
                continue
            elif line.strip() == "```" and in_fence:
                break
            elif in_fence:
                json_lines.append(line)
        cleaned = "\n".join(json_lines)

    try:
        data = json.loads(cleaned)
        if isinstance(data, list):
            return data
    except json.JSONDecodeError:
        pass

    # Try to find JSON array in raw text
    start = text.find("[")
    end = text.rfind("]") + 1
    if start >= 0 and end > start:
        try:
            data = json.loads(text[start:end])
            if isinstance(data, list):
                return data
        except json.JSONDecodeError:
            pass

    return None


def parse_labels(raw: list) -> list[str]:
    """Parse label entries (dicts or strings) into a flat list of label names."""
    labels: list[str] = []
    for lbl in raw:
        if isinstance(lbl, dict):
            labels.append(lbl.get("name", ""))
        elif isinstance(lbl, str):
            labels.append(lbl)
    return labels


def parse_datetime(value: str | None) -> datetime | None:
    """Parse an ISO datetime string, returning None on failure."""
    if not value:
        return None
    try:
        # Handle both Z suffix and +00:00
        cleaned = value.replace("Z", "+00:00")
        dt = datetime.fromisoformat(cleaned)
        return dt.replace(tzinfo=None)
    except (ValueError, TypeError):
        _console.print(f"[dim]Warning: Could not parse datetime '{value}'[/dim]")
        return None


def parse_pr_list_response(text: str, repo: str) -> list[PRInfo]:
    """Parse Claude's PR discovery response into a list of PRInfo."""
    data = extract_json_from_response(text)

    pr_list: list[dict] = []
    if data is not None and "prs" in data:
        pr_list = data.get("prs") or []
    else:
        # Try as a plain JSON array
        arr = _extract_json_array_from_response(text)
        if arr is not None:
            pr_list = arr

    results: list[PRInfo] = []
    for pr_data in pr_list:
        if not isinstance(pr_data, dict):
            _console.print("[dim]Warning: skipping non-dict PR entry[/dim]")
            continue
        try:
            labels = parse_labels(pr_data.get("labels") or [])
            results.append(
                PRInfo(
                    repo=pr_data.get("repo", repo),
                    pr_number=pr_data.get("pr_number", pr_data.get("number", 0)),
                    title=pr_data.get("title", ""),
                    author=pr_data.get("author", ""),
                    url=pr_data.get("url", ""),
                    created_at=parse_datetime(pr_data.get("created_at", pr_data.get("createdAt"))),
                    updated_at=parse_datetime(pr_data.get("updated_at", pr_data.get("updatedAt"))),
                    additions=pr_data.get("additions", 0),
                    deletions=pr_data.get("deletions", 0),
                    changed_files=pr_data.get("changed_files", pr_data.get("changedFiles", 0)),
                    draft=pr_data.get("draft", pr_data.get("isDraft", False)),
                    description=pr_data.get("description", pr_data.get("body", "")),
                    labels=labels,
                )
            )
        except (TypeError, ValueError, KeyError) as e:
            _console.print(f"[dim]Warning: skipping malformed PR entry: {e}[/dim]")
            continue

    return results


def parse_review_response(text: str, pr: PRInfo) -> PRReviewResult:
    """Parse Claude's review JSON response into a PRReviewResult."""
    data = extract_json_from_response(text)

    if data is None:
        return PRReviewResult(
            pr=pr,
            risk_level=Severity.MEDIUM,
            summary="",
            analysis_error=f"Failed to parse review response: {text[:200]}...",
        )

    # Parse risk_level
    risk_str = data.get("risk_level", "medium")
    try:
        risk_level = Severity(risk_str)
    except ValueError:
        risk_level = Severity.MEDIUM

    # Parse concerns
    concerns: list[ReviewConcern] = []
    for concern_data in data.get("concerns") or []:
        if not isinstance(concern_data, dict):
            _console.print("[dim]Warning: skipping non-dict concern[/dim]")
            continue
        try:
            category = concern_data.get("category", "code_quality")
            try:
                category = ReviewCategory(category)
            except ValueError:
                category = ReviewCategory.CODE_QUALITY
            severity = concern_data.get("severity", "medium")
            try:
                severity = Severity(severity)
            except ValueError:
                severity = Severity.MEDIUM
            line_number = concern_data.get("line_number")
            if line_number is not None:
                try:
                    line_number = int(line_number)
                except (TypeError, ValueError):
                    line_number = None
            concerns.append(
                ReviewConcern(
                    category=category,
                    severity=severity,
                    description=concern_data.get("description", ""),
                    file_path=concern_data.get("file_path", ""),
                    line_number=line_number,
                    suggestion=concern_data.get("suggestion", ""),
                )
            )
        except (TypeError, ValueError, KeyError) as e:
            _console.print(f"[dim]Warning: skipping malformed concern: {e}[/dim]")
            continue

    return PRReviewResult(
        pr=pr,
        risk_level=risk_level,
        summary=data.get("summary", ""),
        concerns=concerns,
        recommendations=data.get("recommendations") or [],
        estimated_review_time=data.get("estimated_review_time", ""),
        approval_recommendation=data.get("approval_recommendation", ""),
    )
