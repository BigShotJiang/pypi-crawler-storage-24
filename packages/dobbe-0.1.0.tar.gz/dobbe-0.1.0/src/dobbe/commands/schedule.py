"""Schedule commands - `dobbe schedule`."""

from __future__ import annotations

from datetime import datetime

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn
from rich.table import Table

from dobbe.core.scheduler import (
    acquire_lock,
    add_schedule,
    execute_schedule,
    find_overdue,
    get_shell_hook_info,
    install_login_hook,
    install_shell_hook,
    load_run_logs,
    load_schedules,
    release_lock,
    remove_schedule,
    run_check,
    uninstall_login_hook,
    uninstall_shell_hook,
)
from dobbe.models.schedule import (
    INTERVAL_DELTAS,
    RunStatus,
    Schedule,
    ScheduleInterval,
)

console = Console()
schedule_app = typer.Typer(help="Manage scheduled tasks.")

KNOWN_COMMANDS = {"vuln scan", "vuln resolve", "review digest", "review post"}


@schedule_app.command("add")
def add(
    name: str = typer.Argument(..., help="Unique name for this schedule"),
    command: str = typer.Option(..., "--command", "-c", help="dobbe command to schedule"),
    args: str = typer.Option("", "--args", "-a", help="Arguments string"),
    every: ScheduleInterval = typer.Option(..., "--every", "-e", help="Interval: hourly, every_4h, every_12h, daily, weekly"),
) -> None:
    """Add a new scheduled task."""
    if command not in KNOWN_COMMANDS:
        console.print(
            f"[bold yellow]Warning:[/bold yellow] '{command}' is not a known dobbe command. "
            f"Known commands: {', '.join(sorted(KNOWN_COMMANDS))}"
        )

    schedule = Schedule(
        name=name,
        command=command,
        args=args,
        interval=every,
    )

    try:
        add_schedule(schedule)
    except ValueError as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)

    console.print(f"[bold green]✓[/bold green] Schedule '{name}' added - runs {every.value}")


@schedule_app.command("list")
def list_schedules() -> None:
    """List all scheduled tasks."""
    schedules = load_schedules()
    if not schedules:
        console.print("[dim]No schedules configured. Use [bold]dobbe schedule add[/bold] to create one.[/dim]")
        return

    now = datetime.now()
    overdue_names = {s.name for s in find_overdue(schedules, now)}

    table = Table(title="Scheduled Tasks")
    table.add_column("Name", style="bold")
    table.add_column("Command")
    table.add_column("Interval")
    table.add_column("Last Run")
    table.add_column("Next Due")
    table.add_column("Status")

    for name, sched in schedules.items():
        delta = INTERVAL_DELTAS[sched.interval]
        last_run_str = sched.last_run.strftime("%Y-%m-%d %H:%M") if sched.last_run else "never"
        if sched.last_run:
            next_due = sched.last_run + delta
            next_due_str = next_due.strftime("%Y-%m-%d %H:%M")
        else:
            next_due_str = "now"

        if not sched.enabled:
            status = "[dim]disabled[/dim]"
            row_style = "dim"
        elif name in overdue_names:
            status = "[bold yellow]overdue[/bold yellow]"
            row_style = "yellow"
        else:
            status = "[green]on schedule[/green]"
            row_style = ""

        cmd_str = sched.command
        if sched.args:
            cmd_str += f" {sched.args}"

        table.add_row(name, cmd_str, sched.interval.value, last_run_str, next_due_str, status, style=row_style)

    console.print(table)


@schedule_app.command("remove")
def remove(
    name: str = typer.Argument(..., help="Name of the schedule to remove"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove a scheduled task."""
    if not force:
        confirm = typer.confirm(f"Remove schedule '{name}'?")
        if not confirm:
            raise typer.Abort()

    try:
        remove_schedule(name)
    except KeyError as e:
        console.print(f"[bold red]Error:[/bold red] {e}")
        raise typer.Exit(1)

    console.print(f"[bold green]✓[/bold green] Schedule '{name}' removed")


@schedule_app.command("check")
def check(
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Minimal output (for shell hook)"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would run without executing"),
) -> None:
    """Check for overdue schedules and run them."""
    if dry_run:
        schedules = load_schedules()
        overdue = find_overdue(schedules)
        if not overdue:
            if not quiet:
                console.print("[dim]No overdue schedules.[/dim]")
            return
        if not quiet:
            console.print(f"[bold]{len(overdue)} schedule(s) would run:[/bold]")
        for sched in overdue:
            cmd = sched.command
            if sched.args:
                cmd += f" {sched.args}"
            console.print(f"  • {sched.name}: {cmd}")
        return

    result = run_check(dry_run=False)

    if quiet:
        # Only print errors + one-line summary
        err_console = Console(stderr=True)
        failures = [r for r in result.results if r.status != RunStatus.SUCCESS]
        for f in failures:
            err_console.print(f"[red]✗ {f.schedule_name}: {f.error or f.summary}[/red]")
        if result.schedules_run > 0:
            fail_count = len(failures)
            err_console.print(
                f"dobbe: {result.schedules_run} schedule(s) run, {fail_count} failure(s)",
            )
    else:
        if result.schedules_run == 0:
            console.print("[dim]No overdue schedules.[/dim]")
        else:
            console.print(f"[bold]{result.schedules_run} schedule(s) executed:[/bold]")
            for log in result.results:
                if log.status == RunStatus.SUCCESS:
                    console.print(f"  [green]✓[/green] {log.schedule_name} ({log.duration_seconds:.1f}s)")
                else:
                    console.print(f"  [red]✗[/red] {log.schedule_name}: {log.error or log.summary}")


@schedule_app.command("run")
def run(
    name: str = typer.Argument(..., help="Name of the schedule to run immediately"),
) -> None:
    """Run a schedule immediately regardless of overdue status."""
    schedules = load_schedules()
    if name not in schedules:
        console.print(f"[bold red]Error:[/bold red] Schedule '{name}' not found")
        raise typer.Exit(1)

    sched = schedules[name]
    cmd = sched.command
    if sched.args:
        cmd += f" {sched.args}"
    console.print(f"[bold]Running '{name}': dobbe {cmd}[/bold]")

    lock = acquire_lock(sched.name)
    if lock is None:
        console.print(f"[bold yellow]![/bold yellow] Schedule '{name}' is currently running")
        raise typer.Exit(1)

    try:
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
            progress.add_task(f"Running '{name}'...", total=None)
            log = execute_schedule(sched)
    finally:
        release_lock(sched.name)

    if log.status == RunStatus.SUCCESS:
        console.print(f"[bold green]✓[/bold green] Completed in {log.duration_seconds:.1f}s")
        if log.summary:
            console.print(f"  {log.summary}")
    else:
        console.print(f"[bold red]✗[/bold red] {log.status.value}: {log.error or log.summary}")
        raise typer.Exit(1)


@schedule_app.command("logs")
def logs(
    name: str = typer.Argument(None, help="Schedule name (omit for all)"),
    limit: int = typer.Option(10, "--limit", "-n", help="Number of recent logs"),
) -> None:
    """View recent run logs."""
    if name:
        entries = load_run_logs(name, limit=limit)
        if not entries:
            console.print(f"[dim]No logs found for '{name}'.[/dim]")
            return
    else:
        # Load logs for all schedules
        schedules = load_schedules()
        entries = []
        for sched_name in schedules:
            entries.extend(load_run_logs(sched_name, limit=limit))
        entries.sort(key=lambda e: e.started_at, reverse=True)
        entries = entries[:limit]
        if not entries:
            console.print("[dim]No logs found.[/dim]")
            return

    table = Table(title="Run Logs")
    table.add_column("Schedule")
    table.add_column("Timestamp")
    table.add_column("Status")
    table.add_column("Duration")
    table.add_column("Summary / Error")

    for entry in entries:
        ts = entry.started_at.strftime("%Y-%m-%d %H:%M:%S")
        duration = f"{entry.duration_seconds:.1f}s"
        if entry.status == RunStatus.SUCCESS:
            status_str = "[green]success[/green]"
            detail = entry.summary
        else:
            status_str = f"[red]{entry.status.value}[/red]"
            detail = entry.error or entry.summary
        table.add_row(entry.schedule_name, ts, status_str, duration, detail[:80])

    console.print(table)


@schedule_app.command("install")
def install(
    trigger: str = typer.Option("shell", "--trigger", help="Trigger type: 'shell' or 'login'"),
    shell: str = typer.Option(None, "--shell", help="Force shell type (bash, zsh, fish)"),
    uninstall: bool = typer.Option(False, "--uninstall", help="Remove the installed hook"),
) -> None:
    """Install automatic schedule checking."""
    if trigger == "shell":
        if uninstall:
            success, msg = uninstall_shell_hook(shell)
        else:
            hook_text, profile_path = get_shell_hook_info(shell)
            console.print(f"[bold]Will add to {profile_path}:[/bold]")
            console.print(f"[dim]{hook_text.strip()}[/dim]")
            confirm = typer.confirm("Proceed?")
            if not confirm:
                raise typer.Abort()
            success, msg = install_shell_hook(shell)
    elif trigger == "login":
        if uninstall:
            success, msg = uninstall_login_hook()
        else:
            success, msg = install_login_hook()
    else:
        console.print(f"[bold red]Error:[/bold red] Unknown trigger type '{trigger}'. Use 'shell' or 'login'.")
        raise typer.Exit(1)

    if success:
        console.print(f"[bold green]✓[/bold green] {msg}")
    else:
        console.print(f"[bold yellow]![/bold yellow] {msg}")
