"""Configuration commands - `dobbe config`."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

from dobbe.core.config_manager import CONFIG_FILE, load_config

console = Console()
config_app = typer.Typer(help="View and manage dobbe configuration.")


@config_app.command("check")
def config_check() -> None:
    """Deprecated - use `dobbe doctor` instead."""
    console.print(
        "[bold yellow]Warning:[/bold yellow] 'config check' is deprecated. "
        "Use [bold]dobbe doctor[/bold] instead.\n"
    )
    from dobbe.commands.doctor import run_doctor

    run_doctor()


@config_app.command("show")
def config_show() -> None:
    """Display the current configuration."""
    if not CONFIG_FILE.exists():
        console.print("[yellow]No config file found. Run [bold]dobbe setup[/bold] first.[/yellow]")
        raise typer.Exit(1)

    config = load_config()

    table = Table(title="dobbe configuration", show_header=True, header_style="bold")
    table.add_column("Setting", style="bold")
    table.add_column("Value")

    table.add_row("Config file", str(CONFIG_FILE))
    table.add_row("Organization", config.get("general", {}).get("default_org", ""))
    table.add_row("Default format", config.get("general", {}).get("default_format", "table"))
    table.add_row("Default severity", config.get("general", {}).get("default_severity", "critical,high"))
    table.add_row("Slack channel", config.get("notifications", {}).get("slack_channel", ""))

    local_paths = config.get("repos", {}).get("local_paths", [])
    table.add_row("Local repos", str(len(local_paths)))

    console.print(table)

    if local_paths:
        console.print("\n[bold]Local repo paths:[/bold]")
        for p in local_paths:
            console.print(f"  [dim]{p}[/dim]")
