"""Vulnerability scanning commands - `dobbe vuln`."""

from __future__ import annotations

import asyncio
import sys

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from dobbe.core.claude import ask_claude, ask_claude_async, build_allowed_tools
from dobbe.core.config_manager import (
    get_default_format,
    get_default_org,
    get_default_severity,
    load_config,
)
from dobbe.core.mcp_discovery import discover_mcps
from dobbe.core.notifier import send_notification
from dobbe.core.batch_resolve import BatchResolveConfig, run_batch_resolve
from dobbe.core.org_repos import OrgListError, list_org_repos, list_user_repos
from dobbe.core.pipeline import PipelineConfig, run_pipeline, scan_summary_from_repo_result
from dobbe.core.prompts import build_scan_prompt
from dobbe.core.repo_resolver import resolve_repo
from dobbe.core.response_parser import parse_triage_response
from dobbe.models.alert import (
    AccessMode,
    RepoResult,
    ScanReport,
    Severity,
)
from dobbe.models.resolve import AgentMessage, BatchResolveReport, ResolveReport
from dobbe.output import json_out, markdown
from dobbe.output import table as table_out
from dobbe.output.progress import LiveProgress
from dobbe.output.transcript import render_live_message, render_transcript

console = Console()
vuln_app = typer.Typer(help="Vulnerability scanning and triage.")

MAX_CONCURRENT_SCANS = 5
SCAN_TIMEOUT = 600


def _load_scan_report(path: str) -> ScanReport:
    """Load a ScanReport from a JSON file or stdin ('-').

    Exits with code 1 on IO or parse errors.
    """
    try:
        if path == "-":
            raw = sys.stdin.read()
        else:
            with open(path) as f:
                raw = f.read()
    except (IOError, OSError) as e:
        console.print(f"[bold red]Error:[/bold red] Failed to read scan file: {e}")
        raise typer.Exit(1)

    if not raw.strip():
        console.print("[bold red]Error:[/bold red] Scan file is empty.")
        raise typer.Exit(1)

    try:
        return ScanReport.model_validate_json(raw)
    except Exception as e:
        console.print(f"[bold red]Error:[/bold red] Failed to parse scan report: {e}")
        raise typer.Exit(1)


def _handle_notification(
    report: ScanReport,
    platform: str,
    channel: str | None,
    available_mcps: dict[str, bool],
    config: dict,
) -> None:
    """Backward-compat wrapper - delegates to core.notifier.send_notification."""
    send_notification(
        report_json=report.model_dump_json(indent=2),
        platform=platform,
        channel=channel,
        available_mcps=available_mcps,
        config=config,
        console=console,
    )


def _prepare_scan(
    repo: str,
    severity_filter: list[str],
    available_mcps: dict[str, bool],
    config: dict,
) -> tuple[AccessMode, str, list, str | None]:
    """Build the prompt, tools, and cwd for a repo scan."""
    access_mode, local_path = resolve_repo(repo, config)

    prompt = build_scan_prompt(
        repo=repo,
        severity_filter=severity_filter if severity_filter else None,
        available_mcps=available_mcps,
        access_mode=access_mode.value,
        local_path=str(local_path) if local_path else None,
    )

    tools = build_allowed_tools(
        available_mcps=available_mcps,
        access_mode=access_mode.value,
    )

    cwd = str(local_path) if local_path else None
    return access_mode, prompt, tools, cwd


async def _scan_repo_async(
    repo: str,
    severity_filter: list[str],
    available_mcps: dict[str, bool],
    config: dict,
) -> RepoResult:
    """Scan a single repo asynchronously."""
    access_mode, prompt, tools, cwd = _prepare_scan(repo, severity_filter, available_mcps, config)
    result = await ask_claude_async(prompt=prompt, tools=tools, cwd=cwd, timeout=SCAN_TIMEOUT)

    if not result.success:
        return RepoResult(repo=repo, access_mode=access_mode, error=result.error)

    repo_result = parse_triage_response(result.text, repo)
    repo_result.access_mode = access_mode
    return repo_result


def _scan_repo_sync(
    repo: str,
    severity_filter: list[str],
    available_mcps: dict[str, bool],
    config: dict,
) -> RepoResult:
    """Scan a single repo synchronously."""
    access_mode, prompt, tools, cwd = _prepare_scan(repo, severity_filter, available_mcps, config)
    result = ask_claude(prompt=prompt, tools=tools, cwd=cwd, timeout=SCAN_TIMEOUT)

    if not result.success:
        return RepoResult(repo=repo, access_mode=access_mode, error=result.error)

    repo_result = parse_triage_response(result.text, repo)
    repo_result.access_mode = access_mode
    return repo_result


async def _scan_repos_parallel(
    repos: list[str],
    severity_filter: list[str],
    available_mcps: dict[str, bool],
    config: dict,
) -> list[RepoResult]:
    """Scan multiple repos in parallel (max MAX_CONCURRENT_SCANS concurrent)."""
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_SCANS)

    async def _bounded_scan(repo: str) -> RepoResult:
        async with semaphore:
            return await _scan_repo_async(repo, severity_filter, available_mcps, config)

    tasks = [_bounded_scan(repo) for repo in repos]
    return await asyncio.gather(*tasks)


@vuln_app.command("scan")
def scan(
    repo: str | None = typer.Option(None, "--repo", "-r", help="Single repo to scan (org/repo)"),
    org: str | None = typer.Option(None, "--org", "-o", help="Scan all repos in an organization"),
    user: str | None = typer.Option(None, "--user", "-u", help="Scan all repos for a GitHub user"),
    severity: str | None = typer.Option(None, "--severity", "-s", help="Comma-separated severity filter (critical,high,medium,low)"),
    format: str | None = typer.Option(None, "--format", "-f", help="Output format: table, json, markdown"),
    verbose: bool = typer.Option(False, "--verbose", "-V", help="Show evidence, CVEs, and upgrade paths"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress progress output, only show final result"),
    output: str | None = typer.Option(None, "--output", help="Write output to file instead of stdout"),
    notify: str | None = typer.Option(None, "--notify", help="Send report to platform (slack, jira)"),
    channel: str | None = typer.Option(None, "--channel", help="Notification channel (e.g., #security-alerts)"),
) -> None:
    """Scan repositories for Dependabot vulnerabilities and triage with AI."""
    # Validate mutual exclusivity
    provided = [flag for flag in (repo, org, user) if flag is not None]
    if len(provided) > 1:
        console.print("[bold red]Error:[/bold red] Specify only one of --repo, --org, or --user.")
        raise typer.Exit(1)

    config = load_config()

    # Resolve defaults
    target_org = org or user or get_default_org(config)
    output_format = format or get_default_format(config)
    severity_filter = (
        [s.strip() for s in severity.split(",")]
        if severity
        else get_default_severity(config)
    )

    if not repo and not target_org:
        console.print(
            "[bold red]Error:[/bold red] Specify --repo, --org, or --user, "
            "or set a default org with [bold]dobbe setup[/bold]."
        )
        raise typer.Exit(1)

    # Validate severity values early
    valid_severities: list[str] = []
    for s in severity_filter:
        try:
            Severity(s.lower())
            valid_severities.append(s)
        except ValueError:
            console.print(f"[bold yellow]Warning:[/bold yellow] Unknown severity '{s}' - ignored.")
    if not valid_severities:
        console.print("[bold red]Error:[/bold red] No valid severity values provided.")
        raise typer.Exit(1)
    severity_filter = valid_severities

    # Discover MCPs
    if not quiet:
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
            progress.add_task("Discovering MCP integrations...", total=None)
            available_mcps = discover_mcps()
    else:
        available_mcps = discover_mcps()

    if not quiet:
        mcp_list = [name for name, avail in available_mcps.items() if avail]
        if mcp_list:
            console.print(f"[bold]MCPs available:[/bold] {', '.join(mcp_list)}")
        else:
            console.print("[dim]No MCPs detected - will use gh CLI fallback[/dim]")

    # Determine repos to scan
    repos: list[str] = []
    if repo:
        repos = [repo]
    elif user:
        if not quiet:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
                progress.add_task(f"Listing repos for user {user}...", total=None)
                try:
                    repos = list_user_repos(user, available_mcps)
                except OrgListError as e:
                    console.print(f"[bold red]Error:[/bold red] {e}")
                    raise typer.Exit(1)
        else:
            try:
                repos = list_user_repos(user, available_mcps)
            except OrgListError as e:
                console.print(f"[bold red]Error:[/bold red] {e}")
                raise typer.Exit(1)

        if not quiet:
            console.print(f"Found {len(repos)} repos with Dependabot alerts.")
    elif target_org:
        if not quiet:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
                progress.add_task(f"Listing repos for {target_org}...", total=None)
                try:
                    repos = list_org_repos(target_org, available_mcps)
                except OrgListError as e:
                    console.print(f"[bold red]Error:[/bold red] {e}")
                    raise typer.Exit(1)
        else:
            try:
                repos = list_org_repos(target_org, available_mcps)
            except OrgListError as e:
                console.print(f"[bold red]Error:[/bold red] {e}")
                raise typer.Exit(1)

        if not quiet:
            console.print(f"Found {len(repos)} repos with Dependabot alerts.")

    if not repos:
        console.print("[yellow]No repos to scan.[/yellow]")
        raise typer.Exit(0)

    # Scan repos
    if not quiet:
        console.print(f"\n[bold]Scanning {len(repos)} repo(s) with severity filter: {', '.join(severity_filter)}[/bold]\n")

    repo_results: list[RepoResult] = []

    if len(repos) == 1:
        if not quiet:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
                progress.add_task(f"Triaging {repos[0]}...", total=None)
                repo_results = [_scan_repo_sync(repos[0], severity_filter, available_mcps, config)]
        else:
            repo_results = [_scan_repo_sync(repos[0], severity_filter, available_mcps, config)]
    else:
        if not quiet:
            with LiveProgress(console=console, title="dobbe vuln scan") as lp:
                lp.update(phase=f"Triaging {len(repos)} repos in parallel", total=len(repos))
                for r in repos:
                    lp.update(repo=r, repo_status="waiting")
                repo_results = asyncio.run(
                    _scan_repos_parallel(repos, severity_filter, available_mcps, config)
                )
                for i, r in enumerate(repos):
                    lp.update(repo=r, repo_status="done", completed=i + 1)
        else:
            repo_results = asyncio.run(
                _scan_repos_parallel(repos, severity_filter, available_mcps, config)
            )

    # Build report
    severity_enums = [Severity(s.lower()) for s in severity_filter]

    report = ScanReport(
        org=target_org,
        severity_filter=severity_enums,
        available_mcps=available_mcps,
        repos=repo_results,
    )

    # Output
    if output:
        # Write to file
        if output_format == "json":
            content = json_out.render_report(report)
        elif output_format == "markdown":
            content = markdown.render_report(report, verbose=verbose)
        else:
            # Table → fall back to JSON for file output
            content = json_out.render_report(report)
        try:
            with open(output, "w") as f:
                f.write(content)
        except (IOError, OSError) as e:
            console.print(f"[bold red]Error:[/bold red] Failed to write to {output}: {e}")
            raise typer.Exit(1)
        if not quiet:
            console.print(f"[bold green]\u2713[/bold green] Report written to {output}")
    elif output_format == "json":
        console.print(json_out.render_report(report))
    elif output_format == "markdown":
        console.print(markdown.render_report(report, verbose=verbose))
    else:
        table_out.render_report(report, console=console, verbose=verbose)

    # Notifications
    if notify:
        _handle_notification(report, notify, channel, available_mcps, config)


def _render_resolve_report(report: ResolveReport, output_format: str, console: Console) -> None:
    """Render a ResolveReport in the requested format."""
    if output_format == "json":
        console.print(report.model_dump_json(indent=2))
    elif output_format == "markdown":
        console.print(render_transcript(report))
    else:
        # Table (default) - summary panel
        from rich.panel import Panel
        from rich.table import Table

        status_icon = "\u2705" if report.converged else "\u274c"
        header = (
            f"{status_icon} {report.repo} - "
            f"{report.iteration_count}/{report.max_iterations} iterations, "
            f"{report.total_fixes} fixes, {report.total_skipped} skipped"
        )
        console.print(Panel(header, title="dobbe vuln resolve", style="bold"))

        if report.iterations:
            last = report.iterations[-1]
            if last.fix_result.fixes:
                table = Table(show_header=True, header_style="bold", pad_edge=False, box=None)
                table.add_column("Package", min_width=15)
                table.add_column("Old", width=12)
                table.add_column("New", width=12)
                table.add_column("File", min_width=20)
                table.add_column("Alerts", width=10)
                for fix in last.fix_result.fixes:
                    table.add_row(
                        fix.package_name,
                        fix.old_version,
                        fix.new_version,
                        fix.file_modified,
                        ", ".join(str(a) for a in fix.alerts_addressed),
                    )
                console.print(table)

            if last.fix_result.skipped:
                console.print("\n[bold]Skipped:[/bold]")
                for skip in last.fix_result.skipped:
                    console.print(f"  [dim]{skip.package_name}:[/dim] {skip.reason}")

        if report.pr_url:
            console.print(f"\n[bold]PR:[/bold] {report.pr_url}")

        if report.summary:
            console.print(f"\n{report.summary[:500]}")


def _render_batch_resolve_report(batch_report: BatchResolveReport, output_format: str, console: Console) -> None:
    """Render a BatchResolveReport in the requested format."""
    if output_format == "json":
        console.print(batch_report.model_dump_json(indent=2))
    elif output_format == "markdown":
        parts = [f"# Batch Resolve - {batch_report.owner}", ""]
        parts.append(f"**Repos:** {batch_report.total_repos} | "
                     f"**Converged:** {batch_report.converged_count} | "
                     f"**Fixes:** {batch_report.total_fixes} | "
                     f"**PRs:** {batch_report.total_prs}")
        parts.append("")
        for report in batch_report.reports:
            parts.append(f"## {report.repo}")
            parts.append(render_transcript(report))
            parts.append("")
        console.print("\n".join(parts))
    else:
        # Table (default) - summary panel + per-repo rows
        from rich.panel import Panel
        from rich.table import Table

        header = (
            f"{batch_report.owner} - "
            f"{batch_report.total_repos} repos, "
            f"{batch_report.converged_count} converged, "
            f"{batch_report.total_fixes} fixes, "
            f"{batch_report.total_prs} PRs"
        )
        console.print(Panel(header, title="dobbe vuln resolve (batch)", style="bold"))

        table = Table(show_header=True, header_style="bold", pad_edge=False, box=None)
        table.add_column("Repo", min_width=20)
        table.add_column("Status", width=8)
        table.add_column("Fixes", width=8)
        table.add_column("PR", min_width=30)
        for report in batch_report.reports:
            status = "\u2705" if report.converged else "\u274c"
            table.add_row(
                report.repo,
                status,
                str(report.total_fixes),
                report.pr_url or "-",
            )
        console.print(table)

        if batch_report.pr_urls:
            console.print("\n[bold]PRs created:[/bold]")
            for url in batch_report.pr_urls:
                console.print(f"  {url}")


@vuln_app.command("resolve")
def resolve(
    repo: str | None = typer.Option(None, "--repo", "-r", help="Repository to fix (org/repo)"),
    org: str | None = typer.Option(None, "--org", "-o", help="Resolve all repos in an organization"),
    user: str | None = typer.Option(None, "--user", "-u", help="Resolve all repos for a GitHub user"),
    severity: str | None = typer.Option(None, "--severity", "-s", help="Comma-separated severity filter"),
    max_iterations: int = typer.Option(3, "--max-iterations", min=1, max=10, help="Max fix-verify iterations"),
    base: str = typer.Option("main", "--base", help="Base branch"),
    branch: str | None = typer.Option(None, "--branch", help="Branch name for fixes"),
    create_pr: bool = typer.Option(True, "--create-pr/--no-pr", help="Create PR on convergence"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview mode - scan only, no edits"),
    skip_verify: bool = typer.Option(False, "--skip-verify", help="Skip verification step"),
    format: str | None = typer.Option(None, "--format", "-f", help="Output format: table, json, markdown"),
    from_scan: str | None = typer.Option(
        None, "--from-scan",
        help="Path to scan JSON from `dobbe vuln scan --format json`. Use '-' for stdin.",
    ),
) -> None:
    """Scan, fix, and verify vulnerable dependencies with an agentic feedback loop."""
    # Validate: exactly one of --repo, --org, --user required
    provided = [name for name, val in [("--repo", repo), ("--org", org), ("--user", user)] if val is not None]
    if len(provided) == 0:
        console.print("[bold red]Error:[/bold red] Specify one of --repo, --org, or --user.")
        raise typer.Exit(1)
    if len(provided) > 1:
        console.print(f"[bold red]Error:[/bold red] Conflicting flags: {', '.join(provided)}. Specify only one.")
        raise typer.Exit(1)

    config = load_config()

    output_format = format or get_default_format(config)
    severity_filter = (
        [s.strip() for s in severity.split(",")]
        if severity
        else get_default_severity(config)
    )

    # Validate severity values early
    valid_severities: list[str] = []
    for s in severity_filter:
        try:
            Severity(s.lower())
            valid_severities.append(s)
        except ValueError:
            console.print(f"[bold yellow]Warning:[/bold yellow] Unknown severity '{s}' - ignored.")
    if not valid_severities:
        console.print("[bold red]Error:[/bold red] No valid severity values provided.")
        raise typer.Exit(1)
    severity_filter = valid_severities

    # Validate --from-scan / --dry-run mutual exclusion
    if from_scan and dry_run:
        console.print("[bold red]Error:[/bold red] --from-scan and --dry-run are mutually exclusive.")
        raise typer.Exit(1)

    # Discover MCPs
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
        progress.add_task("Discovering MCP integrations...", total=None)
        available_mcps = discover_mcps()

    # --- Single repo path ---
    if repo:
        access_mode, local_path = resolve_repo(repo, config)
        local_path_str = str(local_path) if local_path else None

        # Load pre-computed scan if --from-scan provided
        scan_override: str | None = None
        if from_scan:
            report = _load_scan_report(from_scan)
            matching = [r for r in report.repos if r.repo == repo]
            if not matching:
                available_repos = [r.repo for r in report.repos]
                console.print(
                    f"[bold red]Error:[/bold red] Repo '{repo}' not found in scan report. "
                    f"Available: {', '.join(available_repos) or '(none)'}"
                )
                raise typer.Exit(1)
            scan_override = scan_summary_from_repo_result(matching[0])

        def _on_message(msg: AgentMessage) -> None:
            render_live_message(msg, console=console)

        pipeline_cfg = PipelineConfig(
            repo=repo,
            local_path=local_path_str,
            severity_filter=severity_filter,
            available_mcps=available_mcps,
            max_iterations=max_iterations,
            branch_name=branch,
            base_branch=base,
            dry_run=dry_run,
            skip_verify=skip_verify,
            no_pr=not create_pr,
            timeout_per_step=600,
            scan_summary_override=scan_override,
        )

        console.print(f"\n[bold]Resolving vulnerabilities for {repo}[/bold]\n")
        report = run_pipeline(pipeline_cfg, callbacks=_on_message)

        # Save transcript
        try:
            from pathlib import Path

            transcript_dir = Path(".dobbe") / "transcripts"
            transcript_dir.mkdir(parents=True, exist_ok=True)
            ts = report.conversation.messages[0].timestamp.strftime("%Y%m%d-%H%M%S") if report.conversation.messages else "unknown"
            transcript_path = transcript_dir / f"resolve-{repo.replace('/', '-')}-{ts}.md"
            transcript_path.write_text(render_transcript(report))
            console.print(f"\n[dim]Transcript saved to {transcript_path}[/dim]")
        except OSError as e:
            console.print(f"[dim]Warning: Could not save transcript: {e}[/dim]")

        _render_resolve_report(report, output_format, console)
        return

    # --- Multi-repo path (--org or --user) ---
    owner = org or user
    assert owner is not None  # guaranteed by validation above

    scan_overrides: dict[str, str] = {}

    if from_scan:
        # Use repos from the scan report instead of discovering them
        scan_report = _load_scan_report(from_scan)
        repos = []
        for repo_result in scan_report.repos:
            if repo_result.error:
                continue
            repos.append(repo_result.repo)
            scan_overrides[repo_result.repo] = scan_summary_from_repo_result(repo_result)
    else:
        # Discover repos
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
            progress.add_task(f"Listing repos for {owner}...", total=None)
            try:
                if user:
                    repos = list_user_repos(owner, available_mcps)
                else:
                    repos = list_org_repos(owner, available_mcps)
            except OrgListError as e:
                console.print(f"[bold red]Error:[/bold red] {e}")
                raise typer.Exit(1)

    if not repos:
        console.print("[yellow]No repos with Dependabot alerts found.[/yellow]")
        raise typer.Exit(0)

    console.print(f"Found {len(repos)} repos with Dependabot alerts.")
    console.print(f"\n[bold]Resolving vulnerabilities across {len(repos)} repos[/bold]\n")

    def _on_batch_start(repo_name: str, index: int, total: int) -> None:
        console.print(f"\n[bold]({index}/{total}) {repo_name}[/bold]")

    def _on_batch_done(repo_name: str, report: ResolveReport) -> None:
        status = "\u2705 converged" if report.converged else "\u274c not converged"
        pr_info = f" - PR: {report.pr_url}" if report.pr_url else ""
        console.print(f"  {status}, {report.total_fixes} fixes{pr_info}")

    def _on_batch_message(msg: AgentMessage) -> None:
        render_live_message(msg, console=console)

    batch_cfg = BatchResolveConfig(
        repos=repos,
        severity_filter=severity_filter,
        available_mcps=available_mcps,
        max_iterations=max_iterations,
        base_branch=base,
        dry_run=dry_run,
        skip_verify=skip_verify,
        no_pr=not create_pr,
        timeout_per_step=600,
        scan_overrides=scan_overrides,
    )

    reports = run_batch_resolve(
        batch_cfg,
        on_repo_start=_on_batch_start,
        on_repo_done=_on_batch_done,
        callbacks=_on_batch_message,
    )

    batch_report = BatchResolveReport.from_reports(reports, owner=owner)
    _render_batch_resolve_report(batch_report, output_format, console)
