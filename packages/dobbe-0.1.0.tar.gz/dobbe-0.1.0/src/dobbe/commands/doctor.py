"""Environment health checks - `dobbe doctor`."""

from __future__ import annotations

import shutil
from dataclasses import dataclass

import typer
from rich.console import Console

from dobbe.core.claude import check_claude_auth, is_claude_installed
from dobbe.core.config_manager import CONFIG_FILE, get_default_org, get_local_paths
from dobbe.core.mcp_discovery import discover_mcps

console = Console()
doctor_app = typer.Typer(help="Check environment health.")


@dataclass
class CheckResult:
    name: str
    passed: bool
    message: str
    fix_hint: str


def _check_claude_installed() -> CheckResult:
    ok = is_claude_installed()
    return CheckResult(
        name="Claude Code CLI",
        passed=ok,
        message="installed" if ok else "not found",
        fix_hint="Install from https://claude.ai/download",
    )


def _check_claude_auth() -> CheckResult:
    ok, msg = check_claude_auth()
    return CheckResult(
        name="Authentication",
        passed=ok,
        message=msg,
        fix_hint="Run: claude login",
    )


def _check_config_exists() -> CheckResult:
    ok = CONFIG_FILE.exists()
    return CheckResult(
        name="Config file",
        passed=ok,
        message=str(CONFIG_FILE) if ok else "not found",
        fix_hint="Run: dobbe setup",
    )


def _check_default_org() -> CheckResult:
    org = get_default_org()
    ok = bool(org)
    return CheckResult(
        name="Default org",
        passed=ok,
        message=org if ok else "not set",
        fix_hint="Run: dobbe setup",
    )


def _check_watch_repos() -> CheckResult:
    paths = get_local_paths()
    ok = len(paths) > 0
    return CheckResult(
        name="Watch repos",
        passed=ok,
        message=f"{len(paths)} configured" if ok else "none configured",
        fix_hint="Run: dobbe setup",
    )


def _check_github_mcp(mcps: dict[str, bool]) -> CheckResult:
    ok = mcps.get("github", False)
    return CheckResult(
        name="GitHub MCP",
        passed=ok,
        message="available" if ok else "not configured",
        fix_hint="Add GitHub MCP to Claude settings",
    )


def _check_slack_mcp(mcps: dict[str, bool]) -> CheckResult:
    ok = mcps.get("slack", False)
    return CheckResult(
        name="Slack MCP",
        passed=ok,
        message="available" if ok else "not configured",
        fix_hint="Add Slack plugin in Claude settings",
    )


def _check_gh_cli() -> CheckResult:
    path = shutil.which("gh")
    ok = path is not None
    return CheckResult(
        name="gh CLI",
        passed=ok,
        message=f"installed ({path})" if ok else "not found",
        fix_hint="Install from https://cli.github.com",
    )


def _check_shell_completions() -> CheckResult:
    from pathlib import Path

    # Check common completion file locations
    home = Path.home()
    candidates = [
        home / ".zfunc" / "_dobbe",
        home / ".bash_completions" / "dobbe",
        home / ".config" / "fish" / "completions" / "dobbe.fish",
    ]
    # Simple heuristic: check if any dedicated completion file exists
    for path in candidates:
        if path.exists():
            return CheckResult(
                name="Shell completions",
                passed=True,
                message="installed",
                fix_hint="",
            )

    return CheckResult(
        name="Shell completions",
        passed=False,
        message="not installed",
        fix_hint="Run: dobbe --install-completion",
    )


def run_doctor() -> list[CheckResult]:
    """Run all health checks and display results. Returns list of results."""
    mcps = discover_mcps()

    checks = [
        _check_claude_installed(),
        _check_claude_auth(),
        _check_config_exists(),
        _check_default_org(),
        _check_watch_repos(),
        _check_github_mcp(mcps),
        _check_slack_mcp(mcps),
        _check_gh_cli(),
        _check_shell_completions(),
    ]

    for check in checks:
        if check.passed:
            console.print(f"  [bold green]✓[/bold green] {check.name} [dim].... {check.message}[/dim]")
        else:
            console.print(f"  [bold red]✗[/bold red] {check.name} [dim].... {check.message}[/dim]")
            if check.fix_hint:
                console.print(f"    [dim]{check.fix_hint}[/dim]")

    passed = sum(1 for c in checks if c.passed)
    total = len(checks)
    console.print(f"\n  {passed}/{total} checks passed.")

    return checks


@doctor_app.callback(invoke_without_command=True)
def doctor(ctx: typer.Context) -> None:
    """Check environment health and diagnose issues."""
    console.print("[bold]dobbe doctor[/bold]\n")
    run_doctor()
