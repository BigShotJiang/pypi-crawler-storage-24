"""First-time setup wizard - `dobbe setup`."""

from __future__ import annotations

import copy
import re
import shutil
import subprocess
import sys

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from dobbe.core.claude import check_claude_auth, is_claude_installed
from dobbe.core.config_manager import DEFAULT_CONFIG, load_config, save_config
from dobbe.core.mcp_discovery import KNOWN_MCPS, discover_mcps
from dobbe.core.repo_resolver import COMMON_PROJECT_DIRS

console = Console()
setup_app = typer.Typer(help="First-time setup wizard for dobbe.")


def _scan_for_repos() -> list[str]:
    """Auto-detect local git repositories in common directories."""
    found: list[str] = []
    for base_dir in COMMON_PROJECT_DIRS:
        if not base_dir.exists():
            continue
        try:
            for child in sorted(base_dir.iterdir()):
                if child.is_dir() and (child / ".git").exists():
                    found.append(str(child))
        except PermissionError:
            continue
    return found


def _verify_org(org: str) -> bool:
    """Verify org exists on GitHub via gh CLI. Returns True if verified."""
    if not org:
        return False
    gh_path = shutil.which("gh")
    if not gh_path:
        return False
    try:
        result = subprocess.run(
            [gh_path, "api", f"/orgs/{org}", "--jq", ".public_repos"],
            capture_output=True, text=True, timeout=15,
        )
        if result.returncode == 0 and result.stdout.strip():
            repo_count = result.stdout.strip()
            console.print(
                f"  [bold green]✓[/bold green] Organization verified - {repo_count} public repos"
            )
            return True
        console.print(
            f"  [bold yellow]⚠[/bold yellow] Could not verify '{org}' on GitHub. "
            "Check the name and try again, or continue anyway."
        )
        return False
    except (subprocess.TimeoutExpired, OSError):
        console.print("  [dim]Org verification skipped (gh CLI timed out)[/dim]")
        return False


def _check_gh_cli(github_mcp_available: bool) -> None:
    """Check if gh CLI is available when GitHub MCP is missing."""
    if github_mcp_available:
        return
    gh_path = shutil.which("gh")
    if gh_path:
        console.print(f"  [bold green]✓[/bold green] gh CLI found at {gh_path}")
    else:
        console.print(
            "  [bold red]✗[/bold red] gh CLI not found. "
            "Install from: https://cli.github.com\n"
            "    dobbe needs either the GitHub MCP or gh CLI for GitHub API access."
        )


def _select_repos(found_repos: list[str]) -> list[str]:
    """Interactive repo selection. Returns list of selected repo paths."""
    if not found_repos:
        console.print("  [dim]No repositories found in common directories.[/dim]")
        return []

    console.print(f"  Found {len(found_repos)} repositories:")
    for i, repo in enumerate(found_repos, 1):
        console.print(f"    [{i}] [dim]{repo}[/dim]")

    selection = typer.prompt(
        "  Enter numbers to include (e.g. 1,3,5), 'all', or 'none'",
        default="all",
    )

    selection = selection.strip().lower()
    if selection == "none":
        return []
    if selection == "all":
        return found_repos

    selected: list[str] = []
    seen: set[int] = set()
    for part in selection.split(","):
        part = part.strip()
        if part.isdigit():
            idx = int(part)
            if 1 <= idx <= len(found_repos) and idx not in seen:
                seen.add(idx)
                selected.append(found_repos[idx - 1])
    if not selected:
        console.print("  [yellow]No valid selection - including all repositories.[/yellow]")
        return found_repos
    return selected


def _run_smoke_test(org: str, mcps: dict[str, bool], *, org_verified: bool = False) -> None:
    """Run a quick validation after config is saved."""
    console.print("\n[bold]Verifying setup...[/bold]")

    # Check 1: Config saved (always passes if we got here)
    console.print("  [bold green]✓[/bold green] Config saved")

    # Check 2: Org reachable via gh (skip if already verified during setup)
    if org_verified and org:
        console.print(
            f"  [bold green]✓[/bold green] GitHub access works (org already verified)"
        )
    else:
        gh_path = shutil.which("gh")
        if gh_path and org:
            try:
                result = subprocess.run(
                    [gh_path, "api", f"/orgs/{org}", "--jq", ".public_repos"],
                    capture_output=True, text=True, timeout=15,
                )
                if result.returncode == 0 and result.stdout.strip():
                    console.print(
                        f"  [bold green]✓[/bold green] GitHub access works "
                        f"(found {result.stdout.strip()} repos in org)"
                    )
                else:
                    console.print("  [bold yellow]⚠[/bold yellow] GitHub org access could not be verified")
            except (subprocess.TimeoutExpired, OSError):
                console.print("  [dim]⚠ GitHub access check timed out[/dim]")
        else:
            console.print("  [dim]- GitHub access check skipped (no gh CLI or org)[/dim]")

    # Check 3: Report MCPs found
    found_mcps = [n for n, v in mcps.items() if v]
    if found_mcps:
        console.print(f"  [bold green]✓[/bold green] MCPs available: {', '.join(found_mcps)}")
    else:
        console.print("  [bold yellow]⚠[/bold yellow] No MCPs detected")

    # Check 4: Slack MCP specifically
    if not mcps.get("slack"):
        console.print("  [dim]- Slack MCP not configured (notifications won't work)[/dim]")


def _post_setup_menu(org: str) -> None:
    """Offer guided next step after setup."""
    console.print("\nWhat would you like to do next?")
    console.print("  [bold][1][/bold] Scan for vulnerabilities")
    console.print("  [bold][2][/bold] Review open PRs")
    console.print("  [bold][3][/bold] Skip")

    choice = typer.prompt("Choose", default="3")
    choice = choice.strip()

    if choice == "1" and org:
        console.print(f"\n[dim]Running: dobbe vuln scan --org {org}[/dim]")
        subprocess.run([sys.executable, "-m", "dobbe", "vuln", "scan", "--org", org])
    elif choice == "2" and org:
        console.print(f"\n[dim]Running: dobbe review digest --org {org}[/dim]")
        subprocess.run([sys.executable, "-m", "dobbe", "review", "digest", "--org", org])
    elif choice in ("1", "2") and not org:
        console.print("[yellow]No org configured - use --repo to target a specific repo.[/yellow]")


def run_setup_wizard() -> None:
    """Run the setup wizard. Extracted so first_run.py can call it directly."""
    console.print(Panel("[bold]dobbe setup[/bold]\n\nLet's configure your environment.", style="bold blue"))

    # Step 1: Check Claude Code
    console.print("\n[bold]Step 1:[/bold] Checking Claude Code CLI...")
    if not is_claude_installed():
        console.print("[bold red]✗[/bold red] Claude Code CLI not found.")
        console.print("  Install it from: https://claude.ai/download")
        console.print("  Then run [bold]dobbe setup[/bold] again.")
        raise typer.Exit(1)
    console.print("[bold green]✓[/bold green] Claude Code CLI is installed.")

    # Step 2: Check authentication
    console.print("\n[bold]Step 2:[/bold] Checking Claude Code authentication...")
    auth_ok, auth_msg = check_claude_auth()
    if not auth_ok:
        console.print(f"[bold red]✗[/bold red] {auth_msg}")
        console.print("  Log in with: [bold]claude login[/bold]")
        raise typer.Exit(1)
    console.print(f"[bold green]✓[/bold green] {auth_msg}")

    # Step 3: Discover MCPs
    console.print("\n[bold]Step 3:[/bold] Discovering MCP servers...")
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
        progress.add_task("Scanning for MCP servers...", total=None)
        mcps = discover_mcps()
    for name in KNOWN_MCPS:
        status = "[bold green]✓[/bold green]" if mcps.get(name) else "[dim]✗[/dim]"
        console.print(f"  {status} {name}")

    if not mcps.get("github"):
        console.print(
            "\n[bold yellow]Warning:[/bold yellow] GitHub MCP not found. "
            "dobbe will fall back to the `gh` CLI for GitHub API calls."
        )
    # B3: Check gh CLI when GitHub MCP is missing
    _check_gh_cli(mcps.get("github", False))

    # Step 4: Ask for default org
    console.print("\n[bold]Step 4:[/bold] Configuration")
    existing_config = load_config()
    existing_org = existing_config.get("general", {}).get("default_org", "")

    default_org = typer.prompt(
        "Default GitHub organization",
        default=existing_org or "",
        show_default=bool(existing_org),
    )

    _ORG_NAME_RE = re.compile(r"^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?$")
    if default_org and not _ORG_NAME_RE.match(default_org):
        console.print(
            f"[bold yellow]Warning:[/bold yellow] '{default_org}' doesn't look like a valid "
            "GitHub organization name (expected alphanumeric with optional hyphens)."
        )

    # B1: Verify org exists on GitHub
    org_verified = False
    if default_org and _ORG_NAME_RE.match(default_org):
        org_verified = _verify_org(default_org)

    # Step 5: Auto-detect local repos with interactive selection
    console.print("\n[bold]Step 5:[/bold] Scanning for local repositories...")
    with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
        progress.add_task("Scanning local directories...", total=None)
        found_repos = _scan_for_repos()

    # B2: Interactive repo selection
    selected_repos = _select_repos(found_repos)

    # Build and save config
    config = copy.deepcopy(DEFAULT_CONFIG)
    config["general"]["default_org"] = default_org
    config["repos"]["local_paths"] = selected_repos

    # Preserve any existing notification settings
    if "notifications" in existing_config:
        config["notifications"] = existing_config["notifications"]

    config_path = save_config(config)
    console.print(f"\n[bold green]✓[/bold green] Config saved to [bold]{config_path}[/bold]")

    # B4: Smoke test
    _run_smoke_test(default_org, mcps, org_verified=org_verified)

    # Mark setup complete in state
    from dobbe.core.state_manager import mark_setup_complete
    mark_setup_complete()

    # Summary
    console.print(
        Panel(
            f"[bold green]Setup complete![/bold green]\n\n"
            f"Organization: {default_org or '(not set)'}\n"
            f"Local repos: {len(selected_repos)}\n"
            f"MCPs: {', '.join(n for n, v in mcps.items() if v) or 'none detected'}\n\n"
            f"Try: [bold]dobbe vuln scan --repo {default_org + '/your-repo' if default_org else 'org/repo'}[/bold]",
            style="bold green",
        )
    )

    # E1: Post-setup menu
    _post_setup_menu(default_org)


@setup_app.callback(invoke_without_command=True)
def setup(
    ctx: typer.Context,
) -> None:
    """Interactive setup wizard for dobbe."""
    run_setup_wizard()
