"""PR review digest commands - `dobbe review`."""

from __future__ import annotations

import asyncio

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

from dobbe.core.claude import build_allowed_tools
from dobbe.core.config_manager import (
    get_default_format,
    get_default_org,
    get_review_max_diff_lines,
    get_review_reviewers,
    get_review_skip_authors,
    get_review_skip_labels,
    get_review_stale_days,
    get_review_watch_repos,
    get_slack_channel,
    load_config,
)
from dobbe.core.mcp_discovery import discover_mcps
from dobbe.core.notifier import send_notification
from dobbe.core.org_repos import OrgListError, list_org_repos
from dobbe.core.prompts import build_review_notify_prompt
from dobbe.core.review_pipeline import run_review_digest, run_review_post
from dobbe.models.review import ReviewDigest
from dobbe.output import review_markdown, review_post_markdown, review_post_table, review_table
from dobbe.output.progress import LiveProgress

console = Console()
review_app = typer.Typer(help="PR review digest and analysis.")


def _handle_review_notification(
    digest: ReviewDigest,
    channel: str | None,
    available_mcps: dict[str, bool],
    config: dict,
) -> None:
    """Send review digest to Slack."""
    from dobbe.core.claude import ask_claude

    if not available_mcps.get("slack"):
        console.print("[bold red]Error:[/bold red] Slack MCP not available. Cannot send notification.")
        return

    target_channel = channel or get_slack_channel(config)
    if not target_channel:
        console.print("[bold red]Error:[/bold red] No Slack channel specified. Use --channel or configure in dobbe setup.")
        return

    console.print(f"\n[bold]Sending digest to Slack channel {target_channel}...[/bold]")
    prompt = build_review_notify_prompt(
        digest_json=digest.model_dump_json(indent=2),
        channel=target_channel,
    )
    tools = build_allowed_tools(available_mcps=available_mcps)

    result = ask_claude(prompt=prompt, tools=tools, timeout=120)
    if result.success:
        console.print(f"[bold green]\u2713[/bold green] Digest posted to {target_channel}")
    else:
        console.print(f"[bold red]\u2717[/bold red] Failed to post to Slack: {result.error}")


@review_app.command("digest")
def digest(
    repo: str | None = typer.Option(None, "--repo", "-r", help="Single repo to review (org/repo)"),
    org: str | None = typer.Option(None, "--org", "-o", help="Review all repos in an organization"),
    reviewer: str | None = typer.Option(None, "--reviewer", help="GitHub username to filter by (default: @me)"),
    stale_days: int | None = typer.Option(None, "--stale-days", help="Days before flagging PR as stale"),
    format: str | None = typer.Option(None, "--format", "-f", help="Output format: table, json, markdown"),
    verbose: bool = typer.Option(False, "--verbose", "-V", help="Show hidden data: diff stats, recommendations, concerns"),
    output: str | None = typer.Option(None, "--output", help="Write output to file instead of stdout"),
    notify: str | None = typer.Option(None, "--notify", help="Send digest to platform (slack)"),
    channel: str | None = typer.Option(None, "--channel", help="Notification channel (e.g., #pr-reviews)"),
    skip_label: str | None = typer.Option(None, "--skip-label", help="Skip PRs with these labels (comma-separated)"),
    skip_author: str | None = typer.Option(None, "--skip-author", help="Skip PRs by these authors (comma-separated)"),
    max_diff_lines: int | None = typer.Option(None, "--max-diff-lines", help="Max diff lines to include (default: 2000)"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress progress output, only show final result"),
) -> None:
    """Fetch open PRs, analyze with AI, and output a prioritized review digest."""
    config = load_config()

    # Resolve output format
    output_format = format or get_default_format(config)

    # Resolve reviewers
    reviewers = [reviewer] if reviewer else get_review_reviewers(config)

    # Resolve stale days
    stale = stale_days if stale_days is not None else get_review_stale_days(config)

    # Resolve filter options
    labels_to_skip = [s.strip() for s in skip_label.split(",") if s.strip()] if skip_label else get_review_skip_labels(config)
    authors_to_skip = [s.strip() for s in skip_author.split(",") if s.strip()] if skip_author else get_review_skip_authors(config)
    diff_lines = max_diff_lines if max_diff_lines is not None else get_review_max_diff_lines(config)

    # Discover MCPs
    if not quiet:
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
            progress.add_task("Discovering MCP integrations...", total=None)
            available_mcps = discover_mcps()
    else:
        available_mcps = discover_mcps()

    if not quiet:
        mcp_list = [name for name, avail in available_mcps.items() if avail]
        if mcp_list:
            console.print(f"[bold]MCPs available:[/bold] {', '.join(mcp_list)}")
        else:
            console.print("[dim]No MCPs detected - will use gh CLI fallback[/dim]")

    # Resolve repos
    repos: list[str] = []
    if repo:
        repos = [repo]
    elif org:
        target_org = org
        if not quiet:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
                progress.add_task(f"Listing repos for {target_org}...", total=None)
                try:
                    repos = list_org_repos(target_org, available_mcps)
                except OrgListError as e:
                    console.print(f"[bold red]Error:[/bold red] {e}")
                    raise typer.Exit(1)
        else:
            try:
                repos = list_org_repos(target_org, available_mcps)
            except OrgListError as e:
                console.print(f"[bold red]Error:[/bold red] {e}")
                raise typer.Exit(1)
    else:
        repos = get_review_watch_repos(config)

    if not repos:
        console.print(
            "[bold red]Error:[/bold red] No repos to review. "
            "Specify --repo or --org, or configure [review] watch_repos in dobbe setup."
        )
        raise typer.Exit(1)

    # Run pipeline
    if not quiet:
        console.print(f"\n[bold]Reviewing PRs across {len(repos)} repo(s) for reviewers: {', '.join(reviewers)}[/bold]\n")

    if quiet:
        review_digest = asyncio.run(
            run_review_digest(
                repos=repos,
                reviewers=reviewers,
                available_mcps=available_mcps,
                stale_days=stale,
                skip_labels=labels_to_skip,
                skip_authors=authors_to_skip,
                max_diff_lines=diff_lines,
            )
        )
    else:
        with LiveProgress(console=console, title="dobbe review digest") as lp:
            review_digest = asyncio.run(
                run_review_digest(
                    repos=repos,
                    reviewers=reviewers,
                    available_mcps=available_mcps,
                    stale_days=stale,
                    skip_labels=labels_to_skip,
                    skip_authors=authors_to_skip,
                    max_diff_lines=diff_lines,
                    on_progress=lp.callback,
                )
            )

    # Output
    if output:
        if output_format == "json":
            content = review_digest.model_dump_json(indent=2)
        elif output_format == "markdown":
            content = review_markdown.render_digest(review_digest, verbose=verbose)
        else:
            content = review_digest.model_dump_json(indent=2)
        try:
            with open(output, "w") as f:
                f.write(content)
        except (IOError, OSError) as e:
            console.print(f"[bold red]Error:[/bold red] Failed to write to {output}: {e}")
            raise typer.Exit(1)
        if not quiet:
            console.print(f"[bold green]\u2713[/bold green] Report written to {output}")
    elif output_format == "json":
        console.print(review_digest.model_dump_json(indent=2))
    elif output_format == "markdown":
        console.print(review_markdown.render_digest(review_digest, verbose=verbose))
    else:
        review_table.render_digest(review_digest, console=console, verbose=verbose)

    # Notifications
    if notify == "slack":
        _handle_review_notification(review_digest, channel, available_mcps, config)


@review_app.command("post")
def post(
    repo: str | None = typer.Option(None, "--repo", "-r", help="Single repo (org/repo)"),
    org: str | None = typer.Option(None, "--org", "-o", help="Review all repos in an organization"),
    pr: int | None = typer.Option(None, "--pr", help="PR number to review"),
    all_prs: bool = typer.Option(False, "--all", help="Review all open PRs"),
    reviewer: str | None = typer.Option(None, "--reviewer", help="GitHub username to filter by"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Preview without posting"),
    format: str | None = typer.Option(None, "--format", "-f", help="Output format: table, json, markdown"),
    verbose: bool = typer.Option(False, "--verbose", "-V", help="Show concern details with file:line and suggestions"),
    output: str | None = typer.Option(None, "--output", help="Write output to file instead of stdout"),
    skip_label: str | None = typer.Option(None, "--skip-label", help="Skip PRs with these labels (comma-separated)"),
    skip_author: str | None = typer.Option(None, "--skip-author", help="Skip PRs by these authors (comma-separated)"),
    max_diff_lines: int | None = typer.Option(None, "--max-diff-lines", help="Max diff lines to include (default: 2000)"),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Suppress progress output, only show final result"),
) -> None:
    """Analyze PRs with AI and post reviews to GitHub."""
    config = load_config()

    # Default to --all when neither --pr nor --all is given
    if not pr and not all_prs:
        all_prs = True
    if pr and all_prs:
        console.print("[bold red]Error:[/bold red] Use --pr or --all, not both.")
        raise typer.Exit(1)

    # --pr requires --repo
    if pr and not repo:
        console.print("[bold red]Error:[/bold red] --pr requires --repo.")
        raise typer.Exit(1)

    # Resolve output format
    output_format = format or get_default_format(config)

    # Resolve reviewers
    reviewers = [reviewer] if reviewer else get_review_reviewers(config)

    # Resolve filter options
    labels_to_skip = [s.strip() for s in skip_label.split(",") if s.strip()] if skip_label else get_review_skip_labels(config)
    authors_to_skip = [s.strip() for s in skip_author.split(",") if s.strip()] if skip_author else get_review_skip_authors(config)
    diff_lines = max_diff_lines if max_diff_lines is not None else get_review_max_diff_lines(config)

    # Discover MCPs
    if not quiet:
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
            progress.add_task("Discovering MCP integrations...", total=None)
            available_mcps = discover_mcps()
    else:
        available_mcps = discover_mcps()

    if not quiet:
        mcp_list = [name for name, avail in available_mcps.items() if avail]
        if mcp_list:
            console.print(f"[bold]MCPs available:[/bold] {', '.join(mcp_list)}")
        else:
            console.print("[dim]No MCPs detected - will use gh CLI fallback[/dim]")

    # Resolve repos
    repos: list[str] = []
    if repo:
        repos = [repo]
    elif org:
        target_org = org
        if not quiet:
            with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), TimeElapsedColumn(), console=console) as progress:
                progress.add_task(f"Listing repos for {target_org}...", total=None)
                try:
                    repos = list_org_repos(target_org, available_mcps)
                except OrgListError as e:
                    console.print(f"[bold red]Error:[/bold red] {e}")
                    raise typer.Exit(1)
        else:
            try:
                repos = list_org_repos(target_org, available_mcps)
            except OrgListError as e:
                console.print(f"[bold red]Error:[/bold red] {e}")
                raise typer.Exit(1)
    else:
        repos = get_review_watch_repos(config)

    if not repos:
        console.print(
            "[bold red]Error:[/bold red] No repos specified. "
            "Use --repo or --org, or configure [review] watch_repos."
        )
        raise typer.Exit(1)

    # Run pipeline
    if not quiet:
        action = "Previewing" if dry_run else "Posting"
        console.print(f"\n[bold]{action} reviews for {len(repos)} repo(s)...[/bold]\n")

    if quiet:
        report = asyncio.run(
            run_review_post(
                repos=repos,
                pr_number=pr,
                reviewers=reviewers,
                available_mcps=available_mcps,
                dry_run=dry_run,
                skip_labels=labels_to_skip,
                skip_authors=authors_to_skip,
                max_diff_lines=diff_lines,
            )
        )
    else:
        with LiveProgress(console=console, title="dobbe review post") as lp:
            report = asyncio.run(
                run_review_post(
                    repos=repos,
                    pr_number=pr,
                    reviewers=reviewers,
                    available_mcps=available_mcps,
                    dry_run=dry_run,
                    skip_labels=labels_to_skip,
                    skip_authors=authors_to_skip,
                    max_diff_lines=diff_lines,
                    on_progress=lp.callback,
                )
            )

    # Output
    if output:
        if output_format == "json":
            content = report.model_dump_json(indent=2)
        elif output_format == "markdown":
            content = review_post_markdown.render_post_report(report, verbose=verbose)
        else:
            content = report.model_dump_json(indent=2)
        try:
            with open(output, "w") as f:
                f.write(content)
        except (IOError, OSError) as e:
            console.print(f"[bold red]Error:[/bold red] Failed to write to {output}: {e}")
            raise typer.Exit(1)
        if not quiet:
            console.print(f"[bold green]\u2713[/bold green] Report written to {output}")
    elif output_format == "json":
        console.print(report.model_dump_json(indent=2))
    elif output_format == "markdown":
        console.print(review_post_markdown.render_post_report(report, verbose=verbose))
    else:
        review_post_table.render_post_report(report, console=console, verbose=verbose)
