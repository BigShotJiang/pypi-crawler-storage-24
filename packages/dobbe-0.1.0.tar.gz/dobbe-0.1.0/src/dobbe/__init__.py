"""dobbe - AI-powered engineering CLI."""

__version__ = "0.1.0"
