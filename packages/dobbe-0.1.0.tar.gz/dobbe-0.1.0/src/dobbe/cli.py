"""dobbe CLI - AI-powered engineering automation."""

from __future__ import annotations

import importlib
import os

import typer

from dobbe import __version__

app = typer.Typer(
    name="dobbe",
    help="AI-powered engineering CLI - triage vulnerabilities, automate workflows.",
    no_args_is_help=True,
)


def _register_command(module_path: str, attr: str, name: str, help_text: str) -> None:
    """Import a command module and register its Typer app.

    On import failure, register a stub that reports the error - other commands
    keep working.
    """
    try:
        mod = importlib.import_module(module_path)
        app.add_typer(getattr(mod, attr), name=name, help=help_text)
    except (ImportError, AttributeError) as exc:
        broken = typer.Typer(help=f"{help_text} [UNAVAILABLE]")

        @broken.callback(invoke_without_command=True)
        def _handler(ctx: typer.Context) -> None:
            typer.echo(f"Error: '{name}' command failed to load: {exc}", err=True)
            raise typer.Exit(1)

        app.add_typer(broken, name=name, help=f"{help_text} [UNAVAILABLE]")


_register_command("dobbe.commands.vuln", "vuln_app", "vuln", "Vulnerability scanning and triage.")
_register_command("dobbe.commands.review", "review_app", "review", "PR review digest and analysis.")
_register_command("dobbe.commands.config", "config_app", "config", "View and manage configuration.")
_register_command("dobbe.commands.setup", "setup_app", "setup", "First-time setup wizard.")
_register_command("dobbe.commands.schedule", "schedule_app", "schedule", "Manage scheduled tasks.")
_register_command("dobbe.commands.doctor", "doctor_app", "doctor", "Check environment health.")


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"dobbe {__version__}")
        raise typer.Exit()


def _no_color_callback(value: bool) -> None:
    if value:
        os.environ["NO_COLOR"] = "1"


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False, "--version", "-v", help="Show version and exit.",
        callback=_version_callback, is_eager=True,
    ),
    no_color: bool = typer.Option(
        False, "--no-color", help="Disable colored output (also respects NO_COLOR env var).",
        callback=_no_color_callback, is_eager=True,
    ),
) -> None:
    if ctx.invoked_subcommand is not None:
        from dobbe.core.first_run import maybe_show_tip, prompt_and_run_setup, should_prompt_setup
        from dobbe.core.state_manager import increment_run_count

        quiet = os.environ.get("DOBBE_QUIET") == "1"
        if should_prompt_setup(ctx.invoked_subcommand, quiet):
            prompt_and_run_setup()
        if ctx.invoked_subcommand not in {"setup", "doctor"}:
            increment_run_count()
            ctx.call_on_close(lambda: maybe_show_tip(quiet))
