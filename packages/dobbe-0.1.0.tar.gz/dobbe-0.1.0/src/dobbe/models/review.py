"""Pydantic models for PR review digest results."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from dobbe.models.shared import ReviewCategory, Severity


class PRInfo(BaseModel):
    """Metadata for a single pull request."""

    repo: str
    pr_number: int
    title: str
    author: str
    url: str
    created_at: datetime | None = None
    updated_at: datetime | None = None
    additions: int = 0
    deletions: int = 0
    changed_files: int = 0
    draft: bool = False
    description: str = ""
    labels: list[str] = Field(default_factory=list)

    @property
    def age_days(self) -> int:
        if self.created_at is None:
            return 0
        delta = datetime.now() - self.created_at
        return delta.days


class ReviewConcern(BaseModel):
    """A specific concern found during PR review."""

    category: ReviewCategory
    severity: Severity
    description: str
    file_path: str = ""
    line_number: int | None = None
    suggestion: str = ""


class PRReviewResult(BaseModel):
    """Claude's review of a single pull request."""

    pr: PRInfo
    risk_level: Severity
    summary: str
    concerns: list[ReviewConcern] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)
    estimated_review_time: str = ""
    approval_recommendation: str = ""
    analysis_error: str | None = None


class ReviewDigest(BaseModel):
    """Full review digest across one or more repositories."""

    timestamp: datetime = Field(default_factory=datetime.now)
    reviewers: list[str] = Field(default_factory=list)
    repos_scanned: list[str] = Field(default_factory=list)
    results: list[PRReviewResult] = Field(default_factory=list)
    stale_days: int = 7
    errors: list[str] = Field(default_factory=list)

    @property
    def total_prs(self) -> int:
        return len(self.results)

    @property
    def critical_count(self) -> int:
        return sum(1 for r in self.results if r.risk_level == Severity.CRITICAL)

    @property
    def stale_prs(self) -> list[PRReviewResult]:
        return [r for r in self.results if r.pr.age_days >= self.stale_days]

    @property
    def stats_by_risk(self) -> dict[Severity, int]:
        counts: dict[Severity, int] = {}
        for r in self.results:
            counts[r.risk_level] = counts.get(r.risk_level, 0) + 1
        return counts


class PostResult(BaseModel):
    """Result of posting a review to a single PR."""

    pr: PRInfo
    review: PRReviewResult
    posted: bool = False
    skipped_reason: str = ""
    review_url: str = ""
    error: str = ""


class ReviewPostReport(BaseModel):
    """Full report of a review post run."""

    timestamp: datetime = Field(default_factory=datetime.now)
    repos_scanned: list[str] = Field(default_factory=list)
    results: list[PostResult] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    dry_run: bool = False

    @property
    def total_posted(self) -> int:
        return sum(1 for r in self.results if r.posted)

    @property
    def total_skipped(self) -> int:
        return sum(1 for r in self.results if r.skipped_reason)

    @property
    def total_failed(self) -> int:
        return sum(1 for r in self.results if r.error)
