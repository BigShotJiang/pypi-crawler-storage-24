"""Pydantic models for vulnerability alerts and triage results."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from dobbe.models.shared import AccessMode, Severity

# Re-export for backward compatibility
__all__ = [
    "AccessMode",
    "Severity",
    "Alert",
    "TriageResult",
    "AlertGroup",
    "RepoResult",
    "ScanReport",
]


class Alert(BaseModel):
    """Raw vulnerability alert from GitHub Dependabot."""

    number: int
    state: str = "open"
    cve_id: str | None = None
    ghsa_id: str | None = None
    package_name: str
    package_ecosystem: str = ""
    vulnerable_version_range: str = ""
    patched_version: str | None = None
    severity: Severity
    summary: str = ""
    description: str = ""
    url: str = ""


class TriageResult(BaseModel):
    """Claude's assessment of a vulnerability alert."""

    alert_number: int
    cve_id: str | None = None
    package_name: str
    severity: Severity
    summary: str = Field(description="Plain English summary of the vulnerability")
    affected: bool = Field(description="Whether the code is actually affected")
    evidence: str = Field(
        default="",
        description="Code paths or reasoning for the affected determination",
    )
    risk_level: Severity = Field(
        description="Adjusted risk level after triage (may differ from original severity)"
    )
    recommended_action: str = Field(description="What to do about this vulnerability")


class AlertGroup(BaseModel):
    """Group of related alerts that share a common fix (e.g., same package upgrade)."""

    package_name: str
    package_ecosystem: str = ""
    current_version: str = ""
    target_version: str | None = None
    alerts: list[TriageResult] = Field(default_factory=list)

    @property
    def max_risk(self) -> Severity:
        if not self.alerts:
            return Severity.LOW
        order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW]
        for level in order:
            if any(a.risk_level == level for a in self.alerts):
                return level
        return Severity.LOW

    @property
    def all_safe_to_ignore(self) -> bool:
        return all(not a.affected for a in self.alerts)


class RepoResult(BaseModel):
    """Triage results for a single repository."""

    repo: str
    access_mode: AccessMode
    groups: list[AlertGroup] = Field(default_factory=list)
    error: str | None = None

    @property
    def total_alerts(self) -> int:
        return sum(len(g.alerts) for g in self.groups)

    @property
    def affected_count(self) -> int:
        return sum(1 for g in self.groups for a in g.alerts if a.affected)

    @property
    def safe_to_ignore_count(self) -> int:
        return sum(1 for g in self.groups for a in g.alerts if not a.affected)


class ScanReport(BaseModel):
    """Full scan report across one or more repositories."""

    timestamp: datetime = Field(default_factory=datetime.now)
    org: str | None = None
    severity_filter: list[Severity] = Field(default_factory=list)
    available_mcps: dict[str, bool] = Field(default_factory=dict)
    repos: list[RepoResult] = Field(default_factory=list)

    @property
    def total_alerts(self) -> int:
        return sum(r.total_alerts for r in self.repos)

    @property
    def total_affected(self) -> int:
        return sum(r.affected_count for r in self.repos)

    @property
    def total_safe_to_ignore(self) -> int:
        return sum(r.safe_to_ignore_count for r in self.repos)

    @property
    def stats_by_severity(self) -> dict[Severity, int]:
        counts: dict[Severity, int] = {}
        for repo in self.repos:
            for group in repo.groups:
                for alert in group.alerts:
                    counts[alert.risk_level] = counts.get(alert.risk_level, 0) + 1
        return counts
