"""Pydantic models for the vulnerability resolution pipeline."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field

from dobbe.models.shared import FixStatus, Severity, VerifyCategory


class FixAction(BaseModel):
    """A single package upgrade applied by the fix agent."""

    package_name: str
    file_modified: str
    old_version: str
    new_version: str
    alerts_addressed: list[int] = Field(default_factory=list)
    status: FixStatus = FixStatus.APPLIED


class SkippedFix(BaseModel):
    """A package that was intentionally skipped during fixing."""

    package_name: str
    reason: str
    alerts_skipped: list[int] = Field(default_factory=list)


class FixResult(BaseModel):
    """Result of one fix iteration."""

    repo: str
    branch: str
    base_branch: str
    fixes: list[FixAction] = Field(default_factory=list)
    skipped: list[SkippedFix] = Field(default_factory=list)
    diff_summary: str = ""
    raw_response: str = ""


class VerifyIssue(BaseModel):
    """A single issue found during verification."""

    category: VerifyCategory
    severity: Severity
    description: str
    suggestion: str = ""


class VerifyResult(BaseModel):
    """Result of one verification iteration."""

    passed: bool
    issues: list[VerifyIssue] = Field(default_factory=list)
    test_output: str = ""
    feedback: str = ""
    raw_response: str = ""


class PipelineIteration(BaseModel):
    """One fix-verify cycle."""

    iteration: int
    fix_result: FixResult
    verify_result: VerifyResult | None = None


class AgentMessage(BaseModel):
    """One message in the agent conversation thread."""

    agent: str
    icon: str
    iteration: int | None = None
    summary: str
    details: str | None = None
    timestamp: datetime = Field(default_factory=datetime.now)


class ConversationLog(BaseModel):
    """Full agent conversation thread."""

    messages: list[AgentMessage] = Field(default_factory=list)

    def add(
        self,
        agent: str,
        icon: str,
        summary: str,
        details: str | None = None,
        iteration: int | None = None,
    ) -> AgentMessage:
        """Append a message and return it."""
        msg = AgentMessage(
            agent=agent,
            icon=icon,
            summary=summary,
            details=details,
            iteration=iteration,
        )
        self.messages.append(msg)
        return msg


class ResolveReport(BaseModel):
    """Final output of the resolve pipeline."""

    repo: str
    scan_summary: str = ""
    iterations: list[PipelineIteration] = Field(default_factory=list)
    converged: bool = False
    max_iterations: int = 3
    final_branch: str = ""
    pr_url: str = ""
    summary: str = ""
    conversation: ConversationLog = Field(default_factory=ConversationLog)

    @property
    def total_fixes(self) -> int:
        if not self.iterations:
            return 0
        last = self.iterations[-1]
        return len(last.fix_result.fixes)

    @property
    def total_skipped(self) -> int:
        if not self.iterations:
            return 0
        last = self.iterations[-1]
        return len(last.fix_result.skipped)

    @property
    def iteration_count(self) -> int:
        return len(self.iterations)


class BatchResolveReport(BaseModel):
    """Aggregate report across multiple repo resolves."""

    timestamp: datetime = Field(default_factory=datetime.now)
    owner: str = ""
    reports: list[ResolveReport] = Field(default_factory=list)

    @classmethod
    def from_reports(cls, reports: list[ResolveReport], owner: str = "") -> BatchResolveReport:
        return cls(owner=owner, reports=reports)

    @property
    def total_repos(self) -> int:
        return len(self.reports)

    @property
    def converged_count(self) -> int:
        return sum(1 for r in self.reports if r.converged)

    @property
    def total_fixes(self) -> int:
        return sum(r.total_fixes for r in self.reports)

    @property
    def total_prs(self) -> int:
        return sum(1 for r in self.reports if r.pr_url)

    @property
    def pr_urls(self) -> list[str]:
        return [r.pr_url for r in self.reports if r.pr_url]
