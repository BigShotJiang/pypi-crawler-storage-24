"""Pydantic models for the schedule system."""

from __future__ import annotations

from datetime import datetime, timedelta
from enum import Enum

from pydantic import BaseModel, Field


class ScheduleInterval(str, Enum):
    """Supported scheduling intervals."""

    HOURLY = "hourly"
    EVERY_4H = "every_4h"
    EVERY_12H = "every_12h"
    DAILY = "daily"
    WEEKLY = "weekly"


INTERVAL_DELTAS: dict[ScheduleInterval, timedelta] = {
    ScheduleInterval.HOURLY: timedelta(hours=1),
    ScheduleInterval.EVERY_4H: timedelta(hours=4),
    ScheduleInterval.EVERY_12H: timedelta(hours=12),
    ScheduleInterval.DAILY: timedelta(hours=24),
    ScheduleInterval.WEEKLY: timedelta(hours=168),
}


class Schedule(BaseModel):
    """A single scheduled dobbe command."""

    name: str
    command: str
    args: str = ""
    interval: ScheduleInterval
    enabled: bool = True
    last_run: datetime | None = None
    created_at: datetime = Field(default_factory=datetime.now)


class RunStatus(str, Enum):
    """Outcome of a scheduled run."""

    SUCCESS = "success"
    FAILED = "failed"
    TIMEOUT = "timeout"


class RunLog(BaseModel):
    """Log entry for a single scheduled execution."""

    schedule_name: str
    started_at: datetime
    finished_at: datetime
    status: RunStatus
    duration_seconds: float
    exit_code: int = 0
    summary: str = ""
    error: str = ""
    command: str
    args: str


class CheckResult(BaseModel):
    """Result of a schedule check run."""

    checked_at: datetime = Field(default_factory=datetime.now)
    schedules_checked: int = 0
    schedules_run: int = 0
    results: list[RunLog] = Field(default_factory=list)
