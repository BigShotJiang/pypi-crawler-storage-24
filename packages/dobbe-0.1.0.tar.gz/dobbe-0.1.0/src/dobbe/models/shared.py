"""Shared enums used across multiple modules."""

from __future__ import annotations

from enum import Enum


class Severity(str, Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class AccessMode(str, Enum):
    LOCAL = "local"
    REMOTE = "remote"


class FixStatus(str, Enum):
    """Outcome of a fix attempt."""

    APPLIED = "applied"
    SKIPPED = "skipped"
    FAILED = "failed"


class VerifyCategory(str, Enum):
    """Category of an issue found during verification."""

    TEST_FAILURE = "test_failure"
    BREAKING_CHANGE = "breaking_change"
    LOCKFILE_INCONSISTENCY = "lockfile_inconsistency"
    DEPENDENCY_CONFLICT = "dependency_conflict"
    OTHER = "other"


class ReviewCategory(str, Enum):
    """Category of a concern found during PR review."""

    SECURITY = "security"
    TEST_COVERAGE = "test_coverage"
    BREAKING_CHANGE = "breaking_change"
    CODE_QUALITY = "code_quality"
    COMPLEXITY = "complexity"


SEVERITY_EMOJI: dict[Severity, str] = {
    Severity.CRITICAL: "\U0001f534",  # Red circle
    Severity.HIGH: "\U0001f7e0",  # Orange circle
    Severity.MEDIUM: "\U0001f7e1",  # Yellow circle
    Severity.LOW: "\u26aa",  # White circle
}
