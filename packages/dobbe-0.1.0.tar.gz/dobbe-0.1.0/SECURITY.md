# Security Policy

## Supported Versions

| Version | Supported |
|---------|-----------|
| 0.1.x   | Yes       |

## Reporting a Vulnerability

If you discover a security vulnerability in dobbe, please report it responsibly.

**Email**: nareshnavinash@gmail.com

Please include:
- Description of the vulnerability
- Steps to reproduce
- Potential impact

We will acknowledge your report within 48 hours and aim to release a fix within 7 days for critical issues.

## Scope

dobbe orchestrates Claude Code agents and interacts with GitHub APIs. Security concerns may include:
- Prompt injection via repository content
- Unintended code execution during the fix-verify loop
- Credential exposure in transcripts or logs
