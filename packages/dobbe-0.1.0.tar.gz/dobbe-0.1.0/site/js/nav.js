(function () {
  'use strict';

  var header = document.querySelector('header');
  var hamburger = document.getElementById('hamburger');
  var navLinks = document.getElementById('nav-links');

  // Sticky nav - add class when scrolled past 20px
  window.addEventListener('scroll', function () {
    if (header) header.classList.toggle('nav-scrolled', window.scrollY > 20);
  });

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      var target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  // Mobile hamburger toggle
  if (hamburger && navLinks) {
    hamburger.addEventListener('click', function () {
      hamburger.classList.toggle('active');
      navLinks.classList.toggle('active');
    });
    navLinks.querySelectorAll('a').forEach(function (link) {
      link.addEventListener('click', function () {
        hamburger.classList.remove('active');
        navLinks.classList.remove('active');
      });
    });
  }

  // Active section highlight via IntersectionObserver
  var sections = document.querySelectorAll('section[id]');
  if (sections.length && 'IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        var id = entry.target.getAttribute('id');
        var link = document.querySelector('.nav-links a[href="#' + id + '"]');
        if (link) link.classList.toggle('active', entry.isIntersecting);
      });
    }, { rootMargin: '-20% 0px -60% 0px' });
    sections.forEach(function (section) { observer.observe(section); });
  }
})();
