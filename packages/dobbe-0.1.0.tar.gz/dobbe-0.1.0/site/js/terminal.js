(function () {
  'use strict';

  var terminalOutput = document.getElementById('terminal-output');
  if (!terminalOutput) return;

  var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var hasPlayed = false;

  var sequence = [
    { text: '$ dobbe vuln resolve --repo nareshnavinash/api', type: 'typed', className: 'terminal-command', delay: 0 },
    { text: '', type: 'line', delay: 500 },
    { text: '  dobbe v0.1.0 \u2014 AI Security Engineer', type: 'line', className: 'term-dim', delay: 100 },
    { text: '', type: 'line', delay: 50 },
    { text: '  \u25cf Discovering MCP servers... GitHub \u2713  Slack \u2713', type: 'line', delay: 200 },
    { text: '  \u25cf Resolving repository... nareshnavinash/api (main)', type: 'line', delay: 200 },
    { text: '  \u25cf Creating fix branch... fix/dobbe-security-2026-03-21', type: 'line', delay: 200 },
    { text: '', type: 'line', delay: 400 },
    { text: '  \u250c\u2500 SCAN \u2014 Fetching Dependabot alerts \u2500\u2510', type: 'line', className: 'term-blue', delay: 100 },
    { text: '  Found 12 alerts. Triaging with AI...', type: 'line', delay: 300 },
    { text: '', type: 'line', delay: 100 },
    { text: '  #  Package          Severity   AI Triage', type: 'line', className: 'term-dim', delay: 100 },
    { text: '  1  lodash 4.17.20   Critical   Fix \u2014 in path', type: 'line', className: 'term-red', delay: 100 },
    { text: '  2  express 4.17.1   High       Fix \u2014 in path', type: 'line', className: 'term-yellow', delay: 100 },
    { text: '  3  semver 7.3.5     Medium     Skip \u2014 unused', type: 'line', className: 'term-dim', delay: 100 },
    { text: '', type: 'line', delay: 400 },
    { text: '  \u250c\u2500 FIX \u2014 Upgrading 2 dependencies \u2500\u2510', type: 'line', className: 'term-green', delay: 100 },
    { text: '  \u2713 lodash 4.17.20 \u2192 4.17.21', type: 'line', className: 'term-green', delay: 200 },
    { text: '  \u2713 express 4.17.1 \u2192 4.21.0', type: 'line', className: 'term-green', delay: 200 },
    { text: '', type: 'line', delay: 400 },
    { text: '  \u250c\u2500 VERIFY \u2014 Running tests (attempt 1/3) \u2500\u2510', type: 'line', className: 'term-yellow', delay: 100 },
    { text: '  \u2713 847 tests passed', type: 'line', className: 'term-green', delay: 300 },
    { text: '', type: 'line', delay: 400 },
    { text: '  \u250c\u2500 REPORT \u2014 Creating pull request \u2500\u2510', type: 'line', className: 'term-purple', delay: 100 },
    { text: '  \u2713 PR #142 opened: fix/dobbe-security-2026-03-21', type: 'line', className: 'term-green', delay: 200 },
    { text: '    https://github.com/nareshnavinash/api/pull/142', type: 'line', className: 'term-blue', delay: 100 },
  ];

  function wait(ms) {
    return new Promise(function (resolve) { setTimeout(resolve, ms); });
  }

  function createLine(className) {
    var div = document.createElement('div');
    if (className) div.className = className;
    terminalOutput.appendChild(div);
    return div;
  }

  function typeText(el, text, speed) {
    return new Promise(function (resolve) {
      var i = 0;
      (function tick() {
        if (i < text.length) {
          el.textContent += text[i++];
          setTimeout(tick, speed);
        } else {
          resolve();
        }
      })();
    });
  }

  function addCursor() {
    var cursor = document.createElement('span');
    cursor.className = 'terminal-cursor';
    cursor.textContent = '\u2588';
    terminalOutput.appendChild(cursor);
  }

  function showAllImmediate() {
    sequence.forEach(function (step) {
      var line = createLine(step.className);
      line.textContent = step.text;
    });
    addCursor();
  }

  async function playSequence() {
    for (var i = 0; i < sequence.length; i++) {
      var step = sequence[i];
      if (step.delay > 0) await wait(step.delay);
      var line = createLine(step.className);
      if (step.type === 'typed') {
        await typeText(line, step.text, 30);
      } else {
        line.textContent = step.text;
      }
    }
    addCursor();
  }

  function startAnimation() {
    if (hasPlayed) return;
    hasPlayed = true;
    if (prefersReducedMotion) {
      showAllImmediate();
    } else {
      playSequence();
    }
  }

  if ('IntersectionObserver' in window) {
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          observer.unobserve(terminalOutput);
          startAnimation();
        }
      });
    }, { threshold: 0.3 });
    observer.observe(terminalOutput);
  } else {
    startAnimation();
  }
})();
