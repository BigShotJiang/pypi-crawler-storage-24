"""UniFi Protect MCP Server."""
