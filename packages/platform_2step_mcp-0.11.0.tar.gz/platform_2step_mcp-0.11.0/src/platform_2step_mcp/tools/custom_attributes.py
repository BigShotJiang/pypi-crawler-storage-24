"""Custom attributes tools for MCP."""

import json
from typing import Any

from mcp.types import TextContent, Tool

from ..client import Platform2StepClient

CUSTOM_ATTRIBUTE_TOOLS: list[Tool] = [
    Tool(
        name="list_custom_attributes",
        description="List custom attribute definitions for a company. Returns attribute IDs, names, field types, and whether they are mandatory. Use before creating clients to discover required custom attributes.",
        inputSchema={
            "type": "object",
            "properties": {
                "company_id": {
                    "type": "integer",
                    "description": "Company ID",
                },
            },
            "required": ["company_id"],
            "additionalProperties": False,
        },
    ),
]


async def handle_custom_attribute_tool(
    name: str,
    arguments: dict[str, Any],
    client: Platform2StepClient,
) -> list[TextContent]:
    """Handle custom attribute tool calls."""
    if name == "list_custom_attributes":
        result = await client.list_custom_attributes(
            company_id=arguments["company_id"],
        )
        return [TextContent(type="text", text=json.dumps(result, indent=2))]

    raise ValueError(f"Unknown custom attribute tool: {name}")
