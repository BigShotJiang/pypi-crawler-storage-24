"""Tests for create_batch tool schema — location country/timezone exclusion."""

from platform_2step_mcp.tools.batches import BATCH_TOOLS


def _get_create_batch_tool():
    for tool in BATCH_TOOLS:
        if tool.name == "create_batch":
            return tool
    raise AssertionError("create_batch tool not found in BATCH_TOOLS")


def _get_payload_properties():
    tool = _get_create_batch_tool()
    return tool.inputSchema["properties"]["operations"]["items"]["properties"][
        "payload"
    ]["properties"]


class TestCreateBatchSchema:
    def test_payload_does_not_contain_country_id(self):
        props = _get_payload_properties()
        assert "country_id" not in props

    def test_payload_does_not_contain_timezone(self):
        props = _get_payload_properties()
        assert "timezone" not in props

    def test_description_mentions_auto_resolved(self):
        tool = _get_create_batch_tool()
        assert "auto-resolved" in tool.description.lower()

    def test_description_mentions_activate_deactivate(self):
        tool = _get_create_batch_tool()
        desc = tool.description.lower()
        assert "activate" in desc
        assert "deactivate" in desc
