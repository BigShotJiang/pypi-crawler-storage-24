"""Tests for custom attributes tools and client methods."""

import respx
from httpx import Response

from platform_2step_mcp.client import Platform2StepClient
from platform_2step_mcp.tools.custom_attributes import handle_custom_attribute_tool
from platform_2step_mcp.tools.batches import handle_batch_tool


class TestListCustomAttributesClient:
    """Tests for the client list_custom_attributes method."""

    async def test_list_custom_attributes_success(
        self,
        client: Platform2StepClient,
        mock_api: respx.MockRouter,
    ):
        sample_response = [
            {"id": 1, "name": "RUT", "field_type": "text", "mandatory": True},
            {"id": 2, "name": "Previsión", "field_type": "select", "mandatory": False},
        ]
        mock_api.get("/api/v1/custom_attributes").mock(
            return_value=Response(200, json=sample_response)
        )

        result = await client.list_custom_attributes(company_id=9479)

        assert result == sample_response
        assert len(result) == 2
        request = mock_api.calls.last.request
        assert "company_id=9479" in str(request.url)


class TestListCustomAttributesTool:
    """Tests for the list_custom_attributes tool handler."""

    async def test_list_custom_attributes_tool(
        self,
        client: Platform2StepClient,
        mock_api: respx.MockRouter,
    ):
        sample_response = [
            {"id": 1, "name": "RUT", "field_type": "text", "mandatory": True},
        ]
        mock_api.get("/api/v1/custom_attributes").mock(
            return_value=Response(200, json=sample_response)
        )

        result = await handle_custom_attribute_tool(
            "list_custom_attributes",
            {"company_id": 9479},
            client,
        )

        assert len(result) == 1
        assert "RUT" in result[0].text


class TestBatchPreviewMasking:
    """Tests for custom_attributes masking in batch preview."""

    async def test_batch_preview_masks_custom_attributes(
        self,
        client: Platform2StepClient,
        mock_api: respx.MockRouter,
    ):
        batch_response = {
            "batch_id": "batch-123",
            "status": "pending",
            "operations_count": 1,
            "expires_at": "2026-03-06T10:30:00Z",
            "confirmable": True,
            "operations": [
                {
                    "position": 0,
                    "confirmation_id": "op-1",
                    "operation": "create",
                    "resource": "client",
                    "status": "pending",
                    "preview": {
                        "first_name": "Jane",
                        "custom_attributes": [
                            {"id": 1, "value": "12345678-9"},
                            {"id": 2, "value": "Fonasa"},
                        ],
                    },
                }
            ],
        }
        mock_api.post("/api/v1/batches").mock(
            return_value=Response(202, json=batch_response)
        )

        result = await handle_batch_tool(
            "create_batch",
            {
                "company_id": 9479,
                "operations": [
                    {
                        "operation": "create",
                        "resource": "client",
                        "payload": {
                            "first_name": "Jane",
                            "custom_attributes": [
                                {"id": 1, "value": "12345678-9"},
                            ],
                        },
                    }
                ],
            },
            client,
        )

        assert len(result) == 1
        text = result[0].text
        assert "(+2 custom attributes)" in text
        assert "12345678-9" not in text
