"""Tests for configuration module."""

import pytest

from platform_2step_mcp.config import Settings


class TestSettingsDeviceFlow:
    """Tests for device flow configuration."""

    def test_device_flow_uses_bff_url_for_api(self):
        """Test that device flow mode uses BFF URL for API requests."""
        settings = Settings(PLATFORM_2STEPS_BFF_URL="https://bff.example.com")

        assert settings.api_url == "https://bff.example.com"
        assert settings.bff_url == "https://bff.example.com"

    def test_bff_url_required(self):
        """Test that BFF URL is required."""
        with pytest.raises(ValueError, match="PLATFORM_2STEPS_BFF_URL is required"):
            Settings()

    def test_api_url_raises_if_not_configured(self):
        """Test that api_url raises ValueError if BFF URL not set."""
        # Can't create Settings without BFF URL, so we test indirectly
        # by checking the validation error message
        with pytest.raises(ValueError, match="PLATFORM_2STEPS_BFF_URL is required"):
            Settings()


class TestSettingsPublicUrl:
    """Tests for public_url property."""

    def test_public_url_falls_back_to_api_url(self):
        """Without API_HOST_PUBLIC, public_url equals api_url."""
        settings = Settings(PLATFORM_2STEPS_BFF_URL="https://bff.example.com")
        assert settings.public_url == "https://bff.example.com"

    def test_public_url_bare_hostname(self):
        """Bare hostname gets https:// prepended."""
        settings = Settings(
            PLATFORM_2STEPS_BFF_URL="https://bff.example.com",
            API_HOST_PUBLIC="mcp.agendaprodev.com",
        )
        assert settings.public_url == "https://mcp.agendaprodev.com"

    def test_public_url_full_url_with_https(self):
        """Full URL with https:// is used as-is."""
        settings = Settings(
            PLATFORM_2STEPS_BFF_URL="https://bff.example.com",
            API_HOST_PUBLIC="https://mcp.agendaprodev.com",
        )
        assert settings.public_url == "https://mcp.agendaprodev.com"

    def test_public_url_full_url_with_http(self):
        """Full URL with http:// is used as-is."""
        settings = Settings(
            PLATFORM_2STEPS_BFF_URL="https://bff.example.com",
            API_HOST_PUBLIC="http://localhost:5000",
        )
        assert settings.public_url == "http://localhost:5000"

    def test_public_url_strips_trailing_slash(self):
        """Trailing slash is stripped."""
        settings = Settings(
            PLATFORM_2STEPS_BFF_URL="https://bff.example.com",
            API_HOST_PUBLIC="https://mcp.agendaprodev.com/",
        )
        assert settings.public_url == "https://mcp.agendaprodev.com"

    def test_public_url_bare_hostname_with_trailing_slash(self):
        """Bare hostname with trailing slash is normalized."""
        settings = Settings(
            PLATFORM_2STEPS_BFF_URL="https://bff.example.com",
            API_HOST_PUBLIC="mcp.agendaprodev.com/",
        )
        assert settings.public_url == "https://mcp.agendaprodev.com"


class TestSettingsLogging:
    """Tests for logging configuration."""

    def test_default_log_level(self):
        """Test default log level is INFO."""
        settings = Settings(PLATFORM_2STEPS_BFF_URL="https://bff.example.com")
        assert settings.LOG_LEVEL == "INFO"

    def test_custom_log_level(self):
        """Test custom log level."""
        settings = Settings(
            PLATFORM_2STEPS_BFF_URL="https://bff.example.com",
            LOG_LEVEL="DEBUG",
        )
        assert settings.LOG_LEVEL == "DEBUG"

    def test_debug_http_default_false(self):
        """Test DEBUG_HTTP defaults to False."""
        settings = Settings(PLATFORM_2STEPS_BFF_URL="https://bff.example.com")
        assert settings.DEBUG_HTTP is False

    def test_debug_http_can_be_enabled(self):
        """Test DEBUG_HTTP can be enabled."""
        settings = Settings(
            PLATFORM_2STEPS_BFF_URL="https://bff.example.com",
            DEBUG_HTTP=True,
        )
        assert settings.DEBUG_HTTP is True
