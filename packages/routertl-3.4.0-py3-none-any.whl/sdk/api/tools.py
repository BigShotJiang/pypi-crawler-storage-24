# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Public API for vendor tool resolution and project configuration.

Hook scripts and external consumers should import from this module
instead of using ``shutil.which()`` directly.  The functions here
respect ``hardware.tool_path`` from ``project.yml`` and probe
vendor-specific subdirectories before falling back to ``PATH``.

Usage in a pre-build hook script::

    from sdk.api.tools import resolve_tool_binary, load_project_config

    quartus = resolve_tool_binary("quartus_sh")
    config  = load_project_config()
    vendor  = get_hardware_config(config).get("vendor", "xilinx")
"""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Any

import yaml

# ── Project Configuration ─────────────────────────────────────


def load_project_config(project_yml: str | Path = "project.yml") -> dict[str, Any]:
    """Load and return the ``project.yml`` configuration as a dict.

    Parameters
    ----------
    project_yml:
        Path to the project YAML file.  Defaults to ``project.yml``
        in the current working directory.

    Returns
    -------
    dict
        Parsed configuration, or ``{}`` if the file is missing or
        contains invalid YAML.
    """
    p = Path(project_yml)
    if not p.exists():
        return {}
    try:
        with open(p, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    except yaml.YAMLError:
        return {}
    return data if isinstance(data, dict) else {}


def get_hardware_config(
    config: dict[str, Any] | None = None,
    project_yml: str | Path = "project.yml",
) -> dict[str, Any]:
    """Return the ``hardware`` section from the project configuration.

    Parameters
    ----------
    config:
        Pre-loaded config dict.  If ``None``, loads from *project_yml*.
    project_yml:
        Path to ``project.yml`` (used only when *config* is ``None``).

    Returns
    -------
    dict
        The ``hardware`` section, or ``{}`` if absent / malformed.
    """
    if config is None:
        config = load_project_config(project_yml)
    hw = config.get("hardware") or {}
    return hw if isinstance(hw, dict) else {}


# ── Tool Resolution ───────────────────────────────────────────


def resolve_tool_path(
    config: dict[str, Any] | None = None,
    project_yml: str | Path = "project.yml",
) -> str | None:
    """Read ``hardware.tool_path`` from the project configuration.

    Parameters
    ----------
    config:
        Pre-loaded config dict.  If ``None``, loads from *project_yml*.
    project_yml:
        Path to ``project.yml`` (used only when *config* is ``None``).

    Returns
    -------
    str or None
        The raw ``tool_path`` string, or ``None`` if not configured.
    """
    hw = get_hardware_config(config, project_yml)
    return hw.get("tool_path")


def resolve_tool_binary(
    binary_name: str,
    config: dict[str, Any] | None = None,
    project_yml: str | Path = "project.yml",
) -> str | None:
    """Resolve a vendor tool binary, respecting ``hardware.tool_path``.

    Resolution order:

    1. Check ``hardware.tool_path`` from ``project.yml``.  If set,
       probe the path directly and under vendor-specific subdirectories
       (``bin/``, ``quartus/bin/``, ``Vivado/bin/``, etc.).
    2. Fall back to ``shutil.which()`` (whatever is on ``PATH``).

    Parameters
    ----------
    binary_name:
        Executable name, e.g. ``"quartus_sh"``, ``"vivado"``.
    config:
        Pre-loaded config dict.  If ``None``, loads from *project_yml*.
    project_yml:
        Path to ``project.yml`` (used only when *config* is ``None``).

    Returns
    -------
    str or None
        Absolute path to the binary, or ``None`` if not found.
    """
    tool_path = resolve_tool_path(config, project_yml)
    if tool_path:
        tp = Path(tool_path)
        # Direct: tool_path points to the bin dir itself
        candidate = tp / binary_name
        if candidate.exists() and candidate.is_file():
            return str(candidate)
        # One level down: tool_path is the install root
        for sub in (
            "bin",
            "quartus/bin",
            "Vivado/bin",
            "Designer/bin",
            "Designer/bin64",
        ):
            candidate = tp / sub / binary_name
            if candidate.exists() and candidate.is_file():
                return str(candidate)

    # Fallback: shutil.which (whatever is on PATH)
    return shutil.which(binary_name)


def get_project_root(start: str | Path = ".") -> Path | None:
    """Walk up from *start* to find the project root (directory containing ``project.yml``).

    Parameters
    ----------
    start:
        Directory to start searching from.  Defaults to CWD.

    Returns
    -------
    Path or None
        Absolute path to the project root, or ``None`` if no
        ``project.yml`` is found up to the filesystem root.
    """
    current = Path(start).resolve()
    while True:
        if (current / "project.yml").exists():
            return current
        parent = current.parent
        if parent == current:
            return None
        current = parent
