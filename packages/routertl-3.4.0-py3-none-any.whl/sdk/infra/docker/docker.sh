#!/usr/bin/env bash
# RouteRTL SDK Docker Environment Orchestrator
# Usage: docker.sh <command> [environment]
#   command: help | install | shell | run
#   environment: sim | vivado (default: sim)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SDK_ROOT="$(dirname "$(dirname "$(dirname "$SCRIPT_DIR")")")"

# ── Detect or provision Docker Compose ────────────────────────
# Strategy:
#   1. System 'docker compose' v2 plugin  (fastest, no download)
#   2. SDK-local binary at sdk/infra/docker/bin/docker-compose  (cached)
#   3. Auto-download the v2 binary on first use  (lazy provision)
#
# The legacy docker-compose v1 binary is incompatible with docker-py >= 7.0
# and is NOT supported.

LOCAL_COMPOSE_DIR="$SDK_ROOT/sdk/infra/docker/bin"
LOCAL_COMPOSE_BIN="$LOCAL_COMPOSE_DIR/docker-compose"
COMPOSE_VERSION="${COMPOSE_VERSION:-v2.32.4}"

_ensure_compose() {
    # Tier 1: system plugin
    if docker compose version &>/dev/null; then
        COMPOSE_CMD="docker compose"
        return
    fi

    # Tier 2: cached SDK-local binary
    if [ -x "$LOCAL_COMPOSE_BIN" ]; then
        COMPOSE_CMD="$LOCAL_COMPOSE_BIN"
        return
    fi

    # Tier 3: auto-download
    echo "📦 Docker Compose v2 not found — downloading $COMPOSE_VERSION..."
    mkdir -p "$LOCAL_COMPOSE_DIR"

    local arch
    arch="$(uname -m)"
    case "$arch" in
        x86_64)  arch="x86_64" ;;
        aarch64) arch="aarch64" ;;
        *)
            echo "❌ Unsupported architecture: $arch"
            exit 1
            ;;
    esac

    local url="https://github.com/docker/compose/releases/download/${COMPOSE_VERSION}/docker-compose-linux-${arch}"
    if ! curl -fsSL "$url" -o "$LOCAL_COMPOSE_BIN"; then
        echo "❌ Failed to download Docker Compose from:"
        echo "   $url"
        echo ""
        echo "   Install manually:"
        echo "     mkdir -p ~/.docker/cli-plugins"
        echo "     curl -SL $url -o ~/.docker/cli-plugins/docker-compose"
        echo "     chmod +x ~/.docker/cli-plugins/docker-compose"
        exit 1
    fi

    chmod +x "$LOCAL_COMPOSE_BIN"
    echo "✅ Docker Compose $COMPOSE_VERSION installed to $LOCAL_COMPOSE_BIN"
    COMPOSE_CMD="$LOCAL_COMPOSE_BIN"
}

_ensure_compose

# Default environment
DOCKER_ENV="${2:-sim}"

# Docker compose file path
COMPOSE_DIR="$SDK_ROOT/sdk/infra/docker"

# Resolve service name based on environment
case "$DOCKER_ENV" in
    sim)
        SERVICE_NAME="sim"
        WORK_USER="runner"
        ;;
    vivado)
        SERVICE_NAME="vivado"
        WORK_USER="vivado"
        ;;
    questa)
        SERVICE_NAME="questa"
        WORK_USER="runner"
        ;;
    riviera)
        SERVICE_NAME="riviera"
        WORK_USER="runner"
        ;;
    quartus)
        SERVICE_NAME="quartus"
        WORK_USER="runner"
        ;;
    radiant)
        SERVICE_NAME="radiant"
        WORK_USER="runner"
        ;;
    libero)
        SERVICE_NAME="libero"
        WORK_USER="runner"
        ;;
    buildroot)
        SERVICE_NAME="buildroot"
        WORK_USER="runner"
        ;;
    *)
        echo "❌ Unknown environment: $DOCKER_ENV"
        echo "   Valid options: sim, vivado, questa, riviera, quartus, radiant, libero, buildroot"
        exit 1
        ;;
esac

COMPOSE_FILE="$COMPOSE_DIR/docker-compose.$SERVICE_NAME.yml"


# Resolve the client project root.
# When invoked from the SDK (vendor/routertl), the client root is two levels up
# from the SDK root (i.e. the repo that contains vendor/routertl as a submodule).
# If PROJECT_ROOT is already set in the environment, honour it.
if [ -z "${PROJECT_ROOT:-}" ]; then
    # Walk up from SDK_ROOT to find the client project root.
    # The client root is the first ancestor that contains a project.yml
    # OR the first ancestor that is NOT inside vendor/.
    _candidate="$(dirname "$SDK_ROOT")"   # e.g. <client>/vendor
    _candidate="$(dirname "$_candidate")" # e.g. <client>
    if [ -f "$_candidate/project.yml" ]; then
        PROJECT_ROOT="$_candidate"
    elif [ -f "$SDK_ROOT/project.yml" ]; then
        # Fallback: SDK itself has a project.yml (standalone SDK dev mode)
        PROJECT_ROOT="$SDK_ROOT"
    else
        # Last resort: use caller's working directory
        PROJECT_ROOT="$(pwd)"
    fi
fi
export PROJECT_ROOT

# Point docker-compose at the project root's .env file.
# rr docker config/setup writes QUARTUS_INSTALLER_PATH, LM_LICENSE_FILE, etc.
# to PROJECT_ROOT/.env, but docker-compose reads .env from the working directory
# by default, which may not be the project root.
ENV_FILE_FLAG=""
if [ -f "$PROJECT_ROOT/.env" ]; then
    ENV_FILE_FLAG="--env-file $PROJECT_ROOT/.env"
    # Source .env so shell variables are available for MAC override detection.
    # Only export KEY=VALUE lines; skip comments and blank lines.
    set -a
    # shellcheck disable=SC1090
    source <(grep -E '^[A-Z_][A-Z0-9_]*=' "$PROJECT_ROOT/.env" 2>/dev/null || true)
    set +a
fi

# ── Edition-Aware Volume Selection (Quartus) ──────────────────
# Volume resolution priority:
#   1. QUARTUS_INSTALL_DIR  — per-tool bind-mount path (highest)
#   2. EDA_INSTALL_DIR      — general base path + edition subdir
#   3. QUARTUS_VOLUME_NAME  — explicit Docker named volume
#   4. Default              — routertl_quartus_opt (backward compat)
#
# Edition is read from project.yml hardware.edition (pro|standard|lite).
# Naming: routertl_quartus_pro_opt, routertl_quartus_std_opt
#
# Must run AFTER PROJECT_ROOT resolution and .env sourcing so that
# $PROJECT_ROOT, $EDA_INSTALL_DIR, $QUARTUS_INSTALL_DIR are available.
if [ "$DOCKER_ENV" = "quartus" ]; then
    # Detect edition from project.yml
    _edition=""
    if [ -f "$PROJECT_ROOT/project.yml" ] 2>/dev/null; then
        _edition=$(python3 -c "
import yaml, sys
with open('$PROJECT_ROOT/project.yml') as f:
    cfg = yaml.safe_load(f) or {}
hw = cfg.get('hardware') or {}
print((hw.get('edition') or '').lower().strip())
" 2>/dev/null || true)
    fi

    # Map edition to volume name (if not already overridden)
    if [ -z "${QUARTUS_VOLUME_NAME:-}" ]; then
        case "$_edition" in
            pro)      QUARTUS_VOLUME_NAME="routertl_quartus_pro_opt" ;;
            standard) QUARTUS_VOLUME_NAME="routertl_quartus_std_opt" ;;
            lite)     QUARTUS_VOLUME_NAME="routertl_quartus_lite_opt" ;;
            *)        QUARTUS_VOLUME_NAME="routertl_quartus_opt" ;;
        esac
    fi
    export QUARTUS_VOLUME_NAME

    # Bind-mount override: per-tool > general base path > (none)
    _install_dir="${QUARTUS_INSTALL_DIR:-}"
    if [ -z "$_install_dir" ] && [ -n "${EDA_INSTALL_DIR:-}" ]; then
        # Derive subdir from edition
        case "$_edition" in
            pro)      _install_dir="$EDA_INSTALL_DIR/quartus_pro" ;;
            standard) _install_dir="$EDA_INSTALL_DIR/quartus_std" ;;
            lite)     _install_dir="$EDA_INSTALL_DIR/quartus_lite" ;;
            *)        _install_dir="$EDA_INSTALL_DIR/quartus" ;;
        esac
    fi

    if [ -n "$_install_dir" ]; then
        # Ensure directory exists for bind mount
        mkdir -p "$_install_dir"
        export QUARTUS_INSTALL_DIR="$_install_dir"
        echo "📂 Quartus install dir: $_install_dir (bind mount)"
    fi

    [ -n "$_edition" ] && echo "📋 Quartus edition: $_edition (volume: $QUARTUS_VOLUME_NAME)"
    export QUARTUS_EDITION="${_edition}"
fi

# ── Volume Selection (Radiant) ────────────────────────────────
# Volume resolution priority (mirrors Quartus pattern):
#   1. RADIANT_INSTALL_DIR  — per-tool bind-mount path (highest)
#   2. EDA_INSTALL_DIR      — general base path + radiant subdir
#   3. RADIANT_VOLUME_NAME  — explicit Docker named volume
#   4. Default              — routertl_radiant_opt (backward compat)
if [ "$DOCKER_ENV" = "radiant" ]; then
    if [ -z "${RADIANT_VOLUME_NAME:-}" ]; then
        RADIANT_VOLUME_NAME="routertl_radiant_opt"
    fi
    export RADIANT_VOLUME_NAME

    # Bind-mount override: per-tool > general base path > (none)
    _install_dir="${RADIANT_INSTALL_DIR:-}"
    if [ -z "$_install_dir" ] && [ -n "${EDA_INSTALL_DIR:-}" ]; then
        _install_dir="$EDA_INSTALL_DIR/radiant"
    fi

    if [ -n "$_install_dir" ]; then
        # Ensure directory exists for bind mount
        mkdir -p "$_install_dir"
        export RADIANT_INSTALL_DIR="$_install_dir"
        echo "📂 Radiant install dir: $_install_dir (bind mount)"
    fi

    echo "📋 Radiant volume: $RADIANT_VOLUME_NAME"
fi

# ── Volume Selection (Libero) ─────────────────────────────────
# Volume resolution priority (mirrors Quartus/Radiant pattern):
#   1. LIBERO_INSTALL_DIR    — per-tool bind-mount path (highest)
#   2. EDA_INSTALL_DIR       — general base path + libero subdir
#   3. LIBERO_VOLUME_NAME    — explicit Docker named volume
#   4. Default               — routertl_libero_opt (backward compat)
if [ "$DOCKER_ENV" = "libero" ]; then
    if [ -z "${LIBERO_VOLUME_NAME:-}" ]; then
        LIBERO_VOLUME_NAME="routertl_libero_opt"
    fi
    export LIBERO_VOLUME_NAME

    # Bind-mount override: per-tool > general base path > (none)
    _install_dir="${LIBERO_INSTALL_DIR:-}"
    if [ -z "$_install_dir" ] && [ -n "${EDA_INSTALL_DIR:-}" ]; then
        _install_dir="$EDA_INSTALL_DIR/libero"
    fi

    if [ -n "$_install_dir" ]; then
        # Ensure directory exists for bind mount
        mkdir -p "$_install_dir"
        export LIBERO_INSTALL_DIR="$_install_dir"
        echo "📂 Libero install dir: $_install_dir (bind mount)"
    fi

    echo "📋 Libero volume: $LIBERO_VOLUME_NAME"
fi

# ── Volume Selection (Vivado) ─────────────────────────────────
# Volume resolution priority (mirrors Quartus/Radiant pattern):
#   1. VIVADO_INSTALL_DIR   — per-tool bind-mount path (highest)
#   2. EDA_INSTALL_DIR      — general base path + vivado subdir
#   3. VIVADO_VOLUME_NAME   — explicit Docker named volume
#   4. Default              — routertl_vivado_opt (backward compat)
if [ "$DOCKER_ENV" = "vivado" ]; then
    if [ -z "${VIVADO_VOLUME_NAME:-}" ]; then
        VIVADO_VOLUME_NAME="routertl_vivado_opt"
    fi
    export VIVADO_VOLUME_NAME

    # Bind-mount override: per-tool > general base path > (none)
    _install_dir="${VIVADO_INSTALL_DIR:-}"
    if [ -z "$_install_dir" ] && [ -n "${EDA_INSTALL_DIR:-}" ]; then
        _install_dir="$EDA_INSTALL_DIR/vivado"
    fi

    if [ -n "$_install_dir" ]; then
        # Ensure directory exists for bind mount
        mkdir -p "$_install_dir"
        export VIVADO_INSTALL_DIR="$_install_dir"
        echo "📂 Vivado install dir: $_install_dir (bind mount)"
    fi

    echo "📋 Vivado volume: $VIVADO_VOLUME_NAME"
fi

# ── Node-Locked License: MAC Address Override ──────────────────
# If EDA_MAC_ADDRESS_OVERRIDE is set (via 'rr docker setup'), layer
# the MAC override compose file.  This replaces network_mode: host
# with bridge networking + spoofed MAC address so node-locked
# FlexLM licenses validate correctly inside containers.
#
# ⚠️  Bridge networking routes through Docker NAT.  VPN-routed
#    license servers typically remain reachable, but if your VPN
#    blocks NAT traffic, the server will be unreachable.
MAC_COMPOSE_FILE=""
if [ -n "${EDA_MAC_ADDRESS_OVERRIDE:-}" ]; then
    # Patch the compose file to inject MAC address for the target service.
    # Why not simpler approaches:
    #   - Top-level 'mac_address:' → deprecated, ignored by Docker Engine 25.0+
    #   - Overlay YAML with 'networks:' → conflicts with base 'network_mode: host'
    #   - 'docker compose run --mac-address' → flag doesn't exist on compose run
    # So we patch the YAML: remove network_mode, add networks.default.mac_address.
    MAC_COMPOSE_FILE=$(mktemp "${COMPOSE_DIR}/rr-mac-compose-XXXXXX.yml")
    python3 -c "
import yaml, sys
with open('${COMPOSE_FILE}') as f:
    cfg = yaml.safe_load(f)
svc = cfg.get('services', {}).get('${SERVICE_NAME}', {})
svc.pop('network_mode', None)
svc.setdefault('networks', {})['default'] = {
    'mac_address': '${EDA_MAC_ADDRESS_OVERRIDE}'
}
yaml.dump(cfg, sys.stdout, default_flow_style=False)
" > "$MAC_COMPOSE_FILE"
    # Replace COMPOSE_FILE so all commands use the patched version
    COMPOSE_FILE="$MAC_COMPOSE_FILE"
    echo "🔑 MAC override active: $EDA_MAC_ADDRESS_OVERRIDE"
    trap 'rm -f "$MAC_COMPOSE_FILE"' EXIT
fi

show_help() {
    cat <<EOF
🐳 RouteRTL Docker Environment

Usage (CLI):
  routertl docker install <env>              Install the Docker image
  routertl docker shell <env>              Start interactive shell
  routertl docker run <env> "<command>"    Run a command in container
  routertl docker add-device <env>         Install device packages (.qdz)
  routertl docker status                   Show volumes, images, containers
  routertl docker uninstall <env>          Remove volume and/or image

Usage (Make — equivalent):
  make docker-build [DOCKER_ENV=<env>]     Build the Docker image
  make docker-shell [DOCKER_ENV=<env>]     Start interactive shell
  make docker-run CMD="..." [DOCKER_ENV=<env>]   Run a command in container

Environments:
  sim        Open-source simulators (NVC 1.18.2, Verilator 5.036, GHDL, Cocotb 2.0.1)
  vivado     Extends sim with Xilinx Vivado support (requires local installer)
  quartus    Altera Quartus Prime with unattended installation (requires sim image)
  radiant    Lattice Radiant with unattended installation (requires sim image)
  questa     Siemens Questa with unattended installation (requires sim image)
  riviera    Aldec Riviera-PRO with unattended installation (requires sim image)
  libero     Microchip Libero SoC with unattended installation (requires sim image)
  buildroot  Embedded Linux cross-compilation pipeline (ARM/AArch64, bootgen)

⚠️  Image Dependencies:
  quartus, radiant, questa, riviera, and libero images extend the sim image.
  You MUST install sim first:  routertl docker install sim

Device Packages:
  After installing Quartus, add device families via .qdz files:
    routertl docker add-device quartus
    routertl eda add-device quartus          (native — no Docker needed)
  .qdz files must be in your QUARTUS_INSTALLER_PATH directory.

Storage Options:
  Docker named volume  — default, managed by Docker (rr docker status shows it)
  Bind mount           — set QUARTUS_INSTALL_DIR in .env to a host path
                         (e.g. /mnt/d/eda_volumes/quartus_std)

Examples:
  routertl docker shell sim                       # Enter sim container
  routertl docker shell buildroot                 # Enter buildroot container
  routertl docker shell vivado                    # Enter Vivado container
  routertl docker install sim                     # Install base simulation image
  routertl docker install quartus                 # Install Quartus image (requires sim)
  routertl docker run sim "routertl sim --all"    # Run simulation in container

The container mounts your project directory, creating a mirrored
development environment with all SDK tools available.

Node-Locked Licenses:
  If your FlexLM license is locked to a specific MAC address,
  set EDA_MAC_ADDRESS_OVERRIDE in .env (via 'rr docker setup').
  This automatically switches containers from host networking
  to bridge + MAC spoofing so the license validates correctly.

  Find your host MAC:
    Windows:  Get-NetAdapter | Select Name, MacAddress
    Linux:    ip link show | grep ether
EOF
}

do_build() {
    echo "🔨 Building $DOCKER_ENV Docker image..."

    # Run the interactive setup wizard for Heavy EDA WSL optimization
    if [ "$DOCKER_ENV" = "quartus" ] || [ "$DOCKER_ENV" = "riviera" ]; then
        if [ -x "$COMPOSE_DIR/wsl_setup_wizard.sh" ]; then
            "$COMPOSE_DIR/wsl_setup_wizard.sh"
        fi
    fi

    # Pass --project-directory so docker compose resolves 'context: .' and
    # 'dockerfile: Dockerfile.*' relative to the SDK docker dir, not CWD.
    # In pip mode CWD is the client project dir and the Dockerfiles are not
    # there, so without this the build fails with 'Dockerfile.sim not found'.
    $COMPOSE_CMD $ENV_FILE_FLAG --project-directory "$COMPOSE_DIR" \
        -f "$COMPOSE_FILE" --profile "$DOCKER_ENV" build
    echo "✅ Image built successfully"
}

do_shell() {
    echo "🚀 Starting $DOCKER_ENV container..."
    echo "   Project root: $PROJECT_ROOT"

    # Detect deployment mode:
    #   Submodule mode — vendor/routertl/ is present (SDK in-tree)
    #   Pip mode       — no vendor dir; SDK installed via pip on the host
    #
    # For pip mode we inject a `pip install --upgrade routertl` init step.
    # This is needed for images built before pip-mode support was added to
    # the Dockerfile (where the baked-in /usr/local/bin/rr wrapper only
    # handled the submodule path).  The upgrade overwrites the stale wrapper
    # with the pip console_script entry point, making `rr` work correctly
    # without requiring a full image rebuild.
    _INIT_CMD=""
    if [ ! -d "$PROJECT_ROOT/vendor/routertl" ]; then
        echo "📦 Pip mode detected — upgrading routertl in container (first-time ~10s)..."
        _INIT_CMD="pip install --upgrade --quiet routertl 2>&1 | tail -1 && "
    fi

    $COMPOSE_CMD -f "$COMPOSE_FILE" $ENV_FILE_FLAG --profile "$DOCKER_ENV" run --rm \
        -v "$PROJECT_ROOT:/home/$WORK_USER/work" \
        -w "/home/$WORK_USER/work" \
        "$SERVICE_NAME" bash -c "${_INIT_CMD}exec bash --login"
}

do_run() {
    local cmd="${3:-}"
    if [[ -z "$cmd" ]]; then
        echo "❌ No command specified. Usage: docker.sh run \"<command>\" [env]"
        exit 1
    fi

    echo "🚀 Running in $DOCKER_ENV container: $cmd"
    $COMPOSE_CMD -f "$COMPOSE_FILE" $ENV_FILE_FLAG --profile "$DOCKER_ENV" run --rm \
        -v "$PROJECT_ROOT:/home/$WORK_USER/work" \
        -w "/home/$WORK_USER/work" \
        "$SERVICE_NAME" bash -c "$cmd"
}

# Main dispatch
case "${1:-help}" in
    help)
        show_help
        ;;
    install|build)
        do_build
        ;;
    shell)
        do_shell
        ;;
    run)
        do_run "$@"
        ;;
    *)
        echo "❌ Unknown command: $1"
        show_help
        exit 1
        ;;
esac
