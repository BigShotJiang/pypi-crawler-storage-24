#!/usr/bin/env bash
# install_questa.sh: Automated entrypoint for RouteRTL Questa container
# This script checks if Questa is installed in the persistent volume.
# If not, it natively executes the unattended installer from the mounted installers directory.

set -euo pipefail

# Source the shared progress indicator
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/install_progress.sh"

# Define target installation directories on the persistent volume
QUESTA_OPT_DIR="/opt/questa"
INSTALLERS_DIR="/installers"

echo "Checking Questa installation in ${QUESTA_OPT_DIR}..."

# Ensure the persistent volume directory exists and is writable by the runner user
mkdir -p "${QUESTA_OPT_DIR}"
chown -R runner:runner "${QUESTA_OPT_DIR}"

# -------------------------------------------------------------
# 1. Questa Installation
# -------------------------------------------------------------
if [ ! -d "${QUESTA_OPT_DIR}/bin" ]; then
    echo "Questa not found. Looking for installer..."

    # ── Validate the /installers mount ──────────────────────────
    if [ -f "${INSTALLERS_DIR}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "❌  Questa_INSTALLER_PATH points to a FILE, not a DIRECTORY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  It must point to the DIRECTORY containing the installer:"
        echo "    Questa_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads  ← correct"
        echo "    Questa_INSTALLER_PATH=/path/to/Questa.bin              ← wrong"
        echo ""
        echo "  Fix your .env file and re-run: routertl docker shell questa"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Questa..."
        # Fall through to handover
    fi

    # Example: Looking for a standard Siemens install script or tarball
    if ls ${INSTALLERS_DIR}/Questa*.bin 1> /dev/null 2>&1; then
        QUESTA_INSTALLER=$(ls ${INSTALLERS_DIR}/Questa*.bin | head -n 1)
        echo "Found Questa installer: ${QUESTA_INSTALLER}"
        run_with_progress "Questa Unattended Installation" "${QUESTA_OPT_DIR}" \
            bash "${QUESTA_INSTALLER}" --mode unattended --prefix "${QUESTA_OPT_DIR}" --agree-license yes
    elif [ -f "${INSTALLERS_DIR}/install.linux64" ]; then
        echo "Found Siemens batch installer."
        run_with_progress "Questa Batch Installation" "${QUESTA_OPT_DIR}" \
            "${INSTALLERS_DIR}/install.linux64" -batch -dest "${QUESTA_OPT_DIR}" -all
    else
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  No Questa installer found!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  Looked in: ${INSTALLERS_DIR}/"
        echo "  Expected:  Questa*.bin or install.linux64"
        echo ""
        echo "  Contents of ${INSTALLERS_DIR}/:"
        ls -la "${INSTALLERS_DIR}/" 2>/dev/null || echo "    (directory does not exist or is empty)"
        echo ""
        echo "  To fix this, set Questa_INSTALLER_PATH in your .env file:"
        echo ""
        echo "    # .env (in your project root)"
        echo "    Questa_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads"
        echo ""
        echo "  ⚠️  Must be the DIRECTORY, not the .bin file itself!"
        echo "  Then re-run: routertl docker shell questa"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Questa..."
    fi
else
    echo "✅ Questa is already installed."
fi

# -------------------------------------------------------------
# 2. Volume Version Stamp
# -------------------------------------------------------------
# Stamp the volume on fresh installs so future image rebuilds can
# detect a stale volume from an incompatible image generation.
VOLUME_STAMP="${QUESTA_OPT_DIR}/.routertl_image_id"
CURRENT_IMAGE_ID="$(cat /etc/hostname 2>/dev/null || echo unknown)"
if [ -d "${QUESTA_OPT_DIR}/bin" ]; then
    if [ -f "${VOLUME_STAMP}" ]; then
        PREV_ID="$(cat "${VOLUME_STAMP}")"
        if [ "${PREV_ID}" != "${CURRENT_IMAGE_ID}" ]; then
            echo ""
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "⚠️  Questa volume was created by a different image"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
            echo "  Previous: ${PREV_ID}"
            echo "  Current:  ${CURRENT_IMAGE_ID}"
            echo ""
            echo "  If Questa fails, remove the stale volume:"
            echo "    routertl docker uninstall questa --volume"
            echo "  Then re-run: routertl docker shell questa"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
        fi
    fi
    echo "${CURRENT_IMAGE_ID}" > "${VOLUME_STAMP}" 2>/dev/null || true
fi

# -------------------------------------------------------------
# 3. Ensure CLI aliases exist
# -------------------------------------------------------------
# Create rr symlink if missing (covers images built before it was
# added to Dockerfile.sim, or system PATH reset by su/PAM).
if command -v routertl >/dev/null 2>&1 && ! command -v rr >/dev/null 2>&1; then
    ROUTERTL_PATH="$(command -v routertl)"
    ln -sf "${ROUTERTL_PATH}" "$(dirname "${ROUTERTL_PATH}")/rr" 2>/dev/null || true
fi

# Execute the main command passed to the container (e.g., bash)
echo "Handing over to: $*"
# Drop privileges to 'runner' for simulation.
# IMPORTANT: env vars MUST be set inside the -c string because
# 'su' goes through PAM which resets the environment.
# NOTE: $PATH here expands to ROOT's PATH at parse time — this is
# intentional!  PAM resets runner's PATH to empty, so we bake in the
# full system PATH (/usr/bin, /bin, etc.) from the root context.
# NOTE: do NOT redirect stderr (2>/dev/null) — bash writes PS1 to stderr!
exec su -s /bin/bash runner -c "
  export PATH='/opt/questa/bin:/usr/local/bin:$PATH'
  export SIM=questa
  cd /home/runner/work
  echo \"🔧 Active simulator: \$SIM\"
  exec $*"
