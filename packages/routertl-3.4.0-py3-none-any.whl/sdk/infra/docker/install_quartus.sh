#!/usr/bin/env bash
# install_quartus.sh: Automated entrypoint for RouteRTL Quartus container
# This script checks if Quartus is installed in the persistent volume.
# If not, it natively executes the unattended setup script from the mounted installers directory.
# Quartus bundles Questa Intel FPGA Edition — this script discovers and injects its PATH.

set -euo pipefail

# Source the shared progress indicator
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/install_progress.sh"

# Define target installation directories on the persistent volume
QUARTUS_OPT_DIR="/opt/altera"
INSTALLERS_DIR="/installers"
# The host-side path is passed via docker-compose for better error messages.
HOST_PATH="${QUARTUS_INSTALLER_PATH_HOST:-${INSTALLERS_DIR}}"

echo "Checking Altera Quartus installation in ${QUARTUS_OPT_DIR}..."

# Ensure the persistent volume directory exists and is writable by the runner user
mkdir -p "${QUARTUS_OPT_DIR}"
chown -R runner:runner "${QUARTUS_OPT_DIR}"

# =============================================================
# Helper: select_installer
# =============================================================
# When multiple .tar files exist, present an interactive menu
# or use QUARTUS_INSTALLER_INDEX for CI/CD headless selection.
#
# Arguments: array of tar file paths
# Returns: sets TAR_FILE to the selected path
# =============================================================
select_installer() {
    local -a tars=("$@")
    local count=${#tars[@]}

    if [ "$count" -eq 1 ]; then
        TAR_FILE="${tars[0]}"
        return
    fi

    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📦  Found ${count} Quartus installer archives"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    local i=1
    for f in "${tars[@]}"; do
        local fname
        fname=$(basename "$f")
        local fsize
        fsize=$(du -h "$f" 2>/dev/null | cut -f1)
        printf "  %d) %-50s  (%s)\n" "$i" "$fname" "$fsize"
        i=$((i + 1))
    done
    echo ""

    # CI/CD headless: use QUARTUS_INSTALLER_INDEX (1-based)
    if [ -n "${QUARTUS_INSTALLER_INDEX:-}" ]; then
        local idx=$((QUARTUS_INSTALLER_INDEX))
        if [ "$idx" -ge 1 ] && [ "$idx" -le "$count" ]; then
            TAR_FILE="${tars[$((idx - 1))]}"
            echo "  ▸ Using installer #${idx} (QUARTUS_INSTALLER_INDEX=${QUARTUS_INSTALLER_INDEX})"
        else
            echo "  ❌ QUARTUS_INSTALLER_INDEX=${QUARTUS_INSTALLER_INDEX} is out of range [1-${count}]"
            echo "     Falling back to installer #1"
            TAR_FILE="${tars[0]}"
        fi
        echo ""
        return
    fi

    # Interactive: show menu if stdin is a terminal
    if [ -t 0 ]; then
        local choice
        while true; do
            printf "  Select installer [1-%d]: " "$count"
            read -r choice </dev/tty
            if [[ "$choice" =~ ^[0-9]+$ ]] && [ "$choice" -ge 1 ] && [ "$choice" -le "$count" ]; then
                TAR_FILE="${tars[$((choice - 1))]}"
                echo ""
                break
            fi
            echo "  ⚠️  Invalid selection. Enter a number between 1 and ${count}."
        done
    else
        # Non-interactive, no index set: use first
        echo "  ▸ Non-interactive mode — using first installer"
        TAR_FILE="${tars[0]}"
        echo ""
    fi
}

# =============================================================
# Helper: qdz_inventory
# =============================================================
# Scans the installer directory for .qdz device files and prints
# a summary BEFORE installation begins so the user knows which
# device families will be available.
#
# Arguments: $1 = directory to scan for .qdz files
# =============================================================
qdz_inventory() {
    local scan_dir="$1"
    local -a qdz_files=()

    # Collect .qdz files from the directory (non-recursive)
    while IFS= read -r -d '' f; do
        qdz_files+=("$f")
    done < <(find "$scan_dir" -maxdepth 1 -name '*.qdz' -print0 2>/dev/null)

    echo ""
    echo "┌──────────────────────────────────────────────────────────┐"
    echo "│  📦  Device Packages (.qdz) Detected                    │"
    echo "├──────────────────────────────────────────────────────────┤"

    if [ ${#qdz_files[@]} -eq 0 ]; then
        echo "│  ⚠️  No .qdz files found                               │"
        echo "│  Only the base Quartus toolchain will be installed.     │"
        echo "│                                                        │"
        echo "│  To add device families, download .qdz files from:     │"
        echo "│  https://www.intel.com/content/www/us/en/products/      │"
        echo "│  details/fpga/ and place them in:                      │"
        printf "│  %-54s│\n" "${HOST_PATH}"
    else
        for qf in "${qdz_files[@]}"; do
            local qname
            qname=$(basename "$qf")
            local qsize
            qsize=$(du -h "$qf" 2>/dev/null | cut -f1)
            printf "│  ✅ %-44s %6s │\n" "$qname" "$qsize"
        done
    fi

    echo "└──────────────────────────────────────────────────────────┘"
    echo ""
}

# =============================================================
# Helper: device_inventory
# =============================================================
# Scans the Quartus installation tree for installed device families
# and prints a status table. Optionally validates against the
# QUARTUS_DEVICES environment variable.
#
# Layout discovery (edition-dependent):
#   Pro:          {root}/devices/<family>/
#   Std / Lite:   {root}/quartus/common/devinfo/<family>/
#                 or {root}/<ver>/quartus/common/devinfo/<family>/
#
# Arguments: $1 = install directory (e.g. /opt/altera)
# =============================================================
device_inventory() {
    local install_dir="$1"
    local -a devices_found=()
    local -a device_parts=()    # parallel array: part-count per family

    # ── Process-node to product-name mapping ──
    # Intel uses process-node names or codenames for device directories.
    # This mapping gives the user a human-friendly product name.
    local -A family_names=(
        # Pro edition (process-node dirs)
        [10nm]="Agilex"
        [7nm]="Agilex 5 / 7"
        [14nm]="Stratix 10"
        [20nm]="Arria 10, Cyclone 10 GX"
        [28nm]="Arria V, Cyclone V, MAX 10"
        # Std/Lite edition (family-name dirs)
        [cyclone10gx]="Cyclone 10 GX"
        [cyclonev]="Cyclone V"
        [cycloneiv]="Cyclone IV"
        [cycloneiii]="Cyclone III"
        [cyclone]="Cyclone"
        [arriav]="Arria V"
        [arriaii]="Arria II"
        [arria10]="Arria 10"
        [stratix10]="Stratix 10"
        [stratixv]="Stratix V"
        [stratixiv]="Stratix IV"
        [max10]="MAX 10"
        [maxv]="MAX V"
        [maxii]="MAX II"
        [55nm]="Cyclone III/IV, MAX V"
    )

    # ── Admin dir deny-list ──
    # These directories appear alongside real device families inside the
    # device metadata tree.  The set is small and stable across all
    # editions (validated against Pro 25.3, Std 24.1, Lite 25.1).
    local -a admin_dirs=(
        configuration dev_install legacy programmer
        cdc_lib sim_lib sim_lib2
    )

    # ── Locate the device metadata directory ──
    # Pro uses a top-level devices/ dir; Std/Lite use quartus/common/devinfo/.
    local device_root=""

    # Path 1 (Pro): {root}/devices/
    if [ -d "${install_dir}/devices" ]; then
        device_root="${install_dir}/devices"
    else
        # Path 2 (Std/Lite): locate quartus/common/devinfo/
        # Fast path: flat layout (single stat)
        local quartus_dir=""
        if [ -d "${install_dir}/quartus" ]; then
            quartus_dir="${install_dir}/quartus"
        else
            # Versioned subdir (e.g., 24.1std/quartus/)
            quartus_dir=$(find "${install_dir}" -maxdepth 3 -type d -name "quartus" -print -quit 2>/dev/null)
        fi
        if [ -n "$quartus_dir" ] && [ -d "${quartus_dir}/common/devinfo" ]; then
            device_root="${quartus_dir}/common/devinfo"
        fi
    fi

    # ── Scan device families ──
    if [ -n "$device_root" ] && [ -d "$device_root" ]; then
        for fam_dir in "${device_root}"/*/; do
            [ -d "$fam_dir" ] || continue
            local dir_name
            dir_name=$(basename "$fam_dir" | tr '[:upper:]' '[:lower:]')
            # Reject known admin directories
            local is_admin=0
            for admin in "${admin_dirs[@]}"; do
                if [[ "$dir_name" == "$admin" ]]; then
                    is_admin=1
                    break
                fi
            done
            if [ "$is_admin" -eq 0 ]; then
                devices_found+=("$(basename "$fam_dir")")
                # Count part subdirectories (device variants)
                local part_count
                part_count=$(find "$fam_dir" -maxdepth 1 -mindepth 1 -type d 2>/dev/null | wc -l)
                device_parts+=("$part_count")
            fi
        done
    fi

    # Parse expected devices from QUARTUS_DEVICES env var
    local -a expected_devices=()
    if [ -n "${QUARTUS_DEVICES:-}" ]; then
        IFS=',' read -ra expected_devices <<< "${QUARTUS_DEVICES}"
    fi

    # Print device inventory table
    echo ""
    echo "┌──────────────────────────────────────────────────────────────┐"
    echo "│  📦  Installed Device Families                              │"
    echo "├──────────────────────────────────────────────────────────────┤"

    if [ ${#devices_found[@]} -eq 0 ]; then
        echo "│  ⚠️  No device families detected                           │"
    else
        local idx=0
        for dev in "${devices_found[@]}"; do
            local parts="${device_parts[$idx]:-0}"
            local key
            key=$(echo "$dev" | tr '[:upper:]' '[:lower:]')
            local friendly="${family_names[$key]:-}"
            if [ -n "$friendly" ] && [ "$parts" -gt 0 ]; then
                printf "│  ✅ %-18s %-25s %3d parts  │\n" "$dev" "($friendly)" "$parts"
            elif [ -n "$friendly" ]; then
                printf "│  ✅ %-18s %-37s│\n" "$dev" "($friendly)"
            elif [ "$parts" -gt 0 ]; then
                printf "│  ✅ %-42s %3d parts  │\n" "$dev" "$parts"
            else
                printf "│  ✅ %-56s│\n" "$dev"
            fi
            idx=$((idx + 1))
        done
    fi

    # Check expected devices (QUARTUS_DEVICES)
    local missing=0
    if [ ${#expected_devices[@]} -gt 0 ]; then
        echo "├──────────────────────────────────────────────────────────────┤"
        echo "│  🔍  Expected Devices (QUARTUS_DEVICES)                     │"
        echo "├──────────────────────────────────────────────────────────────┤"
        for expected in "${expected_devices[@]}"; do
            expected=$(echo "$expected" | xargs)  # trim whitespace
            local found=0
            for dev in "${devices_found[@]+"${devices_found[@]}"}"; do
                if [[ "$(echo "$dev" | tr '[:upper:]' '[:lower:]')" == *"$(echo "$expected" | tr '[:upper:]' '[:lower:]')"* ]]; then
                    found=1
                    break
                fi
            done
            if [ "$found" -eq 1 ]; then
                printf "│  ✅ %-56s│\n" "$expected"
            else
                printf "│  ❌ %-51s MISSING │\n" "$expected"
                missing=$((missing + 1))
            fi
        done
    fi

    echo "└──────────────────────────────────────────────────────────────┘"

    if [ "$missing" -gt 0 ]; then
        echo ""
        echo "  ⚠️  ${missing} expected device family/families missing!"
        echo "     Download the .qdz files from the Intel FPGA Download Center"
        echo "     and place them in your QUARTUS_INSTALLER_PATH directory."
        echo "     Then remove the volume and reinstall:"
        echo "       routertl docker uninstall quartus --volume"
        echo "       routertl docker shell quartus"
    fi

    # ── WSL2 bind-mount performance warning ──
    # Quartus installations on Windows drives (e.g. /mnt/c/) accessed via
    # WSL2's 9P filesystem are extremely slow — device scanning, project
    # opening, and compilation can take 10-50x longer than native Linux
    # filesystems. Warn the user if we detect this configuration.
    if grep -qi microsoft /proc/version 2>/dev/null; then
        local is_bind_mount=0
        # Check if the install dir is on a Windows mount (/mnt/)
        if [[ "${install_dir}" == /mnt/* ]]; then
            is_bind_mount=1
        elif [ -n "${QUARTUS_INSTALL_DIR:-}" ] && [[ "${QUARTUS_INSTALL_DIR}" == /mnt/* ]]; then
            is_bind_mount=1
        elif [ -n "${EDA_INSTALL_DIR:-}" ] && [[ "${EDA_INSTALL_DIR}" == /mnt/* ]]; then
            is_bind_mount=1
        fi
        if [ "$is_bind_mount" -eq 1 ]; then
            echo "  ⚠️  WSL2 Performance Warning"
            echo "     The Quartus installation is bind-mounted from a Windows"
            echo "     filesystem (/mnt/). The 9P protocol bridge causes"
            echo "     severe I/O bottlenecks (10-50x slower than native)."
            echo ""
            echo "     For best performance, use a Docker named volume instead"
            echo "     (stored on the native Linux ext4 filesystem):"
            echo "       rr docker uninstall quartus --purge"
            echo "       rr docker install quartus"
            echo ""
        fi
    fi
    echo ""
}


# -------------------------------------------------------------
# 1. Quartus Installation
# -------------------------------------------------------------
# We check for the presence of a 'quartus' directory inside the opt folder
if ! find "${QUARTUS_OPT_DIR}" -maxdepth 3 -type d -name "quartus" | grep -q .; then
    echo "Altera Quartus not found. Looking for installer..."

    # ── Validate the /installers mount ──────────────────────────
    #
    # Common mistake: QUARTUS_INSTALLER_PATH points to the .tar FILE
    # instead of the DIRECTORY containing it. Docker then mounts the
    # file as /installers (a single flat file), not a directory.
    #
    if [ -f "${INSTALLERS_DIR}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "❌  QUARTUS_INSTALLER_PATH points to a FILE, not a DIRECTORY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  Your QUARTUS_INSTALLER_PATH resolves to a FILE:"
        echo "    ${HOST_PATH}"
        echo ""
        echo "  It must point to the DIRECTORY containing the installer:"
        echo "    QUARTUS_INSTALLER_PATH=/path/to/Downloads/             ← correct"
        echo ""
        echo "  Fix your .env file and re-run: routertl docker shell quartus"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Quartus..."
        # Fall through to handover
    fi

    # Quartus installers can be: setup.sh, *.tar, or *.run
    # Priority: setup.sh > edition-matched archive > first archive
    #
    # Edition matching keywords:
    #   pro      → *pro*
    #   standard → *std* or *standard*
    #   lite     → *lite*
    _edition_tag="${QUARTUS_EDITION:-}"
    _edition_patterns=()
    case "$_edition_tag" in
        pro)      _edition_patterns=("*pro*" "*Pro*" "*PRO*") ;;
        standard) _edition_patterns=("*std*" "*Std*" "*standard*" "*Standard*") ;;
        lite)     _edition_patterns=("*lite*" "*Lite*" "*LITE*") ;;
    esac

    if [ -n "$_edition_tag" ]; then
        echo "📋 Target edition: $_edition_tag"
    fi

    if ls ${INSTALLERS_DIR}/setup.sh 1> /dev/null 2>&1; then
        QUARTUS_INSTALLER="${INSTALLERS_DIR}/setup.sh"
        echo "Found Quartus setup script: ${QUARTUS_INSTALLER}"
        qdz_inventory "${INSTALLERS_DIR}"
        run_with_progress "Quartus Unattended Installation" "${QUARTUS_OPT_DIR}" \
            bash "${QUARTUS_INSTALLER}" --mode unattended --accept_eula 1 --installdir "${QUARTUS_OPT_DIR}"

    elif ls ${INSTALLERS_DIR}/*.run 1> /dev/null 2>&1 || ls ${INSTALLERS_DIR}/*.tar 1> /dev/null 2>&1; then
        # Collect all installer archives (.tar and .run)
        mapfile -t ALL_INSTALLERS < <(ls ${INSTALLERS_DIR}/*.tar ${INSTALLERS_DIR}/*.run 2>/dev/null)

        # ── Edition-aware selection ──
        # If QUARTUS_EDITION is set, try to find an installer that matches
        EDITION_MATCH=""
        if [ ${#_edition_patterns[@]} -gt 0 ]; then
            for pattern in "${_edition_patterns[@]}"; do
                for installer in "${ALL_INSTALLERS[@]}"; do
                    fname=$(basename "$installer")
                    # shellcheck disable=SC2053  # intentional glob matching
                    if [[ "$fname" == $pattern ]]; then
                        EDITION_MATCH="$installer"
                        echo "✅ Edition match: $(basename "$EDITION_MATCH") (matches '$_edition_tag')"
                        break 2
                    fi
                done
            done
            if [ -z "$EDITION_MATCH" ]; then
                echo "⚠️  No installer matching edition '$_edition_tag' found."
                echo "   Available installers:"
                for f in "${ALL_INSTALLERS[@]}"; do
                    echo "     • $(basename "$f")"
                done
                echo "   Falling back to interactive selection..."
            fi
        fi

        if [ -n "$EDITION_MATCH" ]; then
            TAR_FILE="$EDITION_MATCH"
        else
            # No edition match — use select_installer for interactive or CI index
            select_installer "${ALL_INSTALLERS[@]}"
        fi

        echo "Using installer: $(basename "${TAR_FILE}")"
        qdz_inventory "${INSTALLERS_DIR}"

        # ── Handle .run files (direct execution) ──
        if [[ "${TAR_FILE}" == *.run ]]; then
            echo "Executing .run installer: $(basename "${TAR_FILE}")"

            # /installers is mounted read-only — copy to temp to make executable
            RUN_TMP="/home/runner/quartus_tmp_install"
            mkdir -p "${RUN_TMP}"
            RUN_COPY="${RUN_TMP}/$(basename "${TAR_FILE}")"
            cp "${TAR_FILE}" "${RUN_COPY}"
            chmod +x "${RUN_COPY}"

            # Inject .qdz device files into a components/ subdirectory
            # so the .run installer discovers them during extraction.
            # NOTE: .run installers are self-extracting — they look for
            # .qdz files in components/ relative to their working dir,
            # NOT alongside the .run binary itself.
            RUN_COMPONENTS="${RUN_TMP}/components"
            mkdir -p "${RUN_COMPONENTS}"
            for qdz in "${INSTALLERS_DIR}"/*.qdz; do
                [ -f "$qdz" ] || continue
                local_qdz="${RUN_COMPONENTS}/$(basename "$qdz")"
                if [ ! -e "$local_qdz" ]; then
                    ln -sf "$qdz" "$local_qdz"
                    echo "  📦 Linked device package: $(basename "$qdz")"
                fi
            done

            # .run installers are self-extracting — run directly
            run_with_progress "Quartus Unattended Installation" "${QUARTUS_OPT_DIR}" \
                "${RUN_COPY}" --mode unattended --accept_eula 1 --installdir "${QUARTUS_OPT_DIR}"

            # Clean up
            echo "Cleaning up temporary installer copy..."
            rm -rf "${RUN_TMP}"

        # ── Handle .tar files (extract + run setup script) ──
        elif [[ "${TAR_FILE}" == *.tar ]]; then
            # Validate tar integrity before spending time extracting
            echo "Verifying archive integrity..."
            if ! tar -tf "${TAR_FILE}" > /dev/null 2>&1; then
                echo ""
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo "❌  Installer archive appears corrupt or incomplete"
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo ""
                echo "  File: ${TAR_FILE}"
                echo "  Size: $(du -h "${TAR_FILE}" | cut -f1)"
                echo ""
                echo "  Possible causes:"
                echo "    • Incomplete download — re-download the installer"
                echo "    • WSL2 I/O issue — copy the file into the WSL filesystem:"
                echo "        cp /mnt/c/.../Quartus.tar ~/quartus_installers/"
                echo "        # Then set QUARTUS_INSTALLER_PATH=~/quartus_installers"
                echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
                echo ""
                echo "Continuing to shell without Quartus..."
                # Fall through to handover
            else
                echo "✅ Archive OK"

                # Create a temporary extraction directory inside the container
                TMP_EXTRACT="/home/runner/quartus_tmp_install"
                mkdir -p "${TMP_EXTRACT}"

                echo "Extracting ${TAR_FILE} to ${TMP_EXTRACT}..."
                TAR_SIZE=$(stat -c%s "${TAR_FILE}" 2>/dev/null || echo 0)
                if command -v pv > /dev/null 2>&1 && [ "${TAR_SIZE}" -gt 0 ]; then
                    # Real progress bar with speed and ETA
                    pv -p -t -e -r -s "${TAR_SIZE}" "${TAR_FILE}" | tar -xf - -C "${TMP_EXTRACT}"
                else
                    # Fallback: checkpoint-based progress (1 dot per 1000 records)
                    echo "(progress bar unavailable — showing checkpoints)"
                    tar --checkpoint=1000 --checkpoint-action=dot -xf "${TAR_FILE}" -C "${TMP_EXTRACT}"
                    echo ""
                fi

                if [ -f "${TMP_EXTRACT}/setup_pro.sh" ]; then
                    QUARTUS_INSTALLER="${TMP_EXTRACT}/setup_pro.sh"
                elif [ -f "${TMP_EXTRACT}/setup.sh" ]; then
                    QUARTUS_INSTALLER="${TMP_EXTRACT}/setup.sh"
                else
                    QUARTUS_INSTALLER=""
                fi

                # ── Inject .qdz device files into the extraction directory ──
                # The Quartus installer discovers .qdz files relative to
                # setup_pro.sh (same dir or components/ subdir), NOT from
                # the original /installers/ mount. We symlink them to avoid
                # doubling disk usage for multi-GB device packages.
                QDZ_COUNT=0
                COMPONENTS_DIR="${TMP_EXTRACT}/components"
                mkdir -p "${COMPONENTS_DIR}"
                for qdz in "${INSTALLERS_DIR}"/*.qdz; do
                    [ -f "$qdz" ] || continue
                    local_name="${COMPONENTS_DIR}/$(basename "$qdz")"
                    if [ ! -e "$local_name" ]; then
                        ln -sf "$qdz" "$local_name"
                        echo "  📦 Linked device package: $(basename "$qdz")"
                        QDZ_COUNT=$((QDZ_COUNT + 1))
                    fi
                done
                if [ "$QDZ_COUNT" -gt 0 ]; then
                    echo "  ✅ ${QDZ_COUNT} device package(s) linked into extraction directory"
                fi

                if [ -n "${QUARTUS_INSTALLER}" ]; then
                    run_with_progress "Quartus Unattended Installation" "${QUARTUS_OPT_DIR}" \
                        bash "${QUARTUS_INSTALLER}" --mode unattended --accept_eula 1 --installdir "${QUARTUS_OPT_DIR}"
                else
                    echo "Error: Neither setup_pro.sh nor setup.sh found inside the extracted tarball."
                fi

                # Clean up
                echo "Cleaning up temporary installation files..."
                rm -rf "${TMP_EXTRACT}"
            fi
        fi
    else
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  No Quartus installer found!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  Looked in: ${HOST_PATH}  (mounted as ${INSTALLERS_DIR}/ inside container)"
        echo "  Expected:  setup.sh, setup_pro.sh, *.tar, or *.run"
        echo ""
        echo "  Contents of ${HOST_PATH}:"
        ls -la "${INSTALLERS_DIR}/" 2>/dev/null || echo "    (directory does not exist or is empty)"
        echo ""
        echo "  To fix this, set QUARTUS_INSTALLER_PATH in your .env file:"
        echo ""
        echo "    # .env (in your project root)"
        echo "    QUARTUS_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads"
        echo ""
        echo "  ⚠️  Must be the DIRECTORY, not the .tar file itself!"
        echo "  Then re-run: routertl docker shell quartus"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Quartus..."
    fi
else
    echo "✅ Altera Quartus is already installed."
fi

# -------------------------------------------------------------
# 1b. Kill orphan Quartus DDM daemon processes
# -------------------------------------------------------------
# The Quartus 24.1+ installer spawns a DDM (Device Download Manager)
# daemon via double-fork, which detaches from the installer PID and
# can survive the setsid process-group kill in run_with_progress().
# Kill any lingering ddm processes to ensure a clean handover.
for proc_name in ddm ddm_daemon qddm; do
    if pkill -f "$proc_name" 2>/dev/null; then
        echo "   🧹 Killed orphan process: $proc_name"
    fi
done

# -------------------------------------------------------------
# 2. Volume Version Stamp
# -------------------------------------------------------------
# Stamp the volume on fresh installs so future image rebuilds can
# detect a stale volume from an incompatible image generation.
VOLUME_STAMP="${QUARTUS_OPT_DIR}/.routertl_image_id"
CURRENT_IMAGE_ID="$(cat /etc/hostname 2>/dev/null || echo unknown)"
if find "${QUARTUS_OPT_DIR}" -maxdepth 3 -type d -name "quartus" | grep -q .; then
    if [ -f "${VOLUME_STAMP}" ]; then
        PREV_ID="$(cat "${VOLUME_STAMP}")"
        if [ "${PREV_ID}" != "${CURRENT_IMAGE_ID}" ]; then
            echo ""
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo "⚠️  Quartus volume was created by a different image"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
            echo "  Previous: ${PREV_ID}"
            echo "  Current:  ${CURRENT_IMAGE_ID}"
            echo ""
            echo "  If Quartus fails, remove the stale volume:"
            echo "    routertl docker uninstall quartus --volume"
            echo "  Then re-run: routertl docker shell quartus"
            echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
            echo ""
        fi
    fi
    echo "${CURRENT_IMAGE_ID}" > "${VOLUME_STAMP}" 2>/dev/null || true
fi

# -------------------------------------------------------------
# 3. Device Family Inventory
# -------------------------------------------------------------
# Always show installed device families on boot — this is the
# main feedback mechanism for confirming device support.
if find "${QUARTUS_OPT_DIR}" -maxdepth 3 -type d -name "quartus" | grep -q .; then
    device_inventory "${QUARTUS_OPT_DIR}"
fi

# -------------------------------------------------------------
# 4. Dynamic Questa IFPGA PATH Discovery
# -------------------------------------------------------------
# Quartus bundles Questa Intel FPGA Edition. The bin path varies by
# version: questa_fse (Lite/Standard), questa_fe (Pro), etc.
# We search for vsim dynamically rather than hardcoding.
QUESTA_BIN=$(find "${QUARTUS_OPT_DIR}" -maxdepth 4 -type f -name vsim -print -quit 2>/dev/null || true)
if [ -n "${QUESTA_BIN}" ]; then
    QUESTA_DIR=$(dirname "${QUESTA_BIN}")
    echo "✅ Found bundled Questa IFPGA at: ${QUESTA_DIR}"
else
    # Fallback to common paths
    for candidate in questa_fse/bin questa_fe/bin modelsim_ase/bin; do
        if [ -d "${QUARTUS_OPT_DIR}/${candidate}" ]; then
            QUESTA_DIR="${QUARTUS_OPT_DIR}/${candidate}"
            echo "✅ Found bundled simulator at: ${QUESTA_DIR}"
            break
        fi
    done
    if [ -z "${QUESTA_DIR:-}" ]; then
        QUESTA_DIR="${QUARTUS_OPT_DIR}/questa_fse/bin"
        echo "⚠️  Questa IFPGA not found — using fallback: ${QUESTA_DIR}"
    fi
fi

# -------------------------------------------------------------
# 5. Ensure CLI aliases exist
# -------------------------------------------------------------
# Create rr symlink if missing (covers images built before it was
# added to Dockerfile.sim, or system PATH reset by su/PAM).
if command -v routertl >/dev/null 2>&1 && ! command -v rr >/dev/null 2>&1; then
    ROUTERTL_PATH="$(command -v routertl)"
    ln -sf "${ROUTERTL_PATH}" "$(dirname "${ROUTERTL_PATH}")/rr" 2>/dev/null || true
fi

# Execute the main command passed to the container (e.g., bash)
echo "Handing over to: $*"
# Drop privileges to 'runner' for simulation.
# IMPORTANT: env vars MUST be set inside the -c string because
# 'su' goes through PAM which resets the environment.
# NOTE: Dynamically discover quartus/bin since Quartus Standard
# uses versioned subdirectories (e.g., 24.1std/quartus/bin).
# Fast path: try flat layout first to avoid slow find on WSL2/9P.
if [ -d "${QUARTUS_OPT_DIR}/quartus/bin" ]; then
    QUARTUS_BIN_DIR="${QUARTUS_OPT_DIR}/quartus/bin"
else
    QUARTUS_BIN_DIR=$(find "${QUARTUS_OPT_DIR}" -maxdepth 4 -type d -name bin -path '*/quartus/bin' -print -quit 2>/dev/null)
fi
QUARTUS_BIN_DIR="${QUARTUS_BIN_DIR:-/opt/altera/quartus/bin}"
# NOTE: $PATH here expands to ROOT's PATH at parse time — this is
# intentional!  PAM resets runner's PATH to empty, so we bake in the
# full system PATH (/usr/bin, /bin, etc.) from the root context.
# NOTE: do NOT redirect stderr (2>/dev/null) — bash writes PS1 to stderr!
exec su -s /bin/bash runner -c "
  export PATH='${QUESTA_DIR}:${QUARTUS_BIN_DIR}:/usr/local/bin:$PATH'
  export SIM=questa
  cd /home/runner/work
  echo \"🔧 Active simulator: \$SIM\"
  exec $*"
