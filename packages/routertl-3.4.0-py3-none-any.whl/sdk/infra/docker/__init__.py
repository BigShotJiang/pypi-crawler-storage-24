# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# Package sentinel — makes sdk/infra/docker/ a Python package so setuptools
# includes docker.sh and companion files as wheel package-data.
