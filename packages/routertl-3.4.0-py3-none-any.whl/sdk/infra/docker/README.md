# RouteRTL Docker Environments

Unified development container with all simulation tools pre-configured.

## Quick Start

From any project that includes RouteRTL as a submodule:

```bash
# Build the container image
routertl docker build sim

# Start an interactive shell
routertl docker shell sim

# Run a command inside the container
routertl docker run sim "make simulation"

# View Docker environment dashboard
routertl docker status
```

## Available Environments

| Environment      | Use Case                     | Tools Included                                                           |
|------------------|------------------------------|--------------------------------------------------------------------------|
| `sim` (default)  | Simulation & verification    | NVC 1.18.2, GHDL 6.0+, Verilator 5.036, Cocotb 2.0.1                    |
| `vivado`         | Full Xilinx build flow       | Everything in `sim` + Vivado (requires local installer)                  |
| `questa`         | Siemens Questa verification  | Everything in `sim` + Questa (requires unattended installer)             |
| `riviera`        | Aldec Riviera-PRO verif.     | Everything in `sim` + Riviera (requires unattended installer)            |
| `quartus`        | Full Altera build flow       | Everything in `sim` + Quartus Prime Pro (requires unattended installer)  |
| `radiant`        | Full Lattice build flow      | Everything in `sim` + Lattice Radiant (requires unattended installer)    |

### Switching Environments

```bash
routertl docker shell vivado
routertl docker run vivado "make synthesis"
```

## How It Works

The container mounts your **project directory** into `/home/runner/work` (sim)
or `/home/vivado/work` (vivado). Changes inside the container reflect on your
host filesystem.

## Docker Management

```bash
# Full dashboard (volumes, images, containers, health checks)
routertl docker status

# Remove a vendor tool installation volume
routertl docker uninstall quartus

# Show/edit install configuration
routertl docker config vivado --edit
```

## Architecture

Single multi-stage `Dockerfile`:

- **Stage `sim`**: Lightweight simulation environment (~2 GB)
- **Stage `vivado`**: Extends `sim` with Xilinx Vivado support (~50+ GB)

## Requirements

- Docker and Docker Compose v2 installed
- For Vivado environment: Local Vivado installer (set `VIVADO_INSTALLER_PATH` in `.env`)
- For Quartus environment: Local Quartus installer `.tar` file.
- For Radiant environment: Local Radiant installer `.zip` or `.run` file.

### Quartus Pro Installation Example

Quartus requires a massive 60GB+ installer. To keep the project configuration pristine, you can pass the path to your downloaded installer directory dynamically during the build step.

```bash
# Pass the host directory path where your downloaded Quartus-xxx.tar file is located
QUARTUS_INSTALLER_PATH=/mnt/c/Users/dmazure/Downloads routertl docker build quartus
```

Once installed, subsequent `routertl docker shell quartus` runs will automatically bypass the installation step.

### Device Family Support

Quartus Pro installs device support from `.qdz` files that must be **present alongside
the installer** in your `QUARTUS_INSTALLER_PATH` directory. If a device family's `.qdz`
file is missing, that family will NOT be available.

#### Adding Device Families (e.g., Arria 10)

1. Download the `.qdz` file from the [Intel FPGA Download Center](https://www.intel.com/content/www/us/en/products/details/fpga/)
2. Place it in the same directory as your Quartus `.tar` installer
3. Remove the existing volume and reinstall:

```bash
routertl docker uninstall quartus --volume
routertl docker shell quartus
```

#### Validating Installed Devices

On every container boot, the entrypoint prints a device inventory table showing all
detected families. To check for **expected** families, set `QUARTUS_DEVICES` in `.env`:

```bash
# .env (in your project root)
QUARTUS_DEVICES=cyclonev,arria10,max10
```

Missing families are flagged with ❌ in the boot output.

#### Multiple Installer Archives

When multiple `.tar` files exist in the installer directory, the entrypoint shows an
interactive selection menu. For CI/CD (headless), set `QUARTUS_INSTALLER_INDEX` to the
1-based index of the desired installer:

```bash
# .env — always use the second .tar file
QUARTUS_INSTALLER_INDEX=2
```

### Node-Locked Licenses (MAC Spoofing)

If your FlexLM license is locked to a specific host MAC address (common
with Arria 10 and other premium device families), Docker containers will
fail license validation because they run with a different virtual MAC.

**Solution**: Set `EDA_MAC_ADDRESS_OVERRIDE` in `.env`. This
automatically switches affected containers (Quartus, Questa, Riviera)
from `network_mode: host` to bridge networking with a spoofed MAC.

```bash
# Interactive setup (recommended):
routertl docker setup
# Step 3 will ask for your MAC address

# Or manually add to .env:
EDA_MAC_ADDRESS_OVERRIDE=00:1A:2B:3C:4D:5E
```

**Finding your host MAC:**

- **Windows (PowerShell)**: `Get-NetAdapter | Select Name, MacAddress`
- **Linux**: `ip link show | grep ether`

**Finding your license .dat file:**

- Look for `HOSTID=` or `SERVER` lines in `.dat` files
- **Windows**: `findstr /s /i HOSTID C:\*.dat`
- **Linux**: `grep -rl HOSTID /opt /usr/local 2>/dev/null`

> **Note on `network_mode`:** When MAC override is active, `docker.sh`
> layers `docker-compose.mac-override.yml` which replaces
> `network_mode: host` with bridge networking. VPN-routed license
> servers typically remain reachable through Docker NAT, but some
> VPN configurations may block NAT traffic. To disable MAC spoofing,
> remove `EDA_MAC_ADDRESS_OVERRIDE` from `.env`.

### Quartus & Riviera WSL Interactive Setup

The first time you run `routertl docker build quartus` or
`routertl docker build riviera`, an interactive setup wizard
(`wsl_setup_wizard.sh`) launches to configure:

1. **Memory**: Checks WSL2 `.wslconfig` memory override (recommends
   ≥48 GB for large FPGA synthesis)
2. **Node-Locked Licenses**: Optionally injects MAC into `.env`
3. **CLI Aliases**: Runs `routertl workspace rebrand` for shortcuts

