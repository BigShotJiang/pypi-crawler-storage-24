#!/usr/bin/env bash
# install_libero.sh: Automated entrypoint for RouteRTL Libero container
# This script checks if Libero SoC is installed in the persistent volume.
# If not, it runs the unattended Microchip installer from the mounted directory.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "${SCRIPT_DIR}/install_progress.sh"

LIBERO_OPT_DIR="/opt/microsemi"
INSTALLERS_DIR="/installers"
HOST_PATH="${LIBERO_INSTALLER_PATH_HOST:-${INSTALLERS_DIR}}"

echo "Checking Microchip Libero SoC installation in ${LIBERO_OPT_DIR}..."

# Ensure the persistent volume directory exists and is writable by the runner user
sudo mkdir -p "${LIBERO_OPT_DIR}" 2>/dev/null || true
sudo chown -R $(whoami):$(whoami) "${LIBERO_OPT_DIR}" 2>/dev/null || true

# Check for Libero binary in expected locations.
# Libero installs into versioned subdirectories:
#   /opt/microsemi/Libero_SoC_v2024.2/Libero/bin/libero
#   /opt/microsemi/Libero_SoC_vXX.X/Libero/bin/lin64/libero
if ! find "${LIBERO_OPT_DIR}" -maxdepth 5 -type f -name "libero" | grep -q .; then
    echo "Libero SoC not found. Looking for installer..."

    # ── Validate the /installers mount ────────────────────
    if [ -f "${INSTALLERS_DIR}" ]; then
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "❌  LIBERO_INSTALLER_PATH points to a FILE, not a DIRECTORY"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  It must point to the DIRECTORY containing the installer:"
        echo "    LIBERO_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads  ← correct"
        echo "    LIBERO_INSTALLER_PATH=/path/to/Libero_SoC.bin          ← wrong"
        echo ""
        echo "  Fix your .env file and re-run: routertl docker shell libero"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Libero..."
        exec "$@"
    fi

    # Look for installer: .bin files first, then .zip archives
    LIBERO_INSTALLER=""

    # Priority 1: Direct .bin installer
    LIBERO_INSTALLER=$(find "${INSTALLERS_DIR}" -maxdepth 1 -name "*Libero_SoC*.bin" -o -name "*Libero*.bin" | head -n 1)

    # Priority 2: .zip archive containing the .bin installer
    if [ -z "${LIBERO_INSTALLER}" ]; then
        LIBERO_ZIP=$(find "${INSTALLERS_DIR}" -maxdepth 1 -name "*Libero_SoC*.zip" -o -name "*Libero*.zip" | head -n 1)
        if [ -n "${LIBERO_ZIP}" ]; then
            echo "Found zip file: $(basename "${LIBERO_ZIP}"). Extracting .bin installer..."
            TMP_EXTRACT="/home/$(whoami)/libero_tmp_install"
            mkdir -p "${TMP_EXTRACT}"
            unzip -q -o "${LIBERO_ZIP}" -d "${TMP_EXTRACT}"
            chmod +x "${TMP_EXTRACT}"/*.bin 2>/dev/null || true
            LIBERO_INSTALLER=$(find "${TMP_EXTRACT}" -maxdepth 2 -name "*.bin" | head -n 1)
        fi
    fi

    if [ -n "${LIBERO_INSTALLER}" ]; then
        echo "Found Libero installer: $(basename "${LIBERO_INSTALLER}")"
        chmod +x "${LIBERO_INSTALLER}"

        echo "Starting headless installation (this may take 10-30 minutes)..."
        run_with_progress "Libero SoC Unattended Installation" "${LIBERO_OPT_DIR}" \
            "${LIBERO_INSTALLER}" --mode unattended --prefix "${LIBERO_OPT_DIR}" || {
            echo "❌ Libero installation failed. Check the logs above."
            echo "Continuing to shell..."
            exec "$@"
        }

        # Deploy license if present alongside the installer
        if [ -f "${INSTALLERS_DIR}/license.dat" ]; then
            echo "Deploying license.dat..."
            mkdir -p "${LIBERO_OPT_DIR}/license"
            cp "${INSTALLERS_DIR}/license.dat" "${LIBERO_OPT_DIR}/license/license.dat"
            echo "✅ License deployed to ${LIBERO_OPT_DIR}/license/license.dat"
        else
            echo "⚠️  No license.dat found in ${HOST_PATH}."
            echo "   Place your node-locked license.dat in the installer directory,"
            echo "   or set LM_LICENSE_FILE in .env for a floating license server."
        fi

        # Cleanup temp extraction
        if [ -d "/home/$(whoami)/libero_tmp_install" ]; then
            rm -rf "/home/$(whoami)/libero_tmp_install"
        fi
    else
        echo ""
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "⚠️  No Libero SoC installer found!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "  Looked in: ${HOST_PATH}/"
        echo "  Expected:  *Libero_SoC*.bin or *Libero_SoC*.zip"
        echo ""
        echo "  Contents of ${INSTALLERS_DIR}/:"
        ls -la "${INSTALLERS_DIR}/" 2>/dev/null || echo "    (directory does not exist or is empty)"
        echo ""
        echo "  To fix this, set LIBERO_INSTALLER_PATH in your .env file:"
        echo ""
        echo "    # .env (in your project root)"
        echo "    LIBERO_INSTALLER_PATH=/mnt/c/Users/YourName/Downloads"
        echo ""
        echo "  ⚠️  Must be the DIRECTORY, not the .bin file itself!"
        echo "  Then re-run: routertl docker shell libero"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Continuing to shell without Libero..."
    fi
else
    echo "✅ Microchip Libero SoC is already installed."
fi

# ── Handover ──────────────────────────────────────────────────
# Discover the actual Libero installation path dynamically.
# Libero installs into versioned subdirs:
#   /opt/microsemi/Libero_SoC_v2024.2/Libero/bin/
LIBERO_HOME=$(find "${LIBERO_OPT_DIR}" -maxdepth 3 -type d -name "Libero" | sort -r | head -n 1)

if [ -n "${LIBERO_HOME}" ]; then
    echo "✅ Libero root discovered at: ${LIBERO_HOME}"
    LIBERO_BIN_DIR="${LIBERO_HOME}/bin"
    if [ -d "${LIBERO_HOME}/bin/lin64" ]; then
        LIBERO_BIN_DIR="${LIBERO_HOME}/bin/lin64"
    fi
else
    LIBERO_HOME="${LIBERO_OPT_DIR}"
    LIBERO_BIN_DIR="${LIBERO_OPT_DIR}"
fi

# Set license path: user-provided > deployed > default
LICENSE_PATH="${LM_LICENSE_FILE:-}"
if [ -z "${LICENSE_PATH}" ] && [ -f "${LIBERO_OPT_DIR}/license/license.dat" ]; then
    LICENSE_PATH="${LIBERO_OPT_DIR}/license/license.dat"
fi

echo ""
echo "Active simulator: nvc (default)"
echo "Handing over to: $*"

exec su -s /bin/bash runner -c "
  export PATH='${LIBERO_BIN_DIR}:/usr/local/bin:/usr/bin:/bin:\$PATH'
  export LM_LICENSE_FILE='${LICENSE_PATH}'
  export LEONARDOSPEC='${LIBERO_HOME}'
  cd /home/runner/work
  exec $*"
