#!/bin/bash
# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Restore the original .xdc files if they have only whitespace changes,
# as Vivado tends to modify them with every run.
XDC_DIR=$1
files_changed=0
# Loop through all changed .xdc files
echo "Checking whether xdc files were modified by Vivado ..."
for file in $(git diff --name-only -- ${XDC_DIR}/*.xdc); do
  files_changed=1
  if git diff --ignore-space-at-eol --ignore-blank-lines --exit-code -- "$file" > /dev/null; then
    echo "🔄 Reverting whitespace-only change: $file"
    git checkout -- "$file"
  else
    echo "⚠️ $file has real changes — not resetting."
  fi
done

if [ $files_changed -eq 0 ]; then
  echo "No xdc files were modified"
else
  echo "Restored xdc files modified by Vivado"
fi