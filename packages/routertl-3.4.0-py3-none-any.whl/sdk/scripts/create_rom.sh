#!/usr/bin/env bash
# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# This script is called by Vivado as a presynthesis hook

root_dir=$1
constants_file=$2; # To be picked up by a tcl script
register_map_file=$3
register_map_hex_file=$4
config_hex_file=$5

if [ -z "$root_dir" ] || [ -z "$constants_file" ] || [ -z "$register_map_file" ]; then
  echo "❌ Usage: $0 <root_dir> <constants_file> <register_map_file>"
  exit 1
fi

if [ ! -f "$register_map_file" ]; then
  echo "⚠️  Register map file not found: $register_map_file. Using defaults (0.0.0)"
  # Proceed with defaults
fi

if [ -f "$root_dir/VERSION" ]; then
  version_file="$root_dir/VERSION"
else
  echo "❌ No VERSION file found in $root_dir"
  echo "   Run 'python3 sdk/cli/sync_version.py' to generate it."
  exit 1
fi

# Validate that the constants file ends with 'rom.data'
if [[ "$(basename "$constants_file")" != "rom.data" ]]; then
  echo "❌ Error: constants_file must be named 'rom.data'"
  echo "   You passed: $constants_file"
  exit 1
fi

# Check register map file extension
if [[ -f "$register_map_file" ]] && [[ ! "$register_map_file" =~ \.ya?ml$ ]]; then
  echo "❌ Error: register_map_file must be a .yml or .yaml file"
  echo "   You passed: $register_map_file"
  exit 1
fi


# These values default
system_major=0
system_minor=1
system_patch=0
system_reserved=0

# Check the version file, to overwrite eventually the default values
# Check the version file, to overwrite eventually the default values
# shellcheck source=/dev/null
source "$version_file"

# Dynamic Patch Calculation:
# Count commits on the current branch
# (Optional adjustment: count commits since last change to VERSION file?)
# Simple approach: total commit count modulo 256
system_patch=$(git rev-list --count HEAD)
# Cap at 255 to fit in one byte if needed, or stick to 8 bits
system_patch=$((system_patch % 256))

echo "System Version: $system_major.$system_minor.$system_patch"

# Register bank version
# regbank_major=1
# regbank_minor=0
# regbank_patch=0
# regbank_reserved=0

# Safer version against malformed version field in the yml file:
#IFS='.' read -r regbank_major regbank_minor regbank_patch regbank_reserved <<< "$(echo "${regbank_version}.0.0.0" | cut -d'.' -f1-4)"

if [ -f "$register_map_file" ]; then
  regbank_version=$(grep '^version:' "$register_map_file" | sed -E 's/version:[[:space:]]*//')
  IFS='.' read -r regbank_major regbank_minor regbank_patch <<< "${regbank_version}"
else
  regbank_major=0
  regbank_minor=0
  regbank_patch=0
fi
regbank_reserved=0


# 1. Date
# 2. Git Hash

# This converts the date (from epoc) to hexadecimal value
printf '%x\r\n' "$(date +%s)" > $constants_file

# This extracts the short SHA
SHA_SHELL=$(git rev-parse --short=8 HEAD)

#echo "$PAD_SHA" >> $constants_file
echo "$SHA_SHELL" >> $constants_file

# 3. System Version
printf -v system_major_hex "%02x" $system_major
printf -v system_minor_hex "%02x" $system_minor
printf -v system_patch_hex "%02x" $system_patch


# Reserved field: annotates a "dirty" bit in the version if the release was 
# not clean. This is useful to identify if the release was done from a local build

# Define an array with the directories to check
DIRS_TO_CHECK=(
    "$root_dir/src"
    #"$root_dir/xdc" #Vivado is touching this directory everytime
)

changes_detected=0  # Initialize flag

# Loop through each directory in the list
for dir in "${DIRS_TO_CHECK[@]}"; do
    if [[ -n $(git status --porcelain "$dir") ]]; then
        echo "Changes detected in: $dir"
        changes_detected=1  # Set flag to indicate changes
    fi
done

# Show result
if [[ $changes_detected -eq 1 ]]; then
    echo "Changes detected in one or more directories."
    echo "Changes detected in one or more directories."
    system_reserved=1
else
    echo "Repository is clean."
fi

echo "Changes detected: $changes_detected"

printf -v system_reserved "%02x" $system_reserved

echo ${system_major_hex}${system_minor_hex}${system_patch_hex}${system_reserved} >> $constants_file


# 4. Register Bank Version

printf -v regbank_major_hex    "%02x" $regbank_major
printf -v regbank_minor_hex    "%02x" $regbank_minor
printf -v regbank_patch_hex    "%02x" $regbank_patch
printf -v regbank_reserved_hex "%02x" $regbank_reserved

echo "Register Bank major: $regbank_major_hex"
echo "Register Bank minor: $regbank_minor_hex"
echo "Register Bank patch: $regbank_patch_hex"
echo "Register Bank resvd: $regbank_reserved_hex"

printf "%s%s%s%s\n" \
  "$regbank_major_hex" \
  "$regbank_minor_hex" \
  "$regbank_patch_hex" \
  "$regbank_reserved_hex" >> "$constants_file"

# 5. Manifest size
# This is the size of the schema register map file
# 5. Manifest size
# This is the size of the schema register map file
if [ -f "$register_map_hex_file" ]; then
    num_lines=$(wc -l < $register_map_hex_file)
else
    num_lines=0
fi
printf -v num_lines_hex "%08x" $num_lines
printf "%s\n" "$num_lines_hex" >> "$constants_file"

echo "Manifest size: $num_lines_hex; $num_lines lines"

# 6. Config size

num_lines=$(wc -l < $config_hex_file)
printf -v num_lines_hex "%08x" $num_lines
printf "%s\n" "$num_lines_hex" >> "$constants_file"

echo "Config size: $num_lines_hex; $num_lines lines"
