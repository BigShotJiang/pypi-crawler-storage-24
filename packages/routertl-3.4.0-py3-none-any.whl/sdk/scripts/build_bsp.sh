#!/usr/bin/env bash
# Board Support Package (BSP) Generator wrapper for XSCT
# Generates xparameters.h to unblock build_fsbl.sh natively from the .xsa
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
BUILD_DIR=${BUILD_DIR:-"$PROJECT_ROOT/build"}
PROJECT_NAME=${PROJECT_NAME:-$(basename "$PROJECT_ROOT")}
LINUX_SRC_DIR=${LINUX_SRC_DIR:-"$PROJECT_ROOT/linux/src"}
EMBEDDEDSW_DIR="$LINUX_SRC_DIR/embeddedsw"
FSBL_DEFAULT_REPO="https://github.com/Xilinx/embeddedsw.git"
FSBL_REPO="${FSBL_REPO:-$FSBL_DEFAULT_REPO}"

# Hardware Export Path
HW_PATH="$BUILD_DIR/${PROJECT_NAME}.xsa"

echo "========================================"
echo "Generating XSCT Board Support Package"
echo "========================================"

if [ ! -f "$HW_PATH" ]; then
    echo "❌ Error: XSA hardware definition not found!"
    echo "Expected path: $HW_PATH"
    echo "Did you run 'make build-bitstream' first?"
    exit 1
fi

# Ensure standalone BSP output directory exists
BSP_OUT="$BUILD_DIR/bsp_workspace"
rm -rf "$BSP_OUT"
mkdir -p "$BSP_OUT"

# Generate temporary TCL script for XSCT
XSCT_TCL="$BUILD_DIR/gen_bsp.tcl"

cat << EOF > "$XSCT_TCL"
# Auto-generated XSCT script to extract Board Support Package
setws "$BSP_OUT"
# Create platform from XSA
platform create -name hw_platform -hw "$HW_PATH"
# Create standalone domain (generates the xparameters.h headers)
domain create -name standalone_domain -os standalone -proc ps7_cortexa9_0
# Build the platform
platform generate
EOF

echo "Launching Xilinx XSCT (Vitis command-line)..."
# Check if xsct is available in PATH
if ! command -v xsct &> /dev/null; then
    echo "❌ Error: 'xsct' command not found."
    echo "You must run this in a terminal where Vitis is sourced (e.g., settings64.sh)"
    echo "or skip this phase and manually copy xparameters.h into your embeddedsw/"
    exit 1
fi

xsct "$XSCT_TCL"

# Extract headers for FSBL compilation
FSBL_INC_DIR="$EMBEDDEDSW_DIR/lib/sw_apps/zynq_fsbl/src"
if [ ! -d "$FSBL_INC_DIR" ]; then
    echo "⚠️  embeddedsw repository not found at $FSBL_INC_DIR. Cloning it now..."
    mkdir -p "$LINUX_SRC_DIR"
    git clone --depth 1 "$FSBL_REPO" "$EMBEDDEDSW_DIR"
fi

# Deep copy all BSP includes directly into the FSBL source so GCC can find them
echo "Copying xparameters.h, BSP headers, and libxil.a into $FSBL_INC_DIR"
cp -r "$BSP_OUT/hw_platform/zynq_fsbl/zynq_fsbl_bsp/ps7_cortexa9_0/include/"* "$FSBL_INC_DIR/"

BSP_MISC_DIR="$EMBEDDEDSW_DIR/lib/sw_apps/zynq_fsbl/misc/ps7_cortexa9_0"
mkdir -p "$BSP_MISC_DIR/lib"
cp "$BSP_OUT/hw_platform/zynq_fsbl/zynq_fsbl_bsp/ps7_cortexa9_0/lib/"*.a "$BSP_MISC_DIR/lib/"

echo "✅ BSP Generation Complete. FSBL is now unlocked."
