#!/usr/bin/env bash
# Build First Stage Bootloader (FSBL) from Xilinx/embeddedsw source
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
LINUX_SRC_DIR=${LINUX_SRC_DIR:-"$PROJECT_ROOT/linux/src"}
LINUX_OUT_DIR=${LINUX_OUT_DIR:-"$PROJECT_ROOT/linux/out"}
BOARD=${BOARD:-zc706}
FSBL_ARCH=${FSBL_ARCH:-zynq}

# Configure compiler based on architecture
if [ "$FSBL_ARCH" = "zynqmp" ]; then
    CC="aarch64-linux-gnu-gcc"
    APP_DIR="zynqmp_fsbl"
else
    CC="arm-none-eabi-gcc"
    APP_DIR="zynq_fsbl"
fi

EMBEDDEDSW_DIR="$LINUX_SRC_DIR/embeddedsw"
FSBL_DEFAULT_REPO="https://github.com/Xilinx/embeddedsw.git"
FSBL_REPO="${FSBL_REPO:-$FSBL_DEFAULT_REPO}"

echo "========================================"
echo "Building FSBL ($FSBL_ARCH) for $BOARD"
echo "========================================"

mkdir -p "$LINUX_SRC_DIR"
mkdir -p "$LINUX_OUT_DIR"

if [ ! -d "$EMBEDDEDSW_DIR" ]; then
    echo "Cloning FSBL source from $FSBL_REPO..."
    git clone --depth 1 "$FSBL_REPO" "$EMBEDDEDSW_DIR"
fi

SRC_DIR="$EMBEDDEDSW_DIR/lib/sw_apps/$APP_DIR/src"

# Support for the FSBL overlay hooks from FDD Section 2.4
HOOKS_C="$PROJECT_ROOT/linux/hooks/fsbl_hooks.c"
if [ -f "$HOOKS_C" ]; then
    echo "Applying user FSBL hooks from $HOOKS_C..."
    cp "$HOOKS_C" "$SRC_DIR/fsbl_hooks.c"
fi

cd "$SRC_DIR"
echo "Compiling FSBL..."
make "BOARD=$BOARD" "CC=$CC"

# Standardize output naming
cp fsbl.elf "$LINUX_OUT_DIR/fsbl.elf"
echo "✅ FSBL built: $LINUX_OUT_DIR/fsbl.elf"
