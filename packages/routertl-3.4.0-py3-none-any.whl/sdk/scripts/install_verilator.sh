#!/bin/bash
set -e

echo "[INFO] Removing old Verilator..."
apt-get remove -y verilator || true

echo "[INFO] Installing prerequisites..."
apt-get update
apt-get install -y git help2man perl python3 make autoconf g++ flex bison ccache \
    libgoogle-perftools-dev numactl perl-doc libfl-dev zlib1g zlib1g-dev

echo "[INFO] Cloning Verilator repository..."
# Clone into a temporary directory
cd /tmp
rm -rf verilator
git clone https://github.com/verilator/verilator

echo "[INFO] Building Verilator v5.036 (required by cocotb 2.0+)..."
cd verilator
unset VERILATOR_ROOT
git checkout v5.036

autoconf
./configure
make -j$(nproc)

echo "[INFO] Installing Verilator..."
make install

echo "[SUCCESS] Verilator 5.036 installed!"
verilator --version
