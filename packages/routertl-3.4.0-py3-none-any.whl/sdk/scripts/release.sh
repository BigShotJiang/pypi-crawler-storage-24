#!/bin/bash
# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

# Define paths
ROM_FILE="misc/rom.data"
BITFILE="bitstream/system.bit"

# Check if rom.data exists
if [[ ! -f "$ROM_FILE" ]]; then
    echo "Error: $ROM_FILE not found!"
    exit 1
fi

# Extract the third entry (versioning)
VERSION_LINE=$(sed -n '3p' "$ROM_FILE")
# Extract the second entry (git hash)
GIT_HASH_LINE=$(sed -n '2p' "$ROM_FILE")

# Ensure we got something
if [[ -z "$VERSION_LINE" ]]; then
    echo "Error: Failed to extract version from $ROM_FILE"
    exit 1
fi

if [[ -z "$GIT_HASH_LINE" ]]; then
    echo "Error: Failed to extract git hash from $ROM_FILE"
    exit 1
fi

# Extract major, minor, patch (first 6 characters)
VERSION="${VERSION_LINE:0:6}"
HASH="${GIT_HASH_LINE:0:8}"

# Define new file name
NEW_BITFILE="bitstream/system_${VERSION}_${HASH}.bit"
PYTHON_TEST_PATH="python/tests/system_top.bit"
NUGET_PATH="tools/nuget/bitstream/SYSTEM_V_2_OpalKelly_XEM7305.bit"

if [[ -f "$NEW_BITFILE" ]]; then
    echo "Bitstream was already released: $NEW_BITFILE, re-creating ..."
    rm -rf $NEW_BITFILE
fi

mkdir -p bitstream
mkdir -p python/tests
mkdir -p tools/nuget/bitstream

if [[ ! -f "$BITFILE" ]]; then
    echo "[INFO]: $BITFILE not found - copying one from project directory"
    BITFILE_FOUND=$(find project -name "*.bit" -print -quit)
    LTXFILE_FOUND=$(find project -name "*.ltx" -print -quit)
    if [[ -z "$BITFILE_FOUND" ]]; then
        echo "[ERROR]: No .bit file found either in project directory"
        exit 0
    else
        cp "$BITFILE_FOUND" bitstream/system.bit
        if [[ ! -z "$LTXFILE_FOUND" ]]; then
            cp "$LTXFILE_FOUND" bitstream/system_${VERSION}.ltx
        fi
    fi
fi



# Move and rename the bitfile
cp "$BITFILE" "$PYTHON_TEST_PATH"
cp "$BITFILE" "$NUGET_PATH"
mv "$BITFILE" "$NEW_BITFILE"

echo "Renamed and moved to: $NEW_BITFILE"
echo "Bitstream for Python test: $PYTHON_TEST_PATH"
echo "Bitstream for NuGet: $NUGET_PATH"
