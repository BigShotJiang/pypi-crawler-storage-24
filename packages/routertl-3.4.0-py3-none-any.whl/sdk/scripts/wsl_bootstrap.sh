#!/usr/bin/env bash
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT
#
# RouteRTL WSL2 Bootstrap Script
# ─────────────────────────────────────────────────────────────────
# One-liner to install every system dependency that `routertl doctor`
# expects on a fresh WSL2 Ubuntu (22.04 / 24.04) instance.
#
# Usage:
#   bash sdk/scripts/wsl_bootstrap.sh
#   bash sdk/scripts/wsl_bootstrap.sh --dry-run
#
# Or via curl (from a clean machine):
#   curl -fsSL https://raw.githubusercontent.com/djmazure/routertl/main/sdk/scripts/wsl_bootstrap.sh | bash
#
# The script is idempotent — safe to re-run at any time.
# ─────────────────────────────────────────────────────────────────
set -euo pipefail

# ── Colour helpers ───────────────────────────────────────────────
# Only emit ANSI colours when stdout is a real terminal.
# When piped (curl | bash) or captured, colours are suppressed.
if [ -t 1 ]; then
    GREEN='\033[0;32m'
    YELLOW='\033[1;33m'
    RED='\033[0;31m'
    CYAN='\033[0;36m'
    BOLD='\033[1m'
    NC='\033[0m'
else
    GREEN='' YELLOW='' RED='' CYAN='' BOLD='' NC=''
fi

ok()   { echo -e "${GREEN}✅ $*${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $*${NC}"; }
err()  { echo -e "${RED}❌ $*${NC}"; }
info() { echo -e "${CYAN}ℹ️  $*${NC}"; }
step() { echo -e "\n${BOLD}── $* ──${NC}"; }

# ── Dry-run support ──────────────────────────────────────────────
DRY_RUN=0
for arg in "$@"; do
    case "$arg" in
        --dry-run) DRY_RUN=1 ;;
        --help|-h) echo "Usage: $0 [--dry-run]"; exit 0 ;;
    esac
done

run() {
    if [ $DRY_RUN -eq 1 ]; then
        echo -e "${YELLOW}[dry-run]${NC} $*"
    else
        "$@"
    fi
}

# ── Detect environment ───────────────────────────────────────────
step "Detecting environment"

if [ -f /etc/os-release ]; then
    # shellcheck source=/dev/null
    . /etc/os-release
    DISTRO="${ID:-unknown}"
    VERSION="${VERSION_ID:-0}"
else
    err "Cannot detect OS — /etc/os-release not found."
    exit 1
fi

IS_WSL=0
if grep -qi "microsoft" /proc/version 2>/dev/null; then
    IS_WSL=1
fi

if [ "$DISTRO" != "ubuntu" ]; then
    warn "This script is tested on Ubuntu 22.04/24.04."
    warn "Detected: $DISTRO $VERSION — proceeding anyway."
fi

if [ $IS_WSL -eq 1 ]; then
    ok "WSL2 detected ($DISTRO $VERSION)"
else
    info "Not running under WSL2 — script will still install dependencies."
fi

# ── Helper: version comparison ───────────────────────────────────
version_ge() {
    # Returns 0 (true) if $1 >= $2 using sort -V
    printf '%s\n%s\n' "$2" "$1" | sort -V -C
}

# ── 1. Core apt packages ────────────────────────────────────────
step "Installing core apt packages"

APT_PACKAGES=(
    # Build essentials
    build-essential
    git
    git-lfs
    python3
    python3-pip
    python3-venv
    make
    curl
    wget

    # NVC build dependencies (for 22.04 source build fallback)
    automake
    flex
    pkg-config
    zlib1g-dev
    libdw-dev
    libffi-dev

    # GHDL build dependencies
    gnat
    llvm-dev
)

# On 24.04+, Verilator is available via apt and is v5.x (cocotb 2.0+ compatible)
if version_ge "$VERSION" "24.04"; then
    APT_PACKAGES+=(verilator)
fi

run sudo apt-get update -y
run sudo apt-get install -y "${APT_PACKAGES[@]}"

ok "Core apt packages installed"

# ── 2. Git LFS ──────────────────────────────────────────────────
step "Configuring Git LFS"

if command -v git-lfs >/dev/null 2>&1; then
    run git lfs install
    ok "Git LFS configured"
else
    err "git-lfs not found after apt install — check errors above"
    exit 1
fi

# ── 3. NVC (VHDL simulator) ─────────────────────────────────────
step "Installing NVC 1.19.3"

if command -v nvc >/dev/null 2>&1; then
    NVC_VER=$(nvc --version 2>&1 | head -1 || true)
    ok "NVC already installed: $NVC_VER"
else
    info "Installing NVC 1.19.3 from .deb package..."

    # Determine correct .deb for the Ubuntu version
    if version_ge "$VERSION" "24.04"; then
        NVC_DEB_URL="https://github.com/nickg/nvc/releases/download/r1.19.3/nvc_1.19.3-1_amd64_ubuntu-24.04.deb"
    else
        NVC_DEB_URL="https://github.com/nickg/nvc/releases/download/r1.19.3/nvc_1.19.3-1_amd64_ubuntu-22.04.deb"
    fi

    NVC_TMP="/tmp/nvc_1.19.3.deb"
    run wget -qO "$NVC_TMP" "$NVC_DEB_URL"
    run sudo dpkg -i "$NVC_TMP"
    run rm -f "$NVC_TMP"
    ok "NVC 1.19.3 installed"
fi

# ── 4. GHDL (VHDL analyser for smart linting) ───────────────────
step "Installing GHDL 6.0+"

if command -v ghdl >/dev/null 2>&1; then
    GHDL_VER=$(ghdl --version 2>&1 | head -1 || true)
    ok "GHDL already installed: $GHDL_VER"
else
    info "Building GHDL from source (this takes a few minutes)..."
    GHDL_TMP="/tmp/ghdl-build"
    run rm -rf "$GHDL_TMP"
    run git clone --depth 1 https://github.com/ghdl/ghdl.git "$GHDL_TMP"

    if [ $DRY_RUN -eq 0 ]; then
        cd "$GHDL_TMP"
        mkdir -p build && cd build
        ../configure --prefix=/usr/local --with-llvm-config
        make -j"$(nproc)"
        sudo make install
        cd /
        rm -rf "$GHDL_TMP"
    else
        echo -e "${YELLOW}[dry-run]${NC} cd $GHDL_TMP && mkdir build && cd build"
        echo -e "${YELLOW}[dry-run]${NC} ../configure --prefix=/usr/local --with-llvm-config"
        echo -e "${YELLOW}[dry-run]${NC} make -j\$(nproc) && sudo make install"
    fi

    ok "GHDL installed"
fi

# ── 5. Verilator (for 22.04 — skip with note) ───────────────────
if ! version_ge "$VERSION" "24.04"; then
    if command -v verilator >/dev/null 2>&1; then
        VER_VER=$(verilator --version 2>&1 || true)
        ok "Verilator already installed: $VER_VER"
    else
        warn "Verilator is not available via apt on Ubuntu 22.04."
        warn "Cocotb 2.0+ requires Verilator 5.x for SystemVerilog simulation."
        info "To build from source (optional, ~10 min):"
        echo "  git clone https://github.com/verilator/verilator /tmp/verilator"
        echo "  cd /tmp/verilator && git checkout v5.036"
        echo "  autoconf && ./configure && make -j\$(nproc) && sudo make install"
    fi
fi

# ── 6. Python: RouteRTL SDK ─────────────────────────────────────
step "Installing RouteRTL SDK"

if command -v routertl >/dev/null 2>&1 || command -v rr >/dev/null 2>&1; then
    ok "RouteRTL CLI already available"
else
    info "Installing routertl from PyPI..."
    run pip install --user routertl
    ok "RouteRTL installed"
fi

# ── 7. Final validation ─────────────────────────────────────────
step "Running routertl doctor"

if [ $DRY_RUN -eq 1 ]; then
    echo -e "${YELLOW}[dry-run]${NC} routertl doctor"
else
    if command -v routertl >/dev/null 2>&1; then
        routertl doctor || true
    elif command -v rr >/dev/null 2>&1; then
        rr doctor || true
    else
        warn "RouteRTL not on PATH yet — restart your shell and run: routertl doctor"
    fi
fi

# ── Done ─────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  RouteRTL WSL2 Bootstrap Complete!${NC}"
echo -e "${BOLD}════════════════════════════════════════════════════════════════${NC}"
echo ""
echo -e "  Next steps:"
echo -e "    1. Create a project:  ${CYAN}mkdir my_project && cd my_project${NC}"
echo -e "    2. Initialise:        ${CYAN}routertl init --name my_project --vendor xilinx --part xc7z020clg400-1${NC}"
echo -e "    3. Verify:            ${CYAN}source .venv/bin/activate && routertl doctor${NC}"
echo ""
echo -e "  📖 Full guide: ${CYAN}https://routertl.com/guides/INSTALLATION/${NC}"
echo -e "  🚀 Tutorial:   ${CYAN}https://routertl.com/guides/FIRST_STEPS_TUTORIAL/${NC}"
echo ""
