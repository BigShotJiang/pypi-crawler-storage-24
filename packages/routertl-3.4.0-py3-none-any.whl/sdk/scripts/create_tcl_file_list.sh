#!/usr/bin/env bash
echo "Number of arguments: $#"

output_file="$1/tcl/lattice/file_list.tcl"

design_file_types=("root_dir" "src_files" "xci_files" "sim_files" "tcl_files" "xdc_files")

counter=0
for arg in "$@"
do
    if [ $counter -eq 0 ]; then
        echo -e "set g_root_dir ${arg}"
    else
        file_type=${design_file_types[$counter]}
        echo -e "set ${file_type} [list ${arg}]" >> $output_file
    fi

    ((counter++))
done
