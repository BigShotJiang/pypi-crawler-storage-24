#!/bin/bash
# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

#!/bin/bash

# Usage:
#   ./script.sh /path/to/folder stringA stringB [--dry-run]

folder_path=$1
stringA=$2
stringB=$3
mode=$4  # optional: --dry-run

if [ -z "$folder_path" ] || [ -z "$stringA" ] || [ -z "$stringB" ]; then
  echo "Usage: $0 /path/to/folder stringA stringB [--dry-run]"
  exit 1
fi

if [ ! -d "$folder_path" ]; then
  echo "❌ Error: '$folder_path' is not a directory."
  exit 1
fi

dry_run=0
if [[ "$mode" == "--dry-run" ]]; then
  dry_run=1
fi

echo
[[ "$dry_run" -eq 1 ]] && echo "🔍 DRY-RUN: Searching for files containing '$stringA'..." || echo "🛠️ Replacing '$stringA' with '$stringB'..."
echo

# Create a temp file to store matching file paths
modified_files=()
scanned=0

while IFS= read -r -d '' file; do
  ((scanned++))
  if grep -q -- "$stringA" "$file"; then
    if [[ "$dry_run" -eq 1 ]]; then
      echo "[would modify] $file"
    else
      perl -pi -e "s/\Q$stringA\E/$stringB/g" "$file"
      echo "[modified] $file"
    fi
    modified_files+=("$file")
  fi
done < <(find "$folder_path" -type f -not -path '*/.*/*' -print0)

# Final summary
echo
if [[ "${#modified_files[@]}" -eq 0 ]]; then
  echo "ℹ️ No files contained the string '$stringA'."
else
  echo "✅ ${#modified_files[@]} file(s) ${dry_run:+would be }modified (scanned $scanned total)."
fi
