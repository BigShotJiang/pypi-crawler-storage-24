#!/usr/bin/env bash
# Build Linux Kernel from Xilinx/linux-xlnx source
set -euo pipefail

PROJECT_ROOT=${PROJECT_ROOT:-$(pwd)}
LINUX_SRC_DIR=${LINUX_SRC_DIR:-"$PROJECT_ROOT/linux/src"}
LINUX_OUT_DIR=${LINUX_OUT_DIR:-"$PROJECT_ROOT/linux/out"}
KERNEL_DEFCONFIG=${KERNEL_DEFCONFIG:-xilinx_zynq_defconfig}
ARCH=${ARCH:-arm}
CROSS_COMPILE=${CROSS_COMPILE:-arm-linux-gnueabihf-}

KERNEL_DIR="$LINUX_SRC_DIR/linux-xlnx"
KERNEL_DEFAULT_REPO="https://github.com/Xilinx/linux-xlnx.git"
KERNEL_REPO="${KERNEL_REPO:-$KERNEL_DEFAULT_REPO}"

echo "========================================"
echo "Building Linux Kernel for $KERNEL_DEFCONFIG"
echo "========================================"

mkdir -p "$LINUX_SRC_DIR"
mkdir -p "$LINUX_OUT_DIR"

if [ ! -d "$KERNEL_DIR" ]; then
    echo "Cloning Kernel source from $KERNEL_REPO (this may take a while)..."
    git clone --depth 1 --branch xlnx_rebase_v6.6_LTS "$KERNEL_REPO" "$KERNEL_DIR"
fi

cd "$KERNEL_DIR"

if [ -n "${KERNEL_PATCH_SCRIPT:-}" ] && [ -x "$KERNEL_PATCH_SCRIPT" ]; then
    echo "Applying custom Kernel patches via $KERNEL_PATCH_SCRIPT..."
    "$KERNEL_PATCH_SCRIPT"
fi

echo "Configuring Kernel..."
make ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE $KERNEL_DEFCONFIG

if [ -n "${KERNEL_CONFIG_FRAGMENTS:-}" ]; then
    echo "Merging custom Kernel config fragments: $KERNEL_CONFIG_FRAGMENTS"
    ./scripts/kconfig/merge_config.sh -m .config $KERNEL_CONFIG_FRAGMENTS
    make ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE olddefconfig
fi

echo "Compiling Kernel..."
make ARCH=$ARCH CROSS_COMPILE=$CROSS_COMPILE -j"$(nproc)" UIMAGE_LOADADDR=0x8000 uImage modules

cp arch/$ARCH/boot/uImage "$LINUX_OUT_DIR/uImage"
echo "✅ Linux Kernel built: $LINUX_OUT_DIR/uImage"
