# RouteRTL SDK Package

The `sdk/` directory is the **open-shell** layer of the RouteRTL SDK — all
Python and build-system code shipped under the MIT license.

## Directory Structure

```text
sdk/
├── cli/              CLI entry point and command implementations
│   ├── commands/     Click command modules (sim, docker, fpga, …)
│   ├── tests/        CLI-level tests (SPDX, license, resilience)
│   ├── main.py       Root CLI group and plugin loader
│   ├── console.py    Shared Rich console instance
│   ├── resilience.py Exception-safe decorator framework
│   └── sdk_root.py   SDK path auto-detection
├── engine/           Build-system core (linting, project init, deps)
│   ├── tests/        Engine-level tests (regression, docker smoke)
│   ├── dependency_resolver.py
│   ├── init_project.py
│   ├── show_target_help.py
│   └── ...
├── generators/       Code-generation tools
│   ├── bridge/       AXI/Avalon bridge RTL generator
│   ├── cocotb/       cocotb testbench scaffolder
│   ├── constraints/  Constraint file generator
│   ├── ila/          Integrated Logic Analyzer generator
│   ├── linux/        Embedded Linux devicetree/driver generator
│   ├── regbank/      YAML → HDL/Python/C register bank generator
│   └── report/       Vivado report parser
├── infra/            Infrastructure and deployment
│   └── docker/       Dockerfiles, compose files, and entry scripts
├── mk/               Makefile fragments (Common.mk stubs)
├── scripts/          Shell helpers (linting.sh, repair_venv.sh, …)
└── Common.mk         Top-level Makefile include
```

## Relationship to `routertl_core/`

The proprietary engine (`routertl_core/`) contains the compiled-core
counterparts of some `sdk/engine/` scripts (e.g. `smart_linter.py`,
`dependency_resolver.py`).  At runtime, `routertl_core/` takes
precedence when installed; the `sdk/engine/` versions act as thin
proxies that delegate to the core.

## Relationship to `tools/`

The top-level `tools/` directory contains only a Python backward-
compatibility shim (`__init__.py`) that redirects `from tools.X`
imports to `from sdk.X` with a `DeprecationWarning`.  All real code
lives here in `sdk/`.
