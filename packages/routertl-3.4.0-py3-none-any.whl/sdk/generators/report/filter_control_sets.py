# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import argparse
import re


def parse_ratio(ratio_str):
    """Parse a 'used/available' string into (used, available)."""
    try:
        _, rhs = ratio_str.split(":")
        return float(rhs)
    except (ValueError, TypeError):
        return None


def extract_control_set_rows(filepath, min_ctrl_sets=5, max_ratio=20):
    """Extract control set rows from a utilization report."""
    results = []
    header_row = None
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            if "Instance" in line and "Total Control Sets" in line and "Ratio" in line:
                header_row = [c.strip() for c in line.strip().split("|") if c.strip()]
                header_row.insert(5, "Merit")
                continue

            if re.match(r"^\|\s+\S.*\|\s+\S.*\|\s+\d+\s+\|", line):
                cols = [c.strip() for c in line.strip().split("|")[1:-1]]
                if len(cols) < 5:
                    continue

                instance, module, total_ctrl_sets_str, total_ffs_str, ratio_str = cols[:5]

                try:
                    total_ctrl_sets = int(total_ctrl_sets_str)
                    total_ffs = int(total_ffs_str)
                    ratio_val = parse_ratio(ratio_str)
                except ValueError:
                    continue

                if total_ctrl_sets >= min_ctrl_sets and ratio_val is not None and ratio_val <= max_ratio:
                    merit = total_ffs / ratio_val if ratio_val else 0
                    results.append(
                        {
                            "instance": instance.strip(),
                            "module": module.strip(),
                            "control_sets": total_ctrl_sets,
                            "ffs": total_ffs,
                            "ratio": f"1:{int(ratio_val)}",
                            "merit": merit,
                        }
                    )
    return header_row, results


def format_and_print_table(header, results):
    """Format and print a table of control set data."""
    rows = [
        [r["instance"], r["module"], str(r["control_sets"]), str(r["ffs"]), r["ratio"], f"{r['merit']:.1f}"]
        for r in results
    ]
    all_rows = [header] + rows
    col_widths = [max(len(str(cell)) for cell in col) for col in zip(*all_rows)]

    def format_row(row):
        """Format a single control set row for display."""
        return "| " + " | ".join(f"{str(cell):<{w}}" for cell, w in zip(row, col_widths)) + " |"

    border = "|" + "+".join("-" * (w + 2) for w in col_widths) + "|"
    print(border)
    print(format_row(header))
    print(border)
    for row in rows:
        print(format_row(row))
    print(border)


def save_results_to_file(header, results, output_path):
    """Save control set analysis results to a file."""
    with open(output_path, "w", encoding="utf-8") as f:
        rows = [
            [r["instance"], r["module"], str(r["control_sets"]), str(r["ffs"]), r["ratio"], f"{r['merit']:.1f}"]
            for r in results
        ]
        all_rows = [header] + rows
        col_widths = [max(len(str(cell)) for cell in col) for col in zip(*all_rows)]

        def format_row(row):
            """Format a single result row for file output."""
            return "| " + " | ".join(f"{str(cell):<{w}}" for cell, w in zip(row, col_widths)) + " |"

        border = "|" + "+".join("-" * (w + 2) for w in col_widths) + "|"
        f.write(border)
        f.write(format_row(header) + "\n")
        f.write(border)
        for row in rows:
            f.write(format_row(row) + "\n")
        f.write(border)


def main():
    """CLI entry point for control set filter."""
    parser = argparse.ArgumentParser(description="Filter Vivado control sets report with aligned merit column.")
    parser.add_argument("rpt_path", help="Path to the control_sets.rpt file")
    parser.add_argument("--min_sets", type=int, default=5, help="Minimum control sets (default: 5)")
    parser.add_argument("--max_ratio", type=float, default=20.0, help="Maximum FF/control set ratio (default: 20.0)")
    parser.add_argument(
        "--sort", choices=["ratio", "ffs", "merit"], default="merit", help="Sorting key (default: merit)"
    )
    parser.add_argument("--desc", action="store_true", help="Sort in descending order")
    parser.add_argument("--output", help="Optional output file to save the results")
    args = parser.parse_args()

    header, filtered = extract_control_set_rows(args.rpt_path, args.min_sets, args.max_ratio)

    if not filtered:
        print("✅ No modules matched the filtering criteria.")
    else:
        filtered.sort(key=lambda x: x[args.sort], reverse=args.desc)
        print(
            f"\n🎯 Found {len(filtered)} module(s) with at least {args.min_sets} control sets and ratio ≤ 1:{args.max_ratio:.0f}, sorted by {args.sort}:\n"
        )
        format_and_print_table(header, filtered)

        if args.output:
            save_results_to_file(header, filtered, args.output)
            print(f"\n📝 Results written to: {args.output}")


if __name__ == "__main__":
    main()
