# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

import argparse
import logging

logging.basicConfig(
    level=logging.INFO,
    format="%(levelname)s: %(message)s",  # removes logger name
)
log = logging.getLogger("dbg")
log.setLevel(logging.INFO)  # Enable this to see debug prints


def extract_table(filepath):
    """Extract a table section from a utilization report."""
    table_lines = []
    with open(filepath, "r", encoding="utf-8") as f:
        lines = f.readlines()

    in_table = False
    for line in lines:
        if not in_table and "|" in line and "Instance" in line and "Module" in line:
            in_table = True
            table_lines.append(line.strip())  # Header
            continue
        if in_table:
            if line.strip().startswith("|"):
                table_lines.append(line.strip())
            elif line.strip().startswith("+"):
                continue
            else:
                break
    return table_lines


def split_row(row, preserve_instance_indent=False):
    """Split a pipe-delimited report row into fields."""
    cols = row.strip("|").split("|")
    if preserve_instance_indent:
        # Only strip columns other than the first (instance column)
        return [cols[0]] + [col.strip() for col in cols[1:]]
    else:
        return [col.strip() for col in cols]


def get_indent_level(instance_field):
    """Determine hierarchy indent level from leading whitespace."""
    return len(instance_field) - len(instance_field.lstrip())


def mark_hierarchy(rows, start_idx, max_depth):
    """Mark hierarchical parent-child relationships in rows."""
    result = [rows[start_idx]]
    base_indent = get_indent_level(split_row(rows[start_idx], preserve_instance_indent=True)[0])
    log.debug(f"Base indent for matched row {start_idx}: {base_indent}")
    i = start_idx + 1
    while i < len(rows):
        instance_field = split_row(rows[i], preserve_instance_indent=True)[0]
        current_indent = get_indent_level(instance_field)
        rel_depth = current_indent - base_indent
        log.debug(f"Row {i}: indent={current_indent}, rel_depth={rel_depth}")
        if rel_depth <= 0:
            break  # This ends current hierarchy block
        if rel_depth <= max_depth:
            row_parts = split_row(rows[i])
            row_parts[0] = "*" * rel_depth + " " + row_parts[0].lstrip()
            new_row = "| " + " | ".join(row_parts) + " |"
            log.debug(f"Adding: {new_row}")
            result.append(new_row)
        i += 1
    return result


def align_and_print(header, rows):
    """Align and pretty-print utilization table rows."""
    all_rows = [split_row(header)] + [split_row(row) for row in rows]
    col_widths = [max(len(col) for col in col_vals) for col_vals in zip(*all_rows)]

    def format_row(row):
        """Format a single utilization row for aligned display."""
        return "| " + " | ".join(f"{col:<{w}}" for col, w in zip(row, col_widths)) + " |"

    print("|" + "+".join("-" * (w + 2) for w in col_widths) + "|")
    print(format_row(all_rows[0]))
    print("|" + "+".join("-" * (w + 2) for w in col_widths) + "|")
    for row in all_rows[1:]:
        print(format_row(row))


def main():
    """CLI entry point for utilization filter."""
    parser = argparse.ArgumentParser(description="Extract and align module rows from Vivado utilization report.")
    parser.add_argument(
        "--report_path",
        default="../../reports/utilization/hierarchical_utilization.rpt",
        help="Path to the Vivado report file",
    )
    parser.add_argument("--mod", required=True, help="Module name to filter for (substring match)")
    parser.add_argument("--depth", type=int, default=0, help="Hierarchy levels to include after match")
    parser.add_argument("--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    if args.debug:
        log.setLevel(logging.DEBUG)
        log.debug("Debug logging enabled.")

    module_name = args.mod

    table_lines = extract_table(args.report_path)
    if not table_lines:
        print("❌ No table found.")
        return

    header, *data_rows = table_lines
    matching_indices = [i for i, row in enumerate(data_rows) if module_name.lower() in split_row(row)[1].lower()]

    if not matching_indices:
        print(f"🔍 No matches found for: {module_name}")
        return

    log.debug(f"Matching row indices: {matching_indices}")

    final_rows = []
    for idx in matching_indices:
        final_rows.extend(mark_hierarchy(data_rows, idx, args.depth))

    align_and_print(header, final_rows)


if __name__ == "__main__":
    main()
