#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Reads the target from system_memory_map.yml and looks up its properties
in supported_targets.yml. Emits Makefile variables to stdout.
"""

import os
import sys

import yaml


def main():
    """CLI entry point for target configuration loader."""
    if len(sys.argv) != 3:
        print("Usage: get_target_config.py <system_memory_map.yml> <supported_targets.yml>")
        sys.exit(1)

    mmap_path = sys.argv[1]
    db_path = sys.argv[2]

    if not os.path.exists(mmap_path):
        # Default to zynq-7000 if no mmap is present yet
        target = "zynq-7000"
    else:
        try:
            with open(mmap_path, "r") as f:
                data = yaml.safe_load(f)
                target = data.get("target", "zynq-7000")
        except (OSError, ValueError):
            target = "zynq-7000"

    if not os.path.exists(db_path):
        print(f"Error: Target database {db_path} not found.", file=sys.stderr)
        sys.exit(1)

    with open(db_path, "r") as f:
        db = yaml.safe_load(f)

    targets = db.get("targets", {})
    if target not in targets:
        print(f"Error: Target '{target}' not found in {db_path}.", file=sys.stderr)
        sys.exit(1)

    config = targets[target]

    # Emit Makefile export variables
    print(f"LINUX_TARGET={target}")
    print(f"LINUX_ARCH={config.get('cpu_arch', 'arm')}")
    print(f"LINUX_CROSS_COMPILE={config.get('cross_compile', 'arm-linux-gnueabihf-')}")


if __name__ == "__main__":
    main()
