#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Shared parser for system_memory_map.yml used by all codegen tools.
"""

import os
import sys

import yaml


class MemoryMapParser:
    def __init__(self, yaml_path):
        """Create a memory map parser for the given XSA file."""
        self.yaml_path = yaml_path
        self.data = self._load_and_validate()
        self.version = self.data.get("version", "1.0.0")
        self.target = self.data.get("target", "unknown")
        self.devices = self.data.get("devices", [])

    def _load_and_validate(self):
        if not os.path.exists(self.yaml_path):
            print(f"Error: {self.yaml_path} not found.")
            sys.exit(1)

        with open(self.yaml_path, "r") as f:
            try:
                data = yaml.safe_load(f)
            except yaml.YAMLError as exc:
                print(f"Error parsing {self.yaml_path}: {exc}")
                sys.exit(1)

        # Basic schema validation
        required_fields = ["version", "devices"]
        for field in required_fields:
            if field not in data:
                print(f"Error: Missing required field '{field}' in {self.yaml_path}")
                sys.exit(1)

        # Load supported targets database
        db_path = os.path.join(os.path.dirname(__file__), "supported_targets.yml")
        if not os.path.exists(db_path):
            print(f"Error: Target database not found at {db_path}")
            sys.exit(1)

        with open(db_path, "r") as f:
            valid_db = yaml.safe_load(f)

        valid_targets = list(valid_db.get("targets", {}).keys())

        # Infer target from project.yml if not in system_memory_map.yml
        target = data.get("target")
        if not target:
            # Try to infer from project.yml
            proj_yaml = os.path.join(os.path.dirname(os.path.abspath(self.yaml_path)), "project.yml")
            if os.path.exists(proj_yaml):
                try:
                    with open(proj_yaml, "r") as pf:
                        proj_data = yaml.safe_load(pf) or {}
                        part = proj_data.get("hardware", {}).get("part", "").lower()
                        if part.startswith("xc7z"):
                            target = "zynq-7000"
                        elif part.startswith("xczu"):
                            target = "zynqmp"
                        elif part.startswith("mpfs"):
                            target = "polarfire-soc"
                        # Extend as needed for other vendors
                except yaml.YAMLError:
                    pass

            if not target:
                print(f"Error: Could not infer 'target' from project.yml. Please specify 'target' in {self.yaml_path}")
                sys.exit(1)

            # Update data so it has target
            data["target"] = target

        if data["target"] not in valid_targets:
            print(f"Error: Invalid 'target' = '{data['target']}' in {self.yaml_path}.")
            print(f"       Must be one of: {', '.join(valid_targets)}")
            sys.exit(1)

        if not isinstance(data["devices"], list):
            print(f"Error: 'devices' must be a list in {self.yaml_path}")
            sys.exit(1)

        for i, dev in enumerate(data["devices"]):
            if "name" not in dev:
                print(f"Error: Device {i} missing 'name'")
                sys.exit(1)
            if "base_addr" not in dev:
                print(f"Error: Device '{dev['name']}' missing 'base_addr'")
                sys.exit(1)
            if "span" not in dev:
                print(f"Error: Device '{dev['name']}' missing 'span'")
                sys.exit(1)

            # Convert hex strings to ints if needed
            if isinstance(dev["base_addr"], str):
                dev["base_addr"] = int(dev["base_addr"], 0)
            if isinstance(dev["span"], str):
                dev["span"] = int(dev["span"], 0)

            # Validate optional regbank_ref path
            if "regbank_ref" in dev:
                ref_path = os.path.join(os.path.dirname(os.path.abspath(self.yaml_path)), dev["regbank_ref"])
                if not os.path.exists(ref_path):
                    print(
                        f"Error: Device '{dev['name']}' references regbank_ref '{dev['regbank_ref']}', but the file {ref_path} does not exist."
                    )
                    sys.exit(1)

        return data

    def get_uio_devices(self):
        """Return list of devices where uio is true (default)."""
        return [dev for dev in self.devices if dev.get("uio", True)]


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: memory_map_parser.py <path_to_yml>")
        sys.exit(1)

    parser = MemoryMapParser(sys.argv[1])
    print(f"Loaded {len(parser.devices)} devices for target {parser.target}")
    for dev in parser.get_uio_devices():
        print(f"  UIO Device: {dev['name']} at {hex(dev['base_addr'])} (span {hex(dev['span'])})")
