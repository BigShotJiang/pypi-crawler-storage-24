#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
Parse Vivado XSA files and extract hardware information from the internal .hwh XML.
Used to cross-check the YAML memory map against the actual implemented hardware.
"""

import argparse
import os
import sys
import xml.etree.ElementTree as ET
import zipfile

from memory_map_parser import MemoryMapParser


class XSAParser:
    def __init__(self, xsa_path):
        """Create an XSA parser for the given archive path."""
        self.xsa_path = xsa_path
        if not os.path.exists(xsa_path):
            raise FileNotFoundError(f"XSA file not found: {xsa_path}")
        self._xml_root = self._extract_hwh()

    def _extract_hwh(self):
        with zipfile.ZipFile(self.xsa_path, "r") as z:
            hwh_files = [f for f in z.namelist() if f.endswith(".hwh")]
            if not hwh_files:
                raise FileNotFoundError("No .hwh file found in XSA archive.")
            with z.open(hwh_files[0]) as f:
                return ET.parse(f).getroot()

    def get_module_info(self, instance_name):
        """
        Extract base address, high address, and interrupts for a given module instance.
        """
        for module in self._xml_root.findall(".//MODULE"):
            # Xilinx HWH sometimes prefixes instance names or keeps them exact
            # We do a loose match if exact fails, but exact is preferred.
            inst = module.get("INSTANCE", "")
            if inst == instance_name or inst.endswith(f"_{instance_name}") or inst.endswith(f"/{instance_name}"):
                info = {"base_addr": None, "high_addr": None, "interrupts": []}

                # 1. Search in PATAMETERS (common for AXI IP)
                for param in module.findall(".//PARAMETER"):
                    name = param.get("NAME")
                    val = param.get("VALUE", "")
                    if name == "C_BASEADDR" and val.startswith("0x"):
                        info["base_addr"] = int(val, 0)
                    elif name == "C_HIGHADDR" and val.startswith("0x"):
                        info["high_addr"] = int(val, 0)

                # 2. Search in MEMORYMAP/ADDRESSBLOCK (common for block designs)
                if info["base_addr"] is None:
                    for addr_block in module.findall(".//ADDRESSBLOCK"):
                        base = addr_block.get("BASEVALUE")
                        high = addr_block.get("HIGHVALUE")
                        if base and base.startswith("0x"):
                            info["base_addr"] = int(base, 0)
                        if high and high.startswith("0x"):
                            info["high_addr"] = int(high, 0)

                # 3. Search for Interrupts
                for port in module.findall(".//PORT"):
                    if port.get("SIGIS") == "INTERRUPT":
                        info["interrupts"].append(port.get("NAME"))

                return info
        return None


def cross_check(yaml_path, xsa_path):
    """Cross-check parsed data against a reference memory map."""
    print("========================================")
    print(f"Cross-checking HW: {xsa_path}")
    print(f"Against SW YAML:   {yaml_path}")
    print("========================================")

    mmap = MemoryMapParser(yaml_path)
    try:
        xsa = XSAParser(xsa_path)
    except (OSError, zipfile.BadZipFile, ET.ParseError) as e:
        print(f"❌ Error parsing XSA: {e}")
        return False

    success = True
    for dev in mmap.devices:
        name = dev["name"]
        yaml_base = dev["base_addr"]

        info = xsa.get_module_info(name)
        if not info:
            print(f"⚠️  Warning: Module '{name}' defined in YAML but missing from XSA.")
            continue

        xsa_base = info["base_addr"]

        if xsa_base is not None:
            if xsa_base != yaml_base:
                print(f"❌ Error: Address Mismatch for '{name}'!")
                print(f"   YAML says: 0x{yaml_base:x}")
                print(f"   XSA says:  0x{xsa_base:x}")
                success = False
            else:
                print(f"✅ Address match: '{name}' @ 0x{xsa_base:x}")
        else:
            print(f"⚠️  Warning: Could not extract base address for '{name}' from XSA.")

        # Report interrupts
        if info["interrupts"]:
            print(f"   ↳ Interrupts found: {', '.join(info['interrupts'])}")

    if success:
        print("\n✅ Verification Passed: Software memory map matches hardware.")
    else:
        print("\n❌ Verification Failed: Address mismatches detected.")

    return success


def main():
    """CLI entry point for XSA parser."""
    parser = argparse.ArgumentParser(description="Cross-check XSA hardware against memory map YAML")
    parser.add_argument("yaml", help="Path to system_memory_map.yml")
    parser.add_argument("xsa", help="Path to exported .xsa file")
    args = parser.parse_args()

    if not cross_check(args.yaml, args.xsa):
        sys.exit(1)


if __name__ == "__main__":
    main()
