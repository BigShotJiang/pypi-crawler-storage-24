#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
import logging
import re
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

SRC_DIR_DEFAULT = "src"
TEST_ROOT_DEFAULT = "sim/cocotb/tests"
EXCLUDE_PATTERNS = ["_pkg.vhd", "wrapper_", "top.vhd"]


# --- GENERIC PARSER ---


def parse_generics(vhdl_path: Path) -> Tuple[Optional[str], List[Dict[str, str]]]:
    """Parse VHDL generics from entity declarations."""
    text = vhdl_path.read_text()
    entity_re = re.compile(r"(?i)entity\s+(\w+)\s+is\s+generic\s*\((.*?)\)\s*;", re.DOTALL | re.MULTILINE)
    match = entity_re.search(text)
    if not match:
        return None, []

    entity_name, generic_block = match.groups()
    generic_lines = re.split(r";\s*", generic_block.strip())
    generics = []

    generic_line_re = re.compile(r"(?P<name>\w+)\s*:\s*(?P<type>[^:=]+?)(?:\s*:=\s*(?P<default>.+))?$", re.IGNORECASE)

    for line in generic_lines:
        line = line.strip()
        if not line or line.startswith("--"):
            continue
        m = generic_line_re.match(line)
        if m:
            default_val = m.group("default").strip() if m.group("default") else "None"
            # Strip VHDL comments from default value
            if "--" in default_val:
                default_val = default_val.split("--")[0].strip()
            # Convert VHDL values to Python-compatible
            default_val = convert_vhdl_to_python(default_val)
            generics.append({"name": m.group("name"), "type": m.group("type").strip(), "default": default_val})

    return entity_name, generics


def convert_vhdl_to_python(val: str) -> str:
    """Convert VHDL default values to Python-compatible format."""
    val_upper = val.upper()
    # Boolean conversion
    if val_upper in ("TRUE", "FALSE"):
        return val_upper.capitalize()
    # String values (VHDL uses double quotes, keep them)
    if val.startswith('"') and val.endswith('"'):
        return val
    # Integer/numeric - keep as-is
    return val


# --- MAIN LOGIC ---


def should_exclude(filename: str, exclude_patterns: List[str]) -> bool:
    """Return True if a file should be excluded from scanning."""
    return any(pattern in filename for pattern in exclude_patterns)


def generate_test_skeletons(
    src_dir: Path, base_path: Path, test_root: Path, exclude_patterns: List[str], dry_run: bool = False
) -> List[Path]:
    """Generate cocotb test skeleton files for discovered entities."""
    created_files = []

    # Build the entity map once
    entity_map = build_entity_map(src_dir)
    package_map = build_package_map(src_dir)

    for vhd_path in src_dir.rglob("*.vhd"):
        if should_exclude(vhd_path.name, exclude_patterns):
            logging.debug(f"Skipping excluded file: {vhd_path}")
            continue

        rel_path = vhd_path.relative_to(src_dir)
        module_name = vhd_path.stem
        test_subdir = test_root / rel_path.parent
        test_filename = test_subdir / f"test_{module_name}.py"

        if test_filename.exists():
            logging.debug(f"Test already exists: {test_filename}")
            continue

        # Parse generics from the file
        entity_name, generics = parse_generics(vhd_path)
        if entity_name and entity_name.lower() != module_name.lower():
            logging.warning(f"Entity name '{entity_name}' does not match file name '{module_name}'")

        if generics:
            logging.debug(
                f"Parsed generics for {module_name}: " + ", ".join(f"{g['name']}={g['default']}" for g in generics)
            )
        else:
            logging.debug(f"No generics found for {module_name}")

        if generics:
            template_text = load_template("with_generics.py.j2")
        else:
            template_text = load_template("no_generics.py.j2")

        # Always define these so .format() doesn't crash
        param_names = ", ".join(g["name"] for g in generics) if generics else ""
        param_values = ", ".join(g["default"] for g in generics) if generics else ""
        param_dict = ", ".join(f'"{g["name"]}": {g["name"]}' for g in generics) if generics else ""

        # Resolve full dependencies using entity name
        full_deps = resolve_all_dependencies(module_name, entity_map, package_map)
        if not full_deps:
            logging.warning(f"Skipping {module_name}: no dependencies found")
            continue

        logging.debug(f"All dependencies for {module_name}: {[p.name for p in full_deps]}")

        entity_lib_map = build_entity_library_map(src_dir)
        libraries_dict = defaultdict(list)

        for path in reversed(full_deps):
            ent_name = path.stem
            lib = entity_lib_map.get(ent_name, "work")
            libraries_dict[lib].append(path)

        # Generate the HDL source list after full_deps is populated
        hdl_sources = [p.resolve() for p in reversed(full_deps)]
        hdl_sources_rel = [str(p.relative_to(base_path).as_posix()) for p in hdl_sources]

        hdl_sources_list = ",\n            ".join(f'"{p}"' for p in hdl_sources_rel)

        pretty_param_dict = ",\n            ".join(f'"{g["name"]}": {g["name"]}' for g in generics)

        # Generate param dict with actual default values (for templates that define GENERICS dict)
        param_dict_with_defaults = ",\n    ".join(f'"{g["name"]}": {g["default"]}' for g in generics)

        libraries_block = ",\n            ".join(
            f'"{lib}": [\n'
            + " " * 16
            + (",\n" + " " * 16).join(
                f'"{p.as_posix() if base_path == Path.cwd() else p.relative_to(base_path).as_posix()}"' for p in paths
            )
            + "\n            ]"
            for lib, paths in libraries_dict.items()
        )

        # Extract and comment entity block for the current module
        entity_block = extract_entity_block(vhd_path, module_name)
        entity_comment = make_entity_comment(entity_block, module_name, vhd_path)

        template = template_text.format(
            module_name=module_name,
            rtl_path_posix=hdl_sources_rel[0],  # optional: still keep this as reference
            hdl_sources_list=hdl_sources_list,
            libraries_block=libraries_block,
            param_names=param_names,
            param_values=param_values,
            param_dict=pretty_param_dict,
            param_dict_with_defaults=param_dict_with_defaults,
            entity_comment=entity_comment,
        )

        # Log direct instantiations
        instantiated = find_instantiated_entities(vhd_path)
        for lib, ent_name in instantiated:
            logging.debug(f"Direct instantiation found in {module_name}: {lib}.{ent_name}")

        if not dry_run:
            test_subdir.mkdir(parents=True, exist_ok=True)
            with open(test_filename, "w") as f:
                f.write(template)

        created_files.append(test_filename)

    return created_files


def load_template(name: str) -> str:
    """Load a Jinja2 template from the templates directory."""
    template_dir = Path(__file__).parent / "templates"
    return (template_dir / name).read_text()


def find_instantiated_entities(vhdl_path: Path) -> List[Tuple[str, str]]:
    """Find entity names instantiated within VHDL source files."""
    text = vhdl_path.read_text()

    # Match: label : entity lib.ent
    ENTITY_INSTANCE_RE = re.compile(r"(?P<label>\w+)\s*:\s*entity\s+(?P<lib>\w+)\.(?P<ent>\w+)", re.IGNORECASE)
    entity_matches = ENTITY_INSTANCE_RE.findall(text)
    entities = {(lib, ent) for _, lib, ent in entity_matches}

    # Match: label : component ent
    COMPONENT_INSTANCE_RE = re.compile(
        r"(?P<label>\w+)\s*:\s*component\s+(?P<ent>\w+)\s*(?:generic\s+map|port\s+map)", re.IGNORECASE
    )
    component_matches = COMPONENT_INSTANCE_RE.findall(text)
    for label, ent in component_matches:
        if not any(e == ent for _, e in entities):
            logging.debug(f"Component instantiation found: {label} : component {ent}")
            entities.add(("??", ent))  # library unknown

    return list(entities)


def resolve_dependencies(entity: str, entity_map: Dict[str, Path], seen: Set[str]) -> List[Path]:
    """Build a dependency graph from entity instantiations."""
    if entity in seen:
        return []

    seen.add(entity)

    if entity not in entity_map:
        logging.warning(f"Entity {entity} not in entity map")
        return []

    vhdl_path = entity_map[entity]
    deps = find_instantiated_entities(vhdl_path)
    dep_paths = [entity_map[dep[1]] for dep in deps if dep[1] in entity_map]

    result = [vhdl_path] + sum((resolve_dependencies(dep[1], entity_map, seen) for dep in deps), [])
    return result


def build_entity_map(src_dir: Path) -> Dict[str, Path]:
    """Map entity names to their source file paths."""
    entity_map = {}
    ENTITY_DEF_RE = re.compile(r"(?i)entity\s+(\w+)\s+is")
    logging.debug(f"Building entity map from {src_dir}...")
    for vhd_path in src_dir.rglob("*.vhd"):
        text = vhd_path.read_text()
        match = ENTITY_DEF_RE.search(text)
        if match:
            entity_name = match.group(1)
            entity_map[entity_name] = vhd_path.resolve()
            logging.debug(f"Mapped entity: {entity_name} -> {vhd_path}")

    return entity_map


def build_entity_library_map(src_dir: Path) -> Dict[str, str]:
    """Map entity names to their VHDL library names."""
    entity_lib_map = {}
    ENTITY_INSTANCE_RE = re.compile(r"(?P<label>\w+)\s*:\s*entity\s+(?P<lib>\w+)\.(?P<ent>\w+)", re.IGNORECASE)

    for vhd_path in src_dir.rglob("*.vhd"):
        text = vhd_path.read_text()
        for _, lib, ent in ENTITY_INSTANCE_RE.findall(text):
            if ent not in entity_lib_map:
                entity_lib_map[ent] = lib
    return entity_lib_map


def resolve_all_dependencies(
    entity: str, entity_map: Dict[str, Path], package_map: Dict[str, Path], seen: Optional[set] = None
) -> List[Path]:
    """Recursively resolve all transitive dependencies."""
    if seen is None:
        seen = set()

    if entity in seen:
        return []

    seen.add(entity)

    if entity not in entity_map:
        logging.warning(f"Entity '{entity}' not found in map")
        return []

    vhd_path = entity_map[entity]
    deps = find_instantiated_entities(vhd_path)
    paths = [vhd_path]

    packages = find_used_packages(vhd_path)
    for pkg in packages:
        pkg_key = f"{pkg}_pkg"
        if pkg_key in package_map:
            pkg_path = package_map[pkg_key]
            if pkg_path not in paths:
                logging.debug(f"Found used package: {pkg_key} -> {pkg_path}")
                paths.append(pkg_path)
        else:
            logging.warning(f"Package {pkg_key}.vhd not found in package map")

    for lib, sub_ent in deps:
        sub_paths = resolve_all_dependencies(sub_ent, entity_map, package_map, seen)
        paths.extend(sub_paths)

    return list(dict.fromkeys(paths))  # Deduplicate, preserve order


def export_entity_graph(root_entity: str, entity_map: Dict[str, Path], output_dot: Path):
    """Export the entity dependency graph as a DOT file."""
    edges = []
    seen = set()

    def walk(ent):
        """Recursively walk and collect files matching a pattern."""
        if ent in seen or ent not in entity_map:
            return
        seen.add(ent)
        deps = find_instantiated_entities(entity_map[ent])
        logging.debug(f"{ent} instantiates: {[f'{lib}.{dep}' for lib, dep in deps]}")
        for lib, dep in deps:
            logging.debug(f"Adding edge: {ent} -> {dep}")
            edges.append((ent, dep))
            walk(dep)

    logging.debug(f"Generating graph for root: {root_entity}")
    logging.debug(f"Entity map keys: {list(entity_map.keys())}")
    walk(root_entity)

    with open(output_dot, "w") as f:
        f.write("digraph EntityHierarchy {\n")
        for src, dst in edges:
            f.write(f'  "{src}" -> "{dst}";\n')
        f.write("}\n")

    logging.info(f"Graph exported to {output_dot}")


def find_used_packages(vhdl_path: Path) -> List[str]:
    """Find VHDL packages referenced by use clauses."""
    USE_RE = re.compile(r"use\s+(?P<lib>\w+)\.(?P<pkg>\w+)_pkg\.all\s*;", re.IGNORECASE)
    text = vhdl_path.read_text()
    return [m.group("pkg") for m in USE_RE.finditer(text)]


def build_package_map(src_dir: Path) -> Dict[str, Path]:
    """Map package names to their source file paths."""
    package_map = {}
    PACKAGE_DEF_RE = re.compile(r"(?i)package\s+(\w+)\s+is")
    for vhd_path in src_dir.rglob("*_pkg.vhd"):
        text = vhd_path.read_text()
        match = PACKAGE_DEF_RE.search(text)
        if match:
            pkg_name = match.group(1)
            package_map[pkg_name] = vhd_path.resolve()
    return package_map


def extract_entity_block(vhdl_path: Path, entity_name: str) -> str:
    """
    Return the full 'entity <name> is ... end [entity] <name>;' block as a string.
    Handles variants like 'end entity;', 'end <name>;', and extra whitespace/comments.
    """
    text = vhdl_path.read_text()

    # (?is): ignore case + dot matches newlines
    name = re.escape(entity_name)
    pattern = rf"""(?is)           # flags
        \bentity\s+{name}\s+is     # entity <name> is
        (.*?)                      # body
        \bend\s+                   # end ...
        (?:entity\s+{name}\s*|     #   entity <name>
           {name}\s*|              #   <name>
           entity\s*               #   entity
        );                         # ;
    """
    m = re.search(pattern, text, re.VERBOSE)
    return m.group(0) if m else ""


def make_entity_comment(block: str, module_name: str, vhdl_path: Path) -> str:
    """
    Turn the entity block into a Python comment block to drop into the template.
    If not found, include a short note so the user knows where it came from.
    """
    if not block:
        return f"# Entity definition not found in this file.\n# File: {vhdl_path.as_posix()}\n# Entity: {module_name}\n"
    return "\n".join("# " + line.rstrip() for line in block.splitlines())


def main():
    """CLI entry point for the test structure generator."""
    parser = argparse.ArgumentParser(description="Generate cocotb test stubs from VHDL source tree.")
    parser.add_argument(
        "--src", type=str, default=SRC_DIR_DEFAULT, help=f"Source root directory (default: {SRC_DIR_DEFAULT})"
    )
    parser.add_argument(
        "--out", type=str, default=TEST_ROOT_DEFAULT, help=f"Test root directory (default: {TEST_ROOT_DEFAULT})"
    )
    parser.add_argument(
        "--absolute-paths", action="store_true", help="Use absolute paths for VHDL sources (default: relative to src/)"
    )
    parser.add_argument(
        "--excludes",
        type=str,
        nargs="*",
        default=EXCLUDE_PATTERNS,
        help=f"List of filename patterns to exclude (default: {EXCLUDE_PATTERNS})",
    )
    parser.add_argument("--dry-run", action="store_true", help="Only print what would be created")
    parser.add_argument("--graph", type=str, help="Export dependency graph for given entity (as DOT file)")
    parser.add_argument("--root", type=str, help="Root entity name for the graph")
    parser.add_argument("--verbose", action="store_true", help="Enable verbose debug output")

    args = parser.parse_args()
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO, format="[%(levelname)s] %(message)s")

    src_path = Path(args.src)
    out_path = Path(args.out)

    if args.absolute_paths:
        base_path = Path.cwd()
    else:
        base_path = Path(args.src).resolve()

    logging.info(f"Scanning {src_path}...")
    created = generate_test_skeletons(src_path, base_path, out_path, args.excludes, dry_run=args.dry_run)

    if created:
        print("\n" + ("Would create:" if args.dry_run else "Created:"))
        for f in created:
            print("  -", f)
    else:
        logging.info("No test files needed to be created.")

    if args.graph and args.root:
        output_dot = Path(args.graph)
        entity_map = build_entity_map(src_path)
        package_map = build_package_map(src_path)

        logging.debug(f"Generating graph for root: {args.root}")
        logging.debug(f"Entity map keys: {list(entity_map.keys())}")

        export_entity_graph(args.root, entity_map, output_dot)


if __name__ == "__main__":
    main()
