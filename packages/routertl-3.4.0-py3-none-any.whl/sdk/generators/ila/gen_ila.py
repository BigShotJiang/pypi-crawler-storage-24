# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import os
import re
import sys

import yaml

# ========= CONFIG =========
VERBOSE = False
FORCE = False

TCL_HEADER_TEMPLATE = """# Auto-generated ILA Tcl setup
create_debug_core {ila_name} ila
set_property C_DATA_DEPTH {data_depth} [get_debug_cores {ila_name}]
set_property C_INPUT_PIPE_STAGES 0 [get_debug_cores {ila_name}]
set_property C_TRIGIN_EN false [get_debug_cores {ila_name}]
set_property C_TRIGOUT_EN false [get_debug_cores {ila_name}]
set_property ALL_PROBE_SAME_MU true [get_debug_cores {ila_name}]
set_property ALL_PROBE_SAME_MU_CNT 1 [get_debug_cores {ila_name}]
set_property port_width 1 [get_debug_ports {ila_name}/clk]

connect_debug_port {ila_name}/clk [get_nets [list {clk_net}]]
"""

STARTER_YAML = """# Example YAML configuration for debug generation
rtl_language: vhdl
ila_name: u_ila_debug
clock_rtl: clk_sys
clock_ila: ui_ddr_0
data_depth: 1024
probe_offset: 0
hierarchy: i_top/some_module
rtl_file: ../rtl/my_module.vhd
constants:
    C_NUM_LOGI_SNF_PINS: 8
    C_WIDTH_BUS_X: 32
signals:
    - signal_a
    - signal_b[7:0]
    - name: signal_c
      width: 4
      comment: this is a 4-bit debug bus
    - name: mutePinxCdc_r
      width: C_NUM_LOGI_SNF_PINS
      comment: width from constant
"""

# Example YAML configuration for debug generation
"""
rtl_language: vhdl
ila_name: u_ila_debug
clock_rtl: clk_sys
clock_rtl: ui_ddr_clk
data_depth: 8192
probe_offset: 0 # In case you want to append to existing probes
hierarchy: i_top/some_module
rtl_file: ../rtl/my_module.vhd
signals:
  - signal_a
  - signal_b[7:0]
  - name: signal_c
    width: 4
    comment: this is a 4-bit debug bus
"""


def load_yaml(filepath):
    """Load an ILA configuration YAML file."""
    with open(filepath, "r") as f:
        return yaml.safe_load(f)


def validate_config(data):
    """Validate ILA configuration for required fields."""
    required_keys = ["rtl_language", "ila_name", "clock_rtl", "hierarchy", "signals"]
    for key in required_keys:
        if key not in data:
            raise ValueError(f"❌ Missing required key in YAML: '{key}'")
    if not isinstance(data["signals"], list):
        raise ValueError("❌ 'signals' must be a list.")
    if len(data["signals"]) == 0:
        raise ValueError("❌ 'signals' list is empty.")


def parse_signal_entry(sig_entry):
    """Parse a signal entry into name, width, and options."""
    constants = globals().get("YAML_CONSTANTS", {})
    signal_types = globals().get("SIGNAL_TYPE_MAP", {})

    type_hint = None
    name = ""
    width = 1
    comment = ""

    if isinstance(sig_entry, dict):
        name = sig_entry["name"]
        width = sig_entry.get("width", 1)
        comment = sig_entry.get("comment", "")

        if name in signal_types:
            type_hint = signal_types[name]
            if VERBOSE:
                print(f"✅ Inferred type for '{name}' from RTL: {type_hint}")
        else:
            if VERBOSE:
                print(f"⚠️ No type found for '{name}', defaulting to std_logic")

        if isinstance(width, str):
            try:
                width = eval(width, {}, constants)
            except (ValueError, TypeError, SyntaxError) as e:
                print(f"❌ Failed to evaluate width expression '{width}' for signal '{name}': {e}")
                width = 1

    elif isinstance(sig_entry, str):
        match = re.match(r"(.+?)\s*\[(\d+):(\d+)\]", sig_entry)
        if match:
            name = match.group(1)
            msb = int(match.group(2))
            lsb = int(match.group(3))
            width = abs(msb - lsb) + 1
        else:
            name = sig_entry.strip()
            width = 1

        if name in signal_types:
            type_hint = signal_types[name]
            if VERBOSE:
                print(f"✅ Inferred type for '{name}' from RTL: {type_hint}")
        else:
            if VERBOSE:
                print(f"⚠️ No type found for '{name}', defaulting to std_logic")

    else:
        raise ValueError(f"Invalid signal entry format: {sig_entry}")

    if VERBOSE:
        print(f"Parsed signal: name={name}, width={width}, type={type_hint}, comment='{comment}'")

    return name, width, type_hint, comment


def extract_rtl_signals(filepath, rtl_language):
    """Extract signal declarations from RTL source files."""
    signal_names = set()
    signal_types = {}

    try:
        with open(filepath, "r") as f:
            content = f.read()
    except FileNotFoundError:
        print(f"❌ RTL file not found: {filepath}")
        return set(), {}

    signal_names = set()

    if rtl_language.lower() == "vhdl":
        matches = re.findall(r"\bsignal\s+(\w+)\s*:\s*([^;:]+)", content, re.IGNORECASE)
        for name, sig_type in matches:
            clean_type = sig_type.strip()
            signal_names.add(name)
            signal_types[name] = clean_type

    elif rtl_language.lower() == "verilog":
        matches = re.findall(
            r"(?:input|output|inout|wire|reg|logic)\s+(?:\[\s*\d+:\s*\d+\]\s*)?([\w\s,]+)\s*;", content
        )
        for group in matches:
            for name in group.split(","):
                signal_names.add(name.strip())
    else:
        print(f"❌ Unknown RTL language: {rtl_language}")
        return set(), {}

    # signal_names.update(matches)
    return signal_names, signal_types


def warn_on_missing_signals(data, declared_signals):
    """Warn about signals in config that are missing from RTL."""
    if not declared_signals:
        return

    for sig_entry in data["signals"]:
        name, _, _, _ = parse_signal_entry(sig_entry)
        if name not in declared_signals:
            print(f"⚠️ Warning: signal '{name}' not found in {data.get('rtl_file', 'N/A')}")


def create_starter_yaml():
    """Create a starter ILA YAML configuration template."""
    with open("starter_config.yaml", "w") as f:
        f.write(STARTER_YAML)
    print("✅ Starter YAML written to 'starter_config.yaml'")


def generate_rtl(data):
    """Generate ILA wrapper RTL from configuration."""
    clk = data["clock_rtl"]
    signals = data["signals"]
    ila_name = data["ila_name"]
    gen_label = f"GEN_{ila_name.upper()}"

    if data["rtl_language"].lower() == "verilog":
        lines = ["// Auto-generated debug snippet", "generate", f"  if (G_ILA_EN) begin : {gen_label}"]
        for sig_entry in signals:
            name, width, type_hint, comment = parse_signal_entry(sig_entry)
            comment_str = f" // {comment}" if comment else ""
            if type_hint:
                lines.append(f'    (* keep = "true", mark_debug = "true" *) {type_hint} {name}_d;{comment_str}')
            elif width == 1:
                lines.append(f'    (* keep = "true", mark_debug = "true" *) logic {name}_d;{comment_str}')
            else:
                lines.append(
                    f'    (* keep = "true", mark_debug = "true" *) logic [{width - 1}:0] {name}_d;{comment_str}'
                )
        lines.append(f"    always_ff @(posedge {clk}) begin")
        for sig_entry in signals:
            name, _, _, _ = parse_signal_entry(sig_entry)
            lines.append(f"      {name}_d <= {name};")
        lines.append("    end")
        lines.append("  end")
        lines.append("endgenerate")
        return "\n".join(lines)

    # VHDL
    vhdl_header = f"""-- Auto-generated debug snippet
-- Wrap this in your architecture
{gen_label} : if G_ILA_EN = '1' generate"""
    vhdl_footer = f"end generate {gen_label};"
    lines = [vhdl_header]
    for sig_entry in signals:
        name, width, type_hint, comment = parse_signal_entry(sig_entry)
        reg_sig = f"{name}_d"
        comment_str = f" -- {comment}" if comment else ""

        if VERBOSE:
            print(f"🛠️  Emitting VHDL: {reg_sig}, type_hint={type_hint}, width={width}")

        if type_hint:
            lines.append(f"    signal {reg_sig} : {type_hint};{comment_str}")
        elif width == 1:
            lines.append(f"    signal {reg_sig} : std_logic;{comment_str}")
        else:
            lines.append(f"    signal {reg_sig} : std_logic_vector({width - 1} downto 0);{comment_str}")
    lines += ["", "    -- Attributes", "    attribute keep : boolean;", "    attribute mark_debug : boolean;"]
    for sig_entry in signals:
        name, _, _, _ = parse_signal_entry(sig_entry)
        reg_sig = f"{name}_d"
        lines.append(f"    attribute keep of {reg_sig} : signal is true;")
        lines.append(f"    attribute mark_debug of {reg_sig} : signal is true;")
    lines += ["", "    begin", f"        process({clk})", "        begin", f"            if rising_edge({clk}) then"]
    for sig_entry in signals:
        name, _, _, _ = parse_signal_entry(sig_entry)
        lines.append(f"                {name}_d <= {name};")
    lines += ["            end if;", "        end process;", vhdl_footer]
    return "\n".join(lines)


def generate_tcl(data):
    """Generate Vivado TCL script for ILA insertion."""
    ila_name = data["ila_name"]
    hierarchy = data["hierarchy"]
    signals = data["signals"]
    # Optional parameters
    data_depth = data.get("data_depth", 8192)
    probe_offset = data.get("probe_offset", 0)
    gen_label = f"GEN_{ila_name.upper()}"

    tcl_header = TCL_HEADER_TEMPLATE.format(ila_name=ila_name, clk_net=data["clock_ila"], data_depth=data_depth)
    lines = [tcl_header]

    for idx, sig_entry in enumerate(signals):
        name, width, _, _ = parse_signal_entry(sig_entry)
        lines.append(f"\ncreate_debug_port {ila_name} probe")
        lines.append(f"set_property PROBE_TYPE DATA_AND_TRIGGER [get_debug_ports {ila_name}/probe{idx + probe_offset}]")
        lines.append(f"set_property port_width {width} [get_debug_ports {ila_name}/probe{idx + probe_offset}]")

        if width == 1:
            full_name = f"{hierarchy}/{gen_label}.{name}_d"
            lines.append(f"connect_debug_port {ila_name}/probe{idx + probe_offset} [get_nets [list {{{full_name}}}]]")
        else:
            bit_nets = [f"{{{hierarchy}/{gen_label}.{name}_d[{i}]}}" for i in range(width)]
            lines.append(
                f"connect_debug_port {ila_name}/probe{idx + probe_offset} [get_nets [list {' '.join(bit_nets)}]]"
            )

    lines.append("\nset_property C_CLK_INPUT_FREQ_HZ 300000000 [get_debug_cores dbg_hub]")
    lines.append("set_property C_ENABLE_CLK_DIVIDER false [get_debug_cores dbg_hub]")
    lines.append("set_property C_USER_SCAN_CHAIN 1 [get_debug_cores dbg_hub]")

    lines.append(f"connect_debug_port dbg_hub/clk [get_nets {data['clock_rtl']}]")

    return "\n".join(lines)


def main():
    """CLI entry point for ILA generator."""
    global VERBOSE, FORCE

    if len(sys.argv) < 2:
        print("Usage: python gen_debug.py <config.yaml> [--verbose] [--force] or --init")
        sys.exit(1)

    if sys.argv[1] == "--init":
        create_starter_yaml()
        sys.exit(0)

    config_path = sys.argv[1]
    VERBOSE = "--verbose" in sys.argv
    FORCE = "--force" in sys.argv

    config = load_yaml(config_path)
    globals()["YAML_CONSTANTS"] = config.get("constants", {})

    try:
        validate_config(config)
    except ValueError as e:
        print(str(e))
        sys.exit(1)

    os.makedirs("output", exist_ok=True)

    if "rtl_file" in config:
        declared_signals, signal_types = extract_rtl_signals(config["rtl_file"], config["rtl_language"])
        globals()["SIGNAL_TYPE_MAP"] = signal_types
    if VERBOSE and "rtl_file" in config:
        print("🔎 Extracted RTL signal types:")
        for k, v in signal_types.items():
            print(f"    {k} : {v}")

    warn_on_missing_signals(config, declared_signals)

    rtl_out = generate_rtl(config)
    extension = "v" if config["rtl_language"].lower() == "verilog" else "vhd"
    with open(f"output/ila_debug_snippet.{extension}", "w") as f:
        f.write(rtl_out)

    tcl_out = generate_tcl(config)
    with open("output/ila_setup.tcl", "w") as f:
        f.write(tcl_out)
    with open("output/ila_setup.xdc", "w") as f:
        f.write(tcl_out)

    print(f"✅ Generated debug_snippet.{extension} and ila_setup.tcl in ./output")


if __name__ == "__main__":
    main()
