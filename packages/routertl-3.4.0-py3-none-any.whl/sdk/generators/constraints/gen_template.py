# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

import argparse
import re
import sys
from pathlib import Path

# Add project-manager to path to import DependencyResolver
from sdk.engine.dependency_resolver import DependencyResolver


def extract_vhdl_ports(filepath):
    """Extract port definitions from a VHDL entity declaration."""
    content = Path(filepath).read_text(errors="replace")
    # minimal regex to extract the "port ( ... )" block
    match = re.search(r"(?i)port\s*\((.*?)\);", content, re.DOTALL)
    if not match:
        return []

    ports = []
    # parse lines like: clk : in std_logic;
    lines = match.group(1).split(";")
    for line in lines:
        line = line.strip()
        if not line or line.startswith("--"):
            continue
        parts = line.split(":")
        if len(parts) >= 2:
            names = [n.strip() for n in parts[0].split(",")]
            for name in names:
                if name:
                    ports.append(name)
    return list(dict.fromkeys(ports))


def extract_verilog_ports(filepath):
    """Extract port definitions from a Verilog module declaration."""
    content = Path(filepath).read_text(errors="replace")
    # strip comments
    content = re.sub(r"//.*", "", content)
    content = re.sub(r"/\*.*?\*/", "", content, flags=re.DOTALL)

    match = re.search(r"(?i)module\s+\w+\s*(?:#\s*\([\s\S]*?\))?\s*\((.*?)\);", content, re.DOTALL)
    if not match:
        return []

    ports = []
    lines = match.group(1).split(",")
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # last word is usually the port name: input wire [7:0] my_port
        words = line.split()
        if words:
            # clean up any brackets
            name = words[-1].replace("]", "").replace("[", "")
            if name:
                ports.append(name)
    return list(dict.fromkeys(ports))


def generate_xdc(top, filepath, out_path):
    """Generate an XDC constraints template from port definitions."""
    print(f"🔍 Analyzing {top} at {filepath}...")

    ext = Path(filepath).suffix.lower()
    if ext in [".vhd", ".vhdl"]:
        ports = extract_vhdl_ports(filepath)
    else:
        ports = extract_verilog_ports(filepath)

    clocks = [p for p in ports if "clk" in p.lower() or "clock" in p.lower()]
    inputs = [
        p
        for p in ports
        if p not in clocks
        and ("in" in p.lower() or "tready" in p.lower() or "axi" in p.lower() or "tvalid" in p.lower())
    ]
    outputs = [p for p in ports if p not in clocks and p not in inputs]

    lines = []
    lines.append(f"## Auto-generated XDC Template for {top}")
    lines.append("## ========================================================")
    lines.append("")

    if clocks:
        lines.append("## 1. Clock Definitions")
        for idx, clk in enumerate(clocks):
            freq = 100 if idx == 0 else 50
            period = 1000 / freq
            lines.append(f"create_clock -period {period:.3f} -name {clk} [get_ports {clk}]")
        lines.append("")

        if len(clocks) > 1:
            lines.append("## 2. Clock Domain Crossings (CDC)")
            lines.append("## TIP: Use set_max_delay -datapath_only for async FIFOs or synchronizers")
            lines.append(
                f"# set_max_delay -datapath_only -from [get_clocks {clocks[0]}] -to [get_clocks {clocks[1]}] {(1000 / 100):.3f}"
            )
            lines.append(
                f"# set_max_delay -datapath_only -from [get_clocks {clocks[1]}] -to [get_clocks {clocks[0]}] {(1000 / 50):.3f}"
            )
            lines.append("")

    lines.append("## 3. I/O Delays (Example placeholders)")
    if inputs and clocks:
        lines.append(f"# set_input_delay -clock [get_clocks {clocks[0]}] 2.0 [get_ports {{{inputs[0]}*}}]")
    if outputs and clocks:
        lines.append(f"# set_output_delay -clock [get_clocks {clocks[0]}] 2.0 [get_ports {{{outputs[0]}*}}]")
    lines.append("")

    lines.append("## 4. False Paths")
    lines.append("# set_false_path -from [get_ports {rst_n*}]")
    lines.append("")

    with open(out_path, "w") as f:
        f.write("\n".join(lines))

    print(f"✅ Generated XDC template at {out_path}")


def main():
    """CLI entry point for XDC template generator."""
    parser = argparse.ArgumentParser()
    parser.add_argument("--src", required=True, help="Source directory")
    parser.add_argument("--top", required=True, help="Top module name")
    parser.add_argument("--out", required=True, help="Output XDC file path")
    args = parser.parse_args()

    resolver = DependencyResolver([Path(args.src)])
    if args.top not in resolver.entity_map:
        print(f"❌ Error: Top module '{args.top}' not found in {args.src}")
        sys.exit(1)

    filepath = resolver.entity_map[args.top]

    # Ensure output dir exists
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)

    generate_xdc(args.top, filepath, args.out)


if __name__ == "__main__":
    main()
