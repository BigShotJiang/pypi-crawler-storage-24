# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Telemetry event model."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass(frozen=True)
class TelemetryEvent:
    """A single CLI invocation record.

    Attributes:
        command:      The top-level CLI command name (e.g. ``sim``, ``doctor``).
        timestamp:    ISO-8601 UTC timestamp of the invocation.
        duration_ms:  Wall-clock time in milliseconds.
        exit_code:    CLI exit code (0 = success).
        sdk_version:  SDK version string (e.g. ``3.0.1``).
        project:      Consumer project name from ``project.yml``, if available.
        subcommand:   Optional subcommand (e.g. ``run`` for ``rr synth run``).
    """

    command: str
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    duration_ms: int = 0
    exit_code: int = 0
    sdk_version: str = ""
    project: Optional[str] = None
    subcommand: Optional[str] = None

    def to_dict(self) -> dict:
        """Serialize to a plain dict (JSON-safe)."""
        return {k: v for k, v in asdict(self).items() if v is not None}

    def to_json(self) -> str:
        """Serialize to a compact JSON string."""
        return json.dumps(self.to_dict(), separators=(",", ":"))

    @classmethod
    def from_dict(cls, data: dict) -> TelemetryEvent:
        """Deserialize from a dict."""
        return cls(
            command=data["command"],
            timestamp=data.get("timestamp", ""),
            duration_ms=data.get("duration_ms", 0),
            exit_code=data.get("exit_code", 0),
            sdk_version=data.get("sdk_version", ""),
            project=data.get("project"),
            subcommand=data.get("subcommand"),
        )
