# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""Telemetry collector — hooks into the CLI lifecycle.

Usage in ``main.py``::

    from sdk.telemetry.collector import TelemetryCollector

    collector = TelemetryCollector()
    collector.start()
    # ... CLI runs ...
    collector.stop_and_record("sim", exit_code=0)

Disable via ``ROUTERTL_TELEMETRY=0``.
"""

from __future__ import annotations

import logging
import os
import time
from contextlib import contextmanager
from typing import Optional

from sdk.cli.resilience import cli_resilient_block

logger = logging.getLogger(__name__)


def _is_enabled() -> bool:
    """Check if telemetry collection is enabled."""
    return os.environ.get("ROUTERTL_TELEMETRY", "1") != "0"


class TelemetryCollector:
    """Collects CLI invocation timing and records to the local store."""

    def __init__(self) -> None:
        self._start_time: Optional[float] = None
        self._enabled = _is_enabled()

    def start(self) -> None:
        """Mark the start of a CLI invocation."""
        if self._enabled:
            self._start_time = time.monotonic()

    def stop_and_record(
        self,
        command: str,
        exit_code: int = 0,
        subcommand: Optional[str] = None,
        project: Optional[str] = None,
    ) -> None:
        """Stop timing and record the event to the local store.

        This method is wrapped in ``cli_resilient_block`` — failures are
        logged at DEBUG and never propagate.
        """
        if not self._enabled or self._start_time is None:
            return

        with cli_resilient_block("telemetry record"):
            from sdk.telemetry.events import TelemetryEvent
            from sdk.telemetry.store import TelemetryStore

            duration_ms = int((time.monotonic() - self._start_time) * 1000)

            # Lazy import to avoid import-time overhead
            sdk_version = ""
            try:
                from routertl_core import __version__

                sdk_version = __version__
            except ImportError:
                pass

            event = TelemetryEvent(
                command=command,
                duration_ms=duration_ms,
                exit_code=exit_code,
                sdk_version=sdk_version,
                project=project or _detect_project_name(),
                subcommand=subcommand,
            )

            store = TelemetryStore()
            store.record(event)
            store.close()

        self._start_time = None


@contextmanager
def telemetry_context(command: str, subcommand: Optional[str] = None):
    """Context manager for automatic telemetry collection.

    Usage::

        with telemetry_context("sim") as collector:
            # ... run command ...
            pass
        # Event is recorded automatically on exit
    """
    collector = TelemetryCollector()
    collector.start()
    exit_code = 0
    try:
        yield collector
    except SystemExit as e:
        exit_code = e.code if isinstance(e.code, int) else 1
        raise
    except KeyboardInterrupt:
        exit_code = 1
        raise
    except BaseException:
        exit_code = 1
        raise
    finally:
        collector.stop_and_record(command, exit_code=exit_code, subcommand=subcommand)


def _detect_project_name() -> Optional[str]:
    """Try to read the project name from ``project.yml`` in CWD."""
    try:
        import yaml

        with open("project.yml") as f:
            config = yaml.safe_load(f) or {}
        return config.get("project", {}).get("name") or config.get("name")
    except (FileNotFoundError, ImportError, ValueError, KeyError):
        return None
