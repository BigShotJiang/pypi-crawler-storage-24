# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# sim/pip_bootstrap.py
import importlib
import subprocess
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent  # .../sim
PKG = BASE / "cocotb" / "packages"

def ensure_editable(path: Path, modname: str) -> None:
    try:
        importlib.import_module(modname)
        print(f"[pip] {modname} already importable; skipping")
    except ImportError:
        if not path.exists():
            print(f"[pip] ERROR: {path} does not exist. Did you run 'make -C sim deps'?")
            raise SystemExit(1)
        print(f"[pip] Installing {modname} from {path} (editable)")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-e", str(path)])

ensure_editable(PKG / "cocotbext-i2c",  "cocotbext_i2c")
# UART: Using native SDK driver (tb/drivers/uart_source.py) - no external dep needed
# ensure_editable(PKG / "cocotbext-<proto>",  "cocotbext_<proto>") # Add others
