# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/monitors/avalon_mm_monitor.py
"""
Passive Avalon-MM Protocol Monitor.

Continuously observes Avalon-MM bus signals and flags specification
violations (Intel Avalon Interface Specifications §3.5) without
interfering with DUT operation.

Checks:
  AVL_WR_HOLD  - Write signals stable while waitrequest=1
  AVL_RD_HOLD  - Read signals stable while waitrequest=1
  AVL_RD_VALID - readdatavalid only after a read was initiated
  AVL_OVERLAP  - read and write must not both be 1
  AVL_RST      - Control signals deassert during reset
"""

from __future__ import annotations

import logging
from typing import List

from cocotb.triggers import RisingEdge
from cocotb.utils import get_sim_time

from . import ProtocolViolation


def _safe_int(sig, default: int = 0) -> int:
    """Read a signal as int, treating X/Z/U as *default*."""
    try:
        return int(sig)
    except Exception:
        return default


class AvalonMMMonitor:
    """
    Passive Avalon-MM protocol monitor.

    Attach to an AvalonMMBus and start as a coroutine.  It will
    continuously check protocol rules on every rising clock edge.

    Parameters
    ----------
    bus : AvalonMMBus
        The Avalon-MM bus to monitor.
    clk : cocotb signal
        Clock signal.
    rst : cocotb signal
        Active-high reset signal.
    log : logging.Logger
        Logger instance.
    timeout_cycles : int
        Max cycles a read can wait for readdatavalid before flagging.
    """

    def __init__(
        self,
        bus,
        clk,
        rst,
        *,
        log: logging.Logger,
        timeout_cycles: int = 1000,
        rst_active_low: bool = False,
    ):
        """Create an Avalon-MM protocol monitor.

        Parameters
        ----------
        bus : AvalonMMBus
            The Avalon-MM bus signals to observe.
        clk : cocotb signal
            Clock signal.
        rst : cocotb signal
            Reset signal.
        log : logging.Logger
            Logger for violation messages.
        timeout_cycles : int
            Max cycles a read can wait for readdatavalid. Default ``1000``.
        rst_active_low : bool
            If ``True``, reset is active when low. Default ``False``.
        """
        self.bus = bus
        self.clk = clk
        self.rst = rst
        self.log = log
        self.timeout_cycles = timeout_cycles
        self._rst_active_low = rst_active_low
        self._violations: List[ProtocolViolation] = []

    # ── Public API ──────────────────────────────────────────────

    @property
    def violations(self) -> List[ProtocolViolation]:
        """Return list of recorded violations."""
        return list(self._violations)

    @property
    def violation_count(self) -> int:
        """Number of protocol violations recorded so far."""
        return len(self._violations)

    def report(self) -> str:
        """Return a formatted multi-line violation report."""
        if not self._violations:
            return "Avalon-MM Monitor: 0 violations ✅"
        lines = [f"Avalon-MM Monitor: {len(self._violations)} violation(s) ❌"]
        for v in self._violations:
            lines.append(f"  [{v.check_id}] {v.channel} @ {v.timestamp_ns}ns: {v.message}")
        return "\n".join(lines)

    # ── Main coroutine ──────────────────────────────────────────

    async def run(self):
        """Main monitor loop — call via ``cocotb.start_soon(mon.run())``."""
        bus = self.bus

        # State tracking
        prev_wr_data = None  # (addr, writedata, byteenable)
        prev_rd_data = None  # (addr,)
        outstanding_reads = 0

        while True:
            await RisingEdge(self.clk)
            ts = int(get_sim_time("ns"))
            raw_rst = _safe_int(self.rst, default=0)
            rst_active = (not raw_rst) if self._rst_active_low else raw_rst

            curr_write = _safe_int(bus.write)
            curr_read = _safe_int(bus.read)

            # Waitrequest might not exist on all buses
            if hasattr(bus, "waitrequest") and bus.waitrequest is not None:
                curr_waitreq = _safe_int(bus.waitrequest)
            else:
                curr_waitreq = 0

            # Readdatavalid might not exist
            if hasattr(bus, "readdatavalid") and bus.readdatavalid is not None:
                curr_rdvalid = _safe_int(bus.readdatavalid)
            else:
                curr_rdvalid = 0

            # ── AVL_RST: Control signals deassert during reset ──
            if rst_active:
                if curr_write:
                    self._record("AVL_RST", "write", ts, "write asserted during reset")
                if curr_read:
                    self._record("AVL_RST", "read", ts, "read asserted during reset")
                prev_wr_data = None
                prev_rd_data = None
                outstanding_reads = 0
                continue

            # ── AVL_OVERLAP: read and write must not both be 1 ──
            if curr_write and curr_read:
                self._record("AVL_OVERLAP", "bus", ts, "read and write both asserted simultaneously")

            # ── AVL_WR_HOLD: Write signals stable while waitrequest=1 ──
            if curr_write and curr_waitreq:
                curr_wr = (
                    _safe_int(bus.address),
                    _safe_int(bus.writedata),
                    _safe_int(bus.byteenable),
                )
                if prev_wr_data is not None:
                    if curr_wr[0] != prev_wr_data[0]:
                        self._record(
                            "AVL_WR_HOLD",
                            "write",
                            ts,
                            f"address changed during waitrequest (was 0x{prev_wr_data[0]:X}, now 0x{curr_wr[0]:X})",
                        )
                    if curr_wr[1] != prev_wr_data[1]:
                        self._record(
                            "AVL_WR_HOLD",
                            "write",
                            ts,
                            f"writedata changed during waitrequest (was 0x{prev_wr_data[1]:X}, now 0x{curr_wr[1]:X})",
                        )
                    if curr_wr[2] != prev_wr_data[2]:
                        self._record(
                            "AVL_WR_HOLD",
                            "write",
                            ts,
                            f"byteenable changed during waitrequest (was 0x{prev_wr_data[2]:X}, now 0x{curr_wr[2]:X})",
                        )
                prev_wr_data = curr_wr
            else:
                prev_wr_data = None
                # Capture on first waitrequest cycle
                if curr_write and not curr_waitreq:
                    pass  # accepted immediately, no hold needed
                elif curr_write:  # should not reach here, just safety
                    prev_wr_data = (
                        _safe_int(bus.address),
                        _safe_int(bus.writedata),
                        _safe_int(bus.byteenable),
                    )

            # ── AVL_RD_HOLD: Read signals stable while waitrequest=1 ──
            if curr_read and curr_waitreq:
                curr_rd = (_safe_int(bus.address),)
                if prev_rd_data is not None:
                    if curr_rd[0] != prev_rd_data[0]:
                        self._record(
                            "AVL_RD_HOLD",
                            "read",
                            ts,
                            f"address changed during waitrequest (was 0x{prev_rd_data[0]:X}, now 0x{curr_rd[0]:X})",
                        )
                prev_rd_data = curr_rd
            else:
                prev_rd_data = None
                if curr_read and not curr_waitreq:
                    pass  # accepted immediately

            # ── AVL_RD_VALID: readdatavalid tracking ──
            # Count reads accepted (read=1 AND waitrequest=0)
            if curr_read and not curr_waitreq:
                outstanding_reads += 1

            if curr_rdvalid:
                if outstanding_reads <= 0:
                    self._record("AVL_RD_VALID", "read", ts, "readdatavalid asserted with no outstanding reads")
                else:
                    outstanding_reads -= 1

    # ── Internal ────────────────────────────────────────────────

    def _record(self, check_id: str, channel: str, ts: int, msg: str):
        v = ProtocolViolation(check_id=check_id, channel=channel, timestamp_ns=ts, message=msg)
        self._violations.append(v)
        self.log.error(f"[{check_id}] {msg}")
