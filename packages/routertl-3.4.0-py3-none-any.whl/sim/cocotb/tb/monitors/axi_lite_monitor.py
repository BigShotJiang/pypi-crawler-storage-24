# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/monitors/axi_lite_monitor.py
"""
Passive AXI-Lite Protocol Monitor.

Continuously observes AXI-Lite bus signals and flags specification
violations (AMBA IHI0022E) without interfering with DUT operation.

Checks:
  AXI_STAB_*   - Signal stability while VALID=1 & READY=0
  AXI_XZ       - X/Z on control/data during active transactions
  AXI_RST      - VALID must deassert during reset
  AXI_DEADLOCK - VALID must get READY within timeout_cycles
"""

from __future__ import annotations

import logging
from typing import List

from cocotb.triggers import RisingEdge
from cocotb.utils import get_sim_time

from . import ProtocolViolation


def _safe_int(sig, default: int = 0) -> int:
    """Read a signal as int, treating X/Z/U as *default*."""
    try:
        return int(sig)
    except Exception:
        return default


def _has_xz(sig) -> bool:
    """Return True if the signal contains X or Z bits."""
    try:
        s = sig.value.binstr
        return "x" in s or "X" in s or "z" in s or "Z" in s
    except Exception:
        return False


def _sig_val(sig) -> int:
    """Read signal value, returning -1 if X/Z."""
    try:
        return int(sig)
    except Exception:
        return -1


class AxiLiteMonitor:
    """
    Passive AXI-Lite protocol monitor.

    Attach to an AxiLiteBus and start as a coroutine.  It will
    continuously check protocol rules on every rising clock edge.

    Parameters
    ----------
    bus : AxiLiteBus
        The AXI-Lite bus to monitor.
    clk : cocotb signal
        Clock signal.
    rst : cocotb signal
        Active-high reset signal.
    log : logging.Logger
        Logger instance.
    timeout_cycles : int
        Max cycles VALID can wait for READY before flagging deadlock.
    """

    def __init__(
        self,
        bus,
        clk,
        rst,
        *,
        log: logging.Logger,
        timeout_cycles: int = 1000,
        rst_active_low: bool = False,
    ):
        """Create an AXI-Lite protocol monitor.

        Parameters
        ----------
        bus : AxiLiteBus
            The AXI-Lite bus signals to observe.
        clk : cocotb signal
            Clock signal.
        rst : cocotb signal
            Reset signal.
        log : logging.Logger
            Logger for violation messages.
        timeout_cycles : int
            Deadlock detection threshold. Default ``1000``.
        rst_active_low : bool
            If ``True``, reset is active when low. Default ``False``.
        """
        self.bus = bus
        self.clk = clk
        self.rst = rst
        self.log = log
        self.timeout_cycles = timeout_cycles
        self._rst_active_low = rst_active_low
        self._violations: List[ProtocolViolation] = []

    # ── Public API ──────────────────────────────────────────────

    @property
    def violations(self) -> List[ProtocolViolation]:
        """Return list of recorded violations."""
        return list(self._violations)

    @property
    def violation_count(self) -> int:
        """Number of protocol violations recorded so far."""
        return len(self._violations)

    def report(self) -> str:
        """Return a formatted multi-line violation report."""
        if not self._violations:
            return "AXI-Lite Monitor: 0 violations ✅"
        lines = [f"AXI-Lite Monitor: {len(self._violations)} violation(s) ❌"]
        for v in self._violations:
            lines.append(f"  [{v.check_id}] {v.channel} @ {v.timestamp_ns}ns: {v.message}")
        return "\n".join(lines)

    # ── Main coroutine ──────────────────────────────────────────

    async def run(self):
        """Main monitor loop — call via ``cocotb.start_soon(mon.run())``."""
        bus = self.bus

        # Build channel descriptors: (valid_sig, ready_sig, data_sigs, ch_name)
        # data_sigs are signals that must remain stable while valid && !ready.
        channels = [
            (bus.awvalid, bus.awready, [bus.awaddr], "AW"),
            (bus.wvalid, bus.wready, [bus.wdata, bus.wstrb], "W"),
            (bus.bvalid, bus.bready, [bus.bresp], "B"),
            (bus.arvalid, bus.arready, [bus.araddr], "AR"),
            (bus.rvalid, bus.rready, [bus.rdata, bus.rresp], "R"),
        ]

        # Optional prot signals (may not exist on all buses)
        if hasattr(bus, "awprot") and bus.awprot is not None:
            channels[0] = (bus.awvalid, bus.awready, [bus.awaddr, bus.awprot], "AW")
        if hasattr(bus, "arprot") and bus.arprot is not None:
            channels[3] = (bus.arvalid, bus.arready, [bus.araddr, bus.arprot], "AR")

        # Per-channel state
        prev_data_vals = [None] * len(channels)
        valid_wait_count = [0] * len(channels)

        while True:
            await RisingEdge(self.clk)
            ts = int(get_sim_time("ns"))
            raw_rst = _safe_int(self.rst, default=0)
            rst_active = (not raw_rst) if self._rst_active_low else raw_rst

            for i, (valid_sig, ready_sig, data_sigs, ch_name) in enumerate(channels):
                curr_valid = _safe_int(valid_sig)
                curr_ready = _safe_int(ready_sig)

                # ── AXI_RST: VALID must deassert during reset ──
                if rst_active and curr_valid:
                    self._record(
                        f"AXI_RST_{ch_name}",
                        ch_name,
                        ts,
                        f"{ch_name}VALID asserted during reset",
                    )

                if rst_active:
                    prev_data_vals[i] = None
                    valid_wait_count[i] = 0
                    continue

                # ── AXI_XZ: No X/Z during active transaction ──
                if curr_valid:
                    for dsig in data_sigs:
                        if _has_xz(dsig):
                            sig_name = str(dsig).split(".")[-1] if hasattr(dsig, "_name") else "signal"
                            self._record(
                                f"AXI_XZ_{ch_name}",
                                ch_name,
                                ts,
                                f"X/Z detected on {sig_name} while {ch_name}VALID=1",
                            )

                # ── AXI_STAB_*: Stability while VALID=1 & READY=0 ──
                if curr_valid and not curr_ready:
                    curr_data = tuple(_sig_val(s) for s in data_sigs)
                    if prev_data_vals[i] is not None:
                        for j, (old, new) in enumerate(zip(prev_data_vals[i], curr_data)):
                            if old != new and old != -1 and new != -1:
                                self._record(
                                    f"AXI_STAB_{ch_name}",
                                    ch_name,
                                    ts,
                                    f"Data changed while {ch_name}VALID=1 & {ch_name}READY=0 "
                                    f"(was 0x{old:X}, now 0x{new:X})",
                                )
                    prev_data_vals[i] = curr_data
                    valid_wait_count[i] += 1
                else:
                    prev_data_vals[i] = None
                    if curr_valid and curr_ready:
                        # Capture data for stability check next cycle if
                        # valid stays high (back-to-back)
                        prev_data_vals[i] = None
                    valid_wait_count[i] = 0

                # ── AXI_DEADLOCK: VALID without READY for too long ──
                if valid_wait_count[i] >= self.timeout_cycles:
                    self._record(
                        f"AXI_DEADLOCK_{ch_name}",
                        ch_name,
                        ts,
                        f"{ch_name}VALID asserted for {valid_wait_count[i]} cycles without {ch_name}READY",
                    )
                    # Only flag once per deadlock event
                    valid_wait_count[i] = 0

    # ── Internal ────────────────────────────────────────────────

    def _record(self, check_id: str, channel: str, ts: int, msg: str):
        v = ProtocolViolation(check_id=check_id, channel=channel, timestamp_ns=ts, message=msg)
        self._violations.append(v)
        self.log.error(f"[{check_id}] {msg}")
