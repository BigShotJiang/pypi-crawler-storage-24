# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/monitors/__init__.py
"""
Monitor package for RouteRTL verification.

Contains:
- StreamMonitor: Generic valid+data sampler.
- AxiLiteMonitor: Passive AXI-Lite protocol checker.
- AvalonMMMonitor: Passive Avalon-MM protocol checker.
- ProtocolViolation: Violation record dataclass.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Optional

from cocotb.queue import Queue
from cocotb.triggers import RisingEdge
from cocotb.utils import get_sim_time


@dataclass(frozen=True)
class Sample:
    """A timestamped data sample captured by a monitor.

    Attributes
    ----------
    ts_ns : int
        Simulation time in nanoseconds when the sample was captured.
    value : Any
        The sampled data (int, tuple, or decoded struct).
    """

    ts_ns: int
    value: Any  # int, tuple, or a decoded struct


def bv_to_int(bv, *, x_as: int = 0) -> int:
    """Convert cocotb BinaryValue to int, treating X/Z as x_as."""
    try:
        return int(bv)
    except Exception:
        return x_as


class StreamMonitor:
    """
    Generic valid+data monitor:
      - samples on RisingEdge(clk)
      - if valid_fn() == 1 -> enqueues Sample(ts_ns, data_fn())
      - optional decode_fn(value)->str for pretty logging
    """

    def __init__(
        self,
        env,
        *,
        clk,
        valid_fn: Callable[[], int],
        data_fn: Callable[[], Any],
        name: str = "stream",
        decode_fn: Optional[Callable[[Any], str]] = None,
        log_each: bool = True,
    ):
        """Create a stream monitor.

        Parameters
        ----------
        env : TbEnv
            Testbench environment (provides logger).
        clk : cocotb signal
            Clock signal to sample on rising edge.
        valid_fn : callable
            Returns 1 when data is valid for sampling.
        data_fn : callable
            Returns the data value to capture.
        name : str
            Monitor name for log messages. Default ``"stream"``.
        decode_fn : callable, optional
            Converts raw value to human-readable string for logging.
        log_each : bool
            If ``True`` (default), log each captured sample.
        """
        self.env = env
        self.clk = clk
        self.valid_fn = valid_fn
        self.data_fn = data_fn
        self.name = name
        self.decode_fn = decode_fn
        self.log = env.log
        self.log_each = log_each
        self.q: Queue[Sample] = Queue()

    async def start(self) -> None:
        """Start the monitor loop — run via ``cocotb.start_soon(mon.start())``."""
        while True:
            await RisingEdge(self.clk)
            try:
                vld = int(self.valid_fn())  # X/Z treated as 0 by your fn if needed
            except Exception:
                vld = 0
            if vld:
                ts = get_sim_time(unit="ns")
                val = self.data_fn()
                await self.q.put(Sample(ts_ns=ts, value=val))
                if self.log_each:
                    desc = f"{val!r}"
                    if self.decode_fn:
                        try:
                            desc = self.decode_fn(val)
                        except Exception as e:
                            desc = f"{val!r} (decode err: {e})"
                    self.log.info(f"{self.name} @ {ts / 1e3:.3f} us | {desc}")

    async def get(self) -> Sample:
        """Wait for and return the next captured sample."""
        return await self.q.get()

    def empty(self) -> bool:
        """Return ``True`` if no samples are queued."""
        return self.q.empty()


# ──────────────────────────────────────────────────────────────
#  Protocol Violation Record
# ──────────────────────────────────────────────────────────────


@dataclass(frozen=True)
class ProtocolViolation:
    """Record of a single protocol rule violation."""

    check_id: str  # e.g. "AXI_STAB_AW", "AVL_WR_HOLD"
    channel: str  # e.g. "AW", "W", "write"
    timestamp_ns: int  # simulation time of the violation
    message: str  # human-readable description


# Re-exports for convenience
from .avalon_mm_monitor import AvalonMMMonitor  # noqa: E402
from .axi_lite_monitor import AxiLiteMonitor  # noqa: E402

__all__ = [
    "Sample",
    "bv_to_int",
    "StreamMonitor",
    "ProtocolViolation",
    "AxiLiteMonitor",
    "AvalonMMMonitor",
]
