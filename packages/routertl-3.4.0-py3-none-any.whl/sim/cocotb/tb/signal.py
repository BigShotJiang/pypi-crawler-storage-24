# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/signal.py
from __future__ import annotations

from typing import Dict

import cocotb

__all__ = [
    "read_bit",
    "set_bit",
    "toggle_bit",
    "write_bits",
    "read_vector_int",
    "read_slice",
    "write_slice",
]


def _assign_value(sig, value: int, n_bits: int) -> None:
    """Assign an integer to a signal in a cocotb-1.x/2.x compatible way.

    In cocotb 1.x, many codebases used BinaryValue with explicit width and endianness.
    In cocotb 2.x, BinaryValue was removed; assigning an int directly is supported.

    This helper tries to import BinaryValue when available, otherwise falls back
    to plain integer assignment which cocotb coerces to the signal's width.
    """
    try:
        # Lazy import to avoid hard dependency at module import time
        from cocotb.binary import BinaryValue  # type: ignore

        sig.value = BinaryValue(value=value, n_bits=n_bits, bigEndian=False)
    except Exception:
        sig.value = value


def _width(sig) -> int:
    """Return vector width (LSB index = 0). Works for 1-bit too."""
    try:
        return len(sig)
    except TypeError:
        return 1


def read_bit(sig, index: int, default: int = 0) -> int:
    """
    Read bit at LSB-based 'index'. Returns 0/1; falls back to 'default'
    if out-of-range or the bit is X/Z/undefined.
    """
    n = _width(sig)
    if index < 0 or index >= n:
        cocotb.log.warning(f"read_bit: index {index} out of range for {sig._name}[{n - 1}:0], default={default}")
        return int(bool(default))

    bv = sig.value
    if getattr(bv, "is_resolvable", False) and bv.is_resolvable:
        return (int(bv) >> index) & 1

    s = bv.binstr
    bit_idx = len(s) - 1 - index
    ch = s[bit_idx] if 0 <= bit_idx < len(s) else None
    return 1 if ch == "1" else 0 if ch == "0" else int(bool(default))


def set_bit(sig, index: int, value: int) -> None:
    """
    Set a single bit (LSB index). Leaves other bits unchanged.
    X/Z bits are treated as 0 when constructing the integer.
    """
    n = _width(sig)
    if index < 0 or index >= n:
        cocotb.log.error(f"set_bit: index {index} out of range for {sig._name}[{n - 1}:0]")
        return

    bv = sig.value
    if getattr(bv, "is_resolvable", False) and bv.is_resolvable:
        cur = int(bv)
    else:
        cur = int("".join("0" if c not in ("0", "1") else c for c in bv.binstr), 2)

    mask = 1 << index
    cur = (cur | mask) if value else (cur & ~mask)
    _assign_value(sig, cur, n)


def toggle_bit(sig, index: int) -> None:
    """Flip a single bit (LSB index)."""
    n = _width(sig)
    if index < 0 or index >= n:
        cocotb.log.error(f"toggle_bit: index {index} out of range for {sig._name}[{n - 1}:0]")
        return

    bv = sig.value
    if getattr(bv, "is_resolvable", False) and bv.is_resolvable:
        cur = int(bv)
    else:
        cur = int("".join("0" if c not in ("0", "1") else c for c in bv.binstr), 2)

    cur ^= 1 << index
    _assign_value(sig, cur, n)


def write_bits(sig, updates: Dict[int, int]) -> None:
    """
    Batch update multiple bits: updates={index:0/1, ...}. LSB index convention.
    """
    n = _width(sig)
    bv = sig.value
    if getattr(bv, "is_resolvable", False) and bv.is_resolvable:
        cur = int(bv)
    else:
        cur = int("".join("0" if c not in ("0", "1") else c for c in bv.binstr), 2)

    for index, value in updates.items():
        if index < 0 or index >= n:
            cocotb.log.error(f"write_bits: index {index} out of range for {sig._name}[{n - 1}:0]")
            continue
        mask = 1 << index
        cur = (cur | mask) if value else (cur & ~mask)

    _assign_value(sig, cur, n)


def read_vector_int(sig, default_fill: int = 0) -> int:
    """
    Read entire vector as int. If unresolved (X/Z), treat those bits as 'default_fill'.
    """
    bv = sig.value
    if getattr(bv, "is_resolvable", False) and bv.is_resolvable:
        return int(bv)
    repl = "1" if default_fill else "0"
    return int("".join(repl if c not in ("0", "1") else c for c in bv.binstr), 2)


def read_slice(sig, hi: int, lo: int, default: int = 0) -> int:
    """
    Inclusive slice [hi:lo] using LSB indexing. Falls back for X/Z with 'default'.
    """
    if hi < lo:
        hi, lo = lo, hi
    width = hi - lo + 1
    base = read_vector_int(sig, default_fill=default)
    return (base >> lo) & ((1 << width) - 1)


def write_slice(sig, hi: int, lo: int, value: int) -> None:
    """
    Inclusive slice [hi:lo] write using LSB indexing.
    """
    if hi < lo:
        hi, lo = lo, hi
    n = _width(sig)
    width = hi - lo + 1
    mask = ((1 << width) - 1) << lo

    bv = sig.value
    if getattr(bv, "is_resolvable", False) and bv.is_resolvable:
        cur = int(bv)
    else:
        cur = int("".join("0" if c not in ("0", "1") else c for c in bv.binstr), 2)

    cur = (cur & ~mask) | ((value << lo) & mask)
    _assign_value(sig, cur, n)
