# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/drivers/native_mem.py
"""
Native Memory Master / Slave BFMs for Cocotb Testbenches

Provides pure-Python Bus Functional Models for verifying
Native Memory interfaces (SRAM-like).
"""

import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

import cocotb
from cocotb.triggers import RisingEdge


def _resolve_signal(dut, prefix: str, name: str):
    full = f"{prefix}_{name}" if prefix else name
    try:
        return getattr(dut, full)
    except AttributeError:
        pass
    try:
        return getattr(dut, full.upper())
    except AttributeError:
        pass
    raise AttributeError(f"Cannot find NativeMem signal '{name}' with prefix '{prefix}' on {dut._name}")


@dataclass
class NativeMemBus:
    """Container for native memory interface signals (SRAM-like).

    Attributes
    ----------
    addr : Any
        Address signal.
    din : Any
        Write data input.
    we : Any
        Write enable (per-byte strobe).
    re : Any
        Read enable.
    cs : Any
        Chip select.
    dout : Any
        Read data output.
    ack : Any
        Transaction acknowledge.
    """

    addr: Any
    din: Any
    we: Any
    re: Any
    cs: Any
    dout: Any
    ack: Any

    @classmethod
    def from_prefix(cls, dut, prefix: str) -> "NativeMemBus":
        """Auto-discover native memory signals from a DUT using a prefix.

        Parameters
        ----------
        dut : cocotb handle
            Top-level or sub-module handle.
        prefix : str
            Signal name prefix, e.g. ``"m_mem"``.
        """
        sig_names = ["addr", "din", "we", "re", "cs", "dout", "ack"]
        signals = {name: _resolve_signal(dut, prefix, name) for name in sig_names}
        return cls(**signals)


def _safe_int(sig, default: int = 0) -> int:
    try:
        v = sig.value
        if getattr(v, "is_resolvable", False) and v.is_resolvable:
            return int(v)
    except Exception:
        pass
    return default


def _data_width(sig) -> int:
    try:
        return len(sig)
    except TypeError:
        return 32


class NativeMemSlave:
    """Native Memory Slave Bus Functional Model."""

    def __init__(
        self,
        env,
        prefix: str = "m_mem",
        memory: Optional[Dict[int, int]] = None,
        read_latency: int = 0,
        default_value: int = 0,
    ):
        """Create a native memory slave.

        Parameters
        ----------
        env : TbEnv
            Testbench environment.
        prefix : str
            Signal prefix on the DUT. Default ``"m_mem"``.
        memory : dict, optional
            Pre-populated address→data mapping.
        read_latency : int
            Extra clock cycles before asserting ack on reads. Default ``0``.
        default_value : int
            Value returned for unwritten addresses. Default ``0``.
        """
        self.env = env
        self.log: logging.Logger = env.log
        self.clk = env.clk
        self.bus = NativeMemBus.from_prefix(env.dut, prefix)
        self._mem: Dict[int, int] = dict(memory) if memory else {}
        self._read_latency = read_latency
        self._default_value = default_value
        self._data_width = _data_width(self.bus.din)
        self._strb_width = self._data_width // 8
        self._data_mask = (1 << self._data_width) - 1

        self._idle_outputs()

    def _idle_outputs(self):
        self.bus.dout.value = 0
        self.bus.ack.value = 0

    def get_memory(self, addr: int) -> int:
        """Read memory contents at the given address."""
        return self._mem.get(addr, self._default_value)

    async def start(self):
        """Main slave coroutine."""
        cocotb.start_soon(self._handler())

    async def _handler(self):
        while True:
            await RisingEdge(self.clk)
            self.bus.ack.value = 0

            cs = _safe_int(self.bus.cs)
            if not cs:
                continue

            addr = _safe_int(self.bus.addr)
            we = _safe_int(self.bus.we)
            re = _safe_int(self.bus.re)

            if we:
                din = _safe_int(self.bus.din)
                existing = self._mem.get(addr, 0)
                new_data = 0
                for byte_idx in range(self._strb_width):
                    if we & (1 << byte_idx):
                        byte_val = (din >> (byte_idx * 8)) & 0xFF
                    else:
                        byte_val = (existing >> (byte_idx * 8)) & 0xFF
                    new_data |= byte_val << (byte_idx * 8)
                self._mem[addr] = new_data & self._data_mask

                self.bus.ack.value = 1
                self.log.debug(
                    f"NativeMem SLAVE WR @0x{addr:08X} = 0x{din:0{self._data_width // 4}X} strb={we:0{self._strb_width * 2}X}"
                )

            elif re:
                if self._read_latency > 0:
                    for _ in range(self._read_latency):
                        await RisingEdge(self.clk)

                rdata = self._mem.get(addr, self._default_value)
                self.bus.dout.value = rdata & self._data_mask
                self.bus.ack.value = 1
                self.log.debug(f"NativeMem SLAVE RD @0x{addr:08X} = 0x{rdata:0{self._data_width // 4}X}")


class NativeMemMaster:
    """Native Memory Master Bus Functional Model.

    Drives addr/din/we/re/cs and waits for ack from the slave.
    Used to test bridges where the DUT has a native memory slave input.

    Timing Protocol
    ---------------
    Each ``write()`` and ``read()`` follows this sequence:

    1. **Drive** (1 cycle): Assert ``CS`` + control signals on the bus.
    2. **Guard** (3 cycles): Burn cycles to guarantee any stale ``ACK``
       from a previous transaction has been cleared by the bridge's IDLE
       state.  Bridge state machines need ≥2 states (write) or ≥3 states
       (read) before asserting a fresh ``ACK``; the 3-cycle guard covers
       both paths.
    3. **Poll**: Wait for ``ACK = 1`` from the bridge (fresh ack).
    4. **Capture** (read only): Latch ``DOUT`` at the ack edge.
    5. **Idle**: De-assert all control signals.
    6. **Settle** (1 cycle): Let the bridge observe the de-asserted ``CS``
       and return to IDLE before the next transaction.

    .. warning::

       Without the 3-cycle guard, Verilator's scheduling model can cause
       the BFM to latch a **stale** ``ACK`` from the previous transaction's
       ``WR_DONE`` / ``RD_DONE`` state before the bridge clears it in
       ``IDLE``.  This manifests as reads returning ``0x00000000``.
    """

    def __init__(self, env, prefix: str = "s_mem"):
        """Create a native memory master.

        Parameters
        ----------
        env : TbEnv
            Testbench environment.
        prefix : str
            Signal prefix on the DUT. Default ``"s_mem"``.
        """
        self.env = env
        self.log: logging.Logger = env.log
        self.clk = env.clk
        self.bus = NativeMemBus.from_prefix(env.dut, prefix)
        self._data_width = _data_width(self.bus.din)
        self._strb_width = self._data_width // 8
        self._data_mask = (1 << self._data_width) - 1

        self._idle()

    def _idle(self):
        """De-assert all control signals (combinational, no clock edge)."""
        self.bus.addr.value = 0
        self.bus.din.value = 0
        self.bus.we.value = 0
        self.bus.re.value = 0
        self.bus.cs.value = 0

    async def write(self, addr: int, data: int, strb: int = None):
        """Write a single word.

        Parameters
        ----------
        addr : int
            Word address.
        data : int
            Write data.
        strb : int, optional
            Byte-write strobe (default: all bytes).
        """
        if strb is None:
            strb = (1 << self._strb_width) - 1

        await RisingEdge(self.clk)
        self.bus.cs.value = 1
        self.bus.addr.value = addr
        self.bus.din.value = data & self._data_mask
        self.bus.we.value = strb
        self.bus.re.value = 0

        # Guard: bridge state machine transitions through ≥2 states
        # (IDLE→WR_AVALON→WR_DONE) before ack. Burn enough cycles
        # to guarantee any stale ack from a prior txn has been cleared.
        for _ in range(3):
            await RisingEdge(self.clk)

        # Now poll for the real ack
        while True:
            await RisingEdge(self.clk)
            if _safe_int(self.bus.ack):
                break

        self._idle()
        # Settle: let the bridge see de-asserted CS and return to IDLE
        await RisingEdge(self.clk)
        self.log.debug(
            f"NativeMem MASTER WR @0x{addr:08X} = 0x{data:0{self._data_width // 4}X}"
        )

    async def read(self, addr: int) -> int:
        """Read a single word.

        Parameters
        ----------
        addr : int
            Word address.

        Returns
        -------
        int
            Read data.
        """
        await RisingEdge(self.clk)
        self.bus.cs.value = 1
        self.bus.addr.value = addr
        self.bus.re.value = 1
        self.bus.we.value = 0

        # Guard: bridge state machine transitions through ≥3 states
        # (IDLE→RD_AVALON→RD_WAIT→RD_DONE) before ack. Burn enough
        # cycles to guarantee any stale ack has been cleared.
        for _ in range(3):
            await RisingEdge(self.clk)

        # Now poll for the real ack
        while True:
            await RisingEdge(self.clk)
            if _safe_int(self.bus.ack):
                break

        rdata = _safe_int(self.bus.dout)
        self._idle()
        # Settle: let the bridge see de-asserted CS and return to IDLE
        await RisingEdge(self.clk)
        self.log.debug(
            f"NativeMem MASTER RD @0x{addr:08X} = 0x{rdata:0{self._data_width // 4}X}"
        )
        return rdata
