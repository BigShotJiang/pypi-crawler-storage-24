# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/drivers/axi_lite.py
"""
Native AXI4 Master / Slave BFMs for Cocotb Testbenches

Provides pure-Python AXI4 bus functional models for verifying
AXI4 interfaces without external dependencies.

Key features:
  - SDK-native: integrates with TbEnv for clock, reset, and logging
  - Protocol-aware: built-in handshake violation detection
  - Transaction logging: address, data, response, latency per txn
  - Configurable error handling: raise on SLVERR/DECERR or silent
  - Byte strobe support: first-class write_masked() API
  - Sparse memory slave: dict-backed, configurable latency + error injection

Signal naming convention follows ARM AMBA AXI4-Lite spec (IHI0022E):
  - Write Address:   {prefix}_awaddr, _awprot, _awvalid, _awready
  - Write Data:      {prefix}_wdata,  _wstrb,  _wvalid,  _wready
  - Write Response:  {prefix}_bresp,  _bvalid, _bready
  - Read Address:    {prefix}_araddr, _arprot, _arvalid, _arready
  - Read Data:       {prefix}_rdata,  _rresp,  _rvalid,  _rready

Usage:
    from cocotb.tb.drivers import Axi4Master, Axi4Slave

    master = Axi4Master(env, prefix="s_axi")
    slave  = Axi4Slave(env, prefix="s_axi", depth=256)
    cocotb.start_soon(slave.start())

    await master.write(0x00, 0xDEADBEEF)
    val, resp = await master.read(0x00)
    assert val == 0xDEADBEEF
"""

from __future__ import annotations

import enum
import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional

import cocotb
from cocotb.triggers import RisingEdge, SimTimeoutError, with_timeout
from cocotb.utils import get_sim_time

__all__ = [
    "Axi4Bus",
    "Axi4Master",
    "Axi4Slave",
    "AxiResp",
    "AxiRespError",
    "AxiTimeoutError",
]


# ──────────────────────────────────────────────────────────────
#  AXI Response Codes (AMBA IHI0022E §A3.4.4)
# ──────────────────────────────────────────────────────────────


class AxiResp(enum.IntEnum):
    """AXI response codes (2-bit RRESP / BRESP)."""

    OKAY = 0b00
    EXOKAY = 0b01  # exclusive access OK (not used in AXI4)
    SLVERR = 0b10
    DECERR = 0b11


class AxiRespError(Exception):
    """Raised when an AXI transaction receives a non-OKAY response."""

    def __init__(self, kind: str, addr: int, resp: AxiResp):
        """Create an AXI response error.

        Parameters
        ----------
        kind : str
            Transaction type (``"WR"`` or ``"RD"``).
        addr : int
            Address of the failed transaction.
        resp : AxiResp
            The non-OKAY response code received.
        """
        self.kind = kind
        self.addr = addr
        self.resp = resp
        super().__init__(f"AXI4 {kind} @0x{addr:08X} returned {resp.name} (0x{resp:02X})")


class AxiTimeoutError(TimeoutError):
    """Raised when an AXI transaction times out."""

    def __init__(self, kind: str, addr: int, state: str):
        """Create an AXI timeout error.

        Parameters
        ----------
        kind : str
            Transaction type (``"WR"`` or ``"RD"``).
        addr : int
            Address of the timed-out transaction.
        state : str
            Description of what the transaction was waiting for.
        """
        self.kind = kind
        self.addr = addr
        self.state = state
        super().__init__(f"AXI4 {kind} @0x{addr:08X} timed out while {state}")


# ──────────────────────────────────────────────────────────────
#  Bus Signal Container
# ──────────────────────────────────────────────────────────────


def _resolve_signal(dut, prefix: str, name: str):
    """Resolve a signal from the DUT hierarchy by prefix + suffix.

    Tries ``{prefix}_{name}`` first (VHDL-style underscore),
    then ``{prefix}{name}`` (no separator, some IPs use this).
    """
    full = f"{prefix}_{name}"
    try:
        return getattr(dut, full)
    except AttributeError:
        pass
    # Try without underscore separator
    full_nosep = f"{prefix}{name}"
    try:
        return getattr(dut, full_nosep)
    except AttributeError:
        pass
    # Try uppercase variants (common in VHDL)
    for variant in [full.upper(), full_nosep.upper()]:
        try:
            return getattr(dut, variant)
        except AttributeError:
            pass
    raise AttributeError(
        f"Cannot find AXI4 signal '{name}' with prefix '{prefix}' "
        f"on DUT {dut._name}. Tried: {prefix}_{name}, {prefix}{name}, "
        f"and uppercase variants."
    )


@dataclass
class Axi4Bus:
    """Container for the AXI4 interface signals."""

    # Write Address channel
    awaddr: Any
    awprot: Any
    awvalid: Any
    awready: Any
    awid: Any
    awlen: Any
    awsize: Any
    awburst: Any
    awcache: Any
    awqos: Any
    # Write Data channel
    wdata: Any
    wstrb: Any
    wvalid: Any
    wready: Any
    wlast: Any
    # Write Response channel
    bresp: Any
    bvalid: Any
    bready: Any
    bid: Any
    # Read Address channel
    araddr: Any
    arprot: Any
    arvalid: Any
    arready: Any
    arid: Any
    arlen: Any
    arsize: Any
    arburst: Any
    arcache: Any
    arqos: Any
    # Read Data channel
    rdata: Any
    rresp: Any
    rvalid: Any
    rready: Any
    rid: Any
    rlast: Any

    @classmethod
    def from_prefix(cls, dut, prefix: str) -> "Axi4Bus":
        """Auto-discover all AXI4 signals from a DUT using a prefix.

        Parameters
        ----------
        dut : cocotb handle
            Top-level or sub-module handle.
        prefix : str
            Signal name prefix, e.g. ``"s_axi"``.
        """
        sig_names = [
            "awaddr",
            "awprot",
            "awvalid",
            "awready",
            "awid",
            "awlen",
            "awsize",
            "awburst",
            "awcache",
            "awqos",
            "wdata",
            "wstrb",
            "wvalid",
            "wready",
            "wlast",
            "bresp",
            "bvalid",
            "bready",
            "bid",
            "araddr",
            "arprot",
            "arvalid",
            "arready",
            "arid",
            "arlen",
            "arsize",
            "arburst",
            "arcache",
            "arqos",
            "rdata",
            "rresp",
            "rvalid",
            "rready",
            "rid",
            "rlast",
        ]
        signals = {}
        for name in sig_names:
            signals[name] = _resolve_signal(dut, prefix, name)
        return cls(**signals)


# ──────────────────────────────────────────────────────────────
#  Helpers
# ──────────────────────────────────────────────────────────────


def _safe_int(sig, default: int = 0) -> int:
    """Read a signal as int, treating X/Z/U as *default*."""
    try:
        v = sig.value
        if getattr(v, "is_resolvable", False) and v.is_resolvable:
            return int(v)
    except Exception:
        pass
    return default


def _data_width(sig) -> int:
    """Return the bit-width of a data signal."""
    try:
        return len(sig)
    except TypeError:
        return 32  # fallback for scalar


# ──────────────────────────────────────────────────────────────
#  AXI4 Master BFM
# ──────────────────────────────────────────────────────────────


class Axi4Master:
    """AXI4 Master Bus Functional Model.

    Generates single-beat read and write transactions on an AXI4
    interface, with proper valid/ready handshaking per the AMBA spec.

    Parameters
    ----------
    env : TbEnv
        SDK testbench environment (provides clock, reset, logger).
    prefix : str
        AXI4 signal prefix on the DUT (default ``"s_axi"``).
    raise_on_resp : bool
        If ``True``, raises :class:`AxiRespError` on non-OKAY response.
    """

    def __init__(self, env, prefix: str = "s_axi", raise_on_resp: bool = True):
        self.env = env
        self.log: logging.Logger = env.log
        self.clk = env.clk
        self.bus = Axi4Bus.from_prefix(env.dut, prefix)
        self.raise_on_resp = raise_on_resp
        self._data_width = _data_width(self.bus.wdata)
        self._strb_width = self._data_width // 8
        self._prefix = prefix
        self.stats = {
            "num_writes": 0,
            "num_reads": 0,
            "num_errors": 0,
            "total_latency_ns": 0,
        }
        self._protocol_monitor_running = False
        self._protocol_violations: list = []

        # Drive master outputs to idle state
        self._idle_outputs()

    def _idle_outputs(self):
        """Drive all master-driven signals to their idle state."""
        self.bus.awvalid.value = 0
        self.bus.awaddr.value = 0
        self.bus.awprot.value = 0
        self.bus.awid.value = 0
        self.bus.awlen.value = 0
        self.bus.awsize.value = 0
        self.bus.awburst.value = 0
        self.bus.awcache.value = 0
        self.bus.awqos.value = 0

        self.bus.wvalid.value = 0
        self.bus.wdata.value = 0
        self.bus.wstrb.value = 0
        self.bus.wlast.value = 0

        self.bus.bready.value = 0

        self.bus.arvalid.value = 0
        self.bus.araddr.value = 0
        self.bus.arprot.value = 0
        self.bus.arid.value = 0
        self.bus.arlen.value = 0
        self.bus.arsize.value = 0
        self.bus.arburst.value = 0
        self.bus.arcache.value = 0
        self.bus.arqos.value = 0

        self.bus.rready.value = 0

    def get_stats(self) -> Dict[str, Any]:
        """Return transaction statistics."""
        return dict(self.stats)

    @property
    def protocol_violations(self) -> list:
        """Return list of detected protocol violations."""
        return list(self._protocol_violations)

    def enable_protocol_monitor(self):
        """Start background protocol monitor (AXI spec A3.2.1 checks).

        Monitors VALID stability: once asserted, VALID must remain HIGH
        until the corresponding READY handshake completes.

        Call this once after construction; it spawns a background coroutine.
        """
        if not self._protocol_monitor_running:
            self._protocol_monitor_running = True
            cocotb.start_soon(self._valid_stability_monitor())
            self.log.info("Protocol monitor enabled for %s", self._prefix)

    async def _valid_stability_monitor(self):
        """Background coroutine: check VALID stability per AXI A3.2.1.

        Rule: Once VALID is asserted, it must NOT be de-asserted until
        the corresponding READY is sampled HIGH on a rising clock edge.
        """
        # Channel pairs: (valid_signal, ready_signal, channel_name)
        channels = [
            (self.bus.awvalid, self.bus.awready, "AW"),
            (self.bus.wvalid, self.bus.wready, "W"),
            (self.bus.bvalid, self.bus.bready, "B"),
            (self.bus.arvalid, self.bus.arready, "AR"),
            (self.bus.rvalid, self.bus.rready, "R"),
        ]
        # Track per-channel: was VALID asserted on previous cycle?
        prev_valid = [0] * len(channels)

        while True:
            await RisingEdge(self.clk)
            for i, (valid_sig, ready_sig, ch_name) in enumerate(channels):
                curr_valid = _safe_int(valid_sig)
                curr_ready = _safe_int(ready_sig)

                # Violation: VALID was HIGH, READY was not HIGH, but now
                # VALID has dropped — this means VALID was de-asserted
                # before the handshake completed.
                if prev_valid[i] == 1 and curr_valid == 0 and curr_ready == 0:
                    t = get_sim_time("ns")
                    msg = f"AXI A3.2.1 violation on {ch_name} channel @ {t}ns: VALID de-asserted before READY"
                    self._protocol_violations.append(msg)
                    self.log.critical(msg)

                # Update state for next cycle
                # If handshake completed (both HIGH), reset tracking
                if curr_valid == 1 and curr_ready == 1:
                    prev_valid[i] = 0  # handshake done
                else:
                    prev_valid[i] = curr_valid

    def _check_protocol(self):
        """Perform basic protocol checks (X/Z detection)."""
        # Checks are performed on control signals that should be stable
        # during valid cycles.
        for name in [
            "awvalid",
            "awready",
            "wvalid",
            "wready",
            "bvalid",
            "bready",
            "arvalid",
            "arready",
            "rvalid",
            "rready",
        ]:
            sig = getattr(self.bus, name)
            v = sig.value
            if not getattr(v, "is_resolvable", False) or not v.is_resolvable:
                self.log.critical(f"AXI4 protocol violation: {name} is {v}")

    # ── Write Transaction ─────────────────────────────────────

    async def write(
        self,
        addr: int,
        data: list[int],
        strb: Optional[list[int]] = None,
        prot: int = 0,
        id: int = 0,
        size: int = 2,
        burst: int = 1,
        timeout_ns: int = 5000,
    ) -> AxiResp:
        """Execute an AXI4 write burst transaction.

        Parameters
        ----------
        addr : int
            Write base address.
        data : list[int]
            List of data words (one per beat).
        strb : list[int], optional
            Per-beat byte-strobe masks. ``None`` = full-word writes.
        prot : int
            AXI protection type (default ``0``).
        id : int
            Transaction ID (default ``0``).
        size : int
            Beat size exponent (default ``2`` = 4 bytes).
        burst : int
            Burst type (default ``1`` = INCR).
        timeout_ns : int
            Transaction timeout in nanoseconds.

        Returns
        -------
        AxiResp
            Write response code.

        Raises
        ------
        AxiRespError
            On non-OKAY response if ``raise_on_resp`` is True.
        AxiTimeoutError
            If the transaction times out.
        """
        beats = len(data)
        if strb is None:
            strb = [(1 << self._strb_width) - 1] * beats

        t_start = get_sim_time(unit="ns")

        async def _write_logic():
            # Phase 1: Drive AW
            self.bus.awaddr.value = addr
            self.bus.awprot.value = prot
            self.bus.awid.value = id
            self.bus.awlen.value = beats - 1
            self.bus.awsize.value = size
            self.bus.awburst.value = burst
            self.bus.awvalid.value = 1

            while True:
                await RisingEdge(self.clk)
                if _safe_int(self.bus.awready):
                    break
            self.bus.awvalid.value = 0

            # Phase 2: Drive W Beats
            for i in range(beats):
                self.bus.wdata.value = data[i]
                self.bus.wstrb.value = strb[i]
                self.bus.wlast.value = 1 if i == beats - 1 else 0
                self.bus.wvalid.value = 1

                while True:
                    await RisingEdge(self.clk)
                    if _safe_int(self.bus.wready):
                        break

            self.bus.wvalid.value = 0
            self.bus.wlast.value = 0

            # Phase 3: Wait for write response (B channel)
            self.bus.bready.value = 1
            while not _safe_int(self.bus.bvalid):
                await RisingEdge(self.clk)

            resp_val = AxiResp(_safe_int(self.bus.bresp))
            await RisingEdge(self.clk)
            self.bus.bready.value = 0
            return resp_val

        try:
            resp = await with_timeout(_write_logic(), timeout_ns, "ns")
        except SimTimeoutError:
            self._idle_outputs()
            raise AxiTimeoutError("WR", addr, "waiting for handshakes/response") from None

        t_end = get_sim_time(unit="ns")
        latency_ns = t_end - t_start

        self.stats["num_writes"] += 1
        self.stats["total_latency_ns"] += latency_ns
        if resp != AxiResp.OKAY:
            self.stats["num_errors"] += 1

        self.log.info(f"AXI4 WR @0x{addr:08X} (len={beats}) [{resp.name}] ({latency_ns:.0f} ns)")

        if self.raise_on_resp and resp != AxiResp.OKAY:
            raise AxiRespError("WR", addr, resp)

        return resp

    async def write_masked(self, addr: int, data: list[int], strb: list[int]) -> AxiResp:
        """Convenience wrapper for :meth:`write` with explicit byte strobes."""
        return await self.write(addr, data, strb=strb)

    # ── Read Transaction ──────────────────────────────────────

    async def read(
        self,
        addr: int,
        beats: int = 1,
        prot: int = 0,
        id: int = 0,
        size: int = 2,
        burst: int = 1,
        timeout_ns: int = 5000,
    ) -> tuple[list[int], AxiResp]:
        """Execute an AXI4 read burst transaction."""
        t_start = get_sim_time(unit="ns")
        read_data = []

        async def _read_logic():
            # Phase 1: Drive AR channel
            self.bus.araddr.value = addr
            self.bus.arprot.value = prot
            self.bus.arid.value = id
            self.bus.arlen.value = beats - 1
            self.bus.arsize.value = size
            self.bus.arburst.value = burst
            self.bus.arvalid.value = 1

            while True:
                await RisingEdge(self.clk)
                if _safe_int(self.bus.arready):
                    break
            self.bus.arvalid.value = 0

            # Phase 2: Wait for R channel beats
            self.bus.rready.value = 1
            read_resp = AxiResp.OKAY

            while len(read_data) < beats:
                await RisingEdge(self.clk)
                if _safe_int(self.bus.rvalid):
                    val = _safe_int(self.bus.rdata)
                    resp = AxiResp(_safe_int(self.bus.rresp))
                    is_last = _safe_int(self.bus.rlast)

                    if resp != AxiResp.OKAY:
                        read_resp = resp

                    read_data.append(val)
                    if is_last:
                        if len(read_data) != beats:
                            self.log.error(f"Early RLAST: got {len(read_data)} beats, expected {beats}")
                        break

            self.bus.rready.value = 0
            return read_data, read_resp

        try:
            data, resp = await with_timeout(_read_logic(), timeout_ns, "ns")
        except SimTimeoutError:
            self._idle_outputs()
            raise AxiTimeoutError("RD", addr, "waiting for handshakes/data") from None

        t_end = get_sim_time(unit="ns")
        latency_ns = t_end - t_start

        self.stats["num_reads"] += 1
        self.stats["total_latency_ns"] += latency_ns
        if resp != AxiResp.OKAY:
            self.stats["num_errors"] += 1

        self.log.info(f"AXI4 RD @0x{addr:08X} (len={beats}) [{resp.name}] ({latency_ns:.0f} ns)")

        if self.raise_on_resp and resp != AxiResp.OKAY:
            raise AxiRespError("RD", addr, resp)

        return data, resp


# ──────────────────────────────────────────────────────────────
#  AXI4 Slave BFM (Memory-Mapped Responder)
# ──────────────────────────────────────────────────────────────


class Axi4Slave:
    """AXI4 Slave Bus Functional Model with sparse memory.

    Responds to AXI4 read/write transactions with a dict-backed
    memory model.  Supports **per-channel configurable latency** and
    error injection for specific addresses.

    The latency parameters model real hardware timing, e.g. a Block RAM
    slave that needs 1-2 cycles for read data, or a register bank that
    can accept AW/W immediately but needs time to compute the response.

    Parameters
    ----------
    env : TbEnv
        SDK testbench environment.
    prefix : str
        AXI4 signal prefix on the DUT (default ``"s_axi"``).
    memory : dict, optional
        Pre-populated address→data mapping.
    read_latency : int
        Legacy parameter: extra cycles before ``rvalid`` (default 0).
        Overridden by ``rresp_latency`` if specified.
    write_latency : int
        Legacy parameter: extra cycles before ``bvalid`` (default 0).
        Overridden by ``bresp_latency`` if specified.
    awready_latency : int, optional
        Cycles before asserting AWREADY after seeing AWVALID.
        None = immediate (0 cycles).
    wready_latency : int, optional
        Cycles before asserting WREADY after seeing WVALID.
        None = immediate (0 cycles).
    bresp_latency : int, optional
        Cycles before asserting BVALID after completing the write.
        None = use ``write_latency``.
    arready_latency : int, optional
        Cycles before asserting ARREADY after seeing ARVALID.
        None = immediate (0 cycles).
    rresp_latency : int, optional
        Cycles before asserting RVALID after accepting the read address.
        Models BRAM read pipeline depth.  None = use ``read_latency``.
    default_value : int
        Value returned for unwritten addresses (default 0).
    error_addresses : set, optional
        Set of addresses that will return SLVERR on access.
    """

    def __init__(
        self,
        env,
        prefix: str = "s_axi",
        memory: Optional[Dict[int, int]] = None,
        read_latency: int = 0,
        write_latency: int = 0,
        awready_latency: Optional[int] = None,
        wready_latency: Optional[int] = None,
        bresp_latency: Optional[int] = None,
        arready_latency: Optional[int] = None,
        rresp_latency: Optional[int] = None,
        default_value: int = 0,
        error_addresses: Optional[set] = None,
    ):
        self.env = env
        self.log: logging.Logger = env.log
        self.clk = env.clk
        self.bus = Axi4Bus.from_prefix(env.dut, prefix)
        self._mem: Dict[int, int] = dict(memory) if memory else {}
        # Per-channel latencies (fallback to legacy params)
        self._awready_latency = awready_latency if awready_latency is not None else 0
        self._wready_latency = wready_latency if wready_latency is not None else 0
        self._bresp_latency = bresp_latency if bresp_latency is not None else write_latency
        self._arready_latency = arready_latency if arready_latency is not None else 0
        self._rresp_latency = rresp_latency if rresp_latency is not None else read_latency
        self._default_value = default_value
        self._error_addrs: set = error_addresses or set()
        self._data_width = _data_width(self.bus.rdata)
        self._data_mask = (1 << self._data_width) - 1
        self._byte_width = self._data_width // 8
        self._callbacks: Dict[int, Any] = {}
        self._regions: list[tuple[int, int, str]] = []

        # Drive slave outputs to idle
        self._idle_outputs()

    def _idle_outputs(self):
        """Drive all slave-driven signals to idle state."""
        self.bus.awready.value = 0
        self.bus.wready.value = 0
        self.bus.bvalid.value = 0
        self.bus.bresp.value = 0
        self.bus.arready.value = 0
        self.bus.rvalid.value = 0
        self.bus.rdata.value = 0
        self.bus.rresp.value = 0

    # ── Public API ────────────────────────────────────────────

    def set_memory(self, addr: int, data: int):
        """Pre-populate memory at a specific word-aligned address."""
        self._mem[addr] = data & self._data_mask

    def get_memory(self, addr: int) -> int:
        """Read memory contents at address."""
        return self._mem.get(addr, self._default_value)

    def dump(self) -> Dict[int, int]:
        """Return a copy of the entire memory contents."""
        return dict(self._mem)

    def add_error_address(self, addr: int):
        """Mark an address to return SLVERR on access."""
        self._error_addrs.add(addr)

    def on_write(self, addr: int, callback: Any):
        """Register a callback for writes to a specific address.

        The callback is called as ``callback(addr, data)``.
        """
        self._callbacks[addr] = callback

    def add_region(self, base: int, size: int, name: str = "region"):
        """Define a valid address region for this slave."""
        self._regions.append((base, size, name))

    def set_default_value(self, val: int):
        """Set the value returned for uninitialized memory reads."""
        self._default_value = val & self._data_mask

    def _is_addr_valid(self, addr: int) -> bool:
        """Check if an address is within any defined region."""
        if not self._regions:
            return True  # compatible with legacy behavior (all addrs valid)
        for base, size, _ in self._regions:
            if base <= addr < base + size:
                return True
        return False

    async def start(self):
        """Main slave coroutine — run with ``cocotb.start_soon()``.

        Handles write and read channels concurrently by spawning
        separate coroutines for each.
        """
        cocotb.start_soon(self._write_handler())
        cocotb.start_soon(self._read_handler())

    # ── Write Handler ─────────────────────────────────────────

    async def _write_handler(self):
        """Handle AXI4 write address + data + response."""
        while True:
            # Wait for both AW and W phases (can arrive in any order)
            aw_addr = None
            aw_prot = None
            w_data = None
            w_strb = None

            # Apply per-channel ready latencies
            aw_latency_remaining = self._awready_latency
            w_latency_remaining = self._wready_latency

            # Don't assert ready until latency expires
            self.bus.awready.value = 1 if aw_latency_remaining == 0 else 0
            self.bus.wready.value = 1 if w_latency_remaining == 0 else 0

            # Collect AW and W — they may arrive on the same or different cycles
            while aw_addr is None or w_data is None:
                await RisingEdge(self.clk)
                # Count down AW latency
                if aw_addr is None and aw_latency_remaining > 0:
                    aw_latency_remaining -= 1
                    if aw_latency_remaining == 0:
                        self.bus.awready.value = 1
                # Count down W latency
                if w_data is None and w_latency_remaining > 0:
                    w_latency_remaining -= 1
                    if w_latency_remaining == 0:
                        self.bus.wready.value = 1
                # Sample channels
                if aw_addr is None and _safe_int(self.bus.awvalid) and _safe_int(self.bus.awready):
                    aw_addr = _safe_int(self.bus.awaddr)
                    aw_prot = _safe_int(self.bus.awprot)
                if w_data is None and _safe_int(self.bus.wvalid) and _safe_int(self.bus.wready):
                    w_data = _safe_int(self.bus.wdata)
                    w_strb = _safe_int(self.bus.wstrb)

            # Apply byte strobes to memory
            if not self._is_addr_valid(aw_addr):
                resp = AxiResp.DECERR
            elif aw_addr in self._error_addrs:
                resp = AxiResp.SLVERR
            else:
                resp = AxiResp.OKAY
                existing = self._mem.get(aw_addr, 0)
                new_data = 0
                for byte_idx in range(self._byte_width):
                    if w_strb & (1 << byte_idx):
                        # Take byte from write data
                        byte_val = (w_data >> (byte_idx * 8)) & 0xFF
                    else:
                        # Keep existing byte
                        byte_val = (existing >> (byte_idx * 8)) & 0xFF
                    new_data |= byte_val << (byte_idx * 8)
                self._mem[aw_addr] = new_data & self._data_mask

                # Trigger callbacks
                if aw_addr in self._callbacks:
                    self._callbacks[aw_addr](aw_addr, new_data)

            self.bus.awready.value = 0
            self.bus.wready.value = 0

            # Optional bresp latency
            for _ in range(self._bresp_latency):
                await RisingEdge(self.clk)

            # Drive write response
            self.bus.bresp.value = int(resp)
            self.bus.bvalid.value = 1

            # Wait for bready handshake
            while not _safe_int(self.bus.bready):
                await RisingEdge(self.clk)
            await RisingEdge(self.clk)

            self.bus.bvalid.value = 0
            self.bus.bresp.value = 0

            self.log.debug(
                f"AXI4 SLAVE WR @0x{aw_addr:08X} = "
                f"0x{w_data:0{self._data_width // 4}X} "
                f"strb=0x{w_strb:02X} [{resp.name}]"
            )

    # ── Read Handler ──────────────────────────────────────────

    async def _read_handler(self):
        """Handle AXI4 read address + data response."""
        while True:
            # Apply arready latency
            if self._arready_latency > 0:
                self.bus.arready.value = 0
                for _ in range(self._arready_latency):
                    await RisingEdge(self.clk)
            # Wait for AR phase
            self.bus.arready.value = 1
            while True:
                await RisingEdge(self.clk)
                if _safe_int(self.bus.arvalid):
                    break
            ar_addr = _safe_int(self.bus.araddr)
            self.bus.arready.value = 0

            # Determine response
            if not self._is_addr_valid(ar_addr):
                resp = AxiResp.DECERR
                rdata = 0
            elif ar_addr in self._error_addrs:
                resp = AxiResp.SLVERR
                rdata = 0
            else:
                resp = AxiResp.OKAY
                rdata = self._mem.get(ar_addr, self._default_value)

            # rresp latency (models BRAM read pipeline)
            for _ in range(self._rresp_latency):
                await RisingEdge(self.clk)

            # Drive read data response
            self.bus.rdata.value = rdata & self._data_mask
            self.bus.rresp.value = int(resp)
            self.bus.rvalid.value = 1

            # Wait for rready handshake
            while not _safe_int(self.bus.rready):
                await RisingEdge(self.clk)
            await RisingEdge(self.clk)

            self.bus.rvalid.value = 0
            self.bus.rdata.value = 0
            self.bus.rresp.value = 0

            self.log.debug(f"AXI4 SLAVE RD @0x{ar_addr:08X} = 0x{rdata:0{self._data_width // 4}X} [{resp.name}]")
