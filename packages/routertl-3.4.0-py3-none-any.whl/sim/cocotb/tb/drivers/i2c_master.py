# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/drivers/i2c.py
"""
I2C Master Driver for Cocotb Testbenches

Generates I2C bus activity for testing I2C sniffers and slaves.
Provides low-level control over timing for error injection testing.

Supports two signal modes:
  - Separate: sda and scl are individual signals
  - Combined: i2c_pins is a 2-bit vector [SDA, SCL] (bit 1 = SDA, bit 0 = SCL)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from cocotb.triggers import Timer


@dataclass
class I2cTiming:
    """I2C timing parameters in nanoseconds"""

    period_ns: int = 10_000  # 100 kHz default
    setup_ns: int = 250  # Data setup time
    hold_ns: int = 300  # Data hold time

    @property
    def half_period_ns(self) -> int:
        """Half the I2C clock period in nanoseconds."""
        return self.period_ns // 2


class I2cMasterDriver:
    """
    I2C Master Driver for generating I2C bus traffic.

    Features:
    - Full control over START, STOP, data, and ACK/NACK
    - Error injection: glitches, clock stretching
    - Configurable timing
    - Supports separate SDA/SCL or combined I2C_PINS vector

    Usage (separate signals):
        driver = I2cMasterDriver(env, sda=dut.SDA, scl=dut.SCL)

    Usage (combined vector):
        driver = I2cMasterDriver(env, i2c_pins=dut.I2C_PINS)
    """

    def __init__(
        self,
        env,
        sda=None,
        scl=None,
        sda_in=None,
        i2c_pins=None,
        timing: Optional[I2cTiming] = None,
    ):
        """Create an I2C master driver.

        Parameters
        ----------
        env : TbEnv
            Testbench environment.
        sda : cocotb signal, optional
            SDA output signal (separate mode).
        scl : cocotb signal, optional
            SCL signal (separate mode).
        sda_in : cocotb signal, optional
            SDA input for reading ACKs. Defaults to ``sda``.
        i2c_pins : cocotb signal, optional
            2-bit combined vector ``[SDA, SCL]`` (combined mode).
        timing : I2cTiming, optional
            Timing configuration. Default 100 kHz.

        Raises
        ------
        ValueError
            If neither ``i2c_pins`` nor both ``sda`` and ``scl`` are provided.
        """
        self.env = env
        self.log = env.log
        self.timing = timing or I2cTiming()

        # Determine signal mode
        if i2c_pins is not None:
            self._mode = "combined"
            self._i2c_pins = i2c_pins
            self._sda = None
            self._scl = None
        elif sda is not None and scl is not None:
            self._mode = "separate"
            self._sda = sda
            self._scl = scl
            self._sda_in = sda_in or sda
            self._i2c_pins = None
        else:
            raise ValueError("Must provide either i2c_pins OR both sda and scl")

        # Internal state (both lines high = idle)
        self._sda_val = 1
        self._scl_val = 1

    def _update_bus(self):
        """Update the physical bus signals based on internal state."""
        if self._mode == "combined":
            # I2C_PINS[1] = SDA, I2C_PINS[0] = SCL
            self._i2c_pins.value = (self._sda_val << 1) | self._scl_val
        else:
            self._sda.value = self._sda_val
            self._scl.value = self._scl_val

    async def initialize(self):
        """Initialize bus to idle state (both lines high)."""
        self._sda_val = 1
        self._scl_val = 1
        self._update_bus()
        await Timer(self.timing.half_period_ns, unit="ns")
        self.log.info("I2C Master initialized (bus idle)")

    async def _set_sda(self, val: int):
        """Set SDA line value."""
        self._sda_val = val
        self._update_bus()
        await Timer(self.timing.setup_ns, unit="ns")

    async def _set_scl(self, val: int):
        """Set SCL line value."""
        self._scl_val = val
        self._update_bus()
        await Timer(self.timing.half_period_ns, unit="ns")

    def _read_sda(self) -> int:
        """Read current SDA value from bus."""
        if self._mode == "combined":
            return (int(self._i2c_pins.value) >> 1) & 1
        else:
            return int(self._sda_in.value) & 1

    async def start(self):
        """
        Generate START condition.
        START = SDA falling while SCL is high.
        """
        # Ensure bus is in idle state
        await self._set_sda(1)
        await self._set_scl(1)

        # SDA falls while SCL is high
        await self._set_sda(0)
        await Timer(self.timing.hold_ns, unit="ns")

        # Pull SCL low to start first bit
        await self._set_scl(0)

        self.log.debug("I2C START")

    async def stop(self):
        """
        Generate STOP condition.
        STOP = SDA rising while SCL is high.
        """
        # Ensure SDA is low before STOP
        await self._set_sda(0)
        await self._set_scl(0)

        # Release SCL first
        await self._set_scl(1)
        await Timer(self.timing.setup_ns, unit="ns")

        # SDA rises while SCL is high
        await self._set_sda(1)

        self.log.debug("I2C STOP")

    async def write_bit(self, bit: int):
        """Write a single bit (data changes on SCL low, sampled on SCL high)."""
        # SCL should already be low
        await self._set_sda(bit)
        await self._set_scl(1)  # Rising edge - slave samples
        await self._set_scl(0)  # Falling edge - prepare next bit

    async def read_bit(self) -> int:
        """Read a single bit (sample SDA on SCL high)."""
        await self._set_sda(1)  # Release SDA for slave to drive
        await self._set_scl(1)  # Rising edge

        # Sample SDA using the helper method
        bit = self._read_sda()

        await self._set_scl(0)  # Falling edge
        return bit

    async def write_byte(self, data: int) -> bool:
        """
        Write 8 bits and read ACK.

        Args:
            data: Byte to write (0-255)

        Returns:
            True if ACK received, False if NACK
        """
        # Send 8 bits MSB first
        for i in range(7, -1, -1):
            bit = (data >> i) & 1
            await self.write_bit(bit)

        # Read ACK (9th clock)
        ack = await self.read_bit()
        ack_received = ack == 0  # ACK = SDA low

        self.log.debug(f"I2C wrote 0x{data:02X}, {'ACK' if ack_received else 'NACK'}")
        return ack_received

    async def read_byte(self, send_ack: bool = True) -> int:
        """
        Read 8 bits and send ACK/NACK.

        Args:
            send_ack: True to send ACK, False to send NACK

        Returns:
            Byte read (0-255)
        """
        data = 0
        for i in range(7, -1, -1):
            bit = await self.read_bit()
            data |= bit << i

        # Send ACK (0) or NACK (1)
        await self.write_bit(0 if send_ack else 1)

        self.log.debug(f"I2C read 0x{data:02X}, sent {'ACK' if send_ack else 'NACK'}")
        return data

    async def write_transaction(self, addr: int, data: list[int], read: bool = False) -> list[bool]:
        """
        Perform a complete I2C write transaction.

        Args:
            addr: 7-bit slave address
            data: List of bytes to write
            read: If True, set R/W bit (addr byte only, no data transfer)

        Returns:
            List of ACK results for each byte
        """
        await self.start()

        acks = []

        # Address byte (7-bit addr + R/W bit)
        addr_byte = (addr << 1) | (1 if read else 0)
        acks.append(await self.write_byte(addr_byte))

        # Data bytes
        for byte in data:
            acks.append(await self.write_byte(byte))

        await self.stop()

        self.log.info(f"I2C write to 0x{addr:02X}: {[f'0x{b:02X}' for b in data]}")
        return acks

    async def inject_glitch(self, duration_ns: int = 20):
        """
        Inject a glitch on SDA (short pulse).
        Used to test GLITCH_ERROR detection.

        Args:
            duration_ns: Pulse duration in nanoseconds
        """
        current_sda = self._sda_val

        # Toggle SDA briefly
        await self._set_sda(1 - current_sda)
        await Timer(duration_ns, unit="ns")
        await self._set_sda(current_sda)

        self.log.info(f"I2C glitch injected ({duration_ns} ns)")

    async def stretch_scl(self, duration_ms: int):
        """
        Hold SCL low for extended period.
        Used to test STRETCH_ERROR (clock timeout) detection.

        Args:
            duration_ms: How long to hold SCL low in milliseconds
        """
        await self._set_scl(0)
        await Timer(duration_ms, unit="ms")

        self.log.info(f"I2C SCL stretched for {duration_ms} ms")
