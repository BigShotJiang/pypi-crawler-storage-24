# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

# tb/drivers/uart_source.py
"""
Native UART Source/Sink Drivers for Cocotb Testbenches

Provides pure-Python UART signal generation and reception for testing
UART sniffers without external dependencies.

Key features:
- Zero external dependencies (no cocotbext-uart required)
- Accurate bit-level timing for any baud rate
- Full parity support (none, even, odd)
- Variable stop bits (1, 1.5, 2)
- Error injection: break, framing errors, parity errors

Usage:
    source = UartSource(dut.UART_RX, baud=115200)
    await source.write(0x55)
    await source.write_bytes([0xAA, 0xBB, 0xCC])

    sink = UartSink(dut.UART_TX, baud=115200)
    cocotb.start_soon(sink.start())
    data = await sink.read()  # Returns received byte
"""

from __future__ import annotations

import asyncio
from collections import deque
from dataclasses import dataclass
from typing import List, Literal, Optional

from cocotb.handle import SimHandleBase
from cocotb.triggers import FallingEdge, Timer

__all__ = ["UartSource", "UartSink", "UartConfig"]


@dataclass
class UartConfig:
    """UART configuration parameters."""

    baud: int = 115200
    bits: int = 8
    stop_bits: float = 1  # 1, 1.5, or 2
    parity: Literal["none", "even", "odd"] = "none"

    @property
    def bit_time_ns(self) -> int:
        """Time for one bit in nanoseconds."""
        return int(1_000_000_000 / self.baud)

    @property
    def stop_time_ns(self) -> int:
        """Time for stop bit(s) in nanoseconds."""
        return int(1_000_000_000 * self.stop_bits / self.baud)


class UartSource:
    """
    UART Transmitter Driver.

    Generates accurate UART waveforms on a signal for testing UART receivers.
    Follows standard UART protocol: idle high, start bit low, LSB-first data,
    optional parity, stop bit(s) high.

    Args:
        signal: Cocotb signal handle for UART TX line
        baud: Baud rate (default 115200)
        bits: Data bits 5-9 (default 8)
        stop_bits: Stop bits 1, 1.5, or 2 (default 1)
        parity: "none", "even", or "odd" (default "none")

    Example:
        uart = UartSource(dut.UART_IN, baud=9600, bits=8, parity="even")
        await uart.write(0x55)
    """

    def __init__(
        self,
        signal: SimHandleBase,
        baud: int = 115200,
        bits: int = 8,
        stop_bits: float = 1,
        parity: Literal["none", "even", "odd"] = "none",
    ):
        """Create a UART transmitter driver.

        See class docstring for parameter details.

        Raises
        ------
        ValueError
            If 9-bit data is used with parity enabled.
        """
        self.signal = signal
        # Validate configuration
        if bits == 9 and parity != "none":
            raise ValueError(
                "UART Standard Limitation: 9-bit data with Parity is not supported. Use 9-bit (No Parity) or 8-bit + Parity."
            )

        self.config = UartConfig(baud=baud, bits=bits, stop_bits=stop_bits, parity=parity)

        # Set initial idle state
        self.signal.value = 1

    @property
    def bit_time_ns(self) -> int:
        """Time for one UART bit in nanoseconds."""
        return self.config.bit_time_ns

    def _calculate_parity(self, data: int) -> int:
        """Calculate parity bit for data."""
        ones = bin(data).count("1")
        if self.config.parity == "even":
            return ones % 2  # Even: parity bit makes total ones even
        elif self.config.parity == "odd":
            return (ones + 1) % 2  # Odd: parity bit makes total ones odd
        return 0

    async def write(self, data: int) -> None:
        """
        Transmit a single byte.

        Args:
            data: Byte value (will be masked to configured bit width)
        """
        mask = (1 << self.config.bits) - 1
        data = data & mask

        # Start bit (low)
        self.signal.value = 0
        await Timer(self.bit_time_ns, unit="ns")

        # Data bits (LSB first)
        for i in range(self.config.bits):
            self.signal.value = (data >> i) & 1
            await Timer(self.bit_time_ns, unit="ns")

        # Parity bit (if configured)
        if self.config.parity != "none":
            self.signal.value = self._calculate_parity(data)
            await Timer(self.bit_time_ns, unit="ns")

        # Stop bit(s) (high)
        self.signal.value = 1
        await Timer(self.config.stop_time_ns, unit="ns")

    async def write_bytes(self, data: List[int]) -> None:
        """
        Transmit multiple bytes sequentially.

        Args:
            data: List of byte values
        """
        self.signal._log.info(f"UartSource: start sending {len(data)} bytes")
        for i, byte in enumerate(data):
            if i % 10 == 0:
                self.signal._log.info(f"UartSource: sending byte {i}/{len(data)}: 0x{byte:02X}")
            await self.write(byte)
        self.signal._log.info("UartSource: finished sending bytes")

    async def send_break(self, duration_bits: int = 12) -> None:
        """
        Send a UART break condition (line held low).

        A break is at least 1 frame + 1 bit of continuous low, typically
        used for line synchronization or special signaling.

        Args:
            duration_bits: Number of bit periods to hold low
        """
        self.signal.value = 0
        await Timer(self.bit_time_ns * duration_bits, unit="ns")
        self.signal.value = 1
        await Timer(self.bit_time_ns, unit="ns")

    async def inject_framing_error(self, data: int) -> None:
        """
        Send a byte with invalid stop bit (framing error).

        Sends data normally but holds stop bit low instead of high.

        Args:
            data: Byte value to send with bad stop bit
        """
        mask = (1 << self.config.bits) - 1
        data = data & mask

        # Start bit
        self.signal.value = 0
        await Timer(self.bit_time_ns, unit="ns")

        # Data bits (LSB first)
        for i in range(self.config.bits):
            self.signal.value = (data >> i) & 1
            await Timer(self.bit_time_ns, unit="ns")

        # Parity bit (if configured)
        if self.config.parity != "none":
            self.signal.value = self._calculate_parity(data)
            await Timer(self.bit_time_ns, unit="ns")

        # Invalid stop bit (low instead of high!)
        self.signal.value = 0
        await Timer(self.config.stop_time_ns, unit="ns")

        # Return to idle
        self.signal.value = 1
        await Timer(self.bit_time_ns, unit="ns")

    async def inject_parity_error(self, data: int) -> None:
        """
        Send a byte with inverted parity bit (parity error).

        Only effective when parity is configured.

        Args:
            data: Byte value to send with bad parity
        """
        if self.config.parity == "none":
            # No parity configured, just send normally
            await self.write(data)
            return

        mask = (1 << self.config.bits) - 1
        data = data & mask

        # Start bit
        self.signal.value = 0
        await Timer(self.bit_time_ns, unit="ns")

        # Data bits (LSB first)
        for i in range(self.config.bits):
            self.signal.value = (data >> i) & 1
            await Timer(self.bit_time_ns, unit="ns")

        # Inverted parity bit (wrong parity!)
        correct_parity = self._calculate_parity(data)
        self.signal.value = 1 - correct_parity
        await Timer(self.bit_time_ns, unit="ns")

        # Normal stop bit
        self.signal.value = 1
        await Timer(self.config.stop_time_ns, unit="ns")


class UartSink:
    """
    UART Receiver for capturing transmitted data.

    Monitors a UART line, decodes frames, and queues received bytes.
    Useful for verifying UART transmitters or loopback configurations.

    Args:
        signal: Cocotb signal handle for UART RX line
        baud: Baud rate (default 115200)
        bits: Data bits 5-9 (default 8)
        stop_bits: Stop bits 1, 1.5, or 2 (default 1)
        parity: "none", "even", or "odd" (default "none")

    Example:
        sink = UartSink(dut.UART_TX, baud=9600)
        cocotb.start_soon(sink.start())
        # ... wait for data to be transmitted ...
        byte = await sink.read()
    """

    def __init__(
        self,
        signal: SimHandleBase,
        baud: int = 115200,
        bits: int = 8,
        stop_bits: float = 1,
        parity: Literal["none", "even", "odd"] = "none",
    ):
        """Create a UART receiver/sink.

        See class docstring for parameter details.
        """
        self.signal = signal
        self.config = UartConfig(baud=baud, bits=bits, stop_bits=stop_bits, parity=parity)

        # Received data queue
        self._queue: deque = deque()
        self._event = asyncio.Event()

        # Error tracking
        self.framing_errors = 0
        self.parity_errors = 0

    @property
    def bit_time_ns(self) -> int:
        """Time for one UART bit in nanoseconds."""
        return self.config.bit_time_ns

    def _check_parity(self, data: int, parity_bit: int) -> bool:
        """Verify parity bit is correct."""
        ones = bin(data).count("1")
        if self.config.parity == "even":
            expected = ones % 2
        elif self.config.parity == "odd":
            expected = (ones + 1) % 2
        else:
            return True  # No parity configured
        return parity_bit == expected

    async def _receive_byte(self) -> Optional[int]:
        """Receive a single UART frame."""
        # Wait for start bit (falling edge)
        while self.signal.value == 1:
            await FallingEdge(self.signal)

        # Wait half bit time to sample in middle of start bit
        await Timer(self.bit_time_ns // 2, unit="ns")

        # Verify start bit is still low
        if self.signal.value != 0:
            return None  # False start, noise

        # Wait to middle of first data bit
        await Timer(self.bit_time_ns, unit="ns")

        # Sample data bits (LSB first)
        data = 0
        for i in range(self.config.bits):
            bit = int(self.signal.value) & 1
            data |= bit << i
            await Timer(self.bit_time_ns, unit="ns")

        # Sample parity bit (if configured)
        if self.config.parity != "none":
            parity_bit = int(self.signal.value) & 1
            if not self._check_parity(data, parity_bit):
                self.parity_errors += 1
            await Timer(self.bit_time_ns, unit="ns")

        # Sample stop bit (should be high)
        stop_bit = int(self.signal.value) & 1
        if stop_bit != 1:
            self.framing_errors += 1

        # Wait for remaining stop time
        if self.config.stop_bits > 1:
            await Timer(int(self.bit_time_ns * (self.config.stop_bits - 1)), unit="ns")

        return data

    async def start(self) -> None:
        """Start the receiver coroutine. Must be started with cocotb.start_soon()."""
        while True:
            data = await self._receive_byte()
            if data is not None:
                self._queue.append(data)
                self._event.set()

    async def read(self, timeout_us: Optional[int] = None) -> Optional[int]:
        """
        Read a received byte.

        Args:
            timeout_us: Timeout in microseconds (None = wait forever)

        Returns:
            Received byte or None if timeout
        """
        if self._queue:
            return self._queue.popleft()

        self._event.clear()

        if timeout_us is not None:
            # Wait with timeout
            try:
                await Timer(timeout_us, unit="us")
                if not self._queue:
                    return None
            except Exception:
                pass
        else:
            # Wait indefinitely for data
            while not self._queue:
                await Timer(self.bit_time_ns * 10, unit="ns")
                if self._queue:
                    break

        if self._queue:
            return self._queue.popleft()
        return None

    def read_nowait(self) -> Optional[int]:
        """Read a byte if available, return None otherwise."""
        if self._queue:
            return self._queue.popleft()
        return None

    def empty(self) -> bool:
        """Check if receive queue is empty."""
        return len(self._queue) == 0

    def count(self) -> int:
        """Return number of bytes in receive queue."""
        return len(self._queue)
