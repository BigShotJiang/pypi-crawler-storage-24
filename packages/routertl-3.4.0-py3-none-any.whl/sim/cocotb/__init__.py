# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL simulation package — lazy-loaded public API.

All public symbols are deferred via ``__getattr__`` so that
``import sim.cocotb`` does NOT pull in cocotb at import time.
This allows pure-CLI tests (pytest) to import sub-packages like
``sim.cocotb.engine.simulation`` without requiring cocotb to be
installed — cocotb is only needed when a test actually accesses
driver/env classes (which only happens inside real cocotb tests).
"""

__all__ = [
    "run_simulation",
    "I2cMaster",
    "SpiMaster",
    "UartConfig",
    "UartSink",
    "UartSource",
    "Tb",
    "Item",
    "SignalCollector",
    "_to_int_resolving_xz",
]


def __getattr__(name):  # noqa: C901  — simple dispatch, not complex
    if name == "run_simulation":
        from .engine.simulation import run_simulation

        return run_simulation

    if name in ("I2cMaster", "I2cMasterDriver"):
        from .tb.drivers.i2c_master import I2cMasterDriver

        return I2cMasterDriver

    if name == "SpiMaster":
        from .tb.drivers.spi_master import SpiMaster

        return SpiMaster

    if name in ("UartConfig", "UartSink", "UartSource"):
        from .tb.drivers import uart_master

        return getattr(uart_master, name)

    if name in ("Tb", "TbEnv"):
        from .tb.env import TbEnv

        return TbEnv

    if name in ("Item", "SignalCollector", "_to_int_resolving_xz"):
        from .tb import scoreboard

        return getattr(scoreboard, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
