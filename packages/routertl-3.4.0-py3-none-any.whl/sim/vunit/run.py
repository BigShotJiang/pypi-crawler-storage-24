#!/usr/bin/env python3
# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""
VUnit Test Runner for RouteRTL SDK

This script discovers and runs all VUnit testbenches in the sim/vunit/tb/ directory.
It integrates with the project.yml configuration for source file discovery.

Usage:
    python3 run.py                  # Run all tests
    python3 run.py --list           # List all tests
    python3 run.py *edge*           # Run tests matching pattern
    python3 run.py -p 4             # Run with 4 parallel processes
    python3 run.py --gui            # Open waveform viewer after simulation
"""

import sys
from pathlib import Path

# Add project root to path for yaml parsing
PROJECT_ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT_ROOT / "python"))

try:
    from vunit import VUnit
except ImportError:
    print("ERROR: VUnit not found. Install with: pip install vunit_hdl")
    sys.exit(1)

# Optional: YAML config parsing
try:
    import yaml
    HAS_YAML = True
except ImportError:
    HAS_YAML = False

# Library name for all source files
LIB_NAME = "routertl"


def load_project_sources(vu: VUnit) -> None:
    """
    Load source files from sources.yml manifest or project.yml.

    Priority:
    1. sim/vunit/sources.yml - VUnit-specific manifest of self-contained sources
    2. project.yml - Project configuration (when available)
    3. Fail with helpful message
    """
    vunit_manifest = Path(__file__).parent / "sources.yml"
    project_yml = PROJECT_ROOT / "project.yml"

    lib = vu.add_library(LIB_NAME)

    # Priority 1: VUnit-specific manifest
    if HAS_YAML and vunit_manifest.exists():
        with open(vunit_manifest, "r") as f:
            config = yaml.safe_load(f)

        print(f"  [manifest] Loading from {vunit_manifest.name}")

        # Load packages first (dependency order)
        for src_file in config.get("packages", []):
            src_path = PROJECT_ROOT / src_file
            if src_path.exists():
                lib.add_source_file(str(src_path))
                print(f"  [pkg] Added: {src_file}")

        # Load units under test
        for src_file in config.get("units", []):
            src_path = PROJECT_ROOT / src_file
            if src_path.exists():
                lib.add_source_file(str(src_path))
                print(f"  [src] Added: {src_file}")
        return

    # Priority 2: Project YAML
    if HAS_YAML and project_yml.exists():
        with open(project_yml, "r") as f:
            config = yaml.safe_load(f)

        # Load synthesis sources from YAML
        syn_files = config.get("sources", {}).get("syn", [])
        for src_file in syn_files:
            src_path = PROJECT_ROOT / src_file
            if src_path.exists() and src_path.suffix in (".vhd", ".vhdl"):
                lib.add_source_file(str(src_path))
                print(f"  [yaml] Added: {src_file}")
        return

    # Fallback: Error with helpful message
    print("  [ERROR] No source configuration found!")
    print("  Create sim/vunit/sources.yml or project.yml with source file lists.")
    sys.exit(1)


def load_testbenches(vu: VUnit) -> None:
    """
    Load all testbenches from sim/vunit/tb/ directory.
    """
    tb_dir = Path(__file__).parent / "tb"
    lib = vu.library(LIB_NAME)

    if not tb_dir.exists():
        print(f"WARNING: Testbench directory not found: {tb_dir}")
        return

    for tb_file in tb_dir.glob("tb_*.vhd"):
        lib.add_source_file(str(tb_file))
        print(f"  [tb] Added: {tb_file.name}")


def configure_tests(vu: VUnit) -> None:
    """
    Configure test-specific options (generics, waveforms, etc.)
    """
    lib = vu.library(LIB_NAME)

    # Example: Configure edge_detector tests with different edge types
    try:
        tb = lib.test_bench("tb_edge_detector")

        # Create test configurations for each edge type
        for edge_type, name in [(0, "rising"), (1, "falling"), (2, "both")]:
            tb.add_config(
                name=f"edge_type_{name}",
                generics={"G_EDGE_TYPE": edge_type}
            )
    except KeyError:
        pass  # Testbench not found, skip configuration


def main():
    # Create VUnit instance from command line arguments (new API)
    vu = VUnit.from_argv(compile_builtins=False)

    # Enable VHDL 2008 features
    vu.add_vhdl_builtins()

    print("\n=== Loading RTL Sources ===")
    load_project_sources(vu)

    print("\n=== Loading Testbenches ===")
    load_testbenches(vu)

    print("\n=== Configuring Tests ===")
    configure_tests(vu)

    print("\n=== Running VUnit ===\n")
    vu.main()


if __name__ == "__main__":
    main()
