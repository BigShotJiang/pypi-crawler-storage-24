# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Vendor library discovery and auto-precompilation.

Detects precompiled vendor simulation libraries (e.g. Xilinx unisim)
for each simulator backend and provides search-path flags.  On first
use, auto-compiles from VHDL sources using a 5-tier resolution cascade:

  Tier 1: Already precompiled?   → ~/.nvc/lib/unisim/_NVC_LIB   → skip
  Tier 2: Vivado installed?      → nvc --install vivado          → compile
  Tier 3: Cached VHDL sources?   → ~/.routertl/vendor_libs/unisim → compile
  Tier 4: Network available?     → git clone djmazure/unisim_vhdl → cache + compile
  Tier 5: Nothing works          → actionable error with rr eda install-unisim

Runtime modes:
  - Docker: libs ship precompiled OOB (baked during image build)
  - Bare metal: auto-compile on first use, cache at standard locations
  - CI (no Vivado): skip with warning, tests gated by availability
"""

import os
import shutil
import subprocess
from pathlib import Path


def _ghdl_prefix() -> Path:
    """Resolve GHDL's installation prefix from its own config."""
    try:
        result = subprocess.run(
            ["ghdl", "--disp-config"],
            capture_output=True,
            text=True,
            check=True,
        )
        for line in result.stdout.splitlines():
            if "library prefix:" in line:
                return Path(line.split(":", 1)[1].strip())
    except (FileNotFoundError, subprocess.CalledProcessError):
        pass
    return Path("/usr/local/lib/ghdl")


def _nvc_lib_dir() -> Path:
    """Resolve NVC's user library directory."""
    return Path.home() / ".nvc" / "lib"


# ============================================================================
# Discovery: check if precompiled libs exist
# ============================================================================


def nvc_unisim_available() -> bool:
    """Check if NVC has precompiled unisim."""
    marker = _nvc_lib_dir() / "unisim" / "_NVC_LIB"
    return marker.exists()


def ghdl_unisim_available() -> bool:
    """Check if GHDL has precompiled unisim."""
    prefix = _ghdl_prefix()
    candidate = prefix / "xilinx-vivado" / "unisim"
    return candidate.exists() and any(candidate.iterdir())


def ghdl_unisim_path() -> Path:
    """Return the path to GHDL's precompiled unisim library."""
    return _ghdl_prefix() / "xilinx-vivado"


# ============================================================================
# Unisim source resolution (lazy bootstrap)
# ============================================================================

UNISIM_CACHE = Path.home() / ".routertl" / "vendor_libs" / "unisim"
"""System-wide cache for downloaded unisim VHDL sources."""

UNISIM_REPO = "https://github.com/djmazure/unisim_vhdl.git"
"""Mirror repo containing Xilinx unisim VCOMP + VPKG for sim use."""

UNISIM_FILES = ["unisim_VCOMP.vhd", "unisim_VPKG.vhd"]
"""Required VHDL source files for unisim compilation."""


def _has_unisim_sources(directory: Path) -> bool:
    """Check if a directory contains both unisim VHDL source files."""
    return directory.is_dir() and all(
        (directory / f).is_file() for f in UNISIM_FILES
    )


def _resolve_unisim_path() -> Path | None:
    """Resolve the first directory containing unisim VHDL sources.

    Search order:
      1. In-repo ``sim/unisim/`` (legacy or consumer-committed copy)
      2. System cache ``~/.routertl/vendor_libs/unisim/``
      3. Vivado installation ``$XILINX_VIVADO/data/vhdl/src/unisim/``

    Returns:
        Path to the directory, or None if not found anywhere.
    """
    # 1. Legacy in-repo location (works for consumers who kept a copy)
    try:
        from engine.paths import SIM_PATH
        in_repo = SIM_PATH / "unisim"
    except ImportError:
        in_repo = None
    if in_repo and _has_unisim_sources(in_repo):
        return in_repo

    # 2. System-wide cache
    if _has_unisim_sources(UNISIM_CACHE):
        return UNISIM_CACHE

    # 3. Vivado installation
    vivado_src = _vivado_source_dir()
    if vivado_src:
        unisim_dir = vivado_src / "unisim"
        if _has_unisim_sources(unisim_dir):
            return unisim_dir

    return None


def _ensure_unisim_sources(verbose: bool = False) -> bool:
    """Ensure unisim VHDL sources are available, downloading if needed.

    Attempts to ``git clone --depth 1`` the mirror repo into the
    system-wide cache at ``~/.routertl/vendor_libs/unisim/``.

    Returns:
        True if sources are available after this call.
    """
    # Already resolved?
    if _resolve_unisim_path() is not None:
        return True

    # Try git clone
    git_bin = shutil.which("git")
    if not git_bin:
        if verbose:
            print("[VendorLib] git not found — cannot download unisim sources")
        return False

    if verbose:
        print(f"[VendorLib] Downloading unisim sources from {UNISIM_REPO}...")

    UNISIM_CACHE.parent.mkdir(parents=True, exist_ok=True)
    try:
        subprocess.run(
            [git_bin, "clone", "--depth", "1", UNISIM_REPO, str(UNISIM_CACHE)],
            check=True,
            capture_output=not verbose,
            text=True,
        )
        if verbose:
            print(f"[VendorLib] Unisim sources cached at {UNISIM_CACHE} ✓")
        return _has_unisim_sources(UNISIM_CACHE)
    except subprocess.CalledProcessError as e:
        print(f"[VendorLib] WARNING: Failed to clone unisim sources: {e}")
        # Clean up partial clone
        if UNISIM_CACHE.exists():
            shutil.rmtree(UNISIM_CACHE, ignore_errors=True)
        return False


# ============================================================================
# Auto-compilation
# ============================================================================


def _vivado_source_dir() -> Path | None:
    """Find Vivado VHDL source directory, or None if unavailable."""
    vivado = os.environ.get("XILINX_VIVADO", "")
    if vivado:
        src = Path(vivado) / "data" / "vhdl" / "src"
        if src.is_dir():
            return src
    return None


def ensure_nvc_unisim(verbose: bool = False) -> bool:
    """Ensure NVC has precompiled unisim. Auto-compile if possible.

    Resolution cascade:
      Tier 1: NVC precompiled lib exists → done
      Tier 2: Vivado installed → ``nvc --install vivado``
      Tier 3: VHDL sources available (cache/download) → ``nvc -a``
      Tier 5: Nothing works → actionable error

    Returns:
        True if unisim is available after this call.
    """
    # Tier 1: already precompiled
    if nvc_unisim_available():
        return True

    # Tier 2: Vivado installed — use native nvc --install
    vivado_src = _vivado_source_dir()
    if vivado_src:
        if verbose:
            print(f"[VendorLib] Auto-compiling unisim for NVC from {vivado_src.parent}...")

        # First try the native command
        try:
            subprocess.run(
                ["nvc", "--install", "vivado"],
                check=True,
                capture_output=True,
                text=True,
            )
            if verbose:
                print("[VendorLib] NVC unisim compiled via 'nvc --install vivado' ✓")
            return True
        except subprocess.CalledProcessError:
            pass

        # Fallback: run the install script directly
        install_script = _nvc_lib_dir() / "install-vivado.sh"
        if install_script.exists():
            try:
                subprocess.run(
                    ["bash", str(install_script)],
                    check=True,
                    capture_output=not verbose,
                    text=True,
                    env={**os.environ, "XILINX_VIVADO": str(vivado_src.parent.parent.parent)},
                )
                if verbose:
                    print("[VendorLib] NVC unisim compiled via install script ✓")
                return True
            except subprocess.CalledProcessError as e:
                print(f"[VendorLib] WARNING: NVC unisim compilation failed: {e}")

    # Tier 3/4: resolve or download VHDL sources, compile manually
    if _ensure_unisim_sources(verbose):
        src_dir = _resolve_unisim_path()
        if src_dir:
            nvc_bin = shutil.which("nvc")
            if not nvc_bin:
                if verbose:
                    print("[VendorLib] nvc not found on PATH")
                return False
            if verbose:
                print(f"[VendorLib] Compiling unisim for NVC from {src_dir}...")
            try:
                for vhd in UNISIM_FILES:
                    subprocess.run(
                        [nvc_bin, "-a", "--work=unisim", str(src_dir / vhd)],
                        check=True,
                        capture_output=not verbose,
                        text=True,
                    )
                if verbose:
                    print("[VendorLib] NVC unisim compiled from cached sources ✓")
                return True
            except subprocess.CalledProcessError as e:
                print(f"[VendorLib] WARNING: NVC unisim manual compilation failed: {e}")

    # Tier 5: nothing worked
    if verbose:
        print(
            "[VendorLib] NVC unisim not available. "
            "Install with: rr eda install-unisim"
        )
    return False


def ensure_ghdl_unisim(verbose: bool = False) -> bool:
    """Ensure GHDL has precompiled unisim. Auto-compile if possible.

    Resolution cascade:
      Tier 1: GHDL precompiled lib exists → done
      Tier 2: Vivado installed → ``compile-xilinx-vivado.sh``
      Tier 3: VHDL sources available (cache/download) → ``ghdl -a``
      Tier 5: Nothing works → actionable error

    Returns:
        True if unisim is available after this call.
    """
    # Tier 1: already precompiled
    if ghdl_unisim_available():
        return True

    # Tier 2: Vivado installed — use GHDL vendor compile script
    vivado_src = _vivado_source_dir()
    if vivado_src:
        ghdl_vendors = _ghdl_prefix() / "vendors"
        compile_script = ghdl_vendors / "compile-xilinx-vivado.sh"
        if compile_script.exists():
            output_dir = _ghdl_prefix() / "xilinx-vivado"
            output_dir.mkdir(parents=True, exist_ok=True)

            if verbose:
                print(f"[VendorLib] Auto-compiling unisim for GHDL from {vivado_src}...")
            try:
                subprocess.run(
                    [
                        "bash",
                        str(compile_script),
                        "--source",
                        str(vivado_src),
                        "--output",
                        str(output_dir),
                        "--unisim",
                        "--vhdl2008",
                    ],
                    check=True,
                    capture_output=not verbose,
                    text=True,
                    cwd=str(output_dir),
                )
                if verbose:
                    print("[VendorLib] GHDL unisim compiled ✓")
                return True
            except subprocess.CalledProcessError as e:
                print(f"[VendorLib] WARNING: GHDL unisim compilation failed: {e}")
        elif verbose:
            print(f"[VendorLib] GHDL vendor script not found at {compile_script}")

    # Tier 3/4: resolve or download VHDL sources, compile manually
    if _ensure_unisim_sources(verbose):
        src_dir = _resolve_unisim_path()
        if src_dir:
            ghdl_bin = shutil.which("ghdl")
            if not ghdl_bin:
                if verbose:
                    print("[VendorLib] ghdl not found on PATH")
                return False
            if verbose:
                print(f"[VendorLib] Compiling unisim for GHDL from {src_dir}...")
            try:
                for vhd in UNISIM_FILES:
                    subprocess.run(
                        [ghdl_bin, "-a", "--std=08", "--work=unisim", str(src_dir / vhd)],
                        check=True,
                        capture_output=not verbose,
                        text=True,
                    )
                if verbose:
                    print("[VendorLib] GHDL unisim compiled from cached sources ✓")
                return True
            except subprocess.CalledProcessError as e:
                print(f"[VendorLib] WARNING: GHDL unisim manual compilation failed: {e}")

    # Tier 5: nothing worked
    if verbose:
        print(
            "[VendorLib] GHDL unisim not available. "
            "Install with: rr eda install-unisim"
        )
    return False


# ============================================================================
# Flag generation for simulator backends
# ============================================================================


def get_ghdl_vendor_flags() -> list:
    """Return -P flags for all available GHDL precompiled vendor libraries.

    Returns:
        List of -P flags (e.g., ['-P/path/to/xilinx-vivado/'])
    """
    flags = []
    if ghdl_unisim_available():
        flags.append(f"-P{ghdl_unisim_path()}")
    return flags
