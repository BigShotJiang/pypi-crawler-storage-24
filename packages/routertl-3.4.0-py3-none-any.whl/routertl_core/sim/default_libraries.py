# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Default VHDL library definitions for simulation.

Defines the standard libraries needed for simulations (XPM, Xilinx unisim, project packages)
and maps them to their source files. This is imported by the simulation framework
to set up library compilation order and dependencies.

Note: Paths are now centralized in paths.py. This module defines library content.
"""

from engine.paths import SRC_PATH, XPM_PATH


def _unisim_sources() -> list:
    """Resolve unisim VHDL source paths dynamically.

    Returns file paths from whichever location has the sources
    (in-repo, system cache, or Vivado).  Returns an empty list
    if sources aren't available — the simulation framework will
    skip unisim compilation gracefully.
    """
    try:
        from routertl_core.sim.vendor_libraries import (
            UNISIM_FILES,
            _resolve_unisim_path,
        )
        src_dir = _resolve_unisim_path()
        if src_dir:
            return [f"{src_dir / f}" for f in UNISIM_FILES]
    except ImportError:
        pass
    return []


DEFAULT_LIBRARIES = {
    "unisim": _unisim_sources(),

    "utils": [
        f"{SRC_PATH}/pkg/functions_pkg.vhd",
    ],
    "xpm": [
        f"{XPM_PATH}/xpm_VCOMP.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_single.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_array_single.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_async_rst.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_gray.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_handshake.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_low_latency_handshake.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_pulse.vhd",
        f"{XPM_PATH}/xpm_cdc/hdl/xpm_cdc_sync_rst.vhd",
        f"{XPM_PATH}/xpm_memory/hdl/xpm_memory_base.vhd",
        f"{XPM_PATH}/xpm_memory/hdl/xpm_memory_dpdistram.vhd",
        f"{XPM_PATH}/xpm_memory/hdl/xpm_memory_dprom.vhd",
        f"{XPM_PATH}/xpm_memory/hdl/xpm_memory_sdpram.vhd",
        f"{XPM_PATH}/xpm_memory/hdl/xpm_memory_spram.vhd",
        f"{XPM_PATH}/xpm_memory/hdl/xpm_memory_sprom.vhd",
        f"{XPM_PATH}/xpm_memory/hdl/xpm_memory_tdpram.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_rst.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_reg_bit.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_counter_updn.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_reg_vec.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_reg_pipe_bit.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_base.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_async.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_axi_reg_slice.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_axif.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_axil.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_axis.vhd",
        f"{XPM_PATH}/xpm_fifo/hdl/xpm_fifo_sync.vhd",
    ],
}
