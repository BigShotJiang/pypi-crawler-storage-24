# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Unified VHDL library compilation orchestrator.

Handles compilation, caching, and dependency tracking for VHDL libraries
across different simulators using a consistent interface.
"""

from pathlib import Path
from typing import Dict, List

from .backends.backend_base import SimulatorBackend


class LibraryCompiler:
    """
    Orchestrates VHDL library compilation using a backend simulator.

    Features:
    - Unified compilation interface for all backends
    - Incremental compilation with modification time tracking
    - Automatic directory creation and management
    - Optional verbose logging
    """

    def __init__(self, backend: SimulatorBackend, verbose: bool = False):
        """
        Initialize the compiler with a specific backend.

        Args:
            backend: SimulatorBackend instance (GHDL, NVC, etc.)
            verbose: Enable detailed logging of compilation steps
        """
        self.backend = backend
        self.verbose = verbose

    def compile_all(self, libraries: Dict[str, List[str]], build_dir: str) -> None:
        """
        Compile all VHDL libraries using the backend.

        Args:
            libraries: Dict mapping library names to source file lists
            build_dir: Path to store compiled artifacts

        Raises:
            subprocess.CalledProcessError: If any compilation fails
        """
        if self.verbose:
            print(f"[{self.backend.name}] Compiling {len(libraries)} libraries to {build_dir}")

        self.backend.analyze(libraries, build_dir, verbose=self.verbose)

        if self.verbose:
            print(f"[{self.backend.name}] Compilation complete")

    @staticmethod
    def is_up_to_date(lib_dir: Path, sources: List[str]) -> bool:
        """
        Check if a library is already compiled and all sources are older.

        Args:
            lib_dir: Directory containing compiled library files
            sources: List of source file paths

        Returns:
            True if library exists and is newer than all sources, False otherwise
        """
        lib_cf = lib_dir / "library.cf"
        if not lib_cf.exists():
            return False

        cf_mtime = lib_cf.stat().st_mtime
        return all(Path(s).stat().st_mtime < cf_mtime for s in sources)
