# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Icarus Verilog simulator backend for cocotb simulations.

Provides support for compiling and running Verilog/SystemVerilog simulations
using Icarus Verilog (iverilog + vvp) via the cocotb-tools runner interface.

Icarus Verilog is fully open-source (GPL-2), zero-cost, and the most widely
installed Verilog simulator in academia and hobby projects.
"""

import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional

from engine.paths import COCOTB_VERBOSE, PROJECT_ROOT

from .backend_base import SimulatorBackend


class IcarusBackend(SimulatorBackend):
    """Icarus Verilog simulator backend using cocotb-tools runner."""

    name = "icarus"
    SUPPORTED_WAVE_FORMATS = ["vcd"]

    def __init__(self, verbose: bool = False):
        """Initialize Icarus Verilog backend."""
        self.verbose = verbose or COCOTB_VERBOSE

        if not shutil.which("iverilog"):
            raise FileNotFoundError(
                "Icarus Verilog executable 'iverilog' not found in PATH.\n"
                "Install with: sudo apt install iverilog"
            )

    def analyze(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False) -> None:
        """No-op for Icarus Verilog.

        Everything is handled in elaborate_and_run via cocotb-tools runner.
        """
        pass

    def elaborate_and_run(
        self,
        top_level: str,
        module: str,
        work_lib: str,
        build_dir: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        generics: Dict[str, any],
        hdl_sources: List[str],
        extra_env: Dict[str, str],
        verbose: bool = False,
        build_args: Optional[List[str]] = None,
        includes: Optional[List[str]] = None,
        strict_warnings: bool = False,
        test_args: Optional[List[str]] = None,
        custom_libraries: Optional[Dict[str, List[str]]] = None,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """Compile and run simulation using cocotb_tools.runner.

        Args:
            hdl_sources: Verilog/SV source files to compile. Packages
                (*_pkg.sv) and headers (*.vh, *.svh) are automatically
                sorted before regular modules.
            build_args: Extra build arguments forwarded to iverilog
                (e.g., ['-g2012'] for SystemVerilog).
            includes: Verilog/SV include directories. Parent directories
                of any header files in *hdl_sources* are auto-added.
            strict_warnings: If False (default), inject ``-Wno-timescale``
                so benign warnings don't abort compilation. Set True for
                clean-room RTL that must be warning-free.
        """
        verbose = verbose or self.verbose

        # We use cocotb_tools (2.0+) or cocotb.runner (1.9+) to steer the simulation
        try:
            try:
                from cocotb_tools.runner import get_runner
            except ImportError:
                from cocotb.runner import get_runner
        except ImportError:
            raise RuntimeError("Cocotb runner not found. Please install cocotb 1.9.0+.")

        runner = get_runner("icarus")

        # Prepare environment
        env = os.environ.copy()
        env.update(extra_env or {})

        # Auto-configure PYTHONPATH to find project-relative tests
        python_paths = []
        cocotb_root = PROJECT_ROOT / "sim" / "cocotb"
        python_paths.append(str(cocotb_root))
        python_paths.append(str(PROJECT_ROOT))  # For engine module
        # Add original paths if they are not already there
        for p in env.get("PYTHONPATH", "").split(os.pathsep):
            if p and p not in python_paths:
                python_paths.append(p)
        env["PYTHONPATH"] = os.pathsep.join(python_paths)

        # ── Package-first source ordering ──────────────────────────
        # Icarus requires packages and headers to be compiled before
        # the modules that import them.  Partition into three buckets:
        #   1. Headers  (*.vh, *.svh)  — defines / macros
        #   2. Packages (*_pkg.sv)     — SV package declarations
        #   3. Modules  (everything else)
        _HEADER_EXTS = (".vh", ".svh")

        headers: List[str] = []
        packages: List[str] = []
        modules: List[str] = []

        for src in hdl_sources or []:
            p = Path(src)
            if p.suffix in _HEADER_EXTS:
                headers.append(src)
            elif p.stem.endswith("_pkg") and p.suffix == ".sv":
                packages.append(src)
            else:
                modules.append(src)

        sorted_sources = headers + packages + modules

        # ── Timescale auto-injection ───────────────────────────────
        # Icarus defaults to 1s precision if no `timescale is set.
        # This causes cocotb's Clock(10, units="ns") to throw a
        # ValueError.  Auto-inject a timescale stub at the top of
        # the source list unless any source already defines one.
        _has_timescale = False
        for src in sorted_sources:
            try:
                with open(src, "r", errors="ignore") as f:
                    for line in f:
                        stripped = line.strip()
                        if stripped.startswith("`timescale"):
                            _has_timescale = True
                            break
                if _has_timescale:
                    break
            except OSError:
                continue

        if not _has_timescale:
            ts_dir = Path(build_dir)
            ts_dir.mkdir(parents=True, exist_ok=True)
            ts_file = ts_dir / "_routertl_timescale.v"
            ts_file.write_text(
                "// Auto-generated by RouteRTL Icarus backend\n"
                "// Sets default timescale for cocotb compatibility\n"
                "`timescale 1ns/1ps\n"
            )
            sorted_sources = [str(ts_file)] + sorted_sources
            if verbose:
                print("[Icarus] Auto-injected `timescale 1ns/1ps (no timescale found in sources)")

        # ── Auto-derive include directories ────────────────────────
        # Collect parent dirs of header files so that `include "foo.vh"
        # resolves without the user specifying every -I path manually.
        auto_includes: List[str] = []
        for hdr in headers:
            parent = str(Path(hdr).resolve().parent)
            if parent not in auto_includes:
                auto_includes.append(parent)

        all_includes = list(auto_includes)
        for inc in includes or []:
            inc_resolved = str(Path(inc).resolve())
            if inc_resolved not in all_includes:
                all_includes.append(inc_resolved)

        # ── Build arguments ────────────────────────────────────────
        all_build_args = list(build_args or [])
        if not strict_warnings and "-Wno-timescale" not in all_build_args:
            all_build_args.append("-Wno-timescale")

        if verbose:
            print(f"[Icarus] Running build for top: {top_level}")
            print(f"  Sources ({len(sorted_sources)}):")
            for s in sorted_sources:
                print(f"    {s}")
            if all_includes:
                print(f"  Include dirs: {all_includes}")
            if all_build_args:
                print(f"  Build args: {all_build_args}")
            print(f"  PYTHONPATH: {env.get('PYTHONPATH', '')}")

        # 1. Build
        runner.build(
            sources=sorted_sources,
            hdl_toplevel=top_level,
            build_dir=build_dir,
            waves=bool(wave_dir),
            parameters=generics or {},
            includes=all_includes,
            build_args=all_build_args,
            verbose=verbose,
            clean=False,  # Don't wipe every time if we want incremental
        )

        if verbose:
            print(f"[Icarus] Running test: {module}")

        # 2. Test
        runner.test(
            hdl_toplevel=top_level,
            test_module=module,
            build_dir=build_dir,
            waves=bool(wave_dir),
            extra_env=env,
            verbose=verbose,
            log_file=os.environ.get("COCOTB_LOG_FILE"),
        )
