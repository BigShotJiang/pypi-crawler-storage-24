# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Cadence Xcelium simulator backend for cocotb simulations.
"""

import os
import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

from engine.paths import COCOTB_VERBOSE, VHDL_STD

from .backend_base import SimulatorBackend


class XceliumBackend(SimulatorBackend):
    """Xcelium simulator backend."""

    name = "xcelium"
    SUPPORTED_WAVE_FORMATS = ["shm"]

    def __init__(self, verbose: bool = False):
        """Initialize Xcelium backend."""
        self.verbose = verbose or COCOTB_VERBOSE

        # Check if xrun is available
        if not shutil.which("xrun"):
            raise FileNotFoundError("Cadence Xcelium executable 'xrun' not found in PATH.")

    def analyze(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False) -> None:
        """
        Xcelium prefers a single-step flow.
        However, for RouteRTL compatibility, we compile libraries if needed.
        """
        verbose = verbose or self.verbose
        build_path = Path(build_dir).resolve()
        build_path.mkdir(parents=True, exist_ok=True)

        for lib_name, sources in libraries.items():
            # Xcelium handles libraries via -work <lib>
            # We don't pre-compile unless forced, as elaborate_and_run handles it better.
            if verbose:
                print(f"[Xcelium] Library {lib_name} noted for single-step flow.")

    def elaborate_and_run(
        self,
        top_level: str,
        module: str,
        work_lib: str,
        build_dir: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        generics: Dict[str, any],
        hdl_sources: List[str],
        extra_env: Dict[str, str],
        verbose: bool = False,
        build_args: Optional[List[str]] = None,
        includes: Optional[List[str]] = None,
        test_args: Optional[List[str]] = None,
        custom_libraries: Optional[Dict[str, List[str]]] = None,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """Run single-step xrun command."""
        verbose = verbose or self.verbose
        build_path = Path(build_dir).resolve()

        # Prepare environment
        env = os.environ.copy()
        env.update(extra_env or {})
        env["TOPLEVEL"] = top_level
        env["MODULE"] = module
        env["TOPLEVEL_LANG"] = top_level_lang

        # xrun [options] [sources]
        cmd = ["xrun", "-64bit", "-elaborate"]

        # VHDL Standard
        std_map = {"08": "-v200x", "93": "-v93", "02": "-v2002"}
        cmd.append(std_map.get(VHDL_STD, "-v200x"))

        # Access permissions (needed for cocotb)
        cmd.append("-access")
        cmd.append("+rwc")

        # Work library
        cmd.extend(["-work", work_lib])

        # Cocotb VPI
        try:
            vpi_lib = subprocess.check_output(["cocotb-config", "--lib-name-path", "vpi", "xcelium"], text=True).strip()
            cmd.extend(["-loadvpi", f"{vpi_lib}:cocotb_vpi_entry"])
        except subprocess.CalledProcessError:
            raise RuntimeError("Could not locate cocotb VPI library for Xcelium.")

        # Generics
        for k, v in (generics or {}).items():
            cmd.extend(["-generic", f"{work_lib}.{top_level}:{k}=>{self._vhdl_literal(v)}"])

        # Top level
        cmd.extend(["-top", f"{work_lib}.{top_level}"])

        # Batch mode execute
        cmd.append("-input")
        cmd.append("@run; exit")

        if verbose:
            print(f"[Xcelium] Running xrun flow: {top_level}")
            print(f"  Command: {' '.join(shlex.quote(c) for c in cmd)}")

        subprocess.run(cmd, cwd=build_path, check=True, env=env)

    @staticmethod
    def _vhdl_literal(val: any) -> str:
        if isinstance(val, bool):
            return "true" if val else "false"
        if isinstance(val, str):
            return f'"{val}"'
        return str(val)

    def analyze_all(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False):
        """Override to handle all libraries at once if possible, or just pass."""
        pass
