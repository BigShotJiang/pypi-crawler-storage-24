# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2020-2025 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Abstract base class defining the simulator backend interface.

All simulator backends (GHDL, NVC, etc.) must implement this interface
to ensure consistent behavior and allow seamless switching between simulators.
"""

from abc import ABC, abstractmethod
from typing import Dict, List, Optional


class SimulatorBackend(ABC):
    """
    Abstract base class for VHDL simulator backends.

    Defines the interface that all simulator implementations must follow
    to enable pluggable simulator support.
    """

    name: str = "unknown"
    """Human-readable name of the simulator (e.g., 'ghdl', 'nvc')."""

    SUPPORTED_WAVE_FORMATS: List[str] = []
    """Waveform formats this backend can produce (e.g., ['fst', 'vcd'])."""

    @abstractmethod
    def analyze(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False) -> None:
        """
        Compile/analyze all VHDL libraries.

        Args:
            libraries: Dict mapping library names to lists of VHDL source files.
                      Example: {"xpm": ["file1.vhd", "file2.vhd"], ...}
            build_dir: Path where compiled libraries will be stored
            verbose: Print detailed compilation commands and messages

        Raises:
            subprocess.CalledProcessError: If compilation fails
        """
        pass

    @abstractmethod
    def elaborate_and_run(
        self,
        top_level: str,
        module: str,
        work_lib: str,
        build_dir: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        generics: Dict[str, any],
        hdl_sources: List[str],
        extra_env: Dict[str, str],
        verbose: bool = False,
        build_args: Optional[List[str]] = None,
        includes: Optional[List[str]] = None,
        test_args: Optional[List[str]] = None,
        custom_libraries: Optional[Dict[str, List[str]]] = None,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """
        Elaborate design and run simulation with cocotb testbench.

        Args:
            top_level: Name of the top-level entity/module
            module: Python test module name (e.g., 'test_edge_detector')
            work_lib: VHDL work library containing the top-level
            build_dir: Path to compiled libraries
            wave_dir: Output directory for waveforms (None to disable)
            top_level_lang: 'vhdl' or 'verilog'
            generics: Dict of VHDL generics to override
            hdl_sources: List of additional HDL source files (VHDL, Verilog, or SV)
            extra_env: Extra environment variables for cocotb
            verbose: Print detailed commands and messages
            build_args: Extra build arguments for the simulator (e.g., ['-Wno-fatal'])
            includes: Verilog/SV include directories (e.g., ['src/includes/'])
            test_args: Extra arguments forwarded to the simulator test/run phase
                      (e.g., ['-t', '1ps'] for Questa timescale resolution)
            custom_libraries: Dict mapping library names to source file lists
                             for named library pre-compilation (e.g.,
                             {'dskop': ['frame_drop_pkg.vhd']})
            wave_formats: List of waveform formats to produce (e.g., ['fst', 'vcd']).
                         If None, uses backend default. Unsupported formats are
                         silently skipped.

        Raises:
            subprocess.CalledProcessError: If elaboration or simulation fails
            RuntimeError: If prerequisites (cocotb, simulator) not available
        """
        pass
