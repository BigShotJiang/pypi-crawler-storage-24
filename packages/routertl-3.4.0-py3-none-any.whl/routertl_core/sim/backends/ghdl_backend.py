# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
GHDL simulator backend for cocotb simulations.

Provides analysis, elaboration, and simulation execution using GHDL
with full support for VHDL libraries and waveform generation.
"""

import os
import shlex
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

from engine.paths import COCOTB_VERBOSE, VHDL_STD

from ..vendor_libraries import get_ghdl_vendor_flags
from .backend_base import SimulatorBackend

try:
    from cocotb_test.simulator import run as cocotb_run
except ImportError:
    cocotb_run = None


class GHDLBackend(SimulatorBackend):
    """GHDL simulator backend."""

    name = "ghdl"
    SUPPORTED_WAVE_FORMATS = ["ghw", "fst", "vcd"]

    def __init__(self, verbose: bool = False):
        """Initialize GHDL backend."""
        self.verbose = verbose or COCOTB_VERBOSE
        self._check_version()

    def _check_version(self):
        """Check GHDL version."""
        try:
            result = subprocess.run(["ghdl", "--version"], capture_output=True, text=True, check=True)
            # Example output: GHDL 2.0.0 (sim) [Dunoon edition]
            # or: GHDL 6.0.0-dev (tarball) ...
            import re

            match = re.search(r"GHDL (\d+)\.(\d+)\.(\d+)", result.stdout)
            if match:
                major = int(match.group(1))
                if major < 6:
                    # Warn or Error? User requested "not usable unless > 6.0"
                    # So Error is appropriate.
                    raise RuntimeError(f"GHDL version {match.group(0)} is too old. RouteRTL requires GHDL >= 6.0.0.")
            # If regex doesn't match, assume it's compliant or weird version string
            # and let it proceed (or warn)
        except FileNotFoundError:
            # run_simulation already checks availability, but good to catch
            raise RuntimeError("GHDL executable not found.")
        except subprocess.CalledProcessError:
            raise RuntimeError("Failed to run 'ghdl --version'.")

    def analyze(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False) -> None:
        """
        Compile all VHDL libraries using GHDL.

        Args:
            libraries: Dict mapping library names to source file lists
            build_dir: Path to store compiled artifacts
            verbose: Enable detailed logging

        Raises:
            subprocess.CalledProcessError: If compilation fails
        """
        verbose = verbose or self.verbose
        build_path = Path(build_dir).resolve()
        build_path.mkdir(parents=True, exist_ok=True)

        compile_opts = {
            "unisim": ["-fsynopsys", "-fexplicit", "-frelaxed"],
        }

        for lib_name, sources in libraries.items():
            lib_workdir = build_path / lib_name
            lib_workdir.mkdir(parents=True, exist_ok=True)

            # Check if already compiled (incremental compilation)
            # Use COCOTB_CLEAN=1 to force recompilation
            force_clean = os.environ.get("COCOTB_CLEAN", "0").lower() in ("1", "true", "yes")
            if not force_clean and self._is_up_to_date(lib_workdir, sources):
                if verbose:
                    print(f"[GHDL] {lib_name} library is up-to-date, skipping")
                continue

            # Compile each source file
            for src in sources:
                src_path = Path(src).resolve()
                if not src_path.exists():
                    print(f"[GHDL] WARNING: Source file does not exist: {src_path}")
                    continue

                cmd = (
                    [
                        "ghdl",
                        "-a",
                        f"--std={VHDL_STD}",
                        f"--work={lib_name}",
                        f"--workdir={lib_workdir}",
                        f"-P{build_path / 'utils'}",
                        f"-P{build_path / 'xpm'}",
                        f"-P{build_path / 'unisim'}",
                    ]
                    + get_ghdl_vendor_flags()
                    + compile_opts.get(lib_name, [])
                    + [str(src_path)]
                )

                if verbose:
                    print(f"[GHDL] Compiling {lib_name}: {src_path.name}")
                    print(f"  Command: {' '.join(shlex.quote(c) for c in cmd)}")

                try:
                    result = subprocess.run(
                        cmd,
                        check=True,
                        capture_output=True,
                        text=True,
                    )
                    if result.stderr and verbose:
                        print(f"  Stderr: {result.stderr}")
                except subprocess.CalledProcessError as e:
                    print(f"[GHDL] ERROR compiling {src_path}:")
                    print(f"  Command: {' '.join(shlex.quote(c) for c in cmd)}")
                    if e.stderr:
                        print(f"  Error output:\n{e.stderr}")
                    raise

            # Write manifest for cache invalidation
            self._write_manifest(lib_workdir, sources)

    def elaborate_and_run(
        self,
        top_level: str,
        module: str,
        work_lib: str,
        build_dir: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        generics: Dict[str, any],
        hdl_sources: List[str],
        extra_env: Dict[str, str],
        verbose: bool = False,
        build_args: Optional[List[str]] = None,
        includes: Optional[List[str]] = None,
        test_args: Optional[List[str]] = None,
        custom_libraries: Optional[Dict[str, List[str]]] = None,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """
        Elaborate and run simulation using GHDL and cocotb.

        Args:
            top_level: Name of the top-level entity
            module: Python test module name
            work_lib: VHDL work library
            build_dir: Path to compiled libraries
            wave_dir: Output directory for waveforms
            top_level_lang: Language of top level
            generics: VHDL generics to override
            hdl_sources: Additional HDL source files
            extra_env: Extra environment variables
            verbose: Enable detailed logging

        Raises:
            RuntimeError: If cocotb_test not available
            subprocess.CalledProcessError: If simulation fails
        """
        verbose = verbose or self.verbose

        if cocotb_run is None:
            raise RuntimeError("cocotb_test.simulator.run not available. Install cocotb-test: pip install cocotb-test")

        build_path = Path(build_dir).resolve()

        # Ensure work library directory exists
        (build_path / work_lib).mkdir(parents=True, exist_ok=True)

        # Prepare compile arguments for cocotb
        compile_args = [
            f"--std={VHDL_STD}",
            f"--work={work_lib}",
            f"--workdir={build_path / work_lib}",
            f"-P{build_path / work_lib}",
            f"-P{build_path / 'utils'}",
            f"-P{build_path / 'xpm'}",
            f"-P{build_path / 'unisim'}",
        ] + get_ghdl_vendor_flags()

        # Prepare simulation arguments
        sim_args = [
            "--vcd-enums",
            "--ieee-asserts=disable",
        ]

        # Add waveform generation if requested — selective format output
        if wave_dir:
            wave_path = Path(wave_dir).resolve()
            wave_path.mkdir(parents=True, exist_ok=True)

            # Resolve formats: parameter → default
            formats = wave_formats if wave_formats else ["fst"]

            _FORMAT_MAP = {
                "ghw": lambda p, e: f"--wave={p / f'{e}.ghw'}",
                "fst": lambda p, e: f"--fst={p / f'{e}.fst'}",
                "vcd": lambda p, e: f"--vcd={p / f'{e}.vcd'}",
            }

            for fmt in formats:
                if fmt in _FORMAT_MAP:
                    sim_args.append(_FORMAT_MAP[fmt](wave_path, top_level))
                elif verbose:
                    print(f"[GHDL] WARNING: Ignoring unsupported format '{fmt}'. Supported: ghw, fst, vcd")

        if verbose:
            print(f"[GHDL] Running simulation: {top_level} (module: {module})")
            print(f"  Build directory: {build_path}")
            if wave_dir:
                print(f"  Wave directory: {wave_path}")
            print(f"  Generics: {generics}")

        # Setup environment
        env = os.environ.copy()
        env.update(extra_env or {})

        # Export generics to environment for testbench visibility
        # This works around GHDL optimization visibility issues
        if generics:
            for k, v in generics.items():
                env[k] = str(v)

        # Prepare valid hdl_sources for cocotb-test
        # cocotb-test GHDL backend seems to require a dict {lib: [files]}
        if hdl_sources:
            if isinstance(hdl_sources, list):
                cocotb_sources = {work_lib: hdl_sources}
            else:
                cocotb_sources = hdl_sources
        else:
            cocotb_sources = {}

        # Explicitly elaborate the design
        # This workaround ensures the executable exists where cocotb-test expects it,
        # handling cases where the makefile-based elaboration fails or library paths mismatch.
        sim_build_dir = Path(build_dir).resolve() / "sim_build"
        sim_build_dir.mkdir(parents=True, exist_ok=True)

        elab_cmd = ["ghdl", "-e"] + compile_args + [f"{work_lib}.{top_level}"]

        if verbose:
            print(f"[GHDL] Elaborating: {work_lib}.{top_level}")
            print(f"  Command: {' '.join(shlex.quote(c) for c in elab_cmd)}")
            print(f"  Cwd: {sim_build_dir}")

        try:
            subprocess.run(
                elab_cmd,
                cwd=sim_build_dir,
                check=True,
                capture_output=True,
                text=True,
            )
        except subprocess.CalledProcessError as e:
            print("[GHDL] Elaboration FAILED:")
            print(f"  Command: {' '.join(shlex.quote(c) for c in elab_cmd)}")
            if e.stderr:
                print(f"  Error output:\n{e.stderr}")
            if e.stdout:
                print(f"  Std output:\n{e.stdout}")
            raise RuntimeError("GHDL elaboration failed")

        # Run the simulation
        try:
            cocotb_run(
                simulator="ghdl",
                toplevel=top_level,
                module=module,
                toplevel_lang=top_level_lang,
                parameters=generics or {},
                vhdl_sources=cocotb_sources,
                waves=False,
                compile_args=compile_args,
                sim_args=sim_args,
                extra_env=env,
                verbose=verbose,
                TOPLEVEL_LIBRARY=work_lib,
                sim_build=str(sim_build_dir),
            )
            if verbose:
                print("[GHDL] Simulation completed successfully")
        except subprocess.CalledProcessError as e:
            print(f"[GHDL] ERROR: Simulation failed with exit code {e.returncode}")
            raise RuntimeError(f"GHDL simulation failed: {e}")

    @staticmethod
    def _is_up_to_date(lib_dir: Path, sources: List[str]) -> bool:
        """
        Check if compiled library is up-to-date.

        Validates both the source set identity (via a manifest file)
        and timestamps to avoid false cache hits when different tests
        compile different sources into the same library name.

        Args:
            lib_dir: Library work directory
            sources: Source file paths

        Returns:
            True if library.cf exists and is newer than all sources
        """
        lib_cf = lib_dir / "library.cf"
        if not lib_cf.exists():
            return False

        # Check source-set identity via manifest
        manifest = lib_dir / ".sources_manifest"
        if manifest.exists():
            recorded = set(manifest.read_text().strip().splitlines())
            current = set(str(Path(s).resolve()) for s in sources)
            if recorded != current:
                return False
        else:
            # No manifest → can't trust cache
            return False

        cf_mtime = lib_cf.stat().st_mtime
        return all(Path(s).stat().st_mtime < cf_mtime for s in sources)

    @staticmethod
    def _write_manifest(lib_dir: Path, sources: List[str]) -> None:
        """Write a source manifest so cache invalidation knows which files were compiled."""
        manifest = lib_dir / ".sources_manifest"
        manifest.write_text("\n".join(str(Path(s).resolve()) for s in sources) + "\n")
