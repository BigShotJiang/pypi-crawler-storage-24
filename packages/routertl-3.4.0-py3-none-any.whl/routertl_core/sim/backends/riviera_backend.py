# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Riviera-PRO simulator backend for cocotb simulations.

Uses cocotb_tools.runner (which drives vsimsa) for compilation and simulation.
Supports both VHDL (vcom + FLI) and Verilog/SystemVerilog (vlog + VPI).
"""

import os
import shutil
from pathlib import Path
from typing import Dict, List, Optional

from engine.paths import COCOTB_VERBOSE, PROJECT_ROOT

from .backend_base import SimulatorBackend


class RivieraBackend(SimulatorBackend):
    """Riviera-PRO simulator backend using cocotb_tools.runner (vsimsa)."""

    name = "riviera"
    SUPPORTED_WAVE_FORMATS = ["asdb"]

    def __init__(self, verbose: bool = False):
        """Initialize Riviera-PRO backend."""
        self.verbose = verbose or COCOTB_VERBOSE

        # Verify vsimsa is on PATH (required by cocotb_tools.runner)
        if not shutil.which("vsimsa"):
            raise FileNotFoundError(
                "Riviera-PRO 'vsimsa' not found in PATH.\nPlease add Riviera-PRO binary directory to your PATH."
            )

    def analyze(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False) -> None:
        """
        Pre-compile VHDL/Verilog libraries using the cocotb runner.

        For the runner-based flow, library compilation is handled inside
        elaborate_and_run() via runner.build(). This method is kept for
        backward compatibility with the LibraryCompiler interface.
        """
        # The runner handles compilation internally, so this is a no-op
        # when using the runner flow. Libraries passed here will be
        # compiled by LibraryCompiler.compile_all() before this is called.
        pass

    def elaborate_and_run(
        self,
        top_level: str,
        module: str,
        work_lib: str,
        build_dir: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        generics: Dict[str, any],
        hdl_sources: List[str],
        extra_env: Dict[str, str],
        verbose: bool = False,
        build_args: Optional[List[str]] = None,
        includes: Optional[List[str]] = None,
        test_args: Optional[List[str]] = None,
        custom_libraries: Optional[Dict[str, List[str]]] = None,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """
        Compile and run simulation using cocotb_tools.runner (vsimsa).

        This mirrors the Verilator backend approach: the cocotb runner
        handles compilation (vlog/vcom), elaboration, and cocotb interface
        loading (VPI for SV, FLI/VHPI for VHDL) automatically.
        """
        verbose = verbose or self.verbose

        # Import cocotb runner
        try:
            try:
                from cocotb_tools.runner import get_runner
            except ImportError:
                from cocotb.runner import get_runner
        except ImportError:
            raise RuntimeError("Cocotb runner not found. Please install cocotb ≥ 1.9.0.")

        runner = get_runner("riviera")

        # Prepare environment
        env = os.environ.copy()
        env.update(extra_env or {})

        # Auto-configure PYTHONPATH
        python_paths = []
        cocotb_root = PROJECT_ROOT / "sim" / "cocotb"
        python_paths.append(str(cocotb_root))
        python_paths.append(str(PROJECT_ROOT))
        for p in env.get("PYTHONPATH", "").split(os.pathsep):
            if p and p not in python_paths:
                python_paths.append(p)
        env["PYTHONPATH"] = os.pathsep.join(python_paths)

        # ── Package-first source ordering ──
        _HEADER_EXTS = (".vh", ".svh")
        headers: List[str] = []
        packages: List[str] = []
        modules: List[str] = []

        for src in hdl_sources or []:
            p = Path(src)
            if p.suffix in _HEADER_EXTS:
                headers.append(src)
            elif p.stem.endswith("_pkg") and p.suffix == ".sv":
                packages.append(src)
            else:
                modules.append(src)

        sorted_sources = headers + packages + modules

        # ── Auto-derive include directories ──
        auto_includes: List[str] = []
        for hdr in headers:
            parent = str(Path(hdr).resolve().parent)
            if parent not in auto_includes:
                auto_includes.append(parent)

        all_includes = list(auto_includes)
        for inc in includes or []:
            inc_resolved = str(Path(inc).resolve())
            if inc_resolved not in all_includes:
                all_includes.append(inc_resolved)

        # ── Build arguments ──
        all_build_args = list(build_args or [])

        if verbose:
            print(f"[Riviera] Running build for top: {top_level}")
            print(f"  Top-level language: {top_level_lang}")
            print(f"  Sources ({len(sorted_sources)}):")
            for s in sorted_sources:
                print(f"    {s}")
            if all_includes:
                print(f"  Include dirs: {all_includes}")
            if all_build_args:
                print(f"  Build args: {all_build_args}")
            print(f"  PYTHONPATH: {env.get('PYTHONPATH', '')}")

        # 1. Build (compilation via vsimsa)
        runner.build(
            sources=sorted_sources,
            hdl_toplevel=top_level,
            build_dir=build_dir,
            waves=bool(wave_dir),
            parameters=generics or {},
            includes=all_includes,
            build_args=all_build_args,
            verbose=verbose,
        )

        if verbose:
            print(f"[Riviera] Running test: {module}")

        # 2. Test (simulation via vsimsa)
        runner.test(
            hdl_toplevel=top_level,
            hdl_toplevel_lang=top_level_lang,
            test_module=module,
            build_dir=build_dir,
            waves=bool(wave_dir),
            parameters=generics or {},
            extra_env=env,
            verbose=verbose,
        )

    @staticmethod
    def _is_up_to_date(lib_dir: Path, sources: List[str]) -> bool:
        """Heuristic check if compiled library is newer than all sources."""
        if not lib_dir.exists():
            return False
        lib_mtime = lib_dir.stat().st_mtime
        return all(Path(s).stat().st_mtime < lib_mtime for s in sources)
