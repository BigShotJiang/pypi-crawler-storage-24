# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
Aldec Active-HDL simulator backend for cocotb simulations.
"""

import os
import shutil
import subprocess
from pathlib import Path
from typing import Dict, List, Optional

from engine.paths import COCOTB_VERBOSE, VHDL_STD

from .backend_base import SimulatorBackend


class ActiveHDLBackend(SimulatorBackend):
    """Active-HDL simulator backend using vsimsa."""

    name = "activehdl"
    SUPPORTED_WAVE_FORMATS = ["asdb"]

    def __init__(self, verbose: bool = False):
        """Initialize Active-HDL backend."""
        self.verbose = verbose or COCOTB_VERBOSE

        # Check if vsimsa is available
        if not shutil.which("vsimsa"):
            raise FileNotFoundError("Active-HDL executable 'vsimsa' not found in PATH.")

    def analyze(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False) -> None:
        """Compile libraries using vsimsa script."""
        verbose = verbose or self.verbose
        build_path = Path(build_dir).resolve()
        build_path.mkdir(parents=True, exist_ok=True)

        std_map = {"08": "2008", "93": "93", "02": "2002"}
        vhdl_std = std_map.get(VHDL_STD, "2008")

        script = []
        for lib_name, sources in libraries.items():
            script.append(f"alib {lib_name}")
            script.append(f"amap {lib_name} {lib_name}")
            for src in sources:
                script.append(f"acom -{vhdl_std} -work {lib_name} {Path(src).resolve()}")

        script_path = build_path / "compile.do"
        with open(script_path, "w") as f:
            f.write("\n".join(script))

        if verbose:
            print("[Active-HDL] Compiling libraries via vsimsa...")

        subprocess.run(["vsimsa", "-do", "compile.do"], cwd=build_path, check=True)

    def elaborate_and_run(
        self,
        top_level: str,
        module: str,
        work_lib: str,
        build_dir: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        generics: Dict[str, any],
        hdl_sources: List[str],
        extra_env: Dict[str, str],
        verbose: bool = False,
        build_args: Optional[List[str]] = None,
        includes: Optional[List[str]] = None,
        test_args: Optional[List[str]] = None,
        custom_libraries: Optional[Dict[str, List[str]]] = None,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """Run simulation via vsimsa."""
        verbose = verbose or self.verbose
        build_path = Path(build_dir).resolve()

        # Prepare environment
        env = os.environ.copy()
        env.update(extra_env or {})
        env["TOPLEVEL"] = top_level
        env["MODULE"] = module
        env["TOPLEVEL_LANG"] = top_level_lang

        # Load Cocotb VHPI
        try:
            vhpi_lib = subprocess.check_output(
                ["cocotb-config", "--lib-name-path", "vhpi", "activehdl"], text=True
            ).strip()
        except subprocess.CalledProcessError:
            raise RuntimeError("Could not locate cocotb VHPI library for Active-HDL.")

        # Build simulation script
        sim_script = [f"asim -loadvhpi {vhpi_lib} {work_lib}.{top_level}"]

        # Generics (passed via asim typically)
        for k, v in (generics or {}).items():
            sim_script[0] += f" -g{k}={self._vhdl_literal(v)}"

        sim_script.append("run -all")
        sim_script.append("endsim")
        sim_script.append("quit")

        do_path = build_path / "sim.do"
        with open(do_path, "w") as f:
            f.write("\n".join(sim_script))

        if verbose:
            print("[Active-HDL] Running simulation script...")

        subprocess.run(["vsimsa", "-do", "sim.do"], cwd=build_path, check=True, env=env)

    @staticmethod
    def _vhdl_literal(val: any) -> str:
        if isinstance(val, bool):
            return "true" if val else "false"
        if isinstance(val, str):
            return f'"{val}"'
        return str(val)
