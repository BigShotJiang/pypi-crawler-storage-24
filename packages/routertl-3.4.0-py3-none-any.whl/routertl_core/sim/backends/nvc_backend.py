# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

# MIT License
#
# Copyright (c) 2024-2026 Daniel J. Mazure
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
# IN THE SOFTWARE.

"""
NVC (VHDL compiler) simulator backend for cocotb simulations.

Provides analysis, elaboration, and simulation execution using NVC
with full support for VHDL libraries and waveform generation.
"""

import os
import shlex
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Dict, List, Optional

from engine.paths import COCOTB_VERBOSE, NVC_PRESERVE_CASE, PROJECT_ROOT, VHDL_STD

from .backend_base import SimulatorBackend


class NVCBackend(SimulatorBackend):
    """NVC simulator backend."""

    name = "nvc"
    SUPPORTED_WAVE_FORMATS = ["fst", "vcd"]

    def __init__(self, verbose: bool = False):
        """Initialize NVC backend."""
        self.verbose = verbose or COCOTB_VERBOSE
        self.preserve_case = NVC_PRESERVE_CASE

        # TICH: Auto-configure NVC environment if binary not in PATH
        if not shutil.which("nvc"):
            home = os.environ.get("HOME", "")
            if home:
                nvc_bin = os.path.join(home, ".local/opt/nvc/usr/bin")
                if os.path.exists(nvc_bin):
                    self.verbose and print(f"[NVC] Auto-adding to PATH: {nvc_bin}")
                    os.environ["PATH"] = nvc_bin + os.pathsep + os.environ.get("PATH", "")

        # Auto-configure LD_LIBRARY_PATH for LLVM, Python, and dependencies
        home = os.environ.get("HOME", "")
        if home:
            # Python LIBDIR — needed for NVC VHPI to dlopen libpythonX.Y.so
            import sysconfig

            py_libdir = sysconfig.get_config_var("LIBDIR")
            # LIBPL has the unversioned .so symlink (e.g. libpython3.10.so)
            py_libpl = sysconfig.get_config_var("LIBPL")

            # Common paths used in this environment
            lib_paths = [
                os.path.join(home, ".local/opt/libs/usr/lib/x86_64-linux-gnu"),
                os.path.join(home, ".oss-cad-suite/lib"),
            ]
            if py_libdir:
                lib_paths.append(py_libdir)
            if py_libpl:
                lib_paths.append(py_libpl)
            current_ld = os.environ.get("LD_LIBRARY_PATH", "")
            new_paths = [p for p in lib_paths if os.path.exists(p) and p not in current_ld]

            if new_paths:
                new_ld = os.pathsep.join(new_paths)
                if current_ld:
                    os.environ["LD_LIBRARY_PATH"] = new_ld + os.pathsep + current_ld
                else:
                    os.environ["LD_LIBRARY_PATH"] = new_ld
                self.verbose and print(f"[NVC] Updated LD_LIBRARY_PATH with: {new_paths}")

        # Auto-add Python shared library directories so NVC's VHPI loader can
        # find libpython3.x.so when launching the cocotb subprocess.
        # LIBDIR has the versioned .so.1.0, LIBPL has the unversioned .so (needed by dlopen).
        python_lib_dirs = []
        for var in ("LIBDIR", "LIBPL"):
            d = sysconfig.get_config_var(var)
            if d and os.path.isdir(d):
                python_lib_dirs.append(d)

        if python_lib_dirs:
            current_ld = os.environ.get("LD_LIBRARY_PATH", "")
            new_dirs = [d for d in python_lib_dirs if d not in current_ld]
            if new_dirs:
                prefix = os.pathsep.join(new_dirs)
                os.environ["LD_LIBRARY_PATH"] = prefix + os.pathsep + current_ld if current_ld else prefix
                self.verbose and print(f"[NVC] Added Python lib dirs to LD_LIBRARY_PATH: {new_dirs}")

        # Final check
        if not shutil.which("nvc"):
            raise FileNotFoundError(
                "NVC executable 'nvc' not found in PATH.\n"
                "Please add NVC binary directory to your PATH environment variable.\n"
                "Example: export PATH=$PATH:~/.local/opt/nvc/usr/bin"
            )

    def analyze(self, libraries: Dict[str, List[str]], build_dir: str, verbose: bool = False) -> None:
        """
        Compile all VHDL libraries using NVC.

        Args:
            libraries: Dict mapping library names to source file lists
            build_dir: Path to store compiled artifacts
            verbose: Enable detailed logging

        Raises:
            subprocess.CalledProcessError: If compilation fails
        """
        verbose = verbose or self.verbose
        build_path = Path(build_dir).resolve()
        build_path.mkdir(parents=True, exist_ok=True)

        # Track built libraries for linking
        link_libs = {}

        for lib_name, sources in libraries.items():
            lib_workdir = build_path / lib_name
            lib_workdir.mkdir(parents=True, exist_ok=True)

            # Initialize NVC library from build root (creates/inits subdir matching lib_name)
            if not (lib_workdir / "_NVC_LIB").exists() and not (lib_workdir / "_lib.d").exists():
                subprocess.run(["nvc", f"--work={lib_name}:{lib_workdir}", "--init"], cwd=build_path, check=True)

            # Check if already compiled and up-to-date
            # Use COCOTB_CLEAN=1 to force recompilation
            force_clean = os.environ.get("COCOTB_CLEAN", "0").lower() in ("1", "true", "yes")
            if not force_clean and self._is_up_to_date(lib_workdir, sources):
                if verbose:
                    print(f"[NVC] {lib_name} library is up-to-date, skipping")
                link_libs[lib_name] = str(lib_workdir)
                continue

            # Clean stale compiled units so a different VHDL standard or source
            # set doesn't interfere with the fresh compilation.
            if force_clean and lib_workdir.exists():
                import shutil as _shutil

                _shutil.rmtree(lib_workdir)
                lib_workdir.mkdir(parents=True, exist_ok=True)
                if verbose:
                    print(f"[NVC] Cleaned library directory: {lib_workdir}")

            # Compile all source files for this library in a single nvc -a invocation.
            # This is required for VHDL designs where a package's component declaration
            # (with unconstrained ports) and the entity declaration (with constrained ports)
            # are in the same file — NVC needs to see both in the same analysis pass.
            valid_sources = []
            for src in sources:
                src_path = Path(src).resolve()
                if not src_path.exists():
                    print(f"[NVC] WARNING: Source file does not exist: {src_path}")
                    continue
                valid_sources.append(src_path)

            if valid_sources:
                std_map = {"08": "2008", "93": "1993", "02": "2002", "19": "2019"}
                nvc_std = std_map.get(VHDL_STD, VHDL_STD)

                cmd = [
                    "nvc",
                    "-L",
                    str(build_path),
                    f"--std={nvc_std}",
                    f"--work={lib_name}:{build_path / lib_name}",
                    "-a",
                    "--relaxed",
                ]

                if self.preserve_case:
                    cmd.append("--preserve-case")

                cmd += [str(p) for p in valid_sources]

                if verbose:
                    print(f"[NVC] Compiling {lib_name}: {[p.name for p in valid_sources]}")
                    print(f"  Command: {' '.join(shlex.quote(c) for c in cmd)}")

                try:
                    result = subprocess.run(
                        cmd,
                        cwd=build_path,
                        check=False,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                    )
                    if result.stderr and verbose:
                        print(f"  Stderr: {result.stderr}")
                    if result.returncode != 0:
                        raise subprocess.CalledProcessError(
                            result.returncode, cmd, output=result.stdout, stderr=result.stderr
                        )
                except subprocess.CalledProcessError as e:
                    print(f"[NVC] ERROR compiling library '{lib_name}':")
                    print(f"  Command: {' '.join(shlex.quote(c) for c in cmd)}")
                    if e.stderr:
                        print(f"  Error output:\n{e.stderr}")
                    raise

            # Write manifest for cache invalidation
            self._write_manifest(lib_workdir, sources)

            # Add to link_libs for subsequent libraries
            link_libs[lib_name] = str(lib_workdir)

    def elaborate_and_run(
        self,
        top_level: str,
        module: str,
        work_lib: str,
        build_dir: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        generics: Dict[str, any],
        hdl_sources: List[str],
        extra_env: Dict[str, str],
        verbose: bool = False,
        build_args: Optional[List[str]] = None,
        includes: Optional[List[str]] = None,
        test_args: Optional[List[str]] = None,
        custom_libraries: Optional[Dict[str, List[str]]] = None,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """
        Elaborate and run simulation using NVC and cocotb.

        Args:
            top_level: Name of the top-level entity
            module: Python test module name
            work_lib: VHDL work library
            build_dir: Path to compiled libraries
            wave_dir: Output directory for waveforms
            top_level_lang: Language of top level
            generics: VHDL generics to override
            hdl_sources: Additional HDL source files
            extra_env: Extra environment variables
            verbose: Enable detailed logging

        Raises:
            RuntimeError: If prerequisites not available
            subprocess.CalledProcessError: If elaboration/simulation fails
        """
        verbose = verbose or self.verbose
        build_path = Path(build_dir).resolve()

        if verbose:
            print(f"[NVC] Running simulation: {top_level} (module: {module})")
            print(f"  Build directory: {build_path}")
            if wave_dir:
                print(f"  Wave directory: {wave_dir}")
            print(f"  Generics: {generics}")

        # Step 1: Elaborate
        self._elaborate(top_level, work_lib, build_path, generics, verbose)

        # Step 2: Run with cocotb
        self._run_cocotb(top_level, module, build_path, work_lib, wave_dir, top_level_lang, extra_env, verbose,
                         wave_formats=wave_formats)

        if verbose:
            print("[NVC] Simulation completed successfully")

    def _elaborate(
        self,
        top_level: str,
        work_lib: str,
        build_dir: Path,
        generics: Dict[str, any],
        verbose: bool = False,
    ) -> None:
        """
        Elaborate the design with NVC.

        Args:
            top_level: Top-level entity name
            work_lib: Work library
            build_dir: Build directory path
            generics: Generic overrides
            verbose: Enable logging

        Raises:
            subprocess.CalledProcessError: If elaboration fails
        """
        std_map = {"08": "2008", "93": "1993", "02": "2002", "19": "2019"}
        nvc_std = std_map.get(VHDL_STD, VHDL_STD)

        cmd = [
            "nvc",
            "-L",
            str(build_dir),
            f"--std={nvc_std}",
            f"--work={work_lib}:{build_dir / work_lib}",
            "-e",
        ]

        if self.preserve_case:
            cmd.append("--preserve-case")

        # Add generic overrides
        for key, val in (generics or {}).items():
            vhdl_val = self._vhdl_literal(val)
            cmd += ["-g", f"{key}={vhdl_val}"]

        cmd.append(top_level)

        if verbose:
            print(f"[NVC] Elaborating: {' '.join(shlex.quote(c) for c in cmd)}")

        try:
            result = subprocess.run(
                cmd,
                check=True,
                capture_output=True,
                text=True,
                cwd=build_dir,
            )
            if result.stderr and verbose:
                print(f"  Stderr: {result.stderr}")
        except subprocess.CalledProcessError as e:
            print("[NVC] ERROR during elaboration:")
            print(f"  Command: {' '.join(shlex.quote(c) for c in cmd)}")
            if e.stderr:
                print(f"  Error output:\n{e.stderr}")
            raise RuntimeError(f"NVC elaboration failed: {e}")

    def _run_cocotb(
        self,
        top_level: str,
        module: str,
        build_dir: Path,
        work_lib: str,
        wave_dir: Optional[str],
        top_level_lang: str,
        extra_env: Dict[str, str],
        verbose: bool = False,
        wave_formats: Optional[List[str]] = None,
    ) -> None:
        """
        Run simulation with cocotb via NVC VHPI interface.

        Args:
            top_level: Top-level entity name
            module: Python test module
            build_dir: Build directory
            work_lib: Work library name
            wave_dir: Waveform output directory
            top_level_lang: Language of top level
            extra_env: Extra environment variables
            verbose: Enable logging

        Raises:
            RuntimeError: If cocotb config not available
            subprocess.CalledProcessError: If simulation fails
        """
        # Get VHPI library path
        try:
            vhpi_lib = subprocess.check_output(
                ["cocotb-config", "--lib-name-path", "vhpi", "nvc"],
                text=True,
            ).strip()
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Could not locate NVC VHPI library. Is cocotb installed? Error: {e}")

        # Prepare environment
        env = os.environ.copy()
        env.update(extra_env or {})
        env["TOPLEVEL"] = top_level
        env["MODULE"] = module
        env["COCOTB_TEST_MODULES"] = module
        env["TOPLEVEL_LANG"] = top_level_lang

        # Cocotb 2.0+ requires PYGPI_PYTHON_BIN to locate the Python interpreter
        if "PYGPI_PYTHON_BIN" not in env:
            env["PYGPI_PYTHON_BIN"] = sys.executable

        # TICH: Auto-configure PYTHONPATH
        # Ensure sim/cocotb and sim/cocotb/tests are available
        python_paths = env.get("PYTHONPATH", "").split(os.pathsep)
        cocotb_root = PROJECT_ROOT / "sim" / "cocotb"
        tests_root = cocotb_root / "tests"

        if str(cocotb_root) not in python_paths:
            python_paths.append(str(cocotb_root))
        if str(tests_root) not in python_paths:
            python_paths.append(str(tests_root))

        # Add packages (e.g. cocotbext-i2c)
        packages_root = cocotb_root / "packages"
        if packages_root.exists():
            for pkg_dir in packages_root.iterdir():
                if pkg_dir.is_dir() and str(pkg_dir) not in python_paths:
                    python_paths.append(str(pkg_dir))

        # Propagate sys.path entries injected by run_simulation()
        # (e.g. test file parent dirs for flat module names)
        for p in sys.path:
            if p and p not in python_paths:
                python_paths.append(p)

        env["PYTHONPATH"] = os.pathsep.join(python_paths)

        # Build run command
        cmd = [
            "nvc",
            "-L",
            str(build_dir),
            f"--work={work_lib}:{build_dir / work_lib}",
            "-r",
            top_level,
            f"--load={vhpi_lib}",
        ]

        # Resolve formats: parameter → env var (backward compat) → default
        if wave_formats:
            formats = wave_formats
        else:
            sim_wave_format = os.environ.get("SIM_WAVE_FORMAT", "fst").lower()
            formats = [f.strip() for f in sim_wave_format.split(",") if f.strip()]
            if not formats:
                formats = ["fst"]

        # Run simulation for each format (NVC only supports one --wave per run typically)
        for fmt in formats:
            run_cmd = cmd.copy()

            # Add waveform generation if requested
            if wave_dir:
                wave_path = Path(wave_dir).resolve()
                wave_path.mkdir(parents=True, exist_ok=True)

                # Check for supported formats
                if fmt not in ("fst", "vcd"):
                    if verbose:
                        print(f"[NVC] WARNING: Ignoring unsupported format '{fmt}'. Supported: fst, vcd")
                    continue

                ext = fmt
                run_cmd.append(f"--wave={wave_path / f'{top_level}.{ext}'}")
                run_cmd.append(f"--format={fmt}")

            if verbose:
                print(f"[NVC] Running ({fmt}): {' '.join(shlex.quote(c) for c in run_cmd)}")

            try:
                subprocess.run(
                    run_cmd,
                    check=True,
                    cwd=build_dir,
                    env=env,
                )
            except subprocess.CalledProcessError as e:
                print(f"[NVC] ERROR: Simulation failed with exit code {e.returncode}")
                print(f"  Command: {' '.join(shlex.quote(c) for c in run_cmd)}")
                raise RuntimeError(f"NVC simulation failed: {e}")

    @staticmethod
    def _vhdl_literal(val: any) -> str:
        """
        Convert Python value to VHDL generic literal.

        Args:
            val: Python value (bool, str, int, etc.)

        Returns:
            VHDL literal string representation
        """
        if isinstance(val, bool):
            return "true" if val else "false"
        if isinstance(val, str):
            return f'"{val}"'
        return str(val)

    @staticmethod
    def _is_up_to_date(lib_dir: Path, sources: List[str]) -> bool:
        """
        Check if compiled library is up-to-date (NVC-specific).

        Validates both the source set identity (via a manifest file)
        and timestamps to avoid false cache hits when different tests
        compile different sources into the same library name.

        Args:
            lib_dir: Library work directory
            sources: Source file paths

        Returns:
            True if library appears compiled and current
        """
        lib_dir = Path(lib_dir)
        # Check if any NVC work files exist
        if not list(lib_dir.glob("*")):
            return False

        # Check source-set identity via manifest
        manifest = lib_dir / ".sources_manifest"
        if manifest.exists():
            recorded = set(manifest.read_text().strip().splitlines())
            current = set(str(Path(s).resolve()) for s in sources)
            if recorded != current:
                return False
        else:
            # No manifest → can't trust cache
            return False

        # Get most recent timestamp in work directory, ignoring metadata files and dirs
        # NVC uses directories starting with _ for internal metadata (e.g. _lib.d)
        work_files = [
            f
            for f in lib_dir.glob("**/*")
            if f.is_file()
            and not any(p.startswith("_") for p in f.relative_to(lib_dir).parts)
            and f.name != ".sources_manifest"
        ]

        if not work_files:
            return False

        work_times = [f.stat().st_mtime for f in work_files]
        newest_work = max(work_times)
        return all(Path(s).stat().st_mtime < newest_work for s in sources)

    @staticmethod
    def _write_manifest(lib_dir: Path, sources: List[str]) -> None:
        """Write a source manifest so cache invalidation knows which files were compiled."""
        manifest = lib_dir / ".sources_manifest"
        manifest.write_text("\n".join(str(Path(s).resolve()) for s in sources) + "\n")
