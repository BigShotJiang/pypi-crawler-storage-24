# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL Core — simulation orchestration engine.

This package contains the simulation backend orchestration layer:

- simulation: Multi-backend invocation, library compilation, waveform negotiation
- library_compiler: Custom library pre-compilation logic
- result_collector: JUnit XML/JSON result aggregation and history tracking
- vendor_libraries: Vendor library path resolution and precompile orchestration
- default_libraries: Library configuration constants
- backends: Pluggable simulator backends (NVC, GHDL, Questa, Riviera, etc.)
"""

import sys
from pathlib import Path

# Bootstrap: ensure sim/cocotb/ is on sys.path so that "from engine.paths import ..."
# resolves correctly. The engine.paths module stays at its original location
# (sim/cocotb/engine/paths.py) because it uses __file__ traversal for path resolution.
# This bootstrap is needed when routertl_core.sim.* modules are imported directly
# (e.g. in tests) rather than through the proxy chain at sim/cocotb/engine/*.
_SDK_ROOT = Path(__file__).resolve().parents[2]  # routertl_core/sim/ → routertl/
_COCOTB_DIR = _SDK_ROOT / "sim" / "cocotb"
if _COCOTB_DIR.is_dir() and str(_COCOTB_DIR) not in sys.path:
    sys.path.insert(0, str(_COCOTB_DIR))
