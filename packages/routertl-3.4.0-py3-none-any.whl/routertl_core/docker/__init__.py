# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: MIT

"""RouteRTL Core — Docker orchestration engine.

This subpackage contains the domain logic for Docker-based EDA
container management: volume resolution, edition-aware mapping,
bind mount detection, and EDA version probing.  Compiled to .so
on release builds via Cython (P2.59).
"""
