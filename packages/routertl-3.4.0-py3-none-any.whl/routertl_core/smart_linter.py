# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

"""Smart HDL Linter — dual-engine VHDL + SystemVerilog analysis pipeline.

Executes a multi-phase linting flow:

1. **PRECOMPILE** — compile global VHDL packages (XPM, utils, project pkgs)
   into persistent GHDL work directories.  Custom library files are
   excluded (they use cross-library references like ``use tich.pkg``).
2. **COMPILE_LIB** — compile each custom library into its own GHDL work
   directory, with files topologically sorted via the dependency resolver.
3. **LINT (Phase 2a)** — resolve hierarchies and lint VHDL files against
   all pre-compiled libraries using GHDL.
4. **SV LINT (Phase 2b)** — lint SystemVerilog/Verilog files with
   ``verilator --lint-only -Wall``.  Gracefully skipped when Verilator
   is not installed.

See ``docs/reference/LINTER_PIPELINE.md`` for the full reference.
"""
# NOTE: lint_tracker is imported lazily inside _persist_lint_results()
# to avoid circular imports and keep startup fast.

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from sdk.cli.console import get_console

_con = get_console()

APP_ROOT = Path(__file__).resolve().parents[1]
SDK_DIR = APP_ROOT / "sdk"


LOG_FILE = Path("sim/lint.log")


def _has_verilator():
    """Check if Verilator is available on the system PATH."""
    return shutil.which("verilator") is not None


def exit_with_status(root_dir, failure_code):
    """Write the real linting status to a file, then exit 0.

    **Dual-mode architecture (by design):**

    This function **always exits 0** regardless of ``failure_code``.
    The real exit code is persisted to ``sim/lint.status`` so that
    consumer-facing callers can read it:

    - **Make targets** (``make linting``): Read ``sim/lint.status``
      instead of relying on ``$?``.  This prevents Make from aborting
      the full recipe pipeline on the first linting failure, allowing
      all hierarchies to be analysed before reporting.

    - **CLI** (``rr linting``): The CLI command reads
      ``sim/lint.status`` after the subprocess and sets the correct
      exit code for CI gating.

    - **Pre-commit hooks**: Both ``tools/githooks/pre-commit`` and
      ``project-pre-commit`` explicitly read ``sim/lint.status``
      to gate the commit (see P1.33).

    **Do NOT change this to ``sys.exit(failure_code)``** without
    updating all three consumers above.

    Parameters
    ----------
    root_dir : str or Path
        Project root directory.
    failure_code : int
        The real linting exit code (0=pass, non-zero=failure).
    """
    try:
        status_file = Path(root_dir) / "sim" / "lint.status"
        os.makedirs(status_file.parent, exist_ok=True)
        with open(status_file, "w") as f:
            f.write(str(failure_code))
    except Exception:
        import logging

        logging.debug("Failed to write lint status file", exc_info=True)
    sys.exit(0)


# Status priority for merging: FAIL > WARN > SKIP > PASS
_STATUS_PRIORITY = {"FAIL": 3, "WARN": 2, "SKIP": 1, "PASS": 0}


def _merge_sv_into(entry, sv_status, sv_detail):
    """Merge a Verilator SV result into an existing result entry.

    Updates the entry's status to the worst of (current, SV) and
    refines the details column when the SV result is more severe.
    """
    if not entry:
        return
    # Promote to worst status
    if _STATUS_PRIORITY.get(sv_status, 0) > _STATUS_PRIORITY.get(entry["status"], 0):
        entry["status"] = sv_status
        entry["details"] = sv_detail


def print_summary_table(results):
    """Prints a summary table of linting results."""
    _con.print("\n[cyan]📊 Linting Summary[/]")
    _con.print("━" * 72)
    _con.print(f"{'Hierarchy Top':<30} │ {'Status':<10} │ {'Details'}")
    _con.print("─" * 31 + "┼" + "─" * 12 + "┼" + "─" * 26)

    for r in results:
        # Pad visible text so the total string (markup + text + spaces)
        # is always the same character count.  Rich tags are invisible
        # but f-string :<N counts them, so each tag length needs its
        # own compensation.  We target 19 raw chars total.
        if r["status"] == "SKIP":
            status_icon = f"[cyan]{'SKIP':<10}[/]"    # 6+10+3 = 19
        elif r["status"] == "PASS":
            status_icon = f"[green]{'PASS':<9}[/]"    # 7+9+3  = 19
        elif r["status"] == "WARN":
            status_icon = f"[yellow]{'WARN':<8}[/]"   # 8+8+3  = 19
        else:
            status_icon = f"[red]{'FAIL':<11}[/]"     # 5+11+3 = 19
        _con.print(f"{r['top']:<30} │ {status_icon} │ {r['details']}")

    _con.print("━" * 72)
    _con.print(f"📝 detailed logs saved to {LOG_FILE}. Run 'rr view-log' to view them.\n")


def _persist_lint_results(results, project_root):
    """Record lint results for each hierarchy in the LintTracker cache.

    Skips orphan entries and entries with SKIP status.
    """
    from datetime import datetime, timezone

    from sdk.engine.lint_tracker import LintResult, LintTracker

    tracker = LintTracker(project_root)
    now = datetime.now(timezone.utc).isoformat(timespec="seconds")
    for r in results:
        if r["status"] == "SKIP" or r["top"].startswith("Orphan"):
            continue
        tracker.record(LintResult(
            module=r["top"],
            status=r["status"],
            timestamp=now,
        ))


def run_lint(root_dir, mode, file_list_str, pkg_files, xpm_files, utils_files, log_handle, extra_lib_paths=""):
    """Invoke ``linting.sh`` in the specified mode.

    Parameters
    ----------
    root_dir : str
        Project root directory (passed as ``$2`` to ``linting.sh``).
    mode : str
        One of ``PRECOMPILE``, ``COMPILE_LIB``, or ``LINT``.
    file_list_str : str
        Space-separated files.  Meaning varies by mode:
        * PRECOMPILE — unused (empty string)
        * COMPILE_LIB — library name (``$3``)
        * LINT — unit files to analyse (``$3``)
    pkg_files : str
        Package files for PRECOMPILE (``$4``), or lib files for
        COMPILE_LIB (``$4``).  Empty for LINT.
    xpm_files : str
        XPM stub files (``$5``).  Only used in PRECOMPILE.
    utils_files : str
        Utility library files (``$6``).  Only used in PRECOMPILE.
    log_handle : file
        Open file handle for writing captured stdout.
    extra_lib_paths : str
        Additional ``-P`` search paths for the LINT phase (``$7``).

    Returns
    -------
    tuple[int, bool]
        ``(return_code, has_warnings)``.
    """
    lint_script = SDK_DIR / "scripts" / "linting.sh"
    cmd = [
        "bash",
        str(lint_script),
        mode,
        str(root_dir),
        file_list_str,
        pkg_files,
        xpm_files,
        utils_files,
        extra_lib_paths,
    ]
    # Capture stdout/stderr to analyze for warnings
    res = subprocess.run(cmd, capture_output=True, text=True)

    # Write both stdout and stderr to the log file
    log_handle.write(res.stdout)
    if res.stderr:
        log_handle.write(res.stderr)
    log_handle.flush()

    # Heuristic for warnings (parser output usually contains ⚠ or [warning])
    combined = res.stdout + res.stderr
    has_warnings = "⚠" in combined or "warning" in combined.lower()

    return res.returncode, has_warnings


def run_verilator_lint(sv_files, include_dirs, log_handle):
    """Invoke ``verilator --lint-only -Wall`` on SystemVerilog/Verilog files.

    Parameters
    ----------
    sv_files : list[str]
        Absolute paths to ``.sv``/``.v`` files to lint.
    include_dirs : list[str]
        Directories to pass as ``-I`` include search paths.
    log_handle : file
        Open file handle for writing captured output.

    Returns
    -------
    tuple[int, bool]
        ``(return_code, has_warnings)``.
    """
    inc_flags = [f"-I{d}" for d in sorted(set(include_dirs))]
    cmd = ["verilator", "--lint-only", "-Wall", "-Wno-fatal"] + inc_flags + sv_files
    res = subprocess.run(cmd, capture_output=True, text=True)

    log_handle.write(res.stdout)
    if res.stderr:
        log_handle.write(res.stderr)
    log_handle.flush()

    combined = res.stdout + res.stderr
    has_warnings = "warning" in combined.lower()
    return res.returncode, has_warnings


def _partition_files(files, compiled_set, exclude_set, root_dir):
    """Partition a file list into VHDL, SV, and skipped buckets.

    Parameters
    ----------
    files : list[str]
        Absolute paths to source files.
    compiled_set : set[str]
        Files already compiled (to skip).
    exclude_set : set[str]
        Files to exclude (absolute or relative-to-root paths).
    root_dir : str
        Project root for resolving relative paths.

    Returns
    -------
    tuple[list[str], list[str], list[str]]
        ``(vhdl_files, sv_files, skipped_files)``.
    """
    vhdl_files = []
    sv_files = []
    skipped_files = []
    for f in files:
        if f in compiled_set:
            continue
        try:
            rel_f = str(Path(f).relative_to(root_dir))
        except ValueError:
            rel_f = f
        if rel_f in exclude_set or f in exclude_set:
            skipped_files.append(f)
            continue
        if f.endswith((".v", ".sv", ".vh", ".svh")):
            sv_files.append(f)
            continue
        vhdl_files.append(f)
    return vhdl_files, sv_files, skipped_files


def _resolve_libraries(src_args, resolver_script):
    """Load and merge auto-discovered + manual custom library memberships.

    Returns
    -------
    tuple[dict, set, dict]
        ``(custom_libs, custom_lib_files, lib_sources)``.
    """
    custom_lib_files = set()
    custom_libs = {}

    # Step 1: Auto-discover via --discover-libs
    auto_libs = {}
    try:
        cmd = ["python3", str(resolver_script)] + src_args + ["--discover-libs"]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True)
        auto_libs = json.loads(res.stdout)
    except (subprocess.CalledProcessError, json.JSONDecodeError):
        pass

    # Step 2: Load manual overrides from libraries.json (project.yml cache)
    manual_libs = {}
    lib_cache = Path(".routertl_cache/libraries.json")
    if lib_cache.exists():
        try:
            with open(lib_cache, "r") as f:
                manual_libs = json.load(f)
        except Exception:
            import logging

            logging.debug("Failed to load libraries.json cache", exc_info=True)

    # Step 3: Merge — auto as base, manual extends/overrides
    lib_sources = {}  # {lib: {"auto": set, "manual": set}}
    for lib_name, files in auto_libs.items():
        lib_sources[lib_name] = {"auto": set(files), "manual": set()}

    for lib_name, files in manual_libs.items():
        if lib_name not in lib_sources:
            lib_sources[lib_name] = {"auto": set(), "manual": set()}
        abs_manual = {str(Path(f).resolve()) for f in files}
        lib_sources[lib_name]["manual"] = abs_manual

    # Build final custom_libs with deduplicated union
    for lib_name, sources in lib_sources.items():
        merged = list(sources["auto"] | sources["manual"])
        if merged:
            custom_libs[lib_name] = merged

    for lib_files in custom_libs.values():
        for lf in lib_files:
            custom_lib_files.add(str(Path(lf).resolve()))

    return custom_libs, custom_lib_files, lib_sources


def _check_workdir_health(root_dir, custom_libs, vhdl_pkgs, args, log_handle):
    """Detect stale/missing GHDL work directories and force rebuild.

    After clean, SDK update, or first clone the sim/work/ tree may be
    absent or lack compiled .cf catalog files.
    """
    workdir = Path(root_dir) / "sim" / "work"
    workdir_healthy = (
        workdir.is_dir()
        and (workdir / "work").is_dir()
        and any((workdir / "work").glob("*.cf"))
    )

    if custom_libs and not workdir_healthy:
        _con.print("[yellow]🔧 Stale/missing work directory detected — auto-rebuilding...[/]")
        log_handle.write("=== Workdir Health Check: rebuilding ===\n")
        log_handle.flush()

        # Clean stale custom library dirs to prevent artifact contamination
        for lib_name in custom_libs:
            stale_lib = workdir / lib_name
            if stale_lib.is_dir():
                shutil.rmtree(stale_lib)

        # Force Phase 1 PRECOMPILE even if has_vhdl_libs was False
        vhdl_pkgs_str = " ".join(vhdl_pkgs) if vhdl_pkgs else ""
        ret, warn = run_lint(
            root_dir, "PRECOMPILE", "",
            vhdl_pkgs_str, args.xpm, args.utils, log_handle,
        )
        if ret != 0:
            _con.print("[red]FAIL[/]")
            _con.print(f"[red]❌ Workdir rebuild failed. Check {LOG_FILE}[/]")
            exit_with_status(root_dir, 1)
        _con.print("[green]✅ Work directory rebuilt.[/]")


def _lint_hierarchy(top, vhdl_files, sv_files, root_dir, extra_lib_paths,
                    log_handle, has_verilator, compiled_set):
    """Run GHDL + Verilator lint on a single hierarchy.

    Returns
    -------
    tuple[dict, int]
        ``(result_entry, failure_count_delta)``.
    """
    failure_delta = 0

    if vhdl_files:
        new_files_str = " ".join(vhdl_files)
        log_handle.write(f"\n=== Linting Hierarchy: {top} ===\n")
        log_handle.flush()

        ret, warn = run_lint(root_dir, "LINT", new_files_str, "", "", "", log_handle, extra_lib_paths)
        if ret != 0:
            failure_delta = 1
            entry = {"top": top, "status": "FAIL", "details": "Check Log"}
            _con.print("[red]FAIL[/]")
        elif warn:
            entry = {"top": top, "status": "WARN", "details": f"{len(vhdl_files)} files"}
            _con.print("[yellow]WARN[/]")
            compiled_set.update(vhdl_files)
        else:
            entry = {"top": top, "status": "PASS", "details": f"{len(vhdl_files)} files"}
            _con.print("[green]PASS[/]")
            compiled_set.update(vhdl_files)
    else:
        entry = {"top": top, "status": "PASS", "details": "Cached"}
        _con.print("[green]PASS (Cached)[/]")

    # Phase 2b: Verilator lint for SV files
    if sv_files and has_verilator:
        inc_dirs = sorted({str(Path(f).parent) for f in sv_files})
        _con.print(
            f"[cyan]⚡ Verilator Lint: {top} (SV) ({len(sv_files)} files)[/] ... ",
            end="",
        )
        log_handle.write(f"\n=== Verilator Lint: {top} (SV) ===\n")
        log_handle.flush()
        vret, vwarn = run_verilator_lint(sv_files, inc_dirs, log_handle)
        if vret != 0:
            failure_delta += 1
            _merge_sv_into(entry, "FAIL", f"{len(sv_files)} files")
            _con.print("[red]FAIL[/]")
        elif vwarn:
            _merge_sv_into(entry, "WARN", f"{len(sv_files)} files")
            _con.print("[yellow]WARN[/]")
        else:
            _merge_sv_into(entry, "PASS", f"{len(sv_files)} files")
            _con.print("[green]PASS[/]")
    elif sv_files and not has_verilator:
        _merge_sv_into(entry, "SKIP", "No Verilator")

    return entry, failure_delta


def _compile_custom_libraries(custom_libs, lib_sources, root_dir, src_args,
                               resolver_script, log_handle, vhdl_pkgs=None):
    """Compile each custom library into its own NVC work directory.

    Topologically sorts each library's files via the dependency resolver,
    then invokes ``linting.sh`` in ``COMPILE_LIB`` mode.  Fatal compile
    errors exit the process immediately.

    Parameters
    ----------
    custom_libs : dict[str, list[str]]
        ``{library_name: [source_file, ...]}``.
    lib_sources : dict[str, dict]
        Per-library ``{"auto": set, "manual": set}`` breakdown for UX tags.
    root_dir : str
        Project root directory.
    src_args : list[str]
        ``["--src", dir, ...]`` arguments for the dependency resolver.
    resolver_script : Path
        Absolute path to ``dependency_resolver.py``.
    log_handle : file
        Open log file handle.

    Returns
    -------
    tuple[list[str], set[str]]
        ``(extra_lib_paths, newly_compiled_files)``.
    """
    extra_lib_paths = []
    newly_compiled = set()

    if not custom_libs:
        return extra_lib_paths, newly_compiled

    _con.print("[cyan]📚 Compiling Custom Libraries...[/]")
    log_handle.write("=== Compiling Custom Libraries ===\n")

    for lib_name, lib_files in custom_libs.items():
        if not lib_files:
            continue

        # Pre-compile project packages into the custom library.
        # Projects like deepskopion use `library tich; use tich.pkg.all;`
        # in their package files, so packages must exist in the custom
        # library BEFORE compiling the library's own source files.
        if vhdl_pkgs:
            pkgs_str = " ".join(vhdl_pkgs)
            log_handle.write(f"--- Pre-compiling {len(vhdl_pkgs)} packages into {lib_name} ---\n")
            log_handle.flush()
            ret, _ = run_lint(root_dir, "COMPILE_LIB", lib_name, pkgs_str, "", "", log_handle)
            if ret != 0:
                # Non-fatal: some packages may not reference this library
                log_handle.write(f"--- Package pre-compile into {lib_name}: partial (some may not reference this lib) ---\n")
                log_handle.flush()

        lib_abs = [str(Path(f).resolve()) for f in lib_files]
        lib_abs_set = set(lib_abs)

        ordered = []
        ordered_set = set()

        for lf in lib_abs:
            if lf in ordered_set:
                continue
            entity_name = Path(lf).stem
            try:
                cmd = (
                    ["python3", str(resolver_script)]
                    + src_args
                    + ["--top", entity_name, "--list"]
                )
                res = subprocess.run(
                    cmd, capture_output=True, text=True, check=True
                )
                deps = res.stdout.strip().split()
                for dep in deps:
                    if dep in lib_abs_set and dep not in ordered_set:
                        ordered.append(dep)
                        ordered_set.add(dep)
            except subprocess.CalledProcessError:
                if lf not in ordered_set:
                    ordered.append(lf)
                    ordered_set.add(lf)

        for lf in lib_abs:
            if lf not in ordered_set:
                ordered.append(lf)
                ordered_set.add(lf)

        lib_files_sorted = ordered

        # UX: show auto/manual breakdown
        src_info = lib_sources.get(lib_name, {"auto": set(), "manual": set()})
        n_auto = len(src_info["auto"] & set(lib_files_sorted))
        n_manual = len(src_info["manual"] & set(lib_files_sorted))
        if n_auto and n_manual:
            tag = f"{n_auto} auto + {n_manual} manual"
        elif n_manual:
            tag = f"{n_manual} manual"
        else:
            tag = f"{len(lib_files_sorted)} auto-discovered"
        _con.print(f"  - [cyan]{lib_name}[/] ({tag}) ... ", end="")
        lib_files_str = " ".join(lib_files_sorted)

        ret, warn = run_lint(root_dir, "COMPILE_LIB", lib_name, lib_files_str, "", "", log_handle)

        if ret != 0:
            _con.print("[red]FAIL[/]")
            _con.print(f"[red]❌ Compilation of library '{lib_name}' failed. Check {LOG_FILE}[/]")
            exit_with_status(root_dir, 1)

        if warn:
            _con.print("[yellow]PASS (Warnings)[/]")
        else:
            _con.print("[green]PASS[/]")

        extra_lib_paths.append(f"-Psim/work/{lib_name}")

        for f in lib_files:
            newly_compiled.add(f)

    return extra_lib_paths, newly_compiled


def main():

    """CLI entry point for the smart linter.

    Orchestrates the three-phase linting pipeline:
    PRECOMPILE → COMPILE_LIB → LINT.  See module docstring for overview.
    """
    parser = argparse.ArgumentParser(description="Smart HDL Linter")
    parser.add_argument("--top", help="Specific top entity to lint")
    parser.add_argument("--src", action="append", nargs="+", help="Source directories")
    # Environment configs usually passed from Make
    parser.add_argument("--root", required=True, help="Project Root Directory")
    parser.add_argument("--pkgs", default="", help="Package files (from Make)")
    parser.add_argument("--xpm", default="", help="XPM files (from Make)")
    parser.add_argument("--utils", default="", help="Utils files (from Make)")
    parser.add_argument("--exclude", default="", help="Space-separated list of files to exclude from linting")

    args = parser.parse_args()

    # Build exclusion set (normalize paths)
    exclude_set = set()
    if args.exclude:
        for excl in args.exclude.split():
            exclude_set.add(excl.strip())

    # Ensure sim directory exists for log file
    os.makedirs(LOG_FILE.parent, exist_ok=True)

    # Open log file in write mode (clears previous content)
    with open(LOG_FILE, "w") as log_handle:
        # -----------------------------------------------------------------
        # PHASE 1: Pre-Compile Global Libraries
        # -----------------------------------------------------------------
        resolver_script = SDK_DIR / "engine" / "dependency_resolver.py"
        src_args = []
        if args.src:
            flat_srcs = [item for sublist in args.src for item in sublist]
            for s in flat_srcs:
                src_args.extend(["--src", s])
        else:
            src_args = ["--src", "src"]  # Default

        try:
            cmd = ["python3", str(resolver_script)] + src_args + ["--sort-pkgs"]
            res = subprocess.run(cmd, capture_output=True, text=True, check=True)
            sorted_pkgs = res.stdout.strip()
        except subprocess.CalledProcessError:
            sorted_pkgs = ""

        custom_libs, custom_lib_files, lib_sources = _resolve_libraries(src_args, resolver_script)

        # Filter out non-VHDL files and custom library files from packages
        vhdl_pkgs = [
            p for p in sorted_pkgs.split()
            if p.endswith((".vhd", ".vhdl")) and p not in custom_lib_files
        ]
        has_vhdl_libs = bool(vhdl_pkgs or args.xpm.strip() or args.utils.strip())

        if has_vhdl_libs:
            _con.print("[cyan]🔨 Pre-Compiling Libraries (XPM, Utils, Packages)...[/] ", end="")
            log_handle.write("=== Pre-Compiling Libraries ===\n")
            log_handle.flush()

            vhdl_pkgs_str = " ".join(vhdl_pkgs)
            ret, warn = run_lint(args.root, "PRECOMPILE", "", vhdl_pkgs_str, args.xpm, args.utils, log_handle)

            if ret != 0:
                # ── P2.125: Best-effort fallback ─────────────────
                # Batch pre-compilation failed (likely a missing external
                # package like `en_cl_fix_pkg`).  Fall back to per-package
                # compilation so that valid packages still get compiled
                # and their dependents can still be linted.
                _con.print("[yellow]PARTIAL[/]")
                _con.print(
                    "[yellow]⚠️  Batch pre-compilation failed — "
                    "retrying packages individually...[/]"
                )
                log_handle.write("=== Pre-Compile Fallback: per-package mode ===\n")
                log_handle.flush()

                # XPM and utils are always compiled first (they rarely fail)
                if args.xpm.strip() or args.utils.strip():
                    run_lint(args.root, "PRECOMPILE", "", "", args.xpm, args.utils, log_handle)

                failed_pkgs = []
                for pkg in vhdl_pkgs:
                    r, _ = run_lint(args.root, "PRECOMPILE", "", pkg, "", "", log_handle)
                    if r != 0:
                        failed_pkgs.append(Path(pkg).name)
                        log_handle.write(f"--- SKIP (unresolvable): {pkg} ---\n")
                        log_handle.flush()

                if failed_pkgs:
                    _con.print(
                        f"[yellow]⚠️  {len(failed_pkgs)} package(s) skipped "
                        f"(missing external deps): {', '.join(failed_pkgs)}[/]"
                    )
                    _con.print(
                        "[dim]   Hierarchies using these packages may still fail.[/]"
                    )
                else:
                    _con.print("[green]✅ All packages compiled individually.[/]")
            elif warn:
                _con.print("[yellow]PASS (Warnings)[/]")
            else:
                _con.print("[green]PASS[/]")
        else:
            _con.print("[cyan]⏩ No VHDL libraries found — skipping pre-compilation.[/]")

        compiled_set = set(vhdl_pkgs)

        # -----------------------------------------------------------------
        # WORKDIR HEALTH CHECK
        # -----------------------------------------------------------------
        _check_workdir_health(args.root, custom_libs, vhdl_pkgs, args, log_handle)

        # -----------------------------------------------------------------
        # PHASE 1.5: Custom Libraries
        # -----------------------------------------------------------------
        extra_lib_paths_list, newly_compiled = _compile_custom_libraries(
            custom_libs, lib_sources, args.root, src_args,
            resolver_script, log_handle, vhdl_pkgs=vhdl_pkgs,
        )
        compiled_set.update(newly_compiled)
        extra_lib_paths = " ".join(extra_lib_paths_list)

        # Detect precompiled GHDL vendor libraries
        try:
            ghdl_cfg = subprocess.run(
                ["ghdl", "--disp-config"], capture_output=True, text=True, check=True,
            )
            for line in ghdl_cfg.stdout.splitlines():
                if "library prefix:" in line:
                    ghdl_prefix = Path(line.split(":", 1)[1].strip())
                    xilinx_vendor = ghdl_prefix / "xilinx-vivado"
                    if xilinx_vendor.is_dir():
                        extra_lib_paths += f" -P{xilinx_vendor}"
                    break
        except (FileNotFoundError, subprocess.CalledProcessError):
            pass

        # -----------------------------------------------------------------
        # PHASE 2: Linting Hierarchies
        # -----------------------------------------------------------------
        has_verilator = _has_verilator()
        if not has_verilator:
            _con.print("[yellow]⚠️  Verilator not found — SV/V files will be skipped.[/]")

        _con.print("[cyan]🔍 RouteRTL Smart Linter (Incremental Mode)[/]")
        _con.print("=============================")

        if args.top:
            _con.print(f"Targeting Top: [green]{args.top}[/]")
            cmd = ["python3", str(resolver_script)] + src_args + ["--top", args.top, "--list"]

            results = []
            try:
                res = subprocess.run(cmd, capture_output=True, text=True, check=True)
                files_str = res.stdout.strip()
                if not files_str:
                    _con.print(f"[red]❌ No dependencies found for {args.top}[/]")
                    exit_with_status(args.root, 1)

                files_list = files_str.split()
                new_files, sv_files, skipped_files = _partition_files(
                    files_list, compiled_set, exclude_set, args.root,
                )

                for sf in skipped_files:
                    _con.print(f"[yellow]⏭️  Skipped (excluded): {Path(sf).name}[/]")

                _con.print("[cyan]📂 Unit Files:[/]")
                for f in files_list:
                    _con.print(f"  - {Path(f).name}")

                if new_files or not skipped_files:
                    entry, fdelta = _lint_hierarchy(
                        args.top, new_files, sv_files, args.root,
                        extra_lib_paths, log_handle, has_verilator, compiled_set,
                    )
                    results.append(entry)
                    final_ret = fdelta
                else:
                    _con.print("\n[yellow]⏭️  Top entity excluded — not validated.[/]")
                    results.append({"top": args.top, "status": "SKIP", "details": "Excluded"})
                    final_ret = 0

                _persist_lint_results(results, args.root)
                print_summary_table(results)
                exit_with_status(args.root, final_ret)

            except subprocess.CalledProcessError as e:
                _con.print("[red]❌ Error resolving dependencies:[/]")
                _con.print(e.stderr)
                exit_with_status(args.root, 1)

        else:
            # Auto Mode: Forest
            _con.print("Auto-Detecting Hierarchies...")
            cmd = ["python3", str(resolver_script)] + src_args + ["--forest"]
            try:
                res = subprocess.run(cmd, capture_output=True, text=True, check=True)
                forest = json.loads(res.stdout)
            except subprocess.CalledProcessError as e:
                _con.print("[red]❌ Error analyzing project forest:[/]")
                _con.print(e.stderr)
                exit_with_status(args.root, 1)
            except json.JSONDecodeError:
                _con.print("[red]❌ Error parsing resolver output.[/]")
                _con.print(res.stdout)
                exit_with_status(args.root, 1)

            trees = forest.get("trees", [])
            orphans = forest.get("orphans", [])

            _con.print(f"Detected {len(trees)} Top-Level Hierarchies.")

            failure_count = 0
            results = []

            for tree in trees:
                top = tree["top"]
                path_abs = tree.get("path", "Unknown")
                try:
                    path = str(Path(path_abs).relative_to(args.root))
                except ValueError:
                    path = path_abs

                if path in exclude_set or top in exclude_set:
                    _con.print(f"[yellow]⏭️  Skipping Hierarchy (excluded): {top} ({Path(path).name})[/]")
                    results.append({"top": top, "status": "SKIP", "details": "Excluded"})
                    continue

                count = tree["weight"]
                files_list = tree["files"]

                new_files, sv_files, skipped_files = _partition_files(
                    files_list, compiled_set, exclude_set, args.root,
                )

                if skipped_files:
                    for sf in skipped_files:
                        _con.print(f"\n[yellow]⏭️  Skipped (excluded): {Path(sf).name}[/]")

                _con.print(
                    f"[cyan]📐 Linting Hierarchy: {top} ({path}) ({len(new_files)} new / {count} total)[/] ... ",
                    end="",
                )

                entry, fdelta = _lint_hierarchy(
                    top, new_files, sv_files, args.root,
                    extra_lib_paths, log_handle, has_verilator, compiled_set,
                )
                results.append(entry)
                failure_count += fdelta

            if orphans:
                _con.print(f"[yellow]⚠️  Linting Orphans ({len(orphans)} files)[/] ... ", end="")

                new_orphans, sv_orphans, _ = _partition_files(
                    orphans, compiled_set, exclude_set, args.root,
                )

                entry, fdelta = _lint_hierarchy(
                    "Orphan Files", new_orphans, sv_orphans, args.root,
                    extra_lib_paths, log_handle, has_verilator, compiled_set,
                )
                results.append(entry)
                failure_count += fdelta

                for f in orphans:
                    _con.print(f"      * {Path(f).name}")

            _persist_lint_results(results, args.root)
            print_summary_table(results)

            if failure_count > 0:
                _con.print(f"\n[red]❌ Linting failed in {failure_count} groups.[/]")
                exit_with_status(args.root, 1)
            else:
                _con.print("\n[green]✅ All hierarchies passed linting.[/]")
                exit_with_status(args.root, 0)


if __name__ == "__main__":
    main()
