# SPDX-FileCopyrightText: 2024-2026 Daniel J. Mazure
# SPDX-License-Identifier: LicenseRef-RouteRTL-Proprietary

import argparse
import json
import logging
import os
import re
import sys
from pathlib import Path

import yaml

from routertl_core.dependency_resolver import DependencyResolver
from sdk.engine.git_utils import filter_git_tracked
from sdk.engine.ip_resolver import IpResolver
from sdk.engine.manage_dependencies import ensure_dependencies, get_dependency_files

# Path to sdk/engine/ for data files (supported_vendors.yml)
_ENGINE_DIR = str(Path(__file__).resolve().parents[1] / "sdk" / "engine")


def is_vhdl_package(filepath):
    """Detect if a VHDL file contains a package declaration by parsing its content."""
    if not filepath.endswith((".vhd", ".vhdl")):
        return False
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
        # Match "package <name> is" but NOT "package body <name> is"
        return bool(re.search(r"^\s*package\s+(?!body\b)\w+\s+is", content, re.IGNORECASE | re.MULTILINE))
    except (OSError, UnicodeDecodeError):
        return False


CACHE_FILE = ".routertl_cache/dependencies.json"


def load_cache():
    """Load the project build cache from disk."""
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r") as f:
                return json.load(f)
        except json.JSONDecodeError:
            pass
    return {}


def save_cache(cache_data):
    """Save the project build cache to disk."""
    os.makedirs(os.path.dirname(CACHE_FILE), exist_ok=True)
    with open(CACHE_FILE, "w") as f:
        json.dump(cache_data, f, indent=4)


def resolve_auto_sources(config, project_root):
    """Resolves sources automatically if 'auto_sources' is enabled."""
    if not config.get("auto_sources", False):
        return config

    project = config.get("project", {})
    top_module = project.get("top_module")
    if not top_module:
        logging.warning("Auto-sources enabled but no top_module defined.")
        return config

    # Cache check (simplified timestamp check could be added here)
    cache = load_cache()
    if top_module in cache:
        logging.info(f"Using cached dependencies for {top_module}")
        resolved_files = cache[top_module]
    else:
        logging.info(f"Resolving dependencies for {top_module}...")
        # Read source directories from paths.sources (string or list),
        # falling back to "src" for backward compatibility.
        raw_sources = config.get("paths", {}).get("sources", "src")
        if isinstance(raw_sources, str):
            raw_sources = [raw_sources]
        src_dirs = [Path(project_root) / s for s in raw_sources]
        resolver = DependencyResolver(src_dirs, verbose=False)
        resolved_paths = resolver.get_compilation_order(top_module)
        resolved_files = [str(p.relative_to(project_root)) for p in resolved_paths]

        # Update cache
        cache[top_module] = resolved_files
        save_cache(cache)

    # Merge into config sources
    if "sources" not in config:
        config["sources"] = {}

    # We implicitly assign resolved files to 'syn' and 'sim' for now
    # A more sophisticated logic could split them based on file location

    # Ensure lists exist
    if "syn" not in config["sources"]:
        config["sources"]["syn"] = []

    # Append unique files
    current_syn = set(config["sources"]["syn"])
    for f in resolved_files:
        if f not in current_syn:
            config["sources"]["syn"].append(f)

    return config


def merge_dicts(base, update):
    """Recursively merges two dictionaries."""
    for key, value in update.items():
        if isinstance(value, dict) and key in base and isinstance(base[key], dict):
            merge_dicts(base[key], value)
        elif isinstance(value, list) and key in base and isinstance(base[key], list):
            # For lists, we append to allow cumulative source lists
            # but we want to avoid duplicates
            for item in value:
                if item not in base[key]:
                    base[key].append(item)
        else:
            base[key] = value


def load_config(yaml_path, _visited=None, _depth=0, _max_depth=10):
    """Loads a YAML config file and handles includes recursively.

    Parameters
    ----------
    _visited : set, optional
        Internal — tracks already-visited paths for cycle detection.
    _depth : int
        Internal — current recursion depth.
    _max_depth : int
        Maximum include nesting depth (default 10).
    """
    if _visited is None:
        _visited = set()

    abs_path = os.path.abspath(yaml_path)

    if abs_path in _visited:
        print(f"Warning: circular include detected — skipping {yaml_path}")
        return {}

    if _depth > _max_depth:
        print(f"Warning: include depth exceeded {_max_depth} — skipping {yaml_path}")
        return {}

    if not os.path.exists(yaml_path):
        print(f"Warning: {yaml_path} not found")
        return {}

    _visited.add(abs_path)

    with open(yaml_path, "r") as f:
        try:
            config = yaml.safe_load(f) or {}
        except yaml.YAMLError as e:
            print(f"Error parsing YAML file {yaml_path}:\n{e}")
            return {}

    if not isinstance(config, dict):
        print(f"Warning: {yaml_path} is not a valid YAML dictionary. Ignoring.")
        return {}

    base_dir = os.path.dirname(os.path.abspath(yaml_path))

    combined_config = {}
    if "includes" in config:
        for inc in config["includes"]:
            # Handle both absolute and relative paths
            if os.path.isabs(inc):
                inc_path = inc
            else:
                inc_path = os.path.join(base_dir, inc)
            inc_config = load_config(inc_path, _visited, _depth + 1, _max_depth)
            merge_dicts(combined_config, inc_config)

    merge_dicts(combined_config, config)
    return combined_config


def generate_mk_file(config, output_path):
    """Generates a Makefile include file from the project config."""
    lines = ["# Generated by project_manager.py"]

    project = config.get("project", {})
    lines.append(f"PROJECT_NAME ?= {project.get('name', 'system_top')}")

    hardware = config.get("hardware", {})
    lines.append(f"VENDOR       ?= {hardware.get('vendor', 'xilinx')}")
    lines.append(f"FPGA_PART    ?= {hardware.get('part', '')}")
    lines.append(f"PLATFORM     ?= {hardware.get('platform', 'default')}")
    lines.append(f"HDL_LANGUAGE ?= {hardware.get('language', 'vhdl')}")

    build = config.get("build_options", {})
    if "tool_version" in build:
        v = build["tool_version"]
        lines.append(f"VIVADO_VER   ?= {v}")
        lines.append(f"RADIANT_VER  ?= {v}")
        lines.append(f"QUARTUS_VER  ?= {v}")

    # Specific tool overrides
    if "vivado_version" in build:
        lines.append(f"VIVADO_VER   := {build['vivado_version']}")
    if "radiant_version" in build:
        lines.append(f"RADIANT_VER  := {build['radiant_version']}")
    if "quartus_version" in build:
        lines.append(f"QUARTUS_VER  := {build['quartus_version']}")

    if "quick_impl" in build:
        lines.append(f"QUICK_IMPL   ?= {str(build['quick_impl']).lower()}")

    system_config = config.get("system_config")
    if system_config:
        lines.append(f"CONFIG_YAML  ?= $(ROOT_DIR)/{system_config}")

    # Features Configuration
    features = config.get("features", {})
    # Regbank enabled by default if not specified/disabled explicitly
    regbank_enabled = str(features.get("regbank", "true")).lower()
    lines.append(f"CONFIG_ENABLE_REGBANK ?= {regbank_enabled}")

    # Embedded Linux Configuration
    linux_cfg = config.get("linux", {})
    if linux_cfg:
        lines.append("\n# Embedded Linux Configuration")
        if "board" in linux_cfg:
            lines.append(f"LINUX_BOARD  ?= {linux_cfg['board']}")
            lines.append("BOARD        ?= $(LINUX_BOARD)")
        if "device_tree" in linux_cfg:
            lines.append(f"DEVICE_TREE  ?= {linux_cfg['device_tree']}")
        if "uboot_repo" in linux_cfg:
            lines.append(f"UBOOT_REPO   ?= {linux_cfg['uboot_repo']}")
        if "kernel_repo" in linux_cfg:
            lines.append(f"KERNEL_REPO  ?= {linux_cfg['kernel_repo']}")
        if "fsbl_repo" in linux_cfg:
            lines.append(f"FSBL_REPO    ?= {linux_cfg['fsbl_repo']}")
        if "dtg_repo" in linux_cfg:
            lines.append(f"DTG_REPO     ?= {linux_cfg['dtg_repo']}")
        if "boot_script" in linux_cfg:
            lines.append(f"BOOT_SCRIPT  ?= {linux_cfg['boot_script']}")
        if "kernel_config" in linux_cfg:
            lines.append(f"KERNEL_CONFIG_FRAGMENTS ?= $(ROOT_DIR)/{linux_cfg['kernel_config']}")
        if "kernel_patch" in linux_cfg:
            lines.append(f"KERNEL_PATCH_SCRIPT ?= $(ROOT_DIR)/{linux_cfg['kernel_patch']}")

        sw_repos = linux_cfg.get("sw_repos", [])
        if isinstance(sw_repos, list) and sw_repos:
            repos_str = " ".join(sw_repos)
            lines.append(f"SW_REPOS     ?= {repos_str}")

    simulation = config.get("simulation", {})
    if simulation:
        sim_dir = simulation.get("test_dir", "sim/cocotb/tests")
        lines.append(f"SIM_DIR      := $(ROOT_DIR)/{sim_dir}")

    # Paths configuration (for configurable directory structure)
    paths = config.get("paths", {})
    src_dir = paths.get("sources", "src")
    sim_path = paths.get("simulation", "sim")
    xdc_dir = paths.get("constraints", "xdc")
    verification_dir = paths.get("verification", "verif")

    lines.append("\n# Configurable paths")

    def process_path(val):
        """Resolve and process a single source path entry."""
        if isinstance(val, list):
            return " ".join(val)
        return val

    lines.append(f"SRC_DIR      ?= {process_path(src_dir)}")
    lines.append(f"SIM_PATH     ?= {process_path(sim_path)}")
    lines.append(f"XDC_DIR      ?= {process_path(xdc_dir)}")
    lines.append(f"VERIFICATION_DIR ?= {process_path(verification_dir)}")

    # Simulation Output Paths
    sim_waves_dir = simulation.get("waves_dir", "sim/cocotb/waves")
    sim_logs_dir = simulation.get("logs_dir", "sim/cocotb/logs")
    lines.append(f"SIM_WAVES_DIR ?= $(ROOT_DIR)/{sim_waves_dir}")
    lines.append(f"SIM_LOGS_DIR  ?= $(ROOT_DIR)/{sim_logs_dir}")

    # Simulator Backend (Default: nvc)
    sim_backend = simulation.get("simulator", "nvc")
    lines.append(f"SIM_BACKEND   ?= {sim_backend}")

    # Hook Configuration (exported to Make for regression/linting targets)
    hooks = config.get("hooks", {})
    if hooks:
        pre_commit = hooks.get("pre_commit", {})
        if pre_commit:
            exclude = pre_commit.get("exclude", {})
            exclude_tests = exclude.get("tests", [])
            if isinstance(exclude_tests, list) and exclude_tests:
                lines.append(f"HOOK_EXCLUDE_TESTS := {' '.join(exclude_tests)}")

            exclude_lint = exclude.get("lint", [])
            if isinstance(exclude_lint, list) and exclude_lint:
                lines.append(f"HOOK_EXCLUDE_LINT := {' '.join(exclude_lint)}")

    # Sources section
    sources = config.get("sources", {})

    # 1. Standard sources from YAML
    if sources:
        lines.append("\n# Sources defined in YAML")
        mapping = {
            "syn": "SYN_FILES",
            "sim": "SIM_FILES",
            "xdc": "XDC_FILES",
            "sdc": "SDC_FILES",
            "ip": "IP_FILES",
            "tcl": "TCL_FILES",
        }
        for yaml_key, mk_var in mapping.items():
            if yaml_key in sources:
                files = sources[yaml_key]
                if isinstance(files, list):
                    # If we have existing files, we might be appending later?
                    # Standard behavior is just assignment
                    lines.append(f"{mk_var} := {' '.join(files)}")
                else:
                    lines.append(f"{mk_var} := {files}")

        # Auto-detect VHDL packages from syn files and output as PKG_FILES
        # Packages are detected by parsing the file content for "package <name> is" declarations
        if "syn" in sources and isinstance(sources["syn"], list):
            pkg_files = []
            for f in sources["syn"]:
                # Use content-based detection - checks for "package <name> is" in the file
                if is_vhdl_package(f):
                    pkg_files.append(f)
            if pkg_files:
                lines.append(f"PKG_FILES := {' '.join(pkg_files)}")

    # 4. Dependencies (External Libraries)
    # We fetch the list of files for each library defined in dependencies
    # and map them to standard variables if possible.
    # Currently we support mapping 'xpm' library -> XPM_FILES

    # Project root defaults to CWD (Makefile always runs from project root)
    proj_root = os.getcwd()

    dep_files_map = get_dependency_files(config, proj_root)

    if "xpm" in dep_files_map and dep_files_map["xpm"]:
        xpm_files = " ".join(dep_files_map["xpm"])
        # If XPM_FILES was already defined (unlikely by standard yaml), we append or set
        # But 'xpm' key in sources is not standard.
        lines.append(f"XPM_FILES := {xpm_files}")

    # We could extend this to other libraries by appending to EXTRA_LIBS or similar in future

    if sources:  # Resume standard blocks
        if "ip" in sources:
            lines.append("XCI_FILES := $(IP_FILES)")

    # ── IP Manifest Resolution (sources.ips) ──
    ip_paths = sources.get("ips", []) if sources else []
    if ip_paths:
        hardware = config.get("hardware", {})
        vendor = hardware.get("vendor", "xilinx")
        resolver = IpResolver(Path(proj_root), vendor)
        ip_result = resolver.resolve(ip_paths)

        if ip_result.errors:
            for err in ip_result.errors:
                print(f"ERROR: {err}")
            sys.exit(1)

        lines.append("\n# IP Manifest Sources")
        if ip_result.syn_files:
            existing = sources.get("syn", []) if sources else []
            combined = existing + ip_result.syn_files
            lines.append(f"SYN_FILES := {' '.join(combined)}")
        if ip_result.xci_files:
            lines.append(f"IP_IP_FILES := {' '.join(ip_result.xci_files)}")
            # Append to existing XCI_FILES if any
            lines.append("XCI_FILES += $(IP_IP_FILES)")
        if ip_result.netlist_files:
            lines.append(f"NETLIST_FILES := {' '.join(ip_result.netlist_files)}")
        if ip_result.ooc_dcp_files:
            lines.append(f"OOC_DCP_FILES := {' '.join(ip_result.ooc_dcp_files)}")

        # Merge IP library mappings into the library cache
        if ip_result.libraries:
            lib_cache = os.path.join(".routertl_cache", "libraries.json")
            existing_libs = {}
            if os.path.exists(lib_cache):
                try:
                    with open(lib_cache, "r") as f:
                        existing_libs = json.load(f)
                except (OSError, json.JSONDecodeError):
                    logging.debug("Library cache read failed for %s", lib_cache, exc_info=True)
            for lib, files in ip_result.libraries.items():
                if lib in existing_libs:
                    for fp in files:
                        if fp not in existing_libs[lib]:
                            existing_libs[lib].append(fp)
                else:
                    existing_libs[lib] = files
            os.makedirs(os.path.dirname(lib_cache), exist_ok=True)
            with open(lib_cache, "w") as f:
                json.dump(existing_libs, f, indent=4)

    # ── Explicit sources.libraries → libraries.json cache ─────────
    # When users define manual library mappings in project.yml, serialize
    # them into the cache so smart_linter.py can consume them.
    manual_libs = sources.get("libraries", {}) if sources else {}
    if isinstance(manual_libs, dict) and manual_libs:
        lib_cache = os.path.join(".routertl_cache", "libraries.json")
        existing_libs = {}
        if os.path.exists(lib_cache):
            try:
                with open(lib_cache, "r") as f:
                    existing_libs = json.load(f)
            except (OSError, json.JSONDecodeError):
                logging.debug("Library cache read failed for %s", lib_cache, exc_info=True)
        for lib, files in manual_libs.items():
            if not isinstance(files, list):
                files = [files]
            if lib in existing_libs:
                for fp in files:
                    if fp not in existing_libs[lib]:
                        existing_libs[lib].append(fp)
            else:
                existing_libs[lib] = list(files)
        os.makedirs(os.path.dirname(lib_cache), exist_ok=True)
        with open(lib_cache, "w") as f:
            json.dump(existing_libs, f, indent=4)

    # Vendor Toolchain and TCL Paths from Database
    vendor_db_path = os.path.join(_ENGINE_DIR, "supported_vendors.yml")
    if os.path.exists(vendor_db_path):
        with open(vendor_db_path, "r") as f:
            vdb = yaml.safe_load(f)
            v_data = vdb.get(hardware.get("vendor", "xilinx"), vdb.get("xilinx", {}))

            tool_cmd = v_data.get("tool_cmd", "vivado")
            tool_flags = v_data.get("tool_flags", "")

            # P3.25: hardware.tool override — select a specific tool variant
            hw_tool = hardware.get("tool", "")
            if hw_tool:
                tools_map = v_data.get("tools", {})
                tool_entry = tools_map.get(hw_tool)
                if tool_entry:
                    tool_cmd = tool_entry.get("tool_cmd", tool_cmd)
                    tool_flags = tool_entry.get("tool_flags", tool_flags)
                else:
                    avail = ", ".join(tools_map.keys()) if tools_map else "(none)"
                    print(
                        f"⚠️  hardware.tool '{hw_tool}' not found in vendor "
                        f"'{hardware.get('vendor', 'xilinx')}' tools map. "
                        f"Available: {avail}. Using default: {tool_cmd}"
                    )

            full_cmd = f"{tool_cmd} {tool_flags}".strip()
            lines.append("\n# Vendor Toolchain Mapping")
            lines.append(f"TOOL_CMD = {full_cmd}")

            tcl_paths = v_data.get("tcl", {})
            if "project" in tcl_paths:
                lines.append(f"GEN_PROJECT_TCL = $(SDK_ROOT)/{tcl_paths['project']}")
            if "synthesis" in tcl_paths:
                lines.append(f"SYNTH_TCL = $(SDK_ROOT)/{tcl_paths['synthesis']}")
            if "implementation" in tcl_paths:
                lines.append(f"IMPL_TCL = $(SDK_ROOT)/{tcl_paths['implementation']}")
            if "bitstream" in tcl_paths:
                lines.append(f"BITSTREAM_TCL = $(SDK_ROOT)/{tcl_paths['bitstream']}")

            linux_paths = v_data.get("linux", {})
            if linux_paths:
                lines.append("\n# Vendor Linux Abstractions")
                if "hw_handoff_ext" in linux_paths:
                    lines.append(f"HW_HANDOFF_EXT = {linux_paths['hw_handoff_ext']}")
                if "hw_crosscheck" in linux_paths:
                    lines.append(f"HW_CROSSCHECK_SCRIPT = {linux_paths['hw_crosscheck']}")
                if "fsbl_cmd" in linux_paths:
                    lines.append(f"FSBL_COMMAND = {linux_paths['fsbl_cmd']}")

    # Arbitrary Makefile overrides
    mk_overrides = config.get("makefile_overrides", {})
    if mk_overrides:
        lines.append("\n# Arbitrary Makefile overrides")
        for key, value in mk_overrides.items():
            if isinstance(value, bool):
                val_str = str(value).lower()
            else:
                val_str = str(value)
            lines.append(f"{key} := {val_str}")

    with open(output_path, "w") as f:
        f.write("\n".join(lines) + "\n")


def generate_tcl_file(config, output_path):
    """Generates a TCL environment file from the project config."""
    lines = ["# Generated by project_manager.py"]

    project = config.get("project", {})
    lines.append(f'set g_project_name "{project.get("name", "system_top")}"')
    lines.append(f'set g_top_mod      "{project.get("top_module", "system_top")}"')
    lines.append(f'set g_top_sim      "{project.get("top_sim", "tb_system_top_sim")}"')

    hardware = config.get("hardware", {})
    lines.append(f'set g_fpga_part    "{hardware.get("part", "")}"')
    lines.append(f'set g_fpga_family  "{hardware.get("family", "")}"')

    # Derived paths — always emitted so TCL hooks can rely on them
    lines.append("")
    lines.append("# Derived paths (available to all TCL hooks)")
    lines.append('set g_root_dir     [file normalize [file dirname [info script]]]')

    mk_overrides = config.get("makefile_overrides", {})
    project_subdir = mk_overrides.get("project_dir", "project")
    lines.append(f'set g_project_dir  "${{g_root_dir}}/{project_subdir}"')

    vendor = hardware.get("vendor", "xilinx")
    overrides = config.get("vendor_overrides", {}).get(vendor, {})

    for key, value in overrides.items():
        # Sanitize value for TCL (booleans)
        if isinstance(value, bool):
            val_str = "true" if value else "false"
        else:
            val_str = f'"{value}"'
        lines.append(f"set g_{key} {val_str}")

    # TCL Hooks for gen_project
    tcl_hooks = config.get("tcl_hooks", {})
    gen_project_hooks = tcl_hooks.get("gen_project", [])
    if gen_project_hooks:
        # Format as TCL list: [list "item1" "item2" ...]
        hook_list = " ".join(f'"{h}"' for h in gen_project_hooks)
        lines.append(f"set g_gen_project_hooks [list {hook_list}]")

    # Per-stage TCL hooks (sourced after project_open in each stage script)
    for stage in ["synthesis", "implementation", "bitstream"]:
        stage_hooks = tcl_hooks.get(stage, [])
        if stage_hooks:
            hook_list = " ".join(f'"{h}"' for h in stage_hooks)
            lines.append(f"set g_{stage}_hooks [list {hook_list}]")

    # Quartus edition override (pro/std) — enables TCL-side branching
    build = config.get("build_options", {})
    edition = build.get("edition", "")
    if edition:
        lines.append(f'set g_quartus_edition "{edition}"')

    # Custom VHDL library mappings — auto-detected from source code.
    # The DependencyResolver parses `entity lib.component` and `use lib.pkg.all`
    # patterns to determine which files belong to non-default libraries.
    # This eliminates the need for explicit `sources.libraries` in project.yml.
    sources = config.get("sources", {})
    syn_files = sources.get("syn", [])
    libraries: dict = {}

    if syn_files:
        # Collect unique parent directories of synthesis source files
        # relative to the project root to use as scan paths.
        src_dirs: set = set()
        # The output_path is typically in the project root dir
        project_root = Path(output_path).parent
        for sf in syn_files:
            sf_path = project_root / sf
            if sf_path.exists():
                src_dirs.add(sf_path.parent.resolve())

        if src_dirs:
            try:
                from routertl_core.dependency_resolver import DependencyResolver
                resolver = DependencyResolver(
                    [Path(d) for d in src_dirs],
                    respect_gitignore=False,
                )

                # Build library → files map from the resolver's parse results.
                # _resolve_file_library() does the Path → library reverse lookup
                # using entity_lib_map + package_lib_map populated during scan.
                lib_files: dict = {}
                for sf in syn_files:
                    sf_path = (project_root / sf).resolve()
                    lib = resolver._resolve_file_library(sf_path)
                    if lib != "work":
                        lib_files.setdefault(lib, []).append(sf)

                if lib_files:
                    libraries = lib_files
            except (ImportError, Exception):
                # Fallback gracefully — DependencyResolver may not be available
                # in standalone project_manager.py invocations.
                pass

    if libraries:
        lines.append("")
        lines.append("# VHDL library mappings (library → file list)")
        dict_parts = []
        for lib_name, lib_files in libraries.items():
            if isinstance(lib_files, list):
                files_str = " ".join(f'"{f}"' for f in lib_files)
            else:
                files_str = f'"{lib_files}"'
            dict_parts.append(f'"{lib_name}" [list {files_str}]')
        tcl_dict = " ".join(dict_parts)
        lines.append(f"set g_libraries [dict create {tcl_dict}]")

    with open(output_path, "w") as f:
        f.write("\n".join(lines) + "\n")


def generate_hook_config(config):
    """Generates shell variables for git hooks."""
    lines = []
    hooks = config.get("hooks", {})

    # Pre-commit section
    pre_commit = hooks.get("pre_commit", {})
    if pre_commit:
        enabled = str(pre_commit.get("enabled", "true")).lower()
        lines.append(f"HOOK_ENABLED={enabled}")

        lint = str(pre_commit.get("lint", "false")).lower()
        lines.append(f"HOOK_LINT={lint}")

        check_yaml = str(pre_commit.get("check_yaml", "false")).lower()
        lines.append(f"HOOK_CHECK_YAML={check_yaml}")

        run_regression = str(pre_commit.get("run_regression", "false")).lower()
        lines.append(f"HOOK_RUN_REGRESSION={run_regression}")

        check_links = str(pre_commit.get("check_links", "false")).lower()
        lines.append(f"HOOK_CHECK_LINKS={check_links}")

        check_docs = str(pre_commit.get("check_docs", "false")).lower()
        lines.append(f"HOOK_CHECK_DOCS={check_docs}")

        lint_python = str(pre_commit.get("lint_python", "false")).lower()
        lines.append(f"HOOK_LINT_PYTHON={lint_python}")

        tests = pre_commit.get("tests", [])

        # Support 'inherit' — fall back to cicd.tests
        if isinstance(tests, str) and tests.strip().lower() == "inherit":
            tests = config.get("cicd", {}).get("tests", [])
            if tests:
                logging.info(
                    "hooks.pre_commit.tests: inheriting from cicd.tests"
                )

        # Exclusion lists
        exclude = pre_commit.get("exclude", {})
        exclude_tests = exclude.get("tests", [])
        if not isinstance(exclude_tests, list):
            exclude_tests = []

        if isinstance(tests, str) and tests.strip().lower() == "auto":
            # Auto-discovery mode: find all test_*.py in simulation.test_dir
            sim_cfg = config.get("simulation") or {}
            if not isinstance(sim_cfg, dict):
                sim_cfg = {}
            sim_dir = sim_cfg.get("test_dir", "sim/cocotb/tests")
            sim_path = Path(sim_dir)

            discovered = []
            if sim_path.exists():
                # Filter out untracked files — prevents WIP test_*.py
                # from leaking into the pre-commit hook's test list
                tracked_tests = filter_git_tracked(
                    sorted(sim_path.rglob("test_*.py"))
                )
                for f in tracked_tests:
                    # Convert path to dotted module name:
                    #   sim/cocotb/tests/units/test_edge.py -> tests.units.test_edge
                    rel = f.relative_to(sim_path)
                    parts = list(rel.with_suffix("").parts)
                    module_name = "tests." + ".".join(parts)
                    discovered.append(module_name)

            # Apply exclusions
            filtered = [t for t in discovered if t not in exclude_tests]
            tests_str = " ".join(filtered)
            lines.append(f'HOOK_TESTS="{tests_str}"')
            # Exclusions already applied — emit empty HOOK_EXCLUDE_TESTS
            lines.append('HOOK_EXCLUDE_TESTS=""')
        elif isinstance(tests, list):
            # Divergence warning: both sections explicit and different
            cicd_tests = config.get("cicd", {}).get("tests", [])
            if (
                isinstance(cicd_tests, list)
                and cicd_tests
                and tests
                and set(tests) != set(cicd_tests)
                and cicd_tests != "inherit"
            ):
                logging.warning(
                    "hooks.pre_commit.tests and cicd.tests are both explicit "
                    "and differ. Use 'inherit' in one to stay DRY."
                )

            # Apply exclusions to explicit list
            filtered = [t for t in tests if t not in exclude_tests]
            tests_str = " ".join(filtered)
            lines.append(f'HOOK_TESTS="{tests_str}"')
            # Emit exclude.tests for the hook script to apply (compatibility)
            exclude_tests_str = " ".join(exclude_tests)
            lines.append(f'HOOK_EXCLUDE_TESTS="{exclude_tests_str}"')
        else:
            lines.append('HOOK_TESTS=""')
            lines.append('HOOK_EXCLUDE_TESTS=""')

        exclude_lint = exclude.get("lint", [])
        if isinstance(exclude_lint, list):
            exclude_lint_str = " ".join(exclude_lint)
            lines.append(f'HOOK_EXCLUDE_LINT="{exclude_lint_str}"')
        else:
            lines.append('HOOK_EXCLUDE_LINT=""')

        exclude_docs = exclude.get("docs", [])
        if isinstance(exclude_docs, list):
            exclude_docs_str = " ".join(exclude_docs)
            lines.append(f'HOOK_EXCLUDE_DOC_DIRS="{exclude_docs_str}"')
        else:
            lines.append('HOOK_EXCLUDE_DOC_DIRS=""')

        # Frozen directories
        frozen_dirs = pre_commit.get("frozen_dirs", [])
        if isinstance(frozen_dirs, list) and frozen_dirs:
            frozen_dirs_str = " ".join(frozen_dirs)
            lines.append(f'HOOK_FROZEN_DIRS="{frozen_dirs_str}"')
        else:
            lines.append('HOOK_FROZEN_DIRS=""')
    else:
        # Default behavior if section missing: do nothing
        lines.append("HOOK_ENABLED=false")

    return "\n".join(lines)


def main():
    """CLI entry point for the project manager."""
    parser = argparse.ArgumentParser(description="Manage project configuration from YAML")
    parser.add_argument("yaml_file", help="Path to project.yml")
    parser.add_argument("--out-mk", default="build_env.mk", help="Output Makefile include")
    parser.add_argument("--out-tcl", default="build_env.tcl", help="Output TCL include")
    parser.add_argument("--gen-hook-config", action="store_true", help="Generate shell config for hooks and exit")

    args = parser.parse_args()

    config = load_config(args.yaml_file)
    if not config:
        sys.exit(1)

    # Hook config generation mode
    if args.gen_hook_config:
        print(generate_hook_config(config))
        return

    # Auto-resolve sources if requested
    project_root = os.path.dirname(os.path.abspath(args.yaml_file))

    # Ensure dependencies are present
    ensure_dependencies(config, project_root)

    config = resolve_auto_sources(config, project_root)

    generate_mk_file(config, args.out_mk)
    generate_tcl_file(config, args.out_tcl)

    # Write dependency sentinel — checked by `make check-deps` to avoid
    # cryptic compiler errors when libs are missing but build_env.mk is cached.
    sentinel = os.path.join(project_root, ".deps.ok")
    with open(sentinel, "w") as f:
        f.write("# Dependency sentinel — auto-generated by project_manager.py\n")

    print(f"Successfully generated {args.out_mk} and {args.out_tcl}")


if __name__ == "__main__":
    main()
