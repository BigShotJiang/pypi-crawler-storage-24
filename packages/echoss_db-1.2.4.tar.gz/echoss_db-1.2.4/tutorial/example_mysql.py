# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.0
#   kernelspec:
#     display_name: echoss_dev
#     language: python
#     name: echoss_dev
# ---

# %% pycharm={"is_executing": true}
import sys
import os
import pandas as pd
from echoss_fileformat import to_table

# sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname('echoss_query.py'))))

# Add the project root directory to the Python path
project_root = os.path.abspath('..')
sys.path.insert(0, project_root)
from echoss_db import MysqlQuery

# %%
if 'ipykernel' not in sys.modules:
    def display(obj):
        if isinstance(obj, pd.DataFrame):
            if len(obj) > 0:
                print(to_table(obj))
        else:
            print(obj)

# %%
mysql = MysqlQuery('../config/config_dev.yaml')


# %% [markdown]
# ### MySQL

# %%
mysql.ping()

# %%
# query statement in debug logging mode : default True
mysql.query_debug(False)

# %%
display(mysql.databases())

# %%
display(mysql.tables())

# %%
mysql.query_debug(True)

# %%
display(mysql.select("SELECT * FROM project_info "))

# %%
mysql.faster_select("SELECT * FROM p1_data_info where type_name='type01b' and watertank_number='wt01'")

# %%
for chunk in mysql.faster_select_generator("SELECT * FROM p1_data_info where type_name='type01b' and watertank_number='wt01'"):
    print(f"processing {len(chunk)} data chunk")

# %%
result = mysql.select("SELECT * FROM p1_data_info WHERE file_name = %s", 'v001_45_type01b_wt01_220615_16_100_99_99_001')
display(result)

# %%
# project_id int AI PK
# project_name varchar(255)
# s3_bucket varchar(200)
# start_timestamp datetime
# end_timestamp datetime
# folder_name varchar(20)
# INSERT문 사용 예제
tuple_params = ('test_project','ai-solution-test-bucket','2025-04-08 17:30:00',None,'folder_base')
mysql.insert("INSERT INTO project_info (project_name, s3_bucket, start_timestamp, end_timestamp, folder_name)  VALUES (%s,%s, %s,%s,%s)", tuple_params)

# INSERT 확인
display(mysql.select("SELECT * FROM project_info WHERE project_name = 'test_project'"))

#  return_lastrowid 시험
tuple_params = ('test_project','ai-solution-test-bucket','2025-12-29 10:44:00',None,'folder_base')
mysql.insert("INSERT INTO project_info (project_name, s3_bucket, start_timestamp, end_timestamp, folder_name)  VALUES (%s,%s, %s,%s,%s)", tuple_params, return_lastrowid=True)
display(mysql.select("SELECT * FROM project_info WHERE project_name = 'test_project'"))

# %%
# UPDATE문 사용 예제
update_result = mysql.update("UPDATE project_info SET s3_bucket = 'test'  WHERE project_name = 'test_project'")

# UPDATE 확인
display(mysql.select("SELECT * FROM project_info WHERE project_name = 'test_project'"))

# %%
# DELETE문 사용 예제
mysql.delete("DELETE FROM project_info WHERE project_name = 'test_project'")

# DELETE 확인
display(mysql.select("SELECT * FROM project_info WHERE project_name = 'test_project'"))

# %%
