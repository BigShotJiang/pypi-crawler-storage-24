# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.2
#   kernelspec:
#     display_name: echoss_dev
#     language: python
#     name: echoss_dev
# ---

# %%
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(os.path.dirname('echoss_query.py'))))

from echoss_db import ElasticSearch

elastic = ElasticSearch('../config/config_dev.yaml')

# %%
# ping 날리기
elastic.ping()

# %%
# index 생성
response = elastic.index(
    index='index-test',
    id=1234,
    body={
        'title' : 'Elastic Search',
        'description' : 'index create test',
        'price' : 350.0 
    })

print(response)

# %%
# index 생성
response = elastic.index(
    index='index-test',
    body={
        'title' : 'test only',
        'description' : 'index test data 2',
        'price' : 10.0 
    })

print(response)

# %%
response = elastic.search()
print(response)

# %%
df = elastic.to_dataframe(response)
print(df.to_markdown())

# %%
# 기존 document update
response = elastic.update(index='index-test',
        id=1234,
        body={
            'title' : 'new title',
            'description' : 'update description',
            'auther' : 'Tom John'
        })
print(response)

# %%
# 기존 document update
response = elastic.update(index='index-test',
        id=1234,
        body={
            'title' : 'update title',
            'description' : 'update description'
        })

# %%
print(response)

# %% bulk upsert
doc_list = []
for i in range(300):
    doc = {
        'doc_id': f"doc_{1000+i:05d}",
        'title': 'upsert bulk test',
        'description': f'bulk update {i} operation'
    }
    doc_list.append(doc)

success, errors = elastic.bulk_upsert('index-test', doc_list, id_field='doc_id', raise_on_error=False)

# %%
print(f"{response}, {len(errors)=}")


# %%
# search 기능
response = elastic.search_field(
    field='title',
    value='update title',
    index='index-test'
    )
print(response)

# %%
response = elastic.search_list(body={'query': { 'match_all': {}}}, index='index-test')
print(response)
print(elastic.to_dataframe(response))

# %%
search_query = {
    'query': {
        "range": {
            "price": {
                "gt": 100.0,  
                "lt": 4500.0   
            }
        }
    }
}
response = elastic.search_list(body=search_query, index='index-test')
print(response)
print(elastic.to_dataframe(response))

# %%
# get 기능(select)
response = elastic.get(doc_id=1234, index='index-test')
print(response)

# %%
# get source 기능(select)
response = elastic.get_source(id=1234, index='index-test')
print(response)

# %%
# document delete
response = elastic.delete(id=1234, index='index-test')
print(response)

# %%
response = elastic.delete_index(index='index-test')
print(response)

# %%
