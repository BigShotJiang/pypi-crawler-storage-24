# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.0
#   kernelspec:
#     display_name: echoss_dev
#     language: python
#     name: echoss_dev
# ---

# %% [markdown]
# # Qdrant Vector 테스트
# - Postgres chunk 조회 (먼저 `example_postgres_qdrant_ingest.py` 실행)
# - fastembed_model 기반 원문 업서트
# - 검색 테스트
# - 외부 벡터 주입 방식은 코드 스니펫으로만 설명

# %%
import sys
import os
import json
import pandas as pd
from echoss_fileformat import to_table
from echoss_fileformat import FileUtil

base_path = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.join(base_path, '..')
sys.path.insert(0, project_root)

from echoss_db import PostgresQuery
from echoss_db.qdrant_vector import QdrantVector

# %%
if 'ipykernel' not in sys.modules:
    def display(obj):
        if isinstance(obj, pd.DataFrame):
            if len(obj) > 0:
                print(to_table(obj))
        else:
            print(obj)

CONFIG_PATH = os.path.join(project_root, "config/config_dev.yaml")
COLLECTION_FASTEMBED = "ai_rag_chunks_fastembed"
EMBED_MODEL_NAME = "intfloat/multilingual-e5-large"


def select_korean_multilingual_model(model_details, requested_model):
    names = [item["model"] for item in model_details if "model" in item]
    if requested_model in names:
        return requested_model

    preferred_models = [
        "intfloat/multilingual-e5-large",
        "sentence-transformers/paraphrase-multilingual-mpnet-base-v2",
        "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
    ]
    for model_name in preferred_models:
        if model_name in names:
            return model_name

    keyword_priority = ["korean", "한국", "ko", "multilingual", "m3", "bge"]
    for item in model_details:
        model_name = item.get("model", "")
        description = str(item.get("description", ""))
        search_text = f"{model_name} {description}".lower()
        if any(keyword in search_text for keyword in keyword_priority):
            return model_name

    return names[0] if names else requested_model

# %%
pq = PostgresQuery(CONFIG_PATH)
base_config = FileUtil.dict_load(CONFIG_PATH)
qdrant_base = dict(base_config["qdrant"])

config_fastembed = dict(base_config)
config_fastembed["qdrant"] = dict(qdrant_base)
config_fastembed["qdrant"]["collection"] = COLLECTION_FASTEMBED
config_fastembed["qdrant"]["fastembed_model"] = EMBED_MODEL_NAME

qv_fastembed = QdrantVector(config_fastembed)

print("Qdrant Ping (fastembed):", qv_fastembed.ping())
print("requested fastembed model:", EMBED_MODEL_NAME)
supported_model_details = qv_fastembed.list_supported_models_by_class("TextEmbedding")

print("\n[supported models - details]")
for model_info in supported_model_details:
    model_name = model_info.get("model")
    description = model_info.get("description")
    dim = model_info.get("dim")
    license = model_info.get('license')
    size_in_GB = model_info.get('size_in_GB')
    print(f"- {model_name=} | {dim=} | {description} | {license=} | {size_in_GB=}")

selected_model = select_korean_multilingual_model(supported_model_details, EMBED_MODEL_NAME)
print("selected fastembed model:", selected_model)
qv_fastembed.fastembed_model = selected_model

# %% [markdown]
# ## 1️⃣ Postgres에서 chunk 가져오기

# %%
rows = pq.select_list(
    """
    SELECT c.chunk_id, c.content
    FROM kb_chunk c
    JOIN kb_document d ON d.doc_id = c.doc_id
    WHERE d.source_uri LIKE %s
    ORDER BY c.chunk_id
    LIMIT %s
    """,
    ("tutorial://qdrant/%", 200)
)
if len(rows) < 20:
    raise ValueError(
        "테스트 데이터가 부족합니다. tutorial/example_postgres_qdrant_ingest.py를 먼저 실행하세요."
    )

display(rows[:2])
print("rows json preview:")
print(json.dumps(rows[:2], ensure_ascii=False, indent=2))

# %% [markdown]
# ## 2️⃣ fastembed_model 방식 (원문 직접 주입)

# %%
qv_fastembed.delete_collection(collection=COLLECTION_FASTEMBED)
qv_fastembed.create_collection(collection=COLLECTION_FASTEMBED)

points_fastembed = []
for row in rows:
    points_fastembed.append({
        "id": row["chunk_id"],
        "document": row["content"],
        "payload": {
            "chunk_id": row["chunk_id"],
            "content": row["content"],
            "project": "tutorial",
            "mode": "fastembed_model"
        }
    })

qv_fastembed.upsert_texts(points_fastembed, collection=COLLECTION_FASTEMBED)
print("qdrant input json preview:")
print(json.dumps(points_fastembed[:2], ensure_ascii=False, indent=2))
hits_fastembed = qv_fastembed.search_text(
    query_text="RAG 시스템 설계 아키텍처",
    limit=5,
    collection=COLLECTION_FASTEMBED
)

print("[fastembed_model] top hits")
for h in hits_fastembed:
    print("ID:", h.id, "Score:", h.score, "Content:", h.payload.get("content"))

# %% [markdown]
# ## 3️⃣ 외부 벡터 주입 방식 (설명용 스니펫)

# 외부 임베딩 생성기는 서비스 레이어에서 준비하세요.
# 아래는 실행 예시(설명용)입니다.
#
# qv_vector = QdrantVector({
#     "qdrant": {
#         "host": "localhost",
#         "port": 6333,
#         "scheme": "http",
#         "collection": "ai_rag_chunks_external",
#         "fastembed_model": None
#     }
# })
#
# points = [
#     {"id": 1, "vector": your_embed_fn("문서 원문"), "payload": {"source": "external"}}
# ]
# qv_vector.create_collection(dim=len(points[0]["vector"]))
# qv_vector.upsert_vectors(points)
# hits = qv_vector.search_vector(vector=your_embed_fn("질의"))

# %% [markdown]
# ## 4️⃣ 완료

# %%
print("qdrant 테스트 완료 (fastembed_model)")
