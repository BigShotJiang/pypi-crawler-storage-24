# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.0
#   kernelspec:
#     display_name: echoss_dev
#     language: python
#     name: echoss_dev
# ---

# %% [markdown]
# # Postgres -> Qdrant 테스트용 데이터 적재
# - Qdrant 검색 품질 검증을 위한 충분한 텍스트 chunk를 생성합니다.
# - 이 스크립트를 먼저 실행한 후 `example_qdrant.py`를 실행하세요.

# %%
import sys
import os
import hashlib
import pandas as pd
from echoss_fileformat import to_table

base_path = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(base_path, '..'))
sys.path.insert(0, project_root)

from echoss_db import PostgresQuery


# %%
if "ipykernel" not in sys.modules:
    def display(obj):
        if isinstance(obj, pd.DataFrame):
            if len(obj) > 0:
                print(to_table(obj))
        else:
            print(obj)


CONFIG_PATH = os.path.join(project_root, "config/config_dev.yaml")
SOURCE_URI_PREFIX = "tutorial://qdrant/"

DATASET = [
    {
        "source_uri": "tutorial://qdrant/rag_design",
        "chunks": [
            "RAG 시스템 설계의 핵심은 검색 품질과 프롬프트 결합 전략이다.",
            "질의 임베딩 품질이 낮으면 관련 문서가 누락되어 답변 정확도가 떨어진다.",
            "하이브리드 검색은 키워드와 벡터를 함께 사용해 회수율을 개선한다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/qdrant_ops",
        "chunks": [
            "Qdrant는 벡터 유사도 검색을 위해 컬렉션과 포인트 구조를 사용한다.",
            "검색 시 payload 필터를 함께 사용하면 권한 기반 검색이 가능하다.",
            "컬렉션 차원은 임베딩 모델 차원과 일치해야 정상 검색이 된다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/postgres_fts",
        "chunks": [
            "Postgres FTS는 토큰 기반 검색으로 정확한 키워드 매칭에 강점이 있다.",
            "벡터 검색은 의미 유사성을 찾는 데 유리하지만 키워드 제어가 약할 수 있다.",
            "FTS와 벡터를 조합하면 랭킹 안정성과 재현성을 함께 확보할 수 있다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/embedding_models",
        "chunks": [
            "임베딩 모델 교체 시 동일 질의에서도 유사도 분포가 크게 달라질 수 있다.",
            "한국어 검색에서는 다국어 모델이 영어 중심 모델보다 안정적인 경우가 많다.",
            "모델 버전 고정은 운영 환경에서 검색 회귀를 줄이는 기본 원칙이다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/mlops",
        "chunks": [
            "검색 파이프라인은 배포 전에 오프라인 평가셋으로 NDCG를 점검해야 한다.",
            "온라인 서비스에서는 검색 로그 기반으로 질의 유형을 분류해 개선한다.",
            "관측 지표는 latency, recall, precision, 비용을 함께 봐야 한다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/security",
        "chunks": [
            "RAG 서비스는 소스 문서의 접근 권한을 검색 단계에서 반드시 반영해야 한다.",
            "민감 문서는 payload 태그와 필터로 노출 범위를 통제한다.",
            "검색 결과를 프롬프트에 넣기 전 마스킹 정책을 적용하는 것이 안전하다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/dev_guide",
        "chunks": [
            "테스트 데이터가 너무 적으면 임베딩 모델 간 차이를 판단하기 어렵다.",
            "비슷한 주제와 다른 주제를 함께 넣어야 유사도 판별력을 측정할 수 있다.",
            "질의 문장을 여러 패턴으로 만들어 검색 편향을 확인한다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/agri_policy",
        "chunks": [
            "농업 정책 문서는 지원 대상과 신청 기준이 매년 개정될 수 있다.",
            "보조금 안내 자료는 지역별 차이가 있어 검색 필터 설계가 중요하다.",
            "정책 문서 검색은 최신 공고일 기준 정렬이 함께 필요하다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/supply_chain",
        "chunks": [
            "공급망 데이터 분석에서는 재고 회전율과 리드타임 지표를 함께 본다.",
            "수요 예측 실패는 과잉 재고 또는 품절 리스크로 이어진다.",
            "요약 문서와 원문 보고서를 동시에 검색하면 의사결정 품질이 올라간다.",
        ],
    },
    {
        "source_uri": "tutorial://qdrant/finance_risk",
        "chunks": [
            "리스크 관리 문서는 규제 용어가 많아 키워드 검색 성능이 중요하다.",
            "의미 검색은 표현이 다른 문장을 연결해 규정 해석을 돕는다.",
            "최종 답변에는 반드시 근거 문서의 출처와 구간을 함께 제공해야 한다.",
        ],
    },
]


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# %%
pq = PostgresQuery(CONFIG_PATH)
print("Ping:", pq.ping())

# %%
# 기존 tutorial 데이터 정리 (idempotent)
old_docs = pq.select_list(
    """
    SELECT doc_id
    FROM kb_document
    WHERE source_uri LIKE %s
    """,
    (f"{SOURCE_URI_PREFIX}%",),
)
old_doc_ids = [d["doc_id"] for d in old_docs]
for doc_id in old_doc_ids:
    pq.delete("DELETE FROM kb_chunk WHERE doc_id = %s", (doc_id,))
for doc_id in old_doc_ids:
    pq.delete("DELETE FROM kb_document WHERE doc_id = %s", (doc_id,))

print(f"cleanup complete. deleted_docs={len(old_doc_ids)}")

# %%
inserted_docs = 0
inserted_chunks = 0

for item in DATASET:
    source_uri = item["source_uri"]
    chunks = item["chunks"]
    version_hash = sha256_text(source_uri + "||" + "||".join(chunks))

    doc_id = pq.insert(
        """
        INSERT INTO kb_document
        (source_type, source_uri, version_hash)
        VALUES (%s, %s, %s)
        RETURNING doc_id
        """,
        ("tutorial", source_uri, version_hash),
        return_lastrowid=True,
    )
    if not doc_id:
        raise ValueError(f"doc insert failed: {source_uri}")
    inserted_docs += 1

    rows = []
    for i, text in enumerate(chunks, start=1):
        rows.append((doc_id, i, text))
    inserted_chunks += pq.insert(
        """
        INSERT INTO kb_chunk (doc_id, chunk_no, content)
        VALUES (%s, %s, %s)
        """,
        rows,
    )

print(f"insert complete. docs={inserted_docs}, chunks={inserted_chunks}")

# %%
summary = pq.select(
    """
    SELECT d.doc_id, d.source_uri, count(c.chunk_id) AS chunk_count
    FROM kb_document d
    JOIN kb_chunk c ON c.doc_id = d.doc_id
    WHERE d.source_uri LIKE %s
    GROUP BY d.doc_id, d.source_uri
    ORDER BY d.doc_id
    """,
    (f"{SOURCE_URI_PREFIX}%",),
)

display(summary)
print("now run: tutorial/example_qdrant.py")
