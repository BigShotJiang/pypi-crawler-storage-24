# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.0
#   kernelspec:
#     display_name: echoss_dev
#     language: python
#     name: echoss_dev
# ---

# %%
import pandas as pd
import os
import sys

from echoss_fileformat import to_table

# sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname('echoss_query.py'))))

# Add the project root directory to the Python path
project_root = os.path.abspath('..')
sys.path.insert(0, project_root)
from echoss_db import MongoQuery

# %%
if 'ipykernel' not in sys.modules:
    def display(obj):
        if isinstance(obj, pd.DataFrame):
            print(to_table(obj))
        else:
            print(obj)

from echoss_query import MongoQuery

mongo = MongoQuery('../config/config_dev.yaml')

# %% [markdown]
# ### Mongo

# %%
mongo.ping()

# %%
display(mongo.databases())

# %%
display(mongo.collections('ai_center'))

# %%
result_df = mongo.select('p1_data_info',{})
display(result_df)
# %%
result_df = mongo.select('p1_data_info',{'file_name':'v001_45_type01b_wt01_220615_16_100_99_99_001'})
display(result_df)

result_list = mongo.select_list('p1_data_info',{'file_name':'v001_45_type01b_wt01_220615_16_100_99_99_001'})
display(result_list)

result_dict = mongo.select_one('p1_data_info',{'file_name':'v001_45_type01b_wt01_220615_16_100_99_99_001'})
display(result_dict)

# %%

# %%
# SELECT문 사용 예제
result = mongo.select('DATA_INFO',{'FILE_NAME':'v001_45_type01b_wt01_220615_16_100_99_99_001'})
display(result)

# %%
# INSERT문 사용 예제
mongo.insert('PROJECT_INFO',{'PROJECT_NUMBER':45,'PROJECT_NAME':'abalone_test','START_TIMESTAMP':'2022-04-01 00:00:00','END_TIMESTAMP':'2022-04-01 00:00:00'})

# INSERT 확인
display(mongo.select('PROJECT_INFO',{}))

# use insert_many when insert multiple documents by list at once

# %%
# UPDATE문 사용 예제
mongo.update('PROJECT_INFO',{'PROJECT_NAME':'abalone_test'},{"$set":{'PROJECT_NAME':'abalone2'}})

# UPDATE 확인
display(mongo.select('PROJECT_INFO',{}))

# use update_many when update documents by list at once

# %%
# DELETE문 사용 예제
mongo.delete('PROJECT_INFO',{'PROJECT_NAME':'abalone2'})

# DELETE 확인
display(mongo.select('PROJECT_INFO',{}))

# use delete_many when delete multiple documents by list at once
