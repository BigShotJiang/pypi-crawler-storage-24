# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.16.0
#   kernelspec:
#     display_name: echoss_dev
#     language: python
#     name: echoss_dev
# ---

# %% [markdown]
# # Postgres + ai_rag 테스트
# - kb_document insert
# - kb_chunk insert
# - FTS 검색
# - Qdrant 적재용 데이터 준비 (fastembed model)

# %%
import sys
import os
import hashlib
import pandas as pd
from echoss_fileformat import to_table

# 프로젝트 루트 추가 (현재 수정 코드 사용)
base_path = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(base_path, '..'))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from echoss_db import PostgresQuery


# %%
if 'ipykernel' not in sys.modules:
    def display(obj):
        if isinstance(obj, pd.DataFrame):
            if len(obj) > 0:
                print(to_table(obj))
        else:
            print(obj)

CONFIG_PATH = os.path.join(project_root, 'config', 'config_dev.yaml')
# 임시 데이터 모드: True면 예제 마지막에 kb_chunk / kb_document를 정리 삭제합니다.
CLEANUP_AT_END = True

# %%
pq = PostgresQuery(CONFIG_PATH)
print("Ping:", pq.ping())

# %% [markdown]
# ## 1️⃣ 문서 Insert

# %%
def sha256_text(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()

doc_hash = sha256_text("tutorial_document_v1")

exists = pq.select_one(
    """
    SELECT doc_id
    FROM kb_document
    WHERE version_hash = %s
    ORDER BY doc_id DESC
    LIMIT 1
    """,
    (doc_hash,)
)

if exists and "doc_id" in exists:
    doc_id = exists["doc_id"]
    print("Reuse doc_id:", doc_id)
else:
    doc_id = pq.insert(
        """
        INSERT INTO kb_document
        (source_type, source_uri, version_hash)
        VALUES (%s, %s, %s)
        RETURNING doc_id
        """,
        ("nfs", "/mnt/tutorial.txt", doc_hash),
        return_lastrowid=True
    )
    if not doc_id:
        raise ValueError("doc_id를 확보하지 못했습니다. kb_document INSERT/조회 상태를 확인하세요.")
    print("Inserted doc_id:", doc_id)

# %% [markdown]
# ## 2️⃣ Chunk Insert

# %%
chunks = [
    (doc_id, 1, "Postgres와 Qdrant를 이용한 RAG 시스템 예제입니다."),
    (doc_id, 2, "이 문서는 tutorial 용도로 작성되었습니다.")
]

# tutorial 재실행 시 중복 chunk를 방지하기 위해 기존 chunk를 정리합니다.
pq.delete(
    """
    DELETE FROM kb_chunk
    WHERE doc_id = %s
    """,
    (doc_id,)
)

pq.insert(
    """
    INSERT INTO kb_chunk (doc_id, chunk_no, content)
    VALUES (%s, %s, %s)
    """,
    chunks
)

print("Chunks inserted.")

# %% [markdown]
# ## 3️⃣ FTS 검색

# %%
df = pq.select(
    """
    SELECT chunk_id, content
    FROM kb_chunk
    WHERE content_tsv @@ websearch_to_tsquery('simple', %s)
    ORDER BY chunk_id
    """,
    ("RAG 시스템",)
)

display(df)

# %% [markdown]
# ## 4️⃣ Qdrant 적재용 데이터 준비 (fastembed_model 방식)

# %%
rows = pq.select_list(
    """
    SELECT chunk_id, content
    FROM kb_chunk
    WHERE doc_id = %s
    ORDER BY chunk_no
    """,
    (doc_id,)
)

points_fastembed = []
for row in rows:
    points_fastembed.append({
        "id": row["chunk_id"],
        "document": row["content"],
        "payload": {
            "chunk_id": row["chunk_id"],
            "content": row["content"],
            "source": "postgres_example",
            "mode": "fastembed_model"
        }
    })

print("fastembed_model points:", len(points_fastembed))
print("fastembed_model sample keys:", list(points_fastembed[0].keys()) if points_fastembed else [])

# %% [markdown]
# ## 5️⃣ Optional Cleanup (임시 데이터 정리)

# %%
if CLEANUP_AT_END:
    deleted_chunks = pq.delete(
        """
        DELETE FROM kb_chunk
        WHERE doc_id = %s
        """,
        (doc_id,)
    )
    deleted_docs = pq.delete(
        """
        DELETE FROM kb_document
        WHERE doc_id = %s
        """,
        (doc_id,)
    )
    print(f"Cleanup complete. deleted_chunks={deleted_chunks}, deleted_docs={deleted_docs}")
else:
    print("Cleanup skipped. Set CLEANUP_AT_END=True to remove tutorial rows.")
