from __future__ import annotations

from importlib import import_module

__all__ = [
    "MysqlQuery",
    "MongoQuery",
    "ElasticSearch",
    "PostgresQuery",
    "QdrantVector",
]

_EXPORTS = {
    "MysqlQuery": ".mysql_query",
    "MongoQuery": ".mongo_query",
    "ElasticSearch": ".elastic_search",
    "PostgresQuery": ".postgres_query",
    "QdrantVector": ".qdrant_vector",
}


def __getattr__(name: str):
    module_name = _EXPORTS.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = import_module(module_name, __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__():
    return sorted(list(globals().keys()) + __all__)
