import pandas as pd
from typing import Any, Dict, List, Optional, Union

from echoss_fileformat import FileUtil, get_logger

logger = get_logger("echoss_query")

from qdrant_client import QdrantClient
from qdrant_client.http import models as qm


class QdrantVector:
    conn = None
    empty_dataframe = pd.DataFrame()
    default_limit = 10
    default_fastembed_model = "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2"

    def __init__(self, conn_info: Union[str, dict]):
        """
        Args:
            conn_info:
              ex) {
                'qdrant': {
                  'host': 'rnd62',
                  'port': 6333,
                  'scheme': 'http',
                  'collection': 'ai_rag_chunks',
                  'timeout': 5,
                  'default_limit': 10
                }
              }
        """
        if isinstance(conn_info, str):
            conn_info = FileUtil.dict_load(conn_info)
        elif not isinstance(conn_info, dict):
            raise TypeError("QdrantVector support type 'str' and 'dict'")

        required_keys = ['host', 'port']
        if (len(conn_info) > 0) and ('qdrant' in conn_info) and all(k in conn_info['qdrant'] for k in required_keys):
            q_config = conn_info['qdrant']
        else:
            raise TypeError("[Qdrant] config info not exist")

        self.host = q_config['host']
        self.port = q_config.get('port', 6333)
        self.scheme = q_config.get('scheme', 'http')
        self.timeout = q_config.get('timeout', 5)
        self.collection_name = q_config.get('collection')  # default collection
        self.default_limit = q_config.get('default_limit', 10)
        self.url = f"{self.scheme}://{self.host}:{self.port}"
        self.conn = self._connect()
        # Default policy: use fastembed unless fastembed_model is explicitly null.
        if "fastembed_model" in q_config:
            self.fastembed_model = q_config.get("fastembed_model")
        else:
            self.fastembed_model = self.default_fastembed_model
        self._validate_fastembed_support()

    def __str__(self):
        return f"QdrantVector(url={self.url}, collection={self.collection_name})"

    def _connect(self):
        try:
            cli = QdrantClient(url=self.url, timeout=self.timeout)
            # 간단 ping: collections 호출
            cli.get_collections()
            return cli
        except Exception:
            raise ValueError("Connection failed by config. Please check config data")

    def _validate_fastembed_support(self):
        if not self.fastembed_model:
            return
        if not hasattr(self.conn, "get_embedding_size"):
            raise ValueError(
                "fastembed_model is configured, but qdrant-client fastembed features are unavailable. "
                "Install qdrant-client with fastembed extras."
            )
        if not self.list_supported_models_by_class("TextEmbedding"):
            raise ValueError(
                "fastembed_model is configured, but fastembed.TextEmbedding is unavailable. "
                "Install qdrant-client with fastembed extras."
            )

    def list_supported_models_by_class(self, class_name: str = "TextEmbedding") -> List[Dict[str, Any]]:
        """Return fastembed supported models for given class name.

        Supported class_name values:
            - TextEmbedding
            - SparseTextEmbedding
            - LateInteractionTextEmbedding
            - ImageEmbedding
            - MultimodalEmbedding
            - TextCrossEncoder
        """
        supported_class_names = {
            "TextEmbedding",
            "SparseTextEmbedding",
            "LateInteractionTextEmbedding",
            "ImageEmbedding",
            "MultimodalEmbedding",
            "TextCrossEncoder",
        }
        if class_name not in supported_class_names:
            raise ValueError(
                f"Unsupported class_name: {class_name}. "
                f"Use one of: {', '.join(sorted(supported_class_names))}"
            )
        resolved_class_name = class_name

        try:
            import fastembed
            model_class = getattr(fastembed, resolved_class_name, None)
            if model_class is None:
                return []
            models = model_class.list_supported_models()
            if isinstance(models, list):
                return models
            return []
        except Exception:
            return []

    def ping(self) -> bool:
        try:
            self.conn.get_collections()
            return True
        except Exception:
            return False

    def info(self) -> dict:
        """ES.info() 유사: collections 목록 반환"""
        return self.conn.get_collections().model_dump()

    # ---------- collection helpers ----------
    def _ensure_collection(self, collection: Optional[str]) -> str:
        if collection is None:
            collection = self.collection_name
        if not collection:
            raise ValueError("collection must be provided or set in config(qdrant.collection)")
        return collection

    def create_collection(self, dim: Optional[int] = None, distance: str = "Cosine", collection: Optional[str] = None):
        collection = self._ensure_collection(collection)
        if self.conn.collection_exists(collection):
            return
        if self.fastembed_model:
            try:
                inferred_dim = self.conn.get_embedding_size(self.fastembed_model)
            except ValueError as exc:
                if "Unsupported embedding model" not in str(exc):
                    raise
                supported_models = []
                for model_info in self.list_supported_models_by_class("TextEmbedding"):
                    if isinstance(model_info, str) and model_info:
                        supported_models.append(model_info)
                        continue
                    if isinstance(model_info, dict):
                        for key in ("model", "model_name", "name", "id"):
                            value = model_info.get(key)
                            if isinstance(value, str) and value:
                                supported_models.append(value)
                                break
                supported_preview = ", ".join(sorted(set(supported_models))) if supported_models else "(not available in current runtime)"
                raise ValueError(
                    f"Unsupported embedding model: {self.fastembed_model}. "
                    f"Supported models for qdrant-client/fastembed in this runtime: {supported_preview}. "
                    "Set qdrant.fastembed_model to one of these models."
                ) from exc
            if dim is not None and dim != inferred_dim:
                raise ValueError(
                    f"Configured fastembed_model dimension mismatch: dim={dim}, model_dim={inferred_dim}"
                )
            dim = inferred_dim
        elif dim is None:
            raise ValueError("dim is required when fastembed_model is not configured")

        dist = getattr(qm.Distance, distance.upper())
        self.conn.create_collection(
            collection_name=collection,
            vectors_config=qm.VectorParams(size=dim, distance=dist),
        )

    def delete_collection(self, collection: Optional[str] = None):
        collection = self._ensure_collection(collection)
        if self.conn.collection_exists(collection):
            self.conn.delete_collection(collection)

    def _build_filter(self, filter_: Optional[Dict[str, Any]] = None):
        """Build Qdrant filter from simplified filter dictionary."""
        qfilter = None
        if filter_ and "access_tags_any" in filter_:
            qfilter = qm.Filter(
                must=[qm.FieldCondition(
                    key="access_tags",
                    match=qm.MatchAny(any=filter_["access_tags_any"])
                )]
            )
        return qfilter

    # ---------- data ops ----------
    def upsert_points(self, points: List[Dict[str, Any]], collection: Optional[str] = None):
        """
        Backward-compatible upsert entrypoint.

        Behavior:
            - fastembed_model enabled: expects text fields(document/text/content) and internally
              converts to qm.Document.
            - fastembed_model disabled(None): expects vector fields.

        Args:
            points: Input points.
            collection: Target collection.
        """
        if self.fastembed_model:
            return self.upsert_texts(points=points, collection=collection)
        return self.upsert_vectors(points=points, collection=collection)

    def upsert_texts(self, points: List[Dict[str, Any]], collection: Optional[str] = None):
        """Upsert raw text points using fastembed_model.

        Required input fields per point:
            - id
            - one of document/text/content
        Optional:
            - payload

        Raises:
            ValueError: fastembed_model is disabled or vector field is mixed in text mode.
        """
        collection = self._ensure_collection(collection)
        if not points:
            return
        if not self.fastembed_model:
            raise ValueError("upsert_texts requires fastembed_model. Set qdrant.fastembed_model first.")

        ps = []
        for p in points:
            if "vector" in p:
                raise ValueError("upsert_texts does not accept vector. Use upsert_vectors instead.")
            text = p.get("document") or p.get("text") or p.get("content")
            if not text:
                raise ValueError("text input requires one of: document, text, content")
            ps.append(
                qm.PointStruct(
                    id=p["id"],
                    vector=qm.Document(text=text, model=self.fastembed_model),
                    payload=p.get("payload"),
                )
            )
        self.conn.upsert(collection_name=collection, points=ps, wait=True)

    def upsert_vectors(self, points: List[Dict[str, Any]], collection: Optional[str] = None):
        """Upsert explicit vectors.

        Required input fields per point:
            - id
            - vector
        Optional:
            - payload

        Raises:
            ValueError: fastembed_model is enabled. In that case use upsert_texts().
        """
        collection = self._ensure_collection(collection)
        if not points:
            return
        if self.fastembed_model:
            raise ValueError("upsert_vectors is disabled when fastembed_model is enabled. Use upsert_texts.")

        ps = []
        for p in points:
            if "vector" not in p:
                raise ValueError("vector is required for upsert_vectors")
            ps.append(qm.PointStruct(id=p["id"], vector=p["vector"], payload=p.get("payload")))
        self.conn.upsert(collection_name=collection, points=ps, wait=True)

    def search(self, vector: Optional[List[float]] = None, limit: Optional[int] = None,
               collection: Optional[str] = None,
               filter_: Optional[Dict[str, Any]] = None,
               with_payload: bool = True,
               query_text: Optional[str] = None):
        """
        Backward-compatible search entrypoint.

        Behavior:
            - fastembed_model enabled: query_text is required.
            - fastembed_model disabled(None): vector is required.

        Note:
            Prefer explicit methods for readability and safety:
            - search_text(...)
            - search_vector(...)
        """
        if self.fastembed_model:
            if query_text is None:
                raise ValueError("query_text is required in fastembed mode. Or use search_text().")
            if vector is not None:
                raise ValueError("vector input is not allowed in fastembed mode.")
            return self.search_text(
                query_text=query_text,
                limit=limit,
                collection=collection,
                filter_=filter_,
                with_payload=with_payload,
            )
        if vector is None:
            raise ValueError("vector is required in vector mode. Or use search_vector().")
        if query_text is not None:
            raise ValueError("query_text is not allowed in vector mode.")
        return self.search_vector(
            vector=vector,
            limit=limit,
            collection=collection,
            filter_=filter_,
            with_payload=with_payload,
        )

    def search_text(self, query_text: str, limit: Optional[int] = None,
                    collection: Optional[str] = None,
                    filter_: Optional[Dict[str, Any]] = None,
                    with_payload: bool = True):
        """Search by raw query text using fastembed_model."""
        if not self.fastembed_model:
            raise ValueError("search_text requires fastembed_model. Set qdrant.fastembed_model first.")
        if not query_text:
            raise ValueError("query_text is required")

        collection = self._ensure_collection(collection)
        if limit is None:
            limit = self.default_limit
        qfilter = self._build_filter(filter_)
        query_input = qm.Document(text=query_text, model=self.fastembed_model)

        resp = self.conn.query_points(
            collection_name=collection,
            query=query_input,
            limit=limit,
            with_payload=with_payload,
            query_filter=qfilter,
            with_vectors=False
        )
        return resp.points

    def search_vector(self, vector: List[float], limit: Optional[int] = None,
                      collection: Optional[str] = None,
                      filter_: Optional[Dict[str, Any]] = None,
                      with_payload: bool = True):
        """Search by explicit query vector."""
        if self.fastembed_model:
            raise ValueError("search_vector is disabled when fastembed_model is enabled. Use search_text.")
        if vector is None:
            raise ValueError("vector is required")

        collection = self._ensure_collection(collection)
        if limit is None:
            limit = self.default_limit
        qfilter = self._build_filter(filter_)
        # ✅ 1.16.x: search() 대신 query_points()
        resp =  self.conn.query_points(
            collection_name=collection,
            query=vector,
            limit=limit,
            with_payload=with_payload,
            query_filter=qfilter,
            with_vectors=False
        )

        # QueryResponse -> points 리스트 반환(호출부 호환)
        return resp.points


    def get_point(self, point_id: Union[int, str], collection: Optional[str] = None) -> dict:
        collection = self._ensure_collection(collection)
        pts = self.conn.retrieve(collection_name=collection, ids=[point_id], with_payload=True, with_vectors=False)
        return pts[0].model_dump() if pts else {}

    def delete_points(self, point_ids: List[Union[int, str]], collection: Optional[str] = None):
        collection = self._ensure_collection(collection)
        self.conn.delete(
            collection_name=collection,
            points_selector=qm.PointIdsList(points=point_ids),
            wait=True
        )

    def close(self):
        try:
            # qdrant-client는 명시 close가 필수는 아니지만 스타일 유지
            self.conn = None
        except Exception:
            pass

    def __del__(self):
        self.close()
