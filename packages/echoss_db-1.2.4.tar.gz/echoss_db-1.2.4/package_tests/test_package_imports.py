from __future__ import annotations

import subprocess
import sys
from pathlib import Path


ROOT_DIR = Path(__file__).resolve().parents[1]


def _run_python(code: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, "-c", code],
        cwd=ROOT_DIR,
        text=True,
        capture_output=True,
    )


def test_postgres_submodule_import_does_not_require_other_backends():
    result = _run_python(
        """
import sys
import types

pandas = types.ModuleType("pandas")
pandas.DataFrame = type("DataFrame", (), {})
sys.modules["pandas"] = pandas

echoss_fileformat = types.ModuleType("echoss_fileformat")
echoss_fileformat.FileUtil = type("FileUtil", (), {"dict_load": staticmethod(lambda path: {})})
echoss_fileformat.get_logger = lambda name: type(
    "Logger",
    (),
    {"debug": lambda *a, **k: None, "info": lambda *a, **k: None, "error": lambda *a, **k: None},
)()
sys.modules["echoss_fileformat"] = echoss_fileformat

sqlalchemy = types.ModuleType("sqlalchemy")
sqlalchemy.create_engine = lambda *a, **k: object()
sqlalchemy.text = lambda q: q
sys.modules["sqlalchemy"] = sqlalchemy

engine_mod = types.ModuleType("sqlalchemy.engine")
engine_mod.Engine = object
engine_mod.Connection = object
engine_mod.Result = object
sys.modules["sqlalchemy.engine"] = engine_mod

exc_mod = types.ModuleType("sqlalchemy.exc")
exc_mod.SQLAlchemyError = Exception
sys.modules["sqlalchemy.exc"] = exc_mod

from echoss_db.postgres_query import PostgresQuery

assert PostgresQuery.__name__ == "PostgresQuery"
assert "qdrant_client" not in sys.modules
assert "opensearchpy" not in sys.modules
assert "pymongo" not in sys.modules
"""
    )

    assert result.returncode == 0, result.stdout + result.stderr


def test_top_level_postgres_export_is_lazy():
    result = _run_python(
        """
import sys
import types

pandas = types.ModuleType("pandas")
pandas.DataFrame = type("DataFrame", (), {})
sys.modules["pandas"] = pandas

echoss_fileformat = types.ModuleType("echoss_fileformat")
echoss_fileformat.FileUtil = type("FileUtil", (), {"dict_load": staticmethod(lambda path: {})})
echoss_fileformat.get_logger = lambda name: type(
    "Logger",
    (),
    {"debug": lambda *a, **k: None, "info": lambda *a, **k: None, "error": lambda *a, **k: None},
)()
sys.modules["echoss_fileformat"] = echoss_fileformat

sqlalchemy = types.ModuleType("sqlalchemy")
sqlalchemy.create_engine = lambda *a, **k: object()
sqlalchemy.text = lambda q: q
sys.modules["sqlalchemy"] = sqlalchemy

engine_mod = types.ModuleType("sqlalchemy.engine")
engine_mod.Engine = object
engine_mod.Connection = object
engine_mod.Result = object
sys.modules["sqlalchemy.engine"] = engine_mod

exc_mod = types.ModuleType("sqlalchemy.exc")
exc_mod.SQLAlchemyError = Exception
sys.modules["sqlalchemy.exc"] = exc_mod

from echoss_db import PostgresQuery

assert PostgresQuery.__name__ == "PostgresQuery"
assert "qdrant_client" not in sys.modules
"""
    )

    assert result.returncode == 0, result.stdout + result.stderr
