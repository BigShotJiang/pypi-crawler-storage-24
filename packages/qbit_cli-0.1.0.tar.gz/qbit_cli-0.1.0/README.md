# qbit

A lightweight CLI todo app for your terminal.

## Features

- Add tasks
- List tasks
- Mark tasks as done
- Delete tasks
- Clear completed tasks

## Installation

### Local editable install

```bash
pip install -e .
```

### Install from built wheel

```bash
python -m build
pip install dist/qbit-0.1.0-py3-none-any.whl
```

## Release to TestPyPI and PyPI

Install Twine:

```bash
pip install twine build
```

Build artifacts:

```bash
python -m build
```

Upload to TestPyPI:

```bash
python -m twine upload --repository testpypi dist/*
```

Test install from TestPyPI:

```bash
pip install --index-url https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple qbit
```

Upload to PyPI:

```bash
python -m twine upload dist/*
```

## Usage

```bash
qbit add "Buy milk"
qbit list
qbit done 1
qbit delete 1
qbit clear
```

## Data location

qbit stores data in an OS-specific user data directory:

- Windows: `%APPDATA%/qbit/todos.json`
- macOS: `~/Library/Application Support/qbit/todos.json`
- Linux: `$XDG_DATA_HOME/qbit/todos.json` or `~/.local/share/qbit/todos.json`

You can override the file path with:

```bash
qbit --data-file /path/to/todos.json list
```
