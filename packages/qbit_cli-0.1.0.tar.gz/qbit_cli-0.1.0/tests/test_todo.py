from qbit.todo import TodoItem, TodoList


def test_add_assigns_incrementing_ids():
    todo_list = TodoList()

    one = todo_list.add("one")
    two = todo_list.add("two")

    assert one.id == 1
    assert two.id == 2


def test_mark_done_updates_state():
    todo_list = TodoList([TodoItem(id=7, text="task")])

    item = todo_list.mark_done(7)

    assert item.done is True


def test_delete_removes_item():
    todo_list = TodoList([TodoItem(id=1, text="a"), TodoItem(id=2, text="b")])

    removed = todo_list.delete(1)

    assert removed.id == 1
    assert [item.id for item in todo_list.items()] == [2]


def test_clear_completed_removes_only_done_items():
    todo_list = TodoList(
        [
            TodoItem(id=1, text="a", done=True),
            TodoItem(id=2, text="b", done=False),
            TodoItem(id=3, text="c", done=True),
        ]
    )

    removed = todo_list.clear_completed()

    assert removed == 2
    assert [item.id for item in todo_list.items()] == [2]
