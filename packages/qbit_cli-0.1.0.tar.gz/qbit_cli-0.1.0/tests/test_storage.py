import json

from qbit.storage import TodoStorage
from qbit.todo import TodoItem


def test_load_returns_empty_when_file_missing(tmp_path):
    storage = TodoStorage(tmp_path / "missing.json")

    assert storage.load() == []


def test_save_and_load_round_trip(tmp_path):
    file_path = tmp_path / "todos.json"
    storage = TodoStorage(file_path)

    storage.save([TodoItem(id=1, text="buy milk", done=False, created_at="ts")])

    loaded = storage.load()
    assert len(loaded) == 1
    assert loaded[0].id == 1
    assert loaded[0].text == "buy milk"


def test_save_writes_valid_json(tmp_path):
    file_path = tmp_path / "todos.json"
    storage = TodoStorage(file_path)

    storage.save([TodoItem(id=3, text="x", done=True, created_at="now")])

    parsed = json.loads(file_path.read_text(encoding="utf-8"))
    assert parsed[0]["id"] == 3
