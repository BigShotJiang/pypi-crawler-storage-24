from pathlib import Path

from qbit.cli import main


def test_cli_add_then_list(tmp_path, capsys):
    data_file = tmp_path / "todos.json"

    rc_add = main(["--data-file", str(data_file), "add", "buy milk"])
    out_add = capsys.readouterr().out

    assert rc_add == 0
    assert "Added [1] buy milk" in out_add

    rc_list = main(["--data-file", str(data_file), "list"])
    out_list = capsys.readouterr().out

    assert rc_list == 0
    assert "[1] [ ] buy milk" in out_list


def test_cli_done_missing_id_returns_error(tmp_path, capsys):
    data_file = tmp_path / "todos.json"

    rc = main(["--data-file", str(data_file), "done", "99"])
    out = capsys.readouterr().out

    assert rc == 2
    assert "Error:" in out


def test_cli_clear_completed(tmp_path, capsys):
    data_file = Path(tmp_path) / "todos.json"

    main(["--data-file", str(data_file), "add", "task1"])
    main(["--data-file", str(data_file), "done", "1"])

    rc = main(["--data-file", str(data_file), "clear"])
    out = capsys.readouterr().out

    assert rc == 0
    assert "Removed 1 completed todo(s)" in out
