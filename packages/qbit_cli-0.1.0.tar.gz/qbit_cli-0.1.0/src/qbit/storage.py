"""Persistence layer for todo data."""

from __future__ import annotations

import json
from pathlib import Path

from .todo import TodoItem


class TodoStorage:
    """Reads and writes todos from a JSON file."""

    def __init__(self, data_file: Path) -> None:
        self._data_file = data_file

    def load(self) -> list[TodoItem]:
        if not self._data_file.exists():
            return []

        with self._data_file.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)

        if not isinstance(payload, list):
            raise ValueError("Corrupted data: expected a JSON list.")

        return [TodoItem.from_dict(item) for item in payload]

    def save(self, items: list[TodoItem]) -> None:
        self._data_file.parent.mkdir(parents=True, exist_ok=True)
        temp_file = self._data_file.with_suffix(self._data_file.suffix + ".tmp")

        serialized = [item.to_dict() for item in items]
        with temp_file.open("w", encoding="utf-8") as handle:
            json.dump(serialized, handle, indent=2)
            handle.write("\n")

        temp_file.replace(self._data_file)
