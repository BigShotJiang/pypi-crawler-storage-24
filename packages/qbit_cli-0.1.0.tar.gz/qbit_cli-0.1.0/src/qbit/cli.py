"""Command-line interface for qbit."""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Sequence

from .config import default_data_file
from .storage import TodoStorage
from .todo import TodoList


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="qbit", description="Manage your todos from the CLI")
    parser.add_argument(
        "--data-file",
        type=Path,
        default=None,
        help="Override the default todo data file path.",
    )

    subparsers = parser.add_subparsers(dest="command", required=True)

    add_parser = subparsers.add_parser("add", help="Add a new todo")
    add_parser.add_argument("text", help="Todo text")

    subparsers.add_parser("list", help="List todos")

    done_parser = subparsers.add_parser("done", help="Mark a todo as completed")
    done_parser.add_argument("id", type=int, help="Todo id")

    delete_parser = subparsers.add_parser("delete", help="Delete a todo")
    delete_parser.add_argument("id", type=int, help="Todo id")

    subparsers.add_parser("clear", help="Clear completed todos")

    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    data_file = args.data_file if args.data_file else default_data_file()
    storage = TodoStorage(data_file)

    try:
        todo_list = TodoList(storage.load())
    except ValueError as exc:
        print(f"Error: {exc}")
        return 2

    if args.command == "add":
        try:
            item = todo_list.add(args.text)
        except ValueError as exc:
            print(f"Error: {exc}")
            return 2
        storage.save(todo_list.items())
        print(f"Added [{item.id}] {item.text}")
        return 0

    if args.command == "list":
        items = todo_list.items()
        if not items:
            print("No todos yet.")
            return 0
        for item in items:
            status = "x" if item.done else " "
            print(f"[{item.id}] [{status}] {item.text}")
        return 0

    if args.command == "done":
        try:
            item = todo_list.mark_done(args.id)
        except KeyError as exc:
            print(f"Error: {exc}")
            return 2
        storage.save(todo_list.items())
        print(f"Completed [{item.id}] {item.text}")
        return 0

    if args.command == "delete":
        try:
            item = todo_list.delete(args.id)
        except KeyError as exc:
            print(f"Error: {exc}")
            return 2
        storage.save(todo_list.items())
        print(f"Deleted [{item.id}] {item.text}")
        return 0

    if args.command == "clear":
        removed = todo_list.clear_completed()
        storage.save(todo_list.items())
        print(f"Removed {removed} completed todo(s)")
        return 0

    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
