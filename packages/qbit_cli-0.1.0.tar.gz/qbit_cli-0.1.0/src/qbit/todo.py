"""Core todo domain logic."""

from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timezone


@dataclass
class TodoItem:
    """A single todo item."""

    id: int
    text: str
    done: bool = False
    created_at: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, payload: dict) -> "TodoItem":
        return cls(
            id=int(payload["id"]),
            text=str(payload["text"]),
            done=bool(payload.get("done", False)),
            created_at=str(payload.get("created_at", "")),
        )


class TodoList:
    """Mutable list of todo items with stable integer IDs."""

    def __init__(self, items: list[TodoItem] | None = None) -> None:
        self._items = items[:] if items else []

    def items(self) -> list[TodoItem]:
        return self._items[:]

    def add(self, text: str) -> TodoItem:
        text = text.strip()
        if not text:
            raise ValueError("Todo text cannot be empty.")

        item = TodoItem(
            id=self._next_id(),
            text=text,
            done=False,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._items.append(item)
        return item

    def mark_done(self, item_id: int) -> TodoItem:
        item = self._find(item_id)
        item.done = True
        return item

    def delete(self, item_id: int) -> TodoItem:
        item = self._find(item_id)
        self._items = [existing for existing in self._items if existing.id != item_id]
        return item

    def clear_completed(self) -> int:
        before = len(self._items)
        self._items = [item for item in self._items if not item.done]
        return before - len(self._items)

    def _next_id(self) -> int:
        if not self._items:
            return 1
        return max(item.id for item in self._items) + 1

    def _find(self, item_id: int) -> TodoItem:
        for item in self._items:
            if item.id == item_id:
                return item
        raise KeyError(f"Todo with id {item_id} was not found.")
