"""Configuration and OS-aware path helpers."""

from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "qbit"
DEFAULT_FILE_NAME = "todos.json"


def default_data_file() -> Path:
    """Return the default todo data file path for the current OS."""
    if sys.platform.startswith("win"):
        appdata = os.environ.get("APPDATA")
        base_dir = Path(appdata) if appdata else Path.home() / "AppData" / "Roaming"
        return base_dir / APP_NAME / DEFAULT_FILE_NAME

    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / APP_NAME / DEFAULT_FILE_NAME

    xdg_data_home = os.environ.get("XDG_DATA_HOME")
    base_dir = Path(xdg_data_home) if xdg_data_home else Path.home() / ".local" / "share"
    return base_dir / APP_NAME / DEFAULT_FILE_NAME
