"""
HTTP client for making requests to the RecallrAI API.
"""

import time
from json import JSONDecodeError
from typing import Any, Dict, Iterator, Optional
from httpx import Response, Client, TimeoutException, ConnectError, Limits
from ..exceptions import (
    TimeoutError, 
    ConnectionError,
    ValidationError,
    InternalServerError,
    AuthenticationError,
    RateLimitError,
)

class HTTPClient:
    """HTTP client for making requests to the RecallrAI API."""

    def __init__(
        self,
        api_key: str,
        project_id: str,
        base_url: str,
        timeout: int = 30,
    ):
        """
        Initialize the HTTP client.

        Args:
            api_key: Your RecallrAI API key.
            project_id: Your project ID.
            base_url: The base URL for the RecallrAI API.
            timeout: Request timeout in seconds.
        """

        self.api_key = api_key
        self.project_id = project_id
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        
        # Configure connection limits to handle concurrent requests better
        limits = Limits(
            max_connections=500,
            max_keepalive_connections=100,
        )
        
        self.client = Client(
            timeout=self.timeout,
            limits=limits,
            headers={
                "X-Recallr-Api-Key": self.api_key,
                "X-Recallr-Project-Id": self.project_id,
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "RecallrAI-Python-SDK/0.6.5",
            },
        )
        self._system_prompt_cache: Optional[str] = None
        self._system_prompt_cache_expires_at: float = 0.0

    def get_cached_system_prompt(self) -> str:
        """Fetch the global system prompt, using a 1-hour in-memory cache to
        avoid shipping the ~20 KB prompt on every request."""
        now = time.monotonic()
        if (
            self._system_prompt_cache is not None
            and now < self._system_prompt_cache_expires_at
        ):
            return self._system_prompt_cache  # type: ignore[return-value]
        response = self.get("/api/v1/system-prompt")
        self._system_prompt_cache = response.json()["system_prompt"]
        self._system_prompt_cache_expires_at = now + 3600
        return self._system_prompt_cache  # type: ignore[return-value]

    def request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
    ) -> Response:
        """
        Make a request to the RecallrAI API.

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            path: API endpoint path.
            params: Query parameters.
            data: Request body data.

        Returns:
            The parsed JSON response.
        """
        url = f"{self.base_url}{path}"
        
        # Filter out None values in params and data
        if params:
            params = {k: v for k, v in params.items() if v is not None}
        
        if data:
            data = {k: v for k, v in data.items() if v is not None}
        
        try:
            response = self.client.request(
                method=method,
                url=url,
                params=params,
                json=data,
            )
            
            if response.status_code == 204:
                return response  # No content to parse
            
            elif response.status_code == 422:
                detail = "Validation error"
                raise ValidationError(
                    message=detail,
                    http_status=response.status_code
                )
            elif response.status_code == 500:
                detail = "Internal server error"
                raise InternalServerError(
                    message=detail,
                    http_status=response.status_code
                )
            elif response.status_code == 404 and response.text == "404 page not found":
                detail = "Resource not found"
                raise ConnectionError(
                    message=detail,
                    http_status=response.status_code
                )
            elif response.status_code == 401:
                detail = "Authentication failed"
                raise AuthenticationError(
                    message=detail,
                    http_status=response.status_code
                )
            elif response.status_code == 429:
                detail = "429 Too Many Requests. Please try again in a few moments."
                raise RateLimitError(
                    message=detail,
                    http_status=response.status_code
                )

            # Try to parse to JSON to catch JSON errors early
            _ = response.json()
            
            return response
        except TimeoutException as e:
            raise TimeoutError(
                message=f"Request timed out: {e}",
                http_status=0  # No HTTP status for timeout
            ) from e
        except (ConnectError, JSONDecodeError) as e:
            raise ConnectionError(
                message=f"Failed to connect to the API: {e}",
                http_status=0  # No HTTP status for connection error
            ) from e
        except Exception as e:
            # Handle other exceptions as needed
            raise e

    def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> Response:
        """Make a GET request."""
        return self.request("GET", path, params=params)

    def post(self, path: str, data: Optional[Dict[str, Any]] = None) -> Response:
        """Make a POST request."""
        return self.request("POST", path, data=data)

    def put(self, path: str, data: Optional[Dict[str, Any]] = None) -> Response:
        """Make a PUT request."""
        return self.request("PUT", path, data=data)

    def delete(self, path: str, params: Optional[Dict[str, Any]] = None) -> Response:
        """Make a DELETE request."""
        return self.request("DELETE", path, params=params)

    def stream(self, path: str, params: Optional[Dict[str, Any]] = None) -> Iterator[str]:
        """Stream Server-Sent Events (SSE) from the API.

        Args:
            path: API endpoint path.
            params: Query parameters.

        Yields:
            Raw SSE lines as strings.
        """
        url = f"{self.base_url}{path}"

        if params:
            params = {k: v for k, v in params.items() if v is not None}

        with self.client.stream(
            method="GET",
            url=url,
            params=params,
            headers={"Accept": "text/event-stream"},
        ) as response:
            if response.status_code == 422:
                raise ValidationError(message="Validation error", http_status=response.status_code)
            if response.status_code == 500:
                raise InternalServerError(message="Internal server error", http_status=response.status_code)
            if response.status_code == 404 and response.text == "404 page not found":
                raise ConnectionError(message="Resource not found", http_status=response.status_code)
            if response.status_code == 401:
                raise AuthenticationError(message="Authentication failed", http_status=response.status_code)
            if response.status_code == 429:
                raise RateLimitError(message="Please try again in a few moments.", http_status=response.status_code)

            for line in response.iter_lines():
                if line:
                    yield line
