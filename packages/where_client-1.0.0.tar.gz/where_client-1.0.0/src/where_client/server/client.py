import re
import json
import asyncio

from urllib import parse

import requests

from where_common import cq, define
from . import pack as where

def raise_exception(f):

    def wrapper(*args, **kwargs):
        try:
            res = f(*args, **kwargs)

        except (requests.exceptions.InvalidSchema) as err:
            raise where.UrlException(str(err))

        except (requests.exceptions.ConnectionError) as err:
            raise where.ConnectionException(str(err))

        if where.ServerException.header in res.headers: 
            debug = parse.unquote(res.headers[where.ServerException.header])
            number = res.status_code

            raise where.ServerException(number, debug)

        if where.ServerError.header in res.headers: 
            debug = parse.unquote(res.headers[where.ServerError.header])
            raise where.ServerError(res.json()['error'], debug)

        return res.json()

    return wrapper

class ServerClient:

    def __init__(self, **kwargs):

        self._config = kwargs
        self._headers = {}

        if 'url' not in self._config or re.search(r'^http[s]?://', self._config['url']) is None:
            url = self._config['url']
            raise where.UrlException(f'"{url}" invalid URL' if url is not None else '"url" undefined')

        if 'access_token' in self._config:
            access_token = self._config['access_token']
            self._headers['Authorization'] = f'Bearer {access_token}'

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        return self

    # async def __aenter__(self):
        # return self

    # async def __aexit__(self, exc_type, exc_value, traceback):
        # return self

    def url(self, scope='', path=None):
        url = re.sub('/$', '', self._config['url'])
        path = parse.quote(re.sub('^/(.*)/$', '\\1', path)) if path is not None else ''

        return '/'.join([v for v in (url, scope, path) if v != ''])

    @raise_exception
    def login(self, user, password, passcord=None):

        data = {'user': user, 'password': password, 'passcord': passcord}

        res = requests.post(
                self.url(), headers=self._headers, data=data).json()

        if 'accessToken' in res:
            access_token = res['accessToken']
            self._headers['Authorization'] = f'Bearer {access_token}'

        return {re.sub(r'([A-Z])', '_\\1', k).lower(): v for k, v in res.items()}

    @raise_exception
    def refresh(self, access_token, refresh_token):

        data = {'accessToken': access_token, 'refreshToken': refresh_token}

        res = requests.put(
                self.url(),  headers=self._headers, data=data).json()

        if 'accessToken' in res:
            access_token = res['accessToken']
            self._headers['Authorization'] = f'Bearer {access_token}'

        return {re.sub(r'([A-Z])', '_\\1', k).lower(): v for k, v in res.items()}

    @raise_exception
    def get(self, scope, condition=None):
        cs = cq.string(condition) if type(condition) == dict else condition

        # return requests.get(self.url(scope, cs), headers=self._headers).json()
        return requests.get(self.url(scope, cs), headers=self._headers)

    async def aget(self, scope, condition=None):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.get, scope, condition)

    @raise_exception
    def post(self, scope, data, files=None):

        # todo
        # data ga aruka check suru nakereeeba reigai wo hassei

        # file ga nai baai
        if files is None:
             return requests.post(self.url(scope), headers=self._headers, json=data).json()

        # file ga aru baai
        # files = [('file-name', file), ...]
        data = {define.multipart_formdata_key: json.dumps(data if type(data) == list else [data])}

        files = ([(define.files_key, v) for v in files]
                 if type(files) == list else [(define.files_key, files)])

        return requests.post(
                self.url(scope), headers=self._headers, data=data, files=files).json()

    async def apost(self, scope, data, files=None):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.post, scope, data, files)

    @raise_exception
    def put(self, scope, data, condition, files=None):

        # todo
        # data ga aruka check suru nakereeeba reigai wo hassei

        cs = cq.string(condition) if type(condition) == dict else condition

        # file ga nai baai
        if files is None:
             return requests.put(self.url(scope, cs), headers=self._headers, json=data).json()

        # file ga aru baai
        data = {define.multipart_formdata_key: json.dumps(data if type(data) == list else [data])}

        files = ([(define.files_key, v) for v in files]
                if type(files) == list else [(define.files_key, files)])

        return requests.put(
                self.url(scope, cs),  headers=self._headers, data=data, files=files).json()

    async def aput(self, scope, data, condition, files=None):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.put, scope, data, condition, files)

    @raise_exception
    def delete(self, scope, condition):

        cs = cq.string(condition) if type(condition) == dict else condition

        return requests.delete(
                self.url(scope, cs), headers=self._headers).json()

    async def adelete(self, scope, condition):
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.delete, scope, condition)
