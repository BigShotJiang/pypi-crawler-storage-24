import asyncio
import json
import re
import time
from threading import Timer

from websocket import WebSocket
from websocket._exceptions import WebSocketConnectionClosedException

from where_common import cq, da, common
from . import pack as where

class SocketClient:

    def __init__(self, **kwargs):

        self._config = kwargs
        self._event = {}

        self._sec = 5

        for k, v in ({'origin': None, 'subprotocol': 'echo-protocol', 'reconnect': False}.items()):
            self._config[k] = (self._config[k] if k in self._config else v)

        self._config['loop'] = False

        config = common.util.url.socket.either(self._config)

        if re.search(r'^ws[s]?://', config['url']) is None:
            url = self._config['url']
            raise where.UrlException(f'"{url}" invalid URL')

        self.attribute = {k: v for k, v in config.items() if k != 'url'}
        self._config['url'] = config['url']

        self._connect()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def _connect(self):

        self.connection = WebSocket()

        try:
            self.connection.connect( self._config['url'], origin=self._config['origin'], subprotocols=[self._config['subprotocol']])

        except (ConnectionRefusedError) as err:

            if self._config['reconnect'] is False:
                raise where.ConnectionException('Connection refused.')

            where.log({'error': str(err), 'message': 'Reconnect after 5 seconds.'})
            Timer(self._sec, self._connect).start()

        else:
            if self._config['loop'] is True:
                self.loop()

    def state(self):
        return 1 if self.connection.connected is True else 0

    def on(self, name, cb):
        self._event[name] = cb

    def send(self, data, condition={}):

        if self.state() == 0:
            return

        wco = cq.parse(condition) if type(condition) == str else condition
        wda = da.parse(data)

        self.connection.send(json.dumps({'data': wda, 'condition': wco}))

    def recv(self):
        message = json.loads(self.connection.recv())

        try:
            self._event['message'](message)

        except (KeyError):
            pass

    def loop(self):

        self._config['loop'] = True

        if self.state() == 0:
            return

        while True:
            try:
                self.recv()

            except (WebSocketConnectionClosedException) as err:
                where.log('The connection to the server is disconnected and will reconnect in 5 seconds.')
                Timer(self._sec, self._connect).start()
                break

            except (KeyboardInterrupt) as err:
                break

            time.sleep(1 / 100)

    async def aloop(self):
        loop = asyncio.get_event_loop()
        loop.run_in_executor(None, self.loop())

    def close(self):
        try:
            self._event['close']()

        except (KeyError):
            pass

        self.connection.close()

