import asyncio
import json

from .client import SocketClient

class SocketEmitter:

    def __init__(self, **kwargs):

        self._event_emitter = []
        self._socket = SocketClient(**kwargs)

        self._socket.on('message', self.on_message);

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.close()

    def on_message(self, message):

        data, *rest = message

        try:
            event, args = data['event'], data['args']

        except (KeyError):
            return

        for v in self._event_emitter:
            if v['event'] == event: v['cb'](*args)

        self._event_emitter = [v for v in self._event_emitter
                              if v['event'] != event or v['once'] == False]

    def on(self, event, cb):
        self._event_emitter.append({'event': event, 'cb': cb, 'once': False})

    def once(self, event, cb):
        self._event_emitter.append({'event': event, 'cb': cb, 'once': True})

    def off(self, event, cb):
        self._event_emitter = [v for v in self._event_emitter
                              if v['event'] != event and v['cb'] != cb]

    def emit(self, event, *args):
        data = {'event': event, 'args': args}
        condition = {'where': {'group': self._socket.attribute['group']}}

        self._socket.send(data, condition)

    def loop(self):
        self._socket.loop()

    def close(self):
        self._socket.close()

