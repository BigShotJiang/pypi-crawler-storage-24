import where_common as where

from .server import ServerClient
from .socket import SocketClient, SocketEmitter

class Server:
    def client(self, **kwargs):
        return ServerClient(**kwargs)


class Socket:
    def client(self, **kwargs):
        return SocketClient(**kwargs)

    def emitter(self, **kwargs):
        return SocketEmitter(**kwargs)


class Cq:
    parse = where.cq.parse
    string = where.cq.string


server = Server()
socket = Socket()

cq = Cq()

def client(**kwargs):
    try:
        return ServerClient(**kwargs)

    except (where.UrlException):
        return SocketClient(**kwargs)
