import re
import json
import math

from .common.util.cast import cast
from .define import multipart_formdata_key

def parse(obj, content_type=None):

    # {'k1': ['v1', 'v2'], 'k2': ['v1' , 'v2'], ... }, content_type='multipart/form-data'
    if content_type and 'multipart/form-data' in content_type:

        if multipart_formdata_key in obj:
            data = json.loads(obj[multipart_formdata_key])
            return data if type(obj) == list else [data]

        o = {}

        for k, v in obj.items():
            o = {**o, **{i: {**(o[i] if i in o else {}), k: v}
                         for i, v in enumerate(v if type(v) == list else [v])}}

        return [*o.values()]

    # {'k1': 'v1', ... }
    if type(obj) == dict and len([k for k in  obj.keys() if type(k) == str]):
        return [obj]

    header, *body = obj

    # [['k1', 'k2', ... ], ['v1', 'v2', ... ], ... ]
    if header and type(header) == list:
        return [{header[i]: cast(v) for i, v in enumerate(v)} for v in body]

    # [{'k1': 'v1'}, {'k2': 'v2'}, ...] || {}
    return obj if type(obj) == list else [obj]

def filter():
    # todo
    pass
