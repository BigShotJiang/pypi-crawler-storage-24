import sys
import json
from datetime import datetime

def log(label, indent=False, out='error'):

    console = {'log'  : sys.stdout,
               'info' : sys.stdout,
               'error': sys.stderr}

    module = {'module': label}

    i = 2 if indent is True else None

    def log(o):
        log = {'message': o} if type(o) is str else o
        date = {'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

        print(json.dumps(
            {**date, **module, **log}, indent=i, ensure_ascii=False), file=console[out])

    return log
