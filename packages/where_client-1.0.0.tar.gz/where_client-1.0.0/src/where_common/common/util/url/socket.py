import re
from urllib.parse import urlparse

from ....exception import UrlException, ConnectionException

class Socket:

    # @classmethod
    def _parse(self, string):

        split = [v for v in  urlparse(string).path.split('/') if v != '']

        last_index = len(split) - 1
        user_index = last_index - 1 if ':' in split[-1] else last_index

        app, group, user = reversed(
                [split[user_index - i] for i, v in enumerate(split) if i < 3])

        option = ({} if last_index == user_index
                  else {k: v for k, v in [v.split(':') for v in split[last_index].split(',')]})

        return {'url': string, 'app': app, 'group': group, 'user': user, **option}

    # @classmethod
    def _string(self, obj):

        keys = ['url', 'group', 'user']

        url, group, user = [obj[k] if k in obj else '' for k in keys]

        option = {k: v for k, v in obj.items() if k not in keys}
        option_string = ','.join([f'{k}:{v}' for k, v in option.items()])

        app = ([v for v in urlparse(
                re.sub(r'/?$', '', url)).path.split('/') if v != ''][-1])

        return {'url': '/'.join([url, group, user, option_string]),
                'app': app, 'group': group, 'user': user, **option}

    # @classmethod
    def either(self, config):

        try: 
            return (self._parse(config['url'])
                    if 'group' not in config or 'user' not in config else self._string(config))

        except (KeyError) as err:
            raise UrlException('"url" undefined')

        except (ValueError) as err:
            url = config['url']
            raise UrlException(f'"{url}" invalid URL')

socket = Socket()
