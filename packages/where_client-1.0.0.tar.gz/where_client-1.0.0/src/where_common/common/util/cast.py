import re
import json
from datetime import datetime

def cast(value):
    try:
        return json.loads(value)

    except (json.JSONDecodeError):
        try:
            return datetime.fromisoformat(value)

        except (ValueError):
            pass

    return value
