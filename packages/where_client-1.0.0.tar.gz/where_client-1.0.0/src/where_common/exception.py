from .define import status

class ConnectionException(Exception):
    pass


class UrlException(Exception):
    pass


class ServerException(Exception):

    header = 'X-Where-Server-Exception'

    def __init__(self, message, debug=None):

        try:
            code = {v['number']: v  for k, v in status.items()}[message]

        except (KeyError) as err:
            raise err

        super().__init__(code['message'])

        self.message = code['message']
        self.status = {'code': code}

        self.debug = debug if debug != ''  else None

    def __str__(self):
        return self.status['code']['message']


class ServerError(Exception):

    header = 'X-Where-Server-Error'

    def __init__(self, message, debug=None):

        super().__init__(message)

        self.message = message
        self.debug = debug if debug != ''  else None

    def __str__(self):
        return self.message

