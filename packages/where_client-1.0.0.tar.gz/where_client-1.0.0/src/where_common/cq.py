import re
import itertools

from .common.util.cast import cast

operator = ['=', '!', '<', '>', '<=', '>=', '≦', '≧', '-', '*']

shortcut = {'s': 'select', 'w': 'where',
            'o': 'order' , 'l': 'limit'}

reverse = {v: k for k, v in shortcut.items()}

key = {**shortcut, **{v: v for k, v in shortcut.items()}}

key_or = {k: '|'.join([k, v]) for k, v in shortcut.items()}

# not use
r = {**key_or}

def parse(string, ignore=False):

    def prepare(string, ignore):

        r1 = r'([^/]*["\'].*?["\'][^/]*)|/'
        sp = [v for v in re.split(r1, re.sub(r'^/|/$', '', string.strip())) if v]

        obj = {}

        for i, v in enumerate(sp):

            if i % 2 != 0:
                obj = {**obj, sp[i - 1]: v}
                continue

            if not ignore and v not in key:
                raise Exception(f'{v} is not allowed.')

        return obj

    def split(string):

        r1, r2, r3 = (r'([^:]*?["\'].*?["\'][^:]*)|:',
                      r'([^,]*?["\'].*?["\'][^,]*)|,',
                      r'^["\']|["\']$')

        obj = {}

        for v in [v for v in re.split(r1, string) if v]:
            k, *values = [cast(re.sub(r3, '', v)) for v in re.split(r2, v) if v]
            obj[k] = None if len(values) == 0 else values[0] if len(values) == 1 else values

        return obj

    pre = prepare(string, ignore) if type(string) == str else string
    r1 = r'([^\|]*["\'].*?["\'][^\|]*)|\|'

    obj = {}

    for k, v in pre.items():

        if k not in key:
            continue

        first, *rest = [v for v in re.split(r1, v) if v]
        values = {'or': [split(v) for v in [first, *rest]]} if len(rest) else split(first)

        obj[key[k]] = values

    sl_key = ['select', 'limit']

    select, limit = [obj[k] if k in obj else {} for k in sl_key]
    wo = {k: v for k, v in obj.items() if k not in sl_key}

    sv = itertools.chain.from_iterable(
            [[k] + (v if type(v) == list else [v] if v is not None else [])for k, v in select.items()])

    s = {'select': list(sv)} if len(select) else {}

    lv = list(itertools.chain.from_iterable(
            [[k] + (v if type(v) == list else [v] if v is not None else [])for k, v in limit.items()]))

    # memo parse excception wo hassei saseru 
    l = {'limit': (lv[0], lv[1]) if len(lv) > 1 else (0, lv[0])} if len(limit) else {}

    return {**s, **l, **wo}

def string(obj):

    def join(obj, sep):

        l = []

        for k, v in obj.items():

            if type(v) == list:
                l.append((k, ','.join([str(v) for v in v])))
                continue

            if type(v) == bool:
                l.append((k, str(v).lower()))
                continue

            if v is None:
                l.append((k, 'null'))
                continue

            l.append((k, str(v)))

        return sep.join([','.join(v) for v in l])

    select, where, order, limit = [
            obj[k] if k in obj else None for k in shortcut.values()]

    # s
    s = '/'.join([reverse['select'], ','.join([str(v) for v in select])]) if select is not None else select

    # w, o
    wo = []

    for k, v in {'where': where, 'order': order}.items():

        if v is None:
            wo.append(v)
            continue

        values = '|'.join(  [join(v, ':') for v in v['or']] ) if 'or' in v else join(v, ':')
        wo.append('/'.join([reverse[k], values]))

    w, o = wo

    # l
    lk, lv = limit if type(limit) == tuple else (0, limit)
    l = '/'.join([reverse['limit'], ','.join([str(v) for v in (lk, lv)])]) if limit is not None else limit

    return '/'.join([v for v in [s, w, o, l] if v is not None])
