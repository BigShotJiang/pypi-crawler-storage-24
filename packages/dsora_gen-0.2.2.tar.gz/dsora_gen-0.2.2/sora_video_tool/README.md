# sora_video_tool

Package chính của **dsora-gen**: quản lý Chrome profiles, automation Sora, giao tiếp API và CLI.

---

## Cấu trúc

```
sora_video_tool/
├── cli/                    # CLI (dsg)
│   ├── __init__.py         # Entry: main group, đăng ký lệnh
│   ├── common.py           # Hằng, echo, image_src, ensure_playwright_browsers
│   ├── setup.py            # Lệnh setup
│   ├── run.py              # Lệnh run (ordered / greedy)
│   └── commands.py        # Lệnh check, open, update, help
├── config.py               # Load/save settings (~/.sora-tool/settings.json)
├── constants.py            # APP_DATA_DIR, API_BASE_URL, PRODUCTS_PER_PROFILE, ...
├── profile_manager.py      # Thư mục Chrome profile (~/.sora-tool/profiles/)
├── browser_launcher.py    # Launch Chrome (login / automation với CDP)
├── sora_bot.py             # Logic automation: fill_prompt, upload_image, click_create
├── api_client.py           # get_pending_products, mark_product_done
├── telegram_notifier.py    # Thông báo Telegram
├── session_manager.py      # Session đang chạy (~/.sora-tool/session.json)
└── run_tracker.py          # Lịch sử chạy (run_log)
```

Entry point: `dsg = "sora_video_tool.cli:main"` (trong `pyproject.toml`).

---

## Luồng chạy (ordered mode)

1. **cmd_run** gọi `get_pending_products(username)` → danh sách pending từ API.
2. Phân bổ sản phẩm round-robin cho tất cả profiles → `batches_data`.
3. `create_session(batches_data)` → ghi session.
4. ThreadPoolExecutor: mỗi batch chạy `_process_ordered_batch` (mở Chrome, xử lý từng sản phẩm, gọi API mark done, notify Telegram).
5. Nếu gặp **VideoGenLimitReachedError** (tooltip "out of video gens"): notify, đóng Chrome profile đó, `break`; các profile khác tiếp tục.
6. `mark_session_done()` khi xong.

---

## Development

```bash
# Từ repo (không cài package)
uv run dsg --help
uv run dsg check
```
