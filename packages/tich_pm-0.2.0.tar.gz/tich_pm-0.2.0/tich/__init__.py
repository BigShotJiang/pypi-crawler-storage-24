"""tich-pm — Project management toolkit for AI-agent workflows."""

__version__ = "0.2.0"
