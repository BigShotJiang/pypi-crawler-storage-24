"""tich.cli — Unified CLI entry point.

Usage:
    tich log list [--repo X] [--tier P2] [--status open]
    tich log add --tier P2 --title "..."
    tich log close P2.5 --reason "..."
    tich log show
    tich cap list / add / search / view / summary
    tich dec list / add / search / view / supersede
    tich ctx get / set / clear
    tich rule list / add / enable / disable / remove / view / pick
    tich dash [--tui] [--no-open]
    tich init [--dry-run]
    tich deploy gemini [--dry-run]

SPDX-License-Identifier: MIT
"""

import argparse
import sys

from . import __version__


def main():
    parser = argparse.ArgumentParser(
        prog="tich",
        description="Tich PM — Project management toolkit for AI-agent workflows",
    )
    parser.add_argument("--version", action="version", version=f"tich-pm {__version__}")

    subparsers = parser.add_subparsers(dest="command")

    # ── log ───────────────────────────────
    p_log = subparsers.add_parser("log", help="Backlog management")
    log_sub = p_log.add_subparsers(dest="action")

    p_log_list = log_sub.add_parser("list", help="List backlog items")
    p_log_list.add_argument("--repo")
    p_log_list.add_argument("--tier")
    p_log_list.add_argument("--status", default="open")

    p_log_add = log_sub.add_parser("add", help="Add a backlog item")
    p_log_add.add_argument("--repo")
    p_log_add.add_argument("--tier", required=True,
                           choices=["P0", "P1", "P2", "P3", "P4", "Med", "Low", "Icebox"])
    p_log_add.add_argument("--title", required=True)
    p_log_add.add_argument("--desc", default="")
    p_log_add.add_argument("--cat", default="Uncategorized")
    p_log_add.add_argument("--source")

    p_log_close = log_sub.add_parser("close", help="Close a backlog item")
    p_log_close.add_argument("id")
    p_log_close.add_argument("--reason")

    p_log_view = log_sub.add_parser("view", help="View item details")
    p_log_view.add_argument("id")

    p_log_summary = log_sub.add_parser("summary", help="Show summary")
    p_log_summary.add_argument("--repo")

    log_sub.add_parser("show", help="Open HTML dashboard")

    # ── cap ───────────────────────────────
    p_cap = subparsers.add_parser("cap", help="Capability registry")
    cap_sub = p_cap.add_subparsers(dest="action")

    p_cap_list = cap_sub.add_parser("list", help="List capabilities")
    p_cap_list.add_argument("--repo")
    p_cap_list.add_argument("--cat")
    p_cap_list.add_argument("--status", default="implemented")

    p_cap_add = cap_sub.add_parser("add", help="Register a capability")
    p_cap_add.add_argument("--repo")
    p_cap_add.add_argument("--cat", required=True)
    p_cap_add.add_argument("--name", required=True)
    p_cap_add.add_argument("--entry", default="")
    p_cap_add.add_argument("--docs", default="")
    p_cap_add.add_argument("--since", default="")
    p_cap_add.add_argument("--ref", default="")
    p_cap_add.add_argument("--desc", default="")
    p_cap_add.add_argument("--status", default="implemented",
                           choices=["implemented", "partial", "stub", "deprecated"])

    p_cap_search = cap_sub.add_parser("search", help="Search capabilities")
    p_cap_search.add_argument("query")

    p_cap_view = cap_sub.add_parser("view", help="View capability details")
    p_cap_view.add_argument("id")

    cap_sub.add_parser("summary", help="Show summary").add_argument("--repo", default=None)

    # ── dec ───────────────────────────────
    p_dec = subparsers.add_parser("dec", help="Architecture decision log")
    dec_sub = p_dec.add_subparsers(dest="action")

    p_dec_add = dec_sub.add_parser("add", help="Record a decision")
    p_dec_add.add_argument("--repo")
    p_dec_add.add_argument("--title", required=True)
    p_dec_add.add_argument("--choice", required=True)
    p_dec_add.add_argument("--reason", required=True)
    p_dec_add.add_argument("--alternatives", default="")
    p_dec_add.add_argument("--context", default="")
    p_dec_add.add_argument("--source", default="")

    p_dec_list = dec_sub.add_parser("list", help="List decisions")
    p_dec_list.add_argument("--repo")
    p_dec_list.add_argument("--status", default="all")

    p_dec_view = dec_sub.add_parser("view", help="View decision details")
    p_dec_view.add_argument("id")

    p_dec_search = dec_sub.add_parser("search", help="Search decisions")
    p_dec_search.add_argument("query")

    p_dec_sup = dec_sub.add_parser("supersede", help="Supersede a decision")
    p_dec_sup.add_argument("id")
    p_dec_sup.add_argument("--by", required=True)
    p_dec_sup.add_argument("--reason", default="")

    # ── ctx ───────────────────────────────
    p_ctx = subparsers.add_parser("ctx", help="Context anchors")
    ctx_sub = p_ctx.add_subparsers(dest="action")

    p_ctx_set = ctx_sub.add_parser("set", help="Set context")
    p_ctx_set.add_argument("--repo")
    p_ctx_set.add_argument("--status", required=True)
    p_ctx_set.add_argument("--wip", default="")
    p_ctx_set.add_argument("--last-commit", default="")
    p_ctx_set.add_argument("--blocked", default="")
    p_ctx_set.add_argument("--next", default="")

    p_ctx_get = ctx_sub.add_parser("get", help="Show context")
    p_ctx_get.add_argument("--repo")

    p_ctx_clear = ctx_sub.add_parser("clear", help="Clear context")
    p_ctx_clear.add_argument("--repo")

    # ── dash ──────────────────────────────
    p_dash = subparsers.add_parser("dash", help="Open dashboard")
    p_dash.add_argument("--tui", action="store_true", help="Launch terminal TUI")
    p_dash.add_argument("--no-open", action="store_true", help="Generate HTML without opening")
    p_dash.add_argument("--smoke", action="store_true", help="Smoke test")

    # ── init ──────────────────────────────
    p_init = subparsers.add_parser("init", help="Bootstrap project with JSON files")
    p_init.add_argument("--dry-run", action="store_true")

    # ── rule ──────────────────────────────
    p_rule = subparsers.add_parser("rule", help="Agent governance rules")
    rule_sub = p_rule.add_subparsers(dest="action")

    rule_sub.add_parser("list", help="List all rules")
    rule_sub.add_parser("pick", help="Interactive rule picker")

    p_rule_add = rule_sub.add_parser("add", help="Add a custom rule")
    p_rule_add.add_argument("--id", required=True)
    p_rule_add.add_argument("--title", required=True)
    p_rule_add.add_argument("--trigger", required=True)
    p_rule_add.add_argument("--action", required=True)
    p_rule_add.add_argument("--category", default="custom")

    p_rule_enable = rule_sub.add_parser("enable", help="Enable a rule")
    p_rule_enable.add_argument("id")

    p_rule_disable = rule_sub.add_parser("disable", help="Disable a rule")
    p_rule_disable.add_argument("id")

    p_rule_remove = rule_sub.add_parser("remove", help="Remove a custom rule")
    p_rule_remove.add_argument("id")

    p_rule_view = rule_sub.add_parser("view", help="View rule details")
    p_rule_view.add_argument("id")

    # ── deploy ────────────────────────────
    p_deploy = subparsers.add_parser("deploy", help="Deploy agent rules")
    p_deploy.add_argument("agent", nargs="?", default="gemini",
                          help="Agent to deploy for (gemini, claude, cursor)")
    p_deploy.add_argument("--dry-run", action="store_true")
    p_deploy.add_argument("--list", action="store_true", dest="list_agents",
                          help="List available agents")

    # ── Parse and dispatch ────────────────
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return

    # Log
    if args.command == "log":
        from . import backlog
        if args.action == "list":
            backlog.cmd_list(repo=args.repo, tier=args.tier, status=args.status)
        elif args.action == "add":
            backlog.cmd_add(tier=args.tier, title=args.title, repo=args.repo,
                           desc=args.desc, cat=args.cat, source=args.source)
        elif args.action == "close":
            backlog.cmd_close(args.id, reason=args.reason)
        elif args.action == "view":
            backlog.cmd_view(args.id)
        elif args.action == "summary":
            backlog.cmd_summary(repo=args.repo)
        elif args.action == "show":
            from . import dashboard
            dashboard.generate_html()
        else:
            p_log.print_help()

    # Cap
    elif args.command == "cap":
        from . import capabilities
        if args.action == "list":
            capabilities.cmd_list(repo=args.repo, cat=args.cat, status=args.status)
        elif args.action == "add":
            capabilities.cmd_add(cat=args.cat, name=args.name, repo=args.repo,
                                entry=args.entry, docs=args.docs, since=args.since,
                                ref=args.ref, desc=args.desc, status=args.status)
        elif args.action == "search":
            capabilities.cmd_search(args.query)
        elif args.action == "view":
            capabilities.cmd_view(args.id)
        elif args.action == "summary":
            capabilities.cmd_summary(repo=args.repo)
        else:
            p_cap.print_help()

    # Dec
    elif args.command == "dec":
        from . import decisions
        if args.action == "add":
            decisions.cmd_add(title=args.title, choice=args.choice, reason=args.reason,
                             repo=args.repo, alternatives=args.alternatives,
                             context=args.context, source=args.source)
        elif args.action == "list":
            decisions.cmd_list(repo=args.repo, status=args.status)
        elif args.action == "view":
            decisions.cmd_view(args.id)
        elif args.action == "search":
            decisions.cmd_search(args.query)
        elif args.action == "supersede":
            decisions.cmd_supersede(args.id, by=args.by, reason=args.reason)
        else:
            p_dec.print_help()

    # Ctx
    elif args.command == "ctx":
        from . import context
        if args.action == "set":
            context.cmd_set(status=args.status, repo=args.repo, wip=args.wip,
                           last_commit=getattr(args, "last_commit", ""),
                           blocked=args.blocked, next_step=getattr(args, "next", ""))
        elif args.action == "get":
            context.cmd_get(repo=args.repo)
        elif args.action == "clear":
            context.cmd_clear(repo=args.repo)
        else:
            p_ctx.print_help()

    # Dash
    elif args.command == "dash":
        from . import dashboard
        if args.tui:
            dashboard.run_tui(smoke=args.smoke)
        else:
            dashboard.generate_html(no_open=args.no_open)

    # Init
    elif args.command == "init":
        from .deploy.engine import init_project
        init_project(dry_run=args.dry_run)

    # Rule
    elif args.command == "rule":
        from . import rules
        if args.action == "list":
            rules.cmd_list()
        elif args.action == "add":
            rules.cmd_add(rule_id=args.id, title=args.title,
                         trigger=args.trigger, action=args.action,
                         category=args.category)
        elif args.action == "enable":
            rules.cmd_enable(args.id)
        elif args.action == "disable":
            rules.cmd_disable(args.id)
        elif args.action == "remove":
            rules.cmd_remove(args.id)
        elif args.action == "view":
            rules.cmd_view(args.id)
        elif args.action == "pick":
            rules.cmd_pick()
        else:
            p_rule.print_help()

    # Deploy
    elif args.command == "deploy":
        from .deploy.engine import deploy, list_agents
        if args.list_agents:
            list_agents()
        else:
            deploy(agent=args.agent, dry_run=args.dry_run)


if __name__ == "__main__":
    main()
