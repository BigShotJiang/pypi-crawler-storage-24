"""tich.data — Shared data aggregator for all Tich registries.

Loads and normalises data from:
  backlog.json, capabilities.json, decisions.json, context.json

SPDX-License-Identifier: MIT
"""

import json
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

BACKLOG_FILE = "backlog.json"
CAPS_FILE = "capabilities.json"
DECISIONS_FILE = "decisions.json"
CONTEXT_FILE = "context.json"

TIER_ORDER = {"P0": 0, "P1": 1, "P2": 2, "P3": 3, "P4": 4, "Med": 5, "Low": 6, "Icebox": 7}
ALL_TIERS = list(TIER_ORDER.keys())


def find_root() -> Path:
    """Find the project root.

    Resolution: TLOG_BACKLOG env → .gitmodules + backlog.json
    → backlog.json → .git → script parent.
    """
    env_path = os.environ.get("TLOG_BACKLOG")
    if env_path:
        return Path(env_path).parent.absolute()

    curr = Path(os.getcwd()).absolute()
    ancestors = [curr] + list(curr.parents)

    for parent in ancestors:
        if (parent / ".gitmodules").exists() and (parent / BACKLOG_FILE).exists():
            return parent

    for parent in ancestors:
        if (parent / BACKLOG_FILE).exists():
            return parent

    for parent in ancestors:
        if (parent / ".git").exists():
            return parent

    return curr


def _load_json(filename: str) -> Dict[str, Any]:
    path = find_root() / filename
    if not path.exists():
        return {}
    with open(path, "r") as f:
        return json.load(f)


def load_backlog() -> Dict[str, Any]:
    return _load_json(BACKLOG_FILE)


def load_capabilities() -> Dict[str, Any]:
    return _load_json(CAPS_FILE)


def load_decisions() -> Dict[str, Any]:
    return _load_json(DECISIONS_FILE)


def load_context() -> Dict[str, Any]:
    return _load_json(CONTEXT_FILE)


def load_all() -> Dict[str, Any]:
    """Load all four registries into a single dict."""
    return {
        "backlog": load_backlog(),
        "capabilities": load_capabilities(),
        "decisions": load_decisions(),
        "context": load_context(),
    }


def save_json(filename: str, data: Dict[str, Any]):
    """Save data to a JSON file at the project root."""
    path = find_root() / filename
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def backlog_items(data: Optional[Dict] = None, repo: Optional[str] = None,
                  status: str = "all") -> List[Dict]:
    bl = data or load_backlog()
    items = []
    for r_name, r_data in bl.items():
        if repo and r_name != repo:
            continue
        for item in r_data.get("items", []):
            if status != "all" and item.get("status") != status:
                continue
            items.append({**item, "_repo": r_name})
    items.sort(key=lambda x: (x["_repo"], TIER_ORDER.get(x.get("tier", ""), 99), x.get("id", "")))
    return items


def capability_items(data: Optional[Dict] = None, repo: Optional[str] = None) -> List[Dict]:
    caps = data or load_capabilities()
    items = []
    for r_name, r_data in caps.items():
        if repo and r_name != repo:
            continue
        for item in r_data.get("items", []):
            items.append({**item, "_repo": r_name})
    items.sort(key=lambda x: (x["_repo"], x.get("category", ""), x.get("id", "")))
    return items


def decision_items(data: Optional[Dict] = None, repo: Optional[str] = None) -> List[Dict]:
    dec = data or load_decisions()
    items = []
    for r_name, r_data in dec.items():
        if repo and r_name != repo:
            continue
        for item in r_data.get("items", []):
            items.append({**item, "_repo": r_name})
    items.sort(key=lambda x: (x["_repo"], x.get("id", "")))
    return items


def backlog_stats(data: Optional[Dict] = None) -> Dict[str, Dict[str, Dict[str, int]]]:
    """Returns {repo: {tier: {open: N, done: N}}}."""
    bl = data or load_backlog()
    stats: Dict[str, Dict[str, Dict[str, int]]] = {}
    for r_name, r_data in bl.items():
        stats[r_name] = {}
        for tier in ALL_TIERS:
            stats[r_name][tier] = {"open": 0, "done": 0}
        for item in r_data.get("items", []):
            tier = item.get("tier", "P2")
            if tier not in stats[r_name]:
                stats[r_name][tier] = {"open": 0, "done": 0}
            bucket = "done" if item.get("status") == "done" else "open"
            stats[r_name][tier][bucket] += 1
    return stats


def repo_names(data: Optional[Dict] = None) -> List[str]:
    all_data = data or load_all()
    names = set()
    for registry in all_data.values():
        if isinstance(registry, dict):
            names.update(registry.keys())
    return sorted(names)


def auto_repo() -> str:
    """Infer repo name from CWD relative to root."""
    root = find_root()
    cwd = Path(os.getcwd()).absolute()
    try:
        rel = cwd.relative_to(root)
        parts = rel.parts
        if parts:
            candidate = parts[0]
        else:
            candidate = root.name
    except ValueError:
        candidate = root.name

    data_path = root / BACKLOG_FILE
    if data_path.exists():
        try:
            with open(data_path, "r") as f:
                data = json.load(f)
            if candidate in data:
                return candidate
            if root.name in data:
                return root.name
        except (json.JSONDecodeError, OSError):
            pass
    return candidate
