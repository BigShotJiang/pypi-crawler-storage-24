"""tich.context — Context anchors (set, get, clear).

SPDX-License-Identifier: MIT
"""

from datetime import datetime
from typing import Optional

from . import data as D

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
MAGENTA = "\033[95m"

REPO_COLORS = {
    "logic-trace": "\033[96m", "routertl": "\033[93m",
    "rigtichweb": "\033[95m", "deepskopion": "\033[92m",
    "amd_scraper": "\033[94m",
}


def _color_repo(r):
    return REPO_COLORS.get(r, "\033[37m") + r + RESET


def cmd_set(status: str, repo: Optional[str] = None, wip: str = "",
            last_commit: str = "", blocked: str = "", next_step: str = ""):
    repo = repo or D.auto_repo()
    ctx = D.load_context()
    entry = ctx.get(repo, {})
    entry["status"] = status
    entry["updated_at"] = datetime.now().strftime("%Y-%m-%dT%H:%M")
    if wip:
        entry["wip"] = wip
    if last_commit:
        entry["last_commit"] = last_commit
    if blocked:
        entry["blocked_on"] = blocked
    if next_step:
        entry["next"] = next_step
    ctx[repo] = entry
    D.save_json(D.CONTEXT_FILE, ctx)
    print(f"{BOLD}Updated context for {_color_repo(repo)}{RESET}")


def cmd_get(repo: Optional[str] = None):
    ctx = D.load_context()
    if repo:
        repos = {repo: ctx.get(repo)}
        if not repos[repo]:
            print(f"{DIM}No context set for {repo}.{RESET}")
            return
    else:
        repos = ctx

    if not repos:
        print(f"{DIM}No context anchors set. Use 'tich ctx set' to create one.{RESET}")
        return

    print(f"\n{BOLD}Context Anchors{RESET}")
    print(f"{DIM}{'═'*70}{RESET}")

    for rn, c in sorted(repos.items()):
        if not c:
            continue
        print(f"\n  {BOLD}{_color_repo(rn)}{RESET}  {DIM}(updated {c.get('updated_at', '?')}){RESET}")
        print(f"  {BOLD}Status:{RESET}  {c.get('status', 'N/A')}")
        if c.get("wip"):
            print(f"  {BOLD}WIP:{RESET}     {YELLOW}{c['wip']}{RESET}")
        if c.get("last_commit"):
            print(f"  {BOLD}Last:{RESET}    {DIM}{c['last_commit']}{RESET}")
        if c.get("next"):
            print(f"  {BOLD}Next:{RESET}    {CYAN}{c['next']}{RESET}")
        if c.get("blocked_on"):
            print(f"  {BOLD}Blocked:{RESET} {MAGENTA}{c['blocked_on']}{RESET}")

    print(f"\n{DIM}{'═'*70}{RESET}\n")


def cmd_clear(repo: Optional[str] = None):
    repo = repo or D.auto_repo()
    ctx = D.load_context()
    if repo in ctx:
        del ctx[repo]
        D.save_json(D.CONTEXT_FILE, ctx)
        print(f"{BOLD}Cleared context for {repo}.{RESET}")
    else:
        print(f"{DIM}No context found for {repo}.{RESET}")
