"""tich.deploy — Agent rule injection engine.

SPDX-License-Identifier: MIT
"""
