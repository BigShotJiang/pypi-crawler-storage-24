"""tich.decisions — Architecture decision log (add, list, search, view, supersede).

SPDX-License-Identifier: MIT
"""

import re
from datetime import datetime
from typing import Optional

from . import data as D

RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[96m"
YELLOW = "\033[93m"
GREEN = "\033[92m"
STATUS_EMOJI = {"active": "✅", "superseded": "🔄", "deprecated": "🚫"}


def _ansi_len(s):
    return len(re.sub(r'\033\[[0-9;]*m', '', s))


def _pad(s, w):
    return s + " " * max(0, w - _ansi_len(s))


def _trunc(s, w):
    return s[:w-1] + "…" if len(s) > w else s


def cmd_add(title: str, choice: str, reason: str, repo: Optional[str] = None,
            alternatives: str = "", context: str = "", source: str = ""):
    repo = repo or D.auto_repo()
    dec = D.load_decisions()
    if repo not in dec:
        dec[repo] = {"items": []}
    nums = [int(m.group(1)) for i in dec[repo]["items"] if (m := re.match(r"D\.(\d+)", i["id"]))]
    new_id = f"D.{max(nums, default=0) + 1}"
    item = {
        "id": new_id, "title": title, "choice": choice, "reason": reason,
        "alternatives": alternatives, "context": context, "source": source,
        "status": "active",
        "created_at": datetime.now().strftime("%Y-%m-%d"),
        "updated_at": datetime.now().strftime("%Y-%m-%d"),
    }
    dec[repo]["items"].append(item)
    D.save_json(D.DECISIONS_FILE, dec)
    print(f"{BOLD}Recorded {new_id} in {repo}: {title}{RESET}")


def cmd_list(repo: Optional[str] = None, status: str = "all"):
    repo = repo or D.auto_repo()
    items = D.decision_items(repo=repo)
    if status != "all":
        items = [i for i in items if i.get("status") == status]
    if not items:
        print(f"{DIM}No decisions found matching criteria.{RESET}")
        return

    print(f"\n{BOLD}{'ID':<6} {'S':<3} {'Repo':<14} {'Title':<30} {'Choice'}{RESET}")
    print(f"{DIM}{'─'*90}{RESET}")
    for item in items:
        se = STATUS_EMOJI.get(item.get("status"), "?")
        rl = f"{DIM}{item['_repo']}{RESET}"
        print(f"{BOLD}{item['id']:<6}{RESET} {se}  {_pad(rl, 14)} {_trunc(item.get('title',''), 30):<30} {CYAN}{_trunc(item.get('choice',''), 30)}{RESET}")
    print(f"\n{DIM}{len(items)} decision(s){RESET}\n")


def cmd_view(dec_id: str):
    dec = D.load_decisions()
    item = repo = None
    for r, rd in dec.items():
        for i in rd.get("items", []):
            if i["id"] == dec_id:
                item, repo = i, r
                break
        if item:
            break
    if not item:
        print(f"Error: Decision '{dec_id}' not found.")
        return

    se = STATUS_EMOJI.get(item.get("status"), "?")
    print(f"\n{BOLD}Decision: {item['id']}{RESET}")
    print(f"{DIM}{'═'*60}{RESET}")
    print(f"{BOLD}Repo:         {RESET}{repo}")
    print(f"{BOLD}Title:        {RESET}{item['title']}")
    print(f"{BOLD}Status:       {RESET}{se}  {item['status'].upper()}")
    print(f"{BOLD}Choice:       {RESET}{CYAN}{item['choice']}{RESET}")
    print(f"{BOLD}Source:       {RESET}{item.get('source') or 'N/A'}")
    print(f"\n{BOLD}Reason:{RESET}")
    print(f"  {GREEN}{item['reason']}{RESET}")
    if item.get("alternatives"):
        print(f"\n{BOLD}Rejected Alternatives:{RESET}")
        print(f"  {YELLOW}{item['alternatives']}{RESET}")
    if item.get("context"):
        print(f"\n{BOLD}Context:{RESET}")
        print(f"  {DIM}{item['context']}{RESET}")
    print(f"{DIM}{'═'*60}{RESET}\n")


def cmd_search(query: str):
    items = D.decision_items()
    q = query.lower()
    hits = [i for i in items if q in " ".join(str(v) for v in i.values()).lower()]
    if not hits:
        print(f"{DIM}No decisions matching '{query}'.{RESET}")
        return

    print(f"\n{BOLD}Search results for '{query}'{RESET}")
    print(f"{DIM}{'─'*90}{RESET}")
    for item in hits:
        se = STATUS_EMOJI.get(item.get("status"), "?")
        rl = f"{DIM}{item['_repo']}{RESET}"
        print(f"{BOLD}{item['id']:<6}{RESET} {se}  {_pad(rl, 14)} {_trunc(item.get('title',''), 30):<30} {CYAN}{_trunc(item.get('choice',''), 30)}{RESET}")
    print(f"\n{DIM}{len(hits)} hit(s){RESET}\n")


def cmd_supersede(dec_id: str, by: str, reason: str = ""):
    dec = D.load_decisions()
    for r, rd in dec.items():
        for item in rd.get("items", []):
            if item["id"] == dec_id:
                item["status"] = "superseded"
                item["context"] = (item.get("context", "") + f"\nSuperseded by {by}: {reason}").strip()
                item["updated_at"] = datetime.now().strftime("%Y-%m-%d")
                D.save_json(D.DECISIONS_FILE, dec)
                print(f"{BOLD}Marked {dec_id} as superseded by {by}.{RESET}")
                return
    print(f"Error: Decision {dec_id} not found.")
