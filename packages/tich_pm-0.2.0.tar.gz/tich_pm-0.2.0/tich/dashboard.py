"""tich.dashboard — HTML + TUI unified dashboard.

Generates a self-contained HTML page or launches a Textual TUI.

SPDX-License-Identifier: MIT
"""

import html as html_mod
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Optional

from . import data as D

# ── Colour maps ──────────────────────────────────────────────

TIER_HEX = {
    "P0": "#ef4444", "P1": "#f97316", "P2": "#eab308",
    "P3": "#3b82f6", "P4": "#a855f7",
    "Med": "#eab308", "Low": "#22c55e", "Icebox": "#71717a",
}
CAT_HEX = {
    "CLI": "#22d3ee", "Simulation": "#eab308", "Synthesis": "#ef4444",
    "Build": "#f97316", "API": "#a855f7", "IP": "#22c55e",
    "Verification": "#3b82f6", "Docker": "#2dd4bf", "Workspace": "#ca8a04",
    "UI": "#c084fc", "RTL": "#f87171", "Rendering": "#fbbf24",
    "Scraping": "#67e8f9", "RAG": "#c4b5fd", "Infra": "#a1a1aa",
    "Tool": "#e5e5e5",
}
REPO_HEX = {
    "routertl": "#eab308", "logic-trace": "#22d3ee",
    "rigtichweb": "#a855f7", "deepskopion": "#22c55e",
    "amd_scraper": "#3b82f6", "tich-super": "#f97316",
    "routertl-internal": "#f59e0b",
}
S_EMOJI = {"open": "⭕", "done": "✅", "archived": "📁"}
CAP_E = {"implemented": "✅", "partial": "🔶", "stub": "⬜", "deprecated": "🚫"}
DEC_E = {"active": "✅", "superseded": "🔄", "deprecated": "🚫"}

_e = lambda t: html_mod.escape(str(t or ""))
_rc = lambda r: REPO_HEX.get(r, "#a1a1aa")


def generate_html(no_open: bool = False):
    """Generate a self-contained HTML dashboard."""
    ad = D.load_all()
    bs = D.backlog_stats(ad["backlog"])
    bi = D.backlog_items(ad["backlog"])
    ci = D.capability_items(ad["capabilities"])
    di = D.decision_items(ad["decisions"])
    ctx = ad["context"]
    repos = D.repo_names(ad)
    now = datetime.now().strftime("%Y-%m-%d %H:%M")

    # Backlog cards
    bc = ""
    for repo in sorted(bs.keys()):
        tiers = bs[repo]
        to = sum(v["open"] for v in tiers.values())
        td = sum(v["done"] for v in tiers.values())
        tt = to + td
        pct = int(td / tt * 100) if tt else 0
        pills = ""
        for tier in D.ALL_TIERS:
            c = tiers.get(tier, {})
            o, d = c.get("open", 0), c.get("done", 0)
            if o + d == 0: continue
            cl = TIER_HEX.get(tier, "#71717a")
            pills += f'<span class="tp" style="background:{cl}20;color:{cl};border:1px solid {cl}40">{tier} <b>{o}</b></span> '
        bc += f'''<div class="card"><div class="ch"><span class="rd" style="background:{_rc(repo)}"></span><span class="rn">{_e(repo)}</span><span class="cc">{to} open / {td} done</span></div><div class="pb"><div class="pf" style="width:{pct}%;background:{_rc(repo)}"></div></div><div class="tps">{pills}</div></div>'''

    # Backlog rows
    br = ""
    for i in bi:
        t = i.get("tier", "?"); tc = TIER_HEX.get(t, "#71717a"); se = S_EMOJI.get(i.get("status", ""), "?")
        br += f'<tr><td><code>{_e(i.get("id",""))}</code></td><td><span class="tb" style="background:{tc}20;color:{tc}">{t}</span></td><td>{se}</td><td><span style="color:{_rc(i["_repo"])}">{_e(i["_repo"])}</span></td><td>{_e(i.get("title",""))}</td></tr>'

    # Cap rows
    cr = ""
    for i in ci:
        cat = i.get("category", "?"); cc = CAT_HEX.get(cat, "#a1a1aa"); se = CAP_E.get(i.get("status", ""), "?")
        cr += f'<tr><td><code>{_e(i.get("id",""))}</code></td><td><span class="cb" style="background:{cc}20;color:{cc}">{_e(cat)}</span></td><td>{se}</td><td><span style="color:{_rc(i["_repo"])}">{_e(i["_repo"])}</span></td><td>{_e(i.get("name",""))}</td></tr>'

    # Dec rows
    dr = ""
    for i in di:
        se = DEC_E.get(i.get("status", ""), "?")
        dr += f'<tr><td><code>{_e(i.get("id",""))}</code></td><td>{se}</td><td><span style="color:{_rc(i["_repo"])}">{_e(i["_repo"])}</span></td><td>{_e(i.get("title",""))}</td><td class="choice">{_e(i.get("choice",""))}</td></tr>'

    # Context cards
    ctxc = ""
    for rn in sorted(ctx.keys()):
        c = ctx[rn]
        if not c: continue
        fields = ""
        if c.get("status"): fields += f'<div class="cf"><span class="cl">Status</span> {_e(c["status"])}</div>'
        if c.get("wip"): fields += f'<div class="cf"><span class="cl">WIP</span> <span class="cw">{_e(c["wip"])}</span></div>'
        if c.get("next"): fields += f'<div class="cf"><span class="cl">Next</span> <span class="cn">{_e(c["next"])}</span></div>'
        if c.get("blocked_on"): fields += f'<div class="cf"><span class="cl">Blocked</span> <span class="cbl">{_e(c["blocked_on"])}</span></div>'
        ctxc += f'<div class="card ctx"><div class="ch"><span class="rd" style="background:{_rc(rn)}"></span><span class="rn">{_e(rn)}</span><span class="cu">{_e(c.get("updated_at","?"))}</span></div>{fields}</div>'

    tbo = sum(1 for i in bi if i.get("status") == "open")
    tbd = sum(1 for i in bi if i.get("status") != "open")

    page = _HTML_TEMPLATE.format(
        now=now, n_repos=len(repos), n_bl=len(bi),
        tbo=tbo, tbd=tbd, n_cap=len(ci), n_dec=len(di),
        bc=bc, br=br, cr=cr, dr=dr, ctxc=ctxc,
    )

    out_path = D.find_root() / ".dashboard.html"
    out_path.write_text(page, encoding="utf-8")
    print(f"Dashboard generated: {out_path}")

    if not no_open:
        webbrowser.open(f"file://{out_path}")
        print("Opened in browser.")


# ── TUI ──────────────────────────────────────────────────────

def run_tui(smoke: bool = False):
    """Launch the interactive Textual TUI."""
    try:
        from textual.app import App, ComposeResult
        from textual.widgets import Header, Footer, DataTable, TabbedContent, TabPane, Static, Input
        from textual.binding import Binding
        from textual import on
    except ImportError:
        print("Error: textual is not installed. Run: pip install tich-pm")
        raise SystemExit(1)

    ad = D.load_all()
    bl_items = D.backlog_items(ad["backlog"])
    cap_items = D.capability_items(ad["capabilities"])
    dec_items = D.decision_items(ad["decisions"])
    ctx_data = ad["context"]
    stats = D.backlog_stats(ad["backlog"])

    TE = {"P0":"🔴","P1":"🟠","P2":"🟡","P3":"🔵","P4":"🟣","Med":"🟡","Low":"🟢","Icebox":"⚪"}
    SD = {"open":"⭕ Open","done":"✅ Done","archived":"📁 Archived"}
    CS = {"implemented":"✅","partial":"🔶","stub":"⬜","deprecated":"🚫"}
    DS = {"active":"✅","superseded":"🔄","deprecated":"🚫"}

    class TichDashboard(App):
        CSS = """
        Screen { background: #09090b; }
        Header { background: #18181b; color: #22d3ee; }
        Footer { background: #18181b; }
        TabbedContent { background: #09090b; }
        TabPane { background: #09090b; padding: 1; }
        DataTable { background: #0a0a0c; height: 1fr; }
        DataTable > .datatable--header { background: #18181b; color: #a1a1aa; }
        DataTable > .datatable--cursor { background: #27272a; color: #e4e4e7; }
        DataTable > .datatable--hover { background: #1a1a1e; }
        .ctx-panel { background: #18181b; border: solid #27272a; padding: 1 2; margin: 0 0 1 0; height: auto; }
        .search-input { dock: top; margin: 0 0 1 0; background: #18181b; border: solid #27272a; height: 3; }
        .search-input:focus { border: solid #22d3ee; }
        .summary-panel { background: #18181b; border: solid #27272a; padding: 1 2; margin: 0 0 1 0; height: auto; }
        """
        TITLE = "Tich Mission Control"
        SUB_TITLE = "Backlog · Capabilities · Decisions · Context"
        BINDINGS = [Binding("q","quit","Quit"), Binding("slash","focus_search","Search",key_display="/"), Binding("escape","clear_search","Clear")]

        def compose(self) -> ComposeResult:
            yield Header()
            with TabbedContent("Backlog","Capabilities","Decisions","Context"):
                with TabPane("Backlog", id="bl-tab"):
                    yield self._summary()
                    yield Input(placeholder="Type to filter backlog…", classes="search-input", id="bl-search")
                    yield DataTable(id="bl-table")
                with TabPane("Capabilities", id="cap-tab"):
                    yield Input(placeholder="Type to filter capabilities…", classes="search-input", id="cap-search")
                    yield DataTable(id="cap-table")
                with TabPane("Decisions", id="dec-tab"):
                    yield Input(placeholder="Type to filter decisions…", classes="search-input", id="dec-search")
                    yield DataTable(id="dec-table")
                with TabPane("Context", id="ctx-tab"):
                    for rn in sorted(ctx_data.keys()):
                        c = ctx_data[rn]
                        if not c: continue
                        lines = f"[bold cyan]{rn}[/]"
                        if c.get("status"): lines += f"\n  Status:  {c['status']}"
                        if c.get("wip"): lines += f"\n  WIP:     [yellow]{c['wip']}[/]"
                        if c.get("next"): lines += f"\n  Next:    [cyan]{c['next']}[/]"
                        if c.get("blocked_on"): lines += f"\n  Blocked: [red]{c['blocked_on']}[/]"
                        if c.get("updated_at"): lines += f"\n  Updated: [dim]{c['updated_at']}[/]"
                        yield Static(lines, classes="ctx-panel")
            yield Footer()

        def _summary(self) -> Static:
            lines = []
            for repo in sorted(stats.keys()):
                tiers = stats[repo]
                to = sum(v["open"] for v in tiers.values())
                td = sum(v["done"] for v in tiers.values())
                tt = to + td
                if tt == 0: continue
                bl = 20; dl = int(td/tt*bl) if tt else 0
                bar = "█"*dl + "░"*(bl-dl)
                pct = int(td/tt*100) if tt else 0
                tp = " ".join(f"{TE.get(t,'?')}{t}:{tiers.get(t,{}).get('open',0)}" for t in D.ALL_TIERS if tiers.get(t,{}).get("open",0)>0) or "all done"
                lines.append(f"  [bold]{repo:16s}[/] {bar} {pct:3d}% ({to} open / {td} done)  {tp}")
            return Static("\n".join(lines) if lines else "  No backlog data.", classes="summary-panel")

        def on_mount(self):
            bl = self.query_one("#bl-table", DataTable)
            bl.add_columns("ID","Tier","Status","Repo","Title")
            for i in bl_items: bl.add_row(i.get("id",""), f"{TE.get(i.get('tier','?'),'?')} {i.get('tier','?')}", SD.get(i.get("status",""),i.get("status","?")), i.get("_repo",""), i.get("title",""))

            ct = self.query_one("#cap-table", DataTable)
            ct.add_columns("ID","Category","Status","Repo","Name")
            for i in cap_items: ct.add_row(i.get("id",""), i.get("category",""), f"{CS.get(i.get('status',''),'?')} {i.get('status','')}", i.get("_repo",""), i.get("name",""))

            dt = self.query_one("#dec-table", DataTable)
            dt.add_columns("ID","Status","Repo","Title","Choice")
            for i in dec_items: dt.add_row(i.get("id",""), f"{DS.get(i.get('status',''),'?')} {i.get('status','')}", i.get("_repo",""), i.get("title",""), i.get("choice",""))

        @on(Input.Changed)
        def _filter(self, event: Input.Changed):
            q = event.value.lower()
            tmap = {"bl-search":("bl-table",bl_items), "cap-search":("cap-table",cap_items), "dec-search":("dec-table",dec_items)}
            entry = tmap.get(event.input.id)
            if not entry: return
            tid, src = entry
            tbl = self.query_one(f"#{tid}", DataTable)
            tbl.clear()
            for i in src:
                if q and q not in " ".join(str(v) for v in i.values()).lower(): continue
                if tid == "bl-table": tbl.add_row(i.get("id",""), f"{TE.get(i.get('tier','?'),'?')} {i.get('tier','?')}", SD.get(i.get("status",""),i.get("status","?")), i.get("_repo",""), i.get("title",""))
                elif tid == "cap-table": tbl.add_row(i.get("id",""), i.get("category",""), f"{CS.get(i.get('status',''),'?')} {i.get('status','')}", i.get("_repo",""), i.get("name",""))
                else: tbl.add_row(i.get("id",""), f"{DS.get(i.get('status',''),'?')} {i.get('status','')}", i.get("_repo",""), i.get("title",""), i.get("choice",""))

        def action_focus_search(self):
            for sid in ("bl-search","cap-search","dec-search"):
                try:
                    inp = self.query_one(f"#{sid}", Input)
                    if inp.display: inp.focus(); return
                except: continue

        def action_clear_search(self):
            for sid in ("bl-search","cap-search","dec-search"):
                try: self.query_one(f"#{sid}", Input).value = ""
                except: continue

    if smoke:
        app = TichDashboard()
        print(f"TUI smoke test: OK. {len(bl_items)} backlog, {len(cap_items)} caps, {len(dec_items)} decisions")
        print("Smoke test PASSED ✅")
        return

    TichDashboard().run()


# ── HTML Template ────────────────────────────────────────────
# Kept as a module-level string to keep generate_html() readable.

_HTML_TEMPLATE = '''<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Tich Mission Control</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
  *,*::before,*::after{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Inter',system-ui,sans-serif;background:#09090b;color:#e4e4e7;line-height:1.6;min-height:100vh}}
  .header{{background:linear-gradient(135deg,#18181b,#09090b);border-bottom:1px solid #27272a;padding:1.5rem 2rem;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:100;backdrop-filter:blur(12px)}}
  .header h1{{font-size:1.5rem;font-weight:700;background:linear-gradient(135deg,#22d3ee,#a855f7);-webkit-background-clip:text;-webkit-text-fill-color:transparent;letter-spacing:-0.02em}}
  .hm{{color:#71717a;font-size:.8rem;font-family:'JetBrains Mono',monospace}}
  .sb{{display:flex;gap:1.5rem;padding:1rem 2rem;border-bottom:1px solid #27272a;background:#0a0a0c}}
  .sc{{display:flex;align-items:center;gap:.5rem;padding:.5rem 1rem;background:#18181b;border:1px solid #27272a;border-radius:8px;font-size:.85rem}}
  .sc .n{{font-weight:700;font-size:1.2rem;font-family:'JetBrains Mono',monospace}}
  .tabs{{display:flex;padding:0 2rem;border-bottom:1px solid #27272a;background:#0a0a0c}}
  .tab{{padding:.75rem 1.25rem;cursor:pointer;color:#71717a;font-weight:500;font-size:.9rem;border-bottom:2px solid transparent;transition:all .2s;user-select:none}}
  .tab:hover{{color:#a1a1aa}}.tab.active{{color:#e4e4e7;border-bottom-color:#22d3ee}}
  .content{{padding:1.5rem 2rem}}
  .tp-panel{{display:none;animation:fi .3s ease}}.tp-panel.active{{display:block}}
  @keyframes fi{{from{{opacity:0;transform:translateY(8px)}}to{{opacity:1;transform:translateY(0)}}}}
  .st{{font-weight:600;color:#a1a1aa;margin-bottom:1rem;text-transform:uppercase;letter-spacing:.05em;font-size:.75rem}}
  .cg{{display:grid;grid-template-columns:repeat(auto-fill,minmax(340px,1fr));gap:1rem;margin-bottom:2rem}}
  .card{{background:#18181b;border:1px solid #27272a;border-radius:12px;padding:1rem 1.25rem;transition:border-color .2s,box-shadow .2s}}
  .card:hover{{border-color:#3f3f46;box-shadow:0 4px 24px rgba(0,0,0,.3)}}
  .ch{{display:flex;align-items:center;gap:.5rem;margin-bottom:.75rem}}
  .rd{{width:10px;height:10px;border-radius:50%;flex-shrink:0}}
  .rn{{font-weight:600;font-size:.95rem}}
  .cc{{margin-left:auto;color:#71717a;font-size:.8rem;font-family:'JetBrains Mono',monospace}}
  .pb{{height:6px;background:#27272a;border-radius:3px;overflow:hidden;margin-bottom:.75rem}}
  .pf{{height:100%;border-radius:3px;transition:width .6s ease}}
  .tps{{display:flex;flex-wrap:wrap;gap:.35rem}}
  .tp{{font-size:.7rem;font-weight:600;padding:.15rem .5rem;border-radius:4px;font-family:'JetBrains Mono',monospace}}
  .dt{{width:100%;border-collapse:collapse;font-size:.85rem}}
  .dt th{{text-align:left;padding:.6rem .75rem;color:#71717a;font-weight:500;font-size:.75rem;text-transform:uppercase;letter-spacing:.05em;border-bottom:1px solid #27272a;position:sticky;top:0;background:#09090b;cursor:pointer}}
  .dt th:hover{{color:#a1a1aa}}
  .dt td{{padding:.5rem .75rem;border-bottom:1px solid #18181b;vertical-align:top}}
  .dt tr:hover td{{background:#18181b}}
  .dt code{{font-family:'JetBrains Mono',monospace;font-size:.8rem;color:#22d3ee}}
  .tb,.cb{{display:inline-block;font-size:.7rem;font-weight:600;padding:.1rem .45rem;border-radius:4px;font-family:'JetBrains Mono',monospace}}
  .choice{{color:#22d3ee}}
  .fb{{display:flex;gap:.75rem;margin-bottom:1rem;flex-wrap:wrap;align-items:center}}
  .fb input{{background:#18181b;border:1px solid #27272a;border-radius:8px;padding:.45rem .75rem;color:#e4e4e7;font-family:'Inter',sans-serif;font-size:.85rem;outline:none;transition:border-color .2s;min-width:250px}}
  .fb input:focus{{border-color:#22d3ee}}.fb input::placeholder{{color:#52525b}}
  .fbtn{{background:#18181b;border:1px solid #27272a;border-radius:8px;padding:.4rem .75rem;color:#a1a1aa;font-size:.8rem;cursor:pointer;transition:all .2s}}
  .fbtn:hover{{background:#27272a;color:#e4e4e7}}.fbtn.active{{background:#22d3ee20;border-color:#22d3ee40;color:#22d3ee}}
  .ctx{{padding:1rem 1.25rem}}
  .cf{{padding:.3rem 0;font-size:.85rem;color:#a1a1aa}}
  .cl{{display:inline-block;min-width:60px;font-weight:600;color:#71717a;font-size:.75rem;text-transform:uppercase}}
  .cw{{color:#eab308}}.cn{{color:#22d3ee}}.cbl{{color:#ef4444}}
  .cu{{margin-left:auto;color:#52525b;font-size:.75rem;font-family:'JetBrains Mono',monospace}}
  .tc{{max-height:600px;overflow-y:auto;border:1px solid #27272a;border-radius:12px;background:#0a0a0c}}
  .tc::-webkit-scrollbar{{width:6px}}.tc::-webkit-scrollbar-track{{background:transparent}}.tc::-webkit-scrollbar-thumb{{background:#27272a;border-radius:3px}}
  @media(max-width:768px){{.header{{flex-direction:column;gap:.5rem}}.sb{{flex-wrap:wrap}}.cg{{grid-template-columns:1fr}}.content{{padding:1rem}}}}
</style>
</head>
<body>
<div class="header"><h1>⚡ Tich Mission Control</h1><div class="hm">{now} · {n_repos} repos · {n_bl} backlog items</div></div>
<div class="sb"><div class="sc"><span class="n" style="color:#ef4444">{tbo}</span> Open</div><div class="sc"><span class="n" style="color:#22c55e">{tbd}</span> Done</div><div class="sc"><span class="n" style="color:#22d3ee">{n_cap}</span> Capabilities</div><div class="sc"><span class="n" style="color:#a855f7">{n_dec}</span> Decisions</div></div>
<div class="tabs"><div class="tab active" onclick="sw('backlog')">Backlog</div><div class="tab" onclick="sw('caps')">Capabilities</div><div class="tab" onclick="sw('decisions')">Decisions</div><div class="tab" onclick="sw('context')">Context</div></div>
<div class="content">
<div id="tab-backlog" class="tp-panel active"><div class="st">Per-Repo Summary</div><div class="cg">{bc}</div><div class="st">All Items</div><div class="fb"><input type="text" placeholder="Search backlog…" oninput="ft('bt',this.value)"><button class="fbtn active" onclick="fs(this,'bt','all')">All</button><button class="fbtn" onclick="fs(this,'bt','⭕')">⭕ Open</button><button class="fbtn" onclick="fs(this,'bt','✅')">✅ Done</button></div><div class="tc"><table class="dt" id="bt"><thead><tr><th>ID</th><th>Tier</th><th>S</th><th>Repo</th><th>Title</th></tr></thead><tbody>{br}</tbody></table></div></div>
<div id="tab-caps" class="tp-panel"><div class="fb"><input type="text" placeholder="Search capabilities…" oninput="ft('ct',this.value)"></div><div class="tc"><table class="dt" id="ct"><thead><tr><th>ID</th><th>Category</th><th>S</th><th>Repo</th><th>Name</th></tr></thead><tbody>{cr}</tbody></table></div></div>
<div id="tab-decisions" class="tp-panel"><div class="fb"><input type="text" placeholder="Search decisions…" oninput="ft('det',this.value)"></div><div class="tc"><table class="dt" id="det"><thead><tr><th>ID</th><th>S</th><th>Repo</th><th>Title</th><th>Choice</th></tr></thead><tbody>{dr}</tbody></table></div></div>
<div id="tab-context" class="tp-panel"><div class="cg">{ctxc}</div></div>
</div>
<script>
function sw(n){{document.querySelectorAll('.tp-panel').forEach(p=>p.classList.remove('active'));document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));document.getElementById('tab-'+n).classList.add('active');const m={{'backlog':'Backlog','caps':'Capabilities','decisions':'Decisions','context':'Context'}};document.querySelectorAll('.tab').forEach(t=>{{if(t.textContent.trim()===m[n])t.classList.add('active')}})}}
function ft(id,q){{document.getElementById(id).querySelectorAll('tbody tr').forEach(r=>{{r.style.display=r.textContent.toLowerCase().includes(q.toLowerCase())?'':'none'}})}}
function fs(b,id,e){{b.parentElement.querySelectorAll('.fbtn').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.getElementById(id).querySelectorAll('tbody tr').forEach(r=>{{if(e==='all'){{r.style.display='';return}}r.style.display=r.querySelectorAll('td')[2]?.textContent.trim()===e?'':'none'}})}}
document.addEventListener('keydown',e=>{{const m={{'1':'backlog','2':'caps','3':'decisions','4':'context'}};if(m[e.key]&&!e.ctrlKey&&!e.metaKey&&document.activeElement.tagName!=='INPUT')sw(m[e.key])}})
</script>
</body>
</html>'''
