"""tich.backlog — Backlog management (add, close, list, view, summary).

SPDX-License-Identifier: MIT
"""

import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from . import data as D

TIER_COLORS = {
    "P0": "\033[91m", "P1": "\033[38;5;208m", "P2": "\033[93m",
    "P3": "\033[94m", "P4": "\033[95m", "Icebox": "\033[90m",
    "Med": "\033[93m", "Low": "\033[92m",
}
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
STATUS_EMOJI = {"open": "⭕", "done": "✅", "archived": "📁"}


def _color_tier(tier: str) -> str:
    return TIER_COLORS.get(tier, "") + tier + RESET


def _ansi_len(s: str) -> int:
    return len(re.sub(r'\033\[[0-9;]*m', '', s))


def _pad(s: str, w: int) -> str:
    return s + " " * max(0, w - _ansi_len(s))


def cmd_list(repo: Optional[str] = None, tier: Optional[str] = None, status: str = "open"):
    repo = repo or D.auto_repo()
    items = D.backlog_items(status=status if status != "all" else "all", repo=repo)
    if tier:
        items = [i for i in items if i.get("tier") == tier]
    if not items:
        print(f"{DIM}No items found matching criteria.{RESET}")
        return

    print(f"\n{BOLD}{'ID':<8} {'T':<6} {'S':<2} {'Repo':<12} {'Title'} {RESET}")
    print(f"{DIM}{'─'*80}{RESET}")

    for item in items:
        se = STATUS_EMOJI.get(item.get("status", ""), "?")
        tc = _pad(_color_tier(item.get("tier", "?")), 6)
        rl = f"{DIM}[{item['_repo']}]{RESET}"
        print(f"{BOLD}{item['id']:<8}{RESET} {tc} {se} {rl:<20} {item.get('title', '')}")


def cmd_view(item_id: str):
    bl = D.load_backlog()
    item = repo = None
    for r, rd in bl.items():
        for i in rd.get("items", []):
            if i["id"] == item_id:
                item, repo = i, r
                break
        if item:
            break
    if not item:
        print(f"Error: Item {item_id} not found.")
        return

    print(f"\n{BOLD}Details for {item_id}{RESET}")
    print(f"{DIM}{'═'*60}{RESET}")
    print(f"{BOLD}Repo:      {RESET}{repo}")
    print(f"{BOLD}Tier:      {RESET}{_color_tier(item['tier'])}")
    print(f"{BOLD}Status:    {RESET}{STATUS_EMOJI.get(item['status'])} {item['status'].upper()}")
    print(f"{BOLD}Category:  {RESET}{item.get('category', 'N/A')}")
    print(f"{BOLD}Title:     {RESET}{item['title']}")
    print(f"{BOLD}Source:    {RESET}{item.get('source') or 'N/A'}")
    print(f"{BOLD}Created:   {RESET}{item.get('created_at')}  {BOLD}Updated:{RESET} {item.get('updated_at')}")
    print(f"\n{BOLD}Description:{RESET}")
    print(f"{DIM}{item.get('description') or 'N/A'}{RESET}")
    if item.get("resolution"):
        print(f"\n{BOLD}Resolution:{RESET}")
        print(f"{item['resolution']}")
    print(f"{DIM}{'═'*60}{RESET}\n")


def cmd_add(tier: str, title: str, repo: Optional[str] = None, desc: str = "",
            cat: str = "Uncategorized", source: Optional[str] = None):
    repo = repo or D.auto_repo()
    bl = D.load_backlog()
    if repo not in bl:
        bl[repo] = {"meta": {}, "items": []}

    pattern = re.compile(rf"^{tier}\.?(\d+)$")
    nums = [int(m.group(1)) for i in bl[repo]["items"] if (m := pattern.match(i["id"]))]
    next_num = max(nums, default=0) + 1
    new_id = f"{tier}.{next_num}" if tier.startswith("P") else f"{tier[0]}{next_num}"

    item = {
        "id": new_id, "tier": tier, "category": cat, "status": "open",
        "title": title, "description": desc, "source": source, "resolution": None,
        "created_at": datetime.now().strftime("%Y-%m-%d"),
        "updated_at": datetime.now().strftime("%Y-%m-%d"),
    }
    bl[repo]["items"].append(item)
    D.save_json(D.BACKLOG_FILE, bl)
    print(f"{BOLD}Added {new_id} to {repo}.{RESET}")


def cmd_close(item_id: str, reason: Optional[str] = None):
    bl = D.load_backlog()
    for r, rd in bl.items():
        for item in rd.get("items", []):
            if item["id"] == item_id:
                item["status"] = "done"
                item["resolution"] = reason
                item["updated_at"] = datetime.now().strftime("%Y-%m-%d")
                D.save_json(D.BACKLOG_FILE, bl)
                print(f"{BOLD}Closed {item_id}.{RESET}")
                return
    print(f"Error: Item {item_id} not found.")


def cmd_summary(repo: Optional[str] = None):
    repo = repo or D.auto_repo()
    stats = D.backlog_stats()
    repo_names = sorted(r for r in stats if not repo or r == repo)
    if not repo_names:
        print(f"{DIM}No data available.{RESET}")
        return

    ml = max(len("Repo"), max(len(r) for r in repo_names))
    rcw = ml + 2

    print(f"\n{BOLD}Backlog Summary{RESET}")
    print(f"{DIM}╔{'═'*rcw}╤{'═'*8}╤{'═'*8}╤{'═'*8}╗{RESET}")
    print(f"{BOLD}║ {'Repo':<{ml}} │ {'Tier':<6} │ {'Open':<6} │ {'Done':<6} ║{RESET}")
    print(f"{DIM}╟{'─'*rcw}┼{'─'*8}┼{'─'*8}┼{'─'*8}╢{RESET}")

    for rn in repo_names:
        for t in D.ALL_TIERS:
            c = stats[rn].get(t, {"open": 0, "done": 0})
            tp = _pad(_color_tier(t), 6)
            print(f"║ {rn:<{ml}} │ {tp} │ {c['open']:<6} │ {c['done']:<6} ║")

    print(f"{DIM}╚{'═'*rcw}╧{'═'*8}╧{'═'*8}╧{'═'*8}╝{RESET}\n")
