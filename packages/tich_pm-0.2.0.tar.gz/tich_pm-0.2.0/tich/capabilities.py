"""tich.capabilities — Capability registry (add, list, search, view, summary).

SPDX-License-Identifier: MIT
"""

import re
import unicodedata
from datetime import datetime
from typing import Optional

from . import data as D

CAT_COLORS = {
    "CLI": "\033[96m", "Simulation": "\033[93m", "Synthesis": "\033[91m",
    "Build": "\033[38;5;208m", "API": "\033[95m", "IP": "\033[92m",
    "Verification": "\033[94m", "Docker": "\033[36m", "Workspace": "\033[33m",
    "UI": "\033[35m", "RTL": "\033[31m", "Rendering": "\033[38;5;214m",
    "Scraping": "\033[38;5;109m", "RAG": "\033[38;5;141m",
    "Infra": "\033[90m", "Tool": "\033[37m",
}
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
STATUS_EMOJI = {"implemented": "✅", "partial": "🔶", "stub": "⬜", "deprecated": "🚫"}


def _char_w(ch):
    cat = unicodedata.category(ch)
    if cat in ("Cs", "Cc", "Cf", "Mn", "Me"):
        return 0
    if unicodedata.east_asian_width(ch) in ("W", "F"):
        return 2
    if cat.startswith("So"):
        return 2
    return 1


def _dw(s):
    return sum(_char_w(c) for c in re.sub(r'\033\[[0-9;]*m', '', s))


def _pad(s, w):
    return s + " " * max(0, w - _dw(s))


def _color_cat(cat):
    return CAT_COLORS.get(cat, "\033[37m") + cat + RESET


def _trunc(s, w):
    return s[:w-1] + "…" if len(s) > w else s


def cmd_list(repo: Optional[str] = None, cat: Optional[str] = None, status: str = "implemented"):
    repo = repo or D.auto_repo()
    items = D.capability_items(repo=repo)
    if cat:
        items = [i for i in items if i.get("category") == cat]
    if status != "all":
        items = [i for i in items if i.get("status") == status]
    if not items:
        print(f"{DIM}No capabilities found matching criteria.{RESET}")
        return

    print(f"\n{BOLD}{'ID':<10} {'Cat':<14} {'S':<3} {'Repo':<14} {'Name':<36} {'Docs'}{RESET}")
    print(f"{DIM}{'─'*100}{RESET}")

    for item in items:
        se = STATUS_EMOJI.get(item.get("status"), "?")
        cc = _pad(_color_cat(item.get("category", "?")), 14)
        rl = f"{DIM}{item['_repo']}{RESET}"
        docs = _trunc(item.get("docs", "") or "—", 30)
        name = _trunc(item.get("name", ""), 36)
        print(f"{BOLD}{item['id']:<10}{RESET} {cc} {_pad(se, 3)} {_pad(rl, 14)} {name:<36} {DIM}{docs}{RESET}")

    print(f"\n{DIM}{len(items)} capability(ies){RESET}\n")


def cmd_search(query: str):
    items = D.capability_items()
    q = query.lower()
    hits = [i for i in items if q in " ".join(str(v) for v in i.values()).lower()]
    if not hits:
        print(f"{DIM}No capabilities matching '{query}'.{RESET}")
        return

    print(f"\n{BOLD}Search results for '{query}'{RESET}")
    print(f"{DIM}{'─'*100}{RESET}")
    for item in hits:
        se = STATUS_EMOJI.get(item.get("status"), "?")
        cc = _pad(_color_cat(item.get("category", "?")), 14)
        rl = f"{DIM}{item['_repo']}{RESET}"
        name = _trunc(item.get("name", ""), 36)
        print(f"{BOLD}{item['id']:<10}{RESET} {cc} {_pad(se, 3)} {_pad(rl, 14)} {name}")
    print(f"\n{DIM}{len(hits)} hit(s){RESET}\n")


def cmd_view(cap_id: str):
    caps = D.load_capabilities()
    item = repo = None
    for r, rd in caps.items():
        for i in rd.get("items", []):
            if i["id"] == cap_id:
                item, repo = i, r
                break
        if item:
            break
    if not item:
        print(f"Error: Capability '{cap_id}' not found.")
        return

    se = STATUS_EMOJI.get(item.get("status"), "?")
    print(f"\n{BOLD}Capability: {item['id']}{RESET}")
    print(f"{DIM}{'═'*60}{RESET}")
    print(f"{BOLD}Repo:        {RESET}{repo}")
    print(f"{BOLD}Category:    {RESET}{_color_cat(item['category'])}")
    print(f"{BOLD}Status:      {RESET}{se}  {item['status'].upper()}")
    print(f"{BOLD}Name:        {RESET}{item['name']}")
    print(f"{BOLD}Entry Point: {RESET}{item.get('entry_point', 'N/A')}")
    print(f"{BOLD}Since:       {RESET}{item.get('since', 'N/A')}")
    print(f"{BOLD}Docs:        {RESET}{item.get('docs') or 'N/A'}")
    print(f"{BOLD}Backlog Ref: {RESET}{item.get('backlog_ref') or 'N/A'}")
    print(f"\n{BOLD}Description:{RESET}")
    print(f"  {DIM}{item.get('description') or 'N/A'}{RESET}")
    print(f"{DIM}{'═'*60}{RESET}\n")


def cmd_add(cat: str, name: str, repo: Optional[str] = None, entry: str = "",
            docs: str = "", since: str = "", ref: str = "", desc: str = "",
            status: str = "implemented"):
    repo = repo or D.auto_repo()
    caps = D.load_capabilities()
    if repo not in caps:
        caps[repo] = {"meta": {}, "items": []}

    prefix = cat.upper()[:4]
    pattern = re.compile(rf"^{re.escape(prefix)}\.?(\d+)$", re.IGNORECASE)
    nums = [int(m.group(1)) for i in caps[repo]["items"] if (m := pattern.match(i["id"]))]
    new_id = f"{prefix}.{max(nums, default=0) + 1}"

    item = {
        "id": new_id, "category": cat, "name": name,
        "status": status, "entry_point": entry, "since": since,
        "docs": docs, "backlog_ref": ref, "description": desc,
        "added_at": datetime.now().strftime("%Y-%m-%d"),
    }
    caps[repo]["items"].append(item)
    D.save_json(D.CAPS_FILE, caps)
    print(f"{BOLD}✅ Registered {new_id} in {repo}: {name}{RESET}")


def cmd_summary(repo: Optional[str] = None):
    repo = repo or D.auto_repo()
    caps = D.load_capabilities()
    all_cats, stats = set(), {}
    rns = sorted(r for r in caps if not repo or r == repo)
    if not rns:
        print(f"{DIM}No data available.{RESET}")
        return

    for rn in rns:
        for item in caps[rn].get("items", []):
            cat = item["category"]
            all_cats.add(cat)
            key = (rn, cat)
            if key not in stats:
                stats[key] = {"implemented": 0, "partial": 0, "stub": 0, "deprecated": 0}
            st = item.get("status", "implemented")
            if st in stats[key]:
                stats[key][st] += 1

    cats = sorted(all_cats)
    ml = max(len("Repo"), max(len(r) for r in rns))
    rcw = ml + 2

    print(f"\n{BOLD}Capability Registry Summary{RESET}")
    print(f"{DIM}╔{'═'*rcw}╤{'═'*16}╤{'═'*6}╤{'═'*6}╤{'═'*6}╗{RESET}")
    h_impl = _pad("✅", 4)
    h_part = _pad("🔶", 4)
    h_stub = _pad("⬜", 4)
    print(f"{BOLD}║ {'Repo':<{ml}} │ {'Category':<14} │ {h_impl} │ {h_part} │ {h_stub} ║{RESET}")
    print(f"{DIM}╟{'─'*rcw}┼{'─'*16}┼{'─'*6}┼{'─'*6}┼{'─'*6}╢{RESET}")

    for rn in rns:
        for cat in cats:
            c = stats.get((rn, cat))
            if not c:
                continue
            cp = _pad(_color_cat(cat), 14)
            print(f"║ {rn:<{ml}} │ {cp} │ {c['implemented']:<4} │ {c['partial']:<4} │ {c['stub']:<4} ║")

    print(f"{DIM}╚{'═'*rcw}╧{'═'*16}╧{'═'*6}╧{'═'*6}╧{'═'*6}╝{RESET}")
    total = sum(sum(v.values()) for v in stats.values())
    total_impl = sum(v["implemented"] for v in stats.values())
    print(f"\n  {BOLD}Total:{RESET} {total} capabilities ({total_impl} implemented)\n")
