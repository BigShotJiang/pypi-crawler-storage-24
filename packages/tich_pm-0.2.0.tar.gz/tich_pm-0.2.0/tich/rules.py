"""tich.rules — Agent governance rules engine.

Manages a registry of rules that govern AI-agent behaviour.
Ships with built-in defaults; users can add custom rules.

SPDX-License-Identifier: MIT
"""

import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from . import data as D

RULES_FILE = "rules.json"

# ── ANSI ─────────────────────────────────────────────────────
RESET = "\033[0m"
BOLD = "\033[1m"
DIM = "\033[2m"
CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
MAGENTA = "\033[95m"

# ── Built-in rule catalog ────────────────────────────────────
# These are shipped with tich-pm. Each has:
#   id, title, trigger, action, category, default (on/off)

BUILTIN_RULES: List[Dict] = [
    # ── Defaults (enabled on tich init) ──
    {
        "id": "bug-test",
        "title": "Bug → Test",
        "category": "bug-discovery",
        "trigger": "Logging a bug via `tich log add`",
        "action": "The description MUST include a `[NEEDS-TEST]` tag with a one-liner describing the regression test. When closing the bug, the resolution MUST reference the test that was added. No bug is considered closed without a corresponding test.",
        "default": True,
    },
    {
        "id": "context-first",
        "title": "Context-first",
        "category": "conversation",
        "trigger": "Starting a new conversation or task",
        "action": "Run `tich ctx get` to read the current state of play BEFORE doing any work. This prevents stale context and duplicate work.",
        "default": True,
    },
    {
        "id": "pre-existing-failures",
        "title": "Pre-existing failure protocol",
        "category": "bug-discovery",
        "trigger": "Tests fail that are NOT caused by current changes",
        "action": "The agent MUST: (1) confirm the failures are pre-existing (not regressions), (2) create a backlog entry using `tich log add` with the test name, error, and root cause, (3) tag the source as `pre-existing test failure`. Never silently ignore failing tests.",
        "default": True,
    },
    {
        "id": "cap-registration",
        "title": "Capability registration",
        "category": "shipping",
        "trigger": "A feature is completed and verified",
        "action": "Register the capability with `tich cap add` including category, entry point, and docs reference. This builds the knowledge base organically.",
        "default": True,
    },
    {
        "id": "scope-guard",
        "title": "Scope guard",
        "category": "scope",
        "trigger": "Current task grows beyond its original scope",
        "action": "Do NOT silently expand the task. Create a new backlog item with `tich log add` for the extra work and ask the user whether to tackle it now or defer. This prevents unbounded task creep.",
        "default": True,
    },
    {
        "id": "no-silent-failures",
        "title": "No silent failures",
        "category": "verification",
        "trigger": "Any test fails during verification",
        "action": "Must either fix the failure or create a backlog entry with `tich log add`. Never skip, hide, or ignore a failing test.",
        "default": True,
    },
    # ── Opt-in rules ──
    {
        "id": "decision-recording",
        "title": "Decision recording",
        "category": "shipping",
        "trigger": "An architecture or design decision is made",
        "action": "Record the decision with `tich dec add` including the choice, alternatives considered, and reasoning. This prevents re-debating settled designs.",
        "default": False,
    },
    {
        "id": "context-on-commit",
        "title": "Context update on commit",
        "category": "shipping",
        "trigger": "After committing and pushing code",
        "action": "Update context with `tich ctx set` reflecting the current status, what was shipped, and what's next.",
        "default": False,
    },
    {
        "id": "breaking-change-alert",
        "title": "Breaking change alert",
        "category": "scope",
        "trigger": "A public API, CLI interface, or config format is modified",
        "action": "Flag the change explicitly to the user. Document the migration path in the commit message. If the project uses semver, note that this requires a major version bump.",
        "default": False,
    },
    {
        "id": "dependency-audit",
        "title": "Dependency audit",
        "category": "scope",
        "trigger": "A new dependency is added to the project",
        "action": "Justify the addition in the commit message. Check for license compatibility. Prefer stdlib or existing deps over new ones. Flag the addition to the user before committing.",
        "default": False,
    },
    {
        "id": "backlog-awareness",
        "title": "Backlog awareness",
        "category": "conversation",
        "trigger": "Starting work on a new feature or fix",
        "action": "Run `tich log list` to check if related items already exist. Prevents duplicate work and ensures alignment with planned priorities.",
        "default": False,
    },
    {
        "id": "verify-before-close",
        "title": "Verify before closing",
        "category": "verification",
        "trigger": "Closing a backlog item with `tich log close`",
        "action": "Confirm the fix is actually tested (not just 'it looks right'). Reference the specific test or verification step in the resolution. Run verification commands before closing.",
        "default": False,
    },
]

CATEGORY_LABELS = {
    "bug-discovery": "🐛 Bug Discovery",
    "shipping": "🚀 Shipping",
    "scope": "🛡️ Scope Changes",
    "conversation": "📖 Conversation",
    "verification": "✅ Verification",
    "custom": "🔧 Custom",
}

CATEGORY_ORDER = ["bug-discovery", "conversation", "shipping", "scope", "verification", "custom"]


def _rules_path() -> Path:
    return D.find_root() / RULES_FILE


def load_rules() -> Dict:
    """Load rules from rules.json, merging with built-in defaults."""
    path = _rules_path()
    if not path.exists():
        return {"rules": [], "custom_rules": []}
    with open(path, "r") as f:
        return json.load(f)


def save_rules(data: Dict):
    path = _rules_path()
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


def get_effective_rules() -> List[Dict]:
    """Return the full list of rules with their current enabled/disabled state."""
    data = load_rules()
    configured = {r["id"]: r for r in data.get("rules", [])}
    custom = data.get("custom_rules", [])

    result = []
    for builtin in BUILTIN_RULES:
        entry = {**builtin}
        if builtin["id"] in configured:
            entry["enabled"] = configured[builtin["id"]].get("enabled", builtin["default"])
        else:
            entry["enabled"] = builtin["default"]
        entry["builtin"] = True
        result.append(entry)

    for rule in custom:
        rule["builtin"] = False
        rule.setdefault("enabled", True)
        result.append(rule)

    return result


def get_enabled_rules() -> List[Dict]:
    """Return only enabled rules."""
    return [r for r in get_effective_rules() if r.get("enabled")]


def init_rules():
    """Initialize rules.json with built-in defaults."""
    path = _rules_path()
    if path.exists():
        return False

    data = {
        "rules": [{"id": r["id"], "enabled": r["default"]} for r in BUILTIN_RULES],
        "custom_rules": [],
    }
    save_rules(data)
    return True


# ── CLI commands ─────────────────────────────────────────────

def cmd_list():
    """List all rules with their status."""
    rules = get_effective_rules()
    if not rules:
        print(f"{DIM}No rules configured. Run 'tich init' first.{RESET}")
        return

    print(f"\n{BOLD}Agent Governance Rules{RESET}")
    print(f"{DIM}{'═' * 80}{RESET}")

    by_cat: Dict[str, List[Dict]] = {}
    for r in rules:
        cat = r.get("category", "custom")
        by_cat.setdefault(cat, []).append(r)

    for cat in CATEGORY_ORDER:
        cat_rules = by_cat.get(cat, [])
        if not cat_rules:
            continue
        label = CATEGORY_LABELS.get(cat, cat)
        print(f"\n  {BOLD}{label}{RESET}")

        for r in cat_rules:
            icon = f"{GREEN}●{RESET}" if r.get("enabled") else f"{RED}○{RESET}"
            state = f"{GREEN}ON{RESET}" if r.get("enabled") else f"{DIM}OFF{RESET}"
            builtin = "" if r.get("builtin") else f" {MAGENTA}[custom]{RESET}"
            print(f"    {icon} {BOLD}{r['id']:<24}{RESET} {state}  {r['title']}{builtin}")
            print(f"      {DIM}{r.get('trigger', '')}{RESET}")

    enabled = sum(1 for r in rules if r.get("enabled"))
    print(f"\n  {DIM}{enabled}/{len(rules)} rules enabled{RESET}\n")


def cmd_enable(rule_id: str):
    data = load_rules()
    for r in data.get("rules", []):
        if r["id"] == rule_id:
            r["enabled"] = True
            save_rules(data)
            print(f"{GREEN}● Enabled{RESET} {BOLD}{rule_id}{RESET}")
            print(f"  {DIM}Run 'tich deploy' to update agent config.{RESET}")
            return

    # Check if it's a known builtin
    for builtin in BUILTIN_RULES:
        if builtin["id"] == rule_id:
            data.setdefault("rules", []).append({"id": rule_id, "enabled": True})
            save_rules(data)
            print(f"{GREEN}● Enabled{RESET} {BOLD}{rule_id}{RESET}")
            print(f"  {DIM}Run 'tich deploy' to update agent config.{RESET}")
            return

    # Check custom
    for r in data.get("custom_rules", []):
        if r["id"] == rule_id:
            r["enabled"] = True
            save_rules(data)
            print(f"{GREEN}● Enabled{RESET} {BOLD}{rule_id}{RESET}")
            return

    print(f"{RED}Error: Rule '{rule_id}' not found.{RESET}")


def cmd_disable(rule_id: str):
    data = load_rules()
    for r in data.get("rules", []):
        if r["id"] == rule_id:
            r["enabled"] = False
            save_rules(data)
            print(f"{RED}○ Disabled{RESET} {BOLD}{rule_id}{RESET}")
            print(f"  {DIM}Run 'tich deploy' to update agent config.{RESET}")
            return

    for builtin in BUILTIN_RULES:
        if builtin["id"] == rule_id:
            data.setdefault("rules", []).append({"id": rule_id, "enabled": False})
            save_rules(data)
            print(f"{RED}○ Disabled{RESET} {BOLD}{rule_id}{RESET}")
            return

    for r in data.get("custom_rules", []):
        if r["id"] == rule_id:
            r["enabled"] = False
            save_rules(data)
            print(f"{RED}○ Disabled{RESET} {BOLD}{rule_id}{RESET}")
            return

    print(f"{RED}Error: Rule '{rule_id}' not found.{RESET}")


def cmd_add(rule_id: str, title: str, trigger: str, action: str,
            category: str = "custom"):
    """Add a custom rule."""
    data = load_rules()

    # Check for duplicates
    all_ids = {r["id"] for r in BUILTIN_RULES}
    all_ids.update(r["id"] for r in data.get("custom_rules", []))
    if rule_id in all_ids:
        print(f"{RED}Error: Rule '{rule_id}' already exists.{RESET}")
        return

    rule = {
        "id": rule_id,
        "title": title,
        "category": category,
        "trigger": trigger,
        "action": action,
        "enabled": True,
        "added_at": datetime.now().strftime("%Y-%m-%d"),
    }
    data.setdefault("custom_rules", []).append(rule)
    save_rules(data)
    print(f"{GREEN}● Added custom rule{RESET} {BOLD}{rule_id}{RESET}: {title}")
    print(f"  {DIM}Run 'tich deploy' to update agent config.{RESET}")


def cmd_remove(rule_id: str):
    """Remove a custom rule (built-ins can only be disabled)."""
    data = load_rules()

    # Check if it's a builtin
    for b in BUILTIN_RULES:
        if b["id"] == rule_id:
            print(f"{YELLOW}Cannot remove built-in rule '{rule_id}'. Use 'tich rule disable {rule_id}' instead.{RESET}")
            return

    custom = data.get("custom_rules", [])
    before = len(custom)
    data["custom_rules"] = [r for r in custom if r["id"] != rule_id]
    if len(data["custom_rules"]) < before:
        save_rules(data)
        print(f"{RED}✕ Removed{RESET} {BOLD}{rule_id}{RESET}")
    else:
        print(f"{RED}Error: Custom rule '{rule_id}' not found.{RESET}")


def cmd_view(rule_id: str):
    """View full details of a rule."""
    for r in get_effective_rules():
        if r["id"] == rule_id:
            icon = f"{GREEN}●{RESET}" if r.get("enabled") else f"{RED}○{RESET}"
            state = f"{GREEN}ENABLED{RESET}" if r.get("enabled") else f"{RED}DISABLED{RESET}"
            kind = "Built-in" if r.get("builtin") else f"{MAGENTA}Custom{RESET}"
            cat = CATEGORY_LABELS.get(r.get("category", "custom"), r.get("category", ""))

            print(f"\n{BOLD}Rule: {r['id']}{RESET}")
            print(f"{DIM}{'═' * 60}{RESET}")
            print(f"  {BOLD}Title:    {RESET}{r['title']}")
            print(f"  {BOLD}Status:   {RESET}{icon} {state}")
            print(f"  {BOLD}Type:     {RESET}{kind}")
            print(f"  {BOLD}Category: {RESET}{cat}")
            print(f"\n  {BOLD}Trigger:{RESET}")
            print(f"  {CYAN}{r.get('trigger', 'N/A')}{RESET}")
            print(f"\n  {BOLD}Action:{RESET}")
            print(f"  {r.get('action', 'N/A')}")
            print(f"{DIM}{'═' * 60}{RESET}\n")
            return

    print(f"{RED}Error: Rule '{rule_id}' not found.{RESET}")


def cmd_pick():
    """Interactive menu to toggle rules on/off."""
    rules = get_effective_rules()
    if not rules:
        print(f"{DIM}No rules found. Run 'tich init' first.{RESET}")
        return

    print(f"\n{BOLD}⚡ Rule Picker — Toggle rules on/off{RESET}")
    print(f"{DIM}Enter a number to toggle, 'a' to enable all, 'n' for defaults only, 'q' to save & quit.{RESET}\n")

    while True:
        # Group and display
        by_cat: Dict[str, List] = {}
        for r in rules:
            by_cat.setdefault(r.get("category", "custom"), []).append(r)

        idx = 1
        idx_map = {}
        for cat in CATEGORY_ORDER:
            cat_rules = by_cat.get(cat, [])
            if not cat_rules:
                continue
            label = CATEGORY_LABELS.get(cat, cat)
            print(f"  {BOLD}{label}{RESET}")
            for r in cat_rules:
                icon = f"{GREEN}●{RESET}" if r.get("enabled") else f"{RED}○{RESET}"
                default_mark = f" {DIM}(default){RESET}" if r.get("default") else ""
                print(f"    {DIM}{idx:>2}.{RESET} {icon} {r['title']}{default_mark}")
                idx_map[idx] = r
                idx += 1
            print()

        enabled = sum(1 for r in rules if r.get("enabled"))
        print(f"  {DIM}{enabled}/{len(rules)} enabled{RESET}")

        try:
            choice = input(f"\n  {BOLD}Toggle #{RESET} (a=all, n=defaults, q=save): ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            choice = "q"

        if choice == "q":
            break
        elif choice == "a":
            for r in rules:
                r["enabled"] = True
            print(f"  {GREEN}All rules enabled.{RESET}\n")
        elif choice == "n":
            for r in rules:
                r["enabled"] = r.get("default", False)
            print(f"  {YELLOW}Reset to defaults.{RESET}\n")
        elif choice.isdigit() and int(choice) in idx_map:
            r = idx_map[int(choice)]
            r["enabled"] = not r.get("enabled", False)
            state = f"{GREEN}ON{RESET}" if r["enabled"] else f"{RED}OFF{RESET}"
            print(f"  → {r['title']}: {state}\n")
        else:
            print(f"  {RED}Invalid choice.{RESET}\n")

    # Save
    data = load_rules()
    builtin_ids = {r["id"] for r in BUILTIN_RULES}
    data["rules"] = [{"id": r["id"], "enabled": r["enabled"]} for r in rules if r["id"] in builtin_ids]
    for r in rules:
        if r["id"] not in builtin_ids:
            for cr in data.get("custom_rules", []):
                if cr["id"] == r["id"]:
                    cr["enabled"] = r["enabled"]
    save_rules(data)

    enabled = sum(1 for r in rules if r.get("enabled"))
    print(f"\n  {GREEN}✅ Saved {enabled} enabled rules.{RESET}")
    print(f"  {DIM}Run 'tich deploy' to update agent config.{RESET}\n")


def generate_rules_markdown() -> str:
    """Generate markdown from enabled rules for deploy injection."""
    enabled = get_enabled_rules()
    if not enabled:
        return "No rules configured."

    by_cat: Dict[str, List[Dict]] = {}
    for r in enabled:
        by_cat.setdefault(r.get("category", "custom"), []).append(r)

    lines = []
    for cat in CATEGORY_ORDER:
        cat_rules = by_cat.get(cat, [])
        if not cat_rules:
            continue
        label = CATEGORY_LABELS.get(cat, cat)
        lines.append(f"\n#### {label}\n")
        for r in cat_rules:
            lines.append(f"- **{r['title']}**: When {r['trigger'].lower()}, {r['action']}")

    return "\n".join(lines)
