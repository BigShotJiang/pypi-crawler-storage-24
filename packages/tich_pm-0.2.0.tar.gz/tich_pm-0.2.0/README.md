# tich-pm

**Project management toolkit for AI-agent workflows.**

Structured backlog, capability tracking, architecture decisions, and context anchors — designed for humans **and** AI agents to share the same source of truth.

## Install

```bash
pip install tich-pm
```

Or for development:

```bash
git clone https://github.com/djmazure/tich-pm.git
cd tich-pm
pip install -e .
```

## Quick Start

```bash
# Bootstrap a new project
tich init

# Deploy rules into your AI agent's config
tich deploy gemini          # → GEMINI.md
tich deploy claude          # → .claude/rules
tich deploy cursor          # → .cursorrules

# Manage your backlog
tich log add --tier P2 --title "Add WebSocket support"
tich log list
tich log close P2.1 --reason "Shipped in v1.2"

# Track capabilities
tich cap add --cat CLI --name "Multi-dir lint"

# Record decisions
tich dec add --title "REST vs GraphQL" --choice "REST" --reason "Simpler for our use case"

# Context anchors (agent reads this first)
tich ctx set --status "v1.2 shipped, next: WebSocket support"
tich ctx get

# Dashboard
tich dash                   # HTML dashboard in browser
tich dash --tui             # Interactive terminal TUI
```

## What's Included

| Command | Purpose |
|---------|---------|
| `tich log` | Backlog management (P0–P4 / Med / Low / Icebox) |
| `tich cap` | Capability registry — tracks what's shipped |
| `tich dec` | Decision log — records WHY choices were made |
| `tich ctx` | Context anchors — state of play per repo |
| `tich dash` | Unified dashboard (HTML + terminal TUI) |
| `tich init` | Bootstrap JSON files for a new project |
| `tich deploy` | Inject rules into AI agent config files |

## Deploy System

`tich deploy` injects rules into your AI agent's configuration file using an idempotent marker-based approach:

```bash
tich deploy gemini    # Appends/updates ## Tich PM section in GEMINI.md
tich deploy claude    # .claude/rules
tich deploy cursor    # .cursorrules
tich deploy --list    # Show available agents
tich deploy --dry-run # Preview without writing
```

Re-running `tich deploy` updates the rules in-place — no duplicates.

## Data Storage

All data lives in JSON files at your project root:

- `backlog.json` — Backlog items
- `capabilities.json` — Shipped capabilities
- `decisions.json` — Architecture decisions
- `context.json` — Context anchors

No server, no SaaS, no account. Just files in your repo.

## License

MIT
