from setuptools import find_packages, setup

setup(
    name="mlflow-tclake-plugin",
    version="3.0.16",
    description="Tclake plugin for MLflow",
    packages=find_packages(),
    # Require MLflow as a dependency of the plugin, so that plugin users can simply install
    # the plugin & then immediately use it with MLflow
    install_requires=["mlflow>=3.10.0,<3.11.0", "tencentcloud-sdk-python-common>=3.0.1478"],
    extras_require={
        "dev": ["pytest", "flake8", "python-dotenv"],
    },
    python_requires=">=3.10",
    entry_points={
        "mlflow.model_registry_store": (
            "tclake=mlflow_tclake_plugin.tclake_store:TCLakeStore"
        ),
    },
)
