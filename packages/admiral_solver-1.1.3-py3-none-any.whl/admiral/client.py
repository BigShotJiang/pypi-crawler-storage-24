"""Admiral Solver SDK — HTTP client for all 11 problem types."""
from __future__ import annotations
import os, time, json
import httpx
import numpy as np
from admiral.models.result import SolveResult

class Solver:
    def __init__(self, api_key=None, base_url=None, timeout=120):
        self.api_key = api_key or os.getenv("ADMIRAL_API_KEY")
        self.base_url = (base_url or os.getenv("ADMIRAL_API_URL", "https://api.admiral-platform.tech")).rstrip("/")
        self.timeout = timeout
        self._client = httpx.Client(timeout=timeout)

    # ── 1. QUBO ──
    def solve_qubo(self, Q, timeout=30, num_reads=100, solver="auto", seed=None):
        if isinstance(Q, np.ndarray): Q = Q.tolist()
        return self._submit("qubo", {"Q": Q}, timeout, num_reads, solver, seed)

    # ── 2. Ising ──
    def solve_ising(self, h, J, timeout=30, num_reads=100, solver="auto", seed=None):
        if isinstance(h, np.ndarray): h = h.tolist()
        if isinstance(J, np.ndarray): J = J.tolist()
        return self._submit("ising", {"h": h, "J": J}, timeout, num_reads, solver, seed)

    # ── 3. HUBO ──
    def solve_hubo(self, terms, num_variables, timeout=30, num_reads=100, solver="auto", seed=None):
        data = {"terms": [{"indices": list(idx), "coefficient": c} for idx, c in terms], "num_variables": num_variables}
        return self._submit("hubo", data, timeout, num_reads, solver, seed)

    # ── 4. DQM ──
    def solve_dqm(self, domains, linear=None, quadratic=None, timeout=30, num_reads=100, solver="auto", seed=None):
        data = {"domains": domains}
        if linear: data["linear"] = linear
        if quadratic:
            data["quadratic"] = {}
            for (v1, v2), mat in quadratic.items():
                key = f"{v1},{v2}"
                data["quadratic"][key] = mat if not isinstance(mat, np.ndarray) else mat.tolist()
        return self._submit("dqm", data, timeout, num_reads, solver, seed)

    # ── 5. CQM ──
    def solve_cqm(self, c, Q, A, b, var_types=None, bounds=None, timeout=30, num_reads=100, solver="auto", seed=None):
        data = {"c": _to_list(c), "Q": _to_list(Q), "A": _to_list(A), "b": _to_list(b)}
        if var_types: data["var_types"] = var_types
        if bounds: data["bounds"] = bounds
        return self._submit("cqm", data, timeout, num_reads, solver, seed)

    # ── 6. MILP ──
    def solve_milp(self, c, A, b, integer_vars=None, bounds=None, timeout=30, solver="auto", seed=None):
        data = {"c": _to_list(c), "A": _to_list(A), "b": _to_list(b)}
        if integer_vars is not None: data["integer_vars"] = list(integer_vars)
        if bounds: data["bounds"] = bounds
        return self._submit("milp", data, timeout, 1, solver, seed)

    # ── 7. MIQP ──
    def solve_miqp(self, c, Q, A, b, var_types=None, bounds=None, timeout=30, num_reads=100, solver="auto", seed=None):
        data = {"c": _to_list(c), "Q": _to_list(Q), "A": _to_list(A), "b": _to_list(b)}
        if var_types: data["var_types"] = var_types
        if bounds: data["bounds"] = bounds
        return self._submit("miqp", data, timeout, num_reads, solver, seed)

    # ── 8. Max-SAT ──
    def solve_maxsat(self, clauses, num_variables=None, timeout=30, num_reads=100, solver="auto", seed=None):
        cl = [{"literals": c[0], "weight": c[1] if len(c) > 1 else 1, "hard": c[2] if len(c) > 2 else False} for c in clauses]
        data = {"clauses": cl}
        if num_variables: data["num_variables"] = num_variables
        return self._submit("maxsat", data, timeout, num_reads, solver, seed)

    # ── 9. PBO ──
    def solve_pbo(self, objective, constraints, num_variables, timeout=30, num_reads=100, solver="auto", seed=None):
        obj = [{"coefficient": c, "literals": lits} for c, lits in objective]
        cons = [{"terms": [{"coefficient": c, "literals": l} for c, l in con[0]], "rhs": con[1]} for con in constraints]
        return self._submit("pbo", {"objective": obj, "constraints": cons, "num_variables": num_variables}, timeout, num_reads, solver, seed)

    # ── 10. WCSP ──
    def solve_wcsp(self, num_variables, domains, functions, timeout=30, num_reads=100, solver="auto", seed=None):
        funcs = []
        for scope, costs in functions:
            entries = [{"values": list(k), "cost": v} for k, v in costs.items()]
            funcs.append({"scope": list(scope), "entries": entries})
        return self._submit("wcsp", {"num_variables": num_variables, "domains": domains, "functions": funcs}, timeout, num_reads, solver, seed)

    # ── 11. Potts ──
    def solve_potts(self, num_nodes, num_states, edges, fields=None, timeout=30, num_reads=100, solver="auto", seed=None):
        e = [{"i": i, "j": j, "coupling": c} for (i, j), c in edges.items()]
        f = [{"node": n, "costs": c} for n, c in (fields or {}).items()]
        return self._submit("potts", {"num_nodes": num_nodes, "num_states": num_states, "edges": e, "fields": f}, timeout, num_reads, solver, seed)

    # ── Internal ──
    def _submit(self, problem_type, data, timeout, num_reads, solver, seed):
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        body = {"problem_type": problem_type, "data": data, "config": {"timeout": timeout, "num_reads": num_reads, "solver": solver}}
        if seed is not None: body["config"]["seed"] = seed

        r = self._client.post(f"{self.base_url}/v1/solve", headers=headers, json=body)
        r.raise_for_status()
        jid = r.json()["job_id"]

        deadline = time.time() + timeout + 60
        while time.time() < deadline:
            time.sleep(1)
            r = self._client.get(f"{self.base_url}/v1/jobs/{jid}", headers=headers)
            r.raise_for_status()
            j = r.json()
            if j["status"] == "completed":
                return SolveResult(j["result"])
            if j["status"] == "failed":
                raise RuntimeError(f"Job failed: {j.get('error')}")
        raise TimeoutError(f"Job {jid} did not complete within {timeout + 60}s")


def _to_list(x):
    if isinstance(x, np.ndarray): return x.tolist()
    return x
