"""
Admiral — Combinatorial Optimization Cloud
===========================================
    pip install admiral-solver
    from admiral import Solver
    solver = Solver(api_key="adm_sk_...")
    result = solver.solve_qubo(Q)
"""
__version__ = "1.0.0"
from admiral.client import Solver
from admiral.models.qubo import QUBOModel
from admiral.models.ising import IsingModel
from admiral.models.cqm import CQMModel, Binary, Integer, Real, Spin
from admiral.models.milp import MILPModel
from admiral.models.dqm import DQMModel
from admiral.models.hubo import HUBOModel
from admiral.models.maxsat import MaxSATModel
from admiral.models.result import SolveResult
