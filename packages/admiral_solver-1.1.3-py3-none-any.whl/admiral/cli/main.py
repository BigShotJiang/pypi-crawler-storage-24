"""Admiral CLI."""
import json, sys, time
import click
import numpy as np

@click.group()
@click.version_option("1.0.0", prog_name="admiral")
def cli():
    """Admiral — Combinatorial Optimization Platform"""

@cli.command()
@click.option("--type","ptype",required=True,help="qubo|ising|cqm|milp|maxsat|...")
@click.option("--input","infile",required=True,help="Input file (JSON)")
@click.option("--output","outfile",default=None,help="Output file")
@click.option("--timeout",default=30,help="Timeout seconds")
@click.option("--solver",default="auto",help="auto|sb|pt|tabu|sa")
@click.option("--reads",default=100,help="Num reads")
@click.option("--seed",default=None,type=int)
@click.option("--local",is_flag=True,help="Run locally")
@click.option("--api-key",envvar="ADMIRAL_API_KEY",default=None)
def solve(ptype,infile,outfile,timeout,solver,reads,seed,local,api_key):
    """Solve an optimization problem."""
    with open(infile) as f: data=json.load(f)
    click.echo(f"[admiral] type={ptype} solver={solver} timeout={timeout}s")
    if local:
        from admiral.client import LocalSolver
        result=LocalSolver().solve_qubo(np.array(data.get("Q",data)),timeout=timeout,num_reads=reads,solver=solver,seed=seed)
    else:
        if not api_key: click.echo("Error: --api-key or ADMIRAL_API_KEY required"); sys.exit(1)
        from admiral.client import Solver
        result=Solver(api_key=api_key).solve_qubo(np.array(data["Q"]),timeout=timeout,num_reads=reads,solver=solver,seed=seed)
    click.echo(f"[admiral] energy={result.energy} solver={result.solver_used} time={result.timing.total_ms:.0f}ms")
    out=result.to_dict()
    if outfile:
        with open(outfile,"w") as f: json.dump(out,f,indent=2)
    else: click.echo(json.dumps(out,indent=2))

@cli.command()
@click.option("--from","from_type",required=True)
@click.option("--to","to_type",required=True)
@click.option("--input","infile",required=True)
@click.option("--output","outfile",default=None)
def convert(from_type,to_type,infile,outfile):
    """Convert between formats."""
    with open(infile) as f: data=json.load(f)
    if from_type=="qubo" and to_type=="ising":
        from admiral.models.qubo import QUBOModel
        h,J,off=QUBOModel.from_dict(data if "Q" in data else {"Q":data}).to_ising()
        out={"h":h.tolist(),"J":J.tolist(),"offset":off}
    elif from_type=="ising" and to_type=="qubo":
        from admiral.models.ising import IsingModel
        Q,off=IsingModel.from_dict(data).to_qubo()
        out={"Q":Q.tolist(),"offset":off}
    else: click.echo(f"Unsupported: {from_type} -> {to_type}"); sys.exit(1)
    if outfile:
        with open(outfile,"w") as f: json.dump(out,f,indent=2)
    else: click.echo(json.dumps(out,indent=2))

@cli.command()
@click.option("--sizes",default="10,50,100,500",help="Comma-separated sizes")
@click.option("--solver",default="auto")
@click.option("--timeout",default=60)
def bench(sizes,solver,timeout):
    """Run benchmarks."""
    from admiral.client import LocalSolver
    ls=LocalSolver()
    click.echo(f"{'SIZE':>8} {'ENERGY':>12} {'TIME':>10} {'SOLVER':>20}")
    click.echo("-"*56)
    for n in [int(s) for s in sizes.split(",")]:
        Q=np.random.randn(n,n); Q=(Q+Q.T)/2
        t0=time.monotonic()
        r=ls.solve_qubo(Q,timeout=timeout,solver=solver,num_reads=10)
        click.echo(f"{n:>8} {r.energy:>12.1f} {time.monotonic()-t0:>9.3f}s {r.solver_used:>20}")

@cli.command("server")
@click.option("--host",default="0.0.0.0")
@click.option("--port",default=8000)
@click.option("--workers",default=4)
def server(host,port,workers):
    """Start API server."""
    import uvicorn
    click.echo(f"[admiral] Starting server on {host}:{port}")
    uvicorn.run("admiral.api.server:app",host=host,port=port,workers=workers)

@cli.command("worker")
@click.option("--redis",default="redis://localhost:6379/0")
def worker(redis):
    """Start worker process."""
    import os; os.environ["REDIS_URL"]=redis
    from admiral.worker.run import main; main()

if __name__=="__main__": cli()
