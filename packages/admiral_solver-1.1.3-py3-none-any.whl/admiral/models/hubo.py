"""HUBO: Higher-order Unconstrained Binary Optimization."""
from __future__ import annotations
from typing import Any
from admiral.models.base import ProblemModel, ProblemType
class HUBOModel(ProblemModel):
    problem_type = ProblemType.HUBO
    def __init__(self): self.terms={}; self._n=0
    def add_term(self, variables, coefficient):
        key=frozenset(variables); self.terms[key]=self.terms.get(key,0)+coefficient
        if variables: self._n=max(self._n, max(variables)+1)
    def num_variables(self): return self._n
    def max_degree(self): return max((len(k) for k in self.terms), default=0)
    def to_dict(self): return {"terms":{str(sorted(k)):v for k,v in self.terms.items()},"num_vars":self._n}
    @classmethod
    def from_dict(cls, data):
        m=cls(); m._n=data.get("num_vars",0)
        for ks,v in data["terms"].items(): m.add_term(eval(ks),v)
        return m
