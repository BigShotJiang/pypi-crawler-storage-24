"""QUBO: min x^T Q x, x in {0,1}^n"""
from __future__ import annotations
from typing import Any
import numpy as np
from admiral.models.base import ProblemModel, ProblemType

class QUBOModel(ProblemModel):
    problem_type = ProblemType.QUBO
    def __init__(self, Q):
        if isinstance(Q, dict):
            n = max(max(i,j) for i,j in Q.keys()) + 1
            self.Q = np.zeros((n, n))
            for (i,j), v in Q.items(): self.Q[i][j] = v
        else:
            self.Q = np.array(Q, dtype=float)
        n = self.Q.shape[0]
        for i in range(n):
            for j in range(i):
                self.Q[j][i] += self.Q[i][j]; self.Q[i][j] = 0
    def num_variables(self): return self.Q.shape[0]
    def energy(self, x): return float(np.asarray(x) @ self.Q @ np.asarray(x))
    def to_ising(self):
        n = self.num_variables(); h = np.zeros(n); J = np.zeros((n,n)); offset = 0.0
        for i in range(n):
            h[i] += 0.5*self.Q[i][i]; offset += 0.25*self.Q[i][i]
            for j in range(i+1, n):
                J[i][j] = 0.25*self.Q[i][j]; h[i] += 0.25*self.Q[i][j]
                h[j] += 0.25*self.Q[i][j]; offset += 0.25*self.Q[i][j]
        return h, J, offset
    def to_qubo(self): return self.Q.copy(), 0.0
    def to_dict(self): return {"Q": self.Q.tolist()}
    @classmethod
    def from_dict(cls, data): return cls(Q=data["Q"])
    def analyze(self):
        n = self.num_variables(); nnz = np.count_nonzero(self.Q)
        mx = n*(n+1)//2
        return {"type": "qubo", "num_variables": n, "density": nnz/mx if mx else 0}
