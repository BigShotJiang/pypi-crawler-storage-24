from __future__ import annotations
from abc import ABC, abstractmethod
from enum import Enum
from typing import Any
import numpy as np

class ProblemType(str, Enum):
    QUBO="qubo"; ISING="ising"; HUBO="hubo"; DQM="dqm"; CQM="cqm"
    MILP="milp"; MIQP="miqp"; MAXSAT="maxsat"; PBO="pbo"; WCSP="wcsp"; POTTS="potts"

class ProblemModel(ABC):
    problem_type: ProblemType
    @abstractmethod
    def num_variables(self) -> int: ...
    @abstractmethod
    def to_dict(self) -> dict[str, Any]: ...
    @classmethod
    @abstractmethod
    def from_dict(cls, data: dict[str, Any]) -> "ProblemModel": ...
    def to_qubo(self) -> tuple[np.ndarray, float]:
        raise NotImplementedError(f"{self.problem_type} to QUBO not implemented")
