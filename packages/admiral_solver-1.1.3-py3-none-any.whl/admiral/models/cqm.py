"""CQM: Constrained Quadratic Model with mixed variable types."""
from __future__ import annotations
from typing import Any
from admiral.models.base import ProblemModel, ProblemType

class Variable:
    def __init__(self, name, vartype, lower=0, upper=1):
        self.name=name; self.vartype=vartype; self.lower=lower; self.upper=upper
def Binary(name): return Variable(name, "BINARY", 0, 1)
def Integer(name, lower=0, upper=100): return Variable(name, "INTEGER", lower, upper)
def Real(name, lower=0, upper=1e6, bounds=None):
    if bounds: lower, upper = bounds
    return Variable(name, "REAL", lower, upper)
def Spin(name): return Variable(name, "SPIN", -1, 1)

class Constraint:
    def __init__(self, lhs, sense, rhs, name=""): self.lhs=lhs; self.sense=sense; self.rhs=rhs; self.name=name

class CQMModel(ProblemModel):
    problem_type = ProblemType.CQM
    def __init__(self):
        self.variables = {}; self.objective_linear = {}
        self.objective_quadratic = {}; self.constraints = []
    def add_variable(self, var): self.variables[var.name] = var; return var
    def minimize(self, expr):
        if isinstance(expr, dict):
            for k, v in expr.items():
                if isinstance(k, tuple): self.objective_quadratic[k] = v
                else: self.objective_linear[k] = v
    def add_constraint(self, lhs, sense="<=", rhs=0, name=""):
        c = Constraint(lhs if isinstance(lhs,dict) else {}, sense, rhs, name or f"c{len(self.constraints)}")
        self.constraints.append(c); return c.name
    def num_variables(self): return len(self.variables)
    def to_dict(self):
        return {"variables": {n: {"type":v.vartype,"lower":v.lower,"upper":v.upper} for n,v in self.variables.items()},
                "objective": {"linear": self.objective_linear, "quadratic": {f"{k[0]},{k[1]}":v for k,v in self.objective_quadratic.items()}},
                "constraints": [{"lhs":c.lhs,"sense":c.sense,"rhs":c.rhs,"name":c.name} for c in self.constraints]}
    @classmethod
    def from_dict(cls, data):
        m = cls()
        for name, vd in data.get("variables",{}).items():
            m.add_variable(Variable(name, vd["type"], vd.get("lower",0), vd.get("upper",1)))
        obj = data.get("objective",{})
        m.objective_linear = obj.get("linear",{})
        for k,v in obj.get("quadratic",{}).items():
            p=k.split(","); m.objective_quadratic[(p[0],p[1])]=v
        for cd in data.get("constraints",[]):
            m.add_constraint(cd["lhs"],cd["sense"],cd["rhs"],cd.get("name",""))
        return m
