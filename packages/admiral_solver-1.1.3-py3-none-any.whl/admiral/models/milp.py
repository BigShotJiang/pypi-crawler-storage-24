"""MILP: min c^T x s.t. Ax <= b"""
from __future__ import annotations
from typing import Any
import numpy as np
from admiral.models.base import ProblemModel, ProblemType
class MILPModel(ProblemModel):
    problem_type = ProblemType.MILP
    def __init__(self, c, A, b, integer_vars=None, binary_vars=None):
        self.c=np.asarray(c,dtype=float); self.A=np.asarray(A,dtype=float); self.b=np.asarray(b,dtype=float)
        self.integer_vars=integer_vars or set(); self.binary_vars=binary_vars or set()
    def num_variables(self): return len(self.c)
    def to_dict(self): return {"c":self.c.tolist(),"A":self.A.tolist(),"b":self.b.tolist()}
    @classmethod
    def from_dict(cls, data): return cls(data["c"],data["A"],data["b"])
