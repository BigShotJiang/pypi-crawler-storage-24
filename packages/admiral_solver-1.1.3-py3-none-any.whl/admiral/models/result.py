"""Solver result wrapper."""

class SolveResult:
    def __init__(self, data=None):
        data = data or {}
        self.solution = data.get("solution")
        self.energy = data.get("energy", data.get("score", float("inf")))
        self.solver = data.get("solver", "unknown")
        self.time_ms = data.get("time_ms", 0)
        self.convergence = data.get("convergence", [])
        self.feasible = data.get("feasible", None)
        self.reads = data.get("reads", 0)
        self._raw = data

    def __repr__(self):
        return f"SolveResult(energy={self.energy}, solver={self.solver}, time_ms={self.time_ms:.1f})"
