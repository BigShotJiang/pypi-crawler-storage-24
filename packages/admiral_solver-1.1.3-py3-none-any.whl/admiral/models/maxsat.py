"""Max-SAT: max Σ w_j sat(C_j)"""
from __future__ import annotations
from typing import Any
from admiral.models.base import ProblemModel, ProblemType
class Clause:
    def __init__(self, literals, weight=1.0, hard=False): self.literals=literals; self.weight=weight; self.hard=hard
class MaxSATModel(ProblemModel):
    problem_type = ProblemType.MAXSAT
    def __init__(self): self.clauses=[]; self._n=0
    def add_clause(self, literals, weight=1.0, hard=False):
        self.clauses.append(Clause(literals,weight,hard)); self._n=max(self._n,max(abs(l) for l in literals))
    def num_variables(self): return self._n
    def num_hard(self): return sum(1 for c in self.clauses if c.hard)
    def num_soft(self): return sum(1 for c in self.clauses if not c.hard)
    def to_dict(self): return {"clauses":[{"literals":c.literals,"weight":c.weight,"hard":c.hard} for c in self.clauses]}
    @classmethod
    def from_dict(cls, data):
        m=cls()
        for cd in data["clauses"]: m.add_clause(cd["literals"],cd.get("weight",1),cd.get("hard",False))
        return m
