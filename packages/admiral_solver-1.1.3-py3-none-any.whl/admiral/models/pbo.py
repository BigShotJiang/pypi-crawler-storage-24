"""PBO model — stub."""
from __future__ import annotations
from typing import Any
from admiral.models.base import ProblemModel, ProblemType
class PboModel(ProblemModel):
    problem_type = ProblemType.PBO
    def __init__(self, data=None): self.data=data or {}
    def num_variables(self): return self.data.get("num_vars",0)
    def to_dict(self): return self.data
    @classmethod
    def from_dict(cls, data): return cls(data=data)
