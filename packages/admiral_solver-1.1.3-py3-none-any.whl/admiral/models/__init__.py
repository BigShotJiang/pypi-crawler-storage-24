from admiral.models.result import SolveResult
