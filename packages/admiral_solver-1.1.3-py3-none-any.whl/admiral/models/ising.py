"""Ising: min Σh_i s_i + ΣJ_ij s_i s_j"""
from __future__ import annotations
from typing import Any
import numpy as np
from admiral.models.base import ProblemModel, ProblemType

class IsingModel(ProblemModel):
    problem_type = ProblemType.ISING
    def __init__(self, h, J):
        if isinstance(h, dict):
            n = max(max(h.keys(), default=0), max((max(i,j) for i,j in J.keys()), default=0)) + 1
            self.h = np.zeros(n)
            for i, v in h.items(): self.h[i] = v
            self.J = np.zeros((n,n))
            for (i,j), v in J.items(): self.J[min(i,j)][max(i,j)] = v
        else:
            self.h = np.asarray(h, dtype=float); self.J = np.asarray(J, dtype=float)
    def num_variables(self): return len(self.h)
    def energy(self, s): s = np.asarray(s, dtype=float); return float(self.h @ s + s @ self.J @ s)
    def to_qubo(self):
        n = self.num_variables(); Q = np.zeros((n,n)); offset = 0.0
        for i in range(n):
            Q[i][i] = -2*self.h[i]; offset += self.h[i]
            for j in range(i+1, n):
                Q[i][j] = -4*self.J[i][j]; Q[i][i] += 2*self.J[i][j]
                Q[j][j] += 2*self.J[i][j]; offset -= self.J[i][j]
        return Q, offset
    def to_dict(self): return {"h": self.h.tolist(), "J": self.J.tolist()}
    @classmethod
    def from_dict(cls, data): return cls(h=data["h"], J=data["J"])
