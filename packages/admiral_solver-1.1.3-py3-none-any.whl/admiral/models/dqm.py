"""DQM: Discrete Quadratic Model."""
from __future__ import annotations
from typing import Any
import numpy as np
from admiral.models.base import ProblemModel, ProblemType
class DQMModel(ProblemModel):
    problem_type = ProblemType.DQM
    def __init__(self): self.domains={}; self.linear={}; self.quadratic={}
    def add_variable(self, name, domain_size):
        self.domains[name]=domain_size; self.linear[name]=np.zeros(domain_size); return name
    def num_variables(self): return len(self.domains)
    def to_dict(self): return {"domains":self.domains,"linear":{k:v.tolist() for k,v in self.linear.items()}}
    @classmethod
    def from_dict(cls, data):
        m=cls()
        for n,s in data["domains"].items(): m.add_variable(n,s)
        return m
