"""BigShield - Multi-signal email validation SDK."""

from .async_client import AsyncBigShield
from .client import BigShield
from .errors import AuthError, BigShieldError, RateLimitError, ValidationError
from .types import (
    BatchValidateResponse,
    HealthResponse,
    SignalResult,
    UsageStats,
    ValidationResult,
)

__all__ = [
    "BigShield",
    "AsyncBigShield",
    "BigShieldError",
    "AuthError",
    "RateLimitError",
    "ValidationError",
    "ValidationResult",
    "SignalResult",
    "BatchValidateResponse",
    "UsageStats",
    "HealthResponse",
]

__version__ = "1.0.0"
