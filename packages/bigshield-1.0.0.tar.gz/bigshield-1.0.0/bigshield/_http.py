from __future__ import annotations

import time
from typing import Any, Dict, Optional

import httpx

from .errors import AuthError, BigShieldError, RateLimitError, ValidationError


class HttpClient:
    """Internal HTTP client with retry logic and error handling."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://www.bigshield.app",
        timeout: float = 30.0,
        retries: int = 2,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._retries = retries

    def _headers(self) -> Dict[str, str]:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._api_key}",
        }

    def _handle_error(self, response: httpx.Response) -> None:
        status = response.status_code
        try:
            body = response.json()
        except Exception:
            body = {}

        message = body.get("error", body.get("message", response.text))

        if status == 401:
            raise AuthError(message or "Invalid or missing API key")

        if status == 429:
            retry_after = int(response.headers.get("Retry-After", "60"))
            raise RateLimitError(retry_after=retry_after, message=message or "Rate limit exceeded")

        if status == 400:
            raise ValidationError(message=message or "Validation error", details=body.get("details"))

        raise BigShieldError(
            message=message or f"API error ({status})",
            code=body.get("code", "API_ERROR"),
            status=status,
            details=body.get("details"),
        )

    def _should_retry(self, status: int) -> bool:
        return status >= 500

    def request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        last_error: Optional[Exception] = None

        for attempt in range(self._retries + 1):
            try:
                with httpx.Client(timeout=self._timeout) as client:
                    response = client.request(
                        method,
                        url,
                        headers=self._headers(),
                        json=body,
                    )

                if response.is_success:
                    return response.json()

                if not self._should_retry(response.status_code) or attempt == self._retries:
                    self._handle_error(response)

                last_error = BigShieldError(
                    f"Server error ({response.status_code})",
                    status=response.status_code,
                )

            except (BigShieldError, AuthError, RateLimitError, ValidationError):
                raise
            except httpx.TimeoutException as exc:
                last_error = exc
                if attempt == self._retries:
                    raise BigShieldError(
                        "Request timed out",
                        code="TIMEOUT",
                        status=0,
                    ) from exc
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt == self._retries:
                    raise BigShieldError(
                        f"Network error: {exc}",
                        code="NETWORK_ERROR",
                        status=0,
                    ) from exc

            # Exponential backoff: 0.5s, 1s, 2s, ...
            time.sleep(0.5 * (2 ** attempt))

        raise last_error  # type: ignore[misc]


class AsyncHttpClient:
    """Internal async HTTP client with retry logic and error handling."""

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://www.bigshield.app",
        timeout: float = 30.0,
        retries: int = 2,
    ) -> None:
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._retries = retries

    def _headers(self) -> Dict[str, str]:
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self._api_key}",
        }

    def _handle_error(self, response: httpx.Response) -> None:
        status = response.status_code
        try:
            body = response.json()
        except Exception:
            body = {}

        message = body.get("error", body.get("message", response.text))

        if status == 401:
            raise AuthError(message or "Invalid or missing API key")

        if status == 429:
            retry_after = int(response.headers.get("Retry-After", "60"))
            raise RateLimitError(retry_after=retry_after, message=message or "Rate limit exceeded")

        if status == 400:
            raise ValidationError(message=message or "Validation error", details=body.get("details"))

        raise BigShieldError(
            message=message or f"API error ({status})",
            code=body.get("code", "API_ERROR"),
            status=status,
            details=body.get("details"),
        )

    def _should_retry(self, status: int) -> bool:
        return status >= 500

    async def request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
    ) -> Any:
        import asyncio

        url = f"{self._base_url}{path}"
        last_error: Optional[Exception] = None

        for attempt in range(self._retries + 1):
            try:
                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.request(
                        method,
                        url,
                        headers=self._headers(),
                        json=body,
                    )

                if response.is_success:
                    return response.json()

                if not self._should_retry(response.status_code) or attempt == self._retries:
                    self._handle_error(response)

                last_error = BigShieldError(
                    f"Server error ({response.status_code})",
                    status=response.status_code,
                )

            except (BigShieldError, AuthError, RateLimitError, ValidationError):
                raise
            except httpx.TimeoutException as exc:
                last_error = exc
                if attempt == self._retries:
                    raise BigShieldError(
                        "Request timed out",
                        code="TIMEOUT",
                        status=0,
                    ) from exc
            except httpx.HTTPError as exc:
                last_error = exc
                if attempt == self._retries:
                    raise BigShieldError(
                        f"Network error: {exc}",
                        code="NETWORK_ERROR",
                        status=0,
                    ) from exc

            await asyncio.sleep(0.5 * (2 ** attempt))

        raise last_error  # type: ignore[misc]
