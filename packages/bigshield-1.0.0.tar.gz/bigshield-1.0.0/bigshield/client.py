from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from ._http import HttpClient
from .types import (
    BatchValidateResponse,
    HealthResponse,
    UsageStats,
    ValidationResult,
)


class BigShield:
    """Synchronous BigShield email validation client.

    Usage::

        from bigshield import BigShield

        client = BigShield("ev_live_abc123")
        result = client.validate("user@example.com")
        print(result.risk_score, result.is_valid)
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://www.bigshield.app",
        timeout: float = 30.0,
        retries: int = 2,
    ) -> None:
        if not api_key:
            raise ValueError("API key is required")
        self._http = HttpClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            retries=retries,
        )

    def validate(
        self,
        email: str,
        *,
        wait: bool = False,
        webhook_url: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        ip: Optional[str] = None,
        fingerprint: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> ValidationResult:
        """Validate a single email address.

        Args:
            email: The email address to validate.
            wait: If True, long-poll until Tier 2 signals complete.
            webhook_url: URL to receive a callback when validation completes.
            metadata: Custom metadata to attach to the validation.
            ip: Client IP address for contextual signals.
            fingerprint: Device fingerprint for multi-account detection.
            user_agent: Browser user agent string.

        Returns:
            A ValidationResult with risk score, signals, and recommendation.
        """
        body: Dict[str, Any] = {"email": email}
        if wait:
            body["wait"] = True
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        if metadata is not None:
            body["metadata"] = metadata
        if ip is not None:
            body["ip"] = ip
        if fingerprint is not None:
            body["fingerprint"] = fingerprint
        if user_agent is not None:
            body["user_agent"] = user_agent

        data = self._http.request("POST", "/api/v1/validate", body=body)
        return ValidationResult.from_dict(data)

    def get_validation(self, validation_id: str) -> ValidationResult:
        """Retrieve a validation result by ID.

        Useful for polling Tier 2/3 signal completion after an initial
        ``validate()`` call returns with status ``"partial"``.
        """
        data = self._http.request("GET", f"/api/v1/validate/{validation_id}")
        return ValidationResult.from_dict(data)

    def batch_validate(
        self,
        emails: List[str],
        *,
        webhook_url: Optional[str] = None,
        ip: Optional[str] = None,
        fingerprint: Optional[str] = None,
        user_agent: Optional[str] = None,
    ) -> BatchValidateResponse:
        """Validate multiple email addresses in a single request.

        Maximum batch size depends on your plan (5-100 emails).
        """
        body: Dict[str, Any] = {"emails": emails}
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        if ip is not None:
            body["ip"] = ip
        if fingerprint is not None:
            body["fingerprint"] = fingerprint
        if user_agent is not None:
            body["user_agent"] = user_agent

        data = self._http.request("POST", "/api/v1/validate/batch", body=body)
        return BatchValidateResponse.from_dict(data)

    def get_usage(self) -> UsageStats:
        """Get usage statistics for the current API key."""
        data = self._http.request("GET", "/api/v1/usage")
        return UsageStats.from_dict(data)

    def health(self) -> HealthResponse:
        """Check API health status."""
        data = self._http.request("GET", "/api/v1/health")
        return HealthResponse.from_dict(data)

    def register_webhook(
        self,
        url: str,
        events: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Register a webhook URL for validation completion events."""
        body: Dict[str, Any] = {"url": url}
        if events is not None:
            body["events"] = events
        return self._http.request("POST", "/api/v1/webhooks", body=body)

    def wait_for_completion(
        self,
        validation_id: str,
        *,
        interval: float = 1.0,
        max_attempts: int = 30,
    ) -> ValidationResult:
        """Poll until a validation reaches ``completed`` or ``failed`` status.

        Args:
            validation_id: The validation ID to poll.
            interval: Seconds between polling attempts (default 1.0).
            max_attempts: Maximum number of polling attempts (default 30).

        Returns:
            The final ValidationResult.
        """
        for _ in range(max_attempts):
            result = self.get_validation(validation_id)
            if result.status in ("completed", "failed"):
                return result
            time.sleep(interval)
        return self.get_validation(validation_id)
