from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional


RiskLevel = Literal["very_low", "low", "medium", "high", "very_high"]
Recommendation = Literal["accept", "review", "reject"]
FraudDecision = Literal["allow", "block", "require_verification", "review"]
ValidationStatus = Literal["pending", "partial", "completed", "failed"]
HealthStatus = Literal["ok", "degraded", "down"]


@dataclass
class SignalResult:
    name: str
    tier: str
    score_impact: float
    confidence: float
    description: str
    executed_at: str
    duration_ms: float
    details: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> SignalResult:
        return cls(
            name=data.get("name", ""),
            tier=data.get("tier", ""),
            score_impact=data.get("score_impact", 0),
            confidence=data.get("confidence", 0),
            description=data.get("description", ""),
            executed_at=data.get("executed_at", ""),
            duration_ms=data.get("duration_ms", 0),
            details=data.get("details", {}),
        )


@dataclass
class ValidationResult:
    id: str
    email: str
    status: ValidationStatus
    risk_score: float
    risk_level: RiskLevel
    recommendation: Recommendation
    signals: List[SignalResult]
    created_at: str
    updated_at: str
    fraud_decision: Optional[FraudDecision] = None
    fraud_flags: Optional[List[str]] = None
    tier1_completed_at: Optional[str] = None
    tier2_completed_at: Optional[str] = None
    tier3_completed_at: Optional[str] = None

    @property
    def is_valid(self) -> bool:
        """Returns True if the recommendation is 'accept'."""
        return self.recommendation == "accept"

    @classmethod
    def from_dict(cls, data: dict) -> ValidationResult:
        return cls(
            id=data.get("id", ""),
            email=data.get("email", ""),
            status=data.get("status", "pending"),
            risk_score=data.get("risk_score", 0),
            risk_level=data.get("risk_level", "medium"),
            recommendation=data.get("recommendation", "review"),
            signals=[SignalResult.from_dict(s) for s in data.get("signals", [])],
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
            fraud_decision=data.get("fraud_decision"),
            fraud_flags=data.get("fraud_flags"),
            tier1_completed_at=data.get("tier1_completed_at"),
            tier2_completed_at=data.get("tier2_completed_at"),
            tier3_completed_at=data.get("tier3_completed_at"),
        )


@dataclass
class BatchValidateResponse:
    results: List[ValidationResult]
    total: int
    completed: int

    @classmethod
    def from_dict(cls, data: dict) -> BatchValidateResponse:
        return cls(
            results=[ValidationResult.from_dict(r) for r in data.get("results", [])],
            total=data.get("total", 0),
            completed=data.get("completed", 0),
        )


@dataclass
class UsagePeriod:
    start: str
    end: str


@dataclass
class UsageInfo:
    total: int
    limit: int
    remaining: int


@dataclass
class DailyUsage:
    date: str
    count: int


@dataclass
class UsageStats:
    api_key_prefix: str
    plan: str
    period: UsagePeriod
    usage: UsageInfo
    daily: List[DailyUsage]

    @classmethod
    def from_dict(cls, data: dict) -> UsageStats:
        period = data.get("period", {})
        usage = data.get("usage", {})
        return cls(
            api_key_prefix=data.get("api_key_prefix", ""),
            plan=data.get("plan", ""),
            period=UsagePeriod(start=period.get("start", ""), end=period.get("end", "")),
            usage=UsageInfo(
                total=usage.get("total", 0),
                limit=usage.get("limit", 0),
                remaining=usage.get("remaining", 0),
            ),
            daily=[
                DailyUsage(date=d.get("date", ""), count=d.get("count", 0))
                for d in data.get("daily", [])
            ],
        )


@dataclass
class HealthResponse:
    status: HealthStatus
    version: str
    timestamp: str
    services: Dict[str, str]

    @classmethod
    def from_dict(cls, data: dict) -> HealthResponse:
        return cls(
            status=data.get("status", "down"),
            version=data.get("version", ""),
            timestamp=data.get("timestamp", ""),
            services=data.get("services", {}),
        )
