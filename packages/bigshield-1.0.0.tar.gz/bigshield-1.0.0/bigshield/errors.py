from __future__ import annotations


class BigShieldError(Exception):
    """Base exception for all BigShield API errors."""

    def __init__(
        self,
        message: str,
        code: str = "UNKNOWN_ERROR",
        status: int = 0,
        details: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status = status
        self.details = details or {}


class AuthError(BigShieldError):
    """Raised when the API key is invalid or missing (401)."""

    def __init__(self, message: str = "Invalid or missing API key") -> None:
        super().__init__(message, code="UNAUTHORIZED", status=401)


class RateLimitError(BigShieldError):
    """Raised when the rate limit is exceeded (429)."""

    def __init__(
        self, retry_after: int = 60, message: str = "Rate limit exceeded"
    ) -> None:
        super().__init__(message, code="RATE_LIMIT_EXCEEDED", status=429)
        self.retry_after = retry_after


class ValidationError(BigShieldError):
    """Raised for invalid request parameters (400)."""

    def __init__(self, message: str = "Validation error", details: dict | None = None) -> None:
        super().__init__(message, code="VALIDATION_ERROR", status=400, details=details)
