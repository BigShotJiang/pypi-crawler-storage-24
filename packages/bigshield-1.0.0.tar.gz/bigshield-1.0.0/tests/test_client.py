import pytest
import httpx
import respx

from bigshield import (
    BigShield,
    AsyncBigShield,
    AuthError,
    BigShieldError,
    RateLimitError,
    ValidationError,
)

BASE = "https://www.bigshield.app"

VALIDATE_RESPONSE = {
    "id": "val_123",
    "email": "test@example.com",
    "status": "completed",
    "risk_score": 22,
    "risk_level": "low",
    "recommendation": "accept",
    "signals": [
        {
            "name": "syntax_check",
            "tier": "Tier 1",
            "score_impact": -5,
            "confidence": 1.0,
            "description": "Valid email syntax",
            "executed_at": "2026-03-01T00:00:00Z",
            "duration_ms": 1.2,
        }
    ],
    "created_at": "2026-03-01T00:00:00Z",
    "updated_at": "2026-03-01T00:00:00Z",
}


# --- Constructor ---


def test_api_key_required():
    with pytest.raises(ValueError, match="API key is required"):
        BigShield("")


def test_api_key_required_async():
    with pytest.raises(ValueError, match="API key is required"):
        AsyncBigShield("")


# --- Sync client ---


@respx.mock
def test_validate():
    respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(200, json=VALIDATE_RESPONSE)
    )
    client = BigShield("ev_test_abc", retries=0)
    result = client.validate("test@example.com")

    assert result.id == "val_123"
    assert result.risk_score == 22
    assert result.is_valid is True
    assert result.recommendation == "accept"
    assert len(result.signals) == 1
    assert result.signals[0].name == "syntax_check"


@respx.mock
def test_validate_with_options():
    route = respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(200, json=VALIDATE_RESPONSE)
    )
    client = BigShield("ev_test_abc", retries=0)
    client.validate(
        "test@example.com",
        wait=True,
        ip="1.2.3.4",
        fingerprint="fp_abc",
        user_agent="Mozilla/5.0",
    )

    sent_body = route.calls[0].request.content
    import json

    body = json.loads(sent_body)
    assert body["email"] == "test@example.com"
    assert body["wait"] is True
    assert body["ip"] == "1.2.3.4"
    assert body["fingerprint"] == "fp_abc"
    assert body["user_agent"] == "Mozilla/5.0"


@respx.mock
def test_validate_sends_auth_header():
    route = respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(200, json=VALIDATE_RESPONSE)
    )
    client = BigShield("ev_test_secret", retries=0)
    client.validate("test@example.com")

    assert route.calls[0].request.headers["Authorization"] == "Bearer ev_test_secret"


@respx.mock
def test_get_validation():
    respx.get(f"{BASE}/api/v1/validate/val_123").mock(
        return_value=httpx.Response(200, json=VALIDATE_RESPONSE)
    )
    client = BigShield("ev_test_abc", retries=0)
    result = client.get_validation("val_123")
    assert result.id == "val_123"


@respx.mock
def test_batch_validate():
    batch_response = {
        "results": [VALIDATE_RESPONSE],
        "total": 1,
        "completed": 1,
    }
    respx.post(f"{BASE}/api/v1/validate/batch").mock(
        return_value=httpx.Response(200, json=batch_response)
    )
    client = BigShield("ev_test_abc", retries=0)
    result = client.batch_validate(["test@example.com"])
    assert result.total == 1
    assert result.completed == 1
    assert len(result.results) == 1


@respx.mock
def test_get_usage():
    usage_response = {
        "api_key_prefix": "ev_test_abc...",
        "plan": "starter",
        "period": {"start": "2026-03-01", "end": "2026-03-31"},
        "usage": {"total": 150, "limit": 1000, "remaining": 850},
        "daily": [{"date": "2026-03-01", "count": 50}],
    }
    respx.get(f"{BASE}/api/v1/usage").mock(
        return_value=httpx.Response(200, json=usage_response)
    )
    client = BigShield("ev_test_abc", retries=0)
    usage = client.get_usage()
    assert usage.plan == "starter"
    assert usage.usage.remaining == 850
    assert len(usage.daily) == 1


@respx.mock
def test_health():
    health_response = {
        "status": "ok",
        "version": "1.0.0",
        "timestamp": "2026-03-01T00:00:00Z",
        "services": {"database": "ok", "redis": "ok"},
    }
    respx.get(f"{BASE}/api/v1/health").mock(
        return_value=httpx.Response(200, json=health_response)
    )
    client = BigShield("ev_test_abc", retries=0)
    result = client.health()
    assert result.status == "ok"
    assert result.services["redis"] == "ok"


# --- Error handling ---


@respx.mock
def test_auth_error():
    respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(401, json={"error": "Invalid API key"})
    )
    client = BigShield("ev_test_bad", retries=0)
    with pytest.raises(AuthError):
        client.validate("test@example.com")


@respx.mock
def test_rate_limit_error():
    respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(
            429,
            json={"error": "Rate limit exceeded"},
            headers={"Retry-After": "30"},
        )
    )
    client = BigShield("ev_test_abc", retries=0)
    with pytest.raises(RateLimitError) as exc_info:
        client.validate("test@example.com")
    assert exc_info.value.retry_after == 30


@respx.mock
def test_validation_error():
    respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(400, json={"error": "Invalid email format"})
    )
    client = BigShield("ev_test_abc", retries=0)
    with pytest.raises(ValidationError):
        client.validate("not-an-email")


@respx.mock
def test_server_error():
    respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(500, json={"error": "Internal server error"})
    )
    client = BigShield("ev_test_abc", retries=0)
    with pytest.raises(BigShieldError):
        client.validate("test@example.com")


@respx.mock
def test_custom_base_url():
    respx.post("https://custom.api.com/api/v1/validate").mock(
        return_value=httpx.Response(200, json=VALIDATE_RESPONSE)
    )
    client = BigShield("ev_test_abc", base_url="https://custom.api.com", retries=0)
    result = client.validate("test@example.com")
    assert result.id == "val_123"


# --- Async client ---


@respx.mock
@pytest.mark.asyncio
async def test_async_validate():
    respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(200, json=VALIDATE_RESPONSE)
    )
    client = AsyncBigShield("ev_test_abc", retries=0)
    result = await client.validate("test@example.com")
    assert result.id == "val_123"
    assert result.is_valid is True


@respx.mock
@pytest.mark.asyncio
async def test_async_auth_error():
    respx.post(f"{BASE}/api/v1/validate").mock(
        return_value=httpx.Response(401, json={"error": "Bad key"})
    )
    client = AsyncBigShield("ev_test_bad", retries=0)
    with pytest.raises(AuthError):
        await client.validate("test@example.com")


@respx.mock
@pytest.mark.asyncio
async def test_async_batch():
    batch_response = {
        "results": [VALIDATE_RESPONSE],
        "total": 1,
        "completed": 1,
    }
    respx.post(f"{BASE}/api/v1/validate/batch").mock(
        return_value=httpx.Response(200, json=batch_response)
    )
    client = AsyncBigShield("ev_test_abc", retries=0)
    result = await client.batch_validate(["test@example.com"])
    assert result.total == 1
