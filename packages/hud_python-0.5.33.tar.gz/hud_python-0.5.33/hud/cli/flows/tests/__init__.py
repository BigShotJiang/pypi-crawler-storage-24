"""Tests for CLI flows."""
