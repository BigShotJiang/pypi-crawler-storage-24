"""simlab - A Python package."""

__version__ = "0.0.1"
