"""
Lean and effective tests for deposition module.

Focus on:
1. Exact analytical solutions
2. Perfect roundtrip consistency
3. Clean edge cases with exact comparisons
"""

import warnings

import numpy as np
import pandas as pd
import pytest

from gwtransport.deposition import (
    compute_deposition_weights,
    deposition_to_extraction,
    extraction_to_deposition,
    extraction_to_deposition_full,
    spinup_duration,
)
from gwtransport.examples import generate_example_data, generate_example_deposition_timeseries
from gwtransport.residence_time import residence_time
from gwtransport.utils import compute_time_edges, solve_underdetermined_system


def test_exact_analytical_constant_deposition():
    """
    Test exact analytical solution: C = (residence_time * deposition_rate) / (porosity * thickness)

    Uses constant flow and deposition for exact solution.
    """
    # Simple setup for exact calculation
    dates = pd.date_range("2020-01-01", "2020-01-10", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 500.0,  # m³
        "porosity": 0.25,  # dimensionless
        "thickness": 4.0,  # m
        "retardation_factor": 1.0,
    }

    # Constant inputs for exact solution
    deposition_rate = 100.0  # ng/m²/day
    flow_rate = 100.0  # m³/day → residence time = 500/100 = 5 days

    dep_values = np.full(len(dates), deposition_rate)
    flow_values = np.full(len(dates), flow_rate)

    # Output after sufficient time for steady state
    cout_tedges = tedges[7:9]  # 2 edges for 1 output

    # Calculate actual concentration
    cout_result = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )

    # Calculate expected using exact formula
    rt = residence_time(
        flow=flow_values,
        flow_tedges=tedges,
        index=cout_tedges,
        aquifer_pore_volumes=params["aquifer_pore_volume"],
        retardation_factor=params["retardation_factor"],
        direction="extraction_to_infiltration",
    )

    expected = (rt[0] * deposition_rate) / (params["porosity"] * params["thickness"])

    # Exact comparison
    valid_result = cout_result[~np.isnan(cout_result)]
    valid_expected = expected[: len(valid_result)]

    assert len(valid_result) >= 1, "Must have at least one valid result"

    for actual, exp in zip(valid_result, valid_expected, strict=False):
        rel_error = abs(actual - exp) / exp
        assert rel_error < 1e-12, f"Expected {exp:.12f}, got {actual:.12f}, rel_error={rel_error:.2e}"


def test_exact_analytical_varying_flow():
    """
    Test exact analytical solution with time-varying flow.
    """
    dates = pd.date_range("2020-01-01", "2020-01-08", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 300.0,
        "porosity": 0.3,
        "thickness": 5.0,
        "retardation_factor": 1.0,
    }

    # Variable flow rates
    flow_values = np.array([50.0, 75.0, 100.0, 100.0, 100.0, 100.0, 100.0, 100.0])
    deposition_rate = 60.0
    dep_values = np.full(len(dates), deposition_rate)

    cout_tedges = tedges[5:7]  # Test in stable period

    cout_result = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )

    # Calculate expected using exact residence time
    rt = residence_time(
        flow=flow_values,
        flow_tedges=tedges,
        index=cout_tedges,
        aquifer_pore_volumes=params["aquifer_pore_volume"],
        retardation_factor=params["retardation_factor"],
        direction="extraction_to_infiltration",
    )

    expected = (rt[0] * deposition_rate) / (params["porosity"] * params["thickness"])

    valid_result = cout_result[~np.isnan(cout_result)]
    valid_expected = expected[: len(valid_result)]

    if len(valid_result) >= 1:
        for actual, exp in zip(valid_result, valid_expected, strict=False):
            rel_error = abs(actual - exp) / exp
            # Slightly relaxed tolerance for varying flow
            assert rel_error < 1e-6, f"Expected {exp:.6f}, got {actual:.6f}, rel_error={rel_error:.2e}"


def test_exact_analytical_retardation_factor():
    """
    Test exact analytical solution with different retardation factors.
    """
    dates = pd.date_range("2020-01-01", "2020-01-12", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    base_params = {
        "aquifer_pore_volume": 400.0,
        "porosity": 0.2,
        "thickness": 8.0,
    }

    deposition_rate = 50.0
    flow_rate = 100.0
    dep_values = np.full(len(dates), deposition_rate)
    flow_values = np.full(len(dates), flow_rate)

    cout_tedges = tedges[8:10]  # Test in later period

    # Test different retardation factors
    for retardation_factor in [1.0, 1.5, 2.0]:
        params = {**base_params, "retardation_factor": retardation_factor}

        cout_result = deposition_to_extraction(
            dep=dep_values,
            flow=flow_values,
            tedges=tedges,
            cout_tedges=cout_tedges,
            aquifer_pore_volume=params["aquifer_pore_volume"],
            porosity=params["porosity"],
            thickness=params["thickness"],
            retardation_factor=params["retardation_factor"],
        )

        rt = residence_time(
            flow=flow_values,
            flow_tedges=tedges,
            index=cout_tedges,
            aquifer_pore_volumes=params["aquifer_pore_volume"],
            retardation_factor=retardation_factor,
            direction="extraction_to_infiltration",
        )

        expected = (rt[0] * deposition_rate) / (params["porosity"] * params["thickness"])

        valid_result = cout_result[~np.isnan(cout_result)]
        valid_expected = expected[: len(valid_result)]

        if len(valid_result) >= 1:
            for actual, exp in zip(valid_result, valid_expected, strict=False):
                rel_error = abs(actual - exp) / exp
                assert rel_error < 1e-12, f"R={retardation_factor}: Expected {exp:.12f}, got {actual:.12f}"


def test_perfect_roundtrip_varying_deposition_short():
    """Roundtrip with varying deposition on a short time series.

    Uses half-day cout resolution to create an overdetermined system and
    non-integer RT/dt to avoid structural rank deficiency, achieving
    machine precision on per-element recovery.
    """
    dates = pd.date_range("2020-01-01", "2020-01-08", freq="D")  # 8 days
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 350.0,  # RT = 3.5 days (non-integer avoids rank deficiency)
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    original_deposition = np.array([10.0, 20.0, 30.0, 25.0, 15.0, 35.0, 40.0, 30.0])
    flow_values = np.full(len(dates), 100.0)

    # Half-day cout resolution → overdetermined system
    cout_dates = pd.date_range("2020-01-01", "2020-01-08", freq="12h")
    cout_tedges = compute_time_edges(tedges=None, tstart=None, tend=cout_dates, number_of_bins=len(cout_dates))

    concentration = deposition_to_extraction(
        dep=original_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    recovered_deposition = extraction_to_deposition(
        cout=concentration,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        regularization_strength=1e-20,
        **params,
    )

    valid = ~np.isnan(recovered_deposition)
    assert valid.sum() == len(original_deposition)

    np.testing.assert_allclose(
        recovered_deposition[valid],
        original_deposition[valid],
        atol=1e-10,
        rtol=1e-10,
    )


def test_perfect_roundtrip_constant_deposition():
    """Roundtrip with constant deposition.

    Uses half-day cout resolution to create an overdetermined system.
    Constant deposition is always in the column space (even with integer
    RT/dt), so machine precision is achievable.
    """
    dates = pd.date_range("2020-01-01", "2020-01-08", freq="D")  # 8 days
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 350.0,  # RT = 3.5 days (non-integer)
        "porosity": 0.2,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    original_deposition = np.full(len(dates), 25.0)
    flow_values = np.full(len(dates), 100.0)

    # Half-day cout resolution → overdetermined system
    cout_dates = pd.date_range("2020-01-01", "2020-01-08", freq="12h")
    cout_tedges = compute_time_edges(tedges=None, tstart=None, tend=cout_dates, number_of_bins=len(cout_dates))

    concentration = deposition_to_extraction(
        dep=original_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    recovered_deposition = extraction_to_deposition(
        cout=concentration,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        regularization_strength=1e-20,
        **params,
    )

    valid_mask = ~np.isnan(recovered_deposition)
    np.testing.assert_allclose(
        recovered_deposition[valid_mask],
        original_deposition[valid_mask],
        atol=1e-10,
        rtol=1e-10,
    )


def test_zero_deposition_zero_concentration():
    """Zero deposition must produce exactly zero concentration."""
    dates = pd.date_range("2020-01-01", "2020-01-06", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 300.0,
        "porosity": 0.3,
        "thickness": 5.0,
        "retardation_factor": 1.0,
    }

    dep_values = np.zeros(len(dates))
    flow_values = np.full(len(dates), 100.0)
    cout_tedges = tedges[2:5]

    cout_result = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )

    valid_results = cout_result[~np.isnan(cout_result)]
    if len(valid_results) > 0:
        assert np.allclose(valid_results, 0.0, atol=1e-15), "Zero deposition must give exactly zero concentration"


def test_linearity_exact():
    """Test exact linearity: doubling input exactly doubles output."""
    dates = pd.date_range("2020-01-01", "2020-01-08", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 320.0,
        "porosity": 0.2,
        "thickness": 8.0,
        "retardation_factor": 1.0,
    }

    base_deposition = np.full(len(dates), 20.0)
    double_deposition = 2.0 * base_deposition
    flow_values = np.full(len(dates), 80.0)
    cout_tedges = tedges[4:7]

    # Test both directions
    cout_base = deposition_to_extraction(
        dep=base_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )
    cout_double = deposition_to_extraction(
        dep=double_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )

    valid_base = cout_base[~np.isnan(cout_base)]
    valid_double = cout_double[~np.isnan(cout_double)]

    min_len = min(len(valid_base), len(valid_double))
    if min_len >= 1:
        for i in range(min_len):
            expected_double = 2.0 * valid_base[i]
            rel_error = abs(valid_double[i] - expected_double) / max(abs(expected_double), 1e-12)
            assert rel_error < 1e-12, f"Linearity failed: 2×{valid_base[i]:.6f} ≠ {valid_double[i]:.6f}"


def test_negative_deposition_linearity():
    """Test that negative deposition produces exactly negative concentration."""
    dates = pd.date_range("2020-01-01", "2020-01-06", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 240.0,
        "porosity": 0.3,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    positive_dep = np.full(len(dates), 30.0)
    negative_dep = -positive_dep
    flow_values = np.full(len(dates), 60.0)
    cout_tedges = tedges[3:5]

    cout_positive = deposition_to_extraction(
        dep=positive_dep,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )
    cout_negative = deposition_to_extraction(
        dep=negative_dep,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )

    valid_pos = cout_positive[~np.isnan(cout_positive)]
    valid_neg = cout_negative[~np.isnan(cout_negative)]

    min_len = min(len(valid_pos), len(valid_neg))
    if min_len >= 1:
        for i in range(min_len):
            expected_negative = -valid_pos[i]
            rel_error = abs(valid_neg[i] - expected_negative) / max(abs(expected_negative), 1e-12)
            assert rel_error < 1e-12, f"Sign reversal failed: -{valid_pos[i]:.6f} ≠ {valid_neg[i]:.6f}"


def test_parameter_scaling_exact():
    """Test exact scaling relationships for porosity and thickness."""
    dates = pd.date_range("2020-01-01", "2020-01-06", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    base_params = {
        "aquifer_pore_volume": 200.0,
        "retardation_factor": 1.0,
    }

    deposition_rate = 40.0
    flow_rate = 50.0
    dep_values = np.full(len(dates), deposition_rate)
    flow_values = np.full(len(dates), flow_rate)
    cout_tedges = tedges[3:5]

    # Test porosity scaling (concentration ∝ 1/porosity)
    porosity_1 = 0.2
    porosity_2 = 0.4  # Double the porosity

    params_1 = {**base_params, "porosity": porosity_1, "thickness": 5.0}
    params_2 = {**base_params, "porosity": porosity_2, "thickness": 5.0}

    cout_1 = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params_1["aquifer_pore_volume"],
        porosity=params_1["porosity"],
        thickness=params_1["thickness"],
        retardation_factor=params_1["retardation_factor"],
    )
    cout_2 = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=params_2["aquifer_pore_volume"],
        porosity=params_2["porosity"],
        thickness=params_2["thickness"],
        retardation_factor=params_2["retardation_factor"],
    )

    valid_1 = cout_1[~np.isnan(cout_1)]
    valid_2 = cout_2[~np.isnan(cout_2)]

    min_len = min(len(valid_1), len(valid_2))
    if min_len >= 1:
        for i in range(min_len):
            ratio = valid_1[i] / valid_2[i]
            expected_ratio = porosity_2 / porosity_1  # Should be 2.0
            rel_error = abs(ratio - expected_ratio) / expected_ratio
            assert rel_error < 1e-10, f"Porosity scaling failed: ratio={ratio:.6f}, expected={expected_ratio:.6f}"


def test_input_validation():
    """Test input validation with exact error messages."""
    dates = pd.date_range("2020-01-01", "2020-01-04", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 200.0,
        "porosity": 0.3,
        "thickness": 5.0,
        "retardation_factor": 1.0,
    }

    # Test tedges length mismatch
    with pytest.raises(ValueError, match="tedges must have one more element than flow"):
        deposition_to_extraction(
            dep=np.ones(3),
            flow=np.ones(4),
            tedges=tedges[:4],
            cout_tedges=tedges[1:3],
            aquifer_pore_volume=params["aquifer_pore_volume"],
            porosity=params["porosity"],
            thickness=params["thickness"],
            retardation_factor=params["retardation_factor"],
        )

    # Test cout_tedges length mismatch in extraction_to_deposition
    with pytest.raises(ValueError, match="cout_tedges must have one more element than cout"):
        extraction_to_deposition(
            cout=np.ones(3),
            flow=np.ones(3),
            tedges=tedges[:4],
            cout_tedges=tedges[:3],
            aquifer_pore_volume=params["aquifer_pore_volume"],
            porosity=params["porosity"],
            thickness=params["thickness"],
            retardation_factor=params["retardation_factor"],
        )

    # Test NaN in flow (should be rejected)
    flow_with_nan = np.array([50.0, np.nan, 60.0])
    with pytest.raises(ValueError, match="flow array cannot contain NaN values"):
        extraction_to_deposition(
            cout=np.ones(2),
            flow=flow_with_nan,
            tedges=tedges[:4],
            cout_tedges=tedges[1:4],
            aquifer_pore_volume=params["aquifer_pore_volume"],
            porosity=params["porosity"],
            thickness=params["thickness"],
            retardation_factor=params["retardation_factor"],
        )


def test_rank_deficiency_warning():
    """Warning is raised when weight matrix is rank-deficient (integer RT/dt)."""
    dates = pd.date_range("2020-01-01", "2020-01-08", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 400.0,  # RT = 400/100 = 4.0 days (integer)
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }
    flow_values = np.full(len(dates), 100.0)
    cout_tedges = tedges

    cout = deposition_to_extraction(
        dep=np.full(len(dates), 25.0),
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    with pytest.warns(UserWarning, match="rank-deficient"):
        extraction_to_deposition(
            cout=cout,
            flow=flow_values,
            tedges=tedges,
            cout_tedges=cout_tedges,
            **params,
        )


def test_no_rank_deficiency_warning_non_integer_rt():
    """No warning when RT/dt is non-integer."""
    dates = pd.date_range("2020-01-01", "2020-01-08", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 350.0,  # RT = 350/100 = 3.5 days (non-integer)
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }
    flow_values = np.full(len(dates), 100.0)

    cout_dates = pd.date_range("2020-01-01", "2020-01-08", freq="12h")
    cout_tedges = compute_time_edges(tedges=None, tstart=None, tend=cout_dates, number_of_bins=len(cout_dates))

    cout = deposition_to_extraction(
        dep=np.full(len(dates), 25.0),
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    with warnings.catch_warnings():
        warnings.simplefilter("error")
        extraction_to_deposition(
            cout=cout,
            flow=flow_values,
            tedges=tedges,
            cout_tedges=cout_tedges,
            **params,
        )


def test_regularization_objectives():
    """Test different nullspace regularization objectives work correctly."""
    # This test verifies the solver correctly handles different objectives
    # by testing that squared_differences objective works properly
    # Create a simple underdetermined system (2 equations, 4 unknowns)
    matrix = np.array([[1.0, 2.0, 1.0, 0.0], [0.0, 1.0, 2.0, 1.0]])
    rhs = np.array([5.0, 4.0])

    # Test that squared differences objective works
    result = solve_underdetermined_system(
        coefficient_matrix=matrix, rhs_vector=rhs, nullspace_objective="squared_differences"
    )

    # Should satisfy the original equations
    assert np.allclose(matrix @ result, rhs, atol=1e-10), "Solution should satisfy Ax=b"

    # Should be finite and reasonable
    assert np.all(np.isfinite(result)), "Solution should be finite"
    assert np.max(np.abs(result)) < 100, "Solution should be reasonable magnitude"


def test_extraction_to_deposition_full_default():
    """Test extraction_to_deposition_full with default nullspace objective."""
    dates = pd.date_range("2020-01-01", "2020-01-08", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 400.0,
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    original_deposition = np.full(len(dates), 25.0)
    flow_values = np.full(len(dates), 100.0)
    cout_tedges = tedges[3:]

    concentration = deposition_to_extraction(
        dep=original_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    recovered = extraction_to_deposition_full(
        cout=concentration,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    assert recovered.shape == original_deposition.shape
    assert np.all(np.isfinite(recovered))


def test_extraction_to_deposition_full_objectives():
    """Test extraction_to_deposition_full with different nullspace objectives."""
    dates = pd.date_range("2020-01-01", "2020-01-06", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 300.0,
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    original_deposition = np.full(len(dates), 20.0)
    flow_values = np.full(len(dates), 100.0)
    cout_tedges = tedges[2:]

    concentration = deposition_to_extraction(
        dep=original_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    for objective, method in [("squared_differences", "BFGS"), ("summed_differences", "Nelder-Mead")]:
        recovered = extraction_to_deposition_full(
            cout=concentration,
            flow=flow_values,
            tedges=tedges,
            cout_tedges=cout_tedges,
            nullspace_objective=objective,
            optimization_method=method,
            **params,
        )
        assert np.all(np.isfinite(recovered)), f"Failed for objective={objective}"


def test_extraction_to_deposition_full_with_rcond():
    """Test extraction_to_deposition_full with rcond parameter."""
    dates = pd.date_range("2020-01-01", "2020-01-06", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 300.0,
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    original_deposition = np.full(len(dates), 20.0)
    flow_values = np.full(len(dates), 100.0)
    cout_tedges = tedges[2:]

    concentration = deposition_to_extraction(
        dep=original_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    recovered = extraction_to_deposition_full(
        cout=concentration,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        rcond=1e-10,
        **params,
    )

    assert recovered.shape == original_deposition.shape
    assert np.all(np.isfinite(recovered))


def test_roundtrip_varying_deposition():
    """Roundtrip with sinusoidal deposition on a longer time series.

    Uses half-day cout resolution for an overdetermined system and
    non-integer RT/dt to ensure full rank. Verifies per-element recovery
    to machine precision.
    """
    dates = pd.date_range("2020-01-01", "2020-02-01", freq="D")
    tedges = compute_time_edges(tedges=None, tstart=None, tend=dates, number_of_bins=len(dates))

    params = {
        "aquifer_pore_volume": 350.0,  # RT = 3.5 days (non-integer)
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    t = np.arange(len(dates), dtype=float)
    original_deposition = 20.0 + 10.0 * np.sin(2 * np.pi * t / len(dates))
    flow_values = np.full(len(dates), 100.0)

    # Half-day cout resolution → overdetermined system
    cout_dates = pd.date_range("2020-01-01", "2020-02-01", freq="12h")
    cout_tedges = compute_time_edges(tedges=None, tstart=None, tend=cout_dates, number_of_bins=len(cout_dates))

    concentration = deposition_to_extraction(
        dep=original_deposition,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    recovered = extraction_to_deposition(
        cout=concentration,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        regularization_strength=1e-20,
        **params,
    )

    valid = ~np.isnan(recovered)
    assert valid.sum() == len(original_deposition)

    np.testing.assert_allclose(
        recovered[valid],
        original_deposition[valid],
        atol=1e-10,
        rtol=1e-10,
    )


def test_extraction_to_deposition_sparse_weekly_sampling():
    """
    Test extraction_to_deposition with sparse weekly sampling using exact notebook data.

    Note: This test documents that while the notebook shows a failure with weekly
    cout_tedges, the solver is more robust in the test environment and can handle
    the same conditions successfully. This demonstrates the solver's capability
    to handle challenging underdetermined systems.
    """
    # Set same random seed as notebook
    np.random.seed(42)

    # Generate exact same data as notebook
    date_start = "2020-01-01"
    date_end = "2022-12-31"
    freq = "D"

    # Generate example flow data (same as notebook)
    example_df, _ = generate_example_data(date_start=date_start, date_end=date_end, date_freq=freq)
    flow_series = example_df["flow"]

    # Generate example deposition data with same parameters as notebook
    event_dates = pd.to_datetime(["2020-06-15", "2021-03-20", "2021-09-10", "2022-07-05"]).tz_localize("UTC")
    deposition_series, deposition_tedges = generate_example_deposition_timeseries(
        date_start=date_start,
        date_end=date_end,
        seasonal_amplitude=0.3,
        noise_scale=0.1,
        event_magnitude=3.0,
        event_duration=30,
        event_decay_scale=10.0,
        event_dates=event_dates,
        ensure_non_negative=True,
    )

    # Use exact same parameters as notebook
    aquifer_pore_volume = example_df.attrs["aquifer_pore_volume_gamma_mean"]
    retardation_factor = example_df.attrs["retardation_factor"]
    porosity = 0.25
    thickness = 12.0

    params = {
        "aquifer_pore_volume": aquifer_pore_volume,
        "porosity": porosity,
        "thickness": thickness,
        "retardation_factor": retardation_factor,
    }

    # Test weekly sampling (similar to notebook case that fails)
    weekly_extraction_dates = pd.date_range("2020-01-01", "2022-12-31", freq="7D").tz_localize("UTC")
    weekly_cout_tedges = compute_time_edges(
        tedges=None, tstart=None, tend=weekly_extraction_dates, number_of_bins=len(weekly_extraction_dates)
    )

    # Generate weekly concentrations using forward modeling
    weekly_concentrations = deposition_to_extraction(
        dep=deposition_series.values,
        flow=flow_series.values,
        tedges=deposition_tedges,
        cout_tedges=weekly_cout_tedges,
        aquifer_pore_volume=params["aquifer_pore_volume"],
        porosity=params["porosity"],
        thickness=params["thickness"],
        retardation_factor=params["retardation_factor"],
    )

    # Prepare flow data for inverse modeling
    weekly_flow_for_inverse = flow_series.reindex(weekly_extraction_dates, method="nearest").values

    # Test weekly inverse modeling - this should fail like in the notebook
    # The key is using weekly_cout_tedges for both tedges and cout_tedges
    # Should converge successfully in test environment.
    # Rank-deficiency warning is expected for this challenging system.
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        _ = extraction_to_deposition(
            cout=weekly_concentrations,
            flow=weekly_flow_for_inverse,
            tedges=weekly_cout_tedges,
            cout_tedges=weekly_cout_tedges,
            aquifer_pore_volume=params["aquifer_pore_volume"],
            porosity=params["porosity"],
            thickness=params["thickness"],
            retardation_factor=params["retardation_factor"],
        )

    # Document that this test covers the same scenario as the notebook failure
    assert len(weekly_extraction_dates) == 157, "Should have 157 weekly samples like in notebook"
    assert len(weekly_cout_tedges) == 158, "Should have 158 weekly edges (157 + 1)"


# =============================================================================
# Tests for spinup_duration function (CRITICAL COVERAGE GAP)
# =============================================================================


def test_spinup_duration_constant_flow():
    """Test spinup_duration with constant flow."""
    dates = pd.date_range(start="2020-01-01", periods=100, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=101, freq="D")
    flow = np.ones(len(dates)) * 100.0  # m³/day
    pore_volume = 5000.0  # m³
    retardation_factor = 1.0

    duration = spinup_duration(
        flow=flow, flow_tedges=tedges, aquifer_pore_volume=pore_volume, retardation_factor=retardation_factor
    )

    # Spinup should equal residence time at first time point
    # RT = pore_volume * retardation / flow = 5000 * 1.0 / 100 = 50 days
    expected_duration = pore_volume * retardation_factor / flow[0]
    assert duration == pytest.approx(expected_duration, rel=0.01)


def test_spinup_duration_with_retardation():
    """Test spinup_duration with retardation factor > 1."""
    # RT = 5000 * 2.0 / 100 = 100 days, so need at least 100 days of flow history
    dates = pd.date_range(start="2020-01-01", periods=150, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=151, freq="D")
    flow = np.ones(len(dates)) * 100.0
    pore_volume = 5000.0
    retardation_factor = 2.0  # Temperature transport

    duration = spinup_duration(
        flow=flow, flow_tedges=tedges, aquifer_pore_volume=pore_volume, retardation_factor=retardation_factor
    )

    # Spinup should be longer with retardation
    # RT = 5000 * 2.0 / 100 = 100 days
    expected_duration = pore_volume * retardation_factor / flow[0]
    assert duration == pytest.approx(expected_duration, rel=0.01)
    assert duration > 50.0  # Longer than without retardation


def test_spinup_duration_high_flow():
    """Test spinup_duration with high flow (short spinup)."""
    dates = pd.date_range(start="2020-01-01", periods=100, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=101, freq="D")
    flow = np.ones(len(dates)) * 500.0  # High flow
    pore_volume = 5000.0
    retardation_factor = 1.0

    duration = spinup_duration(
        flow=flow, flow_tedges=tedges, aquifer_pore_volume=pore_volume, retardation_factor=retardation_factor
    )

    # RT = 5000 * 1.0 / 500 = 10 days
    expected_duration = pore_volume * retardation_factor / flow[0]
    assert duration == pytest.approx(expected_duration, rel=0.01)
    assert duration < 20.0  # Short spinup with high flow


def test_spinup_duration_low_flow():
    """Test spinup_duration with low flow (long spinup)."""
    # RT = 5000 * 1.0 / 20 = 250 days, so need at least 250 days of flow history
    dates = pd.date_range(start="2020-01-01", periods=300, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=301, freq="D")
    flow = np.ones(len(dates)) * 20.0  # Low flow
    pore_volume = 5000.0
    retardation_factor = 1.0

    duration = spinup_duration(
        flow=flow, flow_tedges=tedges, aquifer_pore_volume=pore_volume, retardation_factor=retardation_factor
    )

    # RT = 5000 * 1.0 / 20 = 250 days
    expected_duration = pore_volume * retardation_factor / flow[0]
    assert duration == pytest.approx(expected_duration, rel=0.01)
    assert duration > 200.0  # Long spinup with low flow


def test_spinup_duration_large_pore_volume():
    """Test spinup_duration with large pore volume."""
    # RT = 20000 * 1.5 / 100 = 300 days, so need at least 300 days of flow history
    dates = pd.date_range(start="2020-01-01", periods=400, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=401, freq="D")
    flow = np.ones(len(dates)) * 100.0
    pore_volume = 20000.0  # Large aquifer
    retardation_factor = 1.5

    duration = spinup_duration(
        flow=flow, flow_tedges=tedges, aquifer_pore_volume=pore_volume, retardation_factor=retardation_factor
    )

    # RT = 20000 * 1.5 / 100 = 300 days
    expected_duration = pore_volume * retardation_factor / flow[0]
    assert duration == pytest.approx(expected_duration, rel=0.01)


# =============================================================================
# Tests for compute_deposition_weights function (MEDIUM PRIORITY)
# =============================================================================


def test_compute_deposition_weights_structure():
    """Test that compute_deposition_weights produces correct matrix structure."""
    dates = pd.date_range(start="2020-01-01", periods=50, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=51, freq="D")
    # Start output after residence time: RT = 500/100 = 5 days
    cout_tedges = pd.date_range(start="2020-01-08", periods=41, freq="D")

    flow = np.ones(len(dates)) * 100.0
    aquifer_pore_volume = 500.0  # RT = 500/100 = 5 days
    porosity = 0.35
    thickness = 3.0
    retardation_factor = 1.0

    weights = compute_deposition_weights(
        flow=flow,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=aquifer_pore_volume,
        porosity=porosity,
        thickness=thickness,
        retardation_factor=retardation_factor,
    )

    # Verify shape
    assert weights.shape == (len(cout_tedges) - 1, len(tedges) - 1)
    assert weights.shape == (40, 50)

    # Verify all weights are non-negative
    assert np.all(weights >= 0.0)

    # Verify weights are finite
    assert np.all(np.isfinite(weights))


def test_compute_deposition_weights_causality():
    """Test that weight matrix respects causality (temporal ordering)."""
    dates = pd.date_range(start="2020-01-01", periods=50, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=51, freq="D")
    # Start output after residence time: RT = 500/100 = 5 days
    cout_tedges = pd.date_range(start="2020-01-08", periods=31, freq="D")

    flow = np.ones(len(dates)) * 100.0
    aquifer_pore_volume = 500.0  # RT = 500/100 = 5 days
    porosity = 0.35
    thickness = 3.0
    retardation_factor = 1.0

    weights = compute_deposition_weights(
        flow=flow,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=aquifer_pore_volume,
        porosity=porosity,
        thickness=thickness,
        retardation_factor=retardation_factor,
    )

    # Weights should have a roughly diagonal structure
    # (deposition at time t contributes to extraction near time t + residence_time)
    # Most weight should be concentrated near the diagonal-like region
    total_weight = np.sum(weights)
    assert total_weight > 0.0


def test_compute_deposition_weights_with_retardation():
    """Test compute_deposition_weights with different retardation factors."""
    dates = pd.date_range(start="2020-01-01", periods=50, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=51, freq="D")
    # Start output after residence time with retardation
    cout_tedges = pd.date_range(start="2020-01-12", periods=31, freq="D")

    flow = np.ones(len(dates)) * 100.0
    aquifer_pore_volume = 5000.0
    porosity = 0.35
    thickness = 3.0

    # Test with R=1.0
    weights_r1 = compute_deposition_weights(
        flow=flow,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=aquifer_pore_volume,
        porosity=porosity,
        thickness=thickness,
        retardation_factor=1.0,
    )

    # Test with R=2.0 (more retardation)
    weights_r2 = compute_deposition_weights(
        flow=flow,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=aquifer_pore_volume,
        porosity=porosity,
        thickness=thickness,
        retardation_factor=2.0,
    )

    # Shapes should be the same
    assert weights_r1.shape == weights_r2.shape

    # Weight patterns should be different
    assert not np.allclose(weights_r1, weights_r2)


def test_compute_deposition_weights_porosity_effect():
    """Test that porosity affects contact area calculation in weights."""
    dates = pd.date_range(start="2020-01-01", periods=50, freq="D")
    tedges = pd.date_range(start="2020-01-01", periods=51, freq="D")
    # Start output after residence time: RT = 500/100 = 5 days
    cout_tedges = pd.date_range(start="2020-01-08", periods=31, freq="D")

    flow = np.ones(len(dates)) * 100.0
    aquifer_pore_volume = 500.0  # RT = 500/100 = 5 days
    thickness = 3.0
    retardation_factor = 1.0

    # Low porosity (more contact area)
    weights_low_por = compute_deposition_weights(
        flow=flow,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=aquifer_pore_volume,
        porosity=0.25,
        thickness=thickness,
        retardation_factor=retardation_factor,
    )

    # High porosity (less contact area)
    weights_high_por = compute_deposition_weights(
        flow=flow,
        tedges=tedges,
        cout_tedges=cout_tedges,
        aquifer_pore_volume=aquifer_pore_volume,
        porosity=0.45,
        thickness=thickness,
        retardation_factor=retardation_factor,
    )

    # Weights should be affected by porosity (different contact areas)
    assert not np.allclose(weights_low_por, weights_high_por)


# =============================================================================
# Variable-timestep tests
# =============================================================================


def test_variable_timestep_constant_deposition():
    """Constant deposition and flow on irregular time edges.

    After spin-up, the analytical solution C = rt * dep_rate / (porosity * thickness)
    holds exactly regardless of timestep width.
    """
    # Irregular intervals: 1, 3, 2, 5, 7, 4, 2, 3, 1, 6, 4, 2, 5, 3 days = 48 days total
    day_widths = [1, 3, 2, 5, 7, 4, 2, 3, 1, 6, 4, 2, 5, 3]
    cumdays = np.concatenate(([0], np.cumsum(day_widths)))
    t0 = pd.Timestamp("2020-01-01")
    tedges = pd.DatetimeIndex([t0 + pd.Timedelta(days=int(d)) for d in cumdays])
    n = len(tedges) - 1

    params = {
        "aquifer_pore_volume": 500.0,
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    deposition_rate = 100.0
    flow_rate = 100.0  # RT = 500/100 = 5 days
    dep_values = np.full(n, deposition_rate)
    flow_values = np.full(n, flow_rate)

    # Use late output edges to be past spin-up
    cout_tedges = tedges[8:]  # Start well after spin-up

    cout_result = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    # For constant flow, RT is constant: V*R/Q = 500*1/100 = 5 days
    expected_rt = params["aquifer_pore_volume"] * params["retardation_factor"] / flow_rate
    expected_c = expected_rt * deposition_rate / (params["porosity"] * params["thickness"])

    valid = ~np.isnan(cout_result)
    assert valid.sum() >= 1
    np.testing.assert_allclose(cout_result[valid], expected_c, rtol=1e-12)


def test_variable_timestep_roundtrip():
    """Roundtrip with variable timesteps and varying deposition.

    Variable timesteps naturally produce non-integer RT/dt ratios per bin,
    avoiding rank deficiency. Uses half-day cout for overdetermination.
    """
    day_widths = [1, 3, 2, 5, 7, 4, 2, 3, 1, 6, 4, 2, 5, 3, 2, 4, 1, 3, 6, 2]
    cumdays = np.concatenate(([0], np.cumsum(day_widths)))
    t0 = pd.Timestamp("2020-01-01")
    tedges = pd.DatetimeIndex([t0 + pd.Timedelta(days=int(d)) for d in cumdays])
    n = len(tedges) - 1

    params = {
        "aquifer_pore_volume": 350.0,  # RT = 3.5 days (non-integer)
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    dep_values = 20.0 + 10.0 * np.sin(2 * np.pi * np.arange(n) / n)
    flow_values = np.full(n, 100.0)

    # Half-day cout resolution
    total_days = int(cumdays[-1])
    cout_dates = pd.date_range(t0, t0 + pd.Timedelta(days=total_days), freq="12h")
    cout_tedges = compute_time_edges(tedges=None, tstart=None, tend=cout_dates, number_of_bins=len(cout_dates))

    cout = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    recovered = extraction_to_deposition(
        cout=cout,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        regularization_strength=1e-20,
        **params,
    )

    valid = ~np.isnan(recovered)
    assert valid.sum() >= n - 1
    np.testing.assert_allclose(
        recovered[valid],
        dep_values[valid],
        atol=1e-10,
        rtol=1e-10,
    )


def test_variable_cout_tedges_constant_deposition():
    """Daily input data but variable-width cout_tedges (3-day and 7-day bins).

    Constant deposition + constant flow produces the same analytical solution
    regardless of output bin width.
    """
    # Daily tedges for 40 days
    tedges = pd.date_range("2020-01-01", periods=41, freq="D")
    n = len(tedges) - 1

    params = {
        "aquifer_pore_volume": 500.0,
        "porosity": 0.25,
        "thickness": 4.0,
        "retardation_factor": 1.0,
    }

    deposition_rate = 80.0
    flow_rate = 100.0  # RT = 5 days
    dep_values = np.full(n, deposition_rate)
    flow_values = np.full(n, flow_rate)

    # Variable-width output bins: 3-day, 7-day, 3-day, 7-day, ...
    cout_days = [0]
    widths = [3, 7]
    i = 0
    while cout_days[-1] < 30:
        cout_days.append(cout_days[-1] + widths[i % 2])
        i += 1
    # Offset to start after spin-up
    t0 = tedges[8]
    cout_tedges = pd.DatetimeIndex([t0 + pd.Timedelta(days=d) for d in cout_days])

    cout_result = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    # For constant flow, RT is constant: V*R/Q = 500*1/100 = 5 days
    expected_rt = params["aquifer_pore_volume"] * params["retardation_factor"] / flow_rate
    expected_c = expected_rt * deposition_rate / (params["porosity"] * params["thickness"])

    valid = ~np.isnan(cout_result)
    assert valid.sum() >= 1
    np.testing.assert_allclose(cout_result[valid], expected_c, rtol=1e-12)


def test_variable_timestep_linearity():
    """With variable timesteps, verify exact linearity: 2 * dep produces exactly 2 * cout."""
    day_widths = [1, 3, 2, 5, 7, 4, 2, 3, 1, 6, 4, 2]
    cumdays = np.concatenate(([0], np.cumsum(day_widths)))
    t0 = pd.Timestamp("2020-01-01")
    tedges = pd.DatetimeIndex([t0 + pd.Timedelta(days=int(d)) for d in cumdays])
    n = len(tedges) - 1

    params = {
        "aquifer_pore_volume": 400.0,
        "porosity": 0.2,
        "thickness": 8.0,
        "retardation_factor": 1.0,
    }

    base_dep = np.full(n, 20.0)
    double_dep = 2.0 * base_dep
    flow_values = np.full(n, 80.0)

    cout_tedges = tedges[5:]

    cout_base = deposition_to_extraction(
        dep=base_dep,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )
    cout_double = deposition_to_extraction(
        dep=double_dep,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    valid = ~np.isnan(cout_base) & ~np.isnan(cout_double)
    assert valid.sum() >= 1
    np.testing.assert_allclose(cout_double[valid], 2.0 * cout_base[valid], rtol=1e-12)


def test_variable_timestep_zero_deposition():
    """Zero deposition with variable timesteps produces exactly zero concentration."""
    day_widths = [1, 3, 2, 5, 7, 4, 2, 3, 1, 6]
    cumdays = np.concatenate(([0], np.cumsum(day_widths)))
    t0 = pd.Timestamp("2020-01-01")
    tedges = pd.DatetimeIndex([t0 + pd.Timedelta(days=int(d)) for d in cumdays])
    n = len(tedges) - 1

    params = {
        "aquifer_pore_volume": 300.0,
        "porosity": 0.3,
        "thickness": 5.0,
        "retardation_factor": 1.0,
    }

    dep_values = np.zeros(n)
    flow_values = np.full(n, 100.0)
    cout_tedges = tedges[3:]

    cout_result = deposition_to_extraction(
        dep=dep_values,
        flow=flow_values,
        tedges=tedges,
        cout_tedges=cout_tedges,
        **params,
    )

    valid = ~np.isnan(cout_result)
    assert valid.sum() >= 1
    np.testing.assert_allclose(cout_result[valid], 0.0, atol=1e-15)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
