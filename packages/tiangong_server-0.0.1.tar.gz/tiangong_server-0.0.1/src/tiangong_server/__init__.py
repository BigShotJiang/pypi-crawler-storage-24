"""
TianGong Server -- Backend server for the TianGong AI Agent platform.
"""
__version__ = "0.0.1"
