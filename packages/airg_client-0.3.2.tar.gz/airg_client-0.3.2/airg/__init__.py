"""AIRG — AI Runtime Governor Python client.

Usage::

    from airg import AIRG

    client = AIRG()
    decision = client.evaluate(tool="shell_exec", args={"command": "ls"})
"""
from airg._client import (
    AIRG,
    AIRGError,
    BlockedError,
    ReviewExpiredError,
    ReviewRejectedError,
    VerificationError,
)

__all__ = [
    "AIRG",
    "AIRGError",
    "BlockedError",
    "ReviewExpiredError",
    "ReviewRejectedError",
    "VerificationError",
]
