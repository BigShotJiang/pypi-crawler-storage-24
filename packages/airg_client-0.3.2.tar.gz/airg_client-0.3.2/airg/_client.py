"""AIRG — AI Runtime Governor Python client."""
from __future__ import annotations

import os
import time
from typing import Any, Dict, List, Optional

import httpx


class AIRGError(Exception):
    """Base exception for AIRG client errors."""


class BlockedError(AIRGError):
    """Raised when the Governor blocks an action."""


class ReviewRejectedError(AIRGError):
    """Raised when a review decision is rejected by a human operator."""


class ReviewExpiredError(AIRGError):
    """Raised when a review decision times out."""


class VerificationError(AIRGError):
    """Raised when post-execution verification finds a violation."""


class AIRG:
    """
    Client for the AI Runtime Governor.

    Usage::

        from airg import AIRG

        client = AIRG()
        decision = client.evaluate(tool="shell_exec", args={"command": "ls"})

    Reads ``GOVERNOR_API_KEY`` and ``GOVERNOR_URL`` from environment
    variables when not provided explicitly.
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 10.0,
    ) -> None:
        self.api_key = api_key or os.environ.get("GOVERNOR_API_KEY", "")
        self.base_url = (base_url or os.environ.get("GOVERNOR_URL", "http://localhost:8000")).rstrip("/")
        self.timeout = timeout

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _headers(self) -> Dict[str, str]:
        h: Dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            h["X-API-Key"] = self.api_key
        return h

    def _post(self, path: str, json: Any = None, *, timeout: Optional[float] = None) -> Any:
        with httpx.Client(timeout=timeout or self.timeout, headers=self._headers()) as c:
            resp = c.post(f"{self.base_url}{path}", json=json)
            resp.raise_for_status()
        return resp.json()

    def _get(self, path: str, params: Optional[Dict[str, Any]] = None, *, timeout: Optional[float] = None) -> Any:
        with httpx.Client(timeout=timeout or self.timeout, headers=self._headers()) as c:
            resp = c.get(f"{self.base_url}{path}", params=params)
            resp.raise_for_status()
        return resp.json()

    def _delete(self, path: str, *, timeout: Optional[float] = None) -> Any:
        with httpx.Client(timeout=timeout or self.timeout, headers=self._headers()) as c:
            resp = c.delete(f"{self.base_url}{path}")
            resp.raise_for_status()
        return resp.json()

    # ------------------------------------------------------------------
    # Actions
    # ------------------------------------------------------------------

    def evaluate(
        self,
        tool: str,
        args: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
        *,
        review_mode: str = "proceed",
        hold_timeout: int = 60,
        hold_poll_interval: float = 1.0,
    ) -> Dict[str, Any]:
        """
        Evaluate a tool call against the Governor.

        Returns the decision dict with keys:
        ``decision``, ``risk_score``, ``explanation``, ``policy_ids``, ``modified_args``.

        Raises :class:`BlockedError` if the decision is ``"block"``.
        """
        if review_mode not in ("proceed", "hold"):
            raise ValueError(f"review_mode must be 'proceed' or 'hold', got '{review_mode}'")

        result = self._post("/actions/evaluate", {"tool": tool, "args": args, "context": context})

        if result.get("decision") == "block":
            raise BlockedError(
                f"Governor blocked tool '{tool}': {result.get('explanation', 'no reason given')}"
            )

        if result.get("decision") == "review" and review_mode == "hold":
            escalation_id = result.get("escalation_id")
            if escalation_id:
                hold_result = self._hold_for_review(escalation_id, hold_timeout, hold_poll_interval)
                result["review_status"] = hold_result.get("status", "unknown")
                result["review_resolved_by"] = hold_result.get("resolved_by")
                result["review_resolution_note"] = hold_result.get("resolution_note")

                if hold_result.get("timed_out"):
                    raise ReviewExpiredError(
                        f"Review for tool '{tool}' timed out after {hold_timeout}s"
                    )
                if hold_result.get("status") == "rejected":
                    raise ReviewRejectedError(
                        f"Review for tool '{tool}' was rejected: "
                        f"{hold_result.get('resolution_note', 'no reason given')}"
                    )
                if hold_result.get("status") == "expired":
                    raise ReviewExpiredError(f"Review for tool '{tool}' expired before resolution")

        return result

    def _hold_for_review(self, escalation_id: int, timeout_seconds: int, poll_interval: float) -> Dict[str, Any]:
        params = {"timeout_seconds": timeout_seconds, "poll_interval": poll_interval}
        try:
            return self._post(
                f"/escalation/queue/{escalation_id}/hold",
                timeout=timeout_seconds + 10,
            )
        except (httpx.TimeoutException, Exception):
            return {"event_id": escalation_id, "status": "pending", "timed_out": True}

    # ------------------------------------------------------------------
    # Output scanning
    # ------------------------------------------------------------------

    def scan(
        self,
        text: str,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Scan agent response text for threats before sending to users.

        Returns a dict with ``safe``, ``risk_score``, ``findings``,
        and ``sanitized_text``.
        """
        payload: Dict[str, Any] = {"text": text}
        if agent_id:
            payload["agent_id"] = agent_id
        if session_id:
            payload["session_id"] = session_id
        if context:
            payload["context"] = context
        return self._post("/actions/scan-output", payload)

    # ------------------------------------------------------------------
    # Verification
    # ------------------------------------------------------------------

    def verify(
        self,
        action_id: int,
        tool: str,
        result: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Submit a tool execution result for post-execution verification.

        Raises :class:`VerificationError` on violation verdicts.
        """
        verdict = self._post("/actions/verify", {
            "action_id": action_id,
            "tool": tool,
            "result": result,
            "context": context,
        })

        if verdict.get("verification") == "violation":
            raise VerificationError(
                f"Verification violation for tool '{tool}' (action_id={action_id}): "
                f"{[f['detail'] for f in verdict.get('findings', []) if f.get('result') == 'fail']}"
            )
        return verdict

    # ------------------------------------------------------------------
    # Traces
    # ------------------------------------------------------------------

    def ingest_spans(self, spans: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Batch-ingest agent trace spans."""
        return self._post("/traces/ingest", {"spans": spans})

    def list_traces(
        self,
        *,
        agent_id: Optional[str] = None,
        session_id: Optional[str] = None,
        has_blocks: Optional[bool] = None,
        limit: int = 50,
        offset: int = 0,
    ) -> List[Dict[str, Any]]:
        """List traces with optional filters."""
        params: Dict[str, Any] = {"limit": limit, "offset": offset}
        if agent_id is not None:
            params["agent_id"] = agent_id
        if session_id is not None:
            params["session_id"] = session_id
        if has_blocks is not None:
            params["has_blocks"] = str(has_blocks).lower()
        return self._get("/traces", params)

    def get_trace(self, trace_id: str) -> Dict[str, Any]:
        """Fetch full trace detail — all spans plus governance decisions."""
        return self._get(f"/traces/{trace_id}")

    def delete_trace(self, trace_id: str) -> Dict[str, Any]:
        """Delete all spans for a trace."""
        return self._delete(f"/traces/{trace_id}")
