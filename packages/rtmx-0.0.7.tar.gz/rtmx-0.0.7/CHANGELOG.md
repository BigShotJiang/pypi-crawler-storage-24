# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.0.7] - 2026-03-17

**Final Python CLI release.** Future CLI development continues in [rtmx-go](https://github.com/rtmx-ai/rtmx-go). The `rtmx` PyPI package will be reduced to a minimal pytest plugin after Go CLI reaches feature parity.

### Added
- **BDD Support (Phase 18)**
  - Gherkin parser for feature files using `gherkin-official` library (REQ-BDD-001)
  - Step definition discovery for Python pytest-bdd and behave (REQ-BDD-002)
  - Scenario Outline expansion with Examples tables (REQ-BDD-005)
- **Claude Code Integration (Phase 19)**
  - Pre-prompt and post-tool hooks for automatic RTM context injection (REQ-CLAUDE-001)
- **Cross-Language Verification**
  - `--rtmx-output` pytest option for JSON result export (REQ-LANG-004)
- **Documentation**
  - Typst whitepaper template with RTMX branding (REQ-DOC-005)
- **Deprecation Infrastructure**
  - Deprecation warning banner directing users to Go CLI
  - `RTMX_SUPPRESS_DEPRECATION=1` environment variable to suppress
  - `rtmx migrate` command for Go CLI transition assistance
  - Platform-specific Go CLI install instructions (Homebrew, Scoop, curl)
- **Strategic Requirements**
  - Go migration requirements (REQ-MIG-001/002/003, Phase 21)
  - Monorepo consolidation requirements (REQ-MONO-001/002/003, Phase 22)
  - Hierarchical requirements discovery (REQ-HIER-001/002/003, Phase 22)
  - Local E2E testing with Zarf + Kind (REQ-E2E-001/002/003, Phase 10)

### Changed
- CI pipeline migrated from PAT to GitHub App for signed commits
- CI actions bumped: setup-python v6, upload-artifact v6, github-script v8
- Screenshot generation uses modern `.rtmx/` directory layout

### Fixed
- mypy errors for untyped `gherkin-official` library imports

### Deprecated
- **All Python CLI commands.** The Go CLI (`rtmx-go`) will replace the Python CLI as the primary implementation. The Python package will be reduced to a minimal pytest plugin providing `@pytest.mark.req` and JSON result output. See the [migration guide](https://rtmx.ai/docs/go-migration).

## [0.0.6] - 2026-01-23

### Added
- `rtmx_get_spec` MCP tool for reading requirement specification files
- REQ-UX-009: CLI Design System specification documenting icons, colors, and formatting standards
- Strategic roadmap expansion with Phases 14-18 (Language Support, Git-Native Sync, PM Features, BDD Support)

### Changed
- Rich status output now displays phase names (e.g., "Phase 1 (Foundation)" instead of "Phase 1:")
- Standardized status icons across all CLI commands using centralized `formatting.py` module
- Repository migrated to `rtmx-ai` organization
- Website migrated to separate `rtmx.ai` repository

### Fixed
- Inconsistent partial status icon: changed from `△` to `⚠` in backlog command to match status command

## [0.0.5] - 2026-01-06

### Fixed
- MCP server API compatibility with mcp SDK 1.x
  - Updated `create_server` to return `(server, init_options)` tuple
  - Updated `run_server` to use new `stdio_server()` async context manager pattern
  - Fixed `Server.run()` call signature: `(read_stream, write_stream, init_options)`
  - Fixes "unhandled errors in a TaskGroup" error when running MCP server

### Added
- MCP server API compatibility tests in `test_mcp_coverage.py`

## [0.0.4] - 2026-01-03

### Added
- **Phase 5 Complete**: CLI UX enhancements
  - Rich progress bars and formatted output (REQ-UX-001, REQ-UX-002)
  - `rtmx status --live` auto-refresh mode (REQ-UX-003)
  - `rtmx tui` interactive Textual dashboard (REQ-UX-004, REQ-UX-005)
  - Optional `rtmx[tui]` and `rtmx[rich]` dependencies (REQ-UX-006)
  - Named phase support in config with display names (REQ-SCHEMA-001)
- **Phase 6 Complete**: Web UI dashboard
  - `rtmx serve` command starts FastAPI web server (REQ-WEB-001)
  - REST API: `/api/status`, `/api/backlog`, `/api/requirements` (REQ-WEB-002-004)
  - HTML dashboard with phase progress and backlog views (REQ-WEB-005-006)
  - WebSocket support for real-time updates (REQ-WEB-007)
  - Optional `rtmx[web]` dependency group (REQ-WEB-008)
- 19 web UI tests covering all endpoints and WebSocket functionality

### Changed
- Backlog output now matches Phoenix format with summary header and sections
- Phase display shows names from config (e.g., "Phase 6 (Web UI)")

### Fixed
- TUI module now handles missing textual dependency gracefully
- TemplateResponse deprecation warnings fixed for FastAPI/Starlette

## [0.0.3] - 2026-01-02

### Added
- **Phase 3 Complete**: Architecture decisions formally documented
  - 5 ADRs: CSV format, Click framework, lazy imports, markers, adapters
  - API documentation generated with pdoc
- **Phase 4 Complete**: Developer experience improvements
  - `.rtmx/` directory structure for all artifacts (REQ-DX-001)
  - Auto-migration from root configs to `.rtmx/` (REQ-DX-002)
  - `rtmx setup --scaffold` for auto-generating requirement specs (REQ-DX-003)
  - `rtmx docs` command for schema/config documentation (REQ-DX-004)
  - `rtmx install --hooks` for git hook installation (REQ-DX-005)
  - ADR-006 npm distribution trade study (REQ-DX-006)
- Comprehensive test suite expansion:
  - 55 E2E system tests (REQ-TEST-003)
  - 20 adapter integration tests with mock HTTP servers (REQ-TEST-004)
  - 108 Monte Carlo tests for graph algorithms (REQ-TEST-005)
  - 26 sync E2E tests (REQ-TEST-007)
  - 17 MCP server E2E tests (REQ-TEST-008)
  - 18 performance/stress tests with 1000+ req databases (REQ-TEST-009)
  - 33 migration tests (REQ-DX-002)
  - 26 template rendering tests (REQ-DX-003)
  - 31 docs command tests (REQ-DX-004)
- Test marker CI enforcement at 80% threshold (REQ-QUAL-003)

### Changed
- All rtmx artifacts now default to `.rtmx/` directory
- Config discovery prefers `.rtmx/rtmx.yaml` over root `rtmx.yaml`
- Database discovery prefers `.rtmx/rtm_database.csv`

### Fixed
- UnboundLocalError bugs in 8 CLI files (missing return after sys.exit)
- MCP availability check for reliable CI test skipping
- Ruff version pinned to match pre-commit config

## [0.0.2] - 2025-12-06

### Added
- Unified `rtmx setup` command combining init, install, and makefile generation
- `rtmx health` command for project health scoring
- `rtmx diff` command for comparing RTM versions
- Phoenix-style backlog display with summary header and sections
- View modes for backlog: `--view all|critical|quick-wins|blockers`
- Colored terminal screenshots in README documentation
- Auto-regeneration of terminal screenshots in CI

### Changed
- Backlog output now matches Phoenix/Cyclone format with Critical Path and Quick Wins sections
- Phase display format changed to "Phase X" style
- Blocks column shows transitive count with direct count in parentheses
- Status icons updated (△ for PARTIAL)

### Improved
- Code coverage increased from 26% to 87%
- Added comprehensive test suite for CLI commands, models, adapters

### Fixed
- Type errors in health.py, setup.py, integrate.py
- Pre-commit hook compatibility issues

## [0.0.1] - 2024-12-03

### Added
- Initial release of RTMX
- Core RTM data model and CSV parser
- Dependency graph analysis with cycle detection
- Validation framework for requirement integrity
- CLI commands:
  - `rtmx init` - Initialize RTM structure
  - `rtmx status` - Show completion status with verbosity levels
  - `rtmx backlog` - Prioritized incomplete requirements
  - `rtmx deps` - Dependency visualization
  - `rtmx cycles` - Circular dependency detection
  - `rtmx reconcile` - Dependency consistency fixes
  - `rtmx from-tests` - Extract markers from test files
  - `rtmx makefile` - Generate Makefile targets
  - `rtmx analyze` - Project artifact discovery
  - `rtmx bootstrap` - Generate RTM from existing artifacts
  - `rtmx install` - Inject prompts into AI agent configs
  - `rtmx sync` - Bidirectional sync with GitHub/Jira
  - `rtmx mcp-server` - MCP protocol server
- Pytest plugin with custom markers:
  - `@pytest.mark.req()` - Link tests to requirements
  - Scope: `scope_unit`, `scope_integration`, `scope_system`
  - Technique: `technique_nominal`, `technique_parametric`, `technique_stress`
  - Environment: `env_simulation`, `env_hil`, `env_field`
- YAML configuration (rtmx.yaml)
- Service adapters for GitHub Issues and Jira
- MCP server for AI agent integration
- Agent prompt templates for Claude, Cursor, Copilot
- GitHub Actions CI/CD pipeline
- Pre-commit hooks (ruff, mypy)
- Security scanning (pip-audit, CodeQL)
- E2E test suite for lifecycle management

[Unreleased]: https://github.com/rtmx-ai/rtmx/compare/v0.0.7...HEAD
[0.0.7]: https://github.com/rtmx-ai/rtmx/compare/v0.0.6...v0.0.7
[0.0.6]: https://github.com/rtmx-ai/rtmx/compare/v0.0.5...v0.0.6
[0.0.5]: https://github.com/rtmx-ai/rtmx/compare/v0.0.4...v0.0.5
[0.0.4]: https://github.com/rtmx-ai/rtmx/compare/v0.0.3...v0.0.4
[0.0.3]: https://github.com/rtmx-ai/rtmx/compare/v0.0.2...v0.0.3
[0.0.2]: https://github.com/rtmx-ai/rtmx/compare/v0.0.1...v0.0.2
[0.0.1]: https://github.com/rtmx-ai/rtmx/releases/tag/v0.0.1
