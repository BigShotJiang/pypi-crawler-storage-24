import math

import matplotlib.pyplot as plt

from deep_trader.utils import D_TYPE


def plot1(data: D_TYPE, id, sort=False, C=2, bins=200, n_std=3):
    if sort:
        data = dict(sorted(data.items()))
    C = min(C, len(data))
    R = math.ceil(len(data) / C)
    plt.figure(figsize=(4 * C, 3 * R))
    i = 0
    for k, v0 in data.items():
        v = v0.flatten()
        i += 1
        plt.subplot(R, C, i)
        mu, std = v.mean(), v.std()
        plt.title(f"{k} {v0.shape} \n mu={mu:.0e}, std={std:.0e}")
        if ".hist" in k:
            bins_k = min(len(v), bins)
            range = [mu - std * n_std, mu + std * n_std]
            plt.hist(v, bins_k, range=range)
        else:
            plt.plot(v, ".")
    plt.tight_layout()
    plt.savefig(id)
    plt.close()
