from typing import Dict, List, Union

import numpy as np
import torch as tc
import torch.nn as nn

D_TYPE = Dict[str, Union[np.ndarray, tc.Tensor]]


def concat_rows(rows: List[D_TYPE], cat=np.concat):
    return {k: cat([r[k] for r in rows]) for k in rows[0]}


def postfix(x: Dict, txt):
    return {k + txt: v for k, v in x.items()}


def shape(x):
    if isinstance(x, (np.ndarray, tc.Tensor)):
        return x.shape
    if isinstance(x, dict):
        return {k: shape(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return list(map(shape, x))


def to_np(x):
    if isinstance(x, tc.Tensor):
        return x.detach().cpu().numpy()
    if isinstance(x, dict):
        return {k: to_np(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return list(map(to_np, x))
    return x


def tensor(x, device):
    if isinstance(x, np.ndarray):
        if np.issubdtype(x.dtype, np.integer):
            return tc.from_numpy(x).long().to(device)
        return tc.from_numpy(x).float().to(device)
    if isinstance(x, dict):
        return {k: tensor(v, device) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [tensor(v, device) for v in x]
    return x


def mlp(sizes, Act):
    layers = []
    for a, b in zip(sizes[:-1], sizes[1:]):
        layers += [nn.Linear(a, b), Act()]
    return nn.Sequential(*layers[:-1])
