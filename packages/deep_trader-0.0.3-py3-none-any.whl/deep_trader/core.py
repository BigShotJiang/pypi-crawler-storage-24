from typing import List

import numpy as np
import torch as tc
import torch.nn as nn
from crypto_data_downloader.utils import parse_date

from deep_trader.plot import plot1
from deep_trader.sim import simulate
from deep_trader.utils import D_TYPE, concat_rows, postfix, shape, to_np


class DeepTraderBase:
    obs_skip: int

    lev: int
    TO: int
    TP: float
    SL: float
    fee: float

    net: nn.Module
    opt: tc.optim.Adam

    epochs: int
    f_plot: int
    f_test: int
    plot_id: str

    def set_h5_file(s, h5_file: D_TYPE):
        s.h5_file = h5_file
        s.sym2idx = {sym: idx for idx, sym in enumerate(h5_file.keys())}

    def get_period(s, start, end):
        start, end = map(parse_date, (start, end))
        res: D_TYPE = {}
        for sym, x in s.h5_file.items():
            x = x[:]
            time, price = x.T
            mask = (start <= time) & (time < end)
            if np.any(mask) and np.ptp(price[mask]) > 0:
                res[sym] = x[mask]
        return res

    def label_data(s, raw_data: D_TYPE):
        rows: List[D_TYPE] = []
        slc = slice(s.obs_skip, -s.TO)
        for sym, x in raw_data.items():
            time, price = x.T
            sym_idx = np.full(len(time), s.sym2idx[sym])
            obs = s.make_obs(price)
            profit_SL = simulate(price, s.lev, s.TO, s.TP, s.SL, s.fee)
            row = {"sym_idx": sym_idx, "obs": obs, "profit_SL": profit_SL}
            rows.append({k: v[slc] for k, v in row.items()})
        res: D_TYPE = concat_rows(rows)
        print(f"labeled data: {shape(res)}")
        return res

    def make_obs(s, price: np.ndarray) -> np.ndarray:
        raise NotImplementedError()

    def normalize_obs(s, d1: D_TYPE, d2: D_TYPE):
        obs = d1["obs"]
        mu, std = obs.mean(0), obs.std(0)
        for d in [d1, d2]:
            d["obs"] = ((d["obs"] - mu) / std).clip(-3, 3)

    def loss(s, d: D_TYPE) -> D_TYPE:
        raise NotImplementedError()

    def pos_abs_times(s, pos: tc.Tensor, profit_SL: tc.Tensor):
        # pos: (N,), profit_SL: (N, 2)
        pr_short, pr_long = profit_SL.T
        return tc.relu(-pos) * pr_short + tc.relu(pos) * pr_long

    def find_scalars(s, x: D_TYPE):
        return {k: v.detach() for k, v in x.items() if v.ndim == 0}

    def train(s, d1: D_TYPE, d2: D_TYPE):
        rows1, rows2 = [], []
        for e in range(s.epochs):
            is_last = e == s.epochs - 1
            if e % s.f_test == 0 or is_last:
                with tc.no_grad():
                    s.net.eval()
                    l2 = s.loss(d2)
                    rows2.append(s.find_scalars(l2))
                    s.net.train()

            l1 = s.loss(d1)
            s.opt.zero_grad()
            l1["loss"].backward()
            s.opt.step()
            rows1.append(s.find_scalars(l1))

            if e % s.f_plot == 0 or is_last:
                print(f"epoch: {e+1}, loss/train: {l1['loss']:.6f}")
                p1 = {**l1, **concat_rows(rows1, tc.stack)}
                p2 = {**l2, **concat_rows(rows2, tc.stack)}
                plots = {**postfix(p1, "/train"), **postfix(p2, "/test")}
                plot1(to_np(plots), s.plot_id, sort=True)
