import numba
import numpy as np


@numba.njit(parallel=True)
def simulate(price, lev, TO, TP, SL, fee):
    T = len(price)
    profit_SL = np.zeros((T, 2))
    pos_signs = [-1, 1]  # Short, Long
    for t1 in numba.prange(T - 1):
        p1 = price[t1]
        for idx, pos in enumerate(pos_signs):
            pr = 0
            for t2 in range(t1 + 1, T):
                p2 = price[t2]
                dt = t2 - t1
                pr = lev * (pos * (p2 - p1) / p1 - fee)
                if dt >= TO or pr >= TP or pr <= SL:
                    break
            profit_SL[t1, idx] = pr
    return profit_SL
