"""Hub API client scaffold."""
