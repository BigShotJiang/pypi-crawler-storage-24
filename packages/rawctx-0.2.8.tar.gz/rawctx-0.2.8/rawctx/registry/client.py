from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse

import httpx

from rawctx.errors import RegistryError
from rawctx.registry.models import ApiTokenInfo, ClaimResult, OAuthLoginInfo, OAuthSessionInfo, PackageDetail, SearchItem, VersionInfo


@dataclass(frozen=True)
class SearchResult:
    items: list[SearchItem]
    meta: dict[str, Any]


def _auth_header(token: str | None) -> dict[str, str]:
    normalized = token.strip() if token else ""
    if not normalized:
        return {}
    return {"Authorization": f"Bearer {normalized}"}


def _parse_json_dict(response: httpx.Response) -> dict[str, Any]:
    if response.status_code == 204:
        return {}

    try:
        data = response.json()
    except ValueError:
        return {}

    if not isinstance(data, dict):
        return {}
    return data


def _to_error(response: httpx.Response) -> RegistryError:
    detail: str | None = None
    message = f"Registry request failed ({response.status_code})"
    payload_dict: dict[str, Any] | None = None

    try:
        payload = response.json()
    except ValueError:
        payload = None

    if isinstance(payload, dict):
        payload_dict = payload
        if isinstance(payload.get("detail"), str):
            detail = payload["detail"]
        elif isinstance(payload.get("message"), str):
            detail = payload["message"]
        elif payload.get("detail") is not None:
            detail = str(payload.get("detail"))

    if detail:
        message = f"{message}: {detail}"

    return RegistryError(message, status_code=response.status_code, detail=detail, payload=payload_dict)


def _ensure_http_url(url: str, *, action: str) -> None:
    parsed = urlparse(url)
    if parsed.scheme == "memory":
        raise RegistryError(
            f"Cannot {action} using memory:// URL from registry. Configure Hub storage backend with S3/HTTP presigned URLs."
        )
    if parsed.scheme not in {"http", "https"}:
        raise RegistryError(f"Unsupported {action} URL scheme: {parsed.scheme}")


class RegistryClient:
    def __init__(
        self,
        *,
        registry: str,
        token: str | None = None,
        timeout: float = 20.0,
        client: httpx.Client | None = None,
    ) -> None:
        self.registry = registry.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._client = client or httpx.Client(base_url=self.registry, timeout=timeout)
        self._owns_client = client is None

    def close(self) -> None:
        if self._owns_client:
            self._client.close()

    def __enter__(self) -> "RegistryClient":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore[no-untyped-def]
        self.close()

    def oauth_login(self) -> OAuthLoginInfo:
        data = self._request_json("POST", "/api/auth/login", expected_statuses=(200,))
        return OAuthLoginInfo.from_api(data)

    def oauth_login_github(self) -> OAuthLoginInfo:
        data = self._request_json("POST", "/api/auth/login/github", expected_statuses=(200,))
        return OAuthLoginInfo.from_api(data)

    def oauth_login_session(self, session_id: str) -> OAuthSessionInfo:
        data = self._request_json("GET", f"/api/auth/login/session/{session_id}", expected_statuses=(200,))
        return OAuthSessionInfo.from_api(data)

    def oauth_login_session_github(self, session_id: str) -> OAuthSessionInfo:
        data = self._request_json("GET", f"/api/auth/login/github/session/{session_id}", expected_statuses=(200,))
        return OAuthSessionInfo.from_api(data)

    def create_api_token(self, *, id_token: str, name: str, expires_in_days: int | None = None) -> ApiTokenInfo:
        payload: dict[str, Any] = {"name": name}
        if expires_in_days is not None:
            payload["expires_in_days"] = expires_in_days

        data = self._request_json(
            "POST",
            "/api/auth/token",
            expected_statuses=(200,),
            token_override=id_token,
            json=payload,
        )
        return ApiTokenInfo.from_api(data)

    def revoke_api_token(self, token_id: str) -> bool:
        data = self._request_json("DELETE", f"/api/auth/token/{token_id}", expected_statuses=(200, 404))
        return bool(isinstance(data, dict) and data.get("revoked") is True)

    def create_package(self, *, payload: dict[str, Any]) -> PackageDetail:
        data = self._request_json("POST", "/api/packages", expected_statuses=(201,), json=payload)
        return PackageDetail.from_api(data)

    def get_org(self, *, orgname: str) -> dict[str, Any]:
        return self._request_json("GET", f"/api/orgs/{orgname}", expected_statuses=(200,))

    def get_package(self, *, scope: str, name: str) -> PackageDetail:
        data = self._request_json("GET", f"/api/packages/{scope}/{name}", expected_statuses=(200,))
        return PackageDetail.from_api(data)

    def claim_package(self, *, scope: str, name: str) -> ClaimResult:
        data = self._request_json("POST", f"/api/packages/{scope}/{name}/claim", expected_statuses=(200,))
        return ClaimResult.from_api(data)

    def list_versions(self, *, scope: str, name: str, page: int = 1, size: int = 100) -> tuple[list[VersionInfo], dict[str, Any]]:
        data = self._request_json(
            "GET",
            f"/api/packages/{scope}/{name}/versions",
            expected_statuses=(200,),
            params={"page": page, "size": size},
        )
        items_raw = data.get("items") if isinstance(data, dict) else []
        items = [VersionInfo.from_api(item) for item in items_raw if isinstance(item, dict)]
        meta = data.get("meta") if isinstance(data, dict) and isinstance(data.get("meta"), dict) else {}
        return items, meta

    def request_version_upload(
        self,
        *,
        scope: str,
        name: str,
        version: str,
        file_size: int,
        checksum_sha256: str | None,
        origin_ref: str | None = None,
        content_type: str = "application/gzip",
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"file_size": file_size, "content_type": content_type}
        if checksum_sha256:
            payload["checksum_sha256"] = checksum_sha256
        if origin_ref:
            payload["origin_ref"] = origin_ref

        return self._request_json(
            "PUT",
            f"/api/packages/{scope}/{name}/versions/{version}",
            expected_statuses=(200,),
            json=payload,
        )

    def complete_version(
        self,
        *,
        scope: str,
        name: str,
        version: str,
        checksum_sha256: str | None,
    ) -> VersionInfo:
        payload: dict[str, Any] = {}
        if checksum_sha256:
            payload["checksum_sha256"] = checksum_sha256

        data = self._request_json(
            "POST",
            f"/api/packages/{scope}/{name}/versions/{version}/complete",
            expected_statuses=(200,),
            json=payload,
        )
        return VersionInfo.from_api(data)

    def search_packages(
        self,
        *,
        query: str | None,
        format: str | None,
        source_format: str | None,
        origin: str | None,
        domain: str | None,
        source: str | None,
        tags: str | None,
        sort: str | None,
        page: int,
        size: int,
    ) -> SearchResult:
        params: dict[str, Any] = {"page": page, "size": size}
        if query:
            params["q"] = query
        if format:
            params["format"] = format
        if source_format:
            params["source_format"] = source_format
        if origin:
            params["origin"] = origin
        if domain:
            params["domain"] = domain
        if source:
            params["source"] = source
        if tags:
            params["tags"] = tags
        if sort:
            params["sort"] = sort

        data = self._request_json("GET", "/api/search", expected_statuses=(200,), params=params)
        items_raw = data.get("items") if isinstance(data, dict) else []
        items = [SearchItem.from_api(item) for item in items_raw if isinstance(item, dict)]
        meta = data.get("meta") if isinstance(data, dict) and isinstance(data.get("meta"), dict) else {}
        return SearchResult(items=items, meta=meta)

    def request_download(self, *, scope: str, name: str, version: str) -> dict[str, Any]:
        return self._request_json(
            "GET",
            f"/api/packages/{scope}/{name}/versions/{version}/download",
            expected_statuses=(200,),
        )

    def upload_bytes(self, *, upload_url: str, payload: bytes, content_type: str = "application/gzip") -> None:
        _ensure_http_url(upload_url, action="upload")
        try:
            response = httpx.put(upload_url, content=payload, headers={"Content-Type": content_type}, timeout=self.timeout)
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise RegistryError(f"Upload failed: {exc}") from exc

    def download_bytes(self, *, download_url: str) -> bytes:
        _ensure_http_url(download_url, action="download")
        try:
            response = httpx.get(download_url, timeout=self.timeout)
            response.raise_for_status()
            return response.content
        except httpx.HTTPError as exc:
            raise RegistryError(f"Download failed: {exc}") from exc

    def _request_json(
        self,
        method: str,
        path: str,
        *,
        expected_statuses: Iterable[int],
        token_override: str | None = None,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        headers = _auth_header(token_override if token_override else self.token)

        try:
            response = self._client.request(method, path, headers=headers, json=json, params=params)
        except httpx.RequestError as exc:
            raise RegistryError(f"Failed to reach registry: {self.registry}") from exc

        if response.status_code not in set(expected_statuses):
            raise _to_error(response)
        return _parse_json_dict(response)


class AsyncRegistryClient:
    def __init__(
        self,
        *,
        registry: str,
        token: str | None = None,
        timeout: float = 20.0,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self.registry = registry.rstrip("/")
        self.token = token
        self.timeout = timeout
        self._client = client or httpx.AsyncClient(base_url=self.registry, timeout=timeout)
        self._owns_client = client is None

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> "AsyncRegistryClient":
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:  # type: ignore[no-untyped-def]
        await self.close()

    async def oauth_login(self) -> OAuthLoginInfo:
        data = await self._request_json("POST", "/api/auth/login", expected_statuses=(200,))
        return OAuthLoginInfo.from_api(data)

    async def oauth_login_github(self) -> OAuthLoginInfo:
        data = await self._request_json("POST", "/api/auth/login/github", expected_statuses=(200,))
        return OAuthLoginInfo.from_api(data)

    async def oauth_login_session(self, session_id: str) -> OAuthSessionInfo:
        data = await self._request_json("GET", f"/api/auth/login/session/{session_id}", expected_statuses=(200,))
        return OAuthSessionInfo.from_api(data)

    async def oauth_login_session_github(self, session_id: str) -> OAuthSessionInfo:
        data = await self._request_json("GET", f"/api/auth/login/github/session/{session_id}", expected_statuses=(200,))
        return OAuthSessionInfo.from_api(data)

    async def create_api_token(self, *, id_token: str, name: str, expires_in_days: int | None = None) -> ApiTokenInfo:
        payload: dict[str, Any] = {"name": name}
        if expires_in_days is not None:
            payload["expires_in_days"] = expires_in_days

        data = await self._request_json(
            "POST",
            "/api/auth/token",
            expected_statuses=(200,),
            token_override=id_token,
            json=payload,
        )
        return ApiTokenInfo.from_api(data)

    async def revoke_api_token(self, token_id: str) -> bool:
        data = await self._request_json("DELETE", f"/api/auth/token/{token_id}", expected_statuses=(200, 404))
        return bool(isinstance(data, dict) and data.get("revoked") is True)

    async def get_package(self, *, scope: str, name: str) -> PackageDetail:
        data = await self._request_json("GET", f"/api/packages/{scope}/{name}", expected_statuses=(200,))
        return PackageDetail.from_api(data)

    async def claim_package(self, *, scope: str, name: str) -> ClaimResult:
        data = await self._request_json("POST", f"/api/packages/{scope}/{name}/claim", expected_statuses=(200,))
        return ClaimResult.from_api(data)

    async def list_versions(self, *, scope: str, name: str, page: int = 1, size: int = 100) -> tuple[list[VersionInfo], dict[str, Any]]:
        data = await self._request_json(
            "GET",
            f"/api/packages/{scope}/{name}/versions",
            expected_statuses=(200,),
            params={"page": page, "size": size},
        )
        items_raw = data.get("items") if isinstance(data, dict) else []
        items = [VersionInfo.from_api(item) for item in items_raw if isinstance(item, dict)]
        meta = data.get("meta") if isinstance(data, dict) and isinstance(data.get("meta"), dict) else {}
        return items, meta

    async def search_packages(
        self,
        *,
        query: str | None,
        format: str | None,
        source_format: str | None,
        origin: str | None,
        domain: str | None,
        source: str | None,
        tags: str | None,
        sort: str | None,
        page: int,
        size: int,
    ) -> SearchResult:
        params: dict[str, Any] = {"page": page, "size": size}
        if query:
            params["q"] = query
        if format:
            params["format"] = format
        if source_format:
            params["source_format"] = source_format
        if origin:
            params["origin"] = origin
        if domain:
            params["domain"] = domain
        if source:
            params["source"] = source
        if tags:
            params["tags"] = tags
        if sort:
            params["sort"] = sort

        data = await self._request_json("GET", "/api/search", expected_statuses=(200,), params=params)
        items_raw = data.get("items") if isinstance(data, dict) else []
        items = [SearchItem.from_api(item) for item in items_raw if isinstance(item, dict)]
        meta = data.get("meta") if isinstance(data, dict) and isinstance(data.get("meta"), dict) else {}
        return SearchResult(items=items, meta=meta)

    async def _request_json(
        self,
        method: str,
        path: str,
        *,
        expected_statuses: Iterable[int],
        token_override: str | None = None,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        headers = _auth_header(token_override if token_override else self.token)

        try:
            response = await self._client.request(method, path, headers=headers, json=json, params=params)
        except httpx.RequestError as exc:
            raise RegistryError(f"Failed to reach registry: {self.registry}") from exc

        if response.status_code not in set(expected_statuses):
            raise _to_error(response)
        return _parse_json_dict(response)
