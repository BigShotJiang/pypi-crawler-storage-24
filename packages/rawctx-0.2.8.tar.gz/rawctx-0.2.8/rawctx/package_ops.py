from __future__ import annotations

from pathlib import Path
import re
import shutil

import yaml

from rawctx.packaging.manifest import PACKAGE_NAME_RE, SEMVER_RE


_SAFE_NAME_RE = re.compile(r"[^a-z0-9-]+")


def slugify(value: str) -> str:
    normalized = value.strip().lower().replace("_", "-").replace(" ", "-")
    normalized = _SAFE_NAME_RE.sub("-", normalized).strip("-")
    return normalized or "semantic-model"


def default_package_name(project_name: str, username: str | None) -> str:
    scope = slugify(username or "demo")
    package = f"{slugify(project_name)}-semantic"
    return f"@{scope}/{package}"


def resolve_package_name(project_name: str, package_name: str | None, username: str | None) -> str:
    candidate = package_name.strip() if package_name else default_package_name(project_name, username)
    if not PACKAGE_NAME_RE.fullmatch(candidate):
        raise ValueError("package name must match @scope/name with lowercase letters, numbers, and hyphen")
    return candidate


def resolve_version(project_version: str | None, package_version: str | None) -> str:
    if package_version:
        candidate = package_version.strip()
        if not SEMVER_RE.fullmatch(candidate):
            raise ValueError("package version must be strict SemVer X.Y.Z")
        return candidate

    if project_version and SEMVER_RE.fullmatch(project_version.strip()):
        return project_version.strip()

    return "0.1.0"


def write_yaml(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    text = yaml.safe_dump(payload, sort_keys=False, allow_unicode=False)
    path.write_text(text, encoding="utf-8")


def materialize_package(
    output_dir: Path,
    *,
    package_name: str,
    package_version: str,
    source_format: str,
    model_documents: dict[str, dict],
    overwrite: bool,
) -> list[Path]:
    if output_dir.exists():
        if not overwrite:
            raise RuntimeError(f"output already exists: {output_dir} (use --overwrite)")
        shutil.rmtree(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)
    models_dir = output_dir / "models"
    models_dir.mkdir(parents=True, exist_ok=True)

    model_paths: list[str] = []
    written: list[Path] = []

    for file_name in sorted(model_documents.keys()):
        model_rel_path = Path("models") / file_name
        model_path = output_dir / model_rel_path
        write_yaml(model_path, model_documents[file_name])
        model_paths.append(model_rel_path.as_posix())
        written.append(model_path)

    manifest = {
        "name": package_name,
        "version": package_version,
        "format": "osi",
        "source_format": source_format,
        "description": f"Converted from {source_format}",
        "source": "dbt",
        "models": model_paths,
    }
    manifest_path = output_dir / "rawctx.yaml"
    write_yaml(manifest_path, manifest)
    written.append(manifest_path)

    readme_path = output_dir / "README.md"
    readme_path.write_text(
        (
            f"# {package_name}\n\n"
            f"Converted from `{source_format}` using `rawctx convert`.\n"
        ),
        encoding="utf-8",
    )
    written.append(readme_path)

    return written
