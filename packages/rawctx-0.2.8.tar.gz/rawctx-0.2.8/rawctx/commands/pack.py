from __future__ import annotations

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import client as rawctx_client


@click.command()
@click.argument("target_dir", required=False, default=".")
@click.option("--output-dir", default="dist", show_default=True)
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
def pack(target_dir: str, output_dir: str, json_output: bool) -> None:
    """Build a deterministic rawctx package archive. [user]"""

    try:
        with rawctx_client() as sdk_client:
            payload = sdk_client.pack(target_dir, output_dir=output_dir)
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    click.echo(f"package created: {payload['archive_path']}")
