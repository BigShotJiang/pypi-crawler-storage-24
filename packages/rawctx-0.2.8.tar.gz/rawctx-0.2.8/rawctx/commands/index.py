from __future__ import annotations

from pathlib import Path

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import client as rawctx_client


def _emit_index_summary(payload: dict[str, object], *, json_output: bool) -> None:
    if json_output:
        echo_json(payload)
        return

    for result in payload["results"]:
        package_ref = result.get("package_ref") or "-"
        version = result.get("version") or "-"
        reason = f" ({result['reason']})" if result.get("reason") else ""
        click.echo(f"[{result['status']}] {result['repo']} -> {package_ref}@{version}{reason}")

    summary = payload["summary"]
    click.echo(
        f"summary: total={summary['total']} indexed={summary['indexed']} "
        f"skipped={summary['skipped']} dry_run={summary['dry_run']} failed={summary['failed']}"
    )


@click.group()
def index() -> None:
    """Index external package sources into rawctx Hub. [ops]"""


@index.command("dbt")
@click.option("--seed-file", "seed_file", type=click.Path(path_type=Path, exists=True), required=True)
@click.option("--only", "only_repo", default=None, help="Index only this repo (owner/name)")
@click.option("--limit", type=int, default=0, show_default=True, help="Max entries to process (0 = no limit)")
@click.option("--dry-run", is_flag=True, default=False, help="Run conversion checks without publishing")
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def index_dbt(
    seed_file: Path,
    only_repo: str | None,
    limit: int,
    dry_run: bool,
    json_output: bool,
    registry_override: str | None,
) -> None:
    """Index seeded dbt packages. [ops]"""

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            payload = sdk_client.index_dbt(seed_file=seed_file, only=only_repo, limit=limit, dry_run=dry_run)
    except Exception as exc:
        raise_click_for_error(exc)
        return

    _emit_index_summary(payload, json_output=json_output)
    if payload["summary"]["failed"] > 0:
        if json_output:
            raise click.exceptions.Exit(1)
        raise click.ClickException("one or more indexing jobs failed")


@index.command("git")
@click.option("--repo", required=True, help="GitHub repository owner/name")
@click.option("--source-ref", default="main", show_default=True, help="Git reference (branch/tag/sha)")
@click.option("--package-version", required=True, help="Published package version (SemVer)")
@click.option("--package-name", default=None, help="Override indexed package name")
@click.option("--scope", default="github-hub", show_default=True, help="Indexed package scope")
@click.option(
    "--model-glob",
    "model_globs",
    multiple=True,
    help="Optional glob for OSI model files relative to repo root (repeatable)",
)
@click.option("--dry-run", is_flag=True, default=False, help="Run discovery checks without publishing")
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def index_git(
    repo: str,
    source_ref: str,
    package_version: str,
    package_name: str | None,
    scope: str,
    model_globs: tuple[str, ...],
    dry_run: bool,
    json_output: bool,
    registry_override: str | None,
) -> None:
    """Index Git repositories that already contain OSI documents. [ops]"""

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            payload = sdk_client.index_git(
                repo=repo,
                source_ref=source_ref,
                package_version=package_version,
                package_name=package_name,
                scope=scope,
                model_glob=model_globs,
                dry_run=dry_run,
            )
    except Exception as exc:
        raise_click_for_error(exc)
        return

    _emit_index_summary(payload, json_output=json_output)
    if payload["summary"]["failed"] > 0:
        if json_output:
            raise click.exceptions.Exit(1)
        raise click.ClickException("one or more indexing jobs failed")
