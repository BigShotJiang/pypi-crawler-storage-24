from __future__ import annotations

import json

import click

from rawctx.errors import RawctxError, UsageError as RawctxUsageError


def echo_json(payload: object) -> None:
    click.echo(json.dumps(payload, indent=2, sort_keys=False))


def raise_click_for_error(exc: Exception) -> None:
    if isinstance(exc, RawctxUsageError):
        raise click.UsageError(str(exc)) from exc
    if isinstance(exc, RawctxError):
        raise click.ClickException(str(exc)) from exc
    raise click.ClickException(str(exc)) from exc
