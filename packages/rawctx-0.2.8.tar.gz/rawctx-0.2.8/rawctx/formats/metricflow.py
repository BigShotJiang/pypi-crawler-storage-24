from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

import yaml
from yaml import YAMLError

from rawctx.converter.base import ConversionError


@dataclass(frozen=True)
class ParsedMetricFlowProject:
    root: Path
    project_name: str
    project_version: str | None
    semantic_models: list[dict[str, Any]]
    metrics: list[dict[str, Any]]
    source_files: list[Path]


def _resolve_root(path: Path) -> Path:
    resolved = path.expanduser().resolve()
    if not resolved.exists():
        raise ConversionError("input path does not exist", file_path=resolved)

    if resolved.is_file():
        if resolved.name != "dbt_project.yml":
            raise ConversionError("input file must be dbt_project.yml", file_path=resolved)
        return resolved.parent

    if resolved.is_dir():
        return resolved

    raise ConversionError("input path must be file or directory", file_path=resolved)


def _read_yaml(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return yaml.safe_load(handle)
    except YAMLError as exc:
        raise ConversionError("invalid YAML syntax", file_path=path) from exc
    except OSError as exc:
        raise ConversionError("failed to read file", file_path=path) from exc


def _normalize_items(raw: Any) -> list[dict[str, Any]]:
    if isinstance(raw, list):
        return [item for item in raw if isinstance(item, dict)]
    return []


def _extract_items(doc: Any, key: str) -> list[dict[str, Any]]:
    if isinstance(doc, dict):
        return _normalize_items(doc.get(key))
    if isinstance(doc, list):
        out: list[dict[str, Any]] = []
        for item in doc:
            if isinstance(item, dict):
                out.extend(_normalize_items(item.get(key)))
        return out
    return []


def _parse_project_file(root: Path) -> tuple[str, str | None]:
    project_file = root / "dbt_project.yml"
    if not project_file.is_file():
        raise ConversionError("dbt_project.yml not found", file_path=project_file)

    project_doc = _read_yaml(project_file)
    if not isinstance(project_doc, dict):
        raise ConversionError("dbt_project.yml must be a mapping", file_path=project_file)

    raw_name = project_doc.get("name")
    if not isinstance(raw_name, str) or not raw_name.strip():
        raise ConversionError("dbt project name is required", file_path=project_file, field="name")

    raw_version = project_doc.get("version")
    version: str | None = None
    if raw_version is not None:
        if isinstance(raw_version, (int, float)):
            version = str(raw_version)
        elif isinstance(raw_version, str):
            version = raw_version.strip() or None

    return raw_name.strip(), version


def _try_parse_with_official_parser(root: Path) -> ParsedMetricFlowProject | None:
    # MetricFlow/dbt parser public APIs are version-sensitive. Try import to prefer
    # official parser when available, but keep deterministic YAML fallback path.
    try:
        __import__("dbt_semantic_interfaces")
    except Exception:
        return None
    return None


def _collect_semantic_yaml_files(root: Path) -> list[Path]:
    models_dir = root / "models"
    if not models_dir.is_dir():
        return []

    files = [
        *models_dir.rglob("*.yml"),
        *models_dir.rglob("*.yaml"),
    ]
    return sorted({path.resolve() for path in files})


def load_metricflow_project(path: Path) -> ParsedMetricFlowProject:
    root = _resolve_root(path)

    parsed = _try_parse_with_official_parser(root)
    if parsed is not None:
        return parsed

    project_name, project_version = _parse_project_file(root)

    semantic_models: list[dict[str, Any]] = []
    metrics: list[dict[str, Any]] = []
    source_files = _collect_semantic_yaml_files(root)

    for file_path in source_files:
        doc = _read_yaml(file_path)

        for semantic_model in _extract_items(doc, "semantic_models"):
            model_copy = dict(semantic_model)
            model_copy["__rawctx_source_file"] = str(file_path)
            semantic_models.append(model_copy)

        for metric in _extract_items(doc, "metrics"):
            metric_copy = dict(metric)
            metric_copy["__rawctx_source_file"] = str(file_path)
            metrics.append(metric_copy)

    if not semantic_models:
        raise ConversionError(
            "no semantic_models found under dbt models/",
            file_path=root / "models",
            field="semantic_models",
        )

    return ParsedMetricFlowProject(
        root=root,
        project_name=project_name,
        project_version=project_version,
        semantic_models=semantic_models,
        metrics=metrics,
        source_files=source_files,
    )
