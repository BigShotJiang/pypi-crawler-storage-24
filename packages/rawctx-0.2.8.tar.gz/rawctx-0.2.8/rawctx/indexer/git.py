from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
import shutil
import tempfile
from urllib.parse import quote

import yaml

from rawctx.formats.osi import validate_osi
from rawctx.indexer.dbt import IndexRunResult
from rawctx.indexer.github import GitHubIndexError, download_repo_archive
from rawctx.packaging.builder import build_package_archive
from rawctx.packaging.manifest import SEMVER_RE, ValidationError
from rawctx.registry.client import RegistryClient, RegistryError
from rawctx.validation import validate_target


@dataclass(frozen=True)
class GitIndexEntry:
    repo: str
    source_ref: str
    package_version: str
    package_name: str | None = None
    scope: str = "github-hub"
    model_globs: tuple[str, ...] = ()


def _normalize_name(value: str) -> str:
    lowered = value.strip().lower().replace("_", "-").replace(" ", "-")
    out = []
    for ch in lowered:
        if ch.isalnum() or ch == "-":
            out.append(ch)
        else:
            out.append("-")
    compact = "".join(out).strip("-")
    while "--" in compact:
        compact = compact.replace("--", "-")
    return compact or "package"


def _default_package_name(repo: str, explicit: str | None) -> str:
    if explicit:
        return _normalize_name(explicit)
    leaf = repo.split("/", 1)[-1]
    return _normalize_name(leaf)


def _github_source_url(repo: str, ref: str) -> str:
    normalized_repo = repo.strip()
    normalized_ref = ref.strip()
    base = f"https://github.com/{normalized_repo}"
    if not normalized_ref:
        return base
    encoded_ref = quote(normalized_ref, safe="/._-")
    return f"{base}/tree/{encoded_ref}"


def _collect_by_globs(project_root: Path, globs: tuple[str, ...]) -> list[Path]:
    paths: set[Path] = set()
    for pattern in globs:
        cleaned = pattern.strip()
        if not cleaned:
            continue
        for candidate in project_root.glob(cleaned):
            if candidate.is_file():
                paths.add(candidate.resolve())
    return sorted(paths)


def _collect_osi_candidates(project_root: Path) -> list[Path]:
    preferred = _collect_by_globs(project_root, ("**/*.osi.yaml", "**/*.osi.yml"))
    if preferred:
        return preferred
    return _collect_by_globs(project_root, ("**/*.yaml", "**/*.yml"))


def _discover_osi_models(project_root: Path, *, model_globs: tuple[str, ...]) -> list[Path]:
    if model_globs:
        candidates = _collect_by_globs(project_root, model_globs)
    else:
        candidates = _collect_osi_candidates(project_root)

    models: list[Path] = []
    for candidate in candidates:
        try:
            validate_osi(candidate)
        except ValidationError:
            continue
        models.append(candidate)
    return models


def _write_indexed_manifest(
    package_dir: Path,
    *,
    package_ref: str,
    package_version: str,
    description: str,
    model_paths: list[str],
    source_repo: str,
) -> None:
    payload = {
        "name": package_ref,
        "version": package_version,
        "format": "osi",
        "description": description,
        "source": "github",
        "repository": f"https://github.com/{source_repo}",
        "tags": ["indexed", "github", "osi"],
        "models": model_paths,
    }
    text = yaml.safe_dump(payload, sort_keys=False, allow_unicode=False)
    (package_dir / "rawctx.yaml").write_text(text, encoding="utf-8")


def _materialize_osi_package(
    project_root: Path,
    package_dir: Path,
    *,
    package_ref: str,
    package_version: str,
    repo: str,
    model_globs: tuple[str, ...],
) -> tuple[list[str], str]:
    package_dir.mkdir(parents=True, exist_ok=True)

    models = _discover_osi_models(project_root, model_globs=model_globs)
    if not models:
        return [], "no OSI models found"

    model_paths: list[str] = []
    for source_model in models:
        rel = source_model.relative_to(project_root)
        destination = package_dir / "models" / rel
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_model, destination)
        model_paths.append(destination.relative_to(package_dir).as_posix())

    model_paths.sort()

    readme_src = project_root / "README.md"
    if readme_src.is_file():
        shutil.copy2(readme_src, package_dir / "README.md")

    description = f"Indexed OSI package from GitHub: {repo}"
    _write_indexed_manifest(
        package_dir,
        package_ref=package_ref,
        package_version=package_version,
        description=description,
        model_paths=model_paths,
        source_repo=repo,
    )

    validate_target(package_dir, "auto")
    return model_paths, ""


def index_git_repo(
    *,
    entry: GitIndexEntry,
    registry: str,
    token: str | None,
    dry_run: bool,
) -> IndexRunResult:
    package_name = _default_package_name(entry.repo, entry.package_name)
    package_ref = f"@{entry.scope}/{package_name}"

    if SEMVER_RE.fullmatch(entry.package_version) is None:
        return IndexRunResult(
            repo=entry.repo,
            package_ref=package_ref,
            version=entry.package_version,
            status="skipped",
            reason="package_version must be strict SemVer X.Y.Z",
        )

    workspace = Path(tempfile.mkdtemp(prefix="rawctx-index-git-"))
    try:
        try:
            project_root = download_repo_archive(repo=entry.repo, ref=entry.source_ref, target_dir=workspace / "repo")
        except GitHubIndexError as exc:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason=str(exc),
            )

        package_dir = workspace / "package"
        try:
            model_paths, reason = _materialize_osi_package(
                project_root,
                package_dir,
                package_ref=package_ref,
                package_version=entry.package_version,
                repo=entry.repo,
                model_globs=entry.model_globs,
            )
        except ValidationError as exc:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason=str(exc),
            )

        if not model_paths:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="skipped",
                reason=reason or "no OSI models found",
            )

        if dry_run:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="dry-run",
                reason=f"osi_models={len(model_paths)}",
            )

        if not token:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason="authentication required for indexing",
            )

        build_dir = workspace / "dist"
        build_dir.mkdir(parents=True, exist_ok=True)
        build = build_package_archive(package_dir, build_dir)
        archive_bytes = build.archive_path.read_bytes()
        checksum = sha256(archive_bytes).hexdigest()

        payload = {
            "scope": entry.scope,
            "name": package_name,
            "description": f"Indexed OSI package from GitHub: {entry.repo}",
            "format": "osi",
            "source_format": None,
            "origin": "indexed",
            "origin_url": _github_source_url(entry.repo, entry.source_ref),
            "origin_repo": entry.repo,
            "source": "github",
            "repository_url": f"https://github.com/{entry.repo}",
            "tags": ["indexed", "github", "osi"],
        }

        client = RegistryClient(registry=registry, token=token)
        try:
            try:
                client.create_package(payload=payload)
            except RegistryError as exc:
                if exc.status_code != 409:
                    raise

            try:
                upload = client.request_version_upload(
                    scope=entry.scope,
                    name=package_name,
                    version=entry.package_version,
                    file_size=len(archive_bytes),
                    checksum_sha256=checksum,
                    origin_ref=entry.source_ref,
                    content_type="application/gzip",
                )
            except RegistryError as exc:
                if exc.status_code == 409:
                    return IndexRunResult(
                        repo=entry.repo,
                        package_ref=package_ref,
                        version=entry.package_version,
                        status="skipped",
                        reason="version already exists",
                    )
                raise

            upload_url = str(upload.get("upload_url") or "")
            if not upload_url:
                return IndexRunResult(
                    repo=entry.repo,
                    package_ref=package_ref,
                    version=entry.package_version,
                    status="failed",
                    reason="registry did not return upload_url",
                )

            client.upload_bytes(upload_url=upload_url, payload=archive_bytes, content_type="application/gzip")
            client.complete_version(
                scope=entry.scope,
                name=package_name,
                version=entry.package_version,
                checksum_sha256=checksum,
            )
        except RegistryError as exc:
            return IndexRunResult(
                repo=entry.repo,
                package_ref=package_ref,
                version=entry.package_version,
                status="failed",
                reason=str(exc),
            )
        finally:
            client.close()

        return IndexRunResult(
            repo=entry.repo,
            package_ref=package_ref,
            version=entry.package_version,
            status="indexed",
            reason=f"osi_models={len(model_paths)}",
        )
    finally:
        shutil.rmtree(workspace, ignore_errors=True)
