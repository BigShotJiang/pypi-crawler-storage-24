from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.registry.client import RegistryClient, SearchResult
from rawctx.registry.models import SearchItem


def test_search_online_passes_filters(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    observed: dict[str, object] = {}

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed.update(
            {
                "query": query,
                "format": format,
                "source_format": source_format,
                "origin": origin,
                "domain": domain,
                "source": source,
                "tags": tags,
                "sort": sort,
                "page": page,
                "size": size,
            }
        )
        return SearchResult(
            items=[
                SearchItem(
                    id="pkg-1",
                    scope="owner",
                    name="sample",
                    description="Sample",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="shopify",
                    domain="finance",
                    tags=["demo"],
                    download_count=1,
                    star_count=2,
                )
            ],
            meta={"page": page, "size": size, "total": 1},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "search",
            "salesforce revenue",
            "--format",
            "osi",
            "--domain",
            "finance",
            "--origin",
            "indexed",
            "--source",
            "shopify",
            "--tags",
            "demo",
            "--page",
            "2",
            "--size",
            "10",
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code == 0
    assert observed == {
        "query": "salesforce revenue",
        "format": "osi",
        "source_format": None,
        "origin": "indexed",
        "domain": "finance",
        "source": "shopify",
        "tags": "demo",
        "sort": "recent",
        "page": 2,
        "size": 10,
    }
    assert "@owner/sample" in result.output


def test_search_online_prints_expanded_status(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        return SearchResult(
            items=[
                SearchItem(
                    id="pkg-1",
                    scope="owner",
                    name="sample",
                    description="Sample",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="shopify",
                    domain="finance",
                    tags=["demo"],
                    download_count=1,
                    star_count=2,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "query_mode": "expanded", "expanded": True, "applied_rewrite": "sampel"},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "search",
            "sampel",
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code == 0
    assert "Expanded search applied (sampel)." in result.output


def test_search_online_prefers_public_results_over_authenticated_fallback(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.setenv("RAWCTX_TOKEN", "rxctx_secret")

    observed_tokens: list[str | None] = []

    def fake_search_packages(self, *, query, format, source_format, origin, domain, source, tags, sort, page, size):
        observed_tokens.append(self.token)
        if self.token:
            return SearchResult(
                items=[
                    SearchItem(
                        id="private-1",
                        scope="owner",
                        name="private-result",
                        description="Private fallback result",
                        format="osi",
                        source_format=None,
                        origin="native",
                        origin_url=None,
                        origin_repo=None,
                        source="salesforce",
                        domain="crm",
                        tags=["private"],
                        download_count=0,
                        star_count=0,
                    )
                ],
                meta={"page": page, "size": size, "total": 1, "engine": "postgres", "query_mode": "fallback"},
            )
        return SearchResult(
            items=[
                SearchItem(
                    id="public-1",
                    scope="owner",
                    name="public-result",
                    description="Public search result",
                    format="osi",
                    source_format=None,
                    origin="native",
                    origin_url=None,
                    origin_repo=None,
                    source="salesforce",
                    domain="crm",
                    tags=["public"],
                    download_count=0,
                    star_count=0,
                )
            ],
            meta={"page": page, "size": size, "total": 1, "engine": "opensearch", "query_mode": "exact"},
        )

    monkeypatch.setattr(RegistryClient, "search_packages", fake_search_packages)

    runner = CliRunner()
    result = runner.invoke(main, ["search", "sf revenue", "--registry", "https://registry.example", "--json"])

    assert result.exit_code == 0, result.output
    payload = result.output
    assert '"name": "public-result"' in payload
    assert observed_tokens == [None]
