from __future__ import annotations

from pathlib import Path

from click.testing import CliRunner

from rawctx.cli import main
from rawctx.indexer.dbt import IndexRunResult
from rawctx.sdk import RawctxClient


def _write_seed(path: Path) -> Path:
    seed = path / "seed.yaml"
    seed.write_text(
        (
            "- repo: fivetran/dbt_shopify\n"
            "  hub_url: https://hub.getdbt.com/fivetran/shopify/latest/\n"
            "  source_ref: v0.12.0\n"
            "  package_version: 0.12.0\n"
            "  package_name: fivetran-shopify\n"
        ),
        encoding="utf-8",
    )
    return seed


def test_index_dbt_dry_run(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    seed = _write_seed(tmp_path)

    observed: dict[str, object] = {}

    def fake_index_dbt(self, *, seed_file, only=None, limit=0, dry_run=False):  # type: ignore[no-untyped-def]
        observed["seed_file"] = Path(seed_file)
        observed["registry"] = self.registry_override
        observed["token"] = self.token_override
        observed["dry_run"] = dry_run
        return {
            "mode": "dbt",
            "seed_file": str(seed_file),
            "results": [
                {
                    "repo": "fivetran/dbt_shopify",
                    "package_ref": "@dbt-hub/fivetran-shopify",
                    "version": "0.12.0",
                    "status": "dry-run",
                    "reason": "semantic_models=2",
                }
            ],
            "summary": {"total": 1, "indexed": 0, "skipped": 0, "dry_run": 1, "failed": 0},
        }

    monkeypatch.setattr(RawctxClient, "index_dbt", fake_index_dbt)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "index",
            "dbt",
            "--seed-file",
            str(seed),
            "--dry-run",
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert observed["seed_file"] == seed
    assert observed["registry"] == "https://registry.example"
    assert observed["token"] is None
    assert observed["dry_run"] is True
    assert "[dry-run] fivetran/dbt_shopify" in result.output


def test_index_dbt_requires_auth_when_not_dry_run(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.delenv("RAWCTX_TOKEN", raising=False)
    seed = _write_seed(tmp_path)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "index",
            "dbt",
            "--seed-file",
            str(seed),
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code != 0
    assert "Authentication required" in result.output


def test_index_git_dry_run(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))

    observed: dict[str, object] = {}

    def fake_index_git(
        self,
        *,
        repo,
        source_ref="main",
        package_version,
        package_name=None,
        scope="github-hub",
        model_glob=None,
        dry_run=False,
    ):  # type: ignore[no-untyped-def]
        observed["repo"] = repo
        observed["source_ref"] = source_ref
        observed["package_version"] = package_version
        observed["package_name"] = package_name
        observed["scope"] = scope
        observed["model_globs"] = model_glob
        observed["registry"] = self.registry_override
        observed["token"] = self.token_override
        observed["dry_run"] = dry_run
        return {
            "mode": "git",
            "results": [
                {
                    "repo": repo,
                    "package_ref": "@dbt-hub/osi",
                    "version": package_version,
                    "status": "dry-run",
                    "reason": "osi_models=1",
                }
            ],
            "summary": {"total": 1, "indexed": 0, "skipped": 0, "dry_run": 1, "failed": 0},
        }

    monkeypatch.setattr(RawctxClient, "index_git", fake_index_git)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "index",
            "git",
            "--repo",
            "open-semantic-interchange/OSI",
            "--source-ref",
            "main",
            "--package-version",
            "0.1.0",
            "--package-name",
            "osi",
            "--scope",
            "github-hub",
            "--model-glob",
            "examples/*.yaml",
            "--dry-run",
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code == 0, result.output
    assert observed["repo"] == "open-semantic-interchange/OSI"
    assert observed["source_ref"] == "main"
    assert observed["package_version"] == "0.1.0"
    assert observed["package_name"] == "osi"
    assert observed["scope"] == "github-hub"
    assert observed["model_globs"] == ("examples/*.yaml",)
    assert observed["registry"] == "https://registry.example"
    assert observed["token"] is None
    assert observed["dry_run"] is True
    assert "[dry-run] open-semantic-interchange/OSI" in result.output


def test_index_git_requires_auth_when_not_dry_run(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("RAWCTX_CONFIG", str(tmp_path / "rawctx" / "config.yaml"))
    monkeypatch.delenv("RAWCTX_TOKEN", raising=False)

    runner = CliRunner()
    result = runner.invoke(
        main,
        [
            "index",
            "git",
            "--repo",
            "open-semantic-interchange/OSI",
            "--source-ref",
            "main",
            "--package-version",
            "0.1.0",
            "--registry",
            "https://registry.example",
        ],
    )

    assert result.exit_code != 0
    assert "Authentication required" in result.output
