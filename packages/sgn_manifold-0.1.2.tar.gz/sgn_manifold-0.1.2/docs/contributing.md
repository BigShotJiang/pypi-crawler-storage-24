# Contributing to Manifold

We welcome contributions to Manifold! This guide will help you get started.

## Getting Started

### Development Setup

1. Fork the repository on GitLab
2. Clone your fork:
   ```bash
   git clone https://git.ligo.org/YOUR_USERNAME/manifold.git
   cd manifold
   ```

3. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

4. Install in development mode with all dependencies:
   ```bash
   pip install -e ".[dev,test,docs]"
   ```

5. Install pre-commit hooks:
   ```bash
   pre-commit install
   ```

### Development Workflow

1. Create a new branch for your feature:
   ```bash
   git checkout -b feature/my-new-feature
   ```

2. Make your changes and commit:
   ```bash
   git add .
   git commit -m "Add my new feature"
   ```

3. Run tests and checks:
   ```bash
   make  # Runs all formatting, linting, type checking, and tests
   ```

4. Push to your fork and create a merge request

## Code Standards

### Code Style

We use several tools to maintain code quality:

- **black**: Code formatting
- **isort**: Import sorting
- **flake8**: Linting
- **mypy**: Type checking

Run all checks with:
```bash
make
```

### Testing

- Write tests for all new functionality
- Place tests in the `tests/` directory
- Use pytest for testing
- Aim for high test coverage (check with `pytest --cov`)

Example test:
```python
import pytest
from manifold import coordinate

def test_coordinate_creation():
    """Test creating a Coordinates object"""
    coords = coordinate.Coordinates(1.0, 2.0, 3.0)
    assert len(coords) == 3
    assert coords[0] == 1.0
    assert coords[1] == 2.0
    assert coords[2] == 3.0
```

### Documentation

- Add docstrings to all public functions and classes
- Use Google-style docstrings
- Update relevant documentation in `docs/`
- Include examples where appropriate

Example docstring:
```python
def transform_coordinates(coords, transform_func):
    """Transform coordinates using a given transformation function.
    
    Args:
        coords: Input coordinates as a Coordinates object
        transform_func: Function that takes coordinates and returns transformed coordinates
    
    Returns:
        Transformed coordinates as a Coordinates object
        
    Raises:
        ValueError: If transformation fails
        
    Example:
        >>> coords = Coordinates(10.0, 20.0)
        >>> transformed = transform_coordinates(coords, log_transform)
    """
```

## Types of Contributions

### Bug Reports

- Use the GitLab issue tracker
- Include a minimal reproducible example
- Specify your environment (OS, Python version, etc.)
- Describe expected vs. actual behavior

### Feature Requests

- Discuss major changes in an issue first
- Explain the use case and motivation
- Consider backward compatibility

### Code Contributions

Areas where contributions are especially welcome:

1. **New coordinate transformations**: Additional astrophysically relevant coordinates
2. **Metric implementations**: Different waveform approximants
3. **Covering algorithms**: Novel template placement strategies
4. **Performance optimizations**: Speedups for large-scale calculations
5. **Documentation**: Tutorials, examples, and guides
6. **Tests**: Increasing test coverage

## Review Process

1. All merge requests are reviewed by maintainers
2. CI/CD pipeline must pass (tests, linting, etc.)
3. Documentation must be updated as needed
4. Changes should include appropriate tests

## Building Documentation

To build and view the documentation locally:

```bash
mkdocs serve
```

Then open http://localhost:8000 in your browser.

## Release Process

Releases are managed by maintainers and follow semantic versioning:

- **MAJOR**: Incompatible API changes
- **MINOR**: New functionality, backward compatible
- **PATCH**: Bug fixes, backward compatible

## Questions?

- Check existing issues and documentation
- Ask in the merge request or issue
- Contact the maintainers

Thank you for contributing to Manifold!