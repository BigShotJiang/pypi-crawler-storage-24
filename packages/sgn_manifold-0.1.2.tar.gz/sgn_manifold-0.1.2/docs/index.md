# Manifold Documentation

<div align="center">
  <img src="assets/img/manifold-logo.png" alt="Manifold Logo" width="400">
</div>

## Overview

Manifold is a Python library for constructing template banks for gravitational wave data analysis. It provides efficient algorithms for covering parameter spaces with templates, computing metrics on manifolds, and optimizing template placement for gravitational wave searches.

## Key Features

- **Flexible Coordinate Systems**: Support for arbitrary coordinate transformations on parameter manifolds
- **Metric Computation**: Efficient calculation of Fisher information matrices and parameter space metrics
- **Template Bank Generation**: Algorithms for optimal template placement and coverage
- **Signal Modeling**: Interfaces for various gravitational wave signal models
- **Optimization Tools**: SNR optimization and template bank refinement

## Installation

### From Source

```bash
git clone https://git.ligo.org/chad.hanna/manifold.git
cd manifold
pip install -e .
```

### Development Installation

To install with development dependencies:

```bash
pip install -e ".[dev,test]"
```

## Quick Start

Here's a simple example of using Manifold to work with coordinate transformations:

```python
from manifold import coordinate

# Define custom coordinate types
class Mass1(coordinate.CoordinateType):
    key = "m1"

class Mass2(coordinate.CoordinateType):
    key = "m2"

# Create a coordinate point
coords = coordinate.Coordinates(10.0, 20.0, coord_types=[Mass1, Mass2])
print(coords)  # Output: Coordinate(m1=10.0, m2=20.0)

# Perform coordinate arithmetic
coords2 = coordinate.Coordinates(5.0, 10.0, coord_types=[Mass1, Mass2])
result = coords + coords2
print(result)  # Output: Coordinate(m1=15.0, m2=30.0)
```

## Core Concepts

### Coordinates

The coordinate system in Manifold provides a flexible framework for representing points in parameter space. Key features include:

- **Type Safety**: Coordinate types ensure that operations are performed on compatible coordinates
- **Transformations**: Support for arbitrary coordinate transformations (e.g., mass to chirp mass)
- **Arithmetic Operations**: Natural addition and manipulation of coordinate points

### Metrics

Manifold computes parameter space metrics using the Fisher information matrix approach. This allows for:

- Accurate distance calculations between templates
- Optimal template spacing
- Efficient coverage of parameter space

### Template Banks

Template banks are collections of signal templates that cover a parameter space. Manifold provides:

- Algorithms for template placement
- Tools for bank refinement and optimization
- Support for hierarchical template banks

## Project Structure

```
manifold/
├── coordinate.py      # Coordinate system and transformations
├── metric.py          # Metric calculations and Fisher matrices
├── cover.py           # Template bank covering algorithms
├── signal.py          # Signal model interfaces
├── sources/           # Specific source implementations
│   └── cbc.py        # Compact binary coalescence
└── utilities/         # Helper functions and utilities
```

## Next Steps

- Read the [Getting Started Guide](user-guide/getting-started.md) for a detailed introduction
- Explore the [API Reference](api/coordinate.md) for detailed documentation
- Check out [Examples](examples/index.md) for practical use cases

## Contributing

We welcome contributions! Please see our [Contributing Guide](contributing.md) for details on how to get involved.

## License

Manifold is distributed under the GPL-3.0 license. See the LICENSE file for details.