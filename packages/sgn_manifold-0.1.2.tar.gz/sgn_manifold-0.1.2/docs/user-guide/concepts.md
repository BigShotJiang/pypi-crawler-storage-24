# Core Concepts

This guide explains the fundamental concepts in Manifold and how they relate to gravitational wave template bank generation.

## Parameter Spaces

In gravitational wave astronomy, we search for signals by comparing data against templates - theoretical waveforms with different parameters. The **parameter space** is the multi-dimensional space of all possible signal parameters.

For compact binary coalescences (CBCs), common parameters include:
- Component masses (m₁, m₂)
- Spin magnitudes and orientations
- Orbital eccentricity
- Sky location and orientation

## Coordinates and Transformations

### Coordinate Systems

Different coordinate systems can be more natural for different purposes:

- **Component masses (m₁, m₂)**: Natural for astrophysical interpretation
- **Chirp mass and mass ratio (Mchirp, q)**: Better for waveform generation
- **Total mass and symmetric mass ratio (M, η)**: Useful for post-Newtonian expansions

Manifold's coordinate system allows seamless transformations between these representations.

### Type Safety

Coordinate types prevent common errors:

```python
from manifold import coordinate

class Mass1(coordinate.CoordinateType):
    key = "m1"

class Spin1(coordinate.CoordinateType):
    key = "s1"

# This prevents accidentally mixing incompatible coordinates
mass_point = coordinate.Coordinates(30.0, coord_types=[Mass1])
spin_point = coordinate.Coordinates(0.5, coord_types=[Spin1])

# This would raise an error
# combined = mass_point + spin_point  # Error: incompatible types
```

## Metrics

### Fisher Information Matrix

The Fisher information matrix quantifies how distinguishable nearby templates are. For parameters θᵢ, the Fisher matrix elements are:

```
Γᵢⱼ = ⟨∂h/∂θᵢ | ∂h/∂θⱼ⟩
```

where h is the gravitational wave strain and ⟨·|·⟩ is the noise-weighted inner product.

### Parameter Space Metric

The metric tensor gᵢⱼ defines distances in parameter space:

```
ds² = gᵢⱼ dθⁱ dθʲ
```

This metric determines:
- How densely templates must be placed
- The shape of template regions
- Optimal coordinate systems

### Mismatch and Coverage

The **mismatch** between two templates quantifies how different they appear to a detector:

```
mismatch = 1 - ⟨h₁|h₂⟩ / √(⟨h₁|h₁⟩⟨h₂|h₂⟩)
```

A template bank with maximum mismatch MM provides coverage such that any signal has at least (1-MM) overlap with some template.

## Template Banks

### Covering Problem

Template bank generation is fundamentally a covering problem: place templates to ensure every possible signal is sufficiently close to at least one template.

Key challenges:
- High-dimensional parameter spaces
- Non-uniform metrics
- Computational efficiency
- Physical boundaries

### Placement Algorithms

Manifold supports various template placement strategies:

1. **Lattice-based**: Regular grids transformed by the metric
2. **Stochastic**: Random placement with rejection sampling
3. **Hierarchical**: Multi-resolution approaches
4. **Adaptive**: Metric-guided refinement

### Bank Optimization

After initial placement, banks can be optimized by:
- Removing redundant templates
- Filling coverage gaps
- Adjusting for computational constraints
- Balancing sensitivity vs. computational cost

## Signal Models

### Waveform Families

Different physical systems require different waveform models:

- **Inspiral-only**: Early inspiral phase for low-mass systems
- **Inspiral-merger-ringdown (IMR)**: Complete coalescence for comparable masses
- **Eccentric**: Systems with non-circular orbits
- **Precessing**: Systems with misaligned spins

### Approximants

Waveform approximants balance accuracy and speed:

- **Post-Newtonian**: Analytical expansions for inspiral
- **Effective-one-body (EOB)**: Semi-analytical full waveforms
- **Phenomenological (IMRPhenom)**: Calibrated analytical fits
- **Numerical relativity surrogates**: Data-driven models

## Practical Considerations

### Computational Efficiency

Template banks must balance:
- **Coverage**: Ensuring all signals are detectable
- **Size**: Computational cost scales with template count
- **Accuracy**: Higher-order effects vs. simplicity

### Coordinate Choices

Good coordinates for template placement:
- Flatten the metric (make it more uniform)
- Respect physical boundaries
- Have clear physical interpretation
- Enable efficient waveform generation

### Validation

Template banks should be validated by:
- Checking coverage with injection studies
- Computing efficiency vs. optimal matched filter
- Verifying computational feasibility
- Testing on real detector data

## Examples in Manifold

### Metric Calculation

```python
from manifold import metric
from manifold.sources import cbc

# Create a CBC metric for binary neutron stars
metric_obj = cbc.CBCMetric(
    f_low=30.0,  # Low frequency cutoff
    f_high=2048.0,  # High frequency cutoff
    psd=aLIGO_psd,  # Detector noise curve
)

# Evaluate metric at a point
point = coordinate.Coordinates(1.4, 1.4)  # Two neutron stars
g = metric_obj(point)
```

### Template Placement

```python
from manifold import cover

# Create a template bank
bank = cover.TemplateBank(
    metric=metric_obj,
    bounds={"m1": (1.0, 3.0), "m2": (1.0, 3.0)},
    max_mismatch=0.03,  # 3% maximum mismatch
)

# Generate templates
bank.generate()
print(f"Generated {len(bank)} templates")
```

## Further Reading

- [Coordinate Module API](../api/coordinate.md) - Detailed coordinate system documentation
- [Metric Module API](../api/metric.md) - Metric calculation details
- [Examples](../examples/index.md) - Complete working examples