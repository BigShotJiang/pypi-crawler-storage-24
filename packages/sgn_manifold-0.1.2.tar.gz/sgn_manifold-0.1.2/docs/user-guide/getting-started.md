# Getting Started with Manifold

This guide will help you get started with Manifold for gravitational wave template bank generation.

## Installation

### Prerequisites

Manifold requires Python 3.8 or later. We recommend using a virtual environment:

```bash
python -m venv manifold-env
source manifold-env/bin/activate  # On Windows: manifold-env\Scripts\activate
```

### Install from Source

Clone the repository and install in development mode:

```bash
git clone https://git.ligo.org/chad.hanna/manifold.git
cd manifold
pip install -e ".[dev,test]"
```

### Verify Installation

Test your installation by importing Manifold:

```python
import manifold
print(manifold.__version__)
```

## Basic Concepts

### Coordinates

Coordinates represent points in parameter space. In gravitational wave astronomy, these might be masses, spins, or other physical parameters.

```python
from manifold import coordinate

# Define coordinate types for binary masses
class Mass1(coordinate.CoordinateType):
    key = "m1"

class Mass2(coordinate.CoordinateType):
    key = "m2"

# Create a coordinate point
binary = coordinate.Coordinates(30.0, 20.0, coord_types=[Mass1, Mass2])
print(f"Binary system: {binary}")
```

### Coordinate Transformations

Often we need to work in different coordinate systems. For example, converting between component masses and chirp mass:

```python
import numpy as np

class ChirpMass(coordinate.CoordinateType):
    key = "mchirp"

class MassRatio(coordinate.CoordinateType):
    key = "q"

class MassTransform(coordinate.CoordFunc):
    TO_TYPES = (ChirpMass, MassRatio)
    FROM_TYPES = (Mass1, Mass2)
    
    def __call__(self, c, inv=False):
        if inv:
            # Convert from chirp mass, q to m1, m2
            c_dict = self._normalize_coorddict(c, inv=True)
            mchirp = c_dict[ChirpMass]
            q = c_dict[MassRatio]
            
            # q = m2/m1, with m1 >= m2, so q <= 1
            m1 = mchirp * (1 + q)**(1/5) / q**(3/5)
            m2 = q * m1
            
            return {Mass1: float(m1), Mass2: float(m2)}
        else:
            # Convert from m1, m2 to chirp mass, q
            if isinstance(c, dict):
                c = self._normalize_coorddict(c)
                m1 = c[Mass1]
                m2 = c[Mass2]
            else:
                c_array = coordinate.to_array(c)
                m1 = c_array[0]
                m2 = c_array[1]
            
            # Ensure m1 >= m2
            if m2 > m1:
                m1, m2 = m2, m1
            
            mchirp = (m1 * m2)**(3/5) / (m1 + m2)**(1/5)
            q = m2 / m1
            
            return np.array([mchirp, q])
```

### Working with Bounds

Parameter spaces often have physical bounds:

```python
# Create a transform with mass bounds
transform = MassTransform(m1=(10.0, 50.0), m2=(10.0, 50.0))

# Check if a point is within bounds
point = {Mass1: 30.0, Mass2: 20.0}
if point in transform:
    print("Point is within bounds")

# Transform to chirp mass coordinates
chirp_coords = transform(point)
print(f"Chirp mass: {chirp_coords[0]:.2f}, q: {chirp_coords[1]:.2f}")
```

## Next Steps

Now that you understand the basics:

1. Learn about [Metrics](concepts.md#metrics) for measuring distances in parameter space
2. Explore [Template Bank Generation](concepts.md#template-banks) algorithms
3. Check out [Examples](../examples/index.md) for complete working code
4. Read the [API Reference](../api/coordinate.md) for detailed documentation

## Common Issues

### ImportError

If you get import errors, make sure you've installed Manifold in development mode:

```bash
pip install -e .
```

### Type Errors

When working with coordinates, ensure that coordinate types match:

```python
# This will raise an error
coords1 = coordinate.Coordinates(10.0, 20.0, coord_types=[Mass1, Mass2])
coords2 = coordinate.Coordinates(5.0, 10.0)  # No types specified
result = coords1 + coords2  # Error: incompatible types

# This works
coords2 = coordinate.Coordinates(5.0, 10.0, coord_types=[Mass1, Mass2])
result = coords1 + coords2  # OK
```

### Bounds Errors

When creating coordinate functions, ensure bounds are specified for valid coordinate types:

```python
# This will raise an error
transform = MassTransform(spin=(0.0, 1.0))  # 'spin' is not a valid coordinate

# This works
transform = MassTransform(m1=(10.0, 50.0), m2=(10.0, 50.0))
```