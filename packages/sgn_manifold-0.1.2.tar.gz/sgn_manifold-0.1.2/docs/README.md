# Manifold Documentation

This directory contains the documentation for the Manifold project, built using MkDocs.

## Building the Documentation

### Prerequisites

Install the documentation dependencies:

```bash
pip install -e ".[docs]"
```

### Build Documentation

To build the documentation:

```bash
mkdocs build
```

The built documentation will be in the `site/` directory.

### Serve Documentation Locally

To serve the documentation locally for development:

```bash
mkdocs serve
```

Then open http://localhost:8000 in your browser. The documentation will automatically rebuild when you make changes.

### Deploy Documentation

To deploy to GitLab Pages (requires appropriate permissions):

```bash
mkdocs gh-deploy --remote-name origin
```

## Documentation Structure

- `index.md` - Home page
- `user-guide/` - User guides and tutorials
- `api/` - API reference (auto-generated from docstrings)
- `examples/` - Example code and use cases
- `contributing.md` - Contribution guidelines
- `assets/` - Static assets (CSS, images)

## Writing Documentation

### API Documentation

API documentation is automatically generated from Python docstrings using mkdocstrings. To document a module:

1. Add docstrings to your Python code
2. Create a markdown file in `docs/api/`
3. Add the mkdocstrings directive:

```markdown
# Module Name

Module description...

## API Reference

::: manifold.module_name
```

### User Guides

User guides should be written in Markdown and placed in the appropriate subdirectory. Use clear examples and explanations.

### Style Guide

- Use clear, concise language
- Include code examples where appropriate
- Use proper Markdown formatting
- Add cross-references to related documentation
- Test all code examples

## Troubleshooting

If you encounter issues:

1. Ensure all dependencies are installed: `pip install -e ".[docs]"`
2. Check for syntax errors in markdown files
3. Verify Python docstrings are properly formatted
4. Look for errors in the mkdocs output

For more information, see the [MkDocs documentation](https://www.mkdocs.org/).