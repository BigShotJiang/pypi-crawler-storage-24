# Logo Attribution

The Manifold logos used in this documentation:

1. **Original Logo** (`manifold-logo.png`)
   - Source: https://gwsci.org/software/manifold.png
   - Used for: Home page banner, browser favicon
   - Format: PNG
   - Dimensions: 1000 x 460 pixels
   - Color depth: 8-bit/color RGBA

2. **Inverted Logo** (`manifold-logo-inverted.png`)
   - Source: User-provided inverted version
   - Used for: Site header/navigation bar
   - Format: PNG
   - Dimensions: 1000 x 460 pixels
   - Color depth: 8-bit/color RGBA
   - Purpose: Better visibility against the dark header background

The logos help establish the visual identity of the Manifold project in the documentation.