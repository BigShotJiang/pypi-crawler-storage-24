# Simple Template Bank Tutorial

This tutorial walks through creating a simple gravitational wave template bank using Manifold. We'll generate a bank for intermediate-mass black hole binaries, test its coverage, create visualizations, and generate an astrophysical mass model.

## Prerequisites

Before starting, ensure you have:
- Manifold installed with all dependencies
- The O4 PSD file (provided in the examples directory)

## Step 1: Set Up Your Working Directory

First, create a working directory and copy the necessary PSD file:

```bash
mkdir simple_bank_tutorial
cd simple_bank_tutorial
cp /path/to/manifold/examples/O4_projected_psds.xml.gz .
```

## Step 2: Create the Bank Configuration

Create a file called `simple_bank.yaml` with a small parameter space for faster execution:

```yaml
# Mass parameters (in solar masses)
m1: [20, 40]         # Primary mass range
m2: [20, 40]         # Secondary mass range
M: [40, 80]          # Total mass range
mc: [18, 80]         # Chirp mass range
q: [1.0, 10.0]       # Mass ratio range (m1/m2)

# Spin parameters (reduced range for simplicity)
chi: [-0.3, 0.3]     # Effective aligned spin parameter
ns-mass: [0, 3.0]    # Neutron star mass threshold
ns-s1z: [-0.05, 0.05]  # Neutron star spin limit

# Frequency parameters
freq: [10, 1024]     # Frequency range [flow, fhigh] in Hz
max-duration: 128    # Maximum signal duration in seconds

# PSD and instrument
psd-xml: O4_projected_psds.xml.gz
instrument: L1       # LIGO Livingston detector

# Bank generation parameters
mm: 0.03             # Maximum mismatch (3% = 97% minimum match)
reuse-g-mm: 0.10     # Mismatch threshold for reusing metric
max-num-templates: 1  # Maximum templates per rectangle
min-coord-vol: 0.001  # Minimum coordinate volume
min-depth: 7         # Minimum tree depth

# Waveform approximant
approximant: IMRPhenomD  # Fast approximant including merger

# Processing options
trim: true           # Remove templates outside constraints
verbose: true        # Show progress information
```

## Step 3: Generate the Initial Template Bank

First, generate the template bank:

```bash
manifold-cbc-bank \
  --yaml simple_bank.yaml \
  --output-h5 simple_bank_initial.h5
```

You should see output like:
```
reading 'O4_projected_psds.xml.gz' ...
100 <Rectangle [(1.45, 1.49), (1.41, 1.45), (0.15, 0.3)]> 1.0
Trimming templates outside constraints...
188 templates before
172 templates after
Saving bank to simple_bank_initial.h5...
Bank saved successfully with 172 templates
```

## Step 4: Check and Improve Coverage

Now check the bank's coverage and automatically improve it:

```bash
manifold-cbc-bank-check-coverage \
  --bank simple_bank_initial.h5 \
  --output-bank simple_bank.h5 \
  --target-match 0.97 \
  --neighbors 1000 \
  --n-samples 10 \
  --max-iterations 5 \
  --verbose
```

This will:
1. Check coverage of each template
2. Identify templates with poor coverage
3. Split those templates to improve coverage
4. Repeat until target match is achieved

Output:
```
======================================================================
TEMPLATE BANK COVERAGE CHECK
======================================================================

Loading bank from simple_bank_initial.h5...
Loaded 172 templates
Target minimum match: 0.970 (max mismatch: 0.030)
Iterative refinement enabled (max 5 iterations)

--- Iteration 1 ---
Checking 172 templates...
Checking coverage: 100%|████████████| 172/172 [00:00<00:00, 2878.23it/s]

Iteration 1 Results:
  Templates: 172
  Coverage failures: 89 (51.7%)
  Worst match: 0.868
  Mean match: 0.958

Splitting 89 poorly covered templates...
  Template 0: match=0.906, 3 splits → 8 rectangles
  Template 10: match=0.868, 3 splits → 8 rectangles
  ...
  Split 89 templates, added 269 new templates
  Total templates now: 441

--- Iteration 2 ---
Checking 441 templates...
Checking coverage: 100%|████████████| 441/441 [00:00<00:00, 2616.12it/s]

Iteration 2 Results:
  Templates: 441
  Coverage failures: 16 (3.6%)
  Worst match: 0.959
  Mean match: 0.989

Splitting 16 poorly covered templates...
  Split 16 templates, added 14 new templates
  Total templates now: 455

--- Iteration 3 ---
Checking 455 templates...
Checking coverage: 100%|████████████| 455/455 [00:00<00:00, 2826.98it/s]

Iteration 3 Results:
  Templates: 455
  Coverage failures: 0 (0.0%)
  Mean match: 0.991

✓ Coverage target achieved! All templates have match ≥ 0.970

======================================================================
FINAL COVERAGE ANALYSIS
======================================================================

Final Coverage Statistics:
  Initial templates: 172
  Final templates: 455
  Templates added: 283
  Iterations performed: 3
  
  Target minimum match: 0.970
  Worst coverage (min match): 0.971
  Best coverage (max match): 1.000
  Mean nearest neighbor match: 0.991
  Median nearest neighbor match: 0.993

======================================================================
SAVING IMPROVED BANK
======================================================================

Saving bank to simple_bank.h5...
✓ Bank saved successfully!
  Final templates: 455
  Net change: +283
```

## Step 5: Visualize the Template Bank

Create plots showing the distribution of templates in parameter space:

```bash
manifold-cbc-bank-plot \
  simple_bank.h5 \
  --output simple_bank_plot.png
```

This generates several plots:
- `simple_bank_plot_m1_m2.png` - Primary vs secondary mass
- `simple_bank_plot_mchirp_q.png` - Chirp mass vs mass ratio
- `simple_bank_plot_M_chi.png` - Total mass vs effective spin
- `simple_bank_plot_3d.png` - 3D view of the bank

To view the main plot:
```bash
# On macOS
open simple_bank_plot_m1_m2.png

# On Linux
xdg-open simple_bank_plot_m1_m2.png
```

## Step 6: Test the Bank Coverage

Generate test injections and check how well the bank covers the parameter space:

```bash
# Generate 1000 test injections
manifold-cbc-bank-test \
  --bank simple_bank.h5 \
  --output-h5 simple_bank_test.h5 \
  --num-injections 1000 \
  --verbose
```

Output will show:
```
Generating 1000 injections...
Testing bank coverage...
100%|████████████████| 1000/1000 [00:12<00:00, 83.33it/s]

Test Results:
  Total injections: 1000
  Mean match: 0.985
  Median match: 0.986
  90th percentile match: 0.993
  Worst match: 0.971
  Best match: 0.999
  
Saving results to simple_bank_test.h5...
```

### Generate Test Result Plots

Create visualizations of the test results:

```bash
manifold-cbc-bank-test-plot \
  --test simple_bank_test.h5
```

This creates several diagnostic plots:
- `test_match_vs_injm1.png` - Match vs primary mass
- `test_match_vs_injm2.png` - Match vs secondary mass  
- `test_match_vs_injmchirp.png` - Match vs chirp mass
- `test_match_vs_injM.png` - Match vs total mass
- `test_match_vs_injeta.png` - Match vs symmetric mass ratio
- `test_match_vs_injm2_vs_injm1.png` - 2D match distribution
- `test_mismatch_histogram.png` - Histogram of mismatches

View the mismatch histogram to see overall coverage:
```bash
open test_mismatch_histogram.png
```

## Step 7: Create a Mass Model

Generate an astrophysical mass model for the bank. First, create `mass_model.yaml`:

```yaml
# Input bank
bank: simple_bank.h5
output-h5: simple_mass_model.h5

# Mass model configuration
mass_model:
  model: power-law      # Astrophysical mass distribution
  index: -2.35          # Salpeter-like power law
  m_min: 5.0            # Minimum BH mass
  
  # Parameter space cuts (optional)
  cuts:
    m1: [20, 40]
    m2: [20, 40]
    x1: [-0.3, 0.3]      # Primary spin component
    x2: [-0.3, 0.3]      # Secondary spin component
```

Alternative models you can use:
- **Uniform**: Equal probability for all templates
- **Salpeter**: Classic stellar initial mass function
- **O3 Population**: Based on GWTC-3 observations

Generate the mass model:

```bash
manifold-cbc-bank-mass-model \
  --yaml mass_model.yaml \
  --verbose
```

Output:
```
Calculating mass model for 465 templates...
Processing templates 0 to 465
Saving mass model to simple_mass_model.h5...
Computing mass model coefficients...
✅ Mass model saved to simple_mass_model.h5
```

## Step 8: Visualize the Mass Model

Create plots showing the probability distribution across the bank:

```bash
manifold-cbc-bank-plot-mass-model \
  simple_mass_model.h5 \
  --snr 10.0
```

This generates:
- `snr-10.0_m1_m2.png` - 2D probability density in m1-m2 space
- `snr-10.0_mc_chi.png` - Chirp mass vs effective spin distribution

Note: For advanced features with SNR-dependent weighting, install the `strike` package:
```bash
pip install manifold[strike]
```

## Step 9: Export to XML (Optional)

If you need to use the bank with other gravitational wave software:

```bash
# Convert bank to XML format
manifold-cbc-bank-to-xml \
  simple_bank.h5 \
  --output simple_bank.xml.gz
```

## Complete Script

Here's a complete bash script that runs the entire workflow:

```bash
#!/bin/bash
# simple_bank_workflow.sh - Complete simple bank generation workflow

set -e  # Exit on error

echo "======================================"
echo "Simple Template Bank Generation"
echo "======================================"

# Step 1: Generate initial template bank
echo -e "\n1. Generating initial template bank..."
manifold-cbc-bank \
  --yaml simple_bank.yaml \
  --output-h5 simple_bank_initial.h5

# Step 2: Check and improve coverage
echo -e "\n2. Checking and improving coverage..."
manifold-cbc-bank-check-coverage \
  --bank simple_bank_initial.h5 \
  --output-bank simple_bank.h5 \
  --target-match 0.97 \
  --neighbors 1000 \
  --n-samples 10 \
  --max-iterations 5 \
  --verbose

# Step 3: Create bank plots
echo -e "\n3. Creating bank visualization..."
manifold-cbc-bank-plot \
  simple_bank.h5 \
  --output simple_bank_plot.png

# Step 4: Test bank coverage
echo -e "\n4. Testing bank coverage..."
manifold-cbc-bank-test \
  --bank simple_bank.h5 \
  --output-h5 simple_bank_test.h5 \
  --num-injections 1000 \
  --verbose

# Step 5: Plot test results
echo -e "\n5. Creating test result plots..."
manifold-cbc-bank-test-plot \
  --test simple_bank_test.h5

# Step 6: Generate mass model
echo -e "\n6. Generating mass model..."
manifold-cbc-bank-mass-model \
  --yaml mass_model.yaml \
  --verbose

# Step 7: Plot mass model
echo -e "\n7. Creating mass model visualization..."
manifold-cbc-bank-plot-mass-model \
  simple_mass_model.h5 \
  --snr 10.0

# Step 8: Export to XML
echo -e "\n8. Exporting to XML format..."
manifold-cbc-bank-to-xml \
  simple_bank.h5 \
  --output simple_bank.xml.gz

echo -e "\n======================================"
echo "Workflow Complete!"
echo "======================================"
echo "Generated files:"
echo "  - simple_bank.h5 (template bank)"
echo "  - simple_bank_plot.png (bank visualization)"
echo "  - simple_bank_test.h5 (test results)"
echo "  - test_*.png (test result plots)"
echo "  - simple_mass_model.h5 (mass model)"
echo "  - snr-10.0_*.png (mass model plots)"
echo "  - simple_bank.xml.gz (XML export)"
```

Make it executable and run:
```bash
chmod +x simple_bank_workflow.sh
./simple_bank_workflow.sh
```

## Expected Results

For the parameter space defined above (20-40 Msun, chi: [-0.3, 0.3], q: [1.0, 10.0]), you should expect:

- **Initial template count**: ~170-190 templates
- **Final template count**: ~450-500 templates (after 3 iterations)
- **Mean match**: ~99.1% after refinement
- **Worst match**: >97% (successfully meets target)
- **Generation time**: ~1-2 minutes on a modern laptop
- **File sizes**:
  - Bank HDF5: ~2-3 MB
  - Test results: ~500 KB
  - Mass model: ~1 MB
  - XML export: ~5-10 MB (compressed)

## Understanding the Outputs

### Bank Plot
The m1-m2 plot shows template placement:
- Each point represents a template
- Density indicates coverage requirements
- Higher density near equal mass (q=1) line
- Sparser coverage at extreme mass ratios

### Test Mismatch Histogram
Shows distribution of mismatches:
- Peak should be near 0.01-0.02 (98-99% match)
- No values should exceed 0.03 (97% match)
- Sharp cutoff at maximum mismatch confirms coverage

### Mass Model Plot
Shows probability density:
- Brighter regions = higher probability
- Power law favors lower masses
- Useful for weighted template selection in searches

## Troubleshooting

### "ValueError: nan metric"
- **Cause**: Metric calculation failed at extreme parameters
- **Solution**: Tighten mass ranges or reduce spin range

### Too many templates
- **Cause**: Parameter space too large or mismatch too tight
- **Solution**: Increase `mm` to 0.05 or reduce mass range

### Coverage failures persist
- **Cause**: Difficult region in parameter space
- **Solution**: Increase `coverage-max-iterations` or adjust `min-coord-vol`

### Plots not showing
- **Cause**: Display issues
- **Solution**: Save plots and view with image viewer, or use `--format pdf` for vector graphics

## Next Steps

Now that you have a simple bank, you can:

1. **Adjust parameters**: Try different mass ranges or spin distributions
2. **Compare approximants**: Test TaylorF2 vs IMRPhenomD vs SEOBNRv4
3. **Optimize for searches**: Tune mismatch for your computational budget
4. **Scale up**: Use parallel processing for larger parameter spaces
5. **Integrate with pipelines**: Use the XML export with PyCBC or GstLAL

## Summary

This tutorial demonstrated:
- ✅ Creating a template bank with automatic coverage checking
- ✅ Visualizing template distribution
- ✅ Testing bank coverage with injections
- ✅ Generating astrophysical mass models
- ✅ Creating publication-ready plots
- ✅ Exporting for use with other tools

The simple bank is suitable for testing and development. For production searches, expand the parameter space and use the parallel processing workflow described in the advanced tutorial.