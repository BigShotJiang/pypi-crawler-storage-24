# Creating a Compact Binary Template Bank with manifold-cbc-bank

This tutorial demonstrates how to use the `manifold-cbc-bank` command-line tool to create high-quality template banks for gravitational wave searches. We'll walk through the complete workflow from initial seed bank generation through parallel refinement, coverage checking, and final testing.

## Overview

The Manifold template bank generation process consists of several key steps:

1. **Seed Bank Generation** - Create a coarse initial bank
2. **Seed Grouping** - Divide the seed bank for parallel processing
3. **Parallel Refinement** - Refine each seed group with fine resolution
4. **Bank Merging** - Combine refined banks
5. **Coverage Checking** - Verify and improve bank coverage (parallel)
6. **Final Merging** - Combine coverage-improved banks
7. **Testing** - Validate bank performance with injections
8. **Export** - Convert to XML format for search pipelines (optional)

## Prerequisites

Before starting, ensure you have:

- Manifold installed with command-line tools available
- A Power Spectral Density (PSD) file in XML format
- Understanding of CBC parameter space (masses, spins, etc.)

## Tutorial Configuration

This tutorial uses a smaller parameter space for faster execution (~30-60 minutes on a modern machine). For production banks, you would use larger ranges.

## Step 1: Prepare Your Environment

### Get a PSD File

First, obtain a PSD file for your detector. You can use the example O4 PSD from the manifold repository:

```bash
# Create working directory
mkdir bank_tutorial
cd bank_tutorial

# Copy PSD file
cp ../examples/O4_projected_psds.xml.gz .
```

### Create the Bank Configuration YAML

Create a file called `bank.yaml` with the following contents:

```yaml
# Mass parameters (in solar masses)
m1: [10, 100]        # Primary mass range
m2: [10, 100]        # Secondary mass range
M: [20, 200]         # Total mass range
mc: [8, 200]         # Chirp mass range
q: [1.0, 10.0]       # Mass ratio range (m1/m2)

# Spin parameters
chi: [-0.5, 0.5]     # Effective aligned spin parameter
ns-mass: [0, 3.0]    # Neutron star mass threshold
ns-s1z: [-0.05, 0.05]  # Neutron star spin limit

# Frequency parameters
freq: [10, 512]      # Frequency range [flow, fhigh] in Hz
max-duration: 128    # Maximum signal duration in seconds

# PSD and instrument
psd-xml: O4_projected_psds.xml.gz
instrument: L1       # Options: L1, H1, V1

# Bank generation parameters
mm: 0.03             # Maximum mismatch (3% mismatch = 97% minimum match)
reuse-g-mm: 0.10     # Mismatch for reusing metric calculations
min-coord-vol: 1000  # Minimum coordinate volume for seed bank
min-depth: 7         # Minimum tree depth for placement

# Waveform approximant
approximant: IMRPhenomD  # Options: TaylorF2, IMRPhenomD, SEOBNRv4, etc.

# Processing options
trim: true           # Trim templates outside constraints
verbose: true        # Print progress information
```

## Step 2: Generate the Initial Seed Bank

Generate a coarse seed bank with ~1000 templates. This creates large rectangular regions that will be refined later:

```bash
manifold-cbc-bank \
  --yaml bank.yaml \
  --output-h5 SEED.h5 \
  --max-num-templates 1000 \
  --min-coord-vol 1000
```

You should see output showing the placement of templates, ending with something like:

```
reading 'O4_projected_psds.xml.gz' ...
100 <Rectangle [(1.0, 1.05), (1.0, 1.05), (-0.5, -0.4)]> 1.0
200 <Rectangle [(1.1, 1.15), (1.05, 1.1), (-0.3, -0.2)]> 1.0
...
900 <Rectangle [(1.95, 2.0), (1.9, 1.95), (0.4, 0.5)]> 1.0
1000 <Rectangle [(1.85, 1.9), (1.85, 1.9), (0.3, 0.4)]> 1.0
Trimming templates outside constraints...
1024 templates before
987 templates after
Saving bank to SEED.h5...
Bank saved successfully with 987 templates
```

## Step 3: Divide the Seed Bank into Groups

Split the seed bank into groups for parallel refinement. Each group will be refined independently:

```bash
manifold-cbc-bank-group --bank SEED.h5 --num-groups 10
```

This creates:
- `H1L1V1-00000_MANIFOLD_SEED-0-2000000000.h5` through `H1L1V1-00009_MANIFOLD_SEED-0-2000000000.h5` (10 seed groups)
- `H1L1V1-MANIFOLD_SEED_MANIFEST-0-2000000000.json` (manifest file)

Each seed group contains a subset of the seed bank rectangles.

## Step 4: Refine Each Seed Group (Parallel)

For each seed group, generate a refined bank with much smaller rectangles. **This step can be parallelized across multiple cores or machines:**

```bash
# Process all 10 groups (can be run in parallel on different machines/cores)
for i in $(seq -f "%05g" 0 9); do
    manifold-cbc-bank \
        --yaml bank.yaml \
        --seedbank H1L1V1-${i}_MANIFOLD_SEED-0-2000000000.h5 \
        --output-h5 H1L1V1-${i}_MANIFOLD-0-2000000000.h5 \
        --max-num-templates 1 \
        --min-coord-vol 0.0001
done
```

**Parallel execution options:**

```bash
# Using GNU parallel (faster)
parallel -j 10 "manifold-cbc-bank --yaml bank.yaml \
    --seedbank H1L1V1-{}_MANIFOLD_SEED-0-2000000000.h5 \
    --output-h5 H1L1V1-{}_MANIFOLD-0-2000000000.h5 \
    --max-num-templates 1 --min-coord-vol 0.0001" ::: $(seq -f "%05g" 0 9)

# Using background jobs (bash)
for i in $(seq -f "%05g" 0 9); do
    manifold-cbc-bank --yaml bank.yaml \
        --seedbank H1L1V1-${i}_MANIFOLD_SEED-0-2000000000.h5 \
        --output-h5 H1L1V1-${i}_MANIFOLD-0-2000000000.h5 \
        --max-num-templates 1 --min-coord-vol 0.0001 &
done
wait  # Wait for all jobs to complete
```

Each refined bank will have many more templates (~5000-7000 each) covering its portion of the parameter space more finely.

## Step 5: Combine the Refined Banks

Merge all refined banks into a single bank:

```bash
manifold-cbc-bank-add --output-h5 H1L1V1-MANIFOLD_ADD-0-2000000000.h5 \
    H1L1V1-00000_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00001_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00002_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00003_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00004_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00005_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00006_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00007_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00008_MANIFOLD-0-2000000000.h5 \
    H1L1V1-00009_MANIFOLD-0-2000000000.h5
```

This creates a single bank with all templates from all refined groups.

## Step 6: Check and Improve Coverage (Parallel)

Check the bank's coverage and automatically split poorly covered templates. **This step can also be parallelized** by dividing the bank into intervals:

```bash
# Process 10 intervals in parallel (each checks 1/10th of the bank)
for i in $(seq 0 9); do
    manifold-cbc-bank-check-coverage \
        --bank H1L1V1-MANIFOLD_ADD-0-2000000000.h5 \
        --interval-index $i \
        --num-intervals 10 \
        --neighbors 10000 \
        --target-match 0.965 \
        --output-bank H1L1V1-MANIFOLD_COVERAGE_$(printf "%02d" $i)-0-2000000000.h5 \
        --verbose
done
```

**Key parameters:**
- `--interval-index`: Which interval to process (0-based)
- `--num-intervals`: Total number of intervals
- `--neighbors`: Number of neighbors to use as buffer (should be large, e.g., 10000)
- `--target-match`: Minimum match threshold (0.965 = 96.5% match)

**Parallel execution:**

```bash
# Using GNU parallel
parallel -j 10 "manifold-cbc-bank-check-coverage \
    --bank H1L1V1-MANIFOLD_ADD-0-2000000000.h5 \
    --interval-index {} --num-intervals 10 --neighbors 10000 \
    --target-match 0.965 \
    --output-bank H1L1V1-MANIFOLD_COVERAGE_{0>2}-0-2000000000.h5 \
    --verbose" ::: {0..9}
```

Each interval will check its portion of the bank and split templates that don't meet the target match. You'll see output like:

```
======================================================================
TEMPLATE BANK COVERAGE CHECK - INTERVAL 1/10
======================================================================

Loading bank from H1L1V1-MANIFOLD_ADD-0-2000000000.h5...
Processing interval 1 of 10
Using 10000 neighbors as buffer on each side
  Interval range (global indices): [0, 5500)
  Templates in interval: 5500
  Total loaded with neighbors: 15500

--- Iteration 1 ---
Checking 15500 templates...
Checking coverage: 100%|██████████| 5500/5500 [02:15<00:00, 40.56it/s]

Iteration 1 Results:
  Templates: 15500
  Coverage failures: 425 (7.7%)
  Worst match: 0.912345
  Mean match: 0.978654

Splitting 425 poorly covered templates...
  Template 45: match=0.9123, 2 splits → 4 rectangles
  Template 67: match=0.9345, 1 splits → 2 rectangles
  ...
  Split 425 templates, added 687 new templates
  Total templates now: 16187

======================================================================
SAVING IMPROVED BANK
======================================================================

Saving interval bank to H1L1V1-MANIFOLD_COVERAGE_00-0-2000000000.h5...
  Saving only interval templates (6187 templates)
✓ Interval bank saved successfully!
  Templates in interval: 6187
```

**Important notes on parallel coverage checking:**
- Use a large `--neighbors` value (e.g., 10000) to ensure accurate coverage checking
- Each interval uses templates from neighboring intervals to check coverage at boundaries
- Only the interval's own templates (not neighbors) are saved in the output file
- Small differences in total template count between single and parallel runs are expected and acceptable

## Step 7: Combine Coverage-Improved Banks

Merge all coverage-improved intervals into the final bank:

```bash
manifold-cbc-bank-add --output-h5 H1L1V1-MANIFOLD-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_00-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_01-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_02-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_03-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_04-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_05-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_06-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_07-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_08-0-2000000000.h5 \
    H1L1V1-MANIFOLD_COVERAGE_09-0-2000000000.h5
```

**This is your final template bank!** It should have ~60,000-70,000 templates for this parameter space.

## Step 8: Test the Bank (Parallel)

Generate test injections to verify bank performance. This can also be parallelized:

```bash
# Generate 10 test sets in parallel (100 injections each)
for i in $(seq -f "%02g" 1 10); do
    manifold-cbc-bank-test \
        --bank H1L1V1-MANIFOLD-0-2000000000.h5 \
        --output-h5 ${i}_test.h5 \
        --num-injections 100 \
        --verbose
done
```

**Parallel execution:**

```bash
# Using GNU parallel
parallel -j 10 "manifold-cbc-bank-test \
    --bank H1L1V1-MANIFOLD-0-2000000000.h5 \
    --output-h5 {0>2}_test.h5 \
    --num-injections 100 --verbose" ::: {1..10}
```

Each test generates random injections across the parameter space and finds the best-matching template.

## Step 9: Combine and Plot Test Results

Combine all test results:

```bash
manifold-cbc-bank-test-add --output-h5 test.h5 \
    01_test.h5 02_test.h5 03_test.h5 04_test.h5 05_test.h5 \
    06_test.h5 07_test.h5 08_test.h5 09_test.h5 10_test.h5
```

Generate diagnostic plots:

```bash
manifold-cbc-bank-test-plot --test test.h5
```

This creates several plots showing:
- `test_match_vs_injm1.png` - Match vs primary mass
- `test_match_vs_injm2.png` - Match vs secondary mass
- `test_match_vs_injmchirp.png` - Match vs chirp mass
- `test_match_vs_injM.png` - Match vs total mass
- `test_match_vs_injeta.png` - Match vs symmetric mass ratio
- `test_match_vs_inj_mass_ratio.png` - Match vs mass ratio
- `test_match_vs_injm2_vs_injm1.png` - 2D match distribution
- `test_mismatch_histogram.png` - Histogram of mismatches

The plots should show:
- Most injections have match > 96.5%
- Worst matches are still > 95%
- Uniform coverage across the parameter space

## Automation with Makefile

You can automate the entire workflow using a Makefile. Create a file called `Makefile`:

```makefile
all: test

# Step 2: Generate seed bank
SEED.h5: bank.yaml O4_projected_psds.xml.gz
	manifold-cbc-bank --yaml bank.yaml --output-h5 $@ \
		--max-num-templates 1000 --min-coord-vol 1000

# Step 3: Divide into groups
H1L1V1-MANIFOLD_SEED_MANIFEST-0-2000000000.json: SEED.h5
	manifold-cbc-bank-group --bank SEED.h5 --num-groups 10

# Step 4: Refine each group (pattern rule)
H1L1V1-%_MANIFOLD-0-2000000000.h5: H1L1V1-MANIFOLD_SEED_MANIFEST-0-2000000000.json
	manifold-cbc-bank --yaml bank.yaml --output-h5 $@ \
		--seedbank H1L1V1-$*_MANIFOLD_SEED-0-2000000000.h5 \
		--max-num-templates 1 --min-coord-vol 0.0001

# Step 5: Combine refined banks
H1L1V1-MANIFOLD_ADD-0-2000000000.h5: \
		H1L1V1-00000_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00001_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00002_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00003_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00004_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00005_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00006_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00007_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00008_MANIFOLD-0-2000000000.h5 \
		H1L1V1-00009_MANIFOLD-0-2000000000.h5
	manifold-cbc-bank-add --output-h5 $@ $^

# Step 6: Check coverage for each interval (pattern rule)
H1L1V1-MANIFOLD_COVERAGE_%-0-2000000000.h5: H1L1V1-MANIFOLD_ADD-0-2000000000.h5
	manifold-cbc-bank-check-coverage \
		--bank $< \
		--interval-index $* \
		--num-intervals 10 \
		--neighbors 10000 \
		--target-match 0.965 \
		--output-bank $@ \
		--verbose

# Step 7: Combine coverage-improved banks
H1L1V1-MANIFOLD-0-2000000000.h5: \
		H1L1V1-MANIFOLD_COVERAGE_00-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_01-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_02-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_03-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_04-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_05-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_06-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_07-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_08-0-2000000000.h5 \
		H1L1V1-MANIFOLD_COVERAGE_09-0-2000000000.h5
	manifold-cbc-bank-add --output-h5 $@ $^

# Step 8: Generate test injections (pattern rule)
%_test.h5: H1L1V1-MANIFOLD-0-2000000000.h5
	manifold-cbc-bank-test --bank $< --output-h5 $@ \
		--num-injections 100 --verbose

# Step 9: Combine test results
test.h5: 01_test.h5 02_test.h5 03_test.h5 04_test.h5 05_test.h5 \
         06_test.h5 07_test.h5 08_test.h5 09_test.h5 10_test.h5
	manifold-cbc-bank-test-add --output-h5 $@ $^

# Step 9: Plot test results
test: test.h5
	manifold-cbc-bank-test-plot --test $<

clean:
	rm -rf *.h5 *.png *.json

.PHONY: all test clean
```

Then simply run:

```bash
make -j 10  # Run with up to 10 parallel jobs
```

Make will automatically:
- Run all steps in the correct order
- Parallelize where possible (Steps 4, 6, and 8)
- Skip steps that are already complete
- Resume from failures

## Optional Steps for Online Searches

If you need to prepare the bank for online analysis:

### Add Constraint Sets and Template IDs

Create `constrain.yaml`:

```yaml
# Search region constraints (typically tighter than generation bounds)
m1: [12, 98]
m2: [12, 98]
mc: [10, 90]
q: [1.0, 8.0]
M: [24, 196]
chi: [-0.4, 0.4]
ns-mass: [0, 3.0]
ns-s1z: [-0.04, 0.04]

# Options
assign-ids: true    # Assign unique template IDs
trim: true          # Remove templates outside constraints
```

Run the constraint command:

```bash
manifold-cbc-bank-constrain \
    --bank H1L1V1-MANIFOLD-0-2000000000.h5 \
    --output-h5 H1L1V1-MANIFOLD_CONSTRAINED-0-2000000000.h5 \
    --yaml constrain.yaml
```

### Generate Mass Model

Create `mass_model.yaml`:

```yaml
mass_model:
    model: salpeter
    m_min: 0.8
```

Run the mass model generation:

```bash
manifold-cbc-bank-mass-model \
    --bank H1L1V1-MANIFOLD_CONSTRAINED-0-2000000000.h5 \
    --output-h5 H1L1V1-MANIFOLD_MASS_MODEL-0-2000000000.h5 \
    --yaml mass_model.yaml
```

### Convert to XML

Convert the bank to XML format for use with other tools:

```bash
manifold-cbc-bank-to-xml \
    H1L1V1-MANIFOLD_CONSTRAINED-0-2000000000.h5 \
    --output-xml H1L1V1-MANIFOLD-0-2000000000.xml.gz
```

## Performance Notes

**Parallel Processing:**
- Steps 4, 6, and 8 can be parallelized across multiple cores or machines
- For Step 6 (coverage checking), use a large `--neighbors` value (e.g., 10000) to ensure accurate results
- Small differences in template counts between single and parallel runs are expected and acceptable (typically <5% difference)
- The parallel approach can reduce total wall time by ~10x on a 10-core machine

**Parameter Space Size:**
- Smaller mass ranges and spin ranges = faster execution
- The tutorial configuration should complete in ~30-60 minutes on a modern machine
- For production banks, use larger ranges (e.g., m1/m2: [3, 200], chi: [-0.95, 0.95])

**Memory Usage:**
- Each refined bank group uses ~1-2 GB of memory
- Coverage checking uses ~2-4 GB per interval
- Testing uses ~500 MB per test set

**Template Counts:**
- Tutorial configuration: ~60,000-70,000 templates
- Production BBH search (m1/m2: [3,200], chi: [-0.95,0.95]): ~500,000-1,000,000 templates
- BNS search (m1/m2: [1,3], chi small): ~10,000-50,000 templates

## Troubleshooting

### Common Issues

1. **"ValueError: nan metric"**
   - Cause: Metric calculation failed at extreme parameters
   - Solution: Tighten parameter constraints or use different `jump_method`

2. **Too many templates**
   - Cause: Mismatch tolerance too tight or parameter space too large
   - Solution: Increase `mm` parameter or reduce parameter ranges

3. **Poor coverage in tests**
   - Cause: Insufficient templates in certain regions
   - Solution: Check coverage step output, may need to decrease target match or run more iterations

4. **Memory issues**
   - Cause: Too many templates being generated or loaded
   - Solution: Increase number of intervals in parallel processing

5. **Coverage interval results don't match single run**
   - This is expected! Small differences (5-10%) are normal due to boundary effects
   - Use larger `--neighbors` value (e.g., 10000) to minimize differences

## Best Practices

1. **Start Small**: Test your configuration with small parameter space first
2. **Validate Coverage**: Always test your bank with injections before using in production
3. **Use Parallel Processing**: For large banks, parallel processing is essential
4. **Save Intermediate Files**: Keep all HDF5 files for reproducibility
5. **Monitor Template Count**: Typical online searches use 10,000-1,000,000 templates
6. **Check Plots**: Ensure uniform coverage across all parameter dimensions

## Next Steps

- Explore different mass models for specific astrophysical populations
- Optimize bank generation for your specific search
- Integrate with search pipelines (PyCBC, GstLAL, etc.)
- Implement custom coordinate systems for specialized searches

## References

- [Manifold Paper](https://arxiv.org/abs/XXXX.XXXXX) - Algorithm details
- [LALSuite Documentation](https://lscsoft.docs.ligo.org/lalsuite/) - Waveform approximants
- [GstLAL Documentation](https://lscsoft.docs.ligo.org/gstlal/) - Search pipeline integration