# SNR Optimizer Tutorial

This tutorial demonstrates how to use the manifold SNR optimizer to refine gravitational wave event parameters using real LIGO/Virgo data from GWOSC (Gravitational Wave Open Science Center).

## Overview

The SNR optimizer performs a coherent multi-detector analysis to refine the sky position, masses, and spins of gravitational wave candidates. It takes a coarse trigger from a matched-filter search and performs a detailed parameter estimation over nearby templates.

**What you'll learn:**

- How to download strain data from GWOSC
- How to create a template bank for SNR optimization
- How to set up and run the offline SNR optimizer
- How to interpret the optimized results

**Time required:** ~30 minutes

## Prerequisites

Before starting this tutorial, ensure you have:

1. **Manifold installed** with SGN support:
   ```bash
   pip install -e ".[sgn]"
   ```

2. **Required dependencies:**
   - `lalsuite` - LAL/LALSimulation for waveform generation
   - `sgn`, `sgn-ts`, `sgn-ligo` - SGN framework for streaming pipelines
   - `strike` - Statistical framework for likelihood calculations

3. **Python 3.10+** (Python 3.11 recommended)

4. **~100 MB disk space** for test data

## Step 1: Set Up Working Directory

First, create a working directory for this tutorial:

```bash
mkdir -p manifold_snr_tutorial
cd manifold_snr_tutorial
```

## Step 2: Download Frame Data from GWOSC

We'll use data from LIGO's fourth observing run (O4) containing a real gravitational wave event.

### 2.1 Find Available Data

Visit [GWOSC](https://gwosc.org) and navigate to the data release section. For this tutorial, we'll use O4 data:

- **GPS Time:** 1420878141 (approximate event time)
- **Detectors:** H1 (LIGO Hanford), L1 (LIGO Livingston)
- **Sample Rate:** 4096 Hz

### 2.2 Download Frame Files

Download the GWOSC frame files covering the event time:

```bash
# Create frames directory
mkdir -p frames

# Download H1 frame file (4096 seconds starting at GPS 1420877824)
wget -O frames/H-H1_GWOSC_O4b3Disc_4KHZ_R1-1420877824-4096.gwf \
  "https://gwosc.org/archive/data/O4/1420877824/H-H1_GWOSC_O4b3Disc_4KHZ_R1-1420877824-4096.gwf"

# Download L1 frame file
wget -O frames/L-L1_GWOSC_O4b3Disc_4KHZ_R1-1420877824-4096.gwf \
  "https://gwosc.org/archive/data/O4/1420877824/L-L1_GWOSC_O4b3Disc_4KHZ_R1-1420877824-4096.gwf"
```

**Note:** If the above URLs don't work, visit [gwosc.org/data](https://gwosc.org/data) and search for O4 data around GPS time 1420878141.

### 2.3 Verify Downloads

Check that the files downloaded correctly:

```bash
ls -lh frames/*.gwf
```

You should see two files, each ~39 MB.

## Step 3: Create a Template Bank

The SNR optimizer needs a template bank covering the parameter space around the event (20-40 solar mass BBH).

**Please complete the [Simple Bank Tutorial](simple-bank-tutorial.md) to generate a template bank** covering this parameter space. The tutorial creates `simple_bank.h5` with ~455 templates, which is exactly what we need for this SNR optimizer tutorial.

The Simple Bank Tutorial covers:
- Parameter space configuration
- PSD files and sensitivity
- Waveform approximants
- Bank visualization and testing

Once you have completed the Simple Bank Tutorial, you can either:
- Use the `simple_bank.h5` file from that tutorial directly
- Copy it to your `manifold_snr_tutorial` directory: `cp ../simple_bank_tutorial/simple_bank.h5 .`

## Step 4: Set Up Test Data

### 4.1 Create Frame Cache File

The SNR optimizer needs a frame cache file listing available data:

```bash
cat > frames.cache << EOF
H H1_GWOSC_O4b3Disc_4KHZ_R1 1420877824 4096 file://localhost$(pwd)/frames/H-H1_GWOSC_O4b3Disc_4KHZ_R1-1420877824-4096.gwf
L L1_GWOSC_O4b3Disc_4KHZ_R1 1420877824 4096 file://localhost$(pwd)/frames/L-L1_GWOSC_O4b3Disc_4KHZ_R1-1420877824-4096.gwf
EOF
```

This creates a cache file pointing to the frame files in the local `frames` directory using absolute paths.

### 4.2 Create Test Coinc Event

For offline testing, we need a coinc event XML file. You can either:

**Option A:** Use an existing coinc event from a real search

**Option B:** Create a synthetic event for testing:

```python
import lal
from ligo.lw import ligolw, lsctables, utils as ligolw_utils

# Create XML document
xmldoc = ligolw.Document()
xmldoc.appendChild(ligolw.LIGO_LW())

# Create required tables
process_table = lsctables.New(lsctables.ProcessTable)
xmldoc.childNodes[0].appendChild(process_table)

sngl_table = lsctables.New(lsctables.SnglInspiralTable)
xmldoc.childNodes[0].appendChild(sngl_table)

coinc_inspiral_table = lsctables.New(lsctables.CoincInspiralTable)
xmldoc.childNodes[0].appendChild(coinc_inspiral_table)

coinc_table = lsctables.New(lsctables.CoincTable)
xmldoc.childNodes[0].appendChild(coinc_table)

# Add test event: 36-36 solar mass binary at GPS 1420878141
# These parameters are based on a real GWOSC event with H1 and L1

# Helper function to create a single-IFO trigger with all required fields
def create_sngl_inspiral(ifo, end_time, end_time_ns, snr, chisq):
    sngl = sngl_table.RowType()
    # IFO and timing
    sngl.ifo = ifo
    sngl.end = lal.LIGOTimeGPS(end_time, end_time_ns)
    sngl.end_time = end_time
    sngl.end_time_ns = end_time_ns

    # Physical parameters
    sngl.mass1 = 36.05
    sngl.mass2 = 36.05
    sngl.mchirp = 31.38
    sngl.mtotal = 72.1
    sngl.eta = 0.25  # Symmetric mass ratio

    # Spin components (aligned spins, so x and y are zero)
    sngl.spin1x = 0.0
    sngl.spin1y = 0.0
    sngl.spin1z = -0.0155
    sngl.spin2x = 0.0
    sngl.spin2y = 0.0
    sngl.spin2z = -0.0155

    # Match statistics
    sngl.snr = snr
    sngl.chisq = chisq
    sngl.chisq_dof = 1

    # Template IDs (Gamma0 through Gamma9)
    sngl.Gamma0 = 0.0
    sngl.Gamma1 = 0.0
    sngl.Gamma2 = 0.0
    sngl.Gamma3 = 0.0
    sngl.Gamma4 = 0.0
    sngl.Gamma5 = 0.0
    sngl.Gamma6 = 0.0
    sngl.Gamma7 = 0.0
    sngl.Gamma8 = 0.0
    sngl.Gamma9 = 0.0

    # Set other required fields to defaults
    sngl.search = 0
    sngl.channel = "GWOSC-4KHZ_R1_STRAIN"
    sngl.process_id = 0
    sngl.event_id = sngl_table.get_next_id()
    sngl.end_time_gmst = 0.0
    sngl.impulse_time = 0
    sngl.impulse_time_ns = 0
    sngl.template_duration = 0.0
    sngl.event_duration = 0.0
    sngl.amplitude = 0.0
    sngl.eff_distance = 0.0
    sngl.coa_phase = 0.0
    sngl.kappa = 0.0
    sngl.chi = 0.0
    sngl.tau0 = 0.0
    sngl.tau2 = 0.0
    sngl.tau3 = 0.0
    sngl.tau4 = 0.0
    sngl.tau5 = 0.0
    sngl.ttotal = 0.0
    sngl.psi0 = 0.0
    sngl.psi3 = 0.0
    sngl.alpha = 0.0
    sngl.alpha1 = 0.0
    sngl.alpha2 = 0.0
    sngl.alpha3 = 0.0
    sngl.alpha4 = 0.0
    sngl.alpha5 = 0.0
    sngl.alpha6 = 0.0
    sngl.beta = 0.0
    sngl.f_final = 0.0
    sngl.bank_chisq = 0.0
    sngl.bank_chisq_dof = 0
    sngl.cont_chisq = 0.0
    sngl.cont_chisq_dof = 0
    sngl.sigmasq = 0.0
    sngl.rsqveto_duration = 0.0

    return sngl

# Create H1 trigger
sngl_h1 = create_sngl_inspiral("H1", 1420878141, 223632812, 52.5, 0.96)
sngl_table.append(sngl_h1)

# Create L1 trigger (slightly different arrival time due to light travel time)
sngl_l1 = create_sngl_inspiral("L1", 1420878141, 221191406, 60.25, 0.98)
sngl_table.append(sngl_l1)

# Coinc inspiral row (use H1 time as reference)
coinc_insp = coinc_inspiral_table.RowType()
coinc_insp.coinc_event_id = 0
coinc_insp.ifos = "H1,L1"
coinc_insp.end = lal.LIGOTimeGPS(1420878141, 223632812)
coinc_insp.end_time = 1420878141
coinc_insp.end_time_ns = 223632812
coinc_insp.mass = 72.1  # Total mass
coinc_insp.mchirp = 31.38  # Chirp mass for 36-36 Msun binary
coinc_insp.minimum_duration = 0.0
coinc_insp.snr = 79.9  # Combined SNR from H1 and L1
coinc_insp.false_alarm_rate = 8.43e-54
coinc_insp.combined_far = 7.63e-61
coinc_inspiral_table.append(coinc_insp)

# Coinc row
coinc = coinc_table.RowType()
coinc.coinc_event_id = 0
coinc.process_id = 0
coinc.coinc_def_id = 0
coinc.time_slide_id = 0
coinc.instruments = "H1,L1"
coinc.nevents = 2
coinc.likelihood = 128.8
coinc_table.append(coinc)

# Save
ligolw_utils.write_filename(xmldoc, "test_event.xml")
print("Created test_event.xml")
```

Save this as `create_event.py` and run:

```bash
python3 create_event.py
```

## Step 5: Run the SNR Optimizer

Now run the SNR optimizer with the frame data:

```bash
manifold-cbc-bank-snr-optimizer-online \
    --data-source frames \
    --frame-cache frames.cache \
    --channel-name H1=GWOSC-4KHZ_R1_STRAIN \
    --channel-name L1=GWOSC-4KHZ_R1_STRAIN \
    --gps-start-time 1420877824 \
    --gps-end-time 1420878160 \
    --seed-bank simple_bank.h5 \
    --reference-psd O4_projected_psds.xml.gz \
    --whiten-sample-rate 2048 \
    --psd-fft-length 8 \
    --flow 10.0 \
    --min-mismatch 0.03 \
    --min-instruments 2 \
    --output-xml-file optimized_event.xml \
    test_event.xml
```

The pipeline will:

1. Load the template bank (455 templates)
2. Load the PSD and event
3. Set up the SGN pipeline with frame sources
4. Read and whiten strain data
5. Find templates near the event parameters
6. Perform SNR optimization over nearby templates
7. Write the optimized event to `optimized_event.xml`

**Runtime:** ~1-2 minutes depending on your system.

## Step 6: Examine Results

### 6.1 Inspect Output File

Create a file `examine_results.py` to inspect the optimized event:

```python
from ligo.lw import ligolw, lsctables, utils as ligolw_utils
from manifold.snr_optimizer_sink import LIGOLWContentHandler

# Load optimized event
xmldoc = ligolw_utils.load_filename(
    "optimized_event.xml",
    contenthandler=LIGOLWContentHandler
)

# Get tables
sngl_table = lsctables.SnglInspiralTable.get_table(xmldoc)
coinc_table = lsctables.CoincInspiralTable.get_table(xmldoc)

print("Optimized Event Parameters:")
print("=" * 50)

# Print per-detector results
for sngl in sngl_table:
    print(f"\n{sngl.ifo} Detector:")
    print(f"  Mass 1: {sngl.mass1:.2f} Msun")
    print(f"  Mass 2: {sngl.mass2:.2f} Msun")
    print(f"  Spin 1z: {sngl.spin1z:.4f}")
    print(f"  Spin 2z: {sngl.spin2z:.4f}")
    print(f"  SNR: {sngl.snr:.2f}")
    print(f"  Chi-squared: {sngl.chisq:.2f}")
    print(f"  GPS time: {sngl.end_time}.{sngl.end_time_ns}")

# Print combined coincident results
coinc = coinc_table[0]
print(f"\nCombined Coincident Result:")
print(f"  Detectors: {coinc.ifos}")
print(f"  Total mass: {coinc.mass:.2f} Msun")
print(f"  Chirp mass: {coinc.mchirp:.2f} Msun")
print(f"  Combined SNR: {coinc.snr:.2f}")
print(f"  GPS time: {coinc.end_time}.{coinc.end_time_ns}")
print(f"  False alarm rate: {coinc.false_alarm_rate:.2e} Hz")
print(f"  Combined FAR: {coinc.combined_far:.2e} Hz")
```

Run the script:

```bash
python3 examine_results.py
```

This will display the optimized parameters for each detector (H1 and L1) as well as the combined coincident result.

### 6.2 Compare with Input

Compare the optimized parameters with the initial trigger to see the improvement.

## Troubleshooting

### Import Errors

If you see `ImportError: No module named 'sgn'`:

```bash
pip install -e ".[sgn]"
```

Or install SGN packages individually:

```bash
pip install -e /path/to/sgn
pip install -e /path/to/sgn-ts
pip install -e /path/to/sgn-ligo
pip install -e /path/to/strike
```

### Frame File Not Found

Ensure frame cache file uses absolute paths:

```bash
# Use $(pwd) for current directory or full absolute path
file://localhost$(pwd)/frames/...
# NOT relative paths or tilde expansion
file://localhost~/frames/...  # ❌ Wrong
file://localhost./frames/...  # ❌ Wrong
```

### Insufficient Data Error

If you see "Insufficient data to process event":

1. Check that GPS times are within frame coverage (1420877824 to 1420881920)
2. Extend GPS_END to provide more padding for whitening edge effects
3. Verify frame files contain the expected channel names

### NumPy Compatibility Errors

If you see `AttributeError: module 'numpy' has no attribute 'int'`:

Ensure you're using NumPy >= 1.24 compatible code. Manifold includes fixes for this.

## Next Steps

Now that you've run a basic SNR optimization:

1. **Try with live data:** Use `--data-source frames` with real-time frame streams
2. **Kafka integration:** Set up Kafka for event streaming
3. **Multiple events:** Process a catalog of events in batch mode
4. **Parameter estimation:** Compare SNR optimizer results with full PE (e.g., LALInference)
5. **Custom templates:** Generate banks with different approximants or mass ranges

## Additional Resources

- [Manifold Bank Generation Guide](template-bank-tutorial.md)
- [SGN Documentation](https://sgn.docs.io)
- [GWOSC Data Guide](https://gwosc.org/data)
- [LALSuite Documentation](https://lscsoft.docs.ligo.org/lalsuite)

## Summary

In this tutorial, you:

✅ Downloaded real LIGO/Virgo strain data from GWOSC
✅ Created a template bank for SNR optimization
✅ Set up frame cache and event files
✅ Ran the offline SNR optimizer with real data
✅ Examined the optimized event parameters

The SNR optimizer provides rapid parameter refinement for gravitational wave candidates, serving as a crucial step between matched-filter detection and full parameter estimation.
