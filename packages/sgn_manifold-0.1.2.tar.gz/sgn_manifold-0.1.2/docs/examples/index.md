# Examples

This section contains practical examples and tutorials demonstrating how to use Manifold for gravitational wave template bank generation.

## Tutorials

### [Simple Bank Tutorial](simple-bank-tutorial.md)
**Recommended for beginners** - A step-by-step guide to creating your first template bank:
- Generate a template bank with automatic coverage checking
- Visualize template distribution in parameter space
- Test bank coverage with simulated signals
- Create astrophysical mass models
- Export to standard formats

**Time required**: ~15 minutes  
**Parameter space**: 8-200 M☉, reduced spins

### [SNR Optimizer Tutorial](snr-optimizer-tutorial.md)
**For event follow-up** - Learn to use the SGN-based SNR optimizer for refining gravitational wave candidates:
- Download real LIGO/Virgo strain data from GWOSC
- Create template banks for parameter refinement
- Run offline SNR optimization with frame data
- Interpret optimized event parameters
- Compare with initial triggers

**Time required**: ~30 minutes
**Use case**: Rapid parameter refinement between detection and full PE

### [Advanced Template Bank Tutorial](template-bank-tutorial.md)
**For production use** - Comprehensive workflow for large-scale bank generation:
- Parallel seed bank generation and refinement
- Distributed coverage checking across multiple nodes
- Production-scale parameter spaces
- Performance optimization techniques
- Integration with search pipelines

**Time required**: 30-60 minutes
**Parameter space**: Full BBH range with aligned spins

## Quick Start Examples

### Basic Template Bank
```python
# Simple bank generation with Python API
import manifold.sources.cbc as cbc

# Define parameter space
bounds = {
    'm1': [10, 50],    # Primary mass (solar masses)
    'm2': [10, 50],    # Secondary mass
    'chi': [-0.5, 0.5] # Effective spin
}

# Generate bank
bank = cbc.Bank.from_bounds(
    bounds,
    mismatch=0.03,  # 3% maximum mismatch
    approximant='IMRPhenomD'
)

print(f"Generated {len(bank.templates)} templates")
```

### Command Line Usage
```bash
# Generate a simple bank
manifold-cbc-bank \
  --m1 10 50 \
  --m2 10 50 \
  --chi -0.5 0.5 \
  --mm 0.03 \
  --output-h5 my_bank.h5

# Check coverage
manifold-cbc-bank-check-coverage \
  --bank my_bank.h5 \
  --target-match 0.97 \
  --verbose

# Test with injections
manifold-cbc-bank-test \
  --bank my_bank.h5 \
  --num-injections 1000 \
  --output-h5 test_results.h5
```

## Example Categories

### Basic Usage
- **Coordinate Systems** - Working with different coordinate representations
- **Coordinate Transformations** - Converting between mass parameterizations  
- **Metric Calculations** - Computing Fisher information matrices

### Template Banks
- **Simple Bank Generation** - Creating a basic template bank
- **Hierarchical Banks** - Multi-resolution template placement
- **Bank Optimization** - Refining template placement
- **Coverage Verification** - Testing bank effectiveness

### Advanced Topics
- **Custom Metrics** - Implementing your own metric calculations
- **Signal Injection** - Testing template bank effectiveness  
- **Performance Optimization** - Scaling to large parameter spaces
- **Parallel Processing** - Distributed bank generation
- **Mass Models** - Astrophysical population weighting

## File Formats

Manifold uses HDF5 as its primary format, with support for:
- **Input**: YAML configuration, HDF5 banks, XML PSD files
- **Output**: HDF5 banks, XML exports, PNG/PDF plots

### HDF5 Bank Structure
```
bank.h5
├── rectangles/          # Template placement data
│   ├── centers          # Template coordinates
│   ├── metrics          # Fisher matrices
│   └── boundaries       # Rectangle boundaries
├── constraint_sets/     # Parameter space constraints
└── metadata/           # Bank configuration
    ├── approximant
    ├── mismatch
    └── psd_info
```

## Visualization Examples

### Bank Distribution Plot
Shows template placement in mass space:
```bash
manifold-cbc-bank-plot \
  --bank my_bank.h5 \
  --output-png bank_distribution.png
```

### Coverage Test Results
Visualizes match distribution:
```bash
manifold-cbc-bank-test-plot \
  --test test_results.h5
```

### Mass Model Visualization
Shows astrophysical weighting:
```bash
manifold-cbc-bank-plot-mass-model \
  --bank my_bank.h5 \
  --mass-model mass_model.h5 \
  --output-png mass_distribution.png
```

## Performance Tips

1. **Start Small**: Test with reduced parameter space first
2. **Use Appropriate Approximants**: 
   - `TaylorF2` - Fast, good for BNS
   - `IMRPhenomD` - Includes merger, good for BBH
   - `SEOBNRv4` - Most accurate but slower
3. **Parallel Processing**: Use multiple cores for large banks
4. **Coverage vs Speed**: Balance mismatch tolerance with template count
5. **Memory Management**: ~1GB RAM per 10,000 templates

## Common Parameter Spaces

### Binary Neutron Stars (BNS)
```yaml
m1: [1.0, 3.0]
m2: [1.0, 3.0]
chi: [-0.05, 0.05]
freq: [30, 2048]
```

### Binary Black Holes (BBH)
```yaml
m1: [3, 200]
m2: [3, 200]
chi: [-0.95, 0.95]
freq: [10, 1024]
```

### Intermediate Mass Black Holes (IMBH)
```yaml
m1: [50, 500]
m2: [50, 500]
chi: [-0.5, 0.5]
freq: [10, 512]
```

## Getting Help

- **Documentation**: Full API reference in the [User Guide](../user-guide/getting-started.md)
- **Issues**: Report bugs on [GitLab](https://git.ligo.org/chad-hanna/manifold/issues)
- **Examples**: Browse the `examples/` directory in the repository

## Contributing Examples

If you have an interesting use case or example, we welcome contributions! Please see the [Contributing Guide](../contributing.md) for details on submitting new examples.