# CBC Source Module

The `sources.cbc` module implements compact binary coalescence (CBC) specific functionality.

## Overview

This module provides specialized implementations for binary systems of compact objects (black holes and neutron stars).

## API Reference

::: manifold.sources.cbc