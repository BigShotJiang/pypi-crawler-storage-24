# Metric Module

The `metric` module provides tools for computing parameter space metrics using the Fisher information matrix approach.

## Overview

The metric defines distances in parameter space and is fundamental for template bank generation. It determines:

- How densely templates must be placed
- The effective dimensionality of the parameter space  
- Optimal coordinate systems for template placement

## API Reference

::: manifold.metric