# Cover Module

The `cover` module implements algorithms for covering parameter spaces with templates.

## Overview

Template bank generation is fundamentally a covering problem - placing templates such that any possible signal is sufficiently close to at least one template in the bank.

## API Reference

::: manifold.cover