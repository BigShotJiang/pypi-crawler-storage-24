# Signal Module

The `signal` module provides interfaces for gravitational wave signal models.

## Overview

This module defines the base interfaces for working with gravitational wave signals and waveforms.

## API Reference

::: manifold.signal