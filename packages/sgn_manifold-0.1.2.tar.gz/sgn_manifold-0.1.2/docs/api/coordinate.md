# Coordinate Module

The `coordinate` module provides a flexible framework for working with coordinates in parameter spaces. It includes support for coordinate transformations, type safety, and arithmetic operations.

## Overview

The coordinate system in Manifold is designed to handle the complex parameter spaces encountered in gravitational wave data analysis. Key features include:

- **Type-safe coordinates**: Each coordinate dimension can have a specific type
- **Coordinate transformations**: Convert between different coordinate systems (e.g., component masses to chirp mass)
- **Arithmetic operations**: Natural addition and manipulation of coordinate points
- **Bounds checking**: Ensure coordinates remain within valid parameter ranges

## Quick Example

```python
from manifold import coordinate

# Define coordinate types
class Mass1(coordinate.CoordinateType):
    key = "m1"

class Mass2(coordinate.CoordinateType):
    key = "m2"

# Create coordinates
point = coordinate.Coordinates(10.0, 20.0, coord_types=[Mass1, Mass2])
print(point)  # Coordinate(m1=10.0, m2=20.0)

# Coordinate arithmetic
offset = coordinate.Coordinates(1.0, 2.0, coord_types=[Mass1, Mass2])
new_point = point + offset
print(new_point)  # Coordinate(m1=11.0, m2=22.0)
```

## Coordinate Transformations

The module supports complex coordinate transformations through the `CoordFunc` class:

```python
import numpy as np

class LogMass1(coordinate.CoordinateType):
    key = "log10m1"

class LogMass2(coordinate.CoordinateType):
    key = "log10m2"

class MassToLogMassTransform(coordinate.CoordFunc):
    TO_TYPES = (Mass1, Mass2)
    FROM_TYPES = (LogMass1, LogMass2)
    
    def __call__(self, c, inv=False):
        if inv:
            # Convert from mass to log mass
            c_dict = self._normalize_coorddict(c, inv=True)
            return np.array([
                np.log10(c_dict[Mass1]),
                np.log10(c_dict[Mass2])
            ])
        else:
            # Convert from log mass to mass
            if isinstance(c, dict):
                c = self._normalize_coorddict(c)
                return {
                    Mass1: 10 ** c[LogMass1],
                    Mass2: 10 ** c[LogMass2]
                }
            else:
                # Handle array input
                c_array = coordinate.to_array(c)
                return {
                    Mass1: 10 ** c_array[0],
                    Mass2: 10 ** c_array[1]
                }

# Use the transformation
transform = MassToLogMassTransform(m1=(1.0, 100.0), m2=(1.0, 100.0))
log_masses = transform({Mass1: 10.0, Mass2: 20.0}, inv=True)
print(log_masses)  # [1.0, 1.30103]
```

## API Reference

::: manifold.coordinate