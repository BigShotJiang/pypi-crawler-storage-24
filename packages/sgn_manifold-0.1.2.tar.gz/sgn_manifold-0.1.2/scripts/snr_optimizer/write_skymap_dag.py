#!/usr/bin/env python3

import os

paths = ["/home/prathamesh.joshi/try/gwtc4_extra_coincs/optimizer/non-AR/optimizer_coincs/"]

with open("skymap.dag", 'w') as f:
	counter = 0
	for path in paths:
		for coinc in os.listdir(path):
			i = format(counter, '05')
			f.write(f'JOB skymap.{i} skymap.sub\n')
			f.write(f'VARS skymap.{i} nodename="skymap_{i}" input_coinc="{path + coinc}"\n')
			counter += 1
