#!/usr/bin/env python3

import os
from ligo.lw import lsctables
from ligo.lw import utils as ligolw_utils
from ligo.lw import ligolw
from ligo.lw import array as ligolw_array
from ligo.lw import param as ligolw_param



class LIGOLWContentHandler(ligolw.LIGOLWContentHandler):
	pass
ligolw_array.use_in(LIGOLWContentHandler)
ligolw_param.use_in(LIGOLWContentHandler)
lsctables.use_in(LIGOLWContentHandler)

path = "/home/gstlalcbc.offline/observing/4/a/injections/rank_RPO4/rank.edward_250118/combined/coincs/"
output_dir = "optimizer_coincs/"
channel_dict = {'H1':'--channel-name H1=GDS-CALIB_STRAIN_CLEAN ', 'L1':"--channel-name L1=GDS-CALIB_STRAIN_CLEAN "}

with open("snr_optimizer.dag", 'w') as f:
	for i, coinc in enumerate(os.listdir(path)):
		if not coinc.endswith('xml.gz'):
			print(f"skipping {coinc}")
			continue
		coinc_new = output_dir + "/" + coinc
		coinc = path + coinc
		coinc_xmldoc = ligolw_utils.load_filename(coinc, contenthandler = LIGOLWContentHandler)
		coinc_inspiral_table = lsctables.CoincInspiralTable.get_table(coinc_xmldoc)

		sngl_tables = lsctables.SnglInspiralTable.get_table(coinc_xmldoc)
		channels = []
		for sngl_row in sngl_tables:
			channels.append(sngl_row.channel)
		channels = set(channels)

		coinc_inspiral = coinc_inspiral_table[0] # assume 1
		tc = coinc_inspiral.end
		int_tc = int(round(float(tc)))
		start = int_tc - 5*60
		end = int_tc + 1*60

		sngl_inspiral_table = lsctables.SnglInspiralTable.get_table(coinc_xmldoc)
		channels = ""
		for s in sngl_inspiral_table:
			channels += channel_dict[s.ifo]

		i = format(i, '05')
		f.write(f'JOB snr_optimizer.{i} snr_optimizer.sub\n')
		f.write(f'VARS snr_optimizer.{i} nodename="snr_optimizer_{i}" input="{coinc}" output="{coinc_new}" start="{start}" end="{end}" channels="{channels}"\n')
		f.write(f'RETRY snr_optimizer.{i} 1\n')
