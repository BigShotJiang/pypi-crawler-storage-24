"""Tests for manifold.io module"""

import os
import tempfile
from unittest import mock

import h5py
import lal
import numpy
import pytest
from lal import LIGOTimeGPS
from ligo import segments

from sgn_manifold.io import (
    INT64_NAN,
    JSONEncoder,
    dict2r8f,
    gps2k,
    h5decode,
    h5encode,
    h5read,
    h5snapshot,
    h5write,
    k2gps,
    record_env,
    sim_inspiral_to_dict,
)


class TestJSONEncoder:
    """Test JSONEncoder class"""

    def test_encode_ligotimegps(self):
        """Test encoding LIGOTimeGPS objects"""
        gps = LIGOTimeGPS(1234567890, 123456789)
        encoder = JSONEncoder()
        result = encoder.encode(gps)
        assert result == '"1234567890.123456789"'

    def test_encode_regular_object(self):
        """Test encoding regular objects falls back to default"""
        encoder = JSONEncoder()
        result = encoder.encode({"key": "value"})
        assert result == '{"key": "value"}'

    def test_encode_unsupported_object(self):
        """Test encoding unsupported object raises TypeError"""
        encoder = JSONEncoder()

        class UnsupportedClass:
            pass

        with pytest.raises(TypeError):
            encoder.encode(UnsupportedClass())


class TestGPSConversion:
    """Test GPS conversion functions"""

    def test_gps2k(self):
        """Test converting LIGOTimeGPS to string key"""
        gps = LIGOTimeGPS(1234567890, 123456789)
        result = gps2k(gps)
        assert result == "1234567890.123456789"

    def test_k2gps(self):
        """Test converting string key to LIGOTimeGPS"""
        key = "1234567890.123456789"
        result = k2gps(key)
        assert isinstance(result, LIGOTimeGPS)
        assert result.gpsSeconds == 1234567890
        assert result.gpsNanoSeconds == 123456789


class TestDict2R8F:
    """Test dict2r8f function"""

    def test_dict2r8f(self):
        """Test converting dictionary to REAL8FrequencySeries"""
        data = numpy.array([1.0, 2.0, 3.0, 4.0, 5.0])
        obj = {
            "name": "test_series",
            "epoch": LIGOTimeGPS(1234567890, 0),
            "f0": 0.0,
            "deltaF": 1.0,
            "sampleUnits": b"strain",
            "data": data,
        }

        result = dict2r8f(obj)

        assert isinstance(result, lal.REAL8FrequencySeries)
        assert result.name == "test_series"
        assert result.f0 == 0.0
        assert result.deltaF == 1.0
        assert numpy.array_equal(result.data.data, data)


class TestRecordEnv:
    """Test record_env function"""

    def test_record_env_default(self):
        """Test recording environment with default variables"""
        with mock.patch.dict(
            os.environ, {"PATH": "/usr/bin", "PYTHONPATH": "/usr/lib"}
        ):
            with mock.patch("os.uname") as mock_uname:
                mock_uname.return_value = (
                    "Linux",
                    "hostname",
                    "5.0.0",
                    "version",
                    "x86_64",
                )
                with mock.patch("os.getcwd", return_value="/home/user"):
                    with mock.patch("os.getpid", return_value=12345):
                        with mock.patch("pwd.getpwuid") as mock_pwd:
                            mock_pwd.return_value = ["testuser"]
                            with mock.patch("sys.argv", ["test.py", "arg1", "arg2"]):
                                result = record_env()

        # Check that result is a dict with timestamp key
        assert len(result) == 1
        timestamp_key = list(result.keys())[0]
        info = result[timestamp_key]

        assert info["PATH"] == "/usr/bin"
        assert info["PYTHONPATH"] == "/usr/lib"
        assert info["sysname"] == "Linux"
        assert info["nodename"] == "hostname"
        assert info["cwd"] == "/home/user"
        assert info["pid"] == "12345"
        assert info["user"] == "testuser"
        assert info["cmd"] == "test.py arg1 arg2"

    def test_record_env_custom_vars(self):
        """Test recording environment with custom variables"""
        custom_vars = ("CUSTOM_VAR",)
        with mock.patch.dict(os.environ, {"CUSTOM_VAR": "custom_value"}):
            with mock.patch("os.uname") as mock_uname:
                mock_uname.return_value = (
                    "Linux",
                    "hostname",
                    "5.0.0",
                    "version",
                    "x86_64",
                )
                with mock.patch("os.getcwd", return_value="/home/user"):
                    with mock.patch("os.getpid", return_value=12345):
                        with mock.patch("pwd.getpwuid") as mock_pwd:
                            mock_pwd.return_value = ["testuser"]
                            with mock.patch("sys.argv", ["test.py"]):
                                result = record_env(env_vars=custom_vars)

        timestamp_key = list(result.keys())[0]
        info = result[timestamp_key]
        assert info["CUSTOM_VAR"] == "custom_value"


class TestH5Functions:
    """Test HDF5 read/write functions"""

    def test_h5encode_dict(self):
        """Test encoding nested dictionaries"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            with h5py.File(fname, "w") as f:
                obj = {
                    "group1": {
                        "subkey1": "value1",
                        "subkey2": 42,
                    },
                    "scalar": 3.14,
                }
                h5encode(f, obj)

            # Verify the structure
            with h5py.File(fname, "r") as f:
                assert "group1" in f
                assert "scalar" in f
                assert f["group1/subkey1"][()] == b"value1"
                assert f["group1/subkey2"][()] == 42
                assert f["scalar"][()] == 3.14
        finally:
            os.unlink(fname)

    def test_h5encode_with_attrs(self):
        """Test encoding data with attributes"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            with h5py.File(fname, "w") as f:
                obj = {
                    "data_with_attrs": {
                        "__data__": numpy.array([1, 2, 3]),
                        "__attrs__": {"unit": "meters", "version": 1},
                    }
                }
                h5encode(f, obj)

            # Verify the structure
            with h5py.File(fname, "r") as f:
                assert "data_with_attrs" in f
                dataset = f["data_with_attrs"]
                assert numpy.array_equal(dataset[:], [1, 2, 3])
                assert dataset.attrs["unit"] == b"meters"
                assert dataset.attrs["version"] == 1
        finally:
            os.unlink(fname)

    def test_h5encode_invalid_attrs(self):
        """Test encoding with invalid attribute structure raises error"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            with h5py.File(fname, "w") as f:
                obj = {
                    "invalid": {
                        "__attrs__": {"key": "value"},
                        "other_key": "other_value",  # This makes it invalid
                    }
                }
                with pytest.raises(ValueError, match="Currently only attribute"):
                    h5encode(f, obj)
        finally:
            os.unlink(fname)

    def test_h5encode_segmentlist(self):
        """Test encoding segment lists"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            with h5py.File(fname, "w") as f:
                # Create segments with LIGOTimeGPS objects
                seg1 = segments.segment(LIGOTimeGPS(0), LIGOTimeGPS(10))
                seg2 = segments.segment(LIGOTimeGPS(20), LIGOTimeGPS(30))
                seglist = segments.segmentlist([seg1, seg2])
                obj = {"segments": seglist}
                h5encode(f, obj)

            # Verify the data was written
            with h5py.File(fname, "r") as f:
                assert "segments" in f
        finally:
            os.unlink(fname)

    def test_h5encode_ligotimegps(self):
        """Test encoding LIGOTimeGPS objects"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            with h5py.File(fname, "w") as f:
                gps = LIGOTimeGPS(1234567890, 123456789)
                obj = {"gps_time": gps}
                h5encode(f, obj)

            # Verify the data was written
            with h5py.File(fname, "r") as f:
                assert "gps_time" in f
        finally:
            os.unlink(fname)

    def test_h5encode_real8frequencyseries(self):
        """Test encoding REAL8FrequencySeries"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            # Create a REAL8FrequencySeries
            series = lal.CreateREAL8FrequencySeries(
                name="test",
                epoch=LIGOTimeGPS(0),
                f0=0.0,
                deltaF=1.0,
                sampleUnits=lal.HertzUnit,
                length=5,
            )
            series.data.data[:] = [1.0, 2.0, 3.0, 4.0, 5.0]

            with h5py.File(fname, "w") as f:
                obj = {"series": series}
                h5encode(f, obj)

            # Verify the data was written
            with h5py.File(fname, "r") as f:
                assert "series" in f
        finally:
            os.unlink(fname)

    def test_h5encode_ndarray_with_compression(self):
        """Test encoding numpy arrays with compression"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            with h5py.File(fname, "w") as f:
                data = numpy.random.randn(1000)
                obj = {"array": data}
                h5encode(f, obj, compression="gzip")

            # Verify the data was written with compression
            with h5py.File(fname, "r") as f:
                assert "array" in f
                assert f["array"].compression == "gzip"
                assert numpy.allclose(f["array"][:], data)
        finally:
            os.unlink(fname)

    def test_h5encode_unsupported_type(self):
        """Test encoding unsupported type raises informative error"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            with h5py.File(fname, "w") as f:

                class UnsupportedClass:
                    pass

                obj = {"unsupported": UnsupportedClass()}
                with pytest.raises(ValueError, match="Could not write unsupported"):
                    h5encode(f, obj)
        finally:
            os.unlink(fname)

    def test_h5write(self):
        """Test h5write function"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            obj = {"data": numpy.array([1, 2, 3])}
            h5write(fname, obj)

            # Verify the file was written and contains process info
            with h5py.File(fname, "r") as f:
                assert "data" in f
                assert "__process" in f
        finally:
            os.unlink(fname)

    def test_h5write_with_existing_process(self):
        """Test h5write with existing __process key"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            obj = {
                "data": numpy.array([1, 2, 3]),
                "__process": {"existing_key": "existing_value"},
            }
            h5write(fname, obj)

            # Verify the process info was updated
            result = h5read(fname)
            assert "__process" in result
            assert "existing_key" in result["__process"]
            # Should have a timestamp key as well
            assert len(result["__process"]) > 1
        finally:
            os.unlink(fname)

    def test_h5snapshot(self):
        """Test h5snapshot function"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            obj = {"data": numpy.array([1, 2, 3])}
            h5snapshot(fname, obj)

            # Verify the file was written
            result = h5read(fname)
            assert numpy.array_equal(result["data"], [1, 2, 3])
        finally:
            os.unlink(fname)

    def test_h5snapshot_with_condor_scratch(self):
        """Test h5snapshot with CONDOR_SCRATCH_DIR set"""
        with tempfile.TemporaryDirectory() as tmpdir:
            with mock.patch.dict(os.environ, {"_CONDOR_SCRATCH_DIR": tmpdir}):
                fname = os.path.join(tmpdir, "test.h5")
                obj = {"data": numpy.array([1, 2, 3])}
                h5snapshot(fname, obj)

                # Verify the file was written
                result = h5read(fname)
                assert numpy.array_equal(result["data"], [1, 2, 3])

    def test_h5decode_dataset_with_attrs(self):
        """Test decoding dataset with attributes"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            # Create a file with dataset that has attributes
            # Use npencode to encode the attributes properly
            with h5py.File(fname, "w") as f:
                from sgn_manifold.np import npencode

                dataset = f.create_dataset("data", data=numpy.array([1, 2, 3]))
                dataset.attrs["unit"] = npencode("meters")
                dataset.attrs["version"] = npencode(1)

            # Read and decode
            with h5py.File(fname, "r") as f:
                result = h5decode(f["data"])

            assert "__attrs__" in result
            assert "__data__" in result
            assert result["__attrs__"]["unit"] == "meters"
            assert result["__attrs__"]["version"] == 1
            assert numpy.array_equal(result["__data__"], [1, 2, 3])
        finally:
            os.unlink(fname)

    def test_h5decode_group(self):
        """Test decoding groups"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            # Create a file with nested structure
            with h5py.File(fname, "w") as f:
                f.create_dataset("scalar", data=42)
                group = f.create_group("group1")
                group.create_dataset("data", data=numpy.array([1, 2, 3]))

            # Read and decode
            with h5py.File(fname, "r") as f:
                result = h5decode(f)

            assert result["scalar"] == 42
            assert "group1" in result
            assert numpy.array_equal(result["group1"]["data"], [1, 2, 3])
        finally:
            os.unlink(fname)

    def test_h5decode_ignore_groups(self):
        """Test decoding with ignored groups"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            # Create a file with groups to ignore
            with h5py.File(fname, "w") as f:
                f.create_dataset("keep", data=1)
                f.create_group("ignore_me")
                f["ignore_me"].create_dataset("data", data=2)

            # Read and decode with ignore
            with h5py.File(fname, "r") as f:
                result = h5decode(f, ignore_groups=("ignore_me",))

            assert result["keep"] == 1
            assert "ignore_me" not in result
        finally:
            os.unlink(fname)

    def test_h5read_full_file(self):
        """Test reading entire HDF5 file"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            # Write test data
            obj = {"data": numpy.array([1, 2, 3]), "scalar": 42}
            h5write(fname, obj)

            # Read it back
            result = h5read(fname)
            assert numpy.array_equal(result["data"], [1, 2, 3])
            assert result["scalar"] == 42
        finally:
            os.unlink(fname)

    def test_h5read_specific_group(self):
        """Test reading specific group from HDF5 file"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            # Write test data with groups
            with h5py.File(fname, "w") as f:
                f.create_dataset("root_data", data=1)
                group = f.create_group("mygroup")
                group.create_dataset("group_data", data=2)

            # Read specific group
            result = h5read(fname, g="mygroup")
            assert result["group_data"] == 2
            assert "root_data" not in result
        finally:
            os.unlink(fname)

    def test_h5read_nonexistent_file(self):
        """Test reading non-existent file returns empty dict"""
        result = h5read("/nonexistent/file.h5")
        assert result == {}

    def test_h5read_with_ignore_groups(self):
        """Test h5read with ignore_groups parameter"""
        with tempfile.NamedTemporaryFile(delete=False) as f:
            fname = f.name

        try:
            # Write test data
            with h5py.File(fname, "w") as f:
                f.create_dataset("keep", data=1)
                f.create_group("__process")
                f["__process"].create_dataset("data", data=2)

            # Read with ignore
            result = h5read(fname, ignore_groups=("__process",))
            assert result["keep"] == 1
            assert "__process" not in result
        finally:
            os.unlink(fname)


class TestSimInspiralToDict:
    """Test sim_inspiral_to_dict function"""

    def test_sim_inspiral_to_dict_without_snr(self):
        """Test converting sim_inspiral to dict without SNR"""
        # Create a mock sim_inspiral object
        sim = mock.Mock()
        sim.time_geocent = LIGOTimeGPS(1234567890, 0)
        sim.mass1 = 1.4
        sim.mass2 = 1.4
        sim.spin1x = 0.0
        sim.spin1y = 0.0
        sim.spin1z = 0.0
        sim.spin2x = 0.0
        sim.spin2y = 0.0
        sim.spin2z = 0.0
        sim.distance = 100.0
        sim.inclination = 0.0
        sim.coa_phase = 0.0
        sim.h_end_time = 1234567890
        sim.h_end_time_ns = 500000000
        sim.l_end_time = 1234567890
        sim.l_end_time_ns = 500000000
        sim.v_end_time = 1234567890
        sim.v_end_time_ns = 500000000

        result = sim_inspiral_to_dict(sim)

        assert result["mass1"] == 1.4
        assert result["mass2"] == 1.4
        assert result["distance"] == 100.0
        assert "snr" not in result
        assert isinstance(result["h_end_time"], LIGOTimeGPS)
        assert result["h_end_time"].gpsSeconds == 1234567890
        assert result["h_end_time"].gpsNanoSeconds == 500000000

    def test_sim_inspiral_to_dict_with_snr(self):
        """Test converting sim_inspiral to dict with SNR"""
        # Create a mock sim_inspiral object
        sim = mock.Mock()
        sim.time_geocent = LIGOTimeGPS(1234567890, 0)
        sim.mass1 = 1.4
        sim.mass2 = 1.4
        sim.spin1x = 0.0
        sim.spin1y = 0.0
        sim.spin1z = 0.0
        sim.spin2x = 0.0
        sim.spin2y = 0.0
        sim.spin2z = 0.0
        sim.distance = 100.0
        sim.inclination = 0.0
        sim.coa_phase = 0.0
        sim.h_end_time = 1234567890
        sim.h_end_time_ns = 500000000
        sim.l_end_time = 1234567890
        sim.l_end_time_ns = 500000000
        sim.v_end_time = 1234567890
        sim.v_end_time_ns = 500000000

        result = sim_inspiral_to_dict(sim, snr=20.0)

        assert result["snr"] == 20.0


class TestConstants:
    """Test module constants"""

    def test_int64_nan(self):
        """Test INT64_NAN constant"""
        assert INT64_NAN == numpy.iinfo(numpy.int64).min
