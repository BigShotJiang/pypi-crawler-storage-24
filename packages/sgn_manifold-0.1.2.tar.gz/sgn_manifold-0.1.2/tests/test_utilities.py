"""Tests for manifold.utilities.common and manifold.utilities.data modules

This test suite provides 100% coverage for:
- manifold.utilities.common.bounds_from_lists
- manifold.utilities.data module (paths and read_psd function)
"""

from __future__ import annotations

import pathlib

import numpy
import pytest

from sgn_manifold.utilities import common, data


class TestCommon:
    """Test manifold.utilities.common module"""

    def test_bounds_from_lists_success(self):
        """Test successful creation of bounds dictionary"""
        names = ["m1", "m2", "spin"]
        mins = [1.0, 1.0, -0.5]
        maxes = [100.0, 100.0, 0.5]

        result = common.bounds_from_lists(names, mins, maxes)

        assert result == {
            "m1": (1.0, 100.0),
            "m2": (1.0, 100.0),
            "spin": (-0.5, 0.5),
        }

    def test_bounds_from_lists_single_element(self):
        """Test with single element lists"""
        result = common.bounds_from_lists(["x"], [0.0], [1.0])
        assert result == {"x": (0.0, 1.0)}

    def test_bounds_from_lists_empty(self):
        """Test with empty lists"""
        result = common.bounds_from_lists([], [], [])
        assert result == {}

    def test_bounds_from_lists_mismatched_lengths_names_short(self):
        """Test error when names list is shorter than mins/maxes"""
        with pytest.raises(ValueError, match="must have same lengths"):
            common.bounds_from_lists(["m1"], [1.0, 2.0], [10.0, 20.0])

    def test_bounds_from_lists_mismatched_lengths_mins_short(self):
        """Test error when mins list is shorter than names/maxes"""
        with pytest.raises(ValueError, match="must have same lengths"):
            common.bounds_from_lists(["m1", "m2"], [1.0], [10.0, 20.0])

    def test_bounds_from_lists_mismatched_lengths_maxes_short(self):
        """Test error when maxes list is shorter than names/mins"""
        with pytest.raises(ValueError, match="must have same lengths"):
            common.bounds_from_lists(["m1", "m2"], [1.0, 2.0], [10.0])

    def test_bounds_from_lists_all_different_lengths(self):
        """Test error when all lists have different lengths"""
        with pytest.raises(ValueError) as exc_info:
            common.bounds_from_lists(["a"], [1.0, 2.0], [1.0, 2.0, 3.0])

        error_msg = str(exc_info.value)
        assert "must have same lengths" in error_msg
        # Check that the error message shows the actual lengths
        assert "1" in error_msg  # length of names
        assert "2" in error_msg  # length of mins
        assert "3" in error_msg  # length of maxes

    def test_metric_matrix_type_alias(self):
        """Test that MetricMatrix type alias exists and is ndarray"""
        assert common.MetricMatrix is numpy.ndarray


class TestData:
    """Test manifold.utilities.data module"""

    def test_package_root_path(self):
        """Test that PACKAGE_ROOT points to manifold package"""
        assert data.PACKAGE_ROOT.exists()
        assert data.PACKAGE_ROOT.name == "sgn_manifold"
        assert (data.PACKAGE_ROOT / "utilities").exists()

    def test_data_root_path(self):
        """Test that DATA_ROOT points to manifold/data directory"""
        assert data.DATA_ROOT.exists()
        assert data.DATA_ROOT.name == "data"
        assert data.DATA_ROOT.parent.name == "sgn_manifold"

    def test_script_root_path(self):
        """Test that SCRIPT_ROOT points to bin directory"""
        assert data.SCRIPT_ROOT.exists()
        assert data.SCRIPT_ROOT.name == "bin"

    def test_treebank_psd_path(self):
        """Test that TREEBANK_PSD path exists and points to O4 PSD file"""
        assert data.TREEBANK_PSD.exists()
        assert data.TREEBANK_PSD.name == "O4_projected_psds.xml.gz"
        assert data.TREEBANK_PSD.parent == data.DATA_ROOT

    def test_o3a_psd_path(self):
        """Test that O3A_PSD path exists (currently same as O4)"""
        assert data.O3A_PSD.exists()
        assert data.O3A_PSD.name == "O4_projected_psds.xml.gz"
        # Currently O3A_PSD and TREEBANK_PSD point to the same file
        assert data.O3A_PSD == data.TREEBANK_PSD

    def test_read_psd_with_str_path(self):
        """Test reading PSD with string path"""
        psd_path = str(data.TREEBANK_PSD)
        psd = data.read_psd(psd_path, "H1")

        # Check that we got a REAL8FrequencySeries back
        assert hasattr(psd, "data")
        assert hasattr(psd, "f0")
        assert hasattr(psd, "deltaF")

    def test_read_psd_with_pathlib_path(self):
        """Test reading PSD with pathlib.Path object"""
        psd_path = pathlib.Path(data.TREEBANK_PSD)
        psd = data.read_psd(psd_path, "H1")

        # Check that we got a REAL8FrequencySeries back
        assert hasattr(psd, "data")
        assert hasattr(psd, "f0")
        assert hasattr(psd, "deltaF")

    def test_read_psd_different_detectors(self):
        """Test reading PSDs for different detectors"""
        # Test H1
        psd_h1 = data.read_psd(data.TREEBANK_PSD, "H1")
        assert hasattr(psd_h1, "data")

        # Test L1
        psd_l1 = data.read_psd(data.TREEBANK_PSD, "L1")
        assert hasattr(psd_l1, "data")

        # PSDs should be different for different detectors
        # (or at least different objects)
        assert id(psd_h1) != id(psd_l1)

    def test_read_psd_with_verbose_false(self):
        """Test reading PSD with verbose=False (default)"""
        psd = data.read_psd(data.TREEBANK_PSD, "H1", verbose=False)
        assert hasattr(psd, "data")

    def test_read_psd_with_verbose_true(self):
        """Test reading PSD with verbose=True"""
        # This should work without errors, just with more output
        psd = data.read_psd(data.TREEBANK_PSD, "H1", verbose=True)
        assert hasattr(psd, "data")

    def test_read_psd_invalid_detector(self):
        """Test that reading PSD with invalid detector raises KeyError"""
        with pytest.raises(KeyError):
            data.read_psd(data.TREEBANK_PSD, "INVALID_DETECTOR")

    def test_read_psd_nonexistent_file(self):
        """Test that reading PSD from nonexistent file raises error"""
        with pytest.raises(
            (FileNotFoundError, IOError, OSError), match=".*nonexistent.*"
        ):
            data.read_psd("/nonexistent/path/to/psd.xml.gz", "H1")
