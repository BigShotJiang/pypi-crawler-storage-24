"""Tests for manifold.initializer module"""

import inspect

from sgn_manifold.initializer import initializer

# Patch getargspec to use getfullargspec for Python 3 compatibility
if not hasattr(inspect, "getargspec"):

    def _getargspec(func):
        # getfullargspec returns: args, varargs, varkw, defaults, kwonlyargs,
        # kwonlydefaults, annotations
        # getargspec returned: args, varargs, keywords, defaults
        spec = inspect.getfullargspec(func)
        return spec.args, spec.varargs, spec.varkw, spec.defaults

    inspect.getargspec = _getargspec


class TestInitializer:
    """Test the initializer decorator"""

    def test_basic_initialization(self):
        """Test basic parameter initialization"""

        class Process:
            @initializer
            def __init__(self, cmd, reachable=False, user="root"):
                pass

        p = Process("halt", True)
        assert p.cmd == "halt"
        assert p.reachable is True
        assert p.user == "root"

    def test_positional_args(self):
        """Test initialization with positional arguments"""

        class Example:
            @initializer
            def __init__(self, a, b, c):
                pass

        e = Example(1, 2, 3)
        assert e.a == 1
        assert e.b == 2
        assert e.c == 3

    def test_keyword_args(self):
        """Test initialization with keyword arguments"""

        class Example:
            @initializer
            def __init__(self, a, b, c):
                pass

        e = Example(a=1, b=2, c=3)
        assert e.a == 1
        assert e.b == 2
        assert e.c == 3

    def test_mixed_args(self):
        """Test initialization with mixed positional and keyword arguments"""

        class Example:
            @initializer
            def __init__(self, a, b, c=3, d=4):
                pass

        e = Example(1, b=2, d=5)
        assert e.a == 1
        assert e.b == 2
        assert e.c == 3  # default
        assert e.d == 5  # overridden

    def test_default_values(self):
        """Test that default values are properly assigned"""

        class Example:
            @initializer
            def __init__(self, a, b=2, c=3):
                pass

        e = Example(1)
        assert e.a == 1
        assert e.b == 2
        assert e.c == 3

    def test_override_defaults_with_positional(self):
        """Test overriding default values with positional arguments"""

        class Example:
            @initializer
            def __init__(self, a, b=2, c=3):
                pass

        e = Example(1, 4, 5)
        assert e.a == 1
        assert e.b == 4
        assert e.c == 5

    def test_override_defaults_with_keyword(self):
        """Test overriding default values with keyword arguments"""

        class Example:
            @initializer
            def __init__(self, a, b=2, c=3):
                pass

        e = Example(1, c=5)
        assert e.a == 1
        assert e.b == 2  # default
        assert e.c == 5  # overridden

    def test_no_defaults(self):
        """Test class with no default values"""

        class Example:
            @initializer
            def __init__(self, a, b):
                pass

        e = Example(1, 2)
        assert e.a == 1
        assert e.b == 2

    def test_all_defaults(self):
        """Test class where all parameters have defaults"""

        class Example:
            @initializer
            def __init__(self, a=1, b=2, c=3):
                pass

        e = Example()
        assert e.a == 1
        assert e.b == 2
        assert e.c == 3

    def test_function_executes(self):
        """Test that the original __init__ function still executes"""

        class Example:
            @initializer
            def __init__(self, a, b):
                self.computed = a + b

        e = Example(2, 3)
        assert e.a == 2
        assert e.b == 3
        assert e.computed == 5

    def test_self_not_assigned(self):
        """Test that 'self' parameter is not assigned as attribute"""

        class Example:
            @initializer
            def __init__(self, a):
                pass

        e = Example(1)
        assert e.a == 1
        assert not hasattr(e, "self")

    def test_empty_init(self):
        """Test decorator on empty __init__"""

        class Example:
            @initializer
            def __init__(self):
                pass

        e = Example()
        # Should not raise an error
        assert isinstance(e, Example)

    def test_complex_defaults(self):
        """Test with complex default values"""

        class Example:
            @initializer
            def __init__(self, a, b=None, c=None, d=None):
                if c is None:
                    c = []
                if d is None:
                    d = {}
                # The decorator will have already set these, but the function
                # body can modify them if needed

        e1 = Example(1)
        assert e1.a == 1
        assert e1.b is None
        assert e1.c is None
        assert e1.d is None

        # Test with overrides
        e2 = Example(2, b="test", c=[1, 2], d={"key": "value"})
        assert e2.a == 2
        assert e2.b == "test"
        assert e2.c == [1, 2]
        assert e2.d == {"key": "value"}

    def test_many_parameters(self):
        """Test with many parameters to ensure zip works correctly"""

        class Example:
            @initializer
            def __init__(self, a, b, c, d, e, f=6, g=7):
                pass

        ex = Example(1, 2, 3, 4, 5)
        assert ex.a == 1
        assert ex.b == 2
        assert ex.c == 3
        assert ex.d == 4
        assert ex.e == 5
        assert ex.f == 6
        assert ex.g == 7

    def test_decorator_preserves_metadata(self):
        """Test that @wraps preserves function metadata"""

        class Example:
            @initializer
            def __init__(self, a):
                """This is the docstring"""
                pass

        # Check that wrapper preserves the original function's metadata
        assert Example.__init__.__name__ == "__init__"
        assert Example.__init__.__doc__ == "This is the docstring"

    def test_with_inheritance(self):
        """Test that initializer works with inheritance"""

        class Base:
            @initializer
            def __init__(self, a, b=2):
                pass

        class Derived(Base):
            def __init__(self, a, b=2, c=3):
                super().__init__(a, b)
                self.c = c

        d = Derived(1, c=5)
        assert d.a == 1
        assert d.b == 2
        assert d.c == 5

    def test_attribute_already_exists(self):
        """Test behavior when attribute already exists before defaults are applied"""

        class Example:
            @initializer
            def __init__(self, a=1):
                pass

        e = Example()
        # The decorator should set the default value
        assert e.a == 1

        # Test with explicit value
        e2 = Example(a=5)
        assert e2.a == 5

    def test_kwargs_with_args(self):
        """Test kwargs used together with positional args"""

        class Example:
            @initializer
            def __init__(self, a, b, c=3):
                pass

        # Test mixing positional and keyword args
        e = Example(1, b=2)
        assert e.a == 1
        assert e.b == 2
        assert e.c == 3  # default

        # Test all keyword args
        e2 = Example(a=4, b=5, c=6)
        assert e2.a == 4
        assert e2.b == 5
        assert e2.c == 6

    def test_real_world_example(self):
        """Test a real-world usage example"""

        class DatabaseConnection:
            @initializer
            def __init__(
                self, host, port=5432, user="admin", password=None, database="default"
            ):
                self.connected = False
                if password:
                    self.connected = True

        # Test with minimal args
        db1 = DatabaseConnection("localhost")
        assert db1.host == "localhost"
        assert db1.port == 5432
        assert db1.user == "admin"
        assert db1.password is None
        assert db1.database == "default"
        assert db1.connected is False

        # Test with all args
        # S105: This is a test password, not a real credential
        db2 = DatabaseConnection(
            "remote.host", 3306, "root", "testpass", "mydb"
        )  # nosec
        assert db2.host == "remote.host"
        assert db2.port == 3306
        assert db2.user == "root"
        assert db2.password == "testpass"
        assert db2.database == "mydb"
        assert db2.connected is True
