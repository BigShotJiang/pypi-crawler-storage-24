"""Additional tests for metric.py to achieve 100% coverage"""

from unittest import mock

import lal
import numpy
import pytest
from lal import LIGOTimeGPS

from sgn_manifold import coordinate, metric
from sgn_manifold.metric import match_minus_1, match_minus_1_at_coords_w_t


class TestRemainingCoverage:
    """Test remaining uncovered lines"""

    def test_evaluate_with_coordinates_array_conversion(self):
        """Test evaluate with array that needs conversion to Coordinates"""
        # Create real PSD
        psd = lal.CreateREAL8FrequencySeries(
            name="psd",
            epoch=LIGOTimeGPS(0),
            f0=0.0,
            deltaF=1.0,
            sampleUnits=lal.HertzUnit,
            length=100,
        )
        psd.data.data[:] = 1.0

        coord_func = mock.Mock()
        coord_func.target_match = mock.Mock(return_value=0.97)
        coord_func.min_eig_val = 1e-6
        coord_func.base_step = mock.Mock(return_value=numpy.array([1e-4, 1e-4]))

        m = metric.Metric(psd, coord_func)

        # Track whether a Coordinates object was created
        original_init = coordinate.Coordinates.__init__
        coordinates_created = []

        def track_coordinates_init(self, *args, **kwargs):
            coordinates_created.append(True)
            return original_init(self, *args, **kwargs)

        # Mock waveform method to avoid NotImplementedError
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(m.working_length, dtype=complex)
        m.waveform = mock.Mock(return_value=mock_waveform)

        # Mock waveform_shift to avoid the waveform call
        m.waveform_shift = mock.Mock(return_value=mock_waveform)

        # Mock the evaluation methods before tracking coordinates
        mock_metric = numpy.eye(2)
        with mock.patch.object(m, "_post_process_metric", return_value=mock_metric):
            with mock.patch.object(
                m, "_evaluate_deterministic", return_value=numpy.eye(3)
            ):
                with mock.patch.object(
                    coordinate.Coordinates, "__init__", track_coordinates_init
                ):
                    # Test with numpy array input (line 326)
                    center = numpy.array([1.0, 2.0])
                    result = m.evaluate(center, method="deterministic")

                    assert result.shape == (2, 2)
                    # Verify that a Coordinates object was created (array was converted)
                    assert len(coordinates_created) > 0

    def test_post_process_metric_with_nan_determinant(self):
        """Test _post_process_metric when determinant is NaN"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        coord_func.min_eig_val = 1e-6
        coord_func.target_match = mock.Mock(return_value=0.97)

        m = metric.Metric(psd, coord_func)

        # Create matrix that will project to a 2x2 with good properties after
        # time component projection but will have negative eigenvalues
        gamma = numpy.array(
            [
                [1.0, 0.0, 0.0],
                [0.0, -1.0, 0.0],
                [0.0, 0.0, 1.0],
            ]
        )

        # _post_process_metric no longer accepts jump_method parameter
        # and raises ValueError for negative eigenvalues
        with pytest.raises(ValueError, match="Cannot compute valid metric"):
            m._post_process_metric(gamma, numpy.array([1.0, 2.0]))

    def test_post_process_metric_nan_in_final_result(self):
        """Test _post_process_metric raises when final result has NaN"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        coord_func.min_eig_val = 1e-6

        m = metric.Metric(psd, coord_func)

        # Create a valid gamma that will produce NaN after processing
        gamma = numpy.array(
            [
                [1.0, 0.0, 0.0],
                [0.0, 1.0, 0.0],
                [0.0, 0.0, 1.0],
            ]
        )

        # Mock the dot product operations to produce NaN in final result
        with mock.patch("numpy.dot") as mock_dot:
            # Make the final numpy.dot in line 534 return NaN
            def dot_side_effect(*args):
                # Check if this is the final dot operation (Q * diag * Q.T)
                if len(args) == 2 and hasattr(args[1], "T"):
                    return numpy.array([[numpy.nan, 0.0], [0.0, 1.0]])
                # Otherwise return normal dot product
                return numpy.dot(*args)

            mock_dot.side_effect = dot_side_effect

            with pytest.raises(ValueError, match="nan metric"):
                m._post_process_metric(gamma, numpy.array([1.0, 2.0]))

    def test_solve_deltas_optimization(self):
        """Test solve_deltas internal optimization function"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)
        m.freq_vec = numpy.arange(100)

        # Mock waveform_shift
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(100, dtype=complex)
        m.waveform_shift = mock.Mock(return_value=mock_waveform)

        # We need to test the actual optimization function
        center = numpy.array([0.0, 1.0, 2.0])

        # Track calls to match_minus_1
        match_calls = []

        def mock_match(w1, w2, freq_vec):
            # Return different values based on the call
            match_calls.append((w1, w2))
            # Simulate that match improves as we get closer to target
            return -0.02 if len(match_calls) % 2 == 0 else -0.04

        with mock.patch("sgn_manifold.metric.match_minus_1", side_effect=mock_match):

            def mock_minimize(func, *args, **kwargs):
                # Call the function a few times to simulate optimization
                func(-2.0)  # Test value
                func(-1.5)  # Test value
                return mock.Mock(x=-2.0)

            with mock.patch(
                "scipy.optimize.minimize_scalar", side_effect=mock_minimize
            ):
                result = m.solve_deltas(center, 0.97)

                assert len(result) == 3
                assert all(d == 0.01 for d in result)  # 10^-2 = 0.01

    def test_waveform_shift_with_time_offset(self):
        """Test waveform_shift modifies waveform data correctly"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)
        m.freq_vec = numpy.arange(100)

        # Mock waveform
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        # Use a copy to verify it gets modified
        original_data = numpy.ones(100, dtype=complex)
        mock_waveform.data.data = original_data.copy()
        m.waveform = mock.Mock(return_value=mock_waveform)

        # Test with non-zero time shift (lines 610-611)
        c = numpy.array([0.5, 1.0, 2.0])
        result = m.waveform_shift(c)

        # Verify the data was modified with phase shift
        expected = original_data * numpy.exp(-2.0j * numpy.pi * m.freq_vec * 0.5)
        numpy.testing.assert_array_almost_equal(result.data.data, expected)

    def test_fft_match_at_coords_simple(self):
        """Test fft_match_at_coords calls correct methods"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        # Mock methods
        mock_waveform = mock.Mock()
        m.waveform = mock.Mock(return_value=mock_waveform)
        m.fft_match = mock.Mock(return_value=0.95)

        c1 = coordinate.Coordinates([1.0, 2.0])
        c2 = coordinate.Coordinates([1.1, 2.1])

        # Call the method (line 627)
        result = m.fft_match_at_coords(c1, c2)

        assert result == 0.95
        assert m.waveform.call_count == 2
        m.waveform.assert_any_call(c1)
        m.waveform.assert_any_call(c2)

    def test_fft_match_complex_computation(self):
        """Test fft_match performs correct computation"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        # Create mock waveforms with correct length
        w1 = mock.Mock()
        w1.data = mock.Mock()
        w1.data.data = numpy.ones(m.working_length, dtype=complex)

        w2 = mock.Mock()
        w2.data = mock.Mock()
        w2.data.data = numpy.ones(m.working_length, dtype=complex) * 0.9

        # Mock LAL FFT to set time series data
        def mock_fft(t_series, f_series, plan):
            # Simulate FFT result - set a reasonable max value
            t_series.data.data[0] = 10.0 + 0j
            for i in range(1, len(t_series.data.data)):
                t_series.data.data[i] = 1.0 + 0j

        with mock.patch("lal.COMPLEX16FreqTimeFFT", side_effect=mock_fft):
            with mock.patch("sgn_manifold.metric.norm_duration", return_value=10.0):
                result = m.fft_match(w1, w2)

                # Should compute match and check it's <= 1
                assert 0 < result <= 1.0

        # Test match > 1 error
        with mock.patch("lal.COMPLEX16FreqTimeFFT", side_effect=mock_fft):
            with mock.patch("sgn_manifold.metric.norm_duration", return_value=0.1):
                with pytest.raises(ValueError, match="Match is greater than 1"):
                    m.fft_match(w1, w2)

    def test_metric_match_computation(self):
        """Test metric_match computes exp(-d2)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        metric_tensor = numpy.eye(2)
        c1 = coordinate.Coordinates([1.0, 2.0])
        c2 = coordinate.Coordinates([1.1, 2.1])

        # Mock distance_sq
        m.distance_sq = mock.Mock(return_value=0.02)

        # Test line 676
        result = m.metric_match(metric_tensor, c1, c2)

        assert numpy.isclose(result, numpy.exp(-0.02))
        m.distance_sq.assert_called_once_with(metric_tensor, c1, c2)

    def test_random_point_at_mismatch_generator(self):
        """Test random_point_at_mismatch generator function"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        # Make coord_func return dict and support __contains__
        coord_func.side_effect = lambda x, inv=False: (
            numpy.array([1.5, 2.5]) if inv else {"valid": True}
        )
        coord_func.__contains__ = mock.Mock(return_value=True)

        m = metric.Metric(psd, coord_func)

        g = numpy.eye(2)
        center = coordinate.Coordinates([1.0, 2.0])
        mismatch = 0.03

        # Mock random to get predictable results
        with mock.patch("numpy.random.rand") as mock_rand:
            mock_rand.return_value = numpy.array([0.6, 0.8])

            # Test without invert (lines 699-700)
            gen = m.random_point_at_mismatch(g, center, mismatch, invert=False)
            result = next(gen)

            assert "valid" in result
            assert result["valid"] is True

            # Test with invert (lines 701-702)
            gen = m.random_point_at_mismatch(g, center, mismatch, invert=True)
            result = next(gen)

            assert isinstance(result, numpy.ndarray)
            assert result.shape == (2,)

    def test_match_minus_1_with_attribute_error(self):
        """Test match_minus_1 handling AttributeError"""
        # Create mock waveforms
        w1 = mock.Mock()
        w1.data = None  # This will cause AttributeError
        w1.epoch = mock.Mock()

        w2 = mock.Mock()
        w2.data = mock.Mock()
        w2.data.data = numpy.ones(10, dtype=complex)
        w2.epoch = mock.Mock()

        freq_vec = numpy.arange(10)

        # Test line 767
        result = match_minus_1(w1, w2, freq_vec)
        assert result == 0.0

    def test_match_minus_1_at_coords_w_t_full(self):
        """Test match_minus_1_at_coords_w_t function"""
        c1 = coordinate.Coordinates([1.0, 2.0])
        c2 = coordinate.Coordinates([1.1, 2.1])

        # Create mock metric
        g = mock.Mock()
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(10, dtype=complex)
        mock_waveform.epoch = mock.Mock()
        g.waveform = mock.Mock(return_value=mock_waveform)
        g.freq_vec = numpy.arange(10)

        with mock.patch("sgn_manifold.metric.match_minus_1", return_value=-0.03):
            # Test lines 777-780
            result = match_minus_1_at_coords_w_t(c1, c2, g, t1=0.0, t2=0.5)

            assert result == -0.03
            assert g.waveform.call_count == 2
            g.waveform.assert_any_call(c1)
            g.waveform.assert_any_call(c2)

    def test_t_factor_computation(self):
        """Test t_factor computes correct phase factors"""
        t_interval = 0.5
        freq_interval = 1.0
        freq_high = 10.0
        working_length = 5

        # Test lines 797-798
        result = metric.t_factor(t_interval, freq_interval, freq_high, working_length)

        assert result.shape == (5,)
        assert result.dtype == complex

        # Check specific values
        freq_range = numpy.arange(5) * 1.0 - 10.0  # [-10, -9, -8, -7, -6]
        expected = numpy.exp(-2j * numpy.pi * freq_range * 0.5)
        numpy.testing.assert_array_almost_equal(result, expected)

    def test_volume_element_computation(self):
        """Test volume_element computes sqrt(det)"""
        # Identity matrix
        metric_tensor = numpy.eye(2)
        result = metric.volume_element(metric_tensor)
        assert numpy.isclose(result, 1.0)

        # Scaled matrix (line 813)
        metric_tensor = numpy.array([[4.0, 0.0], [0.0, 9.0]])
        result = metric.volume_element(metric_tensor)
        assert numpy.isclose(result, 6.0)  # sqrt(36)
