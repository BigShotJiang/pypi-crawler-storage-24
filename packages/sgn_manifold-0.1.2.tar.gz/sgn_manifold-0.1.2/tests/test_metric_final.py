"""Final tests to achieve 100% coverage for metric.py"""

from unittest import mock

import numpy
import pytest
from lal import LIGOTimeGPS

from sgn_manifold import coordinate, metric
from sgn_manifold.metric import max_diff_at_edges


class TestFinalCoverage:
    """Tests for remaining uncovered lines"""

    def test_normalize_waveform_params_type_in_dict(self):
        """Test _normalize_waveform_params when type already in dict"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        # Create mock coordinate types
        MockType1 = type("MockType1", (), {"key": "param1"})
        MockType2 = type("MockType2", (), {"key": "param2"})

        m.WAVEFORM_COORDS = (MockType1, MockType2)
        m.WAVEFORM_COORD_DEFAULTS = {}

        # Test when type is in dict but not in defaults (line 227->226)
        d = {MockType1: 3.0, "other": 4.0}
        result = m._normalize_waveform_params(d)
        assert result == {"param1": 3.0, "other": 4.0}

    def test_evaluate_array_conversion(self):
        """Test evaluate converts array to Coordinates"""
        # Create real PSD
        import lal
        from lal import LIGOTimeGPS

        psd = lal.CreateREAL8FrequencySeries(
            name="psd",
            epoch=LIGOTimeGPS(0),
            f0=0.0,
            deltaF=1.0,
            sampleUnits=lal.HertzUnit,
            length=100,
        )
        psd.data.data[:] = 1.0

        coord_func = mock.Mock()
        coord_func.target_match = mock.Mock(return_value=0.97)
        coord_func.min_eig_val = 1e-6
        coord_func.base_step = mock.Mock(return_value=numpy.array([1e-4, 1e-4]))

        m = metric.Metric(psd, coord_func)

        # Mock waveform method to avoid NotImplementedError
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(m.working_length, dtype=complex)
        m.waveform = mock.Mock(return_value=mock_waveform)

        # Mock waveform_shift to avoid the waveform call
        m.waveform_shift = mock.Mock(return_value=mock_waveform)

        # Track calls to coordinate conversion
        coordinates_created = []
        original_init = coordinate.Coordinates.__init__

        def track_coordinates_init(self, *args, **kwargs):
            coordinates_created.append(self)
            return original_init(self, *args, **kwargs)

        # Mock internal methods to avoid NotImplementedError
        with mock.patch.object(m, "_evaluate_deterministic", return_value=numpy.eye(3)):
            with mock.patch.object(
                m, "_post_process_metric", return_value=numpy.eye(2)
            ):
                with mock.patch.object(
                    coordinate.Coordinates, "__init__", track_coordinates_init
                ):
                    # Test with array input (lines 325-327)
                    center = numpy.array([1.0, 2.0])
                    m.evaluate(center, method="deterministic")

                    # Verify conversion happened
                    assert len(coordinates_created) > 0
                    assert isinstance(coordinates_created[0], coordinate.Coordinates)

    def test_evaluate_already_coordinates(self):
        """Test evaluate with Coordinates input (line 312->316)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        coord_func.target_match = mock.Mock(return_value=0.97)
        coord_func.min_eig_val = 1e-6
        coord_func.base_step = mock.Mock(return_value=numpy.array([1e-4, 1e-4]))

        m = metric.Metric(psd, coord_func)

        # Mock waveform to prevent errors
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(m.working_length, dtype=complex)
        m.waveform = mock.Mock(return_value=mock_waveform)

        # Mock internal methods
        m._evaluate_deterministic = mock.Mock(return_value=numpy.eye(3))
        m._post_process_metric = mock.Mock(return_value=numpy.eye(2))

        # Test with Coordinates input
        center = coordinate.Coordinates([1.0, 2.0])
        result = m.evaluate(center, method="deterministic", target_match=0.95)

        assert result.shape == (2, 2)
        # Should use provided target_match, not from coord_func
        assert coord_func.target_match.call_count == 0

    def test_post_process_metric_positive_eigenvalues(self):
        """Test _post_process_metric when all eigenvalues are positive"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        coord_func.min_eig_val = 1e-6

        m = metric.Metric(psd, coord_func)

        # Create matrix with positive eigenvalues
        gamma = numpy.array(
            [
                [2.0, 0.5, 0.0],
                [0.5, 2.0, 0.0],
                [0.0, 0.0, 1.0],
            ]
        )

        result = m._post_process_metric(gamma, numpy.array([1.0, 2.0]))

        # Should process normally without jumping
        assert result.shape == (2, 2)
        # Check eigenvalues are positive
        eigvals = numpy.linalg.eigvals(result)
        assert numpy.all(eigvals > 0)

    def test_post_process_metric_nan_final(self):
        """Test _post_process_metric when final result has NaN (line 537)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        coord_func.min_eig_val = 1e-6

        m = metric.Metric(psd, coord_func)

        # Good gamma matrix
        gamma = numpy.array(
            [
                [2.0, 0.0, 0.0],
                [0.0, 2.0, 0.0],
                [0.0, 0.0, 1.0],
            ]
        )

        # Mock the final computation to produce NaN
        # We need to patch at the right level
        original_dot = numpy.dot

        def mock_dot(*args, **kwargs):
            result = original_dot(*args, **kwargs)
            # Check if this is the final computation (result should be 2x2)
            if hasattr(result, "shape") and result.shape == (2, 2):
                result[0, 0] = numpy.nan
            return result

        with mock.patch.object(numpy, "dot", side_effect=mock_dot):
            with pytest.raises(ValueError, match="nan metric"):
                m._post_process_metric(gamma, numpy.array([1.0, 2.0]))

    def test_solve_deltas_internal_match_function(self):
        """Test solve_deltas internal match function behavior (lines 595-597)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)
        m.freq_vec = numpy.arange(100)

        # Mock waveform_shift
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(100, dtype=complex)
        m.waveform_shift = mock.Mock(return_value=mock_waveform)

        # We'll capture the optimization function
        opt_func = None

        def capture_minimize(func, *args, **kwargs):
            nonlocal opt_func
            opt_func = func
            # Call it to ensure coverage
            func(-3.0)  # 10^-3 = 0.001
            func(-1.0)  # 10^-1 = 0.1
            return mock.Mock(x=-2.0)

        with mock.patch("sgn_manifold.metric.match_minus_1", return_value=-0.02):
            with mock.patch(
                "scipy.optimize.minimize_scalar", side_effect=capture_minimize
            ):
                center = numpy.array([0.0, 1.0, 2.0])
                result = m.solve_deltas(center, 0.97)

                assert opt_func is not None
                assert len(result) == 3

    def test_waveform_shift_zero_time(self):
        """Test waveform_shift with zero time offset (lines 608-609)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        # Mock waveform with correct length
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(m.working_length, dtype=complex)
        m.waveform = mock.Mock(return_value=mock_waveform)

        # Test with zero time
        c = numpy.array([0.0, 1.0, 2.0])
        result = m.waveform_shift(c)

        assert result == mock_waveform
        # Data should not be modified
        numpy.testing.assert_array_equal(
            mock_waveform.data.data, numpy.ones(m.working_length, dtype=complex)
        )

    def test_waveform_shift_nonzero_time(self):
        """Test waveform_shift with non-zero time offset (lines 610-611)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        # Mock waveform with correct length
        mock_waveform = mock.Mock()
        mock_waveform.data = mock.Mock()
        mock_waveform.data.data = numpy.ones(m.working_length, dtype=complex)
        m.waveform = mock.Mock(return_value=mock_waveform)

        # Test with non-zero time
        c = numpy.array([0.25, 1.0, 2.0])
        m.waveform_shift(c)

        # Check phase shift was applied
        expected = numpy.ones(m.working_length) * numpy.exp(
            -2.0j * numpy.pi * m.freq_vec * 0.25
        )
        numpy.testing.assert_array_almost_equal(mock_waveform.data.data, expected)

    def test_fft_match_at_coords(self):
        """Test fft_match_at_coords (line 627)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        mock_waveform1 = mock.Mock()
        mock_waveform2 = mock.Mock()
        m.waveform = mock.Mock(side_effect=[mock_waveform1, mock_waveform2])
        m.fft_match = mock.Mock(return_value=0.98)

        c1 = coordinate.Coordinates([1.0, 2.0])
        c2 = coordinate.Coordinates([1.1, 2.1])

        result = m.fft_match_at_coords(c1, c2)

        assert result == 0.98
        m.fft_match.assert_called_once_with(mock_waveform1, mock_waveform2)

    def test_fft_match_computation(self):
        """Test fft_match internal computation (lines 643-654)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        # Initialize series with correct length
        m.f_series.data.data = numpy.zeros(m.working_length, dtype=complex)
        m.t_series.data.data = numpy.zeros(m.working_length, dtype=complex)

        # Create waveforms with correct length
        w1 = mock.Mock()
        w1.data = mock.Mock()
        w1.data.data = numpy.ones(m.working_length, dtype=complex)
        w1.data.data[0] = 1 + 1j
        w1.data.data[1] = 2 + 0j
        w1.data.data[2] = 0 + 1j

        w2 = mock.Mock()
        w2.data = mock.Mock()
        w2.data.data = numpy.ones(m.working_length, dtype=complex) * 0.5
        w2.data.data[0] = 1 + 0j
        w2.data.data[1] = 0 + 2j
        w2.data.data[2] = 1 + 1j

        def mock_fft(t_series, f_series, plan):
            # Simulate FFT setting max value
            t_series.data.data[:] = 0
            t_series.data.data[0] = 5.0 + 0j  # Max value

        with mock.patch("lal.COMPLEX16FreqTimeFFT", side_effect=mock_fft):
            result = m.fft_match(w1, w2)

            # Check that f_series was set correctly (line 643)
            expected_f = numpy.conj(w1.data.data) * w2.data.data
            numpy.testing.assert_array_almost_equal(m.f_series.data.data, expected_f)

            assert 0 < result <= 1.0

    def test_fft_match_greater_than_one(self):
        """Test fft_match when match > 1 (lines 652-653)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        w1 = mock.Mock()
        w1.data = mock.Mock()
        w1.data.data = numpy.ones(m.working_length, dtype=complex)

        w2 = mock.Mock()
        w2.data = mock.Mock()
        w2.data.data = numpy.ones(m.working_length, dtype=complex)

        def mock_fft(t_series, f_series, plan):
            t_series.data.data[:] = 0
            t_series.data.data[0] = 100.0 + 0j  # Very large

        with mock.patch("lal.COMPLEX16FreqTimeFFT", side_effect=mock_fft):
            with mock.patch("sgn_manifold.metric.norm_duration", return_value=0.1):
                with pytest.raises(ValueError, match="Match is greater than 1"):
                    m.fft_match(w1, w2)

    def test_metric_match(self):
        """Test metric_match computation (lines 675-676)"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        metric_tensor = numpy.eye(2)
        c1 = coordinate.Coordinates([1.0, 2.0])
        c2 = coordinate.Coordinates([1.1, 2.1])

        # Mock distance_sq to return specific value
        m.distance_sq = mock.Mock(return_value=0.05)

        result = m.metric_match(metric_tensor, c1, c2)

        assert numpy.isclose(result, numpy.exp(-0.05))

    def test_random_point_at_mismatch_all_paths(self):
        """Test random_point_at_mismatch generator all code paths"""
        psd = mock.Mock()
        psd.data = mock.Mock()
        psd.data.length = 100
        psd.data.data = numpy.ones(100)
        psd.deltaF = 1.0
        psd.f0 = 0.0

        coord_func = mock.Mock()
        m = metric.Metric(psd, coord_func)

        # Test LinAlgError path (lines 689-691)
        g_bad = numpy.array([[1.0, 2.0], [2.0, 1.0]])  # Not positive definite
        center = coordinate.Coordinates([1.0, 2.0])

        gen = m.random_point_at_mismatch(g_bad, center, 0.03)
        with pytest.raises(numpy.linalg.LinAlgError):
            next(gen)

        # Test successful path with dict result and invert=False (lines 698-700)
        g = numpy.eye(2)
        coord_func.side_effect = [{"result": "dict"}]
        coord_func.__contains__ = mock.Mock(return_value=True)

        with mock.patch("numpy.random.rand", return_value=numpy.array([0.5, 0.5])):
            gen = m.random_point_at_mismatch(g, center, 0.03, invert=False)
            result = next(gen)
            assert result == {"result": "dict"}

        # Test with invert=True (lines 701-702)
        coord_func.side_effect = [
            {"result": "dict"},  # First call
            numpy.array([1.5, 2.5]),  # Second call with inv=True
        ]

        with mock.patch("numpy.random.rand", return_value=numpy.array([0.5, 0.5])):
            gen = m.random_point_at_mismatch(g, center, 0.03, invert=True)
            result = next(gen)
            numpy.testing.assert_array_equal(result, numpy.array([1.5, 2.5]))

    def test_max_diff_at_edges_function(self):
        """Test max_diff_at_edges function (lines 819-838)"""
        # Create mock metric
        g = mock.Mock()
        g.fft_match_at_coords = mock.Mock(side_effect=[0.97, 0.96, 0.97, 0.96])
        g.metric_match = mock.Mock(side_effect=[0.98, 0.97, 0.98, 0.97])

        center = coordinate.Coordinates([1.0, 2.0])
        m = numpy.eye(2)
        target_match = 0.97

        result = max_diff_at_edges(g, center, m, target_match)

        # Should call both methods 4 times each
        assert g.fft_match_at_coords.call_count == 4
        assert g.metric_match.call_count == 4

        # Check the calculation
        # fft_mm = 1 - 0.97 = 0.03, metric_mm = 1 - 0.98 = 0.02
        # diff = (0.02 - 0.03) / 0.02 = -0.5
        # max(abs(diffs)) should be 0.5
        assert numpy.isclose(result, 0.5, atol=0.1)

    def test_norm_duration(self):
        """Test norm_duration function (line 719)"""
        w = numpy.array([1 + 1j, 2 + 0j, 0 + 2j])
        duration = 2

        result = metric.norm_duration(w, duration)

        # |w|^2 = 2 + 4 + 4 = 10
        # sqrt(10 / 2) = sqrt(5)
        assert numpy.isclose(result, numpy.sqrt(5))

    def test_norm(self):
        """Test norm function (lines 733-734)"""
        w = numpy.array([3 + 4j, 0 + 0j])

        result = metric.norm(w)

        # |3+4j|^2 = 25, |0|^2 = 0
        # sqrt(25) = 5
        assert result == 5.0

    def test_dot_function(self):
        """Test dot function (line 739)"""
        x = numpy.array([1.0, 2.0])
        y = numpy.array([3.0, 4.0])
        metric_tensor = numpy.array([[2.0, 0.0], [0.0, 3.0]])

        result = metric.dot(x, y, metric_tensor)

        # x^T * M * y = [1, 2] * [[2, 0], [0, 3]] * [[3], [4]]
        #             = [1, 2] * [[6], [12]] = 6 + 24 = 30
        assert result == 30.0

    def test_inner_product(self):
        """Test inner_product function (line 743)"""
        w1 = numpy.array([1 + 2j, 3 + 4j])
        w2 = numpy.array([5 + 6j, 7 + 8j])

        result = metric.inner_product(w1, w2)

        # conj(w1) * w2 = (1-2j)*(5+6j) + (3-4j)*(7+8j)
        #               = (5+12+6j-10j) + (21+32+24j-28j)
        #               = (17-4j) + (53-4j) = 70-8j
        # |70-8j| = sqrt(70^2 + 8^2) = sqrt(4900 + 64) = sqrt(4964)
        assert numpy.isclose(result, numpy.sqrt(4964))

    def test_match_minus_1_all_paths(self):
        """Test match_minus_1 all code paths (lines 752-767)"""
        # Create waveforms
        w1 = mock.Mock()
        w1.data = mock.Mock()
        w1.data.data = numpy.array([1 + 0j, 0 + 1j])
        w1.epoch = LIGOTimeGPS(100)

        w2 = mock.Mock()
        w2.data = mock.Mock()
        w2.data.data = numpy.array([1 + 0j, 0 + 1j])
        w2.epoch = LIGOTimeGPS(100)

        freq_vec = numpy.array([0.0, 1.0])

        # Test with same epoch and no dt
        result = metric.match_minus_1(w1, w2, freq_vec)
        assert numpy.isclose(result, 0.0)  # Perfect match

        # Test with different epochs (line 756)
        w2.epoch = LIGOTimeGPS(101)
        result = metric.match_minus_1(w1, w2, freq_vec)
        assert result != 0.0

        # Test with dt parameter
        result = metric.match_minus_1(w1, w2, freq_vec, dt=0.5)
        assert result != 0.0

        # Test AttributeError path (line 767)
        w1.data = None
        result = metric.match_minus_1(w1, w2, freq_vec)
        assert result == 0.0

    def test_match_minus_1_at_coords_w_t(self):
        """Test match_minus_1_at_coords_w_t (lines 777-780)"""
        c1 = coordinate.Coordinates([1.0, 2.0])
        c2 = coordinate.Coordinates([1.1, 2.1])

        g = mock.Mock()
        mock_w = mock.Mock()
        mock_w.data = mock.Mock()
        mock_w.data.data = numpy.ones(10, dtype=complex)
        mock_w.epoch = LIGOTimeGPS(0)
        g.waveform = mock.Mock(return_value=mock_w)
        g.freq_vec = numpy.arange(10)

        with mock.patch(
            "sgn_manifold.metric.match_minus_1", return_value=-0.05
        ) as mock_match:
            result = metric.match_minus_1_at_coords_w_t(c1, c2, g, t1=1.0, t2=1.5)

            assert result == -0.05
            # Check dt was calculated correctly
            mock_match.assert_called_once()
            call_args = mock_match.call_args
            # dt is passed as the 4th positional argument
            assert len(call_args[0]) == 4
            assert call_args[0][3] == 0.5  # t2 - t1

    def test_t_factor(self):
        """Test t_factor computation (lines 797-798)"""
        result = metric.t_factor(0.25, 2.0, 20.0, 5)

        assert result.shape == (5,)
        # freq_range = [0, 2, 4, 6, 8] - 20 = [-20, -18, -16, -14, -12]
        freq_range = numpy.arange(5) * 2.0 - 20.0
        expected = numpy.exp(-2j * numpy.pi * freq_range * 0.25)
        numpy.testing.assert_array_almost_equal(result, expected)

    def test_volume_element(self):
        """Test volume_element (line 813)"""
        # Test with 3x3 matrix
        metric_tensor = numpy.array(
            [[4.0, 0.0, 0.0], [0.0, 9.0, 0.0], [0.0, 0.0, 16.0]]
        )

        result = metric.volume_element(metric_tensor)
        # det = 4 * 9 * 16 = 576
        # sqrt(576) = 24
        assert numpy.isclose(result, 24.0)
