"""Comprehensive tests for coordinate module to achieve 100% coverage"""

from __future__ import annotations

from typing import Union

import numpy as np
import pytest

from sgn_manifold import coordinate


# Test coordinate types
class Mass1(coordinate.CoordinateType):
    key = "m1"


class Mass2(coordinate.CoordinateType):
    key = "m2"


class LogMass1(coordinate.CoordinateType):
    key = "log10m1"


class LogMass2(coordinate.CoordinateType):
    key = "log10m2"


class Spin(coordinate.CoordinateType):
    key = "spin"


# Test coordinate function
class MassCoordFunc(coordinate.CoordFunc):
    _STANDARD_COORD_TYPES = (Mass1, Mass2, LogMass1, LogMass2)
    TO_TYPES = (Mass1, Mass2)
    FROM_TYPES = (LogMass1, LogMass2)

    def __call__(
        self,
        c: Union[coordinate.Coordinates, coordinate.CoordsDict, np.ndarray],
        inv: bool = False,
    ):
        if inv:
            # Mass to LogMass (TO -> FROM)
            c_dict = self._normalize_coorddict(c, inv=True)
            log10m1 = np.log10(c_dict[Mass1])
            log10m2 = np.log10(c_dict[Mass2])
            return np.array([log10m1, log10m2])
        else:
            # LogMass to Mass (FROM -> TO)
            if isinstance(c, dict):
                c = self._normalize_coorddict(c)
                m1 = 10 ** c[LogMass1]
                m2 = 10 ** c[LogMass2]
            else:
                c_array = coordinate.to_array(c)
                m1 = 10 ** c_array[0]
                m2 = 10 ** c_array[1]
            return {Mass1: float(m1), Mass2: float(m2)}

    def dx(self, c: coordinate.Coordinates):
        return np.array([0.01, 0.01])

    def base_step(self, center):
        return 0.01

    def target_match(self, center):
        return 0.97

    @property
    def min_eig_val(self):
        return 1e-6

    def min_scale(self, coords):
        return 0.001

    def random(self):
        log10m1 = np.random.uniform(
            self.from_bounds[LogMass1][0], self.from_bounds[LogMass1][1]
        )
        log10m2 = np.random.uniform(
            self.from_bounds[LogMass2][0], self.from_bounds[LogMass2][1]
        )
        return {LogMass1: log10m1, LogMass2: log10m2}


class TestCoordinateType:
    """Test CoordinateType class"""

    def test_is_coord_type(self):
        """Test is_coord_type function"""
        assert coordinate.is_coord_type(Mass1)
        assert coordinate.is_coord_type(Mass2)
        assert not coordinate.is_coord_type("not a type")
        assert not coordinate.is_coord_type(42)
        assert not coordinate.is_coord_type(Mass1())  # instance, not type


class TestCoordinates:
    """Test Coordinates class"""

    def test_init_from_scalars(self):
        """Test creating Coordinates from scalar arguments"""
        coords = coordinate.Coordinates(1.0, 2.0, 3.0)
        assert len(coords) == 3
        assert coords[0] == 1.0
        assert coords[1] == 2.0
        assert coords[2] == 3.0

    def test_init_from_list(self):
        """Test creating Coordinates from a list"""
        coords = coordinate.Coordinates([1.0, 2.0, 3.0])
        assert len(coords) == 3
        assert coords[0] == 1.0
        assert coords[1] == 2.0
        assert coords[2] == 3.0

    def test_init_from_ndarray(self):
        """Test creating Coordinates from numpy array"""
        arr = np.array([1.0, 2.0, 3.0])
        coords = coordinate.Coordinates(arr)
        assert len(coords) == 3
        assert coords[0] == 1.0
        assert coords[1] == 2.0
        assert coords[2] == 3.0

    def test_init_with_coord_types(self):
        """Test creating Coordinates with coord_types"""
        coords = coordinate.Coordinates(10.0, 20.0, coord_types=[Mass1, Mass2])
        assert coords._types == [Mass1, Mass2]

    def test_init_invalid_scalars(self):
        """Test error when creating Coordinates from non-numeric scalars"""
        with pytest.raises(TypeError, match="All arguments must be numeric"):
            coordinate.Coordinates(1.0, "not a number", 3.0)

    def test_init_no_args(self):
        """Test error when creating Coordinates with no arguments"""
        with pytest.raises(ValueError, match="At least one coordinate value required"):
            coordinate.Coordinates()

    def test_init_single_scalar_first_arg(self):
        """Test creating Coordinates with single scalar as first argument"""
        coords = coordinate.Coordinates(42.0)
        assert len(coords) == 1
        assert coords[0] == 42.0

    def test_init_dimension_mismatch(self):
        """Test error when coord_types dimension doesn't match coordinates"""
        with pytest.raises(ValueError, match="Coordinate dimension .* doesn't match"):
            coordinate.Coordinates(1.0, 2.0, coord_types=[Mass1])  # 2 coords, 1 type

    def test_add_coordinates(self):
        """Test adding two Coordinates objects"""
        coords1 = coordinate.Coordinates(1.0, 2.0)
        coords2 = coordinate.Coordinates(3.0, 4.0)
        result = coords1 + coords2
        assert result[0] == 4.0
        assert result[1] == 6.0

    def test_add_coordinates_with_types(self):
        """Test adding two Coordinates objects with matching types"""
        coords1 = coordinate.Coordinates(1.0, 2.0, coord_types=[Mass1, Mass2])
        coords2 = coordinate.Coordinates(3.0, 4.0, coord_types=[Mass1, Mass2])
        result = coords1 + coords2
        assert result[0] == 4.0
        assert result[1] == 6.0
        assert result._types == [Mass1, Mass2]

    def test_add_coordinates_mismatched_types(self):
        """Test error when adding Coordinates with mismatched types"""
        coords1 = coordinate.Coordinates(1.0, 2.0, coord_types=[Mass1, Mass2])
        coords2 = coordinate.Coordinates(3.0, 4.0, coord_types=[LogMass1, LogMass2])
        with pytest.raises(ValueError, match="Incompatible coordinate types"):
            coords1 + coords2

    def test_add_coordinates_to_list(self):
        """Test adding a list to Coordinates"""
        coords = coordinate.Coordinates(1.0, 2.0)
        result = coords + [3.0, 4.0]
        assert result[0] == 4.0
        assert result[1] == 6.0

    def test_add_invalid_type(self):
        """Test error when adding invalid type to Coordinates"""
        coords = coordinate.Coordinates(1.0, 2.0)
        # Adding a string creates a 0-d string array, which causes UFuncTypeError
        with pytest.raises((TypeError, np.core._exceptions._UFuncNoLoopError)):
            coords + "invalid"

    def test_add_type_error(self):
        """Test TypeError in __add__ method exception handling"""
        coords = coordinate.Coordinates(1.0, 2.0)

        # Use an object that will raise an exception in to_coordinates
        class BadType:
            pass

        with pytest.raises(TypeError, match="Cannot add Coordinates to"):
            coords + BadType()

    def test_iter(self):
        """Test iterating over Coordinates"""
        coords = coordinate.Coordinates(1.0, 2.0, 3.0)
        values = list(coords)
        assert values == [1.0, 2.0, 3.0]

    def test_len(self):
        """Test len of Coordinates"""
        coords = coordinate.Coordinates(1.0, 2.0, 3.0)
        assert len(coords) == 3

    def test_shape(self):
        """Test shape property"""
        coords = coordinate.Coordinates(1.0, 2.0, 3.0)
        assert coords.shape == (3,)

    def test_repr_without_types(self):
        """Test string representation without types"""
        coords = coordinate.Coordinates(1.0, 2.0)
        assert repr(coords) == "Coordinate(1.0, 2.0)"

    def test_repr_with_types(self):
        """Test string representation with types"""
        coords = coordinate.Coordinates(10.0, 20.0, coord_types=[Mass1, Mass2])
        assert repr(coords) == "Coordinate(m1=10.0, m2=20.0)"

    def test_compatible_types_both_none(self):
        """Test _compatible_types when both have None types"""
        coords1 = coordinate.Coordinates(1.0, 2.0)
        coords2 = coordinate.Coordinates(3.0, 4.0)
        assert coords1._compatible_types(coords2)

    def test_compatible_types_non_coordinates(self):
        """Test _compatible_types with non-Coordinates object"""
        coords = coordinate.Coordinates(1.0, 2.0)
        assert not coords._compatible_types([1.0, 2.0])

    def test_sub_coordinates(self):
        """Test subtracting two Coordinates objects"""
        coords1 = coordinate.Coordinates(5.0, 6.0)
        coords2 = coordinate.Coordinates(2.0, 3.0)
        result = coords1 - coords2
        assert result[0] == 3.0
        assert result[1] == 3.0

    def test_sub_coordinates_with_types(self):
        """Test subtracting two Coordinates objects with matching types"""
        coords1 = coordinate.Coordinates(5.0, 6.0, coord_types=[Mass1, Mass2])
        coords2 = coordinate.Coordinates(2.0, 3.0, coord_types=[Mass1, Mass2])
        result = coords1 - coords2
        assert result[0] == 3.0
        assert result[1] == 3.0
        assert result._types == [Mass1, Mass2]

    def test_sub_coordinates_mismatched_types(self):
        """Test error when subtracting Coordinates with mismatched types"""
        coords1 = coordinate.Coordinates(5.0, 6.0, coord_types=[Mass1, Mass2])
        coords2 = coordinate.Coordinates(2.0, 3.0, coord_types=[LogMass1, LogMass2])
        with pytest.raises(ValueError, match="Incompatible coordinate types"):
            coords1 - coords2

    def test_sub_coordinates_to_list(self):
        """Test subtracting a list from Coordinates"""
        coords = coordinate.Coordinates(5.0, 6.0)
        result = coords - [2.0, 3.0]
        assert result[0] == 3.0
        assert result[1] == 3.0

    def test_sub_type_error(self):
        """Test TypeError in __sub__ method exception handling"""
        coords = coordinate.Coordinates(5.0, 6.0)

        # Use an object that will raise an exception in to_coordinates
        class BadType:
            pass

        with pytest.raises(TypeError, match="Cannot subtract .* from Coordinates"):
            coords - BadType()

    def test_eq_coordinates(self):
        """Test equality comparison of Coordinates"""
        coords1 = coordinate.Coordinates(1.0, 2.0)
        coords2 = coordinate.Coordinates(1.0, 2.0)
        coords3 = coordinate.Coordinates(1.0, 3.0)

        assert coords1 == coords2
        assert not coords1 == coords3

    def test_eq_coordinates_with_types(self):
        """Test equality comparison with coordinate types"""
        coords1 = coordinate.Coordinates(1.0, 2.0, coord_types=[Mass1, Mass2])
        coords2 = coordinate.Coordinates(1.0, 2.0, coord_types=[Mass1, Mass2])
        coords3 = coordinate.Coordinates(1.0, 2.0, coord_types=[LogMass1, LogMass2])

        assert coords1 == coords2
        assert not coords1 == coords3

    def test_eq_type_error(self):
        """Test equality with non-Coordinates type"""
        coords = coordinate.Coordinates(1.0, 2.0)
        assert not coords == "invalid"
        assert not coords == 42

    def test_to_dict_with_types(self):
        """Test to_dict with coordinate types"""
        coords = coordinate.Coordinates(10.0, 20.0, coord_types=[Mass1, Mass2])
        result = coords.to_dict()
        expected = {Mass1: 10.0, Mass2: 20.0}
        assert result == expected

    def test_to_dict_without_types(self):
        """Test to_dict when coordinate types are not defined"""
        coords = coordinate.Coordinates(1.0, 2.0)
        with pytest.raises(ValueError, match="Cannot convert untyped coordinates"):
            coords.to_dict()

    def test_to_array(self):
        """Test to_array method"""
        coords = coordinate.Coordinates(1.0, 2.0, 3.0)
        result = coords.to_array()
        expected = np.array([1.0, 2.0, 3.0])
        np.testing.assert_array_equal(result, expected)
        # Ensure it's a copy, not the same object
        assert result is not coords._array


class TestCoordinateConversion:
    """Test coordinate conversion functions"""

    def test_to_coordinates_from_coordinates(self):
        """Test to_coordinates with Coordinates input"""
        coords = coordinate.Coordinates(1.0, 2.0)
        result = coordinate.to_coordinates(coords)
        assert result is coords

    def test_to_coordinates_from_list(self):
        """Test to_coordinates with list input"""
        result = coordinate.to_coordinates([1.0, 2.0])
        assert isinstance(result, coordinate.Coordinates)
        assert result[0] == 1.0
        assert result[1] == 2.0

    def test_to_coordinates_from_ndarray(self):
        """Test to_coordinates with numpy array input"""
        arr = np.array([1.0, 2.0])
        result = coordinate.to_coordinates(arr)
        assert isinstance(result, coordinate.Coordinates)
        assert result[0] == 1.0
        assert result[1] == 2.0

    def test_to_coordinates_invalid(self):
        """Test to_coordinates with invalid input"""

        # Test with a type that cannot be converted to Coordinates
        class InvalidType:
            pass

        with pytest.raises(ValueError, match="Unable to coerce"):
            coordinate.to_coordinates(InvalidType())

    def test_to_array_from_ndarray(self):
        """Test to_array with numpy array input"""
        arr = np.array([1.0, 2.0])
        result = coordinate.to_array(arr)
        assert result is arr

    def test_to_array_from_coordinates(self):
        """Test to_array with Coordinates input"""
        coords = coordinate.Coordinates(1.0, 2.0)
        result = coordinate.to_array(coords)
        np.testing.assert_array_equal(result, np.array([1.0, 2.0]))

    def test_to_array_from_list(self):
        """Test to_array with list input"""
        result = coordinate.to_array([1.0, 2.0])
        np.testing.assert_array_equal(result, np.array([1.0, 2.0]))


class TestCoordFunc:
    """Test CoordFunc class"""

    def test_init_with_to_bounds(self):
        """Test initialization with TO_TYPES bounds"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        assert cf.to_bounds == {Mass1: (1.0, 100.0), Mass2: (1.0, 100.0)}
        assert cf.from_bounds is not None

    def test_init_with_from_bounds(self):
        """Test initialization with FROM_TYPES bounds"""
        cf = MassCoordFunc(log10m1=(0.0, 2.0), log10m2=(0.0, 2.0))
        assert cf.from_bounds == {LogMass1: (0.0, 2.0), LogMass2: (0.0, 2.0)}
        assert cf.to_bounds is not None

    def test_init_with_string_keys(self):
        """Test initialization with string keys instead of types"""
        cf = MassCoordFunc(**{"m1": (1.0, 100.0), "m2": (1.0, 100.0)})
        assert cf.to_bounds == {Mass1: (1.0, 100.0), Mass2: (1.0, 100.0)}

    def test_init_invalid_bounds(self):
        """Test error with invalid bounds"""
        with pytest.raises(
            ValueError, match="Can only normalize dicts whose keys are subsets"
        ):
            MassCoordFunc(spin=(0.0, 1.0))

    def test_to_dict(self):
        """Test to_dict method"""
        kwargs = {"m1": (1.0, 100.0), "m2": (1.0, 100.0)}
        cf = MassCoordFunc(**kwargs)
        assert cf.to_dict() == kwargs

    def test_contains_valid_to_coords(self):
        """Test __contains__ with valid TO coordinates"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        assert {Mass1: 10.0, Mass2: 20.0} in cf
        assert {Mass1: 1.0, Mass2: 100.0} in cf

    def test_contains_valid_from_coords(self):
        """Test __contains__ with valid FROM coordinates"""
        cf = MassCoordFunc(log10m1=(0.0, 2.0), log10m2=(0.0, 2.0))
        assert {LogMass1: 1.0, LogMass2: 1.5} in cf

    def test_contains_invalid_coords(self):
        """Test __contains__ with out-of-bounds coordinates"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        assert {Mass1: 0.5, Mass2: 20.0} not in cf
        assert {Mass1: 10.0, Mass2: 200.0} not in cf

    def test_contains_none(self):
        """Test __contains__ with None"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        assert None not in cf

    def test_contains_nan(self):
        """Test __contains__ with NaN values"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        assert {Mass1: np.nan, Mass2: 20.0} not in cf

    def test_contains_inf(self):
        """Test __contains__ with infinite values"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        assert {Mass1: np.inf, Mass2: 20.0} not in cf

    def test_contains_wrong_keys(self):
        """Test __contains__ with wrong coordinate keys"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        with pytest.raises(ValueError, match="Cannot determine"):
            _ = {Spin: 0.5} in cf

    def test_contains_no_bounds(self):
        """Test __contains__ when bounds are not set"""

        # Create a minimal CoordFunc without bounds
        class NoBoundsFunc(coordinate.CoordFunc):
            TO_TYPES = ()
            FROM_TYPES = ()

            def __init__(self):
                self.from_bounds = None
                self.to_bounds = None
                self.mins = []
                self.maxes = []

            def __call__(self, c, inv=False):
                return c

        cf = NoBoundsFunc()
        assert {Mass1: 10.0} in cf  # Should return True when no bounds

    def test_normalize_coorddict_from_types(self):
        """Test _normalize_coorddict with FROM_TYPES"""
        cf = MassCoordFunc(log10m1=(0.0, 2.0), log10m2=(0.0, 2.0))
        result = cf._normalize_coorddict({"log10m1": 1.0, "log10m2": 1.5})
        assert result == {LogMass1: 1.0, LogMass2: 1.5}

    def test_normalize_coorddict_to_types(self):
        """Test _normalize_coorddict with TO_TYPES"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        result = cf._normalize_coorddict({"m1": 10.0, "m2": 20.0})
        assert result == {Mass1: 10.0, Mass2: 20.0}

    def test_normalize_coorddict_with_type_keys(self):
        """Test _normalize_coorddict when dict already has type keys"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        result = cf._normalize_coorddict({Mass1: 10.0, Mass2: 20.0})
        assert result == {Mass1: 10.0, Mass2: 20.0}

    def test_normalize_coorddict_invalid_keys(self):
        """Test _normalize_coorddict with invalid keys"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        with pytest.raises(ValueError, match="Can only normalize"):
            cf._normalize_coorddict({"invalid_key": 1.0})

    def test_normalize_coorddict_inv(self):
        """Test _normalize_coorddict with inv=True"""
        cf = MassCoordFunc(m1=(1.0, 100.0), m2=(1.0, 100.0))
        result = cf._normalize_coorddict({"m1": 10.0, "m2": 20.0}, inv=True)
        assert result == {Mass1: 10.0, Mass2: 20.0}

    def test_grid(self):
        """Test grid generation"""
        cf = MassCoordFunc(log10m1=(0.0, 1.0), log10m2=(0.0, 1.0))
        grid_points = list(cf.grid(log10m1=2, log10m2=2))
        assert len(grid_points) == 4
        assert grid_points[0] == (0.0, 0.0)
        assert grid_points[-1] == (1.0, 1.0)

    def test_grid_assertion(self):
        """Test grid with invalid coordinate"""
        cf = MassCoordFunc(log10m1=(0.0, 1.0), log10m2=(0.0, 1.0))
        # Test that grid raises ValueError for invalid coordinate keys
        with pytest.raises(
            ValueError, match="Can only normalize dicts whose keys are subsets"
        ):
            list(cf.grid(log10m1=2, spin=2))  # spin is not in FROM_TYPES

    def test_set_bounds_single_coordinate(self):
        """Test _set_bounds with single coordinate"""

        # Create a single-coordinate function
        class SingleCoordFunc(coordinate.CoordFunc):
            _STANDARD_COORD_TYPES = (Mass1,)
            TO_TYPES = (Mass1,)
            FROM_TYPES = (LogMass1,)

            def __call__(self, c, inv=False):
                if inv:
                    c_dict = self._normalize_coorddict(c, inv=True)
                    return np.log10(c_dict[Mass1])
                else:
                    if isinstance(c, dict):
                        c = self._normalize_coorddict(c)
                        return {Mass1: 10 ** c[LogMass1]}
                    else:
                        return {Mass1: 10 ** float(np.squeeze(c))}

        # Pass bounds for LogMass1 instead of Mass1 since FROM_TYPES = (LogMass1,)
        cf = SingleCoordFunc(log10m1=(0.0, 2.0))  # log10(1) to log10(100)
        assert cf.from_bounds is not None
        assert LogMass1 in cf.from_bounds

    def test_set_bounds_empty_from_types(self):
        """Test _set_bounds with empty FROM_TYPES"""

        class EmptyFromTypesFunc(coordinate.CoordFunc):
            _STANDARD_COORD_TYPES = ()
            TO_TYPES = (Mass1,)
            FROM_TYPES = ()

            def __call__(self, c, inv=False):
                # Return a scalar (0-d array) which has no shape
                return np.array(42.0)

        cf = EmptyFromTypesFunc(m1=(1.0, 100.0))
        assert cf.from_bounds == {}

    def test_not_implemented_methods(self):
        """Test NotImplementedError for abstract methods"""

        # Create a minimal CoordFunc subclass that doesn't call __init__
        class MinimalCoordFunc(coordinate.CoordFunc):
            def __init__(self):
                # Skip parent init to avoid needing bounds
                self.from_bounds = {}
                self.to_bounds = {}
                self.mins = []
                self.maxes = []

        base_cf = MinimalCoordFunc()
        with pytest.raises(NotImplementedError):
            base_cf(None)
        with pytest.raises(NotImplementedError):
            base_cf.dx(None)
        with pytest.raises(NotImplementedError):
            base_cf.random()
        with pytest.raises(NotImplementedError):
            base_cf.base_step(None)
        with pytest.raises(NotImplementedError):
            base_cf.target_match(None)
        with pytest.raises(NotImplementedError):
            _ = base_cf.min_eig_val
        with pytest.raises(NotImplementedError):
            base_cf.min_scale(None)

    def test_coord_func_implementation(self):
        """Test our implementation of CoordFunc methods"""
        cf = MassCoordFunc(log10m1=(0.0, 2.0), log10m2=(0.0, 2.0))

        # Test dx
        coords = coordinate.Coordinates(1.0, 1.5)
        dx = cf.dx(coords)
        np.testing.assert_array_equal(dx, np.array([0.01, 0.01]))

        # Test base_step
        assert cf.base_step(coords) == 0.01

        # Test target_match
        assert cf.target_match(coords) == 0.97

        # Test min_eig_val
        assert cf.min_eig_val == 1e-6

        # Test min_scale
        assert cf.min_scale(coords) == 0.001

        # Test random
        random_point = cf.random()
        assert LogMass1 in random_point
        assert LogMass2 in random_point
        assert 0.0 <= random_point[LogMass1] <= 2.0
        assert 0.0 <= random_point[LogMass2] <= 2.0

    def test_set_bounds_invalid_keys(self):
        """Test _set_bounds with keys that are neither TO_TYPES nor FROM_TYPES"""

        class InvalidBoundsFunc(coordinate.CoordFunc):
            _STANDARD_COORD_TYPES = (Mass1, Mass2)
            TO_TYPES = (Mass1,)
            FROM_TYPES = (LogMass1,)

            def __init__(self):
                # Skip parent init to avoid automatic bounds setting
                self.from_bounds = None
                self.to_bounds = None
                self.mins = []
                self.maxes = []

            def __call__(self, c, inv=False):
                return c

        # Try to set bounds with invalid keys (neither TO_TYPES nor FROM_TYPES)
        cf = InvalidBoundsFunc()
        with pytest.raises(ValueError, match="Unable to set bounds"):
            cf._set_bounds(
                {Mass2: (1.0, 100.0)}
            )  # Mass2 is not in TO_TYPES or FROM_TYPES

    def test_coord_func_coordinate_validation(self):
        """Test coordinate validation with proper dimensions"""

        # Create a function that requires dimension validation
        class DimensionValidatedFunc(coordinate.CoordFunc):
            _STANDARD_COORD_TYPES = (Mass1, Mass2)
            TO_TYPES = (Mass1, Mass2)
            FROM_TYPES = (LogMass1, LogMass2)

            def __call__(self, c, inv=False):
                # This will trigger dimension validation in various paths
                if inv:
                    # Convert to FROM_TYPES
                    c_dict = self._normalize_coorddict(c, inv=True)
                    return np.array([np.log10(c_dict[Mass1]), np.log10(c_dict[Mass2])])
                else:
                    # Convert to TO_TYPES
                    if isinstance(c, dict):
                        c = self._normalize_coorddict(c)
                        return {Mass1: 10 ** c[LogMass1], Mass2: 10 ** c[LogMass2]}
                    else:
                        # This exercises coordinate validation for arrays
                        c_array = coordinate.to_array(c)
                        return {Mass1: 10 ** c_array[0], Mass2: 10 ** c_array[1]}

        cf = DimensionValidatedFunc(log10m1=(0.0, 2.0), log10m2=(0.0, 2.0))

        # Test array input - this should exercise coordinate validation
        result = cf(np.array([1.0, 1.5]))
        assert Mass1 in result
        assert Mass2 in result

    def test_coord_func_validation_edge_cases(self):
        """Test edge cases in coordinate validation"""

        # Test with single FROM_TYPE to trigger single coordinate path
        class SingleFromTypeFunc(coordinate.CoordFunc):
            _STANDARD_COORD_TYPES = (Mass1, LogMass1)
            TO_TYPES = (Mass1,)
            FROM_TYPES = (LogMass1,)

            def __call__(self, c, inv=False):
                if inv:
                    c_dict = self._normalize_coorddict(c, inv=True)
                    return np.log10(c_dict[Mass1])
                else:
                    if isinstance(c, dict):
                        c = self._normalize_coorddict(c)
                        return {Mass1: 10 ** c[LogMass1]}
                    else:
                        return {Mass1: 10 ** float(np.squeeze(c))}

        cf = SingleFromTypeFunc(log10m1=(0.0, 2.0))

        # Test with scalar input
        result = cf(1.0)
        assert result[Mass1] == 10.0

    def test_coord_func_none_from_bounds(self):
        """Test CoordFunc when from_bounds becomes None"""

        # Create a function where from_bounds will be None
        class NoneFromBoundsFunc(coordinate.CoordFunc):
            _STANDARD_COORD_TYPES = (Mass1,)
            TO_TYPES = (Mass1,)
            FROM_TYPES = ()  # Empty FROM_TYPES

            def __call__(self, c, inv=False):
                return c

        cf = NoneFromBoundsFunc(m1=(1.0, 100.0))
        # This should set mins=[] and maxes=[] when from_bounds is None
        assert cf.mins == []
        assert cf.maxes == []
