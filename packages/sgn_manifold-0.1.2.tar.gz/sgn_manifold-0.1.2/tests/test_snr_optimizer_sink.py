"""Tests for SNROptimizerSink (SGN-based SNR optimizer).

This module contains unit tests for the SGN-based SNR optimizer sink element.
"""

from unittest.mock import Mock, patch

import pytest

from sgn_manifold.snr_optimizer_sink import SNROptimizerSink


class TestSNROptimizerSinkInitialization:
    """Test SNROptimizerSink initialization."""

    def test_basic_initialization(self):
        """Test basic sink initialization with minimal parameters."""
        channel_dict = {"H1": "GDS-CALIB_STRAIN", "L1": "GDS-CALIB_STRAIN"}

        sink = SNROptimizerSink(
            channel_dict=channel_dict,
            rate=2048,
            seed_bank=Mock(),  # Mock bank for testing
            psd={"H1": Mock(), "L1": Mock()},
        )

        # Check instruments derived from channel_dict
        assert sink.instruments == ["H1", "L1"]

        # Check sink pads created
        assert len(sink.sink_pads) == 4  # 2 data + 2 PSD pads

        # Check pad names
        pad_names = {pad.name for pad in sink.sink_pads}
        expected_pads = {
            f"{sink.name}:snk:data_H1",
            f"{sink.name}:snk:data_L1",
            f"{sink.name}:snk:psd_H1",
            f"{sink.name}:snk:psd_L1",
        }
        assert pad_names == expected_pads

        # Check unaligned pads (PSDs)
        assert set(sink.unaligned) == {"psd_H1", "psd_L1"}

        # Check data buffers initialized
        assert "H1" in sink.datadeq
        assert "L1" in sink.datadeq

    def test_three_detector_initialization(self):
        """Test initialization with three detectors."""
        channel_dict = {
            "H1": "GDS-CALIB_STRAIN",
            "L1": "GDS-CALIB_STRAIN",
            "V1": "Hrec_hoft_16384Hz",
        }

        sink = SNROptimizerSink(
            channel_dict=channel_dict,
            rate=2048,
            seed_bank=Mock(),
            psd={"H1": Mock(), "L1": Mock(), "V1": Mock()},
        )

        assert sink.instruments == ["H1", "L1", "V1"]
        assert len(sink.sink_pads) == 6  # 3 data + 3 PSD pads

    def test_kafka_initialization(self):
        """Test Kafka setup for live processing."""
        channel_dict = {"H1": "STRAIN", "L1": "STRAIN"}

        with patch("sgn_manifold.snr_optimizer_sink.Consumer"), patch(
            "sgn_manifold.snr_optimizer_sink.Producer"
        ):
            sink = SNROptimizerSink(
                channel_dict=channel_dict,
                rate=2048,
                seed_bank=Mock(),
                psd={"H1": Mock(), "L1": Mock()},
                kafka_server="localhost:9092",
                input_topic="events",
                is_live=True,
            )

            assert sink.consumer is not None
            assert sink.producer is not None

    def test_no_kafka_for_offline(self):
        """Test no Kafka setup for offline processing."""
        channel_dict = {"H1": "STRAIN", "L1": "STRAIN"}

        sink = SNROptimizerSink(
            channel_dict=channel_dict,
            rate=2048,
            seed_bank=Mock(),
            psd={"H1": Mock(), "L1": Mock()},
            is_live=False,
        )

        assert sink.consumer is None
        assert sink.producer is None


class TestSNROptimizerSinkFrameRouting:
    """Test frame routing logic."""

    @pytest.fixture
    def sink(self):
        """Create a test sink instance."""
        channel_dict = {"H1": "STRAIN", "L1": "STRAIN"}

        return SNROptimizerSink(
            channel_dict=channel_dict,
            rate=2048,
            seed_bank=Mock(),
            psd={"H1": Mock(), "L1": Mock()},
            is_live=False,
        )

    def test_pad_name_lookup(self, sink):
        """Test reverse pad name lookup."""
        # Get a data pad
        data_pad = sink.snks["data_H1"]
        assert sink.rsnks[data_pad] == "data_H1"

        # Get a PSD pad
        psd_pad = sink.snks["psd_H1"]
        assert sink.rsnks[psd_pad] == "psd_H1"


class TestSNROptimizerSinkDataBuffering:
    """Test data buffering and management."""

    @pytest.fixture
    def sink(self):
        """Create a test sink instance."""
        channel_dict = {"H1": "STRAIN"}

        return SNROptimizerSink(
            channel_dict=channel_dict,
            rate=2048,
            seed_bank=Mock(),
            psd={"H1": Mock()},
            is_live=False,
        )

    def test_empty_buffer_initially(self, sink):
        """Test data buffers are empty initially."""
        assert len(sink.datadeq["H1"]) == 0

    def test_available_data_segments_empty(self, sink):
        """Test available data segments when no data."""
        segments = sink.get_available_data_segments()
        assert "H1" in segments
        # Should be null segment
        assert segments["H1"][0] == 0
        assert segments["H1"][1] == 0


class TestSNROptimizerSinkEventQueue:
    """Test event queuing logic."""

    @pytest.fixture
    def sink(self):
        """Create a test sink instance."""
        channel_dict = {"H1": "STRAIN", "L1": "STRAIN"}

        return SNROptimizerSink(
            channel_dict=channel_dict,
            rate=2048,
            seed_bank=Mock(),
            psd={"H1": Mock(), "L1": Mock()},
            is_live=False,
        )

    def test_event_queue_empty_initially(self, sink):
        """Test event queue is empty initially."""
        assert len(sink.eventdeq) == 0

    def test_event_queue_maxlen(self, sink):
        """Test event queue has max length of 1."""
        assert sink.eventdeq.maxlen == 1


class TestSNROptimizerSinkHelperMethods:
    """Test helper methods."""

    def test_mchirp_calculation(self):
        """Test chirp mass calculation."""
        m1, m2 = 1.4, 1.4  # Equal mass binary
        mc = SNROptimizerSink._mchirp(m1, m2)

        # For equal masses: mc = m1 * m2^(3/5) / (m1 + m2)^(1/5)
        # = 1.4 * 1.4^(3/5) / 2.8^(1/5)
        expected = (1.4 * 1.4) ** (3.0 / 5.0) / (1.4 + 1.4) ** (1.0 / 5.0)
        assert abs(mc - expected) < 1e-10

    def test_mchirp_unequal_masses(self):
        """Test chirp mass for unequal masses."""
        m1, m2 = 10.0, 5.0
        mc = SNROptimizerSink._mchirp(m1, m2)

        expected = (10.0 * 5.0) ** (3.0 / 5.0) / (10.0 + 5.0) ** (1.0 / 5.0)
        assert abs(mc - expected) < 1e-10


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
