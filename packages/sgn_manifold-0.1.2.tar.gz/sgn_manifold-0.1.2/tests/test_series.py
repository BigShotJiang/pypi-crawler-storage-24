"""Tests for series.py module to achieve 100% coverage"""

import numpy
import pytest
from lal import LIGOTimeGPS

from sgn_manifold import series


class TestSeriesCreation:
    """Test series creation functions"""

    def test_get_default_sample_units(self):
        """Test default sample units initialization"""
        # Reset to test initialization
        series._DEFAULT_SAMPLE_UNITS = None
        units = series._get_default_sample_units()
        assert units is not None
        assert str(units) == "strain"

        # Test caching
        units2 = series._get_default_sample_units()
        assert units is units2  # Should be same object

    def test_r8t_with_array_data(self):
        """Test r8t with array data"""
        data = numpy.array([1.0, 2.0, 3.0, 4.0, 5.0])
        epoch = LIGOTimeGPS(1000000000)
        deltaT = 0.001

        ts = series.r8t(data, epoch, deltaT, f0=0.0, name="test_series")

        assert ts.name == "test_series"
        assert ts.epoch == epoch
        assert ts.deltaT == deltaT
        assert ts.f0 == 0.0
        assert ts.data.length == 5
        numpy.testing.assert_array_equal(ts.data.data, data)

    def test_r8t_with_length(self):
        """Test r8t with integer length"""
        length = 10
        epoch = LIGOTimeGPS(1200000000)
        deltaT = 0.002

        ts = series.r8t(length, epoch, deltaT, f0=1.0, name="zero_series")

        assert ts.data.length == 10
        assert ts.f0 == 1.0
        numpy.testing.assert_array_equal(ts.data.data, numpy.zeros(10))

    def test_r8t_with_custom_units(self):
        """Test r8t with custom sample units"""
        import lal

        data = [1, 2, 3]
        units = lal.Unit("count")
        ts = series.r8t(data, LIGOTimeGPS(0), 1.0, sampleUnits=units)

        assert ts.sampleUnits == units

    def test_c8t_with_complex_data(self):
        """Test c8t with complex data"""
        data = numpy.array([1 + 2j, 3 + 4j, 5 + 6j])
        epoch = LIGOTimeGPS(1300000000)
        deltaT = 0.001

        ts = series.c8t(data, epoch, deltaT, f0=10.0, name="complex_series")

        assert ts.name == "complex_series"
        assert ts.data.length == 3
        assert ts.f0 == 10.0
        numpy.testing.assert_array_equal(ts.data.data, data)

    def test_c8t_with_length(self):
        """Test c8t with integer length"""
        length = 8
        ts = series.c8t(length, LIGOTimeGPS(0), 0.125)

        assert ts.data.length == 8
        numpy.testing.assert_array_equal(ts.data.data, numpy.zeros(8, dtype=complex))

    def test_r4t_with_float32_data(self):
        """Test r4t with float32 data"""
        data = numpy.array([1.5, 2.5, 3.5], dtype=numpy.float32)
        epoch = LIGOTimeGPS(1400000000)
        deltaT = 0.0001

        ts = series.r4t(data, epoch, deltaT, name="float32_series")

        assert ts.data.length == 3
        numpy.testing.assert_array_almost_equal(ts.data.data, data)

    def test_r4t_with_length(self):
        """Test r4t with integer length"""
        ts = series.r4t(5, LIGOTimeGPS(100), 0.1, f0=5.0)

        assert ts.data.length == 5
        assert ts.f0 == 5.0
        numpy.testing.assert_array_equal(ts.data.data, numpy.zeros(5))

    def test_cpr4t(self):
        """Test cpr4t copy function"""
        # Create original series
        data = numpy.array([1, 2, 3, 4], dtype=numpy.float32)
        original = series.r4t(data, LIGOTimeGPS(500), 0.25, f0=2.0, name="original")

        # Copy it
        copy = series.cpr4t(original)

        # Verify all properties are copied
        assert copy.name == original.name
        assert copy.epoch == original.epoch
        assert copy.deltaT == original.deltaT
        assert copy.f0 == original.f0
        assert copy.sampleUnits == original.sampleUnits
        numpy.testing.assert_array_equal(copy.data.data, original.data.data)

        # Verify it's a true copy (modifying one doesn't affect the other)
        copy.data.data[0] = 999
        assert original.data.data[0] == 1


class TestFrequencySeries:
    """Test frequency series functions"""

    def test_c8f_with_complex_data(self):
        """Test c8f with complex frequency data"""
        data = numpy.array([1 + 0j, 0 + 1j, 1 + 1j])
        epoch = LIGOTimeGPS(1234567890)
        deltaF = 1.0

        fs = series.c8f(data, epoch, deltaF, f0=0.0, name="freq_series")

        assert fs.name == "freq_series"
        assert fs.deltaF == deltaF
        assert fs.data.length == 3
        numpy.testing.assert_array_equal(fs.data.data, data)

    def test_c8f_with_length(self):
        """Test c8f with integer length"""
        fs = series.c8f(100, LIGOTimeGPS(0), 0.1, f0=10.0)

        assert fs.data.length == 100
        assert fs.f0 == 10.0
        numpy.testing.assert_array_equal(fs.data.data, numpy.zeros(100, dtype=complex))

    def test_c16f_with_complex128_data(self):
        """Test c16f with complex128 data"""
        data = numpy.array([1 + 2j, 3 + 4j, 5 + 6j], dtype=numpy.complex128)
        epoch = LIGOTimeGPS(987654321)
        deltaF = 0.5

        fs = series.c16f(data, epoch, deltaF, name="complex128_series")

        assert fs.data.length == 3
        numpy.testing.assert_array_equal(fs.data.data, data)

    def test_c16f_with_length(self):
        """Test c16f with integer length"""
        fs = series.c16f(50, LIGOTimeGPS(100), 2.0)

        assert fs.data.length == 50
        numpy.testing.assert_array_equal(
            fs.data.data, numpy.zeros(50, dtype=numpy.complex128)
        )

    def test_r8f_with_float64_data(self):
        """Test r8f with float64 data"""
        data = numpy.array([1.1, 2.2, 3.3, 4.4, 5.5])
        epoch = LIGOTimeGPS(1468135790)
        deltaF = 0.25

        fs = series.r8f(data, epoch, deltaF, f0=20.0, name="real_freq_series")

        assert fs.name == "real_freq_series"
        assert fs.f0 == 20.0
        assert fs.data.length == 5
        numpy.testing.assert_array_equal(fs.data.data, data)

    def test_r8f_with_length(self):
        """Test r8f with integer length"""
        fs = series.r8f(200, LIGOTimeGPS(0), 0.5)

        assert fs.data.length == 200
        numpy.testing.assert_array_equal(fs.data.data, numpy.zeros(200))

    def test_r8f_with_custom_units(self):
        """Test r8f with custom sample units"""
        import lal

        data = [1.5, 2.5, 3.5]
        units = lal.Unit("count")
        fs = series.r8f(data, LIGOTimeGPS(0), 1.0, sampleUnits=units)

        assert fs.sampleUnits == units

    def test_cpc16f(self):
        """Test cpc16f copy function"""
        # Create original series
        data = numpy.array([1 + 1j, 2 + 2j, 3 + 3j], dtype=numpy.complex128)
        original = series.c16f(data, LIGOTimeGPS(1000), 1.0, f0=5.0, name="original")

        # Copy it
        copy = series.cpc16f(original)

        # Verify all properties are copied
        assert copy.name == original.name
        assert copy.epoch == original.epoch
        assert copy.deltaF == original.deltaF
        assert copy.f0 == original.f0
        numpy.testing.assert_array_equal(copy.data.data, original.data.data)

    def test_cpr8f(self):
        """Test cpr8f copy function"""
        # Create original series
        data = numpy.array([1.0, 2.0, 3.0, 4.0])
        original = series.r8f(data, LIGOTimeGPS(2000), 0.1, f0=5.0, name="original_r8f")

        # Copy it
        copy = series.cpr8f(original)

        # Verify all properties are copied
        assert copy.name == original.name
        assert copy.epoch == original.epoch
        assert copy.deltaF == original.deltaF
        assert copy.f0 == original.f0
        assert copy.sampleUnits == original.sampleUnits
        numpy.testing.assert_array_equal(copy.data.data, original.data.data)


class TestTruncateExpand:
    """Test truncate and expand functions"""

    def test_truncater8f(self):
        """Test truncater8f function"""
        # Create a frequency series
        data = numpy.arange(100)
        fs = series.r8f(
            data, LIGOTimeGPS(0), 1.0, f0=10.0, name="test_truncate"
        )  # deltaF = 1 Hz

        # Truncate at 50 Hz
        truncated = series.truncater8f(fs, 50.0)

        assert truncated.data.length == 51  # 0 to 50 Hz inclusive
        assert truncated.name == "test_truncate"
        assert truncated.f0 == 10.0
        assert truncated.deltaF == 1.0
        numpy.testing.assert_array_equal(truncated.data.data, data[:51])

    def test_truncater8f_assertion(self):
        """Test truncater8f assertion for invalid fmax"""
        data = numpy.arange(10)
        fs = series.r8f(data, LIGOTimeGPS(0), 1.0)

        with pytest.raises(AssertionError):
            series.truncater8f(fs, 100.0)  # fmax too large

    def test_truncatec16f(self):
        """Test truncatec16f function"""
        data = numpy.arange(20, dtype=complex)
        fs = series.c16f(data, LIGOTimeGPS(0), 0.5)

        truncated = series.truncatec16f(fs, 10)

        assert truncated.data.length == 10
        numpy.testing.assert_array_equal(truncated.data.data, data[:10])

    def test_truncatec16f_assertion(self):
        """Test truncatec16f assertion"""
        fs = series.c16f(5, LIGOTimeGPS(0), 1.0)

        with pytest.raises(AssertionError):
            series.truncatec16f(fs, 10)  # length too large

    def test_expandc16f(self):
        """Test expandc16f function"""
        data = numpy.array([1 + 1j, 2 + 2j, 3 + 3j])
        fs = series.c16f(data, LIGOTimeGPS(0), 1.0, f0=5.0, name="test")

        expanded = series.expandc16f(fs, 6)

        assert expanded.data.length == 6
        assert expanded.name == "test"
        assert expanded.f0 == 5.0
        assert expanded.deltaF == 1.0
        numpy.testing.assert_array_equal(expanded.data.data[:3], data)
        numpy.testing.assert_array_equal(
            expanded.data.data[3:], numpy.zeros(3, dtype=complex)
        )

    def test_expandc16f_assertion(self):
        """Test expandc16f assertion"""
        fs = series.c16f(10, LIGOTimeGPS(0), 1.0)

        with pytest.raises(AssertionError):
            series.expandc16f(fs, 5)  # length too small

    def test_expandc8f(self):
        """Test expandc8f function"""
        data = numpy.array([1 + 0j, 0 + 1j], dtype=numpy.complex64)
        fs = series.c8f(data, LIGOTimeGPS(0), 2.0)

        expanded = series.expandc8f(fs, 5)

        assert expanded.data.length == 5
        numpy.testing.assert_array_equal(expanded.data.data[:2], data)
        numpy.testing.assert_array_equal(
            expanded.data.data[2:], numpy.zeros(3, dtype=complex)
        )

    def test_truncatec8f(self):
        """Test truncatec8f function"""
        data = numpy.arange(15, dtype=numpy.complex64)
        fs = series.c8f(data, LIGOTimeGPS(0), 0.1)

        truncated = series.truncatec8f(fs, 8)

        assert truncated.data.length == 8
        numpy.testing.assert_array_equal(truncated.data.data, data[:8])

    def test_nipr4t(self):
        """Test nipr4t function - keep last N seconds"""
        # Create 10 seconds of data at 10 Hz
        length = 100
        data = numpy.arange(length, dtype=numpy.float32)
        deltaT = 0.1  # 10 Hz sampling
        epoch = LIGOTimeGPS(1000)
        ts = series.r4t(data, epoch, deltaT)

        # Keep last 2 seconds
        duration = 2.0
        truncated = series.nipr4t(ts, duration)

        assert truncated.data.length == 20  # 2 seconds at 10 Hz
        assert truncated.epoch == LIGOTimeGPS(1008)  # 1000 + 10 - 2
        numpy.testing.assert_array_equal(truncated.data.data, data[-20:])

    def test_nipr4t_assertions(self):
        """Test nipr4t assertions"""
        ts = series.r4t(10, LIGOTimeGPS(0), 0.1)

        # Duration too long
        with pytest.raises(AssertionError):
            series.nipr4t(ts, 2.0)

        # Duration too short
        with pytest.raises(AssertionError):
            series.nipr4t(ts, 0.0)


class TestResamplingClasses:
    """Test resampling classes"""

    def test_rs2r4t_init(self):
        """Test rs2r4t initialization"""
        resampler = series.rs2r4t()
        assert hasattr(resampler, "FWD_PLAN")
        assert hasattr(resampler, "REV_PLAN")
        assert resampler.FWD_PLAN == {}
        assert resampler.REV_PLAN == {}

    def test_rs2r4t_no_resampling(self):
        """Test rs2r4t when no resampling needed"""
        data = numpy.array([1, 2, 3, 4], dtype=numpy.float32)
        ts = series.r4t(data, LIGOTimeGPS(0), 0.25)  # 4 Hz

        resampler = series.rs2r4t()
        result = resampler(ts, 4.0)  # Same rate

        numpy.testing.assert_array_equal(result.data.data, data)
        assert result.deltaT == 0.25

    def test_rs2r4t_upsample(self):
        """Test rs2r4t upsampling"""
        # Create 4 samples at 4 Hz
        data = numpy.array([1, 2, 3, 4], dtype=numpy.float32)
        ts = series.r4t(data, LIGOTimeGPS(0), 0.25)  # 4 Hz

        resampler = series.rs2r4t()
        result = resampler(ts, 8.0)  # Upsample to 8 Hz

        assert result.data.length == 8
        assert result.deltaT == 0.125

    def test_rs2r4t_downsample(self):
        """Test rs2r4t downsampling"""
        # Create 8 samples at 8 Hz
        data = numpy.array([1, 2, 3, 4, 5, 6, 7, 8], dtype=numpy.float32)
        ts = series.r4t(data, LIGOTimeGPS(0), 0.125)  # 8 Hz

        resampler = series.rs2r4t()
        result = resampler(ts, 4.0)  # Downsample to 4 Hz

        assert result.data.length == 4
        assert result.deltaT == 0.25

    def test_rs2r4t_assertions(self):
        """Test rs2r4t assertions for power of 2"""
        # Non-power of 2 input rate
        ts1 = series.r4t(4, LIGOTimeGPS(0), 0.3)  # 3.33 Hz
        resampler = series.rs2r4t()
        with pytest.raises(AssertionError):
            resampler(ts1, 4.0)

        # Non-power of 2 output rate
        ts2 = series.r4t(4, LIGOTimeGPS(0), 0.25)  # 4 Hz
        with pytest.raises(AssertionError):
            resampler(ts2, 3.0)

        # Non-power of 2 length
        ts3 = series.r4t(5, LIGOTimeGPS(0), 0.25)  # 5 samples
        with pytest.raises(AssertionError):
            resampler(ts3, 8.0)

    def test_rsarr_init(self):
        """Test rsarr initialization"""
        resampler = series.rsarr()
        assert hasattr(resampler, "FWD_PLAN")
        assert hasattr(resampler, "REV_PLAN")
        assert resampler.FWD_PLAN == {}
        assert resampler.REV_PLAN == {}

    def test_rsarr_no_resampling(self):
        """Test rsarr when no resampling needed"""
        data = numpy.array([1, 2, 3, 4], dtype=numpy.float32)

        resampler = series.rsarr()
        result = resampler(data, 4)  # Same length

        numpy.testing.assert_array_equal(result, data)

    def test_rsarr_upsample(self):
        """Test rsarr upsampling"""
        data = numpy.array([1, 2, 3, 4], dtype=numpy.float32)

        resampler = series.rsarr()
        result = resampler(data, 8)

        assert len(result) == 8

    def test_rsarr_downsample(self):
        """Test rsarr downsampling"""
        data = numpy.array([1, 2, 3, 4, 5, 6, 7, 8], dtype=numpy.float32)

        resampler = series.rsarr()
        result = resampler(data, 4)

        assert len(result) == 4

    def test_r4fft_init(self):
        """Test r4fft initialization"""
        fft = series.r4fft()
        assert hasattr(fft, "FWD_PLAN")
        assert fft.FWD_PLAN == {}

    def test_r4fft_even_length(self):
        """Test r4fft with even length array"""
        data = numpy.array([1, 2, 3, 4], dtype=numpy.float32)

        fft = series.r4fft()
        result = fft(data)

        assert len(result) == 4
        assert result.dtype == numpy.complex128

    def test_r4fft_odd_length(self):
        """Test r4fft with odd length array"""
        data = numpy.array([1, 2, 3, 4, 5], dtype=numpy.float32)

        fft = series.r4fft()
        result = fft(data)

        assert len(result) == 5
        assert result.dtype == numpy.complex128

    def test_r4fft_plan_caching(self):
        """Test r4fft plan caching"""
        fft = series.r4fft()

        # First call creates plan
        data1 = numpy.array([1, 2, 3, 4], dtype=numpy.float32)
        fft(data1)
        assert 4 in fft.FWD_PLAN

        # Second call reuses plan
        data2 = numpy.array([5, 6, 7, 8], dtype=numpy.float32)
        fft(data2)

        # Different length creates new plan
        data3 = numpy.array([1, 2], dtype=numpy.float32)
        fft(data3)
        assert 2 in fft.FWD_PLAN

    def test_r4fft_result_structure_even(self):
        """Test r4fft result structure for even length"""
        data = numpy.array([1, 0, 0, 0], dtype=numpy.float32)

        fft = series.r4fft()
        result = fft(data)

        # For even length, should concatenate positive and negative frequencies
        # excluding the duplicate at Nyquist
        assert len(result) == 4

    def test_r4ifft_init(self):
        """Test r4ifft initialization"""
        ifft = series.r4ifft()
        assert hasattr(ifft, "REV_PLAN")
        assert ifft.REV_PLAN == {}

    def test_r4ifft(self):
        """Test r4ifft inverse FFT"""
        # Create frequency domain data (must be odd length)
        freq_data = numpy.array([1 + 0j, 2 + 1j, 3 + 2j], dtype=numpy.complex128)

        ifft = series.r4ifft()
        result = ifft(freq_data)

        assert len(result) == 4  # 2 * (3 - 1)
        assert result.dtype == numpy.float32

    def test_r4ifft_assertion(self):
        """Test r4ifft assertion for odd length"""
        # Even length should fail
        freq_data = numpy.array([1 + 0j, 2 + 1j], dtype=numpy.complex128)

        ifft = series.r4ifft()
        with pytest.raises(AssertionError):
            ifft(freq_data)

    def test_r4ifft_plan_caching(self):
        """Test r4ifft plan caching"""
        ifft = series.r4ifft()

        # First call creates plan for length 4
        freq_data = numpy.array([1 + 0j, 2 + 1j, 3 + 2j], dtype=numpy.complex128)
        ifft(freq_data)
        assert 4 in ifft.REV_PLAN


class TestRoundTrip:
    """Test round-trip conversions"""

    def test_resample_roundtrip(self):
        """Test resampling up then down returns similar data"""
        # Create original data
        original_data = numpy.array([1, 2, 3, 4], dtype=numpy.float32)
        ts = series.r4t(original_data, LIGOTimeGPS(0), 0.25)  # 4 Hz

        resampler = series.rs2r4t()

        # Upsample to 8 Hz
        upsampled = resampler(ts, 8.0)

        # Downsample back to 4 Hz
        downsampled = resampler(upsampled, 4.0)

        # Should be similar to original (with some interpolation error)
        assert downsampled.data.length == 4
        assert downsampled.deltaT == 0.25
