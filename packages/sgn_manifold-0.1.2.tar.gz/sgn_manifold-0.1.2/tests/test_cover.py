"""Comprehensive unit tests for the cover module"""

import itertools
from unittest import mock

import numpy
import pytest
from matplotlib import patches
from scipy.special import gamma

from sgn_manifold.cover import (
    Chart,
    ConstraintExteriorError,
    DummyRectangle,
    ManifoldRectangle,
    SizeMethod,
    tmpvol,
)
from sgn_manifold.metric import EvaluationMethod, volume_element


class TestSizeMethod:
    """Tests for SizeMethod enum"""

    def test_size_method_values(self):
        """Test that SizeMethod enum has the correct values"""
        assert SizeMethod.Proper == "proper"


class TestDummyRectangle:
    """Tests for DummyRectangle class"""

    def test_dummy_rectangle_initialization(self):
        """Test DummyRectangle initialization"""
        center = numpy.array([1.0, 2.0, 3.0])
        rect = DummyRectangle(center)
        assert numpy.array_equal(rect.center, center)


class TestConstraintExteriorError:
    """Tests for ConstraintExteriorError exception"""

    def test_constraint_exterior_error(self):
        """Test that ConstraintExteriorError is a ValueError"""
        assert issubclass(ConstraintExteriorError, ValueError)


class TestManifoldRectangle:
    """Tests for ManifoldRectangle class"""

    def test_initialization_basic(self):
        """Test basic initialization with metric"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock(return_value=numpy.eye(2))

        rect = ManifoldRectangle(mins, maxes, metric_mock)

        assert numpy.array_equal(rect.mins, mins)
        assert numpy.array_equal(rect.maxes, maxes)
        assert rect.metric == metric_mock
        assert rect.method == EvaluationMethod.Deterministic
        # jump_method, jump_metric, and jump_validator were removed from codebase
        assert rect.meta == {}
        assert numpy.array_equal(rect.g, numpy.eye(2))
        assert rect.level == 0
        assert rect.right is False
        assert rect.left is False

    def test_initialization_with_g(self):
        """Test initialization with g provided"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        g = numpy.array([[2.0, 0.5], [0.5, 3.0]])

        rect = ManifoldRectangle(mins, maxes, None, g=g)

        assert numpy.array_equal(rect.g, g)

    def test_initialization_no_metric_no_g(self):
        """Test initialization with neither metric nor g provided"""
        mins = numpy.array([0.0, 0.0, 0.0])
        maxes = numpy.array([1.0, 1.0, 1.0])

        rect = ManifoldRectangle(mins, maxes, None, g=None)

        assert numpy.array_equal(rect.g, numpy.eye(3))

    def test_initialization_with_meta(self):
        """Test initialization with metadata"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        meta_data = {"key": "value", "number": 42}

        rect = ManifoldRectangle(mins, maxes, None, meta=meta_data)

        assert rect.meta == meta_data

    # jump_validator was removed from codebase
    # def test_initialization_with_jump_validator(self):
    #     """Test initialization with jump validator"""
    #     mins = numpy.array([0.0, 0.0])
    #     maxes = numpy.array([1.0, 1.0])
    #     metric_mock = mock.Mock(return_value=numpy.eye(2))
    #
    #     def jump_validator(x):
    #         return x[0] > 0.3
    #
    #     rect = ManifoldRectangle(
    #         mins, maxes, metric_mock, jump_validator=jump_validator
    #     )
    #
    #     # The center is [0.5, 0.5], which passes the validator
    #     assert rect.jump_validator == jump_validator
    #     metric_mock.assert_called_once()

    # jump_validator was removed from codebase
    # def test_initialization_with_jump_validator_center_fails(self):
    #     """Test initialization when center fails jump validator"""
    #     mins = numpy.array([0.0, 0.0])
    #     maxes = numpy.array([0.4, 0.4])  # Center will be [0.2, 0.2]
    #     metric_mock = mock.Mock(return_value=numpy.eye(2))
    #
    #     def jump_validator(x):
    #         return x[0] > 0.3  # Center at 0.2 fails, but vertex at 0.4 passes
    #
    #     ManifoldRectangle(mins, maxes, metric_mock, jump_validator=jump_validator)
    #
    #     # Should use one of the vertices instead
    #     metric_mock.assert_called_once()
    #     # The vertex [0.4, 0.4] passes the validator

    # jump_validator was removed from codebase
    # def test_initialization_with_jump_validator_all_fail_no_jump_metric(self):
    #     """Test initialization when all points fail validator and no jump_metric"""
    #     mins = numpy.array([0.0, 0.0])
    #     maxes = numpy.array([0.2, 0.2])
    #     metric_mock = mock.Mock(return_value=numpy.eye(2))
    #
    #     def jump_validator(x):
    #         return x[0] > 0.5  # All points fail
    #
    #     with pytest.raises(ConstraintExteriorError):
    #         with mock.patch("builtins.print") as mock_print:
    #             ManifoldRectangle(
    #                 mins, maxes, metric_mock, jump_validator=jump_validator
    #             )
    #             mock_print.assert_called_once()

    # jump_validator was removed from codebase
    # def test_initialization_with_jump_validator_all_fail_with_jump_metric(self):
    #     """Test initialization when all points fail validator with jump_metric"""
    #     mins = numpy.array([0.0, 0.0])
    #     maxes = numpy.array([0.2, 0.2])
    #     metric_mock = mock.Mock(return_value=numpy.eye(2))
    #     jump_metric = numpy.array([[2.0, 0.0], [0.0, 2.0]])
    #
    #     def jump_validator(x):
    #         return x[0] > 0.5  # All points fail
    #
    #     with mock.patch("builtins.print") as mock_print:
    #         rect = ManifoldRectangle(
    #             mins,
    #             maxes,
    #             metric_mock,
    #             jump_validator=jump_validator,
    #             jump_metric=jump_metric,
    #         )
    #         mock_print.assert_called_once()
    #         assert numpy.array_equal(rect.g, jump_metric)

    def test_hash(self):
        """Test hash method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect1 = ManifoldRectangle(mins, maxes, None)
        rect2 = ManifoldRectangle(mins, maxes, None)

        assert hash(rect1) == hash(rect2)

    def test_equality(self):
        """Test equality operator"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect1 = ManifoldRectangle(mins, maxes, None)
        rect2 = ManifoldRectangle(mins, maxes, None)
        rect3 = ManifoldRectangle(mins, numpy.array([2.0, 2.0]), None)

        assert rect1 == rect2
        assert rect1 != rect3

    def test_ball_volume(self):
        """Test ball_volume method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)

        r = 0.17
        N = 2
        expected = numpy.pi * (N / 2) / gamma(N / 2 + 1) * r**N
        assert rect.ball_volume(r) == pytest.approx(expected)

    def test_num_balls(self):
        """Test num_balls method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        g = numpy.array([[4.0, 0.0], [0.0, 4.0]])
        rect = ManifoldRectangle(mins, maxes, None, g=g)

        r = 0.17
        expected = rect.proper_volume / rect.ball_volume(r)
        assert rect.num_balls(r) == pytest.approx(expected)

    def test_update_meta(self):
        """Test update_meta method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)

        rect.update_meta(key1="value1", key2=42)
        assert rect.meta == {"key1": "value1", "key2": 42}

        rect.update_meta(key2=100, key3="new")
        assert rect.meta == {"key1": "value1", "key2": 100, "key3": "new"}

    def test_update_meta_none_initial(self):
        """Test update_meta when meta is initially None"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)
        rect.meta = None

        rect.update_meta(key="value")
        assert rect.meta == {"key": "value"}

    def test_vertices(self):
        """Test vertices property"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 2.0])
        rect = ManifoldRectangle(mins, maxes, None)

        vertices = list(rect.vertices)
        expected = [(0.0, 0.0), (0.0, 2.0), (1.0, 0.0), (1.0, 2.0)]

        assert len(vertices) == len(expected)
        for v in vertices:
            assert v in expected

    def test_center(self):
        """Test center property"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        rect = ManifoldRectangle(mins, maxes, None)

        assert numpy.array_equal(rect.center, numpy.array([1.0, 2.0]))

    def test_metric_center(self):
        """Test metric_center property"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        rect = ManifoldRectangle(mins, maxes, None)

        assert numpy.array_equal(rect.metric_center, rect.center)

    def test_split(self):
        """Test split method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        metric_mock = mock.Mock(return_value=numpy.eye(2))
        rect = ManifoldRectangle(mins, maxes, metric_mock)

        less, greater = rect.split(0, 0.5)

        assert numpy.array_equal(less.mins, numpy.array([0.0, 0.0]))
        assert numpy.array_equal(less.maxes, numpy.array([0.5, 4.0]))
        assert numpy.array_equal(greater.mins, numpy.array([0.5, 0.0]))
        assert numpy.array_equal(greater.maxes, numpy.array([2.0, 4.0]))
        assert less.level == 1
        assert greater.level == 1
        assert less.right is True
        assert less.left is False
        assert greater.right is False
        assert greater.left is True

    def test_split_reuse_g(self):
        """Test split method with reuse_g=True"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        g = numpy.array([[2.0, 0.5], [0.5, 3.0]])
        rect = ManifoldRectangle(mins, maxes, None, g=g)

        less, greater = rect.split(1, 2.0, reuse_g=True)

        assert numpy.array_equal(less.g, g)
        assert numpy.array_equal(greater.g, g)

    def test_bisect(self):
        """Test bisect method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        rect = ManifoldRectangle(mins, maxes, None)

        less, greater = rect.bisect(0)

        assert numpy.array_equal(less.maxes[0], 1.0)
        assert numpy.array_equal(greater.mins[0], 1.0)

    def test_coordinate_size(self):
        """Test coordinate_size property"""
        mins = numpy.array([1.0, 2.0])
        maxes = numpy.array([4.0, 7.0])
        rect = ManifoldRectangle(mins, maxes, None)

        assert numpy.array_equal(rect.coordinate_size, numpy.array([3.0, 5.0]))

    def test_proper_size(self):
        """Test proper_size property"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=[2.0, 3.0])
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        proper_size = rect.proper_size
        assert numpy.array_equal(proper_size, numpy.array([2.0, 3.0]))

    def test_local_aspect_ratio(self):
        """Test local_aspect_ratio property"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=[1.5, 2.5])
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        aspect_ratio = rect.local_aspect_ratio
        assert numpy.array_equal(aspect_ratio, numpy.array([1.5, 2.5]))

    def test_local_distortion(self):
        """Test local_distortion property"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        # local_distortion calls local_aspect_ratio which needs 2 distance calls
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0, 3.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        assert rect.local_distortion == 3.0

    def test_interpolated_size_global_factor(self):
        """Test interpolated_size with global factor"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        metric_mock = mock.Mock()
        # Need enough values for multiple proper_size calls
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0, 2.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        # global_factor=0 means proper size (0% coordinate, 100% proper)
        size = rect.interpolated_size(global_factor=0.0)
        assert numpy.array_equal(size, numpy.array([1.0, 2.0]))

        # global_factor=1 means coordinate size (100% coordinate, 0% proper)
        size = rect.interpolated_size(global_factor=1.0)
        assert numpy.array_equal(size, rect.coordinate_size)

        # global_factor=0.5 means halfway between
        size = rect.interpolated_size(global_factor=0.5)
        expected = 0.5 * rect.coordinate_size + 0.5 * numpy.array([1.0, 2.0])
        assert numpy.allclose(size, expected)

    def test_interpolated_size_invalid_global_factor(self):
        """Test interpolated_size with invalid global factor"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)

        with pytest.raises(ValueError, match="Global factor must be in"):
            rect.interpolated_size(global_factor=-0.1)

        with pytest.raises(ValueError, match="Global factor must be in"):
            rect.interpolated_size(global_factor=1.1)

    def test_interpolated_size_local_control(self):
        """Test interpolated_size with local control"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        # Need: 2 for local_aspect_ratio, 2 for proper_size
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0, 2.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        size = rect.interpolated_size(
            local_dist_bounds=(1.0, 3.0), local_dist_beta=(1, 1)
        )

        # With uniform beta distribution and distortion of 2.0 in bounds [1.0, 3.0]
        # normalized distortion = (2.0 - 1.0) / (3.0 - 1.0) = 0.5
        # beta.cdf(0.5) with beta(1,1) = 0.5
        factor = 0.5
        expected = factor * rect.coordinate_size + (1 - factor) * numpy.array(
            [1.0, 2.0]
        )
        assert numpy.allclose(size, expected)

    def test_interpolated_size_invalid_local_bounds(self):
        """Test interpolated_size with invalid local bounds"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)

        with pytest.raises(
            ValueError, match="Local distance bounds must be in increasing order"
        ):
            rect.interpolated_size(local_dist_bounds=(3.0, 1.0), local_dist_beta=(1, 1))

    def test_interpolated_size_invalid_beta(self):
        """Test interpolated_size with invalid beta parameters"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)

        with pytest.raises(
            ValueError, match="Local distance beta parameters must be positive"
        ):
            rect.interpolated_size(local_dist_bounds=(1.0, 3.0), local_dist_beta=(0, 1))

    def test_interpolated_size_no_parameters(self):
        """Test interpolated_size with no parameters raises error"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)

        with pytest.raises(
            ValueError, match="Must specify either global factor or local distance"
        ):
            rect.interpolated_size()

    def test_size_method_only_proper_supported(self):
        """Test that only Proper method is supported"""
        mins = numpy.array([1.0, 2.0])
        maxes = numpy.array([4.0, 7.0])
        rect = ManifoldRectangle(mins, maxes, None)

        # Trying to use any non-Proper method should raise an error
        with pytest.raises(ValueError, match="Only SizeMethod.Proper is supported"):
            rect.size(method="coordinate")

    def test_size_method_proper(self):
        """Test size method with proper method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=[2.0, 3.0])
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        size = rect.size(method=SizeMethod.Proper)
        assert numpy.array_equal(size, numpy.array([2.0, 3.0]))

    def test_size_method_proper_with_aspect_ratios(self):
        """Test size method with proper method and aspect ratios"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=[2.0, 3.0])
        g = numpy.eye(2)
        aspect_ratios = numpy.array([0.5, 2.0])

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        size = rect.size(method=SizeMethod.Proper, aspect_ratios=aspect_ratios)
        assert numpy.array_equal(size, numpy.array([1.0, 6.0]))

    def test_size_deprecated_params_ignored(self):
        """Test that deprecated parameters are ignored"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=[1.0, 2.0])
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        # These deprecated parameters should be ignored
        size = rect.size(
            global_factor=0.5, local_dist_bounds=(0, 1), local_dist_beta=(1, 1)
        )
        # Should still return proper size
        assert len(size) == 2

    def test_size_method_unknown(self):
        """Test size method with unknown method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        rect = ManifoldRectangle(mins, maxes, None)

        with pytest.raises(ValueError, match="Only SizeMethod.Proper is supported"):
            rect.size(method="unknown")

    def test_volume(self):
        """Test volume property"""
        mins = numpy.array([0.0, 0.0, 0.0])
        maxes = numpy.array([2.0, 3.0, 4.0])
        rect = ManifoldRectangle(mins, maxes, None)

        assert rect.volume == 24.0

    def test_proper_volume(self):
        """Test proper_volume property"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 3.0])
        g = numpy.array([[4.0, 0.0], [0.0, 4.0]])
        rect = ManifoldRectangle(mins, maxes, None, g=g)

        expected = volume_element(g) * rect.volume
        assert rect.proper_volume == expected

    def test_patch(self):
        """Test patch method"""
        mins = numpy.array([1.0, 2.0, 3.0])
        maxes = numpy.array([4.0, 6.0, 9.0])
        rect = ManifoldRectangle(mins, maxes, None)

        patch = rect.patch(x=0, y=1)
        assert isinstance(patch, patches.Rectangle)
        assert numpy.array_equal(patch.get_xy(), numpy.array([1.0, 2.0]))
        assert patch.get_width() == 3.0
        assert patch.get_height() == 4.0

    def test_is_inside_constraints_no_interpolation(self):
        """Test is_inside_constraints without interpolation"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 2.0])
        rect = ManifoldRectangle(mins, maxes, None)

        # Constraint that requires x > 0.5
        def constraint1(p):
            return p[0] > 0.5

        # Constraint that requires y < 1.5
        def constraint2(p):
            return p[1] < 1.5

        # Center is [1.0, 1.0] which satisfies both
        assert rect.is_inside_constraints([constraint1, constraint2])

        # Constraint that center fails but a vertex passes
        def constraint3(p):
            return p[0] > 1.5

        assert rect.is_inside_constraints([constraint3])

        # Constraint that nothing satisfies
        def constraint4(p):
            return p[0] > 3.0

        assert not rect.is_inside_constraints([constraint4])

    def test_is_inside_constraints_with_interpolation(self):
        """Test is_inside_constraints with interpolation"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 2.0])
        rect = ManifoldRectangle(mins, maxes, None)

        # Constraint that only some interpolated points satisfy
        def constraint(p):
            return 0.8 < p[0] < 1.2 and 0.8 < p[1] < 1.2

        # With interpolation=1, we get 3x3 grid
        assert rect.is_inside_constraints([constraint], interpolation=1)

        # Constraint that no point satisfies
        def constraint2(p):
            return p[0] > 3.0

        assert not rect.is_inside_constraints([constraint2], interpolation=2)

    def test_divide(self):
        """Test divide method"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 4.0])
        metric_mock = mock.Mock()
        # Make dimension 1 have larger proper size
        metric_mock.distance = mock.Mock(side_effect=[1.0, 3.0])
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)

        less, greater = rect.divide()

        # Should split along dimension 1 (larger proper size)
        assert numpy.array_equal(less.maxes[1], 2.0)
        assert numpy.array_equal(greater.mins[1], 2.0)


class TestTmpvol:
    """Tests for tmpvol function"""

    def test_tmpvol_default(self):
        """Test tmpvol with default parameters"""
        result = tmpvol()
        expected = (2 * (0.01 / 2) ** 0.5) ** 2
        assert result == pytest.approx(expected)

    def test_tmpvol_custom(self):
        """Test tmpvol with custom parameters"""
        mm = 0.02
        N = 3
        result = tmpvol(mm, N)
        expected = (2 * (mm / N) ** 0.5) ** N
        assert result == pytest.approx(expected)


class TestChart:
    """Tests for Chart class"""

    def test_initialization_basic(self):
        """Test basic Chart initialization"""
        data = mock.Mock()
        chart = Chart(data)

        assert chart.data == data
        assert chart.parent is None
        assert chart.left is None
        assert chart.right is None
        assert chart.excluded is None

    def test_initialization_with_parent(self):
        """Test Chart initialization with parent"""
        parent_data = mock.Mock()
        parent = Chart(parent_data, excluded=[])

        child_data = mock.Mock()
        child = Chart(child_data, parent=parent)

        assert child.parent == parent
        assert child.excluded == []

    def test_initialization_with_excluded(self):
        """Test Chart initialization with excluded list"""
        data = mock.Mock()
        excluded = []
        chart = Chart(data, excluded=excluded)

        assert chart.excluded is excluded

    def test_atlas_leaf(self):
        """Test atlas method for leaf node"""
        data = mock.Mock()
        chart = Chart(data)

        atlas = list(chart.atlas())
        assert atlas == [data]

    def test_atlas_tree(self):
        """Test atlas method for tree"""
        root_data = mock.Mock()
        left_data = mock.Mock()
        right_data = mock.Mock()

        root = Chart(root_data)
        root.left = Chart(left_data)
        root.right = Chart(right_data)

        atlas = list(root.atlas())
        assert atlas == [left_data, right_data]

    def test_branch_basic(self):
        """Test basic branching"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        # Need multiple calls for divide operation
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        chart = Chart(rect)

        # Mock volume_element to return a consistent value
        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            chart.branch(mm=0.5, max_num_templates=1)

        # Should have created children
        assert chart.left is not None
        assert chart.right is not None

    def test_branch_with_constraints(self):
        """Test branching with constraints"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 2.0])
        metric_mock = mock.Mock()
        # Need multiple calls for divide operation
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        chart = Chart(rect)

        # Constraint function - returns True if point is OUTSIDE constraint
        def constraint(p):
            # Simple constraint: exclude regions where both x and y are > 1.5
            return p[0] > 1.5 and p[1] > 1.5

        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            chart.branch(mm=0.5, constraints=[constraint], max_num_templates=1)

        # The branching should have occurred
        assert chart.left is not None or chart.right is not None

    def test_branch_with_excluded_tracking(self):
        """Test branching with excluded rectangle tracking"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 2.0])
        metric_mock = mock.Mock()
        # Need multiple calls for divide operation
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        excluded = []
        chart = Chart(rect, excluded=excluded)

        # Constraint that excludes right half (returns True if OUTSIDE constraint)
        def constraint(p):
            return p[0] > 0.5  # True means point is OUTSIDE/excluded

        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            chart.branch(mm=0.5, constraints=[constraint], max_num_templates=1)

        # Some rectangles should be excluded and tracked
        assert len(excluded) > 0
        # At least one branch should exist
        assert chart.left is not None or chart.right is not None

    def test_branch_min_depth(self):
        """Test branching respects minimum depth"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([0.1, 0.1])  # Small rectangle
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(return_value=0.1)
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        chart = Chart(rect)

        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            chart.branch(mm=0.5, min_depth=2, max_num_templates=100)

        # Should branch despite small size due to min_depth
        assert chart.left is not None
        assert chart.right is not None

    def test_branch_verbose(self):
        """Test branching with verbose output"""
        # Just test that verbose mode can be enabled without errors
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        chart = Chart(rect)

        # Run with verbose=True and make sure it doesn't crash
        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            # Force deep recursion to generate many leaf nodes
            # Some of them will eventually trigger the verbose output
            chart.branch(
                mm=0.001,  # Very small mismatch
                verbose=True,
                min_depth=8,  # Deep recursion
                max_num_templates=0.001,  # Very small to force lots of subdivision
            )

        # The test passes if we get here without errors
        # The verbose functionality has been exercised
        assert True

    def test_branch_reuse_g(self):
        """Test branching with g reuse optimization"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])  # Larger rectangle
        metric_mock = mock.Mock()
        # Need to provide enough distance values for multiple calls
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0]))
        g = numpy.eye(2)

        # Create rectangle with no parent first
        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        chart = Chart(rect)

        # Define a constraint that accepts all points (returns False for all)
        def constraint(p):
            return False  # False means INSIDE the constraint

        # Mock volume_element to return a value that makes proper_volume reasonable
        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            # Force branching
            chart.branch(
                mm=0.01,  # Small value to ensure large Ntmps
                reuse_g_mm=10.0,  # Large value to ensure reuse_g condition is met
                reuse_g_vol_tol=0.9,  # Tolerant
                max_num_templates=1,  # Small to force subdivision
                min_depth=0,  # Ensure branching happens at level 0
                constraints=[constraint],  # Provide constraint that accepts all
            )

        # At least one child should exist after branching
        assert chart.left is not None or chart.right is not None

        # Test passes if branching occurred - the test verifies that the
        # branching mechanism works, which includes the reuse_g logic

    def test_branch_all_parameters(self):
        """Test branching with all parameters"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])
        metric_mock = mock.Mock()
        # Setup for interpolated size method
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0, 2.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        chart = Chart(rect)

        # Define a simple constraint that accepts all points
        def always_inside(x):
            return False  # False means inside (not outside)

        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            # This should trigger branching with all parameters
            chart.branch(
                mm=0.5,  # Moderate mismatch
                reuse_g_mm=0.01,
                reuse_g_vol_tol=0.1,
                constraints=[always_inside],
                verbose=False,
                cnt=[0],
                aspect_ratios=numpy.array([1.0, 2.0]),
                min_coord_vol=0.001,
                min_depth=1,  # Force at least one level of branching
                max_num_templates=0.5,  # Small to force subdivision
                # Size method now defaults to Proper only
            )

        # Should have branched due to min_depth=1
        assert chart.left is not None and chart.right is not None


# Integration tests
class TestIntegration:
    """Integration tests for cover module"""

    def test_full_tree_construction(self):
        """Test construction of a full coverage tree"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([1.0, 1.0])

        # Use a mock metric
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0, 1.5]))
        g = numpy.array([[1.5, 0.0], [0.0, 1.5]])

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        chart = Chart(rect)

        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            chart.branch(mm=0.1, min_depth=2, max_num_templates=5)

        # Collect all rectangles
        atlas = list(chart.atlas())
        assert len(atlas) > 0

        # Check basic properties of the atlas
        for rect in atlas:
            # All rectangles should be within original bounds
            assert numpy.all(rect.mins >= mins)
            assert numpy.all(rect.maxes <= maxes)
            # All rectangles should have positive volume
            assert rect.volume > 0

    def test_constraint_boundary_coverage(self):
        """Test coverage near constraint boundaries"""
        mins = numpy.array([0.0, 0.0])
        maxes = numpy.array([2.0, 2.0])

        # Circular constraint: x^2 + y^2 < 1 (returns True if OUTSIDE)
        def constraint(p):
            return p[0] ** 2 + p[1] ** 2 >= 1.0  # True means point is OUTSIDE circle

        # Need a metric for proper_size calculations
        metric_mock = mock.Mock()
        metric_mock.distance = mock.Mock(side_effect=itertools.cycle([1.0]))
        g = numpy.eye(2)

        rect = ManifoldRectangle(mins, maxes, metric_mock, g=g)
        excluded = []
        chart = Chart(rect, excluded=excluded)

        with mock.patch("sgn_manifold.cover.volume_element", return_value=1.0):
            chart.branch(
                mm=0.05, constraints=[constraint], min_depth=2, max_num_templates=10
            )

        # Check that we have created an atlas
        atlas = list(chart.atlas())
        assert len(atlas) > 0

        # Check that we excluded some rectangles (those entirely outside the circle)
        assert len(excluded) > 0

        # Verify that at least some rectangles are inside the circle
        # Note: Due to min_depth, some rectangles outside the constraint might be kept
        inside_count = 0
        for rect in atlas:
            # Check if any point is inside the constraint (not outside)
            points = [rect.center] + list(rect.vertices)
            # constraint returns True for outside, so we want at least one False
            has_inside_point = any(not constraint(p) for p in points)
            if has_inside_point:
                inside_count += 1

        # We should have at least some rectangles that touch the circle
        assert inside_count > 0
