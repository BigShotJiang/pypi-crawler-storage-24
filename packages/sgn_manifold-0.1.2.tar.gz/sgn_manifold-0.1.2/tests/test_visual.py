"""Unit tests for visual module"""

from unittest.mock import Mock

from sgn_manifold import coordinate, visual


class TestVisual:
    """Test group for visual module functions"""

    def test_convexity(self):
        """Test convexity function"""
        # Create a mock Coordinates object
        mock_coords = Mock(spec=coordinate.Coordinates)

        # Call convexity - it should complete without error
        result = visual.convexity(mock_coords)

        # Since the function just passes, result should be None
        assert result is None

    def test_convexity_with_none(self):
        """Test convexity with None parameter"""
        # Even though the function expects Coordinates, it just passes
        # so it won't raise an error with None
        result = visual.convexity(None)
        assert result is None

    def test_import(self):
        """Test that visual module imports correctly"""
        # Just verify the module has the expected function
        assert hasattr(visual, "convexity")
        assert callable(visual.convexity)
