"""Tests for np.py module to achieve 100% coverage"""

from unittest import mock

import numpy
from lal import LIGOTimeGPS
from ligo import segments

from sgn_manifold import np


class TestNumpyTypes:
    """Test numpy types and dtype definitions"""

    def test_numpy_float_compatibility(self):
        """Test numpy float compatibility"""
        # This is already covered by the import, but let's verify it works
        assert np.numpy_float in (numpy.float64, getattr(numpy, "float", numpy.float64))

    def test_gpstype(self):
        """Test GPS type definition"""
        assert np.gpstype == numpy.dtype([("s", numpy.int32), ("ns", numpy.int32)])

    def test_gpsseglisttype(self):
        """Test GPS segment list type"""
        assert np.gpsseglisttype == numpy.dtype(
            [("start", np.gpstype), ("end", np.gpstype)]
        )

    def test_r8ftype(self):
        """Test REAL8FrequencySeries type"""
        dtype = np.r8ftype(100)
        assert dtype.names == (
            "__type__",
            "name",
            "epoch",
            "f0",
            "deltaF",
            "sampleUnits",
            "length",
            "data",
        )
        assert dtype["data"].shape == (100,)

    def test_event_type(self):
        """Test event type structure"""
        assert "id" in np.event_type.names
        assert "snr" in np.event_type.names
        assert "H1_snr" in np.event_type.names

    def test_sim_type(self):
        """Test simulation type structure"""
        assert "time_geocent" in np.sim_type.names
        assert "mass1" in np.sim_type.names
        assert "spin1z" in np.sim_type.names

    def test_injection_event_type(self):
        """Test injection event type"""
        assert np.injection_event_type.names == ("event", "sim")


class TestEncoding:
    """Test numpy array encoding functions"""

    def test_npencode_dict(self):
        """Test encoding dictionary (line 130)"""
        d = {"a": 1, "b": 2.0, "c": "test"}
        result = np.npencode(d)
        assert result.dtype.names == ("a", "b", "c")
        assert result["a"] == 1
        assert result["b"] == 2.0
        assert result["c"] == b"test"

    def test_npencode_segmentlist(self):
        """Test encoding segment list (line 132)"""
        seg1 = segments.segment(LIGOTimeGPS(1000), LIGOTimeGPS(2000))
        seg2 = segments.segment(LIGOTimeGPS(3000), LIGOTimeGPS(4000))
        seglist = segments.segmentlist([seg1, seg2])

        result = np.npencode(seglist)
        assert result.dtype == np.gpsseglisttype
        assert len(result) == 2
        assert result[0]["start"]["s"] == 1000
        assert result[1]["end"]["s"] == 4000

    def test_npencode_ligotimegps(self):
        """Test encoding LIGOTimeGPS (line 134)"""
        gps = LIGOTimeGPS(123456789, 500000000)
        result = np.npencode(gps)
        assert result.dtype == np.gpstype
        assert result["s"][0] == 123456789
        assert result["ns"][0] == 500000000

    def test_npencode_real8frequencyseries(self):
        """Test encoding REAL8FrequencySeries (line 136)"""
        import lal

        # Create a REAL8FrequencySeries
        series = lal.CreateREAL8FrequencySeries(
            name="test_series",
            epoch=LIGOTimeGPS(1000),
            f0=0.0,
            deltaF=1.0,
            sampleUnits=lal.HertzUnit,
            length=10,
        )
        series.data.data[:] = numpy.arange(10)

        result = np.npencode(series)
        assert result["__type__"] == b"r8f"
        assert result["name"] == b"test_series"
        assert result["length"] == 10
        numpy.testing.assert_array_equal(result["data"], numpy.arange(10))

    def test_npencode_string(self):
        """Test encoding string"""
        result = np.npencode("test_string")
        assert result == b"test_string"

    def test_npencode_array(self):
        """Test encoding regular array"""
        arr = numpy.array([1, 2, 3])
        result = np.npencode(arr)
        numpy.testing.assert_array_equal(result, arr)

    def test_npencode_deprecation_warning(self):
        """Test encoding with ragged list triggers exception handling (lines 144-145)"""

        # Mock numpy.array to raise ValueError (as numpy 2.x does for ragged lists)
        def mock_array(obj, *args, **kwargs):
            if isinstance(obj, list) and any(isinstance(x, list) for x in obj):
                raise ValueError("inhomogeneous shape")
            return numpy.array(obj, *args, **kwargs)

        import io
        import sys

        # Capture print output
        captured_output = io.StringIO()
        old_stdout = sys.stdout
        sys.stdout = captured_output

        try:
            with mock.patch("numpy.array", side_effect=mock_array):
                # This will trigger the exception handling and print
                result = np.npencode([[1, 2], [3, 4, 5]])
                # The function returns None when exception occurs
                assert result is None
        finally:
            sys.stdout = old_stdout

        # Verify the object was printed (line 145)
        output = captured_output.getvalue()
        assert "[[1, 2], [3, 4, 5]]" in output

    def test_dict2np(self):
        """Test dict2np function (lines 149-156)"""
        d = {
            "int_val": 42,
            "float_val": 3.14,
            "array_val": numpy.array([1, 2, 3]),
            "nested": {"a": 1},
        }
        result = np.dict2np(d)
        assert result["int_val"] == 42
        assert result["float_val"] == 3.14
        numpy.testing.assert_array_equal(result["array_val"], [1, 2, 3])

    def test_seglist2np(self):
        """Test seglist2np function"""
        seg = segments.segment(LIGOTimeGPS(1000, 100), LIGOTimeGPS(2000, 200))
        seglist = segments.segmentlist([seg])

        result = np.seglist2np(seglist)
        assert result[0]["start"]["s"] == 1000
        assert result[0]["start"]["ns"] == 100
        assert result[0]["end"]["s"] == 2000
        assert result[0]["end"]["ns"] == 200

    def test_gps2np(self):
        """Test gps2np function"""
        gps = LIGOTimeGPS(999999999, 123456789)
        result = np.gps2np(gps)
        assert result["s"][0] == 999999999
        assert result["ns"][0] == 123456789

    def test_r8f2np(self):
        """Test r8f2np function"""
        import lal

        series = lal.CreateREAL8FrequencySeries(
            name="test",
            epoch=LIGOTimeGPS(1234567890),
            f0=10.0,
            deltaF=0.5,
            sampleUnits=lal.Unit("strain"),
            length=5,
        )
        series.data.data[:] = [1, 2, 3, 4, 5]

        result = np.r8f2np(series)
        assert result["__type__"] == b"r8f"
        assert result["name"] == b"test"
        assert result["f0"] == 10.0
        assert result["deltaF"] == 0.5
        assert result["length"] == 5
        numpy.testing.assert_array_equal(result["data"], [1, 2, 3, 4, 5])


class TestDecoding:
    """Test numpy array decoding functions"""

    def test_npdecode_segmentlist(self):
        """Test decoding segment list (line 202)"""
        # Create encoded segment list
        seg = segments.segment(LIGOTimeGPS(1000), LIGOTimeGPS(2000))
        seglist = segments.segmentlist([seg])
        encoded = np.seglist2np(seglist)

        # Decode it
        decoded = np.npdecode(encoded)
        assert isinstance(decoded, segments.segmentlist)
        assert len(decoded) == 1
        assert decoded[0][0] == LIGOTimeGPS(1000)
        assert decoded[0][1] == LIGOTimeGPS(2000)

    def test_npdecode_gps(self):
        """Test decoding GPS (line 204)"""
        gps = LIGOTimeGPS(1234567890, 500000000)
        encoded = np.gps2np(gps)

        decoded = np.npdecode(encoded)
        assert isinstance(decoded, LIGOTimeGPS)
        assert decoded == gps

    def test_npdecode_real8frequencyseries(self):
        """Test decoding REAL8FrequencySeries (lines 205-210)"""
        import lal

        # Create and encode series
        series = lal.CreateREAL8FrequencySeries(
            name="decode_test",
            epoch=LIGOTimeGPS(2000000000),
            f0=20.0,
            deltaF=0.25,
            sampleUnits=lal.Unit("count"),
            length=3,
        )
        series.data.data[:] = [10, 20, 30]
        encoded = np.r8f2np(series)

        # Decode it
        decoded = np.npdecode(encoded)
        assert isinstance(decoded, lal.REAL8FrequencySeries)
        # Name is decoded as string from bytes
        assert "decode_test" in str(decoded.name)
        assert decoded.f0 == 20.0
        assert decoded.deltaF == 0.25
        assert decoded.data.length == 3
        numpy.testing.assert_array_equal(decoded.data.data, [10, 20, 30])

    def test_npdecode_event_types(self):
        """Test decoding event types (line 212)"""
        # Create event data
        event_data = numpy.zeros(1, dtype=np.event_type)
        event_data["id"] = b"test_event_001"
        event_data["snr"] = 15.5

        decoded = np.npdecode(event_data)
        assert decoded is event_data  # Should return unchanged

        # Test sim_type
        sim_data = numpy.zeros(1, dtype=np.sim_type)
        sim_data["mass1"] = 30.0
        decoded_sim = np.npdecode(sim_data)
        assert decoded_sim is sim_data

        # Test injection_event_type
        inj_data = numpy.zeros(1, dtype=np.injection_event_type)
        decoded_inj = np.npdecode(inj_data)
        assert decoded_inj is inj_data

    def test_npdecode_dict(self):
        """Test decoding dictionary (line 214)"""
        # Create a structured array with named fields
        dtype = numpy.dtype([("x", "f8"), ("y", "i4"), ("name", "S10")])
        arr = numpy.array((3.14, 42, b"test"), dtype=dtype)

        decoded = np.npdecode(arr)
        assert isinstance(decoded, dict)
        assert decoded["x"] == 3.14
        assert decoded["y"] == 42
        assert decoded["name"] == "test"

    def test_npdecode_string(self):
        """Test decoding string"""
        encoded = numpy.array("hello", dtype="S10")
        decoded = np.npdecode(encoded)
        assert decoded == "hello"

    def test_npdecode_scalar(self):
        """Test decoding scalar"""
        # Test scalar integer
        scalar_int = numpy.array(42)
        assert np.npdecode(scalar_int) == 42

        # Test scalar float
        scalar_float = numpy.array(3.14)
        assert np.npdecode(scalar_float) == 3.14

    def test_npdecode_array(self):
        """Test decoding regular array"""
        arr = numpy.array([1, 2, 3, 4, 5])
        decoded = np.npdecode(arr)
        numpy.testing.assert_array_equal(decoded, arr)

    def test_np2seglist(self):
        """Test np2seglist function (line 224)"""
        # Create encoded segment list
        seg_array = numpy.array(
            [((1000, 0), (2000, 0)), ((3000, 500), (4000, 1000))],
            dtype=np.gpsseglisttype,
        )

        result = np.np2seglist(seg_array)
        assert len(result) == 2
        assert result[0][0] == LIGOTimeGPS(1000, 0)
        assert result[0][1] == LIGOTimeGPS(2000, 0)
        assert result[1][0] == LIGOTimeGPS(3000, 500)
        assert result[1][1] == LIGOTimeGPS(4000, 1000)

    def test_np2gps(self):
        """Test np2gps function"""
        gps_array = numpy.array((1500000000, 750000000), dtype=np.gpstype)
        result = np.np2gps(gps_array)
        assert result.gpsSeconds == 1500000000
        assert result.gpsNanoSeconds == 750000000

    def test_np2r8f(self):
        """Test np2r8f function"""
        import lal

        # Create encoded series manually
        encoded = numpy.zeros(1, dtype=np.r8ftype(4))
        encoded["__type__"] = b"r8f"
        encoded["name"] = b"test_decode"
        encoded["epoch"] = (1000000000, 0)
        encoded["f0"] = 5.0
        encoded["deltaF"] = 2.0
        encoded["sampleUnits"] = b"strain"
        encoded["length"] = 4
        encoded["data"] = [[1.1, 2.2, 3.3, 4.4]]

        result = np.np2r8f(encoded[0])
        assert isinstance(result, lal.REAL8FrequencySeries)
        assert "test_decode" in str(result.name)
        assert result.f0 == 5.0
        assert result.deltaF == 2.0
        assert result.data.length == 4
        numpy.testing.assert_array_almost_equal(result.data.data, [1.1, 2.2, 3.3, 4.4])


class TestCoverageCompletion:
    """Tests to complete coverage for remaining lines"""

    def test_npdecode_complete_coverage(self):
        """Test all branches of npdecode to achieve 100% coverage"""
        # Test line 201 - gpsseglisttype check passes
        seg_array = numpy.array([((1000, 0), (2000, 0))], dtype=np.gpsseglisttype)
        result = np.npdecode(seg_array)
        assert isinstance(result, segments.segmentlist)

        # Test line 203 - gpstype check passes
        gps_array = numpy.array((1234567890, 500000000), dtype=np.gpstype)
        result = np.npdecode(gps_array)
        assert isinstance(result, LIGOTimeGPS)

        # Test lines 205-210 - r8f type
        import lal

        series = lal.CreateREAL8FrequencySeries(
            name="test",
            epoch=LIGOTimeGPS(1000),
            f0=1.0,
            deltaF=1.0,
            sampleUnits=lal.HertzUnit,
            length=3,
        )
        series.data.data[:] = [1, 2, 3]
        encoded = np.r8f2np(series)
        decoded = np.npdecode(encoded)
        assert isinstance(decoded, lal.REAL8FrequencySeries)

        # Test line 211-212 - event types
        event = numpy.zeros(1, dtype=np.event_type)
        assert np.npdecode(event) is event

        sim = numpy.zeros(1, dtype=np.sim_type)
        assert np.npdecode(sim) is sim

        inj = numpy.zeros(1, dtype=np.injection_event_type)
        assert np.npdecode(inj) is inj

        # Test line 213-214 - named fields (dict conversion)
        dtype = numpy.dtype([("x", "f8"), ("y", "i4")])
        arr = numpy.array((3.14, 42), dtype=dtype)
        result = np.npdecode(arr)
        assert isinstance(result, dict)
        assert result["x"] == 3.14
        assert result["y"] == 42

        # Test line 215-216 - string type
        str_arr = numpy.array("hello world", dtype="S20")
        result = np.npdecode(str_arr)
        assert result == "hello world"

        # Test line 217-218 - scalar
        scalar = numpy.array(42.5)
        result = np.npdecode(scalar)
        assert result == 42.5

        # Test line 219-220 - regular array
        arr = numpy.array([1, 2, 3, 4, 5])
        result = np.npdecode(arr)
        numpy.testing.assert_array_equal(result, arr)

    def test_np2seglist_coverage(self):
        """Test np2seglist function for line 224"""
        # Create a segment list array
        seg_array = numpy.array(
            [((1000, 100), (2000, 200)), ((3000, 300), (4000, 400))],
            dtype=np.gpsseglisttype,
        )

        result = np.np2seglist(seg_array)
        assert len(result) == 2
        assert result[0][0].gpsSeconds == 1000
        assert result[0][0].gpsNanoSeconds == 100
        assert result[1][1].gpsSeconds == 4000
        assert result[1][1].gpsNanoSeconds == 400

    def test_np2gps_coverage(self):
        """Test np2gps function for line 228"""
        gps_array = numpy.array((987654321, 123456789), dtype=np.gpstype)
        result = np.np2gps(gps_array)
        assert result.gpsSeconds == 987654321
        assert result.gpsNanoSeconds == 123456789

    def test_np2r8f_coverage(self):
        """Test np2r8f function for lines 232-241"""
        import lal

        # Create a complete encoded array
        encoded = numpy.zeros(1, dtype=np.r8ftype(5))
        encoded["__type__"] = b"r8f"
        encoded["name"] = b"test_series"
        encoded["epoch"] = (1234567890, 987654321)
        encoded["f0"] = 10.5
        encoded["deltaF"] = 0.25
        encoded["sampleUnits"] = b"strain"
        encoded["length"] = 5
        encoded["data"] = [[1.1, 2.2, 3.3, 4.4, 5.5]]

        # Decode it
        result = np.np2r8f(encoded[0])

        # Verify all fields
        assert isinstance(result, lal.REAL8FrequencySeries)
        assert "test_series" in str(result.name)
        assert result.epoch.gpsSeconds == 1234567890
        assert result.epoch.gpsNanoSeconds == 987654321
        assert result.f0 == 10.5
        assert result.deltaF == 0.25
        assert result.data.length == 5
        numpy.testing.assert_array_almost_equal(
            result.data.data[:5], [1.1, 2.2, 3.3, 4.4, 5.5]
        )


class TestIntegration:
    """Integration tests for encode/decode round trips"""

    def test_roundtrip_complex_dict(self):
        """Test encoding and decoding complex dictionary"""
        import lal

        # Create complex data structure
        series = lal.CreateREAL8FrequencySeries(
            name="roundtrip",
            epoch=LIGOTimeGPS(1234567890),
            f0=0.0,
            deltaF=1.0,
            sampleUnits=lal.HertzUnit,
            length=5,
        )
        series.data.data[:] = [1, 2, 3, 4, 5]

        seglist = segments.segmentlist(
            [
                segments.segment(LIGOTimeGPS(1000), LIGOTimeGPS(2000)),
                segments.segment(LIGOTimeGPS(3000), LIGOTimeGPS(4000)),
            ]
        )

        data = {
            "series": series,
            "segments": seglist,
            "gps": LIGOTimeGPS(999999999),
            "array": numpy.array([1, 2, 3]),
            "string": "test_string",
            "number": 42.0,
        }

        # Encode
        encoded = np.npencode(data)

        # Decode
        decoded = np.npdecode(encoded)

        # Verify
        assert isinstance(decoded, dict)
        assert isinstance(decoded["series"], lal.REAL8FrequencySeries)
        assert "roundtrip" in str(decoded["series"].name)
        assert isinstance(decoded["segments"], segments.segmentlist)
        assert len(decoded["segments"]) == 2
        assert decoded["gps"] == LIGOTimeGPS(999999999)
        numpy.testing.assert_array_equal(decoded["array"], [1, 2, 3])
        assert decoded["string"] == "test_string"
        assert decoded["number"] == 42.0

    def test_nested_structures(self):
        """Test deeply nested structures"""
        nested = {
            "level1": {
                "level2": {"gps": LIGOTimeGPS(1000), "array": numpy.array([1, 2, 3])}
            },
            "seglist": segments.segmentlist(
                [segments.segment(LIGOTimeGPS(0), LIGOTimeGPS(100))]
            ),
        }

        encoded = np.npencode(nested)
        decoded = np.npdecode(encoded)

        assert decoded["level1"]["level2"]["gps"] == LIGOTimeGPS(1000)
        numpy.testing.assert_array_equal(
            decoded["level1"]["level2"]["array"], [1, 2, 3]
        )
        assert len(decoded["seglist"]) == 1
