# Copyright (C) 2020-2021 Chad Hanna
# Copyright (C) 2014 Miguel Fernandez, Chad Hanna
# Copyright (C) 2016,2017 Kipp Cannon, Miguel Fernandez, Chad Hanna,
# Stephen Privitera, Jonathan Wang
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2 of the License, or (at your
# option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
# Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
"""CBC Source"""

from __future__ import annotations

import bisect
import logging
from typing import Any, Dict, Generator, List, Optional, Tuple, Union

import lal  # type: ignore[import-untyped]
import lalsimulation as lalsim  # type: ignore[import-untyped]
import numpy
from ligo.lw import ligolw, lsctables, utils  # type: ignore[import-untyped]
from ligo.lw.utils import process as ligolw_process  # type: ignore[import-untyped]
from numpy import log10 as l10
from scipy.interpolate import PPoly, splrep  # type: ignore[import-untyped]
from scipy.special import logsumexp  # type: ignore[import-untyped]

from sgn_manifold import coordinate, cover, io, metric, signal


# Constants for CBC calculations
class CBCConstants:
    """Constants used throughout CBC calculations."""

    # Spin/chi limits
    CHI_MAX = 0.997  # Maximum chi value for metric stability
    CHI_WARNING_THRESHOLD = 0.997  # Threshold for chi warning messages
    CHI_CLAMP_MIN = -0.999  # Minimum chi value for LAL compatibility
    CHI_CLAMP_MAX = 0.999  # Maximum chi value for LAL compatibility

    # Mass parameters
    MASS_TOLERANCE_FACTOR = 1.05  # 5% tolerance for mass comparisons
    PN_MASS_TO_SECONDS = 5e-6  # Convert solar masses to seconds

    # Frequency parameters
    DEFAULT_F_FINAL = 1024.0  # Hz, default final frequency

    # Numerical parameters
    TARGET_MATCH_EPS_FACTOR = 0.7  # Factor for floating point epsilon in target match

    # Bank parameters
    MAX_TEMPLATE_ID = 9999999  # Maximum allowed template ID
    DEFAULT_NEIGHBOR_COUNT = 100000  # Default number of neighbors to check
    DEFAULT_NEIGHBOR_COUNT_SMALL = 30000  # Smaller neighbor count for some operations
    DEFAULT_NEIGHBOR_COUNT_TINY = 1000  # Tiny neighbor count for adjacent operations

    # Grid parameters
    DEFAULT_BASE_STEP = 0.01  # Default step size for grid operations
    DEFAULT_MIN_EIG_VAL = 0.0  # Default minimum eigenvalue


# Define CBC Coordinate Types


class M1(coordinate.CoordinateType):
    """Mass 1"""

    key = "m1"


class M2(coordinate.CoordinateType):
    """Mass 2"""

    key = "m2"


class LogM1(coordinate.CoordinateType):
    """Log10 Mass 1"""

    key = "log10m1"


class LogM2(coordinate.CoordinateType):
    """Log10 Mass 2"""

    key = "log10m2"


class S1X(coordinate.CoordinateType):
    """Spin 1 x-component"""

    key = "S1x"


class S1Y(coordinate.CoordinateType):
    """Spin 1 y-component"""

    key = "S1y"


class S1Z(coordinate.CoordinateType):
    """Spin 1 z-component"""

    key = "S1z"


class S2X(coordinate.CoordinateType):
    """Spin 2 x-component"""

    key = "S2x"


class S2Y(coordinate.CoordinateType):
    """Spin 2 y-component"""

    key = "S2y"


class S2Z(coordinate.CoordinateType):
    """Spin 2 z-component"""

    key = "S2z"


class Chi(coordinate.CoordinateType):
    key = "chi"


class MC(coordinate.CoordinateType):
    key = "mc"


#
# Utility functions to help with the coordinate system for evaluating the
# waveform metric
#


def chirpmass(m1, m2):
    return (m1 * m2) ** 0.6 / (m1 + m2) ** 0.2


def z_from_m1_m2_s1_s2(m1, m2, s1, s2):
    m1 = float(m1)
    m2 = float(m2)
    s1 = float(s1)
    s2 = float(s2)
    M = m1 + m2
    return (s1 * m1 + s2 * m2) / M


CBC_COORD_TRANSFORMS = {
    # Mapping of (from types), (to types): transform function
    ((M1,), (LogM1,)): l10,
    ((M2,), (LogM2,)): l10,
    ((LogM1,), (M1,)): lambda x: 10**x,
    ((LogM2,), (M2,)): lambda x: 10**x,
    ((M1, M2), (MC,)): chirpmass,
    ((M1, M2, S1Z, S2Z), (Chi,)): z_from_m1_m2_s1_s2,
}


class CBCCoordFunc(coordinate.CoordFunc):
    _STANDARD_COORD_TYPES = (
        M1,
        M2,
        S1X,
        S1Y,
        S1Z,
        S2X,
        S2Y,
        S2Z,
    )

    def dx(self, c: coordinate.Coordinates) -> numpy.ndarray:
        return numpy.array(metric.DELTA * numpy.ones(len(c)))

    # Default implementations to reduce duplication in subclasses
    @property
    def min_eig_val(self):
        """Default minimum eigenvalue for CBC coordinate functions."""
        return CBCConstants.DEFAULT_MIN_EIG_VAL

    def base_step(self, coords):
        """Default base step for CBC coordinate functions."""
        return CBCConstants.DEFAULT_BASE_STEP

    def target_match(self, c):
        """Default target match for CBC coordinate functions."""
        return (
            1.0 - CBCConstants.TARGET_MATCH_EPS_FACTOR * numpy.finfo(numpy.float32).eps
        )

    def random(self):
        # TODO find a smarter way to draw uniformly over chi
        # might be a bad idea if people have very different priors for the
        # two components
        if self.to_bounds is None:
            raise ValueError("to_bounds must be set to generate random samples")

        if S1Z in self.to_bounds:
            s = numpy.random.uniform(
                min(self.to_bounds[S1Z][0], self.to_bounds[S2Z][0]),
                max(self.to_bounds[S1Z][1], self.to_bounds[S2Z][1]),
            )
        else:
            s = 0
        m1 = 10 ** numpy.random.uniform(
            numpy.log10(self.to_bounds[M1][0]), numpy.log10(self.to_bounds[M1][1])
        )
        m2 = 10 ** numpy.random.uniform(
            numpy.log10(self.to_bounds[M2][0]), numpy.log10(m1)
        )
        rp = {M1: m1, M2: m2, S1Z: s, S2Z: s, S1X: 0.0, S1Y: 0.0, S2X: 0.0, S2Y: 0.0}
        if rp[M1] < rp[M2]:
            m1, s1x, s1y, s1z = rp[M1], rp[S1X], rp[S1Y], rp[S1Z]
            rp[M1], rp[S1X], rp[S1Y], rp[S1Z] = rp[M2], rp[S2X], rp[S2Y], rp[S2Z]
            rp[M2], rp[S2X], rp[S2Y], rp[S2Z] = m1, s1x, s1y, s1z
        return rp


class M1M2(CBCCoordFunc):
    key = "m1_m2"

    TO_TYPES = (M1, M2)
    FROM_TYPES = (M1, M2)

    def __call__(
        self,
        c: Union[coordinate.Coordinates, coordinate.CoordsDict, numpy.ndarray],
        inv: bool = False,
    ) -> Union[coordinate.CoordsDict, numpy.ndarray, List[coordinate.CoordsDict]]:
        if inv:
            if isinstance(c, dict):
                c_dict = self._normalize_coorddict(c, inv=True)
            else:
                # Convert array/Coordinates to dict first
                c_array = (
                    coordinate.to_array(c)
                    if isinstance(c, coordinate.Coordinates)
                    else c
                )
                if len(c_array.shape) > 1:
                    raise ValueError(
                        "Cannot convert multi-dimensional array to dict for inv=True"
                    )
                # Assume it's m1, m2 order
                c_dict = {M1: float(c_array[0]), M2: float(c_array[1])}
            m1, m2 = c_dict[M1], c_dict[M2]
            return numpy.array([m1, m2])
        else:
            # When inv=False, c can be Coordinates, ndarray, or dict
            if isinstance(c, coordinate.Coordinates):
                c_array = coordinate.to_array(c)
            elif isinstance(c, numpy.ndarray):
                c_array = c
            elif isinstance(c, dict):
                # Handle dict input by extracting m1, m2 values
                c_dict = self._normalize_coorddict(c, inv=False)
                if M1 in c_dict and M2 in c_dict:
                    c_array = numpy.array([c_dict[M1], c_dict[M2]])
                else:
                    raise ValueError("Dict must contain M1 and M2 keys")
            else:
                raise TypeError(
                    f"Expected Coordinates, ndarray, or dict, got {type(c)}"
                )

            if len(c_array.shape) == 1:
                m1 = c_array[0]
                m2 = c_array[1]
                # Add default spin values of 0
                return {M1: float(m1), M2: float(m2), S1Z: 0.0, S2Z: 0.0}
            else:
                m1_array: numpy.ndarray = c_array[..., 0]
                m2_array: numpy.ndarray = c_array[..., 1]
                return [
                    {M1: float(a), M2: float(b), S1Z: 0.0, S2Z: 0.0}
                    for (a, b) in zip(m1_array, m2_array)
                ]


class Log10M1Log10M2(CBCCoordFunc):
    key = "log10m1_log10m2"

    TO_TYPES = (M1, M2)
    FROM_TYPES = (LogM1, LogM2)

    def __call__(
        self,
        c: Union[coordinate.Coordinates, coordinate.CoordsDict, numpy.ndarray],
        inv: bool = False,
    ) -> Union[coordinate.CoordsDict, numpy.ndarray, List[coordinate.CoordsDict]]:
        if inv:
            if isinstance(c, dict):
                c_dict = self._normalize_coorddict(c, inv=True)
            else:
                # Convert array/Coordinates to dict first
                c_array = (
                    coordinate.to_array(c)
                    if isinstance(c, coordinate.Coordinates)
                    else c
                )
                if len(c_array.shape) > 1:
                    raise ValueError(
                        "Cannot convert multi-dimensional array to dict for inv=True"
                    )
                # Assume it's log10(m1), log10(m2) order
                c_dict = {M1: 10 ** float(c_array[0]), M2: 10 ** float(c_array[1])}
            m1, m2 = c_dict[M1], c_dict[M2]
            return numpy.array([l10(m1), l10(m2)])
        else:
            # When inv=False, c is Coordinates or ndarray, not dict
            if isinstance(c, coordinate.Coordinates):
                c_array = coordinate.to_array(c)
            elif isinstance(c, numpy.ndarray):
                c_array = c
            else:
                raise TypeError(f"Expected Coordinates or ndarray, got {type(c)}")

            if len(c_array.shape) == 1:
                m1 = 10 ** c_array[0]
                m2 = 10 ** c_array[1]
                return {M1: float(m1), M2: float(m2)}
            else:
                m1_array: numpy.ndarray = 10 ** c_array[..., 0]
                m2_array: numpy.ndarray = 10 ** c_array[..., 1]
                return [
                    {M1: a, M2: b} for (a, b) in numpy.array([m1_array, m2_array]).T
                ]


class Log10M1Log10M2Chi(CBCCoordFunc):
    key = "log10m1_log10m2_chi"

    TO_TYPES = (M1, M2, S1Z, S2Z)
    FROM_TYPES = (LogM1, LogM2, Chi)

    def __init__(self, **kwargs):
        """Initialize with bounds, clipping extreme chi values.

        Accepts either:
        - log10m1, log10m2, chi (for direct instantiation)
        - m1, m2, S1z, S2z (from command-line tool via bounds_from_lists)
        """
        # BOUNDARY HANDLING: Clip extreme spin values to avoid singularities
        chi_max = CBCConstants.CHI_MAX  # Metrics become unstable for |chi| > CHI_MAX

        # Handle different calling conventions
        if "S1z" in kwargs and "S2z" in kwargs:
            # Called from command-line tool with m1, m2, S1z, S2z
            # S1z and S2z bounds represent the chi bounds
            s1z_bounds = kwargs.get("S1z", (-1.0, 1.0))
            s2z_bounds = kwargs.get("S2z", (-1.0, 1.0))

            # Clip the spin bounds
            kwargs["S1z"] = (max(s1z_bounds[0], -chi_max), min(s1z_bounds[1], chi_max))
            kwargs["S2z"] = (max(s2z_bounds[0], -chi_max), min(s2z_bounds[1], chi_max))

            if s1z_bounds[0] < -chi_max or s1z_bounds[1] > chi_max:
                import warnings

                warnings.warn(
                    f"Log10M1Log10M2Chi: Clipping spin bounds to "
                    f"[-{chi_max}, {chi_max}] to avoid singularities. "
                    f"Metrics are unstable for |chi| > {chi_max}.",
                    UserWarning,
                    stacklevel=2,
                )

        elif "chi" in kwargs:
            # Called directly with log10m1, log10m2, chi
            chi_bounds = kwargs.get("chi", (-1.0, 1.0))
            chi_clipped = (max(chi_bounds[0], -chi_max), min(chi_bounds[1], chi_max))
            kwargs["chi"] = chi_clipped

            if chi_bounds[0] < -chi_max or chi_bounds[1] > chi_max:
                import warnings

                warnings.warn(
                    f"Log10M1Log10M2Chi: Clipping chi bounds from {chi_bounds} "
                    f"to {chi_clipped} to avoid singularities. "
                    f"Metrics are unstable for |chi| > {chi_max}.",
                    UserWarning,
                    stacklevel=2,
                )

        # Call parent __init__ with modified kwargs
        super().__init__(**kwargs)

    def __call__(
        self,
        c: Union[coordinate.Coordinates, coordinate.CoordsDict, numpy.ndarray],
        inv: bool = False,
    ) -> Union[coordinate.CoordsDict, numpy.ndarray, List[coordinate.CoordsDict]]:
        if inv:
            if isinstance(c, dict):
                c_dict = self._normalize_coorddict(c, inv=True)
            else:
                # Convert array/Coordinates to dict first
                c_array = (
                    coordinate.to_array(c)
                    if isinstance(c, coordinate.Coordinates)
                    else c
                )
                if len(c_array.shape) > 1:
                    raise ValueError(
                        "Cannot convert multi-dimensional array to dict for inv=True"
                    )
                # Assume it's log10(m1), log10(m2), chi order
                # Need to calculate s1z, s2z from chi
                m1 = 10 ** float(c_array[0])
                m2 = 10 ** float(c_array[1])
                chi = float(c_array[2])
                # Assuming equal aligned spins: s1z = s2z = chi
                s1z = s2z = chi
                c_dict = {M1: m1, M2: m2, S1Z: s1z, S2Z: s2z}
            m1, m2, s1, s2 = c_dict[M1], c_dict[M2], c_dict[S1Z], c_dict[S2Z]
            chi = z_from_m1_m2_s1_s2(m1, m2, s1, s2)
            return numpy.array([l10(m1), l10(m2), chi])
        else:
            # When inv=False, c is Coordinates or ndarray, not dict
            if isinstance(c, coordinate.Coordinates):
                c_array = coordinate.to_array(c)
            elif isinstance(c, numpy.ndarray):
                c_array = c
            else:
                raise TypeError(f"Expected Coordinates or ndarray, got {type(c)}")

            if len(c_array.shape) == 1:
                m1 = 10 ** c_array[0]
                m2 = 10 ** c_array[1]
                chi = c_array[2]
                # Calculate s1z, s2z from chi (assuming equal aligned spins)
                s1z = s2z = chi
                return {M1: float(m1), M2: float(m2), S1Z: float(s1z), S2Z: float(s2z)}
            else:
                m1_array: numpy.ndarray = 10 ** c_array[..., 0]
                m2_array: numpy.ndarray = 10 ** c_array[..., 1]
                chi_array: numpy.ndarray = c_array[..., 2]
                # Calculate s1z, s2z from chi (assuming equal aligned spins)
                s1z_array = s2z_array = chi_array
                return [
                    {M1: float(a), M2: float(b), S1Z: float(c), S2Z: float(d)}
                    for (a, b, c, d) in zip(m1_array, m2_array, s1z_array, s2z_array)
                ]

    def mass_model(self, r, model=None, **kwargs):
        if model == "salpeter":
            return self._salpeter(
                r,
                m_min=0.80 if "m_min" not in kwargs else kwargs["m_min"],
                cuts=None if "cuts" not in kwargs else kwargs["cuts"],
            )
        if model == "power-law":
            return self._power_law(
                r,
                index=kwargs["index"],
                m_min=0.80 if "m_min" not in kwargs else kwargs["m_min"],
                cuts=None if "cuts" not in kwargs else kwargs["cuts"],
            )
        raise ValueError("model not one of salpeter, power_law")

    def _salpeter(self, r, m_min=0.80, cuts=None):
        return self._power_law(r, index=-2.35, m_min=m_min, cuts=cuts)

    def _power_law(self, r, index=-2.35, m_min=0.80, cuts=None):
        result = self(r.center)
        if not isinstance(result, dict):
            raise TypeError("Coordinate function must return dict for mass models")
        c = result
        _m1, _m2, _x1, _x2 = c[M1], c[M2], c[S1Z], c[S2Z]
        if _m2 > _m1:
            m1, m2, x1, x2 = _m2, _m1, _x2, _x1
        else:
            m1, m2, x1, x2 = _m1, _m2, _x1, _x2
        assert (
            m2 > CBCConstants.MASS_TOLERANCE_FACTOR * m_min
        )  # NOTE THIS 5% tolerance is arbitrary but meant to prevent people
        # from getting an infinite probability.
        volume = (
            (10 ** r.maxes[0] - 10 ** r.mins[0])
            * (10 ** r.maxes[1] - 10 ** r.mins[1])
            * r.coordinate_size[2]
        )
        chi = (m1 * x1 + m2 * x2) / (m1 + m2)
        if cuts is not None:
            prob = 0.0
            minchi = (m1 * cuts["x1"][0] + m2 * cuts["x2"][0]) / (m1 + m2)
            maxchi = (m1 * cuts["x1"][1] + m2 * cuts["x2"][1]) / (m1 + m2)
            if (
                (cuts["m1"][0] <= m1 <= cuts["m1"][1])
                and (cuts["m2"][0] <= m2 <= cuts["m2"][1])
                and (minchi <= chi <= maxchi)
            ):
                prob = m1**index * volume / (m1 - m_min)
        else:
            prob = m1**index * volume / (m1 - m_min)
        return (m1, m2, chi), prob

    def array_to_coord_dict(self, a):
        """Assumes s1z = s2z = chi"""
        return {M1: a[0], M2: a[1], S1Z: a[2], S2Z: a[2]}


#
# Metric object that numerically evaluates the waveform metric
#


class CBCMetric(metric.Metric):
    """
    Class to numerically evaluate the compact binary parameter space metric.

    Parameters
    ----------
    psd: REAL8FrequencySeries
        A LAL type holding a PSD
    coord_func: coord_func
        A coord_func or derived class that specifies the coordinate transformation.
    duration: int, default4
        The duration of waveform to produce
    flow: float, default=15.
        The minimum frequency of the integration
    fhigh: float, default=512
        The maximum frequency of the integration
    approximant: str, default="IMRPhenomD"
        Currently only TaylorF2 and IMRPhenomD are supported

    Examples
    --------
    >>> psd = io.h5read('test_data/H1L1-MASS_BBH-1185149070-800.h5', 'psd')['L1']
    >>> bounds = {"m1":[1., 100.], "m2":[1., 100.], "S1z":[-1., 1.], "S2z":[-1., 1.]}
    >>> cfunc = metric.m1_m2_s1z_s2z(bounds)
    >>> g = metric.CBCMetric(psd, cfunc)
    >>> g([1.4, 1.4, 0, 0])
    array([[ 4.34726584e+05,  4.34725714e+05, -8.52915457e+03,
            -8.52915457e+03],
           [ 4.34725714e+05,  4.34726584e+05, -8.52915457e+03,
            -8.52915457e+03],
           [-8.52915457e+03, -8.52915457e+03,  1.82025977e+02,
             1.81156190e+02],
           [-8.52915457e+03, -8.52915457e+03,  1.81156190e+02,
             1.82025977e+02]])
    """

    WAVEFORM_COORDS = (M1, M2, S1X, S1Y, S1Z, S2X, S2Y, S2Z)
    WAVEFORM_COORD_DEFAULTS = {
        S1X: 0.0,
        S1Y: 0.0,
        S1Z: 0.0,
        S2X: 0.0,
        S2Y: 0.0,
        S2Z: 0.0,
    }

    def __init__(
        self,
        psd: Optional[lal.REAL8FrequencySeries] = None,
        coord_func: Optional[CBCCoordFunc] = None,
        flow: float = 15.0,
        fhigh: float = 512.0,
        approximant: str = "IMRPhenomD",
        max_metric_diff: float = metric.DEFAULT_MAX_DIFF_THRESHOLD,
        max_duration: float = numpy.inf,
    ) -> None:
        self.appxstr = approximant
        self.approximant = lalsim.GetApproximantFromString(approximant)
        self.max_duration = max_duration
        # CBCCoordFunc is a subclass of CoordFunc so this is safe
        metric.Metric.__init__(
            self,
            psd,
            coord_func,  # type: ignore[arg-type]
            flow,
            fhigh,
            max_metric_diff=max_metric_diff,
        )

    def _to_dict(self):
        coord_func_dict = {}
        if hasattr(self.coord_func, "key") and hasattr(self.coord_func, "to_dict"):
            coord_func_dict = {self.coord_func.key: self.coord_func.to_dict()}
        return {
            "psd": self.psd,
            "coord_func": coord_func_dict,
            "flow": self.freq_low,
            "fhigh": self.freq_high,
            "approximant": self.appxstr,
            "max_metric_diff": self.max_diff_threshold,
            "max_duration": self.max_duration,
        }

    @classmethod
    def _from_dict(cls, d):
        # FIXME this is silly - fix how we encode these objects generally and
        # especially the coord functions
        k, v = tuple(d["coord_func"].items())[0]
        d["coord_func"] = coord_funcs[k](**v)

        # FIXME make sure approximate is a string not bytes
        if isinstance(d["approximant"], bytes):
            d["approximant"] = d["approximant"].decode("utf-8")
        return cls(**d)

    def waveform(
        self, c: coordinate.Coordinates
    ) -> Optional[lal.COMPLEX16FrequencySeries]:

        # FIXME replace with something more accurate
        def f_at_t(mc, t):
            M = mc * 4.93e-6  # convert solar mass to seconds
            return 1 / numpy.pi / M * (5.0 / 256 * M / t) ** (3.0 / 8)

        # Generalize to different waveform coords
        result = self.coord_func(c)
        # Should always return a dict for single coordinate point
        if not isinstance(result, dict):
            raise TypeError(f"Expected dict from coord_func, got {type(result)}")
        parameters: coordinate.CoordsDict = result

        # Figure out if we need to adjust the low frequency to limit waveform duration
        if numpy.isfinite(self.max_duration):
            flow = max(
                f_at_t(
                    chirpmass(parameters[M1], parameters[M2]),
                    self.max_duration,
                ),
                self.freq_low,
            )
        else:
            flow = self.freq_low

        try:
            # Convert coordinate types to regular dict with string keys for LAL
            params_dict: Dict[str, Any] = {}
            for k, v in parameters.items():
                if isinstance(k, type) and issubclass(k, coordinate.CoordinateType):
                    params_dict[k.key] = v
                else:
                    params_dict[str(k)] = v

            # Scale masses to SI units
            params_dict["m1"] = parameters[M1] * lal.MSUN_SI
            params_dict["m2"] = parameters[M2] * lal.MSUN_SI

            # Copy spin parameters with string keys
            # For aligned spin systems, x and y components should be zero
            params_dict["S1x"] = 0.0
            params_dict["S1y"] = 0.0
            params_dict["S2x"] = 0.0
            params_dict["S2y"] = 0.0

            # Clamp z components to avoid LAL errors
            if S1Z in parameters:
                params_dict["S1z"] = min(
                    max(parameters[S1Z], CBCConstants.CHI_CLAMP_MIN),
                    CBCConstants.CHI_CLAMP_MAX,
                )
            else:
                params_dict["S1z"] = 0.0
            if S2Z in parameters:
                params_dict["S2z"] = min(
                    max(parameters[S2Z], CBCConstants.CHI_CLAMP_MIN),
                    CBCConstants.CHI_CLAMP_MAX,
                )
            else:
                params_dict["S2z"] = 0.0

            params_dict["distance"] = 1.0e6 * lal.PC_SI
            params_dict["inclination"] = 0.0
            params_dict["phiRef"] = 0.0
            params_dict["longAscNodes"] = 0.0
            params_dict["eccentricity"] = 0.0
            params_dict["meanPerAno"] = 0.0
            params_dict["deltaF"] = self.freq_interval
            params_dict["f_min"] = flow
            params_dict["f_max"] = self.freq_high
            params_dict["f_ref"] = 0.0
            params_dict["LALparams"] = None
            params_dict["approximant"] = self.approximant

            # params_dict already has string keys so no need to normalize
            hplus, hcross = lalsim.SimInspiralFD(**params_dict)

            fseries = hplus
            lal.WhitenCOMPLEX16FrequencySeries(fseries, self.psd)
            fseries = signal.add_quadrature_phase(fseries, self.working_length)

            # TODO why the manual del, is there some lalsim side effect we
            # need to clear?
            del hplus
            del hcross
        except RuntimeError:
            # TODO fix this reference / switch to logging
            logging.debug("RuntimeError in waveform generation", exc_info=True)
            # raise
            return None
        return fseries


#
# register coord funcs
#

coord_funcs = {
    # Tested coord funcs
    M1M2.key: M1M2,
    Log10M1Log10M2.key: Log10M1Log10M2,
    Log10M1Log10M2Chi.key: Log10M1Log10M2Chi,
}


#
# Bank specific classes
#


class ManifoldRectangle(cover.ManifoldRectangle):
    @property
    def metric_center(self):
        # FIXME for now this just returns the actual center of the rectangle
        return self.center

    def match(self, other):
        if isinstance(other, type(self)):
            return self.metric.metric_match(self.g, self.center, other.center)
        elif isinstance(other, numpy.ndarray):
            # Check if this is a 2D array of multiple points
            if other.ndim == 2:
                # Multiple points - compute match for each
                return numpy.array(
                    [self.metric.metric_match(self.g, self.center, pt) for pt in other]
                )
            else:
                # Single point
                return self.metric.metric_match(self.g, self.center, other)
        else:
            raise ValueError("argument %s not supported" % type(other))

    def sample_random_points(self, n=1, deterministic=True):
        """
        Draw random coordinates uniformly distributed inside the rectangle.

        Parameters
        ----------
        n : int
            Number of random points to generate
        deterministic : bool, optional
            If True (default), use deterministic seeding based on rectangle center
            to ensure reproducibility. This is critical for equivalence between
            full bank and interval processing modes. If False, uses global random
            state (non-reproducible).

        Returns
        -------
        points : numpy.ndarray
            Array of shape (n, d) where d is the dimension of the rectangle

        Notes
        -----
        Deterministic mode ensures that the same rectangle always generates the
        same random points, regardless of when or in what context (full bank vs
        interval processing) the method is called. This is essential for parallel
        processing equivalence.
        """
        if deterministic:
            # Create deterministic seed from rectangle center
            # The center is unique per rectangle and invariant across processing modes
            seed = hash(tuple(self.center.tobytes())) & 0xFFFFFFFF
            # Use local random state (doesn't affect global state)
            rng = numpy.random.RandomState(seed)
            random_fractions = rng.random((n, len(self.mins)))
        else:
            # Use global random state (non-deterministic)
            random_fractions = numpy.random.random((n, len(self.mins)))

        # Scale to the rectangle's coordinate ranges
        points = self.mins + random_fractions * self.coordinate_size
        return points

    def fft_match(self, others):
        w1 = self.metric.waveform(self.center)
        # Handle both single rectangle and list of rectangles
        if not hasattr(others, "__iter__"):
            others = [others]
        return numpy.array(
            [
                self.metric.fft_match(w1, self.metric.waveform(other.center))
                for other in others
            ]
        )

    @property
    def sngl_row(self):
        # FIXME also include other relevant paramters here that are known
        # e.g., flow, approximant, instrument, etc.
        coord_dict = self.metric.coord_func(self.center)
        # Convert CoordinateType keys to string keys
        str_dict = {}
        for k, v in coord_dict.items():
            if isinstance(k, type) and issubclass(k, coordinate.CoordinateType):
                str_dict[k.key] = v
            else:
                str_dict[str(k)] = v
        d = self.metric._normalize_waveform_params(str_dict)
        rdict: Dict[str, Union[int, float, str]] = {
            k: 0
            for k in (
                "process:process_id",
                "ifo",
                "search",
                "channel",
                "end_time",
                "end_time_ns",
                "end_time_gmst",
                "impulse_time",
                "impulse_time_ns",
                "template_duration",
                "event_duration",
                "amplitude",
                "eff_distance",
                "coa_phase",
                "mass1",
                "mass2",
                "mchirp",
                "mtotal",
                "eta",
                "kappa",
                "chi",
                "tau0",
                "tau2",
                "tau3",
                "tau4",
                "tau5",
                "ttotal",
                "psi0",
                "psi3",
                "alpha",
                "alpha1",
                "alpha2",
                "alpha3",
                "alpha4",
                "alpha5",
                "alpha6",
                "beta",
                "f_final",
                "snr",
                "chisq",
                "chisq_dof",
                "bank_chisq",
                "bank_chisq_dof",
                "cont_chisq",
                "cont_chisq_dof",
                "sigmasq",
                "rsqveto_duration",
                "Gamma0",
                "Gamma1",
                "Gamma2",
                "Gamma3",
                "Gamma4",
                "Gamma5",
                "Gamma6",
                "Gamma7",
                "Gamma8",
                "Gamma9",
                "spin1x",
                "spin1y",
                "spin1z",
                "spin2x",
                "spin2y",
                "spin2z",
                "event_id",
            )
        }
        rdict.update(
            {
                "ifo": "L1",
                "process_id": 0,
                "mass1": d["m1"],
                "mass2": d["m2"],
                "spin1x": d["S1x"],
                "spin1y": d["S1y"],
                "spin1z": d["S1z"],
                "spin2x": d["S2x"],
                "spin2y": d["S2y"],
                "spin2z": d["S2z"],
            }
        )
        return lsctables.SnglInspiralTable.RowType(**rdict)


class Chart(cover.Chart):
    pass


def _pn_phase(d):
    # From https://arxiv.org/pdf/1107.1267.pdf
    m1, m2 = (
        d[M1] * CBCConstants.PN_MASS_TO_SECONDS,
        d[M2] * CBCConstants.PN_MASS_TO_SECONDS,
    )  # mass in seconds
    mc = (m1 * m2) ** 0.6 / (m1 + m2) ** 0.2
    return mc


class Bank:
    MAX_TEMPLATE_ID = CBCConstants.MAX_TEMPLATE_ID
    MAX_NUM_TEMPLATES = MAX_TEMPLATE_ID

    def __init__(
        self,
        rectangles: List[ManifoldRectangle],
        constraint_sets: Optional[Dict[str, Dict[str, Tuple[float, float]]]] = None,
        ids: Optional[Union[List[int], numpy.ndarray]] = None,
        pns: Optional[List[float]] = None,
        process: Optional[Any] = None,
        reserved_ids: Optional[List[int]] = None,
        default_constraint_set_name: Optional[str] = None,
        exclusions_branched: Optional[List[Any]] = None,
        exclusions_trimmed: Optional[List[Any]] = None,
    ) -> None:
        self.__process = process
        self.rectangles = rectangles
        self.exclusions = {
            "branching": exclusions_branched or [],
            "trimming": exclusions_trimmed or [],
        }
        self.constraint_sets = constraint_sets or {}
        self.default_constraint_set_name = default_constraint_set_name or (
            None
            if len(self.constraint_sets) == 0
            else list(self.constraint_sets.keys())[0]
        )
        self.cfunc = (
            None if len(rectangles) == 0 else self.rectangles[0].metric.coord_func
        )
        self.metric = None if len(rectangles) == 0 else self.rectangles[0].metric
        self.ids = ids
        self.pns = pns
        if self.ids is None or self.pns is None:
            # implies now sorted and has pns
            self.assign_ids(reserved_ids=reserved_ids)
        self.centers = numpy.array([r.center for r in self.rectangles])
        self.ids_map = {
            i: n for n, i in enumerate(self.ids if self.ids is not None else [])
        }
        self.rectangle_meta: Dict = {}

    def __len__(self):
        return len(self.rectangles)

    def assign_ids(
        self, reserved_ids: Optional[List[int]] = None, reassign: bool = False
    ) -> None:
        """Assign identifiers randomly to templates in the Bank.

        Args:
                reserved_ids:
                        List[int], default None, if specified, these ids will not
                        be used in the assignment. This is achieved by removing
                        the reserved ids from the identifier sample space before
                        assigning ids to the templates.
                reassign:
                        bool, default False, if True, the method will reassign
                        ids to the templates, even if the bank already has ids
                        assigned.

        Returns:
                None
        """
        if self.ids is None or reassign:
            # Check for too many templates
            if len(self.rectangles) > self.MAX_NUM_TEMPLATES:
                raise ValueError(
                    f"Too many templates, increase size of draw space. "
                    f"Received {len(self.rectangles)} templates, maximum is "
                    f"{self.MAX_NUM_TEMPLATES}"
                )

            sample_space = set(range(self.MAX_TEMPLATE_ID))
            if reserved_ids is not None:
                sample_space -= set(reserved_ids)

            # Verify remaining sample space is large enough
            if len(sample_space) < len(self.rectangles):
                raise ValueError("Not enough sample space to assign ids")

            self.ids = numpy.random.choice(
                list(sample_space), len(self.rectangles), replace=False
            )
        self.__sort()

    def __sort(self):
        if self.ids is None:
            raise ValueError("Cannot sort bank without ids")
        rs = sorted(
            [
                (_pn_phase(r.metric.coord_func(r.center)), n, r)
                for n, r in zip(self.ids, self.rectangles)
            ]
        )
        self.pns = [r[0] for r in rs]
        self.rectangles = [r[-1] for r in rs]
        self.centers = numpy.array([r.center for r in self.rectangles])
        self.ids = numpy.array([r[1] for r in rs])
        self.ids_map = {i: n for n, i in enumerate(self.ids)}

    def template_by_id(self, tid: int) -> coordinate.CoordsDict:
        if self.cfunc is None:
            raise ValueError("Bank has no coordinate function")
        result = self.cfunc(self.centers[self.ids_map[tid]])
        if not isinstance(result, dict):
            raise TypeError(f"Expected dict from coord_func, got {type(result)}")
        return result

    def rectangle_by_id(self, tid: int) -> ManifoldRectangle:
        return self.rectangles[self.ids_map[tid]]

    def add_constraint_set(
        self,
        name: str,
        constraints: Dict[str, Tuple[float, float]],
        override: bool = False,
        make_default: bool = False,
    ) -> None:
        """Add a new set of constraints to the bank

        Args:
                name:
                        str, name of the constraint set
                constraints:
                        Dict[str, Tuple[float, float]], constraints to add to the
                        bank, e.g. {"m1": (1.0, 100.0), "m2": (1.0, 100.0),
                        "S1z": (-1.0, 1.0), "S2z": (-1.0, 1.0)}
                override:
                        bool, default False, if True, will overwrite any existing
                        constraint set with the same name
                make_default:
                        bool, default False, if True, will make this constraint
                        set the default constraint set for the bank

        Returns:
                None
        """
        if name in self.constraint_sets and not override:
            raise ValueError(
                f"Constraint set {name} already exists in bank. "
                f"Use override=True to overwrite."
            )
        self.constraint_sets[name] = constraints

        if make_default:
            self.default_constraint_set_name = name

    def remove_constraint_set(self, name: str) -> None:
        """Remove a constraint set from the bank

        Args:
                name:
                        str, name of the constraint set to remove

        Returns:
                None
        """
        if name in self.constraint_sets:
            del self.constraint_sets[name]

        # Make sure to unset the default if removed
        if self.default_constraint_set_name == name:
            self.default_constraint_set_name = None

    def constraints(self, name: Optional[str] = None) -> Dict[str, Tuple[float, float]]:
        """Get the constraints for the bank

        Args:
                name:
                        str, default None, if specified, will return the
                        constraints for the specified constraint set, otherwise
                        will return the constraints for the default constraint
                        set

        Returns:
                Dict[str, Tuple[float, float]], the constraints for the bank
        """
        if name is None:
            name = self.default_constraint_set_name
        if name is None:
            raise ValueError("No default constraint set specified")

        return self.constraint_sets[name]

    def templates(self) -> Generator[coordinate.CoordsDict, None, None]:
        if self.cfunc is None:
            raise ValueError("Bank has no coordinate function")
        for c in self.centers:
            yield self.cfunc(c)

    def split(self):
        assert self.pns is not None
        assert self.ids is not None
        left = [r for r in self.rectangles if r.left]
        idsleft = [ID for ID, r in zip(self.ids, self.rectangles) if r.left]
        pnsleft = [pn for pn, r in zip(self.pns, self.rectangles) if r.left]
        right = [r for r in self.rectangles if r.right]
        idsright = [ID for ID, r in zip(self.ids, self.rectangles) if r.right]
        pnsright = [pn for pn, r in zip(self.pns, self.rectangles) if r.right]
        return Bank(
            left,
            self.constraint_sets,
            ids=idsleft,
            pns=pnsleft,
            default_constraint_set_name=self.default_constraint_set_name,
        ), Bank(
            right,
            self.constraint_sets,
            ids=idsright,
            pns=pnsright,
            default_constraint_set_name=self.default_constraint_set_name,
        )

    def group(self, num):
        assert self.pns is not None
        assert self.ids is not None

        # https://stackoverflow.com/questions/2130016/splitting-a-list-into-n-parts-of-approximately-equal-length
        def __split(a, n):
            k, m = divmod(len(a), n)
            return ((i * k + min(i, m), (i + 1) * k + min(i + 1, m)) for i in range(n))

        for six, eix in __split(self.rectangles, num):
            yield Bank(
                self.rectangles[six:eix],
                self.constraint_sets,
                ids=self.ids[six:eix],
                pns=self.pns[six:eix],
                default_constraint_set_name=self.default_constraint_set_name,
            )

    def inside(self, r: ManifoldRectangle, check_vertices: bool = True) -> bool:
        if self.cfunc is None:
            raise ValueError("Bank has no coordinate function")
        return Bank._inside(r, self.constraints(), self.cfunc, check_vertices)

    @staticmethod
    def _inside(
        r: ManifoldRectangle,
        constraints: Dict[str, Tuple[float, float]],
        cfunc: CBCCoordFunc,
        check_vertices: bool,
    ) -> bool:
        out = True
        for func in [
            Bank.m1_constraint,
            Bank.m2_constraint,
            Bank.M_constraint,
            Bank.mc_constraint,
            Bank.q_constraint,
            Bank.chi_constraint,
        ]:
            if check_vertices:
                points = list(r.vertices) + [list(r.center)]
            else:
                points = [list(r.center)]
            out &= not all(func(constraints, cfunc(numpy.array(v))) for v in points)
        return out

    def trim(self, verbose=True):
        if verbose:
            logging.info("%d templates before trimming", len(self.rectangles))

        assert self.ids is not None
        template_data = [
            (r, ID, self.inside(r)) for r, ID in zip(self.rectangles, self.ids)
        ]
        keep = [(x[0], x[1]) for x in template_data if x[2]]
        exclude = [x[0] for x in template_data if not x[2]]

        # Update kept templates
        self.rectangles = [x[0] for x in keep]
        self.ids = numpy.array([x[1] for x in keep])
        self.ids_map = {i: n for n, i in enumerate(self.ids)}

        # Track excluded templates
        self.exclusions["trimming"].extend(exclude)

        if verbose:
            logging.info("%d templates after trimming", len(self.rectangles))

    def hardcut(self, verbose=True):
        if verbose:
            logging.info("%d templates before hardcut", len(self.rectangles))
        assert self.ids is not None
        template_data = [
            (r, ID)
            for r, ID in zip(self.rectangles, self.ids)
            if self.inside(r, check_vertices=False)
        ]
        self.rectangles = [x[0] for x in template_data]
        self.ids = numpy.array([x[1] for x in template_data])
        self.ids_map = {i: n for n, i in enumerate(self.ids)}
        if verbose:
            logging.info("%d templates after hardcut", len(self.rectangles))

    def neighborhood_overlaps(self, ix, n=CBCConstants.DEFAULT_NEIGHBOR_COUNT):
        if self.pns is None:
            raise ValueError(
                "indexing into this bank without calling sort() first will "
                "lead to nonsense. This is probably wrong"
            )
        if ix < n / 2:
            ixL = 0
        else:
            ixL = ix - n // 2
        ixR = ixL + n
        if ixR > len(self.rectangles):
            ixR = len(self.rectangles)
        return self.rectangles[ix].match(self.centers[ixL:ixR]), numpy.arange(ixL, ixR)

    def point_overlaps(self, point, n=CBCConstants.DEFAULT_NEIGHBOR_COUNT, g=None):
        """
        Find overlaps between a point and templates in the bank.

        Parameters
        ----------
        point : numpy.ndarray
            Coordinate point to check
        n : int
            Number of nearby templates to check
        g : numpy.ndarray, optional
            Pre-computed metric at the point. If None, will compute it.

        Returns
        -------
        matches : numpy.ndarray
            Match values with nearby templates
        indices : numpy.ndarray
            Indices of the templates checked
        """
        if self.pns is None:
            raise ValueError(
                "indexing into this bank without calling sort() first will "
                "lead to nonsense. This is probably wrong"
            )

        # Find the nearest template index based on PN phase
        # Convert point to physical parameters first
        if self.cfunc is None:
            raise ValueError("Bank has no coordinate function")
        params_dict = self.cfunc(point)
        pn = _pn_phase(params_dict)
        ix = bisect.bisect(self.pns, pn)

        # Define neighborhood window
        if ix < n / 2:
            ixL = 0
        else:
            ixL = ix - n // 2
        ixR = ixL + n
        if ixR > len(self.rectangles):
            ixR = len(self.rectangles)

        # Use provided metric or compute it
        if g is None:
            if self.metric is None:
                raise ValueError("Bank has no metric")
            g = self.metric(point)

        centers_slice = self.centers[ixL:ixR]

        # Vectorized computation of matches
        if self.metric is None:
            raise ValueError("Bank has no metric")
        d2_array = self.metric._distancesq(g, point, centers_slice)
        matches = numpy.exp(-d2_array)

        return matches, numpy.arange(ixL, ixR)

    def adjacent(
        self,
        c,
        n=CBCConstants.DEFAULT_NEIGHBOR_COUNT_TINY,
        use_metric=False,
        ixs_only=False,
    ):
        if use_metric:
            if self.cfunc is None:
                raise ValueError("Bank has no coordinate function")
            center = self.cfunc(c, inv=True)
            if self.metric is None:
                raise ValueError("Bank has no metric")
            g = self.metric(center)
            matches = self.metric.metric_match(g, center, self.centers)
            ixs = numpy.argsort(matches)
            ixs = ixs[-n:]
            if ixs_only:
                return ixs
            else:
                return [self.rectangles[ix] for ix in ixs]
        else:  # use whatever is in self.pns to sort
            assert self.pns is not None
            pn = _pn_phase(c)
            ix = bisect.bisect(self.pns, pn)
            if ix < n / 2:
                ixL = 0
            else:
                ixL = ix - n // 2
            ixR = ixL + n
            if ixs_only:
                return numpy.array(range(ixL, ixR))
            else:
                this_rs = self.rectangles[ixL:ixR]
                return this_rs

    def nearest(self, c, n=CBCConstants.DEFAULT_NEIGHBOR_COUNT_SMALL):
        # TODO expose 'n' param to yaml
        # TODO expose 'use_metric' to yaml
        this_rs = self.adjacent(c, n=n)
        if self.cfunc is None:
            raise ValueError("Bank has no coordinate function")
        cp = self.cfunc(c, inv=True)

        def _fft_match(x, cp=cp):
            return x[-1].metric.fft_match_at_coords(cp, x[-1].center)

        return max(map(_fft_match, enumerate(this_rs)))

    def prob_of_tk_given_rho(
        self,
        p_of_tj_given_alpha,
        num_rhos=30,
        n=2000000,
        start_ix=None,
        stop_ix=None,
        verbose=True,
    ):
        if start_ix is None:
            start_ix = 0
        if stop_ix is None:
            stop_ix = len(self)
        rhos = numpy.logspace(0.5, 1.5, num_rhos)
        log_p_of_tk_given_alpha_rho = numpy.zeros((len(rhos), len(p_of_tj_given_alpha)))
        # We do this so that someone doesn't mistake an unprocessed template
        # for valid since the user can specify an index range.
        log_p_of_tk_given_alpha_rho.fill(numpy.nan)
        onebyroot2pi = 1.0 / numpy.sqrt(numpy.pi * 2.0)
        log_root_pi_2 = numpy.log(onebyroot2pi)
        log_p_of_tj_given_alpha = numpy.log(p_of_tj_given_alpha)

        for ix in range(len(self)):
            if ix < start_ix or ix >= stop_ix:
                continue
            kdj, indices = self.neighborhood_overlaps(ix, n=n)
            for jx, rho in enumerate(rhos):
                log_p = logsumexp(
                    log_p_of_tj_given_alpha[indices]
                    + log_root_pi_2
                    - rho**2 / 2.0 * (1.0 - 2.0 * kdj + kdj**2)
                )
                log_p_of_tk_given_alpha_rho[jx, ix] = log_p
            if verbose and not ix % 100:
                logging.debug("Processing row %d", ix)
        return rhos, log_p_of_tk_given_alpha_rho

    def mass_model_coefficients(self, rhos, log_p_of_tk_given_alpha_rho):
        # normalize the result
        for jx, _rho in enumerate(rhos):
            # work around that nans are valid for incomplete mass models, but
            # still return a sensible normalization...
            norm_array = log_p_of_tk_given_alpha_rho[jx, :]
            norm_array = norm_array[~numpy.isnan(norm_array)]
            if len(norm_array) >= 1:
                norm = logsumexp(norm_array)
                if numpy.isfinite(norm):
                    log_p_of_tk_given_alpha_rho[jx, :] -= norm

        # and create the piecewise polynomial fit TO THE NATURAL LOG
        coefficients = numpy.zeros((4, len(rhos) + 3, len(self)), dtype=float)
        breakpoints = numpy.zeros(len(rhos) + 4, dtype=float)
        # FIXME YUCK. work around not being able to interpolate over negative
        # inf without getting nans
        log_p_copy = log_p_of_tk_given_alpha_rho.copy()
        minfinite = (log_p_copy[numpy.isfinite(log_p_copy)]).min()
        # We assume negative infinity maps to a probability 1,000,000 times
        # lower than the smallest finite value
        log_p_copy[~numpy.isfinite(log_p_copy)] = minfinite - numpy.log(1e6)
        for tix in range(log_p_copy.shape[1]):
            tck = splrep(rhos, log_p_copy[:, tix])
            p = PPoly.from_spline(tck)
            coefficients[:, :, tix] = p.c
            if tix == 0:
                breakpoints[:] = p.x

        return coefficients, breakpoints

    @staticmethod
    def m1_constraint(constraints, c):
        return (c[M1] < constraints["m1"][0]) or (c[M1] > constraints["m1"][1])

    @staticmethod
    def m2_constraint(constraints, c):
        return (c[M2] < constraints["m2"][0]) or (c[M2] > constraints["m2"][1])

    @staticmethod
    def M_constraint(constraints, c):
        M = c[M1] + c[M2]
        return (M < constraints["M"][0]) or (M > constraints["M"][1])

    @staticmethod
    def mc_constraint(constraints, c):
        mc = chirpmass(c[M1], c[M2])
        return (mc < constraints["mc"][0]) or (mc > constraints["mc"][1])

    @staticmethod
    def q_constraint(constraints, c):
        q = c[M1] / c[M2]
        return (q < constraints["q"][0]) or (q > constraints["q"][1])

    @staticmethod
    def chi_constraint(constraints, c):
        m1, m2 = c[M1], c[M2]
        chi = (c[M1] * c[S1Z] + c[M2] * c[S2Z]) / (c[M1] + c[M2])
        min_sz, max_sz = constraints["chi"]
        min_ns_mass, max_ns_mass = constraints["ns-mass"]
        min_ns_s1z, max_ns_s1z = constraints["ns-s1z"]
        # if both m1 and m2 are NS, then chi must be the same interval as the
        # ns spin
        if (min_ns_mass <= m1 <= max_ns_mass) and (min_ns_mass <= m2 <= max_ns_mass):
            return (chi < min_ns_s1z) or (chi > max_ns_s1z)
        if (min_ns_mass <= m1 <= max_ns_mass) and not (
            min_ns_mass <= m2 <= max_ns_mass
        ):
            min_chi = (min_ns_s1z * m1 + min_sz * m2) / (m1 + m2)
            max_chi = (max_ns_s1z * m1 + max_sz * m2) / (m1 + m2)
            return (chi < min_chi) or (chi > max_chi)
        if not (min_ns_mass <= m1 <= max_ns_mass) and (
            min_ns_mass <= m2 <= max_ns_mass
        ):
            min_chi = (min_ns_s1z * m2 + min_sz * m1) / (m1 + m2)
            max_chi = (max_ns_s1z * m2 + max_sz * m1) / (m1 + m2)
            return (chi < min_chi) or (chi > max_chi)
        # otherwise, use the specified chi range. Note that we probably
        # overcover NSBH somewhat but it is a hard curved boundary to tile
        # properly.
        if chi < constraints["chi"][0] or chi > constraints["chi"][1]:
            return True
        return False

    def constraint(self, c):
        return any(
            f(self.constraints(), c)
            for f in [
                Bank.m1_constraint,
                Bank.m2_constraint,
                Bank.M_constraint,
                Bank.mc_constraint,
                Bank.q_constraint,
                Bank.chi_constraint,
            ]
        )

    @staticmethod
    def fromChart(
        chart: Any,
        constraint_sets: Optional[Dict[str, Dict[str, Tuple[float, float]]]] = None,
        default_constraint_set_name: Optional[str] = None,
    ) -> "Bank":
        return Bank(
            rectangles=list(chart.atlas()),
            constraint_sets=constraint_sets,
            default_constraint_set_name=default_constraint_set_name,
            exclusions_branched=None if chart.excluded is None else chart.excluded,
        )

    @classmethod
    def load(cls, h5fn: str) -> "Bank":
        # @shio figure out how to parse the file back in and make one of
        # these Bank classes
        d = io.h5read(h5fn)
        rectangles = cls._deserialize_rectangles(d, prefix="")
        excluded_branching = cls._deserialize_rectangles(
            d, prefix="exclusion_branching_"
        )
        excluded_trimming = cls._deserialize_rectangles(d, prefix="exclusion_trimming_")

        # Legacy case for constraints, only a single set specified with stale
        # key "constraints", convert to new format key "constraint_sets"
        if "constraints" in d:
            d["constraint_sets"] = {"default": d["constraints"]}
            d["default_constraint_set_name"] = "default"
            del d["constraints"]

        # Sentinel value for serialization (H5py needs a non-None value, so
        # we humor it)
        if d["default_constraint_set_name"] == "__load__":
            d["default_constraint_set_name"] = None

        # Decode bytes to string if needed
        default_name = d["default_constraint_set_name"]
        if isinstance(default_name, bytes):
            default_name = default_name.decode("utf-8")
            d["default_constraint_set_name"] = default_name

        # Ensure ids is a numpy array if present
        ids = None
        if "ids" in d:
            ids = (
                d["ids"]
                if isinstance(d["ids"], numpy.ndarray)
                else numpy.array(d["ids"])
            )

        return cls(
            rectangles,
            constraint_sets=d["constraint_sets"],
            pns=None if "pns" not in d else d["pns"],
            ids=ids,
            process=d["__process"],
            default_constraint_set_name=d["default_constraint_set_name"],
            exclusions_branched=excluded_branching,
            exclusions_trimmed=excluded_trimming,
        )

    @staticmethod
    def _serialize_rectangles(
        rectangles: List[ManifoldRectangle], prefix: str = ""
    ) -> Dict[str, Any]:
        out = {
            prefix
            + "metric": {} if len(rectangles) == 0 else rectangles[0].metric._to_dict(),
            prefix + "mins": numpy.array([r.mins for r in rectangles]),
            prefix + "maxes": numpy.array([r.maxes for r in rectangles]),
            prefix + "gs": numpy.array([r.g for r in rectangles]),
            prefix + "rights": numpy.array([r.right for r in rectangles]),
            prefix + "lefts": numpy.array([r.left for r in rectangles]),
        }

        # Def serialize Rectangle metadata
        meta_keys = []
        for r in rectangles:
            meta_keys.extend(list(r.meta.keys()))
        meta_keys = list(set(meta_keys))

        if meta_keys:
            out[prefix + "meta"] = {}

            for k in meta_keys:
                values = [r.meta.get(k, None) for r in rectangles]

                # Infer array type (either int or float)
                vtypes = set([type(v) for v in values])
                if float in vtypes or numpy.float64 in vtypes:
                    dtype = "float64"
                elif int in vtypes or numpy.int64 in vtypes:
                    dtype = "int64"
                    values = [v if v is not None else io.INT64_NAN for v in values]
                elif vtypes == {type(None)}:
                    dtype = "float64"
                    logging.warning(
                        "Meta data for key %s is all None, defaulting to float64", k
                    )
                else:
                    raise ValueError(
                        f"Unsupported type in meta data for key {k}, types: {vtypes}"
                    )

                out[prefix + "meta"][k] = numpy.array(values).astype(dtype)

        return out

    @staticmethod
    def _deserialize_rectangles(
        d: Dict[str, Any], prefix: str = ""
    ) -> List[ManifoldRectangle]:
        rectangles: List = []

        # Check that prefix is in the keys at all, if not return empty list
        if not any(k.startswith(prefix) for k in d.keys()):
            return rectangles

        r_metric = (
            None
            if d[prefix + "metric"] == {}
            else CBCMetric._from_dict(d[prefix + "metric"])
        )

        # Check for rectangle meta data
        if prefix + "meta" in d:
            meta = d[prefix + "meta"]
            keys = list(sorted(meta.keys()))

            # Invert integer sentinel values to None
            valss = []
            for k in keys:
                vals = meta[k]
                if vals.dtype == numpy.int64:
                    vals = vals.astype("O")
                    mask = vals == io.INT64_NAN
                    for i in numpy.where(mask)[0]:
                        vals[i] = None

                # Deserialize all None
                if vals.dtype == "float64" and numpy.all(numpy.isnan(vals)):
                    vals = [None for _ in vals]
                valss.append(vals)

            valss = list(zip(*valss))
            meta_dicts = [dict(zip(keys, vals)) for vals in valss]
        else:
            meta_dicts = [{} for _ in d["mins"]]

        for mn, mx, g, right, left, meta in zip(
            d[prefix + "mins"],
            d[prefix + "maxes"],
            d[prefix + "gs"],
            d[prefix + "rights"],
            d[prefix + "lefts"],
            meta_dicts,
        ):
            rectangles.append(
                ManifoldRectangle(
                    mn, mx, r_metric, g, right=right, left=left, meta=meta
                )
            )

        return rectangles

    def save(self, h5fn: str) -> None:
        # FIXME @shio please find a way to serialize the data in a metric so
        # that it can be recorded to hdf5
        # FIXME completely untested

        out: Dict[str, Any] = {
            "constraint_sets": self.constraint_sets,
            "default_constraint_set_name": self.default_constraint_set_name
            or "__none__",
            "ids": self.ids,
        }

        # Serialize rectangles
        out.update(self._serialize_rectangles(self.rectangles))

        # Serialize Excluded Rectangles
        if self.exclusions["branching"]:
            out.update(
                self._serialize_rectangles(
                    self.exclusions["branching"], prefix="exclusion_branching_"
                )
            )
        if self.exclusions["trimming"]:
            out.update(
                self._serialize_rectangles(
                    self.exclusions["trimming"], prefix="exclusion_trimming_"
                )
            )

        if self.__process is not None:
            out["__process"] = self.__process
        if self.pns is not None:
            out["pns"] = self.pns
        io.h5write(h5fn, out)

    def to_ligolw(
        self,
        xmlfn: str,
        program_name: Optional[str] = None,
        optdict: Optional[Dict[str, Any]] = None,
    ) -> None:
        if optdict is None:
            optdict = {}
        # prepare a new XML document for writing template bank
        xmldoc = ligolw.Document()
        xmldoc.appendChild(ligolw.LIGO_LW())
        sngl_inspiral_columns = (
            "process:process_id",
            "ifo",
            "search",
            "channel",
            "end_time",
            "end_time_ns",
            "end_time_gmst",
            "impulse_time",
            "impulse_time_ns",
            "template_duration",
            "event_duration",
            "amplitude",
            "eff_distance",
            "coa_phase",
            "mass1",
            "mass2",
            "mchirp",
            "mtotal",
            "eta",
            "kappa",
            "chi",
            "tau0",
            "tau2",
            "tau3",
            "tau4",
            "tau5",
            "ttotal",
            "psi0",
            "psi3",
            "alpha",
            "alpha1",
            "alpha2",
            "alpha3",
            "alpha4",
            "alpha5",
            "alpha6",
            "beta",
            "f_final",
            "snr",
            "chisq",
            "chisq_dof",
            "bank_chisq",
            "bank_chisq_dof",
            "cont_chisq",
            "cont_chisq_dof",
            "sigmasq",
            "rsqveto_duration",
            "Gamma0",
            "Gamma1",
            "Gamma2",
            "Gamma3",
            "Gamma4",
            "Gamma5",
            "Gamma6",
            "Gamma7",
            "Gamma8",
            "Gamma9",
            "spin1x",
            "spin1y",
            "spin1z",
            "spin2x",
            "spin2y",
            "spin2z",
            "event_id",
        )
        tbl = lsctables.New(lsctables.SnglInspiralTable, columns=sngl_inspiral_columns)
        xmldoc.childNodes[-1].appendChild(tbl)
        # FIXME make a real process table
        process = ligolw_process.register_to_xmldoc(
            xmldoc, program_name or "manifold-cbc-bank", optdict
        )
        process.set_end_time_now()

        if self.cfunc is None:
            raise ValueError("Bank has no coordinate function")
        assert self.ids is not None
        for n, c in zip(self.ids, self.rectangles):
            center_dict = self.cfunc(numpy.array(c.center))
            row = c.sngl_row
            row.f_final = CBCConstants.DEFAULT_F_FINAL  # FIXME!!!
            row.mchirp = chirpmass(center_dict[M1], center_dict[M2])
            row.process_id = process.process_id
            row.event_id = n
            row.template_id = n
            tbl.append(row)

        # Write out the bank file
        utils.write_filename(xmldoc, xmlfn)

    def find_rectangle_constraint_interior(
        self, r: ManifoldRectangle
    ) -> Optional[numpy.ndarray]:
        """Find a point of a given rectangle that is in the interior of the
        bank constraint manifold. If not possible,
        return None.

        Returns:
                ManifoldRectangle, the rectangle with the interior point
        """
        p = r.center
        # Check center first
        if self.cfunc is not None and not self.constraint(
            self.cfunc(p)
        ):  # Recall: constraint returns True if point fails constraints, so
            # we want "False" to indicate interior
            return numpy.array(p)

        # Check vertices returning the first one that passes constraints
        for p in r.vertices:
            if self.cfunc is not None and not self.constraint(
                self.cfunc(numpy.array(p))
            ):
                return numpy.array(p)
        return None

    def copy(self, deep: bool = False) -> "Bank":
        """Make a copy of the Bank object.

        Args:
                deep:
                        bool, default False, if True, a deep copy of the object
                        is made. If False, a shallow copy is made.

        Returns:
                Bank, a copy of the Bank object.
        """
        if deep:
            raise NotImplementedError(
                "Deep copy of banks not implemented yet, shallow copy available."
            )
        return Bank(
            rectangles=self.rectangles,
            constraint_sets=self.constraint_sets,
            default_constraint_set_name=self.default_constraint_set_name,
            ids=self.ids,
            pns=self.pns,
            process=self.__process,
        )

    def merge(
        self,
        *others: "Bank",
        new_constraints: Optional[Dict[str, Tuple[float, float]]] = None,
    ) -> "Bank":
        """Merge two or more Bank objects, preserving this banks template ids.

        Args:
                others:
                        Tuple[Bank], the other Bank object to merge with.
                new_constraints:
                        Dict[str, Callable], default None, if specified, the new
                        constraints to use for the merged Bank object. Note, if
                        new_constraints is not specified, then the constraints of
                        all banks must be the same, otherwise a ValueError is
                        raised.

        Returns:
                Bank, the merged Bank object.
        """
        # Reconcile constraints using union of domains
        constraints = new_constraints
        if constraints is None:
            constraints = {}
            for bank in [self] + list(others):
                for k, v in bank.constraints().items():
                    if k in constraints:
                        constraints[k] = (
                            min(constraints[k][0], v[0]),
                            max(constraints[k][1], v[1]),
                        )
                    else:
                        constraints[k] = v

        # Preserve the ids of this bank
        reserved_ids = self.ids

        # Reassign the ids of the other banks, avoiding collisions with the
        # ids of this bank, gathering cumulative attributes
        all_rectangles = list(self.rectangles)
        all_ids = list(self.ids) if self.ids is not None else []
        all_pns = list(self.pns) if self.pns is not None else []

        # Track exclusions
        exclusions = self.exclusions

        for other in others:
            other_cpy = other.copy()
            # Convert reserved_ids to list if it's a numpy array
            reserved_list = (
                list(reserved_ids)
                if isinstance(reserved_ids, numpy.ndarray)
                else reserved_ids
            )
            other_cpy.assign_ids(reserved_ids=reserved_list, reassign=True)

            # TODO should we ensure that rectangles are unique?
            all_rectangles = all_rectangles + list(other_cpy.rectangles)
            if other_cpy.ids is not None:
                all_ids = all_ids + list(other_cpy.ids)
            if other_cpy.pns is not None:
                all_pns = all_pns + list(other_cpy.pns)

            # Track exclusions
            exclusions["branching"].extend(other_cpy.exclusions["branching"])
            exclusions["trimming"].extend(other_cpy.exclusions["trimming"])

        # Merge the banks
        bank = Bank(
            rectangles=all_rectangles,
            constraint_sets={"default": constraints},
            default_constraint_set_name="default",
            ids=all_ids,
            pns=all_pns,
            process=self.__process,
            exclusions_branched=exclusions["branching"],
            exclusions_trimmed=exclusions["trimming"],
        )
        bank.__sort()
        return bank


# FIXME are these functions below used??


def scale_g(g: numpy.ndarray, scale: Optional[float] = None) -> numpy.ndarray:
    if scale is not None:
        scale = max(min(0.2, scale), 1e-4)
        V, Q = numpy.linalg.eig(g)
        V[V < max(V) * scale] = max(V) * scale
        g = numpy.dot(Q, numpy.dot(numpy.diag(abs(V)), numpy.linalg.inv(Q)))
    return g
