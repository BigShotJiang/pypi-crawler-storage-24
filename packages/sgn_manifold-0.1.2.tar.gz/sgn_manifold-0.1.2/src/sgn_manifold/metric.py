from __future__ import annotations

# Copyright (C) 2020-2021 Chad Hanna
# Copyright (C) 2014 Miguel Fernandez, Chad Hanna
# Copyright (C) 2016,2017 Kipp Cannon, Miguel Fernandez, Chad Hanna, Stephen
# Privitera, Jonathan Wang
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 2 of the License, or (at your
# option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
# Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

"""Metric

References:
    [1] B. J. Owen, Search Templates for Gravitational Waves from Inspiraling
        Binaries: Choice of Template Spacing, Phys. Rev. D 53, 6749 (1996).
"""

import itertools
from typing import Any, Callable, Dict, Generator, List, Optional, Type, Union

import lal  # type: ignore[import-untyped]
import numpy
from scipy import optimize  # type: ignore[import-untyped]

from sgn_manifold import coordinate, signal
from sgn_manifold.utilities import common

DEFAULT_F_LOW = 10.0
DEFAULT_F_HIGH = 1024.0
DEFAULT_DURATION = 1
MAX_EPSILON_SCALE = 2 * numpy.finfo(numpy.float32).eps
DEFAULT_TARGET_MATCH = float(1.0 - 0.5 * numpy.finfo(numpy.float32).eps)
DEFAULT_MAX_DIFF_THRESHOLD = 0.7
MIN_TARGET_MATCH = 0.90
DELTA = 1e-4  # Step size for numerical differentiation


def _getAplus(A):
    eigval, eigvec = numpy.linalg.eig(A)
    Q = numpy.matrix(eigvec)
    xdiag = numpy.matrix(numpy.diag(numpy.maximum(eigval, 0)))
    return Q * xdiag * Q.T


def _getPs(A, W=None):
    W05 = numpy.matrix(W**0.5)
    return W05.I * _getAplus(W05 * A * W05) * W05.I


def _getPu(A, W=None):
    Aret = numpy.array(A.copy())
    Aret[W > 0] = numpy.array(W)[W > 0]
    return numpy.matrix(Aret)


def nearPD(A, nit=10):
    n = A.shape[0]
    W = numpy.identity(n)
    # W is the matrix used for the norm (assumed to be Identity matrix here)
    # the algorithm should work for any diagonal W
    deltaS = 0
    Yk = A.copy()
    for _k in range(nit):
        Rk = Yk - deltaS
        Xk = _getPs(Rk, W=W)
        deltaS = Xk - Rk
        Yk = _getPu(Xk, W=W)
    return Yk


class EvaluationMethod:
    """Enum of evaluation methods"""

    Numeric = "numeric"
    Deterministic = "deterministic"


class EvaluationError(ValueError):
    pass


class MaxDiffError(EvaluationError):
    pass


class Metric(object):
    """Class to numerically evaluate a waveform parameter space metric.

    Examples:
            >>> psd = io.h5read('tests/data/H1L1-MASS_BBH-1185149070-800.h5',
            ...                 'psd')['L1']
            >>> bounds = {"m1":[1., 100.], "m2":[1., 100.], "S1z":[-1., 1.],
            ...           "S2z":[-1., 1.]}
            >>> cfunc = m1_m2_s1z_s2z(bounds)
            >>> g = Metric(psd, cfunc)
            >>> g([1.4, 1.4, 0, 0])
            array([[ 4.34726584e+05,  4.34725714e+05, -8.52915457e+03,
                            -8.52915457e+03],
                       [ 4.34725714e+05,  4.34726584e+05, -8.52915457e+03,
                            -8.52915457e+03],
                       [-8.52915457e+03, -8.52915457e+03,  1.82025977e+02,
                             1.81156190e+02],
                       [-8.52915457e+03, -8.52915457e+03,  1.81156190e+02,
                             1.82025977e+02]])
    """

    WAVEFORM_COORDS: tuple = ()  # overridden by subclasses
    WAVEFORM_COORD_DEFAULTS: Dict[Type[coordinate.CoordinateType], float] = (
        {}
    )  # overridden by subclasses

    def __init__(
        self,
        psd: Any,  # LAL REAL8FrequencySeries
        coord_func: coordinate.CoordFunc,
        f_low: float = DEFAULT_F_LOW,
        f_high: float = DEFAULT_F_HIGH,
        duration: int = DEFAULT_DURATION,
        max_metric_diff: float = DEFAULT_MAX_DIFF_THRESHOLD,
    ):
        """Create a Metric

        Args:
                psd:
                        REAL8FrequencySeries, A LAL type holding a PSD
                coord_func:
                        Fucntion, a coord_func or derived class that specifies the
                        coordinate transformation.
                f_low:
                        float, default=15, the minimum frequency of the
                        integration
                f_high:
                        float, default=512, the maximum frequency of the
                        integration
                duration:
                        int, default 4, the time step that determines the
                        frequency interval as freq_interval = 1/duration
        Returns:
                Metric
        """
        # TODO we should investigate how the duration affects this
        self.duration = duration
        self.coord_func = coord_func
        self.freq_interval = 1.0 / self.duration
        self.freq_low = f_low
        self.freq_high = f_high
        self.working_length = int(round(self.duration * 2 * self.freq_high)) + 1
        self.psd = signal.interpolate_psd(psd, self.freq_interval)
        self.revplan = lal.CreateReverseCOMPLEX16FFTPlan(self.working_length, 1)
        self.freq_vec = numpy.arange(self.working_length) * self.freq_interval
        self.t_series = lal.CreateCOMPLEX16TimeSeries(
            name="workspace",
            epoch=0,
            f0=0,
            deltaT=1.0 / (2 * self.freq_high),
            length=self.working_length,
            sampleUnits=lal.Unit("strain"),
        )
        self.f_series = lal.CreateCOMPLEX16FrequencySeries(
            name="template",
            epoch=0.0,
            f0=0.0,
            deltaF=self.freq_interval,
            sampleUnits=lal.Unit("strain"),
            length=self.working_length,
        )
        self._method_funcs = {
            EvaluationMethod.Numeric: self._evaluate_hessian,
            EvaluationMethod.Deterministic: self._evaluate_deterministic,
        }
        self.max_diff_threshold = max_metric_diff

    def __call__(
        self,
        center: coordinate.Coordinates,
        scale: Optional[float] = None,
        method: str = EvaluationMethod.Deterministic,
    ) -> numpy.ndarray:
        """Syntactic sugar wrapper around evaluate method"""
        return self.evaluate(
            center,
            scale=scale,
            method=method,
        )

    def _normalize_waveform_params(self, d: coordinate.CoordsDict) -> Dict[str, Any]:
        n = d.copy()

        # Set defaults
        for k, v in self.WAVEFORM_COORD_DEFAULTS.items():
            if k not in n:
                n[k] = v

        # Replace types with keys (so can be unpacked into waveform func)
        result: Dict[str, Any] = {}
        for t in self.WAVEFORM_COORDS:
            if t in n:
                result[t.key] = n.pop(t)

        # Add any remaining items (shouldn't be any, but just in case)
        for k, v in n.items():
            if isinstance(k, type) and hasattr(k, "key"):
                result[k.key] = v
            else:
                result[str(k)] = v

        return result

    def _distancesq(
        self, metric_tensor: Any, x: numpy.ndarray, y: numpy.ndarray
    ) -> numpy.ndarray:

        delta = x - y
        X = numpy.dot(delta, metric_tensor)
        Y = delta
        d2 = numpy.sum((X * Y), axis=1)
        d2[d2 < 0.0] = 0.0
        return numpy.array(d2)

    def distance(
        self,
        metric_tensor: common.MetricMatrix,
        x: Union[coordinate.Coordinates, numpy.ndarray],
        y: Union[coordinate.Coordinates, numpy.ndarray],
    ) -> float:
        """Compute the distance between two points inside the cube using the
        metric tensor

        Args:
                metric_tensor:
                         Array[N, N], the component representation of the metric
                x:
                        Array[N, 1], the first vector
                y:
                        Array[N, 1], the second vector

        Returns:
                float
        """
        # TODO: why not numpy.sqrt?
        return float(self.distance_sq(metric_tensor, x, y) ** 0.5)

    def distance_sq(
        self,
        metric_tensor: common.MetricMatrix,
        x: Union[coordinate.Coordinates, numpy.ndarray],
        y: Union[coordinate.Coordinates, numpy.ndarray],
    ) -> float:
        """Compute the distance squared between two points inside the cube using
        the metric tensor, but assuming it is constant

        Args:
                metric_tensor:
                         Array[N, N], the component representation of the metric
                x:
                        Array[N, 1], the first vector
                y:
                        Array[N, 1], the second vector

        Returns:
                float, the square distance
        """
        # Convert to arrays if needed
        x_array = coordinate.to_array(x) if isinstance(x, coordinate.Coordinates) else x
        y_array = coordinate.to_array(y) if isinstance(y, coordinate.Coordinates) else y

        if len(y_array.shape) > 1:
            return float(self._distancesq(metric_tensor, x_array, y_array)[0])

        delta = x_array - y_array
        # FIXME I don't remember the reason for this, but it is
        # probably a terrible idea we should drop the max and see what
        # happens
        # always return floating point epsilon distance
        return max(1e-7, float(dot(delta, delta, metric_tensor)))

    def evaluate(
        self,
        center: Union[coordinate.Coordinates, numpy.ndarray],
        scale: Optional[float] = None,
        method: str = EvaluationMethod.Deterministic,
        target_match: Optional[float] = None,
    ) -> numpy.ndarray:
        # TODO coerce to Coordinates when coordinates has been fully array-passthrough
        if target_match is None:
            target_match = self.coord_func.target_match(center)

        # Determine evaluation method
        f = self._method_funcs.get(method.lower(), None)
        if f is None:
            raise ValueError(
                "Unknown evaluation method: {}. Options are: {}".format(
                    method, list(sorted(self._method_funcs.keys()))
                )
            )

        # Ensure center is Coordinates for evaluation methods
        if not isinstance(center, coordinate.Coordinates):
            center = coordinate.Coordinates(center)

        g = f(center, target_match=target_match)
        center = coordinate.to_array(center)

        return self._post_process_metric(
            g,
            center,
            scale=scale,
            method=method,
            target_match=target_match,
        )

    def _evaluate_hessian(
        self, center: coordinate.Coordinates, target_match: float = DEFAULT_TARGET_MATCH
    ) -> numpy.ndarray:
        """Evaluate the metric at a point on the manifold, computing the
        components of the metric
        and returning as a matrix

        Args:
                center:
                        Tuple[float, ...] the coordinates at which to evaluate
                        the metric components
                scale:
                        float, default None

        Returns:
                numpy.ndarray of size len(center) x len(center), the metric
                components at center
        """
        center_array = numpy.array(center)
        # Add time as first coordinate, consistent with deterministic method
        # center_with_time = numpy.array([0.0] + list(center))  # unused
        center_coords = coordinate.Coordinates(center_array)
        w_c = self.waveform(center_coords)

        def match(d):
            # t is first parameter by convention, d[0] is time shift
            # d[1:] are the coordinate shifts
            w2 = self.waveform(center_array + d[1:])
            return match_minus_1(w_c, w2, self.freq_vec, dt=d[0])

        # Construct Hessian
        import numdifftools  # type: ignore[import-not-found, import-untyped]

        # Use parameters from main branch that supposedly worked
        h = numdifftools.Hessian(
            match,
            base_step=self.coord_func.base_step(center_array),
            num_steps=40,
            step_ratio=2,
            num_extrap=16,
        )

        # Evaluate Hessian at (dt, dlambda) ~ (0, ...)
        gamma = -0.5 * h(numpy.zeros(len(center_array) + 1))

        return numpy.array(gamma)

    def _evaluate_deterministic(
        self, center: coordinate.Coordinates, target_match: float = DEFAULT_TARGET_MATCH
    ) -> numpy.ndarray:
        # add in time
        center_array = numpy.array([0.0] + list(center))
        deltas = self.solve_deltas(center_array, target_match)

        mt = numpy.zeros((len(center_array), len(center_array)))
        w1 = self.waveform_shift(center_array)

        for i in range(len(center_array)):
            c2 = center_array.copy()
            c2[i] += deltas[i]
            w2 = self.waveform_shift(c2)
            # mm = - (self.fft_match(w1, w2) - 1)
            mm = -match_minus_1(w1, w2, self.freq_vec)
            mt[i, i] = (mm) / deltas[i] ** 2

        for i in range(len(center_array)):
            for j in range(len(center_array)):
                if j >= i:
                    continue
                c2 = center_array.copy()
                c2[i] += deltas[i]
                c2[j] += deltas[j]
                w2 = self.waveform_shift(c2)
                mm = -match_minus_1(w1, w2, self.freq_vec)
                mt[i, j] = (
                    (mm - mt[i, i] * deltas[i] ** 2 - mt[j, j] * deltas[j] ** 2)
                    / 2
                    / deltas[i]
                    / deltas[j]
                )
                mt[j, i] = mt[i, j]

        return mt

    def _post_process_metric(
        self,
        gamma: numpy.ndarray,
        center: Union[coordinate.Coordinates, numpy.ndarray],
        scale: Optional[float] = None,
        method: str = EvaluationMethod.Numeric,
        target_match: float = DEFAULT_TARGET_MATCH,
    ) -> numpy.ndarray:
        """Post processing after metric computed

        Args:
                gamma:
                        N+1xN+1 array

        Returns:
                NxN array with values coerced
        """
        N = gamma.shape[0] - 1
        g = numpy.zeros((N, N))

        # project out the time component Owen 2.28 [1]
        for i, j in itertools.product(range(N), range(N)):
            g[i, j] = gamma[i + 1, j + 1] - (
                gamma[i + 1, 0] * gamma[j + 1, 0] / gamma[0, 0]
            )

        # Check if metric is ill-conditioned
        V, Q = numpy.linalg.eig(g)
        det1 = numpy.prod(V)

        # Compute condition number
        min_abs_eig = numpy.min(numpy.abs(V))
        max_abs_eig = numpy.max(numpy.abs(V))
        condition_number = max_abs_eig / min_abs_eig if min_abs_eig > 0 else numpy.inf

        # Check if metric needs fixing
        is_ill_conditioned = (
            condition_number > 1e8 or numpy.any(V < 0.0) or numpy.isnan(det1)
        )

        if is_ill_conditioned:
            # HARD FAIL - No regularization, no workarounds
            # This makes failures explicit and trackable
            raise ValueError(
                f"Cannot compute valid metric at {center}:\n"
                f"  Method: {method}\n"
                f"  Condition number: {condition_number:.2e}\n"
                f"  Eigenvalues: {V}\n"
                f"  Min eigenvalue: {numpy.min(V):.2e}\n"
                f"  Max eigenvalue: {numpy.max(V):.2e}\n"
                f"  Determinant: {det1:.2e}\n"
                f"\nMetric is ill-conditioned or has negative eigenvalues.\n"
                f"The {method} method cannot produce a valid metric at this point.\n"
                f"Consider using a different method or parameter region."
            )

        V[V < self.coord_func.min_eig_val] = self.coord_func.min_eig_val
        V[V < max(V) * MAX_EPSILON_SCALE] = MAX_EPSILON_SCALE * max(V)
        det2 = numpy.prod(V)
        # FIXME Check this...
        # Avoid NaN when det1 or det2 is zero or negative
        if det1 > 0 and det2 > 0:
            V *= (det1 / det2) ** (1.0 / len(V))
        elif det2 > 0:
            # If original determinant was non-positive,
            # just use the adjusted eigenvalues
            pass
        else:
            # Both determinants are problematic, use a minimum value
            V = numpy.maximum(V, self.coord_func.min_eig_val)
        g = numpy.dot(Q, numpy.dot(numpy.diag(V), Q.T))

        if numpy.any(numpy.isnan(g)):
            raise ValueError("nan metric")

        return g

    def solve_deltas(self, center, t):
        w1 = self.waveform_shift(center)
        deltas = []
        for i in range(len(center)):
            dx = numpy.zeros(len(center))
            dx[i] = 1.0

            def _m(delta, dx=dx, w1=w1, center=center, target=t):
                w2 = self.waveform_shift(center + dx * 10**delta)
                match_m1 = match_minus_1(w1, w2, self.freq_vec)
                return abs(match_m1 - target + 1.0)

            res = optimize.minimize_scalar(
                _m, bounds=(-10, 0), method="bounded", options={"xatol": 1e-2}
            )
            deltas.append(10**res.x)
        return deltas

    def waveform_shift(self, c):
        # By convention time is first coordinate
        w = self.waveform(c[1:])
        if w is None:
            raise RuntimeError(f"Failed to generate waveform at coordinates {c[1:]}")
        if c[0] == 0.0:
            return w
        w.data.data = w.data.data * numpy.exp(-2.0j * numpy.pi * self.freq_vec * c[0])
        return w

    def fft_match_at_coords(
        self, c1: coordinate.Coordinates, c2: coordinate.Coordinates
    ) -> float:
        """Compute fft match at coordinates

        Args:
                c1:
                        Coorindates, the first point
                c2:
                        Coorindates, the second point

        Returns:
                float
        """
        return self.fft_match(self.waveform(c1), self.waveform(c2))

    def fft_match(
        self, w1: lal.COMPLEX16FrequencySeries, w2: lal.COMPLEX16FrequencySeries
    ) -> float:
        """FFT match between two waveforms

        Args:
                w1:
                        COMPLEX16FrequencySeries, the first waveform
                w2:
                        COMPLEX16FrequencySeries, the second waveform

        Returns:
                float, the match number
        """
        self.f_series.data.data[:] = numpy.conj(w1.data.data) * w2.data.data
        lal.COMPLEX16FreqTimeFFT(self.t_series, self.f_series, self.revplan)
        m = (
            numpy.real(numpy.abs(numpy.array(self.t_series.data.data)).max())
            / norm_duration(w1.data.data, self.duration)
            / norm_duration(w2.data.data, self.duration)
        )

        # TODO persist this threshold somewhere
        if m > 1.0000001:
            raise ValueError("Match is greater than 1 : %f" % m)
        # Clamp to [0, 1] to handle floating point precision issues
        return float(min(1.0, max(0.0, m)))

    def metric_match(
        self,
        metric_tensor: common.MetricMatrix,
        c1: coordinate.Coordinates,
        c2: coordinate.Coordinates,
    ) -> float:
        """Compute a match using the metric tensor and distance between points

        Args:
                metric_tensor:
                        MetricMatrix, the coordinate representation of the metric
                c1:
                        Coordinates, the first point
                c2:
                        Coordinates, the second point

        Returns:
                float, the match number
        """
        d2 = self.distance_sq(metric_tensor, c1, c2)
        return float(numpy.exp(-d2))

    def random_point_at_mismatch(
        self,
        g: common.MetricMatrix,
        center: coordinate.Coordinates,
        mismatch: float,
        mismatch_func: Callable[[float], float] = lambda m: m**0.5,
        invert: bool = False,
    ) -> Generator[
        Union[
            Dict[Type[coordinate.CoordinateType], float],
            numpy.ndarray,
            List[Dict[Type[coordinate.CoordinateType], float]],
        ],
        None,
        None,
    ]:
        mat = numpy.linalg.inv(g)
        try:
            L = numpy.linalg.cholesky(mat)
        except numpy.linalg.LinAlgError as e:
            print(mat, numpy.linalg.det(mat))
            raise e

        while True:
            rp = 2 * numpy.random.rand(g.shape[0]) - 1.0
            rp /= numpy.linalg.norm(rp)
            rp *= mismatch_func(mismatch)
            rp_result = self.coord_func(numpy.dot(rp, L.T) + center)
            if isinstance(rp_result, dict) and self.coord_func.__contains__(rp_result):
                if not invert:
                    yield rp_result
                else:
                    yield self.coord_func(rp_result, inv=True)

    def waveform(self, coords: coordinate.Coordinates) -> lal.COMPLEX16FrequencySeries:
        """Method for producing a waveform, this must be defined by subclasses

        Args:
                coords:
                        Tuple[float, ...], a tuple of floats

        Returns:
                Frequency Series
        """
        raise NotImplementedError


def norm_duration(w: lal.COMPLEX16FrequencySeries, duration: int) -> float:
    # TODO reconcile this norm with other norm
    return float((numpy.real((numpy.conj(w) * w).sum()) / duration) ** 0.5)


def norm(w: numpy.ndarray) -> float:
    """Compute a trapezoidal norm

    Args:
            w:
                    Array, the array for which to compute the norm

    Returns:
            float, the norm
    """
    # TODO why not numpy.sqrt?
    n = numpy.abs((numpy.conj(w) * w).sum()) ** 0.5
    return float(n)


def dot(x: numpy.ndarray, y: numpy.ndarray, metric: common.MetricMatrix) -> float:
    # TODO reconcile this with inner_product
    return float(numpy.dot(numpy.dot(x.T, metric), y))


def inner_product(w1: numpy.ndarray, w2: numpy.ndarray) -> float:
    return float(numpy.abs((numpy.conj(w1) * w2).sum()))


def match_minus_1(
    w1: lal.COMPLEX16FrequencySeries,
    w2: lal.COMPLEX16FrequencySeries,
    freq_vec: numpy.ndarray,
    dt: float = 0.0,
) -> float:
    try:
        x = numpy.copy(w1.data.data)
        y = numpy.copy(w2.data.data)
        if w1.epoch != w2.epoch or dt:
            y *= numpy.exp(
                -2.0j * numpy.pi * freq_vec * (dt + float(w2.epoch - w1.epoch))
            )
        y /= norm(y)
        x /= norm(x)
        m = inner_product(x, y)

        return m - 1.0

    except AttributeError:
        # TODO add logging statement here
        return 0.0


def match_minus_1_at_coords_w_t(
    c1: coordinate.Coordinates,
    c2: coordinate.Coordinates,
    g: Metric,
    t1: float = 0.0,
    t2: float = 0.0,
) -> float:
    dt = t2 - t1
    w1 = g.waveform(c1)
    w2 = g.waveform(c2)
    return match_minus_1(w1, w2, g.freq_vec, dt)


def t_factor(
    t_interval: float, freq_interval: float, freq_high: float, working_length: int
) -> numpy.ndarray:
    """Compute t-factor

    Args:
            t_interval:
            freq_interval:
            freq_high:
            working_length:

    Returns:
            Array
    """
    freq_range = numpy.arange(working_length) * freq_interval - freq_high
    return numpy.array(numpy.exp(-2j * numpy.pi * freq_range * t_interval))


def volume_element(metric_tensor: common.MetricMatrix) -> float:
    """Compute volume element of metric matrix

    Args:
            metric_tensor:
                    MetricMatrix, the matrix repr of the metric

    Returns:
            float
    """

    # TODO use numpy ops for abs and sqrt
    return float(float(numpy.linalg.det(metric_tensor)) ** 0.5)


def max_diff_at_edges(
    g: Metric, center: coordinate.Coordinates, m: numpy.ndarray, target_match: float
) -> float:
    m_inv = numpy.linalg.inv(m)
    L = numpy.linalg.cholesky(m_inv)

    e1 = L[:, 0]
    e2 = L[:, 1]

    d = numpy.sqrt(1 - target_match)
    p1 = center + d * e1
    p2 = center + d * e2
    p3 = center - d * e1
    p4 = center - d * e2

    diffs = []
    for p in [p1, p2, p3, p4]:
        fft_mm = 1 - g.fft_match_at_coords(center, p)
        metric_mm = 1 - g.metric_match(m, center, p)
        diffs.append((metric_mm - fft_mm) / metric_mm)
    max_diff = numpy.abs(numpy.array(diffs)).max()

    return float(max_diff)
