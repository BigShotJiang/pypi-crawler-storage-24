# From https://stackoverflow.com/questions/1389180/
# automatically-initialize-instance-variables
import inspect
from functools import wraps


def initializer(func):
    """
    Automatically assigns the parameters.

    >>> class process:
    ...     @initializer
    ...     def __init__(self, cmd, reachable=False, user='root'):
    ...         pass
    >>> p = process('halt', True)
    >>> p.cmd, p.reachable, p.user
    ('halt', True, 'root')
    """
    # Use getfullargspec (Python 3+) instead of deprecated getargspec
    argspec = inspect.getfullargspec(func)
    names = argspec.args
    defaults = argspec.defaults

    @wraps(func)
    def wrapper(self, *args, **kargs):
        for name, arg in list(zip(names[1:], args)) + list(kargs.items()):
            setattr(self, name, arg)

        for name, default in zip(reversed(names), reversed(defaults or [])):
            if not hasattr(self, name):
                setattr(self, name, default)

        func(self, *args, **kargs)

    return wrapper
