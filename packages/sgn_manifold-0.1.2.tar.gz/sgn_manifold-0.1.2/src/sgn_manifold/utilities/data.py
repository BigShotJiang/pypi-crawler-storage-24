"""Data loading utilities"""

from __future__ import annotations

import pathlib
from typing import Union

import lal  # type: ignore[import-untyped]
from lal import series  # type: ignore[import-untyped]
from ligo.lw import utils as ligolw_utils  # type: ignore[import-untyped]

PACKAGE_ROOT = pathlib.Path(__file__).parent.parent
# Data files are now included in the package
DATA_ROOT = PACKAGE_ROOT / "data"
SCRIPT_ROOT = PACKAGE_ROOT / "bin"
# Use the O4 PSD file that's included with the package
TREEBANK_PSD = DATA_ROOT / "O4_projected_psds.xml.gz"
O3A_PSD = DATA_ROOT / "O4_projected_psds.xml.gz"


def read_psd(
    path: Union[str, pathlib.Path], detector: str, verbose: bool = False
) -> lal.REAL8FrequencySeries:
    """Load PSD (power spectral density) from a file for a particular detector

    Args:
            path:
                    str or Path, the location of the data file
            detector:
                    str, the name of the detector for which to extract data from path
            verbose:
                    bool, default False, if True load verbosely using
                    ligo.lw.utils.load_filename(..., verbose=True)

    Returns:
            REAL8FrequencySeries, the psd series
    """
    path = path.as_posix() if isinstance(path, pathlib.Path) else path
    raw_data = ligolw_utils.load_filename(
        path, verbose=verbose, contenthandler=series.PSDContentHandler
    )
    return series.read_psd_xmldoc(raw_data)[detector]
