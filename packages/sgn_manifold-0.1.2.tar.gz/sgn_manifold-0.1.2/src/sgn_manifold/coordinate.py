"""Coordinate system framework for gravitational wave manifold computations.

This module provides a flexible, type-safe coordinate system that enables:
- Definition of custom coordinate types (e.g., mass, spin, frequency)
- Bidirectional coordinate transformations between different representations
- Automatic bounds checking and constraint validation
- Efficient grid generation for parameter space exploration

Architecture:
    CoordinateType: Base class for defining coordinate semantics
    Coordinates: Container for coordinate values with optional type information
    CoordFunc: Abstract base for coordinate transformations

Example:
    Basic usage:
    >>> from sgn_manifold.coordinate import Coordinates
    >>> coords = Coordinates(30.0, 10.0)  # Binary masses
    >>> print(coords[0])  # Access first coordinate
    30.0

    With type information:
    >>> from sgn_manifold.sources.cbc import M1, M2
    >>> coords = Coordinates(30.0, 10.0, coord_types=[M1, M2])
    >>> print(coords)  # Shows typed representation
    Coordinate(m1=30.0, m2=10.0)
"""

from __future__ import annotations

import itertools

# No longer using ABC since no abstract methods
from collections import abc
from typing import Any, Dict, Iterable, List, Optional, Tuple, Type, Union

import numpy
from numpy.typing import NDArray

# Note: Using standard Python exceptions for better compatibility


class CoordinateType:
    """Base class for typing coordinates.

    Subclasses must define a 'key' class attribute that provides
    a string identifier for the coordinate type.

    Example:
        >>> class Mass1(CoordinateType):
        ...     key = "m1"
    """

    key: str


def is_coord_type(x: Any) -> bool:
    """Check if an object is a coordinate type class.

    Args:
        x: Object to check

    Returns:
        True if x is a subclass of CoordinateType, False otherwise
    """
    return isinstance(x, type) and issubclass(x, CoordinateType)


class Coordinates:
    """Container for coordinate values with optional type information.

    This class provides a flexible way to represent points in a coordinate
    system, with support for type annotations and array-like operations.

    Attributes:
        shape: Shape of the underlying coordinate array

    Examples:
        >>> # Create from individual values
        >>> coords = Coordinates(1.0, 2.0, 3.0)

        >>> # Create from list
        >>> coords = Coordinates([1.0, 2.0, 3.0])

        >>> # Create from numpy array
        >>> coords = Coordinates(numpy.array([1.0, 2.0, 3.0]))

        >>> # With type information
        >>> coords = Coordinates(30.0, 10.0, coord_types=[M1, M2])
    """

    __slots__ = ("_array", "_types")

    def __init__(
        self, *args: Any, coord_types: Optional[Iterable[Type[CoordinateType]]] = None
    ):
        """Create a Coordinates object.

        Args:
            *args: Can be:
                - A sequence of scalar values: Coordinates(1, 2, 3)
                - A single iterable: Coordinates([1, 2, 3])
                - A numpy array: Coordinates(numpy.array([1, 2, 3]))
            coord_types: Optional iterable of CoordinateType subclasses (not instances)
                that define the semantic meaning of each coordinate

        Raises:
            ValueError: If no arguments provided
            TypeError: If arguments cannot be converted to numeric array
            CoordinateDimensionError: If number of coordinates doesn't match
                number of coordinate types
        """
        if not args:
            raise ValueError("At least one coordinate value required")

        # Process arguments
        if len(args) == 1:  # Single argument - array or iterable
            if isinstance(args[0], numpy.ndarray):
                self._array = args[0].copy()  # Defensive copy
            elif hasattr(args[0], "__iter__"):
                try:
                    self._array = numpy.asarray(args[0], dtype=numpy.float64)
                except (TypeError, ValueError) as e:
                    raise TypeError(
                        f"Cannot convert {type(args[0])} to coordinate array"
                    ) from e
            else:
                # Single scalar value
                self._array = numpy.array([args[0]], dtype=numpy.float64)
        else:  # Multiple scalar arguments
            try:
                self._array = numpy.array(args, dtype=numpy.float64)
            except (TypeError, ValueError) as e:
                raise TypeError(f"All arguments must be numeric, got: {args}") from e

        # Validate coordinate types match dimension
        if coord_types is not None:
            coord_types = list(coord_types)  # Convert to list for len()
            if len(self._array) != len(coord_types):
                raise ValueError(
                    f"Coordinate dimension {len(self._array)} doesn't match "
                    f"number of types {len(coord_types)}"
                )

        self._types = coord_types

    def __add__(self, other: Any) -> Coordinates:
        """Add two coordinate objects element-wise.

        Args:
            other: Another Coordinates object or array-like

        Returns:
            New Coordinates object with summed values

        Raises:
            CoordinateTypeError: If coordinate types don't match
            TypeError: If other cannot be converted to Coordinates
        """
        try:
            other = to_coordinates(other)
        except (ValueError, TypeError) as e:
            raise TypeError(f"Cannot add Coordinates to {type(other)}") from e

        if not self._compatible_types(other):
            raise ValueError(
                f"Incompatible coordinate types: {self._types} vs {other._types}"
            )

        return Coordinates(self._array + other._array, coord_types=self._types)

    def __sub__(self, other: Any) -> Coordinates:
        """Subtract two coordinate objects element-wise.

        Args:
            other: Another Coordinates object or array-like

        Returns:
            New Coordinates object with difference

        Raises:
            CoordinateTypeError: If coordinate types don't match
            TypeError: If other cannot be converted to Coordinates
        """
        try:
            other = to_coordinates(other)
        except (ValueError, TypeError) as e:
            raise TypeError(f"Cannot subtract {type(other)} from Coordinates") from e

        if not self._compatible_types(other):
            raise ValueError(
                f"Incompatible coordinate types: {self._types} vs {other._types}"
            )

        return Coordinates(self._array - other._array, coord_types=self._types)

    def __getitem__(self, item):
        """Access coordinate values by index."""
        return self._array.__getitem__(item)

    def __iter__(self):
        """Iterate over coordinate values."""
        return self._array.__iter__()

    def __len__(self) -> int:
        """Return number of coordinates."""
        return len(self._array)

    def __repr__(self) -> str:
        """Return string representation of coordinates."""
        if self._types is not None:
            parts = [f"{t.key}={float(c)}" for c, t in zip(self._array, self._types)]
        else:
            parts = [f"{float(c)}" for c in self._array]
        return f"Coordinate({', '.join(parts)})"

    def __eq__(self, other: Any) -> bool:
        """Check equality with another Coordinates object."""
        if not isinstance(other, Coordinates):
            return False
        return numpy.allclose(self._array, other._array) and self._types == other._types

    def _compatible_types(self, other: Coordinates) -> bool:
        """Check if coordinate types are compatible for operations."""
        if not isinstance(other, Coordinates):
            return False
        if self._types is None or other._types is None:
            return True  # Untyped coordinates are compatible with anything
        return self._types == other._types

    @property
    def shape(self) -> Tuple[int, ...]:
        """Shape of the underlying coordinate array."""
        return self._array.shape

    def to_array(self) -> NDArray[numpy.float64]:
        """Return the underlying numpy array.

        Returns:
            Copy of the internal coordinate array
        """
        return self._array.copy()

    def to_dict(self) -> Dict[Type[CoordinateType], float]:
        """Convert to dictionary with coordinate types as keys.

        Returns:
            Dictionary mapping coordinate types to values

        Raises:
            ValueError: If coordinate types are not defined
        """
        if self._types is None:
            raise ValueError("Cannot convert untyped coordinates to dictionary")
        return {t: float(v) for t, v in zip(self._types, self._array)}


# Type alias for coordinate dictionaries
CoordsDict = Dict[Type[CoordinateType], float]


def to_coordinates(x: Union[Iterable, numpy.ndarray, Coordinates]) -> Coordinates:
    """Convert various inputs to a Coordinates object.

    Args:
        x: Input to convert - can be Coordinates, array, or iterable

    Returns:
        Coordinates object

    Raises:
        ValueError: If input cannot be converted to Coordinates
    """
    if isinstance(x, Coordinates):
        return x

    if isinstance(x, (numpy.ndarray, abc.Iterable)):
        return Coordinates(x)

    raise ValueError(f"Unable to coerce {type(x)} to Coordinates")


def to_array(x: Union[Iterable, numpy.ndarray, Coordinates]) -> numpy.ndarray:
    """Convert various inputs to a numpy array.

    Args:
        x: Input to convert - can be Coordinates, array, or iterable

    Returns:
        Numpy array of coordinate values
    """
    if isinstance(x, numpy.ndarray):
        return x

    if isinstance(x, Coordinates):
        return x._array

    return numpy.array(x)


class CoordFunc:
    """Base class for coordinate transformations.

    This class defines the interface for bidirectional coordinate
    transformations with automatic bounds propagation.

    Subclasses must define:
        - FROM_TYPES: Tuple of input coordinate types
        - TO_TYPES: Tuple of output coordinate types
        - __call__: The transformation method

    Attributes:
        from_bounds: Bounds for input coordinates
        to_bounds: Bounds for output coordinates
        mins: Minimum values for input coordinates
        maxes: Maximum values for input coordinates
    """

    # These will be defined by subclasses
    _STANDARD_COORD_TYPES: Tuple[Type[CoordinateType], ...] = ()
    TO_TYPES: Tuple[Type[CoordinateType], ...] = ()
    FROM_TYPES: Tuple[Type[CoordinateType], ...] = ()

    from_bounds: Optional[
        Dict[Type[CoordinateType], Union[List[float], Tuple[float, float]]]
    ] = None
    to_bounds: Optional[
        Dict[Type[CoordinateType], Union[List[float], Tuple[float, float]]]
    ] = None

    def __init__(self, **kwargs: Any) -> None:
        """Initialize coordinate function with bounds.

        Args:
            **kwargs: Bounds specification as keyword arguments.
                Keys should be coordinate type keys or CoordinateType classes.
                Values should be [min, max] pairs.
        """
        self.__kwargs = kwargs
        kwargs_normalized = self._normalize_coorddict(kwargs)
        self._set_bounds(kwargs_normalized)

        if self.from_bounds is not None:
            self.mins = [self.from_bounds[k][0] for k in self.FROM_TYPES]
            self.maxes = [self.from_bounds[k][1] for k in self.FROM_TYPES]
        else:
            self.mins = []
            self.maxes = []

    def to_dict(self) -> Dict[str, Any]:
        """Return configuration as dictionary.

        Returns:
            Dictionary of initialization parameters
        """
        return self.__kwargs.copy()

    def __call__(
        self, c: Union[Coordinates, CoordsDict, numpy.ndarray], inv: bool = False
    ) -> Union[CoordsDict, numpy.ndarray, List[CoordsDict]]:
        """Transform coordinates between coordinate systems.

        Args:
            c: Input coordinates as Coordinates, dictionary, or array
            inv: If True, perform inverse transformation (TO -> FROM)

        Returns:
            Transformed coordinates in appropriate format

        Notes:
            - Forward transform (inv=False): FROM_TYPES -> TO_TYPES
            - Inverse transform (inv=True): TO_TYPES -> FROM_TYPES

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement __call__()"
        )

    def __contains__(self, params: Optional[CoordsDict]) -> bool:
        """Check if coordinates are within valid bounds.

        Args:
            params: Coordinate dictionary to check

        Returns:
            True if coordinates are within bounds, False otherwise
        """
        if params is None:
            return False

        if self.from_bounds is None or self.to_bounds is None:
            return True  # No bounds defined means all points valid

        # Determine which bounds to check based on coordinate types
        if set(self.TO_TYPES) == set(params.keys()):
            values = numpy.array([params[ct] for ct in self.TO_TYPES])
            bounds = self.to_bounds
        elif set(self.FROM_TYPES) == set(params.keys()):
            values = numpy.array([params[ct] for ct in self.FROM_TYPES])
            bounds = self.from_bounds
        else:
            raise ValueError(
                f"Cannot determine bounds for coordinates with keys "
                f"{list(params.keys())}"
            )

        # Check for invalid values
        if any(numpy.isnan(values)) or any(numpy.isinf(values)):
            return False

        # Check bounds
        for k, v in params.items():
            if k in bounds and (v < bounds[k][0] or v > bounds[k][1]):
                return False

        return True

    def _set_bounds(self, bounds: dict) -> None:
        """Set coordinate bounds and compute reciprocal bounds.

        This method handles automatic propagation of bounds through
        the transformation in both directions.

        Args:
            bounds: Dictionary of coordinate bounds

        Raises:
            ValueError: If bounds don't match expected coordinate types
        """
        if set(self.TO_TYPES) == set(bounds.keys()):
            # Bounds specified for output coordinates
            self.to_bounds = bounds

            # Compute input bounds via inverse transformation
            min_coords = {k: self.to_bounds[k][0] for k in self.to_bounds}
            max_coords = {k: self.to_bounds[k][1] for k in self.to_bounds}

            from_min_coords = self(min_coords, inv=True)
            from_max_coords = self(max_coords, inv=True)

            if isinstance(from_min_coords, numpy.ndarray) and isinstance(
                from_max_coords, numpy.ndarray
            ):
                if from_min_coords.shape and from_max_coords.shape:
                    self.from_bounds = dict(
                        zip(
                            self.FROM_TYPES,
                            zip(from_min_coords.tolist(), from_max_coords.tolist()),
                        )
                    )
                else:  # Single coordinate
                    if len(self.FROM_TYPES) > 0:
                        self.from_bounds = {
                            self.FROM_TYPES[0]: [
                                float(from_min_coords),
                                float(from_max_coords),
                            ]
                        }
                    else:
                        self.from_bounds = {}
            else:
                self.from_bounds = {}

        elif set(self.FROM_TYPES) == set(bounds.keys()):
            # Bounds specified for input coordinates
            self.from_bounds = bounds

            # Compute output bounds via forward transformation
            min_coords_array = numpy.array(
                [self.from_bounds[k][0] for k in self.from_bounds]
            )
            max_coords_array = numpy.array(
                [self.from_bounds[k][1] for k in self.from_bounds]
            )

            to_min_coords = self(min_coords_array)
            to_max_coords = self(max_coords_array)

            if isinstance(to_min_coords, dict) and isinstance(to_max_coords, dict):
                self.to_bounds = {
                    t: [to_min_coords[t], to_max_coords[t]] for t in self.TO_TYPES
                }
            else:
                raise ValueError("Expected dict return from coordinate function")
        else:
            raise ValueError(
                f"Unable to set bounds. Keys must match either FROM_TYPES or TO_TYPES. "
                f"Got keys: {list(bounds.keys())}"
            )

    def _normalize_coorddict(
        self, d: Union[CoordsDict, Dict[Any, Any]], inv: bool = False
    ) -> CoordsDict:
        """Normalize coordinate dictionary keys to CoordinateType classes.

        Args:
            d: Dictionary with string or CoordinateType keys
            inv: If True, use standard coordinate types for normalization

        Returns:
            Dictionary with CoordinateType keys

        Raises:
            ValueError: If keys don't match expected coordinate types
        """
        if inv:
            key_type_lookup = {t.key: t for t in self._STANDARD_COORD_TYPES}
        else:
            d_keys = set(_d.key if is_coord_type(_d) else _d for _d in d.keys())
            if d_keys.issubset(set(t.key for t in self.TO_TYPES)):
                key_type_lookup = {t.key: t for t in self.TO_TYPES}
            elif d_keys.issubset(set(t.key for t in self.FROM_TYPES)):
                key_type_lookup = {t.key: t for t in self.FROM_TYPES}
            else:
                raise ValueError(
                    f"Can only normalize dicts whose keys are subsets of "
                    f"TO_TYPES or FROM_TYPES. Got: {d_keys}"
                )

        cd = {}
        for k, v in d.items():
            if is_coord_type(k):
                cd[k] = v
            else:
                # Convert string key to CoordinateType
                cd[key_type_lookup[str(k)]] = v
        return cd

    def grid(self, **kwargs: Any) -> abc.Iterator[Tuple[float, ...]]:
        """Generate a grid of coordinates within bounds.

        Args:
            **kwargs: Number of points for each coordinate.
                Keys should be coordinate type keys or classes.

        Yields:
            Tuples of coordinate values covering the grid

        Raises:
            ValueError: If bounds are not set

        Example:
            >>> func = MyCoordFunc(m1=[10, 50], m2=[10, 50])
            >>> for m1, m2 in func.grid(m1=10, m2=10):
            ...     print(f"m1={m1}, m2={m2}")
        """
        kwargs_normalized = self._normalize_coorddict(kwargs)
        if self.from_bounds is None:
            raise ValueError("Bounds must be set to generate grid")

        if not set(kwargs_normalized).issubset(set(self.from_bounds)):
            raise ValueError(
                f"Grid parameters must be subset of FROM_TYPES. "
                f"Got: {list(kwargs_normalized.keys())}"
            )

        vecs = [
            numpy.linspace(
                self.from_bounds[p][0],
                self.from_bounds[p][1],
                int(kwargs_normalized[p]),
            )
            for p in kwargs_normalized
        ]

        for coord in itertools.product(*vecs):
            yield coord

    # Methods that may be implemented by subclasses
    def dx(self, c: Coordinates) -> numpy.ndarray:
        """Compute coordinate differentials at given point.

        Args:
            c: Coordinates at which to evaluate

        Returns:
            Array of coordinate differentials

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(f"{self.__class__.__name__} does not implement dx()")

    def random(self) -> Tuple[float, ...]:
        """Generate random coordinates within bounds.

        Returns:
            Tuple of random coordinate values

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement random()"
        )

    def base_step(self, center: Union[Coordinates, numpy.ndarray]) -> float:
        """Compute base step size at given coordinates.

        Args:
            center: Center point for step size calculation

        Returns:
            Recommended step size

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement base_step()"
        )

    def target_match(self, center: Union[Coordinates, numpy.ndarray]) -> float:
        """Compute target match value at given coordinates.

        Args:
            center: Coordinates for match calculation

        Returns:
            Target match value

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement target_match()"
        )

    @property
    def min_eig_val(self) -> float:
        """Minimum eigenvalue of the metric.

        Returns:
            Minimum eigenvalue

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement min_eig_val"
        )

    def min_scale(self, coords: Union[Coordinates, numpy.ndarray]) -> float:
        """Compute minimum scale at given coordinates.

        Args:
            coords: Coordinates for scale calculation

        Returns:
            Minimum scale value

        Raises:
            NotImplementedError: If not implemented by subclass
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} does not implement min_scale()"
        )
