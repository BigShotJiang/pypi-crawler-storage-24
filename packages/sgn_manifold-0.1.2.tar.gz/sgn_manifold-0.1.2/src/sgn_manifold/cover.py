#!/usr/bin/env python
from __future__ import annotations

import enum
import itertools
import logging
from typing import Any, Callable, Dict, Iterable, List, Optional, Tuple

import numpy
from matplotlib import patches
from scipy.spatial import Rectangle  # type: ignore[import-untyped]
from scipy.special import gamma  # type: ignore[import-untyped]
from scipy.stats import beta  # type: ignore[import-untyped]

from sgn_manifold.metric import EvaluationMethod, volume_element

logger = logging.getLogger(__name__)


class SizeMethod(str, enum.Enum):
    """Enumeration of methods for determining the size of a rectangle.

    Measure the sizes is primarily used for the purpose of splitting the rectangle
    into two smaller rectangles. The algorithm splits along the "longest" side of
    the rectangle, where the "longest" side is determined by the size method.

    Attributes:
            Proper: str, "proper", the size of the rectangle in each dimension,
                as measured by the metric
    """

    Proper = "proper"


class DummyRectangle:
    """Dummy rectangle class for checking point-is-inside constraints"""

    def __init__(self, center):
        self.center = center


class ConstraintExteriorError(ValueError):
    """Raised when a point is outside of a constraint submanifold"""


class ManifoldRectangle(Rectangle):
    def __init__(
        self,
        mins: Any,
        maxes: Any,
        metric: Any,
        g: Optional[Any] = None,
        level: int = 0,
        right: bool = False,
        left: bool = False,
        method: str = EvaluationMethod.Deterministic,
        meta: Optional[Dict[str, Any]] = None,
    ) -> None:
        Rectangle.__init__(self, mins, maxes)
        self.metric = metric
        self.method = method
        self.meta = meta or {}
        # TODO rethink this architecture of embedding metric function arguments
        # as attributes of ManifoldRectangle?
        # TODO rename "method" to "est_method" for clarity
        if g is None and metric is not None:
            # Simply evaluate metric at center
            center_to_use = self.center
            max_retries = 50

            for attempt in range(max_retries):
                try:
                    self.g = self.metric(
                        center_to_use,
                        method=self.method,
                    )
                    break  # Success!
                except ValueError as e:
                    # If metric evaluation fails, try with slightly
                    # perturbed coordinates
                    if (
                        "Cannot compute valid metric" in str(e)
                        and attempt < max_retries - 1
                    ):
                        # Try perturbation with increasing fraction of rectangle size
                        import warnings

                        center_to_use = self._perturb_center_for_metric(attempt=attempt)
                        fraction = min(0.01 + 0.01 * attempt, 0.5)
                        warnings.warn(
                            f"Metric evaluation failed "
                            f"(attempt {attempt+1}/{max_retries}), "
                            f"retrying with fraction={fraction:.3f} of "
                            f"rectangle size",
                            stacklevel=2,
                        )
                    else:
                        raise

        elif g is not None:
            self.g = g
        else:
            self.g = numpy.diag(numpy.ones(len(mins)))
        self.edges = numpy.diag(self.coordinate_size)
        self.level = level
        self.right = right
        self.left = left

    # FIXME this object is technically not immutable so it is a bad idea, so
    # be careful
    def __hash__(self):
        mins_rounded = numpy.round(self.mins, 4)
        maxes_rounded = numpy.round(self.maxes, 4)
        # Convert to lists - handling both array and scalar cases
        mins_list: list = []
        maxes_list: list = []

        # Always convert to flat list
        if hasattr(mins_rounded, "tolist"):
            vals = mins_rounded.tolist()
            mins_list = (
                vals if isinstance(vals, list) else [vals]  # type: ignore[unreachable]
            )
        else:
            mins_list = [float(mins_rounded)]

        if hasattr(maxes_rounded, "tolist"):
            vals = maxes_rounded.tolist()
            maxes_list = (
                vals if isinstance(vals, list) else [vals]  # type: ignore[unreachable]
            )
        else:
            maxes_list = [float(maxes_rounded)]

        return hash(tuple(mins_list + maxes_list))

    def __eq__(self, other):
        return numpy.array_equal(self.mins, other.mins) and numpy.array_equal(
            self.maxes, other.maxes
        )

    def ball_volume(self, r=0.17):
        # NOTE for templates r = mismatch**.5; So r=0.17 corresponds to
        # a mismatch of 2.9%
        N = len(self.mins)
        return numpy.pi * (N / 2) / gamma(N / 2 + 1) * r ** (N)

    def num_balls(self, r=0.17):
        # NOTE for templates r = mismatch**.5; So r=0.17 corresponds to
        # a mismatch of 2.9%
        # NOTE it is impossible to pack spheres this tightly. This
        # should be considered a lower bound
        return self.proper_volume / self.ball_volume(r=r)

    def update_meta(self, **kwargs):
        if self.meta is None:
            self.meta = {}
        self.meta.update(kwargs)

    @property
    def vertices(self):
        for v in itertools.product(*zip(self.mins, self.maxes)):
            yield v

    @property
    def center(self):
        return self.mins + self.coordinate_size / 2

    def _perturb_center_for_metric(self, attempt=0):
        """
        Perturb the center point to avoid metric evaluation failures.
        Samples randomly within the rectangle with increasing perturbation size.

        Parameters
        ----------
        attempt : int
            Attempt number (0-49), controls perturbation size.
            Perturbation fraction increases from 1% to 50% with attempts.
        """
        # Calculate perturbation fraction based on attempt
        # Starts at 0.01, increases by 0.01 each attempt, up to 0.5
        fraction = min(0.01 + 0.01 * attempt, 0.5)

        # Get rectangle side lengths
        side_lengths = self.coordinate_size  # This is (maxes - mins)

        # Generate random perturbation within fraction of side lengths
        # Use local random state to avoid affecting global random state
        rng = numpy.random.Generator(numpy.random.PCG64(42 + attempt))
        perturbation = (rng.random(len(self.center)) - 0.5) * 2  # Random in [-1, 1]
        perturbation *= fraction * side_lengths  # Scale by fraction of side lengths

        # Apply perturbation to center
        new_center = self.center + perturbation

        # Ensure new center stays within rectangle bounds
        new_center = numpy.clip(new_center, self.mins, self.maxes)

        return new_center

    @property
    def metric_center(self):
        # NOTE you could override this method to provide a more natural notion
        # of "center" for a given coordinate system
        return self.center

    def split(
        self, d: int, split: float, reuse_g: bool = False
    ) -> Tuple["ManifoldRectangle", "ManifoldRectangle"]:
        """Produce two hyperrectangles by splitting.
        In general, if you need to compute maximum and minimum
        distances to the children, it can be done more efficiently
        by updating the maximum and minimum distances to the parent.
        Parameters
        ----------
        d : int
                Axis to split hyperrectangle along.
        split : float
                Position along axis `d` to split at.
        """
        mid = numpy.copy(self.maxes)
        mid[d] = split
        less = type(self)(
            self.mins,
            mid,
            self.metric,
            g=None if not reuse_g else self.g,
            level=self.level + 1,
            right=True,
            left=False,
            method=self.method,
            meta=None,
        )
        mid = numpy.copy(self.mins)
        mid[d] = split
        greater = type(self)(
            mid,
            self.maxes,
            self.metric,
            g=None if not reuse_g else self.g,
            level=self.level + 1,
            right=False,
            left=True,
            method=self.method,
            meta=None,
        )
        return less, greater

    def bisect(
        self, d: int, reuse_g: bool = False
    ) -> Tuple["ManifoldRectangle", "ManifoldRectangle"]:
        return self.split(d, self.center[d], reuse_g=reuse_g)

    def divide(
        self,
        size_method: SizeMethod = SizeMethod.Proper,
        reuse_g: bool = False,
        aspect_ratios: Optional[Any] = None,
        global_factor: Optional[float] = None,
        local_dist_bounds: Optional[Tuple[float, float]] = None,
        local_dist_beta: Optional[Tuple[float, float]] = None,
    ) -> Tuple["ManifoldRectangle", "ManifoldRectangle"]:
        proper_size = self.size(
            method=size_method,
            global_factor=global_factor,
            local_dist_bounds=local_dist_bounds,
            local_dist_beta=local_dist_beta,
            aspect_ratios=aspect_ratios,
        )
        return self.bisect(int(numpy.argmax(proper_size)), reuse_g=reuse_g)

    @property
    def coordinate_size(self) -> numpy.ndarray:
        """Determine the coordinate size of the rectangle.

        This is the size of the rectangle in each dimension ignoring the metric.

        Returns:
                numpy.ndarray, the size of the rectangle in each dimension
                (ignoring the metric)
        """
        return numpy.array(self.maxes - self.mins)

    @property
    def proper_size(self) -> numpy.ndarray:
        """Determines the proper size of the rectangle.

        This is the size of the rectangle in each dimension, as measured by
        the metric.

        Returns:
                numpy.ndarray, the size of the rectangle in each dimension
                (as measured by the metric)
        """
        origin = numpy.zeros(len(self.edges))
        return numpy.array(
            [self.metric.distance(self.g, origin, edge) for edge in self.edges]
        )

    @property
    def local_aspect_ratio(self):
        """The local aspect ratio is proper sizes of a unit-rectangle.

        (unit in the coordinate sense) that is concentric with this rectangle.

        Returns:
                numpy.ndarray, the local aspect ratio of the rectangle
        """
        origin = numpy.zeros(len(self.edges))
        p111 = numpy.diag(numpy.ones(len(self.edges)))
        return numpy.array(
            [self.metric.distance(self.g, origin, unit_edge) for unit_edge in p111]
        )

    @property
    def local_distortion(self):
        """The local distortion is the ratio of max to min aspect.

        It's the ratio of the maximum aspect to minimum aspect of the local
        aspect ratio.

        Returns:
                float, the local distortion of the rectangle
        """
        return numpy.max(self.local_aspect_ratio) / numpy.min(self.local_aspect_ratio)

    def interpolated_size(
        self,
        global_factor: Optional[float] = None,
        local_dist_bounds: Optional[Tuple[float, float]] = None,
        local_dist_beta: Optional[Tuple[float, float]] = None,
    ) -> Any:
        """Interpolate the size of the rectangle between coordinate and metric.
        Interpolates between coordinate distance and metric distance in each
        dimension, allowing for both global and local control.

                Global control:
                        Simply the linear interpolation factor, where 0 means the
                        proper size and 1 means the coordinate size. The
                        interpolation factor can be thought of
                        as a control for metric insensitivity, where 0 means the
                        distances are fully sensitive to the metric and 1 means
                        distances are insensitive to the metric.

                Local control:
                        More complicated, relies on a notion of "local distortion"
                        and a beta distribution. "Local Distortion" is a relative
                        measure of the local aspect ratio of the metric
                        (local = at the center of the rectangle). We define the
                        local distortion as the ratio of the maximum aspect to
                        minimum aspect. Specifically, the local distortion is:

                                local_distortion = max(local_aspect_ratio) / \
                                                   min(local_aspect_ratio)

                        The local distortion is then used to determine the
                        interpolation factor, which is controlled by a beta
                        distribution. The beta distribution is parameterized by
                        local_dist_beta, which
                        controls the shape of the distribution, and
                        local_dist_bounds, which controls the range of the
                        distribution. Some examples:

                                - If local_dist_beta = (1, 1), then the beta
                                  distribution is uniform, and the interpolation
                                  factor is simply the local_distortion, scaled
                                  to the range of local_dist_bounds.
                                - If local_dist_beta = (1, 2), then the beta
                                  distribution is skewed towards the lower bound
                                  (proper size), and the interpolation factor is
                                  biased towards the lower bound (proper size).
                                - If local_dist_beta = (2, 1), then the beta
                                  distribution is skewed towards the upper bound
                                  (coordinate size), and the interpolation factor
                                  is biased towards the upper bound (coordinate
                                  size).

                        A motivating use case for local control is when a
                        particular coordinate becomes nearly degenerate, and the
                        metric becomes somewhat insensitive to the coordinate.
                        For example, in the
                        LogM1, LogM2, Chi coordinates, at low masses, the metric
                        becomes less sensitive to the chi coordinate, and the chi
                        coordinate becomes nearly degenerate. If unchecked, this
                        can result
                        in template rectangles that are extremely "skinny" in the
                        chi direction, which can lead to poor coverage of the
                        parameter space. By using local control, we can partially
                        force the splitting to occur in the chi direction, even
                        when the metric is insensitive to the chi coordinate, by
                        forcing the interpolation factor to be biased towards the
                        coordinate size.

        Args:
                global_factor:
                        float, default None, the global factor for scaling the
                        size of the rectangle. If None, then no global scaling
                        is applied. If specified, then the size of the rectangle
                        is linearly interpolated between the coordinate and
                        proper sizes, with the global factor controlling the
                        interpolation, where 0 means the coordinate size and 1
                        means the proper size.
                local_dist_bounds:
                        Tuple[float, float], default None, the bounds for the
                        local distortion. If specified, then the local distortion
                        is scaled to the range of the local_dist_bounds. If None,
                        then no local scaling is applied.
                local_dist_beta:
                        Tuple[float, float], default None, the parameters for the
                        beta distribution that controls the interpolation factor.
                        If specified, then the interpolation factor is controlled
                        by the beta distribution. If None, then no local scaling
                        is applied.

        References:
                [1] https://en.wikipedia.org/wiki/Beta_distribution

        Returns:
                numpy.ndarray, the size of the rectangle in each dimension,
                interpolated between the coordinate and proper sizes
        """
        factor = None

        if global_factor is not None:
            if global_factor < 0 or global_factor > 1:
                raise ValueError(
                    f"Global factor must be in [0, 1], got {global_factor}"
                )

            factor = global_factor

        if local_dist_bounds is not None and local_dist_beta is not None:
            # TODO move this config validation to a separate layer, likely
            # with a formal specification of the config parameters
            if local_dist_bounds[0] > local_dist_bounds[1]:
                raise ValueError(
                    f"Local distance bounds must be in increasing order, "
                    f"got local_dist_bounds={local_dist_bounds}"
                )
            if local_dist_beta[0] <= 0 or local_dist_beta[1] <= 0:
                raise ValueError(
                    f"Local distance beta parameters must be positive, "
                    f"got local_dist_beta={local_dist_beta}"
                )

            # Unpack the local distance bounds and beta parameters
            dist_min, dist_max = local_dist_bounds
            beta_a, beta_b = local_dist_beta

            # Compute local distortion
            local_dist = self.local_distortion

            # Clip the local distortion to the bounds
            local_dist = min(dist_max, max(dist_min, local_dist))

            # Regularize the local distortion to the range of the beta
            # distribution
            local_dist = (local_dist - dist_min) / (dist_max - dist_min)

            # Compute the interpolation factor using the beta distribution
            factor = beta(beta_a, beta_b).cdf(local_dist)

        if factor is not None:
            return factor * self.coordinate_size + (1 - factor) * self.proper_size

        raise ValueError(
            f"Must specify either global factor or local distance bounds and "
            f"beta to interpolate size of rectangle, got "
            f"global_factor={global_factor}, "
            f"local_dist_bounds={local_dist_bounds}, "
            f"local_dist_beta={local_dist_beta}"
        )

    def size(
        self,
        method: SizeMethod = SizeMethod.Proper,
        global_factor: Optional[float] = None,
        local_dist_bounds: Optional[Tuple[float, float]] = None,
        local_dist_beta: Optional[Tuple[float, float]] = None,
        aspect_ratios: Optional[numpy.ndarray] = None,
    ) -> numpy.ndarray:
        """Determine the size of the rectangle in each dimension.

        Uses the proper metric method to measure the size of the rectangle.

        Args:
                method:
                        SizeMethod, default SizeMethod.Proper, kept for backward
                        compatibility. Only SizeMethod.Proper is supported.
                global_factor:
                        Deprecated, ignored.
                local_dist_bounds:
                        Deprecated, ignored.
                local_dist_beta:
                        Deprecated, ignored.
                aspect_ratios:
                        numpy.ndarray, default None, the aspect ratios to use for
                        splitting the rectangle. If None, then the aspect ratio
                        is determined by the proper size of the rectangle.

        Returns:
                numpy.ndarray, the size of the rectangle in each dimension,
                as measured by the metric
        """
        if method != SizeMethod.Proper:
            raise ValueError(f"Only SizeMethod.Proper is supported, got: {method}")

        if aspect_ratios is None:
            return numpy.array(self.proper_size)
        return numpy.array(self.proper_size * aspect_ratios)

    @property
    def volume(self):
        return Rectangle.volume(self)

    @property
    def proper_volume(self):
        return volume_element(self.g) * self.volume

    def patch(self, x=0, y=1):
        assert len(self.mins) > 1
        return patches.Rectangle(
            (self.mins[x], self.mins[y]),
            self.coordinate_size[x],
            self.coordinate_size[y],
            edgecolor="k",
            facecolor="none",
        )

    def is_inside_constraints(
        self, constraints: Iterable[Callable], interpolation: int = 0
    ) -> bool:
        """Check if the rectangle is inside a set of constraint functions

        Args:
                constraints:
                        Iterable[Callable], a collection of functions that take
                        a point and return True if the point is INSIDE the
                        constraint, such that constraint(p) == True implies p
                        PASSES the constraint
                interpolation:
                        int, default 0, if > 0, then subdivide the rectangle
                        into a grid of interpolation**len(self.mins) points and
                        check each point for constraint satisfaction. If any
                        point is inside the constraint, then the rectangle is
                        considered inside the constraint. By default, the center
                        and vertices of the rectangle are checked.

        Returns:
                bool, True if the rectangle is inside the constraints,
                False otherwise
        """
        if interpolation > 0:
            # If specified, subdivide each axis into 2^interpolation + 1 points,
            # then take cartesian product of these points to form grid
            grid = list(
                itertools.product(
                    *[
                        numpy.linspace(
                            self.mins[i], self.maxes[i], 2**interpolation + 1
                        )
                        for i in range(len(self.mins))
                    ]
                )
            )
        else:
            # Otherwise, just check the center and vertices
            grid = [self.center] + list(self.vertices)

        for p in grid:
            # Eagerly return True if any point is inside the constraint
            if all(constraint(p) for constraint in constraints):
                return True

        # If no point is inside the constraint, then the rectangle is outside
        # the constraint
        return False


def tmpvol(mm=0.01, N=2):
    return (2 * (mm / N) ** 0.5) ** N


class Chart(object):

    def __init__(
        self,
        data: Any,
        parent: Optional["Chart"] = None,
        excluded: Optional[List] = None,
    ) -> None:
        self.left: Optional[Chart] = None
        self.right: Optional[Chart] = None
        self.data = data
        self.parent = parent

        # Determine the proper behavior regarding recording of excluded rectangles
        # If no excluded specified, attempt to inherit from parent
        if excluded is None:
            # If parent is None, then not tracking
            if parent is None:
                self.excluded = None
            # Otherwise, inherit from parent
            else:
                self.excluded = parent.excluded
        # Otherwise, set to specified value
        else:
            self.excluded = excluded

    def branch(
        self,
        mm: float = 0.02,
        reuse_g_mm: float = 0.0,
        reuse_g_vol_tol: float = 0.1,
        constraints: Tuple[Callable, ...] = (lambda x: True,),
        verbose: bool = False,
        cnt: Optional[Any] = None,
        aspect_ratios: Optional[Any] = None,
        min_coord_vol: float = numpy.inf,
        min_depth: int = 11,
        max_num_templates: int = 1,
        size_method: SizeMethod = SizeMethod.Proper,
        global_factor: Optional[float] = None,
        local_dist_bounds: Optional[Tuple[float, float]] = None,
        local_dist_beta: Optional[Tuple[float, float]] = None,
    ) -> None:
        if cnt is None:
            cnt = [0]

        def inside(r, constraints=constraints):
            # Assume inside
            out = True

            # For each constraint
            for constraint in constraints:
                # Recall, constraint(v) returns True if v is OUTSIDE the
                # constraint, so True = Failure
                # If all vertices and the center are outside the constraint,
                # then the rectangle is outside the constraint
                verts = list(r.data.vertices) + [list(r.data.center)]
                out &= not all(constraint(v) for v in verts)
            return out

        def boundary(r, constraints=constraints):
            out = False
            for constraint in constraints:
                out |= any(constraint(v) for v in r.data.vertices)
            return out

        proper_volume = self.data.proper_volume
        tvol = tmpvol(mm, len(self.data.center))
        Ntmps = max(proper_volume / tvol, self.data.volume / min_coord_vol)
        volratio = (
            (numpy.inf if self.parent is None else self.parent.data.proper_volume)
            / proper_volume
            / 2.0
        )
        reuse_g = (proper_volume < tmpvol(reuse_g_mm, len(self.data.center))) and (
            (1 - reuse_g_vol_tol) < volratio < (1 + reuse_g_vol_tol)
        )

        if Ntmps > max_num_templates or self.data.level < min_depth + 1:
            ldat, rdat = self.data.divide(
                size_method=size_method,
                reuse_g=reuse_g,
                aspect_ratios=aspect_ratios,
                global_factor=global_factor,
                local_dist_bounds=local_dist_bounds,
                local_dist_beta=local_dist_beta,
            )
            left = Chart(ldat, self)
            right = Chart(rdat, self)
            inl = inside(left)
            inr = inside(right)

            # If left subdivision is inside the constraints (or is
            # insufficiently deep), then keep track of it and potentially
            # proceed to the next level
            if inl or left.data.level < min_depth:
                self.left = left
                self.left.branch(
                    mm=mm,
                    reuse_g_mm=reuse_g_mm,
                    reuse_g_vol_tol=reuse_g_vol_tol,
                    constraints=constraints,
                    verbose=verbose,
                    cnt=cnt,
                    aspect_ratios=aspect_ratios,
                    min_coord_vol=min_coord_vol,
                    min_depth=min_depth,
                    max_num_templates=max_num_templates,
                    size_method=size_method,
                    global_factor=global_factor,
                    local_dist_bounds=local_dist_bounds,
                    local_dist_beta=local_dist_beta,
                )
            else:
                # Record the pruned rectangle if applicable
                if self.excluded is not None:
                    self.excluded.append(left.data)

            # If right subdivision is inside the constraints (or is
            # insufficiently deep), then keep track of it and potentially
            # proceed to the next level
            if inr or right.data.level < min_depth:
                self.right = right
                self.right.branch(
                    mm=mm,
                    reuse_g_mm=reuse_g_mm,
                    reuse_g_vol_tol=reuse_g_vol_tol,
                    constraints=constraints,
                    verbose=verbose,
                    cnt=cnt,
                    aspect_ratios=aspect_ratios,
                    min_coord_vol=min_coord_vol,
                    min_depth=min_depth,
                    max_num_templates=max_num_templates,
                    size_method=size_method,
                    global_factor=global_factor,
                    local_dist_bounds=local_dist_bounds,
                    local_dist_beta=local_dist_beta,
                )
            else:
                # Record the pruned rectangle if applicable
                if self.excluded is not None:
                    self.excluded.append(right.data)

        elif verbose:
            cnt[0] += 1
            if not cnt[0] % 100:
                logger.info(
                    "Processed %d rectangles: %s, volratio=%s",
                    cnt[0],
                    self.data,
                    volratio,
                )

    def atlas(self):
        if self.left:
            yield from self.left.atlas()
        if self.right:
            yield from self.right.atlas()
        if not self.left and not self.right:
            yield self.data
