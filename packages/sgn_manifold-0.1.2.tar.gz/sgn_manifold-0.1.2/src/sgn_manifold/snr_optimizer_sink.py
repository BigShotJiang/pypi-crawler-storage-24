"""SNR Optimizer as SGN-TS Sink Element

This module implements the SNR optimizer for CBC template banks as an
SGN time-series sink element.

Copyright (C) 2024 Chad Hanna

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.
"""

from __future__ import annotations

import json
import logging
import os
import threading
from collections import deque
from dataclasses import dataclass, field
from io import BytesIO
from typing import Dict, Optional

import numpy
from confluent_kafka import (  # type: ignore[import-untyped]
    Consumer,
    KafkaError,
    Producer,
)
from ligo.lw import ligolw, lsctables  # type: ignore[import-untyped]
from ligo.lw import utils as ligolw_utils  # type: ignore[import-untyped]
from ligo.segments import segment, segmentlistdict  # type: ignore[import-untyped]
from sgn.base import SinkPad  # type: ignore[import-untyped]
from sgnts.base import (  # type: ignore[import-untyped]
    SeriesBuffer,
    TimeSpanFrame,
    TSSink,
)
from strike.stats.inspiral_extrinsics import (  # type: ignore[import-untyped]
    TimePhaseSNR,
)

from sgn_manifold import snr_optimizer
from sgn_manifold.sources import cbc


# Define content handler for LIGOLW
class LIGOLWContentHandler(ligolw.LIGOLWContentHandler):
    pass


lsctables.use_in(LIGOLWContentHandler)


logger = logging.getLogger(__name__)


def nullseg():
    """Return an empty segment"""
    return segment(0, 0)


@dataclass
class SNROptimizerSink(TSSink):
    """SNR optimizer sink element for CBC template bank optimization.

    This sink receives:
    - Whitened time-series data from multiple detectors (aligned)
    - PSD estimates per detector (unaligned)

    It performs online SNR optimization of template banks for compact
    binary coalescence searches.

    Args:
        channel_dict: Dict mapping IFO names to channel names
        kafka_server: Kafka server for event streaming
        job_tag: Job identification tag
        analysis_tag: Analysis pipeline tag
        input_topic: Kafka topic for input events
        rate: Sample rate of whitened data (Hz)
        durations: List of FFT durations to consider (seconds)
        search_window: Time window for trigger search (seconds)
        min_instruments: Minimum number of detectors required
        inspiral_extrinsics: TimePhaseSNR instance for likelihood calculation
        seed_bank: Template bank for optimization
        psd_fft_length: FFT length for PSD estimation (seconds)
        psd: Initial PSD estimates per detector
        template_psd: Template PSD per detector
        flow: Low frequency cutoff (Hz)
        min_mismatch: Minimum mismatch for template spacing
        is_live: Whether processing live data
        algorithm: Optimization algorithm ("rectangle" or "random")
        output_name: Output filename for results
        nearest: Number of nearest templates to consider
        request_timeout: Kafka request timeout (seconds)
        maximize_L: Whether to maximize likelihood (vs SNR)
        original_template_only: Only process original template
        instrument_override: Instruments to skip processing
    """

    # Required parameters
    channel_dict: Dict[str, str] = field(default_factory=dict)
    instruments: list[str] = field(init=False)

    # Kafka configuration
    kafka_server: Optional[str] = None
    job_tag: str = "snr_optimizer"
    analysis_tag: str = "manifold"
    input_topic: Optional[str] = None

    # Processing parameters
    rate: int = 2048
    durations: tuple = field(default_factory=lambda: (128, 64, 32, 16, 8, 4, 1))
    search_window: int = 1
    min_instruments: int = 2

    # Statistical configuration
    inspiral_extrinsics: Optional[TimePhaseSNR] = None

    # Template bank
    seed_bank: Optional[cbc.Bank] = None  # type: ignore[name-defined]

    # PSD configuration
    psd_fft_length: int = 8
    psd: Dict = field(default_factory=dict)
    template_psd: Optional[Dict] = None

    # Waveform parameters
    flow: float = 10.0
    min_mismatch: float = 0.001

    # Runtime configuration
    is_live: bool = True
    algorithm: str = "rectangle"
    output_name: str = "snr_optimizer_coinc.xml"
    nearest: int = 1000
    request_timeout: float = 0.05
    maximize_L: bool = False
    original_template_only: bool = False
    instrument_override: Optional[list[str]] = None

    # SGN-TS configuration (computed)
    unaligned: list[str] = field(init=False)

    def __post_init__(self):
        """Initialize SNROptimizerSink.

        Sets up:
        - Detector pad configuration (data + PSD pads)
        - Data buffers and state tracking
        - Kafka producer/consumer
        - PSD and horizon distance calculators
        """
        # Derive instruments from channel dict
        self.instruments = list(self.channel_dict.keys())

        # Set up SGN pad configuration
        # Data pads: aligned time-series data
        # PSD pads: unaligned PSD estimates
        self.sink_pad_names = [
            *[f"data_{ifo}" for ifo in self.instruments],
            *[f"psd_{ifo}" for ifo in self.instruments],
        ]

        # PSD pads don't need time alignment
        self.unaligned = [f"psd_{ifo}" for ifo in self.instruments]

        # Call TSSink initialization (TimeSeriesMixin + SinkElement)
        super().__post_init__()

        # Threading lock for concurrent data access
        self.lock = threading.Lock()

        # Data buffers (deques for streaming data)
        # Each deque entry: {"segment": segment(start, end), "data": numpy.array}
        self.datadeq = {ifo: deque(maxlen=4096) for ifo in self.instruments}

        # Event queue (events from Kafka to process)
        self.eventdeq = deque(maxlen=1)

        # Tracking variables for buffer continuity
        self.next_t0 = {ifo: None for ifo in self.instruments}
        self.first_t0 = {ifo: None for ifo in self.instruments}
        self.last_event_time = 0

        # Kafka setup (if live processing)
        if self.is_live and self.kafka_server:
            self._setup_kafka()
        else:
            self.consumer = None
            self.producer = None

        logger.info(
            "SNROptimizerSink initialized for instruments: %s", self.instruments
        )
        logger.info("Data pads: %s", [f"data_{ifo}" for ifo in self.instruments])
        logger.info("PSD pads (unaligned): %s", self.unaligned)

    def _setup_kafka(self):
        """Set up Kafka consumer and producer for live data processing"""
        # Kafka settings
        kafka_settings = {
            "bootstrap.servers": self.kafka_server,
            "group.id": "-".join(
                [
                    (
                        "snr_optimizer"
                        if not self.instrument_override
                        else "skymap_snr_optimizer"
                    ),
                    self.analysis_tag,
                ]
            ),
        }

        # Producer settings
        producer_settings = {
            "message.max.bytes": 10485760,  # 10 MB
            **kafka_settings,
        }

        self.producer = Producer(producer_settings)
        self.consumer = Consumer(kafka_settings)

        # Subscribe to input topic
        full_topic = f"gstlal.{self.analysis_tag}.{self.input_topic}"
        logger.info("Subscribing to Kafka topic: %s", full_topic)
        self.consumer.subscribe([full_topic])

        # Number of messages to fetch per poll
        self.num_messages = 100

    def pull(self, pad: SinkPad, frame: TimeSpanFrame) -> None:
        """Route incoming frames to appropriate handlers.

        Data frames are queued for alignment via TimeSeriesMixin.
        PSD frames are processed immediately (unaligned).

        Args:
            pad: Sink pad receiving the frame
            frame: Time-series frame with data or PSD
        """
        # Get pad name
        pad_name = self.rsnks[pad]  # Reverse lookup: pad -> name

        if pad_name.startswith("psd_"):
            # PSD update - handle immediately (unaligned)
            ifo = pad_name.replace("psd_", "")
            self._on_psd_frame(ifo, frame)
            # Mark EOS for unaligned pads
            if frame.EOS:
                self.mark_eos(pad)
        else:
            # Data frame - let TimeSeriesMixin handle alignment
            super().pull(pad, frame)

    def _on_psd_frame(self, ifo: str, frame: TimeSpanFrame) -> None:
        """Process PSD estimate frame.

        Condition V2 delivers PSDs in frame.metadata['psd'] as SWIG LAL
        REAL8FrequencySeries objects.  The buffer payload is a gap placeholder.

        Args:
            ifo: Detector name (e.g., "H1", "L1")
            frame: TSFrame containing PSD estimate
        """
        psd_obj = frame.metadata.get("psd") if hasattr(frame, "metadata") else None
        if psd_obj is not None:
            with self.lock:
                self.psd[ifo] = psd_obj
            logger.debug("Updated PSD for %s", ifo)

    def internal(self) -> None:
        """Process aligned data frames and handle events.

        This is the main processing method, called after all sink pads
        have pulled data and TimeSeriesMixin has aligned the frames.

        """
        # Let TimeSeriesMixin align frames
        super().internal()

        # Process each aligned data frame
        with self.lock:
            for pad in self.aligned_sink_pads:
                frame = self.preparedframes[pad]

                if frame is None:
                    continue  # No data yet

                # Check for EOS and mark it
                if frame.EOS:
                    self.mark_eos(pad)

                # Determine IFO from pad name
                pad_name = self.rsnks[pad]
                ifo = pad_name.replace("data_", "")

                # Process each buffer in the frame
                for buf in frame:
                    if not buf.is_gap and buf.data is not None:
                        self._process_data_buffer(ifo, buf)

        # Check if all pads are at EOS and finalize
        if self.at_EOS:
            self._finalize()

    def _process_data_buffer(self, ifo: str, buf: SeriesBuffer) -> None:
        """Process a single whitened data buffer.

        Args:
            ifo: Detector name (e.g., "H1", "L1")
            buf: SeriesBuffer containing whitened time-series data
        """
        # Check for buffer continuity
        next_t0 = self.next_t0[ifo]
        if next_t0 is not None and buf.t0 != next_t0:
            logger.warning(
                "%s: Unexpected buffer timestamp: %s instead of %s",
                ifo,
                buf.t0,
                next_t0,
            )

        # Update next expected timestamp
        self.next_t0[ifo] = buf.t0 + buf.duration

        # Extract data
        data = numpy.array(buf.data).flatten()

        # Store in deque with segment information
        self.datadeq[ifo].append(
            {
                "segment": segment(buf.t0, buf.t0 + buf.duration),
                "data": data,
            }
        )

        # Fetch messages from Kafka (if live)
        if self.is_live and self.consumer:
            self.fetch()

        # Handle queued events
        self.handle()

    def fetch(self):
        """Fetch messages from Kafka and ingest them.

        Polls Kafka for new events and adds them to the event queue.
        """
        if not self.consumer:
            return

        messages = self.consumer.consume(
            num_messages=self.num_messages, timeout=self.request_timeout
        )

        for message in messages:
            if message:
                if not message.error():
                    self.ingest(message)
                elif not message.error().code() == KafkaError._PARTITION_EOF:
                    logger.warning("Received message with error: %s", message.error())

    def ingest(self, message):
        """Parse and queue a Kafka message containing an event.

        Args:
            message: Kafka message with event data
        """
        content = json.loads(message.value())

        # Don't process events that are already SNR optimized
        if "snr_optimized" in content and content["snr_optimized"]:
            return

        # Extract event metadata
        time = content["time"]
        time_ns = content["time_ns"]
        far = content["far"]
        snr = content["snr"]

        # Parse coinc XML from message
        xmlobj = content["coinc"]
        if isinstance(xmlobj, str):
            xmlobj = BytesIO(xmlobj.encode("utf-8"))
        xmldoc = ligolw_utils.load_fileobj(xmlobj, contenthandler=LIGOLWContentHandler)

        # Extract event parameters
        snglrow = lsctables.SnglInspiralTable.get_table(xmldoc)[0]
        coincrow = lsctables.CoincInspiralTable.get_table(xmldoc)[0]
        coinceventrow = lsctables.CoincTable.get_table(xmldoc)[0]

        fap = coincrow.false_alarm_rate
        lr = coinceventrow.likelihood
        mc = self._mchirp(snglrow.mass1, snglrow.mass2)

        # Compute analysis segment
        tc = time + 10.0**-9 * time_ns
        int_tc = int(round(float(tc)))

        start = int_tc - int(max(self.durations)) - self.psd_fft_length
        end = (
            int_tc
            + 2 * self.search_window
            + snr_optimizer.SEARCHPAD
            + self.psd_fft_length
        )

        # Queue event for processing
        self.eventdeq.append(
            {
                "far": far,
                "fap": fap,
                "likelihood": lr,
                "snr": snr,
                "time": time,
                "time_ns": time_ns,
                "coinc": xmldoc,
                "mc": mc,
                cbc.M1: snglrow.mass1,
                cbc.M2: snglrow.mass2,
                cbc.S1Z: snglrow.spin1z,
                cbc.S2Z: snglrow.spin2z,
                "analysis_segment": segment(start, end),
                "trig-start": int_tc - self.search_window,
                "trig-end": int_tc + self.search_window,
                "is_injection": content["is_injection"],
                "template_id": snglrow.Gamma0,
            }
        )

        logger.info("Received event from Kafka: tc=%s, mc=%s", tc, mc)

    def handle(self):
        """Handle queued events.

        Processes the latest event if enough data is available.
        """
        if len(self.eventdeq) == 0:
            return

        event = self.eventdeq[-1]

        # Check if we have enough data for this event
        if event["analysis_segment"] in self.get_available_data_segment():
            event_data = {
                "analysis_segment": event["analysis_segment"],
                "data": self.get_data_array(event["analysis_segment"]),
            }

            # Process the event
            self.process_event(event, event_data)

            # Remove from queue
            self.eventdeq.pop()

    def get_available_data_segments(self) -> Dict[str, segment]:
        """Get available data segments for each detector.

        Returns:
            Dict mapping IFO to segment (in GPS seconds)
        """
        out = {}
        for instrument, deq in self.datadeq.items():
            if len(deq) > 0:
                # Segments are already stored in GPS seconds (from buf.t0)
                start_sec = int(deq[0]["segment"][0])
                end_sec = int(deq[-1]["segment"][1])
                out[instrument] = segment(start_sec, end_sec)
            else:
                out[instrument] = nullseg()
        return out

    def get_available_data_segment(self) -> segment:
        """Get intersection of available data across all detectors.

        Returns:
            Segment available across all detectors
        """
        segdict = self.get_available_data_segments()
        out = segmentlistdict({ifo: [x] for ifo, x in segdict.items()}).intersection(
            segdict.keys()
        )
        return nullseg() if len(out) == 0 else out[0]

    def get_data_array(self, seg: segment) -> Dict:
        """Extract data arrays for a specific segment.

        Args:
            seg: Time segment to extract (in GPS seconds)

        Returns:
            Dict with data arrays per detector
        """
        # Segments in datadeq are already in GPS seconds (from buf.t0)
        out = {}
        for instrument, deq in self.datadeq.items():
            bufs = [x for x in deq if x["segment"].intersects(seg)]
            if len(bufs) > 0:
                data = numpy.concatenate([x["data"] for x in bufs])
                if numpy.count_nonzero(data) > 0:
                    out[instrument] = {
                        "t0": bufs[0]["segment"][0],  # Already GPS seconds
                        "data": data,
                        "delta_t": 1.0 / self.rate,
                    }
        return out

    def process_event(self, event: Dict, event_data: Dict):
        """Process an event with SNR optimization.

        This is where the actual SNR optimization happens.

        Args:
            event: Event metadata dictionary
            event_data: Data arrays for the event
        """
        logger.info(
            "Processing event: tc=%s, mc=%s, segment=%s",
            event.get("time", event.get("tc")),
            event["mc"],
            event["analysis_segment"],
        )

        # Get nearby template rectangles from the bank
        assert (
            self.seed_bank is not None
        ), "seed_bank must be set before processing events"
        if self.original_template_only:
            rectangles = [self.seed_bank.rectangle_by_id(event["template_id"])]
        else:
            rectangles = self.seed_bank.adjacent(
                {
                    cbc.M1: event[cbc.M1],
                    cbc.M2: event[cbc.M2],
                    cbc.S1Z: event[cbc.S1Z],
                    cbc.S2Z: event[cbc.S2Z],
                },
                n=self.nearest,
                use_metric=False,
            )

        logger.info("Found %s nearby templates", len(rectangles))

        # Get the correct PSD for template whitening
        template_psd = self.template_psd if self.template_psd is not None else self.psd

        # Format data for SNR optimizer
        splusns_data = snr_optimizer.format_data(
            event["trig-start"],
            event["trig-end"],
            int(max(self.durations)),
            int(2 * self.search_window),
            snr_optimizer.SEARCHPAD,
            event_data,
            self.rate,
            event_data["data"].keys(),
        )

        # Run SNR optimization
        logger.info("Running SNR optimization...")
        L = snr_optimizer.Likelihood(
            splusns_data,
            rectangles,
            event,
            template_psd,
            window_start=event["trig-start"],
            flow=self.flow,
            min_mismatch=self.min_mismatch,
            durations=self.durations,
            search_window=2 * self.search_window,
            inspiral_extrinsics=self.inspiral_extrinsics,
            min_instruments=self.min_instruments,
            algorithm=self.algorithm,
            maximize_L=self.maximize_L,
            original_template_only=self.original_template_only,
            instrument_override=self.instrument_override,
        )

        logger.info("Optimization complete: SNR=%s", L.event.snr)

        # Handle output based on live vs offline mode
        if self.is_live:
            self._publish_live_event(event, L)
        else:
            self._write_offline_event(event, L)

    def _publish_live_event(self, event: Dict, likelihood_result):
        """Publish optimized event to Kafka and save to disk.

        Args:
            event: Original event metadata
            likelihood_result: snr_optimizer.Likelihood result
        """
        # Generate output XML
        xmldoc = likelihood_result.event.to_xml_file(
            self.channel_dict,
            likelihood=event.get("likelihood", 0),
            combined_far=event["far"],
            fap=event["fap"],
            psd=self.psd,
        )

        # Serialize XML for Kafka
        coinc_msg = BytesIO()
        ligolw_utils.write_fileobj(xmldoc, coinc_msg)

        # Prepare Kafka payload
        payload = {
            "far": event["far"],
            "snr": likelihood_result.event.snr,
            "time": event["time"],
            "time_ns": event["time_ns"],
            "coinc": coinc_msg.getvalue().decode(),
            "snr_optimized": True,  # Prevents re-triggering
            "apply_snr_optimized_label": not bool(self.instrument_override),
            "job_tag": self.job_tag,
        }

        # Determine output topic (injection vs production)
        topic_prefix = "" if not event.get("is_injection", False) else "inj_"
        output_topic = f"gstlal.{self.analysis_tag}.{topic_prefix}events"

        logger.info("Sending optimized event to Kafka: %s", output_topic)

        # Publish to Kafka
        if self.producer:
            self.producer.produce(
                topic=output_topic,
                value=json.dumps(payload).encode("utf-8"),
                on_delivery=self._delivery_report,
            )
            self.producer.poll(0)

        # Save to disk
        self._save_event_to_disk(event, xmldoc)

    def _save_event_to_disk(self, event: Dict, xmldoc):
        """Save event XML to disk.

        Args:
            event: Event metadata
            xmldoc: LIGOLW XML document
        """
        # Create output directory based on GPS time
        gracedb_uploads_dir = os.path.join("gracedb_uploads", str(event["time"])[:5])
        os.makedirs(gracedb_uploads_dir, exist_ok=True)

        # Generate filename
        instruments_str = "".join(sorted(self.instruments))
        description = f"MANIFOLD_{self.job_tag}"
        filename = f"{instruments_str}-{description}-{event['time']}-1.xml"

        # Write XML file
        filepath = os.path.join(gracedb_uploads_dir, filename)
        with open(filepath, "wb") as fileobj:
            ligolw_utils.write_fileobj(xmldoc, fileobj)

        logger.info("Saved event to: %s", filepath)

    def _write_offline_event(self, event: Dict, likelihood_result):
        """Write optimized event to disk (offline mode).

        Args:
            event: Event metadata
            likelihood_result: snr_optimizer.Likelihood result
        """
        logger.info("Writing offline event to: %s", self.output_name)

        # Preserve false alarm rates and likelihood from original event
        # The SNR optimizer cannot recompute these, so we copy them
        likelihood_result.event.to_xml_file(
            self.channel_dict,
            name=self.output_name,
            likelihood=event.get("likelihood", 0),
            combined_far=event.get("far", 0),
            fap=event.get("fap", 0),
            psd=self.psd,
        )

    def get_event_from_coinc_xml_doc(self, coinc_xmldoc):
        """Load event from coinc XML document (for offline processing).

        Args:
            coinc_xmldoc: LIGOLW XML document containing coinc event
        """
        # Extract event from XML tables
        coinc_inspiral_table = lsctables.CoincInspiralTable.get_table(coinc_xmldoc)
        sngl_inspiral_table = lsctables.SnglInspiralTable.get_table(coinc_xmldoc)

        # Assume single event
        coinc_inspiral = coinc_inspiral_table[0]
        sngl_inspiral = sngl_inspiral_table[0]

        # Extract parameters
        tc = coinc_inspiral.end
        mc = coinc_inspiral.mchirp
        m1, m2, s1z, s2z = (
            sngl_inspiral.mass1,
            sngl_inspiral.mass2,
            sngl_inspiral.spin1z,
            sngl_inspiral.spin2z,
        )

        # Extract false alarm rates and likelihood from original event
        # These cannot be recomputed by the SNR optimizer, so we preserve them
        far = getattr(coinc_inspiral, "false_alarm_rate", 0)
        combined_far = getattr(coinc_inspiral, "combined_far", far)

        # Try to get likelihood from coinc table if available
        likelihood = 0
        try:
            coinc_table = lsctables.CoincTable.get_table(coinc_xmldoc)
            if len(coinc_table) > 0:
                likelihood = getattr(coinc_table[0], "likelihood", 0)
        except ValueError:
            # CoincTable may not exist in all files
            pass

        # Compute analysis segment
        int_tc = int(round(float(tc)))
        start = int_tc - int(max(self.durations)) - self.psd_fft_length
        end = (
            int_tc
            + 2 * self.search_window
            + snr_optimizer.SEARCHPAD
            + self.psd_fft_length
        )

        template_id = sngl_inspiral.Gamma0

        # Queue event for processing
        event = {
            "tc": tc,
            "mc": mc,
            cbc.M1: m1,
            cbc.M2: m2,
            cbc.S1Z: s1z,
            cbc.S2Z: s2z,
            "analysis_segment": segment(start, end),
            "trig-start": int_tc - self.search_window,
            "trig-end": int_tc + self.search_window,
            "template_id": template_id,
            "coinc": coinc_xmldoc,
            "is_injection": False,  # Offline events are not injections by default
            "far": far,
            "fap": combined_far,  # FAP is combined FAR in this context
            "likelihood": likelihood,
        }

        self.eventdeq.append(event)
        logger.info("Loaded offline event: %s", event)

        return event

    def _finalize(self):
        """Finalize optimization and clean up.

        Called when pipeline reaches end of stream (EOS).
        """
        logger.info("SNROptimizerSink finalizing (EOS received)")

        # Process any remaining queued events
        if not self.is_live and len(self.eventdeq) > 0:
            logger.info(
                "Processing %s queued event(s) before finalize", len(self.eventdeq)
            )

            event = self.eventdeq[-1]
            available_seg = self.get_available_data_segment()

            logger.info("Event analysis segment: %s", event["analysis_segment"])
            logger.info("Available data segment: %s", available_seg)

            # Check if we have enough data for this event
            if event["analysis_segment"] in available_seg:
                event_data = {
                    "analysis_segment": event["analysis_segment"],
                    "data": self.get_data_array(event["analysis_segment"]),
                }

                # Process the event
                self.process_event(event, event_data)
                self.eventdeq.pop()
            else:
                logger.warning(
                    "Insufficient data to process event. Need %s, have %s",
                    event["analysis_segment"],
                    available_seg,
                )

        # Close Kafka connections
        if self.consumer:
            self.consumer.close()
        if self.producer:
            self.producer.flush()

        logger.info("SNROptimizerSink finalized")

    @staticmethod
    def _mchirp(m1: float, m2: float) -> float:
        """Calculate chirp mass.

        Args:
            m1: Primary mass (solar masses)
            m2: Secondary mass (solar masses)

        Returns:
            Chirp mass (solar masses)
        """
        return (m1 * m2) ** (3.0 / 5.0) / (m1 + m2) ** (1.0 / 5.0)

    @staticmethod
    def _delivery_report(error, msg):
        """Handle Kafka message delivery response.

        Args:
            error: Kafka error (if any)
            msg: Kafka message
        """
        if error is not None:
            logger.warning("Message delivery failed: %s", error)
