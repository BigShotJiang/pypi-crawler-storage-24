"""Various plotting utilities"""

from sgn_manifold import coordinate


def convexity(center: coordinate.Coordinates) -> None:
    pass
