# Current Task

No active task is being executed right now.

## Runtime Sources of Truth

- `task.json`
- `AGENT.md`
- `progress.txt`
