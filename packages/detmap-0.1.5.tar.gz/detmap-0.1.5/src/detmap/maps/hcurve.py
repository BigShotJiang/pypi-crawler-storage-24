"""
jax_hybrid_curve.py - Pure JAX hybrid curve embedding using direct indexing
No external dependencies, all JAX-native operations
"""

import jax
import jax.numpy as jnp
from jax import lax
from functools import partial
import numpy as np

# ============================================================
# SPACE-FILLING CURVE UTILITIES
# ============================================================

@partial(jax.jit, static_argnames=("bits",))
def morton_index_nd(coords, bits):
    """Morton (Z-order) curve index."""
    dims = coords.shape[0]
    coords = coords.astype(jnp.uint64)

    max_bits_per_dim = 63 // dims
    if bits > max_bits_per_dim:
        bits = max_bits_per_dim

    def spread_bits(x):
        x = x & ((1 << bits) - 1)
        x = (x | (x << 32)) & 0x00000000ffffffff
        x = (x | (x << 16)) & 0x0000ffff0000ffff
        x = (x | (x << 8)) & 0x00ff00ff00ff00ff
        x = (x | (x << 4)) & 0x0f0f0f0f0f0f0f0f
        x = (x | (x << 2)) & 0x3333333333333333
        x = (x | (x << 1)) & 0x5555555555555555
        return x

    result = jnp.uint64(0)
    for d in range(dims):
        result |= spread_bits(coords[d]) << d
    return result


@partial(jax.jit, static_argnames=("bits",))
def hilbert_index_nd(coords, bits):
    """Hilbert curve index."""
    dims = coords.shape[0]
    coords = coords.astype(jnp.uint64)

    max_bits_per_dim = 63 // dims
    if bits > max_bits_per_dim:
        bits = max_bits_per_dim

    x = coords

    def gray_step(i, x):
        bit = jnp.uint64(1) << (bits - 1 - i)

        def inner(j, x):
            cond = (x[j] & bit) != 0
            x = jnp.where(cond, x ^ (bit - 1), x)
            t = (x[0] ^ x[j]) & (bit - 1)
            x = x.at[0].set(x[0] ^ t)
            x = x.at[j].set(x[j] ^ t)
            return x

        return lax.fori_loop(1, dims, inner, x)

    x = lax.fori_loop(0, bits, gray_step, x)

    def build_index(i, state):
        x, h = state
        b = bits - 1 - i
        digit = jnp.uint64(0)
        for d in range(dims):
            digit |= ((x[d] >> b) & 1) << d
        h = (h << dims) | digit
        return (x, h)

    _, h = lax.fori_loop(0, bits, build_index, (x, jnp.uint64(0)))
    return h


@partial(jax.jit, static_argnames=("bits",))
def hybrid_index_adaptive(coords, bits, cluster_weights):
    """Adaptive hybrid index that mixes Morton and Hilbert based on per-point weights."""
    morton = morton_index_nd(coords, bits)
    hilbert = hilbert_index_nd(coords, bits)

    # Mix based on adaptive weights
    mixed = (morton * (1 - cluster_weights) + hilbert * cluster_weights).astype(jnp.uint64)
    return mixed


@partial(jax.jit, static_argnames=("bits",))
def hybrid_index_interleaved(coords, bits):
    """Bit-level interleaving of Morton and Hilbert indices."""
    morton = morton_index_nd(coords, bits)
    hilbert = hilbert_index_nd(coords, bits)

    # Take high bits from Hilbert, low bits from Morton
    hilbert_high = (hilbert >> 32) & 0xFFFFFFFF
    morton_low = morton & 0xFFFFFFFF
    return (hilbert_high << 32) | morton_low


@partial(jax.jit, static_argnames=("bits",))
def hybrid_index_alternate(coords, bits):
    """Alternate bits: even from Morton, odd from Hilbert."""
    morton = morton_index_nd(coords, bits)
    hilbert = hilbert_index_nd(coords, bits)

    return ((morton & 0xAAAAAAAAAAAAAAAA) |
            (hilbert & 0x5555555555555555))


@partial(jax.jit, static_argnames=("bits",))
def hybrid_index_weighted(coords, bits, morton_weight=0.3):
    """Global weighted combination."""
    morton = morton_index_nd(coords, bits)
    hilbert = hilbert_index_nd(coords, bits)

    hilbert_weight = 1.0 - morton_weight
    return (morton * morton_weight + hilbert * hilbert_weight).astype(jnp.uint64)


# ============================================================
# JAX-ONLY K-MEANS (no external dependencies)
# ============================================================

@partial(jax.jit, static_argnames=("n_clusters", "max_iters"))
def jax_kmeans_fast(X, n_clusters, max_iters=50, key=jax.random.PRNGKey(0)):
    """Fast k-means for adaptive weighting - pure JAX."""
    N, D = X.shape

    # Simple random initialization
    key, subkey = jax.random.split(key)
    indices = jax.random.choice(subkey, N, shape=(n_clusters,), replace=False)
    centroids = X[indices]

    def kmeans_step(centroids):
        # Compute distances to centroids
        # Using broadcasting: (N, D) - (K, D) -> (N, K, D)
        distances = jnp.sum((X[:, None, :] - centroids[None, :, :]) ** 2, axis=2)
        labels = jnp.argmin(distances, axis=1)

        # Update centroids
        new_centroids = jnp.zeros_like(centroids)
        counts = jnp.zeros(n_clusters, dtype=jnp.int32)

        def update_cluster(i, state):
            new_c, cnt = state
            mask = labels == i
            if jnp.any(mask):
                new_c = new_c.at[i].set(jnp.mean(X[mask], axis=0))
                cnt = cnt.at[i].set(jnp.sum(mask))
            return (new_c, cnt)

        new_centroids, counts = lax.fori_loop(0, n_clusters, update_cluster, (new_centroids, counts))
        return new_centroids, labels, counts

    # Run iterations
    def body_fn(carry, _):
        centroids, = carry
        new_centroids, _, _ = kmeans_step(centroids)
        return (new_centroids,), None

    (centroids,), _ = lax.scan(body_fn, (centroids,), None, length=max_iters)

    # Final assignment
    distances = jnp.sum((X[:, None, :] - centroids[None, :, :]) ** 2, axis=2)
    labels = jnp.argmin(distances, axis=1)

    return labels, centroids


# ============================================================
# SMOOTHING AND UTILITIES
# ============================================================

def smooth_along_curve(X_sorted, window):
    """Fast convolution smoothing along the curve using JAX."""
    # Create a simple box filter kernel
    kernel = jnp.ones((window,), dtype=X_sorted.dtype) / window

    def smooth_dim(x):
        # Manual convolution for JAX compatibility
        # Pad the array
        pad_size = window // 2
        x_padded = jnp.pad(x, (pad_size, pad_size), mode='edge')

        # Create sliding window view
        def apply_window(i):
            start = i
            end = i + window
            return jnp.mean(x_padded[start:end])

        # Apply to each position
        return jax.vmap(apply_window)(jnp.arange(len(x)))

    return jax.vmap(smooth_dim, in_axes=1, out_axes=1)(X_sorted)


def random_rotation(key, X):
    """Random orthogonal rotation."""
    D = X.shape[1]
    M = jax.random.normal(key, (D, D), dtype=X.dtype)
    Q, _ = jnp.linalg.qr(M)
    return X @ Q


def randomized_svd_fast(X, rank, key):
    """Fast randomized SVD."""
    N, D = X.shape
    oversample = 8
    n_iter = 2

    # Center the data
    X_centered = X - jnp.mean(X, axis=0)

    l = rank + oversample
    Omega = jax.random.normal(key, (D, l), dtype=X.dtype)

    # Stage A: Find approximate range
    Y = X_centered @ Omega

    # Power iterations
    for _ in range(n_iter):
        Y = X_centered @ (X_centered.T @ Y)

    Q, _ = jnp.linalg.qr(Y)

    # Stage B: Compute SVD on smaller matrix
    B = Q.T @ X_centered
    _, S, Vt = jnp.linalg.svd(B, full_matrices=False)

    # Project data
    X_reduced = X_centered @ Vt.T[:, :rank]

    return X_reduced


# ============================================================
# DIRECT CURVE-BASED EMBEDDING (No distance computations!)
# ============================================================

def direct_curve_embedding(
    X,
    bits=6,
    window=32,
    ensemble_size=4,
    mixing_strategy="adaptive",  # "adaptive", "interleaved", "alternate", "weighted", "morton", "hilbert"
    morton_weight=0.3,           # For "weighted" strategy
    key=jax.random.PRNGKey(0)
):
    """
    Direct embedding using only space-filling curve indices.
    No pairwise distance computations needed!

    Args:
        X: Input data (N, D) - already in target dimensions
        bits: Bits per dimension for space-filling curve
        window: Smoothing window along the curve
        ensemble_size: Number of random rotations
        mixing_strategy: How to combine Morton and Hilbert
        morton_weight: Weight for Morton in "weighted" strategy
        key: Random key

    Returns:
        embedded: Embedded coordinates (N, D) - smoothed along curve
    """
    N, D = X.shape

    # Normalize to grid coordinates
    mins = jnp.min(X, axis=0)
    maxs = jnp.max(X, axis=0)
    scale = (2**bits - 1) / (maxs - mins + 1e-9)
    grid = jnp.floor((X - mins) * scale).astype(jnp.uint64)

    # For adaptive strategy, we need cluster labels
    if mixing_strategy == "adaptive":
        n_clusters = jnp.minimum(20, jnp.maximum(5, N // 200))
        labels, centroids = jax_kmeans_fast(X, n_clusters, key=key)

    embeddings = []
    subkey = key

    for i in range(ensemble_size):
        subkey, rot_key, perm_key = jax.random.split(subkey, 3)

        # Random rotation
        X_rot = random_rotation(rot_key, X)

        # Random permutation of dimensions
        perm = jax.random.permutation(perm_key, D)
        X_perm = X_rot[:, perm]

        # Recompute grid for rotated data
        mins_rot = jnp.min(X_perm, axis=0)
        maxs_rot = jnp.max(X_perm, axis=0)
        scale_rot = (2**bits - 1) / (maxs_rot - mins_rot + 1e-9)
        grid_rot = jnp.floor((X_perm - mins_rot) * scale_rot).astype(jnp.uint64)

        # Compute hybrid indices based on strategy
        if mixing_strategy == "adaptive":
            # Compute adaptive weights based on cluster distance
            # Distance to nearest centroid
            cluster_center_dist = jnp.min(jnp.sum((X_rot[:, None, :] - centroids[None, :, :]) ** 2, axis=2), axis=1)
            cluster_weights = jnp.exp(-cluster_center_dist / (jnp.median(cluster_center_dist) + 1e-8))
            cluster_weights = jnp.clip(cluster_weights, 0.3, 0.8)

            indices = jax.vmap(lambda p, w: hybrid_index_adaptive(p, bits, w))(
                grid_rot, cluster_weights
            )

        elif mixing_strategy == "interleaved":
            indices = jax.vmap(lambda p: hybrid_index_interleaved(p, bits))(grid_rot)

        elif mixing_strategy == "alternate":
            indices = jax.vmap(lambda p: hybrid_index_alternate(p, bits))(grid_rot)

        elif mixing_strategy == "weighted":
            indices = jax.vmap(lambda p: hybrid_index_weighted(p, bits, morton_weight))(grid_rot)

        elif mixing_strategy == "morton":
            indices = jax.vmap(lambda p: morton_index_nd(p, bits))(grid_rot)

        elif mixing_strategy == "hilbert":
            indices = jax.vmap(lambda p: hilbert_index_nd(p, bits))(grid_rot)

        else:
            # Default: equal weighting
            morton = jax.vmap(lambda p: morton_index_nd(p, bits))(grid_rot)
            hilbert = jax.vmap(lambda p: hilbert_index_nd(p, bits))(grid_rot)
            indices = ((morton + hilbert) // 2).astype(jnp.uint64)

        # Sort by the hybrid index
        order = jnp.argsort(indices)

        # Smooth along the curve
        X_sorted = X_perm[order]
        X_smooth = smooth_along_curve(X_sorted, window)

        # Restore original order
        inv_order = jnp.zeros(N, dtype=jnp.int32).at[order].set(jnp.arange(N))
        X_restored = X_smooth[inv_order]

        embeddings.append(X_restored)

    # Average ensemble
    embedded = jnp.mean(jnp.stack(embeddings), axis=0)

    return embedded


# ============================================================
# COMPLETE PIPELINE WITH DIMENSIONALITY REDUCTION
# ============================================================

def cluster_separated_embedding(
    X,
    reduced_dims=32,
    bits=6,
    window=32,
    ensemble_size=4,
    cluster_exaggeration=2.0,
    mixing_strategy="adaptive",
    global_morton_weight=0.3,
    key=jax.random.PRNGKey(0)
):
    """
    Complete embedding with cluster exaggeration and hybrid curve mixing.
    """
    N, D = X.shape

    # Convert to JAX array
    X_jax = jnp.array(X, dtype=jnp.float32)

    # Step 1: Cluster exaggeration (uses k-means, O(N * k * D) - efficient)
    n_clusters = jnp.minimum(50, jnp.maximum(5, N // 200))
    labels, centroids = jax_kmeans_fast(X_jax, n_clusters, key=key)

    # Exaggerate distances from cluster centers
    def exaggerate_point(i):
        point = X_jax[i]
        center = centroids[labels[i]]
        displacement = point - center
        return center + displacement * cluster_exaggeration

    X_exaggerated = jax.vmap(exaggerate_point)(jnp.arange(N))

    # Step 2: Dimensionality reduction (O(N * D * rank) - efficient)
    X_low = randomized_svd_fast(X_exaggerated, reduced_dims, key)

    # Step 3: Direct curve embedding (O(N * ensemble_size * log N) - efficient)
    X_embedded = direct_curve_embedding(
        X_low,
        bits=bits,
        window=window,
        ensemble_size=ensemble_size,
        mixing_strategy=mixing_strategy,
        morton_weight=global_morton_weight,
        key=key
    )

    return X_embedded, labels


# ============================================================
# SIMPLE CLASS INTERFACE
# ============================================================

class HybridCurveMap:
    """
    Fast hybrid curve embedding using only curve indices.
    """

    def __init__(self, n_components=2, reduced_dims=32, bits=6, window=32,
                 ensemble_size=4, cluster_exaggeration=2.0,
                 mixing_strategy="adaptive", random_state=42):
        self.n_components = n_components
        self.reduced_dims = reduced_dims
        self.bits = bits
        self.window = window
        self.ensemble_size = ensemble_size
        self.cluster_exaggeration = cluster_exaggeration
        self.mixing_strategy = mixing_strategy
        self.random_state = random_state
        self.embedded_ = None
        self.labels_ = None

    def fit(self, X, y=None):
        """Just store the training data for reference."""
        self.X_fit_ = self._check_array(X)
        return self

    def transform(self, X):
        """Fit and transform the data."""
        key = jax.random.PRNGKey(self.random_state)

        self.embedded_, self.labels_ = cluster_separated_embedding(
            X,
            reduced_dims=self.reduced_dims,
            bits=self.bits,
            window=self.window,
            ensemble_size=self.ensemble_size,
            cluster_exaggeration=self.cluster_exaggeration,
            mixing_strategy=self.mixing_strategy,
            key=key
        )
        return np.asarray(self.embedded_[:, :self.n_components])

    def get_embedding(self):
        return self.embedded_

    def get_labels(self):
        return self.labels_


# ============================================================
# EXAMPLE
# ============================================================

if __name__ == "__main__":
    import matplotlib.pyplot as plt

    # Generate synthetic data
    np.random.seed(42)
    n_points = 5000
    n_clusters = 5

    X_list = []
    for i in range(n_clusters):
        center = np.random.randn(20) * 5
        cluster = center + np.random.randn(n_points // n_clusters, 20) * 0.5
        X_list.append(cluster)

    X = np.vstack(X_list)
    print(f"Data shape: {X.shape}")

    # Test different mixing strategies
    strategies = ["adaptive", "interleaved", "alternate", "weighted", "morton", "hilbert"]

    fig, axes = plt.subplots(2, 3, figsize=(15, 10))
    axes = axes.flatten()

    for idx, strategy in enumerate(strategies):
        print(f"\nTesting: {strategy}")

        embedder = HybridCurveMap(
            n_components=2,
            reduced_dims=16,
            bits=5,
            window=16,
            ensemble_size=3,
            mixing_strategy=strategy,
            random_state=42
        )

        X_embedded = embedder.fit_transform(X)
        labels = embedder.get_labels()

        ax = axes[idx]
        scatter = ax.scatter(X_embedded[:, 0], X_embedded[:, 1],
                            c=labels, cmap='tab10', alpha=0.7, s=5)
        ax.set_title(f"Strategy: {strategy}")
        ax.set_xticks([])
        ax.set_yticks([])
        plt.colorbar(scatter, ax=ax)

    plt.tight_layout()
    plt.show()

    print(f"\nFinal embedding shape: {X_embedded.shape}")
    print(f"Number of clusters: {len(np.unique(labels))}")
