---
name: xqcwechat-skill
description: 微信公众号开发工具包Skill，支持素材管理、草稿管理、发布管理和留言管理。当需要操作微信公众号、进行内容创作和发布时使用此Skill。
---

# xqcwechat-skill

微信公众号开发工具包，提供素材管理、草稿管理、发布管理和留言管理等功能。

## 快速开始

### 安装

```bash
pip install -U xqcwechat
```

### 最简配置（只需要 Token Secret）

1. 复制 `.env.example` 为 `.env`
2. 配置 `WECHAT_TOKEN_SECRET`：

```env
WECHAT_TOKEN_SECRET=your_secret_key
```

3. 使用智能加载：

```python
from xqcwechat import Auth

auth = Auth.from_env()  # 自动检测配置
```

### 快速脚本

项目提供了几个快速测试脚本，方便快速上手：

| 脚本 | 用途 |
|------|------|
| `quick_test_config.py` | 测试环境配置是否正确 |
| `quick_create_draft.py` | 快速创建草稿（需要本地图片） |
| `quick_list_drafts.py` | 快速查看草稿列表 |
| `quick_publish.py` | 快速发布草稿 |

使用方法：

```bash
# 测试配置
python -m xqcwechat.scripts.quick_test_config

# 创建草稿
python -m xqcwechat.scripts.quick_create_draft "标题" "内容" cover.jpg

# 查看草稿列表
python -m xqcwechat.scripts.quick_list_drafts

# 发布草稿
python -m xqcwechat.scripts.quick_publish <media_id>
```

### 基础使用

```python
from xqcwechat import Auth, Asset, Draft, Publish

auth = Auth(
    app_id=os.getenv("WECHAT_ACCOUNT_1_APP_ID"),
    app_secret=os.getenv("WECHAT_ACCOUNT_1_APP_SECRET")
)

# 草稿管理
draft = Draft(auth)
drafts = draft.get_draft_list()

# 发布管理
publish = Publish(auth)

# 素材管理
asset = Asset(auth)

# 留言管理
comment = Comment(auth)
```

## 核心工作流

### 上传图片→创建草稿→发布

```python
from xqcwechat import Auth, Asset, Draft, Publish

auth = Auth(app_id="xxx", app_secret="xxx")

# 1. 上传封面图 (获取 thumb_media_id)
asset = Asset(auth)
cover = asset.add_material("image", "cover.jpg")
thumb_media_id = cover["media_id"]

# 2. 上传正文图片 (获取 URL)
image_url = asset.upload_image("content.jpg")

# 3. 创建草稿
draft = Draft(auth)
result = draft.create_draft([{
    "title": "文章标题",
    "content": f"正文<img src='{image_url}'>",
    "thumb_media_id": thumb_media_id,
    "show_cover_pic": 1
}])

# 4. 发布
publish = Publish(auth)
publish.publish_draft(result["media_id"])
```

**关键方法说明：**

| 步骤       | 方法                                | 用途                | 返回值                   |
| ---------- | ----------------------------------- | ------------------- | ------------------------ |
| 上传封面   | `asset.add_material("image", path)` | 获取 thumb_media_id | `{"media_id": "xxx"}`    |
| 上传正文图 | `asset.upload_image(path)`          | 获取图片URL         | `{"url": "https://..."}` |
| 创建草稿   | `draft.create_draft(articles)`      | 创建图文草稿        | `{"media_id": "xxx"}`    |
| 发布草稿   | `publish.publish_draft(media_id)`   | 发布到公众号        | `{"publish_id": "xxx"}`  |

## 配置说明

详细配置说明请参阅 [references/config.md](references/config.md)：

- 环境变量配置
- Token获取方式（官方API/默认回调/自定义回调）
- 多账号配置

## 功能模块

### 草稿管理 (Draft)

```python
draft = Draft(auth)
drafts = draft.get_draft_list()        # 获取草稿列表
draft_info = draft.get_draft("xxx")    # 获取单个草稿
count = draft.get_draft_count()         # 获取草稿总数
result = draft.create_draft(articles)  # 创建草稿
result = draft.update_draft(id, articles)  # 更新草稿
result = draft.delete_draft("xxx")     # 删除草稿
```

详细API请参阅 [references/api_reference.md](references/api_reference.md)

### 发布管理 (Publish)

```python
publish = Publish(auth)
articles = publish.get_published_articles()  # 已发布列表
status = publish.get_publish_status(id)       # 查询发布状态
article = publish.get_article(id)             # 获取已发布图文
result = publish.publish_draft(media_id)       # 发布草稿
result = publish.delete_article(id)            # 删除已发布文章
```

### 素材管理 (Asset)

```python
asset = Asset(auth)
result = asset.upload_image(path)              # 上传临时图片(返回URL)
result = asset.add_material(type, path)        # 上传永久素材(返回media_id)
result = asset.get_materials(type, offset, count)  # 获取素材列表
count = asset.get_material_count()             # 获取素材总数
material = asset.get_material(media_id)       # 获取素材详情
result = asset.delete_material(media_id)       # 删除素材
```

### 留言管理 (Comment)

```python
comment = Comment(auth)
comment.open_comment(msg_data_id, index)      # 打开评论
comment.close_comment(msg_data_id, index)     # 关闭评论
comments = comment.list_comment(msg_data_id, index)  # 获取评论列表
comment.elect_comment(msg_data_id, index, user_comment_id)     # 精选评论
comment.unelect_comment(msg_data_id, index, user_comment_id)   # 取消精选
comment.reply_comment(msg_data_id, index, user_comment_id, content)  # 回复
comment.delete_comment(msg_data_id, index, user_comment_id)  # 删除评论
```

## 多账号管理

```python
from xqcwechat import AccountManager

manager = AccountManager()  # 自动加载 .env 配置

# 获取各模块
draft = manager.get_draft()
publish = manager.get_publish()
asset = manager.get_asset()
comment = manager.get_comment()

# 指定账号
draft2 = manager.get_draft("账号2")
```

详细使用示例请参阅 [references/examples.md](references/examples.md)

## 参考资料

- [references/api_reference.md](references/api_reference.md) - 完整API参考
- [references/config.md](references/config.md) - 配置详细说明
- [references/examples.md](references/examples.md) - 完整使用示例
