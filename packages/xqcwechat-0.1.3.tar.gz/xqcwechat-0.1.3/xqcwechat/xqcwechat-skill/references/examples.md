# 微信公众号功能模块示例

本文档提供各模块的详细使用示例。

## 最简使用示例

只需要配置 `WECHAT_TOKEN_SECRET` 即可开始使用：

```python
from dotenv import load_dotenv
from xqcwechat import Auth, Draft, Publish

load_dotenv()

auth = Auth()  # 自动检测 WECHAT_TOKEN_SECRET 并使用默认回调

draft = Draft(auth)
publish = Publish(auth)

# 创建草稿
result = draft.create_draft([...])

# 发布草稿
publish.publish_draft(result["media_id"])
```

## 草稿管理 (Draft)

### 基础操作

```python
from xqcwechat import Auth, Draft

auth = Auth(app_id="xxx", app_secret="xxx")
draft = Draft(auth)

# 获取草稿列表
drafts = draft.get_draft_list(offset=0, count=20)

# 获取单个草稿
draft_info = draft.get_draft("media_id_xxx")

# 获取草稿总数
count = draft.get_draft_count()
```

### 创建草稿

```python
from xqcwechat import Auth, Asset, Draft

auth = Auth(app_id="xxx", app_secret="xxx")

# 1. 先上传封面图，获取 thumb_media_id
asset = Asset(auth)
cover_result = asset.add_material("image", "cover.jpg")
thumb_media_id = cover_result["media_id"]

# 2. (可选) 上传正文内的图片，获取 URL
image_url = asset.upload_image("content.jpg")

# 3. 创建草稿
draft = Draft(auth)
result = draft.create_draft([{
    "title": "文章标题",
    "author": "作者名",
    "content": "正文内容，可以插入图片<img src='" + image_url + "'>",
    "digest": "文章摘要",
    "content_source_url": "https://example.com/original",
    "thumb_media_id": thumb_media_id,
    "show_cover_pic": 1
}])

print(result)  # {"media_id": "xxx"}
```

### 更新草稿

```python
result = draft.update_draft("media_id_xxx", [{
    "title": "新标题",
    "content": "新内容"
}])
```

### 删除草稿

```python
result = draft.delete_draft("media_id_xxx")
```

## 发布管理 (Publish)

### 基础操作

```python
from xqcwechat import Auth, Publish

auth = Auth(app_id="xxx", app_secret="xxx")
publish = Publish(auth)

# 获取已发布列表
articles = publish.get_published_articles(offset=0, count=20)

# 查询发布状态
status = publish.get_publish_status("publish_id_xxx")

# 获取已发布图文
article = publish.get_article("article_id_xxx")
```

### 发布草稿

```python
from xqcwechat import Auth, Draft, Publish

auth = Auth(app_id="xxx", app_secret="xxx")

# 假设已有草稿 media_id
draft = Draft(auth)
draft_result = draft.create_draft([{...}])
media_id = draft_result["media_id"]

# 发布草稿
publish = Publish(auth)
result = publish.publish_draft(media_id)
print(result)  # {"publish_id": "xxx"}
```

### 删除已发布文章

```python
result = publish.delete_article("article_id_xxx")
```

## 素材管理 (Asset)

### 上传临时素材

```python
from xqcwechat import Auth, Asset

auth = Auth(app_id="xxx", app_secret="xxx")
asset = Asset(auth)

# 上传图片，返回 URL（用于正文）
result = asset.upload_image("image.jpg")
print(result)  # {"url": "https://mmbiz.qpic.cn/..."}
```

### 上传永久素材

```python
from xqcwechat import Auth, Asset

auth = Auth(app_id="xxx", app_secret="xxx")
asset = Asset(auth)

# 上传图片永久素材，返回 media_id（用于封面）
result = asset.add_material("image", "cover.jpg")
print(result)  # {"media_id": "xxx", "url": "https://..."}

# 上传图文消息
articles = [{
    "title": "标题",
    "thumb_media_id": "xxx",
    "author": "作者",
    "content": "正文内容",
    "digest": "摘要",
    "content_source_url": "https://example.com"
}]
result = asset.add_material("news", articles)
print(result)  # {"media_id": "xxx"}
```

### 获取素材

```python
# 获取素材列表
result = asset.get_materials("image", offset=0, count=20)

# 获取素材总数
count = asset.get_material_count()

# 获取素材内容
material = asset.get_material("media_id_xxx")
```

### 删除素材

```python
result = asset.delete_material("media_id_xxx")
```

## 留言管理 (Comment)

### 基础操作

```python
from xqcwechat import Auth, Comment

auth = Auth(app_id="xxx", app_secret="xxx")
comment = Comment(auth)

# 打开评论
result = comment.open_comment(msg_data_id="msg_id", index=0)

# 关闭评论
result = comment.close_comment(msg_data_id="msg_id", index=0)

# 获取评论列表
comments = comment.list_comment(msg_data_id="msg_id", index=0)

# 精选评论
comment.elect_comment(msg_data_id="msg_id", index=0, user_comment_id=1)

# 取消精选
comment.unelect_comment(msg_data_id="msg_id", index=0, user_comment_id=1)

# 回复评论
comment.reply_comment(msg_data_id="msg_id", index=0, user_comment_id=1, content="回复内容")

# 删除评论
comment.delete_comment(msg_data_id="msg_id", index=0, user_comment_id=1)
```

## 完整工作流示例

### 发布文章完整流程

```python
import os
from dotenv import load_dotenv
load_dotenv()

from xqcwechat import Auth, Asset, Draft, Publish

# 1. 初始化
auth = Auth(
    app_id=os.getenv("WECHAT_ACCOUNT_1_APP_ID"),
    app_secret=os.getenv("WECHAT_ACCOUNT_1_APP_SECRET")
)

# 2. 上传封面图
asset = Asset(auth)
cover_result = asset.add_material("image", "cover.jpg")
thumb_media_id = cover_result["media_id"]

# 3. 上传正文图片
image_url = asset.upload_image("content_image.jpg")

# 4. 创建草稿
draft = Draft(auth)
draft_result = draft.create_draft([{
    "title": "文章标题",
    "author": "作者名",
    "content": f"正文内容<img src='{image_url}'>",
    "digest": "文章摘要",
    "thumb_media_id": thumb_media_id,
    "show_cover_pic": 1
}])

# 5. 发布草稿
publish = Publish(auth)
publish_result = publish.publish_draft(draft_result["media_id"])
print(f"发布成功: {publish_result}")
```
