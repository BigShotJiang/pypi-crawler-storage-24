#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
快速发布草稿脚本

使用方法：
    python -m xqcwechat.scripts.quick_publish <media_id> [标题]

参数：
    1. media_id（必填）- 草稿的 media_id
    2. 标题（可选）- 用来指定本次发布的标题
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from dotenv import load_dotenv

script_dir = os.path.dirname(os.path.abspath(__file__))
skill_dir = os.path.dirname(script_dir)
env_path = os.path.join(skill_dir, ".env")
if os.path.exists(env_path):
    load_dotenv(env_path, override=True)


def main():
    if len(sys.argv) < 2:
        print("用法：python -m xqcwechat.scripts.quick_publish <media_id> [标题]")
        print("示例：python -m xqcwechat.scripts.quick_publish abc123xyz")
        print("       python -m xqcwechat.scripts.quick_publish abc123xyz \"自定义标题\"")
        sys.exit(1)

    media_id = sys.argv[1]
    title = sys.argv[2] if len(sys.argv) > 2 else None

    print("=" * 50)
    print("快速发布草稿")
    print("=" * 50)

    from xqcwechat import Auth, Publish

    try:
        print("\n1. 初始化 Auth...")
        auth = Auth()
        print("   ✅ Auth 初始化成功")

        print("\n2. 发布草稿...")
        publish = Publish(auth)
        result = publish.publish_draft(media_id, title)

        if "publish_id" in result:
            print(f"   ✅ 草稿发布成功！")
            print(f"   📢 publish_id: {result['publish_id']}")
            print(f"\n💡 提示：查询发布状态：")
            print(f"   python -m xqcwechat.scripts.quick_publish_status {result['publish_id']}")
        else:
            print(f"   ❌ 发布失败：{result}")
            sys.exit(1)

    except Exception as e:
        print(f"\n❌ 错误：{str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
