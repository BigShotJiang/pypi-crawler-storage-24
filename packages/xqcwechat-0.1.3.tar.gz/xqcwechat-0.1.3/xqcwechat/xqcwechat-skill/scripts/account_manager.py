"""
多账号管理器示例

用于管理多个微信公众号账号的认证和功能模块

Token获取优先级 (从高到低):
1. 自定义回调函数: WECHAT_ACCOUNT_X_TOKEN_GETTER_MODULE
2. 默认回调函数: WECHAT_TOKEN_SECRET
3. 微信官方API: WECHAT_ACCOUNT_X_APP_ID + APP_SECRET

使用方式:
1. 在 .env 中配置账号
2. 根据需要配置Token获取方式
3. 使用 AccountManager 获取对应账号的实例
"""

import os
import importlib
from typing import Dict, Optional, Callable

from xqcwechat import Auth, Asset, Draft, Publish, Comment


class AccountManager:
    """微信公众号多账号管理器"""

    def __init__(self, config_path: Optional[str] = None):
        """
        初始化账号管理器

        :param config_path: 配置文件路径，默认为 .env
        """
        from dotenv import load_dotenv

        load_dotenv(config_path)

        self.accounts: Dict[str, Dict] = {}
        self._auth_cache: Dict[str, Auth] = {}
        self._load_accounts()

    def _load_accounts(self):
        """从环境变量加载账号配置"""
        i = 1
        while True:
            app_id = os.environ.get(f"WECHAT_ACCOUNT_{i}_APP_ID")
            app_secret = os.environ.get(f"WECHAT_ACCOUNT_{i}_APP_SECRET")
            name = os.environ.get(f"WECHAT_ACCOUNT_{i}_NAME", f"账号{i}")

            if not app_id:
                break

            token_module = os.environ.get(f"WECHAT_ACCOUNT_{i}_TOKEN_GETTER_MODULE")
            token_func = os.environ.get(
                f"WECHAT_ACCOUNT_{i}_TOKEN_GETTER_FUNC", "get_token"
            )

            self.accounts[name] = {
                "app_id": app_id,
                "app_secret": app_secret,
                "name": name,
                "index": i,
                "token_module": token_module,
                "token_func": token_func,
            }
            i += 1

        print(f"✅ 已加载 {len(self.accounts)} 个账号: {list(self.accounts.keys())}")

    def _get_token_getter(self, account: Dict) -> Optional[Callable]:
        """
        获取Token获取回调函数

        优先级:
        1. 自定义回调函数 (WECHAT_ACCOUNT_X_TOKEN_GETTER_MODULE)
        2. 默认回调函数 (WECHAT_TOKEN_SECRET)
        3. None (使用微信官方API)
        """
        token_module = account.get("token_module")
        token_func = account.get("token_func", "get_token")
        account_index = account.get("index", 1)

        if token_module:
            try:
                module = importlib.import_module(token_module)
                func = getattr(module, token_func)
                if account_index and callable(func):
                    from functools import partial

                    return partial(func, account_index=account_index)
                return func
            except Exception as e:
                print(f"❌ 加载自定义Token获取器失败: {e}")

        token_secret = os.environ.get("WECHAT_TOKEN_SECRET")
        if token_secret:
            try:
                module = importlib.import_module("token_getter")
                func = getattr(module, token_func)
                if account_index and callable(func):
                    from functools import partial

                    return partial(func, account_index=account_index)
                return func
            except Exception as e:
                print(f"❌ 加载默认Token获取器失败: {e}")

        return None

    def get_auth(self, account_name: Optional[str] = None) -> Auth:
        """
        获取指定账号的Auth实例

        :param account_name: 账号名称，默认使用第一个账号
        :return: Auth 认证实例
        """
        if not account_name:
            name, account = next(iter(self.accounts.items()))
        else:
            name = account_name
            account = self.accounts.get(account_name)
            if not account:
                raise ValueError(f"❌ 未找到账号: {account_name}")

        if name in self._auth_cache:
            return self._auth_cache[name]

        token_getter = self._get_token_getter(account)

        auth = Auth(
            app_id=account["app_id"],
            app_secret=account["app_secret"],
            access_token_getter=token_getter,
        )

        self._auth_cache[name] = auth
        return auth

    def get_asset(self, account_name: Optional[str] = None) -> Asset:
        """获取素材管理实例"""
        return Asset(self.get_auth(account_name))

    def get_draft(self, account_name: Optional[str] = None) -> Draft:
        """获取草稿管理实例"""
        return Draft(self.get_auth(account_name))

    def get_publish(self, account_name: Optional[str] = None) -> Publish:
        """获取发布管理实例"""
        return Publish(self.get_auth(account_name))

    def get_comment(self, account_name: Optional[str] = None) -> Comment:
        """获取留言管理实例"""
        return Comment(self.get_auth(account_name))

    def list_accounts(self) -> list:
        """列出所有账号"""
        return list(self.accounts.keys())

    def reload(self):
        """重新加载账号配置"""
        self._auth_cache.clear()
        self.accounts.clear()
        self._load_accounts()


_default_manager: Optional[AccountManager] = None


def get_manager(config_path: Optional[str] = None) -> AccountManager:
    """获取默认账号管理器 (单例)"""
    global _default_manager
    if _default_manager is None:
        _default_manager = AccountManager(config_path)
    return _default_manager


def reset_manager():
    """重置默认账号管理器"""
    global _default_manager
    _default_manager = None
