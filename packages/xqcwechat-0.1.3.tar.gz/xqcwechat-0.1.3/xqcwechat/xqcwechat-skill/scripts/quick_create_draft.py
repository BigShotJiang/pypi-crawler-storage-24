#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
快速创建草稿脚本（带封面图片）

使用方法：
    python -m xqcwechat.scripts.quick_create_draft "文章标题" "文章内容" cover.jpg

参数：
    1. 文章标题（必填）
    2. 文章内容（必填）
    3. 封面图片路径（必填，需要本地存在）
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from dotenv import load_dotenv

script_dir = os.path.dirname(os.path.abspath(__file__))
skill_dir = os.path.dirname(script_dir)
env_path = os.path.join(skill_dir, ".env")
if os.path.exists(env_path):
    load_dotenv(env_path, override=True)


def main():
    if len(sys.argv) < 3:
        print("用法：python -m xqcwechat.scripts.quick_create_draft <标题> <内容> [封面图片路径]")
        print("示例：python -m xqcwechat.scripts.quick_create_draft \"我的文章\" \"这是文章内容\" cover.jpg")
        sys.exit(1)

    title = sys.argv[1]
    content = sys.argv[2]
    cover_path = sys.argv[3] if len(sys.argv) > 3 else None

    print("=" * 50)
    print("快速创建草稿")
    print("=" * 50)

    from xqcwechat import Auth, Draft, Asset

    try:
        print("\n1. 初始化 Auth...")
        auth = Auth()
        print("   ✅ Auth 初始化成功")

        print("\n2. 获取封面图片 media_id...")
        asset = Asset(auth)
        if cover_path and os.path.exists(cover_path):
            cover_result = asset.add_material("image", cover_path)
            thumb_media_id = cover_result.get("media_id")
            print(f"   ✅封面上传成功，media_id: {thumb_media_id}")
        else:
            print("   ❌ 封面图片不存在或未提供，请确保图片路径正确")
            sys.exit(1)

        print("\n3. 创建草稿...")
        draft = Draft(auth)
        result = draft.create_draft([{
            "title": title,
            "content": content,
            "thumb_media_id": thumb_media_id,
            "show_cover_pic": 1,
        }])

        if "media_id" in result:
            print(f"   ✅ 草稿创建成功！")
            print(f"   📝 media_id: {result['media_id']}")
            print(f"\n💡 提示：使用以下命令发布草稿：")
            print(f"   python -m xqcwechat.scripts.quick_publish {result['media_id']}")
        else:
            print(f"   ❌ 草稿创建失败：{result}")
            sys.exit(1)

    except Exception as e:
        print(f"\n❌ 错误：{str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
