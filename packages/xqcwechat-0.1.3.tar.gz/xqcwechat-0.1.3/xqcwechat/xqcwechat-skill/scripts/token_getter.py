"""
微信公众号 Token 回调函数

⚠️ 请勿修改此文件的函数名 get_token
⚠️ 只需修改下面的 CONFIG 配置或函数内部逻辑

支持的配置方式:
1. 从环境变量读取 (推荐)
2. 硬编码配置

多账号支持:
- 全局配置: WECHAT_TOKEN_SECRET, WECHAT_TOKEN_URL, WECHAT_TOKEN_PROXY
- 账号级配置: WECHAT_ACCOUNT_1_TOKEN_APP_ID, WECHAT_ACCOUNT_2_TOKEN_APP_ID
"""

from typing import Dict, Any
import os
import requests

CONFIG = {
    "url": os.environ.get(
        "WECHAT_TOKEN_URL", "https://wechatoken.xiaoqiangclub.qzz.io/token/token"
    ),
    "secret": os.environ.get("WECHAT_TOKEN_SECRET", ""),
    "app_id": os.environ.get("WECHAT_TOKEN_APP_ID", ""),
    "proxy": os.environ.get("WECHAT_TOKEN_PROXY", ""),
}


def get_token(account_index: int = 1) -> Dict[str, Any]:
    """
    Token获取回调函数

    ⚠️ 请勿修改此函数名

    :param account_index: 账号索引，用于获取对应账号的 app_id
    :return: 包含 access_token 和 expires_in 的字典
    """

    if not CONFIG["secret"]:
        raise NotImplementedError(
            "请配置Token获取方式!\n设置环境变量 WECHAT_TOKEN_SECRET"
        )

    params = {
        "simple_response": True,
        "secret": CONFIG["secret"],
    }

    app_id = CONFIG["app_id"] or os.environ.get(
        f"WECHAT_ACCOUNT_{account_index}_TOKEN_APP_ID", ""
    )
    if app_id:
        params["app_id"] = app_id

    proxy = CONFIG["proxy"] or os.environ.get("WECHAT_PROXY", "")
    proxies = None
    if proxy:
        proxies = {"http": proxy, "https": proxy}

    response = requests.get(
        CONFIG["url"],
        params=params,
        proxies=proxies,
        timeout=10,
    )
    response.raise_for_status()
    result = response.json()

    if "access_token" in result and "expires_in" in result:
        return result

    raise Exception(f"获取Token失败: {result}")
