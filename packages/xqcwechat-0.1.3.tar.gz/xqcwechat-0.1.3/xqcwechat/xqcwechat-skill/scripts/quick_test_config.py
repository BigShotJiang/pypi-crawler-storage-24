#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
快速测试脚本：验证环境配置是否正确

使用方法：
    python -m xqcwechat.scripts.quick_test_config

依赖：
    - .env 文件中配置了 WECHAT_TOKEN_SECRET 或 WECHAT_APP_ID + WECHAT_APP_SECRET
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from dotenv import load_dotenv

script_dir = os.path.dirname(os.path.abspath(__file__))
skill_dir = os.path.dirname(script_dir)
env_path = os.path.join(skill_dir, ".env")
if os.path.exists(env_path):
    load_dotenv(env_path, override=True)


def test_config():
    print("=" * 50)
    print("xqcwechat 环境配置测试")
    print("=" * 50)

    from xqcwechat import Auth

    token_secret = os.environ.get("WECHAT_TOKEN_SECRET") or os.environ.get("WECHAT_GET_WECHAT_TOKEN_SECRET")
    app_id = os.environ.get("WECHAT_APP_ID")
    app_secret = os.environ.get("WECHAT_APP_SECRET")
    proxy = os.environ.get("WECHAT_PROXY")

    print("\n📋 当前配置：")
    print(f"  - WECHAT_TOKEN_SECRET: {'✅ 已配置' if token_secret else '❌ 未配置'}")
    print(f"  - WECHAT_APP_ID: {'✅ 已配置' if app_id else '❌ 未配置'}")
    print(f"  - WECHAT_APP_SECRET: {'✅ 已配置' if app_secret else '❌ 未配置'}")
    print(f"  - WECHAT_PROXY: {'✅ 已配置' if proxy else '❌ 未配置'}")

    if not token_secret and not (app_id and app_secret):
        print("\n❌ 错误：未配置有效的 Token 获取方式！")
        print("请选择以下方式之一配置：")
        print("  方式一：配置 WECHAT_TOKEN_SECRET（推荐）")
        print("  方式二：配置 WECHAT_APP_ID + WECHAT_APP_SECRET")
        return False

    print("\n🔄 尝试获取 access_token...")

    try:
        auth = Auth()
        token = auth.get_access_token()
        print(f"✅ Token 获取成功！")
        print(f"   Token: {token[:20]}...")
        return True
    except Exception as e:
        print(f"❌ Token 获取失败：{str(e)}")
        return False


if __name__ == "__main__":
    success = test_config()
    sys.exit(0 if success else 1)
