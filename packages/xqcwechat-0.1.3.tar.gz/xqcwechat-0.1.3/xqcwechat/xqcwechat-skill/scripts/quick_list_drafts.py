#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
快速查看草稿列表脚本

使用方法：
    python -m xqcwechat.scripts.quick_list_drafts
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))

from dotenv import load_dotenv

script_dir = os.path.dirname(os.path.abspath(__file__))
skill_dir = os.path.dirname(script_dir)
env_path = os.path.join(skill_dir, ".env")
if os.path.exists(env_path):
    load_dotenv(env_path, override=True)


def main():
    print("=" * 50)
    print("快速查看草稿列表")
    print("=" * 50)

    from xqcwechat import Auth, Draft

    try:
        print("\n1. 初始化 Auth...")
        auth = Auth()
        print("   ✅ Auth 初始化成功")

        print("\n2. 获取草稿列表...")
        draft = Draft(auth)
        result = draft.get_draft_list(offset=0, count=10, no_content=True)

        if "item" in result:
            items = result["item"]
            total_count = result.get("total_count", len(items))
            print(f"   ✅ 共 {total_count} 篇草稿，显示前 {len(items)} 篇：\n")

            for i, item in enumerate(items, 1):
                media_id = item.get("media_id", "N/A")
                content = item.get("content", {})
                news_item = content.get("news_item", [{}])[0] if content.get("news_item") else {}
                title = news_item.get("title", "无标题")
                author = news_item.get("author", "未知")
                print(f"   {i}. {title}")
                print(f"      作者：{author}")
                print(f"      media_id：{media_id}")
                print()
        else:
            print(f"   ❌ 获取失败：{result}")

    except Exception as e:
        print(f"\n❌ 错误：{str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
