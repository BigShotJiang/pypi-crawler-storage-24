"""
微信公众号 Token 回调函数 - 多账号版本

⚠️ 请勿修改此文件的函数名 get_token

每个账号创建一个对应的模块文件，例如:
- account_账号1.py
- account_账号2.py

然后在 .env 中配置:
WECHAT_ACCOUNT_1_TOKEN_GETTER_MODULE=token_getters.account_账号1
"""

from typing import Dict, Any
import os
import requests

CONFIG = {
    "url": os.environ.get("WECHAT_TOKEN_URL", "https://wechatoken.xiaoqiangclub.qzz.io/token/token"),
    "secret": os.environ.get("WECHAT_TOKEN_SECRET", ""),
    "app_id": os.environ.get("WECHAT_TOKEN_APP_ID", ""),
    "proxy": os.environ.get("WECHAT_TOKEN_PROXY", ""),
}


def get_token() -> Dict[str, Any]:
    """
    Token获取回调函数
    
    ⚠️ 请勿修改此函数名
    
    修改 CONFIG 配置来定制Token获取
    
    :return: 包含 access_token 和 expires_in 的字典
    """
    
    if not CONFIG["secret"]:
        raise NotImplementedError(
            "请配置Token获取方式!\n"
            "设置环境变量 WECHAT_TOKEN_SECRET"
        )
    
    params = {
        "simple_response": True,
        "secret": CONFIG["secret"],
    }
    
    if CONFIG["app_id"]:
        params["app_id"] = CONFIG["app_id"]
    
    proxies = None
    if CONFIG["proxy"]:
        proxies = {"http": CONFIG["proxy"], "https": CONFIG["proxy"]}
    
    response = requests.get(
        CONFIG["url"],
        params=params,
        proxies=proxies,
        timeout=10,
    )
    response.raise_for_status()
    result = response.json()
    
    if "access_token" in result and "expires_in" in result:
        return result
    
    raise Exception(f"获取Token失败: {result}")
