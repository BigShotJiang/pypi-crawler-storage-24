"""
access_token 获取函数模块

提供各种获取微信公众号 access_token 的回调函数
"""

import requests
from typing import Dict, Optional


def get_wechat_token(
    secret: str,
    proxy: Optional[str] = None,
    app_id: Optional[str] = None,
    url: str = "https://wechatoken.xiaoqiangclub.qzz.io/token/token",
) -> Optional[Dict[str, str]]:
    """
    获取微信公众号 Access Token

    此接口为自用接口，仅限本人使用！
    配合自建的 access_token 管理API使用，支持代理。
    部署文档：https://xiaoqiangclub.blog.csdn.net/article/details/155324712
    :param secret: 密钥，用于验证身份
    :param proxy: 代理服务器地址，格式为 "http://ip:port" 或 "https://ip:port"
    :param app_id: 微信公众号 AppID，默认为 None，返回 XiaoqiangClub 的 Access Token
    :param url: access_token 管理 API 地址，默认为自用接口地址
    :return: 包含 access_token 和 expires_in 的字典，获取失败返回 None
    """
    params = {
        "simple_response": True,
        "secret": secret,
    }

    if app_id:
        params["app_id"] = app_id

    # 配置代理
    proxies = None
    if proxy:
        proxies = {
            "http": proxy,
            "https": proxy,
        }

    try:
        response = requests.get(url, params=params, proxies=proxies)
        response.raise_for_status()  # 检查请求是否成功
        result = response.json()

        # 简单响应模式
        if (
            result
            and isinstance(result, dict)
            and "access_token" in result
            and "expires_in" in result
        ):
            return result
        return None
    except Exception as e:
        print(f"❌ 获取access_token失败：{str(e)}")
        return None
