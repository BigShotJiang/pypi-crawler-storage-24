"""
错误码映射模块

存储微信开放平台的错误码及其描述
"""

WECHAT_ERROR_CODES = {
    # 基础错误码
    40002: "invalid grant_type 不合法的凭证类型",
    40003: "invalid openid 不合法的 OpenID",
    40004: "invalid media type 不合法的媒体文件类型",
    40005: "invalid file type 上传素材文件格式不对",
    40006: "invalid meida size 上传素材文件大小超出限制",
    40007: "invalid media_id 不合法的媒体文件 id",
    40008: "invalid message type 不合法的消息类型",
    40009: "invalid image size 图片尺寸太大",
    40010: "invalid voice size 不合法的语音文件大小",
    40011: "invalid video size 不合法的视频文件大小",
    40012: "invalid thumb size 不合法的缩略图文件大小",
    40015: "invalid menu type 不合法的菜单类型",
    40016: "invalid button size 不合法的按钮个数",
    40017: "invalid button type 不合法的按钮类型",
    40018: "invalid button name size 不合法的按钮名字长度",
    40019: "invalid button key size 不合法的按钮 KEY 长度",
    40020: "invalid button url size 不合法的按钮 URL 长度",
    40021: "invalid menu version 不合法的菜单版本号",
    40022: "invalid sub_menu level 不合法的子菜单级数",
    40023: "invalid sub button size 不合法的子菜单按钮个数",
    40024: "invalid sub button type 不合法的子菜单按钮类型",
    40025: "invalid sub button name size 不合法的子菜单按钮名字长度",
    40026: "invalid sub button key size 不合法的子菜单按钮 KEY 长度",
    40027: "invalid sub button url size 不合法的子菜单按钮 URL 长度",
    40028: "invalid menu api user 不合法的自定义菜单使用用户",
    40029: "invalid code 无效的 oauth_code",
    40030: "invalid refresh_token 不合法的 refresh_token",
    40031: "invalid openid list 不合法的 openid 列表",
    40032: "invalid openid list size 不合法的 openid 列表长度",
    40033: "invalid charset. please check your request, if include \\uxxxx will create fail! 不合法的请求字符，不能包含 \\uxxxx 格式的字符",
    40034: "invalid template size",
    40035: "invalid args size 不合法的参数",
    40036: "invalid template_id size 不合法的 template_id 长度",
    40037: "invalid template_id 不合法的 template_id",
    40038: "invalid packaging type 不合法的请求格式",
    40039: "invalid url size 不合法的 URL 长度",
    40048: "invalid url domain 无效的url",
    40050: "invalid timeline type 不合法的分组 id",
    40051: "invalid group name 分组名字不合法",
    40052: "invalid action name",
    40053: "invalid action info, please check document",
    40054: "invalid sub button url domain 不合法的子菜单按钮 url 域名",
    40055: "invalid button url domain 不合法的菜单按钮 url 域名",
    40060: "invalid article idx 删除单篇图文时，指定的 article_idx 不合法",
    40101: "missing parameter",
    41005: "media data missing 媒体数据缺失",
}

def get_error_message(errcode: int) -> str:
    """
    根据错误码获取错误描述
    
    :param errcode: 错误码
    :return: 错误描述
    """
    return WECHAT_ERROR_CODES.get(errcode, f"未知错误码: {errcode}")
