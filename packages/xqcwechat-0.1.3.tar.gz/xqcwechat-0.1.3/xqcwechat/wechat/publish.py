"""
发布管理模块

实现微信公众号发布管理相关API
"""

from typing import Optional, Dict, Any
from ..core import Auth, Client


class Publish:
    """
    发布管理类

    用于管理微信公众号的发布功能
    """

    def __init__(self, auth: Auth):
        """
        初始化发布管理

        :param auth: 认证管理实例
        """
        self.auth = auth
        self.client = Client(proxy=auth.proxy)

    def freepublish_batchget(
        self, offset: int = 0, count: int = 20, no_content: bool = False
    ) -> Dict[str, Any]:
        """
        获取已发布的消息列表

        :param offset: 从全部素材的该偏移位置开始返回，0表示从第一个素材返回
        :param count: 返回素材的数量，取值在1到20之间
        :param no_content: 是否不返回正文，true表示不返回正文，false表示返回正文
        :return: 已发布的消息列表
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/batchget?access_token={access_token}"

        data = {"offset": offset, "count": count, "no_content": no_content}
        return self.client.post(url, data)

    def publish_draft(
        self, media_id: str, title: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        发布草稿

        :param media_id: 要发布的草稿的media_id
        :param title: 可选，用来指定本次发布的标题
        :return: 发布任务的id
        """
        return self.freepublish_submit(media_id, title)

    def get_published_articles(
        self, offset: int = 0, count: int = 20, no_content: bool = False
    ) -> Dict[str, Any]:
        """
        获取已发布的消息列表

        :param offset: 从全部素材的该偏移位置开始返回，0表示从第一个素材返回
        :param count: 返回素材的数量，取值在1到20之间
        :param no_content: 是否不返回正文，true表示不返回正文，false表示返回正文
        :return: 已发布的消息列表
        """
        return self.freepublish_batchget(offset, count, no_content)

    def delete_article(self, article_id: str) -> Dict[str, Any]:
        """
        删除已发布文章

        :param article_id: 要删除的文章的article_id
        :return: 操作结果
        """
        return self.freepublish_delete(article_id)

    def get_publish_status(self, publish_id: str) -> Dict[str, Any]:
        """
        查询发布状态

        :param publish_id: 发布任务的id
        :return: 发布状态
        """
        return self.freepublish_get(publish_id)

    def get_article(self, article_id: str) -> Dict[str, Any]:
        """
        获取已发布图文信息

        :param article_id: 要获取的图文的article_id
        :return: 图文信息
        """
        return self.freepublish_getarticle(article_id)

    def freepublish_delete(self, article_id: str) -> Dict[str, Any]:
        """
        删除发布文章

        :param article_id: 要删除的文章的article_id
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/delete?access_token={access_token}"

        data = {"article_id": article_id}
        return self.client.post(url, data)

    def freepublish_get(self, publish_id: str) -> Dict[str, Any]:
        """
        发布状态查询

        :param publish_id: 发布任务的id
        :return: 发布状态
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/get?access_token={access_token}"

        data = {"publish_id": publish_id}
        return self.client.post(url, data)

    def freepublish_getarticle(self, article_id: str) -> Dict[str, Any]:
        """
        获取已发布图文信息

        :param article_id: 要获取的图文的article_id
        :return: 图文信息
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/getarticle?access_token={access_token}"

        data = {"article_id": article_id}
        return self.client.post(url, data)

    def freepublish_submit(
        self, media_id: str, title: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        发布草稿

        :param media_id: 要发布的草稿的media_id
        :param title: 可选，用来指定本次发布的标题
        :return: 发布任务的id
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/freepublish/submit?access_token={access_token}"

        data = {"media_id": media_id}
        if title:
            data["title"] = title

        return self.client.post(url, data)
