"""
留言管理模块

实现微信公众号留言管理相关API
"""

from typing import Dict, Any
from ..core import Auth, Client


class Comment:
    """
    留言管理类
    
    用于管理微信公众号的留言
    """
    
    def __init__(self, auth: Auth):
        """
        初始化留言管理
        
        :param auth: 认证管理实例
        """
        self.auth = auth
        self.client = Client(proxy=auth.proxy)
    
    def open_article_comment(self, msg_data_id: str, index: int) -> Dict[str, Any]:
        """
        打开已群发文章评论
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/open?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index
        }
        return self.client.post(url, data)
    
    def list_comment(self, msg_data_id: str, index: int, begin: int = 0, count: int = 50, 
                    type: int = 0) -> Dict[str, Any]:
        """
        查看指定文章的评论数据
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :param begin: 起始位置，从0开始
        :param count: 获取数目，最大50
        :param type: 评论类型，0为精选评论，1为普通评论
        :return: 评论列表
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/list?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index,
            "begin": begin,
            "count": count,
            "type": type
        }
        return self.client.post(url, data)
    
    def close_comment(self, msg_data_id: str, index: int) -> Dict[str, Any]:
        """
        关闭已群发文章评论
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/close?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index
        }
        return self.client.post(url, data)
    
    def elect_comment(self, msg_data_id: str, index: int, user_comment_id: str) -> Dict[str, Any]:
        """
        评论标记精选
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :param user_comment_id: 用户评论id
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/markelect?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index,
            "user_comment_id": user_comment_id
        }
        return self.client.post(url, data)
    
    def unelect_comment(self, msg_data_id: str, index: int, user_comment_id: str) -> Dict[str, Any]:
        """
        评论取消精选
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :param user_comment_id: 用户评论id
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/unmarkelect?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index,
            "user_comment_id": user_comment_id
        }
        return self.client.post(url, data)
    
    def del_comment(self, msg_data_id: str, index: int, user_comment_id: str) -> Dict[str, Any]:
        """
        删除评论
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :param user_comment_id: 用户评论id
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/delete?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index,
            "user_comment_id": user_comment_id
        }
        return self.client.post(url, data)
    
    def reply_comment(self, msg_data_id: str, index: int, user_comment_id: str, 
                     content: str) -> Dict[str, Any]:
        """
        回复评论
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :param user_comment_id: 用户评论id
        :param content: 回复内容
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/reply/add?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index,
            "user_comment_id": user_comment_id,
            "content": content
        }
        return self.client.post(url, data)
    
    def del_reply_comment(self, msg_data_id: str, index: int, user_comment_id: str, 
                         reply_comment_id: str) -> Dict[str, Any]:
        """
        删除回复
        
        :param msg_data_id: 群发返回的msg_data_id
        :param index: 多图文时，用来指定是哪一篇图文，从0开始
        :param user_comment_id: 用户评论id
        :param reply_comment_id: 回复评论id
        :return: 操作结果
        """
        access_token = self.auth.get_access_token()
        url = f"https://api.weixin.qq.com/cgi-bin/comment/reply/delete?access_token={access_token}"
        
        data = {
            "msg_data_id": msg_data_id,
            "index": index,
            "user_comment_id": user_comment_id,
            "reply_comment_id": reply_comment_id
        }
        return self.client.post(url, data)
