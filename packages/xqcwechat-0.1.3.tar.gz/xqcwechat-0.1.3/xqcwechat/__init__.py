"""
📱 xqcwechat - 微信公众号开发工具包

支持素材管理、草稿管理、发布管理和留言管理等功能

版本: 0.1.3
"""

__version__ = "0.1.3"
__description__ = "📱 微信公众号开发工具包，支持素材管理、草稿管理、发布管理和留言管理"

from .core import Auth, Client, Cache
from .core.token_getters import get_wechat_token
from .wechat import Asset, Draft, Publish, Comment
from .utils import (
    Crypto,
    get_error_message,
    WECHAT_ERROR_CODES,
    load_image,
    get_crop_parameters,
    generate_optimal_crop,
    create_cover_info,
    create_image_list_item,
)

__all__ = [
    "Auth",
    "Client",
    "Cache",
    "get_wechat_token",
    "Asset",
    "Draft",
    "Publish",
    "Comment",
    "Crypto",
    "get_error_message",
    "WECHAT_ERROR_CODES",
    "load_image",
    "get_crop_parameters",
    "generate_optimal_crop",
    "create_cover_info",
    "create_image_list_item",
]
