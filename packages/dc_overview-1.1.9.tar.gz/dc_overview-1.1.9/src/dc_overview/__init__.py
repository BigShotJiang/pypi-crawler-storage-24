"""
DC Overview - GPU Datacenter Monitoring Suite

A comprehensive monitoring solution for GPU datacenters with:
- Prometheus metrics collection
- Grafana dashboards
- Node, GPU, and VRAM temperature exporters
- IPMI/BMC monitoring integration
- Vast.ai integration
- Automated fleet deployment

Quick Start:
    pipx install dc-overview
    sudo dc-overview setup
"""

__version__ = "1.1.9"
__author__ = "CryptoLabs"
__email__ = "info@cryptolabs.co.za"

# Build info - populated at build time or runtime
__git_commit__ = None
__git_branch__ = None
__build_time__ = None

def _load_build_info():
    """Load build info from _build_info.py if available, or detect from git."""
    global __git_commit__, __git_branch__, __build_time__
    try:
        from . import _build_info
        __git_commit__ = getattr(_build_info, 'GIT_COMMIT', None)
        __git_branch__ = getattr(_build_info, 'GIT_BRANCH', None)
        __build_time__ = getattr(_build_info, 'BUILD_TIME', None)
    except ImportError:
        # Try to detect from git if in development
        try:
            import subprocess
            from pathlib import Path

            # Check if we're in a git repo
            pkg_dir = Path(__file__).parent
            git_dir = pkg_dir.parent.parent / '.git'

            if git_dir.exists():
                # Get current branch
                result = subprocess.run(
                    ['git', 'rev-parse', '--abbrev-ref', 'HEAD'],
                    capture_output=True, text=True, timeout=2, cwd=pkg_dir
                )
                if result.returncode == 0:
                    __git_branch__ = result.stdout.strip()

                # Get current commit
                result = subprocess.run(
                    ['git', 'rev-parse', 'HEAD'],
                    capture_output=True, text=True, timeout=2, cwd=pkg_dir
                )
                if result.returncode == 0:
                    __git_commit__ = result.stdout.strip()
        except Exception:
            pass

_load_build_info()


def get_version_info() -> str:
    """Get detailed version string with build info."""
    parts = [f"dc-overview {__version__}"]

    if __git_branch__ or __git_commit__:
        build_parts = []
        if __git_branch__:
            build_parts.append(__git_branch__)
        if __git_commit__:
            build_parts.append(__git_commit__[:7])
        if build_parts:
            parts.append(f"({', '.join(build_parts)})")

    if __build_time__:
        parts.append(f"built {__build_time__}")

    return " ".join(parts)


def get_image_tag(dev: bool = False) -> str:
    """Return the Docker image tag to use.
    
    Always returns 'latest' (stable) unless --dev flag is explicitly passed.
    This prevents accidentally deploying dev images in production.
    
    Args:
        dev: If True, return 'dev' tag. Requires explicit --dev CLI flag.
    """
    if dev:
        return 'dev'
    return 'latest'

# Export main classes for programmatic use
from .fleet_config import FleetConfig, Server
from .fleet_wizard import FleetWizard, run_fleet_wizard
from .fleet_manager import FleetManager, deploy_fleet
from .ssh_manager import SSHManager
from .prerequisites import PrerequisitesInstaller, ensure_prerequisites

__all__ = [
    "FleetConfig",
    "Server", 
    "FleetWizard",
    "FleetManager",
    "SSHManager",
    "PrerequisitesInstaller",
    "run_fleet_wizard",
    "deploy_fleet",
    "ensure_prerequisites",
]
