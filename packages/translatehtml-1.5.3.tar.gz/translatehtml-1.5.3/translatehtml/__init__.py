from translatehtml.translatehtml import *
