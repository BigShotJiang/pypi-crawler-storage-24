"""Server discovery: find Prodigy servers for tasks assigned to this agent.

The agent doesn't receive task URLs directly. Instead it queries PAM
for its related tasks and resolves each task's Prodigy server URL.

Resolution strategy (per task):
  1. Look for a broker path registered for this task.
  2. Use the ``{execution_id}.{broker_address}`` subdomain.
  3. If neither work, skip the task and log a warning.
"""

from __future__ import annotations

import logging
from typing import cast
from uuid import UUID

from prodigy_teams_recipes_sdk.prodigy_teams_pam_sdk.errors import BrokerPathNotFound
from prodigy_teams_recipes_sdk.prodigy_teams_pam_sdk.models import AgentDetail
from prodigy_teams_recipes_sdk.prodigy_teams_pam_sdk.recipe_client import (
    Settings,
    get_authenticated_pam_client,
)

logger = logging.getLogger(__name__)


async def discover_servers() -> list[str]:
    """Query PAM for tasks assigned to this agent and return their server URLs."""
    settings = Settings()
    if not settings.is_valid():
        raise RuntimeError(
            "Missing PRODIGY_TEAMS_* environment variables — "
            "is this running on the cluster?"
        )
    pam = await get_authenticated_pam_client(settings)
    agent = cast(AgentDetail, await pam.agent.read_async(id=settings.job_id))
    task_ids: list[UUID] = agent.related_tasks
    if not task_ids:
        logger.info("Agent has no related tasks.")
        return []
    broker = await pam.broker.read_async(id=settings.broker_id)
    urls: list[str] = []
    for task_id in task_ids:
        url = await _resolve_task_url(pam, task_id, broker)
        if url:
            urls.append(url)
        else:
            logger.warning("Could not resolve URL for task %s", task_id)
    return urls


async def _resolve_task_url(pam, task_id: UUID, broker) -> str | None:
    """Resolve the Prodigy server URL for a single task.

    Tries broker paths first, then the external subdomain.
    """
    # 1. Try broker paths — a path registered with the task ID as name.
    try:
        path = await pam.broker_path.read_async(name=str(task_id), broker_id=broker.id)
        return f"https://{broker.address}/{path.path.lstrip('/')}"
    except BrokerPathNotFound:
        pass

    # 2. Use external subdomain.
    task = await pam.task.read_async(id=task_id)
    if not task.last_execution_id:
        logger.warning("Task %s has no execution — is it running?", task_id)
        return None
    return f"https://{task.last_execution_id}.{broker.address}"
