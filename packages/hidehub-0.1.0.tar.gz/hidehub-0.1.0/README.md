# HideHub CLI

Secure secret management from the command line.

## Installation

```bash
pip install hidehub-cli
```

Or install from source:

```bash
cd client
pip install -e .
```

## Quick Start

```bash
# Authenticate
hidehub init --email you@example.com

# Push secrets from a .env file
hidehub push --env-file .env.production --project my-api

# List projects
hidehub list

# List secrets in a project
hidehub list --project my-api

# Run a command with secrets injected
hidehub run --project my-api -- npm start

# Rotate a secret
hidehub rotate OPENAI_API_KEY --project my-api

# Export secrets for shell eval
eval "$(hidehub use --project my-api --export)"
```

## CI/CD Usage

Set the `HIDEHUB_API_KEY` environment variable to use API key auth instead of JWT:

```bash
export HIDEHUB_API_KEY=hh_your_api_key_here
hidehub run --project my-api -- npm test
```
