"""Parse .env files into key=value dicts."""

from __future__ import annotations

from pathlib import Path


def parse_env_file(path: str | Path) -> dict[str, str]:
    """Parse a .env file into a dict of key-value pairs.

    Handles:
    - Blank lines and comments (lines starting with #)
    - Quoted values (single and double quotes)
    - Inline comments after values
    """
    result: dict[str, str] = {}
    text = Path(path).read_text()

    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue

        idx = line.find("=")
        if idx == -1:
            continue

        key = line[:idx].strip()
        value = line[idx + 1 :].strip()

        # Remove surrounding quotes
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
            value = value[1:-1]

        if key:
            result[key] = value

    return result
