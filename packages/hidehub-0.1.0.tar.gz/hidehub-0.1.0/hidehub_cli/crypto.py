"""V1 encryption compatible with frontend crypto.ts.

Scheme: PBKDF2-SHA256 (600k iter) → HKDF → AES-256-GCM + HMAC-SHA256
Output: JSON string {v, salt, iv, ct, tag, hmac, algorithm, kdf}
"""

from __future__ import annotations

import base64
import hashlib
import hmac as hmac_mod
import json
import os
from typing import Any

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes

V1_ITERATIONS = 600_000
V1_SALT_BYTES = 32
V1_IV_BYTES = 12


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode()


def _unb64(s: str) -> bytes:
    return base64.b64decode(s)


def _derive_keys(password: str, salt: bytes) -> tuple[bytes, bytes]:
    """Derive encryption key and HMAC key from password + salt.

    Matches frontend deriveKeysV1() exactly:
      1. PBKDF2-SHA256, 600k iterations → 32-byte master key
      2. HKDF-SHA256 with info="encryption" → 32-byte enc key
      3. HKDF-SHA256 with info="hmac" → 32-byte hmac key
    """
    # PBKDF2
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=V1_ITERATIONS,
    )
    master_key = kdf.derive(password.encode())

    # HKDF → encryption key
    hkdf_enc = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b"",  # empty salt, matching frontend
        info=b"encryption",
    )
    enc_key = hkdf_enc.derive(master_key)

    # HKDF → HMAC key
    hkdf_hmac = HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=b"",
        info=b"hmac",
    )
    hmac_key = hkdf_hmac.derive(master_key)

    return enc_key, hmac_key


def encrypt_secret(plaintext: str, password: str) -> str:
    """Encrypt a secret value. Returns JSON string compatible with frontend."""
    salt = os.urandom(V1_SALT_BYTES)
    iv = os.urandom(V1_IV_BYTES)
    enc_key, hmac_key = _derive_keys(password, salt)

    # AES-256-GCM
    aesgcm = AESGCM(enc_key)
    # AESGCM.encrypt returns ciphertext + 16-byte tag appended
    ct_with_tag = aesgcm.encrypt(iv, plaintext.encode(), None)
    ct = ct_with_tag[:-16]
    tag = ct_with_tag[-16:]

    # HMAC-SHA256 over ciphertext
    hmac_sig = hmac_mod.new(hmac_key, ct, hashlib.sha256).digest()

    blob: dict[str, Any] = {
        "v": 1,
        "salt": _b64(salt),
        "iv": _b64(iv),
        "ct": _b64(ct),
        "tag": _b64(tag),
        "hmac": _b64(hmac_sig),
        "algorithm": "AES-256-GCM",
        "kdf": "PBKDF2-SHA256-600k+HKDF",
    }
    return json.dumps(blob)


def decrypt_secret(encrypted_json: str, password: str) -> str:
    """Decrypt a v1 encrypted secret."""
    blob = json.loads(encrypted_json)
    if blob.get("v") != 1:
        raise ValueError(f"Unsupported encryption version: {blob.get('v')}")

    salt = _unb64(blob["salt"])
    iv = _unb64(blob["iv"])
    ct = _unb64(blob["ct"])
    tag = _unb64(blob["tag"])
    hmac_expected = _unb64(blob["hmac"])

    enc_key, hmac_key = _derive_keys(password, salt)

    # Verify HMAC
    hmac_actual = hmac_mod.new(hmac_key, ct, hashlib.sha256).digest()
    if not hmac_mod.compare_digest(hmac_actual, hmac_expected):
        raise ValueError("HMAC verification failed — data may be corrupted or wrong password")

    # Decrypt
    aesgcm = AESGCM(enc_key)
    plaintext = aesgcm.decrypt(iv, ct + tag, None)
    return plaintext.decode()
