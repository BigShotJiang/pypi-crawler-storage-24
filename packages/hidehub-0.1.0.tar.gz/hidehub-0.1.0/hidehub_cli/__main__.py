"""Entry point for `python -m hidehub_cli`."""

from hidehub_cli.cli import app

app()
