"""HideHub CLI — Secure secret management from the command line."""

__version__ = "0.1.0"
