"""hidehub use — Interactive secret picker, outputs export statements."""

from __future__ import annotations

import getpass
import sys

import typer

from hidehub_cli.api_client import HideHubClient, ApiError
from hidehub_cli.crypto import decrypt_secret

app = typer.Typer()


def _pick_from_list(prompt: str, items: list[dict], name_key: str) -> dict | None:
    """Simple numbered list picker for terminals without questionary."""
    if not items:
        return None
    typer.echo(f"\n{prompt}")
    for i, item in enumerate(items, 1):
        typer.echo(f"  {i}. {item[name_key]}")
    while True:
        choice = typer.prompt("Select", default="1")
        try:
            idx = int(choice) - 1
            if 0 <= idx < len(items):
                return items[idx]
        except ValueError:
            pass
        typer.echo("Invalid choice, try again.")


@app.command()
def use(
    project: str = typer.Option(None, "--project", "-p", help="Project name"),
    key: str = typer.Option(None, "--key", "-k", help="Specific key to load"),
    export: bool = typer.Option(False, "--export", help="Output as export statements"),
):
    """Load secrets into your environment."""
    master_password = getpass.getpass("Master password: ")
    client = HideHubClient()

    # Select project
    if project:
        proj = client.find_project_by_name(project)
        if not proj:
            typer.echo(f"✗ Project '{project}' not found", err=True)
            raise typer.Exit(1)
    else:
        projects = client.list_projects()
        if not projects:
            typer.echo("✗ No projects found. Run `hidehub push` first.", err=True)
            raise typer.Exit(1)
        proj = _pick_from_list("Select project:", projects, "name")
        if not proj:
            raise typer.Exit(1)

    # Get secrets
    secrets = client.list_secrets(proj["id"])
    if not secrets:
        typer.echo(f"✗ No secrets in project '{proj['name']}'", err=True)
        raise typer.Exit(1)

    # Filter by key if specified
    if key:
        secrets = [s for s in secrets if s["key_name"] == key]
        if not secrets:
            typer.echo(f"✗ Key '{key}' not found in project '{proj['name']}'", err=True)
            raise typer.Exit(1)

    # Decrypt and output
    loaded = 0
    for s in secrets:
        try:
            full = client.get_secret(proj["id"], s["id"])
            value = decrypt_secret(full["encrypted_blob"], master_password)
            if export:
                # Output for eval: eval "$(hidehub use --export)"
                sys.stdout.write(f"export {s['key_name']}={_shell_escape(value)}\n")
            loaded += 1
        except Exception as e:
            typer.echo(f"✗ Failed to decrypt {s['key_name']}: {e}", err=True)

    if not export:
        typer.echo(f"✓ Loaded {loaded} secrets from project \"{proj['name']}\"")


def _shell_escape(value: str) -> str:
    """Escape a value for safe shell export."""
    if not value or any(c in value for c in " \t\n'\"\\$`!#&|;(){}"):
        escaped = value.replace("'", "'\\''")
        return f"'{escaped}'"
    return value
