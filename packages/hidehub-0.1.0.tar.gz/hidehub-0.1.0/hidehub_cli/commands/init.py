"""hidehub init — Authenticate and save config."""

from __future__ import annotations

import getpass
import time

import httpx
import typer

from hidehub_cli.api_client import HideHubClient, ApiError
from hidehub_cli.config import save_config, DEFAULT_SERVER

app = typer.Typer()


def _prompt_2fa(client: HideHubClient, two_fa_token: str) -> str:
    """Prompt for a TOTP code (or backup code) and verify."""
    typer.echo("\n🔐 Two-factor authentication required.")
    code = typer.prompt("Enter your 2FA code")
    try:
        return client.verify_2fa(two_fa_token, code)
    except ApiError as e:
        typer.echo(f"✗ 2FA verification failed: {e.detail}", err=True)
        raise typer.Exit(1)


def _login_email(client: HideHubClient) -> str:
    """Email/password login flow, returns access token."""
    email = typer.prompt("Email")
    password = getpass.getpass("Password: ")

    try:
        data = client.login(email, password)
    except ApiError as e:
        typer.echo(f"✗ Authentication failed: {e.detail}", err=True)
        raise typer.Exit(1)

    if data.get("requires_2fa"):
        return _prompt_2fa(client, data["two_fa_token"])

    return data["access_token"]


def _login_github(client: HideHubClient, server: str) -> str:
    """GitHub Device Flow login, returns access token."""
    # We need the GitHub Client ID. Fetch it from the server's config endpoint
    # or use the well-known HideHub GitHub OAuth App client ID.
    # For device flow, we call GitHub directly with the client_id.
    typer.echo("\n🔗 Starting GitHub Device Flow...")

    # Step 1: Get the GitHub client_id from the server
    # We'll request a device code from GitHub
    github_client_id = _get_github_client_id(server)
    if not github_client_id:
        typer.echo("✗ GitHub OAuth is not configured on this server.", err=True)
        raise typer.Exit(1)

    # Step 2: Request device code
    with httpx.Client(timeout=30) as http:
        resp = http.post(
            "https://github.com/login/oauth/device/code",
            data={"client_id": github_client_id, "scope": "user:email"},
            headers={"Accept": "application/json"},
        )
        if resp.status_code != 200:
            typer.echo("✗ Failed to start GitHub device flow.", err=True)
            raise typer.Exit(1)
        device = resp.json()

    user_code = device["user_code"]
    verification_uri = device["verification_uri"]
    device_code = device["device_code"]
    interval = device.get("interval", 5)
    expires_in = device.get("expires_in", 900)

    typer.echo(f"\n  Open: {verification_uri}")
    typer.echo(f"  Enter code: {user_code}\n")
    typer.echo("Waiting for authorization...", nl=False)

    # Step 3: Poll for access token
    github_token = None
    deadline = time.time() + expires_in

    with httpx.Client(timeout=30) as http:
        while time.time() < deadline:
            time.sleep(interval)
            typer.echo(".", nl=False)
            resp = http.post(
                "https://github.com/login/oauth/access_token",
                data={
                    "client_id": github_client_id,
                    "device_code": device_code,
                    "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                },
                headers={"Accept": "application/json"},
            )
            body = resp.json()
            error = body.get("error")
            if error == "authorization_pending":
                continue
            elif error == "slow_down":
                interval = body.get("interval", interval + 5)
                continue
            elif error == "expired_token":
                typer.echo("\n✗ Device code expired. Please try again.", err=True)
                raise typer.Exit(1)
            elif error == "access_denied":
                typer.echo("\n✗ Authorization denied.", err=True)
                raise typer.Exit(1)
            elif error:
                typer.echo(f"\n✗ GitHub error: {error}", err=True)
                raise typer.Exit(1)
            else:
                github_token = body.get("access_token")
                break

    typer.echo("")  # newline after dots

    if not github_token:
        typer.echo("✗ Failed to get GitHub access token.", err=True)
        raise typer.Exit(1)

    # Step 4: Exchange GitHub token for HideHub JWT
    try:
        data = client.exchange_github_token(github_token)
    except ApiError as e:
        typer.echo(f"✗ GitHub token exchange failed: {e.detail}", err=True)
        raise typer.Exit(1)

    if data.get("requires_2fa"):
        return _prompt_2fa(client, data["two_fa_token"])

    return data["access_token"]


def _get_github_client_id(server: str) -> str | None:
    """Fetch the GitHub client ID from the server's config endpoint."""
    try:
        with httpx.Client(timeout=10) as http:
            resp = http.get(f"{server}/auth/github/client-id")
            if resp.status_code == 200:
                return resp.json().get("client_id")
    except Exception:
        pass
    return None


@app.command()
def init(
    server: str = typer.Option(DEFAULT_SERVER, "--server", "-s", help="Custom server URL"),
    github: bool = typer.Option(False, "--github", "-g", help="Login with GitHub"),
):
    """Authenticate with HideHub and save your config."""
    client = HideHubClient(server=server)

    if not github:
        # Ask which method
        typer.echo("How would you like to sign in?")
        typer.echo("  [1] Email & password")
        typer.echo("  [2] GitHub")
        choice = typer.prompt("Choose", default="1")
        github = choice.strip() == "2"

    if github:
        token = _login_github(client, server)
    else:
        token = _login_email(client)

    # Save config
    me = client.get_me()
    save_config({"server": server, "token": token, "email": me["email"]})

    typer.echo(f"✓ Authenticated as {me['email']}")
    typer.echo("✓ Config saved to ~/.hidehub/config.json")
