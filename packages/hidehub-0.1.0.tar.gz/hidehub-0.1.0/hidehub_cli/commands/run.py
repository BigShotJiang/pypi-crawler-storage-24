"""hidehub run — Inject secrets and run a command."""

from __future__ import annotations

import getpass
import os
import subprocess
import sys

import typer

from hidehub_cli.api_client import HideHubClient, ApiError
from hidehub_cli.crypto import decrypt_secret

app = typer.Typer()


@app.command(
    context_settings={"allow_extra_args": True, "ignore_unknown_options": True},
)
def run(
    ctx: typer.Context,
    project: str = typer.Option(..., "--project", "-p", help="Project to load secrets from"),
    env_file: str = typer.Option(None, "--env-file", "-f", help="Also load local .env (merged)"),
    silent: bool = typer.Option(False, "--silent", "-s", help="Suppress HideHub output"),
):
    """Inject secrets and run a command.

    Usage: hidehub run --project my-api -- npm start
    """
    command = ctx.args
    if not command:
        typer.echo("✗ No command specified. Usage: hidehub run --project NAME -- COMMAND", err=True)
        raise typer.Exit(1)

    master_password = getpass.getpass("Master password: ")
    client = HideHubClient()

    proj = client.find_project_by_name(project)
    if not proj:
        typer.echo(f"✗ Project '{project}' not found", err=True)
        raise typer.Exit(1)

    secrets = client.list_secrets(proj["id"])

    # Build environment
    env = os.environ.copy()

    # Load local .env file first (lower priority)
    if env_file and os.path.exists(env_file):
        from hidehub_cli.env_parser import parse_env_file
        local_secrets = parse_env_file(env_file)
        env.update(local_secrets)

    # Decrypt and inject HideHub secrets (higher priority)
    loaded = 0
    for s in secrets:
        try:
            full = client.get_secret(proj["id"], s["id"])
            value = decrypt_secret(full["encrypted_blob"], master_password)
            env[s["key_name"]] = value
            loaded += 1
        except Exception as e:
            typer.echo(f"✗ Failed to decrypt {s['key_name']}: {e}", err=True)

    if not silent:
        typer.echo(f"[hidehub] Loaded {loaded} secrets for project \"{project}\"", err=True)

    # Run the command
    result = subprocess.run(command, env=env)

    if not silent:
        typer.echo("[hidehub] Cleaning up environment variables...", err=True)

    raise typer.Exit(result.returncode)
