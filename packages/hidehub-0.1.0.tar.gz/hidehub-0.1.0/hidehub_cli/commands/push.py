"""hidehub push — Encrypt and upload secrets from a .env file."""

from __future__ import annotations

import getpass
import os

import typer

from hidehub_cli.api_client import HideHubClient, ApiError
from hidehub_cli.crypto import encrypt_secret
from hidehub_cli.env_parser import parse_env_file

app = typer.Typer()


@app.command()
def push(
    env_file: str = typer.Option(".env", "--env-file", "-f", help="Path to .env file"),
    project: str = typer.Option(None, "--project", "-p", help="Project name (default: directory name)"),
    clean: bool = typer.Option(False, "--clean", help="Delete local .env after upload"),
    force: bool = typer.Option(False, "--force", help="Overwrite existing secrets"),
):
    """Encrypt and upload secrets from a .env file."""
    if not os.path.exists(env_file):
        typer.echo(f"✗ File not found: {env_file}", err=True)
        raise typer.Exit(1)

    if not project:
        project = os.path.basename(os.getcwd())

    master_password = getpass.getpass("Master password: ")

    secrets = parse_env_file(env_file)
    if not secrets:
        typer.echo("✗ No valid key=value pairs found", err=True)
        raise typer.Exit(1)

    typer.echo(f"✓ Read {len(secrets)} secrets from {env_file}")

    # Encrypt each secret
    encrypted = []
    for key, value in secrets.items():
        encrypted.append({
            "key_name": key,
            "encrypted_blob": encrypt_secret(value, master_password),
        })
    typer.echo("✓ Encrypted with AES-256-GCM")

    client = HideHubClient()

    # Find or create project
    proj = client.find_project_by_name(project)
    if not proj:
        try:
            proj = client.create_project(project)
            typer.echo(f"✓ Created project \"{project}\"")
        except ApiError as e:
            typer.echo(f"✗ Failed to create project: {e.detail}", err=True)
            raise typer.Exit(1)

    # Bulk push
    try:
        result = client.bulk_push(proj["id"], encrypted, force=force)
        typer.echo(
            f"✓ Uploaded to project \"{project}\" "
            f"({result['created']} new, {result['updated']} updated)"
        )
    except ApiError as e:
        typer.echo(f"✗ Upload failed: {e.detail}", err=True)
        raise typer.Exit(1)

    if clean:
        os.remove(env_file)
        typer.echo(f"✓ Local file deleted (--clean)")
