"""hidehub list — View projects and secrets."""

from __future__ import annotations

import getpass

import typer

from hidehub_cli.api_client import HideHubClient, ApiError
from hidehub_cli.crypto import decrypt_secret

app = typer.Typer()


@app.command("list")
def list_cmd(
    project: str = typer.Option(None, "--project", "-p", help="Show secrets for a specific project"),
    show_values: bool = typer.Option(False, "--show-values", help="Display decrypted values"),
):
    """View projects and their secrets."""
    client = HideHubClient()

    if not project:
        # List projects
        projects = client.list_projects()
        if not projects:
            typer.echo("No projects found. Run `hidehub push` to create one.")
            return

        typer.echo(f"{'PROJECT':<25} {'SECRETS':>8}   {'LAST UPDATED'}")
        typer.echo("-" * 55)
        for p in projects:
            updated = p["updated_at"][:10] if p.get("updated_at") else "—"
            typer.echo(f"{p['name']:<25} {p['secret_count']:>8}   {updated}")
        return

    # List secrets for a project
    proj = client.find_project_by_name(project)
    if not proj:
        typer.echo(f"✗ Project '{project}' not found", err=True)
        raise typer.Exit(1)

    secrets = client.list_secrets(proj["id"])
    if not secrets:
        typer.echo(f"No secrets in project '{project}'.")
        return

    master_password = None
    if show_values:
        master_password = getpass.getpass("Master password: ")

    typer.echo(f"\nProject: {project} ({len(secrets)} secrets)")
    typer.echo("-" * 60)

    if show_values:
        typer.echo(f"{'KEY':<30} {'VALUE':<25} {'VERSION'}")
        for s in secrets:
            try:
                full = client.get_secret(proj["id"], s["id"])
                value = decrypt_secret(full["encrypted_blob"], master_password)
                # Truncate long values
                display = value[:22] + "..." if len(value) > 25 else value
                typer.echo(f"{s['key_name']:<30} {display:<25} v{s['version']}")
            except Exception:
                typer.echo(f"{s['key_name']:<30} {'<decrypt failed>':<25} v{s['version']}")
    else:
        typer.echo(f"{'KEY':<30} {'VERSION':>8}   {'UPDATED'}")
        for s in secrets:
            updated = s["updated_at"][:10] if s.get("updated_at") else "—"
            typer.echo(f"{s['key_name']:<30} {'v' + str(s['version']):>8}   {updated}")
