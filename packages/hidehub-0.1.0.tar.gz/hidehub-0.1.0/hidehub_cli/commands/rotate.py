"""hidehub rotate — Update a secret's value with version history."""

from __future__ import annotations

import getpass

import typer

from hidehub_cli.api_client import HideHubClient, ApiError
from hidehub_cli.crypto import encrypt_secret

app = typer.Typer()


@app.command()
def rotate(
    key_name: str = typer.Argument(help="Name of the secret to rotate"),
    project: str = typer.Option(..., "--project", "-p", help="Project containing the secret"),
    value: str = typer.Option(None, "--value", "-v", help="New value (prompted if omitted)"),
    keep_history: bool = typer.Option(True, "--keep-history/--no-history", help="Keep old value in version history"),
):
    """Rotate a secret to a new value."""
    master_password = getpass.getpass("Master password: ")

    if not value:
        value = getpass.getpass(f"Enter new value for {key_name}: ")
        if not value:
            typer.echo("✗ Value cannot be empty", err=True)
            raise typer.Exit(1)

    client = HideHubClient()

    proj = client.find_project_by_name(project)
    if not proj:
        typer.echo(f"✗ Project '{project}' not found", err=True)
        raise typer.Exit(1)

    # Find secret by key name
    secrets = client.list_secrets(proj["id"])
    secret = next((s for s in secrets if s["key_name"] == key_name), None)
    if not secret:
        typer.echo(f"✗ Key '{key_name}' not found in project '{project}'", err=True)
        raise typer.Exit(1)

    encrypted = encrypt_secret(value, master_password)

    try:
        result = client.update_secret(proj["id"], secret["id"], encrypted, keep_history)
        typer.echo(f"✓ Rotated {key_name}")
        if keep_history:
            typer.echo(f"✓ Previous value saved (version {result['version'] - 1})")
    except ApiError as e:
        typer.echo(f"✗ Rotation failed: {e.detail}", err=True)
        raise typer.Exit(1)
