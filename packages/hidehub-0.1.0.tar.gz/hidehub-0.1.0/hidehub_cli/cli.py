"""HideHub CLI — Secure secret management from the command line."""

import typer

from hidehub_cli import __version__
from hidehub_cli.commands.init import init
from hidehub_cli.commands.push import push
from hidehub_cli.commands.use import use
from hidehub_cli.commands.run import run
from hidehub_cli.commands.list import list_cmd
from hidehub_cli.commands.rotate import rotate

app = typer.Typer(
    name="hidehub",
    help="Secure secret management for developers. Never commit an API key again.",
    no_args_is_help=True,
)

app.command("init")(init)
app.command("push")(push)
app.command("use")(use)
app.command("run")(run)
app.command("list")(list_cmd)
app.command("rotate")(rotate)


def version_callback(value: bool):
    if value:
        typer.echo(f"hidehub-cli {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None, "--version", "-V", callback=version_callback, is_eager=True, help="Show version"
    ),
):
    """HideHub — Your secrets, your keys."""
