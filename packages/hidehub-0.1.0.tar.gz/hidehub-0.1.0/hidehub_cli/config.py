"""Manages ~/.hidehub/config.json for auth and server settings."""

import json
import os
from pathlib import Path

CONFIG_DIR = Path.home() / ".hidehub"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_SERVER = "https://hidehub.com/api"


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    if not CONFIG_FILE.exists():
        return {}
    return json.loads(CONFIG_FILE.read_text())


def save_config(config: dict) -> None:
    _ensure_dir()
    CONFIG_FILE.write_text(json.dumps(config, indent=2) + "\n")
    # Restrict permissions
    os.chmod(CONFIG_FILE, 0o600)


def get_server() -> str:
    return load_config().get("server", DEFAULT_SERVER)


def get_token() -> str | None:
    return load_config().get("token")


def get_api_key() -> str | None:
    """Check HIDEHUB_API_KEY env var for headless/CI auth."""
    return os.environ.get("HIDEHUB_API_KEY")
