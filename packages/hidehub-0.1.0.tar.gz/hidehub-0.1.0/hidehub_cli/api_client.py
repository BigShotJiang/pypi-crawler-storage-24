"""HTTP client for HideHub API."""

from __future__ import annotations

import httpx

from hidehub_cli.config import get_server, get_token, get_api_key


class ApiError(Exception):
    def __init__(self, status: int, detail: str):
        self.status = status
        self.detail = detail
        super().__init__(detail)


class HideHubClient:
    def __init__(self, server: str | None = None, token: str | None = None):
        self.server = server or get_server()
        self.token = token or get_token()
        self.api_key = get_api_key()

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            headers["X-API-Key"] = self.api_key
        elif self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    def _request(self, method: str, path: str, **kwargs) -> dict:
        url = f"{self.server}{path}"
        with httpx.Client(timeout=30) as client:
            resp = client.request(method, url, headers=self._headers(), **kwargs)
        if not resp.is_success:
            detail = resp.text
            try:
                body = resp.json()
                detail = body.get("detail", detail)
            except Exception:
                pass
            raise ApiError(resp.status_code, detail)
        if resp.status_code == 204:
            return {}
        return resp.json()

    # Auth
    def login(self, email: str, password: str) -> dict:
        """Returns full login response (may include requires_2fa)."""
        data = self._request("POST", "/auth/login", json={"email": email, "password": password})
        if data.get("access_token"):
            self.token = data["access_token"]
        return data

    def verify_2fa(self, two_fa_token: str, code: str) -> str:
        data = self._request(
            "POST", "/auth/2fa/verify",
            json={"two_fa_token": two_fa_token, "code": code},
        )
        self.token = data["access_token"]
        return data["access_token"]

    def exchange_github_token(self, github_access_token: str) -> dict:
        """Exchange a GitHub access token for a HideHub JWT."""
        data = self._request(
            "POST", "/auth/github/token",
            json={"github_access_token": github_access_token},
        )
        if data.get("access_token"):
            self.token = data["access_token"]
        return data

    def get_me(self) -> dict:
        return self._request("GET", "/auth/me")

    # Projects
    def list_projects(self) -> list[dict]:
        return self._request("GET", "/projects")["items"]

    def create_project(self, name: str) -> dict:
        return self._request("POST", "/projects", json={"name": name})

    def get_project(self, project_id: str) -> dict:
        return self._request("GET", f"/projects/{project_id}")

    def find_project_by_name(self, name: str) -> dict | None:
        projects = self.list_projects()
        for p in projects:
            if p["name"] == name:
                return p
        return None

    # Secrets
    def list_secrets(self, project_id: str) -> list[dict]:
        return self._request("GET", f"/projects/{project_id}/secrets")["items"]

    def get_secret(self, project_id: str, secret_id: str) -> dict:
        return self._request("GET", f"/projects/{project_id}/secrets/{secret_id}")

    def bulk_push(self, project_id: str, secrets: list[dict], force: bool = False) -> dict:
        return self._request(
            "POST",
            f"/projects/{project_id}/secrets/bulk",
            json={"secrets": secrets, "force": force},
        )

    def update_secret(
        self, project_id: str, secret_id: str, encrypted_blob: str, keep_history: bool = True
    ) -> dict:
        return self._request(
            "PUT",
            f"/projects/{project_id}/secrets/{secret_id}",
            json={"encrypted_blob": encrypted_blob, "keep_history": keep_history},
        )
