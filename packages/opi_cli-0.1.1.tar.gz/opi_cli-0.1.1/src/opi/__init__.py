"""OPI — Open Prompt Initiative."""

__version__ = "0.1.0"
