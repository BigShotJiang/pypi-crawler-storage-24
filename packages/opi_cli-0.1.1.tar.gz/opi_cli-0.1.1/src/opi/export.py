"""Export sessions to publishable JSON and generate README with badges."""

from __future__ import annotations

import re
from pathlib import Path

from opi.models import PromptSession
from opi.redact.engine import RedactionEngine


def _slugify(text: str, max_len: int = 50) -> str:
    """Convert text to a filename-safe slug."""
    slug = re.sub(r"[^\w\s-]", "", text.lower())
    slug = re.sub(r"[\s_]+", "-", slug).strip("-")
    return slug[:max_len]


def _session_filename(session: PromptSession) -> str:
    """Generate a filename from session metadata."""
    date_prefix = session.timestamp[:10] if session.timestamp else "unknown"
    # Use first user message as title hint
    title = "session"
    for turn in session.turns:
        if turn.role == "user" and turn.content.strip():
            title = _slugify(turn.content[:60])
            break
    short_id = session.id[:8]
    return f"{date_prefix}_{title}_{short_id}"


def _format_tokens(n: int) -> str:
    """Format a token count as human-readable (e.g., 1.2M, 450K)."""
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f}M"
    if n >= 1_000:
        return f"{n / 1_000:.1f}K"
    return str(n)


def export_session_json(session: PromptSession) -> str:
    """Render a session as formatted JSON."""
    return session.to_json(indent=2)


def export_sessions(
    sessions: list[PromptSession],
    out_dir: Path,
    redact: bool = True,
    engine: RedactionEngine | None = None,
) -> list[Path]:
    """Export sessions as JSON to a directory.

    Returns the list of paths written.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    if redact and engine is None:
        engine = RedactionEngine()

    for session in sessions:
        if redact and engine:
            session, _ = engine.redact_session(session)

        source_dir = out_dir / session.source
        source_dir.mkdir(exist_ok=True)

        filename = _session_filename(session)
        path = source_dir / f"{filename}.json"
        path.write_text(export_session_json(session), encoding="utf-8")
        written.append(path)

    return written


def generate_readme_from_files(out_dir: Path) -> Path:
    """Scan ``out_dir/**/*.json``, aggregate tokens, and write README.md.

    The README contains shields.io badges (one per model) followed by a
    session-index table.  Because it reads *all* JSON files in the tree,
    it naturally aggregates data from every user who has exported into the
    same ``opi-prompts/`` directory.
    """
    json_files = sorted(out_dir.rglob("*.json"))

    sessions: list[PromptSession] = []
    for jf in json_files:
        try:
            sessions.append(PromptSession.from_json_file(jf))
        except Exception:
            continue  # skip malformed files

    # --- badges: aggregate tokens per model ---
    totals: dict[str, dict[str, int]] = {}
    for s in sessions:
        if not s.model:
            continue
        if s.model not in totals:
            totals[s.model] = {"input": 0, "output": 0}
        for turn in s.turns:
            totals[s.model]["input"] += turn.input_tokens
            totals[s.model]["output"] += turn.output_tokens

    lines: list[str] = ["# OPI Prompts", ""]

    if totals:
        for model, counts in sorted(totals.items()):
            label = model.replace("-", "--")
            if counts["input"] > 0:
                in_str = _format_tokens(counts["input"])
                out_str = _format_tokens(counts["output"])
                message = f"{in_str}_in_|_{out_str}_out"
            else:
                total_str = _format_tokens(counts["output"])
                message = f"{total_str}_total"
            badge_url = f"https://img.shields.io/badge/{label}-{message}-blue"
            lines.append(f"![{model}]({badge_url})")
        lines.append("")

    # --- session index table ---
    if sessions:
        lines.append(f"Total sessions: {len(sessions)}")
        lines.append("")

        by_source: dict[str, list[PromptSession]] = {}
        for s in sessions:
            by_source.setdefault(s.source, []).append(s)

        for source, source_sessions in sorted(by_source.items()):
            lines.append(f"## {source}")
            lines.append("")
            lines.append("| Date | Model | First Prompt |")
            lines.append("|------|-------|-------------|")
            for s in sorted(source_sessions, key=lambda x: x.timestamp, reverse=True):
                date = s.timestamp[:10] if s.timestamp else "?"
                model = s.model or ""
                prompt = ""
                for t in s.turns:
                    if t.role == "user" and t.content.strip():
                        prompt = t.content[:80].replace("\n", " ").replace("|", "\\|")
                        break
                filename = _session_filename(s)
                lines.append(f"| {date} | {model} | [{prompt}]({source}/{filename}.json) |")
            lines.append("")

    lines.append("---")
    lines.append("*Generated by [OPI](https://github.com/kpister/opi)*")

    readme_path = out_dir / "README.md"
    readme_path.write_text("\n".join(lines), encoding="utf-8")
    return readme_path


_BADGE_START = "<!-- opi-badges-start -->"
_BADGE_END = "<!-- opi-badges-end -->"


def _build_badge_lines(out_dir: Path) -> list[str]:
    """Build badge markdown lines from all JSON files in *out_dir*."""
    json_files = sorted(out_dir.rglob("*.json"))

    totals: dict[str, dict[str, int]] = {}
    for jf in json_files:
        try:
            s = PromptSession.from_json_file(jf)
        except Exception:
            continue
        if not s.model:
            continue
        if s.model not in totals:
            totals[s.model] = {"input": 0, "output": 0}
        for turn in s.turns:
            totals[s.model]["input"] += turn.input_tokens
            totals[s.model]["output"] += turn.output_tokens

    if not totals:
        return []

    badges: list[str] = []
    for model, counts in sorted(totals.items()):
        label = model.replace("-", "--")
        if counts["input"] > 0:
            in_str = _format_tokens(counts["input"])
            out_str = _format_tokens(counts["output"])
            message = f"{in_str}_in_|_{out_str}_out"
        else:
            total_str = _format_tokens(counts["output"])
            message = f"{total_str}_total"
        badge_url = f"https://img.shields.io/badge/{label}-{message}-blue"
        badges.append(f"![{model}]({badge_url})")
    return badges


def inject_badges_into_readme(root: Path, out_dir: Path) -> bool:
    """Inject/update OPI badge block in the project's root README.md.

    Uses marker comments so re-runs replace the previous block rather
    than appending duplicates.  Returns True if the file was modified.
    """
    badges = _build_badge_lines(out_dir)
    if not badges:
        return False

    badge_block = (
        _BADGE_START + "\n" + "\n".join(badges) + "\n" + _BADGE_END
    )

    readme_path = root / "README.md"
    if readme_path.exists():
        content = readme_path.read_text(encoding="utf-8")
        if _BADGE_START in content and _BADGE_END in content:
            # Replace existing block
            pattern = re.compile(
                re.escape(_BADGE_START) + r".*?" + re.escape(_BADGE_END),
                re.DOTALL,
            )
            new_content = pattern.sub(badge_block, content)
        else:
            # Prepend badge block before existing content
            new_content = badge_block + "\n\n" + content
        readme_path.write_text(new_content, encoding="utf-8")
    else:
        readme_path.write_text(badge_block + "\n", encoding="utf-8")

    return True
