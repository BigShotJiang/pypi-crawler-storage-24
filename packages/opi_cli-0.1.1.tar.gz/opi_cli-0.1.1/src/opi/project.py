"""Project root detection utilities."""

from __future__ import annotations

import subprocess
from pathlib import Path


def detect_project_root() -> Path:
    """Detect the current project root via git, falling back to CWD."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return Path(result.stdout.strip())
    except (OSError, subprocess.TimeoutExpired):
        pass
    return Path.cwd()


def is_git_repo(path: Path) -> bool:
    """Check whether *path* is the root of a git repository."""
    return (path / ".git").exists()


def path_to_dash_format(path: Path) -> str:
    """Convert a path to Claude Code's dash-separated directory format.

    e.g. /Users/x/proj → -Users-x-proj
    """
    return str(path).replace("/", "-")
