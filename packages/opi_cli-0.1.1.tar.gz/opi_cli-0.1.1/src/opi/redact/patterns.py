"""Regex pattern library for redaction."""

from __future__ import annotations

import re

# API Keys & Secrets
API_KEY_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("API_KEY", re.compile(r"sk-[a-zA-Z0-9_-]{20,}")),  # OpenAI / Anthropic
    ("API_KEY", re.compile(r"sk-ant-[a-zA-Z0-9_-]{20,}")),  # Anthropic
    ("GITHUB_TOKEN", re.compile(r"ghp_[a-zA-Z0-9]{36,}")),  # GitHub PAT
    ("GITHUB_TOKEN", re.compile(r"gho_[a-zA-Z0-9]{36,}")),  # GitHub OAuth
    ("GITHUB_TOKEN", re.compile(r"github_pat_[a-zA-Z0-9_]{22,}")),  # GitHub fine-grained
    ("AWS_KEY", re.compile(r"AKIA[0-9A-Z]{16}")),  # AWS Access Key
    ("AWS_SECRET", re.compile(r"(?<=AWS_SECRET_ACCESS_KEY[=: \"'])[A-Za-z0-9/+=]{40}")),
    ("BEARER_TOKEN", re.compile(r"Bearer\s+[a-zA-Z0-9._\-]{20,}")),
    ("PRIVATE_KEY", re.compile(r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----[\s\S]*?-----END (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----")),
    ("GENERIC_SECRET", re.compile(r"(?i)(?:api[_-]?key|secret|token|password|passwd|pwd)\s*[:=]\s*['\"]?([a-zA-Z0-9_\-./+=]{16,})['\"]?")),
    ("NPM_TOKEN", re.compile(r"npm_[a-zA-Z0-9]{36}")),
    ("SLACK_TOKEN", re.compile(r"xox[bpors]-[a-zA-Z0-9-]{10,}")),
    ("STRIPE_KEY", re.compile(r"[sr]k_(?:live|test)_[a-zA-Z0-9]{20,}")),
]

# PII patterns
PII_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("EMAIL", re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")),
    ("PHONE", re.compile(r"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}")),
    ("SSN", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    ("IP_ADDRESS", re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")),
]

# File path patterns — match absolute paths with home directories
FILE_PATH_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("PATH", re.compile(r"/(?:Users|home)/[a-zA-Z0-9._-]+(?:/[^\s:;,\"'`\]}>)]+)+")),
    ("WINDOWS_PATH", re.compile(r"[A-Z]:\\Users\\[a-zA-Z0-9._-]+(?:\\[^\s:;,\"'`\]}>)]+)+")),
]

# URL patterns — match URLs with embedded credentials
URL_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("CREDENTIAL_URL", re.compile(r"(?:https?|ftp|postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis|amqp)://[^\s:]+:[^\s@]+@[^\s]+")),
]
