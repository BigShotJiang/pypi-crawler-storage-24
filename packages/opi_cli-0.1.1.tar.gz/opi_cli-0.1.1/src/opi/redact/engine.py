"""RedactionEngine — orchestrates redaction rules over sessions."""

from __future__ import annotations

import copy
from dataclasses import dataclass, field

from opi.config import OpiConfig
from opi.models import PromptSession, Turn
from opi.redact.rules import (
    SECRETS_RULE,
    PII_RULE,
    FILE_PATHS_RULE,
    URLS_RULE,
    CustomPatternRule,
    OrgTermRule,
    RedactionMatch,
    RedactionRule,
    RegexRedactionRule,
)


@dataclass
class RedactionReport:
    """Summary of redactions applied to a session."""

    session_id: str
    total_redactions: int = 0
    by_category: dict[str, int] = field(default_factory=dict)
    matches: list[RedactionMatch] = field(default_factory=list)


class RedactionEngine:
    """Runs a pipeline of RedactionRule objects over session text."""

    def __init__(self, config: OpiConfig | None = None):
        self.rules: list[RedactionRule] = []
        self._build_rules(config or OpiConfig())

    def _build_rules(self, config: OpiConfig) -> None:
        rc = config.redact

        if rc.secrets:
            self.rules.append(SECRETS_RULE)
        if rc.pii:
            self.rules.append(PII_RULE)
        if rc.file_paths:
            self.rules.append(FILE_PATHS_RULE)
        if rc.urls:
            self.rules.append(URLS_RULE)

        if rc.org_terms:
            self.rules.append(OrgTermRule(rc.org_terms))

        for cp in rc.custom_patterns:
            self.rules.append(
                CustomPatternRule(
                    name=cp.get("name", "custom"),
                    pattern=cp["pattern"],
                    replacement=cp.get("replacement", "[REDACTED]"),
                )
            )

    def redact_text(self, text: str) -> tuple[str, list[RedactionMatch]]:
        """Apply all rules to text. Returns (redacted_text, matches)."""
        all_matches: list[RedactionMatch] = []
        for rule in self.rules:
            all_matches.extend(rule.find_matches(text))

        if not all_matches:
            return text, []

        # Sort by start ascending, then by span length descending (prefer longer matches)
        all_matches.sort(key=lambda m: (m.start, -(m.end - m.start)))

        # Remove overlapping matches — keep the longer/earlier match
        filtered: list[RedactionMatch] = []
        current_end = 0
        for match in all_matches:
            if match.start >= current_end:
                filtered.append(match)
                current_end = match.end

        # Apply replacements from end to start
        result = text
        for match in reversed(filtered):
            result = result[: match.start] + match.replacement + result[match.end :]

        return result, filtered

    def redact_session(
        self, session: PromptSession, dry_run: bool = False
    ) -> tuple[PromptSession, RedactionReport]:
        """Redact a session. Returns a new session and a report."""
        # Reset counters on regex rules
        for rule in self.rules:
            if isinstance(rule, RegexRedactionRule):
                rule.reset_counters()

        report = RedactionReport(session_id=session.id)
        redacted = copy.deepcopy(session)

        for turn in redacted.turns:
            redacted_text, matches = self.redact_text(turn.content)
            if not dry_run:
                turn.content = redacted_text
            report.total_redactions += len(matches)
            report.matches.extend(matches)
            for m in matches:
                report.by_category[m.category] = (
                    report.by_category.get(m.category, 0) + 1
                )

        # Redact project name too
        if redacted.project:
            redacted_project, proj_matches = self.redact_text(redacted.project)
            if not dry_run:
                redacted.project = redacted_project
            report.total_redactions += len(proj_matches)
            report.matches.extend(proj_matches)

        return redacted, report
