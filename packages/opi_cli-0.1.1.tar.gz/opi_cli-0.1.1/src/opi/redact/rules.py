"""Built-in redaction rule definitions."""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass

from opi.redact.patterns import (
    API_KEY_PATTERNS,
    FILE_PATH_PATTERNS,
    PII_PATTERNS,
    URL_PATTERNS,
)


@dataclass
class RedactionMatch:
    """A single redaction match within text."""

    start: int
    end: int
    original: str
    replacement: str
    category: str


class RedactionRule(ABC):
    """Base class for redaction rules."""

    name: str
    category: str

    @abstractmethod
    def find_matches(self, text: str) -> list[RedactionMatch]:
        """Find all matches in the given text."""


class RegexRedactionRule(RedactionRule):
    """Redaction rule based on regex patterns."""

    def __init__(
        self,
        name: str,
        category: str,
        patterns: list[tuple[str, re.Pattern]],
    ):
        self.name = name
        self.category = category
        self.patterns = patterns
        self._counters: dict[str, int] = {}

    def find_matches(self, text: str) -> list[RedactionMatch]:
        matches = []
        for label, pattern in self.patterns:
            for m in pattern.finditer(text):
                count = self._counters.get(label, 0) + 1
                self._counters[label] = count
                matches.append(
                    RedactionMatch(
                        start=m.start(),
                        end=m.end(),
                        original=m.group(),
                        replacement=f"[REDACTED_{label}_{count}]",
                        category=self.category,
                    )
                )
        return matches

    def reset_counters(self) -> None:
        self._counters.clear()


class OrgTermRule(RedactionRule):
    """Redact organization-specific terms."""

    name = "org_terms"
    category = "org"

    def __init__(self, terms: list[str]):
        self.terms = terms
        self._counter = 0

    def find_matches(self, text: str) -> list[RedactionMatch]:
        matches = []
        for term in self.terms:
            for m in re.finditer(re.escape(term), text, re.IGNORECASE):
                self._counter += 1
                matches.append(
                    RedactionMatch(
                        start=m.start(),
                        end=m.end(),
                        original=m.group(),
                        replacement=f"[REDACTED_ORG_{self._counter}]",
                        category=self.category,
                    )
                )
        return matches


class CustomPatternRule(RedactionRule):
    """User-defined regex pattern from config."""

    category = "custom"

    def __init__(self, name: str, pattern: str, replacement: str):
        self.name = name
        self._pattern = re.compile(pattern)
        self._replacement = replacement

    def find_matches(self, text: str) -> list[RedactionMatch]:
        matches = []
        for m in self._pattern.finditer(text):
            matches.append(
                RedactionMatch(
                    start=m.start(),
                    end=m.end(),
                    original=m.group(),
                    replacement=self._replacement,
                    category=self.category,
                )
            )
        return matches


# Pre-built rule instances
SECRETS_RULE = RegexRedactionRule("secrets", "secrets", API_KEY_PATTERNS)
PII_RULE = RegexRedactionRule("pii", "pii", PII_PATTERNS)
FILE_PATHS_RULE = RegexRedactionRule("file_paths", "paths", FILE_PATH_PATTERNS)
URLS_RULE = RegexRedactionRule("urls", "urls", URL_PATTERNS)
