"""Session storage on disk + SQLite FTS5 index."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from opi.config import OPI_DIR, ensure_opi_dir
from opi.models import PromptSession

DB_PATH = OPI_DIR / "index.db"


def _get_db(db_path: Path | None = None) -> sqlite3.Connection:
    db_path = db_path or DB_PATH
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_path))
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute(
        """
        CREATE VIRTUAL TABLE IF NOT EXISTS sessions_fts USING fts5(
            session_id, source, project, model, timestamp, content
        )
        """
    )
    conn.commit()
    return conn


def _session_dir(source: str, opi_dir: Path | None = None) -> Path:
    base = (opi_dir or OPI_DIR) / "sessions" / source
    base.mkdir(parents=True, exist_ok=True)
    return base


def save_session(
    session: PromptSession,
    opi_dir: Path | None = None,
    db_path: Path | None = None,
) -> Path:
    """Save a session to disk and index it in SQLite FTS5."""
    opi_dir = opi_dir or OPI_DIR
    ensure_opi_dir()

    # Write JSON file
    dest = _session_dir(session.source, opi_dir) / f"{session.id}.json"
    dest.write_text(session.to_json(indent=2), encoding="utf-8")

    # Index in FTS5
    content = "\n".join(t.content for t in session.turns)
    conn = _get_db(db_path)
    try:
        # Remove old entry if re-extracting
        conn.execute(
            "DELETE FROM sessions_fts WHERE session_id = ?", (session.id,)
        )
        conn.execute(
            """
            INSERT INTO sessions_fts (session_id, source, project, model, timestamp, content)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                session.id,
                session.source,
                session.project or "",
                session.model or "",
                session.timestamp,
                content,
            ),
        )
        conn.commit()
    finally:
        conn.close()

    return dest


def list_sessions(
    source: str | None = None,
    since: str | None = None,
    limit: int | None = None,
    project: str | None = None,
    project_path: Path | None = None,
    db_path: Path | None = None,
) -> list[dict]:
    """List sessions from the FTS5 index."""
    conn = _get_db(db_path)
    try:
        clauses = []
        params: list = []
        if source:
            clauses.append("source = ?")
            params.append(source)
        if since:
            clauses.append("timestamp >= ?")
            params.append(since)
        if project:
            clauses.append("project LIKE ?")
            params.append(f"%{project}%")
        if project_path:
            # Match both slash-format (/Users/x/proj) and dash-format (-Users-x-proj)
            slash = str(project_path)
            dash = slash.replace("/", "-")
            clauses.append("(project LIKE ? OR project LIKE ?)")
            params.append(f"%{slash}%")
            params.append(f"%{dash}%")

        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        order = "ORDER BY timestamp DESC"
        limit_clause = f"LIMIT {limit}" if limit else ""

        rows = conn.execute(
            f"SELECT session_id, source, project, model, timestamp FROM sessions_fts {where} {order} {limit_clause}",
            params,
        ).fetchall()

        return [
            {
                "session_id": r[0],
                "source": r[1],
                "project": r[2],
                "model": r[3],
                "timestamp": r[4],
            }
            for r in rows
        ]
    finally:
        conn.close()


def load_session(
    session_id: str,
    source: str | None = None,
    opi_dir: Path | None = None,
    db_path: Path | None = None,
) -> PromptSession | None:
    """Load a session from disk by ID."""
    opi_dir = opi_dir or OPI_DIR

    # If source is known, look directly
    if source:
        path = _session_dir(source, opi_dir) / f"{session_id}.json"
        if path.exists():
            return PromptSession.from_json_file(path)
        return None

    # Otherwise search all source dirs
    sessions_dir = opi_dir / "sessions"
    if not sessions_dir.exists():
        return None
    for source_dir in sessions_dir.iterdir():
        if source_dir.is_dir():
            path = source_dir / f"{session_id}.json"
            if path.exists():
                return PromptSession.from_json_file(path)
    return None
