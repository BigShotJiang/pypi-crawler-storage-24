"""Unified prompt schema — PromptSession and Turn dataclasses."""

from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class Turn:
    role: str  # "user" | "assistant" | "tool_call" | "tool_result"
    content: str
    timestamp: str | None = None
    tool_name: str | None = None
    input_tokens: int = 0
    output_tokens: int = 0
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        # Drop None optional fields and zero token counts for cleaner JSON
        return {k: v for k, v in d.items() if v is not None and v != 0}


@dataclass
class PromptSession:
    id: str
    source: str  # "claude-code" | "codex" | "gemini-cli"
    project: str | None
    timestamp: str  # ISO 8601
    model: str | None = None
    tags: list[str] = field(default_factory=list)
    turns: list[Turn] = field(default_factory=list)

    def to_dict(self) -> dict:
        d = asdict(self)
        return {k: v for k, v in d.items() if v is not None}

    def to_json(self, **kwargs) -> str:
        return json.dumps(self.to_dict(), ensure_ascii=False, **kwargs)

    @classmethod
    def from_dict(cls, data: dict) -> PromptSession:
        turns = [Turn(**t) for t in data.pop("turns", [])]
        data.setdefault("project", None)
        data.setdefault("model", None)
        data.setdefault("tags", [])
        return cls(turns=turns, **data)

    @classmethod
    def from_json_file(cls, path: Path) -> PromptSession:
        data = json.loads(path.read_text(encoding="utf-8"))
        return cls.from_dict(data)
