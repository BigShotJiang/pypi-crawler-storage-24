"""Configuration loading from ~/.opi/config.toml."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass, field
from pathlib import Path

OPI_DIR = Path.home() / ".opi"
CONFIG_PATH = OPI_DIR / "config.toml"

DEFAULTS = {
    "redact": {
        "secrets": True,
        "pii": True,
        "file_paths": True,
        "urls": True,
        "org_terms": [],
        "custom_patterns": [],
        "sensitive_paths": [],
    },
}


@dataclass
class RedactConfig:
    secrets: bool = True
    pii: bool = True
    file_paths: bool = True
    urls: bool = True
    org_terms: list[str] = field(default_factory=list)
    custom_patterns: list[dict] = field(default_factory=list)
    sensitive_paths: list[str] = field(default_factory=list)


@dataclass
class OpiConfig:
    redact: RedactConfig = field(default_factory=RedactConfig)

    @classmethod
    def load(cls, path: Path | None = None) -> OpiConfig:
        path = path or CONFIG_PATH
        if not path.exists():
            return cls()

        with open(path, "rb") as f:
            raw = tomllib.load(f)

        redact_raw = {**DEFAULTS["redact"], **raw.get("redact", {})}
        redact = RedactConfig(
            secrets=redact_raw["secrets"],
            pii=redact_raw["pii"],
            file_paths=redact_raw["file_paths"],
            urls=redact_raw["urls"],
            org_terms=redact_raw["org_terms"],
            custom_patterns=redact_raw["custom_patterns"],
            sensitive_paths=redact_raw["sensitive_paths"],
        )
        return cls(redact=redact)


def ensure_opi_dir() -> Path:
    """Create ~/.opi/ and subdirectories if they don't exist."""
    OPI_DIR.mkdir(parents=True, exist_ok=True)
    (OPI_DIR / "sessions").mkdir(exist_ok=True)
    return OPI_DIR
