"""Extractor registry."""

from opi.extractors.base import BaseExtractor
from opi.extractors.claude_code import ClaudeCodeExtractor
from opi.extractors.codex import CodexExtractor
from opi.extractors.gemini import GeminiExtractor

EXTRACTORS: dict[str, type[BaseExtractor]] = {
    "claude-code": ClaudeCodeExtractor,
    "codex": CodexExtractor,
    "gemini-cli": GeminiExtractor,
}

__all__ = ["EXTRACTORS", "BaseExtractor"]
