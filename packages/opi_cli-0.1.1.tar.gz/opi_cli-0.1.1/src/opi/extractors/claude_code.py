"""Claude Code extractor — parses ~/.claude/projects/**/*.jsonl."""

from __future__ import annotations

import json
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path

from opi.extractors.base import BaseExtractor
from opi.models import PromptSession, Turn
from opi.project import path_to_dash_format


class ClaudeCodeExtractor(BaseExtractor):
    name = "claude-code"
    default_data_dir = Path.home() / ".claude"

    def detect(self) -> bool:
        return (self.default_data_dir / "projects").is_dir()

    def extract(
        self,
        since: datetime | None = None,
        project: str | None = None,
        project_path: Path | None = None,
    ) -> Iterator[PromptSession]:
        projects_dir = self.default_data_dir / "projects"
        if not projects_dir.exists():
            return

        # Pre-compute dash-format prefix for project_path filtering
        dash_prefix = path_to_dash_format(project_path) if project_path else None

        for project_dir in projects_dir.iterdir():
            if not project_dir.is_dir():
                continue

            # Decode project path from directory name (dashes replace slashes)
            project_name = project_dir.name

            if project and project not in project_name:
                continue

            # Filter by project_path: dir name must match or be a subdirectory
            if dash_prefix and not (
                project_name == dash_prefix
                or project_name.startswith(dash_prefix + "-")
            ):
                continue

            for jsonl_file in project_dir.glob("*.jsonl"):
                session = self._parse_session(jsonl_file, project_name, since)
                if session and session.turns:
                    yield session

    def _parse_session(
        self, path: Path, project_name: str, since: datetime | None
    ) -> PromptSession | None:
        """Parse a single JSONL session file into a PromptSession."""
        turns: list[Turn] = []
        session_id: str | None = None
        first_timestamp: str | None = None
        model: str | None = None

        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return None

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Extract session metadata from first entry
            if session_id is None:
                session_id = entry.get("sessionId", path.stem)

            ts = entry.get("timestamp")
            if first_timestamp is None and ts:
                first_timestamp = ts

            # Check since filter
            if since and ts:
                try:
                    entry_dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
                    if entry_dt < since:
                        continue
                except ValueError:
                    pass

            entry_type = entry.get("type")
            message = entry.get("message", {})
            if not isinstance(message, dict):
                continue

            msg_role = message.get("role")
            content_blocks = message.get("content")
            if content_blocks is None:
                continue

            # Extract model from assistant messages
            if msg_role == "assistant" and not model:
                model = message.get("model")

            # Extract token usage from message
            usage = message.get("usage", {})
            in_tok = usage.get("input_tokens", 0) if isinstance(usage, dict) else 0
            out_tok = usage.get("output_tokens", 0) if isinstance(usage, dict) else 0

            # Handle string content (simple user messages)
            if isinstance(content_blocks, str):
                turns.append(
                    Turn(
                        role="user" if entry_type == "user" else "assistant",
                        content=content_blocks,
                        timestamp=ts,
                        input_tokens=in_tok,
                        output_tokens=out_tok,
                    )
                )
                continue

            # Handle content block arrays
            if not isinstance(content_blocks, list):
                continue

            # Assign token counts to first turn from this entry only
            tokens_assigned = False
            for block in content_blocks:
                if not isinstance(block, dict):
                    continue
                block_type = block.get("type")

                if block_type == "text":
                    text_content = block.get("text", "")
                    if not text_content:
                        continue
                    turns.append(
                        Turn(
                            role="user" if entry_type == "user" else "assistant",
                            content=text_content,
                            timestamp=ts,
                            input_tokens=in_tok if not tokens_assigned else 0,
                            output_tokens=out_tok if not tokens_assigned else 0,
                        )
                    )
                    tokens_assigned = True

                elif block_type == "tool_use":
                    tool_name = block.get("name", "unknown")
                    tool_input = block.get("input", {})
                    turns.append(
                        Turn(
                            role="tool_call",
                            content=json.dumps(tool_input, ensure_ascii=False),
                            timestamp=ts,
                            tool_name=tool_name,
                            input_tokens=in_tok if not tokens_assigned else 0,
                            output_tokens=out_tok if not tokens_assigned else 0,
                        )
                    )
                    tokens_assigned = True

                elif block_type == "tool_result":
                    tool_content = block.get("content", "")
                    if isinstance(tool_content, list):
                        # Flatten content blocks within tool_result
                        parts = []
                        for sub in tool_content:
                            if isinstance(sub, dict) and sub.get("type") == "text":
                                parts.append(sub.get("text", ""))
                        tool_content = "\n".join(parts)
                    turns.append(
                        Turn(
                            role="tool_result",
                            content=str(tool_content),
                            timestamp=ts,
                            tool_name=block.get("tool_use_id"),
                        )
                    )

                # Skip thinking blocks and other types

        if not session_id or not turns:
            return None

        # Apply since filter to the whole session
        if since and first_timestamp:
            try:
                session_dt = datetime.fromisoformat(
                    first_timestamp.replace("Z", "+00:00")
                )
                if session_dt < since:
                    return None
            except ValueError:
                pass

        return PromptSession(
            id=session_id,
            source=self.name,
            project=project_name,
            timestamp=first_timestamp or "",
            model=model,
            turns=turns,
        )
