"""Base extractor abstract class."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path

from opi.models import PromptSession


class BaseExtractor(ABC):
    name: str
    default_data_dir: Path

    @abstractmethod
    def detect(self) -> bool:
        """Return True if this tool's data is present on disk."""

    @abstractmethod
    def extract(
        self,
        since: datetime | None = None,
        project: str | None = None,
        project_path: Path | None = None,
    ) -> Iterator[PromptSession]:
        """Yield normalized PromptSession objects."""
