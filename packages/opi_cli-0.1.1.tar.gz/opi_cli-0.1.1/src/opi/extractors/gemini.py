"""Gemini CLI extractor — parses ~/.gemini/ chat files."""

from __future__ import annotations

import json
from collections.abc import Iterator
from datetime import datetime
from pathlib import Path

from opi.extractors.base import BaseExtractor
from opi.models import PromptSession, Turn


class GeminiExtractor(BaseExtractor):
    name = "gemini-cli"
    default_data_dir = Path.home() / ".gemini"

    def detect(self) -> bool:
        return self.default_data_dir.is_dir() and (
            (self.default_data_dir / "tmp").is_dir()
            or (self.default_data_dir / "history").is_dir()
        )

    def extract(
        self,
        since: datetime | None = None,
        project: str | None = None,
        project_path: Path | None = None,
    ) -> Iterator[PromptSession]:
        # Load project name mappings
        project_map = self._load_project_map()

        # Build set of valid hashes when filtering by project_path
        valid_hashes: set[str] | None = None
        if project_path:
            valid_hashes = self._hashes_for_project_path(
                project_path, project_map
            )

        # Walk tmp/<hash>/chats/ directories for session files
        tmp_dir = self.default_data_dir / "tmp"
        if tmp_dir.is_dir():
            for hash_dir in tmp_dir.iterdir():
                if not hash_dir.is_dir():
                    continue

                chats_dir = hash_dir / "chats"
                if not chats_dir.is_dir():
                    continue

                # Filter by project_path hash set
                if valid_hashes is not None and hash_dir.name not in valid_hashes:
                    continue

                # Resolve project name from hash
                project_name = None
                for path_key, name in project_map.items():
                    if hash_dir.name in self._hash_candidates(path_key):
                        project_name = name
                        break

                if project and project_name and project not in project_name:
                    continue

                for chat_file in chats_dir.glob("session-*.json"):
                    session = self._parse_chat_file(
                        chat_file, project_name, since
                    )
                    if session and session.turns:
                        yield session

        # Also walk history/<project>/ directories
        history_dir = self.default_data_dir / "history"
        if history_dir.is_dir():
            for proj_dir in history_dir.iterdir():
                if not proj_dir.is_dir():
                    continue

                project_name = proj_dir.name
                if project and project not in project_name:
                    continue

                # Filter by project_path for history dirs (name-based match)
                if project_path:
                    proj_str = str(project_path)
                    if project_name != proj_str and not proj_str.endswith(
                        "/" + project_name
                    ):
                        continue

                for chat_file in proj_dir.glob("session-*.json"):
                    session = self._parse_chat_file(
                        chat_file, project_name, since
                    )
                    if session and session.turns:
                        yield session

    def _hashes_for_project_path(
        self, project_path: Path, project_map: dict[str, str]
    ) -> set[str]:
        """Build a set of directory hashes that match the given project path."""
        import hashlib

        result: set[str] = set()
        pp_str = str(project_path)

        # Hash the project path itself (and without trailing slash)
        for variant in (pp_str, pp_str.rstrip("/")):
            result.add(hashlib.sha256(variant.encode()).hexdigest())

        # Also include hashes of any paths in projects.json at or under project_path
        for path_key in project_map:
            if path_key == pp_str or path_key.startswith(pp_str + "/"):
                for candidate in self._hash_candidates(path_key):
                    result.add(candidate)

        return result

    def _load_project_map(self) -> dict[str, str]:
        """Load path→name mappings from projects.json."""
        projects_file = self.default_data_dir / "projects.json"
        if not projects_file.exists():
            return {}
        try:
            data = json.loads(projects_file.read_text(encoding="utf-8"))
            return data.get("projects", {})
        except (json.JSONDecodeError, OSError):
            return {}

    def _hash_candidates(self, path: str) -> list[str]:
        """Generate possible hash values for a project path."""
        # Gemini uses SHA-256 of the project path as directory name
        import hashlib

        candidates = [
            hashlib.sha256(path.encode()).hexdigest(),
            hashlib.sha256(path.rstrip("/").encode()).hexdigest(),
        ]
        return candidates

    def _parse_chat_file(
        self, path: Path, project_name: str | None, since: datetime | None
    ) -> PromptSession | None:
        """Parse a Gemini session JSON file."""
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError, UnicodeDecodeError):
            return None

        session_id = data.get("sessionId", path.stem)
        start_time = data.get("startTime", "")
        model = data.get("model")
        messages = data.get("messages", [])

        if since and start_time:
            try:
                session_dt = datetime.fromisoformat(
                    start_time.replace("Z", "+00:00")
                )
                if session_dt < since:
                    return None
            except ValueError:
                pass

        turns: list[Turn] = []
        for msg in messages:
            if not isinstance(msg, dict):
                continue

            msg_type = msg.get("type", "")
            raw_content = msg.get("content", "")
            # Content can be a string or a list of {text: ...} blocks
            if isinstance(raw_content, list):
                content = "\n".join(
                    block.get("text", "") for block in raw_content
                    if isinstance(block, dict)
                )
            else:
                content = str(raw_content)
            ts = msg.get("timestamp")

            # Extract per-message token counts
            tokens_data = msg.get("tokens", {})
            in_tok = tokens_data.get("input", 0) if isinstance(tokens_data, dict) else 0
            out_tok = tokens_data.get("output", 0) if isinstance(tokens_data, dict) else 0

            if msg_type == "user":
                turns.append(Turn(role="user", content=content, timestamp=ts, input_tokens=in_tok, output_tokens=out_tok))
            elif msg_type in ("model", "assistant"):
                turns.append(
                    Turn(role="assistant", content=content, timestamp=ts, input_tokens=in_tok, output_tokens=out_tok)
                )
            elif msg_type == "tool_call":
                turns.append(
                    Turn(
                        role="tool_call",
                        content=content,
                        timestamp=ts,
                        tool_name=msg.get("toolName"),
                        input_tokens=in_tok,
                        output_tokens=out_tok,
                    )
                )
            elif msg_type == "tool_result":
                turns.append(
                    Turn(
                        role="tool_result",
                        content=content,
                        timestamp=ts,
                        tool_name=msg.get("toolName"),
                    )
                )

        if not turns:
            return None

        return PromptSession(
            id=session_id,
            source=self.name,
            project=project_name,
            timestamp=start_time,
            model=model,
            turns=turns,
        )
