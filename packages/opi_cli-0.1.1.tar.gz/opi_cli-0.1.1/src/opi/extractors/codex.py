"""Codex CLI extractor — parses ~/.codex/ history + rollout files."""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Iterator
from datetime import datetime, timezone
from pathlib import Path

from opi.extractors.base import BaseExtractor
from opi.models import PromptSession, Turn


class CodexExtractor(BaseExtractor):
    name = "codex"
    default_data_dir = Path.home() / ".codex"

    def detect(self) -> bool:
        return (self.default_data_dir / "state_5.sqlite").exists()

    def extract(
        self,
        since: datetime | None = None,
        project: str | None = None,
        project_path: Path | None = None,
    ) -> Iterator[PromptSession]:
        db_path = self.default_data_dir / "state_5.sqlite"
        if not db_path.exists():
            return

        conn = sqlite3.connect(str(db_path))
        try:
            rows = conn.execute(
                "SELECT id, title, model_provider, created_at, cwd, rollout_path, tokens_used "
                "FROM threads ORDER BY created_at DESC"
            ).fetchall()
        finally:
            conn.close()

        project_path_str = str(project_path) if project_path else None

        for row in rows:
            thread_id, title, model_provider, created_at, cwd, rollout_path, tokens_used = row

            # Convert epoch seconds to ISO 8601
            ts = datetime.fromtimestamp(created_at, tz=timezone.utc)
            if since and ts < since:
                continue

            # Project filter
            project_name = cwd if cwd else None
            if project and project_name and project not in project_name:
                continue

            # Filter by project_path: cwd must be at or under the project root
            if project_path_str and project_name:
                if not (
                    project_name == project_path_str
                    or project_name.startswith(project_path_str + "/")
                ):
                    continue
            elif project_path_str and not project_name:
                continue

            timestamp_iso = ts.isoformat()

            # Parse the rollout file for conversation data
            turns = self._parse_rollout(Path(rollout_path)) if rollout_path else []

            # If no rollout, fall back to history.jsonl
            if not turns:
                turns = self._parse_history_for_thread(thread_id)

            if not turns:
                continue

            # Assign aggregate token count to first assistant turn
            if tokens_used:
                for turn in turns:
                    if turn.role == "assistant":
                        turn.output_tokens = tokens_used
                        break

            yield PromptSession(
                id=thread_id,
                source=self.name,
                project=project_name,
                timestamp=timestamp_iso,
                model=model_provider,
                turns=turns,
            )

    def _parse_rollout(self, path: Path) -> list[Turn]:
        """Parse a Codex rollout JSONL file."""
        if not path.exists():
            return []

        turns: list[Turn] = []
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return []

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            entry_type = entry.get("type")
            ts = entry.get("timestamp")
            payload = entry.get("payload", {})

            if entry_type == "response_item" and isinstance(payload, dict):
                role = payload.get("role")
                item_type = payload.get("type")
                content_blocks = payload.get("content", [])

                if item_type == "message" and role in ("user", "assistant"):
                    text_parts = []
                    if isinstance(content_blocks, list):
                        for block in content_blocks:
                            if isinstance(block, dict):
                                text_content = block.get("text", "")
                                if not text_content:
                                    text_content = block.get("input_text", "")
                                if text_content:
                                    text_parts.append(text_content)
                    if text_parts:
                        turns.append(
                            Turn(
                                role=role,
                                content="\n".join(text_parts),
                                timestamp=ts,
                            )
                        )

                elif item_type == "function_call":
                    func_name = payload.get("name", "unknown")
                    arguments = payload.get("arguments", "")
                    turns.append(
                        Turn(
                            role="tool_call",
                            content=arguments,
                            timestamp=ts,
                            tool_name=func_name,
                        )
                    )

                elif item_type == "function_call_output":
                    output = payload.get("output", "")
                    turns.append(
                        Turn(
                            role="tool_result",
                            content=output if isinstance(output, str) else json.dumps(output),
                            timestamp=ts,
                        )
                    )

            elif entry_type == "event_msg" and isinstance(payload, dict):
                if payload.get("type") == "user_message":
                    msg = payload.get("message", "")
                    if msg:
                        turns.append(
                            Turn(role="user", content=msg, timestamp=ts)
                        )

        return turns

    def _parse_history_for_thread(self, thread_id: str) -> list[Turn]:
        """Fall back to history.jsonl for user messages in a thread."""
        history_path = self.default_data_dir / "history.jsonl"
        if not history_path.exists():
            return []

        turns: list[Turn] = []
        try:
            text = history_path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return []

        for line in text.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            if entry.get("session_id") == thread_id:
                ts_epoch = entry.get("ts")
                ts_iso = (
                    datetime.fromtimestamp(ts_epoch, tz=timezone.utc).isoformat()
                    if ts_epoch
                    else None
                )
                text_content = entry.get("text", "")
                if text_content:
                    turns.append(
                        Turn(role="user", content=text_content, timestamp=ts_iso)
                    )

        return turns
