"""OPI CLI — init, update, config, sources."""

from __future__ import annotations

import subprocess

import click
from rich.console import Console
from rich.table import Table

from opi.config import CONFIG_PATH, ensure_opi_dir, OpiConfig
from opi.extractors import EXTRACTORS
from opi.export import export_sessions, generate_readme_from_files, inject_badges_into_readme
from opi.project import detect_project_root, is_git_repo
from opi.redact.engine import RedactionEngine
from opi.store import save_session, list_sessions, load_session

console = Console()

_PRE_COMMIT_HOOK_BLOCK = """\
- repo: local
  hooks:
    - id: opi-update
      name: OPI prompt export
      entry: opi update
      language: system
      always_run: true
      pass_filenames: false
"""


@click.group()
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose output.")
@click.option("--quiet", "-q", is_flag=True, help="Suppress non-essential output.")
@click.pass_context
def cli(ctx: click.Context, verbose: bool, quiet: bool) -> None:
    """OPI — Open Prompt Initiative. Track and share AI prompt usage."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet


# ---------------------------------------------------------------------------
# opi init
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def init(ctx: click.Context) -> None:
    """Set up OPI in the current git repository.

    Creates the ``opi-prompts/`` export directory and installs a
    pre-commit hook that runs ``opi update`` automatically.
    """
    root = detect_project_root()

    if not is_git_repo(root):
        console.print("[red]Error: not a git repository. Run 'git init' first.[/red]")
        raise SystemExit(1)

    # 1. Create opi-prompts/ directory
    prompts_dir = root / "opi-prompts"
    prompts_dir.mkdir(exist_ok=True)

    # 2. Create / update .pre-commit-config.yaml
    config_file = root / ".pre-commit-config.yaml"
    if config_file.exists():
        content = config_file.read_text(encoding="utf-8")
        if "opi-update" in content:
            if not ctx.obj.get("quiet"):
                console.print("[dim]pre-commit hook already configured — skipping[/dim]")
        else:
            content = content.rstrip("\n") + "\n" + _PRE_COMMIT_HOOK_BLOCK
            config_file.write_text(content, encoding="utf-8")
            if not ctx.obj.get("quiet"):
                console.print("[green]✓[/green] Appended OPI hook to .pre-commit-config.yaml")
    else:
        content = "repos:\n" + _PRE_COMMIT_HOOK_BLOCK
        config_file.write_text(content, encoding="utf-8")
        if not ctx.obj.get("quiet"):
            console.print("[green]✓[/green] Created .pre-commit-config.yaml with OPI hook")

    # 3. Try to install pre-commit hooks
    try:
        subprocess.run(
            ["pre-commit", "install"],
            capture_output=True,
            timeout=10,
            cwd=str(root),
        )
        if not ctx.obj.get("quiet"):
            console.print("[green]✓[/green] pre-commit hooks installed")
    except (OSError, subprocess.TimeoutExpired):
        if not ctx.obj.get("quiet"):
            console.print(
                "[yellow]pre-commit not found.[/yellow] Install it with:\n"
                "  pip install pre-commit && pre-commit install"
            )

    console.print(
        f"\n[bold]OPI initialized.[/bold]\n"
        f"  Export dir: {prompts_dir}\n"
        f"  Hook:       opi update (pre-commit)"
    )


# ---------------------------------------------------------------------------
# opi update
# ---------------------------------------------------------------------------


@cli.command()
@click.pass_context
def update(ctx: click.Context) -> None:
    """Run the full OPI pipeline: extract → redact → export → README.

    Extracts sessions for the current project, redacts sensitive data,
    exports JSON to ``opi-prompts/``, and regenerates the README with
    shields.io badges aggregated from *all* users' exports.
    """
    root = detect_project_root()

    if not is_git_repo(root):
        console.print("[red]Error: not a git repository.[/red]")
        raise SystemExit(1)

    ensure_opi_dir()

    # 1. Extract sessions for the current project
    total_extracted = 0
    for name, extractor_cls in EXTRACTORS.items():
        extractor = extractor_cls()
        if not extractor.detect():
            continue
        count = 0
        for session in extractor.extract(project_path=root):
            save_session(session)
            count += 1
        if not ctx.obj.get("quiet") and count:
            console.print(f"[green]✓[/green] {name}: extracted {count} sessions")
        total_extracted += count

    # 2. Load sessions back & apply redaction
    entries = list_sessions(project_path=root)
    sessions = []
    for entry in entries:
        session = load_session(entry["session_id"], source=entry["source"])
        if session:
            sessions.append(session)

    if not sessions:
        console.print("[dim]No sessions found for this project.[/dim]")
        return

    engine = RedactionEngine(OpiConfig.load())

    # 3. Export as JSON to opi-prompts/
    out_dir = root / "opi-prompts"
    written = export_sessions(sessions, out_dir, redact=True, engine=engine)

    # 4. Generate README from ALL JSON files (multi-user)
    generate_readme_from_files(out_dir)

    # 5. Inject badges into root README.md
    inject_badges_into_readme(root, out_dir)

    if not ctx.obj.get("quiet"):
        console.print(
            f"\n[bold]Updated {len(written)} sessions → {out_dir}[/bold]"
        )


# ---------------------------------------------------------------------------
# opi config  (unchanged)
# ---------------------------------------------------------------------------


@cli.command()
@click.option("--edit", is_flag=True, help="Open config in $EDITOR.")
@click.option("--show", is_flag=True, help="Print current config.")
@click.option("--set", "set_kv", nargs=2, type=str, default=None, help="Set a config value.")
def config(edit: bool, show: bool, set_kv: tuple[str, str] | None) -> None:
    """Manage OPI configuration."""
    ensure_opi_dir()

    if show or (not edit and set_kv is None):
        if CONFIG_PATH.exists():
            console.print(CONFIG_PATH.read_text(encoding="utf-8"))
        else:
            console.print(f"[dim]No config file at {CONFIG_PATH}[/dim]")
            console.print("[dim]Create one with: opi config --edit[/dim]")
        return

    if edit:
        import os

        if not CONFIG_PATH.exists():
            CONFIG_PATH.write_text(
                '[redact]\nsecrets = true\npii = true\nfile_paths = true\nurls = true\n'
                'org_terms = []\n\n# [[redact.custom_patterns]]\n# name = "example"\n'
                '# pattern = "PATTERN"\n# replacement = "[REDACTED]"\n',
                encoding="utf-8",
            )
        editor = os.environ.get("EDITOR", "vi")
        subprocess.run([editor, str(CONFIG_PATH)])
        return

    if set_kv:
        console.print(f"[yellow]Setting {set_kv[0]} = {set_kv[1]}[/yellow]")
        console.print("[dim]Note: direct --set modifies TOML in a basic way. Use --edit for complex changes.[/dim]")
        if not CONFIG_PATH.exists():
            CONFIG_PATH.write_text("", encoding="utf-8")
        content = CONFIG_PATH.read_text(encoding="utf-8")
        if "[redact]" not in content:
            content += "\n[redact]\n"
        content += f"{set_kv[0]} = {set_kv[1]}\n"
        CONFIG_PATH.write_text(content, encoding="utf-8")
        console.print("[green]✓[/green] Config updated")


# ---------------------------------------------------------------------------
# opi sources  (unchanged)
# ---------------------------------------------------------------------------


@cli.command()
def sources() -> None:
    """Show detected CLI tools and their data locations."""
    table = Table(title="Detected Sources")
    table.add_column("Source", style="cyan")
    table.add_column("Data Directory", style="white")
    table.add_column("Status", style="green")

    for name, cls in EXTRACTORS.items():
        ext = cls()
        detected = ext.detect()
        table.add_row(
            name,
            str(ext.default_data_dir),
            "[green]✓ Found[/green]" if detected else "[red]✗ Not found[/red]",
        )

    console.print(table)
