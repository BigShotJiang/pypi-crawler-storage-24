"""Tests for models.py."""

from __future__ import annotations

import json
from pathlib import Path

from opi.models import PromptSession, Turn


def test_turn_to_dict():
    turn = Turn(role="user", content="hello", timestamp="2026-03-06T12:00:00Z")
    d = turn.to_dict()
    assert d["role"] == "user"
    assert d["content"] == "hello"
    assert "tool_name" not in d  # None values stripped


def test_turn_to_dict_with_tool():
    turn = Turn(role="tool_call", content="{}", tool_name="Read")
    d = turn.to_dict()
    assert d["tool_name"] == "Read"


def test_session_to_json():
    session = PromptSession(
        id="s1", source="codex", project=None, timestamp="2026-03-06T12:00:00Z",
        turns=[Turn(role="user", content="hi")],
    )
    j = json.loads(session.to_json())
    assert j["id"] == "s1"
    assert j["source"] == "codex"
    assert "project" not in j  # None stripped
    assert len(j["turns"]) == 1


def test_session_roundtrip(tmp_path: Path):
    session = PromptSession(
        id="s2", source="claude-code", project="myproj",
        timestamp="2026-03-06T12:00:00Z", model="claude-opus-4-6",
        tags=["test"],
        turns=[
            Turn(role="user", content="hello"),
            Turn(role="assistant", content="hi there"),
        ],
    )
    path = tmp_path / "session.json"
    path.write_text(session.to_json(indent=2), encoding="utf-8")

    loaded = PromptSession.from_json_file(path)
    assert loaded.id == "s2"
    assert loaded.source == "claude-code"
    assert loaded.project == "myproj"
    assert loaded.model == "claude-opus-4-6"
    assert len(loaded.turns) == 2
    assert loaded.turns[0].role == "user"
    assert loaded.turns[0].content == "hello"


def test_session_from_dict_missing_optionals():
    data = {
        "id": "s3",
        "source": "gemini-cli",
        "timestamp": "2026-03-06T12:00:00Z",
        "turns": [{"role": "user", "content": "test"}],
    }
    session = PromptSession.from_dict(data)
    assert session.project is None
    assert session.model is None
    assert session.tags == []


def test_turn_token_fields():
    turn = Turn(role="assistant", content="hello", input_tokens=100, output_tokens=50)
    d = turn.to_dict()
    assert d["input_tokens"] == 100
    assert d["output_tokens"] == 50


def test_turn_zero_tokens_stripped():
    turn = Turn(role="user", content="hi")
    d = turn.to_dict()
    assert "input_tokens" not in d
    assert "output_tokens" not in d


def test_session_roundtrip_with_tokens(tmp_path: Path):
    session = PromptSession(
        id="s4", source="claude-code", project="proj",
        timestamp="2026-03-06T12:00:00Z", model="claude-opus-4-6",
        turns=[
            Turn(role="user", content="hello", input_tokens=10),
            Turn(role="assistant", content="hi", input_tokens=50, output_tokens=200),
        ],
    )
    path = tmp_path / "session.json"
    path.write_text(session.to_json(indent=2), encoding="utf-8")

    loaded = PromptSession.from_json_file(path)
    assert loaded.turns[0].input_tokens == 10
    assert loaded.turns[0].output_tokens == 0
    assert loaded.turns[1].input_tokens == 50
    assert loaded.turns[1].output_tokens == 200
