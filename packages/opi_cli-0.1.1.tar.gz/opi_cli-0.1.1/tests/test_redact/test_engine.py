"""Tests for redaction engine."""

from __future__ import annotations

from opi.config import OpiConfig, RedactConfig
from opi.models import PromptSession, Turn
from opi.redact.engine import RedactionEngine


def test_redact_api_keys():
    engine = RedactionEngine()
    text = "My key is sk-1234567890abcdefghij1234567890abcdefghij"
    result, matches = engine.redact_text(text)
    assert "sk-" not in result
    assert "[REDACTED_" in result
    assert len(matches) >= 1


def test_redact_email():
    engine = RedactionEngine()
    text = "Contact me at user@example.com for details"
    result, matches = engine.redact_text(text)
    assert "user@example.com" not in result
    assert "[REDACTED_EMAIL_" in result


def test_redact_file_path():
    engine = RedactionEngine()
    text = "The file is at /Users/testuser/projects/myapp/config.py"
    result, matches = engine.redact_text(text)
    assert "/Users/testuser" not in result
    assert "[REDACTED_PATH_" in result


def test_redact_github_token():
    engine = RedactionEngine()
    text = "Use ghp_abcdefghijklmnopqrstuvwxyz0123456789 for auth"
    result, matches = engine.redact_text(text)
    assert "ghp_" not in result
    assert "[REDACTED_" in result


def test_redact_credential_url():
    engine = RedactionEngine()
    text = "Database: postgres://admin:secretpass@db.example.com/mydb"
    result, matches = engine.redact_text(text)
    assert "secretpass" not in result
    assert "[REDACTED_CREDENTIAL_URL_" in result


def test_redact_session(sample_session_with_secrets: PromptSession):
    engine = RedactionEngine()
    redacted, report = engine.redact_session(sample_session_with_secrets)

    assert report.total_redactions > 0
    assert "secrets" in report.by_category or "paths" in report.by_category

    # Check the content was actually redacted
    content = redacted.turns[0].content
    assert "sk-1234567890" not in content
    assert "user@example.com" not in content
    assert "/Users/testuser" not in content


def test_redact_session_dry_run(sample_session_with_secrets: PromptSession):
    engine = RedactionEngine()
    redacted, report = engine.redact_session(sample_session_with_secrets, dry_run=True)

    # Report should have matches
    assert report.total_redactions > 0

    # But content should be unchanged
    content = redacted.turns[0].content
    assert "sk-1234567890" in content


def test_redact_org_terms():
    config = OpiConfig(
        redact=RedactConfig(
            secrets=False, pii=False, file_paths=False, urls=False,
            org_terms=["Acme Corp", "Project Falcon"],
        )
    )
    engine = RedactionEngine(config)
    text = "At Acme Corp we are working on Project Falcon"
    result, matches = engine.redact_text(text)
    assert "Acme Corp" not in result
    assert "Project Falcon" not in result
    assert len(matches) == 2


def test_redact_custom_pattern():
    config = OpiConfig(
        redact=RedactConfig(
            secrets=False, pii=False, file_paths=False, urls=False,
            custom_patterns=[
                {"name": "ticket_ids", "pattern": r"PROJ-\d{4,}", "replacement": "[REDACTED_TICKET]"},
            ],
        )
    )
    engine = RedactionEngine(config)
    text = "Working on PROJ-12345 and PROJ-6789"
    result, matches = engine.redact_text(text)
    assert "PROJ-12345" not in result
    assert "[REDACTED_TICKET]" in result


def test_no_redaction_on_clean_text():
    engine = RedactionEngine()
    text = "Just a normal message about coding"
    result, matches = engine.redact_text(text)
    assert result == text
    assert len(matches) == 0
