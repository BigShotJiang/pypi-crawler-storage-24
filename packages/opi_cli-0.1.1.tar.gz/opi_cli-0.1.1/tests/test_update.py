"""Tests for ``opi update``."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch, MagicMock

from click.testing import CliRunner

from opi.cli import cli
from opi.models import PromptSession, Turn


def _make_git_repo(path: Path) -> Path:
    (path / ".git").mkdir(parents=True, exist_ok=True)
    return path


def _fake_extractor(sessions: list[PromptSession]):
    """Return a mock extractor class that yields *sessions* on extract()."""
    ext = MagicMock()
    ext.detect.return_value = True
    ext.extract.return_value = iter(sessions)
    cls = MagicMock(return_value=ext)
    return cls


def test_update_full_pipeline(tmp_path: Path):
    repo = _make_git_repo(tmp_path / "repo")
    opi_dir = tmp_path / "opi_home"

    session = PromptSession(
        id="update-001",
        source="claude-code",
        project=str(repo),
        timestamp="2026-03-06T12:00:00Z",
        model="claude-opus-4-6",
        turns=[
            Turn(role="user", content="Hello", input_tokens=100, output_tokens=0),
            Turn(role="assistant", content="Hi there", input_tokens=0, output_tokens=50),
        ],
    )

    mock_extractors = {"claude-code": _fake_extractor([session])}

    runner = CliRunner()
    with (
        patch("opi.cli.detect_project_root", return_value=repo),
        patch("opi.cli.EXTRACTORS", mock_extractors),
        patch("opi.config.OPI_DIR", opi_dir),
        patch("opi.store.OPI_DIR", opi_dir),
        patch("opi.store.DB_PATH", opi_dir / "index.db"),
    ):
        result = runner.invoke(cli, ["update"])

    assert result.exit_code == 0, result.output

    # JSON exported
    json_files = list((repo / "opi-prompts").rglob("*.json"))
    assert len(json_files) >= 1

    # opi-prompts/README.md generated with badge
    readme = repo / "opi-prompts" / "README.md"
    assert readme.exists()
    content = readme.read_text()
    assert "img.shields.io/badge" in content
    assert "claude-opus-4-6" in content

    # Root README.md also has badges injected
    root_readme = repo / "README.md"
    assert root_readme.exists()
    root_content = root_readme.read_text()
    assert "<!-- opi-badges-start -->" in root_content
    assert "img.shields.io/badge" in root_content


def test_update_preserves_other_users_files(tmp_path: Path):
    """Another user's exported JSON is preserved and aggregated into README."""
    repo = _make_git_repo(tmp_path / "repo")
    opi_dir = tmp_path / "opi_home"
    prompts_dir = repo / "opi-prompts" / "codex"
    prompts_dir.mkdir(parents=True)

    # Pre-existing file from another user
    other_session = PromptSession(
        id="other-user-001",
        source="codex",
        project="proj",
        timestamp="2026-03-05T10:00:00Z",
        model="gpt-5",
        turns=[
            Turn(role="user", content="Other user prompt", input_tokens=50, output_tokens=0),
            Turn(role="assistant", content="Response", input_tokens=0, output_tokens=30),
        ],
    )
    other_file = prompts_dir / "other.json"
    other_file.write_text(other_session.to_json(indent=2), encoding="utf-8")

    # Current user's session
    my_session = PromptSession(
        id="my-001",
        source="claude-code",
        project=str(repo),
        timestamp="2026-03-06T12:00:00Z",
        model="claude-opus-4-6",
        turns=[
            Turn(role="user", content="My prompt", input_tokens=200, output_tokens=0),
            Turn(role="assistant", content="My response", input_tokens=0, output_tokens=100),
        ],
    )

    mock_extractors = {"claude-code": _fake_extractor([my_session])}

    runner = CliRunner()
    with (
        patch("opi.cli.detect_project_root", return_value=repo),
        patch("opi.cli.EXTRACTORS", mock_extractors),
        patch("opi.config.OPI_DIR", opi_dir),
        patch("opi.store.OPI_DIR", opi_dir),
        patch("opi.store.DB_PATH", opi_dir / "index.db"),
    ):
        result = runner.invoke(cli, ["update"])

    assert result.exit_code == 0, result.output

    # Other user's file still exists
    assert other_file.exists()

    # README aggregates both users
    readme = repo / "opi-prompts" / "README.md"
    content = readme.read_text()
    assert "gpt-5" in content or "gpt--5" in content
    assert "claude-opus-4-6" in content or "claude--opus--4--6" in content
    assert "Total sessions:" in content


def test_update_fails_outside_git_repo(tmp_path: Path):
    runner = CliRunner()
    with patch("opi.cli.detect_project_root", return_value=tmp_path):
        result = runner.invoke(cli, ["update"])
    assert result.exit_code != 0
    assert "not a git repository" in result.output.lower()
