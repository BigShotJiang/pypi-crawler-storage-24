"""Tests for export."""

from __future__ import annotations

from pathlib import Path

from opi.export import (
    export_sessions,
    generate_readme_from_files,
    inject_badges_into_readme,
    _format_tokens,
    _slugify,
)
from opi.models import PromptSession, Turn


def test_slugify():
    assert _slugify("Hello World!") == "hello-world"
    assert _slugify("This is a TEST-123") == "this-is-a-test-123"
    assert _slugify("a" * 100, max_len=10) == "a" * 10


def test_export_sessions_json(sample_session: PromptSession, tmp_path: Path):
    out_dir = tmp_path / "export"
    written = export_sessions([sample_session], out_dir, redact=False)
    assert len(written) == 1
    assert written[0].suffix == ".json"
    assert written[0].exists()


def test_export_with_redaction(tmp_path: Path):
    session = PromptSession(
        id="redact-export",
        source="claude-code",
        project="/Users/testuser/proj",
        timestamp="2026-03-06T12:00:00Z",
        turns=[
            Turn(role="user", content="Check /Users/testuser/proj/main.py"),
        ],
    )
    out_dir = tmp_path / "export"
    written = export_sessions([session], out_dir, redact=True)
    assert len(written) == 1
    content = written[0].read_text()
    assert "/Users/testuser" not in content
    assert "REDACTED" in content


def test_generate_readme_from_files(tmp_path: Path):
    """README aggregates tokens from multiple users' JSON files."""
    out_dir = tmp_path / "opi-prompts"

    # User A's session
    session_a = PromptSession(
        id="user-a-001",
        source="claude-code",
        project="proj",
        timestamp="2026-03-06T12:00:00Z",
        model="claude-opus-4-6",
        turns=[
            Turn(role="user", content="Hello", input_tokens=100, output_tokens=0),
            Turn(role="assistant", content="Hi", input_tokens=0, output_tokens=50),
        ],
    )
    # User B's session
    session_b = PromptSession(
        id="user-b-001",
        source="claude-code",
        project="proj",
        timestamp="2026-03-07T12:00:00Z",
        model="claude-opus-4-6",
        turns=[
            Turn(role="user", content="Bye", input_tokens=200, output_tokens=0),
            Turn(role="assistant", content="Cya", input_tokens=0, output_tokens=150),
        ],
    )

    # Export each user's sessions separately (simulating multi-user)
    export_sessions([session_a], out_dir, redact=False)
    export_sessions([session_b], out_dir, redact=False)

    readme_path = generate_readme_from_files(out_dir)
    assert readme_path.exists()

    content = readme_path.read_text()
    assert "OPI Prompts" in content
    assert "claude-opus-4-6" in content
    # Should aggregate: 300 input, 200 output
    assert "img.shields.io/badge" in content
    assert "Total sessions: 2" in content


def test_generate_readme_badges_format():
    assert _format_tokens(500) == "500"
    assert _format_tokens(1_500) == "1.5K"
    assert _format_tokens(2_500_000) == "2.5M"


def test_inject_badges_creates_readme(tmp_path: Path):
    """Injects badges into a new root README when none exists."""
    root = tmp_path / "repo"
    root.mkdir()
    out_dir = root / "opi-prompts"

    session = PromptSession(
        id="badge-001",
        source="claude-code",
        project="proj",
        timestamp="2026-03-06T12:00:00Z",
        model="claude-opus-4-6",
        turns=[
            Turn(role="user", content="Hi", input_tokens=100, output_tokens=0),
            Turn(role="assistant", content="Hello", input_tokens=0, output_tokens=50),
        ],
    )
    export_sessions([session], out_dir, redact=False)

    result = inject_badges_into_readme(root, out_dir)
    assert result is True

    readme = root / "README.md"
    assert readme.exists()
    content = readme.read_text()
    assert "<!-- opi-badges-start -->" in content
    assert "<!-- opi-badges-end -->" in content
    assert "img.shields.io/badge" in content


def test_inject_badges_prepends_to_existing_readme(tmp_path: Path):
    """Badges are prepended to an existing README that has no markers."""
    root = tmp_path / "repo"
    root.mkdir()
    out_dir = root / "opi-prompts"

    (root / "README.md").write_text("# My Project\n\nSome content.\n")

    session = PromptSession(
        id="badge-002",
        source="claude-code",
        project="proj",
        timestamp="2026-03-06T12:00:00Z",
        model="gpt-5",
        turns=[
            Turn(role="assistant", content="resp", input_tokens=0, output_tokens=200),
        ],
    )
    export_sessions([session], out_dir, redact=False)
    inject_badges_into_readme(root, out_dir)

    content = (root / "README.md").read_text()
    assert content.startswith("<!-- opi-badges-start -->")
    assert "# My Project" in content
    assert "Some content." in content


def test_inject_badges_replaces_existing_block(tmp_path: Path):
    """Re-running update replaces the badge block, not duplicates."""
    root = tmp_path / "repo"
    root.mkdir()
    out_dir = root / "opi-prompts"

    session = PromptSession(
        id="badge-003",
        source="claude-code",
        project="proj",
        timestamp="2026-03-06T12:00:00Z",
        model="claude-opus-4-6",
        turns=[
            Turn(role="user", content="Hi", input_tokens=100, output_tokens=0),
        ],
    )
    export_sessions([session], out_dir, redact=False)

    # Inject twice
    inject_badges_into_readme(root, out_dir)
    inject_badges_into_readme(root, out_dir)

    content = (root / "README.md").read_text()
    assert content.count("<!-- opi-badges-start -->") == 1
    assert content.count("<!-- opi-badges-end -->") == 1
