"""Tests for project root detection."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from opi.project import detect_project_root, path_to_dash_format


def test_detect_project_root_git(tmp_path: Path):
    """When git rev-parse succeeds, return the git root."""
    with patch("opi.project.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 0
        mock_run.return_value.stdout = str(tmp_path) + "\n"
        result = detect_project_root()
        assert result == tmp_path


def test_detect_project_root_no_git():
    """When git rev-parse fails, fall back to CWD."""
    with patch("opi.project.subprocess.run") as mock_run:
        mock_run.return_value.returncode = 128
        mock_run.return_value.stdout = ""
        result = detect_project_root()
        assert result == Path.cwd()


def test_detect_project_root_git_not_found():
    """When git is not installed, fall back to CWD."""
    with patch("opi.project.subprocess.run", side_effect=OSError("not found")):
        result = detect_project_root()
        assert result == Path.cwd()


def test_path_to_dash_format():
    assert path_to_dash_format(Path("/Users/x/proj")) == "-Users-x-proj"
    assert path_to_dash_format(Path("/")) == "-"
    assert path_to_dash_format(Path("/a/b/c")) == "-a-b-c"
