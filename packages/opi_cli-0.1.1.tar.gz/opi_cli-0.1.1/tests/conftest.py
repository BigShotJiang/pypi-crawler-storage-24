"""Shared test fixtures."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from opi.models import PromptSession, Turn


@pytest.fixture
def tmp_dir(tmp_path: Path) -> Path:
    return tmp_path


@pytest.fixture
def sample_session() -> PromptSession:
    return PromptSession(
        id="test-session-001",
        source="claude-code",
        project="test-project",
        timestamp="2026-03-06T12:00:00Z",
        model="claude-opus-4-6",
        tags=["test"],
        turns=[
            Turn(role="user", content="Write a hello world function", timestamp="2026-03-06T12:00:00Z"),
            Turn(role="assistant", content="Here is a hello world function:\n\n```python\ndef hello():\n    print('Hello, world!')\n```", timestamp="2026-03-06T12:00:01Z"),
            Turn(role="user", content="Now add a parameter for the name", timestamp="2026-03-06T12:00:10Z"),
            Turn(role="assistant", content="```python\ndef hello(name='world'):\n    print(f'Hello, {name}!')\n```", timestamp="2026-03-06T12:00:11Z"),
        ],
    )


@pytest.fixture
def sample_session_with_secrets() -> PromptSession:
    return PromptSession(
        id="test-session-secrets",
        source="codex",
        project="/Users/testuser/projects/myapp",
        timestamp="2026-03-06T12:00:00Z",
        model="gpt-5",
        turns=[
            Turn(
                role="user",
                content=(
                    "Here is my API key: sk-1234567890abcdefghij1234567890abcdefghij\n"
                    "And my email is user@example.com\n"
                    "The file is at /Users/testuser/projects/myapp/config.py\n"
                    "My GitHub token is ghp_abcdefghijklmnopqrstuvwxyz0123456789\n"
                    "Database: postgres://admin:secretpass@db.example.com/mydb"
                ),
            ),
        ],
    )


@pytest.fixture
def claude_jsonl_dir(tmp_dir: Path) -> Path:
    """Create a fake Claude Code data directory with JSONL files."""
    projects_dir = tmp_dir / ".claude" / "projects" / "test-project"
    projects_dir.mkdir(parents=True)

    entries = [
        {
            "type": "user",
            "sessionId": "abc-123",
            "timestamp": "2026-03-06T12:00:00Z",
            "message": {"role": "user", "content": "Hello Claude"},
        },
        {
            "type": "assistant",
            "sessionId": "abc-123",
            "timestamp": "2026-03-06T12:00:01Z",
            "message": {
                "role": "assistant",
                "model": "claude-opus-4-6",
                "content": [{"type": "text", "text": "Hello! How can I help?"}],
                "usage": {"input_tokens": 150, "output_tokens": 30},
            },
        },
        {
            "type": "assistant",
            "sessionId": "abc-123",
            "timestamp": "2026-03-06T12:00:02Z",
            "message": {
                "role": "assistant",
                "content": [
                    {
                        "type": "tool_use",
                        "name": "Read",
                        "input": {"file_path": "/test/file.py"},
                        "id": "tool-1",
                    }
                ],
            },
        },
        {
            "type": "user",
            "sessionId": "abc-123",
            "timestamp": "2026-03-06T12:00:03Z",
            "message": {
                "role": "user",
                "content": [
                    {"type": "tool_result", "tool_use_id": "tool-1", "content": "file contents here"}
                ],
            },
        },
    ]

    jsonl_path = projects_dir / "abc-123.jsonl"
    jsonl_path.write_text(
        "\n".join(json.dumps(e) for e in entries), encoding="utf-8"
    )

    return tmp_dir / ".claude"
