"""Tests for Claude Code extractor."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import patch

from opi.extractors.claude_code import ClaudeCodeExtractor


def test_detect_with_data(claude_jsonl_dir: Path):
    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", claude_jsonl_dir):
        assert ext.detect() is True


def test_detect_without_data(tmp_path: Path):
    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", tmp_path / "nonexistent"):
        assert ext.detect() is False


def test_extract_sessions(claude_jsonl_dir: Path):
    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", claude_jsonl_dir):
        sessions = list(ext.extract())
        assert len(sessions) == 1

        session = sessions[0]
        assert session.id == "abc-123"
        assert session.source == "claude-code"
        assert session.model == "claude-opus-4-6"
        assert len(session.turns) >= 3  # user, assistant text, tool_use, tool_result


def test_extract_handles_string_content(tmp_path: Path):
    projects_dir = tmp_path / ".claude" / "projects" / "proj"
    projects_dir.mkdir(parents=True)

    entries = [
        {
            "type": "user",
            "sessionId": "str-content",
            "timestamp": "2026-03-06T12:00:00Z",
            "message": {"role": "user", "content": "Simple string content"},
        },
    ]
    jsonl_path = projects_dir / "str-content.jsonl"
    jsonl_path.write_text(
        "\n".join(json.dumps(e) for e in entries), encoding="utf-8"
    )

    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", tmp_path / ".claude"):
        sessions = list(ext.extract())
        assert len(sessions) == 1
        assert sessions[0].turns[0].content == "Simple string content"


def test_extract_skips_empty_files(tmp_path: Path):
    projects_dir = tmp_path / ".claude" / "projects" / "proj"
    projects_dir.mkdir(parents=True)
    (projects_dir / "empty.jsonl").write_text("", encoding="utf-8")

    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", tmp_path / ".claude"):
        sessions = list(ext.extract())
        assert len(sessions) == 0


def test_extract_with_project_path_match(tmp_path: Path):
    """project_path filters to matching project directories."""
    # Create two projects: -Users-kaiser-work-opi and -Users-kaiser-work-other
    base = tmp_path / ".claude" / "projects"

    for proj_dir_name in ["-Users-kaiser-work-opi", "-Users-kaiser-work-other"]:
        pdir = base / proj_dir_name
        pdir.mkdir(parents=True)
        entries = [
            {
                "type": "user",
                "sessionId": f"session-{proj_dir_name}",
                "timestamp": "2026-03-06T12:00:00Z",
                "message": {"role": "user", "content": f"Hello from {proj_dir_name}"},
            },
        ]
        (pdir / f"session-{proj_dir_name}.jsonl").write_text(
            "\n".join(json.dumps(e) for e in entries), encoding="utf-8"
        )

    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", tmp_path / ".claude"):
        # Without project_path: should get both
        all_sessions = list(ext.extract())
        assert len(all_sessions) == 2

        # With project_path: only the matching one
        sessions = list(ext.extract(project_path=Path("/Users/kaiser/work/opi")))
        assert len(sessions) == 1
        assert "opi" in sessions[0].project


def test_extract_with_project_path_includes_subdirs(tmp_path: Path):
    """project_path also matches subdirectory sessions."""
    base = tmp_path / ".claude" / "projects"

    # A subdirectory project: -Users-kaiser-work-opi-subdir
    pdir = base / "-Users-kaiser-work-opi-subdir"
    pdir.mkdir(parents=True)
    entries = [
        {
            "type": "user",
            "sessionId": "sub-session",
            "timestamp": "2026-03-06T12:00:00Z",
            "message": {"role": "user", "content": "Hello from subdir"},
        },
    ]
    (pdir / "sub-session.jsonl").write_text(
        "\n".join(json.dumps(e) for e in entries), encoding="utf-8"
    )

    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", tmp_path / ".claude"):
        sessions = list(ext.extract(project_path=Path("/Users/kaiser/work/opi")))
        assert len(sessions) == 1


def test_extract_token_usage(claude_jsonl_dir: Path):
    """Token usage is extracted from message.usage fields."""
    ext = ClaudeCodeExtractor()
    with patch.object(ext, "default_data_dir", claude_jsonl_dir):
        sessions = list(ext.extract())
        assert len(sessions) == 1

        session = sessions[0]
        # The assistant turn (second entry) has usage: {input_tokens: 150, output_tokens: 30}
        assistant_turns = [t for t in session.turns if t.role == "assistant"]
        assert len(assistant_turns) >= 1
        assert assistant_turns[0].input_tokens == 150
        assert assistant_turns[0].output_tokens == 30
