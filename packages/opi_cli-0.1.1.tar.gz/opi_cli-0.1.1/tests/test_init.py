"""Tests for ``opi init``."""

from __future__ import annotations

from pathlib import Path
from unittest.mock import patch

from click.testing import CliRunner

from opi.cli import cli


def _make_git_repo(path: Path) -> Path:
    """Create a bare .git directory so ``is_git_repo`` returns True."""
    (path / ".git").mkdir(parents=True, exist_ok=True)
    return path


def test_init_creates_prompts_dir_and_config(tmp_path: Path):
    repo = _make_git_repo(tmp_path / "repo")
    runner = CliRunner()
    with patch("opi.cli.detect_project_root", return_value=repo):
        result = runner.invoke(cli, ["init"])
    assert result.exit_code == 0
    assert (repo / "opi-prompts").is_dir()
    cfg = repo / ".pre-commit-config.yaml"
    assert cfg.exists()
    content = cfg.read_text()
    assert "opi-update" in content
    assert "opi update" in content


def test_init_idempotent(tmp_path: Path):
    """Running init twice does not duplicate the hook block."""
    repo = _make_git_repo(tmp_path / "repo")
    runner = CliRunner()
    with patch("opi.cli.detect_project_root", return_value=repo):
        runner.invoke(cli, ["init"])
        runner.invoke(cli, ["init"])

    content = (repo / ".pre-commit-config.yaml").read_text()
    assert content.count("opi-update") == 1


def test_init_appends_to_existing_config(tmp_path: Path):
    repo = _make_git_repo(tmp_path / "repo")
    existing = "repos:\n- repo: https://github.com/other/hook\n  hooks:\n    - id: other\n"
    (repo / ".pre-commit-config.yaml").write_text(existing, encoding="utf-8")

    runner = CliRunner()
    with patch("opi.cli.detect_project_root", return_value=repo):
        result = runner.invoke(cli, ["init"])

    assert result.exit_code == 0
    content = (repo / ".pre-commit-config.yaml").read_text()
    # Both hooks present
    assert "other" in content
    assert "opi-update" in content


def test_init_fails_outside_git_repo(tmp_path: Path):
    runner = CliRunner()
    with patch("opi.cli.detect_project_root", return_value=tmp_path):
        result = runner.invoke(cli, ["init"])
    assert result.exit_code != 0
    assert "not a git repository" in result.output.lower()
