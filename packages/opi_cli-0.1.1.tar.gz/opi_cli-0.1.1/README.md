# OPI — Open Prompt Initiative

Track, redact, and share your AI coding tool usage across a team.

OPI extracts prompt sessions from tools like Claude Code, Codex CLI, and Gemini CLI, strips sensitive data, and exports them as JSON to a shared directory in your git repo. A pre-commit hook keeps everything in sync automatically.

## Why

AI coding tools generate thousands of prompts, but that usage data stays siloed on each developer's machine. OPI makes it visible:

- **See what models your team is using** — shields.io badges in your README show token counts per model
- **Share prompt history** — exported sessions live in `opi-prompts/` alongside your code
- **Keep secrets out of git** — built-in redaction strips API keys, PII, file paths, and URLs before export

## Install

```bash
# With uv (recommended)
uv tool install opi-cli

# Or with pip
pip install opi-cli
```

Or run without installing:

```bash
uvx opi-cli init
```

## Quick start

```bash
cd your-repo

# Set up pre-commit hook and opi-prompts/ directory
opi init

# Run the pipeline: extract, redact, export, generate badges
opi update
```

That's it. On every commit, the pre-commit hook runs `opi update` to keep your prompt exports current.

## Commands

| Command | Purpose |
|---------|---------|
| `opi init` | Set up pre-commit hook in current git repo |
| `opi update` | Extract, redact, export sessions, and generate README with badges |
| `opi config` | Manage redaction settings |
| `opi sources` | Show detected AI coding tools |

## Multi-user

Each developer runs `opi update` independently. Sessions export to `opi-prompts/` which is committed to git. The generated README aggregates token usage from **all** users' exports, so badges reflect the full team's usage.

## Redaction

By default, OPI redacts:

- API keys and tokens (OpenAI, GitHub, AWS, etc.)
- PII (email addresses)
- File paths
- URLs with credentials

Configure via `opi config --edit` or `~/.opi/config.toml`:

```toml
[redact]
secrets = true
pii = true
file_paths = true
urls = true
org_terms = ["acme-corp", "internal-project"]
```

## Supported tools

- [Claude Code](https://docs.anthropic.com/en/docs/claude-code)
- [Codex CLI](https://github.com/openai/codex)
- [Gemini CLI](https://github.com/google-gemini/gemini-cli)

## License

MIT
