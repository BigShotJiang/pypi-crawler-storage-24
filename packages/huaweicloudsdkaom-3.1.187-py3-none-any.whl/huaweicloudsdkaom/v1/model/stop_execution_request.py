# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class StopExecutionRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'workflow_id': 'str',
        'execution_id': 'str'
    }

    attribute_map = {
        'workflow_id': 'workflow_id',
        'execution_id': 'execution_id'
    }

    def __init__(self, workflow_id=None, execution_id=None):
        r"""StopExecutionRequest

        The model defined in huaweicloud sdk

        :param workflow_id: 任务id，从工作流命令列表中获取的工作流id。
        :type workflow_id: str
        :param execution_id: 任务执行id。
        :type execution_id: str
        """
        
        

        self._workflow_id = None
        self._execution_id = None
        self.discriminator = None

        self.workflow_id = workflow_id
        self.execution_id = execution_id

    @property
    def workflow_id(self):
        r"""Gets the workflow_id of this StopExecutionRequest.

        任务id，从工作流命令列表中获取的工作流id。

        :return: The workflow_id of this StopExecutionRequest.
        :rtype: str
        """
        return self._workflow_id

    @workflow_id.setter
    def workflow_id(self, workflow_id):
        r"""Sets the workflow_id of this StopExecutionRequest.

        任务id，从工作流命令列表中获取的工作流id。

        :param workflow_id: The workflow_id of this StopExecutionRequest.
        :type workflow_id: str
        """
        self._workflow_id = workflow_id

    @property
    def execution_id(self):
        r"""Gets the execution_id of this StopExecutionRequest.

        任务执行id。

        :return: The execution_id of this StopExecutionRequest.
        :rtype: str
        """
        return self._execution_id

    @execution_id.setter
    def execution_id(self, execution_id):
        r"""Sets the execution_id of this StopExecutionRequest.

        任务执行id。

        :param execution_id: The execution_id of this StopExecutionRequest.
        :type execution_id: str
        """
        self._execution_id = execution_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, StopExecutionRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
