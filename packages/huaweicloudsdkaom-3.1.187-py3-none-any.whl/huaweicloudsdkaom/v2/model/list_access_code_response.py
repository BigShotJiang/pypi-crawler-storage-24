# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListAccessCodeResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'access_codes': 'list[AccessCodeModel]'
    }

    attribute_map = {
        'access_codes': 'access_codes'
    }

    def __init__(self, access_codes=None):
        r"""ListAccessCodeResponse

        The model defined in huaweicloud sdk

        :param access_codes: accessCodes。
        :type access_codes: list[:class:`huaweicloudsdkaom.v2.AccessCodeModel`]
        """
        
        super().__init__()

        self._access_codes = None
        self.discriminator = None

        if access_codes is not None:
            self.access_codes = access_codes

    @property
    def access_codes(self):
        r"""Gets the access_codes of this ListAccessCodeResponse.

        accessCodes。

        :return: The access_codes of this ListAccessCodeResponse.
        :rtype: list[:class:`huaweicloudsdkaom.v2.AccessCodeModel`]
        """
        return self._access_codes

    @access_codes.setter
    def access_codes(self, access_codes):
        r"""Sets the access_codes of this ListAccessCodeResponse.

        accessCodes。

        :param access_codes: The access_codes of this ListAccessCodeResponse.
        :type access_codes: list[:class:`huaweicloudsdkaom.v2.AccessCodeModel`]
        """
        self._access_codes = access_codes

    def to_dict(self):
        import warnings
        warnings.warn("ListAccessCodeResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAccessCodeResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
