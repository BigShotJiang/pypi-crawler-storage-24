Symbol
======

.. autoclass:: ninetoothed.Symbol
