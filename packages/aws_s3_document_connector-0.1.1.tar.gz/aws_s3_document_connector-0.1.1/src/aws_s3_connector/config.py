import os


class Config:
    def __init__(self):
        self.bucket = os.getenv("S3_BUCKET")
        self.region = os.getenv("AWS_REGION", "us-east-1")
        self.kms_key_id = os.getenv("S3_KMS_KEY")
        self.presigned_expiry = int(os.getenv("PRESIGNED_EXPIRY", 300))