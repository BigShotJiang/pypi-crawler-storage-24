from dataclasses import dataclass
from typing import Optional, Dict
from datetime import datetime


@dataclass
class UploadRequest:
    tenant_name: str
    clinic_id: int
    patient_id: int
    document_type: str
    document_format: str
    file_name: str
    content_type: str
    content_length: Optional[int] = None
    review_status: Optional[str] = None
    custom_metadata: Optional[Dict[str, str]] = None

    def __post_init__(self):
        if not self.tenant_name or not str(self.tenant_name).strip():
            raise ValueError("tenant_name is required")
        if not isinstance(self.clinic_id, int) or self.clinic_id <= 0:
            raise ValueError("clinic_id must be a positive integer")
        if not isinstance(self.patient_id, int) or self.patient_id <= 0:
            raise ValueError("patient_id must be a positive integer")
        if not self.document_type or not str(self.document_type).strip():
            raise ValueError("document_type is required")
        if not self.file_name or not str(self.file_name).strip():
            raise ValueError("file_name is required")
        if not self.content_type or not str(self.content_type).strip():
            raise ValueError("content_type is required")


@dataclass
class UploadResult:
    bucket: str
    key: str
    etag: str
    version_id: Optional[str]


@dataclass
class StorageObjectRef:
    bucket: str
    key: str
    version_id: Optional[str] = None