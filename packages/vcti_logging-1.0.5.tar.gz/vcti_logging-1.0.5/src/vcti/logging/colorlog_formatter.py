# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Class that provides colored logging messages"""

import colorlog

from .custom_level import LOG_LEVEL_COLOR_PREFERENCES


def _translate_color_preferences_to_colorlog(preferences: dict[str, str]) -> dict[str, str]:
    """
    Translate color preferences to colorlog-specific color names.

    This allows custom_level.py to remain package-agnostic while colorlog_formatter.py
    handles the package-specific implementation. Provides fallbacks for colors that
    colorlog doesn't support (e.g., "thin_white" -> "white", "light_cyan" -> "cyan").

    Args:
        preferences: Dict mapping level names to color names (standard or extended).

    Returns:
        Dict mapping level names to colorlog-specific color names.
    """
    # Map colors that colorlog doesn't support to colorlog equivalents
    COLORLOG_FALLBACKS = {
        "gray": "thin_white",  # Use thin_white for gray (appears dimmer than white)
        "grey": "thin_white",
        "light_gray": "white",
        "light_grey": "white",
    }

    return {
        level: COLORLOG_FALLBACKS.get(
            color, color
        )  # Use fallback if needed, otherwise pass through
        for level, color in preferences.items()
    }


default_log_colors = {
    **colorlog.default_log_colors,
    **_translate_color_preferences_to_colorlog(LOG_LEVEL_COLOR_PREFERENCES),
}


# Create and return color log formatter
def create_formatter(message_format: str) -> colorlog.ColoredFormatter:
    """
    Creates and returns a colorlog formatter with the specified message format.

    Args:
        message_format: The log message format string.

    Returns:
        colorlog.ColoredFormatter: Configured formatter instance.
    """
    return colorlog.ColoredFormatter(message_format, log_colors=default_log_colors)
