# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""
Logging Module

This module provides logging functionality for the VCTI application. It includes utilities for
configuring logging, defining log levels, and setting up loggers.

The module provides:
- `MESSAGE_FORMAT_PRESETS`: Available message format presets (minimal, standard, detailed).
- `resolve_message_format`: Resolve a preset name or raw format string.
- `create_logging_config`: A function to create a logging configuration.
- `logger`: The primary logger instance for the application.
- `setup_logging`: A function to initialize and configure logging for the application.
- `CustomLevelLogger`: Logger class with custom log level methods (trace, verbose).
- `LogLevel`: IntEnum with all log levels (standard + custom).
- `decode_log_level` / `encode_log_level`: Convert between log level strings and enum.
- `DEFAULT_LOG_LEVEL_STR`: Default log level string ("info").
- `LOG_LEVEL_VALUES`: List of all valid log level strings.
- `LogLevelCoder`: Convenience class bundling Literal type, default, list, encode, decode.
"""

from importlib.metadata import version

__version__ = version("vcti-logging")

from .config import (
    MESSAGE_FORMAT_PRESETS,
    MessageFormatPreset,
    create_logging_config,
    resolve_message_format,
)
from .custom_level import CustomLevelLogger
from .log_level import (
    DEFAULT_LOG_LEVEL_STR,
    LOG_LEVEL_VALUES,
    LogLevel,
    LogLevelStr,
    decode_log_level,
    encode_log_level,
)
from .log_level_coder import LogLevelCoder
from .logger_setup import logger, setup_logging

__all__ = [
    "__version__",
    "MESSAGE_FORMAT_PRESETS",
    "MessageFormatPreset",
    "create_logging_config",
    "resolve_message_format",
    "CustomLevelLogger",
    "DEFAULT_LOG_LEVEL_STR",
    "LOG_LEVEL_VALUES",
    "LogLevel",
    "LogLevelStr",
    "decode_log_level",
    "encode_log_level",
    "LogLevelCoder",
    "logger",
    "setup_logging",
]
