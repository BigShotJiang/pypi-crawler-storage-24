#!/usr/bin/env python
"""Test to verify that custom logger methods have proper type hints."""

from vcti.logging import logger


def test_custom_logger_methods_exist():
    """Verify that logger has trace and verbose methods."""
    assert hasattr(logger, "trace")
    assert hasattr(logger, "verbose")
    assert callable(logger.trace)
    assert callable(logger.verbose)


def test_custom_logger_type_hints():
    """
    This test demonstrates that Pylance should not show errors for
    logger.trace() and logger.verbose() calls.
    """
    # These should not cause Pylance errors
    logger.trace("This is a trace message")
    logger.verbose("This is a verbose message")

    # Standard methods should also work
    logger.debug("Debug message")
    logger.info("Info message")
    logger.warning("Warning message")
    logger.error("Error message")
    logger.fatal("Fatal message")
