"""Tests for vcti.logging.config module."""

from pathlib import Path

from vcti.logging.config import (
    ConsoleLogConfig,
    FileLogConfig,
    create_logging_config,
)


class TestConsoleLogConfig:
    def test_defaults(self):
        config = ConsoleLogConfig()
        assert config.enable_color_log is False
        assert config.message_format is None

    def test_custom_values(self):
        config = ConsoleLogConfig(log_level="debug", enable_color_log=True)
        assert config.log_level == "debug"
        assert config.enable_color_log is True


class TestFileLogConfig:
    def test_creation(self):
        config = FileLogConfig(file_path=Path("test.log"))
        assert config.file_path == Path("test.log")
        assert config.message_format is None
        assert config.mode == "a"


class TestCreateLoggingConfig:
    def test_console_only(self):
        configs = create_logging_config(enable_console_log=True)
        assert len(configs) == 1
        assert isinstance(configs[0], ConsoleLogConfig)

    def test_file_only(self):
        configs = create_logging_config(enable_console_log=False, log_file_path=Path("test.log"))
        assert len(configs) == 1
        assert isinstance(configs[0], FileLogConfig)

    def test_both(self):
        configs = create_logging_config(enable_console_log=True, log_file_path=Path("test.log"))
        assert len(configs) == 2

    def test_neither(self):
        configs = create_logging_config(enable_console_log=False)
        assert len(configs) == 0

    def test_color_log_flag_set(self):
        configs = create_logging_config(enable_color_log=True)
        assert configs[0].enable_color_log is True
