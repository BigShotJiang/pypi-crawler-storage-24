from .bn import BNGenerator
