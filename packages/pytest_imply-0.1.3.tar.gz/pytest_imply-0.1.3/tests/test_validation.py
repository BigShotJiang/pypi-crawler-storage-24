"""Tests for marker argument validation."""  # pylint: disable=R0801

import textwrap


def test_implies_no_args_errors(pytester):
    """implies() with no arguments is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.implies()
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*implies() requires at least one*"])


def test_implied_by_no_args_errors(pytester):
    """implied_by() with no arguments is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.implied_by()
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*implied_by() requires exactly one*"])


def test_implied_by_multiple_args_errors(pytester):
    """implied_by() with multiple arguments is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.implied_by("tok_a", "tok_b")
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*implied_by() requires exactly one*"])


def test_implied_by_any_one_arg_errors(pytester):
    """implied_by_any() with fewer than two arguments is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.implied_by_any("tok_a")
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*implied_by_any() requires at least two*"])


def test_implied_by_all_one_arg_errors(pytester):
    """implied_by_all() with fewer than two arguments is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.implied_by_all("tok_a")
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*implied_by_all() requires at least two*"])


def test_monotonic_no_args_errors(pytester):
    """monotonic() with no arguments is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.monotonic()
        @pytest.mark.parametrize("n", [1, 2])
        def test_bad(n):
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*monotonic() requires a parameter*"])


def test_monotonic_bad_direction_errors(pytester):
    """monotonic() with invalid direction is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.monotonic("n", direction="sideways")
        @pytest.mark.parametrize("n", [1, 2])
        def test_bad(n):
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*direction must be*"])


def test_monotonic_not_parametrized_errors(pytester):
    """monotonic() on a non-parametrized test is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.monotonic("n")
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*requires a parametrized test*"])


def test_monotonic_wrong_param_errors(pytester):
    """monotonic() with a nonexistent parameter name is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.monotonic("missing")
        @pytest.mark.parametrize("n", [1, 2])
        def test_bad(n):
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*parameter not found*"])


def test_monotonic_unsortable_values_errors(pytester):
    """monotonic() with unsortable parameter values is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.monotonic("x")
        @pytest.mark.parametrize("x", [1, "two", 3])
        def test_bad(x):
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*parameter values must be orderable*"])


def test_non_string_token_errors(pytester):
    """Token arguments that are not strings are rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.implies(42)
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*token arguments must be strings*"])


def test_non_string_implied_by_token_errors(pytester):
    """Non-string token in implied_by is rejected."""
    pytester.makepyfile(textwrap.dedent("""\
        import pytest

        @pytest.mark.implied_by(None)
        def test_bad():
            pass
    """))
    result = pytester.runpytest("-v")
    result.stderr.fnmatch_lines(["*token arguments must be strings*"])
