"""
sage.kernel.flow.pipeline_compiler - Pipeline DAG → Actor method-dispatch graph.

Layer: L3 (sage-kernel)
Dependencies: sage.platform L2 adapter (``RuntimeBackendProtocol``), sage.common L1.

This module translates a SAGE declarative pipeline (a list of
``BaseTransformation`` nodes built via ``env.from_source().map().sink()``)
into a set of locally registered actors whose methods are dispatched
directly in Python — no external runtime topology build required.

Terminology
-----------
Pipeline DAG
    The linear (or branching) list of ``BaseTransformation`` objects stored in
    ``BaseEnvironment.pipeline``.

Stage chain
    A list of ``(op_type, MethodRefProtocol)`` tuples compiled from the
    non-source transformations.  Execution iterates this chain for every
    input item, applying fan-out for ``flatmap`` and filtering for ``filter``.

Compilation
-----------
``PipelineCompiler.compile(pipeline, adapter)`` returns a ``CompiledActorGraph``.
The caller invokes ``CompiledActorGraph.submit(autostop=…)`` to start execution.

Two execution modes:

Batch mode (``autostop=True``)
    1. The source function is drained synchronously to collect all items.
    2. Each item is fed through the stage chain sequentially.
    3. ``submit()`` blocks until all items have been processed.

Streaming mode (``autostop=False``)
    1. The source function runs in a background ``threading.Thread``.
    2. Each emitted item is immediately fed through the stage chain.
    3. ``submit()`` returns a ``_StreamingFlowHandle`` immediately.

Runtime independence
    No ``flutty.*`` or ``sage.flownet.*`` imports appear here.  The adapter
    passed to ``compile()`` must implement ``RuntimeBackendProtocol``; this
    module only calls ``adapter.create()`` and ``handle.get_method()``.

References
----------
- Actor DAG specification: intellistream/SAGE#1442
- Runtime protocol:        sage.platform.runtime.protocol.RuntimeBackendProtocol
- Adapter (flutty):        sage.platform.runtime.adapters.flutty_adapter
"""

from __future__ import annotations

import logging
import threading
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from sage.kernel.api.transformation.base_transformation import BaseTransformation
    from sage.platform.runtime.protocol import ActorHandleProtocol, RuntimeBackendProtocol

logger = logging.getLogger(__name__)

__all__ = [
    "PipelineCompiler",
    "CompiledActorGraph",
]


# ---------------------------------------------------------------------------
# Op-type constants
# ---------------------------------------------------------------------------

_OP_MAP: str = "map"
_OP_FLATMAP: str = "flatmap"
_OP_FILTER: str = "filter"
_OP_SINK: str = "sink"


def _classify(t: "BaseTransformation") -> tuple[type, str, str]:
    """Return ``(WrapperClass, op_type_str, method_name)`` for *t*."""
    from sage.kernel.api.transformation.filter_transformation import FilterTransformation
    from sage.kernel.api.transformation.flatmap_transformation import FlatMapTransformation
    from sage.kernel.api.transformation.map_transformation import MapTransformation
    from sage.kernel.api.transformation.sink_transformation import SinkTransformation
    from sage.kernel.api.transformation.source_transformation import SourceTransformation
    from sage.kernel.flow.actor_wrappers import (
        FilterActorWrapper,
        FlatMapActorWrapper,
        MapActorWrapper,
        ServiceActorWrapper,
        SinkActorWrapper,
        SourceActorWrapper,
    )

    if isinstance(t, SourceTransformation):
        return (SourceActorWrapper, "source", "run")
    if isinstance(t, MapTransformation):
        return (MapActorWrapper, _OP_MAP, "process")
    if isinstance(t, FlatMapTransformation):
        return (FlatMapActorWrapper, _OP_FLATMAP, "process")
    if isinstance(t, FilterTransformation):
        return (FilterActorWrapper, _OP_FILTER, "accepts")
    if isinstance(t, SinkTransformation):
        return (SinkActorWrapper, _OP_SINK, "consume")
    return (ServiceActorWrapper, _OP_MAP, "process")


# ---------------------------------------------------------------------------
# Streaming handle
# ---------------------------------------------------------------------------


class _StreamingFlowHandle:
    """Returned by ``CompiledActorGraph.submit(autostop=False)``.

    Holds a reference to the background source thread.  Call ``stop()`` to
    signal the thread and wait for graceful shutdown.
    """

    def __init__(
        self,
        source_thread: threading.Thread | None,
        *,
        stop_event: threading.Event,
    ) -> None:
        self._thread = source_thread
        self._stop_event = stop_event

    def stop(self, timeout: float = 30.0) -> None:
        """Signal the source thread to stop and wait for it to join."""
        self._stop_event.set()
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=timeout)

    @property
    def is_running(self) -> bool:
        """``True`` while the source thread is still alive."""
        return self._thread is not None and self._thread.is_alive()


    @property
    def is_running(self) -> bool:
        """``True`` while the source thread is still alive."""
        return self._thread is not None and self._thread.is_alive()


# ---------------------------------------------------------------------------
# CompiledActorGraph
# ---------------------------------------------------------------------------


@dataclass
class CompiledActorGraph:
    """The compiled result of ``PipelineCompiler.compile()``.

    Holds the stage chain plus a reference to the source transformation.
    The only public entry point is ``submit()``.

    Attributes:
        stage_ops:              List of ``(op_type, MethodRefProtocol)`` pairs
                                for the non-source pipeline stages, in order.
        source_transformation:  The ``SourceTransformation`` node, or ``None``.
        actor_handles:          Protocol-wrapped actor handles (in pipeline
                                order, excluding source).  Kept mainly for
                                lifecycle management (cancel on error).
        adapter:                The ``RuntimeBackendProtocol`` adapter.
    """

    stage_ops: list[tuple[str, Any]]   # (op_type, MethodRefProtocol)
    source_transformation: Any | None
    actor_handles: list[Any] = field(default_factory=list)
    adapter: Any = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def submit(self, autostop: bool = False) -> Any:
        """Execute the compiled pipeline.

        Args:
            autostop: ``True``  — collect all source items and process them
                                  synchronously; blocks until done.
                      ``False`` — start source in a background thread and
                                  return a ``_StreamingFlowHandle`` immediately.

        Returns:
            * ``None`` when ``autostop=True``.
            * A ``_StreamingFlowHandle`` when ``autostop=False``.
        """
        if autostop:
            return self._submit_batch()
        return self._submit_streaming()

    # ------------------------------------------------------------------
    # Pipeline execution — chain dispatch
    # ------------------------------------------------------------------

    def _execute_chain(self, items: list[Any], ops: list[tuple[str, Any]]) -> list[Any]:
        """Recursively execute *items* through the remaining *ops* chain.

        Handles fan-out (``flatmap``) and filtering (``filter``) correctly.

        Args:
            items: Current batch of items at this stage.
            ops:   The remaining ``(op_type, MethodRefProtocol)`` list.

        Returns:
            The list of items produced after the terminal stage (empty for
            pipelines that end with a sink).
        """
        if not ops or not items:
            return items

        op_type, method_ref = ops[0]
        remaining = ops[1:]

        if op_type == _OP_SINK:
            for item in items:
                method_ref.call(item)
            return []

        if op_type == _OP_FLATMAP:
            next_items: list[Any] = []
            for item in items:
                result = method_ref.call(item)
                if result is None:
                    continue
                if hasattr(result, "__iter__") and not isinstance(result, (str, bytes)):
                    next_items.extend(result)
                else:
                    next_items.append(result)
            return self._execute_chain(next_items, remaining)

        if op_type == _OP_FILTER:
            next_items = [item for item in items if method_ref.call(item)]
            return self._execute_chain(next_items, remaining)

        # map / service / default
        next_items = [method_ref.call(item) for item in items]
        return self._execute_chain(next_items, remaining)

    # ------------------------------------------------------------------
    # Batch execution
    # ------------------------------------------------------------------

    def _collect_source_items(self) -> list[Any]:
        """Drain the source function and return all emitted items."""
        t = self.source_transformation
        if t is None:
            return []

        from sage.kernel.runtime.communication.packet import StopSignal

        fn = t.function_class(*t.function_args, **t.function_kwargs)
        items: list[Any] = []
        while True:
            item = fn.execute()
            if isinstance(item, StopSignal) or item is None:
                break
            items.append(item)

        logger.debug(
            "Source '%s' drained: %d items collected.",
            t.function_class.__name__,
            len(items),
        )
        return items

    def _submit_batch(self) -> None:
        """Collect all source items and drive them through the stage chain."""
        items = self._collect_source_items()
        if not items:
            logger.info("Source produced no items; batch pipeline skipped.")
            return None

        logger.info("Processing batch of %d items through pipeline.", len(items))
        for item in items:
            self._execute_chain([item], self.stage_ops)
        return None

    # ------------------------------------------------------------------
    # Streaming execution
    # ------------------------------------------------------------------

    def _submit_streaming(self) -> _StreamingFlowHandle:
        """Start the source in a background thread; return a control handle."""
        stop_event = threading.Event()
        source_thread: threading.Thread | None = None

        if self.source_transformation is not None:
            source_thread = threading.Thread(
                target=self._run_source_thread,
                args=(stop_event,),
                daemon=True,
                name=f"sage-source-{self.source_transformation.basename}",
            )
            source_thread.start()

        return _StreamingFlowHandle(source_thread, stop_event=stop_event)

    def _run_source_thread(self, stop_event: threading.Event) -> None:
        """Background thread: poll source and drive each item through the chain."""
        from sage.kernel.runtime.communication.packet import StopSignal

        t = self.source_transformation
        fn = t.function_class(*t.function_args, **t.function_kwargs)

        try:
            while not stop_event.is_set():
                item = fn.execute()
                if isinstance(item, StopSignal) or item is None:
                    break
                self._execute_chain([item], self.stage_ops)
        except Exception:  # noqa: BLE001
            logger.exception(
                "Source function '%s' raised an exception in streaming mode.",
                t.function_class.__name__,
            )
        finally:
            logger.debug(
                "Source thread for '%s' exiting.", t.function_class.__name__
            )


# ---------------------------------------------------------------------------
# PipelineCompiler
# ---------------------------------------------------------------------------


class PipelineCompiler:
    """Compiles a SAGE ``BaseTransformation`` list into a ``CompiledActorGraph``.

    The compiler creates one actor per processing stage via the supplied
    *adapter*, then wires them together as a ``stage_ops`` list of
    ``(op_type, MethodRefProtocol)`` pairs.  At execution time,
    :py:meth:`CompiledActorGraph._execute_chain` drives data through the
    chain with pure Python dispatch — no external runtime graph is required.

    Usage::

        from sage.platform.runtime.adapters.flutty_adapter import get_flutty_adapter
        from sage.kernel.flow.pipeline_compiler import PipelineCompiler

        adapter = get_flutty_adapter()
        graph = PipelineCompiler().compile(env.pipeline, adapter)
        graph.submit(autostop=True)
    """

    def compile(
        self,
        pipeline: list[BaseTransformation],
        adapter: RuntimeBackendProtocol,
    ) -> CompiledActorGraph:
        """Compile *pipeline* into a ``CompiledActorGraph`` using *adapter*.

        Args:
            pipeline: The ordered list of ``BaseTransformation`` objects built
                      by the ``BaseEnvironment`` DSL.
            adapter:  A started ``RuntimeBackendProtocol`` implementation
                      (e.g. ``FluttyRuntimeAdapter``) used to create actors.

        Returns:
            A ``CompiledActorGraph`` ready to be submitted.

        Raises:
            ValueError: If the pipeline is empty or otherwise malformed.
        """
        if not pipeline:
            raise ValueError(
                "PipelineCompiler.compile() received an empty pipeline.  "
                "Build a pipeline with env.from_source(...).map(...).sink(...) "
                "before calling env.submit()."
            )

        # ------------------------------------------------------------------
        # Step 1: Classify & partition transformations
        # ------------------------------------------------------------------
        source_trans: Any | None = None
        proc_transformations: list[Any] = []

        for t in pipeline:
            _, op_type, _ = _classify(t)
            if op_type == "source":
                if source_trans is not None:
                    raise ValueError(
                        "PipelineCompiler found more than one SourceTransformation in the "
                        "pipeline.  Only a single source is supported per compilation unit."
                    )
                source_trans = t
            else:
                proc_transformations.append(t)

        # ------------------------------------------------------------------
        # Step 2: Create actors and build stage_ops via MethodRefProtocol
        # ------------------------------------------------------------------
        actor_handles: list[ActorHandleProtocol] = []
        stage_ops: list[tuple[str, Any]] = []

        for t in proc_transformations:
            wrapper_cls, op_type, method_name = _classify(t)
            handle = adapter.create(
                wrapper_cls,
                t.function_class,
                *t.function_args,
                **t.function_kwargs,
            )
            actor_handles.append(handle)
            method_ref = handle.get_method(method_name)
            stage_ops.append((op_type, method_ref))

            logger.debug(
                "Compiled stage %s → %s.%s() [op=%s]",
                t.basename,
                wrapper_cls.__name__,
                method_name,
                op_type,
            )

        return CompiledActorGraph(
            stage_ops=stage_ops,
            source_transformation=source_trans,
            actor_handles=actor_handles,
            adapter=adapter,
        )
