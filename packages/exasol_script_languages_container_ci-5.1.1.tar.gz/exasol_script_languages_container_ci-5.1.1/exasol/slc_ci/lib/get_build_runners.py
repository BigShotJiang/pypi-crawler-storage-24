import json

from exasol.slc_ci.lib.get_build_config_model import get_build_config_model
from exasol.slc_ci.lib.get_flavor_ci_model import get_flavor_ci_model
from exasol.slc_ci.lib.github_access import GithubAccess


def get_build_runners(flavor: str, github_access: GithubAccess):
    build_config = get_build_config_model()
    flavor_config = get_flavor_ci_model(build_config, flavor)
    github_access.write_result(json.dumps(flavor_config.build_runners))
