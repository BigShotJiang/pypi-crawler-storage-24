"""Defines the structures and logic for handling query conditions in Tesseract OLAP.

It includes support for:
- Comparison conditions (e.g., greater than, less than)
- Membership conditions (e.g., IN, NOT IN)
- Nullity conditions (e.g., IS NULL, IS NOT NULL)
- Composite conditions (AND/OR logic)
- Temporal conditions (restrictions based on time)

The conditions can be serialized to and deserialized from string representations
used in URL parameters.
"""

from collections.abc import Sequence
from typing import Annotated, Union

from pydantic import BaseModel, Discriminator, RootModel, Tag, model_validator

from .enums import (
    ComparisonOperator,
    LogicOperator,
    MembershipOperator,
    NullityOperator,
    Restriction,
)


class ComparisonCondition(BaseModel):
    """Represents a comparison between a field and a value."""

    operator: ComparisonOperator
    value: Union[str, float, int]

    @model_validator(mode="before")
    @classmethod
    def _coerce_value(cls, data: object) -> object:
        if isinstance(data, dict) and "value" in data:
            data["value"] = _coerce_val(str(data["value"]))
        return data

    def __repr__(self) -> str:
        return f"Comparison(op={self.operator!r}, val={self.value!r})"

    def __str__(self) -> str:
        return f"{self.operator.value}.{self.value}"

    @property
    def dependencies(self) -> set[str]:
        """Returns the set of column names this condition depends on."""
        return {self.value} if isinstance(self.value, str) else set()


class MembershipCondition(BaseModel):
    """Represents a membership check against a list of values."""

    operator: MembershipOperator
    values: list[Union[str, float, int]]

    @model_validator(mode="before")
    @classmethod
    def _coerce_values(cls, data: object) -> object:
        if isinstance(data, dict) and "values" in data:
            data["values"] = [_coerce_val(str(v)) for v in data["values"]]
        return data

    def __repr__(self) -> str:
        return f"Membership(op={self.operator!r}, val={self.values!r})"

    def __str__(self) -> str:
        vals = ".".join(map(str, self.values))
        return f"{self.operator.value}.{vals}"

    @property
    def dependencies(self) -> set[str]:
        """Membership conditions in Tesseract currently only support literal values."""
        return set()


class NullityCondition(BaseModel):
    """Represents a check for null or non-null values."""

    operator: NullityOperator

    def __repr__(self) -> str:
        return f"Nullity(op={self.operator!r})"

    def __str__(self) -> str:
        return self.operator.value

    @property
    def dependencies(self) -> set[str]:
        """Nullity conditions do not have external dependencies."""
        return set()


class CompositeCondition(BaseModel):
    """Represents a combination of multiple conditions using logical operators."""

    operator: LogicOperator
    conditions: list["AnyCondition"]

    def __repr__(self) -> str:
        conds = f" {self.operator} ".join(repr(cond) for cond in self.conditions)
        return f"Composite({conds})"

    def __str__(self) -> str:
        sep = f".{self.operator.value}."
        return sep.join(repr(c) for c in self.conditions)

    @property
    def dependencies(self) -> set[str]:
        """Returns the union of dependencies from all sub-conditions."""
        deps = set()
        for cond in self.conditions:
            deps.update(cond.dependencies)
        return deps


class TemporalCondition(BaseModel):
    """Represents a condition based on temporal restrictions."""

    constraint: Restriction


def _get_discriminator_value(value: object) -> str:
    """Determine the discriminator value for the AnyCondition type.

    Supports both dictionary input and instance input.
    """
    clsname = type(value).__name__
    if "Condition" in clsname:
        return clsname.removesuffix("Condition").lower()

    operator = value.get("operator")

    if LogicOperator.match(operator):
        return "composite"
    if NullityOperator.match(operator):
        return "nullity"
    if MembershipOperator.match(operator):
        return "membership"
    if ComparisonOperator.match(operator):
        return "comparison"

    msg = f"Provided value is not parseable Condition: {value!r}"
    raise ValueError(msg)


AnyCondition = Annotated[
    Union[
        Annotated[ComparisonCondition, Tag("comparison")],
        Annotated[MembershipCondition, Tag("membership")],
        Annotated[NullityCondition, Tag("nullity")],
        Annotated[CompositeCondition, Tag("composite")],
    ],
    Discriminator(_get_discriminator_value),
]


class Condition(RootModel):
    """Root model for any type of condition.

    Supports parsing from both structured data (dicts) and string representations.
    """

    root: AnyCondition

    def __eq__(self, other: object) -> bool:
        return repr(self) == repr(other)

    def __hash__(self) -> int:
        return hash(repr(self.root))

    def __repr__(self) -> str:
        return f"Condition[{self.root!r}]"

    def __str__(self) -> str:
        return str(self.root)

    @property
    def dependencies(self) -> set[str]:
        """Returns the set of column names this condition depends on."""
        return self.root.dependencies

    @model_validator(mode="before")
    @classmethod
    def parse(cls, obj: object) -> object:
        """Entry point for Pydantic's model validation."""
        return cls._parse(obj)

    @classmethod
    def _parse(cls, obj: object) -> object:
        """Parse a condition from a string, dictionary or sequence.

        If it's a sequence, concatenates it into a string.
        If the input is a string, it uses _deserialize_string to convert it.
        """
        if isinstance(obj, (list, tuple)) and obj:
            if len(obj) == 1:
                return cls._parse(obj[0])
            return cls._deserialize_sequence(obj)

        if isinstance(obj, str) and obj:
            return cls._deserialize_string(obj)

        return obj

    @staticmethod
    def _deserialize_sequence(seq_val: Sequence[str]) -> dict:
        """Convert a sequence representation of a condition into a dictionary format.

        The resulting dictionary will be later parsed into a compatible Pydantic model.
        """
        for op in LogicOperator:
            if op.value in seq_val:
                parts = [[]]
                for token in seq_val:
                    if token == op.value:
                        parts = [*parts, []]
                    else:
                        parts = [*parts[:-1], parts[-1] + [token]]
                return {
                    "operator": op.value,
                    "conditions": [Condition._parse(p) for p in parts if p],
                }

        match = NullityOperator.match(seq_val[0])
        if match is not None:
            return {"operator": match.value}

        match = MembershipOperator.match(seq_val[0])
        if match is not None:
            return {
                "operator": match.value,
                "values": [_coerce_val(v) for v in seq_val[1:]],
            }

        match = ComparisonOperator.match(seq_val[0])
        if match is not None:
            return {"operator": match.value, "value": _coerce_val(seq_val[1])}

        msg = f"Could not parse condition sequence: {seq_val!r}"
        raise ValueError(msg)

    @staticmethod
    def _deserialize_string(str_val: str) -> dict:
        """Convert a string representation of a condition into a dictionary format.

        The resulting dictionary will be later parsed into a compatible Pydantic model.
        """
        # 1. Composite logic
        for op in LogicOperator:
            pattern = f".{op.value}."
            if pattern in str_val:
                parts = str_val.split(pattern)
                # Recursively parse parts
                return {
                    "operator": op.value,
                    "conditions": [Condition._deserialize_string(p) for p in parts],
                }

        # 2. Nullity logic
        for op in NullityOperator:
            if str_val == op.value:
                return {"operator": op.value}

        # 3. Membership logic
        for op in MembershipOperator:
            if str_val.startswith(f"{op.value}."):
                _, *vals = str_val.split(".")
                return {
                    "operator": op.value,
                    "values": [_coerce_val(v) for v in vals],
                }

        # 4. Comparison logic
        for op in ComparisonOperator:
            if str_val.startswith(f"{op.value}."):
                _, *extra = str_val.split(".")
                val = ".".join(extra)
                return {
                    "operator": op.value,
                    "value": _coerce_val(val),
                }

        msg = f"Could not parse condition string: {str_val!r}"
        raise ValueError(msg)


def _coerce_val(v: str) -> Union[str, float, int]:
    """Attempt to convert a string value to a numeric type (int or float).

    Returns the original string if conversion fails.
    """
    try:
        if "." in v:
            return float(v)
        return int(v)
    except (TypeError, ValueError):
        return v


# Essential for Forward References in ConditionComposite
CompositeCondition.model_rebuild()
