"""Query-related internal structs module.

This module contains data-storing structs, used mainly on the query and backend
modules.
"""

import dataclasses as dcls
from collections.abc import Collection, Generator, Iterable, Mapping, Sequence
from copy import copy
from functools import cached_property
from typing import Annotated, Any, Literal, NamedTuple, Optional, Union

from pydantic import BaseModel, Field, model_validator

from tesseract_olap.common import TRUTHY_STRINGS, Prim, shorthash
from tesseract_olap.schema import (
    AnyMeasure,
    CalculatedMeasure,
    DataType,
    DimensionTraverser,
    HierarchyTraverser,
    InlineTable,
    LevelTraverser,
    PropertyTraverser,
    Table,
)

from .condition import Condition
from .enums import (
    AnyOrder,
    JoinType,
    Order,
    Restriction,
)

TimeConstraint = Union[
    tuple[Literal[Restriction.COMPLETE], Optional[str]],
    tuple[Literal[Restriction.LATEST, Restriction.OLDEST], int],
    tuple[Literal[Restriction.LEADING, Restriction.TRAILING], int],
    tuple[Literal[Restriction.EXPR], Condition],
]


class CutIntent(BaseModel):
    """Filtering instructions for a qualitative value.

    Instances of this class are used to define cut parameters.
    Its values are directly inputted by the user, so should never be considered
    valid by itself.
    """

    level: str
    include_members: set[Prim]
    exclude_members: set[Prim]

    def __lt__(self, other: object) -> bool:
        """Compare two CutIntent instances by their level name."""
        if isinstance(other, type(self)):
            return self.level < other.level
        return NotImplemented

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: object) -> object:
        """Parse the input value into a CutIntent dictionary."""
        if isinstance(value, str):
            value = value.split(":", 1)

        if isinstance(value, Sequence):
            if len(value) == 2:
                level = str(value[0])
                members = value[1]
                members = (
                    members.split(",") if isinstance(members, str) else list(members)
                )
                value = {
                    "level": level.lstrip("~"),
                    "include_members": [] if level.startswith("~") else members,
                    "exclude_members": members if level.startswith("~") else [],
                }

            elif len(value) == 3:
                level, incl, excl = value
                value = {
                    "level": level,
                    "include_members": incl,
                    "exclude_members": excl,
                }

        if isinstance(value, Mapping):
            nullables = {None, "", ","}
            include = value.get("include") or value.get("include_members", [])
            exclude = value.get("exclude") or value.get("exclude_members", [])
            value = {
                "level": value["level"],
                "include_members": set(include) - nullables,
                "exclude_members": set(exclude) - nullables,
            }

        return value


class FilterIntent(BaseModel):
    """Filtering instructions for a quantitative value.

    Instances of this class are used to define filter parameters.
    Its values are directly inputted by the user, so should never be considered
    valid by itself.
    """

    field: str
    condition: Condition

    def __repr__(self) -> str:
        """Return a string representation of the FilterIntent."""
        return f"FilterIntent(field={self.field!r}, condition={self.condition.root!r})"

    def __str__(self) -> str:
        """Return a string interpretation of the FilterIntent."""
        return f"{self.field}.{self.condition}"

    def __lt__(self, other: object) -> bool:
        """Compare two FilterIntent instances by their level name."""
        if isinstance(other, type(self)):
            return self.field < other.field
        return NotImplemented

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: object) -> object:
        """Parse the input value into a FilterIntent dictionary."""
        if isinstance(value, str):
            value = value.split(".", 1)

        if isinstance(value, Collection) and not isinstance(value, Mapping):
            field, *condition = value

            if not isinstance(field, str):
                msg = (
                    "When parsing a tuple, the first element must be a string with "
                    f"the name of the measure to apply the filter. Found {field!r}"
                )
                raise ValueError(msg)  # noqa: TRY004

            return {"field": field, "condition": Condition.model_validate(condition)}

        return value


class JoinOnColumns(BaseModel):
    """Columns to use for a Join operation."""

    left_on: Union[str, list[str]]
    right_on: Union[str, list[str]]


class JoinIntent(BaseModel):
    """Specifies the intent of the user to perform a Join operation."""

    on: Union[str, list[str], "JoinOnColumns", None] = None
    how: JoinType = JoinType.LEFT
    suffix: Optional[str] = None
    validate_relation: Literal["m:m", "m:1", "1:m", "1:1"] = "m:m"
    join_nulls: bool = False
    coalesce: Optional[bool] = None


class PaginationIntent(BaseModel):
    """Pagination instructions."""

    limit: Annotated[int, Field(ge=0)] = 0
    offset: Annotated[int, Field(ge=0)] = 0

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: object) -> object:
        """Parse the input value into a PaginationIntent dictionary."""
        if isinstance(value, str):
            value = (0, 0) if value == "" else value.strip().split(",")

        if isinstance(value, Sequence):
            if len(value) not in (1, 2):
                msg = (
                    f"Invalid pagination, must provide 1 or 2 integers. Found {value!r}"
                )
                raise ValueError(msg)
            return {"limit": value[0], "offset": value[1] if len(value) == 2 else 0}

        return value

    def as_tuple(self) -> tuple[int, int]:
        """Return the contents of this filter as a tuple of (limit, offset)."""
        return self.limit, self.offset


class SortingIntent(BaseModel):
    """Sorting instructions for internal use."""

    field: str
    order: AnyOrder

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: object) -> object:
        """Parse the input value into a SortingIntent dictionary."""
        if isinstance(value, str):
            field, order, *_ = f"{value}.asc".split(".")
            if not field:
                msg = "Sorting field must be a valid column name"
                raise ValueError(msg)
            return {"field": field, "order": Order.match(order) or Order.ASC}

        if isinstance(value, Sequence):
            field, order, *_ = [*value, "asc"]
            if not field:
                msg = "Sorting field must be a valid column name"
                raise ValueError(msg)
            return {"field": field, "order": Order.match(order) or Order.ASC}

        return value

    def as_tuple(self) -> tuple[str, AnyOrder]:
        """Return the contents of this filter as a tuple of (field, order)."""
        return self.field, self.order


class TimeRestriction(BaseModel):
    """Time-axis filtering instructions for internal use.

    Instances of this class are used to define a time restriction over the
    resulting data. It must always contain both fields.
    """

    level: str
    constraint: TimeConstraint

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: object) -> object:
        """Parse the input value into a TimeRestriction dictionary."""
        if isinstance(value, str):
            if "." not in value:
                msg = "Time restriction is malformed; tokens must be separated by dots"
                raise ValueError(msg)

            value = value.split(".")

        if isinstance(value, (list, tuple)):
            if not value:
                msg = (
                    "Time restriction needs to specify a time scale/level name, and a "
                    "constraint over it"
                )
                raise ValueError(msg)

            level, *constraint = value

            # normalize ['lt.2000'] or ["lt", 2000] to ["lt", 2000]
            constraint = ".".join(constraint).split(".")

            if not level:
                msg = (
                    "Time restriction needs to specify a level from a time dimension, "
                    "or a valid time scale available as level in this cube."
                )
                raise ValueError(msg)

            if not constraint:
                msg = (
                    "Time restriction needs to specify a constraint applied to the "
                    "provided level, which can be a relative time frame or a filtering "
                    "condition"
                )
                raise ValueError(msg)

            token = constraint[0].strip().lower()

            restriction_match = Restriction.match(token)
            if restriction_match is Restriction.COMPLETE:
                # extra params are unused at the moment, but available in case of
                constraint = (Restriction.COMPLETE, "")
            elif restriction_match in (
                Restriction.LATEST,
                Restriction.OLDEST,
                Restriction.TRAILING,
                Restriction.LEADING,
            ):
                amount = int(constraint[1] if len(constraint) > 1 else "1")
                if amount < 1:
                    msg = "Time Restriction periods must be greater than or equal to 1."
                    raise ValueError(msg)
                constraint = (restriction_match, amount)
            else:
                constraint = (Restriction.EXPR, Condition.model_validate(constraint))

            return {"level": level, "constraint": constraint}

        return value


class TopkIntent(BaseModel):
    """Limits the results to the K first/last elements.

    The subsets are determined by one or more levels and their associated value.
    The result dataset adds a new column that indicates the position of each element in
    that ranking.
    """

    levels: tuple[str, ...]
    measure: str
    order: AnyOrder = Order.DESC
    amount: int = 1

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: object) -> object:
        """Parse the input value into a TopkIntent dictionary."""
        if isinstance(value, str):
            amount, levels, measure, order, *_ = f"{value}....".split(".")
            if not levels:
                msg = (
                    "Topk 'levels' field must contain at least a valid level name from "
                    "the drilldowns in your request."
                )
                raise ValueError(msg)
            if not measure:
                msg = (
                    "Topk 'measure' field must contain a valid measure name from the "
                    "measures in your request."
                )
                raise ValueError(msg)
            return {
                "amount": amount,
                "levels": levels.split(","),
                "measure": measure,
                "order": Order.match(order) or Order.ASC,
            }

        return value


class GrowthIntent(BaseModel):
    """Calculation of growth with respect to a time parameter and a measure."""

    time_level: str
    measure: str
    method: Union[
        tuple[Literal["period"], int],
        tuple[Literal["fixed"], str],
        tuple[Literal["cagr"]],
    ] = ("period", 1)
    filter: bool = False

    @model_validator(mode="before")
    @classmethod
    def parse(cls, value: object) -> object:
        """Parse the input value into a GrowthIntent dictionary."""
        if not isinstance(value, str):
            return value

        if value.startswith(("period.", "fixed.", "cagr.")):
            method, time_level, measure, *params = value.split(".")
        else:
            time_level, measure, method, *params = value.split(".")

        if not time_level:
            msg = (
                "Growth calculation requires the name of a level from a time dimension "
                "included in your request."
            )
            raise ValueError(msg)
        if not measure:
            msg = (
                "Growth calculation must contain a valid measure name from the measures"
                " in your request."
            )
            raise ValueError(msg)
        if not method:
            msg = (
                "Growth calculation must specify a calculation method: "
                "'period', 'fixed', or 'cagr'.",
            )
            raise ValueError(msg)

        common = {"time_level": time_level, "measure": measure}

        if method == "cagr":
            # params: filter flag
            filter_flag = params[0] in TRUTHY_STRINGS if len(params) > 0 else False
            return {**common, "method": ("cagr",), "filter": filter_flag}

        if method == "fixed":
            # params: anchor member, filter flag
            anchor = params[0] if len(params) > 0 else None
            filter_flag = params[1] in TRUTHY_STRINGS if len(params) > 1 else False
            if not anchor:
                msg = "The 'fixed' growth method requires a member key after 'fixed', e.g. fixed.2020"
                raise ValueError(msg)
            return {**common, "method": ("fixed", anchor), "filter": filter_flag}

        if method == "period":
            # params: amount of periods, filter flag
            try:
                amount = int(params[0])
            except (IndexError, ValueError):
                msg = "The 'period' growth method requires an integer amount after 'period', e.g. period.1"
                raise ValueError(msg) from None
            filter_flag = params[1] in TRUTHY_STRINGS if len(params) > 1 else False
            return {**common, "method": ("period", amount), "filter": filter_flag}

        msg = "Growth calculation method must be one of: 'fixed', 'period', 'cagr'."
        raise ValueError(msg)


class Column(NamedTuple):
    """Represents a database column with its name and alias."""

    name: str
    alias: str

    @property
    def hash(self) -> str:
        """Return a unique hash for the column."""
        return shorthash(self.alias + self.name)


@dcls.dataclass(eq=True, frozen=True, order=False)
class HierarchyField:
    """Data slicing parameters based on a single Hierarchy.

    Contains the parameters associated to a slicing operation on the data,
    based on a single Hierarchy from a Cube's Dimension.
    """

    dimension: "DimensionTraverser"
    hierarchy: "HierarchyTraverser"
    levels: tuple["LevelField", ...]

    def __copy__(self) -> "HierarchyField":
        """Return a shallow copy of the HierarchyField."""
        return HierarchyField(
            dimension=self.dimension,
            hierarchy=self.hierarchy,
            levels=tuple(copy(level) for level in self.levels),
        )

    @property
    def alias(self) -> str:
        """Returns a deterministic unique short ID for the entity."""
        return shorthash(self.dimension.name + self.hierarchy.primary_key)

    @property
    def cut_levels(self) -> Iterable["LevelField"]:
        """Yield the levels containing a cut declaration."""
        return (item for item in self.levels if item.is_cut)

    @property
    def drilldown_levels(self) -> Iterable["LevelField"]:
        """Yield the levels declared as drilldowns."""
        return (item for item in self.levels if item.is_drilldown)

    @property
    def deepest_level(self) -> "LevelField":
        """Return the deepest LevelField requested in this Hierarchy."""
        # TODO: check if is needed to force this to use drilldowns only
        return self.levels[-1]

    @property
    def deepest_drilldown(self) -> "LevelField":
        """Return the deepest LevelField used as drilldown requested in this Hierarchy."""
        return list(self.drilldown_levels)[-1]

    @property
    def foreign_key(self) -> str:
        """Return the matching foreign key in the fact table.

        The column in the fact table of the Cube this Dimension belongs to,
        that matches the primary key of the items in the dim_table.
        """
        return self.dimension.foreign_key

    @property
    def has_drilldowns(self) -> bool:
        """Verify if any of the contained LevelFields is being used as a drilldown."""
        return any(self.drilldown_levels)

    @property
    def non_hierarchical(self) -> bool:
        """Retrieve the attribute "non_hierarchical" from the schema."""
        return self.hierarchy.non_hierarchical

    @property
    def primary_key(self) -> str:
        """Return the primary key in the dimension table.

        The column in the dimension table for the parent Dimension, which is
        used as primary key for the whole set of levels in the chosen Hierarchy.
        """
        return self.hierarchy.primary_key

    @property
    def table(self) -> Union[Table, InlineTable, None]:
        """Return the table to use as source for the Dimension data.

        If not set, the data is stored directly in the fact table for the Cube.
        """
        return self.hierarchy.table


@dcls.dataclass(eq=True, frozen=True, order=False, repr=False)
class LevelField:
    """Slice operation parameters for output columns.

    Specifies the columns each resulting group should provide to the output data.
    """

    level: "LevelTraverser"
    caption: Optional["PropertyTraverser"] = None
    column_alias: Optional[str] = None
    is_drilldown: bool = False
    members_exclude: set[str] = dcls.field(default_factory=set)
    members_include: set[str] = dcls.field(default_factory=set)
    properties: frozenset["PropertyTraverser"] = dcls.field(default_factory=frozenset)
    time_restriction: Optional[TimeRestriction] = None

    def __copy__(self) -> "LevelField":
        """Return a shallow copy of the LevelField."""
        return LevelField(
            level=self.level,
            column_alias=self.column_alias,
            caption=self.caption,
            is_drilldown=self.is_drilldown,
            members_exclude=set(self.members_exclude),
            members_include=set(self.members_include),
            properties=frozenset(self.properties),
            time_restriction=(
                self.time_restriction.model_copy() if self.time_restriction else None
            ),
        )

    def __repr__(self) -> str:
        """Return a string representation of the LevelField."""
        params = (
            f"name={self.level.name!r}",
            f"is_drilldown={self.is_drilldown!r}",
            f"alias={self.column_alias!r}",
            f"caption={self.caption!r}",
            f"properties={sorted(self.properties, key=lambda x: x.name)!r}",
            f"cut_exclude={sorted(self.members_exclude)!r}",
            f"cut_include={sorted(self.members_include)!r}",
            f"time_restriction={self.time_restriction!r}",
        )
        return f"{type(self).__name__}({', '.join(params)})"

    @property
    def alias(self) -> str:
        """Returns a deterministic unique short ID for the entity."""
        return shorthash(self.level.name + self.level.key_column)

    @property
    def is_cut(self) -> bool:
        """Checks if this level contains a cut declaration."""
        return len(self.members_exclude) + len(self.members_include) > 0

    @property
    def key_column(self) -> str:
        """Return the key_column of the level in this field."""
        return self.level.key_column

    @property
    def name(self) -> str:
        """Return the name of the Level in this field."""
        return self.level.name

    def id_column(self, locale: str) -> Column:
        """Return the column used as ID for the level in this field."""
        key_column = self.level.key_column
        if self.level.get_name_column(locale) is None:
            return Column(key_column, self.level.name)
        return Column(key_column, f"{self.level.name} ID")

    def iter_columns(self, locale: str) -> Generator[Column, Any, None]:
        """Yield the related columns in the database as defined by this object.

        This comprises Drilldown ID, Drilldown Caption, and Properties.
        """
        name = self.level.name
        key_column = self.level.key_column
        name_column = self.level.get_name_column(locale)
        if name_column is None:
            yield Column(key_column, name)
        else:
            yield Column(key_column, f"{name} ID")
            yield Column(name_column, name)
        for propty in self.properties:
            propty_column = propty.get_key_column(locale)
            yield Column(propty_column, propty.name)


@dcls.dataclass(eq=True, frozen=True, order=False, repr=False)
class MeasureField:
    """MeasureField dataclass.

    Contains the parameters needed to filter the data points returned by the
    query operation from the server.
    """

    measure: "AnyMeasure"
    column_alias: Optional[str] = None
    is_measure: bool = False
    constraint: Optional[Condition] = None
    with_ranking: Optional[Literal["asc", "desc"]] = None

    def __copy__(self) -> "MeasureField":
        """Return a shallow copy of the MeasureField."""
        return MeasureField(
            measure=self.measure,
            column_alias=self.column_alias,
            is_measure=self.is_measure,
            constraint=(
                copy(self.constraint)
                if isinstance(self.constraint, tuple)
                else self.constraint
            ),
            with_ranking=self.with_ranking,
        )

    def __repr__(self) -> str:
        """Return a string representation of the MeasureField."""
        params = (
            f"name={self.measure.name!r}",
            f"alias={self.column_alias!r}",
            f"is_measure={self.is_measure!r}",
            f"constraint={self.constraint!r}",
            f"with_ranking={self.with_ranking!r}",
        )
        return f"{type(self).__name__}({', '.join(params)})"

    @cached_property
    def alias_name(self) -> str:
        """Return a deterministic short hash of the name of the entity."""
        return shorthash(self.measure.name)

    @cached_property
    def alias_key(self) -> str:
        """Return a deterministic hash of the key column of the entity."""
        return shorthash(
            repr(self.measure.formula)
            if isinstance(self.measure, CalculatedMeasure)
            else self.measure.key_column,
        )

    @property
    def name(self) -> str:
        """Quick method to return the measure name."""
        return self.measure.name

    @property
    def aggregator_params(self) -> dict[str, str]:
        """Quick method to retrieve the measure aggregator params."""
        return self.measure.aggregator.get_params()

    @property
    def aggregator_type(self) -> str:
        """Quick method to retrieve the measure aggregator type."""
        return str(self.measure.aggregator)

    def get_source(self) -> Optional[str]:
        # TODO add locale compatibility
        """Quick method to obtain the source information of the measure."""
        return self.measure.annotations.get("source")

    @property
    def datatype(self) -> DataType:
        """Return the data type of the measure."""
        return DataType.FLOAT64
