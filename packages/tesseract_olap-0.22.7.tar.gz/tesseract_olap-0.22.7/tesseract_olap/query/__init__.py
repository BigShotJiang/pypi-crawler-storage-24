"""OLAP Query models and request handling.

This module defines the structures for representing OLAP queries (DataQuery, MembersQuery)
and the incoming API requests (DataRequest, MembersRequest). It includes the logic for
parsing, validating, and transforming these requests into executable query objects.

Key Components:
- Requests: Represents the raw user intent (e.g., from an API call).
- Queries: Represents the validated and resolved query ready for execution.
- Models: Helper classes for filtering, sorting, and other query operations.
"""

__all__ = (
    "AnyCondition",
    "AnyOrder",
    "AnyQuery",
    "AnyRequest",
    "Column",
    "ComparisonCondition",
    "ComparisonOperator",
    "CompositeCondition",
    "Condition",
    "CutIntent",
    "DataMultiQuery",
    "DataMultiRequest",
    "DataQuery",
    "DataRequest",
    "DataRequestParams",
    "FilterIntent",
    "GrowthIntent",
    "HierarchyField",
    "JoinIntent",
    "JoinOnColumns",
    "JoinType",
    "LevelField",
    "LogicOperator",
    "MeasureField",
    "MembersQuery",
    "MembersRequest",
    "MembersRequestParams",
    "MembershipCondition",
    "MembershipOperator",
    "NullityCondition",
    "NullityOperator",
    "Order",
    "PaginationIntent",
    "RequestWithRoles",
    "Restriction",
    "SortingIntent",
    "TimeConstraint",
    "TimeRestriction",
    "TopkIntent",
)

from .condition import (
    AnyCondition,
    ComparisonCondition,
    CompositeCondition,
    Condition,
    MembershipCondition,
    NullityCondition,
)
from .enums import (
    AnyOrder,
    ComparisonOperator,
    JoinType,
    LogicOperator,
    MembershipOperator,
    NullityOperator,
    Order,
    Restriction,
)
from .models import (
    Column,
    CutIntent,
    FilterIntent,
    GrowthIntent,
    HierarchyField,
    JoinIntent,
    JoinOnColumns,
    LevelField,
    MeasureField,
    PaginationIntent,
    SortingIntent,
    TimeConstraint,
    TimeRestriction,
    TopkIntent,
)
from .queries import AnyQuery, DataMultiQuery, DataQuery, MembersQuery
from .requests import (
    AnyRequest,
    DataMultiRequest,
    DataRequest,
    DataRequestParams,
    MembersRequest,
    MembersRequestParams,
    RequestWithRoles,
)
