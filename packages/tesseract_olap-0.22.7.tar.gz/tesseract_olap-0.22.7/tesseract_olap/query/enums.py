from typing import Literal, Union

from strenum import StrEnum
from typing_extensions import Self

AnyOrder = Union[Literal["asc", "desc"], "Order"]


class ParseableStrEnum(StrEnum):
    def __repr__(self) -> str:
        return f"{type(self).__name__}.{self.name}"

    def __str__(self) -> str:
        return self.value

    @classmethod
    def from_str(cls, string: str) -> Self:
        value = string.strip().lower()
        if not value:
            msg = f"Can't parse {cls.__name__} from empty string"
            raise ValueError(msg)
        value = EXTRA_VALUE_MAPPINGS.get((cls, value), value)
        return cls(value)

    @classmethod
    def match(cls, string: str) -> Union[Self, None]:
        try:
            return cls.from_str(string)
        except ValueError:
            return None


class ComparisonOperator(ParseableStrEnum):
    """Defines the available comparison operations."""

    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    EQ = "eq"
    NEQ = "neq"


class JoinType(ParseableStrEnum):
    """Defines the different types of join operations available to the user."""

    INNER = "inner"
    LEFT = "left"
    RIGHT = "right"
    FULL = "full"
    SEMI = "semi"
    ANTI = "anti"
    CROSS = "cross"


class LogicOperator(ParseableStrEnum):
    """Defines logical operations between conditional predicates."""

    AND = "and"
    OR = "or"
    XOR = "xor"


class MembershipOperator(ParseableStrEnum):
    """Specifies the membership relation of a value to a set."""

    IN = "in"
    NIN = "nin"


class NullityOperator(ParseableStrEnum):
    """Evaluates if a value is or not is NULL."""

    ISNULL = "isnull"
    ISNOTNULL = "isnotnull"


class Order(ParseableStrEnum):
    """Defines a direction to use in a sorting operation."""

    ASC = "asc"
    DESC = "desc"


class Restriction(ParseableStrEnum):
    COMPLETE = "complete"
    LATEST = "latest"
    OLDEST = "oldest"
    TRAILING = "trailing"
    LEADING = "leading"
    EXPR = "expr"


EXTRA_VALUE_MAPPINGS: dict[tuple[type[ParseableStrEnum], str], str] = {
    (ComparisonOperator, "!="): ComparisonOperator.NEQ,
    (ComparisonOperator, "<"): ComparisonOperator.LT,
    (ComparisonOperator, "<="): ComparisonOperator.LTE,
    (ComparisonOperator, "<>"): ComparisonOperator.NEQ,
    (ComparisonOperator, "="): ComparisonOperator.EQ,
    (ComparisonOperator, "=="): ComparisonOperator.EQ,
    (ComparisonOperator, ">"): ComparisonOperator.GT,
    (ComparisonOperator, ">="): ComparisonOperator.GTE,
    (LogicOperator, "&"): LogicOperator.AND,
    (LogicOperator, "^"): LogicOperator.XOR,
    (LogicOperator, "|"): LogicOperator.OR,
    (MembershipOperator, "notin"): MembershipOperator.NIN,
    (Restriction, "earliest"): Restriction.OLDEST,
    (Restriction, "last"): Restriction.LATEST,
}
