"""OLAP Server interface.

This module provides the `OlapServer` class, which serves as the high-level
entry point for interacting with the Tesseract OLAP engine. It orchestrates
the interaction between the Schema, the Backend, and the Query execution logic.
"""

__all__ = ("OlapServer",)

from .server import OlapServer
