"""LogicLayer integration for Tesseract OLAP.

This module provides the `TesseractModule`, a drop-in component for `LogicLayer`
applications. It exposes a set of API endpoints compatible with the Tesseract OLAP
standard, allowing easy integration into web services.

This module requires the `logiclayer` package to be installed. It is not imported by
default in the main `tesseract_olap` package to avoid hard dependencies.
"""

__all__ = (
    "DataSearchParams",
    "ResponseFormat",
    "TesseractModule",
)

from .dependencies import DataSearchParams
from .module import TesseractModule
from .response import ResponseFormat
