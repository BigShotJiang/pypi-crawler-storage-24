"""Schema exceptions module.

Defines the exceptions that can be raised during the parsing or validation of
a Schema, either from XML, JSON, or YAML sources, or during the traversal of
the Schema models.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import SchemaError

if TYPE_CHECKING:
    from lxml import etree


class XMLParseError(SchemaError):
    """Signal that an error happened while trying to parse a XML Schema."""


class MalformedXML(XMLParseError):
    """Signal that an unexpected node was found during XML parsing."""

    def __init__(self, expected: str, actual: str | etree._Element) -> None:
        """Initialize an instance of the error."""
        message = (
            f"A node '{actual}' was found while attempting to parse a '{expected}'"
        )
        super().__init__(message)


class InvalidXMLAttributeName(XMLParseError):
    """Signal that an invalid attribute was found in a node during XML parsing."""

    def __init__(self, node: str, node_name: str, attr: str) -> None:
        """Initialize an instance of the error."""
        message = (
            f"An attribute {attr!r} was found while attempting to parse "
            f"{node} {node_name!r}"
        )
        super().__init__(message)


class InvalidXMLAttributeValue(XMLParseError):
    """Signal that an invalid value was found in the attribute of a node."""

    def __init__(self, node: str, node_name: str, attr: str, value: str) -> None:
        """Initialize an instance of the error."""
        message = (
            f"An invalid value '{value}' for the '{attr}' attribute was found while "
            f"trying to parse {node} '{node_name}'"
        )
        super().__init__(message)


class MissingXMLNode(XMLParseError):
    """Signal that a required child node is missing in a XML node."""

    def __init__(self, node: str, node_name: str, child_node: str) -> None:
        """Initialize an instance of the error."""
        message = f"A '{child_node}' child node is missing in {node} '{node_name}'"
        super().__init__(message)


class MissingXMLAttribute(XMLParseError):
    """Signal that a required attribute is missing in a XML node."""

    def __init__(self, node: str, attr: str) -> None:
        """Initialize an instance of the error."""
        message = f"A required attribute '{attr}' is missing in a '{node}' node"
        super().__init__(message)


class JSONParseError(SchemaError):
    """Signal that an error happened while trying to parse a JSON Schema."""


class MalformedJSON(JSONParseError):
    """Signal that an unexpected object was found during JSON parsing."""

    def __init__(self, expected: str) -> None:
        """Initialize an instance of the error."""
        message = f"Expected '{expected}' during JSON parsing"
        super().__init__(message)


class MissingFieldError(SchemaError):
    """Signal that a required field is missing in a JSON or YAML Schema."""

    def __init__(self, entity: str, name: str, field: str) -> None:
        """Initialize an instance of the error."""
        message = f"A required field '{field}' is missing in {entity} '{name}'"
        super().__init__(message)


class InvalidFieldTypeError(SchemaError):
    """Signal that a field has an invalid type in a JSON or YAML Schema."""

    def __init__(self, entity: str, name: str, field: str, actual: str) -> None:
        """Initialize an instance of the error."""
        message = (
            f"An invalid value type '{actual}' for the '{field}' field was found while "
            f"trying to parse {entity} '{name}'"
        )
        super().__init__(message)


class ModelInconsistencyError(SchemaError):
    """Signal that a mandatory property couldn't be retrieved from a Shared/Usage entity combination."""

    def __init__(self, entity: str, name: str, attr: str) -> None:
        """Initialize an instance of the error."""
        message = f"There's a missing '{attr}' attribute in {entity} '{name}'."
        super().__init__(message)


class InvalidEntityNameFormatError(SchemaError):
    """Signal that the name of an Entity contains invalid characters."""

    def __init__(self, cube: str, entity: str, name: str) -> None:
        """Initialize an instance of the error."""
        message = (
            f"There's a {entity} with an invalid name '{name}' in the cube '{cube}'. "
            "Entity names can't contain the characters colon (:), dot (.), or comma (,)."
        )
        super().__init__(message)


class DuplicateKeyError(SchemaError):
    """Signal that the key of some property in the schema is shared in two nodes."""

    def __init__(self, key: str) -> None:
        """Initialize an instance of the error."""
        message = f"Key '{key}' is duplicated"
        super().__init__(message)


class DuplicateEntityNameError(SchemaError):
    """Signal that the name of an Entity is duplicated across its parent cube."""

    def __init__(self, cube: str, entity_prev: str, entity: str, name: str) -> None:
        """Initialize an instance of the error."""
        message = (
            f"In the cube '{cube}' a {entity_prev} and a {entity} share the same name '{name}'. "
            "Names of Measures, Levels and Properties must be unique across its cube."
        )
        super().__init__(message)


class UnresolvedReferenceError(SchemaError):
    """Signal that a declared Usage reference points to a non-existent shared Entity."""

    def __init__(self, entity: str, source: str) -> None:
        """Initialize an instance of the error."""
        message = f"An usage reference for '{source}' {entity} cannot be found."
        super().__init__(message)
