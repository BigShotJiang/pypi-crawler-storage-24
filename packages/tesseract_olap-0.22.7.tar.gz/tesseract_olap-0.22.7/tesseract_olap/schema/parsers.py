"""Common Schema parsing module.

Defines base classes for parsing Schema entities from dictionary structures (e.g. from JSON or YAML).
"""

import logging
from collections import OrderedDict
from collections.abc import Generator, Iterable
from typing import Any, Optional, TypeVar, Union

import immutables as immu
from typing_extensions import Self

from tesseract_olap.common import TRUTHY_STRINGS, T, is_numeric, numerify
from tesseract_olap.exceptions.schema import (
    DuplicateKeyError,
    InvalidFieldTypeError,
    MissingFieldError,
)

from . import models
from .aggregators import Aggregator
from .csv import parse_csv
from .enums import AggregatorType, DataType, DimensionType

logger = logging.getLogger(__name__)

DictEntity = Union[
    "DictSharedDimension",
    "DictHierarchy",
    "DictLevel",
    "DictProperty",
    "DictInlineTable",
    "DictCube",
    "DictDimensionUsage",
    "DictHierarchyUsage",
    "DictLevelUsage",
    "DictPropertyUsage",
    "DictPrivateDimension",
    "DictMeasure",
    "DictCalculatedMeasure",
]
AnyDictDimension = TypeVar(
    "AnyDictDimension",
    bound=Union["DictSharedDimension", "DictPrivateDimension"],
)
AnyDictEntity = TypeVar("AnyDictEntity", bound=DictEntity)

FKEY_TIME_FORMATS = (
    "YYYYMMDD",
    "YYYYMM",
    "YYYYQ",
    "YYYYQQ",
    "YYYY-Q",
    "YYYY-QQ",
    "YYYY",
)


class DictSchema(models.Schema):
    """Define a Schema entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], _index: int = 0) -> Self:
        """Parse a Schema dictionary object."""
        name = _get_prop(data, "name", "Schema")
        logger.debug("Parsing Schema '%s'", name)

        return cls(
            name=name,
            cube_map=OrderedDict(
                _raise_if_duplicate(_yield_children(data, "cubes", DictCube)),
            ),
            shared_dimension_map=immu.Map(
                _raise_if_duplicate(
                    _yield_children(data, "shared_dimensions", DictSharedDimension),
                ),
            ),
            shared_table_map=immu.Map(
                _raise_if_duplicate(
                    _yield_children(data, "shared_tables", DictInlineTable),
                ),
            ),
            default_locale=data.get("default_locale", "xx"),
            annotations=immu.Map(_yield_annotations(data)),
        )


class DictAccessControl(models.AccessControl):
    """Define access control rules parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any]) -> Self:
        """Parse access control rules from a dictionary object."""
        rules_data = data.get("access", [])
        if isinstance(rules_data, dict):
            rules_data = [rules_data]
        elif not isinstance(rules_data, list):
            rules_data = []

        rules = []
        for item in rules_data:
            rule = _get_prop(item, "rule", "Access") == "allow"
            roles = _get_prop(item, "roles", "Access")
            if isinstance(roles, str):
                roles = roles.split(",")
            rules.extend((role.strip(), rule) for role in roles)

        return cls(
            public=_get_boolean(data, "public", True),
            rules=immu.Map(_raise_if_duplicate(rules)),
        )


class DictCube(models.Cube):
    """Define a Cube entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], _index: int) -> Self:
        """Parse a Cube dictionary object."""
        name = _get_prop(data, "name", "Cube")
        logger.debug("Parsing Cube '%s'", name)

        table = _find_table_ref(data)
        if table is None:
            raise MissingFieldError("Cube", name, "table")
        dimension_map = OrderedDict(
            _raise_if_duplicate(
                _yield_children(
                    data,
                    "dimensions",
                    DictPrivateDimension,
                    DictDimensionUsage,
                ),
            ),
        )
        if len(dimension_map) == 0:
            raise MissingFieldError("Cube", name, "dimensions")
        measure_map = OrderedDict(
            _raise_if_duplicate(
                _yield_children(data, "measures", DictMeasure, DictCalculatedMeasure),
            ),
        )
        if len(measure_map) == 0:
            raise MissingFieldError("Cube", name, "measures")
        return cls(
            name=name,
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            acl=DictAccessControl.parse(data),
            dimension_map=dimension_map,
            measure_map=measure_map,
            table=table,
            annotations=immu.Map(_yield_annotations(data)),
            subset_table=_get_boolean(data, "subset_table", False),
            visible=_get_boolean(data, "visible", True),
        )


class DictDimensionUsage(models.DimensionUsage):
    """Define a dimension usage reference parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a DimensionUsage dictionary object."""
        name = _get_prop(data, "name", "DimensionUsage")
        logger.debug("Parsing DimensionUsage '%s'", name)

        time_format = data.get("fkey_time")
        if time_format not in (*FKEY_TIME_FORMATS, None):
            raise InvalidFieldTypeError(
                "DimensionUsage",
                name,
                "fkey_time",
                str(time_format),
            )

        return cls(
            name=name,
            source=_get_prop(data, "source", "DimensionUsage", name),
            foreign_key=_get_prop(data, "foreign_key", "DimensionUsage", name),
            annotations=immu.Map(_yield_annotations(data)),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            fkey_time_format=time_format,
            hierarchy_map=OrderedDict(
                _raise_if_duplicate(
                    _yield_children(
                        data,
                        "hierarchies",
                        DictHierarchyUsage,
                        key_attr="source",
                    ),
                ),
            ),
            visible=_get_boolean(data, "visible", True),
        )


class DictHierarchyUsage(models.HierarchyUsage):
    """Define a hierarchy usage reference parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a HierarchyUsage dictionary object."""
        source = _get_prop(data, "source", "HierarchyUsage")
        name = data.get("name", source)
        logger.debug("Parsing HierarchyUsage '%s'", name)

        return cls(
            name=name,
            source=source,
            annotations=immu.Map(_yield_annotations(data)),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            level_map=OrderedDict(
                _raise_if_duplicate(
                    _yield_children(data, "levels", DictLevelUsage, key_attr="source"),
                ),
            ),
            visible=_get_boolean(data, "visible", True),
        )


class DictLevelUsage(models.LevelUsage):
    """Define a level usage reference parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a LevelUsage dictionary object."""
        source = _get_prop(data, "source", "LevelUsage")
        name = data.get("name", source)
        logger.debug("Parsing LevelUsage '%s'", name)

        return cls(
            name=name,
            source=source,
            annotations=immu.Map(_yield_annotations(data)),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            property_map=OrderedDict(
                _raise_if_duplicate(
                    _yield_children(
                        data,
                        "properties",
                        DictPropertyUsage,
                        key_attr="source",
                    ),
                ),
            ),
            visible=_get_boolean(data, "visible", True),
        )


class DictPropertyUsage(models.PropertyUsage):
    """Define a property usage reference parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a PropertyUsage dictionary object."""
        source = _get_prop(data, "source", "PropertyUsage")
        name = data.get("name", source)
        logger.debug("Parsing PropertyUsage '%s'", name)

        return cls(
            name=name,
            source=source,
            annotations=immu.Map(_yield_annotations(data)),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            visible=_get_boolean(data, "visible", True),
        )


class DictTable(models.Table):
    """Define a physical table reference parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a Table dictionary object."""
        name = _get_prop(data, "name", "Table")
        logger.debug("Parsing Table '%s'", name)

        return cls(
            name=name,
            schema=data.get("schema"),
            primary_key=data.get("primary_key", "id"),
        )


class DictInlineTable(models.InlineTable):
    """Define an inline data table parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse an InlineTable dictionary object."""
        name = _get_prop(data, "name", "InlineTable")
        logger.debug("Parsing InlineTable '%s'", name)

        node_format = _get_prop(data, "format", "InlineTable", name)
        if node_format == "csv":
            node_format = "text/csv"
        if node_format == "tuples":
            headers, rows = cls.parse_tuples(data)
        elif node_format.startswith("text/csv"):
            content = data.get("data", "")
            if isinstance(content, list):
                content = "\n".join(content)
            lines = content.strip().splitlines()
            headers, *rows = parse_csv(lines, mimetype=node_format)
            headers = tuple(str(item) for item in headers)
        else:
            raise InvalidFieldTypeError("InlineTable", name, "format", node_format)
        return cls(
            name=name,
            headers=headers,
            types=cls.infer_types(rows),
            rows=tuple(rows),
        )

    @staticmethod
    def parse_tuples(
        data: dict[str, Any],
    ) -> tuple[tuple[str, ...], list[tuple[Union[str, float], ...]]]:
        """Parse data from an InlineTable with `tuples` format."""
        rows_data = data.get("data", [])
        if not isinstance(rows_data, list) or len(rows_data) < 2:
            raise MissingFieldError("InlineTable", data.get("name", ""), "data")
        rows = []
        for item in rows_data:
            if isinstance(item, (list, tuple)):
                rows.append(tuple(item))
            elif isinstance(item, str):
                import ast

                try:
                    val = ast.literal_eval(item)
                    if isinstance(val, (list, tuple)):
                        rows.append(tuple(val))
                    else:
                        rows.append((val,))
                except (ValueError, SyntaxError):
                    clean_item = item.strip()
                    if clean_item.startswith("(") and clean_item.endswith(")"):
                        clean_item = clean_item[1:-1]
                    rows.append(
                        tuple(parse_csv([clean_item], skipinitialspace=True)[0])
                    )
            else:
                rows.append((item,))
        headers = tuple(str(item) for item in rows[0])
        return headers, rows[1:]


class DictDimension(models.Dimension):
    """Define a dimension entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a Dimension dictionary object."""
        name = _get_prop(data, "name", "Dimension")
        logger.debug("Parsing Dimension '%s'", name)

        dim_type = DimensionType.from_str(data.get("type"))
        hierarchy_map = OrderedDict(
            _raise_if_duplicate(_yield_children(data, "hierarchies", DictHierarchy)),
        )
        default_hierarchy = data.get("default_hierarchy")
        if (
            default_hierarchy not in hierarchy_map or default_hierarchy is None
        ) and hierarchy_map:
            default_hierarchy = next(iter(hierarchy_map.keys()))
        if default_hierarchy is None:
            default_hierarchy = ""
        time_format = data.get("fkey_time") if dim_type is DimensionType.TIME else None
        if time_format not in (*FKEY_TIME_FORMATS, None):
            raise InvalidFieldTypeError(
                "Dimension",
                name,
                "fkey_time",
                str(time_format),
            )
        return cls(
            name=name,
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            default_hierarchy=default_hierarchy,
            dim_type=dim_type,
            foreign_key=data.get("foreign_key"),
            fkey_time_format=time_format,
            hierarchy_map=hierarchy_map,
            annotations=immu.Map(_yield_annotations(data)),
            visible=_get_boolean(data, "visible", True),
        )


class DictSharedDimension(DictDimension):
    """Define a shared dimension entity parsed from a dictionary."""


class DictPrivateDimension(DictDimension):
    """Define a private dimension entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a Private Dimension dictionary object."""
        dimension = super().parse(data, index)
        if dimension.foreign_key is None:
            raise MissingFieldError("Dimension", dimension.name, "foreign_key")
        return dimension


class DictHierarchy(models.Hierarchy):
    """Define a hierarchy entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a Hierarchy dictionary object."""
        name = _get_prop(data, "name", "Hierarchy")
        logger.debug("Parsing Hierarchy '%s'", name)

        level_map = OrderedDict(
            _raise_if_duplicate(_yield_children(data, "levels", DictLevel)),
        )
        if len(level_map) == 0:
            raise MissingFieldError("Hierarchy", name, "levels")
        default_pk = ""
        for item in level_map.values():
            default_pk = item.key_column
        return cls(
            name=name,
            primary_key=data.get("primary_key", default_pk),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            table=_find_table_ref(data),
            level_map=level_map,
            default_member=cls._parse_default_member(data),
            annotations=immu.Map(_yield_annotations(data)),
            visible=_get_boolean(data, "visible", True),
            non_hierarchical=_get_boolean(data, "non_hierarchical", False),
        )

    @staticmethod
    def _parse_default_member(data: dict[str, Any]) -> Optional[tuple[str, str]]:
        """Parse the default member attribute into a (level, member) tuple."""
        dm = data.get("default_member", "")
        if not dm:
            return None
        items: list[str] = dm.split(".", maxsplit=1)
        return (items[0], items[1]) if len(items) == 2 else None


class DictLevel(models.Level):
    """Define a level entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a Level dictionary object."""
        name = _get_prop(data, "name", "Level")
        logger.debug("Parsing Level '%s'", name)

        key_type = data.get("key_type")
        return cls(
            name=name,
            depth=index + 1,
            count=0,
            key_column=_get_prop(data, "key_column", "Level", name),
            key_type=DataType.from_str(key_type),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            name_column_map=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "name_column")),
            ),
            property_map=OrderedDict(
                _raise_if_duplicate(_yield_children(data, "properties", DictProperty)),
            ),
            time_scale=data.get("time_scale"),
            annotations=immu.Map(_yield_annotations(data)),
            visible=_get_boolean(data, "visible", True),
        )


class DictProperty(models.Property):
    """Define a property entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a Property dictionary object."""
        name = _get_prop(data, "name", "Property")
        logger.debug("Parsing Property '%s'", name)

        key_type = data.get("key_type")
        keycol_map = immu.Map(
            _raise_if_duplicate(_yield_locale_pairs(data, "key_column")),
        )
        if len(keycol_map) == 0:
            raise MissingFieldError("Property", name, "key_column")
        return cls(
            name=name,
            annotations=immu.Map(_yield_annotations(data)),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            key_column_map=keycol_map,
            key_type=DataType.from_str(key_type),
            visible=_get_boolean(data, "visible", True),
        )


class DictMeasure(models.Measure):
    """Define a measure entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a Measure dictionary object."""
        name = _get_prop(data, "name", "Measure")
        logger.debug("Parsing Measure '%s'", name)

        return cls(
            name=name,
            key_column=_get_prop(data, "key_column", "Measure", name),
            aggregator=cls._get_aggregator(data),
            annotations=immu.Map(_yield_annotations(data)),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            submeasures=immu.Map(
                _raise_if_duplicate(
                    _yield_children(data, "submeasures", cls, DictCalculatedMeasure),
                ),
            ),
            visible=_get_boolean(data, "visible", True),
        )

    @staticmethod
    def _get_aggregator(data: dict[str, Any]) -> Aggregator:
        """Parse the Aggregator parameter from the dictionary object."""
        agg_data = data.get("aggregator") or data.get("aggregation")
        name = data.get("name", "unknown")
        if agg_data is None:
            raise MissingFieldError("Measure", name, "aggregator")
        if isinstance(agg_data, str):
            agg_type_val = agg_data
            agg_args = {}
        elif isinstance(agg_data, dict):
            agg_type_val = agg_data.get("type")
            agg_args = {
                str(k).replace("-", "_"): numerify(v) if is_numeric(v) else str(v)
                for k, v in agg_data.items()
                if k != "type"
            }
        else:
            raise InvalidFieldTypeError(
                "Measure",
                name,
                "aggregator",
                type(agg_data).__name__,
            )
        try:
            agg_type = AggregatorType(agg_type_val)
        except ValueError:
            raise InvalidFieldTypeError(
                "Measure",
                name,
                "aggregator",
                str(agg_type_val),
            )
        else:
            agg_cls = Aggregator.from_enum(agg_type)
            return agg_cls.new(agg_args)


class DictCalculatedMeasure(models.CalculatedMeasure):
    """Define a calculated measure entity parsed from a dictionary."""

    @classmethod
    def parse(cls, data: dict[str, Any], index: int) -> Self:
        """Parse a CalculatedMeasure dictionary object."""
        name = _get_prop(data, "name", "CalculatedMeasure")
        logger.debug("Parsing CalculatedMeasure '%s'", name)

        formula = data.get("formula")
        if not formula:
            raise MissingFieldError("CalculatedMeasure", name, "formula")
        return cls(
            name=name,
            formula=cls._parse_formula(formula),
            annotations=immu.Map(_yield_annotations(data)),
            captions=immu.Map(
                _raise_if_duplicate(_yield_locale_pairs(data, "caption")),
            ),
            visible=_get_boolean(data, "visible", True),
        )


def _find_table_ref(
    data: dict[str, Any],
) -> Optional[Union[DictInlineTable, DictTable, str]]:
    """Find table reference in a dictionary object."""
    if "inline_table" in data:
        return DictInlineTable.parse(data["inline_table"], 0)
    if "table" in data:
        table_data = data["table"]
        if isinstance(table_data, str):
            return DictTable.parse({"name": table_data}, 0)
        return DictTable.parse(table_data, 0)
    if "table_usage" in data:
        usage = data["table_usage"]
        return (
            usage
            if isinstance(usage, str)
            else _get_prop(usage, "source", "TableUsage")
        )
    return None


def _get_prop(
    data: dict[str, Any],
    prop: str,
    parent_tag: str = "Object",
    parent_name: str = "unknown",
) -> Any:
    """Retrieve a property from a dict."""
    try:
        return data[prop]
    except KeyError:
        raise MissingFieldError(parent_tag, parent_name, prop)


def _get_boolean(data: dict[str, Any], prop: str, default: bool) -> bool:
    """Retrieve a boolean property from a dict."""
    value = data.get(prop)
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).lower() in TRUTHY_STRINGS


def _raise_if_duplicate(
    generator: Iterable[tuple[str, T]],
    exc_cls: type[DuplicateKeyError] = DuplicateKeyError,
) -> Generator[tuple[str, T], None, None]:
    """Check for duplicate keys in a generator and raise an exception if found."""
    seen_keys = set()
    for key, value in generator:
        if key in seen_keys:
            raise exc_cls(key)
        seen_keys.add(key)
        yield key, value


def _yield_annotations(data: dict[str, Any]) -> Iterable[tuple[str, Optional[str]]]:
    """Yield a pair of (name, value) for each Annotation in the dictionary object."""
    annotations = data.get("annotations", {})
    if isinstance(annotations, dict):
        return annotations.items()
    if isinstance(annotations, list):
        return [
            (item.get("name"), item.get("value", item.get("text")))
            for item in annotations
        ]
    return []


def _yield_children(
    data: dict[str, Any],
    prop: str,
    *child_classes: type[AnyDictEntity],
    key_attr: str = "name",
) -> Generator[tuple[str, AnyDictEntity], None, None]:
    """Yield parsed children from a list property."""
    items = data.get(prop, [])
    if isinstance(items, dict):
        # Support dict mapping name -> definition
        for name, definition in items.items():
            if isinstance(definition, dict):
                definition[key_attr] = name
                target_cls = _determine_class(definition, child_classes)
                yield name, target_cls.parse(definition, 0)
    elif isinstance(items, list):
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            target_cls = _determine_class(item, child_classes)
            yield (
                _get_prop(item, key_attr, target_cls.__name__),
                target_cls.parse(item, index),
            )


def _determine_class(
    item: dict[str, Any],
    classes: tuple[type[AnyDictEntity], ...],
) -> type[AnyDictEntity]:
    """Determine the appropriate class for a child entity based on its properties."""
    if len(classes) == 1:
        return classes[0]

    # Heuristic for Usage vs main class
    if "source" in item:
        for cls in classes:
            if "Usage" in cls.__name__:
                return cls
    else:
        for cls in classes:
            if "Usage" not in cls.__name__:
                return cls
    return classes[0]


def _yield_locale_pairs(
    data: dict[str, Any],
    prop: str,
) -> Generator[tuple[str, str], None, None]:
    """Yield (locale, value) pairs for a localized property."""
    val = data.get(prop)
    if val is not None:
        if isinstance(val, str):
            yield ("xx", val)
        elif isinstance(val, dict):
            yield from val.items()

    localized_data = data.get("localized", [])
    if isinstance(localized_data, list):
        for item in localized_data:
            if item.get("prop") == prop or item.get("attr") == prop:
                yield (item.get("locale"), item.get("value"))
