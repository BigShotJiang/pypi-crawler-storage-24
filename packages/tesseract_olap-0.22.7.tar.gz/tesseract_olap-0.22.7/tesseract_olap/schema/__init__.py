"""OLAP Schema definition and validation.

This module contains the classes and functions for defining the OLAP schema
(Cubes, Dimensions, Hierarchies, Measures). It supports parsing schemas from various
formats (XML, JSON, YAML) and validating them against the internal model.

Key Components:
- Models: Internal representation of Schema elements (Cube, Dimension, etc.).
- Validators: Tools for validating schema files (XSD validation).
- Parsers: Functions to load schemas from different file formats.
"""

__all__ = (
    "XSD",
    "AccessControl",
    "Aggregator",
    "AggregatorType",
    "Annotations",
    "AnyMeasure",
    "CalculatedMeasure",
    "Cube",
    "CubeTraverser",
    "DataType",
    "Dimension",
    "DimensionTraverser",
    "DimensionType",
    "DimensionUsage",
    "Entity",
    "Hierarchy",
    "HierarchyTraverser",
    "HierarchyUsage",
    "InlineTable",
    "Level",
    "LevelTraverser",
    "LevelUsage",
    "Measure",
    "Property",
    "PropertyTraverser",
    "PropertyUsage",
    "Schema",
    "SchemaTraverser",
    "Table",
    "TesseractCube",
    "TesseractDimension",
    "TesseractHierarchy",
    "TesseractLevel",
    "TesseractMeasure",
    "TesseractProperty",
    "TesseractSchema",
    "TimeScale",
    "parse_csv_schema",
    "parse_json_schema",
    "parse_xml_schema",
    "parse_yaml_schema",
    "validate_schema",
    "validate_xmlfile",
)

from .aggregators import Aggregator
from .csv import parse_csv_schema
from .enums import AggregatorType, DataType, DimensionType, TimeScale
from .json import parse_json_schema
from .models import (
    AccessControl,
    Annotations,
    AnyMeasure,
    CalculatedMeasure,
    Cube,
    Dimension,
    DimensionUsage,
    Entity,
    Hierarchy,
    HierarchyUsage,
    InlineTable,
    Level,
    LevelUsage,
    Measure,
    Property,
    PropertyUsage,
    Schema,
    Table,
)
from .public import (
    TesseractCube,
    TesseractDimension,
    TesseractHierarchy,
    TesseractLevel,
    TesseractMeasure,
    TesseractProperty,
    TesseractSchema,
)
from .traverse import (
    CubeTraverser,
    DimensionTraverser,
    HierarchyTraverser,
    LevelTraverser,
    PropertyTraverser,
    SchemaTraverser,
)
from .validator import XSD, validate_schema, validate_xmlfile
from .xml import parse_xml_schema
from .yaml import parse_yaml_schema
