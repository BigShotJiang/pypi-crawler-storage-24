"""JSON Schema parsing module.

Defines subclasses for the core Entity classes, parsed from a JSON document.
"""

import json
import logging
from pathlib import Path
from typing import TextIO, Union

from .parsers import (
    DictAccessControl as JSONAccessControl,
    DictCalculatedMeasure as JSONCalculatedMeasure,
    DictCube as JSONCube,
    DictDimension as JSONDimension,
    DictDimensionUsage as JSONDimensionUsage,
    DictHierarchy as JSONHierarchy,
    DictHierarchyUsage as JSONHierarchyUsage,
    DictInlineTable as JSONInlineTable,
    DictLevel as JSONLevel,
    DictLevelUsage as JSONLevelUsage,
    DictMeasure as JSONMeasure,
    DictPrivateDimension as JSONPrivateDimension,
    DictProperty as JSONProperty,
    DictPropertyUsage as JSONPropertyUsage,
    DictSchema as JSONSchema,
    DictSharedDimension as JSONSharedDimension,
    DictTable as JSONTable,
)

logger = logging.getLogger(__name__)

# Backward compatibility aliases for types
JSONEntity = Union[
    JSONSharedDimension,
    JSONHierarchy,
    JSONLevel,
    JSONProperty,
    JSONInlineTable,
    JSONCube,
    JSONDimensionUsage,
    JSONHierarchyUsage,
    JSONLevelUsage,
    JSONPropertyUsage,
    JSONPrivateDimension,
    JSONMeasure,
    JSONCalculatedMeasure,
]


def parse_json_schema(source: Union[str, Path, TextIO]) -> JSONSchema:
    """Attempt to parse an object into a JSONSchema.

    This function accepts:
    - A raw JSON :class:`str`
    - A local path (as a :class:`pathlib.Path`) to a JSON file
    - A not-binary read-only :class:`TextIO` instance for a file-like object
    """
    contents: Union[str, bytes]
    if isinstance(source, Path):
        contents = source.read_bytes()
    elif isinstance(source, str):
        if source.strip().startswith(("{", "[")) or "\n" in source:
            contents = source
        else:
            with open(source, "rb") as f:
                contents = f.read()
    else:
        contents = source.read()
    root = json.loads(contents)
    return JSONSchema.parse(root)
