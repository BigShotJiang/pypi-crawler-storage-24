<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema">
    <xsl:output method="html" encoding="UTF-8" indent="yes"/>

    <xsl:template match="/">
        <html>
            <head>
                <title>Schema Documentation</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 2em; line-height: 1.4; }
                    .element, .type { border: 1px solid #ccc; border-radius: 5px; padding: 1em; margin: 1em 0; }
                    .element .element { margin-left: 2em; }
                    h1 { border-bottom: 2px solid #ccc; padding-bottom: 10px; }
                    h2, h3, h4, h5 { margin-top: 0; color: #333; }
                    p { color: #666; }
                    table { border-collapse: collapse; width: 100%; margin-bottom: 1em;}
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; vertical-align: top; }
                    th { background-color: #f2f2f2; }
                    .code { font-family: monospace; background-color: #eee; padding: 2px 4px; border-radius: 3px; }
                    a { color: #06c; text-decoration: none; }
                    a:hover { text-decoration: underline; }
                </style>
            </head>
            <body>
                <h1>Schema Documentation</h1>
                <xsl:apply-templates select="/xs:schema/xs:element[@name='Schema']" mode="doc"/>
                <h2>Global elements</h2>
                <xsl:apply-templates select="/xs:schema/xs:element[@name and @name!='Schema']" mode="doc"/>
                <h2>Complex type definitions</h2>
                <xsl:apply-templates select="/xs:schema/xs:complexType[@name]" mode="doc"/>
                <h2>Simple type definitions</h2>
                <xsl:apply-templates select="/xs:schema/xs:simpleType[@name]" mode="doc"/>
            </body>
        </html>
    </xsl:template>

    <xsl:template match="xs:simpleType" mode="doc">
        <div class="type" id="type-{@name}">
            <h3>Type: <span class="code"><xsl:value-of select="@name"/></span></h3>
            <p><xsl:apply-templates select="xs:annotation/xs:documentation"/></p>
            <xsl:if test="xs:restriction/xs:enumeration">
                <h4>Allowed values</h4>
                <table>
                    <tr><th>Value</th></tr>
                    <xsl:for-each select="xs:restriction/xs:enumeration">
                        <tr><td><span class="code"><xsl:value-of select="@value"/></span></td></tr>
                    </xsl:for-each>
                </table>
            </xsl:if>
        </div>
    </xsl:template>

    <xsl:template match="xs:element" mode="doc">
        <div class="element" id="element-{@name}">
            <h3>Element: <span class="code">&lt;<xsl:value-of select="@name"/>&gt;</span></h3>
            <p><xsl:apply-templates select="xs:annotation/xs:documentation"/></p>
            <xsl:variable name="typeName" select="@type"/>
            <xsl:if test="xs:complexType">
                <xsl:apply-templates select="xs:complexType" mode="doc"/>
            </xsl:if>
            <xsl:if test="$typeName">
                <p>Type: <a href="#type-{$typeName}"><span class="code"><xsl:value-of select="$typeName"/></span></a></p>
            </xsl:if>
        </div>
    </xsl:template>

    <xsl:template match="xs:complexType" mode="doc">
        <div class="type">
            <xsl:if test="@name">
                <xsl:attribute name="id">type-<xsl:value-of select="@name"/></xsl:attribute>
                <h3>Type: <span class="code"><xsl:value-of select="@name"/></span></h3>
            </xsl:if>
            <p><xsl:apply-templates select="xs:annotation/xs:documentation"/></p>

            <h4>Attributes</h4>
            <xsl:if test="not(xs:attribute) and not(xs:simpleContent/xs:extension/xs:attribute)">
                <p>No attributes defined for this type.</p>
            </xsl:if>
            <xsl:if test="xs:attribute or xs:simpleContent/xs:extension/xs:attribute">
                <table>
                    <tr><th>Name</th><th>Description</th><th>Type</th><th>Use</th></tr>
                    <xsl:apply-templates select="xs:attribute"/>
                    <xsl:apply-templates select="xs:simpleContent/xs:extension/xs:attribute"/>
                </table>
            </xsl:if>

            <h4>Children</h4>
            <xsl:variable name="childElements" select="xs:choice/xs:element|xs:sequence/xs:element|xs:sequence/xs:choice/xs:element|xs:choice/xs:choice/xs:element"/>
            <xsl:if test="not($childElements) and not(xs:simpleContent/xs:extension)">
                <p>No children defined for this type.</p>
            </xsl:if>
            <xsl:if test="$childElements">
                <table>
                    <tr><th>Name</th><th>Description</th><th>Type</th><th>Occurrences</th></tr>
                    <xsl:apply-templates select="$childElements" mode="summary"/>
                </table>
            </xsl:if>
            <xsl:if test="xs:simpleContent/xs:extension">
                <h5>Content</h5>
                <p><xsl:apply-templates select="xs:simpleContent/xs:extension/xs:annotation/xs:documentation"/></p>
            </xsl:if>
        </div>
    </xsl:template>

    <xsl:template match="xs:attribute">
        <tr>
            <td><span class="code"><xsl:value-of select="@name"/></span></td>
            <td><xsl:apply-templates select="xs:annotation/xs:documentation"/></td>
            <td>
                <xsl:variable name="attrType" select="@type"/>
                <xsl:choose>
                    <xsl:when test="$attrType and not(starts-with($attrType, 'xs:'))">
                        <a href="#type-{$attrType}"><span class="code"><xsl:value-of select="$attrType"/></span></a>
                    </xsl:when>
                    <xsl:otherwise>
                        <span class="code"><xsl:value-of select="@type"/></span>
                    </xsl:otherwise>
                </xsl:choose>
            </td>
            <td><xsl:value-of select="@use"/></td>
        </tr>
    </xsl:template>

    <xsl:template match="xs:element" mode="summary">
        <tr>
            <td>
                <xsl:choose>
                    <xsl:when test="@ref">
                        <a href="#element-{@ref}"><span class="code">&lt;<xsl:value-of select="@ref"/>&gt;</span></a>
                    </xsl:when>
                    <xsl:otherwise>
                        <span class="code">&lt;<xsl:value-of select="@name"/>&gt;</span>
                    </xsl:otherwise>
                </xsl:choose>
            </td>
            <td><xsl:apply-templates select="xs:annotation/xs:documentation"/></td>
            <td>
                <xsl:variable name="childType" select="@type|@ref"/>
                <xsl:choose>
                    <xsl:when test="@ref">
                        <a href="#element-{@ref}"><span class="code"><xsl:value-of select="@ref"/></span></a>
                    </xsl:when>
                    <xsl:when test="@type and not(starts-with(@type, 'xs:'))">
                        <a href="#type-{@type}"><span class="code"><xsl:value-of select="@type"/></span></a>
                    </xsl:when>
                    <xsl:otherwise>
                        <span class="code"><xsl:value-of select="$childType"/></span>
                    </xsl:otherwise>
                </xsl:choose>
            </td>
            <td>
                <xsl:if test="@minOccurs!='1' or @maxOccurs!='1'">
                    <xsl:if test="@minOccurs">min: <xsl:value-of select="@minOccurs"/> </xsl:if>
                    <xsl:if test="@maxOccurs">max: <xsl:value-of select="@maxOccurs"/></xsl:if>
                </xsl:if>
                <xsl:if test="not(@minOccurs) and not(@maxOccurs)">1</xsl:if>
            </td>
        </tr>
    </xsl:template>

    <xsl:template match="xs:documentation">
        <xsl:value-of select="."/>
    </xsl:template>

</xsl:stylesheet>
