"""YAML Schema parsing module.

Defines subclasses for the core Entity classes, parsed from a YAML document.
"""

import logging
from pathlib import Path
from typing import TextIO, Union

import yaml

from .parsers import (
    DictAccessControl as YAMLAccessControl,
    DictCalculatedMeasure as YAMLCalculatedMeasure,
    DictCube as YAMLCube,
    DictDimension as YAMLDimension,
    DictDimensionUsage as YAMLDimensionUsage,
    DictHierarchy as YAMLHierarchy,
    DictHierarchyUsage as YAMLHierarchyUsage,
    DictInlineTable as YAMLInlineTable,
    DictLevel as YAMLLevel,
    DictLevelUsage as YAMLLevelUsage,
    DictMeasure as YAMLMeasure,
    DictPrivateDimension as YAMLPrivateDimension,
    DictProperty as YAMLProperty,
    DictPropertyUsage as YAMLPropertyUsage,
    DictSchema as YAMLSchema,
    DictSharedDimension as YAMLSharedDimension,
    DictTable as YAMLTable,
)

logger = logging.getLogger(__name__)

# Backward compatibility aliases for types
YAMLEntity = Union[
    YAMLAccessControl,
    YAMLCalculatedMeasure,
    YAMLCube,
    YAMLDimension,
    YAMLDimensionUsage,
    YAMLHierarchy,
    YAMLHierarchyUsage,
    YAMLInlineTable,
    YAMLLevel,
    YAMLLevelUsage,
    YAMLMeasure,
    YAMLPrivateDimension,
    YAMLProperty,
    YAMLPropertyUsage,
    YAMLSchema,
    YAMLSharedDimension,
    YAMLTable,
]


def parse_yaml_schema(source: Union[str, Path, TextIO]) -> YAMLSchema:
    """Attempt to parse an object into a YAMLSchema."""
    if isinstance(source, str):
        if source.strip().startswith(("{", "[")) or "\n" in source:
            data = yaml.safe_load(source)
        else:
            with open(source) as f:
                data = yaml.safe_load(f)
    elif isinstance(source, Path):
        with source.open("r") as f:
            data = yaml.safe_load(f)
    else:
        data = yaml.safe_load(source)
    return YAMLSchema.parse(data)
