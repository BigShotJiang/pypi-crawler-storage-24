import logging
from typing import Any, Callable, Union

from pyparsing import ParseResults
from pypika import analytics as an
from pypika import functions as fn
from pypika.enums import Arithmetic, Boolean
from pypika.queries import Selectable
from pypika.terms import (
    AggregateFunction,
    ArithmeticExpression,
    Case,
    ComplexCriterion,
    Criterion,
    Field,
    NullValue,
    Term,
    ValueWrapper,
)

from tesseract_olap.common import shorthash
from tesseract_olap.query import (
    AnyCondition,
    ComparisonCondition,
    ComparisonOperator,
    CompositeCondition,
    Condition,
    LogicOperator,
    MembershipCondition,
    MembershipOperator,
    NullityCondition,
    NullityOperator,
)
from tesseract_olap.schema import Measure

from .dialect import ArrayElement, Power, Quantile, TopK

logger = logging.getLogger(__name__)


def _get_aggregate(
    table: Selectable,
    measure: Measure,
) -> Union[fn.Function, ArithmeticExpression]:
    """Return the AggregateFunction instance needed to calculate a measure."""
    aggregator_type = str(measure.aggregator)
    column_hash = shorthash(measure.key_column)
    field = table.field(f"ms_{column_hash}")

    if aggregator_type == "Sum":
        return fn.Sum(field)

    if aggregator_type == "Count":
        return fn.Count(field)

    if aggregator_type == "Average":
        return fn.Avg(field)

    if aggregator_type == "Max":
        return fn.Max(field)

    if aggregator_type == "Min":
        return fn.Min(field)

    if aggregator_type == "Mode":
        return ArrayElement(TopK(1, field), 1)

    # elif aggregator_type == "BasicGroupedMedian":
    #     return fn.Abs()

    if aggregator_type == "WeightedSum":
        params = measure.aggregator.get_params()
        weight_field = table.field(f"msp_{column_hash}_weight")
        return fn.Sum(field * weight_field)

    if aggregator_type == "WeightedAverage":
        params = measure.aggregator.get_params()
        weight_field = table.field(f"msp_{column_hash}_weight")
        return AggregateFunction("avgWeighted", field, weight_field)

    # elif aggregator_type == "ReplicateWeightMoe":
    #     return fn.Abs()

    if aggregator_type == "CalculatedMoe":
        params = measure.aggregator.get_params()
        critical_value = ValueWrapper(params["critical_value"])
        term = fn.Sqrt(fn.Sum(Power(field / critical_value, 2)))
        return ArithmeticExpression(Arithmetic.mul, term, critical_value)

    if aggregator_type == "Median":
        return AggregateFunction("median", field)

    if aggregator_type == "Quantile":
        params = measure.aggregator.get_params()
        quantile_level = float(params["quantile_level"])
        return Quantile(quantile_level, field)

    if aggregator_type == "DistinctCount":
        # Count().distinct() might use a different function, configured in Clickhouse
        return AggregateFunction("uniqExact", field)

    # elif aggregator_type == "WeightedAverageMoe":
    #     return fn.Abs()

    msg = f"Aggregation type {aggregator_type!r} not implemented in Clickhouse module."
    raise NameError(msg)


def _filter_criterion(
    column: Field,
    condition: Union[Condition, AnyCondition],
    get_field: Callable[[str], Field],
) -> Criterion:
    """Apply comparison filters to query."""
    root = condition.root if isinstance(condition, Condition) else condition

    if isinstance(root, CompositeCondition):
        criteria = [_filter_criterion(column, c, get_field) for c in root.conditions]
        if not criteria:
            msg = "Composite condition must contain at least one condition"
            raise ValueError(msg)

        result = criteria[0]
        for next_crit in criteria[1:]:
            if root.operator == LogicOperator.AND:
                result &= next_crit
            elif root.operator == LogicOperator.OR:
                result |= next_crit
            elif root.operator == LogicOperator.XOR:
                result ^= next_crit

        return result

    if isinstance(root, NullityCondition):
        if root.operator == NullityOperator.ISNULL:
            return column.isnull()
        if root.operator == NullityOperator.ISNOTNULL:
            return column.isnotnull()

    if isinstance(root, MembershipCondition):
        if root.operator == MembershipOperator.IN:
            return column.isin(root.values)
        if root.operator == MembershipOperator.NIN:
            return column.notin(root.values)

    if isinstance(root, ComparisonCondition):
        ref = root.value
        if isinstance(ref, str):
            # heuristic: if get_field is provided, it must be because we expect field names.
            try:
                ref = get_field(ref)
            except (KeyError, ValueError, NameError):
                ref = ValueWrapper(ref)

        return _filter_comparison(column, root.operator, ref)

    msg = f"Invalid constraint: {root!r}"
    raise ValueError(msg)


def _filter_comparison(
    field: Field,
    comparison: ComparisonOperator,
    reference: Union[float, Term],
) -> Criterion:
    """Retrieve the comparison operator for the provided field."""
    # Note we must use == to also compare Enums values to strings
    if comparison == ComparisonOperator.GT:
        return field.gt(reference)
    if comparison == ComparisonOperator.GTE:
        return field.gte(reference)
    if comparison == ComparisonOperator.LT:
        return field.lt(reference)
    if comparison == ComparisonOperator.LTE:
        return field.lte(reference)
    if comparison == ComparisonOperator.EQ:
        return field.eq(reference)
    if comparison == ComparisonOperator.NEQ:
        return field.ne(reference)

    msg = f"Invalid criterion type: {comparison}"
    raise ValueError(msg)


def _transf_formula(tokens: Any, field_builder: Callable[[str], Field]) -> Term:
    """Transform a :class:`pyparsing.ParseResults` formula into a :class:`pypika.Term` object."""
    if isinstance(tokens, (int, float)):
        return ValueWrapper(tokens)

    if isinstance(tokens, str):
        if (tokens.startswith("'") and tokens.endswith("'")) or (
            tokens.startswith('"') and tokens.endswith('"')
        ):
            return ValueWrapper(tokens[1:-1])
        if tokens == "NULL":
            return NullValue()
        return field_builder(tokens)

    if isinstance(tokens, ParseResults):
        if len(tokens) == 1:
            return _transf_formula(tokens[0], field_builder)

        if tokens[0] == "CASE":
            case = Case()

            for item in tokens[1:]:
                if item[0] == "WHEN":
                    clauses = _transf_formula(item[1], field_builder)
                    expr = _transf_formula(item[3], field_builder)
                    case = case.when(clauses, expr)
                elif item[0] == "ELSE":
                    expr = _transf_formula(item[1], field_builder)
                    case = case.else_(expr)
                    break

            return case

        if tokens[0] == "NOT":
            # 2 tokens: ["NOT", A]
            return _transf_formula(tokens[1], field_builder).negate()

        if tokens[1] in ("AND", "OR", "XOR"):
            # 2n + 1 tokens: [A, "AND", B, "OR", C]
            left = _transf_formula(tokens[0], field_builder)
            for index in range(len(tokens) // 2):
                comparator = Boolean(tokens[index * 2 + 1])
                right = _transf_formula(tokens[index * 2 + 2], field_builder)
                left = ComplexCriterion(comparator, left, right)
            return left

        column = tokens[1]
        if not isinstance(column, str):
            msg = f"Malformed formula: {tokens}"
            raise TypeError(msg)

        if tokens[0] == "ISNULL":
            return field_builder(column).isnull()

        if tokens[0] == "ISNOTNULL":
            return field_builder(column).isnotnull()

        if tokens[0] == "TOTAL":
            return an.Sum(field_builder(column)).over()

        if tokens[0] == "SQRT":
            return fn.Sqrt(field_builder(column))

        if tokens[0] == "POW":
            return field_builder(column) ** tokens[2]

        # At this point expected formula is binary op, ensure odd number of params
        if len(tokens) % 2 == 0:
            msg = f"Malformed formula, binary operation expected: {tokens}"
            raise ValueError(msg)

        # Parse binary expressions left to right in order
        branch_left = _transf_formula(tokens[0], field_builder)

        for index in range(1, len(tokens), 2):
            operator = tokens[index]

            if not isinstance(operator, str):
                msg = f"Malformed formula, binary operator expected: {operator!r}"
                raise TypeError(msg)

            branch_right = _transf_formula(tokens[index + 1], field_builder)

            if operator == ">":
                branch_left = branch_left > branch_right
            elif operator == "<":
                branch_left = branch_left < branch_right
            elif operator == ">=":
                branch_left = branch_left >= branch_right
            elif operator == "<=":
                branch_left = branch_left <= branch_right
            elif operator == "==":
                branch_left = branch_left == branch_right
            elif operator in ("!=", "<>"):
                branch_left = branch_left != branch_right

            elif operator == "+":
                branch_left = branch_left + branch_right
            elif operator == "-":
                branch_left = branch_left - branch_right
            elif operator == "*":
                branch_left = branch_left * branch_right
            elif operator == "/":
                branch_left = branch_left / branch_right
            elif operator == "%":
                branch_left = branch_left % branch_right

            else:
                msg = f"Malformed formula, operator {operator!r} is not supported"
                raise ValueError(msg)

        return branch_left

    logger.error("Couldn't parse formula: <%s %r>", type(tokens).__name__, tokens)
    msg = f"Expression '{tokens!r}' can't be parsed"
    raise ValueError(msg)
