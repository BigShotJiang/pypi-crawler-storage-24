"""Valkey (Redis-compatible) cache implementation for Tesseract OLAP."""

import logging
from io import BytesIO
from typing import TYPE_CHECKING, Any, Union

import polars as pl
import redis as valkey
from httpx import URL
from pydantic import BaseModel, model_validator

from tesseract_olap.common import hide_dsn_password
from tesseract_olap.exceptions.backend import UpstreamInternalError, UpstreamNotPrepared

from .cache import CacheConnection, CacheConnectionStatus, CacheProvider

if TYPE_CHECKING:
    from tesseract_olap.query import AnyQuery

logger = logging.getLogger(__name__)


class ValkeyConnectionParams(BaseModel):
    """Parameters for connecting to a Valkey/Redis instance."""

    dsn: str
    default_ttl: int = -1

    @model_validator(mode="before")
    @classmethod
    def parse_dsn(cls, value: Union[str, URL, dict]) -> dict[str, Union[str, int]]:
        """Parse the DSN string and extract the default_ttl if present."""
        if isinstance(value, str):
            value = URL(value)

        if isinstance(value, URL):
            default_ttl = value.params.get("default_ttl") or -1
            value = value.copy_remove_param("default_ttl")
            return {"dsn": str(value), "default_ttl": default_ttl}

        return value


class ValkeyProvider(CacheProvider):
    """A CacheProvider for Valkey, a high-performance Redis-compatible data store."""

    connection_kwargs: dict[str, Any]
    dsn: str
    pool: valkey.ConnectionPool

    def __init__(self, dsn: Union[str, URL], **kwargs) -> None:
        """Initialize the Valkey provider with a DSN and optional connection arguments."""
        params = ValkeyConnectionParams.model_validate(dsn)
        pool = valkey.ConnectionPool.from_url(params.dsn, **kwargs)

        self.connection_kwargs = {
            "default_ttl": params.default_ttl,
            "single_connection_client": True,
        }
        self.dsn = params.dsn
        self.pool = pool

    def __repr__(self) -> str:
        """Return a string representation of the ValkeyProvider, masking the password."""
        return f"{type(self).__name__}(dsn='{hide_dsn_password(self.dsn)}')"

    def connect(self) -> "ValkeyConnection":
        """Create a new ValkeyConnection using the provider's connection pool."""
        return ValkeyConnection(self.pool, **self.connection_kwargs)

    def clear(self) -> None:
        """Flush the entire database in the Valkey instance."""
        with valkey.Redis(connection_pool=self.pool) as conn:
            _ = conn.flushdb()


class ValkeyConnection(CacheConnection):
    """An active connection to a Valkey instance for caching operations."""

    client: valkey.Redis
    default_ttl: int

    def __init__(
        self,
        pool: valkey.ConnectionPool,
        default_ttl: int = -1,
        **kwargs,
    ) -> None:
        """Initialize a ValkeyConnection from an existing connection pool."""
        self.client = valkey.Redis(connection_pool=pool, **kwargs)
        self.default_ttl = default_ttl

    @property
    def status(self) -> CacheConnectionStatus:
        """Return the current connection status by pinging the server."""
        if hasattr(self.client, "connection") and self.client.connection is None:
            return CacheConnectionStatus.CLOSED

        return (
            CacheConnectionStatus.CONNECTED
            if self.ping()
            else CacheConnectionStatus.CLOSED
        )

    def close(self) -> None:
        """Close the Valkey client connection."""
        self.client.close()
        self.client.connection = None

    def set(self, key: str, value: bytes) -> None:
        """Store raw bytes in Valkey with an optional TTL."""
        try:
            expires = self.default_ttl if self.default_ttl > 0 else None
            _ = self.client.set(key, value, ex=expires)
        except valkey.RedisError as exc:
            logger.exception("Error storing data under %r", key, exc_info=exc)

    def get(self, key: str) -> Union[bytes, None]:
        """Retrieve raw bytes from Valkey by key."""
        try:
            result = self.client.get(key)
        except valkey.ConnectionError as exc:
            logger.exception("Error retrieving data under %r", key, exc_info=exc)
        except valkey.RedisError as exc:
            logger.exception("Error retrieving data under %r", key, exc_info=exc)
        else:
            if result is None:
                return None
            if isinstance(result, bytes):
                return result
            logger.error("Unknown response under %r: %r", key, result)

    def exists(self, query: "AnyQuery") -> bool:
        """Check if a query result exists in the Valkey cache."""
        try:
            return self.client.exists(query.key) == 1
        except valkey.RedisError:
            return False

    def store(self, query: "AnyQuery", data: "pl.DataFrame") -> None:
        """Serialize and store a Polars DataFrame in Valkey using IPC format."""
        dfio = data.write_ipc(file=None, compression="lz4")
        if isinstance(dfio, BytesIO):
            self.set(query.key, dfio.getvalue())

    def retrieve(self, query: "AnyQuery") -> Union["pl.DataFrame", None]:
        """Retrieve and deserialize a Polars DataFrame from Valkey."""
        res = self.get(query.key)

        if isinstance(res, bytes):
            return pl.read_ipc(BytesIO(res))

        return None

    def ping(self) -> bool:
        """Ping the Valkey server to check if it's alive."""
        try:
            res = self.client.ping()
            return res in (True, "PONG", b"PONG")
        except valkey.RedisError:
            return False
