"""SQLite backend for Tesseract OLAP, providing caching capabilities."""

from __future__ import annotations

import logging
import sqlite3
import threading
import time
from collections.abc import Sequence
from io import BytesIO
from typing import TYPE_CHECKING

import polars as pl
from httpx import URL
from pydantic import BaseModel, model_validator

from .cache import CacheConnection, CacheConnectionStatus, CacheProvider

if TYPE_CHECKING:
    from tesseract_olap.query import AnyQuery

logger = logging.getLogger(__name__)


class SQLiteConnectionParams(BaseModel):
    """Configuration parameters for SQLite connection."""

    db_path: str
    default_ttl: int = -1

    @model_validator(mode="before")
    @classmethod
    def parse_dsn(cls, value: str | URL | dict) -> dict[str, str | int]:
        """Parse a DSN string into SQLite connection parameters."""
        if isinstance(value, str):
            if not value.startswith("file:"):
                value = "file:" + value
            value = URL(value)

        if isinstance(value, URL):
            default_ttl = value.params.get("default_ttl") or -1
            params = value.params.remove("default_ttl").set("cache", "shared")
            if value.path == ":memory:":
                params = params.set("mode", "memory")
                value = value.copy_with(path="tesseract_kv_store")
            db_path = str(value.copy_with(params=params))
            return {"db_path": db_path, "default_ttl": default_ttl}

        return value


class SQLiteCacheProvider(CacheProvider):
    """Implements a CacheProvider using a SQLite database as backend."""

    def __init__(self, dsn: str = ":memory:") -> None:
        """Initialize the SQLite Cache Provider."""
        params = SQLiteConnectionParams.model_validate(dsn)
        self.db_path = params.db_path
        self.default_ttl = params.default_ttl

        self._execute("PRAGMA journal_mode=WAL;")  # WAL mode stays across sessions

    def __repr__(self) -> str:
        """Return a string representation of the SQLite Cache Provider."""
        return f"{type(self).__name__}(db_path={self.db_path!r})"

    def connect(self) -> SQLiteCacheConnection:
        """Create a new Connection with the SQLite cache backend."""
        return SQLiteCacheConnection(self.db_path, default_ttl=self.default_ttl)

    def clear(self) -> None:
        """Clear all the stored keys in the SQLite database."""
        try:
            self._execute("DELETE FROM kv_store;")
        except sqlite3.OperationalError as exc:
            if "no such table" in exc.args[0]:
                return
            logger.exception("SQLiteCacheProvider exception", exc_info=exc)

    def _execute(self, stmt: str) -> None:
        """Execute a SQL statement against the SQLite database."""
        with sqlite3.connect(self.db_path, check_same_thread=False, uri=True) as conn:
            conn.execute(stmt)
            conn.commit()


class SQLiteCacheConnection(CacheConnection):
    """Implements a CacheConnection using a SQLite database as Backend."""

    def __init__(self, db_path: str, *, default_ttl: int = -1) -> None:
        """Initialize the SQLite Cache Connection."""
        self.db_path = db_path
        self.default_ttl = default_ttl
        self.conn = sqlite3.connect(self.db_path, check_same_thread=False, uri=True)
        self.lock = threading.Lock()
        self._last_purge = 0
        self._status = CacheConnectionStatus.CONNECTED

        _init_db(self.conn)

    @property
    def status(self) -> CacheConnectionStatus:
        """Return the current state of the Connection against the SQLite backend."""
        return self._status

    def close(self) -> None:
        """Close the connection against the SQLite database."""
        self.conn.close()
        self._status = CacheConnectionStatus.CLOSED

    def set(self, key: str, value: bytes, cube: str | None = None) -> None:
        """Store raw data in the SQLite database."""
        expires_at = (
            int(time.time()) + self.default_ttl if self.default_ttl > -1 else None
        )
        with self.lock:
            try:
                self.conn.execute(
                    "INSERT INTO kv_store (key, cube, value, expires_at) "
                    "VALUES (?, ?, ?, ?) "
                    "ON CONFLICT(key) DO UPDATE SET "
                    "cube=excluded.cube, value=excluded.value, "
                    "expires_at=excluded.expires_at;",
                    (key, cube, value, expires_at),
                )
                self.conn.commit()
            except sqlite3.OperationalError as exc:
                logger.exception("SQLiteCacheConnection exception", exc_info=exc)

    def get(self, key: str) -> bytes | None:
        """Retrieve raw data from the SQLite database."""
        with self.lock:
            now = int(time.time())
            try:
                self._purge(now)
                row = self.conn.execute(
                    "SELECT value FROM kv_store "
                    "WHERE key = ? AND (expires_at IS NULL OR expires_at > ?);",
                    (key, now),
                ).fetchone()
            except sqlite3.OperationalError as exc:
                row = None
                logger.exception("SQLiteCacheConnection exception", exc_info=exc)

            if row and isinstance(row[0], bytes):
                return row[0]

            return None

    def exists(self, query: AnyQuery) -> bool:
        """Check if the result of a query is stored in the SQLite database."""
        with self.lock:
            now = int(time.time())
            try:
                self._purge(now)
                row = self.conn.execute(
                    "SELECT count(key) FROM kv_store "
                    "WHERE key = ? AND (expires_at IS NULL OR expires_at > ?);",
                    (query.key, now),
                ).fetchone()
            except sqlite3.OperationalError as exc:
                row = None
                logger.exception("SQLiteCacheConnection exception", exc_info=exc)

        return isinstance(row, Sequence) and row[0] == 1

    def store(self, query: AnyQuery, data: pl.DataFrame) -> None:
        """Serialize a DataFrame and store it in the SQLite database."""
        dfio = data.write_ipc(file=None, compression="lz4")
        if dfio is not None:
            self.set(query.key, dfio.getvalue(), query.cube.name)

    def retrieve(self, query: AnyQuery) -> pl.DataFrame | None:
        """Retrieve a serialized DataFrame from the SQLite database and deserialize it."""
        row = self.get(query.key)
        if isinstance(row, bytes):
            return pl.read_ipc(BytesIO(row))

        return None

    def ping(self) -> bool:
        """Check the connection against the SQLite database is alive."""
        try:
            self.conn.execute("SELECT 1;")
        except sqlite3.Error:
            return False
        else:
            return True

    def _purge(self, now: int) -> None:
        """Delete expired records from the database."""
        if self.default_ttl > -1 and now - self._last_purge > self.default_ttl:
            self._last_purge = now
            self.conn.execute(
                "DELETE FROM kv_store "
                "WHERE expires_at IS NOT NULL AND expires_at <= ?;",
                (now,),
            )
            self.conn.commit()


def _init_db(conn: sqlite3.Connection) -> None:
    """Initialize the SQLite database schema."""
    conn.executescript(
        """\
CREATE TABLE IF NOT EXISTS kv_store (
    key TEXT PRIMARY KEY,
    cube TEXT,
    value BLOB,
    expires_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_expires_at ON kv_store (expires_at);
""",
    )
    conn.commit()
