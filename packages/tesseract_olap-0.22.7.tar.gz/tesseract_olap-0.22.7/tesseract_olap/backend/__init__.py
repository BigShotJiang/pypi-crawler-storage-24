"""Data backend interface and implementations.

This module provides the core abstractions for connecting to different data sources
(Backends), managing query execution (Sessions, Cursors), and handling result caching.
It also includes utilities for DataFrame manipulation and post-processing of query
results.

Key Components:
- Backend: Abstract base class for data source implementations.
- Session: Manages the connection lifecycle and query execution context.
- CacheProvider: Interface for implementing different caching strategies (e.g., LFU,
  Redis).
"""

__all__ = (
    "Backend",
    "CacheConnection",
    "CacheConnectionStatus",
    "CacheProvider",
    "Cursor",
    "DummyProvider",
    "JoinStep",
    "LfuProvider",
    "ParamManager",
    "Result",
    "Session",
    "apply_custom_cuts",
    "chunk_queries",
    "growth_calculation",
    "rename_columns",
    "topk_calculation",
)

from .cache import (
    CacheConnection,
    CacheConnectionStatus,
    CacheProvider,
    DummyProvider,
    LfuProvider,
)
from .dataframe import (
    JoinStep,
    apply_custom_cuts,
    growth_calculation,
    rename_columns,
    topk_calculation,
)
from .models import Backend, Cursor, ParamManager, Result, Session, chunk_queries
