"""Tests for CONNECTOR_BUILDER_MCP_WORKSPACE_ID workspace pinning."""

import pytest

from connector_builder_mcp._paths import _validate_workspace_id, get_workspace_id


@pytest.mark.parametrize(
    "workspace_id",
    [
        pytest.param("local-connector-build", id="typical-slug"),
        pytest.param("my-workspace-1", id="slug-with-number"),
        pytest.param("abc", id="short-slug"),
        pytest.param("a", id="single-char"),
        pytest.param("test123", id="alphanumeric-no-hyphens"),
    ],
)
def test_valid_workspace_ids(workspace_id: str) -> None:
    """Valid slugs should not raise."""
    _validate_workspace_id(workspace_id)  # should not raise


@pytest.mark.parametrize(
    "workspace_id",
    [
        pytest.param("UPPERCASE", id="uppercase"),
        pytest.param("has spaces", id="spaces"),
        pytest.param("-leading-hyphen", id="leading-hyphen"),
        pytest.param("trailing-hyphen-", id="trailing-hyphen"),
        pytest.param("double--hyphen", id="consecutive-hyphens"),
        pytest.param("special_chars!", id="special-chars"),
        pytest.param("under_score", id="underscore"),
        pytest.param("", id="empty-string"),
        pytest.param("CamelCase", id="camel-case"),
        pytest.param("with.dots", id="dots"),
        pytest.param("path/slash", id="slash"),
    ],
)
def test_invalid_workspace_ids(workspace_id: str) -> None:
    """Invalid slugs should cause SystemExit."""
    with pytest.raises(SystemExit):
        _validate_workspace_id(workspace_id)


def test_get_workspace_id_rejects_empty_string(monkeypatch: pytest.MonkeyPatch) -> None:
    """get_workspace_id treats empty string as set (not None) and returns it."""
    monkeypatch.setattr("connector_builder_mcp._paths.CONNECTOR_BUILDER_MCP_WORKSPACE_ID", "")
    # Empty string is not None, so get_workspace_id returns it (validation catches it at import time)
    assert get_workspace_id("any-session-id") == ""


def test_get_workspace_id_returns_env_var(monkeypatch: pytest.MonkeyPatch) -> None:
    """get_workspace_id returns the env-var workspace ID when set."""
    monkeypatch.setattr(
        "connector_builder_mcp._paths.CONNECTOR_BUILDER_MCP_WORKSPACE_ID", "my-workspace"
    )
    assert get_workspace_id("any-session-id") == "my-workspace"


def test_get_workspace_id_defaults_to_hashed_session(monkeypatch: pytest.MonkeyPatch) -> None:
    """get_workspace_id falls back to hashed session ID when env var is not set."""
    monkeypatch.setattr("connector_builder_mcp._paths.CONNECTOR_BUILDER_MCP_WORKSPACE_ID", None)
    result = get_workspace_id("test-session-id")
    assert result != "test-session-id"  # not raw
    assert len(result) == 64  # SHA-256 hex digest


def test_workspace_id_used_as_session_dir(
    tmp_path: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When workspace ID is set, it should be used directly as the session subdirectory name."""
    workspace_id = "my-test-workspace"
    monkeypatch.setattr(
        "connector_builder_mcp._paths.CONNECTOR_BUILDER_MCP_WORKSPACE_ID", workspace_id
    )
    monkeypatch.setattr("connector_builder_mcp._paths.SESSION_BASE_DIR", tmp_path)

    from connector_builder_mcp._paths import get_session_dir

    get_session_dir.cache_clear()

    session_dir = get_session_dir("any-session-id-ignored")

    assert session_dir.name == workspace_id
    assert session_dir.parent == tmp_path
    assert session_dir.exists()

    get_session_dir.cache_clear()


def test_without_workspace_id_uses_hash(
    tmp_path: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
) -> None:
    """When workspace ID is not set, session ID should be hashed as before."""
    monkeypatch.setattr("connector_builder_mcp._paths.CONNECTOR_BUILDER_MCP_WORKSPACE_ID", None)
    monkeypatch.setattr("connector_builder_mcp._paths.SESSION_BASE_DIR", tmp_path)

    from connector_builder_mcp._paths import get_session_dir

    get_session_dir.cache_clear()

    session_dir = get_session_dir("test-session-id")

    assert session_dir.name != "test-session-id"
    assert len(session_dir.name) == 64  # SHA-256 hex digest length
    assert session_dir.exists()

    get_session_dir.cache_clear()
