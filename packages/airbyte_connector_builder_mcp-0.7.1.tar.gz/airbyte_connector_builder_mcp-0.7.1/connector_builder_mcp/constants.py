"""Constants for the Connector Builder MCP server.

This module contains configuration constants and environment variable names
used throughout the Connector Builder MCP server.
"""

import os
import tempfile
from pathlib import Path


# =============================================================================
# Server Instructions
# =============================================================================
# This text is provided to AI agents via the MCP protocol's "instructions" field.
# It helps agents understand when to use this server's tools, especially when
# tool search is enabled. For more context, see:
# - FastMCP docs: https://gofastmcp.com/servers/overview
# - Claude tool search: https://www.anthropic.com/news/tool-use-improvements
# =============================================================================

MCP_SERVER_INSTRUCTIONS = """
AI-assisted Airbyte connector development server for building, validating, and
testing declarative connectors.

Use this server for:
- Creating and scaffolding new connector manifests from API specifications
- Validating manifest structure and schema without running the connector
- Testing individual streams against real APIs with automatic schema inference
- Running comprehensive connector readiness tests across all streams
- Retrieving connector builder documentation and examples
- Discovering similar connectors by feature (pagination, auth, etc.)
- Managing development checklists and tracking progress

Supported connector types:
- Declarative YAML connectors (default)

The server maintains session-isolated manifests and supports iterative
development with automatic schema updates from API responses.
""".strip()

# =============================================================================
# Session and Environment Configuration
# =============================================================================

CONNECTOR_BUILDER_MCP_SESSIONS_DIR = "CONNECTOR_BUILDER_MCP_SESSIONS_DIR"
"""Environment variable name for the session storage directory.

If set, this environment variable specifies the directory where session-specific
manifest files will be stored. If not set, defaults to a temporary directory.
"""

CONNECTOR_BUILDER_MCP_WORKSPACE_ID = os.environ.get("CONNECTOR_BUILDER_MCP_WORKSPACE_ID")
"""Optional workspace ID for pinning sessions across STDIO invocations.

When set, this workspace ID is used as the session directory slug instead of
the transport-layer session ID. This allows multiple STDIO invocations to share
the same workspace (manifest, checklist, history).

Must be a valid slug: lowercase alphanumeric characters and hyphens only
(e.g., 'local-connector-build', 'my-workspace-1').

Example: CONNECTOR_BUILDER_MCP_WORKSPACE_ID=local-connector-build
"""

SESSION_BASE_DIR = Path(
    os.environ.get(
        CONNECTOR_BUILDER_MCP_SESSIONS_DIR,
        str(Path(tempfile.gettempdir()) / "connector-builder-mcp-sessions"),
    )
)
"""Base directory for session-specific file storage.

This directory is used to store session-isolated manifest files and other
session-specific data. Each session gets its own subdirectory based on
a hashed session ID.
"""

MCP_SERVER_NAME = os.environ.get("CONNECTOR_BUILDER_MCP_SERVER_NAME", "connector-builder-mcp")
"""MCP server name used for server identification and resource URIs.

This can be overridden via the CONNECTOR_BUILDER_MCP_SERVER_NAME environment
variable to match the name configured in the client's MCP settings file.

Default: "connector-builder-mcp"
"""

CONNECTOR_BUILDER_STRATEGY = os.environ.get("CONNECTOR_BUILDER_STRATEGY")
"""Active build strategy name.

This environment variable controls which build strategy is active. Only one
strategy can be active at a time to avoid tool name conflicts. If not set,
the default strategy (declarative_yaml_v1) will be used.

Valid values:
- declarative_yaml_v1 (default)
- declarative_openapi_v3
- kotlin_source
- kotlin_destination

Example: CONNECTOR_BUILDER_STRATEGY=kotlin_source
"""

REQUIRE_SESSION_MANIFEST_IN_TOOL_CALLS = True
"""Whether to require a session manifest for tool calls.

If True, tool calls do not allow sending custom file paths or custom
manifest strings. When this is True (default), the scaffolded manifest
tool and the set_session_manifest_text tool must be used to set
the session manifest before calling other tools.

For now, this cannot be overridden by env vars. We will consider adding
that ability in the future if there is a strong use case.
"""
