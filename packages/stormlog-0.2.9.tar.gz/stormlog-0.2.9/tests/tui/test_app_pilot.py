import asyncio
import builtins
from pathlib import Path
from typing import Any

import pytest

pytest.importorskip("textual")

from textual.widgets import RichLog, TabbedContent, TabPane

import stormlog.tui.app as appmod
from stormlog.telemetry import telemetry_event_from_record
from stormlog.tui.app import GPUMemoryProfilerTUI

pytestmark = pytest.mark.tui_pilot


def _log_text(log: RichLog) -> str:
    return "\n".join(line.text for line in log.lines)


def _tab_labels(app: GPUMemoryProfilerTUI) -> list[str]:
    labels: list[str] = []

    for widget in app.query("*"):
        if widget.__class__.__name__ == "ContentTab":
            label = getattr(widget, "label", "")
            if hasattr(label, "plain"):
                label = label.plain
            labels.append(str(label))

    if labels:
        return labels

    for pane in app.query(TabPane):
        title = _pane_title(pane)
        labels.append(title)
    return labels


def _pane_title(pane: TabPane) -> str:
    title = getattr(pane, "title", None)
    if title is None:
        title = getattr(pane, "_title", "")
    if hasattr(title, "plain"):
        title = title.plain  # type: ignore[union-attr, unused-ignore]
    return str(title)


def _tab_id_by_title(app: GPUMemoryProfilerTUI, title: str) -> str:
    for pane in app.query(TabPane):
        if _pane_title(pane) == title:
            assert pane.id is not None
            return str(pane.id)
    raise AssertionError(f"Tab not found: {title}")


class _StubTrackerSession:
    def __init__(self) -> None:
        self.backend = "gpu"
        self.is_active = False
        self.start_calls = 0
        self.stop_calls = 0
        self.threshold_calls: list[tuple[float, float]] = []
        self.telemetry_events: list[Any] = []

    def start(self) -> None:
        self.start_calls += 1
        self.is_active = True

    def stop(self) -> None:
        self.stop_calls += 1
        self.is_active = False

    def set_thresholds(self, warning: float, critical: float) -> None:
        self.threshold_calls.append((warning, critical))

    def get_thresholds(self) -> dict[str, float]:
        return {
            "memory_warning_percent": 80.0,
            "memory_critical_percent": 95.0,
        }

    def get_device_label(self) -> str:
        return "stub-gpu"

    def set_auto_cleanup(self, enabled: bool) -> None:
        _ = enabled

    def get_statistics(self) -> dict[str, Any]:
        return {}

    def get_cleanup_stats(self) -> dict[str, Any]:
        return {}

    def pull_events(self) -> list[Any]:
        return []

    def get_memory_timeline(self, interval: float = 1.0) -> dict[str, list[Any]]:
        _ = interval
        return {}

    def get_telemetry_events(self) -> list[Any]:
        return list(self.telemetry_events)


class _StubCLIRunner:
    def __init__(self) -> None:
        self.is_running = False
        self.commands: list[str] = []
        self.cancel_calls = 0

    async def run(self, command: str, callback: Any) -> int:
        self.is_running = True
        self.commands.append(command)
        await callback("stdout", "hello")
        await callback("stderr", "warn")
        self.is_running = False
        return 17

    async def cancel(self) -> bool:
        self.cancel_calls += 1
        self.is_running = False
        return True


def _make_event(rank: int, timestamp_s: float = 1.0) -> Any:
    return telemetry_event_from_record(
        {
            "timestamp": timestamp_s,
            "event_type": "sample",
            "memory_allocated": 1000 + rank,
            "memory_reserved": 1200 + rank,
            "memory_change": 0,
            "device_used_bytes": 1300 + rank,
            "device_total_bytes": 10000,
            "device_id": rank,
            "collector": "stormlog.cuda_tracker",
            "sampling_interval_ms": 100,
            "pid": 1,
            "host": "host",
            "context": "pilot",
            "job_id": "job-1",
            "rank": rank,
            "local_rank": rank,
            "world_size": 2,
            "metadata": {},
        },
        permissive_legacy=True,
        default_collector="stormlog.cuda_tracker",
        default_sampling_interval_ms=100,
    )


def test_tab_rendering_and_key_bindings_r_f_g_t(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async def scenario() -> None:
        app = GPUMemoryProfilerTUI()
        async with app.run_test(headless=True, size=(140, 44)) as pilot:
            await pilot.pause()

            assert _tab_labels(app) == [
                "Overview",
                "PyTorch",
                "TensorFlow",
                "Monitoring",
                "Visualizations",
                "Diagnostics",
                "CLI & Actions",
            ]

            messages: list[tuple[str, str]] = []
            refresh_calls = {"count": 0}

            def fake_log_message(title: str, content: str) -> None:
                messages.append((title, content))

            def fake_refresh_content() -> None:
                refresh_calls["count"] += 1

            monkeypatch.setattr(app, "log_message", fake_log_message)
            monkeypatch.setattr(
                app.overview_panel, "refresh_content", fake_refresh_content
            )

            await pilot.press("f")
            await pilot.pause()
            assert app.focused is app.command_log

            await pilot.press("r")
            await pilot.pause()
            await pilot.press("g")
            await pilot.pause()
            await pilot.press("t")
            await pilot.pause()

            assert refresh_calls["count"] == 1
            assert ("Overview", "System overview refreshed.") in messages
            assert (
                "gpumemprof info",
                "Run: gpumemprof info\nRun: gpumemprof monitor --duration 30",
            ) in messages
            assert (
                "tfmemprof info",
                "Run: tfmemprof info\nRun: tfmemprof monitor --duration 30",
            ) in messages

    asyncio.run(scenario())


def test_monitoring_buttons_start_stop_apply_thresholds_clear_log() -> None:
    async def scenario() -> None:
        app = GPUMemoryProfilerTUI()
        async with app.run_test(headless=True, size=(140, 44)) as pilot:
            await pilot.pause()
            app.query_one(TabbedContent).active = _tab_id_by_title(app, "Monitoring")
            await pilot.pause()

            session = _StubTrackerSession()
            app.tracker_session = session  # type: ignore[assignment, unused-ignore]
            app._get_or_create_tracker_session = lambda: session  # type: ignore[assignment, method-assign, return-value, unused-ignore]

            await pilot.click("#btn-start-tracking")
            await pilot.pause()

            app.warning_input.value = "70"
            app.critical_input.value = "90"
            await pilot.click("#btn-apply-thresholds")
            await pilot.pause()

            app.monitor_log.write("transient line")
            await pilot.click("#btn-clear-monitor-log")
            await pilot.pause()

            await pilot.click("#btn-stop-tracking")
            await pilot.pause()

            monitor_text = _log_text(app.monitor_log)
            assert session.start_calls == 1
            assert session.stop_calls == 1
            assert (70.0, 90.0) in session.threshold_calls
            assert "Cleared monitoring log." in monitor_text
            assert "Live tracking stopped." in monitor_text

    asyncio.run(scenario())


def test_diagnostics_buttons_load_live_apply_filter_and_reset() -> None:
    async def scenario() -> None:
        app = GPUMemoryProfilerTUI()
        async with app.run_test(headless=True, size=(140, 44)) as pilot:
            await pilot.pause()
            app.query_one(TabbedContent).active = _tab_id_by_title(app, "Diagnostics")
            await pilot.pause()

            session = _StubTrackerSession()
            session.telemetry_events = [_make_event(0, 1.0), _make_event(1, 2.0)]
            app.tracker_session = session  # type: ignore[assignment, unused-ignore]
            app._get_or_create_tracker_session = lambda: session  # type: ignore[assignment, method-assign, return-value, unused-ignore]

            await pilot.click("#btn-diag-load-live")
            await pilot.pause()

            assert app._diagnostics_source == "live"
            assert len(app._diagnostics_events) == 2

            app.diagnostics_rank_filter_input.value = "1"
            await pilot.click("#btn-diag-apply-filter")
            await pilot.pause()
            assert app._diagnostics_selected_ranks == {1}

            await pilot.click("#btn-diag-reset-filter")
            await pilot.pause()
            assert app.diagnostics_rank_filter_input.value == "all"

            diagnostics_text = _log_text(app.diagnostics_log)
            assert "Loaded 2 live telemetry events" in diagnostics_text
            assert "Applied rank filter: 1" in diagnostics_text
            assert "Reset rank filter to: all" in diagnostics_text

    asyncio.run(scenario())


def test_diagnostics_artifact_actions_surface_loader_failures(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    errors = [RuntimeError("load boom"), RuntimeError("refresh boom")]

    def _fail_load(_paths: list[object]) -> object:
        raise errors.pop(0)

    monkeypatch.setattr(appmod, "load_distributed_artifacts", _fail_load)

    async def scenario() -> None:
        app = GPUMemoryProfilerTUI()
        async with app.run_test(headless=True, size=(140, 44)) as pilot:
            await pilot.pause()
            app.query_one(TabbedContent).active = _tab_id_by_title(app, "Diagnostics")
            await pilot.pause()

            app.diagnostics_path_input.value = str(tmp_path / "broken.json")
            await app.load_diagnostics_artifacts()
            await pilot.pause()

            assert app._diagnostics_source == "artifacts"
            assert app._diagnostics_events == []
            assert len(app._diagnostics_last_paths) == 1
            assert app._diagnostics_last_paths[0].name == "broken.json"

            diagnostics_text = _log_text(app.diagnostics_log)
            assert "Failed to load artifacts: load boom" in diagnostics_text

            await app.refresh_diagnostics()
            await pilot.pause()

            diagnostics_text = _log_text(app.diagnostics_log)
            assert "Failed to refresh artifacts: refresh boom" in diagnostics_text

    asyncio.run(scenario())


def test_save_timeline_plot_png_avoids_pyplot(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    original_import = builtins.__import__

    def _guarded_import(
        name: str,
        globals: dict[str, Any] | None = None,
        locals: dict[str, Any] | None = None,
        fromlist: tuple[str, ...] = (),
        level: int = 0,
    ) -> Any:
        if name == "matplotlib.pyplot":
            raise AssertionError("PNG export should not import matplotlib.pyplot")
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", _guarded_import)
    monkeypatch.chdir(tmp_path)

    app = GPUMemoryProfilerTUI()
    file_path = Path(
        app._save_timeline_plot(
            {
                "timestamps": [1.0, 2.0],
                "allocated": [1024**3, 2 * 1024**3],
                "reserved": [int(1.5 * 1024**3), int(2.5 * 1024**3)],
            },
            "png",
        )
    )

    assert file_path.exists()
    assert file_path.parent == tmp_path / "visualizations"
    assert file_path.suffix == ".png"


def test_save_timeline_plot_png_single_sample_uses_markers(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    from matplotlib.figure import Figure

    captured: dict[str, Any] = {}

    def _capture_savefig(
        self: Figure, file_path: str | Path, *args: Any, **kwargs: Any
    ) -> None:
        _ = (args, kwargs)
        captured["markers"] = [line.get_marker() for line in self.axes[0].lines]
        Path(file_path).write_bytes(b"png")

    monkeypatch.setattr(Figure, "savefig", _capture_savefig)
    monkeypatch.chdir(tmp_path)

    app = GPUMemoryProfilerTUI()
    file_path = Path(
        app._save_timeline_plot(
            {
                "timestamps": [1.0],
                "allocated": [1024**3],
                "reserved": [int(1.5 * 1024**3)],
            },
            "png",
        )
    )

    assert file_path.exists()
    assert captured["markers"] == ["o", "o"]


def test_save_timeline_plot_html_single_sample_uses_markers(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    go = pytest.importorskip("plotly.graph_objects")

    captured: dict[str, Any] = {}

    def _capture_write_html(
        self: Any, file_path: str | Path, *args: Any, **kwargs: Any
    ) -> None:
        _ = (args, kwargs)
        figure_json = self.to_plotly_json()
        captured["modes"] = [trace["mode"] for trace in figure_json["data"]]
        Path(file_path).write_text("<html></html>", encoding="utf-8")

    monkeypatch.setattr(go.Figure, "write_html", _capture_write_html)
    monkeypatch.chdir(tmp_path)

    app = GPUMemoryProfilerTUI()
    file_path = Path(
        app._save_timeline_plot(
            {
                "timestamps": [1.0],
                "allocated": [1024**3],
                "reserved": [int(1.5 * 1024**3)],
            },
            "html",
        )
    )

    assert file_path.exists()
    assert captured["modes"] == ["lines+markers", "lines+markers"]


def test_generate_visual_plot_dependency_error_logs_install_guidance(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async def scenario() -> None:
        app = GPUMemoryProfilerTUI()
        messages: list[tuple[str, str]] = []

        def _log_visual_message(title: str, content: str) -> None:
            messages.append((title, content))

        app.log_visual_message = _log_visual_message  # type: ignore[assignment, method-assign, unused-ignore]
        app._last_timeline = {
            "timestamps": [0.0, 1.0],
            "allocated": [1024**3, int(1.1 * 1024**3)],
            "reserved": [int(1.2 * 1024**3), int(1.3 * 1024**3)],
        }

        def _raise_visualization_import_error(
            _timeline: dict[str, Any], _format: str
        ) -> str:
            raise ImportError("dlopen(PIL/_imaging): incompatible architecture")

        monkeypatch.setattr(
            app,
            "_save_timeline_plot",
            _raise_visualization_import_error,
        )

        await app.generate_visual_plot("png")

        assert any(
            title == "Visualizations"
            and "Visualization dependencies are unavailable." in content
            and "stormlog[viz]" in content
            for title, content in messages
        )

    asyncio.run(scenario())


def test_cli_runner_run_stream_output_and_cancel() -> None:
    async def scenario() -> None:
        app = GPUMemoryProfilerTUI()
        async with app.run_test(headless=True, size=(140, 44)) as pilot:
            await pilot.pause()
            app.query_one(TabbedContent).active = _tab_id_by_title(app, "CLI & Actions")
            await pilot.pause()

            runner = _StubCLIRunner()
            app.cli_runner = runner  # type: ignore[assignment, unused-ignore]

            app.cli_command_input.value = "gpumemprof info"
            await pilot.click("#btn-cli-run")
            await pilot.pause()

            command_text = _log_text(app.command_log)
            assert runner.commands == ["gpumemprof info"]
            assert "gpumemprof info" in command_text
            assert "stdout hello" in command_text
            assert "stderr warn" in command_text
            assert "Command finished with exit code 17." in command_text

            runner.is_running = True
            await pilot.click("#btn-cli-cancel")
            await pilot.pause()

            assert runner.cancel_calls == 1
            assert "Command was cancelled." in _log_text(app.command_log)

    asyncio.run(scenario())


def test_cli_action_buttons_cover_diagnose_oom_and_matrix() -> None:
    async def scenario() -> None:
        app = GPUMemoryProfilerTUI()
        async with app.run_test(headless=True, size=(140, 44)) as pilot:
            await pilot.pause()
            app.query_one(TabbedContent).active = _tab_id_by_title(app, "CLI & Actions")
            await pilot.pause()

            runner = _StubCLIRunner()
            app.cli_runner = runner  # type: ignore[assignment, unused-ignore]

            await pilot.click("#btn-log-diagnose")
            await pilot.pause()
            await pilot.click("#btn-run-oom-scenario")
            await pilot.pause()
            await pilot.click("#btn-run-cap-matrix")
            await pilot.pause()

            assert runner.commands == [
                "gpumemprof diagnose --duration 0 --output artifacts/tui_diagnose",
                "python -m examples.scenarios.oom_flight_recorder_scenario --mode simulated",
                "python -m examples.cli.capability_matrix --mode smoke --target both --oom-mode simulated --skip-tui",
            ]

    asyncio.run(scenario())
