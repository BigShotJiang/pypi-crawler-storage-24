"""
Database utility functions for postgres_tools.
"""

import re
from sqlalchemy import text
from sqlalchemy.orm import Session


# ---------------------------------------------------------------------------
# PostgreSQL identifier validation
# ---------------------------------------------------------------------------

_PG_IDENTIFIER_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_$]*$")


def validate_pg_identifier(name: str) -> bool:
    """
    Return True if *name* is a safe, unquoted PostgreSQL identifier.
    Accepts letters, digits, underscores and dollar signs; max 63 chars.
    """
    return bool(name and _PG_IDENTIFIER_RE.match(name) and len(name) <= 63)


# ---------------------------------------------------------------------------
# pg_stat_statements helpers (version-aware)
# ---------------------------------------------------------------------------

def is_pg_stat_prerequisite_error(exc) -> bool:
    """
    Return True when *exc* signals that pg_stat_statements is not loaded via
    shared_preload_libraries.  Checks both the string representation and the
    underlying driver pgcode (55000 = object_not_in_prerequisite_state).
    Works with psycopg2, psycopg3, and any SQLAlchemy-wrapped variant.
    """
    msg = str(exc)
    if "ObjectNotInPrerequisiteState" in msg or "pg_stat_statements must be loaded via" in msg:
        return True
    for attr in ("orig", "__cause__"):
        cause = getattr(exc, attr, None)
        if cause and getattr(cause, "pgcode", None) == "55000":
            return True
    return False


def probe_pg_stat_statements(db: Session) -> tuple:
    """
    Check whether pg_stat_statements is installed AND accessible.

    Returns:
        (accessible: bool, reason: str | None)
        *reason* is None when accessible, or a human-friendly message when not.
    """
    # Step 1: is the extension registered?
    try:
        row = db.execute(text(
            "SELECT EXISTS("
            "  SELECT 1 FROM pg_extension WHERE extname='pg_stat_statements'"
            ") AS has_ext"
        )).mappings().first()
        if not row or not row["has_ext"]:
            return False, (
                "pg_stat_statements extension is not installed. "
                "Run: CREATE EXTENSION pg_stat_statements; "
                "and add 'pg_stat_statements' to shared_preload_libraries."
            )
    except Exception as e:
        return False, f"Could not query pg_extension: {e}"

    # Step 2: actually access the view (installed ≠ loaded)
    try:
        db.execute(text("SELECT 1 FROM pg_stat_statements LIMIT 0"))
        return True, None
    except Exception as e:
        try:
            db.rollback()
        except Exception:
            pass
        if is_pg_stat_prerequisite_error(e):
            return False, (
                "pg_stat_statements is installed but not loaded via "
                "shared_preload_libraries.  Add 'pg_stat_statements' to "
                "shared_preload_libraries in postgresql.conf and restart PostgreSQL."
            )
        return False, f"pg_stat_statements probe failed: {e}"


def get_pg_version(db: Session) -> int:
    """
    Return the PostgreSQL server version as an integer
    (e.g. 150002 for 15.2, 130008 for 13.8).
    Returns 0 when the version cannot be determined.
    """
    try:
        row = db.execute(text(
            "SELECT current_setting('server_version_num')::integer AS v"
        )).mappings().first()
        return int(row["v"]) if row else 0
    except Exception:
        return 0


def execute_query(db: Session, query_text, params=None):
    """
    Execute a query and return the result as a list of dictionaries.
    This function handles the connection properly to avoid "Connection is closed" errors.
    
    Args:
        db (Session): The SQLAlchemy session
        query_text: The SQL query text (can be a string or sqlalchemy.text)
        params (dict, optional): Parameters for the query
        
    Returns:
        list: List of dictionaries containing the query results
    """
    # Convert string query to text object if needed
    if isinstance(query_text, str):
        query_text = text(query_text)
        
    # Use params dict if provided, otherwise empty dict
    params = params or {}
    
    # Execute the query without using 'with' context manager
    # This prevents the connection from being closed prematurely
    conn = db.connection()
    try:
        result = conn.execute(query_text, params).mappings()
        return [dict(row) for row in result]
    except Exception as e:
        # Log the error but don't close the connection
        print(f"Error executing query: {e}")
        raise
    # Don't close the connection here - let SQLAlchemy manage it


def execute_query_first(db: Session, query_text, params=None):
    """
    Execute a query and return the first result as a dictionary.
    This function handles the connection properly to avoid "Connection is closed" errors.
    
    Args:
        db (Session): The SQLAlchemy session
        query_text: The SQL query text (can be a string or sqlalchemy.text)
        params (dict, optional): Parameters for the query
        
    Returns:
        dict: Dictionary containing the first row of the query result, or None if no results
    """
    # Convert string query to text object if needed
    if isinstance(query_text, str):
        query_text = text(query_text)
        
    # Use params dict if provided, otherwise empty dict
    params = params or {}
    
    # Execute the query without using 'with' context manager
    conn = db.connection()
    try:
        result = conn.execute(query_text, params).mappings().first()
        return dict(result) if result else None
    except Exception as e:
        # Log the error but don't close the connection
        print(f"Error executing query: {e}")
        raise
    # Don't close the connection here - let SQLAlchemy manage it


def execute_command(db: Session, command_text, params=None):
    """
    Execute a command (INSERT, UPDATE, DELETE, etc.) and commit the transaction.
    This function handles the connection properly to avoid "Connection is closed" errors.
    
    Args:
        db (Session): The SQLAlchemy session
        command_text: The SQL command text (can be a string or sqlalchemy.text)
        params (dict, optional): Parameters for the command
        
    Returns:
        None
    """
    # Convert string command to text object if needed
    if isinstance(command_text, str):
        command_text = text(command_text)
        
    # Use params dict if provided, otherwise empty dict
    params = params or {}
    
    # Execute the command without using 'with' context manager
    conn = db.connection()
    try:
        db.execute(command_text, params)
        db.commit()
    except Exception as e:
        # Log the error but don't close the connection
        print(f"Error executing command: {e}")
        db.rollback()
        raise
    # Don't close the connection here - let SQLAlchemy manage it