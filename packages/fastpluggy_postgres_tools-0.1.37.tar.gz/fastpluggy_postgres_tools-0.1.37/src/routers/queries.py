from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session

from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.widgets import CardWidget, TableWidget
from ..utils import execute_query, probe_pg_stat_statements, get_pg_version

queries_router = APIRouter(prefix="/queries", tags=["postgres_queries"])


def get_query_performance_statistics(db_manager: Session, limit: int = 10, include_p95: bool = False):
    """
    Get query performance statistics from pg_stat_statements.

    Uses probe_pg_stat_statements() to verify the extension is both installed
    *and* accessible (i.e. loaded via shared_preload_libraries), then selects
    the correct timing column for the running PostgreSQL version:
      - PG >= 13: total_exec_time
      - PG <  13: total_time
    Returns (rows, True) on success or ([], False) when the extension is absent
    or not loaded.  A human-readable *reason* string is returned as the third
    element so callers can display a helpful message.
    """
    accessible, reason = probe_pg_stat_statements(db_manager)
    if not accessible:
        return [], False, reason

    pg_ver = get_pg_version(db_manager)
    time_col = "total_exec_time" if pg_ver >= 130000 else "total_time"

    p95_column = ""
    if include_p95:
        p95_column = (
            f", (SELECT percentile_cont(0.95) WITHIN GROUP "
            f"(ORDER BY {time_col}/GREATEST(calls,1)) "
            f"FROM pg_stat_statements) AS p95_time"
        )

    query = f"""
        SELECT
          query,
          calls,
          {time_col} AS total_time,
          ROUND({time_col} / GREATEST(calls, 1), 2) AS mean_time,
          ROUND({time_col} / GREATEST(calls, 1), 2) AS avg_time,
          SUBSTRING(query, 1, 100) AS truncated_query
          {p95_column}
        FROM pg_stat_statements
        WHERE calls > 0
        ORDER BY {time_col} DESC
        LIMIT :limit
    """

    result = execute_query(db_manager, query, {"limit": limit})
    return result, True, None


@queries_router.get("")
async def get_queries_view(
    request: Request, 
    db=Depends(get_db), 
    view_builder=Depends(get_view_builder),
    limit: int = 10,
    include_p95: bool = False
):
    """
    Get the PostgreSQL query performance analysis view
    """
    # Create a connection manager for this request

    # Get query performance statistics
    query_stats, has_extension, unavail_reason = get_query_performance_statistics(db, limit, include_p95)

    if not has_extension:
        content_lines = [
            "<p>The <strong>pg_stat_statements</strong> extension is required for query performance analysis.</p>",
        ]
        if unavail_reason and "not installed" in unavail_reason:
            content_lines += [
                "<p>To install it, run the following SQL command as a superuser:</p>",
                "<pre>CREATE EXTENSION IF NOT EXISTS pg_stat_statements;</pre>",
                "<p>Then add <code>pg_stat_statements</code> to "
                "<code>shared_preload_libraries</code> in postgresql.conf and restart PostgreSQL.</p>",
            ]
        elif unavail_reason:
            content_lines += [
                f"<p><strong>Reason:</strong> {unavail_reason}</p>",
                "<p>To enable latency metrics, add <code>pg_stat_statements</code> to "
                "<code>shared_preload_libraries</code> in postgresql.conf and restart PostgreSQL.</p>",
            ]

        extension_card = CardWidget(
            title="pg_stat_statements Unavailable",
            content="\n".join(content_lines),
            links=[
                {
                    "url": request.url_for("install_pg_stat_statements"),
                    "text": "Install Extension",
                    "type": "primary"
                }
            ]
        )

        return view_builder.generate(
            request,
            title="PostgreSQL Query Performance Analysis",
            widgets=[extension_card]
        )

    # Create a table for query performance statistics
    query_table = TableWidget(
        title="Query Performance Statistics",
        endpoint="/postgres/queries",
        data=query_stats,
        description=f"Top {limit} queries by total execution time."
    )

    # Render the view
    return view_builder.generate(
        request,
        title="PostgreSQL Query Performance Analysis",
        widgets=[query_table]
    )


@queries_router.get("/install-pg-stat-statements", name="install_pg_stat_statements")
async def install_pg_stat_statements(request: Request, db=Depends(get_db)):
    """
    Install the pg_stat_statements extension
    """
    try:
        # Create a connection manager for this request

        # SQL command to install the extension
        query = "CREATE EXTENSION IF NOT EXISTS pg_stat_statements;"

        # Execute the SQL command using our connection manager
        db.execute_command(query)
    except Exception as e:
        # If there's an error, we'll just redirect back to the queries view
        # The error will be shown there if the extension still isn't installed
        print(f"Error installing pg_stat_statements extension: {e}")

    # Redirect back to the queries view
    return RedirectResponse(url=request.url_for("get_queries_view"))
