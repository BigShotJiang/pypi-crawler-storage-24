# Harnyard

Unified launcher for AI coding agent harnesses.

## Project Structure

```
bin/hy               # Legacy bash launcher (kept for reference)
src/harnyard/        # Python package
  cli.py             # Click CLI -- entry point
  profile.py         # Harness profile loading from YAML
  setup.py           # Symlink creation for non-native harnesses
  profiles/          # Bundled YAML profiles (package data)
profiles/            # Root-level profiles (dev reference, synced to src/)
pyproject.toml       # Package config (hatch build, click + pyyaml deps)
```

## Key Concepts

- **Canonical config**: `.claude/` is the source of truth for all harnesses
- **Native harnesses**: Claude Code and Copilot CLI read `.claude/` directly
- **Non-native harnesses**: Kiro (`.kiro/`) and Pi (`.pi/`) need symlinks from `.claude/`
- **Profiles**: YAML files defining how each harness maps to `.claude/` config
- **BusyBox pattern**: Symlink `copilot` -> `hy` and it detects the name it was called as

## Entry Points

- `hy` -- short command (primary)
- `harnyard` -- full name command (alias)
- Both are defined in pyproject.toml `[project.scripts]`

## Arguments

All unrecognized arguments are passed through to the harness binary. For example:
- `hy claude --version` passes `--version` to Claude Code
- `hy claude -p "explain this"` passes `-p "explain this"` to Claude Code

## Environment Variables

- `HARNYARD_HARNESS` -- default harness when none specified (e.g., `claude`)

## Testing

```bash
# Install in dev mode
cd ~/Code/github.com/mbailey/harnyard
uv venv && uv pip install -e .

# Run tests
.venv/bin/hy list
.venv/bin/hy status
.venv/bin/hy info kiro
.venv/bin/hy setup kiro      # Creates .kiro/ symlinks

# Zero-install test
uvx --from . hy list
```

## Conventions

- Use `--` (double hyphen) instead of em dashes in all files
- Profiles are YAML with keys: name, binary, aliases, config_dir, native, install, start
- Keep root profiles/ and src/harnyard/profiles/ in sync
- Branch protection: always create a branch before committing
