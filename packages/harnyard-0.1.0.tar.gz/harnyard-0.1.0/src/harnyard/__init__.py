"""Harnyard -- unified launcher for AI coding agent harnesses."""

__version__ = "0.1.0"
