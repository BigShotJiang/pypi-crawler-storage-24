# Harnyard

A unified launcher for AI coding agent harnesses.

Start Claude Code, Copilot CLI, Kiro CLI, or Pi from a single command -- with shared config under `.claude/`.

## Why

AI coding tools are converging on the same concepts: skills, plugins, MCP servers, hooks, and project context files. But each tool looks for config in different places and uses slightly different formats. Harnyard manages the translation layer so you can maintain one source of truth and launch any harness.

## Supported Harnesses

| Harness | Command | Config Dir | Status |
|---------|---------|------------|--------|
| Claude Code | `claude` | `.claude/` | Canonical |
| Copilot CLI | `copilot-cli` | `.claude/` | Native support |
| Kiro CLI | `kiro` | `.kiro/` | Symlink from `.claude/` |
| Pi | `pi` | `.pi/` | Symlink from `.claude/` |

## Quick Start

```bash
# Install
pip install harnyard     # or: pipx install harnyard

# Run without installing
uvx harnyard list

# Start a harness in the current project
hy claude              # Start Claude Code
hy copilot             # Start Copilot CLI
hy kiro                # Start Kiro CLI
hy pi                  # Start Pi Coding Agent

# Setup symlinks for a harness
hy setup kiro          # Create .kiro/ symlinks pointing to .claude/
hy setup pi            # Create .pi/ symlinks pointing to .claude/
hy setup --all         # Setup all harnesses

# Show what each harness sees
hy status              # Show config mapping for all harnesses
```

## How It Works

1. **Canonical config**: All your skills, plugins, agents, and context live under `.claude/`
2. **Harness profiles**: Harnyard knows where each tool looks for config
3. **Symlink bridge**: `hy setup <harness>` creates symlinks so each tool finds what it needs
4. **Launch**: `hy <harness>` starts the tool with the right flags and environment

## Config Mapping

```
.claude/                    # Canonical (Claude Code + Copilot CLI read natively)
├── CLAUDE.md               # Project context
├── settings.json           # Hooks, permissions
├── skills/                 # Skills (SKILL.md format)
├── agents/                 # Agent definitions
└── plugins/                # Plugin manifests

.kiro/  → symlinks          # Created by: hy setup kiro
├── steering.md  → ../.claude/CLAUDE.md
├── skills/      → ../.claude/skills/
└── powers/      # Converted from .claude/plugins/

.pi/    → symlinks          # Created by: hy setup pi
├── agent/extensions/ → ../.claude/plugins/
└── mcp.json         → ../.claude/mcp.json
```

## Harness Profiles

Each harness has a profile in `profiles/` that defines:

- **binary**: Command to run (e.g., `claude`, `kiro`)
- **config_dir**: Where it looks for config (e.g., `.kiro/`)
- **context_file**: Project context filename (e.g., `steering.md`)
- **skills_dir**: Where it looks for skills
- **mcp_config**: MCP server configuration file
- **setup**: Symlinks and conversions needed

## Philosophy

- **`.claude/` is the source of truth** -- other harness configs are derived
- **Non-destructive** -- `hy setup` only creates symlinks, never modifies `.claude/`
- **Optional** -- each harness still works standalone if you prefer manual config
- **Open source** -- contributions welcome for new harnesses

## Mascot

Dolly the sheep. Because all the harnesses are clones of the same concepts.

## License

MIT
