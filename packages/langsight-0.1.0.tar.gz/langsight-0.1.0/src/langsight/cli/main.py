from __future__ import annotations

import click

from langsight.cli.costs import costs
from langsight.cli.init import init
from langsight.cli.investigate import investigate
from langsight.cli.mcp_health import mcp_health
from langsight.cli.monitor import monitor
from langsight.cli.security_scan import security_scan
from langsight.cli.serve import serve
from langsight.cli.sessions import sessions


@click.group()
@click.version_option(version="0.1.0", prog_name="langsight")
def cli() -> None:
    """LangSight — MCP observability and security platform.

    Monitor MCP server health, detect security vulnerabilities,
    and attribute AI agent failures to their root cause.
    """


cli.add_command(costs)
cli.add_command(init)
cli.add_command(sessions)
cli.add_command(investigate)
cli.add_command(mcp_health)
cli.add_command(monitor)
cli.add_command(security_scan)
cli.add_command(serve)
