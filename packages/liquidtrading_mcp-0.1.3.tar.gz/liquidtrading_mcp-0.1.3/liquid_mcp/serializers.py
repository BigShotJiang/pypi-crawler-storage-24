"""Convert frozen dataclasses to plain dicts for MCP responses."""

from __future__ import annotations

import dataclasses
from typing import Any


def to_dict(obj: Any) -> dict[str, Any] | list | Any:
    """Convert a dataclass (or list of dataclasses) to JSON-safe dicts.

    Tuples are converted to lists for JSON compatibility.
    """
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        return {
            k: to_dict(v)
            for k, v in dataclasses.asdict(obj).items()
        }
    if isinstance(obj, (list, tuple)):
        return [to_dict(item) for item in obj]
    return obj
