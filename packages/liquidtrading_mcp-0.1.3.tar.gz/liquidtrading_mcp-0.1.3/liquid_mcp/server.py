"""FastMCP server instance and configuration."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

SERVER_INSTRUCTIONS = """\
Liquid Trading MCP Server — trade perpetual futures on onchain perp DEXs.

CORE CONCEPTS:
- All markets are perpetual futures (perps) — no expiry, no spot, no delivery.
- Positions are long or short. You profit from price moves, not from holding tokens.
- 'size' in place_order is USD notional, NOT token count. size=100 means $100 worth.
- Use calculate_token_amount to convert USD to tokens if needed.
- Funding rates are periodic payments between longs and shorts to anchor price to spot.
  Positive funding = longs pay shorts. Negative = shorts pay longs.
- Leverage amplifies both gains and losses. Each position has a liquidation price —
  if mark price reaches it, the position is force-closed.
- Margin modes: isolated (margin per position) or cross (shared across positions).

SCOPES:
- Read (api key): get_markets, get_ticker, get_orderbook, get_candles, get_account, get_balances, get_positions, get_open_orders, get_order
- Trade (api key): place_order, place_bracket_order, cancel_order, cancel_all_orders, close_position, set_tp_sl, update_leverage, update_margin

SAFETY:
- Minimum order size is $10
- MAX_ORDER_USD limits single order size (default $1000)
- DAILY_LOSS_LIMIT caps cumulative realized losses per UTC day (default $5000)
- Use dry_run=True on any trade tool to preview without executing
- Always call validate_trade before large orders
- Always set TP/SL on positions (use place_bracket_order for guaranteed risk params)

BEST PRACTICES:
1. Check get_positions before opening new trades — avoid unintended exposure stacking
2. Use validate_trade for pre-flight risk checks
3. Use dry_run=True for orders > 50% of MAX_ORDER_USD
4. Prefer place_bracket_order over place_order + set_tp_sl — atomic TP/SL is safer
5. Check get_account to verify available margin before trading
6. Monitor funding rate via get_ticker — holding against funding bleeds capital over time
7. Check liquidation price after adjusting leverage or margin on open positions

ERROR HANDLING:
- If a tool returns {"error": true}, read the "hint" and "next_steps" fields to recover
- On "Symbol not found": call get_markets to discover valid symbols (note: some symbols use prefixes like "k" for kilo-denominated tokens, e.g. kPEPE-PERP, kSHIB-PERP)
- On "Insufficient balance": call get_account to check available margin
- On "Rate limited": wait the suggested seconds in "retry_after" before retrying
- On "Authentication failed": API key/secret are required for all endpoints — verify both are set and valid
- On network errors (timeout/connection): check state with get_positions before retrying, as the order may have already filled onchain

SYMBOLS:
- Format: "BTC-PERP", "ETH-PERP", etc. Always verify with get_markets first.
- All symbols are perpetual contracts settled in USDC.
"""

mcp = FastMCP(
    "Liquid Trading",
    instructions=SERVER_INSTRUCTIONS,
)
