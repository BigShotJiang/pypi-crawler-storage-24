"""Singleton lazy Client factory."""

from __future__ import annotations

from liquidtrading import LiquidClient

from liquid_mcp.config import Config

_client: LiquidClient | None = None


def get_client(config: Config) -> LiquidClient:
    """Return a shared LiquidClient instance, creating it on first call."""
    global _client
    if _client is None:
        kwargs: dict = {
            "api_key": config.api_key,
            "api_secret": config.api_secret,
        }
        if config.base_url is not None:
            kwargs["base_url"] = config.base_url
        _client = LiquidClient(**kwargs)
    return _client


def reset_client() -> None:
    """Close and reset the shared client (for testing)."""
    global _client
    if _client is not None:
        _client.close()
        _client = None
