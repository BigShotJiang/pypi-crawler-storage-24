"""Liquid MCP Server — trade via any MCP-compatible AI agent."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

import liquid_mcp.prompts  # noqa: F401
import liquid_mcp.resources  # noqa: F401
import liquid_mcp.tools  # noqa: F401
from liquid_mcp.server import mcp


def _usage() -> str:
    return """Usage: liquidtrading-mcp [--http] [--help] [--version]

Run the Liquid Trading MCP server over stdio by default.

Options:
  --http       Run using streamable HTTP on 0.0.0.0:4243
  -h, --help   Show this help message and exit
  -V, --version
               Show the package version and exit
"""


def main(argv: list[str] | None = None) -> None:
    """Entry point for the liquidtrading-mcp CLI command."""
    import sys

    args = list(sys.argv[1:] if argv is None else argv)

    if any(arg in ("-h", "--help") for arg in args):
        print(_usage())
        return

    if any(arg in ("-V", "--version") for arg in args):
        try:
            print(version("liquidtrading-mcp"))
        except PackageNotFoundError:
            print("unknown")
        return

    invalid = [arg for arg in args if arg != "--http"]
    if invalid:
        raise SystemExit(
            f"Unknown argument: {invalid[0]}\n\n{_usage()}"
        )

    if "--http" in args:
        mcp.run(transport="streamable-http", host="0.0.0.0", port=4243)
    else:
        mcp.run()


__all__ = ["mcp", "main"]
