"""Tests for account tools."""

from __future__ import annotations

from unittest.mock import patch

from liquidtrading.errors import AuthenticationError, RateLimitError


class TestAccountTools:
    def test_get_account(self, mock_client):
        with patch("liquid_mcp.tools.account.get_client", return_value=mock_client):
            from liquid_mcp.tools.account import get_account

            result = get_account(ctx=None)
            assert result["equity"] == 10000.0
            assert result["available_balance"] == 8000.0
            assert "next_steps" in result

    def test_get_account_auth_error(self, mock_client):
        mock_client.get_account.side_effect = AuthenticationError(
            code="INVALID_API_KEY", message="Invalid API key",
        )
        with patch("liquid_mcp.tools.account.get_client", return_value=mock_client):
            from liquid_mcp.tools.account import get_account

            result = get_account(ctx=None)
            assert result["error"] is True
            assert "authentication" in result["hint"].lower()

    def test_get_balances(self, mock_client):
        with patch("liquid_mcp.tools.account.get_client", return_value=mock_client):
            from liquid_mcp.tools.account import get_balances

            result = get_balances(ctx=None)
            assert result["exchange"] == "hyperliquid"
            assert result["equity"] == 10000.0
            assert "next_steps" in result

    def test_get_balances_rate_limited(self, mock_client):
        mock_client.get_balances.side_effect = RateLimitError(
            code="RATE_LIMIT_EXCEEDED", message="Too many requests",
            status_code=429, retry_after=2.0,
        )
        with patch("liquid_mcp.tools.account.get_client", return_value=mock_client):
            from liquid_mcp.tools.account import get_balances

            result = get_balances(ctx=None)
            assert result["error"] is True
            assert result["retry_after"] == 2.0

    def test_get_positions(self, mock_client):
        with patch("liquid_mcp.tools.account.get_client", return_value=mock_client):
            from liquid_mcp.tools.account import get_positions

            result = get_positions(ctx=None)
            assert len(result["positions"]) == 1
            assert result["positions"][0]["symbol"] == "BTC-PERP"
            assert "next_steps" in result
