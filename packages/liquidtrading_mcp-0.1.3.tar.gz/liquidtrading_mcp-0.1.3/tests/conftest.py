"""Shared fixtures for liquidtrading-mcp tests."""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from liquidtrading.models import (
    Account,
    Balance,
    Candle,
    CloseResult,
    CrossMargin,
    LeverageResult,
    MarginResult,
    OpenOrder,
    Order,
    Orderbook,
    OrderbookLevel,
    Position,
    Ticker,
    TpSlResult,
)
from liquid_mcp.config import Config, set_config, reset_config
from liquid_mcp.guardrails import reset_loss_tracker


@pytest.fixture(autouse=True)
def _setup_config():
    """Set a test config before each test, reset after."""
    cfg = Config(
        api_key="lq_test",
        api_secret="sk_test",
        base_url=None,
        max_order_usd=1000.0,
        daily_loss_limit=5000.0,
        audit_path="/tmp/test-trades.jsonl",
    )
    set_config(cfg)
    yield
    reset_config()
    reset_loss_tracker()


@pytest.fixture()
def config():
    return Config(
        api_key="lq_test",
        api_secret="sk_test",
        base_url=None,
        max_order_usd=1000.0,
        daily_loss_limit=5000.0,
        audit_path="/tmp/test-trades.jsonl",
    )


@pytest.fixture()
def mock_client():
    client = MagicMock()

    client.get_markets.return_value = [
        {"symbol": "BTC-PERP", "ticker": "BTC", "exchange": "hyperliquid",
         "max_leverage": 200, "sz_decimals": 5},
    ]

    client.get_ticker.return_value = Ticker(
        symbol="BTC-PERP", mark_price=50000.0,
        volume_24h=1000000.0, change_24h=2.5, funding_rate=0.001,
    )

    client.get_orderbook.return_value = Orderbook(
        symbol="BTC-PERP",
        bids=(OrderbookLevel(price=49999.0, size=1.5, count=3),),
        asks=(OrderbookLevel(price=50001.0, size=1.2, count=2),),
        timestamp=1700000000,
    )

    client.get_candles.return_value = [
        Candle(timestamp=1700000000, open=49000.0, high=50500.0,
               low=48500.0, close=50000.0, volume=500.0),
    ]

    client.get_account.return_value = Account(
        equity=10000.0, margin_used=2000.0,
        available_balance=8000.0, account_value=10000.0,
    )

    client.get_balances.return_value = Balance(
        exchange="hyperliquid", equity=10000.0,
        available_balance=8000.0, margin_used=2000.0,
        cross_margin=CrossMargin(
            account_value=10000.0, total_margin_used=2000.0, total_ntl_pos=5000.0,
        ),
    )

    client.get_positions.return_value = [
        Position(
            symbol="BTC-PERP", side="buy", size=100.0,
            entry_price=49000.0, leverage=5.0, unrealized_pnl=200.0,
            mark_price=50000.0, liquidation_price=40000.0, margin_used=1000.0,
        ),
    ]

    client.place_order.return_value = Order(
        order_id="ord_123", symbol="BTC-PERP", side="buy", type="market",
        size=100.0, price=None, leverage=1, status="filled",
        exchange="hyperliquid", tp=None, sl=None,
        reduce_only=False, created_at="2024-01-01T00:00:00Z",
    )

    client.get_open_orders.return_value = [
        OpenOrder(
            order_id="ord_456", symbol="BTC-PERP", side="buy",
            size=50.0, price=48000.0, timestamp=1700000000,
        ),
    ]

    client.get_order.return_value = Order(
        order_id="ord_123", symbol="BTC-PERP", side="buy", type="market",
        size=100.0, price=None, leverage=1, status="filled",
        exchange="hyperliquid", tp=None, sl=None,
        reduce_only=False, created_at="2024-01-01T00:00:00Z",
    )

    client.cancel_order.return_value = True
    client.cancel_all_orders.return_value = 3

    client.close_position.return_value = CloseResult(
        symbol="BTC-PERP", status="closed", message="Position closed",
    )

    client.set_tp_sl.return_value = TpSlResult(
        tp={"trigger_price": 52000.0}, sl={"trigger_price": 48000.0},
    )

    client.update_leverage.return_value = LeverageResult(
        symbol="BTC-PERP", leverage=10, is_cross=False,
    )

    client.update_margin.return_value = MarginResult(
        symbol="BTC-PERP", margin_adjusted=500.0,
    )

    return client
