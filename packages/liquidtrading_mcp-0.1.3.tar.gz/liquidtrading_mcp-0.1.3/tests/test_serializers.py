"""Tests for serializers module."""

from __future__ import annotations

from liquidtrading.models import (
    Account,
    Orderbook,
    OrderbookLevel,
    Position,
    Ticker,
)

from liquid_mcp.serializers import to_dict


class TestToDict:
    def test_simple_dataclass(self):
        ticker = Ticker(
            symbol="BTC-PERP", mark_price=50000.0,
            volume_24h=1000000.0, change_24h=2.5, funding_rate=0.001,
        )
        result = to_dict(ticker)
        assert result == {
            "symbol": "BTC-PERP",
            "mark_price": 50000.0,
            "volume_24h": 1000000.0,
            "change_24h": 2.5,
            "funding_rate": 0.001,
        }

    def test_nested_dataclass_with_tuples(self):
        book = Orderbook(
            symbol="BTC-PERP",
            bids=(OrderbookLevel(price=49999.0, size=1.5, count=3),),
            asks=(OrderbookLevel(price=50001.0, size=1.2, count=2),),
            timestamp=1700000000,
        )
        result = to_dict(book)
        assert isinstance(result["bids"], list)
        assert result["bids"][0]["price"] == 49999.0
        assert isinstance(result["asks"], list)

    def test_list_of_dataclasses(self):
        positions = [
            Position(
                symbol="BTC-PERP", side="buy", size=100.0,
                entry_price=49000.0, leverage=5.0, unrealized_pnl=200.0,
                mark_price=50000.0, liquidation_price=40000.0, margin_used=1000.0,
            ),
        ]
        result = to_dict(positions)
        assert isinstance(result, list)
        assert result[0]["symbol"] == "BTC-PERP"

    def test_plain_value_passthrough(self):
        assert to_dict(42) == 42
        assert to_dict("hello") == "hello"
        assert to_dict(None) is None
