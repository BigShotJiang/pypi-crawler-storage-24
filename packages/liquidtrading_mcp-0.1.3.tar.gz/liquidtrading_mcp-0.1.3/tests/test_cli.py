"""Tests for the liquidtrading-mcp CLI entrypoint."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from liquid_mcp import main


def test_help_prints_usage(capsys):
    with patch("liquid_mcp.mcp.run") as run:
        main(["--help"])

    captured = capsys.readouterr()
    assert "Usage: liquidtrading-mcp" in captured.out
    run.assert_not_called()


def test_http_mode_uses_streamable_http():
    with patch("liquid_mcp.mcp.run") as run:
        main(["--http"])

    run.assert_called_once_with(
        transport="streamable-http",
        host="0.0.0.0",
        port=4243,
    )


def test_unknown_flag_exits():
    with pytest.raises(SystemExit, match="Unknown argument"):
        main(["--wat"])
