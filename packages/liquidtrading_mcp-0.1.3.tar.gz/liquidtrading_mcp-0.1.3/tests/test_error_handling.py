"""Tests for the error_handling module."""

from __future__ import annotations

from liquidtrading.errors import (
    AuthenticationError,
    ConnectionError as LiquidConnectionError,
    InsufficientBalanceError,
    LiquidError,
    OrderRejectedError,
    RateLimitError,
    SymbolNotFoundError,
    TimeoutError as LiquidTimeoutError,
)
from liquid_mcp.error_handling import handle_sdk_error


class TestHandleSdkError:
    def test_symbol_not_found(self):
        err = SymbolNotFoundError(code="SYMBOL_NOT_FOUND", message="Not found")
        result = handle_sdk_error("get_ticker", err)
        assert result["error"] is True
        assert result["error_code"] == "SYMBOL_NOT_FOUND"
        assert "get_markets" in result["next_steps"]

    def test_insufficient_balance(self):
        err = InsufficientBalanceError(code="INSUFFICIENT_BALANCE", message="No funds")
        result = handle_sdk_error("place_order", err)
        assert result["error"] is True
        assert "get_account" in result["next_steps"]

    def test_order_rejected(self):
        err = OrderRejectedError(code="ORDER_REJECTED", message="Rejected")
        result = handle_sdk_error("place_order", err)
        assert result["error"] is True
        assert "validate_trade" in result["next_steps"]

    def test_rate_limit_with_retry(self):
        err = RateLimitError(
            code="RATE_LIMIT_EXCEEDED", message="Slow down",
            status_code=429, retry_after=10.0,
        )
        result = handle_sdk_error("get_ticker", err)
        assert result["error"] is True
        assert result["retry_after"] == 10.0
        assert "10s" in result["hint"]

    def test_rate_limit_without_retry(self):
        err = RateLimitError(
            code="RATE_LIMIT_EXCEEDED", message="Slow down",
            status_code=429,
        )
        result = handle_sdk_error("get_ticker", err)
        assert result["retry_after"] is None
        assert "few seconds" in result["hint"]

    def test_auth_error(self):
        err = AuthenticationError(code="INVALID_API_KEY", message="Bad key")
        result = handle_sdk_error("get_account", err)
        assert result["error"] is True
        assert "authentication" in result["hint"].lower()
        assert result["next_steps"] == []

    def test_timeout_error(self):
        err = LiquidTimeoutError()
        result = handle_sdk_error("place_order", err)
        assert result["error"] is True
        assert "network" in result["hint"].lower()
        assert "get_positions" in result["next_steps"]

    def test_connection_error(self):
        err = LiquidConnectionError()
        result = handle_sdk_error("place_order", err)
        assert result["error"] is True
        assert "network" in result["hint"].lower()

    def test_generic_liquid_error(self):
        err = LiquidError(code="UNKNOWN", message="Something broke")
        result = handle_sdk_error("get_ticker", err)
        assert result["error"] is True
        assert result["tool"] == "get_ticker"
        assert "Something broke" in result["hint"]
