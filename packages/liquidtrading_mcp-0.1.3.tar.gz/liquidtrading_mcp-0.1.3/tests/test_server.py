"""Tests verifying all tools, resources, and prompts register correctly."""

from __future__ import annotations

import asyncio


class TestServerRegistration:
    def test_all_tools_registered(self):
        """Verify all 20 tools are registered."""
        from liquid_mcp.server import mcp

        tools = asyncio.get_event_loop().run_until_complete(mcp.list_tools())
        tool_names = {t.name for t in tools}

        expected_tools = {
            # Market (4)
            "get_markets", "get_ticker", "get_orderbook", "get_candles",
            # Account (3)
            "get_account", "get_balances", "get_positions",
            # Orders (6)
            "place_order", "place_bracket_order", "get_open_orders",
            "get_order", "cancel_order", "cancel_all_orders",
            # Positions (4)
            "close_position", "set_tp_sl", "update_leverage", "update_margin",
            # Helpers (3)
            "calculate_token_amount", "calculate_position_size", "validate_trade",
        }
        missing = expected_tools - tool_names
        assert not missing, f"Missing tools: {missing}"
        assert len(expected_tools) == 20

    def test_server_has_instructions(self):
        from liquid_mcp.server import mcp
        assert mcp.instructions is not None
        assert "USD notional" in mcp.instructions
