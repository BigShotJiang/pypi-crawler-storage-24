"""Tests for MCP resources."""

from __future__ import annotations

from unittest.mock import patch

from liquidtrading.errors import AuthenticationError


class TestPortfolioResource:
    def test_portfolio(self, mock_client):
        with patch("liquid_mcp.resources.get_client", return_value=mock_client):
            from liquid_mcp.resources import portfolio_resource

            result = portfolio_resource()
            assert "account" in result
            assert "positions" in result
            assert result["account"]["equity"] == 10000.0
            assert len(result["positions"]) == 1


class TestRiskResource:
    def test_risk(self, mock_client):
        with patch("liquid_mcp.resources.get_client", return_value=mock_client):
            from liquid_mcp.resources import risk_resource

            result = risk_resource()
            assert result["max_order_usd"] == 1000.0
            assert result["daily_loss_limit"] == 5000.0
            assert result["positions_count"] == 1
            assert result["total_exposure"] == 100.0

    def test_risk_with_auth_error(self, mock_client):
        mock_client.get_positions.side_effect = AuthenticationError(
            code="INVALID_API_KEY", message="Bad key",
        )
        with patch("liquid_mcp.resources.get_client", return_value=mock_client):
            from liquid_mcp.resources import risk_resource

            result = risk_resource()
            assert result["positions_count"] is None
            assert result["total_exposure"] is None
            assert "error_hint" in result
