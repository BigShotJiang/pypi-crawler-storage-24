"""Tests for market tools."""

from __future__ import annotations

from unittest.mock import patch

from liquidtrading.errors import RateLimitError, SymbolNotFoundError


class TestMarketTools:
    def test_get_markets(self, mock_client):
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_markets

            result = get_markets(ctx=None)
            assert "markets" in result
            assert len(result["markets"]) == 1
            assert result["markets"][0]["symbol"] == "BTC-PERP"
            assert "next_steps" in result

    def test_get_ticker(self, mock_client):
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_ticker

            result = get_ticker("BTC-PERP", ctx=None)
            assert result["symbol"] == "BTC-PERP"
            assert result["mark_price"] == 50000.0
            assert "next_steps" in result

    def test_get_ticker_symbol_not_found(self, mock_client):
        mock_client.get_ticker.side_effect = SymbolNotFoundError(
            code="SYMBOL_NOT_FOUND", message="Symbol not found",
        )
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_ticker

            result = get_ticker("FAKE-PERP", ctx=None)
            assert result["error"] is True
            assert result["error_code"] == "SYMBOL_NOT_FOUND"
            assert "get_markets" in result["next_steps"]

    def test_get_orderbook(self, mock_client):
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_orderbook

            result = get_orderbook("BTC-PERP", depth=10, ctx=None)
            assert result["symbol"] == "BTC-PERP"
            assert isinstance(result["bids"], list)
            assert isinstance(result["asks"], list)
            assert "next_steps" in result

    def test_get_orderbook_symbol_not_found(self, mock_client):
        mock_client.get_orderbook.side_effect = SymbolNotFoundError(
            code="SYMBOL_NOT_FOUND", message="Symbol not found",
        )
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_orderbook

            result = get_orderbook("FAKE-PERP", ctx=None)
            assert result["error"] is True
            assert "get_markets" in result["next_steps"]

    def test_get_candles(self, mock_client):
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_candles

            result = get_candles("BTC-PERP", interval="1h", limit=10, ctx=None)
            assert result["symbol"] == "BTC-PERP"
            assert result["interval"] == "1h"
            assert isinstance(result["candles"], list)
            assert "next_steps" in result

    def test_get_candles_rate_limited(self, mock_client):
        mock_client.get_candles.side_effect = RateLimitError(
            code="RATE_LIMIT_EXCEEDED", message="Too many requests",
            status_code=429, retry_after=3.0,
        )
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_candles

            result = get_candles("BTC-PERP", ctx=None)
            assert result["error"] is True
            assert result["retry_after"] == 3.0

    def test_get_markets_rate_limited(self, mock_client):
        mock_client.get_markets.side_effect = RateLimitError(
            code="RATE_LIMIT_EXCEEDED", message="Too many requests",
            status_code=429, retry_after=2.0,
        )
        with patch("liquid_mcp.tools.market.get_client", return_value=mock_client):
            from liquid_mcp.tools.market import get_markets

            result = get_markets(ctx=None)
            assert result["error"] is True
            assert result["retry_after"] == 2.0
