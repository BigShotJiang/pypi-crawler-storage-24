# -*- coding: utf-8 -*-

from slowapi import Limiter
from slowapi.util import get_remote_address

from odoo_api.core.config import get_settings

limiter = Limiter(
    key_func=get_remote_address,
    storage_uri=get_settings().limiter_storage_uri,
    in_memory_fallback_enabled=True,
)

_overrides: dict[str, str] = {}


def set_rate_limits(overrides: dict[str, str]):
    _overrides.update(overrides)


def route_limit(path: str):
    """Returns a callable for @limiter.limit() that resolves the limit at request time."""
    def _resolve() -> str:
        return _overrides.get(path, get_settings().rate_limit)
    return _resolve
