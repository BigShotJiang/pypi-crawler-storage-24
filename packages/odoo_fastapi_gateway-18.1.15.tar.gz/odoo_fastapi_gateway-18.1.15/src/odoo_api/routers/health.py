from fastapi import APIRouter

from odoo_api.core.limiter import limiter

router = APIRouter(tags=["Health"])


@router.get("/api/health", summary="Health check", description="Returns the health status of the API server.")
@limiter.exempt
async def health():
    return {"status": "ok"}
