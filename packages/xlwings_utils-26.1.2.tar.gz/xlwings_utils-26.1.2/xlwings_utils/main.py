import xlwings as xw
import peek

@xw.script
def test(book: xw.Book):
    #test
    peek(book.fullname)