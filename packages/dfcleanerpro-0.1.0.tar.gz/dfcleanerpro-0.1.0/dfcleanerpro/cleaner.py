import pandas as pd

def clean_dataframe(
        df,
        drop_duplicates=True,
        snake_case_columns=True,
        fill_missing=None
):
    df = df.copy()

    # Drop duplicates
    if drop_duplicates:
        df = df.drop_duplicates()

    # Convert column names to snake_case
    if snake_case_columns:
        df.columns = [
            col.strip().lower().replace(" ", "_")
            for col in df.columns
        ]

    # Fill missing values
    if fill_missing == "zero":
        df = df.fillna(0)

    elif fill_missing == "mean":
        df = df.fillna(df.mean(numeric_only=True))

    return df