def snake_case(name):
    return name.strip().lower().replace(" ", "_")