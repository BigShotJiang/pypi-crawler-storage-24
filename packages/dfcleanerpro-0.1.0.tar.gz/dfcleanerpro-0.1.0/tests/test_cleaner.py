import pandas as pd
from dfcleanerpro import clean_dataframe


def test_drop_duplicates():
    df = pd.DataFrame({
        "name": ["Alice", "Alice", "Bob"],
        "age": [25, 25, 30]
    })

    result = clean_dataframe(df, drop_duplicates=True)

    assert len(result) == 2


def test_snake_case_columns():
    df = pd.DataFrame({
        "First Name": ["Alice"],
        "Last Name": ["Smith"]
    })

    result = clean_dataframe(df, snake_case_columns=True)

    assert "first_name" in result.columns
    assert "last_name" in result.columns


def test_fill_missing_zero():
    df = pd.DataFrame({
        "age": [25, None, 30]
    })

    result = clean_dataframe(df, fill_missing="zero")

    assert result["age"].isnull().sum() == 0


def test_fill_missing_mean():
    df = pd.DataFrame({
        "age": [20, None, 40]
    })

    result = clean_dataframe(df, fill_missing="mean")

    assert result["age"].isnull().sum() == 0