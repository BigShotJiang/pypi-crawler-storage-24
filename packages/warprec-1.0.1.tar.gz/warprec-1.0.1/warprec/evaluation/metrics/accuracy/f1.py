from typing import Any

import torch
from torch import Tensor
from warprec.evaluation.metrics.base_metric import TopKMetric, BaseMetric
from warprec.utils.registry import metric_registry


@metric_registry.register("F1")
class F1(TopKMetric):
    """The F1@k metric combines precision and recall at k, providing a harmonic mean
    between the two to evaluate the relevance of the top-k recommended items.

    Attributes:
        metric_instance_1 (BaseMetric): First metric to use inside F1-score computation.
        metric_instance_2 (BaseMetric): Second metric to use inside F1-score computation.

    Args:
        k (int): The number of top recommendations to consider (cutoff).
        num_users (int): Number of users in the training set.
        num_items (int): Number of items in the training set.
        *args (Any): Additional arguments to pass to the parent class.
        beta (float): The weight of recall in the harmonic mean. Default is 1.0.
        dist_sync_on_step (bool): Torchmetrics parameter.
        metric_1 (str): The name of the first metric. Defaults to Precision.
        metric_2 (str): The name of the second metric. Defaults to Recall.
        **kwargs (Any): Additional keyword arguments to pass to the parent class.
    """

    metric_instance_1: BaseMetric
    metric_instance_2: BaseMetric

    def __init__(
        self,
        k: int,
        num_users: int,
        num_items: int,
        *args: Any,
        beta: float = 1.0,
        dist_sync_on_step: bool = False,
        metric_1: str = "Precision",
        metric_2: str = "Recall",
        **kwargs: Any,
    ):
        super().__init__(k, dist_sync_on_step)
        self.num_users = num_users
        self.beta = beta
        self.metric_1 = metric_1
        self.metric_2 = metric_2

        # Set up metrics
        self.metric_instance_1 = metric_registry.get(
            metric_1,
            k=k,
            num_users=num_users,
            num_items=num_items,
            dist_sync_on_step=dist_sync_on_step,
            **kwargs,
        )
        self.metric_instance_2 = metric_registry.get(
            metric_2,
            k=k,
            num_users=num_users,
            num_items=num_items,
            dist_sync_on_step=dist_sync_on_step,
            **kwargs,
        )

        # Update needed blocks to be the union of the blocks
        # of the two metrics
        self._REQUIRED_COMPONENTS = (
            self.metric_instance_1._REQUIRED_COMPONENTS
            | self.metric_instance_2._REQUIRED_COMPONENTS
        )

    def update(self, preds: Tensor, user_indices: Tensor, **kwargs: Any):
        """Updates the metric state with the new batch of predictions."""
        # Update first metric
        self.metric_instance_1.update(preds, user_indices, **kwargs)

        # Update second metric
        self.metric_instance_2.update(preds, user_indices, **kwargs)

    def compute(self):
        """Computes the F1 score using the two custom metrics."""
        # Get scores from both metrics
        score_1 = self.metric_instance_1.compute().get(
            self.metric_1, torch.zeros(self.num_users)
        )
        score_2 = self.metric_instance_2.compute().get(
            self.metric_2, torch.zeros(self.num_users)
        )

        # Compute the final F1 score
        f1_score = (
            (1 + self.beta**2)
            * (score_1 * score_2)
            / (self.beta**2 * score_1 + score_2)
        ).nan_to_num(0)
        return {self.name: f1_score}

    @property
    def name(self):
        """The name of the metric customized based on the metrics compared."""
        if self.metric_1 == "Precision" and self.metric_2 == "Recall":
            return self.__class__.__name__
        return f"F1[{self.metric_1}, {self.metric_2}]"
