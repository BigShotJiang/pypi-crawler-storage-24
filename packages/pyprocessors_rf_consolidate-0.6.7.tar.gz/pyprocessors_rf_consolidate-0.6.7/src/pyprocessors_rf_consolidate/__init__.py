"""RF Consolidation processor"""

__version__ = "0.6.7"
