---
name: convert-pdf
description: Convert PDF files to high-quality PNG images. Use when the user wants to convert a PDF to PNG, extract pages as images, or batch convert multiple PDFs in a folder.
---

# PDF to PNG Conversion

**IMPORTANT: Always delegate this task to the `pdf-converter` sub-agent using the Agent tool.** The sub-agent will handle file verification, conversion, and result reporting autonomously.

## How to Delegate

Use the Agent tool with `subagent_type: "pdf-to-png:pdf-converter"` and pass the user's request as the prompt. Include all relevant details:
- PDF file path or folder path
- Any user-specified DPI (default is 1200 — do NOT override)
- Output directory preference if mentioned

Example delegation:
```
Agent tool:
  subagent_type: "pdf-to-png:pdf-converter"
  description: "Convert PDF to PNG"
  prompt: "Convert the PDF at <path> to PNG images."
```

## When to Use

- User wants to convert a single PDF file to PNG images
- User wants to batch convert all PDFs in a folder
- User mentions extracting pages from a PDF as images
