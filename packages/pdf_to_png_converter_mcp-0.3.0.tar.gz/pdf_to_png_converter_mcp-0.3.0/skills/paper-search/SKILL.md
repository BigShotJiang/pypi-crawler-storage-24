---
name: search-paper
description: Search for academic papers using Semantic Scholar. Use when the user wants to find papers by keyword, look up a specific paper, or find open-access PDFs for academic topics.
---

# Academic Paper Search

**IMPORTANT: Always delegate this task to the `pdf-converter` sub-agent using the Agent tool.** The sub-agent will handle searching, presenting results, and offering to download papers autonomously.

## How to Delegate

Use the Agent tool with `subagent_type: "pdf-to-png:pdf-converter"` and pass the user's request as the prompt. Include all relevant details:
- Search keywords
- Number of results desired (default 5, max 20)
- Whether to also download/convert found papers

Example delegation:
```
Agent tool:
  subagent_type: "pdf-to-png:pdf-converter"
  description: "Search academic papers"
  prompt: "Search for papers about <topic> and show the top results."
```

## When to Use

- User wants to search for academic papers by keyword
- User wants to find open-access papers on a topic
- User asks to look up a specific paper
