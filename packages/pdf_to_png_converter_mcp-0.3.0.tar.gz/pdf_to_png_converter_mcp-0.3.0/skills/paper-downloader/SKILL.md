---
name: download-paper
description: Download academic papers from the web and optionally convert them to PNG. Use when the user wants to download a paper PDF, organize it by journal and title, or download and convert in one step.
---

# Paper Download and Organization

**IMPORTANT: Always delegate this task to the `pdf-converter` sub-agent using the Agent tool.** The sub-agent will handle downloading, organizing, and optional conversion autonomously.

## How to Delegate

Use the Agent tool with `subagent_type: "pdf-to-png:pdf-converter"` and pass the user's request as the prompt. Include all relevant details:
- Paper URL
- Journal name and paper title
- Whether to also convert to PNG
- Base directory preference
- Any user-specified DPI (default is 1200 — do NOT override)

Example delegation:
```
Agent tool:
  subagent_type: "pdf-to-png:pdf-converter"
  description: "Download and convert paper"
  prompt: "Download the paper from <url>, journal: <journal>, title: <title>, and convert to PNG."
```

## When to Use

- User provides a URL to a paper PDF
- User wants to download and organize an academic paper
- User wants to download a paper and convert it to PNG in one step
