from enum import Enum, unique


@unique
class PlotTypes(str, Enum):
    """Enumeration for bifurcation diagram types."""

    FIRST = "first"
    SECOND = "second"