from enum import Enum, unique


@unique
class BifurcationTypes(str, Enum):
    """Enumeration for bifurcation types."""

    # bifurcations
    SADDLENODE = "saddleNode"
    TRANSCRITICAL = "transcritical"
    HOPF_SUBCRITICAL = "hopfSubcritical"
    HOPF_SUPERCRITICAL = "hopfSupercritical"
    HOPF_BAUTIN = "hopfBautin"
    # other
    FRONTIER = "frontier"
    INTERNAL_ERROR = "outOfParameters"
    EXTINCT = "extinction"

