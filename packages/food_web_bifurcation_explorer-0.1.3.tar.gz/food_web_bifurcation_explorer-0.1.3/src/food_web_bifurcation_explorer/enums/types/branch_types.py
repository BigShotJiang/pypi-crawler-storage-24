from enum import Enum, unique


@unique
class BranchTypes(str, Enum):
    """Enumeration for branch types."""

    EMPIRICAL = "empirical"
    ALTERNATIVE = "alternative"