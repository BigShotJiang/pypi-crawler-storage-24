from enum import Enum


class IntegerNumbers(int, Enum):
    """Enumeration for integer number parameters used in the application."""

    MAX_FIXED_PARAMETERS = 1001
    MAX_NUM_TRACES = 20
    MAX_NUM_EXTINCTION_TRACES = 130 # correspond to the network with the maximum number of compartments
    EIGENVALUE_SPECTRUM_MIN = 0
    EIGENVALUE_SPECTRUM_MAX = 2000
    EIGENVALUE_SPECTRUM_STEP = 1