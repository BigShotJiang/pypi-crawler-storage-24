class StaticOptions:
    DEBUG = False
    PRECACHE_ALL_TRACES = False
