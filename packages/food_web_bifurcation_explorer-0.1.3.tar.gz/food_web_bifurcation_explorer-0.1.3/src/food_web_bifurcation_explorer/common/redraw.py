# redraw flags
class Redraw:

    def __init__(self) -> None:
        """Initialize all redraw flags to True."""
        self.branches: bool = True
        self.extinct: bool = True
        self.saddlenode_empirical: bool = True
        self.saddlenode_alternative: bool = True
        self.transcritical_empirical: bool = True
        self.transcritical_alternative: bool = True
        self.hopf_subcritical_empirical: bool = True
        self.hopf_subcritical_alternative: bool = True
        self.hopf_supercritical_empirical: bool = True
        self.hopf_supercritical_alternative: bool = True
        self.hopf_bautin_empirical: bool = True
        self.hopf_bautin_alternative: bool = True
        self.hopf_envelope_empirical: bool = True
        self.hopf_envelope_alternative: bool = True
        self.internal_error: bool = True
        self.eigenvalue_spectrum_index: bool = True
        self.redraw_eigenvalue_spectrum_centered_empirical: bool = True
        self.redraw_eigenvalue_spectrum_centered_alternative: bool = True

    def redraw_all(self) -> None:
        """Set all redraw flags to True."""
        self.branches = True
        self.extinct = True
        self.saddlenode_empirical = True
        self.saddlenode_alternative = True
        self.transcritical_empirical = True
        self.transcritical_alternative = True
        self.hopf_subcritical_empirical = True
        self.hopf_subcritical_alternative = True
        self.hopf_supercritical_empirical = True
        self.hopf_supercritical_alternative = True
        self.hopf_bautin_empirical = True
        self.hopf_bautin_alternative = True
        self.hopf_envelope_empirical = True
        self.hopf_envelope_alternative = True
        self.internal_error = True
        self.eigenvalue_spectrum_index = True
        self.redraw_eigenvalue_spectrum_centered_empirical = True
        self.redraw_eigenvalue_spectrum_centered_alternative = True

    def require_redraw_all(self, original: bool, new: bool) -> None:
        """Redraw all if the original and new values differ."""
        if original != new:
            self.redraw_all()

    def require_redraw_branches(self, original: bool, new: bool) -> None:
        """Set branches redraw flag if the original and new values differ."""
        self.branches = self.branches or (original != new)

    def require_redraw_extinct(self, original: bool, new: bool) -> None:
        """Set extinct redraw flag if the original and new values differ."""
        self.extinct = self.extinct or (original != new)

    def require_redraw_saddlenode_empirical(self, original: bool, new: bool) -> None:
        """Set saddlenode_empirical redraw flag if the original and new values differ."""
        self.saddlenode_empirical = self.saddlenode_empirical or (original != new)

    def require_redraw_saddlenode_alternative(self, original: bool, new: bool) -> None:
        """Set saddlenode_alternative redraw flag if the original and new values differ."""
        self.saddlenode_alternative = self.saddlenode_alternative or (original != new)

    def require_redraw_transcritical_empirical(self, original: bool, new: bool) -> None:
        """Set transcritical_empirical redraw flag if the original and new values differ."""
        self.transcritical_empirical = self.transcritical_empirical or (original != new)

    def require_redraw_transcritical_alternative(self, original: bool, new: bool) -> None:
        """Set transcritical_alternative redraw flag if the original and new values differ."""
        self.transcritical_alternative = self.transcritical_alternative or (original != new)

    def require_redraw_hopf_subcritical_empirical(self, original: bool, new: bool) -> None:
        """Set hopf_subcritical_empirical redraw flag if the original and new values differ."""
        self.hopf_subcritical_empirical = self.hopf_subcritical_empirical or (original != new)

    def require_redraw_hopf_subcritical_alternative(self, original: bool, new: bool) -> None:
        """Set hopf_subcritical_alternative redraw flag if the original and new values differ."""
        self.hopf_subcritical_alternative = self.hopf_subcritical_alternative or (original != new)

    def require_redraw_hopf_supercritical_empirical(self, original: bool, new: bool) -> None:
        """Set hopf_supercritical_empirical redraw flag if the original and new values differ."""
        self.hopf_supercritical_empirical = self.hopf_supercritical_empirical or (original != new)

    def require_redraw_hopf_supercritical_alternative(self, original: bool, new: bool) -> None:
        """Set hopf_supercritical_alternative redraw flag if the original and new values differ."""
        self.hopf_supercritical_alternative = self.hopf_supercritical_alternative or (original != new)

    def require_redraw_hopf_bautin_empirical(self, original: bool, new: bool) -> None:
        """Set hopf_bautin_empirical redraw flag if the original and new values differ."""
        self.hopf_bautin_empirical = self.hopf_bautin_empirical or (original != new)

    def require_redraw_hopf_bautin_alternative(self, original: bool, new: bool) -> None:
        """Set hopf_alternative redraw flag if the original and new values differ."""
        self.hopf_bautin_alternative = self.hopf_bautin_alternative or (original != new)

    def require_redraw_hopf_envelope_empirical(self, original: bool, new: bool) -> None:
        """Set envelope_empirical redraw flag if the original and new values differ."""
        self.hopf_envelope_empirical = self.hopf_envelope_empirical or (original != new)

    def require_redraw_hopf_envelope_alternative(self, original: bool, new: bool) -> None:
        """Set envelope_alternative redraw flag if the original and new values differ."""
        self.hopf_envelope_alternative = self.hopf_envelope_alternative or (original != new)

    def require_redraw_internal_error(self, original: bool, new: bool) -> None:
        """Set internal_error redraw flag if the original and new values differ."""
        self.internal_error = self.internal_error or (original != new)

    def require_redraw_eigenvalue_spectrum_index(self, original: bool, new: bool) -> None:
        """Set eigenvalue_spectrum_index redraw flag if the original and new values differ."""
        self.eigenvalue_spectrum_index = self.eigenvalue_spectrum_index or (original != new)

    def require_redraw_eigenvalue_spectrum_centered_empirical(self, original: bool, new: bool) -> None:
        """Set redraw_eigenvalue_spectrum_centered_empirical redraw flag if the original and new values differ."""
        self.redraw_eigenvalue_spectrum_centered_empirical = (
            self.redraw_eigenvalue_spectrum_centered_empirical or (original != new)
        )

    def require_redraw_eigenvalue_spectrum_centered_alternative(self, original: bool, new: bool) -> None:
        """Set redraw_eigenvalue_spectrum_centered_alternative redraw flag if the original and new values differ."""
        self.redraw_eigenvalue_spectrum_centered_alternative = (
            self.redraw_eigenvalue_spectrum_centered_alternative or (original != new)
        )
