from food_web_bifurcation_explorer.common.drawing_options import DrawingOptions
from food_web_bifurcation_explorer.common.exceptions import ParameterTypeError
from food_web_bifurcation_explorer.enums.network_data import NetworkData
from food_web_bifurcation_explorer.enums.resolutions import Resolutions
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes


# config file
class Config:

    def __init__(self) -> None:
        # current dynamic options
        self.network: str | None = None
        self.resolution: int = Resolutions.DEFAULT.value
        self.compartment_first_index: int = 0
        self.compartment_first: str | None = None
        self.compartment_second_index: int = 1
        self.compartment_second: str | None = None
        self.fixed_parameter_type: ParameterTypes = ParameterTypes.LOTKAVOLTERRA
        self.dynamic_paramameter_type: ParameterTypes = ParameterTypes.RECIPIENT
        self.fixed_parameter_value: float = 0.4
        self.fixed_parameter_value_str: str = f"{self.fixed_parameter_value:.5f}"
        # eigenValues spectrum options
        self.eigenvalue_spectrum_index: dict[BranchTypes, int] = {}
        for branch_type in BranchTypes:
            self.eigenvalue_spectrum_index[branch_type] = 0
        # drawing options
        self.drawing_options: DrawingOptions = DrawingOptions()

    def get_current_compartments(self) -> list[str]:
        """Return the list of current compartments for the selected network."""
        if self.network is not None:
            return NetworkData.VALUES[self.network]
        # return empty list
        return []

    def update_network(self, network: str) -> None:
        """Update the current network and adjust compartment indices if necessary."""
        self.network = network
        # adjust compartments
        num_compartments: int = len(self.get_current_compartments())
        if self.compartment_first_index >= num_compartments:
            self.compartment_first_index = 0
        if self.compartment_second_index >= num_compartments:
            self.compartment_second_index = 0

    def update_fixed_parameter_type(self, fixed_parameter_type: ParameterTypes) -> None:
        """Update the type of the fixed parameter."""
        self.fixed_parameter_type = fixed_parameter_type
        # set dynamic parameter
        if self.fixed_parameter_type == ParameterTypes.DONOR:
            self.dynamic_paramameter_type = ParameterTypes.LOTKAVOLTERRA
        elif self.fixed_parameter_type == ParameterTypes.RECIPIENT:
            self.dynamic_paramameter_type = ParameterTypes.DONOR
        elif self.fixed_parameter_type == ParameterTypes.LOTKAVOLTERRA:
            self.dynamic_paramameter_type = ParameterTypes.RECIPIENT
        else:
            raise ParameterTypeError("invalid parameter")

    def update_fixed_parameter_value(self, fixed_parameter_value: float) -> float:
        """Update the value of the fixed parameter and its string representation."""
        self.fixed_parameter_value = fixed_parameter_value
        self.fixed_parameter_value_str = f"{fixed_parameter_value:.5f}"
        # return new value
        return self.fixed_parameter_value

    def update_eigenvalue_spectrum_index(
        self, eigenvalue_spectrum_index: int, branch_type: BranchTypes
    ) -> None:
        """Update the eigenvalue spectrum index for a given branch type."""
        self.eigenvalue_spectrum_index[branch_type] = eigenvalue_spectrum_index

    def update_comparment_first(self, compartment_first: str) -> None:
        """Update first compartment to the specified value if it exists, otherwise set to the first compartment."""
        compartments: list[str] = self.get_current_compartments()
        # continue depending if value exist in the current compartments
        if compartment_first in compartments:
            self.compartment_first = compartment_first
            self.compartment_first_index = compartments.index(compartment_first)
        else:
            self.compartment_first = compartments[0]
            self.compartment_first_index = 0

    def update_comparment_second(self, compartment_second: str) -> None:
        """Update second compartment to the specified value if it exists, otherwise set to the second compartment."""
        compartments: list[str] = self.get_current_compartments()
        # continue depending if value exist in the current compartments
        if compartment_second in compartments:
            self.compartment_second = compartment_second
            self.compartment_second_index = compartments.index(compartment_second)
        else:
            self.compartment_second = compartments[1]
            self.compartment_second_index = 1
