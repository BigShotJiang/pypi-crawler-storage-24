class BifurcationDiagramTypeError(ValueError):
    pass


class BifurcationTypeError(ValueError):
    pass


class ParameterTypeError(ValueError):
    pass


class UpdatingGraphError(ValueError):
    pass
