﻿from dash import dcc

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles


def build() -> dcc.Checklist:
    return dcc.Checklist(
        id=IDs.CHECKBOX_DRAW_LINES,
        options=[{"label": Labels.DRAW_LINES, "value": True}],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
