﻿"""Module for building eigenvalue spectrum centered alternative checkbox component."""
from dash import dcc

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles


def build() -> dcc.Checklist:
    """Build eigenvalue spectrum centered alternative checkbox component.

    Returns:
        dcc.Checklist: Checkbox component for eigenvalue spectrum centered alternative.
    """
    return dcc.Checklist(
        id=IDs.CHECKBOX_EIGENVALUE_SPECTRUM_CENTERED_ALTERNATIVE,
        options=[{"label": Labels.EIGENVALUE_SPECTRUM_CENTERED, "value": True}],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
