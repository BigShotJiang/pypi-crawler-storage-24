from dash import dcc, html

# project imports
from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.bautin import bautin_alternative
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.bautin import bautin_empirical
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.envelope import envelope_alternative
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.envelope import envelope_empirical
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.subcritical import subcritical_alternative
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.subcritical import subcritical_empirical
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.supercritical import supercritical_alternative
from food_web_bifurcation_explorer.frontend.bifurcations.hopf.supercritical import supercritical_empirical
from food_web_bifurcation_explorer.frontend.bifurcations.saddlenode import saddlenode_alternative
from food_web_bifurcation_explorer.frontend.bifurcations.saddlenode import saddlenode_empirical
from food_web_bifurcation_explorer.frontend.bifurcations.transcritical import transcritical_alternative
from food_web_bifurcation_explorer.frontend.bifurcations.transcritical import transcritical_empirical
from food_web_bifurcation_explorer.frontend.biomass_compartment import biomass_compartment_first
from food_web_bifurcation_explorer.frontend.biomass_compartment import biomass_compartment_second
from food_web_bifurcation_explorer.frontend.draw import branch_alternative
from food_web_bifurcation_explorer.frontend.draw import branch_empirical
from food_web_bifurcation_explorer.frontend.draw import lines
from food_web_bifurcation_explorer.frontend.draw import points
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_centered_alternative
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_centered_empirical
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_index_alternative
from food_web_bifurcation_explorer.frontend.eigenvalue_spectrum import eigenvalue_spectrum_index_empirical
from food_web_bifurcation_explorer.frontend.equilibria import area
from food_web_bifurcation_explorer.frontend.equilibria import over_information
from food_web_bifurcation_explorer.frontend.equilibria import stable
from food_web_bifurcation_explorer.frontend.equilibria import unstable
from food_web_bifurcation_explorer.frontend.general import network_selector
from food_web_bifurcation_explorer.frontend.general import resolution_selector
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.frontend.others import eigenvalue_spectrum_index
from food_web_bifurcation_explorer.frontend.others import extinct
from food_web_bifurcation_explorer.frontend.others import internal_error
from food_web_bifurcation_explorer.frontend.parameters import fixed_parameter_type
from food_web_bifurcation_explorer.frontend.parameters import fixed_parameter_value

# html layout
html_layout = html.Div(
    [
        # title
        html.H1(Labels.MAIN_TITLE, style=Styles.MAIN_TITLE),
        # DIV_CONTROL
        html.Div(
            [
                # Group 1
                html.Div(
                    [
                        network_selector.title(),
                        network_selector.build(),
                        resolution_selector.title(),
                        resolution_selector.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 2
                html.Div(
                    [
                        biomass_compartment_first.title(),
                        biomass_compartment_first.build(),
                        biomass_compartment_second.title(),
                        biomass_compartment_second.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 3
                html.Div(
                    [
                        fixed_parameter_type.title(),
                        fixed_parameter_type.build(),
                        fixed_parameter_value.title(),
                        fixed_parameter_value.build(),
                    ],
                    style=Styles.GROUP_DROPDOWN,
                ),
                # Group 4: Equilibria
                html.Div(
                    [
                        html.Label(Labels.EQUILIBRIA, style=Styles.LABEL),
                        area.build(),
                        stable.build(),
                        unstable.build(),
                        over_information.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 5: saddlenode & transcritical bifurcations
                html.Div(
                    [
                        # saddle node bifurcations
                        html.Label(
                            Labels.SADDLENODE_BIFURCATIONS, style=Styles.LABEL
                        ),
                        saddlenode_empirical.build(),
                        saddlenode_alternative.build(),
                        # transcritical bifurcations
                        html.Label(
                            Labels.TRANSCRITICAL_BIFURCATIONS,
                            style=Styles.LABEL,
                        ),
                        transcritical_empirical.build(),
                        transcritical_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 6: hopf bifurcations
                html.Div(
                    [
                        # hopf subcritical bifurcations
                        html.Label(Labels.HOPF_SUBCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        subcritical_empirical.build(),
                        subcritical_alternative.build(),
                        # hopf supercritical bifurcations
                        html.Label(Labels.HOPF_SUPERCRITICAL_BIFURCATIONS, style=Styles.LABEL),
                        supercritical_empirical.build(),
                        supercritical_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 7: bautin & envelope
                html.Div(
                    [
                        html.Label(Labels.HOPF_BAUTIN_BIFURCATIONS, style=Styles.LABEL),
                        bautin_empirical.build(),
                        bautin_alternative.build(),
                        html.Label(Labels.HOPF_ENVELOPES, style=Styles.LABEL),
                        envelope_empirical.build(),
                        envelope_alternative.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 8 : others
                html.Div(
                    [
                        html.Label(Labels.OTHERS, style=Styles.LABEL),
                        extinct.build(),
                        internal_error.build(),
                        eigenvalue_spectrum_index.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 9: Drawing Options
                html.Div(
                    [
                        html.Label(Labels.DRAWING_OPTIONS, style=Styles.LABEL),
                        branch_empirical.build(),
                        branch_alternative.build(),
                        lines.build(),
                        points.build(),
                    ],
                    style=Styles.GROUP_CHECKBOX,
                ),
                # Group 10: eigen value spectrum indices
                html.Div(
                    [
                        eigenvalue_spectrum_index_empirical.title(),
                        # subgroup 10: empirical
                        html.Div(
                            [
                                eigenvalue_spectrum_index_empirical.build(),
                                eigenvalue_spectrum_centered_empirical.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                        eigenvalue_spectrum_index_alternative.title(),
                        # subgroup 10: alternative
                        html.Div(
                            [
                                eigenvalue_spectrum_index_alternative.build(),
                                eigenvalue_spectrum_centered_alternative.build(),
                            ],
                            style=Styles.SUBGROUP_EIGENVALUES,
                        ),
                    ],
                    style=Styles.GROUP_EIGENVALUES,
                ),
            ],
            style=Styles.DIV_CONTROL,
        ),
        # DIV_GRAPHS
        html.Div(
            [
                # ternary graph
                html.Div(
                    [
                        dcc.Graph(
                            id=IDs.FIG_TERNARY_GRAPH,
                            figure=glob.figures.ternary,
                            style=Styles.TERNARY,
                            config={
                                "doubleClick": False,
                                "scrollZoom": False,
                                "responsive": True,
                                "displayModeBar": False
                            },
                        )
                    ],
                    id=IDs.DIV_GRAPH_TERNARY,
                    style=Styles.DIV_GRAPH_TERNARY,
                ),
                # DIV_RIGHT_PANEL
                html.Div(
                    [
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram A
                                        dcc.Graph(
                                            id=IDs.FIG_BIFURCATION_DIAGRAMM_FIRST,
                                            figure=glob.figures.bifurcation_diagram_first,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_01,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum empirical
                                        dcc.Graph(
                                            id=IDs.FIG_EIGENVALUE_SPECTRUM_EMPIRICAL,
                                            figure=glob.figures.eigenvalue_spectrum_empirical,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_02,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SMALL_ROW_01,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # bifurcation diagram B
                                        dcc.Graph(
                                            id=IDs.FIG_BIFURCATION_DIAGRAMM_SECOND,
                                            figure=glob.figures.bifurcation_diagram_second,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_03,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # eigenvalue_spectrum alternative
                                        dcc.Graph(
                                            id=IDs.FIG_EIGENVALUE_SPECTRUM_ALTERNATIVE,
                                            figure=glob.figures.eigenvalue_spectrum_alternative,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_04,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SMALL_ROW_02,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # time series first
                                        dcc.Graph(
                                            id=IDs.FIG_TIME_SERIES_FIRST,
                                            figure=glob.figures.time_series_first,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_05,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # time series second
                                        dcc.Graph(
                                            id=IDs.FIG_TIME_SERIES_SECOND,
                                            figure=glob.figures.time_series_second,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_06,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SMALL_ROW_03,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                        # DIV_SMALL_ROW
                        html.Div(
                            [
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # phase portrait empirical
                                        dcc.Graph(
                                            id=IDs.FIG_PHASE_PORTRAIT_FIRST,
                                            figure=glob.figures.time_series_first,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_07,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                                # DIV_GRAPH_PLOT
                                html.Div(
                                    [
                                        # phase portrait empirical
                                        dcc.Graph(
                                            id=IDs.FIG_PHASE_PORTRAIT_SECOND,
                                            figure=glob.figures.time_series_second,
                                            style=Styles.PLOT,
                                            config={"displayModeBar": False},
                                        ),
                                    ],
                                    id=IDs.DIV_GRAPH_PLOT_08,
                                    style=Styles.DIV_GRAPH_PLOT,
                                ),
                            ],
                            id=IDs.DIV_SMALL_ROW_04,
                            style=Styles.DIV_SMALL_ROW,
                        ),
                    ],
                    id=IDs.DIV_RIGH_PANEL,
                    style=Styles.DIV_RIGHT_PANEL,
                ),
            ],
            id=IDs.DIV_GRAPHS,
            style=Styles.DIV_GRAPHS,
        ),
        # error messages
        html.Div(
            id=IDs.ERROR_MESSAGE,
            style={"color": "red", "fontWeight": "bold", "textAlign": "center", "padding": "10px"},
        ),
    ]
)
