from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.network_data import NetworkData
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.frontend.ids import IDs


# title
def title():
    return html.Label(Labels.NETWORK_SELECTOR, style=Styles.LABEL)


# build
def build():
    return dcc.Dropdown(
        id=IDs.DROPDOWN_NETWORK,
        options=[{"label": name, "value": name} for name in NetworkData.VALUES],
        value="Baja_California_417",  # default network
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )
