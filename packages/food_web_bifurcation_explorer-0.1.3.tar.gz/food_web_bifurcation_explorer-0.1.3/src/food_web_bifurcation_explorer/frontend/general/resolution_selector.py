from dash import dcc, html

from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.resolutions import Resolutions
from food_web_bifurcation_explorer.enums.labels import Labels


# title
def title():
    return html.Label(Labels.ZOOM_LEVEL, style=Styles.LABEL)


# build
def build():
    return dcc.Dropdown(
        id=IDs.DROPDOWN_SIZE,
        options=[{"label": resolution.name.capitalize(), "value": resolution.value} for resolution in Resolutions],
        value=Resolutions.DEFAULT,  # default resolution
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )
