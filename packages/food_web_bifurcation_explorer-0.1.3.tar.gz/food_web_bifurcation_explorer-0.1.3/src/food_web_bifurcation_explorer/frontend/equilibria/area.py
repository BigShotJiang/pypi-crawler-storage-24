﻿from dash import dcc, html

from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.font import Font
from food_web_bifurcation_explorer.enums.styles import Styles
from food_web_bifurcation_explorer.enums.graph_palette import GraphPalette
from food_web_bifurcation_explorer.enums.symbols import Symbols


# build
def build():
    return dcc.Checklist(
        id=IDs.CHECKBOX_EQUILIBRIA_AREA,
        options=[
            {
                "label": html.Span(
                    [
                        Labels.STABILITY_AREA,
                        # group characters
                        html.Span(
                            [
                                # first triangle
                                html.Span(
                                    Symbols.TRIANGLE,
                                    style={
                                        "color": GraphPalette.STABLE,
                                        "fontSize": Font.SIZE,
                                        "position": "relative",
                                        "clipPath": "inset(0 50% 0 0)",
                                        "display": "inline-block",
                                        "transform": "translateX(7px)",
                                    },
                                ),
                                # second triangle
                                html.Span(
                                    Symbols.TRIANGLE,
                                    style={
                                        "color": GraphPalette.UNSTABLE,
                                        "fontSize": Font.SIZE,
                                        "position": "relative",
                                        "clipPath": "inset(0 0 0 50%)",
                                        "display": "inline-block",
                                        "transform": "translateX(-7px)",
                                    },
                                ),
                            ],
                            style={"whiteSpace": "nowrap", "marginLeft": "-1px"},
                        ),
                    ]
                ),
                "value": True,
            }
        ],
        value=[True],
        inline=True,
        labelStyle=Styles.CHECKBOXLABEL,
    )
