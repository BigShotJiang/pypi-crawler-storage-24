from dash import dcc, html

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.frontend.ids import IDs
from food_web_bifurcation_explorer.enums.styles import Styles


# title
def title() -> html.Label:
    """
    Returns a Dash HTML label for the biomass compartment first dropdown.
    """
    return html.Label(Labels.BIOMASS_COMPARTMENT_FIRST, style=Styles.LABEL)


# build
def build() -> dcc.Dropdown:
    """
    Builds and returns a Dash Dropdown component for selecting the first compartment.
    """
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    return dcc.Dropdown(
        id=IDs.DROPDOWN_COMPARTMENT_FIRST,
        options=[
            {"label": compartments[index] + " (" + str(index) + ")", "value": str(index)}
            for index in range(0, len(compartments))
        ],
        value="0",  # default compartment
        clearable=False,  # prevents the user from food_web_bifurcation_explorer.clearing the selection (removes the X)
    )


# update
def update() -> list[dict[str, str]]:
    """
    Updates and returns the options for the compartment first dropdown.
    """
    # get compartments
    compartments: list[str] = glob.config.get_current_compartments()
    # set new options
    options = [
        {"label": compartments[index] + " (" + str(index) + ")", "value": str(index)}
        for index in range(0, len(compartments))
    ]
    return options
