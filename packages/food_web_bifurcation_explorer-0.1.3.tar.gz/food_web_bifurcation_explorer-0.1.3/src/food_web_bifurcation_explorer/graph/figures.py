import plotly.graph_objects as go

from food_web_bifurcation_explorer.enums.types.plot_types import PlotTypes
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes

from food_web_bifurcation_explorer.graph.bifurcation_diagram.build import build_bifurcation_diagram
from food_web_bifurcation_explorer.graph.eigenvalue_spectrum.build import build_eigenvalue_spectrum
from food_web_bifurcation_explorer.graph.time_serie.build import build_time_serie
from food_web_bifurcation_explorer.graph.phase_portrait.build import build_phase_portrait
from food_web_bifurcation_explorer.graph.ternary.build import build_ternary

class Figures:
    
    def __init__(self):
        # empty figure used if case of errors
        self.empty_figure: go.Figure = go.Figure()

        # ternary
        self.ternary: go.Figure = build_ternary()

        # ternary index to know which trace corresponds to which index in the data
        self.ternary_traces_index: dict[str, str] = {}

        # ternary index to know which trace to remove when updating the ternary diagram
        self.ternary_traces_remove: dict[str, str] = {}

        # first bifurcation diagram
        self.bifurcation_diagram_first: go.Figure = build_bifurcation_diagram(PlotTypes.FIRST)

        # second bifurcation diagram
        self.bifurcation_diagram_second: go.Figure = build_bifurcation_diagram(PlotTypes.SECOND)

        # eigenvalue spectrum for empirical branch
        self.eigenvalue_spectrum_empirical: go.Figure = build_eigenvalue_spectrum(BranchTypes.EMPIRICAL)

        # eigenvalue spectrum for alternative branch
        self.eigenvalue_spectrum_alternative: go.Figure = build_eigenvalue_spectrum(BranchTypes.ALTERNATIVE)

        # time series for first bifurcation diagram
        self.time_series_first: go.Figure = build_time_serie(PlotTypes.FIRST)

        # time series for second bifurcation diagram
        self.time_series_second: go.Figure = build_time_serie(PlotTypes.SECOND)

        # phase portrait for first bifurcation diagram
        self.phase_portrait_first: go.Figure = build_phase_portrait(PlotTypes.FIRST)

        # phase portrait for second bifurcation diagram
        self.phase_portrait_second: go.Figure = build_phase_portrait(PlotTypes.SECOND)