﻿"""Module for updating and managing eigenvalue spectrum visualizations."""

import plotly.graph_objects as go
import numpy as np

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


def update_eigenvalue_spectrum(fig: go.Figure, branch_type: BranchTypes) -> go.Figure:
    # get eigen values
    [real_parts, imaginary_parts, min_real, max_real, min_imaginary, max_imaginary] = (
        glob.plot_data.branch_datas[glob.config.fixed_parameter_type][
            branch_type
        ].get_eigenvalue_spectrum_values()
    )
    fig.data = []
    # draw lines between conjugated pairs
    conjugated_pairs = set()
    for i, (r1, i1) in enumerate(zip(real_parts, imaginary_parts)):
        if i in conjugated_pairs:
            continue
        for j in range(i + 1, len(real_parts)):
            r1, i1 = real_parts[i], imaginary_parts[i]
            r2, i2 = real_parts[j], imaginary_parts[j]
            if np.isclose(r1, r2) and np.isclose(i1, -i2):
                fig.add_trace(
                    go.Scattergl(
                        x=[r1, r2],
                        y=[i1, i2],
                        mode="lines",
                        line={"color": "orange"},
                        showlegend=False,
                    )
                )
                conjugated_pairs.update({i, j})
                break
    # add values
    for i, (x, y) in enumerate(zip(real_parts, imaginary_parts)):
        # set point color
        if x > 0:
            if i in conjugated_pairs:
                point_color = "pink"
                text_color = "black"
            else:
                point_color = "red"
                text_color = "white"
        else:
            if i in conjugated_pairs:
                point_color = "cyan"
                text_color = "black"
            else:
                point_color = "blue"
                text_color = "white"
        # add trace
        fig.add_trace(
            go.Scattergl(
                x=[x],
                y=[y],
                mode="markers+text",
                marker={"size": 20, "color": point_color},
                textfont={"color": text_color},
                showlegend=False,
                text=[f"{i+1}"],
                name=f"λ{i+1}",
            )
        )
    # vertical line
    fig.add_vline(x=0, line_width=3, line_dash="dash", line_color="orange")
    # update layout
    fig.update_layout(
        xaxis={
            "range": [min_real, max_real],
            "autorange": False,
        },
        yaxis={
            "range": [min_imaginary, max_imaginary],
            "autorange": False,
        },
    )
    return fig


def add_area_labels(fig: go.Figure, y_position: float) -> None:
    """
    Add area labels ("Unstable area" and "Stable area") to the given figure at the specified y position.

    Args:
        fig: The Plotly figure object to update.
        y_position: The y-coordinate at which to place the area labels.
    """
    fig.update_layout(
        annotations=[
            {
                "x": 12,
                "y": y_position,
                "xref": "x",
                "yref": "y",
                "text": "Unstable area",
                "showarrow": False,
                "font": {"color": "red", "size": 16},
            },
            {
                "x": -10,
                "y": y_position,
                "xref": "x",
                "yref": "y",
                "text": "Stable area",
                "showarrow": False,
                "font": {"color": "blue", "size": 16},
            },
        ]
    )


def add_stable_frame(fig: go.Figure) -> None:
    fig.update_layout(
        shapes=[
            {
                "type": "rect",
                "xref": "paper",
                "yref": "paper",
                "x0": 0,
                "y0": 0,
                "x1": 1,
                "y1": 1,
                "line": {"color": "blue", "width": 4},
            }
        ]
    )


def add_unstable_frame(fig: go.Figure) -> None:
    fig.update_layout(
        shapes=[
            {
                "type": "rect",
                "xref": "paper",
                "yref": "paper",
                "x0": 0,
                "y0": 0,
                "x1": 1,
                "y1": 1,
                "line": {"color": "red", "width": 4},
            }
        ]
    )
