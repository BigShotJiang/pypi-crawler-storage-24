﻿"""Module for updating and managing phase portrait visualizations."""

import plotly.graph_objects as go  # type: ignore
import numpy as np

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.branch_types import BranchTypes


def update_phase_portrait(fig: go.Figure, branch_type: BranchTypes) -> go.Figure:
    # get eigen values
    [real_parts, imaginary_parts, min_real, max_real, min_imaginary, max_imaginary] = (
        glob.plot_data.branch_datas[glob.config.fixed_parameter_type][
            branch_type
        ].get_phase_portrait_values()
    )
    fig.data = []
    # draw lines between conjugated pairs
    conjugated_pairs = set()
    for i, _ in enumerate(real_parts):
        if i in conjugated_pairs:
            continue
        for j in range(i + 1, len(real_parts)):
            r1, i1 = real_parts[i], imaginary_parts[i]
            r2, i2 = real_parts[j], imaginary_parts[j]
            if np.isclose(r1, r2) and np.isclose(i1, -i2):
                fig.add_trace(
                    go.Scattergl(
                        x=[r1, r2],
                        y=[i1, i2],
                        mode="lines",
                        line={"color": "orange"},
                        showlegend=False,
                    )
                )
                conjugated_pairs.update({i, j})
                break
    # add values
    for i, (x, y) in enumerate(zip(real_parts, imaginary_parts)):
        # set point color
        if x > 0:
            if i in conjugated_pairs:
                point_color = "pink"
                text_color = "black"
            else:
                point_color = "red"
                text_color = "white"
        else:
            if i in conjugated_pairs:
                point_color = "cyan"
                text_color = "black"
            else:
                point_color = "blue"
                text_color = "white"
        # add trace
        fig.add_trace(
            go.Scattergl(
                x=[x],
                y=[y],
                mode="markers+text",
                marker={"size": 20, "color": point_color},
                textfont={"color": text_color},
                showlegend=False,
                text=[f"{i+1}"],
                name=f"λ{i+1}",
            )
        )
    # vertical line
    fig.add_vline(x=0, line_width=3, line_dash="dash", line_color="orange")
    # update layout
    fig.update_layout(
        xaxis={
            "range": [min_real, max_real],
            "autorange": False,
        },
        yaxis={
            "range": [min_imaginary, max_imaginary],
            "autorange": False,
        },
    )
    return fig
