"""Module for building ternary plot figures with arrows and annotations."""

import plotly.graph_objects as go  # type: ignore

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.labels import Labels
from food_web_bifurcation_explorer.enums.traces.ternary_traces import TernaryTraces
from food_web_bifurcation_explorer.enums.graph_palette import GraphPalette


def add_ternary_arrows(fig: go.Figure) -> go.Figure:
    # sd tip coordinates
    sd_tip_x = 0
    sd_tip_y = 0.2
    
    # sd tail coordinates
    sd_tail_x = 0.375
    sd_tail_y = 0.866

    # draw sd arrow
    fig.add_annotation(
        x=sd_tip_x, y=sd_tip_y, ax=sd_tail_x, ay=sd_tail_y,
        xref="x", yref="y", axref="x", ayref="y",
        showarrow=True, arrowhead=2, arrowwidth=1.5,
    )

    # draw sd text
    fig.add_annotation(
        x=(sd_tip_x + sd_tail_x) / 2, y=(sd_tip_y + sd_tail_y) / 2,
        text=Labels.DONOR_CONTROL_STRENGTH, showarrow=False,
        xref="x", yref="y", textangle=-60, font={"size": 15},
        bgcolor="white", opacity=1,
    )

    # sl tip coordinates
    sl_tip_x = 0.625
    sl_tip_y = 0.866

    # sl tail coordinates
    sl_tail_x = 1
    sl_tail_y = 0.2

    # draw sl arrow
    fig.add_annotation(
        x=sl_tip_x, y=sl_tip_y, ax=sl_tail_x, ay=sl_tail_y,
        xref="x", yref="y", axref="x", ayref="y",
        showarrow=True, arrowhead=2, arrowwidth=1.5,
    )

    # draw sl text
    fig.add_annotation(
        x=(sl_tip_x + sl_tail_x) / 2, y=(sl_tip_y + sl_tail_y) / 2,
        text=Labels.LOTKAVOLTERRA_CONTROL_STRENGT, showarrow=False,
        xref="x", yref="y", textangle=60, font={"size": 15},
        bgcolor="white", opacity=1,
    )

    # sr tip coordinates
    sr_tip_x = 0.9
    sr_tip_y = 0

    # sr tail coordinates
    sr_tail_x = 0.1
    sr_tail_y = 0

    # draw sr arrow
    fig.add_annotation(
        x=sr_tip_x, y=sr_tip_y, ax=sr_tail_x, ay=sr_tail_y,
        xref="x", yref="y", axref="x", ayref="y",
        showarrow=True, arrowhead=2, arrowwidth=1.5,
    )

    # draw sr text
    fig.add_annotation(
        x=(sr_tip_x + sr_tail_x) / 2, y=(sr_tip_y + sr_tail_y) / 2,
        text=Labels.RECIPIENT_CONTROL_STRENGT, showarrow=False,
        xref="x", yref="y", textangle=0, font={"size": 15},
        bgcolor="white", opacity=1,
    )
    return fig


def build_ternary() -> go.Figure:

    # create figure
    fig = go.Figure()

    # equilibria areas (filled polygons)
    fig.add_trace(go.Scatterternary(
        name=str(TernaryTraces.STABLE_EQUILIBRIA_AREA.value),
        a=[], b=[], c=[], mode="lines", fill="toself",
        fillcolor=GraphPalette.STABLE_AREA,
        line={"width": 2, "color": GraphPalette.STABLE_AREA},
        opacity=1.0,
        showlegend=False, hoverinfo="skip"
    ))
    fig.add_trace(go.Scatterternary(
        name=str(TernaryTraces.UNSTABLE_EQUILIBRIA_AREA.value),
        a=[], b=[], c=[], mode="lines", fill="toself",
        fillcolor=GraphPalette.UNSTABLE_AREA,
        line={"width": 2, "color": GraphPalette.UNSTABLE_AREA},
        opacity=1.0,
        showlegend=False, hoverinfo="skip"
    ))
    
    # equilibra lines
    fig.add_trace(go.Scatterternary(
        name=str(TernaryTraces.STABLE_EQUILIBRIA.value),
        a=[], b=[], c=[], mode="lines",
        line={"color": GraphPalette.STABLE, "width": 2},
        showlegend=False
    ))
    fig.add_trace(go.Scatterternary(
        name=str(TernaryTraces.UNSTABLE_EQUILIBRIA.value),
        a=[], b=[], c=[], mode="lines",
        line={"color": GraphPalette.UNSTABLE, "width": 2},
        showlegend=False
    ))

    # combination of traces and colors
    traces_to_add = [
        (TernaryTraces.EXTINCT, GraphPalette.EXTINCT),
        (TernaryTraces.SADDLENODE_EMPIRICAL, GraphPalette.SADDLENODE_EMPIRICAL),
        (TernaryTraces.SADDLENODE_ALTERNATIVE, GraphPalette.SADDLENODE_ALTERNATIVE),
        (TernaryTraces.TRANSCRITICAL_EMPIRICAL, GraphPalette.TRANSCRITICAL_EMPIRICAL),
        (TernaryTraces.TRANSCRITICAL_ALTERNATIVE, GraphPalette.TRANSCRITICAL_ALTERNATIVE),
        (TernaryTraces.HOPF_SUBCRITICAL_EMPIRICAL, GraphPalette.HOPF_SUBCRITICAL_EMPIRICAL),
        (TernaryTraces.HOPF_SUBCRITICAL_ALTERNATIVE, GraphPalette.HOPF_SUBCRITICAL_ALTERNATIVE),
        (TernaryTraces.HOPF_SUPERCRITICAL_EMPIRICAL, GraphPalette.HOPF_SUPERCRITICAL_EMPIRICAL),
        (TernaryTraces.HOPF_SUPERCRITICAL_ALTERNATIVE, GraphPalette.HOPF_SUPERCRITICAL_ALTERNATIVE),
        (TernaryTraces.HOPF_BAUTIN_EMPIRICAL, GraphPalette.HOPF_BAUTIN_EMPIRICAL),
        (TernaryTraces.HOPF_BAUTIN_ALTERNATIVE, GraphPalette.HOPF_BAUTIN_ALTERNATIVE),
        (TernaryTraces.INTERNAL_ERROR, GraphPalette.INTERNAL_ERROR)
    ]
    # add traces with corresponding colors
    for trace_enum, color in traces_to_add:
        fig.add_trace(go.Scatterternary(
            name=str(trace_enum.value),
            a=[], b=[], c=[],
            mode="lines+markers",
            marker={"size": 6, "color": color, "opacity": 1},
            line={"color": color},
            showlegend=False
        ))

    # configure layout
    tick_vals_increase = [round(i * 0.1, 1) for i in range(11)]
    tick_vals_decrease = [round(i * 0.1, 1) for i in range(10, -1, -1)]
    tick_text_decrease = [f"{val:g}" for val in tick_vals_decrease]
    marging = 0.05

    # set ternary layout with custom ticks and gridlines
    fig.update_layout(
        ternary={
            "domain": {"x": [marging, 1 - marging], "y": [marging, 1 - marging]},
            "sum": 1,
            "aaxis": {"min": 0, "tickvals": tick_vals_increase, "ticktext": tick_text_decrease, "tickangle": 60, "title": "", "linecolor": "black", "gridcolor": "lightgray"},
            "baxis": {"min": 0, "tickvals": tick_vals_increase, "ticktext": tick_text_decrease, "tickangle": -60, "title": "", "linecolor": "black", "gridcolor": "lightgray"},
            "caxis": {"min": 0, "tickvals": tick_vals_increase, "ticktext": tick_text_decrease, "tickangle": 0, "title": "", "linecolor": "black", "gridcolor": "lightgray"},
            "bgcolor": "white",
        },
        xaxis={"range": [0, 1], "scaleanchor": "y", "scaleratio": 1, "visible": False, "showgrid": False, "zeroline": False, "showticklabels": False, "fixedrange": False},
        yaxis={"range": [0, 1], "visible": False, "showgrid": False, "zeroline": False, "showticklabels": False, "fixedrange": False},
        plot_bgcolor="rgba(0,0,0,0)",
        paper_bgcolor="rgba(0,0,0,0)",
        showlegend=False,
        uirevision="ternary",
        width=glob.config.resolution * 2,
        height=glob.config.resolution * 2,
    )
    fig = add_ternary_arrows(fig)
    glob.config.drawing_options.redraw_ternary.redraw_all()
    return fig