from dash import Input, Output, callback

from food_web_bifurcation_explorer.common import glob
from food_web_bifurcation_explorer.enums.types.parameter_types import ParameterTypes
from food_web_bifurcation_explorer.frontend.ids import IDs


# callback to sync parameter checkboxes
@callback(
    # outputs
    Output(IDs.DROPDOWN_PARAMETER_TYPE, "value"),
    # inputs
    Input(IDs.DROPDOWN_PARAMETER_TYPE, "value"),
    # we don't need an initial call
    prevent_initial_call=True,
)

# select parameter type
def select_parameter_type(parameter_type_str: str):
    # set new parameter type
    try:
        glob.config.update_fixed_parameter_type(ParameterTypes(parameter_type_str))
    except ValueError:
        print(f"Error: invalid parameter '{parameter_type_str}'.")
    # force redraw ternaries and bifurcation diagrams
    glob.config.drawing_options.redraw_ternary.redraw_all()
    glob.config.drawing_options.redraw_bifurcation_diagrams_first.redraw_all()
    glob.config.drawing_options.redraw_bifurcation_diagrams_second.redraw_all()
    return parameter_type_str
