# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ObsBucketObject:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'bucket_name': 'str',
        'location': 'str'
    }

    attribute_map = {
        'bucket_name': 'bucket_name',
        'location': 'location'
    }

    def __init__(self, bucket_name=None, location=None):
        r"""ObsBucketObject

        The model defined in huaweicloud sdk

        :param bucket_name: 桶名称
        :type bucket_name: str
        :param location: 桶所在的区域
        :type location: str
        """
        
        

        self._bucket_name = None
        self._location = None
        self.discriminator = None

        if bucket_name is not None:
            self.bucket_name = bucket_name
        if location is not None:
            self.location = location

    @property
    def bucket_name(self):
        r"""Gets the bucket_name of this ObsBucketObject.

        桶名称

        :return: The bucket_name of this ObsBucketObject.
        :rtype: str
        """
        return self._bucket_name

    @bucket_name.setter
    def bucket_name(self, bucket_name):
        r"""Sets the bucket_name of this ObsBucketObject.

        桶名称

        :param bucket_name: The bucket_name of this ObsBucketObject.
        :type bucket_name: str
        """
        self._bucket_name = bucket_name

    @property
    def location(self):
        r"""Gets the location of this ObsBucketObject.

        桶所在的区域

        :return: The location of this ObsBucketObject.
        :rtype: str
        """
        return self._location

    @location.setter
    def location(self, location):
        r"""Sets the location of this ObsBucketObject.

        桶所在的区域

        :param location: The location of this ObsBucketObject.
        :type location: str
        """
        self._location = location

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ObsBucketObject):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
