# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListEcsSpecificationNewRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'image_business_type': 'int'
    }

    attribute_map = {
        'image_business_type': 'image_business_type'
    }

    def __init__(self, image_business_type=None):
        r"""ListEcsSpecificationNewRequest

        The model defined in huaweicloud sdk

        :param image_business_type: **参数解释**： 镜像类型。 **约束限制**： 以取值范围为准 **取值范围**： - 1：运维 - 2：加密 - 3：审计 **默认取值**：   不传则默认为审计 
        :type image_business_type: int
        """
        
        

        self._image_business_type = None
        self.discriminator = None

        if image_business_type is not None:
            self.image_business_type = image_business_type

    @property
    def image_business_type(self):
        r"""Gets the image_business_type of this ListEcsSpecificationNewRequest.

        **参数解释**： 镜像类型。 **约束限制**： 以取值范围为准 **取值范围**： - 1：运维 - 2：加密 - 3：审计 **默认取值**：   不传则默认为审计 

        :return: The image_business_type of this ListEcsSpecificationNewRequest.
        :rtype: int
        """
        return self._image_business_type

    @image_business_type.setter
    def image_business_type(self, image_business_type):
        r"""Sets the image_business_type of this ListEcsSpecificationNewRequest.

        **参数解释**： 镜像类型。 **约束限制**： 以取值范围为准 **取值范围**： - 1：运维 - 2：加密 - 3：审计 **默认取值**：   不传则默认为审计 

        :param image_business_type: The image_business_type of this ListEcsSpecificationNewRequest.
        :type image_business_type: int
        """
        self._image_business_type = image_business_type

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListEcsSpecificationNewRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
