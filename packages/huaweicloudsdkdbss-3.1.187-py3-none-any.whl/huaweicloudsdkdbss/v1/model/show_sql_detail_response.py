# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowSqlDetailResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'sql': 'SqlDetailBean'
    }

    attribute_map = {
        'sql': 'sql'
    }

    def __init__(self, sql=None):
        r"""ShowSqlDetailResponse

        The model defined in huaweicloud sdk

        :param sql: 
        :type sql: :class:`huaweicloudsdkdbss.v1.SqlDetailBean`
        """
        
        super().__init__()

        self._sql = None
        self.discriminator = None

        if sql is not None:
            self.sql = sql

    @property
    def sql(self):
        r"""Gets the sql of this ShowSqlDetailResponse.

        :return: The sql of this ShowSqlDetailResponse.
        :rtype: :class:`huaweicloudsdkdbss.v1.SqlDetailBean`
        """
        return self._sql

    @sql.setter
    def sql(self, sql):
        r"""Sets the sql of this ShowSqlDetailResponse.

        :param sql: The sql of this ShowSqlDetailResponse.
        :type sql: :class:`huaweicloudsdkdbss.v1.SqlDetailBean`
        """
        self._sql = sql

    def to_dict(self):
        import warnings
        warnings.warn("ShowSqlDetailResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowSqlDetailResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
