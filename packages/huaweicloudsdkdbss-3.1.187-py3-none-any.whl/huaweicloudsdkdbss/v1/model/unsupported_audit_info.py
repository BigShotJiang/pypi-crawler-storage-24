# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UnsupportedAuditInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'audit_version': 'str',
        'server_name': 'str'
    }

    attribute_map = {
        'audit_version': 'audit_version',
        'server_name': 'server_name'
    }

    def __init__(self, audit_version=None, server_name=None):
        r"""UnsupportedAuditInfo

        The model defined in huaweicloud sdk

        :param audit_version: 实例版本
        :type audit_version: str
        :param server_name: 实例名称
        :type server_name: str
        """
        
        

        self._audit_version = None
        self._server_name = None
        self.discriminator = None

        if audit_version is not None:
            self.audit_version = audit_version
        if server_name is not None:
            self.server_name = server_name

    @property
    def audit_version(self):
        r"""Gets the audit_version of this UnsupportedAuditInfo.

        实例版本

        :return: The audit_version of this UnsupportedAuditInfo.
        :rtype: str
        """
        return self._audit_version

    @audit_version.setter
    def audit_version(self, audit_version):
        r"""Sets the audit_version of this UnsupportedAuditInfo.

        实例版本

        :param audit_version: The audit_version of this UnsupportedAuditInfo.
        :type audit_version: str
        """
        self._audit_version = audit_version

    @property
    def server_name(self):
        r"""Gets the server_name of this UnsupportedAuditInfo.

        实例名称

        :return: The server_name of this UnsupportedAuditInfo.
        :rtype: str
        """
        return self._server_name

    @server_name.setter
    def server_name(self, server_name):
        r"""Sets the server_name of this UnsupportedAuditInfo.

        实例名称

        :param server_name: The server_name of this UnsupportedAuditInfo.
        :type server_name: str
        """
        self._server_name = server_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UnsupportedAuditInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
