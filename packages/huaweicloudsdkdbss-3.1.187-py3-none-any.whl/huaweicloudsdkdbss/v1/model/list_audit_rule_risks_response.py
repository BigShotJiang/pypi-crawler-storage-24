# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListAuditRuleRisksResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'rules': 'list[RuleRiskResponseRules]',
        'total': 'int',
        'customize_total': 'int'
    }

    attribute_map = {
        'rules': 'rules',
        'total': 'total',
        'customize_total': 'customize_total'
    }

    def __init__(self, rules=None, total=None, customize_total=None):
        r"""ListAuditRuleRisksResponse

        The model defined in huaweicloud sdk

        :param rules: 风险规则列表
        :type rules: list[:class:`huaweicloudsdkdbss.v1.RuleRiskResponseRules`]
        :param total: 总数
        :type total: int
        :param customize_total: 自定义规则总数
        :type customize_total: int
        """
        
        super().__init__()

        self._rules = None
        self._total = None
        self._customize_total = None
        self.discriminator = None

        if rules is not None:
            self.rules = rules
        if total is not None:
            self.total = total
        if customize_total is not None:
            self.customize_total = customize_total

    @property
    def rules(self):
        r"""Gets the rules of this ListAuditRuleRisksResponse.

        风险规则列表

        :return: The rules of this ListAuditRuleRisksResponse.
        :rtype: list[:class:`huaweicloudsdkdbss.v1.RuleRiskResponseRules`]
        """
        return self._rules

    @rules.setter
    def rules(self, rules):
        r"""Sets the rules of this ListAuditRuleRisksResponse.

        风险规则列表

        :param rules: The rules of this ListAuditRuleRisksResponse.
        :type rules: list[:class:`huaweicloudsdkdbss.v1.RuleRiskResponseRules`]
        """
        self._rules = rules

    @property
    def total(self):
        r"""Gets the total of this ListAuditRuleRisksResponse.

        总数

        :return: The total of this ListAuditRuleRisksResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListAuditRuleRisksResponse.

        总数

        :param total: The total of this ListAuditRuleRisksResponse.
        :type total: int
        """
        self._total = total

    @property
    def customize_total(self):
        r"""Gets the customize_total of this ListAuditRuleRisksResponse.

        自定义规则总数

        :return: The customize_total of this ListAuditRuleRisksResponse.
        :rtype: int
        """
        return self._customize_total

    @customize_total.setter
    def customize_total(self, customize_total):
        r"""Sets the customize_total of this ListAuditRuleRisksResponse.

        自定义规则总数

        :param customize_total: The customize_total of this ListAuditRuleRisksResponse.
        :type customize_total: int
        """
        self._customize_total = customize_total

    def to_dict(self):
        import warnings
        warnings.warn("ListAuditRuleRisksResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAuditRuleRisksResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
