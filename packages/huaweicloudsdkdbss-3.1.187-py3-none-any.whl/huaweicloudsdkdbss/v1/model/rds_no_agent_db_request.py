# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class RdsNoAgentDbRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'databases': 'list[RdsNoAgentDbRequestDatabases]',
        'total_count': 'int'
    }

    attribute_map = {
        'databases': 'databases',
        'total_count': 'total_count'
    }

    def __init__(self, databases=None, total_count=None):
        r"""RdsNoAgentDbRequest

        The model defined in huaweicloud sdk

        :param databases: 添加数据库信息列表
        :type databases: list[:class:`huaweicloudsdkdbss.v1.RdsNoAgentDbRequestDatabases`]
        :param total_count: 总数
        :type total_count: int
        """
        
        

        self._databases = None
        self._total_count = None
        self.discriminator = None

        self.databases = databases
        if total_count is not None:
            self.total_count = total_count

    @property
    def databases(self):
        r"""Gets the databases of this RdsNoAgentDbRequest.

        添加数据库信息列表

        :return: The databases of this RdsNoAgentDbRequest.
        :rtype: list[:class:`huaweicloudsdkdbss.v1.RdsNoAgentDbRequestDatabases`]
        """
        return self._databases

    @databases.setter
    def databases(self, databases):
        r"""Sets the databases of this RdsNoAgentDbRequest.

        添加数据库信息列表

        :param databases: The databases of this RdsNoAgentDbRequest.
        :type databases: list[:class:`huaweicloudsdkdbss.v1.RdsNoAgentDbRequestDatabases`]
        """
        self._databases = databases

    @property
    def total_count(self):
        r"""Gets the total_count of this RdsNoAgentDbRequest.

        总数

        :return: The total_count of this RdsNoAgentDbRequest.
        :rtype: int
        """
        return self._total_count

    @total_count.setter
    def total_count(self, total_count):
        r"""Sets the total_count of this RdsNoAgentDbRequest.

        总数

        :param total_count: The total_count of this RdsNoAgentDbRequest.
        :type total_count: int
        """
        self._total_count = total_count

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RdsNoAgentDbRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
