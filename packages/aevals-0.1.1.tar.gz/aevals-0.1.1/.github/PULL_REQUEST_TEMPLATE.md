## What

Brief description of the change.

## Why

Motivation or issue reference.

## Test plan

- [ ] Tests pass (`pytest`)
- [ ] Lint passes (`ruff check src/ tests/`)
- [ ] Covered by existing or new tests
