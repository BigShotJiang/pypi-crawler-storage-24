---
name: Bug report
labels: bug
---

**Describe the bug**
A clear description of what's broken.

**To reproduce**
Steps to reproduce:
1. ...
2. ...

**Expected behavior**
What you expected to happen.

**Environment**
- OS:
- Python version:
- aevals version:
- LLM SDK + version:

**Logs / traceback**
```
paste here
```
