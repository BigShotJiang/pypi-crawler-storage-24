---
name: Feature request
labels: enhancement
---

**Problem**
What are you trying to do that isn't possible or is harder than it should be?

**Proposed solution**
How you'd like it to work.

**Alternatives considered**
Other approaches you've thought about.
