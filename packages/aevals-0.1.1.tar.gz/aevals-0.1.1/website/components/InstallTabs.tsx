'use client'

import { useState, useCallback } from 'react'

const installCommands = {
  uv: { cmd: 'uv add', pkg: 'aevals' },
  pip: { cmd: 'pip install', pkg: 'aevals' },
} as const

type TabKey = keyof typeof installCommands

export function InstallTabs() {
  const [activeTab, setActiveTab] = useState<TabKey>('uv')
  const [copied, setCopied] = useState(false)

  const { cmd, pkg } = installCommands[activeTab]
  const fullCommand = `${cmd} ${pkg}`

  const handleCopy = useCallback(async () => {
    await navigator.clipboard.writeText(fullCommand)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }, [fullCommand])

  return (
    <div className="install-section" aria-label="Install options">
      <div className="install-tabs" role="tablist">
        {(Object.keys(installCommands) as TabKey[]).map((key) => (
          <button
            key={key}
            role="tab"
            className="install-tab"
            aria-selected={key === activeTab}
            onClick={() => setActiveTab(key)}
          >
            {key}
          </button>
        ))}
      </div>
      <div className="install-panels">
        <button className="install-command" onClick={handleCopy}>
          <code>
            <span className="cmd">{cmd} </span>
            <span className="highlight">{pkg}</span>
          </code>
          <span className={`copy-btn${copied ? ' copied' : ''}`}>
            <svg
              className="copy-icon"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
            >
              <path
                d="M8.75 8.75V2.75H21.25V15.25H15.25M15.25 8.75H2.75V21.25H15.25V8.75Z"
                strokeLinecap="square"
              />
            </svg>
            <svg
              className="check-icon"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path
                d="M2.75 15.0938L9 20.25L21.25 3.75"
                strokeLinecap="square"
              />
            </svg>
          </span>
        </button>
      </div>
    </div>
  )
}
