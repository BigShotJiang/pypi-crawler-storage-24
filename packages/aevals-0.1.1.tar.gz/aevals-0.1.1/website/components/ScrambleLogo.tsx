'use client'

import { useState, useRef, useCallback } from 'react'

const CHARS = 'abcdefghijklmnopqrstuvwxyz'
const FROM = 'aevals'
const TO = 'agent evals'
const FRAME_MS = 30
const SETTLE_STAGGER = 2 // frames between each char settling

function randomChar() {
  return CHARS[Math.floor(Math.random() * CHARS.length)]
}

export function ScrambleLogo() {
  const [display, setDisplay] = useState(FROM)
  const rafRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const scrambleTo = useCallback((target: string) => {
    if (rafRef.current) clearInterval(rafRef.current)

    let frame = 0
    const maxLen = target.length

    rafRef.current = setInterval(() => {
      frame++
      const settled = Math.floor(frame / SETTLE_STAGGER)

      if (settled >= maxLen) {
        setDisplay(target)
        if (rafRef.current) clearInterval(rafRef.current)
        rafRef.current = null
        return
      }

      const chars: string[] = []
      for (let i = 0; i < maxLen; i++) {
        if (i < settled) {
          chars.push(target[i])
        } else {
          chars.push(randomChar())
        }
      }
      setDisplay(chars.join(''))
    }, FRAME_MS)
  }, [])

  const handleEnter = useCallback(() => {
    scrambleTo(TO)
  }, [scrambleTo])

  const handleLeave = useCallback(() => {
    scrambleTo(FROM)
  }, [scrambleTo])

  return (
    <a
      href="/"
      className="landing-logo"
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
    >
      {display}
    </a>
  )
}
