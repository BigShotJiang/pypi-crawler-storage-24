'use client'

import { useState, useCallback } from 'react'

function CopyIcon() {
  return (
    <svg
      className="copy-icon"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
    >
      <path
        d="M8.75 8.75V2.75H21.25V15.25H15.25M15.25 8.75H2.75V21.25H15.25V8.75Z"
        strokeLinecap="square"
      />
    </svg>
  )
}

function CheckIcon() {
  return (
    <svg
      className="check-icon"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
    >
      <path d="M2.75 15.0938L9 20.25L21.25 3.75" strokeLinecap="square" />
    </svg>
  )
}

export function CopyButton({
  text,
  className,
}: {
  text: string
  className?: string
}) {
  const [copied, setCopied] = useState(false)

  const handleCopy = useCallback(async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }, [text])

  return (
    <button
      className={className}
      onClick={handleCopy}
      aria-label="Copy to clipboard"
    >
      <span className={`copy-btn${copied ? ' copied' : ''}`}>
        <CopyIcon />
        <CheckIcon />
      </span>
    </button>
  )
}

export function CopyButtonStandalone({
  text,
  className,
}: {
  text: string
  className?: string
}) {
  const [copied, setCopied] = useState(false)

  const handleCopy = useCallback(async () => {
    await navigator.clipboard.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }, [text])

  return (
    <button
      className={`${className ?? ''}${copied ? ' copied' : ''}`}
      onClick={handleCopy}
      aria-label="Copy code"
    >
      <CopyIcon />
      <CheckIcon />
    </button>
  )
}
