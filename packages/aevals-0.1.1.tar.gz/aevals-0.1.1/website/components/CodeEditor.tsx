'use client'

import { useState, useCallback } from 'react'

const FileIcon = () => (
  <svg
    className="code-editor-tab-icon"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
  >
    <path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z" />
    <polyline points="13 2 13 9 20 9" />
  </svg>
)

interface CodePanel {
  id: string
  filename: string
  lines: number
  code: string
  rawCode: string
}

const panels: CodePanel[] = [
  {
    id: 'config',
    filename: 'aevals.yaml',
    lines: 14,
    rawCode: `config_version: 1
entry: src.agent:main

judge:
  model: openai/gpt-4.1

scenarios:
  - name: simple-booking
    input: "Book SFO to JFK next Tuesday"
    rubric:
      - "Calls search_flights before book_flight"
      - "Confirms with user before booking"
    constraints:
      max_steps: 5`,
    code: `<span class="property">config_version</span><span class="operator">:</span> <span class="number">1</span>
<span class="property">entry</span><span class="operator">:</span> <span class="string">src.agent:main</span>

<span class="property">judge</span><span class="operator">:</span>
  <span class="property">model</span><span class="operator">:</span> <span class="string">openai/gpt-4.1</span>

<span class="property">scenarios</span><span class="operator">:</span>
  - <span class="property">name</span><span class="operator">:</span> <span class="string">simple-booking</span>
    <span class="property">input</span><span class="operator">:</span> <span class="string">"Book SFO to JFK next Tuesday"</span>
    <span class="property">rubric</span><span class="operator">:</span>
      - <span class="string">"Calls search_flights before book_flight"</span>
      - <span class="string">"Confirms with user before booking"</span>
    <span class="property">constraints</span><span class="operator">:</span>
      <span class="property">max_steps</span><span class="operator">:</span> <span class="number">5</span>`,
  },
  {
    id: 'run',
    filename: 'terminal',
    lines: 13,
    rawCode: `$ aevals run

── simple-booking ─────────────────────
  3 spans | 4.2s | 1,840 tokens

  Constraints:
    ✓ steps: 3 <= 5
    ✓ duration: 4200ms <= 10000ms

  Rubric: (judge: openai/gpt-4.1)
    ✓ Calls search_flights before book_flight
    ✓ Confirms with user before booking

  PASS`,
    code: `<span class="function">$</span> <span class="keyword">aevals run</span>

<span class="comment">── simple-booking ─────────────────────</span>
  <span class="number">3</span> spans | <span class="number">4.2s</span> | <span class="number">1,840</span> tokens

  Constraints:
    <span class="string">✓</span> steps: 3 <= 5
    <span class="string">✓</span> duration: 4200ms <= 10000ms

  Rubric: <span class="comment">(judge: openai/gpt-4.1)</span>
    <span class="string">✓</span> Calls search_flights before book_flight
    <span class="string">✓</span> Confirms with user before booking

  <span class="keyword">PASS</span>`,
  },
  {
    id: 'ci',
    filename: 'eval.yml',
    lines: 11,
    rawCode: `# .github/workflows/eval.yml
name: Evals
on: [push]
jobs:
  eval:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: pip install aevals
      - run: aevals run --json
      # Exit: 0 = pass, 1 = fail, 2 = no traces`,
    code: `<span class="comment"># .github/workflows/eval.yml</span>
<span class="property">name</span><span class="operator">:</span> <span class="string">Evals</span>
<span class="property">on</span><span class="operator">:</span> <span class="string">[push]</span>
<span class="property">jobs</span><span class="operator">:</span>
  <span class="property">eval</span><span class="operator">:</span>
    <span class="property">runs-on</span><span class="operator">:</span> <span class="string">ubuntu-latest</span>
    <span class="property">steps</span><span class="operator">:</span>
      - <span class="property">uses</span><span class="operator">:</span> <span class="string">actions/checkout@v4</span>
      - <span class="property">run</span><span class="operator">:</span> <span class="keyword">pip install aevals</span>
      - <span class="property">run</span><span class="operator">:</span> <span class="keyword">aevals run --json</span>
      <span class="comment"># Exit: 0 = pass, 1 = fail, 2 = no traces</span>`,
  },
]

export function CodeEditor() {
  const [activePanel, setActivePanel] = useState('config')
  const [copied, setCopied] = useState(false)

  const currentPanel = panels.find((p) => p.id === activePanel)!

  const handleCopy = useCallback(async () => {
    await navigator.clipboard.writeText(currentPanel.rawCode)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }, [currentPanel.rawCode])

  return (
    <section className="code-section">
      <div className="code-editor">
        <div className="code-editor-header">
          <div className="code-editor-tabs" role="tablist">
            {panels.map((panel) => (
              <button
                key={panel.id}
                role="tab"
                className="code-editor-tab"
                aria-selected={panel.id === activePanel}
                onClick={() => {
                  setActivePanel(panel.id)
                  setCopied(false)
                }}
              >
                <FileIcon />
                {panel.filename}
              </button>
            ))}
          </div>
          <button
            className={`code-editor-copy${copied ? ' copied' : ''}`}
            onClick={handleCopy}
            aria-label="Copy code"
          >
            <svg
              className="copy-icon"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
            >
              <path
                d="M8.75 8.75V2.75H21.25V15.25H15.25M15.25 8.75H2.75V21.25H15.25V8.75Z"
                strokeLinecap="square"
              />
            </svg>
            <svg
              className="check-icon"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
            >
              <path
                d="M2.75 15.0938L9 20.25L21.25 3.75"
                strokeLinecap="square"
              />
            </svg>
          </button>
        </div>

        {panels.map((panel) => (
          <div
            key={panel.id}
            className="code-editor-body"
            data-active={panel.id === activePanel ? 'true' : 'false'}
          >
            <div className="code-editor-lines">
              {Array.from({ length: panel.lines }, (_, i) => (
                <span key={i}>{i + 1}</span>
              ))}
            </div>
            <pre>
              <code dangerouslySetInnerHTML={{ __html: panel.code }} />
            </pre>
          </div>
        ))}
      </div>
    </section>
  )
}
