'use client'

import { useState, useCallback, useEffect } from 'react'

export function MobileMenuButton() {
  const [isOpen, setIsOpen] = useState(false)

  const toggle = useCallback(() => {
    setIsOpen((prev) => {
      const next = !prev
      document.body.classList.toggle('mobile-nav-open', next)
      return next
    })
  }, [])

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        setIsOpen(false)
        document.body.classList.remove('mobile-nav-open')
      }
    }
    document.addEventListener('keydown', handleEscape)
    return () => document.removeEventListener('keydown', handleEscape)
  }, [isOpen])

  return (
    <button
      className="mobile-menu-btn"
      aria-label={isOpen ? 'Close navigation menu' : 'Open navigation menu'}
      aria-expanded={isOpen}
      onClick={toggle}
    >
      <svg className="menu-icon" viewBox="0 0 24 24" fill="currentColor">
        <rect x="5" y="8" width="14" height="2" />
        <rect x="5" y="14" width="14" height="2" />
      </svg>
      <svg className="close-icon" viewBox="0 0 24 24" fill="currentColor">
        <rect
          x="5"
          y="11"
          width="14"
          height="2"
          transform="rotate(45 12 12)"
        />
        <rect
          x="5"
          y="11"
          width="14"
          height="2"
          transform="rotate(-45 12 12)"
        />
      </svg>
    </button>
  )
}
