"use client";

import { useState, useCallback, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { InstallTabs } from "@/components/InstallTabs";
import { CodeEditor } from "@/components/CodeEditor";
import { MobileMenuButton } from "@/components/MobileMenu";
import { ScrambleLogo } from "@/components/ScrambleLogo";

const features = [
  {
    title: "Zero to eval",
    description:
      "Scans your codebase, detects SDKs and entrypoints, generates config. You edit scenarios, not scaffolding.",
  },
  {
    title: "Deterministic constraints",
    description:
      "Duration, step count, tool ordering, loop detection. Zero LLM cost. Your CI gate, for free.",
  },
  {
    title: "LLM-as-judge rubrics",
    description:
      "Natural-language assertions scored against the full trajectory — every LLM call and tool invocation, not just the final answer.",
  },
  {
    title: "OTel tracing",
    description:
      "Auto-instruments 6 LLM SDKs via OpenTelemetry. Pipe traces to Langfuse, Phoenix, Jaeger, or any OTel backend.",
  },
  {
    title: "Subprocess isolation",
    description:
      "Each scenario runs in its own process with independent tracing. No shared state, no crosstalk.",
  },
  {
    title: "No platform",
    description:
      "pip install, BYO API keys, all data stays local. Same command on your laptop and in CI.",
  },
];

const faqs = [
  {
    q: "What agents does aevals work with?",
    a: "Any Python agent that makes LLM calls. aevals auto-detects OpenAI, Anthropic, Google GenAI, Cohere, Mistral, and LiteLLM SDKs. If your agent uses one of these, it works out of the box.",
  },
  {
    q: "Do I need to modify my agent code?",
    a: "No. aevals scans your codebase, generates a wrapper, and runs your agent in a subprocess. Your code stays untouched.",
  },
  {
    q: "What's the difference between constraints and rubrics?",
    a: "Constraints are deterministic checks — duration, step count, tool ordering — that cost zero LLM calls. Rubrics are natural-language assertions scored by an LLM judge against the full agent trajectory.",
  },
  {
    q: "Can I run aevals in CI?",
    a: "Yes. It's a pip install with a CLI. No platform, no dashboard, no account. Same command locally and in CI. Constraints are free; rubric evaluation needs an API key for the judge model.",
  },
  {
    q: "Where do traces go?",
    a: "By default, traces are written to local JSON files in .aevals/traces/. Since aevals uses OpenTelemetry, you can pipe traces to Langfuse, Phoenix, Jaeger, or any OTel-compatible backend.",
  },
  {
    q: "Is aevals free?",
    a: "Yes, MIT licensed. The only cost is LLM API calls for rubric evaluation — and that's optional. Deterministic constraints are completely free.",
  },
];

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);

  return (
    <div className={`faq-item${open ? " open" : ""}`}>
      <button className="faq-question" onClick={() => setOpen(!open)}>
        <span>{q}</span>
        <svg
          className="faq-chevron"
          width="16"
          height="16"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.5"
        >
          <path d="M6 9L12 15L18 9" strokeLinecap="square" />
        </svg>
      </button>
      <div className="faq-answer">
        <p>{a}</p>
      </div>
    </div>
  );
}

const ArrowIcon = () => (
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M6.5 12L17 12M13 16.5L17.5 12L13 7.5"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="square"
    />
  </svg>
);


function ViewToggle({
  mode,
  onToggle,
}: {
  mode: "human" | "agent";
  onToggle: () => void;
}) {
  return (
    <div className="view-toggle">
      <button
        className="view-toggle-btn"
        data-active={mode === "human"}
        onClick={() => mode !== "human" && onToggle()}
      >
        Human
      </button>
      <button
        className="view-toggle-btn"
        data-active={mode === "agent"}
        onClick={() => mode !== "agent" && onToggle()}
      >
        Agent
      </button>
    </div>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = useCallback(async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }, [text]);

  return (
    <button
      className={`agent-copy-btn${copied ? " copied" : ""}`}
      onClick={handleCopy}
      aria-label="Copy markdown"
    >
      {copied ? (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M2.75 15.0938L9 20.25L21.25 3.75" strokeLinecap="square" />
        </svg>
      ) : (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
          <path d="M8.75 8.75V2.75H21.25V15.25H15.25M15.25 8.75H2.75V21.25H15.25V8.75Z" strokeLinecap="square" />
        </svg>
      )}
    </button>
  );
}

function AgentView() {
  const [content, setContent] = useState("");

  useEffect(() => {
    fetch("/llms.txt")
      .then((res) => res.text())
      .then(setContent);
  }, []);

  if (!content) return null;

  return (
    <div className="agent-view">
      <CopyButton text={content} />
      <pre className="agent-markdown">{content}</pre>
    </div>
  );
}

export function LandingPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialMode = searchParams.get("view") === "agent" ? "agent" : "human";
  const [mode, setMode] = useState<"human" | "agent">(initialMode);

  const toggleMode = useCallback(() => {
    const next = mode === "human" ? "agent" : "human";
    setMode(next);
    const url = next === "agent" ? "/?view=agent" : "/";
    router.replace(url, { scroll: false });
  }, [mode, router]);

  return (
    <main className="landing">
      <div className="landing-container">
        {/* Header */}
        <header className="landing-header">
          <ScrambleLogo />
          <MobileMenuButton />
          <nav className="landing-nav">
            <a
              href="https://github.com/satyaborg/aevals"
              target="_blank"
              rel="noopener noreferrer"
            >
              GitHub
            </a>
            <a
              href="https://pypi.org/project/aevals/"
              target="_blank"
              rel="noopener noreferrer"
            >
              PyPI
            </a>
          </nav>
        </header>

        {/* Mobile nav */}
        <nav className="mobile-nav">
          <a
            href="https://github.com/satyaborg/aevals"
            target="_blank"
            rel="noopener noreferrer"
          >
            GitHub
          </a>
          <a
            href="https://pypi.org/project/aevals/"
            target="_blank"
            rel="noopener noreferrer"
          >
            PyPI
          </a>
        </nav>

        {/* View Toggle */}
        <ViewToggle mode={mode} onToggle={toggleMode} />

        {mode === "human" ? (
          <>
            {/* Hero */}
            <section className="hero">
              <div className="hero-content">
                <div className="hero-copy">
                  <h1>From Zero to Evals</h1>
                  <p className="hero-subtitle">
                    Go from zero evals to running evals in three commands. Scan
                    your agent code, generate test scenarios, and score runs
                    against deterministic constraints and LLM-judged rubrics.
                  </p>
                </div>
                <InstallTabs />
              </div>
            </section>

            {/* Code Examples */}
            <CodeEditor />

            {/* What is aevals */}
            <section className="what-section">
              <div className="what-section-title">
                <h3>What is aevals?</h3>
                <p>
                  Most teams building agents know they should eval. They
                  don&rsquo;t. The problem isn&rsquo;t motivation — it&rsquo;s
                  that nobody knows where to start. aevals closes that gap.
                  Point it at your codebase and it figures out the rest — which
                  SDKs you use, where your entrypoint is, what tools your agent
                  has.
                </p>
              </div>

              <ul className="what-list">
                {features.map((feature, i) => (
                  <li key={i}>
                    <span className="bullet">[*]</span>
                    <div>
                      <strong>{feature.title}</strong> {feature.description}
                    </div>
                  </li>
                ))}
              </ul>

            </section>

            {/* FAQ */}
            <section className="faq-section">
              <h3>FAQ</h3>
              <div className="faq-list">
                {faqs.map((faq, i) => (
                  <FAQItem key={i} q={faq.q} a={faq.a} />
                ))}
              </div>
            </section>

            {/* CTA */}
            <div className="what-actions">
              <a
                href="https://github.com/satyaborg/aevals#quick-start"
                className="btn-dark"
              >
                <span>Get started</span>
                <ArrowIcon />
              </a>
            </div>

            {/* Footer */}
            <footer className="landing-footer">
              <div className="landing-footer-cell">
                <a
                  href="https://github.com/satyaborg/aevals"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  GitHub
                </a>
              </div>
              <div className="landing-footer-cell">
                <a
                  href="https://pypi.org/project/aevals/"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  PyPI
                </a>
              </div>
            </footer>
          </>
        ) : (
          <AgentView />
        )}
      </div>

      {/* Legal */}
      {mode === "human" && (
        <div className="landing-legal">
          <span>MIT License</span>
        </div>
      )}
    </main>
  );
}
