import { Inter, IBM_Plex_Mono, Silkscreen } from "next/font/google";
import type { Metadata } from "next";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-inter",
});

const ibmPlexMono = IBM_Plex_Mono({
  weight: ["400", "500", "700"],
  subsets: ["latin"],
  display: "swap",
  variable: "--font-ibm-plex-mono",
});

const silkscreen = Silkscreen({
  weight: "400",
  subsets: ["latin"],
  display: "swap",
  variable: "--font-silkscreen",
});

export const metadata: Metadata = {
  title: "Aevals - e2e evals for agents",
  description:
    "Go from zero evals to running evals in three commands. Scans your agent code, generates test scenarios, and scores runs against deterministic constraints and LLM-judged rubrics.",
  icons: {
    icon: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="en"
      className={`${inter.variable} ${ibmPlexMono.variable} ${silkscreen.variable} dark`}
      suppressHydrationWarning
    >
      <head>
        <link
          rel="alternate"
          type="text/markdown"
          href="/llms.txt"
          title="LLM-readable content"
        />
      </head>
      <body>{children}</body>
    </html>
  );
}
