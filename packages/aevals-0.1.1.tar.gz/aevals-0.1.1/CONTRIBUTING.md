# Contributing to aevals

Thanks for your interest in contributing. This guide covers setup, workflow, and conventions.

## Setup

```bash
git clone https://github.com/satyaborg/aevals.git
cd aevals
pip install -e ".[dev]"
pre-commit install
```

## Development workflow

1. Create a branch: `git checkout -b type/short-description`
   - Types: `feat/`, `fix/`, `chore/`, `docs/`, `test/`
2. Make your changes
3. Run checks:

```bash
pytest                                      # tests
pytest --cov=aevals --cov-fail-under=90     # with coverage
ruff check src/ tests/                      # lint
ruff format src/ tests/                     # format
```

4. Commit with a clear, imperative message under 72 chars
5. Open a PR against `main`

## Code conventions

- **Python 3.12+**. Line length 100.
- **Type hints everywhere**. No `Any` unless forced by a library boundary. Strict pyright.
- **Double quotes** for strings (ruff default). Trailing commas always.
- **Imports**: stdlib, third-party, local — separated by blank lines. Sorted by ruff/isort.
- **Shared constants** live in `constants.py`. Don't hardcode `.aevals/` paths.
- **File access**: use `try/except FileNotFoundError` instead of `if path.exists()` then read (TOCTOU).
- **Async tests** use `pytest-asyncio` with `asyncio_mode = "auto"` — no `@pytest.mark.asyncio` needed.

## Testing

- Write tests for any function with branching logic or >10 lines.
- Prefer real objects over mocks. Mock only at system boundaries (network, disk, time).
- Test names: `test_<what>_<condition>_<expected>`.
- CI enforces 90% coverage.

## Pull requests

- Keep PRs small and focused. If a PR touches >300 lines, consider splitting it.
- One logical change per commit.
- PRs run CI automatically (lint + test).

## Lint rules

Ruff is configured with: `E`, `F`, `I`, `UP`, `B`, `SIM`, `RUF`, `PT`, `PIE`, `C4`, `RET`, `PERF`.

Pre-commit hooks run ruff and pyright automatically on commit.

## Releases

Releases are maintainer-only. Run `./scripts/release.sh <patch|minor|major>` from a clean `main` branch — it bumps the version, generates the changelog, tags, and pushes. GitHub Actions handles PyPI publishing via trusted OIDC.
