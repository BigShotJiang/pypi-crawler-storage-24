# Booking Agent

A flight booking agent using the OpenAI SDK. Searches flights, books tickets, checks weather, and answers policy questions.

## Tools

| Tool | Description |
|------|-------------|
| `search_flights` | Search available flights by origin/destination |
| `book_flight` | Book a flight for a passenger |
| `get_policy` | Retrieve refund/cancellation policy |
| `get_weather` | Check weather at a city (intentionally slow 50% of the time) |

All tools use mock data — no real API calls.

## Eval scenarios

The `aevals.yaml` defines four scenarios:

- **Simple booking** — full search-then-book workflow with tool ordering constraint
- **Policy question** — retrieval-only, should not invoke booking tools
- **Edge case (obscure route)** — no flights available, tests graceful failure
- **Weather check** — single tool call with tight duration constraint

## Run

```bash
cd examples/booking-agent
pip install openai
export OPENAI_API_KEY=sk-...
aevals run
```
