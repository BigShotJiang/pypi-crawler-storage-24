"""Simple booking agent using OpenAI SDK.

This is an example agent with intentional failure modes for testing aevals.
"""

from __future__ import annotations

import json
import os

from openai import OpenAI

from tools import book_flight, get_policy, get_weather, search_flights

SYSTEM_PROMPT = """\
You are a flight booking assistant. You can:
- Search for flights between airports
- Book flights for passengers
- Answer policy questions
- Check weather at destinations

Always search before booking. Always confirm with the user before booking.
If no flights are available, say so and suggest alternatives."""

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_flights",
            "description": "Search for available flights",
            "parameters": {
                "type": "object",
                "properties": {
                    "origin": {"type": "string"},
                    "destination": {"type": "string"},
                },
                "required": ["origin", "destination"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "book_flight",
            "description": "Book a flight",
            "parameters": {
                "type": "object",
                "properties": {
                    "flight_id": {"type": "string"},
                    "passenger": {"type": "string"},
                },
                "required": ["flight_id", "passenger"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_policy",
            "description": "Get the refund/cancellation policy",
            "parameters": {"type": "object", "properties": {}},
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "Get weather at a city",
            "parameters": {
                "type": "object",
                "properties": {
                    "city": {"type": "string"},
                },
                "required": ["city"],
            },
        },
    },
]

TOOL_FNS = {
    "search_flights": lambda args: search_flights(args["origin"], args["destination"]),
    "book_flight": lambda args: book_flight(args["flight_id"], args["passenger"]),
    "get_policy": lambda _args: get_policy(),
    "get_weather": lambda args: get_weather(args["city"]),
}


def run(user_input: str) -> str:
    """Run the booking agent. This is the aevals entry point."""
    client = OpenAI()
    messages: list[dict[str, object]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_input},
    ]

    max_turns = 10
    for _ in range(max_turns):
        response = client.chat.completions.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            messages=messages,  # type: ignore[arg-type]
            tools=TOOLS,  # type: ignore[arg-type]
        )

        choice = response.choices[0]

        if choice.finish_reason == "stop":
            return choice.message.content or ""

        if choice.finish_reason == "tool_calls" and choice.message.tool_calls:
            messages.append(choice.message.model_dump())  # type: ignore[arg-type]

            for tool_call in choice.message.tool_calls:
                fn_name = tool_call.function.name
                fn_args = json.loads(tool_call.function.arguments)

                if fn_name in TOOL_FNS:
                    result = TOOL_FNS[fn_name](fn_args)
                else:
                    result = {"error": f"Unknown tool: {fn_name}"}

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(result, default=str),
                    }
                )
        else:
            return choice.message.content or ""

    return "Max turns reached."
