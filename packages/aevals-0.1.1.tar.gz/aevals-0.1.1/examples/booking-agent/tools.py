"""Mock tools for the booking agent example."""

from __future__ import annotations

import random
import time

FLIGHTS_DB: dict[str, list[dict[str, str | int]]] = {
    "SFO-JFK": [
        {"flight": "UA123", "time": "08:00", "price": 350},
        {"flight": "AA456", "time": "14:00", "price": 420},
    ],
    "LAX-ORD": [
        {"flight": "DL789", "time": "10:00", "price": 280},
    ],
}

POLICY = (
    "Refund policy: Full refund within 14 days of booking. "
    "After 14 days, a $50 cancellation fee applies. "
    "No refunds within 24 hours of departure."
)


def search_flights(origin: str, destination: str) -> list[dict[str, str | int]]:
    """Search for available flights."""
    key = f"{origin}-{destination}"
    return FLIGHTS_DB.get(key, [])


def book_flight(flight_id: str, passenger: str) -> dict[str, str]:
    """Book a flight. Returns confirmation."""
    confirmation = f"CONF-{random.randint(10000, 99999)}"
    return {
        "status": "booked",
        "flight": flight_id,
        "passenger": passenger,
        "confirmation": confirmation,
    }


def get_policy() -> str:
    """Get the refund policy."""
    return POLICY


def get_weather(city: str) -> dict[str, str | int]:
    """Get weather for a city. Intentionally slow 50% of the time."""
    if random.random() < 0.5:
        time.sleep(3)  # Simulate timeout
    return {"city": city, "temp": 72, "condition": "sunny"}
