# SDR Agent

A sales development agent using the OpenAI SDK. Researches leads, qualifies against an ICP, drafts personalized outreach, and schedules meetings.

## Tools

| Tool | Description |
|------|-------------|
| `search_leads` | Search CRM by name, company, title, or industry |
| `get_lead` | Get full details for a lead by ID |
| `enrich_company` | Look up company data (size, funding, tech stack, ICP fit) |
| `get_contact_history` | Get prior outreach and interactions |
| `send_email` | Send a personalized outreach email |
| `schedule_meeting` | Schedule a discovery call, demo, or follow-up |
| `qualify_lead` | Run ICP scoring (intentionally slow 50% of the time) |
| `get_campaigns` | List outreach campaigns by status |
| `enroll_in_campaign` | Enroll a lead in an automated outreach cadence |

All tools use mock CRM data — no real API calls or emails sent.

## Eval scenarios

The `aevals.yaml` defines seven scenarios:

- **New lead outreach** — full research-then-email workflow with tool ordering
- **Follow-up with unresponsive lead** — must check history and change angle
- **Disqualify poor-fit lead** — should NOT send outreach to bad ICP fit
- **Schedule discovery call** — look up lead, book a meeting
- **Unknown lead lookup** — lead not in CRM, tests graceful failure
- **Enroll new lead in campaign** — must pick active (not draft) campaign
- **Slow qualification timeout** — tight duration constraint on slow tool

## Run

```bash
cd examples/sdr-agent
pip install openai
export OPENAI_API_KEY=sk-...
aevals run
```
