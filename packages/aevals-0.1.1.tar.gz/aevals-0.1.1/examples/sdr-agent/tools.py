"""Mock CRM and sales tools for the SDR agent example.

Simulates a CRM database with leads, companies, contact history,
outreach campaigns, and scheduling for a B2B SaaS sales workflow.
"""

from __future__ import annotations

import random
import time

# ---------------------------------------------------------------------------
# Mock CRM data
# ---------------------------------------------------------------------------

LEADS_DB: dict[str, dict[str, object]] = {
    "lead-001": {
        "name": "Sarah Chen",
        "title": "VP of Engineering",
        "company": "Acme Corp",
        "email": "s.chen@acmecorp.io",
        "phone": "+1-415-555-0142",
        "linkedin": "linkedin.com/in/sarahchen-eng",
        "status": "new",
        "source": "webinar signup",
        "industry": "fintech",
        "campaign_id": None,
    },
    "lead-002": {
        "name": "James Rivera",
        "title": "CTO",
        "company": "NovaTech",
        "email": "jrivera@novatech.com",
        "phone": "+1-512-555-0198",
        "linkedin": "linkedin.com/in/jamesrivera",
        "status": "contacted",
        "source": "inbound demo request",
        "industry": "healthtech",
        "campaign_id": "camp-01",
    },
    "lead-003": {
        "name": "Priya Sharma",
        "title": "Director of Data",
        "company": "Vertex Analytics",
        "email": "priya@vertexanalytics.co",
        "phone": "+1-628-555-0173",
        "linkedin": "linkedin.com/in/priyasharma-data",
        "status": "replied",
        "source": "content download",
        "industry": "analytics",
        "campaign_id": "camp-02",
    },
    "lead-004": {
        "name": "Marcus Thompson",
        "title": "Intern",
        "company": "TinyStartup",
        "email": "marcus@tinystartup.io",
        "phone": None,
        "linkedin": None,
        "status": "new",
        "source": "cold list",
        "industry": "unknown",
        "campaign_id": None,
    },
    "lead-005": {
        "name": "Elena Vasquez",
        "title": "Head of Platform",
        "company": "Acme Corp",
        "email": "e.vasquez@acmecorp.io",
        "phone": "+1-415-555-0207",
        "linkedin": "linkedin.com/in/elenavasquez",
        "status": "new",
        "source": "referred by Sarah Chen",
        "industry": "fintech",
        "campaign_id": None,
    },
    "lead-006": {
        "name": "David Kim",
        "title": "Staff Engineer",
        "company": "NovaTech",
        "email": "dkim@novatech.com",
        "phone": "+1-512-555-0221",
        "linkedin": "linkedin.com/in/davidkim-swe",
        "status": "new",
        "source": "blog subscriber",
        "industry": "healthtech",
        "campaign_id": None,
    },
}

COMPANIES_DB: dict[str, dict[str, object]] = {
    "Acme Corp": {
        "domain": "acmecorp.io",
        "industry": "fintech",
        "employees": 450,
        "arr_range": "$10M-$25M",
        "funding": "Series C - $80M",
        "investors": "Sequoia, a16z",
        "tech_stack": "Python, AWS, Kubernetes, Postgres",
        "recent_news": "Just closed Series C, expanding engineering team by 40%",
        "decision_makers": 3,
        "icp_fit": "strong",
    },
    "NovaTech": {
        "domain": "novatech.com",
        "industry": "healthtech",
        "employees": 200,
        "arr_range": "$5M-$10M",
        "funding": "Series B - $35M",
        "investors": "GV, Khosla Ventures",
        "tech_stack": "Java, GCP, Terraform, MongoDB",
        "recent_news": "Launched HIPAA-compliant data platform last quarter",
        "decision_makers": 2,
        "icp_fit": "strong",
    },
    "Vertex Analytics": {
        "domain": "vertexanalytics.co",
        "industry": "analytics",
        "employees": 85,
        "arr_range": "$1M-$5M",
        "funding": "Series A - $12M",
        "investors": "First Round Capital",
        "tech_stack": "Python, Snowflake, dbt, AWS",
        "recent_news": "Hiring 5 data engineers, posted on LinkedIn this week",
        "decision_makers": 1,
        "icp_fit": "moderate",
    },
    "TinyStartup": {
        "domain": "tinystartup.io",
        "industry": "unknown",
        "employees": 3,
        "arr_range": "Pre-revenue",
        "funding": "Pre-seed - $50K",
        "investors": "Friends and family",
        "tech_stack": "WordPress",
        "recent_news": None,
        "decision_makers": 1,
        "icp_fit": "poor",
    },
}

CONTACT_HISTORY: dict[str, list[dict[str, str]]] = {
    "lead-002": [
        {
            "date": "2026-02-25",
            "type": "email",
            "campaign": "camp-01",
            "step": "1/3",
            "subject": "Observability for HIPAA-compliant platforms",
            "status": "opened",
            "snippet": "Hi James, saw NovaTech just launched a HIPAA-compliant platform...",
        },
        {
            "date": "2026-02-28",
            "type": "email",
            "campaign": "camp-01",
            "step": "2/3",
            "subject": "Quick question about your monitoring stack",
            "status": "opened",
            "snippet": "Following up — curious how your team handles observability across...",
        },
        {
            "date": "2026-03-03",
            "type": "email",
            "campaign": "camp-01",
            "step": "3/3",
            "subject": "Last note — 15 min to show you something",
            "status": "no_reply",
            "snippet": "Totally understand if the timing isn't right...",
        },
    ],
    "lead-003": [
        {
            "date": "2026-03-05",
            "type": "email",
            "campaign": "camp-02",
            "step": "1/3",
            "subject": "Congrats on the data team growth",
            "status": "replied",
            "snippet": "Hi Priya, noticed Vertex is hiring data engineers...",
            "reply": "Thanks! We're actually looking at observability tools. Can we chat?",
        },
    ],
}

CAMPAIGNS_DB: dict[str, dict[str, object]] = {
    "camp-01": {
        "name": "Healthtech Outbound Q1",
        "status": "active",
        "target_persona": "CTO / VP Eng at healthtech companies (Series A+)",
        "enrolled": 12,
        "replied": 3,
        "meetings_booked": 1,
        "steps": [
            {
                "step": 1,
                "day": 0,
                "type": "email",
                "subject_template": "Observability for {industry} platforms",
                "angle": "Lead with industry-specific compliance pain point",
            },
            {
                "step": 2,
                "day": 3,
                "type": "email",
                "subject_template": "Quick question about your monitoring stack",
                "angle": "Ask about current tooling, position as upgrade",
            },
            {
                "step": 3,
                "day": 7,
                "type": "email",
                "subject_template": "Last note — 15 min to show you something",
                "angle": "Breakup email, low-pressure ask for a short call",
            },
        ],
    },
    "camp-02": {
        "name": "Data Team Expansion",
        "status": "active",
        "target_persona": "Director/Head of Data at growing analytics companies",
        "enrolled": 8,
        "replied": 2,
        "meetings_booked": 0,
        "steps": [
            {
                "step": 1,
                "day": 0,
                "type": "email",
                "subject_template": "Congrats on the data team growth",
                "angle": "Reference hiring activity, pitch observability for scaling teams",
            },
            {
                "step": 2,
                "day": 4,
                "type": "linkedin",
                "subject_template": "Connection request + short note",
                "angle": "Warm touch on LinkedIn, reference email",
            },
            {
                "step": 3,
                "day": 7,
                "type": "email",
                "subject_template": "How {company} can save 10hrs/week on debugging",
                "angle": "ROI-focused, mention case study from similar company",
            },
        ],
    },
    "camp-03": {
        "name": "Series C+ Enterprise Play",
        "status": "draft",
        "target_persona": "VP Eng / Head of Platform at Series C+ fintech",
        "enrolled": 0,
        "replied": 0,
        "meetings_booked": 0,
        "steps": [
            {
                "step": 1,
                "day": 0,
                "type": "email",
                "subject_template": "Scaling observability after Series C",
                "angle": "Reference funding round, pitch enterprise-grade platform",
            },
            {
                "step": 2,
                "day": 3,
                "type": "email",
                "subject_template": "{name}, quick thought on your infra roadmap",
                "angle": "Personalized note referencing tech stack and growth",
            },
        ],
    },
}

CALENDAR_SLOTS = [
    "2026-03-14 10:00 AM PST",
    "2026-03-14 2:00 PM PST",
    "2026-03-15 11:00 AM PST",
    "2026-03-17 9:00 AM PST",
]


# ---------------------------------------------------------------------------
# Tool functions
# ---------------------------------------------------------------------------


def search_leads(query: str) -> list[dict[str, object]]:
    """Search CRM for leads matching a query string."""
    results = []
    query_lower = query.lower()
    for lead_id, lead in LEADS_DB.items():
        searchable = f"{lead['name']} {lead['company']} {lead['title']} {lead['industry']}"
        if query_lower in searchable.lower():
            results.append({"id": lead_id, **lead})
    return results


def get_lead(lead_id: str) -> dict[str, object]:
    """Get full details for a specific lead."""
    lead = LEADS_DB.get(lead_id)
    if not lead:
        return {"error": f"Lead {lead_id} not found"}
    return {"id": lead_id, **lead}


def enrich_company(company_name: str) -> dict[str, object]:
    """Look up company data for ICP qualification."""
    company = COMPANIES_DB.get(company_name)
    if not company:
        return {"error": f"No data found for {company_name}"}
    return {"company": company_name, **company}


def get_contact_history(lead_id: str) -> list[dict[str, str]]:
    """Get prior outreach history for a lead."""
    return CONTACT_HISTORY.get(lead_id, [])


def get_campaigns(status: str | None = None) -> list[dict[str, object]]:
    """List outreach campaigns, optionally filtered by status."""
    results = []
    for camp_id, camp in CAMPAIGNS_DB.items():
        if status and camp["status"] != status:
            continue
        results.append({"id": camp_id, **camp})
    return results


def enroll_in_campaign(lead_id: str, campaign_id: str) -> dict[str, str]:
    """Enroll a lead in an outreach campaign."""
    if lead_id not in LEADS_DB:
        return {"error": f"Lead {lead_id} not found"}
    if campaign_id not in CAMPAIGNS_DB:
        return {"error": f"Campaign {campaign_id} not found"}
    lead = LEADS_DB[lead_id]
    if lead.get("campaign_id"):
        return {
            "error": f"Lead already enrolled in campaign {lead['campaign_id']}",
            "lead_id": lead_id,
        }
    campaign = CAMPAIGNS_DB[campaign_id]
    if campaign["status"] == "draft":
        return {"error": f"Campaign {campaign_id} is in draft status, cannot enroll"}
    # Simulate enrollment
    return {
        "status": "enrolled",
        "lead_id": lead_id,
        "campaign_id": campaign_id,
        "campaign_name": str(campaign["name"]),
        "first_step_date": "2026-03-12",
    }


def send_email(to: str, subject: str, body: str) -> dict[str, str]:
    """Send an outreach email via the CRM."""
    if not to or not subject or not body:
        return {"error": "Missing required fields: to, subject, body"}
    return {
        "status": "sent",
        "to": to,
        "subject": subject,
        "message_id": f"msg-{random.randint(10000, 99999)}",
    }


def schedule_meeting(lead_id: str, time_slot: str, meeting_type: str) -> dict[str, str]:
    """Schedule a meeting with a lead."""
    if lead_id not in LEADS_DB:
        return {"error": f"Lead {lead_id} not found"}
    if time_slot not in CALENDAR_SLOTS:
        return {"error": f"Slot {time_slot} not available", "available": CALENDAR_SLOTS}
    return {
        "status": "scheduled",
        "lead_id": lead_id,
        "time": time_slot,
        "type": meeting_type,
        "meeting_link": f"https://meet.example.com/{random.randint(100000, 999999)}",
    }


def qualify_lead(lead_id: str) -> dict[str, object]:
    """Run ICP scoring on a lead. Intentionally slow 50% of the time."""
    if random.random() < 0.5:
        time.sleep(3)
    lead = LEADS_DB.get(lead_id)
    if not lead:
        return {"error": f"Lead {lead_id} not found"}
    company = COMPANIES_DB.get(str(lead["company"]), {})
    fit = company.get("icp_fit", "unknown")
    return {
        "lead_id": lead_id,
        "icp_fit": str(fit),
        "qualified": fit in ("strong", "moderate"),
        "reason": f"Company ICP fit: {fit}",
    }
