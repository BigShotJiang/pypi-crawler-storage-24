"""SDR (Sales Development Representative) agent using OpenAI SDK.

A realistic outbound sales agent that researches leads, qualifies prospects
against an ICP, drafts personalized outreach, and schedules meetings.
Designed as an aevals example with intentional failure modes for testing.
"""

from __future__ import annotations

import json
import os

from openai import OpenAI
from tools import (
    enrich_company,
    enroll_in_campaign,
    get_campaigns,
    get_contact_history,
    get_lead,
    qualify_lead,
    schedule_meeting,
    search_leads,
    send_email,
)

SYSTEM_PROMPT = """\
You are an AI-powered Sales Development Representative (SDR) for DataFlow, \
a B2B developer tools company that sells an observability platform.

Your responsibilities:
- Research and qualify inbound leads against the Ideal Customer Profile (ICP)
- Draft personalized outreach emails referencing the prospect's role, company, \
and recent activity
- Follow up with leads who haven't responded, adjusting tone and angle
- Schedule discovery calls when a lead is qualified and engaged
- Enroll qualified leads in the right outreach campaign based on persona fit
- Disqualify leads that don't fit the ICP and explain why

ICP criteria:
- Company size: 50-1000 employees
- Industries: fintech, healthtech, analytics, devtools, cloud infrastructure
- Funding: Series A or later
- Tech stack: Uses Python, Java, or Go with cloud infrastructure

Rules:
- ALWAYS look up company data before sending outreach to personalize the message
- ALWAYS check contact history before following up to avoid repeating yourself
- NEVER send outreach to unqualified leads without flagging them first
- Keep emails under 150 words, professional but conversational
- Reference something specific about the company (news, tech stack, hiring)
- When enrolling leads in campaigns, pick the campaign that matches their persona
- NEVER enroll a lead in a draft campaign"""

TOOLS = [
    {
        "type": "function",
        "function": {
            "name": "search_leads",
            "description": "Search CRM for leads by name, company, title, or industry",
            "parameters": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (name, company, title, or industry)",
                    },
                },
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_lead",
            "description": "Get full details for a specific lead by ID",
            "parameters": {
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string"},
                },
                "required": ["lead_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "enrich_company",
            "description": "Look up company data including size, funding, tech stack, and ICP fit",
            "parameters": {
                "type": "object",
                "properties": {
                    "company_name": {"type": "string"},
                },
                "required": ["company_name"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_contact_history",
            "description": "Get prior outreach emails and interactions for a lead",
            "parameters": {
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string"},
                },
                "required": ["lead_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "send_email",
            "description": "Send a personalized outreach email to a lead",
            "parameters": {
                "type": "object",
                "properties": {
                    "to": {"type": "string", "description": "Recipient email address"},
                    "subject": {"type": "string", "description": "Email subject line"},
                    "body": {"type": "string", "description": "Email body text"},
                },
                "required": ["to", "subject", "body"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "schedule_meeting",
            "description": "Schedule a discovery call or demo with a lead",
            "parameters": {
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string"},
                    "time_slot": {
                        "type": "string",
                        "description": "Meeting time (e.g. '2026-03-14 10:00 AM PST')",
                    },
                    "meeting_type": {
                        "type": "string",
                        "enum": ["discovery", "demo", "follow_up"],
                    },
                },
                "required": ["lead_id", "time_slot", "meeting_type"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "qualify_lead",
            "description": "Run ICP scoring on a lead to determine qualification status",
            "parameters": {
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string"},
                },
                "required": ["lead_id"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "get_campaigns",
            "description": "List outreach campaigns, optionally filtered by status (active/draft)",
            "parameters": {
                "type": "object",
                "properties": {
                    "status": {
                        "type": "string",
                        "enum": ["active", "draft"],
                        "description": "Filter by campaign status",
                    },
                },
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "enroll_in_campaign",
            "description": "Enroll a lead in an outreach campaign to start automated cadence",
            "parameters": {
                "type": "object",
                "properties": {
                    "lead_id": {"type": "string"},
                    "campaign_id": {"type": "string"},
                },
                "required": ["lead_id", "campaign_id"],
            },
        },
    },
]

TOOL_FNS = {
    "search_leads": lambda args: search_leads(args["query"]),
    "get_lead": lambda args: get_lead(args["lead_id"]),
    "enrich_company": lambda args: enrich_company(args["company_name"]),
    "get_contact_history": lambda args: get_contact_history(args["lead_id"]),
    "send_email": lambda args: send_email(args["to"], args["subject"], args["body"]),
    "schedule_meeting": lambda args: schedule_meeting(
        args["lead_id"], args["time_slot"], args["meeting_type"]
    ),
    "qualify_lead": lambda args: qualify_lead(args["lead_id"]),
    "get_campaigns": lambda args: get_campaigns(args.get("status")),
    "enroll_in_campaign": lambda args: enroll_in_campaign(args["lead_id"], args["campaign_id"]),
}


def run(user_input: str) -> str:
    """Run the SDR agent. This is the aevals entry point."""
    client = OpenAI()
    messages: list[dict[str, object]] = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_input},
    ]

    max_turns = 15
    for _ in range(max_turns):
        response = client.chat.completions.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            messages=messages,  # type: ignore[arg-type]
            tools=TOOLS,  # type: ignore[arg-type]
        )

        choice = response.choices[0]

        if choice.finish_reason == "stop":
            return choice.message.content or ""

        if choice.finish_reason == "tool_calls" and choice.message.tool_calls:
            messages.append(choice.message.model_dump())  # type: ignore[arg-type]

            for tool_call in choice.message.tool_calls:
                fn_name = tool_call.function.name
                fn_args = json.loads(tool_call.function.arguments)

                if fn_name in TOOL_FNS:
                    result = TOOL_FNS[fn_name](fn_args)
                else:
                    result = {"error": f"Unknown tool: {fn_name}"}

                messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call.id,
                        "content": json.dumps(result, default=str),
                    }
                )
        else:
            return choice.message.content or ""

    return "Max turns reached."
