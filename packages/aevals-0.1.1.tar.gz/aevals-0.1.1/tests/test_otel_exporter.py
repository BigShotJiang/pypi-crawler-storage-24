"""Tests for aevals.capture.otel JSONFileSpanExporter and helpers."""

from __future__ import annotations

import json
from unittest.mock import MagicMock

from opentelemetry.sdk.trace.export import SpanExportResult

from aevals.capture.otel import JSONFileSpanExporter, _span_to_dict


class TestJSONFileSpanExporter:
    def test_creates_parent_directory(self, tmp_path):
        path = tmp_path / "nested" / "dir" / "trace.json"
        JSONFileSpanExporter(str(path))
        assert path.parent.exists()

    def test_exports_spans(self, tmp_path):
        path = tmp_path / "trace.json"
        exporter = JSONFileSpanExporter(str(path))

        mock_span = MagicMock()
        mock_span.name = "test-span"
        mock_span.start_time = 1000000000
        mock_span.end_time = 2000000000
        mock_span.attributes = {"key": "value"}
        mock_span.context = MagicMock()
        mock_span.context.span_id = 0x1234
        mock_span.status = MagicMock()
        mock_span.status.status_code.name = "OK"

        result = exporter.export([mock_span])
        assert result == SpanExportResult.SUCCESS

        data = json.loads(path.read_text())
        assert len(data) == 1
        assert data[0]["name"] == "test-span"

    def test_accumulates_spans(self, tmp_path):
        path = tmp_path / "trace.json"
        exporter = JSONFileSpanExporter(str(path))

        def make_span(name):
            span = MagicMock()
            span.name = name
            span.start_time = 0
            span.end_time = 100
            span.attributes = {}
            span.context = MagicMock()
            span.context.span_id = 0xABCD
            span.status = MagicMock()
            span.status.status_code.name = "OK"
            return span

        exporter.export([make_span("span1")])
        exporter.export([make_span("span2")])

        data = json.loads(path.read_text())
        assert len(data) == 2
        assert data[0]["name"] == "span1"
        assert data[1]["name"] == "span2"

    def test_shutdown_flushes(self, tmp_path):
        path = tmp_path / "trace.json"
        exporter = JSONFileSpanExporter(str(path))
        exporter.shutdown()
        data = json.loads(path.read_text())
        assert data == []

    def test_force_flush(self, tmp_path):
        path = tmp_path / "trace.json"
        exporter = JSONFileSpanExporter(str(path))
        assert exporter.force_flush() is True
        assert path.exists()


class TestSpanToDict:
    def test_converts_span(self):
        span = MagicMock()
        span.name = "llm.call"
        span.start_time = 1_000_000_000
        span.end_time = 2_000_000_000
        span.attributes = {"gen_ai.system": "openai"}
        span.context = MagicMock()
        span.context.span_id = 0xDEADBEEF
        span.status = MagicMock()
        span.status.status_code.name = "OK"

        result = _span_to_dict(span)
        assert result["name"] == "llm.call"
        assert result["duration_ms"] == 1000
        assert result["attributes"]["gen_ai.system"] == "openai"
        assert result["status"] == "OK"

    def test_handles_none_attributes(self):
        span = MagicMock()
        span.name = "test"
        span.start_time = 0
        span.end_time = 0
        span.attributes = None
        span.context = MagicMock()
        span.context.span_id = 0
        span.status = MagicMock()
        span.status.status_code.name = "UNSET"

        result = _span_to_dict(span)
        assert result["attributes"] == {}

    def test_handles_none_times(self):
        span = MagicMock()
        span.name = "test"
        span.start_time = None
        span.end_time = None
        span.attributes = {}
        span.context = MagicMock()
        span.context.span_id = 0
        span.status = MagicMock()
        span.status.status_code.name = "UNSET"

        result = _span_to_dict(span)
        assert result["duration_ms"] == 0
