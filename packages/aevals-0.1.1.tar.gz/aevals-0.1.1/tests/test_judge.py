"""Tests for aevals.evals.judge."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from aevals.capture.schema import LLMCall, Trajectory
from aevals.config.schema import Scenario
from aevals.evals.judge import (
    JudgeError,
    _format_trajectory,
    _parse_judge_response,
    evaluate_rubric,
)


@pytest.fixture
def trajectory() -> Trajectory:
    return Trajectory(
        run_id="test-run",
        scenario=Scenario(name="test", input="hi"),
        spans=[
            LLMCall(
                span_id="s1",
                model="gpt-4o",
                messages=[{"role": "user", "content": "hi"}],
                response="hello",
                tool_calls=None,
                tokens_in=5,
                tokens_out=5,
                duration_ms=100,
                provider="openai",
                error=None,
            ),
        ],
        output={"output": "done"},
        status="success",
        exit_code=0,
        stderr=None,
        total_duration_ms=100,
        total_tokens=10,
    )


class TestFormatTrajectory:
    def test_formats_basic_trajectory(self, trajectory):
        result = _format_trajectory(trajectory)
        parsed = json.loads(result)
        assert parsed["status"] == "success"
        assert parsed["total_duration_ms"] == 100
        assert len(parsed["spans"]) == 1
        assert parsed["spans"][0]["model"] == "gpt-4o"
        assert parsed["output"] == {"output": "done"}

    def test_omits_none_fields(self):
        traj = Trajectory(
            run_id="t",
            scenario=Scenario(name="t", input="t"),
            spans=[
                LLMCall(
                    span_id="s1",
                    model="gpt-4o",
                    messages=None,
                    response=None,
                    tool_calls=None,
                    tokens_in=None,
                    tokens_out=None,
                    duration_ms=50,
                    provider="openai",
                    error=None,
                ),
            ],
            output=None,
            status="success",
            exit_code=0,
            stderr=None,
            total_duration_ms=50,
            total_tokens=None,
        )
        result = _format_trajectory(traj)
        parsed = json.loads(result)
        assert "output" not in parsed
        span = parsed["spans"][0]
        assert "messages" not in span
        assert "response" not in span
        assert "tool_calls" not in span
        assert "error" not in span


class TestParseJudgeResponse:
    def test_parses_array(self):
        content = json.dumps(
            [
                {"criterion_index": 1, "passed": True, "reason": "good"},
                {"criterion_index": 2, "passed": False, "reason": "bad"},
            ]
        )
        rubric = ["criterion 1", "criterion 2"]
        results = _parse_judge_response(content, rubric)
        assert len(results) == 2
        assert results[0].passed is True
        assert results[0].criterion == "criterion 1"
        assert results[0].reason == "good"
        assert results[1].passed is False

    def test_parses_wrapped_object(self):
        content = json.dumps(
            {
                "results": [
                    {"criterion_index": 1, "passed": True, "reason": "ok"},
                ]
            }
        )
        results = _parse_judge_response(content, ["crit 1"])
        assert len(results) == 1
        assert results[0].passed is True

    def test_parses_criteria_key(self):
        content = json.dumps(
            {
                "criteria": [
                    {"criterion_index": 1, "passed": False, "reason": "nope"},
                ]
            }
        )
        results = _parse_judge_response(content, ["crit 1"])
        assert results[0].passed is False

    def test_parses_evaluations_key(self):
        content = json.dumps(
            {
                "evaluations": [
                    {"criterion_index": 1, "passed": True, "reason": "yes"},
                ]
            }
        )
        results = _parse_judge_response(content, ["crit 1"])
        assert results[0].passed is True

    def test_falls_back_to_positional(self):
        content = json.dumps(
            [
                {"passed": True, "reason": "positional match"},
            ]
        )
        results = _parse_judge_response(content, ["crit 1"])
        assert results[0].passed is True
        assert results[0].reason == "positional match"

    def test_missing_criterion(self):
        content = json.dumps(
            [
                {"criterion_index": 1, "passed": True, "reason": "ok"},
            ]
        )
        results = _parse_judge_response(content, ["crit 1", "crit 2"])
        assert results[0].passed is True
        assert results[1].passed is False
        assert "did not return" in results[1].reason

    def test_invalid_json_raises(self):
        with pytest.raises(JudgeError, match="invalid JSON"):
            _parse_judge_response("not json", ["crit"])

    def test_non_array_raises(self):
        with pytest.raises(JudgeError, match="Expected JSON array"):
            _parse_judge_response(json.dumps({"unexpected": "structure"}), ["crit"])

    def test_empty_rubric(self):
        content = json.dumps([])
        results = _parse_judge_response(content, [])
        assert results == []


class TestEvaluateRubric:
    @pytest.mark.asyncio
    async def test_empty_rubric_returns_empty(self, trajectory):
        results = await evaluate_rubric(trajectory, [], "gpt-4o")
        assert results == []

    @pytest.mark.asyncio
    async def test_calls_litellm(self, trajectory):
        mock_response = MagicMock()
        mock_response.choices = [
            MagicMock(
                message=MagicMock(
                    content=json.dumps(
                        [
                            {"criterion_index": 1, "passed": True, "reason": "good"},
                        ]
                    )
                )
            )
        ]

        with patch("aevals.evals.judge.litellm") as mock_litellm:
            mock_litellm.acompletion = AsyncMock(return_value=mock_response)
            results = await evaluate_rubric(trajectory, ["should greet"], "gpt-4o")

        assert len(results) == 1
        assert results[0].passed is True
        mock_litellm.acompletion.assert_called_once()
        call_kwargs = mock_litellm.acompletion.call_args
        assert call_kwargs.kwargs["model"] == "gpt-4o"
        assert call_kwargs.kwargs["temperature"] == 0.0

    @pytest.mark.asyncio
    async def test_raises_on_litellm_error(self, trajectory):
        with patch("aevals.evals.judge.litellm") as mock_litellm:
            mock_litellm.acompletion = AsyncMock(side_effect=RuntimeError("API down"))
            with pytest.raises(JudgeError, match="Judge call failed"):
                await evaluate_rubric(trajectory, ["crit"], "gpt-4o")

    @pytest.mark.asyncio
    async def test_raises_on_empty_response(self, trajectory):
        mock_response = MagicMock()
        mock_response.choices = [MagicMock(message=MagicMock(content=""))]
        with patch("aevals.evals.judge.litellm") as mock_litellm:
            mock_litellm.acompletion = AsyncMock(return_value=mock_response)
            with pytest.raises(JudgeError, match="empty response"):
                await evaluate_rubric(trajectory, ["crit"], "gpt-4o")
