"""Tests for aevals.capture.otel (parse_trace_file)."""

from __future__ import annotations

import json

from aevals.capture.otel import parse_trace_file


class TestParseTraceFile:
    def test_parses_valid_trace(self, tmp_path, trace_data):
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(trace_data))
        calls = parse_trace_file(trace_file)
        assert len(calls) == 2

        assert calls[0].span_id == "abc123"
        assert calls[0].model == "gpt-4o-mini"
        assert calls[0].provider == "openai"
        assert calls[0].tokens_in == 10
        assert calls[0].tokens_out == 20
        assert calls[0].duration_ms == 500

    def test_extracts_messages(self, tmp_path, trace_data):
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(trace_data))
        calls = parse_trace_file(trace_file)
        assert calls[0].messages is not None
        assert calls[0].messages[0]["role"] == "user"
        assert calls[0].messages[0]["content"] == "hello"

    def test_extracts_response(self, tmp_path, trace_data):
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(trace_data))
        calls = parse_trace_file(trace_file)
        assert calls[0].response == "Hi there!"

    def test_extracts_tool_calls(self, tmp_path, trace_data):
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(trace_data))
        calls = parse_trace_file(trace_file)
        assert calls[1].tool_calls is not None
        assert calls[1].tool_calls[0]["name"] == "search_flights"

    def test_returns_empty_for_missing_file(self, tmp_path):
        calls = parse_trace_file(tmp_path / "nonexistent.json")
        assert calls == []

    def test_returns_empty_for_non_list(self, tmp_path):
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps({"not": "a list"}))
        calls = parse_trace_file(trace_file)
        assert calls == []

    def test_skips_non_llm_spans(self, tmp_path):
        data = [
            {
                "span_id": "x",
                "name": "http.request",
                "start_time": 0,
                "end_time": 100,
                "duration_ms": 100,
                "attributes": {"http.url": "https://example.com"},
                "status": "OK",
            },
        ]
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(data))
        calls = parse_trace_file(trace_file)
        assert calls == []

    def test_skips_non_dict_items(self, tmp_path):
        data = ["not_a_dict", 42, None]
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(data))
        calls = parse_trace_file(trace_file)
        assert calls == []

    def test_handles_missing_tokens(self, tmp_path):
        data = [
            {
                "span_id": "s1",
                "name": "llm.call",
                "start_time": 0,
                "end_time": 100000000,
                "duration_ms": 100,
                "attributes": {
                    "gen_ai.request.model": "gpt-4o",
                    "gen_ai.system": "openai",
                },
                "status": "OK",
            },
        ]
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(data))
        calls = parse_trace_file(trace_file)
        assert len(calls) == 1
        assert calls[0].tokens_in is None
        assert calls[0].tokens_out is None

    def test_handles_span_with_error(self, tmp_path):
        data = [
            {
                "span_id": "s1",
                "name": "llm.call",
                "start_time": 0,
                "end_time": 100000000,
                "duration_ms": 100,
                "attributes": {
                    "gen_ai.request.model": "gpt-4o",
                    "gen_ai.system": "openai",
                    "error.message": "Rate limit exceeded",
                },
                "status": "ERROR",
            },
        ]
        trace_file = tmp_path / "trace.json"
        trace_file.write_text(json.dumps(data))
        calls = parse_trace_file(trace_file)
        assert calls[0].error == "Rate limit exceeded"

    def test_empty_trace_file(self, tmp_path):
        trace_file = tmp_path / "trace.json"
        trace_file.write_text("[]")
        calls = parse_trace_file(trace_file)
        assert calls == []
