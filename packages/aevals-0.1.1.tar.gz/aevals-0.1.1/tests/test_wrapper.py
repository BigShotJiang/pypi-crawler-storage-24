"""Tests for aevals.scanner.wrapper."""

from __future__ import annotations

from aevals.constants import RESULT_MARKER_END, RESULT_MARKER_START
from aevals.scanner.wrapper import generate_wrapper


class TestGenerateWrapper:
    def test_creates_wrapper_file(self, tmp_path):
        wrapper_path = generate_wrapper(tmp_path)
        assert wrapper_path.exists()
        assert wrapper_path.name == "run_wrapper.py"

    def test_creates_parent_dir(self, tmp_path):
        target = tmp_path / "nested" / "dir"
        wrapper_path = generate_wrapper(target)
        assert target.exists()
        assert wrapper_path.exists()

    def test_contains_markers(self, tmp_path):
        wrapper_path = generate_wrapper(tmp_path)
        content = wrapper_path.read_text()
        assert RESULT_MARKER_START in content
        assert RESULT_MARKER_END in content

    def test_contains_required_imports(self, tmp_path):
        wrapper_path = generate_wrapper(tmp_path)
        content = wrapper_path.read_text()
        assert "import importlib" in content
        assert "import json" in content
        assert "import os" in content
        assert "import sys" in content

    def test_contains_activate_call(self, tmp_path):
        wrapper_path = generate_wrapper(tmp_path)
        content = wrapper_path.read_text()
        assert "from aevals.capture.otel import activate" in content
        assert "activate(" in content

    def test_contains_entry_loading(self, tmp_path):
        wrapper_path = generate_wrapper(tmp_path)
        content = wrapper_path.read_text()
        assert "AEVALS_ENTRY" in content
        assert "importlib.import_module" in content

    def test_valid_python_syntax(self, tmp_path):
        wrapper_path = generate_wrapper(tmp_path)
        content = wrapper_path.read_text()
        compile(content, str(wrapper_path), "exec")  # raises SyntaxError if invalid

    def test_overwrites_existing(self, tmp_path):
        wrapper_path = generate_wrapper(tmp_path)
        first_content = wrapper_path.read_text()
        wrapper_path2 = generate_wrapper(tmp_path)
        assert wrapper_path == wrapper_path2
        assert wrapper_path2.read_text() == first_content
