"""Tests for aevals.cli.run (integration-level)."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest
from click.testing import CliRunner

from aevals.capture.schema import Trajectory
from aevals.cli.run import _error_result, run_cmd
from aevals.config.schema import AevalsConfig, Scenario
from aevals.evals.types import ScenarioResult


class TestErrorResult:
    def test_creates_error_result(self):
        scenario = Scenario(name="test", input="hi")
        result = _error_result("run-1", scenario, "something broke")
        assert isinstance(result, ScenarioResult)
        assert result.passed is False
        assert result.trajectory.status == "error"
        assert result.trajectory.stderr == "something broke"
        assert result.trajectory.spans == []
        assert result.constraint_results == []
        assert result.rubric_results == []
        assert result.rubric_pending is True

    def test_preserves_run_id(self):
        scenario = Scenario(name="test", input="hi")
        result = _error_result("my-run-id", scenario, "err")
        assert result.trajectory.run_id == "my-run-id"


class TestRunCmd:
    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_exits_on_missing_config(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = runner.invoke(run_cmd, [])
        assert result.exit_code != 0
        assert "Error" in result.output or "not found" in result.output

    def test_no_scenarios_exits(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = AevalsConfig(entry="mod:func", scenarios=[])
        with patch("aevals.cli.run.load_config", return_value=config):
            result = runner.invoke(run_cmd, [])
            assert result.exit_code != 0
            assert "No scenarios" in result.output

    def test_no_scenarios_after_filter(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        scenario = Scenario(name="flight-booking", input="book a flight")
        config = AevalsConfig(entry="mod:func", scenarios=[scenario])
        with patch("aevals.cli.run.load_config", return_value=config):
            result = runner.invoke(run_cmd, ["--scenario", "nonexistent"])
            assert result.exit_code != 0

    def test_json_output_flag(self, runner, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        scenario = Scenario(name="test", input="hi")
        config = AevalsConfig(entry="mod:func", scenarios=[scenario])

        mock_trajectory = Trajectory(
            run_id="r1",
            scenario=scenario,
            spans=[],
            output=None,
            status="success",
            exit_code=0,
            stderr=None,
            total_duration_ms=100,
            total_tokens=None,
        )
        mock_result = ScenarioResult(
            scenario=scenario,
            trajectory=mock_trajectory,
            constraint_results=[],
            rubric_results=[],
            rubric_pending=True,
            passed=True,
        )

        async def mock_run(*args, **kwargs):
            return [mock_result]

        with (
            patch("aevals.cli.run.load_config", return_value=config),
            patch("aevals.cli.run.run_scenarios", side_effect=mock_run),
        ):
            result = runner.invoke(run_cmd, ["--json"])
            # With zero spans, it exits with code 2
            if result.exit_code == 2:
                assert "Zero spans" in result.output
            else:
                parsed = json.loads(result.output)
                assert "summary" in parsed
