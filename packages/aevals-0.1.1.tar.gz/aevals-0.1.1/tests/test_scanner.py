"""Tests for aevals.scanner.detect."""

from __future__ import annotations

from aevals.scanner.detect import scan_directory


class TestScanDirectory:
    def test_empty_directory(self, tmp_path):
        result = scan_directory(tmp_path)
        assert result.python_files == []
        assert result.sdks == []
        assert result.entrypoint_candidates == []
        assert result.tool_definitions == []

    def test_detects_openai_import(self, tmp_path):
        (tmp_path / "agent.py").write_text("from openai import OpenAI\n")
        result = scan_directory(tmp_path)
        assert "openai" in result.sdks

    def test_detects_anthropic_import(self, tmp_path):
        (tmp_path / "agent.py").write_text("import anthropic\n")
        result = scan_directory(tmp_path)
        assert "anthropic" in result.sdks

    def test_detects_multiple_sdks(self, tmp_path):
        (tmp_path / "a.py").write_text("import openai\n")
        (tmp_path / "b.py").write_text("import anthropic\n")
        result = scan_directory(tmp_path)
        assert "openai" in result.sdks
        assert "anthropic" in result.sdks

    def test_detects_entrypoint_main(self, tmp_path):
        (tmp_path / "app.py").write_text("def main():\n    pass\n")
        result = scan_directory(tmp_path)
        assert any("main" in ep for ep in result.entrypoint_candidates)

    def test_detects_entrypoint_run(self, tmp_path):
        (tmp_path / "agent.py").write_text("def run():\n    pass\n")
        result = scan_directory(tmp_path)
        assert any("run" in ep for ep in result.entrypoint_candidates)

    def test_detects_async_entrypoint(self, tmp_path):
        (tmp_path / "agent.py").write_text("async def main():\n    pass\n")
        result = scan_directory(tmp_path)
        assert any("main" in ep for ep in result.entrypoint_candidates)

    def test_detects_graph_entrypoint(self, tmp_path):
        (tmp_path / "workflow.py").write_text("def graph():\n    pass\n")
        result = scan_directory(tmp_path)
        assert any("graph" in ep for ep in result.entrypoint_candidates)

    def test_detects_tool_decorator(self, tmp_path):
        code = "@tool\ndef search():\n    pass\n"
        (tmp_path / "tools.py").write_text(code)
        result = scan_directory(tmp_path)
        assert len(result.tool_definitions) == 1
        assert "search" in result.tool_definitions[0]

    def test_detects_tool_call_decorator(self, tmp_path):
        code = "@tool(name='search')\ndef search_fn():\n    pass\n"
        (tmp_path / "tools.py").write_text(code)
        result = scan_directory(tmp_path)
        assert len(result.tool_definitions) == 1

    def test_skips_venv(self, tmp_path):
        venv = tmp_path / "venv" / "lib"
        venv.mkdir(parents=True)
        (venv / "pkg.py").write_text("import openai\n")
        result = scan_directory(tmp_path)
        assert result.sdks == []
        assert result.python_files == []

    def test_skips_git(self, tmp_path):
        git_dir = tmp_path / ".git" / "hooks"
        git_dir.mkdir(parents=True)
        (git_dir / "pre-commit.py").write_text("import openai\n")
        result = scan_directory(tmp_path)
        assert result.sdks == []

    def test_skips_pycache(self, tmp_path):
        cache = tmp_path / "__pycache__"
        cache.mkdir()
        (cache / "mod.py").write_text("import openai\n")
        result = scan_directory(tmp_path)
        assert result.sdks == []

    def test_counts_python_files(self, tmp_path):
        (tmp_path / "a.py").write_text("")
        (tmp_path / "b.py").write_text("")
        (tmp_path / "c.txt").write_text("")
        result = scan_directory(tmp_path)
        assert len(result.python_files) == 2

    def test_handles_syntax_error(self, tmp_path):
        (tmp_path / "bad.py").write_text("def f(\n")
        result = scan_directory(tmp_path)
        assert len(result.python_files) == 1  # still counted
        assert result.sdks == []  # but not parsed

    def test_nested_directory(self, tmp_path):
        sub = tmp_path / "src" / "agents"
        sub.mkdir(parents=True)
        (sub / "main.py").write_text("import openai\ndef run():\n    pass\n")
        result = scan_directory(tmp_path)
        assert "openai" in result.sdks
        assert any("run" in ep for ep in result.entrypoint_candidates)

    def test_from_import(self, tmp_path):
        (tmp_path / "a.py").write_text("from openai.types import ChatCompletion\n")
        result = scan_directory(tmp_path)
        assert "openai" in result.sdks

    def test_bedrock_boto3(self, tmp_path):
        (tmp_path / "a.py").write_text("import boto3\n")
        result = scan_directory(tmp_path)
        assert "bedrock" in result.sdks

    def test_langchain(self, tmp_path):
        (tmp_path / "a.py").write_text("from langchain.agents import AgentExecutor\n")
        result = scan_directory(tmp_path)
        assert "langchain" in result.sdks
