"""Tests for aevals.config.schema."""

from __future__ import annotations

import pytest
from pydantic import ValidationError

from aevals.config.schema import (
    AevalsConfig,
    Constraints,
    DefaultsConfig,
    JudgeConfig,
    RunConfig,
    Scenario,
)


class TestConstraints:
    def test_defaults_all_none(self):
        c = Constraints()
        assert c.max_duration_ms is None
        assert c.max_steps is None
        assert c.tool_sequence is None
        assert c.no_repeat_calls is None
        assert c.output_contains is None

    def test_all_fields(self):
        c = Constraints(
            max_duration_ms=5000,
            max_steps=10,
            tool_sequence=["search", "book"],
            no_repeat_calls=3,
            output_contains="success",
        )
        assert c.max_duration_ms == 5000
        assert c.tool_sequence == ["search", "book"]


class TestScenario:
    def test_minimal(self):
        s = Scenario(name="test", input="hello")
        assert s.name == "test"
        assert s.input == "hello"
        assert s.tags == []
        assert s.rubric == []
        assert s.constraints == Constraints()

    def test_full(self):
        s = Scenario(
            name="booking",
            input="Book a flight",
            tags=["booking"],
            rubric=["should search first"],
            constraints=Constraints(max_steps=5),
        )
        assert s.tags == ["booking"]
        assert s.rubric == ["should search first"]
        assert s.constraints.max_steps == 5


class TestJudgeConfig:
    def test_valid(self):
        j = JudgeConfig(model="gpt-4o")
        assert j.model == "gpt-4o"

    def test_empty_model_fails(self):
        with pytest.raises(ValidationError, match="judge model must not be empty"):
            JudgeConfig(model="   ")


class TestRunConfig:
    def test_default_timeout(self):
        r = RunConfig()
        assert r.timeout_ms == 60000

    def test_custom_timeout(self):
        r = RunConfig(timeout_ms=30000)
        assert r.timeout_ms == 30000


class TestAevalsConfig:
    def test_minimal(self):
        c = AevalsConfig(entry="mod:func")
        assert c.entry == "mod:func"
        assert c.scenarios == []
        assert c.judge is None
        assert c.config_version == 1

    def test_entry_requires_colon(self):
        with pytest.raises(ValidationError, match="module:callable"):
            AevalsConfig(entry="no_colon_here")

    def test_resolve_constraints_defaults_only(self):
        config = AevalsConfig(
            entry="mod:func",
            defaults=DefaultsConfig(constraints=Constraints(max_duration_ms=10000, max_steps=20)),
        )
        scenario = Scenario(name="test", input="hi")
        resolved = config.resolve_constraints(scenario)
        assert resolved.max_duration_ms == 10000
        assert resolved.max_steps == 20

    def test_resolve_constraints_scenario_overrides(self):
        config = AevalsConfig(
            entry="mod:func",
            defaults=DefaultsConfig(constraints=Constraints(max_duration_ms=10000, max_steps=20)),
        )
        scenario = Scenario(
            name="test",
            input="hi",
            constraints=Constraints(max_steps=5),
        )
        resolved = config.resolve_constraints(scenario)
        assert resolved.max_duration_ms == 10000  # from defaults
        assert resolved.max_steps == 5  # overridden

    def test_resolve_constraints_no_defaults(self):
        config = AevalsConfig(entry="mod:func")
        scenario = Scenario(
            name="test",
            input="hi",
            constraints=Constraints(max_steps=3),
        )
        resolved = config.resolve_constraints(scenario)
        assert resolved.max_steps == 3
        assert resolved.max_duration_ms is None
