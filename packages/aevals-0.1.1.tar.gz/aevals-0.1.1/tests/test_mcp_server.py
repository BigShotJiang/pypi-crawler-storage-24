"""Tests for aevals.mcp.server."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from aevals.config.loader import ConfigError
from aevals.config.schema import AevalsConfig, Scenario
from aevals.mcp.server import (
    _handle_results,
    _handle_run,
    _handle_scan,
    _handle_trajectory,
    call_tool,
    list_tools,
)


class TestListTools:
    @pytest.mark.asyncio
    async def test_returns_five_tools(self):
        tools = await list_tools()
        assert len(tools) == 5
        names = {t.name for t in tools}
        assert names == {
            "aevals_scan",
            "aevals_init",
            "aevals_run",
            "aevals_results",
            "aevals_trajectory",
        }


class TestCallTool:
    @pytest.mark.asyncio
    async def test_unknown_tool(self):
        result = await call_tool("unknown_tool", {})
        assert len(result) == 1
        assert "Unknown tool" in result[0].text


class TestHandleScan:
    @pytest.mark.asyncio
    async def test_scans_directory(self, tmp_path):
        (tmp_path / "agent.py").write_text("import openai\ndef run():\n    pass\n")
        result = await _handle_scan({"directory": str(tmp_path)})
        assert len(result) == 1
        data = json.loads(result[0].text)
        assert "openai" in data["sdks"]
        assert data["python_files_count"] == 1

    @pytest.mark.asyncio
    async def test_scans_empty_directory(self, tmp_path):
        result = await _handle_scan({"directory": str(tmp_path)})
        data = json.loads(result[0].text)
        assert data["sdks"] == []
        assert data["python_files_count"] == 0

    @pytest.mark.asyncio
    async def test_defaults_to_current_dir(self):
        result = await _handle_scan({})
        data = json.loads(result[0].text)
        assert "python_files_count" in data


class TestHandleRun:
    @pytest.mark.asyncio
    async def test_config_error(self):
        with patch(
            "aevals.mcp.server.load_config",
            side_effect=ConfigError("bad config"),
        ):
            result = await _handle_run({})
            assert "Config error" in result[0].text

    @pytest.mark.asyncio
    async def test_no_matching_scenarios(self):
        config = AevalsConfig(
            entry="mod:func",
            scenarios=[Scenario(name="booking", input="book")],
        )
        with patch("aevals.mcp.server.load_config", return_value=config):
            result = await _handle_run({"scenario": "nonexistent"})
            assert "No scenarios matched" in result[0].text

    @pytest.mark.asyncio
    async def test_filters_by_scenario_name(self):
        scenarios = [
            Scenario(name="booking", input="book"),
            Scenario(name="weather", input="weather"),
        ]
        config = AevalsConfig(entry="mod:func", scenarios=scenarios)

        from aevals.capture.schema import Trajectory
        from aevals.evals.types import ScenarioResult

        mock_result = ScenarioResult(
            scenario=scenarios[0],
            trajectory=Trajectory(
                run_id="r1",
                scenario=scenarios[0],
                spans=[],
                output=None,
                status="success",
                exit_code=0,
                stderr=None,
                total_duration_ms=100,
                total_tokens=None,
            ),
            constraint_results=[],
            rubric_results=[],
            rubric_pending=True,
            passed=True,
        )

        async def mock_run(cfg, scens):
            assert len(scens) == 1
            assert scens[0].name == "booking"
            return [mock_result]

        with (
            patch("aevals.mcp.server.load_config", return_value=config),
            patch("aevals.cli.run.run_scenarios", side_effect=mock_run),
        ):
            result = await _handle_run({"scenario": "booking"})
            data = json.loads(result[0].text)
            assert data["summary"]["total_scenarios"] == 1

    @pytest.mark.asyncio
    async def test_filters_by_tag(self):
        scenarios = [
            Scenario(name="s1", input="a", tags=["booking"]),
            Scenario(name="s2", input="b", tags=["weather"]),
        ]
        config = AevalsConfig(entry="mod:func", scenarios=scenarios)

        from aevals.capture.schema import Trajectory
        from aevals.evals.types import ScenarioResult

        mock_result = ScenarioResult(
            scenario=scenarios[1],
            trajectory=Trajectory(
                run_id="r1",
                scenario=scenarios[1],
                spans=[],
                output=None,
                status="success",
                exit_code=0,
                stderr=None,
                total_duration_ms=100,
                total_tokens=None,
            ),
            constraint_results=[],
            rubric_results=[],
            rubric_pending=True,
            passed=True,
        )

        async def mock_run(cfg, scens):
            assert len(scens) == 1
            assert scens[0].tags == ["weather"]
            return [mock_result]

        with (
            patch("aevals.mcp.server.load_config", return_value=config),
            patch("aevals.cli.run.run_scenarios", side_effect=mock_run),
        ):
            result = await _handle_run({"tag": "weather"})
            data = json.loads(result[0].text)
            assert data["summary"]["total_scenarios"] == 1


class TestHandleResults:
    @pytest.mark.asyncio
    async def test_reads_existing_result(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        results_dir = tmp_path / ".aevals" / "results"
        results_dir.mkdir(parents=True)
        result_file = results_dir / "test-run.json"
        result_file.write_text('{"status": "success"}')

        result = await _handle_results({"run_id": "test-run"})
        data = json.loads(result[0].text)
        assert data["status"] == "success"

    @pytest.mark.asyncio
    async def test_missing_result(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = await _handle_results({"run_id": "nonexistent"})
        assert "No results found" in result[0].text


class TestHandleTrajectory:
    @pytest.mark.asyncio
    async def test_reads_existing_trajectory(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        traces_dir = tmp_path / ".aevals" / "traces"
        traces_dir.mkdir(parents=True)
        trace_file = traces_dir / "test-run.json"
        trace_file.write_text("[]")

        result = await _handle_trajectory({"run_id": "test-run"})
        assert result[0].text == "[]"

    @pytest.mark.asyncio
    async def test_missing_trajectory(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        result = await _handle_trajectory({"run_id": "nonexistent"})
        assert "No trajectory found" in result[0].text
