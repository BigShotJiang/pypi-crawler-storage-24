"""Shared fixtures for aevals tests."""

from __future__ import annotations

import pytest

from aevals.capture.schema import LLMCall, Trajectory
from aevals.config.schema import AevalsConfig, Constraints, Scenario
from aevals.evals.types import ConstraintResult, CriterionResult, ScenarioResult


@pytest.fixture
def sample_scenario() -> Scenario:
    return Scenario(
        name="test-scenario",
        input="Book a flight from JFK to LAX",
        tags=["booking", "flight"],
        rubric=["Agent should search before booking"],
        constraints=Constraints(max_duration_ms=5000, max_steps=10),
    )


@pytest.fixture
def sample_scenario_no_constraints() -> Scenario:
    return Scenario(
        name="simple-scenario",
        input="What is the weather?",
        tags=["weather"],
    )


@pytest.fixture
def sample_llm_call() -> LLMCall:
    return LLMCall(
        span_id="abc123",
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "hello"}],
        response="Hi there!",
        tool_calls=None,
        tokens_in=10,
        tokens_out=20,
        duration_ms=500,
        provider="openai",
        error=None,
    )


@pytest.fixture
def sample_llm_call_with_tools() -> LLMCall:
    return LLMCall(
        span_id="def456",
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": "search flights"}],
        response=None,
        tool_calls=[
            {"name": "search_flights", "arguments": '{"origin": "JFK", "destination": "LAX"}'}
        ],
        tokens_in=15,
        tokens_out=25,
        duration_ms=800,
        provider="openai",
        error=None,
    )


@pytest.fixture
def sample_trajectory(
    sample_scenario: Scenario,
    sample_llm_call: LLMCall,
    sample_llm_call_with_tools: LLMCall,
) -> Trajectory:
    return Trajectory(
        run_id="run-001",
        scenario=sample_scenario,
        spans=[sample_llm_call, sample_llm_call_with_tools],
        output={"output": "Flight booked successfully"},
        status="success",
        exit_code=0,
        stderr=None,
        total_duration_ms=1300,
        total_tokens=70,
    )


@pytest.fixture
def sample_trajectory_empty(sample_scenario: Scenario) -> Trajectory:
    return Trajectory(
        run_id="run-002",
        scenario=sample_scenario,
        spans=[],
        output=None,
        status="error",
        exit_code=1,
        stderr="Process failed",
        total_duration_ms=100,
        total_tokens=None,
    )


@pytest.fixture
def sample_config(sample_scenario: Scenario) -> AevalsConfig:
    return AevalsConfig(
        entry="src.agent:run",
        scenarios=[sample_scenario],
    )


@pytest.fixture
def sample_scenario_result(
    sample_scenario: Scenario, sample_trajectory: Trajectory
) -> ScenarioResult:
    return ScenarioResult(
        scenario=sample_scenario,
        trajectory=sample_trajectory,
        constraint_results=[
            ConstraintResult(
                constraint="max_duration_ms",
                passed=True,
                details={"actual": 1300, "limit": 5000},
            ),
            ConstraintResult(
                constraint="max_steps",
                passed=True,
                details={"actual": 2, "limit": 10},
            ),
        ],
        rubric_results=[
            CriterionResult(
                criterion="Agent should search before booking",
                passed=True,
                reason="Agent called search_flights before booking",
            ),
        ],
        rubric_pending=False,
        passed=True,
    )


@pytest.fixture
def sample_failed_result(
    sample_scenario: Scenario, sample_trajectory: Trajectory
) -> ScenarioResult:
    return ScenarioResult(
        scenario=sample_scenario,
        trajectory=sample_trajectory,
        constraint_results=[
            ConstraintResult(
                constraint="max_duration_ms",
                passed=False,
                details={"actual": 6000, "limit": 5000},
            ),
        ],
        rubric_results=[
            CriterionResult(
                criterion="Agent should search before booking",
                passed=False,
                reason="Agent booked without searching",
            ),
        ],
        rubric_pending=False,
        passed=False,
    )


@pytest.fixture
def trace_data(sample_llm_call: LLMCall, sample_llm_call_with_tools: LLMCall) -> list[dict]:
    """Raw trace data as written by JSONFileSpanExporter."""
    return [
        {
            "span_id": "abc123",
            "name": "openai.chat",
            "start_time": 1000000000,
            "end_time": 1500000000,
            "duration_ms": 500,
            "attributes": {
                "gen_ai.request.model": "gpt-4o-mini",
                "gen_ai.system": "openai",
                "gen_ai.usage.input_tokens": 10,
                "gen_ai.usage.output_tokens": 20,
                "gen_ai.prompt.0.role": "user",
                "gen_ai.prompt.0.content": "hello",
                "gen_ai.completion.0.content": "Hi there!",
            },
            "status": "OK",
        },
        {
            "span_id": "def456",
            "name": "openai.chat",
            "start_time": 2000000000,
            "end_time": 2800000000,
            "duration_ms": 800,
            "attributes": {
                "gen_ai.request.model": "gpt-4o-mini",
                "gen_ai.system": "openai",
                "gen_ai.usage.input_tokens": 15,
                "gen_ai.usage.output_tokens": 25,
                "gen_ai.prompt.0.role": "user",
                "gen_ai.prompt.0.content": "search flights",
                "gen_ai.completion.0.tool_calls.0.name": "search_flights",
                "gen_ai.completion.0.tool_calls.0.arguments": (
                    '{"origin": "JFK", "destination": "LAX"}'
                ),
            },
            "status": "OK",
        },
    ]
