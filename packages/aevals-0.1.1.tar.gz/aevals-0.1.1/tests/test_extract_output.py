"""Tests for _extract_output in aevals.cli.run."""

from __future__ import annotations

import json

from aevals.cli.run import _extract_output
from aevals.constants import RESULT_MARKER_END, RESULT_MARKER_START


class TestExtractOutput:
    def test_extracts_valid_output(self):
        payload = json.dumps({"output": "hello world"})
        stdout = f"some log\n{RESULT_MARKER_START}\n{payload}\n{RESULT_MARKER_END}\nmore log"
        result = _extract_output(stdout)
        assert result == {"output": "hello world"}

    def test_returns_none_no_markers(self):
        result = _extract_output("just regular stdout output")
        assert result is None

    def test_returns_none_start_only(self):
        result = _extract_output(f'log\n{RESULT_MARKER_START}\n{{"a": 1}}\n')
        assert result is None

    def test_returns_none_invalid_json(self):
        stdout = f"{RESULT_MARKER_START}\nnot json\n{RESULT_MARKER_END}"
        result = _extract_output(stdout)
        assert result is None

    def test_returns_none_empty_stdout(self):
        result = _extract_output("")
        assert result is None

    def test_handles_whitespace_around_json(self):
        payload = json.dumps({"output": "test"})
        stdout = f"{RESULT_MARKER_START}\n  {payload}  \n{RESULT_MARKER_END}"
        result = _extract_output(stdout)
        assert result == {"output": "test"}

    def test_handles_nested_json(self):
        payload = json.dumps({"output": {"nested": {"deep": True}}})
        stdout = f"{RESULT_MARKER_START}\n{payload}\n{RESULT_MARKER_END}"
        result = _extract_output(stdout)
        assert result == {"output": {"nested": {"deep": True}}}

    def test_ignores_content_before_markers(self):
        payload = json.dumps({"output": "value"})
        stdout = (
            f"lots of agent logs\nerror messages\n"
            f"{RESULT_MARKER_START}\n{payload}\n{RESULT_MARKER_END}"
        )
        result = _extract_output(stdout)
        assert result == {"output": "value"}
