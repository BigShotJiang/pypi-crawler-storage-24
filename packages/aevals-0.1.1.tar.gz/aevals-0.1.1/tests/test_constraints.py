"""Tests for aevals.evals.constraints."""

from __future__ import annotations

from aevals.capture.schema import LLMCall, Trajectory
from aevals.config.schema import Constraints, Scenario
from aevals.evals.constraints import check_constraints


def _make_trajectory(
    spans: list[LLMCall] | None = None,
    total_duration_ms: int = 1000,
    output: dict | None = None,
) -> Trajectory:
    return Trajectory(
        run_id="test-run",
        scenario=Scenario(name="test", input="hi"),
        spans=spans or [],
        output=output,
        status="success",
        exit_code=0,
        stderr=None,
        total_duration_ms=total_duration_ms,
        total_tokens=None,
    )


def _make_span(
    tool_calls: list[dict] | None = None,
    span_id: str = "s1",
) -> LLMCall:
    return LLMCall(
        span_id=span_id,
        model="gpt-4o",
        messages=None,
        response=None,
        tool_calls=tool_calls,
        tokens_in=10,
        tokens_out=10,
        duration_ms=100,
        provider="openai",
        error=None,
    )


class TestMaxDuration:
    def test_passes_under_limit(self):
        traj = _make_trajectory(total_duration_ms=3000)
        results = check_constraints(traj, Constraints(max_duration_ms=5000))
        assert len(results) == 1
        assert results[0].passed is True
        assert results[0].constraint == "max_duration_ms"
        assert results[0].details["actual"] == 3000
        assert results[0].details["limit"] == 5000

    def test_passes_at_limit(self):
        traj = _make_trajectory(total_duration_ms=5000)
        results = check_constraints(traj, Constraints(max_duration_ms=5000))
        assert results[0].passed is True

    def test_fails_over_limit(self):
        traj = _make_trajectory(total_duration_ms=6000)
        results = check_constraints(traj, Constraints(max_duration_ms=5000))
        assert results[0].passed is False


class TestMaxSteps:
    def test_passes_under_limit(self):
        spans = [_make_span(span_id=f"s{i}") for i in range(3)]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(max_steps=5))
        assert results[0].passed is True
        assert results[0].details["actual"] == 3

    def test_fails_over_limit(self):
        spans = [_make_span(span_id=f"s{i}") for i in range(10)]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(max_steps=5))
        assert results[0].passed is False
        assert results[0].details["actual"] == 10

    def test_passes_with_zero_spans(self):
        traj = _make_trajectory(spans=[])
        results = check_constraints(traj, Constraints(max_steps=5))
        assert results[0].passed is True


class TestToolSequence:
    def test_passes_exact_match(self):
        spans = [
            _make_span(tool_calls=[{"name": "search"}], span_id="s1"),
            _make_span(tool_calls=[{"name": "book"}], span_id="s2"),
        ]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(tool_sequence=["search", "book"]))
        assert results[0].passed is True

    def test_passes_subsequence(self):
        spans = [
            _make_span(tool_calls=[{"name": "search"}], span_id="s1"),
            _make_span(tool_calls=[{"name": "weather"}], span_id="s2"),
            _make_span(tool_calls=[{"name": "book"}], span_id="s3"),
        ]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(tool_sequence=["search", "book"]))
        assert results[0].passed is True

    def test_fails_wrong_order(self):
        spans = [
            _make_span(tool_calls=[{"name": "book"}], span_id="s1"),
            _make_span(tool_calls=[{"name": "search"}], span_id="s2"),
        ]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(tool_sequence=["search", "book"]))
        assert results[0].passed is False

    def test_fails_missing_tool(self):
        spans = [_make_span(tool_calls=[{"name": "search"}], span_id="s1")]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(tool_sequence=["search", "book"]))
        assert results[0].passed is False

    def test_passes_empty_sequence(self):
        traj = _make_trajectory(spans=[])
        results = check_constraints(traj, Constraints(tool_sequence=[]))
        assert results[0].passed is True


class TestNoRepeatCalls:
    def test_passes_no_repeats(self):
        spans = [
            _make_span(tool_calls=[{"name": "search", "arguments": '{"q": "a"}'}], span_id="s1"),
            _make_span(tool_calls=[{"name": "search", "arguments": '{"q": "b"}'}], span_id="s2"),
        ]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(no_repeat_calls=3))
        assert results[0].passed is True

    def test_fails_with_repeats(self):
        same_call = {"name": "search", "arguments": '{"q": "a"}'}
        spans = [_make_span(tool_calls=[same_call], span_id=f"s{i}") for i in range(5)]
        traj = _make_trajectory(spans=spans)
        results = check_constraints(traj, Constraints(no_repeat_calls=3))
        assert results[0].passed is False
        assert results[0].details["count"] == 5
        assert results[0].details["tool"] == "search"

    def test_passes_empty_spans(self):
        traj = _make_trajectory(spans=[])
        results = check_constraints(traj, Constraints(no_repeat_calls=3))
        assert results[0].passed is True


class TestOutputContains:
    def test_passes_when_found(self):
        traj = _make_trajectory(output={"output": "Flight booked successfully"})
        results = check_constraints(traj, Constraints(output_contains="booked"))
        assert results[0].passed is True

    def test_fails_when_not_found(self):
        traj = _make_trajectory(output={"output": "Flight booked successfully"})
        results = check_constraints(traj, Constraints(output_contains="cancelled"))
        assert results[0].passed is False

    def test_fails_with_no_output(self):
        traj = _make_trajectory(output=None)
        results = check_constraints(traj, Constraints(output_contains="anything"))
        assert results[0].passed is False

    def test_passes_case_sensitive(self):
        traj = _make_trajectory(output={"output": "Booked"})
        results = check_constraints(traj, Constraints(output_contains="booked"))
        assert results[0].passed is False


class TestMultipleConstraints:
    def test_runs_all_configured(self):
        spans = [_make_span(span_id="s1")]
        traj = _make_trajectory(
            spans=spans,
            total_duration_ms=1000,
            output={"output": "done"},
        )
        constraints = Constraints(
            max_duration_ms=5000,
            max_steps=10,
            output_contains="done",
        )
        results = check_constraints(traj, constraints)
        assert len(results) == 3
        assert all(r.passed for r in results)

    def test_skips_unconfigured(self):
        traj = _make_trajectory()
        results = check_constraints(traj, Constraints())
        assert len(results) == 0
