"""Integration tests for aevals.cli.run scenario execution."""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from aevals.capture.schema import Trajectory
from aevals.cli.run import _run_single_scenario, run_scenarios
from aevals.config.schema import AevalsConfig, Constraints, Scenario
from aevals.constants import RESULTS_DIR, TRACES_DIR
from aevals.evals.types import ScenarioResult


class TestRunScenarios:
    @pytest.mark.asyncio
    async def test_returns_empty_for_no_scenarios(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = AevalsConfig(entry="mod:func")
        results = await run_scenarios(config, [])
        assert results == []

    @pytest.mark.asyncio
    async def test_creates_directories(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = AevalsConfig(entry="mod:func")

        # Mock _run_single_scenario so we don't need real subprocesses
        async def mock_single(cfg, scenario):
            return ScenarioResult(
                scenario=scenario,
                trajectory=Trajectory(
                    run_id="r1",
                    scenario=scenario,
                    spans=[],
                    output=None,
                    status="success",
                    exit_code=0,
                    stderr=None,
                    total_duration_ms=100,
                    total_tokens=None,
                ),
                constraint_results=[],
                rubric_results=[],
                rubric_pending=True,
                passed=True,
            )

        with patch("aevals.cli.run._run_single_scenario", side_effect=mock_single):
            scenario = Scenario(name="test", input="hi")
            await run_scenarios(config, [scenario])

        assert (tmp_path / TRACES_DIR).is_dir()
        assert (tmp_path / RESULTS_DIR).is_dir()


class TestRunSingleScenario:
    @pytest.mark.asyncio
    async def test_returns_error_if_wrapper_missing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config = AevalsConfig(entry="mod:func")
        scenario = Scenario(name="test", input="hi")
        result = await _run_single_scenario(config, scenario)
        assert result.passed is False
        assert result.trajectory.status == "error"
        assert "Wrapper not found" in (result.trajectory.stderr or "")

    @pytest.mark.asyncio
    async def test_runs_subprocess_successfully(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        # Create wrapper that just outputs markers
        wrapper_dir = tmp_path / ".aevals"
        wrapper_dir.mkdir(parents=True)
        traces_dir = tmp_path / ".aevals" / "traces"
        traces_dir.mkdir(parents=True)
        results_dir = tmp_path / ".aevals" / "results"
        results_dir.mkdir(parents=True)

        wrapper = wrapper_dir / "run_wrapper.py"
        wrapper.write_text(
            "import sys, json\n"
            "task = json.loads(sys.stdin.read())\n"
            'print("\\n__AEVALS_RESULT__")\n'
            'print(json.dumps({"output": "done"}))\n'
            'print("__AEVALS_END__")\n'
        )

        config = AevalsConfig(entry="mod:func")
        scenario = Scenario(name="test", input="hello")
        result = await _run_single_scenario(config, scenario)
        assert result.trajectory.status == "success"
        assert result.trajectory.exit_code == 0
        assert result.trajectory.output == {"output": "done"}
        assert result.trajectory.total_duration_ms > 0

    @pytest.mark.asyncio
    async def test_handles_subprocess_error(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        wrapper_dir = tmp_path / ".aevals"
        wrapper_dir.mkdir(parents=True)
        traces_dir = tmp_path / ".aevals" / "traces"
        traces_dir.mkdir(parents=True)
        results_dir = tmp_path / ".aevals" / "results"
        results_dir.mkdir(parents=True)

        wrapper = wrapper_dir / "run_wrapper.py"
        wrapper.write_text('import sys\nprint("error happened", file=sys.stderr)\nsys.exit(1)\n')

        config = AevalsConfig(entry="mod:func")
        scenario = Scenario(name="test", input="hello")
        result = await _run_single_scenario(config, scenario)
        assert result.trajectory.status == "error"
        assert result.trajectory.exit_code == 1
        assert result.trajectory.stderr is not None

    @pytest.mark.asyncio
    async def test_handles_timeout(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        wrapper_dir = tmp_path / ".aevals"
        wrapper_dir.mkdir(parents=True)
        traces_dir = tmp_path / ".aevals" / "traces"
        traces_dir.mkdir(parents=True)
        results_dir = tmp_path / ".aevals" / "results"
        results_dir.mkdir(parents=True)

        wrapper = wrapper_dir / "run_wrapper.py"
        wrapper.write_text(
            "import sys, time, json\ntask = json.loads(sys.stdin.read())\ntime.sleep(10)\n"
        )

        from aevals.config.schema import RunConfig

        config = AevalsConfig(
            entry="mod:func",
            run=RunConfig(timeout_ms=500),
        )
        scenario = Scenario(name="test", input="hello")
        result = await _run_single_scenario(config, scenario)
        assert result.trajectory.status == "timeout"
        assert result.trajectory.exit_code is None
        assert "timed out" in (result.trajectory.stderr or "").lower()

    @pytest.mark.asyncio
    async def test_saves_trajectory(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        wrapper_dir = tmp_path / ".aevals"
        wrapper_dir.mkdir(parents=True)
        traces_dir = tmp_path / ".aevals" / "traces"
        traces_dir.mkdir(parents=True)
        results_dir = tmp_path / ".aevals" / "results"
        results_dir.mkdir(parents=True)

        wrapper = wrapper_dir / "run_wrapper.py"
        wrapper.write_text(
            "import sys, json\n"
            "task = json.loads(sys.stdin.read())\n"
            'print("\\n__AEVALS_RESULT__")\n'
            'print(json.dumps({"output": "ok"}))\n'
            'print("__AEVALS_END__")\n'
        )

        config = AevalsConfig(entry="mod:func")
        scenario = Scenario(name="test", input="hello")
        await _run_single_scenario(config, scenario)

        # Check that a result file was written
        result_files = list(results_dir.glob("*.json"))
        assert len(result_files) == 1
        saved = json.loads(result_files[0].read_text())
        assert saved["status"] == "success"

    @pytest.mark.asyncio
    async def test_runs_constraints(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)

        wrapper_dir = tmp_path / ".aevals"
        wrapper_dir.mkdir(parents=True)
        traces_dir = tmp_path / ".aevals" / "traces"
        traces_dir.mkdir(parents=True)
        results_dir = tmp_path / ".aevals" / "results"
        results_dir.mkdir(parents=True)

        wrapper = wrapper_dir / "run_wrapper.py"
        wrapper.write_text(
            "import sys, json\n"
            "task = json.loads(sys.stdin.read())\n"
            'print("\\n__AEVALS_RESULT__")\n'
            'print(json.dumps({"output": "done"}))\n'
            'print("__AEVALS_END__")\n'
        )

        config = AevalsConfig(entry="mod:func")
        scenario = Scenario(
            name="test",
            input="hello",
            constraints=Constraints(max_duration_ms=60000),
        )
        result = await _run_single_scenario(config, scenario)
        assert len(result.constraint_results) == 1
        assert result.constraint_results[0].constraint == "max_duration_ms"
        assert result.constraint_results[0].passed is True
