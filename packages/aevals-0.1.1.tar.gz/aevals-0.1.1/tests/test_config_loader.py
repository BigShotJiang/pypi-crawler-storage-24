"""Tests for aevals.config.loader."""

from __future__ import annotations

import pytest
import yaml

from aevals.config.loader import ConfigError, find_config, load_config


class TestFindConfig:
    def test_finds_config(self, tmp_path):
        config_file = tmp_path / "aevals.yaml"
        config_file.write_text("entry: mod:func\n")
        result = find_config(tmp_path)
        assert result == config_file

    def test_raises_if_missing(self, tmp_path):
        with pytest.raises(ConfigError, match="not found"):
            find_config(tmp_path)


class TestLoadConfig:
    def test_loads_valid_config(self, tmp_path):
        config_file = tmp_path / "aevals.yaml"
        config_data = {
            "entry": "src.agent:run",
            "scenarios": [
                {"name": "test", "input": "hello"},
            ],
        }
        config_file.write_text(yaml.dump(config_data))
        config = load_config(config_file)
        assert config.entry == "src.agent:run"
        assert len(config.scenarios) == 1
        assert config.scenarios[0].name == "test"

    def test_loads_full_config(self, tmp_path):
        config_file = tmp_path / "aevals.yaml"
        config_data = {
            "entry": "mod:func",
            "judge": {"model": "gpt-4o"},
            "defaults": {"constraints": {"max_duration_ms": 10000}},
            "run": {"timeout_ms": 30000},
            "scenarios": [
                {
                    "name": "s1",
                    "input": "test input",
                    "tags": ["tag1"],
                    "rubric": ["criterion 1"],
                    "constraints": {"max_steps": 5},
                },
            ],
        }
        config_file.write_text(yaml.dump(config_data))
        config = load_config(config_file)
        assert config.judge is not None
        assert config.judge.model == "gpt-4o"
        assert config.run.timeout_ms == 30000
        assert config.defaults.constraints.max_duration_ms == 10000

    def test_raises_on_missing_file(self, tmp_path):
        missing = tmp_path / "nonexistent.yaml"
        with pytest.raises(ConfigError, match="not found"):
            load_config(missing)

    def test_raises_on_invalid_yaml(self, tmp_path):
        config_file = tmp_path / "aevals.yaml"
        config_file.write_text("{{invalid: yaml: [}")
        with pytest.raises(ConfigError, match="Invalid YAML"):
            load_config(config_file)

    def test_raises_on_non_mapping(self, tmp_path):
        config_file = tmp_path / "aevals.yaml"
        config_file.write_text("- just\n- a\n- list\n")
        with pytest.raises(ConfigError, match="must be a YAML mapping"):
            load_config(config_file)

    def test_raises_on_invalid_schema(self, tmp_path):
        config_file = tmp_path / "aevals.yaml"
        config_file.write_text(yaml.dump({"entry": "no_colon"}))
        with pytest.raises(ConfigError, match="Invalid config"):
            load_config(config_file)

    def test_empty_yaml(self, tmp_path):
        config_file = tmp_path / "aevals.yaml"
        config_file.write_text("")
        with pytest.raises(ConfigError, match="must be a YAML mapping"):
            load_config(config_file)
