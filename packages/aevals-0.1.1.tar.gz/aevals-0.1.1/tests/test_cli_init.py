"""Tests for aevals.cli.init."""

from __future__ import annotations

import json

import pytest
import yaml
from click.testing import CliRunner

from aevals.cli.init import init_cmd


class TestInitCmd:
    @pytest.fixture
    def runner(self):
        return CliRunner()

    def test_creates_config_file(self, runner, tmp_path):
        # Create a Python file so the scanner has something to find
        (tmp_path / "agent.py").write_text("def run():\n    pass\n")
        result = runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        assert result.exit_code == 0
        config_path = tmp_path / "aevals.yaml"
        assert config_path.exists()
        config = yaml.safe_load(config_path.read_text())
        assert "entry" in config

    def test_creates_wrapper(self, runner, tmp_path):
        (tmp_path / "agent.py").write_text("def main():\n    pass\n")
        runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        wrapper = tmp_path / ".aevals" / "run_wrapper.py"
        assert wrapper.exists()

    def test_creates_trace_and_results_dirs(self, runner, tmp_path):
        (tmp_path / "agent.py").write_text("def run():\n    pass\n")
        runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        assert (tmp_path / ".aevals" / "traces").is_dir()
        assert (tmp_path / ".aevals" / "results").is_dir()

    def test_creates_mcp_config(self, runner, tmp_path):
        (tmp_path / "agent.py").write_text("def run():\n    pass\n")
        runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        mcp_path = tmp_path / ".claude" / "mcp.json"
        assert mcp_path.exists()
        mcp_config = json.loads(mcp_path.read_text())
        assert "mcpServers" in mcp_config
        assert "aevals" in mcp_config["mcpServers"]

    def test_detects_sdk(self, runner, tmp_path):
        (tmp_path / "agent.py").write_text("import openai\ndef run():\n    pass\n")
        result = runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        assert "openai" in result.output

    def test_detects_entrypoint(self, runner, tmp_path):
        (tmp_path / "agent.py").write_text("def run():\n    pass\n")
        result = runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        assert "entry" in result.output.lower()

    def test_no_entrypoint_detected(self, runner, tmp_path):
        (tmp_path / "utils.py").write_text("def helper():\n    pass\n")
        result = runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert "No entrypoint" in result.output or "module:callable" in result.output

    def test_empty_directory(self, runner, tmp_path):
        result = runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        assert result.exit_code == 0
        assert (tmp_path / "aevals.yaml").exists()

    def test_output_has_done_message(self, runner, tmp_path):
        result = runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        assert "Done!" in result.output

    def test_config_is_valid_yaml(self, runner, tmp_path):
        (tmp_path / "agent.py").write_text("def run():\n    pass\n")
        runner.invoke(init_cmd, ["--dir", str(tmp_path)])
        config_path = tmp_path / "aevals.yaml"
        config = yaml.safe_load(config_path.read_text())
        assert isinstance(config, dict)
        assert "entry" in config
