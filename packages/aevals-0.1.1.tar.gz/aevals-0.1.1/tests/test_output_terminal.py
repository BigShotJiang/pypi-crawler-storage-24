"""Tests for aevals.output.terminal."""

from __future__ import annotations

from aevals.output.terminal import _format_constraint_detail, print_results


class TestFormatConstraintDetail:
    def test_max_duration_ms(self):
        result = _format_constraint_detail("max_duration_ms", {"actual": 3000, "limit": 5000})
        assert "3000ms" in result
        assert "5000ms" in result

    def test_max_steps(self):
        result = _format_constraint_detail("max_steps", {"actual": 3, "limit": 10})
        assert "3" in result
        assert "10" in result

    def test_output_contains_found(self):
        result = _format_constraint_detail("output_contains", {"substring": "hello", "found": True})
        assert "hello" in result
        assert "found" in result

    def test_output_contains_not_found(self):
        result = _format_constraint_detail(
            "output_contains", {"substring": "hello", "found": False}
        )
        assert "not found" in result

    def test_no_repeat_calls(self):
        result = _format_constraint_detail(
            "no_repeat_calls", {"count": 5, "tool": "search", "limit": 3}
        )
        assert "5" in result
        assert "search" in result
        assert "3" in result

    def test_tool_sequence(self):
        result = _format_constraint_detail(
            "tool_sequence",
            {"expected": ["search", "book"], "actual": ["search"]},
        )
        assert "expected" in result
        assert "got" in result

    def test_unknown_constraint(self):
        result = _format_constraint_detail("custom", {"key": "value"})
        assert "key" in result


class TestPrintResults:
    def test_prints_passing_results(self, sample_scenario_result, capsys):
        print_results([sample_scenario_result])
        # Just verify it doesn't crash — Rich output goes to its own console
        # so we check the console fixture instead

    def test_prints_failing_results(self, sample_failed_result, capsys):
        print_results([sample_failed_result])

    def test_prints_mixed_results(self, sample_scenario_result, sample_failed_result):
        print_results([sample_scenario_result, sample_failed_result])

    def test_prints_empty_results(self):
        print_results([])
