"""Tests for aevals.constants."""

from pathlib import Path

from aevals.constants import (
    AEVALS_DIR,
    RESULT_MARKER_END,
    RESULT_MARKER_START,
    RESULTS_DIR,
    TRACES_DIR,
    WRAPPER_PATH,
)


def test_directory_layout():
    assert Path(".aevals") == AEVALS_DIR
    assert Path(".aevals/traces") == TRACES_DIR
    assert Path(".aevals/results") == RESULTS_DIR
    assert Path(".aevals/run_wrapper.py") == WRAPPER_PATH


def test_traces_dir_is_child_of_aevals():
    assert TRACES_DIR.parent == AEVALS_DIR


def test_results_dir_is_child_of_aevals():
    assert RESULTS_DIR.parent == AEVALS_DIR


def test_wrapper_path_is_child_of_aevals():
    assert WRAPPER_PATH.parent == AEVALS_DIR


def test_markers_are_nonempty_strings():
    assert isinstance(RESULT_MARKER_START, str)
    assert isinstance(RESULT_MARKER_END, str)
    assert len(RESULT_MARKER_START) > 0
    assert len(RESULT_MARKER_END) > 0


def test_markers_are_distinct():
    assert RESULT_MARKER_START != RESULT_MARKER_END
