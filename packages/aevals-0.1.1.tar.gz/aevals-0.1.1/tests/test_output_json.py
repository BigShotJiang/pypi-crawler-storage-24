"""Tests for aevals.output.json."""

from __future__ import annotations

import json

from aevals.output.json import format_json


class TestFormatJson:
    def test_formats_passing_results(self, sample_scenario_result):
        output = format_json([sample_scenario_result])
        parsed = json.loads(output)
        assert parsed["summary"]["total_scenarios"] == 1
        assert parsed["summary"]["passed"] == 1
        assert parsed["summary"]["failed"] == 0
        assert parsed["exit_code"] == 0

    def test_formats_failing_results(self, sample_failed_result):
        output = format_json([sample_failed_result])
        parsed = json.loads(output)
        assert parsed["summary"]["passed"] == 0
        assert parsed["summary"]["failed"] == 1
        assert parsed["exit_code"] == 1

    def test_formats_mixed_results(self, sample_scenario_result, sample_failed_result):
        output = format_json([sample_scenario_result, sample_failed_result])
        parsed = json.loads(output)
        assert parsed["summary"]["total_scenarios"] == 2
        assert parsed["summary"]["passed"] == 1
        assert parsed["summary"]["failed"] == 1
        assert parsed["exit_code"] == 1

    def test_empty_results(self):
        output = format_json([])
        parsed = json.loads(output)
        assert parsed["summary"]["total_scenarios"] == 0
        assert parsed["exit_code"] == 0

    def test_scenario_details(self, sample_scenario_result):
        output = format_json([sample_scenario_result])
        parsed = json.loads(output)
        result = parsed["results"][0]
        assert result["scenario"] == "test-scenario"
        assert result["status"] == "success"
        assert result["spans"] == 2
        assert result["duration_ms"] == 1300
        assert result["tokens"] == 70
        assert result["passed"] is True

    def test_constraint_results_in_output(self, sample_scenario_result):
        output = format_json([sample_scenario_result])
        parsed = json.loads(output)
        constraints = parsed["results"][0]["constraint_results"]
        assert len(constraints) == 2
        assert constraints[0]["constraint"] == "max_duration_ms"
        assert constraints[0]["passed"] is True

    def test_rubric_results_in_output(self, sample_scenario_result):
        output = format_json([sample_scenario_result])
        parsed = json.loads(output)
        rubric = parsed["results"][0]["rubric_results"]
        assert len(rubric) == 1
        assert rubric[0]["criterion"] == "Agent should search before booking"
        assert rubric[0]["passed"] is True

    def test_output_is_valid_json(self, sample_scenario_result, sample_failed_result):
        output = format_json([sample_scenario_result, sample_failed_result])
        # Should not raise
        json.loads(output)
