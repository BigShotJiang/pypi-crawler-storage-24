"""Tests for aevals.evals.runner (filter + summarize)."""

from __future__ import annotations

from aevals.config.schema import Scenario
from aevals.evals.runner import filter_scenarios, summarize_results


class TestFilterScenarios:
    def _scenarios(self) -> list[Scenario]:
        return [
            Scenario(name="Book Flight", input="book", tags=["booking", "flight"]),
            Scenario(name="Check Weather", input="weather", tags=["weather"]),
            Scenario(name="Cancel Booking", input="cancel", tags=["booking", "cancel"]),
        ]

    def test_no_filters_returns_all(self):
        scenarios = self._scenarios()
        result = filter_scenarios(scenarios)
        assert result == scenarios

    def test_empty_filters_returns_all(self):
        scenarios = self._scenarios()
        result = filter_scenarios(scenarios, (), ())
        assert result == scenarios

    def test_name_filter_substring(self):
        result = filter_scenarios(self._scenarios(), name_filters=("book",))
        assert len(result) == 2
        assert result[0].name == "Book Flight"
        assert result[1].name == "Cancel Booking"

    def test_name_filter_case_insensitive(self):
        result = filter_scenarios(self._scenarios(), name_filters=("WEATHER",))
        assert len(result) == 1
        assert result[0].name == "Check Weather"

    def test_tag_filter(self):
        result = filter_scenarios(self._scenarios(), tag_filters=("weather",))
        assert len(result) == 1
        assert result[0].name == "Check Weather"

    def test_tag_filter_or_logic(self):
        result = filter_scenarios(self._scenarios(), tag_filters=("weather", "cancel"))
        assert len(result) == 2

    def test_combined_filters(self):
        result = filter_scenarios(
            self._scenarios(),
            name_filters=("book",),
            tag_filters=("cancel",),
        )
        assert len(result) == 1
        assert result[0].name == "Cancel Booking"

    def test_no_matches(self):
        result = filter_scenarios(self._scenarios(), name_filters=("nonexistent",))
        assert result == []

    def test_accepts_list_type(self):
        result = filter_scenarios(self._scenarios(), name_filters=["weather"])
        assert len(result) == 1


class TestSummarizeResults:
    def test_all_passed(self, sample_scenario_result):
        summary = summarize_results([sample_scenario_result])
        assert summary.total_scenarios == 1
        assert summary.passed_scenarios == 1
        assert summary.failed_scenarios == 0
        assert summary.exit_code == 0

    def test_some_failed(self, sample_scenario_result, sample_failed_result):
        summary = summarize_results([sample_scenario_result, sample_failed_result])
        assert summary.total_scenarios == 2
        assert summary.passed_scenarios == 1
        assert summary.failed_scenarios == 1
        assert summary.exit_code == 1

    def test_empty_results(self):
        summary = summarize_results([])
        assert summary.total_scenarios == 0
        assert summary.passed_scenarios == 0
        assert summary.exit_code == 0

    def test_constraint_counts(self, sample_scenario_result):
        summary = summarize_results([sample_scenario_result])
        assert summary.total_constraints == 2
        assert summary.passed_constraints == 2

    def test_rubric_counts(self, sample_scenario_result, sample_failed_result):
        summary = summarize_results([sample_scenario_result, sample_failed_result])
        assert summary.total_rubric == 2
        assert summary.passed_rubric == 1
