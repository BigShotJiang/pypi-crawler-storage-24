# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install
uv pip install -e ".[dev]"

# Test
pytest                                                    # all tests
pytest tests/test_constraints.py                          # single file
pytest tests/test_constraints.py::TestMaxDuration          # single class
pytest tests/test_constraints.py::TestMaxDuration::test_passes_under_limit  # single test
pytest --cov=aevals --cov-report=term-missing --cov-fail-under=90  # with coverage (CI threshold: 90%)

# Lint & format
ruff check src/ tests/
ruff check --fix src/ tests/
ruff format src/ tests/
ruff format --check src/ tests/                           # CI format check (no changes)

# Type check
pyright

# CLI
aevals init                                               # scan project, generate aevals.yaml + .aevals/
aevals run                                                # run all scenarios
aevals run --scenario <name>                              # run specific scenario
aevals run --json                                         # machine-readable output
aevals mcp-serve                                          # start MCP server for Claude Code
```

## Architecture

aevals is an eval framework for LLM-based agents. It runs agent code in subprocesses, captures OpenTelemetry traces, and evaluates results against deterministic constraints and LLM-judged rubrics.

### Data flow

```
aevals.yaml → scenario selection → subprocess (run_wrapper.py)
  → OTel instruments LLM calls → trace JSON file
  → parse into Trajectory → evaluate constraints + rubric → ScenarioResult
```

### Key modules

- **`config/`** — Pydantic models for `aevals.yaml`. `AevalsConfig.resolve_constraints()` merges defaults with scenario overrides.
- **`capture/otel.py`** — `activate()` sets up OTel tracing in agent subprocess. `parse_trace_file()` converts OTel span JSON into `LLMCall` objects by reading `gen_ai.*` attributes. Auto-instruments 6 LLM SDKs.
- **`scanner/`** — AST-based detection of SDK imports and entrypoint candidates. Generates `run_wrapper.py` template with marker constants from `constants.py`.
- **`evals/constraints.py`** — Five deterministic checks (max_duration_ms, max_steps, tool_sequence, no_repeat_calls, output_contains). Zero LLM cost.
- **`evals/judge.py`** — LLM-as-judge via litellm. Sends trajectory + rubric, parses JSON response with index-based matching and positional fallback.
- **`evals/runner.py`** — Shared `filter_scenarios()` and `summarize_results()` used by both CLI and MCP server.
- **`cli/run.py`** — Spawns agent subprocesses concurrently via `asyncio.create_subprocess_exec`. Output extracted between `RESULT_MARKER_START/END` sentinels.
- **`mcp/server.py`** — Primary interface for Claude Code. Five tools: scan, init, run, results, trajectory.
- **`constants.py`** — Single source of truth for directory paths and output marker strings.

### Subprocess isolation model

Each scenario runs in its own subprocess with env vars (`AEVALS_RUN_ID`, `AEVALS_ENTRY`, `AEVALS_TRACE_DIR`). The generated `run_wrapper.py` dynamically imports the agent entry point, pipes input via stdin, and captures output between marker strings in stdout. OTel spans are written to per-run JSON files in `.aevals/traces/`.

### Two-track evaluation

Pass/fail is `constraints_pass AND rubric_pass`. Constraints are synchronous and deterministic. Rubric evaluation is async via litellm, optional (missing judge config → rubric_pending=True, doesn't fail). Results are Pydantic models throughout.

## Conventions

- Python 3.12+. Line length 100. Ruff rules: E, F, I, UP, B, SIM, RUF, PT, PIE, C4, RET, PERF.
- Pyright strict mode. Type hints everywhere.
- Async tests use `pytest-asyncio` with `asyncio_mode = "auto"` (no `@pytest.mark.asyncio` needed).
- All shared path constants live in `constants.py` — don't hardcode `.aevals/` paths.
- Output marker strings (`__AEVALS_RESULT__`, `__AEVALS_END__`) are defined once in `constants.py` and injected into the wrapper template via `.format()`.
- TOCTOU: use `try/except FileNotFoundError` instead of `if path.exists()` then `path.read_text()`.
