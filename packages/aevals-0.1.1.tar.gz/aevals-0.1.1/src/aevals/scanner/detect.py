"""AST-based SDK and entrypoint detection."""

from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path

SKIP_DIRS = {"venv", ".venv", ".git", "node_modules", ".aevals", "__pycache__", ".tox"}

_ENTRY_NAMES = {
    "main",
    "run",
    "invoke",
    "execute",
    "handle",
    "process",
    "agent",
    "graph",
    "chain",
    "workflow",
    "pipeline",
}

SDK_IMPORTS: dict[str, str] = {
    "openai": "openai",
    "anthropic": "anthropic",
    "google.generativeai": "google-generativeai",
    "cohere": "cohere",
    "mistralai": "mistralai",
    "botocore": "bedrock",
    "boto3": "bedrock",
    "langchain": "langchain",
    "llama_index": "llama-index",
    "autogen": "autogen",
}


def _str_list() -> list[str]:
    return []


@dataclass
class ScanResult:
    """Result of scanning a codebase."""

    sdks: list[str] = field(default_factory=_str_list)
    entrypoint_candidates: list[str] = field(default_factory=_str_list)
    tool_definitions: list[str] = field(default_factory=_str_list)
    python_files: list[str] = field(default_factory=_str_list)


def scan_directory(root: Path) -> ScanResult:
    """Scan a directory for LLM SDK usage and entrypoint candidates."""
    result = ScanResult()
    seen_sdks: set[str] = set()

    for py_file in _walk_python_files(root):
        rel = str(py_file.relative_to(root))
        result.python_files.append(rel)

        try:
            tree = ast.parse(py_file.read_text())
        except SyntaxError:
            continue

        _detect_imports(tree, seen_sdks)
        _detect_entrypoints(tree, rel, result)
        _detect_tool_definitions(tree, rel, result)

    result.sdks = sorted(seen_sdks)
    return result


def _walk_python_files(root: Path) -> list[Path]:
    """Walk directory tree, skipping irrelevant directories."""
    files: list[Path] = []
    for path in root.rglob("*.py"):
        if any(part in SKIP_DIRS for part in path.parts):
            continue
        files.append(path)
    return sorted(files)


def _detect_imports(tree: ast.Module, seen_sdks: set[str]) -> None:
    """Find LLM SDK imports in an AST."""
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                _check_sdk(alias.name, seen_sdks)
        elif isinstance(node, ast.ImportFrom) and node.module:
            _check_sdk(node.module, seen_sdks)


def _check_sdk(module_name: str, seen_sdks: set[str]) -> None:
    """Check if a module name matches a known SDK."""
    for sdk_prefix, sdk_label in SDK_IMPORTS.items():
        if module_name == sdk_prefix or module_name.startswith(sdk_prefix + "."):
            seen_sdks.add(sdk_label)


def _detect_entrypoints(tree: ast.Module, filepath: str, result: ScanResult) -> None:
    """Heuristically detect entrypoint candidates."""
    module_path = filepath.replace("/", ".").removesuffix(".py")

    for node in ast.walk(tree):
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        name = node.name
        if name in _ENTRY_NAMES:
            result.entrypoint_candidates.append(f"{module_path}:{name}")


def _detect_tool_definitions(tree: ast.Module, filepath: str, result: ScanResult) -> None:
    """Detect tool/function definitions that look like agent tools."""
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef):
            continue
        # Check for @tool decorator or similar
        for decorator in node.decorator_list:
            dec_name = _get_decorator_name(decorator)
            if dec_name and "tool" in dec_name.lower():
                result.tool_definitions.append(f"{filepath}:{node.name}")
                break


def _get_decorator_name(node: ast.expr) -> str | None:
    """Extract decorator name from AST node."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Call):
        return _get_decorator_name(node.func)
    return None
