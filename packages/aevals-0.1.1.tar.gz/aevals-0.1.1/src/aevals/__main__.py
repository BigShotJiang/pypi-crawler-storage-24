"""python -m aevals entrypoint."""

from aevals.cli import cli

if __name__ == "__main__":
    cli()
