"""Structured JSON output for CI/CD."""

from __future__ import annotations

import json
from typing import Any

from aevals.evals.runner import summarize_results
from aevals.evals.types import ScenarioResult


def format_json(results: list[ScenarioResult]) -> str:
    """Format eval results as JSON."""
    summary = summarize_results(results)

    output: dict[str, Any] = {
        "summary": {
            "total_scenarios": summary.total_scenarios,
            "passed": summary.passed_scenarios,
            "failed": summary.failed_scenarios,
        },
        "results": [_format_scenario(r) for r in results],
        "exit_code": summary.exit_code,
    }

    return json.dumps(output, indent=2, default=str)


def _format_scenario(result: ScenarioResult) -> dict[str, Any]:
    """Format a single scenario result for JSON output."""
    traj = result.trajectory
    tokens = traj.total_tokens

    return {
        "scenario": result.scenario.name,
        "status": traj.status,
        "spans": len(traj.spans),
        "duration_ms": traj.total_duration_ms,
        "tokens": tokens,
        "constraint_results": [
            {
                "constraint": cr.constraint,
                "passed": cr.passed,
                "details": cr.details,
            }
            for cr in result.constraint_results
        ],
        "rubric_results": [
            {
                "criterion": rr.criterion,
                "passed": rr.passed,
                "reason": rr.reason,
            }
            for rr in result.rubric_results
        ],
        "rubric_pending": result.rubric_pending,
        "passed": result.passed,
    }
