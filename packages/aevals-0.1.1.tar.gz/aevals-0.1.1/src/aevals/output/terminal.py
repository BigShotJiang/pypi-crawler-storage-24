"""Rich terminal output for eval results."""

from __future__ import annotations

from collections.abc import Mapping

from rich.console import Console
from rich.text import Text

from aevals.evals.runner import summarize_results
from aevals.evals.types import ScenarioResult

console = Console()


def print_results(results: list[ScenarioResult]) -> None:
    """Print eval results to the terminal using Rich."""
    for result in results:
        _print_scenario(result)

    summary = summarize_results(results)

    console.print()
    console.rule("Summary")

    console.print(
        f"  Scenarios: {summary.total_scenarios} total, "
        f"{summary.passed_scenarios} passed, {summary.failed_scenarios} failed"
    )
    if summary.total_constraints > 0:
        failed_c = summary.total_constraints - summary.passed_constraints
        console.print(
            f"  Constraints: {summary.total_constraints} checked, "
            f"{summary.passed_constraints} passed, {failed_c} failed"
        )
    if summary.total_rubric > 0:
        failed_r = summary.total_rubric - summary.passed_rubric
        console.print(
            f"  Rubric: {summary.total_rubric} criteria, "
            f"{summary.passed_rubric} passed, {failed_r} failed"
        )

    console.print(f"\nExit code: {summary.exit_code}")


def _print_scenario(result: ScenarioResult) -> None:
    """Print a single scenario result."""
    console.print()
    console.rule(result.scenario.name)

    traj = result.trajectory
    span_count = len(traj.spans)
    duration_s = traj.total_duration_ms / 1000
    tokens = traj.total_tokens

    info_parts = [f"{span_count} spans", f"{duration_s:.1f}s"]
    if tokens is not None:
        info_parts.append(f"{tokens:,} tokens")
    console.print(f"  {' | '.join(info_parts)}")

    # Constraints
    if result.constraint_results:
        console.print()
        console.print("  Constraints:")
        for cr in result.constraint_results:
            icon = "[green]✓[/green]" if cr.passed else "[red]✗[/red]"
            detail = _format_constraint_detail(cr.constraint, cr.details)
            console.print(f"    {icon} {cr.constraint}: {detail}")

    # Rubric
    if result.rubric_results:
        console.print()
        judge_info = ""
        if not result.rubric_pending:
            judge_info = " (judged)"
        console.print(f"  Rubric:{judge_info}")
        for rr in result.rubric_results:
            icon = "[green]✓[/green]" if rr.passed else "[red]✗[/red]"
            console.print(f"    {icon} {rr.criterion}")
            if not rr.passed and rr.reason:
                reason_text = Text(f"      → {rr.reason}", style="dim")
                console.print(reason_text)
    elif result.rubric_pending:
        console.print()
        console.print("  Rubric: [yellow]pending[/yellow] (no judge configured)")


def _format_constraint_detail(constraint: str, details: Mapping[str, object]) -> str:
    """Format constraint details for display."""
    if constraint == "max_duration_ms":
        return f"{details.get('actual')}ms / {details.get('limit')}ms"
    if constraint == "max_steps":
        return f"{details.get('actual')} / {details.get('limit')}"
    if constraint == "output_contains":
        found = details.get("found", False)
        sub = details.get("substring", "")
        return f'"{sub}" {"found" if found else "not found"}'
    if constraint == "no_repeat_calls":
        return (
            f"{details.get('count')} identical calls"
            f" ({details.get('tool')}),"
            f" limit {details.get('limit')}"
        )
    if constraint == "tool_sequence":
        return f"expected {details.get('expected')}, got {details.get('actual')}"
    return str(details)
