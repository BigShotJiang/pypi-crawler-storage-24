"""aevals — AI-operated agent eval."""

__version__ = "0.1.1"
