"""Pydantic models for aevals.yaml configuration."""

from __future__ import annotations

from pydantic import BaseModel, field_validator


class Constraints(BaseModel):
    """Deterministic constraints for a scenario."""

    max_duration_ms: int | None = None
    max_steps: int | None = None
    tool_sequence: list[str] | None = None
    no_repeat_calls: int | None = None
    output_contains: str | None = None


class Scenario(BaseModel):
    """A single eval scenario: input + rubric + constraints."""

    name: str
    input: str
    tags: list[str] = []
    rubric: list[str] = []
    constraints: Constraints = Constraints()


class JudgeConfig(BaseModel):
    """LLM judge configuration. Uses litellm model strings."""

    model: str

    @field_validator("model")
    @classmethod
    def model_not_empty(cls, v: str) -> str:
        if not v.strip():
            msg = "judge model must not be empty"
            raise ValueError(msg)
        return v


class DefaultsConfig(BaseModel):
    """Default constraint values applied to all scenarios."""

    constraints: Constraints = Constraints()


class RunConfig(BaseModel):
    """Run-level configuration."""

    timeout_ms: int = 60000


class AevalsConfig(BaseModel):
    """Top-level aevals.yaml configuration."""

    config_version: int = 1
    entry: str
    judge: JudgeConfig | None = None
    scenarios: list[Scenario] = []
    defaults: DefaultsConfig = DefaultsConfig()
    run: RunConfig = RunConfig()

    @field_validator("entry")
    @classmethod
    def entry_format(cls, v: str) -> str:
        if ":" not in v:
            msg = "entry must be in 'module:callable' format (e.g. 'src.agent:graph')"
            raise ValueError(msg)
        return v

    def resolve_constraints(self, scenario: Scenario) -> Constraints:
        """Merge default constraints with scenario-specific overrides."""
        defaults = self.defaults.constraints.model_dump(exclude_none=True)
        overrides = scenario.constraints.model_dump(exclude_none=True)
        merged = {**defaults, **overrides}
        return Constraints(**merged)
