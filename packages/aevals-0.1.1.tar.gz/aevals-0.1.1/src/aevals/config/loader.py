"""YAML config loading and validation."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import ValidationError

from aevals.config.schema import AevalsConfig

CONFIG_FILENAME = "aevals.yaml"


class ConfigError(Exception):
    """Raised when config loading or validation fails."""


def find_config(start: Path | None = None) -> Path:
    """Find aevals.yaml in the given directory or current working directory."""
    directory = start or Path.cwd()
    config_path = directory / CONFIG_FILENAME
    if not config_path.exists():
        msg = f"{CONFIG_FILENAME} not found in {directory}"
        raise ConfigError(msg)
    return config_path


def load_config(path: Path | None = None) -> AevalsConfig:
    """Load and validate aevals.yaml."""
    config_path = path or find_config()
    try:
        text = config_path.read_text()
    except FileNotFoundError as e:
        msg = f"{config_path} not found"
        raise ConfigError(msg) from e
    try:
        raw: object = yaml.safe_load(text)
    except yaml.YAMLError as e:
        msg = f"Invalid YAML in {config_path}: {e}"
        raise ConfigError(msg) from e

    if not isinstance(raw, dict):
        msg = f"{config_path} must be a YAML mapping"
        raise ConfigError(msg)

    try:
        return AevalsConfig.model_validate(raw)
    except ValidationError as e:
        msg = f"Invalid config in {config_path}:\n{e}"
        raise ConfigError(msg) from e
