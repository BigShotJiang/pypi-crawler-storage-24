"""MCP server for aevals — primary interface for Claude Code."""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from aevals.config.loader import ConfigError, load_config
from aevals.constants import RESULTS_DIR, TRACES_DIR
from aevals.evals.runner import filter_scenarios
from aevals.output.json import format_json
from aevals.scanner.detect import scan_directory

server = Server("aevals")


@server.list_tools()
async def list_tools() -> list[Tool]:
    """List available MCP tools."""
    return [
        Tool(
            name="aevals_scan",
            description=(
                "Scan codebase for LLM SDK usage, entrypoint candidates, and tool definitions."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "directory": {
                        "type": "string",
                        "description": "Directory to scan. Defaults to current directory.",
                        "default": ".",
                    }
                },
            },
        ),
        Tool(
            name="aevals_init",
            description=(
                "Generate aevals config and run wrapper. Sets up the eval infrastructure."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "directory": {
                        "type": "string",
                        "description": "Project directory. Defaults to current directory.",
                        "default": ".",
                    }
                },
            },
        ),
        Tool(
            name="aevals_run",
            description="Run eval scenarios. Returns results as JSON.",
            inputSchema={
                "type": "object",
                "properties": {
                    "scenario": {
                        "type": "string",
                        "description": "Filter by scenario name (substring match).",
                    },
                    "tag": {
                        "type": "string",
                        "description": "Filter by tag.",
                    },
                },
            },
        ),
        Tool(
            name="aevals_results",
            description="Read stored results for a run_id.",
            inputSchema={
                "type": "object",
                "properties": {
                    "run_id": {
                        "type": "string",
                        "description": "The run ID to look up.",
                    }
                },
                "required": ["run_id"],
            },
        ),
        Tool(
            name="aevals_trajectory",
            description="Read raw trajectory (OTel spans) for a run_id.",
            inputSchema={
                "type": "object",
                "properties": {
                    "run_id": {
                        "type": "string",
                        "description": "The run ID to look up.",
                    }
                },
                "required": ["run_id"],
            },
        ),
    ]


@server.call_tool()
async def call_tool(name: str, arguments: dict[str, object]) -> list[TextContent]:
    """Handle MCP tool calls."""
    if name == "aevals_scan":
        return await _handle_scan(arguments)
    if name == "aevals_init":
        return await _handle_init(arguments)
    if name == "aevals_run":
        return await _handle_run(arguments)
    if name == "aevals_results":
        return await _handle_results(arguments)
    if name == "aevals_trajectory":
        return await _handle_trajectory(arguments)

    return [TextContent(type="text", text=f"Unknown tool: {name}")]


async def _handle_scan(arguments: dict[str, object]) -> list[TextContent]:
    """Scan codebase."""
    directory = str(arguments.get("directory", "."))
    result = scan_directory(Path(directory).resolve())
    data = {
        "sdks": result.sdks,
        "entrypoint_candidates": result.entrypoint_candidates,
        "tool_definitions": result.tool_definitions,
        "python_files_count": len(result.python_files),
    }
    return [TextContent(type="text", text=json.dumps(data, indent=2))]


async def _handle_init(arguments: dict[str, object]) -> list[TextContent]:
    """Initialize aevals."""
    # Lazy import to avoid loading CLI deps unless needed
    from aevals.cli.init import init_cmd

    directory = str(arguments.get("directory", "."))
    try:
        ctx = init_cmd.make_context("init", ["--dir", directory])
        init_cmd.invoke(ctx)
        return [TextContent(type="text", text="aevals initialized successfully.")]
    except (ConfigError, OSError) as e:
        return [TextContent(type="text", text=f"Init failed: {e}")]


async def _handle_run(arguments: dict[str, object]) -> list[TextContent]:
    """Run scenarios."""
    try:
        config = load_config()
    except ConfigError as e:
        return [TextContent(type="text", text=f"Config error: {e}")]

    scenario_filter = str(arguments["scenario"]) if "scenario" in arguments else ""
    tag_filter = str(arguments["tag"]) if "tag" in arguments else ""

    name_filters = (scenario_filter,) if scenario_filter else ()
    tag_filters = (tag_filter,) if tag_filter else ()
    scenarios = filter_scenarios(config.scenarios, name_filters, tag_filters)

    if not scenarios:
        return [TextContent(type="text", text="No scenarios matched filters.")]

    # Lazy import to avoid circular dependency
    from aevals.cli.run import run_scenarios

    results = await run_scenarios(config, scenarios)
    output = format_json(results)
    return [TextContent(type="text", text=output)]


async def _handle_results(arguments: dict[str, object]) -> list[TextContent]:
    """Read stored results."""
    run_id = str(arguments.get("run_id", ""))
    results_path = RESULTS_DIR / f"{run_id}.json"
    try:
        content = results_path.read_text()
    except FileNotFoundError:
        return [TextContent(type="text", text=f"No results found for run_id: {run_id}")]
    return [TextContent(type="text", text=content)]


async def _handle_trajectory(arguments: dict[str, object]) -> list[TextContent]:
    """Read raw trajectory."""
    run_id = str(arguments.get("run_id", ""))
    trace_path = TRACES_DIR / f"{run_id}.json"
    try:
        content = trace_path.read_text()
    except FileNotFoundError:
        return [TextContent(type="text", text=f"No trajectory found for run_id: {run_id}")]
    return [TextContent(type="text", text=content)]


def run_server() -> None:
    """Run the MCP server with stdio transport."""

    async def _run() -> None:
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(_run())
