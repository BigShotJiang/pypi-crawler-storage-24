"""Deterministic constraint checks. Zero LLM cost."""

from __future__ import annotations

from collections import Counter

from aevals.capture.schema import Trajectory
from aevals.config.schema import Constraints
from aevals.evals.types import ConstraintResult


def check_constraints(trajectory: Trajectory, constraints: Constraints) -> list[ConstraintResult]:
    """Run all configured constraints against a trajectory."""
    results: list[ConstraintResult] = []

    if constraints.max_duration_ms is not None:
        results.append(_check_max_duration(trajectory, constraints.max_duration_ms))

    if constraints.max_steps is not None:
        results.append(_check_max_steps(trajectory, constraints.max_steps))

    if constraints.tool_sequence is not None:
        results.append(_check_tool_sequence(trajectory, constraints.tool_sequence))

    if constraints.no_repeat_calls is not None:
        results.append(_check_no_repeat_calls(trajectory, constraints.no_repeat_calls))

    if constraints.output_contains is not None:
        results.append(_check_output_contains(trajectory, constraints.output_contains))

    return results


def _check_max_duration(trajectory: Trajectory, limit: int) -> ConstraintResult:
    actual = trajectory.total_duration_ms
    return ConstraintResult(
        constraint="max_duration_ms",
        passed=actual <= limit,
        details={"actual": actual, "limit": limit},
    )


def _check_max_steps(trajectory: Trajectory, limit: int) -> ConstraintResult:
    actual = len(trajectory.spans)
    return ConstraintResult(
        constraint="max_steps",
        passed=actual <= limit,
        details={"actual": actual, "limit": limit},
    )


def _check_tool_sequence(trajectory: Trajectory, expected: list[str]) -> ConstraintResult:
    """Check that tool calls contain the expected sequence as a subsequence."""
    actual_calls: list[str] = []
    for span in trajectory.spans:
        if span.tool_calls:
            for tc in span.tool_calls:
                name = tc.get("name")
                if isinstance(name, str):
                    actual_calls.append(name)

    # Subsequence check
    it = iter(actual_calls)
    passed = all(tool in it for tool in expected)

    return ConstraintResult(
        constraint="tool_sequence",
        passed=passed,
        details={"expected": expected, "actual": actual_calls},
    )


def _check_no_repeat_calls(trajectory: Trajectory, limit: int) -> ConstraintResult:
    """Flag if any tool is called N+ times with identical arguments."""
    call_counts: Counter[str] = Counter()
    for span in trajectory.spans:
        if span.tool_calls:
            for tc in span.tool_calls:
                name = str(tc.get("name", ""))
                args = str(tc.get("arguments", ""))
                call_counts[f"{name}({args})"] += 1

    # Find the worst offender
    if call_counts:
        worst_sig, worst_count = call_counts.most_common(1)[0]
        worst_tool = worst_sig.split("(")[0]
    else:
        worst_tool = ""
        worst_count = 0

    passed = worst_count < limit
    return ConstraintResult(
        constraint="no_repeat_calls",
        passed=passed,
        details={"tool": worst_tool, "count": worst_count, "limit": limit},
    )


def _check_output_contains(trajectory: Trajectory, substring: str) -> ConstraintResult:
    """Check if the agent's final output contains a substring."""
    output_text = ""
    if trajectory.output:
        output_val = trajectory.output.get("output", "")
        output_text = str(output_val)

    found = substring in output_text
    return ConstraintResult(
        constraint="output_contains",
        passed=found,
        details={"substring": substring, "found": found},
    )
