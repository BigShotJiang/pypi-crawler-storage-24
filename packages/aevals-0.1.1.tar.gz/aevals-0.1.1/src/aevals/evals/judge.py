"""LLM-as-judge via litellm. BYO API keys."""

from __future__ import annotations

import json
from typing import Any, cast

import litellm

from aevals.capture.schema import Trajectory
from aevals.evals.types import CriterionResult

JUDGE_SYSTEM_PROMPT = """\
You are evaluating an AI agent's trajectory against specific criteria.
For each criterion, respond with a JSON array of objects, each with:
- "criterion_index": the 1-based index
- "passed": true or false
- "reason": brief explanation

Respond ONLY with the JSON array, no other text."""

JUDGE_USER_TEMPLATE = """\
Trajectory:
{trajectory_json}

Criteria:
{criteria_text}

Respond as a JSON array."""


class JudgeError(Exception):
    """Raised when the judge fails."""


async def evaluate_rubric(
    trajectory: Trajectory,
    rubric: list[str],
    model: str,
) -> list[CriterionResult]:
    """Evaluate rubric criteria against a trajectory using an LLM judge."""
    if not rubric:
        return []

    trajectory_json = _format_trajectory(trajectory)
    criteria_text = "\n".join(f"{i + 1}. {c}" for i, c in enumerate(rubric))

    user_message = JUDGE_USER_TEMPLATE.format(
        trajectory_json=trajectory_json,
        criteria_text=criteria_text,
    )

    try:
        response: Any = await litellm.acompletion(  # pyright: ignore[reportUnknownMemberType]
            model=model,
            messages=[
                {"role": "system", "content": JUDGE_SYSTEM_PROMPT},
                {"role": "user", "content": user_message},
            ],
            temperature=0.0,
            response_format={"type": "json_object"},
        )
    except Exception as e:
        msg = f"Judge call failed: {e}"
        raise JudgeError(msg) from e

    content = _extract_content(response)
    return _parse_judge_response(content, rubric)


def _extract_content(response: Any) -> str:
    """Extract text content from litellm response with strict validation."""
    choices: list[Any] = getattr(response, "choices", None) or []
    if not choices:
        msg = "Judge returned no choices"
        raise JudgeError(msg)
    message: Any = getattr(choices[0], "message", None)
    if message is None:
        msg = "Judge returned no message"
        raise JudgeError(msg)
    content: Any = getattr(message, "content", None)
    if not isinstance(content, str) or not content:
        msg = "Judge returned empty response"
        raise JudgeError(msg)
    return content


def _format_trajectory(trajectory: Trajectory) -> str:
    """Format trajectory for the judge prompt."""
    spans_data: list[dict[str, object]] = []
    for span in trajectory.spans:
        span_info: dict[str, object] = {
            "model": span.model,
            "duration_ms": span.duration_ms,
        }
        if span.messages:
            span_info["messages"] = span.messages
        if span.response:
            span_info["response"] = span.response
        if span.tool_calls:
            span_info["tool_calls"] = span.tool_calls
        if span.error:
            span_info["error"] = span.error
        spans_data.append(span_info)

    data: dict[str, object] = {
        "status": trajectory.status,
        "total_duration_ms": trajectory.total_duration_ms,
        "spans": spans_data,
    }
    if trajectory.output:
        data["output"] = trajectory.output

    return json.dumps(data, indent=2, default=str)


def _parse_judge_response(content: str, rubric: list[str]) -> list[CriterionResult]:
    """Parse the judge's JSON response into CriterionResult objects."""
    try:
        raw: object = json.loads(content)
    except json.JSONDecodeError as e:
        msg = f"Judge returned invalid JSON: {e}"
        raise JudgeError(msg) from e

    items = _unwrap_to_list(raw)

    # Build index lookup for O(1) matching by criterion_index
    by_index: dict[int, dict[str, object]] = {}
    for entry in items:
        if isinstance(entry, dict):
            typed_entry = cast(dict[str, object], entry)
            idx = typed_entry.get("criterion_index")
            if isinstance(idx, int):
                by_index[idx] = typed_entry

    results: list[CriterionResult] = []
    for i, criterion in enumerate(rubric):
        item = by_index.get(i + 1)
        if item is None and i < len(items):
            fallback = items[i]
            if isinstance(fallback, dict):
                item = cast(dict[str, object], fallback)

        if item is not None:
            reason_val = item.get("reason")
            results.append(
                CriterionResult(
                    criterion=criterion,
                    passed=bool(item.get("passed", False)),
                    reason=str(reason_val) if reason_val is not None else None,
                )
            )
        else:
            results.append(
                CriterionResult(
                    criterion=criterion,
                    passed=False,
                    reason="Judge did not return a result for this criterion",
                )
            )

    return results


def _unwrap_to_list(raw: object) -> list[object]:
    """Unwrap judge response to a list, handling both bare arrays and wrapper dicts."""
    if isinstance(raw, dict):
        raw_dict = cast(dict[str, object], raw)
        for key in ("results", "criteria", "evaluations"):
            val = raw_dict.get(key)
            if isinstance(val, list):
                return cast(list[object], val)

    if isinstance(raw, list):
        return cast(list[object], raw)

    msg = f"Expected JSON array from judge, got {type(cast(object, raw)).__name__}"
    raise JudgeError(msg)
