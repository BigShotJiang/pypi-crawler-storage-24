"""Shared scenario filtering and result summarization."""

from __future__ import annotations

from dataclasses import dataclass

from aevals.config.schema import Scenario
from aevals.evals.types import ScenarioResult


@dataclass
class ResultsSummary:
    """Aggregated eval results summary."""

    total_scenarios: int
    passed_scenarios: int
    failed_scenarios: int
    total_constraints: int
    passed_constraints: int
    total_rubric: int
    passed_rubric: int
    exit_code: int


def summarize_results(results: list[ScenarioResult]) -> ResultsSummary:
    """Compute summary statistics from a list of scenario results."""
    total = len(results)
    passed = sum(1 for r in results if r.passed)
    total_constraints = sum(len(r.constraint_results) for r in results)
    passed_constraints = sum(sum(1 for c in r.constraint_results if c.passed) for r in results)
    total_rubric = sum(len(r.rubric_results) for r in results)
    passed_rubric = sum(sum(1 for rr in r.rubric_results if rr.passed) for r in results)

    return ResultsSummary(
        total_scenarios=total,
        passed_scenarios=passed,
        failed_scenarios=total - passed,
        total_constraints=total_constraints,
        passed_constraints=passed_constraints,
        total_rubric=total_rubric,
        passed_rubric=passed_rubric,
        exit_code=0 if passed == total else 1,
    )


def filter_scenarios(
    scenarios: list[Scenario],
    name_filters: tuple[str, ...] | list[str] = (),
    tag_filters: tuple[str, ...] | list[str] = (),
) -> list[Scenario]:
    """Filter scenarios by name substring and/or tags."""
    if not name_filters and not tag_filters:
        return scenarios

    filtered: list[Scenario] = []
    for s in scenarios:
        if name_filters and not any(f.lower() in s.name.lower() for f in name_filters):
            continue
        if tag_filters and not any(t in s.tags for t in tag_filters):
            continue
        filtered.append(s)
    return filtered
