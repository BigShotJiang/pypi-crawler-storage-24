"""Eval result types."""

from __future__ import annotations

from pydantic import BaseModel

from aevals.capture.schema import Trajectory
from aevals.config.schema import Scenario

ConstraintDetail = str | int | float | bool | list[str]


class CriterionResult(BaseModel):
    """Result of evaluating a single rubric criterion."""

    criterion: str
    passed: bool
    reason: str | None = None


class ConstraintResult(BaseModel):
    """Result of checking a single deterministic constraint."""

    constraint: str
    passed: bool
    details: dict[str, ConstraintDetail]


class ScenarioResult(BaseModel):
    """Complete eval result for a single scenario."""

    scenario: Scenario
    trajectory: Trajectory
    constraint_results: list[ConstraintResult]
    rubric_results: list[CriterionResult]
    rubric_pending: bool
    passed: bool
