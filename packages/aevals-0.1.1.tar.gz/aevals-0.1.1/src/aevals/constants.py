"""Shared constants for aevals."""

from __future__ import annotations

from pathlib import Path

# Directory layout
AEVALS_DIR = Path(".aevals")
TRACES_DIR = AEVALS_DIR / "traces"
RESULTS_DIR = AEVALS_DIR / "results"
WRAPPER_PATH = AEVALS_DIR / "run_wrapper.py"

# Output markers (used by run_wrapper.py template and result extraction)
RESULT_MARKER_START = "__AEVALS_RESULT__"
RESULT_MARKER_END = "__AEVALS_END__"

# Environment variable names (shared between cli/run.py and run_wrapper.py)
ENV_RUN_ID = "AEVALS_RUN_ID"
ENV_ENTRY = "AEVALS_ENTRY"
ENV_TRACE_DIR = "AEVALS_TRACE_DIR"
