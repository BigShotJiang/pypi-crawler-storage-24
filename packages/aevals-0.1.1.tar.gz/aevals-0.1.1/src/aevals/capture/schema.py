"""Trajectory and span models built from OTel spans."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

from aevals.config.schema import Scenario


class LLMCall(BaseModel):
    """A single LLM call extracted from OTel span attributes."""

    span_id: str
    model: str
    messages: list[dict[str, object]] | None = None
    response: str | None = None
    tool_calls: list[dict[str, object]] | None = None
    tokens_in: int | None = None
    tokens_out: int | None = None
    duration_ms: int
    provider: str
    error: str | None = None


class Trajectory(BaseModel):
    """Complete trajectory for a scenario run."""

    run_id: str
    scenario: Scenario
    spans: list[LLMCall]
    output: dict[str, object] | None = None
    status: Literal["success", "timeout", "error"]
    exit_code: int | None = None
    stderr: str | None = None
    total_duration_ms: int
    total_tokens: int | None = None
