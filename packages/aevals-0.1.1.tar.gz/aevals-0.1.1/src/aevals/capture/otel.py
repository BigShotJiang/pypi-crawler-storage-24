"""OTel setup for agent subprocess tracing."""

from __future__ import annotations

import json
import os
import sys
from collections.abc import Sequence
from pathlib import Path
from typing import cast

from opentelemetry import trace
from opentelemetry.sdk.trace import ReadableSpan, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SpanExporter, SpanExportResult

from aevals.capture.schema import LLMCall

INSTRUMENTORS: list[tuple[str, str, str]] = [
    ("openai", "opentelemetry.instrumentation.openai", "OpenAIInstrumentor"),
    ("anthropic", "opentelemetry.instrumentation.anthropic", "AnthropicInstrumentor"),
    (
        "google.generativeai",
        "opentelemetry.instrumentation.google_generativeai",
        "GoogleGenerativeAiInstrumentor",
    ),
    ("cohere", "opentelemetry.instrumentation.cohere", "CohereInstrumentor"),
    ("mistralai", "opentelemetry.instrumentation.mistralai", "MistralAiInstrumentor"),
    ("botocore", "opentelemetry.instrumentation.bedrock", "BedrockInstrumentor"),
]


class JSONFileSpanExporter(SpanExporter):
    """Export OTel spans to a JSON file."""

    def __init__(self, path: str) -> None:
        self._path = Path(path)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._spans: list[dict[str, object]] = []

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        for span in spans:
            self._spans.append(_span_to_dict(span))
        self._flush()
        return SpanExportResult.SUCCESS

    def shutdown(self) -> None:
        self._flush()

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        self._flush()
        return True

    def _flush(self) -> None:
        self._path.write_text(json.dumps(self._spans, indent=2, default=str))


def _span_to_dict(span: ReadableSpan) -> dict[str, object]:
    """Convert an OTel ReadableSpan to a serializable dict."""
    attributes = dict(span.attributes) if span.attributes else {}
    start = span.start_time or 0
    end = span.end_time or 0
    duration_ns = end - start
    return {
        "span_id": format(span.context.span_id, "016x") if span.context else "",
        "name": span.name,
        "start_time": start,
        "end_time": end,
        "duration_ms": duration_ns // 1_000_000,
        "attributes": attributes,
        "status": span.status.status_code.name if span.status else "UNSET",
    }


def activate(run_id: str, trace_dir: str) -> None:
    """Set up OTel tracing for the agent subprocess."""
    os.environ["TRACELOOP_TRACE_CONTENT"] = "true"

    exporter = JSONFileSpanExporter(
        path=os.path.join(trace_dir, f"{run_id}.json"),
    )
    provider = TracerProvider()
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)

    for sdk_module, instrumentor_module, class_name in INSTRUMENTORS:
        _try_instrument(sdk_module, instrumentor_module, class_name)


def _try_instrument(sdk_module: str, instrumentor_module: str, class_name: str) -> None:
    """Try to auto-instrument an SDK. Skip if not installed."""
    try:
        __import__(sdk_module)
    except ImportError:
        return

    try:
        mod = __import__(instrumentor_module, fromlist=[class_name])
        instrumentor = getattr(mod, class_name)()
        instrumentor.instrument()
    except (ImportError, AttributeError, TypeError) as e:
        print(f"aevals: failed to instrument {sdk_module}: {e}", file=sys.stderr)


def parse_trace_file(trace_path: Path) -> list[LLMCall]:
    """Parse a trace JSON file into LLMCall objects."""
    try:
        raw: object = json.loads(trace_path.read_text())
    except FileNotFoundError:
        return []
    if not isinstance(raw, list):
        return []

    span_list = cast(list[object], raw)
    calls: list[LLMCall] = []
    for item in span_list:
        if not isinstance(item, dict):
            continue
        span_data = cast(dict[str, object], item)

        attrs_raw = span_data.get("attributes", {})
        if not isinstance(attrs_raw, dict):
            continue
        attrs = cast(dict[str, object], attrs_raw)
        if not attrs:
            continue

        model = _get_attr(attrs, "gen_ai.request.model", "")
        if not model:
            # Not an LLM span — skip non-LLM spans
            provider_name = _get_attr(attrs, "gen_ai.system", "")
            if not provider_name:
                continue

        messages = _extract_messages(attrs)
        response = _extract_response(attrs)
        tool_calls = _extract_tool_calls(attrs)
        tokens_in = _get_int_attr(attrs, "gen_ai.usage.input_tokens")
        tokens_out = _get_int_attr(attrs, "gen_ai.usage.output_tokens")
        provider = _get_attr(attrs, "gen_ai.system", "unknown")
        error = _get_attr(attrs, "error.message", None)

        span_id_raw = span_data.get("span_id", "")
        duration_raw = span_data.get("duration_ms", 0)

        calls.append(
            LLMCall(
                span_id=str(span_id_raw),
                model=model,
                messages=messages if messages else None,
                response=response,
                tool_calls=tool_calls if tool_calls else None,
                tokens_in=tokens_in,
                tokens_out=tokens_out,
                duration_ms=int(duration_raw) if isinstance(duration_raw, (int, float)) else 0,
                provider=provider,
                error=error,
            )
        )

    return calls


def _get_attr(attrs: dict[str, object], key: str, default: str | None = None) -> str:
    """Get a string attribute."""
    val = attrs.get(key, default)
    return str(val) if val is not None else ""


def _get_int_attr(attrs: dict[str, object], key: str) -> int | None:
    """Get an integer attribute."""
    val = attrs.get(key)
    if val is None:
        return None
    if isinstance(val, int):
        return val
    if isinstance(val, (float, str)):
        try:
            return int(val)
        except (ValueError, OverflowError):
            return None
    return None


def _extract_messages(attrs: dict[str, object]) -> list[dict[str, object]]:
    """Extract prompt messages from gen_ai.prompt.* attributes."""
    messages: list[dict[str, object]] = []
    i = 0
    while True:
        role_key = f"gen_ai.prompt.{i}.role"
        content_key = f"gen_ai.prompt.{i}.content"
        if role_key not in attrs and content_key not in attrs:
            break
        msg: dict[str, object] = {}
        if role_key in attrs:
            msg["role"] = attrs[role_key]
        if content_key in attrs:
            msg["content"] = attrs[content_key]
        # Extract tool calls in messages
        tc = _extract_indexed_tool_calls(attrs, f"gen_ai.prompt.{i}.tool_calls")
        if tc:
            msg["tool_calls"] = tc
        messages.append(msg)
        i += 1
    return messages


def _extract_response(attrs: dict[str, object]) -> str | None:
    """Extract the first completion content."""
    content = attrs.get("gen_ai.completion.0.content")
    if content is not None:
        return str(content)
    return None


def _extract_tool_calls(attrs: dict[str, object]) -> list[dict[str, object]]:
    """Extract tool calls from gen_ai.completion.0.tool_calls.*."""
    return _extract_indexed_tool_calls(attrs, "gen_ai.completion.0.tool_calls")


def _extract_indexed_tool_calls(attrs: dict[str, object], prefix: str) -> list[dict[str, object]]:
    """Extract tool calls from indexed attributes like prefix.0.name, prefix.0.arguments."""
    tool_calls: list[dict[str, object]] = []
    i = 0
    while True:
        name_key = f"{prefix}.{i}.name"
        args_key = f"{prefix}.{i}.arguments"
        if name_key not in attrs and args_key not in attrs:
            break
        tc: dict[str, object] = {}
        if name_key in attrs:
            tc["name"] = attrs[name_key]
        if args_key in attrs:
            tc["arguments"] = attrs[args_key]
        tool_calls.append(tc)
        i += 1
    return tool_calls
