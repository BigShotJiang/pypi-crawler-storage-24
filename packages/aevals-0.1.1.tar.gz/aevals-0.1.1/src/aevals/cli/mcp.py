"""aevals mcp-serve — start the MCP server."""

from __future__ import annotations

import click


@click.command()
def mcp_serve_cmd() -> None:
    """Start the aevals MCP server (stdio transport)."""
    from aevals.mcp.server import run_server

    run_server()
