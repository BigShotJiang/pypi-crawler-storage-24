"""Click-based CLI for aevals."""

from __future__ import annotations

import click

from aevals.cli.init import init_cmd
from aevals.cli.mcp import mcp_serve_cmd
from aevals.cli.run import run_cmd


@click.group()
@click.version_option(package_name="aevals")
def cli() -> None:
    """aevals — AI-operated agent eval."""


cli.add_command(init_cmd, name="init")
cli.add_command(run_cmd, name="run")
cli.add_command(mcp_serve_cmd, name="mcp-serve")
