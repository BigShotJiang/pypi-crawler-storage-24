"""aevals init — set up evals for a project."""

from __future__ import annotations

import json
from pathlib import Path

import click
import yaml

from aevals.config.schema import AevalsConfig, DefaultsConfig, RunConfig
from aevals.constants import AEVALS_DIR, RESULTS_DIR, TRACES_DIR
from aevals.scanner.detect import scan_directory
from aevals.scanner.wrapper import generate_wrapper


@click.command()
@click.option("--dir", "directory", default=".", help="Project directory to scan.")
def init_cmd(directory: str) -> None:
    """Set up aevals for a project."""
    project_dir = Path(directory).resolve()

    click.echo(f"Scanning {project_dir}...")
    scan = scan_directory(project_dir)

    click.echo(f"  Found {len(scan.python_files)} Python files")
    if scan.sdks:
        click.echo(f"  Detected SDKs: {', '.join(scan.sdks)}")
    if scan.entrypoint_candidates:
        click.echo(f"  Entrypoint candidates: {', '.join(scan.entrypoint_candidates[:5])}")
    if scan.tool_definitions:
        click.echo(f"  Tool definitions: {', '.join(scan.tool_definitions[:5])}")

    # Determine entry
    entry = ""
    if scan.entrypoint_candidates:
        entry = scan.entrypoint_candidates[0]
        click.echo(f"\n  Using entry: {entry}")
    else:
        click.echo("\n  No entrypoint detected. Set 'entry' in aevals.yaml manually.")
        entry = "module:callable"

    # Generate config
    config = AevalsConfig(
        entry=entry,
        defaults=DefaultsConfig(),
        run=RunConfig(),
    )

    config_path = project_dir / "aevals.yaml"
    config_data = config.model_dump(exclude_none=True)
    config_path.write_text(yaml.dump(config_data, default_flow_style=False, sort_keys=False))
    click.echo(f"\n  Created {config_path}")

    # Generate wrapper
    aevals_dir = project_dir / AEVALS_DIR
    wrapper_path = generate_wrapper(aevals_dir)
    click.echo(f"  Created {wrapper_path}")

    # Create trace and results directories
    (project_dir / TRACES_DIR).mkdir(parents=True, exist_ok=True)
    (project_dir / RESULTS_DIR).mkdir(parents=True, exist_ok=True)
    click.echo("  Created .aevals/traces/ and .aevals/results/")

    # Write MCP config
    claude_dir = project_dir / ".claude"
    claude_dir.mkdir(parents=True, exist_ok=True)
    mcp_config_path = claude_dir / "mcp.json"
    mcp_config = {
        "mcpServers": {
            "aevals": {
                "command": "aevals",
                "args": ["mcp-serve"],
            }
        }
    }
    mcp_config_path.write_text(json.dumps(mcp_config, indent=2))
    click.echo(f"  Created {mcp_config_path}")

    click.echo("\nDone! Edit aevals.yaml to add scenarios and rubrics.")
