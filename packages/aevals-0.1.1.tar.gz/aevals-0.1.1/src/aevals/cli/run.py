"""aevals run — execute eval scenarios."""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
import uuid
from typing import Literal

import click

from aevals.capture.otel import parse_trace_file
from aevals.capture.schema import Trajectory
from aevals.config.loader import ConfigError, load_config
from aevals.config.schema import AevalsConfig, Scenario
from aevals.constants import (
    ENV_ENTRY,
    ENV_RUN_ID,
    ENV_TRACE_DIR,
    RESULT_MARKER_END,
    RESULT_MARKER_START,
    RESULTS_DIR,
    TRACES_DIR,
    WRAPPER_PATH,
)
from aevals.evals.constraints import check_constraints
from aevals.evals.judge import JudgeError, evaluate_rubric
from aevals.evals.runner import filter_scenarios
from aevals.evals.types import ScenarioResult
from aevals.output.json import format_json
from aevals.output.terminal import print_results

TrajectoryStatus = Literal["success", "timeout", "error"]


@click.command()
@click.option("--scenario", "scenario_filter", multiple=True, help="Filter by scenario name.")
@click.option("--tag", "tag_filter", multiple=True, help="Filter by tag (OR logic).")
@click.option("--json", "json_output", is_flag=True, help="Output JSON instead of terminal.")
def run_cmd(
    scenario_filter: tuple[str, ...], tag_filter: tuple[str, ...], json_output: bool
) -> None:
    """Run eval scenarios."""
    try:
        config = load_config()
    except ConfigError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    scenarios = filter_scenarios(config.scenarios, scenario_filter, tag_filter)
    if not scenarios:
        click.echo("No scenarios to run.", err=True)
        sys.exit(1)

    if not json_output:
        click.echo(f"Running {len(scenarios)} scenarios...")

    results = asyncio.run(run_scenarios(config, scenarios))

    # Check for zero-trace error
    if results and all(len(r.trajectory.spans) == 0 for r in results):
        click.echo(
            "Error: Zero spans captured across all scenarios. Check OTel instrumentation.",
            err=True,
        )
        sys.exit(2)

    if json_output:
        click.echo(format_json(results))
    else:
        print_results(results)

    any_failed = any(not r.passed for r in results)
    sys.exit(1 if any_failed else 0)


async def run_scenarios(config: AevalsConfig, scenarios: list[Scenario]) -> list[ScenarioResult]:
    """Run all scenarios concurrently."""
    TRACES_DIR.mkdir(parents=True, exist_ok=True)
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)

    tasks = [_run_single_scenario(config, scenario) for scenario in scenarios]
    return list(await asyncio.gather(*tasks))


async def _run_single_scenario(config: AevalsConfig, scenario: Scenario) -> ScenarioResult:
    """Run a single scenario: spawn subprocess, collect traces, evaluate."""
    run_id = str(uuid.uuid4())

    try:
        WRAPPER_PATH.read_bytes()
    except FileNotFoundError:
        return _error_result(run_id, scenario, "Wrapper not found. Run 'aevals init' first.")

    # Prepare subprocess
    env = {
        **os.environ,
        ENV_RUN_ID: run_id,
        ENV_ENTRY: config.entry,
        ENV_TRACE_DIR: str(TRACES_DIR),
    }

    task_input = json.dumps({"input": scenario.input, "run_id": run_id})
    timeout_s = config.run.timeout_ms / 1000

    start_time = time.monotonic()
    status: TrajectoryStatus
    exit_code: int | None
    stderr: str | None
    output: dict[str, object] | None
    proc: asyncio.subprocess.Process | None = None
    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            str(WRAPPER_PATH),
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(input=task_input.encode()),
            timeout=timeout_s,
        )
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        stdout_str = stdout_bytes.decode()
        status = "success" if proc.returncode == 0 else "error"
        exit_code = proc.returncode
        stderr = stderr_bytes.decode() or None
        output = _extract_output(stdout_str)
    except TimeoutError:
        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        if proc is not None:
            proc.kill()
        status = "timeout"
        exit_code = None
        stderr = "Process timed out"
        output = None

    # Parse traces
    trace_path = TRACES_DIR / f"{run_id}.json"
    spans = parse_trace_file(trace_path)

    total_tokens: int | None = None
    token_values = [
        (s.tokens_in or 0) + (s.tokens_out or 0)
        for s in spans
        if s.tokens_in is not None or s.tokens_out is not None
    ]
    if token_values:
        total_tokens = sum(token_values)

    trajectory = Trajectory(
        run_id=run_id,
        scenario=scenario,
        spans=spans,
        output=output,
        status=status,
        exit_code=exit_code,
        stderr=stderr,
        total_duration_ms=elapsed_ms,
        total_tokens=total_tokens,
    )

    # Save trajectory
    result_path = RESULTS_DIR / f"{run_id}.json"
    result_path.write_text(trajectory.model_dump_json(indent=2))

    # Run constraints
    resolved_constraints = config.resolve_constraints(scenario)
    constraint_results = check_constraints(trajectory, resolved_constraints)

    # Run rubric judge
    rubric_pending = True
    rubric_results = []
    if scenario.rubric and config.judge:
        try:
            rubric_results = await evaluate_rubric(trajectory, scenario.rubric, config.judge.model)
            rubric_pending = False
        except JudgeError as e:
            click.echo(f"  Judge error for '{scenario.name}': {e}", err=True)

    # Determine pass/fail
    constraints_pass = all(cr.passed for cr in constraint_results)
    rubric_pass = all(rr.passed for rr in rubric_results) if rubric_results else True
    passed = constraints_pass and rubric_pass

    return ScenarioResult(
        scenario=scenario,
        trajectory=trajectory,
        constraint_results=constraint_results,
        rubric_results=rubric_results,
        rubric_pending=rubric_pending,
        passed=passed,
    )


def _extract_output(stdout: str) -> dict[str, object] | None:
    """Extract output between result markers."""
    start_idx = stdout.find(RESULT_MARKER_START)
    if start_idx == -1:
        return None

    start_idx += len(RESULT_MARKER_START)
    end_idx = stdout.find(RESULT_MARKER_END, start_idx)
    if end_idx == -1:
        return None

    result_str = stdout[start_idx:end_idx].strip()
    try:
        parsed: dict[str, object] = json.loads(result_str)
        return parsed
    except json.JSONDecodeError:
        return None


def _error_result(run_id: str, scenario: Scenario, error_msg: str) -> ScenarioResult:
    """Create an error ScenarioResult."""
    trajectory = Trajectory(
        run_id=run_id,
        scenario=scenario,
        spans=[],
        output=None,
        status="error",
        exit_code=None,
        stderr=error_msg,
        total_duration_ms=0,
        total_tokens=None,
    )
    return ScenarioResult(
        scenario=scenario,
        trajectory=trajectory,
        constraint_results=[],
        rubric_results=[],
        rubric_pending=True,
        passed=False,
    )
