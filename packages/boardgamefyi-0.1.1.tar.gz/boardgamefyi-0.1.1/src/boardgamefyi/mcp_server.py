"""MCP server for boardgamefyi — AI assistant tools for boardgamefyi.com.

Run: uvx --from "boardgamefyi[mcp]" python -m boardgamefyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("BoardGameFYI")


@mcp.tool()
def list_games(limit: int = 20, offset: int = 0) -> str:
    """List games from boardgamefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from boardgamefyi.api import BoardGameFYI

    with BoardGameFYI() as api:
        data = api.list_games(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No games found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_game(slug: str) -> str:
    """Get detailed information about a specific game.

    Args:
        slug: URL slug identifier for the game.
    """
    from boardgamefyi.api import BoardGameFYI

    with BoardGameFYI() as api:
        data = api.get_game(slug)
        return str(data)


@mcp.tool()
def list_designers(limit: int = 20, offset: int = 0) -> str:
    """List designers from boardgamefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from boardgamefyi.api import BoardGameFYI

    with BoardGameFYI() as api:
        data = api.list_designers(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No designers found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_boardgame(query: str) -> str:
    """Search boardgamefyi.com for board games, designers, categories, and awards.

    Args:
        query: Search query string.
    """
    from boardgamefyi.api import BoardGameFYI

    with BoardGameFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
