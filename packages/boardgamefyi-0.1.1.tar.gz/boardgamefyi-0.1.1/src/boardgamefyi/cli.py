"""Command-line interface for boardgamefyi."""

from __future__ import annotations

import json

import typer

from boardgamefyi.api import BoardGameFYI

app = typer.Typer(help="BoardGameFYI — Board games, rules and reviews API client.")


@app.command()
def search(query: str) -> None:
    """Search boardgamefyi.com."""
    with BoardGameFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
