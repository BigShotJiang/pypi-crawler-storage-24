"""Python API client for boardgamefyi.com."""

__version__ = "0.1.0"
