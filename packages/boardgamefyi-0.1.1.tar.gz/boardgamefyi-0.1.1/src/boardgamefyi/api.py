"""HTTP API client for boardgamefyi.com REST endpoints.

Requires the ``api`` extra: ``pip install boardgamefyi[api]``

Usage::

    from boardgamefyi.api import BoardGameFYI

    with BoardGameFYI() as api:
        items = api.list_artists()
        detail = api.get_artist("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class BoardGameFYI:
    """API client for the boardgamefyi.com REST API.

    Provides typed access to all boardgamefyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://boardgamefyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://boardgamefyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_artists(self, **params: Any) -> dict[str, Any]:
        """List all artists."""
        return self._get("/api/v1/artists/", **params)

    def get_artist(self, slug: str) -> dict[str, Any]:
        """Get artist by slug."""
        return self._get(f"/api/v1/artists/" + slug + "/")

    def list_awards(self, **params: Any) -> dict[str, Any]:
        """List all awards."""
        return self._get("/api/v1/awards/", **params)

    def get_award(self, slug: str) -> dict[str, Any]:
        """Get award by slug."""
        return self._get(f"/api/v1/awards/" + slug + "/")

    def list_categories(self, **params: Any) -> dict[str, Any]:
        """List all categories."""
        return self._get("/api/v1/categories/", **params)

    def get_category(self, slug: str) -> dict[str, Any]:
        """Get category by slug."""
        return self._get(f"/api/v1/categories/" + slug + "/")

    def list_designers(self, **params: Any) -> dict[str, Any]:
        """List all designers."""
        return self._get("/api/v1/designers/", **params)

    def get_designer(self, slug: str) -> dict[str, Any]:
        """Get designer by slug."""
        return self._get(f"/api/v1/designers/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_game_night_themes(self, **params: Any) -> dict[str, Any]:
        """List all game night themes."""
        return self._get("/api/v1/game-night-themes/", **params)

    def get_game_night_theme(self, slug: str) -> dict[str, Any]:
        """Get game night theme by slug."""
        return self._get(f"/api/v1/game-night-themes/" + slug + "/")

    def list_games(self, **params: Any) -> dict[str, Any]:
        """List all games."""
        return self._get("/api/v1/games/", **params)

    def get_game(self, slug: str) -> dict[str, Any]:
        """Get game by slug."""
        return self._get(f"/api/v1/games/" + slug + "/")

    def list_glossary(self, **params: Any) -> dict[str, Any]:
        """List all glossary."""
        return self._get("/api/v1/glossary/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/glossary/" + slug + "/")

    def list_guide_series(self, **params: Any) -> dict[str, Any]:
        """List all guide series."""
        return self._get("/api/v1/guide-series/", **params)

    def get_guide_sery(self, slug: str) -> dict[str, Any]:
        """Get guide sery by slug."""
        return self._get(f"/api/v1/guide-series/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/guides/" + slug + "/")

    def list_mechanics(self, **params: Any) -> dict[str, Any]:
        """List all mechanics."""
        return self._get("/api/v1/mechanics/", **params)

    def get_mechanic(self, slug: str) -> dict[str, Any]:
        """Get mechanic by slug."""
        return self._get(f"/api/v1/mechanics/" + slug + "/")

    def list_progression_paths(self, **params: Any) -> dict[str, Any]:
        """List all progression paths."""
        return self._get("/api/v1/progression-paths/", **params)

    def get_progression_path(self, slug: str) -> dict[str, Any]:
        """Get progression path by slug."""
        return self._get(f"/api/v1/progression-paths/" + slug + "/")

    def list_publishers(self, **params: Any) -> dict[str, Any]:
        """List all publishers."""
        return self._get("/api/v1/publishers/", **params)

    def get_publisher(self, slug: str) -> dict[str, Any]:
        """Get publisher by slug."""
        return self._get(f"/api/v1/publishers/" + slug + "/")

    def list_tools(self, **params: Any) -> dict[str, Any]:
        """List all tools."""
        return self._get("/api/v1/tools/", **params)

    def get_tool(self, slug: str) -> dict[str, Any]:
        """Get tool by slug."""
        return self._get(f"/api/v1/tools/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> BoardGameFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
