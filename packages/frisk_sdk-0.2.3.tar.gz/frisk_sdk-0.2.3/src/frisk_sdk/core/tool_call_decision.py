from enum import Enum

from dataclasses import dataclass
from typing import Optional

from .._core import ProcessToolCallResultPy  # type: ignore


class DecisionOutcome(str, Enum):
    """Policy outcome values returned by tool-call evaluation."""

    ALLOW = "allow"
    DENY = "deny"
    ERROR = (
        "error"  # Explicit error state is only constructed in Python, never in Rust.
    )


@dataclass
class ToolCallDecision:
    """Normalized tool-call evaluation result returned by the Python SDK."""

    outcome: DecisionOutcome
    rules_matched_count: int
    reason: Optional[str]

    @staticmethod
    def from_rust_binding(
        rust_binding: ProcessToolCallResultPy,
    ) -> "ToolCallDecision":
        """Convert the native Rust binding result into the Python dataclass shape."""
        return ToolCallDecision(
            outcome=DecisionOutcome(rust_binding.decision),
            rules_matched_count=rust_binding.rules_matched_count,
            reason=rust_binding.reason,
        )
