// Telemetry constants for spans, attributes, metrics, and logs used by the policy engine.
// Keeping these centralized avoids magic strings and keeps naming consistent across the crate.

// Span names (some call sites use literals directly due to macro constraints)
pub const SPAN_NAME_DECIDE_TOOL_CALL: &str = "frisk.engine.decide_tool_call.evaluate";
pub const SPAN_NAME_EVALUATE_POLICY: &str = "frisk.policy.evaluate";

// Common span attribute keys
pub const ATTRIBUTE_NAME_TOOL_NAME: &str = "frisk.tool.name";
pub const ATTRIBUTE_NAME_TOOL_CALL_ID: &str = "frisk.tool_call.id";
pub const ATTRIBUTE_NAME_TOOL_ARGS_JSON: &str = "frisk.tool.args.json";
pub const ATTRIBUTE_NAME_TOOL_ARGS_REDACTED_PATHS_JSON: &str =
    "frisk.tool.args_redacted_paths.json";
pub const ATTRIBUTE_NAME_AGENT_STATE_JSON: &str = "frisk.agent_state.json";
pub const ATTRIBUTE_NAME_AGENT_STATE_REDACTED_PATHS_JSON: &str =
    "frisk.agent_state_redacted_paths.json";

pub const ATTRIBUTE_NAME_POLICY_ID: &str = "frisk.policy.id";
pub const ATTRIBUTE_NAME_POLICY_VERSION_ID: &str = "frisk.policy.version_id";
pub const ATTRIBUTE_NAME_POLICY_STATUS: &str = "frisk.policy.status";

pub const ATTRIBUTE_NAME_POLICY_EFFECT: &str = "frisk.policy.effect";
pub const ATTRIBUTE_NAME_POLICY_EFFECT_REASON: &str = "frisk.policy.effect_reason";
pub const ATTRIBUTE_NAME_POLICY_MATCHED: &str = "frisk.policy.matched";
pub const ATTRIBUTE_NAME_POLICY_EVALUATION_ERRORS_JSON: &str =
    "frisk.policy.evaluation_errors.json";
pub const POLICY_EVALUATION_ERRORS_SERIALIZATION_ERROR: &str = "[{\"error\":\"Some policies were evaluated, but an error was encountered while trying to serialize their evaluation errors.\"}]";

pub const ATTRIBUTE_NAME_DECISION_OUTCOME: &str = "frisk.decision.outcome";
pub const ATTRIBUTE_NAME_DECISION_REASON: &str = "frisk.decision.reason";
pub const ATTRIBUTE_NAME_MATCHED_RULE_COUNT: &str = "frisk.decision.matched_rule_count";
pub const ATTRIBUTE_NAME_POLICIES_SKIPPED: &str = "frisk.tool_call.policies_skipped.json";
pub const POLICIES_SKIPPED_SERIALIZATION_ERROR: &str = "[{\"error\":\"Some policies were skipped, but an error was encountered while trying to serialize them.\"}]";

// Common attribute values
pub const EFFECT_ALLOW: &str = "allow";
pub const EFFECT_DENY: &str = "deny";
pub const EFFECT_MODIFY: &str = "modify";
pub const EFFECT_NONE: &str = "none";
pub const EFFECT_UNKNOWN: &str = "unknown";

// Effect reason strings
pub const EFFECT_REASON_ALLOW_MATCHED: &str = "Explicitly matched allow condition";
pub const EFFECT_REASON_ALLOW_MISMATCHED: &str = "Explicitly mismatched allow condition";
pub const EFFECT_REASON_DENY_MATCHED: &str = "Explicitly matched deny condition";
pub const EFFECT_REASON_DENY_MISMATCHED: &str = "Explicitly mismatched deny condition";

pub const EVAL_FAIL_ALLOW_PREFIX: &str =
    "Failed to evaluate allow condition for the following reason:";
pub const EVAL_FAIL_DENY_PREFIX: &str =
    "Failed to evaluate deny condition for the following reason:";
pub const EVAL_FAIL_MODIFY_PREFIX: &str =
    "Failed to evaluate modify condition for the following reason:";

// Metrics
pub const METER_NAME: &str = "policy-engine";
pub const HISTOGRAM_DECISION_LATENCY_MS: &str = "policy_engine.decision_latency_ms";
pub const HISTOGRAM_DECISION_LATENCY_DESC: &str = "Latency of policy decisions in milliseconds";
pub const UNIT_MS: &str = "ms";
pub const METRIC_ATTR_TOOL_NAME: &str = "tool_name";
pub const METRIC_ATTR_DECISION: &str = "decision";

// Logs
pub const LOGGER_NAME: &str = "policy_engine";
pub const LOG_EVENT_PROCESS_TOOL_CALL_RESULT: &str = "process_tool_call_result";
pub const LOG_TARGET_DECISION: &str = "policy_engine::decision";
pub const LOG_SEVERITY_INFO: &str = "INFO";

// Errors
pub const ATTRIBUTE_NAME_TELEMETRY_ERRORS: &str = "frisk.telemetry_errors";
pub const TELEMETRY_SERIALIZATION_ERROR: &str = "[\"Errors occurred while serializing telemetry, but an error was encountered while trying to serialize them.\"]";
