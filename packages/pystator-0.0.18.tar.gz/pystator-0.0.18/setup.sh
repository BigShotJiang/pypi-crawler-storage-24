#!/bin/bash
################################################################################
# Setup script for PyStator development environment
#
# Creates venv, installs dev dependencies, optional API/UI deps, Jupyter kernel,
# and pre-commit hooks. Run from anywhere:
#   ./setup.sh
#   /path/to/pystator/setup.sh
################################################################################

set -euo pipefail  # Exit on error, undefined vars, pipe failures

# Avoid pyenv rehash hanging 60s if triggered (e.g. by python3 -m venv)
export PYENV_REHASH_TIMEOUT=0

# Run from pystator repo root (script may be run via symlink or from another dir)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

info() { echo -e "${BLUE}ℹ${NC} $1"; }
success() { echo -e "${GREEN}✓${NC} $1"; }
warning() { echo -e "${YELLOW}⚠${NC} $1"; }
error() { echo -e "${RED}✗${NC} $1" >&2; }

# Check if Python 3 is available
if ! command -v python3 &> /dev/null; then
    error "Python 3 is not installed. Please install Python 3.10 or higher."
    exit 1
fi

# Check Python version (requires 3.10+)
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}')
PYTHON_MAJOR=$(echo "$PYTHON_VERSION" | cut -d. -f1)
PYTHON_MINOR=$(echo "$PYTHON_VERSION" | cut -d. -f2)
if ! [[ "$PYTHON_MAJOR" =~ ^[0-9]+$ ]] || ! [[ "$PYTHON_MINOR" =~ ^[0-9]+$ ]]; then
    error "Could not parse Python version. Found: $PYTHON_VERSION"
    exit 1
fi
if [ "$PYTHON_MAJOR" -lt 3 ] || ([ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -lt 11 ]); then
    error "Python 3.11 or higher is required. Found: $PYTHON_VERSION"
    exit 1
fi

info "Python version: $PYTHON_VERSION"
echo ""

# Create virtual environment (or recreate if broken)
if [ ! -d "venv" ] || [ ! -f "venv/bin/python" ]; then
    if [ -d "venv" ]; then
        info "Removing broken or incomplete virtual environment..."
        rm -rf venv
    fi
    info "Creating virtual environment..."
    python3 -m venv venv
    success "Virtual environment created"
else
    success "Virtual environment already exists"
fi

# Use venv binaries directly (no shell activation) — avoids pyenv rehash and works from any shell
VENV_PYTHON="venv/bin/python"
VENV_PIP="venv/bin/pip"

# Upgrade pip
info "Upgrading pip..."
"$VENV_PIP" install --upgrade pip --quiet

# Install package in development mode
info "Installing PyStator in development mode..."
if "$VENV_PIP" install -e ".[dev]" --quiet; then
    success "PyStator installed with dev dependencies"
else
    error "Failed to install PyStator. Check the error messages above."
    exit 1
fi

# Pre-commit hooks (same as pycharter: run on commit so CI stays green)
if [ -x "venv/bin/pre-commit" ]; then
    info "Installing pre-commit hooks..."
    venv/bin/pre-commit install
    success "Pre-commit hooks installed."
else
    warning "pre-commit not found. Install with: $VENV_PIP install pre-commit && venv/bin/pre-commit install"
fi

# Install API dependencies if API exists (src layout)
if [ -d "src/pystator/api" ]; then
    info "Installing API dependencies (required for API server)..."
    if "$VENV_PIP" install -e ".[api]" --quiet; then
        success "API dependencies installed"
    else
        warning "Failed to install API dependencies. API server may not work."
    fi
fi

# Install UI dependencies if UI exists (src layout)
if [ -d "src/pystator/ui" ]; then
    info "Installing UI dependencies (required for UI server)..."
    if "$VENV_PIP" install -e ".[ui]" --quiet; then
        success "UI dependencies installed"
    else
        warning "Failed to install UI dependencies. UI server may not work."
    fi
fi

# Create Jupyter kernel for this environment (optional)
KERNEL_NAME="pystator-dev"
KERNEL_DISPLAY_NAME="Python (pystator-dev)"
info "Setting up Jupyter kernel (optional)..."
venv/bin/python -m jupyter kernelspec remove "$KERNEL_NAME" --quiet 2>/dev/null || true
if "$VENV_PYTHON" -m ipykernel install --user --name="$KERNEL_NAME" --display-name="$KERNEL_DISPLAY_NAME" 2>/dev/null; then
    success "Jupyter kernel '$KERNEL_DISPLAY_NAME' created"
else
    warning "Jupyter kernel not created (install ipykernel if needed: $VENV_PIP install ipykernel)"
fi

echo ""
success "Setup complete!"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📋 Quick Start"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "To activate the environment:"
echo "  source venv/bin/activate"
echo ""
echo "To start development servers:"
echo "  pystator api       # Start API server (http://localhost:8000)"
echo "  pystator ui dev   # Start UI dev server (http://localhost:3000)"
echo "  pystator ui serve # Serve built UI (run 'pystator ui build' first)"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🧪 Testing"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "Run tests:"
echo "  pytest"
echo ""
echo "Run tests with coverage:"
echo "  pytest --cov=pystator"
echo ""
echo "Run linting (Black/isort) or pre-commit on all files:"
echo "  pre-commit run --all-files"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "💡 Development Tips"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "• Package is installed in editable mode (-e), so code changes are"
echo "  reflected immediately (restart server to see changes)"
echo ""
echo "• To build the UI for production:"
echo "  pystator ui build   # Requires Node.js and npm in src/pystator/ui"
echo ""
