# PyStator notebooks

Run the demo notebook:

```bash
# From pystator repo root, with dev deps (includes JupyterLab)
pip install -e ".[dev]"
cd notebook
jupyter lab pystator_demo.ipynb
```

Or with classic Jupyter:

```bash
jupyter notebook pystator_demo.ipynb
```

`pystator_demo.ipynb` walks through loading a state machine (dict or YAML), processing events, and optionally using guards and actions.
