"""Day Trading FSM Example with Parallel States.

This example demonstrates using PyStator for a day trading system
with parallel states (orthogonal regions) that manage:
- Trading workflow (scanning -> analyzing -> executing -> managing)
- Risk monitoring (normal -> elevated -> critical)
- Data feed connection (connecting -> connected -> reconnecting -> failed)
- Order management (idle -> pending -> partial -> cancelling)

Each region operates independently, allowing the system to track
multiple concurrent concerns without complex nested state logic.
"""

import asyncio
from datetime import datetime, timezone
from typing import Any

from pystator import (
    StateMachine,
    GuardRegistry,
    ActionRegistry,
    Event,
)
from pystator.actions import ActionExecutor, ExecutionMode
from pystator import ParallelStateConfig


# =============================================================================
# Trading Context
# =============================================================================

def create_initial_context() -> dict[str, Any]:
    """Create initial trading context."""
    return {
        "daily_pnl": 0.0,
        "max_loss_threshold": -0.02,  # -2%
        "critical_loss_threshold": -0.03,  # -3%
        "account_value": 100_000.0,
        "buying_power": 50_000.0,
        "positions": {},
        "pending_orders": [],
        "signals_today": 0,
        "trades_today": 0,
        "data_status": "disconnected",
        "risk_level": "normal",
        "session_start": None,
    }


# =============================================================================
# Guard Functions
# =============================================================================

guards = GuardRegistry()


@guards.decorator("has_buying_power")
def has_buying_power(ctx: dict) -> bool:
    """Check if there's sufficient buying power for a trade."""
    required = ctx.get("order_value", 10_000)
    return ctx.get("buying_power", 0) >= required


@guards.decorator("risk_allows_entry")
def risk_allows_entry(ctx: dict) -> bool:
    """Check if current risk level allows new entries."""
    return ctx.get("risk_level", "normal") != "critical"


@guards.decorator("daily_pnl_below_threshold")
def daily_pnl_below_threshold(ctx: dict) -> bool:
    """Check if daily P&L has dropped below warning threshold."""
    pnl_pct = ctx.get("daily_pnl", 0) / ctx.get("account_value", 100_000)
    return pnl_pct < ctx.get("max_loss_threshold", -0.02)


@guards.decorator("daily_pnl_critical")
def daily_pnl_critical(ctx: dict) -> bool:
    """Check if daily P&L has reached critical level."""
    pnl_pct = ctx.get("daily_pnl", 0) / ctx.get("account_value", 100_000)
    return pnl_pct < ctx.get("critical_loss_threshold", -0.03)


@guards.decorator("daily_pnl_recovered")
def daily_pnl_recovered(ctx: dict) -> bool:
    """Check if daily P&L has recovered above threshold."""
    pnl_pct = ctx.get("daily_pnl", 0) / ctx.get("account_value", 100_000)
    return pnl_pct >= ctx.get("max_loss_threshold", -0.02) * 0.5


@guards.decorator("daily_pnl_improved")
def daily_pnl_improved(ctx: dict) -> bool:
    """Check if daily P&L has improved from critical."""
    pnl_pct = ctx.get("daily_pnl", 0) / ctx.get("account_value", 100_000)
    return pnl_pct >= ctx.get("critical_loss_threshold", -0.03) * 0.8


# =============================================================================
# Action Functions
# =============================================================================

actions = ActionRegistry()


@actions.decorator("initialize_session")
def initialize_session(ctx: dict) -> None:
    """Initialize trading session."""
    ctx["session_start"] = datetime.now(timezone.utc)
    print(f"Session initialized at {ctx['session_start']}")


@actions.decorator("load_watchlist")
def load_watchlist(ctx: dict) -> None:
    """Load trading watchlist."""
    ctx["watchlist"] = ["AAPL", "GOOGL", "MSFT", "AMZN", "NVDA"]
    print(f"Loaded watchlist: {ctx['watchlist']}")


@actions.decorator("check_account_status")
def check_account_status(ctx: dict) -> None:
    """Check account status and buying power."""
    print(f"Account value: ${ctx['account_value']:,.2f}")
    print(f"Buying power: ${ctx['buying_power']:,.2f}")


@actions.decorator("log_market_open")
def log_market_open(ctx: dict) -> None:
    """Log market open."""
    print("=== MARKET OPEN ===")


@actions.decorator("log_market_close")
def log_market_close(ctx: dict) -> None:
    """Log market close."""
    print("=== MARKET CLOSE ===")


@actions.decorator("start_scanners")
def start_scanners(ctx: dict) -> None:
    """Start market scanners."""
    print("Scanners started - looking for opportunities")


@actions.decorator("reset_signal_queue")
def reset_signal_queue(ctx: dict) -> None:
    """Reset signal queue."""
    ctx["signal_queue"] = []


@actions.decorator("run_technical_analysis")
def run_technical_analysis(ctx: dict) -> None:
    """Run technical analysis on signal."""
    print(f"Running TA on signal: {ctx.get('current_signal', 'N/A')}")


@actions.decorator("check_fundamentals")
def check_fundamentals(ctx: dict) -> None:
    """Check fundamental data."""
    print("Checking fundamentals...")


@actions.decorator("prepare_order")
def prepare_order(ctx: dict) -> None:
    """Prepare order for execution."""
    ctx["order_ready"] = True
    print("Order prepared for execution")


@actions.decorator("check_buying_power")
def check_buying_power_action(ctx: dict) -> None:
    """Verify buying power before execution."""
    print(f"Verifying buying power: ${ctx['buying_power']:,.2f}")


@actions.decorator("log_execution_attempt")
def log_execution_attempt(ctx: dict) -> None:
    """Log execution attempt."""
    print("Execution attempt logged")


@actions.decorator("set_stop_loss")
def set_stop_loss(ctx: dict) -> None:
    """Set stop loss for position."""
    print("Stop loss set")


@actions.decorator("set_profit_target")
def set_profit_target(ctx: dict) -> None:
    """Set profit target for position."""
    print("Profit target set")


@actions.decorator("activate_trailing_stop")
def activate_trailing_stop(ctx: dict) -> None:
    """Activate trailing stop."""
    print("Trailing stop activated")


@actions.decorator("reset_risk_alerts")
def reset_risk_alerts(ctx: dict) -> None:
    """Reset risk alerts."""
    ctx["risk_level"] = "normal"
    print("Risk alerts reset - normal operations")


@actions.decorator("reduce_position_sizes")
def reduce_position_sizes(ctx: dict) -> None:
    """Reduce position sizes due to elevated risk."""
    ctx["max_position_size"] = ctx.get("max_position_size", 10000) * 0.5
    print(f"Position sizes reduced to ${ctx['max_position_size']:,.2f}")


@actions.decorator("alert_elevated_risk")
def alert_elevated_risk(ctx: dict) -> None:
    """Send elevated risk alert."""
    ctx["risk_level"] = "elevated"
    print("WARNING: Risk level ELEVATED")


@actions.decorator("halt_new_entries")
def halt_new_entries(ctx: dict) -> None:
    """Halt new trade entries."""
    ctx["entries_allowed"] = False
    print("ALERT: New entries HALTED")


@actions.decorator("alert_critical_risk")
def alert_critical_risk(ctx: dict) -> None:
    """Send critical risk alert."""
    ctx["risk_level"] = "critical"
    print("CRITICAL: Risk level CRITICAL - no new entries")


@actions.decorator("initiate_data_connection")
def initiate_data_connection(ctx: dict) -> None:
    """Initiate data feed connection."""
    print("Initiating data connection...")


@actions.decorator("subscribe_symbols")
def subscribe_symbols(ctx: dict) -> None:
    """Subscribe to market data symbols."""
    print(f"Subscribed to: {ctx.get('watchlist', [])}")


@actions.decorator("set_data_status_ok")
def set_data_status_ok(ctx: dict) -> None:
    """Set data status to OK."""
    ctx["data_status"] = "connected"
    print("Data feed: CONNECTED")


@actions.decorator("schedule_reconnect")
def schedule_reconnect(ctx: dict) -> None:
    """Schedule reconnection attempt."""
    print("Scheduling reconnection...")


@actions.decorator("set_data_status_warning")
def set_data_status_warning(ctx: dict) -> None:
    """Set data status to warning."""
    ctx["data_status"] = "reconnecting"
    print("Data feed: RECONNECTING")


@actions.decorator("alert_data_failure")
def alert_data_failure(ctx: dict) -> None:
    """Alert data feed failure."""
    ctx["data_status"] = "failed"
    print("ALERT: Data feed FAILED")


@actions.decorator("set_data_status_error")
def set_data_status_error(ctx: dict) -> None:
    """Set data status to error."""
    ctx["data_status"] = "failed"


@actions.decorator("clear_pending_orders")
def clear_pending_orders(ctx: dict) -> None:
    """Clear pending orders list."""
    ctx["pending_orders"] = []


@actions.decorator("start_fill_monitor")
def start_fill_monitor(ctx: dict) -> None:
    """Start monitoring for order fills."""
    print("Monitoring for fills...")


@actions.decorator("evaluate_partial_fill")
def evaluate_partial_fill(ctx: dict) -> None:
    """Evaluate partial fill."""
    print("Evaluating partial fill...")


@actions.decorator("update_position_partial")
def update_position_partial(ctx: dict) -> None:
    """Update position for partial fill."""
    print("Position updated for partial fill")


@actions.decorator("submit_cancellation")
def submit_cancellation(ctx: dict) -> None:
    """Submit order cancellation."""
    print("Submitting cancellation...")


@actions.decorator("log_signal")
def log_signal(ctx: dict) -> None:
    """Log detected signal."""
    ctx["signals_today"] = ctx.get("signals_today", 0) + 1
    print(f"Signal #{ctx['signals_today']} detected")


@actions.decorator("prepare_entry_order")
def prepare_entry_order(ctx: dict) -> None:
    """Prepare entry order."""
    print("Preparing entry order...")


@actions.decorator("log_rejection_reason")
def log_rejection_reason(ctx: dict) -> None:
    """Log signal rejection reason."""
    print(f"Signal rejected: {ctx.get('rejection_reason', 'criteria not met')}")


@actions.decorator("track_entry_time")
def track_entry_time(ctx: dict) -> None:
    """Track entry time."""
    ctx["entry_time"] = datetime.now(timezone.utc)
    print(f"Entry tracked at {ctx['entry_time']}")


@actions.decorator("record_trade_result")
def record_trade_result(ctx: dict) -> None:
    """Record trade result."""
    ctx["trades_today"] = ctx.get("trades_today", 0) + 1
    print(f"Trade #{ctx['trades_today']} completed")


@actions.decorator("update_daily_pnl")
def update_daily_pnl(ctx: dict) -> None:
    """Update daily P&L."""
    trade_pnl = ctx.get("last_trade_pnl", 0)
    ctx["daily_pnl"] = ctx.get("daily_pnl", 0) + trade_pnl
    print(f"Daily P&L: ${ctx['daily_pnl']:,.2f}")


@actions.decorator("flatten_all_positions")
def flatten_all_positions(ctx: dict) -> None:
    """Flatten all positions."""
    print("EMERGENCY: Flattening all positions!")
    ctx["positions"] = {}


@actions.decorator("cancel_all_orders")
def cancel_all_orders(ctx: dict) -> None:
    """Cancel all pending orders."""
    print("EMERGENCY: Cancelling all orders!")
    ctx["pending_orders"] = []


@actions.decorator("send_halt_notification")
def send_halt_notification(ctx: dict) -> None:
    """Send halt notification."""
    print("EMERGENCY: Trading HALTED - notification sent")


@actions.decorator("generate_daily_report")
def generate_daily_report(ctx: dict) -> None:
    """Generate daily report."""
    print("\n=== DAILY REPORT ===")
    print(f"Signals: {ctx.get('signals_today', 0)}")
    print(f"Trades: {ctx.get('trades_today', 0)}")
    print(f"Daily P&L: ${ctx.get('daily_pnl', 0):,.2f}")
    print("====================\n")


@actions.decorator("reconcile_positions")
def reconcile_positions(ctx: dict) -> None:
    """Reconcile positions."""
    print("Reconciling positions...")


@actions.decorator("calculate_pnl")
def calculate_pnl(ctx: dict) -> None:
    """Calculate final P&L."""
    print(f"Final daily P&L: ${ctx.get('daily_pnl', 0):,.2f}")


@actions.decorator("record_market_open_time")
def record_market_open_time(ctx: dict) -> None:
    """Record market open time."""
    ctx["market_open_time"] = datetime.now(timezone.utc)


@actions.decorator("record_market_close_time")
def record_market_close_time(ctx: dict) -> None:
    """Record market close time."""
    ctx["market_close_time"] = datetime.now(timezone.utc)


@actions.decorator("log_emergency_stop")
def log_emergency_stop(ctx: dict) -> None:
    """Log emergency stop."""
    print("EMERGENCY STOP TRIGGERED")


@actions.decorator("send_emergency_alert")
def send_emergency_alert(ctx: dict) -> None:
    """Send emergency alert."""
    print("Emergency alert sent to all channels")


@actions.decorator("reset_daily_stats")
def reset_daily_stats(ctx: dict) -> None:
    """Reset daily statistics."""
    ctx["daily_pnl"] = 0.0
    ctx["signals_today"] = 0
    ctx["trades_today"] = 0
    print("Daily stats reset for new session")


# Register remaining actions as no-ops for completeness
for action_name in [
    "log_risk_elevation", "log_critical_risk", "log_risk_normalized",
    "resume_reduced_trading", "log_connection_success", "log_connection_failure",
    "log_disconnection", "reset_retry_counter", "alert_permanent_failure",
    "record_order_submission", "update_fill_qty", "record_full_fill",
    "record_final_fill", "log_rejection", "notify_rejection",
    "log_cancel_request", "confirm_cancellation",
]:
    if action_name not in actions:
        actions.register(action_name, lambda ctx, name=action_name: print(f"Action: {name}"))


# =============================================================================
# Example Usage
# =============================================================================

async def run_trading_simulation():
    """Run a simulated trading day."""
    
    # Load FSM
    machine = StateMachine.from_yaml("examples/day_trading_fsm.yaml")
    machine.bind_guards(guards)
    
    # Create executor with phased parallel execution
    executor = ActionExecutor(actions, default_mode=ExecutionMode.PHASED)
    
    # Initialize context
    context = create_initial_context()
    
    print("\n" + "="*60)
    print("Day Trading FSM Simulation")
    print("="*60 + "\n")
    
    # === Pre-Market Phase ===
    current_state = machine.get_initial_state().name
    print(f"Starting state: {current_state}")
    
    # Execute pre-market entry actions
    if current_state in machine.states:
        for action in machine.states[current_state].on_enter:
            actions.execute(action, context)
    
    # === Market Open ===
    print("\n--- Market Opening ---")
    result = machine.process(current_state, "market_open", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")
    
    # === Active Trading Phase ===
    # Now we're in a parallel state, so we need to track multiple regions
    parallel_config = machine.enter_parallel_state("active")
    print(f"\nParallel state config: {parallel_config.to_string()}")
    print(f"Active states: {parallel_config.get_all_active()}")
    
    # Execute entry actions for parallel state and region states
    enter_actions = machine.get_parallel_enter_actions("active")
    for action in enter_actions:
        actions.execute(action, context)
    
    # === Simulate Trading Day Events ===
    
    # 1. Data feed connects
    print("\n--- Data Feed Connecting ---")
    parallel_config, results = machine.process_parallel(
        parallel_config, "connection_established", context
    )
    for r in results:
        await executor.async_execute_with_mode(r, context)
    print(f"Data feed region: {parallel_config.get_region_state('data_feed')}")
    
    # 2. Signal detected
    print("\n--- Signal Detected ---")
    context["current_signal"] = {"symbol": "AAPL", "direction": "long"}
    parallel_config, results = machine.process_parallel(
        parallel_config, "signal_detected", context
    )
    for r in results:
        await executor.async_execute_with_mode(r, context)
    print(f"Trading region: {parallel_config.get_region_state('trading')}")
    
    # 3. Signal confirmed (with guards)
    print("\n--- Confirming Signal ---")
    context["order_value"] = 5000  # Under buying power
    parallel_config, results = machine.process_parallel(
        parallel_config, "signal_confirmed", context
    )
    for r in results:
        await executor.async_execute_with_mode(r, context)
    print(f"Trading region: {parallel_config.get_region_state('trading')}")
    
    # 4. Order submitted
    print("\n--- Order Submitted ---")
    parallel_config, results = machine.process_parallel(
        parallel_config, "order_placed", context
    )
    for r in results:
        await executor.async_execute_with_mode(r, context)
    print(f"Order manager region: {parallel_config.get_region_state('order_manager')}")
    
    # 5. Order filled - back to managing
    print("\n--- Order Filled ---")
    parallel_config, results = machine.process_parallel(
        parallel_config, "order_filled", context
    )
    for r in results:
        await executor.async_execute_with_mode(r, context)
    print(f"Order manager region: {parallel_config.get_region_state('order_manager')}")
    
    # 6. Simulate P&L loss triggering risk warning
    print("\n--- Risk Event (P&L Loss) ---")
    context["daily_pnl"] = -2500  # -2.5% loss
    parallel_config, results = machine.process_parallel(
        parallel_config, "risk_warning", context
    )
    for r in results:
        await executor.async_execute_with_mode(r, context)
    print(f"Risk monitor region: {parallel_config.get_region_state('risk_monitor')}")
    
    # 7. Position closed
    print("\n--- Position Closed ---")
    context["last_trade_pnl"] = 500  # Recovered some
    parallel_config, results = machine.process_parallel(
        parallel_config, "position_closed", context
    )
    for r in results:
        await executor.async_execute_with_mode(r, context)
    print(f"Trading region: {parallel_config.get_region_state('trading')}")
    
    # Print final parallel state
    print("\n" + "-"*40)
    print("Final Parallel State Configuration:")
    print(f"  Parallel state: {parallel_config.parallel_state}")
    for region, state in parallel_config.region_states.items():
        print(f"  {region}: {state}")
    print("-"*40)
    
    # === Market Close ===
    print("\n--- Market Closing ---")
    
    # Get exit actions from parallel state
    exit_actions = machine.get_parallel_exit_actions(parallel_config)
    for action in exit_actions:
        actions.execute(action, context)
    
    # Transition to post_market
    result = machine.process("active", "market_close", context)
    if result.success:
        current_state = result.target_state
        await executor.async_execute_with_mode(result, context)
        print(f"Transitioned to: {current_state}")
    
    print("\n" + "="*60)
    print("Trading Day Complete")
    print("="*60)


def main():
    """Main entry point."""
    import os
    
    # Change to project root for relative paths
    script_dir = os.path.dirname(os.path.abspath(__file__))
    project_root = os.path.dirname(script_dir)
    os.chdir(project_root)
    
    asyncio.run(run_trading_simulation())


if __name__ == "__main__":
    main()
