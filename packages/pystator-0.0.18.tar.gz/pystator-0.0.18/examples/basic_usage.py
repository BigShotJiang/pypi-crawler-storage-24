"""Basic usage example for PyStator.

This example demonstrates the core concepts of PyStator:
1. Loading a state machine from YAML
2. Registering guards (business logic conditions)
3. Processing events (computing transitions)
4. Executing actions (side effects)
"""

from __future__ import annotations

from pathlib import Path

from pystator import (
    StateMachine,
    GuardRegistry,
    ActionRegistry,
    Event,
)
from pystator import ActionExecutor


def main() -> None:
    # =========================================================================
    # 1. Load the State Machine Definition
    # =========================================================================
    config_path = Path(__file__).parent / "order_fsm.yaml"
    machine = StateMachine.from_yaml(config_path)

    print(f"Loaded state machine: {machine.name} v{machine.version}")
    print(f"States: {machine.state_names}")
    print(f"Initial state: {machine.get_initial_state().name}")
    print()

    # =========================================================================
    # 2. Register Guards (Business Logic)
    # =========================================================================
    # Guards are pure functions that determine if a transition is allowed
    guards = GuardRegistry()

    guards.register(
        "is_full_fill",
        lambda ctx: ctx.get("fill_qty", 0) >= ctx.get("order_qty", 1),
    )

    guards.register(
        "is_partial_fill",
        lambda ctx: 0 < ctx.get("fill_qty", 0) < ctx.get("order_qty", 1),
    )

    guards.register(
        "is_cancellable",
        lambda ctx: not ctx.get("in_flight", False),
    )

    # Bind guards to the machine
    machine.bind_guards(guards)

    # =========================================================================
    # 3. Register Actions (Side Effects)
    # =========================================================================
    # Actions are executed AFTER state changes are persisted
    actions = ActionRegistry()

    actions.register("update_order_id", lambda ctx: print(f"  -> Updated order ID"))
    actions.register("notify_ui_open", lambda ctx: print(f"  -> UI notified: order open"))
    actions.register("log_audit_trail", lambda ctx: print(f"  -> Audit logged"))
    actions.register("update_positions", lambda ctx: print(f"  -> Positions updated"))
    actions.register(
        "release_buying_power", lambda ctx: print(f"  -> Buying power released")
    )
    actions.register(
        "decrement_remaining_qty", lambda ctx: print(f"  -> Remaining qty decremented")
    )
    actions.register(
        "record_rejection_reason",
        lambda ctx: print(f"  -> Rejection recorded: {ctx.get('reason', 'unknown')}"),
    )
    actions.register(
        "send_cancel_to_exchange", lambda ctx: print(f"  -> Cancel sent to exchange")
    )

    executor = ActionExecutor(actions, log_execution=False)

    # =========================================================================
    # 4. Simulate Order Lifecycle
    # =========================================================================
    print("=" * 60)
    print("Simulating Order Lifecycle")
    print("=" * 60)

    # In a real application, this would come from your database
    order = {
        "id": "ORD-001",
        "state": "PENDING_NEW",
        "order_qty": 100,
    }

    def process_event(trigger: str, extra_context: dict | None = None) -> None:
        """Helper to process an event and execute actions."""
        ctx = {**order, **(extra_context or {})}

        print(f"\n[{order['state']}] Processing event: {trigger}")

        result = machine.process(order["state"], trigger, ctx)

        if result.success:
            print(f"  Transition: {result.source_state} -> {result.target_state}")

            # In real app: persist state change to database here
            order["state"] = result.target_state or order["state"]

            # Execute actions (after DB commit would succeed)
            if result.all_actions:
                print(f"  Executing {len(result.all_actions)} action(s):")
                executor.execute(result, ctx)
        else:
            print(f"  Transition FAILED: {result.error}")

    # Step 1: Exchange acknowledges the order
    process_event("exchange_ack")

    # Step 2: Partial fill (50 of 100 shares)
    process_event("execution_report", {"fill_qty": 50})

    # Step 3: Full fill (remaining 50 shares)
    process_event("execution_report", {"fill_qty": 100})

    # Step 4: Try to cancel (should fail - order is already filled)
    process_event("cancel_request", {"in_flight": False})

    print("\n" + "=" * 60)
    print(f"Final order state: {order['state']}")
    print("=" * 60)


if __name__ == "__main__":
    main()
