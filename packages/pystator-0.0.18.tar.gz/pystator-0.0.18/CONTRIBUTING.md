# Contributing

## Setup

```bash
git clone https://github.com/optophi/pystator
cd pystator
python -m venv .venv
source .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -e ".[dev]"
```

4. **Install pre-commit so Black and isort run on every commit (recommended)**

```bash
pre-commit install
```

Without this step, formatting hooks will not run when you commit, and CI may fail with "would reformat" or isort errors.

## Checks before commit

CI runs Black and isort on `src/pystator` and `tests`. Match that locally:

```bash
# Format (fixes style and import order)
make format
# or:
black --config pyproject.toml src/pystator tests
isort --settings-path pyproject.toml src/pystator tests

# Lint (check only, same as CI)
make lint
# or:
black --check --config pyproject.toml src/pystator tests
isort --check --settings-path pyproject.toml src/pystator tests
```

Then run:

- `mypy src/`
- `pytest`

## Documentation (single source of truth)

- **Python API**: MkDocs + mkdocstrings pull from docstrings in `src/pystator`. Edit docstrings and the content under `docs/` (e.g. `docs/api/*.md`). Build or serve with `pystator docs build` or `pystator docs serve` (default port 5004). Do not duplicate API reference in the UI.
- **REST API**: FastAPI route `summary`/`description` and Pydantic models are the source of truth. Swagger UI at `/docs` and the in-app **API Playground** both use the OpenAPI schema. The playground fetches route list from `GET /api/v1/docs/playground-routes`; do not maintain a separate list in the frontend.
- **UI Documentation page**: Keep it as a thin API Playground plus links to the full docs site and Swagger. Override docs URL via `NEXT_PUBLIC_DOCS_URL` if needed.

## Releasing

1. Update `version` in `pyproject.toml` and add an entry in `CHANGELOG.md`.
2. Commit and push.
3. Create and push a tag: `git tag v0.1.0 && git push origin v0.1.0`.
4. On PyPI, configure [Trusted Publishing](https://docs.pypi.org/trusted-publishers/) for this repository so the GitHub Action can publish without storing tokens.
