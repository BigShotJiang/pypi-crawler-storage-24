# PyStator Documentation

PyStator is a configuration-driven, stateless finite state machine library for Python. Define behavior in YAML or JSON; compute transitions from (current state + event + context); run guards and actions. Optional **REST API**, **worker queue**, and **UI** use the same model.

## Documentation map

| Section | Description |
|---------|-------------|
| [Getting started](getting-started/quickstart.md) | Install, first FSM, `process()`, EntitySession, API pointers |
| [Concepts](guides/concepts.md) | States, transitions, guards, actions, Orchestrator, hierarchical and parallel |
| [Naming rules](reference/fsm-config.md#naming-rules) | Valid identifiers for states, triggers, guards, actions |
| [Package structure](guides/package-structure.md) | Core vs extras (`[api]`, `[worker]`, `[ui]`, `[all]`, …) |
| [Declarative features](guides/declarative-features.md) | YAML `check:` / effects, builtins, sinks, lint, `StateMachineBuilder` |
| [Architecture](guides/architecture.md) | Design goals, sandwich pattern, components |
| [Schedulers](guides/schedulers.md) | Delayed transitions (`after`), Asyncio / Redis / Celery |
| [Configuration](guides/configuration.md) | `pystator.cfg`, environment, database |
| [Worker](guides/worker.md) | `pystator worker`, `submit_event`, `worker_events`, scaling |
| [State stores](guides/state-stores.md) | In-memory, Postgres, Redis, MongoDB, custom |
| [Tutorials](tutorials/index.md) | Order workflow, API & UI |
| [Examples](examples.md) | Runnable examples |
| [Reference](reference/index.md) | FSM config schema |
| [API reference](api.md) | Condensed Python API; generated pages under `api/` |

## Quick links

- **I want to run something in 2 minutes** → [README Quick start](../README.md#quick-start-2-minutes) or [Getting started](getting-started/quickstart.md)
- **I want to understand states and transitions** → [Concepts](guides/concepts.md)
- **I want to know what's core vs optional** → [Package structure](guides/package-structure.md)
- **I want to understand how to run / scale** → [Concepts: Running a machine](guides/concepts.md#running-a-machine-three-ways), [Schedulers](guides/schedulers.md)
- **I want a continuous service that processes events from a queue** → [Worker](guides/worker.md)
- **I want to build an order workflow** → [Tutorial: Order workflow](tutorials/order-workflow.md)
- **I want to use the REST API and UI** → [Tutorial: API and UI](tutorials/api-and-ui.md)
- **I want to see full code examples** → [Examples](examples.md) and [examples/](../examples/) directory
- **I want valid names for states and triggers** → [Naming rules](reference/fsm-config.md#naming-rules)
- **I want the full YAML/config schema** → [FSM configuration reference](reference/fsm-config.md)
- **I want to understand design and architecture** → [Architecture](guides/architecture.md)

## Prerequisites

- Python 3.11+
- Core: `pip install pystator`
- REST API: `pip install pystator[api]` (+ `[postgres]` for PostgreSQL URLs)
- Worker + `submit_event`: `pip install pystator[worker]` and a database (`PYSTATOR_DATABASE_URL`)
- Inline guard expressions (`expr:`): `pip install pystator[recipes]`
- Local docs site: `pip install pystator[docs]` then `pystator docs serve`
