# Examples

Runnable examples that ship with PyStator, with short descriptions and how to run them.

## Where they live

All examples are in the **`examples/`** directory at the project root. Each example pairs a **YAML** FSM with a **Python** script that loads it, registers guards/actions, and processes events.

## Example list

| Example | YAML | Python | Description |
|---------|------|--------|-------------|
| **Order lifecycle** | `order_fsm.yaml` | `basic_usage.py` | Order management: `pending_new` → `open` → `partially_filled` / `filled` / `rejected` / `canceled`. Guards (full/partial fill, cancellable), actions (notify, audit, positions). |
| **Day trading** | `day_trading_fsm.yaml` | `day_trading_example.py` | Parallel states: trading region + risk monitor + data feed. Shows `enter_parallel_state`, `process_parallel`, region-scoped transitions. |
| **Portfolio optimization** | `portfolio_optimization_fsm.yaml` | `portfolio_optimization_example.py` | Hierarchical states and workflow; compound states with parent/child and LCA exit/enter. |

## How to run

From the **project root** (so that `examples/` and paths inside scripts resolve):

```bash
# Order lifecycle (most straightforward)
python examples/basic_usage.py

# Day trading (parallel regions)
python examples/day_trading_example.py

# Portfolio optimization (hierarchical)
python examples/portfolio_optimization_example.py
```

Or from inside `examples/`:

```bash
cd examples
python basic_usage.py
# etc.
```

Scripts that use `Path(__file__).parent` for YAML paths will work from either location.

## Data and templates

- **`data/`** — Sample FSM YAMLs and review/limits docs (e.g. `order_management_fsm.yaml`, `day_trading_system_fsm.yaml`).
- **`data/templates/fsm/`** — Template YAMLs (blank, order_management, day_trading, portfolio_optimization, rebalance_workflow) for use in the API/UI or as starters.

## Learning path

1. **basic_usage.py** — Start here: one FSM, guards, actions, linear flow.
2. **day_trading_example.py** — Parallel regions and multiple active sub-states.
3. **portfolio_optimization_example.py** — Hierarchical states and compound state behavior.

For step-by-step narrative, see the [Order workflow tutorial](tutorials/order-workflow.md) and [Concepts](guides/concepts.md).
