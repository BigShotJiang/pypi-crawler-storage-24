# Visualization API

Generate Mermaid, Graphviz DOT, or SCXML diagrams from a `StateMachine` definition.

See [Visualization guide](../guides/visualization.md) for the full guide with examples.

## Functions

::: pystator.visualization.to_mermaid
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.visualization.to_mermaid_flowchart
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.visualization.to_dot
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.visualization.to_scxml
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.visualization.get_statistics
    options:
      show_root_heading: true
      heading_level: 3

## Import

```python
from pystator.visualization import (
    to_mermaid,
    to_mermaid_flowchart,
    to_dot,
    to_scxml,
    get_statistics,
)
```

## See also

- [Visualization guide](../guides/visualization.md)
- [Linting](lint.md)
