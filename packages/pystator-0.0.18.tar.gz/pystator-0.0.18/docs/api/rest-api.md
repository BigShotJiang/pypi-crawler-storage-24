# REST API

The PyStator REST API is documented and tryable in two places:

- **Swagger UI** — When the API is running, open `/docs` (e.g. `http://localhost:8004/docs`) for interactive request/response documentation and "Try it out" for every endpoint.
- **In-app API Playground** — From the PyStator UI, open the **API Playground** (Documentation) page to call endpoints with a minimal request body editor.

Both use the same OpenAPI schema; Swagger is the single source of truth for endpoint paths, methods, request bodies, and responses.

## Running the API

Start the API server:

```bash
pystator api
```

Or with uvicorn:

```bash
uvicorn pystator.api.main:app --host 0.0.0.0 --port 8004
```

Then open [http://localhost:8004/docs](http://localhost:8004/docs) for the full REST API reference.
