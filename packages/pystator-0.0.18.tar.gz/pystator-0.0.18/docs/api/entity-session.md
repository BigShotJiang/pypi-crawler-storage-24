# EntitySession API

Stateful per-entity FSM wrapper. Tracks current state, context, and history for a single entity.

See [EntitySession guide](../guides/entity-session.md) for the full guide.

## Classes

::: pystator.instance.EntitySession
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.instance.EventRecorder
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.instance.RecordedEvent
    options:
      show_root_heading: true
      heading_level: 3

## Import

```python
# Recommended — via StateMachine factory
from pystator import StateMachine

machine = StateMachine.from_yaml("fsm.yaml")
session = machine.create(context={"id": "entity-1"})

# Direct import
from pystator import EntitySession
from pystator.instance import EntitySession, EventRecorder, RecordedEvent
```

## Auto-generated methods and properties

`EntitySession` dynamically generates, for each state machine definition:

- **`is_<state_name>`** — boolean property; `True` when the current state matches
- **`<trigger_name>(**payload)`** — sends the named trigger (equivalent to `.send(trigger, **payload)`)

YAML **state** and **trigger** names must already be valid lowercase identifiers (`a–z`, digits, underscores). `EntitySession` exposes them as:
- `is_<state>` — e.g. state `pending_new` → `is_pending_new`
- `<trigger>(**payload)` — e.g. trigger `exchange_ack` → `exchange_ack()`

## See also

- [EntitySession guide](../guides/entity-session.md)
- [Orchestrator](orchestrator.md) — multi-entity session management with persistence
- [Stores](stores.md)
