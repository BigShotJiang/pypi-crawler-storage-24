# API Reference

Complete reference documentation for PyStator's Python API. The following pages pull from the library docstrings (single source of truth).

## Module overview

```
pystator
├── StateMachine, StateMachineBuilder   # FSM definition and processing
├── EntitySession, EventRecorder        # Stateful instance (create, send, snapshot)
├── GuardRegistry, ActionRegistry       # Guards and actions
├── ActionExecutor                      # Run actions (sync/async, phased)
├── Orchestrator                        # Delayed transitions, state store
├── stores/                             # InMemory, SQLite, Postgres, MongoDB, Redis
├── hooks/                              # Transition hooks, MetricsCollector, LoggingHook
├── visualization/                      # to_mermaid, to_dot, to_scxml, get_statistics
├── context/                            # TransitionContext, ContextValidatorFn
├── sinks/                              # EventSink, MetricSink, configure helpers
├── errors/                             # FSMError and subclasses
└── lint                                # lint() for static analysis
```

## Quick links

| Topic | Description |
|-------|-------------|
| [State Machine](state-machine.md) | `StateMachine`, `from_yaml`, `from_dict`, `process`, `aprocess`, parallel states |
| [EntitySession](entity-session.md) | `EntitySession`, `EventRecorder`, snapshots, deferred events |
| [Guards](guards.md) | `GuardRegistry`, builtins (`equals`, `greater_than`, `in_list`, `all_of`, `any_of`) |
| [Actions](actions.md) | `ActionRegistry`, `ActionExecutor`, execution modes |
| [Orchestrator](orchestrator.md) | State store, delayed transitions, context validator |
| [Stores](stores.md) | `StateStoreClient`, `InMemoryStateStore`, `SQLiteStateStore`, `PostgresStateStore`, etc. |
| [Hooks](hooks.md) | `TransitionHook`, `LoggingHook`, `MetricsCollector` |
| [Visualization](visualization.md) | `to_mermaid`, `to_dot`, `to_scxml`, `get_statistics` |
| [Context & Sinks](context.md) | `TransitionContext`, `EventSink`, `MetricSink` |
| [Lint](lint.md) | `lint()`, `LintWarning`, `LintSeverity` — static analysis |
| [Errors](errors.md) | `FSMError`, `ConfigurationError`, `InvalidTransitionError`, and others |
| [REST API](rest-api.md) | Swagger and in-app API Playground |

## Import patterns

```python
# Core
from pystator import StateMachine, EntitySession, Orchestrator

# Guards and actions
from pystator import GuardRegistry, ActionRegistry, ActionExecutor

# Stores
from pystator import InMemoryStateStore, SQLiteStateStore, PostgresStateStore

# Errors
from pystator import FSMError, InvalidTransitionError, GuardRejectedError

# Lint and visualization
from pystator import lint, LintWarning
from pystator.visualization import to_mermaid, to_dot, get_statistics

# Hooks
from pystator.hooks import LoggingHook, MetricsCollector

# Context and sinks
from pystator.context import TransitionContext
from pystator.sinks import configure_event_sink, configure_metric_sink

# EventRecorder
from pystator.instance import EventRecorder, RecordedEvent
```
