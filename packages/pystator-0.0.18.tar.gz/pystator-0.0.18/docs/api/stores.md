# State Stores

Abstract interface and implementations for persisting entity state.

::: pystator.stores.base.StateStoreClient

::: pystator.stores.base.InMemoryStateStore

Other backends (`SQLiteStateStore`, `PostgresStateStore`, `MongoDBStateStore`, `RedisStateStore`) are available from `pystator.stores` when the corresponding optional dependencies are installed. See the [package structure](../guides/package-structure.md) and [state stores](../guides/state-stores.md) guide.
