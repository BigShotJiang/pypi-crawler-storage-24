# State Machine

Core FSM class: load config from YAML or dict, process transitions, and run guards and actions.

::: pystator.machine.StateMachine

::: pystator.machine.StateMachineBuilder
