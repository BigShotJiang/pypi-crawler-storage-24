# Guards

Register and evaluate guards used in transitions.

::: pystator.guards.GuardRegistry

::: pystator.guards.GuardEvaluator

Built-in guard helpers:

::: pystator.guards.equals
::: pystator.guards.greater_than
::: pystator.guards.in_list
::: pystator.guards.all_of
::: pystator.guards.any_of
::: pystator.guards.negate
