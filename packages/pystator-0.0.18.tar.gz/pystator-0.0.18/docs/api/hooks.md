# Hooks and Metrics API

Observe the transition lifecycle and collect metrics without modifying guards or actions.

See [Hooks and Metrics guide](../guides/hooks-and-metrics.md) for the full guide.

## Protocol

::: pystator.hooks.TransitionHook
    options:
      show_root_heading: true
      heading_level: 3

## Data classes

::: pystator.hooks.TransitionMetrics
    options:
      show_root_heading: true
      heading_level: 3

## Built-in hooks

::: pystator.hooks.LoggingHook
    options:
      show_root_heading: true
      heading_level: 3

::: pystator.hooks.MetricsCollector
    options:
      show_root_heading: true
      heading_level: 3

## Observer

::: pystator.hooks.TransitionObserver
    options:
      show_root_heading: true
      heading_level: 3

## Import

```python
from pystator.hooks import (
    TransitionHook,
    TransitionMetrics,
    LoggingHook,
    MetricsCollector,
    TransitionObserver,
)
```

## See also

- [Hooks and Metrics guide](../guides/hooks-and-metrics.md)
- [Orchestrator](orchestrator.md) — `hooks` parameter
