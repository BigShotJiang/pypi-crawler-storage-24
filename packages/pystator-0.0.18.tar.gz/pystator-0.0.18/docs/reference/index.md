# Reference

Reference documentation for PyStator.

| Document | Description |
|----------|-------------|
| [FSM configuration (YAML/JSON)](fsm-config.md) | Full schema for state machine definitions: `meta`, `states`, `transitions`, `error_policy`, and validation rules. |

For API (classes and methods), see the [API reference](../api.md). For design and architecture, see [Architecture](../guides/architecture.md).
