"""PyStator test suite."""
