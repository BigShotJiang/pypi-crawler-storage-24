"""Unit tests for submachine composition."""

from __future__ import annotations

import json
from pathlib import Path

import pytest

from pystator.config._submachine import (
    _find_initial,
    _flatten_submachine,
    resolve_submachines,
)

# ---------------------------------------------------------------------------
# SubMachine resolver
# ---------------------------------------------------------------------------


class TestSubmachineResolver:
    """Tests for resolve_submachines()."""

    def test_inline_submachine(self) -> None:
        """Inline submachine dict is resolved."""
        config = {
            "states": [
                {"name": "init", "type": "initial"},
                {
                    "name": "checkout",
                    "type": "stable",
                    "submachine": {
                        "states": [
                            {"name": "selecting", "type": "initial"},
                            {"name": "processing", "type": "stable"},
                            {"name": "done", "type": "terminal"},
                        ],
                        "transitions": [
                            {
                                "trigger": "SELECT",
                                "source": "selecting",
                                "dest": "processing",
                            },
                            {
                                "trigger": "COMPLETE",
                                "source": "processing",
                                "dest": "done",
                            },
                        ],
                    },
                },
                {"name": "complete", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "START", "source": "init", "dest": "checkout"},
                {"trigger": "FINISH", "source": "checkout", "dest": "complete"},
            ],
        }

        result = resolve_submachines(config)
        state_names = [s["name"] for s in result["states"]]

        # Parent state is kept
        assert "checkout" in state_names
        # Child states are prefixed
        assert "checkout.selecting" in state_names
        assert "checkout.processing" in state_names
        assert "checkout.done" in state_names

        # Parent gets initial_child
        checkout = next(s for s in result["states"] if s["name"] == "checkout")
        assert checkout["initial_child"] == "checkout.selecting"

        # Child states have parent set
        selecting = next(
            s for s in result["states"] if s["name"] == "checkout.selecting"
        )
        assert selecting["parent"] == "checkout"

        # Transitions are prefixed
        sub_transitions = [
            t
            for t in result["transitions"]
            if t.get("trigger") in ("SELECT", "COMPLETE")
        ]
        assert len(sub_transitions) == 2
        select = next(t for t in sub_transitions if t["trigger"] == "SELECT")
        assert select["source"] == "checkout.selecting"
        assert select["dest"] == "checkout.processing"

    def test_file_ref_submachine(self, tmp_path: Path) -> None:
        """File reference submachine is loaded and resolved."""
        sub_file = tmp_path / "checkout_flow.yaml"
        sub_file.write_text("""
states:
  - name: selecting
    type: initial
  - name: processing
    type: stable
  - name: done
    type: terminal
transitions:
  - trigger: SELECT
    source: selecting
    dest: processing
  - trigger: COMPLETE
    source: processing
    dest: done
""")

        config = {
            "states": [
                {"name": "init", "type": "initial"},
                {
                    "name": "checkout",
                    "type": "stable",
                    "submachine": "checkout_flow.yaml",
                },
                {"name": "complete", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "START", "source": "init", "dest": "checkout"},
            ],
        }

        result = resolve_submachines(config, base_path=tmp_path)
        state_names = [s["name"] for s in result["states"]]
        assert "checkout.selecting" in state_names
        assert "checkout.processing" in state_names

    def test_json_file_submachine(self, tmp_path: Path) -> None:
        """JSON file reference works."""
        sub_file = tmp_path / "flow.json"
        sub_config = {
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "GO", "source": "a", "dest": "b"},
            ],
        }
        sub_file.write_text(json.dumps(sub_config))

        config = {
            "states": [
                {"name": "init", "type": "initial"},
                {"name": "flow", "type": "stable", "submachine": "flow.json"},
            ],
            "transitions": [],
        }

        result = resolve_submachines(config, base_path=tmp_path)
        state_names = [s["name"] for s in result["states"]]
        assert "flow.a" in state_names
        assert "flow.b" in state_names

    def test_missing_file_raises(self) -> None:
        """Missing submachine file raises ValueError."""
        config = {
            "states": [
                {"name": "x", "type": "stable", "submachine": "nonexistent.yaml"},
            ],
            "transitions": [],
        }
        with pytest.raises(ValueError, match="not found"):
            resolve_submachines(config, base_path=Path("/tmp"))

    def test_no_initial_in_submachine(self) -> None:
        """Submachine without initial state still resolves (no initial_child)."""
        config = {
            "states": [
                {
                    "name": "flow",
                    "type": "stable",
                    "submachine": {
                        "states": [
                            {"name": "a", "type": "stable"},
                            {"name": "b", "type": "stable"},
                        ],
                        "transitions": [],
                    },
                },
            ],
            "transitions": [],
        }

        result = resolve_submachines(config)
        flow = next(s for s in result["states"] if s["name"] == "flow")
        assert "initial_child" not in flow or flow.get("initial_child") is None

    def test_no_submachine_passthrough(self) -> None:
        """Config without submachines is unchanged."""
        config = {
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "GO", "source": "a", "dest": "b"}],
        }

        result = resolve_submachines(config)
        assert len(result["states"]) == 2
        assert result["transitions"][0]["trigger"] == "GO"

    def test_circular_ref_detected(self) -> None:
        """Deep nesting exceeding max depth raises."""

        # Build a config that nests submachines very deeply
        def _make_nested(depth: int) -> dict:
            if depth <= 0:
                return {
                    "states": [{"name": "leaf", "type": "stable"}],
                    "transitions": [],
                }
            return {
                "states": [
                    {
                        "name": f"level{depth}",
                        "type": "stable",
                        "submachine": _make_nested(depth - 1),
                    }
                ],
                "transitions": [],
            }

        config = _make_nested(15)  # Exceeds _MAX_DEPTH=10
        with pytest.raises(ValueError, match="nesting depth"):
            resolve_submachines(config)


# ---------------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------------


class TestSubmachineHelpers:
    """Tests for internal helper functions."""

    def test_find_initial(self) -> None:
        """Find initial state name."""
        config = {
            "states": [
                {"name": "idle", "type": "initial"},
                {"name": "active", "type": "stable"},
            ]
        }
        assert _find_initial(config) == "idle"

    def test_find_initial_none(self) -> None:
        """No initial state returns None."""
        config = {"states": [{"name": "a", "type": "stable"}]}
        assert _find_initial(config) is None

    def test_flatten_prefixes_names(self) -> None:
        """flatten_submachine prefixes state and transition names."""
        sub_config = {
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "stable"},
            ],
            "transitions": [
                {"trigger": "GO", "source": "a", "dest": "b"},
            ],
        }

        states, transitions = _flatten_submachine("parent", sub_config)
        assert states[0]["name"] == "parent.a"
        assert states[1]["name"] == "parent.b"
        assert states[0]["parent"] == "parent"
        assert transitions[0]["source"] == "parent.a"
        assert transitions[0]["dest"] == "parent.b"

    def test_flatten_multi_source(self) -> None:
        """Multi-source transitions are prefixed."""
        sub_config = {
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "stable"},
                {"name": "c", "type": "stable"},
            ],
            "transitions": [
                {"trigger": "GO", "source": ["a", "b"], "dest": "c"},
            ],
        }

        states, transitions = _flatten_submachine("p", sub_config)
        assert transitions[0]["source"] == ["p.a", "p.b"]


# ---------------------------------------------------------------------------
# End-to-end with raw parser
# ---------------------------------------------------------------------------


class TestSubmachineE2E:
    """End-to-end tests through the config parser."""

    def test_inline_through_raw_parser(self) -> None:
        """Inline submachine parsed through ConfigLoader."""
        from pystator.config.loader import ConfigLoader

        config = {
            "states": [
                {"name": "init", "type": "initial"},
                {
                    "name": "flow",
                    "type": "stable",
                    "submachine": {
                        "states": [
                            {"name": "step1", "type": "initial"},
                            {"name": "step2", "type": "stable"},
                            {"name": "end", "type": "terminal"},
                        ],
                        "transitions": [
                            {"trigger": "NEXT", "source": "step1", "dest": "step2"},
                            {"trigger": "DONE", "source": "step2", "dest": "end"},
                        ],
                    },
                },
                {"name": "complete", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "START", "source": "init", "dest": "flow"},
                {"trigger": "FINISH", "source": "flow", "dest": "complete"},
            ],
        }

        loader = ConfigLoader(validate=False)
        loaded = loader.load_dict(config)
        state_names = [s["name"] for s in loaded["states"]]

        assert "flow.step1" in state_names
        assert "flow.step2" in state_names
        assert "flow.end" in state_names

    def test_multiple_submachines(self) -> None:
        """Multiple states with submachines in same config."""
        config = {
            "states": [
                {"name": "init", "type": "initial"},
                {
                    "name": "alpha",
                    "type": "stable",
                    "submachine": {
                        "states": [
                            {"name": "a1", "type": "initial"},
                            {"name": "a2", "type": "stable"},
                        ],
                        "transitions": [
                            {"trigger": "GO_A", "source": "a1", "dest": "a2"}
                        ],
                    },
                },
                {
                    "name": "beta",
                    "type": "stable",
                    "submachine": {
                        "states": [
                            {"name": "b1", "type": "initial"},
                            {"name": "b2", "type": "stable"},
                        ],
                        "transitions": [
                            {"trigger": "GO_B", "source": "b1", "dest": "b2"}
                        ],
                    },
                },
            ],
            "transitions": [],
        }

        result = resolve_submachines(config)
        state_names = [s["name"] for s in result["states"]]

        assert "alpha.a1" in state_names
        assert "alpha.a2" in state_names
        assert "beta.b1" in state_names
        assert "beta.b2" in state_names

        # No name collisions
        assert len(state_names) == len(set(state_names))
