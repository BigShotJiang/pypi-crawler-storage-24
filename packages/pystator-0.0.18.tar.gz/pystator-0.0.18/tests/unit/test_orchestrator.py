"""Unit tests for Orchestrator and state store."""

from __future__ import annotations

import pytest

from pystator import (
    ActionRegistry,
    Event,
    GuardRegistry,
    InMemoryStateStore,
    Orchestrator,
    StateMachine,
)

# Alias to avoid name shadowing when test class is TestOrchestrator
_Orchestrator = Orchestrator


class SpyStateStore:
    """State store that records calls for assertions."""

    def __init__(self) -> None:
        self._state: dict[str, str] = {}
        self.get_state_calls: list[str] = []
        self.set_state_calls: list[tuple[str, str]] = []
        self.get_context_calls: list[str] = []

    def get_state(self, entity_id: str) -> str | None:
        self.get_state_calls.append(entity_id)
        return self._state.get(entity_id)

    def set_state(
        self,
        entity_id: str,
        state: str,
        *,
        metadata: dict | None = None,
    ) -> None:
        self.set_state_calls.append((entity_id, state))
        self._state[entity_id] = state

    def get_context(self, entity_id: str) -> dict:
        self.get_context_calls.append(entity_id)
        return {}


@pytest.fixture
def spy_store() -> SpyStateStore:
    return SpyStateStore()


@pytest.fixture
def orchestrator(
    simple_machine: StateMachine, spy_store: SpyStateStore
) -> Orchestrator:
    guards = GuardRegistry()
    guards.register("always", lambda ctx: True)
    actions = ActionRegistry()
    actions.register("send_notification", lambda ctx: None)
    actions.register("finalize", lambda ctx: None)
    actions.register("log_activation", lambda ctx: None)
    return Orchestrator(simple_machine, spy_store, guards, actions)


class TestInMemoryStateStore:
    """Tests for InMemoryStateStore."""

    def test_get_state_returns_none_for_unknown_entity(self) -> None:
        store = InMemoryStateStore()
        assert store.get_state("unknown") is None

    def test_set_state_and_get_state(self) -> None:
        store = InMemoryStateStore()
        store.set_state("e1", "open")
        assert store.get_state("e1") == "open"

    def test_get_context_returns_empty_by_default(self) -> None:
        store = InMemoryStateStore()
        assert store.get_context("e1") == {}

    def test_set_context_and_get_context(self) -> None:
        store = InMemoryStateStore()
        store.set_context("e1", {"order_id": "o1"})
        assert store.get_context("e1") == {"order_id": "o1"}

    def test_get_is_terminal_after_orchestrator_transitions(
        self, simple_machine: StateMachine
    ) -> None:
        """Orchestrator sets is_terminal in metadata; store exposes it via get_is_terminal."""
        store = InMemoryStateStore()
        guards = GuardRegistry()
        guards.register("always", lambda ctx: True)
        actions = ActionRegistry()
        actions.register("send_notification", lambda ctx: None)
        actions.register("finalize", lambda ctx: None)
        actions.register("log_activation", lambda ctx: None)
        orch = Orchestrator(simple_machine, store, guards, actions)

        assert store.get_is_terminal("e1") is None  # unknown entity

        orch.process_event("e1", "activate", {})
        assert store.get_state("e1") == "active"
        assert store.get_is_terminal("e1") is False  # active is not terminal

        orch.process_event("e1", "complete", {})
        assert store.get_state("e1") == "completed"
        assert store.get_is_terminal("e1") is True  # completed is terminal


class TestOrchestrator:
    """Tests for Orchestrator process_event."""

    def test_process_event_new_entity_uses_initial_state(
        self, orchestrator: Orchestrator, spy_store: SpyStateStore
    ) -> None:
        result = orchestrator.process_event("order-1", "activate", {})
        assert result.success
        assert result.source_state == "pending"
        assert result.target_state == "active"
        assert spy_store.get_state_calls == ["order-1"]
        assert spy_store.set_state_calls == [("order-1", "active")]
        assert spy_store.get_context_calls == ["order-1"]

    def test_process_event_load_process_persist_execute_order(
        self, orchestrator: Orchestrator, spy_store: SpyStateStore
    ) -> None:
        spy_store._state["order-1"] = "pending"
        result = orchestrator.process_event("order-1", "activate", {})
        assert result.success
        assert result.target_state == "active"
        assert spy_store.set_state_calls == [("order-1", "active")]
        assert result.all_actions  # on_enter + transition actions

    def test_process_event_failed_transition_does_not_persist_or_execute(
        self, orchestrator: Orchestrator, spy_store: SpyStateStore
    ) -> None:
        spy_store._state["order-1"] = "pending"
        result = orchestrator.process_event("order-1", "complete", {})
        assert not result.success
        assert result.target_state is None
        assert spy_store.set_state_calls == []
        assert result.all_actions == ()

    def test_process_event_terminal_state_does_not_transition(
        self, orchestrator: Orchestrator, spy_store: SpyStateStore
    ) -> None:
        spy_store._state["order-1"] = "completed"
        result = orchestrator.process_event("order-1", "activate", {})
        assert not result.success
        assert spy_store.set_state_calls == []

    def test_process_event_with_event_object(
        self, orchestrator: Orchestrator, spy_store: SpyStateStore
    ) -> None:
        spy_store._state["order-1"] = "pending"
        event = Event(trigger="activate", payload={"source": "api"})
        result = orchestrator.process_event("order-1", event, {"extra": 1})
        assert result.success
        assert result.target_state == "active"
        assert spy_store.set_state_calls == [("order-1", "active")]

    def test_process_event_entity_unknown_no_initial_raises(
        self,
        simple_machine: StateMachine,
        spy_store: SpyStateStore,
    ) -> None:
        guards = GuardRegistry()
        actions = ActionRegistry()
        orch = _Orchestrator(
            simple_machine,
            spy_store,
            guards,
            actions,
            use_initial_state_when_missing=False,
        )
        with pytest.raises(ValueError, match="has no state"):
            orch.process_event("unknown", "activate", {})

    def test_process_event_requires_sync_state_store(
        self,
        simple_machine: StateMachine,
    ) -> None:
        guards = GuardRegistry()
        actions = ActionRegistry()

        # Object with only async methods (no get_state/set_state/get_context)
        class AsyncOnly:
            async def aget_state(self, entity_id: str): ...
            async def aset_state(
                self, entity_id: str, state: str, *, metadata=None
            ): ...
            async def aget_context(self, entity_id: str): ...

        orch = _Orchestrator(
            simple_machine,
            AsyncOnly(),
            guards,
            actions,
        )
        with pytest.raises(TypeError, match="sync StateStore"):
            orch.process_event("e1", "activate", {})
