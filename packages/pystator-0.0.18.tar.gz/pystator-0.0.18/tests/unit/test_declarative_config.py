"""End-to-end tests for declarative effects, checks, groups, and refs.

Tests the full pipeline: YAML config → parsing → processing → execution.
"""

from __future__ import annotations

import pytest

from pystator import ActionExecutor, StateMachine

# ---------------------------------------------------------------------------
# Minimal YAML-like config dict with all new features
# ---------------------------------------------------------------------------

DECLARATIVE_CONFIG = {
    "meta": {
        "machine_name": "declarative_test",
        "version": "1.0.0",
        "strict_mode": False,
    },
    "groups": {
        "active": {"label": "Active States", "description": "Processing states"},
        "terminal": {"label": "Terminal States"},
    },
    "states": [
        {
            "name": "idle",
            "type": "initial",
            "group": "active",
            "on_enter": [
                {"set": {"phase": "idle", "attempt_count": 0}},
                {"timestamp": "entered_idle_at"},
            ],
        },
        {
            "name": "processing",
            "type": "stable",
            "group": "active",
            "on_enter": [
                {"set": {"phase": "processing"}},
                {"increment": "attempt_count"},
                {"timestamp": "processing_started_at"},
            ],
        },
        {
            "name": "done",
            "type": "terminal",
            "group": "terminal",
            "on_enter": [
                {"set": {"phase": "done"}},
                {"timestamp": "completed_at"},
            ],
        },
        {
            "name": "failed",
            "type": "terminal",
            "group": "terminal",
            "on_enter": [
                {"set": {"phase": "failed"}},
                {"clear": "temp_data"},
            ],
        },
    ],
    "transitions": [
        {
            "trigger": "start",
            "source": "idle",
            "dest": "processing",
            "ref": "SPEC-1.1",
            "guards": [
                {"check": {"field": "ready", "op": "eq", "value": True}},
            ],
            "actions": [
                {"set": {"status": "started"}},
                {"append": {"field": "log", "value": "processing started"}},
            ],
        },
        {
            "trigger": "complete",
            "source": "processing",
            "dest": "done",
            "refs": ["SPEC-1.2", "JIRA-100"],
            "guards": [
                {"check": {"field": "result", "op": "is_set"}},
            ],
        },
        {
            "trigger": "retry",
            "source": "processing",
            "dest": "processing",
            "guards": [
                {"check": {"field": "attempt_count", "op": "lt", "value": 3}},
            ],
            "actions": [
                {"increment": "attempt_count"},
            ],
        },
        {
            "trigger": "fail",
            "source": "processing",
            "dest": "failed",
            "actions": [
                {"set": {"failure_reason": "error_occurred"}},
            ],
        },
        {
            "trigger": "start",
            "source": "idle",
            "dest": "failed",
            "description": "Start rejected — not ready",
            "guards": [
                {"check": {"field": "ready", "op": "neq", "value": True}},
            ],
            "actions": [
                {"set": {"failure_reason": "not_ready"}},
            ],
        },
    ],
}


@pytest.fixture
def machine():
    return StateMachine.from_dict(DECLARATIVE_CONFIG)


class TestDeclarativeConfigParsing:
    """Test that configs with declarative features parse correctly."""

    def test_groups_in_meta(self, machine):
        assert "groups" in machine.meta
        assert "active" in machine.meta["groups"]
        assert machine.meta["groups"]["active"]["label"] == "Active States"

    def test_state_group(self, machine):
        assert machine.get_state("idle").group == "active"
        assert machine.get_state("processing").group == "active"
        assert machine.get_state("done").group == "terminal"

    def test_transition_ref(self, machine):
        start_trans = [
            t
            for t in machine.transitions
            if t.trigger == "start" and t.dest == "processing"
        ]
        assert len(start_trans) == 1
        assert start_trans[0].refs == ("SPEC-1.1",)

    def test_transition_refs(self, machine):
        complete_trans = [t for t in machine.transitions if t.trigger == "complete"]
        assert len(complete_trans) == 1
        assert complete_trans[0].refs == ("SPEC-1.2", "JIRA-100")

    def test_on_enter_effects_parsed(self, machine):
        idle = machine.get_state("idle")
        assert len(idle.on_enter) == 2
        assert idle.on_enter[0].is_effect
        assert idle.on_enter[0].effect == "set"
        assert idle.on_enter[1].is_effect
        assert idle.on_enter[1].effect == "timestamp"

    def test_transition_check_guard_parsed(self, machine):
        start_trans = [
            t
            for t in machine.transitions
            if t.trigger == "start" and t.dest == "processing"
        ]
        assert len(start_trans) == 1
        guards = start_trans[0].guards
        assert len(guards) == 1
        assert guards[0].is_check
        assert guards[0].check.field == "ready"
        assert guards[0].check.op == "eq"

    def test_transition_effect_actions_parsed(self, machine):
        start_trans = [
            t
            for t in machine.transitions
            if t.trigger == "start" and t.dest == "processing"
        ]
        actions = start_trans[0].actions
        assert len(actions) == 2
        assert actions[0].is_effect and actions[0].effect == "set"
        assert actions[1].is_effect and actions[1].effect == "append"


class TestDeclarativeExecution:
    """Test full execution with declarative effects and checks."""

    def test_check_guard_allows_transition(self, machine):
        result = machine.process("idle", "start", {"ready": True})
        assert result.success
        assert result.target_state == "processing"

    def test_check_guard_blocks_transition(self, machine):
        result = machine.process("idle", "start", {"ready": False})
        # Should go to failed via the "not ready" transition
        assert result.success
        assert result.target_state == "failed"

    def test_set_effect_in_transition(self, machine):
        result = machine.process("idle", "start", {"ready": True})
        assert result.success
        # Execute transition actions
        ctx = {"ready": True}
        executor = ActionExecutor(machine.action_registry, strict=False)
        exec_result = executor.execute(result, ctx)
        assert ctx["status"] == "started"

    def test_append_effect_in_transition(self, machine):
        result = machine.process("idle", "start", {"ready": True})
        ctx = {"ready": True}
        executor = ActionExecutor(machine.action_registry, strict=False)
        executor.execute(result, ctx)
        assert ctx["log"] == ["processing started"]

    def test_increment_effect_in_transition(self, machine):
        result = machine.process("processing", "retry", {"attempt_count": 1})
        ctx = {"attempt_count": 1}
        executor = ActionExecutor(machine.action_registry, strict=False)
        executor.execute(result, ctx)
        assert ctx["attempt_count"] == 2

    def test_timestamp_effect_in_on_enter(self, machine):
        result = machine.process("idle", "start", {"ready": True})
        ctx = {"ready": True}
        executor = ActionExecutor(machine.action_registry, strict=False)
        executor.execute(result, ctx)
        # on_enter for processing should set processing_started_at
        assert "processing_started_at" in ctx
        assert isinstance(ctx["processing_started_at"], str)

    def test_set_effect_in_on_enter(self, machine):
        result = machine.process("idle", "start", {"ready": True})
        ctx = {"ready": True}
        executor = ActionExecutor(machine.action_registry, strict=False)
        executor.execute(result, ctx)
        assert ctx["phase"] == "processing"

    def test_increment_effect_in_on_enter(self, machine):
        result = machine.process("idle", "start", {"ready": True})
        ctx = {"ready": True, "attempt_count": 0}
        executor = ActionExecutor(machine.action_registry, strict=False)
        executor.execute(result, ctx)
        assert ctx["attempt_count"] == 1

    def test_clear_effect_in_on_enter(self, machine):
        result = machine.process("processing", "fail", {})
        ctx = {"temp_data": "some_value"}
        executor = ActionExecutor(machine.action_registry, strict=False)
        executor.execute(result, ctx)
        assert "temp_data" not in ctx

    def test_check_lt_guard_pass(self, machine):
        result = machine.process("processing", "retry", {"attempt_count": 1})
        assert result.success
        assert result.target_state == "processing"

    def test_check_lt_guard_fail(self, machine):
        result = machine.process("processing", "retry", {"attempt_count": 3})
        assert not result.success  # No matching transition

    def test_is_set_guard(self, machine):
        result = machine.process("processing", "complete", {"result": "ok"})
        assert result.success
        assert result.target_state == "done"

    def test_is_set_guard_blocks(self, machine):
        result = machine.process("processing", "complete", {})
        assert not result.success

    def test_effects_compose_with_named_actions(self):
        """Effects and named actions work together in the same action list."""
        config = {
            "meta": {"machine_name": "mixed", "strict_mode": False},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [
                {
                    "trigger": "go",
                    "source": "a",
                    "dest": "b",
                    "actions": [
                        {"set": {"x": 1}},
                        "my_action",
                        {"increment": "count"},
                    ],
                },
            ],
        }
        machine = StateMachine.from_dict(config)

        # Register the named action
        call_log = []

        @machine.action("my_action")
        def my_action(ctx):
            call_log.append("called")

        result = machine.process("a", "go", {})
        assert result.success

        ctx = {}
        executor = ActionExecutor(machine.action_registry, strict=False)
        executor.execute(result, ctx)
        assert ctx["x"] == 1
        assert call_log == ["called"]
        assert ctx["count"] == 1


class TestDeclarativeEffectsValidation:
    """Test that validate_actions_exist skips effects."""

    def test_effects_not_reported_as_missing(self, machine):
        result = machine.process("idle", "start", {"ready": True})
        executor = ActionExecutor(machine.action_registry, strict=False)
        missing = executor.validate_actions_exist(result)
        # Effects should not appear in missing list
        assert all(not name.startswith("_effect.") for name in missing)
