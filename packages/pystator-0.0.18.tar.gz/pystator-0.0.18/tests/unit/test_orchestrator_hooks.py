"""Unit tests for orchestrator transition hooks."""

from __future__ import annotations

from typing import Any

import pytest

from pystator import (
    ActionRegistry,
    GuardRegistry,
    InMemoryStateStore,
    Orchestrator,
    StateMachine,
    TransitionHook,
)
from pystator._types import TransitionResult
from pystator.hooks import TransitionObserver


class SpyHook:
    """Hook that records all calls for assertions."""

    def __init__(self) -> None:
        self.before_process_calls: list[dict[str, Any]] = []
        self.transition_start_calls: list[dict[str, Any]] = []
        self.transition_complete_calls: list[dict[str, Any]] = []
        self.transition_error_calls: list[dict[str, Any]] = []

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        self.before_process_calls.append(
            {
                "entity_id": entity_id,
                "current_state": current_state,
                "trigger": trigger,
            }
        )

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        self.transition_start_calls.append(
            {
                "current_state": current_state,
                "trigger": trigger,
            }
        )

    def on_transition_complete(
        self,
        result: TransitionResult,
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        self.transition_complete_calls.append(
            {
                "source_state": result.source_state,
                "target_state": result.target_state,
                "success": result.success,
                "duration_ms": duration_ms,
            }
        )

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        self.transition_error_calls.append(
            {
                "error": error,
                "current_state": current_state,
                "trigger": trigger,
            }
        )


class ErrorHook:
    """Hook that raises on every callback to verify error isolation."""

    def on_before_process(
        self,
        entity_id: str,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        raise RuntimeError("hook exploded in on_before_process")

    def on_transition_start(
        self, current_state: str, trigger: str, context: dict[str, Any]
    ) -> None:
        raise RuntimeError("hook exploded in on_transition_start")

    def on_transition_complete(
        self,
        result: TransitionResult,
        duration_ms: float,
        context: dict[str, Any],
    ) -> None:
        raise RuntimeError("hook exploded in on_transition_complete")

    def on_transition_error(
        self,
        error: Exception,
        current_state: str,
        trigger: str,
        context: dict[str, Any],
    ) -> None:
        raise RuntimeError("hook exploded in on_transition_error")


@pytest.fixture
def store() -> InMemoryStateStore:
    """Fresh in-memory state store."""
    return InMemoryStateStore()


@pytest.fixture
def guards() -> GuardRegistry:
    """Guard registry with default always-pass guard."""
    registry = GuardRegistry()
    registry.register("always", lambda ctx: True)
    return registry


@pytest.fixture
def actions() -> ActionRegistry:
    """Action registry with stub actions for the simple machine."""
    registry = ActionRegistry()
    for name in ("send_notification", "finalize", "log_activation"):
        registry.register(name, lambda ctx: None)
    return registry


@pytest.fixture
def spy_hook() -> SpyHook:
    """A spy hook that records calls."""
    return SpyHook()


def _make_orchestrator(
    machine: StateMachine,
    store: InMemoryStateStore,
    guards: GuardRegistry,
    actions: ActionRegistry,
    hooks: list[TransitionHook] | None = None,
) -> Orchestrator:
    """Helper to build an orchestrator with optional hooks."""
    return Orchestrator(machine, store, guards, actions, hooks=hooks)


class TestOrchestratorWithoutHooks:
    """Backwards compatibility: orchestrator works without hooks."""

    def test_no_hooks_processes_event(
        self,
        simple_machine: StateMachine,
        store: InMemoryStateStore,
        guards: GuardRegistry,
        actions: ActionRegistry,
    ) -> None:
        """Orchestrator without hooks processes events normally."""
        orch = _make_orchestrator(simple_machine, store, guards, actions, hooks=None)
        result = orch.process_event("e1", "activate", {})

        assert result.success
        assert result.source_state == "pending"
        assert result.target_state == "active"


class TestOrchestratorHookLifecycle:
    """Hook lifecycle callbacks are called at the right times."""

    def test_on_before_process_called(
        self,
        simple_machine: StateMachine,
        store: InMemoryStateStore,
        guards: GuardRegistry,
        actions: ActionRegistry,
        spy_hook: SpyHook,
    ) -> None:
        """on_before_process is called before processing."""
        orch = _make_orchestrator(
            simple_machine, store, guards, actions, hooks=[spy_hook]
        )
        orch.process_event("e1", "activate", {})

        assert len(spy_hook.before_process_calls) == 1
        call = spy_hook.before_process_calls[0]
        assert call["entity_id"] == "e1"
        assert call["current_state"] == "pending"
        assert call["trigger"] == "activate"

    def test_on_transition_start_and_complete_on_success(
        self,
        simple_machine: StateMachine,
        store: InMemoryStateStore,
        guards: GuardRegistry,
        actions: ActionRegistry,
        spy_hook: SpyHook,
    ) -> None:
        """on_transition_start and on_transition_complete called on success."""
        orch = _make_orchestrator(
            simple_machine, store, guards, actions, hooks=[spy_hook]
        )
        orch.process_event("e1", "activate", {})

        assert len(spy_hook.transition_start_calls) == 1
        assert spy_hook.transition_start_calls[0]["current_state"] == "pending"
        assert spy_hook.transition_start_calls[0]["trigger"] == "activate"

        assert len(spy_hook.transition_complete_calls) == 1
        complete = spy_hook.transition_complete_calls[0]
        assert complete["success"] is True
        assert complete["source_state"] == "pending"
        assert complete["target_state"] == "active"
        assert complete["duration_ms"] >= 0

    def test_on_transition_error_when_machine_raises(
        self,
        simple_machine: StateMachine,
        store: InMemoryStateStore,
        guards: GuardRegistry,
        actions: ActionRegistry,
        spy_hook: SpyHook,
    ) -> None:
        """on_transition_error called when machine.process raises."""
        orch = _make_orchestrator(
            simple_machine, store, guards, actions, hooks=[spy_hook]
        )

        # Patch machine.process to raise
        original_process = simple_machine.process

        def raising_process(
            state: str, event: Any, ctx: dict[str, Any]
        ) -> TransitionResult:
            raise RuntimeError("kaboom")

        simple_machine.process = raising_process  # type: ignore[assignment]

        try:
            with pytest.raises(RuntimeError, match="kaboom"):
                orch.process_event("e1", "activate", {})

            assert len(spy_hook.transition_error_calls) == 1
            err_call = spy_hook.transition_error_calls[0]
            assert isinstance(err_call["error"], RuntimeError)
            assert err_call["current_state"] == "pending"
            assert err_call["trigger"] == "activate"
        finally:
            simple_machine.process = original_process  # type: ignore[assignment]


class TestAsyncOrchestratorHooks:
    """Hooks work with async_process_event as well."""

    @pytest.mark.asyncio
    async def test_async_hooks_called(
        self,
        simple_machine: StateMachine,
        guards: GuardRegistry,
        actions: ActionRegistry,
        spy_hook: SpyHook,
    ) -> None:
        """Async process_event also calls hooks."""
        store = InMemoryStateStore()
        orch = _make_orchestrator(
            simple_machine, store, guards, actions, hooks=[spy_hook]
        )
        result = await orch.async_process_event("e1", "activate", {})

        assert result.success
        assert len(spy_hook.before_process_calls) == 1
        assert len(spy_hook.transition_start_calls) == 1
        assert len(spy_hook.transition_complete_calls) == 1
        assert spy_hook.transition_complete_calls[0]["success"] is True


class TestMultipleHooks:
    """Multiple hooks are all notified."""

    def test_multiple_hooks_all_called(
        self,
        simple_machine: StateMachine,
        store: InMemoryStateStore,
        guards: GuardRegistry,
        actions: ActionRegistry,
    ) -> None:
        """All registered hooks receive every callback."""
        hook_a = SpyHook()
        hook_b = SpyHook()
        orch = _make_orchestrator(
            simple_machine, store, guards, actions, hooks=[hook_a, hook_b]
        )
        orch.process_event("e1", "activate", {})

        for hook in (hook_a, hook_b):
            assert len(hook.before_process_calls) == 1
            assert len(hook.transition_start_calls) == 1
            assert len(hook.transition_complete_calls) == 1


class TestHookErrorIsolation:
    """Hook errors are caught and do not break the orchestrator."""

    def test_error_hook_does_not_break_orchestrator(
        self,
        simple_machine: StateMachine,
        store: InMemoryStateStore,
        guards: GuardRegistry,
        actions: ActionRegistry,
    ) -> None:
        """A hook that raises does not prevent the orchestrator from working."""
        error_hook = ErrorHook()
        spy = SpyHook()
        orch = _make_orchestrator(
            simple_machine, store, guards, actions, hooks=[error_hook, spy]
        )

        result = orch.process_event("e1", "activate", {})

        assert result.success
        assert result.target_state == "active"
        # The spy hook after the error hook still gets called
        assert len(spy.before_process_calls) == 1
        assert len(spy.transition_start_calls) == 1
        assert len(spy.transition_complete_calls) == 1


class TestTransitionObserverDirectly:
    """Unit tests for TransitionObserver in isolation."""

    def test_add_and_remove_hook(self) -> None:
        """Hooks can be added and removed."""
        observer = TransitionObserver()
        hook = SpyHook()
        observer.add_hook(hook)
        observer.before_process("e1", "pending", "activate", {})
        assert len(hook.before_process_calls) == 1

        observer.remove_hook(hook)
        observer.before_process("e2", "pending", "activate", {})
        assert len(hook.before_process_calls) == 1  # not called again

    def test_hook_error_caught_in_observer(self) -> None:
        """Observer catches hook errors and continues to next hook."""
        observer = TransitionObserver()
        error_hook = ErrorHook()
        spy = SpyHook()
        observer.add_hook(error_hook)
        observer.add_hook(spy)

        observer.before_process("e1", "pending", "activate", {})
        assert len(spy.before_process_calls) == 1

        observer.before_transition("pending", "activate", {})
        assert len(spy.transition_start_calls) == 1
