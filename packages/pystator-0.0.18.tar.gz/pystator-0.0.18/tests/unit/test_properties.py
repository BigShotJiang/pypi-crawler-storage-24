"""Property-based tests for PyStator using Hypothesis.

These tests verify invariants that must hold for ANY valid state machine,
regardless of configuration:

- Terminal states absorb all events
- process() target_state is always a defined state
- Random event sequences never reach undefined states
- Initial state is always reachable
"""

from __future__ import annotations

import pytest
from hypothesis import HealthCheck, given, settings

from pystator import StateMachine
from tests.strategies import state_machines

pytestmark = [pytest.mark.slow]


@given(data=state_machines())
@settings(
    max_examples=50,
    deadline=5000,
    suppress_health_check=[HealthCheck.too_slow],
)
def test_terminal_states_absorb_events(data: tuple[StateMachine, dict]) -> None:
    """Events sent to terminal states should always fail (no transition)."""
    machine, config = data
    terminal_states = machine.terminal_states
    triggers = machine.trigger_names

    for terminal in terminal_states:
        for trigger in triggers:
            result = machine.process(terminal, trigger, {})
            assert not result.success, (
                f"Terminal state '{terminal}' accepted trigger '{trigger}'"
            )


@given(data=state_machines())
@settings(
    max_examples=50,
    deadline=5000,
    suppress_health_check=[HealthCheck.too_slow],
)
def test_process_target_is_defined_state(data: tuple[StateMachine, dict]) -> None:
    """If process() succeeds, target_state must be a defined state."""
    machine, config = data
    state_names = set(machine.state_names)
    triggers = machine.trigger_names

    for state_name in list(state_names):
        for trigger in triggers:
            result = machine.process(state_name, trigger, {})
            if result.success and result.target_state is not None:
                assert result.target_state in state_names, (
                    f"target_state '{result.target_state}' not in defined states"
                )


@given(data=state_machines())
@settings(
    max_examples=50,
    deadline=5000,
    suppress_health_check=[HealthCheck.too_slow],
)
def test_random_event_sequence_stays_in_defined_states(
    data: tuple[StateMachine, dict],
) -> None:
    """A random sequence of events should never land on an undefined state."""
    machine, config = data
    instance = machine.create()
    state_names = set(machine.state_names)
    triggers = machine.trigger_names

    # Send up to 20 random events
    for trigger in (triggers * 4)[:20]:
        if instance.is_final:
            break
        instance.send(trigger)
        assert instance.current_state in state_names, (
            f"Instance reached undefined state '{instance.current_state}'"
        )


@given(data=state_machines())
@settings(
    max_examples=50,
    deadline=5000,
    suppress_health_check=[HealthCheck.too_slow],
)
def test_initial_state_is_valid(data: tuple[StateMachine, dict]) -> None:
    """The initial state must be a defined state."""
    machine, config = data
    initial = machine.get_initial_state()
    assert initial.name in machine.state_names


@given(data=state_machines())
@settings(
    max_examples=50,
    deadline=5000,
    suppress_health_check=[HealthCheck.too_slow],
)
def test_snapshot_roundtrip(data: tuple[StateMachine, dict]) -> None:
    """snapshot() -> from_snapshot() should preserve current_state."""
    machine, config = data
    instance = machine.create()

    # Send a few events
    triggers = machine.trigger_names
    for trigger in triggers[:3]:
        if instance.is_final:
            break
        instance.send(trigger)

    snap = instance.snapshot()
    from pystator import EntitySession

    restored = EntitySession.from_snapshot(machine, snap)
    assert restored.current_state == instance.current_state
