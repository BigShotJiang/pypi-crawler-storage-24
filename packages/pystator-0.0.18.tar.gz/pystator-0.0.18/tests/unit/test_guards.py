"""Unit tests for guard system."""

from __future__ import annotations

import pytest

from pystator import (
    GuardEvaluator,
    GuardNotFoundError,
    GuardRegistry,
    GuardResult,
    GuardSpec,
    Transition,
    all_of,
    any_of,
    equals,
    greater_than,
    in_list,
    negate,
)


class TestGuardRegistry:
    """Tests for GuardRegistry."""

    def test_register_and_get(self) -> None:
        """Test registering and retrieving guards."""
        registry = GuardRegistry()
        registry.register("is_valid", lambda ctx: ctx.get("valid", False))

        func = registry.get("is_valid")
        assert func({"valid": True}) is True
        assert func({"valid": False}) is False

    def test_register_duplicate_raises(self) -> None:
        """Test that registering duplicate name raises."""
        registry = GuardRegistry()
        registry.register("test", lambda ctx: True)
        with pytest.raises(ValueError, match="already registered"):
            registry.register("test", lambda ctx: False)

    def test_register_empty_name_raises(self) -> None:
        """Test that empty name raises error."""
        registry = GuardRegistry()
        with pytest.raises(ValueError, match="empty"):
            registry.register("", lambda ctx: True)

    def test_get_nonexistent_raises(self) -> None:
        """Test that getting non-existent guard raises."""
        registry = GuardRegistry()
        with pytest.raises(GuardNotFoundError):
            registry.get("nonexistent")

    def test_has(self) -> None:
        """Test has method."""
        registry = GuardRegistry()
        registry.register("exists", lambda ctx: True)

        assert registry.has("exists") is True
        assert registry.has("not_exists") is False

    def test_unregister(self) -> None:
        """Test unregistering guards."""
        registry = GuardRegistry()
        registry.register("test", lambda ctx: True)
        registry.unregister("test")

        assert registry.has("test") is False

    def test_unregister_nonexistent_raises(self) -> None:
        """Test that unregistering non-existent guard raises."""
        registry = GuardRegistry()
        with pytest.raises(GuardNotFoundError):
            registry.unregister("nonexistent")

    def test_evaluate_single(self) -> None:
        """Test evaluating a single guard."""
        registry = GuardRegistry()
        registry.register("check", lambda ctx: ctx.get("value", 0) > 10)

        assert registry.evaluate("check", {"value": 15}) is True
        assert registry.evaluate("check", {"value": 5}) is False

    def test_evaluate_all_success(self) -> None:
        """Test evaluating all guards with success."""
        registry = GuardRegistry()
        registry.register("g1", lambda ctx: True)
        registry.register("g2", lambda ctx: True)

        result = registry.evaluate_all(("g1", "g2"), {})
        assert result.passed is True
        assert len(result.evaluated_guards) == 2

    def test_evaluate_all_failure(self) -> None:
        """Test evaluating all guards with failure."""
        registry = GuardRegistry()
        registry.register("g1", lambda ctx: True)
        registry.register("g2", lambda ctx: False)
        registry.register("g3", lambda ctx: True)

        result = registry.evaluate_all(("g1", "g2", "g3"), {}, fail_fast=True)
        assert result.passed is False
        assert result.guard_name == "g2"
        assert len(result.evaluated_guards) == 2  # Stopped at g2

    def test_evaluate_all_no_fail_fast(self) -> None:
        """Test evaluating all guards without fail fast."""
        registry = GuardRegistry()
        registry.register("g1", lambda ctx: True)
        registry.register("g2", lambda ctx: False)
        registry.register("g3", lambda ctx: True)

        result = registry.evaluate_all(("g1", "g2", "g3"), {}, fail_fast=False)
        assert result.passed is False
        assert len(result.evaluated_guards) == 3  # All evaluated

    def test_evaluate_empty_guards(self) -> None:
        """Test evaluating empty guard list."""
        registry = GuardRegistry()
        result = registry.evaluate_all((), {})
        assert result.passed is True

    def test_list_guards(self) -> None:
        """Test listing registered guards."""
        registry = GuardRegistry()
        registry.register("a", lambda ctx: True)
        registry.register("b", lambda ctx: True)

        guards = registry.list_guards()
        assert set(guards) == {"a", "b"}

    def test_clear(self) -> None:
        """Test clearing registry."""
        registry = GuardRegistry()
        registry.register("test", lambda ctx: True)
        registry.clear()

        assert len(registry) == 0
        assert registry.has("test") is False

    def test_len(self) -> None:
        """Test len of registry."""
        registry = GuardRegistry()
        assert len(registry) == 0
        registry.register("test", lambda ctx: True)
        assert len(registry) == 1

    def test_contains(self) -> None:
        """Test 'in' operator."""
        registry = GuardRegistry()
        registry.register("test", lambda ctx: True)

        assert "test" in registry
        assert "other" not in registry

    def test_decorator(self) -> None:
        """Test decorator for registration."""
        registry = GuardRegistry()

        @registry.decorator()
        def my_guard(ctx: dict) -> bool:
            return ctx.get("ok", False)

        assert "my_guard" in registry
        assert registry.evaluate("my_guard", {"ok": True}) is True

    def test_decorator_with_name(self) -> None:
        """Test decorator with custom name."""
        registry = GuardRegistry()

        @registry.decorator(name="custom_name")
        def my_guard(ctx: dict) -> bool:
            return True

        assert "custom_name" in registry
        assert "my_guard" not in registry


class TestGuardResult:
    """Tests for GuardResult dataclass."""

    def test_success_result(self) -> None:
        """Test creating success result."""
        result = GuardResult.success([("g1", True), ("g2", True)])
        assert result.passed is True
        assert result.guard_name is None
        assert len(result.evaluated_guards) == 2

    def test_failure_result(self) -> None:
        """Test creating failure result."""
        result = GuardResult.failure("failing_guard", "Guard rejected")
        assert result.passed is False
        assert result.guard_name == "failing_guard"
        assert result.message == "Guard rejected"


class TestGuardEvaluator:
    """Tests for GuardEvaluator."""

    def test_can_transition_no_guards(self) -> None:
        """Test can_transition with no guards."""
        registry = GuardRegistry()
        evaluator = GuardEvaluator(registry)

        trans = Transition(
            trigger="test",
            source=frozenset({"A"}),
            dest="B",
        )
        result = evaluator.can_transition(trans, {})
        assert result.passed is True

    def test_can_transition_with_guards(self) -> None:
        """Test can_transition with guards."""
        registry = GuardRegistry()
        registry.register("is_ready", lambda ctx: ctx.get("ready", False))
        evaluator = GuardEvaluator(registry)

        trans = Transition(
            trigger="test",
            source=frozenset({"A"}),
            dest="B",
            guards=(GuardSpec(name="is_ready"),),
        )

        assert evaluator.can_transition(trans, {"ready": True}).passed is True
        assert evaluator.can_transition(trans, {"ready": False}).passed is False

    def test_missing_guard_strict_mode(self) -> None:
        """Test missing guard in strict mode raises."""
        registry = GuardRegistry()
        evaluator = GuardEvaluator(registry, strict=True)

        trans = Transition(
            trigger="test",
            source=frozenset({"A"}),
            dest="B",
            guards=(GuardSpec(name="nonexistent"),),
        )

        with pytest.raises(GuardNotFoundError):
            evaluator.can_transition(trans, {})

    def test_missing_guard_non_strict(self) -> None:
        """Test missing guard in non-strict mode passes."""
        registry = GuardRegistry()
        evaluator = GuardEvaluator(registry, strict=False)

        trans = Transition(
            trigger="test",
            source=frozenset({"A"}),
            dest="B",
            guards=(GuardSpec(name="nonexistent"),),
        )

        result = evaluator.can_transition(trans, {})
        assert result.passed is True


class TestBuiltinGuards:
    """Tests for built-in guard functions."""

    def test_equals(self) -> None:
        """Test equals guard factory."""
        guard = equals("status", "active")
        assert guard({"status": "active"}) is True
        assert guard({"status": "inactive"}) is False
        assert guard({}) is False

    def test_greater_than(self) -> None:
        """Test greater_than guard factory."""
        guard = greater_than("value", 10)
        assert guard({"value": 15}) is True
        assert guard({"value": 10}) is False
        assert guard({"value": 5}) is False
        assert guard({}) is False

    def test_in_list(self) -> None:
        """Test in_list guard factory."""
        guard = in_list("role", ["admin", "moderator"])
        assert guard({"role": "admin"}) is True
        assert guard({"role": "moderator"}) is True
        assert guard({"role": "user"}) is False
        assert guard({}) is False

    def test_all_of(self) -> None:
        """Test all_of compound guard."""
        guard = all_of(
            equals("a", 1),
            equals("b", 2),
        )
        assert guard({"a": 1, "b": 2}) is True
        assert guard({"a": 1, "b": 3}) is False
        assert guard({"a": 2, "b": 2}) is False

    def test_any_of(self) -> None:
        """Test any_of compound guard."""
        guard = any_of(
            equals("role", "admin"),
            equals("role", "mod"),
        )
        assert guard({"role": "admin"}) is True
        assert guard({"role": "mod"}) is True
        assert guard({"role": "user"}) is False

    def test_negate(self) -> None:
        """Test negate guard."""
        guard = negate(equals("blocked", True))
        assert guard({"blocked": False}) is True
        assert guard({"blocked": True}) is False
        assert guard({}) is True
