"""Unit tests for state_variables feature: config, machine, builder, orchestrator."""

from __future__ import annotations

import pytest

from pystator import (
    ActionRegistry,
    GuardRegistry,
    InMemoryStateStore,
    Orchestrator,
    StateMachine,
    StateMachineBuilder,
)
from pystator.config.converter import machine_config_to_core
from pystator.config.loader import ConfigLoader
from pystator.config.models import MachineConfig, MetaDef, StateVariableDef
from pystator.config.validator import ConfigValidator

# -----------------------------------------------------------------------------
# Config models: StateVariableDef, MetaDef.validate_context, state_variables
# -----------------------------------------------------------------------------


class TestStateVariableDef:
    """StateVariableDef model."""

    def test_minimal(self) -> None:
        item = StateVariableDef(key="order_id")
        assert item.key == "order_id"
        assert item.type is None
        assert item.required is False

    def test_full(self) -> None:
        item = StateVariableDef(
            key="qty",
            type="number",
            description="Quantity",
            default=0,
            required=True,
        )
        assert item.key == "qty"
        assert item.type == "number"
        assert item.description == "Quantity"
        assert item.default == 0
        assert item.required is True


class TestMetaDefValidateContext:
    """MetaDef.validate_context."""

    def test_default_false(self) -> None:
        m = MetaDef()
        assert m.validate_context is False

    def test_explicit_true(self) -> None:
        m = MetaDef(validate_context=True)
        assert m.validate_context is True


class TestMachineConfigStateVariables:
    """MachineConfig state_variables."""

    def test_state_variables_long_form(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [
                {"key": "order_id", "type": "string", "required": True},
                {"key": "quantity", "type": "number", "default": 0},
            ],
        }
        m = MachineConfig.model_validate(config)
        assert m.state_variables is not None
        assert len(m.state_variables) == 2
        assert m.state_variables[0].key == "order_id"
        assert m.state_variables[0].required is True
        assert m.state_variables[1].key == "quantity"
        assert m.state_variables[1].default == 0

    def test_state_variables_shorthand(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": ["order_id", "quantity"],
        }
        m = MachineConfig.model_validate(config)
        assert m.state_variables is not None
        assert len(m.state_variables) == 2
        assert m.state_variables[0].key == "order_id"
        assert m.state_variables[1].key == "quantity"

    def test_duplicate_key_raises(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "x"}, {"key": "x"}],
        }
        with pytest.raises(ValueError, match="Duplicate state_variable key"):
            MachineConfig.model_validate(config)


# -----------------------------------------------------------------------------
# Converter: state_variables and validate_context in meta
# -----------------------------------------------------------------------------


class TestConverterStateVariables:
    """machine_config_to_core passes state_variables and validate_context."""

    def test_state_variables_in_meta(self) -> None:
        config = MachineConfig.model_validate(
            {
                "meta": {"machine_name": "t", "validate_context": True},
                "states": [
                    {"name": "a", "type": "initial"},
                    {"name": "b", "type": "terminal"},
                ],
                "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
                "state_variables": [{"key": "id", "required": True}],
            }
        )
        states, transitions, meta = machine_config_to_core(config)
        assert "state_variables" in meta
        assert len(meta["state_variables"]) == 1
        assert meta["state_variables"][0]["key"] == "id"
        assert meta["validate_context"] is True

    def test_validate_context_in_meta(self) -> None:
        config = MachineConfig.model_validate(
            {
                "meta": {"machine_name": "t", "validate_context": True},
                "states": [
                    {"name": "a", "type": "initial"},
                    {"name": "b", "type": "terminal"},
                ],
                "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            }
        )
        _, _, meta = machine_config_to_core(config)
        assert meta.get("validate_context") is True


# -----------------------------------------------------------------------------
# StateMachine: get_state_variables, validate_context
# -----------------------------------------------------------------------------


class TestStateMachineStateVariables:
    """StateMachine.get_state_variables and validate_context."""

    def test_get_state_variables_empty_when_none(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
        }
        m = StateMachine.from_dict(config)
        assert m.get_state_variables() == []

    def test_get_state_variables_from_meta(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [
                {"key": "order_id", "required": True},
                {"key": "qty", "default": 0},
            ],
        }
        m = StateMachine.from_dict(config)
        vars_list = m.get_state_variables()
        assert len(vars_list) == 2
        assert vars_list[0]["key"] == "order_id"
        assert vars_list[0].get("required") is True
        assert vars_list[1]["key"] == "qty"
        assert vars_list[1].get("default") == 0

    def test_validate_context_disabled_returns_true(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "x", "required": True}],
        }
        m = StateMachine.from_dict(config)
        valid, errors = m.validate_context({})
        assert valid is True
        assert errors == []

    def test_validate_context_required_missing(self) -> None:
        config = {
            "meta": {"machine_name": "t", "validate_context": True},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "order_id", "required": True}],
        }
        m = StateMachine.from_dict(config)
        valid, errors = m.validate_context({})
        assert valid is False
        assert any("order_id" in e for e in errors)

    def test_validate_context_required_present(self) -> None:
        config = {
            "meta": {"machine_name": "t", "validate_context": True},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "order_id", "required": True}],
        }
        m = StateMachine.from_dict(config)
        valid, errors = m.validate_context({"order_id": "o1"})
        assert valid is True
        assert errors == []

    def test_validate_context_type_check(self) -> None:
        config = {
            "meta": {"machine_name": "t", "validate_context": True},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "qty", "type": "number"}],
        }
        m = StateMachine.from_dict(config)
        valid, errors = m.validate_context({"qty": "not_a_number"})
        assert valid is False
        assert any("number" in e for e in errors)
        valid2, _ = m.validate_context({"qty": 10})
        assert valid2 is True


# -----------------------------------------------------------------------------
# Builder: add_state_variable, from_dict, to_dict
# -----------------------------------------------------------------------------


class TestBuilderStateVariables:
    """StateMachineBuilder state_variables."""

    def test_add_state_variable(self) -> None:
        b = (
            StateMachineBuilder("t")
            .add_state("a", type="initial")
            .add_state("b", type="terminal")
        )
        b.add_state_variable("order_id", type="string", required=True)
        b.add_state_variable("qty", type="number", default=0)
        b.add_transition("go", "a", "b")
        d = b.to_dict()
        assert "state_variables" in d
        assert len(d["state_variables"]) == 2
        assert d["state_variables"][0]["key"] == "order_id"
        assert d["state_variables"][0]["required"] is True
        assert d["state_variables"][1]["key"] == "qty"
        assert d["state_variables"][1]["default"] == 0

    def test_from_dict_loads_state_variables(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "x"}],
        }
        b = StateMachineBuilder.from_dict(config)
        assert len(b._state_variables) == 1
        assert b._state_variables[0]["key"] == "x"

    def test_build_roundtrip_with_state_variables(self) -> None:
        b = (
            StateMachineBuilder("t")
            .add_state("a", type="initial")
            .add_state("b", type="terminal")
            .add_state_variable("id", required=True)
            .add_transition("go", "a", "b")
        )
        m = b.build()
        assert len(m.get_state_variables()) == 1
        assert m.get_state_variables()[0]["key"] == "id"


# -----------------------------------------------------------------------------
# Orchestrator: context validation
# -----------------------------------------------------------------------------


class TestOrchestratorContextValidation:
    """Orchestrator validates context when meta.validate_context is True."""

    def test_validation_failure_returns_failed_result(self) -> None:
        config = {
            "meta": {"machine_name": "t", "validate_context": True},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "required_key", "required": True}],
        }
        machine = StateMachine.from_dict(config)
        store = InMemoryStateStore()
        store.set_state("e1", "a")
        store.set_context("e1", {})  # missing required_key
        guards = GuardRegistry()
        actions = ActionRegistry()
        orch = Orchestrator(machine, store, guards, actions)
        result = orch.process_event("e1", "go", context={})
        assert result.success is False
        assert result.error is not None
        from pystator.errors import FSMError

        assert isinstance(result.error, FSMError)
        validation_errors = result.error.context.get("validation_errors", [])
        assert "required_key" in str(result.error) or any(
            "required_key" in e for e in validation_errors
        )

    def test_validation_success_processes(self) -> None:
        config = {
            "meta": {"machine_name": "t", "validate_context": True},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "required_key", "required": True}],
        }
        machine = StateMachine.from_dict(config)
        store = InMemoryStateStore()
        store.set_state("e1", "a")
        store.set_context("e1", {"required_key": "value"})
        guards = GuardRegistry()
        actions = ActionRegistry()
        orch = Orchestrator(machine, store, guards, actions)
        result = orch.process_event("e1", "go", context={})
        assert result.success is True
        assert result.target_state == "b"

    def test_validation_off_does_not_block(self) -> None:
        config = {
            "meta": {"machine_name": "t", "validate_context": False},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "required_key", "required": True}],
        }
        machine = StateMachine.from_dict(config)
        store = InMemoryStateStore()
        store.set_state("e1", "a")
        store.set_context("e1", {})  # missing required_key but validation off
        guards = GuardRegistry()
        actions = ActionRegistry()
        orch = Orchestrator(machine, store, guards, actions)
        result = orch.process_event("e1", "go", context={})
        assert result.success is True
        assert result.target_state == "b"


# -----------------------------------------------------------------------------
# Config without state_variables (optional section)
# -----------------------------------------------------------------------------


class TestStateVariablesOptional:
    """Configs without state_variables work; section is optional."""

    def test_config_without_state_variables(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
        }
        m = StateMachine.from_dict(config)
        assert m.get_state_variables() == []
        result = m.process("a", "go", {})
        assert result.success is True

    def test_config_with_state_variables_parses_and_processes(self) -> None:
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "order_id", "type": "string"}],
        }
        loader = ConfigLoader(validate=True)
        states, transitions, meta = loader.parse(config)
        assert "state_variables" in meta
        machine = StateMachine.from_dict(config)
        vars_list = machine.get_state_variables()
        assert len(vars_list) >= 1
        result = machine.process("a", "go", {"order_id": "o1"})
        assert result.success is True

    def test_order_config_still_works(self, order_config: dict) -> None:
        """Existing order_config fixture has no state_variables; machine must still work."""
        m = StateMachine.from_dict(order_config)
        assert m.name == "order_fsm"
        assert m.get_state_variables() == []
        result = m.process(
            "pending_new", "exchange_ack", {"order_id": "o1", "order_qty": 100}
        )
        assert result.success is True
        assert result.target_state == "open"

    def test_config_validator_duplicate_state_variable_key(self) -> None:
        """ConfigValidator reports duplicate state_variable keys."""
        config = {
            "meta": {"machine_name": "t"},
            "states": [
                {"name": "a", "type": "initial"},
                {"name": "b", "type": "terminal"},
            ],
            "transitions": [{"trigger": "go", "source": "a", "dest": "b"}],
            "state_variables": [{"key": "x"}, {"key": "x"}],
        }
        validator = ConfigValidator()
        errors = validator.validate(config)
        assert any("Duplicate" in e and "x" in e for e in errors)
