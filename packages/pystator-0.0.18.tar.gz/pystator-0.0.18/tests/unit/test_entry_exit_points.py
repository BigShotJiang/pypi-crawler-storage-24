"""Unit tests for entry/exit point pseudo-states."""

from __future__ import annotations

import pytest

from pystator._types import State, StateType

# ---------------------------------------------------------------------------
# State entry/exit point fields
# ---------------------------------------------------------------------------


class TestEntryPoints:
    """Tests for entry point declarations on State."""

    def test_compound_state_with_entry_points(self) -> None:
        """Compound state can declare entry points."""
        s = State(
            name="payment",
            type=StateType.STABLE,
            initial_child="selecting",
            entry_points=("express", "retry"),
        )
        assert s.entry_points == ("express", "retry")

    def test_compound_state_with_exit_points(self) -> None:
        """Compound state can declare exit points."""
        s = State(
            name="payment",
            type=StateType.STABLE,
            initial_child="selecting",
            exit_points=("success", "failure"),
        )
        assert s.exit_points == ("success", "failure")

    def test_non_compound_with_entry_points_raises(self) -> None:
        """Non-compound state cannot have entry points."""
        with pytest.raises(ValueError, match="Only compound states"):
            State(
                name="simple",
                type=StateType.STABLE,
                entry_points=("fast",),
            )

    def test_non_compound_with_exit_points_raises(self) -> None:
        """Non-compound state cannot have exit points."""
        with pytest.raises(ValueError, match="Only compound states"):
            State(
                name="simple",
                type=StateType.STABLE,
                exit_points=("done",),
            )

    def test_invalid_entry_point_name_raises(self) -> None:
        """Entry point names are validated."""
        with pytest.raises(ValueError, match="must contain only lowercase letters"):
            State(
                name="payment",
                type=StateType.STABLE,
                initial_child="x",
                entry_points=("invalid!",),
            )

    def test_backward_compat_no_points(self) -> None:
        """States without entry/exit points still work."""
        s = State(name="normal", type=StateType.STABLE)
        assert s.entry_points == ()
        assert s.exit_points == ()


# ---------------------------------------------------------------------------
# Entry/exit point resolution
# ---------------------------------------------------------------------------


class TestEntryExitResolution:
    """Tests for resolving parent:point references in transitions."""

    def test_dest_entry_point_resolved(self) -> None:
        """dest 'payment:express' resolves to 'express' child."""
        from pystator._types import Transition
        from pystator.config._shared import resolve_entry_exit_points

        states = {
            "cart": State(name="cart", type=StateType.STABLE),
            "payment": State(
                name="payment",
                type=StateType.STABLE,
                initial_child="selecting",
                entry_points=("express", "retry"),
            ),
            "selecting": State(
                name="selecting", type=StateType.STABLE, parent="payment"
            ),
            "express": State(name="express", type=StateType.STABLE, parent="payment"),
        }
        transitions = [
            Transition(
                trigger="QUICK_PAY",
                source=frozenset({"cart"}),
                dest="payment:express",
            ),
        ]

        resolved = resolve_entry_exit_points(states, transitions)
        assert resolved[0].dest == "express"

    def test_source_exit_point_resolved(self) -> None:
        """source 'payment:success' resolves to 'success' child."""
        from pystator._types import Transition
        from pystator.config._shared import resolve_entry_exit_points

        states = {
            "payment": State(
                name="payment",
                type=StateType.STABLE,
                initial_child="selecting",
                exit_points=("success", "failure"),
            ),
            "selecting": State(
                name="selecting", type=StateType.STABLE, parent="payment"
            ),
            "success": State(name="success", type=StateType.STABLE, parent="payment"),
            "confirmation": State(name="confirmation", type=StateType.STABLE),
        }
        transitions = [
            Transition(
                trigger="PAID",
                source=frozenset({"payment:success"}),
                dest="confirmation",
            ),
        ]

        resolved = resolve_entry_exit_points(states, transitions)
        assert "success" in resolved[0].source
        assert "payment:success" not in resolved[0].source

    def test_default_dest_not_changed(self) -> None:
        """Regular dest like 'payment' is not changed."""
        from pystator._types import Transition
        from pystator.config._shared import resolve_entry_exit_points

        states = {
            "cart": State(name="cart", type=StateType.STABLE),
            "payment": State(
                name="payment",
                type=StateType.STABLE,
                initial_child="selecting",
                entry_points=("express",),
            ),
            "selecting": State(
                name="selecting", type=StateType.STABLE, parent="payment"
            ),
        }
        transitions = [
            Transition(trigger="PAY", source=frozenset({"cart"}), dest="payment"),
        ]

        resolved = resolve_entry_exit_points(states, transitions)
        assert resolved[0].dest == "payment"

    def test_unknown_point_not_resolved(self) -> None:
        """Unknown point name is not resolved."""
        from pystator._types import Transition
        from pystator.config._shared import resolve_entry_exit_points

        states = {
            "cart": State(name="cart", type=StateType.STABLE),
            "payment": State(
                name="payment",
                type=StateType.STABLE,
                initial_child="selecting",
                entry_points=("express",),
            ),
            "selecting": State(
                name="selecting", type=StateType.STABLE, parent="payment"
            ),
        }
        transitions = [
            Transition(
                trigger="GO",
                source=frozenset({"cart"}),
                dest="payment:unknown",
            ),
        ]

        resolved = resolve_entry_exit_points(states, transitions)
        # Not resolved because "unknown" is not an entry point
        assert resolved[0].dest == "payment:unknown"


# ---------------------------------------------------------------------------
# Full config integration
# ---------------------------------------------------------------------------


class TestEntryExitYAML:
    """Test entry/exit points through full config parsing."""

    def test_raw_parser_round_trip(self) -> None:
        """Entry/exit points parsed from raw config dict."""
        from pystator.config._raw_parser import raw_config_to_core

        config = {
            "states": [
                {"name": "cart", "type": "initial"},
                {
                    "name": "payment",
                    "type": "stable",
                    "initial_child": "selecting",
                    "entry_points": ["express", "retry"],
                    "exit_points": ["success", "failure"],
                },
                {"name": "selecting", "type": "stable", "parent": "payment"},
                {"name": "express", "type": "stable", "parent": "payment"},
                {"name": "success", "type": "stable", "parent": "payment"},
                {"name": "failure", "type": "stable", "parent": "payment"},
                {"name": "confirmation", "type": "stable"},
                {"name": "error_page", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "PAY", "source": "cart", "dest": "payment"},
                {"trigger": "QUICK_PAY", "source": "cart", "dest": "payment:express"},
                {
                    "trigger": "PAID",
                    "source": "payment:success",
                    "dest": "confirmation",
                },
                {
                    "trigger": "FAILED",
                    "source": "payment:failure",
                    "dest": "error_page",
                },
            ],
        }

        states, transitions, meta = raw_config_to_core(config)

        # Entry/exit points parsed
        payment = states["payment"]
        assert payment.entry_points == ("express", "retry")
        assert payment.exit_points == ("success", "failure")

        # Dest "payment:express" resolved to "express"
        quick_pay = [t for t in transitions if t.trigger == "QUICK_PAY"][0]
        assert quick_pay.dest == "express"

        # Source "payment:success" resolved to "success"
        paid = [t for t in transitions if t.trigger == "PAID"][0]
        assert "success" in paid.source

        # Regular dest "payment" not changed
        pay = [t for t in transitions if t.trigger == "PAY"][0]
        assert pay.dest == "payment"

    def test_backward_compat(self) -> None:
        """Existing configs without entry/exit points still work."""
        from pystator.config._raw_parser import raw_config_to_core

        config = {
            "states": [
                {"name": "idle", "type": "initial"},
                {"name": "done", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "GO", "source": "idle", "dest": "done"},
            ],
        }

        states, transitions, meta = raw_config_to_core(config)
        assert states["idle"].entry_points == ()
        assert states["idle"].exit_points == ()
        assert transitions[0].dest == "done"
