"""Tests for action parameters support."""

import pytest

from pystator import ActionSpec
from pystator.actions import ACTION_PARAMS_KEY, ActionExecutor, ActionRegistry


class TestActionParams:
    """Tests for parameterized actions."""

    @pytest.fixture
    def registry(self):
        """Create an action registry for testing."""
        reg = ActionRegistry()

        # Action that uses params
        def notify(context):
            params = context.get(ACTION_PARAMS_KEY, {})
            channel = params.get("channel", "default")
            priority = params.get("priority", "normal")
            return f"Notified via {channel} with priority {priority}"

        reg.register("notify", notify)

        # Simple action
        def log_event(context):
            return f"Logged: {context.get('event', 'unknown')}"

        reg.register("log_event", log_event)

        return reg

    @pytest.fixture
    def executor(self, registry):
        """Create an executor for testing."""
        return ActionExecutor(registry, log_execution=False)

    def test_execute_action_spec_no_params(self, executor):
        """Execute ActionSpec without parameters."""
        action = ActionSpec(name="log_event")
        context = {"event": "order_filled"}

        result = executor.execute_action_spec(action, context)

        assert result.success
        assert result.result == "Logged: order_filled"

    def test_execute_action_spec_with_params(self, executor):
        """Execute ActionSpec with parameters."""
        action = ActionSpec(
            name="notify",
            params={"channel": "slack", "priority": "high"},
        )
        context = {}

        result = executor.execute_action_spec(action, context)

        assert result.success
        assert "slack" in result.result
        assert "high" in result.result

    def test_params_injected_into_context(self, executor):
        """Params are injected into context under ACTION_PARAMS_KEY."""
        received_params = []

        def capture_params(context):
            received_params.append(context.get(ACTION_PARAMS_KEY, {}))
            return "ok"

        executor.registry.register("capture", capture_params)

        action = ActionSpec(
            name="capture",
            params={"key1": "value1", "key2": 42},
        )

        executor.execute_action_spec(action, {})

        assert len(received_params) == 1
        assert received_params[0] == {"key1": "value1", "key2": 42}

    def test_params_do_not_override_context(self, executor):
        """Action params don't override existing context keys."""
        received_context = []

        def capture_context(context):
            received_context.append(dict(context))
            return "ok"

        executor.registry.register("capture", capture_context)

        action = ActionSpec(name="capture", params={"x": 1})
        context = {"existing_key": "existing_value"}

        executor.execute_action_spec(action, context)

        assert "existing_key" in received_context[0]
        assert received_context[0]["existing_key"] == "existing_value"
        assert ACTION_PARAMS_KEY in received_context[0]

    def test_execute_action_specs_list(self, executor):
        """Execute multiple ActionSpecs."""
        actions = [
            ActionSpec(name="log_event"),
            ActionSpec(name="notify", params={"channel": "email"}),
        ]
        context = {"event": "test"}

        results = executor.execute_action_specs(actions, context)

        assert len(results) == 2
        assert all(r.success for r in results)

    @pytest.mark.asyncio
    async def test_async_execute_action_spec(self, executor):
        """Async execute ActionSpec with params."""

        async def async_notify(context):
            params = context.get(ACTION_PARAMS_KEY, {})
            return f"Async notified: {params.get('msg', 'none')}"

        executor.registry.register("async_notify", async_notify)

        action = ActionSpec(name="async_notify", params={"msg": "hello"})
        result = await executor.async_execute_action_spec(action, {})

        assert result.success
        assert "hello" in result.result

    @pytest.mark.asyncio
    async def test_async_execute_action_specs_parallel(self, executor):
        """Async execute multiple ActionSpecs in parallel."""
        import asyncio

        execution_order = []

        async def slow_action(context):
            params = context.get(ACTION_PARAMS_KEY, {})
            name = params.get("name", "unknown")
            await asyncio.sleep(0.01)
            execution_order.append(name)
            return name

        executor.registry.register("slow", slow_action)

        actions = [
            ActionSpec(name="slow", params={"name": "first"}),
            ActionSpec(name="slow", params={"name": "second"}),
            ActionSpec(name="slow", params={"name": "third"}),
        ]

        results = await executor.async_execute_action_specs_parallel(actions, {})

        assert len(results) == 3
        assert all(r.success for r in results)
        # Order doesn't matter for parallel execution
        assert {r.result for r in results} == {"first", "second", "third"}


class TestConfigLoaderWithActionParams:
    """Tests for loading parameterized actions from config."""

    def test_load_string_action(self):
        """String actions are parsed as ActionSpec without params."""
        from pystator.config.loader import ConfigLoader

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}],
            "transitions": [
                {
                    "trigger": "go",
                    "source": "a",
                    "dest": "b",
                    "actions": "log_event",
                }
            ],
        }

        _, transitions, _ = loader.parse(config)
        assert len(transitions[0].actions) == 1
        assert transitions[0].actions[0].name == "log_event"
        assert transitions[0].actions[0].has_params is False

    def test_load_parameterized_action(self):
        """Dict actions with name+params are parsed correctly."""
        from pystator.config.loader import ConfigLoader

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}],
            "transitions": [
                {
                    "trigger": "go",
                    "source": "a",
                    "dest": "b",
                    "actions": [
                        {"name": "notify", "params": {"channel": "slack"}},
                    ],
                }
            ],
        }

        _, transitions, _ = loader.parse(config)
        assert len(transitions[0].actions) == 1
        assert transitions[0].actions[0].name == "notify"
        assert transitions[0].actions[0].params == {"channel": "slack"}

    def test_load_mixed_actions(self):
        """Mixed string and parameterized actions."""
        from pystator.config.loader import ConfigLoader

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}],
            "transitions": [
                {
                    "trigger": "go",
                    "source": "a",
                    "dest": "b",
                    "actions": [
                        "log_event",
                        {"name": "notify", "params": {"channel": "email"}},
                        "update_metrics",
                    ],
                }
            ],
        }

        _, transitions, _ = loader.parse(config)
        actions = transitions[0].actions
        assert len(actions) == 3
        assert actions[0].name == "log_event"
        assert actions[0].has_params is False
        assert actions[1].name == "notify"
        assert actions[1].params == {"channel": "email"}
        assert actions[2].name == "update_metrics"
        assert actions[2].has_params is False
