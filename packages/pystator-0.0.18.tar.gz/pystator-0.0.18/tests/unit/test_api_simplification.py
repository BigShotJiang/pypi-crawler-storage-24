"""Tests for API simplification changes.

Covers:
- entity_id on EntitySession (create, snapshot, from_snapshot, repr)
- Orchestrator.machine and Orchestrator.store properties
- machine.orchestrate(store) factory method
- Trimmed __all__ (removed symbols still importable from submodules)
"""

from __future__ import annotations

import uuid

import pytest

from pystator import (
    EntitySession,
    InMemoryStateStore,
    Orchestrator,
    StateMachine,
)

# ------------------------------------------------------------------
# Fixtures
# ------------------------------------------------------------------


@pytest.fixture
def simple_config() -> dict:
    """Minimal FSM config for testing."""
    return {
        "meta": {"machine_name": "test_simple", "version": "1.0.0"},
        "states": [
            {"name": "pending", "type": "initial"},
            {"name": "active", "type": "stable"},
            {"name": "done", "type": "terminal"},
        ],
        "transitions": [
            {"trigger": "start", "source": "pending", "dest": "active"},
            {"trigger": "finish", "source": "active", "dest": "done"},
        ],
    }


@pytest.fixture
def machine(simple_config: dict) -> StateMachine:
    return StateMachine.from_dict(simple_config)


# ------------------------------------------------------------------
# Change 1: entity_id on EntitySession
# ------------------------------------------------------------------


class TestEntityId:
    """EntitySession.entity_id — explicit and auto-generated."""

    def test_explicit_entity_id(self, machine: StateMachine) -> None:
        session = machine.create(entity_id="order-42")
        assert session.entity_id == "order-42"

    def test_auto_generated_entity_id(self, machine: StateMachine) -> None:
        session = machine.create()
        # Should be a valid UUID
        parsed = uuid.UUID(session.entity_id)
        assert str(parsed) == session.entity_id

    def test_entity_id_in_snapshot(self, machine: StateMachine) -> None:
        session = machine.create(entity_id="snap-1")
        snap = session.snapshot()
        assert snap["entity_id"] == "snap-1"

    def test_entity_id_restored_from_snapshot(self, machine: StateMachine) -> None:
        session = machine.create(entity_id="restore-1")
        session.send("start")
        snap = session.snapshot()

        restored = EntitySession.from_snapshot(machine, snap)
        assert restored.entity_id == "restore-1"
        assert restored.current_state == "active"

    def test_old_snapshot_without_entity_id(self, machine: StateMachine) -> None:
        """Snapshots from before this change (no entity_id key) get a UUID."""
        old_snap = {
            "current_state": "pending",
            "context": {},
            "machine_name": "test_simple",
            "machine_version": "1.0.0",
        }
        restored = EntitySession.from_snapshot(machine, old_snap)
        # Should auto-generate a UUID
        uuid.UUID(restored.entity_id)

    def test_entity_id_in_repr(self, machine: StateMachine) -> None:
        session = machine.create(entity_id="repr-1")
        r = repr(session)
        assert "repr-1" in r
        assert "test_simple" in r

    def test_two_sessions_different_ids(self, machine: StateMachine) -> None:
        s1 = machine.create()
        s2 = machine.create()
        assert s1.entity_id != s2.entity_id


# ------------------------------------------------------------------
# Change 2: Orchestrator.machine and Orchestrator.store properties
# ------------------------------------------------------------------


class TestOrchestratorProperties:
    """Orchestrator exposes .machine and .store as read-only properties."""

    def test_machine_property(self, machine: StateMachine) -> None:
        store = InMemoryStateStore()
        orch = Orchestrator(machine, store)
        assert orch.machine is machine

    def test_store_property(self, machine: StateMachine) -> None:
        store = InMemoryStateStore()
        orch = Orchestrator(machine, store)
        assert orch.store is store


# ------------------------------------------------------------------
# Change 3: machine.orchestrate(store)
# ------------------------------------------------------------------


class TestOrchestrateFactory:
    """StateMachine.orchestrate() — one-line Orchestrator creation."""

    def test_basic_orchestrate(self, machine: StateMachine) -> None:
        store = InMemoryStateStore()
        orch = machine.orchestrate(store)
        assert isinstance(orch, Orchestrator)
        assert orch.machine is machine
        assert orch.store is store

    def test_orchestrate_uses_machine_registries(self, machine: StateMachine) -> None:
        """Guards/actions registered via decorators should work."""
        called = []

        @machine.action("log_start")
        def log_start(ctx: dict) -> None:
            called.append("started")

        store = InMemoryStateStore()
        orch = machine.orchestrate(store)
        # Process an event through the orchestrator
        result = orch.process_event("entity-1", "start")
        assert result.success
        assert result.target_state == "active"

    def test_orchestrate_process_full_flow(self, machine: StateMachine) -> None:
        store = InMemoryStateStore()
        orch = machine.orchestrate(store)

        r1 = orch.process_event("e1", "start")
        assert r1.success
        assert r1.target_state == "active"

        r2 = orch.process_event("e1", "finish")
        assert r2.success
        assert r2.target_state == "done"

    def test_orchestrate_with_hooks(self, machine: StateMachine) -> None:
        from pystator import LoggingHook

        store = InMemoryStateStore()
        orch = machine.orchestrate(store, hooks=[LoggingHook()])
        result = orch.process_event("e1", "start")
        assert result.success


# ------------------------------------------------------------------
# Change 4: Trimmed __all__
# ------------------------------------------------------------------


class TestTrimmedAll:
    """Symbols removed from __all__ are still importable."""

    def test_guard_spec_importable(self) -> None:
        from pystator import GuardSpec  # noqa: F401

    def test_action_spec_importable(self) -> None:
        from pystator import ActionSpec  # noqa: F401

    def test_guard_combinators_importable(self) -> None:
        from pystator import all_of, any_of, negate  # noqa: F401

    def test_lint_importable(self) -> None:
        from pystator import LintWarning, lint  # noqa: F401

    def test_sinks_importable(self) -> None:
        from pystator import EventSink, MetricSink  # noqa: F401

    def test_advanced_hooks_importable(self) -> None:
        from pystator import (  # noqa: F401
            MetricsCollector,
            TransitionObserver,
        )

    def test_submodule_imports_work(self) -> None:
        from pystator.guards import all_of, any_of  # noqa: F401
        from pystator.lint import LintWarning, lint  # noqa: F401
        from pystator.sinks import EventSink  # noqa: F401

    def test_core_symbols_in_all(self) -> None:
        import pystator

        expected_core = [
            "StateMachine",
            "EntitySession",
            "Orchestrator",
            "InMemoryStateStore",
            "TransitionResult",
            "Event",
            "FSMError",
            "GuardRegistry",
            "ActionRegistry",
        ]
        for sym in expected_core:
            assert sym in pystator.__all__, f"{sym} should be in __all__"

    def test_removed_symbols_not_in_all(self) -> None:
        import pystator

        removed = [
            "GuardSpec",
            "ActionSpec",
            "EFFECT_TYPES",
            "all_of",
            "any_of",
            "negate",
            "lint",
            "LintWarning",
            "EventSink",
            "MetricSink",
            "GuardEvaluator",
            "ActionExecutor",
        ]
        for sym in removed:
            assert sym not in pystator.__all__, f"{sym} should not be in __all__"
