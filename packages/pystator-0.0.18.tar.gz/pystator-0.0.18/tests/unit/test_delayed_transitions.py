"""Tests for delayed transitions (`after` support)."""

import pytest

from pystator import ActionSpec, GuardSpec, Transition
from pystator._types import parse_delay


class TestParseDelay:
    """Tests for delay parsing."""

    def test_parse_integer_milliseconds(self):
        """Integer values are treated as milliseconds."""
        assert parse_delay(1000) == 1000
        assert parse_delay(5000) == 5000
        assert parse_delay(1) == 1

    def test_parse_string_milliseconds(self):
        """String without unit is treated as milliseconds."""
        assert parse_delay("1000") == 1000
        assert parse_delay("5000") == 5000

    def test_parse_seconds(self):
        """String with 's' suffix is treated as seconds."""
        assert parse_delay("5s") == 5000
        assert parse_delay("30s") == 30000
        assert parse_delay("1s") == 1000

    def test_parse_minutes(self):
        """String with 'm' suffix is treated as minutes."""
        assert parse_delay("5m") == 5 * 60 * 1000
        assert parse_delay("30m") == 30 * 60 * 1000
        assert parse_delay("1m") == 60 * 1000

    def test_parse_hours(self):
        """String with 'h' suffix is treated as hours."""
        assert parse_delay("1h") == 3600 * 1000
        assert parse_delay("24h") == 24 * 3600 * 1000

    def test_invalid_delay_raises(self):
        """Invalid delay values raise ValueError."""
        with pytest.raises(ValueError):
            parse_delay("invalid")


class TestTransitionWithDelay:
    """Tests for Transition with after field."""

    def test_transition_with_delay(self):
        """Transition can have an after delay."""
        trans = Transition(
            trigger="timeout",
            source=frozenset({"waiting"}),
            dest="retry",
            after=5000,
        )
        assert trans.after == 5000
        assert trans.is_delayed is True

    def test_transition_without_delay(self):
        """Transition without after is not delayed."""
        trans = Transition(
            trigger="submit",
            source=frozenset({"new"}),
            dest="pending",
        )
        assert trans.after is None
        assert trans.is_delayed is False

    def test_transition_delay_validation(self):
        """Negative delay raises ValueError."""
        with pytest.raises(ValueError, match="non-negative"):
            Transition(
                trigger="timeout",
                source=frozenset({"waiting"}),
                dest="retry",
                after=-1000,
            )

    def test_from_single_source_with_delay(self):
        """from_single_source supports after parameter."""
        trans = Transition.from_single_source(
            trigger="expire",
            source="pending",
            dest="cancelled",
            after=30000,
        )
        assert trans.after == 30000
        assert trans.is_delayed is True


class TestGuardSpec:
    """Tests for GuardSpec."""

    def test_named_guard(self):
        """GuardSpec with named function."""
        guard = GuardSpec(name="is_valid")
        assert guard.name == "is_valid"
        assert guard.expr is None
        assert guard.is_expression is False

    def test_expression_guard(self):
        """GuardSpec with inline expression."""
        guard = GuardSpec(expr="qty > 0")
        assert guard.name is None
        assert guard.expr == "qty > 0"
        assert guard.is_expression is True

    def test_guard_requires_name_or_expr(self):
        """GuardSpec must have either name, expr, or check."""
        with pytest.raises(ValueError, match="must have 'name', 'expr', 'check'"):
            GuardSpec()

    def test_guard_cannot_have_both(self):
        """GuardSpec cannot have both name and expr."""
        with pytest.raises(ValueError, match="can only have one"):
            GuardSpec(name="is_valid", expr="qty > 0")

    def test_from_config_string(self):
        """GuardSpec.from_config handles string input."""
        guard = GuardSpec.from_config("is_valid")
        assert guard.name == "is_valid"
        assert guard.is_expression is False

    def test_from_config_dict_expr(self):
        """GuardSpec.from_config handles dict with expr."""
        guard = GuardSpec.from_config({"expr": "qty > 0"})
        assert guard.expr == "qty > 0"
        assert guard.is_expression is True


class TestActionSpec:
    """Tests for ActionSpec."""

    def test_simple_action(self):
        """ActionSpec with just a name."""
        action = ActionSpec(name="log_event")
        assert action.name == "log_event"
        assert action.params == {}
        assert action.has_params is False

    def test_parameterized_action(self):
        """ActionSpec with parameters."""
        action = ActionSpec(
            name="send_notification",
            params={"channel": "slack", "priority": "high"},
        )
        assert action.name == "send_notification"
        assert action.params == {"channel": "slack", "priority": "high"}
        assert action.has_params is True

    def test_action_requires_name(self):
        """ActionSpec must have a name."""
        with pytest.raises(ValueError, match="must have a 'name'"):
            ActionSpec(name="")

    def test_from_config_string(self):
        """ActionSpec.from_config handles string input."""
        action = ActionSpec.from_config("log_event")
        assert action.name == "log_event"
        assert action.has_params is False

    def test_from_config_dict(self):
        """ActionSpec.from_config handles dict with name and params."""
        action = ActionSpec.from_config(
            {
                "name": "send_notification",
                "params": {"channel": "email"},
            }
        )
        assert action.name == "send_notification"
        assert action.params == {"channel": "email"}


class TestTransitionWithNewTypes:
    """Tests for Transition with GuardSpec and ActionSpec."""

    def test_transition_with_guard_specs(self):
        """Transition with GuardSpec objects."""
        trans = Transition(
            trigger="fill",
            source=frozenset({"open"}),
            dest="filled",
            guards=(
                GuardSpec(name="is_valid_order"),
                GuardSpec(expr="fill_qty >= order_qty"),
            ),
        )
        assert len(trans.guards) == 2
        assert trans.guards[0].name == "is_valid_order"
        assert trans.guards[1].expr == "fill_qty >= order_qty"
        assert trans.has_guards() is True
        assert trans.has_expression_guards() is True
        assert trans.guard_names == ("is_valid_order",)

    def test_transition_with_action_specs(self):
        """Transition with ActionSpec objects."""
        trans = Transition(
            trigger="fill",
            source=frozenset({"open"}),
            dest="filled",
            actions=(
                ActionSpec(name="log_fill"),
                ActionSpec(name="notify", params={"channel": "slack"}),
            ),
        )
        assert len(trans.actions) == 2
        assert trans.actions[0].name == "log_fill"
        assert trans.actions[1].params == {"channel": "slack"}
        assert trans.action_names == ("log_fill", "notify")


class TestImplicitTriggerForDelayedTransition:
    """Tests for delayed transitions with no explicit trigger (loader assigns synthetic trigger)."""

    def test_loader_assigns_implicit_trigger_when_only_after(self):
        """When transition has only after and dest (no trigger), loader assigns synthetic trigger."""
        from pystator.config.loader import ConfigLoader

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "waiting"}, {"name": "retry"}],
            "transitions": [
                {"source": "waiting", "dest": "retry", "after": 5000},
            ],
        }
        _, transitions, _ = loader.parse(config)
        assert len(transitions) == 1
        assert transitions[0].trigger == "_after_waiting_5000_ms"
        assert transitions[0].after == 5000
        assert transitions[0].source == frozenset({"waiting"})
        assert transitions[0].dest == "retry"

    def test_loader_implicit_trigger_requires_single_source(self):
        """Delayed transition with implicit trigger must have exactly one source."""
        from pystator.config.loader import ConfigLoader
        from pystator.errors import ConfigurationError

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}, {"name": "c"}],
            "transitions": [
                {"source": ["a", "b"], "dest": "c", "after": 1000},
            ],
        }
        with pytest.raises(ConfigurationError, match="exactly one source"):
            loader.parse(config)

    def test_loader_transition_without_trigger_or_after_raises(self):
        """Transition must have either trigger or after."""
        from pystator.config.loader import ConfigLoader
        from pystator.errors import ConfigurationError

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}],
            "transitions": [
                {"source": "a", "dest": "b"},
            ],
        }
        with pytest.raises(ConfigurationError, match="trigger.*after"):
            loader.parse(config)

    def test_validator_requires_trigger_or_after(self):
        """Validator reports error when transition has neither trigger nor after."""
        from pystator.config.validator import ConfigValidator

        validator = ConfigValidator()
        config = {
            "states": [{"name": "a", "type": "initial"}, {"name": "b"}],
            "transitions": [
                {"source": "a", "dest": "b"},
            ],
        }
        errors = validator.validate(config)
        assert any(
            ("trigger" in e and "after" in e) or "trigger" in e or "after" in e
            for e in errors
        )
