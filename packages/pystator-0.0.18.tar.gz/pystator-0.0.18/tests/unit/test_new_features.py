"""Tests for new PyStator v2 features:
- Internal transitions
- Automatic (eventless) transitions
- History pseudo-states (H / H*)
- EntitySession API
- Decorator binding
"""

from __future__ import annotations

import pytest

from pystator import EntitySession, StateMachine

# ---------------------------------------------------------------------------
# Internal transitions
# ---------------------------------------------------------------------------


class TestInternalTransitions:
    """Internal transitions skip exit/enter actions."""

    @pytest.fixture
    def machine(self) -> StateMachine:
        return StateMachine.from_dict(
            {
                "meta": {"machine_name": "internal_test", "strict_mode": False},
                "states": [
                    {
                        "name": "active",
                        "type": "initial",
                        "on_enter": ["enter_active"],
                        "on_exit": ["exit_active"],
                    },
                    {"name": "done", "type": "terminal"},
                ],
                "transitions": [
                    {
                        "trigger": "tick",
                        "source": "active",
                        "dest": "active",
                        "internal": True,
                        "actions": ["count"],
                    },
                    {
                        "trigger": "finish",
                        "source": "active",
                        "dest": "done",
                    },
                ],
            }
        )

    def test_internal_skips_exit_enter(self, machine: StateMachine) -> None:
        result = machine.process("active", "tick")
        assert result.success
        assert result.target_state == "active"
        assert result.on_exit_actions == ()
        assert result.on_enter_actions == ()
        assert len(result.actions_to_execute) == 1
        assert result.actions_to_execute[0].name == "count"

    def test_normal_transition_has_exit_enter(self, machine: StateMachine) -> None:
        result = machine.process("active", "finish")
        assert result.success
        assert result.target_state == "done"
        assert len(result.on_exit_actions) == 1
        assert result.on_exit_actions[0].name == "exit_active"

    def test_internal_via_instance(self, machine: StateMachine) -> None:
        inst = machine.create()
        assert inst.current_state == "active"
        result = inst.send("tick")
        assert result.success
        assert inst.current_state == "active"


# ---------------------------------------------------------------------------
# Automatic (eventless) transitions
# ---------------------------------------------------------------------------


class TestAutoTransitions:
    """Auto transitions fire on state entry when guards pass."""

    @pytest.fixture
    def machine(self) -> StateMachine:
        m = StateMachine.from_dict(
            {
                "meta": {"machine_name": "auto_test", "strict_mode": False},
                "states": [
                    {"name": "start", "type": "initial"},
                    {"name": "checking", "type": "stable"},
                    {"name": "approved", "type": "stable"},
                    {"name": "rejected", "type": "terminal"},
                ],
                "transitions": [
                    {"trigger": "submit", "source": "start", "dest": "checking"},
                    {
                        "source": "checking",
                        "dest": "approved",
                        "auto": True,
                        "guards": ["is_approved"],
                    },
                    {
                        "source": "checking",
                        "dest": "rejected",
                        "auto": True,
                        "guards": ["is_rejected"],
                    },
                ],
            }
        )

        @m.guard("is_approved")
        def _approved(ctx: dict) -> bool:
            return ctx.get("score", 0) >= 80

        @m.guard("is_rejected")
        def _rejected(ctx: dict) -> bool:
            return ctx.get("score", 0) < 80

        return m

    def test_auto_fires_on_entry_approved(self, machine: StateMachine) -> None:
        inst = machine.create(context={"score": 90})
        inst.send("submit")
        assert inst.current_state == "approved"

    def test_auto_fires_on_entry_rejected(self, machine: StateMachine) -> None:
        inst = machine.create(context={"score": 50})
        inst.send("submit")
        assert inst.current_state == "rejected"

    def test_auto_does_not_fire_when_guards_fail(self) -> None:
        m = StateMachine.from_dict(
            {
                "meta": {"machine_name": "auto_noop", "strict_mode": False},
                "states": [
                    {"name": "a", "type": "initial"},
                    {"name": "b", "type": "stable"},
                    {"name": "c", "type": "terminal"},
                ],
                "transitions": [
                    {"trigger": "go", "source": "a", "dest": "b"},
                    {
                        "source": "b",
                        "dest": "c",
                        "auto": True,
                        "guards": ["never"],
                    },
                ],
            }
        )

        @m.guard("never")
        def _never(ctx: dict) -> bool:
            return False

        inst = m.create()
        inst.send("go")
        # Auto transition guard fails, should stay in b
        assert inst.current_state == "b"


# ---------------------------------------------------------------------------
# History pseudo-states
# ---------------------------------------------------------------------------


class TestHistoryStates:
    """History destinations H(Parent) and H*(Parent)."""

    @pytest.fixture
    def machine(self) -> StateMachine:
        return StateMachine.from_dict(
            {
                "meta": {"machine_name": "history_test", "strict_mode": False},
                "states": [
                    {"name": "off", "type": "initial"},
                    {"name": "on", "type": "stable", "initial_child": "idle"},
                    {"name": "idle", "type": "stable", "parent": "on"},
                    {"name": "working", "type": "stable", "parent": "on"},
                    {"name": "paused", "type": "stable"},
                ],
                "transitions": [
                    {"trigger": "power_on", "source": "off", "dest": "on"},
                    {"trigger": "start_work", "source": "idle", "dest": "working"},
                    {"trigger": "stop_work", "source": "working", "dest": "idle"},
                    {
                        "trigger": "pause",
                        "source": ["idle", "working"],
                        "dest": "paused",
                    },
                    {"trigger": "resume", "source": "paused", "dest": "H(on)"},
                    {
                        "trigger": "power_off",
                        "source": ["idle", "working", "paused"],
                        "dest": "off",
                    },
                ],
            }
        )

    def test_history_remembers_working(self, machine: StateMachine) -> None:
        inst = machine.create()
        inst.send("power_on")  # -> idle
        inst.send("start_work")  # -> working
        inst.send("pause")  # -> paused
        inst.send("resume")  # -> working (via history)
        assert inst.current_state == "working"

    def test_history_remembers_idle(self, machine: StateMachine) -> None:
        inst = machine.create()
        inst.send("power_on")  # -> idle
        inst.send("pause")  # -> paused
        inst.send("resume")  # -> idle (via history)
        assert inst.current_state == "idle"

    def test_history_fallback_to_initial(self, machine: StateMachine) -> None:
        """When no history exists, fall back to initial_child."""
        # Directly process: paused -> H(on) with no prior history
        result = machine.process("paused", "resume")
        assert result.success
        # Should resolve to idle (initial child of on)
        assert result.target_state == "idle"


# ---------------------------------------------------------------------------
# EntitySession API
# ---------------------------------------------------------------------------


class TestEntitySession:
    """Tests for the stateful EntitySession wrapper."""

    @pytest.fixture
    def machine(self) -> StateMachine:
        return StateMachine.from_dict(
            {
                "meta": {"machine_name": "instance_test", "strict_mode": False},
                "states": [
                    {"name": "pending", "type": "initial"},
                    {"name": "confirmed", "type": "stable"},
                    {"name": "shipped", "type": "stable"},
                    {"name": "delivered", "type": "terminal"},
                    {"name": "cancelled", "type": "terminal"},
                ],
                "transitions": [
                    {"trigger": "confirm", "source": "pending", "dest": "confirmed"},
                    {"trigger": "ship", "source": "confirmed", "dest": "shipped"},
                    {"trigger": "deliver", "source": "shipped", "dest": "delivered"},
                    {
                        "trigger": "cancel",
                        "source": ["pending", "confirmed"],
                        "dest": "cancelled",
                    },
                ],
            }
        )

    def test_initial_state(self, machine: StateMachine) -> None:
        inst = machine.create()
        assert inst.current_state == "pending"

    def test_send(self, machine: StateMachine) -> None:
        inst = machine.create()
        result = inst.send("confirm")
        assert result.success
        assert inst.current_state == "confirmed"

    def test_trigger_method(self, machine: StateMachine) -> None:
        inst = machine.create()
        result = inst.confirm()
        assert result.success
        assert inst.current_state == "confirmed"

    def test_is_state_properties(self, machine: StateMachine) -> None:
        inst = machine.create()
        assert inst.is_pending is True
        assert inst.is_confirmed is False

        inst.send("confirm")
        assert inst.is_pending is False
        assert inst.is_confirmed is True

    def test_is_final(self, machine: StateMachine) -> None:
        inst = machine.create()
        assert inst.is_final is False

        inst.send("confirm")
        inst.send("ship")
        inst.send("deliver")
        assert inst.is_final is True

    def test_allowed_triggers(self, machine: StateMachine) -> None:
        inst = machine.create()
        assert "confirm" in inst.allowed_triggers
        assert "cancel" in inst.allowed_triggers

    def test_snapshot_and_restore(self, machine: StateMachine) -> None:
        inst = machine.create(context={"order_id": "42"})
        inst.send("confirm")
        snap = inst.snapshot()

        restored = EntitySession.from_snapshot(machine, snap)
        assert restored.current_state == "confirmed"
        assert restored.context["order_id"] == "42"

    def test_history(self, machine: StateMachine) -> None:
        inst = machine.create()
        inst.send("confirm")
        inst.send("ship")
        assert len(inst.history) == 2

    def test_custom_initial_state(self, machine: StateMachine) -> None:
        inst = machine.create(initial_state="confirmed")
        assert inst.current_state == "confirmed"

    def test_context_mutable(self, machine: StateMachine) -> None:
        inst = machine.create(context={"key": "value"})
        inst.context["key"] = "updated"
        assert inst.context["key"] == "updated"


# ---------------------------------------------------------------------------
# Decorator binding
# ---------------------------------------------------------------------------


class TestDecoratorBinding:
    """Tests for @machine.guard and @machine.action decorators."""

    def test_guard_decorator(self) -> None:
        m = StateMachine.from_dict(
            {
                "meta": {"machine_name": "deco_test", "strict_mode": True},
                "states": [
                    {"name": "a", "type": "initial"},
                    {"name": "b", "type": "terminal"},
                ],
                "transitions": [
                    {"trigger": "go", "source": "a", "dest": "b", "guards": ["check"]},
                ],
            }
        )

        @m.guard("check")
        def check(ctx: dict) -> bool:
            return ctx.get("ok", False)

        result = m.process("a", "go", {"ok": True})
        assert result.success

        result2 = m.process("a", "go", {"ok": False})
        assert not result2.success

    def test_action_decorator(self) -> None:
        executed = []
        m = StateMachine.from_dict(
            {
                "meta": {"machine_name": "action_deco", "strict_mode": False},
                "states": [
                    {"name": "a", "type": "initial"},
                    {"name": "b", "type": "terminal"},
                ],
                "transitions": [
                    {"trigger": "go", "source": "a", "dest": "b", "actions": ["do_it"]},
                ],
            }
        )

        @m.action("do_it")
        def do_it(ctx: dict) -> None:
            executed.append("done")

        # Action isn't executed by process (stateless), but it should be registered
        assert m.action_registry.has("do_it")
