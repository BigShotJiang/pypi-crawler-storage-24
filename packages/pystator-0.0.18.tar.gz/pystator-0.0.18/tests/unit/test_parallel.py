"""Unit tests for parallel state (orthogonal regions) support."""

import pytest

from pystator import Region, State, StateType
from pystator._parallel import ParallelStateConfig, ParallelStateManager


class TestRegion:
    """Tests for Region dataclass."""

    def test_region_creation(self):
        """Test basic region creation."""
        region = Region(
            name="trading",
            initial="scanning",
            states=("scanning", "analyzing", "executing"),
            description="Trading workflow region",
        )

        assert region.name == "trading"
        assert region.initial == "scanning"
        assert region.states == ("scanning", "analyzing", "executing")
        assert region.description == "Trading workflow region"

    def test_region_empty_name_raises(self):
        """Test that empty name raises ValueError."""
        with pytest.raises(ValueError, match="cannot be empty"):
            Region(name="", initial="scanning")

    def test_region_empty_initial_raises(self):
        """Test that empty initial raises ValueError."""
        with pytest.raises(ValueError, match="must have an initial"):
            Region(name="trading", initial="")

    def test_region_initial_not_in_states_raises(self):
        """Test that initial not in states list raises ValueError."""
        with pytest.raises(ValueError, match="must be in states"):
            Region(
                name="trading",
                initial="scanning",
                states=("analyzing", "executing"),  # missing scanning
            )

    def test_region_invalid_name_raises(self):
        """Test that invalid name format raises ValueError."""
        with pytest.raises(ValueError, match="must contain only lowercase letters"):
            Region(name="invalid!", initial="scanning")

    def test_region_numeric_name_ok(self):
        """Test that numeric-only region names are accepted."""
        region = Region(name="123", initial="scanning")
        assert region.name == "123"

    def test_region_contains(self):
        """Test region contains method."""
        region = Region(
            name="trading",
            initial="scanning",
            states=("scanning", "analyzing"),
        )

        assert region.contains("scanning") is True
        assert region.contains("analyzing") is True
        assert region.contains("executing") is False

    def test_region_empty_states_no_validation(self):
        """Test that empty states list doesn't validate initial."""
        # When states is empty, no validation against it
        region = Region(name="trading", initial="any_state", states=())
        assert region.initial == "any_state"


class TestParallelStateConfig:
    """Tests for ParallelStateConfig."""

    def test_config_creation(self):
        """Test basic config creation."""
        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        assert config.parallel_state == "active"
        assert config.region_states == {"trading": "scanning", "risk": "normal"}

    def test_get_region_state(self):
        """Test getting state for a specific region."""
        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        assert config.get_region_state("trading") == "scanning"
        assert config.get_region_state("risk") == "normal"
        assert config.get_region_state("unknown") is None

    def test_is_in_state(self):
        """Test checking if any region is in a state."""
        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        assert config.is_in_state("scanning") is True
        assert config.is_in_state("normal") is True
        assert config.is_in_state("executing") is False

    def test_get_all_active(self):
        """Test getting all active states."""
        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        active = config.get_all_active()
        assert "scanning" in active
        assert "normal" in active
        assert len(active) == 2

    def test_with_region_state(self):
        """Test creating new config with updated region state."""
        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        new_config = config.with_region_state("trading", "analyzing")

        # Original unchanged
        assert config.get_region_state("trading") == "scanning"
        # New config updated
        assert new_config.get_region_state("trading") == "analyzing"
        assert new_config.get_region_state("risk") == "normal"

    def test_contains(self):
        """Test contains method."""
        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        assert config.contains("active") is True  # parallel state itself
        assert config.contains("scanning") is True
        assert config.contains("normal") is True
        assert config.contains("unknown") is False

    def test_to_string(self):
        """Test string serialization."""
        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        s = config.to_string()
        # Should contain parallel state and regions
        assert "active:" in s
        assert "trading=scanning" in s
        assert "risk=normal" in s

    def test_from_string(self):
        """Test parsing from string."""
        config = ParallelStateConfig.from_string("active:trading=scanning,risk=normal")

        assert config.parallel_state == "active"
        assert config.get_region_state("trading") == "scanning"
        assert config.get_region_state("risk") == "normal"

    def test_from_string_no_regions(self):
        """Test parsing string with no regions."""
        config = ParallelStateConfig.from_string("simple_state")

        assert config.parallel_state == "simple_state"
        assert config.region_states == {}

    def test_roundtrip_serialization(self):
        """Test that to_string -> from_string preserves data."""
        original = ParallelStateConfig(
            parallel_state="active",
            region_states={
                "trading": "scanning",
                "risk": "normal",
                "data": "connected",
            },
        )

        serialized = original.to_string()
        parsed = ParallelStateConfig.from_string(serialized)

        assert parsed.parallel_state == original.parallel_state
        assert parsed.region_states == original.region_states


class TestParallelStateManager:
    """Tests for ParallelStateManager."""

    @pytest.fixture
    def trading_states(self) -> dict[str, State]:
        """Create a set of states with a parallel state."""
        return {
            "pre_market": State(name="pre_market", type=StateType.INITIAL),
            "active": State(
                name="active",
                type=StateType.PARALLEL,
                regions=(
                    Region(
                        name="trading",
                        initial="scanning",
                        states=("scanning", "analyzing", "executing"),
                    ),
                    Region(
                        name="risk",
                        initial="normal",
                        states=("normal", "elevated", "critical"),
                    ),
                ),
            ),
            "scanning": State(name="scanning", parent="active"),
            "analyzing": State(name="analyzing", parent="active"),
            "executing": State(name="executing", parent="active"),
            "normal": State(name="normal", parent="active"),
            "elevated": State(name="elevated", parent="active"),
            "critical": State(name="critical", parent="active"),
            "halted": State(name="halted", type=StateType.TERMINAL),
        }

    def test_is_parallel_state(self, trading_states):
        """Test identifying parallel states."""
        manager = ParallelStateManager(trading_states)

        assert manager.is_parallel_state("active") is True
        assert manager.is_parallel_state("pre_market") is False
        assert manager.is_parallel_state("scanning") is False

    def test_get_parallel_state(self, trading_states):
        """Test getting parallel state."""
        manager = ParallelStateManager(trading_states)

        state = manager.get_parallel_state("active")
        assert state is not None
        assert state.name == "active"
        assert state.is_parallel

        assert manager.get_parallel_state("pre_market") is None

    def test_enter_parallel_state(self, trading_states):
        """Test entering a parallel state."""
        manager = ParallelStateManager(trading_states)

        config = manager.enter_parallel_state("active")

        assert config.parallel_state == "active"
        assert config.get_region_state("trading") == "scanning"
        assert config.get_region_state("risk") == "normal"

    def test_enter_non_parallel_raises(self, trading_states):
        """Test that entering non-parallel state raises."""
        manager = ParallelStateManager(trading_states)

        with pytest.raises(ValueError, match="not a parallel state"):
            manager.enter_parallel_state("pre_market")

    def test_exit_parallel_state(self, trading_states):
        """Test getting exit order from parallel state."""
        manager = ParallelStateManager(trading_states)

        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "analyzing", "risk": "elevated"},
        )

        exit_order = manager.exit_parallel_state(config)

        # Should contain region states and parallel state
        assert "analyzing" in exit_order
        assert "elevated" in exit_order
        assert "active" in exit_order
        # Parallel state should be last
        assert exit_order[-1] == "active"

    def test_process_region_transition(self, trading_states):
        """Test processing a transition within a region."""
        manager = ParallelStateManager(trading_states)

        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        new_config = manager.process_region_transition(config, "trading", "analyzing")

        assert new_config.get_region_state("trading") == "analyzing"
        assert new_config.get_region_state("risk") == "normal"

    def test_process_region_transition_invalid_state(self, trading_states):
        """Test that invalid state raises."""
        manager = ParallelStateManager(trading_states)

        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        with pytest.raises(ValueError, match="not valid for region"):
            manager.process_region_transition(config, "trading", "unknown_state")

    def test_find_region_for_state(self, trading_states):
        """Test finding which region contains a state."""
        manager = ParallelStateManager(trading_states)

        assert manager.find_region_for_state("active", "scanning") == "trading"
        assert manager.find_region_for_state("active", "normal") == "risk"
        assert manager.find_region_for_state("active", "unknown") is None

    def test_validate_config_valid(self, trading_states):
        """Test validating a valid config."""
        manager = ParallelStateManager(trading_states)

        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning", "risk": "normal"},
        )

        errors = manager.validate_config(config)
        assert errors == []

    def test_validate_config_missing_region(self, trading_states):
        """Test validating config with missing region."""
        manager = ParallelStateManager(trading_states)

        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "scanning"},  # missing risk
        )

        errors = manager.validate_config(config)
        assert any("Missing regions" in e for e in errors)

    def test_validate_config_invalid_state(self, trading_states):
        """Test validating config with invalid state."""
        manager = ParallelStateManager(trading_states)

        config = ParallelStateConfig(
            parallel_state="active",
            region_states={"trading": "invalid_state", "risk": "normal"},
        )

        errors = manager.validate_config(config)
        assert any("Invalid state" in e for e in errors)


class TestParallelStateInState:
    """Test State class with parallel type."""

    def test_parallel_state_requires_regions(self):
        """Test that parallel state requires regions."""
        with pytest.raises(ValueError, match="must have at least one region"):
            State(name="active", type=StateType.PARALLEL)

    def test_non_parallel_cannot_have_regions(self):
        """Test that non-parallel state cannot have regions."""
        with pytest.raises(ValueError, match="cannot have regions"):
            State(
                name="active",
                type=StateType.STABLE,
                regions=(Region(name="trading", initial="scanning"),),
            )

    def test_parallel_state_properties(self):
        """Test parallel state properties."""
        state = State(
            name="active",
            type=StateType.PARALLEL,
            regions=(
                Region(name="trading", initial="scanning"),
                Region(name="risk", initial="normal"),
            ),
        )

        assert state.is_parallel is True
        assert state.is_leaf is False
        assert state.region_names == ("trading", "risk")
        assert state.get_region("trading") is not None
        assert state.get_region("trading").initial == "scanning"
        assert state.get_region("unknown") is None

    def test_duplicate_region_names_raises(self):
        """Test that duplicate region names raise."""
        with pytest.raises(ValueError, match="duplicate region names"):
            State(
                name="active",
                type=StateType.PARALLEL,
                regions=(
                    Region(name="trading", initial="scanning"),
                    Region(name="trading", initial="analyzing"),  # duplicate
                ),
            )
