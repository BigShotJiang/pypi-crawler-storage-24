"""Tests for pystator.shared.name_validator module."""

from __future__ import annotations

import pytest

from pystator.shared.name_validator import is_valid_name, normalize_name, validate_name

# ---------------------------------------------------------------------------
# validate_name
# ---------------------------------------------------------------------------


class TestValidateName:
    """Tests for validate_name()."""

    def test_valid_lowercase_name(self) -> None:
        assert validate_name("order_lifecycle") == "order_lifecycle"

    def test_valid_name_with_numbers(self) -> None:
        assert validate_name("fsm_v2") == "fsm_v2"

    def test_valid_all_numbers(self) -> None:
        assert validate_name("123") == "123"

    def test_valid_single_char(self) -> None:
        assert validate_name("a") == "a"

    def test_uppercase_normalized(self) -> None:
        assert validate_name("UPPER") == "upper"

    def test_mixed_case_normalized(self) -> None:
        assert validate_name("MyMachine") == "mymachine"

    def test_has_dash_raises(self) -> None:
        with pytest.raises(ValueError, match="must contain only lowercase"):
            validate_name("has-dash")

    def test_has_spaces_raises(self) -> None:
        with pytest.raises(ValueError, match="must contain only lowercase"):
            validate_name("has spaces")

    def test_empty_string_raises(self) -> None:
        with pytest.raises(ValueError, match="cannot be empty"):
            validate_name("")

    def test_whitespace_only_raises(self) -> None:
        with pytest.raises(ValueError, match="cannot be empty"):
            validate_name("   ")

    def test_non_string_raises(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            validate_name(123)  # type: ignore[arg-type]

    def test_none_raises(self) -> None:
        with pytest.raises(ValueError, match="must be a string"):
            validate_name(None)  # type: ignore[arg-type]

    def test_special_chars_raise(self) -> None:
        with pytest.raises(ValueError, match="must contain only lowercase"):
            validate_name("hello@world")

    def test_custom_field_name_in_error(self) -> None:
        with pytest.raises(ValueError, match="machine_name"):
            validate_name("bad-name", field_name="machine_name")

    def test_leading_trailing_whitespace_stripped(self) -> None:
        assert validate_name("  valid_name  ") == "valid_name"


# ---------------------------------------------------------------------------
# is_valid_name
# ---------------------------------------------------------------------------


class TestIsValidName:
    """Tests for is_valid_name()."""

    def test_valid_name(self) -> None:
        assert is_valid_name("valid123") is True

    def test_valid_underscores(self) -> None:
        assert is_valid_name("my_machine_v1") is True

    def test_uppercase_valid_after_normalization(self) -> None:
        # validate_name normalizes to lowercase, so "UPPER" → "upper" is valid
        assert is_valid_name("UPPER") is True

    def test_dash_invalid(self) -> None:
        assert is_valid_name("has-dash") is False

    def test_space_invalid(self) -> None:
        assert is_valid_name("has space") is False

    def test_empty_invalid(self) -> None:
        assert is_valid_name("") is False

    def test_non_string_invalid(self) -> None:
        assert is_valid_name(42) is False  # type: ignore[arg-type]

    def test_none_invalid(self) -> None:
        assert is_valid_name(None) is False  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# normalize_name
# ---------------------------------------------------------------------------


class TestNormalizeName:
    """Tests for normalize_name()."""

    def test_already_valid(self) -> None:
        assert normalize_name("valid_name") == "valid_name"

    def test_spaces_to_underscores(self) -> None:
        assert normalize_name("My Machine") == "my_machine"

    def test_hyphens_to_underscores(self) -> None:
        assert normalize_name("my-machine") == "my_machine"

    def test_mixed_spaces_and_hyphens(self) -> None:
        assert normalize_name("my - machine") == "my_machine"

    def test_uppercase_lowered(self) -> None:
        assert normalize_name("UserSchema") == "userschema"

    def test_special_chars_removed(self) -> None:
        assert normalize_name("hello@world!") == "helloworld"

    def test_consecutive_underscores_collapsed(self) -> None:
        assert normalize_name("has__double") == "has_double"

    def test_leading_trailing_underscores_stripped(self) -> None:
        assert normalize_name("--leading--") == "leading"

    def test_empty_returns_none(self) -> None:
        assert normalize_name("") is None

    def test_non_string_returns_none(self) -> None:
        assert normalize_name(42) is None  # type: ignore[arg-type]

    def test_none_returns_none(self) -> None:
        assert normalize_name(None) is None  # type: ignore[arg-type]

    def test_only_special_chars_returns_none(self) -> None:
        assert normalize_name("@#$%") is None

    def test_complex_normalization(self) -> None:
        assert normalize_name("  My Cool-Machine v2.0  ") == "my_cool_machine_v20"
