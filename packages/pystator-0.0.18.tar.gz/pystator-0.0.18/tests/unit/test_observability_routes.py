"""Tests for observability API route handlers."""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from pystator.api.routes.v1.observability import (
    _compute_p95,
    get_observability_summary,
    list_observability_transitions,
    list_observability_worker_events,
)
from pystator.db.base import Base
from pystator.db.models import (
    EntityStateModel,
    TransitionHistoryModel,
    WorkerEventModel,
)


def _make_sqlite_session():
    """Create an in-memory SQLite session with pystator models initialized."""
    original_schemas = {table: table.schema for table in Base.metadata.tables.values()}
    for table in Base.metadata.tables.values():
        if table.schema == "pystator":
            table.schema = None

    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)

    SessionLocal = sessionmaker(bind=engine)
    session = SessionLocal()

    return session, engine, original_schemas


def _restore_schemas(original_schemas: dict):
    """Restore table schema metadata after sqlite tests."""
    for table, schema in original_schemas.items():
        table.schema = schema


def test_compute_p95() -> None:
    assert _compute_p95([]) is None
    assert _compute_p95([10]) == 10
    assert _compute_p95([10, 20, 30, 40, 50]) == 50
    assert _compute_p95([10, 20, 30, 40, 50, 60, 70, 80, 90, 100]) == 100


def test_observability_summary_filters_and_metrics() -> None:
    session, engine, original_schemas = _make_sqlite_session()
    now = datetime.now(UTC)

    try:
        session.add_all(
            [
                EntityStateModel(
                    entity_id="e1", machine_name="m1", current_state="open"
                ),
                EntityStateModel(
                    entity_id="e2", machine_name="m2", current_state="open"
                ),
            ]
        )

        session.add_all(
            [
                TransitionHistoryModel(
                    id=uuid.uuid4(),
                    entity_id="e1",
                    machine_name="m1",
                    source_state="s1",
                    target_state="s2",
                    trigger="go",
                    success=True,
                    created_at=now - timedelta(hours=1),
                    duration_ms=100,
                ),
                TransitionHistoryModel(
                    id=uuid.uuid4(),
                    entity_id="e1",
                    machine_name="m1",
                    source_state="s2",
                    target_state=None,
                    trigger="fail",
                    success=False,
                    error_message="boom",
                    created_at=now - timedelta(minutes=30),
                    duration_ms=300,
                ),
            ]
        )

        session.add_all(
            [
                WorkerEventModel(
                    id=uuid.uuid4(),
                    machine_name="m1",
                    entity_id="e1",
                    trigger="go",
                    status="pending",
                    fires_at=now,
                ),
                WorkerEventModel(
                    id=uuid.uuid4(),
                    machine_name="m1",
                    entity_id="e1",
                    trigger="go",
                    status="failed",
                    fires_at=now,
                ),
                WorkerEventModel(
                    id=uuid.uuid4(),
                    machine_name="m2",
                    entity_id="e2",
                    trigger="go",
                    status="dead_letter",
                    fires_at=now,
                ),
            ]
        )

        session.commit()

        summary = _run_async(
            get_observability_summary(
                session=session,
                window_hours=24,
                machine_name="m1",
                entity_id=None,
            )
        )

        assert summary.active_entities == 1
        assert summary.transitions_total == 2
        assert summary.transitions_failed == 1
        assert summary.transition_failure_rate == 0.5
        assert summary.p95_transition_duration_ms == 300
        assert summary.worker_pending == 1
        assert summary.worker_failed == 1
        assert summary.worker_dead_letter == 0
    finally:
        session.close()
        engine.dispose()
        _restore_schemas(original_schemas)


def test_observability_transitions_pagination_and_status_filter() -> None:
    session, engine, original_schemas = _make_sqlite_session()
    now = datetime.now(UTC)

    try:
        session.add_all(
            [
                TransitionHistoryModel(
                    id=uuid.uuid4(),
                    entity_id="e1",
                    machine_name="m1",
                    source_state="s1",
                    target_state="s2",
                    trigger="t1",
                    success=True,
                    created_at=now - timedelta(minutes=3),
                    duration_ms=10,
                ),
                TransitionHistoryModel(
                    id=uuid.uuid4(),
                    entity_id="e2",
                    machine_name="m1",
                    source_state="s1",
                    target_state=None,
                    trigger="t2",
                    success=False,
                    error_message="bad",
                    created_at=now - timedelta(minutes=2),
                    duration_ms=20,
                ),
                TransitionHistoryModel(
                    id=uuid.uuid4(),
                    entity_id="e3",
                    machine_name="m1",
                    source_state="s1",
                    target_state="s2",
                    trigger="t3",
                    success=True,
                    created_at=now - timedelta(minutes=1),
                    duration_ms=30,
                ),
            ]
        )
        session.commit()

        failed_only = _run_async(
            list_observability_transitions(
                session=session,
                machine_name="m1",
                entity_id=None,
                status="failed",
                start_at=None,
                end_at=None,
                limit=50,
                offset=0,
            )
        )
        assert failed_only.total == 1
        assert len(failed_only.items) == 1
        assert failed_only.items[0].success is False

        paged = _run_async(
            list_observability_transitions(
                session=session,
                machine_name="m1",
                entity_id=None,
                status="all",
                start_at=None,
                end_at=None,
                limit=2,
                offset=1,
            )
        )
        assert paged.total == 3
        assert len(paged.items) == 2
    finally:
        session.close()
        engine.dispose()
        _restore_schemas(original_schemas)


def test_observability_worker_events_status_filter() -> None:
    session, engine, original_schemas = _make_sqlite_session()
    now = datetime.now(UTC)
    transition_id = uuid.uuid4()

    try:
        session.add_all(
            [
                WorkerEventModel(
                    id=uuid.uuid4(),
                    machine_name="m1",
                    entity_id="e1",
                    trigger="go",
                    status="pending",
                    fires_at=now,
                ),
                WorkerEventModel(
                    id=uuid.uuid4(),
                    machine_name="m1",
                    entity_id="e2",
                    trigger="go",
                    status="failed",
                    fires_at=now,
                    transition_history_id=transition_id,
                ),
            ]
        )
        session.commit()

        failed = _run_async(
            list_observability_worker_events(
                session=session,
                machine_name="m1",
                entity_id=None,
                status="failed",
                start_at=None,
                end_at=None,
                limit=50,
                offset=0,
            )
        )

        assert failed.total == 1
        assert len(failed.items) == 1
        assert failed.items[0].status == "failed"
        assert failed.items[0].transition_history_id == str(transition_id)
    finally:
        session.close()
        engine.dispose()
        _restore_schemas(original_schemas)


def _run_async(awaitable):
    """Run an async awaitable in tests without requiring pytest-asyncio."""
    import asyncio

    return asyncio.run(awaitable)
