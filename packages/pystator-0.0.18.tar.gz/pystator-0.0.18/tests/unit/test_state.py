"""Unit tests for State and StateType."""

from __future__ import annotations

import pytest

from pystator import State, StateType, Timeout


class TestStateType:
    """Tests for StateType enum."""

    def test_state_types_values(self) -> None:
        """Test that state types have correct string values."""
        assert StateType.INITIAL.value == "initial"
        assert StateType.STABLE.value == "stable"
        assert StateType.TERMINAL.value == "terminal"
        assert StateType.ERROR.value == "error"
        assert StateType.PARALLEL.value == "parallel"
        assert StateType.CHOICE.value == "choice"

    def test_state_type_from_string(self) -> None:
        """Test creating StateType from string."""
        assert StateType("initial") == StateType.INITIAL
        assert StateType("stable") == StateType.STABLE
        assert StateType("terminal") == StateType.TERMINAL
        assert StateType("error") == StateType.ERROR
        assert StateType("parallel") == StateType.PARALLEL
        assert StateType("choice") == StateType.CHOICE

    def test_invalid_state_type(self) -> None:
        """Test that invalid state type raises ValueError."""
        with pytest.raises(ValueError):
            StateType("invalid")


class TestTimeout:
    """Tests for Timeout dataclass."""

    def test_create_timeout(self) -> None:
        """Test creating a valid timeout."""
        timeout = Timeout(seconds=5.0, destination="timed_out")
        assert timeout.seconds == 5.0
        assert timeout.destination == "timed_out"

    def test_timeout_immutable(self) -> None:
        """Test that Timeout is immutable."""
        timeout = Timeout(seconds=5.0, destination="timed_out")
        with pytest.raises(AttributeError):
            timeout.seconds = 10.0  # type: ignore

    def test_timeout_invalid_seconds(self) -> None:
        """Test that zero or negative seconds raises error."""
        with pytest.raises(ValueError, match="positive"):
            Timeout(seconds=0, destination="timed_out")
        with pytest.raises(ValueError, match="positive"):
            Timeout(seconds=-1, destination="timed_out")

    def test_timeout_empty_destination(self) -> None:
        """Test that empty destination raises error."""
        with pytest.raises(ValueError, match="empty"):
            Timeout(seconds=5.0, destination="")


class TestState:
    """Tests for State dataclass."""

    def test_create_minimal_state(self) -> None:
        """Test creating a state with minimal arguments."""
        state = State(name="pending")
        assert state.name == "pending"
        assert state.type == StateType.STABLE
        assert state.description == ""
        assert state.on_enter == ()
        assert state.on_exit == ()
        assert state.timeout is None

    def test_create_full_state(self) -> None:
        """Test creating a state with all arguments."""
        timeout = Timeout(seconds=5.0, destination="timed_out")
        state = State(
            name="pending_new",
            type=StateType.INITIAL,
            description="Waiting for acknowledgment",
            on_enter=("log_entry",),
            on_exit=("log_exit",),
            timeout=timeout,
            metadata={"priority": "high"},
        )
        assert state.name == "pending_new"
        assert state.type == StateType.INITIAL
        assert state.description == "Waiting for acknowledgment"
        assert state.on_enter == ("log_entry",)
        assert state.on_exit == ("log_exit",)
        assert state.timeout == timeout
        assert state.metadata == {"priority": "high"}

    def test_state_immutable(self) -> None:
        """Test that State is immutable."""
        state = State(name="pending")
        with pytest.raises(AttributeError):
            state.name = "new_name"  # type: ignore

    def test_state_is_initial(self) -> None:
        """Test is_initial property."""
        initial = State(name="start", type=StateType.INITIAL)
        stable = State(name="active", type=StateType.STABLE)
        assert initial.is_initial is True
        assert stable.is_initial is False

    def test_state_is_terminal(self) -> None:
        """Test is_terminal property."""
        terminal = State(name="end", type=StateType.TERMINAL)
        stable = State(name="active", type=StateType.STABLE)
        assert terminal.is_terminal is True
        assert stable.is_terminal is False

    def test_state_is_error(self) -> None:
        """Test is_error property."""
        error = State(name="error", type=StateType.ERROR)
        stable = State(name="active", type=StateType.STABLE)
        assert error.is_error is True
        assert stable.is_error is False

    def test_state_is_choice(self) -> None:
        """Test is_choice property."""
        choice = State(name="check", type=StateType.CHOICE)
        stable = State(name="active", type=StateType.STABLE)
        assert choice.is_choice is True
        assert stable.is_choice is False

    def test_state_has_timeout(self) -> None:
        """Test has_timeout property."""
        with_timeout = State(
            name="pending",
            timeout=Timeout(seconds=5.0, destination="timed_out"),
        )
        without_timeout = State(name="active")
        assert with_timeout.has_timeout is True
        assert without_timeout.has_timeout is False

    def test_state_empty_name_raises(self) -> None:
        """Test that empty name raises error."""
        with pytest.raises(ValueError, match="empty"):
            State(name="")

    def test_state_invalid_name_raises(self) -> None:
        """Test that invalid characters in name raises error."""
        with pytest.raises(ValueError, match="letters"):
            State(name="invalid-name")
        with pytest.raises(ValueError, match="letters"):
            State(name="invalid name")

    def test_state_equality(self) -> None:
        """Test state equality comparison."""
        state1 = State(name="pending", type=StateType.INITIAL)
        state2 = State(name="pending", type=StateType.INITIAL)
        state3 = State(name="active", type=StateType.STABLE)

        assert state1 == state2
        assert state1 != state3
