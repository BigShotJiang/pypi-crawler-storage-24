"""Unit tests for Transition and TransitionResult."""

from __future__ import annotations

import pytest

from pystator import ActionSpec, InvalidTransitionError, Transition, TransitionResult


class TestTransition:
    """Tests for Transition dataclass."""

    def test_create_minimal_transition(self) -> None:
        """Test creating a transition with minimal arguments."""
        trans = Transition(
            trigger="activate",
            source=frozenset({"PENDING"}),
            dest="ACTIVE",
        )
        assert trans.trigger == "activate"
        assert trans.source == frozenset({"PENDING"})
        assert trans.dest == "ACTIVE"
        assert trans.guards == ()
        assert trans.actions == ()

    def test_create_full_transition(self) -> None:
        """Test creating a transition with all arguments."""
        trans = Transition(
            trigger="execute",
            source=frozenset({"OPEN", "PARTIAL"}),
            dest="FILLED",
            guards=("is_full_fill", "is_valid"),
            actions=("update_positions", "notify"),
            description="Complete the order",
            metadata={"priority": 1},
        )
        assert trans.trigger == "execute"
        assert trans.source == frozenset({"OPEN", "PARTIAL"})
        assert trans.dest == "FILLED"
        assert trans.guards == ("is_full_fill", "is_valid")
        assert trans.actions == ("update_positions", "notify")
        assert trans.description == "Complete the order"
        assert trans.metadata == {"priority": 1}

    def test_transition_immutable(self) -> None:
        """Test that Transition is immutable."""
        trans = Transition(
            trigger="activate",
            source=frozenset({"PENDING"}),
            dest="ACTIVE",
        )
        with pytest.raises(AttributeError):
            trans.trigger = "new_trigger"  # type: ignore

    def test_from_single_source(self) -> None:
        """Test creating transition from single source."""
        trans = Transition.from_single_source(
            trigger="activate",
            source="PENDING",
            dest="ACTIVE",
            guards=("is_ready",),
            actions=("log",),
        )
        assert trans.source == frozenset({"PENDING"})
        assert trans.trigger == "activate"

    def test_matches_source(self) -> None:
        """Test matches_source method."""
        trans = Transition(
            trigger="fill",
            source=frozenset({"OPEN", "PARTIAL"}),
            dest="FILLED",
        )
        assert trans.matches_source("OPEN") is True
        assert trans.matches_source("PARTIAL") is True
        assert trans.matches_source("PENDING") is False

    def test_has_guards(self) -> None:
        """Test has_guards method."""
        with_guards = Transition(
            trigger="fill",
            source=frozenset({"OPEN"}),
            dest="FILLED",
            guards=("is_full",),
        )
        without_guards = Transition(
            trigger="fill",
            source=frozenset({"OPEN"}),
            dest="FILLED",
        )
        assert with_guards.has_guards() is True
        assert without_guards.has_guards() is False

    def test_empty_trigger_raises(self) -> None:
        """Test that empty trigger raises error."""
        with pytest.raises(ValueError, match="empty"):
            Transition(trigger="", source=frozenset({"A"}), dest="B")

    def test_empty_source_raises(self) -> None:
        """Test that empty source raises error."""
        with pytest.raises(ValueError, match="source"):
            Transition(trigger="test", source=frozenset(), dest="B")

    def test_empty_dest_raises(self) -> None:
        """Test that empty destination raises error."""
        with pytest.raises(ValueError, match="empty"):
            Transition(trigger="test", source=frozenset({"A"}), dest="")


class TestTransitionResult:
    """Tests for TransitionResult dataclass."""

    def test_success_result(self) -> None:
        """Test creating a successful result."""
        result = TransitionResult.success_result(
            source_state="PENDING",
            target_state="ACTIVE",
            trigger="activate",
            actions=(ActionSpec("log"),),
            on_exit=(ActionSpec("exit_hook"),),
            on_enter=(ActionSpec("enter_hook"),),
        )
        assert result.success is True
        assert result.source_state == "PENDING"
        assert result.target_state == "ACTIVE"
        assert result.trigger == "activate"
        assert result.error is None

    def test_failure_result(self) -> None:
        """Test creating a failure result."""
        error = InvalidTransitionError(
            "Cannot transition",
            current_state="PENDING",
            trigger="invalid",
        )
        result = TransitionResult.failure_result(
            source_state="PENDING",
            trigger="invalid",
            error=error,
        )
        assert result.success is False
        assert result.source_state == "PENDING"
        assert result.target_state is None
        assert result.trigger == "invalid"
        assert result.error == error

    def test_all_actions_property(self) -> None:
        """Test all_actions property returns actions in correct order."""
        result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
            actions=(ActionSpec("trans_action"),),
            on_exit=(ActionSpec("exit_action"),),
            on_enter=(ActionSpec("enter_action"),),
        )
        # Order: exit -> transition -> enter (all_actions returns names)
        assert result.all_actions == ("exit_action", "trans_action", "enter_action")

    def test_is_self_transition(self) -> None:
        """Test is_self_transition property."""
        self_trans = TransitionResult.success_result(
            source_state="A",
            target_state="A",
            trigger="refresh",
        )
        normal_trans = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
        )
        failed = TransitionResult.failure_result(
            source_state="A",
            trigger="fail",
            error=InvalidTransitionError("fail", "A", "fail"),
        )

        assert self_trans.is_self_transition is True
        assert normal_trans.is_self_transition is False
        assert failed.is_self_transition is False

    def test_state_changed(self) -> None:
        """Test state_changed property."""
        changed = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
        )
        unchanged = TransitionResult.success_result(
            source_state="A",
            target_state="A",
            trigger="refresh",
        )
        failed = TransitionResult.failure_result(
            source_state="A",
            trigger="fail",
            error=InvalidTransitionError("fail", "A", "fail"),
        )

        assert changed.state_changed is True
        assert unchanged.state_changed is False
        assert failed.state_changed is False

    def test_result_immutable(self) -> None:
        """Test that TransitionResult is immutable."""
        result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
        )
        with pytest.raises(AttributeError):
            result.success = False  # type: ignore
