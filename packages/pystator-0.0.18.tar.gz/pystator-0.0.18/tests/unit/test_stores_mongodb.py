"""Tests for MongoDBStateStore.

URL validation and MONGO_AVAILABLE guard tested here.
Integration tests should be marked with @pytest.mark.integration.
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

try:
    import pymongo  # noqa: F401

    HAS_PYMONGO = True
except ImportError:
    HAS_PYMONGO = False

pytestmark = pytest.mark.skipif(not HAS_PYMONGO, reason="pymongo not installed")


class TestMongoDBStateStoreInit:
    """Connection string validation and dependency guard."""

    def test_rejects_sqlite_url(self) -> None:
        from pystator.stores.mongodb import MongoDBStateStore

        with pytest.raises(ValueError, match="mongodb://"):
            MongoDBStateStore("sqlite:///test.db")

    def test_rejects_postgresql_url(self) -> None:
        from pystator.stores.mongodb import MongoDBStateStore

        with pytest.raises(ValueError, match="mongodb://"):
            MongoDBStateStore("postgresql://localhost/db")

    def test_accepts_mongodb_url(self) -> None:
        from pystator.stores.mongodb import MongoDBStateStore

        store = MongoDBStateStore("mongodb://localhost:27017")
        assert store.connection_string == "mongodb://localhost:27017"

    def test_accepts_mongodb_srv_url(self) -> None:
        from pystator.stores.mongodb import MongoDBStateStore

        store = MongoDBStateStore("mongodb+srv://cluster.example.net")
        assert store.connection_string == "mongodb+srv://cluster.example.net"

    def test_custom_database_name(self) -> None:
        from pystator.stores.mongodb import MongoDBStateStore

        store = MongoDBStateStore("mongodb://localhost", database_name="custom_db")
        assert store._database_name == "custom_db"


class TestMongoDBStateStoreMocked:
    """Test store methods with mocked pymongo."""

    @pytest.fixture()
    def store(self) -> MagicMock:
        """Create a MongoDBStateStore with a mocked pymongo client."""
        from pystator.stores.mongodb import MongoDBStateStore

        s = MongoDBStateStore("mongodb://localhost:27017", database_name="test_db")

        # Mock the pymongo client and database.
        mock_client = MagicMock()
        mock_db = MagicMock()
        mock_client.__getitem__ = MagicMock(return_value=mock_db)

        s._client = mock_client
        s._db = mock_db
        s._connection = mock_db  # sentinel

        return s

    def test_get_state_missing(self, store: MagicMock) -> None:
        store._db["entity_states"].find_one.return_value = None
        result = store.get_state("missing")
        assert result is None

    def test_get_state_found(self, store: MagicMock) -> None:
        store._db["entity_states"].find_one.return_value = {
            "entity_id": "e1",
            "current_state": "pending",
        }
        assert store.get_state("e1") == "pending"

    def test_set_state_calls_upsert(self, store: MagicMock) -> None:
        store.set_state("e1", "active")
        store._db["entity_states"].update_one.assert_called_once()
        call_args = store._db["entity_states"].update_one.call_args
        assert call_args[0][0] == {"entity_id": "e1"}
        assert call_args[1].get("upsert") is True

    def test_get_context_empty(self, store: MagicMock) -> None:
        store._db["entity_states"].find_one.return_value = None
        assert store.get_context("missing") == {}

    def test_get_context_with_data(self, store: MagicMock) -> None:
        store._db["entity_states"].find_one.return_value = {
            "entity_id": "e1",
            "context": {"key": "value"},
        }
        assert store.get_context("e1") == {"key": "value"}

    def test_delete_entity(self, store: MagicMock) -> None:
        store._db["entity_states"].delete_one.return_value = MagicMock(deleted_count=1)
        assert store.delete_entity("e1") is True

    def test_delete_entity_missing(self, store: MagicMock) -> None:
        store._db["entity_states"].delete_one.return_value = MagicMock(deleted_count=0)
        assert store.delete_entity("missing") is False


class TestMongoDBImportGuard:
    """Test that import fails gracefully without pymongo."""

    @pytest.mark.skipif(HAS_PYMONGO, reason="pymongo is installed")
    def test_import_raises_without_pymongo(self) -> None:
        from pystator.stores.mongodb import MongoDBStateStore

        with pytest.raises(ImportError, match="pymongo"):
            MongoDBStateStore("mongodb://localhost")
