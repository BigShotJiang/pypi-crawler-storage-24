"""Unit tests for action retry and backoff support."""

from __future__ import annotations

from unittest.mock import AsyncMock, patch

import pytest

from pystator import (
    ActionExecutor,
    ActionRegistry,
    ActionSpec,
    TransitionResult,
)


class TestActionSpecRetry:
    """Tests for ActionSpec retry and retry_backoff fields."""

    def test_default_retry_is_zero(self) -> None:
        """ActionSpec retry defaults to 0 (no retries)."""
        spec = ActionSpec(name="my_action")
        assert spec.retry == 0

    def test_default_retry_backoff_is_one(self) -> None:
        """ActionSpec retry_backoff defaults to 1.0."""
        spec = ActionSpec(name="my_action")
        assert spec.retry_backoff == 1.0

    def test_action_spec_with_retry_fields(self) -> None:
        """ActionSpec can be created with retry and retry_backoff."""
        spec = ActionSpec(name="my_action", retry=3, retry_backoff=0.5)
        assert spec.retry == 3
        assert spec.retry_backoff == 0.5

    def test_from_config_parses_retry(self) -> None:
        """ActionSpec.from_config parses retry from dict config."""
        spec = ActionSpec.from_config(
            {
                "name": "my_action",
                "retry": 2,
                "retry_backoff": 0.25,
            }
        )
        assert spec.name == "my_action"
        assert spec.retry == 2
        assert spec.retry_backoff == 0.25

    def test_from_config_defaults_retry(self) -> None:
        """ActionSpec.from_config defaults retry=0, retry_backoff=1.0."""
        spec = ActionSpec.from_config({"name": "my_action"})
        assert spec.retry == 0
        assert spec.retry_backoff == 1.0

    def test_from_string_config_defaults(self) -> None:
        """ActionSpec from string config has default retry fields."""
        spec = ActionSpec.from_config("my_action")
        assert spec.retry == 0
        assert spec.retry_backoff == 1.0


class TestSyncActionRetry:
    """Tests for synchronous action retry behavior."""

    @pytest.fixture
    def registry(self) -> ActionRegistry:
        """Create a basic action registry."""
        return ActionRegistry()

    def test_sync_retry_succeeds_on_later_attempt(
        self, registry: ActionRegistry
    ) -> None:
        """Sync action fails first, succeeds on retry."""
        call_count = 0

        def flaky_action(ctx: dict) -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 3:
                raise ValueError(f"Fail attempt {call_count}")
            return "success"

        registry.register("flaky", flaky_action)
        executor = ActionExecutor(registry, log_execution=False)

        with patch("time.sleep") as mock_sleep:
            spec = ActionSpec(name="flaky", retry=3, retry_backoff=0.1)
            result = executor.execute_action_spec(spec, {})

        assert result.success
        assert result.result == "success"
        assert call_count == 3
        # Verify backoff delays were applied (attempts 2 and 3)
        assert mock_sleep.call_count == 2

    def test_sync_retries_exhausted_returns_last_failure(
        self, registry: ActionRegistry
    ) -> None:
        """After all retries exhausted, returns the last failure."""
        call_count = 0

        def always_fail(ctx: dict) -> str:
            nonlocal call_count
            call_count += 1
            raise ValueError(f"Fail {call_count}")

        registry.register("always_fail", always_fail)
        executor = ActionExecutor(registry, log_execution=False)

        with patch("time.sleep"):
            spec = ActionSpec(name="always_fail", retry=2, retry_backoff=0.1)
            result = executor.execute_action_spec(spec, {})

        assert not result.success
        assert isinstance(result.error, ValueError)
        # 1 initial + 2 retries = 3 attempts
        assert call_count == 3

    def test_sync_backoff_delay_applied(self, registry: ActionRegistry) -> None:
        """Exponential backoff delay is applied between retries."""
        registry.register("fail_action", lambda ctx: 1 / 0)
        executor = ActionExecutor(registry, log_execution=False)

        with patch("time.sleep") as mock_sleep:
            spec = ActionSpec(name="fail_action", retry=3, retry_backoff=0.5)
            executor.execute_action_spec(spec, {})

        # 3 retries -> sleep called 3 times
        assert mock_sleep.call_count == 3
        # Backoff: 0.5 * 2^0 = 0.5, 0.5 * 2^1 = 1.0, 0.5 * 2^2 = 2.0
        delays = [c.args[0] for c in mock_sleep.call_args_list]
        assert delays == pytest.approx([0.5, 1.0, 2.0])

    def test_sync_no_retry_fails_immediately(self, registry: ActionRegistry) -> None:
        """With retry=0, action fails on first attempt without retry."""
        call_count = 0

        def fail_once(ctx: dict) -> str:
            nonlocal call_count
            call_count += 1
            raise ValueError("boom")

        registry.register("fail_once", fail_once)
        executor = ActionExecutor(registry, log_execution=False)

        spec = ActionSpec(name="fail_once", retry=0)
        result = executor.execute_action_spec(spec, {})

        assert not result.success
        assert call_count == 1


class TestAsyncActionRetry:
    """Tests for asynchronous action retry behavior."""

    @pytest.fixture
    def registry(self) -> ActionRegistry:
        """Create a basic action registry."""
        return ActionRegistry()

    @pytest.mark.asyncio
    async def test_async_retry_succeeds_on_later_attempt(
        self, registry: ActionRegistry
    ) -> None:
        """Async action fails first, succeeds on retry."""
        call_count = 0

        async def flaky_async(ctx: dict) -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ValueError("transient failure")
            return "async_success"

        registry.register("flaky_async", flaky_async)
        executor = ActionExecutor(registry, log_execution=False)

        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            spec = ActionSpec(name="flaky_async", retry=2, retry_backoff=0.1)
            result = await executor.async_execute_action_spec(spec, {})

        assert result.success
        assert result.result == "async_success"
        assert call_count == 2
        # One retry -> one sleep call
        assert mock_sleep.call_count == 1

    @pytest.mark.asyncio
    async def test_async_retries_exhausted_returns_failure(
        self, registry: ActionRegistry
    ) -> None:
        """After all async retries exhausted, returns the last failure."""
        call_count = 0

        async def always_fail_async(ctx: dict) -> str:
            nonlocal call_count
            call_count += 1
            raise RuntimeError(f"async fail {call_count}")

        registry.register("always_fail_async", always_fail_async)
        executor = ActionExecutor(registry, log_execution=False)

        with patch("asyncio.sleep", new_callable=AsyncMock):
            spec = ActionSpec(name="always_fail_async", retry=2, retry_backoff=0.1)
            result = await executor.async_execute_action_spec(spec, {})

        assert not result.success
        assert call_count == 3  # 1 initial + 2 retries

    @pytest.mark.asyncio
    async def test_async_backoff_delay_applied(self, registry: ActionRegistry) -> None:
        """Exponential backoff delay is applied between async retries."""

        async def fail_async(ctx: dict) -> None:
            raise ValueError("fail")

        registry.register("fail_async", fail_async)
        executor = ActionExecutor(registry, log_execution=False)

        with patch("asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            spec = ActionSpec(name="fail_async", retry=3, retry_backoff=0.25)
            await executor.async_execute_action_spec(spec, {})

        assert mock_sleep.call_count == 3
        # Backoff: 0.25 * 2^0 = 0.25, 0.25 * 2^1 = 0.5, 0.25 * 2^2 = 1.0
        delays = [c.args[0] for c in mock_sleep.call_args_list]
        assert delays == pytest.approx([0.25, 0.5, 1.0])

    @pytest.mark.asyncio
    async def test_async_retry_in_transition_result(
        self, registry: ActionRegistry
    ) -> None:
        """Retry works when actions come from TransitionResult."""
        call_count = 0

        async def flaky(ctx: dict) -> str:
            nonlocal call_count
            call_count += 1
            if call_count < 2:
                raise ValueError("transient")
            return "ok"

        registry.register("flaky", flaky)
        executor = ActionExecutor(registry, log_execution=False)

        trans_result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
            actions=(ActionSpec(name="flaky", retry=2, retry_backoff=0.01),),
        )

        with patch("asyncio.sleep", new_callable=AsyncMock):
            exec_result = await executor.async_execute(trans_result, {})

        assert exec_result.all_succeeded
        assert call_count == 2
