"""Unit tests for StateMachine."""

from __future__ import annotations

import pytest

from pystator import (
    ActionSpec,
    ConfigurationError,
    Event,
    GuardRegistry,
    InvalidTransitionError,
    State,
    StateMachine,
    StateType,
    TerminalStateError,
    Transition,
    UndefinedStateError,
    UndefinedTriggerError,
)


class TestStateMachineCreation:
    """Tests for StateMachine creation."""

    def test_create_from_states_and_transitions(
        self, simple_states: dict[str, State], simple_transitions: list[Transition]
    ) -> None:
        """Test creating machine from state/transition objects."""
        machine = StateMachine(
            states=simple_states,
            transitions=simple_transitions,
        )
        assert len(machine.states) == 3
        assert len(machine.transitions) == 2

    def test_create_from_dict(self, order_config: dict) -> None:
        """Test creating machine from config dict."""
        machine = StateMachine.from_dict(order_config)
        assert machine.name == "order_fsm"
        assert machine.version == "1.0.0"
        assert len(machine.states) == 7

    def test_no_initial_state_raises(self) -> None:
        """Test that missing initial state raises error."""
        states = {
            "a": State(name="a", type=StateType.STABLE),
            "b": State(name="b", type=StateType.STABLE),
        }
        with pytest.raises(ConfigurationError, match="initial"):
            StateMachine(states=states, transitions=[])

    def test_multiple_initial_states_raises(self) -> None:
        """Test that multiple initial states raise error."""
        states = {
            "a": State(name="a", type=StateType.INITIAL),
            "b": State(name="b", type=StateType.INITIAL),
        }
        with pytest.raises(ConfigurationError, match="Multiple"):
            StateMachine(states=states, transitions=[])

    def test_undefined_source_state_raises(self) -> None:
        """Test that undefined source state raises error."""
        states = {
            "a": State(name="a", type=StateType.INITIAL),
        }
        transitions = [
            Transition(trigger="go", source=frozenset({"nonexistent"}), dest="a"),
        ]
        with pytest.raises(ConfigurationError, match="undefined"):
            StateMachine(states=states, transitions=transitions)

    def test_undefined_dest_state_raises(self) -> None:
        """Test that undefined destination state raises error."""
        states = {
            "a": State(name="a", type=StateType.INITIAL),
        }
        transitions = [
            Transition(trigger="go", source=frozenset({"a"}), dest="nonexistent"),
        ]
        with pytest.raises(ConfigurationError, match="undefined"):
            StateMachine(states=states, transitions=transitions)


class TestStateMachineProcess:
    """Tests for StateMachine.process()."""

    def test_simple_transition(self, simple_machine: StateMachine) -> None:
        """Test a simple state transition."""
        result = simple_machine.process("pending", "activate")

        assert result.success is True
        assert result.source_state == "pending"
        assert result.target_state == "active"
        assert result.trigger == "activate"
        assert "send_notification" in result.all_actions

    def test_transition_with_hooks(self, simple_machine: StateMachine) -> None:
        """Test transition includes state hooks."""
        result = simple_machine.process("pending", "activate")

        assert "log_activation" in result.all_actions

    def test_undefined_state_raises(self, simple_machine: StateMachine) -> None:
        """Test processing from undefined state raises."""
        with pytest.raises(UndefinedStateError):
            simple_machine.process("nonexistent", "activate")

    def test_terminal_state_returns_failure(self, simple_machine: StateMachine) -> None:
        """Test that transitions from terminal states fail."""
        result = simple_machine.process("completed", "activate")

        assert result.success is False
        assert isinstance(result.error, TerminalStateError)

    def test_undefined_trigger_strict_mode(self, simple_machine: StateMachine) -> None:
        """Test undefined trigger in strict mode returns failure."""
        result = simple_machine.process("pending", "nonexistent_trigger")

        assert result.success is False
        assert isinstance(result.error, UndefinedTriggerError)

    def test_no_matching_transition(self, simple_machine: StateMachine) -> None:
        """Test no matching transition returns failure."""
        # "complete" is only valid from active, not pending
        result = simple_machine.process("pending", "complete")

        assert result.success is False
        assert isinstance(result.error, InvalidTransitionError)

    def test_process_with_event_object(self, simple_machine: StateMachine) -> None:
        """Test processing with Event object."""
        event = Event(
            trigger="activate",
            payload={"user_id": 123},
            source="api",
        )
        result = simple_machine.process("pending", event)

        assert result.success is True
        assert result.target_state == "active"


class TestEventNormalization:
    """Tests for meta.event_normalizer (lower/upper)."""

    def test_event_normalizer_lower_matches_uppercase_trigger(self) -> None:
        """With event_normalizer: lower, FILL and fill both match trigger 'fill'."""
        open_state = State(name="open", type=StateType.INITIAL)
        filled_state = State(name="filled", type=StateType.STABLE)
        states = {"open": open_state, "filled": filled_state}
        transitions = [
            Transition(trigger="fill", source=frozenset({"open"}), dest="filled"),
        ]
        meta = {"event_normalizer": "lower"}
        machine = StateMachine(states=states, transitions=transitions, meta=meta)
        result_lower = machine.process("open", "fill", {})
        result_upper = machine.process("open", "FILL", {})
        assert result_lower.success is True
        assert result_upper.success is True
        assert result_lower.target_state == result_upper.target_state == "filled"

    def test_event_normalizer_upper_matches_lowercase_trigger(self) -> None:
        """With event_normalizer: upper, fill and FILL both match trigger 'FILL'."""
        open_state = State(name="open", type=StateType.INITIAL)
        filled_state = State(name="filled", type=StateType.STABLE)
        states = {"open": open_state, "filled": filled_state}
        transitions = [
            Transition(trigger="FILL", source=frozenset({"open"}), dest="filled"),
        ]
        meta = {"event_normalizer": "upper"}
        machine = StateMachine(states=states, transitions=transitions, meta=meta)
        result_lower = machine.process("open", "fill", {})
        result_upper = machine.process("open", "FILL", {})
        assert result_lower.success is True
        assert result_upper.success is True


class TestStateMachineWithGuards:
    """Tests for StateMachine with guards."""

    def test_guard_pass(
        self, order_machine: StateMachine, guard_registry: GuardRegistry
    ) -> None:
        """Test transition with passing guard."""
        order_machine.bind_guards(guard_registry)

        result = order_machine.process(
            "open",
            "execution_report",
            {"fill_qty": 100, "order_qty": 100},
        )

        assert result.success is True
        assert result.target_state == "filled"

    def test_guard_fail(
        self, order_machine: StateMachine, guard_registry: GuardRegistry
    ) -> None:
        """Test transition with failing guard."""
        order_machine.bind_guards(guard_registry)

        # is_full_fill will fail because fill_qty < order_qty
        # is_partial_fill will also fail because source is partially_filled
        result = order_machine.process(
            "partially_filled",
            "execution_report",
            {"fill_qty": 50, "order_qty": 100},
        )

        assert result.success is False
        assert "guards_failed" in str(result.metadata)

    def test_partial_fill_transition(
        self, order_machine: StateMachine, guard_registry: GuardRegistry
    ) -> None:
        """Test partial fill uses correct guard."""
        order_machine.bind_guards(guard_registry)

        result = order_machine.process(
            "open",
            "execution_report",
            {"fill_qty": 50, "order_qty": 100},
        )

        assert result.success is True
        assert result.target_state == "partially_filled"

    def test_no_guards_bound_strict_mode(self, order_machine: StateMachine) -> None:
        """Test that strict mode raises when guards are not registered."""
        from pystator.errors import GuardNotFoundError

        with pytest.raises(GuardNotFoundError, match="not registered"):
            order_machine.process(
                "open",
                "execution_report",
                {"fill_qty": 100, "order_qty": 100},
            )


class TestStateMachineQueries:
    """Tests for StateMachine query methods."""

    def test_get_state(self, simple_machine: StateMachine) -> None:
        """Test getting a state by name."""
        state = simple_machine.get_state("pending")
        assert state.name == "pending"
        assert state.is_initial

    def test_get_state_undefined(self, simple_machine: StateMachine) -> None:
        """Test getting undefined state raises."""
        with pytest.raises(UndefinedStateError):
            simple_machine.get_state("nonexistent")

    def test_get_initial_state(self, simple_machine: StateMachine) -> None:
        """Test getting the initial state."""
        state = simple_machine.get_initial_state()
        assert state.name == "pending"

    def test_get_available_transitions(self, simple_machine: StateMachine) -> None:
        """Test getting available transitions from a state."""
        transitions = simple_machine.get_available_transitions("pending")
        assert len(transitions) == 1
        assert transitions[0].trigger == "activate"

    def test_get_available_triggers(self, simple_machine: StateMachine) -> None:
        """Test getting available triggers from a state."""
        triggers = simple_machine.get_available_triggers("pending")
        assert triggers == ["activate"]

    def test_validate_state(self, simple_machine: StateMachine) -> None:
        """Test validate_state method."""
        assert simple_machine.validate_state("pending") is True
        assert simple_machine.validate_state("nonexistent") is False

    def test_is_terminal(self, simple_machine: StateMachine) -> None:
        """Test is_terminal method."""
        assert simple_machine.is_terminal("completed") is True
        assert simple_machine.is_terminal("active") is False

    def test_is_initial(self, simple_machine: StateMachine) -> None:
        """Test is_initial method."""
        assert simple_machine.is_initial("pending") is True
        assert simple_machine.is_initial("active") is False

    def test_can_transition(self, simple_machine: StateMachine) -> None:
        """Test can_transition helper."""
        assert simple_machine.can_transition("pending", "activate") is True
        assert simple_machine.can_transition("pending", "complete") is False
        assert simple_machine.can_transition("completed", "activate") is False


class TestStateMachineProperties:
    """Tests for StateMachine properties."""

    def test_name_property(self, simple_machine: StateMachine) -> None:
        """Test name property."""
        assert simple_machine.name == "test_machine"

    def test_version_property(self, simple_machine: StateMachine) -> None:
        """Test version property."""
        assert simple_machine.version == "1.0.0"

    def test_state_names(self, simple_machine: StateMachine) -> None:
        """Test state_names property."""
        names = simple_machine.state_names
        assert set(names) == {"pending", "active", "completed"}

    def test_trigger_names(self, simple_machine: StateMachine) -> None:
        """Test trigger_names property."""
        triggers = simple_machine.trigger_names
        assert set(triggers) == {"activate", "complete"}

    def test_terminal_states(self, simple_machine: StateMachine) -> None:
        """Test terminal_states property."""
        terminals = simple_machine.terminal_states
        assert terminals == ["completed"]

    def test_repr(self, simple_machine: StateMachine) -> None:
        """Test string representation."""
        repr_str = repr(simple_machine)
        assert "StateMachine" in repr_str
        assert "test_machine" in repr_str


class TestStateMachineHierarchical:
    """Tests for hierarchical (statecharts) state machines."""

    @pytest.fixture
    def hierarchical_states(self) -> dict[str, State]:
        """States: pre_market (initial), active (compound), active_scanning, active_analyzing, halted."""
        return {
            "pre_market": State(name="pre_market", type=StateType.INITIAL),
            "active": State(
                name="active",
                type=StateType.STABLE,
                initial_child="active_scanning",
                on_enter=(ActionSpec("enter_active"),),
                on_exit=(ActionSpec("exit_active"),),
            ),
            "active_scanning": State(
                name="active_scanning",
                type=StateType.STABLE,
                parent="active",
                on_enter=(ActionSpec("enter_scanning"),),
                on_exit=(ActionSpec("exit_scanning"),),
            ),
            "active_analyzing": State(
                name="active_analyzing",
                type=StateType.STABLE,
                parent="active",
                on_enter=(ActionSpec("enter_analyzing"),),
                on_exit=(ActionSpec("exit_analyzing"),),
            ),
            "halted": State(
                name="halted",
                type=StateType.TERMINAL,
                on_enter=(ActionSpec("enter_halted"),),
            ),
        }

    @pytest.fixture
    def hierarchical_transitions(
        self, hierarchical_states: dict[str, State]
    ) -> list[Transition]:
        """Transitions: pre_market->active, scanning<->analyzing, active->halted (emergency_stop)."""
        return [
            Transition(
                trigger="market_open",
                source=frozenset({"pre_market"}),
                dest="active",
                actions=(ActionSpec("log_open"),),
            ),
            Transition(
                trigger="step",
                source=frozenset({"active_scanning"}),
                dest="active_analyzing",
                actions=(ActionSpec("to_analyzing"),),
            ),
            Transition(
                trigger="back",
                source=frozenset({"active_analyzing"}),
                dest="active_scanning",
                actions=(ActionSpec("to_scanning"),),
            ),
            Transition(
                trigger="emergency_stop",
                source=frozenset({"active"}),
                dest="halted",
                actions=(ActionSpec("emergency_flatten"),),
            ),
        ]

    @pytest.fixture
    def hierarchical_machine(
        self,
        hierarchical_states: dict[str, State],
        hierarchical_transitions: list[Transition],
    ) -> StateMachine:
        """Hierarchical state machine with guards bound (pass-through)."""
        machine = StateMachine(
            states=hierarchical_states,
            transitions=hierarchical_transitions,
            meta={"machine_name": "hier", "version": "1.0.0"},
        )
        registry = GuardRegistry()
        machine.bind_guards(registry)
        return machine

    def test_initial_state_is_leaf(self, hierarchical_machine: StateMachine) -> None:
        """get_initial_state returns root (pre_market) since it has no initial_child)."""
        initial = hierarchical_machine.get_initial_state()
        assert initial.name == "pre_market"

    def test_enter_compound_resolves_to_initial_child(
        self, hierarchical_machine: StateMachine
    ) -> None:
        """Transition to compound state (active) resolves to initial child (active_scanning)."""
        result = hierarchical_machine.process("pre_market", "market_open", {})
        assert result.success
        assert result.target_state == "active_scanning"
        assert result.source_state == "pre_market"
        # Enter chain: active, then active_scanning
        enter_names = tuple(s.name for s in result.on_enter_actions)
        assert "enter_active" in enter_names
        assert "enter_scanning" in enter_names
        assert enter_names.index("enter_active") < enter_names.index("enter_scanning")

    def test_transition_from_parent_matches_substate(
        self, hierarchical_machine: StateMachine
    ) -> None:
        """Transition source 'active' matches when current state is active_scanning."""
        # Start in active_scanning (after market_open)
        result = hierarchical_machine.process("pre_market", "market_open", {})
        assert result.success and result.target_state == "active_scanning"
        # Emergency stop from active_scanning uses transition from 'active' to halted
        result2 = hierarchical_machine.process("active_scanning", "emergency_stop", {})
        assert result2.success
        assert result2.source_state == "active_scanning"
        assert result2.target_state == "halted"

    def test_lca_exit_enter_order(self, hierarchical_machine: StateMachine) -> None:
        """Exit chain: scanning then active; enter chain: halted (LCA is none)."""
        result = hierarchical_machine.process("active_scanning", "emergency_stop", {})
        assert result.success
        # Exit from active_scanning up to root of active tree (exit scanning, then active)
        exit_names = tuple(s.name for s in result.on_exit_actions)
        assert "exit_scanning" in exit_names
        assert "exit_active" in exit_names
        assert exit_names.index("exit_scanning") < exit_names.index("exit_active")
        # Enter halted
        assert tuple(s.name for s in result.on_enter_actions) == ("enter_halted",)
        # Transition actions
        assert "emergency_flatten" in result.all_actions

    def test_sibling_transition_lca(self, hierarchical_machine: StateMachine) -> None:
        """Transition active_scanning -> active_analyzing: LCA is active; exit scanning, enter analyzing."""
        result = hierarchical_machine.process("active_scanning", "step", {})
        assert result.success
        assert result.source_state == "active_scanning"
        assert result.target_state == "active_analyzing"
        # Exit only active_scanning (LCA is active, we don't exit active)
        assert tuple(s.name for s in result.on_exit_actions) == ("exit_scanning",)
        # Enter only active_analyzing
        assert tuple(s.name for s in result.on_enter_actions) == ("enter_analyzing",)
