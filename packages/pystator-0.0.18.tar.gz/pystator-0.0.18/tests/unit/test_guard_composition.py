"""Unit tests for guard composition operators (allOf, anyOf, not) in YAML config."""

from __future__ import annotations

import pytest

from pystator import GuardEvaluator, GuardRegistry, GuardSpec, Transition
from pystator._types import CheckSpec

# ---------------------------------------------------------------------------
# GuardSpec composite construction
# ---------------------------------------------------------------------------


class TestGuardSpecComposite:
    """Tests for GuardSpec composite guard creation."""

    def test_all_of_from_config(self) -> None:
        """allOf creates a composite with children."""
        spec = GuardSpec.from_config(
            {
                "allOf": [
                    "is_valid",
                    {"check": {"field": "status", "op": "eq", "value": "active"}},
                ]
            }
        )
        assert spec.is_composite
        assert spec.is_all_of
        assert len(spec.all_of) == 2
        assert spec.all_of[0].name == "is_valid"
        assert spec.all_of[1].is_check

    def test_any_of_from_config(self) -> None:
        """anyOf creates a composite with children."""
        spec = GuardSpec.from_config(
            {
                "anyOf": [
                    {"check": {"field": "priority", "op": "gte", "value": 5}},
                    "is_vip",
                ]
            }
        )
        assert spec.is_composite
        assert spec.is_any_of
        assert len(spec.any_of) == 2
        assert spec.any_of[0].is_check
        assert spec.any_of[1].name == "is_vip"

    def test_not_from_config(self) -> None:
        """not creates a negation composite."""
        spec = GuardSpec.from_config(
            {"not": {"check": {"field": "deleted", "op": "eq", "value": True}}}
        )
        assert spec.is_composite
        assert spec.is_negate
        assert spec.negate is not None
        assert spec.negate.is_check

    def test_nested_composition(self) -> None:
        """Composites can be nested: allOf containing anyOf."""
        spec = GuardSpec.from_config(
            {
                "allOf": [
                    {"anyOf": ["guard_a", "guard_b"]},
                    {"not": "guard_c"},
                ]
            }
        )
        assert spec.is_all_of
        assert len(spec.all_of) == 2
        assert spec.all_of[0].is_any_of
        assert spec.all_of[1].is_negate

    def test_deeply_nested(self) -> None:
        """Three levels of nesting."""
        spec = GuardSpec.from_config(
            {
                "allOf": [
                    {
                        "anyOf": [
                            {"not": "guard_x"},
                            "guard_y",
                        ]
                    },
                    "guard_z",
                ]
            }
        )
        assert spec.all_of[0].any_of[0].is_negate
        assert spec.all_of[0].any_of[0].negate.name == "guard_x"

    def test_all_of_empty_raises(self) -> None:
        """allOf with empty list raises."""
        with pytest.raises(ValueError, match="non-empty"):
            GuardSpec.from_config({"allOf": []})

    def test_any_of_empty_raises(self) -> None:
        """anyOf with empty list raises."""
        with pytest.raises(ValueError, match="non-empty"):
            GuardSpec.from_config({"anyOf": []})

    def test_multiple_exclusive_fields_raises(self) -> None:
        """Cannot set both name and all_of."""
        with pytest.raises(ValueError, match="can only have one"):
            GuardSpec(name="guard", all_of=(GuardSpec(name="x"),))

    def test_no_fields_set_raises(self) -> None:
        """Must set at least one field."""
        with pytest.raises(ValueError, match="must have"):
            GuardSpec()

    def test_not_with_string_name(self) -> None:
        """not with a string guard name."""
        spec = GuardSpec.from_config({"not": "is_deleted"})
        assert spec.is_negate
        assert spec.negate.name == "is_deleted"

    def test_backward_compatible_string(self) -> None:
        """Plain string still works."""
        spec = GuardSpec.from_config("is_valid")
        assert spec.name == "is_valid"
        assert not spec.is_composite

    def test_backward_compatible_check(self) -> None:
        """Check dict still works."""
        spec = GuardSpec.from_config({"check": {"field": "x", "op": "eq", "value": 1}})
        assert spec.is_check
        assert not spec.is_composite

    def test_backward_compatible_expr(self) -> None:
        """Expression dict still works."""
        spec = GuardSpec.from_config({"expr": "x > 5"})
        assert spec.is_expression
        assert not spec.is_composite


# ---------------------------------------------------------------------------
# GuardEvaluator composite evaluation
# ---------------------------------------------------------------------------


class TestGuardEvaluatorComposite:
    """Tests for evaluating composite guards."""

    @pytest.fixture()
    def registry(self) -> GuardRegistry:
        """Create registry with test guards."""
        reg = GuardRegistry()
        reg.register("is_valid", lambda ctx: ctx.get("valid", False))
        reg.register("is_vip", lambda ctx: ctx.get("vip", False))
        reg.register("is_active", lambda ctx: ctx.get("active", False))
        reg.register("is_deleted", lambda ctx: ctx.get("deleted", False))
        return reg

    @pytest.fixture()
    def evaluator(self, registry: GuardRegistry) -> GuardEvaluator:
        """Create evaluator with test registry."""
        return GuardEvaluator(registry=registry, strict=True)

    def _make_transition(self, guards: tuple[GuardSpec, ...]) -> Transition:
        """Helper: create a minimal transition with guards."""
        return Transition(
            trigger="TEST",
            source=frozenset({"a"}),
            dest="b",
            guards=guards,
        )

    def test_all_of_pass(self, evaluator: GuardEvaluator) -> None:
        """allOf passes when all children pass."""
        guard = GuardSpec(
            all_of=(
                GuardSpec(name="is_valid"),
                GuardSpec(name="is_active"),
            )
        )
        t = self._make_transition((guard,))
        result = evaluator.can_transition(t, {"valid": True, "active": True})
        assert result.passed

    def test_all_of_fail(self, evaluator: GuardEvaluator) -> None:
        """allOf fails when any child fails."""
        guard = GuardSpec(
            all_of=(
                GuardSpec(name="is_valid"),
                GuardSpec(name="is_active"),
            )
        )
        t = self._make_transition((guard,))
        result = evaluator.can_transition(t, {"valid": True, "active": False})
        assert not result.passed

    def test_any_of_pass(self, evaluator: GuardEvaluator) -> None:
        """anyOf passes when at least one child passes."""
        guard = GuardSpec(
            any_of=(
                GuardSpec(name="is_valid"),
                GuardSpec(name="is_vip"),
            )
        )
        t = self._make_transition((guard,))
        result = evaluator.can_transition(t, {"valid": False, "vip": True})
        assert result.passed

    def test_any_of_fail(self, evaluator: GuardEvaluator) -> None:
        """anyOf fails when no child passes."""
        guard = GuardSpec(
            any_of=(
                GuardSpec(name="is_valid"),
                GuardSpec(name="is_vip"),
            )
        )
        t = self._make_transition((guard,))
        result = evaluator.can_transition(t, {"valid": False, "vip": False})
        assert not result.passed

    def test_negate_pass(self, evaluator: GuardEvaluator) -> None:
        """not passes when child fails."""
        guard = GuardSpec(negate=GuardSpec(name="is_deleted"))
        t = self._make_transition((guard,))
        result = evaluator.can_transition(t, {"deleted": False})
        assert result.passed

    def test_negate_fail(self, evaluator: GuardEvaluator) -> None:
        """not fails when child passes."""
        guard = GuardSpec(negate=GuardSpec(name="is_deleted"))
        t = self._make_transition((guard,))
        result = evaluator.can_transition(t, {"deleted": True})
        assert not result.passed

    def test_deeply_nested(self, evaluator: GuardEvaluator) -> None:
        """Nested: allOf(anyOf(not(is_deleted), is_vip), is_active)."""
        guard = GuardSpec(
            all_of=(
                GuardSpec(
                    any_of=(
                        GuardSpec(negate=GuardSpec(name="is_deleted")),
                        GuardSpec(name="is_vip"),
                    )
                ),
                GuardSpec(name="is_active"),
            )
        )
        t = self._make_transition((guard,))

        # not(deleted=True) fails, is_vip=True passes → anyOf passes
        # is_active=True passes → allOf passes
        result = evaluator.can_transition(
            t, {"deleted": True, "vip": True, "active": True}
        )
        assert result.passed

    def test_check_inside_composite(self, evaluator: GuardEvaluator) -> None:
        """Declarative check inside allOf."""
        guard = GuardSpec(
            all_of=(
                GuardSpec(check=CheckSpec(field="count", op="gte", value=5)),
                GuardSpec(name="is_active"),
            )
        )
        t = self._make_transition((guard,))
        result = evaluator.can_transition(t, {"count": 10, "active": True})
        assert result.passed

        result = evaluator.can_transition(t, {"count": 2, "active": True})
        assert not result.passed

    def test_named_guards_inside_composites_collected(
        self, evaluator: GuardEvaluator
    ) -> None:
        """get_required_guards recurses into composites."""
        guard = GuardSpec(
            all_of=(
                GuardSpec(name="is_valid"),
                GuardSpec(
                    any_of=(
                        GuardSpec(name="is_vip"),
                        GuardSpec(negate=GuardSpec(name="is_deleted")),
                    )
                ),
            )
        )
        t = self._make_transition((guard,))
        names = evaluator.get_required_guards([t])
        assert names == {"is_valid", "is_vip", "is_deleted"}


# ---------------------------------------------------------------------------
# Full machine config with composite guards
# ---------------------------------------------------------------------------


class TestGuardCompositionYAML:
    """Test guard composition through a full config dict."""

    def test_full_machine_from_dict(self) -> None:
        """Composite guards parsed from config dict and evaluated correctly."""
        from pystator.config._raw_parser import raw_config_to_core

        config = {
            "states": [
                {"name": "idle", "type": "initial"},
                {"name": "processing", "type": "stable"},
                {"name": "done", "type": "terminal"},
            ],
            "transitions": [
                {
                    "trigger": "START",
                    "source": "idle",
                    "dest": "processing",
                    "guards": [
                        {
                            "allOf": [
                                {
                                    "check": {
                                        "field": "status",
                                        "op": "eq",
                                        "value": "active",
                                    }
                                },
                                "is_valid",
                            ]
                        },
                        {
                            "not": {
                                "check": {"field": "deleted", "op": "eq", "value": True}
                            }
                        },
                    ],
                },
                {"trigger": "DONE", "source": "processing", "dest": "done"},
            ],
        }

        states, transitions, meta = raw_config_to_core(config)
        assert len(transitions) == 2
        start_trans = transitions[0]

        # Verify composite structure
        assert len(start_trans.guards) == 2
        g0 = start_trans.guards[0]
        assert g0.is_all_of
        assert len(g0.all_of) == 2
        assert g0.all_of[0].is_check
        assert g0.all_of[1].name == "is_valid"

        g1 = start_trans.guards[1]
        assert g1.is_negate
        assert g1.negate.is_check

    def test_backward_compat_plain_guards(self) -> None:
        """Existing plain string guards still work."""
        from pystator.config._raw_parser import raw_config_to_core

        config = {
            "states": [
                {"name": "idle", "type": "initial"},
                {"name": "done", "type": "terminal"},
            ],
            "transitions": [
                {
                    "trigger": "GO",
                    "source": "idle",
                    "dest": "done",
                    "guards": ["is_valid", "is_ready"],
                }
            ],
        }

        states, transitions, meta = raw_config_to_core(config)
        assert len(transitions[0].guards) == 2
        assert transitions[0].guards[0].name == "is_valid"
        assert transitions[0].guards[1].name == "is_ready"
        assert not transitions[0].guards[0].is_composite

    def test_any_of_in_yaml(self) -> None:
        """anyOf parsed from config dict."""
        from pystator.config._raw_parser import raw_config_to_core

        config = {
            "states": [
                {"name": "idle", "type": "initial"},
                {"name": "done", "type": "terminal"},
            ],
            "transitions": [
                {
                    "trigger": "GO",
                    "source": "idle",
                    "dest": "done",
                    "guards": [
                        {
                            "anyOf": [
                                {
                                    "check": {
                                        "field": "priority",
                                        "op": "gte",
                                        "value": 5,
                                    }
                                },
                                "is_vip",
                            ]
                        }
                    ],
                }
            ],
        }

        states, transitions, meta = raw_config_to_core(config)
        g = transitions[0].guards[0]
        assert g.is_any_of
        assert len(g.any_of) == 2
