"""Tests for PostgresStateStore.

Only URL validation and init behavior are tested here (no live PostgreSQL).
Integration tests should be marked with @pytest.mark.integration.
"""

from __future__ import annotations

import pytest

from pystator.stores.postgres import PostgresStateStore


class TestPostgresStateStoreInit:
    """Connection string validation."""

    def test_rejects_sqlite_url(self) -> None:
        with pytest.raises(ValueError, match="postgresql://"):
            PostgresStateStore("sqlite:///test.db")

    def test_rejects_mongodb_url(self) -> None:
        with pytest.raises(ValueError, match="postgresql://"):
            PostgresStateStore("mongodb://localhost/db")

    def test_accepts_postgresql_url(self) -> None:
        store = PostgresStateStore("postgresql://user:pass@localhost/db")
        assert store.connection_string == "postgresql://user:pass@localhost/db"

    def test_accepts_postgres_url(self) -> None:
        store = PostgresStateStore("postgres://user:pass@localhost/db")
        assert store.connection_string == "postgres://user:pass@localhost/db"

    def test_requires_connection_string(self) -> None:
        with pytest.raises(TypeError):
            PostgresStateStore()  # type: ignore[call-arg]
