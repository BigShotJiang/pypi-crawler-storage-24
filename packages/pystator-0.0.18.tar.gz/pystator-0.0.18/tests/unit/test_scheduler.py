"""Tests for scheduler adapters."""

import asyncio
from datetime import UTC, datetime

import pytest

from pystator.scheduler import (
    AsyncioScheduler,
    ScheduledTask,
    TaskStatus,
)
from pystator.scheduler.base import generate_task_id


class TestScheduledTask:
    """Tests for ScheduledTask dataclass."""

    def test_task_creation(self):
        """Create a scheduled task."""
        task = ScheduledTask(
            task_id="test-123",
            entity_id="order-456",
            event="timeout",
            delay_ms=5000,
        )
        assert task.task_id == "test-123"
        assert task.entity_id == "order-456"
        assert task.event == "timeout"
        assert task.delay_ms == 5000
        assert task.status == TaskStatus.PENDING
        assert task.is_pending is True

    def test_task_fires_at_computed(self):
        """fires_at is computed from scheduled_at + delay."""
        task = ScheduledTask(
            task_id="test-123",
            entity_id="order-456",
            event="timeout",
            delay_ms=5000,
        )
        assert task.fires_at is not None
        delta = (task.fires_at - task.scheduled_at).total_seconds() * 1000
        assert abs(delta - 5000) < 10  # Within 10ms

    def test_remaining_ms(self):
        """remaining_ms returns time until task fires."""
        task = ScheduledTask(
            task_id="test-123",
            entity_id="order-456",
            event="timeout",
            delay_ms=60000,  # 1 minute
        )
        # Should have close to 60 seconds remaining
        assert 59000 < task.remaining_ms <= 60000


class TestGenerateTaskId:
    """Tests for task ID generation."""

    def test_generates_unique_ids(self):
        """Each call generates a unique ID."""
        ids = [generate_task_id() for _ in range(100)]
        assert len(set(ids)) == 100

    def test_id_is_string(self):
        """Generated ID is a string."""
        task_id = generate_task_id()
        assert isinstance(task_id, str)
        assert len(task_id) > 0


class TestAsyncioScheduler:
    """Tests for AsyncioScheduler."""

    @pytest.fixture
    def scheduler(self):
        """Create a scheduler for testing."""
        return AsyncioScheduler()

    @pytest.mark.asyncio
    async def test_schedule_and_fire(self, scheduler):
        """Schedule a task and verify it fires."""
        fired = []

        async def callback():
            fired.append(datetime.now(UTC))

        task_id = await scheduler.schedule(
            delay_ms=50,  # 50ms
            callback=callback,
            entity_id="order-123",
            event="timeout",
        )

        assert task_id is not None
        assert len(fired) == 0

        # Wait for task to fire
        await asyncio.sleep(0.1)  # 100ms

        assert len(fired) == 1

    @pytest.mark.asyncio
    async def test_schedule_sync_callback(self, scheduler):
        """Schedule with a sync callback."""
        fired = []

        def callback():
            fired.append(True)

        await scheduler.schedule(
            delay_ms=50,
            callback=callback,
            entity_id="order-123",
            event="timeout",
        )

        await asyncio.sleep(0.1)
        assert len(fired) == 1

    @pytest.mark.asyncio
    async def test_cancel_task(self, scheduler):
        """Cancel a scheduled task."""
        fired = []

        async def callback():
            fired.append(True)

        task_id = await scheduler.schedule(
            delay_ms=100,  # 100ms
            callback=callback,
            entity_id="order-123",
            event="timeout",
        )

        # Cancel before it fires
        cancelled = await scheduler.cancel(task_id)
        assert cancelled is True

        # Wait past when it would have fired
        await asyncio.sleep(0.15)

        # Should not have fired
        assert len(fired) == 0

    @pytest.mark.asyncio
    async def test_cancel_nonexistent_task(self, scheduler):
        """Cancel returns False for nonexistent task."""
        cancelled = await scheduler.cancel("nonexistent-id")
        assert cancelled is False

    @pytest.mark.asyncio
    async def test_get_task(self, scheduler):
        """Get information about a scheduled task."""
        task_id = await scheduler.schedule(
            delay_ms=1000,
            callback=lambda: None,
            entity_id="order-123",
            event="timeout",
            metadata={"custom": "data"},
        )

        task = await scheduler.get_task(task_id)
        assert task is not None
        assert task.task_id == task_id
        assert task.entity_id == "order-123"
        assert task.event == "timeout"
        assert task.status == TaskStatus.PENDING
        assert task.metadata == {"custom": "data"}

    @pytest.mark.asyncio
    async def test_get_pending_tasks(self, scheduler):
        """Get all pending tasks."""
        await scheduler.schedule(50, lambda: None, "order-1", "timeout")
        await scheduler.schedule(50, lambda: None, "order-2", "expire")
        await scheduler.schedule(50, lambda: None, "order-1", "cancel")

        # All pending
        pending = await scheduler.get_pending_tasks()
        assert len(pending) == 3

        # Filter by entity
        pending = await scheduler.get_pending_tasks(entity_id="order-1")
        assert len(pending) == 2
        assert all(t.entity_id == "order-1" for t in pending)

    @pytest.mark.asyncio
    async def test_cancel_for_entity(self, scheduler):
        """Cancel all tasks for an entity."""
        await scheduler.schedule(100, lambda: None, "order-1", "timeout")
        await scheduler.schedule(100, lambda: None, "order-1", "expire")
        await scheduler.schedule(100, lambda: None, "order-2", "timeout")

        cancelled = await scheduler.cancel_for_entity("order-1")
        assert cancelled == 2

        pending = await scheduler.get_pending_tasks()
        assert len(pending) == 1
        assert pending[0].entity_id == "order-2"

    @pytest.mark.asyncio
    async def test_close_cancels_all(self, scheduler):
        """Closing scheduler cancels all pending tasks."""
        fired = []

        await scheduler.schedule(100, lambda: fired.append(1), "order-1", "e1")
        await scheduler.schedule(100, lambda: fired.append(2), "order-2", "e2")

        await scheduler.close()

        # Wait past when tasks would fire
        await asyncio.sleep(0.15)

        # Nothing should have fired
        assert len(fired) == 0
        assert scheduler.pending_count == 0

    @pytest.mark.asyncio
    async def test_task_status_updates(self, scheduler):
        """Task status updates through lifecycle."""
        task_id = await scheduler.schedule(
            delay_ms=50,
            callback=lambda: None,
            entity_id="order-123",
            event="timeout",
        )

        # Initially pending
        task = await scheduler.get_task(task_id)
        assert task.status == TaskStatus.PENDING

        # Wait for completion
        await asyncio.sleep(0.1)

        # After firing
        task = await scheduler.get_task(task_id)
        assert task.status == TaskStatus.COMPLETED

    @pytest.mark.asyncio
    async def test_callback_error_marks_failed(self, scheduler):
        """Callback error marks task as failed."""

        async def failing_callback():
            raise ValueError("Test error")

        task_id = await scheduler.schedule(
            delay_ms=10,
            callback=failing_callback,
            entity_id="order-123",
            event="timeout",
        )

        await asyncio.sleep(0.1)

        task = await scheduler.get_task(task_id)
        assert task.status == TaskStatus.FAILED

    @pytest.mark.asyncio
    async def test_pending_count(self, scheduler):
        """pending_count property works."""
        assert scheduler.pending_count == 0

        await scheduler.schedule(1000, lambda: None, "e1", "ev")
        assert scheduler.pending_count == 1

        await scheduler.schedule(1000, lambda: None, "e2", "ev")
        assert scheduler.pending_count == 2

        await scheduler.close()
        assert scheduler.pending_count == 0
