"""Tests for pystator world-class quality improvements.

Covers:
- Phase 1: Thread-safe MetricsCollector, TransitionObserver race fix,
           sync delayed cancel
- Phase 2: Context persistence via orchestrator
- Phase 3: on_enter/on_exit/on_transition callbacks, guard failure messages
- Phase 4: BatchStateStore, QueryableStateStore, batch_fallback
- Phase 5: AuditStore protocol + orchestrator wiring
- Phase 6: DwellTimeTracker, StructuredLoggingHook
"""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Any
from unittest.mock import MagicMock

import pytest

from pystator import (
    ActionRegistry,
    GuardRegistry,
    InMemoryStateStore,
    Orchestrator,
    StateMachine,
)
from pystator._types import TransitionResult
from pystator.hooks import (
    DwellTimeTracker,
    MetricsCollector,
    StructuredLoggingHook,
    TransitionObserver,
)
from pystator.stores.base import (
    BatchStateStore,
    QueryableStateStore,
    batch_fallback,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _simple_machine() -> StateMachine:
    """Build a simple 3-state machine for testing."""
    config = {
        "meta": {"machine_name": "test", "strict_mode": True},
        "states": [
            {"name": "pending", "type": "initial"},
            {"name": "active", "type": "stable"},
            {"name": "done", "type": "terminal"},
        ],
        "transitions": [
            {
                "trigger": "activate",
                "source": "pending",
                "dest": "active",
            },
            {
                "trigger": "finish",
                "source": "active",
                "dest": "done",
            },
        ],
    }
    return StateMachine.from_dict(config)


def _guarded_machine() -> StateMachine:
    """Build a machine with guards for failure message testing."""
    config = {
        "meta": {"machine_name": "guarded", "strict_mode": True},
        "states": [
            {"name": "pending", "type": "initial"},
            {"name": "active", "type": "stable"},
            {"name": "done", "type": "terminal"},
        ],
        "transitions": [
            {
                "trigger": "activate",
                "source": "pending",
                "dest": "active",
                "guards": ["has_permission"],
            },
            {
                "trigger": "finish",
                "source": "active",
                "dest": "done",
            },
        ],
    }
    machine = StateMachine.from_dict(config)
    machine._guard_registry.register(
        "has_permission", lambda ctx: ctx.get("permitted", False)
    )
    return machine


def _make_orchestrator(
    machine: StateMachine,
    store: InMemoryStateStore,
    hooks: list[Any] | None = None,
    audit_store: Any | None = None,
) -> Orchestrator:
    """Helper to build orchestrator with stub registries."""
    guards = GuardRegistry()
    guards.register("always", lambda ctx: True)
    actions = ActionRegistry()
    return Orchestrator(
        machine,
        store,
        guards,
        actions,
        hooks=hooks,
        audit_store=audit_store,
    )


# ===========================================================================
# Phase 1.1: Thread-safe MetricsCollector
# ===========================================================================


class TestMetricsCollectorThreadSafety:
    """MetricsCollector mutations are protected by a lock."""

    def test_concurrent_on_transition_complete(self) -> None:
        """Multiple threads can safely call on_transition_complete."""
        collector = MetricsCollector(max_history=500)
        n_threads = 10
        n_per_thread = 50
        barrier = threading.Barrier(n_threads)

        def worker() -> None:
            barrier.wait()
            for _ in range(n_per_thread):
                result = TransitionResult.success_result(
                    source_state="a",
                    target_state="b",
                    trigger="go",
                    actions=(),
                    on_exit=(),
                    on_enter=(),
                )
                collector.on_transition_complete(result, 1.0, {})

        threads = [threading.Thread(target=worker) for _ in range(n_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        summary = collector.get_summary()
        assert summary["total_transitions"] == n_threads * n_per_thread

    def test_bounded_memory(self) -> None:
        """Transitions and durations are bounded by max_history."""
        collector = MetricsCollector(max_history=5)
        for i in range(20):
            result = TransitionResult.success_result(
                source_state="a",
                target_state="b",
                trigger="go",
                actions=(),
                on_exit=(),
                on_enter=(),
            )
            collector.on_transition_complete(result, float(i), {})

        # Counters still accumulate
        assert collector.get_summary()["total_transitions"] == 20
        # But deques are bounded
        assert len(collector._transitions) == 5
        assert len(collector._durations) == 5

    def test_reset_clears_all(self) -> None:
        """reset() clears all state."""
        collector = MetricsCollector()
        result = TransitionResult.success_result(
            source_state="a",
            target_state="b",
            trigger="go",
            actions=(),
            on_exit=(),
            on_enter=(),
        )
        collector.on_transition_complete(result, 1.0, {})
        collector.on_transition_error(RuntimeError(), "a", "go", {})
        collector.reset()
        summary = collector.get_summary()
        assert summary["total_transitions"] == 0
        assert summary["errors"] == 0


# ===========================================================================
# Phase 1.2: TransitionObserver timing race
# ===========================================================================


class TestTransitionObserverThreadSafety:
    """Per-thread timing state prevents timing races."""

    def test_concurrent_transitions_isolated_timing(self) -> None:
        """Each thread gets its own timing state."""
        observer = TransitionObserver()
        durations: list[float] = []

        class TimingHook:
            """Hook that records durations."""

            def on_before_process(self, *a: Any, **kw: Any) -> None:
                pass

            def on_transition_start(self, *a: Any, **kw: Any) -> None:
                pass

            def on_transition_complete(
                self,
                result: TransitionResult,
                duration_ms: float,
                context: dict[str, Any],
            ) -> None:
                durations.append(duration_ms)

            def on_transition_error(self, *a: Any, **kw: Any) -> None:
                pass

        observer.add_hook(TimingHook())
        barrier = threading.Barrier(2)

        def fast_thread() -> None:
            barrier.wait()
            observer.before_transition("a", "go", {})
            # Short sleep
            time.sleep(0.01)
            result = TransitionResult.success_result(
                source_state="a",
                target_state="b",
                trigger="go",
                actions=(),
                on_exit=(),
                on_enter=(),
            )
            observer.after_transition(result, {})

        def slow_thread() -> None:
            barrier.wait()
            observer.before_transition("x", "go", {})
            # Longer sleep
            time.sleep(0.05)
            result = TransitionResult.success_result(
                source_state="x",
                target_state="y",
                trigger="go",
                actions=(),
                on_exit=(),
                on_enter=(),
            )
            observer.after_transition(result, {})

        t1 = threading.Thread(target=fast_thread)
        t2 = threading.Thread(target=slow_thread)
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        # Both threads should have recorded durations > 0
        assert len(durations) == 2
        assert all(d > 0 for d in durations)


# ===========================================================================
# Phase 2: Context persistence
# ===========================================================================


class TestContextPersistence:
    """Orchestrator persists context after action execution."""

    def test_context_persisted_after_transition(self) -> None:
        """Context is saved to store after successful transition."""
        machine = _simple_machine()
        store = InMemoryStateStore()
        orch = _make_orchestrator(machine, store)

        orch.process_event("e1", "activate", {"foo": "bar"})

        ctx = store.get_context("e1")
        assert ctx.get("foo") == "bar"
        # Internal keys should be filtered out
        assert "_event" not in ctx
        assert "_entity_id" not in ctx

    @pytest.mark.asyncio
    async def test_context_persisted_async(self) -> None:
        """Async path also persists context."""
        machine = _simple_machine()
        store = InMemoryStateStore()
        orch = _make_orchestrator(machine, store)

        await orch.async_process_event("e1", "activate", {"baz": 42})

        ctx = store.get_context("e1")
        assert ctx.get("baz") == 42


# ===========================================================================
# Phase 3.1: on_enter / on_exit / on_transition callbacks
# ===========================================================================


class TestCallbackDecorators:
    """Callback decorators on StateMachine."""

    def test_on_enter_fires(self) -> None:
        """on_enter callback fires when target state is entered."""
        machine = _simple_machine()
        entered: list[str] = []

        @machine.on_enter("active")
        def on_active(ctx: dict[str, Any]) -> None:
            entered.append("active")

        order = machine.create()
        order.send("activate")

        assert entered == ["active"]

    def test_on_exit_fires(self) -> None:
        """on_exit callback fires when source state is exited."""
        machine = _simple_machine()
        exited: list[str] = []

        @machine.on_exit("pending")
        def on_leave_pending(ctx: dict[str, Any]) -> None:
            exited.append("pending")

        order = machine.create()
        order.send("activate")

        assert exited == ["pending"]

    def test_on_transition_fires(self) -> None:
        """on_transition callback fires for specific (source, target) pair."""
        machine = _simple_machine()
        transitions: list[tuple[str, str]] = []

        @machine.on_transition("pending", "active")
        def on_p_to_a(ctx: dict[str, Any]) -> None:
            transitions.append(("pending", "active"))

        order = machine.create()
        order.send("activate")

        assert transitions == [("pending", "active")]

    def test_callbacks_do_not_fire_on_failure(self) -> None:
        """Callbacks are not called when transition fails."""
        machine = _guarded_machine()
        calls: list[str] = []

        @machine.on_enter("active")
        def on_active(ctx: dict[str, Any]) -> None:
            calls.append("entered")

        result = machine.process("pending", "activate", {"permitted": False})
        assert not result.success
        assert calls == []

    def test_multiple_callbacks_same_state(self) -> None:
        """Multiple callbacks for the same state all fire."""
        machine = _simple_machine()
        calls: list[str] = []

        @machine.on_enter("active")
        def first(ctx: dict[str, Any]) -> None:
            calls.append("first")

        @machine.on_enter("active")
        def second(ctx: dict[str, Any]) -> None:
            calls.append("second")

        order = machine.create()
        order.send("activate")

        assert calls == ["first", "second"]

    def test_callback_error_does_not_break_send(self) -> None:
        """A callback that raises does not prevent the transition."""
        machine = _simple_machine()

        @machine.on_enter("active")
        def explode(ctx: dict[str, Any]) -> None:
            raise ValueError("boom")

        order = machine.create()
        result = order.send("activate")

        assert result.success
        assert order.current_state == "active"

    @pytest.mark.asyncio
    async def test_async_callback_in_async_path(self) -> None:
        """Async callbacks are awaited in the async send path."""
        machine = _simple_machine()
        calls: list[str] = []

        @machine.on_enter("active")
        async def async_cb(ctx: dict[str, Any]) -> None:
            calls.append("async_entered")

        order = machine.create()
        await order.asend("activate")

        assert calls == ["async_entered"]

    def test_callbacks_fire_in_orchestrator(self) -> None:
        """Callbacks also fire when using the Orchestrator."""
        machine = _simple_machine()
        entered: list[str] = []

        @machine.on_enter("active")
        def on_active(ctx: dict[str, Any]) -> None:
            entered.append("active")

        store = InMemoryStateStore()
        orch = _make_orchestrator(machine, store)
        orch.process_event("e1", "activate")

        assert entered == ["active"]


# ===========================================================================
# Phase 3.2: Guard failure messages
# ===========================================================================


class TestGuardFailureMessages:
    """Guard failure includes the first failing guard name."""

    def test_failing_guard_name_in_error(self) -> None:
        """Error message includes the specific guard name."""
        machine = _guarded_machine()
        result = machine.process("pending", "activate", {"permitted": False})

        assert not result.success
        assert result.error is not None
        assert "has_permission" in str(result.error)

    def test_guard_details_in_metadata(self) -> None:
        """Full guard details are still in metadata."""
        machine = _guarded_machine()
        result = machine.process("pending", "activate", {"permitted": False})

        guards = result.metadata.get("guards")
        assert guards is not None
        assert any(g["name"] == "has_permission" for g in guards)


# ===========================================================================
# Phase 4: Batch & Queryable
# ===========================================================================


class TestBatchStateStore:
    """InMemoryStateStore implements BatchStateStore."""

    def test_get_states_batch(self) -> None:
        store = InMemoryStateStore()
        store.set_state("e1", "a")
        store.set_state("e2", "b")

        result = store.get_states_batch(["e1", "e2", "e3"])
        assert result == {"e1": "a", "e2": "b", "e3": None}

    def test_set_states_batch(self) -> None:
        store = InMemoryStateStore()
        store.set_states_batch({"e1": "a", "e2": "b"})

        assert store.get_state("e1") == "a"
        assert store.get_state("e2") == "b"

    def test_isinstance_check(self) -> None:
        """InMemoryStateStore satisfies BatchStateStore protocol."""
        store = InMemoryStateStore()
        assert isinstance(store, BatchStateStore)


class TestQueryableStateStore:
    """InMemoryStateStore implements QueryableStateStore."""

    def test_list_entities_all(self) -> None:
        store = InMemoryStateStore()
        store.set_state("e1", "a")
        store.set_state("e2", "b")

        ids = store.list_entities()
        assert sorted(ids) == ["e1", "e2"]

    def test_list_entities_by_state(self) -> None:
        store = InMemoryStateStore()
        store.set_state("e1", "active")
        store.set_state("e2", "done")
        store.set_state("e3", "active")

        ids = store.list_entities(state="active")
        assert sorted(ids) == ["e1", "e3"]

    def test_list_entities_pagination(self) -> None:
        store = InMemoryStateStore()
        for i in range(10):
            store.set_state(f"e{i}", "a")

        page = store.list_entities(limit=3, offset=2)
        assert len(page) == 3

    def test_count_by_state(self) -> None:
        store = InMemoryStateStore()
        store.set_state("e1", "active")
        store.set_state("e2", "done")
        store.set_state("e3", "active")

        counts = store.count_by_state()
        assert counts == {"active": 2, "done": 1}

    def test_isinstance_check(self) -> None:
        """InMemoryStateStore satisfies QueryableStateStore protocol."""
        store = InMemoryStateStore()
        assert isinstance(store, QueryableStateStore)


class TestBatchFallback:
    """batch_fallback wraps any StateStore with loop-based batch ops."""

    def test_fallback_get_states_batch(self) -> None:
        store = InMemoryStateStore()
        store.set_state("e1", "a")
        wrapper = batch_fallback(store)

        result = wrapper.get_states_batch(["e1", "e2"])
        assert result == {"e1": "a", "e2": None}

    def test_fallback_set_states_batch(self) -> None:
        store = InMemoryStateStore()
        wrapper = batch_fallback(store)
        wrapper.set_states_batch({"e1": "x", "e2": "y"})

        assert store.get_state("e1") == "x"
        assert store.get_state("e2") == "y"


# ===========================================================================
# Phase 5: Audit trail
# ===========================================================================


class TestAuditStoreWiring:
    """Orchestrator records audit when audit_store is provided."""

    def test_audit_recorded_on_success(self) -> None:
        """record_transition called after successful transition."""
        machine = _simple_machine()
        store = InMemoryStateStore()
        audit = MagicMock()

        orch = _make_orchestrator(machine, store, audit_store=audit)
        orch.process_event("e1", "activate")

        audit.record_transition.assert_called_once()
        call_kwargs = audit.record_transition.call_args
        assert call_kwargs.kwargs["entity_id"] == "e1"
        assert call_kwargs.kwargs["source_state"] == "pending"
        assert call_kwargs.kwargs["trigger"] == "activate"
        assert call_kwargs.kwargs["target_state"] == "active"
        assert call_kwargs.kwargs["success"] is True

    def test_no_audit_when_not_provided(self) -> None:
        """No error when audit_store is None."""
        machine = _simple_machine()
        store = InMemoryStateStore()
        orch = _make_orchestrator(machine, store, audit_store=None)

        result = orch.process_event("e1", "activate")
        assert result.success

    def test_audit_not_recorded_on_failure(self) -> None:
        """Audit not recorded for failed transitions (no state change)."""
        machine = _guarded_machine()
        store = InMemoryStateStore()
        audit = MagicMock()

        orch = Orchestrator(machine, store, audit_store=audit)
        orch.process_event("e1", "activate", {"permitted": False})

        audit.record_transition.assert_not_called()


# ===========================================================================
# Phase 6.1: DwellTimeTracker
# ===========================================================================


class TestDwellTimeTracker:
    """DwellTimeTracker tracks time spent in each state."""

    def test_tracks_entry_time(self) -> None:
        """get_dwell_time returns time since state entry."""
        tracker = DwellTimeTracker()
        tracker.on_before_process("e1", "pending", "go", {})

        dwell = tracker.get_dwell_time("e1")
        assert dwell is not None
        assert dwell >= 0

    def test_unknown_entity_returns_none(self) -> None:
        """get_dwell_time returns None for unknown entity."""
        tracker = DwellTimeTracker()
        assert tracker.get_dwell_time("e1") is None

    def test_avg_dwell_by_state(self) -> None:
        """get_avg_dwell_by_state computes averages from history."""
        tracker = DwellTimeTracker()

        # Simulate entity entering "pending" and transitioning to "active"
        tracker.on_before_process("e1", "pending", "go", {})
        time.sleep(0.01)
        result = TransitionResult.success_result(
            source_state="pending",
            target_state="active",
            trigger="go",
            actions=(),
            on_exit=(),
            on_enter=(),
        )
        tracker.on_transition_complete(result, 1.0, {"_entity_id": "e1"})

        avgs = tracker.get_avg_dwell_by_state()
        assert "pending" in avgs
        assert avgs["pending"] > 0


# ===========================================================================
# Phase 6.2: StructuredLoggingHook
# ===========================================================================


class TestStructuredLoggingHook:
    """StructuredLoggingHook emits JSON log entries."""

    def test_on_before_process_emits_json(self, caplog: Any) -> None:
        """on_before_process logs valid JSON."""
        hook = StructuredLoggingHook(
            log_level=logging.INFO,
            logger_name="pystator.structured",
        )
        with caplog.at_level(logging.INFO, logger="pystator.structured"):
            hook.on_before_process("e1", "pending", "go", {})

        assert len(caplog.records) == 1
        data = json.loads(caplog.records[0].message)
        assert data["event"] == "before_process"
        assert data["entity_id"] == "e1"

    def test_on_transition_complete_emits_json(self, caplog: Any) -> None:
        """on_transition_complete logs valid JSON with duration."""
        hook = StructuredLoggingHook(
            log_level=logging.INFO,
            logger_name="pystator.structured",
        )
        result = TransitionResult.success_result(
            source_state="a",
            target_state="b",
            trigger="go",
            actions=(),
            on_exit=(),
            on_enter=(),
        )
        with caplog.at_level(logging.INFO, logger="pystator.structured"):
            hook.on_transition_complete(result, 5.123, {})

        data = json.loads(caplog.records[0].message)
        assert data["event"] == "transition_complete"
        assert data["success"] is True
        assert data["duration_ms"] == 5.123

    def test_on_transition_error_emits_json(self, caplog: Any) -> None:
        """on_transition_error logs error details as JSON."""
        hook = StructuredLoggingHook(
            log_level=logging.INFO,
            logger_name="pystator.structured",
        )
        with caplog.at_level(logging.INFO, logger="pystator.structured"):
            hook.on_transition_error(ValueError("boom"), "a", "go", {})

        data = json.loads(caplog.records[0].message)
        assert data["event"] == "transition_error"
        assert data["error_type"] == "ValueError"
        assert data["error_message"] == "boom"
