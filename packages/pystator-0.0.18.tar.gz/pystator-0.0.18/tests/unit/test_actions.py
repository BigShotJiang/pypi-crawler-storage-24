"""Unit tests for action system."""

from __future__ import annotations

import pytest

from pystator import (
    ActionNotFoundError,
    ActionRegistry,
    ActionResult,
    ActionSpec,
    TransitionResult,
)
from pystator.actions import ActionExecutor


class TestActionRegistry:
    """Tests for ActionRegistry."""

    def test_register_and_get(self) -> None:
        """Test registering and retrieving actions."""
        registry = ActionRegistry()

        def my_action(ctx: dict) -> str:
            return f"executed with {ctx}"

        registry.register("my_action", my_action)
        func = registry.get("my_action")
        assert func({"key": "value"}) == "executed with {'key': 'value'}"

    def test_register_duplicate_raises(self) -> None:
        """Test that registering duplicate name raises."""
        registry = ActionRegistry()
        registry.register("test", lambda ctx: None)
        with pytest.raises(ValueError, match="already registered"):
            registry.register("test", lambda ctx: None)

    def test_register_empty_name_raises(self) -> None:
        """Test that empty name raises error."""
        registry = ActionRegistry()
        with pytest.raises(ValueError, match="empty"):
            registry.register("", lambda ctx: None)

    def test_get_nonexistent_raises(self) -> None:
        """Test that getting non-existent action raises."""
        registry = ActionRegistry()
        with pytest.raises(ActionNotFoundError):
            registry.get("nonexistent")

    def test_has(self) -> None:
        """Test has method."""
        registry = ActionRegistry()
        registry.register("exists", lambda ctx: None)

        assert registry.has("exists") is True
        assert registry.has("not_exists") is False

    def test_unregister(self) -> None:
        """Test unregistering actions."""
        registry = ActionRegistry()
        registry.register("test", lambda ctx: None)
        registry.unregister("test")

        assert registry.has("test") is False

    def test_execute_success(self) -> None:
        """Test executing an action successfully."""
        registry = ActionRegistry()
        registry.register("test", lambda ctx: "result")

        result = registry.execute("test", {})
        assert result.success is True
        assert result.action_name == "test"
        assert result.result == "result"
        assert result.error is None

    def test_execute_failure(self) -> None:
        """Test executing an action that raises."""
        registry = ActionRegistry()

        def failing_action(ctx: dict) -> None:
            raise ValueError("Action failed")

        registry.register("failing", failing_action)
        result = registry.execute("failing", {})

        assert result.success is False
        assert result.action_name == "failing"
        assert isinstance(result.error, ValueError)

    def test_execute_raise_on_error(self) -> None:
        """Test execute with raise_on_error."""
        registry = ActionRegistry()
        registry.register("failing", lambda ctx: 1 / 0)

        with pytest.raises(ZeroDivisionError):
            registry.execute("failing", {}, raise_on_error=True)

    def test_execute_all(self) -> None:
        """Test executing multiple actions."""
        executed: list[str] = []
        registry = ActionRegistry()

        registry.register("a", lambda ctx: executed.append("a"))
        registry.register("b", lambda ctx: executed.append("b"))
        registry.register("c", lambda ctx: executed.append("c"))

        results = registry.execute_all(["a", "b", "c"], {})

        assert len(results) == 3
        assert all(r.success for r in results)
        assert executed == ["a", "b", "c"]

    def test_execute_all_stop_on_error(self) -> None:
        """Test execute_all with stop_on_error."""
        executed: list[str] = []
        registry = ActionRegistry()

        registry.register("a", lambda ctx: executed.append("a"))
        registry.register("b", lambda ctx: 1 / 0)
        registry.register("c", lambda ctx: executed.append("c"))

        results = registry.execute_all(["a", "b", "c"], {}, stop_on_error=True)

        assert len(results) == 2  # Stopped at b
        assert executed == ["a"]  # Only a executed

    def test_list_actions(self) -> None:
        """Test listing registered actions."""
        registry = ActionRegistry()
        registry.register("a", lambda ctx: None)
        registry.register("b", lambda ctx: None)

        actions = registry.list_actions()
        assert set(actions) == {"a", "b"}

    def test_metadata(self) -> None:
        """Test action metadata."""
        registry = ActionRegistry()
        registry.register(
            "test",
            lambda ctx: None,
            metadata={"description": "Test action", "priority": 1},
        )

        meta = registry.get_metadata("test")
        assert meta["description"] == "Test action"
        assert meta["priority"] == 1

    def test_decorator(self) -> None:
        """Test decorator for registration."""
        registry = ActionRegistry()

        @registry.decorator()
        def my_action(ctx: dict) -> str:
            return "done"

        assert "my_action" in registry
        result = registry.execute("my_action", {})
        assert result.result == "done"

    def test_decorator_with_name(self) -> None:
        """Test decorator with custom name."""
        registry = ActionRegistry()

        @registry.decorator(name="custom_name")
        def my_action(ctx: dict) -> str:
            return "done"

        assert "custom_name" in registry
        assert "my_action" not in registry


class TestActionResult:
    """Tests for ActionResult dataclass."""

    def test_ok_result(self) -> None:
        """Test creating OK result."""
        result = ActionResult.ok("test_action", "return_value")
        assert result.success is True
        assert result.action_name == "test_action"
        assert result.result == "return_value"
        assert result.error is None

    def test_fail_result(self) -> None:
        """Test creating fail result."""
        error = ValueError("Something went wrong")
        result = ActionResult.fail("test_action", error)

        assert result.success is False
        assert result.action_name == "test_action"
        assert result.error == error


class TestActionExecutor:
    """Tests for ActionExecutor."""

    def test_execute_transition_result(self) -> None:
        """Test executing actions from transition result."""
        executed: list[str] = []

        registry = ActionRegistry()
        registry.register("exit_action", lambda ctx: executed.append("exit"))
        registry.register("trans_action", lambda ctx: executed.append("trans"))
        registry.register("enter_action", lambda ctx: executed.append("enter"))

        executor = ActionExecutor(registry, log_execution=False)

        trans_result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
            actions=(ActionSpec(name="trans_action"),),
            on_exit=(ActionSpec(name="exit_action"),),
            on_enter=(ActionSpec(name="enter_action"),),
        )

        result = executor.execute(trans_result, {})

        assert result.all_succeeded
        assert executed == ["exit", "trans", "enter"]

    def test_execute_failed_transition(self) -> None:
        """Test executing with failed transition result."""
        registry = ActionRegistry()
        executor = ActionExecutor(registry, log_execution=False)

        from pystator import InvalidTransitionError

        trans_result = TransitionResult.failure_result(
            source_state="A",
            trigger="fail",
            error=InvalidTransitionError("failed", "A", "fail"),
        )

        result = executor.execute(trans_result, {})

        assert result.all_succeeded  # No actions to execute
        assert len(result.action_results) == 0

    def test_execute_missing_action(self) -> None:
        """Test executing with missing action (skipped)."""
        registry = ActionRegistry()
        executor = ActionExecutor(registry, log_execution=False)

        trans_result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
            actions=(ActionSpec("nonexistent_action"),),
        )

        result = executor.execute(trans_result, {})

        # Missing actions are skipped, not failures
        assert len(result.action_results) == 1
        assert result.action_results[0].is_skipped
        assert result.action_results[0].result == "not_registered"

    def test_execute_specific(self) -> None:
        """Test executing specific actions."""
        executed: list[str] = []

        registry = ActionRegistry()
        registry.register("a", lambda ctx: executed.append("a"))
        registry.register("b", lambda ctx: executed.append("b"))

        executor = ActionExecutor(registry, log_execution=False)
        results = executor.execute_specific(["a", "b"], {})

        assert len(results) == 2
        assert all(r.success for r in results)
        assert executed == ["a", "b"]

    def test_validate_actions_exist(self) -> None:
        """Test validating actions exist."""
        registry = ActionRegistry()
        registry.register("exists", lambda ctx: None)

        executor = ActionExecutor(registry)

        trans_result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
            actions=(ActionSpec("exists"), ActionSpec("missing")),
        )

        missing = executor.validate_actions_exist(trans_result)
        assert missing == ["missing"]

    def test_execution_result_properties(self) -> None:
        """Test ExecutionResult properties."""
        registry = ActionRegistry()
        registry.register("success_action", lambda ctx: "ok")
        registry.register("fail_action", lambda ctx: 1 / 0)

        executor = ActionExecutor(registry, log_execution=False)

        trans_result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
            actions=(ActionSpec("success_action"), ActionSpec("fail_action")),
        )

        result = executor.execute(trans_result, {})

        assert result.all_succeeded is False
        assert result.failed_actions == ["fail_action"]
        assert result.succeeded_actions == ["success_action"]
        assert result.duration_ms is not None
