"""Tests for SQLiteStateStore."""

from __future__ import annotations

from typing import Any

import pytest

from pystator.stores.sqlite import SQLiteStateStore


class TestSQLiteStateStoreInit:
    """Connection string validation and init behavior."""

    def test_rejects_postgres_url(self) -> None:
        with pytest.raises(ValueError, match="sqlite://"):
            SQLiteStateStore("postgresql://localhost/db")

    def test_rejects_mongodb_url(self) -> None:
        with pytest.raises(ValueError, match="sqlite://"):
            SQLiteStateStore("mongodb://localhost/db")

    def test_accepts_sqlite_url(self) -> None:
        store = SQLiteStateStore("sqlite:///:memory:")
        assert store.connection_string == "sqlite:///:memory:"

    def test_defaults_when_none_in_clean_env(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Any
    ) -> None:
        """With no env/config, defaults to a sqlite:// URL."""
        monkeypatch.delenv("PYSTATOR_DATABASE_URL", raising=False)
        monkeypatch.delenv("DATABASE_URL", raising=False)
        # Run from a temp dir so alembic.ini / pystator.cfg won't be found.
        monkeypatch.chdir(tmp_path)
        store = SQLiteStateStore()
        assert store.connection_string is not None
        assert store.connection_string.startswith("sqlite://")


class TestSQLiteStateStoreLifecycle:
    """Connect / disconnect."""

    def test_connect_auto_initialize(self) -> None:
        store = SQLiteStateStore("sqlite:///:memory:")
        store.connect(auto_initialize=True)
        assert store._connection is not None
        store.disconnect()
        assert store._connection is None

    def test_connect_without_auto_initialize_raises(self) -> None:
        store = SQLiteStateStore("sqlite:///:memory:")
        with pytest.raises(RuntimeError, match="not initialized"):
            store.connect(validate_schema=True, auto_initialize=False)

    def test_context_manager(self) -> None:
        with SQLiteStateStore("sqlite:///:memory:") as store:
            assert store._connection is not None
        assert store._connection is None


class TestSQLiteStateStoreProtocol:
    """StateStore and VersionedStateStore methods."""

    @pytest.fixture()
    def store(self) -> SQLiteStateStore:
        s = SQLiteStateStore("sqlite:///:memory:")
        s.connect(auto_initialize=True)
        yield s  # type: ignore[misc]
        s.disconnect()

    # -- StateStore --------------------------------------------------------

    def test_get_state_missing(self, store: SQLiteStateStore) -> None:
        assert store.get_state("nonexistent") is None

    def test_set_and_get_state(self, store: SQLiteStateStore) -> None:
        store.set_state("e1", "pending")
        assert store.get_state("e1") == "pending"

    def test_set_state_upsert(self, store: SQLiteStateStore) -> None:
        store.set_state("e1", "pending")
        store.set_state("e1", "active")
        assert store.get_state("e1") == "active"

    def test_get_context_empty(self, store: SQLiteStateStore) -> None:
        assert store.get_context("missing") == {}

    def test_set_state_with_context(self, store: SQLiteStateStore) -> None:
        store.set_state("e1", "open", metadata={"context": {"k": "v"}})
        assert store.get_context("e1") == {"k": "v"}

    # -- VersionedStateStore -----------------------------------------------

    def test_get_state_versioned_missing(self, store: SQLiteStateStore) -> None:
        state, ver = store.get_state_versioned("missing")
        assert state is None
        assert ver is None

    def test_set_state_versioned_new(self, store: SQLiteStateStore) -> None:
        ver = store.set_state_versioned("e1", "pending")
        assert ver == 1
        state, v = store.get_state_versioned("e1")
        assert state == "pending"
        assert v == 1

    def test_set_state_versioned_increment(self, store: SQLiteStateStore) -> None:
        store.set_state_versioned("e1", "pending")
        v2 = store.set_state_versioned("e1", "active", expected_version=1)
        assert v2 == 2

    def test_set_state_versioned_stale(self, store: SQLiteStateStore) -> None:
        from pystator.errors import StaleVersionError

        store.set_state_versioned("e1", "pending")
        with pytest.raises(StaleVersionError):
            store.set_state_versioned("e1", "active", expected_version=999)

    # -- Extended helpers --------------------------------------------------

    def test_set_context(self, store: SQLiteStateStore) -> None:
        store.set_state("e1", "open")
        store.set_context("e1", {"qty": 10})
        assert store.get_context("e1") == {"qty": 10}

    def test_set_context_missing_entity(self, store: SQLiteStateStore) -> None:
        with pytest.raises(ValueError, match="not found"):
            store.set_context("missing", {"k": "v"})

    def test_get_is_terminal(self, store: SQLiteStateStore) -> None:
        store.set_state("e1", "done", metadata={"is_terminal": True})
        assert store.get_is_terminal("e1") is True

    def test_get_is_terminal_missing(self, store: SQLiteStateStore) -> None:
        assert store.get_is_terminal("missing") is None

    def test_list_entities(self, store: SQLiteStateStore) -> None:
        store.set_state("a", "s1")
        store.set_state("b", "s2")
        entities = store.list_entities()
        ids = [e["entity_id"] for e in entities]
        assert "a" in ids
        assert "b" in ids

    def test_list_entities_filter_machine(self, store: SQLiteStateStore) -> None:
        store.set_state("a", "s1", metadata={"machine_name": "m1"})
        store.set_state("b", "s2", metadata={"machine_name": "m2"})
        result = store.list_entities(machine_name="m1")
        assert len(result) == 1
        assert result[0]["entity_id"] == "a"

    def test_delete_entity(self, store: SQLiteStateStore) -> None:
        store.set_state("e1", "open")
        assert store.delete_entity("e1") is True
        assert store.get_state("e1") is None

    def test_delete_entity_missing(self, store: SQLiteStateStore) -> None:
        assert store.delete_entity("missing") is False

    # -- Transition history ------------------------------------------------

    def test_record_and_get_transition_history(self, store: SQLiteStateStore) -> None:
        rid = store.record_transition(
            entity_id="e1",
            source_state="pending",
            trigger="confirm",
            target_state="confirmed",
            success=True,
            machine_name="test_machine",
        )
        assert rid is not None

        history = store.get_transition_history("e1")
        assert len(history) == 1
        assert history[0]["source_state"] == "pending"
        assert history[0]["target_state"] == "confirmed"
        assert history[0]["trigger"] == "confirm"
        assert history[0]["success"] is True
