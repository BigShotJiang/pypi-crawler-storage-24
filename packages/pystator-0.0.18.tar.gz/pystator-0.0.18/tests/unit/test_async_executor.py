"""Unit tests for async action execution."""

import asyncio
from datetime import UTC, datetime

import pytest

from pystator import TransitionResult
from pystator.actions import ActionExecutor, ActionRegistry, ExecutionMode


class TestAsyncExecutor:
    """Tests for async action execution."""

    @pytest.fixture
    def registry(self) -> ActionRegistry:
        """Create a test action registry."""
        reg = ActionRegistry()

        # Sync action
        def sync_action(ctx: dict) -> str:
            ctx["sync_called"] = True
            return "sync_result"

        # Async action
        async def async_action(ctx: dict) -> str:
            await asyncio.sleep(0.01)  # Simulate async work
            ctx["async_called"] = True
            return "async_result"

        # Slow action
        async def slow_action(ctx: dict) -> str:
            await asyncio.sleep(0.05)
            ctx["slow_called"] = True
            return "slow_result"

        # Failing action
        def failing_action(ctx: dict) -> None:
            raise ValueError("Action failed")

        reg.register("sync_action", sync_action)
        reg.register("async_action", async_action)
        reg.register("slow_action", slow_action)
        reg.register("failing_action", failing_action)

        return reg

    @pytest.fixture
    def transition_result(self) -> TransitionResult:
        """Create a test transition result."""
        from pystator import ActionSpec

        return TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="test",
            actions=(ActionSpec("sync_action"), ActionSpec("async_action")),
            on_exit=(),
            on_enter=(),
        )

    @pytest.mark.asyncio
    async def test_async_execute_sequential(self, registry, transition_result):
        """Test async sequential execution."""
        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        result = await executor.async_execute(transition_result, context)

        assert result.all_succeeded is True
        assert context["sync_called"] is True
        assert context["async_called"] is True
        assert result.execution_mode == ExecutionMode.SEQUENTIAL

    @pytest.mark.asyncio
    async def test_async_execute_parallel(self, registry):
        """Test async parallel execution."""
        from pystator import ActionSpec

        tr = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="test",
            actions=(
                ActionSpec("sync_action"),
                ActionSpec("async_action"),
                ActionSpec("slow_action"),
            ),
        )

        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        start = datetime.now(UTC)
        result = await executor.async_execute_parallel(tr, context)
        duration = (datetime.now(UTC) - start).total_seconds()

        assert result.all_succeeded is True
        assert context["sync_called"] is True
        assert context["async_called"] is True
        assert context["slow_called"] is True
        assert result.execution_mode == ExecutionMode.PARALLEL

        # Parallel should be faster than sequential
        # (slow_action takes 0.05s, all should run in ~0.05s not 0.07s)
        assert duration < 0.15  # Allow some overhead

    @pytest.mark.asyncio
    async def test_async_execute_phased(self, registry):
        """Test async phased execution."""
        from pystator import ActionSpec

        tr = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="test",
            actions=(ActionSpec("sync_action"),),
            on_exit=(ActionSpec("async_action"),),
            on_enter=(ActionSpec("slow_action"),),
        )

        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        result = await executor.async_execute_phased(tr, context)

        assert result.all_succeeded is True
        assert context["async_called"] is True  # exit phase
        assert context["sync_called"] is True  # transition phase
        assert context["slow_called"] is True  # enter phase
        assert result.execution_mode == ExecutionMode.PHASED

    @pytest.mark.asyncio
    async def test_async_execute_with_mode(self, registry, transition_result):
        """Test async execution with explicit mode."""
        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        # Test SEQUENTIAL mode
        result = await executor.async_execute_with_mode(
            transition_result, context, mode=ExecutionMode.SEQUENTIAL
        )
        assert result.execution_mode == ExecutionMode.SEQUENTIAL

        # Test PARALLEL mode
        context = {}
        result = await executor.async_execute_with_mode(
            transition_result, context, mode=ExecutionMode.PARALLEL
        )
        assert result.execution_mode == ExecutionMode.PARALLEL

    @pytest.mark.asyncio
    async def test_async_execute_parallel_with_failure(self, registry):
        """Test parallel execution with failing action."""
        from pystator import ActionSpec

        tr = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="test",
            actions=(
                ActionSpec("sync_action"),
                ActionSpec("failing_action"),
                ActionSpec("async_action"),
            ),
        )

        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        result = await executor.async_execute_parallel(tr, context)

        assert result.all_succeeded is False
        assert "failing_action" in result.failed_actions
        # Other actions should still complete in parallel mode
        assert "sync_action" in result.succeeded_actions
        assert "async_action" in result.succeeded_actions

    @pytest.mark.asyncio
    async def test_async_execute_phased_stop_on_error(self, registry):
        """Test phased execution stops on error when configured."""
        from pystator import ActionSpec

        tr = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="test",
            on_exit=(ActionSpec("failing_action"),),  # Fail in exit phase
            actions=(ActionSpec("sync_action"),),
            on_enter=(ActionSpec("async_action"),),
        )

        executor = ActionExecutor(registry, log_execution=False, stop_on_error=True)
        context = {}

        result = await executor.async_execute_phased(tr, context)

        assert result.all_succeeded is False
        # Should stop after exit phase failure
        assert "failing_action" in result.failed_actions
        # Subsequent phases should not execute
        assert "sync_called" not in context
        assert "async_called" not in context

    @pytest.mark.asyncio
    async def test_async_execute_specific_parallel(self, registry):
        """Test executing specific actions in parallel."""
        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        results = await executor.async_execute_specific_parallel(
            ["sync_action", "async_action", "slow_action"],
            context,
        )

        assert len(results) == 3
        assert all(r.success for r in results)
        assert context["sync_called"] is True
        assert context["async_called"] is True
        assert context["slow_called"] is True

    @pytest.mark.asyncio
    async def test_async_execute_empty_actions(self, registry):
        """Test execution with no actions."""
        tr = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="test",
            actions=(),
        )

        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        # Sequential
        result = await executor.async_execute(tr, context)
        assert result.all_succeeded is True
        assert result.action_count == 0

        # Parallel
        result = await executor.async_execute_parallel(tr, context)
        assert result.all_succeeded is True
        assert result.action_count == 0

    @pytest.mark.asyncio
    async def test_async_execute_failed_transition(self, registry):
        """Test execution with failed transition result."""
        from pystator import InvalidTransitionError

        tr = TransitionResult.failure_result(
            source_state="A",
            trigger="test",
            error=InvalidTransitionError("test", "A", "test"),
        )

        executor = ActionExecutor(registry, log_execution=False)
        context = {}

        result = await executor.async_execute(tr, context)

        assert result.action_count == 0
        assert result.transition_result.success is False

    @pytest.mark.asyncio
    async def test_default_mode(self, registry, transition_result):
        """Test default execution mode configuration."""
        # Default mode is SEQUENTIAL
        executor1 = ActionExecutor(registry, log_execution=False)
        assert executor1.default_mode == ExecutionMode.SEQUENTIAL

        # Custom default mode
        executor2 = ActionExecutor(
            registry, log_execution=False, default_mode=ExecutionMode.PHASED
        )
        assert executor2.default_mode == ExecutionMode.PHASED


class TestExecutionMode:
    """Tests for ExecutionMode enum."""

    def test_execution_mode_values(self):
        """Test execution mode values."""
        assert ExecutionMode.SEQUENTIAL.value == "sequential"
        assert ExecutionMode.PARALLEL.value == "parallel"
        assert ExecutionMode.PHASED.value == "phased"

    def test_execution_mode_from_string(self):
        """Test creating mode from string."""
        assert ExecutionMode("sequential") == ExecutionMode.SEQUENTIAL
        assert ExecutionMode("parallel") == ExecutionMode.PARALLEL
        assert ExecutionMode("phased") == ExecutionMode.PHASED
