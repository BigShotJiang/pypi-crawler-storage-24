"""Unit tests for fork/join synchronization in parallel regions."""

from __future__ import annotations

import pytest

from pystator._parallel import ParallelStateConfig, ParallelStateManager
from pystator._types import Region, State, StateType

# ---------------------------------------------------------------------------
# Region.final field
# ---------------------------------------------------------------------------


class TestRegionFinal:
    """Tests for the Region.final field."""

    def test_region_with_final(self) -> None:
        """Region accepts a valid final state."""
        r = Region(name="r1", initial="a", states=("a", "b", "done"), final="done")
        assert r.final == "done"

    def test_region_final_not_in_states_raises(self) -> None:
        """final must be in states list."""
        with pytest.raises(ValueError, match="final state 'missing'"):
            Region(name="r1", initial="a", states=("a", "b"), final="missing")

    def test_region_without_final_backward_compat(self) -> None:
        """Regions without final still work (None by default)."""
        r = Region(name="r1", initial="a", states=("a", "b"))
        assert r.final is None

    def test_region_final_no_states_list(self) -> None:
        """final with empty states list (no validation)."""
        r = Region(name="r1", initial="a", final="done")
        assert r.final == "done"


# ---------------------------------------------------------------------------
# ParallelStateManager join condition
# ---------------------------------------------------------------------------


class TestParallelJoinCondition:
    """Tests for the join condition check."""

    def _make_parallel(self, regions: tuple[Region, ...]) -> dict[str, State]:
        """Helper: create states dict with a parallel state."""
        return {
            "parallel_state": State(
                name="parallel_state",
                type=StateType.PARALLEL,
                regions=regions,
            )
        }

    def test_all_regions_final(self) -> None:
        """Join fires when all regions with final are in final state."""
        states = self._make_parallel(
            (
                Region(name="r1", initial="a", states=("a", "done"), final="done"),
                Region(
                    name="r2", initial="x", states=("x", "complete"), final="complete"
                ),
            )
        )
        mgr = ParallelStateManager(states)
        config = ParallelStateConfig(
            parallel_state="parallel_state",
            region_states={"r1": "done", "r2": "complete"},
        )
        assert mgr.check_join_condition(config) is True

    def test_partial_final(self) -> None:
        """Join doesn't fire when only some regions are final."""
        states = self._make_parallel(
            (
                Region(name="r1", initial="a", states=("a", "done"), final="done"),
                Region(
                    name="r2", initial="x", states=("x", "complete"), final="complete"
                ),
            )
        )
        mgr = ParallelStateManager(states)
        config = ParallelStateConfig(
            parallel_state="parallel_state",
            region_states={"r1": "done", "r2": "x"},
        )
        assert mgr.check_join_condition(config) is False

    def test_no_finals_defined(self) -> None:
        """Join never fires when no regions have final."""
        states = self._make_parallel(
            (
                Region(name="r1", initial="a", states=("a", "b")),
                Region(name="r2", initial="x", states=("x", "y")),
            )
        )
        mgr = ParallelStateManager(states)
        config = ParallelStateConfig(
            parallel_state="parallel_state",
            region_states={"r1": "b", "r2": "y"},
        )
        assert mgr.check_join_condition(config) is False

    def test_mixed_final_and_no_final(self) -> None:
        """When one region has final and one doesn't, only the final one matters."""
        states = self._make_parallel(
            (
                Region(name="r1", initial="a", states=("a", "done"), final="done"),
                Region(name="r2", initial="x", states=("x", "y")),
            )
        )
        mgr = ParallelStateManager(states)
        config = ParallelStateConfig(
            parallel_state="parallel_state",
            region_states={"r1": "done", "r2": "x"},
        )
        assert mgr.check_join_condition(config) is True

    def test_unknown_parallel_state(self) -> None:
        """Returns False for unknown parallel state."""
        mgr = ParallelStateManager({})
        config = ParallelStateConfig(
            parallel_state="nonexistent",
            region_states={"r1": "done"},
        )
        assert mgr.check_join_condition(config) is False

    def test_get_join_trigger(self) -> None:
        """Join trigger follows naming convention."""
        assert ParallelStateManager.get_join_trigger("data_prep") == "_join_data_prep"


# ---------------------------------------------------------------------------
# Engine join trigger firing
# ---------------------------------------------------------------------------


class TestEngineJoinFiring:
    """Tests for join trigger metadata in engine."""

    def test_join_fires_when_all_final(self) -> None:
        """When all regions reach final, _join_trigger appears in metadata."""
        from pystator._engine import Engine
        from pystator._types import Transition
        from pystator.errors import ErrorPolicy

        states = {
            "init": State(name="init", type=StateType.INITIAL),
            "data_prep": State(
                name="data_prep",
                type=StateType.PARALLEL,
                regions=(
                    Region(
                        name="market",
                        initial="fetching",
                        states=("fetching", "ready"),
                        final="ready",
                    ),
                    Region(
                        name="risk",
                        initial="loading",
                        states=("loading", "ready"),
                        final="ready",
                    ),
                ),
            ),
            "fetching": State(
                name="fetching", type=StateType.STABLE, parent="data_prep"
            ),
            "ready": State(name="ready", type=StateType.STABLE, parent="data_prep"),
            "loading": State(name="loading", type=StateType.STABLE, parent="data_prep"),
            "all_data_ready": State(name="all_data_ready", type=StateType.STABLE),
        }
        transitions = [
            Transition(
                trigger="FETCH_DONE",
                source=frozenset({"fetching"}),
                dest="ready",
                region="market",
            ),
            Transition(
                trigger="LOAD_DONE",
                source=frozenset({"loading"}),
                dest="ready",
                region="risk",
            ),
            Transition(
                trigger="_join_data_prep",
                source=frozenset({"data_prep"}),
                dest="all_data_ready",
            ),
        ]

        engine = Engine(states, transitions, {"strict_mode": False}, ErrorPolicy())

        # Enter parallel state
        config = engine.parallel.enter_parallel_state("data_prep")
        assert config.region_states["market"] == "fetching"
        assert config.region_states["risk"] == "loading"

        # Process first region transition (market → ready)
        config, results = engine.process_parallel(config, "FETCH_DONE")
        assert config.region_states["market"] == "ready"
        assert "_join_trigger" not in results[-1].metadata

        # Process second region transition (risk → ready) → join fires
        config, results = engine.process_parallel(config, "LOAD_DONE")
        assert config.region_states["risk"] == "ready"
        assert results[-1].metadata.get("_join_trigger") == "_join_data_prep"

    def test_join_does_not_fire_partial(self) -> None:
        """Join doesn't fire when only one region is final."""
        from pystator._engine import Engine
        from pystator._types import Transition
        from pystator.errors import ErrorPolicy

        states = {
            "init": State(name="init", type=StateType.INITIAL),
            "p": State(
                name="p",
                type=StateType.PARALLEL,
                regions=(
                    Region(name="r1", initial="a", states=("a", "done"), final="done"),
                    Region(name="r2", initial="x", states=("x", "done"), final="done"),
                ),
            ),
            "a": State(name="a", type=StateType.STABLE, parent="p"),
            "x": State(name="x", type=StateType.STABLE, parent="p"),
            "done": State(name="done", type=StateType.STABLE, parent="p"),
        }
        transitions = [
            Transition(
                trigger="GO",
                source=frozenset({"a"}),
                dest="done",
                region="r1",
            ),
        ]

        engine = Engine(states, transitions, {"strict_mode": False}, ErrorPolicy())
        config = engine.parallel.enter_parallel_state("p")
        config, results = engine.process_parallel(config, "GO")

        assert config.region_states["r1"] == "done"
        assert config.region_states["r2"] == "x"
        # Only r1 final, r2 still at initial → no join
        assert "_join_trigger" not in results[-1].metadata


# ---------------------------------------------------------------------------
# Config parsing
# ---------------------------------------------------------------------------


class TestForkJoinConfig:
    """Test fork/join config parsing."""

    def test_raw_parser_passes_final(self) -> None:
        """Raw parser passes final field through."""
        from pystator.config._raw_parser import raw_config_to_core

        config = {
            "states": [
                {"name": "init", "type": "initial"},
                {
                    "name": "p",
                    "type": "parallel",
                    "regions": [
                        {
                            "name": "r1",
                            "initial": "a",
                            "states": ["a", "done"],
                            "final": "done",
                        },
                        {
                            "name": "r2",
                            "initial": "x",
                            "states": ["x", "done"],
                            "final": "done",
                        },
                    ],
                },
                {"name": "end", "type": "terminal"},
            ],
            "transitions": [
                {"trigger": "START", "source": "init", "dest": "p"},
                {"trigger": "_join_p", "source": "p", "dest": "end"},
            ],
        }

        states, transitions, meta = raw_config_to_core(config)
        p = states["p"]
        assert p.regions[0].final == "done"
        assert p.regions[1].final == "done"

    def test_backward_compat_no_final(self) -> None:
        """Existing configs without final still work."""
        from pystator.config._raw_parser import raw_config_to_core

        config = {
            "states": [
                {"name": "init", "type": "initial"},
                {
                    "name": "p",
                    "type": "parallel",
                    "regions": [
                        {"name": "r1", "initial": "a", "states": ["a", "b"]},
                    ],
                },
            ],
            "transitions": [],
        }

        states, transitions, meta = raw_config_to_core(config)
        assert states["p"].regions[0].final is None
