"""Tests for inline guard expressions."""

from pystator import GuardEvaluator, GuardRegistry, GuardSpec, Transition
from pystator.guards import _eval_expression


class TestEvalExpression:
    """Tests for inline expression evaluation."""

    def test_simple_comparison(self):
        """Simple comparison expressions."""
        context = {"qty": 100, "threshold": 50}
        assert _eval_expression("qty > threshold", context) is True
        assert _eval_expression("qty < threshold", context) is False
        assert _eval_expression("qty >= 100", context) is True
        assert _eval_expression("qty == 100", context) is True

    def test_arithmetic_expression(self):
        """Expressions with arithmetic."""
        context = {"price": 10.0, "qty": 5}
        assert _eval_expression("price * qty > 40", context) is True
        assert _eval_expression("price * qty == 50", context) is True
        assert _eval_expression("price + qty < 20", context) is True

    def test_boolean_operators(self):
        """Expressions with and/or/not."""
        context = {"a": True, "b": False, "x": 10}
        assert _eval_expression("a and not b", context) is True
        assert _eval_expression("a or b", context) is True
        assert _eval_expression("x > 5 and x < 20", context) is True
        assert _eval_expression("not (x < 5)", context) is True

    def test_string_operations(self):
        """Expressions with strings."""
        context = {"status": "active", "name": ""}
        assert _eval_expression("status == 'active'", context) is True
        assert _eval_expression("status != ''", context) is True
        assert _eval_expression("name == ''", context) is True

    def test_list_operations(self):
        """Expressions with lists."""
        context = {"items": [1, 2, 3], "target": 2, "item_count": 3}
        assert _eval_expression("target in items", context) is True
        assert _eval_expression("5 not in items", context) is True
        assert _eval_expression("item_count == 3", context) is True

    def test_safe_builtins(self):
        """Inline expressions can use safe builtins: len, min, max, abs, sum."""
        context = {"positions": [1, 2, 3], "max_positions": 5}
        assert _eval_expression("len(positions) < max_positions", context) is True
        assert _eval_expression("len(positions) == 3", context) is True
        context = {"vals": [10, 2, 8], "threshold": 2}
        assert _eval_expression("min(vals) >= threshold", context) is True
        assert _eval_expression("max(vals) == 10", context) is True
        context = {"x": -5}
        assert _eval_expression("abs(x) == 5", context) is True
        context = {"nums": [1, 2, 3]}
        assert _eval_expression("sum(nums) == 6", context) is True

    def test_coercion_to_bool(self):
        """Non-boolean results are coerced to bool."""
        context = {"x": 1, "y": 0, "s": "hello", "empty": ""}
        assert _eval_expression("x", context) is True
        assert _eval_expression("y", context) is False
        assert _eval_expression("s", context) is True
        assert _eval_expression("empty", context) is False


class TestGuardEvaluatorWithExpressions:
    """Tests for GuardEvaluator with inline expressions."""

    def test_evaluate_expression_guard(self):
        """Evaluate a single expression guard."""
        evaluator = GuardEvaluator(registry=None, strict=False)

        trans = Transition(
            trigger="fill",
            source=frozenset({"open"}),
            dest="filled",
            guards=(GuardSpec(expr="fill_qty >= order_qty"),),
        )

        # Should pass
        context = {"fill_qty": 100, "order_qty": 100}
        result = evaluator.can_transition(trans, context)
        assert result.passed is True

        # Should fail
        context = {"fill_qty": 50, "order_qty": 100}
        result = evaluator.can_transition(trans, context)
        assert result.passed is False

    def test_evaluate_mixed_guards(self):
        """Evaluate both named and expression guards."""
        registry = GuardRegistry()
        registry.register(
            "is_valid_symbol", lambda ctx: ctx.get("symbol") in ["AAPL", "GOOG"]
        )

        evaluator = GuardEvaluator(registry=registry, strict=True)

        trans = Transition(
            trigger="fill",
            source=frozenset({"open"}),
            dest="filled",
            guards=(
                GuardSpec(name="is_valid_symbol"),
                GuardSpec(expr="qty > 0"),
            ),
        )

        # Both pass
        context = {"symbol": "AAPL", "qty": 100}
        result = evaluator.can_transition(trans, context)
        assert result.passed is True

        # Named guard fails
        context = {"symbol": "INVALID", "qty": 100}
        result = evaluator.can_transition(trans, context)
        assert result.passed is False

        # Expression guard fails
        context = {"symbol": "AAPL", "qty": 0}
        result = evaluator.can_transition(trans, context)
        assert result.passed is False

    def test_expression_error_treated_as_failure(self):
        """Expression errors are treated as guard failure."""
        evaluator = GuardEvaluator(registry=None, strict=False)

        trans = Transition(
            trigger="fill",
            source=frozenset({"open"}),
            dest="filled",
            guards=(GuardSpec(expr="undefined_var > 0"),),
        )

        context = {}  # undefined_var not in context
        result = evaluator.can_transition(trans, context)
        assert result.passed is False
        assert (
            "exception" in result.message.lower()
            or "undefined" in result.message.lower()
        )

    def test_get_required_guards_excludes_expressions(self):
        """get_required_guards returns only named guards."""
        evaluator = GuardEvaluator(registry=GuardRegistry(), strict=True)

        transitions = [
            Transition(
                trigger="a",
                source=frozenset({"s1"}),
                dest="s2",
                guards=(
                    GuardSpec(name="named_guard_1"),
                    GuardSpec(expr="x > 0"),
                ),
            ),
            Transition(
                trigger="b",
                source=frozenset({"s2"}),
                dest="s3",
                guards=(GuardSpec(name="named_guard_2"),),
            ),
        ]

        required = evaluator.get_required_guards(transitions)
        assert required == {"named_guard_1", "named_guard_2"}


class TestConfigLoaderWithInlineGuards:
    """Tests for loading inline guards from config."""

    def test_load_string_guard(self):
        """String guards are parsed as named guards."""
        from pystator.config.loader import ConfigLoader

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}],
            "transitions": [
                {
                    "trigger": "go",
                    "source": "a",
                    "dest": "b",
                    "guards": "is_valid",
                }
            ],
        }

        _, transitions, _ = loader.parse(config)
        assert len(transitions) == 1
        assert len(transitions[0].guards) == 1
        assert transitions[0].guards[0].name == "is_valid"
        assert transitions[0].guards[0].is_expression is False

    def test_load_expression_guard(self):
        """Dict guards with expr are parsed as expression guards."""
        from pystator.config.loader import ConfigLoader

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}],
            "transitions": [
                {
                    "trigger": "go",
                    "source": "a",
                    "dest": "b",
                    "guards": [{"expr": "qty > 0"}],
                }
            ],
        }

        _, transitions, _ = loader.parse(config)
        assert len(transitions) == 1
        assert len(transitions[0].guards) == 1
        assert transitions[0].guards[0].expr == "qty > 0"
        assert transitions[0].guards[0].is_expression is True

    def test_load_mixed_guards(self):
        """Mixed string and expression guards."""
        from pystator.config.loader import ConfigLoader

        loader = ConfigLoader(validate=False)
        config = {
            "states": [{"name": "a"}, {"name": "b"}],
            "transitions": [
                {
                    "trigger": "go",
                    "source": "a",
                    "dest": "b",
                    "guards": [
                        "is_valid",
                        {"expr": "qty > 0"},
                        "has_permission",
                    ],
                }
            ],
        }

        _, transitions, _ = loader.parse(config)
        assert len(transitions[0].guards) == 3
        assert transitions[0].guards[0].name == "is_valid"
        assert transitions[0].guards[1].expr == "qty > 0"
        assert transitions[0].guards[2].name == "has_permission"
