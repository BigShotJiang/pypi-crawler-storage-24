"""Unit tests for PyStator."""
