"""Tests for declarative guard checks (pystator.checks)."""

from __future__ import annotations

import pytest

from pystator._types import CheckSpec, GuardSpec
from pystator.checks import evaluate_check


class TestCheckSpec:
    """Test CheckSpec construction and validation."""

    def test_basic_construction(self):
        check = CheckSpec(field="status", op="eq", value="active")
        assert check.field == "status"
        assert check.op == "eq"
        assert check.value == "active"

    def test_from_config(self):
        check = CheckSpec.from_config({"field": "qty", "op": "gt", "value": 10})
        assert check.field == "qty"
        assert check.op == "gt"
        assert check.value == 10

    def test_from_config_with_values(self):
        check = CheckSpec.from_config(
            {"field": "status", "op": "in", "values": ["OPEN", "PENDING"]}
        )
        assert check.values == ("OPEN", "PENDING")

    def test_empty_field_raises(self):
        with pytest.raises(ValueError, match="field cannot be empty"):
            CheckSpec(field="", op="eq")

    def test_unknown_op_raises(self):
        with pytest.raises(ValueError, match="Unknown check operator"):
            CheckSpec(field="x", op="invalid")

    def test_missing_field_in_config_raises(self):
        with pytest.raises(ValueError, match="requires 'field' and 'op'"):
            CheckSpec.from_config({"op": "eq", "value": 1})


class TestEvaluateCheck:
    """Test evaluate_check() with all operators."""

    # --- Equality ---

    def test_eq_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="eq", value=5), {"x": 5}) is True

    def test_eq_fail(self):
        assert evaluate_check(CheckSpec(field="x", op="eq", value=5), {"x": 3}) is False

    def test_eq_missing_field(self):
        assert evaluate_check(CheckSpec(field="x", op="eq", value=5), {}) is False

    def test_neq_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="neq", value=5), {"x": 3}) is True

    def test_neq_fail(self):
        assert (
            evaluate_check(CheckSpec(field="x", op="neq", value=5), {"x": 5}) is False
        )

    # --- Ordering ---

    def test_gt_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="gt", value=5), {"x": 10}) is True

    def test_gt_fail(self):
        assert evaluate_check(CheckSpec(field="x", op="gt", value=5), {"x": 5}) is False

    def test_gt_none(self):
        assert evaluate_check(CheckSpec(field="x", op="gt", value=5), {}) is False

    def test_gte_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="gte", value=5), {"x": 5}) is True

    def test_gte_fail(self):
        assert (
            evaluate_check(CheckSpec(field="x", op="gte", value=5), {"x": 4}) is False
        )

    def test_lt_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="lt", value=5), {"x": 3}) is True

    def test_lt_fail(self):
        assert evaluate_check(CheckSpec(field="x", op="lt", value=5), {"x": 5}) is False

    def test_lte_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="lte", value=5), {"x": 5}) is True

    def test_lte_fail(self):
        assert (
            evaluate_check(CheckSpec(field="x", op="lte", value=5), {"x": 6}) is False
        )

    # --- Membership ---

    def test_in_pass(self):
        check = CheckSpec(field="s", op="in", values=("A", "B", "C"))
        assert evaluate_check(check, {"s": "B"}) is True

    def test_in_fail(self):
        check = CheckSpec(field="s", op="in", values=("A", "B", "C"))
        assert evaluate_check(check, {"s": "D"}) is False

    def test_not_in_pass(self):
        check = CheckSpec(field="s", op="not_in", values=("A", "B"))
        assert evaluate_check(check, {"s": "C"}) is True

    def test_not_in_fail(self):
        check = CheckSpec(field="s", op="not_in", values=("A", "B"))
        assert evaluate_check(check, {"s": "A"}) is False

    # --- Nullability ---

    def test_is_set_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="is_set"), {"x": 42}) is True

    def test_is_set_fail(self):
        assert evaluate_check(CheckSpec(field="x", op="is_set"), {}) is False

    def test_is_set_none(self):
        assert evaluate_check(CheckSpec(field="x", op="is_set"), {"x": None}) is False

    def test_is_null_pass(self):
        assert evaluate_check(CheckSpec(field="x", op="is_null"), {}) is True

    def test_is_null_none(self):
        assert evaluate_check(CheckSpec(field="x", op="is_null"), {"x": None}) is True

    def test_is_null_fail(self):
        assert evaluate_check(CheckSpec(field="x", op="is_null"), {"x": 1}) is False


class TestGuardSpecCheck:
    """Test GuardSpec with check variant."""

    def test_from_config_check(self):
        guard = GuardSpec.from_config(
            {"check": {"field": "status", "op": "eq", "value": "OPEN"}}
        )
        assert guard.is_check
        assert not guard.is_expression
        assert guard.name is None
        assert guard.check is not None
        assert guard.check.field == "status"

    def test_check_exclusive_with_name(self):
        with pytest.raises(ValueError, match="can only have one"):
            GuardSpec(name="foo", check=CheckSpec(field="x", op="eq", value=1))

    def test_check_exclusive_with_expr(self):
        with pytest.raises(ValueError, match="can only have one"):
            GuardSpec(expr="x > 0", check=CheckSpec(field="x", op="gt", value=0))
