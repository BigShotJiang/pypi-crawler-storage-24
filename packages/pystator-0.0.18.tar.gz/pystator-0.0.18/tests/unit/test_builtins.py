"""Tests for built-in actions: snapshot, copy_key, validate_keys, publish, emit_metric."""

from __future__ import annotations

import logging
from typing import Any
from unittest.mock import MagicMock

from pystator.actions import ACTION_PARAMS_KEY, ActionRegistry
from pystator.builtins import (
    builtin_registries,
    copy_key,
    register_builtins,
    snapshot,
    validate_keys,
)
from pystator.sinks import (
    EventSink,
    LoggingEventSink,
    LoggingMetricSink,
    MetricSink,
    configure_event_sink,
    configure_metric_sink,
    create_metric_action,
    create_publish_action,
)

# =========================================================================
# snapshot
# =========================================================================


class TestSnapshotAction:
    def test_snapshot_basic(self):
        ctx: dict[str, Any] = {"order_id": "123", "qty": 10}
        ctx[ACTION_PARAMS_KEY] = {}
        snapshot(ctx)
        assert "_snapshots" in ctx
        assert len(ctx["_snapshots"]) == 1
        entry = ctx["_snapshots"][0]
        assert entry["data"]["order_id"] == "123"
        assert entry["data"]["qty"] == 10

    def test_snapshot_with_label(self):
        ctx: dict[str, Any] = {"x": 1}
        ctx[ACTION_PARAMS_KEY] = {"label": "pre_execution"}
        snapshot(ctx)
        assert ctx["_snapshots"][0]["label"] == "pre_execution"

    def test_snapshot_default_label(self):
        ctx: dict[str, Any] = {"x": 1}
        ctx[ACTION_PARAMS_KEY] = {}
        snapshot(ctx)
        label = ctx["_snapshots"][0]["label"]
        # Default label is an ISO timestamp string
        assert "T" in label

    def test_snapshot_excludes_internal_keys(self):
        ctx: dict[str, Any] = {
            "order_id": "123",
            "_action_params": {"label": "test"},
            "_trace": [{"action": "trace"}],
            "_snapshots": [],
        }
        ctx[ACTION_PARAMS_KEY] = {}
        snapshot(ctx)
        data = ctx["_snapshots"][0]["data"]
        assert "order_id" in data
        assert "_action_params" not in data
        assert "_trace" not in data
        assert "_snapshots" not in data

    def test_snapshot_deep_copies(self):
        nested = {"a": [1, 2, 3]}
        ctx: dict[str, Any] = {"nested": nested}
        ctx[ACTION_PARAMS_KEY] = {}
        snapshot(ctx)
        # Mutate original after snapshot
        nested["a"].append(4)
        # Snapshot data should be unaffected
        assert ctx["_snapshots"][0]["data"]["nested"]["a"] == [1, 2, 3]

    def test_snapshot_multiple(self):
        ctx: dict[str, Any] = {"x": 1}
        ctx[ACTION_PARAMS_KEY] = {"label": "first"}
        snapshot(ctx)
        ctx["x"] = 2
        ctx[ACTION_PARAMS_KEY] = {"label": "second"}
        snapshot(ctx)
        assert len(ctx["_snapshots"]) == 2
        assert ctx["_snapshots"][0]["data"]["x"] == 1
        assert ctx["_snapshots"][1]["data"]["x"] == 2

    def test_snapshot_empty_context(self):
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {}
        snapshot(ctx)
        assert ctx["_snapshots"][0]["data"] == {}


# =========================================================================
# copy_key
# =========================================================================


class TestCopyKeyAction:
    def test_copy_key_basic(self):
        ctx: dict[str, Any] = {"price": 100.5}
        ctx[ACTION_PARAMS_KEY] = {"from": "price", "to": "entry_price"}
        copy_key(ctx)
        assert ctx["entry_price"] == 100.5

    def test_copy_key_missing_source(self):
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {"from": "missing_key", "to": "dest"}
        copy_key(ctx)
        assert "dest" not in ctx

    def test_copy_key_overwrites_existing(self):
        ctx: dict[str, Any] = {"src": "new", "dst": "old"}
        ctx[ACTION_PARAMS_KEY] = {"from": "src", "to": "dst"}
        copy_key(ctx)
        assert ctx["dst"] == "new"

    def test_copy_key_missing_from_param(self, caplog):
        ctx: dict[str, Any] = {"x": 1}
        ctx[ACTION_PARAMS_KEY] = {"to": "y"}
        with caplog.at_level(logging.WARNING):
            copy_key(ctx)
        assert "missing 'from' or 'to'" in caplog.text
        assert "y" not in ctx

    def test_copy_key_missing_to_param(self, caplog):
        ctx: dict[str, Any] = {"x": 1}
        ctx[ACTION_PARAMS_KEY] = {"from": "x"}
        with caplog.at_level(logging.WARNING):
            copy_key(ctx)
        assert "missing 'from' or 'to'" in caplog.text

    def test_copy_key_no_params(self, caplog):
        ctx: dict[str, Any] = {"x": 1}
        ctx[ACTION_PARAMS_KEY] = {}
        with caplog.at_level(logging.WARNING):
            copy_key(ctx)
        assert "missing 'from' or 'to'" in caplog.text

    def test_copy_key_none_value(self):
        """None source value IS copied (it's present in ctx, just None)."""
        ctx: dict[str, Any] = {"src": None}
        ctx[ACTION_PARAMS_KEY] = {"from": "src", "to": "dst"}
        copy_key(ctx)
        assert ctx["dst"] is None


# =========================================================================
# validate_keys
# =========================================================================


class TestValidateKeysAction:
    def test_validate_keys_all_present(self):
        ctx: dict[str, Any] = {"order_id": "123", "qty": 10}
        ctx[ACTION_PARAMS_KEY] = {"required": ["order_id", "qty"]}
        validate_keys(ctx)
        assert "_validation_errors" not in ctx

    def test_validate_keys_some_missing(self, caplog):
        ctx: dict[str, Any] = {"order_id": "123"}
        ctx[ACTION_PARAMS_KEY] = {"required": ["order_id", "qty", "price"]}
        with caplog.at_level(logging.WARNING):
            validate_keys(ctx)
        assert "qty" in ctx["_validation_errors"]
        assert "price" in ctx["_validation_errors"]
        assert "order_id" not in ctx["_validation_errors"]
        assert "qty" in caplog.text

    def test_validate_keys_none_value(self, caplog):
        ctx: dict[str, Any] = {"key": None}
        ctx[ACTION_PARAMS_KEY] = {"required": ["key"]}
        with caplog.at_level(logging.WARNING):
            validate_keys(ctx)
        assert "key" in ctx["_validation_errors"]

    def test_validate_keys_empty_required(self):
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {"required": []}
        validate_keys(ctx)
        assert "_validation_errors" not in ctx

    def test_validate_keys_non_list_required(self, caplog):
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {"required": "not_a_list"}
        with caplog.at_level(logging.WARNING):
            validate_keys(ctx)
        assert "'required' param must be a list" in caplog.text

    def test_validate_keys_no_params(self):
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {}
        validate_keys(ctx)
        assert "_validation_errors" not in ctx


# =========================================================================
# EventSink protocol
# =========================================================================


class TestEventSinkProtocol:
    def test_logging_event_sink_satisfies_protocol(self):
        assert isinstance(LoggingEventSink(), EventSink)

    def test_custom_sink_satisfies_protocol(self):
        class MySink:
            def send(
                self, topic: str, payload: dict[str, Any], metadata: dict[str, Any]
            ) -> None:
                pass

        assert isinstance(MySink(), EventSink)


# =========================================================================
# MetricSink protocol
# =========================================================================


class TestMetricSinkProtocol:
    def test_logging_metric_sink_satisfies_protocol(self):
        assert isinstance(LoggingMetricSink(), MetricSink)

    def test_custom_sink_satisfies_protocol(self):
        class MySink:
            def emit(self, name: str, value: float, tags: dict[str, str]) -> None:
                pass

        assert isinstance(MySink(), MetricSink)


# =========================================================================
# publish action
# =========================================================================


class TestPublishAction:
    def _make_sink(self) -> MagicMock:
        sink = MagicMock(spec=["send"])
        return sink

    def test_publish_basic(self):
        sink = self._make_sink()
        action = create_publish_action(sink)
        ctx: dict[str, Any] = {"order_id": "123", "qty": 10}
        ctx[ACTION_PARAMS_KEY] = {"topic": "order.filled"}
        action(ctx)
        sink.send.assert_called_once()
        topic, payload, metadata = sink.send.call_args[0]
        assert topic == "order.filled"
        assert "order_id" in payload

    def test_publish_with_include(self):
        sink = self._make_sink()
        action = create_publish_action(sink)
        ctx: dict[str, Any] = {"order_id": "123", "qty": 10, "secret": "xxx"}
        ctx[ACTION_PARAMS_KEY] = {
            "topic": "order.filled",
            "include": ["order_id", "qty"],
        }
        action(ctx)
        _, payload, _ = sink.send.call_args[0]
        assert payload == {"order_id": "123", "qty": 10}
        assert "secret" not in payload

    def test_publish_without_include(self):
        sink = self._make_sink()
        action = create_publish_action(sink)
        ctx: dict[str, Any] = {"order_id": "123", "_internal": "skip"}
        ctx[ACTION_PARAMS_KEY] = {"topic": "test"}
        action(ctx)
        _, payload, _ = sink.send.call_args[0]
        assert "order_id" in payload
        assert "_internal" not in payload

    def test_publish_missing_topic(self, caplog):
        sink = self._make_sink()
        action = create_publish_action(sink)
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {}
        with caplog.at_level(logging.WARNING):
            action(ctx)
        sink.send.assert_not_called()
        assert "missing 'topic'" in caplog.text

    def test_publish_includes_metadata(self):
        sink = self._make_sink()
        action = create_publish_action(sink)
        ctx: dict[str, Any] = {
            "current_state": "OPEN",
            "trigger": "fill",
        }
        ctx[ACTION_PARAMS_KEY] = {"topic": "test"}
        action(ctx)
        _, _, metadata = sink.send.call_args[0]
        assert metadata["state"] == "OPEN"
        assert metadata["trigger"] == "fill"
        assert "timestamp" in metadata

    def test_publish_with_action_executor(self):
        sink = self._make_sink()
        registry = ActionRegistry()
        registry.register("publish", create_publish_action(sink))
        ctx: dict[str, Any] = {"order_id": "123"}
        # Simulate how ActionExecutor injects params
        ctx[ACTION_PARAMS_KEY] = {"topic": "order.created", "include": ["order_id"]}
        registry.execute("publish", ctx)
        sink.send.assert_called_once()


# =========================================================================
# emit_metric action
# =========================================================================


class TestEmitMetricAction:
    def _make_sink(self) -> MagicMock:
        sink = MagicMock(spec=["emit"])
        return sink

    def test_emit_metric_counter(self):
        sink = self._make_sink()
        action = create_metric_action(sink)
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {"name": "orders.submitted", "type": "counter"}
        action(ctx)
        sink.emit.assert_called_once()
        name, value, tags = sink.emit.call_args[0]
        assert name == "orders.submitted"
        assert value == 1.0
        assert tags["metric_type"] == "counter"

    def test_emit_metric_gauge(self):
        sink = self._make_sink()
        action = create_metric_action(sink)
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {
            "name": "queue.depth",
            "value": 42,
            "type": "gauge",
        }
        action(ctx)
        _, value, tags = sink.emit.call_args[0]
        assert value == 42.0
        assert tags["metric_type"] == "gauge"

    def test_emit_metric_with_tags(self):
        sink = self._make_sink()
        action = create_metric_action(sink)
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {
            "name": "trade.executed",
            "tags": {"venue": "NYSE"},
        }
        action(ctx)
        _, _, tags = sink.emit.call_args[0]
        assert tags["venue"] == "NYSE"

    def test_emit_metric_missing_name(self, caplog):
        sink = self._make_sink()
        action = create_metric_action(sink)
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {}
        with caplog.at_level(logging.WARNING):
            action(ctx)
        sink.emit.assert_not_called()
        assert "missing 'name'" in caplog.text

    def test_emit_metric_state_tag(self):
        sink = self._make_sink()
        action = create_metric_action(sink)
        ctx: dict[str, Any] = {"current_state": "PROCESSING"}
        ctx[ACTION_PARAMS_KEY] = {"name": "test"}
        action(ctx)
        _, _, tags = sink.emit.call_args[0]
        assert tags["state"] == "PROCESSING"

    def test_emit_metric_with_action_executor(self):
        sink = self._make_sink()
        registry = ActionRegistry()
        registry.register("emit_metric", create_metric_action(sink))
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {"name": "test_metric"}
        registry.execute("emit_metric", ctx)
        sink.emit.assert_called_once()


# =========================================================================
# configure helpers
# =========================================================================


class TestConfigureHelpers:
    def test_configure_event_sink_default(self):
        registry = ActionRegistry()
        configure_event_sink(registry)
        assert registry.has("publish")

    def test_configure_event_sink_custom(self):
        registry = ActionRegistry()
        sink = MagicMock(spec=["send"])
        configure_event_sink(registry, sink)
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {"topic": "test"}
        registry.execute("publish", ctx)
        sink.send.assert_called_once()

    def test_configure_event_sink_replaces(self):
        registry = ActionRegistry()
        sink1 = MagicMock(spec=["send"])
        sink2 = MagicMock(spec=["send"])
        configure_event_sink(registry, sink1)
        configure_event_sink(registry, sink2)
        ctx: dict[str, Any] = {}
        ctx[ACTION_PARAMS_KEY] = {"topic": "test"}
        registry.execute("publish", ctx)
        sink1.send.assert_not_called()
        sink2.send.assert_called_once()

    def test_configure_metric_sink_default(self):
        registry = ActionRegistry()
        configure_metric_sink(registry)
        assert registry.has("emit_metric")


# =========================================================================
# register_builtins integration
# =========================================================================


class TestRegisterBuiltinsIntegration:
    def test_builtin_registries_has_all_actions(self):
        _, actions = builtin_registries()
        expected = [
            "noop",
            "log",
            "trace",
            "set_context",
            "snapshot",
            "copy_key",
            "validate_keys",
            "publish",
            "emit_metric",
        ]
        for name in expected:
            assert actions.has(name), f"Missing action: {name}"

    def test_register_builtins_has_publish(self):
        _, actions = register_builtins()
        assert actions.has("publish")

    def test_register_builtins_has_emit_metric(self):
        _, actions = register_builtins()
        assert actions.has("emit_metric")
