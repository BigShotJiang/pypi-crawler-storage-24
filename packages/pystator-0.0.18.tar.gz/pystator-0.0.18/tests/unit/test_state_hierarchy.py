"""Unit tests for StateHierarchy."""

from __future__ import annotations

import pytest

from pystator import State, StateType
from pystator._hierarchy import StateHierarchy
from pystator.errors import ConfigurationError


@pytest.fixture
def flat_states() -> dict[str, State]:
    """Flat FSM: no parents."""
    return {
        "a": State(name="a", type=StateType.INITIAL),
        "b": State(name="b", type=StateType.STABLE),
        "c": State(name="c", type=StateType.TERMINAL),
    }


@pytest.fixture
def hierarchical_states() -> dict[str, State]:
    """Hierarchical: active (compound) -> active_scanning, active_analyzing; halted root."""
    return {
        "active": State(
            name="active",
            type=StateType.STABLE,
            initial_child="active_scanning",
            on_enter=("start_feed",),
            on_exit=("stop_feed",),
        ),
        "active_scanning": State(
            name="active_scanning",
            type=StateType.STABLE,
            parent="active",
        ),
        "active_analyzing": State(
            name="active_analyzing",
            type=StateType.STABLE,
            parent="active",
        ),
        "halted": State(name="halted", type=StateType.TERMINAL),
    }


@pytest.fixture
def hierarchical_with_initial() -> dict[str, State]:
    """One root initial (pre_market), active compound with children."""
    return {
        "pre_market": State(name="pre_market", type=StateType.INITIAL),
        "active": State(
            name="active",
            type=StateType.STABLE,
            initial_child="active_scanning",
            parent=None,
        ),
        "active_scanning": State(
            name="active_scanning", type=StateType.STABLE, parent="active"
        ),
        "active_analyzing": State(
            name="active_analyzing", type=StateType.STABLE, parent="active"
        ),
        "halted": State(name="halted", type=StateType.TERMINAL),
    }


class TestStateHierarchyFlat:
    """Tests for flat (no parent) hierarchy."""

    def test_flat_build(self, flat_states: dict[str, State]) -> None:
        """Flat states build one root (a is initial)."""
        h = StateHierarchy(flat_states)
        assert h.roots == ["a", "b", "c"]
        assert h.ancestors("a") == ["a"]
        assert h.ancestors("b") == ["b"]
        assert h.resolve_initial_leaf("a") == "a"
        assert h.effective_target_leaf("c") == "c"
        assert h.is_compound("a") is False
        assert h.children("a") == []

    def test_flat_lca(self, flat_states: dict[str, State]) -> None:
        """LCA of two roots is None (different trees in flat = each is own root)."""
        h = StateHierarchy(flat_states)
        assert h.lca("a", "b") is None
        assert h.lca("a", "a") == "a"

    def test_flat_exit_chain(self, flat_states: dict[str, State]) -> None:
        """Exit chain from leaf with no LCA is just that state."""
        h = StateHierarchy(flat_states)
        assert h.exit_chain("b", None) == ["b"]
        assert h.exit_chain("b", "x") == ["b"]  # x not in path, so full path

    def test_flat_enter_chain(self, flat_states: dict[str, State]) -> None:
        """Enter chain with no LCA is path from root to leaf; flat = single state."""
        h = StateHierarchy(flat_states)
        assert h.enter_chain(None, "b") == ["b"]
        assert h.enter_chain("b", "b") == []


class TestStateHierarchyNested:
    """Tests for hierarchical states."""

    def test_hierarchical_no_root_initial_raises(
        self, hierarchical_states: dict[str, State]
    ) -> None:
        """No root has type initial -> ConfigurationError."""
        with pytest.raises(ConfigurationError, match="No initial state"):
            StateHierarchy(hierarchical_states)

    def test_ancestors(self, hierarchical_with_initial: dict[str, State]) -> None:
        """Ancestors from leaf to root."""
        h = StateHierarchy(hierarchical_with_initial)
        assert h.ancestors("active_scanning") == ["active_scanning", "active"]
        assert h.ancestors("active") == ["active"]
        assert h.ancestors("pre_market") == ["pre_market"]
        assert h.ancestors("halted") == ["halted"]

    def test_resolve_initial_leaf(
        self, hierarchical_with_initial: dict[str, State]
    ) -> None:
        """Compound state resolves to initial child leaf."""
        h = StateHierarchy(hierarchical_with_initial)
        assert h.resolve_initial_leaf("active") == "active_scanning"
        assert h.resolve_initial_leaf("active_scanning") == "active_scanning"
        assert h.resolve_initial_leaf("pre_market") == "pre_market"
        assert h.resolve_initial_leaf("halted") == "halted"

    def test_effective_target_leaf(
        self, hierarchical_with_initial: dict[str, State]
    ) -> None:
        """Same as resolve_initial_leaf."""
        h = StateHierarchy(hierarchical_with_initial)
        assert h.effective_target_leaf("active") == "active_scanning"

    def test_lca_same_branch(self, hierarchical_with_initial: dict[str, State]) -> None:
        """LCA of active_scanning and active_analyzing is active."""
        h = StateHierarchy(hierarchical_with_initial)
        assert h.lca("active_scanning", "active_analyzing") == "active"
        assert h.lca("active_analyzing", "active_scanning") == "active"

    def test_lca_different_trees(
        self, hierarchical_with_initial: dict[str, State]
    ) -> None:
        """LCA of active_scanning and halted is None."""
        h = StateHierarchy(hierarchical_with_initial)
        assert h.lca("active_scanning", "halted") is None
        assert h.lca("pre_market", "halted") is None

    def test_lca_self(self, hierarchical_with_initial: dict[str, State]) -> None:
        """LCA of leaf with self is leaf."""
        h = StateHierarchy(hierarchical_with_initial)
        assert h.lca("active_scanning", "active_scanning") == "active_scanning"

    def test_exit_chain_to_lca(
        self, hierarchical_with_initial: dict[str, State]
    ) -> None:
        """Exit from leaf up to (but not including) LCA."""
        h = StateHierarchy(hierarchical_with_initial)
        # From active_scanning to LCA active -> exit only active_scanning
        assert h.exit_chain("active_scanning", "active") == ["active_scanning"]
        # From active_scanning to LCA None -> exit full path
        assert h.exit_chain("active_scanning", None) == ["active_scanning", "active"]

    def test_enter_chain_from_lca(
        self, hierarchical_with_initial: dict[str, State]
    ) -> None:
        """Enter from first child of LCA down to leaf."""
        h = StateHierarchy(hierarchical_with_initial)
        # From LCA active to active_scanning -> enter active_scanning
        assert h.enter_chain("active", "active_scanning") == ["active_scanning"]
        # From LCA None to active_scanning -> path from root to leaf
        assert h.enter_chain(None, "active_scanning") == ["active", "active_scanning"]
        # From LCA active to active_analyzing
        assert h.enter_chain("active", "active_analyzing") == ["active_analyzing"]

    def test_is_compound(self, hierarchical_with_initial: dict[str, State]) -> None:
        """Compound state has initial_child."""
        h = StateHierarchy(hierarchical_with_initial)
        assert h.is_compound("active") is True
        assert h.is_compound("active_scanning") is False
        assert h.is_compound("pre_market") is False

    def test_children(self, hierarchical_with_initial: dict[str, State]) -> None:
        """Direct children of a state."""
        h = StateHierarchy(hierarchical_with_initial)
        assert set(h.children("active")) == {"active_scanning", "active_analyzing"}
        assert h.children("active_scanning") == []
        assert h.children("pre_market") == []


class TestStateHierarchyValidation:
    """Validation: cycles, unknown parent, unknown initial_child, multiple initial."""

    def test_unknown_parent_raises(self) -> None:
        """State references non-existent parent."""
        states = {
            "root": State(name="root", type=StateType.INITIAL),
            "child": State(name="child", type=StateType.STABLE, parent="missing"),
        }
        with pytest.raises(ConfigurationError, match="unknown parent"):
            StateHierarchy(states)

    def test_unknown_initial_child_raises(self) -> None:
        """Compound state references non-existent initial_child."""
        states = {
            "root": State(name="root", type=StateType.INITIAL),
            "compound": State(
                name="compound", type=StateType.STABLE, initial_child="missing"
            ),
        }
        with pytest.raises(ConfigurationError, match="unknown initial_child"):
            StateHierarchy(states)

    def test_cycle_raises(self) -> None:
        """Parent chain cycle raises."""
        states = {
            "a": State(name="a", type=StateType.INITIAL),
            "b": State(name="b", type=StateType.STABLE, parent="c"),
            "c": State(name="c", type=StateType.STABLE, parent="b"),
        }
        with pytest.raises(ConfigurationError, match="Cycle"):
            StateHierarchy(states)

    def test_multiple_root_initial_raises(self) -> None:
        """Two roots with type initial."""
        states = {
            "a": State(name="a", type=StateType.INITIAL),
            "b": State(name="b", type=StateType.INITIAL),
        }
        with pytest.raises(ConfigurationError, match="Multiple root initial"):
            StateHierarchy(states)

    def test_unknown_state_in_ancestors_returns_empty(self) -> None:
        """ancestors() for unknown state returns [] (no crash)."""
        h = StateHierarchy({"a": State(name="a", type=StateType.INITIAL)})
        assert h.ancestors("unknown") == []
        assert h.resolve_initial_leaf("unknown") == "unknown"
        assert h.lca("a", "unknown") is None
