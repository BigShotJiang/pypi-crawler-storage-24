"""Tests for declarative effects (pystator.effects)."""

from __future__ import annotations

import pytest

from pystator._types import EFFECT_TYPES, ActionSpec
from pystator.effects import apply_effect


class TestApplyEffect:
    """Test each effect type."""

    def test_set_single_key(self):
        ctx: dict = {"existing": 1}
        apply_effect("set", {"status": "active"}, ctx)
        assert ctx["status"] == "active"
        assert ctx["existing"] == 1

    def test_set_multiple_keys(self):
        ctx: dict = {}
        apply_effect("set", {"a": 1, "b": "two", "c": True}, ctx)
        assert ctx == {"a": 1, "b": "two", "c": True}

    def test_set_overwrites_existing(self):
        ctx: dict = {"status": "old"}
        apply_effect("set", {"status": "new"}, ctx)
        assert ctx["status"] == "new"

    def test_timestamp(self):
        ctx: dict = {}
        apply_effect("timestamp", {"field": "created_at"}, ctx)
        assert "created_at" in ctx
        # Should be ISO format string
        assert isinstance(ctx["created_at"], str)
        assert "T" in ctx["created_at"]

    def test_increment_from_zero(self):
        ctx: dict = {}
        apply_effect("increment", {"field": "count"}, ctx)
        assert ctx["count"] == 1

    def test_increment_existing(self):
        ctx: dict = {"count": 5}
        apply_effect("increment", {"field": "count"}, ctx)
        assert ctx["count"] == 6

    def test_decrement_from_zero(self):
        ctx: dict = {}
        apply_effect("decrement", {"field": "count"}, ctx)
        assert ctx["count"] == -1

    def test_decrement_existing(self):
        ctx: dict = {"count": 3}
        apply_effect("decrement", {"field": "count"}, ctx)
        assert ctx["count"] == 2

    def test_append_new_list(self):
        ctx: dict = {}
        apply_effect("append", {"field": "items", "value": "first"}, ctx)
        assert ctx["items"] == ["first"]

    def test_append_existing_list(self):
        ctx: dict = {"items": ["a", "b"]}
        apply_effect("append", {"field": "items", "value": "c"}, ctx)
        assert ctx["items"] == ["a", "b", "c"]

    def test_clear_existing(self):
        ctx: dict = {"temp": 42, "keep": "yes"}
        apply_effect("clear", {"field": "temp"}, ctx)
        assert "temp" not in ctx
        assert ctx["keep"] == "yes"

    def test_clear_nonexistent(self):
        ctx: dict = {"keep": "yes"}
        apply_effect("clear", {"field": "missing"}, ctx)
        assert ctx == {"keep": "yes"}

    def test_unknown_effect_raises(self):
        with pytest.raises(ValueError, match="Unknown effect type"):
            apply_effect("invalid", {}, {})


class TestActionSpecEffectParsing:
    """Test ActionSpec.from_config() with effect syntax."""

    def test_parse_set_effect(self):
        spec = ActionSpec.from_config({"set": {"status": "active", "count": 0}})
        assert spec.is_effect
        assert spec.effect == "set"
        assert spec.name == "_effect.set"
        assert spec.params == {"status": "active", "count": 0}

    def test_parse_timestamp_effect(self):
        spec = ActionSpec.from_config({"timestamp": "created_at"})
        assert spec.is_effect
        assert spec.effect == "timestamp"
        assert spec.name == "_effect.timestamp"
        assert spec.params == {"field": "created_at"}

    def test_parse_increment_effect(self):
        spec = ActionSpec.from_config({"increment": "retry_count"})
        assert spec.is_effect
        assert spec.effect == "increment"
        assert spec.params == {"field": "retry_count"}

    def test_parse_decrement_effect(self):
        spec = ActionSpec.from_config({"decrement": "remaining"})
        assert spec.is_effect
        assert spec.effect == "decrement"
        assert spec.params == {"field": "remaining"}

    def test_parse_append_effect(self):
        spec = ActionSpec.from_config({"append": {"field": "log", "value": "entry"}})
        assert spec.is_effect
        assert spec.effect == "append"
        assert spec.params == {"field": "log", "value": "entry"}

    def test_parse_clear_effect(self):
        spec = ActionSpec.from_config({"clear": "temp_data"})
        assert spec.is_effect
        assert spec.effect == "clear"
        assert spec.params == {"field": "temp_data"}

    def test_named_action_unchanged(self):
        spec = ActionSpec.from_config("submit_order")
        assert not spec.is_effect
        assert spec.name == "submit_order"

    def test_parameterized_action_unchanged(self):
        spec = ActionSpec.from_config({"name": "log", "params": {"level": "info"}})
        assert not spec.is_effect
        assert spec.name == "log"
        assert spec.params == {"level": "info"}

    def test_set_requires_dict(self):
        with pytest.raises(ValueError, match="'set' effect requires a mapping"):
            ActionSpec.from_config({"set": "not_a_dict"})

    def test_timestamp_requires_string(self):
        with pytest.raises(ValueError, match="requires a field name"):
            ActionSpec.from_config({"timestamp": 123})

    def test_append_requires_field_and_value(self):
        with pytest.raises(ValueError, match="requires.*field.*value"):
            ActionSpec.from_config({"append": {"field": "items"}})

    def test_effect_types_constant(self):
        assert "set" in EFFECT_TYPES
        assert "timestamp" in EFFECT_TYPES
        assert "increment" in EFFECT_TYPES
        assert "decrement" in EFFECT_TYPES
        assert "append" in EFFECT_TYPES
        assert "clear" in EFFECT_TYPES
        assert len(EFFECT_TYPES) == 6
