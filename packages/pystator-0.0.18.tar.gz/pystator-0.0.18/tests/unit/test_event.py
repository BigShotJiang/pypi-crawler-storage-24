"""Unit tests for Event."""

from __future__ import annotations

from datetime import UTC, datetime
from uuid import UUID

import pytest

from pystator import Event


class TestEvent:
    """Tests for Event dataclass."""

    def test_create_minimal_event(self) -> None:
        """Test creating an event with minimal arguments."""
        event = Event(trigger="activate")
        assert event.trigger == "activate"
        assert event.payload == {}
        assert isinstance(event.event_id, UUID)
        assert isinstance(event.timestamp, datetime)

    def test_create_full_event(self) -> None:
        """Test creating an event with all arguments."""
        event_id = UUID("12345678-1234-5678-1234-567812345678")
        timestamp = datetime(2024, 1, 1, 12, 0, 0, tzinfo=UTC)

        event = Event(
            trigger="execution_report",
            payload={"fill_qty": 100, "price": 50.0},
            event_id=event_id,
            timestamp=timestamp,
            source="exchange",
            metadata={"sequence": 42},
        )

        assert event.trigger == "execution_report"
        assert event.payload == {"fill_qty": 100, "price": 50.0}
        assert event.event_id == event_id
        assert event.timestamp == timestamp
        assert event.source == "exchange"
        assert event.metadata == {"sequence": 42}

    def test_event_immutable(self) -> None:
        """Test that Event is immutable."""
        event = Event(trigger="test")
        with pytest.raises(AttributeError):
            event.trigger = "new"  # type: ignore

    def test_empty_trigger_raises(self) -> None:
        """Test that empty trigger raises error."""
        with pytest.raises(ValueError, match="empty"):
            Event(trigger="")

    def test_event_get(self) -> None:
        """Test get method for payload access."""
        event = Event(trigger="test", payload={"a": 1, "b": 2})
        assert event.get("a") == 1
        assert event.get("c") is None
        assert event.get("c", "default") == "default"

    def test_event_getitem(self) -> None:
        """Test dictionary-style payload access."""
        event = Event(trigger="test", payload={"a": 1})
        assert event["a"] == 1
        with pytest.raises(KeyError):
            _ = event["nonexistent"]

    def test_event_contains(self) -> None:
        """Test 'in' operator for payload."""
        event = Event(trigger="test", payload={"a": 1})
        assert "a" in event
        assert "b" not in event

    def test_with_payload(self) -> None:
        """Test with_payload method."""
        event = Event(trigger="test", payload={"a": 1})
        new_event = event.with_payload(b=2, c=3)

        assert event.payload == {"a": 1}  # Original unchanged
        assert new_event.payload == {"a": 1, "b": 2, "c": 3}
        assert new_event.trigger == event.trigger
        assert new_event.event_id == event.event_id

    def test_with_metadata(self) -> None:
        """Test with_metadata method."""
        event = Event(trigger="test", metadata={"x": 1})
        new_event = event.with_metadata(y=2)

        assert event.metadata == {"x": 1}
        assert new_event.metadata == {"x": 1, "y": 2}

    def test_simple_factory(self) -> None:
        """Test simple factory method."""
        event = Event.simple("execute", qty=100, price=50.0)
        assert event.trigger == "execute"
        assert event.payload == {"qty": 100, "price": 50.0}

    def test_to_dict(self) -> None:
        """Test serialization to dictionary."""
        event = Event(
            trigger="test",
            payload={"a": 1},
            source="system",
        )
        data = event.to_dict()

        assert data["trigger"] == "test"
        assert data["payload"] == {"a": 1}
        assert data["source"] == "system"
        assert "event_id" in data
        assert "timestamp" in data

    def test_from_dict(self) -> None:
        """Test deserialization from dictionary."""
        data = {
            "trigger": "test",
            "payload": {"a": 1},
            "event_id": "12345678-1234-5678-1234-567812345678",
            "timestamp": "2024-01-01T12:00:00+00:00",
            "source": "api",
            "metadata": {"key": "value"},
        }
        event = Event.from_dict(data)

        assert event.trigger == "test"
        assert event.payload == {"a": 1}
        assert str(event.event_id) == "12345678-1234-5678-1234-567812345678"
        assert event.source == "api"
        assert event.metadata == {"key": "value"}

    def test_from_dict_minimal(self) -> None:
        """Test deserialization with minimal data."""
        data = {"trigger": "test"}
        event = Event.from_dict(data)

        assert event.trigger == "test"
        assert event.payload == {}
        assert isinstance(event.event_id, UUID)

    def test_round_trip_serialization(self) -> None:
        """Test that to_dict/from_dict round trips correctly."""
        original = Event(
            trigger="execute",
            payload={"qty": 100},
            source="exchange",
            metadata={"seq": 1},
        )
        data = original.to_dict()
        restored = Event.from_dict(data)

        assert restored.trigger == original.trigger
        assert restored.payload == original.payload
        assert restored.event_id == original.event_id
        assert restored.source == original.source
        assert restored.metadata == original.metadata
