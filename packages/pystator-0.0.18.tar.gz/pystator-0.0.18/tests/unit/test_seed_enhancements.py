"""Tests for seed data: enhancements_examples.yaml.

Ensures the example machines load, validate, and have at least one trigger
from the initial state (so UI Create Entity works). Also runs a quick
process() for each machine with declarative/expression guards.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from pystator import StateMachine
from pystator.config._raw_parser import raw_config_to_core


def _load_enhancements_yaml():
    """Load enhancements_examples.yaml as list of config dicts."""
    import yaml

    path = Path(__file__).resolve().parent.parent.parent
    path = path / "src" / "pystator" / "data" / "seed" / "enhancements_examples.yaml"
    with open(path) as f:
        data = yaml.safe_load(f)
    assert isinstance(data, list), "Expected list of machine docs"
    return data


@pytest.fixture(scope="module")
def enhancement_configs():
    return _load_enhancements_yaml()


def test_enhancements_yaml_has_three_machines(enhancement_configs):
    """All three example machines are present."""
    names = {c.get("meta", {}).get("machine_name") for c in enhancement_configs}
    assert names == {
        "config_enhancements_example",
        "expression_guards_example",
        "declarative_checks_example",
    }


def test_each_machine_parses_and_has_trigger_from_initial(enhancement_configs):
    """Each machine has exactly one initial state and at least one transition with trigger from it."""
    for doc in enhancement_configs:
        name = doc.get("meta", {}).get("machine_name", "?")
        states, transitions, meta = raw_config_to_core(doc)
        initial_states = [s for s in states.values() if s.type.value == "initial"]
        assert len(initial_states) == 1, f"{name}: expected one initial state"
        init_name = initial_states[0].name
        from_initial = [t for t in transitions if init_name in t.source and t.trigger]
        assert from_initial, f"{name}: no trigger from initial state {init_name}"


def test_config_enhancements_example_process(enhancement_configs):
    """config_enhancements_example: start from idle -> validating."""
    doc = next(
        c
        for c in enhancement_configs
        if c["meta"]["machine_name"] == "config_enhancements_example"
    )
    machine = StateMachine.from_dict(doc)
    result = machine.process("idle", "start", {})
    assert result.success
    assert result.target_state == "validating"


def test_expression_guards_example_process(enhancement_configs):
    """expression_guards_example: filled with fill_qty >= order_qty -> filled."""
    doc = next(
        c
        for c in enhancement_configs
        if c["meta"]["machine_name"] == "expression_guards_example"
    )
    machine = StateMachine.from_dict(doc)
    ctx = {"order_qty": 100, "fill_qty": 100}
    result = machine.process("open", "filled", ctx)
    assert result.success
    assert result.target_state == "filled"


def test_declarative_checks_example_process(enhancement_configs):
    """declarative_checks_example: submit with role=admin -> approved (check guard)."""
    doc = next(
        c
        for c in enhancement_configs
        if c["meta"]["machine_name"] == "declarative_checks_example"
    )
    machine = StateMachine.from_dict(doc)
    ctx = {"role": "admin"}
    result = machine.process("pending", "submit", ctx)
    assert result.success
    assert result.target_state == "approved"
