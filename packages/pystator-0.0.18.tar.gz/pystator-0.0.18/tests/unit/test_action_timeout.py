"""Unit tests for action timeout support."""

from __future__ import annotations

import asyncio

import pytest

from pystator import (
    ActionExecutor,
    ActionRegistry,
    ActionSpec,
    TransitionResult,
)


class TestActionSpecTimeout:
    """Tests for ActionSpec timeout field."""

    def test_action_spec_default_timeout_is_none(self) -> None:
        """ActionSpec timeout defaults to None."""
        spec = ActionSpec(name="my_action")
        assert spec.timeout is None

    def test_action_spec_with_timeout(self) -> None:
        """ActionSpec can be created with a timeout value."""
        spec = ActionSpec(name="my_action", timeout=5.0)
        assert spec.timeout == 5.0

    def test_action_spec_from_config_with_timeout(self) -> None:
        """ActionSpec.from_config parses timeout from dict config."""
        spec = ActionSpec.from_config(
            {
                "name": "my_action",
                "timeout": 3.5,
            }
        )
        assert spec.name == "my_action"
        assert spec.timeout == 3.5

    def test_action_spec_from_config_without_timeout(self) -> None:
        """ActionSpec.from_config defaults timeout to None when omitted."""
        spec = ActionSpec.from_config({"name": "my_action"})
        assert spec.timeout is None

    def test_action_spec_from_string_config_no_timeout(self) -> None:
        """ActionSpec.from_config with string has no timeout."""
        spec = ActionSpec.from_config("my_action")
        assert spec.timeout is None


class TestAsyncActionTimeout:
    """Tests for async action execution with timeout."""

    @pytest.fixture
    def registry(self) -> ActionRegistry:
        """Create a registry with fast and slow async actions."""
        reg = ActionRegistry()

        async def fast_action(ctx: dict) -> str:
            await asyncio.sleep(0.01)
            return "fast_done"

        async def slow_action(ctx: dict) -> str:
            await asyncio.sleep(5.0)
            return "slow_done"

        def sync_action(ctx: dict) -> str:
            return "sync_done"

        reg.register("fast_action", fast_action)
        reg.register("slow_action", slow_action)
        reg.register("sync_action", sync_action)
        return reg

    @pytest.mark.asyncio
    async def test_async_action_completes_within_timeout(
        self, registry: ActionRegistry
    ) -> None:
        """Action that finishes before timeout succeeds."""
        executor = ActionExecutor(registry, log_execution=False)
        spec = ActionSpec(name="fast_action", timeout=2.0)

        result = await executor.async_execute_action_spec(spec, {})

        assert result.success
        assert result.result == "fast_done"

    @pytest.mark.asyncio
    async def test_async_action_exceeds_timeout_returns_failure(
        self, registry: ActionRegistry
    ) -> None:
        """Action that takes too long returns failure with TimeoutError."""
        executor = ActionExecutor(registry, log_execution=False)
        spec = ActionSpec(name="slow_action", timeout=0.05)

        result = await executor.async_execute_action_spec(spec, {})

        assert not result.success
        assert isinstance(result.error, TimeoutError)
        assert "timed out" in str(result.error)

    @pytest.mark.asyncio
    async def test_timeout_none_means_no_timeout(
        self, registry: ActionRegistry
    ) -> None:
        """timeout=None does not impose any timeout (action runs freely)."""
        executor = ActionExecutor(registry, log_execution=False)
        spec = ActionSpec(name="fast_action", timeout=None)

        result = await executor.async_execute_action_spec(spec, {})

        assert result.success
        assert result.result == "fast_done"

    @pytest.mark.asyncio
    async def test_timeout_in_transition_result_execution(
        self, registry: ActionRegistry
    ) -> None:
        """Timeout is applied when executing actions from a TransitionResult."""
        executor = ActionExecutor(registry, log_execution=False)
        trans_result = TransitionResult.success_result(
            source_state="A",
            target_state="B",
            trigger="go",
            actions=(ActionSpec(name="slow_action", timeout=0.05),),
        )

        exec_result = await executor.async_execute(trans_result, {})

        assert not exec_result.all_succeeded
        failed = exec_result.failed_actions
        assert "slow_action" in failed
