"""Shared test fixtures for PyStator."""

from __future__ import annotations

import pytest

from pystator import (
    ActionRegistry,
    ActionSpec,
    GuardRegistry,
    State,
    StateMachine,
    StateType,
    Transition,
)


@pytest.fixture
def simple_states() -> dict[str, State]:
    """Simple state definitions for testing."""
    return {
        "pending": State(
            name="pending",
            type=StateType.INITIAL,
            description="Waiting for processing",
        ),
        "active": State(
            name="active",
            type=StateType.STABLE,
            description="Currently active",
            on_enter=(ActionSpec("log_activation"),),
        ),
        "completed": State(
            name="completed",
            type=StateType.TERMINAL,
            description="Processing complete",
        ),
    }


@pytest.fixture
def simple_transitions() -> list[Transition]:
    """Simple transition definitions for testing."""
    return [
        Transition(
            trigger="activate",
            source=frozenset({"pending"}),
            dest="active",
            actions=(ActionSpec("send_notification"),),
        ),
        Transition(
            trigger="complete",
            source=frozenset({"active"}),
            dest="completed",
            actions=(ActionSpec("finalize"),),
        ),
    ]


@pytest.fixture
def simple_machine(
    simple_states: dict[str, State], simple_transitions: list[Transition]
) -> StateMachine:
    """Simple state machine for testing."""
    return StateMachine(
        states=simple_states,
        transitions=simple_transitions,
        meta={"machine_name": "test_machine", "version": "1.0.0"},
    )


@pytest.fixture
def order_config() -> dict:
    """Order management FSM configuration."""
    return {
        "meta": {
            "version": "1.0.0",
            "machine_name": "order_fsm",
            "strict_mode": True,
        },
        "states": [
            {
                "name": "pending_new",
                "type": "initial",
                "description": "Order waiting for exchange ack",
                "timeout": {"seconds": 5.0, "destination": "timed_out"},
            },
            {
                "name": "open",
                "type": "stable",
                "description": "Order is live on the book",
                "on_enter": ["notify_ui_open", "log_audit_trail"],
            },
            {
                "name": "partially_filled",
                "type": "stable",
                "description": "Some qty executed",
            },
            {
                "name": "filled",
                "type": "terminal",
                "description": "100% execution complete",
            },
            {
                "name": "rejected",
                "type": "terminal",
                "description": "Order rejected",
            },
            {
                "name": "canceled",
                "type": "terminal",
                "description": "User canceled",
            },
            {
                "name": "timed_out",
                "type": "terminal",
                "description": "Exchange did not respond",
            },
        ],
        "transitions": [
            {
                "trigger": "exchange_ack",
                "source": "pending_new",
                "dest": "open",
                "actions": ["update_order_id"],
            },
            {
                "trigger": "exchange_nack",
                "source": "pending_new",
                "dest": "rejected",
                "actions": ["record_rejection_reason"],
            },
            {
                "trigger": "timeout",
                "source": "pending_new",
                "dest": "timed_out",
            },
            {
                "trigger": "execution_report",
                "source": ["open", "partially_filled"],
                "dest": "filled",
                "guards": ["is_full_fill"],
                "actions": ["update_positions", "release_buying_power"],
            },
            {
                "trigger": "execution_report",
                "source": "open",
                "dest": "partially_filled",
                "guards": ["is_partial_fill"],
                "actions": ["update_positions", "decrement_remaining_qty"],
            },
            {
                "trigger": "cancel_request",
                "source": ["open", "partially_filled"],
                "dest": "canceled",
                "guards": ["is_cancellable"],
                "actions": ["send_cancel_to_exchange"],
            },
        ],
        "error_policy": {
            "default_fallback": "rejected",
            "retry_attempts": 3,
        },
    }


@pytest.fixture
def order_machine(order_config: dict) -> StateMachine:
    """Order management state machine."""
    return StateMachine.from_dict(order_config)


@pytest.fixture
def guard_registry() -> GuardRegistry:
    """Guard registry with common guards."""
    registry = GuardRegistry()

    registry.register(
        "is_full_fill",
        lambda ctx: ctx.get("fill_qty", 0) >= ctx.get("order_qty", 1),
    )
    registry.register(
        "is_partial_fill",
        lambda ctx: 0 < ctx.get("fill_qty", 0) < ctx.get("order_qty", 1),
    )
    registry.register(
        "is_cancellable",
        lambda ctx: not ctx.get("in_flight", False),
    )
    registry.register("always_pass", lambda ctx: True)
    registry.register("always_fail", lambda ctx: False)

    return registry


@pytest.fixture
def action_registry() -> ActionRegistry:
    """Action registry with test actions."""
    registry = ActionRegistry()
    executed: list[str] = []

    def make_action(name: str):
        def action(ctx: dict) -> str:
            executed.append(name)
            return f"executed_{name}"

        return action

    for name in [
        "update_order_id",
        "record_rejection_reason",
        "update_positions",
        "release_buying_power",
        "decrement_remaining_qty",
        "send_cancel_to_exchange",
        "notify_ui_open",
        "log_audit_trail",
        "log_activation",
        "send_notification",
        "finalize",
    ]:
        registry.register(name, make_action(name))

    registry._test_executed = executed  # type: ignore

    return registry
