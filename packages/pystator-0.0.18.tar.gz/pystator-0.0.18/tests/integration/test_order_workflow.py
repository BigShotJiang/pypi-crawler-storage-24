"""Integration tests for order management workflow."""

from __future__ import annotations

from datetime import UTC, datetime, timedelta

from pystator import ActionRegistry, Event, GuardRegistry, StateMachine, check_timeout
from pystator.actions import ActionExecutor


class TestOrderLifecycle:
    """Test complete order lifecycle scenarios."""

    def test_happy_path_full_fill(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
        action_registry: ActionRegistry,
    ) -> None:
        """Test happy path: pending_new -> open -> filled."""
        order_machine.bind_guards(guard_registry)
        executor = ActionExecutor(action_registry, log_execution=False)

        # Simulate order state (would be from DB in real app)
        current_state = "pending_new"
        context = {"order_id": "ORD-001", "order_qty": 100}

        # Step 1: Exchange acknowledges the order
        result = order_machine.process(current_state, "exchange_ack", context)
        assert result.success
        assert result.target_state == "open"

        # Execute actions (in real app, after DB commit)
        exec_result = executor.execute(result, context)
        assert exec_result.all_succeeded

        # Step 2: Full fill execution
        current_state = result.target_state
        context["fill_qty"] = 100

        result = order_machine.process(current_state, "execution_report", context)
        assert result.success
        assert result.target_state == "filled"

        # Execute actions
        exec_result = executor.execute(result, context)
        assert exec_result.all_succeeded

    def test_partial_fill_then_full_fill(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
        action_registry: ActionRegistry,
    ) -> None:
        """Test partial fill followed by complete fill."""
        order_machine.bind_guards(guard_registry)
        executor = ActionExecutor(action_registry, log_execution=False)

        context = {"order_id": "ORD-002", "order_qty": 100}

        # Exchange ack
        result = order_machine.process("pending_new", "exchange_ack", context)
        assert result.target_state == "open"
        executor.execute(result, context)

        # Partial fill (50 of 100)
        context["fill_qty"] = 50
        result = order_machine.process("open", "execution_report", context)
        assert result.success
        assert result.target_state == "partially_filled"
        executor.execute(result, context)

        # Complete fill (remaining 50)
        context["fill_qty"] = 100  # Total filled now
        result = order_machine.process("partially_filled", "execution_report", context)
        assert result.success
        assert result.target_state == "filled"

    def test_order_rejection(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test order rejection path."""
        order_machine.bind_guards(guard_registry)

        context = {"order_id": "ORD-003", "reason": "Insufficient margin"}

        result = order_machine.process("pending_new", "exchange_nack", context)
        assert result.success
        assert result.target_state == "rejected"
        assert "record_rejection_reason" in result.all_actions

    def test_order_cancellation(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test order cancellation from open state."""
        order_machine.bind_guards(guard_registry)

        context = {"order_id": "ORD-004", "in_flight": False}

        # First get to open state
        result = order_machine.process("pending_new", "exchange_ack", context)
        assert result.target_state == "open"

        # Cancel the order
        result = order_machine.process("open", "cancel_request", context)
        assert result.success
        assert result.target_state == "canceled"

    def test_cancel_blocked_by_guard(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test cancellation blocked when order is in-flight."""
        order_machine.bind_guards(guard_registry)

        context = {"order_id": "ORD-005", "in_flight": True}  # Order in flight

        # Get to open state
        result = order_machine.process("pending_new", "exchange_ack", context)
        assert result.target_state == "open"

        # Try to cancel - should fail due to guard
        result = order_machine.process("open", "cancel_request", context)
        assert result.success is False

    def test_timeout_handling(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test order timeout when exchange doesn't respond."""
        order_machine.bind_guards(guard_registry)

        # Simulate order that entered pending_new 10 seconds ago
        entered_at = datetime.now(UTC) - timedelta(seconds=10)

        result = check_timeout(order_machine, "pending_new", entered_at)

        assert result is not None
        assert result.success
        assert result.target_state == "timed_out"


class TestIdempotency:
    """Test idempotent event handling."""

    def test_duplicate_fill_from_terminal_state(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test that duplicate fills are rejected from terminal state."""
        order_machine.bind_guards(guard_registry)

        context = {"fill_qty": 100, "order_qty": 100}

        # Trying to process fill from already filled state
        result = order_machine.process("filled", "execution_report", context)

        # Should fail because FILLED is terminal
        assert result.success is False

    def test_same_event_different_context(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test same trigger with different contexts produces different results."""
        order_machine.bind_guards(guard_registry)

        # Full fill context
        full_fill_ctx = {"fill_qty": 100, "order_qty": 100}
        result = order_machine.process("open", "execution_report", full_fill_ctx)
        assert result.target_state == "filled"

        # Partial fill context
        partial_ctx = {"fill_qty": 50, "order_qty": 100}
        result = order_machine.process("open", "execution_report", partial_ctx)
        assert result.target_state == "partially_filled"


class TestEventPayloadIntegration:
    """Test Event object integration."""

    def test_event_payload_in_context(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test that event payload is available in guard context."""
        order_machine.bind_guards(guard_registry)

        event = Event(
            trigger="execution_report",
            payload={"fill_qty": 100, "order_qty": 100},
            source="exchange",
            metadata={"execution_id": "EXE-001"},
        )

        result = order_machine.process("open", event)

        assert result.success
        assert result.target_state == "filled"

    def test_event_object_in_context(
        self,
        order_config: dict,
        guard_registry: GuardRegistry,
    ) -> None:
        """Test that full event object is accessible in context."""
        received_events: list[Event] = []

        guard_registry.register(
            "capture_event",
            lambda ctx: (received_events.append(ctx.get("_event")), True)[1],
        )

        # Build machine with exchange_ack transition that uses the guard so it gets evaluated
        config = dict(order_config)
        transitions = []
        for t in config["transitions"]:
            if t.get("trigger") == "exchange_ack" and t.get("source") == "pending_new":
                transitions.append({**t, "guards": ["capture_event"]})
            else:
                transitions.append(t)
        config["transitions"] = transitions
        machine = StateMachine.from_dict(config)
        machine.bind_guards(guard_registry)

        event = Event(
            trigger="exchange_ack",
            payload={"order_id": "NEW-001"},
        )
        machine.process("pending_new", event)

        assert len(received_events) == 1
        assert received_events[0].trigger == "exchange_ack"


class TestActionExecution:
    """Test action execution integration."""

    def test_actions_executed_in_order(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
        action_registry: ActionRegistry,
    ) -> None:
        """Test actions are executed in correct order."""
        order_machine.bind_guards(guard_registry)
        executor = ActionExecutor(action_registry, log_execution=False)

        # Clear previous executions
        action_registry._test_executed.clear()  # type: ignore

        context = {"fill_qty": 100, "order_qty": 100}

        result = order_machine.process("open", "execution_report", context)
        exec_result = executor.execute(result, context)

        # Verify actions were executed
        executed = action_registry._test_executed  # type: ignore
        assert "update_positions" in executed
        assert "release_buying_power" in executed

    def test_on_enter_actions_executed(
        self,
        order_machine: StateMachine,
        guard_registry: GuardRegistry,
        action_registry: ActionRegistry,
    ) -> None:
        """Test on_enter actions are included in result."""
        order_machine.bind_guards(guard_registry)

        result = order_machine.process("pending_new", "exchange_ack", {})

        # open state has on_enter: ["notify_ui_open", "log_audit_trail"]
        enter_names = tuple(s.name for s in result.on_enter_actions)
        assert "notify_ui_open" in enter_names
        assert "log_audit_trail" in enter_names
