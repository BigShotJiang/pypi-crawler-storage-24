"""Integration tests for PyStator."""
