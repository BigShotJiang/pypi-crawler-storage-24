"""Hypothesis strategies for generating valid PyStator state machines."""

from __future__ import annotations

from typing import Any

from hypothesis import strategies as st

from pystator import StateMachine


@st.composite
def state_names(draw: st.DrawFn, min_size: int = 2, max_size: int = 8) -> list[str]:
    """Generate a list of unique state names (lowercase letters, digits, underscores only)."""
    n = draw(st.integers(min_value=min_size, max_value=max_size))
    names = draw(
        st.lists(
            st.from_regex(r"[a-z][a-z0-9_]{1,12}", fullmatch=True),
            min_size=n,
            max_size=n,
            unique=True,
        )
    )
    return names


@st.composite
def trigger_names(draw: st.DrawFn, min_size: int = 1, max_size: int = 6) -> list[str]:
    """Generate a list of unique trigger names."""
    n = draw(st.integers(min_value=min_size, max_value=max_size))
    names = draw(
        st.lists(
            st.from_regex(r"[a-z][a-z_]{1,10}", fullmatch=True),
            min_size=n,
            max_size=n,
            unique=True,
        )
    )
    return names


@st.composite
def state_machines(draw: st.DrawFn) -> tuple[StateMachine, dict[str, Any]]:
    """Generate a valid random state machine.

    Returns (machine, config_dict) so tests can inspect both.
    """
    names = draw(state_names(min_size=3, max_size=8))
    triggers = draw(trigger_names(min_size=1, max_size=5))

    # First state is initial, last is terminal, rest are stable
    initial_name = names[0]
    terminal_name = names[-1]

    states: list[dict[str, Any]] = []
    states.append({"name": initial_name, "type": "initial"})
    for name in names[1:-1]:
        states.append({"name": name, "type": "stable"})
    states.append({"name": terminal_name, "type": "terminal"})

    non_terminal = names[:-1]

    # Generate transitions: each trigger gets at least one transition
    transitions: list[dict[str, Any]] = []
    for trigger in triggers:
        source = draw(st.sampled_from(non_terminal))
        dest = draw(st.sampled_from(names))
        transitions.append({"trigger": trigger, "source": [source], "dest": dest})

    # Ensure at least one path from initial to terminal
    # by adding a direct transition if none exists
    has_path_to_terminal = any(t["dest"] == terminal_name for t in transitions)
    if not has_path_to_terminal:
        source = draw(st.sampled_from(non_terminal))
        trigger = draw(st.sampled_from(triggers))
        transitions.append(
            {
                "trigger": f"_finish_{source}",
                "source": [source],
                "dest": terminal_name,
            }
        )

    config = {
        "meta": {"machine_name": "test_machine", "strict_mode": False},
        "states": states,
        "transitions": transitions,
    }

    machine = StateMachine.from_dict(config)
    return machine, config
