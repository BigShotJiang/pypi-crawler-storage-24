# ruff: noqa: E402
"""PyStator -- Config-driven finite state machine for Python.

Config is the single source of truth. Python provides implementations.

Quick start:
    >>> from pystator import StateMachine
    >>>
    >>> machine = StateMachine.from_yaml("order_fsm.yaml")
    >>>
    >>> @machine.guard("is_valid")
    ... def is_valid(ctx):
    ...     return ctx.get("valid", False)
    >>>
    >>> @machine.action("notify")
    ... def notify(ctx):
    ...     send_email(ctx["email"], "State changed")
    >>>
    >>> # Stateless processing
    >>> result = machine.process("pending", "confirm", {"valid": True})
    >>>
    >>> # Or create a stateful instance
    >>> order = machine.create(context={"order_id": "123"})
    >>> order.send("confirm", valid=True)
"""

from __future__ import annotations

try:
    from importlib.metadata import version as _get_version

    __version__ = _get_version("pystator")
except Exception:
    __version__ = "0.0.0.dev0"

# Core types
from pystator._types import (
    EFFECT_TYPES,
    ActionSpec,
    CheckSpec,
    GuardSpec,
    HistoryType,
    Region,
    State,
    StateType,
    Timeout,
    Transition,
    TransitionResult,
)
from pystator.actions import ActionExecutor, ActionRegistry, ActionResult, ActionStatus

# Builtins
from pystator.builtins import builtin_registries, register_builtins

# Declarative features
from pystator.checks import evaluate_check
from pystator.effects import apply_effect

# Errors
from pystator.errors import (
    ActionNotFoundError,
    ConfigurationError,
    ErrorCode,
    ErrorPolicy,
    FSMError,
    GuardNotFoundError,
    GuardRejectedError,
    InvalidTransitionError,
    StaleVersionError,
    TerminalStateError,
    TimeoutExpiredError,
    UndefinedStateError,
    UndefinedTriggerError,
)

# Event
from pystator.event import Event

# Guards + Actions
from pystator.guards import (
    GuardEvaluator,
    GuardRegistry,
    GuardResult,
    all_of,
    any_of,
    equals,
    greater_than,
    in_list,
    negate,
)

# Hooks
from pystator.hooks import (
    DwellTimeTracker,
    LoggingHook,
    MetricsCollector,
    StructuredLoggingHook,
    TransitionHook,
    TransitionObserver,
)
from pystator.instance import EntitySession
from pystator.lint import LintSeverity, LintWarning, lint

# Machine + Instance
from pystator.machine import StateMachine, StateMachineBuilder, check_timeout

# Orchestrator
from pystator.orchestrator import Orchestrator

# Sinks
from pystator.sinks import (
    EventSink,
    LoggingEventSink,
    LoggingMetricSink,
    MetricSink,
    configure_event_sink,
    configure_metric_sink,
    create_metric_action,
    create_publish_action,
)

# Stores
from pystator.stores import (
    AsyncStateStore,
    AuditStore,
    BatchStateStore,
    InMemoryStateStore,
    QueryableStateStore,
    StateStore,
    StateStoreClient,
    VersionedStateStore,
    batch_fallback,
)

# Optional store backends (may be None if dependencies are missing)
try:
    from pystator.stores.sqlite import SQLiteStateStore
except ImportError:
    SQLiteStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.postgres import PostgresStateStore
except ImportError:
    PostgresStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.mongodb import MongoDBStateStore
except ImportError:
    MongoDBStateStore = None  # type: ignore[assignment,misc]

try:
    from pystator.stores.redis import RedisStateStore
except ImportError:
    RedisStateStore = None  # type: ignore[assignment,misc]

# Parallel
from pystator._parallel import ParallelStateConfig

__all__ = [
    # Core
    "StateMachine",
    "StateMachineBuilder",
    "EntitySession",
    "Orchestrator",
    "TransitionResult",
    "Event",
    # Stores
    "InMemoryStateStore",
    "StateStore",
    "AsyncStateStore",
    "SQLiteStateStore",
    "PostgresStateStore",
    "MongoDBStateStore",
    "RedisStateStore",
    "StateStoreClient",
    "VersionedStateStore",
    # Errors (the ones users actually catch)
    "FSMError",
    "InvalidTransitionError",
    "GuardRejectedError",
    "TerminalStateError",
    "ConfigurationError",
    "UndefinedStateError",
    "UndefinedTriggerError",
    "StaleVersionError",
    "ErrorPolicy",
    # Registries (needed for decorator flow)
    "GuardRegistry",
    "ActionRegistry",
    # Hooks (most common)
    "TransitionHook",
    "LoggingHook",
    # Types (needed for programmatic machine construction)
    "State",
    "StateType",
    "Transition",
]
