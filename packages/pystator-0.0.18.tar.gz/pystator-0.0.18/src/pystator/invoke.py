"""Invoke adapter: start/stop long-running activities when entering/exiting states.

States may declare ``invoke`` in config; the adapter is called by the
orchestrator around transition application. If no adapter is set, invoke
specs are ignored.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

if TYPE_CHECKING:
    from pystator._types import InvokeSpec

GetStateInvoke = Callable[[str], tuple[Any, ...]]


@runtime_checkable
class InvokeAdapter(Protocol):
    """Protocol for starting and stopping invoked services on state enter/exit.

    Implementations interpret ``spec.src`` (e.g. service type) and ``spec.id``.
    Use ``spec.on_done`` to emit an event when the service completes (caller
    is responsible for sending that event into the FSM).
    """

    def start(
        self,
        spec: InvokeSpec,
        source_state: str,
        context: dict[str, Any],
    ) -> None:
        """Start the invoked service when entering a state."""
        ...

    def stop(self, spec: InvokeSpec, context: dict[str, Any]) -> None:
        """Stop the invoked service when exiting a state."""
        ...


def run_invoke_stop(
    adapter: InvokeAdapter,
    source_state: str,
    get_state_invoke: GetStateInvoke,
    context: dict[str, Any],
) -> None:
    """Stop invokes for the state we are leaving. Call before actions."""
    for spec in get_state_invoke(source_state):
        adapter.stop(spec, context)


def run_invoke_start(
    adapter: InvokeAdapter,
    target_state: str,
    source_state: str,
    get_state_invoke: GetStateInvoke,
    context: dict[str, Any],
) -> None:
    """Start invokes for the state we are entering. Call after actions."""
    for spec in get_state_invoke(target_state):
        adapter.start(spec, source_state, context)


def run_invoke_lifecycle(
    adapter: InvokeAdapter,
    result_source_state: str,
    result_target_state: str | None,
    get_state_invoke: GetStateInvoke,
    context: dict[str, Any],
) -> None:
    """Run stop for source state invokes, then start for target state invokes.

    Call after a successful transition: stop invokes for the state we left,
    then start invokes for the state we entered.

    Args:
        adapter: The invoke adapter implementation.
        result_source_state: State we are leaving.
        result_target_state: State we are entering (None to skip start).
        get_state_invoke: Callable(name) -> tuple of InvokeSpec for that state.
        context: Transition context.
    """
    run_invoke_stop(adapter, result_source_state, get_state_invoke, context)
    if result_target_state:
        run_invoke_start(
            adapter,
            result_target_state,
            result_source_state,
            get_state_invoke,
            context,
        )
