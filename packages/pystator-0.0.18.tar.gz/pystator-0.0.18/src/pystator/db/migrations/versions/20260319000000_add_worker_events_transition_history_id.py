"""Add transition_history_id correlation field to worker_events.

Revision ID: 20260319000000
Revises: 20260223110000
Create Date: 2026-03-19
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects.postgresql import UUID

revision: str = "20260319000000"
down_revision: str | None = "20260223110000"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def _schema() -> str | None:
    """Use pystator schema for PostgreSQL; None for SQLite (no schema support)."""
    connection = op.get_bind()
    return None if connection.dialect.name == "sqlite" else "pystator"


def upgrade() -> None:
    schema_name = _schema()
    op.add_column(
        "worker_events",
        sa.Column("transition_history_id", UUID(as_uuid=True), nullable=True),
        schema=schema_name,
    )
    op.create_index(
        "ix_worker_events_transition_history_id",
        "worker_events",
        ["transition_history_id"],
        schema=schema_name,
    )


def downgrade() -> None:
    schema_name = _schema()
    op.drop_index(
        "ix_worker_events_transition_history_id",
        table_name="worker_events",
        schema=schema_name,
    )
    op.drop_column("worker_events", "transition_history_id", schema=schema_name)
