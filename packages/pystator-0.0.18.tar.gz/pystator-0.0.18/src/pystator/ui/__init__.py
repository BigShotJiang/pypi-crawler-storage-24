"""PyStator UI - Next.js frontend for FSM builder and visualization."""

from __future__ import annotations
