import { create } from 'zustand'
import { devtools } from 'zustand/middleware'

export type ToastType = 'success' | 'error'

export interface ToastMessage {
  id: number
  type: ToastType
  message: string
}

export interface ToastState {
  message: ToastMessage | null
  toast: (type: ToastType, text: string) => void
  success: (text: string) => void
  error: (text: string) => void
  dismiss: () => void
}

let nextId = 0

export const useToastStore = create<ToastState>()(
  devtools(
    (set) => ({
      message: null,
      toast: (type, text) => set({ message: { id: ++nextId, type, message: text } }),
      success: (text) => set({ message: { id: ++nextId, type: 'success', message: text } }),
      error: (text) => set({ message: { id: ++nextId, type: 'error', message: text } }),
      dismiss: () => set({ message: null }),
    }),
    { name: 'toast' },
  ),
)

export const selectToastMessage = (s: ToastState) => s.message
export const selectToast = (s: ToastState) => s.toast
export const selectToastSuccess = (s: ToastState) => s.success
export const selectToastError = (s: ToastState) => s.error
export const selectDismiss = (s: ToastState) => s.dismiss
