import { create } from 'zustand'
import { devtools } from 'zustand/middleware'
import { APP_NAME } from '@/lib/constants'

declare global {
  interface Window {
    __APP_CONFIG__?: { theme?: string; appName?: string; version?: string }
  }
}

export interface AppConfigState {
  appName: string
  theme: string
  version: string
  setAppConfig: (patch: Partial<Pick<AppConfigState, 'appName' | 'theme' | 'version'>>) => void
}

function getInitialAppName(): string {
  if (typeof window === 'undefined') return APP_NAME
  return window.__APP_CONFIG__?.appName ?? APP_NAME
}

function getInitialTheme(): string {
  if (typeof window === 'undefined') return 'light'
  return window.__APP_CONFIG__?.theme ?? 'light'
}

function getInitialVersion(): string {
  if (typeof window === 'undefined') return ''
  return window.__APP_CONFIG__?.version ?? ''
}

export const useAppConfigStore = create<AppConfigState>()(
  devtools(
    (set) => ({
      appName: getInitialAppName(),
      theme: getInitialTheme(),
      version: getInitialVersion(),
      setAppConfig: (patch) => set((s) => ({ ...s, ...patch })),
    }),
    { name: 'app-config' },
  ),
)

export const selectAppName = (s: AppConfigState) => s.appName
export const selectTheme = (s: AppConfigState) => s.theme
export const selectVersion = (s: AppConfigState) => s.version
export const selectSetAppConfig = (s: AppConfigState) => s.setAppConfig
