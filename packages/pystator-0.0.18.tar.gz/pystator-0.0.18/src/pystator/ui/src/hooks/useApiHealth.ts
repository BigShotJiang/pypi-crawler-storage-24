'use client'

import { useState, useCallback } from 'react'
import { getApiBaseUrl } from '@/lib/settings'

export interface ApiHealthResult {
  success: boolean
  message: string
}

/** Test API health. Pass optional baseUrl to test unsaved URL (e.g. from form). */
export function useApiHealth() {
  const [testing, setTesting] = useState(false)
  const [result, setResult] = useState<ApiHealthResult | null>(null)

  const test = useCallback(async (overrideBaseUrl?: string) => {
    setTesting(true)
    setResult(null)
    const base = overrideBaseUrl ?? getApiBaseUrl()
    try {
      const res = await fetch(`${base.replace(/\/$/, '')}/health`)
      const data = res.ok ? await res.json().catch(() => ({})) : null
      const status = data?.status ?? (res.ok ? 'ok' : res.statusText)
      const version = data?.version
      if (!res.ok) throw new Error(status)
      setResult({
        success: true,
        message: `Connected. ${status}${version ? ` (${version})` : ''}`,
      })
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to reach API'
      setResult({ success: false, message: msg })
    } finally {
      setTesting(false)
    }
  }, [])

  return { testing, result, test }
}
