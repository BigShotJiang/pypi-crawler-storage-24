'use client'

import { useState, useCallback, useEffect } from 'react'
import { getDatabaseConfig, testDatabase } from '@/lib/api'
import type { DatabaseConfigResponse, DatabaseTestRequest, DatabaseTestResponse } from '@/lib/api'

export type DbConfigState = {
  database_type: string
  machine_count: number
  message: string
  is_default: boolean
} | null

export function useDatabaseConfig() {
  const [config, setConfig] = useState<DbConfigState>(null)
  const [testing, setTesting] = useState(false)
  const [testResult, setTestResult] = useState<DatabaseTestResponse | null>(null)

  const fetchConfig = useCallback(async () => {
    try {
      const r = await getDatabaseConfig()
      setConfig({
        database_type: r.database_type,
        machine_count: r.machine_count,
        message: r.message,
        is_default: r.is_default,
      })
    } catch {
      setConfig(null)
    }
  }, [])

  useEffect(() => {
    fetchConfig()
  }, [fetchConfig])

  const test = useCallback(async (body: DatabaseTestRequest) => {
    setTesting(true)
    setTestResult(null)
    try {
      const result = await testDatabase(body)
      setTestResult(result)
    } catch (err: unknown) {
      const detail =
        err && typeof err === 'object' && 'response' in err && err.response && typeof (err.response as object) === 'object' && 'detail' in (err.response as object)
          ? String((err.response as { detail?: string }).detail)
          : err instanceof Error
            ? err.message
            : 'Failed to test database connection'
      setTestResult({ success: false, message: detail })
    } finally {
      setTesting(false)
    }
  }, [])

  return { config, fetchConfig, testing, testResult, test }
}
