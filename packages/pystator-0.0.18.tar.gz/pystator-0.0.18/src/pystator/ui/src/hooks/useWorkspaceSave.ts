'use client'

import { useState, useCallback } from 'react'
import { listMachines, createMachine, updateMachine, ApiError } from '@/lib/api'
import type { FSMConfig } from '@/lib/types/fsm'

export type SaveStatus = { type: 'idle' } | { type: 'loading' } | { type: 'success'; message: string } | { type: 'error'; message: string }

export function useWorkspaceSave(config: FSMConfig) {
  const [status, setStatus] = useState<SaveStatus>({ type: 'idle' })

  const save = useCallback(async (nameOverride?: string, versionOverride?: string) => {
    setStatus({ type: 'loading' })
    try {
      const name = nameOverride ?? config.meta?.machine_name ?? ''
      const version = versionOverride ?? config.meta?.version ?? '1.0.0'

      // Inject name/version into config.meta before sending
      const configToSave: FSMConfig = {
        ...config,
        meta: {
          ...config.meta,
          machine_name: name,
          version,
        },
      }

      const { machines } = await listMachines()
      const existing = machines.find((m) => m.name === name && m.version === version)
      if (existing) {
        await updateMachine(existing.id, configToSave)
        setStatus({ type: 'success', message: 'FSM updated.' })
      } else {
        await createMachine(configToSave)
        setStatus({ type: 'success', message: 'FSM saved.' })
      }
      setTimeout(() => setStatus({ type: 'idle' }), 3000)
    } catch (e) {
      const message = e instanceof ApiError ? e.message : e instanceof Error ? e.message : 'Save failed.'
      setStatus({ type: 'error', message })
      throw e
    }
  }, [config])

  return { status, save }
}
