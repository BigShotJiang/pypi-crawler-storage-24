import { type ClassValue, clsx } from 'clsx'
import { twMerge } from 'tailwind-merge'

/**
 * Utility function to merge Tailwind CSS classes
 * This is the main utility used by shadcn/ui components (aligned with pycharter)
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format date to readable string (pycharter parity)
 */
export function formatDate(date: string | Date | null | undefined): string {
  if (!date) return 'N/A'
  try {
    const d = typeof date === 'string' ? new Date(date) : date
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    })
  } catch {
    return String(date)
  }
}

/**
 * Format date with time (pycharter parity)
 */
export function formatDateTime(date: string | Date | null | undefined): string {
  if (!date) return 'N/A'
  try {
    const d = typeof date === 'string' ? new Date(date) : date
    return d.toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return String(date)
  }
}

/**
 * Format date to short format (e.g. "Jan 15, 2024") (pycharter parity)
 */
export function formatDateShort(date: string | Date | null | undefined): string {
  if (!date) return 'N/A'
  try {
    const d = typeof date === 'string' ? new Date(date) : date
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  } catch {
    return String(date)
  }
}

/**
 * Format date with time in short format (pycharter parity)
 */
export function formatDateTimeShort(date: string | Date | null | undefined): string {
  if (!date) return 'N/A'
  try {
    const d = typeof date === 'string' ? new Date(date) : date
    return d.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  } catch {
    return String(date)
  }
}

/**
 * Truncate string with ellipsis (pycharter parity)
 */
export function truncate(str: string, length: number): string {
  if (str.length <= length) return str
  return str.slice(0, length) + '...'
}

/**
 * Debounce function (pycharter parity)
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: ReturnType<typeof setTimeout> | null = null
  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      timeout = null
      func(...args)
    }
    if (timeout) clearTimeout(timeout)
    timeout = setTimeout(later, wait)
  }
}

/**
 * Download a blob as a file (pycharter parity)
 */
export function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob)
  const link = document.createElement('a')
  link.href = url
  link.download = filename
  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
  URL.revokeObjectURL(url)
}

/**
 * Validate that a name/title follows the naming convention (pycharter parity)
 */
export function validateName(name: string, fieldName = 'name'): string {
  if (!name || typeof name !== 'string') {
    throw new Error(`${fieldName} must be a non-empty string`)
  }
  const normalized = name.toLowerCase().trim()
  if (!normalized) throw new Error(`${fieldName} cannot be empty`)
  const pattern = /^[a-z0-9_]+$/
  if (!pattern.test(normalized)) {
    throw new Error(
      `${fieldName} must contain only lowercase letters (a-z), numbers (0-9), and underscores (_). Got: "${name}"`
    )
  }
  return normalized
}

/**
 * Check if a name/title is valid without throwing (pycharter parity)
 */
export function isValidName(name: string): boolean {
  try {
    validateName(name)
    return true
  } catch {
    return false
  }
}

/**
 * Normalize a name to the allowed format (lowercase, alphanumeric + underscores).
 *
 * Converts invalid names to valid ones by lowercasing, replacing spaces/hyphens
 * with underscores, removing invalid characters, and collapsing consecutive underscores.
 *
 * Returns empty string if normalization produces nothing.
 */
export function normalizeName(name: string): string {
  if (!name || typeof name !== 'string') return ''
  let normalized = name.toLowerCase().trim()
  normalized = normalized.replace(/[\s\-]+/g, '_')
  normalized = normalized.replace(/[^a-z0-9_]/g, '')
  normalized = normalized.replace(/_+/g, '_')
  normalized = normalized.replace(/^_+|_+$/g, '')
  return normalized
}
