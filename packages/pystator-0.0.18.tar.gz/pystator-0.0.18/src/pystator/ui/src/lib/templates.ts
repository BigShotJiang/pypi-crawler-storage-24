/**
 * FSM template display labels.
 * Template list and content come from the API (GET /api/v1/templates/fsm, GET /api/v1/templates/fsm/{filename}).
 */

/** Human-readable label for a template filename (e.g. order_management.yaml -> Order Management). */
export function fsmTemplateLabel(filename: string): string {
  const base = filename.replace(/\.(yaml|yml)$/i, '')
  return base
    .split(/[-_]/)
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
    .join(' ')
}
