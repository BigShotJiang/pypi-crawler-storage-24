/**
 * Color coding for FSM diagram elements.
 *
 * States: STATE_COLORS by type (initial=emerald, stable=blue, terminal=slate, error=red, parallel=fuchsia).
 * Compound (parent) boxes: HIERARCHY_COLORS.parent (slate).
 * Edge labels: trigger=teal, guards=amber, actions=violet, delay=pink, region=purple, timeout=slate, initial=slate.
 * All chosen for clear distinction and readability.
 */

/** State node fill and border by type */
export const STATE_COLORS = {
  initial: {
    background: '#d1fae5', // emerald-100
    border: '#059669',     // emerald-600
    text: '#065f46',       // emerald-800
  },
  stable: {
    background: '#dbeafe', // blue-100
    border: '#2563eb',     // blue-600
    text: '#1e40af',       // blue-800
  },
  terminal: {
    background: '#f1f5f9', // slate-100
    border: '#475569',     // slate-600
    text: '#334155',       // slate-700
  },
  error: {
    background: '#fee2e2', // red-100
    border: '#dc2626',     // red-600
    text: '#991b1b',       // red-800
  },
  parallel: {
    background: '#fae8ff', // fuchsia-100
    border: '#c026d3',     // fuchsia-600
    text: '#86198f',       // fuchsia-800
  },
} as const

/** Edge label parts (trigger, guards, actions, delay, region) */
export const EDGE_LABEL_COLORS = {
  trigger: {
    bg: '#ccfbf1',   // teal-100
    text: '#0f766e', // teal-700
    border: '#0d9488', // teal-600
  },
  guards: {
    bg: '#fef3c7',   // amber-100
    text: '#b45309', // amber-700
    border: '#d97706',
  },
  actions: {
    bg: '#ede9fe',   // violet-100
    text: '#6d28d9', // violet-700
    border: '#7c3aed',
  },
  timeout: {
    bg: '#f1f5f9',
    text: '#475569',
    border: '#64748b',
  },
  delay: {
    bg: '#fce7f3',   // pink-100
    text: '#be185d', // pink-700
    border: '#db2777', // pink-600
  },
  region: {
    bg: '#f3e8ff',   // purple-100
    text: '#7e22ce', // purple-700
    border: '#9333ea', // purple-600
  },
  /** Hierarchy / initial-child edge */
  initial: {
    bg: '#f1f5f9',
    text: '#475569',
    border: '#94a3b8',
  },
} as const

/** Default/fallback edge label (e.g. "initial" or plain label) */
export const EDGE_LABEL_COLORS_DEFAULT = {
  bg: '#f1f5f9',
  text: '#475569',
  border: '#64748b',
} as const

/** Edge line stroke by kind (normal vs timeout vs highlighted vs delayed) */
export const EDGE_STROKE = {
  default: '#64748b',   // slate-500
  timeout: '#64748b',   // slate-500, dashed
  highlighted: '#2563eb', // blue-600
  delayed: '#db2777',   // pink-600, dashed
} as const

/** Current-state node highlight (entity instance "you are here") */
export const CURRENT_STATE_HIGHLIGHT = {
  ring: '#2563eb',      // blue-600, matches EDGE_STROKE.highlighted
  ringWidth: 3,
  shadow: '0 0 0 3px rgba(37, 99, 235, 0.4)',
} as const

/** Colors for hierarchical/compound state grouping */
export const HIERARCHY_COLORS = {
  parent: {
    background: '#f8fafc', // slate-50
    border: '#94a3b8',     // slate-400
    text: '#475569',       // slate-600
  },
  region: {
    background: '#fdf4ff', // fuchsia-50
    border: '#d946ef',     // fuchsia-500
    text: '#a21caf',       // fuchsia-700
  },
} as const
