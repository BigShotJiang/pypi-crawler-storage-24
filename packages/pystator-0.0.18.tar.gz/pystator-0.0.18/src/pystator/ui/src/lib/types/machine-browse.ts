/**
 * Types for the client-only machine browse folder tree.
 * Mirrors pycharter FolderTreeNode shape for reuse of tree-rendering patterns.
 */

export const MACHINE_BROWSE_STORAGE_KEY = 'pystator_machine_browse_tree'

/** A folder in the machine browse tree (client-only, persisted in localStorage). */
export interface MachineFolder {
  id: string
  name: string
  parent_id: string | null
}

/** Persisted state for the machine browse tree. */
export interface MachineBrowseTreeState {
  folders: MachineFolder[]
  /** Machine name -> folder id or null for root. */
  assignments: Record<string, string | null>
}

/** Tree node shape matching pycharter FolderTreeNode for consistent UI. */
export interface MachineBrowseTreeNode {
  id: string
  name: string
  kind: 'folder' | 'item'
  /** For tree building we use a single type 'machine'. */
  folder_type: string
  children?: MachineBrowseTreeNode[]
  /** Present for item nodes: machine name. */
  item_id?: string
  item_label?: string
  item_meta?: Record<string, unknown>
}
