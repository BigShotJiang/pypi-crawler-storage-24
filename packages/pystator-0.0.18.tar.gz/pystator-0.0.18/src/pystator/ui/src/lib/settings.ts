/**
 * Settings storage utility
 *
 * Manages client-side settings using localStorage.
 * Mirrors PyCharter's lib/settings.ts: apiServer, database (optional DLQ omitted for parity).
 */

export interface AppSettings {
  apiServer: {
    url: string
  }
  database: {
    enabled: boolean
    connectionString?: string
    host?: string
    port?: number
    database?: string
    username?: string
    password?: string
  }
}

const SETTINGS_KEY = 'pystator_settings'

const DEFAULT_SETTINGS: AppSettings = {
  apiServer: {
    url: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8004',
  },
  database: {
    enabled: false,
  },
}

/**
 * Get current settings from localStorage
 */
export function getSettings(): AppSettings {
  if (typeof window === 'undefined') {
    return DEFAULT_SETTINGS
  }

  try {
    const stored = localStorage.getItem(SETTINGS_KEY)
    if (stored) {
      const parsed = JSON.parse(stored)
      return {
        ...DEFAULT_SETTINGS,
        ...parsed,
        apiServer: {
          ...DEFAULT_SETTINGS.apiServer,
          ...parsed.apiServer,
        },
        database: {
          ...DEFAULT_SETTINGS.database,
          ...parsed.database,
        },
      }
    }
  } catch (error) {
    console.error('Failed to load settings:', error)
  }

  return DEFAULT_SETTINGS
}

/**
 * Save settings to localStorage
 */
export function saveSettings(settings: AppSettings): void {
  if (typeof window === 'undefined') {
    return
  }

  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
  } catch (error) {
    console.error('Failed to save settings:', error)
    throw error
  }
}

/**
 * Get API base URL from settings.
 * In dev when NEXT_PUBLIC_API_URL is set, returns '' so requests go to same-origin
 * /api/* and Next.js rewrites proxy to the API (avoids CORS and connection issues).
 */
export function getApiBaseUrl(): string {
  if (typeof window !== 'undefined' && process.env.NODE_ENV === 'development' && process.env.NEXT_PUBLIC_API_URL) {
    return ''
  }
  const settings = getSettings()
  return settings.apiServer.url || DEFAULT_SETTINGS.apiServer.url
}
