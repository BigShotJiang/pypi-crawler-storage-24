/**
 * Fan out edge label positions when multiple edges share the same source→target
 * so labels do not stack at identical (labelX, labelY).
 */

import type { Edge } from '@xyflow/react'
import type { EdgeLabelData } from './fsmToReactFlow'

/** Pixel spacing between fanned labels (tune here only). */
export const DEFAULT_FAN_STEP_PX = 28

export interface ParallelEdgeLabelDeltaParams {
  isSelfLoop: boolean
  sourceX: number
  sourceY: number
  targetX: number
  targetY: number
  index: number
  count: number
  stepPx?: number
}

/**
 * Offset from the path midpoint for this edge's label.
 * Non–self-loop: perpendicular to source→target. Self-loop: vertical stack (dx=0).
 */
export function parallelEdgeLabelDelta(params: ParallelEdgeLabelDeltaParams): { dx: number; dy: number } {
  const { isSelfLoop, sourceX, sourceY, targetX, targetY, index, count, stepPx = DEFAULT_FAN_STEP_PX } = params
  if (count < 2) return { dx: 0, dy: 0 }

  const offset = (index - (count - 1) / 2) * stepPx

  if (isSelfLoop) {
    return { dx: 0, dy: offset }
  }

  const vx = targetX - sourceX
  const vy = targetY - sourceY
  const len = Math.hypot(vx, vy)
  if (len < 1e-6) {
    return { dx: 0, dy: offset }
  }

  // Unit perpendicular (rotate (vx,vy) by 90° CCW)
  const nx = -vy / len
  const ny = vx / len
  return { dx: nx * offset, dy: ny * offset }
}

function pairKey(source: string, target: string): string {
  return `${source}\0${target}`
}

function compareEdgesForFan(a: Edge<EdgeLabelData>, b: Edge<EdgeLabelData>): number {
  const da = a.data ?? {}
  const db = b.data ?? {}
  const synA = da.isSynthetic === true ? 1 : 0
  const synB = db.isSynthetic === true ? 1 : 0
  if (synA !== synB) return synA - synB
  const tiA = da.transitionIndex
  const tiB = db.transitionIndex
  if (tiA != null && tiB != null && tiA !== tiB) return tiA - tiB
  if (tiA != null && tiB == null) return -1
  if (tiA == null && tiB != null) return 1
  return a.id.localeCompare(b.id)
}

/**
 * Mutates `edges[].data` with labelParallelIndex / labelParallelCount per source→target group.
 */
export function annotateParallelEdgeLabelFan(edges: Edge<EdgeLabelData>[]): void {
  const groups = new Map<string, Edge<EdgeLabelData>[]>()
  for (const e of edges) {
    const k = pairKey(e.source, e.target)
    const list = groups.get(k)
    if (list) list.push(e)
    else groups.set(k, [e])
  }

  for (const group of groups.values()) {
    if (group.length < 2) {
      for (const e of group) {
        const d = e.data
        if (!d) continue
        const { labelParallelIndex: _i, labelParallelCount: _c, ...rest } = d
        e.data = rest as EdgeLabelData
      }
      continue
    }

    group.sort(compareEdgesForFan)
    const n = group.length
    for (let i = 0; i < n; i++) {
      const e = group[i]
      e.data = { ...(e.data ?? {}), labelParallelIndex: i, labelParallelCount: n }
    }
  }
}
