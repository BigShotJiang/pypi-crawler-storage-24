import type { FSMConfig } from '@/lib/types/fsm'

export function buildToggleTemplate(): FSMConfig {
  return {
    meta: { machine_name: 'toggle_machine', version: '1.0.0' },
    states: [
      { name: 'OFF', type: 'initial' },
      { name: 'ON', type: 'stable' },
    ],
    transitions: [
      { trigger: 'toggle', source: 'OFF', dest: 'ON' },
      { trigger: 'toggle', source: 'ON', dest: 'OFF' },
    ],
  }
}

export function buildRequestLifecycleTemplate(): FSMConfig {
  return {
    meta: { machine_name: 'request_lifecycle', version: '1.0.0' },
    states: [
      { name: 'idle', type: 'initial' },
      { name: 'loading', type: 'stable' },
      { name: 'success', type: 'terminal' },
      { name: 'error', type: 'error' },
    ],
    transitions: [
      { trigger: 'start', source: 'idle', dest: 'loading' },
      { trigger: 'resolve', source: 'loading', dest: 'success' },
      { trigger: 'reject', source: 'loading', dest: 'error' },
      { trigger: 'retry', source: 'error', dest: 'loading' },
      { trigger: 'reset', source: ['success', 'error'], dest: 'idle' },
    ],
  }
}
