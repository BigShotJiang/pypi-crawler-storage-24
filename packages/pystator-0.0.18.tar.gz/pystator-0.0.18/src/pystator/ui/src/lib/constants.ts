/** Default app/website name shown in the UI (overridable via app-config). */
export const APP_NAME = 'PyStator'

/** localStorage key for theme so an inline script can apply it before React (avoids flash). */
export const THEME_STORAGE_KEY = 'pystator-theme'

/** Theme IDs that use a dedicated palette (data-theme). light/dark/system use :root + .dark only. */
export const NAMED_THEME_IDS = [
  'ocean',
  'forest',
  'sunset',
  'high-contrast',
  'sepia',
  'violet',
  'cathay',
] as const
export type NamedThemeId = (typeof NAMED_THEME_IDS)[number]

/** User-facing message when the API server is unreachable. */
export const API_CONNECTION_ERROR_MESSAGE =
  'API server not connected. Start it with: pystator api'

/** Timeout for the initial auth check (GET /auth/me) on app load (ms). */
export const AUTH_CHECK_TIMEOUT_MS = 4000
/** Timeout for login POST request (ms). */
export const LOGIN_REQUEST_TIMEOUT_MS = 10000

/** Custom event dispatched when API returns 401 (e.g. token expired). */
export const AUTH_SESSION_EXPIRED_EVENT = 'auth:sessionExpired'
/** Login page query param value for session-expired redirect. */
export const LOGIN_REASON_SESSION_EXPIRED = 'session_expired'

/** Official documentation site URL (Python API, guides, tutorials). Override with NEXT_PUBLIC_DOCS_URL. */
export const DOCS_URL = process.env.NEXT_PUBLIC_DOCS_URL ?? 'https://optophi.github.io/pystator/'

export const ROUTES = {
  HOME: '/',
  LOGIN: '/login',
  WORKSPACE: '/workspace/',
  MACHINES: '/machines/',
  ENTITIES: '/entities/',
  OBSERVABILITY: '/observability/',
  TEMPLATES: '/templates/',
  DOCUMENTATION: '/documentation',
  TABLE_EDITOR: '/table-editor/',
  SETTINGS: '/settings/',
} as const

/** URL for entity detail on the entities page (query param, static export safe). */
export function entityDetailUrl(entityId: string): string {
  return `${ROUTES.ENTITIES}?entityId=${encodeURIComponent(entityId)}`
}
