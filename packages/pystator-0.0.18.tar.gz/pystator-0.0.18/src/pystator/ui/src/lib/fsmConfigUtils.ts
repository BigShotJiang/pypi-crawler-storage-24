/**
 * Pure helpers for FSM config (no API). Used by Create entity flow and tests.
 */
import type { FSMConfig } from '@/lib/types/fsm'

/**
 * Return trigger names for transitions from the initial state.
 * Used to suggest the first event when creating a new entity.
 */
export function getTriggersFromInitialState(config: FSMConfig): string[] {
  const states = config.states ?? []
  const transitions = config.transitions ?? []
  const initial = states.find((s) => s.type === 'initial')
  if (!initial) return []
  const initialName = initial.name
  const triggers: string[] = []
  const seen = new Set<string>()
  for (const t of transitions) {
    if (!t.trigger) continue
    const sources = Array.isArray(t.source) ? t.source : [t.source]
    if (sources.includes(initialName) && !seen.has(t.trigger)) {
      seen.add(t.trigger)
      triggers.push(t.trigger)
    }
  }
  return triggers
}

/**
 * Return trigger names for transitions available from the given state.
 * Used to populate the Send Event trigger dropdown for an entity.
 */
export function getTriggersFromState(config: FSMConfig, currentState: string): string[] {
  const transitions = config.transitions ?? []
  const triggers: string[] = []
  const seen = new Set<string>()
  for (const t of transitions) {
    if (!t.trigger) continue
    const sources = Array.isArray(t.source) ? t.source : [t.source]
    if (sources.includes(currentState) && !seen.has(t.trigger)) {
      seen.add(t.trigger)
      triggers.push(t.trigger)
    }
  }
  return triggers
}
