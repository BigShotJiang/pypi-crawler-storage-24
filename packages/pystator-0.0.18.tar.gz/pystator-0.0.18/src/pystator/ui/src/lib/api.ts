import { clearAccessToken, getAccessToken } from './auth-storage'
import { getApiBaseUrl } from './settings'
import { AUTH_SESSION_EXPIRED_EVENT } from './constants'
import type { FSMConfig, ValidateResponse, ProcessResponse } from './types/fsm'

function handleUnauthorized(): void {
  clearAccessToken()
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(AUTH_SESSION_EXPIRED_EVENT))
  }
}

export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
    public response?: unknown
  ) {
    super(message)
    this.name = 'ApiError'
  }
}

/** Return a user-facing message from a fetch/API error, or a default. */
export function getApiErrorMessage(error: unknown, defaultMessage: string): string {
  if (error instanceof Error) return error.message || defaultMessage
  if (typeof error === 'string') return error
  return defaultMessage
}

/** Response from GET /api/v1/auth/me */
export interface AuthMeResponse {
  username: string
  auth_disabled?: boolean
}

/** Response from POST /api/v1/auth/login */
export interface AuthLoginResponse {
  access_token: string
  token_type: string
  expires_in: number
}

export function authHeaders(): Record<string, string> {
  const token = getAccessToken()
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  if (token) headers['Authorization'] = `Bearer ${token}`
  return headers
}

async function fetchApi<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const url = `${getApiBaseUrl()}${endpoint}`
  const response = await fetch(url, {
    ...options,
    headers: { ...authHeaders(), ...(options?.headers as Record<string, string>) },
  })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  // 204 No Content (e.g. DELETE) has no body; do not call response.json()
  if (response.status === 204) return undefined as T
  const ct = response.headers.get('content-type')
  if (ct?.includes('application/json')) return response.json()
  return response.text() as unknown as T
}

/** Fetch an endpoint and return the response body as a Blob (e.g. for ZIP download). */
export async function getBlob(endpoint: string): Promise<Blob> {
  const url = `${getApiBaseUrl()}${endpoint}`
  const response = await fetch(url, { method: 'GET', headers: authHeaders() })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  return response.blob()
}

/**
 * Fetch with timeout for auth endpoints. On 401 clears token; on AbortError or
 * network error throws ApiError with status 0 or connection message.
 */
async function fetchWithTimeout<T>(
  url: string,
  options: RequestInit,
  timeoutMs: number
): Promise<T> {
  const controller = new AbortController()
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const response = await fetch(url, { ...options, signal: controller.signal })
    clearTimeout(timeoutId)
    if (response.status === 401) {
      handleUnauthorized()
      throw new ApiError('Not authenticated', 401, { detail: 'Not authenticated' })
    }
    if (!response.ok) {
      let errorData: { detail?: string }
      try {
        errorData = await response.json()
      } catch {
        errorData = { detail: response.statusText }
      }
      throw new ApiError(
        errorData.detail ?? `API request failed: ${response.statusText}`,
        response.status,
        errorData
      )
    }
    return await response.json()
  } catch (err) {
    clearTimeout(timeoutId)
    if (err instanceof ApiError) throw err
    if (err instanceof Error && err.name === 'AbortError') {
      throw new ApiError('Request timed out', 0, { originalError: 'Timeout' })
    }
    if (err instanceof TypeError && err.message === 'Failed to fetch') {
      throw new ApiError(
        `Unable to connect to API server at ${getApiBaseUrl()}. Please ensure the API server is running.`,
        0,
        { originalError: 'NetworkError' }
      )
    }
    throw err
  }
}

/** GET /api/v1/auth/me with timeout. Used on initial load. */
export async function authMeWithTimeout(timeoutMs: number): Promise<AuthMeResponse> {
  const url = `${getApiBaseUrl()}/api/v1/auth/me`
  return fetchWithTimeout<AuthMeResponse>(
    url,
    { method: 'GET', headers: authHeaders() },
    timeoutMs
  )
}

/** POST /api/v1/auth/login with timeout. */
export async function loginWithTimeout(
  username: string,
  password: string,
  timeoutMs: number
): Promise<AuthLoginResponse> {
  const url = `${getApiBaseUrl()}/api/v1/auth/login`
  return fetchWithTimeout<AuthLoginResponse>(
    url,
    {
      method: 'POST',
      headers: authHeaders(),
      body: JSON.stringify({ username, password }),
    },
    timeoutMs
  )
}

export async function validateConfig(config: FSMConfig): Promise<ValidateResponse> {
  return fetchApi<ValidateResponse>('/api/v1/machines/validate', {
    method: 'POST',
    body: JSON.stringify({ config }),
  })
}

export async function processEvent(
  config: FSMConfig,
  currentState: string,
  trigger: string,
  context?: Record<string, unknown>
): Promise<ProcessResponse> {
  return fetchApi<ProcessResponse>('/api/v1/process', {
    method: 'POST',
    body: JSON.stringify({ config, current_state: currentState, trigger, context: context ?? {} }),
  })
}

export async function healthCheck(): Promise<{ status: string; version?: string }> {
  return fetchApi<{ status: string; version?: string }>('/health')
}

/** Database config from API (mirrors PyCharter settings/database-config) */
export interface DatabaseConfigResponse {
  configured_url: string | null
  actual_url: string
  database_type: string
  is_default: boolean
  machine_count: number
  message: string
}

/** Request body for testing database connection */
export interface DatabaseTestRequest {
  connection_string?: string
  host?: string
  port?: number
  database?: string
  username?: string
  password?: string
}

/** Response for database connection test */
export interface DatabaseTestResponse {
  success: boolean
  message: string
}

export async function getDatabaseConfig(): Promise<DatabaseConfigResponse> {
  return fetchApi<DatabaseConfigResponse>('/api/v1/settings/database-config')
}

export async function testDatabase(
  body: DatabaseTestRequest
): Promise<DatabaseTestResponse> {
  return fetchApi<DatabaseTestResponse>('/api/v1/settings/test-database', {
    method: 'POST',
    body: JSON.stringify(body),
  })
}

/** Machine list item from API */
export interface MachineListItem {
  id: string
  name: string
  version: string
  description?: string | null
  created_at?: string | null
  updated_at?: string | null
}

/** Machine list response */
export interface MachineListResponse {
  machines: MachineListItem[]
  count: number
}

/** Full machine response (single machine) */
export interface MachineResponse {
  id: string
  name: string
  version: string
  description?: string | null
  strict_mode: boolean
  config: FSMConfig
  created_at?: string | null
  updated_at?: string | null
}

export async function listMachines(): Promise<MachineListResponse> {
  return fetchApi<MachineListResponse>('/api/v1/machines')
}

export async function createMachine(config: FSMConfig): Promise<MachineResponse> {
  return fetchApi<MachineResponse>('/api/v1/machines', {
    method: 'POST',
    body: JSON.stringify({ config }),
  })
}

export async function updateMachine(machineId: string, config: FSMConfig): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(`/api/v1/machines/${encodeURIComponent(machineId)}`, {
    method: 'PUT',
    body: JSON.stringify({ config }),
  })
}

export async function getMachine(machineId: string): Promise<MachineResponse> {
  return fetchApi<MachineResponse>(`/api/v1/machines/${encodeURIComponent(machineId)}`)
}

export async function deleteMachine(machineId: string): Promise<void> {
  await fetchApi<void>(`/api/v1/machines/${encodeURIComponent(machineId)}`, {
    method: 'DELETE',
  })
}

// ---- Entity types ----

/** Entity state from GET /api/v1/entities/{id}/state or list */
export interface EntityState {
  entity_id: string
  current_state: string
  machine_name: string | null
  context: Record<string, unknown>
  updated_at: string | null
  created_at: string | null
}

/** Paginated entity list */
export interface EntityListResponse {
  entities: EntityState[]
  total: number
  limit: number
  offset: number
}

/** Request body for POST /api/v1/entities/{id}/events */
export interface ProcessEntityEventRequest {
  trigger: string
  context?: Record<string, unknown>
  machine_name?: string
  machine_version?: string
}

/** Response from POST /api/v1/entities/{id}/events */
export interface ProcessEntityEventResponse {
  success: boolean
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  actions: string[]
  error: string | null
  transition_id: string | null
}

/** Single transition history entry */
export interface TransitionHistoryEntry {
  id: string
  entity_id: string
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  created_at: string
  duration_ms?: number | null
}

// ---- Observability types ----

export interface ObservabilitySummaryResponse {
  window_start: string
  window_end: string
  active_entities: number
  transitions_total: number
  transitions_failed: number
  transition_failure_rate: number
  p95_transition_duration_ms: number | null
  worker_pending: number
  worker_claimed: number
  worker_failed: number
  worker_dead_letter: number
}

export interface ObservabilityTransitionItem {
  id: string
  entity_id: string
  machine_name: string | null
  source_state: string
  target_state: string | null
  trigger: string
  success: boolean
  error_message: string | null
  actions_executed: string[] | null
  duration_ms: number | null
  created_at: string
}

export interface ObservabilityTransitionsResponse {
  items: ObservabilityTransitionItem[]
  total: number
  limit: number
  offset: number
}

export interface ObservabilityWorkerEventItem {
  id: string
  machine_name: string
  entity_id: string
  trigger: string
  status: 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  attempt: number
  max_attempts: number
  error_message: string | null
  fires_at: string
  claimed_by: string | null
  claimed_at: string | null
  created_at: string | null
  completed_at: string | null
  result_json: Record<string, unknown> | null
  transition_history_id: string | null
}

export interface ObservabilityWorkerEventsResponse {
  items: ObservabilityWorkerEventItem[]
  total: number
  limit: number
  offset: number
}

// ---- Entity functions ----

export async function listEntities(params?: {
  machine_name?: string
  state?: string
  limit?: number
  offset?: number
}): Promise<EntityListResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.state) qs.set('state', params.state)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return fetchApi<EntityListResponse>(`/api/v1/entities${query ? `?${query}` : ''}`)
}

export async function getEntityState(entityId: string): Promise<EntityState> {
  return fetchApi<EntityState>(`/api/v1/entities/${encodeURIComponent(entityId)}/state`)
}

export async function processEntityEvent(
  entityId: string,
  body: ProcessEntityEventRequest
): Promise<ProcessEntityEventResponse> {
  return fetchApi<ProcessEntityEventResponse>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/events`,
    { method: 'POST', body: JSON.stringify(body) }
  )
}

export async function getEntityHistory(
  entityId: string,
  limit = 50,
  offset = 0
): Promise<TransitionHistoryEntry[]> {
  return fetchApi<TransitionHistoryEntry[]>(
    `/api/v1/entities/${encodeURIComponent(entityId)}/history?limit=${limit}&offset=${offset}`
  )
}

export async function deleteEntity(entityId: string): Promise<void> {
  await fetchApi<void>(`/api/v1/entities/${encodeURIComponent(entityId)}`, {
    method: 'DELETE',
  })
}

// ---- Observability ----

export async function getObservabilitySummary(params?: {
  window_hours?: number
  machine_name?: string
  entity_id?: string
}): Promise<ObservabilitySummaryResponse> {
  const qs = new URLSearchParams()
  if (params?.window_hours != null) qs.set('window_hours', String(params.window_hours))
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  const query = qs.toString()
  return fetchApi<ObservabilitySummaryResponse>(
    `/api/v1/observability/summary${query ? `?${query}` : ''}`
  )
}

export async function listObservabilityTransitions(params?: {
  machine_name?: string
  entity_id?: string
  status?: 'all' | 'success' | 'failed'
  start_at?: string
  end_at?: string
  limit?: number
  offset?: number
}): Promise<ObservabilityTransitionsResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  if (params?.status) qs.set('status', params.status)
  if (params?.start_at) qs.set('start_at', params.start_at)
  if (params?.end_at) qs.set('end_at', params.end_at)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return fetchApi<ObservabilityTransitionsResponse>(
    `/api/v1/observability/transitions${query ? `?${query}` : ''}`
  )
}

export async function listObservabilityWorkerEvents(params?: {
  machine_name?: string
  entity_id?: string
  status?: 'all' | 'pending' | 'claimed' | 'completed' | 'failed' | 'dead_letter'
  start_at?: string
  end_at?: string
  limit?: number
  offset?: number
}): Promise<ObservabilityWorkerEventsResponse> {
  const qs = new URLSearchParams()
  if (params?.machine_name) qs.set('machine_name', params.machine_name)
  if (params?.entity_id) qs.set('entity_id', params.entity_id)
  if (params?.status) qs.set('status', params.status)
  if (params?.start_at) qs.set('start_at', params.start_at)
  if (params?.end_at) qs.set('end_at', params.end_at)
  if (params?.limit != null) qs.set('limit', String(params.limit))
  if (params?.offset != null) qs.set('offset', String(params.offset))
  const query = qs.toString()
  return fetchApi<ObservabilityWorkerEventsResponse>(
    `/api/v1/observability/worker-events${query ? `?${query}` : ''}`
  )
}

// ---- Templates ----

/** FSM templates: list and get content (YAML text) */
export interface FsmTemplatesListResponse {
  templates: string[]
}

export async function listFsmTemplates(): Promise<FsmTemplatesListResponse> {
  return fetchApi<FsmTemplatesListResponse>('/api/v1/templates/fsm')
}

/** Fetch FSM template content as YAML text (parse in UI with js-yaml). */
export async function getFsmTemplate(filename: string): Promise<string> {
  const name = filename.endsWith('.yaml') || filename.endsWith('.yml') ? filename : `${filename}.yaml`
  const url = `${getApiBaseUrl()}/api/v1/templates/fsm/${encodeURIComponent(name)}`
  const response = await fetch(url, { headers: authHeaders() })
  if (response.status === 401) {
    handleUnauthorized()
  }
  if (!response.ok) {
    let detail: unknown
    try {
      detail = await response.json()
    } catch {
      detail = { detail: response.statusText }
    }
    const msg = typeof (detail as { detail?: string }).detail === 'string'
      ? (detail as { detail: string }).detail
      : (detail as { error?: string }).error ?? `Request failed: ${response.status}`
    throw new ApiError(msg, response.status, detail)
  }
  return response.text()
}

/** Download all FSM templates as a ZIP file. */
export async function downloadFsmTemplatesZip(): Promise<Blob> {
  return getBlob('/api/v1/templates/fsm/zip')
}
