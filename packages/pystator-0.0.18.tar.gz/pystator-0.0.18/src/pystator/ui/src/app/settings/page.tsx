'use client'

import { useState } from 'react'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Button } from '@/components/ui/button'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { getSettings, saveSettings, type AppSettings } from '@/lib/settings'
import { ApiServerCard, DatabaseConfigCard } from '@/components/settings'
import { Loader2 } from 'lucide-react'
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config'

export default function SettingsPage() {
  const appName = useAppConfigStore(selectAppName)
  const version = useAppConfigStore(selectVersion)
  const [settings, setSettings] = useState<AppSettings>(getSettings())
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)

  const handleSave = () => {
    setSaving(true)
    setMessage(null)
    try {
      saveSettings(settings)
      setMessage({ type: 'success', text: 'Settings saved.' })
      setTimeout(() => window.location.reload(), 1000)
    } catch (e) {
      setMessage({ type: 'error', text: String(e) })
    } finally {
      setSaving(false)
    }
  }

  return (
    <PageContainer>
      <PageHeader
        title="Settings"
        description={version ? `Configure ${appName} API URL and database connection (${version})` : `Configure ${appName} API URL and database connection`}
      />

      {message && (
        <Alert className={`mt-4 ${message.type === 'success' ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
          <AlertDescription className={message.type === 'success' ? 'text-green-800' : 'text-red-800'}>
            {message.text}
          </AlertDescription>
        </Alert>
      )}

      <div className="mt-8 space-y-6">
        <ApiServerCard
          url={settings.apiServer.url}
          onUrlChange={(url) => setSettings((s) => ({ ...s, apiServer: { ...s.apiServer, url } }))}
        />
        <DatabaseConfigCard
          connectionString={settings.database.connectionString ?? ''}
          host={settings.database.host ?? ''}
          port={settings.database.port != null ? String(settings.database.port) : ''}
          database={settings.database.database ?? ''}
          username={settings.database.username ?? ''}
          password={settings.database.password ?? ''}
          onConnectionStringChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, connectionString: v || undefined } }))
          }
          onHostChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, host: v || undefined } }))
          }
          onPortChange={(v) =>
            setSettings((s) => ({
              ...s,
              database: { ...s.database, port: v ? parseInt(v, 10) : undefined },
            }))
          }
          onDatabaseChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, database: v || undefined } }))
          }
          onUsernameChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, username: v || undefined } }))
          }
          onPasswordChange={(v) =>
            setSettings((s) => ({ ...s, database: { ...s.database, password: v || undefined } }))
          }
        />
      </div>

      <div className="flex justify-end mt-6">
        <Button onClick={handleSave} disabled={saving} size="lg">
          {saving ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            'Save Settings'
          )}
        </Button>
      </div>
    </PageContainer>
  )
}
