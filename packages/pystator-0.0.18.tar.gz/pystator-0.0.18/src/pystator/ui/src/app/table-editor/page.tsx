'use client'

import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import {
  StateTable,
  VariableTable,
  TransitionMatrix,
  TransitionList,
  StateVariableMatrix,
  EventTable,
  ActionGuardTable,
  ErrorPolicyForm,
} from '@/components/table-editor'
import {
  listMachines,
  getMachine,
  createMachine,
  updateMachine,
  ApiError,
} from '@/lib/api'
import type { MachineListItem } from '@/lib/api'
import type { FSMConfig } from '@/lib/types/fsm'
import { parseFsmConfig, stringifyFsmConfig } from '@/lib/fsmConfigParse'
import MachineSaveModal from '@/components/machines/MachineSaveModal'
import {
  Save,
  Download,
  Upload,
  RefreshCw,
  CheckCircle2,
} from 'lucide-react'

// ---------------------------------------------------------------------------
// Tab definitions
// ---------------------------------------------------------------------------

type TabId =
  | 'states'
  | 'variables'
  | 'transition_matrix'
  | 'transition_list'
  | 'state_variables'
  | 'events'
  | 'actions_guards'
  | 'error_policy'

const TABS: { id: TabId; label: string; group: string }[] = [
  { id: 'states', label: 'States', group: 'Definition' },
  { id: 'variables', label: 'Variables', group: 'Definition' },
  { id: 'transition_matrix', label: 'Transition matrix', group: 'Transitions' },
  { id: 'transition_list', label: 'Transition list', group: 'Transitions' },
  { id: 'state_variables', label: 'State × Variables', group: 'Constraints' },
  { id: 'events', label: 'Events', group: 'Catalog' },
  { id: 'actions_guards', label: 'Actions / Guards', group: 'Catalog' },
  { id: 'error_policy', label: 'Error policy', group: 'Policy' },
]

// ---------------------------------------------------------------------------
// Default config
// ---------------------------------------------------------------------------

const DEFAULT_CONFIG: FSMConfig = {
  meta: { machine_name: 'my_fsm', version: '1.0.0' },
  states: [
    { name: 'start', type: 'initial' },
    { name: 'end', type: 'terminal' },
  ],
  transitions: [{ trigger: 'go', source: 'start', dest: 'end' }],
  state_variables: [],
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export default function TableEditorPage() {
  // Machine selector
  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [machinesLoading, setMachinesLoading] = useState(true)
  const [selectedMachineId, setSelectedMachineId] = useState<string>('')

  // Config state (source of truth)
  const [config, setConfig] = useState<FSMConfig>(() => structuredClone(DEFAULT_CONFIG))
  const [loadingConfig, setLoadingConfig] = useState(false)
  const [dirty, setDirty] = useState(false)

  // Save state
  const [saving, setSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null)
  const [error, setError] = useState<Error | null>(null)
  const [saveModalOpen, setSaveModalOpen] = useState(false)

  // Tabs
  const [activeTab, setActiveTab] = useState<TabId>('states')

  // File input ref for YAML import
  const fileInputRef = useRef<HTMLInputElement>(null)

  // -----------------------------------------------------------------------
  // Fetch machine list
  // -----------------------------------------------------------------------

  const fetchMachines = useCallback(async () => {
    setMachinesLoading(true)
    try {
      const res = await listMachines()
      setMachines(res.machines ?? [])
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setMachinesLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchMachines()
  }, [fetchMachines])

  // -----------------------------------------------------------------------
  // Load machine config
  // -----------------------------------------------------------------------

  const loadMachine = useCallback(
    async (machineId: string) => {
      if (!machineId) {
        setConfig(structuredClone(DEFAULT_CONFIG))
        setDirty(false)
        return
      }
      setLoadingConfig(true)
      setError(null)
      try {
        const res = await getMachine(machineId)
        setConfig(structuredClone(res.config))
        setDirty(false)
      } catch (e) {
        setError(e instanceof Error ? e : new Error(String(e)))
      } finally {
        setLoadingConfig(false)
      }
    },
    [],
  )

  const handleMachineChange = useCallback(
    (id: string) => {
      if (dirty && !window.confirm('You have unsaved changes. Discard them?')) return
      setSelectedMachineId(id)
      loadMachine(id)
    },
    [dirty, loadMachine],
  )

  // -----------------------------------------------------------------------
  // Config update helper -- wraps setConfig to track dirty
  // -----------------------------------------------------------------------

  const updateConfig = useCallback(
    (updater: (c: FSMConfig) => FSMConfig) => {
      setConfig((prev) => updater(prev))
      setDirty(true)
      setSaveMessage(null)
    },
    [],
  )

  // -----------------------------------------------------------------------
  // Save
  // -----------------------------------------------------------------------

  const handleSaveClick = useCallback(() => {
    setSaveMessage(null)
    setSaveModalOpen(true)
  }, [])

  const handleModalSave = useCallback(async (name: string, version: string) => {
    setSaving(true)
    setSaveMessage(null)
    try {
      // Inject chosen name + version into config.meta
      const configToSave: FSMConfig = {
        ...config,
        meta: { ...config.meta, machine_name: name, version },
      }
      const { machines: allMachines } = await listMachines()
      const existing = allMachines.find(
        (m) => m.name === name && m.version === version,
      )
      if (existing) {
        await updateMachine(existing.id, configToSave)
        setSelectedMachineId(existing.id)
        setSaveMessage({ type: 'success', text: 'Machine updated.' })
      } else {
        const created = await createMachine(configToSave)
        setSelectedMachineId(created.id)
        setSaveMessage({ type: 'success', text: 'Machine created.' })
      }
      // Update local config to reflect the saved name/version
      setConfig((prev) => ({
        ...prev,
        meta: { ...prev.meta, machine_name: name, version },
      }))
      setDirty(false)
      setSaveModalOpen(false)
      fetchMachines()
      setTimeout(() => setSaveMessage(null), 4000)
    } catch (e) {
      const msg =
        e instanceof ApiError ? e.message : e instanceof Error ? e.message : 'Save failed.'
      // Re-throw so the modal can display the error inline
      throw new Error(msg)
    } finally {
      setSaving(false)
    }
  }, [config, fetchMachines])

  // -----------------------------------------------------------------------
  // YAML import / export
  // -----------------------------------------------------------------------

  const handleImportYaml = useCallback(() => {
    fileInputRef.current?.click()
  }, [])

  const handleFileSelected = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (!file) return
      const reader = new FileReader()
      reader.onload = () => {
        const text = reader.result as string
        const result = parseFsmConfig(text, file.name.endsWith('.json') ? 'json' : 'yaml')
        if ('error' in result) {
          setError(new Error(`Import failed: ${result.error}`))
        } else {
          if (dirty && !window.confirm('Replace current config? Unsaved changes will be lost.'))
            return
          setConfig(structuredClone(result.config))
          setSelectedMachineId('')
          setDirty(true)
        }
        // Reset file input so same file can be re-selected
        if (fileInputRef.current) fileInputRef.current.value = ''
      }
      reader.readAsText(file)
    },
    [dirty],
  )

  const handleExportYaml = useCallback(() => {
    const yamlText = stringifyFsmConfig(config, 'yaml')
    const blob = new Blob([yamlText], { type: 'application/x-yaml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${config.meta?.machine_name ?? 'fsm'}_${config.meta?.version ?? '1.0.0'}.yaml`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [config])

  // -----------------------------------------------------------------------
  // Derived data
  // -----------------------------------------------------------------------

  const stateNames = useMemo(
    () => (config.states ?? []).map((s) => s.name),
    [config.states],
  )

  const variableKeys = useMemo(
    () => (config.state_variables ?? []).map((v) => v.key),
    [config.state_variables],
  )

  // -----------------------------------------------------------------------
  // Render
  // -----------------------------------------------------------------------

  return (
    <PageContainer>
      <PageHeader
        title="Table Editor"
        description="Design and inspect FSM configurations using structured tables"
        actions={
          <div className="flex items-center gap-2 flex-wrap">
            {/* Machine selector */}
            <select
              className="h-9 rounded-md border border-input bg-background px-3 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
              value={selectedMachineId}
              onChange={(e) => handleMachineChange(e.target.value)}
              disabled={machinesLoading}
            >
              <option value="">New machine</option>
              {machines.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} v{m.version}
                </option>
              ))}
            </select>

            <Button
              variant="outline"
              size="sm"
              onClick={fetchMachines}
              disabled={machinesLoading}
              className="gap-1.5"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${machinesLoading ? 'animate-spin' : ''}`} />
            </Button>

            <div className="h-5 border-l border-border" />

            {/* YAML import */}
            <Button variant="outline" size="sm" onClick={handleImportYaml} className="gap-1.5">
              <Upload className="h-3.5 w-3.5" />
              Import YAML
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept=".yaml,.yml,.json"
              className="hidden"
              onChange={handleFileSelected}
            />

            {/* YAML export */}
            <Button variant="outline" size="sm" onClick={handleExportYaml} className="gap-1.5">
              <Download className="h-3.5 w-3.5" />
              Export YAML
            </Button>

            <div className="h-5 border-l border-border" />

            {/* Save */}
            <Button
              size="sm"
              onClick={handleSaveClick}
              disabled={saving}
              className="gap-1.5"
            >
              <Save className="h-3.5 w-3.5" />
              {saving ? 'Saving...' : 'Save'}
            </Button>
          </div>
        }
      />

      {error && <ErrorDisplay error={error} className="mt-2 mb-4" />}

      {saveMessage && (
        <div
          className={`mt-2 mb-4 flex items-center gap-2 p-3 rounded-md text-sm ${
            saveMessage.type === 'success'
              ? 'bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 text-green-800 dark:text-green-200'
              : 'bg-destructive/10 border border-destructive/50 text-destructive'
          }`}
        >
          {saveMessage.type === 'success' && (
            <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400 flex-shrink-0" />
          )}
          {saveMessage.text}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 mt-4 mb-4 border-b overflow-x-auto">
        {TABS.map(({ id, label }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id)}
            className={`px-3 py-2 text-sm font-medium border-b-2 whitespace-nowrap transition-colors ${
              activeTab === id
                ? 'border-primary text-primary'
                : 'border-transparent text-muted-foreground hover:text-foreground'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Content */}
      {loadingConfig ? (
        <div className="flex justify-center py-12">
          <LoadingSpinner />
        </div>
      ) : (
        <div className="pb-12">
          {activeTab === 'states' && (
            <StateTable
              states={config.states ?? []}
              allStateNames={stateNames}
              onChange={(states) => updateConfig((c) => ({ ...c, states }))}
            />
          )}

          {activeTab === 'variables' && (
            <VariableTable
              variables={config.state_variables ?? []}
              onChange={(state_variables) =>
                updateConfig((c) => ({ ...c, state_variables }))
              }
            />
          )}

          {activeTab === 'transition_matrix' && (
            <TransitionMatrix
              states={stateNames}
              transitions={config.transitions ?? []}
              onChange={(transitions) =>
                updateConfig((c) => ({ ...c, transitions }))
              }
            />
          )}

          {activeTab === 'transition_list' && (
            <TransitionList
              transitions={config.transitions ?? []}
              stateNames={stateNames}
              onChange={(transitions) =>
                updateConfig((c) => ({ ...c, transitions }))
              }
            />
          )}

          {activeTab === 'state_variables' && (
            <StateVariableMatrix
              states={stateNames}
              variables={variableKeys}
              constraints={config.state_variable_constraints ?? {}}
              onChange={(state_variable_constraints) =>
                updateConfig((c) => ({ ...c, state_variable_constraints }))
              }
            />
          )}

          {activeTab === 'events' && (
            <EventTable
              events={(config.events ?? []) as { name: string; description?: string; payload?: Record<string, unknown> }[]}
              onChange={(events) => updateConfig((c) => ({ ...c, events }))}
            />
          )}

          {activeTab === 'actions_guards' && (
            <ActionGuardTable
              actions={config.action_definitions ?? []}
              guards={config.guard_definitions ?? []}
              onActionsChange={(action_definitions) =>
                updateConfig((c) => ({ ...c, action_definitions }))
              }
              onGuardsChange={(guard_definitions) =>
                updateConfig((c) => ({ ...c, guard_definitions }))
              }
            />
          )}

          {activeTab === 'error_policy' && (
            <ErrorPolicyForm
              defaultFallback={config.error_policy?.default_fallback ?? ''}
              retryAttempts={config.error_policy?.retry_attempts ?? 0}
              stateNames={stateNames}
              onChange={(fallback, retries) =>
                updateConfig((c) => ({
                  ...c,
                  error_policy:
                    fallback || retries > 0
                      ? {
                          default_fallback: fallback || undefined,
                          retry_attempts: retries,
                        }
                      : undefined,
                }))
              }
            />
          )}
        </div>
      )}

      <MachineSaveModal
        isOpen={saveModalOpen}
        onClose={() => setSaveModalOpen(false)}
        onSave={handleModalSave}
        defaultName={config.meta?.machine_name ?? ''}
        defaultVersion={config.meta?.version ?? '1.0.0'}
      />
    </PageContainer>
  )
}
