'use client'

import { useCallback, useEffect, useState } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import EntityTable from '@/components/entities/EntityTable'
import EntityDetailView from '@/components/entities/EntityDetailView'
import CreateEntityModal from '@/components/entities/CreateEntityModal'
import { listEntities, listMachines, deleteEntity } from '@/lib/api'
import type { EntityState, MachineListItem } from '@/lib/api'
import { ROUTES, entityDetailUrl } from '@/lib/constants'
import { ChevronLeft, ChevronRight, Plus, RefreshCw, Search, X } from 'lucide-react'

const PAGE_SIZE = 25

export default function EntitiesPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const entityIdFromQuery = searchParams.get('entityId')
  const showDetail = Boolean(entityIdFromQuery?.trim())
  const entityId = (entityIdFromQuery ?? '').trim()
  const [entities, setEntities] = useState<EntityState[]>([])
  const [total, setTotal] = useState(0)
  const [offset, setOffset] = useState(0)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)

  // Filters
  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [filterMachine, setFilterMachine] = useState('')
  const [filterState, setFilterState] = useState('')
  const [createModalOpen, setCreateModalOpen] = useState(false)

  // Load machine list for filter dropdown
  useEffect(() => {
    listMachines()
      .then((res) => setMachines(res.machines))
      .catch(() => {}) // not critical
  }, [])

  const fetchEntities = useCallback(async (currentOffset: number) => {
    setLoading(true)
    setError(null)
    try {
      const params: { machine_name?: string; state?: string; limit: number; offset: number } = {
        limit: PAGE_SIZE,
        offset: currentOffset,
      }
      if (filterMachine) params.machine_name = filterMachine
      if (filterState.trim()) params.state = filterState.trim()
      const res = await listEntities(params)
      setEntities(res.entities)
      setTotal(res.total)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setLoading(false)
    }
  }, [filterMachine, filterState])

  useEffect(() => {
    fetchEntities(offset)
  }, [fetchEntities, offset])

  const handleView = (entity: EntityState) => {
    router.push(entityDetailUrl(entity.entity_id))
  }

  const handleBackFromDetail = () => {
    router.push(ROUTES.ENTITIES)
  }

  const handleDelete = async (entity: EntityState) => {
    const confirmed = window.confirm(
      `Delete entity "${entity.entity_id}"? This will remove its state and history.`
    )
    if (!confirmed) return
    try {
      await deleteEntity(entity.entity_id)
      await fetchEntities(offset)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  const handleApplyFilter = () => {
    setOffset(0)
    fetchEntities(0)
  }

  const handleClearFilter = () => {
    setFilterMachine('')
    setFilterState('')
    setOffset(0)
  }

  const handleCreateSuccess = useCallback(
    (createdEntityId: string) => {
      router.push(entityDetailUrl(createdEntityId))
      fetchEntities(0)
    },
    [router, fetchEntities]
  )

  const hasPrev = offset > 0
  const hasNext = offset + PAGE_SIZE < total

  if (showDetail && entityId) {
    return (
      <EntityDetailView entityId={entityId} onBack={handleBackFromDetail} />
    )
  }

  return (
    <PageContainer>
      <PageHeader
        title="Entities"
        description="Runtime entity state and transition history"
        actions={
          <div className="flex gap-2">
            <Button variant="default" size="sm" onClick={() => setCreateModalOpen(true)} className="gap-1.5">
              <Plus className="h-4 w-4" /> Create entity
            </Button>
            <Button variant="outline" size="sm" onClick={() => fetchEntities(offset)} disabled={loading} className="gap-1.5">
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        }
      />

      {/* Filter bar */}
      <div className="mt-4 flex flex-wrap items-end gap-3 rounded-lg border bg-muted/30 p-3">
        <div className="flex flex-col gap-1">
          <Label className="text-xs text-muted-foreground">Machine</Label>
          <select
            className="rounded-md border border-input bg-background px-2 py-1.5 text-sm min-w-[180px]"
            value={filterMachine}
            onChange={(e) => setFilterMachine(e.target.value)}
          >
            <option value="">All machines</option>
            {machines.map((m) => (
              <option key={m.id} value={m.name}>{m.name}</option>
            ))}
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <Label className="text-xs text-muted-foreground">State</Label>
          <input
            type="text"
            placeholder="e.g. pending"
            className="rounded-md border border-input bg-background px-2 py-1.5 text-sm w-[160px]"
            value={filterState}
            onChange={(e) => setFilterState(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter') handleApplyFilter() }}
          />
        </div>
        <Button variant="outline" size="sm" onClick={handleApplyFilter} className="gap-1.5">
          <Search className="h-3.5 w-3.5" /> Apply
        </Button>
        {(filterMachine || filterState) && (
          <Button variant="ghost" size="sm" onClick={handleClearFilter} className="gap-1.5">
            <X className="h-3.5 w-3.5" /> Clear
          </Button>
        )}
      </div>

      {error && <ErrorDisplay error={error} className="mt-4" />}

      <div className="mt-6">
        {loading && entities.length === 0 ? (
          <div className="flex justify-center py-12">
            <LoadingSpinner />
          </div>
        ) : entities.length === 0 && !loading ? (
          <Card>
            <CardHeader>
              <CardTitle className="text-base">No entities found</CardTitle>
              <CardDescription>
                Create an entity with the button above, or send events via the Entity API.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" size="sm" onClick={() => setCreateModalOpen(true)} className="gap-1.5">
                <Plus className="h-4 w-4" /> Create entity
              </Button>
            </CardContent>
          </Card>
        ) : (
          <>
            <EntityTable entities={entities} onView={handleView} onDelete={handleDelete} />
            {/* Pagination */}
            <div className="flex items-center justify-between mt-4">
              <p className="text-sm text-muted-foreground">
                Showing {offset + 1}–{Math.min(offset + PAGE_SIZE, total)} of {total}
              </p>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" disabled={!hasPrev} onClick={() => setOffset((o) => Math.max(0, o - PAGE_SIZE))}>
                  <ChevronLeft className="h-4 w-4 mr-1" /> Prev
                </Button>
                <Button variant="outline" size="sm" disabled={!hasNext} onClick={() => setOffset((o) => o + PAGE_SIZE)}>
                  Next <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </div>
          </>
        )}
      </div>

      <CreateEntityModal
        open={createModalOpen}
        onOpenChange={setCreateModalOpen}
        onSuccess={handleCreateSuccess}
      />
    </PageContainer>
  )
}
