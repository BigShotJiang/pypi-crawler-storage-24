'use client'

import { useState, useEffect, useCallback, useRef, useMemo } from 'react'
import { ResizableWorkspaceLayout } from '@/components/layout'
import {
  useWorkspaceStore,
  selectConfig,
  selectSetConfig,
  selectSyncSessionFromConfig,
  selectLastTransition,
  selectDiagramShowGuards,
  selectDiagramShowActions,
  selectDiagramHighlightState,
  selectDiagramHighlightTransition,
  selectPastLength,
  selectFutureLength,
  selectUndo,
  selectRedo,
  selectClearConfig,
} from '@/stores/workspace'
import { useToastStore } from '@/stores/toast'
import { WorkspaceConfigSidebar } from '@/components/workspace'
import { FsmFlowDiagram, DiagramToolbar, DiagramContextMenu } from '@/components/fsm-flow'
import type { DiagramContextMenuProps } from '@/components/fsm-flow'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { listMachines, getMachine } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'
import { parseFsmConfig, stringifyFsmConfig } from '@/lib/fsmConfigParse'
import { makeBlankState, makeBlankTransition } from '@/lib/workspaceDefaults'
import { buildRequestLifecycleTemplate, buildToggleTemplate } from '@/lib/workspaceTemplates'
import { useWorkspaceSave, useToolbarCompression } from '@/hooks'
import MachineSaveModal from '@/components/machines/MachineSaveModal'
import { StateModal } from '@/components/modals/StateModal'
import { TransitionModal } from '@/components/modals/TransitionModal'
import { Save, Download, Loader2, Undo2, Redo2, RotateCcw, Ellipsis, ChevronDown, Check } from 'lucide-react'
import type { FSMState, FSMTransition, FSMConfig } from '@/lib/types/fsm'
import type {
  StatePaletteBlockId,
  TemplatePaletteId,
  TransitionPaletteBlockId,
} from '@/components/workspace/paletteDefs'

function WorkspaceContent() {
  const config = useWorkspaceStore(selectConfig)
  const setConfig = useWorkspaceStore(selectSetConfig)
  const syncSessionFromConfig = useWorkspaceStore(selectSyncSessionFromConfig)
  const lastTransition = useWorkspaceStore(selectLastTransition)
  const diagramShowGuards = useWorkspaceStore(selectDiagramShowGuards)
  const diagramShowActions = useWorkspaceStore(selectDiagramShowActions)
  const diagramHighlightState = useWorkspaceStore(selectDiagramHighlightState)
  const diagramHighlightTransition = useWorkspaceStore(selectDiagramHighlightTransition)
  const pastLength = useWorkspaceStore(selectPastLength)
  const futureLength = useWorkspaceStore(selectFutureLength)
  const undo = useWorkspaceStore(selectUndo)
  const redo = useWorkspaceStore(selectRedo)
  const clearConfig = useWorkspaceStore(selectClearConfig)
  const toast = useToastStore()
  const toolbarRef = useRef<HTMLDivElement>(null)
  const isToolbarCollapsed = useToolbarCompression(toolbarRef)
  const { status: saveStatus, save } = useWorkspaceSave(config)
  const lastSavedRef = useRef<string | null>(null)
  const prevSaveStatusRef = useRef(saveStatus)
  const [saveModalOpen, setSaveModalOpen] = useState(false)

  // Diagram-triggered modal state
  const [stateModalOpen, setStateModalOpen] = useState(false)
  const [stateModalMode, setStateModalMode] = useState<'add' | 'edit'>('add')
  const [stateModalData, setStateModalData] = useState<FSMState>(makeBlankState())
  const [transitionModalOpen, setTransitionModalOpen] = useState(false)
  const [transitionModalMode, setTransitionModalMode] = useState<'add' | 'edit'>('add')
  const [transitionModalData, setTransitionModalData] = useState<FSMTransition>(makeBlankTransition())
  const [editingTransitionIndex, setEditingTransitionIndex] = useState<number | null>(null)

  // Context menu state
  const [contextMenu, setContextMenu] = useState<DiagramContextMenuProps | null>(null)

  // Force re-layout counter (incrementing triggers useMemo recalculation via config identity change)
  const [, setRelayoutCounter] = useState(0)

  const isDirty =
    lastSavedRef.current !== null &&
    JSON.stringify(config) !== lastSavedRef.current

  useEffect(() => {
    const prev = prevSaveStatusRef.current
    prevSaveStatusRef.current = saveStatus
    if (saveStatus.type === 'success') {
      if (prev.type === 'loading') {
        toast.success(saveStatus.message)
        lastSavedRef.current = JSON.stringify(config)
      }
    } else if (saveStatus.type === 'error' && prev.type === 'loading') {
      toast.error(saveStatus.message)
    }
  }, [saveStatus, config, toast])

  const [machineList, setMachineList] = useState<MachineListItem[]>([])
  const [machinesLoading, setMachinesLoading] = useState(true)
  const [machineLoadError, setMachineLoadError] = useState<string | null>(null)
  const [loadingMachine, setLoadingMachine] = useState(false)
  const [selectedMachineName, setSelectedMachineName] = useState<string | null>(null)
  const [loadedMachineId, setLoadedMachineId] = useState<string | null>(null)

  const uniqueNames = useMemo(
    () => [...new Set(machineList.map((m) => m.name))].sort(),
    [machineList]
  )

  useEffect(() => {
    const machineId = sessionStorage.getItem('pystator_open_machine_id')
    if (!machineId) return
    sessionStorage.removeItem('pystator_open_machine_id')
    getMachine(machineId)
      .then((res) => {
        const next = JSON.parse(JSON.stringify(res.config))
        setConfig(next, { replaceHistory: true })
        lastSavedRef.current = JSON.stringify(next)
        syncSessionFromConfig()
      })
      .catch(() => {})
  }, [setConfig, syncSessionFromConfig])

  useEffect(() => {
    const yamlText = sessionStorage.getItem('pystator_load_template_yaml')
    if (!yamlText) return
    sessionStorage.removeItem('pystator_load_template_yaml')
    const result = parseFsmConfig(yamlText, 'yaml')
    if (!('error' in result)) {
      const next = JSON.parse(JSON.stringify(result.config))
      setConfig(next, { replaceHistory: true })
      lastSavedRef.current = JSON.stringify(next)
      syncSessionFromConfig()
    }
  }, [setConfig, syncSessionFromConfig])

  useEffect(() => {
    let cancelled = false
    listMachines()
      .then((res) => {
        if (!cancelled) setMachineList(res.machines ?? [])
      })
      .catch((err) => {
        if (!cancelled) setMachineLoadError(err instanceof Error ? err.message : 'Failed to load machines')
      })
      .finally(() => {
        if (!cancelled) setMachinesLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  // Sync Name/Version dropdowns from loaded config when machineList is available (e.g. after sessionStorage load)
  useEffect(() => {
    if (machineList.length === 0) return
    const name = config.meta?.machine_name
    const version = config.meta?.version
    if (name && version) {
      const m = machineList.find((x) => x.name === name && x.version === version)
      if (m) {
        setLoadedMachineId(m.id)
        setSelectedMachineName(name)
      }
    }
  }, [machineList, config.meta?.machine_name, config.meta?.version])

  // Undo / Redo keyboard shortcuts
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'z') {
        if (e.shiftKey) {
          e.preventDefault()
          redo()
        } else {
          e.preventDefault()
          undo()
        }
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [undo, redo])

  const loadMachine = useCallback(
    (machineId: string) => {
      if (!machineId) return
      setLoadingMachine(true)
      setMachineLoadError(null)
      getMachine(machineId)
        .then((res) => {
          const next = JSON.parse(JSON.stringify(res.config))
          setConfig(next, { replaceHistory: true })
          lastSavedRef.current = JSON.stringify(next)
          syncSessionFromConfig()
          setLoadedMachineId(machineId)
          const machine = machineList.find((m) => m.id === machineId)
          if (machine) setSelectedMachineName(machine.name)
        })
        .catch((err) => {
          setMachineLoadError(err instanceof Error ? err.message : 'Failed to load machine')
        })
        .finally(() => setLoadingMachine(false))
    },
    [setConfig, syncSessionFromConfig, machineList]
  )

  const onMachineNameSelect = useCallback(
    (name: string) => {
      setSelectedMachineName(name)
      const first = machineList.find((m) => m.name === name)
      if (first) loadMachine(first.id)
    },
    [machineList, loadMachine]
  )

  const handleCreateMachineFromScratch = useCallback(() => {
    clearConfig()
    setLoadedMachineId(null)
    setSelectedMachineName(null)
    lastSavedRef.current = null
  }, [clearConfig])

  const downloadCurrentConfig = useCallback(() => {
    const yamlText = stringifyFsmConfig(config, 'yaml')
    const name = (config?.meta?.machine_name ?? 'fsm_config').replace(/[^a-zA-Z0-9_.-]/g, '_')
    const filename = name.endsWith('.yaml') ? name : `${name}.yaml`
    const blob = new Blob([yamlText], { type: 'application/x-yaml' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = filename
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }, [config])

  const handleSaveClick = useCallback(() => {
    setSaveModalOpen(true)
  }, [])

  const handleModalSave = useCallback(async (name: string, version: string) => {
    await save(name, version)
    setConfig((prev) => ({
      ...prev,
      meta: { ...prev.meta, machine_name: name, version },
    }))
    setSaveModalOpen(false)
  }, [save, setConfig])

  // --- Diagram editing callbacks ---

  const stateNames = (config.states ?? []).map((s) => s.name)

  const regionNames = (config.states ?? []).flatMap((s) =>
    s.regions ? s.regions.map((r) => r.name) : []
  )

  const handleDiagramPaneDoubleClick = useCallback(
    (_position: { x: number; y: number }) => {
      setStateModalMode('add')
      setStateModalData(makeBlankState())
      setStateModalOpen(true)
    },
    []
  )

  const handleDiagramNodeDoubleClick = useCallback(
    (stateName: string) => {
      const existing = (config.states ?? []).find((s) => s.name === stateName)
      if (!existing) return
      setStateModalMode('edit')
      setStateModalData({ ...existing })
      setStateModalOpen(true)
    },
    [config.states]
  )

  const handleDiagramEdgeDoubleClick = useCallback(
    (transitionIndex: number) => {
      const existing = (config.transitions ?? [])[transitionIndex]
      if (!existing) return
      setTransitionModalMode('edit')
      setTransitionModalData({ ...existing })
      setEditingTransitionIndex(transitionIndex)
      setTransitionModalOpen(true)
    },
    [config.transitions]
  )

  const handleDiagramConnect = useCallback(
    (sourceName: string, destName: string) => {
      setTransitionModalMode('add')
      setTransitionModalData(makeBlankTransition(sourceName, destName))
      setEditingTransitionIndex(null)
      setTransitionModalOpen(true)
    },
    []
  )

  const handleDiagramNodesDelete = useCallback(
    (deletedNames: string[]) => {
      const initialStates = (config.states ?? [])
        .filter((s) => s.type === 'initial')
        .map((s) => s.name)

      const blocked = deletedNames.filter((n) => initialStates.includes(n))
      if (blocked.length > 0) {
        toast.error(`Cannot delete initial state: ${blocked.join(', ')}`)
        return
      }

      const deletedSet = new Set(deletedNames)

      // Also collect child states of deleted parent states
      for (const s of config.states ?? []) {
        if (s.parent && deletedSet.has(s.parent)) {
          deletedSet.add(s.name)
        }
      }

      setConfig((prev) => {
        const nextStates = (prev.states ?? []).filter((s) => !deletedSet.has(s.name))
        const nextTransitions = (prev.transitions ?? []).filter((t) => {
          const sources = Array.isArray(t.source) ? t.source : [t.source]
          return !sources.some((src) => deletedSet.has(src)) && !deletedSet.has(t.dest)
        })
        return { ...prev, states: nextStates, transitions: nextTransitions }
      })
    },
    [config.states, setConfig, toast]
  )

  const handleDiagramEdgesDelete = useCallback(
    (indices: number[]) => {
      const indexSet = new Set(indices)
      setConfig((prev) => ({
        ...prev,
        transitions: (prev.transitions ?? []).filter((_, i) => !indexSet.has(i)),
      }))
    },
    [setConfig]
  )

  const handleStateSave = useCallback(
    (state: FSMState) => {
      if (stateModalMode === 'add') {
        setConfig((prev) => ({
          ...prev,
          states: [...(prev.states ?? []), state],
        }))
      } else {
        // Edit mode: replace by original name
        const originalName = stateModalData.name
        setConfig((prev) => {
          const nextStates = (prev.states ?? []).map((s) =>
            s.name === originalName ? state : s
          )
          // Update references in transitions if name changed
          let nextTransitions = prev.transitions ?? []
          if (originalName !== state.name) {
            nextTransitions = nextTransitions.map((t) => {
              let source = t.source
              if (Array.isArray(source)) {
                source = source.map((s) => (s === originalName ? state.name : s))
              } else if (source === originalName) {
                source = state.name
              }
              const dest = t.dest === originalName ? state.name : t.dest
              return { ...t, source, dest }
            })
            // Update parent references
            nextStates.forEach((s, i) => {
              if (s.parent === originalName) {
                nextStates[i] = { ...s, parent: state.name }
              }
              if (s.initial_child === originalName) {
                nextStates[i] = { ...nextStates[i], initial_child: state.name }
              }
            })
          }
          return { ...prev, states: nextStates, transitions: nextTransitions }
        })
      }
    },
    [stateModalMode, stateModalData.name, setConfig]
  )

  const handleTransitionSave = useCallback(
    (transition: FSMTransition) => {
      if (transitionModalMode === 'add') {
        setConfig((prev) => ({
          ...prev,
          transitions: [...(prev.transitions ?? []), transition],
        }))
      } else if (editingTransitionIndex != null) {
        setConfig((prev) => ({
          ...prev,
          transitions: (prev.transitions ?? []).map((t, i) =>
            i === editingTransitionIndex ? transition : t
          ),
        }))
      }
    },
    [transitionModalMode, editingTransitionIndex, setConfig]
  )

  const handleToolbarAddState = useCallback(() => {
    setStateModalMode('add')
    setStateModalData(makeBlankState())
    setStateModalOpen(true)
  }, [])

  const handlePaletteStateSelect = useCallback((id: StatePaletteBlockId) => {
    const typeById: Record<StatePaletteBlockId, FSMState['type']> = {
      initial: 'initial',
      stable: 'stable',
      terminal: 'terminal',
      parallel: 'parallel',
    }
    setStateModalMode('add')
    setStateModalData({ ...makeBlankState(), type: typeById[id] })
    setStateModalOpen(true)
  }, [])

  const handlePaletteTransitionSelect = useCallback((id: TransitionPaletteBlockId) => {
    const sourceDefault = stateNames[0] ?? ''
    const destDefault = stateNames.find((n) => n !== sourceDefault) ?? sourceDefault

    const base = makeBlankTransition(sourceDefault, destDefault)
    const prefilled: FSMTransition =
      id === 'guarded'
        ? { ...base, guards: ['condition_ok'] }
        : id === 'action'
          ? { ...base, actions: ['perform_action'] }
          : id === 'delayed'
            ? { ...base, after: '1s' }
            : base

    setTransitionModalMode('add')
    setTransitionModalData(prefilled)
    setEditingTransitionIndex(null)
    setTransitionModalOpen(true)
  }, [stateNames])

  const handlePaletteTemplateApply = useCallback((id: TemplatePaletteId) => {
    const hasExistingContent =
      (config.states?.length ?? 0) > 0 ||
      (config.transitions?.length ?? 0) > 0 ||
      (config.state_variables?.length ?? 0) > 0

    if (hasExistingContent) {
      const confirmed = window.confirm(
        'Applying a template will replace the current machine config. Continue?'
      )
      if (!confirmed) return
    }

    const next = id === 'toggle_fsm'
      ? buildToggleTemplate()
      : buildRequestLifecycleTemplate()

    setConfig(JSON.parse(JSON.stringify(next)), { replaceHistory: true })
    syncSessionFromConfig()
    setLoadedMachineId(null)
    setSelectedMachineName(null)
    lastSavedRef.current = null
    toast.success('Template applied.')
  }, [config, setConfig, syncSessionFromConfig, toast])

  const handleRelayout = useCallback(() => {
    // Force re-layout by creating a new config identity
    setConfig((prev) => ({ ...prev }))
    setRelayoutCounter((c) => c + 1)
  }, [setConfig])

  const highlightTransition =
    diagramHighlightTransition ??
    (lastTransition
      ? {
          source: lastTransition.source_state,
          target: lastTransition.target_state,
          trigger: lastTransition.trigger,
        }
      : null)

  const versionsForSelectedName = useMemo(
    () => (selectedMachineName ? machineList.filter((m) => m.name === selectedMachineName) : []),
    [machineList, selectedMachineName]
  )

  return (
    <ResizableWorkspaceLayout
      groupId="workspace-layout"
      renderSidebar={(api) => (
        <WorkspaceConfigSidebar
          {...api}
          machineList={machineList}
          machinesLoading={machinesLoading}
          machineLoadError={machineLoadError}
          uniqueNames={uniqueNames}
          selectedMachineName={selectedMachineName}
          onMachineNameSelect={onMachineNameSelect}
          onCreateMachineFromScratch={handleCreateMachineFromScratch}
          onSelectStateBlock={handlePaletteStateSelect}
          onSelectTransitionBlock={handlePaletteTransitionSelect}
          onApplyTemplate={handlePaletteTemplateApply}
        />
      )}
    >
      <div className="absolute inset-0">
        <FsmFlowDiagram
          config={config}
          minHeight="100%"
          showGuards={diagramShowGuards}
          showActions={diagramShowActions}
          highlightState={diagramHighlightState}
          highlightTransition={highlightTransition}
          editable
          onPaneDoubleClick={handleDiagramPaneDoubleClick}
          onNodeDoubleClick={handleDiagramNodeDoubleClick}
          onEdgeDoubleClick={handleDiagramEdgeDoubleClick}
          onConnect={handleDiagramConnect}
          onNodesDelete={handleDiagramNodesDelete}
          onEdgesDelete={handleDiagramEdgesDelete}
        />
      </div>

      {/* Diagram editing toolbar */}
      <div className="absolute top-3 left-3 z-10">
        <DiagramToolbar
          onAddState={handleToolbarAddState}
          onRelayout={handleRelayout}
        />
      </div>

      {/* Machine load / save toolbar: Name + Version + Undo/Redo/Clear, with compression */}
      <div
        ref={toolbarRef}
        className="absolute top-3 right-3 z-10 flex flex-row items-center gap-2 rounded-lg border border-border bg-background/95 px-3 py-2 shadow-md backdrop-blur-sm"
      >
        {!isToolbarCollapsed ? (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  disabled={machinesLoading || loadingMachine || !selectedMachineName || versionsForSelectedName.length === 0}
                  className="h-7 gap-1 px-2 text-xs font-medium text-muted-foreground hover:text-foreground"
                  aria-label="Machine version"
                >
                  {loadingMachine ? (
                    <Loader2 className="h-3 w-3 animate-spin" />
                  ) : (
                    <>
                      v{versionsForSelectedName.find((m) => m.id === loadedMachineId)?.version ?? config.meta?.version ?? '—'}
                      {versionsForSelectedName.length > 1 && (
                        <ChevronDown className="h-3 w-3 opacity-60" />
                      )}
                    </>
                  )}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                <DropdownMenuLabel className="text-xs">
                  Versions{versionsForSelectedName.length === 0 ? '' : ` (${versionsForSelectedName.length})`}
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {versionsForSelectedName.length === 0 ? (
                  <DropdownMenuItem disabled className="text-muted-foreground">
                    Select a machine in Browse
                  </DropdownMenuItem>
                ) : (
                  versionsForSelectedName.map((m) => {
                    const isActive = m.id === loadedMachineId
                    return (
                      <DropdownMenuItem
                        key={m.id}
                        onClick={() => loadMachine(m.id)}
                        className="justify-between"
                      >
                        <span className={isActive ? 'font-medium' : ''}>v{m.version}</span>
                        {isActive && <Check className="h-3.5 w-3.5 text-primary" />}
                      </DropdownMenuItem>
                    )
                  })
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            {machineLoadError ? (
              <span className="text-xs text-destructive" title={machineLoadError}>
                {machineLoadError.length > 20 ? machineLoadError.slice(0, 20) + '...' : machineLoadError}
              </span>
            ) : null}
            <div className="h-5 border-l border-border" />
            <Button
              variant="ghost"
              size="sm"
              onClick={undo}
              disabled={pastLength === 0}
              className="shrink-0 p-2"
              title="Undo (Ctrl+Z)"
              aria-label="Undo"
            >
              <Undo2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={redo}
              disabled={futureLength === 0}
              className="shrink-0 p-2"
              title="Redo (Ctrl+Shift+Z)"
              aria-label="Redo"
            >
              <Redo2 className="h-4 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={clearConfig}
              className="h-7 px-2 text-xs text-muted-foreground hover:text-foreground shrink-0"
              title="Clear diagram"
              aria-label="Clear"
            >
              <RotateCcw className="mr-1.5 h-3.5 w-3.5" />
              Clear
            </Button>
            <div className="h-5 border-l border-border" />
            <Button
              variant="outline"
              size="sm"
              onClick={downloadCurrentConfig}
              className="shrink-0 p-2"
              title="Download as YAML"
              aria-label="Download as YAML"
            >
              <Download className="h-4 w-4" />
            </Button>
            <div className="relative inline-flex items-center">
              <Button
                variant="outline"
                size="sm"
                onClick={handleSaveClick}
                disabled={saveStatus.type === 'loading'}
                className="shrink-0 p-2"
                title="Save"
                aria-label={saveStatus.type === 'loading' ? 'Saving...' : 'Save'}
              >
                {saveStatus.type === 'loading' ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Save className="h-4 w-4" />
                )}
              </Button>
              {isDirty && (
                <span
                  className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-amber-500"
                  title="Unsaved changes"
                  aria-hidden
                />
              )}
            </div>
          </>
        ) : (
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="shrink-0 p-2" aria-label="More options">
                  <Ellipsis className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel className="text-xs">Version</DropdownMenuLabel>
                {versionsForSelectedName.length === 0 ? (
                  <DropdownMenuItem disabled className="text-muted-foreground text-xs">
                    Select a machine in Browse
                  </DropdownMenuItem>
                ) : (
                  versionsForSelectedName.map((m) => {
                    const isActive = m.id === loadedMachineId
                    return (
                      <DropdownMenuItem
                        key={m.id}
                        onClick={() => loadMachine(m.id)}
                        className="justify-between text-xs"
                      >
                        <span className={isActive ? 'font-medium' : ''}>v{m.version}</span>
                        {isActive && <Check className="h-3.5 w-3.5 text-primary" />}
                      </DropdownMenuItem>
                    )
                  })
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={undo} disabled={pastLength === 0}>
                  <Undo2 className="mr-2 h-4 w-4" />
                  Undo
                  <span className="ml-auto text-xs text-muted-foreground">Ctrl+Z</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={redo} disabled={futureLength === 0}>
                  <Redo2 className="mr-2 h-4 w-4" />
                  Redo
                  <span className="ml-auto text-xs text-muted-foreground">Ctrl+Shift+Z</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={clearConfig}>
                  <RotateCcw className="mr-2 h-4 w-4" />
                  Clear
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={downloadCurrentConfig}>
                  <Download className="mr-2 h-4 w-4" />
                  Download YAML
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleSaveClick}
                  disabled={saveStatus.type === 'loading'}
                >
                  {saveStatus.type === 'loading' ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Save className="mr-2 h-4 w-4" />
                  )}
                  Save
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {isDirty ? (
              <span className="flex items-center gap-1.5" title="Unsaved changes" role="status">
                <span
                  className="w-2 h-2 rounded-full bg-amber-500 shrink-0"
                  aria-hidden
                />
                <span className="text-xs text-amber-600 dark:text-amber-400">Unsaved</span>
              </span>
            ) : null}
          </>
        )}
      </div>

      {/* Context menu */}
      {contextMenu && (
        <DiagramContextMenu {...contextMenu} />
      )}

      {/* Machine save modal */}
      <MachineSaveModal
        isOpen={saveModalOpen}
        onClose={() => setSaveModalOpen(false)}
        onSave={handleModalSave}
        defaultName={config.meta?.machine_name ?? ''}
        defaultVersion={config.meta?.version ?? '1.0.0'}
      />

      {/* Diagram-triggered state modal (add/edit) */}
      <StateModal
        open={stateModalOpen}
        onOpenChange={setStateModalOpen}
        state={stateModalData}
        existingStateNames={stateNames}
        onSave={handleStateSave}
        title={stateModalMode === 'add' ? 'Add State' : 'Edit State'}
        description={
          stateModalMode === 'add'
            ? 'Add a new state to the machine.'
            : 'Edit the selected state.'
        }
      />

      {/* Diagram-triggered transition modal (add/edit) */}
      <TransitionModal
        open={transitionModalOpen}
        onOpenChange={setTransitionModalOpen}
        transition={transitionModalData}
        stateNames={stateNames}
        regionNames={regionNames}
        onSave={handleTransitionSave}
        title={transitionModalMode === 'add' ? 'Add Transition' : 'Edit Transition'}
        description={
          transitionModalMode === 'add'
            ? 'Add a new transition between states.'
            : 'Edit the selected transition.'
        }
      />
    </ResizableWorkspaceLayout>
  )
}

export default function WorkspacePage() {
  return <WorkspaceContent />
}
