'use client'

import { useState, useEffect } from 'react'
import { CollapsibleSidebar, type SidebarSection } from '@/components/sidebar'
import { ApiTester } from '@/components/documentation'
import { getApiBaseUrl } from '@/lib/settings'
import { getApiErrorMessage } from '@/lib/api'
import { DOCS_URL } from '@/lib/constants'
import LoadingSpinner from '@/components/LoadingSpinner'
import { BookOpen, ExternalLink } from 'lucide-react'
import type { ApiMethodDoc } from '@/data/apiMethods'

/** Response from GET /api/v1/docs/playground-routes */
interface PlaygroundRoute {
  path: string
  method: string
  summary: string
  tag: string
}

function routeToId(path: string, method: string): string {
  return `${method}-${path.replace(/[^a-zA-Z0-9/]/g, '_')}`
}

function routeToMethodDoc(r: PlaygroundRoute): ApiMethodDoc {
  const apiMethod =
    r.method === 'GET' || r.method === 'POST' || r.method === 'PUT' || r.method === 'DELETE'
      ? r.method
      : 'GET'
  return {
    id: routeToId(r.path, r.method),
    title: r.summary || r.path,
    description: '',
    method: `${r.method} ${r.path}`,
    apiEndpoint: r.path,
    apiMethod,
    exampleRequest: undefined,
    exampleCode: '',
  }
}

export default function DocumentationPage() {
  const [rawRoutes, setRawRoutes] = useState<PlaygroundRoute[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>('overview')
  const [selectedTag, setSelectedTag] = useState<string | null>(null)

  useEffect(() => {
    let cancelled = false
    const base = getApiBaseUrl()
    const url = `${base}/api/v1/docs/playground-routes`
    fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error(res.statusText)
        return res.json()
      })
      .then((data: { routes?: PlaygroundRoute[] }) => {
        if (cancelled) return
        const list = Array.isArray(data.routes) ? data.routes : []
        setRawRoutes(list)
        setError(null)
      })
      .catch((e) => {
        if (!cancelled) {
          setRawRoutes([])
          setError(getApiErrorMessage(e, 'Could not load routes. Check API connection.'))
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  const routes = rawRoutes.map(routeToMethodDoc)
  const byTag = rawRoutes.reduce<Record<string, PlaygroundRoute[]>>((acc, r) => {
    const tag = (r.tag || 'API').trim() || 'API'
    if (!acc[tag]) acc[tag] = []
    acc[tag].push(r)
    return acc
  }, {})
  const tags = Object.keys(byTag).sort()
  const sidebarSections: SidebarSection[] = [
    {
      id: 'overview',
      title: 'Overview',
      icon: BookOpen,
      items: [
        {
          id: 'overview',
          label: 'Overview & links',
          onClick: () => {
            setSelectedRouteId('overview')
            setSelectedTag(null)
          },
        },
      ],
    },
    ...tags.map((tag) => ({
      id: tag,
      title: tag,
      icon: BookOpen,
      items: byTag[tag].map((r) => {
        const m = routeToMethodDoc(r)
        return {
          id: m.id,
          label: m.title || m.apiEndpoint || m.id,
          onClick: () => {
            setSelectedRouteId(m.id)
            setSelectedTag(tag)
          },
        }
      }),
    })),
  ].map((s) => ({ ...s, items: s.items.map((item) => ({ ...item, onClick: item.onClick })) }))

  const selectedMethod = routes.find((m) => m.id === selectedRouteId) ?? routes[0]
  const showOverview = selectedRouteId === 'overview' || !selectedRouteId

  const handleSectionClick = (sectionId: string) => {
    if (sectionId === 'overview') {
      setSelectedRouteId('overview')
      setSelectedTag(null)
      return
    }
    const firstInSection = byTag[sectionId]?.[0]
    if (firstInSection) {
      setSelectedRouteId(routeToId(firstInSection.path, firstInSection.method))
      setSelectedTag(sectionId)
    }
  }

  const swaggerUrl = `${getApiBaseUrl()}/docs`

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <LoadingSpinner />
      </div>
    )
  }

  return (
    <div
      className="flex h-full bg-background"
      style={{ height: 'calc(100vh - 4rem)', overflow: 'hidden' }}
    >
      <div className="flex-shrink-0" style={{ height: '100%', overflow: 'hidden' }}>
        <CollapsibleSidebar
          sections={sidebarSections}
          defaultCollapsed={false}
          headerTitle="API Playground"
          selectedSection={selectedTag ?? 'overview'}
          onSectionClick={handleSectionClick}
        />
      </div>

      <div
        className="flex-1 min-w-0"
        style={{ height: '100%', overflowY: 'auto', overflowX: 'hidden' }}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {error && (
            <div className="mb-4 p-4 border border-destructive/50 rounded-lg bg-destructive/10 text-destructive text-sm">
              {error}
            </div>
          )}

          <div className="space-y-8">
            {showOverview && (
              <div id="section-overview" className="scroll-mt-4 space-y-6">
                <h2 className="text-2xl font-bold text-foreground">Overview</h2>
                <p className="text-sm text-muted-foreground">
                  Use this page to try REST API endpoints. For full Python API and guides, use the
                  links below.
                </p>

                <div className="border rounded-lg p-5 bg-muted/30 space-y-4">
                  <h3 className="text-lg font-semibold text-foreground">Documentation</h3>
                  <ul className="text-sm space-y-2">
                    <li>
                      <a
                        href={DOCS_URL}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline inline-flex items-center gap-1"
                      >
                        Full documentation (MkDocs) <ExternalLink className="h-3 w-3" />
                      </a>
                      {' — Python API reference, guides, tutorials.'}
                    </li>
                    <li>
                      <a
                        href={swaggerUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-primary hover:underline inline-flex items-center gap-1"
                      >
                        REST API (Swagger) <ExternalLink className="h-3 w-3" />
                      </a>
                      {' — Interactive OpenAPI docs (when API is running).'}
                    </li>
                  </ul>
                </div>

                <div className="border rounded-lg p-4 bg-primary/5">
                  <h4 className="font-semibold mb-2">API Playground</h4>
                  <p className="text-sm text-muted-foreground">
                    Select an endpoint from the sidebar to send requests. Path parameters (e.g.{' '}
                    <code className="bg-muted px-1 rounded">machine_id</code>,{' '}
                    <code className="bg-muted px-1 rounded">entity_id</code>) are replaced with
                    placeholders for testing. Configure API URL in Settings.
                  </p>
                </div>
              </div>
            )}

            {!showOverview && selectedMethod && (
              <div className="space-y-6">
                <div
                  id={`method-${selectedMethod.id}`}
                  className="border rounded-lg overflow-hidden scroll-mt-4"
                >
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 p-4">
                    <div>
                      <h4 className="font-semibold mb-2">{selectedMethod.title}</h4>
                      {selectedMethod.description && (
                        <p className="text-sm text-muted-foreground mb-3">
                          {selectedMethod.description}
                        </p>
                      )}
                      <div className="text-xs text-muted-foreground">
                        <span className="font-semibold">Endpoint:</span> {selectedMethod.method}
                      </div>
                    </div>
                    <div>
                      <ApiTester method={selectedMethod} />
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="border rounded-lg p-4 bg-muted/30">
              <h4 className="font-semibold mb-2">Resources</h4>
              <ul className="text-sm space-y-1 text-muted-foreground">
                <li>
                  <a href={DOCS_URL} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                    Full docs (MkDocs)
                  </a>
                </li>
                <li>
                  <a href={swaggerUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">
                    Swagger UI (when API running)
                  </a>
                </li>
                <li>Configure API URL in Settings (top right)</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
