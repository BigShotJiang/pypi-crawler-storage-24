'use client'

import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { ROUTES } from '@/lib/constants'
import { GitBranch, Layers, Database, Activity } from 'lucide-react'
import { useAppConfigStore, selectAppName, selectVersion } from '@/stores/app-config'

export default function Home() {
  const appName = useAppConfigStore(selectAppName)
  const version = useAppConfigStore(selectVersion)
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
              {appName}
            </h1>
            <p className="mt-6 text-lg leading-8 text-muted-foreground max-w-2xl mx-auto">
              Configuration-driven FSM builder. Define states and transitions, persist machines, track entity state, and visualize flows.
              {version ? (
                <span className="block mt-2 text-sm font-medium text-muted-foreground/90">
                  Release {version}
                </span>
              ) : null}
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-6">
              <Link href={ROUTES.WORKSPACE}>
                <Button size="lg">Get Started</Button>
              </Link>
              <Link href={ROUTES.MACHINES}>
                <Button variant="outline" size="lg">Browse Machines</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <Layers className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Workspace</CardTitle>
              <CardDescription>
                Design your FSM: meta, states, transitions. Edit JSON or YAML, validate, run tests, and save to the database.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href={ROUTES.WORKSPACE}>
                <Button variant="outline" className="w-full">
                  Open Workspace
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Database className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Machines</CardTitle>
              <CardDescription>
                Browse and manage stored FSM definitions. Open any machine in the Workspace to edit or test it.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href={ROUTES.MACHINES}>
                <Button variant="outline" className="w-full">
                  Browse Machines
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <Activity className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Entities</CardTitle>
              <CardDescription>
                View runtime entity state, send events, and inspect the full transition history for any entity.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Link href={ROUTES.ENTITIES}>
                <Button variant="outline" className="w-full">
                  View Entities
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
