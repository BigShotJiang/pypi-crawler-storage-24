export interface ApiMethodArgument {
  name: string
  type: string
  description: string
  required?: boolean
  default?: string
}

export interface ApiMethodReturn {
  type: string
  description: string
}

export interface ApiMethodDoc {
  id: string
  title: string
  description: string
  method: string
  apiEndpoint: string | null
  apiMethod: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'N/A'
  exampleRequest?: unknown
  exampleCode: string
  arguments?: ApiMethodArgument[]
  returns?: ApiMethodReturn
}

export const API_METHODS: ApiMethodDoc[] = [
  // ---- Machines ----
  {
    id: 'validate',
    title: 'Validate FSM config',
    description: 'Validate FSM configuration. Returns errors or machine info (state_names, trigger_names, terminal_states).',
    method: 'POST /api/v1/machines/validate',
    apiEndpoint: '/api/v1/machines/validate',
    apiMethod: 'POST',
    exampleRequest: {
      config: {
        meta: { machine_name: 'order', version: '1.0.0' },
        states: [
          { name: 'OPEN', type: 'initial' },
          { name: 'FILLED', type: 'terminal' },
        ],
        transitions: [{ trigger: 'fill', source: 'OPEN', dest: 'FILLED' }],
      },
    },
    exampleCode: `from pystator import StateMachine, lint

# Validate by constructing a machine (raises on error)
machine = StateMachine.from_dict(config)

# Or use lint() for non-fatal warnings
warnings = lint(config)
for w in warnings:
    print(w.severity, w.message)`,
    arguments: [
      { name: 'config', type: 'object', description: 'Full FSM config (meta, states, transitions, optional error_policy)', required: true },
    ],
    returns: {
      type: 'ValidateResponse',
      description: 'valid: boolean, errors: string[], info?: { machine_name, version, state_names, trigger_names, terminal_states }',
    },
  },
  {
    id: 'list_machines',
    title: 'List machines',
    description: 'List all FSM machines stored in the database. Supports optional name and version filters.',
    method: 'GET /api/v1/machines',
    apiEndpoint: '/api/v1/machines',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.get("http://localhost:8000/api/v1/machines")
machines = resp.json()["machines"]

# Filter by name
resp = httpx.get(
    "http://localhost:8000/api/v1/machines",
    params={"name": "order_management"},
)`,
    returns: { type: 'MachineListResponse', description: 'machines: [{ id, name, version, description }], count' },
  },
  {
    id: 'get_machine',
    title: 'Get machine',
    description: 'Get a single FSM machine by ID (returns full config).',
    method: 'GET /api/v1/machines/{machine_id}',
    apiEndpoint: '/api/v1/machines/{machine_id}',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

machine_id = "your-uuid-here"
resp = httpx.get(
    f"http://localhost:8000/api/v1/machines/{machine_id}"
)
config = resp.json()["config"]

# Then use locally:
from pystator import StateMachine
machine = StateMachine.from_dict(config)`,
    arguments: [{ name: 'machine_id', type: 'string (UUID)', description: 'Machine UUID', required: true }],
    returns: { type: 'MachineResponse', description: 'id, name, version, description, strict_mode, config (full FSM)' },
  },
  {
    id: 'create_machine',
    title: 'Create machine',
    description: 'Validate and store an FSM machine in the database. Fails if name+version already exists.',
    method: 'POST /api/v1/machines',
    apiEndpoint: '/api/v1/machines',
    apiMethod: 'POST',
    exampleRequest: {
      config: {
        meta: { machine_name: 'order_management', version: '1.0.0' },
        states: [{ name: 'DRAFT', type: 'initial' }, { name: 'DONE', type: 'terminal' }],
        transitions: [{ trigger: 'submit', source: 'DRAFT', dest: 'DONE' }],
      },
    },
    exampleCode: `import httpx

resp = httpx.post(
    "http://localhost:8000/api/v1/machines",
    json={"config": {
        "meta": {"machine_name": "order", "version": "1.0.0"},
        "states": [
            {"name": "OPEN", "type": "initial"},
            {"name": "FILLED", "type": "terminal"},
        ],
        "transitions": [
            {"trigger": "fill", "source": "OPEN", "dest": "FILLED"}
        ],
    }},
)
machine_id = resp.json()["id"]`,
    arguments: [{ name: 'config', type: 'object', description: 'Full FSM config', required: true }],
    returns: { type: 'MachineResponse', description: 'Created machine with id, name, version, config' },
  },
  {
    id: 'update_machine',
    title: 'Update machine',
    description: 'Validate and update an existing FSM machine by ID.',
    method: 'PUT /api/v1/machines/{machine_id}',
    apiEndpoint: '/api/v1/machines/{machine_id}',
    apiMethod: 'PUT',
    exampleRequest: {
      config: {
        meta: { machine_name: 'order_management', version: '1.0.1' },
        states: [{ name: 'DRAFT', type: 'initial' }, { name: 'DONE', type: 'terminal' }],
        transitions: [{ trigger: 'submit', source: 'DRAFT', dest: 'DONE' }],
      },
    },
    exampleCode: `import httpx

machine_id = "your-uuid-here"
resp = httpx.put(
    f"http://localhost:8000/api/v1/machines/{machine_id}",
    json={"config": updated_config},
)
print(resp.json()["version"])  # new version`,
    arguments: [
      { name: 'machine_id', type: 'string (UUID)', description: 'Machine UUID', required: true },
      { name: 'config', type: 'object', description: 'Full FSM config to replace', required: true },
    ],
    returns: { type: 'MachineResponse', description: 'Updated machine' },
  },
  {
    id: 'delete_machine',
    title: 'Delete machine',
    description: 'Delete an FSM machine from the database by ID.',
    method: 'DELETE /api/v1/machines/{machine_id}',
    apiEndpoint: '/api/v1/machines/{machine_id}',
    apiMethod: 'DELETE',
    exampleRequest: null,
    exampleCode: `import httpx

machine_id = "your-uuid-here"
resp = httpx.delete(
    f"http://localhost:8000/api/v1/machines/{machine_id}"
)
assert resp.status_code == 204`,
    arguments: [{ name: 'machine_id', type: 'string (UUID)', description: 'Machine UUID', required: true }],
    returns: { type: 'void', description: '204 No Content' },
  },
  // ---- Process (stateless) ----
  {
    id: 'process',
    title: 'Process event',
    description: 'Process an FSM event: current state + trigger (+ context). Returns success, target_state, actions_to_execute, on_enter/on_exit. Stateless — no persistence.',
    method: 'POST /api/v1/process',
    apiEndpoint: '/api/v1/process',
    apiMethod: 'POST',
    exampleRequest: {
      config: { meta: { machine_name: 'order', version: '1.0' }, states: [{ name: 'OPEN', type: 'initial' }, { name: 'FILLED', type: 'terminal' }], transitions: [{ trigger: 'fill', source: 'OPEN', dest: 'FILLED' }] },
      current_state: 'OPEN',
      trigger: 'fill',
      context: { fill_qty: 100, order_qty: 100 },
    },
    exampleCode: `from pystator import StateMachine

machine = StateMachine.from_yaml("order.yaml")
# or: machine = StateMachine.from_dict(config)

result = machine.process(
    current_state="OPEN",
    trigger="fill",
    context={"fill_qty": 100, "order_qty": 100},
)

print(result.success)       # True
print(result.target_state)  # "FILLED"
print(result.all_actions)   # ("update_positions",)`,
    arguments: [
      { name: 'config', type: 'object', description: 'FSM configuration', required: true },
      { name: 'current_state', type: 'string', description: 'Current state name', required: true },
      { name: 'trigger', type: 'string', description: 'Event trigger name', required: true },
      { name: 'context', type: 'object', description: 'Runtime context for guards', required: false },
    ],
    returns: {
      type: 'ProcessResponse',
      description: 'success, source_state, target_state, trigger, actions_to_execute, on_enter_actions, on_exit_actions, error',
    },
  },
  // ---- Entities (full-service state persistence) ----
  {
    id: 'get_entity_state',
    title: 'Get entity state',
    description: 'Get the current FSM state for an entity from the database (entity_states table).',
    method: 'GET /api/v1/entities/{entity_id}/state',
    apiEndpoint: '/api/v1/entities/order-123/state',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `from pystator import SQLiteStateStore

store = SQLiteStateStore(db_url)
state = store.get_state("order-123")

print(state)  # "OPEN"

# Or get full context:
ctx = store.get_context("order-123")`,
    arguments: [{ name: 'entity_id', type: 'string', description: 'Entity identifier (e.g. order-123, workflow-456)', required: true }],
    returns: {
      type: 'EntityStateResponse',
      description: 'entity_id, current_state, machine_name?, context, updated_at, created_at',
    },
  },
  {
    id: 'process_entity_event',
    title: 'Process entity event (full service)',
    description: 'Full-service event processing: load state from DB, process event, persist new state, record history. Use this when you want the API to manage entity state. For new entities, provide machine_name.',
    method: 'POST /api/v1/entities/{entity_id}/events',
    apiEndpoint: '/api/v1/entities/order-123/events',
    apiMethod: 'POST',
    exampleRequest: {
      trigger: 'exchange_ack',
      context: { order_id: 'ex-123' },
      machine_name: 'order_management',
      machine_version: '1.0.0',
    },
    exampleCode: `from pystator import (
    StateMachine, Orchestrator,
    SQLiteStateStore,
    GuardRegistry, ActionRegistry,
)

machine = StateMachine.from_yaml("order.yaml")
store = SQLiteStateStore(db_url)
guards = GuardRegistry()
actions = ActionRegistry()

orch = Orchestrator(machine, store, guards, actions)

# Full sandwich: load → decide → persist → act
result = await orch.async_process_event(
    entity_id="order-123",
    trigger="fill",
    context={"fill_qty": 100},
)`,
    arguments: [
      { name: 'entity_id', type: 'string', description: 'Entity identifier', required: true },
      { name: 'trigger', type: 'string', description: 'Event trigger name', required: true },
      { name: 'context', type: 'object', description: 'Runtime context for guards/actions', required: false },
      { name: 'machine_name', type: 'string', description: 'Machine name (required for new entities)', required: false },
      { name: 'machine_version', type: 'string', description: 'Machine version (default: latest)', required: false },
    ],
    returns: {
      type: 'ProcessEntityEventResponse',
      description: 'success, entity_id, source_state, target_state?, trigger, actions[], error?, transition_id?',
    },
  },
  {
    id: 'get_entity_history',
    title: 'Get entity transition history',
    description: 'Get the transition history (audit log) for an entity.',
    method: 'GET /api/v1/entities/{entity_id}/history',
    apiEndpoint: '/api/v1/entities/order-123/history',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.get(
    "http://localhost:8000/api/v1/entities/order-123/history",
    params={"limit": 50, "offset": 0},
)
for entry in resp.json():
    print(entry["source_state"], "->", entry["target_state"])`,
    arguments: [
      { name: 'entity_id', type: 'string', description: 'Entity identifier', required: true },
      { name: 'limit', type: 'number', description: 'Max records (default 50)', required: false },
      { name: 'offset', type: 'number', description: 'Skip N records', required: false },
    ],
    returns: {
      type: 'TransitionHistoryResponse[]',
      description: 'id, entity_id, source_state, target_state, trigger, success, error_message?, actions_executed?, created_at',
    },
  },
  {
    id: 'list_entities',
    title: 'List entities',
    description: 'List all entities with optional filters (machine_name, state).',
    method: 'GET /api/v1/entities',
    apiEndpoint: '/api/v1/entities',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

# List all entities
resp = httpx.get("http://localhost:8000/api/v1/entities")

# Filter by machine and state
resp = httpx.get(
    "http://localhost:8000/api/v1/entities",
    params={
        "machine_name": "order_management",
        "state": "OPEN",
        "limit": 50,
    },
)
entities = resp.json()["entities"]`,
    arguments: [
      { name: 'machine_name', type: 'string', description: 'Filter by machine', required: false },
      { name: 'state', type: 'string', description: 'Filter by current state', required: false },
      { name: 'limit', type: 'number', description: 'Max records (default 50)', required: false },
      { name: 'offset', type: 'number', description: 'Skip N records', required: false },
    ],
    returns: {
      type: 'EntityListResponse',
      description: 'entities: EntityStateResponse[], total, limit, offset',
    },
  },
  {
    id: 'delete_entity',
    title: 'Delete entity state',
    description: 'Delete an entity\'s state record from the database (does not delete transition history).',
    method: 'DELETE /api/v1/entities/{entity_id}',
    apiEndpoint: '/api/v1/entities/order-123',
    apiMethod: 'DELETE',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.delete(
    "http://localhost:8000/api/v1/entities/order-123"
)
assert resp.status_code == 204`,
    arguments: [{ name: 'entity_id', type: 'string', description: 'Entity identifier', required: true }],
    returns: { type: 'void', description: '204 No Content' },
  },
  // ---- Auth ----
  {
    id: 'auth_login',
    title: 'Login',
    description: 'Authenticate with username/password. Returns JWT access token. When auth is disabled, returns 503.',
    method: 'POST /api/v1/auth/login',
    apiEndpoint: '/api/v1/auth/login',
    apiMethod: 'POST',
    exampleRequest: { username: 'admin', password: 'admin' },
    exampleCode: `import httpx

resp = httpx.post(
    "http://localhost:8000/api/v1/auth/login",
    json={"username": "admin", "password": "admin"},
)
token = resp.json()["access_token"]

# Use token for authenticated requests
headers = {"Authorization": f"Bearer {token}"}`,
    arguments: [
      { name: 'username', type: 'string', description: 'Username', required: true },
      { name: 'password', type: 'string', description: 'Password', required: true },
    ],
    returns: { type: 'LoginResponse', description: 'access_token, token_type, expires_in' },
  },
  {
    id: 'auth_logout',
    title: 'Logout',
    description: 'Log out (client should discard the token). Server-side invalidation can be added later.',
    method: 'POST /api/v1/auth/logout',
    apiEndpoint: '/api/v1/auth/logout',
    apiMethod: 'POST',
    exampleRequest: {},
    exampleCode: `import httpx

resp = httpx.post(
    "http://localhost:8000/api/v1/auth/logout"
)
# Discard the token client-side`,
    returns: { type: 'object', description: '{"message": "OK"}' },
  },
  {
    id: 'auth_me',
    title: 'Current user (me)',
    description: 'Get current authenticated user. Returns username and auth_disabled flag. 401 if not authenticated.',
    method: 'GET /api/v1/auth/me',
    apiEndpoint: '/api/v1/auth/me',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.get(
    "http://localhost:8000/api/v1/auth/me",
    headers={"Authorization": f"Bearer {token}"},
)
user = resp.json()
print(user["username"])       # "admin"
print(user["auth_disabled"])  # False`,
    returns: { type: 'UserResponse', description: 'username, auth_disabled' },
  },
  // ---- Templates ----
  {
    id: 'list_templates',
    title: 'List FSM templates',
    description: 'List available FSM template filenames (e.g. blank.yaml, order_management.yaml).',
    method: 'GET /api/v1/templates/fsm',
    apiEndpoint: '/api/v1/templates/fsm',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.get(
    "http://localhost:8000/api/v1/templates/fsm"
)
templates = resp.json()
# ["blank.yaml", "order_management.yaml", ...]`,
    returns: { type: 'string[]', description: 'Template filenames' },
  },
  {
    id: 'get_template',
    title: 'Get FSM template',
    description: 'Get FSM template content by filename (YAML text).',
    method: 'GET /api/v1/templates/fsm/{filename}',
    apiEndpoint: '/api/v1/templates/fsm/blank.yaml',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx
import yaml

resp = httpx.get(
    "http://localhost:8000/api/v1/templates/fsm/order_management.yaml"
)
config = yaml.safe_load(resp.text)

from pystator import StateMachine
machine = StateMachine.from_dict(config)`,
    arguments: [{ name: 'filename', type: 'string', description: 'Template filename (e.g. blank.yaml)', required: true }],
    returns: { type: 'text/yaml', description: 'YAML body' },
  },
  // ---- Settings ----
  {
    id: 'get_database_config',
    title: 'Get database config',
    description: 'Get current database configuration and connection info (type, machine_count, message).',
    method: 'GET /api/v1/settings/database-config',
    apiEndpoint: '/api/v1/settings/database-config',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.get(
    "http://localhost:8000/api/v1/settings/database-config"
)
info = resp.json()
print(info["database_type"])  # "SQLite" or "PostgreSQL"
print(info["machine_count"])  # number of stored machines`,
    returns: {
      type: 'DatabaseConfigResponse',
      description: 'configured_url, actual_url, database_type, is_default, machine_count, message',
    },
  },
  {
    id: 'test_database',
    title: 'Test database connection',
    description: 'Test a database connection using provided credentials (connection_string or host/port/database/username/password).',
    method: 'POST /api/v1/settings/test-database',
    apiEndpoint: '/api/v1/settings/test-database',
    apiMethod: 'POST',
    exampleRequest: {
      connection_string: 'postgresql://user:password@localhost:5432/pystator',
    },
    exampleCode: `import httpx

# Test with connection string
resp = httpx.post(
    "http://localhost:8000/api/v1/settings/test-database",
    json={
        "connection_string": "postgresql://user:pw@host:5432/db"
    },
)

# Or test with individual fields
resp = httpx.post(
    "http://localhost:8000/api/v1/settings/test-database",
    json={
        "host": "localhost",
        "port": 5432,
        "database": "pystator",
        "username": "user",
        "password": "password",
    },
)
print(resp.json()["success"])  # True or False`,
    arguments: [
      { name: 'connection_string', type: 'string', description: 'Full connection string (overrides individual fields)', required: false },
      { name: 'host', type: 'string', description: 'Database host', required: false },
      { name: 'port', type: 'number', description: 'Database port (default: 5432)', required: false, default: '5432' },
      { name: 'database', type: 'string', description: 'Database name', required: false },
      { name: 'username', type: 'string', description: 'Database username', required: false },
      { name: 'password', type: 'string', description: 'Database password', required: false },
    ],
    returns: { type: 'DatabaseTestResponse', description: 'success: boolean, message: string' },
  },
  // ---- General ----
  {
    id: 'root',
    title: 'API info',
    description: 'Root endpoint with API name, version, and docs links.',
    method: 'GET /',
    apiEndpoint: '/',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.get("http://localhost:8000/")
info = resp.json()
print(info["name"])         # "PyStator API"
print(info["api_version"])  # "v1"`,
    returns: { type: 'object', description: 'name, version, api_version, docs, redoc' },
  },
  {
    id: 'health',
    title: 'Health check',
    description: 'Health check endpoint for load balancers and monitoring.',
    method: 'GET /health',
    apiEndpoint: '/health',
    apiMethod: 'GET',
    exampleRequest: null,
    exampleCode: `import httpx

resp = httpx.get("http://localhost:8000/health")
print(resp.json()["status"])  # "healthy"`,
    returns: { type: 'object', description: 'status, version' },
  },
]

export const SECTION_METHOD_MAP: Record<string, string[]> = {
  overview: [],
  machines: ['validate', 'list_machines', 'get_machine', 'create_machine', 'update_machine', 'delete_machine'],
  process: ['process'],
  entities: ['get_entity_state', 'process_entity_event', 'get_entity_history', 'list_entities', 'delete_entity'],
  auth: ['auth_login', 'auth_logout', 'auth_me'],
  templates: ['list_templates', 'get_template'],
  settings: ['get_database_config', 'test_database'],
  general: ['root', 'health'],
}

export const SECTION_DESCRIPTIONS: Record<string, string> = {
  overview: 'PyStator overview: features, CLI, state stores, and key concepts (hierarchical/parallel states, sandwich pattern).',
  machines: 'Validate FSM config and manage machines in the database (list, get, create, update, delete).',
  process: 'Stateless process: current state + trigger + context; returns transition result and actions. No persistence.',
  entities: 'Full-service entity state: load state from DB, process event, persist, record history. Use for entity-scoped workflows.',
  auth: 'JWT authentication: login, logout, current user. Optional (disabled when no credentials configured).',
  templates: 'FSM template files (YAML): list and fetch by filename for the workspace editor.',
  settings: 'Database configuration and connection testing (SQLite, PostgreSQL).',
  general: 'API info and health check.',
}
