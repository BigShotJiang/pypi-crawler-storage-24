'use client'

import { Button } from '@/components/ui/button'
import type { FSMConfig } from '@/lib/types/fsm'
import { Pencil, Trash2 } from 'lucide-react'

export interface ConfigErrorPolicySectionProps {
  config: FSMConfig
  onOpenModal: () => void
  onRemove: () => void
}

export function ConfigErrorPolicySection({
  config,
  onOpenModal,
  onRemove,
}: ConfigErrorPolicySectionProps) {
  const hasPolicy = !!config.error_policy

  return (
    <div className="space-y-3">
      <div className="space-y-2">
        {hasPolicy && config.error_policy && (
          <div className="flex items-center gap-2 rounded border p-2 bg-muted/30">
            <div className="flex-1 min-w-0 space-y-1">
              <div className="flex items-baseline gap-1.5 flex-wrap">
                <span className="text-sm font-medium">Error policy</span>
              </div>
              <div className="text-xs text-muted-foreground space-y-0.5">
                <p>
                  <span className="font-medium text-foreground/80">Fallback:</span>{' '}
                  {config.error_policy.default_fallback || '—'}
                </p>
                <p>
                  <span className="font-medium text-foreground/80">Retries:</span>{' '}
                  {config.error_policy.retry_attempts ?? 0}
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0"
              onClick={onOpenModal}
              aria-label="Edit error policy"
            >
              <Pencil className="h-3.5 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0 text-destructive"
              onClick={onRemove}
              aria-label="Remove error policy"
            >
              <Trash2 className="h-3.5 w-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
