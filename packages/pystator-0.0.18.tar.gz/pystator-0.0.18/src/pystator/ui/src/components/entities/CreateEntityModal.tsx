'use client'

import { useCallback, useEffect, useState } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { listMachines, getMachine, processEntityEvent } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'
import { getTriggersFromInitialState } from '@/lib/fsmConfigUtils'
import LoadingSpinner from '@/components/LoadingSpinner'

export interface CreateEntityModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onSuccess: (entityId: string) => void
}

export default function CreateEntityModal({ open, onOpenChange, onSuccess }: CreateEntityModalProps) {
  const [entityId, setEntityId] = useState('')
  const [machines, setMachines] = useState<MachineListItem[]>([])
  const [selectedMachineId, setSelectedMachineId] = useState('')
  const [triggers, setTriggers] = useState<string[]>([])
  const [selectedTrigger, setSelectedTrigger] = useState('')
  const [loadingMachines, setLoadingMachines] = useState(false)
  const [loadingTriggers, setLoadingTriggers] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!open) return
    setLoadingMachines(true)
    listMachines()
      .then((res) => setMachines(res.machines))
      .catch(() => setMachines([]))
      .finally(() => setLoadingMachines(false))
  }, [open])

  useEffect(() => {
    if (!open || !selectedMachineId) {
      setTriggers([])
      setSelectedTrigger('')
      return
    }
    setLoadingTriggers(true)
    getMachine(selectedMachineId)
      .then((machine) => {
        const t = getTriggersFromInitialState(machine.config)
        setTriggers(t)
        setSelectedTrigger(t[0] ?? '')
      })
      .catch(() => {
        setTriggers([])
        setSelectedTrigger('')
      })
      .finally(() => setLoadingTriggers(false))
  }, [open, selectedMachineId])

  const selectedMachine = machines.find((m) => m.id === selectedMachineId)
  const canSubmit =
    entityId.trim() !== '' &&
    selectedMachineId !== '' &&
    selectedTrigger !== '' &&
    !submitting

  const handleSubmit = useCallback(
    async (e: React.FormEvent) => {
      e.preventDefault()
      if (!canSubmit || !selectedMachine) return
      setError(null)
      setSubmitting(true)
      try {
        await processEntityEvent(entityId.trim(), {
          trigger: selectedTrigger,
          machine_name: selectedMachine.name,
          context: {},
        })
        onOpenChange(false)
        setEntityId('')
        setSelectedMachineId('')
        setSelectedTrigger('')
        onSuccess(entityId.trim())
      } catch (err) {
        setError(err instanceof Error ? err.message : String(err))
      } finally {
        setSubmitting(false)
      }
    },
    [canSubmit, entityId, selectedMachine, selectedTrigger, onOpenChange, onSuccess]
  )

  const handleOpenChange = useCallback(
    (next: boolean) => {
      if (!next) {
        setEntityId('')
        setSelectedMachineId('')
        setError(null)
      }
      onOpenChange(next)
    },
    [onOpenChange]
  )

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent showClose>
        <DialogHeader>
          <DialogTitle>Create entity</DialogTitle>
          <DialogDescription>
            Create a new entity by sending its first event. Choose a machine and the initial trigger (from the machine&apos;s initial state).
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="create-entity-id">Entity ID</Label>
            <Input
              id="create-entity-id"
              value={entityId}
              onChange={(e) => setEntityId(e.target.value)}
              placeholder="e.g. order-001"
              disabled={submitting}
              autoFocus
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="create-entity-machine">Machine</Label>
            <select
              id="create-entity-machine"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={selectedMachineId}
              onChange={(e) => setSelectedMachineId(e.target.value)}
              disabled={loadingMachines || submitting}
            >
              <option value="">Select a machine</option>
              {machines.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name} (v{m.version})
                </option>
              ))}
            </select>
          </div>
          {selectedMachineId && (
            <div className="space-y-2">
              <Label htmlFor="create-entity-trigger">First trigger</Label>
              <select
                id="create-entity-trigger"
                className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                value={selectedTrigger}
                onChange={(e) => setSelectedTrigger(e.target.value)}
                disabled={loadingTriggers || submitting}
              >
                {loadingTriggers ? (
                  <option value="">Loading…</option>
                ) : triggers.length === 0 ? (
                  <option value="">No triggers from initial state</option>
                ) : (
                  triggers.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))
                )}
              </select>
              <p className="text-xs text-muted-foreground">
                Triggers available from the machine&apos;s initial state.
              </p>
            </div>
          )}
          {error && (
            <div className="rounded-md bg-destructive/10 border border-destructive/20 px-3 py-2 text-sm text-destructive">
              {error}
            </div>
          )}
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => handleOpenChange(false)} disabled={submitting}>
              Cancel
            </Button>
            <Button type="submit" disabled={!canSubmit}>
              {submitting ? <LoadingSpinner size="sm" /> : 'Create'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
