/**
 * Component exports
 *
 * Shared component primitives used across routes.
 * Feature-specific components are typically imported from their feature folders.
 */

// UI Components (shadcn/ui)
export { Button, buttonVariants } from './ui/button'
export type { ButtonProps } from './ui/button'
export {
  Card,
  CardHeader,
  CardFooter,
  CardTitle,
  CardDescription,
  CardContent,
} from './ui/card'
export { Input } from './ui/input'
export { Label } from './ui/label'
export { Skeleton } from './ui/skeleton'
export { Switch } from './ui/switch'
export type { SwitchProps } from './ui/switch'
export { Alert, AlertDescription, AlertTitle } from './ui/alert'

// Custom Components
export { default as Navigation } from './Navigation'
export { default as ErrorBoundary } from './ErrorBoundary'
export { default as ErrorDisplay } from './ErrorDisplay'
export {
  default as LoadingSpinner,
  PageLoading,
  CardSkeleton,
  TableSkeleton,
} from './LoadingSpinner'

// Common Components
export { PageHeader } from './common'
