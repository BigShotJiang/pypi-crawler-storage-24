'use client'

import { useMemo, useEffect, useRef, useCallback, type CSSProperties } from 'react'
import {
  ReactFlow,
  Controls,
  Background,
  BackgroundVariant,
  useNodesState,
  useEdgesState,
  type ReactFlowInstance,
  type Connection,
  type Node,
  type Edge,
} from '@xyflow/react'
import '@xyflow/react/dist/base.css'
import '@xyflow/react/dist/style.css'
import { fsmConfigToReactFlow, type FsmFlowOptions, type NodeData, type EdgeLabelData } from '@/lib/fsmToReactFlow'
import type { FSMConfig } from '@/lib/types/fsm'
import { CompoundStateNode } from './CompoundStateNode'
import { FsmDiagramFocusProvider, useFsmDiagramFocus } from './FsmDiagramFocusContext'
import { EdgeWithLabel } from './EdgeWithLabel'
import { StateNode } from './StateNode'

const edgeTypes = { smoothstep: EdgeWithLabel }
const nodeTypes = { state: StateNode, compound: CompoundStateNode }

/**
 * Merge layout nodes with current node positions so that:
 * - Data and style (e.g. highlight) come from the latest layout.
 * - Positions are preserved from current nodes when present (user may have dragged).
 * This prevents the diagram from jumping back to default layout after processing an event.
 */
function mergeNodesWithCurrentPositions(
  layoutNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes'],
  currentNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes']
): ReturnType<typeof fsmConfigToReactFlow>['nodes'] {
  const currentById = new Map(currentNodes.map((n) => [n.id, n]))
  return layoutNodes.map((layoutNode) => {
    const current = currentById.get(layoutNode.id)
    if (current?.position) {
      return { ...layoutNode, position: current.position }
    }
    return layoutNode
  })
}

export interface FsmFlowDiagramProps {
  config: FSMConfig
  /** Minimum height of the diagram container */
  minHeight?: number | string
  /** Show guards on edge labels (default true) */
  showGuards?: boolean
  /** Show actions on edge labels (default false) */
  showActions?: boolean
  /** Show hierarchy indicators (parent/child, parallel regions) (default true) */
  showHierarchy?: boolean
  /** Highlight this transition (e.g. last transition) */
  highlightTransition?: { source: string; target: string; trigger: string } | null
  /** Highlight this state as current (entity instance "you are here") */
  highlightState?: string | null
  /** Optional class name for the wrapper */
  className?: string
  /** Enable editing mode: double-click, drag-to-connect, delete */
  editable?: boolean
  /** Called when user double-clicks canvas (for adding a state). Receives flow position {x, y}. */
  onPaneDoubleClick?: (position: { x: number; y: number }) => void
  /** Called when user double-clicks a state node. Receives the original state name. */
  onNodeDoubleClick?: (stateName: string) => void
  /** Called when user double-clicks a transition edge. Receives the transition index in config. */
  onEdgeDoubleClick?: (transitionIndex: number) => void
  /** Called when user drags a connection between two nodes. Receives source and target state names. */
  onConnect?: (sourceName: string, destName: string) => void
  /** Called when user presses Delete on selected state nodes. Receives array of state names. */
  onNodesDelete?: (stateNames: string[]) => void
  /** Called when user presses Delete on selected edges. Receives array of transition indices. */
  onEdgesDelete?: (transitionIndices: number[]) => void
}

type FsmFlowDiagramInnerProps = FsmFlowDiagramProps & {
  initialNodes: ReturnType<typeof fsmConfigToReactFlow>['nodes']
  initialEdges: ReturnType<typeof fsmConfigToReactFlow>['edges']
}

function FsmFlowDiagramInner({
  initialNodes,
  initialEdges,
  config,
  minHeight = 480,
  showGuards = true,
  showActions = false,
  showHierarchy = true,
  highlightTransition = null,
  highlightState = null,
  className = '',
  editable = false,
  onPaneDoubleClick,
  onNodeDoubleClick,
  onEdgeDoubleClick,
  onConnect,
  onNodesDelete,
  onEdgesDelete,
}: FsmFlowDiagramInnerProps) {
  const { clearFocus, requestFocusNode, requestFocusEdgeLabel } = useFsmDiagramFocus()

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes)
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges)
  const rfInstanceRef = useRef<ReactFlowInstance<Node<NodeData>, Edge<EdgeLabelData>> | null>(null)

  useEffect(() => {
    setNodes((current) => mergeNodesWithCurrentPositions(initialNodes, current))
    setEdges(initialEdges)
  }, [initialNodes, initialEdges, setNodes, setEdges])

  const handlePaneDoubleClick = useCallback(
    (event: React.MouseEvent) => {
      if (!editable || !onPaneDoubleClick || !rfInstanceRef.current) return
      // Ignore double-clicks that originated on a node or edge (they have their own handlers)
      const target = event.target as HTMLElement
      if (
        target.closest('.react-flow__node') ||
        target.closest('.react-flow__edge') ||
        target.closest('.react-flow__edgelabel-renderer')
      ) return
      const position = rfInstanceRef.current.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      })
      onPaneDoubleClick(position)
    },
    [editable, onPaneDoubleClick]
  )

  const handleNodeDoubleClick = useCallback(
    (_event: React.MouseEvent, node: Node<NodeData>) => {
      if (!editable || !onNodeDoubleClick) return
      const data = node.data as NodeData
      const stateName = data.stateName ?? node.id
      onNodeDoubleClick(stateName)
    },
    [editable, onNodeDoubleClick]
  )

  const handleNodeClick = useCallback(
    (_event: React.MouseEvent, node: Node<NodeData>) => {
      requestFocusNode(node.id)
    },
    [requestFocusNode]
  )

  const handleEdgeDoubleClick = useCallback(
    (_event: React.MouseEvent, edge: Edge<EdgeLabelData>) => {
      if (!editable || !onEdgeDoubleClick) return
      const data = (edge.data ?? {}) as EdgeLabelData
      if (data.isSynthetic) return
      if (data.transitionIndex != null) {
        onEdgeDoubleClick(data.transitionIndex)
      }
    },
    [editable, onEdgeDoubleClick]
  )

  const handleEdgeClick = useCallback(
    (_event: React.MouseEvent, edge: Edge<EdgeLabelData>) => {
      requestFocusEdgeLabel(edge.id, { sourceId: edge.source, targetId: edge.target })
    },
    [requestFocusEdgeLabel]
  )

  const handleConnect = useCallback(
    (connection: Connection) => {
      if (!editable || !onConnect) return
      if (!connection.source || !connection.target) return
      // Resolve source/target to state names from node data
      const sourceNode = nodes.find((n) => n.id === connection.source)
      const targetNode = nodes.find((n) => n.id === connection.target)
      if (!sourceNode || !targetNode) return
      const sourceData = sourceNode.data as NodeData
      const targetData = targetNode.data as NodeData
      const sourceName = sourceData.stateName ?? sourceNode.id
      const destName = targetData.stateName ?? targetNode.id
      onConnect(sourceName, destName)
    },
    [editable, onConnect, nodes]
  )

  const handleNodesDeleteCb = useCallback(
    (deletedNodes: Node<NodeData>[]) => {
      if (!editable || !onNodesDelete) return
      const stateNames = deletedNodes
        .map((n) => (n.data as NodeData).stateName ?? n.id)
      if (stateNames.length > 0) {
        onNodesDelete(stateNames)
      }
    },
    [editable, onNodesDelete]
  )

  const handleEdgesDeleteCb = useCallback(
    (deletedEdges: Edge<EdgeLabelData>[]) => {
      if (!editable || !onEdgesDelete) return
      const indices = deletedEdges
        .map((e) => ((e.data ?? {}) as EdgeLabelData).transitionIndex)
        .filter((idx): idx is number => idx != null)
      if (indices.length > 0) {
        onEdgesDelete(indices)
      }
    },
    [editable, onEdgesDelete]
  )

  const isPercent = typeof minHeight === 'string' && minHeight.endsWith('%')
  const heightValue: number | string =
    typeof minHeight === 'number'
      ? minHeight
      : typeof minHeight === 'string' && minHeight.endsWith('px')
        ? parseInt(minHeight, 10) || 480
        : isPercent
          ? minHeight
          : 480
  const containerStyle: CSSProperties = {
    width: '100%',
    height: heightValue,
    minHeight: heightValue,
    position: 'relative',
  }

  if (!config.states?.length) {
    return (
      <div
        className={`flex items-center justify-center rounded border bg-muted/30 ${className}`}
        style={containerStyle}
        onDoubleClick={editable ? handlePaneDoubleClick : undefined}
      >
        <p className="text-muted-foreground text-sm">
          {editable
            ? 'Double-click to add a state, or use the sidebar.'
            : 'Add at least one state to see the diagram.'}
        </p>
      </div>
    )
  }

  return (
    <div className={`rounded border bg-muted/30 ${className}`} style={containerStyle}>
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        edgeTypes={edgeTypes}
        defaultEdgeOptions={{ type: 'smoothstep' }}
        height={typeof heightValue === 'number' ? heightValue : parseInt(String(heightValue), 10) || 480}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.2}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
        nodesDraggable
        nodesConnectable={editable}
        elementsSelectable
        panOnDrag
        zoomOnScroll
        zoomOnPinch
        onInit={(instance) => {
          rfInstanceRef.current = instance as ReactFlowInstance<Node<NodeData>, Edge<EdgeLabelData>>
        }}
        onPaneClick={clearFocus}
        onNodeClick={handleNodeClick}
        onEdgeClick={handleEdgeClick}
        onDoubleClick={editable ? handlePaneDoubleClick : undefined}
        onNodeDoubleClick={editable ? handleNodeDoubleClick : undefined}
        onEdgeDoubleClick={editable ? handleEdgeDoubleClick : undefined}
        onConnect={editable ? handleConnect : undefined}
        onNodesDelete={editable ? handleNodesDeleteCb : undefined}
        onEdgesDelete={editable ? handleEdgesDeleteCb : undefined}
        deleteKeyCode={editable ? ['Backspace', 'Delete'] : []}
      >
        <Controls showInteractive={false} />
        <Background variant={BackgroundVariant.Dots} gap={12} size={1} />
      </ReactFlow>
    </div>
  )
}

export default function FsmFlowDiagram(props: FsmFlowDiagramProps) {
  const {
    config,
    showGuards = true,
    showActions = false,
    showHierarchy = true,
    highlightTransition = null,
    highlightState = null,
  } = props

  const options: FsmFlowOptions = {
    showGuards,
    showActions,
    showHierarchy,
    highlightTransition,
    highlightState,
  }

  const { nodes: initialNodes, edges: initialEdges } = useMemo(
    () => fsmConfigToReactFlow(config, options),
    [config, showGuards, showActions, showHierarchy, highlightTransition, highlightState]
  )

  return (
    <FsmDiagramFocusProvider resetSignal={initialEdges}>
      <FsmFlowDiagramInner {...props} initialNodes={initialNodes} initialEdges={initialEdges} />
    </FsmDiagramFocusProvider>
  )
}
