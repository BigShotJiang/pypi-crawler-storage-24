'use client'

import { Button } from '@/components/ui/button'
import type { FSMTransition } from '@/lib/types/fsm'
import { Trash2, Pencil } from 'lucide-react'
import { parseSource, sourceToString, TransitionDetails } from '../ConfigHelpers'

export interface DiagramHighlightTransition {
  source: string
  target: string
  trigger: string
}

export interface ConfigTransitionsSectionProps {
  transitions: FSMTransition[]
  stateNames: string[]
  onAddTransition: () => void
  onEditTransition: (index: number) => void
  onRemoveTransition: (index: number) => void
  /** When set, clicking a transition row highlights it in the diagram. */
  onTransitionClick?: (t: DiagramHighlightTransition) => void
  /** Transition currently highlighted in the diagram (for visual feedback in the list). */
  highlightedTransition?: DiagramHighlightTransition | null
}

export function ConfigTransitionsSection({
  transitions,
  onAddTransition,
  onEditTransition,
  onRemoveTransition,
  stateNames,
  onTransitionClick,
  highlightedTransition,
}: ConfigTransitionsSectionProps) {
  const transitionMatches = (t: FSMTransition, h: DiagramHighlightTransition) => {
    const sources = parseSource(t.source)
    const firstSource = sources[0] ?? ''
    return firstSource === h.source && t.dest === h.target && (t.trigger ?? '') === h.trigger
  }

  return (
    <div className="space-y-3">
      <div className="space-y-2">
        {transitions.map((t, i) => {
          const sources = parseSource(t.source)
          const firstSource = sources[0] ?? ''
          const isHighlighted = highlightedTransition && transitionMatches(t, highlightedTransition)
          return (
          <div
            key={i}
            role={onTransitionClick ? 'button' : undefined}
            tabIndex={onTransitionClick ? 0 : undefined}
            onClick={
              onTransitionClick
                ? () => onTransitionClick({ source: firstSource, target: t.dest, trigger: t.trigger ?? '' })
                : undefined
            }
            onKeyDown={
              onTransitionClick
                ? (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault()
                      onTransitionClick({ source: firstSource, target: t.dest, trigger: t.trigger ?? '' })
                    }
                  }
                : undefined
            }
            className={`flex items-start gap-2 rounded border p-2 bg-muted/30 ${
              onTransitionClick ? 'cursor-pointer hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-primary/50' : ''
            } ${isHighlighted ? 'ring-2 ring-primary bg-primary/10' : ''}`}
          >
            <div className="flex-1 min-w-0 text-sm">
              <div className="flex flex-wrap items-baseline gap-1">
                <span className="font-medium">{sourceToString(t.source)}</span>
                <span className="text-muted-foreground">→</span>
                <span className="font-medium">{t.dest}</span>
                <span className="text-muted-foreground">on</span>
                <span className="font-medium text-primary/90">{t.trigger}</span>
              </div>
              <TransitionDetails t={t} />
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0"
              onClick={(e) => {
                e.stopPropagation()
                onEditTransition(i)
              }}
            >
              <Pencil className="h-3.5 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0 text-destructive"
              onClick={(e) => {
                e.stopPropagation()
                onRemoveTransition(i)
              }}
            >
              <Trash2 className="h-3.5 w-4" />
            </Button>
          </div>
          )
        })}
      </div>
    </div>
  )
}
