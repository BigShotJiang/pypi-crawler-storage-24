'use client'

import { useMemo, useState, useCallback } from 'react'
import MatrixTable from './MatrixTable'
import type { FSMTransition } from '@/lib/types/fsm'
import { TransitionModal } from '@/components/modals'

/** Normalize source to flat array */
function sourcesToArray(source: string | string[]): string[] {
  return Array.isArray(source) ? source : [source]
}

interface TransitionMatrixProps {
  states: string[]
  transitions: FSMTransition[]
  onChange: (transitions: FSMTransition[]) => void
}

export default function TransitionMatrix({
  states,
  transitions,
  onChange,
}: TransitionMatrixProps) {
  const [editingCell, setEditingCell] = useState<{ row: number; col: number } | null>(null)
  const [editingTransitionIdx, setEditingTransitionIdx] = useState<number | null>(null)

  /** Build lookup: "source|dest" -> FSMTransition[] */
  const cellMap = useMemo(() => {
    const map = new Map<string, FSMTransition[]>()
    for (const t of transitions) {
      for (const src of sourcesToArray(t.source)) {
        const key = `${src}|${t.dest}`
        const arr = map.get(key) ?? []
        arr.push(t)
        map.set(key, arr)
      }
    }
    return map
  }, [transitions])

  const getCell = useCallback(
    (ri: number, ci: number): FSMTransition[] => {
      return cellMap.get(`${states[ri]}|${states[ci]}`) ?? []
    },
    [cellMap, states],
  )

  const renderCell = useCallback(
    (cell: FSMTransition[], _ri: number, _ci: number) => {
      if (cell.length === 0) {
        return <span className="text-muted-foreground/50">---</span>
      }
      return (
        <div className="flex flex-col items-center gap-0.5">
          {cell.map((t, i) => (
            <span
              key={i}
              className="inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium bg-primary/10 text-primary"
            >
              {t.trigger ?? '(auto)'}
            </span>
          ))}
        </div>
      )
    },
    [],
  )

  const handleCellClick = useCallback(
    (ri: number, ci: number) => {
      const cell = getCell(ri, ci)
      if (cell.length === 0) {
        // Open modal to add a new transition for this source->dest
        setEditingCell({ row: ri, col: ci })
        setEditingTransitionIdx(null)
      } else if (cell.length === 1) {
        // Edit existing single transition
        setEditingCell({ row: ri, col: ci })
        setEditingTransitionIdx(transitions.indexOf(cell[0]))
      } else {
        // Multiple: edit first, user can use transition list for more control
        setEditingCell({ row: ri, col: ci })
        setEditingTransitionIdx(transitions.indexOf(cell[0]))
      }
    },
    [getCell, transitions],
  )

  const handleSave = useCallback(
    (saved: FSMTransition) => {
      if (editingTransitionIdx != null && editingTransitionIdx >= 0) {
        const next = [...transitions]
        next[editingTransitionIdx] = saved
        onChange(next)
      } else {
        onChange([...transitions, saved])
      }
      setEditingCell(null)
      setEditingTransitionIdx(null)
    },
    [editingTransitionIdx, transitions, onChange],
  )

  const editingTransition: FSMTransition | null = useMemo(() => {
    if (!editingCell) return null
    if (editingTransitionIdx != null && editingTransitionIdx >= 0) {
      return transitions[editingTransitionIdx]
    }
    // New transition template
    return {
      trigger: '',
      source: states[editingCell.row],
      dest: states[editingCell.col],
    }
  }, [editingCell, editingTransitionIdx, transitions, states])

  return (
    <>
      <MatrixTable<FSMTransition[]>
        rowHeaders={states}
        columnHeaders={states}
        getCell={getCell}
        renderCell={renderCell}
        onCellClick={handleCellClick}
        cornerLabel="Source / Target"
        emptyMessage="Define at least one state to see the transition matrix."
      />
      {editingTransition && (
        <TransitionModal
          open={!!editingCell}
          onOpenChange={(open) => {
            if (!open) {
              setEditingCell(null)
              setEditingTransitionIdx(null)
            }
          }}
          transition={editingTransition}
          stateNames={states}
          onSave={handleSave}
          title={
            editingTransitionIdx != null && editingTransitionIdx >= 0
              ? 'Edit transition'
              : 'Add transition'
          }
          description={`${states[editingCell!.row]} → ${states[editingCell!.col]}`}
        />
      )}
    </>
  )
}
