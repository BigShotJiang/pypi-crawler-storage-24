'use client'

import { Button } from '@/components/ui/button'
import type { FSMState } from '@/lib/types/fsm'
import { Trash2, Pencil, GitBranch } from 'lucide-react'
import { EmptyState } from '@/components/EmptyState'
import { StateBadges } from '../ConfigHelpers'

export interface ConfigStatesSectionProps {
  states: FSMState[]
  onAddState: () => void
  onEditState: (index: number) => void
  onRemoveState: (index: number) => void
  /** When set, clicking a state row highlights it in the diagram. */
  onStateClick?: (stateName: string) => void
  /** State name currently highlighted in the diagram (for visual feedback in the list). */
  highlightedStateName?: string | null
}

export function ConfigStatesSection({
  states,
  onAddState,
  onEditState,
  onRemoveState,
  onStateClick,
  highlightedStateName,
}: ConfigStatesSectionProps) {
  return (
    <div className="space-y-3">
      {states.length === 0 ? (
        <EmptyState
          icon={<GitBranch className="h-8 w-8" />}
          title="No states defined"
          description="Add at least one state to define your FSM."
          actionLabel="Add state"
          onAction={onAddState}
        />
      ) : (
      <div className="space-y-2">
        {states.map((s, i) => (
          <div
            key={i}
            role={onStateClick ? 'button' : undefined}
            tabIndex={onStateClick ? 0 : undefined}
            onClick={onStateClick ? () => onStateClick(s.name) : undefined}
            onKeyDown={
              onStateClick
                ? (e) => {
                    if (e.key === 'Enter' || e.key === ' ') {
                      e.preventDefault()
                      onStateClick(s.name)
                    }
                  }
                : undefined
            }
            className={`flex items-center gap-2 rounded border p-2 bg-muted/30 ${
              onStateClick ? 'cursor-pointer hover:bg-muted/50 focus:outline-none focus:ring-2 focus:ring-primary/50' : ''
            } ${highlightedStateName === s.name ? 'ring-2 ring-primary bg-primary/10' : ''}`}
          >
            <div className="flex-1 min-w-0">
              <div className="flex items-baseline gap-1.5 flex-wrap">
                <span className="text-sm font-medium">{s.name}</span>
                <span className="text-xs text-muted-foreground">({s.type})</span>
              </div>
              {s.description && (
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{s.description}</p>
              )}
              <StateBadges s={s} />
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0"
              onClick={(e) => {
                e.stopPropagation()
                onEditState(i)
              }}
            >
              <Pencil className="h-3.5 w-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-7 w-7 shrink-0 text-destructive"
              onClick={(e) => {
                e.stopPropagation()
                onRemoveState(i)
              }}
              disabled={states.length <= 1}
            >
              <Trash2 className="h-3.5 w-4" />
            </Button>
          </div>
        ))}
      </div>
      )}
    </div>
  )
}
