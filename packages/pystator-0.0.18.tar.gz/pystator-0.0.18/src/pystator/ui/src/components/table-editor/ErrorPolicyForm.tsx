'use client'

import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'

interface ErrorPolicyFormProps {
  defaultFallback: string
  retryAttempts: number
  stateNames: string[]
  onChange: (fallback: string, retries: number) => void
}

export default function ErrorPolicyForm({
  defaultFallback,
  retryAttempts,
  stateNames,
  onChange,
}: ErrorPolicyFormProps) {
  return (
    <div className="max-w-lg space-y-4">
      <p className="text-sm text-muted-foreground">
        Optional fallback state and retry behavior when transition or action execution fails.
      </p>
      <div className="space-y-2">
        <Label htmlFor="ep-fallback">Default fallback state</Label>
        <select
          id="ep-fallback"
          className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          value={defaultFallback}
          onChange={(e) => onChange(e.target.value, retryAttempts)}
        >
          <option value="">None</option>
          {stateNames.map((n) => (
            <option key={n} value={n}>
              {n}
            </option>
          ))}
        </select>
      </div>
      <div className="space-y-2">
        <Label htmlFor="ep-retries">Retry attempts</Label>
        <Input
          id="ep-retries"
          type="number"
          min={0}
          className="h-9"
          value={retryAttempts}
          onChange={(e) =>
            onChange(defaultFallback, Math.max(0, parseInt(e.target.value, 10) || 0))
          }
        />
      </div>
    </div>
  )
}
