'use client'

import { useCallback, useState, useRef, useEffect } from 'react'
import MatrixTable from './MatrixTable'

interface StateVariableMatrixProps {
  states: string[]
  variables: string[]
  constraints: Record<string, Record<string, string>>
  onChange: (constraints: Record<string, Record<string, string>>) => void
}

export default function StateVariableMatrix({
  states,
  variables,
  constraints,
  onChange,
}: StateVariableMatrixProps) {
  const [editingCell, setEditingCell] = useState<{ row: number; col: number } | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (editingCell) inputRef.current?.focus()
  }, [editingCell])

  const getCell = useCallback(
    (ri: number, ci: number): string => {
      return constraints[states[ri]]?.[variables[ci]] ?? ''
    },
    [constraints, states, variables],
  )

  const commitEdit = useCallback(
    (ri: number, ci: number, value: string) => {
      const stateName = states[ri]
      const varKey = variables[ci]
      const next = { ...constraints }
      if (value.trim()) {
        next[stateName] = { ...(next[stateName] ?? {}), [varKey]: value.trim() }
      } else {
        if (next[stateName]) {
          const stateConstraints = { ...next[stateName] }
          delete stateConstraints[varKey]
          if (Object.keys(stateConstraints).length === 0) {
            delete next[stateName]
          } else {
            next[stateName] = stateConstraints
          }
        }
      }
      onChange(next)
      setEditingCell(null)
    },
    [constraints, states, variables, onChange],
  )

  const renderCell = useCallback(
    (value: string, ri: number, ci: number) => {
      if (editingCell?.row === ri && editingCell?.col === ci) {
        return (
          <input
            ref={inputRef}
            type="text"
            className="w-full h-7 rounded border border-input bg-background px-2 text-xs focus:outline-none focus:ring-2 focus:ring-ring"
            defaultValue={value}
            onBlur={(e) => commitEdit(ri, ci, e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                commitEdit(ri, ci, (e.target as HTMLInputElement).value)
              }
              if (e.key === 'Escape') setEditingCell(null)
            }}
            onClick={(e) => e.stopPropagation()}
          />
        )
      }
      if (!value) {
        return <span className="text-muted-foreground/50">---</span>
      }
      return <span className="text-xs font-mono">{value}</span>
    },
    [editingCell, commitEdit],
  )

  const handleCellClick = useCallback((ri: number, ci: number) => {
    setEditingCell({ row: ri, col: ci })
  }, [])

  return (
    <MatrixTable<string>
      rowHeaders={states}
      columnHeaders={variables}
      getCell={getCell}
      renderCell={renderCell}
      onCellClick={handleCellClick}
      cornerLabel="State / Variable"
      emptyMessage="Define states and variables to see the constraint matrix."
    />
  )
}
