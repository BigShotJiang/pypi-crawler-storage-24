'use client'

import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { cn } from '@/lib/utils'
import { CheckCircle2, XCircle } from 'lucide-react'
import { useToastStore, selectToastMessage, selectDismiss } from '@/stores/toast'
import type { ToastMessage } from '@/stores/toast'

const TOAST_DURATION_MS = 4_000

function ToastView({ message }: { message: ToastMessage }) {
  const [visible, setVisible] = useState(false)
  const { type, message: text } = message

  useEffect(() => {
    const t = requestAnimationFrame(() => setVisible(true))
    return () => cancelAnimationFrame(t)
  }, [])

  return (
    <div
      role="alert"
      className={cn(
        'flex items-center gap-2 rounded-lg border px-4 py-3 shadow-lg transition-all duration-200',
        visible ? 'translate-x-0 opacity-100' : 'translate-x-4 opacity-0',
        type === 'success' &&
          'border-emerald-200 bg-emerald-50 text-emerald-800 dark:border-emerald-800 dark:bg-emerald-950 dark:text-emerald-200',
        type === 'error' &&
          'border-destructive/30 bg-destructive/10 text-destructive dark:bg-destructive/20',
      )}
    >
      {type === 'success' ? (
        <CheckCircle2 className="h-5 w-5 shrink-0" aria-hidden />
      ) : (
        <XCircle className="h-5 w-5 shrink-0" aria-hidden />
      )}
      <span className="text-sm font-medium">{text}</span>
    </div>
  )
}

export default function ToastPortal() {
  const message = useToastStore(selectToastMessage)
  const dismiss = useToastStore(selectDismiss)

  useEffect(() => {
    if (!message) return
    const t = setTimeout(() => dismiss(), TOAST_DURATION_MS)
    return () => clearTimeout(t)
  }, [message, dismiss])

  if (typeof document === 'undefined' || !message) return null

  return createPortal(
    <div className="fixed top-4 right-4 z-[100] max-w-sm">
      <ToastView message={message} />
    </div>,
    document.body,
  )
}
