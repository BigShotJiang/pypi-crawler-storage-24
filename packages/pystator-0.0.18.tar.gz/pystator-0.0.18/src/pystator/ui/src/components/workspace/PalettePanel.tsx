'use client'

import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'
import {
  STATE_BLOCKS,
  TEMPLATE_BLOCKS,
  TRANSITION_BLOCKS,
  type StatePaletteBlockId,
  type TemplatePaletteId,
  type TransitionPaletteBlockId,
} from './paletteDefs'

export interface PalettePanelProps {
  onSelectStateBlock: (id: StatePaletteBlockId) => void
  onSelectTransitionBlock: (id: TransitionPaletteBlockId) => void
  onApplyTemplate: (id: TemplatePaletteId) => void
  className?: string
}

function Section({
  title,
  children,
}: {
  title: string
  children: React.ReactNode
}) {
  return (
    <div className="space-y-2">
      <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
        {title}
      </h3>
      <div className="grid grid-cols-1 gap-1.5">
        {children}
      </div>
    </div>
  )
}

export default function PalettePanel({
  onSelectStateBlock,
  onSelectTransitionBlock,
  onApplyTemplate,
  className,
}: PalettePanelProps) {
  return (
    <div
      className={cn(
        'w-[320px] rounded-lg border border-border bg-background/95 p-3 shadow-md backdrop-blur-sm',
        className
      )}
      aria-label="FSM building blocks palette"
    >
      <div className="mb-3">
        <h2 className="text-sm font-semibold">Palette</h2>
        <p className="text-xs text-muted-foreground">Quick building blocks for FSM authoring</p>
      </div>

      <div className="space-y-4">
        <Section title="States">
          {STATE_BLOCKS.map((block) => {
            const Icon = block.icon
            return (
              <Button
                key={block.id}
                type="button"
                variant="outline"
                className="h-auto items-start justify-start px-2 py-2"
                title={block.description}
                onClick={() => onSelectStateBlock(block.id)}
              >
                <div className="flex items-start gap-2 text-left">
                  <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <div>
                    <div className="text-xs font-medium leading-tight">{block.label}</div>
                    <div className="text-[10px] leading-tight text-muted-foreground">{block.description}</div>
                  </div>
                </div>
              </Button>
            )
          })}
        </Section>

        <Section title="Transitions">
          {TRANSITION_BLOCKS.map((block) => {
            const Icon = block.icon
            return (
              <Button
                key={block.id}
                type="button"
                variant="outline"
                className="h-auto items-start justify-start px-2 py-2"
                title={block.description}
                onClick={() => onSelectTransitionBlock(block.id)}
              >
                <div className="flex items-start gap-2 text-left">
                  <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <div>
                    <div className="text-xs font-medium leading-tight">{block.label}</div>
                    <div className="text-[10px] leading-tight text-muted-foreground">{block.description}</div>
                  </div>
                </div>
              </Button>
            )
          })}
        </Section>

        <Section title="Templates">
          {TEMPLATE_BLOCKS.map((block) => {
            const Icon = block.icon
            return (
              <Button
                key={block.id}
                type="button"
                variant="secondary"
                className="h-auto items-start justify-start px-2 py-2"
                title={block.description}
                onClick={() => onApplyTemplate(block.id)}
              >
                <div className="flex items-start gap-2 text-left">
                  <Icon className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <div>
                    <div className="text-xs font-medium leading-tight">{block.label}</div>
                    <div className="text-[10px] leading-tight text-muted-foreground">{block.description}</div>
                  </div>
                </div>
              </Button>
            )
          })}
        </Section>
      </div>
    </div>
  )
}
