'use client'

import { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { FSMStateVariable } from '@/lib/types/fsm'

const STATE_VAR_TYPES = ['string', 'number', 'boolean', 'object'] as const

export interface StateVariableModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  variable: FSMStateVariable
  existingKeys: string[]
  onSave: (variable: FSMStateVariable) => void
  title?: string
  description?: string
}

export function StateVariableModal({
  open,
  onOpenChange,
  variable,
  existingKeys,
  onSave,
  title = 'State variable',
  description = 'Define a context key for guards and actions. Optional validation when meta.validate_context is true.',
}: StateVariableModalProps) {
  const [key, setKey] = useState(variable.key)
  const [type, setType] = useState<string>(variable.type ?? '')
  const [required, setRequired] = useState(variable.required ?? false)
  const [descriptionVal, setDescriptionVal] = useState(variable.description ?? '')
  const [defaultVal, setDefaultVal] = useState(
    variable.default !== undefined && variable.default !== null
      ? typeof variable.default === 'object'
        ? JSON.stringify(variable.default)
        : String(variable.default)
      : ''
  )

  useEffect(() => {
    if (open) {
      setKey(variable.key)
      setType(variable.type ?? '')
      setRequired(variable.required ?? false)
      setDescriptionVal(variable.description ?? '')
      setDefaultVal(
        variable.default !== undefined && variable.default !== null
          ? typeof variable.default === 'object'
            ? JSON.stringify(variable.default)
            : String(variable.default)
          : ''
      )
    }
  }, [open, variable])

  const keyError =
    key.trim() === ''
      ? 'Key is required'
      : existingKeys.includes(key.trim())
        ? 'Key already exists'
        : null

  const handleSave = () => {
    if (keyError) return
    const keyTrimmed = key.trim()
    let defaultParsed: unknown = undefined
    if (defaultVal.trim()) {
      const raw = defaultVal.trim()
      if (raw === 'true') defaultParsed = true
      else if (raw === 'false') defaultParsed = false
      else if (raw === 'null') defaultParsed = null
      else if (/^-?\d+$/.test(raw)) defaultParsed = parseInt(raw, 10)
      else if (/^-?\d*\.?\d+$/.test(raw)) defaultParsed = parseFloat(raw)
      else {
        try {
          defaultParsed = JSON.parse(raw)
        } catch {
          defaultParsed = raw
        }
      }
    }
    onSave({
      key: keyTrimmed,
      type: type || undefined,
      required: required || undefined,
      description: descriptionVal.trim() || undefined,
      default: defaultParsed,
    })
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" showClose>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="sv-key">Key</Label>
            <Input
              id="sv-key"
              className="h-9"
              placeholder="e.g. order_id"
              value={key}
              onChange={(e) => setKey(e.target.value)}
            />
            {keyError && (
              <p className="text-xs text-destructive">{keyError}</p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="sv-type">Type</Label>
            <select
              id="sv-type"
              className="h-9 w-full rounded-md border border-input bg-background px-3 text-sm"
              value={type}
              onChange={(e) => setType(e.target.value)}
            >
              <option value="">—</option>
              {STATE_VAR_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={required}
              onChange={(e) => setRequired(e.target.checked)}
              className="rounded border-input"
            />
            <span className="text-sm">Required</span>
          </label>
          <div className="space-y-2">
            <Label htmlFor="sv-desc">Description (optional)</Label>
            <Input
              id="sv-desc"
              className="h-9"
              placeholder="Human-readable description"
              value={descriptionVal}
              onChange={(e) => setDescriptionVal(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="sv-default">Default (optional)</Label>
            <Input
              id="sv-default"
              className="h-9 font-mono text-sm"
              placeholder='e.g. 0 or "pending"'
              value={defaultVal}
              onChange={(e) => setDefaultVal(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!!keyError}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
