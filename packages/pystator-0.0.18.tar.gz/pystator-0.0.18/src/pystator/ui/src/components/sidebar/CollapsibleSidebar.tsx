/**
 * Collapsible Sidebar Component
 *
 * A reusable collapsible sidebar with sections and navigation items.
 * Mirrors PyCharter's CollapsibleSidebar for consistent UX.
 */

'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight, ChevronDown, ChevronUp, type LucideIcon } from 'lucide-react'

export interface SidebarSection {
  id: string
  title: string
  icon?: LucideIcon
  items: SidebarItem[]
}

export interface SidebarItem {
  id: string
  label: string
  href?: string
  onClick?: () => void
}

interface CollapsibleSidebarProps {
  sections: SidebarSection[]
  defaultCollapsed?: boolean
  onItemClick?: (sectionId: string, itemId: string) => void
  onSectionClick?: (sectionId: string) => void
  selectedSection?: string
  headerTitle?: string
}

export function CollapsibleSidebar({
  sections,
  defaultCollapsed = false,
  onItemClick,
  onSectionClick,
  selectedSection,
  headerTitle = 'Navigation',
}: CollapsibleSidebarProps) {
  const [isCollapsed, setIsCollapsed] = useState(defaultCollapsed)
  const [expandedSections, setExpandedSections] = useState<Set<string>>(
    new Set(sections.map((s) => s.id))
  )

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed)
  }

  const toggleSection = (sectionId: string) => {
    setExpandedSections((prev) => {
      const next = new Set(prev)
      if (next.has(sectionId)) {
        next.delete(sectionId)
      } else {
        next.add(sectionId)
      }
      return next
    })
  }

  const handleItemClick = (sectionId: string, itemId: string, item: SidebarItem) => {
    if (item.onClick) {
      item.onClick()
    }
    if (onItemClick) {
      onItemClick(sectionId, itemId)
    }
  }

  return (
    <div
      className={`flex flex-col bg-background border-r border-border/50 shadow-sm transition-all duration-300 ${
        isCollapsed ? 'w-16' : 'w-64'
      }`}
      style={{ height: '100%', overflow: 'hidden' }}
    >
      <div className="flex items-center justify-between px-4 py-3 border-b border-border/50 bg-muted/30">
        {!isCollapsed && (
          <h2 className="text-sm font-semibold text-foreground tracking-wide">{headerTitle}</h2>
        )}
        <button
          onClick={toggleCollapse}
          className="p-1.5 rounded-md hover:bg-muted transition-all duration-200 hover:scale-105 active:scale-95"
          aria-label={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed ? (
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          ) : (
            <ChevronLeft className="h-4 w-4 text-muted-foreground" />
          )}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto overflow-x-hidden px-2 py-3" style={{ maxHeight: '100%' }}>
        <div className="space-y-1">
          {sections.map((section) => {
            const isExpanded = expandedSections.has(section.id)
            return (
              <div key={section.id} className="mb-1">
                <button
                  onClick={() => {
                    if (onSectionClick) onSectionClick(section.id)
                    toggleSection(section.id)
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-all duration-200 ${
                    isCollapsed
                      ? 'justify-center hover:bg-muted/50'
                      : selectedSection === section.id
                        ? 'bg-primary/10 text-primary hover:bg-primary/15'
                        : 'hover:bg-muted/50 hover:shadow-sm'
                  }`}
                  title={isCollapsed ? section.title : undefined}
                >
                  {isCollapsed ? (
                    section.icon ? (
                      <section.icon
                        className={`h-5 w-5 transition-colors ${
                          selectedSection === section.id ? 'text-primary' : 'text-muted-foreground'
                        }`}
                      />
                    ) : (
                      <span
                        className={`text-xs font-semibold ${
                          selectedSection === section.id ? 'text-primary' : 'text-muted-foreground'
                        }`}
                      >
                        {section.title.charAt(0).toUpperCase()}
                      </span>
                    )
                  ) : (
                    <>
                      <div className="flex items-center gap-2.5">
                        {section.icon && (
                          <section.icon
                            className={`h-4 w-4 transition-colors ${
                              selectedSection === section.id ? 'text-primary' : 'text-muted-foreground'
                            }`}
                          />
                        )}
                        <span
                          className={`text-sm font-medium ${
                            selectedSection === section.id ? 'text-primary' : 'text-foreground'
                          }`}
                        >
                          {section.title}
                        </span>
                      </div>
                      {isExpanded ? (
                        <ChevronUp className="h-3.5 w-3.5 text-muted-foreground transition-transform duration-200" />
                      ) : (
                        <ChevronDown className="h-3.5 w-3.5 text-muted-foreground transition-transform duration-200" />
                      )}
                    </>
                  )}
                </button>

                {!isCollapsed && isExpanded && (
                  <div className="ml-1 mt-1 space-y-0.5 pl-2 border-l-2 border-muted">
                    {section.items.map((item) => (
                      <button
                        key={item.id}
                        onClick={() => handleItemClick(section.id, item.id, item)}
                        className="w-full text-left px-3 py-2 text-sm text-muted-foreground hover:text-foreground hover:bg-muted/50 rounded-md transition-all duration-200 hover:translate-x-0.5"
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  )
}
