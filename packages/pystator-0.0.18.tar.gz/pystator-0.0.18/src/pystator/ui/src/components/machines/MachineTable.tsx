'use client'

import { Button } from '@/components/ui/button'
import type { MachineListItem } from '@/lib/api'
import { formatDateShort, formatDateTimeShort, truncate } from '@/lib/utils'
import { Download, ExternalLink, Pencil, Trash2 } from 'lucide-react'

interface MachineTableProps {
  machines: MachineListItem[]
  onOpen: (machine: MachineListItem) => void
  onEdit: (machine: MachineListItem) => void
  onDelete: (machine: MachineListItem) => void
  onDownload: (machine: MachineListItem) => void
  downloadingId?: string | null
}

export default function MachineTable({ machines, onOpen, onEdit, onDelete, onDownload, downloadingId }: MachineTableProps) {
  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="min-w-full divide-y divide-border">
        <thead className="bg-muted/50">
          <tr>
            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Name
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider hidden md:table-cell">
              Version
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider hidden lg:table-cell">
              Created
            </th>
            <th className="px-6 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider hidden xl:table-cell">
              Updated
            </th>
            <th className="px-6 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border bg-background">
          {machines.map((m) => (
            <tr key={m.id} className="hover:bg-muted/30 transition-colors">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm font-medium text-foreground">{m.name}</div>
                {m.description && (
                  <div className="text-sm text-muted-foreground hidden sm:block">
                    {truncate(m.description, 50)}
                  </div>
                )}
              </td>
              <td className="px-6 py-4 text-sm text-muted-foreground whitespace-nowrap hidden md:table-cell">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-muted">
                  {m.version}
                </span>
              </td>
              <td className="px-6 py-4 text-sm text-muted-foreground whitespace-nowrap hidden lg:table-cell">
                {m.created_at ? formatDateShort(m.created_at) : '—'}
              </td>
              <td className="px-6 py-4 text-sm text-muted-foreground whitespace-nowrap hidden xl:table-cell">
                {m.updated_at ? formatDateTimeShort(m.updated_at) : '—'}
              </td>
              <td className="px-6 py-4 text-right whitespace-nowrap">
                <div className="flex items-center justify-end gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onOpen(m)}
                    className="h-8"
                    title="Open machine"
                  >
                    <ExternalLink className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEdit(m)}
                    className="h-8"
                    title="Edit machine"
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDownload(m)}
                    disabled={downloadingId === m.id}
                    className="h-8"
                    title="Download config"
                  >
                    <Download className={`h-4 w-4 ${downloadingId === m.id ? 'animate-pulse' : ''}`} />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDelete(m)}
                    className="h-8 text-destructive hover:text-destructive hover:bg-destructive/10"
                    title="Delete machine"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
