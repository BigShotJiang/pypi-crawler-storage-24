'use client'

import { useCallback, useEffect, useState } from 'react'
import { PageHeader } from '@/components/common'
import { PageContainer } from '@/components/layout'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import ErrorDisplay from '@/components/ErrorDisplay'
import LoadingSpinner from '@/components/LoadingSpinner'
import FsmFlowDiagram from '@/components/fsm-flow/FsmFlowDiagram'
import SendEventForm from '@/components/entities/SendEventForm'
import TransitionHistory from '@/components/entities/TransitionHistory'
import { getEntityState, getEntityHistory, deleteEntity } from '@/lib/api'
import type { EntityState, TransitionHistoryEntry } from '@/lib/api'
import { useMachineConfigByName } from '@/hooks/useMachineConfigByName'
import { getTriggersFromState } from '@/lib/fsmConfigUtils'
import { ArrowLeft, Trash2, RefreshCw } from 'lucide-react'

function StateBadge({ state }: { state: string }) {
  const lower = state.toLowerCase()
  let colorClass = 'bg-primary/10 text-primary'
  if (lower.includes('error') || lower.includes('fail') || lower.includes('reject')) {
    colorClass = 'bg-destructive/10 text-destructive'
  } else if (
    lower.includes('complete') ||
    lower.includes('done') ||
    lower.includes('success') ||
    lower.includes('approved')
  ) {
    colorClass = 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400'
  } else if (lower === 'initial' || lower === 'start' || lower === 'idle') {
    colorClass = 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
  }

  return (
    <span
      className={`inline-flex items-center px-2.5 py-1 rounded-md text-sm font-medium ${colorClass}`}
    >
      {state}
    </span>
  )
}

export interface EntityDetailViewProps {
  entityId: string
  onBack: () => void
}

export default function EntityDetailView({ entityId, onBack }: EntityDetailViewProps) {
  const [entity, setEntity] = useState<EntityState | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<Error | null>(null)
  const [refreshKey, setRefreshKey] = useState(0)
  const [showContext, setShowContext] = useState(false)
  const [lastTransition, setLastTransition] = useState<TransitionHistoryEntry | null>(null)

  const { config: machineConfig, loading: configLoading, error: configError } =
    useMachineConfigByName(entity?.machine_name ?? null)

  const fetchEntity = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await getEntityState(entityId)
      setEntity(data)
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    } finally {
      setLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    fetchEntity()
  }, [fetchEntity])

  useEffect(() => {
    if (!entityId || !entity) return
    getEntityHistory(entityId, 1, 0)
      .then((entries) => setLastTransition(entries[0] ?? null))
      .catch(() => setLastTransition(null))
  }, [entityId, entity, refreshKey])

  const handleEventSuccess = () => {
    fetchEntity()
    setRefreshKey((k) => k + 1)
  }

  const handleDelete = async () => {
    const confirmed = window.confirm(
      `Delete entity "${entityId}"? This will remove its state and all transition history.`
    )
    if (!confirmed) return
    try {
      await deleteEntity(entityId)
      onBack()
    } catch (e) {
      setError(e instanceof Error ? e : new Error(String(e)))
    }
  }

  if (loading && !entity) {
    return (
      <PageContainer>
        <div className="flex justify-center py-20">
          <LoadingSpinner />
        </div>
      </PageContainer>
    )
  }

  return (
    <PageContainer>
      <PageHeader
        title={`Entity: ${entityId}`}
        description={entity ? `Machine: ${entity.machine_name ?? 'unknown'}` : ''}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onBack} className="gap-1.5">
              <ArrowLeft className="h-4 w-4" /> Back
            </Button>
            <Button variant="outline" size="sm" onClick={fetchEntity} className="gap-1.5">
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleDelete}
              className="text-destructive hover:text-destructive hover:bg-destructive/10 gap-1.5"
            >
              <Trash2 className="h-4 w-4" /> Delete
            </Button>
          </div>
        }
      />

      {error && <ErrorDisplay error={error} className="mt-4" />}

      {entity && (
        <div className="space-y-6 mt-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">State Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <div>
                  <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                    Entity ID
                  </dt>
                  <dd className="text-sm font-mono break-all">{entity.entity_id}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                    Machine
                  </dt>
                  <dd className="text-sm">{entity.machine_name ?? '—'}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                    Current State
                  </dt>
                  <dd>
                    <StateBadge state={entity.current_state} />
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                    Created
                  </dt>
                  <dd className="text-sm text-muted-foreground">
                    {entity.created_at ? new Date(entity.created_at).toLocaleString() : '—'}
                  </dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground uppercase tracking-wider mb-1">
                    Updated
                  </dt>
                  <dd className="text-sm text-muted-foreground">
                    {entity.updated_at ? new Date(entity.updated_at).toLocaleString() : '—'}
                  </dd>
                </div>
              </dl>

              {entity.context && Object.keys(entity.context).length > 0 && (
                <div className="mt-4 border-t pt-4">
                  <button
                    type="button"
                    onClick={() => setShowContext(!showContext)}
                    className="text-sm font-medium text-primary hover:underline"
                  >
                    {showContext ? 'Hide' : 'Show'} Context (
                    {Object.keys(entity.context).length} key
                    {Object.keys(entity.context).length === 1 ? '' : 's'})
                  </button>
                  {showContext && (
                    <pre className="mt-2 rounded-lg bg-muted p-3 text-xs font-mono overflow-x-auto max-h-[300px]">
                      {JSON.stringify(entity.context, null, 2)}
                    </pre>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {entity.machine_name && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">State diagram</CardTitle>
                <CardDescription>
                  Current state is highlighted with a ring. Last transition edge is animated.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {configLoading && !machineConfig && (
                  <div
                    className="flex items-center justify-center rounded border bg-muted/30"
                    style={{ minHeight: 320 }}
                  >
                    <LoadingSpinner />
                  </div>
                )}
                {configError && !machineConfig && (
                  <p className="text-sm text-muted-foreground py-4">
                    Machine &quot;{entity.machine_name}&quot; not found. Diagram unavailable.
                  </p>
                )}
                {machineConfig && (
                  <>
                    {lastTransition && (
                      <p className="text-sm text-muted-foreground mb-3">
                        Last transition:{' '}
                        <span className="font-medium text-foreground">
                          {lastTransition.source_state} → {lastTransition.target_state}
                        </span>{' '}
                        (trigger:{' '}
                        <code className="text-xs bg-muted px-1 rounded">
                          {lastTransition.trigger}
                        </code>
                        )
                      </p>
                    )}
                    <FsmFlowDiagram
                      config={machineConfig}
                      minHeight={400}
                      showGuards
                      showActions={false}
                      highlightState={entity.current_state}
                      highlightTransition={
                        lastTransition?.source_state &&
                        lastTransition?.target_state &&
                        lastTransition?.trigger
                          ? {
                              source: lastTransition.source_state,
                              target: lastTransition.target_state,
                              trigger: lastTransition.trigger,
                            }
                          : null
                      }
                    />
                  </>
                )}
              </CardContent>
            </Card>
          )}

          <SendEventForm
            entityId={entityId}
            defaultMachineName={entity.machine_name}
            availableTriggers={
              machineConfig && entity.current_state
                ? getTriggersFromState(machineConfig, entity.current_state)
                : undefined
            }
            stateVariables={machineConfig?.state_variables ?? []}
            onSuccess={handleEventSuccess}
          />

          <TransitionHistory entityId={entityId} refreshKey={refreshKey} />
        </div>
      )}
    </PageContainer>
  )
}
