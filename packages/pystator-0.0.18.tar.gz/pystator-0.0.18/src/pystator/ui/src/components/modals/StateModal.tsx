'use client'

import { useState, useEffect, useMemo } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import type { FSMState, FSMRegion } from '@/lib/types/fsm'
import { normalizeName, validateName } from '@/lib/utils'

const STATE_TYPES: FSMState['type'][] = ['initial', 'stable', 'terminal', 'error', 'parallel']

function regionsToString(regions: FSMRegion[] | undefined): string {
  if (!regions || regions.length === 0) return ''
  return regions.map(r => `${r.name}:${r.initial}`).join(', ')
}

function parseRegions(input: string): FSMRegion[] | undefined {
  const trimmed = input.trim()
  if (!trimmed) return undefined
  const regions: FSMRegion[] = []
  const parts = trimmed.split(',').map(s => s.trim()).filter(Boolean)
  for (const part of parts) {
    const [name, initial] = part.split(':').map(s => s.trim())
    if (name && initial) {
      regions.push({ name, initial })
    }
  }
  return regions.length > 0 ? regions : undefined
}

function getContextKeys(metadata: Record<string, unknown> | undefined): string[] {
  const raw = metadata?.context_keys
  if (!Array.isArray(raw)) return []
  return raw.filter((x): x is string => typeof x === 'string')
}

function contextKeysToString(keys: string[]): string {
  return keys.join(', ')
}

function parseContextKeys(input: string): string[] {
  if (!input.trim()) return []
  return input.split(',').map((s) => s.trim()).filter(Boolean)
}

export interface StateModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  state: FSMState
  existingStateNames: string[]
  onSave: (state: FSMState) => void
  title?: string
  description?: string
  /** When set, a "Suggest from state variables" button fills context keys from machine-level state_variables. */
  machineStateVariableKeys?: string[]
}

export function StateModal({
  open,
  onOpenChange,
  state,
  existingStateNames,
  onSave,
  title = 'State',
  description = 'Add or edit state name, type, hierarchy, and optional hooks.',
  machineStateVariableKeys,
}: StateModalProps) {
  const [name, setName] = useState(state.name)
  const [type, setType] = useState<FSMState['type']>(state.type ?? 'stable')
  const [descriptionVal, setDescriptionVal] = useState(state.description ?? '')
  const [parent, setParent] = useState(state.parent ?? '')
  const [initialChild, setInitialChild] = useState(state.initial_child ?? '')
  const [regions, setRegions] = useState(regionsToString(state.regions))
  const [onEnter, setOnEnter] = useState(
    Array.isArray(state.on_enter) ? state.on_enter.join(', ') : (state.on_enter ?? '')
  )
  const [onExit, setOnExit] = useState(
    Array.isArray(state.on_exit) ? state.on_exit.join(', ') : (state.on_exit ?? '')
  )
  const [timeoutSec, setTimeoutSec] = useState(state.timeout?.seconds?.toString() ?? '')
  const [timeoutDest, setTimeoutDest] = useState(state.timeout?.destination ?? '')
  const [contextKeysInput, setContextKeysInput] = useState(
    contextKeysToString(getContextKeys(state.metadata))
  )

  useEffect(() => {
    if (open) {
      setName(state.name)
      setType(state.type ?? 'stable')
      setDescriptionVal(state.description ?? '')
      setParent(state.parent ?? '')
      setInitialChild(state.initial_child ?? '')
      setRegions(regionsToString(state.regions))
      setOnEnter(Array.isArray(state.on_enter) ? state.on_enter.join(', ') : (state.on_enter ?? ''))
      setOnExit(Array.isArray(state.on_exit) ? state.on_exit.join(', ') : (state.on_exit ?? ''))
      setTimeoutSec(state.timeout?.seconds?.toString() ?? '')
      setTimeoutDest(state.timeout?.destination ?? '')
      setContextKeysInput(contextKeysToString(getContextKeys(state.metadata)))
    }
  }, [open, state])

  const normalizedName = useMemo(() => normalizeName(name), [name])
  const nameValidation = useMemo(() => {
    if (!name.trim()) return { valid: false, error: '' }
    if (!normalizedName) return { valid: false, error: 'Name produces no valid characters' }
    try {
      validateName(normalizedName)
      return { valid: true, error: '' }
    } catch (e) {
      return { valid: false, error: e instanceof Error ? e.message : 'Invalid name' }
    }
  }, [name, normalizedName])
  const showNameHint = name.trim() !== '' && normalizedName !== '' && normalizedName !== name.trim().toLowerCase()

  const isParallel = type === 'parallel'
  const availableParents = existingStateNames.filter(n => n !== name)

  const handleSave = () => {
    if (!nameValidation.valid) return
    const parsedKeys = parseContextKeys(contextKeysInput)
    const metadata: Record<string, unknown> = { ...(state.metadata ?? {}) }
    if (parsedKeys.length > 0) {
      metadata.context_keys = parsedKeys
    } else {
      delete metadata.context_keys
    }
    const next: FSMState = {
      name: normalizedName,
      type,
      description: descriptionVal.trim() || undefined,
      parent: parent.trim() || undefined,
      initial_child: initialChild.trim() || undefined,
      regions: isParallel ? parseRegions(regions) : undefined,
      on_enter: onEnter.trim() ? onEnter.split(',').map((s) => s.trim()).filter(Boolean) : undefined,
      on_exit: onExit.trim() ? onExit.split(',').map((s) => s.trim()).filter(Boolean) : undefined,
      timeout:
        timeoutSec && timeoutDest
          ? { seconds: parseFloat(timeoutSec), destination: timeoutDest.trim() }
          : undefined,
      metadata: Object.keys(metadata).length > 0 ? metadata : undefined,
    }
    onSave(next)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg max-h-[90vh] overflow-y-auto" showClose>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="state-name">Name</Label>
              <Input
                id="state-name"
                className="h-9"
                placeholder="e.g. open"
                value={name}
                onChange={(e) => setName(e.target.value)}
              />
              {showNameHint && (
                <p className="text-xs text-muted-foreground">
                  Will be saved as: <span className="font-mono font-medium text-foreground">{normalizedName}</span>
                </p>
              )}
              {nameValidation.error && (
                <p className="text-xs text-destructive">{nameValidation.error}</p>
              )}
              <p className="text-xs text-muted-foreground">
                Only lowercase letters, numbers, and underscores allowed.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="state-type">Type</Label>
              <select
                id="state-type"
                className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                value={type}
                onChange={(e) => setType(e.target.value as FSMState['type'])}
              >
                {STATE_TYPES.map((t) => (
                  <option key={t} value={t}>
                    {t} {t === 'parallel' && '⊞'}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="state-desc">Description (optional)</Label>
            <Input
              id="state-desc"
              className="h-9"
              placeholder="Short description"
              value={descriptionVal}
              onChange={(e) => setDescriptionVal(e.target.value)}
            />
          </div>

          {/* Hierarchy section */}
          <div className="border-t pt-3">
            <p className="text-sm font-medium mb-2">Hierarchy (Statecharts)</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="state-parent">Parent State</Label>
                <select
                  id="state-parent"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                  value={parent}
                  onChange={(e) => setParent(e.target.value)}
                >
                  <option value="">None (top-level)</option>
                  {availableParents.map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="state-initial-child">Initial Child</Label>
                <select
                  id="state-initial-child"
                  className="flex h-9 w-full rounded-md border border-input bg-background px-3 py-1 text-sm"
                  value={initialChild}
                  onChange={(e) => setInitialChild(e.target.value)}
                >
                  <option value="">None</option>
                  {existingStateNames.filter(n => n !== name).map((n) => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-muted-foreground">
                  Default child when entering this compound state
                </p>
              </div>
            </div>
          </div>

          {/* Parallel state regions */}
          {isParallel && (
            <div className="border-t pt-3">
              <p className="text-sm font-medium mb-2">Parallel State Regions ⊞</p>
              <div className="space-y-2">
                <Label htmlFor="state-regions">Regions (name:initial, ...)</Label>
                <Input
                  id="state-regions"
                  className="h-9"
                  placeholder="trading:scanning, risk:normal"
                  value={regions}
                  onChange={(e) => setRegions(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Each region is independent. Format: regionName:initialState
                </p>
              </div>
            </div>
          )}

          {/* Actions section */}
          <div className="border-t pt-3">
            <p className="text-sm font-medium mb-2">Actions</p>
            <div className="space-y-2">
              <Label htmlFor="state-enter">on_enter (comma-separated)</Label>
              <Input
                id="state-enter"
                className="h-9"
                placeholder="action1, action2"
                value={onEnter}
                onChange={(e) => setOnEnter(e.target.value)}
              />
            </div>
            <div className="space-y-2 mt-2">
              <Label htmlFor="state-exit">on_exit (comma-separated)</Label>
              <Input
                id="state-exit"
                className="h-9"
                placeholder="action1"
                value={onExit}
                onChange={(e) => setOnExit(e.target.value)}
              />
            </div>
          </div>

          {/* Timeout section */}
          <div className="border-t pt-3">
            <p className="text-sm font-medium mb-2">Timeout</p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="state-timeout-sec">Timeout (seconds)</Label>
                <Input
                  id="state-timeout-sec"
                  className="h-9"
                  type="number"
                  step="0.1"
                  placeholder="0"
                  value={timeoutSec}
                  onChange={(e) => setTimeoutSec(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state-timeout-dest">Timeout → state</Label>
                <Input
                  id="state-timeout-dest"
                  className="h-9"
                  placeholder="State name"
                  value={timeoutDest}
                  onChange={(e) => setTimeoutDest(e.target.value)}
                />
              </div>
            </div>
          </div>

          {/* State variables (context keys) – reference metadata only */}
          <div className="border-t pt-3">
            <p className="text-sm font-medium mb-2">State variables (context keys)</p>
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <Label htmlFor="state-context-keys" className="shrink-0">Context keys (comma-separated, reference only)</Label>
                {machineStateVariableKeys && machineStateVariableKeys.length > 0 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="h-8 text-xs"
                    onClick={() => setContextKeysInput(machineStateVariableKeys.join(', '))}
                  >
                    Suggest from state variables
                  </Button>
                )}
              </div>
              <Input
                id="state-context-keys"
                className="h-9"
                placeholder="e.g. flight_id, departure_time, origin"
                value={contextKeysInput}
                onChange={(e) => setContextKeysInput(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Optional. Documents which context variables apply to this state. Not used by the engine.
              </p>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave} disabled={!nameValidation.valid}>
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
