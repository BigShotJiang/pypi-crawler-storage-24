'use client'

import { useState, useEffect } from 'react'
import { X, Save, AlertCircle, CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { getMachine, updateMachine } from '@/lib/api'
import type { MachineListItem } from '@/lib/api'
import type { FSMConfig } from '@/lib/types/fsm'
import LoadingSpinner from '@/components/LoadingSpinner'

type TabId =
  | 'overview'
  | 'state_variables'
  | 'states'
  | 'transitions'
  | 'actions'
  | 'guards'
  | 'error_policy'

interface MachineEditModalProps {
  isOpen: boolean
  machine: MachineListItem | null
  onClose: () => void
  onSuccess: () => void
}

export default function MachineEditModal({
  isOpen,
  machine,
  onClose,
  onSuccess,
}: MachineEditModalProps) {
  const [config, setConfig] = useState<FSMConfig | null>(null)
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)
  const [activeTab, setActiveTab] = useState<TabId>('overview')

  // Form state: overview (meta)
  const [machineName, setMachineName] = useState('')
  const [version, setVersion] = useState('')
  const [description, setDescription] = useState('')
  const [strictMode, setStrictMode] = useState(true)
  // JSON-editable sections
  const [stateVariablesJson, setStateVariablesJson] = useState('')
  const [statesJson, setStatesJson] = useState('')
  const [transitionsJson, setTransitionsJson] = useState('')
  const [actionsJson, setActionsJson] = useState('')
  const [guardsJson, setGuardsJson] = useState('')
  // Error policy (form fields)
  const [errorPolicyDefaultFallback, setErrorPolicyDefaultFallback] = useState('')
  const [errorPolicyRetryAttempts, setErrorPolicyRetryAttempts] = useState('')

  useEffect(() => {
    if (machine && isOpen) {
      loadMachine()
    }
  }, [machine, isOpen])

  useEffect(() => {
    if (config) {
      const meta = config.meta ?? {}
      setMachineName(meta.machine_name ?? '')
      setVersion(meta.version ?? '1.0.0')
      setDescription((meta as { description?: string }).description ?? '')
      setStrictMode(meta.strict_mode ?? true)
      setStateVariablesJson(
        config.state_variables != null
          ? JSON.stringify(config.state_variables, null, 2)
          : ''
      )
      setStatesJson(
        config.states != null ? JSON.stringify(config.states, null, 2) : ''
      )
      setTransitionsJson(
        config.transitions != null
          ? JSON.stringify(config.transitions, null, 2)
          : ''
      )
      const actions = (config as { actions?: unknown }).actions
      setActionsJson(
        actions != null ? JSON.stringify(actions, null, 2) : ''
      )
      const guards = (config as { guards?: unknown }).guards
      setGuardsJson(guards != null ? JSON.stringify(guards, null, 2) : '')
      const ep = config.error_policy
      setErrorPolicyDefaultFallback(ep?.default_fallback ?? '')
      setErrorPolicyRetryAttempts(String(ep?.retry_attempts ?? 0))
    }
  }, [config])

  const loadMachine = async () => {
    if (!machine) return
    try {
      setLoading(true)
      setError(null)
      const res = await getMachine(machine.id)
      setConfig(res.config)
    } catch (err) {
      const e = err as { message?: string; response?: { detail?: string } }
      setError(
        (e.response as { detail?: string })?.detail ?? e.message ?? 'Failed to load machine'
      )
    } finally {
      setLoading(false)
    }
  }

  const buildConfigFromForm = (): FSMConfig => {
    const meta = {
      ...(config?.meta ?? {}),
      machine_name: machineName || undefined,
      version: version || undefined,
      description: description || undefined,
      strict_mode: strictMode,
    }

    let state_variables: FSMConfig['state_variables']
    try {
      state_variables =
        stateVariablesJson.trim() === ''
          ? undefined
          : (JSON.parse(stateVariablesJson) as FSMConfig['state_variables'])
    } catch {
      state_variables = config?.state_variables
    }

    let states: FSMConfig['states']
    try {
      states =
        statesJson.trim() === '' ? undefined : (JSON.parse(statesJson) as FSMConfig['states'])
    } catch {
      states = config?.states
    }

    let transitions: FSMConfig['transitions']
    try {
      transitions =
        transitionsJson.trim() === ''
          ? undefined
          : (JSON.parse(transitionsJson) as FSMConfig['transitions'])
    } catch {
      transitions = config?.transitions
    }

    let actions: unknown
    try {
      actions =
        actionsJson.trim() === ''
          ? undefined
          : JSON.parse(actionsJson)
    } catch {
      actions = (config as { actions?: unknown })?.actions
    }

    let guards: unknown
    try {
      guards =
        guardsJson.trim() === '' ? undefined : JSON.parse(guardsJson)
    } catch {
      guards = (config as { guards?: unknown })?.guards
    }

    const retryNum = Math.max(0, parseInt(errorPolicyRetryAttempts, 10) || 0)
    const error_policy =
      errorPolicyDefaultFallback.trim() || retryNum > 0
        ? {
            default_fallback: errorPolicyDefaultFallback.trim() || undefined,
            retry_attempts: retryNum,
          }
        : undefined

    const out: FSMConfig & { actions?: unknown; guards?: unknown } = {
      ...(config ?? {}),
      meta,
      state_variables,
      states,
      transitions,
      error_policy,
    }
    if (actions !== undefined) out.actions = actions
    if (guards !== undefined) out.guards = guards
    return out
  }

  const handleSave = async () => {
    if (!machine) return
    try {
      setSaving(true)
      setError(null)
      setSuccess(false)
      const newConfig = buildConfigFromForm()
      await updateMachine(machine.id, newConfig)
      setSuccess(true)
      setTimeout(() => {
        onSuccess()
        handleClose()
      }, 1200)
    } catch (err) {
      const e = err as { message?: string; response?: { detail?: string } }
      let msg = e.message ?? 'Failed to update machine'
      const detail = (e.response as { detail?: string | { message?: string; errors?: string[] } })
        ?.detail
      if (typeof detail === 'string') msg = detail
      else if (detail && typeof detail === 'object' && detail.message) msg = detail.message
      setError(msg)
    } finally {
      setSaving(false)
    }
  }

  const handleClose = () => {
    setError(null)
    setSuccess(false)
    setConfig(null)
    onClose()
  }

  if (!isOpen || !machine) return null

  const tabs: { id: TabId; label: string }[] = [
    { id: 'overview', label: 'Overview' },
    { id: 'state_variables', label: 'State variables' },
    { id: 'states', label: 'States' },
    { id: 'transitions', label: 'Transitions' },
    { id: 'actions', label: 'Actions' },
    { id: 'guards', label: 'Guards' },
    { id: 'error_policy', label: 'Error policy' },
  ]

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
      onClick={handleClose}
    >
      <div
        className="bg-background rounded-lg shadow-lg max-w-4xl w-full mx-4 p-6 max-h-[90vh] overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Edit machine: {machine.name}</h2>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-4 border-b">
          {tabs.map(({ id, label }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id)}
              className={`px-4 py-2 text-sm font-medium border-b-2 transition-colors ${
                activeTab === id
                  ? 'border-primary text-primary'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto min-h-0">
          {loading && (
            <div className="flex justify-center items-center py-12">
              <LoadingSpinner />
              <span className="ml-2 text-sm text-muted-foreground">
                Loading machine...
              </span>
            </div>
          )}

          {error && !loading && (
            <div className="mb-4 flex items-start gap-2 p-3 bg-destructive/10 border border-destructive/50 rounded-md">
              <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
              <div className="text-sm text-destructive">
                <p className="font-medium">Error</p>
                <p className="mt-1">{error}</p>
              </div>
            </div>
          )}

          {success && (
            <div className="mb-4 flex items-start gap-2 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md">
              <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-green-800 dark:text-green-200">
                <p className="font-medium">Saved</p>
                <p className="mt-1">Machine has been updated.</p>
              </div>
            </div>
          )}

          {!loading && config && (
            <>
              {activeTab === 'overview' && (
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Machine name <span className="text-destructive">*</span>
                    </label>
                    <input
                      type="text"
                      value={machineName}
                      onChange={(e) => setMachineName(e.target.value)}
                      disabled={saving}
                      className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Version <span className="text-destructive">*</span>
                    </label>
                    <input
                      type="text"
                      value={version}
                      onChange={(e) => setVersion(e.target.value)}
                      disabled={saving}
                      className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Description</label>
                    <textarea
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      disabled={saving}
                      rows={3}
                      className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 resize-none"
                    />
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="strict_mode"
                      checked={strictMode}
                      onChange={(e) => setStrictMode(e.target.checked)}
                      disabled={saving}
                      className="rounded border-input"
                    />
                    <label htmlFor="strict_mode" className="text-sm font-medium">
                      Strict mode (undefined triggers raise errors)
                    </label>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Machine ID</label>
                    <p className="text-sm text-muted-foreground font-mono break-all">
                      {machine.id}
                    </p>
                  </div>
                </div>
              )}

              {activeTab === 'state_variables' && (
                <div>
                  <label className="block text-sm font-medium mb-2">
                    State variables (JSON)
                  </label>
                  <textarea
                    value={stateVariablesJson}
                    onChange={(e) => setStateVariablesJson(e.target.value)}
                    disabled={saving}
                    rows={16}
                    className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 resize-none"
                    placeholder='[{"key": "order_id", "type": "string", "required": true}, ...]'
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Array of state variable definitions: key, type?, description?, default?,
                    required?
                  </p>
                </div>
              )}

              {activeTab === 'states' && (
                <div>
                  <label className="block text-sm font-medium mb-2">States (JSON)</label>
                  <textarea
                    value={statesJson}
                    onChange={(e) => setStatesJson(e.target.value)}
                    disabled={saving}
                    rows={20}
                    className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 resize-none"
                    placeholder='[{"name": "pending", "type": "initial"}, ...]'
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Array of state objects: name, type (initial|stable|terminal|error|parallel),
                    description?, parent?, initial_child?, on_enter?, on_exit?, etc.
                  </p>
                </div>
              )}

              {activeTab === 'transitions' && (
                <div>
                  <label className="block text-sm font-medium mb-2">Transitions (JSON)</label>
                  <textarea
                    value={transitionsJson}
                    onChange={(e) => setTransitionsJson(e.target.value)}
                    disabled={saving}
                    rows={20}
                    className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 resize-none"
                    placeholder='[{"trigger": "confirm", "source": "pending", "dest": "confirmed"}, ...]'
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Array of transitions: trigger, source (string or array), dest, guards?,
                    actions?, region?, after?, internal?, auto?
                  </p>
                </div>
              )}

              {activeTab === 'actions' && (
                <div>
                  <label className="block text-sm font-medium mb-2">Actions (JSON)</label>
                  <textarea
                    value={actionsJson}
                    onChange={(e) => setActionsJson(e.target.value)}
                    disabled={saving}
                    rows={14}
                    className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 resize-none"
                    placeholder='[{"name": "update_order_id", "description": "Updates order ID in context"}, ...]'
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Optional documentation of action names used in transitions and state
                    on_enter/on_exit. Array of objects: name, description?
                  </p>
                </div>
              )}

              {activeTab === 'guards' && (
                <div>
                  <label className="block text-sm font-medium mb-2">Guards (JSON)</label>
                  <textarea
                    value={guardsJson}
                    onChange={(e) => setGuardsJson(e.target.value)}
                    disabled={saving}
                    rows={14}
                    className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground font-mono text-sm focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50 resize-none"
                    placeholder='[{"name": "is_full_fill", "description": "True when order is fully filled"}, ...]'
                  />
                  <p className="text-xs text-muted-foreground mt-1">
                    Optional documentation of guard names used in transitions. Array of objects:
                    name, description?, expr? (inline expression).
                  </p>
                </div>
              )}

              {activeTab === 'error_policy' && (
                <div className="space-y-4">
                  <p className="text-sm text-muted-foreground">
                    Optional fallback state and retry behavior when transition or action execution
                    fails.
                  </p>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Default fallback state
                    </label>
                    <input
                      type="text"
                      value={errorPolicyDefaultFallback}
                      onChange={(e) => setErrorPolicyDefaultFallback(e.target.value)}
                      disabled={saving}
                      placeholder="e.g. ERROR_STATE"
                      className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Retry attempts</label>
                    <input
                      type="number"
                      min={0}
                      value={errorPolicyRetryAttempts}
                      onChange={(e) => setErrorPolicyRetryAttempts(e.target.value)}
                      disabled={saving}
                      className="w-full px-3 py-2 border border-input rounded-md bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-ring disabled:opacity-50"
                    />
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        <div className="flex justify-end gap-2 pt-4 border-t mt-4">
          <Button variant="outline" onClick={handleClose} disabled={saving}>
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={saving || !machineName || !version || loading}
          >
            <Save className="h-4 w-4 mr-2" />
            {saving ? 'Saving...' : 'Save changes'}
          </Button>
        </div>
      </div>
    </div>
  )
}
