'use client'

import { useCallback, useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { getEntityHistory } from '@/lib/api'
import type { TransitionHistoryEntry } from '@/lib/api'
import LoadingSpinner from '@/components/LoadingSpinner'
import { ChevronLeft, ChevronRight, CheckCircle2, XCircle } from 'lucide-react'

const PAGE_SIZE = 20

interface TransitionHistoryProps {
  entityId: string
  refreshKey: number
}

function formatTime(iso: string): string {
  try {
    return new Date(iso).toLocaleString()
  } catch {
    return iso
  }
}

export default function TransitionHistory({ entityId, refreshKey }: TransitionHistoryProps) {
  const [entries, setEntries] = useState<TransitionHistoryEntry[]>([])
  const [offset, setOffset] = useState(0)
  const [loading, setLoading] = useState(true)
  const [hasMore, setHasMore] = useState(false)

  const fetchHistory = useCallback(async (currentOffset: number) => {
    setLoading(true)
    try {
      const data = await getEntityHistory(entityId, PAGE_SIZE + 1, currentOffset)
      if (data.length > PAGE_SIZE) {
        setHasMore(true)
        setEntries(data.slice(0, PAGE_SIZE))
      } else {
        setHasMore(false)
        setEntries(data)
      }
    } catch {
      // silent – main page already handles connection errors
    } finally {
      setLoading(false)
    }
  }, [entityId])

  useEffect(() => {
    setOffset(0)
    fetchHistory(0)
  }, [fetchHistory, refreshKey])

  useEffect(() => {
    fetchHistory(offset)
  }, [fetchHistory, offset])

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Transition History</CardTitle>
      </CardHeader>
      <CardContent>
        {loading && entries.length === 0 ? (
          <div className="flex justify-center py-6">
            <LoadingSpinner size="sm" />
          </div>
        ) : entries.length === 0 ? (
          <p className="text-sm text-muted-foreground py-4 text-center">
            No transitions recorded yet.
          </p>
        ) : (
          <>
            <div className="overflow-x-auto rounded-lg border">
              <table className="min-w-full divide-y divide-border">
                <thead className="bg-muted/50">
                  <tr>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Time</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Trigger</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase">Transition</th>
                    <th className="px-3 py-2 text-center text-xs font-medium text-muted-foreground uppercase">Status</th>
                    <th className="px-3 py-2 text-left text-xs font-medium text-muted-foreground uppercase hidden lg:table-cell">Actions / Error</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-border bg-background">
                  {entries.map((entry) => (
                    <tr key={entry.id} className="hover:bg-muted/30 transition-colors">
                      <td className="px-3 py-2 text-xs text-muted-foreground whitespace-nowrap">
                        {formatTime(entry.created_at)}
                      </td>
                      <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">
                        {entry.trigger}
                      </td>
                      <td className="px-3 py-2 text-sm font-mono whitespace-nowrap">
                        {entry.source_state}
                        <span className="mx-1 text-muted-foreground">→</span>
                        {entry.target_state ?? '—'}
                      </td>
                      <td className="px-3 py-2 text-center">
                        {entry.success ? (
                          <CheckCircle2 className="h-4 w-4 text-emerald-500 inline-block" />
                        ) : (
                          <XCircle className="h-4 w-4 text-destructive inline-block" />
                        )}
                      </td>
                      <td className="px-3 py-2 text-xs text-muted-foreground hidden lg:table-cell max-w-[200px] truncate">
                        {entry.error_message
                          ? <span className="text-destructive">{entry.error_message}</span>
                          : entry.actions_executed?.join(', ') || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Pagination */}
            <div className="flex items-center justify-end gap-2 mt-3">
              <Button variant="outline" size="sm" disabled={offset === 0} onClick={() => setOffset((o) => Math.max(0, o - PAGE_SIZE))}>
                <ChevronLeft className="h-4 w-4 mr-1" /> Prev
              </Button>
              <Button variant="outline" size="sm" disabled={!hasMore} onClick={() => setOffset((o) => o + PAGE_SIZE)}>
                Next <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}
