import type { LucideIcon } from 'lucide-react'
import { Flag, Circle, CircleDot, SplitSquareHorizontal, ArrowRightLeft, Shield, WandSparkles, Clock3, ToggleLeft, Workflow } from 'lucide-react'

export type StatePaletteBlockId = 'initial' | 'stable' | 'terminal' | 'parallel'
export type TransitionPaletteBlockId = 'basic' | 'guarded' | 'action' | 'delayed'
export type TemplatePaletteId = 'toggle_fsm' | 'request_lifecycle'

export interface PaletteBlock<TId extends string> {
  id: TId
  label: string
  description: string
  icon: LucideIcon
}

export const STATE_BLOCKS: PaletteBlock<StatePaletteBlockId>[] = [
  { id: 'initial', label: 'Initial', description: 'Entry point state', icon: Flag },
  { id: 'stable', label: 'Stable', description: 'Default operational state', icon: Circle },
  { id: 'terminal', label: 'Terminal', description: 'End/final state', icon: CircleDot },
  { id: 'parallel', label: 'Parallel', description: 'Parent state with regions', icon: SplitSquareHorizontal },
]

export const TRANSITION_BLOCKS: PaletteBlock<TransitionPaletteBlockId>[] = [
  { id: 'basic', label: 'Basic', description: 'Trigger + source + destination', icon: ArrowRightLeft },
  { id: 'guarded', label: 'Guarded', description: 'Transition with guard condition', icon: Shield },
  { id: 'action', label: 'Action', description: 'Transition with side effect', icon: WandSparkles },
  { id: 'delayed', label: 'Delayed', description: 'Time-based transition', icon: Clock3 },
]

export const TEMPLATE_BLOCKS: PaletteBlock<TemplatePaletteId>[] = [
  { id: 'toggle_fsm', label: 'Toggle FSM', description: 'Simple OFF/ON switch model', icon: ToggleLeft },
  { id: 'request_lifecycle', label: 'Request lifecycle', description: 'IDLE -> LOADING -> SUCCESS/ERROR', icon: Workflow },
]
