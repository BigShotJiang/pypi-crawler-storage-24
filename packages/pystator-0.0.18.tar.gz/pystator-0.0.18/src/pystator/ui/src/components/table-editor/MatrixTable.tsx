'use client'

import { type ReactNode } from 'react'

export interface MatrixTableProps<TCell> {
  rowHeaders: string[]
  columnHeaders: string[]
  getCell: (rowIdx: number, colIdx: number) => TCell
  renderCell: (value: TCell, rowIdx: number, colIdx: number) => ReactNode
  onCellClick?: (rowIdx: number, colIdx: number) => void
  cornerLabel?: string
  emptyMessage?: string
}

export default function MatrixTable<TCell>({
  rowHeaders,
  columnHeaders,
  getCell,
  renderCell,
  onCellClick,
  cornerLabel = '',
  emptyMessage = 'No data.',
}: MatrixTableProps<TCell>) {
  if (rowHeaders.length === 0 || columnHeaders.length === 0) {
    return (
      <div className="rounded-lg border p-8 text-center text-sm text-muted-foreground">
        {emptyMessage}
      </div>
    )
  }

  return (
    <div className="overflow-auto rounded-lg border max-h-[70vh]">
      <table className="min-w-max border-collapse">
        {/* Column headers */}
        <thead>
          <tr>
            {/* Corner */}
            <th className="sticky top-0 left-0 z-20 bg-muted/80 backdrop-blur px-3 py-2.5 text-xs font-medium text-muted-foreground uppercase tracking-wider border-b border-r min-w-[120px]">
              {cornerLabel}
            </th>
            {columnHeaders.map((header, ci) => (
              <th
                key={ci}
                className="sticky top-0 z-10 bg-muted/80 backdrop-blur px-3 py-2.5 text-xs font-medium text-muted-foreground uppercase tracking-wider border-b text-center min-w-[100px]"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rowHeaders.map((rowHeader, ri) => (
            <tr key={ri} className="hover:bg-muted/20 transition-colors">
              {/* Row header (sticky first column) */}
              <th className="sticky left-0 z-10 bg-background border-r px-3 py-2 text-xs font-medium text-muted-foreground uppercase tracking-wider whitespace-nowrap">
                {rowHeader}
              </th>
              {columnHeaders.map((_, ci) => {
                const cellValue = getCell(ri, ci)
                const isDiagonal = ri === ci && rowHeaders === columnHeaders
                return (
                  <td
                    key={ci}
                    className={`px-3 py-2 text-sm text-center border-b border-border/50 transition-colors ${
                      isDiagonal ? 'bg-muted/20' : ''
                    } ${onCellClick ? 'cursor-pointer hover:bg-primary/5' : ''}`}
                    onClick={onCellClick ? () => onCellClick(ri, ci) : undefined}
                  >
                    {renderCell(cellValue, ri, ci)}
                  </td>
                )
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
