'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import type { ObservabilitySummaryResponse } from '@/lib/api'

interface KpiCardsProps {
  summary: ObservabilitySummaryResponse | null
  onFailedTransitionsClick: () => void
}

function pct(value: number): string {
  return `${(value * 100).toFixed(1)}%`
}

export function KpiCards({ summary, onFailedTransitionsClick }: KpiCardsProps) {
  const cards = [
    {
      title: 'Active Entities',
      value: summary?.active_entities ?? 0,
      note: 'Current persisted entity states',
    },
    {
      title: 'Failed Transitions',
      value: summary?.transitions_failed ?? 0,
      note: summary ? `Failure rate: ${pct(summary.transition_failure_rate)}` : 'Failure rate: 0.0%',
      clickable: true,
    },
    {
      title: 'P95 Transition Latency',
      value: summary?.p95_transition_duration_ms != null
        ? `${summary.p95_transition_duration_ms} ms`
        : '—',
      note: 'From transition history durations',
    },
    {
      title: 'Queue Depth',
      value: summary ? summary.worker_pending + summary.worker_claimed : 0,
      note: summary
        ? `Pending ${summary.worker_pending} • Claimed ${summary.worker_claimed}`
        : 'Pending 0 • Claimed 0',
    },
  ]

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <Card
          key={card.title}
          className={card.clickable ? 'cursor-pointer hover:bg-muted/20 transition-colors' : undefined}
          onClick={card.clickable ? onFailedTransitionsClick : undefined}
        >
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{card.title}</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold text-foreground">{card.value}</p>
            <p className="mt-1 text-xs text-muted-foreground">{card.note}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
