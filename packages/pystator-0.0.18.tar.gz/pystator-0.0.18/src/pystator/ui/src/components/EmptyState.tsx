'use client'

import type { ReactNode } from 'react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

export interface EmptyStateProps {
  /** Optional icon (e.g. Lucide icon element). */
  icon?: ReactNode
  /** Short title. */
  title: string
  /** Optional description. */
  description?: string
  /** Label for the primary action button. */
  actionLabel: string
  /** Called when the action button is clicked. */
  onAction: () => void
  className?: string
}

/** Shown when a list or section is empty. Provides icon, copy, and one primary action. */
export function EmptyState({
  icon,
  title,
  description,
  actionLabel,
  onAction,
  className,
}: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center rounded-lg border border-dashed border-border bg-muted/30 py-8 px-4 text-center',
        className
      )}
    >
      {icon && <div className="mb-3 text-muted-foreground">{icon}</div>}
      <p className="text-sm font-medium text-foreground">{title}</p>
      {description && (
        <p className="mt-1 text-xs text-muted-foreground max-w-[220px]">{description}</p>
      )}
      <Button variant="outline" size="sm" className="mt-4" onClick={onAction}>
        {actionLabel}
      </Button>
    </div>
  )
}
