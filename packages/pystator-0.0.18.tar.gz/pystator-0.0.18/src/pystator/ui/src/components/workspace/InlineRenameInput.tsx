'use client'

import { useCallback, useEffect, useRef, useState } from 'react'
import { Input } from '@/components/ui/input'

export interface InlineRenameInputProps {
  initialValue: string
  onCommit: (value: string) => void
  onCancel: () => void
}

/**
 * Inline rename input: replaces a tree node label with an editable field.
 * Enter / blur commits, Escape cancels. Mirrors pycharter InlineRenameInput.
 */
export function InlineRenameInput({
  initialValue,
  onCommit,
  onCancel,
}: InlineRenameInputProps) {
  const [value, setValue] = useState(initialValue)
  const ref = useRef<HTMLInputElement>(null)
  const readyRef = useRef(false)

  useEffect(() => {
    const timer = setTimeout(() => {
      ref.current?.focus()
      ref.current?.select()
      readyRef.current = true
    }, 50)
    return () => clearTimeout(timer)
  }, [])

  const commit = useCallback(() => {
    if (!readyRef.current) return
    const trimmed = value.trim()
    if (trimmed && trimmed !== initialValue) {
      onCommit(trimmed)
    } else {
      onCancel()
    }
  }, [value, initialValue, onCommit, onCancel])

  return (
    <Input
      ref={ref}
      value={value}
      onChange={(e) => setValue(e.target.value)}
      onBlur={commit}
      onKeyDown={(e) => {
        if (e.key === 'Enter') commit()
        if (e.key === 'Escape') onCancel()
      }}
      onClick={(e) => e.stopPropagation()}
      className="h-6 px-1 py-0 text-xs"
    />
  )
}
