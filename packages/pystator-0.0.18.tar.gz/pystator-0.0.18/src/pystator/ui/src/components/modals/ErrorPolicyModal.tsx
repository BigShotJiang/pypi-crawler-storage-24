'use client'

import { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export type ErrorPolicyValue = { default_fallback?: string; retry_attempts?: number }

export interface ErrorPolicyModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  value: ErrorPolicyValue | null
  onSave: (value: ErrorPolicyValue | null) => void
  title?: string
  description?: string
  allowRemove?: boolean
}

export function ErrorPolicyModal({
  open,
  onOpenChange,
  value,
  onSave,
  title = 'Error policy',
  description = 'Optional fallback state and retry attempts on error.',
  allowRemove = true,
}: ErrorPolicyModalProps) {
  const [defaultFallback, setDefaultFallback] = useState(value?.default_fallback ?? '')
  const [retryAttempts, setRetryAttempts] = useState(String(value?.retry_attempts ?? 0))

  useEffect(() => {
    if (open) {
      setDefaultFallback(value?.default_fallback ?? '')
      setRetryAttempts(String(value?.retry_attempts ?? 0))
    }
  }, [open, value])

  const handleSave = () => {
    onSave({
      default_fallback: defaultFallback.trim() || undefined,
      retry_attempts: Math.max(0, parseInt(retryAttempts, 10) || 0),
    })
    onOpenChange(false)
  }

  const handleRemove = () => {
    onSave(null)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md" showClose>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>{description}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-2">
          <div className="space-y-2">
            <Label htmlFor="error-fallback">Default fallback state</Label>
            <Input
              id="error-fallback"
              className="h-9"
              placeholder="ERROR_STATE"
              value={defaultFallback}
              onChange={(e) => setDefaultFallback(e.target.value)}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="error-retry">Retry attempts</Label>
            <Input
              id="error-retry"
              className="h-9"
              type="number"
              min={0}
              placeholder="0"
              value={retryAttempts}
              onChange={(e) => setRetryAttempts(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          {allowRemove && (
            <Button variant="destructive" className="mr-auto" onClick={handleRemove}>
              Remove policy
            </Button>
          )}
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
