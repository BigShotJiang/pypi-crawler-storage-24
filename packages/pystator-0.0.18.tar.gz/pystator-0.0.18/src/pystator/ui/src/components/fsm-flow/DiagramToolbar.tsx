'use client'

import { Plus, LayoutGrid } from 'lucide-react'
import { Button } from '@/components/ui/button'

export interface DiagramToolbarProps {
  onAddState: () => void
  onRelayout: () => void
}

/**
 * Floating toolbar for diagram editing actions: add a state, re-layout the diagram.
 * Positioned in the top-left of the diagram area by the parent.
 */
export function DiagramToolbar({ onAddState, onRelayout }: DiagramToolbarProps) {
  return (
    <div className="flex items-center gap-1.5 rounded-lg border border-border bg-background/95 px-2 py-1.5 shadow-md backdrop-blur-sm">
      <Button
        variant="outline"
        size="sm"
        className="h-7 gap-1 text-xs"
        onClick={onAddState}
        title="Add a new state"
      >
        <Plus className="h-3.5 w-3.5" />
        State
      </Button>
      <Button
        variant="ghost"
        size="sm"
        className="h-7 gap-1 text-xs"
        onClick={onRelayout}
        title="Re-layout diagram"
      >
        <LayoutGrid className="h-3.5 w-3.5" />
      </Button>
    </div>
  )
}
