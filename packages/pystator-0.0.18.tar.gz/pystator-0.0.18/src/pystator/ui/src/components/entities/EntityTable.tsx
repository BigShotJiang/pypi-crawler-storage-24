'use client'

import { Button } from '@/components/ui/button'
import type { EntityState } from '@/lib/api'
import { Eye, Trash2 } from 'lucide-react'

interface EntityTableProps {
  entities: EntityState[]
  onView: (entity: EntityState) => void
  onDelete: (entity: EntityState) => void
}

function formatDate(iso: string | null): string {
  if (!iso) return '—'
  try {
    return new Date(iso).toLocaleString()
  } catch {
    return iso
  }
}

export default function EntityTable({ entities, onView, onDelete }: EntityTableProps) {
  return (
    <div className="overflow-x-auto rounded-lg border">
      <table className="min-w-full divide-y divide-border">
        <thead className="bg-muted/50">
          <tr>
            <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Entity ID
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Machine
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Current State
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-muted-foreground uppercase tracking-wider hidden md:table-cell">
              Updated
            </th>
            <th className="px-4 py-3 text-right text-xs font-medium text-muted-foreground uppercase tracking-wider">
              Actions
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border bg-background">
          {entities.map((ent) => (
            <tr key={ent.entity_id} className="hover:bg-muted/30 transition-colors">
              <td className="px-4 py-3 text-sm font-mono text-foreground whitespace-nowrap max-w-[200px] truncate">
                {ent.entity_id}
              </td>
              <td className="px-4 py-3 text-sm text-muted-foreground whitespace-nowrap">
                {ent.machine_name || '—'}
              </td>
              <td className="px-4 py-3 text-sm whitespace-nowrap">
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-primary/10 text-primary">
                  {ent.current_state}
                </span>
              </td>
              <td className="px-4 py-3 text-sm text-muted-foreground hidden md:table-cell whitespace-nowrap">
                {formatDate(ent.updated_at)}
              </td>
              <td className="px-4 py-3 text-sm text-right whitespace-nowrap">
                <div className="flex items-center justify-end gap-2">
                  <Button variant="outline" size="sm" onClick={() => onView(ent)} className="gap-1.5">
                    <Eye className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">View</span>
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onDelete(ent)}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  )
}
