'use client'

import { useEffect, useRef } from 'react'

export interface DiagramContextMenuProps {
  x: number
  y: number
  items: Array<{
    label: string
    onClick: () => void
    disabled?: boolean
    destructive?: boolean
  }>
  onClose: () => void
}

/**
 * Simple right-click context menu for the diagram. Shows a list of actions
 * at the given screen position. Closes on outside click or Escape.
 */
export function DiagramContextMenu({ x, y, items, onClose }: DiagramContextMenuProps) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as HTMLElement)) {
        onClose()
      }
    }
    function handleEscape(e: KeyboardEvent) {
      if (e.key === 'Escape') onClose()
    }
    document.addEventListener('mousedown', handleClickOutside)
    document.addEventListener('keydown', handleEscape)
    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
      document.removeEventListener('keydown', handleEscape)
    }
  }, [onClose])

  return (
    <div
      ref={ref}
      className="fixed z-50 min-w-[140px] rounded-md border bg-popover p-1 text-popover-foreground shadow-lg"
      style={{ top: y, left: x }}
    >
      {items.map((item) => (
        <button
          key={item.label}
          className={`relative flex w-full cursor-pointer select-none items-center rounded-sm px-2 py-1.5 text-sm outline-none transition-colors hover:bg-accent hover:text-accent-foreground ${
            item.disabled ? 'opacity-50 pointer-events-none' : ''
          } ${item.destructive ? 'text-destructive hover:text-destructive' : ''}`}
          onClick={() => {
            if (!item.disabled) {
              item.onClick()
              onClose()
            }
          }}
          disabled={item.disabled}
        >
          {item.label}
        </button>
      ))}
    </div>
  )
}
