'use client'

import { useMemo } from 'react'
import DataTable, { type Column } from './DataTable'
import type { FSMStateVariable } from '@/lib/types/fsm'

const VAR_TYPES: { value: string; label: string }[] = [
  { value: 'string', label: 'string' },
  { value: 'number', label: 'number' },
  { value: 'boolean', label: 'boolean' },
  { value: 'object', label: 'object' },
]

interface VariableTableProps {
  variables: FSMStateVariable[]
  onChange: (variables: FSMStateVariable[]) => void
}

export default function VariableTable({ variables, onChange }: VariableTableProps) {
  const columns: Column<FSMStateVariable>[] = useMemo(
    () => [
      {
        key: 'key',
        header: 'Key',
        width: '160px',
        accessor: (r) => r.key,
        editor: 'text',
        onChange: (r, v) => ({ ...r, key: String(v) }),
        required: true,
      },
      {
        key: 'type',
        header: 'Type',
        width: '110px',
        accessor: (r) => r.type ?? '',
        editor: 'select',
        editorOptions: { options: VAR_TYPES },
        onChange: (r, v) => ({ ...r, type: String(v) || undefined }),
      },
      {
        key: 'default',
        header: 'Default',
        width: '120px',
        accessor: (r) =>
          r.default != null
            ? typeof r.default === 'object'
              ? JSON.stringify(r.default)
              : String(r.default)
            : '',
        editor: 'text',
        onChange: (r, v) => {
          const raw = String(v).trim()
          if (!raw) return { ...r, default: undefined }
          if (raw === 'true') return { ...r, default: true }
          if (raw === 'false') return { ...r, default: false }
          if (raw === 'null') return { ...r, default: null }
          if (/^-?\d+$/.test(raw)) return { ...r, default: parseInt(raw, 10) }
          if (/^-?\d*\.\d+$/.test(raw)) return { ...r, default: parseFloat(raw) }
          try {
            return { ...r, default: JSON.parse(raw) }
          } catch {
            return { ...r, default: raw }
          }
        },
      },
      {
        key: 'required',
        header: 'Required',
        width: '80px',
        accessor: (r) => r.required ?? false,
        editor: 'checkbox',
        onChange: (r, v) => ({ ...r, required: !!v }),
      },
      {
        key: 'description',
        header: 'Description',
        accessor: (r) => r.description ?? '',
        editor: 'text',
        onChange: (r, v) => ({ ...r, description: String(v) || undefined }),
      },
    ],
    [],
  )

  return (
    <DataTable<FSMStateVariable>
      columns={columns}
      rows={variables}
      onRowsChange={onChange}
      rowKey={(r) => r.key || `var-${variables.indexOf(r)}`}
      onAddRow={() => ({ key: `var_${variables.length + 1}` })}
      emptyMessage="No state variables defined."
      addLabel="Add variable"
    />
  )
}
