'use client'

import { useState } from 'react'
import { X, AlertCircle, CheckCircle2 } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { createMachine, validateConfig } from '@/lib/api'
import type { FSMConfig } from '@/lib/types/fsm'

interface MachineCreateModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

function buildMinimalConfig(name: string, version: string, description: string): FSMConfig {
  return {
    meta: {
      machine_name: name,
      version,
      ...(description ? { description } : {}),
    },
    states: [
      { name: 'start', type: 'initial' },
      { name: 'end', type: 'terminal' },
    ],
    transitions: [
      { trigger: 'go', source: 'start', dest: 'end' },
    ],
  }
}

export default function MachineCreateModal({
  isOpen,
  onClose,
  onSuccess,
}: MachineCreateModalProps) {
  const [name, setName] = useState('')
  const [version, setVersion] = useState('1.0.0')
  const [description, setDescription] = useState('')
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    const trimmedName = name.trim()
    if (!trimmedName) {
      setError('Machine name is required')
      return
    }
    try {
      setSaving(true)
      setError(null)
      const config = buildMinimalConfig(trimmedName, version.trim() || '1.0.0', description.trim())
      await validateConfig(config)
      await createMachine(config)
      setSuccess(true)
      setTimeout(() => {
        onSuccess()
        handleClose()
      }, 1200)
    } catch (err) {
      const e = err as { message?: string; response?: { detail?: string } }
      const msg =
        typeof (e.response as { detail?: string })?.detail === 'string'
          ? (e.response as { detail: string }).detail
          : e.message ?? 'Failed to create machine'
      setError(msg)
    } finally {
      setSaving(false)
    }
  }

  const handleClose = () => {
    setError(null)
    setSuccess(false)
    setName('')
    setVersion('1.0.0')
    setDescription('')
    onClose()
  }

  if (!isOpen) return null

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/50"
      onClick={handleClose}
    >
      <div
        className="bg-background rounded-lg shadow-lg max-w-md w-full mx-4 p-6"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Create machine</h2>
          <Button variant="ghost" size="sm" onClick={handleClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2 p-3 bg-destructive/10 border border-destructive/50 rounded-md">
            <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
            <p className="text-sm text-destructive">{error}</p>
          </div>
        )}

        {success && (
          <div className="mb-4 flex items-start gap-2 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-md">
            <CheckCircle2 className="h-5 w-5 text-green-600 dark:text-green-400 flex-shrink-0 mt-0.5" />
            <p className="text-sm text-green-800 dark:text-green-200">Machine created successfully.</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="create-machine-name">
              Machine name <span className="text-destructive">*</span>
            </Label>
            <Input
              id="create-machine-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. order_workflow"
              disabled={saving}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label htmlFor="create-machine-version">Version</Label>
            <Input
              id="create-machine-version"
              value={version}
              onChange={(e) => setVersion(e.target.value)}
              placeholder="1.0.0"
              disabled={saving}
              className="mt-1.5"
            />
          </div>
          <div>
            <Label htmlFor="create-machine-description">Description (optional)</Label>
            <Input
              id="create-machine-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Short description"
              disabled={saving}
              className="mt-1.5"
            />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="outline" onClick={handleClose} disabled={saving}>
              Cancel
            </Button>
            <Button type="submit" disabled={saving}>
              {saving ? 'Creating...' : 'Create'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  )
}
