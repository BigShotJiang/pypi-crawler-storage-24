"""PostgreSQL state store implementation.

Thin wrapper around ``_SQLAlchemyStateStoreBase`` that validates the
connection string and sets the ``pystator`` schema.
"""

from __future__ import annotations

import logging

from pystator.stores._sqlalchemy_base import _SQLAlchemyStateStoreBase

logger = logging.getLogger(__name__)


class PostgresStateStore(_SQLAlchemyStateStoreBase):
    """PostgreSQL-backed state store.

    Satisfies the ``StateStore`` and ``VersionedStateStore`` protocols.

    Usage::

        store = PostgresStateStore("postgresql://user:pass@localhost/mydb")
        store.connect()

    *connection_string* is **required** — there is no default fallback.
    For PostgreSQL, prefer running ``pystator db init`` before connecting
    (``auto_initialize=False`` by default).
    """

    def __init__(self, connection_string: str) -> None:
        if not connection_string.startswith(("postgresql://", "postgres://")):
            raise ValueError(
                f"PostgresStateStore requires a postgresql:// URL, got: {connection_string!r}"
            )
        super().__init__(connection_string)

    def connect(
        self,
        validate_schema: bool = True,
        auto_initialize: bool = False,
    ) -> None:
        """Connect to the PostgreSQL database.

        Args:
            validate_schema: Check that required tables exist.
            auto_initialize: Create tables if missing (default ``False`` —
                use ``pystator db init`` for production PostgreSQL).
        """
        self._connect_engine(
            schema_name="pystator",
            validate_schema=validate_schema,
            auto_initialize=auto_initialize,
        )
