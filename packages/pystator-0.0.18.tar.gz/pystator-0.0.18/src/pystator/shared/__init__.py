"""Shared utilities used across pystator modules."""
