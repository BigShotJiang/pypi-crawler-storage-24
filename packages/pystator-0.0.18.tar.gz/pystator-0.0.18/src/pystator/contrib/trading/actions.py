"""Action implementations for core trading FSMs (portfolio, optimization, order, intraday).

All actions are side-effect stubs: they log at DEBUG and return. Replace with
real implementations (DB, messaging, HTTP) by registering overrides in your
ActionRegistry. Context is the same dict passed to process() / send().
"""

from __future__ import annotations

import logging
import sys
from typing import Any

logger = logging.getLogger(__name__)


def _make_stub(name: str):
    """Create a stub action that logs at debug and returns."""

    def stub(context: dict[str, Any]) -> None:
        logger.debug("action %s (context keys: %s)", name, list(context.keys()))

    stub.__name__ = name
    stub.__qualname__ = name
    stub.__doc__ = f"Stub action: {name}. Override in your ActionRegistry."
    return stub


# All stub action names, grouped by FSM domain.
# Each generates a no-op function at module level for registry auto-discovery.
STUB_ACTION_NAMES: list[str] = [
    # Portfolio lifecycle (FSM #1)
    "schedule_next_drift_check",
    "log_monitoring_entered",
    "spawn_optimization_cycle",
    "log_rebalance_started",
    "generate_rebalance_report",
    "calculate_implementation_shortfall",
    "cancel_active_cycle",
    "notify_portfolio_manager",
    "log_suspension",
    "log_deactivation",
    "snapshot_portfolio",
    "record_trigger_reason",
    "update_last_rebalance_time",
    "update_current_weights",
    "log_cycle_failure",
    "notify_cycle_failure",
    "log_cycle_cancelled",
    "archive_rebalance_report",
    "record_risk_event",
    "log_risk_cleared",
    # Optimization cycle (FSM #2)
    "fetch_market_data",
    "log_data_collection_started",
    "submit_optimization_job",
    "log_optimization_started",
    "validate_data_quality",
    "validate_risk_constraints",
    "check_turnover",
    "notify_approval_required",
    "submit_rebalance_orders",
    "log_execution_started",
    "start_settlement_monitor",
    "update_portfolio_state",
    "record_execution_stats",
    "notify_cycle_completed",
    "signal_parent_completed",
    "log_failure",
    "notify_cycle_failed",
    "signal_parent_failed",
    "log_cancellation",
    "signal_parent_cancelled",
    "store_optimization_inputs",
    "log_data_quality_failure",
    "store_optimal_weights",
    "log_optimization_result",
    "log_optimization_failure",
    "prepare_approval_summary",
    "record_auto_approval",
    "adjust_constraints",
    "log_validation_failure",
    "log_validation_exhausted",
    "record_approval",
    "log_rejection",
    "log_orders_submitted",
    "log_no_orders_needed",
    "confirm_settlement",
    "calculate_execution_quality",
    "store_error_details",
    "log_cancellation_request",
    "cancel_pending_orders",
    # Order lifecycle (FSM #3)
    "log_order_created",
    "reserve_buying_power",
    "update_order_timestamp",
    "publish_order_status",
    "update_position",
    "release_buying_power",
    "log_order_completed",
    "log_order_canceled",
    "log_rejection_reason",
    "log_timeout",
    "store_external_order_id",
    "store_rejection_reason",
    "record_execution",
    "update_filled_qty",
    # Intraday signal lifecycle
    "log_signal_detected",
    "enqueue_validation",
    "run_signal_validation",
    "build_order",
    "send_to_venue",
    "start_fill_monitor",
    "stop_fill_monitor",
    "update_positions",
    "log_fill",
    # Intraday trading session
    "load_watchlist",
    "check_connectivity",
    "initialize_risk_limits",
    "start_scanners",
    "run_analysis",
    "enter_execution_mode",
    "refresh_positions",
    "close_session",
    "generate_session_report",
    "cancel_open_orders",
    "send_halt_alert",
    "log_no_signals",
    "log_no_trade",
]

# Generate stub functions at module level for registry auto-discovery.
_this = sys.modules[__name__]
for _name in STUB_ACTION_NAMES:
    setattr(_this, _name, _make_stub(_name))
del _this, _name
