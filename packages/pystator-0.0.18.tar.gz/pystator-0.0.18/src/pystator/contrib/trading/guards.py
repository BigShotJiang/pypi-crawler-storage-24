"""Guard implementations for core trading FSMs (portfolio, optimization, order, intraday).

All guards are pure: (context) -> bool. Context is built by the application and
passed to machine.process() or instance.send(). Override any guard in your own
GuardRegistry when you need real logic (e.g. trading hours, risk checks).
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

# ---------------------------------------------------------------------------
# Portfolio lifecycle (FSM #1)
# ---------------------------------------------------------------------------


def cooldown_elapsed(context: dict[str, Any]) -> bool:
    """True if min_rebalance_interval_days has passed since last_rebalance_at."""
    last = context.get("last_rebalance_at")
    days = context.get("min_rebalance_interval_days", 0)
    if last is None or days is None:
        return True
    if isinstance(last, (int, float)):
        last = datetime.fromtimestamp(last, tz=UTC)
    elif not hasattr(last, "timestamp"):
        return True
    delta = (datetime.now(UTC) - last).days
    return delta >= int(days)


def is_within_trading_hours(context: dict[str, Any]) -> bool:
    """True if current time is within trading hours. Stub: always True. Override with real schedule."""
    return True


def drift_exceeds_threshold(context: dict[str, Any]) -> bool:
    """True if portfolio drift exceeds drift_threshold."""
    drift = context.get("drift")
    threshold = context.get("drift_threshold")
    if drift is None or threshold is None:
        return False
    try:
        return float(drift) >= float(threshold)
    except (TypeError, ValueError):
        return False


def risk_actually_cleared(context: dict[str, Any]) -> bool:
    """True if risk conditions have been verified cleared. Stub: True. Override for real checks."""
    return True


# ---------------------------------------------------------------------------
# Optimization cycle (FSM #2)
# ---------------------------------------------------------------------------


def data_quality_sufficient(context: dict[str, Any]) -> bool:
    """True if market data quality is sufficient. Stub: True."""
    return True


def passes_risk_constraints(context: dict[str, Any]) -> bool:
    """True if optimization result passes risk constraints. Stub: True."""
    return True


def acceptable_turnover(context: dict[str, Any]) -> bool:
    """True if turnover is within limits. Stub: True."""
    return True


def requires_approval(context: dict[str, Any]) -> bool:
    """True if this run requires manual approval. From context or stub False."""
    return context.get("requires_approval", False)


def auto_approval_enabled(context: dict[str, Any]) -> bool:
    """True if auto-approval is enabled. From context or stub True."""
    return context.get("auto_approval_enabled", True)


def retry_optimization_allowed(context: dict[str, Any]) -> bool:
    """True if validation failure can retry optimization. Stub: True."""
    return context.get("retry_optimization_allowed", True)


def order_list_empty(context: dict[str, Any]) -> bool:
    """True if no orders to submit (portfolio already aligned)."""
    orders = context.get("calculated_orders") or context.get("order_list") or []
    return len(orders) == 0


def all_orders_filled_or_cancelled(context: dict[str, Any]) -> bool:
    """True if all orders in this cycle are in a terminal state."""
    orders = context.get("orders_status") or context.get("orders") or []
    if not orders:
        return True
    terminal = {"FILLED", "CANCELED", "CANCELLED", "REJECTED", "EXPIRED"}
    return all(o.get("status") in terminal for o in orders)


def can_safely_cancel(context: dict[str, Any]) -> bool:
    """True if cycle can be cancelled safely. Stub: True."""
    return True


# ---------------------------------------------------------------------------
# Order / signal (FSM #3, intraday signal)
# ---------------------------------------------------------------------------


def is_partial_fill(context: dict[str, Any]) -> bool:
    """True if fill_qty > 0 and fill_qty < order_qty."""
    fill = context.get("fill_qty", 0)
    order = context.get("order_qty", 1)
    try:
        return 0 < float(fill) < float(order)
    except (TypeError, ValueError):
        return False


def is_full_fill(context: dict[str, Any]) -> bool:
    """True if fill_qty >= order_qty."""
    fill = context.get("fill_qty", 0)
    order = context.get("order_qty", 1)
    try:
        return float(fill) >= float(order)
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# Order management (comprehensive template)
# ---------------------------------------------------------------------------


def is_cancellable(context: dict[str, Any]) -> bool:
    """True if the order can be cancelled (status is OPEN, PENDING_NEW, or PARTIALLY_FILLED)."""
    cancellable = {"OPEN", "PENDING_NEW", "PARTIALLY_FILLED"}
    return context.get("status") in cancellable


def has_no_fills(context: dict[str, Any]) -> bool:
    """True if no fills have occurred (fill_qty == 0)."""
    try:
        return float(context.get("fill_qty", 0)) == 0
    except (TypeError, ValueError):
        return True


def has_partial_fills(context: dict[str, Any]) -> bool:
    """True if some but not all quantity has been filled."""
    fill = context.get("fill_qty", 0)
    order = context.get("order_qty", 1)
    try:
        return 0 < float(fill) < float(order)
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# Day trading (parallel regions template)
# ---------------------------------------------------------------------------


def has_buying_power(context: dict[str, Any]) -> bool:
    """True if account has positive buying power."""
    try:
        return float(context.get("buying_power", 0)) > 0
    except (TypeError, ValueError):
        return False


def risk_allows_entry(context: dict[str, Any]) -> bool:
    """True if risk state allows new entries. Stub: True. Override with real risk checks."""
    return True


def daily_pnl_below_threshold(context: dict[str, Any]) -> bool:
    """True if daily P&L has dropped below warning threshold."""
    pnl = context.get("daily_pnl", 0)
    threshold = context.get("daily_pnl_warning_threshold")
    if threshold is None:
        return False
    try:
        return float(pnl) < float(threshold)
    except (TypeError, ValueError):
        return False


def daily_pnl_critical(context: dict[str, Any]) -> bool:
    """True if daily P&L has reached critical (stop-loss) level."""
    pnl = context.get("daily_pnl", 0)
    critical = context.get("daily_pnl_critical_threshold")
    if critical is None:
        return False
    try:
        return float(pnl) < float(critical)
    except (TypeError, ValueError):
        return False


def daily_pnl_recovered(context: dict[str, Any]) -> bool:
    """True if daily P&L has recovered to normal levels from elevated risk."""
    pnl = context.get("daily_pnl", 0)
    threshold = context.get("daily_pnl_warning_threshold", 0)
    try:
        return float(pnl) >= float(threshold)
    except (TypeError, ValueError):
        return False


def daily_pnl_improved(context: dict[str, Any]) -> bool:
    """True if daily P&L has improved from critical to elevated risk level."""
    pnl = context.get("daily_pnl", 0)
    critical = context.get("daily_pnl_critical_threshold")
    warning = context.get("daily_pnl_warning_threshold")
    if critical is None or warning is None:
        return False
    try:
        return float(critical) <= float(pnl) < float(warning)
    except (TypeError, ValueError):
        return False


# ---------------------------------------------------------------------------
# Portfolio optimization (hierarchical compound template)
# ---------------------------------------------------------------------------


def is_market_hours(context: dict[str, Any]) -> bool:
    """Alias for is_within_trading_hours. Used by portfolio_optimization template."""
    return is_within_trading_hours(context)


def can_retry(context: dict[str, Any]) -> bool:
    """True if retry_count < max_retries (defaults: 0, 3)."""
    retry = context.get("retry_count", 0)
    max_retries = context.get("max_retries", 3)
    try:
        return int(retry) < int(max_retries)
    except (TypeError, ValueError):
        return False
