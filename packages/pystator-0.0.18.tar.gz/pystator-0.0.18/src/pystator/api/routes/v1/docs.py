"""
API routes for documentation: playground route list.

Provides GET /api/v1/docs/playground-routes so the UI can build the API Playground
from the OpenAPI schema (single source of truth).
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Request

router = APIRouter(prefix="/docs", tags=["Documentation"])


@router.get(
    "/playground-routes",
    summary="List REST API routes for playground",
    description="Return a list of REST API routes (path, method, summary, tag) derived from the OpenAPI schema for use in the API Playground UI.",
)
async def get_playground_routes(request: Request) -> dict[str, Any]:
    """
    Return routes suitable for the API Playground.

    Reads the OpenAPI schema from the running app and returns a minimal list
    of path, method, summary, and tag so the UI can build the playground
    without maintaining a duplicate list.
    """
    try:
        openapi = request.app.openapi()
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to generate OpenAPI schema: {e}",
        ) from e

    paths = openapi.get("paths") or {}
    routes: list[dict[str, Any]] = []

    for path, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue
        if not path.startswith("/api/v1"):
            continue
        for method in ("get", "post", "put", "patch", "delete"):
            op = path_item.get(method)
            if not isinstance(op, dict):
                continue
            summary = op.get("summary") or op.get("description") or ""
            tags = op.get("tags") or []
            tag = tags[0] if tags else ""
            routes.append(
                {
                    "path": path,
                    "method": method.upper(),
                    "summary": summary[:200] if summary else "",
                    "tag": tag,
                }
            )

    return {"routes": routes}
