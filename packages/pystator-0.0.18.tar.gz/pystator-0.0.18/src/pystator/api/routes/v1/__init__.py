"""API v1 routes."""

from __future__ import annotations

from pystator.api.routes.v1 import (
    auth,
    docs,
    entities,
    machines,
    observability,
    process,
    settings,
    templates,
)

__all__ = [
    "auth",
    "docs",
    "entities",
    "machines",
    "observability",
    "process",
    "settings",
    "templates",
]
