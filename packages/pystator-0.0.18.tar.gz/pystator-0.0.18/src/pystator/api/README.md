# PyStator API

REST API for PyStator: **stateless** transition computation, **stored machines**, **entity lifecycle** (with database), auth, settings, and templates.

## Install

```bash
pip install pystator[api]
```

For Postgres URLs, add `pip install pystator[postgres]`. Copy `pystator.cfg.example` to `pystator.cfg` and set `PYSTATOR_DATABASE_URL` (or use env) so machines, entities, and history persist.

Initialize the database:

```bash
pystator db upgrade
# optional: pystator db seed
```

## Run

```bash
pystator api
# or
uvicorn pystator.api.main:app --host 0.0.0.0 --port 8000 --reload
```

- Swagger: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

## Route groups (v1)

All JSON APIs are under `/api/v1/…` unless noted.

| Tag | Purpose |
|-----|--------|
| **Auth** | Login, JWT, current user (`/api/v1/auth/...`) |
| **Process** | `POST /validate` — validate FSM config; `POST /process` — one-shot transition (client sends `config`, `current_state`, `trigger`, optional `context`) |
| **Machines** | CRUD stored machine definitions (requires DB) |
| **Entities** | List/query entity state, transition history, `POST .../entities/{id}/events` — full sandwich (load → process → persist → history) |
| **Settings** | Admin/settings helpers (e.g. DB test) |
| **Templates** | Starter FSM templates for UI |

**Health:** `GET /health` (no auth).

## Design notes

- **`/process`** is **stateless**: each request may include the full FSM `config`. Guards named in YAML are treated as **pass-through** unless you run custom middleware—safe for validation and diagramming.
- **Entity routes** use the **SQLAlchemy** state store and match the worker/API database schema.
- **Auth** is optional: when JWT secrets/users are configured, routes use Bearer tokens; otherwise behavior follows `pystator.cfg` / env.

## See also

- [REST API guide](../../../docs/api/rest-api.md) (MkDocs)
- [Tutorial: API and UI](../../../docs/tutorials/api-and-ui.md)
- [Configuration](../../../docs/guides/configuration.md)
- [Worker](../../../docs/guides/worker.md) — queued processing with `submit_event` + `pystator worker`
