"""API request/response models."""

from __future__ import annotations

from pystator.api.models.requests import ProcessRequest, ValidateRequest
from pystator.api.models.responses import MachineInfo, ProcessResponse, ValidateResponse

__all__ = [
    "ProcessRequest",
    "ProcessResponse",
    "ValidateRequest",
    "ValidateResponse",
    "MachineInfo",
]
