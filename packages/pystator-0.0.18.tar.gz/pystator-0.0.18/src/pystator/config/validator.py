"""Configuration validation for PyStator FSM definitions."""

from __future__ import annotations

import re
from typing import Any

from pydantic import ValidationError

from pystator.config.models import MachineConfig
from pystator.errors import ConfigurationError

_HISTORY_DEST_RE = re.compile(r"^H\*?\(\w[\w.]*\)$")
_ENTRY_EXIT_RE = re.compile(r"^(\w[\w.]*):(\w[\w.]*)$")


class ConfigValidator:
    """Validates FSM configuration with Pydantic and semantic rules.

    Performs two levels of validation:
    1. Pydantic schema validation (structure and types)
    2. Semantic validation (state references, exactly one initial, no transitions from terminal)

    Example:
        >>> validator = ConfigValidator()
        >>> errors = validator.validate(config)
        >>> if errors:
        ...     for error in errors:
        ...         print(f"Error: {error}")
    """

    def __init__(self) -> None:
        """Initialize the validator. Validation uses Pydantic models and semantic rules."""

    def validate(self, config: dict[str, Any]) -> list[str]:
        """Validate configuration.

        Args:
            config: The configuration dictionary to validate.

        Returns:
            List of validation error messages. Empty if valid.
        """
        errors: list[str] = []

        # Pydantic (schema) validation
        try:
            MachineConfig.model_validate(config)
        except ValidationError as e:
            for err in e.errors():
                loc = ".".join(str(p) for p in err.get("loc", ()))
                msg = err.get("msg", "validation error")
                if loc:
                    errors.append(f"[{loc}] {msg}")
                else:
                    errors.append(msg)
            return errors

        # Semantic validation
        errors.extend(self._validate_semantics(config))
        return errors

    def _validate_semantics(self, config: dict[str, Any]) -> list[str]:
        """Validate semantic rules (state refs, one initial, no transitions from terminal)."""
        errors: list[str] = []

        states = config.get("states", [])
        transitions = config.get("transitions", [])

        state_names: set[str] = set()
        initial_states: list[str] = []

        for state in states:
            name = state.get("name", "")
            if name in state_names:
                errors.append(f"Duplicate state name: '{name}'")
            state_names.add(name)
            if state.get("type") == "initial":
                initial_states.append(name)

        if len(initial_states) == 0:
            errors.append(
                "No initial state defined. Exactly one state must have type='initial'"
            )
        elif len(initial_states) > 1:
            errors.append(
                f"Multiple initial states defined: {initial_states}. "
                "Exactly one state must have type='initial'"
            )

        for i, trans in enumerate(transitions):
            trigger = trans.get("trigger") or f"transition[{i}]"
            source = trans.get("source", [])
            if isinstance(source, str):
                source = [source]
            for src in source:
                if src not in state_names and not _ENTRY_EXIT_RE.match(src):
                    errors.append(
                        f"Transition '{trigger}': source state '{src}' not defined"
                    )
            dest = trans.get("dest", "")
            # Allow history destinations like H(Parent) or H*(Parent)
            # Allow entry/exit point refs like parent:point
            if (
                dest not in state_names
                and not _HISTORY_DEST_RE.match(dest)
                and not _ENTRY_EXIT_RE.match(dest)
            ):
                errors.append(
                    f"Transition '{trigger}': destination state '{dest}' not defined"
                )

        for state in states:
            timeout = state.get("timeout")
            if timeout:
                dest = timeout.get("destination", "")
                if dest and dest not in state_names:
                    errors.append(
                        f"State '{state.get('name')}': timeout destination '{dest}' not defined"
                    )

        error_policy = config.get("error_policy") or {}
        fallback = error_policy.get("default_fallback")
        if fallback and fallback not in state_names:
            errors.append(f"Error policy: fallback state '{fallback}' not defined")

        terminal_states = {s.get("name") for s in states if s.get("type") == "terminal"}
        for trans in transitions:
            source = trans.get("source", [])
            if isinstance(source, str):
                source = [source]
            for src in source:
                if src in terminal_states:
                    errors.append(
                        f"Transition '{trans.get('trigger')}': "
                        f"cannot have transitions from terminal state '{src}'"
                    )

        # Check parallel states with final regions but no join transition
        for state in states:
            if state.get("type") != "parallel":
                continue
            regions = state.get("regions", [])
            has_final = any(r.get("final") for r in regions if isinstance(r, dict))
            if not has_final:
                continue
            pname = state.get("name", "")
            join_trigger = f"_join_{pname}"
            has_join = any(
                t.get("trigger") == join_trigger
                or (isinstance(t.get("source"), str) and t.get("source") == pname)
                or (isinstance(t.get("source"), list) and pname in t.get("source", []))
                for t in transitions
                if t.get("trigger", "").startswith("_join_")
            )
            if not has_join:
                errors.append(
                    f"Parallel state '{pname}' has regions with 'final' "
                    f"but no '_join_{pname}' transition defined"
                )

        state_vars = config.get("state_variables")
        if isinstance(state_vars, list):
            seen_keys: set[str] = set()
            for item in state_vars:
                key = (
                    item
                    if isinstance(item, str)
                    else (item.get("key", "") if isinstance(item, dict) else "")
                )
                if key in seen_keys:
                    errors.append(f"Duplicate state_variable key: {key!r}")
                seen_keys.add(key)

        return errors

    def validate_strict(self, config: dict[str, Any]) -> None:
        """Validate and raise ConfigurationError if invalid."""
        errors = self.validate(config)
        if errors:
            raise ConfigurationError(
                f"Configuration validation failed with {len(errors)} error(s)",
                context={"errors": errors},
            )


def validate_config(config: dict[str, Any], strict: bool = True) -> list[str]:
    """Validate a configuration dictionary.

    Args:
        config: The configuration dictionary to validate.
        strict: If True, raises ConfigurationError on failure.

    Returns:
        List of validation error messages.

    Raises:
        ConfigurationError: If strict=True and validation fails.
    """
    validator = ConfigValidator()
    if strict:
        validator.validate_strict(config)
        return []
    return validator.validate(config)
