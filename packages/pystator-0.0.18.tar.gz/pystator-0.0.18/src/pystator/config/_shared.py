"""Shared config parsing helpers used by both the Pydantic and raw parsers."""

from __future__ import annotations

import re
from typing import Any

from pystator._types import ActionSpec, GuardSpec, State, Transition

# Pattern for entry/exit point references: "parent:point"
_ENTRY_EXIT_RE = re.compile(r"^(\w[\w.]*):(\w[\w.]*)$")

# ---------------------------------------------------------------------------
# Synthetic trigger generation
# ---------------------------------------------------------------------------


def implicit_trigger_for_after(source: str, after_ms: int) -> str:
    """Generate synthetic trigger for delayed transition with no explicit trigger."""
    return f"_after_{source}_{after_ms}_ms"


def auto_trigger(source: str) -> str:
    """Generate synthetic trigger for auto (eventless) transitions."""
    return f"_auto_{source}"


# ---------------------------------------------------------------------------
# Guard / action spec parsing
# ---------------------------------------------------------------------------


def parse_guard_specs(raw: Any) -> tuple[GuardSpec, ...]:
    """Parse guards field to tuple of GuardSpec."""
    items = normalize_to_list(raw)
    return tuple(
        GuardSpec.from_config(item) if isinstance(item, dict) else GuardSpec(name=item)
        for item in items
    )


def parse_action_specs(raw: Any) -> tuple[ActionSpec, ...]:
    """Parse actions/on_enter/on_exit field to tuple of ActionSpec."""
    items = normalize_to_list(raw)
    return tuple(
        (
            ActionSpec.from_config(item)
            if isinstance(item, dict)
            else ActionSpec(name=item)
        )
        for item in items
    )


def normalize_to_list(raw: Any) -> list[Any]:
    """Normalize a value to a list (handles None, str, dict, list)."""
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw]
    if isinstance(raw, dict):
        return [raw]
    if isinstance(raw, list):
        return list(raw)
    return []


# ---------------------------------------------------------------------------
# Wildcard expansion
# ---------------------------------------------------------------------------


def expand_wildcard_sources(
    states: dict[str, State],
    transitions: list[Transition],
) -> list[Transition]:
    """Expand wildcard source '*' to all non-terminal state names."""
    non_terminal = frozenset(
        name for name, state in states.items() if not state.is_terminal
    )
    if not non_terminal:
        return transitions

    expanded: list[Transition] = []
    for t in transitions:
        if t.source == frozenset({"*"}):
            expanded.append(
                Transition(
                    trigger=t.trigger,
                    source=non_terminal,
                    dest=t.dest,
                    region=t.region,
                    guards=t.guards,
                    actions=t.actions,
                    after=t.after,
                    internal=t.internal,
                    auto=t.auto,
                    priority=t.priority,
                    description=t.description,
                    refs=t.refs,
                    metadata=t.metadata,
                )
            )
        else:
            expanded.append(t)
    return expanded


# ---------------------------------------------------------------------------
# Entry/exit point resolution
# ---------------------------------------------------------------------------


def resolve_entry_exit_points(
    states: dict[str, State],
    transitions: list[Transition],
) -> list[Transition]:
    """Resolve ``parent:point`` references in transition source/dest.

    - ``dest = "parent:point"`` where *point* is a declared entry point resolves
      to the child state named *point*.
    - ``source = "parent:point"`` where *point* is a declared exit point resolves
      to the child state named *point*.
    """
    resolved: list[Transition] = []
    for t in transitions:
        new_dest = _resolve_entry_point(t.dest, states)
        new_sources = frozenset(_resolve_exit_point(src, states) for src in t.source)
        if new_dest != t.dest or new_sources != t.source:
            resolved.append(
                Transition(
                    trigger=t.trigger,
                    source=new_sources,
                    dest=new_dest,
                    region=t.region,
                    guards=t.guards,
                    actions=t.actions,
                    after=t.after,
                    internal=t.internal,
                    auto=t.auto,
                    priority=t.priority,
                    description=t.description,
                    refs=t.refs,
                    metadata=t.metadata,
                )
            )
        else:
            resolved.append(t)
    return resolved


def _resolve_entry_point(dest: str, states: dict[str, State]) -> str:
    """Resolve ``parent:point`` dest to the entry point child state."""
    m = _ENTRY_EXIT_RE.match(dest)
    if m is None:
        return dest
    parent_name, point_name = m.group(1), m.group(2)
    parent = states.get(parent_name)
    if parent is None:
        return dest
    if point_name in parent.entry_points:
        return point_name
    return dest


def _resolve_exit_point(source: str, states: dict[str, State]) -> str:
    """Resolve ``parent:point`` source to the exit point child state."""
    m = _ENTRY_EXIT_RE.match(source)
    if m is None:
        return source
    parent_name, point_name = m.group(1), m.group(2)
    parent = states.get(parent_name)
    if parent is None:
        return source
    if point_name in parent.exit_points:
        return point_name
    return source
