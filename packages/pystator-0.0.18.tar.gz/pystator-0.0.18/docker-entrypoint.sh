#!/bin/bash
set -euo pipefail

# ---------------------------------------------------------------------------
# PyStator Docker Entrypoint
#
# Dispatches to the correct CLI command based on SERVICE env var or first arg.
# Optionally runs DB migrations before starting the service.
# Uses exec for proper PID 1 signal forwarding (graceful shutdown).
# ---------------------------------------------------------------------------

# --- Run DB migrations if requested ----------------------------------------
if [ "${RUN_MIGRATIONS:-false}" = "true" ]; then
    echo "[entrypoint] Running database migrations..."
    pystator db upgrade || echo "[entrypoint] WARNING: Migration failed (may already be current)"
fi

# --- Dispatch based on first argument or SERVICE env var -------------------
SERVICE_CMD="${1:-${SERVICE:-api}}"

case "$SERVICE_CMD" in
    api)
        echo "[entrypoint] Starting PyStator API server..."
        exec pystator api \
            --host "${API_HOST:-0.0.0.0}" \
            --port "${API_PORT:-8004}" \
            --no-reload
        ;;
    worker)
        echo "[entrypoint] Starting PyStator worker..."
        exec pystator worker \
            --concurrency "${WORKER_CONCURRENCY:-5}" \
            --poll-interval "${WORKER_POLL_INTERVAL:-500}"
        ;;
    ui)
        echo "[entrypoint] Starting PyStator UI server..."
        exec pystator ui serve \
            --host "${UI_HOST:-0.0.0.0}" \
            --port "${UI_PORT:-3004}"
        ;;
    *)
        # Pass through any other command (e.g., bash, sh, pystator db upgrade)
        exec "$@"
        ;;
esac
