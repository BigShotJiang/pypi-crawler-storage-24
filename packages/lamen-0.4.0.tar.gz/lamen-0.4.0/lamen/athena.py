from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional
from .http import HttpClient, AsyncHttpClient
from .types import AthenaLogicEventIngest, AthenaIngestResponse


class AthenaClient:
    """Athena ingest (API key): POST /athena/api/events"""

    def __init__(self, http: HttpClient):
        self._http = http

    def ingest_event(
        self,
        *,
        external_user_id: str,
        event_name: str,
        occurred_at: datetime,
        properties: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> AthenaIngestResponse:
        payload = AthenaLogicEventIngest(
            external_user_id=external_user_id,
            event_name=event_name,
            occurred_at=occurred_at,
            properties=properties,
            idempotency_key=idempotency_key,
        )
        data = self._http.post("/athena/api/events", json=payload.model_dump())
        return AthenaIngestResponse.model_validate(data)


class AsyncAthenaClient:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def ingest_event(
        self,
        *,
        external_user_id: str,
        event_name: str,
        occurred_at: datetime,
        properties: Optional[Dict[str, Any]] = None,
        idempotency_key: Optional[str] = None,
    ) -> AthenaIngestResponse:
        payload = AthenaLogicEventIngest(
            external_user_id=external_user_id,
            event_name=event_name,
            occurred_at=occurred_at,
            properties=properties,
            idempotency_key=idempotency_key,
        )
        data = await self._http.post("/athena/api/events", json=payload.model_dump())
        return AthenaIngestResponse.model_validate(data)
