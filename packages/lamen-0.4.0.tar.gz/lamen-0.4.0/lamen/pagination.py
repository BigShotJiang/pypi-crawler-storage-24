from __future__ import annotations
from typing import Any, Callable, Dict, Iterator, List, Optional

def paginate(
    fetch_page: Callable[[Optional[str]], Dict[str, Any]],
    *,
    cursor_key: str = "next_cursor",
    items_key: str = "items",
) -> Iterator[dict]:
    cursor: Optional[str] = None
    while True:
        page = fetch_page(cursor)
        items = page.get(items_key) or []
        for item in items:
            yield item
        cursor = page.get(cursor_key)
        if not cursor:
            break
