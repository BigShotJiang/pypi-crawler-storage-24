from __future__ import annotations

from uuid import UUID

from .http import HttpClient, AsyncHttpClient
from .types import StreamUrlResponse


class StreamClient:
    """Streaming/CDN signed URL API (API key)."""

    def __init__(self, http: HttpClient):
        self._http = http

    def get_stream_url(self, *, object_id: UUID, expiry_in_seconds: int = 3600) -> StreamUrlResponse:
        data = self._http.get(f"/cdn/{object_id}/url", params={"expiry_in_seconds": expiry_in_seconds})
        return StreamUrlResponse.model_validate(data)
    
    def get_playback_url(self, *, object_id: UUID, expiry_in_seconds: int = 3600) -> StreamUrlResponse:
        data = self._http.get(
            f"/cdn/{object_id}/playback-url",
            params={"expiry_in_seconds": expiry_in_seconds},
        )
        return StreamUrlResponse.model_validate(data)


class AsyncStreamClient:
    def __init__(self, http: AsyncHttpClient):
        self._http = http

    async def get_stream_url(self, *, object_id: UUID, expiry_in_seconds: int = 3600) -> StreamUrlResponse:
        data = await self._http.get(f"/cdn/{object_id}/url", params={"expiry_in_seconds": expiry_in_seconds})
        return StreamUrlResponse.model_validate(data)
    
    async def get_playback_url(self, *, object_id: UUID, expiry_in_seconds: int = 3600) -> StreamUrlResponse:
        data = await self._http.get(
            f"/cdn/{object_id}/playback-url",
            params={"expiry_in_seconds": expiry_in_seconds},
        )
        return StreamUrlResponse.model_validate(data)
