from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class LamenError(Exception):
    """Base exception for the SDK."""


@dataclass
class ApiError(LamenError):
    status_code: int
    message: str
    method: str
    path: str
    response_json: Optional[dict] = None
    request_id: Optional[str] = None

    def __str__(self) -> str:
        rid = f" request_id={self.request_id}" if self.request_id else ""
        return f"ApiError({self.status_code}) {self.method} {self.path}: {self.message}{rid}"


class AuthenticationError(LamenError):
    pass


class BillingError(LamenError):
    pass


class ValidationError(LamenError):
    pass


class RateLimitError(LamenError):
    pass


class TimeoutError(LamenError):
    pass


class NetworkError(LamenError):
    pass
