# crush-config

Tool for statically configuring Crush CLI
