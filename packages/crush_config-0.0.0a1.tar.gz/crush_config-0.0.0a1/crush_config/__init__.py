"""Tool for statically configuring Crush CLI"""

__version__ = "0.0.0a1"
