from __future__ import annotations

import respx
from httpx import Response

from near_langchain_tx_builder.rpc import NEARRPCClient


@respx.mock
def test_rpc_fallback_retries_and_succeeds() -> None:
    # First mainnet endpoint fails, second succeeds.
    respx.post("https://rpc.mainnet.near.org").mock(return_value=Response(503, json={"error": "down"}))
    respx.post("https://free.rpc.fastnear.com").mock(
        return_value=Response(200, json={"jsonrpc": "2.0", "id": "x", "result": {"gas_price": "100000000"}})
    )

    client = NEARRPCClient(timeout_seconds=1, max_retries=2, backoff_seconds=0)
    value = client.gas_price_yocto("mainnet")
    assert value == "100000000"
