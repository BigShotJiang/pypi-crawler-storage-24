from near_langchain_tx_builder.builder import NEARTransactionBuilder
from near_langchain_tx_builder.errors import NEARTxBuilderError


class FakeRPC:
    def gas_price_yocto(self, network: str) -> str:
        return "100000000"

    def account_exists(self, account_id: str, network: str) -> bool:
        return True

    def preflight_call_function(self, *, network: str, account_id: str, method_name: str, args: dict):
        return {"logs": ["ok"]}


def test_build_transfer_tx() -> None:
    builder = NEARTransactionBuilder(rpc_client=FakeRPC())
    tx = builder.build_transfer_tx(
        signer_id="alice.near",
        receiver_id="bob.near",
        amount_near="1.25",
    )
    assert tx["actions"][0]["type"] == "transfer"
    assert tx["actions"][0]["params"]["deposit_yocto"] == "1250000000000000000000000"


def test_build_function_call_tx() -> None:
    builder = NEARTransactionBuilder(rpc_client=FakeRPC())
    tx = builder.build_function_call_tx(
        signer_id="alice.near",
        receiver_id="social.near",
        method_name="set",
        args={"a": 1},
        gas_tgas=25,
    )
    assert tx["actions"][0]["params"]["gas"] == str(25 * 1_000_000_000_000)


def test_build_batch_tx_invalid_action() -> None:
    builder = NEARTransactionBuilder(rpc_client=FakeRPC())
    try:
        builder.build_batch_tx(
            signer_id="alice.near",
            receiver_id="bob.near",
            actions=[{"type": "stake"}],
        )
        assert False, "expected exception"
    except NEARTxBuilderError as exc:
        assert exc.code == "invalid_action"


def test_estimate_and_simulate() -> None:
    builder = NEARTransactionBuilder(rpc_client=FakeRPC())
    tx = builder.build_function_call_tx(
        signer_id="alice.near",
        receiver_id="social.near",
        method_name="get",
        args={"k": "v"},
        gas_tgas=10,
        deposit_near="0",
    )
    estimate = builder.estimate_gas(tx)
    assert estimate["estimated_tgas"] > 0

    sim = builder.simulate_transaction(tx, check_accounts=True, preflight_view_calls=True)
    assert sim["ok"] is True
    assert sim["actions_count"] == 1


def test_apply_template() -> None:
    builder = NEARTransactionBuilder(rpc_client=FakeRPC())
    tx = builder.apply_template(
        template_name="simple_transfer",
        signer_id="alice.near",
        receiver_id="bob.near",
        variables={"amount_near": "2"},
    )
    assert tx["metadata"]["kind"] == "transfer"


def test_list_templates() -> None:
    builder = NEARTransactionBuilder(rpc_client=FakeRPC())
    data = builder.list_templates()
    assert data["count"] >= 4
    names = {x["name"] for x in data["templates"]}
    assert "simple_transfer" in names
    assert "ft_transfer" in names
