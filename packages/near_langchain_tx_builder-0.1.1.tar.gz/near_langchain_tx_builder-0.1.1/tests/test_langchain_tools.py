import json

from near_langchain_tx_builder.langchain_tools import get_near_transaction_tools


def test_tools_exist() -> None:
    tools = get_near_transaction_tools()
    names = {tool.name for tool in tools}
    assert "near_build_transfer_tx" in names
    assert "near_simulate_tx" in names
    assert "near_list_tx_templates" in names


def test_tool_returns_json() -> None:
    tools = {tool.name: tool for tool in get_near_transaction_tools()}
    out = tools["near_build_transfer_tx"].invoke(
        {
            "signer_id": "alice.near",
            "receiver_id": "bob.near",
            "amount_near": "1",
            "network": "mainnet",
        }
    )
    data = json.loads(out)
    assert data["signer_id"] == "alice.near"


def test_list_templates_tool_returns_json() -> None:
    tools = {tool.name: tool for tool in get_near_transaction_tools()}
    out = tools["near_list_tx_templates"].invoke({})
    data = json.loads(out)
    assert data["count"] >= 4
