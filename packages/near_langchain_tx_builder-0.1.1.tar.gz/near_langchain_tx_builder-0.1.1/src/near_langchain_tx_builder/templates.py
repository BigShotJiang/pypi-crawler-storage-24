from __future__ import annotations

from copy import deepcopy
from typing import Any

TEMPLATES: dict[str, dict[str, Any]] = {
    "simple_transfer": {
        "description": "Single transfer action transaction template",
        "actions": [
            {
                "type": "transfer",
                "amount_near": "1",
            }
        ]
    },
    "ft_transfer": {
        "description": "Fungible token transfer via ft_transfer",
        "actions": [
            {
                "type": "function_call",
                "method_name": "ft_transfer",
                "args": {"receiver_id": "receiver.near", "amount": "1"},
                "gas_tgas": 30,
                "deposit_near": "0.000000000000000000000001",
            }
        ]
    },
    "nft_transfer": {
        "description": "NFT transfer via nft_transfer",
        "actions": [
            {
                "type": "function_call",
                "method_name": "nft_transfer",
                "args": {"receiver_id": "receiver.near", "token_id": "1"},
                "gas_tgas": 30,
                "deposit_near": "0.000000000000000000000001",
            }
        ]
    },
    "contract_call": {
        "description": "Generic state-changing contract call",
        "actions": [
            {
                "type": "function_call",
                "method_name": "set_value",
                "args": {"value": "example"},
                "gas_tgas": 30,
                "deposit_near": "0",
            }
        ]
    },
}


def get_template(template_name: str) -> dict[str, Any]:
    if template_name not in TEMPLATES:
        raise KeyError(template_name)
    return deepcopy(TEMPLATES[template_name])


def get_template_summaries() -> list[dict[str, Any]]:
    return [
        {
            "name": name,
            "description": payload.get("description", ""),
            "actions_count": len(payload.get("actions", [])),
        }
        for name, payload in TEMPLATES.items()
    ]
