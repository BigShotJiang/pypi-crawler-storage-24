from __future__ import annotations

from decimal import Decimal
from typing import Any, Optional

from .errors import NEARTxBuilderError
from .models import FunctionCallActionParams, NEARTransaction, TransferActionParams, TxAction, near_to_yocto, validate_account_id
from .rpc import NEARRPCClient
from .templates import get_template, get_template_summaries

YOCTO_PER_NEAR = Decimal("1000000000000000000000000")
TGAS_TO_GAS = 1_000_000_000_000


class NEARTransactionBuilder:
    def __init__(self, rpc_client: Optional[NEARRPCClient] = None):
        self.rpc = rpc_client or NEARRPCClient()

    @staticmethod
    def _validate_network(network: str) -> str:
        if network not in {"mainnet", "testnet"}:
            raise NEARTxBuilderError("invalid_network", "network must be mainnet or testnet", {"network": network})
        return network

    def build_transfer_tx(
        self,
        *,
        signer_id: str,
        receiver_id: str,
        amount_near: str,
        network: str = "mainnet",
        memo: Optional[str] = None,
    ) -> dict[str, Any]:
        self._validate_network(network)
        validate_account_id(signer_id)
        validate_account_id(receiver_id)

        deposit_yocto = near_to_yocto(amount_near)
        params = TransferActionParams(amount_near=str(amount_near), deposit_yocto=deposit_yocto).model_dump()
        action = TxAction(type="transfer", params=params)

        tx = NEARTransaction(
            network=network,
            signer_id=signer_id,
            receiver_id=receiver_id,
            actions=[action],
            metadata={"kind": "transfer", "memo": memo or ""},
        )
        return tx.model_dump()

    def build_function_call_tx(
        self,
        *,
        signer_id: str,
        receiver_id: str,
        method_name: str,
        args: dict[str, Any],
        gas_tgas: float = 30,
        deposit_near: str = "0",
        network: str = "mainnet",
    ) -> dict[str, Any]:
        self._validate_network(network)
        validate_account_id(signer_id)
        validate_account_id(receiver_id)

        if not method_name or len(method_name) > 256:
            raise NEARTxBuilderError("invalid_action", "method_name must be between 1 and 256 chars")
        if gas_tgas <= 0 or gas_tgas > 300:
            raise NEARTxBuilderError("invalid_action", "gas_tgas must be > 0 and <= 300", {"gas_tgas": gas_tgas})

        gas_units = int(gas_tgas * TGAS_TO_GAS)
        params = FunctionCallActionParams(
            method_name=method_name,
            args=args,
            gas=str(gas_units),
            gas_tgas=float(gas_tgas),
            deposit_near=str(deposit_near),
            deposit_yocto=near_to_yocto(deposit_near),
        ).model_dump()

        action = TxAction(type="function_call", params=params)
        tx = NEARTransaction(
            network=network,
            signer_id=signer_id,
            receiver_id=receiver_id,
            actions=[action],
            metadata={"kind": "function_call"},
        )
        return tx.model_dump()

    def build_batch_tx(
        self,
        *,
        signer_id: str,
        receiver_id: str,
        actions: list[dict[str, Any]],
        network: str = "mainnet",
    ) -> dict[str, Any]:
        self._validate_network(network)
        validate_account_id(signer_id)
        validate_account_id(receiver_id)

        if not actions:
            raise NEARTxBuilderError("invalid_action", "actions cannot be empty")

        built_actions: list[TxAction] = []
        for index, action in enumerate(actions):
            action_type = action.get("type")
            if action_type == "transfer":
                if "amount_near" not in action:
                    raise NEARTxBuilderError(
                        "invalid_action",
                        "transfer action requires amount_near",
                        {"index": index},
                    )
                params = TransferActionParams(
                    amount_near=str(action["amount_near"]),
                    deposit_yocto=near_to_yocto(str(action["amount_near"])),
                ).model_dump()
                built_actions.append(TxAction(type="transfer", params=params))
            elif action_type == "function_call":
                method_name = action.get("method_name")
                if not method_name:
                    raise NEARTxBuilderError(
                        "invalid_action",
                        "function_call action requires method_name",
                        {"index": index},
                    )
                gas_tgas = float(action.get("gas_tgas", 30))
                if gas_tgas <= 0 or gas_tgas > 300:
                    raise NEARTxBuilderError(
                        "invalid_action",
                        "function_call gas_tgas must be > 0 and <= 300",
                        {"index": index, "gas_tgas": gas_tgas},
                    )
                params = FunctionCallActionParams(
                    method_name=str(method_name),
                    args=action.get("args", {}),
                    gas=str(int(gas_tgas * TGAS_TO_GAS)),
                    gas_tgas=gas_tgas,
                    deposit_near=str(action.get("deposit_near", "0")),
                    deposit_yocto=near_to_yocto(str(action.get("deposit_near", "0"))),
                ).model_dump()
                built_actions.append(TxAction(type="function_call", params=params))
            else:
                raise NEARTxBuilderError(
                    "invalid_action",
                    "action type must be transfer or function_call",
                    {"index": index, "action_type": action_type},
                )

        tx = NEARTransaction(
            network=network,
            signer_id=signer_id,
            receiver_id=receiver_id,
            actions=built_actions,
            metadata={"kind": "batch", "actions_count": len(built_actions)},
        )
        return tx.model_dump()

    def estimate_gas(self, transaction: dict[str, Any]) -> dict[str, Any]:
        tx = NEARTransaction(**transaction)

        total_tgas = Decimal("1.5")
        assumptions: list[str] = ["Base overhead = 1.5 TGas"]

        for action in tx.actions:
            if action.type == "transfer":
                total_tgas += Decimal("0.45")
                assumptions.append("Transfer action = 0.45 TGas")
            elif action.type == "function_call":
                action_gas_tgas = Decimal(str(action.params.get("gas_tgas", 30)))
                total_tgas += action_gas_tgas
                assumptions.append(f"Function call action uses provided gas_tgas={action_gas_tgas}")

        gas_units = int(total_tgas * TGAS_TO_GAS)
        gas_price_yocto = Decimal(self.rpc.gas_price_yocto(tx.network))
        total_cost_yocto = gas_price_yocto * Decimal(gas_units)
        cost_near = total_cost_yocto / YOCTO_PER_NEAR

        return {
            "network": tx.network,
            "estimated_tgas": float(total_tgas),
            "estimated_gas_units": gas_units,
            "gas_price_yocto_per_gas": str(int(gas_price_yocto)),
            "estimated_cost_near": f"{cost_near:.12f}",
            "assumptions": assumptions,
        }

    def simulate_transaction(
        self,
        transaction: dict[str, Any],
        *,
        check_accounts: bool = True,
        preflight_view_calls: bool = False,
    ) -> dict[str, Any]:
        tx = NEARTransaction(**transaction)
        warnings: list[str] = []
        checks: list[dict[str, Any]] = []

        try:
            estimate = self.estimate_gas(tx.model_dump())
        except NEARTxBuilderError as exc:
            raise NEARTxBuilderError("simulation_error", "failed to estimate gas", exc.to_dict()) from exc

        if check_accounts:
            signer_exists = self.rpc.account_exists(tx.signer_id, tx.network)
            receiver_exists = self.rpc.account_exists(tx.receiver_id, tx.network)
            checks.extend(
                [
                    {"check": "signer_exists", "ok": signer_exists, "account_id": tx.signer_id},
                    {"check": "receiver_exists", "ok": receiver_exists, "account_id": tx.receiver_id},
                ]
            )
            if not signer_exists:
                warnings.append(f"Signer account does not exist on {tx.network}: {tx.signer_id}")
            if not receiver_exists:
                warnings.append(f"Receiver account does not exist on {tx.network}: {tx.receiver_id}")

        total_deposit_yocto = Decimal("0")
        for action in tx.actions:
            if action.type == "transfer":
                total_deposit_yocto += Decimal(action.params["deposit_yocto"])
            elif action.type == "function_call":
                total_deposit_yocto += Decimal(action.params["deposit_yocto"])

                args_size = len(str(action.params.get("args", {})).encode("utf-8"))
                if args_size > 16 * 1024:
                    warnings.append(
                        f"Large function-call args payload ({args_size} bytes) may increase gas and fail limits"
                    )

                if preflight_view_calls and Decimal(str(action.params.get("deposit_yocto", "0"))) == 0:
                    method_name = str(action.params.get("method_name", ""))
                    try:
                        response = self.rpc.preflight_call_function(
                            network=tx.network,
                            account_id=tx.receiver_id,
                            method_name=method_name,
                            args=action.params.get("args", {}),
                        )
                        checks.append(
                            {
                                "check": "preflight_call_function",
                                "ok": True,
                                "method_name": method_name,
                                "logs": response.get("logs", []),
                            }
                        )
                    except NEARTxBuilderError as exc:
                        checks.append(
                            {
                                "check": "preflight_call_function",
                                "ok": False,
                                "method_name": method_name,
                                "error": exc.to_dict(),
                            }
                        )
                        warnings.append(
                            f"Preflight call failed for method '{method_name}'. Method may be state-changing or invalid."
                        )

        total_deposit_near = total_deposit_yocto / YOCTO_PER_NEAR

        if estimate["estimated_tgas"] > 300:
            warnings.append("Estimated total gas is above 300 TGas and may fail on-chain.")

        return {
            "ok": True,
            "network": tx.network,
            "signer_id": tx.signer_id,
            "receiver_id": tx.receiver_id,
            "actions_count": len(tx.actions),
            "estimated": estimate,
            "attached_deposit_near": f"{total_deposit_near:.12f}",
            "checks": checks,
            "warnings": warnings,
            "summary": "Simulation completed. This is a pre-execution safety check, not an on-chain execution.",
        }

    def apply_template(
        self,
        *,
        template_name: str,
        signer_id: str,
        receiver_id: str,
        variables: Optional[dict[str, Any]] = None,
        network: str = "mainnet",
    ) -> dict[str, Any]:
        self._validate_network(network)
        validate_account_id(signer_id)
        validate_account_id(receiver_id)

        variables = variables or {}
        try:
            template = get_template(template_name)
        except KeyError as exc:
            raise NEARTxBuilderError(
                "invalid_template",
                f"unknown template '{template_name}'. Available templates: simple_transfer, ft_transfer, nft_transfer, contract_call",
            ) from exc

        actions = template["actions"]
        if template_name == "simple_transfer":
            amount_near = str(variables.get("amount_near", actions[0].get("amount_near", "1")))
            return self.build_transfer_tx(
                signer_id=signer_id,
                receiver_id=receiver_id,
                amount_near=amount_near,
                network=network,
                memo=variables.get("memo"),
            )

        action = actions[0]
        return self.build_function_call_tx(
            signer_id=signer_id,
            receiver_id=receiver_id,
            method_name=str(variables.get("method_name", action["method_name"])),
            args=variables.get("args", action.get("args", {})),
            gas_tgas=float(variables.get("gas_tgas", action.get("gas_tgas", 30))),
            deposit_near=str(variables.get("deposit_near", action.get("deposit_near", "0"))),
            network=network,
        )

    @staticmethod
    def list_templates() -> dict[str, Any]:
        templates = get_template_summaries()
        return {"templates": templates, "count": len(templates)}
