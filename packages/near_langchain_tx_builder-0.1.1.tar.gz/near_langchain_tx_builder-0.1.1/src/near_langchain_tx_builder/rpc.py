from __future__ import annotations

import base64
import itertools
import json
import time
from typing import Any

import httpx

from .errors import NEARTxBuilderError

RPC_BY_NETWORK = {
    "mainnet": [
        "https://rpc.mainnet.near.org",
        "https://free.rpc.fastnear.com",
    ],
    "testnet": [
        "https://rpc.testnet.near.org",
        "https://test.rpc.fastnear.com",
    ],
}


class NEARRPCClient:
    def __init__(self, timeout_seconds: float = 15.0, max_retries: int = 3, backoff_seconds: float = 0.5):
        self.timeout_seconds = timeout_seconds
        self.max_retries = max_retries
        self.backoff_seconds = backoff_seconds

    def _rpc(self, network: str, method: str, params: Any) -> dict[str, Any]:
        rpc_urls = RPC_BY_NETWORK.get(network)
        if rpc_urls is None:
            raise NEARTxBuilderError("invalid_network", "network must be mainnet or testnet", {"network": network})

        payload = {"jsonrpc": "2.0", "id": "near-langchain-tx-builder", "method": method, "params": params}
        errors: list[str] = []
        cycle = itertools.cycle(rpc_urls)
        attempts = max(1, self.max_retries)

        for attempt in range(attempts):
            rpc_url = next(cycle)
            try:
                with httpx.Client(timeout=self.timeout_seconds) as client:
                    response = client.post(rpc_url, json=payload)
                    response.raise_for_status()
                    data = response.json()
            except httpx.HTTPError as exc:
                errors.append(f"{rpc_url}: {exc}")
                if attempt < attempts - 1:
                    time.sleep(self.backoff_seconds * (attempt + 1))
                continue

            if "error" in data:
                err = data["error"]
                message = err.get("message", "NEAR RPC returned error")
                # Account not found should short-circuit immediately for account existence checks.
                if isinstance(message, str) and "does not exist" in message.lower():
                    raise NEARTxBuilderError("rpc_error", message, {"rpc_error": err, "rpc_url": rpc_url})
                errors.append(f"{rpc_url}: {message}")
                if attempt < attempts - 1:
                    time.sleep(self.backoff_seconds * (attempt + 1))
                continue

            return data.get("result", {})

        raise NEARTxBuilderError(
            "rpc_error",
            "failed to reach NEAR RPC after retries",
            {"network": network, "attempts": attempts, "errors": errors},
        )

    def account_exists(self, account_id: str, network: str) -> bool:
        params = {"request_type": "view_account", "account_id": account_id, "finality": "final"}
        try:
            self._rpc(network, "query", params)
            return True
        except NEARTxBuilderError as exc:
            if exc.code == "rpc_error" and "does not exist" in exc.message.lower():
                return False
            raise

    def gas_price_yocto(self, network: str) -> str:
        result = self._rpc(network, "gas_price", [None])
        value = result.get("gas_price")
        if value is None:
            raise NEARTxBuilderError("rpc_error", "gas_price not found in RPC response")
        return str(value)

    def preflight_call_function(
        self,
        *,
        network: str,
        account_id: str,
        method_name: str,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        args_json = json.dumps(args, separators=(",", ":")).encode("utf-8")
        params = {
            "request_type": "call_function",
            "account_id": account_id,
            "method_name": method_name,
            "args_base64": base64.b64encode(args_json).decode("ascii"),
            "finality": "final",
        }
        return self._rpc(network, "query", params)
