from __future__ import annotations

from decimal import Decimal, InvalidOperation
from typing import Any, Literal
import re

from pydantic import BaseModel, Field, field_validator

from .errors import NEARTxBuilderError

YOCTO_MULTIPLIER = Decimal("1000000000000000000000000")
ACCOUNT_RE = re.compile(r"^(([a-z\d]+[-_])*[a-z\d]+\.)*([a-z\d]+[-_])*[a-z\d]+$|^[a-f0-9]{64}$")


class Network(str):
    MAINNET = "mainnet"
    TESTNET = "testnet"


def validate_account_id(account_id: str) -> str:
    if not account_id or len(account_id) < 2 or len(account_id) > 64:
        raise NEARTxBuilderError(
            "invalid_account_id", "account_id must be between 2 and 64 characters", {"account_id": account_id}
        )
    if not ACCOUNT_RE.fullmatch(account_id):
        raise NEARTxBuilderError("invalid_account_id", "invalid NEAR account_id format", {"account_id": account_id})
    return account_id


def near_to_yocto(value: str) -> str:
    try:
        parsed = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise NEARTxBuilderError("invalid_amount", "amount must be a numeric string", {"amount": value})
    if parsed < 0:
        raise NEARTxBuilderError("invalid_amount", "amount must be >= 0", {"amount": str(value)})

    yocto = (parsed * YOCTO_MULTIPLIER).quantize(Decimal("1"))
    return str(int(yocto))


class TransferActionParams(BaseModel):
    amount_near: str
    deposit_yocto: str


class FunctionCallActionParams(BaseModel):
    method_name: str
    args: dict[str, Any] = Field(default_factory=dict)
    gas: str
    gas_tgas: float
    deposit_near: str
    deposit_yocto: str


class TxAction(BaseModel):
    type: Literal["transfer", "function_call"]
    params: dict[str, Any]


class NEARTransaction(BaseModel):
    network: Literal["mainnet", "testnet"] = "mainnet"
    signer_id: str
    receiver_id: str
    actions: list[TxAction]
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("signer_id")
    @classmethod
    def _validate_signer(cls, value: str) -> str:
        return validate_account_id(value)

    @field_validator("receiver_id")
    @classmethod
    def _validate_receiver(cls, value: str) -> str:
        return validate_account_id(value)
