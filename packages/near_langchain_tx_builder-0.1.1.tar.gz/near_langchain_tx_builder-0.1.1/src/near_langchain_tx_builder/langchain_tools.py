from __future__ import annotations

import json
from typing import Any, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from .builder import NEARTransactionBuilder
from .errors import NEARTxBuilderError


def _safe_json(data: dict[str, Any]) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def _wrap_error(exc: Exception) -> str:
    if isinstance(exc, NEARTxBuilderError):
        return _safe_json(exc.to_dict())
    return _safe_json({"error": "internal_error", "message": str(exc)})


class TransferInput(BaseModel):
    signer_id: str
    receiver_id: str
    amount_near: str
    network: str = "mainnet"
    memo: Optional[str] = None


class FunctionCallInput(BaseModel):
    signer_id: str
    receiver_id: str
    method_name: str
    args: dict[str, Any] = Field(default_factory=dict)
    gas_tgas: float = 30
    deposit_near: str = "0"
    network: str = "mainnet"


class BatchInput(BaseModel):
    signer_id: str
    receiver_id: str
    actions: list[dict[str, Any]]
    network: str = "mainnet"


class EstimateInput(BaseModel):
    transaction: dict[str, Any]


class SimulateInput(BaseModel):
    transaction: dict[str, Any]
    check_accounts: bool = True
    preflight_view_calls: bool = False


class TemplateInput(BaseModel):
    template_name: str
    signer_id: str
    receiver_id: str
    variables: dict[str, Any] = Field(default_factory=dict)
    network: str = "mainnet"


class NEARTransactionBuilderToolkit:
    def __init__(self, builder: Optional[NEARTransactionBuilder] = None):
        self.builder = builder or NEARTransactionBuilder()

    def get_tools(self) -> list[StructuredTool]:
        return [
            StructuredTool.from_function(
                name="near_build_transfer_tx",
                description="Build a NEAR transfer transaction payload.",
                args_schema=TransferInput,
                func=self._build_transfer,
            ),
            StructuredTool.from_function(
                name="near_build_function_call_tx",
                description="Build a NEAR function-call transaction payload.",
                args_schema=FunctionCallInput,
                func=self._build_function_call,
            ),
            StructuredTool.from_function(
                name="near_build_batch_tx",
                description="Build a NEAR batch transaction with multiple actions.",
                args_schema=BatchInput,
                func=self._build_batch,
            ),
            StructuredTool.from_function(
                name="near_estimate_tx_gas",
                description="Estimate gas usage and rough NEAR cost for a transaction payload.",
                args_schema=EstimateInput,
                func=self._estimate_gas,
            ),
            StructuredTool.from_function(
                name="near_simulate_tx",
                description="Simulate transaction safety checks before execution.",
                args_schema=SimulateInput,
                func=self._simulate,
            ),
            StructuredTool.from_function(
                name="near_apply_tx_template",
                description="Apply a built-in NEAR transaction template (simple_transfer, ft_transfer, nft_transfer, contract_call).",
                args_schema=TemplateInput,
                func=self._apply_template,
            ),
            StructuredTool.from_function(
                name="near_list_tx_templates",
                description="List built-in NEAR transaction templates with brief descriptions.",
                func=self._list_templates,
            ),
        ]

    def _build_transfer(self, **kwargs: Any) -> str:
        try:
            return _safe_json(self.builder.build_transfer_tx(**kwargs))
        except Exception as exc:
            return _wrap_error(exc)

    def _build_function_call(self, **kwargs: Any) -> str:
        try:
            return _safe_json(self.builder.build_function_call_tx(**kwargs))
        except Exception as exc:
            return _wrap_error(exc)

    def _build_batch(self, **kwargs: Any) -> str:
        try:
            return _safe_json(self.builder.build_batch_tx(**kwargs))
        except Exception as exc:
            return _wrap_error(exc)

    def _estimate_gas(self, **kwargs: Any) -> str:
        try:
            return _safe_json(self.builder.estimate_gas(**kwargs))
        except Exception as exc:
            return _wrap_error(exc)

    def _simulate(self, **kwargs: Any) -> str:
        try:
            return _safe_json(self.builder.simulate_transaction(**kwargs))
        except Exception as exc:
            return _wrap_error(exc)

    def _apply_template(self, **kwargs: Any) -> str:
        try:
            return _safe_json(self.builder.apply_template(**kwargs))
        except Exception as exc:
            return _wrap_error(exc)

    def _list_templates(self) -> str:
        try:
            return _safe_json(self.builder.list_templates())
        except Exception as exc:
            return _wrap_error(exc)


def get_near_transaction_tools() -> list[StructuredTool]:
    return NEARTransactionBuilderToolkit().get_tools()
