"""
Example usage of the Risk Assessment functions

This demonstrates how to use the risk assessment library.
"""

from rtv_workmate.risk_assessment import (
    set_config,
    list_models,
    get_model,
    create_model,
    update_model,
    APIError
)


def main():
    # Configure the API connection
    set_config(
        base_url="http://localhost:8000",
        api_key="wm_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
        # Alternative: jwt_token="your_jwt_token_here"
    )
    
    print("=== Risk Assessment Examples ===\n")
    
    # Example 1: List all models
    print("1. Listing all models...")
    try:
        models = list_models()
        print(f"   Found {len(models)} models")
        for model in models[:3]:  # Show first 3
            print(f"   - {model.get('name')} ({model.get('category')}) v{model.get('version')}")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 2: Get a specific model
    print("2. Getting a specific model...")
    try:
        model = get_model({
            'name': 'UG_North_1_C',
            'category': 'classification',
            'version': '2025.0.1'
        })
        print(f"   Model: {model.get('name')}")
        print(f"   Metrics: {model.get('metrics')}")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 3: Create a model
    print("3. Creating a model...")
    try:
        create_model({
            'name': 'UG_North_1_C',
            'category': 'classification',
            'version': '2025.0.1',
            'description': 'Latest model',
            'metrics': {'accuracy': 0.76},
            # 'model_file_path': '/path/to/model.pkl'  # Uncomment to upload file
        })
        print("   Model created successfully!")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 4: Update a model
    print("4. Updating a model...")
    try:
        updated = update_model(
            model_identifier={
                'name': 'UG_North_1_C',
                'category': 'classification',
                'version': '2025.0.1'
            },
            model_data={
                'metrics': {'accuracy': 0.78}
            }
        )
        print("   Model updated successfully!")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 5: Delete a model (commented for safety)
    print("5. Deleting a model (commented out)...")
    # try:
    #     delete_model({
    #         'name': 'UG_North_1_C',
    #         'category': 'classification',
    #         'version': '2025.0.1'
    #     })
    #     print("   Model deleted successfully!")
    # except APIError as e:
    #     print(f"   Error: {e}")
    print("   (Skipped - uncomment to test deletion)")


if __name__ == "__main__":
    main()
