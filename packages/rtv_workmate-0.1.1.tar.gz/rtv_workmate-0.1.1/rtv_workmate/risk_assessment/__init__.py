"""
Workmate Risk Assessment Library

A collection of functions for managing risk assessment models.
"""

from .config import set_config
from .models import (
    list_models,
    get_model,
    create_model,
    update_model,
    delete_model,
)
from .exceptions import APIError

__all__ = [
    'list_models',
    'get_model',
    'create_model',
    'update_model',
    'delete_model',
    'set_config',
    'APIError'
]
__version__ = '0.1.0'
