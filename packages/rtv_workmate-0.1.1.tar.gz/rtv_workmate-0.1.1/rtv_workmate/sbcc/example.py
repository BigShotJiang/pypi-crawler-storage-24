"""
Example usage of the SBCC functions

This demonstrates how to use the SBCC library.
"""

from rtv_workmate.sbcc import (
    set_config,
    list_message_feedbacks,
    get_message_feedback,
    create_message_feedback,
    update_message_feedback,
    partial_update_message_feedback,
    APIError
)


def main():
    # Configure the API connection
    set_config(
        base_url="http://localhost:8000",
        api_key="wm_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
        # Alternative: jwt_token="your_jwt_token_here"
    )
    
    print("=== SBCC Message Feedback Examples ===\n")
    
    # Example 1: List all message feedbacks
    print("1. Listing all message feedbacks...")
    try:
        feedbacks = list_message_feedbacks()
        print(f"   Found {len(feedbacks)} feedbacks")
        for feedback in feedbacks[:3]:  # Show first 3
            print(f"   - ID {feedback.get('id')}: {feedback.get('practice')} - {feedback.get('barrier')}")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 2: List with filters
    print("2. Listing with filters...")
    try:
        feedbacks = list_message_feedbacks(filters={
            'is_liked': True,
            'practice': 'Handwashing'
        })
        print(f"   Found {len(feedbacks)} liked feedbacks about Handwashing")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 3: Get a specific feedback
    print("3. Getting a specific feedback...")
    try:
        feedback = get_message_feedback(pk=1)
        print(f"   Practice: {feedback.get('practice')}")
        print(f"   Barrier: {feedback.get('barrier')}")
        print(f"   Liked: {feedback.get('is_liked')}")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 4: Create a feedback
    print("4. Creating a new feedback...")
    try:
        new_feedback = create_message_feedback({
            'form_guid': 'form-123',
            'user_guid': 'user-456',
            'practice': 'Handwashing',
            'barrier': 'Lack of soap',
            'generated_message': 'Remember to wash your hands with soap before eating.',
            'is_liked': True,
            'preferred_message': 'Please wash hands with soap before meals.',
            'test_mode': True  # Set to False to actually persist
        })
        print(f"   Created feedback ID: {new_feedback.get('id')}")
        print(f"   Practice: {new_feedback.get('practice')}")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 5: Update a feedback (full update)
    print("5. Updating a feedback (full update)...")
    try:
        updated = update_message_feedback(
            pk=1,
            feedback_data={
                'form_guid': 'form-123',
                'user_guid': 'user-456',
                'practice': 'Handwashing',
                'barrier': 'Lack of soap',
                'generated_message': 'Updated message about handwashing.',
                'is_liked': False,
                'preferred_message': 'Updated preferred message.',
                'test_mode': True  # Set to False to actually persist
            }
        )
        print("   Feedback updated successfully!")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 6: Partial update
    print("6. Partially updating a feedback...")
    try:
        updated = partial_update_message_feedback(
            pk=1,
            feedback_data={
                'is_liked': True,
                'preferred_message': 'New preferred message',
                'test_mode': True  # Set to False to actually persist
            }
        )
        print("   Feedback partially updated successfully!")
        print(f"   Liked: {updated.get('is_liked')}")
    except APIError as e:
        print(f"   Error: {e}")
    
    print()
    
    # Example 7: Delete a feedback (commented for safety)
    print("7. Deleting a feedback (commented out)...")
    # try:
    #     delete_message_feedback(
    #         pk=1,
    #         test_mode=True  # Set to False to actually persist
    #     )
    #     print("   Feedback deleted successfully!")
    # except APIError as e:
    #     print(f"   Error: {e}")
    print("   (Skipped - uncomment to test deletion)")


if __name__ == "__main__":
    main()
