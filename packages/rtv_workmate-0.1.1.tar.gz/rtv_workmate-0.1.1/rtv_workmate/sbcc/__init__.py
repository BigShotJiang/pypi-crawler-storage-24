"""
Workmate SBCC Library

A collection of functions for managing SBCC message feedback.
"""

from .config import set_config
from .message_feedback import (
    list_message_feedbacks,
    get_message_feedback,
    create_message_feedback,
    update_message_feedback,
    partial_update_message_feedback,
    delete_message_feedback,
)
from .exceptions import APIError

__all__ = [
    'set_config',
    'list_message_feedbacks',
    'get_message_feedback',
    'create_message_feedback',
    'update_message_feedback',
    'partial_update_message_feedback',
    'delete_message_feedback',
    'APIError'
]
__version__ = '0.1.0'
