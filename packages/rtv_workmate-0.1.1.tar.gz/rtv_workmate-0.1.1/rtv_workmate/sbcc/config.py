"""
Configuration for SBCC API

Stores global configuration for API base URL and authentication.
"""

from typing import Optional

_base_url: Optional[str] = None
_api_key: Optional[str] = None
_jwt_token: Optional[str] = None


def set_config(
    base_url: str,
    api_key: Optional[str] = None,
    jwt_token: Optional[str] = None
):
    """
    Set global configuration for API requests.
    
    Args:
        base_url: Base URL of the API (e.g., "http://localhost:8000")
        api_key: API key for authentication (optional if using JWT)
        jwt_token: JWT token for authentication (optional if using API key)
    
    Raises:
        ValueError: If neither api_key nor jwt_token is provided
    """
    global _base_url, _api_key, _jwt_token
    
    if not api_key and not jwt_token:
        raise ValueError("Either api_key or jwt_token must be provided")
    
    _base_url = base_url.rstrip('/')
    _api_key = api_key
    _jwt_token = jwt_token


def get_config():
    """Get current configuration."""
    return {
        'base_url': _base_url,
        'api_key': _api_key,
        'jwt_token': _jwt_token
    }


def get_headers(test_mode: bool = False) -> dict:
    """
    Get headers for API requests based on current config.
    
    Args:
        test_mode: If True, adds X-Test-Mode header
    """
    headers = {}
    if _api_key:
        headers['X-API-Key'] = _api_key
    elif _jwt_token:
        headers['Authorization'] = f'Bearer {_jwt_token}'
    
    if test_mode:
        headers['X-Test-Mode'] = 'true'
    
    return headers


def get_base_path() -> str:
    """Get base path for API requests."""
    if not _base_url:
        raise ValueError("Configuration not set. Call set_config() first.")
    return f"{_base_url}/sbcc"
