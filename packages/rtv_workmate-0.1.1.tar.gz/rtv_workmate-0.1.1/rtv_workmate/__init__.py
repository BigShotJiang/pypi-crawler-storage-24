"""
Workmate Library

A Python client library for interacting with Workmate APIs.
"""

__version__ = '0.1.0'
