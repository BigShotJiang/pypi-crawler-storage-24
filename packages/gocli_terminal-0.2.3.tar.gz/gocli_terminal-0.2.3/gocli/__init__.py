"""goCLI — terminal error detection and auto-fix assistant."""

__version__ = "0.1.0"
