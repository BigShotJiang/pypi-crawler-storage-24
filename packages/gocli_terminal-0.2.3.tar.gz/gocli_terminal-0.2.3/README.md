# goCLI

Terminal error detection and auto-fix assistant. Runs silently alongside your shell, detects errors in command output, queries AI for a fix, and applies it if you confirm.

Works on Windows, macOS, and Linux.

---

## Install

### Python

```
pip install gocli-terminal
```

### Go — macOS / Linux

```
curl -fsSL https://raw.githubusercontent.com/nopedal/gocli-install/main/install.sh | sh
```

### Go — Windows (PowerShell)

```powershell
irm https://raw.githubusercontent.com/nopedal/gocli-install/main/install.ps1 | iex
```

No Go installation required for the Go version. The scripts download a pre-built binary for your platform.

---

## Configure

Set your Gemini API key:

```
# macOS / Linux
export GOCLI_API_KEY="your-api-key"

# Windows (cmd)
set GOCLI_API_KEY=your-api-key

# Windows (PowerShell)
$env:GOCLI_API_KEY = "your-api-key"
```

A default key is bundled for testing. Replace it with your own for production use. Get one free at https://aistudio.google.com/apikey

---

## Use

```
gocli
```

Use it like a normal terminal. When a command fails and an error pattern is recognised, goCLI queries the AI and shows:

```
  goCLI  detected an error
         fix  pip install requests
         run? [Y/n]
```

Press Enter or Y to apply the fix. N to skip. Type `exit` to leave.

---

## Auto-start

To launch goCLI automatically on every new terminal session:

**macOS / Linux** — add to `.bashrc` or `.zshrc`:

```bash
if command -v gocli &> /dev/null && [ -z "$GOCLI_ACTIVE" ]; then
    export GOCLI_ACTIVE=1
    exec gocli
fi
```

**Windows** — add to your PowerShell profile (`$PROFILE`):

```powershell
if ((Get-Command gocli -ErrorAction SilentlyContinue) -and -not $env:GOCLI_ACTIVE) {
    $env:GOCLI_ACTIVE = "1"
    gocli
    exit
}
```

---

## Error detection

Recognises out of the box:

- Python missing module / import / traceback errors
- Node.js missing package errors
- Permission denied errors
- Command not found (including Windows "not recognized" errors)
- Port already in use
- Docker errors
- Git errors
- Rust compiler errors

## License

MIT
