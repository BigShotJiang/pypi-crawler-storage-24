"""GUI adapters"""
