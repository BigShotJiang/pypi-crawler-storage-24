"""GUI server"""
