"""HTTP reporter for sending posture data to the API."""

import asyncio
import logging
from pathlib import Path

import httpx
import yaml

from posture_agent.core.config import Settings
from posture_agent.models.report import PostureReportPayload
from posture_agent.services.fingerprint import get_machine_fingerprint

logger = logging.getLogger(__name__)

UNINSTALL_TIMEOUT = 5  # seconds — short to avoid hanging the uninstall


async def send_report(payload: PostureReportPayload, settings: Settings) -> dict:
    """Send posture report to the API with retry."""
    url = f"{settings.api.url.rstrip('/')}/api/v1/core/posture/reports"

    last_error: Exception | None = None
    for attempt in range(settings.api.retries):
        try:
            headers = {}
            if settings.api.api_key:
                if settings.api.api_key.startswith("hsk_"):
                    headers["X-API-Key"] = settings.api.api_key
                else:
                    logger.warning(
                        "API key does not start with 'hsk_'. "
                        "Sending request without authentication."
                    )

            data = payload.model_dump(mode="json")
            # Only include tenant_id when NOT using an hsk_ API key
            # (API resolves tenant from the key server-side)
            if settings.api.tenant_id and not (
                settings.api.api_key and settings.api.api_key.startswith("hsk_")
            ):
                data["tenant_id"] = settings.api.tenant_id

            async with httpx.AsyncClient(timeout=settings.api.timeout) as client:
                response = await client.post(
                    url,
                    json=data,
                    headers=headers,
                )
                response.raise_for_status()
                return response.json()
        except (httpx.HTTPError, httpx.TimeoutException) as e:
            last_error = e
            if attempt < settings.api.retries - 1:
                import asyncio
                await asyncio.sleep(2 ** attempt)

    raise RuntimeError(f"Failed to send report after {settings.api.retries} attempts: {last_error}")


def report_uninstall() -> None:
    """Best-effort HTTP call to notify the API that the agent is being uninstalled.

    Reads the saved config to get the API URL and API key, generates the
    machine fingerprint, and POSTs to the uninstall endpoint. This function
    catches ALL exceptions so it never prevents the uninstall from proceeding.
    """
    try:
        # 1. Read saved config
        config_path = Path.home() / ".config" / "intercept" / "agent.yaml"
        if not config_path.exists():
            logger.warning("No config file found at %s — skipping uninstall report.", config_path)
            return

        config_data = yaml.safe_load(config_path.read_text()) or {}
        api_config = config_data.get("api", {})
        api_url = api_config.get("url", "")
        api_key = api_config.get("api_key", "")

        if not api_url:
            logger.warning("No API URL in config — skipping uninstall report.")
            return

        if not api_key or not api_key.startswith("hsk_"):
            logger.warning("No valid API key in config — skipping uninstall report.")
            return

        # 2. Generate machine fingerprint (async, but we run it synchronously)
        fingerprint = asyncio.run(get_machine_fingerprint())

        # 3. POST to the uninstall endpoint
        url = f"{api_url.rstrip('/')}/api/v1/core/posture/uninstall"
        headers = {"X-API-Key": api_key}
        body = {"machine_fingerprint": fingerprint}

        with httpx.Client(timeout=UNINSTALL_TIMEOUT) as client:
            resp = client.post(url, json=body, headers=headers)

        if resp.status_code == 204:
            logger.info("Uninstall reported successfully.")
        else:
            logger.warning("Uninstall report returned HTTP %s.", resp.status_code)

    except Exception:
        logger.warning("Failed to report uninstall (best-effort).", exc_info=True)
