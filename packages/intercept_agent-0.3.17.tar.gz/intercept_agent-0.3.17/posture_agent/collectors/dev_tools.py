"""Developer tools collector."""

import os

from posture_agent.collectors.base import BaseCollector, CollectorResult
from posture_agent.utils.shell import check_version, run_command


# Tool definitions: (name, binary, version_flag)
DEV_TOOL_DEFINITIONS = [
    # Core languages & runtimes
    ("Git", "git", "--version"),
    ("Docker", "docker", "--version"),
    ("Node.js", "node", "--version"),
    ("Python", "python3", "--version"),
    ("Go", "go", "version"),
    ("Rust", "rustc", "--version"),
    ("Ruby", "ruby", "--version"),
    ("Java", "java", "--version"),
    ("Swift", "swift", "--version"),
    ("Deno", "deno", "--version"),
    ("Bun", "bun", "--version"),
    ("Zig", "zig", "version"),
    ("Elixir", "elixir", "--version"),
    (".NET SDK", "dotnet", "--version"),
    # Build tools
    ("Make", "make", "--version"),
    ("CMake", "cmake", "--version"),
    ("Bazel", "bazel", "--version"),
    ("Gradle", "gradle", "--version"),
    ("Ant", "ant", "-version"),
    ("sbt", "sbt", "--version"),
    # Security scanners
    ("Trivy", "trivy", "--version"),
    ("Snyk", "snyk", "--version"),
    ("Grype", "grype", "version"),
    ("Checkov", "checkov", "--version"),
    ("tfsec", "tfsec", "--version"),
    ("Hadolint", "hadolint", "--version"),
    ("Cosign", "cosign", "version"),
    ("Syft", "syft", "version"),
    ("Semgrep", "semgrep", "--version"),
    ("Bandit", "bandit", "--version"),
    ("Gitleaks", "gitleaks", "version"),
    ("TruffleHog", "trufflehog", "--version"),
    ("detect-secrets", "detect-secrets", "--version"),
    ("Safety", "safety", "--version"),
    # Container & orchestration
    ("Podman", "podman", "--version"),
    ("kind", "kind", "--version"),
    ("Minikube", "minikube", "version"),
    ("k3s", "k3s", "--version"),
    ("k9s", "k9s", "version"),
    ("Skaffold", "skaffold", "version"),
    ("Tilt", "tilt", "version"),
    # Cloud & infrastructure
    ("Terraform", "terraform", "--version"),
    ("kubectl", "kubectl", "version --client"),
    ("Helm", "helm", "version --short"),
    ("AWS CLI", "aws", "--version"),
    ("gcloud", "gcloud", "--version"),
    ("Azure CLI", "az", "--version"),
    ("Pulumi", "pulumi", "version"),
    ("AWS CDK", "cdk", "--version"),
    ("AWS SAM CLI", "sam", "--version"),
    ("Serverless", "serverless", "--version"),
    ("Fly.io CLI", "flyctl", "version"),
    ("Railway CLI", "railway", "--version"),
]

# Tools known to be slow to start; use a longer timeout
_SLOW_TOOLS = {"sbt", "gradle"}


class DevToolsCollector(BaseCollector):
    """Collects installed developer tools."""

    name = "dev_tools"

    async def collect(self) -> CollectorResult:
        errors: list[str] = []
        tools: list[dict[str, str]] = []

        for name, binary, version_flag in DEV_TOOL_DEFINITIONS:
            try:
                which_result = await run_command("which", binary)
                if which_result and which_result.strip():
                    # Use a longer timeout for tools known to be slow
                    timeout = 30.0 if binary in _SLOW_TOOLS else 10.0
                    version = (
                        await check_version(binary, version_flag, timeout=timeout)
                        or ""
                    )
                    path = os.path.realpath(which_result.strip())
                    tools.append({
                        "name": name,
                        "binary": binary,
                        "version": version,
                        "path": path,
                    })
            except Exception as e:
                errors.append(f"{name}: {e}")

        return CollectorResult(
            collector=self.name,
            data=tools,
            errors=errors,
        )
