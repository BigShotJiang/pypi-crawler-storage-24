"""Tests for machine fingerprint with mocked ioreg commands."""

import asyncio
import hashlib
from unittest.mock import patch

from posture_agent.services.fingerprint import get_machine_fingerprint


class TestFingerprintPrimary:
    """Test the primary IOPlatformUUID path."""

    def test_ioreg_uuid_extracted(self):
        ioreg_output = (
            '+-o IOPlatformExpertDevice  <class IOPlatformExpertDevice>\n'
            '  {\n'
            '    "IOPlatformUUID" = "ABCD-1234-EFGH-5678"\n'
            '  }\n'
        )

        async def mock_run(*args, **kwargs):
            if args[0] == "ioreg" and args[1] == "-rd1":
                return ioreg_output
            return None

        with patch("posture_agent.services.fingerprint.run_command", side_effect=mock_run):
            fp = asyncio.run(get_machine_fingerprint())

        expected = hashlib.sha256("ABCD-1234-EFGH-5678".encode()).hexdigest()[:32]
        assert fp == expected
        assert len(fp) == 32


class TestFingerprintSerialFallback:
    """Test the serial number fallback path."""

    def test_serial_number_fallback(self):
        serial_output = (
            '  {\n'
            '    "IOPlatformSerialNumber" = "C02XYZ123456"\n'
            '  }\n'
        )

        async def mock_run(*args, **kwargs):
            if args[0] == "ioreg" and args[1] == "-rd1":
                return None  # UUID lookup fails
            if args[0] == "ioreg" and args[1] == "-l":
                return serial_output
            return None

        with patch("posture_agent.services.fingerprint.run_command", side_effect=mock_run):
            fp = asyncio.run(get_machine_fingerprint())

        expected = hashlib.sha256("C02XYZ123456".encode()).hexdigest()[:32]
        assert fp == expected
        assert len(fp) == 32


class TestFingerprintHostnameFallback:
    """Test the hostname-based last resort fallback."""

    def test_hostname_fallback(self):
        async def mock_run(*args, **kwargs):
            return None  # All ioreg commands fail

        with patch("posture_agent.services.fingerprint.run_command", side_effect=mock_run), \
             patch("platform.node", return_value="test-machine"), \
             patch("platform.machine", return_value="arm64"):
            fp = asyncio.run(get_machine_fingerprint())

        expected = hashlib.sha256("test-machine-arm64".encode()).hexdigest()[:32]
        assert fp == expected
        assert len(fp) == 32

    def test_hostname_fallback_different_arch(self):
        async def mock_run(*args, **kwargs):
            return None

        with patch("posture_agent.services.fingerprint.run_command", side_effect=mock_run), \
             patch("platform.node", return_value="dev-laptop"), \
             patch("platform.machine", return_value="x86_64"):
            fp = asyncio.run(get_machine_fingerprint())

        expected = hashlib.sha256("dev-laptop-x86_64".encode()).hexdigest()[:32]
        assert fp == expected


class TestFingerprintUUIDNotFound:
    """Test when ioreg returns output but UUID is not in the expected position."""

    def test_uuid_line_without_proper_quotes(self):
        """ioreg output has IOPlatformUUID but not parseable."""
        ioreg_output = (
            '  "IOPlatformUUID" = missing-quotes\n'
        )

        async def mock_run(*args, **kwargs):
            if args[0] == "ioreg" and args[1] == "-rd1":
                return ioreg_output
            if args[0] == "ioreg" and args[1] == "-l":
                return None
            return None

        with patch("posture_agent.services.fingerprint.run_command", side_effect=mock_run), \
             patch("platform.node", return_value="fallback-host"), \
             patch("platform.machine", return_value="arm64"):
            fp = asyncio.run(get_machine_fingerprint())

        # Should fall through to hostname fallback since UUID parse fails
        assert len(fp) == 32
