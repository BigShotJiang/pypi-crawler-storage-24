"""Tests for config env overrides, agent_version, and logging setup."""

import logging
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from posture_agent.core.config import Settings
from posture_agent.core.logging import setup_agent_logging
from posture_agent.main import _get_os_version, _pip_user_bin_candidates


class TestSettingsEnvOverrides:
    """Test environment variable overrides for Settings."""

    def test_intercept_api_url_override(self):
        with patch.dict(os.environ, {"INTERCEPT_API_URL": "https://custom.example.com"}):
            settings = Settings()
        assert settings.api.url == "https://custom.example.com"

    def test_intercept_api_key_override(self):
        with patch.dict(os.environ, {"INTERCEPT_API_KEY": "hsk_test_override"}):
            settings = Settings()
        assert settings.api.api_key == "hsk_test_override"

    def test_intercept_tenant_id_override(self):
        with patch.dict(os.environ, {"INTERCEPT_TENANT_ID": "tenant-override-123"}):
            settings = Settings()
        assert settings.api.tenant_id == "tenant-override-123"

    def test_all_overrides_together(self):
        env = {
            "INTERCEPT_API_URL": "https://all.example.com",
            "INTERCEPT_API_KEY": "hsk_all_key",
            "INTERCEPT_TENANT_ID": "tenant-all",
        }
        with patch.dict(os.environ, env):
            settings = Settings()
        assert settings.api.url == "https://all.example.com"
        assert settings.api.api_key == "hsk_all_key"
        assert settings.api.tenant_id == "tenant-all"


class TestSettingsAgentVersion:
    """Test agent_version property."""

    def test_version_from_file(self):
        settings = Settings()
        version = settings.agent_version
        # Should return something version-like
        assert version
        parts = version.split(".")
        assert len(parts) >= 2  # At minimum major.minor


class TestLoggingSetup:
    """Test logging setup function."""

    def test_default_text_format(self):
        setup_agent_logging()
        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO

    def test_debug_level(self):
        setup_agent_logging({"level": "DEBUG"})
        root_logger = logging.getLogger()
        assert root_logger.level == logging.DEBUG

    def test_json_format(self):
        setup_agent_logging({"level": "INFO", "console": {"format": "json"}})
        root_logger = logging.getLogger()
        # Check that a handler exists with JSON format
        handler = root_logger.handlers[-1]
        assert "timestamp" in handler.formatter._fmt

    def test_none_config(self):
        setup_agent_logging(None)
        root_logger = logging.getLogger()
        assert root_logger.level == logging.INFO


class TestGetOsVersion:
    """Test _get_os_version helper."""

    def test_darwin_returns_mac_ver(self):
        with patch("platform.system", return_value="Darwin"), \
             patch("platform.mac_ver", return_value=("15.2", ("", "", ""), "")):
            assert _get_os_version() == "15.2"

    def test_darwin_empty_mac_ver_falls_back(self):
        with patch("platform.system", return_value="Darwin"), \
             patch("platform.mac_ver", return_value=("", ("", "", ""), "")), \
             patch("platform.release", return_value="24.0.0"):
            assert _get_os_version() == "24.0.0"

    def test_linux_returns_release(self):
        with patch("platform.system", return_value="Linux"), \
             patch("platform.release", return_value="6.1.0"):
            assert _get_os_version() == "6.1.0"


class TestPipUserBinCandidates:
    """Test _pip_user_bin_candidates helper."""

    def test_darwin_includes_library_python(self, tmp_path):
        lib_python = tmp_path / "Library" / "Python" / "3.12"
        lib_python.mkdir(parents=True)

        with patch("platform.system", return_value="Darwin"), \
             patch("pathlib.Path.home", return_value=tmp_path):
            candidates = _pip_user_bin_candidates()

        # Should include macOS Library/Python path and .local/bin
        paths_str = [str(c) for c in candidates]
        assert any("Library/Python/3.12/bin" in p for p in paths_str)
        assert any(".local/bin" in p for p in paths_str)

    def test_darwin_no_library_python(self, tmp_path):
        # No Library/Python dir exists
        with patch("platform.system", return_value="Darwin"), \
             patch("pathlib.Path.home", return_value=tmp_path):
            candidates = _pip_user_bin_candidates()

        paths_str = [str(c) for c in candidates]
        # Should still have .local/bin fallback
        assert any(".local/bin" in p for p in paths_str)

    def test_linux_only_local_bin(self, tmp_path):
        with patch("platform.system", return_value="Linux"), \
             patch("pathlib.Path.home", return_value=tmp_path):
            candidates = _pip_user_bin_candidates()

        paths_str = [str(c) for c in candidates]
        assert any(".local/bin" in p for p in paths_str)
