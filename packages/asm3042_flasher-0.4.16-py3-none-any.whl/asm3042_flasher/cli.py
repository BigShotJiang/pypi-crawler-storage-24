from __future__ import annotations

import argparse
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import tempfile
import time

from . import __version__
from .device import (
    AsmediaXhciController,
    DeviceCompatibilityError,
    DeviceInfo,
    DeviceNotFoundError,
    FlasherError,
    ROM_FW_VERSION,
    discover_devices,
    ensure_protocol_supported,
    format_fw_version,
    normalize_bdf,
    pick_device,
)
from .firmware import (
    CFG_RECORD_ADDRESSES,
    FirmwareImage,
    parse_mptool_ini,
    validate_permanent_image,
    validate_windows_ini_profile,
)
from .flashrom_backend import FlashromConfig, default_backup_path, read_flash, write_flash
from .internal_flash import (
    extract_permanent_firmware,
    probe_internal_spi_rom,
    read_internal_flash,
    restore_internal_flash,
    write_internal_flash,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="asm3042-fw",
        description="ASMedia xHCI firmware utility for Linux",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    subparsers.add_parser("discover", help="list ASMedia xHCI devices found in sysfs")

    inspect_parser = subparsers.add_parser("inspect", help="inspect a firmware image")
    inspect_parser.add_argument("firmware", help="path to the firmware .bin file")

    version_parser = subparsers.add_parser(
        "version", help="read the current firmware version from the controller"
    )
    version_parser.add_argument("--bdf", help="PCI BDF like 0000:03:00.0")
    version_parser.add_argument(
        "--force-device",
        action="store_true",
        help="allow using a device outside the known-safe allowlist",
    )

    upload_parser = subparsers.add_parser(
        "upload", help="upload a firmware image into controller SRAM"
    )
    upload_parser.add_argument("firmware", help="path to the firmware .bin file")
    upload_parser.add_argument("--bdf", help="PCI BDF like 0000:03:00.0")
    upload_parser.add_argument(
        "--force-device",
        action="store_true",
        help="allow using a device outside the known-safe allowlist",
    )
    upload_parser.add_argument(
        "--force-running-firmware",
        action="store_true",
        help="allow upload even if the controller already reports non-ROM firmware",
    )
    upload_parser.add_argument(
        "--keep-driver-bound",
        action="store_true",
        help="skip the default unbind/rebind cycle around the upload",
    )

    permanent_read_internal_parser = subparsers.add_parser(
        "permanent-read-internal",
        help="read the onboard SPI flash through the ASMedia internal PCIe protocol",
    )
    permanent_read_internal_parser.add_argument("output", help="path to the output backup file")
    permanent_read_internal_parser.add_argument("--bdf", help="PCI BDF like 0000:03:00.0")
    permanent_read_internal_parser.add_argument(
        "--force-device",
        action="store_true",
        help="allow using a device outside the known-safe allowlist",
    )
    permanent_read_internal_parser.add_argument(
        "--keep-driver-bound",
        action="store_true",
        help="skip the default unbind/rebind cycle around the flash access",
    )
    permanent_read_internal_parser.add_argument(
        "--size",
        type=lambda value: int(value, 0),
        help="optional byte count to read; defaults to the detected full SPI ROM size",
    )

    permanent_write_internal_parser = subparsers.add_parser(
        "permanent-write-internal",
        help="permanently write the onboard SPI flash through the ASMedia internal PCIe protocol",
    )
    permanent_write_internal_parser.add_argument("firmware", help="path to the firmware .bin file")
    permanent_write_internal_parser.add_argument(
        "--ini",
        help="optional ASMTxHCIMPTool.ini path; applies Windows-style subsystem/config overrides",
    )
    permanent_write_internal_parser.add_argument(
        "--unsafe-allow-ini-overrides",
        action="store_true",
        help="allow the experimental internal CREATE_ROM override path; only use this with a verified external SPI recovery path",
    )
    permanent_write_internal_parser.add_argument("--bdf", help="PCI BDF like 0000:03:00.0")
    permanent_write_internal_parser.add_argument(
        "--force-device",
        action="store_true",
        help="allow using a device outside the known-safe allowlist",
    )
    permanent_write_internal_parser.add_argument(
        "--keep-driver-bound",
        action="store_true",
        help="skip the default unbind/rebind cycle around the flash access",
    )
    permanent_write_internal_parser.add_argument(
        "--backup-file",
        help="where to save the mandatory SPI flash backup before writing; defaults to the current working directory",
    )
    permanent_write_internal_parser.add_argument(
        "--overwrite-backup",
        action="store_true",
        help="allow overwriting an existing backup file",
    )
    permanent_write_internal_parser.add_argument(
        "--no-verify",
        action="store_true",
        help="skip the post-write readback verification",
    )
    permanent_write_internal_parser.add_argument(
        "--plan",
        action="store_true",
        help="run all preflight checks, save the safety backup, and stop before writing SPI flash",
    )
    permanent_write_internal_parser.add_argument(
        "--require-primary-device-id",
        type=lambda value: int(value, 0),
        help="abort unless the predicted post-flash primary PCI device id matches this value",
    )
    permanent_write_internal_parser.add_argument(
        "--require-subsystem-device-id",
        type=lambda value: int(value, 0),
        help="abort unless the predicted post-flash subsystem device id matches this value",
    )
    permanent_write_internal_parser.add_argument(
        "--require-subsystem-vendor-id",
        type=lambda value: int(value, 0),
        help="abort unless the predicted post-flash subsystem vendor id matches this value",
    )

    crossflash_internal_parser = subparsers.add_parser(
        "crossflash-internal",
        help="simplified high-level internal crossflash flow: uses ASMTxHCIMPTool.ini, derives expected target IDs, and saves a verified backup automatically",
    )
    crossflash_internal_parser.add_argument("firmware", help="path to the firmware .bin file")
    crossflash_internal_parser.add_argument(
        "--ini",
        required=True,
        help="path to ASMTxHCIMPTool.ini with Windows-style overrides",
    )
    crossflash_internal_parser.add_argument("--bdf", help="PCI BDF like 0000:03:00.0")
    crossflash_internal_parser.add_argument(
        "--force-device",
        action="store_true",
        help="allow using a device outside the known-safe allowlist",
    )
    crossflash_internal_parser.add_argument(
        "--backup-file",
        help="where to save the mandatory SPI flash backup before writing; defaults to the current working directory",
    )
    crossflash_internal_parser.add_argument(
        "--overwrite-backup",
        action="store_true",
        help="allow overwriting an existing backup file",
    )
    crossflash_internal_parser.add_argument(
        "--no-verify",
        action="store_true",
        help="skip the post-write readback verification",
    )
    crossflash_internal_parser.add_argument(
        "--plan",
        action="store_true",
        help="run all preflight checks, save the safety backup, and stop before writing SPI flash",
    )
    crossflash_internal_parser.add_argument(
        "--apply",
        action="store_true",
        help="actually write SPI flash; without this flag crossflash-internal runs in safe plan-only mode",
    )

    permanent_restore_internal_parser = subparsers.add_parser(
        "permanent-restore-internal",
        help="restore the onboard SPI flash from a previously saved backup image",
    )
    permanent_restore_internal_parser.add_argument("backup", help="path to the backup .bin file")
    permanent_restore_internal_parser.add_argument("--bdf", help="PCI BDF like 0000:03:00.0")
    permanent_restore_internal_parser.add_argument(
        "--force-device",
        action="store_true",
        help="allow using a device outside the known-safe allowlist",
    )
    permanent_restore_internal_parser.add_argument(
        "--keep-driver-bound",
        action="store_true",
        help="skip the default unbind/rebind cycle around the flash access",
    )
    permanent_restore_internal_parser.add_argument(
        "--no-verify",
        action="store_true",
        help="skip the post-restore readback verification",
    )

    permanent_read_parser = subparsers.add_parser(
        "permanent-read",
        help="read the external SPI flash with flashrom and save a backup image",
    )
    permanent_read_parser.add_argument("output", help="path to the output backup file")
    permanent_read_parser.add_argument(
        "--programmer",
        required=True,
        help="flashrom programmer string, for example ch341a_spi or serprog:dev=/dev/ttyACM0",
    )
    permanent_read_parser.add_argument(
        "--chip",
        help="optional flash chip name passed to flashrom with -c",
    )
    permanent_read_parser.add_argument(
        "--flashrom-bin",
        default="flashrom",
        help="path to the flashrom executable",
    )

    permanent_write_parser = subparsers.add_parser(
        "permanent-write",
        help="write the external SPI flash permanently using flashrom and an external programmer",
    )
    permanent_write_parser.add_argument("firmware", help="path to the firmware .bin file")
    permanent_write_parser.add_argument(
        "--programmer",
        required=True,
        help="flashrom programmer string, for example ch341a_spi or serprog:dev=/dev/ttyACM0",
    )
    permanent_write_parser.add_argument(
        "--chip",
        help="optional flash chip name passed to flashrom with -c",
    )
    permanent_write_parser.add_argument(
        "--flashrom-bin",
        default="flashrom",
        help="path to the flashrom executable",
    )
    permanent_write_parser.add_argument(
        "--backup-file",
        help="where to save a mandatory SPI flash backup before writing; defaults to the current working directory",
    )
    permanent_write_parser.add_argument(
        "--skip-backup",
        action="store_true",
        help="deprecated compatibility flag; external writes now always require a pre-write backup",
    )
    permanent_write_parser.add_argument(
        "--overwrite-backup",
        action="store_true",
        help="allow overwriting an existing backup file",
    )
    permanent_write_parser.add_argument(
        "--no-verify",
        action="store_true",
        help="pass -n to flashrom and skip post-write verification",
    )

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        if args.command == "discover":
            return _cmd_discover()
        if args.command == "inspect":
            return _cmd_inspect(args.firmware)
        if args.command == "version":
            _require_root(args.command)
            return _cmd_version(args.bdf, force_device=args.force_device)
        if args.command == "upload":
            _require_root(args.command)
            return _cmd_upload(
                args.firmware,
                bdf=args.bdf,
                force_device=args.force_device,
                force_running_firmware=args.force_running_firmware,
                keep_driver_bound=args.keep_driver_bound,
            )
        if args.command == "permanent-read-internal":
            _require_root(args.command)
            return _cmd_permanent_read_internal(
                args.output,
                bdf=args.bdf,
                force_device=args.force_device,
                keep_driver_bound=args.keep_driver_bound,
                size=args.size,
            )
        if args.command == "permanent-write-internal":
            _require_root(args.command)
            return _cmd_permanent_write_internal(
                args.firmware,
                ini_path=args.ini,
                bdf=args.bdf,
                force_device=args.force_device,
                keep_driver_bound=args.keep_driver_bound,
                allow_unsafe_ini_overrides=args.unsafe_allow_ini_overrides,
                backup_file=args.backup_file,
                skip_backup=False,
                overwrite_backup=args.overwrite_backup,
                verify=not args.no_verify,
                plan_only=args.plan,
                require_primary_device_id=args.require_primary_device_id,
                require_subsystem_device_id=args.require_subsystem_device_id,
                require_subsystem_vendor_id=args.require_subsystem_vendor_id,
            )
        if args.command == "crossflash-internal":
            _require_root(args.command)
            return _cmd_crossflash_internal(
                args.firmware,
                ini_path=args.ini,
                bdf=args.bdf,
                force_device=args.force_device,
                backup_file=args.backup_file,
                overwrite_backup=args.overwrite_backup,
                verify=not args.no_verify,
                plan_only=args.plan,
                apply=args.apply,
            )
        if args.command == "permanent-restore-internal":
            _require_root(args.command)
            return _cmd_permanent_restore_internal(
                args.backup,
                bdf=args.bdf,
                force_device=args.force_device,
                keep_driver_bound=args.keep_driver_bound,
                verify=not args.no_verify,
            )
        if args.command == "permanent-read":
            return _cmd_permanent_read(
                args.output,
                programmer=args.programmer,
                chip=args.chip,
                flashrom_bin=args.flashrom_bin,
            )
        if args.command == "permanent-write":
            return _cmd_permanent_write(
                args.firmware,
                programmer=args.programmer,
                chip=args.chip,
                flashrom_bin=args.flashrom_bin,
                backup_file=args.backup_file,
                skip_backup=args.skip_backup,
                overwrite_backup=args.overwrite_backup,
                verify=not args.no_verify,
            )
    except (DeviceNotFoundError, DeviceCompatibilityError, FlasherError, TimeoutError, ValueError) as exc:
        _append_active_operation_log(f"event=error type={type(exc).__name__} message={exc}")
        print(f"error: {exc}", file=sys.stderr)
        return 1

    parser.error(f"unsupported command: {args.command}")
    return 2


def _cmd_discover() -> int:
    devices = discover_devices()
    if not devices:
        print("No ASMedia xHCI devices found.")
        return 1

    for device in devices:
        known = "yes" if device.protocol_supported else "no"
        driver = device.driver or "-"
        subsystem = _format_optional_id_pair(
            device.subsystem_vendor_id,
            device.subsystem_device_id,
        )
        print(
            f"{device.bdf}  vendor=0x{device.vendor_id:04x}  device=0x{device.device_id:04x}  "
            f"class=0x{device.class_code:06x}  subsystem={subsystem}  "
            f"driver={driver}  known-protocol={known}"
        )
    return 0


def _cmd_inspect(firmware_path: str) -> int:
    image = FirmwareImage.from_path(firmware_path)
    print(f"source: {image.source}")
    print(f"size: {image.size} bytes ({image.word_count} words)")
    print(f"family-tag: {image.family_tag or '-'}")
    print(f"header-tags: {', '.join(image.header_tags) if image.header_tags else '-'}")
    try:
        permanent_image = extract_permanent_firmware(image)
    except ValueError:
        pass
    else:
        print(f"permanent-raw-size: {permanent_image.raw_size} bytes")
        if hasattr(permanent_image, "rom_size"):
            print(f"permanent-rom-size: {permanent_image.rom_size} bytes")
    return 0


def _cmd_version(bdf: str | None, *, force_device: bool) -> int:
    info = pick_device(bdf)
    ensure_protocol_supported(info, force=force_device)

    with AsmediaXhciController(info) as controller:
        version = controller.get_firmware_version()

    print(_format_device_line(info))
    print(f"firmware-version: {format_fw_version(version)}")
    print(f"is-rom-firmware: {'yes' if version == ROM_FW_VERSION else 'no'}")
    return 0


def _cmd_upload(
    firmware_path: str,
    *,
    bdf: str | None,
    force_device: bool,
    force_running_firmware: bool,
    keep_driver_bound: bool,
) -> int:
    image = FirmwareImage.from_path(firmware_path)
    info = pick_device(bdf)
    ensure_protocol_supported(info, force=force_device)

    print(_format_device_line(info))
    print(f"firmware-image: {image.source}")
    print(f"firmware-size: {image.size} bytes")
    if image.header_tags:
        print(f"firmware-tags: {', '.join(image.header_tags)}")

    controller = AsmediaXhciController(info)
    with controller.temporarily_unbound(enabled=not keep_driver_bound):
        with controller:
            before = controller.get_firmware_version()
            print(f"firmware-before: {format_fw_version(before)}")
            if before != ROM_FW_VERSION and not force_running_firmware:
                raise FlasherError(
                    "controller already reports non-ROM firmware; pass "
                    "--force-running-firmware to overwrite the running image"
                )

            controller.upload_firmware(image)
            after = controller.get_firmware_version()

    print(f"firmware-after: {format_fw_version(after)}")
    print("status: uploaded-to-sram")
    return 0


def _cmd_permanent_read(
    output_path: str,
    *,
    programmer: str,
    chip: str | None,
    flashrom_bin: str,
) -> int:
    output = Path(output_path)
    config = FlashromConfig(programmer=programmer, flashrom_bin=flashrom_bin, chip=chip)
    with _operation_log_context("permanent-read", output) as logger:
        emit = lambda message: _emit(message, logger=logger)
        emit(f"mode: permanent-read")
        emit(f"log-file: {logger.path}")
        emit(f"programmer: {programmer}")
        if chip:
            emit(f"chip: {chip}")
        emit(f"output: {output}")

        read_flash(output, config=config)
        backup_data, backup_digest = _verify_existing_file(output, label="external flash backup")
        emit(f"backup-sha256: {backup_digest}")
        manifest_path = _manifest_path_for_backup(output)
        _write_external_backup_manifest(
            manifest_path,
            config=config,
            backup_path=output,
            backup_sha256=backup_digest,
            mode="external-read",
            bytes_written=len(backup_data),
        )
        emit(f"manifest-file: {manifest_path}")
        emit("status: backup-complete")
        return 0


def _cmd_permanent_read_internal(
    output_path: str,
    *,
    bdf: str | None,
    force_device: bool,
    keep_driver_bound: bool,
    size: int | None,
) -> int:
    info = _prepare_internal_device(pick_device(bdf))
    ensure_protocol_supported(info, force=force_device)
    output = Path(output_path)
    with _operation_log_context("permanent-read-internal", output) as logger:
        emit = lambda message: _emit(message, logger=logger)
        emit("mode: permanent-read-internal")
        emit(f"log-file: {logger.path}")
        emit(_format_device_line(info))

        controller = AsmediaXhciController(info)
        with controller.temporarily_unbound(enabled=False):
            with controller:
                rom, data = read_internal_flash(controller, size=size)

        _print_running_version("firmware-running", None, logger=logger)
        emit(_format_spi_rom_line(rom))
        emit(f"output: {output}")
        emit(f"bytes-read: {len(data)}")
        backup_digest = _write_verified_backup(output, data, label="internal flash backup")
        emit(f"backup-sha256: {backup_digest}")
        manifest_path = _manifest_path_for_backup(output)
        _write_backup_manifest(
            manifest_path,
            info=info,
            rom=rom,
            backup_path=output,
            backup_sha256=backup_digest,
            mode="internal-read",
            bytes_written=len(data),
        )
        emit(f"manifest-file: {manifest_path}")
        emit("status: internal-backup-complete")
        return 0


def _cmd_permanent_write_internal(
    firmware_path: str,
    *,
    ini_path: str | None = None,
    bdf: str | None,
    force_device: bool,
    keep_driver_bound: bool,
    allow_unsafe_ini_overrides: bool,
    backup_file: str | None,
    skip_backup: bool,
    overwrite_backup: bool,
    verify: bool,
    plan_only: bool = False,
    require_primary_device_id: int | None = None,
    require_subsystem_device_id: int | None = None,
    require_subsystem_vendor_id: int | None = None,
    command_name: str = "permanent-write-internal",
) -> int:
    image = FirmwareImage.from_path(firmware_path)
    firmware = Path(firmware_path)
    ini_config = parse_mptool_ini(ini_path) if ini_path else None

    if ini_config is not None and not allow_unsafe_ini_overrides:
        raise FlasherError(
            "internal SPI writes with --ini are blocked by default: this experimental CREATE_ROM "
            "override path has already produced non-bootable SPI images on ASM3142-class hardware; "
            "use an external programmer or pass --unsafe-allow-ini-overrides only if you have a "
            "verified SPI recovery path"
        )
    if skip_backup:
        raise FlasherError(
            "internal SPI writes now require a saved backup file; --skip-backup is disabled to keep "
            "the write path fail-closed"
        )
    if ini_config is None and any(
        value is not None
        for value in (
            require_primary_device_id,
            require_subsystem_device_id,
            require_subsystem_vendor_id,
        )
    ):
        raise FlasherError(
            "identity requirement flags currently require --ini, because the raw firmware-image path "
            "does not model post-flash PCI identity yet"
        )
    if ini_config is not None and require_primary_device_id is not None:
        raise FlasherError(
            "internal primary PCI device-id remap is intentionally disabled until it is validated "
            "against the real Windows MPTool behavior on hardware; use only subsystem SVID/SSID "
            "overrides in the internal path"
        )

    info = _prepare_internal_device(pick_device(bdf))
    ensure_protocol_supported(info, force=force_device)

    if ini_config is None:
        permanent_image = extract_permanent_firmware(image)
        config_source_label = "firmware-image"
    else:
        preview_image = extract_permanent_firmware(image)
        config_records = ini_config.build_records(device_type=preview_image.device_type)
        permanent_image = None
        config_source_label = "current-spi-backup"

    with _operation_log_context(command_name, firmware) as logger:
        emit = lambda message: _emit(message, logger=logger)
        emit(f"mode: {command_name}")
        emit(f"log-file: {logger.path}")
        emit(_format_device_line(info))
        emit(f"firmware-image: {image.source}")
        if ini_config is not None:
            emit(f"mptool-ini: {ini_config.source}")
            emit(
                "override-scope: "
                f"{ini_config.override_scope} "
                "(Windows-validated SVID/SSID/PCIe speed only)"
            )
            emit(f"rom-config-source: {config_source_label}")
        emit(f"firmware-size: {image.size} bytes")
        if image.header_tags:
            emit(f"firmware-tags: {', '.join(image.header_tags)}")
        if permanent_image is not None:
            emit(f"firmware-family: {permanent_image.family_tag}")
            emit(f"firmware-raw-size: {permanent_image.raw_size} bytes")
            if hasattr(permanent_image, "rom_size"):
                emit(f"firmware-rom-size: {permanent_image.rom_size} bytes")
            emit(f"config-records: {len(getattr(permanent_image, 'config_records', ()))}")

        controller = AsmediaXhciController(info)
        with controller.temporarily_unbound(enabled=False):
            with controller:
                _print_running_version("firmware-running-before", None, logger=logger)

                backup_path = Path(backup_file) if backup_file else default_backup_path(firmware)
                if backup_path.exists() and not overwrite_backup:
                    raise FlasherError(
                        f"backup file already exists: {backup_path}; pass --overwrite-backup or choose --backup-file"
                    )
                rom, backup_data = read_internal_flash(controller)
                emit(_format_spi_rom_line(rom))
                emit(f"backup-file: {backup_path}")
                emit(f"backup-size: {len(backup_data)} bytes")
                backup_digest = _write_verified_backup(
                    backup_path,
                    backup_data,
                    label="internal flash backup",
                )
                emit(f"backup-sha256: {backup_digest}")
                manifest_path = _manifest_path_for_backup(backup_path)
                _write_backup_manifest(
                    manifest_path,
                    info=info,
                    rom=rom,
                    backup_path=backup_path,
                    backup_sha256=backup_digest,
                    mode="internal-prewrite-backup",
                    firmware_path=image.source,
                )
                emit(f"manifest-file: {manifest_path}")
                emit(f"rollback-capability: available via {backup_path}")
                if ini_config is not None:
                    current_image = FirmwareImage.from_bytes(
                        backup_data,
                        source=f"{info.bdf}:spi-backup",
                    )
                    if current_image.family_tag != image.family_tag:
                        raise FlasherError(
                            "current SPI image and requested firmware image belong to different ASMedia "
                            f"families ({current_image.family_tag or '-'} != {image.family_tag or '-'})"
                        )
                    validate_windows_ini_profile(ini_config, device_type=preview_image.device_type)
                    emit(
                        "windows-profile: "
                        f"validated device-type={preview_image.device_type} "
                        "scope=subsystem-only source=Windows-MPTool-compatible"
                    )
                    permanent_image = image.build_permanent_image(
                        config_records=config_records,
                        config_source=current_image,
                    )

                if permanent_image is None:
                    raise FlasherError("failed to assemble the permanent SPI image")

                _validate_internal_permanent_image(permanent_image)

                if ini_config is not None:
                    emit(f"firmware-family: {permanent_image.family_tag}")
                    emit(f"firmware-raw-size: {permanent_image.raw_size} bytes")
                    emit(f"firmware-rom-size: {permanent_image.rom_size} bytes")
                    emit(f"config-records: {len(permanent_image.config_records)}")
                    _print_identity_plan(info, permanent_image, logger=logger)
                    _enforce_identity_requirements(
                        info,
                        permanent_image,
                        require_primary_device_id=require_primary_device_id,
                        require_subsystem_device_id=require_subsystem_device_id,
                        require_subsystem_vendor_id=require_subsystem_vendor_id,
                    )

                if plan_only:
                    emit("status: internal-permanent-write-plan-complete")
                    emit(
                        "next-step: review the predicted IDs, backup, and Windows-profile gate, "
                        "then rerun in write mode only if the plan matches expectations"
                    )
                    return 0

                try:
                    rom = write_internal_flash(controller, permanent_image, verify=verify)
                except Exception as exc:
                    emit("status: internal-permanent-write-failed")
                    emit("rollback: attempting-restore-from-backup")
                    try:
                        restore_internal_flash(controller, backup_data, verify=True)
                    except Exception as rollback_exc:
                        raise FlasherError(
                            f"internal flash write failed and rollback also failed: {exc}; "
                            f"backup={backup_path}; rollback-error={rollback_exc}"
                        ) from exc
                    emit(f"rollback: restored-from-backup {backup_path}")
                    raise FlasherError(
                        f"internal flash write failed but the previous SPI image was restored from {backup_path}: {exc}"
                    ) from exc

        emit(_format_spi_rom_line(rom))
        emit("status: internal-permanent-write-complete")
        emit("next-step: perform a cold reboot or full power cycle before validating the new SPI image")
        return 0


def _cmd_crossflash_internal(
    firmware_path: str,
    *,
    ini_path: str,
    bdf: str | None,
    force_device: bool,
    backup_file: str | None,
    overwrite_backup: bool,
    verify: bool,
    plan_only: bool,
    apply: bool,
) -> int:
    if plan_only and apply:
        raise FlasherError("crossflash-internal accepts either --plan or --apply, not both")

    ini_config = parse_mptool_ini(ini_path)
    if not ini_config.has_overrides:
        raise FlasherError(
            f"{ini_path} does not define any supported Windows override keys (svid/ssid/pcie_speed)"
        )

    return _cmd_permanent_write_internal(
        firmware_path,
        ini_path=ini_path,
        bdf=bdf,
        force_device=force_device,
        keep_driver_bound=False,
        allow_unsafe_ini_overrides=True,
        backup_file=backup_file,
        skip_backup=False,
        overwrite_backup=overwrite_backup,
        verify=verify,
        plan_only=plan_only or not apply,
        require_subsystem_device_id=ini_config.subsystem_device_id,
        require_subsystem_vendor_id=ini_config.subsystem_vendor_id,
        command_name="crossflash-internal",
    )


def _cmd_permanent_restore_internal(
    backup_path: str,
    *,
    bdf: str | None,
    force_device: bool,
    keep_driver_bound: bool,
    verify: bool,
) -> int:
    info = _prepare_internal_device(pick_device(bdf))
    ensure_protocol_supported(info, force=force_device)
    backup = Path(backup_path)
    try:
        backup_data = backup.read_bytes()
    except OSError as exc:
        raise FlasherError(f"failed to read internal flash backup from {backup}: {exc}") from exc
    if not backup_data:
        raise FlasherError(f"internal flash backup is empty: {backup}")
    manifest_path = _manifest_path_for_backup(backup)
    manifest = _load_and_validate_backup_manifest(
        manifest_path,
        backup_path=backup,
        backup_data=backup_data,
    )

    with _operation_log_context("permanent-restore-internal", backup) as logger:
        emit = lambda message: _emit(message, logger=logger)
        emit("mode: permanent-restore-internal")
        emit(f"log-file: {logger.path}")
        emit(_format_device_line(info))
        emit(f"backup-file: {backup}")
        emit(f"backup-size: {len(backup_data)} bytes")
        emit(f"backup-sha256: {hashlib.sha256(backup_data).hexdigest()}")
        if manifest is not None:
            emit(f"manifest-file: {manifest_path}")
            emit(f"manifest-mode: {manifest.get('mode', '-')}")
            emit(
                "manifest-identity: "
                f"{manifest.get('vendor_id', 'unknown')}:{manifest.get('device_id', 'unknown')} "
                f"subsystem={_format_optional_id_pair(_parse_manifest_optional_id(manifest.get('subsystem_vendor_id')), _parse_manifest_optional_id(manifest.get('subsystem_device_id')))}"
            )
        else:
            emit("manifest-file: missing")

        controller = AsmediaXhciController(info)
        with controller.temporarily_unbound(enabled=False):
            with controller:
                rom = restore_internal_flash(controller, backup_data, verify=verify)

        emit(_format_spi_rom_line(rom))
        emit("status: internal-restore-complete")
        emit("next-step: perform a cold reboot or full power cycle before validating the restored SPI image")
        return 0


def _cmd_permanent_write(
    firmware_path: str,
    *,
    programmer: str,
    chip: str | None,
    flashrom_bin: str,
    backup_file: str | None,
    skip_backup: bool,
    overwrite_backup: bool,
    verify: bool,
) -> int:
    image = FirmwareImage.from_path(firmware_path)
    firmware = Path(firmware_path)
    config = FlashromConfig(programmer=programmer, flashrom_bin=flashrom_bin, chip=chip)
    with _operation_log_context("permanent-write", firmware) as logger:
        emit = lambda message: _emit(message, logger=logger)
        emit("mode: permanent-write")
        emit(f"log-file: {logger.path}")
        emit(f"programmer: {programmer}")
        if chip:
            emit(f"chip: {chip}")
        emit(f"firmware-image: {image.source}")
        emit(f"firmware-size: {image.size} bytes")
        if image.header_tags:
            emit(f"firmware-tags: {', '.join(image.header_tags)}")

        if skip_backup:
            raise FlasherError(
                "external SPI writes now require a saved backup file; --skip-backup is disabled "
                "to keep the write path fail-closed"
            )

        backup_path = Path(backup_file) if backup_file else default_backup_path(firmware)
        if backup_path.exists() and not overwrite_backup:
            raise FlasherError(
                f"backup file already exists: {backup_path}; pass --overwrite-backup or choose --backup-file"
            )
        emit(f"backup-file: {backup_path}")
        read_flash(backup_path, config=config)
        backup_data, backup_digest = _verify_existing_file(backup_path, label="external flash backup")
        emit(f"backup-size: {len(backup_data)} bytes")
        emit(f"backup-sha256: {backup_digest}")
        manifest_path = _manifest_path_for_backup(backup_path)
        _write_external_backup_manifest(
            manifest_path,
            config=config,
            backup_path=backup_path,
            backup_sha256=backup_digest,
            mode="external-prewrite-backup",
            firmware_path=image.source,
            bytes_written=len(backup_data),
        )
        emit(f"manifest-file: {manifest_path}")
        emit(f"rollback-capability: available via {backup_path}")

        try:
            write_flash(firmware, config=config, verify=verify)
        except Exception as exc:
            emit("status: permanent-write-failed")
            emit("rollback: attempting-restore-from-backup")
            try:
                write_flash(backup_path, config=config, verify=True)
            except Exception as rollback_exc:
                raise FlasherError(
                    f"external flash write failed and rollback also failed: {exc}; "
                    f"backup={backup_path}; rollback-error={rollback_exc}"
                ) from exc
            emit(f"rollback: restored-from-backup {backup_path}")
            raise FlasherError(
                f"external flash write failed but the previous SPI image was restored from {backup_path}: {exc}"
            ) from exc

        emit("status: permanent-write-complete")
        return 0


class _OperationLogger:
    def __init__(self, path: Path):
        self.path = path
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._handle = self.path.open("a", encoding="utf-8")

    def log(self, message: str) -> None:
        timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
        self._handle.write(f"[{timestamp}] {message}\n")
        self._handle.flush()

    def close(self) -> None:
        self._handle.close()


def _default_operation_log_path(command: str, subject_path: Path) -> Path:
    safe_name = subject_path.name or "asm3042"
    return Path.cwd() / f"{safe_name}.{command}.log"


@contextmanager
def _operation_log_context(command: str, subject_path: Path):
    logger = _OperationLogger(_default_operation_log_path(command, subject_path))
    previous = os.environ.get("ASM3042_ACTIVE_LOG_FILE")
    os.environ["ASM3042_ACTIVE_LOG_FILE"] = str(logger.path)
    logger.log(f"event=command-start command={command} version={__version__}")
    try:
        yield logger
        logger.log("event=command-end status=ok")
    finally:
        if previous is None:
            os.environ.pop("ASM3042_ACTIVE_LOG_FILE", None)
        else:
            os.environ["ASM3042_ACTIVE_LOG_FILE"] = previous
        logger.close()


def _append_active_operation_log(message: str) -> None:
    path_value = os.environ.get("ASM3042_ACTIVE_LOG_FILE")
    if not path_value:
        return
    path = Path(path_value)
    path.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now(timezone.utc).isoformat(timespec="seconds")
    with path.open("a", encoding="utf-8") as handle:
        handle.write(f"[{timestamp}] {message}\n")


def _emit(message: str, *, logger: _OperationLogger | None = None) -> None:
    print(message)
    if logger is not None:
        logger.log(f"stdout {message}")


def _format_device_line(info: DeviceInfo) -> str:
    driver = info.driver or "-"
    rendered = (
        f"device: {info.bdf} "
        f"(vendor=0x{info.vendor_id:04x}, device=0x{info.device_id:04x}, driver={driver})"
    )
    if info.subsystem_vendor_id is not None and info.subsystem_device_id is not None:
        rendered += (
            f", subsystem=0x{info.subsystem_vendor_id:04x}:0x{info.subsystem_device_id:04x}"
        )
    return rendered


def _validate_internal_permanent_image(permanent_image) -> None:
    try:
        validate_permanent_image(permanent_image)
    except ValueError as exc:
        raise FlasherError(f"refusing to flash a ROM image that fails round-trip validation: {exc}") from exc


def _print_identity_plan(info: DeviceInfo, permanent_image, *, logger=None) -> None:
    predicted_primary_device_id, predicted_subsystem_vendor_id, predicted_subsystem_device_id = (
        _predict_post_flash_identity(info, permanent_image)
    )
    _emit(
        "target-primary-id: "
        f"0x{info.vendor_id:04x}:0x{predicted_primary_device_id:04x}",
        logger=logger,
    )
    _emit(
        "target-subsystem-id: "
        f"{_format_optional_id_pair(predicted_subsystem_vendor_id, predicted_subsystem_device_id)}",
        logger=logger,
    )


def _enforce_identity_requirements(
    info: DeviceInfo,
    permanent_image,
    *,
    require_primary_device_id: int | None,
    require_subsystem_device_id: int | None,
    require_subsystem_vendor_id: int | None,
) -> None:
    predicted_primary_device_id, predicted_subsystem_vendor_id, predicted_subsystem_device_id = (
        _predict_post_flash_identity(info, permanent_image)
    )

    if (
        require_primary_device_id is not None
        and predicted_primary_device_id != require_primary_device_id
    ):
        raise FlasherError(
            "predicted primary PCI device id does not match the required value: "
            f"predicted 0x{predicted_primary_device_id:04x}, required 0x{require_primary_device_id:04x}"
        )
    if (
        require_subsystem_device_id is not None
        and predicted_subsystem_device_id != require_subsystem_device_id
    ):
        predicted = _format_optional_id(predicted_subsystem_device_id)
        raise FlasherError(
            "predicted subsystem device id does not match the required value: "
            f"predicted {predicted}, required 0x{require_subsystem_device_id:04x}"
        )
    if (
        require_subsystem_vendor_id is not None
        and predicted_subsystem_vendor_id != require_subsystem_vendor_id
    ):
        predicted = _format_optional_id(predicted_subsystem_vendor_id)
        raise FlasherError(
            "predicted subsystem vendor id does not match the required value: "
            f"predicted {predicted}, required 0x{require_subsystem_vendor_id:04x}"
        )


def _format_optional_id(value: int | None) -> str:
    return f"0x{value:04x}" if value is not None else "unknown"


def _format_optional_id_pair(left: int | None, right: int | None) -> str:
    return f"{_format_optional_id(left)}:{_format_optional_id(right)}"


def _format_spi_rom_line(rom) -> str:
    ids = f"{rom.manufacturer_id:02x}:{rom.memory_type_id:02x}:{rom.capacity_id:02x}"
    return (
        f"spi-rom: {rom.manufacturer} {rom.model} "
        f"(id={ids}, size={rom.flash_size_bytes} bytes, sector={rom.sector_size_bytes} bytes)"
    )


def _write_bytes(path: Path, data: bytes, *, label: str) -> None:
    try:
        path.write_bytes(data)
    except OSError as exc:
        raise FlasherError(f"failed to write {label} to {path}: {exc}") from exc


def _write_verified_backup(path: Path, data: bytes, *, label: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(data).hexdigest()

    try:
        with tempfile.NamedTemporaryFile(
            mode="wb",
            dir=path.parent,
            prefix=f".{path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
            temp_path = Path(handle.name)
        os.replace(temp_path, path)
    except OSError as exc:
        raise FlasherError(f"failed to write {label} to {path}: {exc}") from exc

    try:
        on_disk = path.read_bytes()
    except OSError as exc:
        raise FlasherError(f"failed to verify {label} at {path}: {exc}") from exc

    if len(on_disk) != len(data):
        raise FlasherError(
            f"backup verification failed for {path}: size mismatch ({len(on_disk)} != {len(data)})"
        )
    on_disk_digest = hashlib.sha256(on_disk).hexdigest()
    if on_disk_digest != digest:
        raise FlasherError(
            f"backup verification failed for {path}: sha256 mismatch "
            f"({on_disk_digest} != {digest})"
        )
    return digest


def _verify_existing_file(path: Path, *, label: str) -> tuple[bytes, str]:
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise FlasherError(f"failed to verify {label} at {path}: {exc}") from exc
    if not data:
        raise FlasherError(f"{label} is empty at {path}")
    return data, hashlib.sha256(data).hexdigest()


def _manifest_path_for_backup(backup_path: Path) -> Path:
    return backup_path.with_name(f"{backup_path.name}.manifest.json")


def _write_backup_manifest(
    manifest_path: Path,
    *,
    info: DeviceInfo,
    rom,
    backup_path: Path,
    backup_sha256: str,
    mode: str,
    firmware_path: str | None = None,
    bytes_written: int | None = None,
) -> None:
    payload = {
        "mode": mode,
        "bdf": info.bdf,
        "vendor_id": f"0x{info.vendor_id:04x}",
        "device_id": f"0x{info.device_id:04x}",
        "subsystem_vendor_id": None if info.subsystem_vendor_id is None else f"0x{info.subsystem_vendor_id:04x}",
        "subsystem_device_id": None if info.subsystem_device_id is None else f"0x{info.subsystem_device_id:04x}",
        "spi_rom": {
            "manufacturer": rom.manufacturer,
            "model": rom.model,
            "id": f"{rom.manufacturer_id:02x}:{rom.memory_type_id:02x}:{rom.capacity_id:02x}",
            "size_bytes": rom.flash_size_bytes,
            "sector_size_bytes": rom.sector_size_bytes,
        },
        "backup_file": str(backup_path),
        "backup_sha256": backup_sha256,
        "bytes_written": bytes_written,
        "firmware_image": firmware_path,
    }
    try:
        manifest_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except OSError as exc:
        raise FlasherError(f"failed to write backup manifest to {manifest_path}: {exc}") from exc


def _write_external_backup_manifest(
    manifest_path: Path,
    *,
    config: FlashromConfig,
    backup_path: Path,
    backup_sha256: str,
    mode: str,
    firmware_path: str | None = None,
    bytes_written: int | None = None,
) -> None:
    payload = {
        "mode": mode,
        "programmer": config.programmer,
        "chip": config.chip,
        "flashrom_bin": config.flashrom_bin,
        "backup_file": str(backup_path),
        "backup_sha256": backup_sha256,
        "bytes_written": bytes_written,
        "firmware_image": firmware_path,
    }
    try:
        manifest_path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    except OSError as exc:
        raise FlasherError(f"failed to write backup manifest to {manifest_path}: {exc}") from exc


def _load_and_validate_backup_manifest(
    manifest_path: Path,
    *,
    backup_path: Path,
    backup_data: bytes,
) -> dict[str, object] | None:
    if not manifest_path.exists():
        return None
    try:
        payload = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise FlasherError(f"failed to read backup manifest from {manifest_path}: {exc}") from exc
    if not isinstance(payload, dict):
        raise FlasherError(f"backup manifest is malformed: {manifest_path}")

    expected_sha = payload.get("backup_sha256")
    actual_sha = hashlib.sha256(backup_data).hexdigest()
    if expected_sha and expected_sha != actual_sha:
        raise FlasherError(
            f"backup manifest sha256 mismatch for {backup_path}: {expected_sha} != {actual_sha}"
        )

    expected_size = payload.get("bytes_written")
    if expected_size is not None:
        try:
            expected_size_int = int(expected_size)
        except (TypeError, ValueError) as exc:
            raise FlasherError(f"backup manifest has an invalid bytes_written value: {manifest_path}") from exc
        if expected_size_int != len(backup_data):
            raise FlasherError(
                f"backup manifest size mismatch for {backup_path}: {expected_size_int} != {len(backup_data)}"
            )

    return payload


def _parse_manifest_optional_id(value: object) -> int | None:
    if value in {None, "", "unknown"}:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value, 0)
        except ValueError:
            return None
    return None


def _predict_post_flash_identity(info: DeviceInfo, permanent_image) -> tuple[int, int | None, int | None]:
    address_map = CFG_RECORD_ADDRESSES.get(getattr(permanent_image, "device_type", None), {})
    config_records = tuple(getattr(permanent_image, "config_records", ()))

    primary_device_id = _find_config_record_value(
        config_records,
        address_map.get("did"),
        default=info.device_id,
    )
    subsystem_vendor_id = _find_config_record_value(
        config_records,
        address_map.get("svid"),
        default=info.subsystem_vendor_id,
    )
    subsystem_device_id = _find_config_record_value(
        config_records,
        address_map.get("ssid"),
        default=info.subsystem_device_id,
    )
    return primary_device_id, subsystem_vendor_id, subsystem_device_id


def _find_config_record_value(config_records, address: int | None, *, default):
    if address is None:
        return default
    for record in reversed(config_records):
        if getattr(record, "address", None) == address:
            return getattr(record, "value", default)
    return default


def _prepare_internal_device(info: DeviceInfo) -> DeviceInfo:
    if info.driver:
        return info

    refreshed = _recover_internal_driver(info.bdf)
    if refreshed is not None:
        return refreshed

    return info


def _recover_internal_driver(bdf: str) -> DeviceInfo | None:
    _try_enable_pci_function(bdf)
    refreshed = _try_probe_pci_drivers(bdf) or _try_bind_xhci_driver(bdf)
    if refreshed is not None and refreshed.driver:
        return refreshed

    if _try_reset_pci_function(bdf):
        _try_enable_pci_function(bdf)
        refreshed = _try_probe_pci_drivers(bdf) or _try_bind_xhci_driver(bdf) or _try_pick_device(bdf)
        if refreshed is not None and refreshed.driver:
            return refreshed

    if _try_reset_parent_bridge(bdf):
        _try_enable_pci_function(bdf)
        refreshed = _try_probe_pci_drivers(bdf) or _try_bind_xhci_driver(bdf) or _try_pick_device(bdf)
        if refreshed is not None and refreshed.driver:
            return refreshed

    if _try_remove_and_rescan_pci_function(bdf):
        _try_enable_pci_function(bdf)
        refreshed = _try_probe_pci_drivers(bdf) or _try_bind_xhci_driver(bdf) or _try_pick_device(bdf)
        if refreshed is not None and refreshed.driver:
            return refreshed

    return _try_pick_device(bdf)


def _try_probe_pci_drivers(bdf: str) -> DeviceInfo | None:
    probe_path = Path("/sys/bus/pci/drivers_probe")
    if not probe_path.exists():
        return None
    try:
        probe_path.write_text(bdf)
    except OSError:
        return None
    time.sleep(0.1)
    return _try_pick_device(bdf)


def _try_bind_xhci_driver(bdf: str) -> DeviceInfo | None:
    for driver_name in ("xhci_hcd", "xhci_pci"):
        bind_path = Path("/sys/bus/pci/drivers") / driver_name / "bind"
        if not bind_path.exists():
            continue
        try:
            bind_path.write_text(bdf)
        except OSError:
            continue
        time.sleep(0.1)
        try:
            return pick_device(bdf)
        except DeviceNotFoundError:
            continue
    return None


def _try_enable_pci_function(bdf: str) -> bool:
    device_path = Path("/sys/bus/pci/devices") / bdf
    changed = False
    enable_path = device_path / "enable"
    power_control_path = device_path / "power" / "control"

    if enable_path.exists():
        try:
            enable_path.write_text("1")
            changed = True
        except OSError:
            pass

    if power_control_path.exists():
        try:
            power_control_path.write_text("on")
            changed = True
        except OSError:
            pass

    return changed


def _try_reset_pci_function(bdf: str) -> bool:
    reset_path = Path("/sys/bus/pci/devices") / bdf / "reset"
    if not reset_path.exists():
        return False
    try:
        reset_path.write_text("1")
    except OSError:
        return False
    time.sleep(0.2)
    return True


def _try_reset_parent_bridge(bdf: str) -> bool:
    parent_path = _find_parent_pci_device_path(bdf)
    if parent_path is None:
        return False
    reset_path = parent_path / "reset"
    if not reset_path.exists():
        return False
    try:
        reset_path.write_text("1")
    except OSError:
        return False
    time.sleep(0.2)
    return True


def _try_remove_and_rescan_pci_function(bdf: str) -> bool:
    device_path = Path("/sys/bus/pci/devices") / bdf
    remove_path = device_path / "remove"
    rescan_path = Path("/sys/bus/pci/rescan")
    if not remove_path.exists() or not rescan_path.exists():
        return False
    try:
        remove_path.write_text("1")
        time.sleep(0.1)
        rescan_path.write_text("1")
    except OSError:
        return False
    time.sleep(0.5)
    return True


def _find_parent_pci_device_path(bdf: str) -> Path | None:
    device_path = Path("/sys/bus/pci/devices") / bdf
    try:
        resolved = device_path.resolve()
    except OSError:
        return None

    parent = resolved.parent
    if not parent.exists():
        return None
    if not parent.name or parent.name == resolved.name:
        return None
    try:
        normalize_bdf(parent.name)
    except ValueError:
        return None
    return Path("/sys/bus/pci/devices") / parent.name


def _try_pick_device(bdf: str) -> DeviceInfo | None:
    try:
        return pick_device(bdf)
    except DeviceNotFoundError:
        return None


def _try_get_firmware_version(controller: AsmediaXhciController) -> int | None:
    try:
        return controller.get_firmware_version()
    except (FlasherError, TimeoutError):
        return None


def _print_running_version(label: str, value: int | None, *, logger=None) -> None:
    if value is None:
        _emit(f"{label}: unavailable", logger=logger)
        return
    _emit(f"{label}: {format_fw_version(value)}", logger=logger)


def _require_root(command: str) -> None:
    if os.geteuid() != 0:
        raise FlasherError(f"'{command}' requires root privileges")


if __name__ == "__main__":
    raise SystemExit(main())
