from __future__ import annotations

from dataclasses import dataclass
import os
import sys
import time

from .device import AsmediaXhciController, FlasherError
from .firmware import FirmwareImage, PermanentFirmwareImage
from .spi_rom_table import SPI_ROM_PREFIXES


FLASH_CHUNK_SIZE = 0x10000
READ_CHUNK_SIZE = 8
READ_READY_MASK = 1 << 0
WRITE_READY_MASK = 1 << 1
CONTROL_OFFSET = 0xE0
DATA_READ0_OFFSET = 0xF0
DATA_READ1_OFFSET = 0xF4
DATA_WRITE0_OFFSET = 0xF8
DATA_WRITE1_OFFSET = 0xFC

READ_RETRY_COUNT = 3
READ_RETRY_DELAY_SEC = 0.1
MAX_FF_CONTROL_READS = 10
WINDOWS_READ_READY_POLLS = 0x4E20
READ_PHASE_RESET_POLLS = 0x40
SPI_ROM_PROBE_DELAY_SEC = 0.010

INTERNAL_DEVICE_TYPES = {
    0x3042: 2,
    0x3142: 2,
}


def _trace_enabled() -> bool:
    value = os.environ.get("ASM3042_SPI_TRACE", "")
    return value.lower() not in {"", "0", "false", "no", "off"} or bool(
        os.environ.get("ASM3042_ACTIVE_LOG_FILE")
    )


def _trace(message: str) -> None:
    if not _trace_enabled():
        return
    rendered = f"[asm3042-spi] {message}\n"
    value = os.environ.get("ASM3042_SPI_TRACE", "")
    if value.lower() not in {"", "0", "false", "no", "off"}:
        sys.stderr.write(rendered)
        sys.stderr.flush()
    log_path = os.environ.get("ASM3042_ACTIVE_LOG_FILE")
    if log_path:
        with open(log_path, "a", encoding="utf-8") as handle:
            handle.write(rendered)

@dataclass(frozen=True)
class SpiRomInfo:
    prefix: bytes
    manufacturer: str
    model: str

    @property
    def read_id_command(self) -> int:
        return self.prefix[0]

    @property
    def manufacturer_id(self) -> int:
        return self.prefix[8]

    @property
    def memory_type_id(self) -> int:
        return self.prefix[9]

    @property
    def capacity_id(self) -> int:
        return self.prefix[10]

    @property
    def rom_size_units(self) -> int:
        return int.from_bytes(self.prefix[4:6], "little")

    @property
    def flash_size_bytes(self) -> int:
        return self.rom_size_units << 12

    @property
    def sector_size_bytes(self) -> int:
        return self.prefix[3] << 12

    @property
    def erase_descriptor_low(self) -> int:
        return int.from_bytes(self.prefix[0:4], "little")

    @property
    def erase_descriptor_high(self) -> int:
        return (
            int.from_bytes(self.prefix[4:6], "little")
            + (self.prefix[6] << 8)
            + (self.prefix[7] << 16)
            + (self.prefix[8] << 24)
        )

    @property
    def ids(self) -> tuple[int, int, int]:
        return (self.manufacturer_id, self.memory_type_id, self.capacity_id)

    @property
    def requires_sst_write_mode(self) -> bool:
        return self.manufacturer_id == 0xBF

    @property
    def uses_split_erase(self) -> bool:
        return (
            (self.manufacturer_id == 0xC8 and self.memory_type_id == 0x40)
            or (self.manufacturer_id == 0x20 and self.memory_type_id == 0x20)
            or (self.manufacturer_id == 0x68 and self.memory_type_id == 0x40)
        )


@dataclass(frozen=True)
class SpiRomProbeResult:
    command: int
    phase1_ids: tuple[int, int, int]
    phase2_ids: tuple[int, int, int]


SPI_ROM_INFOS: tuple[SpiRomInfo, ...] = tuple(
    SpiRomInfo(prefix=prefix, manufacturer=manufacturer, model=model)
    for prefix, manufacturer, model in SPI_ROM_PREFIXES
)


def probe_internal_spi_rom(controller: AsmediaXhciController) -> SpiRomInfo:
    cached = getattr(controller, "_asm3042_spi_rom_info", None)
    if isinstance(cached, SpiRomInfo):
        return cached

    device_type = INTERNAL_DEVICE_TYPES.get(controller.info.device_id)
    if device_type is None:
        raise FlasherError(
            f"internal permanent flashing is not supported for device 0x{controller.info.device_id:04x}"
        )

    _set_spi_page_size(controller, 0x80)
    rom = _find_spi_rom_info(controller)

    if rom.manufacturer_id == 0xC2 and rom.memory_type_id == 0x22 and rom.capacity_id in {0x10, 0x11}:
        _set_spi_page_size(controller, 0x20)

    if device_type in {2, 4} and rom.flash_size_bytes < 0x20000:
        raise FlasherError(
            f"detected SPI ROM is too small ({rom.flash_size_bytes} bytes) for ASM3042/ASM3142"
        )

    setattr(controller, "_asm3042_spi_rom_info", rom)
    return rom


def extract_permanent_firmware(image: FirmwareImage) -> PermanentFirmwareImage:
    return image.build_permanent_image()


def write_internal_flash(
    controller: AsmediaXhciController,
    firmware: PermanentFirmwareImage,
    *,
    verify: bool = True,
) -> SpiRomInfo:
    return _write_spi_image(controller, firmware.rom_data, verify=verify)


def restore_internal_flash(
    controller: AsmediaXhciController,
    backup_data: bytes,
    *,
    verify: bool = True,
) -> SpiRomInfo:
    if not backup_data:
        raise FlasherError("cannot restore internal flash from an empty backup image")
    return _write_spi_image(controller, backup_data, verify=verify)


def _write_spi_image(
    controller: AsmediaXhciController,
    image_data: bytes,
    *,
    verify: bool = True,
) -> SpiRomInfo:
    rom = _init_spi_rom(controller)
    if rom.sector_size_bytes <= 0:
        raise FlasherError("detected SPI ROM reports an invalid erase sector size")
    if not image_data:
        raise FlasherError("SPI image is empty")
    erase_size = _round_up(len(image_data), rom.sector_size_bytes)

    if erase_size > rom.flash_size_bytes:
        raise FlasherError(
            f"firmware payload ({erase_size} bytes after sector alignment) does not fit into detected SPI ROM "
            f"({rom.flash_size_bytes} bytes)"
        )

    for sector_offset in range(0, erase_size, rom.sector_size_bytes):
        _erase_region(controller, rom, offset=sector_offset, size=rom.sector_size_bytes)
        sector_data = image_data[sector_offset : sector_offset + rom.sector_size_bytes]
        if not sector_data:
            continue

        chunk_offset = 0
        while chunk_offset < len(sector_data):
            chunk = sector_data[chunk_offset : chunk_offset + FLASH_CHUNK_SIZE]
            abs_offset = sector_offset + chunk_offset
            last_error: Exception | None = None
            for retry in range(3):
                try:
                    _write_section(
                        controller,
                        rom,
                        chunk,
                        offset=abs_offset,
                        retry_index=retry,
                    )
                    last_error = None
                    break
                except Exception as exc:  # pragma: no cover - hardware dependent
                    last_error = exc
                    time.sleep(0.2)
            if last_error is not None:
                raise FlasherError(
                    f"failed to write SPI chunk at 0x{abs_offset:05x}: {last_error}"
                ) from last_error
            chunk_offset += len(chunk)

        verified_sector = _read_flash(controller, len(sector_data), offset=sector_offset)
        if verified_sector != sector_data:
            mismatch = next(
                idx
                for idx, (left, right) in enumerate(zip(verified_sector, sector_data))
                if left != right
            )
            abs_mismatch = sector_offset + mismatch
            raise FlasherError(
                f"SPI sector verification failed at offset 0x{abs_mismatch:05x}: "
                f"read 0x{verified_sector[mismatch]:02x}, expected 0x{sector_data[mismatch]:02x}"
            )

    if verify:
        read_back = _read_flash(controller, len(image_data), offset=0)
        if read_back != image_data:
            mismatch = next(
                idx
                for idx, (left, right) in enumerate(zip(read_back, image_data))
                if left != right
            )
            raise FlasherError(
                f"SPI verification failed at offset 0x{mismatch:05x}: "
                f"read 0x{read_back[mismatch]:02x}, expected 0x{image_data[mismatch]:02x}"
            )

    _reset_controller_after_write(controller)
    return rom


def read_internal_flash(
    controller: AsmediaXhciController,
    *,
    size: int | None = None,
) -> tuple[SpiRomInfo, bytes]:
    rom = probe_internal_spi_rom(controller)
    read_size = rom.flash_size_bytes if size is None else size
    if read_size <= 0:
        raise FlasherError(f"read size must be positive, got {read_size}")
    if read_size > rom.flash_size_bytes:
        raise FlasherError(
            f"requested read size ({read_size} bytes) exceeds detected SPI ROM size "
            f"({rom.flash_size_bytes} bytes)"
        )
    return rom, _read_flash(controller, read_size)


def _init_spi_rom(controller: AsmediaXhciController) -> SpiRomInfo:
    rom = probe_internal_spi_rom(controller)
    _set_write_protect(controller, enable=False)
    return rom


def _find_spi_rom_info(controller: AsmediaXhciController) -> SpiRomInfo:
    read_cache: dict[int, SpiRomProbeResult] = {}
    have_probe_result = False

    for rom in SPI_ROM_INFOS:
        command = rom.read_id_command
        if command not in read_cache:
            if have_probe_result:
                time.sleep(SPI_ROM_PROBE_DELAY_SEC)
            read_cache[command] = _read_spi_rom_id(controller, command)
            have_probe_result = True

        matched = _match_spi_rom_probe(read_cache[command])
        if matched is not None:
            return matched

    attempted = ", ".join(
        _format_spi_probe_attempt(command, probe)
        for command, probe in sorted(read_cache.items())
    )
    raise FlasherError(f"unsupported SPI ROM ID ({attempted or 'no-response'})")


def _read_spi_rom_id(
    controller: AsmediaXhciController,
    command: int,
) -> SpiRomProbeResult:
    phase1, phase2 = _read_command_response_phases(
        controller,
        cmd=0x40,
        mem_type=0x20,
        size=3,
        addr=0,
        sec_low=command,
        sec_high=0,
    )
    return SpiRomProbeResult(
        command=command,
        phase1_ids=_ids_from_response(phase1),
        phase2_ids=_ids_from_response(phase2),
    )


def _set_spi_page_size(controller: AsmediaXhciController, page_size: int) -> None:
    _write_command(
        controller,
        cmd=0x1B,
        mem_type=0x10,
        size=1,
        addr=0,
        sec_low=page_size,
        sec_high=0,
    )


def _set_write_protect(controller: AsmediaXhciController, *, enable: bool) -> tuple[int, int]:
    protect_bits = 0x9C if enable else 0x00

    _write_command(
        controller,
        cmd=0x19,
        mem_type=0x10,
        size=1,
        addr=0,
        sec_low=0x06,
        sec_high=0,
    )
    _write_status_register(controller, 0x301 | (protect_bits << 8))

    if enable:
        _write_command(
            controller,
            cmd=0x19,
            mem_type=0x10,
            size=1,
            addr=0,
            sec_low=0x04,
            sec_high=0,
        )

    return _read_status_registers(controller)


def _write_status_register(controller: AsmediaXhciController, status_word: int) -> None:
    _write_command(
        controller,
        cmd=0x1C,
        mem_type=0x10,
        size=1,
        addr=0,
        sec_low=status_word,
        sec_high=0,
    )


def _read_status_registers(controller: AsmediaXhciController) -> tuple[int, int]:
    data = _read_command_response(
        controller,
        cmd=0x4C,
        mem_type=0x10,
        size=2,
        addr=0,
        sec_low=0x05,
        sec_high=0,
    )
    return (data[0], data[1])


def _read_command_response(
    controller: AsmediaXhciController,
    *,
    cmd: int,
    mem_type: int,
    size: int,
    addr: int,
    sec_low: int,
    sec_high: int,
) -> bytes:
    first_phase, second_phase = _read_command_response_phases(
        controller,
        cmd=cmd,
        mem_type=mem_type,
        size=size,
        addr=addr,
        sec_low=sec_low,
        sec_high=sec_high,
    )
    if _looks_like_read_echo(second_phase, cmd=cmd, mem_type=mem_type, size=size, addr=addr):
        if not _looks_like_read_echo(first_phase, cmd=cmd, mem_type=mem_type, size=size, addr=addr):
            _trace("read-response selected=phase-1 reason=phase-2-echo")
            return first_phase
    return second_phase


def _read_command_response_phases(
    controller: AsmediaXhciController,
    *,
    cmd: int,
    mem_type: int,
    size: int,
    addr: int,
    sec_low: int,
    sec_high: int,
) -> tuple[bytes, bytes]:
    _trace(
        "read-command "
        f"cmd=0x{cmd:02x} mem=0x{mem_type:02x} size={size} addr=0x{addr:08x} "
        f"sec_low=0x{sec_low:08x} sec_high=0x{sec_high:08x}"
    )
    _set_write_cmd_all(
        controller,
        cmd=cmd,
        mem_type=mem_type,
        size=size,
        addr=addr,
        sec_low=sec_low,
        sec_high=sec_high,
    )
    # Windows ASMedia driver observes two read-ready phases. The first phase is
    # acknowledged and discarded before the real response bytes are read.
    _wait_read_ready(controller)
    first_phase = _drain_read_phase(controller)
    _trace(f"read-phase-1 data={first_phase.hex()}")
    _wait_read_phase_reset(controller)
    _wait_read_ready(controller)
    data = _read_response_bytes(controller, size=size)
    _trace(f"read-phase-2 data={data.hex()}")
    _ack_read_response(controller)
    return first_phase, data


def _cfg_read_u8(controller: AsmediaXhciController, offset: int) -> int:
    reader = getattr(controller, "read_config_u8", None)
    if reader is not None:
        return reader(offset)
    reader = getattr(controller, "read_config_sysfs_u8", None)
    if reader is not None:
        return reader(offset)
    raise AttributeError("controller does not provide config byte reads")


def _cfg_read_u32(controller: AsmediaXhciController, offset: int) -> int:
    reader = getattr(controller, "read_config_u32", None)
    if reader is not None:
        return reader(offset)
    reader = getattr(controller, "read_config_sysfs_u32", None)
    if reader is not None:
        return reader(offset)
    raise AttributeError("controller does not provide config dword reads")


def _cfg_write_u8(controller: AsmediaXhciController, offset: int, value: int) -> None:
    writer = getattr(controller, "write_config_u8", None)
    if writer is not None:
        writer(offset, value)
        return
    writer = getattr(controller, "write_config_sysfs_u8", None)
    if writer is not None:
        writer(offset, value)
        return
    raise AttributeError("controller does not provide config byte writes")


def _cfg_write_u32(controller: AsmediaXhciController, offset: int, value: int) -> None:
    writer = getattr(controller, "write_config_u32", None)
    if writer is not None:
        writer(offset, value)
        return
    writer = getattr(controller, "write_config_sysfs_u32", None)
    if writer is not None:
        writer(offset, value)
        return
    raise AttributeError("controller does not provide config dword writes")


def _ids_from_response(data: bytes) -> tuple[int, int, int]:
    padded = data[:3].ljust(3, b"\x00")
    return (padded[0], padded[1], padded[2])


def _build_read_echo_bytes(
    *,
    cmd: int,
    mem_type: int,
    size: int,
    addr: int,
) -> bytes:
    low = ((size & 0xFFFF) << 16) | ((mem_type & 0xFF) << 8) | (cmd & 0xFF)
    payload = low.to_bytes(4, "little") + (addr & 0xFFFFFFFF).to_bytes(4, "little")
    return payload[:size]


def _looks_like_read_echo(
    data: bytes,
    *,
    cmd: int,
    mem_type: int,
    size: int,
    addr: int,
) -> bool:
    return data == _build_read_echo_bytes(
        cmd=cmd,
        mem_type=mem_type,
        size=size,
        addr=addr,
    )


def _looks_like_spi_probe_echo(ids: tuple[int, int, int]) -> bool:
    return ids == (0x40, 0x20, 0x03)


def _match_spi_rom_ids(
    ids: tuple[int, int, int],
    *,
    command: int | None,
) -> SpiRomInfo | None:
    for rom in SPI_ROM_INFOS:
        if command is not None and rom.read_id_command != command:
            continue
        expected = rom.ids
        if ids[0] != expected[0] or ids[1] != expected[1]:
            continue
        if expected[2] != 0xFF and ids[2] != expected[2]:
            continue
        return rom
    return None


def _match_spi_rom_probe(probe: SpiRomProbeResult) -> SpiRomInfo | None:
    candidates: list[tuple[int, int, int]] = []
    if _looks_like_spi_probe_echo(probe.phase2_ids):
        candidates.append(probe.phase1_ids)
        if probe.phase2_ids != probe.phase1_ids:
            candidates.append(probe.phase2_ids)
    else:
        candidates.append(probe.phase2_ids)
        if probe.phase1_ids != probe.phase2_ids:
            candidates.append(probe.phase1_ids)

    seen: set[tuple[int, int, int]] = set()
    unique_candidates = [ids for ids in candidates if not (ids in seen or seen.add(ids))]

    for ids in unique_candidates:
        match = _match_spi_rom_ids(ids, command=probe.command)
        if match is not None:
            return match
    for ids in unique_candidates:
        match = _match_spi_rom_ids(ids, command=None)
        if match is not None:
            return match
    return None


def _format_spi_probe_attempt(command: int, probe: SpiRomProbeResult) -> str:
    phase2 = f"{probe.phase2_ids[0]:02x}:{probe.phase2_ids[1]:02x}:{probe.phase2_ids[2]:02x}"
    if probe.phase1_ids == probe.phase2_ids:
        return f"0x{command:02x}={phase2}"
    phase1 = f"{probe.phase1_ids[0]:02x}:{probe.phase1_ids[1]:02x}:{probe.phase1_ids[2]:02x}"
    return f"0x{command:02x}={phase2}(phase1={phase1})"


def _erase_region(
    controller: AsmediaXhciController,
    rom: SpiRomInfo,
    *,
    offset: int,
    size: int,
) -> None:
    if size <= 0:
        return
    if rom.sector_size_bytes == 0:
        raise FlasherError("detected SPI ROM reports zero erase sector size")
    if size % rom.sector_size_bytes:
        raise FlasherError(
            f"erase size 0x{size:x} is not aligned to the SPI sector size 0x{rom.sector_size_bytes:x}"
        )

    erase_low = rom.erase_descriptor_low
    erase_high = rom.erase_descriptor_high

    if rom.uses_split_erase:
        total_sectors = size // rom.sector_size_bytes
        sector_count = total_sectors // 2
        if sector_count <= 0:
            raise FlasherError("split erase computed an empty sector count")
        block_size = sector_count * rom.sector_size_bytes
        current = offset
        while current < offset + size:
            _write_command(
                controller,
                cmd=0x30,
                mem_type=0x10,
                size=sector_count,
                addr=current,
                sec_low=erase_low,
                sec_high=erase_high,
                wait_units=0x3E8,
            )
            time.sleep(0.05)
            current += block_size
        return

    _write_command(
        controller,
        cmd=0x30,
        mem_type=0x10,
        size=size // rom.sector_size_bytes,
        addr=offset,
        sec_low=erase_low,
        sec_high=erase_high,
        wait_units=0x7D0,
    )


def _write_section(
    controller: AsmediaXhciController,
    rom: SpiRomInfo,
    chunk: bytes,
    *,
    offset: int,
    retry_index: int,
) -> None:
    if not chunk or len(chunk) > FLASH_CHUNK_SIZE:
        raise FlasherError(
            f"internal write chunks must be between 1 and 0x{FLASH_CHUNK_SIZE:x} bytes, got 0x{len(chunk):x}"
        )

    if rom.requires_sst_write_mode:
        control = _read_memory(controller, mem_type=0x04, size=1, addr=0xF341, sec_low=0)[0]
        mode_base = retry_index << 7
        start_value = mode_base + (0x80 if (control & 0x02) else 0xF0)
        _write_command(
            controller,
            cmd=0x1D,
            mem_type=0x10,
            size=0,
            addr=offset,
            sec_low=start_value,
            sec_high=0,
        )
    else:
        _write_command(
            controller,
            cmd=0x11,
            mem_type=0x10,
            size=0,
            addr=offset,
            sec_low=0,
            sec_high=0,
        )

    for block_offset in range(0, len(chunk), READ_CHUNK_SIZE):
        block = chunk[block_offset : block_offset + READ_CHUNK_SIZE]
        low = int.from_bytes(block[:4], "little")
        high = int.from_bytes(block[4:], "little")
        command = 0x1E if len(block) == READ_CHUNK_SIZE else 0x1F
        _write_command(
            controller,
            cmd=command,
            mem_type=0x10,
            size=len(block),
            addr=offset + block_offset,
            sec_low=low,
            sec_high=high,
        )


def _read_flash(
    controller: AsmediaXhciController,
    size: int,
    *,
    offset: int = 0,
) -> bytes:
    if offset < 0:
        raise FlasherError(f"read offset must be non-negative, got {offset}")
    data = bytearray()
    cursor = 0
    while cursor < size:
        chunk_size = min(READ_CHUNK_SIZE, size - cursor)
        last_error: Exception | None = None
        for attempt in range(READ_RETRY_COUNT):
            try:
                data.extend(
                    _read_memory(
                        controller,
                        mem_type=0x10,
                        size=chunk_size,
                        addr=offset + cursor,
                        sec_low=0,
                    )
                )
                last_error = None
                break
            except Exception as exc:  # pragma: no cover - hardware dependent
                last_error = exc
                if attempt + 1 == READ_RETRY_COUNT:
                    break
                time.sleep(READ_RETRY_DELAY_SEC)
        if last_error is not None:
            raise FlasherError(
                f"failed to read SPI chunk at 0x{offset + cursor:05x}: {last_error}"
            ) from last_error
        cursor += chunk_size
    return bytes(data)


def _read_memory(
    controller: AsmediaXhciController,
    *,
    mem_type: int,
    size: int,
    addr: int,
    sec_low: int,
) -> bytes:
    if not 0 < size <= READ_CHUNK_SIZE:
        raise FlasherError(f"read size must be between 1 and {READ_CHUNK_SIZE}, got {size}")

    return _read_command_response(
        controller,
        cmd=0x40,
        mem_type=mem_type,
        size=size,
        addr=addr,
        sec_low=sec_low,
        sec_high=0,
    )


def _reset_controller_after_write(controller: AsmediaXhciController) -> None:
    _write_reset_register(controller, offset=0xE8, value=0x00015040, size=4)
    _write_reset_register(controller, offset=0xEA, value=0x02, size=1)
    _write_reset_register(controller, offset=0xE8, value=0x00015042, size=4)
    _write_reset_register(controller, offset=0xEA, value=0x01, size=1)
    time.sleep(0.2)


def _write_reset_register(
    controller: AsmediaXhciController,
    *,
    offset: int,
    value: int,
    size: int,
) -> None:
    if size == 4:
        controller.write_config_u32(offset, value)
        time.sleep(0.005)
        observed = controller.read_config_u32(offset)
        mask = 0xFFFFFFFF
    elif size == 1:
        controller.write_config_u8(offset, value)
        time.sleep(0.005)
        observed = controller.read_config_u8(offset)
        mask = 0xFF
    else:  # pragma: no cover - internal only
        raise ValueError(f"unsupported reset register size: {size}")

    expected = value & mask
    if observed != expected:
        raise FlasherError(
            f"failed to verify ASMedia reset register 0x{offset:02x}: "
            f"read 0x{observed:0{size * 2}x}, expected 0x{expected:0{size * 2}x}"
        )


def _write_command(
    controller: AsmediaXhciController,
    *,
    cmd: int,
    mem_type: int,
    size: int,
    addr: int,
    sec_low: int,
    sec_high: int,
    wait_units: int = 0x14,
) -> None:
    _trace(
        "write-command "
        f"cmd=0x{cmd:02x} mem=0x{mem_type:02x} size={size} addr=0x{addr:08x} "
        f"sec_low=0x{sec_low:08x} sec_high=0x{sec_high:08x} wait_units=0x{wait_units:x}"
    )
    _set_write_cmd_all(
        controller,
        cmd=cmd,
        mem_type=mem_type,
        size=size,
        addr=addr,
        sec_low=sec_low,
        sec_high=sec_high,
        wait_units=wait_units,
    )
    _wait_write_ready(controller, wait_units=wait_units)


def _set_write_cmd_all(
    controller: AsmediaXhciController,
    *,
    cmd: int,
    mem_type: int,
    size: int,
    addr: int,
    sec_low: int,
    sec_high: int,
    wait_units: int = 0x14,
) -> None:
    _wait_write_ready(controller, wait_units=0x14)
    value_low = ((size & 0xFFFF) << 16) | ((mem_type & 0xFF) << 8) | (cmd & 0xFF)
    _issue_write_request(controller, value_low=value_low, value_high=addr)
    _wait_write_ready(controller, wait_units=0x14)
    _issue_write_request(controller, value_low=sec_low, value_high=sec_high)


def _issue_write_request(
    controller: AsmediaXhciController,
    *,
    value_low: int,
    value_high: int,
) -> None:
    _trace(
        f"write-request low=0x{value_low:08x} high=0x{value_high:08x}"
    )
    _cfg_write_u32(controller, DATA_WRITE0_OFFSET, value_low & 0xFFFFFFFF)
    _cfg_write_u32(controller, DATA_WRITE1_OFFSET, value_high & 0xFFFFFFFF)
    _cfg_write_u8(controller, CONTROL_OFFSET, WRITE_READY_MASK)


def _read_response_snapshot(controller: AsmediaXhciController, *, size: int) -> bytes:
    low = _cfg_read_u32(controller, DATA_READ0_OFFSET)
    high = _cfg_read_u32(controller, DATA_READ1_OFFSET)
    return (low.to_bytes(4, "little") + high.to_bytes(4, "little"))[:size]


def _read_response_bytes(controller: AsmediaXhciController, *, size: int) -> bytes:
    return _read_response_snapshot(controller, size=size)


def _ack_read_response(controller: AsmediaXhciController) -> None:
    _cfg_write_u8(controller, CONTROL_OFFSET, READ_READY_MASK)


def _drain_read_phase(controller: AsmediaXhciController) -> bytes:
    snapshot = _read_response_snapshot(controller, size=READ_CHUNK_SIZE)
    _ack_read_response(controller)
    return snapshot


def _wait_read_phase_reset(controller: AsmediaXhciController) -> None:
    try:
        _poll_control_clear(
            controller,
            mask=READ_READY_MASK,
            timeout=None,
            label="read-phase-reset",
            max_polls=READ_PHASE_RESET_POLLS,
        )
    except FlasherError:
        _trace("read-phase-reset not observed before second phase")


def _wait_read_ready(controller: AsmediaXhciController) -> None:
    _poll_control_set(
        controller,
        mask=READ_READY_MASK,
        timeout=None,
        label="read-ready",
        max_polls=WINDOWS_READ_READY_POLLS,
    )


def _wait_write_ready(controller: AsmediaXhciController, *, wait_units: int) -> None:
    _poll_control_clear(
        controller,
        mask=WRITE_READY_MASK,
        timeout=None,
        label="write-ready",
        max_polls=max(1, wait_units) * WINDOWS_READ_READY_POLLS,
    )


def _poll_control_clear(
    controller: AsmediaXhciController,
    *,
    mask: int,
    timeout: float | None,
    label: str,
    max_polls: int | None = None,
) -> None:
    deadline = None if timeout is None else time.monotonic() + timeout
    ff_reads = 0
    polls = 0
    last_value: int | None = None
    while True:
        value = _cfg_read_u8(controller, CONTROL_OFFSET)
        last_value = value
        if value == 0xFF:
            ff_reads += 1
            if ff_reads > MAX_FF_CONTROL_READS:
                raise FlasherError(
                    f"timed out waiting for SPI controller {label} state on {controller.info.bdf} "
                    f"(last-control=0x{value:02x}, ff-reads={ff_reads}, polls={polls})"
                )
            continue
        if not (value & mask):
            if not (_cfg_read_u8(controller, CONTROL_OFFSET) & mask):
                return
        polls += 1
        if max_polls is not None and polls >= max_polls:
            raise FlasherError(
                f"timed out waiting for SPI controller {label} state on {controller.info.bdf} "
                f"(last-control=0x{(last_value or 0):02x}, ff-reads={ff_reads}, polls={polls})"
            )
        if deadline is not None and time.monotonic() >= deadline:
            raise FlasherError(
                f"timed out waiting for SPI controller {label} state on {controller.info.bdf} "
                f"(last-control=0x{(last_value or 0):02x}, ff-reads={ff_reads}, polls={polls})"
            )


def _poll_control_set(
    controller: AsmediaXhciController,
    *,
    mask: int,
    timeout: float | None,
    label: str,
    max_polls: int | None = None,
) -> None:
    deadline = None if timeout is None else time.monotonic() + timeout
    ff_reads = 0
    polls = 0
    last_value: int | None = None
    while True:
        value = _cfg_read_u8(controller, CONTROL_OFFSET)
        last_value = value
        if value == 0xFF:
            ff_reads += 1
            if ff_reads > MAX_FF_CONTROL_READS:
                raise FlasherError(
                    f"timed out waiting for SPI controller {label} state on {controller.info.bdf} "
                    f"(last-control=0x{value:02x}, ff-reads={ff_reads}, polls={polls})"
                )
            continue
        if value & mask:
            if _cfg_read_u8(controller, CONTROL_OFFSET) & mask:
                return
        polls += 1
        if max_polls is not None and polls >= max_polls:
            raise FlasherError(
                f"timed out waiting for SPI controller {label} state on {controller.info.bdf} "
                f"(last-control=0x{(last_value or 0):02x}, ff-reads={ff_reads}, polls={polls})"
            )
        if deadline is not None and time.monotonic() >= deadline:
            raise FlasherError(
                f"timed out waiting for SPI controller {label} state on {controller.info.bdf} "
                f"(last-control=0x{(last_value or 0):02x}, ff-reads={ff_reads}, polls={polls})"
            )


def _round_up(value: int, multiple: int) -> int:
    if value % multiple == 0:
        return value
    return value + (multiple - (value % multiple))
