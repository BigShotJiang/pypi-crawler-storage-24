"""codemux — Structurally-aware code context engine for LLM coding agents."""

__version__ = "0.0.1"