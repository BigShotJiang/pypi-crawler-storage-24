# codemux

Structurally-aware code context engine for LLM coding agents. Under development.