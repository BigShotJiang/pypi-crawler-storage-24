"""Traefik service plugin."""
