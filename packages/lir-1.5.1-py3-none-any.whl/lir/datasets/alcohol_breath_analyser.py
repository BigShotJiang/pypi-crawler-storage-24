import numpy as np

from lir.data.models import DataProvider, LLRData


class AlcoholBreathAnalyser(DataProvider):
    """
    Alcohol Breath Analyser example class.

    Example from paper:
        Peter Vergeer, Andrew van Es, Arent de Jongh, Ivo Alberink and Reinoud
        Stoel, Numerical likelihood ratios outputted by LR systems are often
        based on extrapolation: When to stop extrapolating? In: Science and
        Justice 56 (2016) 482–491.

    Parameters
    ----------
    ill_calibrated : bool
        Whether to load the intentionally ill-calibrated variant of the dataset.
    """

    def __init__(self, ill_calibrated: bool = False):
        self.ill_calibrated = ill_calibrated

    def get_instances(self) -> LLRData:
        """
        Provide LLR data for example system.

        Returns
        -------
        LLRData
            Likelihood-ratio data produced by applying the LR system.
        """
        positive_lr = 1000 if self.ill_calibrated else 90
        lrs = np.concatenate(
            [
                np.full(990, 0.101),
                np.full(10, positive_lr),
                np.full(90, positive_lr),
                np.full(10, 0.101),
            ]
        )
        y = np.concatenate([np.zeros(1000), np.ones(100)])
        return LLRData(features=np.log10(lrs), labels=y)
