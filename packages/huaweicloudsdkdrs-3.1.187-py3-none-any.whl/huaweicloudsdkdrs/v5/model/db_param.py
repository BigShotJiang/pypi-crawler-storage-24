# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DbParam:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'key': 'str',
        'target_value': 'str'
    }

    attribute_map = {
        'key': 'key',
        'target_value': 'target_value'
    }

    def __init__(self, key=None, target_value=None):
        r"""DbParam

        The model defined in huaweicloud sdk

        :param key: 数据库参数名。 取值：binlog_cache_size，binlog_stmt_cache_size，bulk_insert_buffer_size，innodb_buffer_pool_size，key_buffer_size，long_query_time，query_cache_type，read_buffer_size，read_rnd_buffer_size，sort_buffer_size，sync_binlog，innodb_buffer_pool_instances
        :type key: str
        :param target_value: 目标数据库参数值。
        :type target_value: str
        """
        
        

        self._key = None
        self._target_value = None
        self.discriminator = None

        self.key = key
        self.target_value = target_value

    @property
    def key(self):
        r"""Gets the key of this DbParam.

        数据库参数名。 取值：binlog_cache_size，binlog_stmt_cache_size，bulk_insert_buffer_size，innodb_buffer_pool_size，key_buffer_size，long_query_time，query_cache_type，read_buffer_size，read_rnd_buffer_size，sort_buffer_size，sync_binlog，innodb_buffer_pool_instances

        :return: The key of this DbParam.
        :rtype: str
        """
        return self._key

    @key.setter
    def key(self, key):
        r"""Sets the key of this DbParam.

        数据库参数名。 取值：binlog_cache_size，binlog_stmt_cache_size，bulk_insert_buffer_size，innodb_buffer_pool_size，key_buffer_size，long_query_time，query_cache_type，read_buffer_size，read_rnd_buffer_size，sort_buffer_size，sync_binlog，innodb_buffer_pool_instances

        :param key: The key of this DbParam.
        :type key: str
        """
        self._key = key

    @property
    def target_value(self):
        r"""Gets the target_value of this DbParam.

        目标数据库参数值。

        :return: The target_value of this DbParam.
        :rtype: str
        """
        return self._target_value

    @target_value.setter
    def target_value(self, target_value):
        r"""Sets the target_value of this DbParam.

        目标数据库参数值。

        :param target_value: The target_value of this DbParam.
        :type target_value: str
        """
        self._target_value = target_value

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DbParam):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
