"""Gene class for representing genomic genes with associated transcripts"""
import copy
from typing import Any, Dict, List, Tuple, Optional, Iterator, Union
from collections import Counter
from pathlib import Path

from .config import get_organism_config, get_default_organism
from .utils import unload_pickle
from .transcript import Transcript


class Gene:
    """
    A class representing a Gene, with associated transcripts and metadata.

    Attributes:
        organism (str): The organism build (e.g. 'hg38').
        transcripts (dict): A dictionary of transcript annotations keyed by transcript ID.
        gene_name (str): The name of the gene.
        gene_id (str): The unique identifier for the gene.
        chrm (str): The chromosome on which the gene resides.
        rev (bool): Whether the gene is on the reverse strand.
    """

    def __init__(self, gene_name: str, gene_id: str, rev: bool, chrm: str, 
                 transcripts: Optional[Dict[str, Any]] = None, organism: Optional[str] = None):
        """
        Initialize a Gene instance.

        Args:
            gene_name: Name of the gene
            gene_id: Unique identifier for the gene
            rev: Whether gene is on reverse strand
            chrm: Chromosome identifier
            transcripts: Dictionary of transcript annotations
            organism: Organism reference build (default from config)
        """
        self.gene_name = gene_name
        self.gene_id = gene_id
        self.rev = rev
        self.chrm = chrm
        self.organism = organism if organism is not None else get_default_organism()
        self.transcripts = transcripts if transcripts is not None else {}

    def __repr__(self) -> str:
        """Official string representation of the Gene object."""
        return f"Gene({self.gene_name})"

    def __str__(self) -> str:
        """User-friendly string representation of the Gene object."""
        return f"Gene: {self.gene_name}, ID: {self.gene_id}, Chr: {self.chrm}, Transcripts: {len(self.transcripts)}"

    def __len__(self) -> int:
        """Returns the number of transcripts associated with this gene."""
        return len(self.transcripts)

    def __copy__(self):
        """Returns a shallow copy of the Gene object."""
        return copy.copy(self)

    def __deepcopy__(self, memo):
        """Returns a deep copy of the Gene object."""
        return copy.deepcopy(self, memo)

    def __iter__(self) -> Iterator[Transcript]:
        """Allow iteration over the gene's transcripts, yielding Transcript objects."""
        for tid, annotations in self.transcripts.items():
            yield Transcript(annotations, organism=self.organism)

    def __getitem__(self, item: str) -> Optional[Transcript]:
        """Get a transcript by ID."""
        if item not in self.transcripts:
            print(f"{item} not an annotated transcript of this gene.")
            return None
        return Transcript(self.transcripts[item], organism=self.organism)

    @classmethod
    def from_file(cls, gene_name: str, organism: Optional[str] = None) -> Optional['Gene']:
        """
        Load gene data from file.

        Load order: LMDB (if installed) → SQLite (genes.db) → per-gene pickle files.
        To use the DB, ensure genes.db exists in your organism data dir (run setup_genomics_data,
        or set SEQMAT_DATA_DIR to a path whose organism subdirs contain genes.db).

        Args:
            gene_name: Name of the gene to load
            organism: Organism reference build

        Returns:
            Gene object or None if not found
        """
        if organism is None:
            organism = get_default_organism()
        try:
            from .lmdb_store import load_gene_from_lmdb
            data = load_gene_from_lmdb(gene_name, organism)
            if data is not None:
                return cls(
                    gene_name=data.get('gene_name'),
                    gene_id=data.get('gene_id'),
                    rev=data.get('rev'),
                    chrm=data.get('chrm'),
                    transcripts=data.get('transcripts', {}),
                    organism=organism
                )
        except ImportError:
            pass
        try:
            from .sqlite_store import load_gene_from_sqlite
            data = load_gene_from_sqlite(gene_name, organism)
            if data is not None:
                return cls(
                    gene_name=data.get('gene_name'),
                    gene_id=data.get('gene_id'),
                    rev=data.get('rev'),
                    chrm=data.get('chrm'),
                    transcripts=data.get('transcripts', {}),
                    organism=organism
                )
        except ImportError:
            pass
        try:
            config = get_organism_config(organism)
        except ValueError:
            print(f"Organism '{organism}' not configured. Run setup_genomics_data() first.")
            return None
        mrna_path = Path(config["MRNA_PATH"])
        gene_files = []
        if mrna_path.exists():
            for biotype_dir in mrna_path.iterdir():
                if biotype_dir.is_dir():
                    gene_files.extend(biotype_dir.glob(f"*_{gene_name}.pkl"))
        if not gene_files:
            print(f"No files available for gene '{gene_name}'.")
            return None
        data = unload_pickle(gene_files[0])
        
        return cls(
            gene_name=data.get('gene_name'),
            gene_id=data.get('gene_id'),
            rev=data.get('rev'),
            chrm=data.get('chrm'),
            transcripts=data.get('transcripts', {}),
            organism=organism
        )

    def splice_sites(self) -> Tuple[Counter, Counter]:
        """Return (Counter of acceptors, Counter of donors) across all transcripts."""
        acceptors: List[Any] = []
        donors: List[Any] = []
        for transcript in self.transcripts.values():
            acceptors.extend(transcript.get('acceptors', []))
            donors.extend(transcript.get('donors', []))

        return Counter(acceptors), Counter(donors)

    def transcript(self, tid: Optional[str] = None) -> Optional[Transcript]:
        """Return Transcript by ID, or primary transcript if tid is None."""
        if tid is None:
            tid = self.primary_transcript
            
        if tid is None or tid not in self.transcripts:
            return None

        return Transcript(self.transcripts[tid], organism=self.organism)

    @property
    def primary_transcript(self) -> Optional[str]:
        """Primary transcript ID, or first protein-coding transcript, or None."""
        if hasattr(self, "_primary_transcript"):
            return self._primary_transcript
        primary = [k for k, v in self.transcripts.items() if v.get("primary_transcript")]
        if primary:
            self._primary_transcript = primary[0]
            return self._primary_transcript
        protein_coding = [k for k, v in self.transcripts.items()
                         if v.get("transcript_biotype") == "protein_coding"]
        if protein_coding:
            self._primary_transcript = protein_coding[0]
            return self._primary_transcript
        self._primary_transcript = None
        return None