from epypack.version import compute_version, main_package_version, package_version

__version__ = compute_version("python")
version = package_version("scp-app-sdk")
main_version = main_package_version("scp-app-sdk")
