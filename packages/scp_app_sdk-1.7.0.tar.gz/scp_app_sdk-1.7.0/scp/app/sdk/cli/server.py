from urllib.parse import urlparse

import click
import requests
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)  # to remove when going to production


def _server_reachable(server: str, token: str | None = None) -> bool:
    headers = {}
    if token:
        headers["Authorization"] = f"Bearer {token}" if "Bearer" not in token else token

    try:
        r = requests.get(f"{server}/api/v1/version", headers=headers, verify=False, timeout=5)  # noqa: S501 why are we disabling ssl?
    except Exception as e:
        print(f"Error connecting to server {server}: {e}")
        return False

    return r.status_code == 200


def scp_app_center_server(server: str | None = None, token: str | None = None) -> str | None:
    if not server:
        click.echo("⚠️  No server provided.")
        return None

    parsed = urlparse(server)

    if not parsed.scheme:
        server = "https://" + server
        parsed = urlparse(server)

    netloc = parsed.netloc if parsed.netloc else parsed.path
    server = f"https://{netloc}"

    server = server.rstrip("/")

    if not _server_reachable(server, token):
        click.echo(f"⚠️  Server {server} is not reachable, url or token invalid please try again.")
        return None

    return server
