import configparser
import os

import click

from scp.app.sdk.cli.config import default_sam_server, default_scp_server
from scp.app.sdk.cli.server import scp_app_center_server
from scp.app.sdk.cli.utils import confirm_with_help


class SCPConfig:
    """Manages SCP App configuration stored in ~/.scp-app-config"""

    DEFAULTS = {"scp_server": default_scp_server, "sam_server": default_sam_server, "token": ""}

    def __init__(self):
        self.config_path = os.path.expanduser("~/.scp-app-config")
        self.config_dir = os.path.dirname(self.config_path)
        self.config = configparser.ConfigParser()

        os.makedirs(self.config_dir, exist_ok=True)

        if not os.path.exists(self.config_path):
            self.config["DEFAULT"] = self.DEFAULTS
            self.save()
        else:
            self.config.read(self.config_path)

    def get(self, key):
        return self.config["DEFAULT"].get(key, "")

    def set(self, key, value):
        self.config["DEFAULT"][key] = value
        self.save()

    def save(self):
        with open(self.config_path, "w") as f:
            self.config.write(f)

    def check_servers(self, check_scp=True, check_sam=True):
        click.echo("⌛ Testing server connections...")
        scp_server = self.get("scp_server")
        sam_server = self.get("sam_server")
        token = self.get("token")

        if "scp-app-center." not in scp_server:
            click.secho("❌ SCP server should be the scp-app-center url", fg="red")
            return False

        if "sam." not in sam_server:
            click.secho("❌ SAM server should be the sam url", fg="red")
            return False

        if check_scp and not scp_app_center_server(scp_server, token):
            click.secho("❌ SCP App Center server unreachable", fg="red")
            return False

        if check_sam and not scp_app_center_server(sam_server, token):
            click.secho("❌ SAM server unreachable", fg="red")
            return False

        return True

    def prompt_and_set(self, key, label, is_url):
        if confirm_with_help(
            f"👉 Do you want to edit {label} ?",
            help_text=(
                "   • This will override the current configuration.\n"
                "   • You'll be able to configure the App Center server, SAM server and the jwt token.\n"
                "   • The App Center server is used to store applications you create.\n"
                "   • The SAM server is used to configure applications on the user(s).\n"
                "   • 💡 You can find your jwt token at  https://doc.chefhub.smartflowagent.net/Tour/telephony-hello-world.\n"
            ),
            default=False,
        ):
            value = click.prompt(f"👉 Enter your {label}", type=str)
            if is_url:
                self.set(key, value.rstrip("/"))
            else:
                self.set(key, value)
            click.secho(f"✅ {label} saved successfully!", fg="green")

    def prompt_for_config(self, prompt_scp=True, prompt_sam=True):
        token = click.prompt("👉 Enter your JWT token", type=str, hide_input=True)
        self.set("token", token)

        if prompt_scp:
            self.prompt_and_set("scp_server", "SCP App Center server", is_url=True)
        if prompt_sam:
            self.prompt_and_set("sam_server", "SAM server", is_url=True)

        for _ in range(3):
            if self.check_servers(check_scp=prompt_scp, check_sam=prompt_sam):
                click.secho("\n✅ Configuration saved successfully!", fg="green", bold=True)
                return
            click.echo("\n❌ Invalid configuration. Please try again.\n")
            self.prompt_for_config(prompt_scp, prompt_sam)

        raise click.ClickException("Configuration failed after multiple attempts.")
