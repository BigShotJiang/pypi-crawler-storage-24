from pathlib import Path

from pathspec import PathSpec
from pathspec.patterns import GitWildMatchPattern

# Add any patterns that should always be ignored by default even if .appignore is not present
# Developers cannot override these patterns, they are always ignored
IGNORED_PATTERNS = [
    ".git/",
    "build/",
    ".idea/",
    ".vscode/",
    "venv/",
    ".venv/",
    "__pycache__/",
]


def load_appignore(root: Path) -> PathSpec:
    ignore_file = root / ".appignore"
    patterns = []
    if ignore_file.exists():
        patterns = ignore_file.read_text().splitlines()
    patterns += IGNORED_PATTERNS.copy()
    return PathSpec.from_lines(GitWildMatchPattern, patterns)


def should_include(path: Path, spec: PathSpec, root: Path) -> bool:
    rel = path.relative_to(root).as_posix()
    return not spec.match_file(rel)
