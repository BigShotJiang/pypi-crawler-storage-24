import json
import os

UI_PLUGINS_PATH = "install/ui-plugins.json"


def get_ui_plugins(directory: str) -> list[dict]:
    """
    Get UI plugins from the app manifest and load their configurations
    :param directory: Directory path of where the app/build is located
    :return: List of UI plugin configurations
    """
    plugin_path = os.path.join(directory, UI_PLUGINS_PATH)

    if not os.path.exists(plugin_path):
        print(f"[DEBUG] UI plugins file not found at: {plugin_path}")  # noqa: T201
        return []

    try:
        with open(plugin_path) as f:
            plugins = json.load(f)
            print(f"[DEBUG] Loaded UI plugins: {plugins}")  # noqa: T201
            return plugins
    except Exception as e:
        print(f"[ERROR] Failed to load UI plugins file {plugin_path}: {str(e)}")  # noqa: T201
        return []
