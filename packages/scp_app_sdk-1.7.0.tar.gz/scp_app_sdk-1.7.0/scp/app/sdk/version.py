import subprocess
import time
from typing import Final


class AppVersionException(Exception):
    pass


def app_version(version: str) -> str:
    git_fatal_error: Final = 128

    tags = subprocess.run(["git", "describe", "--tags", "--exact-match"], check=False, capture_output=True, text=True)  # noqa: S607
    if tags.returncode == git_fatal_error:
        current_time = int(time.time())
        return version + f".dev{current_time}"

    git_tag = subprocess.run(["git", "describe", "--tags", "--abbrev=0"], check=False, capture_output=True, text=True)  # noqa: S607
    if git_tag.returncode != git_fatal_error:
        git_version = git_tag.stdout.strip()
        if git_version != version:
            raise AppVersionException(f"The APP version '{version}' doesn't match the git version '{git_version}'")
    return version
