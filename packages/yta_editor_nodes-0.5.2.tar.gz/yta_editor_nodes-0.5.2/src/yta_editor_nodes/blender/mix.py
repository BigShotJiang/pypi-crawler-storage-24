from yta_editor_nodes.blender.base import _Blender
from yta_editor_parameters.specifications import ParameterSpecification
from typing import Union


class MixBlender(_Blender):
    """
    A blender that uses a float value to mix the
    result with the original input as much as that
    value determines.

    Mandatory inputs:
    - `base_input`
    - `overlay_input`

    Optional inputs:
    - `None`

    Parameters:
    - `*mix_weight`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input', 'overlay_input']
    optional_inputs = []
    parameters_specifications = [
        ParameterSpecification(
            name = 'mix_weight',
            type = float,
            is_required = True,
            default = 1.0,
            min = 0.01,
            max = 1.0
        )
    ]

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_blenders(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU blenders and return 
        them in that order.

        This method has been created to be used in both the
        '__init__' and the '__reinit__' methods.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_cpu.blender.mix import MixBlenderCPU
        from yta_editor_nodes_gpu.blender.mix import MixBlenderGPU

        node_cpu = MixBlenderCPU()
        node_gpu = MixBlenderGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu