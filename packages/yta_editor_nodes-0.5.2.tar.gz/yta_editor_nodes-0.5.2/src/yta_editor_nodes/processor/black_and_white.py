from yta_editor_nodes.processor.base import _NodeProcessor
from typing import Union


class BlackAndWhiteNodeProcessor(_NodeProcessor):
    """
    The node to modify the input provided and set
    it as black and white by using CPU or GPU.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`
    
    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = []

    def __init__(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        super().__init__(
            opengl_context = opengl_context
        )

    def _instantiate_cpu_and_gpu_processors(
        self,
        opengl_context: Union['moderngl.Context', None]
    ):
        """
        *For internal use only*

        Instantiate the CPU and GPU procesors and return 
        them in that order.

        This method must be implemented by each class.
        """
        from yta_editor_nodes_cpu.processor.black_and_white import BlackAndWhiteNodeProcessorCPU
        from yta_editor_nodes_gpu.processor.black_and_white import BlackAndWhiteNodeProcessorGPU

        node_cpu = BlackAndWhiteNodeProcessorCPU()
        node_gpu = BlackAndWhiteNodeProcessorGPU(
            opengl_context = opengl_context
        )

        return node_cpu, node_gpu