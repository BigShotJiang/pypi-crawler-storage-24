from yta_editor_nodes.processor.base import _NodeProcessor
from abc import ABC


# TODO: ABC, do we need it (?)
class _VideoNodeProcessor(_NodeProcessor, ABC):
    """
    *For internal use only*
    
    *Abstract class*

    This class must be inherited by the specific
    implementation of some effect that will be done by
    CPU or GPU (at least one of the options).

    Class that is capable of doing some processing on
    an input by using the GPU or the CPU, but for 
    video frames, including a `t` time moment parameter
    when processing.

    Mandatory inputs:
    - `base_input`

    Optional inputs:
    - `None`

    Parameters:
    - `None`

    The parameters above are the accepted by this
    node, where `*` means that the parameter is
    mandatory.
    """

    mandatory_inputs = ['base_input']
    optional_inputs = []
    parameters_specifications = []