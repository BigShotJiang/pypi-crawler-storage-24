# src/core/request.py
# version: 1.2.0
# Author: Theodore Tasman
# Creation Date: 2025-09-25
# Last Modified: 2026-03-21
# Organization: PSU UAS

from __future__ import annotations
from typing import Self
from pydantic import BaseModel
from lingo import Message

class BaseHeader(BaseModel):
    """
    A class representing a task request.
    """

    @classmethod
    def from_json(cls, json_data: str) -> Self:
        """Create a Request instance from a JSON string."""
        return cls.model_validate_json(json_data)

    @classmethod
    def from_dict(cls, data: dict) -> Self:
        """Create a Request instance from a dictionary."""
        return cls.model_validate(data)

    def to_dict(self) -> dict:
        """Convert the Request instance to a dictionary."""
        return self.model_dump()

    def to_json(self) -> str:
        """Convert the Request instance to a JSON string."""
        return self.model_dump_json()
    
    def to_message(self, topic: str, payload: bytes = b"") -> Message:
        """Convert the Request instance to a UAS Message

        Args:
            topic (str): Message topic
            payload (bytes, optional): Message byte payload. Defaults to b"".

        Returns:
            Message: Lingo Message object
        """
        return Message(
            topic=topic,
            header=self.to_dict(),
            payload=payload
        )