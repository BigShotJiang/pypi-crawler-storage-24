# src/lingo/headers/image.py
# version: 1.0.0
# Original Author: Theodore Tasman
# Creation Date: 2025-03-01
# Last Modified: 2026-03-20
# Organization: PSU UAS

from lingo.base_header import BaseHeader

class Image(BaseHeader):
    seq: int
    timestamp_ms: int # in milliseconds
    latitude_degE7: int # in degrees E7
    longitude_degE7: int # in degrees E7
    altitude_mm: int # in millimeters, MSL
    heading_cdeg: int # in centidegrees
