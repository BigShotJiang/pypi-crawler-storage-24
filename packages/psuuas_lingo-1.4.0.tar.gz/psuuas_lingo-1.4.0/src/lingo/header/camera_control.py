# src/lingo/headers/camera_control.py
# version: 1.0.0
# Original Author: Theodore Tasman
# Creation Date: 2026-03-20
# Last Modified: 2026-03-20
# Organization: PSU UAS

from lingo.base_header import BaseHeader

class CameraControl(BaseHeader):
    capture: bool
