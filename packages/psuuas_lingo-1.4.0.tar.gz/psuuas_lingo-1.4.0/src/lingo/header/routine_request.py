# src/core/request.py
# version: 1.0.0
# Author: Theodore Tasman
# Creation Date: 2025-09-25
# Last Modified: 2025-10-01
# Organization: PSU UAS

from __future__ import annotations
from typing import Any, List
from pydantic import Field
from lingo.base_header import BaseHeader

class RoutineRequest(BaseHeader):
    """
    A class representing a task request.
    """

    request_id: int
    routine: str
    priority: int = Field(default=0)
    params: List[Any] = Field(default_factory=list)