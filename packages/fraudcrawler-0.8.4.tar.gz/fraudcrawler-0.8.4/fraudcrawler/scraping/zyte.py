from base64 import b64decode
import logging
from typing import List

from bs4 import BeautifulSoup
import httpx
from tenacity import RetryCallState

from fraudcrawler.settings import ZYTE_DEFALUT_PROBABILITY_THRESHOLD, REDIS_USE_CACHE
from fraudcrawler.base.base import DomainUtils, ProductItem
from fraudcrawler.base.retry import get_async_retry
from fraudcrawler.cache.cacher import RedisCacher
from fraudcrawler.scraping.saved_search_models import (
    SavedSearchRenderedNetworkCapture,
    SavedSearchRenderedPageResult,
    SavedSearchRenderedProductListItem,
)

logger = logging.getLogger(__name__)


class ZyteAPI(RedisCacher, DomainUtils):
    """A client to interact with the Zyte API for fetching product details."""

    _endpoint = "https://api.zyte.com/v1/extract"
    _config = {
        "javascript": False,
        "browserHtml": False,
        "screenshot": False,
        "productOptions": {"extractFrom": "httpResponseBody"},
        "httpResponseBody": True,
        "geolocation": "CH",
        "viewport": {"width": 1280, "height": 1080},
        "product": True,
        # "actions": [],
    }

    def __init__(
        self,
        http_client: httpx.AsyncClient,
        api_key: str,
        redis_use_cache: bool = REDIS_USE_CACHE,
    ):
        """Initializes the ZyteApiClient with the given API key and retry configurations.

        Args:
            http_client: An httpx.AsyncClient to use for the async requests.
            api_key: The API key for Zyte API.
            redis_use_cache: Whether to use caching by a redis instance or not.
        """
        super().__init__(use_cache=redis_use_cache)

        self._http_client = http_client
        self._api_key = api_key

    def _log_before(self, url: str, retry_state: RetryCallState | None) -> None:
        """Context aware logging before the request is made."""
        if retry_state:
            logger.debug(
                f"Zyte fetching product details for URL {url} (Attempt {retry_state.attempt_number})."
            )
        else:
            logger.debug(f"retry_state is {retry_state}; not logging before.")

    def _log_before_sleep(self, url: str, retry_state: RetryCallState | None) -> None:
        """Context aware logging before sleeping after a failed request."""
        if retry_state and retry_state.outcome:
            logger.warning(
                f'Attempt {retry_state.attempt_number} of Zyte fetching product details for URL "{url}" '
                f"Retrying in {retry_state.upcoming_sleep:.0f} seconds."
            )
        else:
            logger.debug(f"retry_state is {retry_state}; not logging before_sleep.")

    @staticmethod
    def _extract_product_name(details: dict) -> str | None:
        """Extracts the product name from the product data.

        The input argument is a dictionary of the following structure:
            {
                "product": {
                    "name": str,
                }
            }
        """
        return details.get("product", {}).get("name")

    @staticmethod
    def _extract_url_resolved(details: dict) -> str | None:
        """Extracts the resolved URL from the product data - this is automatically resolved by Zyte.

        The input argument is a dictionary of the following structure:
            {
                "product": {
                    "url": str,
                }
            }
        """
        return details.get("product", {}).get("url")

    @staticmethod
    def _extract_product_price(details: dict) -> str | None:
        """Extracts the product price from the product data.

        The input argument is a dictionary of the following structure:
            {
                "product": {
                    "price": str,
                }
            }
        """
        return details.get("product", {}).get("price")

    @staticmethod
    def _extract_product_description(details: dict) -> str | None:
        """Extracts the product description from the product data.

        The input argument is a dictionary of the following structure:
            {
                "product": {
                    "description": str,
                }
            }
        """
        return details.get("product", {}).get("description")

    @staticmethod
    def _extract_image_urls(details: dict) -> List[str]:
        """Extracts the images from the product data.

        The input argument is a dictionary of the following structure:
            {
                "product": {
                    "mainImage": {"url": str},
                    "images": [{"url": str}],
                }
            }
        """
        images = []
        product = details.get("product")
        if product:
            # Extract main image URL
            if (main_img := product.get("mainImage")) and (url := main_img.get("url")):
                images.append(url)
            # Extract additional image URLs
            if urls := product.get("images"):
                images.extend([img["url"] for img in urls if img.get("url")])
        return images

    @staticmethod
    def _extract_gtin(details: dict) -> str | None:
        """Extracts the GTIN from the product data.

        The input argument is a dictionary of the following structure:
            {
                "product": {
                    "gtin": [{"type": str, "value": str}],
                }
            }
        """
        product = details.get("product", {})
        gtin_list = product.get("gtin", [])

        if len(gtin_list) > 0:
            # Extract the first GTIN value
            gtin_value = gtin_list[0].get("value")
            if gtin_value:
                return gtin_value
        return None

    @staticmethod
    def _extract_probability(details: dict) -> float:
        """Extracts the probability from the product data.

        The input argument is a dictionary of the following structure:
            {
                "product": {
                    "metadata": {
                        "probability": float,
                    }
                }
            }
        """
        return float(
            details.get("product", {}).get("metadata", {}).get("probability", 0.0)
        )

    @staticmethod
    def _extract_html(details: dict) -> str | None:
        """Extracts the HTML from the Zyte API response.

        The input argument is a dictionary of the following structure:
            {
                "httpResponseBody": base64
            }
        """
        # Get the Base64-encoded content
        encoded = details.get("httpResponseBody")

        # Decode it into bytes
        if isinstance(encoded, str):
            decoded_bytes = b64decode(encoded)

            # Convert bytes to string
            try:
                decoded_string = decoded_bytes.decode("utf-8")
            except UnicodeDecodeError:
                decoded_string = decoded_bytes.decode("iso-8859-1")
            return decoded_string
        return None

    def enrich_context(self, product: ProductItem, details: dict) -> ProductItem:
        product.product_name = self._extract_product_name(details=details)

        url_resolved = self._extract_url_resolved(details=details)
        if url_resolved:
            product.url_resolved = url_resolved

        # If the resolved URL is different from the original URL, we also need to update the domain as
        # otherwise the unresolved domain will be shown.
        # For example for an unresolved domain "toppreise.ch" but resolved "digitec.ch
        if url_resolved and url_resolved != product.url:
            logger.debug(f"URL resolved for {product.url} is {url_resolved}")
            product.domain = self._get_domain(url=url_resolved)

        product.product_price = self._extract_product_price(details=details)
        product.product_description = self._extract_product_description(details=details)
        product.product_images = self._extract_image_urls(details=details)
        product.product_gtin = self._extract_gtin(details=details)
        product.probability = self._extract_probability(details=details)
        product.html = self._extract_html(details=details)
        if product.html:
            soup = BeautifulSoup(product.html, "html.parser")
            product.html_clean = soup.get_text(separator=" ", strip=True)

        return product

    @staticmethod
    def keep_product(
        details: dict,
        threshold: float = ZYTE_DEFALUT_PROBABILITY_THRESHOLD,
    ) -> bool:
        """Determines whether to keep the product based on the probability threshold.

        Args:
            details: A product details data dictionary.
            threshold: The probability threshold used to filter the products.
        """
        try:
            prob = float(details["product"]["metadata"]["probability"])
        except KeyError:
            logger.warning(
                f"Product with url={details.get('url')} has no probability value - product is ignored"
            )
            return False
        return prob > threshold

    async def unblock_url_content(self, url: str) -> bytes:
        """Unblock the content of an URL using Zyte proxy mode.

        Args:
            url: The URL to fetch using Zyte proxy mode.
        """
        logger.debug(f'Unblock URL content using Zyte proxy for url="{url}"')
        details = await self.capply(url)

        if not details or "httpResponseBody" not in details:
            raise httpx.HTTPError("No httpResponseBody in Zyte response")

        return b64decode(details["httpResponseBody"])

    async def apply(self, url: str) -> dict:
        """Fetches product details for a single URL (cacheable via capply)."""
        logger.info(f"Fetching product details by Zyte for URL {url}.")

        # Perform the request and retry if necessary. There is some context aware logging:
        #  - `before`: before the request is made (and before retrying)
        #  - `before_sleep`: if the request fails before sleeping
        retry = get_async_retry()
        retry.before = lambda retry_state: self._log_before(
            url=url, retry_state=retry_state
        )
        retry.before_sleep = lambda retry_state: self._log_before_sleep(
            url=url, retry_state=retry_state
        )
        async for attempt in retry:
            with attempt:
                response = await self._http_client.post(
                    url=self._endpoint,
                    json={"url": url, **self._config},
                    auth=(self._api_key, ""),  # API key as username, empty password
                )
                response.raise_for_status()

        return response.json()

    @staticmethod
    def _as_trimmed_string(value) -> str | None:
        if not isinstance(value, str):
            return None
        value = value.strip()
        return value or None

    @classmethod
    def _normalize_network_captures(
        cls, payload: dict
    ) -> List[SavedSearchRenderedNetworkCapture]:
        raw_entries = payload.get("networkCapture")
        if not isinstance(raw_entries, list):
            return []
        normalized: List[SavedSearchRenderedNetworkCapture] = []
        for entry in raw_entries:
            if not isinstance(entry, dict):
                continue
            headers = entry.get("responseHeaders", {})
            headers = headers if isinstance(headers, dict) else {}
            body = (
                entry.get("httpResponseBody")
                or entry.get("responseBody")
                or entry.get("body")
            )
            body_text = body if isinstance(body, str) else None
            if body_text is None and isinstance(body, dict):
                body_text = str(body)
            capture = SavedSearchRenderedNetworkCapture(
                url=cls._as_trimmed_string(entry.get("url"))
                or cls._as_trimmed_string(entry.get("requestUrl")),
                statusCode=entry.get("statusCode")
                if isinstance(entry.get("statusCode"), int)
                else None,
                contentType=cls._as_trimmed_string(entry.get("contentType"))
                or cls._as_trimmed_string(headers.get("content-type"))
                or cls._as_trimmed_string(headers.get("Content-Type")),
                bodyText=body_text,
            )
            if capture.url or capture.body_text:
                normalized.append(capture)
        return normalized

    @classmethod
    def _normalize_product_list_items(
        cls, payload: dict
    ) -> List[SavedSearchRenderedProductListItem]:
        product_list = payload.get("productList")
        if isinstance(product_list, list):
            raw_items = product_list
        elif isinstance(product_list, dict):
            raw_items = product_list.get("products") or product_list.get("items") or []
        else:
            raw_items = []
        if not isinstance(raw_items, list):
            return []
        normalized: List[SavedSearchRenderedProductListItem] = []
        for item in raw_items:
            if not isinstance(item, dict):
                continue
            raw_images = item.get("images")
            images = raw_images if isinstance(raw_images, list) else []
            cleaned_images = [
                img.strip() for img in images if isinstance(img, str) and img.strip()
            ]
            normalized.append(
                SavedSearchRenderedProductListItem(
                    url=cls._as_trimmed_string(item.get("url"))
                    or cls._as_trimmed_string(item.get("href"))
                    or cls._as_trimmed_string(item.get("relativeUrl")),
                    name=cls._as_trimmed_string(item.get("name"))
                    or cls._as_trimmed_string(item.get("title")),
                    price=item.get("price")
                    if isinstance(item.get("price"), (str, float, int))
                    else None,
                    currency=cls._as_trimmed_string(item.get("currency")),
                    currencyRaw=cls._as_trimmed_string(item.get("currencyRaw")),
                    description=cls._as_trimmed_string(item.get("description")),
                    mainImage=cls._as_trimmed_string(item.get("mainImage")),
                    images=cleaned_images,
                )
            )
        return normalized

    async def fetch_rendered_page(
        self,
        url: str,
        provider: str | None = None,
        javascript: bool | None = None,
        include_iframes: bool | None = None,
        actions: List[dict] | None = None,
        network_capture: List[dict] | None = None,
        request_headers: dict | None = None,
    ) -> SavedSearchRenderedPageResult:
        _ = provider  # compatibility with generic render_fetcher signature
        payload = {
            "url": url,
            "browserHtml": True,
            "productList": True,
            "productListOptions": {"extractFrom": "browserHtml"},
            "networkCapture": network_capture or [],
            "javascript": javascript,
            "includeIframes": include_iframes,
            "actions": actions or [],
            "requestHeaders": request_headers or {},
        }
        response = await self._http_client.post(
            url=self._endpoint,
            json=payload,
            auth=(self._api_key, ""),
        )
        response.raise_for_status()
        data = response.json()
        html = data.get("browserHtml")
        if not isinstance(html, str) or not html.strip():
            raise httpx.HTTPError("Zyte rendered response has empty browserHtml")
        action_statuses = []
        for item in (
            data.get("actions", []) if isinstance(data.get("actions"), list) else []
        ):
            if not isinstance(item, dict):
                continue
            action = self._as_trimmed_string(item.get("action"))
            status = self._as_trimmed_string(item.get("status"))
            if action and status:
                action_statuses.append(f"{action}:{status}")

        return SavedSearchRenderedPageResult(
            html=html.strip(),
            provider="zyte",
            statusCode=data.get("statusCode")
            if isinstance(data.get("statusCode"), int)
            else response.status_code,
            elapsedMs=0,
            actionStatuses=action_statuses,
            actionError=next(
                (
                    self._as_trimmed_string(entry.get("error"))
                    for entry in data.get("actions", [])
                    if isinstance(entry, dict)
                    and self._as_trimmed_string(entry.get("error"))
                ),
                None,
            ),
            networkCaptureCount=len(self._normalize_network_captures(data)),
            networkCaptures=self._normalize_network_captures(data),
            productListItems=self._normalize_product_list_items(data),
        )
