# aisip-runtime

AISIP Runtime — AI Structured Instruction Protocol runtime

- Protocol: https://aisip.dev
- License: MIT
