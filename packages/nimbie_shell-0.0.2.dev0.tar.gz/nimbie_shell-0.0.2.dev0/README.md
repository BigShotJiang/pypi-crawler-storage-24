# nimbie

`nimbie` is a terminal-first coding assistant shell.

This repository now contains two main parts:

- `nimbie` (root package): REPL/UI, command tools, shell execution flow, session UX
- `oturn` (sub-package): standalone async orchestration/runtime core for agent turns

## Repository Layout

- `src/nimbie`: CLI app and terminal UI
- `oturn/src/oturn`: reusable orchestration package
- `chron`: chronml package used for message/config templating
- `flash`: shell runtime bridge and executor components

## Requirements

- Python `>=3.10`
- `uv` (recommended)

## Install (Root CLI)

```bash
uv sync
uv pip install -e .
```

Run:

```bash
nimbie --help
uv run nimbie --help
```

## Install (`oturn` only)

If you only want the orchestration package:

```bash
cd oturn
uv sync
uv pip install -e .
```

## Build

Root package:

```bash
uv build
```

`oturn` package:

```bash
cd oturn
uv build
```

## Config

The CLI loads config from (first match wins by runtime path logic):

- `~/.nimbie/config.py`
- `~/.nimbie/config.json`
- `~/.openclaw/openclaw.json`
- `.nimbie_config.py`
- `.nimbie_config.json`

## Session and History

- Session artifacts are stored under `.nimbie/` in the workspace/global locations used by CLI.
- The UI supports continue/list/export workflows via CLI flags and REPL commands.

## Notes

- Flash runtime is expected for shell parsing/execution flow.
- `oturn` does not use global auto tool registry; tools are injected explicitly at runtime.
