from __future__ import annotations

import asyncio
import json
import os
import random
import socket
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, AsyncGenerator, Dict, List, Optional

import httpx
from fastapi import FastAPI, HTTPException, Query, Request, WebSocket
from fastapi.responses import JSONResponse, Response, StreamingResponse
from prompt_toolkit.completion import CompleteEvent, Completer, Completion, PathCompleter, WordCompleter
from prompt_toolkit.document import Document
from prompt_toolkit.formatted_text import to_formatted_text
from prompt_toolkit.formatted_text.utils import fragment_list_to_text
from pydantic import BaseModel


def _pick_free_port(start: int, end: int) -> int:
    ports = list(range(start, end + 1))
    random.shuffle(ports)
    for port in ports:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                sock.bind(("127.0.0.1", port))
            except OSError:
                continue
            return port
    raise RuntimeError(f"No free port in range {start}-{end}")


class SubmitCommandRequest(BaseModel):
    text: str
    status: str = "agent"
    input_type: str = "default"


class ShellAutoRequest(BaseModel):
    text: str


class ShellRunRequest(BaseModel):
    cmd: str
    fold: bool = True
    each: int = 2048


class ShellAutoResponse(BaseModel):
    should_run: bool
    reason: Optional[str] = None


class ShellRunResponse(BaseModel):
    retcode: int
    stdout: str
    stderr: str


class ContextResponse(BaseModel):
    markdown: str
    raw: List[dict]


class ResolveFutureRequest(BaseModel):
    future_id: str
    payload: dict


class DebugStateResponse(BaseModel):
    waiting_input: bool
    pending_inputs: int
    agent_running: bool


class CompleteRequest(BaseModel):
    text: str
    cursor: int
    cwd: Optional[str] = None
    max_items: int = 50


class CompletionItem(BaseModel):
    text: str
    start_position: int
    display: str
    display_meta: str = ""


class CompleteResponse(BaseModel):
    items: List[CompletionItem]


class InputQueueEnqueueRequest(BaseModel):
    text: str
    status: str = "agent"
    input_type: str = "default"


def _formatted_to_text(value: Any) -> str:
    try:
        return fragment_list_to_text(to_formatted_text(value))
    except Exception:
        return str(value) if value is not None else ""


def _build_hidden_filter(include_hidden: bool):
    def _allow(path_str: str) -> bool:
        if include_hidden:
            return True
        return not Path(path_str).name.startswith(".")

    return _allow


class ShellCompleter(Completer):
    def __init__(self, commands: List[str], include_hidden: bool = False):
        self._command_names = commands
        self._command_completer = WordCompleter(commands, ignore_case=True, sentence=True)
        self._include_hidden = include_hidden

    def _is_command_position(self, text: str, cursor: int) -> bool:
        before = text[:cursor]
        return " " not in before and "\t" not in before

    def get_completions(self, document: Document, complete_event: CompleteEvent):
        if self._is_command_position(document.text, document.cursor_position):
            yield from self._command_completer.get_completions(document, complete_event)
            return
        cwd = getattr(document, "custom_cwd", None)
        path_completer = PathCompleter(
            expanduser=True,
            get_paths=(lambda: [cwd]) if cwd else lambda: ["."],
            file_filter=_build_hidden_filter(self._include_hidden),
        )
        yield from path_completer.get_completions(document, complete_event)


DEFAULT_COMMANDS = [
    "cd",
    "ls",
    "pwd",
    "cat",
    "echo",
    "grep",
    "find",
    "git",
    "python",
    "pip",
    "uv",
    "node",
    "npm",
    "docker",
    "kubectl",
    "ssh",
    "curl",
    "wget",
    "make",
    "bash",
    "zsh",
]
COMPLETER = ShellCompleter(DEFAULT_COMMANDS, include_hidden=False)


@dataclass
class _Subscriber:
    queue: asyncio.Queue


class WebEventBroadcaster:
    def __init__(self) -> None:
        self._subscribers: List[_Subscriber] = []
        self._lock = threading.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._loop = loop

    def subscribe(self) -> _Subscriber:
        sub = _Subscriber(queue=asyncio.Queue(maxsize=256))
        with self._lock:
            self._subscribers.append(sub)
        return sub

    def unsubscribe(self, sub: _Subscriber) -> None:
        with self._lock:
            if sub in self._subscribers:
                self._subscribers.remove(sub)

    def publish(self, payload: dict) -> None:
        if self._loop is None:
            return
        with self._lock:
            subscribers = list(self._subscribers)
        for sub in subscribers:
            self._loop.call_soon_threadsafe(self._safe_put, sub.queue, payload)

    @staticmethod
    def _safe_put(queue: asyncio.Queue, payload: dict) -> None:
        try:
            queue.put_nowait(payload)
        except asyncio.QueueFull:
            pass


class BrowserGatewayServer:
    def __init__(self, repl: Any, work_dir: Path, token: Optional[str] = None) -> None:
        self.repl = repl
        self.work_dir = work_dir
        self._repo_root = Path(__file__).resolve().parents[2]
        self._frontend_root = self._repo_root / "frontend-app"
        self.token = token or os.environ.get("NIMBIE_WEB_TOKEN") or f"t_{random.randint(100000, 999999)}"
        self.port = _pick_free_port(8413, 8419)
        self.vite_port = _pick_free_port(5173, 5183)
        self._app = FastAPI()
        self._server_thread: Optional[threading.Thread] = None
        self._server: Any = None
        self._server_loop: Optional[asyncio.AbstractEventLoop] = None
        self._vite_proc: Optional[subprocess.Popen] = None
        self._broadcaster = WebEventBroadcaster()
        self._http_client = httpx.AsyncClient(timeout=httpx.Timeout(connect=5.0, read=12.0, write=30.0, pool=5.0))
        self._futures: Dict[str, Any] = {}
        self._futures_lock = threading.Lock()
        self._future_seq = 0
        self._vite_log_path = self._frontend_root / ".devserver.log"
        self._server_log_path = self._frontend_root / ".server.log"
        self._vite_start_lock = threading.Lock()
        self._vite_starting = False
        self._install_routes()

    def bind_loop(self, loop: asyncio.AbstractEventLoop) -> None:
        self._broadcaster.bind_loop(loop)

    @property
    def app(self) -> FastAPI:
        return self._app

    @property
    def broadcaster(self) -> WebEventBroadcaster:
        return self._broadcaster

    def _require_token(self, token: str | None) -> None:
        if not token or token != self.token:
            raise HTTPException(status_code=401, detail="invalid token")

    @staticmethod
    def _err_text(exc: Exception) -> str:
        text = str(exc) if exc is not None else ""
        return text if text else repr(exc)

    def _install_routes(self) -> None:
        app = self._app

        @app.get("/api/context")
        async def get_context(token: str | None = Query(default=None)):
            self._require_token(token)
            markdown, raw = self.repl.build_context_markdown()
            return ContextResponse(markdown=markdown, raw=raw)

        @app.post("/api/submit_command")
        async def submit_command(req: SubmitCommandRequest, token: str | None = Query(default=None)):
            self._require_token(token)
            try:
                result = self.repl.submit_web_command(req.text, mode=req.status, input_type=req.input_type)
                self._write_server_log(
                    f"[submit_command] ok={bool(result.get('ok'))} len={len(req.text)} "
                    f"status={req.status} dispatched={result.get('dispatched')}"
                )
                return result
            except Exception as exc:
                self._write_server_log(f"[submit_command] error: {self._err_text(exc)}")
                return JSONResponse(status_code=500, content={"ok": False, "error": self._err_text(exc)})

        @app.get("/api/input_queue")
        async def input_queue_snapshot(token: str | None = Query(default=None), limit: int = Query(default=100)):
            self._require_token(token)
            return self.repl.input_queue_snapshot(limit=max(1, min(500, int(limit))))

        @app.post("/api/input_queue/enqueue")
        async def input_queue_enqueue(req: InputQueueEnqueueRequest, token: str | None = Query(default=None)):
            self._require_token(token)
            ok = self.repl.enqueue_input(req.text, status=req.status, input_type=req.input_type)
            return {"ok": bool(ok)}

        @app.post("/api/input_queue/dequeue")
        async def input_queue_dequeue(token: str | None = Query(default=None)):
            self._require_token(token)
            return self.repl.input_queue_dequeue()

        @app.post("/api/input_queue/clear")
        async def input_queue_clear(token: str | None = Query(default=None)):
            self._require_token(token)
            return self.repl.input_queue_clear()

        @app.get("/api/shell/command_available")
        async def shell_command_available(name: str, token: str | None = Query(default=None)):
            self._require_token(token)
            return {"available": bool(self.repl.shell.command_available(name))}

        @app.post("/api/shell/auto_should_run")
        async def shell_auto_should_run(req: ShellAutoRequest, token: str | None = Query(default=None)):
            self._require_token(token)
            should_run, reason = self.repl.shell.auto_should_run_shell(req.text)
            return ShellAutoResponse(should_run=bool(should_run), reason=reason)

        @app.post("/api/shell/run_and_capture")
        async def shell_run_and_capture(req: ShellRunRequest, token: str | None = Query(default=None)):
            self._require_token(token)
            retcode, stdout, stderr = self.repl.shell.run_and_capture(req.cmd, fold=req.fold, each=req.each)
            return ShellRunResponse(retcode=retcode, stdout=stdout, stderr=stderr)

        @app.get("/api/events")
        async def events(token: str | None = Query(default=None)):
            self._require_token(token)
            sub = self._broadcaster.subscribe()

            async def _stream() -> AsyncGenerator[bytes, None]:
                try:
                    while True:
                        payload = await sub.queue.get()
                        yield f"data: {json.dumps(payload, ensure_ascii=False)}\n\n".encode("utf-8")
                finally:
                    self._broadcaster.unsubscribe(sub)

            return StreamingResponse(_stream(), media_type="text/event-stream")

        @app.post("/api/resolve_future")
        async def resolve_future(req: ResolveFutureRequest, token: str | None = Query(default=None)):
            self._require_token(token)
            return {"ok": bool(self._resolve_future(req.future_id, req.payload))}

        @app.get("/api/debug/state")
        async def debug_state(token: str | None = Query(default=None)):
            self._require_token(token)
            return DebugStateResponse(
                waiting_input=False,
                pending_inputs=self.repl.input_queue_pending_count(),
                agent_running=bool(getattr(self.repl, "agent", None) is not None),
            )

        @app.get("/api/pending_actions")
        async def pending_actions(token: str | None = Query(default=None)):
            self._require_token(token)
            agent = getattr(self.repl, "agent", None)
            if agent is None or not hasattr(agent, "get_pending_events"):
                return {"items": []}
            try:
                items = await agent.get_pending_events()
            except Exception:
                items = []
            return {"items": items}

        @app.post("/api/complete")
        async def complete(req: CompleteRequest, token: str | None = Query(default=None)):
            self._require_token(token)
            try:
                if hasattr(self.repl, "complete_input"):
                    repl_result = self.repl.complete_input(
                        text=req.text,
                        cursor=req.cursor,
                        cwd=req.cwd,
                        max_items=req.max_items,
                    )
                    if isinstance(repl_result, dict) and repl_result.get("ok"):
                        items: List[CompletionItem] = []
                        for raw in repl_result.get("items") or []:
                            if not isinstance(raw, dict):
                                continue
                            items.append(
                                CompletionItem(
                                    text=str(raw.get("text") or ""),
                                    start_position=int(raw.get("start_position") or 0),
                                    display=str(raw.get("display") or raw.get("text") or ""),
                                    display_meta=str(raw.get("display_meta") or ""),
                                )
                            )
                            if len(items) >= req.max_items:
                                break
                        return CompleteResponse(items=items)
            except Exception:
                pass

            document = Document(req.text, cursor_position=req.cursor)
            if req.cwd:
                setattr(document, "custom_cwd", req.cwd)
            items: List[CompletionItem] = []
            for completion in COMPLETER.get_completions(document, CompleteEvent(completion_requested=True)):
                items.append(
                    CompletionItem(
                        text=completion.text,
                        start_position=completion.start_position,
                        display=getattr(completion, "display_text", None)
                        or _formatted_to_text(getattr(completion, "display", None))
                        or completion.text,
                        display_meta=getattr(completion, "display_meta_text", None)
                        or _formatted_to_text(getattr(completion, "display_meta", None)),
                    )
                )
                if len(items) >= req.max_items:
                    break
            return CompleteResponse(items=items)

        @app.get("/api/meta")
        async def meta(token: str | None = Query(default=None)):
            self._require_token(token)
            return {"token": self.token, "port": self.port, "vite_port": self.vite_port}

        @app.get("/gateway")
        async def gateway(token: str | None = Query(default=None)):
            self._require_token(token)
            self._ensure_vite_started()
            return {
                "vite_port": self.vite_port,
                "vite_running": self._vite_proc is not None and self._vite_proc.poll() is None,
                "vite_logs": self._get_vite_logs(200),
            }

        @app.websocket("/vite-ws")
        async def vite_ws_proxy(ws: WebSocket):
            self._ensure_vite_started()
            if self._vite_proc is None or self._vite_proc.poll() is not None:
                await ws.close(code=1013)
                return
            await ws.accept()
            target = f"ws://127.0.0.1:{self.vite_port}/"
            async with httpx.AsyncClient() as client:
                async with client.websocket_connect(target) as upstream:

                    async def _from_client():
                        while True:
                            await upstream.send_text(await ws.receive_text())

                    async def _from_upstream():
                        async for message in upstream.iter_text():
                            await ws.send_text(message)

                    await asyncio.gather(_from_client(), _from_upstream())

        @app.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
        async def proxy_to_vite(path: str, request: Request):
            if path.startswith("api/") or path.startswith("api") or path.startswith("vite-ws"):
                raise HTTPException(status_code=404, detail="not found")
            self._ensure_vite_started()
            if self._vite_proc is None or self._vite_proc.poll() is not None:
                return JSONResponse(status_code=503, content={"error": "vite not ready"})
            url = f"http://127.0.0.1:{self.vite_port}/{path}"
            if request.url.query:
                url = f"{url}?{request.url.query}"
            headers = dict(request.headers)
            headers.pop("host", None)
            try:
                response = await self._http_client.request(
                    request.method,
                    url,
                    headers=headers,
                    content=await request.body(),
                )
            except httpx.ReadTimeout:
                self._write_server_log(f"[proxy_to_vite] read timeout method={request.method} path=/{path}")
                return JSONResponse(
                    status_code=504,
                    content={"error": "vite proxy timeout (dev server still compiling), retry in 1-2s"},
                )
            except Exception as exc:
                return JSONResponse(status_code=502, content={"error": self._err_text(exc)})
            return Response(content=response.content, status_code=response.status_code, headers=dict(response.headers))

    def start(self) -> None:
        if self._server_thread is not None:
            return

        def _run() -> None:
            import uvicorn
            import warnings

            warnings.filterwarnings("ignore", message=".*websockets\\.legacy.*deprecated.*", category=DeprecationWarning)
            warnings.filterwarnings("ignore", message=".*WebSocketServerProtocol.*deprecated.*", category=DeprecationWarning)
            warnings.filterwarnings("ignore", message=".*ws_handler.*deprecated.*", category=DeprecationWarning)
            warnings.filterwarnings("ignore", message=".*remove second argument of ws_handler.*", category=DeprecationWarning)
            warnings.filterwarnings("ignore", module="websockets\\.legacy\\.server", category=DeprecationWarning)
            config = uvicorn.Config(self._app, host="0.0.0.0", port=self.port, log_level="warning")
            server = uvicorn.Server(config)
            self._server = server
            self._server_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._server_loop)
            self._server_loop.run_until_complete(server.serve())

        self._server_thread = threading.Thread(target=_run, daemon=True)
        self._server_thread.start()

    def stop(self) -> None:
        if self._server is not None:
            try:
                self._server.should_exit = True
            except Exception:
                pass
        if self._vite_proc is not None:
            try:
                self._vite_proc.terminate()
            except Exception:
                pass
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self._http_client.aclose())
            else:
                loop.run_until_complete(self._http_client.aclose())
        except Exception:
            pass

    def register_future(self, fut: Any) -> str:
        with self._futures_lock:
            stale = [key for key, value in self._futures.items() if getattr(value, "done", lambda: False)()]
            for key in stale:
                self._futures.pop(key, None)
            self._future_seq += 1
            future_id = f"f{int(time.time() * 1000)}_{self._future_seq}"
            self._futures[future_id] = fut
            return future_id

    def _resolve_future(self, future_id: str, payload: dict) -> bool:
        with self._futures_lock:
            future = self._futures.pop(future_id, None)
        if future is None or self._broadcaster._loop is None:
            return False
        agent = getattr(self.repl, "agent", None)
        if agent is not None and hasattr(agent, "resolve_pending_future_id"):
            try:
                asyncio.get_running_loop().create_task(agent.resolve_pending_future_id(future_id))
            except Exception:
                pass

        def _apply_result() -> None:
            try:
                if not future.done():
                    future.set_result(payload)
            except Exception:
                pass

        try:
            self._broadcaster._loop.call_soon_threadsafe(_apply_result)
            return True
        except Exception:
            return False

    def _start_vite(self) -> None:
        if not self._frontend_root.exists():
            return
        self._write_vite_log("[gateway] starting dev server")
        try:
            package_json = self._frontend_root / "package.json"
            if package_json.exists():
                package_data = json.loads(package_json.read_text(encoding="utf-8"))
                scripts = package_data.get("scripts", {})
                self._write_vite_log(f"[gateway] cwd={self._frontend_root} package.json=True")
                self._write_vite_log(f"[gateway] scripts={list(scripts.keys())}")
        except Exception as exc:
            self._write_vite_log(f"[gateway] pkg inspect failed: {exc}")
        if not (self._frontend_root / "node_modules" / ".bin" / "esbuild").exists():
            try:
                self._write_vite_log("[gateway] npm install (dev deps missing)")
                install = subprocess.Popen(
                    ["npm", "install"],
                    cwd=str(self._frontend_root),
                    stdout=self._open_vite_log(),
                    stderr=subprocess.STDOUT,
                )
                install.wait()
            except Exception as exc:
                self._write_vite_log(f"[gateway] npm install failed: {exc}")
                return
        try:
            self._vite_proc = subprocess.Popen(
                ["npm", "run", "dev-esbuild"],
                cwd=str(self._frontend_root),
                stdout=self._open_vite_log(),
                stderr=subprocess.STDOUT,
                env={**os.environ, "PORT": str(self.vite_port)},
            )
            threading.Thread(target=self._watch_dev_server, daemon=True).start()
        except Exception as exc:
            self._write_vite_log(f"[gateway] dev server start failed: {exc}")
            self._vite_proc = None

    def _watch_dev_server(self) -> None:
        if self._vite_proc is None:
            return
        try:
            self._write_vite_log(f"[gateway] dev server exited rc={self._vite_proc.wait()}")
        except Exception as exc:
            self._write_vite_log(f"[gateway] dev server wait error: {exc}")
        finally:
            self._vite_proc = None

    def _ensure_vite_started(self) -> None:
        with self._vite_start_lock:
            if self._vite_proc is not None and self._vite_proc.poll() is None:
                return
            if self._vite_starting:
                return
            self._vite_starting = True
            try:
                self._write_vite_log("[gateway] ensure dev server")
                self._start_vite()
            finally:
                self._vite_starting = False

    def _open_vite_log(self):
        self._vite_log_path.parent.mkdir(parents=True, exist_ok=True)
        return open(self._vite_log_path, "a", encoding="utf-8", buffering=1)

    def _write_vite_log(self, line: str) -> None:
        try:
            with self._open_vite_log() as handle:
                handle.write(line + "\n")
        except Exception:
            pass

    def _write_server_log(self, line: str) -> None:
        try:
            self._server_log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(self._server_log_path, "a", encoding="utf-8", buffering=1) as handle:
                handle.write(line + "\n")
        except Exception:
            pass

    def _get_vite_logs(self, limit: int) -> List[dict]:
        try:
            lines = self._vite_log_path.read_text(encoding="utf-8", errors="ignore").splitlines()[-limit:]
        except Exception:
            return []
        return [{"ts": None, "line": line} for line in lines]

    def get_gateway_snapshot(self) -> dict:
        return {
            "vite_port": self.vite_port,
            "vite_running": self._vite_proc is not None and self._vite_proc.poll() is None,
            "vite_logs": self._get_vite_logs(200),
        }
