"""Config loading and normalization for the nimbie CLI."""

from __future__ import annotations

from dataclasses import dataclass, field
import importlib.util
import json
import logging
from pathlib import Path
import sys
from typing import Any

LOGGER = logging.getLogger(__name__)


class APIType:
    """Well-known upstream API families."""

    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    LOCAL = "local"
    OLLAMA = "ollama"


@dataclass(slots=True)
class ProviderConfig:
    """Resolved provider definition."""

    name: str
    default_model: str
    api_base: str
    api_key: str | None = None
    description: str | None = None
    api_type: str = APIType.OPENAI
    debug_request: bool = False
    debug_sse: bool = False
    debug_tools: bool = False


@dataclass(slots=True)
class ModelConfig:
    """Per-model tuning knobs."""

    temperature: float = 0.7
    max_tokens: int | None = None
    max_output_tokens: int | None = 8192
    timeout: int = 60
    extra_body: dict[str, Any] | None = None


@dataclass(slots=True)
class AgentConfig:
    """Agent loop defaults."""

    max_steps: int = 100
    user_name: str = "User"
    email: str | None = None


@dataclass(slots=True)
class UIConfig:
    """Terminal and web UI defaults."""

    show_reasoning: bool = False
    streaming: bool = True
    auto_allow_safe_bash: bool = True
    fold_bash_output: bool = True
    web_token: str | None = None


@dataclass(slots=True)
class Config:
    """Application config after normalization."""

    providers: list[ProviderConfig] = field(default_factory=list)
    default_provider: str | None = None
    models: dict[str, ModelConfig] = field(default_factory=dict)
    agent: AgentConfig = field(default_factory=AgentConfig)
    ui: UIConfig = field(default_factory=UIConfig)
    user_name: str = "User"
    email: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Config":
        """Normalize an OpenClaw-style config dictionary into runtime config."""

        parser = _OpenClawConfigParser(data)
        providers, default_provider, models = parser.parse()
        return cls(
            providers=providers,
            default_provider=default_provider,
            models=models,
            agent=_coerce_dataclass(AgentConfig, data.get("agent")),
            ui=_coerce_dataclass(UIConfig, data.get("ui")),
            user_name=str(data.get("user_name") or "User"),
            email=_optional_text(data.get("email")),
        )

    @classmethod
    def load(cls, config_path: Path | None = None) -> "Config":
        """Load config from the first available candidate path."""

        chosen = config_path or _first_existing_config_path()
        if chosen is None or not chosen.exists():
            return cls()
        try:
            raw_payload = _read_config_payload(chosen)
        except Exception:
            LOGGER.exception("Failed to load config from %s", chosen)
            raise
        return cls.from_dict(raw_payload)


def _first_existing_config_path() -> Path | None:
    candidates = (
        Path.home() / ".nimbie" / "config.py",
        Path.home() / ".nimbie" / "config.json",
        Path.home() / ".openclaw" / "openclaw.json",
        Path.cwd() / ".nimbie_config.py",
        Path.cwd() / ".nimbie_config.json",
    )
    for candidate in candidates:
        if candidate.exists():
            return candidate
    return None


def _read_config_payload(config_path: Path) -> dict[str, Any]:
    if config_path.suffix.lower() == ".json":
        return _read_json_payload(config_path)
    return _read_python_payload(config_path)


def _read_json_payload(config_path: Path) -> dict[str, Any]:
    payload = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"JSON config must be an object: {config_path}")
    return payload


def _read_python_payload(config_path: Path) -> dict[str, Any]:
    module_name = f"nimbie_config_{config_path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, config_path)
    if spec is None or spec.loader is None:
        raise ValueError(f"Cannot import config module: {config_path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
        payload = getattr(module, "CONFIG")
        if not isinstance(payload, dict):
            raise ValueError(f"CONFIG must be a dict: {config_path}")
        return payload
    finally:
        sys.modules.pop(module_name, None)


def _coerce_dataclass(cls: type[Any], raw_value: Any) -> Any:
    if not isinstance(raw_value, dict):
        return cls()
    return cls(**raw_value)


def _optional_text(value: Any) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None


class _OpenClawConfigParser:
    def __init__(self, raw: dict[str, Any]) -> None:
        self.raw = raw
        models_root = raw.get("models")
        if not isinstance(models_root, dict):
            raise ValueError("OpenClaw-style config requires a top-level 'models' object")
        providers_root = models_root.get("providers")
        if not isinstance(providers_root, dict):
            raise ValueError("OpenClaw-style config requires 'models.providers'")
        self.models_root = models_root
        self.providers_root = providers_root
        self.agent_defaults = ((raw.get("agents") or {}).get("defaults") or {}) if isinstance(raw.get("agents"), dict) else {}
        self.primary_provider, self.primary_model_id = _split_model_ref(
            (((self.agent_defaults.get("model") or {}).get("primary")) or "") if isinstance(self.agent_defaults.get("model"), dict) else ""
        )

    def parse(self) -> tuple[list[ProviderConfig], str | None, dict[str, ModelConfig]]:
        providers: list[ProviderConfig] = []
        model_map: dict[str, ModelConfig] = {}
        for provider_name, provider_payload in self.providers_root.items():
            if not isinstance(provider_payload, dict):
                continue
            models = self._extract_model_entries(provider_payload)
            providers.append(self._build_provider(provider_name, provider_payload, models))
            model_map.update(self._build_model_map(provider_name, models))
        self._merge_agent_model_params(model_map)
        default_name = self.primary_provider or (providers[0].name if providers else None)
        return providers, default_name, model_map

    def _extract_model_entries(self, provider_payload: dict[str, Any]) -> list[dict[str, Any]]:
        entries = provider_payload.get("models")
        if not isinstance(entries, list):
            return []
        return [entry for entry in entries if isinstance(entry, dict)]

    def _build_provider(
        self,
        provider_name: str,
        provider_payload: dict[str, Any],
        model_entries: list[dict[str, Any]],
    ) -> ProviderConfig:
        default_model = self._pick_default_model(provider_name, model_entries)
        return ProviderConfig(
            name=provider_name,
            default_model=default_model,
            api_base=str(provider_payload.get("baseUrl") or ""),
            api_key=_resolve_provider_api_key(self.raw, provider_name),
            description=_optional_text(provider_payload.get("api")),
            api_type=_map_api_family(provider_payload.get("api")),
        )

    def _pick_default_model(self, provider_name: str, model_entries: list[dict[str, Any]]) -> str:
        if self.primary_provider == provider_name and self.primary_model_id:
            return f"{provider_name}/{self.primary_model_id}"
        for entry in model_entries:
            model_id = _optional_text(entry.get("id"))
            if model_id:
                return f"{provider_name}/{model_id}"
        return provider_name

    def _build_model_map(self, provider_name: str, model_entries: list[dict[str, Any]]) -> dict[str, ModelConfig]:
        output: dict[str, ModelConfig] = {}
        for entry in model_entries:
            model_id = _optional_text(entry.get("id"))
            if not model_id:
                continue
            max_tokens = entry.get("maxTokens")
            output[f"{provider_name}/{model_id}"] = ModelConfig(
                max_output_tokens=int(max_tokens) if isinstance(max_tokens, int) else 8192
            )
        return output

    def _merge_agent_model_params(self, model_map: dict[str, ModelConfig]) -> None:
        raw_models = self.agent_defaults.get("models")
        if not isinstance(raw_models, dict):
            return
        for model_ref, payload in raw_models.items():
            if not isinstance(model_ref, str) or "/" not in model_ref:
                continue
            if not isinstance(payload, dict):
                continue
            params = payload.get("params")
            if not isinstance(params, dict):
                continue
            base = model_map.get(model_ref, ModelConfig())
            base.extra_body = dict(params)
            model_map[model_ref] = base


def _split_model_ref(value: str) -> tuple[str | None, str | None]:
    if "/" not in value:
        return None, None
    provider, model = value.split("/", 1)
    provider = provider.strip()
    model = model.strip()
    if not provider or not model:
        return None, None
    return provider, model


def _map_api_family(raw_value: Any) -> str:
    marker = str(raw_value or "").strip().lower()
    if marker == "anthropic-messages":
        return APIType.ANTHROPIC
    if marker == "ollama":
        return APIType.OLLAMA
    if marker == "local":
        return APIType.LOCAL
    return APIType.OPENAI


def _resolve_provider_api_key(data: dict[str, Any], provider_name: str) -> str | None:
    profiles = ((data.get("auth") or {}).get("profiles") or {}) if isinstance(data.get("auth"), dict) else {}
    if not isinstance(profiles, dict):
        return None
    for profile in profiles.values():
        if not isinstance(profile, dict):
            continue
        if str(profile.get("provider") or "").strip() != provider_name:
            continue
        key = profile.get("apiKey") or profile.get("api_key")
        return _optional_text(key)
    return None
