"""
Tool system with automatic discovery and registration
"""
import importlib
import sys
from pathlib import Path

def auto_discover_tools():
    """Automatically discover and import all tools from internal directory"""
    internal_dir = Path(__file__).parent / 'internal'
    if not internal_dir.exists():
        return
    internal_path = str(internal_dir)
    if internal_path not in sys.path:
        sys.path.insert(0, internal_path)
    for py_file in internal_dir.glob('*.py'):
        if py_file.name.startswith('__'):
            continue
        module_name = py_file.stem
        try:
            importlib.import_module(f'.internal.{module_name}', package=__name__)
        except ImportError as e:
            print(f'Warning: Failed to import tool module {module_name}: {e}')
auto_discover_tools()
from .tool_runtime import BaseTool, get_global_registry
registry = get_global_registry()
