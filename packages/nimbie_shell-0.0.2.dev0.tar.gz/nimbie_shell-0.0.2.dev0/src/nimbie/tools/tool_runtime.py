"""Core runtime primitives for nimbie tools."""

from __future__ import annotations

import abc
import asyncio
from dataclasses import dataclass
from enum import Enum
import inspect
import json
from typing import TYPE_CHECKING, Any, Awaitable, Callable
from uuid import uuid4

if TYPE_CHECKING:
    from ..model import UserContent


class ToolType(Enum):
    SYNC = "sync"
    ASYNC = "async"
    STREAM = "stream"


class ToolGateStatus(str, Enum):
    ALLOW = "allow"
    DENY = "deny"
    NEEDS_APPROVAL = "needs_approval"


@dataclass(slots=True)
class ToolGateDecision:
    status: ToolGateStatus
    message: str | None = None
    reasons: list[str] | None = None
    metadata: dict[str, Any] | None = None


@dataclass(slots=True)
class ToolResult:
    status: str
    content: Any = None
    error: str | None = None
    metadata: dict[str, Any] | None = None
    needs_user_input: bool = False

    @property
    def success(self) -> bool:
        return self.status == "success"


@dataclass(slots=True)
class ToolStreamEvent:
    type: str
    data: Any
    metadata: dict[str, Any] | None = None


class ToolExecutionError(Exception):
    def __init__(
        self,
        message: str,
        *,
        metadata: dict[str, Any] | None = None,
        needs_user_input: bool = False,
        content: Any = None,
    ) -> None:
        super().__init__(message)
        self.metadata = metadata
        self.needs_user_input = needs_user_input
        self.content = content


class ToolRegistry:
    def __init__(self) -> None:
        self._registered: dict[str, type["BaseTool"]] = {}

    def register(self, tool_class: type["BaseTool"]) -> None:
        instance = tool_class()
        tool_name = instance.name
        if not tool_name:
            raise ValueError(f"Tool class {tool_class.__name__} has no valid name")
        self._registered.setdefault(tool_name, tool_class)

    def get_tool_class(self, name: str) -> type["BaseTool"] | None:
        return self._registered.get(name)

    def list_tools(self) -> list[str]:
        return list(self._registered)

    def get_schemas(self) -> list[dict[str, Any]]:
        schemas: list[dict[str, Any]] = []
        for tool_class in self._registered.values():
            try:
                schemas.append(tool_class.get_schema())
            except Exception:
                continue
        return schemas


_GLOBAL_TOOL_REGISTRY = ToolRegistry()


def get_global_registry() -> ToolRegistry:
    return _GLOBAL_TOOL_REGISTRY


class BaseTool(abc.ABC):
    auto_register = True

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if cls is BaseTool or getattr(cls, "auto_register", True) is False:
            return
        try:
            get_global_registry().register(cls)
        except Exception:
            pass

    @property
    @abc.abstractmethod
    def name(self) -> str: ...

    @property
    @abc.abstractmethod
    def description(self) -> str: ...

    @property
    @abc.abstractmethod
    def schema(self) -> dict[str, Any]: ...

    @property
    def tool_type(self) -> ToolType:
        return ToolType.SYNC

    @property
    def requires_permission(self) -> bool:
        return False

    @property
    def is_destructive(self) -> bool:
        return False

    @classmethod
    @abc.abstractmethod
    def get_schema(cls) -> dict[str, Any]: ...

    @staticmethod
    @abc.abstractmethod
    def execute(**kwargs: Any) -> Any: ...

    @classmethod
    @abc.abstractmethod
    def validate_arguments(cls, args: dict[str, Any]) -> str | None: ...

    @classmethod
    @abc.abstractmethod
    def get_preview(cls, args: dict[str, Any]) -> str | None: ...

    @classmethod
    def get_precheck(cls, args: dict[str, Any]) -> ToolGateDecision | None:
        return None

    @classmethod
    def get_request_template(cls, prefix: str) -> str | None:
        return None

    @classmethod
    def get_response_template(cls, item: Any) -> str | None:
        return None

    @classmethod
    def user_input_hook(cls) -> "UserContent" | None:
        return None

    @classmethod
    def on_denial(cls, args: dict[str, Any]) -> dict[str, Any]:
        return {}

    @classmethod
    async def run(
        cls,
        args: dict[str, Any],
        *,
        cancel_event: asyncio.Event | None = None,
        approval_publish: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
        event_publish: Callable[[dict[str, Any]], Awaitable[None]] | None = None,
    ) -> ToolResult:
        validation_error = cls.validate_arguments(args)
        if validation_error:
            return ToolResult(status="failure", error=validation_error)

        precheck = cls.get_precheck(args) or ToolGateDecision(status=ToolGateStatus.ALLOW)
        if precheck.status == ToolGateStatus.DENY:
            return ToolResult(
                status="denied",
                error=precheck.message or "Tool precheck denied execution.",
                metadata={"reasons": precheck.reasons},
            )
        if precheck.status == ToolGateStatus.NEEDS_APPROVAL:
            if approval_publish is None:
                return ToolResult(
                    status="denied",
                    error="Approval required but publisher is unavailable.",
                    metadata={"reasons": precheck.reasons},
                    needs_user_input=True,
                )
            if not await cls._request_approval(approval_publish, args, precheck):
                return ToolResult(
                    status="denied",
                    error=precheck.message or "User denied tool approval.",
                    metadata={"reasons": precheck.reasons},
                    needs_user_input=True,
                )

        execute_kwargs = cls._prepare_execute_kwargs(args, cancel_event=cancel_event, event_publish=event_publish)
        try:
            output = await cls._invoke_execute(execute_kwargs)
        except ToolExecutionError as exc:
            return ToolResult(
                status="failure",
                error=str(exc),
                metadata=exc.metadata,
                needs_user_input=exc.needs_user_input,
                content=exc.content,
            )
        except Exception as exc:
            return ToolResult(status="failure", error=str(exc))
        if isinstance(output, ToolResult):
            return output
        return ToolResult(status="success", content=output)

    @classmethod
    async def _invoke_execute(cls, kwargs: dict[str, Any]) -> Any:
        execute_fn = cls.execute
        if inspect.iscoroutinefunction(execute_fn):
            return await execute_fn(**kwargs)
        return await asyncio.to_thread(execute_fn, **kwargs)

    @classmethod
    def _prepare_execute_kwargs(
        cls,
        args: dict[str, Any],
        *,
        cancel_event: asyncio.Event | None,
        event_publish: Callable[[dict[str, Any]], Awaitable[None]] | None,
    ) -> dict[str, Any]:
        kwargs = dict(args)
        signature = inspect.signature(cls.execute)
        loop = None
        try:
            loop = asyncio.get_running_loop()
        except Exception:
            loop = None

        if "cancel_event" in signature.parameters and cancel_event is not None:
            kwargs.setdefault("cancel_event", cancel_event)
        if "event_publish" in signature.parameters and event_publish is not None:
            kwargs.setdefault("event_publish", event_publish)
        if "emit_event" in signature.parameters and event_publish is not None and loop is not None:

            def emit_event(payload: dict[str, Any]) -> None:
                try:
                    loop.call_soon_threadsafe(asyncio.create_task, event_publish(payload))
                except Exception:
                    pass

            kwargs.setdefault("emit_event", emit_event)
        if "event_loop" in signature.parameters and loop is not None:
            kwargs.setdefault("event_loop", loop)
        return kwargs

    @classmethod
    async def _request_approval(
        cls,
        publish: Callable[[dict[str, Any]], Awaitable[None]],
        args: dict[str, Any],
        precheck: ToolGateDecision,
    ) -> bool:
        future = asyncio.get_running_loop().create_future()
        await publish(
            {
                "type": "approval_request",
                "id": f"appr_{uuid4().hex}",
                "tool": cls.name,
                "args": args,
                "future": future,
                "precheck": {
                    "status": precheck.status,
                    "message": precheck.message,
                    "reasons": precheck.reasons,
                    "metadata": precheck.metadata,
                },
            }
        )
        try:
            result = await future
        except Exception:
            result = None
        return bool(result.get("approved")) if isinstance(result, dict) else bool(result)

    @classmethod
    async def _request_choice(
        cls,
        publish: Callable[[dict[str, Any]], Awaitable[None]],
        prompt: str,
        choices: list[str],
        *,
        hint: str | None = None,
    ) -> tuple[str | None, bool]:
        future = asyncio.get_running_loop().create_future()
        await publish(
            {
                "type": "choice_request",
                "id": f"choice_{uuid4().hex}",
                "tool": cls.name,
                "prompt": prompt,
                "choices": choices,
                "hint": hint,
                "future": future,
            }
        )
        try:
            result = await future
        except Exception:
            result = None
        if not isinstance(result, dict):
            return None, False
        return result.get("selected"), bool(result.get("confirmed"))

    def format_result(self, result: ToolResult) -> str:
        if result.status == "success":
            if isinstance(result.content, (dict, list)):
                return json.dumps(result.content, ensure_ascii=False, indent=2)
            return str(result.content)
        return json.dumps(
            {"status": result.status, "error": result.error, "metadata": result.metadata},
            ensure_ascii=False,
            indent=2,
        )
