"""Interactive selection tool that asks the operator to pick one option."""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Dict, List, Optional, cast

from ..tool_runtime import BaseTool, ToolResult


class SelectionPromptTool(BaseTool):
    @property
    def name(self) -> str:
        return "request_selection"

    @property
    def description(self) -> str:
        return "Ask the operator to pick one option from a short list."

    @property
    def schema(self) -> Dict[str, Any]:
        return self.get_schema()

    @classmethod
    def get_schema(cls) -> Dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": "request_selection",
                "description": "Show a short selection list and return the operator choice.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "prompt": {
                            "type": "string",
                            "description": "Text shown above the option list.",
                        },
                        "choices": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Selectable options.",
                        },
                    },
                    "required": ["prompt", "choices"],
                },
            },
        }

    @staticmethod
    def execute(**kwargs) -> Dict[str, Any]:
        return {"selection": kwargs.get("selection")}

    @classmethod
    def validate_arguments(cls, args: Dict[str, Any]) -> Optional[str]:
        prompt = args.get("prompt")
        choices = args.get("choices")
        if not isinstance(prompt, str) or not prompt.strip():
            return "prompt is required"
        if not isinstance(choices, list) or not choices:
            return "choices must be a non-empty list"
        if any(not isinstance(item, str) for item in choices):
            return "each choice must be a string"
        return None

    @classmethod
    def get_preview(cls, args: Dict[str, Any]) -> Optional[str]:
        prompt = str(args.get("prompt") or "").strip()
        choices = cast(List[str], args.get("choices") or [])
        if not choices:
            return None
        return "\n".join([prompt, *[f"- {choice}" for choice in choices]])

    @classmethod
    async def run(
        cls,
        args: Dict[str, Any],
        *,
        cancel_event: Optional[Any] = None,
        approval_publish: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
        event_publish: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
    ) -> ToolResult:
        if event_publish is None:
            return ToolResult(status="failure", error="Event publisher unavailable")
        prompt = str(args.get("prompt") or "Please choose an option")
        choices = cast(List[str], args.get("choices") or [])
        selected, confirmed = await cls._request_choice(event_publish, prompt, choices)
        if not confirmed or selected is None:
            return ToolResult(status="denied", error="Selection was cancelled.", needs_user_input=True)
        next_args = dict(args)
        next_args["selection"] = selected
        return await super().run(
            next_args,
            cancel_event=cancel_event,
            approval_publish=approval_publish,
            event_publish=event_publish,
        )
