"""Internal tool adapters used by the nimbie runtime."""
