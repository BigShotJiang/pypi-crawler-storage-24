from __future__ import annotations

from dataclasses import dataclass
import difflib
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
from typing import Any, Sequence

from pydantic import BaseModel, ValidationError, field_validator

from ..tool_runtime import BaseTool, ToolExecutionError, ToolGateDecision, ToolGateStatus
from ...model import ToolMessageContent


class SnapshotError(Exception):
    pass


def _validate_absolute_path(path: Path) -> str | None:
    if not path.is_absolute():
        return "Path must be absolute"
    return None


@dataclass(frozen=True, slots=True)
class SnapshotRef:
    id: str
    parent: str | None
    repo_root: Path


class ReplacementItem(BaseModel):
    description: str | None = None
    old_string: str
    new_string: str
    replace_all: bool = False


class PatchRequest(BaseModel):
    file_name: str
    replacement_list: list[ReplacementItem]

    @field_validator("replacement_list")
    @classmethod
    def _validate_non_empty(cls, value: list[ReplacementItem]) -> list[ReplacementItem]:
        if not value:
            raise ValueError("replacement_list must contain at least one entry")
        return value


@dataclass(frozen=True, slots=True)
class EvidenceBundle:
    match_count: int
    center_line: int | None
    snapshot_cat_n: str
    hints_cat_n: list[str]


class SnapshotStore:
    def __init__(self) -> None:
        self._snapshot_repo = Path.home() / ".nimbie" / "snapshots"

    def create_for_path(self, target: Path) -> SnapshotRef | None:
        repo_root = self._tracked_repo_root(target)
        if repo_root is not None:
            return self._create_repo_snapshot(repo_root)
        return self._create_virtual_file_snapshot(target)

    def restore_by_id(self, repo_path: Path, snapshot_id: str, target_path: Path | None = None) -> bool:
        repo_root = self._locate_snapshot_repo(repo_path, snapshot_id)
        if repo_root is None:
            print(f"[Snapshot] Could not find snapshot {snapshot_id}")
            return False
        if repo_root == self._snapshot_repo:
            return self._restore_virtual_snapshot(snapshot_id, target_path)
        return self._restore_repo_snapshot(SnapshotRef(id=snapshot_id, parent=None, repo_root=repo_root))

    def restore_backup_file(self, backup_path: str, target_path: str) -> bool:
        try:
            backup = Path(backup_path)
            target = Path(target_path)
            if not backup.exists():
                print(f"[Snapshot] Backup file not found: {backup_path}")
                return False
            target.write_bytes(backup.read_bytes())
            return True
        except Exception as exc:
            print(f"[Snapshot] Restore from backup failed: {exc}")
            return False

    def _tracked_repo_root(self, target: Path) -> Path | None:
        probe = target.resolve().parent
        for _ in range(50):
            if self._is_git_repo(probe) and self._is_tracked_file(probe, target.resolve()):
                return probe
            if probe == probe.parent:
                return None
            probe = probe.parent
        return None

    def _create_repo_snapshot(self, repo_root: Path) -> SnapshotRef | None:
        try:
            parent = self._git(repo_root, "rev-parse", "--verify", "HEAD", check=False).stdout.strip() or None
            with tempfile.TemporaryDirectory(prefix="nimbie-git-index-") as tmpdir:
                env = {**os.environ, "GIT_INDEX_FILE": str(Path(tmpdir) / "index")}
                if parent:
                    self._git(repo_root, "read-tree", parent, env=env)
                self._git(repo_root, "add", "--all", env=env)
                tree_id = self._git(repo_root, "write-tree", env=env).stdout.strip()
                commit_env = {
                    **env,
                    "GIT_AUTHOR_NAME": "Nimbie Snapshot",
                    "GIT_AUTHOR_EMAIL": "snapshot@nimbie.local",
                    "GIT_COMMITTER_NAME": "Nimbie Snapshot",
                    "GIT_COMMITTER_EMAIL": "snapshot@nimbie.local",
                }
                args = ["commit-tree", tree_id]
                if parent:
                    args.extend(["-p", parent])
                args.extend(["-m", "nimbie patch snapshot"])
                commit_id = self._git(repo_root, *args, env=commit_env).stdout.strip()
                return SnapshotRef(id=commit_id, parent=parent, repo_root=repo_root)
        except Exception as exc:
            print(f"[Snapshot] Warning: {exc}")
            return None

    def _create_virtual_file_snapshot(self, target: Path) -> SnapshotRef | None:
        snapshot_repo = self._ensure_snapshot_repo()
        if snapshot_repo is None:
            return None
        try:
            virtual_path = str(target.resolve())
            with tempfile.TemporaryDirectory(prefix="nimbie-snap-") as tmpdir:
                blob_path = Path(tmpdir) / "blob"
                blob_path.write_bytes(target.read_bytes())
                blob_hash = self._git(snapshot_repo, "hash-object", "-w", str(blob_path)).stdout.strip()
                self._git(snapshot_repo, "update-index", "--add", f"--cacheinfo=100644,{blob_hash},{virtual_path}")
            parent = self._git(snapshot_repo, "rev-parse", "--verify", "HEAD", check=False).stdout.strip() or None
            tree_id = self._git(snapshot_repo, "write-tree").stdout.strip()
            commit_env = {
                "GIT_AUTHOR_NAME": "Nimbie Snapshot",
                "GIT_AUTHOR_EMAIL": "snapshot@nimbie.local",
                "GIT_COMMITTER_NAME": "Nimbie Snapshot",
                "GIT_COMMITTER_EMAIL": "snapshot@nimbie.local",
            }
            args = ["commit-tree", tree_id]
            if parent:
                args.extend(["-p", parent])
            args.extend(["-m", f"snapshot: {virtual_path}"])
            commit_id = self._git(snapshot_repo, *args, env=commit_env).stdout.strip()
            return SnapshotRef(id=commit_id, parent=parent, repo_root=snapshot_repo)
        except Exception as exc:
            print(f"[Snapshot] File snapshot failed: {exc}")
            return None

    def _restore_repo_snapshot(self, snapshot: SnapshotRef) -> bool:
        try:
            self._git(snapshot.repo_root, "restore", "--source", snapshot.id, "--worktree", "--staged", ".")
            return True
        except Exception as exc:
            print(f"[Snapshot] Restore failed: {exc}")
            return False

    def _restore_virtual_snapshot(self, snapshot_id: str, target_path: Path | None) -> bool:
        try:
            subject = self._git(self._snapshot_repo, "show", "--format=%s", "-s", snapshot_id).stdout.strip()
            if not subject.startswith("snapshot: "):
                return False
            virtual_path = subject[len("snapshot: ") :]
            destination = target_path or Path(virtual_path)
            content = self._git(self._snapshot_repo, "show", f"{snapshot_id}:{virtual_path}").stdout
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(content)
            return True
        except Exception as exc:
            print(f"[Snapshot] Restore from snapshot repo failed: {exc}")
            return False

    def _locate_snapshot_repo(self, repo_path: Path, snapshot_id: str) -> Path | None:
        if self._is_git_repo(repo_path):
            repo_root = Path(self._git(repo_path, "rev-parse", "--show-toplevel").stdout.strip())
            if self._git(repo_root, "cat-file", "-t", snapshot_id, check=False).returncode == 0:
                return repo_root
        if self._is_git_repo(self._snapshot_repo):
            if self._git(self._snapshot_repo, "cat-file", "-t", snapshot_id, check=False).returncode == 0:
                return self._snapshot_repo
        return None

    def _ensure_snapshot_repo(self) -> Path | None:
        self._snapshot_repo.mkdir(parents=True, exist_ok=True)
        if (self._snapshot_repo / ".git").exists():
            return self._snapshot_repo
        try:
            self._git(self._snapshot_repo, "init")
            self._git(self._snapshot_repo, "config", "user.email", "nimbie@snapshot.local")
            self._git(self._snapshot_repo, "config", "user.name", "Nimbie Snapshot")
            return self._snapshot_repo
        except Exception as exc:
            print(f"[Snapshot] Failed to init snapshot repo: {exc}")
            return None

    def _is_git_repo(self, path: Path) -> bool:
        try:
            return self._git(path, "rev-parse", "--is-inside-work-tree", check=False).stdout.strip() == "true"
        except Exception:
            return False

    def _is_tracked_file(self, repo_root: Path, file_path: Path) -> bool:
        try:
            rel_path = file_path.relative_to(repo_root)
        except ValueError:
            return False
        return self._git(repo_root, "ls-files", "--error-unmatch", str(rel_path), check=False).returncode == 0

    def _git(self, cwd: Path, *args: str, check: bool = True, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
        result = subprocess.run(["git", *args], cwd=cwd, env=env, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise SnapshotError(f"git {' '.join(args)} failed: {result.stderr}")
        return result


class ReplacementPlanner:
    @staticmethod
    def sha256_text(content: str) -> str:
        return hashlib.sha256(content.encode("utf-8")).hexdigest()

    @staticmethod
    def read_utf8(path: Path) -> tuple[str, str]:
        content = path.read_text(encoding="utf-8")
        return content, ReplacementPlanner.sha256_text(content)

    @staticmethod
    def find_occurrences(content: str, needle: str) -> list[int]:
        if not needle:
            return []
        hits: list[int] = []
        start = 0
        step = max(1, len(needle))
        while True:
            index = content.find(needle, start)
            if index < 0:
                return hits
            hits.append(index)
            start = index + step

    @staticmethod
    def line_number_for_index(content: str, index: int) -> int:
        return content.count("\n", 0, index) + 1

    @staticmethod
    def format_numbered_block(content: str, start_line: int = 1) -> str:
        lines = content.splitlines()
        if not lines:
            return ""
        width = len(str(start_line + len(lines) - 1))
        return "\n".join(f"{start_line + idx:>{width}}  {line}" for idx, line in enumerate(lines))

    @classmethod
    def head_snapshot(cls, content: str, max_lines: int = 30) -> str:
        return cls.format_numbered_block("\n".join(content.splitlines()[:max_lines]), start_line=1)

    @classmethod
    def around_line_snapshot(cls, content: str, center_line: int, radius: int = 8) -> str:
        lines = content.splitlines()
        start = max(1, center_line - radius)
        end = min(len(lines), center_line + radius)
        return cls.format_numbered_block("\n".join(lines[start - 1 : end]), start_line=start)

    @classmethod
    def hint_snapshots(cls, content: str, target: str, limit: int = 3) -> list[str]:
        lines = content.splitlines()
        if not lines:
            return []
        target_lines = target.splitlines() or [target]
        window_size = max(1, len(target_lines))
        if len(lines) < window_size:
            return [cls.head_snapshot(content, max_lines=min(30, len(lines)))]
        target_text = "\n".join(target_lines)
        scored: list[tuple[float, int, int]] = []
        matcher = difflib.SequenceMatcher()
        for index in range(0, len(lines) - window_size + 1):
            window_text = "\n".join(lines[index : index + window_size])
            matcher.set_seqs(window_text, target_text)
            scored.append((matcher.ratio(), index + 1, index + window_size))
        scored.sort(key=lambda item: item[0], reverse=True)
        hints: list[str] = []
        for score, start, end in scored[:limit]:
            hint_block = "\n".join(lines[start - 1 : end])
            hints.append(f"# hint_score={score:.4f}\n{cls.format_numbered_block(hint_block, start_line=start)}")
        return hints

    @classmethod
    def evidence(cls, content: str, old_string: str) -> EvidenceBundle:
        hits = cls.find_occurrences(content, old_string)
        if hits:
            center_line = cls.line_number_for_index(content, hits[0])
            return EvidenceBundle(
                match_count=len(hits),
                center_line=center_line,
                snapshot_cat_n=cls.around_line_snapshot(content, center_line),
                hints_cat_n=[],
            )
        return EvidenceBundle(
            match_count=0,
            center_line=None,
            snapshot_cat_n=cls.head_snapshot(content),
            hints_cat_n=cls.hint_snapshots(content, old_string),
        )

    @classmethod
    def simulate(
        cls,
        content: str,
        replacements: Sequence[ReplacementItem],
    ) -> tuple[str, int, list[dict[str, Any]]]:
        working = content
        applied = 0
        failures: list[dict[str, Any]] = []
        for index, item in enumerate(replacements, start=1):
            evidence = cls.evidence(working, item.old_string)
            if evidence.match_count == 0:
                failures.append(
                    {
                        "entry_index": index,
                        "description": item.description or f"replacement #{index}",
                        "old_string": item.old_string,
                        "new_string": item.new_string,
                        "replace_all": item.replace_all,
                        "match_count": 0,
                        "reason": "old string not found",
                        "snapshot_cat_n": evidence.snapshot_cat_n,
                        "hints_cat_n": evidence.hints_cat_n[:3],
                    }
                )
                continue
            if not item.replace_all and evidence.match_count > 1:
                failures.append(
                    {
                        "entry_index": index,
                        "description": item.description or f"replacement #{index}",
                        "old_string": item.old_string,
                        "new_string": item.new_string,
                        "replace_all": item.replace_all,
                        "match_count": evidence.match_count,
                        "reason": f"ambiguous match ({evidence.match_count} occurrences)",
                        "snapshot_cat_n": evidence.snapshot_cat_n,
                        "hints_cat_n": evidence.hints_cat_n[:3],
                    }
                )
                continue
            if item.replace_all:
                applied += evidence.match_count
                working = working.replace(item.old_string, item.new_string)
            else:
                applied += 1
                working = working.replace(item.old_string, item.new_string, 1)
        return working, applied, failures

    @staticmethod
    def unified_diff(
        file_path: str,
        before: str,
        after: str,
        *,
        hunk_descriptions: Sequence[str] | None = None,
    ) -> str:
        diff_lines = list(
            difflib.unified_diff(
                before.splitlines(keepends=True),
                after.splitlines(keepends=True),
                fromfile=file_path,
                tofile=file_path,
                lineterm="",
            )
        )
        if hunk_descriptions:
            out: list[str] = []
            desc_iter = iter(hunk_descriptions)
            for line in diff_lines:
                out.append(line)
                if line.startswith("@@"):
                    try:
                        out.append(f"# {next(desc_iter)}")
                    except StopIteration:
                        pass
            diff_lines = out
        return "\n".join(diff_lines)


_SNAPSHOTS = SnapshotStore()
_PLANNER = ReplacementPlanner()


def restore_ghost_snapshot_by_id(repo_path: Path, snapshot_id: str, target_path: Path | None = None) -> bool:
    return _SNAPSHOTS.restore_by_id(repo_path, snapshot_id, target_path=target_path)


def restore_file_backup(backup_path: str, target_path: str) -> bool:
    return _SNAPSHOTS.restore_backup_file(backup_path, target_path)


class FilePatchTool(BaseTool):
    @property
    def name(self) -> str:
        return "edit"

    @property
    def description(self) -> str:
        return (
            "Atomically apply one or more exact string replacements in a file. "
            "All replacements are validated before writing, so either the whole batch succeeds or nothing changes."
        )

    @property
    def schema(self) -> dict[str, Any]:
        return self.get_schema()

    @property
    def is_destructive(self) -> bool:
        return True

    @classmethod
    def get_schema(cls) -> dict[str, Any]:
        return {
            "type": "function",
            "function": {
                "name": "edit",
                "description": cls().description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "file_name": {"type": "string", "description": "Absolute path to the file to edit"},
                        "replacement_list": {
                            "type": "array",
                            "description": "Ordered list of string replacements applied atomically",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "description": {"type": "string"},
                                    "old_string": {"type": "string"},
                                    "new_string": {"type": "string"},
                                    "replace_all": {"type": "boolean", "default": False},
                                },
                                "required": ["old_string", "new_string"],
                            },
                        },
                    },
                    "required": ["file_name", "replacement_list"],
                },
            },
        }

    @staticmethod
    def execute(file_name: str, replacement_list: list[dict[str, Any]]) -> dict[str, Any]:
        request = PatchRequest(file_name=file_name, replacement_list=replacement_list)
        path = Path(request.file_name)
        path_error = _validate_absolute_path(path)
        if path_error:
            raise ToolExecutionError(path_error, metadata={"tool": "edit", "approved": False, "applied": False})
        if not path.exists():
            raise ToolExecutionError(f"File not found: {request.file_name}", metadata={"tool": "edit"})
        original_content, old_hash = _PLANNER.read_utf8(path)
        new_content, replacements_made, failures = _PLANNER.simulate(original_content, request.replacement_list)
        if failures:
            raise ToolExecutionError(
                "Replacement batch has one or more issues; no changes were applied.",
                metadata={"tool": "edit", "approved": True, "applied": False},
                content={
                    "file_name": request.file_name,
                    "applied": False,
                    "old_hash": old_hash,
                    "new_hash": old_hash,
                    "failures": failures,
                },
            )
        snapshot = _SNAPSHOTS.create_for_path(path.resolve())
        path.write_text(new_content, encoding="utf-8")
        on_disk, new_hash = _PLANNER.read_utf8(path)
        diff = _PLANNER.unified_diff(request.file_name, original_content, on_disk)
        return {
            "file_name": request.file_name,
            "replacements_made": replacements_made,
            "old_hash": old_hash,
            "new_hash": new_hash,
            "applied": True,
            "snapshot_cat_n": _PLANNER.head_snapshot(on_disk),
            "hints_cat_n": [],
            "message": f"Successfully applied {replacements_made} replacement(s) in {request.file_name}",
            "diff": diff,
            "ghost_snapshot": {"id": snapshot.id, "parent": snapshot.parent} if snapshot else None,
            "metadata": {"tool": "edit", "replacements": replacements_made, "approved": True, "applied": True},
        }

    @classmethod
    def validate_arguments(cls, args: dict[str, Any]) -> str | None:
        try:
            PatchRequest(**args)
        except ValidationError as exc:
            return str(exc)
        return None

    @classmethod
    def get_preview(cls, args: dict[str, Any]) -> str | None:
        try:
            request = PatchRequest(**args)
        except ValidationError:
            return None
        path = Path(request.file_name)
        if not path.exists():
            return None
        content, _ = _PLANNER.read_utf8(path)
        new_content, replacements_made, failures = _PLANNER.simulate(content, request.replacement_list)
        if failures or replacements_made == 0:
            return None
        descriptions = [
            f"{index}. {item.description or 'no description'} (replace_all={item.replace_all})"
            for index, item in enumerate(request.replacement_list, start=1)
        ]
        diff = _PLANNER.unified_diff(request.file_name, content, new_content, hunk_descriptions=descriptions)
        return f"```diff\n# replacements={replacements_made}\n{diff}\n```\n"

    @classmethod
    def get_precheck(cls, args: dict[str, Any]) -> ToolGateDecision:
        try:
            request = PatchRequest(**args)
        except ValidationError as exc:
            message = f"Invalid replacement request: {exc}"
            return ToolGateDecision(status=ToolGateStatus.DENY, message=message, reasons=[message])
        error = cls._preflight_error(request)
        if error:
            return ToolGateDecision(status=ToolGateStatus.DENY, message=error, reasons=[error])
        return ToolGateDecision(
            status=ToolGateStatus.NEEDS_APPROVAL,
            message="String replacement requires approval.",
            metadata={"file_name": request.file_name},
        )

    @classmethod
    def get_request_template(cls, prefix: str) -> str | None:
        return (
            f"## {{name}} request\n\n{prefix}.function.arguments:\n\n```json\n{{{{ .function.arguments:json }}}}\n```\n\n"
            "File: {{ .function.arguments.file_name }}\n"
        )

    @classmethod
    def get_response_template(cls, record: Any) -> str | None:
        content = getattr(record, "content", None)
        if not isinstance(content, ToolMessageContent) or not isinstance(content.data, dict):
            return None
        replacements = content.data.get("replacements_made", 0)
        file_path = content.data.get("file_name", "")
        return "\n\n".join(
            [
                "# Replacement Result",
                f"File: {file_path}",
                f"Replacements made: {replacements}",
                "✅ Changes applied" if replacements > 0 else "⚠️ No changes applied",
            ]
        )

    @classmethod
    def on_denial(cls, args: dict[str, Any]) -> dict[str, Any]:
        try:
            request = PatchRequest(**args)
        except ValidationError as exc:
            return {
                "status": "denied",
                "file_name": str(args.get("file_name", "")),
                "applied": False,
                "error": f"Invalid replacement request: {exc}",
                "snapshot_cat_n": "",
                "hints_cat_n": [],
                "message": "User denied approval. No changes were applied.",
            }
        path = Path(request.file_name)
        path_error = _validate_absolute_path(path)
        if path_error:
            return {
                "status": "denied",
                "file_name": request.file_name,
                "applied": False,
                "error": path_error,
                "snapshot_cat_n": "",
                "hints_cat_n": [],
                "message": "User denied approval. No changes were applied.",
            }
        if not path.exists():
            return {
                "status": "denied",
                "file_name": request.file_name,
                "applied": False,
                "error": f"File not found: {request.file_name}",
                "snapshot_cat_n": "",
                "hints_cat_n": [],
                "message": "User denied approval. No changes were applied.",
            }
        content, current_hash = _PLANNER.read_utf8(path)
        evidence = _PLANNER.evidence(content, request.replacement_list[0].old_string)
        note = ""
        if not request.replacement_list[0].replace_all and evidence.match_count > 1:
            note = f" Note: old_string occurs {evidence.match_count} times; consider using a longer unique old_string."
        return {
            "status": "denied",
            "file_name": request.file_name,
            "applied": False,
            "new_hash": current_hash,
            "snapshot_cat_n": evidence.snapshot_cat_n,
            "hints_cat_n": evidence.hints_cat_n[:3],
            "match_count": evidence.match_count,
            "message": "User denied approval. No changes were applied. Snapshot reflects current on-disk file state." + note,
        }

    @classmethod
    def _preflight_error(cls, request: PatchRequest) -> str | None:
        path = Path(request.file_name)
        path_error = _validate_absolute_path(path)
        if path_error:
            return path_error
        if not path.exists():
            return f"File not found: {request.file_name}"
        try:
            content = path.read_text(encoding="utf-8")
        except Exception as exc:
            return f"Failed to read file: {exc}"
        _, _, failures = _PLANNER.simulate(content, request.replacement_list)
        if failures:
            summary = "; ".join(
                f"entry {item['entry_index']} ({item['description']}): {item['reason']}" for item in failures
            )
            return f"Replacement preflight failed: {summary}"
        return None
