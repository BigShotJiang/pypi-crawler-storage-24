"""Command parsing and approval policy for shell execution."""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Callable, Literal, Sequence

try:
    import nimbie_flash as flash
except ImportError:
    flash = None

PolicyDecision = Literal["ALLOW", "NEEDS_APPROVAL", "REJECT"]
PolicyResult = tuple[PolicyDecision, list[str], list[str]]


@dataclass(frozen=True, slots=True)
class ParsedCommand:
    raw: str
    argv: list[str]
    program: str
    arguments: list[str]
    ordinal: int
    redirections: list[tuple[str, str]] = field(default_factory=list)


@dataclass(frozen=True, slots=True)
class PolicyRule:
    program: str
    aliases: tuple[str, ...] = ()
    evaluator: Callable[[ParsedCommand], PolicyResult] | None = None


def _allow(_: ParsedCommand) -> PolicyResult:
    return "ALLOW", [], []


def _needs_approval_if(predicate: Callable[[ParsedCommand], bool], reason: str, suggestion: str = "") -> Callable[[ParsedCommand], PolicyResult]:
    def evaluate(command: ParsedCommand) -> PolicyResult:
        if predicate(command):
            return "NEEDS_APPROVAL", [reason], [suggestion] if suggestion else []
        return "ALLOW", [], []

    return evaluate


def _first_positional(arguments: list[str]) -> str | None:
    for value in arguments:
        if not value.startswith("-"):
            return value
    return None


def _git_rule(readonly_commands: Sequence[str]) -> Callable[[ParsedCommand], PolicyResult]:
    readonly = set(readonly_commands)

    def evaluate(command: ParsedCommand) -> PolicyResult:
        if not command.arguments:
            return "ALLOW", [], []
        subcommand = command.arguments[0]
        if subcommand in {"push", "rm", "remove", "reset", "clean", "rebase", "commit"}:
            return "NEEDS_APPROVAL", ["git write operation"], ["Use --dry-run first when possible"]
        if subcommand.startswith("-") and subcommand not in readonly:
            return "NEEDS_APPROVAL", [f"git {subcommand} may modify repository state"], []
        return "ALLOW", [], []

    return evaluate


def _find_rule(command: ParsedCommand) -> PolicyResult:
    args = command.arguments
    if "-delete" in args:
        return "NEEDS_APPROVAL", ["find -delete is destructive"], ["Prefer review before deleting files"]
    if "-exec" in args:
        return "NEEDS_APPROVAL", ["find -exec can run arbitrary commands"], []
    first_target = _first_positional(args)
    if first_target and first_target.startswith("/home") and "-maxdepth" not in args:
        return "NEEDS_APPROVAL", ["recursive find under home directory without -maxdepth"], ["Add -maxdepth 3"]
    return "ALLOW", [], []


def _tar_rule(command: ParsedCommand) -> PolicyResult:
    if {"-c", "--create", "--append", "--concatenate", "-r", "-A"} & set(command.arguments):
        return "NEEDS_APPROVAL", ["tar archive write operation"], ["Use -t to inspect archives"]
    return "ALLOW", [], []


def _unzip_rule(_: ParsedCommand) -> PolicyResult:
    return "NEEDS_APPROVAL", ["unzip can overwrite files"], ["Extract into a temporary directory first"]


def _seven_zip_rule(command: ParsedCommand) -> PolicyResult:
    if {"a", "x", "e", "d", "m", "-a", "-x", "-e", "-d", "-m"} & set(command.arguments):
        return "NEEDS_APPROVAL", ["7z operation may modify files"], []
    return "ALLOW", [], []


def _sed_rule(command: ParsedCommand) -> PolicyResult:
    if "-i" in command.arguments or "--in-place" in command.arguments:
        return "NEEDS_APPROVAL", ["sed in-place edit"], ["Redirect output to a new file instead"]
    return "ALLOW", [], []


def _xargs_rule(command: ParsedCommand) -> PolicyResult:
    args = command.arguments
    if "-I" in args or "--replace" in args:
        return "NEEDS_APPROVAL", ["xargs with replacement template can execute arbitrary commands"], []
    if "-0" not in args and "--null" not in args:
        return "NEEDS_APPROVAL", ["xargs without -0 may mis-handle special filenames"], ["Use -0 when reading paths"]
    return "ALLOW", [], []


class CommandPolicyEngine:
    def __init__(self, extra_programs: str = "") -> None:
        self._rules = self._build_rule_map(extra_programs)

    def parse(self, source: str) -> tuple[list[ParsedCommand], list[str]]:
        if flash is None:
            return [], ["Flash parser unavailable. Install with: pip install nimbie_flash"]
        try:
            interpreter = flash.FlashInterpreter()
            ast = json.loads(interpreter.parse(source))
        except Exception as exc:
            return [], [f"Shell parse failed: {exc}"]
        commands = self._extract_commands(ast)
        parsed: list[ParsedCommand] = []
        for index, command_node in enumerate(commands):
            program = str(command_node.get("name") or "")
            arguments = [str(value) for value in command_node.get("args", [])]
            argv = [program, *arguments] if program else list(arguments)
            parsed.append(
                ParsedCommand(
                    raw=" ".join(argv),
                    argv=argv,
                    program=program,
                    arguments=arguments,
                    ordinal=index,
                    redirections=[],
                )
            )
        return parsed, []

    def analyze(self, source: str) -> PolicyResult:
        commands, parse_reasons = self.parse(source)
        if parse_reasons:
            return "NEEDS_APPROVAL", parse_reasons, []
        decision: PolicyDecision = "ALLOW"
        reasons: list[str] = []
        suggestions: list[str] = []
        for command in commands:
            if not command.program:
                decision = _escalate(decision, "NEEDS_APPROVAL")
                reasons.append("Empty command segment requires approval.")
                continue
            rule = self._rules.get(command.program)
            if rule is None:
                decision = _escalate(decision, "NEEDS_APPROVAL")
                reasons.append(f"Command '{command.program}' not in allowlist")
                continue
            rule_decision, rule_reasons, rule_suggestions = (rule.evaluator or _allow)(command)
            decision = _escalate(decision, rule_decision)
            reasons.extend(rule_reasons)
            suggestions.extend(rule_suggestions)
        return decision, reasons, suggestions

    def _build_rule_map(self, extra_programs: str) -> dict[str, PolicyRule]:
        base_rules = [
            PolicyRule("cat"),
            PolicyRule("ls"),
            PolicyRule("find", evaluator=_find_rule),
            PolicyRule("grep"),
            PolicyRule("rg"),
            PolicyRule("head"),
            PolicyRule("tail"),
            PolicyRule("less"),
            PolicyRule("more"),
            PolicyRule("sort"),
            PolicyRule("uniq"),
            PolicyRule("wc"),
            PolicyRule("diff"),
            PolicyRule("stat"),
            PolicyRule("file"),
            PolicyRule("pwd"),
            PolicyRule("echo"),
            PolicyRule("printf"),
            PolicyRule("date"),
            PolicyRule("id"),
            PolicyRule("whoami"),
            PolicyRule("hostname"),
            PolicyRule("uptime"),
            PolicyRule("df"),
            PolicyRule("du"),
            PolicyRule("free"),
            PolicyRule("top"),
            PolicyRule("ps"),
            PolicyRule("env"),
            PolicyRule("printenv"),
            PolicyRule("git", evaluator=_git_rule(("status", "log", "show", "diff", "branch", "remote", "fetch", "clone", "rev-parse", "ls-files", "ls-tree", "cat-file", "grep"))),
            PolicyRule("python"),
            PolicyRule("python3"),
            PolicyRule("pip"),
            PolicyRule("pip3"),
            PolicyRule("uv"),
            PolicyRule("npm", evaluator=_needs_approval_if(lambda command: "run" in command.arguments, "npm run may execute project scripts")),
            PolicyRule("yarn"),
            PolicyRule("pnpm"),
            PolicyRule("cargo"),
            PolicyRule("rustc"),
            PolicyRule("curl"),
            PolicyRule("wget"),
            PolicyRule("ssh"),
            PolicyRule("scp"),
            PolicyRule("docker"),
            PolicyRule("podman"),
            PolicyRule("kubectl"),
            PolicyRule("vim"),
            PolicyRule("vi"),
            PolicyRule("nano"),
            PolicyRule("emacs"),
            PolicyRule("code"),
            PolicyRule("gh"),
            PolicyRule("tar", evaluator=_tar_rule),
            PolicyRule("zip"),
            PolicyRule("unzip", evaluator=_unzip_rule),
            PolicyRule("7z", evaluator=_seven_zip_rule),
            PolicyRule("xargs", evaluator=_xargs_rule),
            PolicyRule("sed", evaluator=_sed_rule),
            PolicyRule("pkill", evaluator=_needs_approval_if(lambda _command: True, "pkill can terminate processes")),
            PolicyRule("killall", evaluator=_needs_approval_if(lambda _command: True, "killall can terminate many processes")),
        ]
        rule_map: dict[str, PolicyRule] = {}
        for rule in base_rules:
            rule_map[rule.program] = rule
        alias_pairs = {
            "la": "ls",
            "ll": "ls",
            "eza": "ls",
            "exa": "ls",
            "bat": "cat",
            "zcat": "cat",
        }
        for alias, canonical in alias_pairs.items():
            rule_map[alias] = rule_map[canonical]
        for program in [item.strip() for item in extra_programs.split(",") if item.strip()]:
            rule_map[program] = PolicyRule(program)
        return rule_map

    def _extract_commands(self, node: Any) -> list[dict[str, Any]]:
        if not isinstance(node, dict):
            return []
        node_type = str(node.get("type") or "")
        if node_type == "Command":
            return [node]
        if node_type == "Pipeline":
            return [child for item in node.get("commands", []) for child in self._extract_commands(item)]
        if node_type == "List":
            return [child for item in node.get("statements", []) for child in self._extract_commands(item)]
        if node_type in {"ForLoop", "WhileLoop"}:
            return self._extract_commands(node.get("body"))
        if node_type == "IfStatement":
            commands = self._extract_commands(node.get("condition"))
            commands.extend(self._extract_commands(node.get("consequence")))
            commands.extend(self._extract_commands(node.get("alternative")))
            return commands
        return []


def _escalate(current: PolicyDecision, incoming: PolicyDecision) -> PolicyDecision:
    order = {"ALLOW": 0, "NEEDS_APPROVAL": 1, "REJECT": 2}
    return incoming if order[incoming] > order[current] else current


def parse_shell_command(command: str) -> tuple[list[ParsedCommand], list[str]]:
    return CommandPolicyEngine().parse(command)


def should_auto_allow(command: str, extra_whitelist_csv: str = "") -> bool:
    decision, _, _ = CommandPolicyEngine(extra_whitelist_csv).analyze(command)
    return decision == "ALLOW"


def get_audit_details(command: str, extra_whitelist_csv: str = "") -> PolicyResult:
    return CommandPolicyEngine(extra_whitelist_csv).analyze(command)
