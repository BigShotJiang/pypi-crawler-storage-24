from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from threading import RLock
from typing import Deque, Optional, TextIO
import sys
import re
import shutil

@dataclass
class _LineEntry:
    text: str
    source: str
    printed: bool

class OutputHub:
    """
    Unified output hub with a tiny live buffer and native scrollback overflow.
    """

    def __init__(self, *, high_water_lines: int=2000, low_water_lines: int=1500, stream: Optional[TextIO]=None) -> None:
        self.high_water_lines = max(1, int(high_water_lines))
        self.low_water_lines = max(1, min(int(low_water_lines), self.high_water_lines))
        self.stream = stream or sys.stdout
        self._lines: Deque[_LineEntry] = deque()
        self._tail = ''
        self._deferred_writes: list[tuple[str, bool]] = []
        self._writes_enabled = True
        self._protected_bottom_rows = 0
        self._lock = RLock()
        self._ansi_re = re.compile('\\x1b\\[[0-9;?]*[ -/]*[@-~]')

    def set_terminal_writes_enabled(self, enabled: bool) -> None:
        with self._lock:
            self._writes_enabled = bool(enabled)
            if self._writes_enabled and self._deferred_writes:
                pending = list(self._deferred_writes)
                self._deferred_writes.clear()
                for text, force_scrollback in pending:
                    self._write_direct(text, force_scrollback=force_scrollback)

    def set_protected_bottom_rows(self, rows: int) -> None:
        with self._lock:
            self._protected_bottom_rows = max(0, int(rows))

    def push(self, source: str, text: str, *, echo: bool, already_printed: bool=False) -> None:
        if not text:
            return
        normalized = text.replace('\r\n', '\n')
        normalized = normalized.replace('\r', '\n')
        with self._lock:
            if echo and (not already_printed):
                self._write(normalized)
            merged = self._tail + normalized
            parts = merged.split('\n')
            self._tail = parts.pop() if parts else ''
            for part in parts:
                self._lines.append(_LineEntry(text=part + '\n', source=source, printed=bool(echo) or bool(already_printed)))
            self._rebalance_locked()

    def push_collect(self, source: str, text: str, *, echo: bool, already_printed: bool=False) -> str:
        if not text:
            return ''
        normalized = text.replace('\r\n', '\n')
        normalized = normalized.replace('\r', '\n')
        with self._lock:
            if echo and (not already_printed):
                self._write(normalized)
            merged = self._tail + normalized
            parts = merged.split('\n')
            self._tail = parts.pop() if parts else ''
            for part in parts:
                self._lines.append(_LineEntry(text=part + '\n', source=source, printed=bool(echo) or bool(already_printed)))
            return self._collect_high_water_overflow_locked()

    def flush_pending_to_scrollback(self) -> None:
        with self._lock:
            pending: list[str] = []
            while self._lines:
                entry = self._lines.popleft()
                if not entry.printed:
                    pending.append(entry.text)
            if self._tail:
                pending.append(self._tail)
                self._tail = ''
            if pending:
                self._write(''.join(pending), force_scrollback=True)

    def rebalance_for_budget(self, *, max_visible_rows: int, width: int) -> None:
        budget = max(1, int(max_visible_rows))
        width = max(1, int(width))
        with self._lock:
            while self._rows_locked(width) > budget and self._lines:
                entry = self._lines.popleft()
                if not entry.printed:
                    self._write(entry.text, force_scrollback=True)

    def rebalance_collect(self, *, max_visible_rows: int, width: int) -> str:
        budget = max(1, int(max_visible_rows))
        width = max(1, int(width))
        with self._lock:
            overflow: list[str] = []
            while self._rows_locked(width) > budget and self._lines:
                entry = self._lines.popleft()
                if not entry.printed:
                    overflow.append(entry.text)
            return ''.join(overflow)

    def snapshot_visible(self, *, max_rows: int) -> str:
        limit = max(1, int(max_rows))
        with self._lock:
            entries = list(self._lines)[-limit:]
            text = ''.join((e.text for e in entries))
            if self._tail:
                text += self._tail
            return text

    def _rebalance_locked(self) -> None:
        if len(self._lines) <= self.high_water_lines:
            return
        to_evict = len(self._lines) - self.low_water_lines
        if to_evict <= 0:
            return
        overflow: list[str] = []
        for _ in range(to_evict):
            if not self._lines:
                break
            entry = self._lines.popleft()
            if not entry.printed:
                overflow.append(entry.text)
        if overflow:
            self._write(''.join(overflow), force_scrollback=True)

    def _collect_high_water_overflow_locked(self) -> str:
        if len(self._lines) <= self.high_water_lines:
            return ''
        to_evict = len(self._lines) - self.low_water_lines
        if to_evict <= 0:
            return ''
        overflow: list[str] = []
        for _ in range(to_evict):
            if not self._lines:
                break
            entry = self._lines.popleft()
            if not entry.printed:
                overflow.append(entry.text)
        return ''.join(overflow)

    def _rows_locked(self, width: int) -> int:
        total = 0
        for entry in self._lines:
            total += self._entry_rows(entry.text, width)
        if self._tail:
            total += self._entry_rows(self._tail, width)
        return max(1, total)

    def _entry_rows(self, text: str, width: int) -> int:
        if width <= 0:
            return 1
        plain = self._ansi_re.sub('', text).replace('\n', '')
        ln = len(plain)
        if ln <= 0:
            return 1
        return (ln + width - 1) // width

    def _write(self, text: str, force_scrollback: bool=False) -> None:
        with self._lock:
            if not self._writes_enabled:
                self._deferred_writes.append((text, bool(force_scrollback)))
                return
            self._write_direct(text, force_scrollback=force_scrollback)

    def _write_direct(self, text: str, force_scrollback: bool=False) -> None:
        try:
            if force_scrollback and hasattr(self.stream, 'isatty') and self.stream.isatty():
                rows = max(1, int(shutil.get_terminal_size((120, 40)).lines))
                protected = min(max(0, self._protected_bottom_rows), rows - 1)
                scroll_bottom = max(1, rows - protected)
                self.stream.write('\x1b[s')
                self.stream.write(f'\x1b[1;{scroll_bottom}r')
                self.stream.write(f'\x1b[{scroll_bottom};1H')
                self.stream.write(text)
                if text and (not text.endswith('\n')):
                    self.stream.write('\n')
                self.stream.write('\x1b[r')
                self.stream.write('\x1b[u')
            else:
                self.stream.write(text)
            self.stream.flush()
        except Exception:
            pass
