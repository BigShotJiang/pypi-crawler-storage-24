from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import List, Optional

from rich.console import Console
from rich.segment import Segment
from rich.style import Style
from rich.syntax import Syntax
from rich.text import Text

_INLINE_PATTERNS = [
    ("code", re.compile(r"`([^`]+)`")),
    ("bold", re.compile(r"\*\*([^\*]+)\*\*")),
    ("italic", re.compile(r"(?<!\*)\*([^\*]+)\*(?!\*)")),
    ("strike", re.compile(r"~~([^~]+)~~")),
]


@dataclass(frozen=True, slots=True)
class InlineToken:
    start: int
    end: int
    kind: str
    text: str


def _token_style(kind: str, base: Style) -> Style:
    if kind == "code":
        return base + Style(meta={"class": "md.inline_code"})
    if kind == "bold":
        return base + Style(bold=True)
    if kind == "italic":
        return base + Style(italic=True)
    if kind == "strike":
        return base + Style(strike=True)
    return base


def _collect_inline_tokens(source: str) -> list[InlineToken]:
    tokens: list[InlineToken] = []
    for kind, pattern in _INLINE_PATTERNS:
        for match in pattern.finditer(source):
            tokens.append(InlineToken(match.start(), match.end(), kind, match.group(1)))
    return sorted(tokens, key=lambda token: token.start)


def paint_inline_markup(text: str, base_style: Style | None = None) -> Text:
    base = base_style or Style()
    tokens = _collect_inline_tokens(text)
    if not tokens:
        return Text(text, style=base)
    rich_text = Text()
    cursor = 0
    for token in tokens:
        if token.start < cursor:
            continue
        if token.start > cursor:
            rich_text.append(text[cursor:token.start], base)
        rich_text.append(token.text, _token_style(token.kind, base))
        cursor = token.end
    if cursor < len(text):
        rich_text.append(text[cursor:], base)
    return rich_text


def paint_code_line(
    line: str,
    language: str = "text",
    theme: str = "monokai",
    base_style: Style | None = None,
    console: Optional[Console] = None,
) -> Text:
    active_console = console or Console()
    base = base_style or Style()
    syntax = Syntax(
        line.rstrip("\n") + "\n",
        language or "text",
        theme=theme,
        line_numbers=False,
        word_wrap=False,
        indent_guides=False,
    )
    rendered = Text(style=base)
    for segment_line in Segment.split_lines(list(active_console.render(syntax))):
        for segment in segment_line:
            style = segment.style or base
            rendered.append(
                segment.text,
                Style(
                    color=style.color,
                    bold=style.bold,
                    dim=style.dim,
                    italic=style.italic,
                    underline=style.underline,
                    blink=style.blink,
                    blink2=style.blink2,
                    reverse=style.reverse,
                    conceal=style.conceal,
                    strike=style.strike,
                    underline2=style.underline2,
                    frame=style.frame,
                    encircle=style.encircle,
                    overline=style.overline,
                    link=style.link,
                    meta=style.meta,
                ),
            )
    return rendered


@dataclass
class TerminalMarkdownTheme:
    code_theme: str = "monokai"
    heading_style: Style = field(default_factory=lambda: Style(bold=True))
    h1_style: Style = field(default_factory=lambda: Style(bold=True, underline=True))
    h2_style: Style = field(default_factory=lambda: Style(bold=True))
    h3_style: Style = field(default_factory=lambda: Style(bold=True, italic=True))
    blockquote_style: Style = field(default_factory=lambda: Style(color="green"))
    bullet_style: Style = field(default_factory=lambda: Style())
    number_style: Style = field(default_factory=lambda: Style(color="cyan"))
    paragraph_style: Style = field(default_factory=lambda: Style())
    code_block_style: Style = field(default_factory=lambda: Style())


class TerminalMarkdownPainter:
    def __init__(self, console: Optional[Console] = None, theme: Optional[TerminalMarkdownTheme] = None) -> None:
        self.console = console or Console()
        self.theme = theme or TerminalMarkdownTheme()

    def to_lines(self, source: str) -> List[Text]:
        output: list[Text] = []
        in_fence = False
        fence_language = "text"
        for raw_line in source.splitlines(keepends=False):
            stripped = raw_line.lstrip()
            indent = len(raw_line) - len(stripped)
            fence = re.match(r"^```(\w+)?\s*$", stripped)
            if fence:
                if in_fence:
                    in_fence = False
                    fence_language = "text"
                else:
                    in_fence = True
                    fence_language = fence.group(1) or "text"
                continue
            if in_fence:
                code_line = paint_code_line(
                    stripped,
                    language=fence_language,
                    theme=self.theme.code_theme,
                    base_style=self.theme.code_block_style,
                    console=self.console,
                )
                if indent:
                    prefix = Text(" " * indent, style=self.theme.code_block_style)
                    prefix.append(code_line)
                    output.append(prefix)
                else:
                    output.append(code_line)
                continue
            if not stripped:
                output.append(Text(""))
                continue
            rendered = self._render_non_code_line(stripped, indent)
            output.append(rendered)
        return output

    def _render_non_code_line(self, stripped: str, indent: int) -> Text:
        heading = re.match(r"^(#+)\s+(.*)$", stripped)
        if heading:
            level = len(heading.group(1))
            content = heading.group(2)
            style = self.theme.h1_style if level == 1 else self.theme.h2_style if level == 2 else self.theme.h3_style
            return paint_inline_markup(content, base_style=style)
        if stripped.startswith(">"):
            content = stripped[1:].lstrip()
            prefix = Text("> ", style=self.theme.blockquote_style)
            prefix.append(paint_inline_markup(content, base_style=self.theme.blockquote_style))
            return prefix
        unordered = re.match(r"^([-*+])\s+(.*)$", stripped)
        if unordered:
            prefix = Text(" " * indent + unordered.group(1) + " ", style=self.theme.bullet_style)
            prefix.append(paint_inline_markup(unordered.group(2), base_style=self.theme.paragraph_style))
            return prefix
        ordered = re.match(r"^(\d+)\.\s+(.*)$", stripped)
        if ordered:
            prefix = Text(" " * indent + ordered.group(1) + ". ", style=self.theme.number_style)
            prefix.append(paint_inline_markup(ordered.group(2), base_style=self.theme.paragraph_style))
            return prefix
        body = paint_inline_markup(stripped, base_style=self.theme.paragraph_style)
        if not indent:
            return body
        prefix = Text(" " * indent, style=self.theme.paragraph_style)
        prefix.append(body)
        return prefix


def render_terminal_markdown(source: str, console: Optional[Console] = None) -> List[Text]:
    return TerminalMarkdownPainter(console=console or Console()).to_lines(source)
