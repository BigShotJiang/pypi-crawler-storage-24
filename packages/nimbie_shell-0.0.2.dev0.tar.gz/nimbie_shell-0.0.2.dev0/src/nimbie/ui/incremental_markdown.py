from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from rich.console import Console
from rich.text import Text

from .terminal_markdown import TerminalMarkdownPainter, TerminalMarkdownTheme, render_terminal_markdown


@dataclass(slots=True)
class _RenderProgress:
    source: str = ""
    emitted_lines: int = 0


class IncrementalMarkdownBuffer:
    """Release rendered markdown only after full lines have arrived."""

    def __init__(self, console: Optional[Console] = None, config: Optional[TerminalMarkdownTheme] = None) -> None:
        self.console = console or Console()
        self._painter = TerminalMarkdownPainter(console=self.console, theme=config)
        self._progress = _RenderProgress()

    @property
    def full_buffer(self) -> str:
        return self._progress.source

    def clear(self) -> None:
        self._progress = _RenderProgress()

    def push_delta(self, delta: str) -> None:
        if delta:
            self._progress.source += delta

    def commit_complete_lines(self) -> List[Text]:
        cutoff = self._completed_cutoff(self._progress.source)
        if cutoff <= 0:
            return []
        return self._emit_from_source(self._progress.source[:cutoff])

    def finalize_and_drain(self) -> List[Text]:
        if not self._progress.source:
            return []
        source = self._progress.source
        if not source.endswith("\n"):
            source += "\n"
        return self._emit_from_source(source)

    @staticmethod
    def _completed_cutoff(source: str) -> int:
        return source.rfind("\n") + 1 if source else 0

    def _emit_from_source(self, source: str) -> List[Text]:
        rendered_lines = self._painter.to_lines(source)
        if len(rendered_lines) <= self._progress.emitted_lines:
            return []
        fresh_lines = rendered_lines[self._progress.emitted_lines :]
        self._progress.emitted_lines = len(rendered_lines)
        return fresh_lines


TerminalMarkdownRenderer = TerminalMarkdownPainter


def simulate_incremental_markdown(chunks: List[str], console: Optional[Console] = None) -> List[Text]:
    """Run deltas through the same incremental renderer used at runtime."""

    buffer = IncrementalMarkdownBuffer(console=console or Console())
    rendered: list[Text] = []
    for chunk in chunks:
        buffer.push_delta(chunk)
        rendered.extend(buffer.commit_complete_lines())
    rendered.extend(buffer.finalize_and_drain())
    return rendered


def render_markdown_snapshot(markdown: str, console: Optional[Console] = None) -> List[Text]:
    """Render a complete markdown snapshot for parity checks."""

    return render_terminal_markdown(markdown, console=console)
