from __future__ import annotations

import json
from dataclasses import asdict, dataclass, is_dataclass
from typing import Any, Callable, Sequence

from chronml import Chron
from pydantic import BaseModel
from rich.markdown import Markdown
from rich.rule import Rule
from rich.text import Text
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Footer, Select, Static

_SESSION_CHRON = Chron(marker_prefix="md_as_config:ctx:")


def _render_record_to_md(record: dict[str, Any]) -> str:
    return _SESSION_CHRON.dumps([record], template="")


@dataclass(frozen=True, slots=True)
class HistoryEntry:
    role: str
    payload: dict[str, Any]
    content: Any
    compact_value: Any


class SessionHistoryInspectorApp(App[None]):
    CSS = """
    Screen {
        align: center top;
    }

    #history-scroll {
        height: 1fr;
        padding: 0 1;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit", show=True),
        Binding("escape", "toggle_raw", "Raw JSON", show=True),
    ]

    def __init__(
        self,
        messages: Sequence[Any],
        path: str | None = None,
        fork_callback: Callable[[int], str | None] | None = None,
    ) -> None:
        super().__init__()
        self._messages = list(messages)
        self._path = path
        self._fork_callback = fork_callback
        self._show_raw = False
        self._select_options = [("fork here", "fork_here")]
        self._last_widget: Static | None = None

    def compose(self) -> ComposeResult:
        yield Vertical(VerticalScroll(id="history-scroll"))
        yield Footer()

    def on_mount(self) -> None:
        self._render_view()

    def on_select_changed(self, event: Select.Changed) -> None:
        if not event.select.id or not event.value:
            return
        try:
            entry_index = int(event.select.id.split("_")[1])
        except (IndexError, ValueError):
            return
        if event.value == "fork_here":
            self.action_fork_here(entry_index)
        event.select.value = Select.BLANK

    def action_quit(self) -> None:
        self.exit()

    def action_toggle_raw(self) -> None:
        self._show_raw = not self._show_raw
        self._render_view()

    def action_fork_here(self, entry_index: int) -> None:
        self.bell()
        if self._fork_callback is None:
            self.exit("Fork functionality is not available")
            return
        try:
            result = self._fork_callback(entry_index)
        except Exception as exc:
            result = f"Fork failed: {exc}"
        self.exit(result)

    def _render_view(self) -> None:
        scroll = self.query_one("#history-scroll", VerticalScroll)
        scroll.remove_children()
        self._last_widget = None
        if self._path:
            scroll.mount(Static(Text(f"history: {self._path}", style="dim")))
            scroll.mount(Static(Rule(style="dim")))
        if self._show_raw:
            self._render_raw(scroll)
        else:
            self._render_entries(scroll)
        self.call_later(lambda: self._scroll_to_last(scroll))

    def _render_raw(self, scroll: VerticalScroll) -> None:
        try:
            pretty = json.dumps([entry.payload for entry in self._normalize_entries()], ensure_ascii=False, indent=2)
        except Exception:
            pretty = "[]"
        widget = Static(Text(pretty))
        scroll.mount(widget)
        self._last_widget = widget

    def _render_entries(self, scroll: VerticalScroll) -> None:
        entries = self._normalize_entries()
        if not entries:
            scroll.mount(Static(Text("[empty context]", style="dim")))
            return
        for index, entry in enumerate(entries):
            if entry.role.lower() == "user":
                scroll.mount(Select(self._select_options, id=f"entry_{index}", prompt=f"#{index + 1} - actions..."))
            widget = Static(self._build_renderable(entry))
            scroll.mount(widget)
            scroll.mount(Static(Text("")))
            self._last_widget = widget

    def _normalize_entries(self) -> list[HistoryEntry]:
        return [self._coerce_entry(message) for message in self._messages]

    @staticmethod
    def _coerce_entry(message: Any) -> HistoryEntry:
        payload: dict[str, Any] = {}
        if isinstance(message, dict):
            payload.update(message)
            content = message.get("content", message)
        elif is_dataclass(message):
            payload.update(asdict(message))
            content = payload.get("content", payload)
        else:
            try:
                payload.update(dict(vars(message)))
            except Exception:
                pass
            content = getattr(message, "content", None)
            if content is None:
                content = repr(message)
            payload.setdefault("__repr__", repr(message))
        if isinstance(content, BaseModel):
            content = content.model_dump()
        payload["content"] = content
        role = str(payload.get("role") or ("compact" if payload.get("type") == "compact" else "?"))
        payload.setdefault("role", role)
        return HistoryEntry(
            role=role,
            payload=payload,
            content=payload.get("content", ""),
            compact_value=payload.get("value", ""),
        )

    def _build_renderable(self, entry: HistoryEntry) -> Text | Markdown:
        markdown_body = self._render_markdown(entry)
        if markdown_body is not None:
            return Markdown(markdown_body)
        plain = entry.compact_value if entry.payload.get("type") == "compact" else entry.content
        if not isinstance(plain, str):
            plain = json.dumps(plain, ensure_ascii=False, indent=2)
        return Text(plain)

    @staticmethod
    def _render_markdown(entry: HistoryEntry) -> str | None:
        try:
            rendered = _render_record_to_md(entry.payload)
        except Exception:
            rendered = ""
        if rendered.strip():
            return rendered
        if entry.role == "assistant" and isinstance(entry.content, str) and entry.content.strip():
            return entry.content
        return None

    def _scroll_to_last(self, scroll: VerticalScroll) -> None:
        if self._last_widget is None:
            return
        try:
            scroll.scroll_to_widget(self._last_widget, animate=False, top=True, immediate=True)
        except Exception:
            pass


class EphemeralNotice(Screen):
    CSS = """
    EphemeralNotice {
        align: center middle;
        background: rgba(0, 0, 0, 0.45);
    }

    #message-box {
        padding: 1 2;
        width: 40;
        max-width: 80%;
        border: thick white;
        background: $panel;
        text-align: center;
    }
    """

    BINDINGS = [
        Binding("escape", "dismiss", "Close", show=False),
        Binding("enter", "dismiss", "Close", show=False),
    ]

    def __init__(self, message: str) -> None:
        super().__init__()
        self._message = message

    def compose(self) -> ComposeResult:
        yield Static(Text(self._message, justify="center"), id="message-box")

    def on_mount(self) -> None:
        self.set_timer(1.2, self._dismiss_later)

    def _dismiss_later(self) -> None:
        self.dismiss()

    def action_dismiss(self) -> None:
        self.dismiss()
