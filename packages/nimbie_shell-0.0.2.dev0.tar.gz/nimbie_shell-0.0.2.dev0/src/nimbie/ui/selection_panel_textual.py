"""Inline Textual selection panel used by option-picking flows."""

from __future__ import annotations

from dataclasses import dataclass

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.widgets import Label, ListItem, ListView, Static


@dataclass(frozen=True, slots=True)
class SelectionResult:
    selected: str | None
    confirmed: bool


class SelectionPanelApp(App[dict[str, str | bool | None]]):
    CSS = """
    Screen {
        align: left top;
        max-height: 60%;
    }

    #selection-root {
        border: solid gray;
        padding: 1;
        width: auto;
        min-width: 50;
        background: #101010;
    }

    ListView {
        border: solid gray;
        padding: 0 1;
        width: 60;
        max-height: 12;
    }

    .title {
        color: yellow;
    }

    .hint {
        color: #888888;
    }

    .subtitle {
        color: cyan;
    }
    """

    BINDINGS = [
        Binding("enter", "confirm", "Confirm"),
        Binding("escape", "cancel", show=False),
        Binding("c", "cancel", "Cancel", show=False),
        Binding("n", "cancel", "", show=False),
    ]

    def __init__(
        self,
        prompt: str,
        options: list[str],
        hint: str | None = None,
        subtitle: str | None = None,
        *,
        show_cancel: bool = True,
    ) -> None:
        super().__init__()
        self._prompt = prompt or "Please choose an option"
        self._options = [str(option) for option in (options or [])]
        self._hint = hint or "Use ↑/↓ to choose, Enter to confirm, Esc/C/N to cancel"
        self._subtitle = subtitle
        self._show_cancel = show_cancel
        self._highlighted_id: str | None = None
        self._result = SelectionResult(selected=None, confirmed=False)

    def compose(self) -> ComposeResult:
        items = [ListItem(Label(option), id=f"option_{index}") for index, option in enumerate(self._options)]
        if self._show_cancel:
            items.append(ListItem(Label("Cancel"), id="option_cancel"))
        children = [
            Static(self._prompt, classes="title"),
            Static(self._hint, classes="hint"),
        ]
        if self._subtitle:
            children.append(Static(self._subtitle, classes="subtitle"))
        children.append(ListView(*items, id="selection-list"))
        yield Vertical(*children, id="selection-root")

    def on_mount(self) -> None:
        try:
            self.query_one("#selection-list", ListView).focus()
        except Exception:
            pass

    def on_list_view_highlighted(self, event: ListView.Highlighted) -> None:
        self._highlighted_id = (event.item.id or "").lower()

    def on_list_view_selected(self, event: ListView.Selected) -> None:
        self._highlighted_id = (event.item.id or "").lower()
        self.action_confirm()

    def action_confirm(self) -> None:
        if not self._highlighted_id:
            return
        if self._highlighted_id == "option_cancel":
            self.action_cancel()
            return
        if not self._highlighted_id.startswith("option_"):
            return
        try:
            index = int(self._highlighted_id.split("_", 1)[1])
        except ValueError:
            return
        if 0 <= index < len(self._options):
            self._result = SelectionResult(selected=self._options[index], confirmed=True)
            self.exit()

    def action_cancel(self) -> None:
        self._result = SelectionResult(selected=None, confirmed=False)
        self.exit()

    @staticmethod
    def ask(
        prompt: str,
        options: list[str],
        hint: str | None = None,
        subtitle: str | None = None,
        *,
        show_cancel: bool = True,
    ) -> dict[str, str | bool | None]:
        app = SelectionPanelApp(prompt, options, hint=hint, subtitle=subtitle, show_cancel=show_cancel)
        app.run(inline=True)
        return {"selected": app._result.selected, "confirmed": app._result.confirmed}

    @staticmethod
    async def ask_async(
        prompt: str,
        options: list[str],
        hint: str | None = None,
        subtitle: str | None = None,
        *,
        show_cancel: bool = True,
    ) -> dict[str, str | bool | None]:
        app = SelectionPanelApp(prompt, options, hint=hint, subtitle=subtitle, show_cancel=show_cancel)
        await app.run_async(inline=True)
        return {"selected": app._result.selected, "confirmed": app._result.confirmed}
