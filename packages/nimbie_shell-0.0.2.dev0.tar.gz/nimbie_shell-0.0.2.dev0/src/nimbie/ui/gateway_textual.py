from __future__ import annotations
from typing import Callable, Any
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical, VerticalScroll
from textual.widgets import Footer, Static
from rich.text import Text

class GatewayDebugApp(App[None]):
    CSS = '\n    Screen { align: center top; }\n    #scroll { height: 1fr; padding: 0 1; }\n    '
    BINDINGS = [Binding('q', 'quit', 'Quit', show=True), Binding('r', 'refresh', 'Refresh', show=True)]

    def __init__(self, snapshot_provider: Callable[[], dict[str, Any]]) -> None:
        super().__init__()
        self._snapshot_provider = snapshot_provider
        self._snapshot: dict[str, Any] = {}

    def compose(self) -> ComposeResult:
        yield Vertical(VerticalScroll(id='scroll'))
        yield Footer()

    def on_mount(self) -> None:
        self._refresh_view()

    def action_quit(self) -> None:
        self.exit()

    def action_refresh(self) -> None:
        self._refresh_view()

    def _refresh_view(self) -> None:
        try:
            self._snapshot = self._snapshot_provider()
        except Exception:
            self._snapshot = {}
        scroll = self.query_one('#scroll', VerticalScroll)
        scroll.remove_children()
        if not self._snapshot:
            scroll.mount(Static(Text('[no gateway info]', style='dim')))
            return
        lines: list[str] = []
        lines.append('## Web Gateway')
        lines.append(f"- vite_running: {self._snapshot.get('vite_running')}")
        lines.append(f"- vite_port: {self._snapshot.get('vite_port')}")
        lines.append('')
        lines.append('## Vite Logs')
        logs = self._snapshot.get('vite_logs') or []
        if not logs:
            lines.append('(no logs)')
        else:
            for item in logs:
                ts = item.get('ts', '')
                line = item.get('line', '')
                lines.append(f'[{ts}] {line}')
        scroll.mount(Static(Text('\n'.join(lines))))
