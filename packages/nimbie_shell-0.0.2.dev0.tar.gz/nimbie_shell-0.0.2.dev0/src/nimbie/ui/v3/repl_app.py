from __future__ import annotations
import asyncio
import json
import queue
import sys
import time
import threading
import select
import signal
import shutil
import subprocess
import traceback
import contextvars
import re
import fcntl
import unicodedata
import hashlib
import shlex
from concurrent.futures import ThreadPoolExecutor, Future as ThreadFuture, TimeoutError as ThreadTimeoutError
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Tuple, Any, Dict, Callable, TypedDict, Literal
import click
from chronml import Chron
from rich.console import Console
from rich.markdown import Markdown
from rich.style import Style
from rich.text import Text
from ..v2.renderer import Renderer, RendererConfig, RenderState
from ..v2.output_hub import OutputHub
from ..incremental_markdown import IncrementalMarkdownBuffer
from ..shared.remote_shell_support import RemoteShellSupport
from oturn import Oturn, OturnConfig, OturnProviderConfig, OturnModelConfig, OturnAgentConfig, Context, Message
from oturn.events import EventPayload
import datetime as _dt
from ...model import ShellResult
from ...system_prompt import get_system_prompt
from ...command_policy import parse_shell_command
from ...tools import registry as nimbie_tool_registry
from ...tools.internal.shell_runner import get_background_registry_snapshot
from ..process_overview_textual import ProcessOverviewApp
from ..session_history_inspector_textual import SessionHistoryInspectorApp
from ..selection_panel_textual import SelectionPanelApp
from ...browser_gateway import BrowserGatewayServer
from dataclasses import is_dataclass, asdict
from pydantic import BaseModel
from ..gateway_textual import GatewayDebugApp
from prompt_toolkit.application import Application
from prompt_toolkit.layout import Layout, HSplit, VSplit, Window
from prompt_toolkit.layout.controls import BufferControl, FormattedTextControl
from prompt_toolkit.layout.dimension import Dimension
from prompt_toolkit.data_structures import Point
from prompt_toolkit.buffer import Buffer
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.layout.processors import BeforeInput
from prompt_toolkit.layout.containers import FloatContainer, Float, ConditionalContainer
from prompt_toolkit.layout.menus import CompletionsMenu
try:
    import asyncssh
except Exception:
    asyncssh = None
try:
    from pygments import highlight as _pyg_highlight
    from pygments.formatters import Terminal256Formatter as _PygTermFormatter
except Exception:
    _pyg_highlight = None
    _PygTermFormatter = None
try:
    import termios as _termios
    import tty as _tty
except Exception:
    _termios = None
    _tty = None
_SHELL_BUILTINS = {'.', ':', '[', 'alias', 'bg', 'break', 'cd', 'continue', 'echo', 'eval', 'exec', 'exit', 'export', 'fg', 'hash', 'jobs', 'printf', 'pwd', 'read', 'return', 'set', 'shift', 'source', 'test', 'times', 'trap', 'true', 'false', 'type', 'ulimit', 'umask', 'unalias', 'unset', 'wait'}

class _ShutdownEvent(TypedDict):
    type: Literal['shutdown']
ReplEvent = EventPayload | _ShutdownEvent
_SESSION_CHRON = Chron(marker_prefix='md_as_config:ctx:')

def _render_record_to_md(record: dict) -> str:
    return _SESSION_CHRON.dumps([record], template='')

def _build_ps1_prompt_fallback() -> str:
    import socket
    user = os.getenv('USER') or os.getenv('USERNAME') or 'user'
    try:
        host = socket.gethostname().split('.', 1)[0] or 'host'
    except Exception:
        host = 'host'
    try:
        cwd = os.getcwd()
        home = str(Path.home())
        if home and cwd.startswith(home):
            cwd = '~' + cwd[len(home):]
    except Exception:
        cwd = '?'
    try:
        is_root = hasattr(os, 'geteuid') and os.geteuid() == 0
    except Exception:
        is_root = False
    suffix = '#' if is_root else '$'
    return f'{user}@{host}:{cwd}{suffix} '


@dataclass
class ReplOptions:
    provider: Any
    model: str
    model_config: Any
    agent_config: Any
    ui_config: Any
    new_session: bool = False
    resume_id: Optional[str] = None
    fork_session_id: Optional[str] = None
    debug_loop: bool = False
    connect: Optional[str] = None

class EscCancelController:
    """
    Handles ESC double-tap cancel during non-PTK phases (tool run, spinner display).
    For PTK phases, use key bindings directly (more reliable).
    """

    def __init__(self) -> None:
        self._thread: Optional[threading.Thread] = None
        self._stop_evt: Optional[threading.Event] = None
        self._fd: Optional[int] = None
        self._orig: Any = None
        self._agent: Any = None

    def start(self, agent: Any) -> None:
        if _termios is None or _tty is None:
            return
        if self._thread is not None:
            return
        try:
            fd = sys.stdin.fileno()
            orig = _termios.tcgetattr(fd)
            _tty.setcbreak(fd)
        except Exception:
            return
        stop_evt = threading.Event()
        self._fd = fd
        self._orig = orig
        self._stop_evt = stop_evt
        self._agent = agent

        def _consume_after_esc(fd: int, grace: float=0.03) -> str:
            r, _, _ = select.select([fd], [], [], max(0.0, grace))
            if not r:
                return 'isolated'
            try:
                b2 = os.read(fd, 1)
            except Exception:
                return 'isolated'
            if not b2:
                return 'isolated'
            if b2 == b'O':
                select.select([fd], [], [], 0.02)
                try:
                    os.read(fd, 1)
                except Exception:
                    pass
                return 'control'
            if b2 == b'[':
                end_deadline = time.monotonic() + 0.08
                while time.monotonic() < end_deadline:
                    r, _, _ = select.select([fd], [], [], 0.02)
                    if not r:
                        break
                    try:
                        b = os.read(fd, 1)
                    except Exception:
                        break
                    if not b:
                        break
                    if 64 <= b[0] <= 126:
                        return 'control'
                return 'control'
            if b2 in (b']', b'P', b'_', b'^'):
                end_deadline = time.monotonic() + 0.2
                prev = b''
                while time.monotonic() < end_deadline:
                    r, _, _ = select.select([fd], [], [], 0.02)
                    if not r:
                        break
                    try:
                        b = os.read(fd, 1)
                    except Exception:
                        break
                    if not b:
                        break
                    if b == b'\x07':
                        return 'control'
                    if prev == b'\x1b' and b == b'\\':
                        return 'control'
                    prev = b
                return 'control'
            if b2 in (b'(', b')', b'*', b'+', b'#', b'=', b'>', b'7', b'8'):
                select.select([fd], [], [], 0.02)
                try:
                    os.read(fd, 1)
                except Exception:
                    pass
                return 'control'
            return 'alt_or_text'

        def _loop() -> None:
            last = 0.0
            try:
                while not stop_evt.is_set():
                    r, _, _ = select.select([fd], [], [], 0.1)
                    if not r:
                        continue
                    try:
                        b = os.read(fd, 1)
                    except Exception:
                        break
                    if not b:
                        continue
                    if b == b'\x1b':
                        now = time.monotonic()
                        kind = _consume_after_esc(fd)
                        if kind != 'isolated':
                            continue
                        if now - last < 0.6:
                            try:
                                self._agent.request_cancel_tool()
                            except Exception:
                                pass
                            last = 0.0
                        else:
                            last = now
            finally:
                try:
                    if self._orig is not None and self._fd is not None and (_termios is not None):
                        _termios.tcsetattr(self._fd, _termios.TCSADRAIN, self._orig)
                except Exception:
                    pass
        th = threading.Thread(target=_loop, daemon=True)
        self._thread = th
        th.start()

    def stop(self) -> None:
        if self._stop_evt is not None:
            self._stop_evt.set()
        if self._thread is not None:
            try:
                self._thread.join(timeout=0.5)
            except Exception:
                pass
        try:
            if self._orig is not None and self._fd is not None and (_termios is not None):
                _termios.tcsetattr(self._fd, _termios.TCSADRAIN, self._orig)
        except Exception:
            pass
        self._thread = None
        self._stop_evt = None
        self._fd = None
        self._orig = None
        self._agent = None

class ShellAdapter(RemoteShellSupport):
    """
    Shell initialization and execution adapter to avoid duplicated shell logic in run_loop.
    """

    def __init__(self, opts: ReplOptions) -> None:
        super().__init__(opts)

    def init(self) -> None:
        os.environ.setdefault('PROMPT_TOOLKIT_NO_CPR', '1')
        from prompt_toolkit import PromptSession
        from prompt_toolkit.enums import EditingMode
        from prompt_toolkit.completion import Completer, Completion, PathCompleter
        from prompt_toolkit.history import InMemoryHistory, ThreadedHistory
        from prompt_toolkit.auto_suggest import AutoSuggestFromHistory
        from prompt_toolkit.shortcuts.prompt import CompleteStyle
        adapter = self

        class _CommandPathCompleter(Completer):

            def __init__(self, update_on_keypress: bool) -> None:
                self._update_on_keypress = bool(update_on_keypress)
                self._path_completer = PathCompleter(expanduser=True)
                self._repl_cmds = ('/exit', '/quit', '/bg', '/background', '/history', '/compact', '/gateway', '/connect-ssh', '/disconnect-ssh')

            def _iter_exec_names(self):
                seen: set[str] = set()
                for p in os.environ.get('PATH', '').split(os.pathsep):
                    if not p:
                        continue
                    try:
                        for n in os.listdir(p):
                            if n in seen:
                                continue
                            full = os.path.join(p, n)
                            if os.path.isfile(full) and os.access(full, os.X_OK):
                                seen.add(n)
                                yield n
                    except Exception:
                        continue

            def get_completions(self, document, complete_event):
                should_complete = complete_event.completion_requested or self._update_on_keypress
                if not should_complete:
                    return
                text = document.text_before_cursor
                stripped = text.lstrip()
                first_word = stripped.split(maxsplit=1)[0] if stripped else ''
                is_first_token = ' ' not in stripped and (not stripped.endswith(' '))
                looks_like_path = first_word.startswith(('.', '/', '~'))
                if is_first_token and (not looks_like_path):
                    seen: set[str] = set()
                    for cmd in self._repl_cmds:
                        if cmd.startswith(first_word) and cmd not in seen:
                            seen.add(cmd)
                            yield Completion(cmd, start_position=-len(first_word), display_meta='repl')
                    for name in self._iter_exec_names():
                        if name.startswith(first_word) and name not in seen:
                            seen.add(name)
                            yield Completion(name, start_position=-len(first_word), display_meta='cmd')
                    return
                token = text.split()[-1] if text and (not text.endswith(' ')) else ''
                from prompt_toolkit.document import Document
                token_doc = Document(text=token, cursor_position=len(token))
                yield from self._path_completer.get_completions(token_doc, complete_event)

        class _PTKPromptShell:

            def __init__(self) -> None:
                self._session = None
                self._history = ThreadedHistory(InMemoryHistory())
                self._autosuggest = AutoSuggestFromHistory()
                self.pt_completer = self._build_completer()
                self._local_shell_lexer_cls = None
                self._bottom_toolbar_provider = None
                self._keybinding_callbacks: dict[str, Any] = {}
                self._last_esc = 0.0
                self._key_bindings = self._build_key_bindings()

            def _env_bool(self, name: str, default: bool) -> bool:
                v = os.getenv(name)
                if v is None:
                    return default
                return v.strip().lower() in {'1', 'true', 'yes', 'on'}

            def _env_int(self, name: str, default: Optional[int]) -> Optional[int]:
                v = os.getenv(name)
                if v is None or not v.strip():
                    return default
                try:
                    return int(v.strip())
                except Exception:
                    return default

            def _env_float(self, name: str, default: Optional[float]) -> Optional[float]:
                v = os.getenv(name)
                if v is None or not v.strip():
                    return default
                try:
                    parsed = float(v.strip())
                    return parsed if parsed > 0 else None
                except Exception:
                    return default

            def _build_completer(self):
                update_on_keypress = self._env_bool('UPDATE_COMPLETIONS_ON_KEYPRESS', False)
                return _CommandPathCompleter(update_on_keypress=update_on_keypress)

            def _build_local_shell_lexer_cls(self):
                import re
                from keyword import iskeyword
                from pygments.lexer import bygroups, include, inherit
                from pygments.lexers.python import Python3Lexer
                from pygments.token import Error, Keyword, Name, Operator, Punctuation, String, Text, Whitespace
                command_token_re = '[^=\\s\\[\\]{}()$"\\\'`<&|;!]+(?=\\s|$|\\)|\\]|\\}|!)'
                repl_cmds = {'cd', 'pushd', 'popd', 'exit', 'quit', 'source'}

                def _command_is_valid(cmd: str) -> bool:
                    if iskeyword(cmd):
                        return False
                    if cmd in repl_cmds:
                        return True
                    if '/' in cmd:
                        p = Path(cmd).expanduser()
                        try:
                            return p.is_file() and os.access(p, os.X_OK)
                        except Exception:
                            return False
                    return shutil.which(cmd) is not None

                def _command_is_autocd(cmd: str) -> bool:
                    if not self._env_bool('AUTO_CD', False):
                        return False
                    try:
                        cmd_abspath = os.path.abspath(os.path.expanduser(cmd))
                    except OSError:
                        return False
                    return os.path.isdir(cmd_abspath)

                def _subproc_cmd_callback(_, match):
                    cmd = match.group()
                    yield (match.start(), Name.Builtin if _command_is_valid(cmd) else Error, cmd)

                def _subproc_arg_callback(_, match):
                    text = match.group()
                    tok = Text
                    try:
                        path = os.path.expanduser(text)
                        if os.path.exists(path):
                            tok = Name.Constant
                    except OSError:
                        pass
                    yield (match.start(), tok, text)

                class LocalShellLexer(Python3Lexer):
                    name = 'Local shell lexer'
                    aliases = ['local-shell', 'local-sh']
                    filenames = ['*.sh', '*.bash']
                    tokens = {'mode_switch_brackets': [('(\\$)(\\{)', bygroups(Keyword, Punctuation), 'py_curly_bracket'), ('(@)(\\()', bygroups(Keyword, Punctuation), 'py_bracket'), ('([\\!\\$])(\\()', bygroups(Keyword, Punctuation), ('subproc_bracket', 'subproc_start')), ('(@\\$)(\\()', bygroups(Keyword, Punctuation), ('subproc_bracket', 'subproc_start')), ('([\\!\\$])(\\[)', bygroups(Keyword, Punctuation), ('subproc_square_bracket', 'subproc_start')), ('(g?)(`)', bygroups(String.Affix, String.Backtick), 'backtick_re')], 'subproc_bracket': [('\\)', Punctuation, '#pop'), include('subproc')], 'subproc_square_bracket': [('\\]', Punctuation, '#pop'), include('subproc')], 'py_bracket': [('\\)', Punctuation, '#pop'), include('root')], 'py_curly_bracket': [('\\}', Punctuation, '#pop'), include('root')], 'backtick_re': [('[\\.\\^\\$\\*\\+\\?\\[\\]\\|]', String.Regex), ('({[0-9]+}|{[0-9]+,[0-9]+})\\??', String.Regex), ('\\\\([0-9]+|[AbBdDsSwWZabfnrtuUvx\\\\])', String.Escape), ('`', String.Backtick, '#pop'), ('[^`\\.\\^\\$\\*\\+\\?\\[\\]\\|]+', String.Backtick)], 'root': [('\\?', Keyword), ('(?<=\\w)!', Keyword), ('\\$\\w+', Name.Variable), ('\\(', Punctuation, 'py_bracket'), ('\\{', Punctuation, 'py_curly_bracket'), include('mode_switch_brackets'), inherit], 'subproc_start': [('\\s+', Whitespace), (command_token_re, _subproc_cmd_callback, '#pop'), ('', Whitespace, '#pop')], 'subproc': [include('mode_switch_brackets'), ('&&|\\|\\||\\band\\b|\\bor\\b', Operator, 'subproc_start'), ('"(\\\\\\\\|\\\\[0-7]+|\\\\.|[^"\\\\])*"', String.Double), ("'(\\\\\\\\|\\\\[0-7]+|\\\\.|[^'\\\\])*'", String.Single), ('(?<=\\w|\\s)!', Keyword, 'subproc_macro'), ('^!', Keyword, 'subproc_macro'), (';', Punctuation, 'subproc_start'), ('&|=', Punctuation), ('\\|', Punctuation, 'subproc_start'), ('\\s+', Text), ('[^=\\s\\[\\]{}()$"\\\'`<&|;]+', _subproc_arg_callback), ('<', Text), ('\\$\\w+', Name.Variable)], 'subproc_macro': [('(\\s*)([^\\n]+)', bygroups(Whitespace, String)), ('', Whitespace, '#pop')]}

                    def get_tokens_unprocessed(self, text, **_):
                        start = 0
                        state = ('root',)
                        m = re.match(f'(\\s*)({command_token_re})', text)
                        if m is not None:
                            yield (m.start(1), Whitespace, m.group(1))
                            start = m.end(1)
                            cmd = m.group(2)
                            cmd_is_valid = _command_is_valid(cmd)
                            cmd_is_autocd = _command_is_autocd(cmd)
                            if cmd_is_valid or cmd_is_autocd:
                                yield (m.start(2), Name.Builtin if cmd_is_valid else Name.Constant, cmd)
                                start = m.end(2)
                                state = ('subproc',)
                        for i, t, v in super().get_tokens_unprocessed(text[start:], state):
                            yield (i + start, t, v)
                return LocalShellLexer

            def _build_lexer(self):
                if not self._env_bool('COLOR_INPUT', True):
                    return None
                try:
                    from prompt_toolkit.lexers import PygmentsLexer
                    if self._local_shell_lexer_cls is None:
                        self._local_shell_lexer_cls = self._build_local_shell_lexer_cls()
                    return PygmentsLexer(self._local_shell_lexer_cls)
                except Exception:
                    pass
                try:
                    from prompt_toolkit.lexers import PygmentsLexer
                    from pygments.lexers.shell import BashLexer
                    return PygmentsLexer(BashLexer)
                except Exception:
                    return None

            def _build_prompt_style(self):
                if not self._env_bool('COLOR_INPUT', True):
                    return None
                try:
                    from prompt_toolkit.styles.pygments import style_from_pygments_cls
                    from pygments.styles import get_style_by_name
                    style_name = os.getenv('SHELL_COLOR_STYLE', os.getenv('XONSH_COLOR_STYLE', 'monokai'))
                    try:
                        style_cls = get_style_by_name(style_name)
                    except Exception:
                        style_cls = get_style_by_name('monokai')
                    return style_from_pygments_cls(style_cls)
                except Exception:
                    return None

            def _bottom_toolbar(self) -> str:
                provider = self._bottom_toolbar_provider
                if callable(provider):
                    try:
                        return provider()
                    except Exception:
                        pass
                return 'PTK+subprocess mode'

            def set_bottom_toolbar_provider(self, provider) -> None:
                self._bottom_toolbar_provider = provider

            def set_keybinding_callbacks(self, callbacks: dict[str, Any]) -> None:
                self._keybinding_callbacks = dict(callbacks or {})

            def _cb(self, name: str):
                cb = self._keybinding_callbacks.get(name)
                return cb if callable(cb) else None

            def _build_key_bindings(self):
                from prompt_toolkit.key_binding import KeyBindings
                bindings = KeyBindings()

                @bindings.add('f2')
                def _toggle_mode(event) -> None:
                    cb = self._cb('toggle_mode')
                    if cb:
                        cb()
                    try:
                        event.app.invalidate()
                    except Exception:
                        pass

                @bindings.add('f1')
                def _history(event) -> None:
                    cb = self._cb('open_history')
                    if cb:
                        cb()

                @bindings.add('f6')
                def _bg(event) -> None:
                    cb = self._cb('open_background')
                    if cb:
                        cb()

                @bindings.add('f4')
                def _mcp(event) -> None:
                    cb = self._cb('open_mcp')
                    if cb:
                        cb()

                @bindings.add('f3')
                def _chat_only(event) -> None:
                    text = ''
                    try:
                        buf = event.app.current_buffer
                        text = buf.text if hasattr(buf, 'text') else ''
                    except Exception:
                        text = ''
                    cb = self._cb('chat_only')
                    if cb:
                        cb(text)
                    event.app.exit(exception=KeyboardInterrupt('Chat only mode activated'))

                @bindings.add('c-q')
                def _exit_cq(event) -> None:
                    cb = self._cb('exit')
                    if cb:
                        cb()
                    event.app.exit(result='')

                @bindings.add('f10')
                def _exit_f10(event) -> None:
                    cb = self._cb('exit')
                    if cb:
                        cb()
                    event.app.exit(result='')

                @bindings.add('escape')
                def _esc(event) -> None:
                    now = time.monotonic()
                    if now - self._last_esc < 0.6:
                        cb = self._cb('cancel_tool')
                        if cb:
                            cb()
                        self._last_esc = 0.0
                        try:
                            event.app.invalidate()
                        except Exception:
                            pass
                    else:
                        self._last_esc = now

                @bindings.add('escape', 'escape')
                def _esc_esc(event) -> None:
                    cb = self._cb('cancel_tool')
                    if cb:
                        cb()
                    try:
                        event.app.invalidate()
                    except Exception:
                        pass
                return bindings

            def _get_session(self):
                if self._session is None:
                    self.pt_completer = self._build_completer()
                    self._session = PromptSession(history=self._history, completer=self.pt_completer, key_bindings=self._key_bindings)
                    self.pt_completer = getattr(self._session, 'completer', None)
                return self._session

            def singleline(self) -> str:
                session = self._get_session()
                completions_display = os.getenv('COMPLETIONS_DISPLAY', 'multi').strip().lower()
                completion_style = {'multi': CompleteStyle.MULTI_COLUMN, 'single': CompleteStyle.COLUMN, 'readline': CompleteStyle.READLINE_LIKE, 'none': None}.get(completions_display, CompleteStyle.MULTI_COLUMN)
                complete_while_typing = self._env_bool('UPDATE_COMPLETIONS_ON_KEYPRESS', False)
                enable_history_search = not complete_while_typing
                menu_rows = self._env_int('COMPLETIONS_MENU_ROWS', None)
                if menu_rows is not None and menu_rows > 0:
                    menu_rows += 1
                editing_mode = EditingMode.VI if self._env_bool('VI_MODE', False) else EditingMode.EMACS
                lexer = self._build_lexer()
                style = self._build_prompt_style()
                prompt_args = {'bottom_toolbar': self._bottom_toolbar, 'auto_suggest': self._autosuggest if self._env_bool('AUTO_SUGGEST', True) else None, 'completer': None if completions_display == 'none' else self.pt_completer, 'complete_style': completion_style, 'complete_while_typing': complete_while_typing, 'enable_history_search': enable_history_search, 'reserve_space_for_menu': menu_rows, 'editing_mode': editing_mode, 'mouse_support': self._env_bool('MOUSE_SUPPORT', False), 'complete_in_thread': self._env_bool('COMPLETION_IN_THREAD', True), 'refresh_interval': self._env_float('PROMPT_REFRESH_INTERVAL', None)}
                if lexer is not None:
                    prompt_args['lexer'] = lexer
                    prompt_args['include_default_pygments_style'] = True
                if style is not None:
                    prompt_args['style'] = style
                return session.prompt(adapter.build_prompt(), **prompt_args)
        self.shell = _PTKPromptShell()

    def command_available(self, name: str) -> bool:
        if not name:
            return False
        if name in _SHELL_BUILTINS:
            return True
        if self._remote_executor_path and self._remote_ssh_host:
            if '/' in name:
                return True
            if name in self._remote_initial_commands:
                return True
            return self._remote_command_exists(name)
        if '/' in name:
            p = Path(name).expanduser()
            try:
                return p.is_file() and os.access(p, os.X_OK)
            except Exception:
                return False
        return shutil.which(name) is not None

    def auto_should_run_shell(self, line: str) -> Tuple[bool, Optional[str]]:
        segments, parse_reasons = parse_shell_command(line)
        if parse_reasons:
            return (False, str(parse_reasons[0]))
        if not segments:
            return (False, 'unrecognized command: manual confirmation required')
        for seg in segments:
            program = str(getattr(seg, 'program', '') or '')
            if program and (not self.command_available(program)):
                return (False, f'command not found: {program}')
        return (True, None)

    def run_and_capture(self, cmd: str, *, fold: bool=True, each: int=2048, proxy_stdin: bool=True, stdin_queue: Optional[queue.Queue[bytes]]=None) -> Tuple[int, str, str]:
        """
        Execute command and return rc/stdout/stderr, preserving existing behavior.
        """
        if self.shell is None:
            return (127, '', 'shell adapter not initialized')
        t0 = time.monotonic()
        started_cap = '-' if self._remote_supports_started_event is None else '1' if self._remote_supports_started_event else '0'
        self._emit_executor_debug(f'run start backend={self.remote_status_text()} started_cap={started_cap} cmd={cmd!r}')
        first_event_ts: Optional[float] = None
        first_output_ts: Optional[float] = None
        first_stdout_ts: Optional[float] = None
        first_stderr_ts: Optional[float] = None
        first_dispatch_ts: Optional[float] = None
        first_recv_ts: Optional[float] = None
        first_started_ts: Optional[float] = None
        exit_event_ts: Optional[float] = None
        backend_pid_seen: str = '-'
        child_pid_seen: str = '-'
        stream_event_count = 0

        def to_text(s: Any) -> str:
            if isinstance(s, bytes):
                return s.decode('utf-8', errors='backslashreplace')
            return str(s or '')

        def fix_surrogate(s: Any) -> str:
            return to_text(s).encode('utf-8', errors='backslashreplace').decode('utf-8')

        def trim(t: str) -> str:
            if not fold:
                return t
            b = t.encode('utf-8', errors='ignore')
            if len(b) <= each * 2:
                return t
            head = b[:each].decode('utf-8', errors='ignore')
            tail = b[-each:].decode('utf-8', errors='ignore')
            return head + '\n...<snip>...\n' + tail

        def _emit_text(text: str) -> None:
            if not text:
                return
            sink = self._output_sink
            if callable(sink):
                try:
                    sink('pty', text, True, False)
                except TypeError:
                    try:
                        sink('pty', text, True)
                    except Exception:
                        pass
                except Exception:
                    pass
            else:
                try:
                    sys.stdout.write(text)
                    sys.stdout.flush()
                except Exception:
                    pass
        try:
            import nimbie_flash as flash
            if self._flash_interp is None:
                self._flash_interp = flash.FlashInterpreter()
            interp = self._flash_interp
            custom_env = self._build_remote_ssh_command()
            executor = self._ensure_flash_executor(flash, remote=(custom_env is not None))
            self._emit_executor_debug(f"backend_route={('remote' if custom_env is not None else 'local')}")
            old_bin = os.environ.get('FLASH_STDIO_EXECUTOR_BIN')
            old_args = os.environ.get('FLASH_STDIO_EXECUTOR_ARGS_JSON')
            if custom_env is not None:
                bin_name, args = custom_env
                os.environ['FLASH_STDIO_EXECUTOR_BIN'] = bin_name
                os.environ['FLASH_STDIO_EXECUTOR_ARGS_JSON'] = json.dumps(args)
            else:
                os.environ.pop('FLASH_STDIO_EXECUTOR_BIN', None)
                os.environ.pop('FLASH_STDIO_EXECUTOR_ARGS_JSON', None)

            def _on_event(ev: Any) -> None:
                nonlocal first_event_ts, first_output_ts, first_stdout_ts, first_stderr_ts, first_dispatch_ts, first_recv_ts, first_started_ts, exit_event_ts, backend_pid_seen, child_pid_seen, stream_event_count
                data = ''
                ev_type = 'raw'
                try:
                    if isinstance(ev, dict):
                        t = str(ev.get('type') or '')
                        ev_type = t or 'raw'
                        if t in {'stdout', 'stderr', 'raw'}:
                            data = str(ev.get('data') or ev.get('stdout') or ev.get('stderr') or '')
                        else:
                            data = str(ev.get('stdout') or ev.get('stderr') or ev.get('data') or '')
                    else:
                        data = str(ev or '')
                except Exception:
                    data = ''
                now = time.monotonic()
                stream_event_count += 1
                if first_event_ts is None:
                    first_event_ts = now
                if ev_type == 'exit' and exit_event_ts is None:
                    exit_event_ts = now
                if ev_type == 'dispatch' and first_dispatch_ts is None:
                    first_dispatch_ts = now
                if ev_type == 'recv' and first_recv_ts is None:
                    first_recv_ts = now
                if ev_type == 'started' and first_started_ts is None:
                    first_started_ts = now
                    if isinstance(ev, dict):
                        try:
                            bp = ev.get('backend_pid')
                            cp = ev.get('child_pid')
                            backend_pid_seen = str(bp) if bp is not None else '-'
                            child_pid_seen = str(cp) if cp is not None else '-'
                        except Exception:
                            backend_pid_seen = '-'
                            child_pid_seen = '-'
                if data and first_output_ts is None:
                    first_output_ts = now
                if data and ev_type == 'stdout' and (first_stdout_ts is None):
                    first_stdout_ts = now
                if data and ev_type == 'stderr' and (first_stderr_ts is None):
                    first_stderr_ts = now
                if self._executor_debug_verbose():
                    self._emit_executor_debug(f"stream event type={ev_type} bytes={len(data.encode('utf-8', errors='ignore'))}")
                if data:
                    _emit_text(fix_surrogate(data))
            try:
                result = interp.run_shell_stream(cmd, executor, _on_event)
            finally:
                if old_bin is not None:
                    os.environ['FLASH_STDIO_EXECUTOR_BIN'] = old_bin
                else:
                    os.environ.pop('FLASH_STDIO_EXECUTOR_BIN', None)
                if old_args is not None:
                    os.environ['FLASH_STDIO_EXECUTOR_ARGS_JSON'] = old_args
                else:
                    os.environ.pop('FLASH_STDIO_EXECUTOR_ARGS_JSON', None)
            stdout = trim(fix_surrogate(getattr(result, 'stdout', '')))
            stderr = trim(fix_surrogate(getattr(result, 'stderr', '')))
            rc = int(getattr(result, 'exit_code', 1))
            first_event_ms = f'{(first_event_ts - t0) * 1000:.1f}' if first_event_ts is not None else '-'
            first_output_ms = f'{(first_output_ts - t0) * 1000:.1f}' if first_output_ts is not None else '-'
            first_stdout_ms = f'{(first_stdout_ts - t0) * 1000:.1f}' if first_stdout_ts is not None else '-'
            first_stderr_ms = f'{(first_stderr_ts - t0) * 1000:.1f}' if first_stderr_ts is not None else '-'
            first_dispatch_ms = f'{(first_dispatch_ts - t0) * 1000:.1f}' if first_dispatch_ts is not None else '-'
            first_recv_ms = f'{(first_recv_ts - t0) * 1000:.1f}' if first_recv_ts is not None else '-'
            first_started_ms = f'{(first_started_ts - t0) * 1000:.1f}' if first_started_ts is not None else '-'
            exit_event_ms = f'{(exit_event_ts - t0) * 1000:.1f}' if exit_event_ts is not None else '-'
            self._emit_executor_debug(f"run done rc={rc} out_bytes={len(stdout.encode('utf-8', errors='ignore'))} err_bytes={len(stderr.encode('utf-8', errors='ignore'))} elapsed_ms={(time.monotonic() - t0) * 1000:.1f} events={stream_event_count} first_event_ms={first_event_ms} first_dispatch_ms={first_dispatch_ms} first_recv_ms={first_recv_ms} first_started_ms={first_started_ms} first_output_ms={first_output_ms} first_stdout_ms={first_stdout_ms} first_stderr_ms={first_stderr_ms} exit_event_ms={exit_event_ms} backend_pid={backend_pid_seen} child_pid={child_pid_seen}")
            return (rc, stdout, stderr)
        except KeyboardInterrupt:
            self._emit_executor_debug(f'run interrupted elapsed_ms={(time.monotonic() - t0) * 1000:.1f}')
            return (130, '', 'Interrupted')
        except Exception as e:
            self._emit_executor_debug(f'run error err={e} elapsed_ms={(time.monotonic() - t0) * 1000:.1f}')
            return (1, '', str(e))

class ReplApp:

    def __init__(self, work_dir: Path, opts: ReplOptions) -> None:
        self.work_dir = work_dir.absolute()
        self.opts = opts
        self.console = Console(highlight=False, force_terminal=True, soft_wrap=False)
        self.renderer = Renderer(self.console, RendererConfig(refresh_per_second=16, code_theme='monokai'))
        self.shell = ShellAdapter(opts)
        self.esc_cancel = EscCancelController()
        self.MODE = 'auto'
        self.USAGE_TOTAL: Optional[int] = None
        self.EXIT = False
        self.ctx: Any = None
        self.session: Any = None
        self.agent: Any = None
        self.event_q: asyncio.Queue[ReplEvent] = asyncio.Queue()
        self._agent_task: Optional[asyncio.Task] = None
        self._lazy_input_task: Optional[asyncio.Task] = None
        self._chat_only_pending = False
        self._chat_only_text = ''
        self._chat_only_was_used = False
        self._session_initialized: bool = False
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._ptk_app: Any = None
        self._ptk_input_active = False
        self._web_server: Optional[BrowserGatewayServer] = None
        self._input_lock: Optional[asyncio.Lock] = None
        self._defer_prompt_refresh = False
        self._prompt_executor = ThreadPoolExecutor(max_workers=1)
        self._prompt_tls = threading.local()
        self.output_hub = OutputHub()
        self.shell.set_output_sink(self._push_output)
        self._last_input_visual_lines = 1
        self._main_app: Optional[Application] = None
        self._main_app_task: Optional[asyncio.Task] = None
        self._ui_loop: Optional[asyncio.AbstractEventLoop] = None
        self._ui_thread: Optional[threading.Thread] = None
        self._ui_ready_evt = threading.Event()
        self._ui_exit_requested: bool = False
        self._input_buffer: Optional[Buffer] = None
        self._input_window: Any = None
        self._inline_action_window: Any = None
        self._footer_window: Any = None
        self._output_control: Any = None
        self._input_line_queue: asyncio.Queue[str] = asyncio.Queue()
        self._shell_tasks: set[asyncio.Task] = set()
        self._ui_output_q: queue.Queue[Optional[tuple[str, str, bool, bool]]] = queue.Queue()
        self._ui_output_task: Optional[asyncio.Task] = None
        self._output_budget_rows: int = 20
        self._output_budget_cols: int = 120
        self._main_scrollback_chunk_bytes: int = 16384
        self._main_output_row: int = 1
        self._main_clear_upper_on_first_output: bool = True
        self._last_app_invalidate_ts: float = 0.0
        self._ui_tick_interval_s: float = 0.2
        self._ui_input_quiet_s: float = 0.0
        self._ui_max_bytes_per_tick: int = 8192
        self._ui_pending_payload: str = ''
        self._ui_last_flush_ts: float = 0.0
        self._last_input_activity_ts: float = time.monotonic()
        self._request_phase: str = 'IDLE'
        self._main_reasoning_stream = IncrementalMarkdownBuffer(console=self.console)
        self._main_content_stream = IncrementalMarkdownBuffer(console=self.console)
        self._main_stream_flush_interval_s: float = 0.2
        self._main_stream_pending: dict[str, str] = {'reasoning': '', 'content': ''}
        self._main_stream_last_flush_ts: dict[str, float] = {'reasoning': 0.0, 'content': 0.0}
        self._main_stream_force_flush_bytes: int = 8192
        self._echo_lexer_cls: Any = None
        self._csi_re = re.compile('\\x1b\\[([0-9;?]*)([@-~])')
        self._osc_re = re.compile('\\x1b\\][^\\x07]*(?:\\x07|\\x1b\\\\)')
        self._pty_clear_requested: bool = False
        self._pty_stdin_q: queue.Queue[bytes] = queue.Queue()
        self._pty_session_active: bool = False
        self._pty_focus_mode: bool = False
        self._pty_cursor_row: int = 1
        self._pty_cursor_col: int = 1
        self._inline_action_visible: bool = False
        self._inline_action_kind: str = ''
        self._inline_action_tool: str = ''
        self._inline_action_message: str = ''
        self._inline_action_reasons: list[str] = []
        self._inline_action_choices: list[str] = []
        self._inline_action_selected: int = 0
        self._inline_action_future: Any = None
        self._inline_action_input_snapshot: Optional[tuple[str, int]] = None
        self._inline_action_preserved_input_rows: int = 1
        self._suppress_enter_until_ts: float = 0.0
        self._display_prompt_cache_text: str = _build_ps1_prompt_fallback()
        self._display_prompt_cache_ts: float = 0.0
        self._prompt_refresh_task: Optional[asyncio.Task] = None
        self._litellm_prewarm_triggered: bool = False

    def _build_agent_tools(self) -> list[type]:
        tool_classes: list[type] = []
        try:
            for tool_name in nimbie_tool_registry.list_tools():
                tool_cls = nimbie_tool_registry.get_tool_class(tool_name)
                if tool_cls is not None:
                    tool_classes.append(tool_cls)
        except Exception:
            pass
        return tool_classes

    def _build_oturn_config(self) -> OturnConfig:
        provider = getattr(self.opts, 'provider', None)
        model_cfg = getattr(self.opts, 'model_config', None)
        agent_cfg = getattr(self.opts, 'agent_config', None)
        return OturnConfig(model=str(getattr(self.opts, 'model', '') or ''), provider=OturnProviderConfig(api_base=str(getattr(provider, 'api_base', '') or ''), api_key=getattr(provider, 'api_key', None), debug_request=bool(getattr(provider, 'debug_request', False)), debug_sse=bool(getattr(provider, 'debug_sse', False)), debug_tools=bool(getattr(provider, 'debug_tools', False))), model_config=OturnModelConfig(max_output_tokens=getattr(model_cfg, 'max_output_tokens', None), temperature=getattr(model_cfg, 'temperature', None), extra_body=getattr(model_cfg, 'extra_body', None)), agent_config=OturnAgentConfig(max_steps=int(getattr(agent_cfg, 'max_steps', 100) or 100), user_name=str(getattr(agent_cfg, 'user_name', 'User') or 'User'), email=getattr(agent_cfg, 'email', None)), debug_loop=bool(getattr(self.opts, 'debug_loop', False)))

    def _start_litellm_prewarm_once(self) -> None:
        if self._litellm_prewarm_triggered:
            return
        self._litellm_prewarm_triggered = True
        try:
            from oturn import start_global_litellm_prewarm
            start_global_litellm_prewarm(blocking=False)
        except Exception as exc:
            self.renderer.print_warning(f'[litellm] prewarm failed: {exc}')

    async def run(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._input_lock = asyncio.Lock()
        self._start_web_server()
        self._install_sigttou_handler()
        self._load_or_create_session()
        self._print_last_assistant_if_resumed()
        self.shell.init()
        self._start_litellm_prewarm_once()
        if getattr(self.opts, 'connect', None):
            try:
                target = str(self.opts.connect)
                self.renderer.print_info(f'[ssh] connecting to {target} ...')
                msg = await self.shell.connect_ssh(target)
                self.renderer.print_info(f'[ssh] {msg}')
            except Exception as e:
                self.renderer.print_error(f'[ssh] auto connect failed: {e}')
        self._move_cursor_to_terminal_bottom()
        self._install_ptk_keybindings()
        self._refresh_display_prompt_cache(raise_on_error=True, force=True)
        self._start_main_application()
        if self._session_initialized:
            self.agent = Oturn(self.session.work_dir, self._build_oturn_config(), tools=self._build_agent_tools())
            self.agent.subscribe(self.event_q)
            self._agent_task = asyncio.create_task(self.agent.run_queues(self.ctx))
        if self._lazy_input_task is None or self._lazy_input_task.done():
            self._lazy_input_task = asyncio.create_task(self._lazy_input_loop())
        try:
            await self._event_loop()
        finally:
            self.renderer.close()
            self.esc_cancel.stop()
            try:
                self.shell.close()
            except Exception:
                pass
            if self._agent_task is not None:
                try:
                    self._agent_task.cancel()
                except Exception:
                    pass
            if self._lazy_input_task is not None:
                try:
                    self._lazy_input_task.cancel()
                except Exception:
                    pass
            if self._main_app_task is not None:
                try:
                    self._ui_call_soon(self._main_app_task.cancel)
                except Exception:
                    pass
            try:
                if self._ui_pending_payload:
                    sys.stdout.write(self._ui_pending_payload)
                    if not self._ui_pending_payload.endswith('\n'):
                        sys.stdout.write('\n')
                    sys.stdout.flush()
                    self._ui_pending_payload = ''
            except Exception:
                pass
            if self._ui_output_task is not None:
                try:
                    self._ui_call_soon(self._ui_output_task.cancel)
                except Exception:
                    pass
            if self._ui_thread is not None:
                try:
                    app = self._main_app
                    if app is not None:
                        self._request_main_app_exit()
                except Exception:
                    pass
                try:
                    self._ui_thread.join(timeout=1.0)
                except Exception:
                    pass
            try:
                self.output_hub.set_protected_bottom_rows(0)
            except Exception:
                pass
            for t in list(self._shell_tasks):
                try:
                    t.cancel()
                except Exception:
                    pass
            if self.agent is not None:
                try:
                    self.agent.unsubscribe(self.event_q)
                except Exception:
                    pass
                try:
                    await self.agent.aclose()
                except Exception:
                    pass
            self._stop_web_server()
            try:
                self._prompt_executor.shutdown(wait=False, cancel_futures=True)
            except Exception:
                pass
            try:
                self.output_hub.flush_pending_to_scrollback()
            except Exception:
                pass

    def _move_cursor_to_terminal_bottom(self) -> None:
        try:
            rows = max(1, int(shutil.get_terminal_size((120, 40)).lines))
            sys.stdout.write(f'\x1b[{rows};1H')
            sys.stdout.flush()
        except Exception:
            pass

    def _clear_upper_region_once(self) -> None:
        if not self._main_clear_upper_on_first_output:
            return
        self._clear_upper_region()
        self._main_clear_upper_on_first_output = False

    def _clear_upper_region(self) -> None:
        try:
            rows = max(1, int(shutil.get_terminal_size((120, 40)).lines))
            protected = max(2, int(getattr(self, '_last_input_visual_lines', 1)) + 2)
            protected = min(protected, rows - 1)
            upper_bottom = max(1, rows - protected)
            for i in range(1, upper_bottom + 1):
                sys.stdout.write(f'\x1b[{i};1H\x1b[2K')
            sys.stdout.flush()
        except Exception:
            pass

    def _install_sigttou_handler(self) -> None:

        def on_sigttou(signum, frame) -> None:
            return

        def on_sigwinch(signum, frame) -> None:
            self._rebalance_output_budget()
        try:
            signal.signal(signal.SIGTTOU, on_sigttou)
        except Exception:
            pass
        try:
            signal.signal(signal.SIGWINCH, on_sigwinch)
        except Exception:
            pass

    def _load_or_create_session(self) -> None:
        wd = self.work_dir
        opts = self.opts
        self._session_initialized = False
        self._resumed = False
        session_meta_dir = '.nimbie'
        session_global_root = Path.home() / '.nimbie' / 'global_sessions'
        if opts.fork_session_id is not None:
            if not opts.resume_id:
                raise click.ClickException('--fork requires --resume-id to specify source session')
            source_session = Context.resume_session(wd, opts.resume_id, meta_dirname=session_meta_dir, global_sessions_root=session_global_root)
            if source_session is None:
                raise click.ClickException(f'source session not found: {opts.resume_id}')
            source_session.restore()
            self.ctx = source_session
            return
        session = None
        if opts.resume_id:
            session = Context.resume_session(wd, opts.resume_id, meta_dirname=session_meta_dir, global_sessions_root=session_global_root)
            if session is None:
                session = Context.create_session(wd, defer_persist=True, meta_dirname=session_meta_dir, global_sessions_root=session_global_root)
        elif not opts.new_session:
            session = Context.continue_session(wd, meta_dirname=session_meta_dir, global_sessions_root=session_global_root)
        if session is not None:
            self.session = session
            self.ctx = session
            self.ctx.restore()
            self._session_initialized = True
            self._resumed = True
            return

    def _start_web_server(self) -> None:
        try:
            token = None
            try:
                token = getattr(self.opts.ui_config, 'web_token', None)
            except Exception:
                token = None
            self._web_server = BrowserGatewayServer(self, self.work_dir, token=token)
            self._web_server.bind_loop(self._loop)
            self._web_server.start()
            host_ip = self._get_default_route_ip() or '127.0.0.1'
            self.console.print(f'[info] Web UI (listen 0.0.0.0): http://{host_ip}:{self._web_server.port}/?token={self._web_server.token}')
        except Exception as exc:
            self.console.print(f'[warning] Web server failed to start: {exc}')
            self._web_server = None

    def _stop_web_server(self) -> None:
        if self._web_server is None:
            return
        try:
            self._web_server.stop()
        except Exception:
            pass

    def _get_default_route_ip(self) -> Optional[str]:
        try:
            import socket
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.connect(('8.8.8.8', 80))
                return s.getsockname()[0]
            finally:
                s.close()
        except Exception:
            return None

    def _ensure_session_initialized(self) -> None:
        """Lazily initialize session on first user message."""
        if self._session_initialized:
            return
        wd = self.work_dir
        opts = self.opts
        session_meta_dir = '.nimbie'
        session_global_root = Path.home() / '.nimbie' / 'global_sessions'
        if opts.fork_session_id is not None:
            session = Context.fork_session(wd, opts.resume_id, opts.fork_session_id, meta_dirname=session_meta_dir, global_sessions_root=session_global_root)
            self.console.print(f'[info] Forked from session {opts.resume_id} -> {session.session_id}')
            self.session = session
            self.ctx = session
        else:
            session = Context.create_session(wd, defer_persist=True, meta_dirname=session_meta_dir, global_sessions_root=session_global_root)
            self.session = session
            self.ctx = session
        self._session_initialized = True
        self._ensure_system_prompt()
        self.agent = Oturn(self.session.work_dir, self._build_oturn_config(), tools=self._build_agent_tools())
        self.agent.subscribe(self.event_q)
        self._agent_task = asyncio.create_task(self.agent.run_queues(self.ctx))
        if self._lazy_input_task is None or self._lazy_input_task.done():
            self._lazy_input_task = asyncio.create_task(self._lazy_input_loop())

    def _ensure_system_prompt(self) -> None:
        if self.ctx is None:
            return
        try:
            if not any((getattr(m, 'role', '') == 'system' for m in self.ctx.history)):
                self.ctx.append_message(Message(role='system', content=get_system_prompt(self.work_dir)))
        except Exception:
            pass

    def _print_last_assistant_if_resumed(self) -> None:
        if not getattr(self, '_resumed', False):
            return
        try:
            for m in reversed(list(self.ctx.history)):
                if getattr(m, 'role', '') == 'assistant' and (getattr(m, 'content', '') or '').strip():
                    self.console.print(Markdown(m.content))
                    break
        except Exception:
            pass

    def _coerce_messages(self, msgs: list[Any]) -> list[dict]:
        out: list[dict] = []
        for m in msgs:
            rec: dict[str, Any] = {}
            if isinstance(m, dict):
                rec.update(m)
                rec.setdefault('role', str(m.get('role', '?')))
                content = m.get('content', m)
                if isinstance(content, BaseModel):
                    content = content.model_dump()
                rec['content'] = content
            elif is_dataclass(m):
                d = asdict(m)
                rec.update(d)
                rec.setdefault('role', str(d.get('role', '?')))
                rec['content'] = d.get('content', d)
            else:
                role = getattr(m, 'role', '?')
                content = getattr(m, 'content', None)
                if isinstance(content, BaseModel):
                    content = content.model_dump()
                if content is None:
                    content = repr(m)
                try:
                    rec.update(dict(vars(m)))
                except Exception:
                    pass
                rec.setdefault('role', str(role))
                rec['content'] = content
                rec.setdefault('__repr__', repr(m))
            out.append(rec)
        return out

    def build_context_markdown(self) -> tuple[str, list[dict]]:
        if self.ctx is None:
            return ('', [])
        records = self._coerce_messages(list(self.ctx.history))
        parts: list[str] = []
        for rec in records:
            try:
                md = _render_record_to_md(rec)
            except Exception:
                md = ''
            if md.strip():
                parts.append(md.strip() + '\n')
                continue
            role = str(rec.get('role') or '')
            content = rec.get('content', '')
            parts.append(f'## {role}\n{content}\n')
        return ('\n'.join(parts).strip(), records)

    def enqueue_input(self, text: str, status: str='agent', input_type: str='default') -> bool:
        loop = self._loop
        if loop is None or loop.is_closed():
            return False

        def _do() -> None:
            self._force_cancel_ptk()
            self._defer_prompt_refresh = True
            self._ensure_session_initialized()
            try:
                if self.agent is not None and hasattr(self.agent, 'enqueue_user_input_nowait'):
                    pushed = bool(self.agent.enqueue_user_input_nowait(text=text, status=status, input_type=input_type))
                    if pushed:
                        return
            except Exception:
                pass
        try:
            loop.call_soon_threadsafe(_do)
            return True
        except Exception:
            return False

    def submit_web_command(self, text: str, mode: str='auto', input_type: str='default') -> dict:
        loop = self._loop
        if loop is None or loop.is_closed():
            return {'ok': False, 'error': 'loop_unavailable'}

        def _err_text(exc: Exception) -> str:
            msg = str(exc) if exc is not None else ''
            return msg if msg else repr(exc)
        result_fut: ThreadFuture = ThreadFuture()

        def _set_result(payload: dict) -> None:
            if not result_fut.done():
                result_fut.set_result(payload)

        async def _run_shell_web_async(s: str, mode_label: str) -> None:
            try:
                shell_result = await asyncio.to_thread(self._run_shell_and_build_summary, s)
                try:
                    self.ctx.append_message(Message(role='user', content=shell_result))
                except Exception as exc:
                    _set_result({'ok': False, 'mode': mode_label, 'dispatched': 'shell', 'error': f'append_shell_result_failed: {_err_text(exc)}'})
                    return
                _set_result({'ok': True, 'mode': mode_label, 'dispatched': 'shell', 'shell_result': shell_result.model_dump() if hasattr(shell_result, 'model_dump') else None})
            except Exception as exc:
                _set_result({'ok': False, 'mode': mode_label, 'dispatched': 'shell', 'error': f'shell_run_failed: {_err_text(exc)}'})

        def _do() -> None:
            try:
                s = (text or '').strip()
                if not s:
                    _set_result({'ok': False, 'error': 'empty'})
                    return
                self._force_cancel_ptk()
                self._defer_prompt_refresh = True
                self._ensure_session_initialized()
                m = (mode or 'auto').strip().lower()
                if m not in {'shell', 'agent', 'auto'}:
                    m = 'auto'
                if m == 'shell':
                    asyncio.create_task(_run_shell_web_async(s, 'shell'))
                    return
                if m == 'auto':
                    should_run, reason = self.shell.auto_should_run_shell(s)
                    if should_run:
                        asyncio.create_task(_run_shell_web_async(s, 'auto'))
                        return
                    if reason:
                        try:
                            self.renderer.print_warning(f'Auto mode deferred to agent: {reason}; delegating to agent.')
                        except Exception:
                            pass
                pushed = False
                try:
                    if self.agent is not None and hasattr(self.agent, 'enqueue_user_input_nowait'):
                        pushed = bool(self.agent.enqueue_user_input_nowait(text=s, status='agent', input_type=input_type))
                except Exception:
                    pushed = False
                _set_result({'ok': bool(pushed), 'mode': m, 'dispatched': 'agent'})
            except Exception as exc:
                _set_result({'ok': False, 'error': _err_text(exc)})
        try:
            loop.call_soon_threadsafe(_do)
            return result_fut.result(timeout=2.0)
        except ThreadTimeoutError:
            return {'ok': False, 'error': 'timeout'}
        except Exception as exc:
            msg = str(exc) if exc is not None else ''
            return {'ok': False, 'error': msg if msg else repr(exc)}

    def _call_agent_queue_op(self, op: str, **kwargs: Any) -> dict:
        loop = self._loop
        if loop is None or loop.is_closed():
            return {'ok': False, 'error': 'loop_unavailable'}
        result_fut: ThreadFuture = ThreadFuture()

        def _set_result(payload: dict) -> None:
            if not result_fut.done():
                result_fut.set_result(payload)

        def _do() -> None:
            try:
                self._ensure_session_initialized()
                agent = self.agent
                if agent is None:
                    _set_result({'ok': False, 'error': 'agent_unavailable'})
                    return
                if op == 'snapshot':
                    limit = int(kwargs.get('limit', 100))
                    if hasattr(agent, 'get_input_queue_snapshot'):
                        items = agent.get_input_queue_snapshot(limit=limit)
                    else:
                        items = []
                    _set_result({'ok': True, 'items': items, 'size': len(items)})
                    return
                if op == 'dequeue':
                    item = agent.dequeue_user_input_nowait() if hasattr(agent, 'dequeue_user_input_nowait') else None
                    _set_result({'ok': True, 'item': item})
                    return
                if op == 'clear':
                    removed = int(agent.clear_user_input_queue()) if hasattr(agent, 'clear_user_input_queue') else 0
                    _set_result({'ok': True, 'removed': removed})
                    return
                if op == 'count':
                    count = int(agent.pending_input_count()) if hasattr(agent, 'pending_input_count') else 0
                    _set_result({'ok': True, 'count': count})
                    return
                _set_result({'ok': False, 'error': f'unknown_op:{op}'})
            except Exception as exc:
                _set_result({'ok': False, 'error': str(exc)})
        try:
            loop.call_soon_threadsafe(_do)
            return result_fut.result(timeout=2.0)
        except ThreadTimeoutError:
            return {'ok': False, 'error': 'timeout'}
        except Exception as exc:
            return {'ok': False, 'error': str(exc)}

    def input_queue_snapshot(self, limit: int=100) -> dict:
        return self._call_agent_queue_op('snapshot', limit=limit)

    def input_queue_dequeue(self) -> dict:
        return self._call_agent_queue_op('dequeue')

    def input_queue_clear(self) -> dict:
        return self._call_agent_queue_op('clear')

    def input_queue_pending_count(self) -> int:
        result = self._call_agent_queue_op('count')
        if result.get('ok'):
            try:
                return int(result.get('count', 0))
            except Exception:
                return 0
        return 0

    def complete_input(self, text: str, cursor: int, cwd: Optional[str]=None, max_items: int=50) -> dict:
        loop = self._loop
        if loop is None or loop.is_closed():
            return {'ok': False, 'error': 'loop_unavailable', 'items': []}

        def _compute() -> dict:
            from prompt_toolkit.document import Document
            from prompt_toolkit.completion import CompleteEvent
            shell_obj = getattr(self.shell, 'shell', None)
            completer = getattr(shell_obj, 'pt_completer', None)
            if completer is None:
                return {'ok': False, 'error': 'completer_unavailable', 'items': []}
            doc = Document(text or '', cursor_position=max(0, int(cursor)))
            if cwd:
                setattr(doc, 'custom_cwd', str(cwd))
            items: list[dict] = []
            for comp in completer.get_completions(doc, CompleteEvent(completion_requested=True)):
                items.append({'text': comp.text, 'start_position': comp.start_position, 'display': getattr(comp, 'display_text', None) or comp.text, 'display_meta': getattr(comp, 'display_meta_text', None) or ''})
                if len(items) >= int(max_items):
                    break
            return {'ok': True, 'items': items}
        try:
            running = asyncio.get_running_loop()
        except Exception:
            running = None
        if running is loop:
            try:
                return _compute()
            except Exception as exc:
                return {'ok': False, 'error': str(exc), 'items': []}
        result_fut: ThreadFuture = ThreadFuture()

        def _set_result(payload: dict) -> None:
            if not result_fut.done():
                result_fut.set_result(payload)

        def _do() -> None:
            try:
                _set_result(_compute())
            except Exception as exc:
                _set_result({'ok': False, 'error': str(exc), 'items': []})
        try:
            loop.call_soon_threadsafe(_do)
            return result_fut.result(timeout=2.0)
        except ThreadTimeoutError:
            return {'ok': False, 'error': 'timeout', 'items': []}
        except Exception as exc:
            return {'ok': False, 'error': str(exc), 'items': []}

    def _force_cancel_ptk(self) -> None:
        try:
            if self._main_app is not None:
                self._invalidate_main_app()
                return
            app = self._ptk_app
            if app is not None:
                app.exit()
        except Exception:
            pass

    def _ui_call_soon(self, fn: Any, *args: Any) -> None:
        loop = self._ui_loop
        if loop is None or loop.is_closed():
            return
        try:
            loop.call_soon_threadsafe(fn, *args)
        except Exception:
            pass

    def _invalidate_main_app(self) -> None:
        app = self._main_app
        if app is None:
            return
        self._ui_call_soon(app.invalidate)

    def _request_main_app_exit(self) -> None:
        app = self._main_app
        if app is None:
            return
        if self._ui_exit_requested:
            return
        self._ui_exit_requested = True

        def _do_exit() -> None:
            try:
                done = getattr(app, 'is_done', False)
                if bool(done):
                    return
            except Exception:
                pass
            try:
                running = getattr(app, 'is_running', None)
                if running is not None and (not bool(running)):
                    return
            except Exception:
                pass
            try:
                app.exit(result=None)
            except Exception as exc:
                msg = str(exc)
                if 'Return value already set' in msg or 'Application is not running' in msg:
                    return
                return
        self._ui_call_soon(_do_exit)

    def _start_esc_cancel_if_needed(self) -> None:
        if self._main_app is not None:
            return
        try:
            self.esc_cancel.start(self.agent)
        except Exception:
            pass

    def _status_line_text(self) -> str:
        mode = self.MODE.upper()
        usage = '-'
        if isinstance(self.USAGE_TOTAL, (int, float)):
            usage = f'{self.USAGE_TOTAL / 1000:.1f}K'
        req = self._request_phase
        pty_focus = '-'
        if self._pty_session_active:
            pty_focus = 'PTY' if self._pty_focus_mode else 'PTK'
        try:
            cols = max(20, int(shutil.get_terminal_size((80, 24)).columns))
        except Exception:
            cols = 80
        full = f'mode={mode} req={req} focus={pty_focus} usage={usage} | F2 mode | F3 focus | F1 history | F6 bg | F10/Ctrl-Q exit'
        mid = f'm={mode} r={req} f={pty_focus} u={usage} | F2 mode | F3 focus | F1 hist | F10 exit'
        short = f'{mode} {req} {pty_focus} {usage} | F2/F10'
        if cols >= 100:
            return self._fit_single_line(full)
        if cols >= 72:
            return self._fit_single_line(mid)
        return self._fit_single_line(short)

    def _footer_fragments(self) -> list[tuple[str, str]]:
        if self._inline_action_active():
            return self._inline_action_fragments()
        txt = self._fit_single_line(self._status_line_text(), keep_tail_pad=True)
        return [('', txt)]

    def _inline_action_active(self) -> bool:
        return bool(self._inline_action_visible and self._inline_action_kind)

    def _inline_action_rows(self) -> int:
        return 0

    def _bottom_reserved_rows(self) -> int:
        if self._inline_action_active():
            input_rows = 0
        else:
            input_rows = max(1, int(getattr(self, '_last_input_visual_lines', 1)))
        return input_rows + 2 + self._inline_action_rows()

    def _trim_inline_text(self, text: str, limit: int=160) -> str:
        s = str(text or '').replace('\n', ' ').strip()
        if len(s) <= limit:
            return s
        return s[:max(0, limit - 1)] + '…'

    def _terminal_cols(self, default: int=80) -> int:
        try:
            return max(20, int(shutil.get_terminal_size((default, 24)).columns))
        except Exception:
            return default

    def _fit_single_line(self, text: str, *, keep_tail_pad: bool=False) -> str:
        cols = self._terminal_cols(80)
        usable = max(1, cols - 1)
        s = str(text or '').replace('\n', ' ').replace('\r', ' ')
        s = self._slice_by_display_width(s, usable)
        if keep_tail_pad:
            pad = max(0, usable - self._display_width(s))
            if pad:
                s += ' ' * pad
        return s

    def _display_width(self, text: str) -> int:
        total = 0
        for ch in str(text or ''):
            if unicodedata.combining(ch):
                continue
            total += 2 if unicodedata.east_asian_width(ch) in {'W', 'F'} else 1
        return total

    def _slice_by_display_width(self, text: str, max_width: int) -> str:
        out: list[str] = []
        used = 0
        for ch in str(text or ''):
            if ch in ('\n', '\r'):
                ch = ' '
            if unicodedata.combining(ch):
                out.append(ch)
                continue
            w = 2 if unicodedata.east_asian_width(ch) in {'W', 'F'} else 1
            if used + w > max_width:
                break
            out.append(ch)
            used += w
        return ''.join(out)

    def _inline_action_text(self) -> str:
        if not self._inline_action_active():
            return ''
        if self._inline_action_kind == 'approval':
            tool = self._inline_action_tool or 'tool'
            if tool == 'execute_shell_command':
                return '[exec approval] Y Allow  N/Esc Deny'
            return f'[approval] {tool} | Y Allow  N/Esc Deny'
        if self._inline_action_kind == 'choice':
            choices = self._inline_action_choices or []
            if not choices:
                return '[choice] (empty) | Enter Confirm  Esc Cancel'
            idx = max(0, min(self._inline_action_selected, len(choices) - 1))
            try:
                cols = max(20, int(shutil.get_terminal_size((80, 24)).columns))
            except Exception:
                cols = 80
            if cols < 56:
                curr = self._trim_inline_text(choices[idx], limit=18)
                line = f'[C] {idx + 1}/{len(choices)} {curr} | Tab ^v Enter Esc'
                return line
            if cols < 80:
                curr = self._trim_inline_text(choices[idx], limit=28)
                line = f'[choice] {idx + 1}/{len(choices)}: {curr} | Tab/Up/Down Enter Esc'
                return line
            curr = self._trim_inline_text(choices[idx], limit=56)
            line = f'[choice] {idx + 1}/{len(choices)}: {curr} | Tab/Up/Down Cycle  Enter Confirm  Esc Cancel'
            return line
        return ''

    def _inline_action_fragments(self) -> list[tuple[str, str]]:
        txt = self._inline_action_text()
        if not txt:
            return []
        cut = self._fit_single_line(txt, keep_tail_pad=True)
        return [('reverse', cut)]

    def _activate_inline_action_approval(self, tool: str, message: str, reasons: list[str], fut: Any) -> None:
        buf = self._input_buffer
        if buf is not None:
            try:
                self._inline_action_input_snapshot = (str(buf.text or ''), int(buf.cursor_position))
            except Exception:
                self._inline_action_input_snapshot = None
        self._inline_action_preserved_input_rows = 1
        self._inline_action_visible = True
        self._inline_action_kind = 'approval'
        self._inline_action_tool = str(tool or '')
        self._inline_action_message = str(message or '')
        self._inline_action_reasons = [str(r) for r in reasons or []]
        self._inline_action_choices = []
        self._inline_action_selected = 1
        self._inline_action_future = fut
        self._focus_footer_window()
        self._rebalance_output_budget()
        self._invalidate_main_app()

    def _activate_inline_action_choice(self, prompt: str, choices: list[str], fut: Any) -> None:
        buf = self._input_buffer
        if buf is not None:
            try:
                self._inline_action_input_snapshot = (str(buf.text or ''), int(buf.cursor_position))
            except Exception:
                self._inline_action_input_snapshot = None
        self._inline_action_preserved_input_rows = 1
        self._inline_action_visible = True
        self._inline_action_kind = 'choice'
        self._inline_action_tool = ''
        self._inline_action_message = str(prompt or 'Please choose an option')
        self._inline_action_reasons = []
        self._inline_action_choices = [str(c) for c in choices or []]
        self._inline_action_selected = 0
        self._inline_action_future = fut
        self._focus_footer_window()
        self._rebalance_output_budget()
        self._invalidate_main_app()

    def _deactivate_inline_action(self) -> None:
        was_active = self._inline_action_active()
        snap = self._inline_action_input_snapshot
        self._inline_action_visible = False
        self._inline_action_kind = ''
        self._inline_action_tool = ''
        self._inline_action_message = ''
        self._inline_action_reasons = []
        self._inline_action_choices = []
        self._inline_action_selected = 0
        self._inline_action_future = None
        self._inline_action_input_snapshot = None
        self._inline_action_preserved_input_rows = max(1, int(getattr(self, '_last_input_visual_lines', 1)))
        buf = self._input_buffer
        if snap is not None and buf is not None:
            try:
                text, cursor = snap
                buf.text = text
                buf.cursor_position = max(0, min(int(cursor), len(buf.text)))
            except Exception:
                pass
        self._focus_input_window()
        if was_active:
            self._rebalance_output_budget()
            self._invalidate_main_app()

    def _focus_footer_window(self) -> None:
        app = self._main_app
        win = self._footer_window
        if app is None or win is None:
            return
        try:
            app.layout.focus(win)
            app.invalidate()
        except Exception:
            pass

    def _focus_input_window(self) -> None:
        app = self._main_app
        win = self._input_window
        if app is None or win is None:
            return
        try:
            app.layout.focus(win)
            self._force_full_repaint()
            app.invalidate()
        except Exception:
            pass

    def _force_full_repaint(self) -> None:
        app = self._main_app
        if app is None:
            return
        try:
            renderer = getattr(app, 'renderer', None)
            if renderer is not None:
                if hasattr(renderer, '_last_screen'):
                    renderer._last_screen = None
                if hasattr(renderer, '_last_size'):
                    renderer._last_size = None
                if hasattr(renderer, '_last_style'):
                    renderer._last_style = None
        except Exception:
            pass

    def _resolve_future_threadsafe(self, fut: Any, payload: Any) -> None:
        fut_loop = None
        if isinstance(fut, asyncio.Future):
            try:
                fut_loop = fut.get_loop()
            except Exception:
                fut_loop = None
        loop = fut_loop or self._loop
        if loop is not None and (not loop.is_closed()):
            try:
                loop.call_soon_threadsafe(self._set_future, fut, payload)
                return
            except Exception:
                pass
        self._set_future(fut, payload)

    def _inline_finish(self, payload: dict) -> None:
        fut = self._inline_action_future
        self._suppress_enter_until_ts = time.monotonic() + 0.2
        self._deactivate_inline_action()
        self._resolve_future_threadsafe(fut, payload)

    def _inline_cycle_choice(self, delta: int) -> None:
        if self._inline_action_kind != 'choice':
            return
        choices = self._inline_action_choices
        if not choices:
            return
        n = len(choices)
        self._inline_action_selected = (int(self._inline_action_selected) + int(delta)) % n
        self._invalidate_main_app()

    def _inline_handle_any_key(self, key_data: str) -> None:
        if not self._inline_action_active():
            return
        ch = str(key_data or '').strip().lower()
        if self._inline_action_kind == 'approval':
            reasons = list(self._inline_action_reasons)
            if ch in {'y', 'a', '1'}:
                self._inline_finish({'approved': True, 'decision': 'ALLOW', 'reasons': reasons})
            elif ch in {'n', 'd', '0'}:
                self._inline_finish({'approved': False, 'decision': 'DENIED', 'reasons': reasons})
            return
        if self._inline_action_kind == 'choice':
            if ch in {'j', 'l'}:
                self._inline_cycle_choice(+1)
                return
            if ch in {'k', 'h'}:
                self._inline_cycle_choice(-1)
                return
            if ch.isdigit():
                idx = int(ch) - 1
                if 0 <= idx < len(self._inline_action_choices):
                    self._inline_action_selected = idx
                    self._invalidate_main_app()
            return

    def _pty_mode_active(self) -> bool:
        return bool(self._pty_session_active and self._pty_focus_mode)

    def _drain_pty_input_queue(self) -> None:
        while True:
            try:
                self._pty_stdin_q.get_nowait()
            except queue.Empty:
                break
            except Exception:
                break

    def _send_pty_input(self, data: bytes) -> bool:
        if not self._pty_session_active or not data:
            return False
        try:
            self._pty_stdin_q.put_nowait(data)
            return True
        except Exception:
            return False

    def _toggle_pty_focus(self) -> None:
        if not self._pty_session_active:
            return
        self._pty_focus_mode = not self._pty_focus_mode
        self._invalidate_main_app()
        self._ui_call_soon(self._position_cursor_for_focus)

    def _position_cursor_for_focus(self) -> None:
        try:
            if self._inline_action_active():
                return
            rows = max(1, int(shutil.get_terminal_size((120, 40)).lines))
            cols = max(1, int(shutil.get_terminal_size((120, 40)).columns))
            protected = max(2, int(self._bottom_reserved_rows()))
            protected = min(protected, rows - 1)
            scroll_bottom = max(1, rows - protected)
            protected_top = max(1, scroll_bottom + 1)
            if self._pty_mode_active():
                row = max(1, min(int(getattr(self, '_pty_cursor_row', 1)), scroll_bottom))
                col = max(1, min(int(getattr(self, '_pty_cursor_col', 1)), cols))
            else:
                row, col = self._input_cursor_terminal_pos()
            sys.stdout.write(f'\x1b[{row};{col}H')
            sys.stdout.flush()
        except Exception:
            pass

    def _track_pty_cursor(self, text: str, *, scroll_bottom: int, cols: int) -> None:
        if not text:
            return
        row = max(1, min(int(getattr(self, '_pty_cursor_row', 1)), max(1, int(scroll_bottom))))
        col = max(1, min(int(getattr(self, '_pty_cursor_col', 1)), max(1, int(cols))))
        i = 0
        n = len(text)
        while i < n:
            ch = text[i]
            if ch == '\x1b' and i + 1 < n and (text[i + 1] == '['):
                j = i + 2
                while j < n and (not '@' <= text[j] <= '~'):
                    j += 1
                if j >= n:
                    break
                params = text[i + 2:j]
                final = text[j]
                parts = [p for p in params.split(';') if p != '']

                def _p(idx: int, default: int=1) -> int:
                    try:
                        return int(parts[idx]) if idx < len(parts) else default
                    except Exception:
                        return default
                if final == 'A':
                    row -= _p(0, 1)
                elif final == 'B':
                    row += _p(0, 1)
                elif final == 'C':
                    col += _p(0, 1)
                elif final == 'D':
                    col -= _p(0, 1)
                elif final == 'E':
                    row += _p(0, 1)
                    col = 1
                elif final == 'F':
                    row -= _p(0, 1)
                    col = 1
                elif final == 'G':
                    col = _p(0, 1)
                elif final in {'H', 'f'}:
                    row = _p(0, 1)
                    col = _p(1, 1)
                elif final == 'd':
                    row = _p(0, 1)
                row = max(1, min(row, max(1, int(scroll_bottom))))
                col = max(1, min(col, max(1, int(cols))))
                i = j + 1
                continue
            if ch == '\n':
                row += 1
                col = 1
            elif ch == '\r':
                col = 1
            elif ch == '\x08':
                col = max(1, col - 1)
            else:
                o = ord(ch)
                if o >= 32:
                    col += 1
                    if col > cols:
                        col = 1
                        row += 1
            row = max(1, min(row, max(1, int(scroll_bottom))))
            col = max(1, min(col, max(1, int(cols))))
            i += 1
        self._pty_cursor_row = row
        self._pty_cursor_col = col

    def _prompt_prefix_text(self) -> str:
        return '> '

    def _display_prompt_text(self) -> str:
        return str(self._display_prompt_cache_text or '')

    def _refresh_display_prompt_cache(self, *, raise_on_error: bool=False, force: bool=False) -> None:
        now = time.monotonic()
        if not force and now - float(getattr(self, '_display_prompt_cache_ts', 0.0)) < 0.2:
            return
        try:
            p = str(self.shell.build_prompt() or '')
        except Exception:
            if raise_on_error:
                raise
            self._display_prompt_cache_ts = now
            return
        if p:
            self._display_prompt_cache_text = p
        self._display_prompt_cache_ts = now

    def _schedule_prompt_refresh(self, *, force: bool=False) -> None:
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        task = self._prompt_refresh_task
        if task is not None and (not task.done()):
            return

        async def _run() -> None:
            try:
                await asyncio.to_thread(self._refresh_display_prompt_cache, force=force)
            except Exception:
                return
            if self._main_app is not None:
                try:
                    self._invalidate_main_app()
                except Exception:
                    pass
        self._prompt_refresh_task = loop.create_task(_run())

    def _separator_line_text(self) -> str:
        try:
            cols = max(8, int(shutil.get_terminal_size((80, 24)).columns))
        except Exception:
            cols = 80
        p = str(self._display_prompt_text() or '').replace('\n', ' ').replace('\r', ' ').strip()
        if not p:
            return '─' * cols
        left_bar = '─' * 5
        left_bar_w = max(0, int(self._display_width(left_bar)))
        if left_bar_w >= cols:
            return self._slice_by_display_width(left_bar, cols)
        core = f' {p} '
        core_w = max(0, int(self._display_width(core)))
        rem = cols - left_bar_w
        if core_w >= rem:
            return left_bar + self._slice_by_display_width(core, rem)
        right = rem - core_w
        return left_bar + core + '─' * right

    def _mark_input_activity(self) -> None:
        self._last_input_activity_ts = time.monotonic()

    async def _main_stream_delta(self, kind: str, delta: str) -> None:
        if not delta:
            return
        if kind not in self._main_stream_pending:
            return
        self._main_stream_pending[kind] += delta
        await self._flush_main_stream_kind(kind, force=False)

    async def _flush_main_stream_kind(self, kind: str, force: bool) -> None:
        pending = self._main_stream_pending.get(kind, '')
        if not pending:
            return
        now = time.monotonic()
        interval = max(0.05, float(self._main_stream_flush_interval_s))
        if not force and now - float(self._main_stream_last_flush_ts.get(kind, 0.0)) < interval:
            if len(pending.encode('utf-8', errors='ignore')) < max(1024, int(self._main_stream_force_flush_bytes)):
                return
        self._main_stream_pending[kind] = ''
        self._main_stream_last_flush_ts[kind] = now
        stream = self._main_reasoning_stream if kind == 'reasoning' else self._main_content_stream
        stream.push_delta(pending)
        lines = stream.commit_complete_lines()
        if not lines:
            return
        text = await asyncio.to_thread(self._render_rich_lines_to_ansi, lines)
        if text:
            self._push_output('assistant_' + kind, text, False)

    async def _flush_main_streams(self) -> None:
        try:
            await self._flush_main_stream_kind('reasoning', force=True)
            await self._flush_main_stream_kind('content', force=True)
            reason_lines = self._main_reasoning_stream.finalize_and_drain()
            if reason_lines:
                txt = await asyncio.to_thread(self._render_rich_lines_to_ansi, reason_lines)
                if txt:
                    self._push_output('assistant_reasoning', txt, False)
            content_lines = self._main_content_stream.finalize_and_drain()
            if content_lines:
                txt = await asyncio.to_thread(self._render_rich_lines_to_ansi, content_lines)
                if txt:
                    self._push_output('assistant', txt, False)
        except Exception:
            pass
        try:
            self._main_reasoning_stream.clear()
            self._main_content_stream.clear()
            self._main_stream_pending['reasoning'] = ''
            self._main_stream_pending['content'] = ''
        except Exception:
            pass

    def _is_user_composing_input(self) -> bool:
        buf = self._input_buffer
        if buf is None:
            return False
        try:
            return bool(buf.text)
        except Exception:
            return False

    def _render_rich_lines_to_ansi(self, lines: list[Any]) -> str:
        if not lines:
            return ''
        try:
            width = max(20, int(getattr(self, '_output_budget_cols', 120)))
            c = Console(force_terminal=True, highlight=False, soft_wrap=False, width=width, color_system='truecolor')
            with c.capture() as cap:
                for line in lines:
                    c.print(line)
            return cap.get()
        except Exception:
            return ''.join((getattr(line, 'plain', str(line)) + '\n' for line in lines))

    def _input_cursor_terminal_pos(self) -> tuple[int, int]:
        rows = max(1, int(shutil.get_terminal_size((120, 40)).lines))
        cols = max(1, int(shutil.get_terminal_size((120, 40)).columns))
        input_rows = max(1, int(getattr(self, '_last_input_visual_lines', 1)))
        action_rows = max(0, int(self._inline_action_rows()))
        input_bottom = max(1, rows - 1 - action_rows)
        input_top = max(1, input_bottom - input_rows + 1)
        buf = self._input_buffer
        if buf is None:
            return (input_top, 1)
        try:
            before = buf.document.text_before_cursor
        except Exception:
            before = ''
        prompt_prefix = len(self._prompt_prefix_text())
        logical_lines = before.split('\n')
        visual_row_offset = 0
        col = 1
        for idx, line in enumerate(logical_lines):
            prefix = prompt_prefix if idx == 0 else 0
            used = prefix + len(line)
            wraps = used // cols
            rem = used % cols
            if idx < len(logical_lines) - 1:
                visual_row_offset += max(1, wraps + (1 if rem > 0 else 0))
            else:
                visual_row_offset += wraps
                col = rem + 1
        row = input_top + visual_row_offset
        row = max(input_top, min(input_bottom, row))
        col = max(1, min(cols, col))
        return (row, col)

    def _render_output_text(self) -> str:
        rows = 20
        try:
            sz = shutil.get_terminal_size((120, 40))
            rows = max(1, int(sz.lines) - int(self._bottom_reserved_rows()))
        except Exception:
            pass
        try:
            return self.output_hub.snapshot_visible(max_rows=rows)
        except Exception:
            return ''

    def _on_input_buffer_changed(self) -> None:
        try:
            self._mark_input_activity()
            buf = self._input_buffer
            if buf is None:
                return
            cols = shutil.get_terminal_size((120, 40)).columns
            rows = self._estimate_visual_lines(buf.text or '', cols)
            rows = max(1, min(8, rows))
            prev_rows = int(getattr(self, '_last_input_visual_lines', 1))
            self._last_input_visual_lines = rows
            if rows != prev_rows:
                if self._input_window is not None:
                    self._input_window.height = Dimension.exact(rows)
                try:
                    self.output_hub.set_protected_bottom_rows(self._bottom_reserved_rows())
                except Exception:
                    pass
                self._rebalance_output_budget()
                if self._main_app is not None:
                    self._invalidate_main_app()
        except Exception:
            pass

    def _submit_current_input(self) -> None:
        self._mark_input_activity()
        buf = self._input_buffer
        if buf is None:
            return
        text = buf.text
        try:
            self._push_output('input', self._format_submitted_input_echo(text), False)
        except Exception:
            pass
        try:
            if text.strip():
                hist = getattr(buf, 'history', None)
                if hist is not None and hasattr(hist, 'append_string'):
                    hist.append_string(text)
        except Exception:
            pass
        buf.text = ''
        self._on_input_buffer_changed()
        try:
            loop = self._loop
            if loop is not None and (not loop.is_closed()):
                self._defer_prompt_refresh = True
                loop.call_soon_threadsafe(self._input_line_queue.put_nowait, text)
        except Exception:
            pass

    def _format_submitted_input_echo(self, text: str) -> str:
        raw = str(text or '')
        prefix = self._display_prompt_text()
        if raw == '':
            return f'{prefix}\n'
        colored = self._colorize_input_echo(raw)
        lines = colored.splitlines()
        if not lines:
            return f'{prefix}\n'
        out: list[str] = [f'{prefix}{lines[0]}']
        if len(lines) > 1:
            out.extend(lines[1:])
        return '\n'.join(out) + '\n'

    def _colorize_input_echo(self, raw: str) -> str:
        lexer_cls = self._echo_lexer_cls
        if lexer_cls is None or _pyg_highlight is None or _PygTermFormatter is None:
            return raw
        try:
            return str(_pyg_highlight(raw, lexer_cls(), _PygTermFormatter())).rstrip('\n')
        except Exception:
            return raw

    def _build_main_application(self) -> Application:
        from prompt_toolkit.keys import Keys
        from prompt_toolkit.filters import Condition
        shell_obj = getattr(self.shell, 'shell', None)
        completer = getattr(shell_obj, 'pt_completer', None)
        history = getattr(shell_obj, '_history', None)
        autosuggest = getattr(shell_obj, '_autosuggest', None)
        lexer = None
        style = None
        try:
            build_lexer = getattr(shell_obj, '_build_lexer', None)
            if callable(build_lexer):
                lexer = build_lexer()
        except Exception:
            lexer = None
        try:
            self._echo_lexer_cls = getattr(lexer, 'pygments_lexer_cls', None) if lexer is not None else None
        except Exception:
            self._echo_lexer_cls = None
        try:
            build_style = getattr(shell_obj, '_build_prompt_style', None)
            if callable(build_style):
                style = build_style()
        except Exception:
            style = None
        self._input_buffer = Buffer(completer=completer, history=history, auto_suggest=autosuggest, complete_while_typing=False, multiline=True, read_only=Condition(lambda: self._inline_action_active()))
        self._input_buffer.on_text_changed += lambda _: self._on_input_buffer_changed()
        self._input_window = Window(content=BufferControl(buffer=self._input_buffer, lexer=lexer, input_processors=[BeforeInput(self._prompt_prefix_text)]), wrap_lines=True, height=Dimension.exact(1))
        separator_window = Window(height=Dimension.exact(1), content=FormattedTextControl(text=lambda: self._separator_line_text()), dont_extend_height=True)
        footer_control = FormattedTextControl(text=lambda: self._footer_fragments(), focusable=Condition(lambda: self._inline_action_active()), get_cursor_position=lambda: Point(x=0, y=0))
        status_window = Window(height=Dimension.exact(1), content=footer_control, wrap_lines=False, dont_extend_height=True)
        self._footer_window = status_window
        self._inline_action_window = Window(height=Dimension.exact(1), content=FormattedTextControl(text=lambda: self._inline_action_fragments()), dont_extend_height=True, wrap_lines=False)
        input_container = ConditionalContainer(content=VSplit([self._input_window]), filter=Condition(lambda: not self._inline_action_active()))
        kb = KeyBindings()

        @kb.add('enter', filter=Condition(lambda: self._inline_action_active()), eager=True)
        def _on_enter_inline(event) -> None:
            if self._inline_action_kind == 'approval':
                reasons = list(self._inline_action_reasons)
                self._inline_finish({'approved': False, 'decision': 'DENIED', 'reasons': reasons})
            elif self._inline_action_kind == 'choice':
                choices = self._inline_action_choices
                idx = max(0, min(int(self._inline_action_selected), len(choices) - 1)) if choices else -1
                selected = choices[idx] if idx >= 0 else None
                self._inline_finish({'selected': selected, 'confirmed': bool(selected)})

        @kb.add('enter', filter=Condition(lambda: not self._inline_action_active()))
        def _on_enter(event) -> None:
            if time.monotonic() < float(getattr(self, '_suppress_enter_until_ts', 0.0)):
                return
            if self._pty_mode_active():
                self._send_pty_input(b'\n')
                return
            self._submit_current_input()

        @kb.add('escape', 'enter')
        def _on_alt_enter(event) -> None:
            try:
                event.current_buffer.insert_text('\n')
            except Exception:
                pass

        @kb.add('f10')
        @kb.add('c-q')
        def _on_exit(event) -> None:
            self._signal_exit()

        @kb.add('tab', filter=Condition(lambda: self._inline_action_active() and self._inline_action_kind == 'choice'), eager=True)
        def _on_tab_inline(event) -> None:
            self._inline_cycle_choice(+1)

        @kb.add('tab')
        def _on_tab(event) -> None:
            if self._inline_action_active():
                return
            if self._pty_mode_active():
                self._send_pty_input(b'\t')
                return
            try:
                event.current_buffer.start_completion(select_first=False)
            except Exception:
                pass

        @kb.add('f2')
        def _on_f2(event) -> None:
            self._toggle_mode()
            event.app.invalidate()

        @kb.add('f3')
        def _on_f3(event) -> None:
            self._toggle_pty_focus()
            event.app.invalidate()

        @kb.add('f1')
        def _on_f1(event) -> None:
            self._schedule_history_ui()

        @kb.add('f6')
        def _on_f6(event) -> None:
            self._schedule_background_manager()

        @kb.add('f4')
        def _on_f4(event) -> None:
            return

        @kb.add('up', filter=Condition(lambda: self._inline_action_active() and self._inline_action_kind == 'choice'), eager=True)
        def _on_up_inline(event) -> None:
            self._inline_cycle_choice(-1)

        @kb.add('up')
        def _on_up(event) -> None:
            if self._inline_action_active():
                return
            if self._pty_mode_active():
                self._send_pty_input(b'\x1b[A')
                return
            buf = event.current_buffer
            try:
                if buf.document.cursor_position_row == 0:
                    buf.history_backward()
                else:
                    buf.cursor_up(count=1)
            except Exception:
                pass

        @kb.add('down', filter=Condition(lambda: self._inline_action_active() and self._inline_action_kind == 'choice'), eager=True)
        def _on_down_inline(event) -> None:
            self._inline_cycle_choice(+1)

        @kb.add('down')
        def _on_down(event) -> None:
            if self._inline_action_active():
                return
            if self._pty_mode_active():
                self._send_pty_input(b'\x1b[B')
                return
            buf = event.current_buffer
            try:
                if buf.document.cursor_position_row >= max(0, buf.document.line_count - 1):
                    buf.history_forward()
                else:
                    buf.cursor_down(count=1)
            except Exception:
                pass

        @kb.add('left')
        def _on_left(event) -> None:
            if self._pty_mode_active():
                self._send_pty_input(b'\x1b[D')
                return
            try:
                event.current_buffer.cursor_left(count=1)
            except Exception:
                pass

        @kb.add('right')
        def _on_right(event) -> None:
            if self._pty_mode_active():
                self._send_pty_input(b'\x1b[C')
                return
            try:
                event.current_buffer.cursor_right(count=1)
            except Exception:
                pass

        @kb.add('c-c')
        def _on_ctrl_c(event) -> None:
            if self._pty_mode_active():
                self._send_pty_input(b'\x03')
                return
            try:
                event.current_buffer.reset()
            except Exception:
                pass

        @kb.add('backspace')
        def _on_backspace(event) -> None:
            if self._pty_mode_active():
                self._send_pty_input(b'\x7f')
                return
            try:
                event.current_buffer.delete_before_cursor(count=1)
            except Exception:
                pass

        @kb.add('escape', filter=Condition(lambda: self._inline_action_active()), eager=True)
        def _on_escape_inline(event) -> None:
            if self._inline_action_kind == 'approval':
                reasons = list(self._inline_action_reasons)
                self._inline_finish({'approved': False, 'decision': 'DENIED', 'reasons': reasons})
            elif self._inline_action_kind == 'choice':
                self._inline_finish({'selected': None, 'confirmed': False})

        @kb.add('escape')
        def _on_escape(event) -> None:
            if self._inline_action_active():
                return
            if self._pty_mode_active():
                self._send_pty_input(b'\x1b')
                return

        @kb.add(Keys.Any, filter=Condition(lambda: self._inline_action_active() and (not self._pty_mode_active())))
        def _on_any_inline(event) -> None:
            self._inline_handle_any_key(event.data)

        @kb.add(Keys.Any, filter=Condition(lambda: self._pty_mode_active()))
        def _on_any(event) -> None:
            data = event.data
            if not data:
                return
            try:
                self._send_pty_input(data.encode('utf-8', errors='ignore'))
            except Exception:
                pass
        body = HSplit([separator_window, input_container, status_window])
        root = FloatContainer(content=body, floats=[Float(xcursor=True, ycursor=True, content=CompletionsMenu(max_height=8))])
        layout = Layout(root, focused_element=self._input_window)
        app = Application(layout=layout, key_bindings=kb, full_screen=False, mouse_support=False, style=style)
        return app

    def _start_main_application(self) -> None:
        if self._ui_thread is not None and self._ui_thread.is_alive():
            return
        self.renderer.restore_stdout_stderr()
        self._ui_ready_evt.clear()
        t = threading.Thread(target=self._ui_thread_main, name='nimbie-ui', daemon=True)
        self._ui_thread = t
        t.start()
        self._ui_ready_evt.wait(timeout=2.0)

    def _ui_thread_main(self) -> None:
        loop = asyncio.new_event_loop()
        self._ui_loop = loop
        self._ui_exit_requested = False
        asyncio.set_event_loop(loop)
        try:
            self._main_app = self._build_main_application()
            try:
                self.output_hub.set_protected_bottom_rows(self._bottom_reserved_rows())
            except Exception:
                pass
            self._on_input_buffer_changed()
            self._main_app_task = loop.create_task(self._run_main_application())
            self._ui_output_task = loop.create_task(self._ui_output_drain_loop())
            self._ui_ready_evt.set()
            try:
                loop.run_until_complete(self._main_app_task)
            except asyncio.CancelledError:
                pass
        except Exception:
            self._ui_ready_evt.set()
        finally:
            for task in [self._ui_output_task]:
                if task is not None:
                    try:
                        task.cancel()
                    except Exception:
                        pass
            try:
                pending = asyncio.all_tasks(loop)
                for task in pending:
                    task.cancel()
                if pending:
                    loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
            except Exception:
                pass
            try:
                loop.stop()
            except Exception:
                pass
            try:
                loop.close()
            except Exception:
                pass
            self._ui_loop = None
            self._ui_exit_requested = False

    async def _run_main_application(self) -> None:
        app = self._main_app
        if app is None:
            return
        try:
            await app.run_async()
        except asyncio.CancelledError:
            try:
                app.exit(result=None)
            except Exception:
                pass
            raise
        except Exception:
            pass
        finally:
            self._ui_exit_requested = False

    async def _ui_output_drain_loop(self) -> None:
        self._ui_last_flush_ts = time.monotonic()
        next_tick = self._ui_last_flush_ts + max(0.1, float(self._ui_tick_interval_s))
        while not self.EXIT:
            now = time.monotonic()
            timeout = max(0.01, min(0.2, next_tick - now))
            item = None
            try:
                item = self._ui_output_q.get_nowait()
            except queue.Empty:
                try:
                    await asyncio.sleep(timeout)
                except asyncio.CancelledError:
                    break
            batch: list[tuple[str, str, bool, bool]] = []
            if item is not None:
                batch.append(item)
            while True:
                try:
                    nxt = self._ui_output_q.get_nowait()
                except queue.Empty:
                    break
                if nxt is not None:
                    batch.append(nxt)
            rows = max(1, int(shutil.get_terminal_size((120, 40)).lines))
            cols = max(1, int(shutil.get_terminal_size((120, 40)).columns))
            protected = max(2, int(self._bottom_reserved_rows()))
            protected = min(protected, rows - 1)
            scroll_bottom = max(1, rows - protected)
            payload_parts: list[str] = []
            saw_pty_chunk = False
            saw_input_chunk = False
            for source, text, _, _ in batch:
                if not text:
                    continue
                t = str(text or '')
                if source == 'pty':
                    saw_pty_chunk = True
                    t = self._sanitize_pty_stream_text(t)
                    self._track_pty_cursor(t, scroll_bottom=scroll_bottom, cols=cols)
                elif source == 'input':
                    saw_input_chunk = True
                payload_parts.append(t)
            payload = ''.join(payload_parts)
            if payload:
                self._ui_pending_payload += payload
            if self._inline_action_active():
                continue
            now = time.monotonic()
            tick_due = now >= next_tick
            if tick_due:
                step = max(0.1, float(self._ui_tick_interval_s))
                while next_tick <= now:
                    next_tick += step
            input_quiet = now - float(self._last_input_activity_ts) >= max(0.0, float(self._ui_input_quiet_s))
            should_flush = False
            if self._ui_pending_payload and tick_due and input_quiet:
                should_flush = True
            if self._ui_pending_payload and saw_pty_chunk and (now - float(self._ui_last_flush_ts) >= 0.02):
                should_flush = True
            if self._ui_pending_payload and saw_input_chunk and (now - float(self._ui_last_flush_ts) >= 0.005):
                should_flush = True
            if self._ui_pending_payload and len(self._ui_pending_payload) > self._main_scrollback_chunk_bytes * 16:
                should_flush = True
            if not should_flush:
                continue
            payload = self._pop_ui_pending_payload(max(1024, int(self._ui_max_bytes_per_tick)))
            self._ui_last_flush_ts = now
            chunk_limit = max(1024, int(self._main_scrollback_chunk_bytes))
            chunks: list[str] = []
            if len(payload.encode('utf-8', errors='ignore')) <= chunk_limit:
                chunks = [payload]
            else:
                acc = ''
                for ln in payload.splitlines(keepends=True):
                    if len((acc + ln).encode('utf-8', errors='ignore')) > chunk_limit and acc:
                        chunks.append(acc)
                        acc = ln
                    else:
                        acc += ln
                if acc:
                    chunks.append(acc)
            app = self._main_app
            for chunk in chunks:
                if not chunk:
                    continue

                def _write_one(c: str=chunk) -> None:
                    try:
                        if app is not None:
                            self._clear_upper_region_once()
                            if self._pty_clear_requested:
                                self._clear_upper_region()
                                self._pty_clear_requested = False
                                self._pty_cursor_row = 1
                                self._pty_cursor_col = 1
                                self._main_output_row = 1
                        rows = max(1, int(shutil.get_terminal_size((120, 40)).lines))
                        protected = max(2, int(self._bottom_reserved_rows()))
                        protected = min(protected, rows - 1)
                        scroll_bottom = max(1, rows - protected)
                        sys.stdout.write(f'\x1b[1;{scroll_bottom}r')
                        row = max(1, min(int(getattr(self, '_main_output_row', 1)), scroll_bottom))
                        sys.stdout.write(f'\x1b[{row};1H')
                        sys.stdout.write(c)
                        if c and (not c.endswith('\n')):
                            sys.stdout.write('\n')
                        line_adv = c.count('\n')
                        if c and (not c.endswith('\n')):
                            line_adv += 1
                        row = min(scroll_bottom, row + max(0, line_adv))
                        self._main_output_row = row
                        sys.stdout.write('\x1b[r')
                        if app is not None:
                            if not self._pty_mode_active():
                                self._position_cursor_for_focus()
                        sys.stdout.flush()
                    except Exception:
                        pass
                if app is not None:
                    try:
                        _write_one()
                    except Exception:
                        _write_one()
                else:
                    _write_one()
            if app is not None:
                try:
                    if now - self._last_app_invalidate_ts >= 0.1:
                        app.invalidate()
                        self._last_app_invalidate_ts = now
                except Exception:
                    pass

    def _sanitize_pty_stream_text(self, text: str) -> str:
        if not text:
            return ''
        s = self._osc_re.sub('', text)
        clear_hit = False

        def _csi_filter(m: re.Match[str]) -> str:
            nonlocal clear_hit
            params = m.group(1) or ''
            final = m.group(2)
            if final == 'J':
                clear_hit = True
                return ''
            if final in {'h', 'l'} and params.startswith('?') and (params[1:] in {'1049', '47', '1047'}):
                return ''
            return m.group(0)
        s = self._csi_re.sub(_csi_filter, s)
        s = s.replace('\x1b=\x1b>', '')
        if clear_hit:
            self._pty_clear_requested = True
        return s

    def _pop_ui_pending_payload(self, max_bytes: int) -> str:
        payload = self._ui_pending_payload
        if not payload:
            return ''
        max_bytes = max(256, int(max_bytes))
        raw = payload.encode('utf-8', errors='ignore')
        if len(raw) <= max_bytes:
            self._ui_pending_payload = ''
            return payload
        acc_parts: list[str] = []
        acc_bytes = 0
        used_chars = 0
        for line in payload.splitlines(keepends=True):
            line_bytes = len(line.encode('utf-8', errors='ignore'))
            if acc_bytes and acc_bytes + line_bytes > max_bytes:
                break
            if not acc_bytes and line_bytes > max_bytes:
                cut = raw[:max_bytes].decode('utf-8', errors='ignore')
                self._ui_pending_payload = payload[len(cut):]
                return cut
            acc_parts.append(line)
            acc_bytes += line_bytes
            used_chars += len(line)
            if acc_bytes >= max_bytes:
                break
        if not acc_parts:
            cut = raw[:max_bytes].decode('utf-8', errors='ignore')
            self._ui_pending_payload = payload[len(cut):]
            return cut
        out = ''.join(acc_parts)
        self._ui_pending_payload = payload[used_chars:]
        return out

    def _flush_ui_output_queue(self) -> None:
        """Flush all pending output from queue to output_hub. Call after activating inline action."""
        try:
            items: list[tuple[str, str, bool, bool]] = []
            while True:
                try:
                    item = self._ui_output_q.get_nowait()
                    items.append(item)
                except queue.Empty:
                    break
            if not items:
                return
            for source, text, echo, already_printed in items:
                if not text:
                    continue
                self.output_hub.push(source, text, echo=echo, already_printed=already_printed)
            if self._ui_pending_payload:
                self.output_hub.push('flush', self._ui_pending_payload, echo=False, already_printed=False)
                self._ui_pending_payload = ''
            self._rebalance_output_budget()
        except Exception:
            pass

    async def _run_prompt_in_thread(self) -> str:
        loop = asyncio.get_running_loop()
        ctx = contextvars.copy_context()

        def _runner() -> str:
            from prompt_toolkit.patch_stdout import patch_stdout
            if not hasattr(self._prompt_tls, 'loop'):
                tloop = asyncio.new_event_loop()
                asyncio.set_event_loop(tloop)
                self._prompt_tls.loop = tloop
            with patch_stdout(raw=True):
                return ctx.run(self.shell.shell.singleline)
        return await loop.run_in_executor(self._prompt_executor, _runner)

    def _text_display_width(self, text: str) -> int:
        s = str(text or '')
        try:
            s = self._osc_re.sub('', s)
            s = self._csi_re.sub('', s)
        except Exception:
            pass
        total = 0
        for ch in s:
            if ch in '\n\r':
                continue
            if unicodedata.combining(ch):
                continue
            total += 2 if unicodedata.east_asian_width(ch) in {'W', 'F'} else 1
        return max(0, int(total))

    def _estimate_visual_lines(self, text: str, width: int) -> int:
        w = max(1, int(width))
        if not text:
            return 1
        total = 0
        for line in text.split('\n'):
            n = len(line)
            total += max(1, (n + w - 1) // w)
        return max(1, total)

    def _rebalance_output_budget(self) -> None:
        try:
            sz = shutil.get_terminal_size((120, 40))
            cols = max(1, int(sz.columns))
            rows = max(1, int(sz.lines))
            reserved = int(self._bottom_reserved_rows())
            self._output_budget_cols = cols
            self._output_budget_rows = max(1, rows - reserved)
            self._main_output_row = max(1, min(int(getattr(self, '_main_output_row', 1)), self._output_budget_rows))
            try:
                self.output_hub.set_protected_bottom_rows(reserved)
            except Exception:
                pass
            if self._main_app is None:
                self.output_hub.rebalance_for_budget(max_visible_rows=self._output_budget_rows, width=cols)
        except Exception:
            pass

    def _install_ptk_keybindings(self) -> None:
        try:
            from prompt_toolkit.formatted_text import HTML
        except Exception:
            return

        def status_html():
            if self.MODE == 'agent':
                mode_text, mode_style = ('🤖 Agent', '#0c9')
                mode_desc = 'chat with AI'
            elif self.MODE == 'shell':
                mode_text, mode_style = ('💻 Shell', '#0f0')
                mode_desc = 'run shell commands'
            else:
                mode_text, mode_style = ('🎯 Auto', '#fa0')
                mode_desc = 'auto mode (smart routing)'
            usage = '-'
            if isinstance(self.USAGE_TOTAL, (int, float)):
                usage = f'{self.USAGE_TOTAL / 1000:.1f}K'
            renderer_status = {RenderState.OFF: '⌨️', RenderState.LIVE_TRANSIENT: '⏳', RenderState.LIVE_NON_TRANSIENT: '📌', RenderState.MARKDOWN_STREAMING: '📺'}.get(self.renderer.state, '❓')
            session_info = f'📂 {self.session.session_id[:8]}' if hasattr(self, 'session') and self.session else '📂 -'
            remote_exec = 'local'
            try:
                remote_exec = str(self.shell.remote_status_text())
            except Exception:
                remote_exec = 'local'
            try:
                return HTML(" <b><style fg='#888'>mode:</style></b> " + f"<style fg='{mode_style}'>{mode_text}</style>" + f"<style fg='#666'> ({mode_desc})</style>" + ' | ' + f"<b><style fg='#888'>render:</style></b> {renderer_status}" + ' | ' + f"<b><style fg='#888'>session:</style></b> {session_info}" + ' | ' + f"<b><style fg='#888'>exec:</style></b> " + f"<style fg='#9cf'>{remote_exec}</style>" + ' | ' + f"<b><style fg='#888'>usage:</style></b> " + f"<style fg='#fff' bg='#333'>{usage}</style>" + ' | ' + f"<style fg='#888'>shortcuts:</style> " + f"<style fg='#999'>F2 mode</style> " + f"<style fg='#999'>F3 chat</style> " + f"<style fg='#999'>F1 history</style> " + f"<style fg='#999'>F6 background</style> " + f"<style fg='#999'>Ctrl-Q/F10 exit</style>")
            except Exception:
                return 'PTK+subprocess mode'
        shell_obj = getattr(self.shell, 'shell', None)
        setter = getattr(shell_obj, 'set_bottom_toolbar_provider', None)
        if callable(setter):
            setter(status_html)
        kb_setter = getattr(shell_obj, 'set_keybinding_callbacks', None)
        if callable(kb_setter):

            def _chat_only(current_text: str) -> None:
                self._chat_only_pending = True
                self._chat_only_text = current_text or ''
                try:
                    self.console.print('[green]Switched to Chat Only mode[/green]')
                except Exception:
                    pass

            def _cancel_tool() -> None:
                try:
                    if self.agent is not None:
                        self.agent.request_cancel_tool()
                except Exception:
                    pass
            callbacks = {'toggle_mode': self._toggle_mode, 'open_history': self._schedule_history_ui, 'open_background': self._schedule_background_manager, 'chat_only': _chat_only, 'exit': self._signal_exit, 'cancel_tool': _cancel_tool}
            kb_setter(callbacks)

    def _toggle_mode(self) -> None:
        if self.MODE == 'auto':
            self.MODE = 'agent'
        elif self.MODE == 'agent':
            self.MODE = 'shell'
        else:
            self.MODE = 'auto'

    def _signal_exit(self) -> None:
        self.EXIT = True
        try:
            if self._main_app is not None:
                self._request_main_app_exit()
        except Exception:
            pass
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        try:
            loop.call_soon_threadsafe(self.event_q.put_nowait, {'type': 'shutdown'})
        except Exception:
            pass

    async def _event_loop(self) -> None:
        while True:
            if self.EXIT and self.event_q.empty():
                break
            try:
                ev = await asyncio.wait_for(self.event_q.get(), timeout=0.2)
            except asyncio.TimeoutError:
                continue
            t = ev.get('type')
            self._emit_web_event(ev)
            if t == 'shutdown':
                break
            if t == 'message_sent':
                self._request_phase = 'REQUESTING'
                if self._main_app is not None:
                    try:
                        self._invalidate_main_app()
                    except Exception:
                        pass
                self._start_esc_cancel_if_needed()
                continue
            if t == 'assistant_reasoning_delta':
                if self._request_phase != 'STREAMING':
                    self._request_phase = 'STREAMING'
                    if self._main_app is not None:
                        try:
                            self._invalidate_main_app()
                        except Exception:
                            pass
                delta_text = str(ev.get('text', '') or '')
                if self._main_app is None:
                    self._push_output('assistant_reasoning', delta_text, False)
                    self.renderer.stream_delta('reasoning', delta_text)
                else:
                    await self._main_stream_delta('reasoning', delta_text)
                continue
            if t == 'assistant_delta':
                if self._request_phase != 'STREAMING':
                    self._request_phase = 'STREAMING'
                    if self._main_app is not None:
                        try:
                            self._invalidate_main_app()
                        except Exception:
                            pass
                delta_text = str(ev.get('text', '') or '')
                if self._main_app is None:
                    self._push_output('assistant', delta_text, False)
                    self.renderer.stream_delta('content', delta_text)
                else:
                    await self._main_stream_delta('content', delta_text)
                continue
            if t == 'tool_call_delta':
                if self._main_app is None:
                    self.renderer.end_streaming_turn()
                else:
                    await self._flush_main_streams()
                delta_id = str(ev.get('delta_id') or '')
                snap = None
                try:
                    if self.agent is not None and hasattr(self.agent, 'get_tool_call_delta') and delta_id:
                        snap = self.agent.get_tool_call_delta(delta_id)
                except Exception:
                    snap = None
                src = snap if isinstance(snap, dict) else ev
                name = str(src.get('tool') or '')
                arg_str = str(src.get('args') or '')
                header = f'### Tool Preview: {name}\n'
                preview_text = src.get('preview')
                if not preview_text:
                    try:
                        tool_class = self.agent.get_tool_class(name) if self.agent is not None else None
                        if tool_class:
                            import json
                            try:
                                parsed_args = json.loads(arg_str) if arg_str else {}
                                preview_text = tool_class.get_preview(parsed_args)
                            except (json.JSONDecodeError, TypeError):
                                preview_text = f'```\n{arg_str}\n```\n' if arg_str else None
                    except Exception:
                        preview_text = f'```\n{arg_str}\n```\n' if arg_str else None
                if preview_text:
                    if self._main_app is None:
                        self.renderer.show_tool_preview(preview_text, header=header)
                    else:
                        self._push_output('tool_preview', header + preview_text, False)
                continue
            if t == 'tool_call':
                self._refresh_usage_total_from_context()
                self.renderer.enter_prompt()
                self.esc_cancel.stop()
                self._set_future(ev.get('future'), {'status': 'preview_done'})
                continue
            if t == 'approval_request':
                await self._handle_approval_request(ev)
                continue
            if t == 'choice_request':
                await self._handle_choice_request(ev)
                continue
            if t == 'run_aborted':
                self._refresh_usage_total_from_context()
                self._request_phase = 'IDLE'
                if self._main_app is None:
                    self.renderer.end_streaming_turn()
                else:
                    await self._flush_main_streams()
                self.esc_cancel.stop()
                if self._main_app is not None:
                    try:
                        self._invalidate_main_app()
                    except Exception:
                        pass
                continue
            if t == 'assistant_final':
                self._refresh_usage_total_from_context()
                self._request_phase = 'IDLE'
                if self._main_app is None:
                    self.renderer.end_streaming_turn()
                else:
                    await self._flush_main_streams()
                self.esc_cancel.stop()
                if self._main_app is not None:
                    try:
                        self._invalidate_main_app()
                    except Exception:
                        pass
                continue
            if t == 'warning':
                if self._main_app is None:
                    self.renderer.end_streaming_turn()
                    self.renderer.print_warning(f"Warning: {ev.get('warning', 'unknown warning')}")
                else:
                    self._push_output('warning', f"Warning: {ev.get('warning', 'unknown warning')}\n", False)
                continue
            if t == 'error':
                self._refresh_usage_total_from_context()
                self._request_phase = 'IDLE'
                if self._main_app is None:
                    self.renderer.end_streaming_turn()
                    self.renderer.print_error(f"Error: {ev.get('error', 'unknown error')}")
                else:
                    await self._flush_main_streams()
                    self._push_output('error', f"Error: {ev.get('error', 'unknown error')}\n", False)
                et = ev.get('exception_type', '')
                if et:
                    if self._main_app is None:
                        self.renderer.print_info(f'Exception type: {et}')
                    else:
                        self._push_output('error', f'Exception type: {et}\n', False)
                tb = ev.get('traceback', '')
                if tb:
                    if self._main_app is None:
                        self.renderer.print_info(f'Traceback:\n{tb}')
                    else:
                        self._push_output('error', f'Traceback:\n{tb}\n', False)
                self.esc_cancel.stop()
                if self._main_app is not None:
                    try:
                        self._invalidate_main_app()
                    except Exception:
                        pass
                continue
            if t == 'tool_exit':
                self._refresh_usage_total_from_context()
                self.esc_cancel.stop()
                continue
            if t == 'tool_output':
                try:
                    raw = ev.get('text', '')
                    txt = str(raw or '')
                    if txt:
                        self._push_output('tool', txt, False)
                except Exception:
                    pass
                continue
            if t == 'tool_call_debug':
                try:
                    import json
                    self.renderer.print_info('[tool] debug: ' + json.dumps(ev, ensure_ascii=False))
                except Exception:
                    pass
                continue
            if t == 'debug_latency':
                try:
                    stage = str(ev.get('stage') or 'unknown')
                    ms = ev.get('ms')
                    self.renderer.print_info(f'[latency] {stage}={ms}ms')
                except Exception:
                    pass
                continue

    def _refresh_usage_total_from_context(self) -> None:
        try:
            if self.agent is None or self.ctx is None:
                return
            if not hasattr(self.agent, 'get_last_total_tokens'):
                return
            total_tokens = self.agent.get_last_total_tokens(self.ctx)
            if isinstance(total_tokens, int):
                self.USAGE_TOTAL = total_tokens
        except Exception:
            pass

    async def _handle_user_input(self, ev: dict) -> None:
        fut = ev.get('future')
        lock = self._input_lock
        if lock is None:
            lock = asyncio.Lock()
            self._input_lock = lock
        async with lock:
            self._start_litellm_prewarm_once()
            if self._defer_prompt_refresh:
                self._defer_prompt_refresh = False
                if self._main_app is not None:
                    self._schedule_prompt_refresh(force=True)
            self.renderer.enter_prompt()
            self.esc_cancel.stop()
            line: Optional[str] = None
            try:
                if self._main_app is not None:
                    self._ptk_input_active = True
                    line = await self._input_line_queue.get()
                else:
                    try:
                        self.output_hub.set_terminal_writes_enabled(False)
                    except Exception:
                        pass
                    self._ptk_input_active = True
                    line = await self._run_prompt_in_thread()
                try:
                    cols = shutil.get_terminal_size((120, 40)).columns
                    self._last_input_visual_lines = self._estimate_visual_lines(line or '', cols)
                    self._rebalance_output_budget()
                except Exception:
                    pass
            except KeyboardInterrupt:
                if self._chat_only_pending:
                    line = self._chat_only_text
                    self._chat_only_pending = False
                    self._chat_only_text = ''
                    self._chat_only_was_used = True
                else:
                    self._resolve_input(fut, status='agent', text='', input_type='default')
                    return
            finally:
                self._ptk_input_active = False
                if self._main_app is None:
                    try:
                        self.output_hub.set_terminal_writes_enabled(True)
                    except Exception:
                        pass
        if self.EXIT:
            self._resolve_input(fut, status='agent', text='', input_type='default')
            try:
                sys.stdout.write('Bye\n')
                sys.stdout.flush()
            except Exception:
                pass
            return
        if line is None:
            self._resolve_input(fut, status='agent', text='', input_type='default')
            return
        s = line.strip()
        input_type = 'chat_only' if self._chat_only_was_used else 'default'
        self._chat_only_was_used = False
        lazy_input = fut is None
        if not lazy_input:
            self._ensure_session_initialized()
        if not s:
            if not lazy_input:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            else:
                self._schedule_lazy_prompt()
            return
        if s in ('exit', 'quit', '/exit', '/quit'):
            if not lazy_input:
                self._resolve_input(fut, status='agent', text='', input_type=input_type)
            try:
                sys.stdout.write('Bye\n')
                sys.stdout.flush()
            except Exception:
                pass
            self._signal_exit()
            return
        self._append_to_shell_history(s)
        from .slash_commands import get_slash_command_registry, CommandContext
        registry = get_slash_command_registry()
        if s in ('exit', 'quit', '/exit', '/quit'):
            cmd = registry.get('/exit')
            if cmd:
                ctx = CommandContext(app=self, args=[], raw_input=s, lazy_input=lazy_input, future=fut)
                await cmd.execute(ctx)
                if not lazy_input:
                    self._resolve_input(fut, status='agent', text='', input_type=input_type)
                return
        if s.startswith('/'):
            cmd, args = registry.resolve(s)
            if cmd:
                if cmd.requires_session and lazy_input:
                    self._ensure_session_initialized()
                try:
                    ctx = CommandContext(app=self, args=args, raw_input=s, lazy_input=lazy_input, future=fut)
                    await cmd.execute(ctx)
                except Exception as e:
                    cmd.on_error(ctx, e)
                if not lazy_input:
                    self._resolve_input(fut, status='agent', text='', input_type=input_type)
                return
        if self.MODE == 'shell':
            self._ensure_session_initialized()
            self._start_shell_task(s)
            if lazy_input:
                self._schedule_lazy_prompt()
                return
            if not lazy_input:
                self._resolve_input(fut, status='shell', text=s, input_type=input_type)
            return
        if self.MODE == 'auto':
            should_run, reason = self.shell.auto_should_run_shell(s)
            if should_run:
                self._ensure_session_initialized()
                self._start_shell_task(s)
                if lazy_input:
                    self._schedule_lazy_prompt()
                    return
                if not lazy_input:
                    self._resolve_input(fut, status='auto', text=s, input_type=input_type)
                return
            if reason:
                msg = f'Auto mode deferred to agent: {reason}; delegating to agent.'
                if self._main_app is not None:
                    self._push_output('warning', msg + '\n', False)
                else:
                    self.renderer.print_warning(msg)
        if lazy_input:
            self._ensure_session_initialized()
            try:
                if self.agent is not None and hasattr(self.agent, 'enqueue_user_input_nowait'):
                    self.agent.enqueue_user_input_nowait(text=s, status='agent', input_type=input_type)
            except Exception:
                pass
            return
        self._resolve_input(fut, status='agent', text=s, input_type=input_type)

    def _run_shell_and_build_summary(self, cmd: str) -> ShellResult:
        fold = True
        try:
            if hasattr(self.opts.ui_config, 'fold_bash_output') and (not self.opts.ui_config.fold_bash_output):
                fold = False
        except Exception:
            pass
        interactive_pty = self._main_app is not None
        if interactive_pty:
            self._pty_session_active = True
            self._pty_focus_mode = False
            self._drain_pty_input_queue()
            self._pty_cursor_row = max(1, int(getattr(self, '_main_output_row', 1)))
            self._pty_cursor_col = 1
            self._invalidate_main_app()
        try:
            self._rebalance_output_budget()
            rc, stdout, stderr = self.shell.run_and_capture(cmd, fold=fold, proxy_stdin=self._main_app is None, stdin_queue=self._pty_stdin_q if interactive_pty else None)
            self._rebalance_output_budget()
        finally:
            if interactive_pty:
                self._pty_focus_mode = False
                self._pty_session_active = False
                self._drain_pty_input_queue()
                self._invalidate_main_app()
                self._ui_call_soon(self._position_cursor_for_focus)
        shell_result = ShellResult(command=cmd, cwd=os.getcwd(), stdout=stdout, stderr=stderr, retcode=rc, date=_dt.datetime.now().astimezone())
        return shell_result

    async def _run_shell_and_record_async(self, cmd: str) -> None:
        try:
            shell_result = await asyncio.to_thread(self._run_shell_and_build_summary, cmd)
            try:
                if self.ctx is not None:
                    self.ctx.append_message(Message(role='user', content=shell_result))
            except Exception:
                pass
        except Exception as exc:
            try:
                self.renderer.print_error(f'Shell command failed: {exc}')
            except Exception:
                pass

    def _start_shell_task(self, cmd: str) -> None:
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        task = loop.create_task(self._run_shell_and_record_async(cmd))
        self._shell_tasks.add(task)

        def _done(t: asyncio.Task) -> None:
            self._shell_tasks.discard(t)
            try:
                _ = t.exception()
            except asyncio.CancelledError:
                return
            except Exception:
                return
        task.add_done_callback(_done)

    def _emit_web_event(self, ev: ReplEvent) -> None:
        if self._web_server is None:
            return
        payload = {}
        for k, v in ev.items():
            if k == 'future':
                continue
            try:
                json.dumps(v)
                payload[k] = v
            except Exception:
                payload[k] = str(v)
        fut = ev.get('future')
        ev_type = str(ev.get('type') or '')
        if fut is not None and ev_type != 'tool_call':
            try:
                if self._web_server is not None:
                    fid = self._web_server.register_future(fut)
                    payload['future_id'] = fid
            except Exception:
                pass
        try:
            self._web_server.broadcaster.publish(payload)
            if self.agent is not None and hasattr(self.agent, 'add_pending_event'):
                try:
                    loop = asyncio.get_running_loop()
                    loop.create_task(self.agent.add_pending_event(payload))
                except Exception:
                    pass
        except Exception:
            pass

    async def _handle_approval_request(self, ev: dict) -> None:
        name = str(ev.get('tool') or '')
        args = ev.get('args') or {}
        fut = ev.get('future')
        precheck = ev.get('precheck') or {}
        message = str(precheck.get('message') or '')
        raw_reasons = precheck.get('reasons') or []
        reasons: List[str] = [str(r) for r in raw_reasons if isinstance(r, (str, int, float))]
        self.renderer.enter_prompt()
        self.esc_cancel.stop()
        if name == 'execute_shell_command':
            cmd = ''
            if isinstance(args, dict):
                cmd = str(args.get('command', '') or '')
            if cmd.strip():
                self._push_output('approval', 'Command to approve:\n```bash\n' + cmd + '\n```\n', True)
        if message:
            self._push_output('warning', message + '\n', True)
        if reasons:
            self._push_output('approval', 'Reasons:\n' + '\n'.join([f'  - {r}' for r in reasons]) + '\n', True)
        inline_handled = False
        fut_res: Any = None
        if self._main_app is not None and isinstance(fut, asyncio.Future):
            inline_handled = True
            self._ui_call_soon(self._activate_inline_action_approval, name, message or str(args), reasons, fut)
            await asyncio.sleep(0.05)
            self._flush_ui_output_queue()
            try:
                fut_res = await fut
            except Exception as e:
                self.renderer.print_error(f'[approval] inline await error: {e}')
                fut_res = None
            finally:
                if self._inline_action_active():
                    self._ui_call_soon(self._deactivate_inline_action)
        approved = False
        decision = 'ALLOW'
        if inline_handled:
            if isinstance(fut_res, dict):
                approved = bool(fut_res.get('approved'))
            else:
                approved = bool(fut_res)
        else:
            self.renderer.print_warning(f'[approval] No TTY available, auto-denying: {name}')
            approved = False
        if isinstance(fut, asyncio.Future) and fut.done():
            self._start_esc_cancel_if_needed()
            self.renderer.enter_prompt()
            return
        if not approved:
            decision = 'DENIED'
            self._push_output('warning', '[tool] denied\n', False)
        payload = {'approved': bool(approved), 'decision': decision, 'reasons': reasons}
        self._set_future(fut, payload)
        self._start_esc_cancel_if_needed()
        self.renderer.enter_prompt()

    async def _handle_choice_request(self, ev: dict) -> None:
        prompt = str(ev.get('prompt') or 'Please choose an option')
        choices = ev.get('choices') or []
        fut = ev.get('future')
        self.renderer.enter_prompt()
        self.esc_cancel.stop()
        selected = None
        confirmed = False
        inline_handled = False
        if self._main_app is not None and isinstance(fut, asyncio.Future):
            inline_handled = True
            mapped_choices = list(map(str, choices))
            self._ui_call_soon(self._activate_inline_action_choice, prompt, mapped_choices, fut)
            fut_res: Any = None
            try:
                fut_res = await fut
            except Exception:
                fut_res = None
            finally:
                if self._inline_action_active():
                    self._ui_call_soon(self._deactivate_inline_action)
            if isinstance(fut_res, dict):
                selected = fut_res.get('selected')
                confirmed = bool(fut_res.get('confirmed'))
        else:
            try:
                result = await SelectionPanelApp.ask_async(prompt, list(map(str, choices)))
                selected = result.get('selected')
                confirmed = bool(result.get('confirmed'))
            except Exception:
                pass
        if not inline_handled:
            if confirmed and selected is not None:
                self.renderer.print_info(f'[choice] selected: {selected}')
            else:
                self.renderer.print_warning('[choice] cancelled')
        payload = {'selected': selected, 'confirmed': confirmed}
        self._set_future(fut, payload)
        if confirmed:
            self._start_esc_cancel_if_needed()
        else:
            self.renderer.enter_prompt()

    async def _run_history_ui(self) -> None:
        os.environ.setdefault('TEXTUAL_DISABLE_MOUSE', '1')

        def _fork_from_debug(msg_idx: int) -> str | None:
            try:
                old_id = self.ctx.session_id
                new_session = Context.create_session(self.work_dir, meta_dirname='.nimbie', global_sessions_root=Path.home() / '.nimbie' / 'global_sessions')
                forked = self.ctx.truncate_and_fork(msg_idx, new_session.history_file)
                self.ctx.adopt(forked)
                self.session = self.ctx
                result = f'Forked from {old_id} to {self.ctx.session_id}'
                self.renderer.print_info(f'[info] {result}')
                return result
            except Exception as err:
                self.renderer.print_error(f'Fork failed: {err}')
                return f'Fork failed: {err}'
        app = SessionHistoryInspectorApp(list(self.ctx.history), path=str(self.session.history_file), fork_callback=_fork_from_debug)
        try:
            fork_result = await app.run_async()
            if fork_result:
                self.renderer.print_info(f'[info]{fork_result}[/info]')
        except Exception:
            pass

    async def _run_background_manager_ui(self) -> None:
        os.environ.setdefault('TEXTUAL_DISABLE_MOUSE', '1')
        app = ProcessOverviewApp(get_background_registry_snapshot)
        try:
            await app.run_async()
        except Exception:
            pass

    async def _run_gateway_ui(self) -> None:
        os.environ.setdefault('TEXTUAL_DISABLE_MOUSE', '1')
        if self._web_server is None:
            self.renderer.print_warning('Gateway is not running.')
            return
        app = GatewayDebugApp(self._web_server.get_gateway_snapshot)
        try:
            await app.run_async()
        except Exception:
            pass
        self._defer_prompt_refresh = True

    def _schedule_history_ui(self) -> None:
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(self._run_history_ui(), loop)
        except RuntimeError:
            pass

    def _schedule_background_manager(self) -> None:
        loop = self._loop
        if loop is None or loop.is_closed():
            return
        try:
            asyncio.run_coroutine_threadsafe(self._run_background_manager_ui(), loop)
        except RuntimeError:
            pass

    async def _run_compact(self, cmd: str) -> None:
        try:
            hist = list(self.ctx.history)
            if not hist:
                self.renderer.print_warning('Context is empty.')
                return
            preserve_start = len(hist)
            n_keep = 0
            for idx in range(len(hist) - 1, -1, -1):
                r = getattr(hist[idx], 'role', None)
                c = getattr(hist[idx], 'content', None)
                if isinstance(r, str) and r in ('user', 'assistant') and isinstance(c, str) and c.strip():
                    n_keep += 1
                    if n_keep == 2:
                        preserve_start = idx
                        break
            to_compact = hist[:preserve_start]
            if not to_compact:
                self.renderer.print_warning('Nothing to compact (history too short).')
                return
            parts: list[str] = []
            for i, rec in enumerate(to_compact, 1):
                role = getattr(rec, 'role', None)
                if role is None and getattr(rec, 'type', None) == 'compact':
                    role = 'assistant'
                    content = getattr(rec, 'value', '')
                else:
                    content = getattr(rec, 'content', '')
                parts.append(f'## Message {i}\nRole: {role}\nContent: {str(content)}')
            history_text = '\n\n'.join(parts)
            sys_prompt = 'You are a helpful assistant that compacts conversation context. Summarize the following earlier messages into a concise markdown note that preserves key intent, constraints, paths, and code.'
            additional_instructions = cmd[len('/compact'):].strip() if len(cmd) > len('/compact') else ''
            user_prompt = f"Please compact the following context into a concise summary.{(' ' + additional_instructions if additional_instructions else '')}\n\n{history_text}"
            payload = [{'role': 'system', 'content': sys_prompt}, {'role': 'user', 'content': user_prompt}]
            got_first = False
            acc: list[str] = []
            agen = await self.agent.client.acreate(payload, stream=True, tool_stream=False, debug=self.opts.provider.debug_request, sse_debug=self.opts.provider.debug_sse)
            try:
                async for cev in agen:
                    if not got_first:
                        got_first = True
                        self.renderer.end_streaming_turn()
                        self.renderer.enter_prompt()
                    if isinstance(cev, dict) and cev.get('type') in ('assistant_delta', 'assistant_reasoning_delta'):
                        text = cev.get('text', '')
                        if text:
                            acc.append(text)
            finally:
                pass
            content = ''.join(acc).strip()
            if not content:
                self.renderer.print_warning('LLM did not return summary; skipping compaction.')
                return
            self.console.print(Markdown(content))
            self.ctx.append_compact(str(content), additional_instructions)
        except Exception as e:
            self.renderer.print_error(f'Failed to compact context: {e}')

    def _append_to_shell_history(self, s: str) -> None:
        return

    def _push_output(self, source: str, text: str, echo: bool=False, already_printed: bool=False) -> None:
        try:
            if self._main_app is not None and self._ui_thread is not None and self._ui_thread.is_alive():
                try:
                    self._ui_output_q.put_nowait((source, text, echo, bool(already_printed)))
                except Exception:
                    pass
                return
            effective_echo = bool(echo)
            self.output_hub.push(source, text, echo=effective_echo, already_printed=bool(already_printed))
            self._rebalance_output_budget()
        except Exception:
            pass

    def _set_future(self, fut: Any, payload: Any) -> None:
        if fut is None:
            return
        try:
            if isinstance(fut, asyncio.Future) and (not fut.done()):
                if self.opts.debug_loop:
                    print(f'[debug][future.set_result] {payload}')
                fut.set_result(payload)
        except Exception:
            pass

    def _resolve_input(self, fut: Any, *, status: str, text: str, input_type: str) -> None:
        self._set_future(fut, {'status': status, 'text': text, 'type': input_type})

    def _schedule_lazy_prompt(self) -> None:
        if self.EXIT:
            return
        if self._lazy_input_task is None or self._lazy_input_task.done():
            self._lazy_input_task = asyncio.create_task(self._lazy_input_loop())

    async def _lazy_input_loop(self) -> None:
        while not self.EXIT:
            try:
                await self._handle_user_input({'future': None})
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                try:
                    self.renderer.print_error(f'Prompt failed: {exc}')
                except Exception:
                    pass
                self._signal_exit()
                break

async def run_repl(work_dir: Path, opts: ReplOptions) -> None:
    """
    Compatibility entrypoint: delegates to ReplApp.
    """
    app = ReplApp(work_dir, opts)
    await app.run()
