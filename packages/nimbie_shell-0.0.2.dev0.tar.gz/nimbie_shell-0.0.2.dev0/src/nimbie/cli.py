"""Command line entrypoints for nimbie."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime
import importlib
import json
from pathlib import Path
import re
import shutil
from typing import Any

import click
from oturn import Context
from pydantic import BaseModel

from .config import Config, ModelConfig, ProviderConfig

_SESSION_META_DIR = ".nimbie"
_SESSION_GLOBAL_ROOT = Path.home() / ".nimbie" / "global_sessions"


@dataclass(slots=True)
class LaunchArgs:
    model_name: str | None
    api_base: str | None
    api_key: str | None
    provider_name: str | None
    work_dir: Path
    new_session: bool
    resume_id: str | None
    fork_id: str | None
    debug_request: bool
    debug_sse: bool
    debug_tool_calls: bool
    debug_loop: bool
    list_sessions: bool
    export_session: str | None
    export_out: Path | None
    no_fold_bash: bool
    connect: str | None
    ui_version: str


@dataclass(slots=True)
class RuntimeBundle:
    provider: ProviderConfig
    model_name: str
    model_config: ModelConfig
    agent_config: Any
    ui_config: Any


@dataclass(slots=True)
class SessionPreview:
    session_id: str
    path: str
    updated_at: str
    is_current: bool
    first_user_text: str
    last_user_text: str


class SessionExportFormatter:
    @staticmethod
    def render(session: Context) -> str:
        restored = session.restore()
        updated_at = datetime.fromtimestamp(session.history_file.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        lines = [
            f"# Session {session.session_id}",
            "",
            f"- workspace: `{session.work_dir}`",
            f"- history: `{session.history_file}`",
            f"- updated: {updated_at}",
            "",
        ]
        for message in restored.history:
            role = str(message.role or "").lower()
            heading = f"tool: {message.name or ''}" if role == "tool" else role
            lines.append(f"## {heading}")
            lines.append(SessionExportFormatter._render_message_body(role, message))
            lines.append("")
        return "\n".join(lines).rstrip() + "\n"

    @staticmethod
    def _render_message_body(role: str, message: Any) -> str:
        content = message.content or ""
        if role == "assistant" and getattr(message, "tool_calls", None):
            return SessionExportFormatter._fenced_json(SessionExportFormatter._serialize_tool_calls(message.tool_calls))
        if role == "tool":
            return SessionExportFormatter._render_tool_payload(content)
        return str(content)

    @staticmethod
    def _fenced_json(content: str) -> str:
        return f"```json\n{content}\n```\n"

    @staticmethod
    def _fenced_block(language: str, content: str) -> str:
        return f"```{language}\n{content}\n```\n"

    @staticmethod
    def _serialize_tool_calls(raw_value: Any) -> str:
        try:
            if isinstance(raw_value, list):
                payload = [item.to_dict() if hasattr(item, "to_dict") else item for item in raw_value]
            else:
                payload = json.loads(raw_value)
            return json.dumps(payload, ensure_ascii=False, indent=2)
        except Exception:
            return str(raw_value)

    @staticmethod
    def _render_tool_payload(raw_value: Any) -> str:
        try:
            if isinstance(raw_value, BaseModel):
                payload = raw_value.model_dump()
            else:
                payload = json.loads(raw_value)
            return SessionExportFormatter._fenced_block("", json.dumps(payload, ensure_ascii=False, indent=2))
        except Exception:
            return SessionExportFormatter._fenced_block("", str(raw_value))


class SessionCatalog:
    def __init__(self, work_dir: Path) -> None:
        self.work_dir = work_dir.resolve()

    def list_previews(self) -> list[SessionPreview]:
        raw_items, current_id = Context.list_sessions(self.work_dir, meta_dirname=_SESSION_META_DIR)
        return [self._build_preview(session_id, path, timestamp, current_id) for session_id, path, timestamp in raw_items]

    def export_markdown(self, session_id: str, output_path: Path | None) -> Path | None:
        session = Context.resume_session(
            self.work_dir,
            session_id,
            meta_dirname=_SESSION_META_DIR,
            global_sessions_root=_SESSION_GLOBAL_ROOT,
        )
        if session is None:
            return None
        target = output_path or (self.work_dir / ".nimbie-exports" / f"session_{session.session_id}.md")
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(SessionExportFormatter.render(session), encoding="utf-8")
        return target

    def emit_listing(self) -> None:
        previews = self.list_previews()
        if not previews:
            click.echo("(no sessions)")
            return
        for preview in previews:
            marker = " *" if preview.is_current else ""
            click.echo(f"{preview.session_id}{marker}  {preview.updated_at}  {preview.path}")
            if preview.first_user_text and preview.last_user_text:
                click.echo(f"  └─ {preview.first_user_text} → {preview.last_user_text}")
            elif preview.first_user_text:
                click.echo(f"  └─ {preview.first_user_text}")
            elif preview.last_user_text:
                click.echo(f"  └─ → {preview.last_user_text}")

    def _build_preview(self, session_id: str, path: str, timestamp: float, current_id: str | None) -> SessionPreview:
        first_user_text = ""
        last_user_text = ""
        session = Context.resume_session(
            self.work_dir,
            session_id,
            meta_dirname=_SESSION_META_DIR,
            global_sessions_root=_SESSION_GLOBAL_ROOT,
        )
        if session is not None:
            user_messages = [message for message in session.history if getattr(message, "role", None) == "user"]
            if user_messages:
                first_user_text = self._shorten_message(user_messages[0].content)
                last_user_text = self._shorten_message(user_messages[-1].content)
        return SessionPreview(
            session_id=session_id,
            path=path,
            updated_at=datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S"),
            is_current=session_id == current_id,
            first_user_text=first_user_text,
            last_user_text=last_user_text,
        )

    @staticmethod
    def _shorten_message(value: Any, limit: int = 60) -> str:
        if not isinstance(value, str):
            return ""
        text = value.strip()
        return text if len(text) <= limit else f"{text[:limit]}..."


class CliCoordinator:
    def __init__(self, config: Config) -> None:
        self.config = config

    def handle_root(self, args: LaunchArgs) -> bool:
        catalog = SessionCatalog(args.work_dir)
        if args.list_sessions:
            catalog.emit_listing()
            return True
        if args.export_session:
            target = catalog.export_markdown(args.export_session, args.export_out)
            if target is None:
                click.echo(f"session not found: {args.export_session}")
            else:
                click.echo(str(target))
            return True
        return False

    def launch(self, args: LaunchArgs) -> None:
        runtime = self._build_runtime(args)
        options_cls, run_repl = self._resolve_ui(args.ui_version)
        options = options_cls(
            provider=runtime.provider,
            model=runtime.model_name,
            model_config=runtime.model_config,
            agent_config=runtime.agent_config,
            ui_config=runtime.ui_config,
            new_session=args.new_session,
            resume_id=args.resume_id,
            fork_session_id=args.fork_id,
            debug_loop=args.debug_loop,
            connect=args.connect,
        )
        click.echo(
            f"[cfg] ui={args.ui_version} provider={options.provider.name} "
            f"model={options.model} api_base={options.provider.api_base} "
            f"key={self._redact_secret(options.provider.api_key)}"
        )
        asyncio.run(run_repl(args.work_dir.resolve(), options))

    def _build_runtime(self, args: LaunchArgs) -> RuntimeBundle:
        provider = self._merge_provider(self._pick_provider(args.provider_name), args)
        model_name = self._normalize_model_name(provider, args.model_name)
        model_config = self.config.models.get(model_name, ModelConfig())
        ui_config = self.config.ui
        ui_config.fold_bash_output = not args.no_fold_bash
        return RuntimeBundle(
            provider=provider,
            model_name=model_name,
            model_config=model_config,
            agent_config=self.config.agent,
            ui_config=ui_config,
        )

    def _pick_provider(self, requested_name: str | None) -> ProviderConfig:
        if requested_name:
            for provider in self.config.providers:
                if provider.name == requested_name:
                    return provider
            choices = ", ".join(provider.name for provider in self.config.providers) or "(none)"
            raise click.ClickException(f"Preset provider '{requested_name}' not found, available: {choices}")
        if self.config.default_provider:
            for provider in self.config.providers:
                if provider.name == self.config.default_provider:
                    return provider
            raise click.ClickException(f"Default provider '{self.config.default_provider}' not found")
        if self.config.providers:
            return self.config.providers[0]
        raise click.ClickException("No providers configured")

    @staticmethod
    def _merge_provider(base: ProviderConfig, args: LaunchArgs) -> ProviderConfig:
        return ProviderConfig(
            name=base.name,
            default_model=base.default_model,
            api_base=args.api_base or base.api_base,
            api_key=args.api_key or base.api_key,
            description=base.description,
            api_type=base.api_type,
            debug_request=base.debug_request or args.debug_request,
            debug_sse=base.debug_sse or args.debug_sse,
            debug_tools=base.debug_tools or args.debug_tool_calls,
        )

    @staticmethod
    def _normalize_model_name(provider: ProviderConfig, explicit_model: str | None) -> str:
        chosen = explicit_model or provider.default_model
        return chosen if "/" in chosen else f"{provider.name}/{chosen}"

    @staticmethod
    def _resolve_ui(version: str) -> tuple[type[Any], Any]:
        module = importlib.import_module(f".ui.{version}.repl_app", package=__package__)
        return getattr(module, "ReplOptions"), getattr(module, "run_repl")

    @staticmethod
    def _redact_secret(value: str | None) -> str:
        if not value or value == "(default)":
            return value or ""
        if len(value) < 7:
            return "*" * max(0, len(value) - 1) + value[-1]
        return f"{value[:3]}***{value[-3:]}"


def _move_sessions_to_global(work_dir: Path) -> tuple[int, int]:
    sessions_dir = work_dir.resolve() / ".nimbie" / "sessions"
    if not sessions_dir.exists():
        raise FileNotFoundError(f"sessions dir not found: {sessions_dir}")
    moved = 0
    skipped = 0
    date_prefix = re.compile(r"^\d{8}")
    for source in sorted(sessions_dir.glob("*.md")):
        if source.is_symlink() or not source.is_file() or not date_prefix.match(source.stem):
            skipped += 1
            continue
        destination_dir = _SESSION_GLOBAL_ROOT / source.stem[:8]
        destination_dir.mkdir(parents=True, exist_ok=True)
        destination = destination_dir / source.name
        if not destination.exists():
            shutil.copy2(source, destination)
        source.unlink()
        source.symlink_to(destination.resolve())
        moved += 1
    return moved, skipped


@click.group(context_settings={"help_option_names": ["-h", "--help"]}, invoke_without_command=True)
@click.option("--model", "model_name", type=str, default=None)
@click.option("--api-base", type=str, default=None, help="API base URL for the configured model provider.")
@click.option("--api-key", type=str, default=None, help="API key for the configured model provider.")
@click.option("--provider", "provider_name", type=str, default=None, help="Preset provider to use (overrides defaults).")
@click.option("--work-dir", "work_dir", type=click.Path(file_okay=False, dir_okay=True, path_type=Path), default=Path.cwd())
@click.option("--new-session/--continue", "new_session", default=True, help="Start a new session (default) or continue the last one.")
@click.option("--resume-id", type=str, default=None, help="Resume a specific session id (overrides --new-session/--continue).")
@click.option("--fork", "fork_id", type=str, default=None, is_flag=False, flag_value="[AUTO]", help="Fork a session to create a new one with the same history. Use without value to auto-generate name.")
@click.option("--debug-request", is_flag=True, default=False, help="Dump request payload.")
@click.option("--debug-sse", is_flag=True, default=False, help="Dump streaming chunk json (SDK).")
@click.option("--debug-tool-calls", is_flag=True, default=False, help="Print raw tool_call deltas and assembled payloads.")
@click.option("--debug-loop", is_flag=True, default=False, help="Print debug log for out_q/future flow.")
@click.option("--list-sessions", is_flag=True, default=False, help="List sessions for this work_dir and exit.")
@click.option("--export-session", type=str, default=None, help="Export the given session id to a Markdown file and exit.")
@click.option("--export-out", type=click.Path(path_type=Path), default=None, help="Output markdown path (defaults under work_dir).")
@click.option("--no-fold-bash", is_flag=True, default=False, help="Do not fold/truncate bash outputs in UI and context.")
@click.option("--connect", type=str, default=None, help="Auto connect ssh executor target, e.g. 30.1.0.5 or user@30.1.0.5:22")
@click.option("--ui-version", type=click.Choice(["v2", "v3"]), default="v3", show_default=True, help="Select REPL UI implementation.")
@click.pass_context
def nimbie(ctx: click.Context, **raw_args: Any) -> None:
    """Root nimbie CLI group."""

    if ctx.invoked_subcommand is not None:
        return
    args = LaunchArgs(**raw_args)
    coordinator = CliCoordinator(Config.load())
    if coordinator.handle_root(args):
        return
    coordinator.launch(args)


@nimbie.command("summary", context_settings={"help_option_names": ["-h", "--help"]})
@click.option("--model", "model_name", type=str, default=None)
@click.option("--provider", "provider_name", type=str, default=None, help="Preset provider to use (overrides defaults).")
@click.option("--work-dir", "work_dir", type=click.Path(file_okay=False, dir_okay=True, path_type=Path), default=Path.cwd())
def summary_cmd(model_name: str | None, provider_name: str | None, work_dir: Path) -> None:
    """Run non-interactive summarization."""

    from .summary_entry import run_summary

    asyncio.run(run_summary(work_dir=work_dir, summary_model=model_name, provider_name=provider_name))


@nimbie.command("move_sessions_to_global", context_settings={"help_option_names": ["-h", "--help"]})
@click.option("--work-dir", "work_dir", type=click.Path(file_okay=False, dir_okay=True, path_type=Path), default=Path.cwd())
def move_sessions_to_global_cmd(work_dir: Path) -> None:
    """Move local session markdown files into the shared global store."""

    try:
        moved, skipped = _move_sessions_to_global(work_dir)
    except FileNotFoundError as exc:
        click.echo(str(exc))
        return
    click.echo(f"moved={moved} skipped={skipped}")


def main() -> None:
    nimbie()


if __name__ == "__main__":
    main()
