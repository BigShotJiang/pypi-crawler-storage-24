from __future__ import annotations

from dataclasses import dataclass
import datetime as dt
import json
from typing import Any, Literal, Protocol, TypeAlias, runtime_checkable

from pydantic import BaseModel, field_serializer, field_validator

try:
    from zoneinfo import ZoneInfo
except Exception:
    ZoneInfo = None


Role: TypeAlias = Literal["user", "assistant", "system", "tool"]
ROLE_USER: Role = "user"
ROLE_ASSISTANT: Role = "assistant"
ROLE_SYSTEM: Role = "system"
ROLE_TOOL: Role = "tool"


def _current_time() -> dt.datetime:
    return dt.datetime.now().astimezone()


def _local_tz() -> dt.tzinfo:
    return _current_time().tzinfo or dt.timezone.utc


def _normalize_time(value: dt.datetime) -> dt.datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=_local_tz())
    return value.astimezone(_local_tz())


def _offset_label(value: dt.datetime) -> str:
    offset = value.utcoffset() or dt.timedelta()
    seconds = int(offset.total_seconds())
    sign = "+" if seconds >= 0 else "-"
    seconds = abs(seconds)
    hours, remainder = divmod(seconds, 3600)
    minutes = remainder // 60
    return f"{sign}{hours:02d}:{minutes:02d}"


def _decode_timestamp(raw: Any) -> dt.datetime | Any:
    if isinstance(raw, dt.datetime):
        return _normalize_time(raw)
    if isinstance(raw, (int, float)):
        return dt.datetime.fromtimestamp(raw, tz=dt.timezone.utc).astimezone(_local_tz())
    if not isinstance(raw, dict) or "ts" not in raw:
        return raw
    timestamp = raw.get("ts")
    zone_hint = raw.get("tz")
    if not isinstance(timestamp, (int, float)):
        raise TypeError(f"date.ts must be int/float seconds, got {type(timestamp)}")
    if isinstance(zone_hint, str):
        hinted = _decode_timestamp_with_zone(float(timestamp), zone_hint)
        if hinted is not None:
            return hinted
    return dt.datetime.fromtimestamp(float(timestamp), tz=dt.timezone.utc).astimezone(_local_tz())


def _decode_timestamp_with_zone(timestamp: float, zone_hint: str) -> dt.datetime | None:
    if ZoneInfo is not None:
        try:
            return dt.datetime.fromtimestamp(timestamp, tz=ZoneInfo(zone_hint)).astimezone(_local_tz())
        except Exception:
            pass
    if zone_hint.startswith(("+", "-")):
        try:
            sign = 1 if zone_hint[0] == "+" else -1
            hours, minutes = zone_hint[1:].split(":", 1)
            delta = dt.timedelta(hours=int(hours) * sign, minutes=int(minutes) * sign)
            return dt.datetime.fromtimestamp(timestamp, tz=dt.timezone(delta)).astimezone(_local_tz())
        except Exception:
            return None
    return None


def _encode_timestamp(value: dt.datetime) -> dict[str, float | str]:
    normalized = _normalize_time(value)
    zone_name = getattr(normalized.tzinfo, "key", None) if ZoneInfo is not None else None
    return {
        "ts": normalized.timestamp(),
        "tz": zone_name if isinstance(zone_name, str) and zone_name else _offset_label(normalized),
    }


def _mail_date(value: dt.datetime) -> str:
    return _normalize_time(value).strftime("%a, %d %b %Y %H:%M:%S %z")


class TimestampedRecord(BaseModel):
    date: dt.datetime

    @field_validator("date", mode="before")
    @classmethod
    def _parse_date(cls, value: Any) -> dt.datetime:
        parsed = _decode_timestamp(value)
        if not isinstance(parsed, dt.datetime):
            raise TypeError(f"date must be datetime-like, got {type(parsed)}")
        return parsed

    @field_validator("date", mode="after")
    @classmethod
    def _normalize_date(cls, value: dt.datetime) -> dt.datetime:
        return _normalize_time(value)

    @field_serializer("date")
    def _dump_date(self, value: dt.datetime) -> dict[str, float | str]:
        return _encode_timestamp(value)


@dataclass(slots=True)
class FunctionInfo:
    name: str
    arguments: Any = None

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "FunctionInfo":
        return cls(name=str(data.get("name", "")), arguments=data.get("arguments"))

    def to_dict(self) -> dict[str, Any]:
        payload = {"name": self.name}
        if self.arguments is not None:
            payload["arguments"] = self.arguments
        return payload


@dataclass(slots=True)
class ToolCallInfo:
    id: str
    type: str
    function: FunctionInfo

    @classmethod
    def from_json(cls, data: dict[str, Any]) -> "ToolCallInfo":
        raw_function = data.get("function")
        return cls(
            id=str(data.get("id", "")),
            type=str(data.get("type", "")),
            function=FunctionInfo.from_json(raw_function if isinstance(raw_function, dict) else {}),
        )

    def to_dict(self) -> dict[str, Any]:
        return {"id": self.id, "type": self.type, "function": self.function.to_dict()}


class UserContent(TimestampedRecord):
    user_name: str
    content: str
    email: str | None = None
    tool_contents: list["UserContent"] | None = None
    __chronml_template__ = "From: {.user_name}\nDate: {.date}\n\n{.content:block}\n"

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "UserContent":
        return cls(
            user_name=str(data.get("user_name", "")),
            content=str(data.get("content", "")),
            email=data.get("email"),
            tool_contents=data.get("tool_contents"),
            date=data.get("date", _current_time()),
        )

    def to_message_text(self) -> str:
        header = f"From: {self.user_name}"
        if self.email:
            header += f" <{self.email}>"
        lines = [header, f"Date: {_mail_date(self.date)}", ""]
        for index, nested in enumerate(self.tool_contents or [], start=1):
            lines.extend([f"[Tool Notice {index}]", nested.to_message_text(), ""])
        lines.append(self.content)
        return "\n".join(lines).strip()


class ShellResult(TimestampedRecord):
    command: str
    cwd: str
    stdout: str
    stderr: str
    retcode: int
    __chronml_template__ = (
        "# [user]\n- **Command:** {.command}\n- **Working Directory:** {.cwd}\n"
        "- **Exit Code:** {.retcode}\n- **Date:** {.date}\n\n**STDOUT:**\n{.stdout:block}\n\n"
        "**STDERR:**\n{.stderr:block}\n"
    )

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ShellResult":
        return cls(
            command=str(data.get("command", "")),
            cwd=str(data.get("cwd", "")),
            stdout=str(data.get("stdout", "")),
            stderr=str(data.get("stderr", "")),
            retcode=int(data.get("retcode", 0)),
            date=data.get("date", _current_time()),
        )

    def to_message_text(self) -> str:
        lines = [
            "From: User Shell <user_shell@agent_system.com>",
            "Subject: User Shell Execution Report",
            f"Date: {_mail_date(self.date)}",
            f"X-Exec-Cwd: {self.cwd}",
            f"X-Exec-Cmd: {self.command}",
            f"X-Exec-Retcode: {self.retcode}",
            "",
        ]
        if self.stdout:
            lines.extend(["STDOUT:", self.stdout, ""])
        if self.stderr:
            lines.extend(["STDERR:", self.stderr, ""])
        if not self.stdout and not self.stderr:
            lines.append("(no output)")
        return "\n".join(lines).strip()


class ToolMessageContent(BaseModel):
    status: str | None = None
    data: Any = None
    error: str | None = None
    metadata: dict[str, Any] | None = None
    info: dict[str, Any] | None = None

    def to_message_text(self) -> str:
        return json.dumps(self.model_dump(exclude_none=True), ensure_ascii=False, indent=2)


@runtime_checkable
class MessageTextRenderable(Protocol):
    def to_message_text(self) -> str:
        """Render object as plain text for model input serialization."""


class Message(BaseModel):
    role: Role
    content: str | UserContent | ShellResult | ToolMessageContent
    name: str | None = None
    tool_call_id: str | None = None
    tool_calls: list[ToolCallInfo] | None = None
    usage: dict[str, Any] | None = None
    reasoning_content: str | None = None
    model_name: str | None = None
    extra: dict[str, Any] | None = None


class CompactRecord(BaseModel):
    type: str = "compact"
    value: str = ""
    user_intent: str = ""
