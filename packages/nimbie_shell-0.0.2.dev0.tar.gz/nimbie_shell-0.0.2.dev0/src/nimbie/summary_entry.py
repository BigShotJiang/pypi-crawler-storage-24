from __future__ import annotations

import asyncio
import datetime as dt
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from chronml import Chron
from oturn import (
    Context,
    Message,
    Oturn,
    OturnAgentConfig,
    OturnConfig,
    OturnModelConfig,
    OturnProviderConfig,
    ToolMessageContent,
    UserContent,
)
from oturn.events import EventPayload
from pydantic import BaseModel

from .config import AgentConfig, Config, ModelConfig, ProviderConfig, UIConfig
from .model import ShellResult
from .tools.internal.set_result import SetResultTool

_SESSION_CHRON = Chron(marker_prefix="md_as_config:ctx:")
_SUMMARY_PROMPT = (
    "You are a summarizer focused on project structure, file paths, code behavior, "
    "and the user's questions plus the assistant's response style and content. "
    "Always call set_result with the summary."
)


@dataclass(slots=True)
class SummaryRuntime:
    provider: ProviderConfig
    model_name: str
    model_config: ModelConfig
    agent_config: AgentConfig
    ui_config: UIConfig
    debug_loop: bool = False


@dataclass(frozen=True, slots=True)
class SessionKey:
    date_dir: str
    session_id: str


@dataclass(frozen=True, slots=True)
class SessionJob:
    key: SessionKey
    source_path: Path


@dataclass(frozen=True, slots=True)
class SummaryPaths:
    draft_summary: Path
    final_summary: Path
    draft_trace: Path
    final_trace: Path


@dataclass(frozen=True, slots=True)
class SummaryRound:
    index: int
    messages: tuple[Message, ...]


@dataclass(slots=True)
class SummaryCounters:
    total_sessions: int = 0
    completed_sessions: int = 0
    skipped_done: int = 0
    skipped_empty: int = 0
    processed_rounds: int = 0


def _select_provider(config: Config, requested_name: str | None) -> ProviderConfig:
    if requested_name:
        for provider in config.providers:
            if provider.name == requested_name:
                return provider
    if config.default_provider:
        for provider in config.providers:
            if provider.name == config.default_provider:
                return provider
    if config.providers:
        return config.providers[0]
    raise ValueError("No providers configured.")


def _build_runtime(config: Config, summary_model: str | None, provider_name: str | None) -> SummaryRuntime:
    provider = _select_provider(config, provider_name)
    model_name = summary_model or provider.default_model
    if "/" not in model_name:
        model_name = f"{provider.name}/{model_name}"
    return SummaryRuntime(
        provider=provider,
        model_name=model_name,
        model_config=config.models.get(model_name, ModelConfig()),
        agent_config=config.agent,
        ui_config=config.ui,
        debug_loop=False,
    )


def _build_oturn_config(runtime: SummaryRuntime) -> OturnConfig:
    return OturnConfig(
        model=runtime.model_name,
        provider=OturnProviderConfig(
            api_base=runtime.provider.api_base,
            api_key=runtime.provider.api_key,
            debug_request=runtime.provider.debug_request,
            debug_sse=runtime.provider.debug_sse,
            debug_tools=runtime.provider.debug_tools,
        ),
        model_config=OturnModelConfig(
            max_output_tokens=runtime.model_config.max_output_tokens,
            temperature=runtime.model_config.temperature,
            extra_body=runtime.model_config.extra_body,
        ),
        agent_config=OturnAgentConfig(
            max_steps=int(runtime.agent_config.max_steps or 100),
            user_name=str(runtime.agent_config.user_name or "User"),
            email=runtime.agent_config.email,
        ),
        debug_loop=runtime.debug_loop,
    )


def _global_sessions_root() -> Path:
    return Path.home() / ".nimbie" / "global_sessions"


def _summary_root() -> Path:
    return Path.home() / ".nimbie" / "summary"


def _summary_trace_root() -> Path:
    return Path.home() / ".nimbie" / "sessions_for_summary"


def _discover_jobs(root: Path) -> list[SessionJob]:
    if not root.exists():
        return []
    jobs: list[SessionJob] = []
    for source_path in sorted(root.glob("*/*.md")):
        jobs.append(
            SessionJob(
                key=SessionKey(date_dir=source_path.parent.name, session_id=source_path.stem),
                source_path=source_path,
            )
        )
    return jobs


def _summary_paths(key: SessionKey) -> SummaryPaths:
    draft_summary = _summary_root() / f"{key.date_dir}_tmp" / f"{key.session_id}.md.tmp"
    final_summary = _summary_root() / key.date_dir / f"{key.session_id}.md"
    draft_trace = _summary_trace_root() / f"{key.date_dir}_tmp" / f"{key.session_id}.md.tmp"
    final_trace = _summary_trace_root() / key.date_dir / f"{key.session_id}.md"
    return SummaryPaths(
        draft_summary=draft_summary,
        final_summary=final_summary,
        draft_trace=draft_trace,
        final_trace=final_trace,
    )


def _load_rounds(source_path: Path) -> list[SummaryRound]:
    raw_records = _SESSION_CHRON.load(source_path)
    messages = [record for record in raw_records if isinstance(record, Message)]
    rounds: list[SummaryRound] = []
    current: list[Message] = []
    for message in messages:
        if message.role == "system":
            continue
        if message.role == "user":
            if current:
                rounds.append(SummaryRound(index=len(rounds) + 1, messages=tuple(current)))
            current = [message]
            continue
        if not current:
            continue
        current.append(message)
    if current:
        rounds.append(SummaryRound(index=len(rounds) + 1, messages=tuple(current)))
    return rounds


def _ensure_parent_file(path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.touch(exist_ok=True)
    return path


def _processed_round_count(summary_path: Path) -> int:
    if not summary_path.exists() or summary_path.stat().st_size == 0:
        return 0
    records = _SESSION_CHRON.load(summary_path)
    return sum(1 for record in records if isinstance(record, Message) and record.role == "assistant")


def _format_message(message: Message) -> str:
    content = message.content
    if isinstance(content, UserContent):
        body = content.to_message_text()
    elif isinstance(content, ShellResult):
        body = content.to_message_text()
    elif isinstance(content, ToolMessageContent):
        body = json.dumps(content.model_dump(), ensure_ascii=False)
    else:
        body = str(content)
    return f"[{message.role}]\n{body}".strip()


def _round_prompt(round_data: SummaryRound) -> str:
    transcript = "\n\n".join(_format_message(message) for message in round_data.messages)
    return (
        "Summarize the following round. Focus on project structure, file paths, code behavior, "
        "and the user's questions plus the assistant's response style and content. "
        "You must call the set_result tool with the summary text. Do not ask for user input.\n\n"
        f"{transcript}"
    )


def _create_ephemeral_context(trace_path: Path, work_dir: Path) -> Context:
    return Context(
        _ensure_parent_file(trace_path),
        session_id=trace_path.stem,
        work_dir=work_dir,
        meta_dirname=".nimbie",
        global_sessions_root=_global_sessions_root(),
    )


def _append_summary(summary_ctx: Context, round_index: int, summary_text: str) -> None:
    summary_ctx.append_message(Message(role="assistant", content=f"Round {round_index}: {summary_text.strip()}"))


def _append_trace(trace_ctx: Context, prompt: str, summary_text: str) -> None:
    trace_ctx.append_message(Message(role="user", content=prompt))
    trace_ctx.append_message(Message(role="assistant", content=summary_text))


def _extract_summary_result(ctx: Context) -> str:
    for item in reversed(list(ctx.history)):
        if not isinstance(item, Message):
            continue
        if item.role != "tool" or item.name != "set_result":
            continue
        content = item.content
        if isinstance(content, ToolMessageContent) and isinstance(content.data, dict):
            result = content.data.get("result")
            if isinstance(result, str):
                return result
        if isinstance(content, dict):
            result = content.get("result")
            if isinstance(result, str):
                return result
    raise ValueError("set_result tool did not return a summary.")


def _is_rate_limited(error_text: str) -> bool:
    lowered = error_text.lower()
    return "429" in error_text or "rate limit" in lowered


async def _run_single_round(runtime: SummaryRuntime, work_dir: Path, prompt: str, trace_path: Path) -> str:
    ctx = _create_ephemeral_context(trace_path, work_dir)
    ctx.append_message(Message(role="system", content=_SUMMARY_PROMPT))
    event_q: asyncio.Queue[EventPayload] = asyncio.Queue()

    async def _tool_policy(name: str, _args: dict) -> bool:
        return name == "set_result"

    agent = Oturn(work_dir=work_dir, config=_build_oturn_config(runtime), tools=[SetResultTool], tool_policy=_tool_policy)
    agent.subscribe(event_q)
    rate_limit_retries = 5
    try:
        for attempt in range(1, 4):
            loop_task = asyncio.create_task(agent.run_queues(ctx))
            saw_rate_limit = False
            rate_limit_error = ""
            try:
                while True:
                    event = await event_q.get()
                    event_type = str(event.get("type") or "")
                    if event_type == "request_user_input":
                        future = event.get("future")
                        if future is not None and not future.done():
                            suffix = ""
                            if attempt > 1:
                                suffix = "\n\nYou must call the set_result tool. Return only the tool call."
                            future.set_result({"status": "agent", "text": prompt + suffix})
                    elif event_type == "tool_call":
                        future = event.get("future")
                        if future is not None and not future.done():
                            future.set_result({"status": "preview_done"})
                    elif event_type == "assistant_final":
                        return _extract_summary_result(ctx)
                    elif event_type == "error":
                        error_text = str(event.get("error") or "unknown error")
                        if _is_rate_limited(error_text):
                            saw_rate_limit = True
                            rate_limit_error = error_text
                            break
                        raise RuntimeError(f"summary loop error: {error_text}")
            finally:
                loop_task.cancel()
            if saw_rate_limit:
                if attempt >= rate_limit_retries:
                    raise RuntimeError(f"summary loop error: {rate_limit_error}")
                await asyncio.sleep(min(2**attempt, 60))
                continue
            ctx.append_message(Message(role="system", content="Retry: call set_result with the summary."))
        return _extract_summary_result(ctx)
    finally:
        agent.unsubscribe(event_q)
        try:
            await agent.aclose()
        except Exception:
            pass


def _finalize_file(draft_path: Path, final_path: Path) -> None:
    if final_path.exists():
        return
    final_path.parent.mkdir(parents=True, exist_ok=True)
    draft_path.rename(final_path)


def _finalize_completed_day(date_dir: str, today: str) -> None:
    if date_dir == today:
        return
    for root in (_summary_root(), _summary_trace_root()):
        draft_dir = root / f"{date_dir}_tmp"
        final_dir = root / date_dir
        if not draft_dir.exists():
            continue
        if list(draft_dir.glob("*.md.tmp")):
            continue
        if final_dir.exists():
            for path in draft_dir.glob("*.md"):
                target = final_dir / path.name
                if not target.exists():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    path.rename(target)
            if not list(draft_dir.iterdir()):
                draft_dir.rmdir()
        else:
            draft_dir.rename(final_dir)


def _group_jobs_by_day(jobs: Iterable[SessionJob]) -> dict[str, list[SessionJob]]:
    grouped: dict[str, list[SessionJob]] = {}
    for job in jobs:
        grouped.setdefault(job.key.date_dir, []).append(job)
    return grouped


async def _process_job(job: SessionJob, runtime: SummaryRuntime, work_dir: Path, counters: SummaryCounters) -> bool:
    paths = _summary_paths(job.key)
    if paths.final_summary.exists():
        counters.skipped_done += 1
        return True
    rounds = _load_rounds(job.source_path)
    if not rounds:
        counters.skipped_empty += 1
        return False
    summary_ctx = Context(
        _ensure_parent_file(paths.draft_summary),
        session_id=job.key.session_id,
        work_dir=work_dir,
        meta_dirname=".nimbie",
        global_sessions_root=_global_sessions_root(),
    )
    trace_ctx = Context(
        _ensure_parent_file(paths.draft_trace),
        session_id=job.key.session_id,
        work_dir=work_dir,
        meta_dirname=".nimbie",
        global_sessions_root=_global_sessions_root(),
    )
    completed_rounds = _processed_round_count(paths.draft_summary)
    for round_data in rounds:
        if round_data.index <= completed_rounds:
            continue
        round_prompt = _round_prompt(round_data)
        round_summary = await _run_single_round(runtime, work_dir, round_prompt, paths.draft_trace)
        _append_summary(summary_ctx, round_data.index, round_summary)
        _append_trace(trace_ctx, round_prompt, round_summary)
        counters.processed_rounds += 1
    _finalize_file(paths.draft_summary, paths.final_summary)
    _finalize_file(paths.draft_trace, paths.final_trace)
    counters.completed_sessions += 1
    print(f"[summary] session done: {job.key.session_id}")
    return True


async def run_summary(*, work_dir: Path, summary_model: str | None = None, provider_name: str | None = None) -> None:
    runtime = _build_runtime(Config.load(), summary_model, provider_name)
    jobs = _discover_jobs(_global_sessions_root())
    counters = SummaryCounters(total_sessions=len(jobs))
    today = dt.datetime.now().strftime("%Y%m%d")
    for date_dir, day_jobs in sorted(_group_jobs_by_day(jobs).items()):
        all_completed = True
        for job in sorted(day_jobs, key=lambda item: item.key.session_id):
            finished = await _process_job(job, runtime, work_dir, counters)
            if not finished:
                all_completed = False
        if all_completed:
            _finalize_completed_day(date_dir, today)
    print(
        "[summary] done: "
        f"sessions={counters.total_sessions}, "
        f"completed={counters.completed_sessions}, "
        f"processed_rounds={counters.processed_rounds}, "
        f"skipped_done={counters.skipped_done}, "
        f"skipped_empty={counters.skipped_empty}"
    )
