"""System prompt discovery and interpolation helpers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

_FALLBACK_PROMPT = """You are an AI coding agent.

Tools are available through the Chat Completions function-calling interface.
- If a tool is required, call it through tool_calls.
- Do not print JSON that imitates a tool call.
- After tool results arrive, continue the task and answer the user.
- If no tool is needed, answer directly.

Keep responses concise and practical for a terminal workflow.
"""


@dataclass(frozen=True, slots=True)
class PromptBindings:
    work_dir: str
    work_dir_listing: str
    agents_text: str


def get_system_prompt(base_dir: Path) -> str:
    """Return the resolved system prompt for a workspace."""

    workspace = base_dir.resolve()
    prompt_path = _locate_prompt_template(workspace)
    if prompt_path is None:
        return _FALLBACK_PROMPT
    template = _safe_read_text(prompt_path)
    if template is None:
        return _FALLBACK_PROMPT
    bindings = _build_bindings(workspace)
    return _render_prompt(template, bindings)


def _locate_prompt_template(workspace: Path) -> Path | None:
    package_root = Path(__file__).resolve().parent
    relative_prompt = Path("system.md")
    for root in (workspace, *workspace.parents):
        candidate = (root / package_root / relative_prompt).resolve()
        if candidate.is_file():
            return candidate
    packaged = package_root / relative_prompt
    if packaged.is_file():
        return packaged
    return None


def _build_bindings(workspace: Path) -> PromptBindings:
    return PromptBindings(
        work_dir=str(workspace),
        work_dir_listing=f"(omitted) work_dir={workspace}",
        agents_text=_merge_agents_documents(workspace),
    )


def _merge_agents_documents(workspace: Path) -> str:
    chunks: list[str] = []
    for candidate in _agents_candidates(workspace):
        text = _safe_read_text(candidate)
        if text:
            chunks.append(text)
    return "\n\n".join(chunks)


def _agents_candidates(workspace: Path) -> tuple[Path, Path]:
    return workspace / "AGENTS.md", Path.home() / ".nimbie" / "AGENTS.md"


def _render_prompt(template: str, bindings: PromptBindings) -> str:
    output = template
    output = output.replace("${WORK_DIR}", bindings.work_dir)
    output = output.replace("${WORK_DIR_LS}", bindings.work_dir_listing)
    output = output.replace("${AGENTS_MD}", bindings.agents_text)
    return output


def _safe_read_text(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except Exception:
        return None
