# 3brown1blue

Generate Manim animated explainer videos from any topic using an LLM, or install the Manim skill into your AI coding tool.

## Generate a video

```bash
# one-shot, no install needed
uvx '3brown1blue[anthropic]' generate "explain the attention mechanism"
uvx '3brown1blue[openai]' generate "explain backpropagation" --provider openai --render
```

```bash
# or install permanently
pip install '3brown1blue[all]'
3brown1blue generate "explain Fourier transforms" --provider google --render
```

The tool prompts for your provider if you don't pass `--provider`.

## Supported providers

| Provider | Install extra | Env var |
|----------|--------------|---------|
| Anthropic (Claude) | `[anthropic]` | `ANTHROPIC_API_KEY` |
| OpenAI (GPT) | `[openai]` | `OPENAI_API_KEY` |
| Google Gemini | `[openai]` | `GOOGLE_API_KEY` |
| Groq | `[openai]` | `GROQ_API_KEY` |
| Mistral | `[openai]` | `MISTRAL_API_KEY` |

Google, Groq, and Mistral all use the OpenAI-compatible API format.

## Generate options

```
3brown1blue generate TOPIC [OPTIONS]

  --provider  -p  anthropic | openai | google | groq | mistral
  --model     -m  model name (uses provider default if omitted)
  --api-key   -k  API key (or set the provider env var)
  --output    -o  output file  [default: scene.py]
  --render        run manim after generation
  --quality   -q  l=fast | m=medium | h=1080p | k=4K  [default: l]
```

## Install as a coding skill

The skill installs Manim knowledge (24 reference guides + templates) into your AI coding tool so it generates better animations without you prompting it.

```bash
uvx 3brown1blue install
```

Supports: **Claude Code**, **Cursor**, **Windsurf**, **GitHub Copilot**

## Prerequisites

To render animations you need Manim and LaTeX:

```bash
pip install manim
# macOS: brew install mactex
# Linux: apt install texlive-full
# Windows: install MiKTeX
```

## License

MIT
