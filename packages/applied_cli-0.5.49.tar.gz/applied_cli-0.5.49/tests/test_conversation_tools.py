import json

import pytest

from applied_cli import tools

CONVERSATION = {
    "id": "conv-123",
    "title": "Refund request",
    "status": "open",
    "resolution": "escalated",
    "type": "email",
    "remote_platform": "gorgias",
    "secondary_remote_platform": "zendesk",
    "human_readable_remote_platform": "Gorgias",
    "summary": (
        "Customer asked for a refund because the replacement item arrived damaged."
    ),
    "score": 2,
    "comment": "The customer is frustrated and wants a quick resolution.",
    "sentiment": "negative",
    "sentiment_score": -0.7,
    "created_at": "2026-03-20T10:00:00Z",
    "last_message_at": "2026-03-20T10:15:00Z",
    "message_count": 4,
    "ttr_seconds": 900,
    "is_one_touch": False,
    "source_url": "https://example.com/conversations/conv-123",
    "remote_id": "zendesk-42",
    "contact": {
        "name": "Casey Customer",
        "email": "casey@example.com",
    },
    "label": {"name": "Returns"},
    "sublabel": {"name": "Refund"},
    "user": {"email": "agent@example.com"},
    "agent": {"id": "agent-1", "name": "Refund Bot"},
    "flags": [{"name": "VIP"}, {"name": "Damaged item"}],
}

MESSAGES = [
    {
        "id": "msg-1",
        "created_at": "2026-03-20T10:00:00Z",
        "role": "user",
        "text": "I need help with a refund.",
        "contact": {"email": "casey@example.com"},
    },
    {
        "id": "msg-2",
        "created_at": "2026-03-20T10:05:00Z",
        "role": "assistant",
        "content": "I can help with that. What happened to the item?",
        "agent": {"name": "Refund Bot"},
    },
]

REFERENCES = [
    {
        "id": "ref-1",
        "message_id": "msg-2",
        "response": {
            "id": "resp-1",
            "type": "qa",
            "question": "What is the refund policy?",
        },
        "content": {
            "id": "content-1",
            "title": "Refund policy",
            "source_url": "https://example.com/policy",
        },
        "reason": "Matched refund policy article",
        "relevance_score": 0.9,
        "text_fragment_data": {"start": 0, "end": 25},
        "knowledge_gap": {
            "id": "gap-1",
            "title": "Add damaged-item examples",
        },
    }
]

SPANS = [
    {
        "span_id": "span-1",
        "span_name": "completion",
        "scope_name": "flows",
        "duration": 1.3,
        "status_code": "OK",
        "status_message": "",
        "span_attributes": {
            "tool_name": "Agent Response",
            "content": "I can help with that.",
        },
    }
]

FLOW_RUNS = [
    {
        "id": "run-1",
        "conversation_id": "conv-123",
        "status": "Success",
        "started_at": "2026-03-20T10:05:00Z",
        "ended_at": "2026-03-20T10:05:03Z",
        "duration": 3.0,
        "flow": {"id": "flow-1", "name": "Refund Flow"},
    }
]


class FakeClient:
    def __init__(self):
        self.query_kwargs = None
        self.query_calls = []
        self.query_results = [CONVERSATION]
        self.get_kwargs = None
        self.message_kwargs = None
        self.reference_kwargs = None
        self.spans_kwargs = None
        self.flow_run_kwargs = None
        self.create_scenario_kwargs = None
        self.bulk_run_kwargs = None
        self.analytics_report_kwargs = None

    async def query_conversations(self, **kwargs):
        self.query_kwargs = kwargs
        self.query_calls.append(kwargs)
        return list(self.query_results)

    async def get_conversation(self, conversation_id, *, shop_id=None):
        self.get_kwargs = {"conversation_id": conversation_id, "shop_id": shop_id}
        return CONVERSATION

    async def get_messages(
        self,
        *,
        conversation_id=None,
        ticket_id=None,
        limit=50,
        ordering="created_at",
        shop_id=None,
    ):
        self.message_kwargs = {
            "conversation_id": conversation_id,
            "ticket_id": ticket_id,
            "limit": limit,
            "ordering": ordering,
            "shop_id": shop_id,
        }
        return MESSAGES

    async def get_conversation_references(self, conversation_id, *, shop_id=None):
        self.reference_kwargs = {
            "conversation_id": conversation_id,
            "shop_id": shop_id,
        }
        return REFERENCES

    async def get_spans(self, object_type, object_id):
        self.spans_kwargs = {
            "object_type": object_type,
            "object_id": object_id,
        }
        return SPANS

    async def list_flow_runs(
        self,
        flow_id=None,
        conversation_id=None,
        status=None,
        limit=20,
    ):
        self.flow_run_kwargs = {
            "flow_id": flow_id,
            "conversation_id": conversation_id,
            "status": status,
            "limit": limit,
        }
        return FLOW_RUNS

    async def create_scenario(
        self,
        input_conversation_id,
        name,
        benchmark_id=None,
        benchmark_name=None,
        agent_id=None,
    ):
        self.create_scenario_kwargs = {
            "input_conversation_id": input_conversation_id,
            "name": name,
            "benchmark_id": benchmark_id,
            "benchmark_name": benchmark_name,
            "agent_id": agent_id,
        }
        return {
            "id": "scenario-1",
            "name": name,
            "benchmark": {
                "id": benchmark_id or "bench-1",
                "name": benchmark_name or "GoPure Repro",
            },
        }

    async def bulk_run_scenarios(
        self,
        scenario_ids=None,
        benchmark_id=None,
        target_agent_id=None,
    ):
        self.bulk_run_kwargs = {
            "scenario_ids": scenario_ids,
            "benchmark_id": benchmark_id,
            "target_agent_id": target_agent_id,
        }
        return {
            "job_id": "job-1",
            "total": len(scenario_ids or []),
            "queued": len(scenario_ids or []),
            "scenario_run_ids": ["scenario-run-1"],
            "target_agent_id": target_agent_id,
        }

    async def analytics_report(self, payload):
        self.analytics_report_kwargs = payload
        return {
            "escalation_rate": [
                {
                    "period": "2026-03-22",
                    "value": 0.18,
                }
            ]
        }


@pytest.mark.asyncio
async def test_conversation_query_defaults_to_search_view():
    client = FakeClient()

    result = await tools.conversation_query(
        client,
        search="refund",
        output_format="csv",
    )

    lines = result.strip().splitlines()
    assert lines[0] == "# 1 results"
    assert (
        lines[1]
        == "id,title,remote_platform,remote_id,contact_name,contact_email,status,resolution,topic,intent,assigned_user_email,agent_name,last_message_at,message_count,flags,summary"
    )
    assert "Refund request" in lines[2]
    assert "Casey Customer" in lines[2]
    assert "VIP, Damaged item" in lines[2]
    assert client.query_kwargs["search"] == "refund"


@pytest.mark.asyncio
async def test_conversation_query_fields_override_view():
    client = FakeClient()

    result = await tools.conversation_query(
        client,
        fields=["id", "contact.email"],
        view="detail",
        output_format="csv",
    )

    lines = result.strip().splitlines()
    assert lines[1] == "id,contact.email"
    assert lines[2] == "conv-123,casey@example.com"


@pytest.mark.asyncio
async def test_conversation_query_distinct_by_dedupes_rows():
    client = FakeClient()
    duplicate = json.loads(json.dumps(CONVERSATION))
    duplicate["id"] = "conv-456"
    duplicate["remote_id"] = "zendesk-99"
    client.query_results = [CONVERSATION, duplicate]

    result = await tools.conversation_query(
        client,
        fields=["id", "contact.email"],
        distinct_by=["contact.email"],
        output_format="csv",
    )

    lines = result.strip().splitlines()
    assert lines[0] == "# 1 results"
    assert lines[1] == "id,contact.email"
    assert lines[2] == "conv-123,casey@example.com"


@pytest.mark.asyncio
async def test_conversation_get_returns_structured_payload_with_messages():
    client = FakeClient()

    result = await tools.conversation_get(
        client,
        "conv-123",
        include_messages=True,
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["view"] == "detail"
    assert payload["message_view"] == "compact"
    assert payload["conversation"]["contact_email"] == "casey@example.com"
    assert payload["conversation"]["flags"] == "VIP, Damaged item"
    assert payload["messages"][0]["author"] == "casey@example.com"
    assert payload["messages"][1]["author"] == "Refund Bot"
    assert payload["messages"][1]["content"] == "I can help with that. What happened to the item?"
    assert client.get_kwargs == {"conversation_id": "conv-123", "shop_id": None}
    assert client.message_kwargs["conversation_id"] == "conv-123"


@pytest.mark.asyncio
async def test_conversation_lookup_resolves_remote_ticket_url():
    client = FakeClient()

    result = await tools.conversation_lookup(
        client,
        identifier="https://gopure-beauty.gorgias.com/app/ticket/566129454",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["lookup"]["platform"] == "gorgias"
    assert payload["lookup"]["primary_value"] == "566129454"
    assert payload["matches"][0]["matched_by"] == "remote_id"
    assert client.query_calls[0]["filters"] == {
        "remote_id": "566129454",
        "remote_platform": "gorgias",
    }


@pytest.mark.asyncio
async def test_conversation_debug_returns_lookup_bundle_for_remote_identifier():
    client = FakeClient()

    result = await tools.conversation_debug(
        client,
        identifier="https://gopure-beauty.gorgias.com/app/ticket/566129454",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["lookup"]["matched_by"] == ["remote_id"]
    assert payload["conversation"]["remote_platform"] == "gorgias"
    assert payload["messages"][1]["content"] == "I can help with that. What happened to the item?"
    assert payload["message_references"][0]["content_title"] == "Refund policy"
    assert payload["flow_runs"][0]["flow_name"] == "Refund Flow"
    assert payload["spans"][0]["tool_name"] == "Agent Response"
    assert client.reference_kwargs == {"conversation_id": "conv-123", "shop_id": None}
    assert client.spans_kwargs == {"object_type": "conversations", "object_id": "conv-123"}
    assert client.flow_run_kwargs["conversation_id"] == "conv-123"


@pytest.mark.asyncio
async def test_conversation_repro_creates_and_runs_scenario_from_remote_identifier():
    client = FakeClient()

    result = await tools.conversation_repro(
        client,
        identifier="https://gopure-beauty.gorgias.com/app/ticket/566129454",
        benchmark_name="GoPure Fixes",
        run_now=True,
        target_agent_id="agent-2",
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["conversation_id"] == "conv-123"
    assert payload["scenario"]["id"] == "scenario-1"
    assert payload["run"]["job_id"] == "job-1"
    assert client.create_scenario_kwargs == {
        "input_conversation_id": "conv-123",
        "name": "Refund request",
        "benchmark_id": None,
        "benchmark_name": "GoPure Fixes",
        "agent_id": "agent-1",
    }
    assert client.bulk_run_kwargs == {
        "scenario_ids": ["scenario-1"],
        "benchmark_id": None,
        "target_agent_id": "agent-2",
    }


@pytest.mark.asyncio
async def test_analytics_report_returns_structured_json_payload():
    client = FakeClient()

    result = await tools.analytics_report(
        client,
        view="dashboard_rate_metrics",
        group_by="agent_revision_version",
        period="day",
        start="2026-03-15",
        end="2026-03-22",
        timezone="America/Los_Angeles",
        conversation_filters={"agent_revision_version": "448"},
        custom_rate_metrics_requests=[
            {
                "rate": "escalation_rate",
                "numerator": "escalated_total_cnt",
                "denominator": "total",
            }
        ],
        output_format="json",
    )

    payload = json.loads(result)
    assert payload["escalation_rate"][0]["value"] == 0.18
    assert client.analytics_report_kwargs == {
        "view": "dashboard_rate_metrics",
        "model": "conversation",
        "group_by": "agent_revision_version",
        "period": "day",
        "start_date": "2026-03-15",
        "end_date": "2026-03-22",
        "tz": "America/Los_Angeles",
        "conversation_filters": {"agent_revision_version": "448"},
        "custom_rate_metrics_requests": [
            {
                "rate": "escalation_rate",
                "numerator": "escalated_total_cnt",
                "denominator": "total",
            }
        ],
    }
