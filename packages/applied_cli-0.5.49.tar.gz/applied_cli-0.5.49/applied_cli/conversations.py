"""Conversation projections shared by CLI and MCP tools."""

from __future__ import annotations

import json
from typing import Any

from applied_cli.formatters import get_nested_value, to_json

SUMMARY_PREVIEW_LIMIT = 280
COMMENT_PREVIEW_LIMIT = 160

_CONVERSATION_VIEW_FIELDS: dict[str, tuple[str, ...]] = {
    "ids": ("id",),
    "search": (
        "id",
        "title",
        "remote_platform",
        "remote_id",
        "contact_name",
        "contact_email",
        "status",
        "resolution",
        "topic",
        "intent",
        "assigned_user_email",
        "agent_name",
        "last_message_at",
        "message_count",
        "flags",
        "summary",
    ),
    "detail": (
        "id",
        "title",
        "contact_name",
        "contact_email",
        "status",
        "resolution",
        "type",
        "remote_platform",
        "secondary_remote_platform",
        "human_readable_remote_platform",
        "topic",
        "intent",
        "assigned_user_email",
        "agent_name",
        "score",
        "comment",
        "sentiment",
        "sentiment_score",
        "created_at",
        "last_message_at",
        "message_count",
        "ttr_seconds",
        "is_one_touch",
        "flags",
        "summary",
        "source_url",
        "remote_id",
    ),
}

_CONVERSATION_VIEW_ALIASES = {
    "default": "search",
    "id": "ids",
    "list": "search",
    "lookup": "search",
    "raw": "full",
    "summary": "search",
}

_MESSAGE_VIEW_ALIASES = {
    "default": "compact",
    "raw": "full",
    "summary": "compact",
}

_MESSAGE_VIEW_FIELDS: dict[str, tuple[str, ...]] = {
    "compact": ("id", "created_at", "role", "author", "content"),
}


def _coerce_string(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    if isinstance(value, (dict, list)):
        return json.dumps(value, default=str, ensure_ascii=True)
    return str(value)


def _compact_text(value: Any, *, limit: int | None = None) -> str | None:
    text = _coerce_string(value)
    if text is None:
        return None
    compact = " ".join(text.split())
    if limit and len(compact) > limit:
        return f"{compact[: limit - 3].rstrip()}..."
    return compact


def _first_non_empty(*values: Any) -> str | None:
    for value in values:
        text = _compact_text(value)
        if text:
            return text
    return None


def _join_names(items: Any) -> str:
    if not isinstance(items, list):
        return ""

    values: list[str] = []
    for item in items:
        if isinstance(item, dict):
            text = _first_non_empty(item.get("name"), item.get("title"), item.get("id"))
        else:
            text = _compact_text(item)
        if text:
            values.append(text)
    return ", ".join(values)


def resolve_conversation_view(
    view: str | None,
    *,
    default: str,
) -> str:
    normalized = (view or default).strip().lower()
    normalized = _CONVERSATION_VIEW_ALIASES.get(normalized, normalized)

    if normalized == "full" or normalized in _CONVERSATION_VIEW_FIELDS:
        return normalized

    available = ", ".join(["ids", "search", "detail", "full"])
    raise ValueError(f"view must be one of: {available}")


def resolve_message_view(view: str | None, *, default: str = "compact") -> str:
    normalized = (view or default).strip().lower()
    normalized = _MESSAGE_VIEW_ALIASES.get(normalized, normalized)

    if normalized == "full" or normalized in _MESSAGE_VIEW_FIELDS:
        return normalized

    available = ", ".join(["compact", "full"])
    raise ValueError(f"message_view must be one of: {available}")


def conversation_view_fields(view: str) -> list[str] | None:
    if view == "full":
        return None
    return list(_CONVERSATION_VIEW_FIELDS[view])


def _base_conversation_projection(conversation: dict[str, Any]) -> dict[str, Any]:
    return {
        "id": conversation.get("id"),
        "title": _compact_text(conversation.get("title")),
        "contact_name": _first_non_empty(
            get_nested_value(conversation, "contact.name"),
            get_nested_value(conversation, "contact.full_name"),
        ),
        "contact_email": _compact_text(get_nested_value(conversation, "contact.email")),
        "status": conversation.get("status"),
        "resolution": conversation.get("resolution"),
        "type": conversation.get("type"),
        "remote_platform": conversation.get("remote_platform"),
        "secondary_remote_platform": conversation.get("secondary_remote_platform"),
        "human_readable_remote_platform": _compact_text(
            conversation.get("human_readable_remote_platform")
        ),
        "topic": _compact_text(get_nested_value(conversation, "label.name")),
        "intent": _compact_text(get_nested_value(conversation, "sublabel.name")),
        "assigned_user_email": _compact_text(get_nested_value(conversation, "user.email")),
        "agent_name": _compact_text(get_nested_value(conversation, "agent.name")),
        "score": conversation.get("score"),
        "comment": _compact_text(
            conversation.get("comment"),
            limit=COMMENT_PREVIEW_LIMIT,
        ),
        "sentiment": conversation.get("sentiment"),
        "sentiment_score": conversation.get("sentiment_score"),
        "created_at": conversation.get("created_at"),
        "last_message_at": conversation.get("last_message_at"),
        "message_count": conversation.get("message_count"),
        "ttr_seconds": conversation.get("ttr_seconds"),
        "is_one_touch": conversation.get("is_one_touch"),
        "flags": _join_names(conversation.get("flags")),
        "summary": _compact_text(
            conversation.get("summary"),
            limit=SUMMARY_PREVIEW_LIMIT,
        ),
        "source_url": _compact_text(conversation.get("source_url")),
        "remote_id": _compact_text(conversation.get("remote_id")),
    }


def project_conversation(conversation: dict[str, Any], view: str) -> dict[str, Any]:
    if view == "full":
        return dict(conversation)

    projection = _base_conversation_projection(conversation)
    return {field: projection.get(field) for field in _CONVERSATION_VIEW_FIELDS[view]}


def project_conversations(
    conversations: list[dict[str, Any]],
    *,
    view: str,
) -> list[dict[str, Any]]:
    return [project_conversation(conversation, view) for conversation in conversations]


def _message_author(message: dict[str, Any]) -> str | None:
    return _first_non_empty(
        get_nested_value(message, "agent.name"),
        get_nested_value(message, "user.email"),
        get_nested_value(message, "user.name"),
        get_nested_value(message, "contact.email"),
        get_nested_value(message, "contact.name"),
    )


def _message_content(message: dict[str, Any]) -> str | None:
    return _coerce_string(message.get("text")) or _coerce_string(message.get("content"))


def project_message(message: dict[str, Any], view: str) -> dict[str, Any]:
    if view == "full":
        return dict(message)

    projection = {
        "id": message.get("id"),
        "created_at": message.get("created_at"),
        "role": message.get("role"),
        "author": _message_author(message),
        "content": _message_content(message),
    }
    return {field: projection.get(field) for field in _MESSAGE_VIEW_FIELDS[view]}


def project_messages(
    messages: list[dict[str, Any]],
    *,
    view: str,
) -> list[dict[str, Any]]:
    return [project_message(message, view) for message in messages]


def build_conversation_payload(
    conversation: dict[str, Any],
    *,
    view: str,
    messages: list[dict[str, Any]] | None = None,
    message_view: str = "compact",
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "view": view,
        "conversation": project_conversation(conversation, view),
    }
    if messages is not None:
        payload["message_view"] = message_view
        payload["messages"] = project_messages(messages, view=message_view)
    return payload


def render_conversation_text(payload: dict[str, Any]) -> str:
    result = f"# Conversation\n{to_json(payload['conversation'])}"

    if "messages" in payload:
        messages = payload["messages"]
        result += f"\n\n# Messages ({len(messages)})\n{to_json(messages)}"

    return result
