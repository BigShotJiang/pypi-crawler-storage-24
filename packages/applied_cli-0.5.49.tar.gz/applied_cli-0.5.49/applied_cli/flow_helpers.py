"""Flow helper functions shared by CLI and MCP tools."""

from __future__ import annotations

import re
from collections import defaultdict, deque
from typing import Any

FLOW_HORIZONTAL_GAP = 380
FLOW_VERTICAL_GAP = 220

_CANONICAL_EXECUTOR_TYPES: tuple[str, ...] = (
    "completion",
    "structured_completion",
    "branch",
    "code",
    "http_request",
    "loop",
    "memory",
    "search",
    "recommend",
    "flow",
    "end_flow",
    "global",
    "_escalate_conversation",
    "handoff",
    "resource",
    "mutate_ticket",
    "mutate_conversation",
    "mutate_message",
)

_EXECUTOR_UI_LABELS: dict[str, str] = {
    "completion": "Agent Response",
    "structured_completion": "Analyze & Return Data",
    "branch": "Branch",
    "code": "Code",
    "http_request": "HTTP Request",
    "loop": "Loop",
    "memory": "Memory",
    "search": "Search",
    "recommend": "Recommend",
    "flow": "Run Flow",
    "end_flow": "End Flow & Return",
    "global": "Global",
    "_escalate_conversation": "Escalate Conversation",
    "handoff": "Agent Hand Off",
    "resource": "Resource",
    "mutate_ticket": "Ticket",
    "mutate_conversation": "Conversation",
    "mutate_message": "Add Message",
}

_EXECUTOR_ALIASES: dict[str, tuple[str, ...]] = {
    "completion": ("agent response", "response"),
    "structured_completion": (
        "analyze",
        "analyze return data",
        "analyze and return data",
        "structured completion",
    ),
    "flow": ("run flow", "run_flow", "subflow"),
    "end_flow": (
        "end flow return",
        "end flow and return",
        "return data",
        "return_data",
    ),
    "resource": ("connector", "integration"),
    "mutate_ticket": ("ticket",),
    "mutate_conversation": ("conversation",),
    "mutate_message": ("add message",),
}

_BRANCH_DEFAULT_ALIASES = {
    "default",
    "default branch",
    "else",
    "fallback",
    "fallback branch",
}

_BRANCH_INDEX_RE = re.compile(r"^(?:branch\s+)?(\d+)$")


def _normalize_key(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.lower()).strip()


_EXECUTOR_ALIAS_LOOKUP: dict[str, str] = {}
for canonical in _CANONICAL_EXECUTOR_TYPES:
    _EXECUTOR_ALIAS_LOOKUP[_normalize_key(canonical)] = canonical
    _EXECUTOR_ALIAS_LOOKUP[_normalize_key(_EXECUTOR_UI_LABELS[canonical])] = canonical
    for alias in _EXECUTOR_ALIASES.get(canonical, ()):
        _EXECUTOR_ALIAS_LOOKUP[_normalize_key(alias)] = canonical


def canonical_executor_types() -> list[str]:
    """Return the supported canonical executor types."""
    return list(_CANONICAL_EXECUTOR_TYPES)


def executor_ui_label(executor_type: str) -> str:
    """Return the frontend label for a canonical executor type."""
    return _EXECUTOR_UI_LABELS.get(executor_type, executor_type)


def executor_aliases(executor_type: str) -> list[str]:
    """Return accepted aliases for a canonical executor type."""
    aliases = {_EXECUTOR_UI_LABELS.get(executor_type, executor_type), executor_type}
    aliases.update(_EXECUTOR_ALIASES.get(executor_type, ()))
    return sorted(aliases)


def normalize_executor_type(executor_type: str) -> str:
    """Map frontend labels and legacy aliases to canonical executor names."""
    canonical = _EXECUTOR_ALIAS_LOOKUP.get(_normalize_key(executor_type))
    if canonical:
        return canonical

    available = ", ".join(
        f"{ui} ({canonical})"
        for canonical, ui in _EXECUTOR_UI_LABELS.items()
    )
    raise ValueError(
        f"Unknown executor_type '{executor_type}'. Use UI labels like "
        f"'Agent Response' or canonical names like 'completion'. Available: {available}"
    )


def normalize_branch_handle(value: str | int | None) -> str | None:
    """Normalize a branch identifier to a backend source_handle."""
    if value is None:
        return None
    if isinstance(value, int):
        return str(value)

    raw = str(value).strip()
    if not raw:
        return None

    normalized = _normalize_key(raw)
    if normalized in _BRANCH_DEFAULT_ALIASES:
        return "default"

    match = _BRANCH_INDEX_RE.fullmatch(normalized)
    if match:
        return str(int(match.group(1)))

    return raw


def branch_handle_label(handle: str) -> str:
    """Return a human-readable label for a normalized branch handle."""
    if handle == "default":
        return "Default branch"
    return f"Branch {handle}"


def branch_handle_sort_key(handle: str | None) -> tuple[int, int | str]:
    """Sort numbered handles before the default branch and unknown handles last."""
    normalized = normalize_branch_handle(handle)
    if normalized is None:
        return (2, "")
    if normalized == "default":
        return (1, 0)
    if normalized.isdigit():
        return (0, int(normalized))
    return (2, normalized)


def get_node_type(node: dict[str, Any]) -> str:
    """Return the canonical node type from a flow graph node."""
    return node.get("type") or node.get("data", {}).get("executor_type", "")


def get_node_name(node: dict[str, Any]) -> str:
    """Return the UI display name for a node."""
    data = node.get("data", {})
    return data.get("humanReadableName") or data.get("name") or node.get("id", "")


def get_node_position(node: dict[str, Any]) -> tuple[float, float]:
    """Return a node's current position, falling back to metadata when needed."""
    top_level = node.get("position") or {}
    metadata = node.get("data", {}).get("metadata", {}).get("position", {}) or {}
    x = top_level.get("x", metadata.get("x", 0)) or 0
    y = top_level.get("y", metadata.get("y", 0)) or 0
    return float(x), float(y)


def suggest_node_position(flow: dict[str, Any]) -> dict[str, int]:
    """Suggest a non-overlapping default position for a newly-created node."""
    nodes = flow.get("graph", {}).get("nodes", [])
    flow_type = flow.get("type", "conversational")
    if not nodes:
        return {"x": 0, "y": 0}

    positioned_nodes = [(node, *get_node_position(node)) for node in nodes]
    if flow_type == "operational":
        anchor, x, y = max(positioned_nodes, key=lambda item: (item[2], item[1]))
        return {"x": int(x), "y": int(y + FLOW_VERTICAL_GAP)}

    anchor, x, y = max(positioned_nodes, key=lambda item: (item[1], item[2]))
    return {"x": int(x + FLOW_HORIZONTAL_GAP), "y": int(y)}


def compute_flow_layout(flow: dict[str, Any]) -> dict[str, dict[str, int]]:
    """Compute a simple deterministic layout for a flow graph."""
    graph = flow.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])
    flow_type = flow.get("type", "conversational")

    if not nodes:
        return {}

    node_map = {node["id"]: node for node in nodes}
    indegree = {node["id"]: 0 for node in nodes}
    working_indegree = dict(indegree)
    adjacency: dict[str, list[dict[str, Any]]] = {node["id"]: [] for node in nodes}

    for edge in edges:
        source = edge.get("source")
        target = edge.get("target")
        if source not in node_map or target not in node_map:
            continue
        adjacency[source].append(edge)
        indegree[target] += 1
        working_indegree[target] += 1

    def node_sort_key(node_id: str) -> tuple[int, float, float, str]:
        node = node_map[node_id]
        node_type = get_node_type(node)
        type_order = 0 if node_type == "trigger" else 1 if node_type == "global" else 2
        x, y = get_node_position(node)
        return (type_order, x, y, get_node_name(node))

    def outgoing_edges(node_id: str) -> list[dict[str, Any]]:
        return sorted(
            adjacency[node_id],
            key=lambda edge: (
                branch_handle_sort_key(edge.get("sourceHandle")),
                node_sort_key(edge["target"]),
            ),
        )

    roots = sorted(
        [node_id for node_id, degree in indegree.items() if degree == 0],
        key=node_sort_key,
    )
    if not roots:
        roots = sorted(node_map, key=node_sort_key)

    depth = {root: 0 for root in roots}
    queue = deque(roots)
    while queue:
        node_id = queue.popleft()
        for edge in outgoing_edges(node_id):
            target = edge["target"]
            next_depth = depth.get(node_id, 0) + 1
            if next_depth > depth.get(target, -1):
                depth[target] = next_depth
            working_indegree[target] -= 1
            if working_indegree[target] == 0:
                queue.append(target)

    visit_order: dict[str, int] = {}
    order_counter = 0

    def dfs(node_id: str) -> None:
        nonlocal order_counter
        if node_id in visit_order:
            return
        visit_order[node_id] = order_counter
        order_counter += 1
        for edge in outgoing_edges(node_id):
            dfs(edge["target"])

    for root in roots:
        dfs(root)
    for node_id in sorted(node_map, key=node_sort_key):
        dfs(node_id)

    level_members: dict[int, list[str]] = defaultdict(list)
    for node_id in node_map:
        level_members[depth.get(node_id, 0)].append(node_id)

    positions: dict[str, dict[str, int]] = {}
    for level in sorted(level_members):
        ordered_nodes = sorted(
            level_members[level],
            key=lambda node_id: (
                visit_order.get(node_id, 0),
                *get_node_position(node_map[node_id]),
                get_node_name(node_map[node_id]),
            ),
        )
        for index, node_id in enumerate(ordered_nodes):
            if flow_type == "operational":
                x = index * FLOW_HORIZONTAL_GAP
                y = level * FLOW_VERTICAL_GAP
            else:
                x = level * FLOW_HORIZONTAL_GAP
                y = index * FLOW_VERTICAL_GAP
            positions[node_id] = {"x": int(x), "y": int(y)}

    return positions
