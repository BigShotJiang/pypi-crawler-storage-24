//! Dispatch metadata stage: Prepare metadata for dispatch

use std::time::{SystemTime, UNIX_EPOCH};

use async_trait::async_trait;
use axum::response::Response;
use tracing::error;

use super::PipelineStage;
use crate::{
    core::UNKNOWN_MODEL_ID,
    routers::{
        error,
        grpc::context::{DispatchMetadata, RequestContext, RequestType, WorkerSelection},
    },
};

/// Dispatch metadata stage: Prepare metadata for dispatch
pub(crate) struct DispatchMetadataStage;

#[async_trait]
impl PipelineStage for DispatchMetadataStage {
    async fn execute(&self, ctx: &mut RequestContext) -> Result<Option<Response>, Response> {
        let proto_request = ctx.state.proto_request.as_ref().ok_or_else(|| {
            error!(
                function = "DispatchMetadataStage::execute",
                "Proto request not built"
            );
            error::internal_error("proto_request_not_built", "Proto request not built")
        })?;

        let request_id = proto_request.request_id().to_string();
        let model = match &ctx.input.request_type {
            RequestType::Chat(req) => req.model.clone(),
            RequestType::Generate(_req) => {
                // Generate requests don't have a model field
                // Use model_id from input or UNKNOWN_MODEL_ID
                ctx.input
                    .model_id
                    .clone()
                    .unwrap_or_else(|| UNKNOWN_MODEL_ID.to_string())
            }
            RequestType::Responses(req) => req.model.clone(),
            RequestType::Embedding(req) => req.model.clone(),
            RequestType::Classify(req) => req.model.clone(),
            RequestType::Messages(req) => req.model.clone(),
        };

        let weight_version = ctx
            .state
            .workers
            .as_ref()
            .map(|w| match w {
                WorkerSelection::Single { worker } => worker,
                WorkerSelection::Dual { decode, .. } => decode,
            })
            .and_then(|w| w.metadata().spec.labels.get("weight_version").cloned())
            .unwrap_or_else(|| "default".to_string());

        let created = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap_or_default()
            .as_secs();

        ctx.state.dispatch = Some(DispatchMetadata {
            request_id,
            model,
            created,
            weight_version: Some(weight_version),
        });

        Ok(None)
    }

    fn name(&self) -> &'static str {
        "DispatchMetadata"
    }
}
