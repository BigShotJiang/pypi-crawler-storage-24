//! Power-of-two choices load balancing policy

use std::{
    collections::HashMap,
    sync::{Arc, RwLock},
};

use openai_protocol::worker::WorkerLoadResponse;
use rand::Rng;
use tracing::debug;

use super::{get_healthy_worker_indices, LoadBalancingPolicy, SelectWorkerInfo};
use crate::core::Worker;

/// Power-of-two choices policy
///
/// Randomly selects two workers and routes to the one with lower load.
/// This provides good load distribution with minimal coordination overhead.
#[derive(Debug)]
pub struct PowerOfTwoPolicy {
    /// Cached load information from external monitoring
    cached_loads: RwLock<HashMap<String, WorkerLoadResponse>>,
}

impl PowerOfTwoPolicy {
    pub fn new() -> Self {
        Self {
            cached_loads: RwLock::new(HashMap::new()),
        }
    }
}

impl LoadBalancingPolicy for PowerOfTwoPolicy {
    fn select_worker(
        &self,
        workers: &[Arc<dyn Worker>],
        _info: &SelectWorkerInfo,
    ) -> Option<usize> {
        let healthy_indices = get_healthy_worker_indices(workers);

        if healthy_indices.is_empty() {
            return None;
        }

        if healthy_indices.len() == 1 {
            return Some(healthy_indices[0]);
        }

        // Select two random workers - use offset to guarantee different selection in O(1)
        let mut rng = rand::rng();
        let idx1 = rng.random_range(0..healthy_indices.len());
        // Pick idx2 from remaining indices: offset by 1 + random from (len-1) to guarantee different
        let idx2 =
            (idx1 + 1 + rng.random_range(0..healthy_indices.len() - 1)) % healthy_indices.len();

        let worker_idx1 = healthy_indices[idx1];
        let worker_idx2 = healthy_indices[idx2];
        let worker1 = &workers[worker_idx1];
        let worker2 = &workers[worker_idx2];

        // Access cached loads safely
        let loads_guard = self.cached_loads.read().ok();

        // Try to get high-fidelity token usage for BOTH workers
        let load1_response = loads_guard.as_ref().and_then(|m| m.get(worker1.url()));
        let load2_response = loads_guard.as_ref().and_then(|m| m.get(worker2.url()));

        // If either worker is missing token data (e.g. monitor failure),
        // we must degrade BOTH to request counts to ensure fairness.
        let (load1, load2, metric_label) = match (load1_response, load2_response) {
            (Some(r1), Some(r2)) => {
                // Both have load data. Compare by token usage ratio (0.0–1.0).
                (
                    r1.effective_token_usage(),
                    r2.effective_token_usage(),
                    "token_usage",
                )
            }
            _ => {
                // One or both are missing load data.
                // Fallback to local request counts for BOTH.
                (
                    worker1.load() as f64,
                    worker2.load() as f64,
                    "request_count",
                )
            }
        };

        // Select worker with lower load
        let selected_idx = if load1 <= load2 {
            worker_idx1
        } else {
            worker_idx2
        };

        debug!(
            "Power-of-two selection ({metric_label}): {}={:.4} vs {}={:.4} -> selected {}",
            worker1.url(),
            load1,
            worker2.url(),
            load2,
            workers[selected_idx].url()
        );

        // Increment processed counter
        workers[selected_idx].increment_processed();

        Some(selected_idx)
    }

    fn name(&self) -> &'static str {
        "power_of_two"
    }

    fn update_loads(&self, loads: &HashMap<String, WorkerLoadResponse>) {
        if let Ok(mut cached) = self.cached_loads.write() {
            cached.extend(loads.iter().map(|(k, v)| (k.clone(), v.clone())));
        }
    }

    fn as_any(&self) -> &dyn std::any::Any {
        self
    }
}

impl Default for PowerOfTwoPolicy {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use openai_protocol::worker::SchedulerLoadSnapshot;

    use super::*;
    use crate::core::{BasicWorkerBuilder, WorkerType};

    /// Create a `WorkerLoadResponse` with a single DP rank at the given token_usage ratio.
    fn make_load(token_usage: f64) -> WorkerLoadResponse {
        WorkerLoadResponse {
            timestamp: String::new(),
            dp_rank_count: 1,
            loads: vec![SchedulerLoadSnapshot {
                dp_rank: 0,
                num_running_reqs: 0,
                num_waiting_reqs: 0,
                num_total_reqs: 0,
                num_used_tokens: 0,
                max_total_num_tokens: 0,
                token_usage,
                gen_throughput: 0.0,
                cache_hit_rate: 0.0,
                utilization: 0.0,
                max_running_requests: 0,
            }],
        }
    }

    #[test]
    fn test_power_of_two_selection() {
        let policy = PowerOfTwoPolicy::new();
        let worker1 = BasicWorkerBuilder::new("http://w1:8000")
            .worker_type(WorkerType::Regular)
            .build();
        let worker2 = BasicWorkerBuilder::new("http://w2:8000")
            .worker_type(WorkerType::Regular)
            .build();
        let worker3 = BasicWorkerBuilder::new("http://w3:8000")
            .worker_type(WorkerType::Regular)
            .build();

        // Set different loads
        for _ in 0..10 {
            worker1.increment_load();
        }
        for _ in 0..5 {
            worker2.increment_load();
        }
        // worker3 has load 0

        let workers: Vec<Arc<dyn Worker>> =
            vec![Arc::new(worker1), Arc::new(worker2), Arc::new(worker3)];

        // Run multiple selections (no cached loads → fallback to request counts)
        let mut selected_counts = [0; 3];
        let info = SelectWorkerInfo::default();
        for _ in 0..100 {
            if let Some(idx) = policy.select_worker(&workers, &info) {
                selected_counts[idx] += 1;
            }
        }

        // Worker with lowest load (worker3) should be selected most often
        assert!(selected_counts[2] > selected_counts[1]);
        assert!(selected_counts[1] > selected_counts[0]);
    }

    #[test]
    fn test_power_of_two_with_cached_loads() {
        let policy = PowerOfTwoPolicy::new();
        let workers: Vec<Arc<dyn Worker>> = vec![
            Arc::new(
                BasicWorkerBuilder::new("http://w1:8000")
                    .worker_type(WorkerType::Regular)
                    .build(),
            ),
            Arc::new(
                BasicWorkerBuilder::new("http://w2:8000")
                    .worker_type(WorkerType::Regular)
                    .build(),
            ),
        ];

        // Update cached loads: w1 at 80% usage, w2 at 10% usage
        let mut loads = HashMap::new();
        loads.insert("http://w1:8000".to_string(), make_load(0.8));
        loads.insert("http://w2:8000".to_string(), make_load(0.1));
        policy.update_loads(&loads);

        // Should prefer worker2 with lower token usage
        let mut w2_selected = 0;
        let info = SelectWorkerInfo::default();
        for _ in 0..50 {
            if let Some(idx) = policy.select_worker(&workers, &info) {
                if idx == 1 {
                    w2_selected += 1;
                }
            }
        }

        // Worker2 should be selected significantly more often
        assert!(w2_selected > 35); // Should win most of the time
    }

    #[test]
    fn test_power_of_two_single_worker() {
        let policy = PowerOfTwoPolicy::new();
        let workers: Vec<Arc<dyn Worker>> = vec![Arc::new(
            BasicWorkerBuilder::new("http://w1:8000")
                .worker_type(WorkerType::Regular)
                .build(),
        )];

        // With single worker, should always select it
        assert_eq!(
            policy.select_worker(&workers, &SelectWorkerInfo::default()),
            Some(0)
        );
    }

    #[test]
    #[expect(clippy::print_stdout, reason = "test diagnostic output")]
    fn test_reproduce_incompatible_metric_bug() {
        use std::{collections::HashMap, sync::Arc};

        use crate::core::{BasicWorkerBuilder, WorkerType};

        // 1. Setup the policy
        let policy = PowerOfTwoPolicy::new();

        // 2. Create Worker A: Idle (0 reqs), but has high token usage in cache
        let worker_a = BasicWorkerBuilder::new("http://worker_a:8000")
            .worker_type(WorkerType::Regular)
            .build();

        // 3. Create Worker B: Busy (5 reqs), but missing from cache
        let worker_b = BasicWorkerBuilder::new("http://worker_b:8000")
            .worker_type(WorkerType::Regular)
            .build();

        // Manually increment load on Worker B to simulate active requests
        for _ in 0..5 {
            worker_b.increment_load();
        }

        let workers: Vec<Arc<dyn Worker>> = vec![Arc::new(worker_a), Arc::new(worker_b)];

        // 4. Simulate LoadMonitor update:
        // Only Worker A gets a token report. Worker B is missing (e.g. monitor failure).
        let mut loads = HashMap::new();
        loads.insert("http://worker_a:8000".to_string(), make_load(0.9));
        policy.update_loads(&loads);

        // 5. Run selection
        let selected_idx = policy
            .select_worker(&workers, &SelectWorkerInfo::default())
            .expect("Should select a worker");

        // 6. Verify the Fix
        // Logic:
        // - Worker A has token load data but Worker B does NOT.
        // - Policy should fallback to request counts for BOTH.
        // - A has 0 requests, B has 5 requests.
        // - 0 <= 5, so A should be selected.

        if selected_idx == 0 {
            println!("Bug Fixed: System correctly fell back to request counts and selected idle Worker A.");
        } else {
            println!("Bug PERSISTS: Selected Worker B (Load: 5 reqs) over Worker A");
        }

        // Assert that the CORRECT worker (A, index 0) is selected
        assert_eq!(
            selected_idx, 0,
            "The policy failed to handle incompatible metrics. Should select idle Worker A."
        );
    }

    #[test]
    #[expect(clippy::print_stdout, reason = "test diagnostic output")]
    fn test_power_of_two_edge_cases() {
        use std::{collections::HashMap, sync::Arc};

        use crate::core::{BasicWorkerBuilder, WorkerType};

        let policy = PowerOfTwoPolicy::new();

        // Helper to create a worker with specific request load
        let create_worker = |url: &str, reqs: usize| {
            let w = BasicWorkerBuilder::new(url)
                .worker_type(WorkerType::Regular)
                .build();
            for _ in 0..reqs {
                w.increment_load();
            }
            Arc::new(w)
        };

        // Scenario 1: Happy Path (Both have token_usage data)
        // Worker A: 10 requests, but only 10% token usage (Light) -> Should be CHOSEN
        // Worker B:  2 requests, but 90% token usage (Heavy) -> Should be AVOIDED
        // This proves we use token_usage ratio when available, ignoring request counts.
        let w_a = create_worker("http://a:8000", 10);
        let w_b = create_worker("http://b:8000", 2);
        let workers_1: Vec<Arc<dyn Worker>> = vec![w_a.clone(), w_b.clone()];

        let mut loads_1 = HashMap::new();
        loads_1.insert("http://a:8000".to_string(), make_load(0.1));
        loads_1.insert("http://b:8000".to_string(), make_load(0.9));
        policy.update_loads(&loads_1);

        let idx_1 = policy
            .select_worker(&workers_1, &SelectWorkerInfo::default())
            .unwrap();
        assert_eq!(
            idx_1, 0,
            "Happy Path Failed: Should select Worker A (lower token_usage) despite higher request count"
        );

        // Scenario 2: Partial Failure (Worker A has data, Worker B is missing)
        // Worker A: 10 requests, 10% token_usage (Cached)
        // Worker B:  2 requests, MISSING cache
        // Logic: Fallback to requests -> Compare 10 (A) vs 2 (B) -> Select B
        let w_c = create_worker("http://c:8000", 10);
        let w_d = create_worker("http://d:8000", 2);
        let workers_2: Vec<Arc<dyn Worker>> = vec![w_c.clone(), w_d.clone()];

        let mut loads_2 = HashMap::new();
        loads_2.insert("http://c:8000".to_string(), make_load(0.1));
        // http://d:8000 is MISSING
        policy.update_loads(&loads_2);

        let idx_2 = policy
            .select_worker(&workers_2, &SelectWorkerInfo::default())
            .unwrap();
        assert_eq!(idx_2, 1, "Partial Fail 1 Failed: Should fallback to requests and select Worker B (fewer requests)");

        // Scenario 3: Partial Failure (Worker A is missing, Worker B has data)
        // Worker A:  2 requests, MISSING cache
        // Worker B: 10 requests, 10% token_usage (Cached)
        // Logic: Fallback to requests -> Compare 2 (A) vs 10 (B) -> Select A
        let w_e = create_worker("http://e:8000", 2);
        let w_f = create_worker("http://f:8000", 10);
        let workers_3: Vec<Arc<dyn Worker>> = vec![w_e.clone(), w_f.clone()];

        let mut loads_3 = HashMap::new();
        // http://e:8000 is MISSING
        loads_3.insert("http://f:8000".to_string(), make_load(0.1));
        policy.update_loads(&loads_3);

        let idx_3 = policy
            .select_worker(&workers_3, &SelectWorkerInfo::default())
            .unwrap();
        assert_eq!(idx_3, 0, "Partial Fail 2 Failed: Should fallback to requests and select Worker A (fewer requests)");

        // Scenario 4: Total Failure (Both missing)
        // Worker A: 5 requests
        // Worker B: 3 requests
        // Logic: Requests vs Requests -> Select B
        let w_g = create_worker("http://g:8000", 5);
        let w_h = create_worker("http://h:8000", 3);
        let workers_4: Vec<Arc<dyn Worker>> = vec![w_g.clone(), w_h.clone()];

        let loads_4 = HashMap::new();
        policy.update_loads(&loads_4);

        let idx_4 = policy
            .select_worker(&workers_4, &SelectWorkerInfo::default())
            .unwrap();
        assert_eq!(
            idx_4, 1,
            "Total Fail Failed: Should select Worker B based on request count"
        );

        println!("All edge case tests passed successfully.");
    }
}
