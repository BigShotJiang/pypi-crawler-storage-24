from datetime import datetime
from typing import TypeVar, Optional

from langfuse.langchain import CallbackHandler
from openkosmos_core.common.model import BaseConfig
from pydantic import BaseModel


class AIBaseConfig(BaseConfig):
    pass


AI_CONFIG_T = TypeVar("AI_CONFIG_T", bound=AIBaseConfig)


class RunConfigConfigurable(BaseModel):
    thread_id: Optional[str] = datetime.now().strftime("%Y%m%d-%H%M%S")


class RunConfigMetadata(BaseModel):
    langfuse_session_id: Optional[str] = None
    langfuse_user_id: Optional[str] = "dev"
    langfuse_tags: Optional[list[str]] = None


class RunConfig:

    def __init__(self, name: str):
        self._name = name
        self._configurable: RunConfigConfigurable = RunConfigConfigurable()
        self._recursion_limit: int = 13
        self._metadata: Optional[RunConfigMetadata] = None

    def name(self, value: str):
        self._name = value
        return self

    def configurable(self, value: RunConfigConfigurable):
        self._configurable = value
        return self

    def metadata(self, value: RunConfigMetadata):
        self._metadata = value
        return self

    def recursion_limit(self, value: int):
        self._recursion_limit = value
        return self

    def to_config(self, callbacks: list = None):
        return {
            "run_name": self._name,
            "configurable": self._configurable.model_dump(exclude_none=True),
            "recursion_limit": self._recursion_limit,
            "metadata": None if self._metadata is None else self.metadata.model_dump(exclude_none=True),
            "callbacks": [CallbackHandler()] if callbacks is None else callbacks
        }


class SearchResult(BaseModel):
    id: str
    content: Optional[str] = None
    similarity_score: float = 0
    relevance_score: Optional[float] = 0
    metadata: Optional[dict] = None


class RelevanceDocument(BaseModel):
    text: str


class RelevanceResult(BaseModel):
    index: int
    relevance_score: float
    document: Optional[RelevanceDocument] = None


class RerankResult(BaseModel):
    results: list[RelevanceResult]
    metadata: Optional[dict] = None


class EmbeddingData(BaseModel):
    index: int
    object: str = "embedding"
    embedding: list[float]


class EmbeddingResult(BaseModel):
    object: str = "list"
    data: list[EmbeddingData]
    model: str
