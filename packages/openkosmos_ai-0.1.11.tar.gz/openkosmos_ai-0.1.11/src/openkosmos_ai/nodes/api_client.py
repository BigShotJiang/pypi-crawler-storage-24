from typing import TypeVar

from openkosmos_core.web.rest_client import RestClientConfig, RestClient

from openkosmos_ai.nodes.base_node import BaseStateNode


class ApiClientConfig(RestClientConfig):
    pass


API_CONFIG_T = TypeVar("API_CONFIG_T", bound=ApiClientConfig)


class ApiClientNode(BaseStateNode[API_CONFIG_T], RestClient):
    def __init__(self, config: API_CONFIG_T):
        BaseStateNode.__init__(self, config)
        RestClient.__init__(self, config)
