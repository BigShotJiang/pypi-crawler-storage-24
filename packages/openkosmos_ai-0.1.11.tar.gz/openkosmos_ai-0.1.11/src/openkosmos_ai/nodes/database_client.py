from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase

from openkosmos_ai.common.model import AIBaseConfig
from openkosmos_ai.nodes.base_node import BaseStateNode


class BaseEntity(DeclarativeBase):
    pass


class DatabaseClientConfig(AIBaseConfig):
    url: str
    create_table: bool = False


class DatabaseClientNode(BaseStateNode[DatabaseClientConfig]):
    def __init__(self, config: DatabaseClientConfig):
        super().__init__(config)
        self.database_engine = create_engine(config.url, pool_size=10)
        if config.create_table:
            BaseEntity.metadata.create_all(self.database_engine)

    def engine(self):
        return self.database_engine
