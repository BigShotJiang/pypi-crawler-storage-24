# elizaos-plugin-tts

elizaOS plugin.
