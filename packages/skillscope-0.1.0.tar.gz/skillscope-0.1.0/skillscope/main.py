#!/usr/bin/env python3
"""SkillScope CLI — Search, discover, and install AI Agent skills."""
import fire

from . import __version__
from .client import SkillScopeClient
from . import config as cfg
from .installer import install as _install


def _client() -> SkillScopeClient:
    return SkillScopeClient()


def recommend(task: str, region: str = "", platform: str = "", budget: str = "any",
              skill_level: str = "", explain: bool = True):
    """Get personalized skill recommendation for a task.

    Examples:
        skillscope recommend "translate PDF to Chinese" --region cn
        skillscope recommend "write unit tests" --budget free --platform macos
    """
    client = _client()
    result = client.recommend(
        task, explain=explain,
        region=region, platform=platform, budget=budget, skill_level=skill_level,
    )

    rec = result.get("recommendation")
    if not rec:
        print("No recommendation found for this task.")
        return

    # 显示推荐
    print(f"\n  Best: {rec['skill_id']}")
    print(f"  Quality: {rec['quality']}  Safety: {rec['safety']}  Score: {rec['score']}")
    if rec.get("reason"):
        print(f"  {rec['reason']}")
    print(f"  Install: {rec['install']}")
    print(f"         or: skillscope install {rec['skill_id']}")

    alts = result.get("alternatives", [])
    if alts:
        print(f"\n  Alternatives:")
        for alt in alts:
            print(f"    {alt['skill_id']}  q={alt['quality']} safety={alt['safety']} score={alt['score']}")
            if alt.get("reason"):
                print(f"      {alt['reason']}")

    meta = result.get("meta", {})
    if meta:
        print(f"\n  ({meta.get('candidates', 0)} candidates, {meta.get('latency_ms', 0)}ms)")


def search(query: str):
    """Search skills by keyword or description.

    Examples:
        skillscope search "web scraping"
        skillscope search "PDF translation"
    """
    client = _client()
    result = client.search(query)
    results = result.get("results", [])

    if not results:
        print(f"No results for '{query}'")
        return

    print(f"\n  Found {result.get('total', len(results))} results for '{query}':\n")
    for r in results[:15]:
        grade = r.get("security_grade", "?")
        quality = r.get("quality_score", 0)
        downloads = r.get("downloads", 0)
        desc = r.get("description_en") or r.get("description_zh") or r.get("description", "")
        if len(desc) > 80:
            desc = desc[:77] + "..."
        print(f"  {r['id']:<40} q={quality:<4} {grade}  dl={downloads}")
        if desc:
            print(f"    {desc}")


def detail(skill_id: str):
    """Show detailed info about a skill.

    Examples:
        skillscope detail steipete/weather
    """
    client = _client()
    result = client.detail(skill_id)
    skill = result.get("skill")
    if not skill:
        print(f"Skill '{skill_id}' not found")
        return

    analysis = skill.get("analysis_json") or {}
    security = analysis.get("security", {})

    print(f"\n  {skill['id']}  v{skill.get('version', '?')}")
    print(f"  Author: {skill.get('author', '?')}")
    print(f"  Source: {skill.get('source', 'clawhub')}")
    print(f"  Quality: {skill.get('quality_score', 0)}  Safety: {skill.get('security_grade', '?')}")

    desc = analysis.get("description_en") or analysis.get("description") or skill.get("description", "")
    if desc:
        print(f"\n  {desc}")

    cats = skill.get("categories") or []
    if cats:
        print(f"\n  Categories: {', '.join(cats)}")

    env = security.get("env_requirements", [])
    if env:
        print(f"  Env: {', '.join(str(e) for e in env)}")

    deps = analysis.get("external_deps", [])
    if deps:
        dep_names = [d.get("name", str(d)) if isinstance(d, dict) else str(d) for d in deps]
        print(f"  Deps: {', '.join(dep_names)}")

    stats = skill.get("clawhub_stats") or {}
    if stats:
        print(f"  Downloads: {stats.get('downloads', 0)}  Stars: {stats.get('stars', 0)}  Installs: {stats.get('installs_all_time', 0)}")

    print(f"\n  Install: clawhub install {skill.get('name', skill_id.split('/')[-1])}")
    print(f"         or: skillscope install {skill_id}")


def install(skill_id: str, target: str = "claude", project: bool = False,
            force: bool = False):
    """Install a skill locally.

    Downloads all files from the SkillScope mirror and writes them to your
    skills directory. Compatible with clawhub lockfile format.

    Args:
        skill_id: Skill ID (author/name format)
        target: Install target - 'claude' or 'codex'
        project: Install to project-level instead of user-level
        force: Overwrite existing skill without asking

    Examples:
        skillscope install steipete/weather
        skillscope install steipete/weather --target codex
        skillscope install steipete/weather --project
    """
    _install(skill_id, target=target, project=project, force=force)


def config(action: str = "show", key: str = "", value: str = ""):
    """Manage configuration.

    Examples:
        skillscope config                          # show all
        skillscope config set api_key sk-xxx       # set API key
        skillscope config set base_url https://skillscope.sh
    """
    if action == "show" or (action != "set" and not key):
        print("SkillScope config:")
        cfg.show()
    elif action == "set" and key and value:
        cfg.set(key, value)
    else:
        print("Usage: skillscope config set <key> <value>")


def version():
    """Show CLI version."""
    print(f"skillscope {__version__}")


def main():
    fire.Fire({
        "recommend": recommend,
        "search": search,
        "detail": detail,
        "install": install,
        "config": config,
        "version": version,
    })


if __name__ == "__main__":
    main()
