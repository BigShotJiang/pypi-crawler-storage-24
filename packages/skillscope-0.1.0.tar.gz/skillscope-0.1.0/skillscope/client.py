"""SkillScope API 客户端"""
import requests
from typing import Any, Dict, List, Optional

from . import config


class SkillScopeClient:
    def __init__(self, base_url: str = "", api_key: str = ""):
        self.base_url = (base_url or config.get("base_url")).rstrip("/")
        self.api_key = api_key or config.get("api_key")
        self.session = requests.Session()
        if self.api_key:
            self.session.headers["X-API-Key"] = self.api_key

    def _get(self, path: str, **params) -> Dict:
        resp = self.session.get(f"{self.base_url}{path}", params=params, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def _post(self, path: str, json: Dict) -> Dict:
        resp = self.session.post(f"{self.base_url}{path}", json=json, timeout=30)
        resp.raise_for_status()
        return resp.json()

    def recommend(self, task: str, explain: bool = True, **context) -> Dict:
        """POST /api/v1/recommend"""
        body = {"task": task, "explain": explain}
        if context:
            body["context"] = {k: v for k, v in context.items() if v is not None}
        return self._post("/api/v1/recommend", body)

    def search(self, query: str) -> Dict:
        """GET /api/v1/search"""
        return self._get("/api/v1/search", q=query)

    def detail(self, skill_id: str) -> Dict:
        """GET /api/v1/skills/{skill_id}"""
        return self._get(f"/api/v1/skills/{skill_id}")

    def files(self, skill_id: str) -> Dict:
        """GET /api/v1/install/{skill_id}/files"""
        return self._get(f"/api/v1/install/{skill_id}/files")

    def install_guide(self, skill_id: str) -> Dict:
        """GET /api/v1/install/{skill_id}/guide"""
        return self._get(f"/api/v1/install/{skill_id}/guide")
