"""配置管理 — ~/.skillscope/config.yml"""
import os
from pathlib import Path
from typing import Optional

import yaml

CONFIG_DIR = Path.home() / ".skillscope"
CONFIG_FILE = CONFIG_DIR / "config.yml"

_DEFAULT = {
    "base_url": "https://skillscope.cn",
    "api_key": "",
}


def _load() -> dict:
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                return {**_DEFAULT, **(yaml.safe_load(f) or {})}
        except Exception:
            pass
    return dict(_DEFAULT)


def _save(cfg: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w") as f:
        yaml.dump(cfg, f, default_flow_style=False)


def get(key: str) -> str:
    """读取配置项"""
    # 环境变量优先
    env_key = f"SKILLSCOPE_{key.upper()}"
    env_val = os.environ.get(env_key)
    if env_val:
        return env_val
    return _load().get(key, _DEFAULT.get(key, ""))


def set(key: str, value: str):
    """设置配置项"""
    cfg = _load()
    cfg[key] = value
    _save(cfg)
    print(f"Set {key} = {value}")


def show():
    """显示当前配置"""
    cfg = _load()
    for k, v in cfg.items():
        # 隐藏 API Key 中间部分
        display = v
        if k == "api_key" and v and len(v) > 8:
            display = v[:4] + "..." + v[-4:]
        print(f"  {k}: {display or '(not set)'}")
