"""Skill 安装器 — 下载文件并写入目标目录"""
import json
import time
from pathlib import Path
from typing import Optional

from .client import SkillScopeClient

# 目标目录映射
TARGET_DIRS = {
    "claude": Path.home() / ".claude",
    "codex": Path.home() / ".codex",
}


def _get_skills_dir(target: str, project: bool) -> Path:
    """获取 skills 安装目录"""
    if project:
        base = Path.cwd()
        # 项目级：查找 .claude/ 或 .codex/ 目录（向上查找）
        if target == "codex":
            cfg_dir = base / ".codex"
        else:
            cfg_dir = base / ".claude"
        return cfg_dir / "skills"
    return TARGET_DIRS[target] / "skills"


def install(skill_id: str, target: str = "claude", project: bool = False,
            force: bool = False, client: Optional[SkillScopeClient] = None):
    """安装 skill 到本地

    Args:
        skill_id: skill ID（author/name 格式）
        target: 安装目标 'claude' 或 'codex'
        project: 安装到项目级（当前目录）而非用户级
        force: 覆盖已存在的 skill
        client: API 客户端（可选）
    """
    if target not in TARGET_DIRS:
        print(f"Error: unknown target '{target}', use 'claude' or 'codex'")
        return False

    client = client or SkillScopeClient()

    # 1. 下载文件
    print(f"Fetching {skill_id}...")
    try:
        data = client.files(skill_id)
    except Exception as e:
        err = str(e)
        if "404" in err:
            print(f"Error: skill '{skill_id}' not found or not available for install")
        else:
            print(f"Error: {e}")
        return False

    files = data.get("files", [])
    slug = data.get("slug", skill_id.split("/")[-1])
    if not files:
        print("Error: no files returned")
        return False

    # 2. 确定目标目录
    skills_dir = _get_skills_dir(target, project)
    skill_dir = skills_dir / slug

    if skill_dir.exists() and not force:
        print(f"Skill '{slug}' already exists at {skill_dir}")
        resp = input("Overwrite? [y/N] ").strip().lower()
        if resp != "y":
            print("Cancelled.")
            return False

    # 3. 写入文件
    skill_dir.mkdir(parents=True, exist_ok=True)
    written = 0
    for f in files:
        fpath = skill_dir / f["path"]
        fpath.parent.mkdir(parents=True, exist_ok=True)
        fpath.write_text(f["content"], encoding="utf-8")
        written += 1

    # 4. 写 .clawhub/origin.json（兼容 clawhub 格式）
    clawhub_dir = skill_dir / ".clawhub"
    clawhub_dir.mkdir(exist_ok=True)

    # 从 _meta.json 提取版本
    version = "unknown"
    for f in files:
        if f["path"] == "_meta.json":
            try:
                meta = json.loads(f["content"])
                version = meta.get("latest", {}).get("version", version)
            except (json.JSONDecodeError, KeyError):
                pass
            break

    origin = {
        "version": 1,
        "registry": "https://skillscope.cn",
        "slug": slug,
        "installedVersion": version,
        "installedAt": int(time.time() * 1000),
    }
    (clawhub_dir / "origin.json").write_text(
        json.dumps(origin, indent=2), encoding="utf-8"
    )

    # 5. 更新全局 lock.json
    lock_dir = skills_dir.parent / ".clawhub"
    lock_dir.mkdir(exist_ok=True)
    lock_file = lock_dir / "lock.json"
    lock = {"version": 1, "skills": {}}
    if lock_file.exists():
        try:
            lock = json.loads(lock_file.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    lock.setdefault("skills", {})[slug] = {
        "version": version,
        "installedAt": int(time.time() * 1000),
    }
    lock_file.write_text(json.dumps(lock, indent=2), encoding="utf-8")

    # 6. 提取描述
    desc = ""
    for f in files:
        if f["path"] == "SKILL.md":
            for line in f["content"].split("\n"):
                if line.startswith("description:"):
                    desc = line.split(":", 1)[1].strip()
                    break
            break

    scope = "project" if project else "user"
    print(f"Installed {skill_id} ({version}) -> {skill_dir}")
    print(f"  Target: {target} ({scope})")
    print(f"  Files: {written}")
    if desc:
        print(f"  {desc}")
    return True
