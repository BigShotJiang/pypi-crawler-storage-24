"""SkillScope CLI — Search, discover, and install AI Agent skills."""
__version__ = "0.1.0"
