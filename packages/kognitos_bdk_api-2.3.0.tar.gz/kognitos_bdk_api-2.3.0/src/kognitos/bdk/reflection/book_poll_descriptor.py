from dataclasses import dataclass
from typing import Dict

from .concept_descriptor import ConceptDescriptor


@dataclass
class BookPollDescriptor:
    """Descriptor for long-running polling/streaming procedures.

    A poll consists of an async iterator function that yields items continuously (decorated with @poll).
    """

    id: str
    """Identifier - the poll function name"""

    name: str
    """Display name for the polling operation (e.g., "Email Polling")"""

    description: str
    """Combined short and long description from the poll function docstring"""

    configuration: Dict[str, ConceptDescriptor]
    """Configuration parameters from the poll function signature"""

    event: Dict[str, ConceptDescriptor]
    """Event fields from the poll's yielded type (if @poll_event dataclass)"""
