#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  081 — L-frame cantilever, horizontal tip load
//
//  Geometry:  N1(0,0,0) ── beam1 ── N2(5,0,0)
//                                      │
//                                    beam2
//                                      │
//                                   N3(5,5,0) ← F = −1000 N in X
//
//  Supports:  N1 fully fixed (only)
//  Checks:    Force & moment equilibrium, zero Z displacement on all nodes
// ─────────────────────────────────────────────────────────────────────────────

fn test_081_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("081_l_frame", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let length_si = 5.0_f64;
    let force_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let fl = f * l;
    let len = length_si / l;
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // Supports — only N1 is fully fixed
    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, len, 0.0, 0.0, None);
    let n3 = make_node(3, len, len, 0.0, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 3, force_u, (-1.0, 0.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case(lc)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx1 = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);

    // Global force equilibrium — only N1 carries all reactions
    assert_close_ctx(&ctx, force_u, rx1.fx, tol_f, "Rx1.fx");
    assert_close_ctx(&ctx, 0.0, rx1.fy, tol_f, "Rx1.fy");
    assert_close_ctx(&ctx, 0.0, rx1.fz, tol_f, "Rx1.fz");

    // Mz at origin: Mz_applied = x₃·0 − y₃·(−F) = 5·1000 = 5000 → Mz_react = −5000
    assert_close_ctx(&ctx, -5000.0 / fl, rx1.mz, tol_m, "Rx1.mz");

    // All nodes must have zero Z displacement (planar problem in XY)
    for nid in [1u32, 2, 3] {
        let dz = r.displacement_nodes[&nid].dz;
        assert_close_ctx(&ctx, 0.0, dz, tol_d, &format!("N{nid}.dz == 0"));
    }
}

#[test]
fn test_081_l_frame_fixed_cantilever_no_z_displacement() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_081_case(s, lu, fu, pu);
        }
    }
}

#[test]
fn test_081_second_order_equilibrium() {
    let strategy = RigidStrategy::RigidMember;
    let lu = LengthUnit::M;
    let fu = ForceUnit::N;
    let pu = PressureUnit::Pa;
    let ctx = make_ctx("081_second_order", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);
    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, 1.0, 0.0, 0.0, None);
    let n3 = make_node(3, 1.0, 1.0, 0.0, None);
    add_member_set(&mut model, 1, vec![
        make_beam_member(1, &n1, &n2, sec),
        make_beam_member(2, &n2, &n3, sec),
    ]);

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 3, 1000.0, (-1.0, 0.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case_second_order(lc, 30)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx1 = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    println!("=== 081 Second-Order (1m arms) Reactions at N1 ===");
    println!("  fx = {:.6}", rx1.fx);
    println!("  fy = {:.6}", rx1.fy);
    println!("  fz = {:.6}", rx1.fz);
    println!("  mx = {:.6}", rx1.mx);
    println!("  my = {:.6}", rx1.my);
    println!("  mz = {:.6}", rx1.mz);

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, 1.0);

    // Global force equilibrium must hold even in second-order analysis:
    // pure X load → Fx = 1000, Fy = 0, Mz = -1000
    assert_close_ctx(&ctx, 1000.0, rx1.fx, tol_f, "Rx1.fx");
    assert_close_ctx(&ctx, 0.0, rx1.fy, tol_f, "Rx1.fy");
    assert_close_ctx(&ctx, 0.0, rx1.fz, tol_f, "Rx1.fz");
}
