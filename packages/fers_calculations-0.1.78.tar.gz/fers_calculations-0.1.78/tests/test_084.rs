#[path = "test_support/mod.rs"]
mod test_support;

use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use test_support::helpers::*;
use test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  084 — Triple cantilever 3D (three orthogonal beams)
//
//  N1(0,0,0) ── beam1(X) ── N2(1,0,0) ── beam2(Y) ── N3(1,1,0) ── beam3(Z) ── N4(1,1,1)
//                                                                                  ↑
//                                                                        F = −1000 N in Y
//
//  Support:   N1 fully fixed
//  Checks:    Force & moment equilibrium at fixed support
// ─────────────────────────────────────────────────────────────────────────────

fn test_084_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("084_3d_triple", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let arm_si = 1.0_f64;
    let force_si = 1000.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let fl = f * l;
    let arm = arm_si / l;
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, arm, 0.0, 0.0, None);
    let n3 = make_node(3, arm, arm, 0.0, None);
    let n4 = make_node(4, arm, arm, arm, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_beam_member(3, &n3, &n4, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, force_u, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case(lc)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Force equilibrium
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx(&ctx, force_u, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f, "Rx.fz");

    // Moment equilibrium about origin
    // r × F = (1,1,1) × (0,−1000,0) = (1000, 0, −1000)
    // → reaction moments = (−1000, 0, 1000) N·m
    assert_close_ctx(&ctx, -1000.0 / fl, rx.mx, tol_m, "Rx.mx");
    assert_close_ctx(&ctx, 0.0, rx.my, tol_m, "Rx.my");
    assert_close_ctx(&ctx, 1000.0 / fl, rx.mz, tol_m, "Rx.mz");
}

#[test]
fn test_084_triple_cantilever_3d_equilibrium() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_084_case(s, lu, fu, pu);
        }
    }
}
