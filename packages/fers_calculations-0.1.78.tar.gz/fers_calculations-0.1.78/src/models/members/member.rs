use crate::functions::geometry::{DOFS_PER_NODE, ELEMENT_DOFS};
use crate::models::members::enums::MemberType;
use crate::models::nodes::node::Node;
use serde::{Deserialize, Serialize};
use utoipa::ToSchema;

#[derive(Serialize, Deserialize, ToSchema, Debug, Clone)]
pub struct Member {
    pub id: u32,
    pub start_node: Node,
    pub end_node: Node,
    pub section: Option<u32>,
    pub rotation_angle: f64,
    pub start_hinge: Option<u32>,
    pub end_hinge: Option<u32>,
    pub classification: String,
    pub weight: f64,
    pub chi: Option<f64>,
    pub reference_member: Option<u32>,
    pub reference_node: Option<u32>,
    pub member_type: MemberType,
}

use crate::models::members::{material::Material, section::Section};
use nalgebra::{DMatrix, Vector3};
use std::collections::HashMap;

impl Member {
    pub fn calculate_length(&self) -> f64 {
        self.start_node.distance_to(&self.end_node)
    }

    pub fn calculate_stiffness_matrix_2d(
        &self,
        material_map: &HashMap<u32, &Material>,
        section_map: &HashMap<u32, &Section>,
    ) -> Option<DMatrix<f64>> {
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });

        let section = section_map.get(&section_id)?;
        let material = material_map.get(&section.material)?;

        let e = material.e_mod;
        let a = section.area;
        let i = section.i_y;
        let l = self.calculate_length();

        let axial = e * a / l;
        let bending = e * i / (l * l * l);

        Some(DMatrix::from_row_slice(
            6,
            6,
            &[
                axial,
                0.0,
                0.0,
                -axial,
                0.0,
                0.0,
                0.0,
                12.0 * bending,
                6.0 * l * bending,
                0.0,
                -12.0 * bending,
                6.0 * l * bending,
                0.0,
                6.0 * l * bending,
                4.0 * l * l * bending,
                0.0,
                -6.0 * l * bending,
                2.0 * l * l * bending,
                -axial,
                0.0,
                0.0,
                axial,
                0.0,
                0.0,
                0.0,
                -12.0 * bending,
                -6.0 * l * bending,
                0.0,
                12.0 * bending,
                -6.0 * l * bending,
                0.0,
                6.0 * l * bending,
                2.0 * l * l * bending,
                0.0,
                -6.0 * l * bending,
                4.0 * l * l * bending,
            ],
        ))
    }

    pub fn calculate_stiffness_matrix_3d(
        &self,
        material_map: &HashMap<u32, &Material>,
        section_map: &HashMap<u32, &Section>,
    ) -> Option<DMatrix<f64>> {
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });

        let section = section_map.get(&section_id)?;
        let material = material_map.get(&section.material)?;

        let e = material.e_mod;
        let g = material.g_mod;
        let a = section.area;
        let i_y = section.i_y;
        let i_z = section.i_z;
        let j = section.j;
        let i_w = section.i_w.unwrap_or(0.0);
        let l = self.calculate_length();
        let l2 = l * l;
        let l3 = l2 * l;

        let mut k = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);

        // Helper to set symmetric pair
        let set_sym = |m: &mut DMatrix<f64>, i: usize, j: usize, v: f64| {
            m[(i, j)] = v;
            m[(j, i)] = v;
        };

        // --- 1. Axial block (DOFs 0, 7) ---
        let axial = e * a / l;
        k[(0, 0)] = axial;
        k[(7, 7)] = axial;
        set_sym(&mut k, 0, 7, -axial);

        // --- 2. Y-bending block with Timoshenko shear (DOFs 1, 5, 8, 12) ---
        let phi_z = if let Some(a_sz) = section.a_sz {
            12.0 * e * i_z / (g * a_sz * l2)
        } else {
            0.0
        };
        let denom_z = 1.0 + phi_z;
        k[(1, 1)] = 12.0 * e * i_z / (l3 * denom_z);
        set_sym(&mut k, 1, 5, 6.0 * e * i_z / (l2 * denom_z));
        set_sym(&mut k, 1, 8, -12.0 * e * i_z / (l3 * denom_z));
        set_sym(&mut k, 1, 12, 6.0 * e * i_z / (l2 * denom_z));
        k[(5, 5)] = (4.0 + phi_z) * e * i_z / (l * denom_z);
        set_sym(&mut k, 5, 8, -6.0 * e * i_z / (l2 * denom_z));
        set_sym(&mut k, 5, 12, (2.0 - phi_z) * e * i_z / (l * denom_z));
        k[(8, 8)] = 12.0 * e * i_z / (l3 * denom_z);
        set_sym(&mut k, 8, 12, -6.0 * e * i_z / (l2 * denom_z));
        k[(12, 12)] = (4.0 + phi_z) * e * i_z / (l * denom_z);

        // --- 3. Z-bending block with Timoshenko shear (DOFs 2, 4, 9, 11) ---
        let phi_y = if let Some(a_sy) = section.a_sy {
            12.0 * e * i_y / (g * a_sy * l2)
        } else {
            0.0
        };
        let denom_y = 1.0 + phi_y;
        k[(2, 2)] = 12.0 * e * i_y / (l3 * denom_y);
        set_sym(&mut k, 2, 4, -6.0 * e * i_y / (l2 * denom_y));
        set_sym(&mut k, 2, 9, -12.0 * e * i_y / (l3 * denom_y));
        set_sym(&mut k, 2, 11, -6.0 * e * i_y / (l2 * denom_y));
        k[(4, 4)] = (4.0 + phi_y) * e * i_y / (l * denom_y);
        set_sym(&mut k, 4, 9, 6.0 * e * i_y / (l2 * denom_y));
        set_sym(&mut k, 4, 11, (2.0 - phi_y) * e * i_y / (l * denom_y));
        k[(9, 9)] = 12.0 * e * i_y / (l3 * denom_y);
        set_sym(&mut k, 9, 11, 6.0 * e * i_y / (l2 * denom_y));
        k[(11, 11)] = (4.0 + phi_y) * e * i_y / (l * denom_y);

        // --- 4. Torsion-Warping block (DOFs 3, 6, 10, 13) ---
        k[(3, 3)] = g * j / l + 12.0 * e * i_w / l3;
        set_sym(&mut k, 3, 6, 6.0 * e * i_w / l2);
        set_sym(&mut k, 3, 10, -(g * j / l + 12.0 * e * i_w / l3));
        set_sym(&mut k, 3, 13, 6.0 * e * i_w / l2);
        k[(6, 6)] = 4.0 * e * i_w / l;
        set_sym(&mut k, 6, 10, -6.0 * e * i_w / l2);
        set_sym(&mut k, 6, 13, 2.0 * e * i_w / l);
        k[(10, 10)] = g * j / l + 12.0 * e * i_w / l3;
        set_sym(&mut k, 10, 13, -6.0 * e * i_w / l2);
        k[(13, 13)] = 4.0 * e * i_w / l;

        // Stabilize warping DOFs when no warping stiffness exists to prevent singular matrix
        if i_w.abs() < 1e-30 {
            let stab = 1e-10 * e * a / l;
            k[(6, 6)] += stab;
            k[(13, 13)] += stab;
        }

        Some(k)
    }

    pub fn calculate_truss_stiffness_matrix_3d(
        &self,
        material_map: &std::collections::HashMap<u32, &Material>,
        section_map: &std::collections::HashMap<u32, &Section>,
    ) -> Option<nalgebra::DMatrix<f64>> {
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });

        let section: &&Section = section_map.get(&section_id)?;
        let material: &&Material = material_map.get(&section.material)?;
        let e_modulus: f64 = material.e_mod;
        let area: f64 = section.area;
        let length: f64 = self.calculate_length();

        if length <= 0.0 {
            return None;
        }

        let axial: f64 = e_modulus * area / length;

        let mut k_local = nalgebra::DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);
        // Local translational x of start and end nodes (indices 0 and DOFS_PER_NODE) couple axially
        k_local[(0, 0)] = axial;
        k_local[(0, DOFS_PER_NODE)] = -axial;
        k_local[(DOFS_PER_NODE, 0)] = -axial;
        k_local[(DOFS_PER_NODE, DOFS_PER_NODE)] = axial;

        // Stabilize all non-axial DOFs to prevent singular global matrix
        let stab = 1e-10 * axial;
        for i in 1..DOFS_PER_NODE {
            k_local[(i, i)] += stab;
            k_local[(i + DOFS_PER_NODE, i + DOFS_PER_NODE)] += stab;
        }

        let t = self.calculate_transformation_matrix_3d();
        let k_global = t.transpose() * k_local * t;
        Some(k_global)
    }

    pub fn calculate_transformation_matrix_2d(&self) -> DMatrix<f64> {
        let dx = self.end_node.X - self.start_node.X;
        let dy = self.end_node.Y - self.start_node.Y;
        let l = (dx.powi(2) + dy.powi(2)).sqrt();

        let c = dx / l;
        let s = dy / l;

        DMatrix::from_row_slice(
            6,
            6,
            &[
                c, s, 0.0, 0.0, 0.0, 0.0, -s, c, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0,
                0.0, 0.0, 0.0, c, s, 0.0, 0.0, 0.0, 0.0, -s, c, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0,
            ],
        )
    }

    pub fn calculate_transformation_matrix_3d(&self) -> DMatrix<f64> {
        // Local x: along the member
        let dx = self.end_node.X - self.start_node.X;
        let dy = self.end_node.Y - self.start_node.Y;
        let dz = self.end_node.Z - self.start_node.Z;
        let length = (dx * dx + dy * dy + dz * dz).sqrt();
        if length < 1e-12 {
            panic!("Start and end nodes are the same or too close to define a direction.");
        }
        let local_x = Vector3::new(dx / length, dy / length, dz / length);

        let mut reference_vector = Vector3::new(0.0, 1.0, 0.0);
        let dot = local_x.dot(&reference_vector);
        if dot.abs() > 1.0 - 1e-6 {
            reference_vector = Vector3::new(0.0, 0.0, 1.0);
        }

        // Build right-handed frame
        let mut local_z = local_x.cross(&reference_vector);
        let norm_z = local_z.norm();
        if norm_z < 1e-12 {
            // Extremely unlikely with the fallback above
            reference_vector = Vector3::new(1.0, 0.0, 0.0);
            local_z = local_x.cross(&reference_vector);
            if local_z.norm() < 1e-12 {
                panic!("Cannot define a valid local_z axis.");
            }
        }
        let local_z = local_z.normalize();
        let local_y = local_z.cross(&local_x).normalize();

        // Apply roll about local_x by rotation_angle (radians after normalize_units conversion)
        let mut y_axis = local_y;
        let mut z_axis = local_z;
        let phi = self.rotation_angle;
        if phi.abs() > 0.0 {
            let c = phi.cos();
            let s = phi.sin();
            let y_rot = y_axis * c + z_axis * s;
            let z_rot = -y_axis * s + z_axis * c;
            y_axis = y_rot;
            z_axis = z_rot;
        }

        // Rotation R with rows [x; y; z] (global → local)
        let r = DMatrix::from_row_slice(
            3,
            3,
            &[
                local_x.x, local_x.y, local_x.z, y_axis.x, y_axis.y, y_axis.z, z_axis.x, z_axis.y,
                z_axis.z,
            ],
        );

        // Block-diagonal T = diag(R, R, 1, R, R, 1) for 14×14
        // Each node has a 7×7 block: [R₃ₓ₃  0  0; 0  R₃ₓ₃  0; 0  0  1]
        // Warping DOF (φ) is a scalar invariant under rotation.
        let mut transformation = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);
        for node in 0..2 {
            let base = node * DOFS_PER_NODE;
            // Translations (3×3 block)
            for i in 0..3 {
                for j in 0..3 {
                    transformation[(base + i, base + j)] = r[(i, j)];
                }
            }
            // Rotations (3×3 block)
            for i in 0..3 {
                for j in 0..3 {
                    transformation[(base + 3 + i, base + 3 + j)] = r[(i, j)];
                }
            }
            // Warping DOF (scalar, invariant)
            transformation[(base + 6, base + 6)] = 1.0;
        }
        transformation
    }

    pub fn calculate_axial_force_3d(
        &self,
        global_displacement: &DMatrix<f64>,
        material_map: &HashMap<u32, &Material>,
        section_map: &HashMap<u32, &Section>,
    ) -> f64 {
        // 1) Look up E and A
        let section_id = self.section.unwrap_or_else(|| {
            panic!(
                "Member {} ({:?}) missing section id required to compute axial force.",
                self.id, self.member_type
            )
        });
        let section: &&Section = section_map.get(&section_id).unwrap_or_else(|| {
            panic!(
                "Missing section data: member_id={}, section_id={}",
                self.id, section_id
            )
        });

        let material = material_map.get(&section.material).unwrap_or_else(|| {
            panic!(
                "Missing material for section: member_id={}, section_id={}, material_id={}",
                self.id, section_id, section.material
            )
        });
        let e_mod = material.e_mod;
        let area = section.area;

        // 2) Length and transformation
        let length = self.calculate_length();
        let t = self.calculate_transformation_matrix_3d(); // 14×14

        // 3) Extract the ELEMENT_DOFS global DOFs for this member
        let start_index = (self.start_node.id as usize - 1) * DOFS_PER_NODE;
        let end_index = (self.end_node.id as usize - 1) * DOFS_PER_NODE;
        let mut u_elem = DMatrix::<f64>::zeros(ELEMENT_DOFS, 1);
        // start node displacements
        for i in 0..DOFS_PER_NODE {
            u_elem[(i, 0)] = global_displacement[(start_index + i, 0)];
        }
        // end node displacements
        for i in 0..DOFS_PER_NODE {
            u_elem[(i + DOFS_PER_NODE, 0)] = global_displacement[(end_index + i, 0)];
        }

        // 4) Transform to local coords: u_local = T * u_elem
        let u_local = &t * &u_elem;

        // 5) Axial extension = u_local[x_end] - u_local[x_start]
        let extension = u_local[(DOFS_PER_NODE, 0)] - u_local[(0, 0)];

        // 6) Axial force = (E·A/L) · extension
        e_mod * area / length * extension
    }

    /// Build the local geometric stiffness matrix for this member, given its axial force.
    pub fn calculate_geometric_stiffness_matrix_3d(
        &self,
        axial_force: f64,
        wagner_coeff: f64,
    ) -> DMatrix<f64> {
        let l = self.calculate_length();
        let p = axial_force;
        let p_over_l = p / l;
        let p_times_l = p * l;

        let mut k_geo = DMatrix::<f64>::zeros(ELEMENT_DOFS, ELEMENT_DOFS);

        // --- Axial terms (DOFs 0, 7) ---
        k_geo[(0, 0)] = p_over_l;
        k_geo[(0, 7)] = -p_over_l;
        k_geo[(7, 0)] = -p_over_l;
        k_geo[(7, 7)] = p_over_l;

        // --- Bending about local z (deflection in y) ---
        // DOFs: 1, 5, 8, 12
        k_geo[(1, 1)] = 6.0 / 5.0 * p_over_l;
        k_geo[(1, 5)] = 1.0 / 10.0 * p_times_l;
        k_geo[(1, 8)] = -6.0 / 5.0 * p_over_l;
        k_geo[(1, 12)] = 1.0 / 10.0 * p_times_l;

        k_geo[(5, 1)] = 1.0 / 10.0 * p_times_l;
        k_geo[(5, 5)] = 4.0 / 15.0 * p_times_l;
        k_geo[(5, 8)] = -1.0 / 10.0 * p_times_l;
        k_geo[(5, 12)] = 2.0 / 15.0 * p_times_l;

        k_geo[(8, 1)] = -6.0 / 5.0 * p_over_l;
        k_geo[(8, 5)] = -1.0 / 10.0 * p_times_l;
        k_geo[(8, 8)] = 6.0 / 5.0 * p_over_l;
        k_geo[(8, 12)] = -1.0 / 10.0 * p_times_l;

        k_geo[(12, 1)] = 1.0 / 10.0 * p_times_l;
        k_geo[(12, 5)] = 2.0 / 15.0 * p_times_l;
        k_geo[(12, 8)] = -1.0 / 10.0 * p_times_l;
        k_geo[(12, 12)] = 4.0 / 15.0 * p_times_l;

        // --- Bending about local y (deflection in z) ---
        // DOFs: 2, 4, 9, 11
        k_geo[(2, 2)] = 6.0 / 5.0 * p_over_l;
        k_geo[(2, 4)] = 1.0 / 10.0 * p_times_l;
        k_geo[(2, 9)] = -6.0 / 5.0 * p_over_l;
        k_geo[(2, 11)] = 1.0 / 10.0 * p_times_l;

        k_geo[(4, 2)] = 1.0 / 10.0 * p_times_l;
        k_geo[(4, 4)] = 4.0 / 15.0 * p_times_l;
        k_geo[(4, 9)] = -1.0 / 10.0 * p_times_l;
        k_geo[(4, 11)] = 2.0 / 15.0 * p_times_l;

        k_geo[(9, 2)] = -6.0 / 5.0 * p_over_l;
        k_geo[(9, 4)] = -1.0 / 10.0 * p_times_l;
        k_geo[(9, 9)] = 6.0 / 5.0 * p_over_l;
        k_geo[(9, 11)] = -1.0 / 10.0 * p_times_l;

        k_geo[(11, 2)] = 1.0 / 10.0 * p_times_l;
        k_geo[(11, 4)] = 2.0 / 15.0 * p_times_l;
        k_geo[(11, 9)] = -1.0 / 10.0 * p_times_l;
        k_geo[(11, 11)] = 4.0 / 15.0 * p_times_l;

        // --- Wagner effect on torsion (DOFs 3, 10) ---
        let ip_s2 = wagner_coeff;
        k_geo[(3, 3)] += p_over_l * ip_s2;
        k_geo[(3, 10)] += -p_over_l * ip_s2;
        k_geo[(10, 3)] += -p_over_l * ip_s2;
        k_geo[(10, 10)] += p_over_l * ip_s2;

        k_geo
    }
}
