=======
Turtles
=======

.. |RELEASE| replace:: 0.7.0
.. |RELEASE_DATE| replace:: 2026-03-18
.. |TURTLES| replace:: **Turtles**

.. image:: https://assets.lockss.org/images/logos/turtles/turtles_128x128.png
   :alt: Turtles logo
   :align: right

|TURTLES| is a command line tool and Python library to manage LOCKSS plugin sets and LOCKSS plugin registries.

:Latest release: |RELEASE| (|RELEASE_DATE|)
:Documentation: https://docs.lockss.org/en/latest/software/turtles
:Release notes: `CHANGELOG.rst <https://github.com/lockss/lockss-turtles/blob/main/CHANGELOG.rst>`_
:License: `LICENSE <https://github.com/lockss/lockss-turtles/blob/main/LICENSE>`_
:Repository: https://github.com/lockss/lockss-turtles
:Issues: https://github.com/lockss/lockss-turtles/issues

----

Quick Start::

   # Requires Python 3.10
   python --version

   # Install with pipx
   pipx install lockss-turtles

   # Verify installation and discover all the commands
   turtles --help

