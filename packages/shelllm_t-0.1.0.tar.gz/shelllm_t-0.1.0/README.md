# shelllm

Shell integration for LLM interactions.

## Installation

```bash
pip install shelllm
```

## Usage

```bash
shelllm "Explain this error: $(cat /var/log/error.log)"
```

## License

MIT
