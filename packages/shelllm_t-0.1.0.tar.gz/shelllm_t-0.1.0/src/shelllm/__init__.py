"""Shell integration for LLM interactions."""

__version__ = "0.1.0"

import subprocess
import sys

def cli():
    """CLI entry point for shelllm."""
    if len(sys.argv) < 2:
        print("Usage: shelllm <prompt>")
        sys.exit(1)
    
    prompt = " ".join(sys.argv[1:])
    result = subprocess.run(["llm", prompt], capture_output=False)
    sys.exit(result.returncode)

if __name__ == "__main__":
    cli()
