"""
GeoXERL command-line interface.

Usage
-----
    geoxerl --help
    geoxerl preprocess --config geoxerl/data_preprocessing/config.py
    geoxerl train      --config geoxerl/base_models/config.json
    geoxerl ensemble   --config geoxerl/ensemble/config.py
    geoxerl optimize   --config geoxerl/threshold_optimization/config.py
    geoxerl run-all    --config <config_dir>
"""

import argparse
import sys


def _get_version() -> str:
    from geoxerl.__version__ import __version__
    return __version__


def cmd_preprocess(args: argparse.Namespace) -> None:
    """Run the full data-preprocessing pipeline."""
    from geoxerl.data_preprocessing.main import main
    main()


def cmd_train(args: argparse.Namespace) -> None:
    """Train base models."""
    from geoxerl.base_models.train import main
    main()


def cmd_ensemble(args: argparse.Namespace) -> None:
    """Run ensemble methods."""
    # Entry points differ per method; default to stacking
    method = getattr(args, "method", "stacking")
    if method == "bagging":
        from geoxerl.ensemble.bagging import main
    elif method == "boosting":
        from geoxerl.ensemble.boosting import main
    elif method == "gwrf":
        from geoxerl.ensemble.ppo_main import main
    else:
        from geoxerl.ensemble.stacking import main
    main()


def cmd_optimize(args: argparse.Namespace) -> None:
    """Run threshold optimization."""
    from geoxerl.threshold_optimization.q_main import main
    main()


def cmd_run_all(args: argparse.Namespace) -> None:
    """Run the complete pipeline end-to-end."""
    print("[GeoXERL] Step 1/4 — Data preprocessing …")
    cmd_preprocess(args)
    print("[GeoXERL] Step 2/4 — Base model training …")
    cmd_train(args)
    print("[GeoXERL] Step 3/4 — Ensemble …")
    cmd_ensemble(args)
    print("[GeoXERL] Step 4/4 — Threshold optimization …")
    cmd_optimize(args)
    print("[GeoXERL] Pipeline complete.")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="geoxerl",
        description="GeoXERL — Geospatial Ensemble + RL Threshold Optimization",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version", "-V",
        action="version",
        version=f"geoxerl {_get_version()}",
    )

    subparsers = parser.add_subparsers(dest="command", metavar="<command>")
    subparsers.required = True

    # ── preprocess ─────────────────────────────────────────────────────────────
    p_pre = subparsers.add_parser("preprocess", help="Run data-preprocessing pipeline")
    p_pre.add_argument("--config", default=None, help="Path to config file (optional)")
    p_pre.set_defaults(func=cmd_preprocess)

    # ── train ──────────────────────────────────────────────────────────────────
    p_train = subparsers.add_parser("train", help="Train base models")
    p_train.add_argument("--config", default=None, help="Path to config file (optional)")
    p_train.set_defaults(func=cmd_train)

    # ── ensemble ───────────────────────────────────────────────────────────────
    p_ens = subparsers.add_parser("ensemble", help="Run ensemble methods")
    p_ens.add_argument(
        "--method",
        choices=["bagging", "boosting", "stacking", "gwrf"],
        default="stacking",
        help="Ensemble method to use (default: stacking)",
    )
    p_ens.set_defaults(func=cmd_ensemble)

    # ── optimize ───────────────────────────────────────────────────────────────
    p_opt = subparsers.add_parser("optimize", help="Run threshold optimization")
    p_opt.add_argument("--config", default=None, help="Path to config file (optional)")
    p_opt.set_defaults(func=cmd_optimize)

    # ── run-all ────────────────────────────────────────────────────────────────
    p_all = subparsers.add_parser("run-all", help="Run the full pipeline end-to-end")
    p_all.set_defaults(func=cmd_run_all)

    args = parser.parse_args()
    try:
        args.func(args)
    except KeyboardInterrupt:
        print("\n[GeoXERL] Interrupted by user.", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:  # noqa: BLE001
        print(f"[GeoXERL] Error: {exc}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
