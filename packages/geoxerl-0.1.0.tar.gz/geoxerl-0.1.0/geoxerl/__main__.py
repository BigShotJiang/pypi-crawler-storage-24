"""Entry point for `python -m geoxerl`."""

from geoxerl.cli import main

if __name__ == "__main__":
    main()
