"""
数据预处理模块
负责数据加载、清洗、合并和格式转换
"""
import os
import pandas as pd
import numpy as np
import rasterio
from tqdm import tqdm
import glob
from pathlib import Path
from typing import List, Dict, Tuple, Optional
import logging

from .config import MODEL_CONFIG, PROCESSING_CONFIG, DATA_PATHS, OUTPUT_PATHS
from .utils import (sanitize_probabilities, validate_dataframe, normalize_weights,
                   impute_missing_values, ensure_numeric_columns,
                   create_coordinate_matching_columns, save_results_with_backup)

# 设置日志
logger = logging.getLogger(__name__)

def identify_environmental_variables(csv_file: str) -> List[str]:
    """
    从CSV文件中动态识别环境变量列
    
    Args:
        csv_file: CSV文件路径
        
    Returns:
        环境变量名列表
    """
    logger.info(f"从CSV文件识别环境变量: {os.path.basename(csv_file)}")
    
    # 读取CSV文件的列名（只读取第一行）
    df_header = pd.read_csv(csv_file, nrows=0)
    all_columns = df_header.columns.tolist()
    
    # 获取需要排除的列
    exclude_cols = PROCESSING_CONFIG["exclude_columns"]
    
    # 识别环境变量（排除系统列）
    env_variables = [col for col in all_columns if col not in exclude_cols]
    
    logger.info(f"总列数: {len(all_columns)}, 识别环境变量: {len(env_variables)}")
    logger.info(f"环境变量列表: {env_variables[:5]}{'...' if len(env_variables) > 5 else ''}")
    
    if not env_variables:
        raise ValueError(f"在文件 {csv_file} 中未识别到任何环境变量")
    
    return env_variables

def extract_original_env_values(points_csv: str, env_dir: str, output_csv: str) -> pd.DataFrame:
    """
    从原始TIFF文件中提取点的环境变量原始值

    Args:
        points_csv: 包含经纬度和环境变量名称的CSV文件路径
        env_dir: 原始环境变量栅格文件目录
        output_csv: 输出CSV文件路径

    Returns:
        处理后的DataFrame
    """
    logger.info(f"从栅格文件提取原始环境变量值...")
    logger.info(f"输入: {os.path.basename(points_csv)}")
    logger.info(f"栅格目录: {env_dir}")

    # 读取点数据
    points_df = pd.read_csv(points_csv)

    # 验证CSV格式
    coord_cols = MODEL_CONFIG["coordinate_columns"]
    validate_dataframe(points_df, coord_cols, "点数据")

    # 动态识别环境变量列
    env_vars = identify_environmental_variables(points_csv)

    logger.info(f"识别到 {len(env_vars)} 个环境变量")

    # 获取栅格文件映射
    env_file_map = _build_env_file_mapping(env_dir, env_vars)

    # 创建输出数据框
    output_df = points_df.copy()

    # 提取原始值
    total_points = len(output_df)
    available_vars = list(env_file_map.keys())

    logger.info(f"开始提取 {len(available_vars)} 个变量的原始值...")

    pbar = tqdm(total=total_points * len(available_vars),
                desc="提取原始环境变量值")

    for env_var in available_vars:
        tif_path = env_file_map[env_var]
        original_col = f"{env_var}{PROCESSING_CONFIG['env_var_suffix']}"

        try:
            output_df[original_col] = _extract_values_from_raster(
                output_df, tif_path, pbar, env_var
            )
            logger.debug(f"成功提取 {env_var} 的原始值")
        except Exception as e:
            logger.error(f"处理 {env_var} 栅格失败: {str(e)}")
            output_df[original_col] = np.nan

    pbar.close()

    # 保存结果
    save_results_with_backup(output_df, Path(output_csv))
    logger.info(f"结果已保存: {output_csv}")

    # 生成质量报告
    _generate_extraction_report(output_df, env_vars, total_points)

    return output_df

def _build_env_file_mapping(env_dir: str, env_vars: List[str]) -> Dict[str, str]:
    """构建环境变量到文件路径的映射"""
    tif_files = glob.glob(os.path.join(env_dir, "*.tif"))
    if not tif_files:
        raise FileNotFoundError(f"在 {env_dir} 中未找到任何TIFF文件")

    env_file_map = {}
    for tif_file in tif_files:
        var_name = os.path.splitext(os.path.basename(tif_file))[0]
        env_file_map[var_name] = tif_file

    # 检查缺失的变量
    missing_vars = [var for var in env_vars if var not in env_file_map]
    if missing_vars:
        logger.warning(f"缺少以下变量的栅格文件: {', '.join(missing_vars)}")

    # 只保留有栅格文件的变量
    available_vars = [var for var in env_vars if var in env_file_map]
    logger.info(f"找到 {len(available_vars)} 个可用的栅格文件")

    return {var: env_file_map[var] for var in available_vars}

def _extract_values_from_raster(df: pd.DataFrame, tif_path: str,
                               pbar: tqdm, var_name: str) -> np.ndarray:
    """从栅格文件中提取值"""
    values = np.full(len(df), np.nan)

    with rasterio.open(tif_path) as src:
        for index, row in df.iterrows():
            try:
                lon, lat = row['longitude'], row['latitude']
                row_idx, col_idx = src.index(lon, lat)

                # 读取值
                value = src.read(1, window=rasterio.windows.Window(col_idx, row_idx, 1, 1))

                if isinstance(value, np.ndarray):
                    value = value[0, 0] if value.ndim == 2 else value[0]

                values[index] = value

            except (rasterio.errors.RasterioIOError, IndexError):
                values[index] = np.nan
            except Exception as e:
                logger.error(f"提取 {var_name} 在索引 {index} 失败: {str(e)}")
                values[index] = np.nan

            pbar.update(1)

    return values

def _generate_extraction_report(df: pd.DataFrame, env_vars: List[str], total_points: int):
    """生成提取质量报告"""
    logger.info("数据提取质量报告:")
    logger.info("-" * 50)

    suffix = PROCESSING_CONFIG['env_var_suffix']

    for env_var in env_vars[:10]:  # 只显示前10个
        col_name = f"{env_var}{suffix}"
        if col_name in df.columns:
            na_count = df[col_name].isna().sum()
            if na_count < total_points:
                min_val = df[col_name].min()
                max_val = df[col_name].max()
                logger.info(f"{env_var}: {min_val:.4f} - {max_val:.4f} (缺失: {na_count}/{total_points})")
            else:
                logger.warning(f"{env_var}: 全部缺失")

def extract_prediction_probability(df: pd.DataFrame, prediction_tif: str) -> pd.DataFrame:
    """
    从集成模型预测TIF文件中提取预测概率
    
    Args:
        df: 包含经纬度的数据框
        prediction_tif: 集成模型预测TIF文件路径
    
    Returns:
        添加了预测概率列的数据框
    """
    prob_col = MODEL_CONFIG["prediction_prob_column"]
    
    logger.info(f"从TIF文件提取预测概率: {os.path.basename(prediction_tif)}")
    
    # 初始化概率列
    df[prob_col] = np.nan
    
    try:
        with rasterio.open(prediction_tif) as src:
            total_points = len(df)
            pbar = tqdm(total=total_points, desc="提取预测概率")
            
            for i, row in df.iterrows():
                try:
                    lon, lat = row['longitude'], row['latitude']
                    # 使用sample方法提取值
                    value = next(src.sample([(lon, lat)]))[0]
                    df.at[i, prob_col] = value
                except:
                    df.at[i, prob_col] = np.nan
                pbar.update(1)
            
            pbar.close()
        
        # 确保概率值在0-1范围
        df[prob_col] = df[prob_col].clip(0, 1)
        
        # 报告统计
        valid_count = df[prob_col].notna().sum()
        prob_min = df[prob_col].min()
        prob_max = df[prob_col].max()
        prob_mean = df[prob_col].mean()
        
        logger.info(f"预测概率提取完成!")
        logger.info(f"有效点数: {valid_count}/{total_points}")
        logger.info(f"概率范围: {prob_min:.4f} - {prob_max:.4f}")
        logger.info(f"平均概率: {prob_mean:.4f}")
        
    except Exception as e:
        logger.error(f"预测概率提取失败: {str(e)}")
        # 使用随机值作为回退
        df[prob_col] = np.random.rand(len(df))
        logger.warning("使用随机值作为回退方案")
    
    return df

def prepare_threshold_input(presence_env_path: str, background_env_path: str,
                          presence_env_original_path: str, background_env_original_path: str,
                          prediction_tif: str, output_path: str) -> pd.DataFrame:
    """
    准备阈值优化输入文件

    Args:
        presence_env_path: 存在点环境变量文件路径
        background_env_path: 背景点环境变量文件路径
        presence_env_original_path: 存在点原始环境变量文件路径
        background_env_original_path: 背景点原始环境变量文件路径
        prediction_tif: 集成模型预测TIF文件路径
        output_path: 输出文件路径

    Returns:
        处理后的DataFrame
    """
    logger.info("=" * 80)
    logger.info("阈值优化数据预处理")
    logger.info("=" * 80)

    # 1. 加载存在点和背景点数据
    logger.info("步骤1: 加载存在点和背景点数据...")
    presence_original = pd.read_csv(presence_env_original_path)
    background_original = pd.read_csv(background_env_original_path)

    # 确保presence列正确设置
    presence_original['presence'] = 1
    background_original['presence'] = 0

    # 合并数据
    all_points = pd.concat([presence_original, background_original], ignore_index=True)
    logger.info(f"总点数: {len(all_points)} (存在点: {len(presence_original)}, 背景点: {len(background_original)})")

    # 2. 从集成模型TIF提取预测概率
    logger.info("步骤2: 从集成模型TIF提取预测概率...")
    all_points = extract_prediction_probability(all_points, prediction_tif)

    # 3. 选择最终需要的列
    logger.info("步骤3: 准备最终数据...")
    coord_cols = MODEL_CONFIG["coordinate_columns"]
    prob_col = MODEL_CONFIG["prediction_prob_column"]

    # 动态识别环境变量（带_original后缀的）
    suffix = PROCESSING_CONFIG["env_var_suffix"]
    env_vars_with_suffix = [col for col in all_points.columns 
                           if col.endswith(suffix) and col not in PROCESSING_CONFIG["exclude_columns"]]

    final_cols = coord_cols + [prob_col] + env_vars_with_suffix
    final_df = all_points[final_cols].copy()

    # 重命名列，去掉_original后缀
    rename_dict = {}
    for col in env_vars_with_suffix:
        new_name = col.replace(suffix, '')
        rename_dict[col] = new_name

    final_df = final_df.rename(columns=rename_dict)

    # 4. 数据清理
    logger.info("步骤4: 数据清理...")
    final_df = _clean_threshold_data(final_df, prob_col)

    # 5. 保存结果
    save_results_with_backup(final_df, Path(output_path))
    logger.info(f"阈值优化输入文件已保存: {output_path}")

    # 6. 生成质量报告
    _generate_processing_report(final_df, prob_col)

    return final_df

def _clean_threshold_data(df: pd.DataFrame, prob_col: str) -> pd.DataFrame:
    """清理阈值数据"""
    before_count = len(df)
    
    # 移除概率为空的行
    df = df.dropna(subset=[prob_col])
    
    # 确保概率在0-1范围
    df[prob_col] = df[prob_col].clip(0, 1)
    
    after_count = len(df)
    if before_count != after_count:
        logger.warning(f"移除了 {before_count - after_count} 个概率为空的点")
    
    return df

def _generate_processing_report(df: pd.DataFrame, prob_col: str):
    """生成处理质量报告"""
    coord_cols = MODEL_CONFIG["coordinate_columns"]
    env_vars = [col for col in df.columns if col not in coord_cols + [prob_col]]

    logger.info("数据处理质量报告:")
    logger.info("-" * 50)
    logger.info(f"总点数: {len(df)}")

    # 安全处理概率范围
    if prob_col in df.columns and pd.api.types.is_numeric_dtype(df[prob_col]):
        prob_min = df[prob_col].min()
        prob_max = df[prob_col].max()
        prob_mean = df[prob_col].mean()
        logger.info(f"预测概率范围: {prob_min:.4f} - {prob_max:.4f}")
        logger.info(f"平均预测概率: {prob_mean:.4f}")
    else:
        logger.error(f"预测概率列 '{prob_col}' 不存在或非数值类型")

    logger.info(f"环境变量数量: {len(env_vars)}")

    # 显示前5个变量的统计
    logger.info("前5个环境变量统计:")
    for var in env_vars[:5]:
        if var in df.columns:
            # 安全获取最小值和最大值
            min_val = df[var].min()
            max_val = df[var].max()
            missing = df[var].isna().sum()

            # 检查是否为数值类型
            if pd.api.types.is_numeric_dtype(df[var]):
                logger.info(f"{var}: {min_val:.2f} - {max_val:.2f} (缺失: {missing})")
            else:
                logger.info(f"{var}: 非数值类型 (缺失: {missing})")
        else:
            logger.warning(f"{var}: 列不存在")

    logger.info("处理完成!")

