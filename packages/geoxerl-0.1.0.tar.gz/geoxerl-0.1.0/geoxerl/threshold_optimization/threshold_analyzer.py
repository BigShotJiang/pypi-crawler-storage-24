"""
阈值分析主模块
整合Q-Learning优化和可视化功能
"""
import os
import pandas as pd
import numpy as np
import json
from datetime import datetime
from typing import Dict, List, Tuple, Optional
from tqdm import tqdm
import logging

from .config import OUTPUT_PATHS, QLEARNING_CONFIG, REPORT_CONFIG, MODEL_CONFIG, PROCESSING_CONFIG
from .q_learning_optimizer import RobustThresholdOptimizer
from .visualizer import ThresholdVisualizer
from .utils import save_results_with_backup

# 设置日志
logger = logging.getLogger(__name__)

def run_threshold_optimization(input_csv: str, output_dir: str,
                             config: Optional[Dict] = None) -> Dict:
    """
    运行完整的阈值优化流程

    Args:
        input_csv: 输入数据文件路径
        output_dir: 输出目录
        config: 优化配置参数

    Returns:
        优化结果字典
    """
    # 使用配置参数
    opt_config = config or QLEARNING_CONFIG

    logger.info("=" * 80)
    logger.info("THRESHOLD OPTIMIZATION SYSTEM")
    logger.info("=" * 80)
    logger.info(f"Input file: {input_csv}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Optimization strategy: Q-Learning with outlier removal")
    logger.info("=" * 80)

    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)

    # 加载数据
    logger.info("Loading input data...")
    try:
        data = pd.read_csv(input_csv)
        logger.info(f"Loaded {len(data)} data points")
    except Exception as e:
        logger.error(f"Cannot load input file {input_csv}: {e}")
        raise FileNotFoundError(f"Cannot load input file {input_csv}: {e}")

    # 确定概率列名
    prob_col = MODEL_CONFIG["prediction_prob_column"]

    # 检查概率列是否存在
    if prob_col not in data.columns:
        logger.error(f"Probability column '{prob_col}' not found in input data")
        raise ValueError(f"Probability column '{prob_col}' not found in input data")

    # 识别环境变量
    env_vars = _identify_environmental_variables(data, prob_col)
    logger.info(f"Identified {len(env_vars)} environmental variables")

    # 初始化结果存储
    results = {
        'metadata': {
            'optimization_date': datetime.now().isoformat(),
            'input_file': input_csv,
            'probability_column': prob_col,
            'total_variables': len(env_vars),
            'total_data_points': len(data),
            'config': opt_config,
            'environmental_variables': env_vars
        },
        'variables': {},
        'optimal_thresholds': {}
    }

    # 初始化可视化器
    visualizer = ThresholdVisualizer()

    # 优化每个变量
    successful_optimizations = 0

    for var_name in tqdm(env_vars, desc="Optimizing variables"):
        logger.info(f"Optimizing variable: {var_name}")

        try:
            # 优化单个变量
            var_results = _optimize_single_variable(
                data, var_name, prob_col, output_dir, opt_config, visualizer
            )

            results['variables'][var_name] = var_results
            results['optimal_thresholds'][var_name] = (
                var_results['optimal_min'],
                var_results['optimal_max']
            )

            successful_optimizations += 1
            logger.info(f"Successfully optimized {var_name}: {var_results['optimal_min']:.4f} - {var_results['optimal_max']:.4f}")

        except Exception as e:
            logger.error(f"Error optimizing {var_name}: {str(e)}")
            results['variables'][var_name] = {
                'error': str(e),
                'skipped': True
            }
            results['optimal_thresholds'][var_name] = (np.nan, np.nan)

    # 更新元数据
    results['metadata']['successful_optimizations'] = successful_optimizations
    results['metadata']['failed_optimizations'] = len(env_vars) - successful_optimizations

    # 保存结果
    _save_optimization_results(results, output_dir)

    # 生成汇总可视化
    if successful_optimizations > 0:
        try:
            visualizer.create_summary_plot(results, output_dir)
            logger.info("Summary plot generated successfully")
        except Exception as e:
            logger.error(f"Failed to generate summary plot: {e}")

    # 生成HTML报告
    try:
        _generate_html_report(results, output_dir)
        logger.info("HTML report generated successfully")
    except Exception as e:
        logger.error(f"Failed to generate HTML report: {e}")

    logger.info(f"Optimization completed!")
    logger.info(f"Successfully optimized: {successful_optimizations}/{len(env_vars)} variables")
    logger.info(f"Results saved in: {output_dir}")

    return results

def _identify_environmental_variables(data: pd.DataFrame, prob_col: str) -> List[str]:
    """识别环境变量列"""
    # 排除的列
    exclude_cols = PROCESSING_CONFIG["exclude_columns"]
    coord_cols = MODEL_CONFIG["coordinate_columns"]
    
    # 合并所有需要排除的列
    all_exclude_cols = set(exclude_cols + coord_cols + [prob_col])

    # 识别环境变量
    env_vars = [col for col in data.columns if col not in all_exclude_cols]

    if not env_vars:
        logger.error("No environmental variables found in the input data")
        raise ValueError("No environmental variables found in the input data")

    logger.info(f"Environmental variables: {env_vars[:5]}{'...' if len(env_vars) > 5 else ''}")
    return env_vars

def _optimize_single_variable(data: pd.DataFrame, var_name: str, prob_col: str,
                            output_dir: str, config: Dict,
                            visualizer: ThresholdVisualizer) -> Dict:
    """优化单个变量"""
    # 创建变量专用目录
    var_dir = os.path.join(output_dir, var_name)
    os.makedirs(var_dir, exist_ok=True)

    # 提取数据
    values = data[var_name].values
    probs = data[prob_col].values

    # 检查数据质量
    if np.all(np.isnan(values)):
        logger.warning(f"Variable {var_name} has all NaN values, skipping...")
        raise ValueError(f"Variable {var_name} has all NaN values")

    # 初始化优化器
    logger.debug(f"Initializing optimizer for {var_name}")
    optimizer = RobustThresholdOptimizer(var_name, values, probs, config)

    # 训练
    logger.debug(f"Training optimizer for {var_name}")
    optimizer.train()

    # 获取最优阈值
    optimal_threshold = optimizer.get_optimal_threshold()

    # 获取训练总结
    training_summary = optimizer.get_training_summary()

    # 分析阈值质量
    quality_analysis = optimizer.analyze_threshold_quality()

    # 生成可视化
    try:
        logger.debug(f"Generating visualizations for {var_name}")
        visualizer.generate_all_plots(optimizer, var_dir, optimal_threshold)
        visualizer.plot_training_progress(optimizer, var_dir)
    except Exception as e:
        logger.warning(f"Failed to generate visualizations for {var_name}: {e}")

    # 准备结果
    var_results = {
        'min': float(optimizer.min_val),
        'max': float(optimizer.max_val),
        'optimal_min': float(optimal_threshold[0]),
        'optimal_max': float(optimal_threshold[1]),
        'max_reward': float(optimizer.max_position_reward),
        'high_prob_threshold': float(optimizer.high_prob_threshold),
        'n_points': len(optimizer.values),
        'training_summary': training_summary,
        'quality_analysis': quality_analysis
    }

    logger.debug(f"Optimal range for {var_name}: {optimal_threshold[0]:.4f} - {optimal_threshold[1]:.4f}")
    logger.debug(f"Max reward for {var_name}: {optimizer.max_position_reward:.4f}")

    return var_results

def _save_optimization_results(results: Dict, output_dir: str) -> None:
    """保存优化结果"""
    # 保存完整结果JSON
    results_path = os.path.join(output_dir, 'optimization_results.json')
    try:
        with open(results_path, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=4, ensure_ascii=False)
        logger.info(f"Complete results saved: {results_path}")
    except Exception as e:
        logger.error(f"Failed to save JSON results: {e}")

    # 保存阈值表格
    threshold_data = []
    for var_name, thresholds in results['optimal_thresholds'].items():
        if var_name not in results['variables'] or 'error' in results['variables'][var_name]:
            continue

        var_data = results['variables'][var_name]
        threshold_data.append({
            'Variable': var_name,
            'Lower_Threshold': thresholds[0],
            'Upper_Threshold': thresholds[1],
            'Max_Reward': var_data.get('max_reward', np.nan),
            'Data_Points': var_data.get('n_points', np.nan),
            'Range_Width': thresholds[1] - thresholds[0] if not any(np.isnan(thresholds)) else np.nan
        })

    if threshold_data:
        threshold_df = pd.DataFrame(threshold_data)
        threshold_df = threshold_df.sort_values('Max_Reward', ascending=False)

        threshold_csv_path = os.path.join(output_dir, 'optimal_thresholds.csv')
        try:
            threshold_df.to_csv(threshold_csv_path, index=False)
            logger.info(f"Threshold table saved: {threshold_csv_path}")
        except Exception as e:
            logger.error(f"Failed to save threshold CSV: {e}")

def _generate_html_report(results: Dict, output_dir: str) -> None:
    """生成HTML报告"""
    html_content = _build_html_content(results)

    report_path = os.path.join(output_dir, 'threshold_optimization_report.html')
    try:
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        logger.info(f"HTML report saved: {report_path}")
    except Exception as e:
        logger.error(f"Failed to generate HTML report: {e}")

def _build_html_content(results: Dict) -> str:
    """构建HTML报告内容 - 包含图像的完整版本"""
    metadata = results['metadata']

    # 找出最高奖励的变量
    max_reward_var = None
    max_reward_val = -1

    for var_name, var_data in results['variables'].items():
        if 'error' not in var_data and 'skipped' not in var_data:
            reward = var_data.get('max_reward', 0)
            if reward > max_reward_val:
                max_reward_val = reward
                max_reward_var = var_name

    # 按奖励排序变量
    sorted_vars = []
    for var_name, var_data in results['variables'].items():
        if 'error' not in var_data and 'skipped' not in var_data:
            sorted_vars.append((var_name, var_data))
    sorted_vars.sort(key=lambda x: x[1].get('max_reward', 0), reverse=True)

    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Threshold Optimization Report</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 40px;
                line-height: 1.6;
                color: #333;
            }}
            h1, h2, h3 {{
                color: #2c3e50;
                margin-top: 30px;
            }}
            h1 {{
                border-bottom: 2px solid #3498db;
                padding-bottom: 10px;
            }}
            .summary-section {{
                background-color: #e8f4f8;
                padding: 20px;
                border-radius: 10px;
                margin-bottom: 30px;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin: 25px 0;
                font-size: 14px;
            }}
            th, td {{
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }}
            th {{
                background-color: #3498db;
                color: white;
            }}
            tr:nth-child(even) {{
                background-color: #f2f2f2;
            }}
            .highlight {{
                background-color: #fffacd;
                font-weight: bold;
            }}
            .variable-section {{
                margin-bottom: 40px;
                padding: 25px;
                background-color: #f9f9f9;
                border-radius: 10px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
                page-break-inside: avoid;
            }}
            .var-title {{
                color: #3498db;
                font-size: 20px;
                margin-bottom: 15px;
            }}
            .threshold-info {{
                background-color: #e8f4f8;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
                font-size: 16px;
            }}
            .highlight-info {{
                background-color: #fffacd;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
                font-size: 16px;
            }}
            .image-row {{
                display: flex;
                justify-content: space-between;
                flex-wrap: wrap;
                margin-top: 20px;
            }}
            .image-container {{
                width: 23%;
                text-align: center;
                margin-bottom: 20px;
                background-color: white;
                padding: 10px;
                border-radius: 5px;
                box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            }}
            .image-container img {{
                max-width: 100%;
                height: auto;
                border: 1px solid #ddd;
                border-radius: 5px;
            }}
            .image-container p {{
                margin-top: 10px;
                font-weight: bold;
                font-size: 12px;
            }}
            .training-image {{
                width: 100%;
                text-align: center;
                margin: 20px 0;
            }}
            .training-image img {{
                max-width: 100%;
                height: auto;
                border: 1px solid #ddd;
                border-radius: 5px;
            }}
            .summary-image {{
                text-align: center;
                margin: 30px 0;
            }}
            .summary-image img {{
                max-width: 100%;
                height: auto;
                border: 1px solid #ddd;
                border-radius: 10px;
            }}
            .timestamp {{
                color: #7f8c8d;
                font-size: 14px;
                text-align: right;
                margin-top: 30px;
            }}
            .stats-grid {{
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
                gap: 15px;
                margin: 20px 0;
            }}
            .stat-card {{
                background-color: white;
                padding: 15px;
                border-radius: 8px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }}
            .stat-value {{
                font-size: 24px;
                font-weight: bold;
                color: #3498db;
            }}
            .stat-label {{
                font-size: 14px;
                color: #666;
                margin-top: 5px;
            }}
            .quality-metrics {{
                background-color: #f0f8ff;
                padding: 15px;
                border-radius: 5px;
                margin: 15px 0;
            }}
            .metric {{
                display: inline-block;
                margin: 5px 15px 5px 0;
                font-size: 14px;
            }}
            .metric-label {{
                font-weight: bold;
                color: #2c3e50;
            }}
            .metric-value {{
                color: #3498db;
            }}
        </style>
    </head>
    <body>
        <h1>Environmental Variable Threshold Optimization Report</h1>

        <div class="summary-section">
            <h2>Optimization Summary</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-value">{metadata['total_variables']}</div>
                    <div class="stat-label">Total Variables</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{metadata['successful_optimizations']}</div>
                    <div class="stat-label">Successful Optimizations</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{metadata['total_data_points']:,}</div>
                    <div class="stat-label">Total Data Points</div>
                </div>
                <div class="stat-card">
                    <div class="stat-value">{datetime.now().strftime('%Y-%m-%d')}</div>
                    <div class="stat-label">Analysis Date</div>
                </div>
            </div>
            
            <p><strong>Optimization Strategy:</strong> Q-Learning based threshold optimization with improved reward function</p>
            <p><strong>High Probability Threshold:</strong> {metadata.get('config', {}).get('high_prob_threshold', 0.7)}</p>
            <p><strong>Best Performing Variable:</strong> {max_reward_var if max_reward_var else "N/A"} (Reward = {max_reward_val:.2f})</p>

            <h3>Overall Results Summary</h3>
            <div class="summary-image">
                <img src="threshold_summary.png" alt="Overall Threshold Summary">
                <p><strong>Figure 1:</strong> Overall threshold optimization results showing optimal ranges and reward comparison</p>
            </div>

            <h3>Detailed Threshold Results</h3>
            <table>
                <tr>
                    <th>Rank</th>
                    <th>Environmental Variable</th>
                    <th>Lower Threshold</th>
                    <th>Upper Threshold</th>
                    <th>Range Width</th>
                    <th>Max Reward</th>
                    <th>Data Points</th>
                </tr>
    """

    # 添加阈值表格
    for rank, (var_name, var_data) in enumerate(sorted_vars, 1):
        is_max_reward = var_name == max_reward_var
        row_class = 'class="highlight"' if is_max_reward else ''
        range_width = var_data['optimal_max'] - var_data['optimal_min']

        html_content += f"""
            <tr {row_class}>
                <td>{rank}</td>
                <td>{var_name}</td>
                <td>{var_data['optimal_min']:.4f}</td>
                <td>{var_data['optimal_max']:.4f}</td>
                <td>{range_width:.4f}</td>
                <td>{var_data['max_reward']:.2f}</td>
                <td>{var_data['n_points']}</td>
            </tr>
        """

    html_content += """
            </table>
        </div>

        <h2>Detailed Variable Analysis</h2>
        <p>The following sections provide detailed analysis for each environmental variable, including visualization of threshold optimization results and training progress.</p>
    """

    # 为每个变量添加详细部分（按奖励排序，显示前10个）
    display_count = min(10, len(sorted_vars))
    for rank, (var_name, var_data) in enumerate(sorted_vars[:display_count], 1):
        is_max_reward = var_name == max_reward_var
        range_width = var_data['optimal_max'] - var_data['optimal_min']

        # 获取质量分析数据
        quality_data = var_data.get('quality_analysis', {})
        
        html_content += f"""
        <div class="variable-section">
            <h2 class="var-title">#{rank} - {var_name}</h2>

            <div class="{'highlight-info' if is_max_reward else 'threshold-info'}">
                <strong>Optimal Threshold Range:</strong> {var_data['optimal_min']:.4f} - {var_data['optimal_max']:.4f}<br>
                <strong>Range Width:</strong> {range_width:.4f}<br>
                <strong>Max Reward:</strong> {var_data['max_reward']:.2f}<br>
                <strong>Data Points:</strong> {var_data['n_points']:,}<br>
                <strong>High Probability Threshold:</strong> {var_data.get('high_prob_threshold', 'N/A'):.2f}
                {' <span style="color: #d4a424;">⭐ BEST VARIABLE</span>' if is_max_reward else ''}
            </div>
        """

        # 添加质量指标
        if quality_data:
            html_content += f"""
            <div class="quality-metrics">
                <h4>Quality Metrics:</h4>
                <div class="metric">
                    <span class="metric-label">Points in Range:</span>
                    <span class="metric-value">{quality_data.get('points_in_optimal_range', 'N/A')}</span>
                </div>
                <div class="metric">
                    <span class="metric-label">High Prob Points:</span>
                    <span class="metric-value">{quality_data.get('high_prob_points_in_range', 'N/A')}</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Avg Probability:</span>
                    <span class="metric-value">{quality_data.get('avg_probability_in_range', 0):.3f}</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Point Density:</span>
                    <span class="metric-value">{quality_data.get('point_density', 0):.2f}</span>
                </div>
                <div class="metric">
                    <span class="metric-label">Coverage Ratio:</span>
                    <span class="metric-value">{quality_data.get('coverage_ratio', 0):.3f}</span>
                </div>
                <div class="metric">
                    <span class="metric-label">High Prob Ratio:</span>
                    <span class="metric-value">{quality_data.get('high_prob_ratio', 0):.3f}</span>
                </div>
            </div>
            """

        html_content += f"""
            <h4>Threshold Analysis Plots</h4>
            <div class="image-row">
                <div class="image-container">
                    <img src="{var_name}/{var_name}_scatter.png" alt="{var_name} scatter plot">
                    <p>Probability Distribution</p>
                </div>
                <div class="image-container">
                    <img src="{var_name}/{var_name}_threshold.png" alt="{var_name} threshold">
                    <p>Optimal Threshold Range</p>
                </div>
                <div class="image-container">
                    <img src="{var_name}/{var_name}_high_prob_density.png" alt="{var_name} density">
                    <p>High Probability Point Density</p>
                </div>
                <div class="image-container">
                    <img src="{var_name}/{var_name}_response_curve.png" alt="{var_name} response">
                    <p>Response Curve</p>
                </div>
            </div>

            <h4>Training Progress Analysis</h4>
            <div class="training-image">
                <img src="{var_name}/{var_name}_training.png" alt="{var_name} training">
                <p><strong>Figure:</strong> Q-Learning training progress showing reward evolution, exploration decay, and threshold convergence</p>
            </div>
        </div>
        """

    # 如果有更多变量，显示简化列表
    if len(sorted_vars) > display_count:
        html_content += f"""
        <div class="variable-section">
            <h2>Additional Variables (Ranks {display_count + 1}-{len(sorted_vars)})</h2>
            <p>The following variables were also optimized but are not shown in detail:</p>
            <table>
                <tr>
                    <th>Rank</th>
                    <th>Variable</th>
                    <th>Lower Threshold</th>
                    <th>Upper Threshold</th>
                    <th>Max Reward</th>
                </tr>
        """
        
        for rank, (var_name, var_data) in enumerate(sorted_vars[display_count:], display_count + 1):
            html_content += f"""
                <tr>
                    <td>{rank}</td>
                    <td>{var_name}</td>
                    <td>{var_data['optimal_min']:.4f}</td>
                    <td>{var_data['optimal_max']:.4f}</td>
                    <td>{var_data['max_reward']:.2f}</td>
                </tr>
            """
        
        html_content += """
            </table>
        </div>
        """


    return html_content

