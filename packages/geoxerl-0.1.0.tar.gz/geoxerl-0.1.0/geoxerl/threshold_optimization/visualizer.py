"""
阈值优化可视化模块 - 优化版本
生成响应曲线、散点图、密度图等分析图表
"""
import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pygam import LinearGAM, s
from scipy.interpolate import interp1d
from scipy.stats import gaussian_kde
from typing import Dict, List, Tuple, Optional
import warnings
import logging

from .config import VISUALIZATION_CONFIG, REPORT_CONFIG
from .q_learning_optimizer import RobustThresholdOptimizer

# 设置matplotlib参数
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.facecolor'] = 'white'

logger = logging.getLogger(__name__)

class ThresholdVisualizer:
    """阈值优化可视化器 - 优化版本"""
    
    def __init__(self, config: Optional[Dict] = None):
        """
        初始化可视化器
        
        Args:
            config: 可视化配置
        """
        self.config = config or VISUALIZATION_CONFIG
        self.figure_size = self.config["figure_size"]
        self.dpi = self.config["dpi"]
        self.colors = self.config["colors"]
        self.alpha = self.config["alpha"]
        self.marker_sizes = self.config["marker_sizes"]

    def generate_all_plots(self, optimizer: RobustThresholdOptimizer, 
                          output_dir: str, optimal_threshold: Tuple[float, float]) -> None:
        """
        生成所有图表
        
        Args:
            optimizer: 优化器对象
            output_dir: 输出目录
            optimal_threshold: 最优阈值范围
        """
        os.makedirs(output_dir, exist_ok=True)
        
        try:
            # 图1: 散点图
            self.plot_scatter(optimizer, output_dir, optimal_threshold)
            
            # 图2: 阈值范围图
            self.plot_threshold_range(optimizer, output_dir, optimal_threshold)
            
            # 图3: 高概率点密度图
            self.plot_high_prob_density(optimizer, output_dir, optimal_threshold)
            
            # 图4: 响应曲线
            self.plot_response_curve(optimizer, output_dir, optimal_threshold)
            
            logger.debug(f"为 {optimizer.var_name} 生成了所有图表")
            
        except Exception as e:
            logger.error(f"为 {optimizer.var_name} 生成图表时出错: {e}")

    def plot_scatter(self, optimizer: RobustThresholdOptimizer, 
                    output_dir: str, optimal_threshold: Tuple[float, float]) -> None:
        """绘制散点图"""
        plt.figure(figsize=self.figure_size)
        
        # 识别高低概率点
        high_prob_mask = optimizer.probs > optimizer.high_prob_threshold
        low_prob_mask = ~high_prob_mask
        
        # 绘制低概率点
        if np.sum(low_prob_mask) > 0:
            plt.scatter(optimizer.values[low_prob_mask], optimizer.probs[low_prob_mask],
                       alpha=self.alpha["low_prob"], 
                       s=self.marker_sizes["low_prob"], 
                       color=self.colors["low_prob"], 
                       label=f'Low Probability Points (≤{optimizer.high_prob_threshold})')
        
        # 绘制高概率点
        if np.sum(high_prob_mask) > 0:
            plt.scatter(optimizer.values[high_prob_mask], optimizer.probs[high_prob_mask],
                       alpha=self.alpha["high_prob"], 
                       s=self.marker_sizes["high_prob"], 
                       color=self.colors["high_prob"], 
                       label=f'High Probability Points (>{optimizer.high_prob_threshold})')
        
        plt.title(f'{optimizer.var_name} - Prediction Probability Distribution', fontsize=14)
        plt.xlabel(f'{optimizer.var_name}', fontsize=12)
        plt.ylabel('Prediction Probability', fontsize=12)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        output_path = os.path.join(output_dir, f'{optimizer.var_name}_scatter.png')
        plt.savefig(output_path, dpi=self.dpi, bbox_inches='tight')
        plt.close()

    def plot_threshold_range(self, optimizer: RobustThresholdOptimizer, 
                           output_dir: str, optimal_threshold: Tuple[float, float]) -> None:
        """绘制阈值范围图"""
        plt.figure(figsize=self.figure_size)
        
        # 绘制所有点
        plt.scatter(optimizer.values, optimizer.probs, 
                   alpha=self.alpha["low_prob"], 
                   s=self.marker_sizes["low_prob"], 
                   color=self.colors["low_prob"],
                   label='All Points')
        
        # 标记最优阈值范围内的点
        mask = (optimizer.values >= optimal_threshold[0]) & (optimizer.values <= optimal_threshold[1])
        if np.sum(mask) > 0:
            plt.scatter(optimizer.values[mask], optimizer.probs[mask],
                       s=self.marker_sizes["high_prob"], 
                       color=self.colors["high_prob"], 
                       alpha=0.8,
                       label='Points in Optimal Range')
        
        # 标注最优阈值范围
        lower, upper = optimal_threshold
        plt.axvline(x=lower, color=self.colors["threshold"], linestyle='--', 
                   linewidth=2, label=f'Lower Threshold ({lower:.3f})')
        plt.axvline(x=upper, color=self.colors["threshold"], linestyle='--', 
                   linewidth=2, label=f'Upper Threshold ({upper:.3f})')
        plt.axvspan(lower, upper, alpha=self.alpha["optimal_range"], 
                   color=self.colors["optimal_range"], label='Optimal Range')
        
        plt.title(f'{optimizer.var_name} - Optimal Threshold Range', fontsize=14)
        plt.xlabel(f'{optimizer.var_name}', fontsize=12)
        plt.ylabel('Prediction Probability', fontsize=12)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        output_path = os.path.join(output_dir, f'{optimizer.var_name}_threshold.png')
        plt.savefig(output_path, dpi=self.dpi, bbox_inches='tight')
        plt.close()

    def plot_high_prob_density(self, optimizer: RobustThresholdOptimizer, 
                              output_dir: str, optimal_threshold: Tuple[float, float]) -> None:
        """绘制高概率点密度图"""
        plt.figure(figsize=self.figure_size)
        
        # 只考虑高概率点
        high_prob_mask = optimizer.probs > optimizer.high_prob_threshold
        high_prob_values = optimizer.values[high_prob_mask]
        high_prob_probs = optimizer.probs[high_prob_mask]
        
        if len(high_prob_values) > 1:
            try:
                # 计算密度
                xy = np.vstack([high_prob_values, high_prob_probs])
                z = gaussian_kde(xy)(xy)
                
                # 绘制密度散点图
                scatter = plt.scatter(high_prob_values, high_prob_probs, c=z, 
                                    s=self.marker_sizes["low_prob"], cmap='viridis')
                plt.colorbar(scatter, label='High Probability Point Density')
                
            except Exception as e:
                logger.warning(f"密度计算失败 {optimizer.var_name}: {e}")
                plt.scatter(high_prob_values, high_prob_probs,
                           s=self.marker_sizes["low_prob"], 
                           color=self.colors["high_prob"])
        elif len(high_prob_values) == 1:
            plt.scatter(high_prob_values, high_prob_probs,
                       s=self.marker_sizes["high_prob"], 
                       color=self.colors["high_prob"])
        else:
            plt.text(0.5, 0.5, 'No High Probability Points', 
                    ha='center', va='center', fontsize=16, 
                    transform=plt.gca().transAxes)
        
        # 标注最优阈值范围
        lower, upper = optimal_threshold
        plt.axvline(x=lower, color=self.colors["high_prob"], linestyle='--', 
                   linewidth=2, label='Lower Threshold')
        plt.axvline(x=upper, color=self.colors["high_prob"], linestyle='--', 
                   linewidth=2, label='Upper Threshold')
        plt.axvspan(lower, upper, alpha=self.alpha["optimal_range"], 
                   color=self.colors["high_prob"], label='Optimal Range')
        
        plt.title(f'{optimizer.var_name} - High Probability Point Density', fontsize=14)
        plt.xlabel(f'{optimizer.var_name}', fontsize=12)
        plt.ylabel('Prediction Probability', fontsize=12)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        output_path = os.path.join(output_dir, f'{optimizer.var_name}_high_prob_density.png')
        plt.savefig(output_path, dpi=self.dpi, bbox_inches='tight')
        plt.close()

    def plot_response_curve(self, optimizer: RobustThresholdOptimizer, 
                           output_dir: str, optimal_threshold: Tuple[float, float]) -> None:
        """绘制响应曲线"""
        plt.figure(figsize=self.figure_size)
        
        # 绘制数据点
        plt.scatter(optimizer.values, optimizer.probs, 
                   alpha=self.alpha["low_prob"], 
                   s=self.marker_sizes["low_prob"], 
                   color=self.colors["low_prob"], 
                   label='Data Points')
        
        # 拟合响应曲线
        self._fit_and_plot_response_curve(optimizer)
        
        # 标注最优阈值范围
        lower, upper = optimal_threshold
        plt.axvspan(lower, upper, alpha=self.alpha["optimal_range"], 
                   color=self.colors["optimal_range"], label='Optimal Range')
        
        plt.title(f'{optimizer.var_name} - Response Curve', fontsize=14)
        plt.xlabel(f'{optimizer.var_name}', fontsize=12)
        plt.ylabel('Prediction Probability', fontsize=12)
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        output_path = os.path.join(output_dir, f'{optimizer.var_name}_response_curve.png')
        plt.savefig(output_path, dpi=self.dpi, bbox_inches='tight')
        plt.close()

    def _fit_and_plot_response_curve(self, optimizer: RobustThresholdOptimizer) -> None:
        """拟合并绘制响应曲线"""
        # 准备数据 - 使用分箱平均
        n_bins = min(20, len(optimizer.values) // 10)
        if n_bins < 3:
            n_bins = 3
        
        try:
            # 创建分箱
            bin_edges = np.linspace(optimizer.min_val, optimizer.max_val, n_bins + 1)
            bin_centers = (bin_edges[:-1] + bin_edges[1:]) / 2
            bin_means = []
            
            for i in range(len(bin_centers)):
                mask = (optimizer.values >= bin_edges[i]) & (optimizer.values < bin_edges[i+1])
                if np.sum(mask) > 0:
                    bin_means.append(np.mean(optimizer.probs[mask]))
                else:
                    bin_means.append(np.nan)
            
            # 移除NaN值
            valid_mask = ~np.isnan(bin_means)
            valid_centers = bin_centers[valid_mask]
            valid_means = np.array(bin_means)[valid_mask]
            
            if len(valid_centers) >= 3:
                # 尝试GAM拟合
                try:
                    gam = LinearGAM(s(0, n_splines=min(10, len(valid_centers)))).fit(valid_centers, valid_means)
                    x_smooth = np.linspace(optimizer.min_val, optimizer.max_val, 100)
                    y_smooth = gam.predict(x_smooth)
                    plt.plot(x_smooth, y_smooth, 'r-', linewidth=3, label='GAM Response Curve')
                except:
                    # GAM失败，使用插值
                    if len(valid_centers) >= 3:
                        interp_func = interp1d(valid_centers, valid_means, 
                                             kind='quadratic', fill_value="extrapolate")
                        x_smooth = np.linspace(optimizer.min_val, optimizer.max_val, 100)
                        y_smooth = interp_func(x_smooth)
                        plt.plot(x_smooth, y_smooth, 'r-', linewidth=3, label='Interpolated Curve')
            else:
                # 数据点太少，使用简单连线
                plt.plot(valid_centers, valid_means, 'r-', linewidth=3, 
                        marker='o', markersize=6, label='Mean Response')
                
        except Exception as e:
            logger.warning(f"响应曲线拟合失败 {optimizer.var_name}: {e}")

    def plot_training_progress(self, optimizer: RobustThresholdOptimizer, 
                             output_dir: str) -> None:
        """绘制训练进度图 - 优化版本"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # 子图1: 总奖励曲线
        axes[0,0].plot(optimizer.rewards, alpha=0.7, color='blue')
        # 添加移动平均
        if len(optimizer.rewards) > 20:
            window = min(50, len(optimizer.rewards) // 10)
            moving_avg = pd.Series(optimizer.rewards).rolling(window=window).mean()
            axes[0,0].plot(moving_avg, color='red', linewidth=2, label=f'Moving Average (window={window})')
            axes[0,0].legend()
        
        axes[0,0].set_title(f'{optimizer.var_name} - Total Reward Progress')
        axes[0,0].set_xlabel('Episode')
        axes[0,0].set_ylabel('Total Reward')
        axes[0,0].grid(True, alpha=0.3)
        
        # 子图2: 位置奖励趋势（更重要）
        axes[0,1].plot(optimizer.position_rewards, alpha=0.7, color='green')
        if len(optimizer.position_rewards) > 20:
            window = min(50, len(optimizer.position_rewards) // 10)
            moving_avg = pd.Series(optimizer.position_rewards).rolling(window=window).mean()
            axes[0,1].plot(moving_avg, color='red', linewidth=2, label=f'Moving Average (window={window})')
            axes[0,1].legend()
        
        axes[0,1].set_title(f'{optimizer.var_name} - Position Reward Trend')
        axes[0,1].set_xlabel('Episode')
        axes[0,1].set_ylabel('Position Reward')
        axes[0,1].grid(True, alpha=0.3)
        
        # 子图3: 探索率衰减
        exploration_rates = [optimizer.config["exploration_rate"] * 
                            (optimizer.config["exploration_decay"] ** i) 
                            for i in range(len(optimizer.rewards))]
        exploration_rates = [max(rate, optimizer.config["min_exploration"]) 
                            for rate in exploration_rates]
        
        axes[1,0].plot(exploration_rates, color='orange')
        axes[1,0].set_title('Exploration Rate Decay')
        axes[1,0].set_xlabel('Episode')
        axes[1,0].set_ylabel('Exploration Rate')
        axes[1,0].grid(True, alpha=0.3)
        
        # 子图4: 最优阈值收敛
        if optimizer.optimal_thresholds:
            lower_bounds = [state[0] * optimizer.bin_size + optimizer.min_val 
                           for state in optimizer.optimal_thresholds]
            upper_bounds = [state[1] * optimizer.bin_size + optimizer.min_val 
                           for state in optimizer.optimal_thresholds]
            
            axes[1,1].plot(lower_bounds, label='Lower Bound', alpha=0.7)
            axes[1,1].plot(upper_bounds, label='Upper Bound', alpha=0.7)
            axes[1,1].axhline(y=optimizer.get_optimal_threshold()[0], 
                             color='green', linestyle='--', label='Final Lower')
            axes[1,1].axhline(y=optimizer.get_optimal_threshold()[1], 
                             color='red', linestyle='--', label='Final Upper')
            axes[1,1].legend()
        
        axes[1,1].set_title('Threshold Convergence')
        axes[1,1].set_xlabel('Episode')
        axes[1,1].set_ylabel('Threshold Value')
        axes[1,1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        output_path = os.path.join(output_dir, f'{optimizer.var_name}_training.png')
        plt.savefig(output_path, dpi=self.dpi, bbox_inches='tight')
        plt.close()

    def create_summary_plot(self, results: Dict, output_dir: str) -> None:
        """创建优化的汇总图表"""
        # 提取数据
        variables = []
        thresholds_lower = []
        thresholds_upper = []
        rewards = []
        
        for var_name, var_data in results['variables'].items():
            if 'error' not in var_data and 'skipped' not in var_data:
                variables.append(var_name)
                thresholds_lower.append(var_data['optimal_min'])
                thresholds_upper.append(var_data['optimal_max'])
                rewards.append(var_data['max_reward'])
        
        if not variables:
            logger.warning("没有成功的优化结果用于汇总图")
            return
        
        # 创建汇总图
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 12))
        
        # 阈值范围图
        y_pos = np.arange(len(variables))
        
        # 按奖励值排序
        sorted_indices = np.argsort(rewards)[::-1]  # 降序
        sorted_vars = [variables[i] for i in sorted_indices]
        sorted_lower = [thresholds_lower[i] for i in sorted_indices]
        sorted_upper = [thresholds_upper[i] for i in sorted_indices]
        sorted_rewards = [rewards[i] for i in sorted_indices]
        
        # 绘制阈值范围（前15个变量）
        display_count = min(15, len(sorted_vars))
        for i in range(display_count):
            width = sorted_upper[i] - sorted_lower[i]
            ax1.barh(i, width, left=sorted_lower[i], alpha=0.7, 
                    color=plt.cm.viridis(i / display_count))
        
        ax1.set_yticks(range(display_count))
        ax1.set_yticklabels(sorted_vars[:display_count])
        ax1.set_xlabel('Environmental Variable Value')
        ax1.set_title('Optimal Threshold Ranges (Top Variables by Reward)')
        ax1.grid(True, alpha=0.3)
        
        # 奖励值对比 - 使用对数刻度解决差异过大问题
        if REPORT_CONFIG.get("reward_display_log_scale", True):
            # 确保所有奖励值为正
            min_reward = min(sorted_rewards)
            if min_reward <= 0:
                offset = abs(min_reward) + 1
                adjusted_rewards = [r + offset for r in sorted_rewards]
                ax2.set_ylabel('Maximum Reward (Log Scale, Offset Applied)')
            else:
                adjusted_rewards = sorted_rewards
                ax2.set_ylabel('Maximum Reward (Log Scale)')
            
            bars = ax2.bar(range(len(sorted_vars)), adjusted_rewards, alpha=0.7, 
                          color=[plt.cm.viridis(i / len(sorted_vars)) for i in range(len(sorted_vars))])
            ax2.set_yscale('log')
        else:
            bars = ax2.bar(range(len(sorted_vars)), sorted_rewards, alpha=0.7, 
                          color=[plt.cm.viridis(i / len(sorted_vars)) for i in range(len(sorted_vars))])
            ax2.set_ylabel('Maximum Reward')
        
        ax2.set_xlabel('Environmental Variables')
        ax2.set_title('Maximum Reward Comparison (Log Scale)')
        ax2.set_xticks(range(len(sorted_vars)))
        ax2.set_xticklabels(sorted_vars, rotation=45, ha='right')
        ax2.grid(True, alpha=0.3)
        
        # 标注最高奖励
        bars[0].set_color('red')
        bars[0].set_alpha(1.0)
        
        plt.tight_layout()
        
        output_path = os.path.join(output_dir, 'threshold_summary.png')
        plt.savefig(output_path, dpi=self.dpi, bbox_inches='tight')
        plt.close()
        
        logger.info(f"汇总图已保存: {output_path}")

