"""
阈值优化系统主程序
基于Q-Learning的环境变量最适阈值分析
"""
import argparse
import os
import sys
from pathlib import Path
import traceback
import logging

from .config import (DATA_PATHS, OUTPUT_PATHS, QLEARNING_CONFIG, LOGGING_CONFIG,
                   validate_paths, create_output_directories)
from .data_processor import (extract_original_env_values, prepare_threshold_input)
from .threshold_analyzer import run_threshold_optimization
from .utils import setup_logging, suppress_warnings

# 设置日志
logger = None

def setup_system_logging():
    """设置系统日志"""
    global logger
    logger = setup_logging(LOGGING_CONFIG)
    return logger

def print_system_info():
    """打印系统信息"""
    print("=" * 80)
    print("              环境变量阈值优化系统")
    print("=" * 80)
    print(f"结果目录: {OUTPUT_PATHS['results_dir']}")
    print("=" * 80)

def step_extract_original_values():
    """步骤1: 提取原始环境变量值"""
    logger.info("步骤1: 提取原始环境变量值")
    print("\n 步骤1: 提取原始环境变量值")
    print("-" * 50)

    # 处理存在点
    logger.info("处理存在点数据...")
    print("处理存在点数据...")
    presence_df = extract_original_env_values(
        DATA_PATHS["presence_env_csv"],
        DATA_PATHS["env_raster_dir"],
        str(DATA_PATHS["presence_env_original_csv"])
    )

    # 处理背景点
    logger.info("处理背景点数据...")
    print("\n处理背景点数据...")
    background_df = extract_original_env_values(
        DATA_PATHS["background_env_csv"],
        DATA_PATHS["env_raster_dir"],
        str(DATA_PATHS["background_env_original_csv"])
    )

    logger.info(f"原始值提取完成! 存在点: {len(presence_df)}, 背景点: {len(background_df)}")
    print(f" 原始值提取完成!")
    print(f"   - 存在点数据: {len(presence_df)} 个")
    print(f"   - 背景点数据: {len(background_df)} 个")

    return presence_df, background_df

def step_prepare_threshold_data():
    """步骤2: 准备阈值优化数据"""
    logger.info("步骤2: 准备阈值优化数据")
    print("\n 步骤2: 准备阈值优化数据")
    print("-" * 50)

    # 准备阈值优化输入
    threshold_df = prepare_threshold_input(
        presence_env_path=DATA_PATHS["presence_env_csv"],
        background_env_path=DATA_PATHS["background_env_csv"],
        presence_env_original_path=str(DATA_PATHS["presence_env_original_csv"]),
        background_env_original_path=str(DATA_PATHS["background_env_original_csv"]),
        prediction_tif=DATA_PATHS["prediction_tif"],
        output_path=str(OUTPUT_PATHS["input_csv"])
    )

    logger.info(f"阈值数据准备完成! 总点数: {len(threshold_df)}")
    print(f" 阈值数据准备完成!")
    print(f"   - 总点数: {len(threshold_df):,}")
    print(f"   - 输入文件: {OUTPUT_PATHS['input_csv']}")

    return threshold_df

def step_run_optimization(custom_config=None):
    """步骤3: 运行阈值优化"""
    logger.info("步骤3: 运行Q-Learning阈值优化")
    print("\n 步骤3: 运行Q-Learning阈值优化")
    print("-" * 50)

    # 检查输入文件
    input_file = OUTPUT_PATHS["input_csv"]
    if not os.path.exists(input_file):
        error_msg = f"输入文件不存在: {input_file}"
        logger.error(error_msg)
        raise FileNotFoundError(error_msg)

    # 使用自定义配置或默认配置
    config = custom_config or QLEARNING_CONFIG

    # 运行优化
    logger.info(f"开始阈值优化，配置: {config}")
    results = run_threshold_optimization(
        input_csv=str(input_file),
        output_dir=str(OUTPUT_PATHS["results_dir"]),
        config=config
    )

    # 保存主要结果到配置的路径
    save_main_results(results)

    successful = results['metadata']['successful_optimizations']
    total = results['metadata']['total_variables']
    
    logger.info(f"阈值优化完成! 成功: {successful}/{total}")
    print(f" 阈值优化完成!")
    print(f"   - 成功优化: {successful}/{total} 个变量")
    print(f"   - 结果目录: {OUTPUT_PATHS['results_dir']}")

    return results

def save_main_results(results):
    """保存主要结果到配置的路径"""
    import json
    import pandas as pd
    
    # 保存JSON结果
    try:
        with open(OUTPUT_PATHS["results_json"], 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=4, ensure_ascii=False)
        logger.info(f"主要JSON结果已保存: {OUTPUT_PATHS['results_json']}")
    except Exception as e:
        logger.error(f"保存JSON结果失败: {e}")

    # 保存阈值CSV
    try:
        threshold_data = []
        for var_name, var_data in results['variables'].items():
            if 'error' not in var_data:
                threshold_data.append({
                    'Variable': var_name,
                    'Lower_Threshold': var_data['optimal_min'],
                    'Upper_Threshold': var_data['optimal_max'],
                    'Max_Reward': var_data['max_reward'],
                    'Data_Points': var_data['n_points']
                })
        
        if threshold_data:
            threshold_df = pd.DataFrame(threshold_data)
            threshold_df = threshold_df.sort_values('Max_Reward', ascending=False)
            threshold_df.to_csv(OUTPUT_PATHS["thresholds_csv"], index=False)
            logger.info(f"阈值CSV已保存: {OUTPUT_PATHS['thresholds_csv']}")
    except Exception as e:
        logger.error(f"保存阈值CSV失败: {e}")

def print_final_summary():
    """打印最终摘要"""
    print("\n" + "=" * 80)
    print("                  系统执行完成")
    print("=" * 80)
    print(f" 输出文件清单:")
    print(f"   输入文件: {OUTPUT_PATHS['input_csv']}")
    print(f"   阈值结果: {OUTPUT_PATHS['thresholds_csv']}")
    print(f"   优化结果: {OUTPUT_PATHS['results_json']}")
    print(f"   HTML报告: {OUTPUT_PATHS['html_report']}")
    print(f"   详细结果: {OUTPUT_PATHS['results_dir']}")
    print(f"\n 所有步骤执行成功!")
    print("=" * 80)

def main():
    """主程序入口"""
    parser = argparse.ArgumentParser(
        description="环境变量阈值优化系统",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  python q_main.py --step all                    # 运行所有步骤
  python q_main.py --step extract                # 仅提取原始值
  python q_main.py --step prepare                # 仅准备阈值数据
  python q_main.py --step optimize               # 仅运行优化
  python q_main.py --episodes 1000 --bins 150   # 自定义参数
  
步骤说明:
  extract   - 从栅格文件提取原始环境变量值
  prepare   - 准备阈值优化输入数据
  optimize  - 运行Q-Learning阈值优化
  all       - 按顺序执行所有步骤
        """
    )

    parser.add_argument("--step",
                       choices=["all", "extract", "prepare", "optimize"],
                       default="all",
                       help="执行步骤")
    parser.add_argument("--episodes",
                       type=int,
                       default=QLEARNING_CONFIG["num_episodes"],
                       help=f"训练轮数 (默认: {QLEARNING_CONFIG['num_episodes']})")
    parser.add_argument("--bins",
                       type=int,
                       default=QLEARNING_CONFIG["n_bins"],
                       help=f"离散化区间数 (默认: {QLEARNING_CONFIG['n_bins']})")
    parser.add_argument("--output",
                       help="自定义输出目录")
    parser.add_argument("--verbose",
                       action="store_true",
                       help="显示详细输出")

    args = parser.parse_args()

    # 设置日志
    setup_system_logging()
    
    # 抑制警告
    suppress_warnings()

    # 设置输出目录
    if args.output:
        output_base = Path(args.output)
        for key in OUTPUT_PATHS:
            if key != "results_dir":
                OUTPUT_PATHS[key] = output_base / OUTPUT_PATHS[key].name
        OUTPUT_PATHS["results_dir"] = output_base

    # 显示系统信息
    print_system_info()
    logger.info(f"系统启动，执行步骤: {args.step}")
    print(f"执行步骤: {args.step}")
    if args.episodes != QLEARNING_CONFIG["num_episodes"]:
        logger.info(f"自定义训练轮数: {args.episodes}")
        print(f"训练轮数: {args.episodes:,}")
    if args.bins != QLEARNING_CONFIG["n_bins"]:
        logger.info(f"自定义离散化区间: {args.bins}")
        print(f"离散化区间: {args.bins}")

    # 验证路径
    print("\n 验证输入路径...")
    logger.info("开始路径验证")
    if not validate_paths():
        error_msg = "路径验证失败，请检查配置文件中的路径设置"
        logger.error(error_msg)
        print(f" {error_msg}")
        print("\n请检查以下路径:")
        print(f"  - 存在点文件: {DATA_PATHS['presence_env_csv']}")
        print(f"  - 背景点文件: {DATA_PATHS['background_env_csv']}")
        print(f"  - 集成模型TIF: {DATA_PATHS['prediction_tif']}")
        print(f"  - 环境变量栅格目录: {DATA_PATHS['env_raster_dir']}")
        return 1

    logger.info("路径验证通过")
    print(" 路径验证通过")

    # 创建输出目录
    create_output_directories()

    try:
        # 准备自定义配置
        custom_config = None
        if args.episodes != QLEARNING_CONFIG["num_episodes"] or args.bins != QLEARNING_CONFIG["n_bins"]:
            custom_config = QLEARNING_CONFIG.copy()
            custom_config["num_episodes"] = args.episodes
            custom_config["n_bins"] = args.bins
            logger.info(f"使用自定义配置: episodes={args.episodes}, bins={args.bins}")

        # 执行步骤
        if args.step in ["all", "extract"]:
            logger.info("开始执行提取步骤")
            presence_df, background_df = step_extract_original_values()

        if args.step in ["all", "prepare"]:
            logger.info("开始执行准备步骤")
            threshold_df = step_prepare_threshold_data()

        if args.step in ["all", "optimize"]:
            logger.info("开始执行优化步骤")
            results = step_run_optimization(custom_config)

        # 打印最终摘要
        if args.step == "all":
            print_final_summary()
            logger.info("所有步骤执行完成")
        else:
            logger.info(f"步骤 '{args.step}' 执行完成")
            print(f"\n 步骤 '{args.step}' 执行完成!")

        return 0

    except KeyboardInterrupt:
        error_msg = "用户中断程序执行"
        logger.warning(error_msg)
        print(f"\n\n {error_msg}")
        return 1

    except Exception as e:
        error_msg = f"程序执行出错: {e}"
        logger.error(error_msg, exc_info=True)
        print(f"\n {error_msg}")
        if args.verbose:
            print("\n详细错误信息:")
            traceback.print_exc()
        print("\n请检查:")
        print("  1. 输入文件路径是否正确")
        print("  2. 数据文件格式是否符合要求")
        print("  3. 系统是否有足够的内存和存储空间")
        print("  4. 是否已安装所有必需的Python包")
        print(f"  5. 查看日志文件: {LOGGING_CONFIG['file']}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
