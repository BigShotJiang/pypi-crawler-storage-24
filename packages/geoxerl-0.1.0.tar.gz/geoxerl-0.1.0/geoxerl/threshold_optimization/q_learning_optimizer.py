"""
Q-Learning阈值优化器 - 优化版本
基于强化学习的环境变量最适阈值搜索
"""
import numpy as np
import pandas as pd
from tqdm import tqdm
from typing import Tuple, List, Dict, Optional
from scipy.stats import gaussian_kde
import logging

from .config import QLEARNING_CONFIG, PROCESSING_CONFIG
from .utils import remove_outliers

logger = logging.getLogger(__name__)

class RobustThresholdOptimizer:
    """
    稳健阈值优化器 - 优化版本
    使用Q-Learning算法寻找环境变量的最适阈值范围
    """
    
    def __init__(self, var_name: str, values: np.ndarray, probs: np.ndarray, 
                 config: Optional[Dict] = None):
        """
        初始化优化器
        
        Args:
            var_name: 变量名称
            values: 变量值数组
            probs: 预测概率数组
            config: 配置参数字典
        """
        self.var_name = var_name
        self.config = config or QLEARNING_CONFIG
        
        # 数据清洗
        self.values, self.probs = self._clean_data(values, probs)
        
        # 计算变量范围
        self._calculate_value_range()
        
        # 初始化Q-Learning参数
        self._initialize_qlearning()
        
        # 训练历史
        self.rewards = []
        self.position_rewards = []  # 新增：只记录位置奖励
        self.optimal_thresholds = []
        self.best_state = None
        self.max_position_reward = -np.inf
        
        # 奖励标准化参数
        self._setup_reward_scaling()
        
        logger.info(f"变量 {var_name} 优化器初始化完成:")
        logger.info(f"  数据点: {len(self.values)}")
        logger.info(f"  值范围: {self.min_val:.4f} - {self.max_val:.4f}")
        logger.info(f"  离散化: {self.n_bins} 个区间")

    def _clean_data(self, values: np.ndarray, probs: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """清洗数据，移除异常值"""
        std_threshold = PROCESSING_CONFIG["outlier_std_threshold"]
        
        try:
            clean_values, clean_probs = remove_outliers(values, probs, std_threshold)
            logger.info(f"数据清洗完成: {len(clean_values)} 个有效点")
            return clean_values, clean_probs
        except ValueError as e:
            logger.error(f"变量 {self.var_name} 数据清洗失败: {e}")
            raise ValueError(f"变量 {self.var_name} 数据清洗失败: {e}")

    def _calculate_value_range(self):
        """计算变量范围和离散化参数"""
        self.min_val = np.min(self.values)
        self.max_val = np.max(self.values)
        self.value_range = self.max_val - self.min_val
        
        if self.value_range == 0:
            raise ValueError(f"变量 {self.var_name} 的值没有变化")
        
        # 区间参数
        min_interval_ratio = self.config["min_interval_ratio"]
        max_interval_ratio = self.config.get("max_interval_ratio", 0.8)
        
        self.min_interval = self.value_range * min_interval_ratio
        self.max_interval = self.value_range * max_interval_ratio
        
        # 离散化参数
        self.n_bins = self.config["n_bins"]
        self.bin_edges = np.linspace(self.min_val, self.max_val, self.n_bins + 1)
        self.bin_centers = (self.bin_edges[:-1] + self.bin_edges[1:]) / 2
        self.bin_size = self.value_range / self.n_bins
        
        # 最小和最大允许的bin数
        self.min_bins = max(1, int(self.min_interval / self.bin_size))
        self.max_bins = min(self.n_bins - 1, int(self.max_interval / self.bin_size))
        
        logger.debug(f"区间设置: min_bins={self.min_bins}, max_bins={self.max_bins}")

    def _setup_reward_scaling(self):
        """设置奖励标准化参数"""
        # 计算数据特征用于标准化
        self.total_points = len(self.values)
        self.high_prob_points = np.sum(self.probs > self.config["high_prob_threshold"])
        self.avg_prob = np.mean(self.probs)
        
        # 计算理论最大密度（用于标准化）
        self.max_possible_density = self.total_points / self.min_interval
        
        logger.debug(f"奖励标准化设置: 总点数={self.total_points}, 高概率点={self.high_prob_points}")

    def _initialize_qlearning(self):
        """初始化Q-Learning参数"""
        # Q-Learning超参数
        self.learning_rate = self.config["learning_rate"]
        self.discount_factor = self.config["discount_factor"]
        self.exploration_rate = self.config["exploration_rate"]
        self.min_exploration = self.config["min_exploration"]
        self.exploration_decay = self.config["exploration_decay"]
        self.max_steps = self.config["max_steps"]
        
        # 奖励函数参数
        self.high_prob_threshold = self.config["high_prob_threshold"]
        self.density_weight = self.config["density_weight"]
        self.high_density_weight = self.config["high_density_weight"]
        self.prob_weight = self.config["prob_weight"]
        self.coverage_weight = self.config.get("coverage_weight", 0.1)
        
        # Q表: (下边界索引, 上边界索引, 动作)
        self.q_table = np.zeros((self.n_bins, self.n_bins, 4))

    def initialize_state(self) -> Tuple[int, int]:
        """初始化状态 - 更好的初始化策略"""
        # 寻找高概率点集中的区域作为初始状态
        high_prob_mask = self.probs > self.high_prob_threshold
        
        if np.sum(high_prob_mask) > 0:
            high_prob_values = self.values[high_prob_mask]
            # 以高概率点的中位数范围为中心
            center_val = np.median(high_prob_values)
            center_bin = int((center_val - self.min_val) / self.bin_size)
            center_bin = np.clip(center_bin, 0, self.n_bins - 1)
            
            # 创建合理大小的初始区间
            initial_size = max(self.min_bins, self.n_bins // 10)
            lower_bound = max(0, center_bin - initial_size // 2)
            upper_bound = min(self.n_bins - 1, lower_bound + initial_size)
            
            if upper_bound - lower_bound < self.min_bins:
                upper_bound = min(self.n_bins - 1, lower_bound + self.min_bins)
        else:
            # 如果没有高概率点，随机初始化
            initial_size = max(self.min_bins, self.n_bins // 10)
            lower_bound = np.random.randint(0, self.n_bins - initial_size)
            upper_bound = lower_bound + initial_size
        
        return lower_bound, upper_bound

    def is_valid_interval(self, lower: int, upper: int) -> bool:
        """检查区间是否有效"""
        interval_size = upper - lower
        return self.min_bins <= interval_size <= self.max_bins

    def calculate_position_reward(self, lower: int, upper: int) -> float:
        """
        优化后的位置奖励计算
        综合考虑多个因素并进行标准化
        """
        if not self.is_valid_interval(lower, upper):
            return -np.inf
        
        # 获取区间内的点
        mask = (self.values >= self.bin_edges[lower]) & (self.values < self.bin_edges[upper + 1])
        
        if np.sum(mask) == 0:
            return -1000  # 大负数惩罚
        
        # 计算区间宽度
        interval_width = (upper - lower) * self.bin_size
        if interval_width <= 0:
            return -1000
        
        # 基础指标计算
        n_points = np.sum(mask)
        n_high_prob = np.sum(self.probs[mask] > self.high_prob_threshold)
        avg_prob = np.mean(self.probs[mask])
        
        # 密度指标（标准化）
        density = n_points / interval_width
        normalized_density = density / self.max_possible_density
        
        high_prob_density = n_high_prob / interval_width
        max_high_density = self.high_prob_points / self.min_interval
        normalized_high_density = high_prob_density / max(max_high_density, 1e-6)
        
        # 覆盖度指标（惩罚过大区间）
        coverage_ratio = interval_width / self.value_range
        coverage_penalty = 1.0 - coverage_ratio  # 区间越大惩罚越大
        
        # 概率质量指标
        prob_quality = avg_prob
        
        # 综合奖励计算
        reward = (
            self.density_weight * normalized_density +
            self.high_density_weight * normalized_high_density +
            self.prob_weight * prob_quality +
            self.coverage_weight * coverage_penalty
        )
        
        # 应用缩放因子
        if self.config.get("reward_scaling", True):
            scale_factor = self.config.get("reward_scale_factor", 1000)
            reward *= scale_factor
        
        logger.debug(f"区间[{lower},{upper}]: 密度={normalized_density:.3f}, "
                    f"高密度={normalized_high_density:.3f}, 概率={prob_quality:.3f}, "
                    f"覆盖={coverage_penalty:.3f}, 奖励={reward:.3f}")
        
        return reward

    def choose_action(self, state: Tuple[int, int]) -> int:
        """选择动作：ε-贪心策略"""
        if np.random.random() < self.exploration_rate:
            return np.random.randint(0, 4)
        else:
            lower, upper = state
            return np.argmax(self.q_table[lower, upper])

    def take_action(self, state: Tuple[int, int], action: int) -> Tuple[Tuple[int, int], float]:
        """执行动作并返回新状态"""
        lower, upper = state
        new_lower, new_upper = lower, upper
        
        if action == 0:  # 下边界左移
            new_lower = max(0, lower - 1)
        elif action == 1:  # 下边界右移
            new_lower = min(upper - self.min_bins, lower + 1)
        elif action == 2:  # 上边界左移
            new_upper = max(lower + self.min_bins, upper - 1)
        elif action == 3:  # 上边界右移
            new_upper = min(self.n_bins - 1, upper + 1)
        
        # 验证新状态
        if not self.is_valid_interval(new_lower, new_upper):
            return state, -100  # 无效动作惩罚
        
        return (new_lower, new_upper), 0

    def update_q_table(self, state: Tuple[int, int], action: int, 
                      reward: float, next_state: Tuple[int, int]):
        """更新Q表"""
        l, u = state
        nl, nu = next_state
        
        best_next_action = np.argmax(self.q_table[nl, nu])
        td_target = reward + self.discount_factor * self.q_table[nl, nu, best_next_action]
        td_error = td_target - self.q_table[l, u, action]
        self.q_table[l, u, action] += self.learning_rate * td_error

    def train(self, num_episodes: Optional[int] = None) -> None:
        """训练Q-Learning智能体"""
        num_episodes = num_episodes or self.config["num_episodes"]
        
        logger.info(f"开始训练 {self.var_name} (共 {num_episodes} 轮)...")
        
        # 用于收敛检测
        recent_rewards = []
        convergence_window = 50
        
        for episode in tqdm(range(num_episodes), desc=f"训练 {self.var_name}"):
            state = self.initialize_state()
            total_reward = 0
            episode_best_state = state
            episode_best_reward = -np.inf
            
            for step in range(self.max_steps):
                # 选择和执行动作
                action = self.choose_action(state)
                next_state, move_reward = self.take_action(state, action)
                
                # 计算位置奖励
                position_reward = self.calculate_position_reward(next_state[0], next_state[1])
                
                # 更新最佳状态
                if position_reward > episode_best_reward:
                    episode_best_state = next_state
                    episode_best_reward = position_reward
                
                # 总奖励
                reward = move_reward + position_reward
                
                # 更新Q表
                self.update_q_table(state, action, reward, next_state)
                
                state = next_state
                total_reward += reward
                
                # 早期停止条件
                if step > 10 and episode_best_reward == self.max_position_reward:
                    break
            
            # 记录结果
            self.optimal_thresholds.append(episode_best_state)
            self.position_rewards.append(episode_best_reward)
            
            # 更新全局最佳
            if episode_best_reward > self.max_position_reward:
                self.best_state = episode_best_state
                self.max_position_reward = episode_best_reward
                logger.debug(f"新的最佳状态 {episode}: {episode_best_state}, 奖励: {episode_best_reward:.3f}")
            
            # 衰减探索率
            self.exploration_rate = max(self.min_exploration,
                                      self.exploration_rate * self.exploration_decay)
            self.rewards.append(total_reward)
            
            # 收敛检测
            recent_rewards.append(episode_best_reward)
            if len(recent_rewards) > convergence_window:
                recent_rewards.pop(0)
                if len(recent_rewards) == convergence_window:
                    reward_std = np.std(recent_rewards)
                    if reward_std < abs(np.mean(recent_rewards)) * 0.01:  # 1%变化
                        logger.info(f"在第 {episode} 轮检测到收敛")
                        break
        
        logger.info(f"训练完成: 最终探索率={self.exploration_rate:.4f}, "
                   f"最佳奖励={self.max_position_reward:.3f}")

    def get_optimal_threshold(self) -> Tuple[float, float]:
        """获取最优阈值范围"""
        if self.best_state is None:
            return (self.min_val, self.max_val)
        
        lower_idx, upper_idx = self.best_state
        return (self.bin_edges[lower_idx], self.bin_edges[upper_idx + 1])

    def get_training_summary(self) -> Dict:
        """获取训练总结"""
        optimal_threshold = self.get_optimal_threshold()
        
        return {
            'variable_name': self.var_name,
            'data_points': len(self.values),
            'value_range': (float(self.min_val), float(self.max_val)),
            'optimal_threshold': optimal_threshold,
            'max_reward': float(self.max_position_reward),
            'training_episodes': len(self.rewards),
            'final_exploration_rate': self.exploration_rate,
            'high_prob_threshold': self.high_prob_threshold,
            'convergence_stability': np.std(self.position_rewards[-20:]) if len(self.position_rewards) >= 20 else np.inf
        }

    def analyze_threshold_quality(self) -> Dict:
        """分析阈值质量"""
        optimal_threshold = self.get_optimal_threshold()
        
        # 在最优区间内的点
        mask = ((self.values >= optimal_threshold[0]) & 
                (self.values <= optimal_threshold[1]))
        
        if np.sum(mask) == 0:
            return {'error': '最优区间内无数据点'}
        
        points_in_range = np.sum(mask)
        high_prob_points = np.sum(self.probs[mask] > self.high_prob_threshold)
        avg_prob_in_range = np.mean(self.probs[mask])
        
        # 区间覆盖度
        interval_width = optimal_threshold[1] - optimal_threshold[0]
        coverage_ratio = interval_width / self.value_range
        
        return {
            'points_in_optimal_range': int(points_in_range),
            'high_prob_points_in_range': int(high_prob_points),
            'avg_probability_in_range': float(avg_prob_in_range),
            'interval_width': float(interval_width),
            'coverage_ratio': float(coverage_ratio),
            'point_density': float(points_in_range / interval_width),
            'high_prob_ratio': float(high_prob_points / points_in_range) if points_in_range > 0 else 0.0
        }
    
