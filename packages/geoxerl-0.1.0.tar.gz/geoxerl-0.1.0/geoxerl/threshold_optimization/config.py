"""
阈值优化系统配置文件 - 优化版本
"""
import os
from pathlib import Path

# ===== 基础路径配置 =====
BASE_DIR = Path("D:/ginkgo/code/threshold_optimization")
DATA_DIR = BASE_DIR / "data"
RESULTS_DIR = BASE_DIR / "results"
LOG_DIR = BASE_DIR / "logs"

# 确保目录存在
for dir_path in [DATA_DIR, RESULTS_DIR, LOG_DIR]:
    dir_path.mkdir(parents=True, exist_ok=True)

# ===== 模型配置 =====
MODEL_CONFIG = {
    "model_names": ["MaxEnt", "XGBoost", "RandomForest", "LightGBM", "MLP", "GBDT_LR", "SVM"],
    "prediction_prob_column": "prediction_probability",
    "coordinate_columns": ["longitude", "latitude"],
    "position_columns": ["longitude", "latitude", "x", "y", "lon", "lat", "coord_x", "coord_y"],
    "label_columns": ["label", "presence", "absence"]
}

# ===== 数据路径配置 =====
DATA_PATHS = {
    # 您的实际文件路径
    "presence_env_csv": "D:/ginkgo/code/data_preprocessing/results/processed_data/selected/points/presence_points_with_env.csv", #存在点环境数据文件路径
    "background_env_csv": "D:/ginkgo/code/data_preprocessing/results/processed_data/selected/points/background_points_with_env.csv",  #背景点环境数据文件路径,
    "prediction_tif": "D:/CNS/GeoXAI/GeoXERL/DATA/Output/GWRF_Enhanced_20260309_152831/01_Predictions/GWRF_Enhanced.tif", #集成模型预测结果TIF文件"
    "env_raster_dir": "D:/ginkgo/code/data_preprocessing/results/preprocessed/environment/all/env_variables/original",  #原始环境变量栅格文件目录    
    # 将生成的原始值文件路径
    "presence_env_original_csv": DATA_DIR / "presence_points_with_env_original.csv",
    "background_env_original_csv": DATA_DIR / "background_points_with_env_original.csv"
}



# ===== 输出路径配置 =====
OUTPUT_PATHS = {
    "input_csv": RESULTS_DIR / "threshold_input.csv",
    "thresholds_csv": RESULTS_DIR / "optimal_thresholds.csv",
    "results_json": RESULTS_DIR / "optimization_results.json",
    "html_report": RESULTS_DIR / "threshold_report.html",
    "results_dir": RESULTS_DIR
}

# 确保输出目录存在
for key, path in OUTPUT_PATHS.items():
    if isinstance(path, Path) and key != "results_dir":
        path.parent.mkdir(parents=True, exist_ok=True)

# ===== 数据处理配置 =====
PROCESSING_CONFIG = {
    "coordinate_precision": 5,
    "knn_neighbors": 5,
    "env_var_suffix": "_original",
    "default_weight": None,
    "probability_clip_range": [0, 1],
    "outlier_std_threshold": 3,  # 放宽异常值阈值
    "exclude_columns": [
        "geometry", "longitude", "latitude", "presence", "prediction_probability"
    ]
}

# ===== 优化后的Q-Learning配置 =====
QLEARNING_CONFIG = {
    # 基础参数 - 优化
    "n_bins": 200,  # 减少区间数，避免过度离散化
    "num_episodes": 2000,  # 增加训练轮数
    "max_steps": 200,  # 减少每轮步数，提高收敛速度

    # 学习参数 - 优化
    "learning_rate": 0.05,  # 降低学习率，提高稳定性
    "discount_factor": 0.95,  # 提高折扣因子
    "exploration_rate": 0.5,  # 增加初始探索
    "min_exploration": 0.05,  # 保持最小探索
    "exploration_decay": 0.998,  # 更慢的衰减

    # 优化后的奖励函数参数
    "high_prob_threshold": 0.7,  # 降低高概率阈值
    "density_weight": 0.4,       # 点密度权重
    "high_density_weight": 0.3,  # 高概率点密度权重
    "prob_weight": 0.2,          # 平均概率权重
    "coverage_weight": 0.1,      # 覆盖度权重（新增）

    # 区间约束 - 优化
    "min_interval_ratio": 0.05,  # 减小最小区间比例
    "max_interval_ratio": 0.3,   # 新增最大区间限制
    
    # 奖励标准化参数（新增）
    "reward_scaling": True,      # 启用奖励标准化
    "reward_scale_factor": 1000, # 奖励缩放因子
}

# ===== 可视化配置 =====
VISUALIZATION_CONFIG = {
    "figure_size": (12, 8),  # 增大图像尺寸
    "dpi": 300,
    "font_family": "DejaVu Sans",
    "colors": {
        "low_prob": "#1f77b4",    # 蓝色
        "high_prob": "#d62728",   # 红色
        "threshold": "#2ca02c",   # 绿色
        "optimal_range": "#2ca02c"
    },
    "alpha": {
        "low_prob": 0.3,
        "high_prob": 0.7,
        "optimal_range": 0.2
    },
    "marker_sizes": {
        "low_prob": 8,
        "high_prob": 15,
        "max_prob": 50
    },
    "labels": {
        "probability": "Prediction Probability",
        "density": "Point Density",
        "optimal_range": "Optimal Range",
        "threshold_lower": "Lower Threshold",
        "threshold_upper": "Upper Threshold",
        "high_prob_points": "High Probability Points",
        "low_prob_points": "Low Probability Points",
        "response_curve": "Response Curve",
        "training_progress": "Training Progress"
    }
}

# ===== 日志配置 =====
LOGGING_CONFIG = {
    "level": "INFO",
    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    "file": str(LOG_DIR / "threshold_optimization.log")
}

# ===== 报告配置 =====
REPORT_CONFIG = {
    "title": "Environmental Variable Threshold Optimization Report",
    "subtitle": "Q-Learning Based Optimal Threshold Analysis",
    "encoding": "utf-8",
    "include_training_plots": True,
    "include_variable_plots": True, 
    "max_variables_summary": 15,     
    "reward_display_log_scale": True 
}

def validate_paths():
    """验证关键路径是否存在"""
    missing_paths = []

    skip_paths = [
        "presence_env_original_csv",
        "background_env_original_csv"
    ]

    for key, path in DATA_PATHS.items():
        if key in skip_paths:
            continue

        if key == "env_raster_dir":
            if not os.path.exists(path):
                missing_paths.append(f"Environmental raster directory: {path}")
            elif not any(f.endswith('.tif') for f in os.listdir(path)):
                missing_paths.append(f"No TIF files in environmental raster directory: {path}")
        else:
            if not os.path.exists(path):
                missing_paths.append(f"{key}: {path}")

    if missing_paths:
        print("Warning: The following paths do not exist or are invalid:")
        for path in missing_paths:
            print(f"  - {path}")
        return False
    return True

def get_model_names():
    """获取模型名称列表"""
    return MODEL_CONFIG["model_names"]

def get_env_var_suffix():
    """获取环境变量后缀"""
    return PROCESSING_CONFIG["env_var_suffix"]

def create_output_directories():
    """创建输出目录"""
    for path in OUTPUT_PATHS.values():
        if isinstance(path, Path):
            path.parent.mkdir(parents=True, exist_ok=True)

        