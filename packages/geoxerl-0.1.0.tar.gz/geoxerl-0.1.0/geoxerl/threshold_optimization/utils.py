"""
工具函数模块
"""
import os
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
from sklearn.impute import KNNImputer
import warnings

def setup_logging(config: Dict) -> logging.Logger:
    """设置日志配置"""
    # 确保日志目录存在
    log_file = Path(config["file"])
    log_file.parent.mkdir(parents=True, exist_ok=True)
    
    # 配置日志格式
    logging.basicConfig(
        level=getattr(logging, config["level"]),
        format=config["format"],
        handlers=[
            logging.FileHandler(config["file"], encoding='utf-8'),
            logging.StreamHandler()
        ],
        force=True  # 强制重新配置
    )
    
    logger = logging.getLogger(__name__)
    logger.info("日志系统初始化完成")
    return logger

def sanitize_probabilities(df: pd.DataFrame, model_names: List[str], 
                          clip_range: Tuple[float, float] = (0, 1)) -> None:
    """
    清洗概率值，确保在指定范围内
    
    Args:
        df: 数据框
        model_names: 模型名称列表
        clip_range: 截断范围
    """
    logger = logging.getLogger(__name__)
    logger.info("清洗概率值...")
    
    for model in model_names:
        if model not in df.columns:
            continue
            
        # 处理非数值类型
        df[model] = pd.to_numeric(df[model], errors='coerce')
        
        # 处理无限值
        df[model] = np.where(np.isinf(df[model]), np.nan, df[model])
        
        # 截断到指定范围
        df[model] = df[model].clip(clip_range[0], clip_range[1])
        
        # 验证范围
        min_val = df[model].min()
        max_val = df[model].max()
        logger.debug(f"{model}: {min_val:.4f} - {max_val:.4f}")

def validate_dataframe(df: pd.DataFrame, required_columns: List[str], 
                      name: str = "DataFrame") -> bool:
    """验证DataFrame是否包含必需的列"""
    logger = logging.getLogger(__name__)
    missing_columns = set(required_columns) - set(df.columns)
    if missing_columns:
        error_msg = f"{name} 缺少必需的列: {', '.join(missing_columns)}"
        logger.error(error_msg)
        raise ValueError(error_msg)
    logger.debug(f"{name} 列验证通过")
    return True

def normalize_weights(weights: np.ndarray, epsilon: float = 1e-6) -> np.ndarray:
    """归一化权重，确保总和为1"""
    logger = logging.getLogger(__name__)
    weights = np.clip(weights, epsilon, 1.0)
    normalized = weights / (np.sum(weights, axis=1, keepdims=True) + epsilon)
    logger.debug(f"权重归一化完成，形状: {normalized.shape}")
    return normalized

def remove_outliers(values: np.ndarray, probs: np.ndarray, 
                   std_threshold: float = 2) -> Tuple[np.ndarray, np.ndarray]:
    """
    移除异常值（基于标准差）
    
    Args:
        values: 变量值数组
        probs: 概率数组
        std_threshold: 标准差阈值
        
    Returns:
        清洗后的values和probs数组
    """
    logger = logging.getLogger(__name__)
    
    # 创建有效掩码
    valid_mask = ~np.isnan(values) & ~np.isinf(values) & ~np.isnan(probs) & ~np.isinf(probs)
    
    if not np.any(valid_mask):
        error_msg = "没有有效数据点"
        logger.error(error_msg)
        raise ValueError(error_msg)
    
    values_clean = values[valid_mask]
    probs_clean = probs[valid_mask]
    
    # 计算统计量
    mean_val = np.mean(values_clean)
    std_val = np.std(values_clean)
    
    # 定义异常值范围
    lower_bound = mean_val - std_threshold * std_val
    upper_bound = mean_val + std_threshold * std_val
    
    # 移除异常值
    inlier_mask = (values_clean >= lower_bound) & (values_clean <= upper_bound)
    
    n_outliers = len(values_clean) - np.sum(inlier_mask)
    outlier_percent = (n_outliers / len(values_clean)) * 100
    
    logger.info(f"移除 {n_outliers} 个异常值 ({outlier_percent:.1f}%)")
    
    return values_clean[inlier_mask], probs_clean[inlier_mask]

def impute_missing_values(df: pd.DataFrame, columns: List[str], 
                         n_neighbors: int = 5) -> pd.DataFrame:
    """
    使用KNN填充缺失值
    
    Args:
        df: 数据框
        columns: 需要填充的列
        n_neighbors: KNN邻居数
        
    Returns:
        填充后的数据框
    """
    logger = logging.getLogger(__name__)
    missing_mask = df[columns].isna().any(axis=1)
    
    if missing_mask.any():
        logger.info(f"使用KNN填充 {missing_mask.sum()} 个点的缺失值...")
        
        imputer = KNNImputer(n_neighbors=n_neighbors)
        df_imputed = df.copy()
        df_imputed[columns] = imputer.fit_transform(df[columns])
        
        logger.info("KNN填充完成")
        return df_imputed
    
    logger.debug("无需填充缺失值")
    return df

def ensure_numeric_columns(df: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
    """确保指定列为数值类型"""
    logger = logging.getLogger(__name__)
    df_numeric = df.copy()
    
    for col in columns:
        if col in df_numeric.columns:
            df_numeric[col] = pd.to_numeric(df_numeric[col], errors='coerce')
            logger.debug(f"列 {col} 转换为数值类型")
    
    return df_numeric

def create_coordinate_matching_columns(df: pd.DataFrame, precision: int = 5) -> pd.DataFrame:
    """创建用于坐标匹配的四舍五入列"""
    logger = logging.getLogger(__name__)
    df_matched = df.copy()
    df_matched['lon_round'] = df_matched['longitude'].round(precision)
    df_matched['lat_round'] = df_matched['latitude'].round(precision)
    logger.debug(f"创建坐标匹配列，精度: {precision}")
    return df_matched

def save_results_with_backup(data: Any, filepath: Path, backup: bool = True) -> None:
    """
    保存结果文件，支持备份
    
    Args:
        data: 要保存的数据
        filepath: 文件路径
        backup: 是否创建备份
    """
    logger = logging.getLogger(__name__)
    
    # 确保目录存在
    filepath.parent.mkdir(parents=True, exist_ok=True)
    
    # 创建备份
    if backup and filepath.exists():
        backup_path = filepath.with_suffix(f'.backup{filepath.suffix}')
        try:
            backup_path.write_bytes(filepath.read_bytes())
            logger.debug(f"创建备份文件: {backup_path}")
        except Exception as e:
            logger.warning(f"无法创建备份文件 {backup_path}: {e}")
    
    # 保存数据
    try:
        if isinstance(data, pd.DataFrame):
            data.to_csv(filepath, index=False)
            logger.info(f"DataFrame保存成功: {filepath}")
        elif isinstance(data, dict):
            import json
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=4, ensure_ascii=False)
            logger.info(f"JSON数据保存成功: {filepath}")
        else:
            raise ValueError(f"不支持的数据类型: {type(data)}")
    except Exception as e:
        logger.error(f"保存文件失败 {filepath}: {e}")
        raise

def format_number(value: float, decimals: int = 4) -> str:
    """格式化数字显示"""
    if np.isnan(value):
        return "N/A"
    return f"{value:.{decimals}f}"

def calculate_data_quality_metrics(df: pd.DataFrame, prob_column: str, 
                                  env_columns: List[str]) -> Dict[str, Any]:
    """
    计算数据质量指标
    
    Args:
        df: 数据框
        prob_column: 概率列名
        env_columns: 环境变量列名列表
        
    Returns:
        质量指标字典
    """
    logger = logging.getLogger(__name__)
    
    metrics = {
        'total_points': len(df),
        'prob_range': (df[prob_column].min(), df[prob_column].max()),
        'prob_mean': df[prob_column].mean(),
        'missing_data': {}
    }
    
    # 计算各列缺失值
    for col in env_columns:
        if col in df.columns:
            missing_count = df[col].isna().sum()
            missing_percent = (missing_count / len(df)) * 100
            metrics['missing_data'][col] = {
                'count': missing_count,
                'percent': missing_percent
            }
    
    logger.debug(f"数据质量指标计算完成: {metrics['total_points']} 个点")
    return metrics

def suppress_warnings():
    """抑制常见警告"""
    warnings.filterwarnings('ignore', category=UserWarning)
    warnings.filterwarnings('ignore', category=FutureWarning)
    warnings.filterwarnings('ignore', category=RuntimeWarning)
    warnings.filterwarnings('ignore', category=DeprecationWarning)
    
    logger = logging.getLogger(__name__)
    logger.debug("警告抑制设置完成")
    