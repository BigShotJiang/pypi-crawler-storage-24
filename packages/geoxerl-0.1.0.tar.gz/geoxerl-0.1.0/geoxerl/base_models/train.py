# train.py
# 适生区模型训练：支持命令行选择单模型、5折交叉验证、全区概率预测并输出 .tif 概率图
#
# 修复内容：
#   1. 标准化顺序 — cross_validate() 前不再对训练集做全局标准化；
#      CV 内部已在每折自行标准化（见 models.py）。
#      全局 scaler 仅在"用全量训练集再训练"阶段 fit，测试集 / 全区预测均用同一 scaler。
#   2. XGBoost scale_pos_weight — 已移至 fit() 动态计算，此处无需传参。
#   3. 模型保存一致性 — save() 统一由各子类负责；同时额外 joblib.dump wrapper
#      对象本身，供 batch_models.py 的 check_model_completion() 找到
#      {name}_model.joblib 文件，skip_existing 功能恢复正常。

import os
import argparse
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import joblib
import warnings
from sklearn.metrics import roc_curve, auc
from sklearn.preprocessing import StandardScaler
from osgeo import gdal
import sys
from .models import (
    RandomForestModel, XGBoostModel, LightGBMModel,
    SVMModel, GBDTLRModel, MLPKerasModel, MaxEntModel
)

warnings.filterwarnings('ignore')
np.random.seed(42)
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.family'] = 'SimHei'
plt.rcParams['axes.unicode_minus'] = False

MODEL_DICT = {
    "rf":      RandomForestModel,
    "maxent":  MaxEntModel,
    "xgb":     XGBoostModel,
    "lgb":     LightGBMModel,
    "svm":     SVMModel,
    "gbdtlr":  GBDTLRModel,
    "mlp":     MLPKerasModel,
}


# ──────────────────────────────────────────────────────────────────────────────
# 参数解析
# ──────────────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(description="适生区单模型训练与全区概率预测")
    parser.add_argument('--model',        type=str, required=True, choices=list(MODEL_DICT.keys()))
    parser.add_argument('--train_data',   type=str, required=True)
    parser.add_argument('--test_data',    type=str, required=True)
    parser.add_argument('--feature_cols', type=str, required=True)
    parser.add_argument('--output_dir',   type=str, required=True)
    parser.add_argument('--env_stack',    type=str, required=True)
    parser.add_argument('--output_tif',   type=str, default="probability_map.tif")
    return parser.parse_args()


# ──────────────────────────────────────────────────────────────────────────────
# 数据 I/O
# ──────────────────────────────────────────────────────────────────────────────

def load_data(train_file, test_file, feature_cols_file):
    print("加载训练集和测试集...")
    train_data   = pd.read_csv(train_file)
    test_data    = pd.read_csv(test_file)
    feature_cols = joblib.load(feature_cols_file)
    X_train = train_data[feature_cols].values
    y_train = train_data['presence'].values
    X_test  = test_data[feature_cols].values
    y_test  = test_data['presence'].values
    return X_train, y_train, X_test, y_test, feature_cols, train_data, test_data


def load_env_stack(env_stack_path, feature_cols):
    ds     = gdal.Open(env_stack_path)
    n_bands = ds.RasterCount
    n_rows  = ds.RasterYSize
    n_cols  = ds.RasterXSize
    arr = np.zeros((n_rows, n_cols, n_bands), dtype=np.float32)
    for i in range(n_bands):
        band     = ds.GetRasterBand(i + 1)
        band_arr = band.ReadAsArray()
        nodata   = band.GetNoDataValue()
        if nodata is not None:
            band_arr = np.where(band_arr == nodata, np.nan, band_arr)
        arr[:, :, i] = band_arr
    print(f"读取环境变量 stack: {env_stack_path}, shape={arr.shape}")
    return arr


# ──────────────────────────────────────────────────────────────────────────────
# 标准化
# ──────────────────────────────────────────────────────────────────────────────

def standardize(X_train, X_test, full_stack=None):
    """
    ★ 修复后的调用时机：
      此函数只在"全量训练集再训练"阶段调用（CV 阶段各折已在内部自行标准化）。
      scaler.fit 只见 X_train，不会泄露到任何验证/测试数据。
    """
    scaler      = StandardScaler()
    X_train_std = scaler.fit_transform(X_train)
    X_test_std  = scaler.transform(X_test)

    X_stack_std = None
    if full_stack is not None:
        orig_shape  = full_stack.shape
        X_flat      = full_stack.reshape(-1, orig_shape[2])
        X_flat      = np.where(np.isfinite(X_flat), X_flat, 0)
        X_stack_std = scaler.transform(X_flat)
        X_stack_std = np.where(np.isfinite(X_stack_std), X_stack_std, 0)
        X_stack_std = X_stack_std.reshape(orig_shape)

    return X_train_std, X_test_std, X_stack_std, scaler


# ──────────────────────────────────────────────────────────────────────────────
# 全区预测 & 保存 tif
# ──────────────────────────────────────────────────────────────────────────────

def predict_stack(model, X_stack_std, out_shape, batch_size=100000):
    n_features = X_stack_std.shape[2]
    flat_X     = X_stack_std.reshape(-1, n_features)
    flat_X     = np.where(np.isfinite(flat_X), flat_X, 0)
    y_pred     = np.zeros(flat_X.shape[0], dtype=np.float32)

    for start in range(0, flat_X.shape[0], batch_size):
        end = min(start + batch_size, flat_X.shape[0])
        y_pred[start:end] = model.predict_proba(flat_X[start:end])

    return y_pred.reshape(out_shape)


def save_tif(reference_tif, out_arr, out_path):
    ds     = gdal.Open(reference_tif)
    driver = gdal.GetDriverByName("GTiff")
    out_ds = driver.Create(out_path, ds.RasterXSize, ds.RasterYSize, 1, gdal.GDT_Float32)
    out_ds.SetGeoTransform(ds.GetGeoTransform())
    out_ds.SetProjection(ds.GetProjection())
    band = out_ds.GetRasterBand(1)
    band.WriteArray(out_arr)
    band.SetNoDataValue(-9999)
    out_ds.FlushCache()
    out_ds = None
    print(f"概率 .tif 已保存: {out_path}")


# ──────────────────────────────────────────────────────────────────────────────
# AUC 曲线图
# ──────────────────────────────────────────────────────────────────────────────

def save_auc_curve(y_true, y_prob, out_path, title):
    fpr, tpr, _ = roc_curve(y_true, y_prob)
    roc_auc     = auc(fpr, tpr)
    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, color='blue', lw=2, label=f"AUC = {roc_auc:.4f}")
    plt.plot([0, 1], [0, 1], 'r--', lw=1)
    plt.xlim([0, 1.02]); plt.ylim([0, 1.02])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(title)
    plt.legend(loc="lower right")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(out_path, dpi=330)
    plt.close()
    print(f"AUC 曲线图已保存: {out_path}")


# ──────────────────────────────────────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────────────────────────────────────

def main():
    args = parse_args()
    os.makedirs(args.output_dir, exist_ok=True)

    # 1. 加载原始数据（未标准化）
    X_train, y_train, X_test, y_test, feature_cols, train_data, test_data = load_data(
        args.train_data, args.test_data, args.feature_cols
    )

    # 2. 初始化模型
    if args.model == "mlp":
        model = MLPKerasModel(input_dim=len(feature_cols), cv=5)
    else:
        model = MODEL_DICT[args.model](cv=5)

    # ─────────────────────────────────────────────────────────────────────────
    # 3. 5 折交叉验证
    #    ★ 直接传入原始（未标准化）X_train。
    #      cross_validate() 内部每折自行 fit/transform，不存在泄露。
    # ─────────────────────────────────────────────────────────────────────────
    print(f"\n==> 开始5折交叉验证 [{model.name}]")
    cv_results = model.cross_validate(X_train, y_train, feature_names=feature_cols)
    print(f"{model.name} CV AUC: {cv_results['mean_auc']:.4f} ± {cv_results['std_auc']:.4f}")

    cv_auc_path = os.path.join(args.output_dir, f"{model.name}_cv_auc.csv")
    pd.DataFrame({
        "fold": list(range(1, len(cv_results["fold_scores"]) + 1)),
        "auc":  cv_results["fold_scores"]
    }).to_csv(cv_auc_path, index=False)
    print(f"CV AUC 已保存: {cv_auc_path}")

    # ─────────────────────────────────────────────────────────────────────────
    # 4. 全量训练集标准化（含全区 stack），然后用全量数据再训练一次
    #    ★ scaler.fit 仅在此处调用一次，fit 在 X_train 上，不见测试集/验证集。
    # ─────────────────────────────────────────────────────────────────────────
    print(f"\n==> 加载全区环境变量 stack，进行全局标准化...")
    env_stack = load_env_stack(args.env_stack, feature_cols)
    X_train_std, X_test_std, X_stack_std, scaler = standardize(X_train, X_test, env_stack)

    # 保存 scaler 供后续推理复用
    scaler_path = os.path.join(args.output_dir, f"{model.name}_scaler.joblib")
    joblib.dump(scaler, scaler_path)
    print(f"Scaler 已保存: {scaler_path}")

    print(f"\n==> 用全量训练集再次训练 {model.name} ...")
    model.fit(X_train_std, y_train, feature_names=feature_cols)

    # ─────────────────────────────────────────────────────────────────────────
    # 5. 保存模型
    #    ★ 修复：save() 负责子类特定格式；同时 dump wrapper 对象供
    #      batch_models.py check_model_completion() 检测用。
    # ─────────────────────────────────────────────────────────────────────────
    model.save(args.output_dir)
    # ★ 额外保存一个统一命名的 joblib 文件，batch_models 的完成检测依赖它
    wrapper_path = os.path.join(args.output_dir, f"{model.name}_model.joblib")
    joblib.dump(model, wrapper_path)
    print(f"模型已保存: {args.output_dir}")

    # ─────────────────────────────────────────────────────────────────────────
    # 6. 训练集 / 测试集预测 & AUC
    # ─────────────────────────────────────────────────────────────────────────
    train_pred_prob = model.predict_proba(X_train_std)
    test_pred_prob  = model.predict_proba(X_test_std)

    train_out = train_data.copy(); train_out['probability'] = train_pred_prob
    test_out  = test_data.copy();  test_out['probability']  = test_pred_prob

    train_out.to_csv(os.path.join(args.output_dir, f"{model.name}_train_pred.csv"), index=False)
    test_out.to_csv( os.path.join(args.output_dir, f"{model.name}_test_pred.csv"),  index=False)
    print(f"训练集/测试集预测概率已保存: {args.output_dir}")

    train_auc = auc(*roc_curve(y_train, train_pred_prob)[:2])
    test_auc  = auc(*roc_curve(y_test,  test_pred_prob)[:2])
    pd.DataFrame({"set": ["train", "test"], "auc": [train_auc, test_auc]}).to_csv(
        os.path.join(args.output_dir, f"{model.name}_train_test_auc.csv"), index=False)
    print(f"Train AUC={train_auc:.4f}  Test AUC={test_auc:.4f}")

    save_auc_curve(y_train, train_pred_prob,
                   os.path.join(args.output_dir, f"{model.name}_train_auc_curve.png"),
                   f"{model.name} Train ROC Curve")
    save_auc_curve(y_test, test_pred_prob,
                   os.path.join(args.output_dir, f"{model.name}_test_auc_curve.png"),
                   f"{model.name} Test ROC Curve")

    # ─────────────────────────────────────────────────────────────────────────
    # 7. 全区概率预测 → .tif
    # ─────────────────────────────────────────────────────────────────────────
    print(f"\n==> 全区概率预测，保存适生区概率图 .tif ...")
    prob_map    = predict_stack(model, X_stack_std, env_stack.shape[:2])
    out_tif_path = os.path.join(args.output_dir, args.output_tif)
    save_tif(args.env_stack, prob_map, out_tif_path)

    print("\n模型训练和概率预测全部完成！")


if __name__ == "__main__":
    main()


# ──────────────────────────────────────────────────────────────────────────────
# 运行示例（与原版保持一致）
# ──────────────────────────────────────────────────────────────────────────────
# RandomForestModel
# & D:/Anaconda/envs/env/python.exe d:/ginkgo/code/base_models/train.py --model rf --train_data D:\ginkgo\data\processed\黄花刺茄数据\dataset\train_data.csv --test_data D:\ginkgo\data\processed\黄花刺茄数据\dataset\test_data.csv --feature_cols D:\ginkgo\data\processed\黄花刺茄数据\env_variables\feature_cols.joblib --output_dir D:\ginkgo\results\random_forest --env_stack D:\ginkgo\data\processed\黄花刺茄数据\env_variables\selected_stack.tif --output_tif rf_probability_map.tif
