"""
批次模型训练脚本
支持选择特定模型或训练所有模型，并行训练提高效率
"""

import os
import argparse
import subprocess
import time
import pandas as pd
import json
from datetime import datetime
from pathlib import Path
import concurrent.futures
from typing import List, Dict, Optional

# 模型配置
MODEL_CONFIG = {
    "rf": {
        "name": "RandomForest",
        "description": "随机森林模型",
        "output_dir_suffix": "random_forest",
        "output_tif": "rf_probability_map.tif"
    },
    "maxent": {
        "name": "MaxEnt",
        "description": "最大熵模型", 
        "output_dir_suffix": "maxent",
        "output_tif": "maxent_probability_map.tif"
    },
    "xgb": {
        "name": "XGBoost",
        "description": "XGBoost梯度提升模型",
        "output_dir_suffix": "xgboost", 
        "output_tif": "xgb_probability_map.tif"
    },
    "lgb": {
        "name": "LightGBM",
        "description": "LightGBM梯度提升模型",
        "output_dir_suffix": "lightgbm",
        "output_tif": "lgb_probability_map.tif"
    },
    "svm": {
        "name": "SVM",
        "description": "支持向量机模型",
        "output_dir_suffix": "svm",
        "output_tif": "svm_probability_map.tif"
    },
    "mlp": {
        "name": "MLP",
        "description": "多层感知机神经网络",
        "output_dir_suffix": "mlp_keras",
        "output_tif": "mlp_probability_map.tif"
    },
    "gbdtlr": {
        "name": "GBDT_LR",
        "description": "GBDT+逻辑回归组合模型",
        "output_dir_suffix": "gbdt_lr",
        "output_tif": "gbdtlr_probability_map.tif"
    }
}

def parse_args():
    parser = argparse.ArgumentParser(
        description="批次模型训练",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 训练所有模型
  & D:\Anaconda\envs\env\python.exe D:\ginkgo\code\\base_models\\batch_models.py --all --base_config D:\ginkgo\code\\base_models\config.json
  & D:\Program\DevTools\anaconda3\envs\EL2\python.exe D:\ginkgo\code\\base_models\\batch_models.py --all --base_config D:\ginkgo\code\\base_models\config.json
  # 训练指定模型
  python batch_train.py --models rf xgb lgb --base_config D:\ginkgo\code\\base_models\config.json
  
  # 并行训练（适用于多核CPU）
  python batch_train.py --all --parallel --max_workers 3
  
  # 跳过已完成的模型
  python batch_train.py --all --skip_existing
        """
    )
    
    # 模型选择
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--all', action='store_true', help='训练所有模型')
    group.add_argument('--models', nargs='+', choices=list(MODEL_CONFIG.keys()),
                      help='选择要训练的模型')
    
    # 配置文件
    parser.add_argument('--base_config', type=str, required=False,
                       help='基础配置JSON文件路径')
    
    # 训练选项
    parser.add_argument(
        '--train_script',
        type=str,
        default=None,
        help='单模型训练脚本路径；省略则使用 python -m geoxerl.base_models.train',
    )
    parser.add_argument('--python_path', type=str, default='python',
                       help='Python解释器路径')
    
    # 并行选项
    parser.add_argument('--parallel', action='store_true',
                       help='并行训练模型')
    parser.add_argument('--max_workers', type=int, default=2,
                       help='并行训练的最大进程数')
    
    # 其他选项
    parser.add_argument('--skip_existing', action='store_true',
                       help='跳过已完成的模型')
    parser.add_argument('--dry_run', action='store_true',
                       help='仅显示训练命令，不实际执行')
    parser.add_argument('--log_level', choices=['DEBUG', 'INFO', 'WARNING'], 
                       default='INFO', help='日志级别')
    
    return parser.parse_args()

def load_config(config_path: str) -> Dict:
    """加载基础配置"""
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        # 验证必需的配置项
        required_keys = ['train_data', 'test_data', 'feature_cols', 'base_output_dir', 'env_stack']
        missing_keys = [key for key in required_keys if key not in config]
        if missing_keys:
            raise ValueError(f"配置文件缺少必需的键: {missing_keys}")
        
        return config
        
    except Exception as e:
        print(f" 配置文件加载失败: {e}")
        raise

def validate_paths(config: Dict) -> bool:
    """验证输入文件路径"""
    paths_to_check = {
        'train_data': config['train_data'],
        'test_data': config['test_data'], 
        'feature_cols': config['feature_cols'],
        'env_stack': config['env_stack']
    }
    
    missing_paths = []
    for name, path in paths_to_check.items():
        if not os.path.exists(path):
            missing_paths.append(f"{name}: {path}")
    
    if missing_paths:
        print(" 以下文件不存在:")
        for path in missing_paths:
            print(f"   - {path}")
        return False
    
    return True

def check_model_completion(output_dir: str, model_key: str) -> bool:
    """检查模型是否已完成训练"""
    expected_files = [
        f"{MODEL_CONFIG[model_key]['name']}_model.joblib",
        f"{MODEL_CONFIG[model_key]['name']}_cv_auc.csv",
        f"{MODEL_CONFIG[model_key]['name']}_train_test_auc.csv",
        MODEL_CONFIG[model_key]['output_tif']
    ]
    
    return all(os.path.exists(os.path.join(output_dir, f)) for f in expected_files)

def build_train_command(model_key: str, config: Dict, args) -> List[str]:
    """构建单个模型的训练命令"""
    model_output_dir = os.path.join(
        config['base_output_dir'], 
        MODEL_CONFIG[model_key]['output_dir_suffix']
    )
    
    if args.train_script:
        launcher = [args.python_path, args.train_script]
    else:
        launcher = [args.python_path, "-m", "geoxerl.base_models.train"]
    cmd = launcher + [
        '--model', model_key,
        '--train_data', config['train_data'],
        '--test_data', config['test_data'],
        '--feature_cols', config['feature_cols'],
        '--output_dir', model_output_dir,
        '--env_stack', config['env_stack'],
        '--output_tif', MODEL_CONFIG[model_key]['output_tif']
    ]
    
    return cmd, model_output_dir

def run_single_model(model_key: str, config: Dict, args, log_file: str = None) -> Dict:
    """训练单个模型"""
    start_time = time.time()
    model_name = MODEL_CONFIG[model_key]['name']
    
    try:
        # 构建命令
        cmd, output_dir = build_train_command(model_key, config, args)
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        print(f" 开始训练 {model_name}...")
        print(f"   输出目录: {output_dir}")
        
        if args.dry_run:
            print(f"   命令: {' '.join(cmd)}")
            return {
                'model': model_key,
                'status': 'dry_run',
                'duration': 0,
                'output_dir': output_dir
            }
        
        # 执行训练
        if log_file:
            with open(log_file, 'w', encoding='utf-8') as f:
                result = subprocess.run(cmd, stdout=f, stderr=subprocess.STDOUT, 
                                      text=True, check=True)
        else:
            result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        
        duration = time.time() - start_time
        
        # 验证输出
        if check_model_completion(output_dir, model_key):
            print(f" {model_name} 训练完成! 耗时: {duration:.1f}秒")
            return {
                'model': model_key,
                'status': 'success',
                'duration': duration,
                'output_dir': output_dir
            }
        else:
            print(f" {model_name} 训练完成")
            return {
                'model': model_key,
                'status': 'incomplete',
                'duration': duration,
                'output_dir': output_dir
            }
            
    except subprocess.CalledProcessError as e:
        duration = time.time() - start_time
        print(f" {model_name} 训练失败!")
        if hasattr(e, 'stdout') and e.stdout:
            print(f"   错误输出: {e.stdout}")
        if hasattr(e, 'stderr') and e.stderr:
            print(f"   错误信息: {e.stderr}")
        
        return {
            'model': model_key,
            'status': 'failed',
            'duration': duration,
            'error': str(e),
            'output_dir': output_dir
        }
    
    except Exception as e:
        duration = time.time() - start_time
        print(f" {model_name} 训练出现异常: {e}")
        return {
            'model': model_key,
            'status': 'error', 
            'duration': duration,
            'error': str(e),
            'output_dir': output_dir if 'output_dir' in locals() else None
        }

def run_parallel_training(models_to_train: List[str], config: Dict, args) -> List[Dict]:
    """并行训练多个模型"""
    print(f" 并行训练 {len(models_to_train)} 个模型 (最大并发: {args.max_workers})")
    
    # 创建日志目录
    log_dir = os.path.join(config['base_output_dir'], 'training_logs')
    os.makedirs(log_dir, exist_ok=True)
    
    results = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.max_workers) as executor:
        # 提交任务
        futures = {}
        for model_key in models_to_train:
            log_file = os.path.join(log_dir, f"{model_key}_training.log")
            future = executor.submit(run_single_model, model_key, config, args, log_file)
            futures[future] = model_key
        
        # 收集结果
        for future in concurrent.futures.as_completed(futures):
            model_key = futures[future]
            try:
                result = future.result()
                results.append(result)
            except Exception as e:
                print(f" 模型 {model_key} 并行训练异常: {e}")
                results.append({
                    'model': model_key,
                    'status': 'parallel_error',
                    'duration': 0,
                    'error': str(e)
                })
    
    return results

def run_sequential_training(models_to_train: List[str], config: Dict, args) -> List[Dict]:
    """顺序训练多个模型"""
    print(f" 顺序训练 {len(models_to_train)} 个模型")
    
    results = []
    for i, model_key in enumerate(models_to_train, 1):
        print(f"\n 进度: {i}/{len(models_to_train)}")
        result = run_single_model(model_key, config, args)
        results.append(result)
        
        # 简短间隔，避免资源冲突
        if i < len(models_to_train):
            time.sleep(2)
    
    return results

def save_training_summary(results: List[Dict], config: Dict) -> None:
    """保存训练摘要"""
    summary_data = []
    total_duration = 0
    
    for result in results:
        model_key = result['model']
        model_config = MODEL_CONFIG[model_key]
        
        summary_data.append({
            'model_key': model_key,
            'model_name': model_config['name'],
            'description': model_config['description'],
            'status': result['status'],
            'duration_seconds': result.get('duration', 0),
            'duration_minutes': result.get('duration', 0) / 60,
            'output_dir': result.get('output_dir', ''),
            'error': result.get('error', ''),
            'timestamp': datetime.now().isoformat()
        })
        
        if result['status'] == 'success':
            total_duration += result.get('duration', 0)
    
    # 保存CSV摘要
    summary_df = pd.DataFrame(summary_data)
    summary_path = os.path.join(config['base_output_dir'], 'training_summary.csv')
    summary_df.to_csv(summary_path, index=False, encoding='utf-8')
    
    # 保存JSON详细信息
    detailed_summary = {
        'training_date': datetime.now().isoformat(),
        'total_models': len(results),
        'successful_models': len([r for r in results if r['status'] == 'success']),
        'failed_models': len([r for r in results if r['status'] in ['failed', 'error']]),
        'total_training_time_seconds': total_duration,
        'total_training_time_minutes': total_duration / 60,
        'model_results': results,
        'config_used': config
    }
    
    json_path = os.path.join(config['base_output_dir'], 'training_summary.json')
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(detailed_summary, f, indent=2, ensure_ascii=False)
    
    print(f"\n 训练摘要已保存:")
    print(f"   - CSV: {summary_path}")
    print(f"   - JSON: {json_path}")

def print_final_summary(results: List[Dict]) -> None:
    """打印最终摘要"""
    successful = [r for r in results if r['status'] == 'success']
    failed = [r for r in results if r['status'] in ['failed', 'error', 'parallel_error']]
    incomplete = [r for r in results if r['status'] == 'incomplete']
    
    print("\n" + "="*80)
    print("                   批次训练完成")
    print("="*80)
    print(f" 总体统计:")
    print(f"   - 总模型数: {len(results)}")
    print(f"   - 成功训练: {len(successful)}")
    print(f"   - 训练失败: {len(failed)}")
    print(f"   - 输出不完整: {len(incomplete)}")
    
    if successful:
        total_time = sum(r['duration'] for r in successful)
        print(f"   - 总训练时间: {total_time:.1f}秒 ({total_time/60:.1f}分钟)")
        print(f"\n 成功训练的模型:")
        for result in successful:
            model_name = MODEL_CONFIG[result['model']]['name']
            print(f"   - {model_name}: {result['duration']:.1f}秒")
    
    if failed:
        print(f"\n 失败的模型:")
        for result in failed:
            model_name = MODEL_CONFIG[result['model']]['name']
            print(f"   - {model_name}: {result.get('error', '未知错误')}")
    
    print("="*80)

def main():
    args = parse_args()
    
    print("="*80)
    print("           批次模型训练")
    print("="*80)
    print(f"训练时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    # 1. 加载配置
    print(f"\n 加载配置文件: {args.base_config}")
    config = load_config(args.base_config)
    
    # 2. 验证路径
    print("\n 验证输入文件...")
    if not validate_paths(config):
        return 1
    print(" 所有输入文件验证通过")
    
    # 3. 确定要训练的模型
    if args.all:
        models_to_train = list(MODEL_CONFIG.keys())
        print(f"\n 将训练所有 {len(models_to_train)} 个模型")
    else:
        models_to_train = args.models
        print(f"\n 将训练指定的 {len(models_to_train)} 个模型: {', '.join(models_to_train)}")
    
    # 4. 检查已完成的模型
    if args.skip_existing:
        print("\n 检查已完成的模型...")
        remaining_models = []
        for model_key in models_to_train:
            output_dir = os.path.join(
                config['base_output_dir'],
                MODEL_CONFIG[model_key]['output_dir_suffix']
            )
            if check_model_completion(output_dir, model_key):
                print(f"   ⏭ 跳过 {MODEL_CONFIG[model_key]['name']} (已完成)")
            else:
                remaining_models.append(model_key)
        
        models_to_train = remaining_models
        if not models_to_train:
            print(" 所有模型都已完成训练!")
            return 0
        print(f"    需要训练 {len(models_to_train)} 个模型")
    
    # 5. 显示训练计划
    print(f"\n 训练计划:")
    for i, model_key in enumerate(models_to_train, 1):
        model_config = MODEL_CONFIG[model_key]
        print(f"   {i}. {model_config['name']} - {model_config['description']}")
    
    # 确认开始训练
    if not args.dry_run:
        print(f"\n 训练模式: {'并行' if args.parallel else '顺序'}")
        if args.parallel:
            print(f"   最大并发进程: {args.max_workers}")
    
    # 6. 创建输出目录
    os.makedirs(config['base_output_dir'], exist_ok=True)
    
    # 7. 开始训练
    start_time = time.time()
    
    if args.parallel and len(models_to_train) > 1:
        results = run_parallel_training(models_to_train, config, args)
    else:
        results = run_sequential_training(models_to_train, config, args)
    
    total_time = time.time() - start_time
    
    # 8. 保存和显示结果
    if not args.dry_run:
        save_training_summary(results, config)
    
    print_final_summary(results)
    print(f"\n⏱ 总耗时: {total_time:.1f}秒 ({total_time/60:.1f}分钟)")
    
    # 返回退出码
    failed_count = len([r for r in results if r['status'] in ['failed', 'error']])
    return 1 if failed_count > 0 else 0

if __name__ == "__main__":
    exit(main())