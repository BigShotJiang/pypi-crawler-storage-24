"""
适生区分布模型库
包含所有基础模型定义，5折交叉验证

修复内容：
  1. BaseModel.cross_validate — 每折内部独立 fit StandardScaler，消除数据泄露
  2. RandomForestModel        — max_depth=None、n_estimators=200、min_samples_leaf=2
  3. XGBoostModel             — max_depth=5、n_estimators=200；scale_pos_weight 在 fit() 动态计算
  4. LightGBMModel            — load() 改用 joblib 保存/加载 LGBMClassifier，修复 Booster 类型错误
  5. MLPKerasModel            — fit() 开头重建模型权重；重写 cross_validate() 避免折间权重累积
  6. GBDTLRModel              — 叶节点编码改用 OneHotEncoder 后再接 LR
"""

import os
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.svm import SVC
from sklearn.ensemble import GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import KFold
from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler, OneHotEncoder
import xgboost as xgb
import lightgbm as lgb
import joblib
import matplotlib.pyplot as plt
import tensorflow as tf
from keras.models import Sequential, load_model
from keras.layers import Dense, Dropout, BatchNormalization
from keras.optimizers import Adam
from keras.callbacks import EarlyStopping, ReduceLROnPlateau


# ──────────────────────────────────────────────────────────────────────────────
# 基类
# ──────────────────────────────────────────────────────────────────────────────

class BaseModel:
    """所有模型的基类，包含带内部标准化的 K 折交叉验证"""

    def __init__(self, name="base_model", cv=5, random_state=42):
        self.name = name
        self.model = None
        self.cv = cv
        self.random_state = random_state
        self.cv_results = None
        self.feature_importances = None

    def fit(self, X, y, feature_names=None):
        raise NotImplementedError

    def cross_validate(self, X, y, feature_names=None):
        """
        K 折交叉验证。
        ★ 修复：每折内部独立 fit StandardScaler，防止验证集信息泄露到 scaler。
        """
        kf = KFold(n_splits=self.cv, shuffle=True, random_state=self.random_state)
        cv_scores = []
        y_pred_cv = np.zeros_like(y, dtype=float)

        print(f"开始进行{self.cv}折交叉验证 [{self.name}]...")

        for fold, (train_idx, val_idx) in enumerate(kf.split(X)):
            X_tr, X_val = X[train_idx], X[val_idx]
            y_tr, y_val = y[train_idx], y[val_idx]

            # ★ 每折独立标准化，scaler 只见训练折，不见验证折
            scaler = StandardScaler()
            X_tr  = scaler.fit_transform(X_tr)
            X_val = scaler.transform(X_val)

            print(f"  训练折 {fold+1}/{self.cv}")
            self.fit(X_tr, y_tr, feature_names)

            y_pred = self.predict_proba(X_val)
            y_pred_cv[val_idx] = y_pred

            score = roc_auc_score(y_val, y_pred)
            cv_scores.append(score)
            print(f"  折 {fold+1} AUC: {score:.4f}")

        mean_auc = np.mean(cv_scores)
        std_auc  = np.std(cv_scores)

        self.cv_results = {
            'mean_auc':       mean_auc,
            'std_auc':        std_auc,
            'fold_scores':    cv_scores,
            'cv_predictions': y_pred_cv
        }

        print(f"交叉验证完成 - 平均AUC: {mean_auc:.4f} ± {std_auc:.4f}")
        return self.cv_results

    def predict_proba(self, X):
        raise NotImplementedError

    def save(self, path):
        raise NotImplementedError

    def load(self, path):
        raise NotImplementedError

    def get_feature_importance(self, feature_names=None):
        if self.feature_importances is None:
            return None
        if feature_names is not None and len(feature_names) == len(self.feature_importances):
            importance_dict = dict(zip(feature_names, self.feature_importances))
            return dict(sorted(importance_dict.items(), key=lambda x: x[1], reverse=True))
        return self.feature_importances


# ──────────────────────────────────────────────────────────────────────────────
# MaxEnt（Logistic Regression 近似）
# ──────────────────────────────────────────────────────────────────────────────

class MaxEntModel(BaseModel):
    """最大熵模型（Logistic Regression 近似）"""

    def __init__(self, cv=5, random_state=42):
        super().__init__(name="maxent", cv=cv, random_state=random_state)
        self.model = LogisticRegression(
            solver="lbfgs",
            penalty="l2",
            max_iter=1000,
            class_weight="balanced",
            random_state=random_state
        )

    def fit(self, X, y, feature_names=None):
        self.model.fit(X, y)
        if hasattr(self.model, 'coef_'):
            self.feature_importances = np.abs(self.model.coef_).flatten()
        return self

    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        joblib.dump(self.model, f"{path}/{self.name}.joblib")

    def load(self, path):
        self.model = joblib.load(f"{path}/{self.name}.joblib")
        if hasattr(self.model, 'coef_'):
            self.feature_importances = np.abs(self.model.coef_).flatten()
        return self


# ──────────────────────────────────────────────────────────────────────────────
# RandomForest
# ──────────────────────────────────────────────────────────────────────────────

class RandomForestModel(BaseModel):
    """随机森林模型

    ★ 修复：
      - max_depth: 5  →  None（不限深度，让树充分生长）
      - n_estimators: 50  →  200
      - 新增 min_samples_leaf=2 防止过拟合
    """

    def __init__(self, n_estimators=200, max_depth=None, min_samples_leaf=2,
                 cv=5, random_state=42):
        super().__init__(name="random_forest", cv=cv, random_state=random_state)
        self.model = RandomForestClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            min_samples_leaf=min_samples_leaf,
            random_state=random_state,
            n_jobs=-1,
            class_weight='balanced'
        )

    def fit(self, X, y, feature_names=None):
        self.model.fit(X, y)
        self.feature_importances = self.model.feature_importances_
        return self

    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        joblib.dump(self.model, f"{path}/{self.name}.joblib")

    def load(self, path):
        self.model = joblib.load(f"{path}/{self.name}.joblib")
        if hasattr(self.model, 'feature_importances_'):
            self.feature_importances = self.model.feature_importances_
        return self


# ──────────────────────────────────────────────────────────────────────────────
# XGBoost
# ──────────────────────────────────────────────────────────────────────────────

class XGBoostModel(BaseModel):
    """XGBoost 模型

    ★ 修复：
      - max_depth: 3  →  5
      - n_estimators: 50  →  200
      - scale_pos_weight: 硬编码 10  →  在 fit() 中根据实际样本比动态计算
    """

    def __init__(self, learning_rate=0.05, max_depth=5, n_estimators=200,
                 cv=5, random_state=42):
        super().__init__(name="xgboost", cv=cv, random_state=random_state)
        self._learning_rate  = learning_rate
        self._max_depth      = max_depth
        self._n_estimators   = n_estimators
        # model 在 fit() 中实例化，因为 scale_pos_weight 需要运行时数据
        self.model = None

    def _build_model(self, scale_pos_weight):
        return xgb.XGBClassifier(
            learning_rate=self._learning_rate,
            max_depth=self._max_depth,
            n_estimators=self._n_estimators,
            random_state=self.random_state,
            eval_metric='auc',
            scale_pos_weight=scale_pos_weight,   # ★ 动态计算
            tree_method='hist',
            use_label_encoder=False,
        )

    def fit(self, X, y, feature_names=None):
        # ★ 根据当前折的样本比例动态计算权重
        n_neg = np.sum(y == 0)
        n_pos = np.sum(y == 1)
        spw   = n_neg / n_pos if n_pos > 0 else 1.0
        self.model = self._build_model(scale_pos_weight=spw)

        self.model.fit(X, y, eval_set=[(X, y)], verbose=False)
        self.feature_importances = self.model.feature_importances_
        return self

    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        self.model.save_model(f"{path}/{self.name}.json")

    def load(self, path):
        # 加载时 scale_pos_weight 已固化在模型文件中，用占位值即可
        self.model = self._build_model(scale_pos_weight=1.0)
        self.model.load_model(f"{path}/{self.name}.json")
        if hasattr(self.model, 'feature_importances_'):
            self.feature_importances = self.model.feature_importances_
        return self


# ──────────────────────────────────────────────────────────────────────────────
# LightGBM
# ──────────────────────────────────────────────────────────────────────────────

class LightGBMModel(BaseModel):
    """LightGBM 模型

    ★ 修复：
      - load() 原先加载为 lgb.Booster，没有 predict_proba()，推理会崩溃。
        改为用 joblib 保存/加载 LGBMClassifier 对象，保持类型一致。
    """

    def __init__(self, learning_rate=0.05, max_depth=6, n_estimators=200,
                 cv=5, random_state=42):
        super().__init__(name="lightgbm", cv=cv, random_state=random_state)
        self.model = lgb.LGBMClassifier(
            learning_rate=learning_rate,
            max_depth=max_depth,
            n_estimators=n_estimators,
            random_state=random_state,
            class_weight='balanced',
            verbose=-1
        )

    def fit(self, X, y, feature_names=None):
        if feature_names is not None:
            self.model.fit(X, y,
                           feature_name=list(feature_names),
                           eval_set=[(X, y)],
                           eval_names=['train'])
        else:
            self.model.fit(X, y,
                           eval_set=[(X, y)],
                           eval_names=['train'])
        self.feature_importances = self.model.feature_importances_
        return self

    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        # ★ 用 joblib 保存整个 LGBMClassifier，load() 后类型不变
        joblib.dump(self.model, f"{path}/{self.name}.joblib")
        joblib.dump(self.feature_importances, f"{path}/{self.name}_importance.joblib")

    def load(self, path):
        # ★ 修复：加载回来仍是 LGBMClassifier，predict_proba() 可正常使用
        self.model = joblib.load(f"{path}/{self.name}.joblib")
        try:
            self.feature_importances = joblib.load(f"{path}/{self.name}_importance.joblib")
        except Exception:
            pass
        return self


# ──────────────────────────────────────────────────────────────────────────────
# SVM
# ──────────────────────────────────────────────────────────────────────────────

class SVMModel(BaseModel):
    """SVM 模型（RBF 核）"""

    def __init__(self, C=1.0, gamma='scale', cv=5, random_state=42):
        super().__init__(name="svm", cv=cv, random_state=random_state)
        self.model = SVC(
            C=C,
            gamma=gamma,
            kernel='rbf',
            probability=True,
            random_state=random_state,
            class_weight='balanced'
        )

    def fit(self, X, y, feature_names=None):
        self.model.fit(X, y)
        return self

    def predict_proba(self, X):
        return self.model.predict_proba(X)[:, 1]

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        joblib.dump(self.model, f"{path}/{self.name}.joblib")

    def load(self, path):
        self.model = joblib.load(f"{path}/{self.name}.joblib")
        return self


# ──────────────────────────────────────────────────────────────────────────────
# MLP（Keras）
# ──────────────────────────────────────────────────────────────────────────────

class MLPKerasModel(BaseModel):
    """深度学习模型 — Keras 实现的多层感知机

    ★ 修复：
      1. fit() 开头调用 self.model = self._build_model() 重置权重，
         防止折间权重累积。
      2. 重写 cross_validate()：每折独立标准化 + 重建模型，结果才可信。
      3. EarlyStopping monitor 改为更稳定的 'val_loss'（'val_auc' 在部分
         Keras 版本中 key 不统一，容易报 warning 或静默失效）。
    """

    def __init__(self, input_dim, hidden_layers=None, dropout_rates=None,
                 learning_rate=0.001, cv=5, random_state=42):
        super().__init__(name="mlp_keras", cv=cv, random_state=random_state)

        try:
            tf.random.set_seed(random_state)
        except Exception:
            pass
        np.random.seed(random_state)

        self.input_dim     = input_dim
        self.hidden_layers = hidden_layers  if hidden_layers  is not None else [64, 32]
        self.dropout_rates = dropout_rates  if dropout_rates  is not None else [0.2, 0.1]
        self.learning_rate = learning_rate

        self.model = self._build_model()

    def _build_model(self):
        model = Sequential()
        model.add(Dense(self.hidden_layers[0], input_dim=self.input_dim, activation='relu'))
        model.add(BatchNormalization())
        model.add(Dropout(self.dropout_rates[0]))

        for i in range(1, len(self.hidden_layers)):
            model.add(Dense(self.hidden_layers[i], activation='relu'))
            model.add(BatchNormalization())
            if i < len(self.dropout_rates):
                model.add(Dropout(self.dropout_rates[i]))

        model.add(Dense(1, activation='sigmoid'))

        model.compile(
            optimizer=Adam(learning_rate=self.learning_rate),
            loss='binary_crossentropy',
            metrics=['accuracy', tf.keras.metrics.AUC(name='auc')]
        )
        return model

    def fit(self, X, y, feature_names=None,
            validation_split=0.2, epochs=100, batch_size=64):
        # ★ 每次 fit 前重建模型，保证权重从零开始（交叉验证折间隔离）
        self.model = self._build_model()

        callbacks = [
            # ★ monitor 改为 val_loss，跨 Keras 版本更稳定
            EarlyStopping(monitor='val_loss', patience=10,
                          mode='min', restore_best_weights=True),
            ReduceLROnPlateau(monitor='val_loss', factor=0.2,
                              patience=5, min_lr=1e-5)
        ]

        self.history = self.model.fit(
            X, y,
            validation_split=validation_split,
            epochs=epochs,
            batch_size=batch_size,
            callbacks=callbacks,
            verbose=0          # 训练时静默，减少日志刷屏
        )
        return self

    def predict_proba(self, X):
        return self.model.predict(X, verbose=0).flatten()

    def cross_validate(self, X, y, feature_names=None):
        """
        ★ 重写：每折独立标准化 + 重建模型，彻底消除折间泄露和权重累积。
        """
        kf = KFold(n_splits=self.cv, shuffle=True, random_state=self.random_state)
        cv_scores = []
        y_pred_cv = np.zeros_like(y, dtype=float)

        print(f"开始进行{self.cv}折交叉验证 [mlp_keras]...")

        for fold, (train_idx, val_idx) in enumerate(kf.split(X)):
            X_tr, X_val = X[train_idx], X[val_idx]
            y_tr, y_val = y[train_idx], y[val_idx]

            # 每折独立标准化
            scaler = StandardScaler()
            X_tr  = scaler.fit_transform(X_tr)
            X_val = scaler.transform(X_val)

            print(f"  训练折 {fold+1}/{self.cv}")
            self.fit(X_tr, y_tr)   # fit() 内部已重建模型

            y_pred = self.predict_proba(X_val)
            y_pred_cv[val_idx] = y_pred

            score = roc_auc_score(y_val, y_pred)
            cv_scores.append(score)
            print(f"  折 {fold+1} AUC: {score:.4f}")

        mean_auc = np.mean(cv_scores)
        std_auc  = np.std(cv_scores)

        self.cv_results = {
            'mean_auc':       mean_auc,
            'std_auc':        std_auc,
            'fold_scores':    cv_scores,
            'cv_predictions': y_pred_cv
        }

        print(f"交叉验证完成 - 平均AUC: {mean_auc:.4f} ± {std_auc:.4f}")
        return self.cv_results

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        self.model.save(f"{path}/{self.name}.h5")

    def load(self, path):
        self.model = load_model(f"{path}/{self.name}.h5")
        return self


# ──────────────────────────────────────────────────────────────────────────────
# GBDT + LR
# ──────────────────────────────────────────────────────────────────────────────

class GBDTLRModel(BaseModel):
    """GBDT + LR 混合模型

    ★ 修复：
      - 叶节点编码（整数索引）改用 OneHotEncoder 转为稀疏二值特征后再接 LR。
        原来直接用整数索引会引入不合理的序数关系，导致 LR 精度打折。
    """

    def __init__(self, n_estimators=200, max_depth=6, learning_rate=0.1,
                 cv=5, random_state=42):
        super().__init__(name="gbdt_lr", cv=cv, random_state=random_state)
        self.gbdt = GradientBoostingClassifier(
            n_estimators=n_estimators,
            max_depth=max_depth,
            learning_rate=learning_rate,
            random_state=random_state
        )
        self.lr = LogisticRegression(
            random_state=random_state,
            class_weight='balanced',
            max_iter=1000,
            solver='lbfgs'
        )
        # ★ 新增：叶节点 OneHotEncoder
        self.ohe = OneHotEncoder(sparse_output=True, handle_unknown='ignore')

    def fit(self, X, y, feature_names=None):
        print(f"训练GBDT+LR模型 "
              f"(n_estimators={self.gbdt.n_estimators}, max_depth={self.gbdt.max_depth})")

        # 1. 训练 GBDT
        self.gbdt.fit(X, y)

        # 2. 取叶节点索引  shape: (n_samples, n_estimators)
        leaf_idx = self.gbdt.apply(X)[:, :, 0]

        # 3. ★ OneHot 编码，消除序数关系
        leaf_ohe = self.ohe.fit_transform(leaf_idx)

        # 4. 用 OHE 特征训练 LR
        self.lr.fit(leaf_ohe, y)

        self.feature_importances = self.gbdt.feature_importances_
        return self

    def predict_proba(self, X):
        leaf_idx = self.gbdt.apply(X)[:, :, 0]
        leaf_ohe = self.ohe.transform(leaf_idx)          # ★ transform（不 fit）
        return self.lr.predict_proba(leaf_ohe)[:, 1]

    def save(self, path):
        os.makedirs(path, exist_ok=True)
        joblib.dump({'gbdt': self.gbdt, 'lr': self.lr, 'ohe': self.ohe},
                    f"{path}/{self.name}.joblib")

    def load(self, path):
        ckpt = joblib.load(f"{path}/{self.name}.joblib")
        self.gbdt = ckpt['gbdt']
        self.lr   = ckpt['lr']
        self.ohe  = ckpt['ohe']
        if hasattr(self.gbdt, 'feature_importances_'):
            self.feature_importances = self.gbdt.feature_importances_
        return self


# ──────────────────────────────────────────────────────────────────────────────
# 快速冒烟测试
# ──────────────────────────────────────────────────────────────────────────────

def main():
    print("=== 模型冒烟测试 ===")
    np.random.seed(42)
    n_samples, n_features = 400, 20
    X = np.random.randn(n_samples, n_features)
    y = np.random.randint(0, 2, n_samples)
    feature_names = [f"var_{i+1}" for i in range(n_features)]
    X_tr, X_te = X[:320], X[320:]
    y_tr, y_te = y[:320], y[320:]

    models = [
        MaxEntModel(),
        RandomForestModel(n_estimators=20),
        XGBoostModel(n_estimators=20),
        LightGBMModel(n_estimators=20),
        SVMModel(),
        GBDTLRModel(n_estimators=20),
    ]

    for m in models:
        m.fit(X_tr, y_tr, feature_names)
        prob = m.predict_proba(X_te)
        auc  = __import__('sklearn.metrics', fromlist=['roc_auc_score']).roc_auc_score(y_te, prob)
        print(f"  {m.name:<18} predict_proba shape={prob.shape}  AUC={auc:.4f}")

    try:
        mlp = MLPKerasModel(input_dim=n_features, hidden_layers=[16, 8])
        mlp.fit(X_tr, y_tr, epochs=5, batch_size=32)
        prob = mlp.predict_proba(X_te)
        print(f"  {'mlp_keras':<18} predict_proba shape={prob.shape}")
    except Exception as e:
        print(f"  mlp_keras 测试失败: {e}")

    print("\n冒烟测试完成。")


if __name__ == "__main__":
    main()
