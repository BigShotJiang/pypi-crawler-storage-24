# evaluate.py
# 适生区基础模型精度评价脚本
# 评价指标：TSS、AUC-ROC、AUC-PR、Boyce Index、Kappa
# 使用方式：直接运行本脚本，与 train.py / models.py / config.json 放在同一目录下

import os
import json
import warnings
import argparse
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import joblib
from pathlib import Path

from sklearn.metrics import (
    roc_curve, auc, precision_recall_curve,
    confusion_matrix, cohen_kappa_score,
    average_precision_score, roc_auc_score
)
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore')
np.random.seed(42)

# ──────────────────────────────────────────────────────────────────────────────
# 1. 模型名称映射（与 batch_models.py 保持一致）
# ──────────────────────────────────────────────────────────────────────────────
MODEL_MAP = {
    "rf":      {"name": "random_forest", "display": "RandomForest",  "dir": "random_forest"},
    "maxent":  {"name": "maxent",        "display": "MaxEnt",         "dir": "maxent"},
    "xgb":     {"name": "xgboost",       "display": "XGBoost",        "dir": "xgboost"},
    "lgb":     {"name": "lightgbm",      "display": "LightGBM",       "dir": "lightgbm"},
    "svm":     {"name": "svm",           "display": "SVM",            "dir": "svm"},
    "mlp":     {"name": "mlp_keras",     "display": "MLP",            "dir": "mlp_keras"},
    "gbdtlr":  {"name": "gbdt_lr",       "display": "GBDT+LR",        "dir": "gbdt_lr"},
}

# ──────────────────────────────────────────────────────────────────────────────
# 2. 精度评价指标实现
# ──────────────────────────────────────────────────────────────────────────────

def calc_tss(y_true, y_prob, threshold=None):
    """
    True Skill Statistic (TSS) = Sensitivity + Specificity - 1
    threshold 为 None 时自动选取使 TSS 最大的阈值。
    返回: (tss_value, best_threshold, sensitivity, specificity)
    """
    fpr, tpr, thresholds = roc_curve(y_true, y_prob)
    tss_vals = tpr - fpr          # tpr = sensitivity, fpr = 1 - specificity
    if threshold is None:
        best_idx = np.argmax(tss_vals)
        best_thr = thresholds[best_idx]
    else:
        best_idx = np.argmin(np.abs(thresholds - threshold))
        best_thr = threshold

    tss_val    = tss_vals[best_idx]
    sensitivity = tpr[best_idx]
    specificity = 1.0 - fpr[best_idx]
    return float(tss_val), float(best_thr), float(sensitivity), float(specificity)


def calc_auc_roc(y_true, y_prob):
    """AUC-ROC"""
    return float(roc_auc_score(y_true, y_prob))


def calc_auc_pr(y_true, y_prob):
    """
    AUC-PR (Precision-Recall AUC)
    用 average_precision_score 实现（等价于梯形积分 PR 曲线）
    """
    return float(average_precision_score(y_true, y_prob))


def calc_kappa(y_true, y_prob, threshold=None):
    """
    Cohen's Kappa
    threshold 为 None 时使用让 TSS 最大的阈值（与 TSS 保持一致）。
    """
    if threshold is None:
        _, threshold, _, _ = calc_tss(y_true, y_prob)
    y_pred = (y_prob >= threshold).astype(int)
    return float(cohen_kappa_score(y_true, y_pred))


def calc_boyce_index(y_true, y_prob, n_bins=10, method="pearson"):
    """
    Continuous Boyce Index (CBI)
    参考 Hirzel et al. (2006) 的滑动窗口实现。
    将预测概率分成 n_bins 个等宽区间，计算
        F_i  = (presence 点落在该区间的比例) / (区间宽度)
        E_i  = (所有点落在该区间的比例)      / (区间宽度)
        Fi/Ei 比值与区间中心的 Spearman / Pearson 相关系数即为 CBI。
    返回值范围 [-1, 1]，越接近 1 越好。
    """
    bins = np.linspace(0, 1, n_bins + 1)
    bin_centers = (bins[:-1] + bins[1:]) / 2.0

    presence_probs     = y_prob[y_true == 1]
    all_probs          = y_prob

    Fi_list, Ei_list = [], []
    for lo, hi in zip(bins[:-1], bins[1:]):
        n_presence_bin = np.sum((presence_probs >= lo) & (presence_probs < hi))
        n_all_bin      = np.sum((all_probs      >= lo) & (all_probs      < hi))
        n_presence     = len(presence_probs)
        n_all          = len(all_probs)

        Fi = (n_presence_bin / n_presence) if n_presence > 0 else 0.0
        Ei = (n_all_bin      / n_all)      if n_all      > 0 else 0.0
        Fi_list.append(Fi)
        Ei_list.append(Ei)

    Fi_arr = np.array(Fi_list, dtype=float)
    Ei_arr = np.array(Ei_list, dtype=float)

    # 避免除零
    ratio = np.where(Ei_arr > 0, Fi_arr / Ei_arr, np.nan)
    valid  = ~np.isnan(ratio)

    if valid.sum() < 2:
        return np.nan

    # Spearman 相关（CBI 标准做法）
    from scipy.stats import spearmanr
    cbi, _ = spearmanr(bin_centers[valid], ratio[valid])
    return float(cbi)


# ──────────────────────────────────────────────────────────────────────────────
# 3. 从已保存的预测结果 CSV 读取概率
# ──────────────────────────────────────────────────────────────────────────────

def load_predictions(results_dir, model_name, split="test"):
    """
    读取 train.py 保存的 {model_name}_{split}_pred.csv
    返回 (y_true, y_prob) 数组
    """
    csv_path = os.path.join(results_dir, f"{model_name}_{split}_pred.csv")
    if not os.path.exists(csv_path):
        return None, None
    df = pd.read_csv(csv_path)
    if 'presence' not in df.columns or 'probability' not in df.columns:
        print(f"  [警告] {csv_path} 缺少 'presence' 或 'probability' 列，跳过")
        return None, None
    return df['presence'].values, df['probability'].values


# ──────────────────────────────────────────────────────────────────────────────
# 4. 评价单个模型
# ──────────────────────────────────────────────────────────────────────────────

def evaluate_one_model(model_key, base_output_dir, split="test"):
    """
    对单个模型计算所有精度指标。
    返回 dict 或 None（文件不存在时）
    """
    info         = MODEL_MAP[model_key]
    results_dir  = os.path.join(base_output_dir, info["dir"])
    model_name   = info["name"]
    display_name = info["display"]

    y_true, y_prob = load_predictions(results_dir, model_name, split)
    if y_true is None:
        print(f"  [跳过] {display_name}：找不到预测结果文件")
        return None

    tss, best_thr, sens, spec = calc_tss(y_true, y_prob)
    auc_roc  = calc_auc_roc(y_true, y_prob)
    auc_pr   = calc_auc_pr(y_true, y_prob)
    kappa    = calc_kappa(y_true, y_prob, threshold=best_thr)
    boyce    = calc_boyce_index(y_true, y_prob)

    result = {
        "model_key":    model_key,
        "model":        display_name,
        "TSS":          round(tss, 4),
        "AUC_ROC":      round(auc_roc, 4),
        "AUC_PR":       round(auc_pr, 4),
        "Boyce_Index":  round(boyce, 4) if not np.isnan(boyce) else np.nan,
        "Kappa":        round(kappa, 4),
        "Sensitivity":  round(sens, 4),
        "Specificity":  round(spec, 4),
        "Best_Threshold": round(best_thr, 4),
        "N_presence":   int(np.sum(y_true == 1)),
        "N_absence":    int(np.sum(y_true == 0)),
        "_y_true":      y_true,    # 保留用于绘图，不写入 CSV
        "_y_prob":      y_prob,
    }
    return result


# ──────────────────────────────────────────────────────────────────────────────
# 5. 绘图：ROC / PR / 综合指标雷达 / 条形对比图
# ──────────────────────────────────────────────────────────────────────────────

COLORS = ['#1f77b4','#ff7f0e','#2ca02c','#d62728',
          '#9467bd','#8c564b','#e377c2']


def plot_roc_curves(results_list, out_path):
    """所有模型 ROC 曲线叠加在同一图上"""
    fig, ax = plt.subplots(figsize=(7, 6))
    for i, r in enumerate(results_list):
        fpr, tpr, _ = roc_curve(r["_y_true"], r["_y_prob"])
        ax.plot(fpr, tpr, lw=2, color=COLORS[i % len(COLORS)],
                label=f"{r['model']} (AUC={r['AUC_ROC']:.3f})")
    ax.plot([0, 1], [0, 1], 'k--', lw=1)
    ax.set_xlim([0, 1.02]);  ax.set_ylim([0, 1.02])
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate", fontsize=12)
    ax.set_title("ROC Curves — All Models", fontsize=13)
    ax.legend(loc="lower right", fontsize=9)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    print(f"  ROC 曲线图已保存: {out_path}")


def plot_pr_curves(results_list, out_path):
    """所有模型 PR 曲线叠加"""
    fig, ax = plt.subplots(figsize=(7, 6))
    for i, r in enumerate(results_list):
        precision, recall, _ = precision_recall_curve(r["_y_true"], r["_y_prob"])
        ax.plot(recall, precision, lw=2, color=COLORS[i % len(COLORS)],
                label=f"{r['model']} (AUC-PR={r['AUC_PR']:.3f})")
    ax.set_xlim([0, 1.02]);  ax.set_ylim([0, 1.02])
    ax.set_xlabel("Recall", fontsize=12)
    ax.set_ylabel("Precision", fontsize=12)
    ax.set_title("Precision-Recall Curves — All Models", fontsize=13)
    ax.legend(loc="upper right", fontsize=9)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    print(f"  PR 曲线图已保存: {out_path}")


def plot_metric_bars(df_metrics, out_path):
    """
    各模型 5 个指标的分组条形图
    """
    metrics   = ["TSS", "AUC_ROC", "AUC_PR", "Boyce_Index", "Kappa"]
    labels    = ["TSS", "AUC-ROC", "AUC-PR", "Boyce Index", "Kappa"]
    n_models  = len(df_metrics)
    n_metrics = len(metrics)
    x         = np.arange(n_models)
    width     = 0.14

    fig, ax = plt.subplots(figsize=(max(10, n_models * 1.6), 6))
    for j, (m, lbl) in enumerate(zip(metrics, labels)):
        vals = df_metrics[m].values.astype(float)
        offset = (j - n_metrics / 2 + 0.5) * width
        bars = ax.bar(x + offset, vals, width,
                      label=lbl, color=COLORS[j % len(COLORS)], alpha=0.85)
        for bar, v in zip(bars, vals):
            if not np.isnan(v):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                        f"{v:.3f}", ha='center', va='bottom', fontsize=6.5)

    ax.set_xticks(x)
    ax.set_xticklabels(df_metrics["model"].tolist(), fontsize=11)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Score", fontsize=12)
    ax.set_title("Model Accuracy Metrics Comparison", fontsize=13)
    ax.legend(loc="upper right", fontsize=9)
    ax.grid(axis='y', alpha=0.3)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    print(f"  指标对比条形图已保存: {out_path}")


def plot_heatmap(df_metrics, out_path):
    """
    精度指标热力图（模型 × 指标）
    """
    import matplotlib.colors as mcolors
    metrics  = ["TSS", "AUC_ROC", "AUC_PR", "Boyce_Index", "Kappa",
                "Sensitivity", "Specificity"]
    labels   = ["TSS", "AUC-ROC", "AUC-PR", "Boyce Index", "Kappa",
                "Sensitivity", "Specificity"]

    data = df_metrics[metrics].values.astype(float)
    fig, ax = plt.subplots(figsize=(len(metrics) * 1.2 + 1, len(df_metrics) * 0.7 + 1.5))

    im = ax.imshow(data, cmap="YlGn", vmin=0, vmax=1, aspect="auto")
    plt.colorbar(im, ax=ax, fraction=0.03, pad=0.02)

    ax.set_xticks(range(len(labels)));   ax.set_xticklabels(labels, rotation=30, ha="right", fontsize=10)
    ax.set_yticks(range(len(df_metrics))); ax.set_yticklabels(df_metrics["model"].tolist(), fontsize=10)

    for i in range(data.shape[0]):
        for j in range(data.shape[1]):
            val = data[i, j]
            txt = f"{val:.3f}" if not np.isnan(val) else "N/A"
            ax.text(j, i, txt, ha="center", va="center",
                    fontsize=9, color="black" if val < 0.7 else "white")

    ax.set_title("Model Evaluation Heatmap", fontsize=13, pad=12)
    fig.tight_layout()
    fig.savefig(out_path, dpi=200)
    plt.close(fig)
    print(f"  热力图已保存: {out_path}")


# ──────────────────────────────────────────────────────────────────────────────
# 6. 主流程
# ──────────────────────────────────────────────────────────────────────────────

def parse_args():
    parser = argparse.ArgumentParser(
        description="适生区模型精度评价（TSS / AUC-ROC / AUC-PR / Boyce Index / Kappa）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例（直接运行，自动读取同目录 config.json）:
  python evaluate.py

示例（手动指定配置）:
  python evaluate.py --config config.json

示例（只评价训练集）:
  python evaluate.py --split train

示例（仅评价指定模型）:
  python evaluate.py --models rf xgb lgb
        """
    )
    parser.add_argument('--config', type=str, default=None,
                        help='配置文件路径，默认自动读取同目录下的 config.json')
    parser.add_argument('--split', type=str, default='test',
                        choices=['train', 'test', 'both'],
                        help='评价训练集还是测试集，默认 test')
    parser.add_argument('--models', nargs='+', default=None,
                        choices=list(MODEL_MAP.keys()),
                        help='仅评价指定模型，不指定则评价全部')
    parser.add_argument('--output_dir', type=str, default=None,
                        help='评价结果输出目录，默认写入 base_output_dir/evaluation/')
    return parser.parse_args()


def run_evaluation(base_output_dir, model_keys, split, eval_output_dir):
    """核心评价流程"""
    os.makedirs(eval_output_dir, exist_ok=True)

    splits = ['train', 'test'] if split == 'both' else [split]
    all_dfs = {}

    for sp in splits:
        print(f"\n{'='*60}")
        print(f"  评价集合: {sp.upper()}")
        print(f"{'='*60}")

        results_list = []
        for mk in model_keys:
            print(f"\n  >> 评价模型: {MODEL_MAP[mk]['display']}")
            r = evaluate_one_model(mk, base_output_dir, split=sp)
            if r is not None:
                results_list.append(r)
                print(f"     TSS={r['TSS']:.4f}  AUC-ROC={r['AUC_ROC']:.4f}  "
                      f"AUC-PR={r['AUC_PR']:.4f}  "
                      f"Boyce={r['Boyce_Index'] if not np.isnan(r['Boyce_Index']) else 'N/A'}  "
                      f"Kappa={r['Kappa']:.4f}")

        if not results_list:
            print(f"\n  [警告] {sp} 集无任何可用结果，跳过绘图与保存")
            continue

        # 整理 DataFrame（剔除内部用的 _y_true / _y_prob）
        keep_cols = ["model_key", "model", "TSS", "AUC_ROC", "AUC_PR",
                     "Boyce_Index", "Kappa", "Sensitivity", "Specificity",
                     "Best_Threshold", "N_presence", "N_absence"]
        df = pd.DataFrame([{k: v for k, v in r.items() if not k.startswith('_')}
                           for r in results_list])[keep_cols]
        all_dfs[sp] = df

        # ── 保存 CSV ──
        csv_path = os.path.join(eval_output_dir, f"evaluation_{sp}.csv")
        df.to_csv(csv_path, index=False, encoding='utf-8-sig')
        print(f"\n  精度评价结果已保存: {csv_path}")

        # ── 打印排名（按 TSS 降序）──
        print(f"\n  ┌─ 模型排名（按 TSS 降序）{'─'*36}┐")
        df_sorted = df.sort_values('TSS', ascending=False).reset_index(drop=True)
        print(f"  {'排名':<4} {'模型':<14} {'TSS':<8} {'AUC-ROC':<10} "
              f"{'AUC-PR':<10} {'Boyce':<10} {'Kappa':<8}")
        print(f"  {'─'*64}")
        for idx, row in df_sorted.iterrows():
            boyce_str = f"{row['Boyce_Index']:.4f}" if not np.isnan(row['Boyce_Index']) else "  N/A "
            print(f"  {idx+1:<4} {row['model']:<14} {row['TSS']:<8.4f} "
                  f"{row['AUC_ROC']:<10.4f} {row['AUC_PR']:<10.4f} "
                  f"{boyce_str:<10} {row['Kappa']:<8.4f}")
        print(f"  └{'─'*64}┘")

        # ── 绘图 ──
        print(f"\n  正在生成图表...")
        plot_roc_curves(results_list,
                        os.path.join(eval_output_dir, f"roc_curves_{sp}.png"))
        plot_pr_curves(results_list,
                       os.path.join(eval_output_dir, f"pr_curves_{sp}.png"))
        plot_metric_bars(df,
                         os.path.join(eval_output_dir, f"metric_bars_{sp}.png"))
        plot_heatmap(df,
                     os.path.join(eval_output_dir, f"heatmap_{sp}.png"))

    # ── 若同时评价了 train & test，输出两集合对比 ──
    if 'train' in all_dfs and 'test' in all_dfs:
        merged = all_dfs['train'][['model', 'TSS', 'AUC_ROC', 'AUC_PR',
                                    'Boyce_Index', 'Kappa']].copy()
        merged.columns = ['model', 'Train_TSS', 'Train_AUC_ROC',
                           'Train_AUC_PR', 'Train_Boyce', 'Train_Kappa']
        df_test = all_dfs['test'][['model', 'TSS', 'AUC_ROC', 'AUC_PR',
                                    'Boyce_Index', 'Kappa']].copy()
        df_test.columns = ['model', 'Test_TSS', 'Test_AUC_ROC',
                            'Test_AUC_PR', 'Test_Boyce', 'Test_Kappa']
        comparison = pd.merge(merged, df_test, on='model')
        cmp_path = os.path.join(eval_output_dir, "evaluation_train_vs_test.csv")
        comparison.to_csv(cmp_path, index=False, encoding='utf-8-sig')
        print(f"\n  训练/测试集对比表已保存: {cmp_path}")

    print(f"\n{'='*60}")
    print(f"  所有评价结果已写入: {eval_output_dir}")
    print(f"{'='*60}\n")


def main():
    args = parse_args()

    # ── 自动定位 config.json ──
    if args.config is None:
        default_cfg = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")
        if os.path.exists(default_cfg):
            args.config = default_cfg
        else:
            raise FileNotFoundError(
                "未找到 config.json，请通过 --config 参数指定配置文件路径。")

    print(f"\n加载配置文件: {args.config}")
    with open(args.config, 'r', encoding='utf-8') as f:
        config = json.load(f)

    base_output_dir = config['base_output_dir']
    eval_output_dir = args.output_dir or os.path.join(base_output_dir, "evaluation")

    model_keys = args.models if args.models else list(MODEL_MAP.keys())

    print(f"基础结果目录: {base_output_dir}")
    print(f"评价输出目录: {eval_output_dir}")
    print(f"评价模型: {[MODEL_MAP[k]['display'] for k in model_keys]}")
    print(f"评价数据集: {args.split}")

    run_evaluation(base_output_dir, model_keys, args.split, eval_output_dir)


if __name__ == "__main__":
    main()