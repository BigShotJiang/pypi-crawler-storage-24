"""
GeoXERL
=======
Geospatial Species Distribution Modeling toolkit combining:
- Multi-step environmental data preprocessing
- Base model training & evaluation
- Ensemble methods (Bagging / Boosting / Stacking / GWRF)
- Reinforcement-learning-based threshold optimization (Q-Learning / PPO)

Quick start
-----------
>>> from geoxerl.data_preprocessing import main as preprocess
>>> from geoxerl.base_models import train, evaluate
>>> from geoxerl.ensemble import StackingEnsemble
>>> from geoxerl.threshold_optimization import ThresholdAnalyzer

See README.md or https://geoxerl.readthedocs.io for full documentation.
"""

from geoxerl.__version__ import __version__

__all__ = ["__version__"]
