"""
集成学习与动态特征选择相关参数的集中管理。
所有参数均可通过环境变量覆盖，便于主流程灵活管理。

参数分区说明：
  ① 路径配置
  ② 数据与特征
  ③ 集成模型公共参数
  ④ Stacking 专属参数
  ⑤ Bagging 专属参数
  ⑥ Boosting 专属参数
  ⑦ GWRF 专属参数
  ⑧ 强化学习参数
  ⑨ 后处理与日志参数
  ⑩ 接口约定常量
  ⑪ 工具函数
"""

# ============================================================
# 【必须放在文件最顶部】彻底禁用 Matplotlib GUI 后端
# ============================================================
import os
os.environ['MPLBACKEND'] = 'Agg'
os.environ['QT_QPA_PLATFORM'] = 'offscreen'

import matplotlib
matplotlib.use('Agg', force=True)

from datetime import datetime


# ============================================================
# ① 路径配置
# ============================================================
PROJECT_ROOT = os.environ.get(
    "PROJECT_ROOT",
    os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
)

def set_project_root(new_root):
    """运行时动态修改项目根目录"""
    global PROJECT_ROOT
    PROJECT_ROOT = os.path.abspath(new_root)


PREPROCESSED_TRAIN_DATA = os.environ.get(
    "PREPROCESSED_TRAIN_DATA",
    r"D:\ginkgo\code\data_preprocessing\results\processed_data\selected\dataset\train_data.csv"
)
PREPROCESSED_TEST_DATA = os.environ.get(
    "PREPROCESSED_TEST_DATA",
    r"D:\ginkgo\code\data_preprocessing\results\processed_data\selected\dataset\test_data.csv"
)
FEATURE_COLS_PATH = os.environ.get(
    "FEATURE_COLS_PATH",
    r"D:\ginkgo\code\data_preprocessing\results\preprocessed\environment\selected\env_variables\selected\feature_cols.joblib"
)
ENV_STACK_TIF = os.environ.get(
    "ENV_STACK_TIF",
    r"D:\ginkgo\code\data_preprocessing\results\preprocessed\environment\selected\env_variables\selected\selected_stack.tif"
)
TIF_DIR = os.environ.get(
    "TIF_DIR",
    r"d:\ginkgo\code\data_preprocessing\results\preprocessed\environment\all\env_variables\standardized"
)
RESULTS_DIR = os.environ.get(
    "RESULTS_DIR",
    os.path.join(PROJECT_ROOT, "ensemble", "results")
)

os.makedirs(RESULTS_DIR, exist_ok=True)


# ============================================================
# ② 数据与特征
# ============================================================
NUM_TOTAL_FEATURES = int(os.environ.get("NUM_TOTAL_FEATURES", 19))  # 原始特征总数
TOP_K_FEATURES     = int(os.environ.get("TOP_K_FEATURES", 12))       # 候选 Top-K 特征数
INIT_FEATURE_NUM   = int(os.environ.get("INIT_FEATURE_NUM", 9))      # RL 初始特征子集大小


# ============================================================
# ③ 集成模型公共参数
# ============================================================
RANDOM_SEED     = int(os.environ.get("RANDOM_SEED", 42))
N_FOLDS         = int(os.environ.get("N_FOLDS", 5))          # K 折交叉验证折数（所有方法共用）
ENSEMBLE_METHOD = os.environ.get("ENSEMBLE_METHOD", "gwrf")   # 默认集成方法
BASE_MODELS     = os.environ.get("BASE_MODELS", "rf,xgb,maxent,svm").split(",")


# ============================================================
# ④ Stacking 专属参数
# ============================================================
# 元模型类型：logistic_regression | random_forest | rf | lightgbm
META_MODEL = os.environ.get("META_MODEL", "random_forest")

_VALID_META_MODELS = {"logistic_regression", "random_forest", "rf", "lightgbm"}
if META_MODEL not in _VALID_META_MODELS:
    raise ValueError(
        f"META_MODEL 必须是 {_VALID_META_MODELS} 之一，当前值：{META_MODEL!r}"
    )

# 元模型额外超参（透传给 sklearn 构造函数）
META_MODEL_PARAMS = {}


# ============================================================
# ⑤ Bagging 专属参数
# ============================================================
# 每类基模型独立训练的副本数（越多越稳定，但训练时间线性增长）
BAGGING_N_ESTIMATORS = int(os.environ.get("BAGGING_N_ESTIMATORS", 10))

# 校验
if BAGGING_N_ESTIMATORS < 1:
    raise ValueError(f"BAGGING_N_ESTIMATORS 必须 ≥ 1，当前值：{BAGGING_N_ESTIMATORS}")


# ============================================================
# ⑥ Boosting 专属参数
# ============================================================
# Boosting 迭代轮数（独立于 N_FOLDS，不再复用折数）
BOOSTING_N_ESTIMATORS = int(os.environ.get("BOOSTING_N_ESTIMATORS", 10))

# 每轮模型权重的缩放系数（AdaBoost 风格）
BOOSTING_LR = float(os.environ.get("BOOSTING_LR", 0.1))

# 损失函数类型：exponential（AdaBoost）| deviance（LogitBoost）
BOOSTING_LOSS = os.environ.get("BOOSTING_LOSS", "exponential")

# Boosting 专用基模型（SVM 不支持 sample_weight，默认排除）
BOOSTING_BASE_MODELS = os.environ.get("BOOSTING_BASE_MODELS", "rf,xgb,maxent").split(",")

# 参数校验
if BOOSTING_LOSS not in {"exponential", "deviance"}:
    raise ValueError(
        f"BOOSTING_LOSS 必须是 'exponential' 或 'deviance'，当前值：{BOOSTING_LOSS!r}"
    )
if not (0 < BOOSTING_LR <= 1):
    raise ValueError(
        f"BOOSTING_LR 必须在 (0, 1] 范围内，当前值：{BOOSTING_LR}"
    )
if BOOSTING_N_ESTIMATORS < 1:
    raise ValueError(
        f"BOOSTING_N_ESTIMATORS 必须 ≥ 1，当前值：{BOOSTING_N_ESTIMATORS}"
    )

# 历史兼容：N_ESTIMATORS 保留，指向 BOOSTING_N_ESTIMATORS
# 新代码请直接使用 BOOSTING_N_ESTIMATORS / BAGGING_N_ESTIMATORS
N_ESTIMATORS = BOOSTING_N_ESTIMATORS


# ============================================================
# ⑦ GWRF 专属参数
# ============================================================
GWRF_PARAMS = {
    "bandwidth":    float(os.environ.get("GWRF_BANDWIDTH", 0.1)),
    "n_estimators": int(os.environ.get("GWRF_N_ESTIMATORS", 100)),
    "random_state": RANDOM_SEED,   # 统一使用全局随机种子，不单独读环境变量
}


# ============================================================
# ⑧ 强化学习参数
# ============================================================
try:
    RL_LEARNING_RATE = float(os.environ.get("RL_LEARNING_RATE", 1e-3))
except ValueError:
    raise ValueError(
        f"RL_LEARNING_RATE 必须是合法浮点数，当前值：{os.environ.get('RL_LEARNING_RATE')!r}"
    )

RL_ALGO       = os.environ.get("RL_ALGO", "ppo")
RL_GAMMA      = float(os.environ.get("RL_GAMMA", 0.99))
RL_BATCH_SIZE = int(os.environ.get("RL_BATCH_SIZE", 32))
RL_NUM_EPISODES = int(os.environ.get("RL_NUM_EPISODES", 10))

# 历史兼容
N_EPISODES = int(os.environ.get("N_EPISODES", 20))
MAX_STEPS  = int(os.environ.get("MAX_STEPS", 50))

TERMINATION_CONDITIONS = {
    "max_no_improve_rounds": 25,   # 最大无改善轮数后提前终止
    "max_steps":             50,   # 单 episode 最大步数
    "min_features":          1,    # 特征子集最小规模
}

# 核心变量额外权重（空字典 = 不启用；按需填写特征名和倍数）
CORE_VARIABLE_WEIGHTS: dict = {
    # 示例：
    # "DEM":      2.0,
    # "RoadDis":  1.8,
}

REWARD_PARAMETERS = {
    "base_reward_scale":   20.0,
    "core_variable_bonus": 0.5,
    "exploration_bonus":   0.2,
    "redundancy_penalty":  0.2,
    "target_features":     10,
    "min_features":        5,
    "max_features":        15,
}

STAGE_PARAMETERS = {
    "exploration_stage":  0.4,   # 前 40% 为探索阶段
    "balance_stage":      0.7,   # 40%–70% 为平衡阶段
    "optimization_stage": 1.0,   # 70%–100% 为优化阶段
}


# ============================================================
# ⑨ 后处理与日志参数
# ============================================================
POST_PROCESSING_PARAMS = {
    "selected_top_features":         int(os.environ.get("SELECTED_TOP_FEATURES", 9)),
    "create_separate_folders":        True,
    "folder_naming_strategy":         "timestamp_features",
    "include_feature_names_in_folder": True,
    "max_folder_name_length":         100,
}

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
LOG_FILE  = os.path.join(RESULTS_DIR, "ensemble.log")


# ============================================================
# ⑩ 接口约定常量
#    fit_and_eval_cv 返回值：(oof_auc: float, oof_prob: ndarray[n_samples])
#    oof_prob 是 K 折 out-of-fold 预测概率，不含训练集信息，
#    可直接传入 RL reward 计算，无需额外处理。
# ============================================================
ENSEMBLE_RETURN_OOF = True   # 标记位：True 表示第二返回值为 OOF 概率


# ============================================================
# ⑪ 工具函数
# ============================================================
def get_selected_top_features() -> int:
    """获取当前配置的 Top 特征数量"""
    return POST_PROCESSING_PARAMS["selected_top_features"]


def set_selected_top_features(num_features: int) -> None:
    """运行时动态修改 Top 特征数量"""
    POST_PROCESSING_PARAMS["selected_top_features"] = num_features


def create_experiment_folder(selected_features: list, base_dir: str = None, suffix: str = "") -> str:
    """
    为每次实验创建独立的时间戳文件夹。

    参数：
      selected_features : 当前实验选用的特征名列表
      base_dir          : 父目录（默认 RESULTS_DIR）
      suffix            : 文件夹名后缀，如 "_stacking" / "_bagging" / "_boosting"

    返回：
      experiment_dir : 已创建的实验目录绝对路径
    """
    if base_dir is None:
        base_dir = RESULTS_DIR

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    feature_summary = f"top{len(selected_features)}"

    if POST_PROCESSING_PARAMS["include_feature_names_in_folder"] and selected_features:
        feature_str = selected_features[0]
        if len(feature_str) > 30:
            feature_str = feature_str[:30] + "..."
        feature_summary += f"_{feature_str}"

    folder_name = f"experiment_{timestamp}_{feature_summary}{suffix}"

    max_len = POST_PROCESSING_PARAMS["max_folder_name_length"]
    if len(folder_name) > max_len:
        folder_name = folder_name[:max_len - 3] + "..."

    experiment_dir = os.path.join(base_dir, folder_name)
    os.makedirs(experiment_dir, exist_ok=True)
    return experiment_dir