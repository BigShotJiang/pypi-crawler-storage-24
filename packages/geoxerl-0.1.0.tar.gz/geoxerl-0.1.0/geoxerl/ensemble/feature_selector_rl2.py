"""
PPO动态特征选择环境 - 优化版
核心修复：
1. 【动作空间】从连续 Box(1,) 改为 MultiDiscrete([2, n_total_features])
   - 动作维度0：0=remove, 1=add（明确语义，不再靠 0.5 阈值判断）
   - 动作维度1：特征索引（直接指定操作哪个特征，消除不稳定的索引映射）
2. 【奖励量纲】对所有分量归一化到同一量级，用显式权重字典统一管理
   - 每个分量的原始值先归一化到 [-1, 1] 或 [0, 1]，再乘以权重
   - 权重全部来自 config.REWARD_WEIGHTS，可在外部统一调节
3. 【其他修复】
   - 移除 diversity_bonus（与 feature_count_reward 逻辑冲突）
   - auc_cache 实装：用 frozenset(selected) 作为 key，避免重复训练
   - 评估初始状态固定 seed，使频率统计结果更可信
"""

import numpy as np
import gym
from gym import spaces
import pandas as pd
import logging

from . import config
from .stacking import DynamicStackingEnsembleCV
from .metrics import mean_corr_among_features
from sklearn.metrics import cohen_kappa_score

# ── 日志 ────────────────────────────────────────────────────────────────────
logging.basicConfig(
    filename=config.LOG_FILE,
    level=getattr(logging, config.LOG_LEVEL),
    format="%(asctime)s %(levelname)s %(message)s",
    encoding="utf-8"
)
logger = logging.getLogger("feature_selector_rl")


# ── 奖励权重默认值（当 config 未定义时使用）────────────────────────────────
_DEFAULT_REWARD_WEIGHTS = {
    "auc_improve":    2.0,   # AUC 提升量（最核心信号，权重最高）
    "auc_absolute":   0.5,   # 绝对 AUC 值（引导向高区间收敛）
    "core_variable":  0.3,   # 核心变量命中奖励
    "stage":          0.2,   # 分阶段探索引导
    "feature_count":  0.3,   # 特征数量控制
    "redundancy":    -0.4,   # 冗余度惩罚（负号在权重里，计算时传正值）
    "new_feature":    0.2,   # 新特征探索奖励
}


def _get_reward_weights():
    """从 config 读取权重，缺失时用默认值补全。"""
    base = dict(_DEFAULT_REWARD_WEIGHTS)
    cfg_w = getattr(config, "REWARD_WEIGHTS", {})
    base.update(cfg_w)
    return base


class FeatureSelectorEnv(gym.Env):
    """
    特征选择强化学习环境。

    动作空间（MultiDiscrete）：
        [op, feat_idx]
        op       : 0 = remove，1 = add
        feat_idx : 0 ~ n_total_features-1，直接表示要操作的特征索引

    观测空间：
        [one_hot(n_total_features), norm_auc, norm_redundancy]
        共 n_total_features + 2 维，全部归一化到 [0, 1]
    """

    # ── 初始化 ────────────────────────────────────────────────────────────
    def __init__(
        self,
        X, y,
        feature_names,
        base_model_classes,
        meta_model_name=None,
        n_total_features=None,
        init_feature_num=None,
        top_k=None,
        max_steps=None,
        random_state=None,
        n_folds=None
    ):
        super().__init__()
        self.X = X
        self.y = y
        self.feature_names = feature_names

        # 参数优先级：传参 > config
        self.n_total_features = n_total_features or config.NUM_TOTAL_FEATURES
        self.init_feature_num = init_feature_num or config.INIT_FEATURE_NUM
        self.top_k            = top_k            or config.TOP_K_FEATURES
        self.max_steps        = max_steps        or config.MAX_STEPS
        self.random_state     = random_state     or config.RANDOM_SEED
        self.n_folds          = n_folds          or config.N_FOLDS

        self.base_model_classes = base_model_classes
        self.meta_model_name    = meta_model_name or config.META_MODEL

        # ── 【修复1】动作空间：MultiDiscrete([2, n_total_features]) ──────
        #   dim-0: 0=remove / 1=add
        #   dim-1: 特征索引（0 ~ n_total_features-1）
        #   PPO 对 MultiDiscrete 直接输出离散概率，无需任何阈值映射
        self.action_space = spaces.MultiDiscrete(
            [2, self.n_total_features]
        )

        # 观测空间：one-hot + [norm_auc, norm_redundancy]
        self.observation_space = spaces.Box(
            low=0.0, high=1.0,
            shape=(self.n_total_features + 2,),
            dtype=np.float32
        )

        # ── Stacking 模型 ─────────────────────────────────────────────────
        self.stacking = DynamicStackingEnsembleCV(
            base_model_classes=self.base_model_classes,
            meta_model_name=self.meta_model_name,
            random_state=self.random_state,
            n_folds=self.n_folds
        )

        # ── 【修复3】AUC 缓存：frozenset(selected) → (auc, prob) ─────────
        self.auc_cache: dict = {}

        # ── 奖励权重（归一化后统一量纲）─────────────────────────────────
        self.reward_weights = _get_reward_weights()

        # 边界参数
        self.min_features = getattr(config, "MIN_FEATURES", 5)
        self.max_features = getattr(config, "MAX_FEATURES", 15)

        # 运行状态（reset 会重置）
        self.selected: list   = []
        self.steps:    int    = 0
        self.best_auc: float  = 0.0
        self.no_improve_round = 0
        self.last_auc: float  = 0.0
        self.history:  list   = []
        self.current_episode: int = 0

        self.seed(self.random_state)
        self.reset()

    # ── 工具 ──────────────────────────────────────────────────────────────
    def seed(self, seed=None):
        np.random.seed(seed)

    def _eval_features(self, feature_indices: list):
        """
        评估给定特征子集的 AUC，带缓存。
        返回 (auc: float, prob: np.ndarray)
        """
        key = frozenset(feature_indices)
        if key in self.auc_cache:
            return self.auc_cache[key]

        try:
            auc, prob = self.stacking.fit_and_eval_cv(
                self.X, self.y,
                feature_indices=list(feature_indices),
                feature_names=self.feature_names,
                n_folds=self.n_folds,
                verbose=False
            )
            if auc is None or np.isnan(auc):
                auc = 0.5
        except Exception as e:
            logger.warning(f"AUC 计算失败: {e}")
            auc, prob = 0.5, None

        self.auc_cache[key] = (auc, prob)
        return auc, prob

    # ── 观测 ──────────────────────────────────────────────────────────────
    def get_state(self) -> np.ndarray:
        one_hot = np.zeros(self.n_total_features, dtype=np.float32)
        if self.selected:
            one_hot[self.selected] = 1.0
        norm_auc       = float(np.clip(self.last_auc, 0.0, 1.0))
        norm_redundancy = float(np.clip(
            mean_corr_among_features(self.X, self.selected), 0.0, 1.0
        ))
        return np.concatenate([one_hot, [norm_auc, norm_redundancy]]).astype(np.float32)

    def get_observation(self):
        return self.get_state()

    # ── 奖励函数（各分量归一化到同量纲）──────────────────────────────────
    def _norm_auc_improve(self, auc_current, auc_last) -> float:
        """
        AUC 提升量归一化。
        理论范围 [-1, 1]，clip 后送入权重计算。
        """
        delta = auc_current - auc_last
        return float(np.clip(delta / 0.1, -1.0, 1.0))   # 0.1 为预期最大单步提升

    def _norm_auc_absolute(self, auc_current) -> float:
        """
        绝对 AUC 归一化到 [0, 1]，以 0.5 为零点拉伸。
        auc=0.5 → 0，auc=1.0 → 1
        """
        return float(np.clip((auc_current - 0.5) / 0.5, 0.0, 1.0))

    def _norm_core_variable(self, action_type, last_added_idx) -> float:
        """核心变量命中归一化到 [0, 1]。"""
        if action_type != "add" or last_added_idx is None:
            return 0.0
        if not getattr(config, "CORE_VARIABLE_WEIGHTS", {}):
            return 0.0
        fname = self.feature_names[last_added_idx]
        weight = config.CORE_VARIABLE_WEIGHTS.get(fname, 0.0)
        return float(np.clip(weight, 0.0, 1.0))

    def _norm_stage(self, action_type) -> float:
        """
        分阶段探索信号，归一化到 [-1, 1]。
        前期鼓励 add，后期鼓励精简。
        """
        progress = self.steps / max(self.max_steps, 1)
        params   = getattr(config, "STAGE_PARAMETERS", {})
        exp_stage = params.get("exploration_stage", 0.3)
        bal_stage = params.get("balance_stage", 0.7)

        if progress < exp_stage:
            return 1.0 if action_type == "add" else -0.5
        elif progress < bal_stage:
            return 0.0
        else:
            if action_type == "remove" and len(self.selected) > 10:
                return 0.5
            elif action_type == "add" and len(self.selected) < 5:
                return 0.5
            return 0.0

    def _norm_feature_count(self, num_features) -> float:
        """
        特征数量控制，归一化到 [-1, 1]。
        在 [min, max] 范围内给正值，越接近 target 越高；超界给负值。
        """
        target  = getattr(config, "REWARD_PARAMETERS", {}).get("target_features", 10)
        min_f   = self.min_features
        max_f   = self.max_features

        if num_features < min_f:
            return float(np.clip(-(min_f - num_features) / min_f, -1.0, 0.0))
        elif num_features > max_f:
            return float(np.clip(-(num_features - max_f) / max_f, -1.0, 0.0))
        else:
            dist = abs(num_features - target)
            span = max(max_f - min_f, 1) / 2
            return float(np.clip(1.0 - dist / span, 0.0, 1.0))

    def _norm_redundancy(self, redundancy) -> float:
        """冗余度归一化到 [0, 1]，权重已为负，此处传正值。"""
        return float(np.clip(redundancy, 0.0, 1.0))

    def _norm_new_feature(self, action_type) -> float:
        """新特征探索奖励，0 或 1。"""
        if action_type != "add" or not self.selected:
            return 0.0
        last_idx = self.selected[-1]
        # 检查该特征在历史中是否首次出现
        for h in self.history[:-1]:
            if last_idx in h.get("selected", []):
                return 0.0
        return 1.0

    def calculate_enhanced_reward(self, auc_current, auc_last, redundancy,
                                  action_type, last_added_idx=None):
        """
        【修复2】归一化奖励函数：各分量先归一化到 [-1,1] / [0,1]，再乘以权重。
        所有权重来自 self.reward_weights，量纲统一可比。
        """
        w = self.reward_weights

        # 各分量归一化值
        n_auc_improve   = self._norm_auc_improve(auc_current, auc_last)
        n_auc_absolute  = self._norm_auc_absolute(auc_current)
        n_core          = self._norm_core_variable(action_type, last_added_idx)
        n_stage         = self._norm_stage(action_type)
        n_count         = self._norm_feature_count(len(self.selected))
        n_redundancy    = self._norm_redundancy(redundancy)
        n_new_feature   = self._norm_new_feature(action_type)

        # 加权求和（redundancy 权重已为负数）
        total = (
            w["auc_improve"]   * n_auc_improve  +
            w["auc_absolute"]  * n_auc_absolute +
            w["core_variable"] * n_core         +
            w["stage"]         * n_stage        +
            w["feature_count"] * n_count        +
            w["redundancy"]    * n_redundancy   +   # 负权重，n_redundancy 为正
            w["new_feature"]   * n_new_feature
        )

        breakdown = {
            "n_auc_improve":  n_auc_improve,
            "n_auc_absolute": n_auc_absolute,
            "n_core":         n_core,
            "n_stage":        n_stage,
            "n_count":        n_count,
            "n_redundancy":   n_redundancy,
            "n_new_feature":  n_new_feature,
            # 加权后各项（便于 debug）
            "w_auc_improve":  w["auc_improve"]   * n_auc_improve,
            "w_auc_absolute": w["auc_absolute"]  * n_auc_absolute,
            "w_core":         w["core_variable"] * n_core,
            "w_stage":        w["stage"]         * n_stage,
            "w_count":        w["feature_count"] * n_count,
            "w_redundancy":   w["redundancy"]    * n_redundancy,
            "w_new_feature":  w["new_feature"]   * n_new_feature,
            "total_reward":   float(total),
            "auc_pure":       float(auc_current),
        }
        return float(total), breakdown

    # ── 动作执行（修复后：直接用索引，无映射偏差）───────────────────────
    def execute_action(self, op: int, feat_idx: int):
        """
        【修复1】直接用 feat_idx 操作，无需任何线性映射。

        op=0 (remove): 若 feat_idx 在 selected 中且特征数 > min，则移除
        op=1 (add):    若 feat_idx 不在 selected 中且特征数 < max，则添加

        返回实际执行的动作类型字符串。
        """
        if op == 0:  # remove
            if feat_idx in self.selected and len(self.selected) > self.min_features:
                self.selected.remove(feat_idx)
                return "remove"
            else:
                return "remove_failed"
        else:  # add
            if feat_idx not in self.selected and len(self.selected) < self.max_features:
                self.selected.append(feat_idx)
                return "add"
            else:
                return "add_failed"

    # ── 终止条件 ──────────────────────────────────────────────────────────
    def is_done(self) -> bool:
        tc = getattr(config, "TERMINATION_CONDITIONS", {})
        max_no_improve = tc.get("max_no_improve_rounds", 10)
        max_steps      = tc.get("max_steps", self.max_steps)
        min_features   = tc.get("min_features", 1)

        return (
            self.no_improve_round >= max_no_improve or
            self.steps >= max_steps or
            len(self.selected) < min_features
        )

    def get_termination_reason(self) -> str:
        tc = getattr(config, "TERMINATION_CONDITIONS", {})
        max_no_improve = tc.get("max_no_improve_rounds", 10)
        max_steps      = tc.get("max_steps", self.max_steps)
        min_features   = tc.get("min_features", 1)

        if len(self.selected) < min_features:
            return f"特征数 < {min_features}"
        if self.no_improve_round >= max_no_improve:
            return f"无改善轮数 ≥ {max_no_improve}（当前 {self.no_improve_round}）"
        if self.steps >= max_steps:
            return f"步数上限（{self.steps}/{max_steps}）"
        return "未知"

    def calculate_redundancy(self) -> float:
        if len(self.selected) <= 1:
            return 0.0
        corr  = mean_corr_among_features(self.X, self.selected)
        count = max(0, len(self.selected) - 10) / 10
        return float(0.7 * corr + 0.3 * count)

    # ── reset ─────────────────────────────────────────────────────────────
    def reset(self) -> np.ndarray:
        self.selected = np.random.choice(
            self.n_total_features,
            size=self.init_feature_num,
            replace=False
        ).tolist()

        self.steps            = 0
        self.best_auc         = 0.0
        self.no_improve_round = 0
        self.last_auc         = 0.0
        self.history          = []

        # 初始 AUC（走缓存）
        auc, _ = self._eval_features(self.selected)
        self.last_auc = auc
        self.best_auc = auc

        init_names = [self.feature_names[i] for i in self.selected]
        logger.info(
            f"环境重置: 初始特征数={len(self.selected)}, "
            f"初始AUC={self.last_auc:.4f}"
        )
        logger.info(f"初始特征: {', '.join(init_names)}")

        self.history.append({
            "step":             0,
            "selected":         list(self.selected),
            "selected_features": init_names,
            "auc":              self.last_auc,
            "best_auc":         self.best_auc,
            "no_improve_round": 0,
            "redundancy":       self.calculate_redundancy(),
            "reward":           0.0,
            "reward_breakdown": {},
            "action_type":      "initial",
        })

        return self.get_state()

    # ── step ──────────────────────────────────────────────────────────────
    def step(self, action):
        """
        action: np.ndarray of shape (2,) — [op, feat_idx]
                op       : 0=remove, 1=add
                feat_idx : 0 ~ n_total_features-1
        """
        self.steps += 1
        op       = int(action[0])
        feat_idx = int(action[1])

        before_selected = self.selected.copy()
        before_features = [self.feature_names[i] for i in before_selected]

        # ── 执行动作 ──────────────────────────────────────────────────────
        actual_type = self.execute_action(op, feat_idx)

        after_features = [self.feature_names[i] for i in self.selected]
        last_added_idx = self.selected[-1] if (actual_type == "add" and self.selected) else None

        # ── 计算 AUC（走缓存，避免重复训练）─────────────────────────────
        auc, stacking_prob = self._eval_features(self.selected)

        # ── 更新 best / no_improve ────────────────────────────────────────
        if auc > self.best_auc:
            self.best_auc         = auc
            self.no_improve_round = 0
        else:
            self.no_improve_round += 1

        # ── 计算冗余度 ────────────────────────────────────────────────────
        redundancy = self.calculate_redundancy()

        # ── 【修复2】归一化奖励 ───────────────────────────────────────────
        reward, reward_breakdown = self.calculate_enhanced_reward(
            auc, self.last_auc, redundancy, actual_type, last_added_idx
        )

        # ── Kappa（保留，用于 info 监控）─────────────────────────────────
        if stacking_prob is not None:
            if stacking_prob.ndim == 2:
                y_pred = stacking_prob.argmax(axis=1)
            else:
                threshold = np.quantile(stacking_prob, 0.75)
                y_pred    = (stacking_prob > threshold).astype(np.int32)
        else:
            y_pred = np.zeros_like(self.y)

        try:
            kappa = cohen_kappa_score(self.y, y_pred)
        except ValueError:
            kappa = 0.0

        # ── 日志 ──────────────────────────────────────────────────────────
        intended = "add" if op == 1 else "remove"
        logger.info(
            f"Ep{self.current_episode:03d}_S{self.steps:02d}: "
            f"Intent={intended:6s}, Act={actual_type:13s}, "
            f"FeatIdx={feat_idx:3d}, Feat#={len(self.selected):2d}, "
            f"AUC={auc:.4f}, Best={self.best_auc:.4f}, "
            f"NoImprove={self.no_improve_round}, Reward={reward:+.4f}"
        )

        added   = list(set(after_features) - set(before_features))
        removed = list(set(before_features) - set(after_features))
        if added:
            logger.info(f"  → Added:   {', '.join(added)}")
        if removed:
            logger.info(f"  → Removed: {', '.join(removed)}")

        logger.info(
            f"  → Breakdown: "
            f"w_auc_improve={reward_breakdown['w_auc_improve']:+.3f}, "
            f"w_auc_abs={reward_breakdown['w_auc_absolute']:+.3f}, "
            f"w_core={reward_breakdown['w_core']:+.3f}, "
            f"w_stage={reward_breakdown['w_stage']:+.3f}, "
            f"w_count={reward_breakdown['w_count']:+.3f}, "
            f"w_redun={reward_breakdown['w_redundancy']:+.3f}, "
            f"w_new={reward_breakdown['w_new_feature']:+.3f}"
        )

        # ── 历史记录 ──────────────────────────────────────────────────────
        self.history.append({
            "step":             self.steps,
            "selected":         list(self.selected),
            "selected_features": after_features,
            "auc":              auc,
            "best_auc":         self.best_auc,
            "no_improve_round": self.no_improve_round,
            "redundancy":       redundancy,
            "reward":           reward,
            "reward_breakdown": reward_breakdown,
            "action_type":      actual_type,
        })

        self.last_auc = auc
        obs  = self.get_observation()
        done = self.is_done()

        if done:
            logger.info(f"  → Episode 终止: {self.get_termination_reason()}")

        info = {
            "auc":              auc,
            "kappa":            kappa,
            "best_auc":         self.best_auc,
            "no_improve_round": self.no_improve_round,
            "redundancy":       redundancy,
            "selected":         list(self.selected),
            "selected_features": after_features,
            "action_type":      actual_type,
            "reward_breakdown": reward_breakdown,
            "y_true":           self.y,
            "y_pred":           y_pred,
        }
        return obs, reward, done, info

    # ── 辅助接口 ──────────────────────────────────────────────────────────
    def render(self, mode="human"):
        print(
            f"Step {self.steps}: 特征数={len(self.selected)}, "
            f"AUC={self.last_auc:.4f}, "
            f"冗余={self.calculate_redundancy():.4f}, "
            f"Best={self.best_auc:.4f}"
        )

    def get_best_features(self) -> list:
        """返回历史中 AUC 最高的特征子集索引列表。"""
        best_idx = int(np.argmax([h["auc"] for h in self.history]))
        return self.history[best_idx]["selected"]

    def get_feature_selection_frequency(self, feature_names=None) -> pd.DataFrame:
        """统计每个特征在历史步骤中被选中的次数。"""
        freq = np.zeros(self.n_total_features, dtype=int)
        for h in self.history:
            for fidx in h.get("selected", []):
                if 0 <= fidx < self.n_total_features:
                    freq[fidx] += 1

        cols = feature_names if (
            feature_names is not None and len(feature_names) == self.n_total_features
        ) else self.feature_names

        n_steps = max(len(self.history), 1)
        df = pd.DataFrame({
            "feature":   cols,
            "freq":      freq,
            "avg_freq":  freq / n_steps,
            "total_freq": freq,
        })
        return df.sort_values("total_freq", ascending=False).reset_index(drop=True)


# ── 单元测试入口 ───────────────────────────────────────────────────────────
if __name__ == "__main__":
    from ..base_models.models import (
        RandomForestModel, XGBoostModel, MaxEntModel, SVMModel
    )

    np.random.seed(42)
    n_samples, n_features = 500, 40
    X = np.random.randn(n_samples, n_features)
    y = np.random.randint(0, 2, n_samples)
    feature_names = [f"var_{i+1}" for i in range(n_features)]

    env = FeatureSelectorEnv(
        X, y, feature_names,
        base_model_classes=[RandomForestModel, XGBoostModel, MaxEntModel, SVMModel],
        meta_model_name="logistic_regression",
        n_total_features=n_features,
        init_feature_num=8,
        top_k=15,
        max_steps=30,
        random_state=42
    )

    print("动作空间:", env.action_space)
    print("观测空间:", env.observation_space)

    obs = env.reset()
    done, total_reward = False, 0.0

    while not done:
        action = env.action_space.sample()
        obs, reward, done, info = env.step(action)
        env.render()
        total_reward += reward

    print(f"\n训练结束。总奖励: {total_reward:.4f}")
    print("最佳特征索引:", env.get_best_features())
    print("\n特征选中频率（Top 10）:")
    print(env.get_feature_selection_frequency().head(10).to_string(index=False))