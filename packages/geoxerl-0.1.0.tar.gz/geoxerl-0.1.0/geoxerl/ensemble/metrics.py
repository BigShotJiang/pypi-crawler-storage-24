import numpy as np
from sklearn.metrics import roc_auc_score, confusion_matrix, cohen_kappa_score, average_precision_score

def tss_score(y_true, y_pred, threshold=0.5):
    """
    计算TSS (True Skill Statistic)
    TSS = Sensitivity + Specificity - 1
    """
    y_pred_bin = (y_pred >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred_bin).ravel()
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    tss = sensitivity + specificity - 1
    return tss

def kappa_score(y_true, y_pred, threshold=0.5):
    """
    计算Kappa系数
    """
    y_pred_bin = (y_pred >= threshold).astype(int)
    return cohen_kappa_score(y_true, y_pred_bin)

def boyce_index(pred, presence_mask, n_bins=10):
    """
    计算Boyce Index
    pred: 全部样本的预测概率
    presence_mask: 是否为存在点的bool数组（或0/1）
    n_bins: 分箱数
    """
    try:
        pred = np.asarray(pred)
        presence_mask = np.asarray(presence_mask).astype(bool)
        
        if pred[presence_mask].size == 0 or pred[~presence_mask].size == 0:
            return np.nan

        # 分箱
        bins = np.percentile(pred, np.linspace(0, 100, n_bins + 1))
        bins[0] -= 1e-8  # 保证最小值包含
        bins[-1] += 1e-8
        bin_ids = np.digitize(pred, bins) - 1

        px = np.bincount(bin_ids[presence_mask], minlength=n_bins)
        qx = np.bincount(bin_ids[~presence_mask], minlength=n_bins)
        px = px / (px.sum() + 1e-8)
        qx = qx / (qx.sum() + 1e-8)

        # Boyce index（去掉qx=0的分箱）
        valid = (qx > 0) & (px > 0)
        if valid.sum() < 2:
            return np.nan
        ratio = px[valid] / qx[valid]
        x = np.arange(len(ratio))
        corr = np.corrcoef(x, ratio)[0, 1]
        return corr
    except Exception as e:
        print(f"Boyce Index计算错误: {e}")
        return np.nan

def mean_corr_among_features(X, feature_indices):
    """
    计算选中特征之间的平均绝对相关系数（用于特征冗余度奖励）
    X: [n_samples, n_features]（全量特征）
    feature_indices: list[int]
    """
    if len(feature_indices) <= 1:
        return 0.0
    X_sub = X[:, feature_indices]
    corr_mat = np.corrcoef(X_sub, rowvar=False)
    abs_corr = np.abs(corr_mat)
    # 只统计上三角，不含对角线
    tri_idx = np.triu_indices_from(abs_corr, k=1)
    mean_corr = abs_corr[tri_idx].mean()
    return mean_corr

def all_metrics(y_true, y_prob, presence_mask=None, threshold=0.5):
    """
    汇总指标 - 修正版本，键名与调用代码匹配
    """
    try:
        # 基本验证
        y_true = np.asarray(y_true)
        y_prob = np.asarray(y_prob)
        
        if len(y_true) != len(y_prob):
            raise ValueError(f"y_true和y_prob长度不匹配: {len(y_true)} vs {len(y_prob)}")
        
        if len(np.unique(y_true)) < 2:
            raise ValueError("y_true必须包含至少两个不同的类别")
        
        # 计算AUC-ROC
        auc_roc = roc_auc_score(y_true, y_prob)
        
        # 计算AUC-PR
        auc_pr = average_precision_score(y_true, y_prob)
        
        # 计算TSS
        tss = tss_score(y_true, y_prob, threshold)
        
        # 计算Kappa
        kappa = kappa_score(y_true, y_prob, threshold)
        
        # 计算Boyce Index
        if presence_mask is None:
            presence_mask = (y_true == 1)
        boyce = boyce_index(y_prob, presence_mask)
        
        # 返回键名与调用代码匹配的字典
        return {
            "auc_roc": auc_roc,        # 匹配 final_metrics.get('auc_roc')
            "auc_pr": auc_pr,          # 匹配 final_metrics.get('auc_pr')
            "tss": tss,                # 匹配 final_metrics.get('tss')
            "kappa": kappa,            # 匹配 final_metrics.get('kappa')
            "boyce_index": boyce,      # 匹配 final_metrics.get('boyce_index')
            # 保留原有键名以兼容其他代码
            "AUC": auc_roc,
            "TSS": tss,
            "Kappa": kappa,
            "Boyce": boyce
        }
        
    except Exception as e:
        print(f"指标计算错误: {e}")
        return {
            "auc_roc": np.nan,
            "auc_pr": np.nan,
            "tss": np.nan,
            "kappa": np.nan,
            "boyce_index": np.nan,
            "AUC": np.nan,
            "TSS": np.nan,
            "Kappa": np.nan,
            "Boyce": np.nan
        }
    
