"""
PPO主流程：动态特征选择 + 集成学习AUC优化（替换为分类指标：Kappa、F1、Precision、Recall）
"""

import os
import numpy as np
import pandas as pd
import joblib
import logging
import torch
import time
from datetime import datetime, timedelta
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import BaseCallback
from sklearn.metrics import roc_auc_score, cohen_kappa_score, f1_score, precision_score, recall_score, accuracy_score
import json
from . import config
from .feature_selector_rl2 import FeatureSelectorEnv

from ..base_models.models import RandomForestModel, XGBoostModel, MaxEntModel, SVMModel
import warnings
warnings.filterwarnings("ignore", category=UserWarning)

# 配置日志
logging.basicConfig(
    filename=config.LOG_FILE,
    level=getattr(logging, config.LOG_LEVEL),
    format="%(asctime)s %(levelname)s %(message)s",
    encoding="utf-8"
)
logger = logging.getLogger("ppo_main")
device = "cuda" if torch.cuda.is_available() else "cpu"


def save_visualization_data(data_dict, save_path, file_format="csv"):
    """
    保存可视化数据到文件
    :param data_dict: 要保存的数据字典
    :param save_path: 保存路径
    :param file_format: 保存格式 (csv/json)
    """
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    try:
        if file_format == "csv":
            # 处理时序数据（不同episode步数不一致的情况）
            if isinstance(data_dict, dict) and "steps" in data_dict:
                df = pd.DataFrame(data_dict)
            else:
                # 处理二维列表（episodes × steps）
                max_steps = max(len(lst) for lst in data_dict.values()) if data_dict else 0
                df_data = {}
                for key, values in data_dict.items():
                    # 补全NaN使长度一致
                    padded_values = values + [np.nan] * (max_steps - len(values))
                    df_data[key] = padded_values
                df = pd.DataFrame(df_data)
            df.to_csv(save_path, index=False, encoding="utf-8-sig")
        elif file_format == "json":
            # 处理numpy数组，转换为列表
            def convert_to_serializable(obj):
                if isinstance(obj, np.ndarray):
                    return obj.tolist()
                elif isinstance(obj, np.floating):
                    return float(obj)
                elif isinstance(obj, np.integer):
                    return int(obj)
                elif isinstance(obj, dict):
                    return {k: convert_to_serializable(v) for k, v in obj.items()}
                elif isinstance(obj, list):
                    return [convert_to_serializable(v) for v in obj]
                else:
                    return obj

            serializable_data = convert_to_serializable(data_dict)
            with open(save_path, "w", encoding="utf-8") as f:
                json.dump(serializable_data, f, ensure_ascii=False, indent=2)
        print(f"✓ 可视化数据已保存: {save_path}")
        logger.info(f"可视化数据保存成功: {save_path}")
    except Exception as e:
        print(f"⚠ 保存可视化数据失败: {e}")
        logger.warning(f"保存可视化数据失败: {e}")


def save_temporal_data(auc_list_all, reward_list_all, kappa_list_all, save_dir):
    """
    保存时序可视化数据（AUC、Reward、Kappa随步数变化）
    """
    # 1. 整理时序数据（按步数对齐）
    max_steps = max(len(lst) for lst in auc_list_all) if auc_list_all else 0
    steps = list(range(1, max_steps + 1))

    # 2. 保存每个episode的原始时序数据
    temporal_raw_data = {"step": steps}
    for i, (auc_lst, reward_lst, kappa_lst) in enumerate(zip(auc_list_all, reward_list_all, kappa_list_all)):
        # 补全NaN
        auc_padded = auc_lst + [np.nan] * (max_steps - len(auc_lst))
        reward_padded = reward_lst + [np.nan] * (max_steps - len(reward_lst))
        kappa_padded = kappa_lst + [np.nan] * (max_steps - len(kappa_lst))

        temporal_raw_data[f"episode_{i + 1}_auc"] = auc_padded
        temporal_raw_data[f"episode_{i + 1}_reward"] = reward_padded
        temporal_raw_data[f"episode_{i + 1}_kappa"] = kappa_padded

    save_visualization_data(
        temporal_raw_data,
        os.path.join(save_dir, "ppo_temporal_raw.csv"),
        file_format="csv"
    )

    # 3. 计算均值和标准差，保存统计数据（方便直接绘图）
    if max_steps > 0:
        # 构建矩阵
        auc_mat = np.full((len(auc_list_all), max_steps), np.nan)
        reward_mat = np.full((len(reward_list_all), max_steps), np.nan)
        kappa_mat = np.full((len(kappa_list_all), max_steps), np.nan)

        for i in range(len(auc_list_all)):
            auc_mat[i, :len(auc_list_all[i])] = auc_list_all[i]
            reward_mat[i, :len(reward_list_all[i])] = reward_list_all[i]
            kappa_mat[i, :len(kappa_list_all[i])] = kappa_list_all[i]

        # 计算统计值
        temporal_stats = {
            "step": steps,
            "auc_mean": np.nanmean(auc_mat, axis=0).tolist(),
            "auc_std": np.nanstd(auc_mat, axis=0).tolist(),
            "reward_mean": np.nanmean(reward_mat, axis=0).tolist(),
            "reward_std": np.nanstd(reward_mat, axis=0).tolist(),
            "kappa_mean": np.nanmean(kappa_mat, axis=0).tolist(),
            "kappa_std": np.nanstd(kappa_mat, axis=0).tolist(),
            "auc_max": np.nanmax(auc_mat, axis=0).tolist(),
            "kappa_max": np.nanmax(kappa_mat, axis=0).tolist()
        }

        save_visualization_data(
            temporal_stats,
            os.path.join(save_dir, "ppo_temporal_stats.csv"),
            file_format="csv"
        )


def save_feature_frequency_data(freq_total, feature_cols, save_dir):
    """保存特征频率数据"""
    # 1. 基础频率数据
    freq_data = {
        "feature_name": feature_cols,
        "total_freq": freq_total.tolist(),
        "avg_freq": (freq_total / config.N_EPISODES).tolist(),
        "freq_ratio": (freq_total / config.N_EPISODES / config.MAX_STEPS).tolist()  # 相对频率（步数归一化）
    }
    save_visualization_data(
        freq_data,
        os.path.join(save_dir, "ppo_feature_frequency.csv"),
        file_format="csv"
    )

    # 2. 排序后的Top特征（方便绘图）
    freq_df = pd.DataFrame(freq_data).sort_values("avg_freq", ascending=False)
    save_visualization_data(
        freq_df.to_dict('list'),
        os.path.join(save_dir, "ppo_feature_frequency_sorted.csv"),
        file_format="csv"
    )


def save_training_metadata(total_timesteps, total_time, save_dir):
    """保存训练元信息"""
    metadata = {
        "training_info": {
            "start_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "total_timesteps": total_timesteps,
            "total_training_time_seconds": total_time,
            "total_training_time_str": str(timedelta(seconds=int(total_time))),
            "avg_time_per_step": total_time / total_timesteps if total_timesteps > 0 else 0,
            "n_episodes": config.N_EPISODES,
            "max_steps_per_episode": config.MAX_STEPS
        },
        "hyperparameters": {
            "rl_learning_rate": config.RL_LEARNING_RATE,
            "rl_gamma": config.RL_GAMMA,
            "rl_batch_size": config.RL_BATCH_SIZE,
            "init_feature_num": config.INIT_FEATURE_NUM,
            "top_k_features": config.TOP_K_FEATURES,
            "reward_parameters": config.REWARD_PARAMETERS,
            "termination_conditions": config.TERMINATION_CONDITIONS
        },
        "device": device
    }
    save_visualization_data(
        metadata,
        os.path.join(save_dir, "ppo_training_metadata.json"),
        file_format="json"
    )

def load_data():
    """加载训练数据"""
    X_train = pd.read_csv(config.PREPROCESSED_TRAIN_DATA)
    y_train = X_train["presence"].values
    # 加载特征名和矩阵
    feature_cols = joblib.load(config.FEATURE_COLS_PATH)
    X = X_train[feature_cols].values
    logger.info(f"数据加载完成: X shape={X.shape}, y shape={y_train.shape}, features={len(feature_cols)}")
    return X, y_train, feature_cols

def create_training_env(X, y, feature_cols):
    """创建训练环境"""
    def make_env():
        env = FeatureSelectorEnv(
            X, y, feature_names=feature_cols,  # 传入真实特征名称
            base_model_classes=[RandomForestModel, XGBoostModel, MaxEntModel, SVMModel],
            meta_model_name=config.META_MODEL,
            n_total_features=len(feature_cols),
            init_feature_num=config.INIT_FEATURE_NUM,
            top_k=config.TOP_K_FEATURES,
            max_steps=config.MAX_STEPS,
            random_state=config.RANDOM_SEED,
            n_folds=config.N_FOLDS
        )
        return env
    return make_env

class DetailedProgressCallback(BaseCallback):
    """详细的训练进度回调（精准闭环进度条版）"""

    def __init__(self, total_timesteps, check_freq=10, verbose=1):
        super().__init__(verbose)
        self.total_timesteps = total_timesteps  # 训练总步数（硬上限）
        self.check_freq = check_freq
        self.start_time = None
        self.last_print_step = 0
        self.step_times = []
        self.has_printed_100_percent = False  # 标记是否已打印100%进度

    def _on_training_start(self):
        self.start_time = time.time()
        print(f"\n{'=' * 60}")
        print(f"训练开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"总步数: {self.total_timesteps}")
        print(f"预估总时间: 约 {self.total_timesteps * 3.5 / 3600:.1f} 小时")
        print(f"{'=' * 60}\n")
        logger.info(f"训练开始，总步数: {self.total_timesteps}")

    def _on_step(self):
        # 1. 定义当前有效步数（不超过总步数，避免超界）
        current_effective_step = min(self.num_timesteps, self.total_timesteps)

        # 2. 进度打印逻辑（仅在有效步数范围内，且满足检查频率，或达到100%未打印）
        need_print = False
        # 条件1：满足检查频率
        if current_effective_step % self.check_freq == 0 and current_effective_step > self.last_print_step:
            need_print = True
        # 条件2：达到总步数且未打印100%进度（强制闭环）
        if current_effective_step == self.total_timesteps and not self.has_printed_100_percent:
            need_print = True

        if need_print:
            # 计算核心进度参数（基于有效步数，确保不超界）
            progress = 100.0 * current_effective_step / self.total_timesteps
            elapsed = time.time() - self.start_time
            avg_time_per_step = elapsed / current_effective_step if current_effective_step > 0 else 0
            remaining_steps = self.total_timesteps - current_effective_step
            eta_seconds = remaining_steps * avg_time_per_step if avg_time_per_step > 0 else 0
            eta = timedelta(seconds=int(eta_seconds))
            elapsed_str = str(timedelta(seconds=int(elapsed)))

            # 格式化输出（严格对应总步数，无超界）
            print(f"[进度] Step {current_effective_step}/{self.total_timesteps} "
                  f"({progress:.1f}%) | "
                  f"用时: {elapsed_str} | "
                  f"预计剩余: {eta} | "
                  f"速度: {avg_time_per_step:.2f}s/step",
                  flush=True)

            # 日志记录（仅在10倍检查频率，且未超界）
            if (current_effective_step % (self.check_freq * 10) == 0) and (
                    current_effective_step <= self.total_timesteps):
                logger.info(f"训练进度: {current_effective_step}/{self.total_timesteps} "
                            f"({progress:.1f}%), ETA: {eta}")

            # 3. 更新状态，避免重复打印
            self.last_print_step = current_effective_step
            if current_effective_step == self.total_timesteps:
                self.has_printed_100_percent = True

        # 4. 训练终止判断（达到总步数后，后续步骤不再处理）
        return self.num_timesteps < self.total_timesteps

    def _on_training_end(self):
        total_time = time.time() - self.start_time
        total_time_str = str(timedelta(seconds=int(total_time)))

        # 兜底：如果未打印100%进度，补充打印（防止极端情况遗漏）
        if not self.has_printed_100_percent:
            print(f"[进度] Step {self.total_timesteps}/{self.total_timesteps} "
                  f"(100.0%) | 用时: {total_time_str} | 预计剩余: 0:00:00 | "
                  f"速度: {total_time / self.total_timesteps:.2f}s/step",
                  flush=True)

        # 打印训练完成总结
        print(f"\n{'=' * 60}")
        print(f"✅ 训练完成!")
        print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"总用时: {total_time_str}")
        print(f"平均速度: {total_time / self.total_timesteps:.2f}s/step")
        print(f"{'=' * 60}\n")
        logger.info(f"训练完成，总用时: {total_time_str}")

def train_ppo(vec_env):
    """训练PPO模型"""
    logger.info("开始PPO训练...")
    print("[train_ppo] 即将实例化 PPO 模型...", flush=True)
    print(f"[train_ppo] learning_rate = {config.RL_LEARNING_RATE}, type: {type(config.RL_LEARNING_RATE)}", flush=True)

    model = PPO(
        "MlpPolicy",
        vec_env,
        learning_rate=config.RL_LEARNING_RATE,
        gamma=config.RL_GAMMA,
        batch_size=config.RL_BATCH_SIZE,
        verbose=0,  # 关闭 stable-baselines3 自带的输出，使用自定义回调
        seed=config.RANDOM_SEED,
        device=device
    )

    print("[train_ppo] ✓ PPO 实例化完成", flush=True)

    total_timesteps = config.RL_NUM_EPISODES * config.MAX_STEPS
    logger.info(f"训练参数: timesteps={total_timesteps}, episodes={config.RL_NUM_EPISODES}, max_steps={config.MAX_STEPS}")
    print(f"[train_ppo] 训练配置:", flush=True)
    print(f"  - 总步数: {total_timesteps}", flush=True)
    print(f"  - Episodes: {config.RL_NUM_EPISODES}", flush=True)
    print(f"  - 每个Episode最大步数: {config.MAX_STEPS}", flush=True)
    print(f"  - 设备: {device}", flush=True)
    print(f"\n提示: 首次step可能需要3-5秒，请耐心等待...\n", flush=True)

    # 创建详细进度回调
    callback = DetailedProgressCallback(
        total_timesteps=total_timesteps,
        check_freq=10,  # 每10步显示一次进度
        verbose=1
    )

    try:
        model.learn(total_timesteps=total_timesteps, callback=callback)
        logger.info("PPO训练完成")
    except KeyboardInterrupt:
        print("\n\n⚠️  训练被用户中断")
        logger.warning("训练被用户中断")
        print("正在保存当前模型...")
        return model
    except Exception as e:
        print(f"\n\n❌ 训练过程中出错: {e}", flush=True)
        logger.error(f"训练失败: {e}", exc_info=True)
        raise

    return model

def save_and_load_model(model):
    """保存并重新加载模型"""
    ppo_model_path = os.path.join(config.RESULTS_DIR, "ppo_policy.zip")
    model.save(ppo_model_path)
    logger.info(f"PPO策略模型已保存到: {ppo_model_path}")
    print(f"✓ PPO策略模型已保存到: {ppo_model_path}")
    return ppo_model_path

def calculate_classification_metrics(y_true, y_pred, y_pred_proba=None):
    """
    计算分类任务核心指标（兜底处理避免报错）
    """
    # 兜底：防止空值、维度不匹配
    if len(y_true) == 0 or len(y_pred) == 0:
        return 0.0, 0.0, 0.0, 0.0, 0.0

    # 计算核心分类指标（带兜底，避免除零错误）
    try:
        kappa = cohen_kappa_score(y_true, y_pred)
    except:
        kappa = 0.0

    try:
        f1 = f1_score(y_true, y_pred, average='binary')  # 二分类任务使用binary
    except:
        f1 = 0.0

    try:
        precision = precision_score(y_true, y_pred, average='binary')
    except:
        precision = 0.0

    try:
        recall = recall_score(y_true, y_pred, average='binary')
    except:
        recall = 0.0

    return kappa, f1, precision, recall

def run_evaluation_episodes(model, eval_env, feature_cols):
    """运行评估episodes并收集统计信息（替换为分类指标：Kappa、F1、Precision、Recall）"""
    logger.info("开始多次PPO策略回放...")

    n_episodes = config.N_EPISODES
    freq_total = np.zeros(len(feature_cols), dtype=int)
    # 分类指标列表（存储每个episode的每一步指标）
    auc_list_all = []
    reward_list_all = []
    kappa_list_all = []
    # f1_list_all = []
    # precision_list_all = []
    # recall_list_all = []

    print(f"\n{'='*60}")
    print(f"多次PPO策略回放 (共{n_episodes}次)")
    print(f"{'='*60}\n")

    eval_start_time = time.time()

    for ep in range(n_episodes):
        ep_start_time = time.time()

        # 设置当前episode到环境中
        eval_env.current_episode = ep

        step_count = 0
        obs = eval_env.reset()
        done = False
        # 单episode内的指标列表
        auc_list, reward_list = [], []
        kappa_list = []
        #f1_list, precision_list, recall_list = [], [], []
        episode_reward = 0

        logger.info(f"=== Episode {ep + 1}/{n_episodes} 开始 ===")

        while not done:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, done, info = eval_env.step(action)
            step_count += 1
            episode_reward += reward

            # 收集性能数据（AUC和奖励）
            auc_val = info.get('auc', 0.0)
            auc_list.append(auc_val)
            reward_list.append(reward)

            # 收集分类指标（从info中获取真实标签和预测标签）
            y_true = info.get('y_true', eval_env.y)  # 真实标签
            y_pred = info.get('y_pred', np.zeros_like(y_true))  # 模型预测标签（二分类）
            kappa, f1, precision, recall = calculate_classification_metrics(y_true, y_pred)

            # 存入单episode列表
            kappa_list.append(kappa)
            # f1_list.append(f1)
            # precision_list.append(precision)
            # recall_list.append(recall)

        # 累计本episode变量freq
        freq_ep = eval_env.get_feature_selection_frequency(feature_names=feature_cols)["freq"].values
        freq_total += freq_ep

        # 存入全局列表（用于后续统计和可视化）
        auc_list_all.append(auc_list)
        reward_list_all.append(reward_list)
        kappa_list_all.append(kappa_list)
        # f1_list_all.append(f1_list)
        # precision_list_all.append(precision_list)
        # recall_list_all.append(recall_list)

        # 记录episode结果
        final_auc = max(auc_list) if auc_list else 0
        final_kappa = max(kappa_list) if kappa_list else 0
        # final_f1 = max(f1_list) if f1_list else 0
        final_features = len(info.get('selected', []))
        ep_time = time.time() - ep_start_time

        logger.info(f"=== Episode {ep + 1} 完成 ===")
        logger.info(f"  Steps: {step_count}, Total Reward: {episode_reward:.4f}")
        # logger.info(f"  Best AUC: {final_auc:.4f}, Best Kappa: {final_kappa:.4f}, Best F1: {final_f1:.4f}")
        logger.info(f"  Final Features: {final_features}")

        # 计算剩余时间
        avg_time_per_ep = (time.time() - eval_start_time) / (ep + 1)
        remaining_eps = n_episodes - (ep + 1)
        eta = timedelta(seconds=int(remaining_eps * avg_time_per_ep))

        print(f"Episode {ep+1}/{n_episodes} | "
              f"Steps: {step_count} | "
              f"Best AUC: {final_auc:.4f} | "
              # f"Best F1: {final_f1:.4f} | "
              f"Reward: {episode_reward:.4f} | "
              f"用时: {ep_time:.1f}s | "
              f"剩余: {eta}",
              flush=True)

    total_eval_time = time.time() - eval_start_time
    print(f"\n✓ 评估完成，总用时: {timedelta(seconds=int(total_eval_time))}\n")

    # 返回分类指标列表
    return (freq_total, auc_list_all, reward_list_all,
            kappa_list_all)

def analyze_feature_frequency(freq_total, feature_cols):
    """分析特征选择频次并保存数据"""
    logger.info("分析特征选择频次...")

    # 保存特征频率数据（新增）
    save_feature_frequency_data(freq_total, feature_cols, config.RESULTS_DIR)

    # 计算平均频次
    freq_avg = freq_total / config.N_EPISODES
    freq_df = pd.DataFrame({
        "feature": feature_cols,
        "avg_freq": freq_avg,
        "total_freq": freq_total
    })
    freq_df = freq_df.sort_values("avg_freq", ascending=False).reset_index(drop=True)

    # 保存Top 30结果
    top30_df = freq_df.head(config.TOP_K_FEATURES)
    top30_path = os.path.join(config.RESULTS_DIR, "top30_variable_freq_avg.csv")
    top30_df.to_csv(top30_path, index=False)

    logger.info(f"Top 30变量及平均选择频次已保存: {top30_path}")
    print(f"✓ Top 30变量及平均选择频次已保存: {top30_path}")

    # 打印Top 10结果
    print(f"\n{'='*60}")
    print("Top 10 特征选择频次")
    print(f"{'='*60}")
    print(top30_df.head(10).to_string(index=False))
    print(f"{'='*60}\n")

    return top30_df


def create_visualization(auc_list_all, reward_list_all, kappa_list_all):
    """创建可视化图表并保存原始数据"""
    logger.info("创建可视化图表并保存原始数据...")

    try:
        # ========== 第一步：保存所有可视化数据 ==========
        # 1. 保存时序数据（AUC/Reward/Kappa）
        save_temporal_data(auc_list_all, reward_list_all, kappa_list_all, config.RESULTS_DIR)

        # ========== 第二步：原有绘图逻辑（保持不变） ==========
        import matplotlib.pyplot as plt

        # 设置matplotlib支持中文
        plt.rcParams['font.sans-serif'] = ['SimHei', 'Arial']
        plt.rcParams['axes.unicode_minus'] = False

        n_episodes = len(auc_list_all)
        max_steps = max(len(lst) for lst in auc_list_all) if auc_list_all else 0

        # 构建所有指标的矩阵（带NaN兜底）
        auc_mat = np.full((n_episodes, max_steps), np.nan)
        reward_mat = np.full((n_episodes, max_steps), np.nan)
        kappa_mat = np.full((n_episodes, max_steps), np.nan)

        # 填充数据
        for i in range(n_episodes):
            auc_mat[i, :len(auc_list_all[i])] = auc_list_all[i]
            reward_mat[i, :len(reward_list_all[i])] = reward_list_all[i]
            kappa_mat[i, :len(kappa_list_all[i])] = kappa_list_all[i]

        # 计算均值和标准差
        auc_mean = np.nanmean(auc_mat, axis=0) if max_steps > 0 else np.array([])
        auc_std = np.nanstd(auc_mat, axis=0) if max_steps > 0 else np.array([])
        final_auc_std = auc_std[-1] if len(auc_std) > 0 and not np.isnan(auc_std[-1]) else 0.0001

        reward_mean = np.nanmean(reward_mat, axis=0) if max_steps > 0 else np.array([])
        reward_std = np.nanstd(reward_mat, axis=0) if max_steps > 0 else np.array([])
        final_reward_std = reward_std[-1] if len(reward_std) > 0 and not np.isnan(reward_std[-1]) else 0.0001

        kappa_mean = np.nanmean(kappa_mat, axis=0) if max_steps > 0 else np.array([])

        # 绘制图表
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        # AUC曲线
        if len(auc_mean) > 0:
            steps = range(len(auc_mean))
            ax1.plot(steps, auc_mean, label='AUC (mean)', color='blue', linewidth=2)
            ax1.fill_between(steps, auc_mean - auc_std, auc_mean + auc_std,
                             alpha=0.3, color='blue', label='±1 std')
            ax1.set_xlabel('Step')
            ax1.set_ylabel('AUC')
            ax1.set_title('PPO AUC Learning Curve')
            ax1.legend()
            ax1.grid(True, alpha=0.3)

        # Reward曲线
        if len(reward_mean) > 0:
            steps = range(len(reward_mean))
            ax2.plot(steps, reward_mean, label='Reward (mean)', color='red', linewidth=2)
            ax2.fill_between(steps, reward_mean - reward_std, reward_mean + reward_std,
                             alpha=0.3, color='red', label='±1 std')
            ax2.set_xlabel('Step')
            ax2.set_ylabel('Reward')
            ax2.set_title('PPO Reward Learning Curve')
            ax2.legend()
            ax2.grid(True, alpha=0.3)

        plt.tight_layout()

        # 保存图表
        chart_path = os.path.join(config.RESULTS_DIR, "ppo_replay_auc_reward_avg.png")
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()

        logger.info(f"可视化图表已保存: {chart_path}")
        print(f"✓ 可视化图表已保存: {chart_path}")

        # 打印统计信息
        print(f"\n{'=' * 60}")
        print("训练统计信息（分类任务）")
        print(f"{'=' * 60}")
        if len(auc_mean) > 0:
            print(f"最终平均AUC: {auc_mean[-1]:.4f} ± {final_auc_std:.4f}")
            print(f"最高AUC: {np.nanmax(auc_mat):.4f}")
        else:
            print("无AUC数据")
        if len(reward_mean) > 0:
            print(f"最终平均Reward: {reward_mean[-1]:.4f} ± {final_reward_std:.4f}")
        else:
            print("无奖励数据")
        if len(kappa_mean) > 0:
            print(f"最终平均Kappa系数: {kappa_mean[-1]:.4f} | 最高Kappa: {np.nanmax(kappa_mat):.4f}")
        else:
            print("无分类指标数据")
        print(f"{'=' * 60}\n")

    except Exception as ex:
        logger.warning(f"可视化失败: {ex}")
        print(f"⚠ 可视化失败: {ex}")

def main():
    """主函数"""
    overall_start_time = time.time()

    print("\n" + "="*60)
    print("          PPO动态特征选择训练系统")
    print("="*60)
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"设备: {device}")
    print("="*60 + "\n")

    try:
        # ========== 1. 加载数据 ==========
        print("📂 [1/8] 加载数据...", flush=True)
        X, y, feature_cols = load_data()
        print(f"✓ 数据加载完成: {X.shape[0]} 样本, {X.shape[1]} 特征\n")

        # ========== 2. 构建训练环境 ==========
        print("🏗️  [2/8] 构建训练环境...", flush=True)
        make_env = create_training_env(X, y, feature_cols)
        vec_env = make_vec_env(make_env, n_envs=1)
        print("✓ 训练环境构建完成\n")

        # ========== 3. PPO训练 ==========
        print("🚀 [3/8] PPO训练...")
        model = train_ppo(vec_env)
        print("✓ PPO训练完成\n")

        # ========== 4. 保存模型 ==========
        print("💾 [4/8] 保存PPO模型...", flush=True)
        ppo_model_path = save_and_load_model(model)
        print("✓ 模型保存完成\n")

        # ========== 5. 创建评估环境 ==========
        print("🔧 [5/8] 创建评估环境...", flush=True)
        eval_env = make_env()
        model = PPO.load(ppo_model_path, env=eval_env)
        print("✓ 评估环境就绪\n")

        # ========== 6. 多次策略回放（返回分类指标） ==========
        print("🎯 [6/8] 策略回放评估...")
        (freq_total, auc_list_all, reward_list_all,
         kappa_list_all) = run_evaluation_episodes(
            model, eval_env, feature_cols
        )
        print("✓ 评估完成\n")

        # ========== 7. 分析特征频次 ==========
        print("📊 [7/8] 分析特征选择频次...", flush=True)
        top30_df = analyze_feature_frequency(freq_total, feature_cols)
        print("✓ 特征分析完成\n")

        # ========== 8. 创建可视化（传入分类指标） ==========
        print("📈 [8/8] 创建可视化图表...", flush=True)
        create_visualization(
            auc_list_all, reward_list_all,
            kappa_list_all)
        print("✓ 可视化完成\n")


        # ========== 总结 ==========
        total_time = time.time() - overall_start_time
        total_time_str = str(timedelta(seconds=int(total_time)))

        print("\n" + "="*60)
        print("          ✅ 所有任务完成！")
        print("="*60)
        print(f"完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"总用时: {total_time_str}")
        print(f"\n结果文件:")
        print(f"  📁 结果目录: {config.RESULTS_DIR}")
        print(f"  📄 日志文件: {config.LOG_FILE}")
        print(f"  📊 模型文件: ppo_policy.zip")
        print(f"  📈 特征频次: top30_variable_freq_avg.csv")
        print(f"  🖼️  可视化图: ppo_replay_auc_reward_avg.png")
        print("="*60 + "\n")

        logger.info(f"PPO主流程完成，总用时: {total_time_str}")

        # ========== 保存训练元信息（新增） ==========
        print("📝 [9/9] 保存训练元信息...", flush=True)
        total_timesteps = config.RL_NUM_EPISODES * config.MAX_STEPS
        save_training_metadata(total_timesteps, total_time, config.RESULTS_DIR)
        print("✓ 训练元信息保存完成\n")

    except KeyboardInterrupt:
        print("\n\n⚠️  程序被用户中断")
        logger.warning("程序被用户中断")
    except Exception as e:
        print(f"\n\n❌ 程序执行出错: {e}")
        logger.error(f"程序执行失败: {e}", exc_info=True)
        raise

if __name__ == "__main__":
    main()