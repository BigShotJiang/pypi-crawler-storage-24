"""
gwrf_shap_analysis.py
=====================
GWRF 模型深度 SHAP 空间分析模块

实现五个分析方向：
  方向1  元模型层 SHAP —— 基模型"空间贡献权重"及主导性分布图
  方向2  基模型层 SHAP —— 逐模型特征归因 + 空间化 + Moran's I
  方向3  空间平滑前后 SHAP 对比 —— 量化地理加权贡献 (ΔSHAP)
  方向4  SHAP 交互值 —— 特征间在空间上的联合作用
  方向5  SHAP 依赖图 + 空间分层 —— 因果机制区域异质性

使用方式（直接放在与 gwrf.py / predict_gwrf.py / config.py 同一文件夹下）：

    python gwrf_shap_analysis.py --experiment_dir <实验目录> [--top_features 9]

或在其他脚本中引入：

    from gwrf_shap_analysis import GWRFSHAPAnalyzer
    analyzer = GWRFSHAPAnalyzer(model, X, y, coords, top_vars, experiment_dir)
    analyzer.run_all()
"""

# ── 强制 Agg 后端（与 config.py 保持一致）──────────────────────
import os
os.environ['MPLBACKEND'] = 'Agg'
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import matplotlib
matplotlib.use('Agg', force=True)
# ───────────────────────────────────────────────────────────────

import sys
import logging
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.cm as cm
from matplotlib.gridspec import GridSpec
from pathlib import Path

warnings.filterwarnings("ignore")

logger = logging.getLogger("gwrf_shap")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s",
)


# ============================================================
#  辅助函数
# ============================================================

def _ensure_2d_shap(sv):
    """把 SHAP 输出统一整理为 2-D ndarray (n_samples, n_features)。"""
    if isinstance(sv, list):
        sv = sv[1] if len(sv) == 2 else sv[0]
    sv = np.array(sv)
    if sv.ndim == 3:          # (n_samples, n_features, 2) → 取正类
        sv = sv[:, :, 1]
    return sv


def _normalize_col(arr: np.ndarray) -> np.ndarray:
    """Min-Max 归一化至 [0, 1]，防除零。"""
    lo, hi = np.nanmin(arr), np.nanmax(arr)
    if hi == lo:
        return np.zeros_like(arr, dtype=float)
    return (arr - lo) / (hi - lo)


def _scatter_spatial(ax, x, y, values, title, cmap="RdBu_r", s=15, vmin=None, vmax=None):
    """通用地理散点图。"""
    vmin = vmin if vmin is not None else np.nanpercentile(values, 2)
    vmax = vmax if vmax is not None else np.nanpercentile(values, 98)
    sc = ax.scatter(x, y, c=values, cmap=cmap, s=s, vmin=vmin, vmax=vmax, alpha=0.8)
    plt.colorbar(sc, ax=ax, shrink=0.7)
    ax.set_title(title, fontsize=10)
    ax.set_xlabel("Longitude / X", fontsize=8)
    ax.set_ylabel("Latitude / Y", fontsize=8)
    ax.tick_params(labelsize=7)


def _compute_morans_i(values: np.ndarray, coords: np.ndarray, k: int = 8) -> float:
    """
    基于 KNN 权重矩阵计算 Moran's I 空间自相关系数。
    使用 k 个最近邻（默认 k=8）。
    """
    from scipy.spatial import cKDTree
    n = len(values)
    if n < 10:
        return np.nan
    tree = cKDTree(coords)
    _, idx = tree.query(coords, k=k + 1)   # 第一列是自身
    idx = idx[:, 1:]                        # 去掉自身

    # 构建稀疏权重矩阵（行归一化）
    z = values - np.nanmean(values)
    W_z = np.array([z[idx[i]].mean() for i in range(n)])
    numerator = (z * W_z).sum()
    denominator = (z ** 2).sum()
    if denominator == 0:
        return np.nan
    return n / (n * k) * numerator / denominator   # 简化版 Moran's I


# ============================================================
#  主分析类
# ============================================================

class GWRFSHAPAnalyzer:
    """
    Parameters
    ----------
    model        : 已训练的 GWRFEnsemble 实例
    X            : 原始特征矩阵，shape (n_samples, n_all_features)
    y            : 标签，shape (n_samples,)
    coords       : 地理坐标，shape (n_samples, 2)  列顺序 [lon, lat]
    top_vars     : 模型所用特征名列表，长度 == X.shape[1]（即已提取子集后的特征）
                   如果 X 是全特征矩阵则传入 feature_indices 对应的子集名
    experiment_dir : 结果保存目录
    sample_size  : SHAP 计算采样数（数据量大时控制速度）
    bg_size      : KernelSHAP 背景集大小
    random_state : 随机种子
    region_col   : 可选，coords 附带的地理分区列（字符串），用于方向5分层
    regions      : 可选，与 X 等长的区域标签数组，用于方向5分层
    """

    def __init__(
        self,
        model,
        X: np.ndarray,
        y: np.ndarray,
        coords: np.ndarray,
        top_vars: list,
        experiment_dir: str,
        sample_size: int = 300,
        bg_size: int = 50,
        random_state: int = 42,
        regions: np.ndarray = None,
    ):
        self.model = model
        self.X = X
        self.y = y
        self.coords = coords
        self.top_vars = top_vars
        self.n_features = len(top_vars)
        self.experiment_dir = experiment_dir
        self.sample_size = sample_size
        self.bg_size = bg_size
        self.rng = np.random.default_rng(random_state)
        self.random_state = random_state
        self.regions = regions

        self.out_dir = Path(experiment_dir) / "gwrf_shap_deep_analysis"
        self.out_dir.mkdir(parents=True, exist_ok=True)

        # 采样索引
        n = X.shape[0]
        self._sample_idx = self.rng.choice(n, min(sample_size, n), replace=False)
        self._bg_idx = self.rng.choice(n, min(bg_size, n), replace=False)

        self.X_sample = X[self._sample_idx]
        self.X_bg = X[self._bg_idx]
        self.coords_sample = coords[self._sample_idx]

        # 缓存：各方向计算结果
        self._meta_shap_values = None        # (n_sample, n_base_models)
        self._base_shap_dict = {}            # {"ModelName": (n_sample, n_features)}
        self._shap_unsmoothed = None         # (n_sample, n_features)  平滑前
        self._shap_smoothed = None           # (n_sample, n_features)  平滑后
        self._interaction_values = None      # (n_sample, n_features, n_features)

        logger.info(f"GWRFSHAPAnalyzer 初始化完成。输出目录: {self.out_dir}")
        logger.info(f"  样本数 {n}, 分析采样 {len(self._sample_idx)}, 背景集 {len(self._bg_idx)}")

    # ──────────────────────────────────────────────────────────
    #  方向1  元模型层 SHAP
    # ──────────────────────────────────────────────────────────

    def direction1_meta_shap(self):
        """
        对元模型（RandomForest 元学习器）做 TreeSHAP。
        输入空间：基模型预测概率向量 [p_RF, p_XGB, p_MaxEnt, ...]。
        输出：每个样本对每个基模型的 SHAP 依赖权重，并映射到地理空间。
        """
        import shap

        print("\n" + "="*60)
        print("  方向1：元模型层 SHAP —— 基模型空间贡献权重")
        print("="*60)

        # 获取元特征（基模型输出概率）
        meta_X_full = self._get_meta_X(self.X)            # (n_all, n_base)
        meta_X_sample = meta_X_full[self._sample_idx]     # (n_sample, n_base)
        base_names = self._get_base_model_names()

        # TreeSHAP（元模型是 RandomForest，直接支持）
        print("  计算 Meta TreeSHAP ...")
        try:
            explainer = shap.TreeExplainer(self.model.meta_model)
            sv = explainer(meta_X_sample)
            shap_vals = _ensure_2d_shap(
                sv.values if hasattr(sv, 'values') else explainer.shap_values(meta_X_sample)
            )
        except Exception as e:
            print(f"  TreeSHAP 失败，退回 KernelSHAP: {e}")
            explainer = shap.KernelExplainer(
                lambda x: self.model.meta_model.predict_proba(x)[:, 1],
                meta_X_full[self._bg_idx]
            )
            shap_vals = _ensure_2d_shap(explainer.shap_values(meta_X_sample, nsamples=100))

        # 维度对齐
        if shap_vals.shape[1] > len(base_names):
            shap_vals = shap_vals[:, :len(base_names)]

        self._meta_shap_values = shap_vals   # 缓存

        # ── 1a. 基模型平均贡献表 ──────────────────────────────
        mean_abs = np.abs(shap_vals).mean(axis=0)
        df_summary = pd.DataFrame({
            "base_model": base_names[:shap_vals.shape[1]],
            "mean_abs_shap": mean_abs
        }).sort_values("mean_abs_shap", ascending=False)
        p = self.out_dir / "dir1_meta_shap_summary.csv"
        df_summary.to_csv(p, index=False)
        print(f"  基模型贡献摘要:\n{df_summary.to_string(index=False)}")

        # ── 1b. 各基模型 SHAP 值散点（地理空间）────────────────
        n_base = shap_vals.shape[1]
        n_cols = min(n_base, 3)
        n_rows = (n_base + n_cols - 1) // n_cols
        fig, axes = plt.subplots(n_rows, n_cols, figsize=(6 * n_cols, 5 * n_rows))
        axes = np.array(axes).flatten() if n_base > 1 else [axes]

        for i, name in enumerate(base_names[:n_base]):
            _scatter_spatial(
                axes[i],
                self.coords_sample[:, 0], self.coords_sample[:, 1],
                shap_vals[:, i],
                title=f"SHAP: {name}  (φ_{name[:3]})",
                cmap="RdBu_r",
            )
        for ax in axes[n_base:]:
            ax.set_visible(False)

        fig.suptitle("Direction 1: Spatial Distribution of Base Model SHAP Contributions\n"
                     "(Red = positive trust, Blue = negative trust)", fontsize=13)
        plt.tight_layout()
        fig.savefig(self.out_dir / "dir1_meta_shap_spatial.png", dpi=200, bbox_inches="tight")
        plt.close(fig)
        print("  空间分布图已保存: dir1_meta_shap_spatial.png")

        # ── 1c. 主导基模型地图（argmax |SHAP|）───────────────
        dominant = np.argmax(np.abs(shap_vals), axis=1)   # (n_sample,)
        fig, ax = plt.subplots(figsize=(9, 6))
        cmap_dom = plt.cm.get_cmap("tab10", n_base)
        sc = ax.scatter(
            self.coords_sample[:, 0], self.coords_sample[:, 1],
            c=dominant, cmap=cmap_dom, vmin=-0.5, vmax=n_base - 0.5, s=20, alpha=0.85
        )
        cbar = plt.colorbar(sc, ax=ax, ticks=range(n_base))
        cbar.ax.set_yticklabels(base_names[:n_base])
        ax.set_title("Direction 1: Dominant Base Model per Location\n"
                     "(Which model 'has the final say' spatially)", fontsize=11)
        ax.set_xlabel("Longitude / X")
        ax.set_ylabel("Latitude / Y")
        plt.tight_layout()
        fig.savefig(self.out_dir / "dir1_dominant_model_map.png", dpi=200, bbox_inches="tight")
        plt.close(fig)
        print("  主导模型地图已保存: dir1_dominant_model_map.png")

        # ── 1d. 主导模型统计 ────────────────────────────────
        dom_counts = pd.Series(dominant).value_counts().sort_index()
        dom_counts.index = [base_names[i] for i in dom_counts.index]
        dom_counts.name = "n_dominant_pixels"
        dom_counts.to_csv(self.out_dir / "dir1_dominant_model_counts.csv", header=True)
        print(f"  主导模型像素分布:\n{dom_counts.to_string()}")
        print(f"  ✅ 方向1 完成\n")

        return df_summary, shap_vals

    # ──────────────────────────────────────────────────────────
    #  方向2  基模型层 SHAP
    # ──────────────────────────────────────────────────────────

    def direction2_base_model_shap(self, max_samples_tree: int = 500):
        """
        对每个支持 TreeSHAP 的基模型（RF/XGB）分别计算特征 SHAP，
        然后把值映射到地理空间，并计算 Moran's I。
        """
        import shap

        print("\n" + "="*60)
        print("  方向2：基模型层 SHAP —— 逐模型特征归因 + 空间化")
        print("="*60)

        feature_indices = list(range(self.n_features))
        X_sub_sample = self.X_sample    # 已经是子特征矩阵

        all_shap = {}          # model_name → (n_sample, n_features)
        morans_results = {}    # model_name → {feature: moran_i}

        for m in self.model.base_models:
            native = getattr(m, "model", m)
            name = native.__class__.__name__

            print(f"\n  [{name}] 计算 TreeSHAP ...")
            try:
                exp = shap.TreeExplainer(native)
                sv = exp.shap_values(X_sub_sample)
                sv = _ensure_2d_shap(sv)
                print(f"    TreeSHAP 成功 shape={sv.shape}")
            except Exception as e:
                print(f"    TreeSHAP 失败 ({e})，尝试 KernelSHAP ...")
                try:
                    def _pred(x, _m=native):
                        return _m.predict_proba(x)[:, 1]
                    bg = X_sub_sample[
                        self.rng.choice(len(X_sub_sample),
                                        min(20, len(X_sub_sample)), replace=False)
                    ]
                    kexp = shap.KernelExplainer(_pred, bg)
                    sv = _ensure_2d_shap(kexp.shap_values(X_sub_sample, nsamples=50))
                    print(f"    KernelSHAP 成功 shape={sv.shape}")
                except Exception as e2:
                    print(f"    跳过 {name}: {e2}")
                    continue

            # 截断至特征数
            sv = sv[:, :self.n_features]
            all_shap[name] = sv
            self._base_shap_dict[name] = sv

            # ── 2a. 特征平均 |SHAP| ──────────────────────────
            mean_abs = np.abs(sv).mean(axis=0)
            df_imp = pd.DataFrame({
                "feature": self.top_vars,
                f"mean_abs_shap_{name}": mean_abs
            }).sort_values(f"mean_abs_shap_{name}", ascending=False)
            df_imp.to_csv(
                self.out_dir / f"dir2_{name}_feature_shap.csv", index=False
            )

            # ── 2b. Moran's I ────────────────────────────────
            moran_dict = {}
            for fi, fname in enumerate(self.top_vars):
                mi = _compute_morans_i(sv[:, fi], self.coords_sample)
                moran_dict[fname] = mi
            morans_results[name] = moran_dict

            df_moran = pd.DataFrame(list(moran_dict.items()),
                                    columns=["feature", "morans_i"])
            df_moran = df_moran.sort_values("morans_i", ascending=False)
            df_moran.to_csv(
                self.out_dir / f"dir2_{name}_morans_i.csv", index=False
            )
            print(f"    Top-5 Moran's I ({name}):")
            print(f"    {df_moran.head(5).to_string(index=False)}")

            # ── 2c. 空间散点图（Top-6 特征）───────────────────
            top6_feats = df_imp["feature"].values[:6]
            fig, axes = plt.subplots(2, 3, figsize=(16, 10))
            axes = axes.flatten()
            for ai, feat in enumerate(top6_feats):
                fi = self.top_vars.index(feat)
                _scatter_spatial(
                    axes[ai],
                    self.coords_sample[:, 0], self.coords_sample[:, 1],
                    sv[:, fi],
                    title=f"{feat}\n(Moran's I={moran_dict[feat]:.3f})",
                )
            fig.suptitle(
                f"Direction 2: {name} Feature SHAP — Top-6 Spatial Distribution\n"
                f"Color = SHAP value (positive/negative contribution)",
                fontsize=12
            )
            plt.tight_layout()
            fig.savefig(
                self.out_dir / f"dir2_{name}_spatial_shap.png",
                dpi=200, bbox_inches="tight"
            )
            plt.close(fig)

        # ── 2d. 跨模型特征归因对比 ──────────────────────────
        if len(all_shap) >= 2:
            names = list(all_shap.keys())
            mean_abs_list = {
                n: np.abs(all_shap[n]).mean(axis=0) for n in names
            }
            df_compare = pd.DataFrame(
                mean_abs_list, index=self.top_vars
            ).reset_index().rename(columns={"index": "feature"})
            df_compare.to_csv(
                self.out_dir / "dir2_cross_model_shap_comparison.csv", index=False
            )

            fig, ax = plt.subplots(figsize=(10, max(5, self.n_features * 0.45)))
            x_pos = np.arange(self.n_features)
            width = 0.8 / len(names)
            for i, n in enumerate(names):
                ax.barh(
                    x_pos + i * width,
                    mean_abs_list[n],
                    height=width * 0.9,
                    label=n
                )
            ax.set_yticks(x_pos + width * (len(names) - 1) / 2)
            ax.set_yticklabels(self.top_vars, fontsize=8)
            ax.invert_yaxis()
            ax.set_xlabel("Mean |SHAP|")
            ax.set_title("Direction 2: Cross-Model Feature SHAP Attribution Comparison")
            ax.legend()
            plt.tight_layout()
            fig.savefig(
                self.out_dir / "dir2_cross_model_comparison.png",
                dpi=200, bbox_inches="tight"
            )
            plt.close(fig)
            print("\n  跨模型对比图已保存: dir2_cross_model_comparison.png")

        print(f"  ✅ 方向2 完成\n")
        return all_shap, morans_results

    # ──────────────────────────────────────────────────────────
    #  方向3  空间平滑前后 SHAP 对比
    # ──────────────────────────────────────────────────────────

    def direction3_smoothing_delta_shap(self):
        """
        分别对 meta_X（未平滑）和 weighted_meta_X（空间平滑后）
        做 KernelSHAP，比较 ΔSHAP，量化地理加权的贡献。
        """
        import shap

        print("\n" + "="*60)
        print("  方向3：空间平滑前后 SHAP 对比 —— 量化地理加权贡献")
        print("="*60)

        feature_indices = list(range(self.n_features))

        # ── 构造"未平滑"预测函数 ──────────────────────────────
        def predict_unsmoothed(x):
            """直接用基模型概率向量送入元模型，不做空间插值。"""
            if x.ndim == 1:
                x = x.reshape(1, -1)
            meta_X = self._get_meta_X(x)
            return self.model.meta_model.predict_proba(meta_X)[:, 1]

        # ── 构造"空间平滑后"预测函数 ──────────────────────────
        # 需要坐标——这里用采样点坐标近似（固定空间上下文）
        sample_coords = self.coords_sample

        def predict_smoothed(x):
            """用 spatial_alpha 混合空间插值后送入元模型。"""
            if x.ndim == 1:
                x = x.reshape(1, -1)
            meta_X = self._get_meta_X(x)
            from scipy.spatial.distance import cdist
            if self.model.train_coords is None:
                return self.model.meta_model.predict_proba(meta_X)[:, 1]
            bw = self.model._bandwidth_val or self.model._resolve_bandwidth(self.model.train_coords)
            dists = cdist(meta_X[:, :2].reshape(-1, 2) if meta_X.shape[1] >= 2
                          else np.zeros((len(x), 2)),
                          self.model.train_coords, metric="euclidean")
            weights = np.exp(-(dists**2) / (bw**2))
            weights /= (weights.sum(axis=1, keepdims=True) + 1e-10)
            spatial_interp = weights @ self.model.train_meta_features
            wm = (self.model.spatial_alpha * meta_X
                  + (1 - self.model.spatial_alpha) * spatial_interp)
            return self.model.meta_model.predict_proba(wm)[:, 1]

        # ── 用 KernelSHAP 分别计算（以原始特征为输入） ────────
        print("  计算未平滑 SHAP ...")
        bg_shap = self.X_bg
        exp_unsmooth = shap.KernelExplainer(predict_unsmoothed, bg_shap)
        sv_unsmooth = _ensure_2d_shap(
            exp_unsmooth.shap_values(self.X_sample, nsamples=80)
        )

        print("  计算空间平滑后 SHAP ...")
        exp_smooth = shap.KernelExplainer(predict_smoothed, bg_shap)
        sv_smooth = _ensure_2d_shap(
            exp_smooth.shap_values(self.X_sample, nsamples=80)
        )

        # 对齐列数
        sv_unsmooth = sv_unsmooth[:, :self.n_features]
        sv_smooth = sv_smooth[:, :self.n_features]

        self._shap_unsmoothed = sv_unsmooth
        self._shap_smoothed = sv_smooth

        delta_shap = sv_smooth - sv_unsmooth     # (n_sample, n_features)

        # ── 3a. ΔSHAP 统计摘要 ───────────────────────────────
        delta_mean = delta_shap.mean(axis=0)
        delta_abs_mean = np.abs(delta_shap).mean(axis=0)
        df_delta = pd.DataFrame({
            "feature": self.top_vars,
            "delta_shap_mean": delta_mean,
            "delta_shap_abs_mean": delta_abs_mean,
        }).sort_values("delta_shap_abs_mean", ascending=False)
        df_delta.to_csv(self.out_dir / "dir3_delta_shap_summary.csv", index=False)
        print(f"\n  ΔSHAP 摘要（|Δ|均值最大的特征代表地理加权影响最大）:")
        print(df_delta.head(8).to_string(index=False))

        # ── 3b. 前后对比条形图 ───────────────────────────────
        abs_unsmooth = np.abs(sv_unsmooth).mean(axis=0)
        abs_smooth = np.abs(sv_smooth).mean(axis=0)

        fig, ax = plt.subplots(figsize=(10, max(5, self.n_features * 0.45)))
        y = np.arange(self.n_features)
        ax.barh(y - 0.2, abs_unsmooth, height=0.35, label="Before smoothing", color="#5B9BD5")
        ax.barh(y + 0.2, abs_smooth, height=0.35, label="After smoothing", color="#ED7D31")
        ax.set_yticks(y)
        ax.set_yticklabels(self.top_vars, fontsize=8)
        ax.invert_yaxis()
        ax.set_xlabel("Mean |SHAP|")
        ax.set_title("Direction 3: SHAP Before vs After Spatial Smoothing\n"
                     "(Difference = contribution of geographic weighting)")
        ax.legend()
        plt.tight_layout()
        fig.savefig(self.out_dir / "dir3_shap_before_after_smoothing.png",
                    dpi=200, bbox_inches="tight")
        plt.close(fig)

        # ── 3c. ΔSHAP 空间分布（每个样本点的 Δ 大小，代表空间效应强度）──
        delta_norm = np.abs(delta_shap).sum(axis=1)   # 各点 ΔSHAP 总量

        fig, ax = plt.subplots(figsize=(9, 6))
        _scatter_spatial(
            ax,
            self.coords_sample[:, 0], self.coords_sample[:, 1],
            delta_norm,
            title="Direction 3: Total |ΔSHAP| per Location\n"
                  "(High value = prediction strongly influenced by spatial neighbors)",
            cmap="YlOrRd",
        )
        plt.tight_layout()
        fig.savefig(self.out_dir / "dir3_delta_shap_spatial.png",
                    dpi=200, bbox_inches="tight")
        plt.close(fig)

        # ── 3d. 逐特征 ΔSHAP 空间图（Top-4）────────────────
        top4_feats = df_delta["feature"].values[:4]
        fig, axes = plt.subplots(2, 2, figsize=(13, 10))
        axes = axes.flatten()
        for ai, feat in enumerate(top4_feats):
            fi = self.top_vars.index(feat)
            _scatter_spatial(
                axes[ai],
                self.coords_sample[:, 0], self.coords_sample[:, 1],
                delta_shap[:, fi],
                title=f"ΔSHAP: {feat}\n(pos=smoothing increased contribution)",
                cmap="coolwarm",
            )
        fig.suptitle("Direction 3: Per-Feature ΔSHAP Spatial Distribution", fontsize=12)
        plt.tight_layout()
        fig.savefig(self.out_dir / "dir3_per_feature_delta_shap.png",
                    dpi=200, bbox_inches="tight")
        plt.close(fig)

        print(f"  ✅ 方向3 完成\n")
        return df_delta, delta_shap

    # ──────────────────────────────────────────────────────────
    #  方向4  SHAP 交互值
    # ──────────────────────────────────────────────────────────

    def direction4_shap_interactions(self, n_pairs: int = 10):
        """
        对 RF 基模型（或 XGB）计算 TreeSHAP Interaction Values，
        找出特征对之间的空间联合作用。
        """
        import shap

        print("\n" + "="*60)
        print("  方向4：SHAP 交互值 —— 特征间空间联合作用")
        print("="*60)

        # 优先选 RF，退一步选任意树模型
        target_model = None
        target_name = ""
        for m in self.model.base_models:
            native = getattr(m, "model", m)
            cls_name = native.__class__.__name__
            if "RandomForest" in cls_name or "Forest" in cls_name:
                target_model = native
                target_name = cls_name
                break
        if target_model is None:
            for m in self.model.base_models:
                native = getattr(m, "model", m)
                cls_name = native.__class__.__name__
                if "Boost" in cls_name or "XGB" in cls_name or "Tree" in cls_name:
                    target_model = native
                    target_name = cls_name
                    break

        if target_model is None:
            print("  ⚠️  未找到树模型，跳过方向4。")
            return None

        print(f"  使用 {target_name} 计算 SHAP Interaction Values ...")
        print(f"  采样 {len(self.X_sample)} 个点（交互值计算耗时较长）...")

        try:
            exp = shap.TreeExplainer(target_model)
            # interaction_values: (n_sample, n_features, n_features)
            iv = exp.shap_interaction_values(self.X_sample)
            if isinstance(iv, list):
                iv = iv[1] if len(iv) == 2 else iv[0]
            iv = np.array(iv)

            # 如果是 3D (n_sample, nf, nf)
            if iv.ndim == 4:     # 二分类时有 (n_sample, nf, nf, 2)
                iv = iv[:, :, :, 1]

            iv = iv[:, :self.n_features, :self.n_features]
            self._interaction_values = iv
            print(f"  Interaction values shape: {iv.shape}")
        except Exception as e:
            print(f"  ⚠️  交互值计算失败: {e}")
            return None

        # ── 4a. 全局交互热图 ─────────────────────────────────
        mean_interaction = np.abs(iv).mean(axis=0)   # (nf, nf)
        np.fill_diagonal(mean_interaction, 0)        # 去自身交互

        df_inter = pd.DataFrame(
            mean_interaction,
            index=self.top_vars,
            columns=self.top_vars
        )
        df_inter.to_csv(self.out_dir / "dir4_shap_interaction_matrix.csv")

        fig, ax = plt.subplots(figsize=(max(8, self.n_features * 0.7),
                                        max(7, self.n_features * 0.7)))
        import matplotlib.colors as mcolors
        im = ax.imshow(mean_interaction, cmap="Oranges", aspect="auto")
        ax.set_xticks(range(self.n_features))
        ax.set_yticks(range(self.n_features))
        ax.set_xticklabels(self.top_vars, rotation=45, ha="right", fontsize=8)
        ax.set_yticklabels(self.top_vars, fontsize=8)
        plt.colorbar(im, ax=ax, label="Mean |Interaction SHAP|")
        ax.set_title(f"Direction 4: Feature Interaction SHAP Heatmap ({target_name})\n"
                     "Brighter = stronger joint contribution", fontsize=11)
        plt.tight_layout()
        fig.savefig(self.out_dir / "dir4_interaction_heatmap.png",
                    dpi=200, bbox_inches="tight")
        plt.close(fig)

        # ── 4b. Top-N 交互对 ──────────────────────────────────
        triu = np.triu_indices(self.n_features, k=1)
        pairs = [(self.top_vars[i], self.top_vars[j], mean_interaction[i, j])
                 for i, j in zip(*triu)]
        pairs.sort(key=lambda x: -x[2])
        df_top_pairs = pd.DataFrame(pairs[:n_pairs],
                                    columns=["feature_i", "feature_j", "mean_abs_interaction"])
        df_top_pairs.to_csv(self.out_dir / "dir4_top_interaction_pairs.csv", index=False)
        print(f"\n  Top-{n_pairs} 交互对:")
        print(df_top_pairs.to_string(index=False))

        # ── 4c. Top-4 交互对的空间分布 ────────────────────────
        top4_pairs = df_top_pairs.head(4)
        fig, axes = plt.subplots(2, 2, figsize=(13, 10))
        axes = axes.flatten()

        for ai, row in enumerate(top4_pairs.itertuples()):
            fi = self.top_vars.index(row.feature_i)
            fj = self.top_vars.index(row.feature_j)
            interaction_vals = iv[:, fi, fj]   # per-sample interaction

            _scatter_spatial(
                axes[ai],
                self.coords_sample[:, 0], self.coords_sample[:, 1],
                interaction_vals,
                title=f"{row.feature_i} × {row.feature_j}\n"
                      f"(mean|interaction|={row.mean_abs_interaction:.4f})",
                cmap="PuOr",
            )
        fig.suptitle(
            "Direction 4: Top-4 Feature Interaction SHAP — Spatial Distribution\n"
            "(Positive = synergy, Negative = antagonism)",
            fontsize=11
        )
        plt.tight_layout()
        fig.savefig(self.out_dir / "dir4_top_interactions_spatial.png",
                    dpi=200, bbox_inches="tight")
        plt.close(fig)

        print(f"  ✅ 方向4 完成\n")
        return df_top_pairs, iv

    # ──────────────────────────────────────────────────────────
    #  方向5  SHAP 依赖图 + 空间分层
    # ──────────────────────────────────────────────────────────

    def direction5_stratified_dependence(
        self,
        shap_values: np.ndarray = None,
        n_lat_bins: int = 4,
        top_n_features: int = 3,
    ):
        """
        按纬度带（或用户传入的 self.regions）将样本分层，
        分别画每个 Top 特征的 SHAP Dependence Plot，
        揭示生态响应的区域异质性。

        Parameters
        ----------
        shap_values   : 可选，传入已有的 (n_sample, n_features) SHAP 矩阵；
                        为 None 时自动用 KernelSHAP 计算。
        n_lat_bins    : 按纬度等分的分区数（当 self.regions 为 None 时启用）
        top_n_features: 绘图的 Top 特征数
        """
        import shap

        print("\n" + "="*60)
        print("  方向5：SHAP 依赖图 + 空间分层 —— 区域异质性")
        print("="*60)

        # ── 获取 SHAP 值 ──────────────────────────────────────
        if shap_values is None:
            if self._shap_unsmoothed is not None:
                shap_values = self._shap_unsmoothed
                print("  使用方向3 缓存的 SHAP 值（未平滑）")
            else:
                print("  计算 SHAP 值（KernelSHAP）...")
                feature_indices = list(range(self.n_features))

                def _pred(x):
                    if x.ndim == 1:
                        x = x.reshape(1, -1)
                    meta = self._get_meta_X(x)
                    return self.model.meta_model.predict_proba(meta)[:, 1]

                exp = shap.KernelExplainer(_pred, self.X_bg)
                shap_values = _ensure_2d_shap(
                    exp.shap_values(self.X_sample, nsamples=80)
                )[:, :self.n_features]

        # ── 确定地理分区标签 ─────────────────────────────────
        if self.regions is not None:
            region_labels = np.array(self.regions)[self._sample_idx]
            region_ids = np.unique(region_labels)
            print(f"  使用用户提供的区域标签，共 {len(region_ids)} 个分区")
        else:
            lat = self.coords_sample[:, 1]
            bins = np.quantile(lat, np.linspace(0, 1, n_lat_bins + 1))
            bins[0] -= 1e-6;  bins[-1] += 1e-6
            region_labels = np.digitize(lat, bins) - 1
            region_ids = np.arange(n_lat_bins)
            print(f"  按纬度等分 {n_lat_bins} 个分区，分位点: {np.round(bins, 3)}")

        # ── Top 特征（按全局 |SHAP| 均值）─────────────────────
        global_imp = np.abs(shap_values).mean(axis=0)
        top_feat_idx = np.argsort(global_imp)[::-1][:top_n_features]
        top_feat_names = [self.top_vars[i] for i in top_feat_idx]

        # ── 逐特征绘制分层 Dependence 图 ──────────────────────
        for fi, fname in zip(top_feat_idx, top_feat_names):
            feat_vals = self.X_sample[:, fi]
            shap_col = shap_values[:, fi]

            n_regions = len(region_ids)
            n_cols = min(n_regions, 4)
            n_rows = (n_regions + n_cols - 1) // n_cols

            fig, axes = plt.subplots(
                n_rows, n_cols,
                figsize=(5 * n_cols, 4.5 * n_rows),
                sharey=False
            )
            axes = np.array(axes).flatten()

            for ri, rid in enumerate(region_ids):
                mask = region_labels == rid
                if mask.sum() < 5:
                    axes[ri].set_visible(False)
                    continue
                ax = axes[ri]
                ax.scatter(feat_vals[mask], shap_col[mask],
                           c=self.coords_sample[mask, 1], cmap="viridis",
                           s=20, alpha=0.7)
                # 拟合趋势线
                try:
                    z = np.polyfit(feat_vals[mask], shap_col[mask], 2)
                    p = np.poly1d(z)
                    xp = np.linspace(feat_vals[mask].min(), feat_vals[mask].max(), 100)
                    ax.plot(xp, p(xp), "r-", linewidth=1.5, alpha=0.8)
                except Exception:
                    pass
                ax.axhline(0, color="gray", linewidth=0.8, linestyle="--")
                ax.set_xlabel(fname, fontsize=9)
                ax.set_ylabel("SHAP value", fontsize=9)
                label = (str(rid) if self.regions is not None
                         else f"Lat-zone {rid + 1}")
                ax.set_title(label, fontsize=9)

            for ax in axes[n_regions:]:
                ax.set_visible(False)

            fig.suptitle(
                f"Direction 5: SHAP Dependence Plot — {fname}\n"
                f"Stratified by geographic region (color=latitude)",
                fontsize=11
            )
            plt.tight_layout()
            fig.savefig(
                self.out_dir / f"dir5_dependence_{fname}.png",
                dpi=200, bbox_inches="tight"
            )
            plt.close(fig)
            print(f"  分层依赖图已保存: dir5_dependence_{fname}.png")

        # ── 5b. 分区特征重要性热图 ────────────────────────────
        region_imp = {}
        for rid in region_ids:
            mask = region_labels == rid
            if mask.sum() < 5:
                continue
            label = (str(rid) if self.regions is not None
                     else f"Zone-{rid + 1}")
            region_imp[label] = np.abs(shap_values[mask]).mean(axis=0)

        if region_imp:
            df_reg_imp = pd.DataFrame(
                region_imp, index=self.top_vars
            ).T
            df_reg_imp.to_csv(self.out_dir / "dir5_regional_feature_importance.csv")

            fig, ax = plt.subplots(
                figsize=(max(8, self.n_features * 0.8),
                         max(4, len(region_imp) * 0.7))
            )
            im = ax.imshow(df_reg_imp.values, cmap="YlOrRd", aspect="auto")
            ax.set_xticks(range(self.n_features))
            ax.set_xticklabels(self.top_vars, rotation=45, ha="right", fontsize=8)
            ax.set_yticks(range(len(df_reg_imp)))
            ax.set_yticklabels(df_reg_imp.index, fontsize=9)
            plt.colorbar(im, ax=ax, label="Mean |SHAP|")
            ax.set_title(
                "Direction 5: Feature Importance by Geographic Region\n"
                "(Non-stationarity: same feature, different regional importance)",
                fontsize=11
            )
            plt.tight_layout()
            fig.savefig(self.out_dir / "dir5_regional_importance_heatmap.png",
                        dpi=200, bbox_inches="tight")
            plt.close(fig)
            print("  分区重要性热图已保存: dir5_regional_importance_heatmap.png")

        print(f"  ✅ 方向5 完成\n")
        return shap_values

    # ──────────────────────────────────────────────────────────
    #  一键运行全部方向
    # ──────────────────────────────────────────────────────────

    def run_all(
        self,
        directions: list = None,
        dir4_n_pairs: int = 10,
        dir5_n_lat_bins: int = 4,
        dir5_top_n: int = 3,
    ):
        """
        批量运行指定方向（默认全部）。

        Parameters
        ----------
        directions : list of int, e.g. [1, 2, 3]；None 则全部运行
        """
        directions = directions or [1, 2, 3, 4, 5]
        print("\n" + "#"*60)
        print("  GWRF 深度 SHAP 空间分析 — 全方向运行")
        print(f"  输出目录: {self.out_dir}")
        print("#"*60)

        results = {}

        if 1 in directions:
            try:
                results["dir1"] = self.direction1_meta_shap()
            except Exception as e:
                logger.error(f"方向1 失败: {e}", exc_info=True)
                print(f"  ❌ 方向1 失败: {e}")

        if 2 in directions:
            try:
                results["dir2"] = self.direction2_base_model_shap()
            except Exception as e:
                logger.error(f"方向2 失败: {e}", exc_info=True)
                print(f"  ❌ 方向2 失败: {e}")

        if 3 in directions:
            try:
                results["dir3"] = self.direction3_smoothing_delta_shap()
            except Exception as e:
                logger.error(f"方向3 失败: {e}", exc_info=True)
                print(f"  ❌ 方向3 失败: {e}")

        if 4 in directions:
            try:
                results["dir4"] = self.direction4_shap_interactions(n_pairs=dir4_n_pairs)
            except Exception as e:
                logger.error(f"方向4 失败: {e}", exc_info=True)
                print(f"  ❌ 方向4 失败: {e}")

        if 5 in directions:
            try:
                sv5 = (self._shap_unsmoothed
                       if self._shap_unsmoothed is not None else None)
                results["dir5"] = self.direction5_stratified_dependence(
                    shap_values=sv5,
                    n_lat_bins=dir5_n_lat_bins,
                    top_n_features=dir5_top_n,
                )
            except Exception as e:
                logger.error(f"方向5 失败: {e}", exc_info=True)
                print(f"  ❌ 方向5 失败: {e}")

        print("\n" + "#"*60)
        print(f"  ✅ 全部完成！结果保存在: {self.out_dir}")
        print("#"*60)
        return results

    # ──────────────────────────────────────────────────────────
    #  内部工具
    # ──────────────────────────────────────────────────────────

    def _get_meta_X(self, X: np.ndarray) -> np.ndarray:
        """
        根据输入 X（子特征矩阵，已只含 top_vars 列），
        调用所有基模型得到元特征矩阵 (n_samples, n_base)。
        """
        base_probs = []
        fn = self.top_vars
        for m in self.model.base_models:
            try:
                import inspect
                sig = inspect.signature(m.predict_proba).parameters
                if "feature_names" in sig:
                    p = m.predict_proba(X, feature_names=fn)
                else:
                    p = m.predict_proba(X)
            except Exception:
                p = m.predict_proba(X)
            base_probs.append(np.array(p).reshape(-1, 1))
        return np.hstack(base_probs)

    def _get_base_model_names(self) -> list:
        names = []
        for m in self.model.base_models:
            native = getattr(m, "model", m)
            names.append(native.__class__.__name__)
        return names


# ============================================================
#  命令行入口
# ============================================================

def _parse_args():
    import argparse
    p = argparse.ArgumentParser(
        description="GWRF 深度 SHAP 空间分析（五方向）"
    )
    p.add_argument("--experiment_dir", required=True,
                   help="实验目录（内含已保存的 gwrf_ensemble_model.pkl）")
    p.add_argument("--top_features", type=int, default=None,
                   help="Top 特征数（默认从 config 读取）")
    p.add_argument("--directions", type=int, nargs="+", default=None,
                   help="运行指定方向，如 --directions 1 2 3（默认全部）")
    p.add_argument("--sample_size", type=int, default=300,
                   help="SHAP 采样数（默认 300）")
    p.add_argument("--bg_size", type=int, default=50,
                   help="KernelSHAP 背景集大小（默认 50）")
    p.add_argument("--n_lat_bins", type=int, default=4,
                   help="方向5 纬度分区数（默认 4）")
    return p.parse_args()


def main():
    args = _parse_args()

    from . import config
    import joblib

    # ── 加载模型 ──────────────────────────────────────────────
    experiment_dir = args.experiment_dir
    model_path = os.path.join(experiment_dir, "gwrf_ensemble_model.pkl")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"找不到模型文件: {model_path}")

    print(f"加载模型: {model_path}")
    model_data = joblib.load(model_path)
    ensemble_model = model_data["ensemble_model"]
    top_vars = model_data["top_variables"]

    # ── 加载数据 ──────────────────────────────────────────────
    n_top = args.top_features or len(top_vars)
    top_vars = top_vars[:n_top]

    train_df = pd.read_csv(config.PREPROCESSED_TRAIN_DATA)
    y = train_df["presence"].values
    coords = train_df.iloc[:, :2].values
    X = train_df[top_vars].values

    print(f"训练数据: X={X.shape}, y={y.shape}, coords={coords.shape}")
    print(f"特征列表: {top_vars}")

    # ── 构建分析器并运行 ──────────────────────────────────────
    analyzer = GWRFSHAPAnalyzer(
        model=ensemble_model,
        X=X,
        y=y,
        coords=coords,
        top_vars=top_vars,
        experiment_dir=experiment_dir,
        sample_size=args.sample_size,
        bg_size=args.bg_size,
    )

    analyzer.run_all(
        directions=args.directions,
        dir5_n_lat_bins=args.n_lat_bins,
    )


if __name__ == "__main__":
    main()