"""
gwrf_shap_tif.py
================
基于已有适生区预测 TIF，生成 GWRF SHAP 空间分析栅格

前提条件：
  - gwrf_area_suitability_pred.tif 已存在（提供空间参考 + 范围）
  - gwrf_ensemble_model.pkl 已存在（包含训练好的 GWRFEnsemble）
  - 与 gwrf.py / config.py 放在同一文件夹

生成内容：
  方向1  dominant_model.tif          —— 每个像素由哪个基模型主导（整数编码）
  方向2  shap_<feature>.tif          —— 每个特征的 SHAP 贡献度空间分布
  方向3  delta_shap_<feature>.tif    —— 空间平滑前后 ΔSHAP
           delta_shap_total.tif      —— 各特征 |ΔSHAP| 总和（地理加权效应强度）
  方向4  interaction_<fi>_x_<fj>.tif —— Top 交互对的空间联合作用

运行方式：
  python gwrf_shap_tif.py \
      --experiment_dir "D:\ginkgo\code\ensemble\results\experiment_20260319_192348_top9_bio1_gwrf" \
      --directions 1 2 3 4

可选参数：
  --n_bg        KernelSHAP 背景集大小（默认 50，越大越准但越慢）
  --n_sample    SHAP 采样训练点数（默认 200）
  --chunk_size  栅格分块预测大小（默认 50000，内存不足时调小）
  --top_pairs   方向4 输出的交互对数量（默认 5）
  --interp      插值方式：linear（默认）/ nearest / cubic
"""

import os, sys, warnings, logging
os.environ['MPLBACKEND'] = 'Agg'
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import joblib
import rasterio
from rasterio.transform import rowcol
from scipy.interpolate import griddata
from pathlib import Path

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("gwrf_shap_tif")


# ============================================================
#  工具函数
# ============================================================

def _ensure_2d_shap(sv):
    if isinstance(sv, list):
        sv = sv[1] if len(sv) == 2 else sv[0]
    sv = np.array(sv)
    if sv.ndim == 3:
        sv = sv[:, :, 1]
    return sv


def _load_reference_tif(tif_path: str):
    """读取参考 TIF，返回 meta、空间范围内所有像素的经纬度坐标数组。"""
    with rasterio.open(tif_path) as src:
        meta = src.meta.copy()
        height, width = src.height, src.width
        transform = src.transform
        nodata = src.nodata

    # 生成全图像素中心点坐标 (lon, lat)
    rows, cols = np.indices((height, width))
    xs, ys = rasterio.transform.xy(transform, rows.flatten(), cols.flatten())
    coords_all = np.column_stack([xs, ys])   # (H*W, 2)

    return meta, coords_all, (height, width)


def _interpolate_to_grid(
    sample_coords: np.ndarray,   # (n_sample, 2) 训练点坐标
    sample_values: np.ndarray,   # (n_sample,)   每个点的 SHAP 值
    grid_coords: np.ndarray,     # (H*W, 2)      全图像素坐标
    method: str = "linear",
) -> np.ndarray:
    """
    把稀疏采样点的 SHAP 值，插值到全图每个像素。
    返回 shape (H*W,) 的数组。
    """
    fill = np.nanmean(sample_values)
    result = griddata(
        sample_coords, sample_values, grid_coords,
        method=method, fill_value=fill
    )
    # linear/cubic 边缘可能出现 nan，用 nearest 补洞
    nan_mask = np.isnan(result)
    if nan_mask.any():
        result[nan_mask] = griddata(
            sample_coords, sample_values, grid_coords[nan_mask],
            method="nearest", fill_value=fill
        )
    return result.astype(np.float32)


def _save_tif(array: np.ndarray, shape: tuple, meta: dict, path: str):
    """保存单波段 float32 TIF。"""
    out_meta = meta.copy()
    out_meta.update(dtype="float32", count=1, compress="lzw", nodata=np.nan)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with rasterio.open(path, "w", **out_meta) as dst:
        dst.write(array.reshape(shape).astype(np.float32), 1)
    logger.info(f"已保存: {path}")


def _save_int_tif(array: np.ndarray, shape: tuple, meta: dict, path: str):
    """保存单波段 int16 TIF（用于主导模型编码）。"""
    out_meta = meta.copy()
    out_meta.update(dtype="int16", count=1, compress="lzw", nodata=-1)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with rasterio.open(path, "w", **out_meta) as dst:
        dst.write(array.reshape(shape).astype(np.int16), 1)
    logger.info(f"已保存: {path}")


# ============================================================
#  主类
# ============================================================

class GWRFSHAPTifGenerator:
    """
    Parameters
    ----------
    model        : 已训练的 GWRFEnsemble 实例
    X_train      : 训练特征矩阵 (n_train, n_features)
    coords_train : 训练点坐标  (n_train, 2)  [lon, lat]
    top_vars     : 特征名列表
    ref_tif      : 参考 TIF 路径（适生区预测结果）
    out_dir      : TIF 输出目录
    n_sample     : SHAP 计算采样训练点数
    n_bg         : KernelSHAP 背景集大小
    interp       : 插值方式 linear / nearest / cubic
    random_state : 随机种子
    """

    def __init__(
        self,
        model,
        X_train: np.ndarray,
        coords_train: np.ndarray,
        top_vars: list,
        ref_tif: str,
        out_dir: str,
        n_sample: int = 200,
        n_bg: int = 50,
        interp: str = "linear",
        random_state: int = 42,
    ):
        self.model = model
        self.X_train = X_train
        self.coords_train = coords_train
        self.top_vars = top_vars
        self.n_features = len(top_vars)
        self.ref_tif = ref_tif
        self.out_dir = Path(out_dir)
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.interp = interp
        self.rng = np.random.default_rng(random_state)

        # 采样索引
        n = X_train.shape[0]
        self._sidx = self.rng.choice(n, min(n_sample, n), replace=False)
        self._bidx = self.rng.choice(n, min(n_bg, n), replace=False)
        self.X_sample = X_train[self._sidx]
        self.X_bg = X_train[self._bidx]
        self.coords_sample = coords_train[self._sidx]

        # 读取参考 TIF
        print(f"  读取参考 TIF: {ref_tif}")
        self.ref_meta, self.grid_coords, self.grid_shape = _load_reference_tif(ref_tif)
        print(f"  栅格尺寸: {self.grid_shape[1]}×{self.grid_shape[0]} = {np.prod(self.grid_shape):,} 像素")

        # 缓存
        self._meta_shap = None     # (n_sample, n_base)
        self._feat_shap = None     # (n_sample, n_features)
        self._feat_shap_unsmooth = None
        self._feat_shap_smooth = None
        self._base_names = self._get_base_names()

        print(f"  基模型: {self._base_names}")
        print(f"  特征数: {self.n_features}")
        print(f"  SHAP 采样点: {len(self._sidx)}, 背景集: {len(self._bidx)}")

    # ──────────────────────────────────────────────────────────
    #  方向1  主导基模型 TIF
    # ──────────────────────────────────────────────────────────

    def direction1_dominant_model_tif(self):
        """
        每个栅格像素：哪个基模型的 |SHAP| 贡献最大。
        输出：dominant_model.tif（整数，0=RF，1=XGB，2=MaxEnt...）
              base_model_legend.csv（编码 → 模型名）
        """
        import shap
        print("\n" + "="*60)
        print("  方向1：主导基模型 TIF")
        print("="*60)

        meta_shap = self._get_meta_shap()   # (n_sample, n_base)
        n_base = meta_shap.shape[1]
        names = self._base_names[:n_base]

        # 用训练采样点的 dominant 插值到全图
        # 思路：对每个基模型单独插值 |SHAP| 值，再取 argmax
        n_pixels = np.prod(self.grid_shape)
        shap_grids = np.zeros((n_pixels, n_base), dtype=np.float32)

        for i in range(n_base):
            vals = np.abs(meta_shap[:, i])
            shap_grids[:, i] = _interpolate_to_grid(
                self.coords_sample, vals, self.grid_coords, method=self.interp
            )
            print(f"    基模型 [{names[i]}] 插值完成")

        dominant = np.argmax(shap_grids, axis=1).astype(np.int16)

        out_path = str(self.out_dir / "dir1_dominant_model.tif")
        _save_int_tif(dominant, self.grid_shape, self.ref_meta, out_path)

        # 图例
        legend = pd.DataFrame({
            "code": list(range(n_base)),
            "model_name": names
        })
        legend.to_csv(self.out_dir / "dir1_dominant_model_legend.csv", index=False)
        print(f"  图例（编码→模型名）已保存: dir1_dominant_model_legend.csv")

        # 同时输出每个基模型的 |SHAP| 强度 TIF（方便在 GIS 中叠加分析）
        for i, name in enumerate(names):
            p = str(self.out_dir / f"dir1_meta_shap_{name}.tif")
            _save_tif(shap_grids[:, i], self.grid_shape, self.ref_meta, p)

        print(f"  ✅ 方向1 完成 → {self.out_dir}")
        return dominant

    # ──────────────────────────────────────────────────────────
    #  方向2  逐特征 SHAP 空间 TIF
    # ──────────────────────────────────────────────────────────

    def direction2_feature_shap_tif(self):
        """
        对每个特征，把采样点的 SHAP 值插值到全图。
        输出：dir2/shap_<feature>.tif（每个特征一个文件）
        """
        import shap as shap_lib
        print("\n" + "="*60)
        print("  方向2：逐特征 SHAP 空间 TIF")
        print("="*60)

        feat_shap = self._get_feature_shap()   # (n_sample, n_features)
        sub_dir = self.out_dir / "dir2_feature_shap"
        sub_dir.mkdir(exist_ok=True)

        mean_abs_list = []
        for fi, fname in enumerate(self.top_vars):
            vals = feat_shap[:, fi]
            grid_vals = _interpolate_to_grid(
                self.coords_sample, vals, self.grid_coords, method=self.interp
            )
            p = str(sub_dir / f"shap_{fname}.tif")
            _save_tif(grid_vals, self.grid_shape, self.ref_meta, p)
            mean_abs_list.append({"feature": fname, "mean_abs_shap": float(np.abs(vals).mean())})
            print(f"    [{fi+1}/{self.n_features}] {fname} → 已保存")

        # 汇总 CSV
        df = pd.DataFrame(mean_abs_list).sort_values("mean_abs_shap", ascending=False)
        df.to_csv(sub_dir / "dir2_feature_shap_summary.csv", index=False)
        print(f"\n  特征 SHAP 均值排名（Top-5）:")
        print(df.head(5).to_string(index=False))
        print(f"  ✅ 方向2 完成 → {sub_dir}")
        return feat_shap

    # ──────────────────────────────────────────────────────────
    #  方向3  ΔSHAP TIF（平滑前后差值）
    # ──────────────────────────────────────────────────────────

    def direction3_delta_shap_tif(self):
        """
        分别计算空间平滑前/后的 SHAP，差值 ΔSHAP 插值到全图。
        输出：dir3/delta_shap_<feature>.tif  +  delta_shap_total.tif
        """
        import shap as shap_lib
        print("\n" + "="*60)
        print("  方向3：ΔSHAP TIF（量化地理加权贡献）")
        print("="*60)

        sv_unsmooth, sv_smooth = self._get_smooth_unsmooth_shap()
        delta = sv_smooth - sv_unsmooth   # (n_sample, n_features)

        sub_dir = self.out_dir / "dir3_delta_shap"
        sub_dir.mkdir(exist_ok=True)

        # 逐特征 ΔSHAP TIF
        for fi, fname in enumerate(self.top_vars):
            vals = delta[:, fi]
            grid_vals = _interpolate_to_grid(
                self.coords_sample, vals, self.grid_coords, method=self.interp
            )
            p = str(sub_dir / f"delta_shap_{fname}.tif")
            _save_tif(grid_vals, self.grid_shape, self.ref_meta, p)
            print(f"    [{fi+1}/{self.n_features}] ΔSHAP {fname} → 已保存")

        # 总 |ΔSHAP|（各特征绝对值之和，代表地理加权总体效应强度）
        total_delta = np.abs(delta).sum(axis=1)
        grid_total = _interpolate_to_grid(
            self.coords_sample, total_delta, self.grid_coords, method=self.interp
        )
        _save_tif(grid_total, self.grid_shape, self.ref_meta,
                  str(sub_dir / "delta_shap_total.tif"))
        print("    总 |ΔSHAP| → delta_shap_total.tif 已保存")

        # 摘要 CSV
        df = pd.DataFrame({
            "feature": self.top_vars,
            "mean_delta": delta.mean(axis=0),
            "mean_abs_delta": np.abs(delta).mean(axis=0),
        }).sort_values("mean_abs_delta", ascending=False)
        df.to_csv(sub_dir / "dir3_delta_shap_summary.csv", index=False)
        print(f"\n  ΔSHAP 摘要（越大代表地理加权影响越强）:")
        print(df.to_string(index=False))
        print(f"  ✅ 方向3 完成 → {sub_dir}")
        return delta

    # ──────────────────────────────────────────────────────────
    #  方向4  交互值 TIF
    # ──────────────────────────────────────────────────────────

    def direction4_interaction_tif(self, top_pairs: int = 5):
        """
        对 RF 基模型计算 TreeSHAP Interaction Values，
        把 Top 交互对的逐样本交互值插值到全图。
        输出：dir4/interaction_<fi>_x_<fj>.tif
        """
        import shap as shap_lib
        print("\n" + "="*60)
        print(f"  方向4：交互值 TIF（Top-{top_pairs} 交互对）")
        print("="*60)

        # 找 RF 基模型
        target = None
        target_name = ""
        for m in self.model.base_models:
            native = getattr(m, "model", m)
            name = native.__class__.__name__
            if "Forest" in name or "RandomForest" in name:
                target, target_name = native, name
                break
        if target is None:
            for m in self.model.base_models:
                native = getattr(m, "model", m)
                name = native.__class__.__name__
                if "Boost" in name or "XGB" in name:
                    target, target_name = native, name
                    break
        if target is None:
            print("  ⚠️  未找到树模型，跳过方向4。")
            return None

        print(f"  使用 {target_name} 计算 SHAP Interaction Values ...")
        print(f"  采样 {len(self.X_sample)} 点（耗时较长，请耐心等待）...")

        try:
            exp = shap_lib.TreeExplainer(target)
            iv = exp.shap_interaction_values(self.X_sample)
            if isinstance(iv, list):
                iv = iv[1] if len(iv) == 2 else iv[0]
            iv = np.array(iv)
            if iv.ndim == 4:
                iv = iv[:, :, :, 1]
            iv = iv[:, :self.n_features, :self.n_features]
            print(f"  交互值 shape: {iv.shape}")
        except Exception as e:
            print(f"  ⚠️  交互值计算失败: {e}")
            return None

        # 找 Top 交互对
        mean_abs = np.abs(iv).mean(axis=0)
        np.fill_diagonal(mean_abs, 0)
        triu = np.triu_indices(self.n_features, k=1)
        pairs = sorted(
            [(i, j, mean_abs[i, j]) for i, j in zip(*triu)],
            key=lambda x: -x[2]
        )[:top_pairs]

        sub_dir = self.out_dir / "dir4_interactions"
        sub_dir.mkdir(exist_ok=True)

        # 全局交互矩阵 CSV
        df_mat = pd.DataFrame(mean_abs, index=self.top_vars, columns=self.top_vars)
        df_mat.to_csv(sub_dir / "dir4_interaction_matrix.csv")

        pair_records = []
        for rank, (fi, fj, strength) in enumerate(pairs, 1):
            fname_i = self.top_vars[fi]
            fname_j = self.top_vars[fj]
            interaction_vals = iv[:, fi, fj]   # (n_sample,)

            grid_vals = _interpolate_to_grid(
                self.coords_sample, interaction_vals,
                self.grid_coords, method=self.interp
            )
            tif_name = f"interaction_{fname_i}_x_{fname_j}.tif"
            _save_tif(grid_vals, self.grid_shape, self.ref_meta,
                      str(sub_dir / tif_name))
            pair_records.append({
                "rank": rank,
                "feature_i": fname_i,
                "feature_j": fname_j,
                "mean_abs_interaction": strength,
                "tif_file": tif_name,
            })
            print(f"    #{rank} {fname_i} × {fname_j}  (strength={strength:.4f}) → 已保存")

        df_pairs = pd.DataFrame(pair_records)
        df_pairs.to_csv(sub_dir / "dir4_top_pairs.csv", index=False)
        print(f"\n  Top-{top_pairs} 交互对已保存: dir4_top_pairs.csv")
        print(f"  ✅ 方向4 完成 → {sub_dir}")
        return df_pairs

    # ──────────────────────────────────────────────────────────
    #  一键运行
    # ──────────────────────────────────────────────────────────

    def run_all(self, directions=None, top_pairs=5):
        directions = directions or [1, 2, 3, 4]
        print("\n" + "#"*60)
        print("  GWRF SHAP → TIF 生成器")
        print(f"  输出目录: {self.out_dir}")
        print(f"  插值方式: {self.interp}")
        print("#"*60)

        if 1 in directions:
            try:
                self.direction1_dominant_model_tif()
            except Exception as e:
                logger.error(f"方向1 失败: {e}", exc_info=True)

        if 2 in directions:
            try:
                self.direction2_feature_shap_tif()
            except Exception as e:
                logger.error(f"方向2 失败: {e}", exc_info=True)

        if 3 in directions:
            try:
                self.direction3_delta_shap_tif()
            except Exception as e:
                logger.error(f"方向3 失败: {e}", exc_info=True)

        if 4 in directions:
            try:
                self.direction4_interaction_tif(top_pairs=top_pairs)
            except Exception as e:
                logger.error(f"方向4 失败: {e}", exc_info=True)

        print("\n" + "#"*60)
        print(f"  ✅ 全部完成！TIF 文件保存在: {self.out_dir}")
        print("#"*60)

        # 输出文件树
        print("\n  生成的文件：")
        for p in sorted(self.out_dir.rglob("*.tif")):
            rel = p.relative_to(self.out_dir)
            print(f"    {rel}")

    # ──────────────────────────────────────────────────────────
    #  内部：获取 Meta SHAP（对元模型做 TreeSHAP）
    # ──────────────────────────────────────────────────────────

    def _get_meta_shap(self):
        if self._meta_shap is not None:
            return self._meta_shap
        import shap as shap_lib

        meta_X_sample = self._build_meta_X(self.X_sample)
        meta_X_bg = self._build_meta_X(self.X_bg)

        print("  计算 Meta TreeSHAP ...")
        try:
            exp = shap_lib.TreeExplainer(self.model.meta_model)
            sv = exp.shap_values(meta_X_sample)
            sv = _ensure_2d_shap(sv)
        except Exception as e:
            print(f"  退回 KernelSHAP: {e}")
            exp = shap_lib.KernelExplainer(
                lambda x: self.model.meta_model.predict_proba(x)[:, 1],
                meta_X_bg
            )
            sv = _ensure_2d_shap(exp.shap_values(meta_X_sample, nsamples=100))

        self._meta_shap = sv
        return sv

    # ──────────────────────────────────────────────────────────
    #  内部：获取特征 SHAP（对整体预测函数做 KernelSHAP）
    # ──────────────────────────────────────────────────────────

    def _get_feature_shap(self):
        if self._feat_shap is not None:
            return self._feat_shap
        import shap as shap_lib

        print("  计算特征 KernelSHAP ...")

        def predict_fn(x):
            if x.ndim == 1:
                x = x.reshape(1, -1)
            meta = self._build_meta_X(x)
            return self.model.meta_model.predict_proba(meta)[:, 1]

        exp = shap_lib.KernelExplainer(predict_fn, self.X_bg)
        sv = _ensure_2d_shap(exp.shap_values(self.X_sample, nsamples=100))
        sv = sv[:, :self.n_features]
        self._feat_shap = sv
        return sv

    # ──────────────────────────────────────────────────────────
    #  内部：获取平滑前/后 SHAP
    # ──────────────────────────────────────────────────────────

    def _get_smooth_unsmooth_shap(self):
        if self._feat_shap_unsmooth is not None:
            return self._feat_shap_unsmooth, self._feat_shap_smooth

        import shap as shap_lib

        # ── 未平滑：只用基模型概率送入元模型
        def predict_unsmoothed(x):
            if x.ndim == 1:
                x = x.reshape(1, -1)
            meta = self._build_meta_X(x)
            return self.model.meta_model.predict_proba(meta)[:, 1]

        # ── 平滑：加入空间插值混合
        def predict_smoothed(x):
            if x.ndim == 1:
                x = x.reshape(1, -1)
            meta = self._build_meta_X(x)
            if self.model.train_coords is None:
                return self.model.meta_model.predict_proba(meta)[:, 1]
            from scipy.spatial.distance import cdist
            bw = (self.model._bandwidth_val
                  or self.model._resolve_bandwidth(self.model.train_coords))
            dists = cdist(self.coords_sample[:len(x)],
                          self.model.train_coords, metric="euclidean")
            w = np.exp(-(dists**2) / (bw**2))
            w /= (w.sum(axis=1, keepdims=True) + 1e-10)
            interp = w @ self.model.train_meta_features
            n = min(len(meta), len(interp))
            wm = (self.model.spatial_alpha * meta[:n]
                  + (1 - self.model.spatial_alpha) * interp[:n])
            return self.model.meta_model.predict_proba(wm)[:, 1]

        print("  计算未平滑 SHAP ...")
        exp1 = shap_lib.KernelExplainer(predict_unsmoothed, self.X_bg)
        sv1 = _ensure_2d_shap(exp1.shap_values(self.X_sample, nsamples=100))[:, :self.n_features]

        print("  计算平滑后 SHAP ...")
        exp2 = shap_lib.KernelExplainer(predict_smoothed, self.X_bg)
        sv2 = _ensure_2d_shap(exp2.shap_values(self.X_sample, nsamples=100))[:, :self.n_features]

        self._feat_shap_unsmooth = sv1
        self._feat_shap_smooth = sv2
        return sv1, sv2

    # ──────────────────────────────────────────────────────────
    #  内部工具
    # ──────────────────────────────────────────────────────────

    def _build_meta_X(self, X: np.ndarray) -> np.ndarray:
        probs = []
        for m in self.model.base_models:
            try:
                import inspect
                sig = inspect.signature(m.predict_proba).parameters
                if "feature_names" in sig:
                    p = m.predict_proba(X, feature_names=self.top_vars)
                else:
                    p = m.predict_proba(X)
            except Exception:
                p = m.predict_proba(X)
            probs.append(np.array(p).reshape(-1, 1))
        return np.hstack(probs)

    def _get_base_names(self):
        names = []
        for m in self.model.base_models:
            native = getattr(m, "model", m)
            names.append(native.__class__.__name__)
        return names


# ============================================================
#  命令行入口
# ============================================================

def main():
    import argparse
    p = argparse.ArgumentParser(description="GWRF SHAP → TIF 生成器")
    p.add_argument("--experiment_dir", required=True,
                   help="实验目录（含 gwrf_ensemble_model.pkl 和 gwrf_area_suitability_pred.tif）")
    p.add_argument("--directions", type=int, nargs="+", default=None,
                   help="运行方向，如 --directions 1 2 3 4（默认全部）")
    p.add_argument("--n_sample", type=int, default=200, help="SHAP 采样点数（默认200）")
    p.add_argument("--n_bg",     type=int, default=50,  help="背景集大小（默认50）")
    p.add_argument("--top_pairs",type=int, default=5,   help="方向4 输出交互对数（默认5）")
    p.add_argument("--interp",   type=str, default="linear",
                   choices=["linear", "nearest", "cubic"], help="插值方式（默认linear）")
    args = p.parse_args()

    from . import config

    exp_dir = args.experiment_dir

    # ── 加载模型 ──────────────────────────────────────────────
    model_path = os.path.join(exp_dir, "gwrf_ensemble_model.pkl")
    if not os.path.exists(model_path):
        raise FileNotFoundError(f"找不到模型: {model_path}")
    print(f"加载模型: {model_path}")
    model_data = joblib.load(model_path)
    ensemble_model = model_data["ensemble_model"]
    top_vars = model_data["top_variables"]
    print(f"特征列表 ({len(top_vars)}): {top_vars}")

    # ── 加载训练数据 ──────────────────────────────────────────
    train_df = pd.read_csv(config.PREPROCESSED_TRAIN_DATA)
    coords_train = train_df.iloc[:, :2].values
    X_train = train_df[top_vars].values
    print(f"训练数据: X={X_train.shape}, coords={coords_train.shape}")

    # ── 参考 TIF ─────────────────────────────────────────────
    ref_tif = os.path.join(exp_dir, "gwrf_area_suitability_pred.tif")
    if not os.path.exists(ref_tif):
        raise FileNotFoundError(f"找不到适生区 TIF: {ref_tif}\n请先运行 predict_gwrf.py 生成它。")

    # ── 输出目录 ─────────────────────────────────────────────
    out_dir = os.path.join(exp_dir, "gwrf_shap_tif_output")

    # ── 构建生成器并运行 ──────────────────────────────────────
    gen = GWRFSHAPTifGenerator(
        model=ensemble_model,
        X_train=X_train,
        coords_train=coords_train,
        top_vars=top_vars,
        ref_tif=ref_tif,
        out_dir=out_dir,
        n_sample=args.n_sample,
        n_bg=args.n_bg,
        interp=args.interp,
    )

    gen.run_all(directions=args.directions, top_pairs=args.top_pairs)


if __name__ == "__main__":
    main()
