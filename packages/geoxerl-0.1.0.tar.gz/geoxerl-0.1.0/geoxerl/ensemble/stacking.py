"""
Dynamic stacking ensemble with config参数支持。

修复说明：
- 原版 fit_and_eval_cv 返回全量数据的 stacking_prob（含训练集，轻度泄露）
- 修复后：返回 K 折 OOF 拼合的 oof_prob，AUC 基于真正 hold-out 预测
- self.base_models / self.meta_model 仍在全量数据上 fit，供后续推理
"""

import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
import lightgbm as lgb
import shap
import pandas as pd
from . import config


class DynamicStackingEnsembleCV:
    def __init__(
        self,
        base_model_classes,
        meta_model_name=None,
        random_state=None,
        meta_model_params=None,
        n_folds=None
    ):
        self.base_model_classes = base_model_classes
        self.meta_model_name = meta_model_name or config.META_MODEL
        self.random_state = random_state if random_state is not None else config.RANDOM_SEED
        self.meta_model_params = meta_model_params or {}
        self.n_folds = n_folds if n_folds is not None else config.N_FOLDS
        self.base_models = []
        self.meta_model = None

    def _get_meta_model(self):
        if self.meta_model_name == "logistic_regression":
            return LogisticRegression(
                max_iter=500,
                random_state=self.random_state,
                **self.meta_model_params
            )
        elif self.meta_model_name == "lightgbm":
            pass
        elif self.meta_model_name in ("random_forest", "rf"):
            from sklearn.ensemble import RandomForestClassifier
            return RandomForestClassifier(
                n_estimators=100,
                random_state=self.random_state,
                n_jobs=-1,
                **self.meta_model_params
            )
        else:
            raise ValueError(f"不支持的元模型类型: {self.meta_model_name}")

    def fit(self, X, y, feature_indices, feature_names=None, n_folds=None, verbose=False):
        X_sub = X[:, feature_indices]
        n_folds = n_folds if n_folds is not None else self.n_folds
        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=self.random_state)
        n_samples = X_sub.shape[0]
        n_base = len(self.base_model_classes)
        meta_features = np.zeros((n_samples, n_base))

        for fold, (train_idx, val_idx) in enumerate(skf.split(X_sub, y)):
            X_tr, y_tr = X_sub[train_idx], y[train_idx]
            X_val = X_sub[val_idx]
            for i, model_cls in enumerate(self.base_model_classes):
                base_model = model_cls(cv=1, random_state=self.random_state)
                base_model.fit(
                    X_tr, y_tr,
                    feature_names=[feature_names[j] for j in feature_indices] if feature_names else None
                )
                meta_features[val_idx, i] = base_model.predict_proba(X_val).reshape(-1)
            if verbose:
                print(f"K折Stacking: 第{fold + 1}折 完成")

        self.meta_model = self._get_meta_model()
        self.meta_model.fit(meta_features, y)
        if verbose:
            print("元模型训练完成")

        # 全量重训基模型，供后续推理
        self.base_models = []
        for model_cls in self.base_model_classes:
            model = model_cls(cv=1, random_state=self.random_state)
            model.fit(
                X_sub, y,
                feature_names=[feature_names[j] for j in feature_indices] if feature_names else None
            )
            self.base_models.append(model)

        # ★ 保存 OOF meta_features，供 fit_and_eval_cv 计算 OOF AUC 使用
        self._oof_meta_features = meta_features

    def predict_proba(self, X, feature_indices, feature_names=None, verbose=False):
        X_sub = X[:, feature_indices]
        base_probs = [m.predict_proba(X_sub).reshape(-1, 1) for m in self.base_models]
        meta_X = np.hstack(base_probs)
        stacking_prob = self.meta_model.predict_proba(meta_X)[:, 1]
        if verbose:
            print(f"[predict] stacking 输出 shape: {stacking_prob.shape}")
        return stacking_prob

    def fit_and_eval_cv(self, X, y, feature_indices, feature_names=None, n_folds=None, verbose=False):
        """
        【修复版】训练 + K 折 OOF 评估，消除数据泄露。

        原版：fit 后用全量数据预测 stacking_prob → AUC（含训练集，泄露）
        修复：fit 内部已积累 OOF meta_features → 用元模型对 OOF 预测 → OOF AUC

        返回：
          oof_auc  : float，基于 OOF 的真实泛化 AUC
          oof_prob : ndarray shape (n_samples,)，OOF 预测概率
        """
        self.fit(X, y, feature_indices, feature_names, n_folds, verbose)

        # ★ 关键修复：用 OOF meta_features 经元模型预测，而非全量数据预测
        oof_prob = self.meta_model.predict_proba(self._oof_meta_features)[:, 1]
        oof_auc = roc_auc_score(y, oof_prob)

        if verbose:
            print(f"[fit_and_eval_cv] OOF Stacking AUC: {oof_auc:.4f}")

        return oof_auc, oof_prob

    def get_base_model_importances(self, feature_names):
        tree_importances = []
        for model in self.base_models:
            native_model = getattr(model, "model", model)
            if hasattr(native_model, "feature_importances_"):
                tree_importances.append(native_model.feature_importances_)
        if tree_importances:
            mean_importance = np.mean(tree_importances, axis=0)
        else:
            mean_importance = np.zeros(len(feature_names))
        return pd.DataFrame({
            "feature": feature_names,
            "importance": mean_importance
        }).sort_values("importance", ascending=False).reset_index(drop=True)

    def get_meta_model_shap(self, X, feature_indices, feature_names):
        X_sub = X[:, feature_indices]
        base_probs = [m.predict_proba(X_sub).reshape(-1, 1) for m in self.base_models]
        meta_X = np.hstack(base_probs)
        explainer = shap.Explainer(self.meta_model, meta_X)
        shap_values = explainer(meta_X)
        mean_abs_shap = np.abs(shap_values.values).mean(axis=0)
        meta_names = [m.name for m in self.base_models]
        return pd.DataFrame({
            "meta_feature": meta_names,
            "mean_abs_shap": mean_abs_shap
        }).sort_values("mean_abs_shap", ascending=False).reset_index(drop=True)

    def transform(self, X, feature_indices, feature_names=None):
        X_sub = X[:, feature_indices]
        base_probs = [m.predict_proba(X_sub).reshape(-1, 1) for m in self.base_models]
        return np.hstack(base_probs)


# === 测试主函数 ===
if __name__ == "__main__":
    print("==== 动态Stacking集成类K折接口调试 ====")
    from ..base_models.models import RandomForestModel, XGBoostModel, MaxEntModel, SVMModel

    n_samples, n_features = 1000, 50
    np.random.seed(42)
    X = np.random.randn(n_samples, n_features)
    y = np.random.randint(0, 2, n_samples)
    feature_names = [f"var_{i + 1}" for i in range(n_features)]

    select_k = 10
    feature_indices = np.random.choice(n_features, select_k, replace=False).tolist()
    print(f"选中特征索引: {feature_indices}")

    stacking = DynamicStackingEnsembleCV(
        base_model_classes=[RandomForestModel, XGBoostModel, MaxEntModel, SVMModel],
        meta_model_name=config.META_MODEL
    )

    auc, oof_prob = stacking.fit_and_eval_cv(
        X, y,
        feature_indices=feature_indices,
        feature_names=feature_names,
        n_folds=config.N_FOLDS,
        verbose=True
    )
    print(f"\n[调试结果] OOF Stacking AUC: {auc:.4f}（修复后，随机数据预期 ~0.50）")

    for i in range(3):
        feature_indices = np.random.choice(n_features, select_k, replace=False).tolist()
        auc, _ = stacking.fit_and_eval_cv(
            X, y,
            feature_indices=feature_indices,
            feature_names=feature_names,
            n_folds=config.N_FOLDS,
            verbose=False
        )
        print(f"第 {i + 1} 轮，特征索引: {feature_indices}，OOF AUC: {auc:.4f}")

    print("==== 动态Stacking集成类K折接口调试完成 ====")