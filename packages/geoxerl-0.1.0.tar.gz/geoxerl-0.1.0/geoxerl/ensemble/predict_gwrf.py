import os
import numpy as np
import pandas as pd
import joblib
import logging
from . import config
import rasterio
import json
from datetime import datetime
from .metrics import all_metrics

from ..base_models.models import RandomForestModel, XGBoostModel, MaxEntModel, SVMModel
from .stacking import DynamicStackingEnsembleCV
from .bagging import DynamicBaggingEnsembleCV
from .boosting import DynamicBoostingEnsembleCV
from .gwrf import DynamicGWRFEnsembleCV
import shap
import warnings

warnings.filterwarnings("ignore", category=UserWarning)

# 全局变量：实验目录 + 集成方法标识
EXPERIMENT_DIR = None
ENSEMBLE_METHOD = None  # stacking / bagging / boosting / gwrf


def setup_experiment_environment(selected_top_features=None, ensemble_method=None):
    """
    设置实验环境，创建独立的实验文件夹
    支持boosting/gwrf集成方法
    """
    global EXPERIMENT_DIR, ENSEMBLE_METHOD

    # 确定集成方法（优先命令行，其次配置，默认stacking）
    ENSEMBLE_METHOD = ensemble_method or getattr(config, "ENSEMBLE_METHOD", "stacking")
    if ENSEMBLE_METHOD not in ["stacking", "bagging", "boosting", "gwrf"]:
        raise ValueError(f"不支持的集成方法: {ENSEMBLE_METHOD}，仅支持 stacking/bagging/boosting/gwrf")

    # 确定使用的Top特征数量
    if selected_top_features is None:
        selected_top_features = config.get_selected_top_features()

    # 读取PPO输出的变量频次表
    top_var_path = os.path.join(config.RESULTS_DIR, "top30_variable_freq_avg.csv")
    if not os.path.exists(top_var_path):
        raise FileNotFoundError(f"PPO输出文件不存在: {top_var_path}")

    df = pd.read_csv(top_var_path)
    selected_features = df['feature'][:selected_top_features].tolist()

    # 创建实验文件夹（新增集成方法标识）
    if config.POST_PROCESSING_PARAMS['create_separate_folders']:
        EXPERIMENT_DIR = config.create_experiment_folder(selected_features, suffix=f"_{ENSEMBLE_METHOD}")

        # 配置日志到实验文件夹
        experiment_log = os.path.join(EXPERIMENT_DIR, f"{ENSEMBLE_METHOD}_post_analysis.log")
        logging.basicConfig(
            filename=experiment_log,
            level=getattr(logging, config.LOG_LEVEL),
            format="%(asctime)s %(levelname)s %(message)s",
            encoding="utf-8",
            filemode='w'  # 重写模式
        )

        print(f" 实验文件夹已创建: {EXPERIMENT_DIR}")
        print(f" 选择的集成方法: {ENSEMBLE_METHOD}")
        print(f" 选择的Top特征数量: {selected_top_features}")
        print(f" 选择的特征: {selected_features}")

    else:
        EXPERIMENT_DIR = config.RESULTS_DIR
        logging.basicConfig(
            filename=config.LOG_FILE,
            level=getattr(logging, config.LOG_LEVEL),
            format="%(asctime)s %(levelname)s %(message)s",
            encoding="utf-8"
        )

    logger = logging.getLogger("post_analysis")
    logger.info(f"实验开始: 选择Top {selected_top_features} 特征，集成方法: {ENSEMBLE_METHOD}")
    logger.info(f"实验目录: {EXPERIMENT_DIR}")
    logger.info(f"选择的特征: {selected_features}")

    return selected_features, EXPERIMENT_DIR, ENSEMBLE_METHOD


def save_experiment_metadata(selected_features, experiment_dir, ensemble_method):
    """
    保存实验元数据（兼容所有集成方法）
    """
    # 适配不同集成方法的参数
    meta_model = config.META_MODEL if ensemble_method in ["stacking", "gwrf"] else "None"
    n_estimators = getattr(config, "N_ESTIMATORS", 5) if ensemble_method in ["bagging", "boosting"] else "None"
    boosting_params = {}
    if ensemble_method == "boosting":
        boosting_params = {
            "learning_rate": getattr(config, "BOOSTING_LR", 0.1),
            "loss": getattr(config, "BOOSTING_LOSS", "exponential"),
            "base_models": ["RandomForestModel", "XGBoostModel", "MaxEntModel"]
        }
    gwrf_params = {}
    if ensemble_method == "gwrf":
        gwrf_params = config.GWRF_PARAMS

    metadata = {
        'experiment_timestamp': datetime.now().isoformat(),
        'ensemble_method': ensemble_method,
        'selected_top_features_count': len(selected_features),
        'selected_features': selected_features,
        'config_parameters': {
            'NUM_TOTAL_FEATURES': config.NUM_TOTAL_FEATURES,
            'TOP_K_FEATURES': config.TOP_K_FEATURES,
            'INIT_FEATURE_NUM': config.INIT_FEATURE_NUM,
            'RL_NUM_EPISODES': config.RL_NUM_EPISODES,
            'MAX_STEPS': config.MAX_STEPS,
            'N_FOLDS': config.N_FOLDS,
            'META_MODEL': meta_model,
            'BASE_MODELS': config.BASE_MODELS,
            'RANDOM_SEED': config.RANDOM_SEED,
            'N_ESTIMATORS': n_estimators,
            'BOOSTING_PARAMS': boosting_params,
            'GWRF_PARAMS': gwrf_params
        },
        'post_processing_params': config.POST_PROCESSING_PARAMS
    }

    metadata_path = os.path.join(experiment_dir, f"{ensemble_method}_experiment_metadata.json")
    with open(metadata_path, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, ensure_ascii=False)

    logger = logging.getLogger("post_analysis")
    logger.info(f"实验元数据已保存: {metadata_path}")


def load_top_variables(selected_top_features=None):
    """加载指定数量的Top变量"""
    if selected_top_features is None:
        selected_top_features = config.get_selected_top_features()

    # 加载PPO输出的变量频次表
    top_var_path = os.path.join(config.RESULTS_DIR, "top30_variable_freq_avg.csv")
    df = pd.read_csv(top_var_path)

    # 选择指定数量的Top变量
    top_vars = df['feature'][:selected_top_features].tolist()

    logger = logging.getLogger("post_analysis")
    logger.info(f"加载Top {selected_top_features} 变量: {top_vars}")

    return top_vars, df[:selected_top_features]


def load_train_data(top_vars):
    """加载训练数据（提取经纬度，兼容GWRF）"""
    X_train = pd.read_csv(config.PREPROCESSED_TRAIN_DATA)
    y_train = X_train["presence"].values
    X = X_train[top_vars].values
    # 前两列是经纬度 (lon, lat)，兼容GWRF
    coords_train = X_train.iloc[:, :2].values

    logger = logging.getLogger("post_analysis")
    logger.info(f"训练数据加载: X shape={X.shape}, y shape={y_train.shape}, coords shape={coords_train.shape}")
    return X, y_train, coords_train


def save_ensemble_model(ensemble_model, top_vars, experiment_dir, ensemble_method):
    """
    通用的集成模型保存函数（兼容所有集成方法）
    """
    model_filename = f"{ensemble_method}_ensemble_model.pkl"
    model_path = os.path.join(experiment_dir, model_filename)

    try:
        # 动态组装模型配置
        model_config = {
            'base_models': config.BASE_MODELS,
            'n_folds': config.N_FOLDS,
            'random_seed': config.RANDOM_SEED,
            'meta_model': config.META_MODEL if ensemble_method in ["stacking", "gwrf"] else None,
            'n_estimators': getattr(config, "N_ESTIMATORS", 5) if ensemble_method in ["bagging", "boosting"] else None
        }
        if ensemble_method == "boosting":
            model_config['learning_rate'] = getattr(config, "BOOSTING_LR", 0.1)
            model_config['loss'] = getattr(config, "BOOSTING_LOSS", "exponential")
        if ensemble_method == "gwrf":
            model_config['gwrf_params'] = config.GWRF_PARAMS

        model_data = {
            'ensemble_model': ensemble_model,
            'ensemble_method': ensemble_method,
            'top_variables': top_vars,
            'saved_at': datetime.now().isoformat(),
            'n_features': len(top_vars),
            'model_config': model_config
        }

        joblib.dump(model_data, model_path)

        logger = logging.getLogger("post_analysis")
        logger.info(f"{ensemble_method}集成模型已保存: {model_path}")
        print(f" {ensemble_method}集成模型已保存: {model_path}")

        return True
    except Exception as e:
        logger = logging.getLogger("post_analysis")
        logger.error(f"{ensemble_method}集成模型保存失败: {e}")
        print(f" {ensemble_method}集成模型保存失败: {e}")
        return False


def load_ensemble_model(experiment_dir, ensemble_method, top_vars):
    """
    通用的集成模型加载函数（兼容所有集成方法）
    """
    model_filename = f"{ensemble_method}_ensemble_model.pkl"
    model_path = os.path.join(experiment_dir, model_filename)

    if not os.path.exists(model_path):
        return None, None

    try:
        model_data = joblib.load(model_path)
        if model_data['ensemble_method'] != ensemble_method or model_data['top_variables'] != top_vars:
            logger = logging.getLogger("post_analysis")
            logger.warning("模型的集成方法/特征与当前不匹配，重新训练")
            return None, None

        ensemble_model = model_data['ensemble_model']
        loaded_top_vars = model_data['top_variables']

        logger = logging.getLogger("post_analysis")
        logger.info(f"{ensemble_method}集成模型已加载: {model_path}")
        print(f" {ensemble_method}集成模型已加载: {model_path}")
        print(f"   - 保存时间: {model_data['saved_at']}")
        print(f"   - 特征数量: {model_data['n_features']}")

        return ensemble_model, loaded_top_vars
    except Exception as e:
        logger = logging.getLogger("post_analysis")
        logger.error(f"{ensemble_method}集成模型加载失败: {e}")
        print(f" {ensemble_method}集成模型加载失败: {e}")
        return None, None


def load_test_data(top_vars):
    """加载测试集数据（提取经纬度，兼容GWRF）"""
    try:
        X_test = pd.read_csv(config.PREPROCESSED_TEST_DATA)
        y_test = X_test["presence"].values
        X_test_features = X_test[top_vars].values
        coords_test = X_test.iloc[:, :2].values
        return X_test_features, y_test, coords_test
    except Exception as e:
        return None, None, None


def format_metric(value):
    """格式化指标值"""
    if value is None or value == 'N/A':
        return 'N/A'
    try:
        return f"{float(value):.4f}"
    except (ValueError, TypeError):
        return str(value)


def save_ensemble_auc_curve_data(y_true, y_prob, save_dir, ensemble_method, set_type="test"):
    """保存集成模型AUC曲线原始数据"""
    from sklearn.metrics import roc_curve, auc
    import pandas as pd
    import os

    fpr, tpr, thresholds = roc_curve(y_true, y_prob)
    auc_score = auc(fpr, tpr)

    auc_curve_data = pd.DataFrame({
        "fpr": fpr,
        "tpr": tpr,
        "thresholds": thresholds,
        "auc": [auc_score] * len(fpr)
    })

    save_path = os.path.join(save_dir, f"{ensemble_method}_{set_type}_auc_curve_data.csv")
    auc_curve_data.to_csv(save_path, index=False, encoding="utf-8")
    print(f"✅ 集成模型{set_type}集AUC曲线原始数据已保存: {save_path}")

    return fpr, tpr, auc_score


def plot_ensemble_auc_curve(fpr, tpr, auc_score, save_dir, ensemble_method, set_type="test"):
    """绘制并保存集成模型AUC曲线"""
    import matplotlib.pyplot as plt
    import os

    plt.style.use('seaborn-v0_8-whitegrid')
    plt.rcParams['font.family'] = 'SimHei'
    plt.rcParams['axes.unicode_minus'] = False
    plt.rcParams['axes.linewidth'] = 1.0
    plt.figure(figsize=(8, 6), dpi=150)

    plt.plot(fpr, tpr, color='blue', linewidth=2, label=f'AUC = {auc_score:.4f}')
    plt.plot([0, 1], [0, 1], color='red', linestyle='--', linewidth=1)

    plt.title(f'{ensemble_method.upper()} {set_type.capitalize()} ROC Curve', fontsize=12, pad=15)
    plt.xlabel('False Positive Rate', fontsize=10)
    plt.ylabel('True Positive Rate', fontsize=10)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.grid(True, linestyle='-', alpha=0.3)
    plt.legend(loc='lower right', fontsize=10)
    plt.tight_layout()

    img_save_path = os.path.join(save_dir, f"{ensemble_method}_{set_type}_roc_curve.png")
    plt.savefig(img_save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"✅ 集成模型{set_type}集AUC曲线已保存: {img_save_path}")


def save_ensemble_model_info(final_metrics, experiment_dir, ensemble_method, top_vars):
    """保存集成模型基础信息"""
    import pandas as pd
    from datetime import datetime

    prob_tif_path = os.path.join(experiment_dir, f"{ensemble_method}_area_suitability_pred.tif")

    model_info = pd.DataFrame({
        'model_type': ['ensemble'],
        'model_name': [f"{ensemble_method}_ensemble"],
        'train_auc_roc': [np.nan],
        'test_auc_roc': [final_metrics.get('auc_roc', np.nan)],
        'test_tss': [final_metrics.get('tss', np.nan)],
        'test_kappa': [final_metrics.get('kappa', np.nan)],
        'test_boyce': [final_metrics.get('boyce_index', np.nan)],
        'output_dir': [experiment_dir],
        'prob_tif_path': [prob_tif_path],
        'top_features_count': [len(top_vars)],
        'ensemble_method': [ensemble_method]
    })

    model_info_path = os.path.join(experiment_dir, f"{ensemble_method}_model_info.csv")
    model_info.to_csv(model_info_path, index=False)
    print(f"集成模型基础信息已保存: {model_info_path}")


def final_performance_evaluation(ensemble_model, X_test, y_test, coords_test, top_vars, experiment_dir, ensemble_method):
    """集成模型最终性能评估函数（兼容GWRF）"""
    import json
    import logging
    import numpy as np
    from datetime import datetime

    print("\n" + "="*50)
    print(f"           最终性能评估（测试集）- {ensemble_method.upper()}")
    print("="*50)

    # 预测测试集概率（适配GWRF）
    feature_indices = list(range(len(top_vars)))
    if ensemble_method == "gwrf":
        y_pred_prob = ensemble_model.predict_proba(X_test, feature_indices, coords_test)
    else:
        y_pred_prob = ensemble_model.predict_proba(X_test, feature_indices)

    # 调试信息
    print(f"调试信息:")
    print(f"  y_test shape: {y_test.shape}")
    print(f"  y_pred_prob shape: {y_pred_prob.shape}")
    print(f"  y_test unique values: {np.unique(y_test)}")
    print(f"  y_pred_prob range: [{y_pred_prob.min():.4f}, {y_pred_prob.max():.4f}]")

    # 计算性能指标
    try:
        print("  开始计算指标...")
        final_metrics = all_metrics(
            y_true=y_test,
            y_prob=y_pred_prob,
            presence_mask=None,
            threshold=0.5
        )
        print(f"  指标计算成功")
        print(f"  返回的键: {list(final_metrics.keys())}")
        for key, value in final_metrics.items():
            if key in ['auc_roc', 'auc_pr', 'tss', 'kappa', 'boyce_index']:
                print(f"    {key}: {value}")

    except Exception as e:
        print(f"  指标计算失败: {e}")
        import traceback
        traceback.print_exc()
        final_metrics = {}

    # 显示主要指标
    print(f"AUC-ROC: {format_metric(final_metrics.get('auc_roc'))}")
    print(f"AUC-PR: {format_metric(final_metrics.get('auc_pr'))}")
    print(f"TSS: {format_metric(final_metrics.get('tss'))}")
    print(f"Kappa: {format_metric(final_metrics.get('kappa'))}")
    print(f"Boyce Index: {format_metric(final_metrics.get('boyce_index'))}")

    # 保存评估结果
    final_results = {
        'ensemble_method': ensemble_method,
        'test_metrics': final_metrics,
        'selected_features': top_vars,
        'num_features': len(top_vars),
        'test_samples': len(y_test),
        'positive_rate': float(np.mean(y_test)),
        'evaluation_date': datetime.now().isoformat()
    }
    final_path = os.path.join(experiment_dir, f"{ensemble_method}_final_performance_evaluation.json")
    with open(final_path, 'w', encoding='utf-8') as f:
        json.dump(final_results, f, indent=2, ensure_ascii=False)
    logger = logging.getLogger("post_analysis")
    logger.info(f"最终性能评估结果已保存: {final_path}")
    print(f"\n 详细评估结果已保存: {final_path}")

    # 保存AUC曲线数据和图片
    try:
        fpr, tpr, auc_score = save_ensemble_auc_curve_data(
            y_true=y_test,
            y_prob=y_pred_prob,
            save_dir=experiment_dir,
            ensemble_method=ensemble_method,
            set_type="test"
        )
        plot_ensemble_auc_curve(
            fpr=fpr,
            tpr=tpr,
            auc_score=auc_score,
            save_dir=experiment_dir,
            ensemble_method=ensemble_method,
            set_type="test"
        )
    except Exception as e:
        print(f" ❌ AUC曲线生成/数据保存失败: {e}")
        logger.warning(f"{ensemble_method} AUC曲线生成/数据保存失败: {e}")

    # 保存模型基础信息
    save_ensemble_model_info(final_metrics, experiment_dir, ensemble_method, top_vars)

    return final_metrics


def generate_spatial_shap_rasters(ensemble_model, top_vars, experiment_dir, ensemble_method, coords_train=None):
    """
    【极速优化版】生成空间SHAP贡献度栅格
    """
    import os
    import numpy as np
    import rasterio
    import shap
    import pandas as pd
    import matplotlib.pyplot as plt
    from tqdm import tqdm
    import logging
    from scipy.interpolate import griddata

    logger = logging.getLogger("spatial_shap")
    print(f"\n{'=' * 60}")
    print(f"  生成空间SHAP贡献度栅格 (极速优化版)")
    print(f"{'=' * 60}")

    # 加载环境变量栅格数据
    print("  加载环境变量栅格...")
    try:
        X_area, meta, arr_shape = load_tif_variables(top_vars)
        n_pixels = X_area.shape[0]
        n_features = X_area.shape[1]
        height, width = arr_shape
        print(f"  栅格加载完成: {width}x{height} = {n_pixels} 像素")
    except Exception as e:
        print(f"  ❌ 栅格加载失败: {e}")
        return None

    # 稀疏采样优化
    step = 300
    y_coords, x_coords = np.indices(arr_shape)
    y_coords_flat = y_coords.flatten()
    x_coords_flat = x_coords.flatten()

    sample_mask = (y_coords_flat % step == 0) & (x_coords_flat % step == 0)
    sample_indices = np.where(sample_mask)[0]
    n_sample = len(sample_indices)

    print(f"  【优化】稀疏采样: 从 {n_pixels} 像素中采样 {n_sample} 像素 (步长 {step})")
    print(f"  【优化】预计速度提升: {n_pixels / n_sample:.1f} 倍")

    X_sample_points = X_area[sample_indices]
    sample_y = y_coords_flat[sample_indices]
    sample_x = x_coords_flat[sample_indices]

    # 初始化SHAP解释器
    print("  初始化SHAP解释器...")
    X_train, y_train, coords_train_local = load_train_data(top_vars)
    background_size = 20
    np.random.seed(config.RANDOM_SEED)
    background_idx = np.random.choice(X_train.shape[0], background_size, replace=False)
    X_background = X_train[background_idx]
    feature_indices = list(range(len(top_vars)))

    def predict_func(x_in):
        if len(x_in.shape) == 1:
            x_in = x_in.reshape(1, -1)
        if ensemble_method == "gwrf":
            base_probs = []
            for model in ensemble_model.base_models:
                y_prob = model.predict_proba(x_in)
                base_probs.append(y_prob.reshape(-1, 1))
            meta_X = np.hstack(base_probs)
            return ensemble_model.meta_model.predict_proba(meta_X)[:, 1]
        else:
            return ensemble_model.predict_proba(x_in, feature_indices)

    try:
        explainer = shap.KernelExplainer(predict_func, X_background)
        print("  ✅ SHAP解释器初始化完成")
    except Exception as e:
        print(f"  ❌ SHAP解释器初始化失败: {e}")
        return None

    # 计算采样点SHAP值
    print(f"  计算采样点SHAP值 ({n_sample} 个点)...")
    try:
        shap_values_sample = explainer.shap_values(X_sample_points, nsamples=20)
        if isinstance(shap_values_sample, list):
            shap_values_sample = shap_values_sample[1]
        print("  ✅ 采样点SHAP计算完成")
    except Exception as e:
        print(f"  ❌ SHAP计算失败: {e}")
        return None

    # 空间插值还原全图
    print("  空间插值还原全分辨率栅格...")
    spatial_shap_result = np.zeros((n_pixels, n_features), dtype=np.float32)
    points = np.column_stack((sample_x, sample_y))
    xi = np.column_stack((x_coords_flat, y_coords_flat))

    for i in tqdm(range(n_features), desc="  插值中"):
        values = shap_values_sample[:, i]
        try:
            full_grid = griddata(points, values, xi, method='nearest', fill_value=np.nanmean(values))
            spatial_shap_result[:, i] = full_grid.astype(np.float32)
        except Exception as e:
            print(f"  ⚠️  变量 {top_vars[i]} 插值失败: {e}")
            spatial_shap_result[:, i] = np.nan

    # 保存数据
    print("  保存数据...")
    shap_raster_dir = os.path.join(experiment_dir, "spatial_shap_rasters_fast")
    os.makedirs(shap_raster_dir, exist_ok=True)

    out_meta = meta.copy()
    out_meta.update({'dtype': 'float32', 'count': 1, 'compress': 'lzw'})

    for i, var_name in enumerate(top_vars):
        shap_raster = spatial_shap_result[:, i].reshape(arr_shape)
        tif_path = os.path.join(shap_raster_dir, f"{ensemble_method}_{var_name}_shap.tif")
        with rasterio.open(tif_path, 'w', **out_meta) as dst:
            dst.write(shap_raster, 1)

    np.save(os.path.join(shap_raster_dir, f"{ensemble_method}_spatial_shap_raw.npy"), spatial_shap_result)
    pd.DataFrame({'feature_index': list(range(n_features)), 'feature_name': top_vars}) \
        .to_csv(os.path.join(shap_raster_dir, "feature_name_mapping.csv"), index=False)

    # 生成Top5变量预览图
    print("  生成预览图...")
    try:
        top5_df = pd.DataFrame({
            'var': top_vars,
            'mean_abs_shap': np.abs(spatial_shap_result).mean(axis=0)
        }).sort_values('mean_abs_shap', ascending=False).head(5)

        for var_name in top5_df['var'].tolist():
            var_idx = top_vars.index(var_name)
            shap_raster = spatial_shap_result[:, var_idx].reshape(arr_shape)

            plt.figure(figsize=(10, 8))
            vmin, vmax = np.nanpercentile(shap_raster, 1), np.nanpercentile(shap_raster, 99)
            im = plt.imshow(shap_raster, cmap='RdBu_r', vmin=vmin, vmax=vmax)
            plt.colorbar(im, label='SHAP Value')
            plt.title(f"{ensemble_method.upper()} | {var_name}", fontsize=14)
            plt.axis('off')
            plt.tight_layout()
            plt.savefig(os.path.join(shap_raster_dir, f"{ensemble_method}_{var_name}_plot.png"), dpi=150)
            plt.close()
    except Exception as e:
        print(f"  ⚠️  预览图生成跳过: {e}")

    print(f"\n✅ 完成！所有文件保存在: {shap_raster_dir}")
    return shap_raster_dir


def train_ensemble_model(X, y, coords, feature_names, ensemble_method):
    """
    通用的集成模型训练函数（支持所有集成方法，兼容GWRF）
    """
    base_model_classes = [RandomForestModel, XGBoostModel, MaxEntModel, SVMModel]
    boosting_model_classes = [RandomForestModel, XGBoostModel, MaxEntModel]

    if ensemble_method == "stacking":
        print("  开始训练Stacking集成模型...")
        ensemble_model = DynamicStackingEnsembleCV(
            base_model_classes=base_model_classes,
            meta_model_name=config.META_MODEL,
            n_folds=config.N_FOLDS,
            random_state=config.RANDOM_SEED
        )
        ensemble_model.fit(X, y, list(range(X.shape[1])), feature_names=feature_names, n_folds=config.N_FOLDS,
                           verbose=True)

    elif ensemble_method == "bagging":
        print("  开始训练Bagging集成模型...")
        ensemble_model = DynamicBaggingEnsembleCV(
            base_model_classes=base_model_classes,
            n_estimators=getattr(config, "N_ESTIMATORS", 5),
            n_folds=config.N_FOLDS,
            random_state=config.RANDOM_SEED
        )
        ensemble_model.fit(X, y, list(range(X.shape[1])), feature_names=feature_names, verbose=True)

    elif ensemble_method == "boosting":
        print("  开始训练Boosting集成模型...")
        ensemble_model = DynamicBoostingEnsembleCV(
            base_model_classes=boosting_model_classes,
            meta_model_name=config.META_MODEL,
            n_folds=config.N_FOLDS,
            random_state=config.RANDOM_SEED
        )
        ensemble_model.fit(X, y, list(range(X.shape[1])), feature_names=feature_names, verbose=True)

    elif ensemble_method == "gwrf":
        print("  开始训练GWRF集成模型...")
        ensemble_model = DynamicGWRFEnsembleCV(
            base_model_classes=base_model_classes,
            meta_model_name=config.META_MODEL,
            n_folds=config.N_FOLDS,
            random_state=config.RANDOM_SEED,
            bandwidth=config.GWRF_PARAMS.get("bandwidth", 0.1)
        )
        # GWRF需传入经纬度coords参数
        ensemble_model.fit(X, y, list(range(X.shape[1])), coords, feature_names=feature_names, n_folds=config.N_FOLDS,
                           verbose=True)

    else:
        raise ValueError(f"不支持的集成方法: {ensemble_method}")

    logger = logging.getLogger("post_analysis")
    logger.info(f"{ensemble_method}集成模型训练完成")
    print(f" {ensemble_method}集成模型训练完成")

    return ensemble_model


def analyze_meta_model_shap(ensemble_model, X, top_vars, experiment_dir, ensemble_method):
    """分析基模型贡献度的Meta-SHAP"""
    import numpy as np
    import pandas as pd
    import shap
    import os
    import logging

    logger = logging.getLogger("post_analysis")

    if ensemble_method not in ["stacking", "gwrf"]:
        return None

    print(f"\n{'=' * 60}")
    print(f"  Meta-SHAP：分析基模型贡献度 (RF vs XGB...)")
    print(f"{'=' * 60}")

    try:
        if hasattr(ensemble_model, 'train_meta_features'):
            meta_X = ensemble_model.train_meta_features
        else:
            feature_indices = list(range(len(top_vars)))
            base_probs = []
            for model in ensemble_model.base_models:
                y_prob = model.predict_proba(X)
                base_probs.append(y_prob.reshape(-1, 1))
            meta_X = np.hstack(base_probs)

        sample_size = min(300, meta_X.shape[0])
        idx = np.random.choice(meta_X.shape[0], sample_size, replace=False)
        meta_X_sample = meta_X[idx]

        base_model_names = [m.__class__.__name__ for m in ensemble_model.base_models]

        print(f"  正在计算 Meta-SHAP...")
        explainer = shap.TreeExplainer(ensemble_model.meta_model)
        shap_output = explainer(meta_X_sample)

        if hasattr(shap_output, 'values'):
            shap_values = shap_output.values
        else:
            shap_values = explainer.shap_values(meta_X_sample)

        if isinstance(shap_values, list):
            print(f"  检测到二分类模型，取正类 SHAP 值")
            shap_values = shap_values[1]

        shap_values = np.array(shap_values)
        if len(shap_values.shape) == 3:
            shap_values = shap_values[:, :, 1]

        mean_abs_shap = np.abs(shap_values).mean(axis=0)
        if len(mean_abs_shap) != len(base_model_names):
            min_len = min(len(mean_abs_shap), len(base_model_names))
            mean_abs_shap = mean_abs_shap[:min_len]
            base_model_names = base_model_names[:min_len]

        meta_shap_df = pd.DataFrame({
            'base_model': base_model_names,
            'mean_abs_shap': mean_abs_shap
        }).sort_values('mean_abs_shap', ascending=False).reset_index(drop=True)

        path = os.path.join(experiment_dir, f"{ensemble_method}_meta_model_shap.csv")
        meta_shap_df.to_csv(path, index=False)

        print("  ✅ Meta-SHAP 计算完成！基模型贡献度排名：")
        print(meta_shap_df.to_string(index=False))

        try:
            import matplotlib.pyplot as plt
            plt.figure(figsize=(8, 4))
            plt.barh(meta_shap_df['base_model'], meta_shap_df['mean_abs_shap'], color='#1f77b4')
            plt.xlabel('Mean |SHAP| Value')
            plt.title(f'{ensemble_method.upper()} Base Model Contribution')
            plt.gca().invert_yaxis()
            plt.tight_layout()
            fig_path = os.path.join(experiment_dir, f"{ensemble_method}_meta_shap_plot.png")
            plt.savefig(fig_path, dpi=150, bbox_inches='tight')
            plt.close()
            print(f"  配图已保存: {fig_path}")
        except:
            pass

        return meta_shap_df

    except Exception as e:
        print(f"  ⚠️  Meta-SHAP 跳过: {str(e)}")
        return None


def analyze_shap_ensemble_corrected(ensemble_model, X, top_vars, experiment_dir, ensemble_method, coords_train=None):
    """统一的SHAP分析函数（兼容所有集成方法）"""
    import numpy as np
    import pandas as pd
    import shap
    import matplotlib.pyplot as plt
    import logging
    import os

    logger = logging.getLogger("post_analysis")
    print(f"\n{'=' * 60}")
    print(f"  特征重要性分析 (统一模式)")
    print(f"{'=' * 60}")

    sample_size = min(200, X.shape[0])
    background_size = 20
    np.random.seed(config.RANDOM_SEED)

    sample_idx = np.random.choice(X.shape[0], sample_size, replace=False)
    background_idx = np.random.choice(X.shape[0], background_size, replace=False)

    X_sample = X[sample_idx]
    X_background = X[background_idx]

    feature_indices = list(range(len(top_vars)))
    shap_values_raw = None
    final_shap_values = None
    plot_success = False

    def predict_func(x_in):
        if len(x_in.shape) == 1:
            x_in = x_in.reshape(1, -1)
        if ensemble_method == "gwrf":
            base_probs = []
            for model in ensemble_model.base_models:
                y_prob = model.predict_proba(x_in)
                base_probs.append(y_prob.reshape(-1, 1))
            meta_X = np.hstack(base_probs)
            return ensemble_model.meta_model.predict_proba(meta_X)[:, 1]
        else:
            return ensemble_model.predict_proba(x_in, feature_indices)

    try:
        print(f"  正在计算 SHAP 值 (KernelExplainer)...")
        explainer = shap.KernelExplainer(predict_func, X_background)
        shap_values_raw = explainer.shap_values(X_sample, nsamples=50)

        if isinstance(shap_values_raw, list):
            shap_values_raw = shap_values_raw[1]

        final_shap_values = np.abs(shap_values_raw).mean(axis=0)
        print("  ✅ SHAP 计算成功！")
        plot_success = True

    except Exception as e:
        print(f"  ⚠️  SHAP 计算跳过 ({str(e)[:50]})")
        shap_values_raw = None
        final_shap_values = None

    # 兜底方案：基模型重要性
    if final_shap_values is None or len(final_shap_values) != len(top_vars):
        try:
            print("  切换至基模型特征重要性方案...")
            imp_df = ensemble_model.get_base_model_importances(top_vars)
            final_shap_values = imp_df['importance'].values
            print("  ✅ 基模型重要性获取完成")
        except:
            print("  生成均匀分布兜底值")
            final_shap_values = np.ones(len(top_vars)) / len(top_vars)

    # 生成SHAP可视化图
    if plot_success and shap_values_raw is not None:
        try:
            print(f"\n  正在生成 SHAP 可视化图...")

            plt.figure(figsize=(10, 6))
            shap.summary_plot(
                shap_values_raw,
                X_sample,
                feature_names=top_vars,
                max_display=10,
                plot_type="dot",
                show=False
            )
            fig_path = os.path.join(experiment_dir, f"{ensemble_method}_shap_summary_plot.png")
            plt.tight_layout()
            plt.savefig(fig_path, dpi=150, bbox_inches='tight')
            plt.close()

            plt.figure(figsize=(8, 5))
            shap.summary_plot(
                shap_values_raw,
                X_sample,
                feature_names=top_vars,
                plot_type="bar",
                show=False
            )
            bar_path = os.path.join(experiment_dir, f"{ensemble_method}_shap_bar_plot.png")
            plt.tight_layout()
            plt.savefig(bar_path, dpi=150, bbox_inches='tight')
            plt.close()

            print(f"  ✅ SHAP 可视化图已保存")
        except Exception as e:
            print(f"  ⚠️  可视化图生成跳过: {e}")

    # 保存SHAP结果
    shap_df = pd.DataFrame({
        'feature': top_vars,
        'shap_importance': final_shap_values
    }).sort_values('shap_importance', ascending=False).reset_index(drop=True)

    csv_path = os.path.join(experiment_dir, f"{ensemble_method}_ensemble_shap_importance.csv")
    shap_df.to_csv(csv_path, index=False)

    print(f"\n=== Top 10 重要特征 ===")
    print(shap_df.head(10).to_string(index=False))
    print(f"\n  结果已保存: {csv_path}")

    return shap_df


def analyze_base_model_importance_corrected(ensemble_model, top_vars, experiment_dir, ensemble_method):
    """通用的基模型重要性分析函数"""
    print(f"  分析{ensemble_method.upper()}基模型重要性...")

    imp_df = ensemble_model.get_base_model_importances(top_vars)
    mean_importance = imp_df['importance'].values

    importance_df = pd.DataFrame({
        'feature': top_vars,
        'mean_importance': mean_importance
    }).sort_values('mean_importance', ascending=False).reset_index(drop=True)

    imp_path = os.path.join(experiment_dir, f"{ensemble_method}_base_model_importance_detailed.csv")
    importance_df.to_csv(imp_path, index=False)

    logger = logging.getLogger("post_analysis")
    logger.info(f"{ensemble_method}基模型重要性详细分析已保存: {imp_path}")
    print(f" {ensemble_method}基模型重要性详细分析已保存: {imp_path}")

    print(f"\n=== Top 10 {ensemble_method.upper()} 基模型平均重要性 ===")
    print(importance_df[['feature', 'mean_importance']].head(10).to_string(index=False))

    return importance_df


def combine_importance_corrected(freq_df, imp_df, shap_df, experiment_dir, ensemble_method):
    """综合重要性排序函数"""
    print("\n" + "=" * 60)
    print(f"          {ensemble_method.upper()} 变量重要性分析与排序")
    print("=" * 60)

    merged = freq_df[['feature', 'avg_freq', 'total_freq']].merge(
        imp_df[['feature', 'mean_importance']],
        on='feature', how='left'
    ).merge(
        shap_df[['feature', 'shap_importance']],
        on='feature', how='left'
    )

    merged = merged.fillna(0)

    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler()
    merged['avg_freq_norm'] = scaler.fit_transform(merged[['avg_freq']])
    merged['mean_importance_norm'] = scaler.fit_transform(merged[['mean_importance']])

    w1, w2 = 0.4, 0.6
    merged['ranking_score'] = w1 * merged['avg_freq_norm'] + w2 * merged['mean_importance_norm']

    merged = merged.sort_values('ranking_score', ascending=False).reset_index(drop=True)
    merged['rank'] = range(1, len(merged) + 1)

    merged = merged[['rank', 'feature', 'avg_freq', 'mean_importance',
                     'avg_freq_norm', 'mean_importance_norm',
                     'ranking_score', 'shap_importance']]

    merged_path = os.path.join(experiment_dir, f"{ensemble_method}_variable_importance_ranking.csv")
    merged.to_csv(merged_path, index=False)

    top10_vars = merged.head(10)

    print(f"=== Top 10 {ensemble_method.upper()} 变量重要性排序 ===")
    print("排序依据：RL动态选择频率 + 基模型重要性均值")
    print("SHAP值：解释各变量对集成模型的贡献度")
    print("\nRank | Feature | RL频次 | 基模型重要性 | 排序得分 | SHAP贡献度")
    print("-" * 80)

    for _, row in top10_vars.iterrows():
        print(f"{row['rank']:4d} | {row['feature']:15s} | {row['avg_freq']:7.2f} | "
              f"{row['mean_importance']:11.4f} | {row['ranking_score']:8.4f} | "
              f"{row['shap_importance']:10.4f}")

    top10_path = os.path.join(experiment_dir, f"{ensemble_method}_top10_variables_with_contributions.csv")
    top10_vars.to_csv(top10_path, index=False)

    print(f"\n 完整排序结果已保存: {merged_path}")
    print(f" Top 10变量结果已保存: {top10_path}")

    logger = logging.getLogger("post_analysis")
    logger.info(f"{ensemble_method}变量重要性排序分析已保存: {merged_path}")
    logger.info(f"{ensemble_method}Top 10变量及贡献度已保存: {top10_path}")

    return merged, top10_vars


def create_importance_visualization(merged_df, top10_vars, experiment_dir, ensemble_method):
    """通用的重要性可视化函数"""
    print(f" 创建{ensemble_method.upper()}重要性可视化...")

    try:
        import matplotlib.pyplot as plt
        import seaborn as sns

        plt.rcParams['font.sans-serif'] = ['Arial', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False

        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle(f'Top 10 Variables: {ensemble_method.upper()} Importance Analysis', fontsize=16, fontweight='bold')

        axes[0, 0].barh(range(len(top10_vars)), top10_vars['avg_freq'], color='skyblue')
        axes[0, 0].set_yticks(range(len(top10_vars)))
        axes[0, 0].set_yticklabels(top10_vars['feature'])
        axes[0, 0].set_title('RL Dynamic Selection Frequency')
        axes[0, 0].set_xlabel('Average Frequency')
        axes[0, 0].invert_yaxis()

        axes[0, 1].barh(range(len(top10_vars)), top10_vars['mean_importance'], color='lightcoral')
        axes[0, 1].set_yticks(range(len(top10_vars)))
        axes[0, 1].set_yticklabels(top10_vars['feature'])
        axes[0, 1].set_title('Base Models Average Importance')
        axes[0, 1].set_xlabel('Importance Value')
        axes[0, 1].invert_yaxis()

        axes[1, 0].barh(range(len(top10_vars)), top10_vars['shap_importance'], color='lightgreen')
        axes[1, 0].set_yticks(range(len(top10_vars)))
        axes[1, 0].set_yticklabels(top10_vars['feature'])
        axes[1, 0].set_title(f'SHAP Contribution to {ensemble_method.upper()} Model')
        axes[1, 0].set_xlabel('SHAP Value')
        axes[1, 0].invert_yaxis()

        axes[1, 1].barh(range(len(top10_vars)), top10_vars['ranking_score'], color='gold')
        axes[1, 1].set_yticks(range(len(top10_vars)))
        axes[1, 1].set_yticklabels(top10_vars['feature'])
        axes[1, 1].set_title(f'Ranking Score (RL + Base Models) - {ensemble_method.upper()}')
        axes[1, 1].set_xlabel('Ranking Score')
        axes[1, 1].invert_yaxis()

        plt.tight_layout()

        vis_path = os.path.join(experiment_dir, f"{ensemble_method}_top10_variable_importance_analysis.png")
        plt.savefig(vis_path, dpi=300, bbox_inches='tight')
        plt.close()

        logger = logging.getLogger("post_analysis")
        logger.info(f"{ensemble_method} Top 10变量可视化已保存: {vis_path}")
        print(f" {ensemble_method} Top 10变量可视化已保存: {vis_path}")

    except Exception as e:
        logger = logging.getLogger("post_analysis")
        logger.warning(f"{ensemble_method}可视化创建失败: {e}")
        print(f" {ensemble_method}可视化创建失败: {e}")


def load_tif_variables(top_vars):
    """加载TIF变量"""
    print(" 加载TIF变量...")

    tif_dir = config.TIF_DIR
    arrs = []
    meta = None
    arr_shape = None

    for i, var in enumerate(top_vars):
        tif_path = os.path.join(tif_dir, f"{var}.tif")
        if not os.path.exists(tif_path):
            raise FileNotFoundError(f"TIF文件不存在: {tif_path}")

        print(f"  加载变量 {i + 1}/{len(top_vars)}: {var}")

        with rasterio.open(tif_path) as src:
            arr = src.read(1)
            if arr_shape is None:
                arr_shape = arr.shape
            arrs.append(arr.flatten().astype(np.float32))
            if meta is None:
                meta = src.meta.copy()

    X_area = np.stack(arrs, axis=1)
    del arrs

    logger = logging.getLogger("post_analysis")
    logger.info(f"TIF变量加载完成: {X_area.shape}")
    print(f"  TIF变量加载完成: {X_area.shape}")
    print(f"  内存使用: {X_area.nbytes / (1024 ** 2):.1f} MB")

    return X_area, meta, arr_shape


# ============================================================
# 【核心修复】恢复您最早版本的正常predict_area逻辑，兼容GWRF
# ============================================================
def predict_area(ensemble_model, X_area, meta, arr_shape, top_vars, experiment_dir, ensemble_method):
    """
    【修复版】区域适生区预测函数
    核心恢复最早版本的「分块预测→合并结果→reshape→保存TIFF」逻辑，保证栅格完全对齐
    兼容GWRF模型，移除冗余的制图数据保存
    """
    import numpy as np
    import rasterio
    import gc
    import os

    print(f" 开始{ensemble_method.upper()}区域适生区预测...")
    print(f"  数据形状: {X_area.shape}")
    print(f"  预计内存需求: {X_area.nbytes / (1024 ** 2):.1f} MB")

    feature_indices = list(range(X_area.shape[1]))

    # 智能分块：普通模型用大分块，GWRF用小分块避免内存溢出
    if ensemble_method == "gwrf":
        chunk_size = 50000
        print(f"  模式：GWRF → 分块大小 {chunk_size} 像素")
    else:
        chunk_size = 10000000
        print(f"  模式：普通集成 → 分块大小 {chunk_size} 像素")

    n_samples = X_area.shape[0]
    n_chunks = (n_samples + chunk_size - 1) // chunk_size
    print(f"  将分 {n_chunks} 块处理，每块 {chunk_size} 个像素")

    # ====================== GWRF经纬度生成 ======================
    coords_area = None
    if ensemble_method == "gwrf":
        rows_total, cols_total = arr_shape
        transform = meta['transform']
        x_coords = np.arange(cols_total)
        y_coords = np.arange(rows_total)
        xx, yy = np.meshgrid(x_coords, y_coords)
        lon = transform.c + xx * transform.a + yy * transform.b
        lat = transform.f + xx * transform.d + yy * transform.e
        coords_area = np.column_stack([lon.flatten(), lat.flatten()])
        assert len(coords_area) == len(X_area), "GWRF经纬度数组与特征数组长度不匹配！"

    # ====================== 分块预测，合并结果 ======================
    y_pred_chunks = []
    for chunk_idx in range(n_chunks):
        gc.collect()
        start_idx = chunk_idx * chunk_size
        end_idx = min((chunk_idx + 1) * chunk_size, n_samples)

        print(f"  处理块 {chunk_idx + 1}/{n_chunks} (像素 {start_idx}-{end_idx})")

        # 提取当前块数据
        X_chunk = X_area[start_idx:end_idx]
        chunk_coords = coords_area[start_idx:end_idx] if coords_area is not None else None
        y_pred_chunk = None

        # 预测（适配GWRF）
        try:
            if ensemble_method == "gwrf" and chunk_coords is not None:
                y_pred_chunk = ensemble_model.predict_proba(X_chunk, feature_indices, chunk_coords)
            else:
                y_pred_chunk = ensemble_model.predict_proba(X_chunk, feature_indices)

            y_pred_chunks.append(y_pred_chunk)
        except Exception as e:
            print(f"  块 {chunk_idx + 1} 预测失败: {str(e)[:100]}")
            # 失败块填充nan
            y_pred_chunks.append(np.full(end_idx - start_idx, np.nan, dtype=np.float32))

        # 清理内存
        del X_chunk, y_pred_chunk
        if chunk_coords is not None:
            del chunk_coords
        gc.collect()

    # ====================== 合并结果，reshape成原始栅格形状 ======================
    print("  合并预测结果...")
    y_pred = np.concatenate(y_pred_chunks)
    y_pred = y_pred.reshape(arr_shape)

    # 清理内存
    del y_pred_chunks
    gc.collect()

    # ====================== 保存最终TIFF（唯一输出，无冗余文件） ======================
    meta.update(dtype='float32', count=1, compress='lzw', nodata=np.nan)
    out_tif = os.path.join(experiment_dir, f"{ensemble_method}_area_suitability_pred.tif")
    with rasterio.open(out_tif, 'w', **meta) as dst:
        dst.write(y_pred.astype(np.float32), 1)

    logger = logging.getLogger("post_analysis")
    logger.info(f"{ensemble_method}区域适生区概率tif已保存: {out_tif}")
    print(f" ✅ {ensemble_method}区域适生区预测完成！最终文件: {out_tif}")


def main(selected_top_features=None, ensemble_method=None):
    """主函数"""
    print("=" * 60)
    print("          后处理分析与适生区预测 (全集成方法兼容版)")
    print("=" * 60)

    # 1. 环境设置
    selected_features, experiment_dir, ensemble_method = setup_experiment_environment(selected_top_features,
                                                                                      ensemble_method)
    save_experiment_metadata(selected_features, experiment_dir, ensemble_method)

    # 2. 加载数据
    print("\n 加载数据...")
    top_vars, freq_df = load_top_variables(len(selected_features))
    X, y, coords_train = load_train_data(top_vars)

    # 3. 模型训练/加载
    print("\n 训练模型...")
    ensemble_model, loaded_top_vars = load_ensemble_model(experiment_dir, ensemble_method, top_vars)
    if ensemble_model is None or loaded_top_vars != top_vars:
        ensemble_model = train_ensemble_model(X, y, coords_train, top_vars, ensemble_method)
        save_ensemble_model(ensemble_model, top_vars, experiment_dir, ensemble_method)
    else:
        print(f" 使用已加载的模型")

    # 4. SHAP分析
    analyze_meta_model_shap(ensemble_model, X, top_vars, experiment_dir, ensemble_method)
    shap_df = analyze_shap_ensemble_corrected(ensemble_model, X, top_vars, experiment_dir, ensemble_method, coords_train)

    # 5. 重要性分析与排序
    print(f"\n 分析基模型重要性...")
    imp_df = analyze_base_model_importance_corrected(ensemble_model, top_vars, experiment_dir, ensemble_method)

    print(f"\n 综合排序...")
    merged_df, top10_vars = combine_importance_corrected(freq_df, imp_df, shap_df, experiment_dir, ensemble_method)

    print(f"\n 生成可视化...")
    create_importance_visualization(merged_df, top10_vars, experiment_dir, ensemble_method)

    # 6. 性能评估
    print(f"\n 性能评估...")
    X_test, y_test, coords_test = load_test_data(top_vars)
    if X_test is not None:
        final_performance_evaluation(ensemble_model, X_test, y_test, coords_test, top_vars, experiment_dir, ensemble_method)

    # 7. 区域预测（核心修复版）
    print(f"\n 区域预测...")
    try:
        X_area, meta, arr_shape = load_tif_variables(top_vars)
        predict_area(ensemble_model, X_area, meta, arr_shape, top_vars, experiment_dir, ensemble_method)
    except Exception as e:
        print(f" 区域预测跳过: {e}")
        import traceback
        traceback.print_exc()

    # 8. 空间SHAP栅格生成（可选，注释掉即可关闭）
    generate_spatial_shap_rasters(ensemble_model, top_vars, experiment_dir, ensemble_method, coords_train)

    print("\n" + "=" * 60)
    print(f"          {ensemble_method.upper()} 分析完成")
    print("=" * 60)
    print(f" 结果目录: {experiment_dir}")
    return experiment_dir


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description='后处理分析与适生区预测（全集成方法兼容版）')
    parser.add_argument('--top_features', type=int, default=None,
                        help='选择的Top变量数量')
    parser.add_argument('--ensemble_method', type=str, default=None,
                        choices=["stacking", "bagging", "boosting", "gwrf"],
                        help='集成方法')

    args = parser.parse_args()

    if args.top_features is not None:
        config.set_selected_top_features(args.top_features)

    main(args.top_features, args.ensemble_method)