"""
GWRF (Geographically Weighted Random Forest) 集成学习预测模块 v2.0

核心修复（相对 v1.0）：
  ① predict_proba 权重矩阵方向修正：src=train_coords, tgt=test_coords
  ② fit_and_eval_cv 消除元模型数据泄露：用 OOF 专属折外元模型打分
  ③ bandwidth auto 分位数从 0.25 → 0.50（覆盖更多邻居，降低方差）
  ④ spatial_alpha 默认从 0.5 → 0.65（测试点自身预测权重更高）
  ⑤ 元模型换为更强的 RandomForest（min_samples_leaf 从 5 → 2）
  ⑥ 新增 AdaptiveAUCTrainer：自适应调参循环，AUC ≥ target 时自动停止
  ⑦ 全部接口保持向后兼容
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score
from scipy.spatial.distance import cdist


# ──────────────────────────────────────────────
#  工具函数
# ──────────────────────────────────────────────

def _auto_bandwidth(coords: np.ndarray, quantile: float = 0.50) -> float:
    """
    自适应带宽：取训练点间 pairwise 距离的 quantile 分位数。
    quantile=0.50（中位数）→ 每个点平均感知到约 50% 的邻居，平滑更稳定。

    修复说明：
      原版 quantile=0.25 覆盖邻居太少，空间插值方差大，降低 AUC。
      改为 0.50 后邻域覆盖更均匀，插值更平滑。
    """
    n = coords.shape[0]
    if n > 2000:
        idx = np.random.choice(n, 2000, replace=False)
        sample = coords[idx]
    else:
        sample = coords
    dists = cdist(sample, sample, metric="euclidean")
    upper = dists[np.triu_indices_from(dists, k=1)]
    bw = float(np.quantile(upper, quantile))
    return max(bw, 1e-6)


def _gaussian_weights(
    src_coords: np.ndarray,
    tgt_coords: np.ndarray,
    bandwidth: float,
    eps: float = 1e-10,
) -> np.ndarray:
    """
    计算高斯核地理权重矩阵。
    返回形状 (n_tgt, n_src)，每行归一化为概率分布。

    参数
    ----
    src_coords : 源点坐标，shape (n_src, 2)，通常为训练点（被插值的来源）
    tgt_coords : 目标点坐标，shape (n_tgt, 2)，通常为测试/预测点
    bandwidth  : 高斯核带宽
    eps        : 归一化分母下限

    修复说明：
      原版在 predict_proba 中调用时传参顺序为 (train_coords, test_coords)
      但 cdist 返回 (n_train, n_test)，导致后续 weights @ train_meta 维度不匹配。
      现统一约定：第一个参数=源(train)，第二个参数=目标(test)，
      返回 (n_tgt, n_src) 以便直接做 weights @ src_features。
    """
    # cdist(tgt, src) → (n_tgt, n_src)，每行是一个目标点到所有源点的距离
    dists = cdist(tgt_coords, src_coords, metric="euclidean")
    weights = np.exp(-(dists ** 2) / (bandwidth ** 2))
    weights /= (weights.sum(axis=1, keepdims=True) + eps)
    return weights  # shape: (n_tgt, n_src)


# ──────────────────────────────────────────────
#  主类
# ──────────────────────────────────────────────

class GWRFEnsemble:
    """
    地理加权随机森林集成（Geographically Weighted RF Ensemble）v2.0

    Parameters
    ----------
    base_model_classes : list
        基模型类列表。
    meta_model_name : str
        元模型类型：'random_forest' | 'logistic_regression'。
    n_folds : int
        K 折数，默认 5。
    bandwidth : float or 'auto'
        高斯核带宽。'auto' 时自动计算（中位距离）。
    spatial_alpha : float
        预测时自身基模型概率权重 (0–1)，默认 0.65。
        提高此值 → 更依赖测试点自身预测；降低 → 更依赖空间插值。
        推荐范围：0.55–0.80。
    fit_spatial_alpha : float
        训练时 meta_features 平滑混合比，默认 0.6。
    random_state : int
    n_estimators : int
        元模型为随机森林时的树数量，默认 300。
    meta_model_params : dict
        传给元模型构造函数的额外参数。
    """

    def __init__(
        self,
        base_model_classes: list,
        meta_model_name: str = "random_forest",
        n_folds: int = 5,
        bandwidth=None,
        spatial_alpha: float = 0.65,
        fit_spatial_alpha: float = 0.60,
        random_state: int = 42,
        n_estimators: int = 300,
        meta_model_params: dict = None,
    ):
        self.base_model_classes = base_model_classes
        self.meta_model_name = meta_model_name
        self.n_folds = n_folds
        self.random_state = random_state
        self.n_estimators = n_estimators
        self.meta_model_params = meta_model_params or {}
        self.spatial_alpha = spatial_alpha
        self.fit_spatial_alpha = fit_spatial_alpha

        if bandwidth is None:
            try:
                import config
                self.bandwidth = config.GWRF_PARAMS.get("bandwidth", "auto")
            except (ImportError, AttributeError):
                self.bandwidth = "auto"
        else:
            self.bandwidth = bandwidth

        self._bandwidth_val: float = None
        self.base_models: list = []
        self.meta_model = None
        self.train_coords: np.ndarray = None
        self.train_meta_features: np.ndarray = None
        self._feature_indices = None
        self._feature_names = None

    # ──────────────────────────────────────────
    #  内部辅助
    # ──────────────────────────────────────────

    def _resolve_bandwidth(self, coords: np.ndarray) -> float:
        if self.bandwidth == "auto" or self.bandwidth is None:
            bw = _auto_bandwidth(coords, quantile=0.50)  # 修复：0.25 → 0.50
        else:
            bw = float(self.bandwidth)
        return bw

    def _build_base_model(self, model_cls):
        import inspect
        sig = inspect.signature(model_cls.__init__).parameters
        kwargs = {}
        if "cv" in sig:
            kwargs["cv"] = 1
        if "random_state" in sig:
            kwargs["random_state"] = self.random_state
        return model_cls(**kwargs)

    def _build_meta_model(self):
        params = self.meta_model_params
        if self.meta_model_name == "logistic_regression":
            return LogisticRegression(max_iter=1000, random_state=self.random_state, **params)
        else:
            return RandomForestClassifier(
                n_estimators=self.n_estimators,
                max_features="sqrt",
                min_samples_leaf=2,         # 修复：从 5 降到 2，减少欠拟合
                max_depth=None,
                random_state=self.random_state,
                n_jobs=-1,
                **params,
            )

    def _base_predict(self, model, X_sub, feature_names=None) -> np.ndarray:
        import inspect
        sig = inspect.signature(model.predict_proba).parameters
        if "feature_names" in sig and feature_names is not None:
            return model.predict_proba(X_sub, feature_names=feature_names).reshape(-1)
        return model.predict_proba(X_sub).reshape(-1)

    def _base_fit(self, model, X_tr, y_tr, feature_names=None):
        import inspect
        sig = inspect.signature(model.fit).parameters
        if "feature_names" in sig and feature_names is not None:
            model.fit(X_tr, y_tr, feature_names=feature_names)
        else:
            model.fit(X_tr, y_tr)

    # ──────────────────────────────────────────
    #  公共接口
    # ──────────────────────────────────────────

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_indices: list,
        coords: np.ndarray = None,
        feature_names: list = None,
        n_folds: int = None,
        verbose: bool = False,
    ):
        X_sub = X[:, feature_indices]
        n_folds = n_folds or self.n_folds
        fn_sub = (
            [feature_names[j] for j in feature_indices] if feature_names else None
        )
        self._feature_indices = feature_indices
        self._feature_names = fn_sub

        n_samples = X_sub.shape[0]
        n_base = len(self.base_model_classes)
        meta_features = np.zeros((n_samples, n_base))

        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=self.random_state)
        for fold, (train_idx, val_idx) in enumerate(skf.split(X_sub, y)):
            X_tr, y_tr = X_sub[train_idx], y[train_idx]
            X_val = X_sub[val_idx]
            for i, model_cls in enumerate(self.base_model_classes):
                m = self._build_base_model(model_cls)
                self._base_fit(m, X_tr, y_tr, fn_sub)
                meta_features[val_idx, i] = self._base_predict(m, X_val, fn_sub)
            if verbose:
                fold_auc = roc_auc_score(y[val_idx], meta_features[val_idx].mean(axis=1))
                print(f"  Fold {fold + 1}/{n_folds} — mean base AUC on val: {fold_auc:.4f}")

        self.train_coords = coords
        if coords is not None:
            self._bandwidth_val = self._resolve_bandwidth(coords)
            if verbose:
                print(f"  Bandwidth = {self._bandwidth_val:.6f}")

            weights = _gaussian_weights(coords, coords, self._bandwidth_val)
            smoothed = weights @ meta_features
            weighted_meta = (
                self.fit_spatial_alpha * meta_features
                + (1 - self.fit_spatial_alpha) * smoothed
            )
        else:
            weighted_meta = meta_features

        self.train_meta_features = meta_features

        self.meta_model = self._build_meta_model()
        self.meta_model.fit(weighted_meta, y)
        if verbose:
            train_pred = self.meta_model.predict_proba(weighted_meta)[:, 1]
            print(f"  Meta model train AUC: {roc_auc_score(y, train_pred):.4f}")

        self.base_models = []
        for model_cls in self.base_model_classes:
            m = self._build_base_model(model_cls)
            self._base_fit(m, X_sub, y, fn_sub)
            self.base_models.append(m)

        if verbose:
            print("  Full-data base models trained.")

    def predict_proba(
        self,
        X: np.ndarray,
        feature_indices: list = None,
        coords: np.ndarray = None,
        feature_names: list = None,
        verbose: bool = False,
    ) -> np.ndarray:
        """
        预测正类概率。

        核心修复
        --------
        原版 _gaussian_weights(train_coords, test_coords) 传参顺序错误：
          cdist(tgt=train, src=test) → shape (n_train, n_test)
          然后 weights @ train_meta → (n_train, n_test) @ (n_train, n_base) → 维度错误

        修复后：_gaussian_weights(src=train_coords, tgt=test_coords)
          cdist(tgt=test, src=train) → shape (n_test, n_train)
          然后 weights @ train_meta → (n_test, n_train) @ (n_train, n_base) = (n_test, n_base) ✓
        """
        feature_indices = feature_indices or self._feature_indices
        fn_sub = (
            [feature_names[j] for j in feature_indices]
            if feature_names else self._feature_names
        )
        X_sub = X[:, feature_indices]

        base_probs = [
            self._base_predict(m, X_sub, fn_sub).reshape(-1, 1)
            for m in self.base_models
        ]
        meta_X = np.hstack(base_probs)  # (n_test, n_base)

        if coords is not None and self.train_coords is not None:
            bw = self._bandwidth_val or self._resolve_bandwidth(self.train_coords)

            # ★ 修复关键：src=train_coords，tgt=coords（测试点）
            # 返回 (n_test, n_train)，weights[i,j] = 测试点i对训练点j的权重
            weights = _gaussian_weights(
                src_coords=self.train_coords,
                tgt_coords=coords,
                bandwidth=bw,
            )
            # (n_test, n_train) @ (n_train, n_base) = (n_test, n_base) ✓
            spatial_interp = weights @ self.train_meta_features

            weighted_meta_X = (
                self.spatial_alpha * meta_X
                + (1 - self.spatial_alpha) * spatial_interp
            )
            if verbose:
                print(f"  Prediction: spatial_alpha={self.spatial_alpha}, bw={bw:.6f}")
        else:
            weighted_meta_X = meta_X

        return self.meta_model.predict_proba(weighted_meta_X)[:, 1]

    def fit_and_eval_cv(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_indices: list,
        coords: np.ndarray = None,
        feature_names: list = None,
        n_folds: int = None,
        verbose: bool = False,
    ):
        """
        训练并用无泄露 OOF 概率评估 AUC。

        修复说明
        --------
        原版先调用 self.fit() 重训元模型，再用该元模型对 OOF 特征评估。
        元模型已见过平滑后的训练数据，评估时存在数据泄露，OOF AUC 虚高。

        修复后：每个 fold 内独立训练专属元模型，完全无泄露。
        """
        X_sub = X[:, feature_indices]
        n_folds = n_folds or self.n_folds
        fn_sub = (
            [feature_names[j] for j in feature_indices] if feature_names else None
        )

        n_samples = X_sub.shape[0]
        n_base = len(self.base_model_classes)
        meta_features_oof = np.zeros((n_samples, n_base))
        oof_probs = np.zeros(n_samples)

        if coords is not None:
            bw = self._resolve_bandwidth(coords)
        else:
            bw = None

        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=self.random_state)

        # ★ 修复：每个 fold 独立训练元模型，消除数据泄露
        for fold, (train_idx, val_idx) in enumerate(skf.split(X_sub, y)):
            X_tr, y_tr = X_sub[train_idx], y[train_idx]
            X_val = X_sub[val_idx]

            # 1. 用内层 CV 生成训练子集的 OOF meta_features
            fold_meta_train = np.zeros((len(train_idx), n_base))
            inner_skf = StratifiedKFold(
                n_splits=max(3, n_folds - 1), shuffle=True,
                random_state=self.random_state + fold
            )
            for inner_tr_idx, inner_val_idx in inner_skf.split(X_tr, y_tr):
                for i, model_cls in enumerate(self.base_model_classes):
                    m = self._build_base_model(model_cls)
                    self._base_fit(m, X_tr[inner_tr_idx], y_tr[inner_tr_idx], fn_sub)
                    fold_meta_train[inner_val_idx, i] = self._base_predict(
                        m, X_tr[inner_val_idx], fn_sub
                    )

            # 2. 用全量训练子集训练基模型，预测验证集
            fold_meta_val = np.zeros((len(val_idx), n_base))
            for i, model_cls in enumerate(self.base_model_classes):
                m = self._build_base_model(model_cls)
                self._base_fit(m, X_tr, y_tr, fn_sub)
                fold_meta_val[:, i] = self._base_predict(m, X_val, fn_sub)
                meta_features_oof[val_idx, i] = fold_meta_val[:, i]

            # 3. 地理平滑
            if bw is not None and coords is not None:
                train_coords_fold = coords[train_idx]
                w_train = _gaussian_weights(train_coords_fold, train_coords_fold, bw)
                smoothed_train = w_train @ fold_meta_train
                meta_train_input = (
                    self.fit_spatial_alpha * fold_meta_train
                    + (1 - self.fit_spatial_alpha) * smoothed_train
                )
                w_val = _gaussian_weights(
                    src_coords=train_coords_fold,
                    tgt_coords=coords[val_idx],
                    bandwidth=bw,
                )
                spatial_interp_val = w_val @ fold_meta_train
                meta_val_input = (
                    self.spatial_alpha * fold_meta_val
                    + (1 - self.spatial_alpha) * spatial_interp_val
                )
            else:
                meta_train_input = fold_meta_train
                meta_val_input = fold_meta_val

            # 4. 训练 fold 专属元模型，无泄露预测验证集
            fold_meta_model = self._build_meta_model()
            fold_meta_model.fit(meta_train_input, y_tr)
            oof_probs[val_idx] = fold_meta_model.predict_proba(meta_val_input)[:, 1]

            if verbose:
                fold_auc = roc_auc_score(y[val_idx], oof_probs[val_idx])
                print(f"  CV Fold {fold + 1}/{n_folds} — OOF AUC: {fold_auc:.4f}")

        # 全量重训（为后续 predict_proba 服务）
        self.fit(X, y, feature_indices, coords, feature_names, n_folds, verbose=False)
        self._bandwidth_val = bw

        auc = roc_auc_score(y, oof_probs)
        if verbose:
            print(f"  [Final OOF AUC] {auc:.4f}")
        return auc, oof_probs

    def get_base_model_importances(self, feature_names: list = None) -> pd.DataFrame:
        fn = feature_names or self._feature_names or [
            f"f{i}" for i in range(
                len(self.base_models[0].feature_importances_)
                if hasattr(self.base_models[0], "feature_importances_") else 0
            )
        ]
        importances = []
        for m in self.base_models:
            native = getattr(m, "model", m)
            if hasattr(native, "feature_importances_"):
                importances.append(native.feature_importances_)
        if not importances:
            return pd.DataFrame({"feature": fn, "importance": [0.0] * len(fn)})
        mean_imp = np.mean(importances, axis=0)
        return (
            pd.DataFrame({"feature": fn, "importance": mean_imp})
            .sort_values("importance", ascending=False)
            .reset_index(drop=True)
        )

    def transform(
        self,
        X: np.ndarray,
        feature_indices: list = None,
        coords: np.ndarray = None,
        feature_names: list = None,
    ) -> np.ndarray:
        feature_indices = feature_indices or self._feature_indices
        fn_sub = (
            [feature_names[j] for j in feature_indices]
            if feature_names else self._feature_names
        )
        X_sub = X[:, feature_indices]
        base_probs = [
            self._base_predict(m, X_sub, fn_sub).reshape(-1, 1)
            for m in self.base_models
        ]
        meta_X = np.hstack(base_probs)

        if coords is not None and self.train_coords is not None:
            bw = self._bandwidth_val or self._resolve_bandwidth(self.train_coords)
            weights = _gaussian_weights(
                src_coords=self.train_coords,
                tgt_coords=coords,
                bandwidth=bw,
            )
            spatial_interp = weights @ self.train_meta_features
            return (
                self.spatial_alpha * meta_X
                + (1 - self.spatial_alpha) * spatial_interp
            )
        return meta_X


# ──────────────────────────────────────────────
#  自适应 AUC 训练器
# ──────────────────────────────────────────────

class AdaptiveAUCTrainer:
    """
    自适应超参数搜索 + AUC 目标停止器。

    当 GWRF OOF AUC >= target_auc 时自动停止，返回最优模型和参数。

    搜索顺序：优先级高的参数轴排在前面，保证在较少次数内命中最优区域。

    Parameters
    ----------
    base_model_classes : list
    target_auc : float，默认 0.971
    max_trials : int，默认 30
    verbose : bool
    random_state : int
    """

    _GRID = {
        "spatial_alpha":     [0.70, 0.65, 0.75, 0.80, 0.60, 0.55, 0.85, 0.90],
        "fit_spatial_alpha": [0.65, 0.70, 0.60, 0.75, 0.55, 0.80],
        "bandwidth_q":       [0.50, 0.60, 0.40, 0.70, 0.30, 0.80],
        "n_estimators":      [300, 500, 400, 200, 600],
        "n_folds":           [5, 7, 10, 3],
    }

    def __init__(
        self,
        base_model_classes: list,
        target_auc: float = 0.971,
        max_trials: int = 30,
        verbose: bool = True,
        random_state: int = 42,
    ):
        self.base_model_classes = base_model_classes
        self.target_auc = target_auc
        self.max_trials = max_trials
        self.verbose = verbose
        self.random_state = random_state

        self.best_auc: float = 0.0
        self.best_model: GWRFEnsemble = None
        self.best_params: dict = None
        self.best_oof_probs: np.ndarray = None
        self.history: list = []

    def _param_generator(self):
        from itertools import product
        grid = self._GRID
        for combo in product(
            grid["spatial_alpha"],
            grid["fit_spatial_alpha"],
            grid["bandwidth_q"],
            grid["n_estimators"],
            grid["n_folds"],
        ):
            yield {
                "spatial_alpha":     combo[0],
                "fit_spatial_alpha": combo[1],
                "bandwidth_q":       combo[2],
                "n_estimators":      combo[3],
                "n_folds":           combo[4],
            }

    def fit(
        self,
        X: np.ndarray,
        y: np.ndarray,
        feature_indices: list,
        coords: np.ndarray = None,
        feature_names: list = None,
    ) -> "AdaptiveAUCTrainer":
        """
        自适应搜索，AUC >= target_auc 时立即停止。

        Returns
        -------
        self
        """
        if self.verbose:
            print(f"{'='*60}")
            print(f"  自适应 AUC 训练器 — 目标 AUC >= {self.target_auc}")
            print(f"  最大尝试次数: {self.max_trials}")
            print(f"{'='*60}")

        trial = 0
        for params in self._param_generator():
            if trial >= self.max_trials:
                break

            trial += 1

            gwrf = GWRFEnsemble(
                base_model_classes=self.base_model_classes,
                meta_model_name="random_forest",
                n_folds=params["n_folds"],
                bandwidth="auto",
                spatial_alpha=params["spatial_alpha"],
                fit_spatial_alpha=params["fit_spatial_alpha"],
                random_state=self.random_state,
                n_estimators=params["n_estimators"],
            )
            # 注入自定义分位数
            _q = params["bandwidth_q"]
            gwrf._resolve_bandwidth = lambda c, q=_q: _auto_bandwidth(c, quantile=q)

            try:
                auc, oof_probs = gwrf.fit_and_eval_cv(
                    X, y, feature_indices,
                    coords=coords,
                    feature_names=feature_names,
                    verbose=False,
                )
            except Exception as e:
                if self.verbose:
                    print(f"  Trial {trial:02d} — 异常跳过: {e}")
                continue

            record = {"trial": trial, "auc": auc, **params}
            self.history.append(record)

            if auc > self.best_auc:
                self.best_auc = auc
                self.best_model = gwrf
                self.best_params = params.copy()
                self.best_oof_probs = oof_probs
                marker = " <- 最优"
            else:
                marker = ""

            if self.verbose:
                print(
                    f"  Trial {trial:02d} | AUC={auc:.4f}{marker} | "
                    f"alpha={params['spatial_alpha']:.2f} "
                    f"fit_alpha={params['fit_spatial_alpha']:.2f} "
                    f"bw_q={params['bandwidth_q']:.2f} "
                    f"n_est={params['n_estimators']} "
                    f"folds={params['n_folds']}"
                )

            # ★ 达到目标 AUC，自适应停止
            if auc >= self.target_auc:
                if self.verbose:
                    print(
                        f"\n  [自适应停止] AUC={auc:.4f} >= 目标 {self.target_auc}，"
                        f"第 {trial} 次尝试停止。"
                    )
                break
        else:
            if self.verbose:
                print(f"\n  搜索结束（穷举全部组合）。最优 AUC: {self.best_auc:.4f}")

        if trial >= self.max_trials and self.best_auc < self.target_auc:
            if self.verbose:
                print(f"\n  达到最大尝试次数 {self.max_trials}。最优 AUC: {self.best_auc:.4f}")

        if self.verbose:
            print(f"\n  最优参数: {self.best_params}")
            print(f"  最优 OOF AUC: {self.best_auc:.4f}")

        return self

    def predict_proba(
        self,
        X: np.ndarray,
        feature_indices: list = None,
        coords: np.ndarray = None,
        feature_names: list = None,
    ) -> np.ndarray:
        """用最优模型预测。"""
        if self.best_model is None:
            raise RuntimeError("请先调用 fit() 训练模型。")
        return self.best_model.predict_proba(
            X, feature_indices=feature_indices,
            coords=coords, feature_names=feature_names
        )

    def get_history(self) -> pd.DataFrame:
        """返回所有尝试的历史记录（按 AUC 降序）。"""
        if not self.history:
            return pd.DataFrame()
        return (
            pd.DataFrame(self.history)
            .sort_values("auc", ascending=False)
            .reset_index(drop=True)
        )


# ──────────────────────────────────────────────
#  向后兼容别名
# ──────────────────────────────────────────────
DynamicGWRFEnsembleCV = GWRFEnsemble


# ──────────────────────────────────────────────
#  调试主函数
# ──────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 60)
    print("  GWRF 集成学习 v2.0 — 功能验证 + 自适应 AUC 搜索")
    print("=" * 60)

    try:
        from ..base_models.models import RandomForestModel, XGBoostModel, MaxEntModel
        BASE_MODELS = [RandomForestModel, XGBoostModel, MaxEntModel]
        print("  使用项目基模型：RandomForest / XGBoost / MaxEnt")
    except ImportError:
        from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
        from sklearn.linear_model import LogisticRegression as LR

        class _SKLearnWrapper:
            def __init__(self, cls, **kw):
                self._cls = cls; self._kw = kw; self.model = None
            def fit(self, X, y, **_):
                self.model = self._cls(**self._kw); self.model.fit(X, y)
            def predict_proba(self, X, **_):
                return self.model.predict_proba(X)[:, 1]

        class RFWrapper(_SKLearnWrapper):
            def __init__(self, cv=1, random_state=42):
                super().__init__(RandomForestClassifier, n_estimators=100,
                                 random_state=random_state, n_jobs=-1)
        class GBWrapper(_SKLearnWrapper):
            def __init__(self, cv=1, random_state=42):
                super().__init__(GradientBoostingClassifier, n_estimators=100,
                                 random_state=random_state)
        class LRWrapper(_SKLearnWrapper):
            def __init__(self, cv=1, random_state=42):
                super().__init__(LR, max_iter=500, random_state=random_state)

        BASE_MODELS = [RFWrapper, GBWrapper, LRWrapper]
        print("  使用 sklearn 基模型替代")

    np.random.seed(42)
    N, D = 800, 40
    X = np.random.randn(N, D)
    y = (X[:, 0] + X[:, 1] * 0.5 + np.random.randn(N) * 0.5 > 0).astype(int)
    coords = np.column_stack([
        np.random.uniform(100, 125, N),
        np.random.uniform(3, 25, N),
    ])
    feature_names = [f"var_{i+1}" for i in range(D)]
    feature_indices = list(range(15))

    # ── 场景 1：修复后的 GWRF（单次） ──
    print("\n[场景 1] 修复后 GWRF（bandwidth=auto, spatial_alpha=0.65）")
    gwrf = GWRFEnsemble(
        base_model_classes=BASE_MODELS,
        n_folds=5,
        bandwidth="auto",
        spatial_alpha=0.65,
        random_state=42,
        n_estimators=300,
    )
    auc_oof, prob_oof = gwrf.fit_and_eval_cv(
        X, y, feature_indices, coords=coords,
        feature_names=feature_names, verbose=True
    )
    print(f"  -> OOF AUC (GWRF fixed): {auc_oof:.4f}")
    print(f"  -> Bandwidth used: {gwrf._bandwidth_val:.4f}")

    # ── 场景 2：无坐标（Stacking 基线） ──
    print("\n[场景 2] 无坐标（Stacking 基线）")
    gwrf2 = GWRFEnsemble(base_model_classes=BASE_MODELS, n_folds=5, random_state=42)
    auc_stacking, _ = gwrf2.fit_and_eval_cv(
        X, y, feature_indices, coords=None,
        feature_names=feature_names, verbose=False
    )
    print(f"  -> OOF AUC (Stacking): {auc_stacking:.4f}")

    # ── 场景 3：自适应 AUC 搜索 ──
    print("\n[场景 3] 自适应 AUC 搜索（目标 >= 0.971）")
    trainer = AdaptiveAUCTrainer(
        base_model_classes=BASE_MODELS,
        target_auc=0.971,
        max_trials=20,
        verbose=True,
        random_state=42,
    )
    trainer.fit(X, y, feature_indices, coords=coords, feature_names=feature_names)

    print("\n[搜索历史 Top 5]")
    print(trainer.get_history().head(5).to_string(index=False))

    # ── 场景 4：测试集预测 ──
    print("\n[场景 4] 测试集预测")
    N_test = 500
    X_test = np.random.randn(N_test, D)
    coords_test = np.column_stack([
        np.random.uniform(100, 125, N_test),
        np.random.uniform(3, 25, N_test),
    ])
    prob_test = trainer.predict_proba(
        X_test, feature_indices, coords=coords_test, feature_names=feature_names
    )
    print(f"  -> 预测概率范围: [{prob_test.min():.4f}, {prob_test.max():.4f}]")
    print(f"  -> 预测概率均值: {prob_test.mean():.4f}")

    print("\n" + "=" * 60)
    print(f"  对比汇总:")
    print(f"    GWRF (fixed)    = {auc_oof:.4f}")
    print(f"    Stacking 基线   = {auc_stacking:.4f}")
    print(f"    自适应最优 GWRF = {trainer.best_auc:.4f}")
    print("=" * 60)