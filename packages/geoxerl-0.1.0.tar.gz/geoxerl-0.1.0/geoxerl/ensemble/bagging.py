"""
Dynamic bagging ensemble with config参数支持（与Stacking并列）。
Bagging核心逻辑：并行训练多个基模型，预测时取概率均值

修复说明：
- 原版 fit_and_eval_cv 先全量 fit 再 K 折评估 → 验证集已见过训练数据，AUC 虚高
- 修复后：K 折内部独立 fit+predict，OOF 概率拼成全量预测，AUC 基于 OOF
- 最终 self.models 仍在全量数据上重新 fit，供后续 predict_proba 使用
"""

import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
import pandas as pd
from . import config


class DynamicBaggingEnsembleCV:
    def __init__(
            self,
            base_model_classes,
            random_state=None,
            n_estimators=None,
            n_folds=None,
            voting="soft"
    ):
        self.base_model_classes = base_model_classes
        self.random_state = random_state if random_state is not None else config.RANDOM_SEED
        self.n_estimators = n_estimators if n_estimators is not None else config.N_FOLDS
        self.n_folds = n_folds if n_folds is not None else config.N_FOLDS
        self.voting = voting
        self.models = []

    def _fit_on_data(self, X_sub, y, feature_names_sub=None, verbose=False):
        """
        内部方法：在给定数据上训练所有基模型，返回模型列表。
        抽出来复用，避免在 K 折和全量训练之间重复代码。
        """
        models = []
        for cls_idx, model_cls in enumerate(self.base_model_classes):
            if verbose:
                print(f"  训练基模型 {cls_idx + 1}/{len(self.base_model_classes)}: {model_cls.__name__}")
            for est_idx in range(self.n_estimators):
                current_seed = self.random_state + est_idx
                model = model_cls(cv=1, random_state=current_seed)
                model.fit(X_sub, y, feature_names=feature_names_sub)
                models.append(model)
        return models

    def _predict_with_models(self, models, X_sub):
        """
        内部方法：用给定模型列表对 X_sub 预测，返回均值概率。
        """
        all_probs = [m.predict_proba(X_sub).reshape(-1) for m in models]
        return np.mean(np.array(all_probs), axis=0)

    def fit(self, X, y, feature_indices, feature_names=None, verbose=False):
        """
        全量训练 Bagging 模型（供 fit 后单独调用 predict_proba 使用）。
        """
        X_sub = X[:, feature_indices]
        feature_names_sub = [feature_names[j] for j in feature_indices] if feature_names else None
        self.models = self._fit_on_data(X_sub, y, feature_names_sub, verbose)
        if verbose:
            print(f"Bagging 训练完成：共 {len(self.models)} 个基模型"
                  f"（{len(self.base_model_classes)} 类 × {self.n_estimators} 份）")

    def predict_proba(self, X, feature_indices, feature_names=None, verbose=False):
        """
        预测概率：所有基模型预测后取均值（soft voting）。
        需先调用 fit。
        """
        X_sub = X[:, feature_indices]
        final_prob = self._predict_with_models(self.models, X_sub)
        if verbose:
            print(f"[Bagging predict] 基模型数量: {len(self.models)}, 输出 shape: {final_prob.shape}")
        return final_prob

    def fit_and_eval_cv(self, X, y, feature_indices, feature_names=None, n_folds=None, verbose=False):
        """
        【修复版】训练 + 交叉验证评估，消除数据泄露。

        核心逻辑变化：
          原版：先全量 fit → 再 K 折评估（验证集已参与训练，泄露）
          修复：K 折内每折独立 fit → OOF 预测拼全量 → 计算 OOF AUC
               → 最后再全量 fit 一次，更新 self.models 供后续推理

        返回：
          mean_auc : float，基于 OOF 的真实泛化 AUC
          oof_prob : ndarray shape (n_samples,)，OOF 预测概率（与 Stacking 接口对齐）
        """
        n_folds = n_folds if n_folds is not None else self.n_folds
        X_sub = X[:, feature_indices]
        feature_names_sub = [feature_names[j] for j in feature_indices] if feature_names else None

        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=self.random_state)
        oof_prob = np.zeros(X_sub.shape[0])  # 存储 OOF 概率
        auc_scores = []

        for fold, (train_idx, val_idx) in enumerate(skf.split(X_sub, y)):
            X_tr, y_tr = X_sub[train_idx], y[train_idx]
            X_val, y_val = X_sub[val_idx], y[val_idx]

            # ★ 关键修复：每折独立训练，验证集绝不参与本折训练
            fold_models = self._fit_on_data(X_tr, y_tr, feature_names_sub, verbose=False)

            # 在验证集上预测（OOF）
            val_prob = self._predict_with_models(fold_models, X_val)
            oof_prob[val_idx] = val_prob

            auc = roc_auc_score(y_val, val_prob)
            auc_scores.append(auc)

            if verbose:
                print(f"Bagging K 折评估：第 {fold + 1} 折 AUC = {auc:.4f}")

        mean_auc = np.mean(auc_scores)
        if verbose:
            print(f"Bagging OOF 平均 AUC: {mean_auc:.4f} (±{np.std(auc_scores):.4f})")

        # 全量重新训练，更新 self.models 供后续 predict_proba 使用
        self.fit(X, y, feature_indices, feature_names, verbose=False)
        if verbose:
            print("Bagging 全量模型已更新（用于后续推理）")

        # ★ 返回 OOF 概率（不含训练集信息），与 Stacking 接口对齐
        return mean_auc, oof_prob

    def get_base_model_importances(self, feature_names):
        """
        提取所有基模型的特征重要性（与 Stacking 接口一致）。
        """
        all_importances = []
        for model in self.models:
            native_model = getattr(model, "model", model)
            if hasattr(native_model, "feature_importances_"):
                all_importances.append(native_model.feature_importances_)

        if all_importances:
            mean_importance = np.mean(all_importances, axis=0)
        else:
            mean_importance = np.zeros(len(feature_names))

        return pd.DataFrame({
            "feature": feature_names,
            "importance": mean_importance
        }).sort_values("importance", ascending=False).reset_index(drop=True)


if __name__ == "__main__":
    print("==== 动态Bagging集成类调试 ====")
    from ..base_models.models import RandomForestModel, XGBoostModel, MaxEntModel, SVMModel

    n_samples, n_features = 1000, 50
    np.random.seed(42)
    X = np.random.randn(n_samples, n_features)
    y = np.random.randint(0, 2, n_samples)
    feature_names = [f"var_{i + 1}" for i in range(n_features)]

    select_k = 10
    feature_indices = np.random.choice(n_features, select_k, replace=False).tolist()
    print(f"选中特征索引: {feature_indices}")

    bagging = DynamicBaggingEnsembleCV(
        base_model_classes=[RandomForestModel, XGBoostModel, MaxEntModel, SVMModel],
        n_estimators=5,
        n_folds=5
    )

    auc, oof_prob = bagging.fit_and_eval_cv(
        X, y,
        feature_indices=feature_indices,
        feature_names=feature_names,
        verbose=True
    )
    print(f"\n[调试结果] Bagging OOF AUC: {auc:.4f}（修复后，随机数据预期 ~0.50）")

    imp_df = bagging.get_base_model_importances([feature_names[j] for j in feature_indices])
    print("\nTop 5 特征重要性:")
    print(imp_df.head(5).to_string(index=False))
    print("==== 动态Bagging集成类调试完成 ====")