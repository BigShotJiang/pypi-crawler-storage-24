"""
Dynamic Boosting ensemble with config参数支持。
【接口完全对齐 Stacking 版】

修复说明：
1. fit_and_eval_cv 原版直接用训练集算 AUC（最严重的泄露）
   → 修复：加入真正的 K 折 OOF 评估
2. AdaBoost 权重更新逻辑失效：sample_weights 算完后从未传给 model.fit()
   → 修复：通过 bootstrap 采样将权重注入训练（兼容不支持 sample_weight 的基模型）
3. 返回 OOF 概率，与 Stacking / Bagging 接口对齐
"""

import numpy as np
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import roc_auc_score
import pandas as pd
from . import config


class DynamicBoostingEnsembleCV:
    def __init__(
        self,
        base_model_classes,
        meta_model_name=None,
        random_state=None,
        meta_model_params=None,
        n_folds=None,
        learning_rate=None,
        loss=None
    ):
        self.base_model_classes = base_model_classes
        self.meta_model_name = meta_model_name
        self.random_state = random_state if random_state is not None else config.RANDOM_SEED
        self.meta_model_params = meta_model_params or {}
        self.n_folds = n_folds if n_folds is not None else config.N_FOLDS

        self.learning_rate = learning_rate if learning_rate is not None else getattr(config, "BOOSTING_LR", 0.1)
        self.n_estimators = self.n_folds

        self.boosting_models = []
        self.model_weights = []
        self.feature_importances_ = None

    def fit(self, X, y, feature_indices, feature_names=None, n_folds=None, verbose=False):
        """
        Fit 方法签名与 Stacking 完全一致。

        【修复】sample_weights 通过加权 bootstrap 采样注入训练，
        不再依赖基模型是否支持 sample_weight 参数。
        """
        X_sub = X[:, feature_indices]
        n_samples = X_sub.shape[0]
        feature_names_sub = [feature_names[j] for j in feature_indices] if feature_names else None

        sample_weights = np.ones(n_samples) / n_samples
        self.boosting_models = []
        self.model_weights = []

        if verbose:
            print(f"开始训练 Boosting 集成模型（{self.n_estimators} 轮）...")

        rng = np.random.RandomState(self.random_state)

        for i in range(self.n_estimators):
            if verbose:
                print(f"  训练 Boosting 轮次 {i + 1}/{self.n_estimators}")

            model_cls = self.base_model_classes[i % len(self.base_model_classes)]
            current_seed = self.random_state + i

            try:
                # ★ 修复：用加权 bootstrap 采样将样本权重注入训练
                # 权重越大的样本被采样概率越高，等价于 AdaBoost 的重加权效果
                sample_idx = rng.choice(n_samples, size=n_samples, replace=True, p=sample_weights)
                X_boot = X_sub[sample_idx]
                y_boot = y[sample_idx]

                model = model_cls(cv=1, random_state=current_seed)
                model.fit(X_boot, y_boot, feature_names=feature_names_sub)

                # 在全量数据上预测，用于计算模型权重和更新样本权重
                y_pred_prob = model.predict_proba(X_sub).reshape(-1)
                y_pred = (y_pred_prob > 0.5).astype(int)

                # AdaBoost 模型权重
                error = np.mean(sample_weights * (y_pred != y))
                error = np.clip(error, 1e-10, 1 - 1e-10)
                model_weight = self.learning_rate * np.log((1 - error) / error)

                # 更新样本权重（错分样本权重增大）
                sample_weights *= np.exp(model_weight * (y_pred != y))
                sample_weights /= np.sum(sample_weights)  # 归一化

                self.boosting_models.append(model)
                self.model_weights.append(model_weight)

                if verbose:
                    print(f"    完成. 加权 error: {error:.4f}, model_weight: {model_weight:.4f}")

            except Exception as e:
                print(f"    轮次 {i + 1} 训练失败: {e}")
                import traceback
                traceback.print_exc()
                continue

        self._calculate_feature_importances(feature_names_sub)

        if verbose:
            print(f"Boosting 训练完成！共 {len(self.boosting_models)} 个基模型")

    def _calculate_feature_importances(self, feature_names):
        all_imps = []
        for model in self.boosting_models:
            native_model = getattr(model, "model", model)
            if hasattr(native_model, "feature_importances_"):
                all_imps.append(native_model.feature_importances_)
        if all_imps:
            self.feature_importances_ = np.mean(all_imps, axis=0)
        else:
            self.feature_importances_ = np.zeros(len(feature_names) if feature_names else 0)

    def predict_proba(self, X, feature_indices, feature_names=None, verbose=False):
        if not self.boosting_models:
            raise RuntimeError("Boosting 模型未训练，无法预测")

        X_sub = X[:, feature_indices]
        final_pred = np.zeros(X_sub.shape[0])
        total_weight = sum(self.model_weights) if sum(self.model_weights) > 0 else 1.0

        for model, weight in zip(self.boosting_models, self.model_weights):
            pred = model.predict_proba(X_sub).reshape(-1)
            final_pred += weight * pred

        final_pred /= total_weight
        return np.clip(final_pred, 0, 1)

    def fit_and_eval_cv(self, X, y, feature_indices, feature_names=None, n_folds=None, verbose=False):
        """
        【修复版】训练 + K 折 OOF 评估，消除数据泄露。

        原版：fit(全量) → predict(全量) → AUC（训练集 AUC，严重泄露）
        修复：K 折内独立 fit → OOF predict → OOF AUC
             → 最后全量 fit 更新 self.boosting_models 供推理

        返回：
          oof_auc  : float，基于 OOF 的真实泛化 AUC
          oof_prob : ndarray shape (n_samples,)，OOF 预测概率
        """
        n_folds = n_folds if n_folds is not None else self.n_folds
        X_sub_full = X[:, feature_indices]
        feature_names_sub = [feature_names[j] for j in feature_indices] if feature_names else None

        skf = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=self.random_state)
        oof_prob = np.zeros(X_sub_full.shape[0])
        auc_scores = []

        for fold, (train_idx, val_idx) in enumerate(skf.split(X_sub_full, y)):
            X_tr, y_tr = X[train_idx], y[train_idx]
            X_val, y_val = X[val_idx], y[val_idx]

            # ★ 关键修复：每折独立训练一个 Boosting 实例
            fold_booster = DynamicBoostingEnsembleCV(
                base_model_classes=self.base_model_classes,
                random_state=self.random_state + fold * 100,
                n_folds=self.n_folds,
                learning_rate=self.learning_rate
            )
            fold_booster.fit(X_tr, y_tr, feature_indices, feature_names, verbose=False)

            val_prob = fold_booster.predict_proba(X_val, feature_indices)
            oof_prob[val_idx] = val_prob

            auc = roc_auc_score(y_val, val_prob)
            auc_scores.append(auc)

            if verbose:
                print(f"Boosting K 折评估：第 {fold + 1} 折 AUC = {auc:.4f}")

        oof_auc = np.mean(auc_scores)
        if verbose:
            print(f"Boosting OOF 平均 AUC: {oof_auc:.4f} (±{np.std(auc_scores):.4f})")

        # 全量重新训练，更新 self.boosting_models 供后续推理
        self.fit(X, y, feature_indices, feature_names, verbose=False)
        if verbose:
            print("Boosting 全量模型已更新（用于后续推理）")

        return oof_auc, oof_prob

    def get_base_model_importances(self, feature_names):
        if self.feature_importances_ is None or len(self.feature_importances_) != len(feature_names):
            self._calculate_feature_importances(feature_names)

        return pd.DataFrame({
            "feature": feature_names,
            "importance": self.feature_importances_
        }).sort_values("importance", ascending=False).reset_index(drop=True)