# 04_dataset_splitting.py
# 数据集划分脚本（支持命令行参数输入）

import os
import pandas as pd
import geopandas as gpd
import numpy as np
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import warnings
import argparse
from geoxerl.data_preprocessing.utils import ensure_dir

# 禁用警告
warnings.filterwarnings('ignore')


def parse_args():
    parser = argparse.ArgumentParser(description="数据集划分（命令行参数版）")
    parser.add_argument('--output_dir', type=str, required=True, help="输出主目录")
    parser.add_argument('--points_dir', type=str, default=None, help="点数据目录（可选，默认=output_dir/points）")
    parser.add_argument('--boundary_file', type=str, required=True, help="研究区边界shp文件路径")
    return parser.parse_args()


def main():
    """数据集划分主函数"""
    print("数据集划分")
    print("=" * 50)
    
    # 解析命令行参数
    args = parse_args()
    output_dir = args.output_dir
    points_dir = args.points_dir if args.points_dir else os.path.join(output_dir, "points")
    dataset_dir = os.path.join(output_dir, "dataset")
    figures_dir = os.path.join(output_dir, "figures")
    boundary_file = args.boundary_file
    
    # 创建输出目录
    ensure_dir(dataset_dir)
    ensure_dir(figures_dir)
    
    # 1. 读取存在点和背景点数据
    print("\n1. 读取存在点和背景点数据")
    try:
        # 读取存在点数据
        presence_file = os.path.join(points_dir, "presence_points_with_env.csv")
        presence_data = pd.read_csv(presence_file)
        print(f"成功读取存在点数据，包含 {len(presence_data)} 个点")
        presence_data['presence'] = 1
        # 读取背景点数据
        background_file = os.path.join(points_dir, "background_points_with_env.csv")
        background_data = pd.read_csv(background_file)
        print(f"成功读取背景点数据，包含 {len(background_data)} 个点")
        if 'presence' not in background_data.columns:
            background_data['presence'] = 0
    except Exception as e:
        print(f"读取数据失败: {e}")
        return
    
    # 2. 合并存在点和背景点数据
    print("\n2. 合并存在点和背景点数据")
    common_cols = [col for col in presence_data.columns if col in background_data.columns]
    env_columns = [col for col in common_cols if col not in ['geometry', 'presence', 'longitude', 'latitude']]
    print(f"共有 {len(env_columns)} 个环境变量特征")
    presence_data = presence_data[common_cols]
    background_data = background_data[common_cols]
    combined_data = pd.concat([presence_data, background_data], ignore_index=True)
    print(f"合并后的数据包含 {len(combined_data)} 个点")
    print(f"其中存在点 {combined_data['presence'].sum()} 个，背景点 {(combined_data['presence'] == 0).sum()} 个")
    
    # 3. 检查数据
    print("\n3. 检查数据")
    na_counts = combined_data.isna().sum()
    if na_counts.any():
        print("\n存在缺失值:")
        print(na_counts[na_counts > 0])
        for col in env_columns:
            if combined_data[col].isna().any():
                combined_data[col] = combined_data[col].fillna(combined_data[col].mean())
        print("已填充所有缺失值")
    else:
        print("数据完整，无缺失值")
    
    # 4. 划分训练集和测试集
    print("\n4. 划分训练集和测试集")
    random_seed = 42
    presence_indices = combined_data[combined_data['presence'] == 1].index
    background_indices = combined_data[combined_data['presence'] == 0].index
    train_presence, test_presence = train_test_split(presence_indices, test_size=0.2, random_state=random_seed)
    train_background, test_background = train_test_split(background_indices, test_size=0.2, random_state=random_seed)
    train_indices = np.concatenate([train_presence, train_background])
    test_indices = np.concatenate([test_presence, test_background])
    train_data = combined_data.loc[train_indices].copy()
    test_data = combined_data.loc[test_indices].copy()
    print(f"训练集大小: {len(train_data)} 个点 ({len(train_presence)} 存在点, {len(train_background)} 背景点)")
    print(f"测试集大小: {len(test_data)} 个点 ({len(test_presence)} 存在点, {len(test_background)} 背景点)")
    
    # 5. 保存训练集和测试集
    print("\n5. 保存训练集和测试集")
    train_file = os.path.join(dataset_dir, "train_data.csv")
    train_data.to_csv(train_file, index=False)
    print(f"训练集已保存至: {train_file}")
    test_file = os.path.join(dataset_dir, "test_data.csv")
    test_data.to_csv(test_file, index=False)
    print(f"测试集已保存至: {test_file}")
    full_file = os.path.join(dataset_dir, "full_data.csv")
    combined_data.to_csv(full_file, index=False)
    print(f"完整数据集已保存至: {full_file}")
    
    # 6. 可视化数据分布
    print("\n6. 可视化数据分布")
    try:
        from shapely.geometry import Point
        def create_gdf(df):
            geometry = [Point(xy) for xy in zip(df['longitude'], df['latitude'])]
            return gpd.GeoDataFrame(df, geometry=geometry, crs='EPSG:4326')
        train_gdf = create_gdf(train_data)
        test_gdf = create_gdf(test_data)
        boundary_gdf = gpd.read_file(boundary_file)
        boundary_gdf = boundary_gdf.to_crs('EPSG:4326')
        fig, ax = plt.subplots(figsize=(12, 10))
        boundary_gdf.plot(ax=ax, color='lightgray', edgecolor='gray', alpha=0.5)
        train_presence_gdf = train_gdf[train_gdf['presence'] == 1]
        train_background_gdf = train_gdf[train_gdf['presence'] == 0]
        train_presence_gdf.plot(ax=ax, color='red', markersize=30, alpha=0.7, label='训练集-存在点')
        train_background_gdf.plot(ax=ax, color='blue', markersize=10, alpha=0.3, label='训练集-背景点')
        test_presence_gdf = test_gdf[test_gdf['presence'] == 1]
        test_background_gdf = test_gdf[test_gdf['presence'] == 0]
        test_presence_gdf.plot(ax=ax, color='darkred', markersize=30, alpha=0.7, label='测试集-存在点')
        test_background_gdf.plot(ax=ax, color='darkblue', markersize=10, alpha=0.3, label='测试集-背景点')
        ax.set_title('训练集和测试集的空间分布', fontsize=14)
        ax.legend()
        plt.savefig(os.path.join(figures_dir, "06_train_test_distribution.png"), dpi=300, bbox_inches='tight')
        plt.close()
    except Exception as e:
        print(f"可视化数据分布失败: {e}")
    
    # 7. 生成数据集描述文件
    print("\n7. 生成数据集描述文件")
    metadata = {
        "total_points": len(combined_data),
        "presence_points": combined_data['presence'].sum(),
        "background_points": (combined_data['presence'] == 0).sum(),
        "train_size": len(train_data),
        "train_presence": train_data['presence'].sum(),
        "train_background": (train_data['presence'] == 0).sum(),
        "test_size": len(test_data),
        "test_presence": test_data['presence'].sum(),
        "test_background": (test_data['presence'] == 0).sum(),
        "feature_count": len(env_columns),
        "train_test_ratio": "80:20",
        "random_seed": random_seed,
    }
    meta_df = pd.DataFrame([metadata])
    meta_file = os.path.join(dataset_dir, "dataset_metadata.csv")
    meta_df.to_csv(meta_file, index=False)
    print(f"数据集元数据已保存至: {meta_file}")
    feature_stats = combined_data[env_columns].describe().T
    feature_stats['missing'] = combined_data[env_columns].isna().sum()
    feature_stats['missing_pct'] = combined_data[env_columns].isna().mean() * 100
    feature_file = os.path.join(dataset_dir, "feature_statistics.csv")
    feature_stats.to_csv(feature_file)
    print(f"特征统计信息已保存至: {feature_file}")
    print("\n数据集划分完成!")
    print("=" * 50)


if __name__ == "__main__":
    main()

# & D:\Anaconda\envs\env\python.exe D:\ginkgo\code\data_preprocessing\04_dataset_splitting.py --output_dir "D:/ginkgo/data/processed/黄花刺茄数据_30" --boundary_file "D:/ginkgo/data/external/GS2023/省面.shp"