# 03_background_points_generation.py
# 背景点生成脚本（支持命令行参数输入）

import os
import pandas as pd
import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
import warnings
import argparse
from geoxerl.data_preprocessing.utils import (
    ensure_dir, list_raster_files, get_env_variable_name,
    create_buffer_around_points, sample_points_outside_buffer,
    extract_values_from_rasters, plot_point_distribution
)

# 禁用警告
warnings.filterwarnings('ignore')


def parse_args():
    parser = argparse.ArgumentParser(description="背景点生成脚本（命令行参数版）")
    parser.add_argument('--presence_file', type=str, required=True, help="存在点GPKG文件路径")
    parser.add_argument('--boundary_file', type=str, required=True, help="研究区边界shp文件路径")
    parser.add_argument('--env_dir', type=str, required=True, help="环境变量tif文件夹路径")
    parser.add_argument('--output_dir', type=str, required=True, help="输出主目录")
    parser.add_argument('--figures_dir', type=str, default=None, help="图表输出目录（可选）")
    parser.add_argument('--cache_dir', type=str, default=None, help="缓存目录（可选）")
    parser.add_argument('--buffer_distance_km', type=float, default=10, help="缓冲区距离（km）")
    parser.add_argument('--background_multiplier', type=int, default=10, help="背景点数量=存在点数*倍数")
    # 预留背景点生成方式参数
    parser.add_argument('--method', type=str, default='random', choices=['random'], help="背景点生成方式")
    return parser.parse_args()

def main():
    """背景点生成主函数"""
    print("背景点生成")
    print("=" * 50)

    args = parse_args()
    presence_file = args.presence_file
    boundary_file = args.boundary_file
    env_dir = args.env_dir
    output_dir = args.output_dir
    points_dir = os.path.join(output_dir, "points")
    figures_dir = args.figures_dir if args.figures_dir else os.path.join(output_dir, "figures")
    cache_dir = args.cache_dir if args.cache_dir else os.path.join(output_dir, "cache", "env_values")
    buffer_distance_km = args.buffer_distance_km
    background_multiplier = args.background_multiplier
    method = args.method

    # 创建输出目录
    ensure_dir(points_dir)
    ensure_dir(figures_dir)
    ensure_dir(cache_dir)

    # 1. 读取存在点和研究区域边界数据
    print("\n1. 读取存在点和研究区域边界")
    try:
        presence_gdf = gpd.read_file(presence_file)
        print(f"成功读取存在点数据，包含 {len(presence_gdf)} 个点")
    except Exception as e:
        print(f"读取存在点数据失败: {e}")
        return

    try:
        boundary_gdf = gpd.read_file(boundary_file)
        boundary_gdf = boundary_gdf.to_crs('EPSG:4326')
        print(f"成功读取研究区域边界")
    except Exception as e:
        print(f"读取研究区域边界失败: {e}")
        return

    # 2. 在存在点周围创建缓冲区
    print("\n2. 在存在点周围创建缓冲区")
    buffer_gdf = create_buffer_around_points(presence_gdf, buffer_distance_km)
    print(f"已创建 {buffer_distance_km} 公里的缓冲区")

    # 可视化缓冲区
    fig, ax = plt.subplots(figsize=(12, 10))
    boundary_gdf.plot(ax=ax, color='lightgray', edgecolor='gray', alpha=0.5)
    buffer_gdf.plot(ax=ax, color='blue', alpha=0.3, edgecolor='blue', label='缓冲区')
    presence_gdf.plot(ax=ax, color='red', markersize=10, alpha=0.7, label='存在点')
    ax.set_title(f"存在点及其 {buffer_distance_km} 公里缓冲区", fontsize=14)
    ax.legend()
    plt.savefig(os.path.join(figures_dir, "04_presence_points_buffer.png"), dpi=300, bbox_inches='tight')
    plt.close()

    # 3. 生成随机背景点
    print("\n3. 生成随机背景点")
    n_presence = len(presence_gdf)
    n_background = n_presence * background_multiplier
    print(f"目标背景点数量: {n_background} (存在点的{background_multiplier}倍)")

    if method == 'random':
        background_gdf = sample_points_outside_buffer(boundary_gdf, buffer_gdf, n_background)
        print(f"成功生成 {len(background_gdf)} 个背景点")
    else:
        print(f"暂不支持的方法: {method}")
        return

    background_gdf['longitude'] = background_gdf.geometry.x
    background_gdf['latitude'] = background_gdf.geometry.y
    background_gdf['presence'] = 0  # 0表示背景点

    # 4. 可视化背景点分布
    print("\n4. 可视化背景点分布")
    plot_fig = plot_point_distribution(
        presence_gdf,
        background_gdf=background_gdf,
        boundary_gdf=boundary_gdf,
        output_path=os.path.join(figures_dir, "05_background_points_distribution.png")
    )
    plt.close()

    # 5. 收集环境变量栅格
    print("\n5. 收集环境变量栅格")
    raster_files = list_raster_files(env_dir, "*.tif")
    if not raster_files:
        print("未找到环境变量栅格文件，请检查路径")
        return

    # 6. 从环境变量提取背景点的值
    print("\n6. 从环境变量提取背景点的值")
    background_env_data = extract_values_from_rasters(
        background_gdf,
        raster_files,
        env_cache_dir=cache_dir
    )
    env_columns = [get_env_variable_name(file) for file in raster_files]

    # 7. 检查提取结果
    print("\n7. 检查提取结果")
    na_counts = background_env_data[env_columns].isna().sum()
    na_summary = na_counts[na_counts > 0]
    if not na_summary.empty:
        print("\n环境变量缺失值统计:")
        print(na_summary.sort_values(ascending=False))
        background_env_data['missing_pct'] = background_env_data[env_columns].isna().mean(axis=1) * 100
        threshold = 20
        valid_points = background_env_data[background_env_data['missing_pct'] <= threshold]
        if len(valid_points) < len(background_env_data):
            print(f"\n移除 {len(background_env_data) - len(valid_points)} 个缺失值过多的点 (>{threshold}%)")
            background_env_data = valid_points
    else:
        print("所有环境变量都已成功提取，没有缺失值")

    # 8. 处理剩余缺失值
    print("\n8. 处理剩余缺失值")
    for col in env_columns:
        missing = background_env_data[col].isna().sum()
        if missing > 0:
            background_env_data[col] = background_env_data[col].fillna(background_env_data[col].mean())
            print(f"  填充 {col} 的 {missing} 个缺失值")

    # 9. 保存背景点数据
    print("\n9. 保存背景点数据")
    output_csv = os.path.join(points_dir, "background_points_with_env.csv")
    background_env_data.drop(columns=['missing_pct'] if 'missing_pct' in background_env_data.columns else []).to_csv(output_csv, index=False)
    print(f"背景点数据已保存至: {output_csv}")

    output_gpkg = os.path.join(points_dir, "background_points_with_env.gpkg")
    background_env_data.drop(columns=['missing_pct'] if 'missing_pct' in background_env_data.columns else []).to_file(output_gpkg, driver="GPKG")
    print(f"背景点数据也保存为GeoPackage: {output_gpkg}")

    # 保存点数统计信息
    stats = {
        "generated_points": n_background,
        "valid_points": len(background_env_data),
        "removed_points": n_background - len(background_env_data),
        "buffer_distance_km": buffer_distance_km,
        "env_variables": len(env_columns),
        "processing_date": "2025-07"
    }

    stats_df = pd.DataFrame([stats])
    stats_df.to_csv(os.path.join(points_dir, "background_points_stats.csv"), index=False)

    # 10. 环境分层抽样功能接口（留空）
    print("\n10. 环境分层抽样框架 (未启用)")
    print("已预留环境分层抽样功能接口")
    def generate_stratified_background_points(boundary_gdf, presence_gdf, env_rasters, n_points, n_strata=10):
        print("环境分层抽样功能尚未实现")
        return None

    # 11. 目标群体抽样功能接口（留空）
    print("\n11. 目标群体抽样框架 (未启用)")
    print("已预留目标群体抽样功能接口")
    def generate_target_group_background_points(boundary_gdf, presence_gdf, env_rasters, n_points):
        print("目标群体抽样功能尚未实现")
        return None

    print("\n背景点生成完成!")
    print(f"有效背景点数: {len(background_env_data)} / {n_background}")
    print("=" * 50)


if __name__ == "__main__":
    main()

# & D:\Anaconda\envs\env\python.exe D:\ginkgo\code\data_preprocessing\03_background_points_generation.py --presence_file "D:/ginkgo/data/processed/黄花刺茄数据_30/points/presence_points_with_env.gpkg" --boundary_file "D:/ginkgo/data/external/GS2023/省面.shp" --env_dir "D:\ginkgo\data\processed\黄花刺茄数据_30\env_variables\selected" --output_dir "D:/ginkgo/data/processed/黄花刺茄数据_30" --buffer_distance_km 10 --background_multiplier 10

    