# 01_env_variables_preprocessing.py
# 环境变量预处理脚本（支持命令行传入输入输出路径）

import os
import numpy as np
import pandas as pd
import traceback
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm.auto import tqdm
import warnings
import argparse
from geoxerl.data_preprocessing.utils import (
    ensure_dir, list_raster_files, get_env_variable_name, check_raster_alignment,
    standardize_raster, reproject_raster, calculate_raster_correlation,
    identify_correlated_pairs, select_uncorrelated_variables, plot_correlation_matrix
)

# 禁用警告
warnings.filterwarnings('ignore')

def parse_args():
    parser = argparse.ArgumentParser(description="环境变量预处理（命令行输入路径）")
    parser.add_argument('--env_dir', type=str, required=True, help="原始环境变量文件夹路径")
    parser.add_argument('--output_dir', type=str, required=True, help="处理结果输出主目录")
    parser.add_argument('--figures_dir', type=str, default=None, help="图表输出目录（可选）")
    parser.add_argument('--cache_dir', type=str, default=None, help="缓存目录（可选）")
    return parser.parse_args()

def main():
    print("环境变量预处理")
    print("=" * 50)

    args = parse_args()
    env_dir = args.env_dir
    output_dir = args.output_dir
    env_output_dir = os.path.join(output_dir, "env_variables")
    figures_dir = args.figures_dir if args.figures_dir else os.path.join(output_dir, "figures")
    cache_dir = args.cache_dir if args.cache_dir else os.path.join(output_dir, "cache")

    ensure_dir(env_output_dir)
    ensure_dir(os.path.join(env_output_dir, "original"))
    ensure_dir(os.path.join(env_output_dir, "standardized"))
    ensure_dir(os.path.join(env_output_dir, "selected"))
    ensure_dir(figures_dir)
    ensure_dir(cache_dir)

    print("\n1. 收集并检查环境变量栅格")
    raster_files = list_raster_files(env_dir, "*.tif")
    if not raster_files:
        print("未找到环境变量栅格文件，请检查路径")
        return

    rasters_aligned = check_raster_alignment(raster_files)
    if not rasters_aligned:
        print("警告: 栅格文件不完全对齐，可能会影响后续分析")

    print("\n2. 确保所有栅格使用WGS84坐标系")
    reprojected_files = []
    for raster_file in tqdm(raster_files, desc="重投影栅格"):
        var_name = get_env_variable_name(raster_file)
        output_file = os.path.join(env_output_dir, "original", f"{var_name}.tif")
        if reproject_raster(raster_file, output_file, dst_crs='EPSG:4326'):
            reprojected_files.append(output_file)
    print(f"完成重投影，共处理 {len(reprojected_files)} 个栅格文件")

    print("\n3. 对环境变量进行Z-score标准化")
    standardized_files = []
    for raster_file in tqdm(reprojected_files, desc="标准化栅格"):
        var_name = get_env_variable_name(raster_file)
        output_file = os.path.join(env_output_dir, "standardized", f"{var_name}.tif")
        if standardize_raster(raster_file, output_file):
            standardized_files.append(output_file)
    print(f"完成标准化，共处理 {len(standardized_files)} 个栅格文件")

    print("\n4. 进行环境变量相关性分析")
    correlation_matrix, var_names = calculate_raster_correlation(
        standardized_files,
        sample_size=10000000,
        cache_dir=cache_dir
    )
    plot_correlation_matrix(
        correlation_matrix,
        var_names,
        output_path=os.path.join(figures_dir, "01_env_correlation_matrix.png")
    )
    plt.close()

    threshold = 0.8
    high_corr_pairs = identify_correlated_pairs(correlation_matrix, var_names, threshold)
    if high_corr_pairs:
        print(f"\n发现 {len(high_corr_pairs)} 对高相关性变量(|r| > {threshold}):")
        for var1, var2, corr in high_corr_pairs[:10]:
            print(f"  {var1} & {var2}: {corr:.4f}")
        if len(high_corr_pairs) > 10:
            print(f"  ... 以及 {len(high_corr_pairs) - 10} 个其他对")
    else:
        print(f"未发现相关性大于 {threshold} 的变量对")

    print("\n5. 选择不相关的变量子集")
    selected_vars, removed_vars = select_uncorrelated_variables(correlation_matrix, var_names, threshold)
    if removed_vars:
        print(f"移除了以下 {len(removed_vars)} 个变量:")
        for var in removed_vars[:20]:
            print(f"  {var}")
        if len(removed_vars) > 20:
            print(f"  ... 以及 {len(removed_vars) - 20} 个其他变量")

    print("\n6. 创建最终环境变量集")
    selected_files = []
    for var in tqdm(selected_vars, desc="复制选定变量"):
        source_file = os.path.join(env_output_dir, "standardized", f"{var}.tif")
        target_file = os.path.join(env_output_dir, "selected", f"{var}.tif")
        if os.path.exists(source_file):
            import shutil
            shutil.copy2(source_file, target_file)
            selected_files.append(target_file)
    print(f"完成最终环境变量集创建，共包含 {len(selected_files)} 个变量")

    print("\n7. 保存变量信息")
    var_info = pd.DataFrame({
        'variable': var_names,
        'selected': [var in selected_vars for var in var_names]
    })
    var_mean_corr = {}
    for i, var in enumerate(var_names):
        corrs = [abs(correlation_matrix[i, j]) for j in range(len(var_names)) if i != j]
        var_mean_corr[var] = np.mean(corrs)
    var_info['mean_correlation'] = var_info['variable'].map(var_mean_corr)
    var_info = var_info.sort_values(['selected', 'mean_correlation'], ascending=[False, True])
    var_info_path = os.path.join(env_output_dir, "variable_info.csv")
    var_info.to_csv(var_info_path, index=False)
    print(f"变量信息已保存至: {var_info_path}")

    try:
        corr_matrix_path = os.path.join(env_output_dir, "correlation_matrix.csv")
        corr_df = pd.DataFrame(
            correlation_matrix,
            columns=var_names,
            index=var_names
        )
        print(f"相关性矩阵维度: {correlation_matrix.shape}")
        print(f"变量名数量: {len(var_names)}")
        if np.isnan(correlation_matrix).any():
            print("警告: 相关性矩阵包含NaN值，将替换为0")
            corr_df = corr_df.fillna(0)
        corr_df.to_csv(corr_matrix_path, float_format="%.4f")
        print(f"相关性矩阵已保存至: {corr_matrix_path}")
        corr_df.to_excel(os.path.join(env_output_dir, "correlation_matrix.xlsx"))
    except Exception as e:
        print(f"保存相关性矩阵失败: {e}")
        print("详细错误信息:", traceback.format_exc())

    print("\n环境变量预处理完成!")
    print("=" * 50)
    print("\n结果摘要:")
    print(f"原始环境变量数量: {len(raster_files)}")
    print(f"重投影后环境变量数量: {len(reprojected_files)}")
    print(f"标准化后环境变量数量: {len(standardized_files)}")
    print(f"最终选择的环境变量数量: {len(selected_vars)}")

if __name__ == "__main__":
    main()

# & D:\Anaconda\envs\env\python.exe D:\ginkgo\code\data_preprocessing\01_env_variables_preprocessing.py --env_dir "D:/ginkgo/data/raw/黄花刺茄环境变量/data" --output_dir "D:/ginkgo/data/processed/黄花刺茄数据_new"