import os
os.environ['PROJ_DATA'] = r'D:\Program\DevTools\anaconda3\envs\EL2\Library\share\proj'
os.environ['PROJ_LIB'] = r'D:\Program\DevTools\anaconda3\envs\EL2\Library\share\proj'

# 之后再导入其他库
import sys
import geopandas as gpd
# ... 其余原有 import
# 02_presence_points_processing.py
import os
import pandas as pd
import geopandas as gpd
import numpy as np
import matplotlib.pyplot as plt
from tqdm.auto import tqdm
import argparse
from geoxerl.data_preprocessing.utils import (
    ensure_dir, list_raster_files, get_env_variable_name,
    extract_values_from_rasters, plot_point_distribution,
    plot_env_variable_histograms
)

def parse_args():
    parser = argparse.ArgumentParser(description="存在点处理脚本（命令行参数版）")
    parser.add_argument('--presence_file', type=str, required=True, help="存在点shp文件路径")
    parser.add_argument('--boundary_file', type=str, required=True, help="研究区边界shp文件路径")
    parser.add_argument('--env_dir', type=str, required=True, help="环境变量tif文件夹路径")
    parser.add_argument('--output_dir', type=str, required=True, help="输出主目录")
    parser.add_argument('--figures_dir', type=str, default=None, help="图表输出目录（可选）")
    parser.add_argument('--cache_dir', type=str, default=None, help="缓存目录（可选）")
    return parser.parse_args()

def main():
    """存在点处理的主函数"""
    print("存在点数据处理")
    print("=" * 50)
    
    # 解析命令行参数
    args = parse_args()
    presence_file = args.presence_file
    boundary_file = args.boundary_file
    env_dir = args.env_dir
    output_dir = args.output_dir
    points_dir = os.path.join(output_dir, "points")
    figures_dir = args.figures_dir if args.figures_dir else os.path.join(output_dir, "figures")
    cache_dir = args.cache_dir if args.cache_dir else os.path.join(output_dir, "cache", "env_values")
    
    # 创建输出目录
    ensure_dir(points_dir)
    ensure_dir(figures_dir)
    ensure_dir(cache_dir)
    
    # 1. 读取存在点数据
    print("\n1. 读取存在点数据")
    try:
        presence_gdf = gpd.read_file(presence_file)
        print(f"成功读取存在点数据，包含 {len(presence_gdf)} 个点")
        print(f"坐标系: {presence_gdf.crs}")
        if presence_gdf.crs != 'EPSG:4326':
            print(f"将存在点从{presence_gdf.crs}转换为EPSG:4326")
            presence_gdf = presence_gdf.to_crs('EPSG:4326')
        print("\n数据预览:")
        print(presence_gdf.head())
        required_columns = ['longitude', 'latitude']
        has_lonlat = all(col in presence_gdf.columns for col in required_columns)
        if not has_lonlat:
            print("\n未找到经纬度列，将从geometry提取")
            presence_gdf['longitude'] = presence_gdf.geometry.x
            presence_gdf['latitude'] = presence_gdf.geometry.y
    except Exception as e:
        print(f"读取存在点数据失败: {e}")
        return
    
    # 2. 读取研究区域边界
    print("\n2. 读取研究区域边界")
    try:
        boundary_gdf = gpd.read_file(boundary_file)
        boundary_gdf = boundary_gdf.to_crs('EPSG:4326')
        print(f"成功读取研究区域边界")
    except Exception as e:
        print(f"读取研究区域边界失败: {e}")
        boundary_gdf = None
    
    # 3. 可视化存在点分布
    print("\n3. 可视化存在点分布")
    plot_fig = plot_point_distribution(
        presence_gdf, 
        boundary_gdf=boundary_gdf,
        output_path=os.path.join(figures_dir, "02_presence_points_distribution.png")
    )
    plt.close()
    
    # 4. 收集环境变量栅格
    print("\n4. 收集环境变量栅格")
    raster_files = list_raster_files(env_dir, "*.tif")
    if not raster_files:
        print("未找到环境变量栅格文件，请检查路径")
        return
    
    # 5. 从环境变量提取存在点的值
    print("\n5. 从环境变量提取存在点的值")
    presence_env_data = extract_values_from_rasters(
        presence_gdf, 
        raster_files, 
        env_cache_dir=cache_dir
    )
    env_columns = [get_env_variable_name(file) for file in raster_files]
    
    # 6. 检查提取结果
    print("\n6. 检查提取结果")
    na_counts = presence_env_data[env_columns].isna().sum()
    na_summary = na_counts[na_counts > 0]
    if not na_summary.empty:
        print("\n环境变量缺失值统计:")
        print(na_summary.sort_values(ascending=False))
        presence_env_data['missing_pct'] = presence_env_data[env_columns].isna().mean(axis=1) * 100
        threshold = 20
        valid_points = presence_env_data[presence_env_data['missing_pct'] <= threshold]
        if len(valid_points) < len(presence_env_data):
            print(f"\n移除 {len(presence_env_data) - len(valid_points)} 个缺失值过多的点 (>{threshold}%)")
            presence_env_data = valid_points
    else:
        print("所有环境变量都已成功提取，没有缺失值")
    
    # 7. 处理剩余缺失值
    print("\n7. 处理剩余缺失值")
    for col in env_columns:
        missing = presence_env_data[col].isna().sum()
        if missing > 0:
            presence_env_data[col] = presence_env_data[col].fillna(presence_env_data[col].mean())
            print(f"  填充 {col} 的 {missing} 个缺失值")
    
    # 8. 可视化环境特征分布
    print("\n8. 可视化环境特征分布")
    sample_vars = env_columns[:min(10, len(env_columns))]
    hist_fig = plot_env_variable_histograms(
        presence_env_data[sample_vars],
        output_path=os.path.join(figures_dir, "03_env_variables_histograms.png")
    )
    plt.close()
    
    # 9. 保存处理后的存在点数据
    print("\n9. 保存处理后的存在点数据")
    output_columns = ['longitude', 'latitude'] + env_columns
    result_df = presence_env_data[output_columns].copy()
    output_csv = os.path.join(points_dir, "presence_points_with_env.csv")
    result_df.to_csv(output_csv, index=False)
    print(f"存在点数据已保存至: {output_csv}")
    output_gpkg = os.path.join(points_dir, "presence_points_with_env.gpkg")
    geometry = gpd.points_from_xy(result_df['longitude'], result_df['latitude'])
    result_gdf = gpd.GeoDataFrame(result_df, geometry=geometry, crs='EPSG:4326')
    result_gdf.to_file(output_gpkg, driver="GPKG")
    print(f"存在点数据也已保存为: {output_gpkg}")

if __name__ == "__main__":
    main()

# & D:\Anaconda\envs\env\python.exe D:\ginkgo\code\data_preprocessing\02_presence_points_processing.py --presence_file "D:/ginkgo/data/raw/1黄花刺茄矢量点/黄花刺茄_1kmFishNet筛选后P.shp" --boundary_file "D:/ginkgo/data/external/GS2023/省面.shp" --env_dir "D:\ginkgo\data\processed\黄花刺茄数据_30\env_variables\selected" --output_dir "D:\ginkgo\data\processed\黄花刺茄数据_30"