"""
环境变量预处理脚本
默认对所有环境变量进行重投影和标准化，可选择进行变量筛选
"""

import os
import numpy as np
import pandas as pd
import traceback
import matplotlib.pyplot as plt
import seaborn as sns
from tqdm.auto import tqdm
import warnings
import argparse
from geoxerl.data_preprocessing.utils import (
    ensure_dir, list_raster_files, get_env_variable_name, check_raster_alignment,
    standardize_raster, reproject_raster, calculate_raster_correlation,
    identify_correlated_pairs, select_uncorrelated_variables, plot_correlation_matrix
)

# 禁用警告
warnings.filterwarnings('ignore')

def parse_args():
    """解析命令行参数"""
    parser = argparse.ArgumentParser(
        description="环境变量预处理脚本 - 默认处理所有变量，可选择筛选",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:

1. 仅处理所有环境变量（不筛选）：
python 01_env_variables_preprocessing.py --env_dir "path/to/env" --output_dir "path/to/output"

2. 处理并通过CSV文件筛选：
python 01_env_variables_preprocessing.py --env_dir "path/to/env" --output_dir "path/to/output" --select_variables --features_csv "features.csv"

3. 处理并通过相关性筛选：
python 01_env_variables_preprocessing.py --env_dir "path/to/env" --output_dir "path/to/output" --select_variables --correlation_threshold 0.8

4. 完整处理包含相关性分析：
python 01_env_variables_preprocessing.py --env_dir "path/to/env" --output_dir "path/to/output" --select_variables --enable_correlation_analysis --correlation_threshold 0.8

Windows示例:
& D:\Anaconda\envs\env\python.exe D:\ginkgo\code\data_preprocessing\\01_env_variables_preprocessing.py --env_dir "D:\ginkgo\data\raw\黄花刺茄环境变量\data" --output_dir "D:\ginkgo\data\processed\黄花刺茄数据_30" --select_variables --features_csv "D:\ginkgo\code\ensemble\\results\\top30_variable_freq_avg.csv"
        """
    )
    
    # 基本输入输出路径
    parser.add_argument(
        '--env_dir', 
        type=str, 
        required=True,
        help="原始环境变量文件夹路径"
    )
    
    parser.add_argument(
        '--output_dir', 
        type=str, 
        required=True,
        help="处理结果输出主目录"
    )
    
    parser.add_argument(
        '--figures_dir', 
        type=str, 
        default=None,
        help="图表输出目录（默认为output_dir/figures）"
    )
    
    parser.add_argument(
        '--cache_dir', 
        type=str, 
        default=None,
        help="缓存目录（默认为output_dir/cache）"
    )
    
    # 变量筛选选项
    parser.add_argument(
        '--select_variables', 
        action='store_true',
        help="是否进行变量筛选（默认不筛选）"
    )
    
    parser.add_argument(
        '--features_csv', 
        type=str, 
        help="包含选定特征的CSV文件路径（优先级高于相关性筛选）"
    )
    
    parser.add_argument(
        '--feature_column', 
        type=str, 
        default='feature',
        help="CSV文件中包含特征名称的列名，默认为'feature'"
    )
    
    # 相关性筛选选项
    parser.add_argument(
        '--correlation_threshold', 
        type=float, 
        default=0.8,
        help="相关性阈值，默认0.8（仅在进行相关性筛选时使用）"
    )
    
    parser.add_argument(
        '--enable_correlation_analysis', 
        action='store_true',
        help="启用相关性分析和可视化（默认关闭）"
    )
    
    # 处理选项
    parser.add_argument(
        '--sample_size', 
        type=int, 
        default=5000000,
        help="相关性分析的采样数量，默认500万"
    )
    
    parser.add_argument(
        '--skip_existing', 
        action='store_true',
        help="跳过已存在的处理结果"
    )
    
    return parser.parse_args()

def load_selected_features(csv_path, feature_column='feature'):
    """从CSV文件中加载选定的环境变量列表"""
    if not os.path.exists(csv_path):
        raise FileNotFoundError(f"选定的环境变量CSV文件不存在: {csv_path}")

    print(f"正在从 {csv_path} 加载特征列表...")
    df = pd.read_csv(csv_path)
    
    print(f"CSV文件包含列: {list(df.columns)}")

    # 检查指定的列是否存在
    if feature_column in df.columns:
        features = df[feature_column].tolist()
        print(f"使用列 '{feature_column}' 加载了 {len(features)} 个特征")
        return features
    
    # 如果指定列不存在，尝试其他可能的列名
    possible_cols = ['feature', 'variable', 'env_var', 'name', 'selected_features', 'features']
    for col in possible_cols:
        if col in df.columns:
            features = df[col].tolist()
            print(f"未找到列 '{feature_column}'，使用列 '{col}' 加载了 {len(features)} 个特征")
            return features

    # 如果没有合适的列，使用第一列
    features = df.iloc[:, 0].tolist()
    print(f"未找到合适的特征列，使用第一列加载了 {len(features)} 个特征")
    return features

def validate_args(args):
    """验证命令行参数"""
    if not os.path.exists(args.env_dir):
        raise FileNotFoundError(f"环境变量目录不存在: {args.env_dir}")
    
    if args.select_variables and args.features_csv:
        if not os.path.exists(args.features_csv):
            raise FileNotFoundError(f"CSV文件不存在: {args.features_csv}")

def process_all_variables(args):
    """处理所有环境变量：重投影和标准化"""
    print("\n" + "="*60)
    print("第一阶段：处理所有环境变量")
    print("="*60)
    
    # 设置目录
    env_dir = args.env_dir
    output_dir = args.output_dir
    env_output_dir = os.path.join(output_dir, "env_variables")
    
    # 设置默认路径
    if args.figures_dir is None:
        figures_dir = os.path.join(output_dir, "figures")
    else:
        figures_dir = args.figures_dir
    
    if args.cache_dir is None:
        cache_dir = os.path.join(output_dir, "cache")
    else:
        cache_dir = args.cache_dir

    # 创建输出目录
    ensure_dir(env_output_dir)
    ensure_dir(os.path.join(env_output_dir, "original"))
    ensure_dir(os.path.join(env_output_dir, "standardized"))
    ensure_dir(figures_dir)
    ensure_dir(cache_dir)

    print(f"环境变量目录: {env_dir}")
    print(f"输出目录: {output_dir}")
    print(f"图表目录: {figures_dir}")
    print(f"缓存目录: {cache_dir}")

    # 1. 收集并检查环境变量栅格
    print("\n1. 收集并检查环境变量栅格")
    raster_files = list_raster_files(env_dir, "*.tif")

    if not raster_files:
        print(" 未找到环境变量栅格文件，请检查路径")
        return None, None, None, None

    print(f" 找到 {len(raster_files)} 个栅格文件")

    # 检查栅格是否对齐
    rasters_aligned = check_raster_alignment(raster_files)
    if not rasters_aligned:
        print(" 警告: 栅格文件不完全对齐，可能会影响后续分析")

    # 2. 确保所有栅格都是WGS84坐标系
    print("\n2. 重投影到WGS84坐标系")
    reprojected_files = []
    
    for raster_file in tqdm(raster_files, desc="重投影栅格"):
        var_name = get_env_variable_name(raster_file)
        output_file = os.path.join(env_output_dir, "original", f"{var_name}.tif")
        
        # 检查是否跳过已存在的文件
        if args.skip_existing and os.path.exists(output_file):
            reprojected_files.append(output_file)
            continue

        if reproject_raster(raster_file, output_file, dst_crs='EPSG:4326'):
            reprojected_files.append(output_file)

    print(f" 完成重投影，共处理 {len(reprojected_files)} 个栅格文件")

    # 3. Z-score标准化
    print("\n3. Z-score标准化")
    standardized_files = []
    
    for raster_file in tqdm(reprojected_files, desc="标准化栅格"):
        var_name = get_env_variable_name(raster_file)
        output_file = os.path.join(env_output_dir, "standardized", f"{var_name}.tif")
        
        # 检查是否跳过已存在的文件
        if args.skip_existing and os.path.exists(output_file):
            standardized_files.append(output_file)
            continue

        if standardize_raster(raster_file, output_file):
            standardized_files.append(output_file)

    print(f" 完成标准化，共处理 {len(standardized_files)} 个栅格文件")

    # 获取所有变量名称
    var_names = [get_env_variable_name(f) for f in standardized_files]
    
    print(f"\n 处理完成统计:")
    print(f"- 原始栅格文件: {len(raster_files)}")
    print(f"- 重投影文件: {len(reprojected_files)}")
    print(f"- 标准化文件: {len(standardized_files)}")
    print(f"- 可用变量: {len(var_names)}")

    return standardized_files, var_names, figures_dir, cache_dir

def perform_correlation_analysis(standardized_files, var_names, args, figures_dir, cache_dir):
    """执行相关性分析"""
    print("\n" + "="*60)
    print("相关性分析")
    print("="*60)
    
    try:
        # 计算相关性矩阵
        print("计算相关性矩阵...")
        correlation_matrix, var_names_corr = calculate_raster_correlation(
            standardized_files,
            sample_size=args.sample_size,
            cache_dir=cache_dir
        )
        
        # 绘制相关性矩阵
        plot_correlation_matrix(
            correlation_matrix,
            var_names_corr,
            output_path=os.path.join(figures_dir, "correlation_matrix.png")
        )
        plt.close()
        
        print(f" 相关性矩阵计算完成，维度: {correlation_matrix.shape}")
        print(f" 相关性矩阵图已保存至: {os.path.join(figures_dir, 'correlation_matrix.png')}")
        
        return correlation_matrix, var_names_corr
        
    except Exception as e:
        print(f" 相关性分析失败: {e}")
        traceback.print_exc()
        return None, var_names

def select_variables_by_method(var_names, args, correlation_matrix=None):
    """根据指定方法选择变量"""
    print("\n" + "="*60)
    print("第二阶段：变量筛选")
    print("="*60)
    
    selected_vars = None
    selection_method = "未选择"
    
    # 优先使用CSV文件
    if args.features_csv and os.path.exists(args.features_csv):
        print(" 使用CSV文件进行变量筛选")
        try:
            csv_vars = load_selected_features(args.features_csv, args.feature_column)
            
            # 检查哪些变量在可用变量中存在
            available_vars = set(var_names)
            valid_vars = [var for var in csv_vars if var in available_vars]
            missing_vars = [var for var in csv_vars if var not in available_vars]
            
            if missing_vars:
                print(f" 以下 {len(missing_vars)} 个变量在处理后的文件中不存在:")
                for var in missing_vars[:10]:
                    print(f"   - {var}")
                if len(missing_vars) > 10:
                    print(f"   - ... 以及其他 {len(missing_vars) - 10} 个变量")
            
            selected_vars = valid_vars
            selection_method = f"CSV文件筛选 (来源: {args.features_csv})"
            
            print(f" CSV筛选完成: {len(selected_vars)}/{len(csv_vars)} 个变量可用")
            
        except Exception as e:
            print(f" CSV文件加载失败: {e}")
            selected_vars = None
    
    # 如果CSV失败或不存在，且有相关性矩阵，则使用相关性筛选
    if selected_vars is None and correlation_matrix is not None:
        print(" 使用相关性分析进行变量筛选")
        try:
            threshold = args.correlation_threshold
            
            # 识别高相关性变量对
            high_corr_pairs = identify_correlated_pairs(correlation_matrix, var_names, threshold)
            
            if high_corr_pairs:
                print(f"发现 {len(high_corr_pairs)} 对高相关性变量(|r| > {threshold}):")
                for var1, var2, corr in high_corr_pairs[:5]:
                    print(f"   - {var1} & {var2}: {corr:.4f}")
                if len(high_corr_pairs) > 5:
                    print(f"   - ... 以及其他 {len(high_corr_pairs) - 5} 个对")
            else:
                print(f"未发现相关性大于 {threshold} 的变量对")

            # 选择不相关的变量子集
            selected_vars, removed_vars = select_uncorrelated_variables(
                correlation_matrix, var_names, threshold
            )
            
            selection_method = f"相关性筛选 (阈值: {threshold})"
            
            if removed_vars:
                print(f"移除了 {len(removed_vars)} 个高相关性变量:")
                for var in removed_vars[:10]:
                    print(f"   - {var}")
                if len(removed_vars) > 10:
                    print(f"   - ... 以及其他 {len(removed_vars) - 10} 个变量")
            
            print(f" 相关性筛选完成: 保留 {len(selected_vars)} 个变量")
            
        except Exception as e:
            print(f" 相关性筛选失败: {e}")
            selected_vars = None
    
    # 如果都失败了，提示用户
    if selected_vars is None:
        if args.features_csv:
            print(" CSV文件筛选失败")
        if not args.enable_correlation_analysis:
            print(" 提示: 使用 --enable_correlation_analysis 启用相关性筛选")
        print(" 将使用所有可用变量")
        selected_vars = var_names
        selection_method = "使用所有变量（筛选失败）"
    
    return selected_vars, selection_method

def create_selected_folder(selected_vars, args):
    """创建selected文件夹并复制选定的变量"""
    print("\n4. 创建最终环境变量集")
    
    env_output_dir = os.path.join(args.output_dir, "env_variables")
    ensure_dir(os.path.join(env_output_dir, "selected"))
    
    selected_files = []
    for var in tqdm(selected_vars, desc="复制选定变量"):
        source_file = os.path.join(env_output_dir, "standardized", f"{var}.tif")
        target_file = os.path.join(env_output_dir, "selected", f"{var}.tif")

        if os.path.exists(source_file):
            import shutil
            shutil.copy2(source_file, target_file)
            selected_files.append(target_file)
        else:
            print(f" 警告: 未找到 {var} 的标准化栅格文件")

    print(f" 完成最终环境变量集创建，共包含 {len(selected_files)} 个变量")
    return selected_files

def save_results(var_names, selected_vars, selection_method, args, correlation_matrix=None):
    """保存处理结果和统计信息"""
    print("\n5. 保存结果和统计信息")
    
    env_output_dir = os.path.join(args.output_dir, "env_variables")
    
    # 保存变量信息
    var_info = pd.DataFrame({
        'variable': var_names,
        'selected': [var in selected_vars for var in var_names]
    })

    # 如果有相关性矩阵，添加平均相关性信息
    if correlation_matrix is not None:
        try:
            var_mean_corr = {}
            for i, var in enumerate(var_names):
                if i < len(correlation_matrix):
                    corrs = [abs(correlation_matrix[i, j]) for j in range(len(var_names)) 
                            if i != j and j < len(correlation_matrix)]
                    var_mean_corr[var] = np.mean(corrs) if corrs else 0
                else:
                    var_mean_corr[var] = 0
            var_info['mean_correlation'] = var_info['variable'].map(var_mean_corr)
            var_info = var_info.sort_values(['selected', 'mean_correlation'], ascending=[False, True])
        except Exception as e:
            print(f" 计算平均相关性失败: {e}")
            var_info = var_info.sort_values('selected', ascending=False)
    else:
        var_info = var_info.sort_values('selected', ascending=False)

    # 保存变量信息
    var_info_path = os.path.join(env_output_dir, "variable_info.csv")
    var_info.to_csv(var_info_path, index=False)
    print(f" 变量信息已保存至: {var_info_path}")

    # 保存选定变量列表
    selected_vars_path = os.path.join(env_output_dir, "selected_variables.csv")
    pd.DataFrame({'variable': selected_vars}).to_csv(selected_vars_path, index=False)
    print(f" 选定变量列表已保存至: {selected_vars_path}")
    
    # 保存相关性矩阵（如果存在）
    if correlation_matrix is not None:
        try:
            corr_matrix_path = os.path.join(env_output_dir, "correlation_matrix.csv")
            corr_df = pd.DataFrame(
                correlation_matrix,
                columns=var_names,
                index=var_names
            )
            if np.isnan(correlation_matrix).any():
                print(" 警告: 相关性矩阵包含NaN值，将替换为0")
                corr_df = corr_df.fillna(0)
            corr_df.to_csv(corr_matrix_path, float_format="%.4f")
            print(f" 相关性矩阵已保存至: {corr_matrix_path}")
        except Exception as e:
            print(f" 保存相关性矩阵失败: {e}")
    
    # 保存处理摘要
    summary = {
        'processing_date': pd.Timestamp.now().isoformat(),
        'selection_method': selection_method,
        'total_variables': len(var_names),
        'selected_variables': len(selected_vars),
        'selection_ratio': len(selected_vars) / len(var_names) if var_names else 0,
        'arguments': vars(args)
    }
    
    summary_path = os.path.join(env_output_dir, "processing_summary.json")
    import json
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)
    print(f" 处理摘要已保存至: {summary_path}")

def main():
    """环境变量预处理的主函数"""
    print("=" * 80)
    print("           环境变量预处理系统")
    print("=" * 80)
    print("=" * 80)
    
    # 解析命令行参数
    args = parse_args()
    
    # 验证参数
    try:
        validate_args(args)
    except (ValueError, FileNotFoundError) as e:
        print(f" 参数错误: {e}")
        return 1

    print(f" 输入目录: {args.env_dir}")
    print(f" 输出目录: {args.output_dir}")
    print(f" 变量筛选: {'是' if args.select_variables else '否'}")
    if args.select_variables:
        if args.features_csv:
            print(f" 特征文件: {args.features_csv}")
        print(f"🔗 相关性分析: {'是' if args.enable_correlation_analysis else '否'}")
        if args.enable_correlation_analysis:
            print(f" 相关性阈值: {args.correlation_threshold}")

    try:
        # 第一阶段：处理所有变量
        result = process_all_variables(args)
        if result[0] is None:  # 处理失败
            return 1
            
        standardized_files, var_names, figures_dir, cache_dir = result
        
        # 初始化变量
        correlation_matrix = None
        selected_vars = var_names  # 默认选择所有变量
        selection_method = "使用所有变量（未筛选）"
        
        # 第二阶段：可选的变量筛选
        if args.select_variables:
            # 相关性分析（如果启用）
            if args.enable_correlation_analysis:
                correlation_matrix, var_names = perform_correlation_analysis(
                    standardized_files, var_names, args, figures_dir, cache_dir
                )
            
            # 变量筛选
            selected_vars, selection_method = select_variables_by_method(
                var_names, args, correlation_matrix
            )
            
            # 创建selected文件夹
            create_selected_folder(selected_vars, args)
        else:
            print("\n 跳过变量筛选，保留所有变量")
        
        # 保存结果
        save_results(var_names, selected_vars, selection_method, args, correlation_matrix)
        
        # 最终摘要
        print("\n" + "="*80)
        print("           处理完成")
        print("="*80)
        print(f" 处理摘要:")
        print(f"   - 筛选方法: {selection_method}")
        print(f"   - 总变量数: {len(var_names)}")
        print(f"   - 选定变量数: {len(selected_vars)}")
        print(f"   - 选择比例: {len(selected_vars)/len(var_names)*100:.1f}%")
        
        output_dirs = []
        env_output_dir = os.path.join(args.output_dir, "env_variables")
        output_dirs.append(f"   - 原始栅格: {os.path.join(env_output_dir, 'original')}")
        output_dirs.append(f"   - 标准化栅格: {os.path.join(env_output_dir, 'standardized')}")
        if args.select_variables:
            output_dirs.append(f"   - 选定栅格: {os.path.join(env_output_dir, 'selected')}")
        
        print(f"\n 输出目录:")
        for dir_info in output_dirs:
            print(dir_info)
        
        print("="*80)
        return 0
        
    except KeyboardInterrupt:
        print("\n\n 用户中断程序执行")
        return 1
        
    except Exception as e:
        print(f"\n 程序执行出错: {e}")
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    exit(main())