# main.py
import os
import sys
import subprocess
from . import config
from datetime import datetime
import shlex
import shutil

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(SCRIPT_DIR)
print(f"当前工作目录: {SCRIPT_DIR}")

def validate_input_files():
    """验证输入文件是否存在"""
    print("\n验证输入文件...")
    
    files_to_check = [
        ("存在点文件", config.PRESENCE_FILE),
        ("边界文件", config.BOUNDARY_FILE),
        ("环境变量目录", config.ENV_DIR)
    ]
    
    missing_files = []
    
    for file_desc, file_path in files_to_check:
        if file_path is None:
            missing_files.append(f"{file_desc}: 未检测到")
        elif not os.path.exists(file_path):
            missing_files.append(f"{file_desc}: {file_path}")
        else:
            print(f"✓ {file_desc}: {os.path.basename(file_path)}")
    
    if missing_files:
        print("\n错误: 以下文件不存在或未检测到:")
        for missing in missing_files:
            print(f"  - {missing}")
        
        # 尝试重新检测
        print("\n尝试重新检测文件...")
        presence_file, boundary_file = config.auto_detect_files()
        
        if presence_file and boundary_file:
            print("✓ 重新检测成功，更新配置")
            config.PRESENCE_FILE = presence_file
            config.BOUNDARY_FILE = boundary_file
            return True
        else:
            print("✗ 重新检测失败")
            return False
    
    return True

def run_script(script_name, args, capture_output=False):
    """运行指定的Python脚本，支持捕获输出"""
    print(f"\n{'=' * 60}")
    print(f"  正在运行: {script_name}")
    print(f"{'=' * 60}")

    # 构造命令行参数
    script_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), script_name)
    cmd = [sys.executable, script_path]
    for key, value in args.items():
        if isinstance(value, bool) and value:
            cmd.append(f"--{key}")
        elif value is not None:
            cmd.extend([f"--{key}", str(value)])

    # 打印命令
    print("执行命令: " + ' '.join(shlex.quote(arg) for arg in cmd))

    # 执行命令
    result = subprocess.run(cmd, capture_output=capture_output)
    if capture_output and result.returncode == 0:
        return result.stdout.decode('utf-8').strip()
    return result.returncode


def create_directories(scenario_dir):
    """创建所有必要的输出目录"""
    print(f"\n创建输出目录 (场景: {scenario_dir})")

    # 基于场景创建目录
    processed_data_dir = os.path.join(config.PROCESSED_DATA_BASE_DIR, scenario_dir)
    env_output_dir = os.path.join(config.ENV_OUTPUT_BASE_DIR, scenario_dir)
    points_dir = os.path.join(processed_data_dir, "points")
    dataset_dir = os.path.join(processed_data_dir, "dataset")
    figures_dir = os.path.join(processed_data_dir, "figures")
    cache_dir = os.path.join(processed_data_dir, "cache")

    # 创建目录
    os.makedirs(processed_data_dir, exist_ok=True)
    os.makedirs(env_output_dir, exist_ok=True)
    os.makedirs(points_dir, exist_ok=True)
    os.makedirs(dataset_dir, exist_ok=True)
    os.makedirs(figures_dir, exist_ok=True)
    os.makedirs(cache_dir, exist_ok=True)

    print(f"- 主输出目录: {processed_data_dir}")
    print(f"- 环境变量输出目录: {env_output_dir}")

    return {
        "processed_data_dir": processed_data_dir,
        "env_output_dir": env_output_dir,
        "points_dir": points_dir,
        "dataset_dir": dataset_dir,
        "figures_dir": figures_dir,
        "cache_dir": cache_dir
    }


def backup_previous_results():
    """备份之前的结果"""
    try:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_dir = os.path.join(config.BACKUP_DIR, f"backup_{timestamp}")
        os.makedirs(backup_dir, exist_ok=True)
        
        # 备份特征选择文件
        if os.path.exists(config.FEATURES_CSV):
            shutil.copy2(config.FEATURES_CSV, 
                        os.path.join(backup_dir, "top30_variable_freq_avg.csv"))
            print(f"✓ 已备份特征选择文件到: {backup_dir}")
        
        return backup_dir
        
    except Exception as e:
        print(f"✗ 备份失败: {e}")
        return None


def handle_incremental_merge(new_variables, dirs):
    """处理增量合并"""
    print(f"\n开始增量合并处理 ({len(new_variables)} 个新变量)")
    
    all_paths = config.get_all_scenario_paths()
    
    # 1. 处理新增变量（重投影和标准化）
    print("步骤1: 处理新增变量")
    new_env_args = {
        "env_dir": config.ENV_DIR,
        "output_dir": dirs["env_output_dir"],
        "figures_dir": dirs["figures_dir"],
        "cache_dir": dirs["cache_dir"],
        "skip_existing": False,  # 对新变量不跳过
        "process_only_new": True,  # 新增参数：只处理新变量
        "new_variables": ",".join(new_variables)  # 传递新变量列表
    }
    
    ret_code = run_script("01_env_variables_preprocessing.py", new_env_args)
    if ret_code != 0:
        print(f"✗ 新变量处理失败")
        return False
    
    # 2. 合并到all场景
    print("步骤2: 合并到all场景")
    ret_code = merge_with_all_scenario(new_variables, dirs["env_output_dir"], all_paths)
    if ret_code != 0:
        print(f"✗ 合并到all场景失败")
        return False
    
    print("✓ 增量合并完成")
    return True


def merge_with_all_scenario(new_variables, new_env_dir, all_paths):
    """将新处理的变量合并到all场景中"""
    try:
        print("  合并标准化文件...")
        
        # 复制新的标准化文件到all场景
        new_standardized_dir = os.path.join(new_env_dir, "env_variables", "standardized")
        all_standardized_dir = all_paths['standardized_dir']
        
        for var in new_variables:
            src_file = os.path.join(new_standardized_dir, f"{var}.tif")
            dst_file = os.path.join(all_standardized_dir, f"{var}.tif")
            
            if os.path.exists(src_file):
                shutil.copy2(src_file, dst_file)
                print(f"    ✓ 已合并: {var}.tif")
            else:
                print(f"    ✗ 未找到: {var}.tif")
        
        # 重新生成all场景的完整特征栈
        print("  重新生成特征栈...")
        ret_code = regenerate_all_scenario_stack(all_paths)
        
        return ret_code
        
    except Exception as e:
        print(f"  ✗ 合并过程出错: {e}")
        return 1


def regenerate_all_scenario_stack(all_paths):
    """重新生成all场景的特征栈"""
    try:
        # 创建临时训练数据来生成特征栈
        import glob
        
        # 获取所有标准化的tif文件
        tif_files = glob.glob(os.path.join(all_paths['standardized_dir'], "*.tif"))
        feature_names = [os.path.splitext(os.path.basename(f))[0] for f in tif_files]
        feature_names.sort()
        
        print(f"    发现 {len(feature_names)} 个变量")
        
        # 使用新的脚本生成特征栈（需要修改05脚本支持直接从tif目录生成）
        stack_args = {
            "tif_dir": all_paths['standardized_dir'],
            "feature_names": ",".join(feature_names),
            "feature_cols_out": all_paths['feature_cols_joblib'],
            "output_stack_tif": all_paths['selected_stack_tif'],
            "direct_mode": True  # 直接模式，不依赖训练数据
        }
        
        ret_code = run_script("05_prepare_feature_stack.py", stack_args)
        return ret_code
        
    except Exception as e:
        print(f"    ✗ 重新生成特征栈失败: {e}")
        return 1


def copy_from_all_scenario(target_scenario_dir, selected_features):
    """从all场景复制选择的特征到目标场景"""
    print(f"\n从all场景复制选择的特征 ({len(selected_features)} 个)")
    
    all_paths = config.get_all_scenario_paths()
    target_env_dir = os.path.join(config.ENV_OUTPUT_BASE_DIR, target_scenario_dir, "env_variables")
    target_selected_dir = os.path.join(target_env_dir, "selected")
    
    os.makedirs(target_selected_dir, exist_ok=True)
    
    # 复制选择的特征文件
    copied_features = []
    for feature in selected_features:
        src_file = os.path.join(all_paths['standardized_dir'], f"{feature}.tif")
        dst_file = os.path.join(target_selected_dir, f"{feature}.tif")
        
        if os.path.exists(src_file):
            shutil.copy2(src_file, dst_file)
            copied_features.append(feature)
            print(f"  ✓ 已复制: {feature}.tif")
        else:
            print(f"  ✗ 未找到: {feature}.tif")
    
    print(f"✓ 成功复制 {len(copied_features)} 个特征文件")
    return target_selected_dir, copied_features


def main():
    """主执行函数"""
    start_time = datetime.now()
    print("\n" + "=" * 80)
    print(f"  物种分布数据预处理流程 - 开始时间: {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 80)

    if not validate_input_files():
        print("\n请检查以下位置是否存在shp文件:")
        print(f"  - 存在点目录: {os.path.join(config.DATA_DIR, 'raw', 'species_presence')}")
        print(f"  - 边界文件目录: {os.path.join(config.DATA_DIR, 'external', 'boundary')}")
        return 1

    # 1. 确定处理策略
    strategy_info = config.determine_processing_strategy()
    strategy = strategy_info['strategy']
    scenario = strategy_info['scenario']
    change_info = strategy_info['change_info']

    print(f"\n处理策略分析:")
    print(f"  - 策略: {strategy}")
    print(f"  - 场景: {scenario}")
    
    if change_info['has_changes']:
        if change_info['new_variables']:
            print(f"  - 新增变量: {len(change_info['new_variables'])} 个")
        if change_info['removed_variables']:
            print(f"  - 移除变量: {len(change_info['removed_variables'])} 个")
    
    # 2. 备份（如果需要）
    if strategy_info['has_feature_csv'] and config.BACKUP_PREVIOUS_RESULTS:
        backup_dir = backup_previous_results()

    # 3. 创建目录
    dirs = create_directories(scenario)

    # 4. 根据策略执行不同的处理流程
    if strategy == 'incremental_merge':
        # 增量合并模式
        success = handle_incremental_merge(change_info['new_variables'], dirs)
        if not success:
            print("✗ 增量合并失败，切换到完全重新处理")
            strategy = 'full_process_all'
        else:
            # 增量合并成功，使用all场景的结果继续后续处理
            env_final_dir = config.get_all_scenario_paths()['standardized_dir']

    if strategy in ['full_process_all', 'full_reprocess_all', 'use_all']:
        # 完全处理all场景
        print(f"\n执行完全处理流程 (策略: {strategy})")
        
        # 如果是重新处理，删除现有的CSV文件
        if strategy == 'full_reprocess_all' and os.path.exists(config.FEATURES_CSV):
            os.remove(config.FEATURES_CSV)
            print("  已删除现有特征选择文件")

        # ================== 01 环境变量预处理 ==================
        env_args = {
            "env_dir": config.ENV_DIR,
            "output_dir": dirs["env_output_dir"],
            "figures_dir": dirs["figures_dir"],
            "cache_dir": dirs["cache_dir"],
            "skip_existing": config.SKIP_EXISTING
        }

        ret_code = run_script("01_env_variables_preprocessing.py", env_args)
        if ret_code != 0:
            print(f"\n✗ 环境变量预处理失败")
            return ret_code

        env_final_dir = os.path.join(dirs["env_output_dir"], "env_variables", "standardized")

    elif strategy == 'use_selected':
        # 使用选择的特征
        print(f"\n使用已选择的特征")
        
        # 读取选择的特征
        import pandas as pd
        features_df = pd.read_csv(config.FEATURES_CSV)
        selected_features = features_df[config.FEATURE_COLUMN].tolist()
        
        # 从all场景复制选择的特征
        env_final_dir, copied_features = copy_from_all_scenario(scenario, selected_features)
        
        if len(copied_features) != len(selected_features):
            print(f"✗ 部分特征文件缺失，切换到完全处理模式")
            strategy = 'full_process_all'
            # 重新执行完全处理...
            env_args = {
                "env_dir": config.ENV_DIR,
                "output_dir": dirs["env_output_dir"],
                "figures_dir": dirs["figures_dir"],
                "cache_dir": dirs["cache_dir"],
                "skip_existing": config.SKIP_EXISTING,
                "select_variables": True,
                "features_csv": config.FEATURES_CSV,
                "feature_column": config.FEATURE_COLUMN
            }

            ret_code = run_script("01_env_variables_preprocessing.py", env_args)
            if ret_code != 0:
                print(f"\n✗ 环境变量预处理失败")
                return ret_code

            env_final_dir = os.path.join(dirs["env_output_dir"], "env_variables", "selected")

    
    # 02 存在点处理
    presence_args = {
        "presence_file": config.PRESENCE_FILE,
        "boundary_file": config.BOUNDARY_FILE,
        "env_dir": env_final_dir,
        "output_dir": dirs["processed_data_dir"],
        "figures_dir": dirs["figures_dir"],
        "cache_dir": os.path.join(dirs["cache_dir"], "env_values")
    }

    ret_code = run_script("02_presence_points_processing.py", presence_args)
    if ret_code != 0:
        print(f"\n✗ 存在点处理失败")
        return ret_code

    # 03 背景点生成
    presence_output_file = os.path.join(dirs["points_dir"], "presence_points_with_env.gpkg")
    background_args = {
        "presence_file": presence_output_file,
        "boundary_file": config.BOUNDARY_FILE,
        "env_dir": env_final_dir,
        "output_dir": dirs["processed_data_dir"],
        "figures_dir": dirs["figures_dir"],
        "cache_dir": os.path.join(dirs["cache_dir"], "env_values"),
        "buffer_distance_km": config.BUFFER_DISTANCE_KM,
        "background_multiplier": config.BACKGROUND_MULTIPLIER,
        "method": config.BACKGROUND_METHOD
    }

    ret_code = run_script("03_background_points_generation.py", background_args)
    if ret_code != 0:
        print(f"\n✗ 背景点生成失败")
        return ret_code

    # 04 数据集划分
    dataset_args = {
        "output_dir": dirs["processed_data_dir"],
        "boundary_file": config.BOUNDARY_FILE
    }

    ret_code = run_script("04_dataset_splitting.py", dataset_args)
    if ret_code != 0:
        print(f"\n✗ 数据集划分失败")
        return ret_code

    # 05 准备特征堆栈
    train_csv = os.path.join(dirs["dataset_dir"], "train_data.csv")
    stack_args = {
        "train_csv": train_csv,
        "feature_cols_out": os.path.join(env_final_dir, config.FEATURE_COLS_OUT),
        "tif_dir": env_final_dir,
        "output_stack_tif": os.path.join(env_final_dir, config.OUTPUT_STACK_TIF)
    }

    ret_code = run_script("05_prepare_feature_stack.py", stack_args)
    if ret_code != 0:
        print(f"\n✗ 特征堆栈准备失败")
        return ret_code

    # ================== 流程完成 ==================
    end_time = datetime.now()
    duration = end_time - start_time

    print("\n" + "=" * 80)
    print(f"  数据处理流程已完成!")
    print(f"  策略: {strategy}")
    print(f"  场景: {scenario}")
    print(f"  总耗时: {duration}")

    # 显示最终输出文件位置
    print("\n最终输出文件:")
    print(f"- 训练集: {os.path.join(dirs['dataset_dir'], 'train_data.csv')}")
    print(f"- 测试集: {os.path.join(dirs['dataset_dir'], 'test_data.csv')}")
    print(f"- 多波段环境变量堆栈: {os.path.join(env_final_dir, config.OUTPUT_STACK_TIF)}")
    print(f"- 特征列表: {os.path.join(env_final_dir, config.FEATURE_COLS_OUT)}")

    print("=" * 80)
    return 0


if __name__ == "__main__":
    sys.exit(main())