import os
import joblib
import pandas as pd
from osgeo import gdal
import argparse

def save_feature_cols(feature_cols, output_path):
    """保存特征名列表为joblib文件"""
    joblib.dump(feature_cols, output_path)
    print(f"已保存特征名到: {output_path}")

def combine_tifs_to_multiband(feature_cols, tif_dir, output_path):
    """
    将feature_cols中所有变量的tif（假定文件名带变量名）合成多波段tif
    tif_dir: 存放所有单变量tif的目录
    output_path: 输出多波段tif路径
    """
    band_arrays = []
    first_ds = None
    for i, var in enumerate(feature_cols):
        # 在tif_dir中按变量名找文件（允许模糊匹配）
        tif_files = [f for f in os.listdir(tif_dir) if var in f and f.endswith('.tif')]
        if len(tif_files) == 0:
            raise FileNotFoundError(f"未找到变量 {var} 对应的tif文件")
        tif_path = os.path.join(tif_dir, tif_files[0])
        ds = gdal.Open(tif_path)
        arr = ds.GetRasterBand(1).ReadAsArray()
        band_arrays.append(arr)
        if first_ds is None:
            first_ds = ds
        print(f"添加变量 {var}: {tif_files[0]}  shape={arr.shape}")

    # 检查所有栅格shape一致
    ref_shape = band_arrays[0].shape
    for arr in band_arrays:
        if arr.shape != ref_shape:
            raise ValueError("所有tif shape需一致，发现不一致！")

    n_rows, n_cols = ref_shape
    n_bands = len(band_arrays)

    # 创建输出多波段tif
    driver = gdal.GetDriverByName("GTiff")
    out_ds = driver.Create(output_path, n_cols, n_rows, n_bands, gdal.GDT_Float32)
    out_ds.SetGeoTransform(first_ds.GetGeoTransform())
    out_ds.SetProjection(first_ds.GetProjection())

    for i, arr in enumerate(band_arrays):
        out_ds.GetRasterBand(i+1).WriteArray(arr)
        out_ds.GetRasterBand(i+1).SetNoDataValue(-9999)

    out_ds.FlushCache()
    out_ds = None
    print(f"已输出多波段stack tif到: {output_path}")

def parse_args():
    parser = argparse.ArgumentParser(description="保存特征名并合成多波段tif（命令行参数版）")
    parser.add_argument('--train_csv', type=str, help="包含所有特征的train_data.csv路径")
    parser.add_argument('--feature_cols_out', type=str, required=True, help="特征名joblib输出路径")
    parser.add_argument('--tif_dir', type=str, required=True, help="单变量tif文件夹路径")
    parser.add_argument('--output_stack_tif', type=str, required=True, help="输出多波段tif路径")
    parser.add_argument('--direct_mode', action='store_true', help="直接模式：从tif目录生成，不依赖训练数据")
    parser.add_argument('--feature_names', type=str, help="直接模式下的特征名列表（逗号分隔）")
    return parser.parse_args()

if __name__ == "__main__":
    args = parse_args()

    if args.direct_mode:
        # 直接模式：从特征名列表生成
        if args.feature_names:
            feature_cols = args.feature_names.split(',')
        else:
            # 从tif目录自动扫描
            import glob
            tif_files = glob.glob(os.path.join(args.tif_dir, "*.tif"))
            feature_cols = sorted([os.path.splitext(os.path.basename(f))[0] for f in tif_files])
        
        print(f"直接模式：处理 {len(feature_cols)} 个特征")
    else:
        # 正常模式：从训练数据读取
        train_data = pd.read_csv(args.train_csv)
        feature_cols = [col for col in train_data.columns if col not in ['presence', 'longitude', 'latitude']]

    # 保存特征名
    save_feature_cols(feature_cols, args.feature_cols_out)

    # 合成多波段tif
    combine_tifs_to_multiband(feature_cols, args.tif_dir, args.output_stack_tif)

# & D:\Anaconda\envs\env\python.exe D:\ginkgo\code\data_preprocessing\05_prepare_feature_stack.py --train_csv "D:/ginkgo/data/processed/黄花刺茄数据_30/dataset/train_data.csv" --feature_cols_out "D:/ginkgo/data/processed/黄花刺茄数据_30/env_variables/feature_cols.joblib" --tif_dir "D:/ginkgo/data/processed/黄花刺茄数据_30/env_variables/selected" --output_stack_tif "D:/ginkgo/data/processed/黄花刺茄数据_30/env_variables/selected_stack.tif"