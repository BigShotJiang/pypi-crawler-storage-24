# 适生区模型数据预处理工具函数
import os
import numpy as np
import pandas as pd
import geopandas as gpd
import rasterio
import seaborn as sns
from rasterio.mask import mask
from rasterio.warp import calculate_default_transform, reproject, Resampling
from rasterio.features import geometry_mask
import matplotlib.pyplot as plt
from shapely.geometry import Point, box, mapping
from shapely.ops import unary_union
import pickle
from scipy.spatial.distance import cdist
from sklearn.preprocessing import StandardScaler
import warnings
from tqdm.auto import tqdm
from pathlib import Path
import hashlib

# 禁用警告
warnings.filterwarnings('ignore')

# 设置绘图样式
plt.style.use('seaborn-v0_8-whitegrid')
plt.rcParams['font.family'] = 'SimHei'  # 中文字体
plt.rcParams['axes.unicode_minus'] = False  # 正确显示负号


# ===== 文件和路径工具 =====

def ensure_dir(directory):
    """确保目录存在，如果不存在则创建"""
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"创建目录: {directory}")
    return directory


def list_raster_files(directory, pattern="*.tif"):
    """列出目录中的所有栅格文件"""
    from glob import glob
    files = sorted(glob(os.path.join(directory, pattern)))
    print(f"找到 {len(files)} 个栅格文件")
    return files


def get_env_variable_name(file_path):
    """从栅格文件路径获取环境变量名称"""
    return os.path.splitext(os.path.basename(file_path))[0]


def create_file_hash(file_path):
    """创建文件内容的哈希值，用于缓存"""
    hasher = hashlib.md5()
    with open(file_path, 'rb') as f:
        buf = f.read(65536)  # 读取64kb块
        while len(buf) > 0:
            hasher.update(buf)
            buf = f.read(65536)
    return hasher.hexdigest()


# ===== 栅格处理工具 =====

def check_raster_alignment(raster_files):
    """
    检查栅格文件是否具有相同的分辨率和坐标系
    """
    if not raster_files:
        return False
    
    print("检查栅格对齐情况...")
    
    with rasterio.open(raster_files[0]) as src:
        ref_crs = src.crs
        ref_res = tuple(round(x, 3) for x in src.res)  # 分辨率保留3位小数
        ref_bounds = src.bounds
        ref_shape = src.shape
    
    print(f"参考栅格: {os.path.basename(raster_files[0])}")
    print(f"  坐标系: {ref_crs}")
    print(f"  分辨率: {ref_res}")
    print(f"  范围: {ref_bounds}")
    print(f"  形状: {ref_shape}")
    
    misaligned = []
    for i, raster_file in enumerate(raster_files[1:], 1):
        with rasterio.open(raster_file) as src:
            current_res = tuple(round(x, 3) for x in src.res)  # 当前文件分辨率也保留3位小数
            # 比较坐标系和四舍五入后的分辨率
            if src.crs != ref_crs or current_res != ref_res:
                misaligned.append((raster_file, src.crs, current_res, src.shape))
    
    if misaligned:
        print(f"发现 {len(misaligned)} 个栅格文件坐标系或分辨率不一致:")
        for file_path, crs, res, shape in misaligned[:5]:
            print(f"  {os.path.basename(file_path)}: CRS={crs}, 分辨率={res}")
        if len(misaligned) > 5:
            print(f"  ...以及 {len(misaligned) - 5} 个其他文件")
        return False
    
    print("所有栅格文件的坐标系和分辨率一致!")
    return True


def standardize_raster(input_path, output_path):
    """对栅格文件进行Z-score标准化"""
    with rasterio.open(input_path) as src:
        data = src.read(1)
        meta = src.meta.copy()
        
        # 创建掩码(忽略NoData值)
        mask = data != src.nodata
        if not mask.any():  # 如果全是NoData值
            print(f"警告: {os.path.basename(input_path)} 全是NoData值")
            return False
        
        # 提取有效值
        valid_data = data[mask]
        
        # 计算均值和标准差
        mean = np.mean(valid_data)
        std = np.std(valid_data)
        
        if std == 0:  # 避免除以零
            print(f"警告: {os.path.basename(input_path)} 标准差为0，跳过标准化")
            return False
        
        # 应用Z-score标准化
        data_standardized = np.copy(data).astype(np.float32)
        data_standardized[mask] = (valid_data - mean) / std
        data_standardized[~mask] = src.nodata
        
        # 更新元数据
        meta.update({'dtype': 'float32'})
        
        # 写入标准化后的栅格
        with rasterio.open(output_path, 'w', **meta) as dst:
            dst.write(data_standardized, 1)
            
    return True


def reproject_raster(input_path, output_path, dst_crs='EPSG:4326'):
    """重投影栅格到指定坐标系"""
    with rasterio.open(input_path) as src:
        if src.crs == dst_crs:
            print(f"{os.path.basename(input_path)} 已经是目标坐标系 {dst_crs}")
            # 复制文件
            with rasterio.open(output_path, 'w', **src.meta) as dst:
                dst.write(src.read())
            return True
            
        # 计算转换参数
        transform, width, height = calculate_default_transform(
            src.crs, dst_crs, src.width, src.height, *src.bounds)
        
        # 更新元数据
        meta = src.meta.copy()
        meta.update({
            'crs': dst_crs,
            'transform': transform,
            'width': width,
            'height': height
        })
        
        # 重投影
        with rasterio.open(output_path, 'w', **meta) as dst:
            for i in range(1, src.count + 1):
                reproject(
                    source=rasterio.band(src, i),
                    destination=rasterio.band(dst, i),
                    src_transform=src.transform,
                    src_crs=src.crs,
                    dst_transform=transform,
                    dst_crs=dst_crs,
                    resampling=Resampling.bilinear)
    
    return True


def extract_values_from_rasters(points_gdf, raster_files, env_cache_dir=None):
    """从栅格中提取点位置的环境变量值"""
    # 创建结果DataFrame
    result_df = points_gdf.copy()
    
    # 获取点的坐标
    coords = [(point.x, point.y) for point in points_gdf.geometry]
    
    # 创建缓存目录
    if env_cache_dir:
        ensure_dir(env_cache_dir)
    
    # 遍历栅格文件提取值
    for raster_file in tqdm(raster_files, desc="提取环境变量"):
        var_name = get_env_variable_name(raster_file)
        
        # 检查缓存
        cache_file = None
        if env_cache_dir:
            file_hash = create_file_hash(raster_file)
            cache_file = os.path.join(env_cache_dir, f"{var_name}_{file_hash}.pkl")
            
            if os.path.exists(cache_file):
                with open(cache_file, 'rb') as f:
                    cached_coords, cached_values = pickle.load(f)
                
                # 检查坐标是否匹配
                if len(cached_coords) == len(coords) and all(np.allclose(c1, c2) for c1, c2 in zip(cached_coords, coords)):
                    result_df[var_name] = cached_values
                    continue
        
        try:
            with rasterio.open(raster_file) as src:
                # 提取点位置的栅格值
                values = []
                for x, y in coords:
                    # 转换为像素坐标
                    try:
                        row, col = src.index(x, y)
                        # 检查是否在栅格范围内
                        if 0 <= row < src.height and 0 <= col < src.width:
                            value = src.read(1)[row, col]
                            if value == src.nodata:
                                values.append(np.nan)
                            else:
                                values.append(float(value))
                        else:
                            values.append(np.nan)
                    except:
                        values.append(np.nan)
                
                result_df[var_name] = values
                
                # 缓存结果
                if cache_file:
                    with open(cache_file, 'wb') as f:
                        pickle.dump((coords, values), f)
                
        except Exception as e:
            print(f"提取{var_name}时出错: {e}")
            result_df[var_name] = np.nan
    
    return result_df


def calculate_raster_correlation(raster_files, sample_size=10000, cache_dir=None):
    """
    计算栅格文件之间的相关性
    
    参数:
    raster_files: 栅格文件路径列表
    sample_size: 用于计算相关性的随机样本大小
    cache_dir: 缓存目录，如果提供则缓存结果
    
    返回:
    correlation_matrix: 相关性矩阵
    var_names: 变量名称列表
    """
    # 检查缓存
    cache_file = None
    if cache_dir:
        ensure_dir(cache_dir)
        # 创建文件列表的哈希值作为缓存键
        hash_input = ''.join(sorted([os.path.basename(f) for f in raster_files]))
        cache_key = hashlib.md5(hash_input.encode()).hexdigest()
        cache_file = os.path.join(cache_dir, f"corr_matrix_{cache_key}_{sample_size}.pkl")
        
        if os.path.exists(cache_file):
            print(f"从缓存加载相关性矩阵: {cache_file}")
            try:
                with open(cache_file, 'rb') as f:
                    result = pickle.load(f)
                    # 验证缓存数据的结构
                    if (isinstance(result, tuple) and len(result) == 2 and 
                        isinstance(result[0], np.ndarray) and isinstance(result[1], list)):
                        return result
                    else:
                        print("缓存数据结构不正确，重新计算相关性矩阵")
            except Exception as e:
                print(f"加载缓存失败，重新计算相关性矩阵: {e}")
    
    # 获取变量名
    var_names = [get_env_variable_name(f) for f in raster_files]
    
    # 检查变量名是否唯一
    if len(var_names) != len(set(var_names)):
        print("警告: 发现重复的变量名，可能会导致相关性矩阵不准确")
        # 确保变量名唯一
        unique_var_names = []
        for i, name in enumerate(var_names):
            count = var_names[:i].count(name)
            if count > 0:
                unique_var_names.append(f"{name}_{count+1}")
            else:
                unique_var_names.append(name)
        var_names = unique_var_names
    
    # 从第一个栅格获取参考信息
    try:
        with rasterio.open(raster_files[0]) as src:
            height, width = src.height, src.width
            total_pixels = height * width
            
            # 确定采样大小
            if sample_size > total_pixels:
                sample_size = total_pixels
                print(f"警告: 采样大小大于总像素数，调整为 {sample_size}")
            
            # 随机选择像素位置
            np.random.seed(42)  # 设置随机种子以确保可重复性
            random_indices = np.random.choice(total_pixels, size=sample_size, replace=False)
            rows, cols = np.unravel_index(random_indices, (height, width))
            
            # 创建掩码(忽略NoData值)
            mask = src.read(1) != src.nodata
    except Exception as e:
        print(f"读取第一个栅格文件失败: {e}")
        return np.eye(len(raster_files)), var_names
    
    # 提取每个栅格的像素值
    print("从栅格中提取随机样本...")
    samples = np.full((len(raster_files), sample_size), np.nan)
    
    for i, raster_file in enumerate(tqdm(raster_files, desc="读取栅格")):
        try:
            with rasterio.open(raster_file) as src:
                data = src.read(1)
                for j in range(sample_size):
                    row, col = rows[j], cols[j]
                    if 0 <= row < src.height and 0 <= col < src.width:
                        value = data[row, col]
                        if value != src.nodata:
                            samples[i, j] = value
        except Exception as e:
            print(f"读取栅格 {os.path.basename(raster_file)} 失败: {e}")
    
    # 移除全是NaN的行
    valid_rows = np.logical_not(np.all(np.isnan(samples), axis=1))
    if not np.any(valid_rows):
        print("错误: 所有提取的样本都是NaN值")
        return np.eye(len(raster_files)), var_names
    
    valid_samples = samples[valid_rows]
    valid_var_names = [var_names[i] for i, valid in enumerate(valid_rows) if valid]
    
    if len(valid_var_names) < len(var_names):
        print(f"警告: {len(var_names) - len(valid_var_names)} 个变量因为全是NaN被移除")
        var_names = valid_var_names
        samples = valid_samples
    
    # 替换NaN为每列的中值
    for col in range(samples.shape[1]):
        col_data = samples[:, col]
        if np.all(np.isnan(col_data)):
            # 如果整列都是NaN，用0填充
            samples[:, col] = 0
        else:
            # 否则用中值填充NaN
            col_median = np.nanmedian(col_data)
            nan_indices = np.isnan(col_data)
            samples[nan_indices, col] = col_median
    
    # 计算相关系数矩阵
    print("计算相关性矩阵...")
    try:
        correlation_matrix = np.corrcoef(samples)
        
        # 检查结果
        if np.isnan(correlation_matrix).any():
            print("警告: 相关性矩阵包含NaN值，将替换为0")
            correlation_matrix = np.nan_to_num(correlation_matrix)
    except Exception as e:
        print(f"计算相关性矩阵失败: {e}")
        # 返回单位矩阵作为后备
        correlation_matrix = np.eye(len(var_names))
    
    # 缓存结果
    if cache_file:
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump((correlation_matrix, var_names), f)
            print(f"相关性矩阵已缓存到: {cache_file}")
        except Exception as e:
            print(f"缓存相关性矩阵失败: {e}")
    
    return correlation_matrix, var_names


def identify_correlated_pairs(correlation_matrix, var_names, threshold=0.8):
    """
    识别相关系数高于阈值的变量对
    
    参数:
    correlation_matrix: 相关性矩阵
    var_names: 变量名称列表
    threshold: 相关性阈值
    
    返回:
    high_corr_pairs: (var1, var2, corr)元组列表，按相关性降序排序
    """
    high_corr_pairs = []
    
    for i in range(len(var_names)):
        for j in range(i+1, len(var_names)):
            corr = correlation_matrix[i, j]
            if abs(corr) > threshold:
                high_corr_pairs.append((var_names[i], var_names[j], corr))
    
    # 按相关性绝对值降序排序
    high_corr_pairs.sort(key=lambda x: abs(x[2]), reverse=True)
    
    return high_corr_pairs


def select_uncorrelated_variables(correlation_matrix, var_names, threshold=0.8):
    """
    选择不相关的变量子集
    
    参数:
    correlation_matrix: 相关性矩阵
    var_names: 变量名称列表
    threshold: 相关性阈值
    
    返回:
    selected_vars: 保留的变量列表
    removed_vars: 被删除的变量列表
    """
    # 获取高相关性变量对
    high_corr_pairs = identify_correlated_pairs(correlation_matrix, var_names, threshold)
    
    # 记录要删除的变量
    to_remove = set()
    
    # 为每个变量计算与其他变量的平均相关性
    var_mean_corr = {}
    for i, var in enumerate(var_names):
        # 计算与所有其他变量的平均相关性
        corrs = [abs(correlation_matrix[i, j]) for j in range(len(var_names)) if i != j]
        var_mean_corr[var] = np.mean(corrs)
    
    # 处理高相关性对
    for var1, var2, corr in high_corr_pairs:
        # 如果其中一个已经在要删除的集合中，跳过
        if var1 in to_remove or var2 in to_remove:
            continue
        
        # 删除平均相关性更高的变量
        if var_mean_corr[var1] > var_mean_corr[var2]:
            to_remove.add(var1)
        else:
            to_remove.add(var2)
    
    # 确定要保留的变量
    selected_vars = [var for var in var_names if var not in to_remove]
    removed_vars = list(to_remove)
    
    print(f"选择了 {len(selected_vars)} 个变量，移除了 {len(removed_vars)} 个变量")
    
    return selected_vars, removed_vars


# ===== 空间分析工具 =====

def create_buffer_around_points(points_gdf, buffer_distance_km=10):
    """
    在点周围创建缓冲区
    
    参数:
    points_gdf: 点的GeoDataFrame
    buffer_distance_km: 缓冲区距离(千米)
    
    返回:
    buffer_gdf: 缓冲区GeoDataFrame
    """
    # 检查坐标系统是否为地理坐标系
    if points_gdf.crs.is_geographic:
        # 将千米转换为度，大致近似为111.32千米/度（在赤道）
        # 这是一个粗略的近似，不同纬度上的转换比例不同
        buffer_distance_deg = buffer_distance_km / 111.32
        
        # 创建带缓冲区的点几何图形
        buffer_geometries = [point.buffer(buffer_distance_deg) for point in points_gdf.geometry]
    else:
        # 投影坐标系，直接使用距离(假设单位为米)
        buffer_distance_m = buffer_distance_km * 1000
        buffer_geometries = [point.buffer(buffer_distance_m) for point in points_gdf.geometry]
    
    # 合并所有缓冲区
    union_buffer = unary_union(buffer_geometries)
    
    # 创建缓冲区GeoDataFrame
    buffer_gdf = gpd.GeoDataFrame(geometry=[union_buffer], crs=points_gdf.crs)
    
    return buffer_gdf


def sample_points_outside_buffer(boundary_gdf, buffer_gdf, n_points):
    """
    在边界内、缓冲区外随机采样点
    """
    # 确保坐标系一致
    if boundary_gdf.crs != buffer_gdf.crs:
        buffer_gdf = buffer_gdf.to_crs(boundary_gdf.crs)
    
    # 合并所有省的geometry为一个整体
    boundary_union = boundary_gdf.unary_union
    buffer_union = buffer_gdf.unary_union
    
    # 采样区域是所有省的联合-缓冲区
    try:
        sampling_area = boundary_union.difference(buffer_union)
    except Exception as e:
        print("计算差集失败，尝试不减去缓冲区:", e)
        sampling_area = boundary_union
    
    minx, miny, maxx, maxy = sampling_area.bounds
    points = []
    pbar = tqdm(total=n_points, desc="生成背景点")
    
    while len(points) < n_points:
        batch_size = min(1000, n_points - len(points))
        xs = np.random.uniform(minx, maxx, batch_size)
        ys = np.random.uniform(miny, maxy, batch_size)
        for x, y in zip(xs, ys):
            point = Point(x, y)
            if sampling_area.contains(point):
                points.append(point)
                pbar.update(1)
                if len(points) >= n_points:
                    break
    pbar.close()
    
    sampled_points_gdf = gpd.GeoDataFrame({'geometry': points}, crs=boundary_gdf.crs)
    return sampled_points_gdf


# ===== 数据分析和可视化工具 =====

def plot_correlation_matrix(correlation_matrix, var_names, output_path=None, figsize=(14, 12)):
    import seaborn as sns

    # 确保变量名与矩阵维度一致
    if len(var_names) != correlation_matrix.shape[0]:
        raise ValueError("变量名数量与相关性矩阵不一致，请检查变量名生成过程！")

    corr_df = pd.DataFrame(correlation_matrix, index=var_names, columns=var_names)
    plt.figure(figsize=figsize if len(var_names) <= 30 else (max(12, 0.45*len(var_names)), max(10, 0.45*len(var_names))))
    cmap = sns.diverging_palette(220, 20, as_cmap=True)
    ax = sns.heatmap(
        corr_df, cmap=cmap, vmax=1, vmin=-1, center=0,
        square=True, linewidths=.5, annot=False, cbar_kws={"shrink": .5},
        xticklabels=True, yticklabels=True
    )
    plt.title('环境变量相关性矩阵', fontsize=16)
    plt.xticks(rotation=90, fontsize=8)
    plt.yticks(rotation=0, fontsize=8)
    plt.tight_layout()
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"相关性矩阵图已保存至: {output_path}")
    return plt.gcf()


def plot_point_distribution(presence_gdf, background_gdf=None, boundary_gdf=None, 
                           output_path=None, figsize=(14, 12)):
    """绘制存在点和背景点分布图"""
    fig, ax = plt.subplots(figsize=figsize)
    
    # 绘制边界
    if boundary_gdf is not None:
        boundary_gdf.plot(ax=ax, color='lightgray', edgecolor='gray', alpha=0.5)
    
    # 绘制背景点
    if background_gdf is not None:
        background_gdf.plot(ax=ax, color='blue', markersize=10, alpha=0.5, label='背景点')
    
    # 绘制存在点
    presence_gdf.plot(ax=ax, color='red', markersize=30, alpha=0.7, label='存在点')
    
    # 设置标题和标签
    ax.set_title('点分布图', fontsize=16)
    ax.set_xlabel('经度', fontsize=12)
    ax.set_ylabel('纬度', fontsize=12)
    ax.legend(loc='upper right')
    
    # 添加网格
    ax.grid(True, linestyle='--', alpha=0.7)
    
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"点分布图已保存至: {output_path}")
    
    return fig


def plot_env_variable_histograms(env_data, vars_to_plot=None, n_cols=3, output_path=None):
    """绘制环境变量的直方图"""
    if vars_to_plot is None:
        vars_to_plot = env_data.columns.tolist()
    
    # 限制变量数量
    vars_to_plot = vars_to_plot[:30]  # 最多绘制30个变量
    
    n_vars = len(vars_to_plot)
    n_rows = (n_vars + n_cols - 1) // n_cols
    
    fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 4, n_rows * 3))
    
    if n_vars == 1:
        axes = [axes]
    else:
        axes = axes.flatten()
    
    for i, var in enumerate(vars_to_plot):
        if i < len(axes):
            sns.histplot(env_data[var].dropna(), kde=True, ax=axes[i])
            axes[i].set_title(var)
    
    # 隐藏未使用的子图
    for j in range(n_vars, len(axes)):
        axes[j].axis('off')
    
    plt.tight_layout()
    
    if output_path:
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        print(f"环境变量直方图已保存至: {output_path}")
    
    return fig