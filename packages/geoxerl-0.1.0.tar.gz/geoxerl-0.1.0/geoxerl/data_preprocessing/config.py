# config.py
from datetime import datetime
import json
import os
import glob

# 获取当前文件（config.py）所在的目录
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))

# 项目根目录：上两级目录（因为当前目录是项目根目录/code/data_preprocessing）
BASE_DIR = os.path.dirname(os.path.dirname(CURRENT_DIR))

# 数据目录
DATA_DIR = os.path.join(BASE_DIR, "data")
# 结果目录
RESULTS_DIR = os.path.join(CURRENT_DIR, "results")

# ================== 文件自动检测函数 ==================
def find_shapefile_in_directory(directory, description="shapefile"):
    """
    在指定目录中查找shp文件
    """
    if not os.path.exists(directory):
        print(f"警告: 目录不存在: {directory}")
        return None
    
    # 查找所有shp文件
    shp_files = glob.glob(os.path.join(directory, "*.shp"))
    
    if not shp_files:
        print(f"警告: 在目录 {directory} 中未找到shp文件")
        return None
    elif len(shp_files) == 1:
        print(f" 找到{description}: {os.path.basename(shp_files[0])}")
        return shp_files[0]
    else:
        print(f"警告: 在目录 {directory} 中找到多个shp文件:")
        for i, shp_file in enumerate(shp_files):
            print(f"  {i+1}. {os.path.basename(shp_file)}")
        # 返回第一个文件
        print(f" 使用第一个文件: {os.path.basename(shp_files[0])}")
        return shp_files[0]

def auto_detect_files():
    """
    自动检测存在点和边界文件
    """
    print("自动检测数据文件...")
    
    # 检测存在点文件
    presence_dir = os.path.join(DATA_DIR, "raw", "species_presence")
    presence_file = find_shapefile_in_directory(presence_dir, "存在点文件")
    
    # 检测边界文件
    boundary_dir = os.path.join(DATA_DIR, "external", "boundary")
    boundary_file = find_shapefile_in_directory(boundary_dir, "边界文件")
    
    return presence_file, boundary_file

# ================== 01 环境变量预处理配置 ==================
# 原始环境变量目录
ENV_DIR = os.path.join(DATA_DIR, "raw", "environment_variables")
# 环境变量预处理输出基础目录
ENV_OUTPUT_BASE_DIR = os.path.join(RESULTS_DIR, "preprocessed", "environment")
# 特征选择CSV文件路径（如果存在则使用）
FEATURES_CSV = os.path.join(os.path.dirname(CURRENT_DIR), "ensemble", "results", "top30_variable_freq_avg.csv")
# 特征选择列名
FEATURE_COLUMN = "feature"
# 跳过已存在文件
SKIP_EXISTING = True

# ================== 02 存在点处理配置 ==================
# 自动检测文件
PRESENCE_FILE, BOUNDARY_FILE = auto_detect_files()

# 如果自动检测失败，使用默认路径
if PRESENCE_FILE is None:
    PRESENCE_FILE = os.path.join(DATA_DIR, "raw", "species_presence", "species_presence.shp")
if BOUNDARY_FILE is None:
    BOUNDARY_FILE = os.path.join(DATA_DIR, "external", "boundary", "country.shp")

# ================== 03 背景点生成配置 ==================
# 缓冲区距离(km)
BUFFER_DISTANCE_KM = 10
# 背景点倍数
BACKGROUND_MULTIPLIER = 1
# 背景点生成方法
BACKGROUND_METHOD = 'random'

# ================== 04 数据集划分配置 ==================
# 测试集比例
TEST_SIZE = 0.2
# 随机种子
RANDOM_SEED = 4

# ================== 05 特征堆栈配置 ==================
# 特征名列表输出文件名
FEATURE_COLS_OUT = "feature_cols.joblib"
# 多波段tif文件名
OUTPUT_STACK_TIF = "selected_stack.tif"

# ================== 统一输出目录配置 ==================
# 主输出基础目录
PROCESSED_DATA_BASE_DIR = os.path.join(RESULTS_DIR, "processed_data")

# ================== 新增变量检测和增量合并配置 ==================
# 变量变化检测
ENABLE_VARIABLE_CHANGE_DETECTION = True
# 变量变化日志文件
VARIABLE_CHANGE_LOG = os.path.join(RESULTS_DIR, "variable_change_log.json")
# 备份配置
BACKUP_PREVIOUS_RESULTS = True
BACKUP_DIR = os.path.join(RESULTS_DIR, "backups")
# 增量合并配置
ENABLE_INCREMENTAL_MERGE = True
# all场景的基准目录
ALL_SCENARIO_BASE = os.path.join(ENV_OUTPUT_BASE_DIR, "all")

class VariableChangeDetector:
    """环境变量变化检测和管理类"""
    
    @staticmethod
    def get_current_variables():
        """获取当前环境变量列表"""
        tif_files = glob.glob(os.path.join(ENV_DIR, "*.tif"))
        return sorted([os.path.splitext(os.path.basename(f))[0] for f in tif_files])
    
    @staticmethod
    def load_variable_log():
        """加载变量变化日志"""
        if os.path.exists(VARIABLE_CHANGE_LOG):
            with open(VARIABLE_CHANGE_LOG, 'r', encoding='utf-8') as f:
                return json.load(f)
        return None
    
    @staticmethod
    def save_variable_log(log_data):
        """保存变量变化日志"""
        os.makedirs(os.path.dirname(VARIABLE_CHANGE_LOG), exist_ok=True)
        with open(VARIABLE_CHANGE_LOG, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, indent=2, ensure_ascii=False)
    
    @staticmethod
    def detect_changes():
        """检测环境变量变化"""
        current_vars = VariableChangeDetector.get_current_variables()
        log_data = VariableChangeDetector.load_variable_log()
        
        if log_data is None:
            # 首次运行
            new_log = {
                'timestamp': datetime.now().isoformat(),
                'current_variables': current_vars,
                'previous_variables': [],
                'new_variables': current_vars,
                'removed_variables': [],
                'total_count': len(current_vars),
                'change_history': []
            }
            VariableChangeDetector.save_variable_log(new_log)
            return {
                'has_changes': True,
                'new_variables': current_vars,
                'removed_variables': [],
                'current_variables': current_vars,
                'is_first_run': True
            }
        
        previous_vars = log_data.get('current_variables', [])
        new_vars = list(set(current_vars) - set(previous_vars))
        removed_vars = list(set(previous_vars) - set(current_vars))
        
        if new_vars or removed_vars:
            # 更新日志
            change_entry = {
                'timestamp': datetime.now().isoformat(),
                'new_variables': new_vars,
                'removed_variables': removed_vars,
                'action': 'incremental_merge' if new_vars and not removed_vars else 'full_reprocess'
            }
            
            log_data['previous_variables'] = log_data['current_variables']
            log_data['current_variables'] = current_vars
            log_data['new_variables'] = new_vars
            log_data['removed_variables'] = removed_vars
            log_data['total_count'] = len(current_vars)
            log_data['timestamp'] = datetime.now().isoformat()
            log_data['change_history'].append(change_entry)
            
            VariableChangeDetector.save_variable_log(log_data)
        
        return {
            'has_changes': len(new_vars) > 0 or len(removed_vars) > 0,
            'new_variables': new_vars,
            'removed_variables': removed_vars,
            'current_variables': current_vars,
            'is_first_run': False
        }

def get_all_scenario_paths():
    """获取all场景的路径信息"""
    all_env_dir = os.path.join(ALL_SCENARIO_BASE, "env_variables")
    return {
        'base_dir': ALL_SCENARIO_BASE,
        'env_variables_dir': all_env_dir,
        'original_dir': os.path.join(all_env_dir, "original"),
        'standardized_dir': os.path.join(all_env_dir, "standardized"),
        'selected_stack_tif': os.path.join(all_env_dir, "standardized", OUTPUT_STACK_TIF),
        'feature_cols_joblib': os.path.join(all_env_dir, "standardized", FEATURE_COLS_OUT),
        'variable_info_csv': os.path.join(all_env_dir, "variable_info.csv")
    }

def check_all_scenario_completeness():
    """检查all场景的完整性"""
    paths = get_all_scenario_paths()
    
    required_files = [
        paths['selected_stack_tif'],
        paths['feature_cols_joblib'],
        paths['variable_info_csv']
    ]
    
    missing_files = [f for f in required_files if not os.path.exists(f)]
    
    return {
        'is_complete': len(missing_files) == 0,
        'missing_files': missing_files,
        'paths': paths
    }

def determine_processing_strategy():
    """确定处理策略"""
    # 1. 检测变量变化
    change_info = VariableChangeDetector.detect_changes()
    
    # 2. 检查CSV文件存在性
    print(FEATURES_CSV)
    has_feature_csv = os.path.exists(FEATURES_CSV)
    
    # 3. 检查all场景完整性
    all_scenario_status = check_all_scenario_completeness()
    
    # 4. 决定策略
    if change_info['is_first_run']:
        strategy = 'full_process_all'
        scenario = 'all'
    elif change_info['has_changes']:
        if change_info['removed_variables']:
            # 有变量被移除，需要完全重新处理
            strategy = 'full_reprocess_all'
            scenario = 'all'
        elif change_info['new_variables'] and all_scenario_status['is_complete'] and ENABLE_INCREMENTAL_MERGE:
            # 只有新增变量，且all场景完整，可以增量合并
            strategy = 'incremental_merge'
            scenario = 'all'
        else:
            # 新增变量但all场景不完整，需要完全处理
            strategy = 'full_process_all'
            scenario = 'all'
    else:
        # 无变化，根据CSV文件决定场景
        if has_feature_csv:
            strategy = 'use_selected'
            scenario = 'selected'
        else:
            strategy = 'use_all'
            scenario = 'all'
    
    return {
        'strategy': strategy,
        'scenario': scenario,
        'change_info': change_info,
        'has_feature_csv': has_feature_csv,
        'all_scenario_status': all_scenario_status
    }

