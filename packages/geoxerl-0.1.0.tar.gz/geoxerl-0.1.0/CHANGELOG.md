# Changelog

All notable changes to GeoXERL will be documented here.

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).
Versioning follows [Semantic Versioning](https://semver.org/).

---

## [Unreleased]

### Planned
- Sphinx documentation site
- Additional base model integrations (XGBoost, LightGBM)
- Parallel preprocessing with Dask

---

## [0.1.0] — 2024-XX-XX

### Added
- `data_preprocessing` pipeline: environment variable extraction, presence-point
  processing, background point generation, dataset splitting, and feature-stack
  preparation (steps 00–05).
- `base_models`: configurable model training, batch inference, and evaluation.
- `ensemble`: Bagging, Boosting, Stacking, GWRF, and SHAP-based feature selection
  via RL (`feature_selector_rl2`).
- `threshold_optimization`: Q-Learning and PPO-based threshold optimizers with
  visualizer and analyzer utilities.
- Command-line interface: `geoxerl preprocess | train | ensemble | optimize | run-all`.
- `pyproject.toml`-based packaging; installable via `pip install geoxerl`.
- GitHub Actions CI (multi-OS, Python 3.8–3.11) and automated PyPI publish on tag.

[Unreleased]: https://github.com/YourUsername/GeoXERL/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/YourUsername/GeoXERL/releases/tag/v0.1.0
