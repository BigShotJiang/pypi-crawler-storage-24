import numpy as np
import requests
import json
from submodulo import ayudante

def ejecutar_test():
    """Función de prueba para Curb"""
    print("Iniciando lógica de Nanograd...")
    datos = np.random.rand(10, 10)
    ayudante.saludar()
    return datos.mean()

if __name__ == "__main__":
    print(f"Resultado: {ejecutar_test()}")
