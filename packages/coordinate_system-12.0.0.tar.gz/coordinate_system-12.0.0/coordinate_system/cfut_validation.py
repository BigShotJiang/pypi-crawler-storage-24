"""
CFUT Universal Validation Framework
====================================

A methodology-embedded computation and validation pipeline for the
Complex Frame Unified Theory (CFUT) research program.

This module implements the six-stage research workflow and five-level
evidence grading system defined in the CFUT Research Methodology (v1.1).

Core Design Principles:
    1. Zero-parameter: all predictions use only CFUT constants + direct physical inputs
    2. Control group: every validation compares CFUT vs best traditional formula
    3. Honest reporting: all data points reported, including unfavorable ones
    4. Falsifiability: every prediction states explicit falsification conditions
    5. Boundary awareness: domains must pass the five-dimensional gate check

Usage:
    from coordinate_system.cfut_validation import (
        CFUTConstants, BoundaryCheck, EvidenceLevel,
        ValidationResult, DomainValidator, DynamicStallValidator,
    )

Authors: Pan Guojun
Version: 11.0.0
"""

from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Callable, Dict, List, Optional, Sequence, Tuple


# ============================================================
# CFUT Fundamental Constants (first-principles, from alpha)
# ============================================================

class CFUTConstants:
    """
    CFUT fundamental constants derived from the fine structure constant.

    All values are first-principles or minimal-matching results.
    No fitted parameters.

    Mathematical basis:
        alpha   = 1/137.036           (SM input, irreducible)
        lambda0 = 4 * pi * alpha      (minimal matching, theta=1)
        k_c     = pi * alpha           (= lambda0 / 4)

    Lambda Irreducibility Theorem (2026-03-23):
        lambda is an irreducible free parameter of the two-sector curvature
        formalism. lambda0 = 4*pi*alpha is a minimal matching, not a derivation.
    """

    ALPHA: float = 1.0 / 137.036
    """Fine structure constant (Standard Model input)."""

    LAMBDA0: float = 4.0 * math.pi / 137.036
    """Baseline topological coupling: lambda_0 = 4*pi*alpha ~ 0.09170."""

    K_C: float = math.pi / 137.036
    """Characteristic reduced frequency: k_c = pi*alpha ~ 0.02293."""

    E_REF_EV: float = 0.40
    """Reference energy scale for thermal suppression (eV)."""

    KB_EV_PER_K: float = 8.617333e-5
    """Boltzmann constant in eV/K."""

    @classmethod
    def lambda_eff(cls, T_kelvin: float = 300.0) -> float:
        """
        Effective topological coupling at temperature T.

        Formula: lambda_eff = lambda_0 * exp(-k_B*T / E_ref)

        This is a phenomenological thermal suppression model (A0 level),
        not a theorem-level RG running.

        Args:
            T_kelvin: Temperature in Kelvin.

        Returns:
            Effective coupling lambda_eff.
        """
        kT = cls.KB_EV_PER_K * T_kelvin
        return cls.LAMBDA0 * math.exp(-kT / cls.E_REF_EV)

    @classmethod
    def N_max(cls, delta_alpha_deg: float) -> float:
        """
        Maximum winding number from pitch amplitude (first-principles).

        Formula: N_max = Delta_alpha_rad / (4 * alpha)

        This is a theorem-level (T0) result: the winding number is
        determined by the ratio of the angular excursion to the
        fundamental topological quantum 4*alpha.

        Args:
            delta_alpha_deg: Pitch amplitude in degrees.

        Returns:
            Maximum winding number N_max.
        """
        delta_alpha_rad = math.radians(delta_alpha_deg)
        return delta_alpha_rad / (4.0 * cls.ALPHA)

    @classmethod
    def F_enhancement(cls, k: float, delta_alpha_deg: float,
                      T_kelvin: float = 300.0) -> float:
        """
        Dynamic stall enhancement factor (zero-parameter formula).

        Formula: F(k) = 1 + lambda_eff * N_max * (1 - exp(-k / k_c))

        All parameters from first principles or direct physical inputs.

        Args:
            k: Reduced frequency (dimensionless).
            delta_alpha_deg: Pitch amplitude in degrees.
            T_kelvin: Temperature in Kelvin.

        Returns:
            Enhancement factor F(k) >= 1.
        """
        lam = cls.lambda_eff(T_kelvin)
        n = cls.N_max(delta_alpha_deg)
        saturation = 1.0 - math.exp(-k / cls.K_C)
        return 1.0 + lam * n * saturation

    @classmethod
    def ratio_test_prediction(cls, k1: float, k2: float, k3: float) -> float:
        """
        Ratio test prediction (eliminates N_max and lambda_eff).

        Formula: R = (1 - exp(-k3/k_c)) - (1 - exp(-k1/k_c))
                    / (1 - exp(-k2/k_c)) - (1 - exp(-k1/k_c))

        This is a pure topological test: only k_c = pi*alpha enters.
        No adjustable parameters whatsoever.

        Args:
            k1, k2, k3: Three reduced frequency values.

        Returns:
            Predicted ratio R.
        """
        s1 = 1.0 - math.exp(-k1 / cls.K_C)
        s2 = 1.0 - math.exp(-k2 / cls.K_C)
        s3 = 1.0 - math.exp(-k3 / cls.K_C)
        denom = s2 - s1
        if abs(denom) < 1e-15:
            raise ValueError("k1 and k2 too close: denominator vanishes")
        return (s3 - s1) / denom


# ============================================================
# Five-Dimensional Boundary Gate Check
# ============================================================

class BoundaryStatus(IntEnum):
    """Result of a single boundary check."""
    PASS = 2
    WEAK_PASS = 1
    FAIL = 0


@dataclass(frozen=True)
class BoundaryCheckResult:
    """
    Result of the five-dimensional framework boundary gate check.

    Every new domain must pass this check before entering Stage I.
    B2 (topological complexity) is the hard gate: if it fails,
    the domain is rejected regardless of other boundaries.
    """

    b1_smoothness: BoundaryStatus
    b1_note: str

    b2_topology: BoundaryStatus
    b2_note: str

    b3_eft_truncation: BoundaryStatus
    b3_note: str

    b4_lambda_dependence: BoundaryStatus
    b4_note: str

    b5_observer_separation: BoundaryStatus
    b5_note: str

    @property
    def pass_count(self) -> int:
        """Number of boundaries that pass (PASS or WEAK_PASS)."""
        return sum(1 for s in self.statuses if s >= BoundaryStatus.WEAK_PASS)

    @property
    def statuses(self) -> Tuple[BoundaryStatus, ...]:
        return (self.b1_smoothness, self.b2_topology, self.b3_eft_truncation,
                self.b4_lambda_dependence, self.b5_observer_separation)

    @property
    def admitted(self) -> bool:
        """
        Whether the domain is admitted for CFUT research.

        Rules:
            - B2 FAIL -> rejected (hard gate)
            - 4/5 pass -> admitted
            - <=3/5 pass -> rejected
        """
        if self.b2_topology == BoundaryStatus.FAIL:
            return False
        return self.pass_count >= 4

    @property
    def max_evidence_level(self) -> int:
        """
        Maximum achievable evidence level given boundary status.

        - All PASS: up to Level 5
        - B4 WEAK_PASS: capped at Level 2
        - Any other WEAK_PASS: capped at Level 3
        """
        if all(s == BoundaryStatus.PASS for s in self.statuses):
            return 5
        if self.b4_lambda_dependence == BoundaryStatus.WEAK_PASS:
            return 2
        return 3

    def summary(self) -> str:
        labels = ["B1 Smoothness", "B2 Topology", "B3 EFT",
                  "B4 Lambda", "B5 Observer"]
        notes = [self.b1_note, self.b2_note, self.b3_note,
                 self.b4_note, self.b5_note]
        lines = []
        for label, status, note in zip(labels, self.statuses, notes):
            mark = {2: "PASS", 1: "WEAK", 0: "FAIL"}[status]
            lines.append(f"  [{mark}] {label}: {note}")
        verdict = "ADMITTED" if self.admitted else "REJECTED"
        lines.append(f"  Verdict: {verdict} ({self.pass_count}/5)")
        lines.append(f"  Max evidence level: {self.max_evidence_level}")
        return "\n".join(lines)


def boundary_check(
    b1_smoothness: BoundaryStatus, b1_note: str = "",
    b2_topology: BoundaryStatus = BoundaryStatus.FAIL, b2_note: str = "",
    b3_eft_truncation: BoundaryStatus = BoundaryStatus.PASS, b3_note: str = "",
    b4_lambda_dependence: BoundaryStatus = BoundaryStatus.PASS, b4_note: str = "",
    b5_observer_separation: BoundaryStatus = BoundaryStatus.PASS, b5_note: str = "",
) -> BoundaryCheckResult:
    """
    Perform the five-dimensional framework boundary gate check.

    B2 (topological complexity) defaults to FAIL as a safety measure:
    you must explicitly confirm that N can be defined as an integer.
    """
    return BoundaryCheckResult(
        b1_smoothness=b1_smoothness, b1_note=b1_note,
        b2_topology=b2_topology, b2_note=b2_note,
        b3_eft_truncation=b3_eft_truncation, b3_note=b3_note,
        b4_lambda_dependence=b4_lambda_dependence, b4_note=b4_note,
        b5_observer_separation=b5_observer_separation, b5_note=b5_note,
    )


# ============================================================
# Evidence Grading
# ============================================================

class EvidenceLevel(IntEnum):
    """
    Five-level evidence grading system.

    Level 0: Internal consistency (no data comparison)
    Level 1: Directional consistency (correct sign/order)
    Level 2: Strong compatibility (comparable to traditional, zero-param)
    Level 3: Exclusionary advantage (significantly better OR traditional fails)
    Level 4: Independent replication (Level 3 from independent source)
    Level 5: Cross-domain unification (Level 3+ in 2+ independent domains)
    """
    INTERNAL_CONSISTENCY = 0
    DIRECTIONAL = 1
    STRONG_COMPATIBILITY = 2
    EXCLUSIONARY = 3
    INDEPENDENT_REPLICATION = 4
    CROSS_DOMAIN = 5


@dataclass(frozen=True)
class DataSourceGrade(IntEnum):
    """Data source reliability grading."""
    D1_GOLD = 1       # DOI, peer-reviewed, raw data downloadable
    D2_RELIABLE = 2   # DOI, clear methods
    D3_CAUTION = 3    # No peer review, credible institution
    D4_REFERENCE = 4  # Secondary data only


# ============================================================
# Validation Results
# ============================================================

@dataclass
class PointResult:
    """Single data point comparison result."""
    label: str
    observed: float
    cfut_predicted: float
    classical_predicted: float
    cfut_error_pct: float
    classical_error_pct: float


@dataclass
class ValidationMetrics:
    """Statistical metrics for a validation run."""

    n_points: int
    cfut_mape: float
    classical_mape: float
    cfut_max_error_pct: float
    classical_max_error_pct: float
    cfut_mre: float
    classical_mre: float
    mape_ratio: float  # cfut_mape / classical_mape (< 1 means CFUT better)

    @property
    def cfut_direction_correct(self) -> bool:
        """Whether CFUT predictions have correct sign direction overall."""
        return self.cfut_mape < 100.0  # not wildly wrong

    @property
    def classical_qualitative_failure(self) -> bool:
        """Whether traditional method has qualitative (directional) failure."""
        return self.classical_mape > 30.0

    def auto_grade(self, data_grade: int = 2,
                   boundary: Optional[BoundaryCheckResult] = None) -> EvidenceLevel:
        """
        Automatically assign evidence level based on metrics and data quality.

        Rules (from CFUT Research Methodology):
            Level 3: mape_ratio < 0.5 OR classical qualitative failure,
                     zero params, data >= D2, n >= 3
            Level 2: mape_ratio <= 1.5, zero params, data >= D2, n >= 10
            Level 1: correct direction, n >= 5, data >= D3
            Level 0: otherwise
        """
        max_level = 5
        if boundary is not None:
            max_level = boundary.max_evidence_level

        # Level 3 check
        if (self.n_points >= 3 and data_grade <= 2 and
                (self.mape_ratio < 0.5 or self.classical_qualitative_failure)):
            return EvidenceLevel(min(3, max_level))

        # Level 2 check
        if (self.n_points >= 10 and data_grade <= 2 and
                self.mape_ratio <= 1.5):
            return EvidenceLevel(min(2, max_level))

        # Level 1 check
        if (self.n_points >= 5 and data_grade <= 3 and
                self.cfut_direction_correct):
            return EvidenceLevel(min(1, max_level))

        return EvidenceLevel.INTERNAL_CONSISTENCY


@dataclass
class ValidationResult:
    """
    Complete validation result for a domain.

    Contains all information needed for evidence assessment:
    point-by-point comparison, aggregate metrics, evidence level,
    boundary check, and methodology compliance notes.
    """

    domain_name: str
    cfut_formula: str
    classical_formula: str
    data_source: str
    data_grade: int

    points: List[PointResult]
    metrics: ValidationMetrics
    evidence_level: EvidenceLevel
    boundary_check: Optional[BoundaryCheckResult] = None

    notes: List[str] = field(default_factory=list)
    falsification_condition: str = ""

    def report(self) -> str:
        """Generate a human-readable validation report."""
        lines = [
            f"{'='*60}",
            f"CFUT Validation Report: {self.domain_name}",
            f"{'='*60}",
            f"",
            f"CFUT formula:      {self.cfut_formula}",
            f"Classical formula:  {self.classical_formula}",
            f"Data source:       {self.data_source} (D{self.data_grade})",
            f"",
        ]

        if self.boundary_check:
            lines.append("Boundary Check:")
            lines.append(self.boundary_check.summary())
            lines.append("")

        lines.append("Point-by-point comparison:")
        lines.append(f"{'Label':<20} {'Obs':>10} {'CFUT':>10} {'Class':>10} "
                     f"{'CFUT%':>8} {'Class%':>8}")
        lines.append("-" * 70)
        for p in self.points:
            lines.append(f"{p.label:<20} {p.observed:>10.4f} "
                        f"{p.cfut_predicted:>10.4f} "
                        f"{p.classical_predicted:>10.4f} "
                        f"{p.cfut_error_pct:>+8.2f} "
                        f"{p.classical_error_pct:>+8.2f}")

        lines.extend([
            "",
            "Aggregate Metrics:",
            f"  CFUT MAPE:          {self.metrics.cfut_mape:.4f}%",
            f"  Classical MAPE:     {self.metrics.classical_mape:.4f}%",
            f"  MAPE ratio:         {self.metrics.mape_ratio:.4f} "
            f"({'CFUT better' if self.metrics.mape_ratio < 1 else 'Classical better'})",
            f"  CFUT max error:     {self.metrics.cfut_max_error_pct:+.4f}%",
            f"  Classical max error: {self.metrics.classical_max_error_pct:+.4f}%",
            f"  n points:           {self.metrics.n_points}",
            "",
            f"Evidence Level: {self.evidence_level.name} "
            f"(Level {self.evidence_level.value})",
        ])

        if self.falsification_condition:
            lines.append(f"Falsification: {self.falsification_condition}")

        if self.notes:
            lines.append("")
            lines.append("Notes:")
            for note in self.notes:
                lines.append(f"  - {note}")

        lines.append(f"{'='*60}")
        return "\n".join(lines)


# ============================================================
# Domain Validator Base Class
# ============================================================

class DomainValidator(ABC):
    """
    Abstract base class for domain-specific CFUT validators.

    To validate CFUT in a new domain:
    1. Subclass DomainValidator
    2. Implement cfut_predict() and classical_predict()
    3. Provide data via add_point()
    4. Call validate() to run the comparison

    The methodology is embedded in the base class:
    - Zero-parameter enforcement (cfut_predict must not use fitted params)
    - Automatic metrics computation
    - Automatic evidence grading
    - Honest full-dataset reporting
    """

    def __init__(self, domain_name: str, cfut_formula: str,
                 classical_formula: str, data_source: str,
                 data_grade: int = 2,
                 boundary: Optional[BoundaryCheckResult] = None):
        self.domain_name = domain_name
        self.cfut_formula = cfut_formula
        self.classical_formula = classical_formula
        self.data_source = data_source
        self.data_grade = data_grade
        self.boundary = boundary
        self._data: List[Tuple[str, float, dict]] = []
        self._notes: List[str] = []
        self._falsification = ""

    def add_point(self, label: str, observed: float, **params) -> None:
        """
        Add a data point for validation.

        Args:
            label: Human-readable label for this point.
            observed: Observed/measured value.
            **params: Physical parameters needed by predict functions.
        """
        self._data.append((label, observed, params))

    def add_note(self, note: str) -> None:
        """Add a methodology note to the report."""
        self._notes.append(note)

    def set_falsification(self, condition: str) -> None:
        """Set the falsification condition for this domain."""
        self._falsification = condition

    @abstractmethod
    def cfut_predict(self, **params) -> float:
        """
        CFUT prediction for a single data point.

        MUST use only CFUTConstants and direct physical inputs.
        MUST NOT use any fitted parameters.
        """
        ...

    @abstractmethod
    def classical_predict(self, **params) -> float:
        """
        Best traditional formula prediction for the same data point.

        Used as control group for comparison.
        """
        ...

    def validate(self) -> ValidationResult:
        """
        Run the full validation pipeline.

        Returns a complete ValidationResult with point-by-point comparison,
        aggregate metrics, and automatic evidence grading.
        """
        if not self._data:
            raise ValueError("No data points added. Use add_point() first.")

        if self.boundary and not self.boundary.admitted:
            raise ValueError(
                f"Domain '{self.domain_name}' failed boundary check:\n"
                f"{self.boundary.summary()}\n"
                "Cannot validate a domain outside CFUT's effective region."
            )

        points = []
        for label, obs, params in self._data:
            cfut = self.cfut_predict(**params)
            classical = self.classical_predict(**params)

            cfut_err = (cfut - obs) / abs(obs) * 100.0 if obs != 0 else 0.0
            class_err = (classical - obs) / abs(obs) * 100.0 if obs != 0 else 0.0

            points.append(PointResult(
                label=label, observed=obs,
                cfut_predicted=cfut, classical_predicted=classical,
                cfut_error_pct=cfut_err, classical_error_pct=class_err,
            ))

        # Compute aggregate metrics
        n = len(points)
        cfut_apes = [abs(p.cfut_error_pct) for p in points]
        class_apes = [abs(p.classical_error_pct) for p in points]

        cfut_mape = sum(cfut_apes) / n
        class_mape = sum(class_apes) / n
        cfut_mre = sum(p.cfut_error_pct for p in points) / n
        class_mre = sum(p.classical_error_pct for p in points) / n
        mape_ratio = cfut_mape / class_mape if class_mape > 0 else float('inf')

        metrics = ValidationMetrics(
            n_points=n,
            cfut_mape=cfut_mape,
            classical_mape=class_mape,
            cfut_max_error_pct=max(cfut_apes),
            classical_max_error_pct=max(class_apes),
            cfut_mre=cfut_mre,
            classical_mre=class_mre,
            mape_ratio=mape_ratio,
        )

        level = metrics.auto_grade(self.data_grade, self.boundary)

        return ValidationResult(
            domain_name=self.domain_name,
            cfut_formula=self.cfut_formula,
            classical_formula=self.classical_formula,
            data_source=self.data_source,
            data_grade=self.data_grade,
            points=points,
            metrics=metrics,
            evidence_level=level,
            boundary_check=self.boundary,
            notes=self._notes,
            falsification_condition=self._falsification,
        )


# ============================================================
# Reference Implementation: Dynamic Stall Validator
# ============================================================

class DynamicStallValidator(DomainValidator):
    """
    Reference validator for the dynamic stall domain.

    This is CFUT's strongest evidence domain (Level 3).
    It demonstrates the standard validation workflow.

    CFUT formula:
        F(k) = 1 + lambda_eff * N_max * (1 - exp(-k / k_c))
        N_max = delta_alpha_rad / (4 * alpha)
        k_c = pi * alpha
        lambda_eff = lambda_0 * exp(-kT / E_ref)

    Classical control:
        Theodorsen function |C(k)| (always < 1 for k > 0)

    Boundary check: 5/5 PASS
    """

    def __init__(self, data_source: str = "UAD-ODS CENER NACA64418",
                 data_grade: int = 1):
        bc = boundary_check(
            b1_smoothness=BoundaryStatus.PASS,
            b1_note="Continuum fluid mechanics on smooth manifold",
            b2_topology=BoundaryStatus.PASS,
            b2_note="N = delta_alpha / (4*alpha), integer winding from pitch oscillation",
            b3_eft_truncation=BoundaryStatus.PASS,
            b3_note="Classical energy scale, weak topological correction",
            b4_lambda_dependence=BoundaryStatus.PASS,
            b4_note="Ratio test eliminates lambda; F(k) uses lambda_eff from first principles",
            b5_observer_separation=BoundaryStatus.PASS,
            b5_note="Wind tunnel experimenter fully external to airfoil system",
        )
        super().__init__(
            domain_name="Dynamic Stall",
            cfut_formula="F(k) = 1 + lambda_eff * N_max * (1 - exp(-k/k_c))",
            classical_formula="Theodorsen |C(k)|",
            data_source=data_source,
            data_grade=data_grade,
            boundary=bc,
        )
        self.set_falsification(
            "If k_c ratio test error exceeds 5%, or if F_obs < 1 for any "
            "trailing-edge stall airfoil in dynamic oscillation, the formula "
            "is falsified."
        )

    def cfut_predict(self, *, k: float, delta_alpha_deg: float,
                     T_kelvin: float = 300.0, **_kw) -> float:
        """CFUT dynamic stall enhancement factor F(k)."""
        return CFUTConstants.F_enhancement(k, delta_alpha_deg, T_kelvin)

    def classical_predict(self, *, k: float, **_kw) -> float:
        """
        Theodorsen function magnitude |C(k)| (classical unsteady aerodynamics).

        C(k) = H1(k) / (H1(k) + i*H0(k))
        where H0, H1 are Hankel functions of the second kind.

        For large k: |C(k)| -> 0.5
        For k -> 0: |C(k)| -> 1.0
        Always |C(k)| <= 1.0 (predicts reduction, not enhancement).
        """
        # Approximation (Schlichting & Truckenbrodt)
        if k <= 0:
            return 1.0
        return 1.0 / math.sqrt(1.0 + (math.pi * k) ** 2) * (
            1.0 + 0.5 * math.pi * k / math.sqrt(1.0 + (math.pi * k) ** 2)
        )


# ============================================================
# Ratio Test (standalone utility)
# ============================================================

@dataclass(frozen=True)
class RatioTestResult:
    """
    Result of the k_c = pi*alpha ratio test.

    This test eliminates N_max and lambda_eff entirely,
    testing only the pure topological constraint k_c = pi*alpha.
    """

    k_values: Tuple[float, float, float]
    R_observed: float
    R_predicted: float
    error_pct: float
    k_c_predicted: float
    k_c_best_fit: Optional[float] = None
    k_c_deviation_pct: Optional[float] = None


def dynamic_stall_ratio_test(
    k1: float, k2: float, k3: float,
    N_obs_k1: float, N_obs_k2: float, N_obs_k3: float,
) -> RatioTestResult:
    """
    Perform the dynamic stall k_c ratio test.

    This is CFUT's strongest single validation result:
    it eliminates N_max and lambda_eff, testing ONLY k_c = pi*alpha.

    Formula:
        R_obs  = (N(k3) - N(k1)) / (N(k2) - N(k1))
        R_pred = (sat(k3) - sat(k1)) / (sat(k2) - sat(k1))
        where sat(k) = 1 - exp(-k / k_c), k_c = pi*alpha

    Args:
        k1, k2, k3: Three reduced frequency values.
        N_obs_k1, N_obs_k2, N_obs_k3: Observed N values at each k.

    Returns:
        RatioTestResult with observed vs predicted ratio and error.
    """
    denom_obs = N_obs_k2 - N_obs_k1
    if abs(denom_obs) < 1e-15:
        raise ValueError("N(k2) ~ N(k1): denominator too small")

    R_obs = (N_obs_k3 - N_obs_k1) / denom_obs
    R_pred = CFUTConstants.ratio_test_prediction(k1, k2, k3)
    err = (R_pred - R_obs) / R_obs * 100.0

    # Find best-fit k_c by bisection
    def ratio_at_kc(kc: float) -> float:
        s1 = 1.0 - math.exp(-k1 / kc)
        s2 = 1.0 - math.exp(-k2 / kc)
        s3 = 1.0 - math.exp(-k3 / kc)
        d = s2 - s1
        return (s3 - s1) / d if abs(d) > 1e-15 else float('inf')

    kc_lo, kc_hi = 0.005, 0.5
    for _ in range(80):
        kc_mid = (kc_lo + kc_hi) / 2.0
        r_mid = ratio_at_kc(kc_mid)
        if abs(r_mid - R_obs) < 1e-12:
            break
        if r_mid < R_obs:
            kc_lo = kc_mid
        else:
            kc_hi = kc_mid

    kc_best = (kc_lo + kc_hi) / 2.0
    kc_dev = (kc_best - CFUTConstants.K_C) / CFUTConstants.K_C * 100.0

    return RatioTestResult(
        k_values=(k1, k2, k3),
        R_observed=R_obs,
        R_predicted=R_pred,
        error_pct=err,
        k_c_predicted=CFUTConstants.K_C,
        k_c_best_fit=kc_best,
        k_c_deviation_pct=kc_dev,
    )


# ============================================================
# Winding Number Registry (for cross-domain tracking)
# ============================================================

@dataclass(frozen=True)
class WindingNumberDefinition:
    """
    Registry entry for a domain-specific winding number definition.

    The winding number N is the central operational object of CFUT research.
    Each domain must define N precisely before any validation.
    """
    domain: str
    formula: str
    physical_meaning: str
    homotopy_class: str  # e.g., "pi_1", "Chern number", etc.
    verified: bool
    evidence_level: int


WINDING_NUMBER_REGISTRY: Dict[str, WindingNumberDefinition] = {
    "dynamic_stall": WindingNumberDefinition(
        domain="Dynamic Stall",
        formula="N_max = Delta_alpha_rad / (4 * alpha)",
        physical_meaning="Number of topological quanta in pitch oscillation amplitude",
        homotopy_class="pi_1 (loop winding in angle parameter space)",
        verified=True,
        evidence_level=3,
    ),
    "qhe": WindingNumberDefinition(
        domain="Quantum Hall Effect",
        formula="N = Chern number (first Chern class of Berry bundle)",
        physical_meaning="Topologically quantized Hall conductance",
        homotopy_class="c_1 (first Chern number)",
        verified=True,
        evidence_level=1,
    ),
}


# ============================================================
# Public API
# ============================================================

__all__ = [
    # Constants
    "CFUTConstants",

    # Boundary check
    "BoundaryStatus",
    "BoundaryCheckResult",
    "boundary_check",

    # Evidence grading
    "EvidenceLevel",
    "DataSourceGrade",

    # Validation results
    "PointResult",
    "ValidationMetrics",
    "ValidationResult",

    # Domain validators
    "DomainValidator",
    "DynamicStallValidator",

    # Ratio test
    "RatioTestResult",
    "dynamic_stall_ratio_test",

    # Winding number registry
    "WindingNumberDefinition",
    "WINDING_NUMBER_REGISTRY",
]
