"""
CFUT layer.

This is the system-level theory entry that sits between CCS geometry and
application-facing topological physics. It collects:
    - CFUT constants and validation helpers
    - complex frame and gauge objects
    - complex frame field and curvature / CS-flow packaging
    - unified two-sector state construction
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional, Sequence

from .cfut_validation import (
    BoundaryCheckResult,
    BoundaryStatus,
    CFUTConstants,
    DomainValidator,
    DynamicStallValidator,
    EvidenceLevel,
    PointResult,
    RatioTestResult,
    ValidationMetrics,
    ValidationResult,
    WindingNumberDefinition,
    WINDING_NUMBER_REGISTRY,
    boundary_check,
    dynamic_stall_ratio_test,
)
from .complex_frame import (
    ComplexFrame,
    FieldStrength,
    GaugeConnection,
    SU3Component,
    SymmetryBreakingPotential,
)
from .complex_frame_theory import (
    ComplexCurvaturePackage,
    ComplexFrameField,
    TopologicalFlowPackage,
)
from .unified_topological_physics import (
    DarkMatterSectorPackage,
    LambdaSectorPackage,
    LoopObservables,
    TwoSectorPackage,
    UnifiedTopologicalState,
    compute_cs_term,
    build_dark_matter_sector_package,
    build_lambda_sector_package,
    build_loop_observables,
    build_two_sector_package,
    build_unified_topological_state,
)


@dataclass(frozen=True)
class CFUT:
    """
    Physical wrapper for CFUT-level workflows.

    Mathematical objects such as `ComplexFrame` and `ComplexFrameField` remain
    independent classes. This wrapper packages the common theory-level calls.
    """

    planck_mass: float = 1.0
    topo_lambda: float = 1.0
    gauge_weight: float = 1.0
    theta: float = 1.0
    energy_ev: float = 0.026
    running_beta: Optional[float] = None

    def check_boundary(self, **kwargs) -> BoundaryCheckResult:
        return boundary_check(**kwargs)

    def ratio_test(
        self,
        k1: float,
        k2: float,
        k3: float,
        n_obs_k1: float,
        n_obs_k2: float,
        n_obs_k3: float,
    ) -> RatioTestResult:
        return dynamic_stall_ratio_test(k1, k2, k3, n_obs_k1, n_obs_k2, n_obs_k3)

    def lambda_sector(self) -> LambdaSectorPackage:
        return build_lambda_sector_package(
            theta=self.theta,
            energy_ev=self.energy_ev,
            running_beta=self.running_beta,
        )

    def dark_matter_sector(self, target_masses_GeV: Sequence[float]) -> DarkMatterSectorPackage:
        return build_dark_matter_sector_package(target_masses_GeV)

    def loop_observables(self, field: ComplexFrameField, x: Iterable[float]) -> LoopObservables:
        return build_loop_observables(field, x)

    def cs_term(self, field: ComplexFrameField, x: Iterable[float]):
        return compute_cs_term(field, x, topo_lambda=self.topo_lambda)

    def two_sector(self, field: ComplexFrameField, x: Iterable[float]) -> TwoSectorPackage:
        return build_two_sector_package(
            field,
            x,
            planck_mass=self.planck_mass,
            topo_lambda=self.topo_lambda,
            gauge_weight=self.gauge_weight,
        )

    def state(self, field: ComplexFrameField, x: Iterable[float], **kwargs) -> UnifiedTopologicalState:
        return build_unified_topological_state(
            field,
            x,
            planck_mass=self.planck_mass,
            topo_lambda=self.topo_lambda,
            gauge_weight=self.gauge_weight,
            theta=self.theta,
            energy_ev=self.energy_ev,
            running_beta=self.running_beta,
            **kwargs,
        )


__all__ = [
    "CFUT",
    "CFUTConstants",
    "BoundaryStatus",
    "BoundaryCheckResult",
    "boundary_check",
    "EvidenceLevel",
    "PointResult",
    "ValidationMetrics",
    "ValidationResult",
    "DomainValidator",
    "DynamicStallValidator",
    "RatioTestResult",
    "dynamic_stall_ratio_test",
    "WindingNumberDefinition",
    "WINDING_NUMBER_REGISTRY",
    "ComplexFrame",
    "SU3Component",
    "GaugeConnection",
    "FieldStrength",
    "SymmetryBreakingPotential",
    "ComplexCurvaturePackage",
    "ComplexFrameField",
    "TopologicalFlowPackage",
    "LoopObservables",
    "LambdaSectorPackage",
    "DarkMatterSectorPackage",
    "TwoSectorPackage",
    "UnifiedTopologicalState",
    "compute_cs_term",
    "build_loop_observables",
    "build_lambda_sector_package",
    "build_dark_matter_sector_package",
    "build_two_sector_package",
    "build_unified_topological_state",
]
