"""
CCS layer: computable coordinate systems and differential geometry.

This module is the stable front door for the geometry side of the library.
The user asked to keep CCS usage unchanged, so the canonical geometry APIs
remain available from the package root as well.
"""

from __future__ import annotations

from dataclasses import dataclass

from .coordinate_system import (
    coord3,
    cross,
    cross_right,
    get_handedness,
    is_left_handed,
    is_right_handed,
    quat,
    set_handedness,
    vec2,
    vec3,
)
from .differential_geometry import (
    CCSGeometryPackage,
    CurvatureCalculator,
    GradientResult,
    IntrinsicGradientCurvatureCalculator,
    IntrinsicGradientOperator,
    LieGroupCurvatureCalculator,
    MetricTensor,
    Sphere,
    Surface,
    Torus,
    all_curvatures,
    all_curvatures_classical,
    compare_methods,
    compute_all_curvatures,
    compute_ccs_geometry_package,
    compute_connection_matrices,
    compute_curvature_tensor,
    compute_gaussian_curvature,
    compute_intrinsic_gradient,
    compute_mean_curvature,
    compute_riemann_curvature,
    derivative_2nd_5pt,
    derivative_5pt,
    gaussian_curvature,
    gaussian_curvature_classical,
    gaussian_curvature_lie,
    intrinsic_gradient_all_curvatures,
    intrinsic_gradient_gaussian_curvature,
    intrinsic_gradient_mean_curvature,
    intrinsic_gradient_principal_curvatures,
    mean_curvature,
    mean_curvature_classical,
    principal_curvatures,
    principal_curvatures_classical,
    richardson_extrapolation,
)


@dataclass(frozen=True)
class CCS:
    """
    Physical wrapper for CCS geometry workflows.

    The underlying mathematical objects remain the standalone geometry classes
    and functions. This wrapper only organizes common physical-geometry calls.
    """

    step_size: float = 1.0e-4

    def geometry_package(self, surface: Surface, u: float, v: float) -> CCSGeometryPackage:
        return compute_ccs_geometry_package(surface, u, v, step_size=self.step_size)

    def gaussian(self, surface: Surface, u: float, v: float) -> float:
        return compute_gaussian_curvature(surface, u, v, step_size=self.step_size)

    def mean(self, surface: Surface, u: float, v: float) -> float:
        return compute_mean_curvature(surface, u, v, step_size=self.step_size)

    def riemann(self, surface: Surface, u: float, v: float) -> float:
        return compute_riemann_curvature(surface, u, v, step_size=self.step_size)

    def connection_matrices(self, surface: Surface, u: float, v: float):
        return compute_connection_matrices(surface, u, v, step_size=self.step_size)

    def curvature_tensor(self, surface: Surface, u: float, v: float):
        return compute_curvature_tensor(surface, u, v, step_size=self.step_size)


__all__ = [
    "CCS",
    "vec3",
    "vec2",
    "quat",
    "coord3",
    "cross",
    "cross_right",
    "set_handedness",
    "get_handedness",
    "is_left_handed",
    "is_right_handed",
    "Surface",
    "Sphere",
    "Torus",
    "MetricTensor",
    "GradientResult",
    "CCSGeometryPackage",
    "IntrinsicGradientOperator",
    "IntrinsicGradientCurvatureCalculator",
    "LieGroupCurvatureCalculator",
    "CurvatureCalculator",
    "compute_gaussian_curvature",
    "compute_mean_curvature",
    "compute_riemann_curvature",
    "compute_curvature_tensor",
    "compute_all_curvatures",
    "compute_intrinsic_gradient",
    "compute_ccs_geometry_package",
    "compute_connection_matrices",
    "intrinsic_gradient_gaussian_curvature",
    "intrinsic_gradient_mean_curvature",
    "intrinsic_gradient_principal_curvatures",
    "intrinsic_gradient_all_curvatures",
    "gaussian_curvature_classical",
    "mean_curvature_classical",
    "principal_curvatures_classical",
    "all_curvatures_classical",
    "gaussian_curvature",
    "mean_curvature",
    "principal_curvatures",
    "all_curvatures",
    "compare_methods",
    "gaussian_curvature_lie",
    "derivative_5pt",
    "derivative_2nd_5pt",
    "richardson_extrapolation",
]
