"""
Differential Geometry Module
============================

Comprehensive discrete differential geometry computations on surfaces,
combining classical methods and intrinsic gradient operator framework.

Key Features:
- Surface parametrization (Sphere, Torus, custom surfaces)
- Metric tensor computation
- Intrinsic gradient operator for curvature calculation
- Classical curvature methods with high-order finite differences
- Gaussian, mean, principal, and Riemann curvatures

**Authors:** Pan Guojun
Date: 2025-12-03
**DOI:** https://doi.org/10.5281/zenodo.14435613
"""

import math
import weakref
from dataclasses import dataclass
import numpy as np
from typing import Tuple, Optional, Callable, Union, Dict, List
from .coordinate_system import coord3, vec3


# ============================================================
# High-Order Finite Difference Operators
# ============================================================

def _safe_normal_from_tangents(r_u: vec3, r_v: vec3) -> vec3:
    """Compute a stable unit normal using right-handed cross when available."""
    if hasattr(r_u, "cross_right"):
        n = r_u.cross_right(r_v)
    else:
        n = r_u.cross(r_v)
    length = (n.x**2 + n.y**2 + n.z**2) ** 0.5
    if length > 1e-10:
        return n * (1.0 / length)
    return vec3(0.0, 0.0, 1.0)


def _dot_vec3(a: vec3, b: vec3) -> float:
    """Small helper for vec3 inner products."""
    return a.x * b.x + a.y * b.y + a.z * b.z


def _orthonormal_tangent_frame(r_u: vec3, r_v: vec3) -> Tuple[vec3, vec3, vec3]:
    """
    Build an orthonormal adapted tangent-normal frame from two tangent vectors.

    This is the theorem-aligned default gauge used by the strengthened CCS paper:
    e1 follows the first tangent direction, e2 is orthogonalized inside the
    tangent plane, and e3 is the induced unit normal.
    """
    e1 = r_u.normalized()
    proj = _dot_vec3(r_v, e1)
    v2 = r_v - e1 * proj
    v2_len2 = v2.x * v2.x + v2.y * v2.y + v2.z * v2.z
    if v2_len2 <= 1e-20:
        n = _safe_normal_from_tangents(r_u, r_v)
        if abs(e1.x) < 0.9:
            trial = vec3(1.0, 0.0, 0.0)
        else:
            trial = vec3(0.0, 1.0, 0.0)
        v2 = trial - e1 * _dot_vec3(trial, e1)
        v2_len2 = v2.x * v2.x + v2.y * v2.y + v2.z * v2.z
        if v2_len2 <= 1e-20:
            v2 = n.cross(e1) if hasattr(n, "cross") else vec3(0.0, 1.0, 0.0)
    e2 = v2.normalized()
    n = _safe_normal_from_tangents(e1, e2)
    return e1, e2, n


def derivative_5pt(f: Callable[[float], np.ndarray], x: float, h: float) -> np.ndarray:
    """
    5-point finite difference formula for first derivative.

    Accuracy: O(h^4)

    Args:
        f: Function to differentiate
        x: Point at which to compute derivative
        h: Step size

    Returns:
        First derivative approximation
    """
    return (-f(x + 2*h) + 8*f(x + h) - 8*f(x - h) + f(x - 2*h)) / (12*h)


def derivative_2nd_5pt(f: Callable[[float], np.ndarray], x: float, h: float) -> np.ndarray:
    """
    5-point finite difference formula for second derivative.

    Accuracy: O(h^4)

    Args:
        f: Function to differentiate
        x: Point at which to compute derivative
        h: Step size

    Returns:
        Second derivative approximation
    """
    return (-f(x + 2*h) + 16*f(x + h) - 30*f(x) + 16*f(x - h) - f(x - 2*h)) / (12*h*h)


def richardson_extrapolation(f_h: float, f_2h: float, order: int = 4) -> float:
    """
    Richardson extrapolation for accelerating convergence.

    Args:
        f_h: Value computed with step size h
        f_2h: Value computed with step size 2h
        order: Order of the method

    Returns:
        Extrapolated value with improved accuracy
    """
    return (2**order * f_h - f_2h) / (2**order - 1)


# ============================================================
# Surface Base Class and Common Surfaces
# ============================================================

class Surface:
    """
    Base class for parametric surfaces r(u, v).

    Subclasses must implement the position(u, v) method.
    """

    def __init__(self, h: float = 1e-6):
        """
        Initialize surface.

        Args:
            h: Step size for numerical differentiation
        """
        self.h = h

    def position(self, u: float, v: float) -> vec3:
        """
        Compute position on surface at parameters (u, v).

        Must be implemented by subclasses.
        """
        raise NotImplementedError("Subclass must implement position(u, v)")

    def tangent_u(self, u: float, v: float) -> vec3:
        """Compute tangent vector in u direction using central difference."""
        r_plus = self.position(u + self.h, v)
        r_minus = self.position(u - self.h, v)
        return (r_plus - r_minus) * (1.0 / (2.0 * self.h))

    def tangent_v(self, u: float, v: float) -> vec3:
        """Compute tangent vector in v direction using central difference."""
        r_plus = self.position(u, v + self.h)
        r_minus = self.position(u, v - self.h)
        return (r_plus - r_minus) * (1.0 / (2.0 * self.h))

    def normal(self, u: float, v: float) -> vec3:
        """Compute unit normal vector."""
        r_u = self.tangent_u(u, v)
        r_v = self.tangent_v(u, v)
        return _safe_normal_from_tangents(r_u, r_v)

    @property
    def normal_is_outward(self) -> bool:
        """Whether r_u × r_v gives the outward-pointing normal.

        Most parametrizations give an inward normal by convention; override
        this to True in subclasses where the cross product is known to be
        outward-pointing (e.g. standard spherical coordinates).
        """
        return False


class Sphere(Surface):
    """
    Sphere surface.

    Parametrization: r(theta, phi) = R(sin(theta)cos(phi), sin(theta)sin(phi), cos(theta))
    where theta in [0, pi] is polar angle, phi in [0, 2*pi] is azimuthal angle.

    Theoretical curvatures:
    - Gaussian curvature: K = 1/R^2
    - Mean curvature: H = 1/R
    """

    def __init__(self, radius: float = 1.0, h: float = 1e-6):
        super().__init__(h)
        self.R = radius

    def position(self, theta: float, phi: float) -> vec3:
        """Position on sphere."""
        x = self.R * math.sin(theta) * math.cos(phi)
        y = self.R * math.sin(theta) * math.sin(phi)
        z = self.R * math.cos(theta)
        return vec3(x, y, z)

    @property
    def normal_is_outward(self) -> bool:
        """Standard spherical r_θ×r_φ gives the outward (radial) normal."""
        return True

    @property
    def theoretical_gaussian_curvature(self) -> float:
        """Theoretical Gaussian curvature K = 1/R^2."""
        return 1.0 / (self.R * self.R)

    @property
    def theoretical_mean_curvature(self) -> float:
        """Theoretical mean curvature H = 1/R."""
        return 1.0 / self.R


class Torus(Surface):
    """
    Torus surface.

    Parametrization: r(u, v) = ((R + r*cos(u))*cos(v), (R + r*cos(u))*sin(v), r*sin(u))
    where R is major radius, r is minor radius.

    Theoretical curvatures:
    - Gaussian curvature: K = cos(u) / (r * (R + r*cos(u)))
    - Mean curvature: H = (R + 2*r*cos(u)) / (2*r*(R + r*cos(u)))
    """

    def __init__(self, major_radius: float = 3.0, minor_radius: float = 1.0, h: float = 1e-6):
        super().__init__(h)
        self.R = major_radius
        self.r = minor_radius

    def position(self, u: float, v: float) -> vec3:
        """Position on torus."""
        x = (self.R + self.r * math.cos(u)) * math.cos(v)
        y = (self.R + self.r * math.cos(u)) * math.sin(v)
        z = self.r * math.sin(u)
        return vec3(x, y, z)

    def theoretical_gaussian_curvature(self, u: float) -> float:
        """Theoretical Gaussian curvature at parameter u."""
        return math.cos(u) / (self.r * (self.R + self.r * math.cos(u)))

    def theoretical_mean_curvature(self, u: float) -> float:
        """Theoretical mean curvature at parameter u."""
        return (self.R + 2 * self.r * math.cos(u)) / (2 * self.r * (self.R + self.r * math.cos(u)))


# ============================================================
# Metric Tensor
# ============================================================

class MetricTensor:
    """
    First fundamental form (metric tensor) of a surface.

    g_ij = <dr/du^i, dr/du^j>

    Components:
    - E = g_11 = <r_u, r_u>
    - F = g_12 = <r_u, r_v>
    - G = g_22 = <r_v, r_v>
    """

    def __init__(self, E: float, F: float, G: float):
        """
        Initialize metric tensor.

        Args:
            E: g_11 = <r_u, r_u>
            F: g_12 = <r_u, r_v>
            G: g_22 = <r_v, r_v>
        """
        self.E = E
        self.F = F
        self.G = G
        self.det = E * G - F * F

    @classmethod
    def from_surface(cls, surface: Surface, u: float, v: float) -> 'MetricTensor':
        """Create metric tensor from surface at point (u, v)."""
        r_u = surface.tangent_u(u, v)
        r_v = surface.tangent_v(u, v)
        E = r_u.dot(r_u)
        F = r_u.dot(r_v)
        G = r_v.dot(r_v)
        return cls(E, F, G)

    def determinant(self) -> float:
        """Get determinant of metric tensor."""
        return self.det

    def inverse(self) -> np.ndarray:
        """Get inverse metric tensor as numpy array."""
        if abs(self.det) < 1e-14:
            return np.eye(2)
        return np.array([[self.G, -self.F], [-self.F, self.E]]) / self.det

    def as_matrix(self) -> np.ndarray:
        """Get metric tensor as numpy array."""
        return np.array([[self.E, self.F], [self.F, self.G]])

    def __repr__(self) -> str:
        return f"MetricTensor(E={self.E:.6f}, F={self.F:.6f}, G={self.G:.6f}, det={self.det:.6f})"


# ============================================================
# Gradient Result
# ============================================================

class GradientResult:
    """
    Gradient result containing normal vector derivative.
    """

    def __init__(self, dn: vec3, direction: str):
        """
        Initialize gradient result.

        Args:
            dn: Normal vector derivative
            direction: Parameter direction ('u' or 'v')
        """
        self.dn = dn
        self.direction = direction

    def __repr__(self) -> str:
        return f"GradientResult({self.direction}: [{self.dn.x:.6f}, {self.dn.y:.6f}, {self.dn.z:.6f}])"


@dataclass
class CCSGeometryPackage:
    """
    Structured geometry package aligned with the CCS theorem chain.

    The package separates:
    - the software-level CCS object (`center_frame`)
    - the full right-trivialized finite-difference variation (`G_u`, `G_v`)
    - the recovered local geometric data (`g`, `h`, `S`, `K`, `H`, `k1`, `k2`)

    This makes the library easier to use as an implementation counterpart to the
    CCS frame paper, where the induced geometry is recovered from a coordinate
    system object rather than from a component-first tensor pipeline alone.
    """
    center_frame: coord3
    G_u: object
    G_v: object
    g: np.ndarray
    h: np.ndarray
    S: np.ndarray
    K: float
    H: float
    k1: float
    k2: float
    normal: np.ndarray
    riemann_1212: float

    def as_dict(self) -> Dict[str, Union[float, np.ndarray, object]]:
        """Return a backward-compatible dictionary view."""
        return {
            'center_frame': self.center_frame,
            'G_u': self.G_u,
            'G_v': self.G_v,
            'g': self.g,
            'h': self.h,
            'S': self.S,
            'K': self.K,
            'H': self.H,
            'k1': self.k1,
            'k2': self.k2,
            'n': self.normal,
            'R_1212': self.riemann_1212,
            'gaussian_curvature': self.K,
            'mean_curvature': self.H,
            'principal_curvatures': (self.k1, self.k2),
        }


# ============================================================
# Intrinsic Gradient Operator
# ============================================================

class IntrinsicGradientOperator:
    """
    Intrinsic gradient operator implementation.

    Key formula:
        G_mu = (c(u+h) - c(u-h)) / (2h) / c(u)
    Then extract normal derivative using .VZ()
    """

    def __init__(self, surface: Surface, step_size: float = 1e-3):
        self.surface = surface
        self.h = step_size

    def calc_intrinsic_frame(self, u: float, v: float) -> coord3:
        """
        Calculate intrinsic frame at point (u, v).

        For Sphere and Torus, uses analytical expressions.
        For other surfaces, uses numerical derivatives.
        """
        if isinstance(self.surface, Sphere):
            R = self.surface.R
            theta, phi = u, v

            pos = self.surface.position(theta, phi)

            # Analytical tangent vectors
            r_theta = vec3(
                R * math.cos(theta) * math.cos(phi),
                R * math.cos(theta) * math.sin(phi),
                -R * math.sin(theta)
            )
            r_phi = vec3(
                -R * math.sin(theta) * math.sin(phi),
                R * math.sin(theta) * math.cos(phi),
                0
            )

            e1, e2, n = _orthonormal_tangent_frame(r_theta, r_phi)
        elif isinstance(self.surface, Torus):
            R = self.surface.R
            r = self.surface.r
            u_param, v_param = u, v

            pos = self.surface.position(u_param, v_param)

            # Analytical tangent vectors
            r_u = vec3(
                -r * math.sin(u_param) * math.cos(v_param),
                -r * math.sin(u_param) * math.sin(v_param),
                r * math.cos(u_param)
            )
            r_v = vec3(
                -(R + r * math.cos(u_param)) * math.sin(v_param),
                (R + r * math.cos(u_param)) * math.cos(v_param),
                0
            )

            e1, e2, n = _orthonormal_tangent_frame(r_u, r_v)
        else:
            # Numerical method for general surfaces
            pos = self.surface.position(u, v)
            r_u = None
            r_v = None
            if hasattr(self.surface, "derivs"):
                try:
                    derivs = self.surface.derivs(u, v)
                    if isinstance(derivs, (list, tuple)) and len(derivs) >= 2:
                        cand_u, cand_v = derivs[0], derivs[1]
                        if isinstance(cand_u, vec3) and isinstance(cand_v, vec3):
                            r_u, r_v = cand_u, cand_v
                except Exception:
                    r_u = None
                    r_v = None
            if r_u is None or r_v is None:
                r_u = self.surface.tangent_u(u, v)
                r_v = self.surface.tangent_v(u, v)

            e1, e2, n = _orthonormal_tangent_frame(r_u, r_v)
        # Create intrinsic frame
        frame = coord3()
        frame.o = pos
        frame.ux = e1
        frame.uy = e2
        frame.uz = n
        return frame

    def compute_both(self, u: float, v: float) -> Tuple[GradientResult, GradientResult, coord3]:
        """
        Compute gradients in both u and v directions using central differences.

        Returns:
            Tuple of (G_u, G_v, center_frame)
        """
        c_center = self.calc_intrinsic_frame(u, v)

        # u direction: central difference
        c_u_plus = self.calc_intrinsic_frame(u + self.h, v)
        c_u_minus = self.calc_intrinsic_frame(u - self.h, v)
        dn_du = ((c_u_plus - c_u_minus) / (2 * self.h)).VZ()

        # v direction: central difference
        c_v_plus = self.calc_intrinsic_frame(u, v + self.h)
        c_v_minus = self.calc_intrinsic_frame(u, v - self.h)
        dn_dv = ((c_v_plus - c_v_minus) / (2 * self.h)).VZ()

        G_u = GradientResult(dn_du, "u")
        G_v = GradientResult(dn_dv, "v")

        return G_u, G_v, c_center

    def compute_u(self, u: float, v: float) -> GradientResult:
        """Compute gradient in u direction only."""
        c_plus = self.calc_intrinsic_frame(u + self.h, v)
        c_minus = self.calc_intrinsic_frame(u - self.h, v)
        dn = ((c_plus - c_minus) / (2 * self.h)).VZ()
        return GradientResult(dn, "u")

    def compute_v(self, u: float, v: float) -> GradientResult:
        """Compute gradient in v direction only."""
        c_plus = self.calc_intrinsic_frame(u, v + self.h)
        c_minus = self.calc_intrinsic_frame(u, v - self.h)
        dn = ((c_plus - c_minus) / (2 * self.h)).VZ()
        return GradientResult(dn, "v")

    def compute_connection_matrices(self, u: float, v: float):
        """
        Compute the intrinsic gradient connection matrices G_u, G_v.

        These are the core objects of the CCS framework:
            G_i = dC/di * C^{-1}

        where C is the local coordinate system (Coord object).
        The connection matrices encode the complete local geometry:
        curvature, shape operator, and parallel transport can all be
        extracted from G_u and G_v.

        Returns:
            (G_u, G_v, c_center): G_u and G_v as coord3 connection
            matrices, c_center is the center frame.
        """
        c_center = self.calc_intrinsic_frame(u, v)

        c_u_plus  = self.calc_intrinsic_frame(u + self.h, v)
        c_u_minus = self.calc_intrinsic_frame(u - self.h, v)
        G_u = (c_u_plus - c_u_minus) / (2 * self.h) / c_center

        c_v_plus  = self.calc_intrinsic_frame(u, v + self.h)
        c_v_minus = self.calc_intrinsic_frame(u, v - self.h)
        G_v = (c_v_plus - c_v_minus) / (2 * self.h) / c_center

        return G_u, G_v, c_center


# ============================================================
# Intrinsic Gradient Curvature Calculator
# ============================================================

class IntrinsicGradientCurvatureCalculator:
    """
    Curvature calculator using intrinsic gradient method.

    Computes curvatures from the shape operator derived
    from the intrinsic gradient of the normal field.
    """

    # Path constants (detected once in __init__, used in hot loop with zero isinstance overhead)
    _PATH_VEC3_DERIVS  = 1   # derivs() → (r_u, r_v, r_uu, r_uv, r_vv) as vec3
    _PATH_MONGE_DERIVS = 2   # derivs() → (fu, fv, fuu, fuv, fvv) as scalars (Monge patch)
    _PATH_SPHERE_TORUS = 3   # analytical tangents + numerical normal offsets
    _PATH_STENCIL      = 4   # 13-point O(h⁴) position stencil (fallback)

    def __init__(self, surface: Surface, step_size: float = 1e-3):
        self.surface = surface
        self.h = step_size
        self.grad_op = IntrinsicGradientOperator(surface, step_size)
        self._cache_u: Optional[float] = None
        self._cache_v: Optional[float] = None
        self._cache_terms: Optional[Tuple[float, float, float, float, float, float, float, float]] = None

        # ── Detect computation path once so the hot loop has zero branching cost ──
        self._path = self._detect_path(surface)

    @staticmethod
    def _detect_path(surface: Surface) -> int:
        """Probe the surface once to decide which computation branch to use."""
        if isinstance(surface, (Sphere, Torus)):
            return IntrinsicGradientCurvatureCalculator._PATH_SPHERE_TORUS
        if hasattr(surface, "derivs"):
            try:
                # Use a generic interior point; avoid u=v=0 to dodge singularities
                sample = surface.derivs(0.3, 0.5)
                if isinstance(sample, (list, tuple)) and len(sample) == 5:
                    if isinstance(sample[0], vec3):
                        return IntrinsicGradientCurvatureCalculator._PATH_VEC3_DERIVS
                    if isinstance(sample[0], (int, float)):
                        return IntrinsicGradientCurvatureCalculator._PATH_MONGE_DERIVS
            except Exception:
                pass
        return IntrinsicGradientCurvatureCalculator._PATH_STENCIL

    def _get_tangent_vectors(self, u: float, v: float) -> Tuple[vec3, vec3]:
        """Get tangent vectors (analytical for known surfaces, numerical otherwise)."""
        if isinstance(self.surface, Sphere):
            R = self.surface.R
            theta, phi = u, v
            r_u = vec3(
                R * math.cos(theta) * math.cos(phi),
                R * math.cos(theta) * math.sin(phi),
                -R * math.sin(theta)
            )
            r_v = vec3(
                -R * math.sin(theta) * math.sin(phi),
                R * math.sin(theta) * math.cos(phi),
                0
            )
        elif isinstance(self.surface, Torus):
            R = self.surface.R
            r = self.surface.r
            r_u = vec3(
                -r * math.sin(u) * math.cos(v),
                -r * math.sin(u) * math.sin(v),
                r * math.cos(u)
            )
            r_v = vec3(
                -(R + r * math.cos(u)) * math.sin(v),
                (R + r * math.cos(u)) * math.cos(v),
                0
            )
        else:
            r_u = None
            r_v = None
            if hasattr(self.surface, "derivs"):
                try:
                    derivs = self.surface.derivs(u, v)
                    if isinstance(derivs, (list, tuple)) and len(derivs) >= 2:
                        cand_u, cand_v = derivs[0], derivs[1]
                        if isinstance(cand_u, vec3) and isinstance(cand_v, vec3):
                            r_u, r_v = cand_u, cand_v
                except Exception:
                    r_u = None
                    r_v = None
            if r_u is None or r_v is None:
                r_u = self.surface.tangent_u(u, v)
                r_v = self.surface.tangent_v(u, v)

        return r_u, r_v

    def _normal_at(self, u: float, v: float) -> vec3:
        r_u, r_v = self._get_tangent_vectors(u, v)
        return _safe_normal_from_tangents(r_u, r_v)

    def _compute_shape_terms_cached_positions(self, u: float, v: float) -> Tuple[float, float, float, float, float, float, float, float]:
        """
        Compute shape-operator terms via direct second-derivative projection.

        Improvements over the previous normal-differencing approach:
        - Accuracy : O(h⁴) for r_uu, r_vv via 5-point stencil
                     (vs. O(h²) central-difference on unit normals)
        - Speed    : single normal computation (1 cross product + 1 sqrt)
                     vs. four offset normals (4 cross products + 4 sqrts)

        Formula: L = r_uu · n,  M = r_uv · n,  N = r_vv · n
        where n = (r_u × r_v) / |r_u × r_v|  (same direction as before).
        This is mathematically equivalent to L = -dn/du · r_u (Weingarten),
        so _compute_curvatures_from_terms needs no changes.
        """
        h = self.h
        inv2h  = 0.5 / h
        c1_5pt = 1.0 / (12.0 * h)
        c5     = 1.0 / (12.0 * h * h)   # 5-pt 2nd-derivative prefactor
        inv4h2 = 0.25 / (h * h)          # mixed-derivative prefactor

        # ── 13-point position stencil ────────────────────────────────────────
        p    = self.surface.position(u,         v        )
        pp   = self.surface.position(u + h,     v        )
        pm   = self.surface.position(u - h,     v        )
        pq   = self.surface.position(u,         v + h    )
        pn   = self.surface.position(u,         v - h    )
        p2p  = self.surface.position(u + 2*h,   v        )
        p2m  = self.surface.position(u - 2*h,   v        )
        pq2  = self.surface.position(u,         v + 2*h  )
        pn2  = self.surface.position(u,         v - 2*h  )
        ppp  = self.surface.position(u + h,     v + h    )
        ppn  = self.surface.position(u + h,     v - h    )
        pmp  = self.surface.position(u - h,     v + h    )
        pmn  = self.surface.position(u - h,     v - h    )

        # ── First derivatives  O(h²) ─────────────────────────────────────────
        r_u = (p2p * (-1.0) + pp * 8.0 - pm * 8.0 + p2m) * c1_5pt
        r_v = (pq2 * (-1.0) + pq * 8.0 - pn * 8.0 + pn2) * c1_5pt

        # ── Second derivatives  O(h⁴) via 5-pt stencil ──────────────────────
        #   (-f₊₂ + 16f₊₁ - 30f₀ + 16f₋₁ - f₋₂) / (12h²)
        r_uu = (p2p * (-1.0) + pp * 16.0 + p * (-30.0) + pm * 16.0 + p2m * (-1.0)) * c5
        r_vv = (pq2 * (-1.0) + pq * 16.0 + p * (-30.0) + pn * 16.0 + pn2 * (-1.0)) * c5

        # ── Mixed derivative  O(h²) ──────────────────────────────────────────
        r_uv = (ppp - ppn - pmp + pmn) * inv4h2

        # ── First fundamental form ────────────────────────────────────────────
        E          = r_u.dot(r_u)
        F          = r_u.dot(r_v)
        G          = r_v.dot(r_v)
        metric_det = E * G - F * F

        # ── Single unit normal ────────────────────────────────────────────────
        n = _safe_normal_from_tangents(r_u, r_v)

        # ── Second fundamental form via direct projection ─────────────────────
        #   L = r_uu·n  is equivalent to  L = -dn/du·r_u  (Gauss/Weingarten)
        #   sign convention is identical to the previous method, so
        #   _compute_curvatures_from_terms (with normal_is_outward flip) is unchanged.
        L    = r_uu.dot(n)
        M_uv = r_uv.dot(n)
        N    = r_vv.dot(n)
        M    = M_uv

        return E, F, G, metric_det, L, M, N, M_uv

    def _compute_shape_terms(self, u: float, v: float) -> Tuple[float, float, float, float, float, float, float, float]:
        """
        Compute shared shape-operator terms.  Path is selected ONCE in __init__
        so there is no isinstance / hasattr overhead in the hot loop.

        Returns: (E, F, G, metric_det, L, M, N, M_uv)
        """
        p = self._path

        # ── Path 1: derivs() → 5 vec3  (ParamSurface) ───────────────────────
        if p == 1:
            r_u, r_v, r_uu, r_uv, r_vv = self.surface.derivs(u, v)
            E          = r_u.dot(r_u)
            F          = r_u.dot(r_v)
            G          = r_v.dot(r_v)
            metric_det = E * G - F * F
            n    = _safe_normal_from_tangents(r_u, r_v)
            L    = r_uu.dot(n)
            M_uv = r_uv.dot(n)
            N    = r_vv.dot(n)
            return E, F, G, metric_det, L, M_uv, N, M_uv

        # ── Path 2: derivs() → 5 scalars  (Monge patch z = f(u,v)) ──────────
        # r_u=(1,0,fu), r_v=(0,1,fv), n=(-fu,-fv,1)/W, L=fuu/W, M=fuv/W, N=fvv/W
        if p == 2:
            fu, fv, fuu, fuv, fvv = self.surface.derivs(u, v)
            W2         = 1.0 + fu * fu + fv * fv
            inv_W      = 1.0 / (W2 ** 0.5)
            E          = 1.0 + fu * fu
            F          = fu * fv
            G          = 1.0 + fv * fv
            metric_det = W2                      # = E*G - F^2 for Monge patch
            L    = fuu * inv_W
            M_uv = fuv * inv_W
            N    = fvv * inv_W
            return E, F, G, metric_det, L, M_uv, N, M_uv

        # ── Path 3: Sphere / Torus — analytical tangents ─────────────────────
        if p == 3:
            r_u, r_v = self._get_tangent_vectors(u, v)
            inv_2h    = 1.0 / (2.0 * self.h)

            n_u_plus  = self._normal_at(u + self.h, v)
            n_u_minus = self._normal_at(u - self.h, v)
            dn_du = (n_u_plus - n_u_minus) * inv_2h

            n_v_plus  = self._normal_at(u, v + self.h)
            n_v_minus = self._normal_at(u, v - self.h)
            dn_dv = (n_v_plus - n_v_minus) * inv_2h

            E          = r_u.dot(r_u)
            F          = r_u.dot(r_v)
            G          = r_v.dot(r_v)
            metric_det = E * G - F * F
            L    = -dn_du.dot(r_u)
            M_uv = -dn_du.dot(r_v)
            M_vu = -dn_dv.dot(r_u)
            N    = -dn_dv.dot(r_v)
            M    = (M_uv + M_vu) / 2.0
            return E, F, G, metric_det, L, M, N, M_uv

        # ── Path 4: General surfaces — 13-point O(h⁴) stencil ────────────────
        return self._compute_shape_terms_cached_positions(u, v)

    def _get_terms_cached(self, u: float, v: float) -> Tuple[float, float, float, float, float, float, float, float]:
        if self._cache_terms is not None and u == self._cache_u and v == self._cache_v:
            return self._cache_terms
        terms = self._compute_shape_terms(u, v)
        self._cache_u = u
        self._cache_v = v
        self._cache_terms = terms
        return terms

    def _compute_curvatures_from_terms(
        self,
        u: float,
        terms: Tuple[float, float, float, float, float, float, float, float]
    ) -> Tuple[float, float]:
        """
        Compute Gaussian and mean curvature from shared terms.
        """
        E, F, G, metric_det, L, M, N, _ = terms

        if abs(metric_det) > 1e-14:
            K = (L * N - M * M) / metric_det
            H = (G * L - 2 * F * M + E * N) / (2 * metric_det)
            # When r_u × r_v produces an outward normal (e.g. standard spherical
            # coords), the shape-operator formula yields H with opposite sign.
            # Correct by negation instead of a surface-specific copysign hack.
            if self.surface.normal_is_outward:
                H = -H
        else:
            K = 0.0
            H = 0.0

        return K, H

    def compute_gaussian_curvature(self, u: float, v: float) -> float:
        """
        Compute Gaussian curvature K = det(II) / det(I).
        """
        terms = self._get_terms_cached(u, v)
        K, _ = self._compute_curvatures_from_terms(u, terms)
        return K

    def compute_mean_curvature(self, u: float, v: float) -> float:
        """
        Compute mean curvature H = (EN - 2FM + GL) / (2*det(I)).
        """
        terms = self._get_terms_cached(u, v)
        _, H = self._compute_curvatures_from_terms(u, terms)
        return H

    def compute_riemann_curvature(self, u: float, v: float) -> float:
        """
        Compute Riemann curvature tensor component R^1_212.

        For 2D surfaces: R^1_212 = K * det(g) = LN - M^2
        """
        terms = self._get_terms_cached(u, v)
        _, _, _, _, L, _, N, M_uv = terms
        R_1212 = L * N - M_uv * M_uv
        return R_1212

    def compute_principal_curvatures(self, u: float, v: float) -> Tuple[float, float]:
        """
        Compute principal curvatures k1 and k2.

        Uses: k1,k2 = H +/- sqrt(H^2 - K)
        """
        terms = self._get_terms_cached(u, v)
        K, H = self._compute_curvatures_from_terms(u, terms)

        discriminant = max(0, H * H - K)
        sqrt_disc = discriminant ** 0.5

        k1 = H + sqrt_disc
        k2 = H - sqrt_disc

        return k1, k2

    def _compute_full_shape_terms(self, u: float, v: float):
        """
        Extended shape terms that also return tangent vectors and normal.

        Returns: (E, F, G, metric_det, L, M, N, M_uv, r_u_np, r_v_np, n_np)
            where r_u_np, r_v_np, n_np are numpy arrays (3,).
        """
        p = self._path

        def _to_np(v):
            return np.array([v.x, v.y, v.z], dtype=np.float64)

        if p == 1:
            r_u, r_v, r_uu, r_uv, r_vv = self.surface.derivs(u, v)
            E          = r_u.dot(r_u)
            F          = r_u.dot(r_v)
            G          = r_v.dot(r_v)
            metric_det = E * G - F * F
            n    = _safe_normal_from_tangents(r_u, r_v)
            L    = r_uu.dot(n)
            M_uv = r_uv.dot(n)
            N    = r_vv.dot(n)
            return E, F, G, metric_det, L, M_uv, N, M_uv, _to_np(r_u), _to_np(r_v), _to_np(n)

        if p == 2:
            fu, fv, fuu, fuv, fvv = self.surface.derivs(u, v)
            W2         = 1.0 + fu * fu + fv * fv
            inv_W      = 1.0 / (W2 ** 0.5)
            E          = 1.0 + fu * fu
            F          = fu * fv
            G          = 1.0 + fv * fv
            metric_det = W2
            L    = fuu * inv_W
            M_uv = fuv * inv_W
            N    = fvv * inv_W
            r_u_np = np.array([1.0, 0.0, fu], dtype=np.float64)
            r_v_np = np.array([0.0, 1.0, fv], dtype=np.float64)
            n_np   = np.array([-fu * inv_W, -fv * inv_W, inv_W], dtype=np.float64)
            return E, F, G, metric_det, L, M_uv, N, M_uv, r_u_np, r_v_np, n_np

        if p == 3:
            r_u, r_v = self._get_tangent_vectors(u, v)
            inv_2h    = 1.0 / (2.0 * self.h)
            n_u_plus  = self._normal_at(u + self.h, v)
            n_u_minus = self._normal_at(u - self.h, v)
            dn_du = (n_u_plus - n_u_minus) * inv_2h
            n_v_plus  = self._normal_at(u, v + self.h)
            n_v_minus = self._normal_at(u, v - self.h)
            dn_dv = (n_v_plus - n_v_minus) * inv_2h
            E          = r_u.dot(r_u)
            F          = r_u.dot(r_v)
            G          = r_v.dot(r_v)
            metric_det = E * G - F * F
            L    = -dn_du.dot(r_u)
            M_uv = -dn_du.dot(r_v)
            M_vu = -dn_dv.dot(r_u)
            N    = -dn_dv.dot(r_v)
            M    = (M_uv + M_vu) / 2.0
            n_center = _safe_normal_from_tangents(r_u, r_v)
            return E, F, G, metric_det, L, M, N, M_uv, _to_np(r_u), _to_np(r_v), _to_np(n_center)

        # Path 4 — reuse cached positions stencil
        h = self.h
        inv2h = 0.5 / h
        c1_5pt = 1.0 / (12.0 * h)
        c5    = 1.0 / (12.0 * h * h)
        inv4h2 = 0.25 / (h * h)

        p_  = self.surface.position(u, v)
        pp  = self.surface.position(u + h, v)
        pm  = self.surface.position(u - h, v)
        pq  = self.surface.position(u, v + h)
        pn  = self.surface.position(u, v - h)
        p2p = self.surface.position(u + 2 * h, v)
        p2m = self.surface.position(u - 2 * h, v)
        pq2 = self.surface.position(u, v + 2 * h)
        pn2 = self.surface.position(u, v - 2 * h)
        ppp = self.surface.position(u + h, v + h)
        ppn = self.surface.position(u + h, v - h)
        pmp = self.surface.position(u - h, v + h)
        pmn = self.surface.position(u - h, v - h)

        def _v(p):
            return np.array([p.x, p.y, p.z], dtype=np.float64)

        P   = _v(p_)
        PP  = _v(pp);  PM  = _v(pm)
        PQ  = _v(pq);  PN  = _v(pn)
        P2P = _v(p2p); P2M = _v(p2m)
        PQ2 = _v(pq2); PN2 = _v(pn2)
        PPP = _v(ppp); PPN = _v(ppn)
        PMP = _v(pmp); PMN = _v(pmn)

        r_u_np = (P2P * (-1.0) + PP * 8.0 - PM * 8.0 + P2M) * c1_5pt
        r_v_np = (PQ2 * (-1.0) + PQ * 8.0 - PN * 8.0 + PN2) * c1_5pt
        r_uu = (P2P * (-1.0) + PP * 16.0 + P * (-30.0) + PM * 16.0 + P2M * (-1.0)) * c5
        r_vv = (PQ2 * (-1.0) + PQ * 16.0 + P * (-30.0) + PN * 16.0 + PN2 * (-1.0)) * c5
        r_uv = (PPP - PPN - PMP + PMN) * inv4h2

        n_vec = np.cross(r_u_np, r_v_np)
        n_norm = np.linalg.norm(n_vec)
        n_np = n_vec / n_norm if n_norm > 1e-12 else np.array([0., 0., 1.])

        E = float(r_u_np @ r_u_np)
        F = float(r_u_np @ r_v_np)
        G = float(r_v_np @ r_v_np)
        metric_det = E * G - F * F
        L    = float(r_uu @ n_np)
        M_uv = float(r_uv @ n_np)
        N    = float(r_vv @ n_np)

        return E, F, G, metric_det, L, M_uv, N, M_uv, r_u_np, r_v_np, n_np

    def compute_all_curvatures(self, u: float, v: float) -> Dict[str, Union[float, Tuple[float, float], np.ndarray]]:
        """
        Compute all curvature quantities at once, including fundamental forms,
        shape operator, principal directions, and Riemann tensor component.

        Returns a dict with keys:
            'K', 'H', 'k1', 'k2',
            'dir1', 'dir2'  (principal directions as 3D numpy arrays),
            'g'             (2x2 first fundamental form),
            'h'             (2x2 second fundamental form B),
            'n'             (unit normal as numpy array),
            'S'             (2x2 shape operator g^{-1}B),
            'R_1212'        (Riemann tensor component = K * det(g)),
            # backward-compatible aliases
            'gaussian_curvature', 'mean_curvature', 'principal_curvatures'
        """
        E, F, G, metric_det, L, M, N, M_uv, r_u_np, r_v_np, n_np = \
            self._compute_full_shape_terms(u, v)

        # --- Scalar curvatures ---
        if abs(metric_det) > 1e-14:
            K = (L * N - M * M) / metric_det
            H = (G * L - 2 * F * M + E * N) / (2 * metric_det)
            if self.surface.normal_is_outward:
                H = -H
        else:
            K = 0.0
            H = 0.0

        # --- Principal curvatures and directions ---
        g = np.array([[E, F], [F, G]], dtype=np.float64)
        B = np.array([[L, M], [M, N]], dtype=np.float64)

        if abs(metric_det) > 1e-14:
            g_inv = np.array([[G, -F], [-F, E]], dtype=np.float64) / metric_det
            S = g_inv @ B
            eigenvalues, eigenvectors = np.linalg.eig(S)
            k1, k2 = float(eigenvalues.real[0]), float(eigenvalues.real[1])
            if abs(k1) < abs(k2):
                k1, k2 = k2, k1
                eigenvectors = eigenvectors[:, [1, 0]]
            d1_2d = eigenvectors[:, 0].real
            d2_2d = eigenvectors[:, 1].real
            dir1 = d1_2d[0] * r_u_np + d1_2d[1] * r_v_np
            dir2 = d2_2d[0] * r_u_np + d2_2d[1] * r_v_np
            nrm1 = np.linalg.norm(dir1)
            nrm2 = np.linalg.norm(dir2)
            dir1 = dir1 / nrm1 if nrm1 > 1e-14 else np.array([1., 0., 0.])
            dir2 = dir2 / nrm2 if nrm2 > 1e-14 else np.array([0., 1., 0.])
        else:
            k1, k2 = 0.0, 0.0
            S = np.zeros((2, 2), dtype=np.float64)
            dir1 = np.array([1., 0., 0.])
            dir2 = np.array([0., 1., 0.])

        R_1212 = L * N - M_uv * M_uv

        return {
            # Standard keys (same as CurvatureCalculator)
            'K': K, 'H': H,
            'k1': k1, 'k2': k2,
            'dir1': dir1, 'dir2': dir2,
            'g': g, 'h': B, 'n': n_np,
            'S': S, 'R_1212': R_1212,
            # Backward-compatible aliases
            'gaussian_curvature': K,
            'mean_curvature': H,
            'principal_curvatures': (k1, k2),
        }


# ============================================================
# Classical Curvature Calculator
# ============================================================

class CurvatureCalculator:
    """
    High-precision discrete curvature calculator using classical differential geometry.

    Uses high-order finite differences for computing derivatives
    and fundamental forms.
    """

    def __init__(self, surface: Surface, step_size: float = 1e-3):
        self.surface = surface
        self.h = step_size
        self._cache_u: Optional[float] = None
        self._cache_v: Optional[float] = None
        self._cache_derivs: Optional[Dict[str, np.ndarray]] = None
        self._cache_forms: Optional[Tuple[np.ndarray, np.ndarray, np.ndarray]] = None

    def _get_derivs_cached(self, u: float, v: float) -> Dict[str, np.ndarray]:
        if self._cache_derivs is not None and u == self._cache_u and v == self._cache_v:
            return self._cache_derivs
        derivs = self._compute_derivatives(u, v)
        self._cache_u = u
        self._cache_v = v
        self._cache_derivs = derivs
        self._cache_forms = None
        return derivs

    def _get_forms_cached(self, u: float, v: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        if self._cache_forms is not None and u == self._cache_u and v == self._cache_v:
            return self._cache_forms
        derivs = self._get_derivs_cached(u, v)
        forms = self.compute_fundamental_forms(u, v, derivs)
        self._cache_forms = forms
        return forms

    def _position_array(self, u: float, v: float) -> np.ndarray:
        """Convert vec3 position to numpy array."""
        pos = self.surface.position(u, v)
        return np.array([pos.x, pos.y, pos.z])

    def _compute_derivatives(self, u: float, v: float) -> Dict[str, np.ndarray]:
        """Compute surface derivatives using high-order finite differences."""
        effective_h = max(self.h, 1e-6)
        h = effective_h

        offsets = (-2, -1, 0, 1, 2)
        pos = {}
        for du in offsets:
            u_offset = u + du * h
            for dv in offsets:
                pos[(du, dv)] = self._position_array(u_offset, v + dv * h)

        # 5-point first-derivative coefficients
        c1 = { -2: 1.0, -1: -8.0, 1: 8.0, 2: -1.0 }

        # First derivatives
        r_u = (
            pos[(-2, 0)] - 8.0 * pos[(-1, 0)] + 8.0 * pos[(1, 0)] - pos[(2, 0)]
        ) / (12.0 * h)
        r_v = (
            pos[(0, -2)] - 8.0 * pos[(0, -1)] + 8.0 * pos[(0, 1)] - pos[(0, 2)]
        ) / (12.0 * h)

        # 5-point second derivatives
        r_uu = (
            -pos[(2, 0)] + 16.0 * pos[(1, 0)] - 30.0 * pos[(0, 0)] +
            16.0 * pos[(-1, 0)] - pos[(-2, 0)]
        ) / (12.0 * h * h)
        r_vv = (
            -pos[(0, 2)] + 16.0 * pos[(0, 1)] - 30.0 * pos[(0, 0)] +
            16.0 * pos[(0, -1)] - pos[(0, -2)]
        ) / (12.0 * h * h)

        # Mixed derivative via separable 5-point stencil
        r_uv = np.zeros(3, dtype=np.float64)
        for du, cu in c1.items():
            for dv, cv in c1.items():
                r_uv += (cu * cv) * pos[(du, dv)]
        r_uv /= (144.0 * h * h)

        return {
            'r_u': r_u, 'r_v': r_v,
            'r_uu': r_uu, 'r_vv': r_vv, 'r_uv': r_uv
        }

    def compute_fundamental_forms(
        self,
        u: float,
        v: float,
        derivs: Optional[Dict[str, np.ndarray]] = None
    ) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Compute first and second fundamental forms.

        Returns:
            (g, h, n): First form, second form, normal vector
        """
        if derivs is None:
            derivs = self._compute_derivatives(u, v)
        r_u = derivs['r_u']
        r_v = derivs['r_v']
        r_uu = derivs['r_uu']
        r_vv = derivs['r_vv']
        r_uv = derivs['r_uv']

        # First fundamental form
        E = np.dot(r_u, r_u)
        F = np.dot(r_u, r_v)
        G = np.dot(r_v, r_v)
        g = np.array([[E, F], [F, G]])

        # Normal vector
        n_vec = np.cross(r_u, r_v)
        n_norm = np.linalg.norm(n_vec)
        if n_norm > 1e-14:
            n = n_vec / n_norm
        else:
            n = np.array([0., 0., 1.])

        # Second fundamental form
        L = np.dot(r_uu, n)
        M = np.dot(r_uv, n)
        N = np.dot(r_vv, n)
        h = np.array([[L, M], [M, N]])

        return g, h, n

    def _compute_curvatures_from_forms(
        self,
        g: np.ndarray,
        h: np.ndarray
    ) -> Tuple[float, float]:
        """Compute Gaussian and mean curvature from fundamental forms."""
        det_g = np.linalg.det(g)
        if abs(det_g) < 1e-14:
            return 0.0, 0.0

        det_h = np.linalg.det(h)
        K = det_h / det_g

        trace_term = g[1, 1] * h[0, 0] - 2 * g[0, 1] * h[0, 1] + g[0, 0] * h[1, 1]
        H = trace_term / (2 * det_g)

        return K, abs(H)

    def _compute_principal_from_forms(
        self,
        derivs: Dict[str, np.ndarray],
        g: np.ndarray,
        h: np.ndarray
    ) -> Tuple[float, float, np.ndarray, np.ndarray]:
        """Compute principal curvatures and directions from forms."""
        r_u = derivs['r_u']
        r_v = derivs['r_v']

        det_g = np.linalg.det(g)
        if abs(det_g) < 1e-14:
            return 0.0, 0.0, np.array([1., 0., 0.]), np.array([0., 1., 0.])

        g_inv = np.linalg.inv(g)
        S = g_inv @ h

        eigenvalues, eigenvectors = np.linalg.eig(S)
        k1, k2 = eigenvalues.real

        if abs(k1) < abs(k2):
            k1, k2 = k2, k1
            eigenvectors = eigenvectors[:, [1, 0]]

        dir1_2d = eigenvectors[:, 0]
        dir2_2d = eigenvectors[:, 1]

        dir1_3d = dir1_2d[0] * r_u + dir1_2d[1] * r_v
        dir2_3d = dir2_2d[0] * r_u + dir2_2d[1] * r_v

        dir1_3d = dir1_3d / (np.linalg.norm(dir1_3d) + 1e-14)
        dir2_3d = dir2_3d / (np.linalg.norm(dir2_3d) + 1e-14)

        return k1, k2, dir1_3d, dir2_3d

    def compute_gaussian_curvature(self, u: float, v: float) -> float:
        """Compute Gaussian curvature K = det(II) / det(I)."""
        g, h, _ = self._get_forms_cached(u, v)
        K, _ = self._compute_curvatures_from_forms(g, h)
        return K

    def compute_mean_curvature(self, u: float, v: float) -> float:
        """Compute mean curvature H."""
        g, h, _ = self._get_forms_cached(u, v)
        _, H = self._compute_curvatures_from_forms(g, h)
        return H

    def compute_principal_curvatures(self, u: float, v: float) -> Tuple[float, float, np.ndarray, np.ndarray]:
        """
        Compute principal curvatures and principal directions.

        Returns:
            (k1, k2, dir1, dir2): Principal curvatures and directions
        """
        derivs = self._get_derivs_cached(u, v)
        g, h, _ = self._get_forms_cached(u, v)
        return self._compute_principal_from_forms(derivs, g, h)

    def compute_all_curvatures(self, u: float, v: float) -> Dict[str, Union[float, np.ndarray]]:
        """Compute all curvature quantities at once."""
        derivs = self._get_derivs_cached(u, v)
        g, h, n = self._get_forms_cached(u, v)
        K, H = self._compute_curvatures_from_forms(g, h)
        k1, k2, dir1, dir2 = self._compute_principal_from_forms(derivs, g, h)

        return {
            'K': K,
            'H': H,
            'k1': k1,
            'k2': k2,
            'dir1': dir1,
            'dir2': dir2,
            'g': g,
            'h': h,
            'n': n
        }


# ============================================================
# Convenience Functions - Intrinsic Gradient Method (Default)
# ============================================================

_intrinsic_calc_cache: "weakref.WeakKeyDictionary[Surface, Dict[float, IntrinsicGradientCurvatureCalculator]]" = weakref.WeakKeyDictionary()
_classical_calc_cache: "weakref.WeakKeyDictionary[Surface, Dict[float, CurvatureCalculator]]" = weakref.WeakKeyDictionary()
_intrinsic_grad_cache: "weakref.WeakKeyDictionary[Surface, Dict[float, IntrinsicGradientOperator]]" = weakref.WeakKeyDictionary()


def _get_cached_calc(cache, surface: Surface, step_size: float, ctor, attr_name: str):
    try:
        surf_dict = surface.__dict__
    except Exception:
        surf_dict = None

    if surf_dict is not None:
        step_map = surf_dict.get(attr_name)
        if step_map is None:
            step_map = {}
            surf_dict[attr_name] = step_map
        calc = step_map.get(step_size)
        if calc is None:
            calc = ctor(surface, step_size)
            step_map[step_size] = calc
        return calc

    step_map = cache.get(surface)
    if step_map is None:
        step_map = {}
        cache[surface] = step_map
    calc = step_map.get(step_size)
    if calc is None:
        calc = ctor(surface, step_size)
        step_map[step_size] = calc
    return calc


def _curvatures_from_derivs(
    r_u: vec3,
    r_v: vec3,
    r_uu: vec3,
    r_uv: vec3,
    r_vv: vec3
) -> Tuple[float, float]:
    E = r_u.dot(r_u)
    F = r_u.dot(r_v)
    G = r_v.dot(r_v)
    denom = E * G - F * F
    if abs(denom) < 1e-14:
        return 0.0, 0.0
    n = _safe_normal_from_tangents(r_u, r_v)
    L = r_uu.dot(n)
    M = r_uv.dot(n)
    N = r_vv.dot(n)
    K = (L * N - M * M) / denom
    H = (E * N - 2.0 * F * M + G * L) / (2.0 * denom)
    return K, H


def _analytic_curvatures(surface: Surface, u: float, v: float) -> Optional[Tuple[float, float]]:
    if not USE_ANALYTIC_DERIVS:
        return None
    if isinstance(surface, Sphere):
        return surface.theoretical_gaussian_curvature, surface.theoretical_mean_curvature
    if isinstance(surface, Torus):
        return surface.theoretical_gaussian_curvature(u), surface.theoretical_mean_curvature(u)
    if hasattr(surface, "analytic_KH"):
        try:
            return surface.analytic_KH(u, v)
        except Exception:
            pass
    if hasattr(surface, "derivs"):
        try:
            r_u, r_v, r_uu, r_uv, r_vv = surface.derivs(u, v)
            return _curvatures_from_derivs(r_u, r_v, r_uu, r_uv, r_vv)
        except Exception:
            pass
    return None


def _compute_intrinsic_kh(surface: Surface, u: float, v: float, step_size: float) -> Tuple[float, float]:
    calc = _get_cached_calc(_intrinsic_calc_cache, surface, step_size, IntrinsicGradientCurvatureCalculator, "_cs_intrinsic_calc")
    terms = calc._get_terms_cached(u, v)
    return calc._compute_curvatures_from_terms(u, terms)


def _compute_classical_kh(surface: Surface, u: float, v: float, step_size: float) -> Tuple[float, float]:
    calc = _get_cached_calc(_classical_calc_cache, surface, step_size, CurvatureCalculator, "_cs_classical_calc")
    g, h, _ = calc._get_forms_cached(u, v)
    return calc._compute_curvatures_from_forms(g, h)


_last_intrinsic: Dict[str, Union[Surface, float, Tuple[float, float], None]] = {
    "surface": None,
    "u": None,
    "v": None,
    "step": None,
    "kh": None,
}

_last_classical: Dict[str, Union[Surface, float, Tuple[float, float], None]] = {
    "surface": None,
    "u": None,
    "v": None,
    "step": None,
    "kh": None,
}

# Toggle analytic fast path (derivs/analytic_KH/theoretical formulas)
USE_ANALYTIC_DERIVS = True


def compute_gaussian_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """
    Compute Gaussian curvature using intrinsic gradient method.
    """
    if (
        _last_intrinsic["surface"] is surface and
        _last_intrinsic["u"] == u and
        _last_intrinsic["v"] == v and
        _last_intrinsic["step"] == step_size and
        _last_intrinsic["kh"] is not None
    ):
        return _last_intrinsic["kh"][0]

    analytic = _analytic_curvatures(surface, u, v)
    if analytic is not None:
        _last_intrinsic.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": analytic})
        return analytic[0]

    K, H = _compute_intrinsic_kh(surface, u, v, step_size)
    _last_intrinsic.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": (K, H)})
    return K


def compute_mean_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """
    Compute mean curvature using intrinsic gradient method.
    """
    if (
        _last_intrinsic["surface"] is surface and
        _last_intrinsic["u"] == u and
        _last_intrinsic["v"] == v and
        _last_intrinsic["step"] == step_size and
        _last_intrinsic["kh"] is not None and
        _last_intrinsic["kh"][1] is not None
    ):
        return _last_intrinsic["kh"][1]

    analytic = _analytic_curvatures(surface, u, v)
    if analytic is not None:
        _last_intrinsic.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": analytic})
        return analytic[1]

    K, H = _compute_intrinsic_kh(surface, u, v, step_size)
    _last_intrinsic.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": (K, H)})
    return H


def compute_riemann_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """
    Compute Riemann curvature tensor component R^1_212.
    """
    calc = _get_cached_calc(_intrinsic_calc_cache, surface, step_size, IntrinsicGradientCurvatureCalculator, "_cs_intrinsic_calc")
    return calc.compute_riemann_curvature(u, v)


def compute_all_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Dict[str, Union[float, Tuple[float, float]]]:
    """
    Compute all curvature quantities using intrinsic gradient method.
    """
    analytic = _analytic_curvatures(surface, u, v)
    if analytic is not None:
        K, H = analytic
        discriminant = max(0, H * H - K)
        sqrt_disc = discriminant ** 0.5
        k1 = H + sqrt_disc
        k2 = H - sqrt_disc
        return {
            'K': K, 'H': H, 'k1': k1, 'k2': k2,
            'gaussian_curvature': K,
            'mean_curvature': H,
            'principal_curvatures': (k1, k2)
        }

    calc = _get_cached_calc(_intrinsic_calc_cache, surface, step_size, IntrinsicGradientCurvatureCalculator, "_cs_intrinsic_calc")
    return calc.compute_all_curvatures(u, v)


def compute_intrinsic_gradient(
    surface: Surface,
    u: float,
    v: float,
    direction: str = 'u',
    step_size: float = 1e-3
) -> GradientResult:
    """
    Compute intrinsic gradient in specified direction.

    Args:
        surface: Surface object
        u, v: Parameter values
        direction: 'u' or 'v'
        step_size: Step size

    Returns:
        GradientResult object
    """
    grad_op = _get_cached_calc(_intrinsic_grad_cache, surface, step_size, IntrinsicGradientOperator, "_cs_intrinsic_grad")

    if direction == 'u':
        return grad_op.compute_u(u, v)
    elif direction == 'v':
        return grad_op.compute_v(u, v)
    else:
        raise ValueError(f"direction must be 'u' or 'v', got: {direction}")


def compute_connection_matrices(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
):
    """
    Compute the CCS connection matrices G_u, G_v at (u, v).

    G_i = dC/di * C^{-1}, where C is the local coordinate system.
    These encode the complete differential geometry: curvature,
    shape operator, and parallel transport.

    Returns:
        (G_u, G_v, c_center): connection matrices and center frame
    """
    grad_op = _get_cached_calc(
        _intrinsic_grad_cache, surface, step_size,
        IntrinsicGradientOperator, "_cs_grad_op"
    )
    return grad_op.compute_connection_matrices(u, v)


def compute_ccs_geometry_package(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> CCSGeometryPackage:
    """
    Compute a structured CCS geometry package at a surface point.

    This is the explicit theorem-chain API for the library:

        CCS object/frame
            -> full finite-difference variation G_u, G_v
            -> recovered local geometry (g, h, S)
            -> curvature invariants (K, H, k1, k2, R_1212)

    Returns:
        CCSGeometryPackage
    """
    grad_op = _get_cached_calc(
        _intrinsic_grad_cache, surface, step_size,
        IntrinsicGradientOperator, "_cs_grad_op"
    )
    calc = _get_cached_calc(
        _intrinsic_calc_cache, surface, step_size,
        IntrinsicGradientCurvatureCalculator, "_cs_intrinsic_calc"
    )
    G_u, G_v, center_frame = grad_op.compute_connection_matrices(u, v)
    curvatures = calc.compute_all_curvatures(u, v)
    return CCSGeometryPackage(
        center_frame=center_frame,
        G_u=G_u,
        G_v=G_v,
        g=np.array(curvatures['g'], copy=True),
        h=np.array(curvatures['h'], copy=True),
        S=np.array(curvatures['S'], copy=True),
        K=float(curvatures['K']),
        H=float(curvatures['H']),
        k1=float(curvatures['k1']),
        k2=float(curvatures['k2']),
        normal=np.array(curvatures['n'], copy=True),
        riemann_1212=float(curvatures['R_1212']),
    )


# ============================================================
# Convenience Functions - Classical Method
# ============================================================

def gaussian_curvature_classical(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Compute Gaussian curvature using classical method."""
    if (
        _last_classical["surface"] is surface and
        _last_classical["u"] == u and
        _last_classical["v"] == v and
        _last_classical["step"] == step_size and
        _last_classical["kh"] is not None
    ):
        return _last_classical["kh"][0]

    analytic = _analytic_curvatures(surface, u, v)
    if analytic is not None:
        _last_classical.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": (analytic[0], abs(analytic[1]))})
        return analytic[0]

    K, H = _compute_classical_kh(surface, u, v, step_size)
    _last_classical.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": (K, H)})
    return K


def mean_curvature_classical(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Compute mean curvature using classical method."""
    if (
        _last_classical["surface"] is surface and
        _last_classical["u"] == u and
        _last_classical["v"] == v and
        _last_classical["step"] == step_size and
        _last_classical["kh"] is not None and
        _last_classical["kh"][1] is not None
    ):
        return _last_classical["kh"][1]

    analytic = _analytic_curvatures(surface, u, v)
    if analytic is not None:
        _last_classical.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": (analytic[0], abs(analytic[1]))})
        return abs(analytic[1])

    K, H = _compute_classical_kh(surface, u, v, step_size)
    _last_classical.update({"surface": surface, "u": u, "v": v, "step": step_size, "kh": (K, H)})
    return H


def principal_curvatures_classical(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Tuple[float, float]:
    """Compute principal curvatures using classical method."""
    calc = _get_cached_calc(_classical_calc_cache, surface, step_size, CurvatureCalculator, "_cs_classical_calc")
    k1, k2, _, _ = calc.compute_principal_curvatures(u, v)
    return k1, k2


def all_curvatures_classical(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Dict[str, Union[float, np.ndarray]]:
    """Compute all curvature quantities using classical method."""
    calc = _get_cached_calc(_classical_calc_cache, surface, step_size, CurvatureCalculator, "_cs_classical_calc")
    return calc.compute_all_curvatures(u, v)


# ============================================================
# Backward Compatibility Aliases
# ============================================================

def gaussian_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Compute Gaussian curvature (default: intrinsic gradient method)."""
    return compute_gaussian_curvature(surface, u, v, step_size)


def mean_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Compute mean curvature (default: intrinsic gradient method)."""
    return compute_mean_curvature(surface, u, v, step_size)


def principal_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Tuple[float, float]:
    """Compute principal curvatures (default: intrinsic gradient method)."""
    calc = IntrinsicGradientCurvatureCalculator(surface, step_size)
    return calc.compute_principal_curvatures(u, v)


def all_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Dict[str, Union[float, Tuple[float, float]]]:
    """Compute all curvature quantities (default: intrinsic gradient method)."""
    return compute_all_curvatures(surface, u, v, step_size)


# ============================================================
# Legacy / Compatibility Aliases
# ============================================================

class LieGroupCurvatureCalculator(IntrinsicGradientCurvatureCalculator):
    """Legacy alias for intrinsic gradient curvature calculator."""


def compute_curvature_tensor(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Legacy alias for compute_riemann_curvature."""
    return compute_riemann_curvature(surface, u, v, step_size)


def gaussian_curvature_lie(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Legacy alias for intrinsic gradient Gaussian curvature."""
    return compute_gaussian_curvature(surface, u, v, step_size)


def intrinsic_gradient_gaussian_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Legacy alias for intrinsic gradient Gaussian curvature."""
    return compute_gaussian_curvature(surface, u, v, step_size)


def intrinsic_gradient_mean_curvature(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> float:
    """Legacy alias for intrinsic gradient mean curvature."""
    return compute_mean_curvature(surface, u, v, step_size)


def intrinsic_gradient_principal_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Tuple[float, float]:
    """Legacy alias for intrinsic gradient principal curvatures."""
    return principal_curvatures(surface, u, v, step_size)


def intrinsic_gradient_all_curvatures(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Dict[str, Union[float, Tuple[float, float]]]:
    """Legacy alias for intrinsic gradient curvature set."""
    return compute_all_curvatures(surface, u, v, step_size)


# ============================================================
# Method Comparison
# ============================================================

def compare_methods(
    surface: Surface,
    u: float,
    v: float,
    step_size: float = 1e-3
) -> Dict[str, float]:
    """
    Compare classical and intrinsic gradient curvature methods.

    Returns:
        Dictionary with curvature values from both methods and error metrics
    """
    K_classical = gaussian_curvature_classical(surface, u, v, step_size)
    K_intrinsic = compute_gaussian_curvature(surface, u, v, step_size)

    difference = abs(K_classical - K_intrinsic)
    relative_error = difference / abs(K_classical) if abs(K_classical) > 1e-14 else 0.0

    return {
        'K_classical': K_classical,
        'K_intrinsic': K_intrinsic,
        'difference': difference,
        'relative_error': relative_error
    }


# ============================================================
# Export
# ============================================================

__all__ = [
    # Surface classes
    'Surface',
    'Sphere',
    'Torus',

    # Core classes
    'MetricTensor',
    'GradientResult',
    'CCSGeometryPackage',
    'IntrinsicGradientOperator',
    'IntrinsicGradientCurvatureCalculator',
    'LieGroupCurvatureCalculator',
    'CurvatureCalculator',

    # Intrinsic gradient method functions (default)
    'compute_gaussian_curvature',
    'compute_mean_curvature',
    'compute_riemann_curvature',
    'compute_curvature_tensor',
    'compute_all_curvatures',
    'compute_intrinsic_gradient',
    'compute_ccs_geometry_package',

    # Intrinsic gradient legacy aliases
    'intrinsic_gradient_gaussian_curvature',
    'intrinsic_gradient_mean_curvature',
    'intrinsic_gradient_principal_curvatures',
    'intrinsic_gradient_all_curvatures',

    # Classical method functions
    'gaussian_curvature_classical',
    'mean_curvature_classical',
    'principal_curvatures_classical',
    'all_curvatures_classical',

    # Backward compatibility aliases
    'gaussian_curvature',
    'mean_curvature',
    'principal_curvatures',
    'all_curvatures',

    # Legacy Lie group naming
    'gaussian_curvature_lie',

    # Method comparison
    'compare_methods',

    # Utility functions
    'derivative_5pt',
    'derivative_2nd_5pt',
    'richardson_extrapolation',
]
