"""
Lambda layer.

This module is the clear public entry for topological-coupling related objects:
benchmark normalization, low-energy effective suppression, and exploratory
running ansatz.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .topological_physics import (
    LambdaRunningResult,
    LambdaStructuralMatch,
    lambda_from_theta,
    lambda_low_energy_effective,
    lambda_power_law_running,
    lambda_reference_benchmark,
)
from .unified_topological_physics import LambdaSectorPackage, build_lambda_sector_package


@dataclass(frozen=True)
class Lambda:
    """
    Physical wrapper for lambda-level workflows.

    This layer is responsible for parameterization, benchmark normalization,
    effective running, and constraint-oriented packaging.
    """

    theta: float = 1.0
    energy_ev: float = 0.026
    running_beta: Optional[float] = None

    def benchmark(self) -> LambdaStructuralMatch:
        return lambda_reference_benchmark(theta=self.theta)

    def from_theta(self) -> float:
        return lambda_from_theta(theta=self.theta)

    def low_energy(self) -> LambdaRunningResult:
        return lambda_low_energy_effective(energy_ev=self.energy_ev, lambda_0=self.from_theta())

    def power_law(self) -> Optional[LambdaRunningResult]:
        if self.running_beta is None:
            return None
        return lambda_power_law_running(
            energy_ev=self.energy_ev,
            beta=self.running_beta,
            lambda_0=self.from_theta(),
        )

    def package(self) -> LambdaSectorPackage:
        return build_lambda_sector_package(
            theta=self.theta,
            energy_ev=self.energy_ev,
            running_beta=self.running_beta,
        )


__all__ = [
    "Lambda",
    "LambdaStructuralMatch",
    "LambdaRunningResult",
    "LambdaSectorPackage",
    "lambda_reference_benchmark",
    "lambda_from_theta",
    "lambda_low_energy_effective",
    "lambda_power_law_running",
    "build_lambda_sector_package",
]
