"""
System-level packaging for the CCS -> complex frame -> two-sector -> application chain.

This module does not invent new low-level formulas.  Instead, it organizes
existing numerical components into a single structured interface so users can
work with the theory as one pipeline:

    CCS geometry
        -> complexified frame field
        -> spacetime / gauge two-sector tensor
        -> Chern-Simons flow contribution
        -> lambda diagnostics
        -> dark-matter shell probes
        -> loop observables
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np

from .complex_frame_theory import ComplexCurvaturePackage, ComplexFrameField, TopologicalFlowPackage
from .differential_geometry import CCSGeometryPackage, Surface, compute_ccs_geometry_package
from .topological_physics import (
    DMShellResult,
    LambdaRunningResult,
    LambdaStructuralMatch,
    dm_shell_scan,
    lambda_low_energy_effective,
    lambda_power_law_running,
    lambda_reference_benchmark,
)


def _vector_norm(v: np.ndarray) -> float:
    return float(np.linalg.norm(np.asarray(v, dtype=float)))


@dataclass(frozen=True)
class LoopObservables:
    """
    Operational loop hierarchy extracted from the complex frame / CS flow package.

    The naming is intentionally pragmatic:
    - small loops: local color / component phases
    - large loop: global frame phase
    - evolution loop: CS-flow-driven change proxy
    """

    small_loop_phases: np.ndarray
    large_loop_phase: float
    evolution_loop_strength: float
    loop_balance: float


@dataclass(frozen=True)
class LambdaSectorPackage:
    """Unified lambda diagnostics for the current state."""

    benchmark: LambdaStructuralMatch
    low_energy: LambdaRunningResult
    power_law: Optional[LambdaRunningResult]


@dataclass(frozen=True)
class DarkMatterSectorPackage:
    """Dark-matter shell probes derived from the shared mass shell map."""

    nearest_shells: List[DMShellResult]


@dataclass(frozen=True)
class TwoSectorPackage:
    """
    Two-sector packaging of the unified field left-hand side.

    real_sector:
        Conformal Einstein / spacetime geometry sector.
    gauge_sector:
        Imaginary gauge-curvature encoding sector.
    cs_sector:
        Imaginary Chern-Simons flow contribution.
    total_lhs:
        Combined proxy used by the current numerical theory layer.
    """

    real_sector: np.ndarray
    gauge_sector: np.ndarray
    cs_sector: np.ndarray
    total_lhs: np.ndarray


@dataclass(frozen=True)
class UnifiedTopologicalState:
    """
    Full package for the current numerical topological-physics chain.
    """

    point: np.ndarray
    geometry: Optional[CCSGeometryPackage]
    complex_curvature: ComplexCurvaturePackage
    topological_flow: TopologicalFlowPackage
    two_sector: TwoSectorPackage
    lambda_sector: LambdaSectorPackage
    dark_matter_sector: Optional[DarkMatterSectorPackage]
    loop_observables: LoopObservables

    def summary(self) -> str:
        """Human-readable short summary."""
        lines = [
            "Unified topological-physics state",
            f"point = {np.array2string(self.point, precision=4)}",
            f"large_loop_phase = {self.loop_observables.large_loop_phase:+.6f}",
            f"evolution_loop_strength = {self.loop_observables.evolution_loop_strength:.6f}",
            f"lambda_low_energy = {self.lambda_sector.low_energy.lambda_value:.6f}",
            f"dm_shell_count = {0 if self.dark_matter_sector is None else len(self.dark_matter_sector.nearest_shells)}",
        ]
        if self.geometry is not None:
            lines.append(f"geometry: K = {self.geometry.K:+.6f}, H = {self.geometry.H:+.6f}")
        lines.append(f"two-sector real norm = {_vector_norm(self.two_sector.real_sector):.6f}")
        lines.append(f"two-sector gauge norm = {_vector_norm(np.real(1j * self.two_sector.gauge_sector)):.6f}")
        lines.append(f"cs-sector norm = {_vector_norm(np.real(1j * self.two_sector.cs_sector)):.6f}")
        return "\n".join(lines)


def build_loop_observables(field: ComplexFrameField, x: Iterable[float]) -> LoopObservables:
    """Extract operational small/large/evolution loop observables."""
    point = np.asarray(list(x), dtype=float)
    frame = field.frame(point)
    small = np.asarray(frame.color_phases(), dtype=float)
    large = float(frame.global_phase)
    flow = field.cs_flow_package(point)
    evolution = _vector_norm(flow.cs_current)
    balance = float(abs(large) / (np.sum(np.abs(small)) + 1.0e-12))
    return LoopObservables(
        small_loop_phases=small,
        large_loop_phase=large,
        evolution_loop_strength=evolution,
        loop_balance=balance,
    )


def build_lambda_sector_package(
    *,
    theta: float = 1.0,
    energy_ev: float = 0.026,
    running_beta: Optional[float] = None,
) -> LambdaSectorPackage:
    """Package lambda benchmark and running models together."""
    benchmark = lambda_reference_benchmark(theta=theta)
    low_energy = lambda_low_energy_effective(energy_ev=energy_ev, lambda_0=benchmark.lambda_0)
    power = None
    if running_beta is not None:
        power = lambda_power_law_running(
            energy_ev=energy_ev,
            beta=running_beta,
            lambda_0=benchmark.lambda_0,
        )
    return LambdaSectorPackage(
        benchmark=benchmark,
        low_energy=low_energy,
        power_law=power,
    )


def build_dark_matter_sector_package(target_masses_GeV: Sequence[float]) -> DarkMatterSectorPackage:
    """Package nearest-shell scans for a list of target mass scales."""
    return DarkMatterSectorPackage(nearest_shells=dm_shell_scan(list(target_masses_GeV)))


def build_two_sector_package(
    field: ComplexFrameField,
    x: Iterable[float],
    *,
    planck_mass: float = 1.0,
    topo_lambda: float = 1.0,
    gauge_weight: float = 1.0,
) -> TwoSectorPackage:
    """Package spacetime, gauge, and CS sectors explicitly."""
    point = np.asarray(list(x), dtype=float)
    real = 0.5 * (planck_mass ** 2) * field.einstein_conformal_tensor(point)
    gauge = 1j * gauge_weight * field.gauge_curvature_encoding_tensor(point)
    cs = compute_cs_term(field, point, topo_lambda=topo_lambda)
    total = real + gauge + cs
    return TwoSectorPackage(
        real_sector=real,
        gauge_sector=gauge,
        cs_sector=cs,
        total_lhs=total,
    )


def compute_cs_term(
    field: ComplexFrameField,
    x: Iterable[float],
    *,
    topo_lambda: float = 1.0,
) -> np.ndarray:
    """
    Compute the numerical Chern-Simons contribution tensor directly.

    Formula:
        i * lambda / (32 pi^2) * nabla_(i K_j)
    where K is the Chern-Simons current proxy from the complex frame field.
    """
    point = np.asarray(list(x), dtype=float)
    return 1j * (topo_lambda / (32.0 * np.pi**2)) * field.cs_gradient_tensor(point)


def build_unified_topological_state(
    field: ComplexFrameField,
    x: Iterable[float],
    *,
    surface: Optional[Surface] = None,
    surface_u: Optional[float] = None,
    surface_v: Optional[float] = None,
    surface_step_size: float = 1.0e-4,
    planck_mass: float = 1.0,
    topo_lambda: float = 1.0,
    gauge_weight: float = 1.0,
    theta: float = 1.0,
    energy_ev: float = 0.026,
    running_beta: Optional[float] = None,
    dark_matter_targets_GeV: Optional[Sequence[float]] = None,
) -> UnifiedTopologicalState:
    """
    Build a system-level state spanning geometry, two-sector theory, lambda, and applications.
    """
    point = np.asarray(list(x), dtype=float)
    geometry = None
    if surface is not None:
        if surface_u is None or surface_v is None:
            raise ValueError("surface_u and surface_v are required when surface is provided")
        geometry = compute_ccs_geometry_package(surface, surface_u, surface_v, step_size=surface_step_size)

    complex_curvature = field.complex_curvature_package(point, gauge_weight=gauge_weight)
    flow = field.cs_flow_package(point)
    two_sector = build_two_sector_package(
        field,
        point,
        planck_mass=planck_mass,
        topo_lambda=topo_lambda,
        gauge_weight=gauge_weight,
    )
    lambda_sector = build_lambda_sector_package(
        theta=theta,
        energy_ev=energy_ev,
        running_beta=running_beta,
    )
    dark_sector = None
    if dark_matter_targets_GeV:
        dark_sector = build_dark_matter_sector_package(dark_matter_targets_GeV)
    loops = build_loop_observables(field, point)

    return UnifiedTopologicalState(
        point=point,
        geometry=geometry,
        complex_curvature=complex_curvature,
        topological_flow=flow,
        two_sector=two_sector,
        lambda_sector=lambda_sector,
        dark_matter_sector=dark_sector,
        loop_observables=loops,
    )


__all__ = [
    "LoopObservables",
    "LambdaSectorPackage",
    "DarkMatterSectorPackage",
    "TwoSectorPackage",
    "UnifiedTopologicalState",
    "compute_cs_term",
    "build_loop_observables",
    "build_lambda_sector_package",
    "build_dark_matter_sector_package",
    "build_two_sector_package",
    "build_unified_topological_state",
]
