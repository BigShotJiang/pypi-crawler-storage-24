"""
Research registry for numerically packaged CCS / CFUT studies.

This registry intentionally avoids embedding user-local workspace paths.
Source provenance is represented by stable source references rather than
filesystem locations.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Dict, Iterable, List, Optional, Tuple

from .cfut_validation import (
    BoundaryCheckResult,
    BoundaryStatus,
    DataSourceGrade,
    EvidenceLevel,
    boundary_check,
)


class ResearchClaimStatus(str, Enum):
    ESTABLISHED_NUMERICAL = "established_numerical"
    EXCLUSIVE_SUPPORT = "exclusive_support"
    STRONG_EVIDENCE = "strong_evidence"
    COMPATIBILITY_ONLY = "compatibility_only"
    CONDITIONAL = "conditional"
    INTERNAL_ONLY = "internal_only"


@dataclass(frozen=True)
class ResearchEntry:
    slug: str
    title: str
    domain: str
    summary: str
    evidence_level: EvidenceLevel
    data_source_grade: DataSourceGrade
    claim_status: ResearchClaimStatus
    reliable: bool
    numerically_packaged: bool
    boundary: Optional[BoundaryCheckResult]
    formula_summary: Tuple[str, ...]
    api_symbols: Tuple[str, ...]
    key_results: Tuple[str, ...]
    limitations: Tuple[str, ...]
    source_refs: Tuple[str, ...]
    tags: Tuple[str, ...] = ()

    @property
    def evidence_label(self) -> str:
        return f"Level {int(self.evidence_level)}"

    @property
    def source_grade_label(self) -> str:
        return f"D{int(self.data_source_grade)}"

    def to_dict(self) -> Dict[str, object]:
        return {
            "slug": self.slug,
            "title": self.title,
            "domain": self.domain,
            "summary": self.summary,
            "evidence_level": int(self.evidence_level),
            "evidence_label": self.evidence_label,
            "data_source_grade": int(self.data_source_grade),
            "data_source_label": self.source_grade_label,
            "claim_status": self.claim_status.value,
            "reliable": self.reliable,
            "numerically_packaged": self.numerically_packaged,
            "boundary_summary": self.boundary.summary() if self.boundary else None,
            "formula_summary": list(self.formula_summary),
            "api_symbols": list(self.api_symbols),
            "key_results": list(self.key_results),
            "limitations": list(self.limitations),
            "source_refs": list(self.source_refs),
            "tags": list(self.tags),
        }


def _geometry_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Smooth parametric surfaces used for curvature benchmarks",
        b2_topology=BoundaryStatus.PASS,
        b2_note="Local surface topology and frame transport are explicit",
        b3_eft_truncation=BoundaryStatus.PASS,
        b3_note="Pure numerical differential geometry regime",
        b4_lambda_dependence=BoundaryStatus.PASS,
        b4_note="No lambda fitting is required",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Compared against analytical or reference geometry",
    )


def _dynamic_stall_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Continuum fluid setting",
        b2_topology=BoundaryStatus.PASS,
        b2_note="Winding count defined from pitch excursion",
        b3_eft_truncation=BoundaryStatus.PASS,
        b3_note="Weak topological correction regime",
        b4_lambda_dependence=BoundaryStatus.PASS,
        b4_note="Strongest ratio test removes lambda",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="External matched observations",
    )


def _friction_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Continuum interface and boundary-layer description",
        b2_topology=BoundaryStatus.WEAK_PASS,
        b2_note="Operational topology proxy exists but is not yet unique across all sub-branches",
        b3_eft_truncation=BoundaryStatus.PASS,
        b3_note="Low-order closure appears stable",
        b4_lambda_dependence=BoundaryStatus.WEAK_PASS,
        b4_note="Some sub-branches remain phenomenological",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Externally benchmarked tribology data",
    )


def _mass_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Discrete shell law is algebraically defined",
        b2_topology=BoundaryStatus.WEAK_PASS,
        b2_note="N reconstruction exists but unique first-principles generator is incomplete",
        b3_eft_truncation=BoundaryStatus.PASS,
        b3_note="Low-order shared-parameter shell law",
        b4_lambda_dependence=BoundaryStatus.PASS,
        b4_note="Uses fixed lambda0 convention",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Masses are external observables",
    )


def _transport_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Matched transport observables are smooth in regime",
        b2_topology=BoundaryStatus.PASS,
        b2_note="Chern-number observable is explicit",
        b3_eft_truncation=BoundaryStatus.PASS,
        b3_note="Low-energy topological transport regime",
        b4_lambda_dependence=BoundaryStatus.WEAK_PASS,
        b4_note="Compatibility constraints only, not unique no-fit closure",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Metrology observations are external",
    )


def _sunspot_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.WEAK_PASS,
        b1_note="Coarse-grained cycle statistics are smooth enough for comparison",
        b2_topology=BoundaryStatus.WEAK_PASS,
        b2_note="Operational topology link remains suggestive",
        b3_eft_truncation=BoundaryStatus.PASS,
        b3_note="Compatibility statistics only",
        b4_lambda_dependence=BoundaryStatus.WEAK_PASS,
        b4_note="No zero-parameter exclusive discriminator is packaged",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Public external observations",
    )


def _geomagnetic_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Continuous mantle-core heat-flow model",
        b2_topology=BoundaryStatus.WEAK_PASS,
        b2_note="Topology is structural rather than uniquely validated",
        b3_eft_truncation=BoundaryStatus.WEAK_PASS,
        b3_note="Reduced closure with calibrated beta",
        b4_lambda_dependence=BoundaryStatus.WEAK_PASS,
        b4_note="Observed-scale matching depends on calibration",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Observation chronology is external",
    )


def _two_sector_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Complex frame field and induced metric are smooth numerically",
        b2_topology=BoundaryStatus.PASS,
        b2_note="Gauge curvature and CS flow are operationally explicit",
        b3_eft_truncation=BoundaryStatus.WEAK_PASS,
        b3_note="Numerical proxy layer, not full theorem-closed system",
        b4_lambda_dependence=BoundaryStatus.WEAK_PASS,
        b4_note="Topological coupling enters explicitly in CS sector packaging",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Diagnostic state construction",
    )


def _lambda_boundary() -> BoundaryCheckResult:
    return boundary_check(
        b1_smoothness=BoundaryStatus.PASS,
        b1_note="Running and benchmark maps are smooth scalar functions",
        b2_topology=BoundaryStatus.WEAK_PASS,
        b2_note="Topological meaning is explicit but full uniqueness remains open",
        b3_eft_truncation=BoundaryStatus.WEAK_PASS,
        b3_note="Effective suppression and power-law running are model closures",
        b4_lambda_dependence=BoundaryStatus.WEAK_PASS,
        b4_note="This branch studies lambda directly",
        b5_observer_separation=BoundaryStatus.PASS,
        b5_note="Externally interpretable benchmark and comparison",
    )


_RESEARCH_REGISTRY: Dict[str, ResearchEntry] = {
    "ccs_geometry_core": ResearchEntry(
        slug="ccs_geometry_core",
        title="CCS Frame Geometry Package",
        domain="computable differential geometry",
        summary="Numerical CCS frame chain from surface frame to curvature invariants.",
        evidence_level=EvidenceLevel.STRONG_COMPATIBILITY,
        data_source_grade=DataSourceGrade.D1_GOLD,
        claim_status=ResearchClaimStatus.ESTABLISHED_NUMERICAL,
        reliable=True,
        numerically_packaged=True,
        boundary=_geometry_boundary(),
        formula_summary=(
            "compute_ccs_geometry_package(surface, u, v)",
            "K = det(S), H = 0.5 tr(S), R_1212 = K det(g)",
        ),
        api_symbols=(
            "compute_ccs_geometry_package",
            "compute_gaussian_curvature",
            "compute_mean_curvature",
            "IntrinsicGradientCurvatureCalculator",
        ),
        key_results=(
            "Sphere and torus invariants match analytical geometry in automated tests",
            "Non-orthogonal parametrizations recover orthonormal adapted frames",
        ),
        limitations=("Numerical geometry result, not a direct physical confirmation",),
        source_refs=(
            "openreview_ccs_submission",
            "ccs_geometry_numerical_verification",
            "ccs_frame_core_tests",
        ),
        tags=("geometry", "ccs", "curvature", "reliable"),
    ),
    "dynamic_stall": ResearchEntry(
        slug="dynamic_stall",
        title="Dynamic Stall Enhancement",
        domain="fluid dynamics",
        summary="Zero-parameter dynamic-stall enhancement with strongest current exclusionary evidence.",
        evidence_level=EvidenceLevel.EXCLUSIONARY,
        data_source_grade=DataSourceGrade.D1_GOLD,
        claim_status=ResearchClaimStatus.EXCLUSIVE_SUPPORT,
        reliable=True,
        numerically_packaged=True,
        boundary=_dynamic_stall_boundary(),
        formula_summary=(
            "F(k) = 1 + lambda_eff * N_max * (1 - exp(-k / k_c))",
            "N_max = Delta alpha_rad / (4 alpha)",
            "k_c = pi alpha",
        ),
        api_symbols=(
            "dynamic_stall_F",
            "dynamic_stall_N_max",
            "dynamic_stall_ratio_test",
            "DynamicStallValidator",
        ),
        key_results=(
            "Ratio-test error reported at about +0.13%",
            "Classical baseline fails directionally while CFUT remains stable",
        ),
        limitations=("Evidence is concentrated in matched oscillating-airfoil datasets",),
        source_refs=(
            "evidence_status_summary",
            "dynamic_stall_strong_evidence_chain_2026_03_19",
            "dynamic_stall_fk_formula_note",
        ),
        tags=("fluid", "dynamic_stall", "level3", "reliable"),
    ),
    "friction_branch": ResearchEntry(
        slug="friction_branch",
        title="Unified Friction Branch",
        domain="tribology / boundary flow",
        summary="Velocity-dependent friction and boundary-flow closures with strong evidence but not final exclusivity.",
        evidence_level=EvidenceLevel.STRONG_COMPATIBILITY,
        data_source_grade=DataSourceGrade.D2_RELIABLE,
        claim_status=ResearchClaimStatus.STRONG_EVIDENCE,
        reliable=True,
        numerically_packaged=True,
        boundary=_friction_boundary(),
        formula_summary=(
            "F_f(v) = [mu_k + (mu_s - mu_k)/(1 + (v/v_c)^p)] * N",
            "mu(v) = mu_0 * [1 + lambda(E) * N * (1 - exp(-v/v_char))] + mu_basic",
        ),
        api_symbols=("predict_friction_force", "predict_velocity_decay", "predict_viscosity_vs_velocity"),
        key_results=(
            "Wall-skin-friction baseline is stable in audits",
            "Surface-condition and internal-friction branches show strong candidate structure",
        ),
        limitations=(
            "Exclusive support is not yet adjudicated",
            "Some sub-branches still depend on operational topology proxies",
        ),
        source_refs=(
            "evidence_status_summary",
            "friction_high_standard_benchmark_conclusion_2026_03_20",
            "friction_evidence_update_2026_03_05",
        ),
        tags=("tribology", "fluid", "friction", "reliable"),
    ),
    "mass_sector": ResearchEntry(
        slug="mass_sector",
        title="Shared-Parameter Mass Sector",
        domain="particle mass phenomenology",
        summary="Shared-parameter winding-shell mass reconstruction with numerically packaged forward and inverse mapping.",
        evidence_level=EvidenceLevel.STRONG_COMPATIBILITY,
        data_source_grade=DataSourceGrade.D2_RELIABLE,
        claim_status=ResearchClaimStatus.STRONG_EVIDENCE,
        reliable=True,
        numerically_packaged=True,
        boundary=_mass_boundary(),
        formula_summary=("m = m_unit * N^2", "m_unit = (4 pi alpha)^2 / E0"),
        api_symbols=(
            "mass_from_winding",
            "infer_winding_from_mass",
            "proton_neutron_split",
            "compute_particle_masses",
            "nearest_dm_shell",
            "dm_shell_scan",
        ),
        key_results=(
            "Shared-parameter reconstruction is numerically strong for e, mu, tau, p, n",
            "n-p split is near the observed scale after local constraint cleanup",
        ),
        limitations=(
            "Independent first-principles generator for N_i is still incomplete",
            "Current support is reconstruction-heavy rather than blind prediction-heavy",
        ),
        source_refs=(
            "evidence_status_summary",
            "proton_mass_multiparticle_winding_attempt_2026_03_04",
            "independent_ni_unique_rule_from_quantum_topology_2026_03_04",
        ),
        tags=("particle", "mass", "reliable"),
    ),
    "dark_matter_shells": ResearchEntry(
        slug="dark_matter_shells",
        title="Dark-Matter Shell Probe",
        domain="mass-shell applications",
        summary="Nearest-shell probe interface for dark-matter-scale targets built on the shared winding-shell mass map.",
        evidence_level=EvidenceLevel.DIRECTIONAL,
        data_source_grade=DataSourceGrade.D3_CAUTION,
        claim_status=ResearchClaimStatus.CONDITIONAL,
        reliable=False,
        numerically_packaged=True,
        boundary=_mass_boundary(),
        formula_summary=("m = m_unit * N^2", "nearest shell chosen by inverse winding map"),
        api_symbols=("nearest_dm_shell", "dm_shell_scan", "build_dark_matter_sector_package"),
        key_results=("Callable shell scan exists for target mass scales",),
        limitations=("Independent dark-matter confirmation is not established",),
        source_refs=("cfut_formula_collection", "topological_physics_dm_shell_api"),
        tags=("dark_matter", "conditional"),
    ),
    "lambda_sector": ResearchEntry(
        slug="lambda_sector",
        title="Lambda Benchmark and Running Sector",
        domain="topological coupling",
        summary="Numerical packaging for lambda benchmark, low-energy effective suppression, and exploratory running ansatz.",
        evidence_level=EvidenceLevel.INTERNAL_CONSISTENCY,
        data_source_grade=DataSourceGrade.D2_RELIABLE,
        claim_status=ResearchClaimStatus.INTERNAL_ONLY,
        reliable=True,
        numerically_packaged=True,
        boundary=_lambda_boundary(),
        formula_summary=(
            "lambda_0 = theta * e^2 = 4 pi alpha theta",
            "lambda_eff(E) = lambda_0 exp(-E / E_ref)",
            "lambda(E) = lambda_0 (E / E0)^beta",
        ),
        api_symbols=(
            "lambda_reference_benchmark",
            "lambda_low_energy_effective",
            "lambda_power_law_running",
            "build_lambda_sector_package",
        ),
        key_results=("Benchmark convention and running models are encoded as stable APIs",),
        limitations=("Packaging and comparison layer, not a closed derivation of lambda",),
        source_refs=(
            "lambda_in_complexified_ccs_physical_method_2026_03_19",
            "lambda_running_as_effective_coupling_2026_03_19",
        ),
        tags=("lambda", "theory"),
    ),
    "two_sector_chain": ResearchEntry(
        slug="two_sector_chain",
        title="CCS to Two-Sector Unified Chain",
        domain="system architecture",
        summary="System-level packaging from CCS geometry to complex frame field, dual sectors, CS flow, lambda, dark-matter shell probes, and loop observables.",
        evidence_level=EvidenceLevel.INTERNAL_CONSISTENCY,
        data_source_grade=DataSourceGrade.D2_RELIABLE,
        claim_status=ResearchClaimStatus.ESTABLISHED_NUMERICAL,
        reliable=True,
        numerically_packaged=True,
        boundary=_two_sector_boundary(),
        formula_summary=(
            "G_CF = G_conf + i Q(F)",
            "LHS = 0.5 M_P^2 G_CF + i lambda /(32 pi^2) nabla_(i K_j)",
        ),
        api_symbols=(
            "ComplexFrameField",
            "compute_cs_term",
            "build_two_sector_package",
            "build_unified_topological_state",
            "build_loop_observables",
        ),
        key_results=("A single state object packages the current numerical theory chain",),
        limitations=("Architectural numerical layer; not every theorem-level claim is closed",),
        source_refs=(
            "complex_frame_theory_module",
            "unified_topological_physics_module",
            "system_topological_physics_design_note",
        ),
        tags=("architecture", "two_sector", "reliable"),
    ),
    "topological_transport": ResearchEntry(
        slug="topological_transport",
        title="Topological Transport Constraints",
        domain="quantum topology / transport metrology",
        summary="Quantum Hall and pumping-related topology package with strong constraints but no unique CFUT discriminator yet.",
        evidence_level=EvidenceLevel.DIRECTIONAL,
        data_source_grade=DataSourceGrade.D1_GOLD,
        claim_status=ResearchClaimStatus.COMPATIBILITY_ONLY,
        reliable=True,
        numerically_packaged=False,
        boundary=_transport_boundary(),
        formula_summary=("N = first Chern number / Berry-bundle topological index",),
        api_symbols=("WINDING_NUMBER_REGISTRY", "ChernNumber", "BerryPhase"),
        key_results=(
            "QAHE metrology imposes a tight upper bound in matched regimes",
            "Positive topological response is present but no robust no-fit invariant is packaged",
        ),
        limitations=("No exclusive-support claim should be made at present",),
        source_refs=(
            "evidence_status_summary",
            "topological_strong_evidence_2026_03_04",
            "topological_exclusivity_gaplist_2026_03_04",
        ),
        tags=("quantum", "transport", "constraints"),
    ),
    "sunspot_cycle": ResearchEntry(
        slug="sunspot_cycle",
        title="Sunspot Cycle Statistics",
        domain="solar-cycle compatibility",
        summary="Public statistical package for observed sunspot-cycle ranges, used as a compatibility filter rather than a direct confirmation.",
        evidence_level=EvidenceLevel.DIRECTIONAL,
        data_source_grade=DataSourceGrade.D1_GOLD,
        claim_status=ResearchClaimStatus.COMPATIBILITY_ONLY,
        reliable=True,
        numerically_packaged=True,
        boundary=_sunspot_boundary(),
        formula_summary=("Observed cycle envelope extracted from statistical series",),
        api_symbols=("sunspot_cycle_stats", "is_sunspot_period_compatible"),
        key_results=(
            "Median observed cycle is about 11.33 years in packaged statistics",
            "Compatibility gate is explicit and reusable in code",
        ),
        limitations=("Observational compatibility module, not a zero-parameter proof",),
        source_refs=("sunspot_cycle_evidence_note", "zenodo_doc_12_sunspot_cycle_evidence"),
        tags=("solar", "compatibility"),
    ),
    "geomagnetic_reversal": ResearchEntry(
        slug="geomagnetic_reversal",
        title="Geomagnetic Reversal Period Model",
        domain="geophysics",
        summary="Structural geomagnetic reversal-period model with callable public API and explicit calibration caveat.",
        evidence_level=EvidenceLevel.DIRECTIONAL,
        data_source_grade=DataSourceGrade.D2_RELIABLE,
        claim_status=ResearchClaimStatus.CONDITIONAL,
        reliable=False,
        numerically_packaged=True,
        boundary=_geomagnetic_boundary(),
        formula_summary=(
            "tau = (2 pi / alpha_rate) / sqrt(1 - beta * (B_tor/B_pol)^2)",
            "Q_CMB = Q0 * (v_sub/v_sub0)^3 * (1 + A_LIP/A_ref)",
        ),
        api_symbols=("predict_geomagnetic_reversal_period",),
        key_results=("Callable structural model exists for heat-flow-driven reversal timing",),
        limitations=(
            "Observed-scale matching requires beta calibration",
            "Should be treated as conditional structure rather than confirmed branch",
        ),
        source_refs=(
            "geomagnetic_reversal_geometric_topology_model",
            "geomagnetic_reversal_observation_comparison_2026_03_02",
        ),
        tags=("geophysics", "conditional"),
    ),
}


def get_research_entry(slug: str) -> ResearchEntry:
    try:
        return _RESEARCH_REGISTRY[slug]
    except KeyError as exc:
        raise KeyError(f"Unknown research entry: {slug}") from exc


def iter_research_entries(
    *,
    min_evidence_level: int = 0,
    reliable_only: bool = False,
    numerically_packaged_only: bool = False,
) -> Iterable[ResearchEntry]:
    for entry in _RESEARCH_REGISTRY.values():
        if int(entry.evidence_level) < int(min_evidence_level):
            continue
        if reliable_only and not entry.reliable:
            continue
        if numerically_packaged_only and not entry.numerically_packaged:
            continue
        yield entry


def list_research_entries(
    *,
    min_evidence_level: int = 0,
    reliable_only: bool = False,
    numerically_packaged_only: bool = False,
) -> List[ResearchEntry]:
    return list(
        iter_research_entries(
            min_evidence_level=min_evidence_level,
            reliable_only=reliable_only,
            numerically_packaged_only=numerically_packaged_only,
        )
    )


def summarize_research_registry(
    *,
    min_evidence_level: int = 0,
    reliable_only: bool = False,
) -> str:
    entries = list_research_entries(
        min_evidence_level=min_evidence_level,
        reliable_only=reliable_only,
    )
    if not entries:
        return "No research entries matched the requested filters."

    level_counts: Dict[int, int] = {}
    for entry in entries:
        level_counts[int(entry.evidence_level)] = level_counts.get(int(entry.evidence_level), 0) + 1

    lines = [
        f"Research entries: {len(entries)}",
        f"Reliable entries: {sum(1 for entry in entries if entry.reliable)}",
        f"Numerically packaged entries: {sum(1 for entry in entries if entry.numerically_packaged)}",
        "Evidence distribution: " + ", ".join(f"L{level}={count}" for level, count in sorted(level_counts.items())),
        "",
    ]
    for entry in entries:
        lines.append(
            f"- {entry.slug}: {entry.evidence_label}, {entry.claim_status.value}, "
            f"{'reliable' if entry.reliable else 'conditional'}"
        )
    return "\n".join(lines)


def research_registry_as_dicts(
    *,
    min_evidence_level: int = 0,
    reliable_only: bool = False,
    numerically_packaged_only: bool = False,
) -> List[Dict[str, object]]:
    return [
        entry.to_dict()
        for entry in list_research_entries(
            min_evidence_level=min_evidence_level,
            reliable_only=reliable_only,
            numerically_packaged_only=numerically_packaged_only,
        )
    ]


def get_reliable_research_entries(
    *,
    min_evidence_level: int = int(EvidenceLevel.STRONG_COMPATIBILITY),
) -> List[ResearchEntry]:
    return list_research_entries(
        min_evidence_level=min_evidence_level,
        reliable_only=True,
    )


__all__ = [
    "ResearchClaimStatus",
    "ResearchEntry",
    "get_research_entry",
    "iter_research_entries",
    "list_research_entries",
    "summarize_research_registry",
    "research_registry_as_dicts",
    "get_reliable_research_entries",
]
