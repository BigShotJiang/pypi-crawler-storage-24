from __future__ import annotations

import sys
from pathlib import Path

import pytest

from suvra import cli


@pytest.mark.parametrize(
    ("argv", "expected_exit", "stdout_contains", "stderr_contains"),
    [
        (["suvra", "policy", "list"], 0, "default", ""),
        (["suvra", "policy", "use", "missing-pack"], 1, "", "policy pack 'missing-pack' not found"),
    ],
)
def test_policy_cli_basic(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    argv: list[str],
    expected_exit: int,
    stdout_contains: str,
    stderr_contains: str,
) -> None:
    monkeypatch.setattr(sys, "argv", argv)
    with pytest.raises(SystemExit) as exc_info:
        cli.main()
    assert exc_info.value.code == expected_exit
    captured = capsys.readouterr()
    assert stdout_contains in captured.out
    assert stderr_contains in captured.err


def test_policy_init_creates_policy_yaml(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    out_path = tmp_path / "policy.yaml"
    monkeypatch.setattr(sys, "argv", ["suvra", "policy", "init", "--out", str(out_path)])
    with pytest.raises(SystemExit) as exc_info:
        cli.main()
    assert exc_info.value.code == 0
    assert out_path.exists()
    assert "Default policy pack" in out_path.read_text(encoding="utf-8")


def test_policy_use_copies_selected_pack(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    out_path = tmp_path / "custom-policy.yaml"
    monkeypatch.setattr(sys, "argv", ["suvra", "policy", "use", "coding", "--out", str(out_path)])
    with pytest.raises(SystemExit) as exc_info:
        cli.main()
    assert exc_info.value.code == 0
    assert out_path.exists()
    assert "Coding policy pack" in out_path.read_text(encoding="utf-8")


def test_policy_init_overwrite_protection(monkeypatch: pytest.MonkeyPatch, tmp_path: Path, capsys) -> None:
    out_path = tmp_path / "policy.yaml"
    out_path.write_text("existing", encoding="utf-8")
    monkeypatch.setattr(sys, "argv", ["suvra", "policy", "init", "--out", str(out_path)])
    with pytest.raises(SystemExit) as exc_info:
        cli.main()
    assert exc_info.value.code == 1
    assert out_path.read_text(encoding="utf-8") == "existing"
    captured = capsys.readouterr()
    assert "refusing to overwrite existing file" in captured.err
