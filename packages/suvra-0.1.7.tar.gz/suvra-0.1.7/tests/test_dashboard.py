from __future__ import annotations

import json
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )


def _write_policy_with_delete_approval(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    },
                    {
                        "id": "delete_requires_approval",
                        "effect": "needs_approval",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    },
                ],
            }
        )
    )


def _write_policy_with_delete_allow(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "allow_workspace_writes",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    },
                    {
                        "id": "allow_workspace_delete",
                        "effect": "allow",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    },
                ],
            }
        )
    )


def _create_pending_delete_approval(engine: EnforcementEngine, suffix: str = "1", actor: str = "tester") -> str:
    path = f"workspace/pending-{suffix}.txt"
    engine.execute(
        {
            "action_id": f"seed-write-{suffix}",
            "type": "fs.write_file",
            "params": {"path": path, "content": "hello"},
            "meta": {"actor": actor},
        }
    )
    pending = engine.execute(
        {
            "action_id": f"seed-delete-{suffix}",
            "type": "fs.delete_file",
            "params": {"path": path},
            "meta": {"actor": actor},
        }
    )
    return str(pending["approval_id"])


def test_dashboard_index_returns_200(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard")
            assert response.status_code == 200
            assert "Templates unavailable" not in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_shows_mode_banner_when_monitor(monkeypatch, tmp_path: Path) -> None:
    _write_policy(tmp_path)
    monkeypatch.setenv("SUVRA_MODE", "monitor")
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard")
            assert response.status_code == 200
            assert "Monitor mode: enforcement is NOT blocking." in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_hides_mode_banner_in_strict(monkeypatch, tmp_path: Path) -> None:
    _write_policy(tmp_path)
    monkeypatch.delenv("SUVRA_MODE", raising=False)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard")
            assert response.status_code == 200
            assert "Monitor mode: enforcement is NOT blocking." not in response.text
            assert "Disabled mode: policy is NOT evaluated." not in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_approvals_returns_200(tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        approval_id = _create_pending_delete_approval(app_main.engine, "a")
        app_main.engine.approve(approval_id, decided_by="admin", note="approved")
        approval_id = _create_pending_delete_approval(app_main.engine, "b")
        app_main.engine.deny(approval_id, decided_by="admin", note="denied")
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/approvals")
            assert response.status_code == 200
            assert "<pre>" not in response.text
            assert "Pending (" in response.text
            assert "Approved (" in response.text
            assert "Denied (" in response.text
            assert "All (" in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_approvals_all_filter_returns_200(tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        _create_pending_delete_approval(app_main.engine, "all")
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/approvals?status=all")
            assert response.status_code == 200
    finally:
        app_main.engine = old_engine


def test_dashboard_approvals_search_by_actor(tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        _create_pending_delete_approval(app_main.engine, "s1", actor="alice")
        _create_pending_delete_approval(app_main.engine, "s2", actor="bob")
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/approvals?q=alice")
            assert response.status_code == 200
            assert "alice" in response.text
            assert "bob" not in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_approvals_search_by_workspace_target(tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        _create_pending_delete_approval(app_main.engine, "workspace-search", actor="searcher")
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/approvals?q=workspace")
            assert response.status_code == 200
            assert "Delete file" in response.text
            assert "workspace/pending-workspace-search.txt" in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_audit_returns_200(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        app_main.engine.execute(
            {
                "action_id": "audit-ui-1",
                "type": "fs.write_file",
                "params": {"path": "workspace/audit-ui.txt", "content": "hello"},
                "meta": {"actor": "tester"},
            }
        )
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/audit")
            assert response.status_code == 200
            assert "<pre>" not in response.text
            assert '"action_id"' not in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_audit_pagination_and_search(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        for idx in range(25):
            app_main.engine.execute(
                {
                    "action_id": f"audit-page-{idx}",
                    "type": "fs.write_file",
                    "params": {"path": f"workspace/audit-page-{idx}.txt", "content": "hello"},
                    "meta": {"actor": f"actor-{idx % 2}"},
                }
            )

        with TestClient(app_main.app) as client:
            page1 = client.get("/dashboard/audit?page=1&page_size=10")
            assert page1.status_code == 200
            assert "Page 1 of" in page1.text

            page2 = client.get("/dashboard/audit?page=2&page_size=10")
            assert page2.status_code == 200

            search = client.get("/dashboard/audit?q=write")
            assert search.status_code == 200
            assert "Write file" in search.text
    finally:
        app_main.engine = old_engine


def test_dashboard_approve_action_updates_status(tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        approval_id = _create_pending_delete_approval(app_main.engine)
        with TestClient(app_main.app) as client:
            response = client.post(
                f"/dashboard/approvals/{approval_id}/approve",
                data={"decided_by": "admin", "note": "ok", "status": "pending", "limit": "100"},
                follow_redirects=False,
            )
            assert response.status_code in (302, 303)
            assert "msg=approved" in response.headers.get("location", "")

        approval = app_main.engine.get_approval(approval_id)
        assert approval["status"] == "approved"
    finally:
        app_main.engine = old_engine


def test_dashboard_deny_action_updates_status(tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        approval_id = _create_pending_delete_approval(app_main.engine)
        with TestClient(app_main.app) as client:
            response = client.post(
                f"/dashboard/approvals/{approval_id}/deny",
                data={"decided_by": "admin", "note": "no", "status": "pending", "limit": "100"},
                follow_redirects=False,
            )
            assert response.status_code in (302, 303)
            assert "msg=denied" in response.headers.get("location", "")

        approval = app_main.engine.get_approval(approval_id)
        assert approval["status"] == "denied"
    finally:
        app_main.engine = old_engine


def test_dashboard_approve_execute_runs_action(tmp_path: Path) -> None:
    _write_policy_with_delete_approval(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        suffix = "exec"
        approval_id = _create_pending_delete_approval(app_main.engine, suffix)
        assert tmp_path.joinpath(f"workspace/pending-{suffix}.txt").exists()
        with TestClient(app_main.app) as client:
            response = client.post(
                f"/dashboard/approvals/{approval_id}/approve_execute",
                data={"decided_by": "admin", "note": "ship it", "status": "pending", "limit": "100"},
                follow_redirects=False,
            )
            assert response.status_code in (302, 303)
            assert "msg=executed" in response.headers.get("location", "")

        assert not tmp_path.joinpath(f"workspace/pending-{suffix}.txt").exists()
        events = app_main.engine.list_audit(action_type="fs.delete_file", status="executed", limit=20)
        assert any(event.get("action_id") == f"seed-delete-{suffix}" for event in events)
    finally:
        app_main.engine = old_engine


def test_dashboard_rollback_restores_file(tmp_path: Path) -> None:
    _write_policy_with_delete_allow(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        app_main.engine.execute(
            {
                "action_id": "rb-write-1",
                "type": "fs.write_file",
                "params": {"path": "workspace/rb-demo.txt", "content": "rollback me"},
                "meta": {"actor": "tester"},
            }
        )
        app_main.engine.execute(
            {
                "action_id": "rb-delete-1",
                "type": "fs.delete_file",
                "params": {"path": "workspace/rb-demo.txt"},
                "meta": {"actor": "tester"},
            }
        )
        assert not tmp_path.joinpath("workspace/rb-demo.txt").exists()

        with TestClient(app_main.app) as client:
            response = client.post("/dashboard/rollback/rb-delete-1", follow_redirects=False)
            assert response.status_code in (302, 303)
            assert "msg=rolled_back" in response.headers.get("location", "")

        assert tmp_path.joinpath("workspace/rb-demo.txt").exists()
        rollback_events = app_main.engine.list_audit(action_type="rollback", status="rolled_back", limit=10)
        assert any(event.get("action_id") == "rb-delete-1" for event in rollback_events)
    finally:
        app_main.engine = old_engine


def test_dashboard_audit_displays_identity_fields(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        app_main.engine.execute(
            {
                "action_id": "audit-identity-ui-1",
                "type": "fs.write_file",
                "params": {"path": "workspace/audit-identity-ui.txt", "content": "hello"},
                "meta": {"actor": "tester"},
                "agent": "codex",
                "user": "alice",
                "role": "admin",
                "workspace": "prod",
                "environment": "server",
            }
        )
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/audit")
            assert response.status_code == 200
            assert "Agent" in response.text
            assert "codex" in response.text
            assert "User" in response.text
            assert "alice" in response.text
            assert "Workspace" in response.text
            assert "prod" in response.text
    finally:
        app_main.engine = old_engine


def test_dashboard_audit_identity_filters(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        for i, (agent, tenant_id, domain) in enumerate([
            ("codex", "tenant-a", "finance"),
            ("gpt-4o", "tenant-b", "research"),
        ]):
            app_main.engine.execute({
                "action_id": f"audit-filter-{i}",
                "type": "fs.write_file",
                "params": {"path": f"workspace/filter-{i}.txt", "content": "x"},
                "meta": {"actor": "tester"},
                "agent": agent,
                "tenant_id": tenant_id,
                "domain": domain,
            })

        with TestClient(app_main.app) as client:
            # Agent filter: only codex events
            r = client.get("/dashboard/audit?agent=codex")
            assert r.status_code == 200
            assert "codex" in r.text
            assert "gpt-4o" not in r.text

            # Tenant ID filter: only tenant-a events
            r = client.get("/dashboard/audit?tenant_id=tenant-a")
            assert r.status_code == 200
            assert "tenant-a" in r.text
            assert "tenant-b" not in r.text

            # Domain filter: only finance events
            r = client.get("/dashboard/audit?domain=finance")
            assert r.status_code == 200
            assert "finance" in r.text
            assert "research" not in r.text

            # Filter inputs are rendered in the HTML
            r = client.get("/dashboard/audit")
            assert "Agent" in r.text
            assert "Tenant ID" in r.text
            assert "Domain" in r.text
    finally:
        app_main.engine = old_engine


def test_dashboard_policy_scoped_browser(tmp_path: Path) -> None:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "10-global.yaml").write_text(json.dumps({
        "scope": {"level": "global"},
        "defaults": {"mode": "deny"},
        "rules": [{"id": "global-allow-write", "effect": "allow", "type": "fs.write_file",
                   "constraints": {"path_prefix": "workspace/"}}],
    }))
    (policies_dir / "20-tenant.yaml").write_text(json.dumps({
        "scope": {"level": "tenant", "tenant_id": "tenant-a"},
        "defaults": {"mode": "deny"},
        "rules": [{"id": "tenant-approve-delete", "effect": "needs_approval", "type": "fs.delete_file",
                   "constraints": {"path_prefix": "workspace/"}}],
    }))
    (policies_dir / "30-agent.yaml").write_text(json.dumps({
        "scope": {"level": "agent", "agent": "codex"},
        "defaults": {"mode": "deny"},
        "rules": [],
    }))

    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path, policy_path=policies_dir)
    try:
        with TestClient(app_main.app) as client:
            response = client.get("/dashboard/policy")
            assert response.status_code == 200

            # Scoped browser table is rendered
            assert "Scoped Policy Files" in response.text

            # All three files appear
            assert "10-global.yaml" in response.text
            assert "20-tenant.yaml" in response.text
            assert "30-agent.yaml" in response.text

            # Scope levels and identities are shown
            assert "global" in response.text
            assert "tenant" in response.text
            assert "tenant-a" in response.text
            assert "agent" in response.text
            assert "codex" in response.text

            # Rule IDs are shown in expanded rows
            assert "global-allow-write" in response.text
            assert "tenant-approve-delete" in response.text

            # Single-file hint is NOT shown in scoped mode
            assert "Single-file mode" not in response.text
    finally:
        app_main.engine = old_engine
