from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine


IDENTITY_PAYLOAD = {
    "meta": {"actor": "tester"},
    "agent": "codex",
    "user": "alice",
    "role": "admin",
    "workspace": "prod",
    "environment": "server",
    "labels": ["ops", "critical", "ops"],
}


def _write_policy(root: Path) -> None:
    root.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "identity_allow_write",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {
                            "path_prefix": "workspace/",
                            "max_bytes": 2048,
                            "agent": "codex",
                            "user": "alice",
                            "role": "admin",
                            "workspace": "prod",
                            "environment": "server",
                            "labels": ["critical", "ops"],
                        },
                    }
                ],
            }
        )
    )


def _audit_row(engine: EnforcementEngine, action_id: str) -> dict[str, object]:
    with sqlite3.connect(engine.audit.db_path) as conn:
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM audit_events WHERE action_id = ? ORDER BY event_id DESC LIMIT 1",
            (action_id,),
        ).fetchone()
    assert row is not None
    return dict(row)


def test_validate_api_accepts_top_level_identity_fields_end_to_end(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/validate",
                json={
                    "action_id": "api-identity-validate-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/api-identity-validate.txt", "content": "hello"},
                    **IDENTITY_PAYLOAD,
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        row = _audit_row(app_main.engine, "api-identity-validate-1")
        assert row["status"] == "validated"
        assert row["agent"] == "codex"
        assert row["user"] == "alice"
        assert row["role"] == "admin"
        assert row["workspace"] == "prod"
        assert row["environment"] == "server"
        assert json.loads(str(row["labels_json"])) == ["critical", "ops"]
    finally:
        app_main.engine = old_engine


def test_execute_api_accepts_top_level_identity_fields_end_to_end(tmp_path: Path) -> None:
    _write_policy(tmp_path)
    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path)
    try:
        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": "api-identity-execute-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/api-identity-execute.txt", "content": "hello"},
                    **IDENTITY_PAYLOAD,
                },
            )
        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        assert payload["status"] == "executed"
        assert (tmp_path / "workspace" / "api-identity-execute.txt").read_text() == "hello"
        row = _audit_row(app_main.engine, "api-identity-execute-1")
        assert row["status"] == "executed"
        assert row["agent"] == "codex"
        assert row["user"] == "alice"
        assert row["role"] == "admin"
        assert row["workspace"] == "prod"
        assert row["environment"] == "server"
        assert json.loads(str(row["labels_json"])) == ["critical", "ops"]
    finally:
        app_main.engine = old_engine
