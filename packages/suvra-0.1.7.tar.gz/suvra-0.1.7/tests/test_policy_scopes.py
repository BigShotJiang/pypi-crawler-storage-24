from __future__ import annotations

import json
from pathlib import Path

import pytest

from suvra.app import main as app_main
from suvra.core.engine import EnforcementEngine
from suvra.core.policy import PolicyEngine


def test_legacy_single_policy_file_still_works(tmp_path: Path) -> None:
    tmp_path.joinpath("policy.yaml").write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "legacy_allow",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 1024},
                    }
                ],
            }
        )
    )

    engine = PolicyEngine(policy_path=tmp_path / "policy.yaml")
    decision = engine.evaluate(
        {
            "type": "fs.write_file",
            "params": {"path": "workspace/legacy.txt", "content": "ok"},
            "meta": {"actor": "tester"},
        }
    )

    assert decision.decision == "allow"
    assert decision.rule_id == "legacy_allow"


def test_scoped_policy_directory_collects_applicable_policies_in_deterministic_order(tmp_path: Path) -> None:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "10-global.yaml").write_text(
        json.dumps(
            {
                "scope": {"level": "global"},
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "global_approval",
                        "effect": "needs_approval",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )
    (policies_dir / "20-tenant.yaml").write_text(
        json.dumps(
            {
                "scope": {"level": "tenant", "tenant_id": "tenant-a"},
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "tenant_allow",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )
    (policies_dir / "30-agent.yaml").write_text(
        json.dumps(
            {
                "scope": {"level": "agent", "agent": "codex"},
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "agent_deny",
                        "effect": "deny",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )

    engine = PolicyEngine(policy_path=policies_dir)

    tenant_only = engine.evaluate(
        {
            "type": "fs.write_file",
            "params": {"path": "workspace/tenant.txt", "content": "ok"},
            "meta": {"actor": "tester"},
            "tenant_id": "tenant-a",
        }
    )
    assert tenant_only.decision == "needs_approval"
    assert tenant_only.rule_id == "global_approval"

    tenant_and_agent = engine.evaluate(
        {
            "type": "fs.write_file",
            "params": {"path": "workspace/agent.txt", "content": "ok"},
            "meta": {"actor": "tester"},
            "tenant_id": "tenant-a",
            "agent": "codex",
        }
    )
    assert tenant_and_agent.decision == "needs_approval"
    assert tenant_and_agent.rule_id == "global_approval"


def test_scoped_policy_directory_defaults_to_deny_when_no_applicable_rule_matches(tmp_path: Path) -> None:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "10-global.yaml").write_text(json.dumps({"scope": {"level": "global"}, "defaults": {"mode": "deny"}, "rules": []}))
    (policies_dir / "20-tenant.yaml").write_text(
        json.dumps(
            {
                "scope": {"level": "tenant", "tenant_id": "tenant-a"},
                "defaults": {"mode": "allow"},
                "rules": [],
            }
        )
    )

    engine = PolicyEngine(policy_path=policies_dir)
    decision = engine.evaluate(
        {
            "type": "fs.write_file",
            "params": {"path": "workspace/no-rule.txt", "content": "ok"},
            "meta": {"actor": "tester"},
            "tenant_id": "tenant-a",
        }
    )
    assert decision.decision == "deny"


def test_scoped_policy_directory_rejects_unscoped_files(tmp_path: Path) -> None:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "10-global.yaml").write_text(
        json.dumps({"scope": {"level": "global"}, "defaults": {"mode": "deny"}, "rules": []})
    )
    (policies_dir / "20-legacy.yaml").write_text(
        json.dumps({"defaults": {"mode": "allow"}, "rules": []})
    )

    with pytest.raises(ValueError, match="scoped policy directories require every policy file to declare scope"):
        PolicyEngine(policy_path=policies_dir)


def test_scope_validation_requires_exact_scope_shape() -> None:
    with pytest.raises(ValueError, match="policy.scope.agent is required"):
        PolicyEngine.from_policy_data(
            {
                "scope": {"level": "agent"},
                "defaults": {"mode": "deny"},
                "rules": [],
            }
        )

    with pytest.raises(ValueError, match="unexpected fields"):
        PolicyEngine.from_policy_data(
            {
                "scope": {"level": "tenant", "tenant_id": "tenant-a", "workspace": "prod"},
                "defaults": {"mode": "deny"},
                "rules": [],
            }
        )


def test_execute_api_accepts_scope_request_context_fields(tmp_path: Path) -> None:
    policies_dir = tmp_path / "policies"
    policies_dir.mkdir()
    (policies_dir / "10-global.yaml").write_text(json.dumps({"scope": {"level": "global"}, "defaults": {"mode": "deny"}, "rules": []}))
    (policies_dir / "20-tenant.yaml").write_text(
        json.dumps(
            {
                "scope": {"level": "tenant", "tenant_id": "tenant-a"},
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "tenant_allow_write",
                        "effect": "allow",
                        "type": "fs.write_file",
                        "constraints": {"path_prefix": "workspace/", "max_bytes": 2048},
                    }
                ],
            }
        )
    )
    (policies_dir / "30-domain.yaml").write_text(
        json.dumps(
            {
                "scope": {"level": "domain", "domain": "finance"},
                "defaults": {"mode": "deny"},
                "rules": [],
            }
        )
    )

    old_engine = app_main.engine
    app_main.engine = EnforcementEngine(root=tmp_path, policy_path=policies_dir)
    try:
        from fastapi.testclient import TestClient

        with TestClient(app_main.app) as client:
            response = client.post(
                "/actions/execute",
                json={
                    "action_id": "api-scope-context-1",
                    "type": "fs.write_file",
                    "params": {"path": "workspace/scoped.txt", "content": "hello"},
                    "meta": {"actor": "tester"},
                    "tenant_id": "tenant-a",
                    "business_unit": "platform",
                    "domain": "finance",
                },
            )
            audit_response = client.get("/audit")
            csv_response = client.get("/audit.csv")

        assert response.status_code == 200
        payload = response.json()
        assert payload["decision"] == "allow"
        assert (tmp_path / "workspace" / "scoped.txt").read_text() == "hello"

        assert audit_response.status_code == 200
        audit_rows = audit_response.json()
        assert audit_rows[0]["tenant_id"] == "tenant-a"
        assert audit_rows[0]["business_unit"] == "platform"
        assert audit_rows[0]["domain"] == "finance"

        assert csv_response.status_code == 200
        assert "tenant_id,business_unit,domain" in csv_response.text
        assert "tenant-a,platform,finance" in csv_response.text
    finally:
        app_main.engine = old_engine


def test_approval_persists_scope_request_context_fields(tmp_path: Path) -> None:
    policy_path = tmp_path / "policy.yaml"
    policy_path.write_text(
        json.dumps(
            {
                "defaults": {"mode": "deny"},
                "rules": [
                    {
                        "id": "delete_needs_approval",
                        "effect": "needs_approval",
                        "type": "fs.delete_file",
                        "constraints": {"path_prefix": "workspace/"},
                    }
                ],
            }
        )
    )

    engine = EnforcementEngine(root=tmp_path, policy_path=policy_path)
    approval = engine.request_approval(
        {
            "action_id": "approval-scope-1",
            "type": "fs.delete_file",
            "params": {"path": "workspace/demo.txt"},
            "meta": {"actor": "tester"},
            "tenant_id": "tenant-a",
            "business_unit": "platform",
            "domain": "finance",
        }
    )

    stored = engine.get_approval(approval["approval_id"])
    assert stored["tenant_id"] == "tenant-a"
    assert stored["business_unit"] == "platform"
    assert stored["domain"] == "finance"


def test_repo_policies_directory_loads_as_valid_scoped_policies() -> None:
    """The policies/ directory shipped in the repo must load without errors."""
    repo_policies = Path(__file__).resolve().parents[1] / "policies"
    assert repo_policies.is_dir(), "policies/ directory must exist in repo root"

    engine = PolicyEngine(policy_path=repo_policies)

    assert len(engine.policies) >= 1, "policies/ must contain at least one scoped policy file"
    for lp in engine.policies:
        assert lp.scope_level is not None, f"{lp.path} must declare a scope level"
        assert not lp.legacy_unscoped, f"{lp.path} must not be an unscoped legacy file"

    # Confirm a global scope file is present
    levels = {lp.scope_level for lp in engine.policies}
    assert "global" in levels, "policies/ must include a global-scoped policy file"
