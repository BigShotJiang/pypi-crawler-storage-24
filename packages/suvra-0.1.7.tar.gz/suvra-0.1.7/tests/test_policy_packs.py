from __future__ import annotations

from importlib import resources
from pathlib import Path

import pytest

from suvra.core.policy import PolicyEngine
from suvra.core.policy_packs import copy_policy_pack, get_policy_pack_metadata, list_policy_packs, read_policy_pack


PACK_NAMES = ["coding", "default", "research"]


def test_list_policy_packs() -> None:
    packs = list_policy_packs()
    assert [item.name for item in packs] == PACK_NAMES
    assert all(item.description for item in packs)


def test_get_policy_pack_metadata() -> None:
    metadata = get_policy_pack_metadata("default")
    assert metadata.name == "default"
    assert metadata.package_path.endswith("default.yaml")


def test_read_policy_pack_loads_policy() -> None:
    raw = read_policy_pack("coding")
    assert "fs.write_file" in raw
    engine = PolicyEngine(policy_data=pytest.importorskip("yaml").safe_load(raw))
    decision = engine.evaluate(
        {
            "type": "http.request",
            "params": {"method": "GET", "url": "https://github.com/suvra-core/suvra"},
            "meta": {"actor": "tester"},
        }
    )
    assert decision.decision == "allow"


def test_copy_policy_pack(tmp_path: Path) -> None:
    out_path = tmp_path / "policy.yaml"
    written = copy_policy_pack("research", out_path)
    assert written == out_path
    assert out_path.exists()
    assert "Research policy pack" in out_path.read_text(encoding="utf-8")


def test_copy_policy_pack_refuses_overwrite_without_force(tmp_path: Path) -> None:
    out_path = tmp_path / "policy.yaml"
    out_path.write_text("existing", encoding="utf-8")
    with pytest.raises(FileExistsError):
        copy_policy_pack("default", out_path)


def test_pack_resources_available_via_importlib_resources() -> None:
    resources_root = resources.files("suvra.resources")
    packs_dir = resources_root / "policies" / "packs"
    assert packs_dir.is_dir()
    names = sorted(item.name[:-5] for item in packs_dir.iterdir() if item.name.endswith(".yaml"))
    assert names == PACK_NAMES
