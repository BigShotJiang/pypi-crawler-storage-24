from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional, Tuple, Union
from urllib.parse import urlparse

import json

from suvra.core.identity import IDENTITY_FIELDS, extract_identity, normalize_identity_value, normalize_labels

try:
    import yaml
except ModuleNotFoundError:
    yaml = None

TEMPLATE_DIR = Path(__file__).resolve().parents[1] / "policies" / "templates"
DEFAULT_TEMPLATE_NAME = "local_sandbox"
SCOPE_LEVEL_ORDER = ("global", "tenant", "business_unit", "domain", "workspace", "agent", "environment")
SCOPE_LEVEL_FIELDS = {
    "global": None,
    "tenant": "tenant_id",
    "business_unit": "business_unit",
    "domain": "domain",
    "workspace": "workspace",
    "agent": "agent",
    "environment": "environment",
}


@dataclass
class Decision:
    decision: str
    reasons: list[str]
    rule_id: Optional[str] = None
    constraints: Optional[dict[str, Any]] = None
    checks: Optional[list[dict[str, Any]]] = None


@dataclass
class LoadedPolicy:
    path: str
    defaults: dict[str, Any]
    rules: list[dict[str, Any]]
    scope: Optional[dict[str, Any]]
    scope_level: Optional[str]
    legacy_unscoped: bool = False


class PolicyEngine:
    def __init__(self, policy_path: Union[str, Path] = "policy.yaml", policy_data: Optional[dict[str, Any]] = None) -> None:
        self.policy_path = Path(policy_path)
        self.auto_created_template: Optional[str] = None
        self.policies: list[LoadedPolicy] = []
        if policy_data is not None:
            normalized = self._normalize_policy(policy_data)
            self.policy = normalized
            self.policies = [
                LoadedPolicy(
                    path=str(self.policy_path),
                    defaults=normalized["defaults"],
                    rules=normalized["rules"],
                    scope=normalized.get("scope"),
                    scope_level=(normalized.get("scope") or {}).get("level"),
                    legacy_unscoped=normalized.get("scope") is None,
                )
            ]
        else:
            self.policy = self._load_policy()

    @classmethod
    def from_policy_data(cls, policy_data: dict[str, Any]) -> "PolicyEngine":
        return cls(policy_path="policy.yaml", policy_data=policy_data)

    @staticmethod
    def template_dir() -> Path:
        return TEMPLATE_DIR

    @classmethod
    def available_templates(cls) -> list[dict[str, str]]:
        template_dir = cls.template_dir()
        if not template_dir.exists():
            return []
        items: list[dict[str, str]] = []
        for path in sorted(template_dir.glob("*.yaml")):
            items.append({"name": path.stem, "path": str(path.resolve())})
        return items

    @classmethod
    def read_template(cls, name: str) -> str:
        path = cls.template_dir() / f"{name}.yaml"
        if not path.exists():
            raise ValueError(f"policy template '{name}' not found")
        return path.read_text()

    @staticmethod
    def _normalize_policy(data: Any) -> dict[str, Any]:
        if not isinstance(data, dict):
            raise ValueError("policy must be an object")

        defaults = data.get("defaults", {}) or {}
        if not isinstance(defaults, dict):
            raise ValueError("policy.defaults must be an object")
        default_mode = str(defaults.get("mode", "deny"))
        if default_mode not in {"allow", "deny"}:
            raise ValueError("policy.defaults.mode must be 'allow' or 'deny'")

        rules = data.get("rules", [])
        if rules is None:
            rules = []
        if not isinstance(rules, list):
            raise ValueError("policy.rules must be a list")
        for idx, rule in enumerate(rules):
            if not isinstance(rule, dict):
                raise ValueError(f"policy.rules[{idx}] must be an object")

        scope = data.get("scope")
        normalized_scope = PolicyEngine._normalize_scope(scope)

        normalized = dict(data)
        normalized["defaults"] = dict(defaults)
        normalized["defaults"]["mode"] = default_mode
        normalized["rules"] = rules
        if normalized_scope is None:
            normalized.pop("scope", None)
        else:
            normalized["scope"] = normalized_scope
        return normalized

    @staticmethod
    def _normalize_scope(scope: Any) -> Optional[dict[str, str]]:
        if scope is None:
            return None
        if not isinstance(scope, dict):
            raise ValueError("policy.scope must be an object")

        level = normalize_identity_value(scope.get("level"))
        if level is None or level not in SCOPE_LEVEL_FIELDS:
            raise ValueError(
                "policy.scope.level must be one of: global, tenant, business_unit, domain, workspace, agent, environment"
            )

        expected_field = SCOPE_LEVEL_FIELDS[level]
        allowed_fields = {"level"}
        normalized: dict[str, str] = {"level": level}

        if expected_field is not None:
            allowed_fields.add(expected_field)
            raw_value = scope.get(expected_field)
            normalized_value = normalize_identity_value(raw_value)
            if normalized_value is None:
                raise ValueError(f"policy.scope.{expected_field} is required when policy.scope.level is '{level}'")
            normalized[expected_field] = normalized_value

        unknown_fields = sorted(set(scope.keys()) - allowed_fields)
        if unknown_fields:
            raise ValueError(f"policy.scope contains unexpected fields: {', '.join(unknown_fields)}")

        return normalized

    def _load_policy_document(self, path: Path) -> LoadedPolicy:
        raw = path.read_text()
        if yaml is not None:
            data = yaml.safe_load(raw) or {}
        else:
            data = json.loads(raw) if raw.strip() else {}
        normalized = self._normalize_policy(data)
        return LoadedPolicy(
            path=str(path.resolve()),
            defaults=normalized["defaults"],
            rules=normalized["rules"],
            scope=normalized.get("scope"),
            scope_level=(normalized.get("scope") or {}).get("level"),
            legacy_unscoped=normalized.get("scope") is None,
        )

    def _load_policy(self) -> dict[str, Any]:
        if not self.policy_path.exists():
            self._create_policy_from_default_template()

        if self.policy_path.is_dir():
            self.policies = self._load_policy_directory(self.policy_path)
            return self._effective_policy_data(self.policies)

        loaded = self._load_policy_document(self.policy_path)
        self.policies = [loaded]
        return self._effective_policy_data([loaded])

    def _load_policy_directory(self, directory: Path) -> list[LoadedPolicy]:
        candidates: list[Path] = []
        for pattern in ("*.yaml", "*.yml", "*.json"):
            candidates.extend(directory.glob(pattern))
        if not candidates:
            raise ValueError(f"no policy files found in directory: {directory}")

        loaded: list[LoadedPolicy] = []
        unscoped_paths: list[str] = []
        for path in sorted({candidate.resolve() for candidate in candidates}, key=lambda item: str(item)):
            policy = self._load_policy_document(path)
            loaded.append(policy)
            if policy.legacy_unscoped:
                unscoped_paths.append(policy.path)
            elif policy.defaults.get("mode") == "allow":
                print(
                    f"[suvra] warning: policy {policy.path} declares defaults.mode=allow "
                    "but this is ignored in directory mode; the combined default is always deny"
                )
        if unscoped_paths:
            raise ValueError(
                "scoped policy directories require every policy file to declare scope; "
                f"unscoped files found: {', '.join(unscoped_paths)}"
            )
        return loaded

    @staticmethod
    def _effective_policy_data(policies: list[LoadedPolicy]) -> dict[str, Any]:
        if len(policies) == 1 and policies[0].legacy_unscoped:
            return {
                "defaults": dict(policies[0].defaults),
                "rules": list(policies[0].rules),
            }

        combined_rules: list[dict[str, Any]] = []
        for policy in policies:
            combined_rules.extend(policy.rules)
        return {
            "defaults": {"mode": "deny"},
            "rules": combined_rules,
        }

    def _create_policy_from_default_template(self) -> None:
        parent = self.policy_path.parent
        if parent != Path("."):
            parent.mkdir(parents=True, exist_ok=True)
        template_text = self.read_template(DEFAULT_TEMPLATE_NAME)
        self.policy_path.write_text(template_text)
        self.auto_created_template = DEFAULT_TEMPLATE_NAME
        print(f"[suvra] created policy at {self.policy_path} from template {DEFAULT_TEMPLATE_NAME}")

    def reload(self) -> None:
        self.policy = self._load_policy()

    def evaluate(self, action: dict[str, Any]) -> Decision:
        action_type = action.get("type")
        params = action.get("params", {})
        identity = extract_identity(action)
        applicable_policies = self._applicable_policies(identity)
        effective_policy = self._effective_policy_data(applicable_policies)

        matching: list[tuple[dict[str, Any], list[str], list[dict[str, Any]]]] = []
        first_type_match: Optional[Tuple[dict[str, Any], list[str], list[dict[str, Any]]]] = None

        for rule in effective_policy.get("rules", []):
            if rule.get("type") != action_type:
                continue
            ok, reasons, checks = self._constraints_match(rule.get("constraints", {}), params, str(action_type or ""), identity)
            if first_type_match is None:
                first_type_match = (rule, reasons, checks)
            if ok:
                matching.append((rule, reasons, checks))

        if matching:
            rule, reasons, checks = matching[0]
            effect = str(rule.get("effect", "deny"))
            if effect not in {"allow", "deny", "needs_approval"}:
                effect = "deny"
                reasons = [*reasons, "invalid effect in policy rule; failing closed to deny"]
            return Decision(
                decision=effect,
                reasons=[f"matched rule {rule.get('id', 'unknown')}", *reasons],
                rule_id=rule.get("id"),
                constraints=rule.get("constraints", {}),
                checks=checks,
            )

        if first_type_match is not None:
            rule, reasons, checks = first_type_match
            default_mode = effective_policy.get("defaults", {}).get("mode", "deny")
            return Decision(
                decision="allow" if default_mode == "allow" else "deny",
                reasons=[
                    f"constraints failed for rule {rule.get('id', 'unknown')}",
                    *reasons,
                    f"default mode is {default_mode}",
                ],
                rule_id=rule.get("id"),
                constraints=rule.get("constraints", {}),
                checks=checks,
            )

        default_mode = effective_policy.get("defaults", {}).get("mode", "deny")
        return Decision(
            decision="allow" if default_mode == "allow" else "deny",
            reasons=["no rule for action type", f"default mode is {default_mode}"],
            rule_id=None,
            constraints=None,
            checks=[],
        )

    def _applicable_policies(self, identity: dict[str, Any]) -> list[LoadedPolicy]:
        if len(self.policies) == 1 and self.policies[0].legacy_unscoped:
            return list(self.policies)

        applicable: list[tuple[int, str, LoadedPolicy]] = []
        for policy in self.policies:
            if not self._scope_matches(policy.scope, identity):
                continue
            level = policy.scope_level or "global"
            applicable.append((SCOPE_LEVEL_ORDER.index(level), policy.path, policy))
        applicable.sort(key=lambda item: (item[0], item[1]))
        return [item[2] for item in applicable]

    @staticmethod
    def _scope_matches(scope: Optional[dict[str, str]], identity: dict[str, Any]) -> bool:
        if scope is None:
            return True
        level = scope["level"]
        if level == "global":
            return True
        expected_field = SCOPE_LEVEL_FIELDS[level]
        if expected_field is None:
            return True
        expected_value = normalize_identity_value(scope.get(expected_field))
        actual_value = normalize_identity_value(identity.get(expected_field))
        return actual_value == expected_value and expected_value is not None

    def _constraints_match(
        self,
        constraints: dict[str, Any],
        params: dict[str, Any],
        action_type: str,
        identity: dict[str, Any],
    ) -> tuple[bool, list[str], list[dict[str, Any]]]:
        reasons: list[str] = []
        checks: list[dict[str, Any]] = []
        ok_all = True

        def _record(name: str, ok: bool, detail: str) -> None:
            nonlocal ok_all
            checks.append({"name": name, "ok": ok, "detail": detail})
            if not ok:
                ok_all = False

        path_prefix = constraints.get("path_prefix")
        if path_prefix is not None:
            path_value = str(params.get("path", ""))
            is_ok = path_value.startswith(path_prefix)
            if is_ok:
                reasons.append(f"path_prefix={path_prefix}")
                _record("path_prefix", True, f"expected prefix {path_prefix} and got {path_value}")
            else:
                reasons.append(f"path '{path_value}' does not start with '{path_prefix}'")
                _record("path_prefix", False, f"expected prefix {path_prefix} but got {path_value}")

        working_dir_prefix = constraints.get("working_dir_prefix")
        if working_dir_prefix is not None:
            wd = str(params.get("cwd") or params.get("working_dir") or "")
            is_ok = wd.startswith(working_dir_prefix)
            if is_ok:
                reasons.append(f"working_dir_prefix={working_dir_prefix}")
                _record("working_dir_prefix", True, f"expected prefix {working_dir_prefix} and got {wd}")
            else:
                reasons.append(f"working_dir '{wd}' does not start with '{working_dir_prefix}'")
                _record("working_dir_prefix", False, f"expected prefix {working_dir_prefix} but got {wd}")

        method = constraints.get("method")
        if method is not None:
            action_method = str(params.get("method", "")).upper()
            expected = str(method).upper()
            is_ok = action_method == expected
            if is_ok:
                reasons.append(f"method={method}")
                _record("method", True, f"expected {expected} and got {action_method}")
            else:
                reasons.append(f"method '{action_method}' != '{method}'")
                _record("method", False, f"expected {expected} but got {action_method}")

        allow_domains = constraints.get("allow_domains")
        if allow_domains is not None:
            parsed = urlparse(str(params.get("url", "")))
            domain = parsed.hostname or ""
            is_ok = domain in allow_domains
            if is_ok:
                reasons.append(f"allow_domains={allow_domains}")
                _record("allow_domains", True, f"domain {domain} is allowlisted")
            else:
                reasons.append(f"domain '{domain}' not allowlisted")
                _record("allow_domains", False, f"domain {domain} not in {allow_domains}")

        host_in = constraints.get("host_in")
        if host_in is not None:
            parsed = urlparse(str(params.get("url", "")))
            domain = parsed.hostname or ""
            is_ok = domain in host_in
            if is_ok:
                reasons.append(f"host_in={host_in}")
                _record("host_in", True, f"hostname {domain} in {host_in}")
            else:
                reasons.append(f"hostname '{domain}' not in required hosts")
                _record("host_in", False, f"hostname {domain} not in {host_in}")

        host_prefix = constraints.get("host_prefix")
        if host_prefix is not None:
            parsed = urlparse(str(params.get("url", "")))
            domain = parsed.hostname or ""
            is_ok = domain.startswith(str(host_prefix))
            if is_ok:
                reasons.append(f"host_prefix={host_prefix}")
                _record("host_prefix", True, f"hostname {domain} starts with {host_prefix}")
            else:
                reasons.append(f"hostname '{domain}' does not start with '{host_prefix}'")
                _record("host_prefix", False, f"hostname {domain} does not start with {host_prefix}")

        for field in IDENTITY_FIELDS:
            expected_value = constraints.get(field)
            if expected_value is None:
                continue
            expected = normalize_identity_value(expected_value)
            actual = normalize_identity_value(identity.get(field))
            is_ok = actual == expected and expected is not None
            if is_ok:
                reasons.append(f"{field}={expected}")
                _record(field, True, f"expected {expected} and got {actual}")
            else:
                reasons.append(f"{field} {actual!r} != {expected!r}")
                _record(field, False, f"expected {expected} but got {actual}")

        required_labels = constraints.get("labels")
        if required_labels is not None:
            expected_labels = normalize_labels(required_labels)
            actual_labels = normalize_labels(identity.get("labels"))
            missing = [label for label in expected_labels if label not in actual_labels]
            is_ok = not missing
            if is_ok:
                reasons.append(f"labels={expected_labels}")
                _record("labels", True, f"required labels present in {actual_labels}")
            else:
                reasons.append(f"labels missing required values: {missing}")
                _record("labels", False, f"missing {missing} from {actual_labels}")

        allow_commands = constraints.get("allow_commands")
        if allow_commands is not None:
            cmd = str(params.get("command", ""))
            is_ok = cmd in allow_commands
            if is_ok:
                reasons.append("allow_commands matched")
                _record("allow_commands", True, f"command {cmd} is allowed")
            else:
                reasons.append(f"command '{cmd}' not allowed")
                _record("allow_commands", False, f"command {cmd} not in {allow_commands}")

        if action_type == "email.delete":
            message_id = str(params.get("message_id", "")).strip()
            has_message_id = bool(message_id)
            if has_message_id:
                _record("message_id", True, "message_id provided")
            else:
                reasons.append("message_id is required for email.delete")
                _record("message_id", False, "message_id is required")

        allow_providers = constraints.get("allow_providers")
        if allow_providers is not None:
            provider = str(params.get("provider", "")).strip().lower()
            allowed = {str(value).strip().lower() for value in allow_providers}
            is_ok = provider in allowed
            if is_ok:
                reasons.append(f"allow_providers={allow_providers}")
                _record("allow_providers", True, f"provider {provider} is allowed")
            else:
                reasons.append(f"provider '{provider}' not allowlisted")
                _record("allow_providers", False, f"provider {provider} not in {sorted(allowed)}")

        allow_mailboxes = constraints.get("allow_mailboxes")
        if allow_mailboxes is not None:
            mailbox = str(params.get("mailbox", "")).strip().lower()
            allowed = {str(value).strip().lower() for value in allow_mailboxes}
            is_ok = mailbox in allowed
            if is_ok:
                reasons.append(f"allow_mailboxes={allow_mailboxes}")
                _record("allow_mailboxes", True, f"mailbox {mailbox} is allowed")
            else:
                reasons.append(f"mailbox '{mailbox}' not allowlisted")
                _record("allow_mailboxes", False, f"mailbox {mailbox} not in {sorted(allowed)}")

        allow_names = constraints.get("allow_names")
        if allow_names is not None:
            name = str(params.get("name", ""))
            is_ok = name in allow_names
            if is_ok:
                reasons.append(f"allow_names={allow_names}")
                _record("allow_names", True, f"name {name} is allowed")
            else:
                reasons.append(f"name '{name}' not allowlisted")
                _record("allow_names", False, f"name {name} not in {allow_names}")

        max_bytes = constraints.get("max_bytes")
        if max_bytes is not None:
            content = params.get("content", "")
            size = len(str(content).encode("utf-8"))
            limit = int(max_bytes)
            is_ok = size <= limit
            if is_ok:
                reasons.append(f"max_bytes={max_bytes}")
                _record("max_bytes", True, f"content size {size} <= {limit}")
            else:
                reasons.append(f"content size {size} > max_bytes {max_bytes}")
                _record("max_bytes", False, f"content size {size} > {limit}")

        timeout_seconds = constraints.get("timeout_seconds")
        if timeout_seconds is not None:
            timeout = float(params.get("timeout_seconds", timeout_seconds))
            limit = float(timeout_seconds)
            is_ok = timeout <= limit
            if is_ok:
                reasons.append(f"timeout_seconds<={timeout_seconds}")
                _record("timeout_seconds", True, f"timeout {timeout} <= {limit}")
            else:
                reasons.append(f"timeout {timeout} > allowed {timeout_seconds}")
                _record("timeout_seconds", False, f"timeout {timeout} > {limit}")

        return ok_all, reasons, checks
