from __future__ import annotations

from typing import Any, Optional

IDENTITY_FIELDS = (
    "agent",
    "user",
    "role",
    "workspace",
    "environment",
    "tenant_id",
    "business_unit",
    "domain",
)


def normalize_identity_value(value: Any) -> Optional[str]:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def normalize_labels(labels: Any) -> list[str]:
    if labels is None:
        return []
    if isinstance(labels, (str, bytes)):
        items = [labels]
    elif isinstance(labels, (list, tuple, set)):
        items = list(labels)
    else:
        items = [labels]

    normalized: list[str] = []
    seen: set[str] = set()
    for item in items:
        value = normalize_identity_value(item)
        if value is None or value in seen:
            continue
        seen.add(value)
        normalized.append(value)
    normalized.sort()
    return normalized


def extract_identity(action: dict[str, Any]) -> dict[str, Any]:
    identity: dict[str, Any] = {}
    for field in IDENTITY_FIELDS:
        value = normalize_identity_value(action.get(field))
        if value is not None:
            identity[field] = value
    labels = normalize_labels(action.get("labels"))
    if labels:
        identity["labels"] = labels
    return identity


def apply_identity(action: dict[str, Any]) -> dict[str, Any]:
    normalized = dict(action)
    for field in IDENTITY_FIELDS:
        value = normalize_identity_value(normalized.get(field))
        if value is None:
            normalized.pop(field, None)
        else:
            normalized[field] = value
    labels = normalize_labels(normalized.get("labels"))
    if labels:
        normalized["labels"] = labels
    else:
        normalized.pop("labels", None)
    return normalized
