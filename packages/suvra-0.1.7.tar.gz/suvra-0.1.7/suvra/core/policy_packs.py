from __future__ import annotations

from dataclasses import dataclass
from importlib import resources
from pathlib import Path


@dataclass(frozen=True)
class PolicyPackInfo:
    name: str
    package_path: str
    description: str


_DEFAULT_DESCRIPTIONS = {
    "default": "Safe deny-by-default starter policy for local file writes, approval-gated deletes, and narrow HTTP GET access.",
    "coding": "Coding-oriented starter policy with workspace writes, approval-gated deletes, narrow shell simulation rules, and common docs/package hosts.",
    "research": "Research-oriented starter policy for notes, read-only web fetches, and approval-gated or denied sensitive actions.",
}


def _packs_root():
    return resources.files("suvra.resources") / "policies" / "packs"


def list_policy_packs() -> list[PolicyPackInfo]:
    root = _packs_root()
    items: list[PolicyPackInfo] = []
    for entry in sorted(root.iterdir(), key=lambda item: item.name):
        if not entry.name.endswith(".yaml"):
            continue
        name = entry.name[:-5]
        items.append(
            PolicyPackInfo(
                name=name,
                package_path=f"suvra.resources/policies/packs/{entry.name}",
                description=_DEFAULT_DESCRIPTIONS.get(name, f"Built-in policy pack '{name}'."),
            )
        )
    return items


def get_policy_pack_metadata(name: str) -> PolicyPackInfo:
    for item in list_policy_packs():
        if item.name == name:
            return item
    raise ValueError(f"policy pack '{name}' not found")


def read_policy_pack(name: str) -> str:
    pack_path = _packs_root() / f"{name}.yaml"
    if not pack_path.is_file():
        raise ValueError(f"policy pack '{name}' not found")
    return pack_path.read_text(encoding="utf-8")


def copy_policy_pack(name: str, destination: Path, *, force: bool = False) -> Path:
    target = Path(destination)
    if target.exists() and not force:
        raise FileExistsError(f"refusing to overwrite existing file: {target}")
    if target.parent != Path("."):
        target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(read_policy_pack(name), encoding="utf-8")
    return target
