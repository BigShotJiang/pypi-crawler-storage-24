from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.get_api_v1_images_response_200_images_item import GetApiV1ImagesResponse200ImagesItem


T = TypeVar("T", bound="GetApiV1ImagesResponse200")


@_attrs_define
class GetApiV1ImagesResponse200:
    """
    Attributes:
        images (list[GetApiV1ImagesResponse200ImagesItem]):
    """

    images: list[GetApiV1ImagesResponse200ImagesItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        images = []
        for images_item_data in self.images:
            images_item = images_item_data.to_dict()
            images.append(images_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "images": images,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_api_v1_images_response_200_images_item import GetApiV1ImagesResponse200ImagesItem

        d = dict(src_dict)
        images = []
        _images = d.pop("images")
        for images_item_data in _images:
            images_item = GetApiV1ImagesResponse200ImagesItem.from_dict(images_item_data)

            images.append(images_item)

        get_api_v1_images_response_200 = cls(
            images=images,
        )

        get_api_v1_images_response_200.additional_properties = d
        return get_api_v1_images_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
