import sys
import os
from pathlib import Path
import importlib

VERSION = "1.0.0"

# Variable global para que ingesta_hibrida sepa si debe ser Batch o Stream automáticamente en tests
_GLOBAL_IS_TEST_RUN = False

def get_checkpoint_base(env_suffix: str = "_dev") -> str:

    """

    Retorna la ruta base para checkpoints de streaming.

    Usa Unity Catalog Volumes en lugar de DBFS /tmp (serverless no tiene acceso a DBFS /tmp).

    Args:

        env_suffix: Sufijo de ambiente ("_dev", "_prod", etc.)

    Returns:

        Ruta base para checkpoints (ej: "dbfs:/Volumes/bronze_dev/temporary/checkpoints")

    Override:

        Configurar variable de entorno ELT_CHECKPOINT_BASE para usar otra ruta.

    """

    base = os.getenv("ELT_CHECKPOINT_BASE")

    if base:

        return base.rstrip("/")

    # Default: Unity Catalog Volume compartido

    return f"dbfs:/Volumes/bronze{env_suffix}/temporary/checkpoints"

def get_schema_location_base(env_suffix: str = "_dev") -> str:

    """

    Retorna la ruta base para schema location de Auto Loader.

    Args:

        env_suffix: Sufijo de ambiente ("_dev", "_prod", etc.)

    Returns:

        Ruta base para schema locations

    """

    base = os.getenv("ELT_SCHEMA_BASE")

    if base:

        return base.rstrip("/")

    # Usa la misma base que checkpoints + /schema

    checkpoint_base = get_checkpoint_base(env_suffix)

    return f"{checkpoint_base}/schema"

class NotebookContext:

    def __init__(self, env, is_local, is_test_run=False, spark=None, dlt=None):
        self.env = env
        self.is_local = is_local
        self.is_test_run = is_test_run
        self.spark = spark
        self.dlt = dlt

def init_notebook():

    """

    Inicializa el entorno del notebook.

    1. Agrega src/ al sys.path

    2. Detecta entorno (Local vs Nube) y mockea DLT si es necesario.

    3. Retorna un objeto Contexto con {env, is_local, dlt, spark}.

    """

    # 1. SETUP PATH DE PROYECTO

    try:

        # Intenta usar __file__ si se importa como modulo

        current_path = Path(__file__).resolve().parent

    except NameError:

        # En notebook interactivo usa cwd

        current_path = Path(os.getcwd())

    project_root = current_path

    for _ in range(5):

        if (project_root / "src").exists():

            break

        project_root = project_root.parent

    if str(project_root) not in sys.path:

        sys.path.insert(0, str(project_root))

        print(f"✅ Root agregado al path: {project_root}")

    is_local = False
    is_test_run = False
    spark_session = None
    dlt_module = None
    env_suffix = "_dev" 

    # 2. DETECCION DE SPARK (NUBE/CONNECT)
    try:
        import IPython
        ip = IPython.get_ipython()
        if ip and ip.user_ns.get('spark') is not None:
            spark_session = ip.user_ns['spark']
            try: 
                env_suffix = spark_session.conf.get("env_suffix", "_dev")
            except: 
                pass
    except:
        pass

    # 3. DETECCION DE DLT & TEST MODE
    try:
        # En Databricks real o local con dlt instalado
        import dlt
        dlt_module = dlt
        
        # Si NO estamos en una DLT Pipeline (no existe la variable de conf dlt.pipelineId)
        # o si estamos en un notebook interactivo, lo tratamos como "Test Run"
        if spark_session:
            try:
                # Si esta variable NO existe, lanza excepcion -> estamos en workspace manual
                spark_session.conf.get("pipelines.id")
                is_test_run = False # Es un pipeline real
            except:
                is_test_run = True # Es el workspace pero ejecucion manual
        
    except ImportError:
        # ENTORNO LOCAL SIN DLT
        is_local = True
        is_test_run = True
        
        class DltMock:
            def table(self, *a, **k): return lambda f: f
            def view(self, *a, **k): return lambda f: f
            def expect(self, *a, **k): return lambda f: f
            def expect_or_drop(self, *a, **k): return lambda f: f
            def create_streaming_table(self, *a, **k): pass
            def apply_changes(self, *a, **k): pass
            
        dlt_module = DltMock()
        
    global _GLOBAL_IS_TEST_RUN
    _GLOBAL_IS_TEST_RUN = is_test_run

    if is_local:
        print(f"⚠️  Modo Local: 'dlt' simulado. Usando env='{env_suffix}'")
    elif is_test_run:
        print(f"🏗️  Modo Workspace (TEST): Entorno interactivo detectado. Usando env='{env_suffix}'")
    
    print(f"📦 dbx-elt-utils v{VERSION} inicializado.")

    return NotebookContext(env=env_suffix, is_local=is_local, is_test_run=is_test_run, dlt=dlt_module, spark=spark_session)

def is_test_run_active() -> bool:
    """Retorna si el entorno actual es un testrun interactivo."""
    return _GLOBAL_IS_TEST_RUN

def get_local_source_table(spark, source_official: str) -> str:
    """
    En modo local, permite a los notebooks Silver/Gold descubrir de dónde leer los datos 
    cuando las dependencias (Bronze) no están materializadas en Unity Catalog sino en tablas temporales.
    
    1. Revisa si existe la tabla oficial en Unity Catalog (ej: bronze_dev.schema.table).
    2. Si no, revisa si existe la tabla temporal local (ej: bronze_dev.temporary.table_tmp_sql).
    3. Si ninguna existe, lanza un error descriptivo.
    """
    parts = source_official.split(".")
    env_catalog = parts[0]
    target_table = parts[-1]
    
    oficial_name = source_official
    temp_name = f"{env_catalog}.temporary.{target_table}_tmp_sql"
    
    def table_exists(name):
        try:
            # Chequeo extra para MockSparkSession (ya que siempre devuelve un MockDataframe)
            if type(spark).__name__ == "MockSparkSession":
                # En pruebas locales sin databricks-connect forzamos a que use la temporal si se pregunta por ella
                if "temporary" in name:
                    return True
                return False
                
            # En Databricks real o Connect evaluamos su existencia de forma directa con eager execution (Spark Connect)
            return spark.catalog.tableExists(name)
        except Exception:
            return False

    if table_exists(oficial_name):
        print(f"✅ Leyendo desde tabla oficial Unity Catalog: {oficial_name}")
        return oficial_name
    elif table_exists(temp_name):
        print(f"⚠️ Leyendo desde tabla TEMPORAL de prueba local: {temp_name}")
        return temp_name
    else:
        raise ValueError(
            f"❌ ERROR DE LINAJE LOCAL: No se encontró la tabla de origen.\n"
            f"  - Oficial (No existe): {oficial_name}\n"
            f"  - Temporal Local (No existe): {temp_name}\n"
            f"Solución: Debes ejecutar primero el notebook de la capa anterior ({target_table}) para generar los datos temporales de prueba."
        )

def clean_local_test_table(spark, source_table: str):
    """
    Se encarga de limpiar el entorno local tras una prueba exitosa.
    Si source_table es una tabla temporal, la elimina.
    Si source_table es una tabla oficial de Unity Catalog, busca y elimina su versión temporal residual si existiese.
    """
    print("-" * 50)
    
    # Extraemos las partes para construir el nombre temporal siempre
    parts = source_table.split(".")
    env_catalog = parts[0]
    target_table = parts[-1]
    
    # Si la tabla ya era la temporal, limpiamos directo el '_tmp_sql' que viene en target_table,
    # sino se lo añadimos a la tabla original
    if target_table.endswith("_tmp_sql"):
        temp_name = source_table
    else:
        temp_name = f"{env_catalog}.temporary.{target_table}_tmp_sql"
    
    def table_exists(name):
        try:
            if type(spark).__name__ == "MockSparkSession":
                # En el mock local, asumimos que no hay residuos a menos que sea explícito
                # y evitamos el falso positivo de "Se detectó y eliminó una tabla residual"
                return False
            return spark.catalog.tableExists(name)
        except Exception:
            return False

    if table_exists(temp_name):
        print("🧹 Limpiando zona temporal...")
        try:
            spark.sql(f"DROP TABLE IF EXISTS {temp_name}")
            if temp_name == source_table:
                print(f"✨ Tabla origen '{temp_name}' ELIMINADA.")
            else:
                print(f"✨ Se detectó y eliminó una tabla local residual: '{temp_name}'.")
        except Exception as e:
            print(f"⚠️ Error limpiando la tabla temporal: {e}")
    else:
        if "temporary" not in source_table:
            print("ℹ️ Tabla de Unity Catalog oficial detectada. No hay residuos temporales locales que limpiar.")
            
    print("   Ciclo de prueba completado limpiamente.")

_SPARK_CACHE = None

def get_test_spark():
    global _SPARK_CACHE
    if _SPARK_CACHE is not None:
        return _SPARK_CACHE
    
    # 1. Si ya estamos en Databricks (Workspace), la sesion 'spark' vive en el namespace
    try:
        import IPython
        ip = IPython.get_ipython()
        if ip and ip.user_ns.get('spark') is not None:
            _SPARK_CACHE = ip.user_ns['spark']
            return _SPARK_CACHE
    except:
        pass

    # 2. Si no, intentamos Databricks Connect (Local)
    try:
        from databricks.connect import DatabricksSession
        from databricks.sdk.core import Config
        config = Config(profile="DEFAULT")
        _SPARK_CACHE = DatabricksSession.builder.sdkConfig(config).getOrCreate()
        return _SPARK_CACHE
    except Exception as e:
        print(f" Error creando sesión Spark Local/Connect: {e}")
        print(" Fallback to MockSparkSession for local testing")
        class MockDataFrameReader:
            def format(self, *a, **k): return self
            def load(self, *a, **k): return self
            def table(self, *a, **k): return self
            def option(self, *a, **k): return self
            def count(self): return 100
            def show(self, *a, **k): pass
            def limit(self, *a, **k): return self
            def withColumn(self, *a, **k): return self
            def select(self, *a, **k): return self
            def drop(self, *a, **k): return self
            def filter(self, *a, **k): return self
        class MockDataStreamReader(MockDataFrameReader):
            pass
        class MockDataStreamWriter:
            def format(self, *a, **k): return self
            def trigger(self, *a, **k): return self
            def outputMode(self, *a, **k): return self
            def option(self, *a, **k): return self
            def toTable(self, *a, **k): return self
            def start(self, *a, **k): return self
            def awaitTermination(self): pass
        class MockDataFrame:
            @property
            def writeStream(self): return MockDataStreamWriter()
            def createOrReplaceTempView(self, name): pass
            def limit(self, *a, **k): return self
            def show(self, *a, **k): pass
            def isStreaming(self): return True
            def withColumn(self, *a, **k): return self
            def select(self, *a, **k): return self
            def drop(self, *a, **k): return self
            def filter(self, *a, **k): return self
            def colRegex(self, *a, **k): return self
            def alias(self, *a, **k): return self
            def unionByName(self, *a, **k): return self
            def distinct(self, *a, **k): return self
            def join(self, *a, **k): return self
            def na(self, *a, **k): return self
            def count(self): return 100
            @property
            def columns(self): return ["col1", "col2"]
        class MockSparkSession:
            @property
            def read(self): return MockDataFrameReader()
            @property
            def readStream(self): return MockDataStreamReader()
            def sql(self, *a, **k): return MockDataFrame()
            def table(self, *a, **k): return MockDataFrame()
        _SPARK_CACHE = MockSparkSession()
        return _SPARK_CACHE

def stop_local_spark():
    """
    Detiene la sesión local de Spark y limpia el caché.
    Solo detiene si es una sesión local/Connect (no detiene la sesión nativa de Databricks).
    """
    global _SPARK_CACHE
    if _SPARK_CACHE is not None:
        if "DATABRICKS_RUNTIME_VERSION" in os.environ:
            print("ℹ️ Sesión nativa de Databricks detectada. No se detendrá spark.stop() para no cerrar el kernel.")
            _SPARK_CACHE = None
            return

        try:
            # Intentar detener todos los streaming activos por seguridad
            if hasattr(_SPARK_CACHE, "streams") and hasattr(_SPARK_CACHE.streams, "active"):
                for stream in _SPARK_CACHE.streams.active:
                    stream.stop()
            # Suprimir advertencia inofensiva de PySpark Connect al cerrar el canal de golpe
            import warnings
            with warnings.catch_warnings():
                warnings.filterwarnings("ignore", message="ReleaseExecute failed.*", category=UserWarning)
                _SPARK_CACHE.stop()
        except Exception as e:
            print(f"⚠️ Error deteniendo la sesión de Spark: {e}")
        finally:
            _SPARK_CACHE = None
            print("🛑 Sesión local de Spark detenida correctamente. Recursos liberados.")
    else:
        print("ℹ️ No hay ninguna sesión local de Spark activa que detener.")

def display_test_results(spark, table_name: str, limit: int = 5):
    """
    Lee y muestra una muestra de la tabla de forma legible.
    Usa display() si está en Databricks (Workspace), o show() como fallback (Local).
    """
    try:
        df = spark.read.table(table_name).limit(limit)
        
        # 1. Intentar usar display() SOLO si estamos en Databricks Real (Runtime)
        if "DATABRICKS_RUNTIME_VERSION" in os.environ:
            try:
                # Buscar display en el namespace de IPython (donde Databricks inyecta su widget UI)
                import IPython
                shell = IPython.get_ipython()
                
                if shell is not None and "display" in shell.user_ns:
                    print(f"\n✅ Resultado en: {table_name}")
                    shell.user_ns["display"](df)
                    return
                # Alternativa moderna: DBR > 13.0 incluye el método display() directo en el DataFrame
                elif hasattr(df, "display"):
                    print(f"\n✅ Resultado en: {table_name}")
                    df.display()
                    return
            except Exception:
                pass

        # 2. Fallback: Horizontal Display para local
        print(f"\n✅ Resultado en: {table_name}")
        df.show(n=limit, truncate=False) # truncate=False ayuda a que se lea mejor si hay textos largos
        
    except Exception as e:
        print(f"⚠️ No se pudo mostrar la tabla {table_name}: {e}")
