# madpod-nanobot

A fork of [HKUDS/nanobot](https://github.com/HKUDS/nanobot) customized for [Madpod](https://madpodai.com) — a task-centric AI agent hosting platform.

## What changed

- **Removed** all upstream messaging channels (Telegram, Discord, Slack, WhatsApp, Email, Feishu, DingTalk, QQ, Matrix)
- **Added** `MadpodChannel` — persistent WebSocket client connecting agents to the Madpod control plane
- **Added** hooks (`activity_logger`, `intervention_detector`) bundled in the package
- **Renamed** package to `madpod-nanobot`

## Install

```bash
uv add madpod-nanobot
```

## Usage

```bash
madpod-nanobot gateway --config /path/to/config.json --workspace /path/to/workspace
```

### Environment variables

| Variable | Description | Default |
|----------|-------------|---------|
| `MADPOD_AGENT_ID` | Agent identifier | (required) |
| `MADPOD_GATEWAY_TOKEN` | Bearer token for WS auth | (required) |
| `MADPOD_CONTROL_PLANE_WS_URL` | Control plane WebSocket URL | `wss://api.madpodai.com` |

## License

MIT — see [LICENSE](LICENSE).
