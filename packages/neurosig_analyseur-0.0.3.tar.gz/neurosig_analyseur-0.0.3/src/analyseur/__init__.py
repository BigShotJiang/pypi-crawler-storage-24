# ~/analyseur/analyseur/__init__.py

__version__ = "0.0.1"
__all__ = ["cbgtc", "rbcbg"]