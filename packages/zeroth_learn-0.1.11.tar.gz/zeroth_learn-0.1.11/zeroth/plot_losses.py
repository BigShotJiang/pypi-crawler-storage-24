from __future__ import annotations

from typing import TYPE_CHECKING

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from cycler import cycler
from matplotlib.axes import Axes

from .types import Array

if TYPE_CHECKING:
    from .abstract.model import Model


def set_style() -> None:
    plt.rcParams.update({
        "font.family": "serif",
        "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
        "font.size": 10,
        "axes.labelsize": 10,
        "axes.titlesize": 11,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.labelsize": 9,
        "ytick.labelsize": 9,
        "xtick.direction": "out",
        "ytick.direction": "out",
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "lines.linewidth": 2.2,
        "legend.fontsize": 9,
        "legend.frameon": False,
        "grid.color": "0.85",
        "grid.linewidth": 0.6,
        "grid.linestyle": "-",
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
    })
    plt.rcParams["axes.prop_cycle"] = cycler(color=[
        "#4477AA", "#EE6677", "#228833",
        "#CCBB44", "#66CCEE", "#AA3377"
    ])

    plt.rcParams.update({
        "text.usetex": True,
        "text.latex.preamble": (
            r"\usepackage[T1]{fontenc} "
            r"\usepackage{lmodern} "  # La police Overleaf
            r"\usepackage{amsmath} "
            r"\usepackage{amssymb} "
            r"\usepackage{upgreek} "
            r"\usepackage{bm} "
        ),
    })


def format_ax(ax: Axes) -> None:
    ax.set_axisbelow(True)
    ax.set_yscale('log')
    ax.grid(True, which="major", axis="y")
    ax.grid(False, axis="x")
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)


def plot_loss(ax: Axes, train_loss: Array, label: str, smooth_fraction: float = 0) -> None:
    window_length = int(len(train_loss) * smooth_fraction)
    if window_length > 1:
        ax.plot(train_loss, alpha=0.25, linewidth=1.0)
        smooth = smooth_curve(train_loss, window_length)
        ax.plot(smooth, label=label, linewidth=2.5)
    else:
        ax.plot(train_loss, alpha=1, linewidth=2.5)


def smooth_curve(loss: Array, window_length: int) -> Array:
    return np.exp(pd.Series(np.log(loss)).ewm(span=window_length, adjust=True).mean())


def plot_0d(models: list[Model], title: str, smooth_fraction: float = 50) -> None:
    """
    Plots a single graph overlaying multiple models that share the same hyperparameters.
    """
    fig, ax = plt.subplots(figsize=(5.5, 3.5))

    for model in models:
        others = [f"{k} = {v}" for k, v in model.id.items()]
        label = ", ".join(others)
        plot_loss(ax, model.training_loss, label, smooth_fraction)

        format_ax(ax)

    plt.subplots_adjust(left=0.1, right=0.95, top=0.9, bottom=0.2)
    fig.suptitle(rf"\textbf{{{title}}}", fontweight='bold', fontsize=12)
    ax.set_xlabel("Training steps")
    ax.set_ylabel("Training loss")
    format_ax(ax)

    handles, labels = ax.get_legend_handles_labels()

    if handles:
        fig.legend(handles, labels, loc='lower center', ncol=len(handles),
                   bbox_to_anchor=(0.5, 0), frameon=False, fontsize=9)


def plot_1d(models: list[Model], title: str, key: str, smooth_fraction: float = 50) -> None:
    """
    Plots a row of subplots, varying one hyperparameter (key) across columns.
    """

    cols = list(dict.fromkeys([m.id[key] for m in models]))
    n_models = len(cols)
    fig, axs = plt.subplots(1, n_models, figsize=(4.5 * n_models, 3.5), sharey=True)

    for i, val in enumerate(cols):
        ax = axs[i]
        cell_models = [m for m in models if m.id[key] == val]

        for model in cell_models:
            others = [f"{k} = {v}" for k, v in model.id.items()
                      if k != key]
            label = ", ".join(others)
            plot_loss(ax, model.training_loss, label, smooth_fraction)

        format_ax(ax)

        ax.set_title(f"{key} = {val}")

    fig.text(0.5, 0.1, "Training steps", ha='center', fontsize=10)
    fig.text(0.01, 0.5, "Training loss", va='center', rotation='vertical', fontsize=10)

    plt.subplots_adjust(left=0.05, right=0.96, top=0.85, bottom=0.2, wspace=0.10, hspace=0.18)
    fig.suptitle(rf"\textbf{{{title}}}", fontweight='bold', fontsize=12)

    handles, labels = axs[0].get_legend_handles_labels()

    if handles:
        fig.legend(handles, labels, loc='lower center', ncol=len(handles),
                   bbox_to_anchor=(0.5, 0), frameon=False, fontsize=9)


def plot_2d(models: list[Model], title: str, row_key: str, col_key: str, smooth_fraction: float) -> None:
    """
    Plots a grid of subplots varying two hyperparameters: one across rows, one across columns.

    Args:
        models (list): List of model objects.
        title (str): The title of the plot.
        row_key (str): The hyperparameter key changing across rows.
        col_key (str): The hyperparameter key changing across columns.
        smooth_fraction (int)
    """
    rows = list(dict.fromkeys([m.id[row_key] for m in models]))
    cols = list(dict.fromkeys([m.id[col_key] for m in models]))

    fig, axs = plt.subplots(len(rows), len(cols),
                            figsize=(4.5 * len(cols), 3.5 * len(rows)),
                            sharex=True, sharey=True, squeeze=False)

    for i, r_val in enumerate(rows):
        for j, c_val in enumerate(cols):
            ax = axs[i, j]
            cell_models = [m for m in models if m.id[row_key] == r_val and m.id[col_key] == c_val]

            for model in cell_models:
                others = [f"{k} = {v}" for k, v in model.id.items() if k not in [row_key, col_key]]
                label = ", ".join(others)
                plot_loss(ax, model.training_loss, label, smooth_fraction)

            format_ax(ax)

            if i == 0:
                ax.set_title(f"{col_key} = {c_val}")

            if j == len(cols) - 1:
                ax.text(1.02, 0.5, f"{row_key} = {r_val}",
                        transform=ax.transAxes, rotation=-90,
                        va="center", ha="left")

    plt.subplots_adjust(left=0.06, right=0.96, top=0.90, bottom=0.12, wspace=0.10, hspace=0.18)
    fig.suptitle(rf"\textbf{{{title}}}", fontsize=14, fontweight='bold', y=0.98)

    handles, labels = axs[0, 0].get_legend_handles_labels()
    if handles:
        fig.legend(handles, labels, loc='lower center', ncol=len(handles),
                   bbox_to_anchor=(0.5, 0.02), frameon=False, fontsize=9)

    fig.text(0.5, 0.07, "Training steps", ha='center', fontsize=10)
    fig.text(0.02, 0.5, "Training loss", va='center', rotation='vertical', fontsize=10)


def plot_losses(dimension: int, models: list[Model], title: str, smooth_fraction: float, save_path: str = None) -> None:
    """
    Main entry point for plotting. Automatically detects if the plot should be 0D, 1D, or 2D
    based on the number of variation parameters.

    Args:
        dimension (int): dimension of the plot
        models (list): List of model objects.
        title (str): The title of the plot.
        save_path (str, optional): File path to save the figure (e.g., 'plot.png').
        smooth_fraction (int): span for smoothing.
    """
    set_style()

    keys = list(models[0].id.keys())

    if dimension == 0:
        plot_0d(models, title, smooth_fraction)
    elif dimension == 1:
        plot_1d(models, title, keys[0], smooth_fraction)
    else:
        plot_2d(models, title, keys[0], keys[1], smooth_fraction)

    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches="tight")
        print(f"Plot saved to {save_path}")

    plt.show()
