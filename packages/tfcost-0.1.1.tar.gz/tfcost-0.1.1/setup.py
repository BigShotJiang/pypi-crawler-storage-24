from setuptools import setup, find_packages

setup(
    name="tfcost",
    version="0.1.1",
    packages=find_packages(),
    install_requires=[
        "boto3"
    ],
    entry_points={
        "console_scripts": [
            "tfcost=tfcost.cli:main"
        ]
    },
    author="Rakshith Jakkani",
    description="Terraform cost estimation tool",
)