# from tfcost.engines.resource_engine import register
# from tfcost.pricing.aws_pricing import get_ec2_price

# HOURS_PER_MONTH = 730.5

# @register("aws_instance")
# def price_ec2(resource, region):

#     instance_type = resource["config"]["instance_type"]

#     hourly = get_ec2_price(instance_type, region)

#     monthly = hourly * HOURS_PER_MONTH

#     return {
#         "service": "EC2",
#         "cost": monthly
#     }