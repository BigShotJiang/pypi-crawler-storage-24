RESOURCE_PRICING_MAP = {

# ========================
# EC2
# ========================
"aws_instance": {
    "service": "EC2",
    "lookup": "instance_type",
    "pricing_model": "instance_hour"
},

"aws_launch_template": {
    "service": "EC2",
    "lookup": "instance_type",
    "pricing_model": "instance_hour"
},

"aws_autoscaling_group": {
    "service": "EC2",
    "lookup": "instance_type",
    "pricing_model": "instance_hour"
},

"aws_spot_instance_request": {
    "service": "EC2",
    "lookup": "instance_type",
    "pricing_model": "instance_hour"
},

# ========================
# EBS
# ========================
"aws_ebs_volume": {
    "service": "EBS",
    "lookup": "type",
    "size": "size",
    "pricing_model": "storage_gb_month"
},

"aws_ebs_snapshot": {
    "service": "EBS",
    "size": "size",
    "pricing_model": "storage_gb_month"
},

# ========================
# S3
# ========================
"aws_s3_bucket": {
    "service": "S3",
    "pricing_model": "bucket_storage",
    "default_size": 10,
    "price_per_gb": 0.023
},

# ========================
# RDS
# ========================
"aws_db_instance": {
    "service": "RDS",
    "lookup": "instance_class",
    "pricing_model": "instance_hour"
},

"aws_rds_cluster_instance": {
    "service": "RDS",
    "lookup": "instance_class",
    "pricing_model": "instance_hour"
},

"aws_rds_cluster": {
    "service": "RDS",
    "lookup": "engine",
    "pricing_model": "instance_hour"
},

# ========================
# Load Balancers
# ========================
"aws_lb": {
    "service": "ELB",
    "pricing_model": "hourly_fixed",
    "price": 0.025
},

"aws_elb": {
    "service": "ELB",
    "pricing_model": "hourly_fixed",
    "price": 0.025
},

# ========================
# NAT Gateway
# ========================
"aws_nat_gateway": {
    "service": "NAT Gateway",
    "pricing_model": "hourly_fixed",
    "price": 0.045
},

# ========================
# Elastic IP
# ========================
"aws_eip": {
    "service": "Elastic IP",
    "pricing_model": "hourly_fixed",
    "price": 0.005
},

# ========================
# EFS
# ========================
"aws_efs_file_system": {
    "service": "EFS",
    "size": "size",
    "pricing_model": "storage_gb_month"
},

# ========================
# DynamoDB
# ========================
"aws_dynamodb_table": {
    "service": "DynamoDB",
    "pricing_model": "capacity"
},

# ========================
# ElastiCache
# ========================
"aws_elasticache_cluster": {
    "service": "ElastiCache",
    "lookup": "node_type",
    "pricing_model": "instance_hour"
},

"aws_elasticache_replication_group": {
    "service": "ElastiCache",
    "lookup": "node_type",
    "pricing_model": "instance_hour"
},

# ========================
# Redshift
# ========================
"aws_redshift_cluster": {
    "service": "Redshift",
    "lookup": "node_type",
    "pricing_model": "instance_hour"
},

# ========================
# EKS
# ========================
"aws_eks_cluster": {
    "service": "EKS",
    "pricing_model": "hourly_fixed",
    "price": 0.10
},

"aws_eks_node_group": {
    "service": "EKS",
    "lookup": "instance_types",
    "count": "desired_size",
    "pricing_model": "eks_node_group"
},

# ========================
# MSK
# ========================
"aws_msk_cluster": {
    "service": "MSK",
    "lookup": "instance_type",
    "pricing_model": "instance_hour"
},

# ========================
# OpenSearch
# ========================
"aws_opensearch_domain": {
    "service": "OpenSearch",
    "lookup": "instance_type",
    "pricing_model": "instance_hour"
},

# ========================
# EKS
# ========================

"aws_eks_cluster": {
    "service": "EKS",
    "pricing_model": "hourly_fixed",
    "price": 0.10
},

# ========================
# Glue
# ========================
"aws_glue_job": {
    "service": "Glue",
    "pricing_model": "hourly_fixed",
    "price": 0.44
}


}