# from tfcost.engines.resource_engine import register

# @register("aws_s3_bucket")
# def price_s3(resource, region):

#     storage_gb = 10
#     price_per_gb = 0.023

#     monthly = storage_gb * price_per_gb

#     return {
#         "service": "S3",
#         "cost": monthly
#     }