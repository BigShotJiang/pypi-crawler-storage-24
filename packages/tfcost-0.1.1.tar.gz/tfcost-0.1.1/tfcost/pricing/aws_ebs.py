# from tfcost.engines.resource_engine import register
# from tfcost.pricing.aws_pricing import get_ebs_price

# @register("aws_ebs_volume")
# def price_ebs(resource, region):

#     size = resource["config"].get("size")
#     vtype = resource["config"].get("type", "gp3")

#     price = get_ebs_price(vtype, region)

#     monthly = price * size

#     return {
#         "service": "EBS",
#         "cost": monthly
#     }