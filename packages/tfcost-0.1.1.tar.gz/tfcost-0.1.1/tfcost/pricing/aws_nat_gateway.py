# from tfcost.engines.resource_engine import register

# HOURS_PER_MONTH = 730.5
# NAT_HOURLY_PRICE = 0.045


# @register("aws_nat_gateway")
# def price_nat_gateway(resource, region):

#     monthly = NAT_HOURLY_PRICE * HOURS_PER_MONTH

#     return {
#         "service": "NAT Gateway",
#         "cost": monthly
#     }