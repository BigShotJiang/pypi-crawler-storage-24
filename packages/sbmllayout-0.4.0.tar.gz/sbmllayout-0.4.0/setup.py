from setuptools import setup

setup(
    name='SBMLLayout',
    version='0.4.0',
    description='Clean API for reading and writing the SBML Layout extension',
    long_description=open('README.md').read(),
    long_description_content_type='text/markdown',
    author='Herbert M Sauro',
    packages=['SBMLLayout'],
    package_dir={'SBMLLayout': 'SBMLLayout'},
    python_requires='>=3.8',
    install_requires=[
        'python-libsbml',
        'skia-python',
    ],
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Topic :: Scientific/Engineering :: Bio-Informatics',
    ],
)