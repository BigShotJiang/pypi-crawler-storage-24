"""
SBMLLayout - clean API for the SBML Layout extension.

Quick start::

    import SBMLLayout as sl

    layout = sl.Layout(sbml_string)
    layout.addNode('S1', x=100, y=150, w=60, h=40)
    layout.addNode('S2', x=300, y=150, w=60, h=40)
    layout.addReaction('J1', center=(200, 170),
                       reactants=['S1'], products=['S2'])
    layout.draw()
    layout.draw(output='network.png')
    layout.draw(output='network.pdf')
    layout.draw(output='network.svg')
"""

from .layout import Layout
from .renderer import Renderer, Style

__version__ = '0.4.0'
__all__ = ['Layout', 'Renderer', 'Style']
