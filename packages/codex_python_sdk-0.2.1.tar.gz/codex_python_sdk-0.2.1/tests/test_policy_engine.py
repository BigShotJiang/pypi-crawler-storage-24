from __future__ import annotations

from codex_python_sdk import (
    DefaultPolicyEngine,
    PolicyContext,
    RuleBasedPolicyEngine,
    build_policy_engine_from_rubric,
)
from codex_python_sdk.errors import CodexAgenticError
from codex_python_sdk.policy import (
    DEFAULT_POLICY_RUBRIC,
    _matches_rule,
    _normalize_command_or_file_decision,
    _normalize_user_input_decision,
)


def test_build_policy_engine_returns_rule_based_engine():
    engine = build_policy_engine_from_rubric({"system_rubric": "test"})
    assert isinstance(engine, RuleBasedPolicyEngine)


def test_default_policy_rubric_is_not_shared_across_engines_or_global():
    rb1 = RuleBasedPolicyEngine()
    rb2 = RuleBasedPolicyEngine()
    assert rb1.rubric is not rb2.rubric
    assert rb1.rubric is not DEFAULT_POLICY_RUBRIC
    assert rb2.rubric is not DEFAULT_POLICY_RUBRIC

    rb1.rubric.command_rules.append({"name": "x", "when": {"command_regex": ".*"}, "decision": "decline"})
    assert rb2.rubric.command_rules == []
    assert DEFAULT_POLICY_RUBRIC.command_rules == []


def test_default_policy_engine_is_fail_closed():
    engine = DefaultPolicyEngine()
    context = PolicyContext(
        request_type="command",
        method="item/commandExecution/requestApproval",
        thread_id="t1",
        turn_id="u1",
        item_id="i1",
        params={"command": "pwd"},
    )
    assert engine.on_command_approval(context.params, context) == {"decision": "decline"}
    assert engine.on_file_change_approval({"reason": "write"}, context) == {"decision": "decline"}
    assert engine.on_tool_request_user_input({}, context) == {"answers": {}}


def test_rule_based_policy_engine_matches_command_regex():
    engine = RuleBasedPolicyEngine(
        {
            "system_rubric": "test",
            "command_rules": [
                {
                    "name": "block_rm_root",
                    "priority": 5,
                    "when": {"command_regex": r"rm\s+-rf\s+/"},
                    "decision": "cancel",
                }
            ],
            "defaults": {"command": "decline", "file_change": "decline", "tool_input": "auto_empty"},
        }
    )
    context = PolicyContext(
        request_type="command",
        method="item/commandExecution/requestApproval",
        thread_id="t1",
        turn_id="u1",
        item_id="i1",
        params={"command": "rm -rf /"},
    )
    out = engine.on_command_approval({"command": "rm -rf /"}, context)
    assert out == {"decision": "cancel"}


def test_rule_based_policy_engine_raises_for_invalid_rule_decision():
    engine = RuleBasedPolicyEngine(
        {
            "system_rubric": "test",
            "command_rules": [
                {
                    "name": "bad_rule",
                    "priority": 1,
                    "when": {"command_regex": r"^rm"},
                    "decision": "typo-invalid",
                }
            ],
            "defaults": {"command": "decline", "file_change": "decline", "tool_input": "auto_empty"},
        }
    )
    command_context = PolicyContext(
        request_type="command",
        method="item/commandExecution/requestApproval",
        thread_id="t1",
        turn_id="u1",
        item_id="i1",
        params={"command": "rm -rf /tmp/x"},
    )
    try:
        engine.on_command_approval(command_context.params, command_context)
        raise AssertionError("expected CodexAgenticError")
    except CodexAgenticError as exc:
        assert "Policy decision string must be one of" in str(exc)


def test_user_input_normalization_from_list_shape():
    normalized = _normalize_user_input_decision(
        {
            "answers": [
                {"id": "q1", "answers": ["a1"]},
                {"id": "q2", "answers": ["a2", "a3"]},
            ]
        }
    )
    assert normalized == {
        "answers": {
            "q1": {"answers": ["a1"]},
            "q2": {"answers": ["a2", "a3"]},
        }
    }


def test_matches_rule_honors_command_context_conditions():
    context = PolicyContext(
        request_type="command",
        method="item/commandExecution/requestApproval",
        thread_id="thread-123",
        turn_id="turn-abc",
        item_id="item-1",
        params={},
    )
    params = {
        "command": "rm -rf /tmp/cache",
        "cwd": "/tmp/workspace",
        "reason": "cleanup",
        "proposedExecpolicyAmendment": ["allow /tmp/workspace/**"],
    }
    when = {
        "command_regex": r"rm\s+-rf",
        "cwd_prefix": "/tmp",
        "reason_regex": "clean",
        "thread_id_regex": "thread-\\d+",
        "turn_id_regex": "turn-",
        "has_proposed_execpolicy": True,
    }
    assert _matches_rule(when, params, context, kind="command") is True

    unmatched = dict(when)
    unmatched["has_proposed_execpolicy"] = False
    assert _matches_rule(unmatched, params, context, kind="command") is False


def test_matches_rule_tool_input_and_file_change_specific_conditions():
    tool_context = PolicyContext(
        request_type="tool_user_input",
        method="item/tool/requestUserInput",
        thread_id="thread-1",
        turn_id="turn-1",
        item_id="item-1",
        params={},
    )
    tool_params = {"questions": [{"id": "q-approval", "question": "Proceed?"}]}
    assert _matches_rule({"question_id_regex": r"q-approval"}, tool_params, tool_context, kind="tool_user_input") is True
    assert _matches_rule({"question_id_regex": r"q-missing"}, tool_params, tool_context, kind="tool_user_input") is False

    file_context = PolicyContext(
        request_type="file_change",
        method="item/fileChange/requestApproval",
        thread_id="thread-2",
        turn_id="turn-2",
        item_id="item-2",
        params={},
    )
    file_params = {"grantRoot": "/repo"}
    assert _matches_rule({"grant_root_present": True}, file_params, file_context, kind="file_change") is True
    assert _matches_rule({"grant_root_present": False}, file_params, file_context, kind="file_change") is False


def test_matches_rule_rejects_unknown_rule_fields():
    context = PolicyContext(
        request_type="command",
        method="item/commandExecution/requestApproval",
        thread_id="thread-1",
        turn_id="turn-1",
        item_id="item-1",
        params={},
    )
    try:
        _matches_rule({"unknown_key": "x"}, {"command": "pwd"}, context, kind="command")
        raise AssertionError("expected CodexAgenticError")
    except CodexAgenticError as exc:
        assert "Unsupported policy rule fields for 'command': unknown_key" in str(exc)


def test_normalize_command_or_file_decision_rejects_invalid_dict():
    try:
        _normalize_command_or_file_decision({"decision": "deny"}, fallback="decline")
        raise AssertionError("expected CodexAgenticError")
    except CodexAgenticError as exc:
        assert "valid 'decision'" in str(exc)


def test_normalize_command_or_file_decision_accepts_supported_structured_shapes():
    exec_policy = _normalize_command_or_file_decision(
        {
            "decision": {
                "acceptWithExecpolicyAmendment": {
                    "execpolicy_amendment": ["allow /repo/**"],
                }
            }
        },
        fallback="decline",
    )
    assert exec_policy["decision"]["acceptWithExecpolicyAmendment"]["execpolicy_amendment"] == ["allow /repo/**"]

    network_policy = _normalize_command_or_file_decision(
        {
            "decision": {
                "applyNetworkPolicyAmendment": {
                    "network_policy_amendment": {"action": "allow", "host": "example.com"},
                }
            }
        },
        fallback="decline",
    )
    assert network_policy["decision"]["applyNetworkPolicyAmendment"]["network_policy_amendment"]["host"] == "example.com"
