from __future__ import annotations

import copy
import re
from dataclasses import dataclass, field
from typing import Any, Awaitable, Literal, Protocol

from ._shared import utc_now
from .errors import CodexAgenticError

RequestType = Literal["command", "file_change", "tool_user_input"]
Decision = Literal["accept", "acceptForSession", "decline", "cancel"]
PolicyMode = Literal["permissive", "balanced", "strict"]


@dataclass
class PolicyContext:
    request_type: RequestType
    method: str
    thread_id: str | None
    turn_id: str | None
    item_id: str | None
    params: dict[str, Any]
    timestamp: str = field(default_factory=utc_now)


@dataclass
class PolicyRubric:
    system_rubric: str
    mode: PolicyMode = "permissive"
    command_rules: list[dict[str, Any]] = field(default_factory=list)
    file_change_rules: list[dict[str, Any]] = field(default_factory=list)
    tool_input_rules: list[dict[str, Any]] = field(default_factory=list)
    defaults: dict[str, Any] = field(
        default_factory=lambda: {
            "command": "decline",
            "file_change": "decline",
            "tool_input": "auto_empty",
        }
    )
    audit: dict[str, Any] = field(default_factory=lambda: {"enabled": False, "include_params": False})


DEFAULT_POLICY_RUBRIC = PolicyRubric(
    system_rubric=(
        "Apply deterministic local rules for command and file-change approvals. "
        "When uncertain, prefer safe behavior."
    ),
    mode="permissive",
)


def _default_policy_rubric() -> PolicyRubric:
    return copy.deepcopy(DEFAULT_POLICY_RUBRIC)


class PolicyEngine(Protocol):
    def on_command_approval(
        self,
        params: dict[str, Any],
        context: PolicyContext,
    ) -> dict[str, Any] | Awaitable[dict[str, Any]]:
        ...

    def on_file_change_approval(
        self,
        params: dict[str, Any],
        context: PolicyContext,
    ) -> dict[str, Any] | Awaitable[dict[str, Any]]:
        ...

    def on_tool_request_user_input(
        self,
        params: dict[str, Any],
        context: PolicyContext,
    ) -> dict[str, Any] | Awaitable[dict[str, Any]]:
        ...


class DefaultPolicyEngine:
    """Default fail-closed behavior for unattended clients."""

    def on_command_approval(self, params: dict[str, Any], context: PolicyContext) -> dict[str, Any]:
        del params, context
        return {"decision": "decline"}

    def on_file_change_approval(self, params: dict[str, Any], context: PolicyContext) -> dict[str, Any]:
        del params, context
        return {"decision": "decline"}

    def on_tool_request_user_input(self, params: dict[str, Any], context: PolicyContext) -> dict[str, Any]:
        del params, context
        return {"answers": {}}


class RuleBasedPolicyEngine:
    """Rule evaluator based on a declarative rubric dict/dataclass."""

    def __init__(self, rubric: PolicyRubric | dict[str, Any] | None = None) -> None:
        self.rubric = _to_rubric(rubric) if rubric is not None else _default_policy_rubric()

    def on_command_approval(self, params: dict[str, Any], context: PolicyContext) -> dict[str, Any]:
        fallback = self.rubric.defaults.get("command", "decline")
        decision = self._apply_rules(
            self.rubric.command_rules,
            params,
            context,
            fallback=fallback,
            kind="command",
        )
        return _normalize_command_or_file_decision(decision, fallback=str(fallback))

    def on_file_change_approval(self, params: dict[str, Any], context: PolicyContext) -> dict[str, Any]:
        fallback = self.rubric.defaults.get("file_change", "decline")
        decision = self._apply_rules(
            self.rubric.file_change_rules,
            params,
            context,
            fallback=fallback,
            kind="file_change",
        )
        return _normalize_command_or_file_decision(decision, fallback=str(fallback))

    def on_tool_request_user_input(self, params: dict[str, Any], context: PolicyContext) -> dict[str, Any]:
        decision = self._apply_rules(
            self.rubric.tool_input_rules,
            params,
            context,
            fallback=self.rubric.defaults.get("tool_input", "auto_empty"),
            kind="tool_user_input",
        )
        return _normalize_user_input_decision(decision)

    def _apply_rules(
        self,
        rules: list[dict[str, Any]],
        params: dict[str, Any],
        context: PolicyContext,
        *,
        fallback: Any,
        kind: RequestType,
    ) -> Any:
        ordered = sorted(rules, key=lambda item: int(item.get("priority", 1000)))
        for rule in ordered:
            when = rule.get("when", {})
            if not isinstance(when, dict):
                continue
            if _matches_rule(when, params, context, kind=kind):
                return rule.get("decision", fallback)
        return fallback


def build_policy_engine_from_rubric(rubric: PolicyRubric | dict[str, Any]) -> PolicyEngine:
    return RuleBasedPolicyEngine(rubric=_to_rubric(rubric))


def _to_rubric(rubric: PolicyRubric | dict[str, Any]) -> PolicyRubric:
    if isinstance(rubric, PolicyRubric):
        return rubric
    data = dict(rubric)
    return PolicyRubric(
        system_rubric=str(data.get("system_rubric") or DEFAULT_POLICY_RUBRIC.system_rubric),
        mode=str(data.get("mode") or "permissive"),  # type: ignore[arg-type]
        command_rules=[item for item in data.get("command_rules", []) if isinstance(item, dict)],
        file_change_rules=[item for item in data.get("file_change_rules", []) if isinstance(item, dict)],
        tool_input_rules=[item for item in data.get("tool_input_rules", []) if isinstance(item, dict)],
        defaults=data.get("defaults") if isinstance(data.get("defaults"), dict) else DEFAULT_POLICY_RUBRIC.defaults.copy(),
        audit=data.get("audit") if isinstance(data.get("audit"), dict) else DEFAULT_POLICY_RUBRIC.audit.copy(),
    )


def _matches_rule(
    when: dict[str, Any],
    params: dict[str, Any],
    context: PolicyContext,
    *,
    kind: RequestType,
) -> bool:
    common_keys = {
        "command_regex",
        "cwd_prefix",
        "reason_regex",
        "thread_id_regex",
        "turn_id_regex",
        "has_proposed_execpolicy",
    }
    kind_specific_keys: dict[RequestType, set[str]] = {
        "command": set(),
        "file_change": {"grant_root_present"},
        "tool_user_input": {"question_id_regex"},
    }
    allowed_keys = common_keys | kind_specific_keys[kind]
    unknown_keys = sorted(key for key in when if key not in allowed_keys)
    if unknown_keys:
        names = ", ".join(unknown_keys)
        raise CodexAgenticError(f"Unsupported policy rule fields for '{kind}': {names}")

    command = str(params.get("command") or "")
    cwd = str(params.get("cwd") or "")
    reason = str(params.get("reason") or "")
    proposed = params.get("proposedExecpolicyAmendment")
    has_proposed = isinstance(proposed, list) and len(proposed) > 0

    if "command_regex" in when:
        pattern = str(when["command_regex"])
        if not re.search(pattern, command):
            return False
    if "cwd_prefix" in when:
        prefix = str(when["cwd_prefix"])
        if not cwd.startswith(prefix):
            return False
    if "reason_regex" in when:
        pattern = str(when["reason_regex"])
        if not re.search(pattern, reason):
            return False
    if "thread_id_regex" in when:
        pattern = str(when["thread_id_regex"])
        if not re.search(pattern, context.thread_id or ""):
            return False
    if "turn_id_regex" in when:
        pattern = str(when["turn_id_regex"])
        if not re.search(pattern, context.turn_id or ""):
            return False
    if "has_proposed_execpolicy" in when:
        expected = bool(when["has_proposed_execpolicy"])
        if expected != has_proposed:
            return False
    if kind == "file_change" and "grant_root_present" in when:
        expected = bool(when["grant_root_present"])
        present = bool(params.get("grantRoot"))
        if expected != present:
            return False
    if kind == "tool_user_input" and "question_id_regex" in when:
        pattern = str(when["question_id_regex"])
        questions = params.get("questions")
        if not isinstance(questions, list):
            return False
        matched = False
        for question in questions:
            if not isinstance(question, dict):
                continue
            qid = question.get("id")
            if isinstance(qid, str) and re.search(pattern, qid):
                matched = True
                break
        if not matched:
            return False
    return True


def _normalize_command_or_file_decision(decision: Any, *, fallback: str) -> dict[str, Any]:
    valid = {"accept", "acceptForSession", "decline", "cancel"}
    if isinstance(decision, dict):
        payload = dict(decision)
        value = payload.get("decision")
        if isinstance(value, str) and value in valid:
            return payload
        if isinstance(value, dict) and _is_supported_structured_decision(value):
            return payload
        raise CodexAgenticError("Policy decision dict must contain a valid 'decision'.")
    if isinstance(decision, str):
        if decision == "auto_empty":
            return {"decision": fallback}
        if decision in valid:
            return {"decision": decision}
        raise CodexAgenticError("Policy decision string must be one of: accept, acceptForSession, decline, cancel.")
    raise CodexAgenticError("Policy decision must be a dict or string.")


def _is_supported_structured_decision(value: dict[str, Any]) -> bool:
    exec_amendment = value.get("acceptWithExecpolicyAmendment")
    if isinstance(exec_amendment, dict):
        amendment = exec_amendment.get("execpolicy_amendment")
        if isinstance(amendment, list) and all(isinstance(item, str) for item in amendment):
            return True

    network_amendment = value.get("applyNetworkPolicyAmendment")
    if isinstance(network_amendment, dict):
        amendment = network_amendment.get("network_policy_amendment")
        if isinstance(amendment, dict):
            action = amendment.get("action")
            host = amendment.get("host")
            if action in {"allow", "deny"} and isinstance(host, str) and host:
                return True

    return False


def _normalize_user_input_decision(decision: Any) -> dict[str, Any]:
    if isinstance(decision, dict):
        answers = decision.get("answers")
        if isinstance(answers, list):
            mapped: dict[str, dict[str, list[str]]] = {}
            for row in answers:
                if not isinstance(row, dict):
                    continue
                qid = row.get("id")
                values = row.get("answers")
                if not isinstance(qid, str):
                    continue
                if not isinstance(values, list):
                    continue
                normalized_values = [value for value in values if isinstance(value, str)]
                mapped[qid] = {"answers": normalized_values}
            return {"answers": mapped}
        if isinstance(answers, dict):
            return {"answers": answers}
    return {"answers": {}}
