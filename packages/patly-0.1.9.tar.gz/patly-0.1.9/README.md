# patly

Gasless Polymarket position redemption. Two functions.

## Install

```bash
pip install patly
```

## Usage

```python
import patly, os

patly.init(api_key=os.getenv("PATLY_API_KEY"), pk=os.getenv("PK"))

patly.redeem("btc-updown-15m-1234567890", "YES")
```

## Setup

1. Connect your wallet at [patly.duckdns.org](http://patly.duckdns.org)
2. Copy your API key
3. Add to `.env`:
```
PATLY_API_KEY=your_api_key
```

## How it works

Your private key signs the transaction locally — it is **never transmitted**.
Only the cryptographic signature is sent to Patly, identical to how MetaMask works.

Each redemption costs **$0.01 USDC**, paid automatically.

## Docs

[patly.mintlify.app](https://patly.mintlify.app)