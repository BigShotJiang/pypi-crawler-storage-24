# Komodo Connector SDK

The Komodo Connector SDK is a Python library that provides programmatic access to the Komodo Health platform. It includes both a CLI for authentication management and a Python API for interacting with Komodo services and executing Snowflake queries through the Komodo platform.

## Features

- **OAuth 2.0 Device Authorization Flow**: Browser-based authentication for easy credential management
- **CLI Tools**: Simple commands for login, JWT management, and account selection
- **Snowflake Integration**: Execute SQL queries against Komodo's Snowflake data warehouse via proxy
- **Synchronous and Asynchronous Query Execution**: Support for both blocking and async query patterns
- **Automatic Token Refresh**: Credentials are automatically refreshed when they expire
- **Multi-Environment Support**: Switch between integration and production environments

### Prerequisites

- Python 3.11 or higher

## Installation

Install via pip:
```bash
pip install komodo
```

Confirm expected version:
```bash
komodo --version
```

## Usage

See: https://docs.komodohealth.com

## Local Development

### Building Images Locally

The `komodo build` command uses BuildKit to build and push container images. For local development outside of a Komodo workspace, you'll need to set up a local BuildKit daemon.

1. **Docker**: Ensure Docker Desktop is running

2. **buildctl**: Install the BuildKit client
   ```bash
   brew install buildkit
   ```

3. Start a BuildKit daemon container with TCP access:

```bash
docker run -d --name buildkitd --privileged -p 1234:1234 moby/buildkit:latest --addr tcp://0.0.0.0:1234
```

4. Set the BuildKit host environment variable:

```bash
export BUILDKIT_HOST="tcp://127.0.0.1:1234"
```

5. Verify the connection:

```bash
buildctl --addr tcp://127.0.0.1:1234 debug workers
```

6. Get AWS creds for AWS account and set them as environment variables:
```bash
export AWS_ACCESS_KEY_ID=<your-access-key-id>
export AWS_SECRET_ACCESS_KEY=<your-secret-access-key>
export AWS_SESSION_TOKEN=<your-session-token>
```

7. Set the AWS role ARN environment variable:

dev/staging:
```bash
export AWS_ROLE_ARN=arn:aws:iam::<your-aws-account-id>:role/<your-aws-role-name>
```
prod:
```bash
export AWS_ROLE_ARN=arn:aws:iam::<your-aws-account-id>:role/<your-aws-role-name>
```

8. Login using the CLI and set the account:
```bash
export KOMODO_ENVIRONMENT=integration
komodo login
komodo account set
```


#### Running a Build

Once BuildKit is configured, run the build command from a directory containing a `Dockerfile` or `devfile.yaml`:

```bash
komodo build
```

#### Stopping BuildKit

When you're done, you can stop and remove the BuildKit container:

```bash
docker rm -f buildkitd
```

#### Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `BUILDKIT_HOST` | BuildKit daemon address | `docker-container://buildkitd` (local) or `tcp://buildkit-service.buildkit.svc.cluster.local:1234` (workspace) |
| `AWS_ROLE_ARN` | AWS role ARN for ECR authentication | Required for pushing images |
