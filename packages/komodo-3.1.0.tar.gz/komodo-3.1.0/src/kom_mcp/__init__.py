"""Komodo Health Assistant - MCP server for the Komodo Health platform.

This module provides an MCP server with tools for working with Komodo Health, including:

**Data Exploration:**
- Exploring Snowflake schemas (databases, tables, columns)
- Understanding Komodo Health's healthcare data structure

**Additional capabilities will be added over time.**

Usage:
    python -m kom_mcp

Or via the CLI:
    komodo-mcp-server
"""

__version__ = "1.0.0"

from .server import mcp, run_server

__all__ = ["mcp", "run_server"]
