# PyMapsHelper

**PyMapsHelper** is a simple Python library that wraps OpenStreetMap APIs:

- Geocoding & reverse geocoding
- Nearby places search
- Routing, distance, and travel time
- Interactive maps with markers using **folium**

---

## Installation

Install dependencies:

```bash
pip install requests folium