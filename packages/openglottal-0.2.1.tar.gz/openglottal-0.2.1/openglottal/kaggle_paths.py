"""Resolve Kaggle input paths when running inside a Kaggle notebook/kernel."""

from __future__ import annotations

import os
from pathlib import Path

# BAGLS on Kaggle: gomezp/benchmark-for-automatic-glottis-segmentation
# Mounted at /kaggle/input/benchmark-for-automatic-glottis-segmentation/
KAGGLE_BAGLS_SLUG = "benchmark-for-automatic-glottis-segmentation"
KAGGLE_INPUT = Path("/kaggle/input")


def is_kaggle() -> bool:
    """True if running in a Kaggle notebook/kernel."""
    return os.environ.get("KAGGLE_KERNEL_RUN_TYPE", "") != ""


def get_kaggle_bagls_path(split: str) -> Path | None:
    """
    Return path to BAGLS split when on Kaggle, else None.

    Parameters
    ----------
    split : str
        ``"training"`` or ``"test"`` (BAGLS uses one dir per split; images and
        masks are in the same dir: N.png and N_seg.png).

    Returns
    -------
    Path to the split directory if on Kaggle and it exists, else None.
    """
    if not is_kaggle():
        return None
    path = KAGGLE_INPUT / KAGGLE_BAGLS_SLUG / split
    return path if path.is_dir() else None
