"""
llm-guard-kit framework integrations.

Drop-in callbacks and handlers for popular agent frameworks.
Each integration captures reasoning steps automatically and scores
the completed chain via AgentGuard.

Available
---------
    from llm_guard.integrations.langchain import AgentGuardCallback
    from llm_guard.integrations.llamaindex import AgentGuardEventHandler
    from llm_guard.integrations.crewai import AgentGuardCrewCallback
"""
