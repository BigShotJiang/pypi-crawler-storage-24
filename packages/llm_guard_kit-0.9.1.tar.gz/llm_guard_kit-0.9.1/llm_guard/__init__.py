"""
llm-guard-kit v0.9.0: Real-time reliability monitoring, failure diagnosis,
cross-domain scoring, and A2A trust management for LLM agents.

Validated performance (held-out evaluation only — no in-sample figures):
  Within-domain AUROC (behavioral, $0):         ~0.81  (exp88 5-fold CV, HotpotQA)
  Within-domain AUROC (+ Sonnet judge):         ~0.78  (exp89)
  Within-domain AUROC (+ local verifier):       ~0.80  (exp111, 200 labels, $0 inference)
  Cross-domain AUROC (structural LogReg, $0):   ~0.73  (exp119, HP→TriviaQA, 200 labels)
  Cross-domain AUROC (P(True) Haiku alone):     ~0.74  (exp120, ~$0.0003/call, zero-shot)
  Cross-domain AUROC (behavioral+P(True) 50/50):~0.78  (exp120, best cross-domain signal)
  Alert precision at FPR ≤ 10%:                 0.908  (exp92 conformal calibration)
  Mid-chain abort at step 2:                     AUROC 0.683  (exp107)

v0.9.0 new:
  guard.score_with_ptrue()           — P(True) ensemble (exp120, ~$0.0003/call)
  guard.fit_structural_verifier()    — structural-only LogReg for cross-domain (exp119/124)
  guard.fit_structural_verifier(..., target_unlabeled_runs=...) — +2pp with unlabeled target data

Quick start
-----------
    from llm_guard import AgentGuard, LLMGuard, SmartRouter

    # --- Chain scoring (behavioral, $0) ---
    guard  = AgentGuard()
    result = guard.score_chain(question, steps, final_answer)
    trust  = guard.generate_trust_object(question, steps, final_answer)

    # --- Cross-domain scoring with P(True) (best cross-domain, ~$0.0003/call) ---
    guard  = AgentGuard(api_key="sk-ant-...")
    result = guard.score_with_ptrue(question, steps, final_answer)
    # result.risk_score is behavioral+P(True) ensemble (AUROC ~0.78 cross-domain)

    # --- Cross-domain structural LogReg ($0 inference, 200 labeled source chains) ---
    guard = AgentGuard()
    guard.fit_structural_verifier(labeled_source_runs)
    # Optional: pass unlabeled target chains for feature normalization (+2pp)
    guard.fit_structural_verifier(labeled_source_runs, target_unlabeled_runs=target_runs)
    result = guard.score_chain(question, steps, final_answer)

    # --- Local verifier (within-domain, $0 inference after 200 labels) ---
    guard = AgentGuard(use_local_verifier=True)
    guard.fit_verifier(labeled_runs)
    result = guard.score_chain(question, steps, final_answer)

    # --- Zero-install nano scorer (no package needed) ---
    from llm_guard import QPPGNano
    nano = QPPGNano()
    result = nano.score_chain(question, steps, final_answer)

    # --- Cost-optimal model routing ---
    router = SmartRouter(LLMGuard(api_key="sk-ant-..."))
    result = router.route("What is 15% of 240?")
    print(result.model_used)  # Haiku for easy, Sonnet/Opus for hard
"""

from qppg.guard import QPPGLLMGuard as LLMGuard
from qppg.guard import GuardResult
from llm_guard.client import GuardClient, ScoreResult, MonitorResult
from llm_guard.router import SmartRouter, RouterResult
from llm_guard.agent_guard import AgentGuard, AgentStepResult, ChainTrustResult
from llm_guard.trust_object import A2ATrustObject, MeshResult, StreamGuardResult, TemporalValidity
from llm_guard.query_rewriter import QueryRewriter, RewriteResult
from llm_guard.nano import QPPGNano
from llm_guard.local_verifier import LocalVerifier, FEATURE_NAMES, extract_features
from llm_guard.adapter_registry import AdapterRegistry, AdapterConfig, AdapterResult
from llm_guard.white_box_probe import WhiteBoxProbe, ProbeResult
from llm_guard.step_normalizer import normalize_steps, validate_step_coverage
from llm_guard.adaptive_cisc import AdaptiveCISC, AdaptiveCISCRegistry
from llm_guard.drift_detector import DriftDetector, DriftMonitor, DriftEvent
from llm_guard.integrations.langchain import AgentGuardCallback
from llm_guard.integrations.llamaindex import AgentGuardEventHandler
from llm_guard.integrations.crewai import AgentGuardCrewCallback

__version__ = "0.9.0"
__all__ = [
    # One-line SDK client (SaaS + local modes)
    "GuardClient",
    "ScoreResult",
    "MonitorResult",
    # Core guard (KNN + repair)
    "LLMGuard",
    "GuardResult",
    # Cost-optimal routing
    "SmartRouter",
    "RouterResult",
    # Agent monitoring (SC_OLD + Sonnet judge / local verifier)
    "AgentGuard",
    "AgentStepResult",
    "ChainTrustResult",
    # A2A trust object + stream guard (exp113) + mesh routing (exp115)
    "A2ATrustObject",
    "StreamGuardResult",
    "MeshResult",
    "TemporalValidity",
    # Query diversification
    "QueryRewriter",
    "RewriteResult",
    # Zero-install nano scorer
    "QPPGNano",
    # Local verifier (LogReg on 12 SC features, $0 inference)
    "LocalVerifier",
    "FEATURE_NAMES",
    "extract_features",
    # Adaptive adapter selection (exp116)
    "AdapterRegistry",
    "AdapterConfig",
    "AdapterResult",
    # White-box hidden-state probe (exp117)
    "WhiteBoxProbe",
    "ProbeResult",
    # Framework integrations (2-line drop-in callbacks)
    "AgentGuardCallback",
    "AgentGuardEventHandler",
    "AgentGuardCrewCallback",
    # Multi-format step normalization
    "normalize_steps",
    "validate_step_coverage",
    # Adaptive CISC threshold bandit
    "AdaptiveCISC",
    "AdaptiveCISCRegistry",
    # Drift detection (exp118: CUSUM + PSI, validated)
    "DriftDetector",
    "DriftMonitor",
    "DriftEvent",
]
