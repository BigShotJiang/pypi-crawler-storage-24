"""
tracker.py — Metrics tracking, validation, and RL feedback loop for llm-guard-kit MCP server.

Three concerns:
  1. MetricsTracker  — SQLite store for every scored chain + human feedback
  2. AUROCTracker    — rolling AUROC over time windows (validation)
  3. RLFeedbackLoop  — online LogReg retraining from accumulated human labels
"""

from __future__ import annotations

import json
import math
import sqlite3
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional, Tuple

import numpy as np

DB_PATH = Path.home() / ".llm_guard_mcp" / "metrics.db"
DB_PATH.parent.mkdir(parents=True, exist_ok=True)


# ── Schema ─────────────────────────────────────────────────────────────────────

_SCHEMA = """
CREATE TABLE IF NOT EXISTS chains (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL    NOT NULL,           -- unix timestamp
    session_id  TEXT,
    question    TEXT    NOT NULL,
    final_answer TEXT,
    n_steps     INTEGER,
    risk_score  REAL,
    tier        TEXT,                       -- LOW / MEDIUM / HIGH
    ptrue_score REAL,
    beh_score   REAL,
    aborted     INTEGER DEFAULT 0,          -- 1 if stream_guard aborted
    human_label INTEGER DEFAULT NULL,       -- NULL=unlabeled, 0=correct, 1=wrong
    feedback_ts REAL    DEFAULT NULL,       -- when human labeled it
    source      TEXT    DEFAULT 'api',      -- api / mcp / cursor / claude_code
    metadata    TEXT    DEFAULT '{}'        -- JSON blob for extras
);

CREATE TABLE IF NOT EXISTS rl_checkpoints (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    ts          REAL    NOT NULL,
    n_labels    INTEGER,
    auroc       REAL,
    precision   REAL,
    recall      REAL,
    model_bytes BLOB                        -- pickled sklearn model
);

CREATE TABLE IF NOT EXISTS auroc_windows (
    ts          REAL    NOT NULL,
    window_days INTEGER NOT NULL,
    n_chains    INTEGER,
    n_labeled   INTEGER,
    auroc       REAL,
    PRIMARY KEY (ts, window_days)
);
"""


# ── MetricsTracker ──────────────────────────────────────────────────────────────

@dataclass
class ChainRecord:
    question:     str
    final_answer: str
    n_steps:      int
    risk_score:   float
    tier:         str
    ptrue_score:  float  = 0.0
    beh_score:    float  = 0.0
    aborted:      bool   = False
    session_id:   str    = ""
    source:       str    = "api"
    metadata:     dict   = None

    def __post_init__(self):
        if self.metadata is None:
            self.metadata = {}


class MetricsTracker:
    """Persistent SQLite store for all scored chains + human feedback."""

    def __init__(self, db_path: Path = DB_PATH):
        self.db_path = db_path
        self._con = sqlite3.connect(str(db_path), check_same_thread=False)
        self._con.row_factory = sqlite3.Row
        self._con.executescript(_SCHEMA)
        self._con.commit()

    # ── Write ─────────────────────────────────────────────────────────────────

    def log_chain(self, record: ChainRecord) -> int:
        """Insert a scored chain. Returns the new row ID."""
        cur = self._con.execute(
            """INSERT INTO chains
               (ts, session_id, question, final_answer, n_steps, risk_score, tier,
                ptrue_score, beh_score, aborted, source, metadata)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                time.time(),
                record.session_id,
                record.question[:500],
                (record.final_answer or "")[:500],
                record.n_steps,
                record.risk_score,
                record.tier,
                record.ptrue_score,
                record.beh_score,
                int(record.aborted),
                record.source,
                json.dumps(record.metadata),
            )
        )
        self._con.commit()
        return cur.lastrowid

    def add_feedback(self, chain_id: int, correct: bool) -> bool:
        """
        Record human feedback: correct=True means the answer WAS right.
        Returns True if the row was found and updated.
        """
        n = self._con.execute(
            "UPDATE chains SET human_label=?, feedback_ts=? WHERE id=?",
            (int(not correct), time.time(), chain_id)
        ).rowcount
        self._con.commit()
        return n > 0

    # ── Read ──────────────────────────────────────────────────────────────────

    def get_labeled(self, days: float = None) -> List[dict]:
        """Return all chains with human labels (optionally within last N days)."""
        q = "SELECT * FROM chains WHERE human_label IS NOT NULL"
        params = []
        if days is not None:
            q += " AND ts >= ?"
            params.append(time.time() - days * 86400)
        q += " ORDER BY ts DESC"
        return [dict(r) for r in self._con.execute(q, params)]

    def get_recent(self, n: int = 100) -> List[dict]:
        """Return last N scored chains (labeled or not)."""
        return [dict(r) for r in self._con.execute(
            "SELECT * FROM chains ORDER BY ts DESC LIMIT ?", (n,))]

    def summary(self, days: float = 7) -> dict:
        cutoff = time.time() - days * 86400
        rows = self._con.execute(
            "SELECT tier, risk_score, aborted, human_label FROM chains WHERE ts >= ?",
            (cutoff,)
        ).fetchall()
        total = len(rows)
        if total == 0:
            return {"total": 0, "days": days}
        labeled = [r for r in rows if r["human_label"] is not None]
        wrong   = [r for r in labeled if r["human_label"] == 1]
        return {
            "days":           days,
            "total":          total,
            "aborted":        sum(1 for r in rows if r["aborted"]),
            "tier_LOW":       sum(1 for r in rows if r["tier"] == "LOW"),
            "tier_MEDIUM":    sum(1 for r in rows if r["tier"] == "MEDIUM"),
            "tier_HIGH":      sum(1 for r in rows if r["tier"] == "HIGH"),
            "mean_risk":      round(sum(r["risk_score"] for r in rows) / total, 4),
            "n_labeled":      len(labeled),
            "n_wrong_labeled": len(wrong),
            "label_error_rate": round(len(wrong) / max(len(labeled), 1), 3),
        }

    def pending_feedback(self, limit: int = 10) -> List[dict]:
        """Return recently scored HIGH-risk chains awaiting human feedback."""
        return [dict(r) for r in self._con.execute(
            """SELECT id, ts, question, final_answer, risk_score, tier
               FROM chains WHERE human_label IS NULL AND tier='HIGH'
               ORDER BY ts DESC LIMIT ?""", (limit,))]


# ── AUROCTracker ───────────────────────────────────────────────────────────────

class AUROCTracker:
    """Compute rolling AUROC over labeled feedback windows."""

    def __init__(self, tracker: MetricsTracker):
        self.tracker = tracker

    def compute(self, days: float = 30) -> Optional[float]:
        labeled = self.tracker.get_labeled(days=days)
        if len(labeled) < 10:
            return None
        try:
            from sklearn.metrics import roc_auc_score
            y     = np.array([r["human_label"] for r in labeled])
            score = np.array([r["risk_score"]  for r in labeled])
            if len(np.unique(y)) < 2:
                return None
            auroc = float(round(roc_auc_score(y, score), 4))
            # Store snapshot
            self.tracker._con.execute(
                "INSERT OR REPLACE INTO auroc_windows VALUES (?,?,?,?,?)",
                (time.time(), int(days), len(labeled), len(labeled), auroc)
            )
            self.tracker._con.commit()
            return auroc
        except Exception:
            return None

    def history(self, n: int = 20) -> List[dict]:
        """Return last N AUROC snapshots."""
        return [dict(r) for r in self.tracker._con.execute(
            "SELECT * FROM auroc_windows ORDER BY ts DESC LIMIT ?", (n,))]

    def drift_alert(self, days: float = 30, min_delta: float = 0.05) -> Optional[str]:
        """
        Return a warning string if AUROC has dropped by min_delta from peak.
        Returns None if no drift detected or insufficient data.
        """
        hist = self.history(10)
        if len(hist) < 3:
            return None
        aurocs = [h["auroc"] for h in hist if h["auroc"] is not None]
        if len(aurocs) < 3:
            return None
        peak    = max(aurocs)
        current = aurocs[0]
        if peak - current >= min_delta:
            return (f"DRIFT ALERT: AUROC dropped from {peak:.3f} to {current:.3f} "
                    f"(Δ={peak-current:.3f} ≥ {min_delta} threshold). "
                    f"Consider retraining or reviewing recent flagged chains.")
        return None


# ── RLFeedbackLoop ─────────────────────────────────────────────────────────────

class RLFeedbackLoop:
    """
    Online RL-style adaptation: retrain LogReg local verifier from accumulated
    human feedback labels. Uses behavioral components (SC features) as input.

    This is not deep RL — it's supervised retraining triggered by label accumulation.
    The 'RL' framing: each human feedback = reward signal; we update the policy
    (LogReg weights) when enough new signals arrive.

    Trigger: retrain when N new labels have accumulated since last checkpoint.
    """

    RETRAIN_EVERY = 20    # retrain after every 20 new human labels
    MIN_LABELS    = 30    # minimum labels before first retrain
    MIN_PER_CLASS = 5     # need at least 5 wrong and 5 correct

    def __init__(self, tracker: MetricsTracker):
        self.tracker = tracker
        self._clf    = None   # current LogReg model
        self._n_at_last_train = 0

    def should_retrain(self) -> Tuple[bool, str]:
        labeled = self.tracker.get_labeled()
        n = len(labeled)
        n_wrong   = sum(1 for r in labeled if r["human_label"] == 1)
        n_correct = n - n_wrong
        if n < self.MIN_LABELS:
            return False, f"Need {self.MIN_LABELS - n} more labels before first retrain (have {n})"
        if n_wrong < self.MIN_PER_CLASS or n_correct < self.MIN_PER_CLASS:
            return False, f"Need ≥{self.MIN_PER_CLASS} per class (have {n_correct} correct, {n_wrong} wrong)"
        new_since_last = n - self._n_at_last_train
        if new_since_last < self.RETRAIN_EVERY:
            return False, f"Need {self.RETRAIN_EVERY - new_since_last} more labels before retraining"
        return True, f"Ready: {n} labels ({n_correct} correct, {n_wrong} wrong), {new_since_last} new since last train"

    def retrain(self, guard=None) -> dict:
        """
        Retrain LogReg on all labeled chains.
        Returns a dict with new AUROC, precision, recall, n_labels.
        If guard is provided, update guard's local_verifier weights.
        """
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler
        from sklearn.pipeline import Pipeline
        from sklearn.model_selection import cross_val_score
        from sklearn.metrics import roc_auc_score, precision_score, recall_score
        import pickle

        labeled = self.tracker.get_labeled()
        if not labeled:
            return {"error": "No labeled data"}

        # Features: [risk_score, beh_score, ptrue_score, n_steps, tier_num]
        def extract(r):
            tier_num = {"LOW": 0, "MEDIUM": 0.5, "HIGH": 1.0}.get(r["tier"], 0.5)
            return [
                r["risk_score"]  or 0.0,
                r["beh_score"]   or 0.0,
                r["ptrue_score"] or 0.0,
                min((r["n_steps"] or 3) / 10.0, 1.0),
                tier_num,
            ]

        X = np.array([extract(r) for r in labeled])
        y = np.array([r["human_label"] for r in labeled])

        if len(np.unique(y)) < 2:
            return {"error": "Single class — need more labels of the other class"}

        clf = Pipeline([
            ("sc", StandardScaler()),
            ("lr", LogisticRegression(max_iter=500, class_weight="balanced",
                                       C=1.0, solver="lbfgs"))
        ])

        # Cross-validated AUROC (honest estimate)
        if len(y) >= 20:
            cv_aurocs = cross_val_score(clf, X, y, cv=min(5, len(y)//5),
                                         scoring="roc_auc")
            cv_auroc = float(round(np.mean(cv_aurocs), 4))
        else:
            cv_auroc = None

        # Fit on all data
        clf.fit(X, y)
        self._clf = clf

        proba = clf.predict_proba(X)[:, 1]
        train_auroc = float(round(roc_auc_score(y, proba), 4))

        # Precision/recall at 0.5 threshold
        pred = (proba >= 0.5).astype(int)
        prec = float(round(precision_score(y, pred, zero_division=0), 3))
        rec  = float(round(recall_score(y, pred,    zero_division=0), 3))

        self._n_at_last_train = len(labeled)

        # Persist checkpoint
        model_bytes = pickle.dumps(clf)
        self.tracker._con.execute(
            "INSERT INTO rl_checkpoints (ts, n_labels, auroc, precision, recall, model_bytes) VALUES (?,?,?,?,?,?)",
            (time.time(), len(labeled), train_auroc, prec, rec, model_bytes)
        )
        self.tracker._con.commit()

        result = {
            "status":       "retrained",
            "n_labels":     len(labeled),
            "n_wrong":      int(y.sum()),
            "n_correct":    int((1 - y).sum()),
            "train_auroc":  train_auroc,
            "cv_auroc":     cv_auroc,
            "precision":    prec,
            "recall":       rec,
            "improvement_note": (
                f"CV AUROC {cv_auroc:.3f}" if cv_auroc else
                f"Train AUROC {train_auroc:.3f} (need ≥20 labels for CV)"
            ),
        }

        # Optionally push updated weights into AgentGuard
        if guard is not None:
            try:
                guard._local_verifier = clf
                guard._use_local_verifier = True
                result["guard_updated"] = True
            except Exception as e:
                result["guard_update_error"] = str(e)

        return result

    def predict(self, risk_score: float, beh_score: float, ptrue_score: float,
                n_steps: int, tier: str) -> Optional[float]:
        """Use current RL model to re-score a chain. Returns None if no model."""
        if self._clf is None:
            return None
        tier_num = {"LOW": 0, "MEDIUM": 0.5, "HIGH": 1.0}.get(tier, 0.5)
        X = np.array([[risk_score, beh_score, ptrue_score,
                       min(n_steps / 10.0, 1.0), tier_num]])
        return float(round(self._clf.predict_proba(X)[0, 1], 4))

    def load_latest(self) -> bool:
        """Load the most recent RL checkpoint from DB."""
        import pickle
        row = self.tracker._con.execute(
            "SELECT model_bytes, n_labels FROM rl_checkpoints ORDER BY ts DESC LIMIT 1"
        ).fetchone()
        if row and row["model_bytes"]:
            try:
                self._clf = pickle.loads(row["model_bytes"])
                self._n_at_last_train = row["n_labels"]
                return True
            except Exception:
                pass
        return False

    def checkpoint_history(self, n: int = 10) -> List[dict]:
        return [dict(r) for r in self.tracker._con.execute(
            "SELECT ts, n_labels, auroc, precision, recall FROM rl_checkpoints ORDER BY ts DESC LIMIT ?",
            (n,))]
