"""
server.py — llm-guard-kit MCP Server.

Exposes llm-guard-kit as MCP tools that Claude, Cursor, and any MCP-compatible
host can call. Includes metrics tracking and RL feedback loop.

Tools exposed:
  score_chain         — score a completed agent chain (behavioral + P(True))
  stream_check        — mid-chain abort check (call after step 2)
  submit_feedback     — human labels a chain as correct/wrong (RL signal)
  get_metrics         — summary stats for a time window
  get_auroc           — rolling AUROC over labeled feedback
  trigger_retrain     — retrain RL model from accumulated labels
  get_pending_review  — chains awaiting human feedback
  get_rl_status       — current RL model status and training history

Run:
  python -m llm_guard_mcp.server          # stdio transport (Claude Desktop / Cursor)
  python -m llm_guard_mcp.server --sse    # SSE transport (web clients)
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

# ── Path setup ────────────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from llm_guard.agent_guard import AgentGuard
from llm_guard_mcp.tracker import MetricsTracker, AUROCTracker, RLFeedbackLoop, ChainRecord

# ── Globals ───────────────────────────────────────────────────────────────────
_API_KEY = os.environ.get("ANTHROPIC_API_KEY", "")
_guard   = None
_tracker = MetricsTracker()
_auroc   = AUROCTracker(_tracker)
_rl      = RLFeedbackLoop(_tracker)
_rl.load_latest()   # restore last RL checkpoint if available


def _get_guard() -> AgentGuard:
    global _guard
    if _guard is None:
        _guard = AgentGuard(
            api_key=_API_KEY if _API_KEY else None,
            use_judge=bool(_API_KEY),  # enable judge only when key is present
        )
    return _guard


# ── MCP Server ────────────────────────────────────────────────────────────────
app = Server("llm-guard-kit")


@app.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="score_chain",
            description=(
                "Score a completed agent chain for reliability. "
                "Returns risk_score (0=safe, 1=wrong), tier (LOW/MEDIUM/HIGH), "
                "and whether human review is needed. "
                "Call this after every multi-step agent response before returning to user."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "question":     {"type": "string", "description": "The original user question"},
                    "steps":        {"type": "array",  "description": "List of agent steps. Each step: {thought, action_type, action_arg, observation}"},
                    "final_answer": {"type": "string", "description": "The agent's final answer"},
                    "session_id":   {"type": "string", "description": "Optional session identifier for tracking"},
                    "source":       {"type": "string", "description": "Source: api | cursor | claude_code | langchain", "default": "mcp"},
                },
                "required": ["question", "steps", "final_answer"],
            }
        ),
        Tool(
            name="stream_check",
            description=(
                "Mid-chain abort check. Call after step 2 (index 1) with steps so far. "
                "If should_abort=true, stop the agent immediately — it is unlikely to succeed. "
                "Saves API cost by aborting failing chains early."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "question":    {"type": "string"},
                    "steps_so_far": {"type": "array", "description": "Steps completed so far (typically 2)"},
                    "session_id":  {"type": "string"},
                },
                "required": ["question", "steps_so_far"],
            }
        ),
        Tool(
            name="submit_feedback",
            description=(
                "Submit human feedback on a scored chain. "
                "This is the RL signal: every label improves the model over time. "
                "Call this when a user marks an answer as correct or wrong."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "chain_id": {"type": "integer", "description": "ID returned by score_chain"},
                    "correct":  {"type": "boolean", "description": "true if the answer was correct, false if wrong"},
                    "note":     {"type": "string",  "description": "Optional note explaining the error"},
                },
                "required": ["chain_id", "correct"],
            }
        ),
        Tool(
            name="get_metrics",
            description="Get summary metrics for recent chains (default: last 7 days).",
            inputSchema={
                "type": "object",
                "properties": {
                    "days": {"type": "number", "description": "Time window in days", "default": 7},
                },
            }
        ),
        Tool(
            name="get_auroc",
            description=(
                "Compute rolling AUROC from human-labeled feedback. "
                "Returns current model quality and drift alerts. "
                "Requires at least 10 labeled chains."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "days": {"type": "number", "description": "Window for AUROC computation", "default": 30},
                },
            }
        ),
        Tool(
            name="trigger_retrain",
            description=(
                "Retrain the RL model from accumulated human feedback labels. "
                "Automatically triggered when 20+ new labels accumulate, "
                "but can be called manually. Returns new AUROC and precision/recall."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="get_pending_review",
            description=(
                "Get HIGH-risk chains that are waiting for human feedback. "
                "Use this to show reviewers what needs labeling to improve the RL model."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "limit": {"type": "integer", "description": "Max chains to return", "default": 10},
                },
            }
        ),
        Tool(
            name="get_rl_status",
            description="Get current RL model status: training history, AUROC trend, drift alerts.",
            inputSchema={"type": "object", "properties": {}},
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[TextContent]:
    try:
        result = await _dispatch(name, arguments)
        return [TextContent(type="text", text=json.dumps(result, indent=2))]
    except Exception as e:
        return [TextContent(type="text", text=json.dumps({
            "error": str(e), "tool": name
        }))]


async def _dispatch(name: str, args: dict) -> Any:

    # ── score_chain ────────────────────────────────────────────────────────────
    if name == "score_chain":
        guard        = _get_guard()
        question     = args["question"]
        steps        = args.get("steps", [])
        final_answer = args.get("final_answer", "")
        session_id   = args.get("session_id", "")
        source       = args.get("source", "mcp")

        # Score (P(True) if API key available, else behavioral only)
        if _API_KEY:
            result = guard.score_with_ptrue(question, steps, final_answer)
        else:
            result = guard.score_chain(question, steps, final_answer)

        beh_score   = result.behavioral_score
        risk_score  = result.risk_score
        tier        = result.confidence_tier
        ptrue_score = getattr(result, "ptrue_score", 0.0) or 0.0

        # RL re-score (if model trained)
        rl_score = _rl.predict(risk_score, beh_score, ptrue_score, len(steps), tier)

        # Log to tracker
        record = ChainRecord(
            question=question, final_answer=final_answer,
            n_steps=len(steps), risk_score=risk_score, tier=tier,
            ptrue_score=ptrue_score, beh_score=beh_score,
            aborted=False, session_id=session_id, source=source,
        )
        chain_id = _tracker.log_chain(record)

        # Auto-trigger retrain check
        should, reason = _rl.should_retrain()
        retrain_msg = None
        if should:
            retrain_result = _rl.retrain(guard)
            retrain_msg = f"RL model auto-retrained: CV AUROC={retrain_result.get('cv_auroc')}"

        response = {
            "chain_id":    chain_id,
            "risk_score":  round(risk_score, 4),
            "tier":        tier,
            "needs_review": tier in ("HIGH", "MEDIUM"),
            "needs_alert":  tier == "HIGH",
            "beh_score":   round(beh_score, 4),
            "ptrue_score": round(ptrue_score, 4),
            "rl_score":    round(rl_score, 4) if rl_score is not None else None,
            "interpretation": _interpret(risk_score, tier),
            "action":      _recommend_action(tier),
        }
        if retrain_msg:
            response["rl_retrain"] = retrain_msg
        return response

    # ── stream_check ───────────────────────────────────────────────────────────
    elif name == "stream_check":
        guard      = _get_guard()
        question   = args["question"]
        steps      = args.get("steps_so_far", [])
        session_id = args.get("session_id", "")

        sg = guard.stream_guard(question, steps, abort_threshold=0.65)

        if sg.abort:
            record = ChainRecord(
                question=question, final_answer="[ABORTED]",
                n_steps=len(steps), risk_score=sg.risk_at_step, tier="HIGH",
                aborted=True, session_id=session_id, source="mcp",
            )
            chain_id = _tracker.log_chain(record)
        else:
            chain_id = None

        return {
            "should_abort": sg.abort,
            "risk_score":   round(sg.risk_at_step, 4),
            "step":         len(steps),
            "chain_id":     chain_id,
            "message": (
                "ABORT: Agent is not finding useful information. Stop and report failure."
                if sg.abort else
                "CONTINUE: Chain looks on-track so far."
            ),
        }

    # ── submit_feedback ────────────────────────────────────────────────────────
    elif name == "submit_feedback":
        chain_id = args["chain_id"]
        correct  = args["correct"]
        note     = args.get("note", "")

        found = _tracker.add_feedback(chain_id, correct)
        if not found:
            return {"error": f"chain_id={chain_id} not found"}

        labeled = _tracker.get_labeled()
        should, reason = _rl.should_retrain()

        response = {
            "status":        "feedback_recorded",
            "chain_id":      chain_id,
            "label":         "correct" if correct else "wrong",
            "n_labeled":     len(labeled),
            "retrain_ready": should,
            "retrain_reason": reason,
        }
        if note:
            response["note"] = note
        if should:
            response["suggestion"] = "Call trigger_retrain to update the RL model with new labels."
        return response

    # ── get_metrics ────────────────────────────────────────────────────────────
    elif name == "get_metrics":
        days    = float(args.get("days", 7))
        summary = _tracker.summary(days=days)
        recent  = _tracker.get_recent(5)

        return {
            "summary": summary,
            "recent_chains": [
                {
                    "id": r["id"],
                    "question": r["question"][:60] + "...",
                    "risk": round(r["risk_score"], 3),
                    "tier": r["tier"],
                    "labeled": r["human_label"] is not None,
                }
                for r in recent
            ],
            "rl_status": {
                "model_trained": _rl._clf is not None,
                "labels_since_last_train": len(_tracker.get_labeled()) - _rl._n_at_last_train,
            },
        }

    # ── get_auroc ──────────────────────────────────────────────────────────────
    elif name == "get_auroc":
        days  = float(args.get("days", 30))
        auroc = _auroc.compute(days=days)
        drift = _auroc.drift_alert()
        hist  = _auroc.history(5)

        return {
            "auroc":           auroc,
            "window_days":     days,
            "n_labeled":       len(_tracker.get_labeled(days=days)),
            "drift_alert":     drift,
            "auroc_history":   [
                {"ts": h["ts"], "auroc": h["auroc"], "n": h["n_labeled"]}
                for h in hist
            ],
            "baseline_ref": {
                "behavioral_only":   0.682,
                "ptrue_ensemble":    0.775,
                "integration_target": 0.795,
            },
            "status": (
                "INSUFFICIENT DATA (need ≥10 labels)" if auroc is None else
                f"AUROC={auroc:.3f} — " + (
                    "EXCELLENT (above integration target)"  if auroc >= 0.795 else
                    "GOOD (above P(True) baseline)"         if auroc >= 0.775 else
                    "ACCEPTABLE (above behavioral baseline)" if auroc >= 0.682 else
                    "BELOW BASELINE — review scoring setup"
                )
            ),
        }

    # ── trigger_retrain ────────────────────────────────────────────────────────
    elif name == "trigger_retrain":
        should, reason = _rl.should_retrain()
        if not should:
            return {"status": "skipped", "reason": reason}
        guard  = _get_guard()
        result = _rl.retrain(guard)
        return result

    # ── get_pending_review ─────────────────────────────────────────────────────
    elif name == "get_pending_review":
        limit   = int(args.get("limit", 10))
        pending = _tracker.pending_feedback(limit=limit)
        labeled = _tracker.get_labeled()
        should, reason = _rl.should_retrain()

        return {
            "pending_count": len(pending),
            "pending": [
                {
                    "chain_id":    r["id"],
                    "question":    r["question"][:80],
                    "answer":      r["final_answer"][:80],
                    "risk_score":  round(r["risk_score"], 3),
                    "tier":        r["tier"],
                    "how_to_label": f"Call submit_feedback with chain_id={r['id']}, correct=true/false",
                }
                for r in pending
            ],
            "total_labeled":  len(labeled),
            "retrain_ready":  should,
            "retrain_reason": reason,
        }

    # ── get_rl_status ──────────────────────────────────────────────────────────
    elif name == "get_rl_status":
        hist       = _rl.checkpoint_history(10)
        auroc_hist = _auroc.history(10)
        labeled    = _tracker.get_labeled()
        should, reason = _rl.should_retrain()

        return {
            "model_trained":   _rl._clf is not None,
            "total_labels":    len(labeled),
            "labels_wrong":    sum(1 for r in labeled if r["human_label"] == 1),
            "labels_correct":  sum(1 for r in labeled if r["human_label"] == 0),
            "labels_since_last_train": len(labeled) - _rl._n_at_last_train,
            "retrain_ready":   should,
            "retrain_reason":  reason,
            "training_history": [
                {
                    "n_labels":  h["n_labels"],
                    "auroc":     h["auroc"],
                    "precision": h["precision"],
                    "recall":    h["recall"],
                    "ts":        h["ts"],
                }
                for h in hist
            ],
            "auroc_trend": [
                {"auroc": h["auroc"], "n": h["n_labeled"], "ts": h["ts"]}
                for h in auroc_hist
            ],
            "drift_alert": _auroc.drift_alert(),
            "rl_loop_config": {
                "retrain_every_n_labels": _rl.RETRAIN_EVERY,
                "min_labels_for_first_train": _rl.MIN_LABELS,
                "min_per_class": _rl.MIN_PER_CLASS,
                "features": ["risk_score", "beh_score", "ptrue_score", "n_steps_norm", "tier_num"],
            },
        }

    else:
        return {"error": f"Unknown tool: {name}"}


# ── Interpretation helpers ─────────────────────────────────────────────────────

def _interpret(risk: float, tier: str) -> str:
    if tier == "LOW":
        return f"LOW risk ({risk:.3f}): Agent found clear evidence. Answer is likely reliable."
    elif tier == "MEDIUM":
        return f"MEDIUM risk ({risk:.3f}): Some uncertainty detected. Spot-check recommended."
    else:
        return f"HIGH risk ({risk:.3f}): Agent failed, contradicted itself, or gave up. Do not use without verification."


def _recommend_action(tier: str) -> str:
    return {
        "LOW":    "Use answer directly. No review needed.",
        "MEDIUM": "Show answer to user with caveat; log for periodic review.",
        "HIGH":   "Block answer. Alert human reviewer. Do not send to end user.",
    }.get(tier, "Review manually.")


# ── Entry point ────────────────────────────────────────────────────────────────

async def main():
    import argparse
    parser = argparse.ArgumentParser(description="llm-guard-kit MCP Server")
    parser.add_argument("--sse", action="store_true", help="Use SSE transport instead of stdio")
    parser.add_argument("--port", type=int, default=8765, help="Port for SSE transport")
    args = parser.parse_args()

    if args.sse:
        from mcp.server.sse import SseServerTransport
        from starlette.applications import Starlette
        from starlette.routing import Route
        import uvicorn

        sse = SseServerTransport("/messages/")

        async def handle_sse(request):
            async with sse.connect_sse(request.scope, request.receive, request._send) as streams:
                await app.run(streams[0], streams[1], app.create_initialization_options())

        starlette_app = Starlette(routes=[Route("/sse", endpoint=handle_sse)])
        print(f"llm-guard-kit MCP server running on http://localhost:{args.port}/sse", file=sys.stderr)
        uvicorn.run(starlette_app, host="0.0.0.0", port=args.port)
    else:
        print("llm-guard-kit MCP server starting (stdio transport)...", file=sys.stderr)
        async with stdio_server() as (read_stream, write_stream):
            await app.run(read_stream, write_stream, app.create_initialization_options())


def run():
    """Sync entry point for `llm-guard-mcp` CLI script (registered in pyproject.toml)."""
    asyncio.run(main())


if __name__ == "__main__":
    run()
