"""Detect authentication credentials for the Ansel API."""

from __future__ import annotations

import os


def get_token() -> str | None:
    """Return the best available auth token.

    Priority:
    1. ANTHROPIC_API_KEY (direct API key)
    2. CLAUDE_CODE_OAUTH_TOKEN (OAuth from Claude Code / Cowork)
    """
    return os.getenv('ANTHROPIC_API_KEY') or os.getenv('CLAUDE_CODE_OAUTH_TOKEN')


def get_identity_headers() -> dict[str, str]:
    """Return identity headers from Cowork environment variables.

    These are sent on every request so the Worker can scope
    persistence and queries to the calling account.
    """
    headers: dict[str, str] = {}
    account_id = os.getenv('CLAUDE_CODE_ACCOUNT_UUID')
    if account_id:
        headers['X-Account-Id'] = account_id
    email = os.getenv('CLAUDE_CODE_USER_EMAIL')
    if email:
        headers['X-Account-Email'] = email
    return headers
