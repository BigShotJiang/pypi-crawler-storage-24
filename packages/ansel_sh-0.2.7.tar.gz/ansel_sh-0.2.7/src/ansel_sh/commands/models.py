"""ansel models — train forecasting models from uploaded files."""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Any

from ..auth import get_token
from ..client import get_json, post_stream
from ..output import on_models_event, print_models_result


def _require_token() -> str | None:
    """Get auth token or print error."""
    token = get_token()
    if not token:
        print(
            'error: no credentials found. Set ANTHROPIC_API_KEY or CLAUDE_CODE_OAUTH_TOKEN.',
            file=sys.stderr,
        )
    return token


def _parse_flags(args: list[str]) -> tuple[list[str], dict[str, str]]:
    """Separate positional args from --flag value pairs."""
    positional: list[str] = []
    flags: dict[str, str] = {}
    i = 0
    while i < len(args):
        if args[i].startswith('--') and i + 1 < len(args):
            flags[args[i][2:]] = args[i + 1]
            i += 2
        else:
            positional.append(args[i])
            i += 1
    return positional, flags


def _build_params(flags: dict[str, str]) -> dict[str, str]:
    """Build query params from parsed flags."""
    params: dict[str, str] = {}
    if 'limit' in flags:
        params['limit'] = flags['limit']
    return params


def _run_models_path(token: str, path: Path, params: dict[str, str]) -> int:
    """ansel models <path> — upload CSVs and train models."""
    if path.is_dir():
        csv_files = sorted(path.glob('*.csv'))
        if not csv_files:
            print(f'error: no CSV files found in {path}', file=sys.stderr)
            return 1
    elif path.suffix.lower() == '.csv':
        csv_files = [path]
    else:
        print(f'error: {path} is not a CSV file', file=sys.stderr)
        return 1

    files_data = [('file', csv_file.name, csv_file.read_text()) for csv_file in csv_files]
    start = time.monotonic()
    result = post_stream(
        '/models', token, files=files_data, params=params, on_event=on_models_event
    )
    elapsed = time.monotonic() - start
    return print_models_result(result, elapsed)


def _run_models_ids(token: str, file_ids: list[str], params: dict[str, str]) -> int:
    """ansel models <file_id...> — train models from pre-uploaded files."""
    start = time.monotonic()
    result = post_stream(
        '/models',
        token,
        json_body={'file_ids': file_ids},
        params=params,
        on_event=on_models_event,
    )
    elapsed = time.monotonic() - start
    return print_models_result(result, elapsed)


def _run_list(token: str) -> int:
    """ansel models list"""
    from ..output import format_model_line

    data = get_json(token, '/models')
    if data is None:
        print('error: failed to fetch models', file=sys.stderr)
        return 1

    models_list: list[dict[str, Any]] = data.get('models', [])
    if not models_list:
        print('no models found')
        return 0

    for m in models_list:
        print(format_model_line(m))
    return 0


def run(args: list[str]) -> int:
    """Execute the models command."""
    if not args:
        print('ansel models: train forecasting models')
        print()
        print('Usage:')
        print('  ansel models <path>          Upload CSVs + train models')
        print('  ansel models <file_id...>    Train from pre-uploaded files')
        print('  ansel models list            List previously trained models')
        print()
        print('Flags:')
        print('  --limit N         Max series to train (default: 10)')
        print()
        print('Examples:')
        print('  ansel models ./sales.csv')
        print('  ansel models ./data --limit 5')
        print('  ansel models fil_abc fil_def')
        print('  ansel models list')
        return 1

    positional, flags = _parse_flags(args)
    params = _build_params(flags)

    token = _require_token()
    if not token:
        return 1

    if positional and positional[0] == 'list':
        return _run_list(token)

    # Detect mode: file IDs (fil_ prefix) vs path
    if all(arg.startswith('fil_') for arg in positional):
        return _run_models_ids(token, positional, params)

    if len(positional) != 1:
        print('error: provide a single path or one or more file IDs', file=sys.stderr)
        return 1

    path = Path(positional[0])
    if not path.exists():
        print(f'error: {path} not found', file=sys.stderr)
        return 1

    return _run_models_path(token, path, params)
