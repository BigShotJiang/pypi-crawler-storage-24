"""ansel forecast — generate demand forecasts."""

from __future__ import annotations

import sys
import time
from pathlib import Path
from typing import Any

from ..auth import get_token
from ..client import get_json, post_stream
from ..output import on_forecast_event, print_forecast_result


def _require_token() -> str | None:
    """Get auth token or print error."""
    token = get_token()
    if not token:
        print(
            'error: no credentials found. Set ANTHROPIC_API_KEY or CLAUDE_CODE_OAUTH_TOKEN.',
            file=sys.stderr,
        )
    return token


def _parse_flags(args: list[str]) -> tuple[list[str], dict[str, str]]:
    """Separate positional args from --flag value pairs.

    Returns (positional_args, flags_dict).
    """
    positional: list[str] = []
    flags: dict[str, str] = {}
    i = 0
    while i < len(args):
        if args[i].startswith('--') and i + 1 < len(args):
            flags[args[i][2:]] = args[i + 1]
            i += 2
        else:
            positional.append(args[i])
            i += 1
    return positional, flags


def _build_params(flags: dict[str, str]) -> dict[str, str]:
    """Build query params from parsed flags."""
    params: dict[str, str] = {}
    for key in ('horizon', 'target', 'interval', 'limit'):
        if key in flags:
            params[key] = flags[key]
    return params


def _run_forecast_path(token: str, path: Path, params: dict[str, str]) -> int:
    """ansel forecast <path> — upload CSVs and run full pipeline."""
    if path.is_dir():
        csv_files = sorted(path.glob('*.csv'))
        if not csv_files:
            print(f'error: no CSV files found in {path}', file=sys.stderr)
            return 1
    elif path.suffix.lower() == '.csv':
        csv_files = [path]
    else:
        print(f'error: {path} is not a CSV file', file=sys.stderr)
        return 1

    files_data = [('file', csv_file.name, csv_file.read_text()) for csv_file in csv_files]
    start = time.monotonic()
    result = post_stream(
        '/forecasts', token, files=files_data, params=params, on_event=on_forecast_event
    )
    elapsed = time.monotonic() - start
    return print_forecast_result(result, elapsed)


def _run_forecast_ids(token: str, file_ids: list[str], params: dict[str, str]) -> int:
    """ansel forecast <file_id...> — run pipeline from pre-uploaded files."""
    start = time.monotonic()
    result = post_stream(
        '/forecasts',
        token,
        json_body={'file_ids': file_ids},
        params=params,
        on_event=on_forecast_event,
    )
    elapsed = time.monotonic() - start
    return print_forecast_result(result, elapsed)


def _run_get(token: str, forecast_id: str) -> int:
    """ansel forecast get <fct_id>"""
    import json

    data = get_json(token, f'/forecasts/{forecast_id}')
    if data is None:
        print(f'error: forecast not found: {forecast_id}', file=sys.stderr)
        return 1

    series_id: str = data.get('series_id', '?')
    series_name: str = data.get('series_name', '')
    series_str = f'{series_name} ({series_id})' if series_name else series_id
    model_id: str = data.get('model_id', '?')
    interval: str = data.get('interval', '')
    horizon = data.get('horizon', '')
    created_at = str(data.get('created_at', ''))[:16]

    horizon_str = f'{horizon} {interval}s' if horizon and interval else ''
    parts = [forecast_id, series_str, horizon_str, created_at]
    print('  '.join(p for p in parts if p))
    print(f'model: https://api.ansel.sh/models/{model_id}')
    print()

    raw_items = data.get('items', '[]')
    if isinstance(raw_items, str):
        try:
            items = json.loads(raw_items)
        except (json.JSONDecodeError, TypeError):
            items = []
    else:
        items = raw_items

    if items:
        print('date        value')
        for item in items:
            print(f'{item.get("date", "?")}  {item.get("value", "?")}')

    return 0


def _run_list(token: str) -> int:
    """ansel forecast list"""
    from ..output import format_forecast_line

    data = get_json(token, '/forecasts')
    if data is None:
        print('error: failed to fetch forecasts', file=sys.stderr)
        return 1

    forecasts_list: list[dict[str, Any]] = data.get('forecasts', [])
    if not forecasts_list:
        print('no forecasts found')
        return 0

    for f in forecasts_list:
        print(format_forecast_line(f))
    return 0


def run(args: list[str]) -> int:
    """Execute the forecast command."""
    if not args:
        print('ansel forecast: generate demand forecasts')
        print()
        print('Usage:')
        print('  ansel forecast <path>          Full pipeline from local CSV files')
        print('  ansel forecast <file_id...>    Pipeline from pre-uploaded files')
        print('  ansel forecast get <fct_id>    Get forecast details and items')
        print('  ansel forecast list            List previously generated forecasts')
        print()
        print('Flags:')
        print('  --horizon N       Periods to forecast (default: 12)')
        print('  --target STR      What to forecast (default: demand)')
        print('  --interval STR    week | month | quarter (default: month)')
        print('  --limit N         Max series to process (default: 10)')
        print()
        print('Examples:')
        print('  ansel forecast ./sales.csv')
        print('  ansel forecast ./data --horizon 6 --interval week --limit 3')
        print('  ansel forecast fil_abc fil_def --horizon 6')
        return 1

    positional, flags = _parse_flags(args)
    params = _build_params(flags)

    token = _require_token()
    if not token:
        return 1

    if positional and positional[0] == 'get':
        if len(positional) < 2:
            print('error: forecast ID required', file=sys.stderr)
            return 1
        return _run_get(token, positional[1])

    if positional and positional[0] == 'list':
        return _run_list(token)

    # Detect mode: file IDs (fil_ prefix) vs path
    if all(arg.startswith('fil_') for arg in positional):
        return _run_forecast_ids(token, positional, params)

    if len(positional) != 1:
        print('error: provide a single path or one or more file IDs', file=sys.stderr)
        return 1

    path = Path(positional[0])
    if not path.exists():
        print(f'error: {path} not found', file=sys.stderr)
        return 1

    return _run_forecast_path(token, path, params)
