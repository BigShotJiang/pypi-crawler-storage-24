"""Output formatting for CLI results (Layer 2).

Formats structured SDK events for agent consumption.

Progress events print immediately as they arrive (via on_event callbacks).
Completion events print the final result after the stream closes.
"""

from __future__ import annotations

from typing import Any

from .client import StreamResult
from .parse import SDKEvent, parse_json_field

# ---- Shared formatters ----


def format_file_line(f: dict[str, Any]) -> str:
    """Format a single file as a one-line summary."""
    file_id: str = f.get('id', '?')
    name: str = f.get('name', '?')
    records = ', '.join(parse_json_field(f.get('records')))
    aggs = ', '.join(parse_json_field(f.get('aggregations')))
    freqs = ', '.join(parse_json_field(f.get('frequencies')))

    # Handle both JSONL event format and D1 format for date range
    dr = f.get('date_range')
    dr_min = f.get('date_range_min')
    dr_max = f.get('date_range_max')
    if dr and isinstance(dr, dict):
        date_str = f'{dr["min"][:7]} -> {dr["max"][:7]}'
    elif dr_min and dr_max:
        date_str = f'{str(dr_min)[:7]} -> {str(dr_max)[:7]}'
    else:
        date_str = '-'

    created_at = str(f.get('created_at', ''))[:16]  # "2026-03-17 23:47"
    parts = [f'  {file_id}', name, records, aggs, freqs, date_str]
    if created_at:
        parts.append(created_at)
    return '  '.join(parts)


# ---- Streaming callbacks (print as events arrive) ----


def on_files_event(event: SDKEvent, result: StreamResult) -> None:
    """Print files progress events as they arrive."""
    name = event['event']
    data = event['data']

    if name == 'FilesDiscovered':
        count = len(data.get('files', []))
        run_id = result.run_id or ''
        prefix = f'{run_id}: ' if run_id else ''
        print(f'{prefix}classifying {count} file{"s" if count != 1 else ""}', flush=True)

    elif name == 'FilesClassificationCompleted':
        files: list[dict[str, Any]] = data.get('files', [])
        for f in files:
            print(format_file_line(f), flush=True)

    elif name == 'FilesClassificationFailed':
        error: str = data.get('error', 'unknown error')
        print(f'error: classification failed — {error}', flush=True)


def on_forecast_event(event: SDKEvent, result: StreamResult) -> None:
    """Print forecast progress events as they arrive."""
    name = event['event']
    data = event['data']

    if name == 'FilesDiscovered':
        count = len(data.get('files', []))
        run_id = result.run_id or ''
        prefix = f'{run_id}: ' if run_id else ''
        print(f'{prefix}classifying {count} file{"s" if count != 1 else ""}', flush=True)

    elif name == 'FilesClassificationCompleted':
        files: list[dict[str, Any]] = data.get('files', [])
        print(f'classified {len(files)} file{"s" if len(files) != 1 else ""}', flush=True)

    elif name == 'SeriesExtractionStarted':
        print('extracting series', flush=True)

    elif name == 'ModelingStarted':
        series: list[dict[str, Any]] = data.get('series', [])
        print(f'training {len(series)} model{"s" if len(series) != 1 else ""}', flush=True)

    elif name == 'ForecastingStarted':
        series = data.get('series', [])
        print(f'forecasting {len(series)} series', flush=True)

    elif name == 'ForecastGenCompleted':
        series_name = data.get('series_name', data.get('series_id', '?'))
        print(f'  \u2713  {series_name}', flush=True)

    elif name == 'ForecastGenFailed' or name == 'TargetDataFailed':
        series_name = data.get('series_name', data.get('series_id', '?'))
        error = data.get('error', 'unknown error')
        print(f'  \u2717  {series_name}  {error}', flush=True)

    elif name == 'FilesClassificationFailed':
        error_msg: str = data.get('error', 'unknown error')
        print(f'error: classification failed — {error_msg}', flush=True)


# ---- Final result printers (after stream closes) ----


def print_files_result(result: StreamResult, elapsed: float) -> int:
    """Print final footer for files command. Returns exit code.

    Progress events are already printed by on_files_event during streaming.
    This only handles errors and the footer.
    """
    code = result.exit_code if result.exit_code is not None else 1

    if result.errors:
        for err in result.errors:
            print(f'error: {err}')
        print(f'[exit:{code} | {elapsed:.1f}s]')
        return code

    if code != 0 and not result.get_event('FilesClassificationFailed') and result.stderr.strip():
        print(f'error: {result.stderr.strip().splitlines()[-1]}')

    print(f'[exit:{code} | {elapsed:.1f}s]')
    return code


def format_series_line(s: dict[str, Any]) -> str:
    """Format a single series as a one-line summary."""
    series_id: str = s.get('id', '?')
    name: str = s.get('name', '?')
    aggregation: str = s.get('aggregation', '')

    # Identifiers: from SDK event (list of dicts) or D1 (JSON string)
    raw_identifiers = s.get('identifiers', [])
    if isinstance(raw_identifiers, str):
        import json

        try:
            raw_identifiers = json.loads(raw_identifiers)
        except (json.JSONDecodeError, TypeError):
            raw_identifiers = []

    if isinstance(raw_identifiers, list) and raw_identifiers:
        id_parts = []
        for ident in raw_identifiers:
            if isinstance(ident, dict):
                id_parts.append(f'{ident.get("type", "")}: {ident.get("value", "")}')
            else:
                id_parts.append(str(ident))
        id_str = ', '.join(id_parts)
    else:
        id_str = ''

    parts = [f'  {series_id}', name, aggregation]
    if id_str:
        parts.append(id_str)
    created_at = str(s.get('created_at', ''))[:16]
    if created_at:
        parts.append(created_at)
    return '  '.join(parts)


def on_series_event(event: SDKEvent, result: StreamResult) -> None:
    """Print series progress events as they arrive."""
    name = event['event']
    data = event['data']

    if name == 'FilesDiscovered':
        count = len(data.get('files', []))
        run_id = result.run_id or ''
        prefix = f'{run_id}: ' if run_id else ''
        print(f'{prefix}classifying {count} file{"s" if count != 1 else ""}', flush=True)

    elif name == 'FilesClassificationCompleted':
        files: list[dict[str, Any]] = data.get('files', [])
        print(f'classified {len(files)} file{"s" if len(files) != 1 else ""}', flush=True)

    elif name == 'SeriesExtractionStarted':
        limit = data.get('limit', '')
        suffix = f' (limit {limit})' if limit else ''
        print(f'extracting series{suffix}', flush=True)

    elif name == 'SeriesExtractionCompleted':
        series: list[dict[str, Any]] = data.get('series', [])
        for s in series:
            print(format_series_line(s), flush=True)

    elif name == 'SeriesExtractionFailed':
        error: str = data.get('error', 'unknown error')
        print(f'error: series extraction failed — {error}', flush=True)

    elif name == 'FilesClassificationFailed':
        error_msg: str = data.get('error', 'unknown error')
        print(f'error: classification failed — {error_msg}', flush=True)


def print_series_result(result: StreamResult, elapsed: float) -> int:
    """Print final footer for series command. Returns exit code."""
    code = result.exit_code if result.exit_code is not None else 1

    if result.errors:
        for err in result.errors:
            print(f'error: {err}')
        print(f'[exit:{code} | {elapsed:.1f}s]')
        return code

    if code != 0 and not result.get_event('SeriesExtractionFailed') and result.stderr.strip():
        print(f'error: {result.stderr.strip().splitlines()[-1]}')

    print(f'[exit:{code} | {elapsed:.1f}s]')
    return code


def format_model_line(m: dict[str, Any]) -> str:
    """Format a single model as a one-line summary."""
    model_id: str = m.get('id', '?')
    series_id: str = m.get('series_id', '?')
    series_name: str = m.get('series_name', '')
    series_str = f'{series_name} ({series_id})' if series_name else series_id
    target: str = m.get('target', '')
    interval: str = m.get('interval', '')
    horizon = m.get('horizon', '')
    created_at = str(m.get('created_at', ''))[:16]
    parts = [f'  {model_id}', series_str]
    if target:
        parts.append(target)
    if horizon and interval:
        parts.append(f'{horizon} {interval}s')
    if created_at:
        parts.append(created_at)
    return '  '.join(parts)


def on_models_event(event: SDKEvent, result: StreamResult) -> None:
    """Print model training progress events as they arrive."""
    name = event['event']
    data = event['data']

    if name == 'FilesDiscovered':
        count = len(data.get('files', []))
        run_id = result.run_id or ''
        prefix = f'{run_id}: ' if run_id else ''
        print(f'{prefix}classifying {count} file{"s" if count != 1 else ""}', flush=True)

    elif name == 'FilesClassificationCompleted':
        files: list[dict[str, Any]] = data.get('files', [])
        print(f'classified {len(files)} file{"s" if len(files) != 1 else ""}', flush=True)

    elif name == 'SeriesExtractionStarted':
        print('extracting series', flush=True)

    elif name == 'SeriesExtractionCompleted':
        series: list[dict[str, Any]] = data.get('series', [])
        print(f'extracted {len(series)} series', flush=True)

    elif name == 'ModelingStarted':
        series = data.get('series', [])
        print(f'training {len(series)} model{"s" if len(series) != 1 else ""}', flush=True)

    elif name == 'DataPrepCompleted':
        series_name = data.get('series_name', data.get('series_id', '?'))
        print(f'  \u2713 data prep: {series_name}', flush=True)

    elif name == 'DataPrepFailed':
        series_name = data.get('series_name', data.get('series_id', '?'))
        error = data.get('error', 'unknown error')
        print(f'  \u2717 data prep: {series_name}  {error}', flush=True)

    elif name == 'ModelTrainCompleted':
        series_name = data.get('series_name', data.get('series_id', '?'))
        print(f'  \u2713 trained: {series_name}', flush=True)

    elif name == 'ModelTrainFailed':
        series_name = data.get('series_name', data.get('series_id', '?'))
        error = data.get('error', 'unknown error')
        print(f'  \u2717 training: {series_name}  {error}', flush=True)

    elif name == 'FilesClassificationFailed':
        error_msg: str = data.get('error', 'unknown error')
        print(f'error: classification failed — {error_msg}', flush=True)


def print_models_result(result: StreamResult, elapsed: float) -> int:
    """Print final result for models command. Returns exit code.

    Progress and per-series events are already printed by on_models_event.
    This prints the summary table from ModelingCompleted and the footer.
    """
    code = result.exit_code if result.exit_code is not None else 1

    if result.errors:
        for err in result.errors:
            print(f'error: {err}')
        print(f'[exit:{code} | {elapsed:.1f}s]')
        return code

    completed = result.get_event('ModelingCompleted')
    if completed is not None:
        models_data: list[dict[str, Any]] = completed['data'].get('models', [])
        series_data: list[dict[str, Any]] = completed['data'].get('series', [])
        series_names = {s.get('id', ''): s.get('name', '') for s in series_data}

        for m in models_data:
            model_id: str = m.get('id', '?')
            series_id: str = m.get('series_id', '?')
            name = series_names.get(series_id, series_id)
            status: str = m.get('status', 'ready')
            print(f'  {model_id}  {name}  {series_id}  {status}')
    elif code != 0:
        if result.stderr.strip():
            print(f'error: {result.stderr.strip().splitlines()[-1]}')

    print(f'[exit:{code} | {elapsed:.1f}s]')
    return code


def _format_forecast_line(forecast: dict[str, Any], series_names: dict[str, str]) -> str:
    """Format a single forecast as a one-line summary."""
    fct_id: str = forecast.get('id', '?')
    series_id: str = forecast.get('series_id', '?')
    name = series_names.get(series_id, series_id)
    items: list[dict[str, Any]] = forecast.get('items', [])
    n_periods = len(items)

    if items:
        first_date = str(items[0].get('date', ''))[:7]
        last_date = str(items[-1].get('date', ''))[:7]
        date_str = f'{first_date} -> {last_date}'
    else:
        date_str = '-'

    return f'  {fct_id}  {name}  {n_periods} periods  {date_str}'


def format_forecast_line(f: dict[str, Any]) -> str:
    """Format a forecast from D1 as a one-line summary."""
    import json

    fct_id: str = f.get('id', '?')
    series_id: str = f.get('series_id', '?')
    series_name: str = f.get('series_name', '')
    series_str = f'{series_name} ({series_id})' if series_name else series_id
    interval: str = f.get('interval', '')
    horizon = f.get('horizon', '')

    raw_items = f.get('items', '[]')
    if isinstance(raw_items, str):
        try:
            items = json.loads(raw_items)
        except (json.JSONDecodeError, TypeError):
            items = []
    else:
        items = raw_items

    if items:
        first_date = str(items[0].get('date', ''))[:7]
        last_date = str(items[-1].get('date', ''))[:7]
        date_str = f'{first_date} -> {last_date}'
    else:
        date_str = '-'

    created_at = str(f.get('created_at', ''))[:16]
    parts = [f'  {fct_id}', series_str]
    if horizon and interval:
        parts.append(f'{horizon} {interval}s')
    parts.append(date_str)
    if created_at:
        parts.append(created_at)
    return '  '.join(parts)


def print_forecast_result(result: StreamResult, elapsed: float) -> int:
    """Print final result for forecast command. Returns exit code.

    Progress and per-series events are already printed by on_forecast_event.
    This prints the summary table from ForecastingCompleted and the footer.
    """
    code = result.exit_code if result.exit_code is not None else 1

    if result.errors:
        for err in result.errors:
            print(f'error: {err}')
        print(f'[exit:{code} | {elapsed:.1f}s]')
        return code

    completed = result.get_event('ForecastingCompleted')
    if completed is not None:
        forecasts_data: list[dict[str, Any]] = completed['data'].get('forecasts', [])
        series_data: list[dict[str, Any]] = completed['data'].get('series', [])
        series_names = {s.get('id', ''): s.get('name', '') for s in series_data}

        for f in forecasts_data:
            print(_format_forecast_line(f, series_names))
    elif code != 0:
        if result.stderr.strip():
            print(f'error: {result.stderr.strip().splitlines()[-1]}')

    print(f'[exit:{code} | {elapsed:.1f}s]')
    return code
