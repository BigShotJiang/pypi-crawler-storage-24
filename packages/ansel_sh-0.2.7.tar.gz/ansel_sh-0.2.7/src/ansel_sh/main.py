"""ansel CLI — demand forecasting for AI agents."""

from __future__ import annotations

import sys

from .commands import files as files_cmd
from .commands import forecast as forecast_cmd
from .commands import models as models_cmd
from .commands import series as series_cmd

COMMANDS = {
    'files': files_cmd.run,
    'series': series_cmd.run,
    'models': models_cmd.run,
    'forecast': forecast_cmd.run,
}


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] in ('-h', '--help', 'help'):
        print('Usage: ansel <command> [args]')
        print()
        print('Commands:')
        print('  files <path>        Upload and classify CSV data files')
        print('  files list          List all classified files')
        print('  series <path>       Extract forecastable series from CSV files')
        print('  series <fil_id>     Extract series from pre-uploaded files')
        print('  series list         List previously extracted series')
        print('  models <path>       Train forecasting models from CSV files')
        print('  models <fil_id>     Train models from pre-uploaded files')
        print('  models list         List previously trained models')
        print('  forecast <path>     Generate demand forecasts from CSV files')
        print('  forecast <fil_id>   Generate forecasts from pre-uploaded files')
        print('  forecast get <id>   Get forecast details and items')
        print('  forecast list       List previously generated forecasts')
        sys.exit(0)

    if args[0] in ('-v', '--version'):
        print('ansel 0.2.7')
        sys.exit(0)

    command = args[0]
    handler = COMMANDS.get(command)

    if handler is None:
        print(f"error: unknown command '{command}'", file=sys.stderr)
        print("Run 'ansel --help' for usage.", file=sys.stderr)
        sys.exit(1)

    sys.exit(handler(args[1:]))
