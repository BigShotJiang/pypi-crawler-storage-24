# ansel

Inventory forecasting CLI for agents.

```bash
pip install ansel-sh
# list commands
ansel --help
```
