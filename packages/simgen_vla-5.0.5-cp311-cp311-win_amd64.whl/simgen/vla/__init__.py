"""
SimGen VLA - High-Precision GPU Arithmetic
===========================================

Drop-in PyTorch replacement with exact arithmetic.
"""

__version__ = "5.0.5"

# Core exports - all torch-compatible API
from .vla import (
    # Core class
    Tensor,

    # Creation functions
    tensor,
    zeros,
    ones,
    randn,
    rand,
    arange,
    linspace,
    eye,

    # Reductions
    sum,
    mean,
    prod,
    min,
    max,
    std,
    var,

    # Linear algebra
    matmul,
    mm,
    mv,
    dot,
    bmm,

    # Math functions
    exp,
    log,
    sqrt,
    abs,
    sin,
    cos,
    tan,
    tanh,
    sigmoid,

    # Shape functions
    reshape,
    transpose,
    squeeze,
    unsqueeze,
    stack,
    cat,

    # Device/dtype
    float32,
    float64,
    device,
    cuda,
    cpu,
)

__all__ = [
    '__version__',
    'Tensor',
    'tensor',
    'zeros',
    'ones',
    'randn',
    'rand',
    'arange',
    'linspace',
    'eye',
    'sum',
    'mean',
    'prod',
    'min',
    'max',
    'std',
    'var',
    'matmul',
    'mm',
    'mv',
    'dot',
    'bmm',
    'exp',
    'log',
    'sqrt',
    'abs',
    'sin',
    'cos',
    'tan',
    'tanh',
    'sigmoid',
    'reshape',
    'transpose',
    'squeeze',
    'unsqueeze',
    'stack',
    'cat',
    'float32',
    'float64',
    'device',
    'cuda',
    'cpu',
]
