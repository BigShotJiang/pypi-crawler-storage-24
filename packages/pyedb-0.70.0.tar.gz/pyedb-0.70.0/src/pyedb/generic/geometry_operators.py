# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

# -*- coding: utf-8 -*-
from collections import defaultdict
import math
import re
import sys
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pyedb.dotnet.database.Variables import VariableManager as DotNetVariableManager
    from pyedb.grpc.database.variables import Variable as CoreVariableManager

import numpy as np

from pyedb.generic.constants import SWEEPDRAFT, scale_units


class GeometryOperators(object):
    """Manages geometry operators."""

    @staticmethod
    def List2list(input_list) -> list:  # pragma: no cover
        """Convert a C# list object to a Python list.

        This function performs a deep conversion.

        Parameters
        ----------
        input_list : list
            C# list to convert to a Python list.

        Returns
        -------
        list
            Converted Python list.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> csharp_list = [1, 2, [3, 4]]
        >>> go.List2list(csharp_list)
        [1, 2, [3, 4]]

        """
        output_list = []
        for i in input_list:
            if "List" in str(type(i)):
                output_list.append(GeometryOperators.List2list(list(i)))
            else:
                output_list.append(i)
        return output_list

    @staticmethod
    def parse_dim_arg(
        string: str | float, scale_to_unit: str | None = None, variable_manager: "VariableManager" = None
    ) -> float | str | None:  # pragma: no cover
        """Convert a number and unit to a float.

        Angles are converted in radians.

        Parameters
        ----------
        string : str or float
            String to convert. For example, ``"2mm"``.
        scale_to_unit : str or None, optional
            Units for the value to convert.
        variable_manager : VariableManager, optional
            Try to parse formula and returns numeric value.

        Returns
        -------
        float, str, or None
            Value for the converted value and units.

        Examples
        --------
        Parse ``"2mm"``.

        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> go.parse_dim_arg("2mm")
        0.002

        Use the optional argument ``scale_to_unit`` to specify the destination unit.

        >>> go.parse_dim_arg("2mm", scale_to_unit="mm")
        2.0

        """
        if type(string) is not str:
            try:
                return float(string)
            except ValueError:  # pragma: no cover
                raise TypeError("Input argument is not string nor number")
        sunit = 1.0
        if scale_to_unit:
            sunit = scale_units(scale_to_unit)

        pattern = r"(?P<number>[-+]?(\d+(\.\d*)?|\.\d+)([eE][-+]?\d+)?)\s*(?P<unit>[a-z_A-Z]*)"
        m = re.search(pattern, string)
        if m:
            if m.group(0) != string:
                if variable_manager:
                    variable_manager["temp_var"] = string
                    value = variable_manager["temp_var"].numeric_value
                    del variable_manager["temp_var"]
                    return value
                else:
                    return string
            elif not m.group("unit"):
                return float(m.group("number"))
            else:
                scaling_factor = scale_units(m.group("unit"))
                return float(m.group("number")) * scaling_factor / sunit
        else:
            if variable_manager:
                if not variable_manager.set_variable("temp_var", string):
                    if not variable_manager.set_variable("temp_var", string, postprocessing=True):
                        return string
                value = variable_manager["temp_var"].value / sunit
                del variable_manager["temp_var"]
                return value

    @staticmethod
    def draft_type_str(val: int) -> str:  # pragma: no cover
        """Retrieve the draft type.

        Parameters
        ----------
        val : int
            ``SWEEPDRAFT`` enum value.

        Returns
        -------
        str
            Type of the draft.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> from pyedb.generic.constants import SWEEPDRAFT
        >>> go.draft_type_str(SWEEPDRAFT.Extended)
        'Extended'

        """
        if val == SWEEPDRAFT.Extended:
            return "Extended"
        elif val == SWEEPDRAFT.Round:
            return "Round"
        else:
            return "Natural"

    @staticmethod
    def get_mid_point(v1: list[float], v2: list[float]) -> list[float]:
        """Evaluate the midpoint between two points.

        Parameters
        ----------
        v1 : list[float]
            List of ``[x, y, z]`` coordinates for the first point.
        v2 : list[float]
            List of ``[x, y, z]`` coordinates for the second point.

        Returns
        -------
        list[float]
            List of ``[x, y, z]`` coordinates for the midpoint.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> p1 = [0.0, 0.0, 0.0]
        >>> p2 = [2.0, 4.0, 6.0]
        >>> go.get_mid_point(p1, p2)
        [1.0, 2.0, 3.0]

        """
        m = [((i + j) / 2.0) for i, j in zip(v1, v2)]
        return m

    @staticmethod
    def get_triangle_area(v1: list[float], v2: list[float], v3: list[float]) -> float:  # pragma: no cover
        """Evaluate the area of a triangle defined by its three vertices.

        Parameters
        ----------
        v1 : list[float]
            List of ``[x, y, z]`` coordinates for the first vertex.
        v2 : list[float]
            List of ``[x, y, z]`` coordinates for the second vertex.
        v3 : list[float]
            List of ``[x, y, z]`` coordinates for the third vertex.

        Returns
        -------
        float
            Area of the triangle.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> v1 = [0.0, 0.0, 0.0]
        >>> v2 = [1.0, 0.0, 0.0]
        >>> v3 = [0.0, 1.0, 0.0]
        >>> go.get_triangle_area(v1, v2, v3)
        0.5

        """
        a = ((v1[0] - v2[0]) ** 2 + (v1[1] - v2[1]) ** 2 + (v1[2] - v2[2]) ** 2) ** 0.5
        b = ((v2[0] - v3[0]) ** 2 + (v2[1] - v3[1]) ** 2 + (v2[2] - v3[2]) ** 2) ** 0.5
        c = ((v3[0] - v1[0]) ** 2 + (v3[1] - v1[1]) ** 2 + (v3[2] - v1[2]) ** 2) ** 0.5
        s = 0.5 * (a + b + c)
        area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
        if isinstance(area, complex):
            area = area.real
        return area

    @staticmethod
    def v_cross(a: list[float], b: list[float]) -> list[float]:  # pragma: no cover
        """Evaluate the cross product of two geometry vectors.

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.

        Returns
        -------
        list[float]
            List of ``[x, y, z]`` coordinates for the result vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [1.0, 0.0, 0.0]
        >>> b = [0.0, 1.0, 0.0]
        >>> go.v_cross(a, b)
        [0.0, 0.0, 1.0]

        """
        c = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
        return c

    @staticmethod
    def _v_dot(a: list[float], b: list[float]) -> float | bool:  # pragma: no cover
        """Evaluate the dot product between two geometry vectors.

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.

        Returns
        -------
        float, or bool
            Result of the dot product.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [1.0, 2.0, 3.0]
        >>> b = [4.0, 5.0, 6.0]
        >>> go._v_dot(a, b)
        32.0

        """
        if len(a) == 3:
            c = a[0] * b[0] + a[1] * b[1] + a[2] * b[2]
            return c
        elif len(a) == 2:
            c = a[0] * b[0] + a[1] * b[1]
            return c
        return False

    @staticmethod
    def v_dot(a: list[float], b: list[float]) -> float | bool:  # pragma: no cover
        """Evaluate the dot product between two geometry vectors.

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.

        Returns
        -------
        float, or bool
            Result of the dot product.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [1.0, 2.0, 3.0]
        >>> b = [4.0, 5.0, 6.0]
        >>> go.v_dot(a, b)
        32.0

        """
        return GeometryOperators._v_dot(a, b)

    @staticmethod
    def v_prod(s: float, v: list[float]) -> list[float]:  # pragma: no cover
        """Evaluate the product between a scalar value and a vector.

        Parameters
        ----------
        s : float
            Scalar value.
        v : list[float]
            List of values for the vector in the format ``[v1, v2,..., vn]``.
            The vector can be any length.

        Returns
        -------
        list[float]
            List of values for the result vector. This list is the
            same length as the list for the input vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> v = [1.0, 2.0, 3.0]
        >>> go.v_prod(2.0, v)
        [2.0, 4.0, 6.0]

        """
        r = [s * i for i in v]
        return r

    @staticmethod
    def v_rotate_about_axis(
        vector: list[float], angle: float, radians: bool = False, axis: str = "z"
    ) -> tuple[float, float, float]:  # pragma: no cover
        """Evaluate rotation of a vector around an axis.

        Parameters
        ----------
        vector : list[float]
            List of the three component of the vector.
        angle : float
            Angle by which the vector is to be rotated (radians or degree).
        radians : bool, optional
            Whether the angle is expressed in radians. The default is ``False``.
        axis : str, optional
            Axis about which to rotate the vector. The default is ``"z"``.

        Returns
        -------
        tuple[float, float, float]
            List of values for the result vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> import math
        >>> v = [1.0, 0.0, 0.0]
        >>> go.v_rotate_about_axis(v, 90.0, axis="z")
        (6.123233995736766e-17, 1.0, 0.0)
        """
        if not radians:
            angle = math.radians(angle)
        x, y, z = vector
        axis = axis.lower()
        if axis == "z":
            rotated_x = x * math.cos(angle) - y * math.sin(angle)
            rotated_y = x * math.sin(angle) + y * math.cos(angle)
            rotated_z = z
        elif axis == "y":
            rotated_x = x * math.cos(angle) + z * math.sin(angle)
            rotated_y = y
            rotated_z = -x * math.sin(angle) + z * math.cos(angle)
        elif axis == "x":
            rotated_x = x
            rotated_y = y * math.cos(angle) - z * math.sin(angle)
            rotated_z = y * math.sin(angle) + z * math.cos(angle)
        else:  # pragma: no cover
            raise ValueError("Invalid axis. Choose 'x', 'y', or 'z'.")
        return rotated_x, rotated_y, rotated_z

    @staticmethod
    def v_sub(a: list[float], b: list[float]) -> list[float]:  # pragma: no cover
        """Evaluate two geometry vectors by subtracting them (a-b).

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.

        Returns
        -------
        list[float]
            List of ``[x, y, z]`` coordinates for the result vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [5.0, 7.0, 9.0]
        >>> b = [1.0, 2.0, 3.0]
        >>> go.v_sub(a, b)
        [4.0, 5.0, 6.0]

        """
        c = [i - j for i, j in zip(a, b)]
        return c

    @staticmethod
    def v_sum(a: list[float], b: list[float]) -> list[float]:  # pragma: no cover
        """Evaluate two geometry vectors by adding them (a+b).

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.

        Returns
        -------
        list[float]
            List of ``[x, y, z]`` coordinates for the result vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [1.0, 2.0, 3.0]
        >>> b = [4.0, 5.0, 6.0]
        >>> go.v_sum(a, b)
        [5.0, 7.0, 9.0]

        """
        c = [i + j for i, j in zip(a, b)]
        return c

    @staticmethod
    def v_norm(a: list[float]) -> float:  # pragma: no cover
        """Evaluate the Euclidean norm of a geometry vector.

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the vector.

        Returns
        -------
        float
            Evaluated norm in the same unit as the coordinates for the input vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [3.0, 4.0, 0.0]
        >>> go.v_norm(a)
        5.0

        """
        t = 0
        for i in a:
            t += i**2
        m = t**0.5
        return m

    @staticmethod
    def normalize_vector(v: list[float]) -> list[float]:  # pragma: no cover
        """Normalize a geometry vector.

        Parameters
        ----------
        v : list[float]
            List of ``[x, y, z]`` coordinates for vector.

        Returns
        -------
        list[float]
            List of ``[x, y, z]`` coordinates for the normalized vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> v = [3.0, 4.0, 0.0]
        >>> go.normalize_vector(v)
        [0.6, 0.8, 0.0]

        """
        # normalize a vector to its norm
        norm = GeometryOperators.v_norm(v)
        vn = [i / norm for i in v]
        return vn

    @staticmethod
    def v_points(p1: list[float], p2: list[float]) -> list[float]:  # pragma: no cover
        """Vector from one point to another point.

        Parameters
        ----------
        p1 : list[float]
            Coordinates ``[x1,y1,z1]`` for the first point.
        p2 : list[float]
            Coordinates ``[x2,y2,z2]`` for second point.

        Returns
        -------
        list[float]
            Coordinates ``[vx, vy, vz]`` for the vector from the first point to the second point.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> p1 = [1.0, 2.0, 3.0]
        >>> p2 = [4.0, 6.0, 8.0]
        >>> go.v_points(p1, p2)
        [3.0, 4.0, 5.0]

        """
        return GeometryOperators.v_sub(p2, p1)

    @staticmethod
    def points_distance(p1: list[float], p2: list[float]) -> float | bool:  # pragma: no cover
        """Evaluate the distance between two points expressed as their Cartesian coordinates.

        Parameters
        ----------
        p1 : list[float]
            List of ``[x1,y1,z1]`` coordinates for the first point.
        p2 : list[float]
            List of ``[x2,y2,z2]`` coordinates for the second point.

        Returns
        -------
        float, or bool
            Distance between the two points in the same unit as the coordinates for the points.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> p1 = [0.0, 0.0, 0.0]
        >>> p2 = [3.0, 4.0, 0.0]
        >>> go.points_distance(p1, p2)
        5.0

        """
        # fmt: off
        if len(p1) == 3:
            return math.sqrt((p2[0]-p1[0])**2 + (p2[1]-p1[1])**2 + (p2[2]-p1[2])**2)
        elif len(p1) == 2:
            return math.sqrt((p2[0]-p1[0])**2 + (p2[1]-p1[1])**2)
        return False
        # fmt: on

    @staticmethod
    def find_point_on_plane(pointlists: list[list[float]], direction: int = 0) -> float:  # pragma: no cover
        """Find a point on a plane.

        Parameters
        ----------
        pointlists : list[list[float]]
            List of points.
        direction : int, optional
            Direction parameter. The default is ``0``.

        Returns
        -------
        float
            Point on plane.

        """
        if direction <= 2:
            point = 1e6
            for p in pointlists:
                if p[direction] < point:
                    point = p[direction]
        else:
            point = -1e6
            for p in pointlists:
                if p[direction - 3] > point:
                    point = p[direction - 3]
        return point

    @staticmethod
    def distance_vector(p: list[float], a: list[float], b: list[float]) -> list[float]:  # pragma: no cover
        """Evaluate the vector distance between point ``p`` and a line defined by two points, ``a`` and ``b``.

        The formula is  ``d = (a-p)-((a-p)dot p)n``, where ``a`` is a point of the line (either ``a`` or ``b``)
        and ``n`` is the unit vector in the direction of the line.

        Parameters
        ----------
        p : list[float]
            List of ``[x, y, z]`` coordinates for the reference point.
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the segment.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the segment.

        Returns
        -------
        list[float]
            List of ``[x, y, z]`` coordinates for the distance vector.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> p = [0.0, 1.0, 0.0]
        >>> a = [0.0, 0.0, 0.0]
        >>> b = [1.0, 0.0, 0.0]
        >>> go.distance_vector(p, a, b)
        [0.0, 1.0, 0.0]

        """
        v1 = GeometryOperators.v_points(a, b)
        n = [i / GeometryOperators.v_norm(v1) for i in v1]
        v2 = GeometryOperators.v_sub(a, p)
        s1 = GeometryOperators._v_dot(v2, n)
        v3 = [i * s1 for i in n]
        vd = GeometryOperators.v_sub(v2, v3)
        return vd

    @staticmethod
    def is_between_points(
        p: list[float], a: list[float], b: list[float], tol: float = 1e-6
    ) -> bool:  # pragma: no cover
        """Check if a point lies on the segment defined by two points.

        Parameters
        ----------
        p : list[float]
            List of ``[x, y, z]`` coordinates for the reference point ``p``.
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the segment.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the segment.
        tol : float, optional
            Linear tolerance.  The default is ``1e-6``.

        Returns
        -------
        bool
            ``True`` when the point lies on the segment defined by the two points, ``False`` otherwise.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> p = [0.5, 0.5, 0.0]
        >>> a = [0.0, 0.0, 0.0]
        >>> b = [1.0, 1.0, 0.0]
        >>> go.is_between_points(p, a, b)
        True

        """
        v1 = GeometryOperators.v_points(a, b)
        v2 = GeometryOperators.v_points(a, p)
        if abs(GeometryOperators.v_norm(GeometryOperators.v_cross(v1, v2))) > tol:
            return False  # not collinear
        t1 = GeometryOperators._v_dot(v1, v2)
        t2 = GeometryOperators._v_dot(v1, v1)
        if t1 < 0 or t1 > t2:
            return False
        else:
            return True

    @staticmethod
    def is_parallel(
        a1: list[float], a2: list[float], b1: list[float], b2: list[float], tol: float = 1e-6
    ) -> bool:  # pragma: no cover
        """Check if a segment defined by two points is parallel to a segment defined by two other points.

        Parameters
        ----------
        a1 : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the first segment.
        a2 : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the first segment.
        b1 : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the second segment.
        b2 : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the second segment.
        tol : float, optional
            Linear tolerance. The default is ``1e-6``.

        Returns
        -------
        bool
            ``True`` when successful, ``False`` when failed.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a1 = [0.0, 0.0, 0.0]
        >>> a2 = [1.0, 0.0, 0.0]
        >>> b1 = [0.0, 1.0, 0.0]
        >>> b2 = [1.0, 1.0, 0.0]
        >>> go.is_parallel(a1, a2, b1, b2)
        True

        """
        if 1.0 - GeometryOperators.parallel_coeff(a1, a2, b1, b2) < tol * tol:
            return True
        else:
            return False

    @staticmethod
    def parallel_coeff(a1: list[float], a2: list[float], b1: list[float], b2: list[float]) -> float:  # pragma: no cover
        """Evaluate the parallelism coefficient between two segments.

        Parameters
        ----------
        a1 : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the first segment.
        a2 : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the first segment.
        b1 : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the second segment.
        b2 : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the second segment.

        Returns
        -------
        float
            Dot product of 4 vertices of 2 segments.

        """
        va = GeometryOperators.v_points(a1, a2)
        vb = GeometryOperators.v_points(b1, b2)
        an = GeometryOperators.v_norm(va)
        bn = GeometryOperators.v_norm(vb)
        var = GeometryOperators._v_dot(va, vb) / (an * bn)
        return abs(var)

    @staticmethod
    def is_collinear(a: list[float], b: list[float], tol: float = 1e-6) -> bool:  # pragma: no cover
        """Check if two vectors are collinear (parallel or anti-parallel).

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.
        tol : float, optional
            Linear tolerance. The default is ``1e-6``.

        Returns
        -------
        bool
            ``True`` if vectors are collinear, ``False`` otherwise.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [1.0, 0.0, 0.0]
        >>> b = [2.0, 0.0, 0.0]
        >>> go.is_collinear(a, b)
        True

        """
        an = GeometryOperators.v_norm(a)
        bn = GeometryOperators.v_norm(b)
        var = GeometryOperators._v_dot(a, b) / (an * bn)
        if 1.0 - abs(var) < tol * tol:
            return True
        else:
            return False

    @staticmethod
    def is_projection_inside(
        a1: list[float], a2: list[float], b1: list[float], b2: list[float]
    ) -> bool:  # pragma: no cover
        """Project a segment onto another segment and check if the projected segment is inside it.

        Parameters
        ----------
        a1 : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the projected segment.
        a2 : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the projected segment.
        b1 : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the other segment.
        b2 : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the other segment.

        Returns
        -------
        bool
            ``True`` when the projected segment is inside the other segment, ``False`` otherwise.

        """
        if not GeometryOperators.is_parallel(a1, a2, b1, b2):
            return False
        d = GeometryOperators.distance_vector(a1, b1, b2)
        a1n = GeometryOperators.v_sum(a1, d)
        a2n = GeometryOperators.v_sum(a2, d)
        if not GeometryOperators.is_between_points(a1n, b1, b2):
            return False
        if not GeometryOperators.is_between_points(a2n, b1, b2):
            return False
        return True

    @staticmethod
    def arrays_positions_sum(vertlist1: list[list[float]], vertlist2: list[list[float]]) -> float:  # pragma: no cover
        """Return the sum of two vertices lists.

        Parameters
        ----------
        vertlist1 : list[list[float]]
            First list of vertices.
        vertlist2 : list[list[float]]
            Second list of vertices.

        Returns
        -------
        float
            Average distance between all vertex pairs.

        """
        s = 0
        for el in vertlist1:
            for el1 in vertlist2:
                s += GeometryOperators.points_distance(el, el1)
        return s / (len(vertlist1) + len(vertlist2))

    @staticmethod
    def v_angle(a: list[float], b: list[float]) -> float:  # pragma: no cover
        """Evaluate the angle between two geometry vectors.

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.

        Returns
        -------
        float
            Angle in radians.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> import math
        >>> a = [1.0, 0.0, 0.0]
        >>> b = [0.0, 1.0, 0.0]
        >>> angle = go.v_angle(a, b)
        >>> math.degrees(angle)
        90.0

        """
        d = GeometryOperators.v_dot(a, b)
        an = GeometryOperators.v_norm(a)
        bn = GeometryOperators.v_norm(b)
        if (an * bn) == 0.0:
            return 0.0
        else:
            return math.acos(d / (an * bn))

    @staticmethod
    def pointing_to_axis(
        x_pointing: list[float], y_pointing: list[float]
    ) -> tuple[list[float], list[float], list[float]]:  # pragma: no cover
        """Retrieve the axes from the HFSS X axis and Y pointing axis.

        This is as per the definition of the AEDT interface coordinate system.

        Parameters
        ----------
        x_pointing : list[float]
            List of ``[x, y, z]`` coordinates for the X axis.
        y_pointing : list[float]
            List of ``[x, y, z]`` coordinates for the Y pointing axis.

        Returns
        -------
        tuple[list[float], list[float], list[float]]
            ``[Xx, Xy, Xz], [Yx, Yy, Yz], [Zx, Zy, Zz]`` of the three axes (normalized).

        """
        zpt = GeometryOperators.v_cross(x_pointing, y_pointing)
        ypt = GeometryOperators.v_cross(zpt, x_pointing)

        xp = GeometryOperators.normalize_vector(x_pointing)
        zp = GeometryOperators.normalize_vector(zpt)
        yp = GeometryOperators.normalize_vector(ypt)

        return xp, yp, zp

    @staticmethod
    def axis_to_euler_zxz(
        x: list[float], y: list[float], z: list[float]
    ) -> tuple[float, float, float]:  # pragma: no cover
        """Retrieve Euler angles of a frame following the rotation sequence ZXZ.

        Provides assumption for the gimbal lock problem.

        Parameters
        ----------
        x : list[float]
            List of ``[Xx, Xy, Xz]`` coordinates for the X axis.
        y : list[float]
            List of ``[Yx, Yy, Yz]`` coordinates for the Y axis.
        z : list[float]
            List of ``[Zx, Zy, Zz]`` coordinates for the Z axis.

        Returns
        -------
        tuple[float, float, float]
            (phi, theta, psi) containing the Euler angles in radians.

        """
        tol = 1e-16
        x1 = x[0]
        x2 = x[1]
        x3 = x[2]
        y3 = y[2]
        z1 = z[0]
        z2 = z[1]
        z3 = z[2]
        if GeometryOperators.v_norm(GeometryOperators.v_sub(z, [0, 0, 1])) < tol:
            phi = GeometryOperators.atan2(x2, x1)
            theta = 0.0
            psi = 0.0
        elif GeometryOperators.v_norm(GeometryOperators.v_sub(z, [0, 0, -1])) < tol:
            phi = GeometryOperators.atan2(x2, x1)
            theta = math.pi
            psi = 0.0
        else:
            phi = GeometryOperators.atan2(z1, -z2)
            theta = math.acos(z3)
            psi = GeometryOperators.atan2(x3, y3)
        return phi, theta, psi

    @staticmethod
    def axis_to_euler_zyz(
        x: list[float], y: list[float], z: list[float]
    ) -> tuple[float, float, float]:  # pragma: no cover
        """Retrieve Euler angles of a frame following the rotation sequence ZYZ.

        Provides assumption for the gimbal lock problem.

        Parameters
        ----------
        x : list[float]
            List of ``[Xx, Xy, Xz]`` coordinates for the X axis.
        y : list[float]
            List of ``[Yx, Yy, Yz]`` coordinates for the Y axis.
        z : list[float]
            List of ``[Zx, Zy, Zz]`` coordinates for the Z axis.

        Returns
        -------
        tuple[float, float, float]
            (phi, theta, psi) containing the Euler angles in radians.

        """
        tol = 1e-16
        x1 = x[0]
        x2 = x[1]
        x3 = x[2]
        y3 = y[2]
        z1 = z[0]
        z2 = z[1]
        z3 = z[2]
        if GeometryOperators.v_norm(GeometryOperators.v_sub(z, [0, 0, 1])) < tol:
            phi = GeometryOperators.atan2(-x1, x2)
            theta = 0.0
            psi = math.pi / 2
        elif GeometryOperators.v_norm(GeometryOperators.v_sub(z, [0, 0, -1])) < tol:
            phi = GeometryOperators.atan2(-x1, x2)
            theta = math.pi
            psi = math.pi / 2
        else:
            phi = GeometryOperators.atan2(z2, z1)
            theta = math.acos(z3)
            psi = GeometryOperators.atan2(y3, -x3)
        return phi, theta, psi

    @staticmethod
    def quaternion_to_axis(q: list[float]) -> tuple[list[float], list[float], list[float]]:  # pragma: no cover
        """Convert a quaternion to a rotated frame defined by X, Y, and Z axes.

        Parameters
        ----------
        q : list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        Returns
        -------
        tuple[list[float], list[float], list[float]]
            [Xx, Xy, Xz], [Yx, Yy, Yz], [Zx, Zy, Zz] of the three axes (normalized).

        """
        q1 = q[0]
        q2 = q[1]
        q3 = q[2]
        q4 = q[3]

        m11 = q1 * q1 + q2 * q2 - q3 * q3 - q4 * q4
        m12 = 2.0 * (q2 * q3 - q1 * q4)
        m13 = 2.0 * (q2 * q4 + q1 * q3)

        m21 = 2.0 * (q2 * q3 + q1 * q4)
        m22 = q1 * q1 - q2 * q2 + q3 * q3 - q4 * q4
        m23 = 2.0 * (q3 * q4 - q1 * q2)

        m31 = 2.0 * (q2 * q4 - q1 * q3)
        m32 = 2.0 * (q3 * q4 + q1 * q2)
        m33 = q1 * q1 - q2 * q2 - q3 * q3 + q4 * q4

        x = GeometryOperators.normalize_vector([m11, m21, m31])
        y = GeometryOperators.normalize_vector([m12, m22, m32])
        z = GeometryOperators.normalize_vector([m13, m23, m33])

        return x, y, z

    @staticmethod
    def quaternion_to_axis_angle(q: list[float]) -> tuple[list[float], float]:  # pragma: no cover
        """Convert a quaternion to the axis angle rotation formulation.

        Parameters
        ----------
        q : list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        Returns
        -------
        tuple[list[float], float]
            ([ux, uy, uz], theta) containing the rotation axes expressed as X, Y, Z components of
            the unit vector ``u`` and the rotation angle theta expressed in radians.

        """
        q1 = q[0]
        q2 = q[1]
        q3 = q[2]
        q4 = q[3]
        n = (q2 * q2 + q3 * q3 + q4 * q4) ** 0.5
        u = [q2 / n, q3 / n, q4 / n]
        theta = 2.0 * GeometryOperators.atan2(n, q1)
        return u, theta

    @staticmethod
    def axis_angle_to_quaternion(u: list[float], theta: float) -> list[float]:  # pragma: no cover
        """Convert the axis angle rotation formulation to a quaternion.

        Parameters
        ----------
        u : list[float]
            List of ``[ux, uy, uz]`` coordinates for the rotation axis.
        theta : float
            Angle of rotation in radians.

        Returns
        -------
        list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        """
        un = GeometryOperators.normalize_vector(u)
        s = math.sin(theta * 0.5)
        q1 = math.cos(theta * 0.5)
        q2 = un[0] * s
        q3 = un[1] * s
        q4 = un[2] * s
        return [q1, q2, q3, q4]

    @staticmethod
    def quaternion_to_euler_zxz(q: list[float]) -> tuple[float, float, float]:  # pragma: no cover
        """Convert a quaternion to Euler angles following rotation sequence ZXZ.

        Parameters
        ----------
        q : list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        Returns
        -------
        tuple[float, float, float]
            (phi, theta, psi) containing the Euler angles in radians.

        """
        q1 = q[0]
        q2 = q[1]
        q3 = q[2]
        q4 = q[3]
        m13 = 2.0 * (q2 * q4 + q1 * q3)
        m23 = 2.0 * (q3 * q4 - q1 * q2)
        m33 = q1 * q1 - q2 * q2 - q3 * q3 + q4 * q4
        m31 = 2.0 * (q2 * q4 - q1 * q3)
        m32 = 2.0 * (q3 * q4 + q1 * q2)
        phi = GeometryOperators.atan2(m13, -m23)
        theta = GeometryOperators.atan2((1.0 - m33 * m33) ** 0.5, m33)
        psi = GeometryOperators.atan2(m31, m32)
        return phi, theta, psi

    @staticmethod
    def euler_zxz_to_quaternion(phi: float, theta: float, psi: float) -> list[float]:  # pragma: no cover
        """Convert the Euler angles following rotation sequence ZXZ to a quaternion.

        Parameters
        ----------
        phi : float
            Euler angle phi in radians.
        theta : float
            Euler angle theta in radians.
        psi : float
            Euler angle psi in radians.

        Returns
        -------
        list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        """
        t1 = phi
        t2 = theta
        t3 = psi
        c = math.cos(t2 * 0.5)
        s = math.sin(t2 * 0.5)
        q1 = c * math.cos((t1 + t3) * 0.5)
        q2 = s * math.cos((t1 - t3) * 0.5)
        q3 = s * math.sin((t1 - t3) * 0.5)
        q4 = c * math.sin((t1 + t3) * 0.5)
        return [q1, q2, q3, q4]

    @staticmethod
    def quaternion_to_euler_zyz(q: list[float]) -> tuple[float, float, float]:  # pragma: no cover
        """Convert a quaternion to Euler angles following rotation sequence ZYZ.

        Parameters
        ----------
        q : list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        Returns
        -------
        tuple[float, float, float]
            (phi, theta, psi) containing the Euler angles in radians.

        """
        q1 = q[0]
        q2 = q[1]
        q3 = q[2]
        q4 = q[3]
        m13 = 2.0 * (q2 * q4 + q1 * q3)
        m23 = 2.0 * (q3 * q4 - q1 * q2)
        m33 = q1 * q1 - q2 * q2 - q3 * q3 + q4 * q4
        m31 = 2.0 * (q2 * q4 - q1 * q3)
        m32 = 2.0 * (q3 * q4 + q1 * q2)
        phi = GeometryOperators.atan2(m23, m13)
        theta = GeometryOperators.atan2((1.0 - m33 * m33) ** 0.5, m33)
        psi = GeometryOperators.atan2(m32, -m31)
        return phi, theta, psi

    @staticmethod
    def euler_zyz_to_quaternion(phi: float, theta: float, psi: float) -> list[float]:  # pragma: no cover
        """Convert the Euler angles following rotation sequence ZYZ to a quaternion.

        Parameters
        ----------
        phi : float
            Euler angle phi in radians.
        theta : float
            Euler angle theta in radians.
        psi : float
            Euler angle psi in radians.

        Returns
        -------
        list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        """
        t1 = phi
        t2 = theta
        t3 = psi
        c = math.cos(t2 * 0.5)
        s = math.sin(t2 * 0.5)
        q1 = c * math.cos((t1 + t3) * 0.5)
        q2 = -s * math.sin((t1 - t3) * 0.5)
        q3 = s * math.cos((t1 - t3) * 0.5)
        q4 = c * math.sin((t1 + t3) * 0.5)
        return [q1, q2, q3, q4]

    @staticmethod
    def deg2rad(angle: float) -> float:
        """Convert the angle from degrees to radians.

        Parameters
        ----------
        angle : float
            Angle in degrees.

        Returns
        -------
        float
            Angle in radians.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> go.deg2rad(180.0)
        3.141592653589793

        """
        pi = math.pi
        return angle / 180.0 * pi

    @staticmethod
    def rad2deg(angle: float) -> float:
        """Convert the angle from radians to degrees.

        Parameters
        ----------
        angle : float
            Angle in radians.

        Returns
        -------
        float
            Angle in degrees.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> import math
        >>> go.rad2deg(math.pi)
        180.0

        """
        pi = math.pi
        return angle * 180.0 / pi

    @staticmethod
    def atan2(y: float, x: float) -> float:  # pragma: no cover
        """Implementation of atan2 that does not suffer from sign issues.

        This implementation always returns 0.0 for very small values.

        Parameters
        ----------
        y : float
            Y-axis value for atan2.
        x : float
            X-axis value for atan2.

        Returns
        -------
        float
            Arctangent of y/x in radians.

        """
        eps = 7.0 / 3.0 - 4.0 / 3.0 - 1.0
        if abs(y) < eps:
            y = 0.0
        if abs(x) < eps:
            x = 0.0
        return math.atan2(y, x)

    @staticmethod
    def q_prod(p: list[float], q: list[float]) -> list[float]:  # pragma: no cover
        """Evaluate the product of two quaternions.

        The product is defined as:
        p = p0 + p' = p0 + ip1 + jp2 + kp3.
        q = q0 + q' = q0 + iq1 + jq2 + kq3.
        r = pq = p0q0 - p' • q' + p0q' + q0p' + p' x q'.

        Parameters
        ----------
        p : list[float]
            List of ``[p1, p2, p3, p4]`` coordinates for quaternion ``p``.
        q : list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for quaternion ``q``.

        Returns
        -------
        list[float]
            List of [r1, r2, r3, r4] coordinates for the result quaternion.

        """
        p0 = p[0]
        pv = p[1:4]
        q0 = q[0]
        qv = q[1:4]

        r0 = p0 * q0 - GeometryOperators.v_dot(pv, qv)

        t1 = GeometryOperators.v_prod(p0, qv)
        t2 = GeometryOperators.v_prod(q0, pv)
        t3 = GeometryOperators.v_cross(pv, qv)
        rv = GeometryOperators.v_sum(t1, GeometryOperators.v_sum(t2, t3))

        return [r0, rv[0], rv[1], rv[2]]

    @staticmethod
    def q_rotation(v: list[float], q: list[float]) -> list[float]:  # pragma: no cover
        """Evaluate the rotation of a vector, defined by a quaternion.

        Evaluated as:
        ``q = q0 + q' = q0 + iq1 + jq2 + kq3``,
        ``w = qvq* = (q0^2 - |q'|^2)v + 2(q' • v)q' + 2q0(q' x v)``.

        Parameters
        ----------
        v : list[float]
            List of ``[v1, v2, v3]`` coordinates for the vector.
        q : list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        Returns
        -------
        list[float]
            List of ``[w1, w2, w3]`` coordinates for the result vector ``w``.

        """
        q0 = q[0]
        qv = q[1:4]

        c1 = q0 * q0 - (qv[0] * qv[0] + qv[1] * qv[1] + qv[2] * qv[2])
        t1 = GeometryOperators.v_prod(c1, v)

        c2 = 2.0 * GeometryOperators.v_dot(qv, v)
        t2 = GeometryOperators.v_prod(c2, qv)

        t3 = GeometryOperators.v_cross(qv, v)
        t4 = GeometryOperators.v_prod(2.0 * q0, t3)

        w = GeometryOperators.v_sum(t1, GeometryOperators.v_sum(t2, t4))

        return w

    @staticmethod
    def q_rotation_inv(v: list[float], q: list[float]) -> list[float]:
        """Evaluate the inverse rotation of a vector that is defined by a quaternion.

        It can also be the rotation of the coordinate frame with respect to the vector.

        q = q0 + q' = q0 + iq1 + jq2 + kq3
        q* = q0 - q' = q0 - iq1 - jq2 - kq3
        w = q*vq

        Parameters
        ----------
        v : list[float]
            List of ``[v1, v2, v3]`` coordinates for the vector.
        q : list[float]
            List of ``[q1, q2, q3, q4]`` coordinates for the quaternion.

        Returns
        -------
        list[float]
            List of ``[w1, w2, w3]`` coordinates for the vector.

        """
        q1 = [q[0], -q[1], -q[2], -q[3]]
        return GeometryOperators.q_rotation(v, q1)

    @staticmethod
    def get_polygon_centroid(pts: list[list[float]]) -> list[float]:  # pragma: no cover
        """Evaluate the centroid of a polygon defined by its points.

        Parameters
        ----------
        pts : list[list[float]]
            List of points, with each point defined by its ``[x,y,z]`` coordinates.

        Returns
        -------
        list[float]
            List of [x,y,z] coordinates for the centroid of the polygon.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> pts = [[0.0, 0.0, 0.0], [1.0, 0.0, 0.0], [1.0, 1.0, 0.0], [0.0, 1.0, 0.0]]
        >>> go.get_polygon_centroid(pts)
        [0.5, 0.5, 0.0]

        """
        if len(pts) == 0:  # pragma: no cover
            raise ValueError("pts must contain at list one point")
        sx = sy = sz = sl = sl2 = 0
        x1, y1, z1 = pts[0]
        for i in range(len(pts)):  # counts from 0 to len(points)-1
            x0, y0, z0 = pts[i - 1]  # in Python points[-1] is last element of points
            x1, y1, z1 = pts[i]
            L = ((x1 - x0) ** 2 + (y1 - y0) ** 2) ** 0.5
            sx += (x0 + x1) / 2 * L
            sy += (y0 + y1) / 2 * L
            L2 = ((z1 - z0) ** 2 + (x1 - x0) ** 2) ** 0.5
            sz += (z0 + z1) / 2 * L2
            sl += L
            sl2 += L2
        xc = sx / sl if sl != 0.0 else x1
        yc = sy / sl if sl != 0.0 else y1
        zc = sz / sl2 if sl2 != 0.0 else z1

        return [xc, yc, zc]

    @staticmethod
    def cs_xy_pointing_expression(yaw: str, pitch: str, roll: str) -> list[list[str]]:  # pragma: no cover
        """Return x_pointing and y_pointing vectors as expressions.

        Parameters
        ----------
        yaw : str
            String expression for the yaw angle (rotation about Z-axis).
        pitch : str
            String expression for the pitch angle (rotation about Y-axis).
        roll : str
            String expression for the roll angle (rotation about X-axis).

        Returns
        -------
        list[list[str]]
            [x_pointing, y_pointing] vector expressions.

        """
        # X-Pointing
        xx = "cos(" + yaw + ")*cos(" + pitch + ")"
        xy = "sin(" + yaw + ")*cos(" + pitch + ")"
        xz = "sin(" + pitch + ")"

        # Y-Pointing
        yx = "sin(" + roll + ")*sin(" + pitch + ")*cos(" + yaw + ") - "
        yx += "sin(" + yaw + ")*cos(" + roll + ")"

        yy = "sin(" + roll + ")*sin(" + yaw + ")*sin(" + pitch + ") + "
        yy += "cos(" + roll + ")*cos(" + yaw + ")"

        yz = "sin(" + roll + " + pi)*cos(" + pitch + ")"  # use pi to avoid negative sign.

        # x, y pointing vectors for CS
        x_pointing = [xx, xy, xz]
        y_pointing = [yx, yy, yz]

        return [x_pointing, y_pointing]

    @staticmethod
    def get_numeric(s: str | float | None) -> float:
        """Convert a string to a numeric value. Discard the suffix.

        Parameters
        ----------
        s : str, float, or None
            String or numeric value to convert.

        Returns
        -------
        float
            Numeric value.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> go.get_numeric("123.45mm")
        123.45

        """
        if type(s) == str:
            if s == "Global":
                return 0.0
            else:
                return float("".join(c for c in s if c.isdigit() or c == "."))
        elif s is None:
            return 0.0
        else:
            return float(s)

    @staticmethod
    def is_small(s: str | float) -> bool:
        """Return ``True`` if the number represented by s is zero (i.e very small).

        Parameters
        ----------
        s : str, or float
            Variable value.

        Returns
        -------
        bool
            ``True`` if the value is very small, ``False`` otherwise.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> go.is_small(0.0)
        True
        >>> go.is_small(1e-20)
        True
        >>> go.is_small(1.0)
        False

        """
        n = GeometryOperators.get_numeric(s)
        return True if math.fabs(n) < 2.0 * abs(sys.float_info.epsilon) else False

    @staticmethod
    def numeric_cs(cs_in: list[str] | str) -> list[float] | None:  # pragma: no cover
        """Return a list of [x,y,z] numeric values given a coordinate system as input.

        Parameters
        ----------
        cs_in : list[str], or str
            ``["x", "y", "z"]`` or "Global".

        Returns
        -------
        list[float], or None
            Numeric coordinate values or None.

        """
        if type(cs_in) is str:
            if cs_in == "Global":
                return [0.0, 0.0, 0.0]
            else:
                return None
        elif type(cs_in) is list:
            if len(cs_in) == 3:
                return [GeometryOperators.get_numeric(s) if type(s) is str else s for s in cs_in]
            else:
                return [0, 0, 0]

    @staticmethod
    def orient_polygon(x: list[float], y: list[float], clockwise: bool = True) -> tuple[list[float], list[float]]:
        """Orient a polygon clockwise or counterclockwise.

        The vertices should be already ordered either way.
        Use this function to change the orientation.
        The polygon is represented by its vertices coordinates.

        Parameters
        ----------
        x : list[float]
            List of x coordinates of the vertices. Length must be >= 1.
            Degenerate polygon with only 2 points is also accepted, in this case the points are returned unchanged.
        y : list[float]
            List of y coordinates of the vertices. Must be of the same length as x.
        clockwise : bool, optional
            If ``True`` the polygon is oriented clockwise, if ``False`` it is oriented counterclockwise.
            The default is ``True``.

        Returns
        -------
        tuple[list[float], list[float]]
            Lists of oriented vertices.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> x = [0.0, 1.0, 1.0, 0.0]
        >>> y = [0.0, 0.0, 1.0, 1.0]
        >>> x_new, y_new = go.orient_polygon(x, y, clockwise=True)

        """
        x_ret = x[:]
        y_ret = y[:]
        if len(x) < 2:  # pragma: no cover
            raise ValueError("'x' length must be >= 2")
        if len(y) != len(x):  # pragma: no cover
            raise ValueError("'y' must be same length as 'x'")
        if len(x) == 2:
            return x_ret, y_ret
        # fmt: off
        # select a vertex on the hull
        xmin = min(x)
        ixmin = [i for i, el in enumerate(x) if xmin == el]
        if len(ixmin) == 1:
            imin = ixmin[0]
        else:  # searching for the minimum y
            tmpy = [(i, el) for i, el in enumerate(y) if i in ixmin]
            min_tmpy = min(tmpy, key=lambda t: t[1])
            imin = min_tmpy[0]
        ymin = y[imin]
        if imin == 0:  # the minimum is the first point of the polygon
            xa = x[-1]
            ya = y[-1]
            xb = xmin
            yb = ymin
            xc = x[1]
            yc = y[1]
        elif imin == len(x)-1:  # the minimum is the last point of the polygon
            xa = x[imin-1]
            ya = y[imin-1]
            xb = xmin
            yb = ymin
            xc = x[0]
            yc = y[0]
        else:
            xa = x[imin-1]
            ya = y[imin-1]
            xb = xmin
            yb = ymin
            xc = x[imin+1]
            yc = y[imin+1]
        det = (xb-xa) * (yc-ya) - (xc-xa) * (yb-ya)
        if det > 0:  # counterclockwise
            is_CW = False
        else:   # clockwise
            is_CW = True
        # fmt: on
        if (clockwise and not is_CW) or (not clockwise and is_CW):
            x_ret.reverse()
            y_ret.reverse()
        return x_ret, y_ret

    @staticmethod
    def v_angle_sign(
        va: list[float], vb: list[float], vn: list[float], right_handed: bool = True
    ) -> float:  # pragma: no cover
        """Evaluate the signed angle between two geometry vectors.

        The sign is evaluated respect to the normal to the plane containing the two vectors as per the following rule.
        In case of opposite vectors, it returns an angle equal to 180deg (always positive).
        Assuming that the plane normal is normalized (vb == 1), the signed angle is simplified.
        For the right-handed rotation from Va to Vb:
        - atan2((va x Vb) . vn, va . vb).
        For the left-handed rotation from Va to Vb:
        - atan2((Vb x va) . vn, va . vb).

        Parameters
        ----------
        va : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        vb : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.
        vn : list[float]
            List of ``[x, y, z]`` coordinates for the plane normal.
        right_handed : bool, optional
            Whether to consider the right-handed rotation from va to vb.
            When ``False``, left-hand rotation from va to vb is considered.
            The default is ``True``.

        Returns
        -------
        float
            Angle in radians.

        """
        tol = 1e-12
        cross = GeometryOperators.v_cross(va, vb)
        if GeometryOperators.v_norm(cross) < tol:
            return math.pi
        if not GeometryOperators.is_collinear(cross, vn):
            raise ValueError("vn must be the normal to the plane containing va and vb")  # pragma: no cover

        vnn = GeometryOperators.normalize_vector(vn)
        if right_handed:
            return math.atan2(GeometryOperators.v_dot(cross, vnn), GeometryOperators.v_dot(va, vb))
        else:
            mcross = GeometryOperators.v_cross(vb, va)
            return math.atan2(GeometryOperators.v_dot(mcross, vnn), GeometryOperators.v_dot(va, vb))

    @staticmethod
    def v_angle_sign_2D(va: list[float], vb: list[float], right_handed: bool = True) -> float:
        """Evaluate the signed angle between two 2D geometry vectors.

        It is the 2D version of the ``GeometryOperators.v_angle_sign`` considering vn = [0,0,1].
        In case of opposite vectors, it returns an angle equal to 180deg (always positive).

        Parameters
        ----------
        va : list[float]
            List of ``[x, y]`` coordinates for the first vector.
        vb : list[float]
            List of ``[x, y]`` coordinates for the second vector.
        right_handed : bool, optional
            Whether to consider the right-handed rotation from Va to Vb.
            When ``False``, left-hand rotation from Va to Vb is considered.
            The default is ``True``.

        Returns
        -------
        float
            Angle in radians.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> import math
        >>> va = [1.0, 0.0]
        >>> vb = [0.0, 1.0]
        >>> angle = go.v_angle_sign_2D(va, vb)
        >>> math.degrees(angle)
        90.0

        """
        c = va[0] * vb[1] - va[1] * vb[0]

        if right_handed:
            return math.atan2(c, GeometryOperators.v_dot(va, vb))
        else:
            return math.atan2(-c, GeometryOperators.v_dot(va, vb))

    @staticmethod
    def point_in_polygon(point: list[float], polygon: list[list[float]], tolerance: float = 1e-8) -> int:
        """Determine if a point is inside, outside the polygon or at exactly at the border.

        The method implements the radial algorithm (https://es.wikipedia.org/wiki/Algoritmo_radial)

        Parameters
        ----------
        point : list[float]
            List of ``[x, y]`` coordinates.
        polygon : list[list[float]]
            [[x1, x2, ..., xn],[y1, y2, ..., yn]]
        tolerance : float, optional
            Tolerance used for the algorithm. The default is ``1e-8``.

        Returns
        -------
        int
            - ``-1`` When the point is outside the polygon.
            - ``0`` When the point is exactly on one of the sides of the polygon.
            - ``1`` When the point is inside the polygon.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> point = [0.5, 0.5]
        >>> polygon = [[0.0, 1.0, 1.0, 0.0], [0.0, 0.0, 1.0, 1.0]]
        >>> go.point_in_polygon(point, polygon)
        1

        """
        # fmt: off
        tol = tolerance
        if len(point) != 2:  # pragma: no cover
            raise ValueError("Point must be a list in the form [x, y].")
        pl = len(polygon[0])
        if len(polygon[1]) != pl:  # pragma: no cover
            raise ValueError("Polygon x and y lists must be the same length")
        asum = 0
        for i in range(pl):
            vj = [polygon[0][i-1], polygon[1][i-1]]
            vi = [polygon[0][i], polygon[1][i]]
            if GeometryOperators.points_distance(point, vi) < tol:
                return 0  # point is one of polyline vertices
            vpj = GeometryOperators.v_points(point, vj)
            vpi = GeometryOperators.v_points(point, vi)
            a = GeometryOperators.v_angle_sign_2D(vpj, vpi)
            if abs(abs(a) - math.pi) < tol:
                return 0
            asum += a
        if abs(asum) < tol:
            return -1
        elif abs(abs(asum) - 2*math.pi) < tol:
            return 1
        else:  # pragma: no cover
            raise Exception("Unexpected error!")
        # fmt: on

    @staticmethod
    def is_point_in_polygon(point: list[float], polygon: list[list[float]]) -> bool:
        """Determine if a point is inside or outside a polygon, both located on the same plane.

        The method implements the radial algorithm (https://es.wikipedia.org/wiki/Algoritmo_radial)

        Parameters
        ----------
        point : list[float]
            List of ``[x, y]`` coordinates.
        polygon : list[list[float]]
            [[x1, x2, ..., xn],[y1, y2, ..., yn]]

        Returns
        -------
        bool
            ``True`` if the point is inside the polygon or exactly on one of its sides.
            ``False`` otherwise.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> point = [0.5, 0.5]
        >>> polygon = [[0.0, 1.0, 1.0, 0.0], [0.0, 0.0, 1.0, 1.0]]
        >>> go.is_point_in_polygon(point, polygon)
        True

        """
        r = GeometryOperators.point_in_polygon(point, polygon)
        if r == -1:
            return False
        else:
            return True

    @staticmethod
    def are_segments_intersecting(
        a1: list[float], a2: list[float], b1: list[float], b2: list[float], include_collinear: bool = True
    ) -> bool:
        """Determine if the two segments a and b are intersecting.

        Parameters
        ----------
        a1 : list[float]
            First point of segment a. List of ``[x, y]`` coordinates.
        a2 : list[float]
            Second point of segment a. List of ``[x, y]`` coordinates.
        b1 : list[float]
            First point of segment b. List of ``[x, y]`` coordinates.
        b2 : list[float]
            Second point of segment b. List of ``[x, y]`` coordinates.
        include_collinear : bool, optional
            If ``True`` two segments are considered intersecting also if just one end lies on the other segment.
            The default is ``True``.

        Returns
        -------
        bool
            ``True`` if the segments are intersecting.
            ``False`` otherwise.

        """

        # fmt: off
        def on_segment(p, q, r):
            # Given three collinear points p, q, r, the function checks if point q lies on line-segment 'pr'
            if ((q[0] <= max(p[0], r[0])) and (q[0] >= min(p[0], r[0])) and
               (q[1] <= max(p[1], r[1])) and (q[1] >= min(p[1], r[1]))):
                return True
            return False

        def orientation(p, q, r):
            # Find the orientation of an ordered triplet (p,q,r) using the slope evaluation.
            # The function returns the following values:
            # 0 : Collinear points
            # 1 : Clockwise points
            # -1 : Counterclockwise
            val = float(q[1]-p[1]) * float(r[0]-q[0]) - float(q[0]-p[0]) * float(r[1]-q[1])
            if val > 0:
                return 1  # Clockwise orientation
            elif val < 0:
                return -1  # Counterclockwise orientation
            else:
                return 0   # Collinear orientation

        # MAIN
        # Find the 4 orientations
        o1 = orientation(a1, a2, b1)
        o2 = orientation(a1, a2, b2)
        o3 = orientation(b1, b2, a1)
        o4 = orientation(b1, b2, a2)

        # General case
        if (o1 != o2) and (o3 != o4):
            if include_collinear:
                return True
            else:
                # a1 , a2 and b1 are collinear and b1 lies on segment a1a2
                if (o1 == 0) and on_segment(a1, b1, a2):
                    return False
                # a1 , a2 and b2 are collinear and b2 lies on segment a1a2
                if (o2 == 0) and on_segment(a1, b2, a2):
                    return False
                # b1 , b2 and a1 are collinear and a1 lies on segment b1b2
                if (o3 == 0) and on_segment(b1, a1, b2):
                    return False
                # b1 , b2 and a2 are collinear and a2 lies on segment b1b2
                if (o4 == 0) and on_segment(b1, a2, b2):
                    return False
                return True

        # Special Cases
        # a1 , a2 and b1 are collinear and b1 lies on segment a1a2
        if (o1 == 0) and on_segment(a1, b1, a2):
            return include_collinear
        # a1 , a2 and b2 are collinear and b2 lies on segment a1a2
        if (o2 == 0) and on_segment(a1, b2, a2):
            return include_collinear
        # b1 , b2 and a1 are collinear and a1 lies on segment b1b2
        if (o3 == 0) and on_segment(b1, a1, b2):
            return include_collinear
        # b1 , b2 and a2 are collinear and a2 lies on segment b1b2
        if (o4 == 0) and on_segment(b1, a2, b2):
            return include_collinear
        # If none of the cases
        return False
        # fmt: on

    @staticmethod
    def is_segment_intersecting_polygon(a: list[float], b: list[float], polygon: list[list[float]]) -> bool:
        """Determine if a segment defined by two points ``a`` and ``b`` intersects a polygon.

        Points on the vertices and on the polygon boundaries are not considered intersecting.

        Parameters
        ----------
        a : list[float]
            First point of the segment. List of ``[x, y]`` coordinates.
        b : list[float]
            Second point of the segment. List of ``[x, y]`` coordinates.
        polygon : list[list[float]]
            [[x1, x2, ..., xn],[y1, y2, ..., yn]]

        Returns
        -------
        bool
            ``True`` if the segment intersect the polygon. ``False`` otherwise.

        """
        if len(a) != 2 or len(b) != 2:
            raise ValueError("Point must be a list in the form [x, y]")
        pl = len(polygon[0])
        if len(polygon[1]) != pl:
            raise ValueError("The two sublists in polygon must have the same length")

        a_in = GeometryOperators.is_point_in_polygon(a, polygon)
        b_in = GeometryOperators.is_point_in_polygon(b, polygon)
        if a_in != b_in:
            return True  # one point is inside and one is outside, no need for further investigation.
        for i in range(pl):
            vj = [polygon[0][i - 1], polygon[1][i - 1]]
            vi = [polygon[0][i], polygon[1][i]]
            if GeometryOperators.are_segments_intersecting(a, b, vi, vj, include_collinear=False):
                return True
        return False

    @staticmethod
    def is_perpendicular(a: list[float], b: list[float], tol: float = 1e-6) -> bool:
        """Check if two vectors are perpendicular.

        Parameters
        ----------
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first vector.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second vector.
        tol : float, optional
            Linear tolerance. The default is ``1e-6``.

        Returns
        -------
        bool
            ``True`` if vectors are perpendicular, ``False`` otherwise.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> a = [1.0, 0.0, 0.0]
        >>> b = [0.0, 1.0, 0.0]
        >>> go.is_perpendicular(a, b)
        True

        """
        var = GeometryOperators._v_dot(a, b)
        if abs(var) < tol * tol:
            return True
        else:
            return False

    @staticmethod
    def is_point_projection_in_segment(p: list[float], a: list[float], b: list[float]) -> bool:
        """Check if a point projection lies on the segment defined by two points.

        Parameters
        ----------
        p : list[float]
            List of ``[x, y, z]`` coordinates for the reference point ``p``.
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the segment.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the segment.

        Returns
        -------
        bool
            ``True`` when the projection point lies on the segment defined by the two points, ``False`` otherwise.

        """
        # fmt: off
        dx = b[0]-a[0]
        dy = b[1]-a[1]
        inner_product = (p[0]-a[0])*dx + (p[1]-a[1])*dy
        return 0 <= inner_product <= dx*dx + dy*dy
        # fmt: on

    @staticmethod
    def point_segment_distance(p: list[float], a: list[float], b: list[float]) -> float:  # pragma: no cover
        """Calculate the distance between a point ``p`` and a segment defined by two points ``a`` and ``b``.

        Parameters
        ----------
        p : list[float]
            List of ``[x, y, z]`` coordinates for the reference point ``p``.
        a : list[float]
            List of ``[x, y, z]`` coordinates for the first point of the segment.
        b : list[float]
            List of ``[x, y, z]`` coordinates for the second point of the segment.

        Returns
        -------
        float
            Distance between the point and the segment.

        """
        # fmt: off
        den = math.sqrt((b[0] - a[0])**2 + (b[1] - a[1])**2)
        num = (b[0] - a[0])*(a[1] - p[1]) - (a[0] - p[0])*(b[1] - a[1])
        d = abs(num)/den
        return d
        # fmt: on

    @staticmethod
    def find_largest_rectangle_inside_polygon(
        polygon: list[list[float]], partition_max_order: int = 16
    ) -> list[list[list[float]]]:
        """Find the largest area rectangles of arbitrary orientation in a polygon.

        Implements the algorithm described by Rubén Molano, et al.
        *"Finding the largest area rectangle of arbitrary orientation in a closed contour"*, published in
        *Applied Mathematics and Computation*.
        https://doi.org/10.1016/j.amc.2012.03.063.
        (https://www.sciencedirect.com/science/article/pii/S0096300312003207)

        Parameters
        ----------
        polygon : list[list[float]]
            [[x1, x2, ..., xn],[y1, y2, ..., yn]]
        partition_max_order : int, optional
            Order of the lattice partition used to find the quasi-lattice polygon that approximates ``polygon``.
            The default is ``16``.

        Returns
        -------
        list[list[list[float]]]
            List containing the rectangles points. Return all rectangles found.
            List is in the form: [[[x1, y1],[x2, y2],...],[[x1, y1],[x2, y2],...],...].

        """

        # fmt: off
        def evaluate_partition_size(polygon, partition_max_order):
            x, y = polygon
            max_size = max(max(x)-min(x), max(y)-min(y))
            L = max_size/partition_max_order
            return L

        def build_s_ploygon_points(vertices, L):
            x, y = vertices

            # build the lattice
            xmin = min(x)
            r = int(math.ceil(float(max(x)-xmin)/L))
            ymin = min(y)
            s = int(math.ceil(float(max(y)-ymin)/L))

            # get the lattice points S inside the polygon
            Spoints = []
            for i in range(r + 1):
                xi = xmin + L * i
                for j in range(s + 1):
                    yj = ymin + L * j
                    if GeometryOperators.is_point_in_polygon([xi, yj], [x, y]):
                        Spoints.append([xi, yj])
            return Spoints

        def build_u_matrix(S, polygon):
            N = len(S)
            # preallocate the matrix
            Umatrix = [[None for j in range(N)] for i in range(N)]
            for i in range(N):
                for j in range(N):
                    if i >= j:
                        Umatrix[i][j] = 0
                    else:
                        if GeometryOperators.is_segment_intersecting_polygon(S[i], S[j], polygon):
                            Umatrix[i][j] = 0
                        else:
                            p = GeometryOperators.get_mid_point(S[i], S[j])
                            if not GeometryOperators.is_point_in_polygon(p, polygon):
                                Umatrix[i][j] = 0
                            else:
                                Umatrix[i][j] = GeometryOperators.v_points(S[i], S[j])
            return Umatrix

        def inside(i, j):
            if U[i][j] == 0 and isinstance(U[i][j], int):
                return False
            else:
                return True

        def compute_largest_rectangle(S):
            max_area = 0
            rectangles = []
            N = len(S)
            for i in range(N-3):
                for j in range(i+1, N-2):
                    if inside(i, j):
                        for k in range(j+1, N-1):
                            if inside(i, k) and GeometryOperators.is_perpendicular(U[i][j], U[i][k]):
                                ps = GeometryOperators.v_sum(GeometryOperators.v_sub(S[j], S[i]), S[k])
                                try:
                                    s = S.index(ps)
                                except ValueError:
                                    break
                                if inside(k, s) and inside(j, s):
                                    area = GeometryOperators.v_norm(U[i][j]) * GeometryOperators.v_norm(U[i][k])
                                    if area > max_area:
                                        max_area = area
                                        R = [S[i], S[j], S[s], S[k]]
                                        rectangles = [R]
                                    elif area == max_area:
                                        R = [S[i], S[j], S[s], S[k]]
                                        rectangles.append(R)
            return rectangles

        L = evaluate_partition_size(polygon, partition_max_order=partition_max_order)
        S = build_s_ploygon_points(polygon, L)
        U = build_u_matrix(S, polygon)
        R = compute_largest_rectangle(S)
        return R
        # fmt: on

    @staticmethod
    def degrees_over_rounded(angle: float, digits: int) -> float:
        """Ceil of angle.

        Parameters
        ----------
        angle : float
            Angle in radians which will be converted to degrees and will be over-rounded to the next "digits" decimal.
        digits : int
            Integer number which is the number of decimals.

        Returns
        -------
        float
            Angle in degrees rounded up.

        """
        return math.ceil(math.degrees(angle) * 10**digits) / (10**digits)

    @staticmethod
    def radians_over_rounded(angle: float, digits: int) -> float:
        """Radian angle ceiling.

        Parameters
        ----------
        angle : float
            Angle in degrees which will be converted to radians and will be over-rounded to the  next "digits" decimal.
        digits : int
            Integer number which is the number of decimals.

        Returns
        -------
        float
            Angle in radians rounded up.

        """
        return math.ceil(math.radians(angle) * 10**digits) / (10**digits)

    @staticmethod
    def degrees_default_rounded(angle: float, digits: int) -> float:
        """Convert angle to degree with given digits rounding.

        Parameters
        ----------
        angle : float
            Angle in radians which will be converted to degrees and will be under-rounded to the next "digits" decimal.
        digits : int
            Integer number which is the number of decimals.

        Returns
        -------
        float
            Angle in degrees rounded down.

        """
        return math.floor(math.degrees(angle) * 10**digits) / (10**digits)

    @staticmethod
    def radians_default_rounded(angle: float, digits: int) -> float:
        """Convert to radians with given round.

        Parameters
        ----------
        angle : float
            Angle in degrees which will be converted to radians and will be under-rounded to the next "digits" decimal.
        digits : int
            Integer number which is the number of decimals.

        Returns
        -------
        float
            Angle in radians rounded down.

        """
        return math.floor(math.radians(angle) * 10**digits) / (10**digits)

    @staticmethod
    def find_closest_points(
        points_list: list[list[float]], reference_point: list[float], tol: float = 1e-6
    ) -> list[list[float]] | bool:  # pragma: no cover
        """Given a list of points, finds the closest points to a reference point.

        It returns a list of points because more than one can be found.
        It works with 2D or 3D points. The tolerance used to evaluate the distance
        to the reference point can be specified.

        Parameters
        ----------
        points_list : list[list[float]]
            List of points. The points can be defined in 2D or 3D space.
        reference_point : list[float]
            The reference point. The point can be defined in 2D or 3D space (same as points_list).
        tol : float, optional
            The tolerance used to evaluate the distance. The default is ``1e-6``.

        Returns
        -------
        list[list[float]], or bool
            List of closest points or False if none found.

        """
        # fmt: off
        if not isinstance(points_list, list) or not isinstance(points_list[0], list):
            raise AttributeError("points_list must be a list of points")
        if len(points_list[0]) < 2 or len(points_list[0]) > 3:
            raise AttributeError("points must be defined in either 2D or 3D space.")
        if len(points_list[0]) != len(reference_point):
            raise AttributeError("Points in points_list attribute and reference_point must have the same length.")
        # make copy of the input points
        pl = [i[:] for i in points_list]
        pr = reference_point[:]
        # find the closest points
        dm = 1e12
        close_points = []
        for p in pl:
            d = GeometryOperators.points_distance(p, pr)
            if abs(d-dm) < tol:
                close_points.append(p)
            elif d < dm:
                dm = d
                close_points = [p]
        if close_points:
            return close_points
        else:  # pragma: no cover
            return False
        # fmt: on

    @staticmethod
    def mirror_point(
        start: list[float], reference: list[float], vector: list[float]
    ) -> list[float]:  # pragma: no cover
        """Mirror point about a plane defining by a point on the plane and a normal point.

        Parameters
        ----------
        start : list[float]
            Point to be mirrored.
        reference : list[float]
            The reference point. Point on the plane around which you want to mirror the object.
        vector : list[float]
            Normalized vector used for the mirroring.

        Returns
        -------
        list[float]
            List of the reflected point.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> start = [1.0, 0.0, 0.0]
        >>> reference = [0.0, 0.0, 0.0]
        >>> vector = [1.0, 0.0, 0.0]
        >>> go.mirror_point(start, reference, vector)
        [-1.0, 0.0, 0.0]

        """
        distance = [start[i] - reference[i] for i in range(3)]
        vector_norm = GeometryOperators.v_norm(vector)
        vector = [vector[i] / vector_norm for i in range(3)]
        dot_product = sum([distance[i] * vector[i] for i in range(3)])
        reflection = [-dot_product * vector[i] * 2 + start[i] for i in range(3)]
        return reflection

    @staticmethod
    def find_points_along_lines(
        points: list[list[float]] | np.ndarray,
        minimum_number_of_points: int = 3,
        distance_threshold: float | None = None,
        selected_angles: list[float] | None = None,
        return_additional_info: bool = False,
    ) -> tuple:
        """Detect all points that are placed along lines.

        The method takes as input a list of 2D points and detects all lines that contain at least 3 points.
        Optionally, the minimum number of points contained in a line can be specified by setting the
        argument ``minimum_number_of_points``.
        As default, all points along the lines are returned, regardless of their relative distance.
        Optionally, a `distance_threshold` can be set. If two points in a line are separated by a distance larger than
        ``distance_threshold``, the line is divided in two parts. If one of those parts does not satisfy the
        ``minimum_number_of_points`` requirement, it is discarded.
        If `distance_threshold` is set (not ``None``), the computational time increases.

        Parameters
        ----------
        points : list[list[float]] or np.ndarray
            The points to process. Can be a list of lists where each sublist
            represents a 2D point ``[x, y]`` coordinates, or a numpy array of shape (n, 2).
        minimum_number_of_points : int, optional
            The minimum number of points that a line must contain.
            The default is ``3``.
        distance_threshold : float or None, optional
            If two points in a line are separated by a distance larger than `distance_threshold`,
            the line is divided in two parts.
            The default is ``None``.
        selected_angles : list[float] or None, optional
            Specify a list of angles in degrees. If specified, the method returns only the lines which
            have one of the specified angles.
            The angle is defined as the positive angle of the infinite line with respect to the x-axis
            It is positive, and between 0 and 180 degrees.
            For example, ``[90]`` indicated vertical lines parallel to the y-axis,
            ``[0]`` or ``[180]`` identifies horizontal lines parallel to the x-axis,
            ``45`` identifies lines parallel to the first quadrant bisector.
            The default is ``None``.
        return_additional_info : bool, optional
            Whether to return additional information about the number of elements processed.
            The default is ``False``.

        Returns
        -------
        tuple
            The tuple contains:
            - lines: a list of lists where each sublist represents a 2D point ``[x, y]`` coordinates in each line.
            - lines indexes: a list of lists where each sublist represents the index of the point in each line.
                            The index is referring to the point position in the input point list.
            - number of processed points: optional, returned if ``return_additional_info`` is ``True``
            - number of processed lines: optional, returned if ``return_additional_info`` is ``True``
            - number of detected lines after ``minimum_number_of_points`` is applied: optional,
                returned if ``return_additional_info`` is ``True``
            - number of detected lines after ``distance_threshold`` is applied: optional,
                returned if ``return_additional_info`` is ``True``

        """

        # Parameters
        min_num_points = max(3, int(minimum_number_of_points))
        cluster_lines_flag = False if distance_threshold is None else True
        if selected_angles is not None:
            if 0 in selected_angles or 180 in selected_angles:
                selected_angles.extend([0, 180])
            selected_angles = set(selected_angles)
            selected_angles = np.deg2rad(np.array(list(selected_angles)))
        tol_rad = 1e-10

        # Converts the input
        points = np.array(points)
        # Number of points
        num_points = len(points)

        angles = []
        # Evaluate the angle with x-axis for every possible line defined by 2 points
        # Nested for loops to iterate over each point
        for i in range(num_points - 1):
            angles.append([])
            for j in range(i + 1, num_points):
                p1 = points[i]
                p2 = points[j]
                x1 = p1[0]
                y1 = p1[1]
                x2 = p2[0]
                y2 = p2[1]

                dx = x2 - x1
                dy = y2 - y1

                # Calculate the angle in radians with the x-axis
                angle_rad = np.arctan2(dy, dx)
                if abs(angle_rad - np.pi) < tol_rad:
                    angles[i].append(0.0)
                elif angle_rad < 0:
                    angles[i].append(angle_rad + np.pi)
                else:
                    angles[i].append(angle_rad)

        # rounding the angles float number
        def bin_float(value, bin_size):
            return round(value / bin_size) * bin_size

        for col in angles:
            for i, a in enumerate(col):
                col[i] = bin_float(a, tol_rad)

        # Group the lines based on angles
        detected_lines_idx = []
        for i in range(num_points - 1):
            column = angles[i]
            new_lines = defaultdict(set)  # sets are more efficient than lists for inclusion check
            lines_to_check = [line for line in detected_lines_idx if i in line]
            for k in range(len(column)):
                j = k + i + 1
                angle = column[k]

                # Check if both indexes (points) are in any of the sets (lines)
                # Note that lines containing `i` are preselected outside this loop.
                # This makes the check O(n^2) instead of O(n^3)
                found = any(j in l for l in lines_to_check)
                if found:
                    # this two points already belong to a line, no need to store them again
                    continue
                new_lines[angle].update((i, j))

            # Depending on user choice, it checks if the angle is among the desired angles
            if selected_angles is not None:
                selected_lines = []
                for ang, v in new_lines.items():
                    if any(abs(sa - ang) < tol_rad for sa in selected_angles):
                        selected_lines.append(v)
            else:
                selected_lines = [l for l in new_lines.values()]

            # considering only lines with at least 3 points
            lines_to_add = [l for l in selected_lines if len(l) >= 3]
            detected_lines_idx.extend(lines_to_add)

        # Discard the lines with less than min_num_points
        selected_lines_idx = [line for line in detected_lines_idx if len(line) >= min_num_points]

        # Convert the lines' indexes in ndarrays
        selected_lines_idx = [np.array(list(line)) for line in selected_lines_idx]

        # First sort the points in the detected lines
        lines_with_sorted_points_idx = []
        for line_idx in selected_lines_idx:
            pts_in_line = points[list(line_idx)]
            min_x = pts_in_line[:, 0].min()
            max_x = pts_in_line[:, 0].max()
            if max_x - min_x < 1e-7:
                # cluster on y because the line is vertical
                sort_idx = pts_in_line[:, 1].argsort()
            else:
                # cluster on x on the other cases
                sort_idx = pts_in_line[:, 0].argsort()
            sorted_points_idx = line_idx[sort_idx]
            lines_with_sorted_points_idx.append(sorted_points_idx)
        lines_idx = lines_with_sorted_points_idx

        def cluster_line_points(points_idx, threshold):
            # Requires sorted points, points must be in numpy array format
            # Initialize clusters
            clusters = []
            current_cluster = [points_idx[0]]
            # Iterate through the sorted points
            for i in range(1, len(points_idx)):
                # Check if the current point is within the distance threshold from the last point in the current cluster
                if np.linalg.norm(points[points_idx[i]] - points[points_idx[i - 1]]) <= threshold:
                    current_cluster.append(points_idx[i])
                else:
                    # The current point is too far from the last point, finalize the current cluster and start a new one
                    clusters.append(current_cluster)
                    current_cluster = [points_idx[i]]
            # Append the last cluster
            clusters.append(current_cluster)
            return clusters

        # separate lines based on required minimum distance btw points
        # It requires the points of the line to be sorted
        if cluster_lines_flag:
            clustered_lines = []
            for p_idx in lines_with_sorted_points_idx:
                clusters_in_line = cluster_line_points(p_idx, distance_threshold)
                clustered_lines.extend([c for c in clusters_in_line if len(c) >= min_num_points])
            lines_idx = clustered_lines

        # Convert indexes to points coordinates
        lines = [points[list(line)].tolist() for line in lines_idx]

        if return_additional_info:
            return lines, lines_idx, num_points, len(detected_lines_idx), len(selected_lines_idx), len(lines_idx)
        return lines, lines_idx

    @staticmethod
    def smallest_distance_between_polygons(
        polygon1: list[tuple[float, float]], polygon2: list[tuple[float, float]]
    ) -> float:
        """Find the smallest distance between two polygons using KDTree for efficient nearest neighbor search.

        Parameters
        ----------
        polygon1 : list[tuple[float, float]]
            List of (x, y) coordinates representing the points of the first polygon.
        polygon2 : list[tuple[float, float]]
            List of (x, y) coordinates representing the points of the second polygon.

        Returns
        -------
        float
            The smallest distance between any two points from the two polygons.

        Examples
        --------
        >>> from pyedb.generic.geometry_operators import GeometryOperators as go
        >>> polygon1 = [(1, 1), (4, 1), (4, 4), (1, 4)]
        >>> polygon2 = [(5, 5), (8, 5), (8, 8), (5, 8)]
        >>> go.smallest_distance_between_polygons(polygon1, polygon2)
        1.4142135623730951

        """
        try:
            from scipy.spatial import KDTree
        except ImportError:
            raise ImportError(
                "Scipy library is required for KDTree functionality. "
                "Please install it using 'pip install pyedb[geometry]' or 'pip install scipy'."
            )

        # Convert lists of points to numpy arrays
        points1 = np.array(polygon1)
        points2 = np.array(polygon2)

        # Check for overlapping points
        for point1 in points1:
            for point2 in points2:
                if np.array_equal(point1, point2):
                    print("Warning: Overlapping points detected. Distance will be 0.0.")
                    return 0.0

        # Build KDTree for the second polygon
        tree = KDTree(points2)

        # Query the nearest neighbor in the second polygon for each point in the first polygon
        distances, _ = tree.query(points1)

        # The smallest distance is the minimum of these distances
        min_distance = np.min(distances)

        return min_distance
