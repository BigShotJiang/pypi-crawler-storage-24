# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

from __future__ import annotations

import math
from typing import TYPE_CHECKING
import warnings

if TYPE_CHECKING:
    from pyedb.grpc.database.primitive.padstack_instance import PadstackInstance
from ansys.edb.core.definition.padstack_def import PadstackDef as CorePadstackDef
from ansys.edb.core.definition.padstack_def_data import (
    PadGeometryType as CorePadGeometryType,
    PadstackHoleRange as CorePadstackHoleRange,
    PadType as CorePadType,
    SolderballPlacement,
    SolderballShape,
)
import ansys.edb.core.geometry.polygon_data
from ansys.edb.core.geometry.polygon_data import PolygonData as CorePolygonData
from ansys.edb.core.hierarchy.structure3d import MeshClosure as CoreMeshClosure, Structure3D as CoreStructure3D

from pyedb.generic.general_methods import generate_unique_name
from pyedb.grpc.database.primitive.circle import Circle
from pyedb.grpc.database.utility.value import Value


class PadProperties:
    """Manages EDB functionalities for pad properties.

    Parameters
    ----------
    edb_padstack :

    layer_name : str
        Name of the layer.
    pad_type :
        Type of the pad.
    pedbpadstack : str
        Inherited AEDT object.

    Examples
    --------
    >>> from pyedb import Edb
    >>> edb = Edb("myedb", version="2026.1")
    >>> edb_pad_properties = edb.padstacks.definitions["MyPad"].pad_by_layer["TOP"]
    """

    def __init__(self, core, layer_name, pad_type, p_edb_padstack):
        self._edb_object = core
        self._pedbpadstack = p_edb_padstack
        self.layer_name = layer_name
        self.pad_type = pad_type
        self._edb_padstack = core

    @property
    def _stackup_layers(self):
        return self._pedbpadstack._stackup_layers

    @property
    def _edb(self):
        return self._pedbpadstack._edb

    @property
    def _pad_parameter_value(self):
        p_val = self._edb_padstack.get_pad_parameters(self.layer_name, CorePadType.REGULAR_PAD)
        if isinstance(p_val[0], ansys.edb.core.geometry.polygon_data.PolygonData):
            p_val = [CorePadGeometryType.PADGEOMTYPE_POLYGON] + [i for i in p_val]
        return p_val

    @property
    def geometry_type(self) -> float:
        """Geometry type.

        Returns
        -------
        int
            Type of the geometry.
        """
        return self._pad_parameter_value[0].value

    @property
    def _edb_geometry_type(self):
        return self._pad_parameter_value[0]

    @property
    def shape(self) -> str:
        """Pad shape.

        Returns
        -------
        str
            pad shape.
        """
        return self._pad_parameter_value[0].name.split("_")[-1].lower()

    @shape.setter
    def shape(self, value: str):
        """Set pad shape.

        Parameters
        ----------
        value : str
            Pad shape.
        """
        if value.lower() == "circle":
            self._update_pad_parameters_parameters(geom_type=CorePadGeometryType.PADGEOMTYPE_CIRCLE)
        elif value.lower() == "rectangle":
            self._update_pad_parameters_parameters(geom_type=CorePadGeometryType.PADGEOMTYPE_RECTANGLE)
        elif value.lower() == "polygon":
            self._update_pad_parameters_parameters(geom_type=CorePadGeometryType.PADGEOMTYPE_POLYGON)
        else:
            raise ValueError(
                f"Unsupported pad shape: {value}. Supported shapes are 'circle', 'rectangle', and 'polygon'."
            )

    @property
    def parameters_values(self):
        """Parameters.

        Returns
        -------
        list
            List of parameters.
        """
        try:
            return [Value(i) for i in self._pad_parameter_value[1]]
        except TypeError:
            return []

    @parameters_values.setter
    def parameters_values(self, value):
        if isinstance(value, (float, str)):
            value = [value]
        self._update_pad_parameters_parameters(params=value)

    @property
    def parameters_values_string(self):
        """Parameters value in string format."""
        try:
            return [str(i) for i in self._pad_parameter_value[1]]
        except TypeError:
            return []

    @property
    def polygon_data(self) -> CorePolygonData:
        """Parameters.

        Returns
        -------
        PolygonData
            PolygonData object.
        """
        p = self._pad_parameter_value[1]
        return p if isinstance(p, ansys.edb.core.geometry.polygon_data.PolygonData) else None

    @property
    def offset_x(self) -> float:
        """Offset for the X axis.

        Returns
        -------
        str
            Offset for the X axis.
        """
        return Value(self._pad_parameter_value[2])

    @property
    def offset_y(self) -> float:
        """Offset for the Y axis.

        Returns
        -------
        str
            Offset for the Y axis.
        """

        return Value(self._pad_parameter_value[3])

    @offset_x.setter
    def offset_x(self, value):
        self._update_pad_parameters_parameters(offsetx=value)

    @offset_y.setter
    def offset_y(self, value):
        self._update_pad_parameters_parameters(offsety=value)

    @property
    def rotation(self) -> float:
        """Rotation.

        Returns
        -------
        str
            Value for the rotation.
        """

        return Value(self._pad_parameter_value[4])

    @rotation.setter
    def rotation(self, value):
        self._update_pad_parameters_parameters(rotation=value)

    def _update_pad_parameters_parameters(
        self,
        layer_name=None,
        pad_type=None,
        geom_type=None,
        params=None,
        offsetx=None,
        offsety=None,
        rotation=None,
    ):
        if layer_name is None:
            layer_name = self.layer_name
        if pad_type is None:
            pad_type = CorePadType.REGULAR_PAD
        if geom_type is None:
            geom_type = self.geometry_type
        for k in CorePadGeometryType:
            if k.value == geom_type:
                geom_type = k
        if params is None:
            params = self._pad_parameter_value[1]
        elif isinstance(params, list):
            offsetx = [self._pedbpadstack._pedb._value_setter(i) for i in params]
        if rotation is None:
            rotation = self._pad_parameter_value[4]
        elif isinstance(rotation, (str, float, int)):
            rotation = self._pedbpadstack._pedb._value_setter(rotation)
        if offsetx is None:
            offsetx = self._pad_parameter_value[2]
        elif isinstance(offsetx, (str, float, int)):
            offsetx = self._pedbpadstack._pedb._value_setter(offsetx)
        if offsety is None:
            offsety = self._pad_parameter_value[3]
        elif isinstance(offsety, (str, float, int)):
            offsety = self._pedbpadstack._pedb._value_setter(offsety)
        self._edb_padstack.set_pad_parameters(
            layer=layer_name,
            pad_type=pad_type,
            type_geom=geom_type,
            offset_x=self._pedbpadstack._pedb._value_setter(offsetx),
            offset_y=self._pedbpadstack._pedb._value_setter(offsety),
            rotation=self._pedbpadstack._pedb._value_setter(rotation),
            sizes=[self._pedbpadstack._pedb._value_setter(i) for i in params],
        )


class PadstackDef:
    """Manages EDB functionalities for a padstack.

    Parameters
    ----------
    edb_padstack :

    ppadstack : str
        Inherited AEDT object.

    Examples
    --------
    >>> from pyedb import Edb
    >>> edb = Edb("myedb", version="2026.1")
    >>> edb_padstack = edb.padstacks.definitions["MyPad"]
    """

    def __init__(self, pedb, edb_object):
        self.core = edb_object
        self._pedb = pedb
        self._pad_by_layer = {}
        self._antipad_by_layer = {}
        self._thermalpad_by_layer = {}
        self._bounding_box = []

    @property
    def id(self) -> int:
        """Padstack definition ID."""
        return self.core.id

    @property
    def is_null(self):
        """Check if the padstack definition is null."""
        return self.core.is_null

    @classmethod
    def create(cls, edb, name: str):
        """Create a new padstack definition."""
        padstack_def = CorePadstackDef.create(edb.db, name)
        return cls(edb, padstack_def)

    @property
    def instances(self) -> list[PadstackInstance]:
        """Definitions Instances.

        Returns
        -------
        List[:class:`PadstackInstance <pyedb.grpc.database.primitive.padstack_instance.PadstackInstance>`]
            Dict of PadstackInstance objects.
        """
        return [
            j
            for j in list(self._pedb.padstacks.instances.values())
            if not j.is_null and j.padstack_def.name == self.core.name
        ]

    @property
    def name(self):
        """Padstack definition name."""
        return self.core.name

    @name.setter
    def name(self, value):
        self.core.name = value

    @property
    def data(self):
        """Padstack definition data.

        Returns
        -------
        PadstackDef
            Padstack definition data object.
        """
        return self.core.data

    @data.setter
    def data(self, value):
        self.core.data = value

    @property
    def layers(self) -> list[str]:
        """Layers.

        Returns
        -------
        list[str]
            List of layer names.
        """
        return self.core.data.layer_names

    @property
    def start_layer(self):
        """Starting layer.

        Returns
        -------
        str
            Name of the starting layer.
        """
        return self.layers[0]

    @property
    def via_start_layer(self):
        """Via starting layer.

        .deprecated
        Use: :method:`start_layer <pyedb.grpc.database.definition.padstack_def.PadstackDef.start_layer>`
        instead.

        Returns
        -------
        str
            Name of the via starting layer.
        """
        warnings.warn("via_start_layer is deprecated. Use start_layer instead.", DeprecationWarning)
        return self.start_layer

    @property
    def stop_layer(self):
        """Stopping layer.

        Returns
        -------
        str
            Name of the stopping layer.
        """
        return self.layers[-1]

    @property
    def via_stop_layer(self):
        """Via stop layer.

        .deprecated
        Use :method:`stop_layer <pyedb.grpc.database.definition.padstack_def.PadstackDef.stop_layer>`
        instead.

        Returns
        -------
        str
            Name of the via stop layer.
        """
        warnings.warn("via_stop_layer is deprecated. Use stop_layer instead.", DeprecationWarning)
        return self.stop_layer

    @property
    def material(self):
        """Return hole material name.

        Returns
        -------
        str
            Hole material name.
        """
        return self.core.data.material.value

    @material.setter
    def material(self, value):
        if isinstance(value, str):
            self.core.data.material = value

    @property
    def hole_diameter(self) -> float | None:
        """Hole diameter.

        Returns
        -------
        float
            Diameter value.

        """
        try:
            hole_parameter = self.core.data.get_hole_parameters()
            if hole_parameter[0].name.lower() == "padgeomtype_circle":
                return Value(hole_parameter[1][0])
        except:
            return 0.0

    @hole_diameter.setter
    def hole_diameter(self, value):
        hole_parameter = self.core.data.get_hole_parameters()
        if not isinstance(value, list):
            value = [self._pedb._value_setter(value)]
        else:
            value = [self._pedb._value_setter(p) for p in value]
        hole_size = value
        geometry_type = hole_parameter[0]
        hole_offset_x = hole_parameter[2]
        hole_offset_y = hole_parameter[3]
        if not isinstance(geometry_type, CorePolygonData):
            hole_rotation = hole_parameter[4]
            self.core.data.set_hole_parameters(
                offset_x=hole_offset_x,
                offset_y=hole_offset_y,
                rotation=hole_rotation,
                type_geom=geometry_type,
                sizes=hole_size,
            )

    @property
    def hole_type(self) -> float:
        """Holy type.

        Returns
        -------
        float
            hole type.

        """
        return Value(self.core.data.get_hole_parameters()[0])

    @property
    def edb_hole_type(self):
        """EDB hole type.

        Returns
        -------
        str
            Hole type.

        """
        return self.core.data.get_hole_parameters()[0]

    @property
    def hole_offset_x(self) -> float:
        """Hole offset for the X axis.

        Returns
        -------
        float
            Hole offset value for the X axis.
        """
        try:
            return Value(self.core.data.get_hole_parameters()[2])
        except:
            return 0.0

    @hole_offset_x.setter
    def hole_offset_x(self, value):
        hole_parameter = list(self.core.data.get_hole_parameters())
        hole_parameter[2] = self._pedb._value_setter(value)
        self.core.data.set_hole_parameters(
            offset_x=hole_parameter[2],
            offset_y=hole_parameter[3],
            rotation=hole_parameter[4],
            type_geom=hole_parameter[0],
            sizes=hole_parameter[1],
        )

    @property
    def hole_offset_y(self) -> float:
        """Hole offset for the Y axis.

        Returns
        -------
        float
            Hole offset value for the Y axis.
        """
        try:
            return Value(self.core.data.get_hole_parameters()[3])
        except:
            return 0.0

    @hole_offset_y.setter
    def hole_offset_y(self, value):
        hole_parameter = list(self.core.data.get_hole_parameters())
        hole_parameter[3] = self._pedb._value_setter(value)
        self.core.data.set_hole_parameters(
            offset_x=hole_parameter[2],
            offset_y=hole_parameter[3],
            rotation=hole_parameter[4],
            type_geom=hole_parameter[0],
            sizes=hole_parameter[1],
        )

    @property
    def hole_rotation(self) -> float:
        """Hole rotation.

        Returns
        -------
        float
            Value for the hole rotation.
        """
        try:
            return Value(self.core.data.get_hole_parameters()[4])
        except:
            return 0.0

    @hole_rotation.setter
    def hole_rotation(self, value):
        hole_parameter = list(self.core.data.get_hole_parameters())
        hole_parameter[4] = self._pedb._value_setter(
            value,
        )
        self.core.data.set_hole_parameters(
            offset_x=hole_parameter[2],
            offset_y=hole_parameter[3],
            rotation=hole_parameter[4],
            type_geom=hole_parameter[0],
            sizes=hole_parameter[1],
        )

    @property
    def pad_by_layer(self) -> dict[str, PadProperties]:
        """Pad by layer.

        Returns
        -------
        Dict[str, :class:`PadProperties <pyedb.grpc.database.definition.padstack_def.PadProperties>`]
            Dictionary with layer as key and PadProperties as value.
        """
        if not self._pad_by_layer:
            for layer in self.layers:
                try:
                    self._pad_by_layer[layer] = PadProperties(self.core.data, layer, CorePadType.REGULAR_PAD, self)
                except:
                    self._pad_by_layer[layer] = None
        return self._pad_by_layer

    @property
    def antipad_by_layer(self) -> dict[str, PadProperties]:
        """Antipad by layer.

        Returns
        -------
        Dict[str, :class:`PadProperties <pyedb.grpc.database.definition.padstack_def.PadProperties>`]
            Dictionary with layer as key and PadProperties as value.
        """
        if not self._antipad_by_layer:
            for layer in self.layers:
                try:
                    self._antipad_by_layer[layer] = PadProperties(self.core.data, layer, CorePadType.ANTI_PAD, self)
                except:
                    self._antipad_by_layer[layer] = None
        return self._antipad_by_layer

    @property
    def thermalpad_by_layer(self) -> dict[str, PadProperties]:
        """Thermal by layer.

        Returns
        -------
        Dict[str, :class:`PadProperties <pyedb.grpc.database.definition.padstack_def.PadProperties>`]
            Dictionary with layer as key and PadProperties as value.
        """
        if not self._thermalpad_by_layer:
            for layer in self.layers:
                try:
                    self._pad_by_layer[layer] = PadProperties(self.core.data, layer, CorePadType.THERMAL_PAD, self)
                except:
                    self._thermalpad_by_layer[layer] = None
        return self._thermalpad_by_layer

    @property
    def hole_plating_ratio(self) -> float:
        """Hole plating ratio.

        Returns
        -------
        float
            Percentage for the hole plating.
        """
        return Value(self.core.data.plating_percentage)

    @hole_plating_ratio.setter
    def hole_plating_ratio(self, ratio):
        self.core.data.plating_percentage = self._pedb._value_setter(ratio)

    @property
    def hole_plating_thickness(self) -> float:
        """Hole plating thickness.

        Returns
        -------
         float
            Thickness of the hole plating if present.
        """
        try:
            if len(self.core.data.get_hole_parameters()) > 0:
                return round((self.hole_diameter * self.hole_plating_ratio / 100) / 2, 6)
            else:
                return 0.0
        except:
            return 0.0

    @hole_plating_thickness.setter
    def hole_plating_thickness(self, value):
        """Hole plating thickness.

        Returns
        -------
        float
            Thickness of the hole plating if present.
        """
        hr = 200 * self._pedb.value(value).value / self.hole_diameter
        self.hole_plating_ratio = hr

    @property
    def hole_finished_size(self) -> float:
        """Finished hole size.

        Returns
        -------
        float
            Finished size of the hole (Total Size + PlatingThickess*2).
        """
        try:
            if len(self.core.data.get_hole_parameters()) > 0:
                return round(self.hole_diameter - (self.hole_plating_thickness * 2), 6)
            else:
                return 0.0
        except:
            return 0.0

    @property
    def hole_range(self) -> str | None:
        """Get hole range value from padstack definition.

        Returns
        -------
        str
            Possible returned values are ``"through"``, ``"begin_on_upper_pad"``,
            ``"end_on_lower_pad"``, ``"upper_pad_to_lower_pad"``, and ``"undefined"``.
        """
        try:
            return self.core.data.hole_range.name.lower()
        except:
            return None

    @hole_range.setter
    def hole_range(self, value):
        if isinstance(value, str):
            if value == "through":
                self.core.data.hole_range = CorePadstackHoleRange.THROUGH
            elif value == "begin_on_upper_pad":
                self.core.data.hole_range = CorePadstackHoleRange.BEGIN_ON_UPPER_PAD
            elif value == "end_on_lower_pad":
                self.core.data.hole_range = CorePadstackHoleRange.END_ON_LOWER_PAD
            elif value == "upper_pad_to_lower_pad":
                self.core.data.hole_range = CorePadstackHoleRange.UPPER_PAD_TO_LOWER_PAD
            else:  # pragma no cover
                self.core.data.hole_range = CorePadstackHoleRange.UNKNOWN_RANGE

    def convert_to_3d_microvias(
        self, convert_only_signal_vias=True, hole_wall_angle=15, delete_padstack_def=True
    ) -> bool:
        """Convert actual padstack instance to microvias 3D Objects with a given aspect ratio.

        Parameters
        ----------
        convert_only_signal_vias : bool, optional
            Either to convert only vias belonging to signal nets or all vias. Defaults is ``True``.
        hole_wall_angle : float, optional
            Angle of laser penetration in degrees. The angle defines the lowest hole diameter with this formula:
            HoleDiameter -2*tan(laser_angle* Hole depth). Hole depth is the height of the via (dielectric thickness).
            The default is ``15``.
            The lowest hole is ``0.75*HoleDepth/HoleDiam``.
        delete_padstack_def : bool, optional
            Whether to delete the padstack definition. The default is ``True``.
            If ``False``, the padstack definition is not deleted and the hole size is set to zero.

        Returns
        -------
            ``True`` when successful, ``False`` when failed.
        """

        if isinstance(self.core.data.get_hole_parameters()[0], CorePolygonData):
            self._pedb.logger.error("Microvias cannot be applied on vias using hole shape polygon")
            return False

        if self.start_layer == self.stop_layer:
            self._pedb.logger.error("Microvias cannot be applied when Start and Stop Layers are the same.")
        layout = self._pedb.active_layout
        layers = self._pedb.stackup.signal_layers
        layer_names = [i for i in list(layers.keys())]
        if convert_only_signal_vias:
            signal_nets = [i for i in list(self._pedb._pedb.nets.signal_nets.keys())]
        topl, topz, bottoml, bottomz = self._pedb.stackup.limits(True)
        if self.start_layer in layers:
            start_elevation = layers[self.start_layer].lower_elevation
        else:
            start_elevation = layers[self.instances[0].start_layer].lower_elevation
        if self.stop_layer in layers:
            stop_elevation = layers[self.stop_layer].upper_elevation
        else:
            stop_elevation = layers[self.instances[0].stop_layer].upper_elevation

        diel_thick = abs(start_elevation - stop_elevation)
        if self.hole_diameter:
            rad1 = self.hole_diameter / 2 - math.tan(hole_wall_angle * diel_thick * math.pi / 180)
            rad2 = self.hole_diameter / 2
        else:
            rad1 = 0.0
            rad2 = 0.0

        if start_elevation < (topz + bottomz) / 2:
            rad1, rad2 = rad2, rad1
        i = 0
        for via in self.instances:
            if convert_only_signal_vias and via.net_name in signal_nets or not convert_only_signal_vias:
                pos = via.position
                started = False
                if len(self.pad_by_layer[self.start_layer].parameters_values) == 0:
                    self._pedb.modeler.create_polygon(
                        self.pad_by_layer[self.start_layer].polygon_data,
                        layer_name=self.start_layer,
                        net_name=via.net_name,
                    )
                else:
                    Circle(self._pedb).create(
                        layout,
                        self.start_layer,
                        via.net,
                        self._pedb._value_setter(pos[0]),
                        self._pedb._value_setter(pos[1]),
                        self._pedb._value_setter(self.pad_by_layer[self.start_layer].parameters_values[0] / 2),
                    )
                if len(self.pad_by_layer[self.stop_layer].parameters_values) == 0:
                    self._pedb.modeler.create_polygon(
                        self.pad_by_layer[self.stop_layer].polygon_data,
                        layer_name=self.stop_layer,
                        net_name=via.net_name,
                    )
                else:
                    Circle(self._pedb).create(
                        layout,
                        self.stop_layer,
                        via.net,
                        self._pedb._value_setter(pos[0]),
                        self._pedb._value_setter(pos[1]),
                        self._pedb._value_setter(self.pad_by_layer[self.stop_layer].parameters_values[0] / 2),
                    )
                for layer_name in layer_names:
                    stop = ""
                    if layer_name == via.start_layer or started:
                        start = layer_name
                        stop = layer_names[layer_names.index(layer_name) + 1]
                        cloned_circle = Circle(self._pedb).create(
                            layout,
                            start,
                            via.net,
                            self._pedb._value_setter(pos[0]),
                            self._pedb._value_setter(pos[1]),
                            self._pedb._value_setter(rad1),
                        )
                        cloned_circle2 = Circle(self._pedb).create(
                            layout,
                            stop,
                            via.net,
                            self._pedb._value_setter(pos[0]),
                            self._pedb._value_setter(pos[1]),
                            self._pedb._value_setter(rad2),
                        )
                        s3d = CoreStructure3D.create(
                            layout.core, generate_unique_name("via3d_" + via.aedt_name.replace("via_", ""), n=3)
                        )
                        s3d.add_member(cloned_circle.core)
                        s3d.add_member(cloned_circle2.core)
                        if not self.core.data.material.value:
                            self._pedb.logger.warning(
                                f"Padstack definution {self.name} has no material defined.Defaulting to copper"
                            )
                            self.data.material = "copper"
                        s3d.set_material(self.core.data.material.value)
                        s3d.mesh_closure = CoreMeshClosure.ENDS_CLOSED
                        started = True
                        i += 1
                    if stop == via.stop_layer:
                        break
                if delete_padstack_def:  # pragma no cover
                    via.delete()
                else:  # pragma no cover
                    self.hole_diameter = 0.0
                    self._pedb.logger.info("Padstack definition kept, hole size set to 0.")

        self._pedb.logger.info(f"{i} Converted successfully to 3D Objects.")
        return True

    def split_to_microvias(self) -> list[PadstackInstance] | bool:
        """Convert actual padstack definition to multiple microvias definitions.

        Returns
        -------
        List[:class:`PadstackInstance <pyedb.grpc.database.primitive.padstack_instance.PadstackInstance>`]
        """
        from pyedb.grpc.database.primitive.padstack_instance import PadstackInstance

        if self.start_layer == self.stop_layer:
            self._pedb.logger.error("Microvias cannot be applied when Start and Stop Layers are the same.")
        layout = self._pedb.active_layout
        layers = self._pedb.stackup.signal_layers
        layer_names = [i for i in list(layers.keys())]
        if abs(layer_names.index(self.start_layer) - layer_names.index(self.stop_layer)) < 2:
            self._pedb.logger.error(
                "Conversion can be applied only if padstack definition is composed by more than 2 layers."
            )
            return False
        started = False
        new_instances = []
        for layer_name in layer_names:
            stop = ""
            if layer_name == self.start_layer or started:
                start = layer_name
                stop = layer_names[layer_names.index(layer_name) + 1]
                new_padstack_name = f"MV_{self.name}_{start}_{stop}"
                included = [start, stop]
                new_padstack_definition = CorePadstackDef.create(self._pedb.db, new_padstack_name)
                new_padstack_definition.data.add_layers(included)
                for layer in included:
                    pl = self.pad_by_layer[layer]
                    new_padstack_definition.data.set_pad_parameters(
                        layer=layer,
                        pad_type=CorePadType.REGULAR_PAD,
                        offset_x=self._pedb._value_setter(
                            pl.offset_x,
                        ),
                        offset_y=self._pedb._value_setter(
                            pl.offset_y,
                        ),
                        rotation=self._pedb._value_setter(
                            pl.rotation,
                        ),
                        type_geom=pl._edb_geometry_type,
                        sizes=pl.parameters_values,
                    )
                    antipads = self.antipad_by_layer
                    if layer in antipads:
                        pl = antipads[layer]
                        new_padstack_definition.data.set_pad_parameters(
                            layer=layer,
                            pad_type=CorePadType.ANTI_PAD,
                            offset_x=self._pedb._value_setter(
                                pl.offset_x,
                            ),
                            offset_y=self._pedb._value_setter(pl.offset_y),
                            rotation=self._pedb._value_setter(pl.rotation),
                            type_geom=pl._edb_geometry_type,
                            sizes=pl.parameters_values,
                        )
                    thermal_pads = self.thermalpad_by_layer
                    if layer in thermal_pads:
                        pl = thermal_pads[layer]
                        new_padstack_definition.data.set_pad_parameters(
                            layer=layer,
                            pad_type=CorePadType.THERMAL_PAD,
                            offset_x=self._pedb._value_setter(
                                pl.offset_x,
                            ),
                            offset_y=self._pedb._value_setter(
                                pl.offset_y,
                            ),
                            rotation=self._pedb._value_setter(pl.rotation),
                            type_geom=pl._edb_geometry_type,
                            sizes=pl.parameters_values,
                        )
                new_padstack_definition.data.set_hole_parameters(
                    offset_x=self.hole_offset_x,
                    offset_y=self.hole_offset_y,
                    rotation=self.hole_rotation,
                    type_geom=self.edb_hole_type,
                    sizes=[self.hole_diameter],
                )
                new_padstack_definition.data.material = self.material
                new_padstack_definition.data.plating_percentage = self._pedb._value_setter(self.hole_plating_ratio)
                new_instances.append(PadstackDef(self._pedb, new_padstack_definition))
                started = True
            if self.stop_layer == stop:
                break
        i = 0
        for via in self.instances:
            for instance in new_instances:
                from_layer = self.core.data.layer_names[0]
                to_layer = self.core.data.layer_names[-1]
                from_layer = next(l for layer_name, l in self._pedb.stackup.layers.items() if l.name == from_layer)
                to_layer = next(l for layer_name, l in self._pedb.stackup.layers.items() if l.name == to_layer)
                padstack_instance = PadstackInstance.create(
                    layout=layout,
                    net=via.net,
                    name=generate_unique_name(instance.name),
                    padstack_definition=instance.name,
                    position_x=via.position[0],
                    position_y=via.position[1],
                    rotation=0.0,
                    top_layer=from_layer,
                    bottom_layer=to_layer,
                    solder_ball_layer=None,
                    layer_map="two_way",
                )
                padstack_instance.is_layout_pin = via.is_pin
                i += 1
            via.delete()
        self._pedb.logger.info("Created {} new microvias.".format(i))
        return new_instances

    def get_pad_parameters(self):
        """Pad parameters.

        Returns
        -------
        dict
            params = {
            'regular_pad': [
                {'layer_name': '1_Top', 'shape': 'circle', 'offset_x': '0.1mm', 'offset_y': '0',
                'rotation': '0', 'diameter': '0.5mm'}
            ],
            'anti_pad': [
                {'layer_name': '1_Top', 'shape': 'circle', 'offset_x': '0', 'offset_y': '0', 'rotation': '0',
                'diameter': '1mm'}
            ],
            'thermal_pad': [
                {'layer_name': '1_Top', 'shape': 'round90', 'offset_x': '0', 'offset_y': '0', 'rotation': '0',
                'inner': '1mm', 'channel_width': '0.2mm', 'isolation_gap': '0.3mm'},
            ],
            'hole': [
                {'layer_name': '1_Top', 'shape': 'circle', 'offset_x': '0', 'offset_y': '0', 'rotation': '0',
                 'diameter': '0.1499997mm'},
            ]
        }
        """

        pdef_data = self.core.data
        pad_type_list = [CorePadType.REGULAR_PAD, CorePadType.ANTI_PAD, CorePadType.THERMAL_PAD]
        data = {}
        for pad_type in pad_type_list:
            pad_type_name = str(pad_type.name)
            temp_list = []
            for lyr_name in pdef_data.layer_names:
                result = pdef_data.get_pad_parameters(lyr_name, pad_type)
                if len(result) < 5:
                    continue
                pad_shape, params, offset_x, offset_y, rotation = result
                pad_shape = str(pad_shape.name)
                pad_params = {}
                pad_params["layer_name"] = lyr_name
                pad_params["shape"] = pad_shape
                pad_params["offset_x"] = str(offset_x)
                pad_params["offset_y"] = str(offset_y)
                pad_params["rotation"] = str(rotation)

                for idx, i in enumerate(self.PAD_SHAPE_PARAMETERS[pad_shape.lower()]):
                    pad_params[i] = str(params[idx])
                temp_list.append(pad_params)
            data[pad_type_name] = temp_list
        return data

    def set_pad_parameters(self, param):
        pdef_data = self.core.data

        pad_type_list = [
            CorePadType.REGULAR_PAD,
            CorePadType.ANTI_PAD,
            CorePadType.THERMAL_PAD,
            CorePadType.HOLE,
        ]
        for pad_type in pad_type_list:
            pad_type_name = str(pad_type.name)
            rpp = param.get(pad_type_name, []) if param.get(pad_type_name, []) else param.get(pad_type_name.lower(), [])
            for _, layer_data in enumerate(rpp):
                # Get geometry type from kwargs
                p = layer_data.get("shape").upper()
                if not p.startswith("PADGEOMTYPE_"):
                    p = "PADGEOMTYPE_" + p
                temp_param = []

                # Handle Circle geometry type
                if p == CorePadGeometryType.PADGEOMTYPE_CIRCLE.name:
                    temp_param.append(layer_data["diameter"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_CIRCLE

                # Handle Square geometry type
                elif p == CorePadGeometryType.PADGEOMTYPE_SQUARE.name:
                    temp_param.append(layer_data["size"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_SQUARE

                elif p == CorePadGeometryType.PADGEOMTYPE_RECTANGLE.name:
                    temp_param.append(layer_data["x_size"])
                    temp_param.append(layer_data["y_size"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_RECTANGLE

                # Handle Oval geometry type
                elif p == CorePadGeometryType.PADGEOMTYPE_OVAL.name:
                    temp_param.append(layer_data["x_size"])
                    temp_param.append(layer_data["y_size"])
                    temp_param.append(layer_data["corner_radius"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_OVAL

                # Handle Bullet geometry type
                elif p == CorePadGeometryType.PADGEOMTYPE_BULLET.name:
                    temp_param.append(layer_data["x_size"])
                    temp_param.append(layer_data["y_size"])
                    temp_param.append(layer_data["corner_radius"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_BULLET

                # Handle Round45 geometry type
                elif p == CorePadGeometryType.PADGEOMTYPE_SQUARE45.name:
                    temp_param.append(layer_data["inner"])
                    temp_param.append(layer_data["channel_width"])
                    temp_param.append(layer_data["isolation_gap"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_SQUARE45

                # Handle Round90 geometry type
                elif p == CorePadGeometryType.PADGEOMTYPE_SQUARE90.name:
                    temp_param.append(layer_data["inner"])
                    temp_param.append(layer_data["channel_width"])
                    temp_param.append(layer_data["isolation_gap"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_SQUARE90
                elif p == CorePadGeometryType.PADGEOMTYPE_ROUND90.name:
                    temp_param.append(layer_data["inner"])
                    temp_param.append(layer_data["channel_width"])
                    temp_param.append(layer_data["isolation_gap"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_ROUND90
                elif p == CorePadGeometryType.PADGEOMTYPE_ROUND45.name:
                    temp_param.append(layer_data["inner"])
                    temp_param.append(layer_data["channel_width"])
                    temp_param.append(layer_data["isolation_gap"])
                    pad_shape = CorePadGeometryType.PADGEOMTYPE_ROUND45
                else:
                    continue

                # Set pad parameters for the current layer
                pdef_data.set_pad_parameters(
                    layer=layer_data["layer_name"],
                    pad_type=pad_type,
                    offset_x=self._pedb._value_setter(layer_data.get("offset_x", 0)),
                    offset_y=self._pedb._value_setter(layer_data.get("offset_y", 0)),
                    rotation=self._pedb._value_setter(layer_data.get("rotation", 0)),
                    type_geom=pad_shape,
                    sizes=temp_param,
                )
        self.core.data = pdef_data

    def get_hole_parameters(self):
        pdef_data = self.core.data
        result = pdef_data.get_hole_parameters()
        if len(result) == 0:
            return {}
        hole_shape, params, offset_x, offset_y, rotation = result
        hole_shape = str(hole_shape.name)

        hole_params = {}
        hole_params["shape"] = hole_shape
        for idx, i in enumerate(self.PAD_SHAPE_PARAMETERS[hole_shape.lower()]):
            hole_params[i] = str(params[idx])
        hole_params["offset_x"] = str(offset_x)
        hole_params["offset_y"] = str(offset_y)
        hole_params["rotation"] = str(rotation)
        return hole_params

    def set_hole_parameters(self, params):
        original_params = self.get_hole_parameters()
        pdef_data = self.core.data

        temp_param = []
        shape = params["shape"]
        if not shape.startswith("padgeomtype_"):
            shape = "padgeomtype_" + shape
        if shape == "padgeomtype_no_geometry":
            return  # .net api doesn't tell how to set no_geometry shape.
        for i in self.PAD_SHAPE_PARAMETERS[shape]:
            temp_param.append(self._pedb._value_setter(params[i]))
            pedb_shape = shape

        pdef_data.set_hole_parameters(
            self._pedb._value_setter(params.get("offset_x", original_params.get("offset_x", 0))),
            self._pedb._value_setter(params.get("offset_y", original_params.get("offset_y", 0))),
            self._pedb._value_setter(params.get("rotation", original_params.get("rotation", 0))),
            self.PAD_SHAPE_KEYS[shape],
            temp_param,
        )

        self.core.data = pdef_data

    def get_solder_parameters(self):
        pdef_data = self.core.data
        shape = pdef_data.solder_ball_shape
        diameter, mid_diameter = pdef_data.solder_ball_param
        try:
            placement = pdef_data.solder_ball_placement
        except ValueError:
            placement = ""
        material = pdef_data.solder_ball_material
        place = [i for i, j in self.SOLDER_PLACEMENT.items() if j == placement]
        place = place[0] if place else ""
        parameters = {
            "shape": [i for i, j in self.SOLDER_SHAPE_TYPE.items() if j == shape][0],
            "diameter": str(Value(diameter)),
            "mid_diameter": str(Value(mid_diameter)),
            "placement": place,
            "material": material,
        }
        return parameters

    def set_solder_parameters(self, parameters):
        pdef_data = self.core.data

        shape = parameters.get("shape", "no_solder_ball")
        diameter = parameters.get("diameter", "0.4mm")
        mid_diameter = parameters.get("mid_diameter", diameter)
        placement = parameters.get("placement", "above_padstack")
        material = parameters.get("material", None)

        pdef_data.solder_ball_shape = self.SOLDER_SHAPE_TYPE[shape]
        if not shape == "no_solder_ball":
            pdef_data.solder_ball_parameters = (
                self._pedb._value_setter(diameter),
                self._pedb._value_setter(mid_diameter),
            )
            pdef_data.solder_ball_param = (self._pedb._value_setter(diameter), self._pedb._value_setter(mid_diameter))
            pdef_data.solder_ball_placement = self.SOLDER_PLACEMENT[placement]
        if material:
            pdef_data.solder_ball_material = material

    PAD_SHAPE_PARAMETERS = {
        "padgeomtype_circle": ["diameter"],
        "padgeomtype_square": ["size"],
        "padgeomtype_rectangle": ["x_size", "y_size"],
        "padgeomtype_oval": ["x_size", "y_size", "corner_radius"],
        "padgeomtype_bullet": ["x_size", "y_size", "corner_radius"],
        "padgeomtype_round45": ["inner", "channel_width", "isolation_gap"],
        "padgeomtype_round90": ["inner", "channel_width", "isolation_gap"],
        "padgeomtype_no_geometry": [],
    }
    PAD_SHAPE_KEYS = {
        "padgeomtype_circle": CorePadGeometryType.PADGEOMTYPE_CIRCLE,
        "padgeomtype_square": CorePadGeometryType.PADGEOMTYPE_SQUARE,
        "padgeomtype_rectangle": CorePadGeometryType.PADGEOMTYPE_RECTANGLE,
        "padgeomtype_oval": CorePadGeometryType.PADGEOMTYPE_OVAL,
        "padgeomtype_bullet": CorePadGeometryType.PADGEOMTYPE_BULLET,
        "padgeomtype_round45": CorePadGeometryType.PADGEOMTYPE_ROUND45,
        "padgeomtype_round90": CorePadGeometryType.PADGEOMTYPE_ROUND90,
        "padgeomtype_no_geometry": CorePadGeometryType.PADGEOMTYPE_NO_GEOMETRY,
    }
    SOLDER_SHAPE_TYPE = {
        "no_solder_ball": SolderballShape.NO_SOLDERBALL,
        "cylinder": SolderballShape.SOLDERBALL_CYLINDER,
        "spheroid": SolderballShape.SOLDERBALL_SPHEROID,
    }
    SOLDER_PLACEMENT = {
        "above_padstack": SolderballPlacement.ABOVE_PADSTACK,
        "below_padstack": SolderballPlacement.BELOW_PADSTACK,
    }
    # TODO check if update layer name is needed.
