# Nvitop Multi-Server Monitor

다중 서버의 GPU 상태를 nvitop으로 모니터링하는 웹 기반 시스템입니다.

## 기능

- 각 서버에서 nvitop 데이터 실시간 수집
- 중앙 서버로 데이터 전송
- 웹 대시보드에서 모든 서버의 GPU 상태 확인
- 통계 및 사용자 정보 표시
- 관리자 페이지에서 사용자 이름 수동 지정
- WebSocket을 통한 실시간 업데이트

## 설치

```bash
cd nvitop-monitor
pip install -r requirements.txt
```

## 사용법

### 1. 중앙 서버 실행

```bash
# 백그라운드로 실행 (nohup 사용)
./start_server.sh

# 로그 확인
tail -f server.log

# 서버 중지
./stop_server.sh
```

기본적으로 `http://localhost:5000`에서 실행됩니다.
- 대시보드: http://localhost:5000
- 관리자 페이지: http://localhost:5000/admin

**같은 네트워크의 다른 기기에서 접속:**
서버 시작 시 표시되는 네트워크 IP 주소를 사용하세요.
예: `http://141.223.24.72:5000`

자세한 내용은 [NETWORK_ACCESS.md](NETWORK_ACCESS.md)를 참조하세요.

### 2. 각 서버에서 에이전트 실행

각 모니터링할 서버에서 다음 명령을 실행하세요:

```bash
# 백그라운드로 실행 (nohup 사용)
./start_agent.sh 서버이름 http://중앙서버주소:5000
# 예제:
./start_agent.sh server1 http://141.223.24.72:5000

# 로그 확인
tail -f agent_server1.log

# 에이전트 중지
./stop_agent.sh server1
```

**자세한 에이전트 설정 방법은 [AGENT_SETUP.md](AGENT_SETUP.md)를 참조하세요.**

### 3. 관리자 페이지에서 사용자 이름 지정

1. http://localhost:5000/admin 접속
2. 각 서버에 대해 사용자 이름 입력
3. 저장 버튼 클릭

## 데이터 수집 방식

에이전트는 다음 순서로 GPU 데이터를 수집합니다:
1. nvitop Python API (우선)
2. pynvml (fallback)
3. nvidia-smi (최종 fallback)

## 프로젝트 구조

```
nvitop-monitor/
├── agent/           # 에이전트 (각 서버에서 실행)
│   └── agent.py
├── server/          # 중앙 서버
│   ├── app.py       # Flask 서버
│   └── models.py    # 데이터베이스 모델
├── web/             # 웹 인터페이스
│   ├── templates/   # HTML 템플릿
│   └── static/      # CSS, JS
├── config/          # 설정 파일
└── data/            # 데이터베이스 (자동 생성)
```

## 요구사항

- Python 3.7+
- nvitop 또는 nvidia-smi
- 각 서버에서 중앙 서버로 네트워크 접근 가능
