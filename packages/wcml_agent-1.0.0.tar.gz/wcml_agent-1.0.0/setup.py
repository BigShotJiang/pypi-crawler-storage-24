#!/usr/bin/env python3
"""
Nvitop Monitor Agent Setup
pip 패키지로 배포하기 위한 setup.py (에이전트 전용)
"""

from setuptools import setup, find_packages
import os

# README 읽기
def read_readme():
    readme_path = "README.md"
    if os.path.exists(readme_path):
        with open(readme_path, "r", encoding="utf-8") as fh:
            return fh.read()
    return "Nvitop GPU Monitoring Agent"

# requirements-agent.txt 읽기 (에이전트 전용)
def read_requirements():
    req_path = "requirements-agent.txt"
    if os.path.exists(req_path):
        with open(req_path, "r", encoding="utf-8") as fh:
            return [line.strip() for line in fh if line.strip() and not line.startswith("#")]
    # Fallback to requirements.txt
    req_path = "requirements.txt"
    if os.path.exists(req_path):
        with open(req_path, "r", encoding="utf-8") as fh:
            return [line.strip() for line in fh if line.strip() and not line.startswith("#")]
    return []

setup(
    name="wcml-agent",
    version="1.0.0",
    description="Nvitop-based GPU monitoring agent for multi-server environments",
    long_description=read_readme(),
    long_description_content_type="text/markdown",
    author="WCML",
    author_email="wcml@example.com",
    url="https://github.com/yourusername/wcml-agent",
    packages=find_packages(include=["agent"]),  # 에이전트만 포함
    py_modules=[],
    install_requires=read_requirements(),
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "wcml-agent=agent.agent:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: System Administrators",
        "Topic :: System :: Monitoring",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    include_package_data=True,
    zip_safe=False,
)
