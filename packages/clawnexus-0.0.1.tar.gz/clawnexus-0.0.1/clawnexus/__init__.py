"""
ClawNexus — Identity registry for AI agents.

The primary ClawNexus package is distributed via npm:

    npm install -g clawnexus

Source code: https://github.com/SilverstreamsAI/ClawNexus
"""

__version__ = "0.0.1"
