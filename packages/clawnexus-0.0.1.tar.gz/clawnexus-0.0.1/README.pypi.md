# ClawNexus

Identity registry for AI agents — discover, name, and connect OpenClaw instances across networks.

## Installation

ClawNexus is a Node.js/TypeScript project. Install via npm:

```bash
npm install -g clawnexus
```

## Links

- **GitHub**: https://github.com/SilverstreamsAI/ClawNexus
- **npm**: https://www.npmjs.com/package/clawnexus
- **SDK**: https://www.npmjs.com/package/@clawnexus/sdk

This PyPI package is a namespace reservation. The real package lives on npm.
