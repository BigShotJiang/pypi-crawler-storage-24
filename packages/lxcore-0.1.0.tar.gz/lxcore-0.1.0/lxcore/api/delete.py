def delete(engine, key) -> bool:
    """
    Delete a record by key (tombstone).

    Parameters
    ----------
    key : str | bytes

    Returns
    -------
    bool
        True if the record was found and deleted, False if key did not exist.
    """
    if isinstance(key, str):
        key = key.encode()

    return engine.tombstone(key)