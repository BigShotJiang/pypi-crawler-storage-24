def read(engine, key):
    """
    Read a record by key.

    Parameters
    ----------
    key : str | bytes

    Returns
    -------
    bytes | None
        Raw value bytes, or None if the key does not exist.
    """
    if isinstance(key, str):
        key = key.encode()

    return engine.read(key)