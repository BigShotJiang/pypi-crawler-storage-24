def update(engine, key, value):
    """
    Update an existing record.

    Strategy
    --------
    1. If the new value is the same byte-length as the old one:
       overwrite in-place (zero disk amplification, fastest path).
    2. Otherwise: tombstone the old record and append a new one.

    Parameters
    ----------
    key   : str | bytes
    value : str | bytes

    Raises
    ------
    KeyError  if the key does not exist — use create() or write() instead.
    """
    if isinstance(key, str):
        key = key.encode()
    if isinstance(value, str):
        value = value.encode()

    if not engine.has(key):
        raise KeyError(f"Key not found: {key!r}  — use create() or write() to add new records.")

    # fast path: same-size in-place rewrite
    if engine.overwrite_value(key, value):
        return

    # slow path: tombstone + append
    engine.tombstone(key)
    engine.append(key, value)