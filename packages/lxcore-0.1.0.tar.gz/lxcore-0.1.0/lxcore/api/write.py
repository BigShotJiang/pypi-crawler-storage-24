def write(engine, key, value):
    """
    Write (upsert) a record.

    Creates the record if it does not exist.
    Overwrites silently if it does — no error raised.

    Parameters
    ----------
    key   : str | bytes
    value : str | bytes
    """
    if isinstance(key, str):
        key = key.encode()
    if isinstance(value, str):
        value = value.encode()

    if engine.has(key):
        # tombstone old entry, then append fresh
        engine.tombstone(key)

    engine.append(key, value)