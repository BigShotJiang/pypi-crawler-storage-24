import json

TYPE_RAW  = b'\x00'
TYPE_JSON = b'\x01'

_SUPPORTED = (dict, list, str, int, float, bool, type(None))


def encode(value) -> bytes:
    if isinstance(value, bytes):
        return TYPE_RAW + value
    if isinstance(value, _SUPPORTED):
        return TYPE_JSON + json.dumps(value, ensure_ascii=False).encode('utf-8')
    raise TypeError(
        f"Unsupported type: {type(value).__name__}. "
        f"Use bytes for raw data or dict/list/str/int/float/bool/None for auto-serialization."
    )


def decode(data: bytes):
    if not data:
        return data
    tag     = data[0:1]
    payload = data[1:]
    if tag == TYPE_RAW:
        return payload
    if tag == TYPE_JSON:
        return json.loads(payload.decode('utf-8'))
    return data