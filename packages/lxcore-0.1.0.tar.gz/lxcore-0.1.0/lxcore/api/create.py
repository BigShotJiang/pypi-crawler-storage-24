def create(engine, key, value):
    """
    Create a new record.

    Parameters
    ----------
    key   : str | bytes
    value : str | bytes

    Raises
    ------
    KeyError  if the key already exists in the database.
    """
    if isinstance(key, str):
        key = key.encode()
    if isinstance(value, str):
        value = value.encode()

    if engine.has(key):
        raise KeyError(f"Key already exists: {key!r}  — use write() to overwrite or update() to modify.")

    engine.append(key, value)