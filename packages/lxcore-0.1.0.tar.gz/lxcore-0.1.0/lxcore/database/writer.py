import struct
import zlib

MAGIC = b'LXDB'
VERSION = 1
FILE_HEADER_SIZE = 10

STATUS_LIVE = 0x01
STATUS_DEAD = 0x00

REC_HEADER_FMT  = '>BHI'
REC_HEADER_SIZE = struct.calcsize(REC_HEADER_FMT)  # 7
CRC_SIZE        = 4


def crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


def pack_record(key: bytes, value: bytes) -> bytes:
    header  = struct.pack(REC_HEADER_FMT, STATUS_LIVE, len(key), len(value))
    payload = header + key + value
    crc     = struct.pack('>I', crc32(payload))
    return payload + crc


def mfh() -> bytes: # <- make_file_header btw
    return MAGIC + struct.pack('>H', VERSION) + b'\x00' * 4


def rts(key_len: int, val_len: int) -> int: # <- record_total_size btw
    return REC_HEADER_SIZE + key_len + val_len + CRC_SIZE