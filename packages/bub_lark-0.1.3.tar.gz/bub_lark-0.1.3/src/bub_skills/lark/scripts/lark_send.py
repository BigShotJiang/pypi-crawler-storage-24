#!/usr/bin/env python3

from __future__ import annotations

import argparse
import asyncio
import json
import sys

from bub.channels.message import ChannelMessage
from bub_lark.channel import LarkChannel


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Send a Lark / Feishu message using Bub's native Lark adapter.")
    parser.add_argument("--chat-id", required=True, help="Target Lark chat_id / open_id / union_id")
    parser.add_argument(
        "--kind",
        default="send_message",
        choices=["send_message", "reply_message", "edit_message", "update_card"],
        help="Outbound action kind",
    )
    parser.add_argument(
        "--content-type",
        default="text",
        choices=["text", "rich_text", "card", "image", "file", "audio"],
        help="Outbound content type",
    )
    parser.add_argument("--message", help="Message text content")
    parser.add_argument("--message-id", help="Target message id for edit / update flows")
    parser.add_argument("--reply-to-message-id", help="Reply target message id")
    parser.add_argument("--card-json", help="Interactive card JSON object")
    parser.add_argument("--attachment", help="Attachment path or data URL for image/file/audio sends")
    return parser.parse_args()


def _card_from_json(raw: str | None) -> dict[str, object] | None:
    if raw is None:
        return None
    data = json.loads(raw)
    if not isinstance(data, dict):
        raise TypeError("--card-json must decode to a JSON object")
    return data


async def _main_async(args: argparse.Namespace) -> None:
    channel = LarkChannel(lambda message: None)
    message = ChannelMessage(
        session_id=f"lark:{args.chat_id}",
        channel="lark",
        chat_id=args.chat_id,
        content=args.message or "",
        context={
            "lark_kind": args.kind,
            "content_type": args.content_type,
            "message_id": args.message_id,
            "reply_to_message_id": args.reply_to_message_id,
            "card": _card_from_json(args.card_json),
            "attachment": args.attachment,
        },
    )
    await channel.send(message)


def main() -> int:
    args = _parse_args()
    try:
        asyncio.run(_main_async(args))
    except Exception as exc:
        print(f"lark send failed: {exc}", file=sys.stderr)
        return 1
    print("lark action sent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
