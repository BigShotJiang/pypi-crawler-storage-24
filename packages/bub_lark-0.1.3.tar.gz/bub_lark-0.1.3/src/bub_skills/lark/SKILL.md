---
name: lark
description: |
  Lark / Feishu communication skill for Bub. Use when Bub needs to send
  proactive Lark messages, update an existing Lark message, or send a Lark
  interactive card outside the ordinary inbound reply path.
metadata:
  channel: lark
---

# Lark Skill

Agent-facing execution guide for proactive Lark / Feishu outbound communication.

Assumption: the relevant `BUB_LARK_*` environment variables are already configured.

## Required Inputs

- `chat_id` for proactive sends
- message content or card payload
- `message_id` for edit / card update flows

## Execution Policy

1. Prefer Bub's native reply path for ordinary replies on inbound `lark` sessions.
2. Use `lark_send.py` for proactive notifications or explicit update flows.
3. For card updates, pass `--kind update_card --message-id <id> --card-json ...`.
4. For image / file / audio sends, provide `--attachment` and an appropriate `--content-type`.

## Examples

```bash
uv run ./scripts/lark_send.py --chat-id oc_xxx --message "hello from Bub"
uv run ./scripts/lark_send.py --chat-id oc_xxx --kind update_card --message-id om_xxx --card-json '{"config":{"wide_screen_mode":true}}'
```
