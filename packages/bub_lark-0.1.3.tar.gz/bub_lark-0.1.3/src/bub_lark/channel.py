from __future__ import annotations

import asyncio
import base64
import contextlib
import json
import mimetypes
import re
import tempfile
import threading
import time
import uuid
from dataclasses import dataclass
from html import unescape
from pathlib import Path
from typing import Any, Literal

from aiohttp import web
from bub.channels.base import Channel
from bub.channels.message import ChannelMessage, MediaItem
from bub.types import MessageHandler
from lark_oapi.api.contact.v3.model.get_user_request import GetUserRequest
from lark_oapi.api.im.v1.model.create_file_request import CreateFileRequest
from lark_oapi.api.im.v1.model.create_file_request_body import CreateFileRequestBody
from lark_oapi.api.im.v1.model.create_image_request import CreateImageRequest
from lark_oapi.api.im.v1.model.create_image_request_body import CreateImageRequestBody
from lark_oapi.api.im.v1.model.create_message_request import CreateMessageRequest
from lark_oapi.api.im.v1.model.create_message_request_body import CreateMessageRequestBody
from lark_oapi.api.im.v1.model.get_message_resource_request import GetMessageResourceRequest
from lark_oapi.api.im.v1.model.p2_im_message_receive_v1 import P2ImMessageReceiveV1
from lark_oapi.api.im.v1.model.patch_message_request import PatchMessageRequest
from lark_oapi.api.im.v1.model.patch_message_request_body import PatchMessageRequestBody
from lark_oapi.api.im.v1.model.reply_message_request import ReplyMessageRequest
from lark_oapi.api.im.v1.model.reply_message_request_body import ReplyMessageRequestBody
from lark_oapi.client import Client as LarkOpenAPIClient
from lark_oapi.core.enum import LogLevel
from lark_oapi.core.model import RawRequest
from lark_oapi.event.dispatcher_handler import EventDispatcherHandler
from loguru import logger
from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from bub_lark.markdown_renderer import MarkdownCardRenderer

type LarkConnectionMode = Literal["websocket", "webhook", "auto"]
type LarkDomainPreset = Literal["feishu", "lark"]
type LarkSendKind = Literal["send_message", "reply_message", "edit_message", "update_card"]
type LarkContentType = Literal["text", "rich_text", "card", "image", "file", "audio"]

MARKDOWNISH_RE = re.compile(r"(^|\n)(#{1,6}\s|[-*+]\s|\d+\.\s)|```|\[[^\]]+\]\([^)]+\)")
LINK_RE = re.compile(r"\[([^\]]+)\]\(([^)]+)\)")
CODE_FENCE_RE = re.compile(r"^\s*```")
FILE_NAME_RE = re.compile(r"(?P<name>[A-Za-z0-9._-]+\.[A-Za-z0-9._-]+)")
PATHISH_RE = re.compile(r"([A-Za-z]:[\\/]|/)[^ \t\n\r`)]{3,}")
_MARKDOWN_RENDERER = MarkdownCardRenderer()
CODE_LINE_RE = re.compile(
    r"^\s*(from\s+\S+\s+import\s+|import\s+\S+|class\s+\w+|async\s+def\s+\w+|def\s+\w+|return\b|raise\b|await\b|const\s+\w+|let\s+\w+|var\s+\w+|function\s+\w+|type\s+\w+\s*=|interface\s+\w+|enum\s+\w+|package\s+\w+|public\s+class\s+\w+|#include\b)"
)
COMMENT_LINE_RE = re.compile(r"^\s*(#|//|/\*|\* |\"\"\"|''')")
MARKDOWN_STRUCTURE_RE = re.compile(r"^\s*(#{1,6}\s|[-*+]\s|\d+\.\s|>\s)")
PROSE_PUNCTUATION = {
    0xFF0C,
    0x3002,
    0xFF01,
    0xFF1F,
    0xFF1B,
    0xFF1A,
    0xFF08,
    0xFF09,
    0x3010,
    0x3011,
    0x201C,
    0x201D,
}


@dataclass(frozen=True, slots=True)
class SenderInfo:
    sender_id: str
    id_kind: str
    display_name: str | None = None
    open_id: str | None = None
    user_id: str | None = None
    union_id: str | None = None
    tenant_key: str | None = None
    sender_type: str | None = None


class LarkSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="BUB_LARK_", extra="ignore", env_file=".env")

    app_id: str = Field(default="", description="Lark / Feishu app id.")
    app_secret: str = Field(default="", description="Lark / Feishu app secret.")
    domain: LarkDomainPreset = Field(default="feishu", description="Open Platform domain preset: feishu or lark.")
    api_base: str = Field(default="", description="Optional Open Platform base URL override.")
    connection_mode: LarkConnectionMode = Field(
        default="auto", description="Event delivery mode: websocket, webhook, or auto."
    )
    verification_token: str = Field(default="", description="Webhook verification token.")
    encrypt_key: str = Field(default="", description="Webhook encrypt key.")
    webhook_host: str = Field(default="127.0.0.1", description="Webhook listener host.")
    webhook_port: int = Field(default=8080, description="Webhook listener port.")
    webhook_path: str = Field(default="/lark/events", description="Webhook callback path.")
    allow_users: str | None = Field(
        default=None, description="Comma-separated allowlist of sender ids (open_id, user_id, union_id)."
    )
    allow_chats: str | None = Field(default=None, description="Comma-separated allowlist of chat ids.")
    auto_reconnect: bool = Field(default=True, description="Reconnect the websocket client on disconnect.")
    ready_timeout_seconds: float = Field(default=5.0, description="Seconds to wait for the websocket worker.")
    download_max_bytes: int = Field(default=2 * 1024 * 1024, description="Maximum resource bytes to inline.")
    debug_outbound: bool = Field(default=False, description="Log full outbound render payloads for debugging.")
    resolve_sender_profile: bool = Field(
        default=True,
        description="Resolve sender names through contact user lookup when message events only include ids.",
    )
    sender_cache_ttl_seconds: float = Field(
        default=300.0,
        description="Seconds to cache sender profile lookups by open_id/user_id/union_id.",
    )

    @property
    def allow_user_set(self) -> set[str]:
        return {item.strip() for item in (self.allow_users or "").split(",") if item.strip()}

    @property
    def allow_chat_set(self) -> set[str]:
        return {item.strip() for item in (self.allow_chats or "").split(",") if item.strip()}

    @property
    def base_url(self) -> str:
        if self.api_base:
            return self.api_base.rstrip("/")
        if self.domain == "lark":
            return "https://open.larksuite.com"
        return "https://open.feishu.cn"

    @property
    def effective_connection_mode(self) -> Literal["websocket", "webhook"]:
        if self.connection_mode != "auto":
            return self.connection_mode
        return "webhook" if self.domain == "lark" else "websocket"


class LarkChannel(Channel):
    name = "lark"

    def __init__(self, on_receive: MessageHandler) -> None:
        self._on_receive = on_receive
        self._settings = LarkSettings()
        self._api_client: LarkOpenAPIClient | None = None
        self._runtime_loop: asyncio.AbstractEventLoop | None = None
        self._worker_thread: threading.Thread | None = None
        self._worker_loop: asyncio.AbstractEventLoop | None = None
        self._worker_client: Any = None
        self._worker_ready = threading.Event()
        self._worker_error: Exception | None = None
        self._runner: web.AppRunner | None = None
        self._site: web.BaseSite | None = None
        self._dispatcher: EventDispatcherHandler | None = None
        self._sender_profile_cache: dict[tuple[str, str], tuple[float, dict[str, str | None]]] = {}
        self._sender_profile_lock = threading.Lock()

    @property
    def needs_debounce(self) -> bool:
        return True

    async def start(self, stop_event: asyncio.Event) -> None:
        self._runtime_loop = asyncio.get_running_loop()
        if not (self._settings.app_id and self._settings.app_secret):
            logger.info("lark.start configured=false")
            return
        mode = self._settings.effective_connection_mode
        logger.info("lark.start mode={} domain={}", mode, self._settings.domain)
        if mode == "webhook":
            await self._start_webhook()
            return
        await self._start_websocket()

    async def stop(self) -> None:
        if self._runner is not None:
            await self._runner.cleanup()
            self._runner = None
            self._site = None
            self._dispatcher = None
        if self._worker_client is not None and self._worker_loop is not None:
            self._worker_client._auto_reconnect = False
            future = asyncio.run_coroutine_threadsafe(self._worker_client._disconnect(), self._worker_loop)
            with contextlib.suppress(Exception):
                await asyncio.to_thread(future.result, 5.0)
        if self._worker_thread is not None:
            await asyncio.to_thread(self._worker_thread.join, 5.0)
        self._worker_thread = None
        self._worker_loop = None
        self._worker_client = None
        self._worker_ready.clear()
        self._worker_error = None
        logger.info("lark.stopped")

    async def send(self, message: ChannelMessage) -> None:
        if self._api_client is None and not (self._settings.app_id and self._settings.app_secret):
            raise RuntimeError("Lark app credentials are not configured.")
        await asyncio.to_thread(self._send_channel_message_sync, message)

    async def _start_websocket(self) -> None:
        self._worker_ready.clear()
        self._worker_error = None
        self._worker_thread = threading.Thread(target=self._run_websocket_worker, name="bub-lark-ws", daemon=True)
        self._worker_thread.start()
        await asyncio.to_thread(self._worker_ready.wait, self._settings.ready_timeout_seconds)
        if self._worker_error is not None:
            raise RuntimeError(f"Lark websocket worker failed: {self._worker_error}")
        if not self._worker_ready.is_set():
            logger.warning("lark.start websocket ready_timeout_seconds={}", self._settings.ready_timeout_seconds)

    def _run_websocket_worker(self) -> None:
        from lark_oapi.ws.client import Client as LarkWSClient
        from lark_oapi.ws.client import loop as ws_loop

        self._worker_loop = ws_loop
        dispatcher = self._build_dispatcher(validate_webhook=False)
        client = LarkWSClient(
            app_id=self._settings.app_id,
            app_secret=self._settings.app_secret,
            log_level=LogLevel.INFO,
            event_handler=dispatcher,
            domain=self._settings.base_url,
            auto_reconnect=self._settings.auto_reconnect,
        )
        self._worker_client = client
        self._worker_ready.set()
        try:
            client.start()
        except Exception as exc:  # pragma: no cover - exercised through integration runs
            self._worker_error = exc
            logger.opt(exception=True).error("lark.websocket_worker_failed")
            self._worker_ready.set()

    async def _start_webhook(self) -> None:
        self._dispatcher = self._build_dispatcher(validate_webhook=True)

        async def handle(request: web.Request) -> web.Response:
            if self._dispatcher is None:
                raise RuntimeError("Lark webhook dispatcher is not initialized")
            body = await request.read()
            raw = RawRequest()
            raw.uri = request.path_qs
            raw.headers = dict(request.headers)
            raw.body = body
            response = self._dispatcher.do(raw)
            headers = dict(response.headers)
            return web.Response(status=response.status_code, body=response.content, headers=headers)

        app = web.Application()
        app.router.add_post(self._settings.webhook_path, handle)
        self._runner = web.AppRunner(app)
        await self._runner.setup()
        self._site = web.TCPSite(self._runner, host=self._settings.webhook_host, port=self._settings.webhook_port)
        await self._site.start()
        logger.info(
            "lark.webhook_started host={} port={} path={}",
            self._settings.webhook_host,
            self._settings.webhook_port,
            self._settings.webhook_path,
        )

    def _build_dispatcher(self, *, validate_webhook: bool) -> EventDispatcherHandler:
        encrypt_key = self._settings.encrypt_key if validate_webhook else ""
        verification_token = self._settings.verification_token if validate_webhook else ""
        builder = EventDispatcherHandler.builder(encrypt_key, verification_token, level=LogLevel.WARNING)
        builder.register_p2_im_message_receive_v1(self._handle_message_event)
        builder.register_p2_im_chat_access_event_bot_p2p_chat_entered_v1(self._handle_bot_entered_event)
        return builder.build()

    @staticmethod
    def _handle_bot_entered_event(payload: Any) -> None:
        logger.info("lark.bot_p2p_chat_entered")

    def _handle_message_event(self, payload: P2ImMessageReceiveV1) -> None:
        event = getattr(payload, "event", None)
        message = getattr(event, "message", None) if event is not None else None
        logger.info(
            "lark.event_received message_id={} message_type={} chat_id={}",
            _string_or_none(getattr(message, "message_id", None)),
            _string_or_none(getattr(message, "message_type", None)),
            _string_or_none(getattr(message, "chat_id", None)),
        )
        if self._runtime_loop is None:
            return
        future = asyncio.run_coroutine_threadsafe(self._handle_event(payload), self._runtime_loop)
        future.add_done_callback(self._log_future_error)

    @staticmethod
    def _log_future_error(future: asyncio.Future[None]) -> None:
        try:
            future.result()
        except Exception:
            logger.opt(exception=True).error("lark.event_handler_failed")

    async def _handle_event(self, payload: P2ImMessageReceiveV1) -> None:
        message = await self._build_message(payload)
        if message is None:
            return
        await self._on_receive(message)

    async def _build_message(self, payload: P2ImMessageReceiveV1 | dict[str, Any]) -> ChannelMessage | None:
        event = _field(payload, "event")
        if event is None:
            return None
        message = _field(event, "message")
        sender = _field(event, "sender")
        if message is None:
            return None
        if not self._is_allowed(message, sender):
            return None
        chat_id = str(_field(message, "chat_id") or "default")
        message_id = _string_or_none(_field(message, "message_id"))
        content_text, media = await self._parse_content(message)
        if not content_text.strip() and not media:
            return None
        sender_info = await self._resolve_sender_info(sender)
        thread_id = _thread_id_from_message(message)
        context: dict[str, Any] = {
            "account_id": self._settings.app_id or "default",
            "actor_id": sender_info.sender_id if sender_info is not None else None,
            "chat_type": _field(message, "chat_type"),
            "message_id": message_id,
            "message_type": _field(message, "message_type"),
            "parent_id": _string_or_none(_field(message, "parent_id")),
            "root_id": _string_or_none(_field(message, "root_id")),
            "surface": _normalize_lark_surface(_field(message, "chat_type")),
            "tenant_id": sender_info.tenant_key if sender_info is not None else None,
            "thread_id": thread_id,
        }
        context.update(_sender_prompt_context(sender_info))
        context = {key: value for key, value in context.items() if value is not None}
        return ChannelMessage(
            session_id=f"{self.name}:{chat_id}",
            channel=self.name,
            chat_id=chat_id,
            is_active=True,
            content=content_text,
            media=media,
            context=context,
        )

    async def _parse_content(self, message: Any) -> tuple[str, list[MediaItem]]:
        raw_content = str(_field(message, "content", "") or "")
        message_type = str(_field(message, "message_type", "unknown") or "unknown")
        mentions = list(_field(message, "mentions", []) or [])
        content = _loads_json(raw_content)
        media: list[MediaItem] = []

        if message_type == "text":
            text = _expand_lark_mentions(str(content.get("text") or ""), mentions) if isinstance(content, dict) else raw_content
            return text.strip(), media
        if message_type == "post":
            if isinstance(content, dict):
                return _flatten_post_content(content).strip() or "[Lark post message]", media
            return "[Lark post message]", media
        if message_type == "interactive":
            return _summarize_interactive_card(content), media
        if message_type in {"image", "file", "audio", "media", "sticker"}:
            if isinstance(content, dict):
                item = await self._media_item_from_content(message, message_type, content)
                if item is not None:
                    media.append(item)
            return _media_summary(message_type, content), media
        if message_type in {"share_chat", "share_user"}:
            return _share_summary(message_type, content), media
        return f"[Unsupported Lark message type: {message_type}]", media

    async def _media_item_from_content(
        self,
        message: dict[str, Any],
        message_type: str,
        content: dict[str, Any],
    ) -> MediaItem | None:
        file_key = _string_or_none(content.get("file_key") or content.get("image_key"))
        message_id = _string_or_none(message.get("message_id"))
        if file_key is None or message_id is None:
            return None
        resource_type = _resource_type_for_message_type(message_type)
        filename = _attachment_name(message_type, content)
        fallback_mime = _attachment_mime_for_message_type(message_type)
        try:
            payload, mime_type = await asyncio.to_thread(
                self._download_message_resource_sync,
                message_id,
                file_key,
                resource_type,
            )
        except Exception as exc:
            logger.warning(
                "lark.download_resource_failed message_id={} file_key={} type={} error={}",
                message_id,
                file_key,
                resource_type,
                exc,
            )
            return MediaItem(type=_media_type_for_message_type(message_type), mime_type=fallback_mime, filename=filename)
        if len(payload) > self._settings.download_max_bytes:
            return MediaItem(
                type=_media_type_for_message_type(message_type),
                mime_type=mime_type or fallback_mime,
                filename=filename,
            )

        async def fetch_cached() -> bytes:
            return payload

        return MediaItem(
            type=_media_type_for_message_type(message_type),
            mime_type=mime_type or fallback_mime,
            filename=filename,
            data_fetcher=fetch_cached,
        )

    def _download_message_resource_sync(self, message_id: str, file_key: str, resource_type: str) -> tuple[bytes, str | None]:
        client = self._api()
        request = (
            GetMessageResourceRequest.builder()
            .message_id(message_id)
            .file_key(file_key)
            .type(resource_type)
            .build()
        )
        response = client.im.v1.message_resource.get(request)
        _ensure_response_success(response, "download_resource")
        payload = getattr(response, "file", None)
        if payload is None:
            raw = getattr(response, "raw", None)
            payload = getattr(raw, "content", None)
        if payload is None:
            raise RuntimeError("Lark resource response did not contain file bytes")
        raw = getattr(response, "raw", None)
        headers = getattr(raw, "headers", {}) if raw is not None else {}
        mime_type = headers.get("Content-Type") if isinstance(headers, dict) else None
        return bytes(payload), mime_type

    def _send_channel_message_sync(self, message: ChannelMessage) -> None:
        client = self._api()
        kind = _outbound_kind(message)
        match kind:
            case "send_message":
                self._send_message_sync(client, message)
            case "reply_message":
                self._reply_message_sync(client, message)
            case "edit_message":
                self._patch_message_sync(client, message, update_card=False)
            case "update_card":
                self._patch_message_sync(client, message, update_card=True)
            case _:
                logger.warning("lark.send unsupported message kind={}", kind)

    def _send_message_sync(self, client: LarkOpenAPIClient, message: ChannelMessage) -> None:
        if _is_media_message(message):
            self._send_media_and_follow_up_sync(client, message, reply_to=None)
            return
        msg_type, content = _resolve_outbound_payload(message, allow_markdown_upgrade=True)
        self._log_outbound_debug(message, msg_type, content, phase="send_message")
        request = (
            CreateMessageRequest.builder()
            .receive_id_type(_receive_id_type(message))
            .request_body(
                CreateMessageRequestBody.builder()
                .receive_id(message.chat_id)
                .msg_type(msg_type)
                .content(content)
                .uuid(uuid.uuid4().hex)
                .build()
            )
            .build()
        )
        response = client.im.v1.message.create(request)
        _ensure_response_success(response, "create_message")

    def _reply_message_sync(self, client: LarkOpenAPIClient, message: ChannelMessage) -> None:
        reply_to = _reply_to_message_id(message)
        if reply_to is None:
            self._send_message_sync(client, message)
            return
        if _is_media_message(message):
            self._send_media_and_follow_up_sync(client, message, reply_to=reply_to)
            return
        msg_type, content = _resolve_outbound_payload(message, allow_markdown_upgrade=True)
        self._log_outbound_debug(message, msg_type, content, phase="reply_message")
        request = (
            ReplyMessageRequest.builder()
            .message_id(reply_to)
            .request_body(
                ReplyMessageRequestBody.builder()
                .content(content)
                .msg_type(msg_type)
                .uuid(uuid.uuid4().hex)
                .build()
            )
            .build()
        )
        response = client.im.v1.message.reply(request)
        _ensure_response_success(response, "reply_message")

    def _patch_message_sync(self, client: LarkOpenAPIClient, message: ChannelMessage, *, update_card: bool) -> None:
        message_id = _target_message_id(message)
        if message_id is None:
            raise RuntimeError("Lark message patch requires a target message_id")
        msg_type, content = _resolve_outbound_payload(
            message,
            allow_markdown_upgrade=False,
            force_interactive=update_card,
        )
        self._log_outbound_debug(message, "interactive" if update_card else msg_type, content, phase="patch_message")
        request = (
            PatchMessageRequest.builder()
            .message_id(message_id)
            .request_body(PatchMessageRequestBody.builder().content(content).build())
            .build()
        )
        response = client.im.v1.message.patch(request)
        _ensure_response_success(response, "patch_message")

    def _send_media_and_follow_up_sync(
        self,
        client: LarkOpenAPIClient,
        message: ChannelMessage,
        *,
        reply_to: str | None,
    ) -> None:
        msg_type, content = _upload_media_content(client, message)
        self._log_outbound_debug(message, msg_type, content, phase="media_message")
        if reply_to is None:
            request = (
                CreateMessageRequest.builder()
                .receive_id_type(_receive_id_type(message))
                .request_body(
                    CreateMessageRequestBody.builder()
                    .receive_id(message.chat_id)
                    .msg_type(msg_type)
                    .content(content)
                    .uuid(uuid.uuid4().hex)
                    .build()
                )
                .build()
            )
            response = client.im.v1.message.create(request)
        else:
            request = (
                ReplyMessageRequest.builder()
                .message_id(reply_to)
                .request_body(
                    ReplyMessageRequestBody.builder()
                    .content(content)
                    .msg_type(msg_type)
                    .uuid(uuid.uuid4().hex)
                    .build()
                )
                .build()
            )
            response = client.im.v1.message.reply(request)
        _ensure_response_success(response, "send_media")
        follow_up_text = message.content.strip()
        if follow_up_text:
            follow_up = ChannelMessage(
                session_id=message.session_id,
                channel=message.channel,
                chat_id=message.chat_id,
                content=follow_up_text,
                context={
                    "lark_kind": "reply_message" if reply_to is not None else "send_message",
                    "reply_to_message_id": reply_to,
                },
            )
            if reply_to is None:
                self._send_message_sync(client, follow_up)
            else:
                self._reply_message_sync(client, follow_up)

    def _log_outbound_debug(self, message: ChannelMessage, msg_type: str, content: str, *, phase: str) -> None:
        if not self._settings.debug_outbound:
            return
        logger.info(
            "lark.outbound.debug phase={} kind={} chat_id={} message_id={} reply_to={} content_type={}",
            phase,
            _outbound_kind(message),
            message.chat_id,
            _target_message_id(message) or "",
            _reply_to_message_id(message) or "",
            _content_type(message),
        )
        logger.info("lark.outbound.debug raw_text=\n{}", message.content)
        logger.info("lark.outbound.debug final msg_type={} content=\n{}", msg_type, content)

    def _api(self) -> LarkOpenAPIClient:
        if self._api_client is None:
            self._api_client = (
                LarkOpenAPIClient.builder()
                .app_id(self._settings.app_id)
                .app_secret(self._settings.app_secret)
                .domain(self._settings.base_url)
                .log_level(LogLevel.WARNING)
                .build()
            )
        return self._api_client

    async def _resolve_sender_info(self, sender: Any) -> SenderInfo | None:
        sender_info = self._sender_info(sender)
        if sender_info is None or not self._settings.resolve_sender_profile:
            return sender_info
        return await asyncio.to_thread(self._enrich_sender_info_sync, sender_info)

    def _enrich_sender_info_sync(self, sender_info: SenderInfo) -> SenderInfo:
        lookup_kind, lookup_value = _sender_lookup_key(sender_info)
        if lookup_kind is None or lookup_value is None:
            return sender_info
        cached = self._get_cached_sender_profile(lookup_kind, lookup_value)
        if cached is not None:
            return _merge_sender_profile(sender_info, cached)
        try:
            profile = self._lookup_sender_profile_sync(lookup_kind, lookup_value)
        except Exception as exc:
            logger.warning(
                "lark.sender_profile_lookup_failed user_id_type={} sender_id={} error={}",
                lookup_kind,
                lookup_value,
                exc,
            )
            profile = {}
        self._store_sender_profile(lookup_kind, lookup_value, profile)
        return _merge_sender_profile(sender_info, profile)

    def _lookup_sender_profile_sync(self, user_id_type: str, user_id: str) -> dict[str, str | None]:
        client = self._api()
        request = GetUserRequest.builder().user_id(user_id).user_id_type(user_id_type).build()
        response = client.contact.v3.user.get(request)
        _ensure_response_success(response, "get_user")
        user = _field(getattr(response, "data", None), "user")
        if user is None:
            return {}
        display_name = _string_or_none(_field(user, "name")) or _string_or_none(_field(user, "nickname"))
        return {
            "display_name": display_name,
            "name": display_name,
            "open_id": _string_or_none(_field(user, "open_id")),
            "user_id": _string_or_none(_field(user, "user_id")),
            "union_id": _string_or_none(_field(user, "union_id")),
        }

    def _get_cached_sender_profile(self, lookup_kind: str, lookup_value: str) -> dict[str, str | None] | None:
        now = time.monotonic()
        with self._sender_profile_lock:
            cached = self._sender_profile_cache.get((lookup_kind, lookup_value))
            if cached is None:
                return None
            expires_at, profile = cached
            if expires_at <= now:
                self._sender_profile_cache.pop((lookup_kind, lookup_value), None)
                return None
            return dict(profile)

    def _store_sender_profile(self, lookup_kind: str, lookup_value: str, profile: dict[str, str | None]) -> None:
        ttl = self._settings.sender_cache_ttl_seconds
        if ttl <= 0:
            return
        expires_at = time.monotonic() + ttl
        keys = {(lookup_kind, lookup_value)}
        for key in ("open_id", "user_id", "union_id"):
            value = _string_or_none(profile.get(key))
            if value is not None:
                keys.add((key, value))
        with self._sender_profile_lock:
            for cache_key in keys:
                self._sender_profile_cache[cache_key] = (expires_at, dict(profile))

    def _is_allowed(self, message: dict[str, Any], sender: Any) -> bool:
        chat_id = _field(message, "chat_id")
        if self._settings.allow_chat_set and str(chat_id or "") not in self._settings.allow_chat_set:
            return False
        if not self._settings.allow_user_set:
            return True
        tokens: set[str] = set()
        sender_id = _field(sender, "sender_id")
        if sender_id is not None:
            for key in ("open_id", "user_id", "union_id"):
                sender_value = _string_or_none(_field(sender_id, key))
                if sender_value:
                    tokens.add(sender_value)
        sender_user_id = _string_or_none(_field(sender, "id"))
        if sender_user_id:
            tokens.add(sender_user_id)
        return bool(tokens & self._settings.allow_user_set)

    @staticmethod
    def _sender_info(sender: Any) -> SenderInfo | None:
        if sender is None:
            return None
        sender_id = _field(sender, "sender_id")
        open_id = _string_or_none(_field(sender_id, "open_id"))
        user_id = _string_or_none(_field(sender_id, "user_id"))
        union_id = _string_or_none(_field(sender_id, "union_id"))
        tenant_key = _string_or_none(_field(sender, "tenant_key"))
        sender_type = _string_or_none(_field(sender, "sender_type"))
        participant_id = open_id or user_id or union_id or _string_or_none(_field(sender, "id"))
        if participant_id is None:
            return None
        raw_id_kind = _string_or_none(_field(sender, "id_type"))
        if raw_id_kind is None and open_id:
            raw_id_kind = "open_id"
        id_kind = f"lark_{raw_id_kind or 'user_id'}"
        return SenderInfo(
            sender_id=participant_id,
            id_kind=id_kind,
            display_name=_string_or_none(_field(sender, "name")) or _string_or_none(_field(sender, "display_name")),
            open_id=open_id,
            user_id=user_id,
            union_id=union_id,
            tenant_key=tenant_key,
            sender_type=sender_type,
        )


def _sender_lookup_key(sender_info: SenderInfo) -> tuple[str | None, str | None]:
    if sender_info.open_id:
        return "open_id", sender_info.open_id
    if sender_info.user_id:
        return "user_id", sender_info.user_id
    if sender_info.union_id:
        return "union_id", sender_info.union_id
    if sender_info.id_kind == "lark_open_id":
        return "open_id", sender_info.sender_id
    if sender_info.id_kind == "lark_union_id":
        return "union_id", sender_info.sender_id
    if sender_info.id_kind == "lark_user_id":
        return "user_id", sender_info.sender_id
    return None, None


def _merge_sender_profile(sender_info: SenderInfo, profile: dict[str, str | None]) -> SenderInfo:
    if not profile:
        return sender_info
    return SenderInfo(
        sender_id=sender_info.sender_id,
        id_kind=sender_info.id_kind,
        display_name=_string_or_none(profile.get("display_name")) or sender_info.display_name,
        open_id=_string_or_none(profile.get("open_id")) or sender_info.open_id,
        user_id=_string_or_none(profile.get("user_id")) or sender_info.user_id,
        union_id=_string_or_none(profile.get("union_id")) or sender_info.union_id,
        tenant_key=sender_info.tenant_key,
        sender_type=sender_info.sender_type,
    )


def _sender_prompt_context(sender_info: SenderInfo | None) -> dict[str, Any]:
    if sender_info is None:
        return {}
    context: dict[str, Any] = {
        "sender_id": sender_info.sender_id,
        "sender_id_kind": sender_info.id_kind,
    }
    if sender_info.display_name:
        context["sender_name"] = sender_info.display_name
    if sender_info.open_id:
        context["sender_open_id"] = sender_info.open_id
    if sender_info.user_id:
        context["sender_user_id"] = sender_info.user_id
    if sender_info.union_id:
        context["sender_union_id"] = sender_info.union_id
    if sender_info.tenant_key:
        context["sender_tenant_key"] = sender_info.tenant_key
    if sender_info.sender_type:
        context["sender_type"] = sender_info.sender_type
    return context


def _normalize_lark_surface(chat_type: object) -> str:
    value = str(chat_type or "unknown")
    if value == "p2p":
        return "direct"
    if value == "group":
        return "group"
    return value


def _thread_id_from_message(message: Any) -> str | None:
    return (
        _string_or_none(_field(message, "thread_id"))
        or _string_or_none(_field(message, "root_id"))
        or _string_or_none(_field(message, "parent_id"))
    )


def _outbound_kind(message: ChannelMessage) -> LarkSendKind:
    raw_kind = _string_or_none(message.context.get("lark_kind"))
    if raw_kind in {"send_message", "reply_message", "edit_message", "update_card"}:
        return raw_kind
    if _reply_to_message_id(message):
        return "reply_message"
    return "send_message"


def _content_type(message: ChannelMessage) -> LarkContentType:
    raw = _string_or_none(message.context.get("content_type"))
    if raw in {"text", "rich_text", "card", "image", "file", "audio"}:
        return raw
    return "text"


def _reply_to_message_id(message: ChannelMessage) -> str | None:
    return _string_or_none(message.context.get("reply_to_message_id"))


def _target_message_id(message: ChannelMessage) -> str | None:
    return _string_or_none(message.context.get("message_id")) or _reply_to_message_id(message)


def _receive_id_type(message: ChannelMessage) -> str:
    if message.chat_id.startswith("ou_"):
        return "open_id"
    if message.chat_id.startswith("on_"):
        return "union_id"
    return "chat_id"


def _resolve_outbound_payload(
    message: ChannelMessage,
    *,
    allow_markdown_upgrade: bool,
    force_interactive: bool = False,
) -> tuple[str, str]:
    card = message.context.get("card")
    content_type = _content_type(message)
    if force_interactive or isinstance(card, dict) or content_type in {"card", "rich_text"}:
        return "interactive", _interactive_content(message)
    text = message.content
    if allow_markdown_upgrade and _should_upgrade_text_to_card(text):
        return "interactive", json.dumps(_markdown_card(text), ensure_ascii=False)
    return "text", json.dumps({"text": text}, ensure_ascii=False)


def _interactive_content(message: ChannelMessage) -> str:
    card = message.context.get("card")
    if isinstance(card, dict):
        return json.dumps(card, ensure_ascii=False)
    return json.dumps(_markdown_card(message.content), ensure_ascii=False)


def _should_upgrade_text_to_card(text: str) -> bool:
    stripped = text.strip()
    if not stripped:
        return False
    if _looks_like_document_style_reply(stripped):
        return True
    return ("\n" in stripped) or bool(MARKDOWNISH_RE.search(stripped))


def _upload_media_content(client: LarkOpenAPIClient, message: ChannelMessage) -> tuple[str, str]:
    content_type = _content_type(message)
    source = _attachment_source(message)
    file_path, mime_type, filename, cleanup_path = _resolve_attachment_source(source, content_type)
    try:
        if content_type == "image":
            with open(file_path, "rb") as handle:
                request = (
                    CreateImageRequest.builder()
                    .request_body(
                        CreateImageRequestBody.builder()
                        .image_type("message")
                        .image(handle)
                        .build()
                    )
                    .build()
                )
                response = client.im.v1.image.create(request)
            _ensure_response_success(response, "create_image")
            image_key = getattr(getattr(response, "data", None), "image_key", None)
            if not image_key:
                raise RuntimeError("Lark image upload returned no image_key")
            return "image", json.dumps({"image_key": image_key}, ensure_ascii=False)

        file_type = _lark_file_type(content_type, mime_type, filename)
        with open(file_path, "rb") as handle:
            request = (
                CreateFileRequest.builder()
                .request_body(
                    CreateFileRequestBody.builder()
                    .file_type(file_type)
                    .file_name(filename)
                    .file(handle)
                    .build()
                )
                .build()
            )
            response = client.im.v1.file.create(request)
        _ensure_response_success(response, "create_file")
        file_key = getattr(getattr(response, "data", None), "file_key", None)
        if not file_key:
            raise RuntimeError("Lark file upload returned no file_key")
        msg_type = "audio" if content_type == "audio" else "file"
        return msg_type, json.dumps({"file_key": file_key}, ensure_ascii=False)
    finally:
        if cleanup_path is not None:
            cleanup_path.unlink(missing_ok=True)


def _attachment_source(message: ChannelMessage) -> str:
    attachment = _string_or_none(message.context.get("attachment"))
    if attachment:
        return attachment
    source = message.content.strip()
    if not source:
        raise ValueError("Lark media messages require an attachment source")
    return source


def _resolve_attachment_source(
    source: str,
    content_type: str,
) -> tuple[str, str | None, str, Path | None]:
    if source.startswith("data:"):
        header, encoded = source.split(",", 1)
        mime_type = header[5:].split(";", 1)[0] if header.startswith("data:") else None
        extension = mimetypes.guess_extension(mime_type or "") or ".bin"
        with tempfile.NamedTemporaryFile(prefix="bub-lark-", suffix=extension, delete=False) as handle:
            handle.write(base64.b64decode(encoded))
            temp_path = Path(handle.name)
        return str(temp_path), mime_type, temp_path.name, temp_path
    if source.startswith("file://"):
        source = source.removeprefix("file://")
    path = Path(source).expanduser()
    if not path.exists():
        raise ValueError(f"Attachment path does not exist: {path}")
    mime_type = mimetypes.guess_type(path.name)[0]
    if content_type == "audio" and mime_type is None:
        mime_type = "audio/ogg"
    return str(path), mime_type, path.name, None


def _lark_file_type(content_type: str, mime_type: str | None, filename: str) -> str:
    if content_type == "audio":
        return "opus"
    guessed = (mime_type or "").lower()
    if "mp4" in guessed or filename.lower().endswith(".mp4"):
        return "mp4"
    return "stream"


def _ensure_response_success(response: Any, operation: str) -> None:
    success = getattr(response, "success", None)
    if callable(success) and success():
        return
    if getattr(response, "code", 0) == 0:
        return
    raise RuntimeError(f"Lark {operation} failed code={getattr(response, 'code', 'unknown')} msg={getattr(response, 'msg', '')}")


def _is_media_message(message: ChannelMessage) -> bool:
    return _content_type(message) in {"image", "file", "audio"}


def _media_type_for_message_type(message_type: str) -> Literal["image", "audio", "video", "document"]:
    return {
        "image": "image",
        "sticker": "image",
        "audio": "audio",
        "media": "video",
    }.get(message_type, "document")


def _loads_json(raw: str) -> Any:
    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        return raw


def _expand_lark_mentions(text: str, mentions: list[Any]) -> str:
    mention_names = []
    for mention in mentions:
        name = getattr(mention, "name", None)
        if name is None and isinstance(mention, dict):
            name = mention.get("name")
        mention_names.append(f"@{name}" if name else "@user")
    pattern = re.compile(r"@_user_\d+")
    for replacement in mention_names:
        text, count = pattern.subn(replacement, text, count=1)
        if count == 0:
            break
    return unescape(text)


def _flatten_post_content(content: dict[str, Any]) -> str:
    lines: list[str] = []
    for locale_body in content.values():
        if not isinstance(locale_body, dict):
            continue
        lines.extend(_post_title_lines(locale_body))
        blocks = locale_body.get("content")
        if not isinstance(blocks, list):
            continue
        for block in blocks:
            if not isinstance(block, list):
                continue
            parts = [_post_block_part(item) for item in block]
            line = " ".join(part for part in parts if part)
            if line:
                lines.append(line)
    return "\n".join(lines)


def _summarize_interactive_card(content: Any) -> str:
    if not isinstance(content, dict):
        return "[Lark interactive card]"
    titles: list[str] = []

    def walk(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"title", "text", "content", "plain_text"} and isinstance(item, str):
                    titles.append(item.strip())
                else:
                    walk(item)
        elif isinstance(value, list):
            for item in value:
                walk(item)

    walk(content)
    summary = " | ".join(part for part in titles if part)[:240]
    return f"[Lark interactive card] {summary}".strip()


def _media_summary(message_type: str, content: Any) -> str:
    if not isinstance(content, dict):
        return f"[Lark {message_type} message]"
    if message_type == "image":
        return "[Lark image]"
    if message_type == "sticker":
        return "[Lark sticker]"
    if message_type == "audio":
        duration = content.get("duration")
        return f"[Lark audio{f' {duration}ms' if duration else ''}]"
    if message_type == "media":
        file_name = content.get("file_name")
        return f"[Lark media: {file_name}]" if file_name else "[Lark media]"
    file_name = content.get("file_name")
    return f"[Lark file: {file_name}]" if file_name else "[Lark file]"


def _share_summary(message_type: str, content: Any) -> str:
    if not isinstance(content, dict):
        return f"[Lark {message_type}]"
    if message_type == "share_chat":
        return f"[Lark shared chat: {content.get('chat_name') or 'unknown'}]"
    return f"[Lark shared user: {content.get('user_name') or 'unknown'}]"


def _resource_type_for_message_type(message_type: str) -> str:
    if message_type == "image":
        return "image"
    if message_type == "audio":
        return "audio"
    if message_type == "media":
        return "media"
    if message_type == "sticker":
        return "image"
    return "file"


def _attachment_mime_for_message_type(message_type: str) -> str:
    return {
        "image": "image/*",
        "sticker": "image/*",
        "audio": "audio/*",
        "media": "video/*",
    }.get(message_type, "application/octet-stream")


def _attachment_name(message_type: str, content: dict[str, Any]) -> str:
    if name := _string_or_none(content.get("file_name")):
        return name
    extension = {
        "image": "png",
        "sticker": "png",
        "audio": "opus",
        "media": "mp4",
    }.get(message_type, "bin")
    return f"lark-{message_type}.{extension}"


def _string_or_none(value: object) -> str | None:
    if value is None:
        return None
    text = str(value)
    return text if text else None


def _field(obj: Any, name: str, default: Any = None) -> Any:
    if obj is None:
        return default
    if isinstance(obj, dict):
        return obj.get(name, default)
    return getattr(obj, name, default)


def _post_title_lines(locale_body: dict[str, Any]) -> list[str]:
    title = str(locale_body.get("title") or "").strip()
    return [title] if title else []


def _post_block_part(item: Any) -> str:
    if not isinstance(item, dict):
        return ""
    tag = str(item.get("tag") or "")
    if tag in {"text", "a", "at"}:
        return str(item.get("text") or item.get("href") or "").strip()
    if tag == "img":
        return "[image]"
    if tag == "media":
        return "[media]"
    return ""


def _card_title_and_lines(text: str) -> tuple[str, list[str]]:
    raw_lines = [line.rstrip() for line in text.splitlines()] or [text]
    lines = _trim_blank_edges(raw_lines)
    lines = _unwrap_outer_fenced_block(lines)
    lines = _maybe_strip_leading_line_numbers(lines)
    if not lines:
        return "Bub", [text or ""]
    first = next((line.strip() for line in lines if line.strip()), "")
    if not first:
        return "Bub", lines
    if _looks_like_intro_line(first):
        title = _title_from_intro_line(first)
        return title, lines
    if first.startswith("#"):
        title = first.lstrip("#").strip() or "Bub"
        remaining = lines[1:] or [title]
        return title, remaining
    title = _plain_text_title(first) or "Bub"
    remaining = lines[1:] or [first]
    return title, remaining


def _markdown_card(text: str) -> dict[str, Any]:
    title, lines = _card_title_and_lines(text)
    elements = _card_body_elements(lines)
    if not elements:
        fallback = "\n".join(_normalize_markdownish_line(line) for line in lines).strip() or text or ""
        elements = [{"tag": "markdown", "content": fallback}]
    return {
        "schema": "2.0",
        "config": {"wide_screen_mode": True},
        "header": {
            "template": _card_template_for_text(text),
            "title": {"tag": "plain_text", "content": title},
        },
        "body": {"elements": elements},
    }


def _normalize_markdownish_line(line: str) -> str:
    return line.rstrip()


def _card_body_elements(lines: list[str]) -> list[dict[str, str]]:
    if _should_render_body_as_code(lines):
        return _code_card_elements(lines)
    return _rich_markdown_card_elements(lines)


def _rich_markdown_card_elements(lines: list[str]) -> list[dict[str, str]]:
    working = _trim_blank_edges(lines)
    if not working:
        return []
    intro = working[0].strip() if working and _looks_like_intro_line(working[0].strip()) else None
    body_lines = working[1:] if intro is not None else working
    body_text = "\n".join(body_lines).strip()
    elements: list[dict[str, str]] = []
    if intro:
        elements.append({"tag": "markdown", "content": intro})
    if body_text:
        elements.extend(_MARKDOWN_RENDERER.render(body_text))
    return elements


def _code_card_elements(lines: list[str]) -> list[dict[str, str]]:
    working = _trim_blank_edges(lines)
    if not working:
        return []
    elements: list[dict[str, str]] = []
    cursor = 0
    intro = working[0].strip()
    if _looks_like_intro_line(intro):
        elements.append({"tag": "markdown", "content": intro})
        cursor = 1

    code_lines = [line.rstrip() for line in working[cursor:]]
    code_body = "\n".join(code_lines).strip()
    if not code_body:
        return elements

    language = _code_language_from_lines(working)
    fenced = f"```{language}\n{code_body}\n```" if language else f"```\n{code_body}\n```"
    elements.append({"tag": "markdown", "content": fenced})
    return elements


def _card_template_for_text(text: str) -> str:
    lowered = text.casefold()
    if "error" in lowered or "failed" in lowered or "exception" in lowered:
        return "red"
    if "warning" in lowered or "注意" in text:
        return "orange"
    if "done" in lowered or "success" in lowered or "完成" in text:
        return "green"
    return "blue"


def _plain_text_title(text: str) -> str:
    return LINK_RE.sub(r"\1", text).replace("`", "").strip()


def _looks_like_intro_line(text: str) -> bool:
    return bool(_extract_intro_file_name(text)) and (_ends_with_colon(text) or bool(PATHISH_RE.search(text)))


def _maybe_strip_leading_line_numbers(lines: list[str]) -> list[str]:
    numbered = sum(1 for line in lines if re.match(r"^\s*\d+\s+", line))
    if numbered < 3 or numbered < max(1, len(lines) // 2):
        return lines
    return [re.sub(r"^\s*\d+\s+", "", line, count=1) for line in lines]


def _title_from_intro_line(text: str) -> str:
    if match := _extract_intro_file_name(text):
        return match
    return "文件内容"


def _extract_intro_file_name(text: str) -> str | None:
    matches = FILE_NAME_RE.findall(text)
    if not matches:
        return None
    return matches[0]


def _is_markdown_filename(name: str | None) -> bool:
    if not name:
        return False
    lowered = name.casefold()
    return lowered.endswith((".md", ".markdown", ".mdx"))


def _should_render_body_as_code(lines: list[str]) -> bool:
    if not lines:
        return False
    intro = next((line.strip() for line in lines if line.strip()), "")
    file_name = _extract_intro_file_name(intro)
    if not file_name or _is_markdown_filename(file_name):
        return False
    body_lines = _body_lines_after_intro(lines)
    return _looks_like_raw_code_body(body_lines)


def _code_language_from_lines(lines: list[str]) -> str:
    intro = next((line.strip() for line in lines if line.strip()), "")
    file_name = _extract_intro_file_name(intro)
    if file_name is None:
        return ""
    suffix = Path(file_name).suffix.casefold()
    return {
        ".py": "python",
        ".js": "javascript",
        ".ts": "typescript",
        ".tsx": "tsx",
        ".jsx": "jsx",
        ".json": "json",
        ".toml": "toml",
        ".yml": "yaml",
        ".yaml": "yaml",
        ".sh": "bash",
        ".bash": "bash",
        ".zsh": "bash",
        ".md": "markdown",
        ".rs": "rust",
        ".go": "go",
        ".java": "java",
        ".kt": "kotlin",
        ".swift": "swift",
        ".rb": "ruby",
        ".php": "php",
        ".css": "css",
        ".scss": "scss",
        ".html": "html",
        ".xml": "xml",
        ".sql": "sql",
    }.get(suffix, suffix.removeprefix("."))


def _body_lines_after_intro(lines: list[str]) -> list[str]:
    working = _trim_blank_edges(lines)
    if not working:
        return []
    if _looks_like_intro_line(working[0].strip()):
        return working[1:]
    return working


def _looks_like_raw_code_body(lines: list[str]) -> bool:
    working = _trim_blank_edges(lines)
    if not working:
        return False
    if CODE_FENCE_RE.match(working[0].strip()):
        return True

    non_empty = [line.rstrip() for line in working if line.strip()]
    if not non_empty:
        return False

    head = non_empty[:12]
    numbered = sum(1 for line in head if re.match(r"^\s*\d+\s+", line))
    if numbered >= max(3, len(head) // 2):
        return True

    markdownish = sum(1 for line in head if MARKDOWN_STRUCTURE_RE.match(line.strip()))
    if markdownish >= 2:
        return False

    head_code_signals = sum(1 for line in head if _is_code_like_line(line))
    if head_code_signals >= 3:
        return True

    code_like = sum(1 for line in non_empty if _is_code_like_line(line))
    prose_like = sum(1 for line in non_empty if _is_prose_like_line(line))
    return code_like >= max(4, len(non_empty) // 3) and code_like > prose_like


def _is_code_like_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if CODE_LINE_RE.match(stripped) or COMMENT_LINE_RE.match(stripped):
        return True
    if stripped.endswith(("{", "}", "):", ");", "]", "],", "},", "()")):
        return True
    if "=" in stripped and not stripped.startswith(("-", "*")) and "==" not in stripped:
        return True
    return bool(stripped.count("(") and stripped.count(")") and stripped.count(":") <= 1)


def _is_prose_like_line(line: str) -> bool:
    stripped = line.strip()
    if not stripped:
        return False
    if MARKDOWN_STRUCTURE_RE.match(stripped):
        return True
    if any(ord(ch) in PROSE_PUNCTUATION for ch in stripped):
        return True
    return " " in stripped and not CODE_LINE_RE.match(stripped) and not COMMENT_LINE_RE.match(stripped)


def _ends_with_colon(text: str) -> bool:
    stripped = text.rstrip()
    return bool(stripped) and stripped[-1] in {":", chr(0xFF1A)}


def _looks_like_document_style_reply(text: str) -> bool:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    if len(lines) < 2:
        return False
    first = lines[0]
    rest = lines[1:]
    numbered_lines = sum(1 for line in rest[:8] if re.match(r"^\d+\s+", line))
    has_path = bool(PATHISH_RE.search(first))
    has_file = _extract_intro_file_name(first) is not None
    has_body_shape = numbered_lines >= 2 or any(CODE_FENCE_RE.match(line) for line in rest[:6]) or len(rest) >= 4
    return (has_file and (has_path or _ends_with_colon(first))) and has_body_shape


def _trim_blank_edges(lines: list[str]) -> list[str]:
    start = 0
    end = len(lines)
    while start < end and not lines[start].strip():
        start += 1
    while end > start and not lines[end - 1].strip():
        end -= 1
    return lines[start:end]


def _unwrap_outer_fenced_block(lines: list[str]) -> list[str]:
    if len(lines) < 3:
        return lines
    first_nonempty = next((idx for idx, line in enumerate(lines) if line.strip()), None)
    last_nonempty = next((idx for idx in range(len(lines) - 1, -1, -1) if lines[idx].strip()), None)
    if first_nonempty is None or last_nonempty is None or first_nonempty >= last_nonempty:
        return lines

    intro_index = first_nonempty
    intro_line = lines[intro_index]
    has_intro = _looks_like_intro_line(intro_line.strip())
    if has_intro:
        fence_start = next((idx for idx in range(intro_index + 1, len(lines)) if lines[idx].strip()), None)
    else:
        fence_start = intro_index
    if fence_start is None or fence_start >= len(lines):
        return lines

    opening = lines[fence_start].strip()
    closing = lines[last_nonempty].strip()
    if not CODE_FENCE_RE.match(opening):
        return lines
    if closing != "```":
        return lines

    inner = lines[fence_start + 1 : last_nonempty]
    if has_intro:
        return [intro_line, *inner]
    return inner
