from __future__ import annotations

from bub.channels.base import Channel
from bub.hookspecs import hookimpl
from bub.types import MessageHandler, State

LARK_SYSTEM_PROMPT = """\
For inbound conversations on Bub's Lark / Feishu native channel (`lark`), your final plain text answer will be routed automatically by Bub.
Do not use proactive Lark send scripts for an ordinary reply on an inbound Lark session unless you need a platform-native action like card updates or proactive notifications.
"""


class LarkPlugin:
    """External Bub plugin that provides the Lark / Feishu channel."""

    def __init__(self, framework: object) -> None:
        self.framework = framework

    @hookimpl
    def provide_channels(self, message_handler: MessageHandler) -> list[Channel]:
        from bub_lark.channel import LarkChannel

        return [LarkChannel(on_receive=message_handler)]

    @hookimpl
    def system_prompt(self, prompt: str | list[dict], state: State) -> str:
        return LARK_SYSTEM_PROMPT
