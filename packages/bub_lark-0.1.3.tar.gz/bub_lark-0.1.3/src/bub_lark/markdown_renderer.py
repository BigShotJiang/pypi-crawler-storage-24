from __future__ import annotations

from typing import Any

import mistune


class MarkdownCardRenderer:
    """Render markdown into small Feishu card markdown blocks."""

    def __init__(self) -> None:
        self._markdown = mistune.create_markdown(renderer="ast", plugins=["strikethrough", "table"])

    def render(self, text: str) -> list[dict[str, str]]:
        tokens = self._markdown(text)
        blocks = self._render_blocks(tokens)
        return [{"tag": "markdown", "content": block} for block in blocks if block.strip()]

    def _render_blocks(self, tokens: list[dict[str, Any]]) -> list[str]:
        blocks: list[str] = []
        for token in tokens:
            block = self._render_block(token)
            if not block:
                continue
            if isinstance(block, list):
                blocks.extend(item for item in block if item.strip())
            else:
                blocks.append(block)
        return blocks

    def _render_block(self, token: dict[str, Any]) -> str | list[str]:
        kind = token.get("type")
        if kind == "paragraph":
            return self._render_inlines(token.get("children", []))
        if kind == "block_text":
            return self._render_inlines(token.get("children", []))
        if kind == "heading":
            level = int(token.get("attrs", {}).get("level", 1))
            prefix = "#" * max(1, min(level, 6))
            return f"{prefix} {self._render_inlines(token.get('children', []))}".strip()
        if kind == "block_code":
            info = str(token.get("attrs", {}).get("info", "") or "").strip()
            raw = str(token.get("raw", "") or "")
            fence = f"```{info}".rstrip()
            return f"{fence}\n{raw.rstrip()}\n```"
        if kind == "block_quote":
            return self._render_quote(token.get("children", []))
        if kind == "list":
            return self._render_list(token)
        if kind == "thematic_break":
            return "---"
        if kind == "table":
            return self._render_table(token)
        if kind == "blank_line":
            return ""
        return token.get("raw", "") or ""

    def _render_inlines(self, children: list[dict[str, Any]]) -> str:
        parts: list[str] = []
        for child in children:
            child_type = child.get("type")
            if child_type == "text":
                parts.append(str(child.get("raw", "") or ""))
            elif child_type == "strong":
                parts.append(f"**{self._render_inlines(child.get('children', []))}**")
            elif child_type == "emphasis":
                parts.append(f"*{self._render_inlines(child.get('children', []))}*")
            elif child_type == "strikethrough":
                parts.append(f"~~{self._render_inlines(child.get('children', []))}~~")
            elif child_type == "link":
                label = self._render_inlines(child.get("children", []))
                url = str(child.get("attrs", {}).get("url", "") or "")
                parts.append(f"[{label}]({url})" if url else label)
            elif child_type == "codespan":
                parts.append(f"`{child.get('raw', '') or ''!s}`")
            elif child_type in {"linebreak", "softbreak"}:
                parts.append("\n")
            elif child_type == "image":
                alt = str(child.get("attrs", {}).get("alt", "") or child.get("alt", "") or "image")
                src = str(child.get("attrs", {}).get("url", "") or child.get("src", "") or "")
                parts.append(f"![{alt}]({src})" if src else f"[image: {alt}]")
            else:
                parts.append(str(child.get("raw", "") or ""))
        return "".join(parts).strip()

    def _render_quote(self, children: list[dict[str, Any]]) -> str:
        lines: list[str] = []
        for child in children:
            block = self._render_block(child)
            if isinstance(block, list):
                lines.extend(block)
            elif block:
                lines.append(block)
        return "\n".join(f"> {line}" if line else ">" for line in "\n".join(lines).splitlines())

    def _render_list(self, token: dict[str, Any]) -> list[str]:
        ordered = bool(token.get("attrs", {}).get("ordered", False))
        items = token.get("children", [])
        rendered: list[str] = []
        for index, item in enumerate(items, start=1):
            if item.get("type") != "list_item":
                continue
            lines = self._render_list_item_lines(item, ordered=ordered, index=index, indent=0)
            rendered.append("\n".join(lines))
        return rendered

    def _render_list_item_lines(
        self,
        item: dict[str, Any],
        *,
        ordered: bool,
        index: int,
        indent: int,
    ) -> list[str]:
        prefix = f"{index}. " if ordered else "- "
        pad = "  " * indent
        lines: list[str] = []
        first_line = True
        for child in item.get("children", []):
            if child.get("type") == "blank_line":
                continue
            if child.get("type") == "list":
                lines.extend(self._render_nested_list(child, indent=indent + 1))
                continue

            block_lines = self._flatten_block_lines(self._render_block(child))
            if not block_lines:
                continue
            for i, line in enumerate(block_lines):
                if first_line and i == 0:
                    lines.append(f"{pad}{prefix}{line}".rstrip())
                else:
                    lines.append(f"{pad}{' ' * len(prefix)}{line}".rstrip())
            first_line = False
        return lines or [f"{pad}{prefix}".rstrip()]

    def _render_nested_list(self, token: dict[str, Any], *, indent: int) -> list[str]:
        nested_ordered = bool(token.get("attrs", {}).get("ordered", False))
        nested_items = token.get("children", [])
        lines: list[str] = []
        for nested_index, nested_item in enumerate(nested_items, start=1):
            if nested_item.get("type") != "list_item":
                continue
            lines.extend(
                self._render_list_item_lines(
                    nested_item,
                    ordered=nested_ordered,
                    index=nested_index,
                    indent=indent,
                )
            )
        return lines

    @staticmethod
    def _flatten_block_lines(block: str | list[str]) -> list[str]:
        if isinstance(block, list):
            lines: list[str] = []
            for entry in block:
                lines.extend(entry.splitlines() or [""])
            return lines
        if block:
            return block.splitlines() or [""]
        return []

    def _render_table(self, token: dict[str, Any]) -> str:
        header: list[str] = []
        rows: list[list[str]] = []
        for child in token.get("children", []):
            child_type = child.get("type")
            if child_type == "table_head":
                header = self._render_table_row(child)
            elif child_type == "table_body":
                for row in child.get("children", []):
                    if row.get("type") == "table_row":
                        rows.append(self._render_table_row(row))
            elif child_type == "table_row":
                rows.append(self._render_table_row(child))
        if not header and rows:
            header = rows.pop(0)
        if not header:
            return ""
        divider = ["---"] * len(header)
        all_rows = [header, divider, *rows]
        return "\n".join("| " + " | ".join(row) + " |" for row in all_rows)

    def _render_table_row(self, token: dict[str, Any]) -> list[str]:
        values: list[str] = []
        for child in token.get("children", []):
            if child.get("type") in {"table_cell", "table_head_cell"}:
                values.append(self._render_inlines(child.get("children", [])))
        return values
