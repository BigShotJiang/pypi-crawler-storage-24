from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest
from bub.channels.message import ChannelMessage
from bub.framework import BubFramework

from bub_lark.channel import LarkChannel, _markdown_card
from bub_lark.plugin import LARK_SYSTEM_PROMPT, LarkPlugin


class _Response:
    def __init__(self, *, code: int = 0, msg: str = "", data: object | None = None, file: bytes | None = None) -> None:
        self.code = code
        self.msg = msg
        self.data = data
        self.file = file
        self.raw = SimpleNamespace(content=file, headers={"Content-Type": "image/png"} if file else {})

    def success(self) -> bool:
        return self.code == 0


def test_plugin_provides_lark_channel_and_prompt() -> None:
    plugin = LarkPlugin(BubFramework())

    def on_receive(_message) -> None:
        return None

    channels = plugin.provide_channels(on_receive)

    assert [channel.name for channel in channels] == ["lark"]
    assert isinstance(channels[0], LarkChannel)
    assert plugin.system_prompt(prompt="hello", state={}) == LARK_SYSTEM_PROMPT


@pytest.mark.asyncio
async def test_build_message_parses_text_event() -> None:
    channel = LarkChannel(lambda message: None)
    payload = {
        "event": {
            "sender": {"sender_id": {"open_id": "ou_sender", "user_id": "u_sender"}},
            "message": {
                "chat_id": "oc_123",
                "chat_type": "p2p",
                "message_id": "om_123",
                "message_type": "text",
                "content": json.dumps({"text": "hello"}),
            },
        }
    }

    result = await channel._build_message(payload)

    assert result is not None
    assert result.channel == "lark"
    assert result.chat_id == "oc_123"
    assert result.content == "hello"
    assert result.context["message_id"] == "om_123"
    assert result.context["sender_id"] == "ou_sender"
    assert result.context["sender_id_kind"] == "lark_open_id"
    assert result.context["surface"] == "direct"
    assert result.context["actor_id"] == "ou_sender"


@pytest.mark.asyncio
async def test_build_message_enriches_sender_name_and_caches_profile() -> None:
    class UserApi:
        def __init__(self) -> None:
            self.calls = 0

        def get(self, request):
            self.calls += 1
            assert request.user_id == "ou_sender"
            assert request.user_id_type == "open_id"
            return _Response(
                data=SimpleNamespace(
                    user=SimpleNamespace(
                        name="Alice",
                        open_id="ou_sender",
                        user_id="u_sender",
                        union_id="on_sender",
                    )
                )
            )

    user_api = UserApi()
    channel = LarkChannel(lambda message: None)
    channel._api_client = SimpleNamespace(contact=SimpleNamespace(v3=SimpleNamespace(user=user_api)))
    payload = {
        "event": {
            "sender": {"sender_id": {"open_id": "ou_sender"}},
            "message": {
                "chat_id": "oc_123",
                "chat_type": "group",
                "message_id": "om_123",
                "message_type": "text",
                "content": json.dumps({"text": "hello"}),
            },
        }
    }

    first = await channel._build_message(payload)
    second = await channel._build_message(payload)

    assert first is not None
    assert second is not None
    assert first.context["sender_name"] == "Alice"
    assert first.context["sender_open_id"] == "ou_sender"
    assert first.context["sender_user_id"] == "u_sender"
    assert first.context["sender_union_id"] == "on_sender"
    assert second.context["sender_name"] == "Alice"
    assert user_api.calls == 1


@pytest.mark.asyncio
async def test_build_message_continues_when_sender_profile_lookup_fails() -> None:
    class UserApi:
        def get(self, request):
            raise RuntimeError("boom")

    channel = LarkChannel(lambda message: None)
    channel._api_client = SimpleNamespace(contact=SimpleNamespace(v3=SimpleNamespace(user=UserApi())))
    payload = {
        "event": {
            "sender": {"sender_id": {"open_id": "ou_sender"}},
            "message": {
                "chat_id": "oc_123",
                "chat_type": "group",
                "message_id": "om_123",
                "message_type": "text",
                "content": json.dumps({"text": "hello"}),
            },
        }
    }

    result = await channel._build_message(payload)

    assert result is not None
    assert result.content == "hello"
    assert result.context["sender_id"] == "ou_sender"
    assert "sender_name" not in result.context


@pytest.mark.asyncio
async def test_build_message_parses_post_and_reduces_to_plain_text() -> None:
    channel = LarkChannel(lambda message: None)
    payload = {
        "event": {
            "message": {
                "chat_id": "oc_123",
                "chat_type": "group",
                "message_id": "om_123",
                "message_type": "post",
                "content": json.dumps(
                    {
                        "zh_cn": {
                            "title": "Daily",
                            "content": [
                                [{"tag": "text", "text": "hello"}],
                                [{"tag": "a", "text": "docs", "href": "https://example.com"}],
                            ],
                        }
                    }
                ),
            }
        }
    }

    result = await channel._build_message(payload)

    assert result is not None
    assert "Daily" in result.content
    assert "hello" in result.content
    assert "docs" in result.content
    assert result.context["surface"] == "group"


@pytest.mark.asyncio
async def test_build_message_downloads_image_attachment(monkeypatch: pytest.MonkeyPatch) -> None:
    channel = LarkChannel(lambda message: None)

    def fake_download(message_id: str, file_key: str, resource_type: str) -> tuple[bytes, str | None]:
        assert message_id == "om_123"
        assert file_key == "img_123"
        assert resource_type == "image"
        return b"png-bytes", "image/png"

    monkeypatch.setattr(channel, "_download_message_resource_sync", fake_download)
    payload = {
        "event": {
            "message": {
                "chat_id": "oc_123",
                "chat_type": "p2p",
                "message_id": "om_123",
                "message_type": "image",
                "content": json.dumps({"image_key": "img_123"}),
            }
        }
    }

    result = await channel._build_message(payload)

    assert result is not None
    assert result.content == "[Lark image]"
    assert len(result.media) == 1
    assert result.media[0].type == "image"
    assert result.media[0].mime_type == "image/png"
    assert result.media[0].data_fetcher is not None
    assert await result.media[0].data_fetcher() == b"png-bytes"


@pytest.mark.asyncio
async def test_build_message_keeps_file_media_when_download_fails(monkeypatch: pytest.MonkeyPatch) -> None:
    channel = LarkChannel(lambda message: None)

    def fail_download(message_id: str, file_key: str, resource_type: str) -> tuple[bytes, str | None]:
        raise RuntimeError("boom")

    monkeypatch.setattr(channel, "_download_message_resource_sync", fail_download)
    payload = {
        "event": {
            "message": {
                "chat_id": "oc_123",
                "chat_type": "group",
                "message_id": "om_123",
                "message_type": "file",
                "content": json.dumps({"file_key": "file_123", "file_name": "report.pdf"}),
            }
        }
    }

    result = await channel._build_message(payload)

    assert result is not None
    assert result.content == "[Lark file: report.pdf]"
    assert len(result.media) == 1
    assert result.media[0].type == "document"
    assert result.media[0].filename == "report.pdf"
    assert result.media[0].data_fetcher is None


@pytest.mark.asyncio
async def test_lark_channel_send_text_reply_edit_card_and_file(tmp_path: Path) -> None:
    events: list[tuple[str, object]] = []

    class MessageResource:
        pass

    class MessageApi:
        def create(self, request):
            events.append(("create", request.request_body))
            return _Response(data=SimpleNamespace(message_id="om_created"))

        def reply(self, request):
            events.append(("reply", request.request_body))
            return _Response(data=SimpleNamespace(message_id="om_reply"))

        def patch(self, request):
            events.append(("patch", request.request_body))
            return _Response()

    class ImageApi:
        def create(self, request):
            events.append(("image", request.request_body))
            return _Response(data=SimpleNamespace(image_key="img_uploaded"))

    class FileApi:
        def create(self, request):
            events.append(("file", request.request_body))
            return _Response(data=SimpleNamespace(file_key="file_uploaded"))

    fake_client = SimpleNamespace(
        im=SimpleNamespace(
            v1=SimpleNamespace(
                message=MessageApi(),
                image=ImageApi(),
                file=FileApi(),
                message_resource=MessageResource(),
            )
        )
    )
    channel = LarkChannel(lambda message: None)
    channel._api_client = fake_client
    channel._settings = channel._settings.model_copy(update={"app_id": "cli_x", "app_secret": "sec_y"})

    tmp_file = tmp_path / "upload.txt"
    tmp_file.write_text("hello", encoding="utf-8")

    await channel.send(ChannelMessage(session_id="lark:oc_123", channel="lark", chat_id="oc_123", content="hello"))
    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content="hi",
            context={"lark_kind": "reply_message", "reply_to_message_id": "om_parent"},
        )
    )
    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content="updated",
            context={"lark_kind": "edit_message", "message_id": "om_edit"},
        )
    )
    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content="",
            context={
                "lark_kind": "update_card",
                "message_id": "om_card",
                "content_type": "card",
                "card": {"config": {"wide_screen_mode": True}},
            },
        )
    )
    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content="see attachment",
            context={"content_type": "file", "attachment": str(tmp_file)},
        )
    )

    assert [item[0] for item in events] == ["create", "reply", "patch", "patch", "file", "create", "create"]
    assert events[0][1].msg_type == "text"
    assert events[1][1].msg_type == "text"
    assert events[2][1].content == json.dumps({"text": "updated"}, ensure_ascii=False)
    assert events[3][1].content == json.dumps({"config": {"wide_screen_mode": True}}, ensure_ascii=False)
    assert events[4][1].file_name == "upload.txt"
    assert events[5][1].msg_type == "file"
    assert events[6][1].msg_type == "text"


@pytest.mark.asyncio
async def test_lark_channel_upgrades_multiline_text_to_interactive_card() -> None:
    events: list[tuple[str, object]] = []

    class MessageApi:
        def create(self, request):
            events.append(("create", request.request_body))
            return _Response(data=SimpleNamespace(message_id="om_created"))

    fake_client = SimpleNamespace(im=SimpleNamespace(v1=SimpleNamespace(message=MessageApi())))
    channel = LarkChannel(lambda message: None)
    channel._api_client = fake_client
    channel._settings = channel._settings.model_copy(update={"app_id": "cli_x", "app_secret": "sec_y"})

    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content="# Summary\n- first item\n- second item\nSee [docs](https://example.com)",
        )
    )

    assert len(events) == 1
    body = events[0][1]
    assert body.msg_type == "interactive"
    payload = json.loads(body.content)
    assert payload["schema"] == "2.0"
    assert payload["header"]["title"]["content"] == "Summary"
    assert payload["body"]["elements"][0]["tag"] == "markdown"


@pytest.mark.asyncio
async def test_lark_card_title_uses_first_line_and_strips_code_fences() -> None:
    events: list[tuple[str, object]] = []

    class MessageApi:
        def create(self, request):
            events.append(("create", request.request_body))
            return _Response(data=SimpleNamespace(message_id="om_created"))

    fake_client = SimpleNamespace(im=SimpleNamespace(v1=SimpleNamespace(message=MessageApi())))
    channel = LarkChannel(lambda message: None)
    channel._api_client = fake_client
    channel._settings = channel._settings.model_copy(update={"app_id": "cli_x", "app_secret": "sec_y"})

    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content="当前项目 README.md 内容如下:\n```markdown\n[Bub](https://github.com/bubbuild/bub)\n```",
        )
    )

    body = events[0][1]
    payload = json.loads(body.content)
    assert payload["header"]["title"]["content"] == "README.md"
    elements = payload["body"]["elements"]
    assert elements[0]["content"] == "当前项目 README.md 内容如下:"
    assert "```" not in elements[0]["content"]
    assert "[Bub](https://github.com/bubbuild/bub)" in elements[1]["content"]


@pytest.mark.asyncio
async def test_lark_card_strips_numbered_file_dump_prefixes() -> None:
    events: list[tuple[str, object]] = []

    class MessageApi:
        def create(self, request):
            events.append(("create", request.request_body))
            return _Response(data=SimpleNamespace(message_id="om_created"))

    fake_client = SimpleNamespace(im=SimpleNamespace(v1=SimpleNamespace(message=MessageApi())))
    channel = LarkChannel(lambda message: None)
    channel._api_client = fake_client
    channel._settings = channel._settings.model_copy(update={"app_id": "cli_x", "app_secret": "sec_y"})

    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content="当前项目 README.md 内容如下:\n1 Bub\n2 [Bub](https://github.com/bubbuild/bub)\n3 It starts from...",
        )
    )

    payload = json.loads(events[0][1].content)
    body = "\n\n".join(element["content"] for element in payload["body"]["elements"])
    assert payload["header"]["title"]["content"] == "README.md"
    assert "当前项目 README.md 内容如下:" in body
    assert "\n1 Bub" not in body
    assert "\n2 [Bub]" not in body
    assert "[Bub](https://github.com/bubbuild/bub)" in body


@pytest.mark.asyncio
async def test_lark_card_unwraps_outer_markdown_fence_but_keeps_inner_code_blocks() -> None:
    events: list[tuple[str, object]] = []

    class MessageApi:
        def create(self, request):
            events.append(("create", request.request_body))
            return _Response(data=SimpleNamespace(message_id="om_created"))

    fake_client = SimpleNamespace(im=SimpleNamespace(v1=SimpleNamespace(message=MessageApi())))
    channel = LarkChannel(lambda message: None)
    channel._api_client = fake_client
    channel._settings = channel._settings.model_copy(update={"app_id": "cli_x", "app_secret": "sec_y"})

    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content=(
                "当前项目 README.md 内容如下:\n"
                "```md\n"
                "## Quick Start\n\n"
                "```bash\n"
                "uv sync\n"
                "```\n"
                "```"
            ),
        )
    )

    payload = json.loads(events[0][1].content)
    elements = payload["body"]["elements"]
    assert elements[0]["content"] == "当前项目 README.md 内容如下:"
    assert all("```md" not in element["content"] for element in elements)
    assert any("## Quick Start" in element["content"] for element in elements)
    assert any("```bash" in element["content"] for element in elements)
    assert any("\nuv sync\n" in element["content"] for element in elements)


@pytest.mark.asyncio
async def test_lark_card_uses_short_title_for_long_intro_line() -> None:
    events: list[tuple[str, object]] = []

    class MessageApi:
        def create(self, request):
            events.append(("create", request.request_body))
            return _Response(data=SimpleNamespace(message_id="om_created"))

    fake_client = SimpleNamespace(im=SimpleNamespace(v1=SimpleNamespace(message=MessageApi())))
    channel = LarkChannel(lambda message: None)
    channel._api_client = fake_client
    channel._settings = channel._settings.model_copy(update={"app_id": "cli_x", "app_secret": "sec_y"})

    intro = "当前项目 README.md 的全文如下 (路径: /Users/ui06/code/bub/README.md, 以下为完整原文)"
    await channel.send(
        ChannelMessage(
            session_id="lark:oc_123",
            channel="lark",
            chat_id="oc_123",
            content=f"{intro}\n# Bub\ncontent",
        )
    )

    payload = json.loads(events[0][1].content)
    assert payload["header"]["title"]["content"] == "README.md"
    assert intro in payload["body"]["elements"][0]["content"]


def test_markdown_card_regression_for_bub_readme() -> None:
    sibling_readme = Path(__file__).resolve().parents[1].parent / "bub" / "README.md"
    content = sibling_readme.read_text(encoding="utf-8")
    payload = _markdown_card(f"当前项目 README.md 内容如下:\n\n```md\n{content}\n```")

    assert payload["header"]["title"]["content"] == "README.md"
    elements = payload["body"]["elements"]
    assert elements[0]["content"] == "当前项目 README.md 内容如下:"
    assert all("```md" not in element["content"] for element in elements)
    assert any("## Quick Start" in element["content"] for element in elements)
    assert any("```bash" in element["content"] for element in elements)
    assert any('BUB_RUNTIME_ENABLED=0 uv run bub run "hello"' in element["content"] for element in elements)


def test_code_file_regression_for_bub_tools_py() -> None:
    sibling_tools = Path(__file__).resolve().parents[1].parent / "bub" / "src" / "bub" / "tools.py"
    content = sibling_tools.read_text(encoding="utf-8")
    payload = _markdown_card(f"src/bub/tools.py (`/Users/ui06/code/bub/src/bub/tools.py`) 文件内容如下:\n\n```py\n{content}\n```")

    assert payload["header"]["title"]["content"] == "tools.py"
    elements = payload["body"]["elements"]
    assert elements[0]["content"].startswith("src/bub/tools.py")
    assert elements[1]["content"].startswith("```python\n")
    assert "Central registry for tools." in elements[1]["content"]
    assert "```python" in elements[1]["content"]


def test_code_explanation_for_python_file_stays_markdown_not_code_block() -> None:
    payload = _markdown_card(
        "src/bub/channels/telegram.py 文件内容如下:\n\n"
        "## 1) 组件与职责\n"
        "- **`TelegramChannel`**: Bub 的 Telegram 渠道适配器\n"
        "- **`TelegramMessageParser`**: 负责解析媒体与 metadata\n\n"
        "## 2) 启动方式\n"
        "- polling\n"
        "- 注册 `/start` 与普通消息 handler\n"
    )

    elements = payload["body"]["elements"]
    assert elements[0]["content"].startswith("src/bub/channels/telegram.py")
    assert not any(element["content"].startswith("```python") for element in elements[1:])
    assert any("## 1) 组件与职责" in element["content"] for element in elements)


def test_lark_connection_mode_defaults() -> None:
    channel = LarkChannel(lambda message: None)
    channel._settings = channel._settings.model_copy(update={"app_id": "cli_x", "app_secret": "sec_y"})

    assert channel.needs_debounce is True
    assert channel._settings.effective_connection_mode == "websocket"

    webhook_mode = channel._settings.model_copy(update={"domain": "lark", "connection_mode": "auto"})
    assert webhook_mode.effective_connection_mode == "webhook"
