from __future__ import annotations

from typing import Any

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import client as rawctx_client


def _summary_osi_preview(summary: dict[str, Any]) -> str | None:
    primary = summary.get("osi_version")
    if isinstance(primary, str) and primary.strip():
        return primary.strip()

    versions = summary.get("osi_versions")
    if isinstance(versions, list):
        cleaned = [item.strip() for item in versions if isinstance(item, str) and item.strip()]
        if cleaned:
            return ", ".join(cleaned)
    return None


def _echo_model_paths(model_paths: list[str]) -> None:
    if not model_paths:
        click.echo("Model paths: -")
        return
    click.echo("Model paths:")
    for path in model_paths:
        click.echo(f"  - {path}")


@click.command()
@click.argument("package_ref", required=True)
@click.option("--json", "json_output", is_flag=True, default=False)
@click.option("--offline", is_flag=True, default=False)
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def info(package_ref: str, json_output: bool, offline: bool, registry_override: str | None) -> None:
    """Show package details and versions. [user]"""

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            payload = sdk_client.info(package_ref, offline=offline)
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    package = payload["package"]
    versions = payload["versions"]
    selected_version = payload["selected_version"]
    model_paths = payload.get("model_paths") if isinstance(payload.get("model_paths"), list) else []

    click.echo(f"Package: @{package['scope']}/{package['name']}")
    click.echo(f"Description: {package.get('description') or '-'}")
    if package.get("source_format"):
        click.echo(f"Format: {package['format']} (from {package['source_format']})")
    else:
        click.echo(f"Format: {package['format']}")
    click.echo(f"Origin: {package['origin']}")
    if package.get("origin") == "indexed" and package.get("origin_url"):
        click.echo(f"Indexed source: {package['origin_url']}")
    click.echo(f"Source: {package.get('source') or '-'}  Domain: {package.get('domain') or '-'}")
    click.echo(f"Downloads: {int(package.get('download_count') or 0)}  Stars: {int(package.get('star_count') or 0)}")
    tags = package.get("tags") or []
    click.echo(f"Tags: {', '.join(tags) if tags else '-'}")
    package_level_osi = package.get("latest_osi_version")

    if selected_version:
        click.echo(f"Version: {selected_version['version']} ({selected_version['status']})")
        summary = selected_version.get("model_summary")
        if isinstance(summary, dict):
            click.echo(
                "Model summary: "
                f"datasets={summary.get('dataset_count', 0)} "
                f"measures={summary.get('measure_count', 0)} "
                f"dimensions={summary.get('dimension_count', 0)} "
                f"relationships={summary.get('relationship_count', 0)}"
            )
            osi_preview = _summary_osi_preview(summary)
            if osi_preview:
                click.echo(f"OSI schema preview: {osi_preview}")
            elif package_level_osi:
                click.echo(f"OSI schema preview: {package_level_osi}")
        elif package_level_osi:
            click.echo(f"OSI schema preview: {package_level_osi}")
        _echo_model_paths(model_paths)
        return

    if versions:
        click.echo("Versions: " + ", ".join(item["version"] for item in versions))
        latest = versions[0]
        click.echo(f"Latest: {latest['version']} ({latest['status']})")
        summary = latest.get("model_summary")
        if isinstance(summary, dict):
            click.echo(
                "Latest model preview: "
                f"datasets={summary.get('dataset_count', 0)} "
                f"measures={summary.get('measure_count', 0)} "
                f"dimensions={summary.get('dimension_count', 0)} "
                f"relationships={summary.get('relationship_count', 0)}"
            )
            osi_preview = _summary_osi_preview(summary)
            if osi_preview:
                click.echo(f"OSI schema preview: {osi_preview}")
            elif package_level_osi:
                click.echo(f"OSI schema preview: {package_level_osi}")
        elif package_level_osi:
            click.echo(f"OSI schema preview: {package_level_osi}")
        _echo_model_paths(model_paths)
    else:
        click.echo("Versions: -")
        if package_level_osi:
            click.echo(f"OSI schema preview: {package_level_osi}")
        _echo_model_paths(model_paths)
