import os, sys, getopt
from PIL import Image
from collections import defaultdict

from img2gcode import __version__

class ArgumentList:
    def __init__(self):
        self.src = ""
        self.dst = ""
        self.mx = 1
        self.my = 1
        self.sx = 20000
        self.sy = 20000
        self.p = 30
        self.t = 1
        self.pi = 0
        self.po = 0
        self.ps = 0
        self.pe = 1
        self.ll = 10
        self.ind = 4
        self.link = 1
        self.gapx = 0
        self.gapy = 0
        self.fill = 3
        self.flip = 0
        self.zz = 0

def path_fix(inp, dir):
    terms = inp.split("\n")
    res_fix = []
    for i in range(len(terms)):
        if i < len(terms) - 1 and terms[i][:3] == "G1 " and terms[i + 1][:3] == "G1 " and len(terms[i].split(" ")) == len(terms[i + 1].split(" ")):
            merge = True
            ts = {}
            for t in terms[i].split(" "):
                ts[t[0]] = t[1:]
            for t in terms[i + 1].split(" "):
                if t[0] not in ts or t[1:] != ts[t[0]]:
                #if t[0] not in ts or (t[1:] != ts[t[0]] and t[0] == dir):
                    merge = False
                    break
            if merge:
                continue
        res_fix.append(terms[i])
    return "\n".join(res_fix)

def handle_line(img, mx, my, sx, sy, p, pi, po, t, ps, pe, ll, ind, link, gapx, gapy, fill, flip, zz):
    pause = f"G4 P0.01\n"
    # print vline
    SX = "Y" if flip else "X"
    SY = "X" if flip else "Y"
    gcs = defaultdict(lambda: defaultdict(list))
    mskx = [[0 for y in range(img.size[1])] for x in range(img.size[0])]
    line = [0 for _ in range(img.size[1])]
    for x in range(img.size[0]):
        pt = x
        for y in range(img.size[1]):
            line[y] = 1 if img.getpixel((x, y)) < 128 else 0
        ps = 0
        for i in range(1, len(line)+1):
            if i == len(line) or line[i] != line[ps]:
                pe = i - 1
                if line[ps] == 1 and pe - ps > ll:
                    mskx[x][ps:pe + 1] = [1 for _ in range(pe - ps + 1)]
                    if pe - ps - gapy*2 < gapy * 4:
                        print("???")
                    gtt = [f"G1 {SX}{round(pt*mx, 3)} {SY}{round((ps+gapy)*my, 3)} S0\n"]
                    gtt.append(f"G1 {SY}{round((pe-ind)*my, 3)} S{p}\n")
                    gtt.append(f"G1 {SX}{round(pt*mx, 3)} {SY}{round((pe-gapy)*my, 3)} S0\n")
                    gtt.append(f"G1 {SY}{round((ps+ind)*my, 3)} S{p}\n")
                    gcs[pt][ps] = ["".join([gtt[0], pause, gtt[1], gtt[2]]), "".join([gtt[2], pause, gtt[3], gtt[0]])]
                ps = i
    # fill vline
    for x in range(1, img.size[0]):
        for y in range(img.size[1]):
            line[y] = 1 if mskx[x - 1][y] == 1 and mskx[x][y] == 1 else 0
        for k in range(1, fill):
            pt = x - 1 + k / fill
            ps = 0
            for i in range(1, len(line)+1):
                if i == len(line) or line[i] != line[ps]:
                    pe = i - 1
                    if line[ps] == 1:
                        if pe - ps - gapy*2 < gapy * 4:
                            print("???")
                        gtt = [f"G1 {SX}{round(pt*mx, 3)} {SY}{round((ps+gapy+zz*(k%2)/2)*my, 3)} S0\n"]
                        gtt.append(f"G1 {SY}{round((pe-ind)*my, 3)} S{p}\n")
                        gtt.append(f"G1 {SX}{round(pt*mx, 3)} {SY}{round((pe-gapy-zz*(k%2)/2)*my, 3)} S0\n")
                        gtt.append(f"G1 {SY}{round((ps+ind)*my, 3)} S{p}\n")
                        gcs[pt][ps] = ["".join([gtt[0], pause, gtt[1], gtt[2]]), "".join([gtt[2], pause, gtt[3], gtt[0]])]
                    ps = i
    gc_x = ""
    for ki, vi in sorted(gcs.items(), key=lambda x: x[0]):
        for kj, vj in sorted(vi.items(), key=lambda x: x[0]):
            gc_x += vj[0]
        for kj, vj in sorted(vi.items(), key=lambda x: x[0], reverse=True):
            gc_x += vj[1]
    gc_x = path_fix(gc_x, "X")
    # print hline
    links = defaultdict(list)
    linke = defaultdict(list)
    gcs = defaultdict(lambda: defaultdict(list))
    msky = [[0 for x in range(img.size[0])] for y in range(img.size[1])]
    line = [0 for _ in range(img.size[0])]
    for y in range(img.size[1]):
        pt = y
        for x in range(img.size[0]):
            line[x] = 1 if img.getpixel((x, y)) < 128 else 0
        ps = 0
        for i in range(1, len(line)+1):
            if i == len(line) or line[i] != line[ps]:
                pe = i - 1
                ms = [mskx[k][y] for k in range(ps, pe + 1)]
                if line[ps] == 1 and pe - ps + 1 > ms.count(1):
                    links[ps].append(pt)
                    linke[pe].append(pt)
                    msky[y][ps:pe + 1] = [1 for _ in range(pe - ps + 1)]
                    gtt = [f"G1 {SX}{round((ps+gapx)*mx, 3)} {SY}{round(pt*my, 3)} S0\n"]#+1
                    gtt.append(f"G1 {SX}{round((pe-ind)*mx, 3)} S{p}\n")
                    gtt.append(f"G1 {SX}{round((pe-gapx)*mx, 3)} {SY}{round(pt*my, 3)} S0\n")
                    gtt.append(f"G1 {SX}{round((ps+ind)*mx, 3)} S{p}\n")
                    gcs[pt][ps] = ["".join([gtt[0], pause, gtt[1], gtt[2]]), "".join([gtt[2], pause, gtt[3], gtt[0]])]
                ps = i
    # fill hline
    for y in range(1, img.size[1]):
        for x in range(img.size[0]):
            line[x] = 1 if msky[y - 1][x] == 1 and msky[y][x] == 1 else 0
        for k in range(1, fill):
            pt = y - 1 + k / fill
            ps = 0
            for i in range(1, len(line)+1):
                if i == len(line) or line[i] != line[ps]:
                    pe = i - 1
                    if line[ps] == 1:
                        gtt = [f"G1 {SX}{round((ps+gapx+zz*(k%2)/2)*mx, 3)} {SY}{round(pt*my, 3)} S0\n"]#+1
                        gtt.append(f"G1 {SX}{round((pe-ind)*mx, 3)} S{p}\n")
                        gtt.append(f"G1 {SX}{round((pe-gapx-zz*(k%2)/2)*mx, 3)} {SY}{round(pt*my, 3)} S0\n")
                        gtt.append(f"G1 {SX}{round((ps+ind)*mx, 3)} S{p}\n")
                        gcs[pt][ps] = ["".join([gtt[0], pause, gtt[1], gtt[2]]), "".join([gtt[2], pause, gtt[3], gtt[0]])]
                    ps = i
    gc_y = ""
    for ki, vi in sorted(gcs.items(), key=lambda x: x[0]):
        for kj, vj in sorted(vi.items(), key=lambda x: x[0]):
            gc_y += vj[0]
        for kj, vj in sorted(vi.items(), key=lambda x: x[0], reverse=True):
            gc_y += vj[1]
    gc_y = path_fix(gc_y, "Y")
    # fill links
    gcs = defaultdict(lambda: defaultdict(list))
    for hx, hys in sorted(links.items(), key=lambda x: x[0]):
        lines = []
        s = 0
        for i in range(1, len(hys)):
            if hys[i] - hys[i - 1] > 1:
                lines.append([hys[s], hys[i - 1]])
                s = i
        lines.append([hys[s], hys[-1]])
        for ps, pe in lines:
            for k in range(1, fill * 3):
                pt = hx + k / fill
                gtt = ["", ""]
                if img.getpixel((hx, min(pe + 1, img.size[1] - 1))) < 128 and img.getpixel((min(hx + 1, img.size[0]), min(pe + 1, img.size[1] - 1))) >= 128:
                    gtt[0] = f"G1 {SX}{round(pt*mx, 3)} {SY}{round((ps+gapy)*my, 3)} S0\n" + pause
                    gtt[0] += f"G1 {SY}{round((pe+link)*my, 3)} S{p}\n"
                    gtt[0] += f"G1 {SX}{round(pt*mx, 3)} {SY}{round((pe+link*2)*my, 3)} S0\n"
                if img.getpixel((hx, max(ps - 1, 0))) < 128 and img.getpixel((min(hx + 1, img.size[0] - 1), max(ps - 1, 0))) >= 128:
                    gtt[1] = f"G1 {SX}{round(pt*mx, 3)} {SY}{round((pe-gapy)*my, 3)} S0\n" + pause
                    gtt[1] += f"G1 {SY}{round((ps-link)*my, 3)} S{p}\n"
                    gtt[1] += f"G1 {SX}{round(pt*mx, 3)} {SY}{round((ps-link*2)*my, 3)} S0\n"
                if gtt != ["", ""]:
                    gcs[pt][ps] = gtt
    # fill linke
    for hx, hys in sorted(linke.items(), key=lambda x: x[0]):
        lines = []
        s = 0
        for i in range(1, len(hys)):
            if hys[i] - hys[i - 1] > 1:
                lines.append([hys[s], hys[i - 1]])
                s = i
        lines.append([hys[s], hys[-1]])
        for ps, pe in lines:
            for k in range(1, fill * 2):
                pt = hx - k / fill
                gtt = ["", ""]
                if img.getpixel((hx, min(pe + 1, img.size[1] - 1))) < 128 and img.getpixel((max(hx - 1, 0), min(pe + 1, img.size[1] - 1))) >= 128:
                    gtt[0] = f"G1 {SX}{round(pt*mx, 3)} {SY}{round((ps+gapy)*my, 3)} S0\n" + pause
                    gtt[0] += f"G1 {SY}{round((pe+link)*my, 3)} S{p}\n"
                    gtt[0] += f"G1 {SX}{round(pt*mx, 3)} {SY}{round((pe+link*2)*my, 3)} S0\n"
                if img.getpixel((hx, max(ps - 1, 0))) < 128 and img.getpixel((max(hx - 1, 0), max(ps - 1, 0))) >= 128:
                    gtt[1] = f"G1 {SX}{round(pt*mx, 3)} {SY}{round((pe-gapy)*my, 3)} S0\n" + pause
                    gtt[1] += f"G1 {SY}{round((ps-link)*my, 3)} S{p}\n"
                    gtt[1] += f"G1 {SX}{round(pt*mx, 3)} {SY}{round((ps-link*2)*my, 3)} S0\n"
                if gtt != ["", ""]:
                    gcs[pt][ps] = gtt
    gc_l = ""
    for ki, vi in sorted(gcs.items(), key=lambda x: x[0]):
        for kj, vj in sorted(vi.items(), key=lambda x: x[0]):
            if vj[0] != "":
                gc_l += vj[0]
        for kj, vj in sorted(vi.items(), key=lambda x: x[0], reverse=True):
            if vj[1] != "":
                gc_l += vj[1]
    gc_l = path_fix(gc_l, "X")
    res = "G0\nG17\nG40\nG21\nG54\nG90\nM3\nM8\nM3\nM8\nM9\nG90\n"
    res += f"G0 {SX}0 {SY}0 S0 F0\nG1 {SX}0 {SY}0 S0 F{sx}\n"
    res += "".join([gc_y for _ in range(t)])
    res += f"G0 {SX}0 {SY}0 S0 F0\nG1 {SX}0 {SY}0 S0 F{sy}\n"
    res += "".join([gc_x for _ in range(t)])
    res += f"G0 {SX}0 {SY}0 S0 F0\nG1 {SX}0 {SY}0 S0 F{sy}\n"
    res += "".join([gc_l for _ in range(t)])
    res += f"G0 {SX}0 {SY}0 S0\nM5\nG90\n"
    return res

def img2gcode(args):
    img = Image.open(args.src).convert("L")
    res = handle_line(img, args.mx, args.my, args.sx, args.sy, args.p, args.pi, args.po, args.t, args.ps, args.pe, args.ll, args.ind, args.link, args.gapx, args.gapy, args.fill, args.flip, args.zz)
    gc = open(args.dst, "w")
    r = gc.write(res)
    gc.close()
    img.close()

def main():
    opts, terms = getopt.getopt(sys.argv[1:], "hi:o:n:k:x:y:c:d:p:t:a:b:s:e:l:g:j:m:fz", 
        ["help", "input=", "output=", "indent=", "link=", "step_x=", "step_y=", "speed_x=", "speed_y=", "power=", "times=", "pause_in=", "pause_out=", "start=", "end=", "limit=", "gap_x=", "gap_y=", "fill=", "flip", "zigzag"])
    args = ArgumentList()
    help_flag = False
    help_info = "Usage:\nimg2gcode [options] -i <image>\nArguments:\n"\
        +"--help, -h\t\tShow this help information\n"\
        +"--input, -i\t\tThe path of source image file\n"\
        +"--output, -o\t\tThe path of generated gcode file (default: same as input)\n"\
        +"--indent, -n\t\tThe end indentation of lines (pixel, default: 4)\n"\
        +"--link, -k\t\tThe length of links (pixel, default: 1)\n"\
        +"--step_x, -x\t\tStep on x-axis (step/pixel, default: 1)\n"\
        +"--step_y, -y\t\tStep on y-axis (step/pixel, default: 1)\n"\
        +"--speed_x, -c\t\tSpeed on x-axis (1-20000, default: 20000)\n"\
        +"--speed_y, -d\t\tSpeed on y-axis (1-20000, default: 20000)\n"\
        +"--power, -p\t\tPower of laser (0-1000, default: 30)\n"\
        +"--times, -t\t\tNumber of exposures (default: 1)\n"\
        +"--pause_in, -a\t\tPause time before laser on (sec, default: 0)\n"\
        +"--pause_out, -b\t\tPause time after laser off (sec, default: 0)\n"\
        +"--start, -s\t\tStart y position for test (default: 0)\n"\
        +"--end, -e\t\tEnd y position for test (default: 1)\n"\
        +"--limit, -l\t\tThe min length of line to draw (default: 10)\n"\
        +"--gap_x, -g\t\tThe gap for matching x-axis (pixel, default: 0)\n"\
        +"--gap_y, -j\t\tThe gap for matching y-axis (pixel, default: 0)\n"\
        +"--fill, -m\t\tThe padding times for blocks (default: 3)\n"\
        +"--flip, -f\t\tFlip image\n"\
        +"--zigzag, -z\t\tUsing zigzag padding\n"
    for opt, arg in opts:
        if opt in ("--help", "-h"):
            help_flag = True
        elif opt in ("--input", "-i"):
            args.src = arg
        elif opt in ("--output", "-o"):
            args.dst = arg
        elif opt in ("--indent", "-n"):
            args.ind = max(round(float(arg), 3), 0)
        elif opt in ("--link", "-k"):
            args.link = max(round(float(arg), 3), 0)
        elif opt in ("--step_x", "-x"):
            args.mx = max(float(arg), 0)
        elif opt in ("--step_y", "-y"):
            args.my = max(float(arg), 0)
        elif opt in ("--speed_x", "-c"):
            args.sx = max(int(arg), 1)
        elif opt in ("--speed_y", "-d"):
            args.sy = max(int(arg), 1)
        elif opt in ("--power", "-p"):
            args.p = max(int(arg), 0)
        elif opt in ("--times", "-t"):
            args.t = max(int(arg), 1)
        elif opt in ("--pause_in", "-a"):
            args.pi = max(round(float(arg), 3), 0)
        elif opt in ("--pause_out", "-b"):
            args.po = max(round(float(arg), 3), 0)
        elif opt in ("--start", "-s"):
            args.ps = min(max(round(float(arg), 3), 0), 1)
        elif opt in ("--end", "-e"):
            args.pe = min(max(round(float(arg), 3), 0), 1)
        elif opt in ("--limit", "-l"):
            args.ll = max(0, int(arg))
        elif opt in ("--gap_x", "-g"):
            args.gapx = round(float(arg), 3)
        elif opt in ("--gap_y", "-j"):
            args.gapy = round(float(arg),3)
        elif opt in ("--fill", "-m"):
            args.fill = max(0, int(arg))
        elif opt in ("--flip", "-f"):
            args.flip = 1
        elif opt in ("--zigzag", "-z"):
            args.zz = 1
    args.dst = os.path.splitext(args.src)[0] + ".gcode" if args.dst == "" else args.dst
    print("img2gcode - Version: "+__version__)
    if help_flag or args.src == "":
        print(help_info)
        sys.exit()
    print(f"Converting {args.src} ...")
    img2gcode(args)
    print(f"Done!")

if __name__ == "__main__":
    main()
