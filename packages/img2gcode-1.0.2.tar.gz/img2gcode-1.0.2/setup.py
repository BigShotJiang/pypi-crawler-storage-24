'''Setup script for img2gcode'''

from __future__ import absolute_import

import os.path
from setuptools import setup
from img2gcode import __version__

# The directory containing this file
HERE = os.path.abspath(os.path.dirname(__file__))

# The text of the README file
with open(os.path.join(HERE, 'README.md')) as fid:
    README = fid.read()

# This call to setup() does all the work
setup(
    name='img2gcode',
    version=__version__,
    description='Convert image to gcode for laser printing',
    long_description=README,
    long_description_content_type='text/markdown',
    url='https://github.com/0CBH0/img2gcode',
    author='0CBH0',
    author_email='maodatou88@163.com',
    license='MIT',
    classifiers=[
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Programming Language :: Python :: 3',
    ],
    packages=['img2gcode'],
    include_package_data=True,
    install_requires=['Pillow'],
    python_requires='>=3.7',
    entry_points={'console_scripts': ['img2gcode=img2gcode.__main__:main']},
)
