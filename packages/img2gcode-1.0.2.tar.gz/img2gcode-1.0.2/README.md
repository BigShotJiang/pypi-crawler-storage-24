# img2gcode

Convert image to gcode for laser printing.

## Installation
~~~
python3 -m pip install --upgrade img2gcode
~~~

## Usage
~~~
# Basic usage
img2gcode [options] -i <image_file>

# For more information
img2gcode -h
~~~
