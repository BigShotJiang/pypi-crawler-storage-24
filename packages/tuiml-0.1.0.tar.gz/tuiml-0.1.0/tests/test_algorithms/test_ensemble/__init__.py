"""Tests for ensemble algorithms."""
