"""Tests for trees algorithms."""
