"""Tests for neighbors algorithms."""
