"""Tests for linear algorithms."""
