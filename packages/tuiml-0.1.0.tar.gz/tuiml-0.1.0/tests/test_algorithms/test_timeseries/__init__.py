"""Tests for timeseries algorithms."""
