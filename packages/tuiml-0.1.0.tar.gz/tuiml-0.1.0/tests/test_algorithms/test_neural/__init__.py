"""Tests for neural algorithms."""
