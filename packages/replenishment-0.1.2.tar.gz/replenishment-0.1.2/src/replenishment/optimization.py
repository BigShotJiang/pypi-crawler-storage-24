"""Optimization helpers for replenishment simulations."""

from __future__ import annotations

from collections.abc import Iterable, Mapping
from dataclasses import dataclass, replace as dataclass_replace

from .aggregation import (
    aggregate_lead_time,
    aggregate_periods,
    aggregate_policy,
    aggregate_series,
)
from .policies import (
    EmpiricalMultiplierPolicy,
    ForecastBasedPolicy,
    ForecastSeriesPolicy,
    LeadTimeForecastOptimizationPolicy,
    PercentileForecastOptimizationPolicy,
    PointForecastOptimizationPolicy,
    RopEmpiricalMultiplierPolicy,
    RopPercentileForecastOptimizationPolicy,
    RopPointForecastOptimizationPolicy,
    SAFETY_STOCK_METHOD_K_RMSE,
    normalize_safety_stock_method,
)
from .service_levels import normalize_service_level_mode
from .simulation import (
    ArticleSimulationConfig,
    DemandModel,
    SimulationMetadata,
    SimulationResult,
    simulate_replenishment,
)


def _attach_metadata(
    simulation: SimulationResult,
    *,
    service_level_factor: float | None = None,
    service_level_mode: str | None = None,
    safety_stock_method: str | None = None,
    aggregation_window: int | None = None,
    review_period: int | None = None,
    forecast_horizon: int | None = None,
    rmse_window: int | None = None,
    percentile_target: float | str | None = None,
) -> SimulationResult:
    base = simulation.metadata
    metadata = SimulationMetadata(
        service_level_factor=(
            service_level_factor
            if service_level_factor is not None
            else base.service_level_factor
            if base is not None
            else None
        ),
        service_level_mode=(
            service_level_mode
            if service_level_mode is not None
            else base.service_level_mode
            if base is not None
            else None
        ),
        safety_stock_method=(
            safety_stock_method
            if safety_stock_method is not None
            else base.safety_stock_method
            if base is not None
            else None
        ),
        aggregation_window=(
            aggregation_window
            if aggregation_window is not None
            else base.aggregation_window
            if base is not None
            else None
        ),
        review_period=(
            review_period
            if review_period is not None
            else base.review_period
            if base is not None
            else None
        ),
        forecast_horizon=(
            forecast_horizon
            if forecast_horizon is not None
            else base.forecast_horizon
            if base is not None
            else None
        ),
        rmse_window=(
            rmse_window
            if rmse_window is not None
            else base.rmse_window
            if base is not None
            else None
        ),
        percentile_target=(
            percentile_target
            if percentile_target is not None
            else base.percentile_target
            if base is not None
            else None
        ),
    )
    return SimulationResult(
        snapshots=simulation.snapshots,
        summary=simulation.summary,
        metadata=metadata,
    )


def _rmse_from_series(actuals: Iterable[int], forecasts: Iterable[int]) -> float:
    actual_values = list(actuals)
    forecast_values = list(forecasts)
    count = min(len(actual_values), len(forecast_values))
    if count <= 0:
        return 0.0
    errors = [
        actual_values[index] - forecast_values[index]
        for index in range(count)
    ]
    if not errors:
        return 0.0
    if len(errors) == 1:
        return abs(errors[0])
    mean_squared_error = sum(error * error for error in errors) / len(errors)
    return mean_squared_error**0.5


@dataclass(frozen=True)
class PointForecastOptimizationResult:
    service_level_factor: float
    simulation: SimulationResult


@dataclass(frozen=True)
class KRmseFillRateOptimizationResult:
    k: float
    meets_fill_rate_target: bool
    achieved_fill_rate: float
    simulation: SimulationResult


@dataclass(frozen=True)
class ForecastCandidatesConfig:
    """Inputs for forecast-candidate optimization.

    Use string labels to disambiguate candidates (for example "45-low", "45-high").
    """

    periods: int
    demand: Iterable[int] | DemandModel
    initial_on_hand: int
    lead_time: int
    forecast_candidates: Mapping[float | str, Iterable[int] | DemandModel]
    review_period: int = 1
    forecast_horizon: int | None = None
    holding_cost_per_unit: float = 0.0
    stockout_cost_per_unit: float = 0.0
    order_cost_per_order: float = 0.0
    order_cost_per_unit: float = 0.0


@dataclass(frozen=True)
class PercentileForecastOptimizationResult:
    target: float | str
    policy: PercentileForecastOptimizationPolicy
    simulation: SimulationResult


ServiceLevelOptimizationResult = PointForecastOptimizationResult
ForecastTargetOptimizationResult = PercentileForecastOptimizationResult


@dataclass(frozen=True)
class AggregationWindowOptimizationResult:
    window: int
    simulation: SimulationResult
    policy: (
        ForecastSeriesPolicy
        | ForecastBasedPolicy
        | PointForecastOptimizationPolicy
        | LeadTimeForecastOptimizationPolicy
        | RopPointForecastOptimizationPolicy
        | PercentileForecastOptimizationPolicy
        | RopPercentileForecastOptimizationPolicy
        | None
    )


@dataclass(frozen=True)
class AggregationServiceLevelOptimizationResult:
    window: int
    service_level_factor: float
    policy: (
        PointForecastOptimizationPolicy
        | LeadTimeForecastOptimizationPolicy
        | RopPointForecastOptimizationPolicy
    )
    simulation: SimulationResult


@dataclass(frozen=True)
class AggregationForecastTargetOptimizationResult:
    window: int
    target: float | str
    policy: PercentileForecastOptimizationPolicy | RopPercentileForecastOptimizationPolicy
    simulation: SimulationResult


def _resolve_service_level_mode(
    policy: (
        ForecastBasedPolicy
        | PointForecastOptimizationPolicy
        | LeadTimeForecastOptimizationPolicy
        | RopPointForecastOptimizationPolicy
    ),
    service_level_mode: str | None,
) -> str:
    if service_level_mode is not None:
        return normalize_service_level_mode(service_level_mode)
    return normalize_service_level_mode(getattr(policy, "service_level_mode", None))


def _validate_service_level_candidates(
    factors: list[float], service_level_mode: str
) -> None:
    if not factors:
        raise ValueError("Candidate factors must be provided.")
    if service_level_mode == "factor":
        if any(factor < 0 for factor in factors):
            raise ValueError("Service level factors must be non-negative.")
        return
    if any(factor <= 0 or factor >= 1 for factor in factors):
        raise ValueError(
            "Service level probabilities must be between 0 and 1 (exclusive)."
        )


def _candidate_policy_for(
    policy: (
        ForecastBasedPolicy
        | PointForecastOptimizationPolicy
        | LeadTimeForecastOptimizationPolicy
        | RopPointForecastOptimizationPolicy
    ),
    *,
    forecast: Iterable[int] | DemandModel,
    actuals: Iterable[int] | DemandModel,
    lead_time: int,
    factor: float,
    mode: str,
    fixed_rmse: float | None = None,
    aggregation_window: int | None = None,
    safety_stock_method: str | None = None,
) -> (
    PointForecastOptimizationPolicy
    | LeadTimeForecastOptimizationPolicy
    | RopPointForecastOptimizationPolicy
):
    review_period = (
        aggregation_window
        if aggregation_window is not None
        else getattr(policy, "review_period", None)
    )
    forecast_horizon = (
        aggregation_window
        if aggregation_window is not None
        else getattr(policy, "forecast_horizon", None)
    )
    rmse_window = (
        aggregation_window
        if aggregation_window is not None
        else getattr(policy, "rmse_window", None)
    )
    selected_safety_stock_method = (
        normalize_safety_stock_method(safety_stock_method)
        if safety_stock_method is not None
        else normalize_safety_stock_method(getattr(policy, "safety_stock_method", None))
    )
    if isinstance(policy, LeadTimeForecastOptimizationPolicy):
        return LeadTimeForecastOptimizationPolicy(
            forecast=forecast,
            actuals=actuals,
            lead_time=lead_time,
            aggregation_window=(
                aggregation_window
                if aggregation_window is not None
                else policy.aggregation_window
            ),
            review_period=review_period,
            forecast_horizon=forecast_horizon,
            rmse_window=rmse_window,
            service_level_factor=factor,
            service_level_mode=mode,
            safety_stock_method=selected_safety_stock_method,
            fixed_rmse=fixed_rmse,
        )
    if isinstance(policy, RopPointForecastOptimizationPolicy):
        return RopPointForecastOptimizationPolicy(
            forecast=forecast,
            actuals=actuals,
            lead_time=lead_time,
            aggregation_window=(
                aggregation_window
                if aggregation_window is not None
                else policy.aggregation_window
            ),
            review_period=review_period,
            forecast_horizon=forecast_horizon,
            rmse_window=rmse_window,
            service_level_factor=factor,
            service_level_mode=mode,
            safety_stock_method=selected_safety_stock_method,
            fixed_rmse=fixed_rmse,
        )
    return PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=lead_time,
        aggregation_window=(
            aggregation_window
            if aggregation_window is not None
            else policy.aggregation_window
        ),
        review_period=review_period,
        forecast_horizon=forecast_horizon,
        rmse_window=rmse_window,
        service_level_factor=factor,
        service_level_mode=mode,
        safety_stock_method=selected_safety_stock_method,
        fixed_rmse=fixed_rmse,
    )


def optimize_service_level_factors(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_factors: Iterable[float],
    service_level_mode: str | None = None,
    safety_stock_method: str | None = None,
) -> dict[str, PointForecastOptimizationResult]:
    """Pick the point-forecast safety stock factor that minimizes total cost."""
    factors = list(candidate_factors)

    results: dict[str, PointForecastOptimizationResult] = {}
    for article_id, config in articles.items():
        policy = config.policy
        if not isinstance(
            policy,
            (
                ForecastBasedPolicy,
                PointForecastOptimizationPolicy,
                LeadTimeForecastOptimizationPolicy,
                RopPointForecastOptimizationPolicy,
            ),
        ):
            raise TypeError(
                "Point forecast optimization requires point-forecast policies."
            )
        mode = _resolve_service_level_mode(policy, service_level_mode)
        _validate_service_level_candidates(factors, mode)
        best_result: PointForecastOptimizationResult | None = None
        for factor in factors:
            candidate_policy = _candidate_policy_for(
                policy,
                forecast=policy.forecast,
                actuals=policy.actuals,
                lead_time=config.lead_time,
                factor=factor,
                mode=mode,
                fixed_rmse=getattr(policy, "fixed_rmse", None),
                safety_stock_method=safety_stock_method,
            )
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=candidate_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )
            simulation = _attach_metadata(
                simulation,
                service_level_factor=factor,
                service_level_mode=mode,
                safety_stock_method=getattr(candidate_policy, "safety_stock_method", None),
                aggregation_window=getattr(candidate_policy, "aggregation_window", None),
                review_period=getattr(candidate_policy, "review_period", None),
                forecast_horizon=getattr(candidate_policy, "forecast_horizon", None),
                rmse_window=getattr(candidate_policy, "rmse_window", None),
            )
            if best_result is None:
                best_result = PointForecastOptimizationResult(
                    service_level_factor=factor,
                    simulation=simulation,
                )
                continue
            if simulation.summary.total_cost < best_result.simulation.summary.total_cost:
                best_result = PointForecastOptimizationResult(
                    service_level_factor=factor,
                    simulation=simulation,
                )
        if best_result is None:
            raise RuntimeError("No optimization result computed.")
        results[article_id] = best_result
    return results


def point_forecast_optimisation(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_factors: Iterable[float],
) -> dict[str, PointForecastOptimizationResult]:
    """Alias for optimizing point-forecast safety stock factors."""
    return optimize_service_level_factors(articles, candidate_factors)


def optimize_k_rmse_factors(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_k: Iterable[float],
) -> dict[str, PointForecastOptimizationResult]:
    """Pick k in safety_stock = k * RMSE by minimizing total cost."""
    return optimize_service_level_factors(
        articles,
        candidate_factors=candidate_k,
        service_level_mode="factor",
        safety_stock_method=SAFETY_STOCK_METHOD_K_RMSE,
    )


def optimize_k_rmse_factors_for_fill_rate(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_k: Iterable[float],
    target_fill_rate: float,
) -> dict[str, KRmseFillRateOptimizationResult]:
    """Pick k for safety_stock = k * RMSE with a fill-rate target.

    Chooses the lowest-cost candidate that meets `fill_rate >= target_fill_rate`.
    If none meet target, returns the highest-fill-rate candidate (cost tie-break).
    """
    if target_fill_rate <= 0 or target_fill_rate > 1:
        raise ValueError("Target fill rate must be in (0, 1].")
    factors = list(candidate_k)
    _validate_service_level_candidates(factors, "factor")

    results: dict[str, KRmseFillRateOptimizationResult] = {}
    for article_id, config in articles.items():
        policy = config.policy
        if not isinstance(
            policy,
            (
                ForecastBasedPolicy,
                PointForecastOptimizationPolicy,
                LeadTimeForecastOptimizationPolicy,
                RopPointForecastOptimizationPolicy,
            ),
        ):
            raise TypeError(
                "k*RMSE optimization requires point-forecast policies."
            )
        best_meeting_target: KRmseFillRateOptimizationResult | None = None
        best_fallback: KRmseFillRateOptimizationResult | None = None
        for k in factors:
            candidate_policy = _candidate_policy_for(
                policy,
                forecast=policy.forecast,
                actuals=policy.actuals,
                lead_time=config.lead_time,
                factor=k,
                mode="factor",
                fixed_rmse=getattr(policy, "fixed_rmse", None),
                safety_stock_method=SAFETY_STOCK_METHOD_K_RMSE,
            )
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=candidate_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )
            simulation = _attach_metadata(
                simulation,
                service_level_factor=k,
                service_level_mode="factor",
                safety_stock_method=getattr(candidate_policy, "safety_stock_method", None),
                aggregation_window=getattr(candidate_policy, "aggregation_window", None),
                review_period=getattr(candidate_policy, "review_period", None),
                forecast_horizon=getattr(candidate_policy, "forecast_horizon", None),
                rmse_window=getattr(candidate_policy, "rmse_window", None),
            )
            candidate = KRmseFillRateOptimizationResult(
                k=k,
                meets_fill_rate_target=simulation.summary.fill_rate >= target_fill_rate,
                achieved_fill_rate=simulation.summary.fill_rate,
                simulation=simulation,
            )
            if candidate.meets_fill_rate_target:
                if best_meeting_target is None:
                    best_meeting_target = candidate
                elif (
                    candidate.simulation.summary.total_cost
                    < best_meeting_target.simulation.summary.total_cost
                ):
                    best_meeting_target = candidate
                continue
            if best_fallback is None:
                best_fallback = candidate
                continue
            if candidate.achieved_fill_rate > best_fallback.achieved_fill_rate:
                best_fallback = candidate
                continue
            if (
                candidate.achieved_fill_rate == best_fallback.achieved_fill_rate
                and candidate.simulation.summary.total_cost
                < best_fallback.simulation.summary.total_cost
            ):
                best_fallback = candidate
        if best_meeting_target is not None:
            results[article_id] = best_meeting_target
        elif best_fallback is not None:
            results[article_id] = best_fallback
        else:
            raise RuntimeError("No optimization result computed.")
    return results


def optimize_forecast_targets(
    articles: Mapping[str, ForecastCandidatesConfig],
    candidate_targets: Iterable[float | str] | None = None,
    *,
    policy_mode: str = "base_stock",
) -> dict[str, PercentileForecastOptimizationResult]:
    """Pick the percentile forecast candidate that minimizes total cost."""
    results: dict[str, PercentileForecastOptimizationResult] = {}
    for article_id, config in articles.items():
        if not config.forecast_candidates:
            raise ValueError("Forecast candidates must be provided.")
        targets = (
            list(candidate_targets)
            if candidate_targets is not None
            else list(config.forecast_candidates.keys())
        )
        if not targets:
            raise ValueError("Candidate targets must be provided.")

        best_result: PercentileForecastOptimizationResult | None = None
        for target in targets:
            if target not in config.forecast_candidates:
                raise ValueError(f"Unknown forecast target: {target}")
            if policy_mode == "rop":
                candidate_policy = RopPercentileForecastOptimizationPolicy(
                    forecast=config.forecast_candidates[target],
                    lead_time=config.lead_time,
                    review_period=config.review_period,
                    forecast_horizon=config.forecast_horizon,
                )
            elif policy_mode == "base_stock":
                candidate_policy = PercentileForecastOptimizationPolicy(
                    forecast=config.forecast_candidates[target],
                    lead_time=config.lead_time,
                    review_period=config.review_period,
                    forecast_horizon=config.forecast_horizon,
                )
            else:
                raise ValueError("policy_mode must be 'base_stock' or 'rop'.")
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=candidate_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )
            simulation = _attach_metadata(
                simulation,
                percentile_target=target,
                aggregation_window=getattr(candidate_policy, "aggregation_window", None),
                review_period=getattr(candidate_policy, "review_period", None),
                forecast_horizon=getattr(candidate_policy, "forecast_horizon", None),
            )
            if best_result is None:
                best_result = PercentileForecastOptimizationResult(
                    target=target,
                    policy=candidate_policy,
                    simulation=simulation,
                )
                continue
            if simulation.summary.total_cost < best_result.simulation.summary.total_cost:
                best_result = PercentileForecastOptimizationResult(
                    target=target,
                    policy=candidate_policy,
                    simulation=simulation,
                )
        if best_result is None:
            raise RuntimeError("No optimization result computed.")
        results[article_id] = best_result
    return results


def evaluate_forecast_target_costs(
    articles: Mapping[str, ForecastCandidatesConfig],
    candidate_targets: Iterable[float | str] | None = None,
    *,
    policy_mode: str = "base_stock",
) -> dict[str, dict[float | str, float]]:
    """Return total costs for each forecast candidate per article."""
    results: dict[str, dict[float | str, float]] = {}
    for article_id, config in articles.items():
        if not config.forecast_candidates:
            raise ValueError("Forecast candidates must be provided.")
        targets = (
            list(candidate_targets)
            if candidate_targets is not None
            else list(config.forecast_candidates.keys())
        )
        if not targets:
            raise ValueError("Candidate targets must be provided.")

        target_costs: dict[float | str, float] = {}
        for target in targets:
            if target not in config.forecast_candidates:
                raise ValueError(f"Unknown forecast target: {target}")
            if policy_mode == "rop":
                candidate_policy = RopPercentileForecastOptimizationPolicy(
                    forecast=config.forecast_candidates[target],
                    lead_time=config.lead_time,
                    review_period=config.review_period,
                    forecast_horizon=config.forecast_horizon,
                )
            elif policy_mode == "base_stock":
                candidate_policy = PercentileForecastOptimizationPolicy(
                    forecast=config.forecast_candidates[target],
                    lead_time=config.lead_time,
                    review_period=config.review_period,
                    forecast_horizon=config.forecast_horizon,
                )
            else:
                raise ValueError("policy_mode must be 'base_stock' or 'rop'.")
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=candidate_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )
            target_costs[target] = simulation.summary.total_cost
        results[article_id] = target_costs
    return results


def evaluate_service_level_factor_costs(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_factors: Iterable[float],
    service_level_mode: str | None = None,
    safety_stock_method: str | None = None,
) -> dict[str, dict[float, float]]:
    """Return total costs for each service-level factor per article."""
    factors = list(candidate_factors)

    results: dict[str, dict[float, float]] = {}
    for article_id, config in articles.items():
        policy = config.policy
        if not isinstance(
            policy,
            (
                ForecastBasedPolicy,
                PointForecastOptimizationPolicy,
                LeadTimeForecastOptimizationPolicy,
                RopPointForecastOptimizationPolicy,
            ),
        ):
            raise TypeError(
                "Service-level cost evaluation requires point-forecast policies."
            )
        mode = _resolve_service_level_mode(policy, service_level_mode)
        _validate_service_level_candidates(factors, mode)
        factor_costs: dict[float, float] = {}
        for factor in factors:
            candidate_policy = _candidate_policy_for(
                policy,
                forecast=policy.forecast,
                actuals=policy.actuals,
                lead_time=config.lead_time,
                factor=factor,
                mode=mode,
                fixed_rmse=getattr(policy, "fixed_rmse", None),
                safety_stock_method=safety_stock_method,
            )
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=candidate_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )
            factor_costs[factor] = simulation.summary.total_cost
        results[article_id] = factor_costs
    return results


def evaluate_aggregation_and_service_level_factor_costs(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_windows: Iterable[int],
    candidate_factors: Iterable[float],
    service_level_mode: str | None = None,
    safety_stock_method: str | None = None,
) -> dict[str, dict[int, dict[float, float]]]:
    """Return total costs for each window and service-level factor per article."""
    windows = list(candidate_windows)
    if not windows:
        raise ValueError("Aggregation windows must be provided.")
    if any(window <= 0 for window in windows):
        raise ValueError("Aggregation windows must be positive.")

    factors = list(candidate_factors)

    results: dict[str, dict[int, dict[float, float]]] = {}
    for article_id, config in articles.items():
        policy = config.policy
        if not isinstance(
            policy,
            (
                ForecastBasedPolicy,
                PointForecastOptimizationPolicy,
                LeadTimeForecastOptimizationPolicy,
                RopPointForecastOptimizationPolicy,
            ),
        ):
            raise TypeError(
                "Aggregation with service-level costs requires point-forecast policies."
            )
        mode = _resolve_service_level_mode(policy, service_level_mode)
        _validate_service_level_candidates(factors, mode)
        window_costs: dict[int, dict[float, float]] = {}
        for window in windows:
            factor_costs: dict[float, float] = {}
            for factor in factors:
                candidate_policy = _candidate_policy_for(
                    policy,
                    forecast=policy.forecast,
                    actuals=policy.actuals,
                    lead_time=config.lead_time,
                    factor=factor,
                    mode=mode,
                    fixed_rmse=getattr(policy, "fixed_rmse", None),
                    aggregation_window=window,
                    safety_stock_method=safety_stock_method,
                )
                simulation = simulate_replenishment(
                    periods=config.periods,
                    demand=config.demand,
                    initial_on_hand=config.initial_on_hand,
                    lead_time=config.lead_time,
                    policy=candidate_policy,
                    holding_cost_per_unit=config.holding_cost_per_unit,
                    stockout_cost_per_unit=config.stockout_cost_per_unit,
                    order_cost_per_order=config.order_cost_per_order,
                    order_cost_per_unit=config.order_cost_per_unit,
                )
                factor_costs[factor] = simulation.summary.total_cost
            window_costs[window] = factor_costs
        results[article_id] = window_costs
    return results


def evaluate_aggregation_and_forecast_target_costs(
    articles: Mapping[str, ForecastCandidatesConfig],
    candidate_windows: Iterable[int],
    candidate_targets: Iterable[float | str] | None = None,
    *,
    policy_mode: str = "base_stock",
) -> dict[str, dict[int, dict[float | str, float]]]:
    """Return total costs for each review window and forecast target per article."""
    windows = list(candidate_windows)
    if not windows:
        raise ValueError("Aggregation windows must be provided.")
    if any(window <= 0 for window in windows):
        raise ValueError("Aggregation windows must be positive.")

    target_candidates = list(candidate_targets) if candidate_targets is not None else None
    results: dict[str, dict[int, dict[float | str, float]]] = {}
    for article_id, config in articles.items():
        if not config.forecast_candidates:
            raise ValueError("Forecast candidates must be provided.")
        candidate_series = {
            target: list(series) if not callable(series) else series
            for target, series in config.forecast_candidates.items()
        }
        targets = (
            list(target_candidates)
            if target_candidates is not None
            else list(candidate_series.keys())
        )
        if not targets:
            raise ValueError("Candidate targets must be provided.")

        window_costs: dict[int, dict[float | str, float]] = {}
        for window in windows:
            target_costs: dict[float | str, float] = {}
            for target in targets:
                if target not in candidate_series:
                    raise ValueError(f"Unknown forecast target: {target}")
                if policy_mode == "rop":
                    candidate_policy = RopPercentileForecastOptimizationPolicy(
                        forecast=candidate_series[target],
                        lead_time=config.lead_time,
                        aggregation_window=window,
                        review_period=window,
                        forecast_horizon=window,
                    )
                elif policy_mode == "base_stock":
                    candidate_policy = PercentileForecastOptimizationPolicy(
                        forecast=candidate_series[target],
                        lead_time=config.lead_time,
                        aggregation_window=window,
                        review_period=window,
                        forecast_horizon=window,
                    )
                else:
                    raise ValueError("policy_mode must be 'base_stock' or 'rop'.")
                simulation = simulate_replenishment(
                    periods=config.periods,
                    demand=config.demand,
                    initial_on_hand=config.initial_on_hand,
                    lead_time=config.lead_time,
                    policy=candidate_policy,
                    holding_cost_per_unit=config.holding_cost_per_unit,
                    stockout_cost_per_unit=config.stockout_cost_per_unit,
                    order_cost_per_order=config.order_cost_per_order,
                    order_cost_per_unit=config.order_cost_per_unit,
                )
                target_costs[target] = simulation.summary.total_cost
            window_costs[window] = target_costs
        results[article_id] = window_costs
    return results


def percentile_forecast_optimisation(
    articles: Mapping[str, ForecastCandidatesConfig],
    candidate_targets: Iterable[float | str] | None = None,
    *,
    policy_mode: str = "base_stock",
) -> dict[str, PercentileForecastOptimizationResult]:
    """Alias for optimizing percentile forecast targets without safety stock."""
    return optimize_forecast_targets(
        articles, candidate_targets, policy_mode=policy_mode
    )


def optimize_aggregation_windows(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_windows: Iterable[int],
) -> dict[str, AggregationWindowOptimizationResult]:
    """Pick the aggregation window that minimizes total cost."""
    windows = list(candidate_windows)
    if not windows:
        raise ValueError("Aggregation windows must be provided.")
    if any(window <= 0 for window in windows):
        raise ValueError("Aggregation windows must be positive.")

    results: dict[str, AggregationWindowOptimizationResult] = {}
    for article_id, config in articles.items():
        best_result: AggregationWindowOptimizationResult | None = None
        for window in windows:
            if hasattr(config.policy, "aggregation_window"):
                replace_kwargs: dict[str, object] = {"aggregation_window": window}
                if hasattr(config.policy, "review_period"):
                    replace_kwargs["review_period"] = window
                if hasattr(config.policy, "forecast_horizon"):
                    replace_kwargs["forecast_horizon"] = window
                if hasattr(config.policy, "rmse_window"):
                    replace_kwargs["rmse_window"] = window
                aggregated_policy = dataclass_replace(
                    config.policy, **replace_kwargs
                )
            else:
                aggregated_policy = config.policy
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=aggregated_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )
            simulation = _attach_metadata(
                simulation,
                aggregation_window=window,
                review_period=getattr(aggregated_policy, "review_period", None),
                forecast_horizon=getattr(aggregated_policy, "forecast_horizon", None),
                rmse_window=getattr(aggregated_policy, "rmse_window", None),
            )
            candidate = AggregationWindowOptimizationResult(
                window=window,
                simulation=simulation,
                policy=aggregated_policy
                if isinstance(
                    aggregated_policy,
                    (
                        ForecastSeriesPolicy,
                        ForecastBasedPolicy,
                        PointForecastOptimizationPolicy,
                        PercentileForecastOptimizationPolicy,
                    ),
                )
                else None,
            )
            if best_result is None:
                best_result = candidate
                continue
            if simulation.summary.total_cost < best_result.simulation.summary.total_cost:
                best_result = candidate
        if best_result is None:
            raise RuntimeError("No optimization result computed.")
        results[article_id] = best_result
    return results


def optimize_aggregation_and_service_level_factors(
    articles: Mapping[str, ArticleSimulationConfig],
    candidate_windows: Iterable[int],
    candidate_factors: Iterable[float],
    service_level_mode: str | None = None,
    safety_stock_method: str | None = None,
) -> dict[str, AggregationServiceLevelOptimizationResult]:
    """Pick the aggregation window and service-level factor that minimize total cost."""
    windows = list(candidate_windows)
    if not windows:
        raise ValueError("Aggregation windows must be provided.")
    if any(window <= 0 for window in windows):
        raise ValueError("Aggregation windows must be positive.")

    factors = list(candidate_factors)

    results: dict[str, AggregationServiceLevelOptimizationResult] = {}
    for article_id, config in articles.items():
        policy = config.policy
        if not isinstance(
            policy,
            (
                ForecastBasedPolicy,
                PointForecastOptimizationPolicy,
                LeadTimeForecastOptimizationPolicy,
                RopPointForecastOptimizationPolicy,
            ),
        ):
            raise TypeError(
                "Aggregation with service-level optimization requires point-forecast policies."
            )
        mode = _resolve_service_level_mode(policy, service_level_mode)
        _validate_service_level_candidates(factors, mode)

        best_result: AggregationServiceLevelOptimizationResult | None = None
        for window in windows:
            for factor in factors:
                candidate_policy = _candidate_policy_for(
                    policy,
                    forecast=policy.forecast,
                    actuals=policy.actuals,
                    lead_time=config.lead_time,
                    factor=factor,
                    mode=mode,
                    fixed_rmse=getattr(policy, "fixed_rmse", None),
                    aggregation_window=window,
                    safety_stock_method=safety_stock_method,
                )
                simulation = simulate_replenishment(
                    periods=config.periods,
                    demand=config.demand,
                    initial_on_hand=config.initial_on_hand,
                    lead_time=config.lead_time,
                    policy=candidate_policy,
                    holding_cost_per_unit=config.holding_cost_per_unit,
                    stockout_cost_per_unit=config.stockout_cost_per_unit,
                    order_cost_per_order=config.order_cost_per_order,
                    order_cost_per_unit=config.order_cost_per_unit,
                )
                simulation = _attach_metadata(
                    simulation,
                    service_level_factor=factor,
                    service_level_mode=mode,
                    safety_stock_method=getattr(candidate_policy, "safety_stock_method", None),
                    aggregation_window=window,
                    review_period=getattr(candidate_policy, "review_period", None),
                    forecast_horizon=getattr(candidate_policy, "forecast_horizon", None),
                    rmse_window=getattr(candidate_policy, "rmse_window", None),
                )
                candidate = AggregationServiceLevelOptimizationResult(
                    window=window,
                    service_level_factor=factor,
                    policy=candidate_policy,
                    simulation=simulation,
                )
                if best_result is None:
                    best_result = candidate
                    continue
                if (
                    simulation.summary.total_cost
                    < best_result.simulation.summary.total_cost
                ):
                    best_result = candidate

        if best_result is None:
            raise RuntimeError("No optimization result computed.")
        results[article_id] = best_result

    return results


def optimize_aggregation_and_forecast_targets(
    articles: Mapping[str, ForecastCandidatesConfig],
    candidate_windows: Iterable[int],
    candidate_targets: Iterable[float | str] | None = None,
    *,
    policy_mode: str = "base_stock",
) -> dict[str, AggregationForecastTargetOptimizationResult]:
    """Pick the review window and forecast target that minimize total cost."""
    windows = list(candidate_windows)
    if not windows:
        raise ValueError("Aggregation windows must be provided.")
    if any(window <= 0 for window in windows):
        raise ValueError("Aggregation windows must be positive.")

    target_candidates = list(candidate_targets) if candidate_targets is not None else None
    results: dict[str, AggregationForecastTargetOptimizationResult] = {}
    for article_id, config in articles.items():
        if not config.forecast_candidates:
            raise ValueError("Forecast candidates must be provided.")
        candidate_series = {
            target: list(series) if not callable(series) else series
            for target, series in config.forecast_candidates.items()
        }
        targets = (
            list(target_candidates)
            if target_candidates is not None
            else list(candidate_series.keys())
        )
        if not targets:
            raise ValueError("Candidate targets must be provided.")

        best_result: AggregationForecastTargetOptimizationResult | None = None
        for window in windows:
            for target in targets:
                if target not in candidate_series:
                    raise ValueError(f"Unknown forecast target: {target}")
                if policy_mode == "rop":
                    candidate_policy = RopPercentileForecastOptimizationPolicy(
                        forecast=candidate_series[target],
                        lead_time=config.lead_time,
                        aggregation_window=window,
                        review_period=window,
                        forecast_horizon=window,
                    )
                elif policy_mode == "base_stock":
                    candidate_policy = PercentileForecastOptimizationPolicy(
                        forecast=candidate_series[target],
                        lead_time=config.lead_time,
                        aggregation_window=window,
                        review_period=window,
                        forecast_horizon=window,
                    )
                else:
                    raise ValueError("policy_mode must be 'base_stock' or 'rop'.")
                simulation = simulate_replenishment(
                    periods=config.periods,
                    demand=config.demand,
                    initial_on_hand=config.initial_on_hand,
                    lead_time=config.lead_time,
                    policy=candidate_policy,
                    holding_cost_per_unit=config.holding_cost_per_unit,
                    stockout_cost_per_unit=config.stockout_cost_per_unit,
                    order_cost_per_order=config.order_cost_per_order,
                    order_cost_per_unit=config.order_cost_per_unit,
                )
                simulation = _attach_metadata(
                    simulation,
                    aggregation_window=window,
                    percentile_target=target,
                    review_period=getattr(candidate_policy, "review_period", None),
                    forecast_horizon=getattr(candidate_policy, "forecast_horizon", None),
                )
                candidate = AggregationForecastTargetOptimizationResult(
                    window=window,
                    target=target,
                    policy=candidate_policy,
                    simulation=simulation,
                )
                if best_result is None:
                    best_result = candidate
                    continue
                if (
                    simulation.summary.total_cost
                    < best_result.simulation.summary.total_cost
                ):
                    best_result = candidate

        if best_result is None:
            raise RuntimeError("No optimization result computed.")
        results[article_id] = best_result

    return results


@dataclass(frozen=True)
class EmpiricalCalibrationConfig:
    """Inputs for empirical multiplier calibration.

    The calibration will find the smallest multiplier that achieves
    the target lost sales rate during backtesting.
    """

    periods: int
    demand: Iterable[int] | DemandModel
    forecast: Iterable[int] | DemandModel
    initial_on_hand: int
    lead_time: int
    holding_cost_per_unit: float = 0.0
    stockout_cost_per_unit: float = 0.0
    order_cost_per_order: float = 0.0
    order_cost_per_unit: float = 0.0


@dataclass(frozen=True)
class EmpiricalCalibrationResult:
    """Result of empirical multiplier calibration."""

    multiplier: float
    lost_sales_rate: float
    policy: EmpiricalMultiplierPolicy | RopEmpiricalMultiplierPolicy
    simulation: SimulationResult


def calibrate_empirical_multipliers(
    articles: Mapping[str, EmpiricalCalibrationConfig],
    candidate_multipliers: Iterable[float],
    target_lost_sales_rate: float = 0.05,
    *,
    policy_mode: str = "base_stock",
) -> dict[str, EmpiricalCalibrationResult]:
    """Calibrate forecast multipliers to achieve a target lost sales rate.

    For each article, this function simulates with different multipliers
    and selects the smallest multiplier that achieves <= target_lost_sales_rate.

    Parameters
    ----------
    articles : Mapping[str, EmpiricalCalibrationConfig]
        Configuration for each article to calibrate.
    candidate_multipliers : Iterable[float]
        Multipliers to try (e.g., [1.0, 1.1, 1.2, ..., 2.0]).
        Should be sorted in ascending order for efficiency.
    target_lost_sales_rate : float
        Target maximum lost sales rate (e.g., 0.05 for 5% lost sales).
    policy_mode : str
        Either "base_stock" or "rop" for reorder-point policy.

    Returns
    -------
    dict[str, EmpiricalCalibrationResult]
        Calibration results for each article.
    """
    multipliers = sorted(set(candidate_multipliers))
    if not multipliers:
        raise ValueError("Candidate multipliers must be provided.")
    if any(m < 0 for m in multipliers):
        raise ValueError("Multipliers must be non-negative.")
    if not 0.0 <= target_lost_sales_rate <= 1.0:
        raise ValueError("Target lost sales rate must be between 0 and 1.")

    results: dict[str, EmpiricalCalibrationResult] = {}

    for article_id, config in articles.items():
        # Cache iterables to avoid exhaustion when looping over multipliers
        demand = config.demand if callable(config.demand) else list(config.demand)
        forecast = config.forecast if callable(config.forecast) else list(config.forecast)

        best_result: EmpiricalCalibrationResult | None = None
        fallback_result: EmpiricalCalibrationResult | None = None

        for multiplier in multipliers:
            if policy_mode == "rop":
                candidate_policy = RopEmpiricalMultiplierPolicy(
                    forecast=forecast,
                    lead_time=config.lead_time,
                    multiplier=multiplier,
                )
            elif policy_mode == "base_stock":
                candidate_policy = EmpiricalMultiplierPolicy(
                    forecast=forecast,
                    lead_time=config.lead_time,
                    multiplier=multiplier,
                )
            else:
                raise ValueError("policy_mode must be 'base_stock' or 'rop'.")

            simulation = simulate_replenishment(
                periods=config.periods,
                demand=demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=candidate_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )

            # Calculate lost sales rate
            total_demand = simulation.summary.total_demand
            total_fulfilled = simulation.summary.total_fulfilled
            if total_demand > 0:
                lost_sales_rate = (total_demand - total_fulfilled) / total_demand
            else:
                lost_sales_rate = 0.0

            simulation = _attach_metadata(
                simulation,
                service_level_factor=multiplier,
                service_level_mode="empirical_multiplier",
                aggregation_window=getattr(candidate_policy, "aggregation_window", None),
                review_period=getattr(candidate_policy, "review_period", None),
                forecast_horizon=getattr(candidate_policy, "forecast_horizon", None),
            )

            candidate = EmpiricalCalibrationResult(
                multiplier=multiplier,
                lost_sales_rate=lost_sales_rate,
                policy=candidate_policy,
                simulation=simulation,
            )

            # Track the best result that meets target
            if lost_sales_rate <= target_lost_sales_rate:
                if best_result is None or multiplier < best_result.multiplier:
                    best_result = candidate
                    # We found a valid result; since multipliers are sorted,
                    # we can stop here to get the smallest valid multiplier
                    break

            # Track fallback (lowest lost sales rate even if above target)
            if fallback_result is None or lost_sales_rate < fallback_result.lost_sales_rate:
                fallback_result = candidate

        # Use best result if found, otherwise use fallback with lowest lost sales
        if best_result is not None:
            results[article_id] = best_result
        elif fallback_result is not None:
            results[article_id] = fallback_result
        else:
            raise RuntimeError("No calibration result computed.")

    return results


def evaluate_empirical_multiplier_lost_sales(
    articles: Mapping[str, EmpiricalCalibrationConfig],
    candidate_multipliers: Iterable[float],
    *,
    policy_mode: str = "base_stock",
) -> dict[str, dict[float, float]]:
    """Return lost sales rates for each multiplier per article.

    This is useful for analyzing how different multipliers affect
    lost sales before selecting a target.
    """
    multipliers = list(candidate_multipliers)
    if not multipliers:
        raise ValueError("Candidate multipliers must be provided.")

    results: dict[str, dict[float, float]] = {}

    for article_id, config in articles.items():
        # Cache iterables to avoid exhaustion when looping over multipliers
        demand = config.demand if callable(config.demand) else list(config.demand)
        forecast = config.forecast if callable(config.forecast) else list(config.forecast)

        multiplier_rates: dict[float, float] = {}

        for multiplier in multipliers:
            if policy_mode == "rop":
                candidate_policy = RopEmpiricalMultiplierPolicy(
                    forecast=forecast,
                    lead_time=config.lead_time,
                    multiplier=multiplier,
                )
            elif policy_mode == "base_stock":
                candidate_policy = EmpiricalMultiplierPolicy(
                    forecast=forecast,
                    lead_time=config.lead_time,
                    multiplier=multiplier,
                )
            else:
                raise ValueError("policy_mode must be 'base_stock' or 'rop'.")

            simulation = simulate_replenishment(
                periods=config.periods,
                demand=demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=candidate_policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
                order_cost_per_order=config.order_cost_per_order,
                order_cost_per_unit=config.order_cost_per_unit,
            )

            total_demand = simulation.summary.total_demand
            total_fulfilled = simulation.summary.total_fulfilled
            if total_demand > 0:
                lost_sales_rate = (total_demand - total_fulfilled) / total_demand
            else:
                lost_sales_rate = 0.0

            multiplier_rates[multiplier] = lost_sales_rate

        results[article_id] = multiplier_rates

    return results
