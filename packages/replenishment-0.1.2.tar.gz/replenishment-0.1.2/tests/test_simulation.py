import pytest

from replenishment import (
    ArticleSimulationConfig,
    EmpiricalMultiplierPolicy,
    ForecastBasedPolicy,
    ForecastCandidatesConfig,
    InventoryState,
    PercentileForecastOptimizationPolicy,
    PointForecastOptimizationPolicy,
    ReorderPointPolicy,
    evaluate_aggregation_and_forecast_target_costs,
    evaluate_aggregation_and_service_level_factor_costs,
    evaluate_forecast_target_costs,
    evaluate_service_level_factor_costs,
    optimize_aggregation_and_forecast_targets,
    optimize_aggregation_and_service_level_factors,
    simulate_replenishment_with_aggregation,
    optimize_aggregation_windows,
    optimize_forecast_targets,
    optimize_k_rmse_factors,
    optimize_k_rmse_factors_for_fill_rate,
    optimize_service_level_factors,
    percentile_forecast_optimisation,
    point_forecast_optimisation,
    simulate_replenishment,
)
from replenishment.aggregation import (
    aggregate_lead_time,
    aggregate_periods,
    aggregate_series,
)

def test_simulation_summary_consistency():
    policy = ReorderPointPolicy(reorder_point=10, order_quantity=20)
    result = simulate_replenishment(
        periods=4,
        demand=[5, 15, 8, 12],
        initial_on_hand=10,
        lead_time=1,
        policy=policy,
        holding_cost_per_unit=0.5,
        stockout_cost_per_unit=2.0,
    )

    assert result.summary.total_demand == 40
    assert result.summary.total_fulfilled <= result.summary.total_demand
    assert 0 <= result.summary.fill_rate <= 1
    assert result.summary.holding_cost >= 0
    assert result.summary.stockout_cost >= 0
    assert (
        result.summary.total_cost
        == result.summary.holding_cost
        + result.summary.stockout_cost
        + result.summary.ordering_cost
    )


def test_simulation_includes_ordering_costs():
    policy = ReorderPointPolicy(reorder_point=5, order_quantity=10)
    result = simulate_replenishment(
        periods=2,
        demand=[6, 6],
        initial_on_hand=0,
        lead_time=0,
        policy=policy,
        holding_cost_per_unit=0.0,
        stockout_cost_per_unit=0.0,
        order_cost_per_order=3.0,
        order_cost_per_unit=0.5,
    )

    assert result.summary.ordering_cost == 2 * (3.0 + 0.5 * 10)


def test_point_forecast_policy_orders_forecast_plus_safety_stock():
    policy = PointForecastOptimizationPolicy(
        forecast=[10, 12, 11],
        actuals=[9, 14, 10],
        lead_time=1,
        service_level_factor=1.0,
    )
    state_period0 = InventoryState(period=0, on_hand=0, on_order=0, backorders=0)
    state_period1 = InventoryState(period=1, on_hand=0, on_order=0, backorders=0)

    assert policy.order_quantity_for(state_period0) == 12
    assert policy.order_quantity_for(state_period1) == 13


def test_point_forecast_policy_uses_last_forecast_value_for_horizon():
    policy = PointForecastOptimizationPolicy(
        forecast=[18, 22, 20, 19, 21, 23],
        actuals=[20, 21, 19, 18, 22, 24],
        lead_time=1,
        service_level_factor=0.0,
    )
    state_period5 = InventoryState(period=5, on_hand=0, on_order=0, backorders=0)

    assert policy.order_quantity_for(state_period5) == 23


def test_point_forecast_policy_scales_safety_stock_with_high_forecast():
    baseline = PointForecastOptimizationPolicy(
        forecast=[10, 10, 10, 10, 10],
        actuals=[10, 10, 10, 10, 10],
        lead_time=1,
        forecast_horizon=2,
        service_level_factor=1.0,
        fixed_rmse=4.0,
        demand_buffer_reference=20.0,
        demand_buffer_strength=0.5,
    )
    peak = PointForecastOptimizationPolicy(
        forecast=[10, 10, 10, 20, 20],
        actuals=[10, 10, 10, 10, 10],
        lead_time=1,
        forecast_horizon=2,
        service_level_factor=1.0,
        fixed_rmse=4.0,
        demand_buffer_reference=20.0,
        demand_buffer_strength=0.5,
    )
    state = InventoryState(period=1, on_hand=0, on_order=0, backorders=0)

    assert baseline.order_quantity_for(state) == 27
    assert peak.order_quantity_for(state) == 39


def test_point_forecast_policy_rejects_invalid_demand_buffer_values():
    with pytest.raises(ValueError, match="Demand buffer strength"):
        PointForecastOptimizationPolicy(
            forecast=[10, 10],
            actuals=[10, 10],
            demand_buffer_strength=-0.1,
        )

    with pytest.raises(ValueError, match="Demand buffer reference"):
        PointForecastOptimizationPolicy(
            forecast=[10, 10],
            actuals=[10, 10],
            demand_buffer_reference=0.0,
        )

    with pytest.raises(ValueError, match="Demand buffer max multiplier"):
        PointForecastOptimizationPolicy(
            forecast=[10, 10],
            actuals=[10, 10],
            demand_buffer_max_multiplier=0.5,
        )


def test_point_forecast_fill_rate_uses_protection_window_demand():
    point_policy = PointForecastOptimizationPolicy(
        forecast=[10, 20, 30, 40, 50],
        actuals=[10, 20, 30, 40, 50],
        lead_time=2,
        forecast_horizon=1,
        service_level_factor=0.95,
        service_level_mode="fill_rate",
        fixed_rmse=2.0,
    )
    reference_policy = ForecastBasedPolicy(
        forecast=[10, 20, 30, 40, 50],
        actuals=[10, 20, 30, 40, 50],
        lead_time=2,
        forecast_horizon=1,
        service_level_factor=0.95,
        service_level_mode="fill_rate",
        fixed_rmse=2.0,
    )
    state_period1 = InventoryState(period=1, on_hand=0, on_order=0, backorders=0)

    assert point_policy.order_quantity_for(state_period1) == reference_policy.order_quantity_for(
        state_period1
    )


def test_empirical_multiplier_policy_uses_lead_time_offset_for_forecast_horizon():
    policy = EmpiricalMultiplierPolicy(
        forecast=[10, 20, 30, 40, 50],
        lead_time=2,
        forecast_horizon=2,
        multiplier=1.0,
    )
    state_period0 = InventoryState(period=0, on_hand=0, on_order=0, backorders=0)

    assert policy.order_quantity_for(state_period0) == 70


def test_optimize_point_forecast_selects_lowest_cost():
    forecast = [10, 10, 10, 10, 10]
    actuals = [8, 12, 9, 11, 10]
    candidates = [0.0, 1.5, 3.0]
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        service_level_factor=0.0,
    )
    config = ArticleSimulationConfig(
        periods=4,
        demand=actuals[:4],
        initial_on_hand=5,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=2.0,
        stockout_cost_per_unit=2.0,
    )

    results = point_forecast_optimisation({"A": config}, candidates)
    result = results["A"]

    candidate_costs = []
    for factor in candidates:
        policy = PointForecastOptimizationPolicy(
            forecast=forecast,
            actuals=actuals,
            lead_time=1,
            service_level_factor=factor,
        )
        simulation = simulate_replenishment(
            periods=config.periods,
            demand=config.demand,
            initial_on_hand=config.initial_on_hand,
            lead_time=config.lead_time,
            policy=policy,
            holding_cost_per_unit=config.holding_cost_per_unit,
            stockout_cost_per_unit=config.stockout_cost_per_unit,
        )
        candidate_costs.append(simulation.summary.total_cost)

    expected_factor = candidates[candidate_costs.index(min(candidate_costs))]
    assert result.service_level_factor == expected_factor
    legacy_results = optimize_service_level_factors({"A": config}, candidates)
    assert legacy_results["A"].service_level_factor == expected_factor


def test_optimize_service_level_factors_preserves_custom_forecast_horizon():
    forecast = [4, 6, 5, 7, 8]
    actuals = [5, 5, 6, 6, 7]
    factor = 0.0
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        aggregation_window=1,
        review_period=1,
        forecast_horizon=3,
        rmse_window=1,
        service_level_factor=factor,
    )
    config = ArticleSimulationConfig(
        periods=3,
        demand=[5, 6, 7],
        initial_on_hand=0,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=1.0,
    )

    result = optimize_service_level_factors({"A": config}, [factor])["A"]

    expected_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        aggregation_window=1,
        review_period=1,
        forecast_horizon=3,
        rmse_window=1,
        service_level_factor=factor,
    )
    expected_simulation = simulate_replenishment(
        periods=config.periods,
        demand=config.demand,
        initial_on_hand=config.initial_on_hand,
        lead_time=config.lead_time,
        policy=expected_policy,
        holding_cost_per_unit=config.holding_cost_per_unit,
        stockout_cost_per_unit=config.stockout_cost_per_unit,
    )

    assert result.service_level_factor == factor
    assert result.simulation.metadata is not None
    assert result.simulation.metadata.forecast_horizon == 3
    assert (
        result.simulation.summary.total_cost
        == expected_simulation.summary.total_cost
    )


def test_percentile_forecast_policy_orders_forecast():
    policy = PercentileForecastOptimizationPolicy(forecast=[10, 12], lead_time=1)
    state_period0 = InventoryState(period=0, on_hand=0, on_order=0, backorders=0)

    assert policy.order_quantity_for(state_period0) == 12


def test_percentile_forecast_policy_uses_last_value_for_horizon():
    policy = PercentileForecastOptimizationPolicy(forecast=[10, 12], lead_time=1)
    state_period1 = InventoryState(period=1, on_hand=0, on_order=0, backorders=0)

    assert policy.order_quantity_for(state_period1) == 12


def test_optimize_percentile_forecast_selects_lowest_cost():
    config = ForecastCandidatesConfig(
        periods=2,
        demand=[10, 10],
        initial_on_hand=0,
        lead_time=0,
        forecast_candidates={
            "mean": [10, 10],
            "45-high": [20, 20],
        },
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=0.0,
    )

    results = percentile_forecast_optimisation({"A": config})

    assert results["A"].target == "mean"
    legacy_results = optimize_forecast_targets({"A": config})
    assert legacy_results["A"].target == "mean"


def test_evaluate_forecast_target_costs_matches_simulation():
    config = ForecastCandidatesConfig(
        periods=2,
        demand=[10, 10],
        initial_on_hand=0,
        lead_time=0,
        forecast_candidates={
            "mean": [10, 10],
            "45-high": [20, 20],
        },
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=0.0,
    )

    costs = evaluate_forecast_target_costs({"A": config})

    expected: dict[str, float] = {}
    for target, forecast in config.forecast_candidates.items():
        policy = PercentileForecastOptimizationPolicy(
            forecast=forecast,
            lead_time=config.lead_time,
        )
        simulation = simulate_replenishment(
            periods=config.periods,
            demand=config.demand,
            initial_on_hand=config.initial_on_hand,
            lead_time=config.lead_time,
            policy=policy,
            holding_cost_per_unit=config.holding_cost_per_unit,
            stockout_cost_per_unit=config.stockout_cost_per_unit,
        )
        expected[target] = simulation.summary.total_cost

    assert costs["A"] == expected


def test_evaluate_service_level_factor_costs_matches_simulation():
    forecast = [10, 10]
    actuals = [9, 11]
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        service_level_factor=0.0,
    )
    config = ArticleSimulationConfig(
        periods=2,
        demand=actuals,
        initial_on_hand=0,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=2.0,
    )
    factors = [0.0, 1.0]

    costs = evaluate_service_level_factor_costs({"A": config}, factors)

    expected: dict[float, float] = {}
    for factor in factors:
        policy = PointForecastOptimizationPolicy(
            forecast=forecast,
            actuals=actuals,
            lead_time=1,
            service_level_factor=factor,
        )
        simulation = simulate_replenishment(
            periods=config.periods,
            demand=config.demand,
            initial_on_hand=config.initial_on_hand,
            lead_time=config.lead_time,
            policy=policy,
            holding_cost_per_unit=config.holding_cost_per_unit,
            stockout_cost_per_unit=config.stockout_cost_per_unit,
        )
        expected[factor] = simulation.summary.total_cost

    assert costs["A"] == expected


def test_evaluate_service_level_factor_costs_preserves_custom_forecast_horizon():
    forecast = [4, 6, 5, 7, 8]
    actuals = [5, 5, 6, 6, 7]
    factor = 0.0
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        aggregation_window=1,
        review_period=1,
        forecast_horizon=3,
        rmse_window=1,
        service_level_factor=factor,
    )
    config = ArticleSimulationConfig(
        periods=3,
        demand=[5, 6, 7],
        initial_on_hand=0,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=1.0,
    )

    costs = evaluate_service_level_factor_costs({"A": config}, [factor])

    expected_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        aggregation_window=1,
        review_period=1,
        forecast_horizon=3,
        rmse_window=1,
        service_level_factor=factor,
    )
    expected_simulation = simulate_replenishment(
        periods=config.periods,
        demand=config.demand,
        initial_on_hand=config.initial_on_hand,
        lead_time=config.lead_time,
        policy=expected_policy,
        holding_cost_per_unit=config.holding_cost_per_unit,
        stockout_cost_per_unit=config.stockout_cost_per_unit,
    )

    assert costs["A"][factor] == expected_simulation.summary.total_cost


def test_evaluate_aggregation_and_forecast_target_costs_matches_simulation():
    config = ForecastCandidatesConfig(
        periods=4,
        demand=[1, 2, 3, 4],
        initial_on_hand=0,
        lead_time=1,
        forecast_candidates={
            "mean": [1, 2, 3, 4],
            "p90": [2, 3, 4, 5],
        },
        holding_cost_per_unit=0.5,
        stockout_cost_per_unit=1.0,
    )
    window = 2

    costs = evaluate_aggregation_and_forecast_target_costs(
        {"A": config},
        candidate_windows=[window],
    )

    expected: dict[str, float] = {}
    for target, forecast in config.forecast_candidates.items():
        policy = PercentileForecastOptimizationPolicy(
            forecast=forecast,
            lead_time=config.lead_time,
            aggregation_window=window,
            review_period=window,
            forecast_horizon=window,
        )
        simulation = simulate_replenishment(
            periods=config.periods,
            demand=config.demand,
            initial_on_hand=config.initial_on_hand,
            lead_time=config.lead_time,
            policy=policy,
            holding_cost_per_unit=config.holding_cost_per_unit,
            stockout_cost_per_unit=config.stockout_cost_per_unit,
        )
        expected[target] = simulation.summary.total_cost

    assert costs["A"][window] == expected


def test_evaluate_aggregation_and_service_level_factor_costs_matches_simulation():
    forecast = [10, 10, 10, 10]
    actuals = [9, 11, 10, 8]
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        service_level_factor=0.0,
    )
    config = ArticleSimulationConfig(
        periods=4,
        demand=actuals,
        initial_on_hand=0,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=2.0,
    )
    window = 2
    factors = [0.0, 1.0]

    costs = evaluate_aggregation_and_service_level_factor_costs(
        {"A": config},
        candidate_windows=[window],
        candidate_factors=factors,
    )

    expected: dict[float, float] = {}
    for factor in factors:
        policy = PointForecastOptimizationPolicy(
            forecast=forecast,
            actuals=actuals,
            lead_time=config.lead_time,
            service_level_factor=factor,
            aggregation_window=window,
        )
        simulation = simulate_replenishment(
            periods=config.periods,
            demand=config.demand,
            initial_on_hand=config.initial_on_hand,
            lead_time=config.lead_time,
            policy=policy,
            holding_cost_per_unit=config.holding_cost_per_unit,
            stockout_cost_per_unit=config.stockout_cost_per_unit,
        )
        expected[factor] = simulation.summary.total_cost

    assert costs["A"][window] == expected


def test_simulation_with_aggregation_groups_demand():
    policy = ReorderPointPolicy(reorder_point=-1, order_quantity=0)
    result = simulate_replenishment_with_aggregation(
        periods=6,
        demand=[1, 2, 3, 4, 5, 6],
        initial_on_hand=100,
        lead_time=0,
        policy=policy,
        aggregation_window=3,
    )

    assert len(result.snapshots) == 6
    assert [snapshot.demand for snapshot in result.snapshots] == [1, 2, 3, 4, 5, 6]
    assert result.summary.total_demand == 21


def test_simulation_with_aggregation_truncates_demand_to_periods():
    policy = ReorderPointPolicy(reorder_point=-1, order_quantity=0)
    result = simulate_replenishment_with_aggregation(
        periods=5,
        demand=[1, 2, 3, 4, 5, 6],
        initial_on_hand=100,
        lead_time=0,
        policy=policy,
        aggregation_window=3,
    )

    assert [snapshot.demand for snapshot in result.snapshots] == [1, 2, 3, 4, 5]
    assert result.summary.total_demand == 15


def test_simulation_with_aggregation_allows_empty_actuals():
    policy = PointForecastOptimizationPolicy(
        forecast=[10, 12],
        actuals=[],
        lead_time=0,
        service_level_factor=1.0,
    )
    result = simulate_replenishment_with_aggregation(
        periods=2,
        demand=[10, 11],
        initial_on_hand=0,
        lead_time=0,
        policy=policy,
        aggregation_window=1,
    )

    assert len(result.snapshots) == 2


def test_optimize_aggregation_windows_picks_first_best():
    policy = ReorderPointPolicy(reorder_point=-1, order_quantity=0)
    config = ArticleSimulationConfig(
        periods=4,
        demand=[1, 1, 1, 1],
        initial_on_hand=0,
        lead_time=0,
        policy=policy,
        holding_cost_per_unit=0.0,
        stockout_cost_per_unit=0.0,
    )

    results = optimize_aggregation_windows({"A": config}, [1, 2])

    assert results["A"].window == 1
    assert len(results["A"].simulation.snapshots) == 4


def test_optimize_aggregation_and_service_level_factors_picks_lowest_cost():
    forecast = [10, 10, 10, 10]
    actuals = [8, 12, 9, 11]
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        service_level_factor=0.0,
    )
    config = ArticleSimulationConfig(
        periods=4,
        demand=actuals,
        initial_on_hand=0,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=2.0,
    )
    windows = [1, 2]
    factors = [0.0, 2.0]

    results = optimize_aggregation_and_service_level_factors(
        {"A": config},
        candidate_windows=windows,
        candidate_factors=factors,
    )
    result = results["A"]

    candidate_costs = {}
    for window in windows:
        for factor in factors:
            policy = PointForecastOptimizationPolicy(
                forecast=forecast,
                actuals=actuals,
                lead_time=config.lead_time,
                service_level_factor=factor,
                aggregation_window=window,
            )
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
            )
            candidate_costs[(window, factor)] = simulation.summary.total_cost

    expected_window, expected_factor = min(
        candidate_costs, key=candidate_costs.get
    )
    assert result.window == expected_window
    assert result.service_level_factor == expected_factor


def test_optimize_aggregation_and_forecast_targets_picks_lowest_cost():
    config = ForecastCandidatesConfig(
        periods=4,
        demand=[5, 5, 5, 5],
        initial_on_hand=0,
        lead_time=0,
        forecast_candidates={
            "p50": [5, 5, 5, 5],
            "p90": [8, 8, 8, 8],
        },
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=0.5,
    )
    windows = [1, 2]

    results = optimize_aggregation_and_forecast_targets(
        {"A": config},
        candidate_windows=windows,
    )
    result = results["A"]

    candidate_costs = {}
    for window in windows:
        for target, forecast in config.forecast_candidates.items():
            policy = PercentileForecastOptimizationPolicy(
                forecast=forecast,
                lead_time=config.lead_time,
                aggregation_window=window,
                review_period=window,
                forecast_horizon=window,
            )
            simulation = simulate_replenishment(
                periods=config.periods,
                demand=config.demand,
                initial_on_hand=config.initial_on_hand,
                lead_time=config.lead_time,
                policy=policy,
                holding_cost_per_unit=config.holding_cost_per_unit,
                stockout_cost_per_unit=config.stockout_cost_per_unit,
            )
            candidate_costs[(window, target)] = simulation.summary.total_cost

    expected_window, expected_target = min(
        candidate_costs, key=candidate_costs.get
    )
    assert result.window == expected_window
    assert result.target == expected_target


def test_optimize_aggregation_and_forecast_targets_accepts_generator_targets():
    candidate_configs = {
        "A": ForecastCandidatesConfig(
            periods=2,
            demand=[5, 5],
            initial_on_hand=0,
            lead_time=0,
            forecast_candidates={"p50": [5, 5], "p90": [7, 7]},
        ),
        "B": ForecastCandidatesConfig(
            periods=2,
            demand=[6, 6],
            initial_on_hand=0,
            lead_time=0,
            forecast_candidates={"p50": [6, 6], "p90": [8, 8]},
        ),
    }
    target_generator = (target for target in ["p50", "p90"])

    results = optimize_aggregation_and_forecast_targets(
        candidate_configs,
        candidate_windows=[1],
        candidate_targets=target_generator,
    )

    assert set(results.keys()) == {"A", "B"}


def test_optimize_aggregation_and_service_level_handles_short_actuals():
    policy = PointForecastOptimizationPolicy(
        forecast=[10, 11, 12, 13],
        actuals=[9, 12],
        lead_time=1,
        service_level_factor=0.0,
    )
    config = ArticleSimulationConfig(
        periods=4,
        demand=[10, 11, 12, 13],
        initial_on_hand=0,
        lead_time=1,
        policy=policy,
    )

    results = optimize_aggregation_and_service_level_factors(
        {"A": config},
        candidate_windows=[1, 2],
        candidate_factors=[0.0, 1.0],
    )

    assert results["A"].service_level_factor in {0.0, 1.0}


def test_optimize_aggregation_and_forecast_targets_handles_generator_series():
    candidate_configs = {
        "A": ForecastCandidatesConfig(
            periods=4,
            demand=[5, 6, 5, 6],
            initial_on_hand=0,
            lead_time=0,
            forecast_candidates={
                "p50": (value for value in [5, 6, 5, 6]),
                "p90": (value for value in [7, 8, 7, 8]),
            },
        )
    }

    results = optimize_aggregation_and_forecast_targets(
        candidate_configs,
        candidate_windows=[1, 2],
    )

    assert results["A"].target in {"p50", "p90"}


def test_point_forecast_policy_k_rmse_uses_unscaled_rmse():
    policy = PointForecastOptimizationPolicy(
        forecast=[10, 10, 10, 10, 10, 10],
        actuals=[10, 10, 10, 10, 10, 10],
        lead_time=2,
        forecast_horizon=3,
        service_level_factor=2.0,
        safety_stock_method="k_rmse",
        fixed_rmse=3.0,
    )
    state_period2 = InventoryState(period=2, on_hand=0, on_order=0, backorders=0)

    # forecast qty = 30, safety stock = 2 * 3 = 6
    assert policy.order_quantity_for(state_period2) == 36


def test_optimize_k_rmse_factors_selects_lowest_cost():
    forecast = [10, 10, 10, 10, 10]
    actuals = [8, 12, 9, 11, 10]
    candidates = [0.0, 1.0, 2.0]
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        service_level_factor=0.0,
    )
    config = ArticleSimulationConfig(
        periods=4,
        demand=actuals[:4],
        initial_on_hand=4,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=2.0,
        stockout_cost_per_unit=2.0,
    )

    result = optimize_k_rmse_factors({"A": config}, candidates)["A"]

    candidate_costs = {}
    for k in candidates:
        policy = PointForecastOptimizationPolicy(
            forecast=forecast,
            actuals=actuals,
            lead_time=1,
            service_level_factor=k,
            safety_stock_method="k_rmse",
        )
        simulation = simulate_replenishment(
            periods=config.periods,
            demand=config.demand,
            initial_on_hand=config.initial_on_hand,
            lead_time=config.lead_time,
            policy=policy,
            holding_cost_per_unit=config.holding_cost_per_unit,
            stockout_cost_per_unit=config.stockout_cost_per_unit,
        )
        candidate_costs[k] = simulation.summary.total_cost

    expected_k = min(candidate_costs, key=candidate_costs.get)
    assert result.service_level_factor == expected_k
    assert result.simulation.metadata is not None
    assert result.simulation.metadata.safety_stock_method == "k_rmse"


def test_optimize_k_rmse_factors_for_fill_rate_targets_with_cost_tiebreak():
    forecast = [10, 10, 10, 10, 10, 10]
    actuals = [10, 12, 9, 11, 13, 8]
    candidates = [0.0, 1.0, 2.0, 3.0]
    base_policy = PointForecastOptimizationPolicy(
        forecast=forecast,
        actuals=actuals,
        lead_time=1,
        service_level_factor=0.0,
    )
    config = ArticleSimulationConfig(
        periods=6,
        demand=actuals,
        initial_on_hand=2,
        lead_time=1,
        policy=base_policy,
        holding_cost_per_unit=1.0,
        stockout_cost_per_unit=10.0,
    )
    target_fill_rate = 0.84

    result = optimize_k_rmse_factors_for_fill_rate(
        {"A": config},
        candidates,
        target_fill_rate=target_fill_rate,
    )["A"]

    eligible: dict[float, float] = {}
    for k in candidates:
        policy = PointForecastOptimizationPolicy(
            forecast=forecast,
            actuals=actuals,
            lead_time=1,
            service_level_factor=k,
            safety_stock_method="k_rmse",
        )
        simulation = simulate_replenishment(
            periods=config.periods,
            demand=config.demand,
            initial_on_hand=config.initial_on_hand,
            lead_time=config.lead_time,
            policy=policy,
            holding_cost_per_unit=config.holding_cost_per_unit,
            stockout_cost_per_unit=config.stockout_cost_per_unit,
        )
        if simulation.summary.fill_rate >= target_fill_rate:
            eligible[k] = simulation.summary.total_cost

    assert result.meets_fill_rate_target
    assert result.achieved_fill_rate >= target_fill_rate
    assert result.k == min(eligible, key=eligible.get)
