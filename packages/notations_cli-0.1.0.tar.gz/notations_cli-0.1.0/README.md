<p align="center">
  <img src="logo.png" width="200" />
</p>

<h1 align="center">notations-cli</h1>

<p align="center">
  <a href="https://github.com/takashiishida/notations-cli/actions/workflows/tests.yml"><img src="https://github.com/takashiishida/notations-cli/actions/workflows/tests.yml/badge.svg" alt="Tests"></a>
  <a href="https://pypi.org/project/notations-cli/"><img src="https://img.shields.io/pypi/v/notations-cli?color=blue" alt="PyPI"></a>
  <a href="https://pepy.tech/project/notations-cli"><img src="https://img.shields.io/pepy/dt/notations-cli?color=orange" alt="Downloads"></a>
  <a href="https://github.com/takashiishida/notations-cli/blob/main/LICENSE"><img src="https://img.shields.io/github/license/takashiishida/notations-cli?color=green" alt="License"></a>
</p>

Extract notation tables from arXiv papers using LLMs.

## Installation

```bash
pip install notations-cli
```

Or with uv:

```bash
uv add notations-cli
```

## Usage

```bash
# From arXiv ID
notations 2006.11239

# From arXiv URL
notations https://arxiv.org/abs/2006.11239

# From local .tex files
notations /path/to/tex/folder

# With options
notations 2006.11239 --model gpt-5.2-2025-12-11 --provider openai
notations 2006.11239 --model anthropic/claude-sonnet-4.5 --provider openrouter
notations 2006.11239 --output my_paper    # custom base name → .json/.html/.md
notations 2006.11239 --terminal           # also print table to terminal
notations 2006.11239 --no-comments        # strip LaTeX comments first
notations 2006.11239 --no-expand-macros   # disable macro expansion
notations 2006.11239 --no-filter-body     # keep all extracted notations

# Re-render from existing JSON (no LLM call)
notations 2006_11239_notations.json
notations 2006_11239_notations.json -t    # also print to terminal
```

By default, LaTeX macro definitions (`\newcommand`, etc.) are expanded inline before processing. Use `--no-expand-macros` to disable this.

Notations are also filtered by default to only include symbols that appear in the document body (`\begin{document}...\end{document}`), removing artifacts from preamble-only macro definitions. Use `--no-filter-body` to disable this.

## Configuration

Set your API key as an environment variable:

```bash
# For OpenAI
export OPENAI_API_KEY=...

# For OpenRouter
export OPENROUTER_API_KEY=...
```

## Output

Generates a self-contained HTML file with:
- Paper metadata (title, authors, arXiv link)
- Searchable notation table
- LaTeX rendering via KaTeX

## Development

```bash
git clone https://github.com/takashiishida/notations-cli.git
cd notations-cli
uv sync
uv run pytest
```
