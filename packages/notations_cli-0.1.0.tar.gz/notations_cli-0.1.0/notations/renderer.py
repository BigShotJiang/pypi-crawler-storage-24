"""Render notations into various output formats."""

import json
from importlib import resources

import click


def render_html(notations: list[dict], metadata: dict) -> str:
    """Render notations into the HTML template.

    Args:
        notations: List of notation dicts with "symbol" and "description"
        metadata: Dict with "title", "authors", and "arxiv_id"

    Returns:
        Complete HTML string
    """
    template = resources.files("notations").joinpath("template.html").read_text()

    authors_str = ", ".join(metadata.get("authors", [])) or "Unknown authors"

    html = template.replace("{{TITLE}}", metadata.get("title", "Unknown"))
    html = html.replace("{{AUTHORS}}", authors_str)
    html = html.replace("{{ARXIV_ID}}", metadata.get("arxiv_id", ""))
    html = html.replace("{{NOTATIONS_JSON}}", json.dumps(notations, ensure_ascii=False))

    return html


def render_terminal(notations: list[dict], metadata: dict) -> None:
    """Print notations as a formatted table to stdout.

    Args:
        notations: List of notation dicts with "symbol" and "description"
        metadata: Dict with "title", "authors", and "arxiv_id"
    """
    title = metadata.get("title", "Unknown")
    authors = ", ".join(metadata.get("authors", [])) or "Unknown authors"
    arxiv_id = metadata.get("arxiv_id", "")

    click.echo(f"\n  {title}")
    click.echo(f"  {authors}")
    if arxiv_id:
        click.echo(f"  arXiv:{arxiv_id}")
    click.echo()

    if not notations:
        click.echo("  No notations found.")
        return

    # Compute column widths
    sym_width = max(len(n.get("symbol", "")) for n in notations)
    sym_width = max(sym_width, 6)  # minimum width for header "Symbol"

    header = f"  {'Symbol':<{sym_width}}   Description"
    click.echo(header)
    click.echo(f"  {'─' * sym_width}   {'─' * 40}")

    for n in notations:
        symbol = n.get("symbol", "")
        description = n.get("description", "")
        click.echo(f"  {symbol:<{sym_width}}   {description}")

    click.echo()


def render_json(notations: list[dict], metadata: dict) -> str:
    """Render notations as a JSON string.

    Args:
        notations: List of notation dicts with "symbol" and "description"
        metadata: Dict with "title", "authors", and "arxiv_id"

    Returns:
        JSON string
    """
    data = {
        "metadata": metadata,
        "notations": notations,
    }
    return json.dumps(data, ensure_ascii=False, indent=2)


def render_markdown(notations: list[dict], metadata: dict) -> str:
    """Render notations as a Markdown string.

    Args:
        notations: List of notation dicts with "symbol" and "description"
        metadata: Dict with "title", "authors", and "arxiv_id"

    Returns:
        Markdown string
    """
    title = metadata.get("title", "Unknown")
    authors = ", ".join(metadata.get("authors", [])) or "Unknown authors"
    arxiv_id = metadata.get("arxiv_id", "")

    lines = [f"# {title}", "", f"**Authors:** {authors}"]
    if arxiv_id:
        lines.append(f"**arXiv:** {arxiv_id}")
    lines.append("")

    lines.append("| Symbol | Description |")
    lines.append("|--------|-------------|")
    for n in notations:
        symbol = n.get("symbol", "").replace("|", "\\|")
        description = n.get("description", "").replace("|", "\\|")
        lines.append(f"| ${symbol}$ | {description} |")
    lines.append("")

    return "\n".join(lines)
