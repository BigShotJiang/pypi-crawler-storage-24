"""Command-line interface for notations."""

import json
import os
import sys

import click
from arxiv_to_prompt import process_latex_source

from .extractor import SUPPORTED_OPENAI_MODELS, extract_notations, filter_notations_by_body, get_paper_metadata
from .renderer import render_html, render_json, render_markdown, render_terminal


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("source")
@click.option(
    "--model",
    "-m",
    default="gpt-5.2",
    help=f"Model to use for extraction (default: gpt-5.2). OpenAI: {', '.join(SUPPORTED_OPENAI_MODELS)}. OpenRouter: any model.",
)
@click.option(
    "--provider",
    "-p",
    type=click.Choice(["openai", "openrouter"]),
    default="openai",
    help="API provider (default: openai)",
)
@click.option(
    "--terminal",
    "-t",
    is_flag=True,
    help="Also print notation table to terminal",
)
@click.option(
    "--output",
    "-o",
    type=click.Path(),
    help="Base name for output files (default: <arxiv_id>_notations). Produces .json, .html, .md.",
)
@click.option(
    "--no-comments",
    is_flag=True,
    help="Remove comments from LaTeX source before processing",
)
@click.option(
    "--no-expand-macros",
    is_flag=True,
    help="Disable macro expansion (\\newcommand etc.) in LaTeX source",
)
@click.option(
    "--no-filter-body",
    is_flag=True,
    help="Disable filtering notations by document body presence",
)
@click.option(
    "--no-cache",
    is_flag=True,
    help="Disable caching of downloaded LaTeX source (re-download from arXiv)",
)
def main(source: str, model: str, provider: str, terminal: bool, output: str | None, no_comments: bool, no_expand_macros: bool, no_filter_body: bool, no_cache: bool):
    """Extract notation table from an arXiv paper.

    SOURCE can be:

    \b
      - arXiv ID (e.g., 2006.11239)
      - arXiv URL (e.g., https://arxiv.org/abs/2006.11239)
      - Local folder path containing .tex files
      - A .json file from a previous extraction (skips LLM call)
    """
    # Check if source is a JSON file (re-render mode)
    if source.endswith(".json") and os.path.isfile(source):
        click.echo(f"Loading notations from {source}...", err=True)
        try:
            with open(source, encoding="utf-8") as f:
                data = json.load(f)
            notations = data["notations"]
            metadata = data["metadata"]
        except (json.JSONDecodeError, KeyError) as e:
            click.echo(f"Error loading JSON: {e}", err=True)
            sys.exit(1)

        click.echo(f"Loaded {len(notations)} notations", err=True)

        # Derive base name from JSON filename
        base = output or os.path.splitext(source)[0]
    else:
        # Determine if source is local or arxiv
        is_local = "/" in source and "arxiv.org" not in source

        # Extract arxiv_id for metadata and default filename
        if is_local:
            arxiv_id = None
            metadata = {
                "title": "Local Paper",
                "authors": [],
                "arxiv_id": "local",
            }
        else:
            # Clean up arxiv_id
            arxiv_id = source
            arxiv_id = arxiv_id.replace("https://arxiv.org/abs/", "")
            arxiv_id = arxiv_id.replace("https://arxiv.org/pdf/", "")
            arxiv_id = arxiv_id.replace(".pdf", "")

            click.echo(f"Fetching metadata for arXiv:{arxiv_id}...", err=True)
            metadata = get_paper_metadata(arxiv_id)
            click.echo(f"Title: {metadata['title']}", err=True)

        # Get LaTeX source
        if is_local:
            click.echo("Fetching LaTeX source...", err=True)
        elif no_cache:
            click.echo("Fetching LaTeX source (cache disabled)...", err=True)
        else:
            click.echo("Fetching LaTeX source (using cache if available)...", err=True)
        try:
            if is_local:
                latex_source = process_latex_source(
                    local_folder=source,
                    keep_comments=not no_comments,
                    expand_macros_flag=not no_expand_macros,
                )
            else:
                latex_source = process_latex_source(
                    arxiv_id=arxiv_id,
                    keep_comments=not no_comments,
                    expand_macros_flag=not no_expand_macros,
                    use_cache=not no_cache,
                )
        except Exception as e:
            click.echo(f"Error fetching LaTeX source: {e}", err=True)
            sys.exit(1)

        click.echo(f"LaTeX source: {len(latex_source)} characters", err=True)

        # Extract notations using LLM
        click.echo(f"Extracting notations using {model} via {provider}...", err=True)
        try:
            notations = extract_notations(
                latex_source=latex_source,
                model=model,
                provider=provider,
            )
        except Exception as e:
            click.echo(f"Error extracting notations: {e}", err=True)
            sys.exit(1)

        click.echo(f"Found {len(notations)} notations", err=True)

        # Filter notations by document body presence
        if not no_filter_body:
            before = len(notations)
            notations = filter_notations_by_body(notations, latex_source)
            click.echo(f"Filtered to {len(notations)}/{before} notations (body presence)", err=True)

        # Derive base name
        base_id = arxiv_id if arxiv_id else "local"
        base_id = base_id.replace("/", "_").replace(".", "_")
        base = output or f"{base_id}_notations"

    # Write all three output files
    json_path = f"{base}.json"
    html_path = f"{base}.html"
    md_path = f"{base}.md"

    with open(json_path, "w", encoding="utf-8") as f:
        f.write(render_json(notations, metadata))
    click.echo(f"Written to {json_path}", err=True)

    with open(html_path, "w", encoding="utf-8") as f:
        f.write(render_html(notations, metadata))
    click.echo(f"Written to {html_path}", err=True)

    with open(md_path, "w", encoding="utf-8") as f:
        f.write(render_markdown(notations, metadata))
    click.echo(f"Written to {md_path}", err=True)

    if terminal:
        render_terminal(notations, metadata)


if __name__ == "__main__":
    main()
