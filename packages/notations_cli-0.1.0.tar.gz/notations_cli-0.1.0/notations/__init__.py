"""Extract notation tables from arXiv papers using LLMs."""

__version__ = "0.1.0"
