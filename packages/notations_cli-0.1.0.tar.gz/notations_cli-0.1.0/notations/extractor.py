"""LLM-based notation extraction from LaTeX source."""

import json
import os
from openai import OpenAI

# Supported OpenAI models for notation extraction
SUPPORTED_OPENAI_MODELS = [
    "gpt-5.2",
    "gpt-5.1",
    "gpt-5-mini",
    "gpt-5-nano",
]

SYSTEM_PROMPT = """You are a notation extractor for academic papers. Given a LaTeX source, extract all mathematical notations used in the paper.

For each notation, provide:
- symbol: The LaTeX representation (e.g., "\\theta", "\\mathcal{D}", "x_i")
- description: A concise description of what it represents

Output a JSON array of objects with "symbol" and "description" fields.

Rules:
1. Include all meaningful mathematical symbols, variables, and operators defined or used in the paper
2. Do not include standard LaTeX commands that aren't paper-specific notations
3. For indexed variables like x_1, x_2, ..., x_n, just include the general form x_i or x_n
4. Keep descriptions concise but informative
5. If a symbol is used with different meanings in different contexts, create separate entries
6. In descriptions, use $...$ for inline math (e.g., "Model parameters with dimension $d$")

Output ONLY the JSON array, no other text."""


def extract_notations(
    latex_source: str,
    model: str = "gpt-4o",
    provider: str = "openai",
) -> list[dict]:
    """Extract notations from LaTeX source using an LLM.

    Args:
        latex_source: The LaTeX source code of the paper
        model: The model to use for extraction
        provider: The API provider ("openai" or "openrouter")

    Returns:
        List of notation dicts with "symbol" and "description" keys
    """
    if provider == "openai":
        if model not in SUPPORTED_OPENAI_MODELS:
            supported = ", ".join(SUPPORTED_OPENAI_MODELS)
            raise ValueError(f"Unsupported OpenAI model: {model}. Supported: {supported}")
        base_url = None
        api_key = os.environ.get("OPENAI_API_KEY")
    elif provider == "openrouter":
        base_url = "https://openrouter.ai/api/v1"
        api_key = os.environ.get("OPENROUTER_API_KEY")
    else:
        raise ValueError(f"Unknown provider: {provider}")

    if not api_key:
        env_var = "OPENAI_API_KEY" if provider == "openai" else "OPENROUTER_API_KEY"
        raise ValueError(f"No API key provided. Set {env_var} or pass --api-key")

    client = OpenAI(api_key=api_key, base_url=base_url)

    # Check if it's a reasoning model (gpt-5 series, o1, o3, o4)
    is_reasoning_model = any(x in model for x in ["gpt-5", "o1", "o3", "o4"])

    if is_reasoning_model:
        # Use Responses API for reasoning models
        response = client.responses.create(
            model=model,
            instructions=SYSTEM_PROMPT,
            input=latex_source,
            reasoning={"effort": "low"},
        )
        content = response.output_text.strip()
    else:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": latex_source},
            ],
            temperature=0,
        )
        content = response.choices[0].message.content.strip()

    # Handle markdown code blocks if present
    if content.startswith("```"):
        lines = content.split("\n")
        content = "\n".join(lines[1:-1])

    return json.loads(content)


def filter_notations_by_body(
    notations: list[dict], latex_source: str
) -> list[dict]:
    """Filter notations to only those whose symbol appears in the document body.

    This removes notations extracted from preamble-only macro definitions
    that were expanded away and don't appear in the actual document.

    Args:
        notations: List of notation dicts with "symbol" key
        latex_source: Full LaTeX source including preamble

    Returns:
        Filtered list of notations
    """
    import re

    begin = re.search(r"\\begin\{document\}", latex_source)
    end = re.search(r"\\end\{document\}", latex_source)
    if begin is None or end is None:
        return notations

    body = latex_source[begin.end() : end.start()]

    filtered = []
    for n in notations:
        symbol = n.get("symbol", "")
        # Strip $...$ wrappers if present
        if symbol.startswith("$") and symbol.endswith("$"):
            symbol = symbol[1:-1]
        if symbol and symbol in body:
            filtered.append(n)
    return filtered


def get_paper_metadata(arxiv_id: str) -> dict:
    """Fetch basic metadata for an arXiv paper.

    Args:
        arxiv_id: The arXiv ID (e.g., "2006.11239")

    Returns:
        Dict with title, authors, and arxiv_id
    """
    import urllib.request
    import xml.etree.ElementTree as ET

    # Clean up arxiv_id
    arxiv_id = arxiv_id.replace("https://arxiv.org/abs/", "")
    arxiv_id = arxiv_id.replace("https://arxiv.org/pdf/", "")
    arxiv_id = arxiv_id.replace(".pdf", "")

    url = f"http://export.arxiv.org/api/query?id_list={arxiv_id}"

    with urllib.request.urlopen(url) as response:
        xml_data = response.read()

    root = ET.fromstring(xml_data)
    ns = {"atom": "http://www.w3.org/2005/Atom"}

    entry = root.find("atom:entry", ns)
    if entry is None:
        return {"title": "Unknown", "authors": [], "arxiv_id": arxiv_id}

    title = entry.find("atom:title", ns)
    title_text = title.text.strip().replace("\n", " ") if title is not None else "Unknown"

    authors = entry.findall("atom:author", ns)
    author_names = []
    for author in authors:
        name = author.find("atom:name", ns)
        if name is not None:
            author_names.append(name.text)

    return {
        "title": title_text,
        "authors": author_names,
        "arxiv_id": arxiv_id,
    }
