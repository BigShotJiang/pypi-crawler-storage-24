"""Tests for the extractor module."""

from notations.extractor import filter_notations_by_body


class TestFilterNotationsByBody:
    """Tests for filter_notations_by_body."""

    def test_filters_to_body_only(self):
        latex = r"""
\newcommand{\foo}{bar}
\begin{document}
We use $\theta$ and $\alpha$ here.
\end{document}
"""
        notations = [
            {"symbol": r"\theta", "description": "parameter"},
            {"symbol": r"\alpha", "description": "learning rate"},
            {"symbol": r"\foo", "description": "a macro from preamble"},
        ]
        result = filter_notations_by_body(notations, latex)
        symbols = [n["symbol"] for n in result]
        assert r"\theta" in symbols
        assert r"\alpha" in symbols
        assert r"\foo" not in symbols

    def test_strips_dollar_wrappers(self):
        latex = r"""
\begin{document}
Use $\beta$ in text.
\end{document}
"""
        notations = [{"symbol": r"$\beta$", "description": "coefficient"}]
        result = filter_notations_by_body(notations, latex)
        assert len(result) == 1

    def test_returns_all_if_no_document_env(self):
        latex = r"Just some raw LaTeX with \gamma"
        notations = [
            {"symbol": r"\gamma", "description": "discount factor"},
            {"symbol": r"\delta", "description": "tolerance"},
        ]
        result = filter_notations_by_body(notations, latex)
        assert result == notations

    def test_empty_notations(self):
        latex = r"\begin{document}content\end{document}"
        result = filter_notations_by_body([], latex)
        assert result == []

    def test_no_matching_symbols(self):
        latex = r"""
\begin{document}
Nothing relevant here.
\end{document}
"""
        notations = [{"symbol": r"\zeta", "description": "unused"}]
        result = filter_notations_by_body(notations, latex)
        assert result == []
