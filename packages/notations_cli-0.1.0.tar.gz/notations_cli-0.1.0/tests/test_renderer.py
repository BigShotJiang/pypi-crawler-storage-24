"""Tests for the renderer module."""

import json

from notations.renderer import render_html, render_json, render_markdown


SAMPLE_NOTATIONS = [
    {"symbol": r"\theta", "description": "Model parameters"},
    {"symbol": r"\mathcal{D}", "description": "Training dataset"},
]

SAMPLE_METADATA = {
    "title": "A Great Paper",
    "authors": ["Alice", "Bob"],
    "arxiv_id": "2006.11239",
}


class TestRenderJson:
    def test_roundtrips(self):
        output = render_json(SAMPLE_NOTATIONS, SAMPLE_METADATA)
        data = json.loads(output)
        assert data["metadata"] == SAMPLE_METADATA
        assert data["notations"] == SAMPLE_NOTATIONS

    def test_empty_notations(self):
        output = render_json([], SAMPLE_METADATA)
        data = json.loads(output)
        assert data["notations"] == []
        assert data["metadata"]["title"] == "A Great Paper"


class TestRenderMarkdown:
    def test_contains_title_and_authors(self):
        md = render_markdown(SAMPLE_NOTATIONS, SAMPLE_METADATA)
        assert "# A Great Paper" in md
        assert "Alice, Bob" in md
        assert "2006.11239" in md

    def test_table_rows(self):
        md = render_markdown(SAMPLE_NOTATIONS, SAMPLE_METADATA)
        assert r"| $\theta$ | Model parameters |" in md
        assert r"| $\mathcal{D}$ | Training dataset |" in md

    def test_escapes_pipes(self):
        notations = [{"symbol": "a|b", "description": "has | pipe"}]
        md = render_markdown(notations, SAMPLE_METADATA)
        assert r"$a\|b$" in md
        assert r"has \| pipe" in md

    def test_empty_notations(self):
        md = render_markdown([], SAMPLE_METADATA)
        assert "| Symbol | Description |" in md
        # Should still have header but no data rows beyond the header separator
        lines = [l for l in md.strip().split("\n") if l.startswith("|")]
        assert len(lines) == 2  # header + separator

    def test_missing_metadata_fields(self):
        md = render_markdown(SAMPLE_NOTATIONS, {})
        assert "# Unknown" in md
        assert "Unknown authors" in md


class TestRenderHtml:
    def test_contains_metadata(self):
        html = render_html(SAMPLE_NOTATIONS, SAMPLE_METADATA)
        assert "A Great Paper" in html
        assert "Alice, Bob" in html
        assert "2006.11239" in html

    def test_contains_notations_json(self):
        html = render_html(SAMPLE_NOTATIONS, SAMPLE_METADATA)
        # The notations should be embedded as JSON
        assert r"\theta" in html
        assert r"\mathcal{D}" in html
