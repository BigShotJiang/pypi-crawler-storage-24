"""CLI commands for ailock."""
