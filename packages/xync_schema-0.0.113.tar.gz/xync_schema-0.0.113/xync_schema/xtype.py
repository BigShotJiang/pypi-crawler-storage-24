from datetime import datetime
from enum import IntEnum
from typing import Literal

from pydantic import BaseModel
from x_auth.types import Xs

from xync_schema.enums import AdStatus, OrderStatus, OrderErr


# Frontend/Human models
class Result(Xs):
    err: IntEnum
    data: dict | str | int | None = None


class OrderResult(Result):
    class Order(Xs):
        exid: int
        status: OrderStatus
        amount: float
        quantity: float = None
        # username_id: int = None

    err: OrderErr = OrderErr.ok
    data: Order | float = None  # pydantic объект ордера, либо сумма (уже приведенная к фронт-формату)


class HotAd(Xs):
    price: float
    filtered: bool
    cur_id: int
    maker: str
    web_url: str
    mob_url: str
    url: str
    min_fiat: int
    max_fiat: int | None = None


class HotAds(Xs):
    sells: list[HotAd]
    buys: list[HotAd]
    balance: dict[int, float]


# # # # # # # # # # # # # # # # # # # # # # # # # # # # # #


# Backend models
class CurEx(BaseModel):
    exid: int | str
    ticker: str
    scale: int = None
    rate: float | None = None
    minimum: float | None = None


class CoinEx(CurEx):
    p2p: bool = None


class PmExBank(BaseModel):
    # id: int | None = None
    exid: str
    name: str


class BaseAd(BaseModel):
    amount: int
    auto_msg: str | None
    created_at: int  # utc(0) seconds
    exid: int
    id: int = None
    max_fiat: int
    min_fiat: int
    premium: int
    price: int
    quantity: int | None = None
    status: Literal[AdStatus.active, AdStatus.defActive, AdStatus.soldOut]  # 10: online; 20: offline; 30: completed
    filtered: bool = False

    cond_id: int | None = None
    maker_id: int
    pair_side_id: int

    pm_ids: list[int]

    _unq = "exid", "maker_id"


class AdBuy(BaseAd):
    pmex_exids: list[int]


class AdSale(BaseAd):
    credex_exids: list[int]


class BaseOrder(BaseModel):
    exid: int  #
    amount: float
    quantity: float
    ad_id: int
    cred_id: int
    taker_id: int
    status: OrderStatus = OrderStatus.created
    created_at: datetime

    _unq = "id", "exid", "ad_id", "taker_id"


class OrderIn(BaseModel):
    exid: int
    amount: float
    created_at: datetime
    # ad: models.Ad
    # cred: models.Cred
    # taker: models.Actor
    ad_id: int
    cred_id: int
    taker_id: int
    id: int = None
    maker_topic: int | None = None
    taker_topic: int | None = None
    status: OrderStatus = OrderStatus.created
    _unq = "id", "exid", "amount", "maker_topic", "taker_topic", "ad", "cred", "taker"

    class Config:
        arbitrary_types_allowed = True
