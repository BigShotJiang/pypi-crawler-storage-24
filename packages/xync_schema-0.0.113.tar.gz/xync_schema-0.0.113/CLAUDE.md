# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is `xync-schema`, a shared database schema package for the XyncNet project. It defines Tortoise ORM models for a P2P cryptocurrency trading platform with multi-exchange support.

## Commands

```bash
# Install dependencies
pip install -r requirements.dev.txt

# Run tests (also runs as pre-commit hook)
pytest

# Run a single test
pytest tests/test_db.py::test_init_db

# Initialize database schema
python -m xync_schema
```

## Environment Setup

Requires PostgreSQL. Copy `.env.sample` to `.env` and set `DB_URL` connection string.

## Architecture

### Modules

- **`xync_schema/models/`** — All Tortoise ORM models (~60) in `__init__.py` (see `models/CLAUDE.md` for model details, conventions, domain groups)
- **`xync_schema/enums.py`** — IntEnum definitions for statuses and types
- **`xync_schema/graph.py`** — Order state machine transitions (OrderStatus -> OrderAction -> OrderStatus)
- **`xync_schema/xtype.py`** — Pydantic types for exchange API interop
- **`xync_schema/shared.py`** — Utilities: `qr_gen()`, `typ_ts_pack()`/`typ_ts_unpack()`

### Database Triggers (Transaction)

PL/pgSQL triggers enforce Transaction integrity at the DB level (see `.idea/queries/Query_1.sql`):

- **`_tx_pack(status, ts, cur_id, receiver_id, amount, sender_id) -> uuid`** — deterministic UUID: type(2bit)+ts(30bit) + cur_id(1byte) + receiver_id(3bytes) + amount(5bytes) + sender_id(3bytes) = 16 bytes. Mirrors `Transaction.pack` property.
- **`_user_balance(uid, cid) -> int`** — user's balance in a currency (sum received - sum sent, for signed+ transactions)
- **`tx_before_new()`** `BEFORE INSERT` — checks sender balance (status >= 1), generates/validates `id` via `_tx_pack`
- **`tx_id_upd()`** `BEFORE UPDATE` — forbids changing `id` or pack-affecting fields
- **`tx_no_delete()`** `BEFORE DELETE` — forbids deleting transactions

### Dependencies

- `tortoise-orm` with asyncpg for PostgreSQL
- `xn-auth` and `x_model` — shared authentication/model utilities
- `aerich` — database migrations
- `cryptography` — Ed25519 for transaction signing
