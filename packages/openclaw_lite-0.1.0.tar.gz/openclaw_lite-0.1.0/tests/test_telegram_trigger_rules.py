from __future__ import annotations

from openclaw_lite.interfaces.telegram_trigger import TriggerDecision, is_openclaw_command, should_trigger_agent


def test_plain_non_reply_message_is_ignored() -> None:
    decision = should_trigger_agent("hello there", is_reply_to_bot=False)
    assert decision == TriggerDecision(False, "ignored_plain_message")


def test_openclaw_command_is_accepted() -> None:
    decision = should_trigger_agent("/openclaw inspect file", is_reply_to_bot=False)
    assert decision == TriggerDecision(True, "openclaw_command")
    assert is_openclaw_command("/openclaw inspect file") is True


def test_openclaw_command_with_mention_is_accepted() -> None:
    decision = should_trigger_agent("/openclaw@litebot inspect file", is_reply_to_bot=False)
    assert decision == TriggerDecision(True, "openclaw_command")


def test_reply_to_bot_is_accepted() -> None:
    decision = should_trigger_agent("here is the file", is_reply_to_bot=True)
    assert decision == TriggerDecision(True, "reply_to_bot")


def test_active_session_is_accepted() -> None:
    decision = should_trigger_agent("continue", is_reply_to_bot=False, has_active_session=True)
    assert decision == TriggerDecision(True, "active_session")
