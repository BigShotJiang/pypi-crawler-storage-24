from __future__ import annotations

from types import SimpleNamespace

from openclaw_lite.interfaces.telegram_media import (
    TelegramInboundMedia,
    build_inbox_root,
    build_media_save_path,
    extract_telegram_media,
    format_media_prompt_payload,
    make_fake_message,
)


def test_build_media_save_path_uses_chat_message_and_kind(tmp_path) -> None:
    item = TelegramInboundMedia(kind="document", file_id="f1", file_unique_id="u1", original_name="Report 2026.txt")
    path = build_media_save_path(tmp_path, chat_id=-100123, message_id=77, item=item)
    assert path.parent.name == "-100123"
    assert path.name == "msg77-document-Report-2026.txt"


def test_extract_telegram_media_reads_text_and_multiple_kinds() -> None:
    message = make_fake_message(
        text="process this",
        caption=None,
        photo=[SimpleNamespace(file_id="p1", file_unique_id="pu1", file_size=123)],
        document=SimpleNamespace(file_id="d1", file_unique_id="du1", file_name="hello.pdf", mime_type="application/pdf", file_size=456),
        video=None,
        animation=None,
        audio=None,
        voice=None,
        sticker=None,
    )
    items = extract_telegram_media(message)
    assert [item.kind for item in items] == ["photo", "document"]
    assert items[0].message_text == "process this"
    assert items[1].original_name == "hello.pdf"


def test_format_media_prompt_payload_contains_text_and_paths() -> None:
    payload = format_media_prompt_payload(
        message_text="convert this file",
        saved_items=[
            {
                "kind": "document",
                "saved_path": "/data/telegram_inbox/1/msg7-document-file.pdf",
                "original_name": "file.pdf",
            }
        ],
    )
    assert "convert this file" in payload
    assert "[saved telegram attachments]" in payload
    assert "path=/data/telegram_inbox/1/msg7-document-file.pdf" in payload


def test_build_inbox_root_uses_data_dir(tmp_path) -> None:
    inbox = build_inbox_root({"data_dir": str(tmp_path)})
    assert inbox == tmp_path / "telegram_inbox"
