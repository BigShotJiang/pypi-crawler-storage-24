from __future__ import annotations

from pathlib import Path

from openclaw_lite.config import ConfigManager
from openclaw_lite.interfaces.web_ui import render_settings_page, update_config_from_form


def test_render_settings_page_contains_key_fields() -> None:
    html = render_settings_page(
        {
            "telegram": {"bot_token": "123", "owner_user_ids": [1]},
            "providers": {
                "items": {
                    "openai": {"api_key": "sk-openai", "default_model": "gpt-test"},
                    "gemini": {"api_key": "gm-key", "default_model": "gemini-test"},
                }
            },
        }
    )
    assert "OpenAI API Key" in html
    assert "Gemini API Key" in html
    assert "Telegram Bot Token" in html


def test_update_config_from_form_saves_provider_keys(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yaml"
    manager = ConfigManager(config_path)
    update_config_from_form(
        manager,
        {
            "telegram_bot_token": "bot:token",
            "telegram_owner_user_ids": "1,2",
            "telegram_allowed_user_ids": "3",
            "telegram_allowed_chat_ids": "-1001",
            "openai_api_key": "sk-openai",
            "openai_default_model": "gpt-x",
            "gemini_api_key": "gm-key",
            "gemini_default_model": "gemini-x",
            "openrouter_api_key": "or-key",
            "openrouter_base_url": "https://example.test/v1",
        },
    )
    reloaded = ConfigManager(config_path)
    assert reloaded.get("telegram.bot_token") == "bot:token"
    assert reloaded.get("telegram.owner_user_ids") == [1, 2]
    assert reloaded.get("providers.items.openai.api_key") == "sk-openai"
    assert reloaded.get("providers.items.gemini.api_key") == "gm-key"
