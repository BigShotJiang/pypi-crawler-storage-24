from __future__ import annotations

from pathlib import Path

from openclaw_lite.config import load_config, save_config


def test_load_config_resolves_env(tmp_path, monkeypatch):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    config_path = tmp_path / "config.yaml"
    config_path.write_text(
        """
telegram:
  bot_token: ${TELEGRAM_BOT_TOKEN:-abc}
providers:
  default: openai
  items:
    openai:
      type: openai
      api_key: ${OPENAI_API_KEY}
      default_model: gpt-test
""",
        encoding="utf-8",
    )
    config = load_config(config_path)
    assert config.telegram.bot_token == "abc"
    assert config.providers["openai"].api_key == "sk-test"
    assert config.default_model_for("openai") == "gpt-test"


def test_save_and_reload_roundtrip(tmp_path):
    config_path = tmp_path / "config.yaml"
    config = load_config(config_path)
    config.name = "demo"
    save_config(config, config_path)
    reloaded = load_config(config_path)
    assert reloaded.name == "demo"
    assert reloaded.paths.config_file == config_path.resolve()
