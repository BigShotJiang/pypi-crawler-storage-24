from __future__ import annotations

from openclaw_lite.schema import ToolResult


def test_tool_result_prompt_string_contains_content():
    result = ToolResult(ok=True, content={"value": 42})
    text = result.to_prompt_string()
    assert '"value": 42' in text
