from __future__ import annotations

from pathlib import Path

from openclaw_lite.core.prompting import build_system_prompt
from openclaw_lite.schemas import SessionState


def test_root_agents_prompt_is_included(tmp_path: Path) -> None:
    root = tmp_path / 'repo'
    root.mkdir()
    (root / 'AGENTS.md').write_text('Always answer with repo rules.', encoding='utf-8')
    session = SessionState(session_id='s', chat_id='c', user_id=1, provider='openai', model='gpt')
    prompt = build_system_prompt(
        {
            'system_prompt': 'Base prompt',
            'project_root': str(root),
            'workspace_dir': str(root / 'workspace'),
        },
        session,
        provider_names=['openai'],
        skill_fragments=[],
        root_agents_prompt=(root / 'AGENTS.md').read_text(encoding='utf-8'),
    )
    assert 'Always answer with repo rules.' in prompt
    assert 'Root AGENTS.md instructions:' in prompt
