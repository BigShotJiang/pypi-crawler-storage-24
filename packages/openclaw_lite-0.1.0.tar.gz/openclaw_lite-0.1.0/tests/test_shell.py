from __future__ import annotations

import pytest

from openclaw_lite.config import default_config
from openclaw_lite.tools.shell import _is_safe_command, run_shell_command


def test_safe_command_allowlist(tmp_path):
    config = default_config(tmp_path)
    assert _is_safe_command("ls -la", config)[0] is True
    allowed, reason = _is_safe_command("rm -rf /", config)
    assert allowed is False
    assert "blocked" in reason


@pytest.mark.asyncio
async def test_run_shell_command_safe(tmp_path):
    config = default_config(tmp_path)
    result = await run_shell_command(config, command="python3 -c 'print(123)'", mode="safe", cwd=tmp_path)
    assert result.returncode == 0
    assert result.stdout.strip() == "123"
