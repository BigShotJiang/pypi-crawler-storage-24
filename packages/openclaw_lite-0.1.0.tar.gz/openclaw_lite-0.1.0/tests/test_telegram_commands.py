from __future__ import annotations

from openclaw_lite.interfaces.telegram_bot import (
    ParsedCommand,
    build_bot_commands,
    build_help_text,
    build_session_id,
    parse_command,
    render_markdownish_html_chunks,
)


def test_parse_command_basic() -> None:
    parsed = parse_command("/status")
    assert parsed == ParsedCommand(name="status", args="", tokens=(), mention=None)


def test_parse_command_with_args_and_mention() -> None:
    parsed = parse_command("/models@mybot openai")
    assert parsed is not None
    assert parsed.name == "models"
    assert parsed.mention == "mybot"
    assert parsed.args == "openai"
    assert parsed.tokens == ("openai",)


def test_parse_command_pair_create_tokens() -> None:
    parsed = parse_command("/pair create 300")
    assert parsed is not None
    assert parsed.name == "pair"
    assert parsed.tokens == ("create", "300")


def test_parse_command_returns_none_for_plain_text() -> None:
    assert parse_command("hello world") is None
    assert parse_command("") is None


def test_build_session_id_supports_topics() -> None:
    assert build_session_id(12345) == "telegram:12345:main"
    assert build_session_id(12345, 7) == "telegram:12345:topic:7"


def test_help_text_mentions_new_commands() -> None:
    text = build_help_text()
    assert "/openclaw" in text
    assert "/pair" in text
    assert "/approve" in text
    assert "/sessions" in text
    assert "/end" in text
    assert "/reset" in text
    assert "/settings" in text
    assert "/apikey" in text
    assert "/exec" in text


def test_parse_command_login_code() -> None:
    parsed = parse_command("/login ABC123")
    assert parsed is not None
    assert parsed.name == "login"
    assert parsed.tokens == ("ABC123",)


def test_parse_command_openclaw_prefix() -> None:
    parsed = parse_command("/openclaw почини себя")
    assert parsed is not None
    assert parsed.name == "openclaw"
    assert parsed.args == "почини себя"


def test_render_markdownish_html_chunks_inline_code() -> None:
    chunks = render_markdownish_html_chunks("hello `world` !")
    assert chunks == ["hello <code>world</code> !"]


def test_render_markdownish_html_chunks_code_block() -> None:
    chunks = render_markdownish_html_chunks("```print(123)```")
    assert chunks == ["<pre><code>print(123)</code></pre>"]


def test_render_markdownish_html_chunks_bold_italic() -> None:
    chunks = render_markdownish_html_chunks("**bold** _italic_ ~~strike~~")
    assert chunks == ["<b>bold</b> <i>italic</i> <s>strike</s>"]


def test_parse_command_settings() -> None:
    parsed = parse_command("/settings")
    assert parsed is not None
    assert parsed.name == "settings"


def test_parse_command_apikey() -> None:
    parsed = parse_command("/apikey claude sk-test")
    assert parsed is not None
    assert parsed.name == "apikey"
    assert parsed.tokens[:2] == ("claude", "sk-test")


def test_parse_command_reset() -> None:
    parsed = parse_command("/reset telegram:123:main")
    assert parsed is not None
    assert parsed.name == "reset"
    assert parsed.args == "telegram:123:main"


def test_build_bot_commands_exposes_settings_and_reset() -> None:
    commands = {item.command: item.description for item in build_bot_commands()}
    assert "settings" in commands
    assert "apikey" in commands
    assert "provider" in commands
    assert "reset" in commands
    assert "openclaw" in commands
