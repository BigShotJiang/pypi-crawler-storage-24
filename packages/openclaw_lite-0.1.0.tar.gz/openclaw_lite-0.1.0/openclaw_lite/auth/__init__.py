from .manager import AuthGrant, PairingCode, TelegramAccessManager

AuthManager = TelegramAccessManager

__all__ = ["AuthGrant", "PairingCode", "TelegramAccessManager", "AuthManager"]
