from __future__ import annotations

from .openai_compatible import OpenAICompatibleProvider


class OpenAIProvider(OpenAICompatibleProvider):
    provider_type = "openai"

    def __init__(
        self,
        *,
        api_key: str,
        base_url: str = "https://api.openai.com/v1",
        provider_name: str = "openai",
        timeout: float = 60.0,
        extra_headers: dict[str, str] | None = None,
        http_client=None,
    ) -> None:
        super().__init__(
            api_key=api_key,
            base_url=base_url,
            provider_name=provider_name,
            timeout=timeout,
            extra_headers=extra_headers,
            http_client=http_client,
        )
