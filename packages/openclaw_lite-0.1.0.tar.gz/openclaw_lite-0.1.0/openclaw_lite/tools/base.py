from __future__ import annotations

from typing import Any

from openclaw_lite.schema import ToolResult


def object_schema(properties: dict[str, Any], required: list[str] | None = None) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": required or [],
        "additionalProperties": False,
    }


def ok(content: Any = None, *, metadata: dict[str, Any] | None = None) -> ToolResult:
    return ToolResult(ok=True, content=content, metadata=metadata or {})


def fail(error: str, *, content: Any = None, metadata: dict[str, Any] | None = None) -> ToolResult:
    return ToolResult(ok=False, content=content, error=str(error), metadata=metadata or {})
