from __future__ import annotations

from typing import Any


async def shell_run_handler(context, arguments: dict[str, Any]) -> dict[str, Any]:
    mode = arguments.get("mode") or context.session.security_mode
    result = await context.runtime.shell_executor.run(
        arguments["command"],
        mode=mode,
        cwd=arguments.get("cwd"),
        timeout_seconds=arguments.get("timeout_seconds"),
    )
    return result.to_dict()
