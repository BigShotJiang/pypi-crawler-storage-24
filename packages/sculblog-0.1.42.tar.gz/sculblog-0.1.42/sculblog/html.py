"""HTML processing: pandoc conversion, link extraction/stripping, preview generation."""

import re
import traceback
import importlib.resources as resources

from bs4 import BeautifulSoup
import pypandoc

lua_filter = str(resources.files('sculblog') / 'subsection-wrapper.lua')


def write_page_html(file_path: str):
    try:
        html = pypandoc.convert_file(
            file_path,
            to='html',
            format='markdown+fenced_divs-markdown_in_html_blocks',
            extra_args=['--mathml', f'--lua-filter={lua_filter}']
        )
    except Exception as e:
        print(f"Error in write_page_html: {str(e)}")
        raise
    return html


def write_preview_html(html_content: str, char_len: int):
    try:
        soup = BeautifulSoup(html_content, 'html.parser')

        for s_tag in soup.find_all(['style', 'iframe']):
            s_tag.replace_with("")

        for a_tag in soup.find_all('a'):
            span_tag = soup.new_tag('span', **{'class': 'false-external-link'})
            span_tag.string = a_tag.get_text()
            a_tag.replace_with(span_tag)

        for h_tag in soup.find_all(['h1', 'h2', 'h3', 'h4', 'h5', 'h6']):
            span_tag = soup.new_tag('span', **{'class': 'preview-header'})
            span_tag.string = h_tag.get_text()
            h_tag.replace_with(span_tag)

        for tag in soup.find_all():
            if tag.name not in ['span', 'sup', 'sub', 'em', 'strong', 'i', 'b',
                                's', 'strike', 'del', 'u', 'mark', 'small',
                                'q', 'cite', 'code', 'kbd', 'abbr']:
                tag.unwrap()

        text_content = soup.get_text()

        if len(text_content) > char_len:
            text_nodes = []
            current_count = 0

            for element in soup.descendants:
                if isinstance(element, str) and current_count < char_len:
                    if current_count + len(element) <= char_len:
                        text_nodes.append((element, element))
                        current_count += len(element)
                    else:
                        truncated = element[:char_len - current_count] + "..."
                        text_nodes.append((element, truncated))
                        current_count = char_len
                        break

            for original, truncated in text_nodes:
                if original != truncated:
                    original.replace_with(truncated)

        clean_html = ''.join(str(tag) for tag in soup.contents)
        return clean_html

    except Exception as e:
        print(f"Error in write_preview_html: {str(e)}")
        print("Traceback:")
        traceback.print_exc()
        raise


def _classify_links(links, html):
    """Classify a flat list of {href, ref_start, ref_end} into macrolinks and autolinks.
    Header id positions are resolved against the provided html string."""
    header_positions = {}
    for m in re.finditer(r'<(?:h[1-6]|section|div)[^>]*\bid=["\']([^"\']+)["\'][^>]*>', html):
        anchor_id = m.group(1)
        tag_end = m.end()
        tag_name = re.match(r'<(\w+)', m.group()).group(1)
        close = re.search(r'</' + tag_name + r'\s*>', html[tag_end:], re.IGNORECASE)
        if close:
            header_positions[anchor_id] = (tag_end, tag_end + close.start() - 1)

    macrolinks = []
    autolinks = []
    for link in links:
        href = link["href"]
        if href.startswith("#"):
            anchor = href[1:]
            if anchor in header_positions:
                def_start, def_end = header_positions[anchor]
                autolinks.append({
                    "def_start": def_start,
                    "def_end": def_end,
                    "ref_start": link["ref_start"],
                    "ref_end": link["ref_end"],
                })
        else:
            macrolinks.append({
                "href": href,
                "ref_start": link["ref_start"],
                "ref_end": link["ref_end"],
            })
    return macrolinks, autolinks


def strip_and_extract_links(html):
    """Strip classless <a> tags, keep classed ones. Positions reference the stripped HTML.

    Returns (stripped_html, macrolinks, autolinks).
    """
    links = []
    parts = []
    i = 0

    while i < len(html):
        a_match = re.search(r'<a\s[^>]*>', html[i:])
        if not a_match:
            parts.append(html[i:])
            break

        parts.append(html[i:i + a_match.start()])

        tag_str = a_match.group()
        has_class = bool(re.search(r'\bclass=["\']', tag_str))

        inner_start = i + a_match.start() + len(tag_str)
        close_match = re.search(r'</a\s*>', html[inner_start:], re.IGNORECASE)
        if not close_match:
            parts.append(html[i + a_match.start():])
            break

        full_tag_end = inner_start + close_match.start() + len(close_match.group())

        if has_class:
            parts.append(html[i + a_match.start():full_tag_end])
        else:
            href_match = re.search(r'href=["\']([^"\']*)["\']', tag_str)
            href = href_match.group(1) if href_match else ""
            if href.startswith("http://") or href.startswith("https://"):
                # external link — keep the full <a> tag in content
                parts.append(html[i + a_match.start():full_tag_end])
            else:
                # internal link — strip tag, record as link
                inner_text = html[inner_start:inner_start + close_match.start()]
                stripped_pos = sum(len(p) for p in parts)
                parts.append(inner_text)
                links.append({"href": href, "ref_start": stripped_pos, "ref_end": stripped_pos + len(inner_text) - 1})

        i = full_tag_end

    stripped = ''.join(parts)
    macrolinks, autolinks = _classify_links(links, stripped)
    return stripped, macrolinks, autolinks


def extract_links(html):
    """Extract links without stripping — positions reference the original HTML.

    Dormant: use strip_and_extract_links for the active pipeline.
    Returns (macrolinks, autolinks).
    """
    links = []
    i = 0

    while i < len(html):
        a_match = re.search(r'<a\s[^>]*>', html[i:])
        if not a_match:
            break

        tag_str = a_match.group()
        href_match = re.search(r'href=["\']([^"\']*)["\']', tag_str)
        href = href_match.group(1) if href_match else ""

        inner_start = i + a_match.start() + len(tag_str)
        close_match = re.search(r'</a\s*>', html[inner_start:], re.IGNORECASE)
        if not close_match:
            break

        ref_start = inner_start
        ref_end = inner_start + close_match.start() - 1
        links.append({"href": href, "ref_start": ref_start, "ref_end": ref_end})

        i = inner_start + close_match.start() + len(close_match.group())

    return _classify_links(links, html)
