"""sculblog CLI — publish, update, and manage documents."""

import os
import sys
import re

from sculblog.diego_flavored_markdown import count_markdown_words
from sculblog.db import DbConn
from sculblog.html import write_page_html, write_preview_html
from sculblog.netdoc import write_netdoc, get_xruid_for_file, current_draft
from datetime import datetime

#===============================
# Configuration
#===============================

server_path = os.path.abspath(os.path.join('/', 'var', 'www', 'html'))
db_path = os.path.abspath(os.path.join(server_path, 'database', 'db.db'))
draft_db_path = os.path.abspath(os.path.join(server_path, 'database', 'drafts.db'))

input_header_message = "what is the header of the page? "


def sanitize_filename(filename: str) -> str:
    return re.sub(r'[^\w\-_\. ]', '_', filename)


def remove_extension(filename):
    return os.path.splitext(filename)[0]


def custom_date():
    now = datetime.now()
    year, day, month_abbr = now.year, now.day, now.strftime('%b')
    month = 'July' if month_abbr == 'Jul' else month_abbr
    return f"{year} {month} {day:02d}"


#===============================
# Post updater (file-based, no SQL writes)
#===============================

def post_updater(category, file_path, subcommand):
    try:
        page_html = write_page_html(file_path)
        file_name = os.path.splitext(os.path.basename(file_path))[0]

        with open(os.path.abspath(file_path), "r") as file:
            markdown_content = file.read()

        preview_html = write_preview_html(page_html, 1500)
        word_count = count_markdown_words(markdown_content)

        xruid = get_xruid_for_file(server_path, category, file_name)

        if not xruid:
            # new post
            header = input(input_header_message)
            date_splash = custom_date()
            xruid = os.urandom(32)

            # write PHP stub
            php_stub_path = os.path.join(server_path, category, file_name + ".php")
            os.makedirs(os.path.join(server_path, category), exist_ok=True)
            with open(php_stub_path, 'w') as f:
                f.write(f'<?php $xruid = "{xruid.hex()}"; $page = \'{category}\'; $attributes = \'../resources/post-attrs.php\'; include \'../resources/post-template.php\'; ?>')

            write_netdoc(page_html, server_path, category, file_name, 1, xruid=xruid, title=header, word_count=word_count, date_splash=date_splash, preview_html=preview_html)

            print(f"xruid:{xruid.hex()}")

        else:
            cur_draft = current_draft(server_path, xruid)

            if subcommand == "draft":
                new_draft = cur_draft + 1
                write_netdoc(page_html, server_path, category, file_name, new_draft, xruid=xruid, word_count=word_count, preview_html=preview_html)

            elif subcommand == "update":
                draft = max(cur_draft, 1)
                write_netdoc(page_html, server_path, category, file_name, draft, xruid=xruid, word_count=word_count, is_update=True, preview_html=preview_html)

            elif subcommand == "preview":
                write_netdoc(page_html, server_path, category, file_name, 0, xruid=xruid, word_count=word_count, preview_html=preview_html)

            else:
                print(f"unknown subcommand: {subcommand}")
                return

    except Exception as e:
        print(f"An error of Exception type {type(e).__name__} occurred: {e}")


#===============================
# Legacy SQL single-field updaters
#===============================

def db_single_updater(func):
    def wrapper(category, file_path, *args, **kwargs):
        file_name = remove_extension(file_path)
        DbConn(db_path).update_row(category, "file_name", file_name, dict([func(*args, **kwargs)]))
    return wrapper


@db_single_updater
def hide():
    return "hide", "0"


@db_single_updater
def unhide():
    return "hide", ""


@db_single_updater
def date():
    date_splash = input("What is the date of the page? ")
    return "date_splash", date_splash


@db_single_updater
def header():
    header = input(input_header_message)
    return "header", header


def main():
    if len(sys.argv) < 4:
        print("Usage: sculblog <command> <category> <postname> \n\t  commands: preview, draft, hide, unhide, date, header")
        sys.exit(1)

    command, category, file_path = sys.argv[1], sys.argv[2], sys.argv[3]

    if command == "preview":
        post_updater(category, file_path, "preview")
    elif command == "draft":
        post_updater(category, file_path, "draft")
    elif command == "update":
        post_updater(category, file_path, "update")

    elif command == "hide":
        hide(category, file_path)
    elif command == "unhide":
        unhide(category, file_path)

    elif command == "date":
        date(category, file_path)
    elif command == "header":
        header(category, file_path)

    else:
        print('Invalid command. Command must be "preview", "draft", "hide", "unhide", "date", or "header"')
        sys.exit(1)

if __name__ == "__main__":
    main()
