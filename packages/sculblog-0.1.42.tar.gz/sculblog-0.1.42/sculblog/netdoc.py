"""Netdoc: DTOB netdoc encoding, XVS, neolinks, memcache maps, OTS timestamping."""

import os
import re
import ctypes
import subprocess
import time
import tempfile

from sculblog.html import strip_and_extract_links

#===============================
# libdtob ctypes setup
#===============================

_dtob_lib_path = os.environ.get('DTOB_LIB', '/root/dtob-doc/libdtob.so')
potc_bin = os.environ.get('POTC_BIN', '/root/potc-c/potc')
ots_bin = os.environ.get('OTS_BIN', '/usr/local/bin/ots')

try:
    _dtob = ctypes.CDLL(_dtob_lib_path)
    _dtob.dtob_array_append_to_file.restype = ctypes.c_int
    _dtob.dtob_array_append_to_file.argtypes = [ctypes.c_char_p, ctypes.c_void_p]
    _dtob.dtob_kvset.restype = ctypes.c_void_p
    _dtob.dtob_kvset_put.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p]
    _dtob.dtob_raw.restype = ctypes.c_void_p
    _dtob.dtob_raw.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    _dtob.dtob_uint.restype = ctypes.c_void_p
    _dtob.dtob_uint.argtypes = [ctypes.c_uint64]
    _dtob.dtob_array.restype = ctypes.c_void_p
    _dtob.dtob_array_push.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    _dtob.dtob_encode.restype = ctypes.POINTER(ctypes.c_uint8)
    _dtob.dtob_encode.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t)]
except OSError:
    _dtob = None


class _DtobValue(ctypes.Structure):
    """Minimal ctypes mirror of DtobValue for reading num_elements."""
    pass

_DtobValue._fields_ = [
    ("type", ctypes.c_int),
    ("custom_code", ctypes.c_uint16),
    ("inner_code", ctypes.c_uint16),
    ("data", ctypes.POINTER(ctypes.c_uint8)),
    ("data_len", ctypes.c_size_t),
    ("elements", ctypes.POINTER(ctypes.POINTER(_DtobValue))),
    ("num_elements", ctypes.c_size_t),
    ("pairs", ctypes.c_void_p),
    ("num_pairs", ctypes.c_size_t),
]


def _dtob_decode_file(path):
    """Decode a DTOB file, return a ctypes pointer to DtobValue. Caller must free."""
    if not _dtob or not os.path.exists(path):
        return None
    with open(path, 'rb') as f:
        data = f.read()
    if not data:
        return None
    buf = (ctypes.c_uint8 * len(data))(*data)
    _dtob.dtob_decode.restype = ctypes.POINTER(_DtobValue)
    _dtob.dtob_decode.argtypes = [ctypes.c_void_p, ctypes.c_size_t]
    return _dtob.dtob_decode(buf, len(data))


def _dtob_free(ptr):
    if ptr:
        _dtob.dtob_free.argtypes = [ctypes.c_void_p]
        _dtob.dtob_free(ptr)


def _dtob_kv_entry(**fields):
    """Build a DtobValue kvset from keyword args via ctypes. Values can be bytes, int, or str."""
    kv = _dtob.dtob_kvset()
    for key, val in fields.items():
        if isinstance(val, bytes):
            v = _dtob.dtob_raw(val, len(val))
        elif isinstance(val, int):
            v = _dtob.dtob_uint(val)
        elif isinstance(val, str):
            encoded = val.encode('utf-8')
            v = _dtob.dtob_raw(encoded, len(encoded))
        else:
            continue
        _dtob.dtob_kvset_put(kv, key.encode(), v)
    return kv


#===============================
# Crypto helpers
#===============================

def compute_cid(content_path):
    """Compute Bromberg CID by calling potc singlehash. Returns 32 bytes or None."""
    try:
        result = subprocess.run([potc_bin, "singlehash", "-f", content_path],
                                capture_output=True, text=True)
        if result.returncode == 0 and len(result.stdout.strip()) == 64:
            return bytes.fromhex(result.stdout.strip())
    except Exception:
        pass
    return None


def generate_druid():
    """Generate a random 32-byte draft RUID (unique per version)."""
    return os.urandom(32)


def stamp_ots(content_bytes):
    """Submit content hash to OpenTimestamps, return the .ots proof bytes or None.
    Uses the CID (bromberg hash) of the content as the hash to timestamp."""
    try:
        with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.bin') as tmp:
            tmp.write(content_bytes)
            tmp_path = tmp.name
        result = subprocess.run([ots_bin, "stamp", tmp_path],
                                capture_output=True, timeout=30)
        ots_path = tmp_path + ".ots"
        if result.returncode == 0 and os.path.exists(ots_path):
            with open(ots_path, 'rb') as f:
                proof = f.read()
            os.unlink(ots_path)
            os.unlink(tmp_path)
            return proof
        os.unlink(tmp_path)
    except Exception as e:
        print(f"  ots stamp failed: {e}")
    return None


#===============================
# XVS
#===============================

def update_xvs(server_path, category, file_name, druid, cid, timestamp, xruid=None):
    """Append {druid, cid, timestamp} to the .xvs DTOB file via libdtob."""
    if not _dtob:
        print("libdtob not loaded, skipping xvs")
        return druid

    if xruid:
        xvs_path = os.path.join(server_path, "repo", xruid.hex() + ".xvs")
    else:
        xvs_path = os.path.join(server_path, category, file_name + ".xvs")
    entry = _dtob_kv_entry(
        druid=druid,
        cid=cid if cid else b'\x00' * 32,
        timestamp=timestamp,
    )
    _dtob.dtob_array_append_to_file(xvs_path.encode(), entry)
    return druid


def current_draft(server_path, xruid):
    """Get current draft count from XVS file. Draft number = number of entries in XVS."""
    xvs_path = os.path.join(server_path, "repo", xruid.hex() + ".xvs")
    root = _dtob_decode_file(xvs_path)
    if not root:
        return 0
    count = root.contents.num_elements
    _dtob_free(root)
    return count


#===============================
# Resolution helpers
#===============================

def read_xruid_from_stub(server_path, category, file_name):
    """Read the target document's xruid from its PHP stub file. Returns hex string or None."""
    stub_path = os.path.join(server_path, category, file_name + ".php")
    try:
        with open(stub_path) as f:
            content = f.read()
        m = re.search(r'\$xruid\s*=\s*["\']([0-9a-f]+)["\']', content)
        return m.group(1) if m else None
    except (FileNotFoundError, OSError):
        return None


def get_xruid_for_file(server_path, category, file_name):
    """Read xruid from the PHP stub file. Returns bytes or None."""
    hex_str = read_xruid_from_stub(server_path, category, file_name)
    if hex_str:
        return bytes.fromhex(hex_str)
    return None


def _parse_href_target(href, current_category):
    """Parse a macrolink href into (target_category, target_file_name).
    Returns (None, None) for external URLs."""
    if href.startswith("http://") or href.startswith("https://"):
        return None, None

    href_clean = href.split("#")[0].split("?")[0]
    if href_clean.endswith(".php"):
        href_clean = href_clean[:-4]
    href_clean = href_clean.rstrip("/")
    target_name = os.path.basename(href_clean)
    if not target_name:
        return None, None

    href_parts = [p for p in href_clean.strip("/").split("/") if p != "." and p != ".."]
    target_category = href_parts[-2] if len(href_parts) >= 2 else current_category
    return target_category, target_name


def _resolve_target_ids(server_path, target_category, target_file_name):
    """Resolve a target document's latest druid and cid from its XVS.
    Returns (druid, cid) — zero-filled 32-byte blobs if not found."""
    zero = b'\x00' * 32

    target_xruid_hex = read_xruid_from_stub(server_path, target_category, target_file_name)
    if not target_xruid_hex:
        return zero, zero

    xvs_path = os.path.join(server_path, "repo", target_xruid_hex + ".xvs")
    root = _dtob_decode_file(xvs_path)
    if not root:
        return zero, zero

    n = root.contents.num_elements
    if n == 0:
        _dtob_free(root)
        return zero, zero

    latest = root.contents.elements[n - 1]
    if not latest:
        _dtob_free(root)
        return zero, zero

    _dtob.dtob_kvset_get.restype = ctypes.POINTER(_DtobValue)
    _dtob.dtob_kvset_get.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

    druid_val = _dtob.dtob_kvset_get(latest, b"druid")
    cid_val = _dtob.dtob_kvset_get(latest, b"cid")

    druid = bytes(druid_val.contents.data[:32]) if druid_val and druid_val.contents.data_len == 32 else zero
    cid_out = bytes(cid_val.contents.data[:32]) if cid_val and cid_val.contents.data_len == 32 else zero

    _dtob_free(root)
    return druid, cid_out


#===============================
# Neolinks
#===============================

def propagate_neolinks(server_path, category, file_name, macrolinks, druid, cid, timestamp, xruid=None):
    """For each macrolink pointing to a local document, append a neolink to the target's
    <target_latest_druid>.nl DTOB file."""
    if not _dtob:
        print("libdtob not loaded, skipping neolink propagation")
        return

    for link in macrolinks:
        href = link["href"]
        if href.startswith("http://") or href.startswith("https://"):
            continue

        target_category, target_name = _parse_href_target(href, category)
        if not target_category or not target_name:
            continue

        # resolve target's latest druid from XVS
        target_druid, _ = _resolve_target_ids(server_path, target_category, target_name)
        if target_druid == b'\x00' * 32:
            print(f"  neolink skipped (can't resolve {target_category}/{target_name})")
            continue

        # neolinks stored per-druid: <target_druid>.nl
        nl_path = os.path.join(server_path, "repo", target_druid.hex() + ".nl")

        zero32 = b'\x00' * 32
        entry = _dtob_kv_entry(
            from_druid=druid,
            from_cid=cid if cid else zero32,
            from_sha256=zero32,
            from_xruid=xruid if xruid else zero32,
            timestamp=timestamp,
            ref_start=link["ref_start"],
            ref_end=link["ref_end"],
        )
        _dtob.dtob_array_append_to_file(nl_path.encode(), entry)

        print(f"  neolink → {target_category}/{target_name}")


#===============================
# Memcache maps
#===============================

def rebuild_memcache_maps(server_path):
    """Scan all .xvs files, build three DTOB kvset maps, write them, SIGHUP the daemons.
    Map 1 (xruid_to_druid): xruid (32 bytes) → latest druid (32 bytes)
    Map 2 (druid_to_xruid): druid (32 bytes) → xruid (32 bytes)
    Map 3 (druid_to_path):  druid (32 bytes) → URL path string (e.g. "/blog/my-post.php")
    """
    if not _dtob:
        return

    import glob as globmod
    import signal

    repo = os.path.join(server_path, "repo")
    xvs_files = globmod.glob(os.path.join(repo, "*.xvs"))

    # build xruid → path map by scanning PHP stubs for $xruid declarations
    xruid_to_path = {}
    for php_path in globmod.glob(os.path.join(server_path, "*", "*.php")):
        try:
            with open(php_path) as f:
                content = f.read(512)
            m = re.search(r'\$xruid\s*=\s*["\']([0-9a-f]+)["\']', content)
            if m:
                rel = os.path.relpath(php_path, server_path)
                xruid_to_path[m.group(1)] = "/" + rel
        except (OSError, UnicodeDecodeError):
            pass

    x2d = _dtob.dtob_kvset()   # xruid → latest druid
    d2x = _dtob.dtob_kvset()   # druid → xruid
    d2p = _dtob.dtob_kvset()   # druid → path

    _dtob.dtob_kvset_get.restype = ctypes.POINTER(_DtobValue)
    _dtob.dtob_kvset_get.argtypes = [ctypes.c_void_p, ctypes.c_char_p]

    for xvs_path in xvs_files:
        xruid_hex = os.path.basename(xvs_path)[:-4]
        try:
            xruid_bytes = bytes.fromhex(xruid_hex)
        except ValueError:
            continue

        root = _dtob_decode_file(xvs_path)
        if not root:
            continue

        n = root.contents.num_elements
        if n == 0:
            _dtob_free(root)
            continue

        # xruid → latest druid
        latest = root.contents.elements[n - 1]
        if latest:
            druid_val = _dtob.dtob_kvset_get(latest, b"druid")
            if druid_val and druid_val.contents.data_len == 32:
                latest_druid = bytes(druid_val.contents.data[:32])
                _dtob.dtob_kvset_put(x2d, xruid_bytes, _dtob.dtob_raw(latest_druid, 32))

        # path from PHP stub scan
        path_str = xruid_to_path.get(xruid_hex)
        path_bytes = path_str.encode('utf-8') if path_str else None

        # map every druid in this xvs
        for i in range(n):
            entry = root.contents.elements[i]
            if not entry:
                continue
            druid_val = _dtob.dtob_kvset_get(entry, b"druid")
            if druid_val and druid_val.contents.data_len == 32:
                druid_bytes = bytes(druid_val.contents.data[:32])
                _dtob.dtob_kvset_put(d2x, druid_bytes, _dtob.dtob_raw(xruid_bytes, 32))
                if path_bytes:
                    _dtob.dtob_kvset_put(d2p, druid_bytes, _dtob.dtob_raw(path_bytes, len(path_bytes)))

        _dtob_free(root)

    out_len = ctypes.c_size_t()
    for name, kvset in [("xruid_to_druid", x2d), ("druid_to_xruid", d2x), ("druid_to_path", d2p)]:
        encoded = _dtob.dtob_encode(kvset, ctypes.byref(out_len))
        if encoded and out_len.value > 0:
            map_path = os.path.join(repo, name + ".dtob")
            with open(map_path, 'wb') as f:
                f.write(bytes(encoded[:out_len.value]))
            ctypes.CDLL(None).free(encoded)

    for sock_name in ["xruid-lookup", "druid-lookup", "druid-path"]:
        pid_path = os.path.join("/tmp", f"dtob-{sock_name}.pid")
        try:
            with open(pid_path) as f:
                pid = int(f.read().strip())
            os.kill(pid, signal.SIGHUP)
            print(f"  SIGHUP → {sock_name} (pid {pid})")
        except (FileNotFoundError, ValueError, ProcessLookupError):
            pass


#===============================
# write_netdoc
#===============================

def write_netdoc(page_html, server_path, category, file_name, version, xruid=None, title=None, word_count=0, is_update=False, date_splash=None, preview_html=None):
    """Strip links from HTML, encode content as .nd DTOB, write link metadata,
    update XVS, and propagate neolinks."""
    try:
        stripped_html, macrolinks, autolinks = strip_and_extract_links(page_html)

        os.makedirs(os.path.join(server_path, "repo"), exist_ok=True)

        content_bytes = stripped_html.encode('utf-8')

        # compute CID from the stripped content
        with tempfile.NamedTemporaryFile(mode='wb', delete=False) as tmp:
            tmp.write(content_bytes)
            tmp_path = tmp.name
        cid = compute_cid(tmp_path)
        os.unlink(tmp_path)

        druid = generate_druid()
        doc_timestamp = int(time.time())
        nd_output = os.path.join(server_path, "repo", druid.hex() + ".nd")

        if not _dtob:
            print("libdtob not loaded, can't build netdoc")
            return

        # OTS proof for the content
        ots_proof = stamp_ots(content_bytes)

        # build the full netdoc via libdtob ctypes
        root = _dtob.dtob_kvset()

        # 1. magic
        magic = b"25032026"
        _dtob.dtob_kvset_put(root, b"magic", _dtob.dtob_raw(magic, len(magic)))

        # 2. ids
        ids = _dtob.dtob_kvset()
        _dtob.dtob_kvset_put(ids, b"druid", _dtob.dtob_raw(druid, 32))
        _dtob.dtob_kvset_put(ids, b"cid", _dtob.dtob_raw(cid if cid else b'\x00' * 32, 32))
        _dtob.dtob_kvset_put(ids, b"sha256", _dtob.dtob_raw(b'\x00' * 32, 32))
        _dtob.dtob_kvset_put(root, b"ids", ids)

        # 3. non-essential metadata (spec: xruid, timestamp, ots_proof + optional extras)
        meta = _dtob.dtob_kvset()
        for key, val in [("title", title), ("preview_html", preview_html)]:
            if val:
                vb = val.encode('utf-8')
                _dtob.dtob_kvset_put(meta, key.encode(), _dtob.dtob_raw(vb, len(vb)))
        if xruid:
            _dtob.dtob_kvset_put(meta, b"xruid", _dtob.dtob_raw(xruid, 32))
        _dtob.dtob_kvset_put(meta, b"word_count", _dtob.dtob_uint(word_count))
        _dtob.dtob_kvset_put(meta, b"timestamp", _dtob.dtob_uint(doc_timestamp))
        if ots_proof:
            _dtob.dtob_kvset_put(meta, b"ots_proof", _dtob.dtob_raw(ots_proof, len(ots_proof)))
        _dtob.dtob_kvset_put(root, b"non_essential_metadata", meta)

        # 4. paleomacrolinks — identifiers only, no hrefs (CAN, not name-addressed)
        zero32 = b'\x00' * 32
        paleo_arr = _dtob.dtob_array()
        for link in macrolinks:
            target_cat, target_fn = _parse_href_target(link["href"], category)
            if target_cat and target_fn:
                def_druid, def_cid = _resolve_target_ids(server_path, target_cat, target_fn)
            else:
                def_druid, def_cid = zero32, zero32
            entry = _dtob_kv_entry(
                def_druid=def_druid,
                ref_druid=druid,
                def_cid=def_cid,
                ref_cid=cid if cid else zero32,
                def_sha256=zero32,
                ref_sha256=zero32,
                ref_start=link["ref_start"],
                ref_end=link["ref_end"],
            )
            _dtob.dtob_array_push(paleo_arr, entry)
        # autolinks (spec: autolink = 2 * slice)
        auto_arr = _dtob.dtob_array()
        for link in autolinks:
            entry = _dtob_kv_entry(
                def_start=link["def_start"],
                def_end=link["def_end"],
                ref_start=link["ref_start"],
                ref_end=link["ref_end"],
            )
            _dtob.dtob_array_push(auto_arr, entry)

        # 5. references
        refs = _dtob.dtob_kvset()
        _dtob.dtob_kvset_put(refs, b"paleotransclusions", _dtob.dtob_array())
        _dtob.dtob_kvset_put(refs, b"paleomicrolinks", _dtob.dtob_array())
        _dtob.dtob_kvset_put(refs, b"paleomacrolinks", paleo_arr)
        _dtob.dtob_kvset_put(refs, b"autotransclusions", _dtob.dtob_array())
        _dtob.dtob_kvset_put(refs, b"autolinks", auto_arr)
        _dtob.dtob_kvset_put(root, b"references", refs)

        # 6. content (raw bytes)
        _dtob.dtob_kvset_put(root, b"content", _dtob.dtob_raw(content_bytes, len(content_bytes)))

        # encode and write
        out_len = ctypes.c_size_t()
        encoded = _dtob.dtob_encode(root, ctypes.byref(out_len))
        if encoded:
            with open(nd_output, 'wb') as f:
                f.write(bytes(encoded[:out_len.value]))
            ctypes.CDLL(None).free(encoded)

        # update XVS (skip append for "update" — same draft, just new content)
        if not is_update:
            update_xvs(server_path, category, file_name, druid, cid, doc_timestamp, xruid=xruid)

        # propagate neolinks to targets (per-druid)
        propagate_neolinks(server_path, category, file_name, macrolinks, druid, cid, doc_timestamp, xruid=xruid)

        # rebuild memcache maps and signal daemons
        if xruid:
            rebuild_memcache_maps(server_path)

        print(f"netdoc: {len(macrolinks)} paleomacrolinks, {len(autolinks)} autolinks, cid={'ok' if cid else 'failed'}, ots={'ok' if ots_proof else 'skipped'}")

    except Exception as e:
        if "dtob" in str(e).lower() or isinstance(e, FileNotFoundError):
            print("dtob not installed")
        else:
            print(f"netdoc error: {e}")
