def ping():
    return True
