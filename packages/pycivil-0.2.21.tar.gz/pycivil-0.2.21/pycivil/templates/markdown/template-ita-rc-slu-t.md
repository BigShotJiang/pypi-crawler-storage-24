<!-- SLU Shear Verification Table -->

### Verifiche SLU a Taglio

| **id** | $T_{ed}$ | $T_{rd}$ | $T_{rcd}$ | $T_{rsd}$ | $\cot\theta$ | $A_{sw}$ | **step** | $\sigma_{cp}$ | **FS** | **check** |
|--------|----------|----------|-----------|-----------|--------------|----------|----------|---------------|--------|-----------|
|        | *[KN]*   | *[KN]*   | *[KN]*    | *[KN]*    | *[...]*      | *[mm²]*  | *[mm]*   | *[N/mm²]*     |        |           |
{% for c in check_SLU_T %}
| {{ c.id }} | {{ c.Ted }} | {{ c.Trd }} | {{ c.Trcd }} | {{ c.Trsd }} | {{ c.cotgtheta }} | {{ c.Asw }} | {{ c.step }} | {{ c.sigmacp }} | {{ c.FS }} | {{ c.check }} |
{% endfor %}
