<!-- SLE Cracking Verification Table -->

### Verifiche FESSURAZIONE

| **id** | $N_{ed}$ | $M_{ed}$ | **state** | $w_k$ | $\sigma_c$ | $\sigma_s$ | $x_i$ | $\epsilon_{sm}$ | **check** |
|--------|----------|----------|-----------|-------|------------|------------|-------|-----------------|-----------|
|        | *[KN]*   | *[KNm]*  | **severity** | $\overline{w}$ | $\overline{\sigma}_c$ | $\sigma_{s,stiff}$ | $\Delta_{sm}$ | $\rho_{eff}$ | **FS** |
|        |          |          |           | *[mm]* | *[N/mm²]* | *[N/mm²]* | *[mm]* | *[...]* | |
{% for c in check_SLE_F %}
| {{ c.id }} | {{ c.Ned }} | {{ c.Med }} | {{ c.state }} | {{ c.wk }} | {{ c.sigmac }} | {{ c.sigmas }} | {{ c.xi }} | {{ c.epsism }} | {{ c.check }} |
|            |             |             | {{ c.severity }} | {{ c.wkMax }} | {{ c.fctcrack }} | {{ c.sigmasStiff }} | {{ c.deltasm }} | {{ c.roeff }} | {{ c.FS }} |
{% endfor %}

---

Il significato delle sigle contenute nella colonna **severity** e riportato nella tabella seguente.

### Tabella delle condizioni ambientali e delle armature

| Gruppi di Esigenze | Condizioni ambientali | Combinazione di azioni | Armatura Sensibile |  | Armatura Poco Sensibile |  |
|--------------------|----------------------|------------------------|--------------------|----|-------------------------|-----|
|                    |                      |                        | **Stato limite** | $w_k$ | **Stato limite** | $w_k$ |
| **A** | Ordinarie | frequente | apertura fessure A2FR | $\leq w_2$ | apertura fessure A1FR | $\leq w_3$ |
|       |           | quasi permanente | apertura fessure A2QP | $\leq w_1$ | apertura fessure A1QP | $\leq w_2$ |
| **B** | Aggressive | frequente | apertura fessure B2FR | $\leq w_1$ | apertura fessure B1FR | $\leq w_2$ |
|       |            | quasi permanente | decompressione B2QP | - | apertura fessure B1QP | $\leq w_1$ |
| **C** | Molto aggressive | frequente | formazione fessure C2FR | - | apertura fessure C1FR | $\leq w_1$ |
|       |                  | quasi permanente | decompressione C1QP | - | apertura fessure C2QP | $\leq w_1$ |
