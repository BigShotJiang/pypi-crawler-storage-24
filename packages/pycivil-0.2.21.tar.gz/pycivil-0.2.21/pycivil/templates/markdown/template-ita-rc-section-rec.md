<!-- Rectangular RC Section Definition -->

{% if shape == 'RECT' %}
La sezione ha forma *rettangolare* con le seguenti caratteristiche geometriche:

| Parametro | Valore |
|-----------|--------|
| $b$ | {{ width }} *mm* |
| $h$ | {{ height }} *mm* |

<!-- Placeholder: section image will be generated here in future -->
*[Immagine della sezione: da generare]*
![Immagine delle sezione](section.png){width=70%}

{% endif %}

---

Di seguito la tabella relativa al posizionamento degli acciai, essendo $d$ il diametro ed $A$ l'area:

### Tabella dei rinforzi

| **id** | $X$ | $Y$ | $d$ | $A$ |
|--------|-----|-----|-----|-----|
|        | *[mm]* | *[mm]* | *[mm]* | *[mm²]* |
{% for r in rebars %}
| {{ r.id }} | {{ r.xPos }} | {{ r.yPos }} | {{ r.diam }} | {{ r.area }} |
{% endfor %}

### Armatura trasversale (staffe)

| Parametro | Valore |
|-----------|--------|
| $A_{sw}$ | {{ stirrupArea }} *mm²* |
| $s$ | {{ stirrupStep }} *mm* |
| $\alpha$ | {{ stirrupAngle }} *°* |
