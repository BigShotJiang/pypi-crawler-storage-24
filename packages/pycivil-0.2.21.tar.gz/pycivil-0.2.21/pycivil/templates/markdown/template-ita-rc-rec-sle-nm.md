<!-- SLE Verification Table for Rectangular RC Sections -->

### Verifiche SLE

| **id** | $N_{ed}$ | $M_{ed}$ | $\sigma_s$ | $\sigma_c$ | $x_i$ | **FS** | **check** |
|--------|----------|----------|------------|------------|-------|--------|-----------|
|        | *[KN]*   | *[KNm]*  | $\overline{\sigma}_s$ | $\overline{\sigma}_c$ | *[mm]* | | |
|        |          |          | *[N/mm²]*  | *[N/mm²]*  |       |        |           |
{% for c in check_SLE_MN %}
| {{ c.id }} | {{ c.Ned }} | {{ c.Med }} | {{ c.sigmas }} | {{ c.sigmac }} | {{ c.xi }} | {{ c.FS }} | {{ c.check }} |
|            |             |             | {{ c.sigmxs }} | {{ c.sigmxc }} |            |            |               |
{% endfor %}
