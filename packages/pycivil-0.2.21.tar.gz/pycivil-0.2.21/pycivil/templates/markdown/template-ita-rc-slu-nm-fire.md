<!-- SLU Fire Verification Table -->

Nella seguente figura sono rappresentati i due domini della sezione a caldo e a freddo. Il dominio a caldo e rappresentato in rosso.

{% if domain %}
### Dominio di interazione SLU per pressoflessione retta ed incendio

![Dominio di interazione SLU]({{ domainUrl }}){width=90%}
{% endif %}

---

La sezione ridotta utilizzando il *metodo della isoterma 500* ha forma *rettangolare* con le seguenti caratteristiche geometriche:

| Parametro | Valore |
|-----------|--------|
| $b_{red}$ | {{ width }} *mm* |
| $h_{red}$ | {{ height }} *mm* |

Per la mappatura termica della sezione sono stati utilizzati i seguenti parametri di incendio:

| Parametro | Valore |
|-----------|--------|
| Curva di incendio | {{ curve }} |
| Tempo di incendio | {{ time }} *min* |

---

### Verifiche SLU per pressoflessione retta e incendio

| **id** | $N_{ed}$ | $M_{ed}$ | $N_{er}$ | $M_{er}$ | **FS** | **check** |
|--------|----------|----------|----------|----------|--------|-----------|
|        | *[KN]*   | *[KNm]*  | *[KN]*   | *[KNm]*  | *[...]* | *[...]* |
{% for c in check_SLU_MN %}
| {{ c.id }} | {{ c.Ned }} | {{ c.Med }} | {{ c.Ner }} | {{ c.Mer }} | {{ c.FS }} | {{ c.check }} |
{% endfor %}
