<!-- SLU Verification Table for Rectangular RC Sections -->

### Verifiche SLU per pressoflessione retta

| **id** | $N_{ed}$ | $M_{ed}$ | $N_{er}$ | $M_{er}$ | **FS** | **check** |
|--------|----------|----------|----------|----------|--------|-----------|
|        | *[KN]*   | *[KNm]*  | *[KN]*   | *[KNm]*  | *[...]* | *[...]*  |
{% for c in check_SLU_MN %}
| {{ c.id }} | {{ c.Ned }} | {{ c.Med }} | {{ c.Ner }} | {{ c.Mer }} | {{ c.FS }} | {{ c.check }} |
{% endfor %}

{% if domain %}
### Dominio di interazione SLU per pressoflessione retta

![Dominio di interazione SLU]({{ domainUrl }}){width=90%}
{% endif %}
