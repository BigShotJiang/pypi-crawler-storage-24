#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Elemento strutturale e classe di calcestruzzo*]),
    [Elemento strutturale:], [*<< elementDescr >>*],
    [Norma utilizzata:], [*<< keyCode >>*],
    [Classe del calcestruzzo:], [*<< concreteClass >>*],
  ),
)

#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Valori medi e caratteristici* \[N/mm²\]]),
    [Caratteristica], [Valore],
    [Resistenza cubica a 28gg], [$R_(c k) = << value_Rck >>$],
    [Resistenza cilindrica a 28gg], [$f_(c k) = << value_fck >>$],
    [Resistenza media a compressione], [$f_(c m) = f_(c k) + 8 = << value_fcm >>$],
    [Resistenza media a trazione], [$f_(c t m) = << value_fctm >>$],
    [Modulo elastico medio], [$E_(c m) = 22000 (f_(c m) / 10)^0.3 = << value_Ecm >>$],
  ),
)

#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Valori di progetto* \[N/mm²\]]),
    [Caratteristica], [Valore],
    [Riduzione a lungo termine], [$alpha_(c c) = << value_alphacc >>$],
    [Coefficiente di sicurezza], [$gamma_c = << value_gammac >>$],
    [Resistenza cilindrica di progetto], [$f_(c d) = alpha_(c c) dot f_(c k) / gamma_c = << value_fcd >>$],
    [Max compr. in combinazione rara], [$sigma^("car")_(c, max) = 0.60 dot f_(c k) = << value_sigmaCar >>$],
    [Max compr. in combinazione q.p.], [$sigma^("qp")_(c, max) = 0.45 dot f_(c k) = << value_sigmaQp >>$],
  ),
)
