#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Dati generali*]),
    [Elemento strutturale:], [*<< elementDescr >>*],
    [Norma utilizzata per il materiale:], [*<< keyCode >>*],
  ),
)

#figure(
  table(
    columns: (auto, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Caratteristiche dei materiali*]),
    [Descrizione], [Valore], [u.d.m.],
    [Classe del calcestruzzo:], [*<< concreteClass >>*], [...],
    [Resistenza cilindrica a compressione:], [$f_(c k) = << cls_fck >>$], [N/mm²],
    [Resistenza media a trazione:], [$f_(c t m) = << cls_fctm >>$], [N/mm²],
    [Classe di acciaio:], [*<< steelClass >>*], [...],
    [Resistenza caratteristica a snervamento:], [$f_(y k) = << steel_fyk >>$], [N/mm²],
  ),
)

#figure(
  table(
    columns: (auto, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Dati geometrici della sezione*]),
    [Descrizione], [Valore], [u.d.m.],
    [Altezza dell'elemento:], [$H = << hEl >>$], [mm],
    [Diametro delle barre principali:], [$phi_(l t) = << rebarD >>$], [mm],
    [Diametro delle barre secondarie:], [$phi^*_(l t) = << rebarDSec >>$], [mm],
    [Copriferro delle barre principali:], [$c = << cover >>$], [mm],
    [Copriferro delle barre secondarie:], [$c^* = << coverSec >>$], [mm],
    [Diametro barre trasversali:], [$phi_(s t) = << stirrupD >>$], [mm],
    [Numero di bracci trasversali:], [$n_(b,t) = << nbLegDirX >>$], [...],
  ),
)

#figure(
  table(
    columns: (4cm, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Armatura a flessione minima in direzione principale*]),
    [Descrizione], [Valore], [u.d.m.],
    [Altezza utile], [$d = H - c - phi_(l t) / 2 = << heightUtil >>$], [mm],
    [Area utile], [$A_u = b_(t,"med") dot d = 1000 dot d = << areaUtil >>$], [mm²],
    [Area minima criterio (1)], [$A^((1))_("min") = 0.26 dot f_(c t m) / f_(y k) dot A_u = << minimumRebarAreaCrit1 >>$], [mm²],
    [Area minima criterio (2)], [$A^((2))_("min") = 0.0013 dot A_u = << minimumRebarAreaCrit2 >>$], [mm²],
    [Area minima], [$A_("min") = max(A^((1))_("min"), A^((2))_("min")) = << minimumRebarArea >>$], [mm²],
    [Distanza max zona corrente], [$s_("max,slabs") = min(3H, 400) = << distMaxRebar >>$], [mm],
    [Distanza max con M max], [$s^m_("max,slabs") = min(2H, 250) = << distMaxRebarMaxLoad >>$], [mm],
    [Area acciaio zona corrente], [$A_("disp") = << disposedRebarArea >>$], [mm²],
    [Numero barre zona corrente], [$n_("disp") = << disposedRebarNumber >>$], [...],
    [Area acciaio con M max], [$A^m_("disp") = << disposedRebarAreaMaxLoad >>$], [mm²],
    [Numero barre con M max], [$n^m_("disp") = << disposedRebarNumberMaxLoad >>$], [...],
  ),
)

#figure(
  table(
    columns: (4cm, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Armatura a flessione minima in direzione secondaria*]),
    [Descrizione], [Valore], [u.d.m.],
    [Altezza utile], [$d^* = H^* - c^* - phi^*_(l t) / 2 = << heightUtilSec >>$], [mm],
    [Area utile], [$A^*_u = b^*_(t,"med") dot d^* = 1000 dot d^* = << areaUtilSec >>$], [mm²],
    [Area minima criterio (1)], [$A^(*,(1))_("min") = 0.26 dot f_(c t m) / f_(y k) dot A^*_u = << minimumRebarAreaCrit1Sec >>$], [mm²],
    [Area minima criterio (2)], [$A^(*,(2))_("min") = 0.0013 dot A^*_u = << minimumRebarAreaCrit2Sec >>$], [mm²],
    [Area minima], [$A^*_("min") = max(A^(*,(1))_("min"), A^(*,(2))_("min")) = << minimumRebarAreaSec >>$], [mm²],
    [Distanza max zona corrente], [$s^*_("max,slabs") = min(3.5 H^*, 450) = << distMaxRebarSec >>$], [mm],
    [Distanza max con M max], [$s^(*,m)_("max,slabs") = min(3 H^*, 400) = << distMaxRebarMaxLoadSec >>$], [mm],
    [Area acciaio zona corrente], [$A^*_("disp") = << disposedRebarAreaSec >>$], [mm²],
    [Numero barre zona corrente], [$n^*_("disp") = << disposedRebarNumberSec >>$], [...],
    [Area acciaio con M max], [$A^(*,m)_("disp") = << disposedRebarAreaMaxLoadSec >>$], [mm²],
    [Numero barre con M max], [$n^(*,m)_("disp") = << disposedRebarNumberMaxLoadSec >>$], [...],
  ),
)

#figure(
  table(
    columns: (4cm, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Armatura a taglio minima (spilli)*]),
    [Descrizione], [Valore], [u.d.m.],
    [Area minima per metro], [$A_(s w,"min") / s = 0.08 dot sqrt(f_(c k)) / f_(y k) = << minimumRebarAreaForElementLenght >>$], [mm²],
    [Passo max trasversale], [$s_(t,"max") = 1.5 dot d = << maxStepTrasv >>$], [mm],
    [N. bracci per area minima], [$n_b = << legsNumber >>$], [...],
    [N. bracci trasversali], [$n_(b,c) = << legsNumberTrasv >>$], [...],
    [Passo max (1)], [$s^((1))_("max") = n_(b,t) / n_b dot 1000 = << maxStepLongCrit1 >>$], [mm],
    [Passo max altezza utile (2)], [$s^((2))_("max") = 0.75 dot d dot (1 + cot alpha) = << maxStepLongCrit2 >>$], [mm],
    [Passo max generale], [$s_("max") = min(s^((1))_("max"), s^((2))_("max")) = << maxStep >>$], [mm],
    [Area staffe per metro], [$A_(s w) / s = << rebarAreaForElementLenght >>$], [mm²],
  ),
)
