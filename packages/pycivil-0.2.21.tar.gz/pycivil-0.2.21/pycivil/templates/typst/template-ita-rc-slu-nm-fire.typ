Nella seguente figura sono rappresentati i due domini della sezione a caldo e a freddo. Il dominio a caldo è rappresentato in rosso.

<%% if domain %%>
#figure(
  image("<< domainUrl >>", width: 90%),
  caption: [Dominio di interazione SLU per pressoflessione retta ed incendio],
)
<%% endif %%>

La sezione ridotta utilizzando il _metodo della isoterma 500_ ha forma _rettangolare_ con le seguenti caratteristiche geometriche sono:

$ b_("red") &= << width >> " mm" quad& h_("red") &= << height >> " mm" $

Per la mappatura termica della sezione sono stati utilizzati i seguenti parametri di incendio:

$ "Curva di incendio" &= "<< curve >>" quad& "Tempo di incendio" &= "<< time >>" " min" $

#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto),
    align: (center, right, right, right, right, right, center),
    table.header(
      [*id*], [$bold(N_(e d))$ \ _\[KN\]_], [$bold(M_(e d))$ \ _\[KNm\]_], [$bold(N_(e r))$ \ _\[KN\]_], [$bold(M_(e r))$ \ _\[KNm\]_], [$bold(F S)$ \ _\[...\]_], [$bold("check")$ \ _\[...\]_],
    ),
    <%% for c in check_SLU_MN %%>
    [<< c.id >>], [<< c.Ned >>], [<< c.Med >>], [<< c.Ner >>], [<< c.Mer >>], [<< c.FS >>], [<< c.check >>],
    <%% endfor %%>
  ),
  caption: [Verifiche SLU per pressoflessione retta e incendio],
)
