#figure(
  table(
    columns: (auto, auto, auto, auto, auto, auto, auto, auto),
    align: (center, right, right, right, right, right, right, center),
    table.header(
      [*id*], [$bold(N_(e d))$ \ _\[KN\]_], [$bold(M_(x e d))$ \ _\[KNm\]_], [$bold(M_(y e d))$ \ _\[KNm\]_], [$bold(sigma_s)$ / $overline(sigma)_s$ \ _\[N/mm²\]_], [$bold(sigma_c)$ / $overline(sigma)_c$ \ _\[N/mm²\]_], [$bold(F S)$], [$bold("check")$],
    ),
    <%% for c in check_SLE_MN %%>
    [<< c.id >>], [<< c.Ned >>], [<< c.Mxed >>], [<< c.Myed >>], [<< c.sigmas >> / << c.sigmaxs >>], [<< c.sigmac >> / << c.sigmaxc >>], [<< c.FS >>], [<< c.check >>],
    <%% endfor %%>
  ),
  caption: [Verifiche SLE],
)

<%% for f in figures %%>
#figure(
  grid(
    columns: 2,
    gutter: 1em,
    <%% for url in f.domainUrls %%>
    image("<< url.domainUrl >>", width: 100%),
    <%% endfor %%>
  ),
  caption: [Tensioni agli SLE - Parte << f.figIndex >> di << nbFigs >>],
)
<%% endfor %%>
