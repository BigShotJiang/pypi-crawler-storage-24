#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Dati generali*]),
    [Elemento strutturale:], [*<< elementDescr >>*],
    [Norma utilizzata per il materiale:], [*<< keyCode >>*],
  ),
)

#figure(
  table(
    columns: (auto, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Caratteristiche dei materiali*]),
    [Descrizione], [Valore], [u.d.m.],
    [Classe del calcestruzzo:], [*<< concreteClass >>*], [...],
    [Resistenza cilindrica a compressione:], [$f_(c k) = << cls_fck >>$], [N/mm²],
    [Resistenza media a trazione:], [$f_(c t m) = << cls_fctm >>$], [N/mm²],
    [Classe di acciaio:], [*<< steelClass >>*], [...],
    [Resistenza caratteristica a snervamento:], [$f_(y k) = << steel_fyk >>$], [N/mm²],
  ),
)

#figure(
  table(
    columns: (auto, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Dati geometrici della sezione*]),
    [Descrizione], [Valore], [u.d.m.],
    [Altezza dell'elemento:], [$H = << hEl >>$], [mm],
    [Larghezza dell'elemento:], [$W = << wEl >>$], [mm],
    [Larghezza media in zona tesa:], [$b_(t,"med") = << bt >>$], [mm],
    [Diametro barre longitudinali:], [$phi_(l t) = << rebarD >>$], [mm],
    [Copriferro barre longitudinali:], [$c = << cover >>$], [mm],
    [Larghezza minima a taglio:], [$b_(t,"min") = << bMin >>$], [mm],
    [Diametro barre compresse:], [$phi_(l c) = << rebarDComp >>$], [mm],
    [Diametro staffe o spilli:], [$phi_(s t) = << stirrupD >>$], [mm],
    [N. bracci trasversali assegnato:], [$n_(b,t) = << nbLegDirX >>$], [...],
  ),
)

#figure(
  table(
    columns: (4cm, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Armatura a flessione minima*]),
    [Descrizione], [Valore], [u.d.m.],
    [Altezza utile], [$d = H - c - phi_(l t) / 2 = << heightUtil >>$], [mm],
    [Area utile], [$A_u = b_(t,"med") dot d = 1000 dot d = << areaUtil >>$], [mm²],
    [Area minima criterio (1)], [$A^((1))_("min") = 0.26 dot f_(c t m) / f_(y k) dot A_u = << minimumRebarAreaCrit1 >>$], [mm²],
    [Area minima criterio (2)], [$A^((2))_("min") = 0.0013 dot A_u = << minimumRebarAreaCrit2 >>$], [mm²],
    [Area minima], [$A_("min") = max(A^((1))_("min"), A^((2))_("min")) = << minimumRebarArea >>$], [mm²],
    [Area acciaio disposta], [$A_("disp") = << rebarAreaDisposed >>$], [mm²],
    [Numero barre disposte], [$n_("disp") = << rebarNumber >>$], [...],
  ),
)

#figure(
  table(
    columns: (4cm, 1fr, auto),
    align: (left, left, center),
    table.header(table.cell(colspan: 3, align: center)[*Armatura a taglio minima (spilli o staffe)*]),
    [Descrizione], [Valore], [u.d.m.],
    [Area minima per metro], [$A_(s w,"min") / s = 1.5 dot b_(t,"min") = << minimumRebarAreaForElementLenght >>$], [mm²/m],
    [N. bracci totale], [$n_b = << minimumLegsForElementLenght >>$], [...],
    [Passo max (1)], [$s^((1))_("max") = n_(b,t) / n_b dot 1000 = << maxStepCrit1 >>$], [mm],
    [Passo max altezza utile (2)], [$s^((2))_("max") = 0.8 dot d = << maxStepCrit3 >>$], [mm],
    [Passo max assoluto (3)], [$s^((3))_("max") = << maxStepCrit2 >>$], [mm],
    [Passo max barre compresse (4)], [$s^((4))_("max") = 15 dot phi_(l c) = << maxStepCrit4 >>$], [mm],
    [Passo max generale], [$s_("max") = min(s^((1))_("max"), s^((2))_("max"), s^((3))_("max")) = << stirrupStepMin >>$], [mm],
    [Passo max con barre compresse], [$s_("max") = min(s^((1))_("max"), s^((4))_("max")) = << stirrupCompStepMin >>$], [mm],
  ),
)
