<%% if geometryFigure %%>
#figure(
  image("<< geometryUrl >>", width: 90%),
  caption: [Plot della sezione trasversale],
)
<%% endif %%>

Si riportano nella tabella seguente le coordinate dei vertici della sezione ed il loro identificativo _id_:

#figure(
  table(
    columns: (auto, auto, auto),
    align: (center, center, center),
    table.header(
      [*id*], [$bold(X)$ \ _\[mm\]_], [$bold(Y)$ \ _\[mm\]_],
    ),
    <%% for v in vertices %%>
    [<< v.id >>], [<< v.xPos >>], [<< v.yPos >>],
    <%% endfor %%>
  ),
  caption: [Tabella dei vertici],
)

<%% if namedVertices %%>
La sezione è di forma specifica _<< sectionShape >>_ con i seguenti parametri:

<%% if rectangularShape %%>
$ b &= << shape_width >> " mm" quad& h &= << shape_height >> " mm" $
<%% endif %%>

Le coordinate notevoli dei vertici sono espresse nella seguente tabella:

#figure(
  table(
    columns: (auto, auto, auto),
    align: (center, center, center),
    table.header(
      [*id*], [$bold(X)$ \ _\[mm\]_], [$bold(Y)$ \ _\[mm\]_],
    ),
    <%% for n in namedVertices %%>
    [<< n.name >>], [<< n.xPos >>], [<< n.yPos >>],
    <%% endfor %%>
  ),
  caption: [Tabella dei vertici notevoli],
)
<%% endif %%>

mentre nella seguente tabella si rappresenta la connettività dei triangoli:

#figure(
  table(
    columns: (auto, auto, auto, auto),
    align: (center, center, center, center),
    table.header(
      [*id*], [*id\_1*], [*id\_2*], [*id\_3*],
    ),
    <%% for t in triangles %%>
    [<< t.id >>], [<< t.id1 >>], [<< t.id2 >>], [<< t.id3 >>],
    <%% endfor %%>
  ),
  caption: [Tabella dei triangoli e connettività],
)

Di seguito la tabella relativa al posizionamento degli acciai, essendo _id_ l'identificativo della barra, $X$ ed $Y$ le coordinate, $d$ il diametro e _idv_ l'identificativo del vertice:

#figure(
  table(
    columns: (auto, auto, auto, auto, auto),
    align: (center, center, center, center, center),
    table.header(
      [*id*], [$bold(X)$ \ _\[mm\]_], [$bold(Y)$ \ _\[mm\]_], [$bold(d)$ \ _\[mm\]_], [*idv*],
    ),
    <%% for r in rebars %%>
    [<< r.id >>], [<< r.xPos >>], [<< r.yPos >>], [<< r.diam >>], [<< r.id_v >>],
    <%% endfor %%>
  ),
  caption: [Tabella dei rinforzi],
)
