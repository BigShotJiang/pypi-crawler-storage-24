#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Elemento strutturale e classe di acciaio*]),
    [Elemento strutturale:], [*<< elementDescr >>*],
    [Norma utilizzata:], [*<< keyCode >>*],
    [Classe di acciaio:], [*<< steelClass >>*],
  ),
)

#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Valori medi e caratteristici* \[N/mm²\]]),
    [Caratteristica], [Valore],
    [Resistenza caratteristica a snervamento], [$f_(y k) = << value_fyk >>$],
    [Resistenza caratteristica a rottura], [$f_(t k) = << value_ftk >>$],
    [Modulo elastico], [$E_s = << value_Es >>$],
  ),
)

#figure(
  table(
    columns: (auto, 1fr),
    align: (left, left),
    table.header(table.cell(colspan: 2, align: center)[*Valori di progetto* \[N/mm²\]]),
    [Caratteristica], [Valore],
    [Coefficiente di sicurezza SLU], [$gamma_s = << value_gammas >>$],
    [Resistenza a trazione di progetto], [$f_(y d) = f_(y k) / gamma_s = << value_fyd >>$],
    [Limite di tensione in combinazione rara], [$sigma^("car")_(s, max) = 0.80 dot f_(y k) = << value_sigmaCar >>$],
  ),
)
