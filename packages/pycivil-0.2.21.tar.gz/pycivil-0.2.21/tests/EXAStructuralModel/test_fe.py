import pytest

from pycivil.EXAStructuralModel import fe

# Test that show difference between model and mesh assigning relative tags
# The way to force mesh recognition elements with tags is assign a physical
# group during creation of 0d and 1d element
def test_fe_1d_elements_001():
    # It builds an analytical model
    #
    am = fe.FEModel(descr=f"Model for {__name__}", modelName=__name__)

    # Only one model created currently by constructor ...
    #
    assert len(am.getModels()) == 1

    # ... named as passed in modelName ard during init
    #
    assert am.getModels()[0] == __name__

    # I build 3 nodes, forcing tag to specific values to 3, 5, 7
    #
    node_3 = am.addNode(
        x=0.0, y=0.0, z=5.0,
        tag=3, group=True, tagGroup=13
    )
    assert node_3 == 3
    node_3_pg = am.getNodesByPhysicalGroup(13)
    assert node_3_pg[0] == 3

    node_5 = am.addNode(
        x=5.0, y=0.0, z=5.0,
        tag=5, group=True, tagGroup=15
    )
    assert node_5 == 5
    node_5_pg = am.getNodesByPhysicalGroup(15)
    assert node_5_pg[0] == 5

    node_7 = am.addNode(
        x=10.0, y=0.0, z=5.0,
        tag=7, group=True, tagGroup=17
    )
    assert node_7 == 7
    node_7_pg = am.getNodesByPhysicalGroup(17)
    assert node_7_pg[0] == 7

    # I build 2 frames linked to nodes meshed in one element each one forcing
    # tag to 1 and 2.
    #
    frame_20 = am.addFrame(
        tagStart=node_5, tagEnd=node_7, tag=20,
        group=True, tagGroup=21, nb=1
    )
    assert frame_20 == 20

    frame_20_pg = am.getFramesByPhysicalGroup(21)
    assert frame_20_pg[0] == 20

    frame_10 = am.addFrame(
        tagStart=node_3, tagEnd=node_5, tag=10,
        group=True, tagGroup=11, nb=1
    )
    assert frame_10 == 10

    frame_10_pg = am.getFramesByPhysicalGroup(11)
    assert frame_10_pg[0] == 10

    # am.show()

