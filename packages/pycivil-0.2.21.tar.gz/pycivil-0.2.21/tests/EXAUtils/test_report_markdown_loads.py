# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

from pathlib import Path

from pycivil.EXAStructural.loads import (
    ForcesOnSection,
)
from pycivil.EXAStructural.loads import Frequency_Enum as Fr
from pycivil.EXAStructural.loads import LimiteState_Enum as Ls
from pycivil.EXAUtils.markdownReportMakers import ForcesOnSectionListMdFB
from pycivil.EXAUtils.report import (
    MarkdownReporter,
    ReportTemplateEnum,
    getMarkdownTemplatesPath,
)


def test_report_markdown_loads(tmp_path: Path):
    """Test forces on section list markdown fragment generation."""
    markdownTemplatePath = getMarkdownTemplatesPath()
    fragmentBuilder = ForcesOnSectionListMdFB(markdownTemplatePath)
    listOfForces = fragmentBuilder.forces()

    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 101,
            Fy=1e3 * 201,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f1",
            id=1,
            limitState=Ls.ULTIMATE,
            frequency=Fr.FREQUENCY_ND,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 102,
            Fy=1e3 * 202,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f2",
            id=2,
            limitState=Ls.ULTIMATE,
            frequency=Fr.FREQUENCY_ND,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 103,
            Fy=1e3 * 203,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f3",
            id=3,
            limitState=Ls.ULTIMATE,
            frequency=Fr.FREQUENCY_ND,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 104,
            Fy=1e3 * 204,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f4",
            id=4,
            limitState=Ls.ULTIMATE,
            frequency=Fr.FREQUENCY_ND,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 105,
            Fy=1e3 * 205,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f5",
            id=5,
            limitState=Ls.SERVICEABILITY,
            frequency=Fr.CHARACTERISTIC,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 106,
            Fy=1e3 * 206,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f6",
            id=6,
            limitState=Ls.SERVICEABILITY,
            frequency=Fr.FREQUENT,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 107,
            Fy=1e3 * 207,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f7",
            id=7,
            limitState=Ls.SERVICEABILITY,
            frequency=Fr.QUASI_PERMANENT,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 108,
            Fy=1e3 * 208,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="f9",
            id=8,
            limitState=Ls.LIMIT_STATE_ND,
            frequency=Fr.FREQUENCY_ND,
        )
    )

    f1 = fragmentBuilder.buildFragment()

    print(f1.frags())

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f1])
    reporter.compileDocument(path=str(tmp_path), output_format="md")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()

    # Verify content has load data
    content = tmp_path.joinpath("report.md").read_text(encoding="utf-8")
    assert "f1" in content or "101" in content


def test_report_markdown_loads_with_html(tmp_path: Path):
    """Test forces on section list with HTML output."""
    markdownTemplatePath = getMarkdownTemplatesPath()
    fragmentBuilder = ForcesOnSectionListMdFB(markdownTemplatePath)
    listOfForces = fragmentBuilder.forces()

    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 100,
            Fy=1e3 * 200,
            Fz=1e3 * 300,
            Mx=1e3 * 100000,
            My=1e3 * 200000,
            Mz=1e3 * 300000,
            descr="Load 1",
            id=1,
            limitState=Ls.ULTIMATE,
            frequency=Fr.FREQUENCY_ND,
        )
    )
    listOfForces.append(
        ForcesOnSection(
            Fx=1e3 * 50,
            Fy=1e3 * 100,
            Fz=1e3 * 150,
            Mx=1e3 * 50000,
            My=1e3 * 100000,
            Mz=1e3 * 150000,
            descr="Load 2",
            id=2,
            limitState=Ls.SERVICEABILITY,
            frequency=Fr.CHARACTERISTIC,
        )
    )

    f1 = fragmentBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(template=ReportTemplateEnum.MD_ENG_CAL, fragments=[f1])
    reporter.compileDocument(path=str(tmp_path), output_format="html")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("report.md").exists()
    assert tmp_path.joinpath("report.html").exists()
