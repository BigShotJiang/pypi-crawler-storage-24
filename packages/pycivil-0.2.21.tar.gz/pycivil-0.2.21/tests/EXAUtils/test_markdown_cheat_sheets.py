# Copyright (c) 2026 Luigi Paone <ppc.luigi.paone@gmail.com>
# SPDX-License-Identifier: BSD-3-Clause

"""Tests for markdown cheat sheets generation.

These tests verify the markdown and HTML cheat sheet generation for:
- Concrete material properties (NTC2018)
- Rebar material properties (NTC2018)
- Beam minimum area (NTC2018)
- Plate minimum area (EC2-1-1)
"""

from pathlib import Path

import pytest

from pycivil.EXAStructural.cheatsheets.codeEC2Rules import (
    PlateMinimumArea,
    PlateMinimumAreaInput,
    PlateMinimumAreaLogs,
    SolverPlateMinRebar,
)
from pycivil.EXAStructural.cheatsheets.codeNTC2018Rules import (
    BeamMinimumArea,
    BeamMinimumAreaInput,
    BeamMinimumAreaLogs,
    BeamMinimumAreaOutput,
    ConcreteMaterial,
    ConcreteMaterialInput,
    ConcreteMaterialOutput,
    RebarMaterial,
    RebarMaterialInput,
    RebarMaterialOutput,
    SolverBeamMinRebar,
    SolverConcrete,
    SolverSteelRebar,
)
from pycivil.EXAUtils import markdownCheatSheets
from pycivil.EXAUtils.report import (
    MarkdownFragment,
    MarkdownReporter,
    ReportTemplateEnum,
    getMarkdownTemplatesPath,
)


def test_concrete_material_markdown(tmp_path: Path):
    """Test concrete material cheat sheet generation in markdown format."""
    matInput = ConcreteMaterialInput()
    solver = SolverConcrete(inputModel=matInput)

    assert solver.run()

    outputData = solver.getModelOutput()
    assert isinstance(outputData, ConcreteMaterialOutput)
    material = ConcreteMaterial(inputData=matInput, outputData=outputData)

    markdownTemplatePath = getMarkdownTemplatesPath()

    print(f"Markdown Templates path for test is {markdownTemplatePath}")
    fragBuilder = markdownCheatSheets.ConcreteMaterialMdCS(
        markdownTemplatePath=markdownTemplatePath, data=material
    )

    frag_title = MarkdownFragment()
    frag_title.add(line="## Calcestruzzo adottato per l'elemento")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="MD_ENG_CAL", output_format="md")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("MD_ENG_CAL.md").exists()


def test_concrete_material_html(tmp_path: Path):
    """Test concrete material cheat sheet generation in HTML format."""
    matInput = ConcreteMaterialInput()
    solver = SolverConcrete(inputModel=matInput)

    assert solver.run()

    outputData = solver.getModelOutput()
    assert isinstance(outputData, ConcreteMaterialOutput)
    material = ConcreteMaterial(inputData=matInput, outputData=outputData)

    markdownTemplatePath = getMarkdownTemplatesPath()

    fragBuilder = markdownCheatSheets.ConcreteMaterialMdCS(
        markdownTemplatePath=markdownTemplatePath, data=material
    )

    frag_title = MarkdownFragment()
    frag_title.add(line="## Calcestruzzo adottato per l'elemento")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="HTML_ENG_CAL", output_format="html")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("HTML_ENG_CAL.md").exists()
    assert tmp_path.joinpath("HTML_ENG_CAL.html").exists()

    # Check HTML contains MathJax for LaTeX rendering
    html_content = tmp_path.joinpath("HTML_ENG_CAL.html").read_text(encoding="utf-8")
    assert "MathJax" in html_content
    assert "f_{ck}" in html_content or "fck" in html_content


def test_rebar_material_markdown(tmp_path: Path):
    """Test rebar material cheat sheet generation in markdown format."""
    matInput = RebarMaterialInput()
    solver = SolverSteelRebar(inputModel=matInput)

    assert solver.run()
    outputData = solver.getModelOutput()
    assert isinstance(outputData, RebarMaterialOutput)
    material = RebarMaterial(inputData=matInput, outputData=outputData)

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragBuilder = markdownCheatSheets.RebarMaterialMdCS(
        markdownTemplatePath=markdownTemplatePath, data=material
    )
    frag_title = MarkdownFragment()
    frag_title.add(line="## Acciaio adottato per l'elemento")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="MD_ENG_CAL", output_format="md")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("MD_ENG_CAL.md").exists()


def test_rebar_material_html(tmp_path: Path):
    """Test rebar material cheat sheet generation in HTML format."""
    matInput = RebarMaterialInput()
    solver = SolverSteelRebar(inputModel=matInput)

    assert solver.run()
    outputData = solver.getModelOutput()
    assert isinstance(outputData, RebarMaterialOutput)
    material = RebarMaterial(inputData=matInput, outputData=outputData)

    markdownTemplatePath = getMarkdownTemplatesPath()
    fragBuilder = markdownCheatSheets.RebarMaterialMdCS(
        markdownTemplatePath=markdownTemplatePath, data=material
    )
    frag_title = MarkdownFragment()
    frag_title.add(line="## Acciaio adottato per l'elemento")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="HTML_ENG_CAL", output_format="html")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("HTML_ENG_CAL.md").exists()
    assert tmp_path.joinpath("HTML_ENG_CAL.html").exists()


def test_beam_minimum_area_markdown(tmp_path: Path):
    """Test beam minimum area cheat sheet generation in markdown format."""
    dataInput = BeamMinimumAreaInput()
    solver = SolverBeamMinRebar(inputModel=dataInput)

    assert solver.run()

    logsData = solver.getModelLogs()
    assert isinstance(logsData, BeamMinimumAreaLogs)

    outputData = solver.getModelOutput()
    assert isinstance(outputData, BeamMinimumAreaOutput)

    data = BeamMinimumArea(
        inputData=dataInput,
        logsData=logsData,
        outputData=outputData,
    )

    markdownTemplatePath = getMarkdownTemplatesPath()

    fragBuilder = markdownCheatSheets.BeamMinimumAreaMdCS(
        markdownTemplatePath=markdownTemplatePath, data=data
    )

    frag_title = MarkdownFragment()
    frag_title.add(line="## Area minima delle travi secondo NTC2018")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="MD_ENG_CAL", output_format="md")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("MD_ENG_CAL.md").exists()


def test_beam_minimum_area_html(tmp_path: Path):
    """Test beam minimum area cheat sheet generation in HTML format."""
    dataInput = BeamMinimumAreaInput()
    solver = SolverBeamMinRebar(inputModel=dataInput)

    assert solver.run()

    logsData = solver.getModelLogs()
    assert isinstance(logsData, BeamMinimumAreaLogs)

    outputData = solver.getModelOutput()
    assert isinstance(outputData, BeamMinimumAreaOutput)

    data = BeamMinimumArea(
        inputData=dataInput,
        logsData=logsData,
        outputData=outputData,
    )

    markdownTemplatePath = getMarkdownTemplatesPath()

    fragBuilder = markdownCheatSheets.BeamMinimumAreaMdCS(
        markdownTemplatePath=markdownTemplatePath, data=data
    )

    frag_title = MarkdownFragment()
    frag_title.add(line="## Area minima delle travi secondo NTC2018")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="HTML_ENG_CAL", output_format="html")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("HTML_ENG_CAL.md").exists()
    assert tmp_path.joinpath("HTML_ENG_CAL.html").exists()


def test_plate_minimum_area_markdown(tmp_path: Path):
    """Test plate minimum area cheat sheet generation in markdown format."""
    dataInput = PlateMinimumAreaInput()
    solver = SolverPlateMinRebar(inputModel=dataInput)

    assert solver.run()

    logsData = solver.getModelLogs()
    assert isinstance(logsData, PlateMinimumAreaLogs)

    data = PlateMinimumArea(
        inputData=dataInput,
        logsData=logsData,
    )

    markdownTemplatePath = getMarkdownTemplatesPath()

    fragBuilder = markdownCheatSheets.PlateMinimumAreaMdCS(
        markdownTemplatePath=markdownTemplatePath, data=data
    )

    frag_title = MarkdownFragment()
    frag_title.add(line="## Area minima delle piastre secondo EC2")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="MD_ENG_CAL", output_format="md")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("MD_ENG_CAL.md").exists()


def test_plate_minimum_area_html(tmp_path: Path):
    """Test plate minimum area cheat sheet generation in HTML format."""
    dataInput = PlateMinimumAreaInput()
    solver = SolverPlateMinRebar(inputModel=dataInput)

    assert solver.run()

    logsData = solver.getModelLogs()
    assert isinstance(logsData, PlateMinimumAreaLogs)

    data = PlateMinimumArea(
        inputData=dataInput,
        logsData=logsData,
    )

    markdownTemplatePath = getMarkdownTemplatesPath()

    fragBuilder = markdownCheatSheets.PlateMinimumAreaMdCS(
        markdownTemplatePath=markdownTemplatePath, data=data
    )

    frag_title = MarkdownFragment()
    frag_title.add(line="## Area minima delle piastre secondo EC2")
    frag = fragBuilder.buildFragment()

    reporter = MarkdownReporter(markdownTemplatePath)
    reporter.linkFragments(
        template=ReportTemplateEnum.MD_ENG_CAL, fragments=[frag_title, frag]
    )
    reporter.compileDocument(path=str(tmp_path), fileName="HTML_ENG_CAL", output_format="html")
    print(f"Temporary path for test is {tmp_path}")
    assert tmp_path.joinpath("HTML_ENG_CAL.md").exists()
    assert tmp_path.joinpath("HTML_ENG_CAL.html").exists()
