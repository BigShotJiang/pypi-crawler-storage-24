"""Built-in language specifications for common programming languages."""

from .ada import Ada
from .bash import Bash
from .c import C
from .clojure import Clojure
from .cobol import Cobol
from .common_lisp import CommonLisp
from .cpp import Cpp
from .crystal import Crystal
from .csharp import CSharp
from .d import D
from .dart import Dart
from .elixir import Elixir
from .erlang import Erlang
from .fortran import Fortran
from .fsharp import FSharp
from .go import Go
from .groovy import Groovy
from .haskell import Haskell
from .hcl import Hcl
from .java import Java
from .javascript import JavaScript
from .julia import Julia
from .kotlin import Kotlin
from .lua import Lua
from .matlab import Matlab
from .mojo import Mojo
from .nim import Nim
from .norg import Norg
from .objective_c import ObjectiveC
from .ocaml import OCaml
from .occam import Occam
from .perl import Perl
from .php import Php
from .powershell import PowerShell
from .python import Python
from .r import R
from .racket import Racket
from .ruby import Ruby
from .rust import Rust
from .scala import Scala
from .swift import Swift
from .toml import Toml
from .typescript import TypeScript
from .vb import VisualBasic
from .yaml import Yaml
from .zig import Zig

__all__ = [
    "Ada",
    "Bash",
    "C",
    "CSharp",
    "Clojure",
    "Cobol",
    "CommonLisp",
    "Cpp",
    "Crystal",
    "D",
    "Dart",
    "Elixir",
    "Erlang",
    "FSharp",
    "Fortran",
    "Go",
    "Groovy",
    "Haskell",
    "Hcl",
    "Java",
    "JavaScript",
    "Julia",
    "Kotlin",
    "Lua",
    "Matlab",
    "Mojo",
    "Nim",
    "Norg",
    "OCaml",
    "ObjectiveC",
    "Occam",
    "Perl",
    "Php",
    "PowerShell",
    "Python",
    "R",
    "Racket",
    "Ruby",
    "Rust",
    "Scala",
    "Swift",
    "Toml",
    "TypeScript",
    "VisualBasic",
    "Yaml",
    "Zig",
]
