from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from typing import Optional

import requests

from .config import Config, OPENROUTER_API_URL

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = (
    "You are an expert librarian. Given a messy book filename (without extension), "
    "extract the book's title, author(s), and publication year. "
    "Return ONLY a JSON object with these exact keys: "
    '{"title": "...", "authors": ["..."], "year": "YYYY or null"}. '
    "If uncertain about a field, use null. Do not include any explanation or markdown."
)


@dataclass
class LLMResult:
    title: Optional[str]
    authors: list[str]
    year: Optional[str]
    raw_response: str


def parse_filename_with_llm(stem: str, config: Config) -> Optional[LLMResult]:
    """Send the filename stem to OpenRouter and parse structured metadata."""
    payload = {
        "model": config.model,
        "messages": [
            {"role": "system", "content": _SYSTEM_PROMPT},
            {"role": "user", "content": f"Filename: {stem}"},
        ],
        "temperature": 0.1,
        "max_tokens": 200,
    }
    headers = {
        "Authorization": f"Bearer {config.openrouter_api_key}",
        "Content-Type": "application/json",
        "HTTP-Referer": "https://github.com/bookcleaner",
        "X-Title": "BookCleaner",
    }

    last_exc: Optional[Exception] = None
    for attempt in range(1, config.max_retries + 1):
        try:
            resp = requests.post(
                OPENROUTER_API_URL,
                headers=headers,
                json=payload,
                timeout=config.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            raw = data["choices"][0]["message"]["content"].strip()
            return _parse_llm_json(raw)
        except requests.exceptions.Timeout:
            logger.warning("LLM request timed out (attempt %d/%d): %s", attempt, config.max_retries, stem)
            last_exc = TimeoutError("LLM request timed out")
        except requests.exceptions.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "?"
            logger.warning("LLM HTTP %s (attempt %d/%d): %s", status, attempt, config.max_retries, stem)
            last_exc = exc
            if exc.response is not None and exc.response.status_code in {400, 401, 403}:
                break  # Non-retryable
        except requests.exceptions.RequestException as exc:
            logger.warning("LLM request error (attempt %d/%d): %s → %s", attempt, config.max_retries, stem, exc)
            last_exc = exc

        if attempt < config.max_retries:
            time.sleep(2 ** (attempt - 1))

    logger.error("LLM failed after %d attempts for '%s': %s", config.max_retries, stem, last_exc)
    return None


def _parse_llm_json(raw: str) -> Optional[LLMResult]:
    """Extract JSON from the LLM response, handling markdown fences."""
    text = raw
    if "```" in text:
        import re
        match = re.search(r"```(?:json)?\s*([\s\S]+?)```", text)
        if match:
            text = match.group(1).strip()

    try:
        obj = json.loads(text)
    except json.JSONDecodeError:
        # Last-ditch: try to find first {...} block
        import re
        match = re.search(r"\{[\s\S]+\}", text)
        if match:
            try:
                obj = json.loads(match.group(0))
            except json.JSONDecodeError:
                logger.debug("Could not parse LLM JSON: %s", raw[:200])
                return None
        else:
            logger.debug("No JSON found in LLM response: %s", raw[:200])
            return None

    title = obj.get("title") or None
    authors_raw = obj.get("authors") or []
    if isinstance(authors_raw, str):
        authors_raw = [authors_raw]
    authors = [str(a).strip() for a in authors_raw if a]
    year_raw = obj.get("year")
    year: Optional[str] = str(year_raw).strip() if year_raw and str(year_raw).strip().lower() != "null" else None

    return LLMResult(title=title, authors=authors, year=year, raw_response=raw)
