from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from .cache import FileCache
from .config import Config
from .google import GoogleBooksResult, query_google_books
from .llm import LLMResult, parse_filename_with_llm
from .utils import (
    format_filename,
    normalize_authors,
    safe_rename_path,
    token_similarity,
)

logger = logging.getLogger(__name__)


@dataclass
class BookMetadata:
    title: Optional[str]
    author: Optional[str]
    year: Optional[str]
    confidence: float
    source: str  # "google", "llm", "cache"


@dataclass
class ProcessResult:
    original_path: Path
    new_name: Optional[str]
    new_path: Optional[Path]
    metadata: Optional[BookMetadata]
    renamed: bool = False
    skipped: bool = False
    error: Optional[str] = None


def _compute_confidence(llm: LLMResult, google: GoogleBooksResult) -> float:
    """
    Compare LLM and Google Books results using token similarity on title + author.
    Returns a float in [0, 1].
    """
    scores: list[float] = []

    # Title similarity
    if llm.title and google.title:
        scores.append(token_similarity(llm.title, google.title))
    elif llm.title or google.title:
        scores.append(0.3)  # One side missing

    # Author similarity
    llm_author = normalize_authors(llm.authors) if llm.authors else None
    google_author = normalize_authors(google.authors) if google.authors else None
    if llm_author and google_author:
        scores.append(token_similarity(llm_author, google_author))
    elif llm_author or google_author:
        scores.append(0.3)

    return sum(scores) / len(scores) if scores else 0.0


def _resolve_metadata(
    llm_result: Optional[LLMResult],
    google_result: Optional[GoogleBooksResult],
    confidence_threshold: float,
) -> Optional[BookMetadata]:
    if llm_result is None and google_result is None:
        return None

    if llm_result is None:
        assert google_result is not None
        return BookMetadata(
            title=google_result.title,
            author=normalize_authors(google_result.authors),
            year=google_result.year,
            confidence=0.5,
            source="google",
        )

    if google_result is None:
        return BookMetadata(
            title=llm_result.title,
            author=normalize_authors(llm_result.authors),
            year=llm_result.year,
            confidence=0.4,
            source="llm",
        )

    confidence = _compute_confidence(llm_result, google_result)
    logger.debug("Confidence score: %.2f", confidence)

    if confidence >= confidence_threshold:
        # Use Google Books (more authoritative)
        return BookMetadata(
            title=google_result.title or llm_result.title,
            author=normalize_authors(google_result.authors) if google_result.authors else normalize_authors(llm_result.authors),
            year=google_result.year or llm_result.year,
            confidence=confidence,
            source="google",
        )
    else:
        logger.debug("Low confidence (%.2f < %.2f); falling back to LLM result.", confidence, confidence_threshold)
        return BookMetadata(
            title=llm_result.title,
            author=normalize_authors(llm_result.authors),
            year=llm_result.year,
            confidence=confidence,
            source="llm",
        )


def process_file(file_path: Path, config: Config, cache: FileCache) -> ProcessResult:
    """Full pipeline for a single file: LLM → Google → confidence → rename."""
    stem = file_path.stem
    ext = file_path.suffix

    # Cache hit
    cached = cache.get(stem)
    if cached is not None:
        new_path = safe_rename_path(file_path.parent / (cached + ext))
        logger.debug("Cache hit for '%s' → '%s'", stem, cached + ext)
        result = ProcessResult(
            original_path=file_path,
            new_name=cached + ext,
            new_path=new_path,
            metadata=BookMetadata(title=None, author=None, year=None, confidence=1.0, source="cache"),
        )
        if not config.dry_run:
            _do_rename(file_path, new_path, result)
        else:
            result.skipped = True
        return result

    # LLM parsing
    logger.debug("Sending to LLM: '%s'", stem)
    llm_result = parse_filename_with_llm(stem, config)
    if llm_result is None:
        return ProcessResult(
            original_path=file_path,
            new_name=None,
            new_path=None,
            metadata=None,
            error="LLM parsing failed",
        )

    logger.debug("LLM result: title=%s authors=%s year=%s", llm_result.title, llm_result.authors, llm_result.year)

    # Google Books verification
    first_author = llm_result.authors[0] if llm_result.authors else None
    google_result = query_google_books(llm_result.title, first_author, config)

    # Resolve metadata
    metadata = _resolve_metadata(llm_result, google_result, config.confidence_threshold)
    if metadata is None:
        return ProcessResult(
            original_path=file_path,
            new_name=None,
            new_path=None,
            metadata=None,
            error="Could not resolve metadata",
        )

    new_name_no_ext = format_filename(metadata.author, metadata.title, metadata.year, "")[:-1]  # strip trailing "."
    # Actually build proper name
    new_filename = format_filename(metadata.author, metadata.title, metadata.year, ext)
    new_path = safe_rename_path(file_path.parent / new_filename)

    # Store in cache (stem → cleaned stem without ext)
    cache.set(stem, new_path.stem)

    result = ProcessResult(
        original_path=file_path,
        new_name=new_path.name,
        new_path=new_path,
        metadata=metadata,
    )

    if not config.dry_run:
        _do_rename(file_path, new_path, result)
    else:
        result.skipped = True

    return result


def _do_rename(src: Path, dst: Path, result: ProcessResult) -> None:
    """Attempt os-level rename; update result in place."""
    try:
        if src == dst:
            logger.debug("Source and destination are identical; skipping rename.")
            result.skipped = True
            return
        src.rename(dst)
        result.renamed = True
        logger.debug("Renamed: %s → %s", src.name, dst.name)
    except OSError as exc:
        result.error = str(exc)
        logger.error("Failed to rename '%s': %s", src.name, exc)


def collect_files(folder: Path, config: Config) -> list[Path]:
    """Recursively collect supported book files from a directory."""
    files: list[Path] = []
    for p in sorted(folder.rglob("*")):
        if p.is_file() and p.suffix.lower() in config.supported_extensions:
            files.append(p)
    return files
