from __future__ import annotations

import re
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_INVALID_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')
_MULTI_SPACES = re.compile(r"\s{2,}")
_TRAILING_DOTS = re.compile(r"\.+$")


def sanitize_filename(name: str, max_length: int = 200) -> str:
    """Remove or replace characters that are invalid in filenames."""
    name = _INVALID_CHARS.sub("_", name)
    name = _MULTI_SPACES.sub(" ", name)
    name = _TRAILING_DOTS.sub("", name)
    name = name.strip(". ")
    return name[:max_length]


def format_filename(author: Optional[str], title: Optional[str], year: Optional[str], ext: str) -> str:
    """Build canonical filename: Author - Title (Year).ext"""
    parts: list[str] = []

    author_part = sanitize_filename(author.strip()) if author and author.strip() else "Unknown Author"
    title_part = sanitize_filename(title.strip()) if title and title.strip() else "Unknown Title"

    parts.append(author_part)
    parts.append(" - ")
    parts.append(title_part)

    if year and year.strip():
        parts.append(f" ({year.strip()})")

    ext = ext.lower()
    if not ext.startswith("."):
        ext = f".{ext}"

    return "".join(parts) + ext


def safe_rename_path(target: Path) -> Path:
    """If target exists, append _1, _2, etc. to avoid collision."""
    if not target.exists():
        return target

    stem = target.stem
    suffix = target.suffix
    parent = target.parent
    counter = 1

    while True:
        candidate = parent / f"{stem}_{counter}{suffix}"
        if not candidate.exists():
            logger.debug("Collision detected; using alternative: %s", candidate.name)
            return candidate
        counter += 1


def token_similarity(a: str, b: str) -> float:
    """Jaccard similarity on lowercased word tokens."""
    if not a or not b:
        return 0.0
    tokens_a = set(re.findall(r"\b\w+\b", a.lower()))
    tokens_b = set(re.findall(r"\b\w+\b", b.lower()))
    if not tokens_a and not tokens_b:
        return 1.0
    intersection = tokens_a & tokens_b
    union = tokens_a | tokens_b
    return len(intersection) / len(union)


def normalize_authors(authors: list[str]) -> str:
    """Collapse multiple authors to 'FirstAuthor et al.' format."""
    if not authors:
        return "Unknown Author"
    if len(authors) == 1:
        return authors[0].strip()
    return f"{authors[0].strip()} et al."


def extract_year(text: str) -> Optional[str]:
    """Pull first 4-digit year (1800-2099) from a string."""
    match = re.search(r"\b(1[89]\d{2}|20\d{2})\b", text)
    return match.group(1) if match else None


def setup_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s" if verbose else "[%(levelname)s] %(message)s"
    logging.basicConfig(level=level, format=fmt, datefmt="%H:%M:%S")
    # Suppress noisy third-party loggers
    for lib in ("urllib3", "requests", "charset_normalizer"):
        logging.getLogger(lib).setLevel(logging.WARNING)
