from __future__ import annotations

import argparse
import logging
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Optional

from tqdm import tqdm

from .cache import FileCache
from .config import Config
from .core import ProcessResult, collect_files, process_file
from .utils import setup_logging

logger = logging.getLogger(__name__)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="bookcleaner",
        description="Clean and standardize messy book filenames using LLM + Google Books.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  bookcleaner /path/to/books
  bookcleaner /path/to/books --dry-run
  bookcleaner /path/to/books --workers 8 --confidence-threshold 0.7
  bookcleaner /path/to/books --verbose
  bookcleaner --clear-cache
""",
    )
    parser.add_argument(
        "folder",
        nargs="?",
        type=Path,
        help="Folder containing book files to process.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        default=False,
        help="Preview rename operations without making any changes.",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=4,
        metavar="N",
        help="Number of parallel worker threads (default: 4).",
    )
    parser.add_argument(
        "--confidence-threshold",
        type=float,
        default=0.6,
        metavar="FLOAT",
        help="Minimum similarity score to trust Google Books result (default: 0.6).",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        default=False,
        help="Enable verbose debug logging.",
    )
    parser.add_argument(
        "--cache-file",
        type=Path,
        default=None,
        metavar="PATH",
        help="Path to cache file (default: ~/.bookcleaner_cache.json).",
    )
    parser.add_argument(
        "--clear-cache",
        action="store_true",
        default=False,
        help="Clear the local cache and exit.",
    )
    return parser


def _print_summary(results: list[ProcessResult], dry_run: bool) -> None:
    renamed = sum(1 for r in results if r.renamed)
    skipped_dry = sum(1 for r in results if r.skipped and not r.error)
    errors = sum(1 for r in results if r.error)
    unchanged = sum(1 for r in results if not r.renamed and not r.skipped and not r.error)

    print("\n" + "=" * 60)
    print("  BookCleaner Summary")
    print("=" * 60)
    if dry_run:
        print(f"  [DRY-RUN] Would rename : {skipped_dry}")
    else:
        print(f"  Renamed               : {renamed}")
        print(f"  Unchanged             : {unchanged}")
    print(f"  Errors                : {errors}")
    print(f"  Total processed       : {len(results)}")
    print("=" * 60 + "\n")


def _print_result(result: ProcessResult, dry_run: bool, verbose: bool) -> None:
    src = result.original_path.name
    if result.error:
        print(f"  ✗  {src}")
        print(f"     └─ ERROR: {result.error}")
        return

    dst = result.new_name or src
    prefix = "[DRY-RUN] " if dry_run else ""
    arrow = "⟶"

    if src == dst:
        if verbose:
            print(f"  ─  {src}  (already clean)")
    else:
        meta = result.metadata
        conf_str = f"  [{meta.confidence:.0%} via {meta.source}]" if meta else ""
        print(f"  {prefix}✓  {src}")
        print(f"     └─ {arrow}  {dst}{conf_str}")


def main(argv: Optional[list[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    setup_logging(args.verbose)

    config = Config(
        dry_run=args.dry_run,
        workers=args.workers,
        confidence_threshold=args.confidence_threshold,
        verbose=args.verbose,
    )

    if args.cache_file:
        config.cache_file = args.cache_file

    cache = FileCache(config.cache_file)

    # Handle --clear-cache
    if args.clear_cache:
        cache.clear()
        print("Cache cleared.")
        return 0

    if args.folder is None:
        parser.print_help()
        return 1

    folder: Path = args.folder.resolve()
    if not folder.exists():
        logger.error("Folder does not exist: %s", folder)
        return 1
    if not folder.is_dir():
        logger.error("Path is not a directory: %s", folder)
        return 1

    try:
        config.validate()
    except ValueError as exc:
        logger.error("Configuration error: %s", exc)
        return 1

    files = collect_files(folder, config)
    if not files:
        print(f"No supported book files found in: {folder}")
        print(f"Supported extensions: {', '.join(sorted(config.supported_extensions))}")
        return 0

    print(f"\nBookCleaner {'[DRY-RUN] ' if config.dry_run else ''}─ {len(files)} file(s) found in {folder}\n")

    results: list[ProcessResult] = []

    with ThreadPoolExecutor(max_workers=config.workers) as executor:
        future_map = {
            executor.submit(process_file, f, config, cache): f
            for f in files
        }
        progress = tqdm(
            as_completed(future_map),
            total=len(files),
            desc="Processing",
            unit="file",
            disable=args.verbose,
        )
        for future in progress:
            file_path = future_map[future]
            try:
                result = future.result()
            except Exception as exc:  # noqa: BLE001
                logger.debug("Unhandled exception for %s: %s", file_path, exc, exc_info=True)
                result = ProcessResult(
                    original_path=file_path,
                    new_name=None,
                    new_path=None,
                    metadata=None,
                    error=str(exc),
                )
            results.append(result)

    # Print per-file output
    for result in sorted(results, key=lambda r: r.original_path.name):
        _print_result(result, config.dry_run, args.verbose)

    _print_summary(results, config.dry_run)
    return 0


if __name__ == "__main__":
    sys.exit(main())
