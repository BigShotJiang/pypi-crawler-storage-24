"""BookCleaner — clean and standardize messy book filenames."""

__version__ = "0.1.0"
__author__ = "BookCleaner"
