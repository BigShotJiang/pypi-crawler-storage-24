from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

SUPPORTED_EXTENSIONS: frozenset[str] = frozenset({".pdf", ".epub", ".mobi", ".azw", ".azw3"})

OPENROUTER_API_URL = "https://openrouter.ai/api/v1/chat/completions"
GOOGLE_BOOKS_API_URL = "https://www.googleapis.com/books/v1/volumes"

DEFAULT_MODEL = "openai/gpt-4o-mini"
DEFAULT_WORKERS = 4
DEFAULT_CONFIDENCE_THRESHOLD = 0.6
DEFAULT_TIMEOUT = 15
DEFAULT_MAX_RETRIES = 3
DEFAULT_CACHE_FILE = Path.home() / ".bookcleaner_cache.json"


@dataclass
class Config:
    openrouter_api_key: str = field(default_factory=lambda: os.getenv("OPENROUTER_API_KEY", ""))
    model: str = DEFAULT_MODEL
    workers: int = DEFAULT_WORKERS
    confidence_threshold: float = DEFAULT_CONFIDENCE_THRESHOLD
    timeout: int = DEFAULT_TIMEOUT
    max_retries: int = DEFAULT_MAX_RETRIES
    cache_file: Path = field(default_factory=lambda: DEFAULT_CACHE_FILE)
    dry_run: bool = False
    verbose: bool = False
    supported_extensions: frozenset[str] = field(default_factory=lambda: SUPPORTED_EXTENSIONS)

    def validate(self) -> None:
        if not self.openrouter_api_key:
            raise ValueError(
                "OPENROUTER_API_KEY is not set. "
                "Add it to your .env file or export it as an environment variable."
            )
        if not (0.0 <= self.confidence_threshold <= 1.0):
            raise ValueError("confidence_threshold must be between 0.0 and 1.0")
        if self.workers < 1:
            raise ValueError("workers must be >= 1")
