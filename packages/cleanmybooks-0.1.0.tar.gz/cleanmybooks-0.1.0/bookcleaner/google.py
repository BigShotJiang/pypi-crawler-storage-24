from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import Optional

import requests

from .config import Config, GOOGLE_BOOKS_API_URL
from .utils import extract_year

logger = logging.getLogger(__name__)


@dataclass
class GoogleBooksResult:
    title: Optional[str]
    authors: list[str]
    year: Optional[str]
    publisher: Optional[str]


def query_google_books(title: Optional[str], author: Optional[str], config: Config) -> Optional[GoogleBooksResult]:
    """Search Google Books and return the best matching result."""
    if not title and not author:
        return None

    query_parts: list[str] = []
    if title:
        query_parts.append(f"intitle:{title}")
    if author:
        query_parts.append(f"inauthor:{author}")

    params = {
        "q": " ".join(query_parts),
        "maxResults": 1,
        "orderBy": "relevance",
        "printType": "books",
    }

    last_exc: Optional[Exception] = None
    for attempt in range(1, config.max_retries + 1):
        try:
            resp = requests.get(
                GOOGLE_BOOKS_API_URL,
                params=params,
                timeout=config.timeout,
            )
            resp.raise_for_status()
            data = resp.json()
            items = data.get("items")
            if not items:
                logger.debug("Google Books returned no results for query: %s", params["q"])
                return None
            return _extract_volume_info(items[0])
        except requests.exceptions.Timeout:
            logger.warning("Google Books timed out (attempt %d/%d)", attempt, config.max_retries)
            last_exc = TimeoutError("Google Books timeout")
        except requests.exceptions.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else "?"
            logger.warning("Google Books HTTP %s (attempt %d/%d)", status, attempt, config.max_retries)
            last_exc = exc
            if exc.response is not None and exc.response.status_code in {400, 401, 403}:
                break
        except requests.exceptions.RequestException as exc:
            logger.warning("Google Books request error (attempt %d/%d): %s", attempt, config.max_retries, exc)
            last_exc = exc

        if attempt < config.max_retries:
            time.sleep(2 ** (attempt - 1))

    logger.error("Google Books failed after %d attempts: %s", config.max_retries, last_exc)
    return None


def _extract_volume_info(item: dict) -> GoogleBooksResult:
    info = item.get("volumeInfo", {})
    title = info.get("title") or None
    authors = info.get("authors") or []
    publisher = info.get("publisher") or None

    published_date = info.get("publishedDate", "")
    year = extract_year(published_date) if published_date else None

    return GoogleBooksResult(
        title=title,
        authors=[a.strip() for a in authors if a],
        year=year,
        publisher=publisher,
    )
