"""Inter-process communication modules."""
