"""GUI components for PyProbe."""
