from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_7 import PostPublicEnvelopeAddBlocksBodyBlocksItemType7
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_1 import PostPublicEnvelopeAddBlocksBodyBlocksItemType1
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_4 import PostPublicEnvelopeAddBlocksBodyBlocksItemType4
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_5 import PostPublicEnvelopeAddBlocksBodyBlocksItemType5
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_2 import PostPublicEnvelopeAddBlocksBodyBlocksItemType2
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_0 import PostPublicEnvelopeAddBlocksBodyBlocksItemType0
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_8 import PostPublicEnvelopeAddBlocksBodyBlocksItemType8
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_6 import PostPublicEnvelopeAddBlocksBodyBlocksItemType6
  from ..models.post_public_envelope_add_blocks_body_blocks_item_type_3 import PostPublicEnvelopeAddBlocksBodyBlocksItemType3





T = TypeVar("T", bound="PostPublicEnvelopeAddBlocksBody")



@_attrs_define
class PostPublicEnvelopeAddBlocksBody:
    """ 
        Attributes:
            envelope_uuid (str): The UUID of the envelope.
            document_uuid (str): The UUID of the document.
            blocks (list[PostPublicEnvelopeAddBlocksBodyBlocksItemType0 | PostPublicEnvelopeAddBlocksBodyBlocksItemType1 |
                PostPublicEnvelopeAddBlocksBodyBlocksItemType2 | PostPublicEnvelopeAddBlocksBodyBlocksItemType3 |
                PostPublicEnvelopeAddBlocksBodyBlocksItemType4 | PostPublicEnvelopeAddBlocksBodyBlocksItemType5 |
                PostPublicEnvelopeAddBlocksBodyBlocksItemType6 | PostPublicEnvelopeAddBlocksBodyBlocksItemType7 |
                PostPublicEnvelopeAddBlocksBodyBlocksItemType8]): Array of blocks to add to the document.
            workspace_uuid (str | Unset): Optional. When omitted, the team's default workspace is used.
     """

    envelope_uuid: str
    document_uuid: str
    blocks: list[PostPublicEnvelopeAddBlocksBodyBlocksItemType0 | PostPublicEnvelopeAddBlocksBodyBlocksItemType1 | PostPublicEnvelopeAddBlocksBodyBlocksItemType2 | PostPublicEnvelopeAddBlocksBodyBlocksItemType3 | PostPublicEnvelopeAddBlocksBodyBlocksItemType4 | PostPublicEnvelopeAddBlocksBodyBlocksItemType5 | PostPublicEnvelopeAddBlocksBodyBlocksItemType6 | PostPublicEnvelopeAddBlocksBodyBlocksItemType7 | PostPublicEnvelopeAddBlocksBodyBlocksItemType8]
    workspace_uuid: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_7 import PostPublicEnvelopeAddBlocksBodyBlocksItemType7
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_1 import PostPublicEnvelopeAddBlocksBodyBlocksItemType1
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_4 import PostPublicEnvelopeAddBlocksBodyBlocksItemType4
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_5 import PostPublicEnvelopeAddBlocksBodyBlocksItemType5
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_2 import PostPublicEnvelopeAddBlocksBodyBlocksItemType2
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_0 import PostPublicEnvelopeAddBlocksBodyBlocksItemType0
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_8 import PostPublicEnvelopeAddBlocksBodyBlocksItemType8
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_6 import PostPublicEnvelopeAddBlocksBodyBlocksItemType6
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_3 import PostPublicEnvelopeAddBlocksBodyBlocksItemType3
        envelope_uuid = self.envelope_uuid

        document_uuid = self.document_uuid

        blocks = []
        for blocks_item_data in self.blocks:
            blocks_item: dict[str, Any]
            if isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType0):
                blocks_item = blocks_item_data.to_dict()
            elif isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType1):
                blocks_item = blocks_item_data.to_dict()
            elif isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType2):
                blocks_item = blocks_item_data.to_dict()
            elif isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType3):
                blocks_item = blocks_item_data.to_dict()
            elif isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType4):
                blocks_item = blocks_item_data.to_dict()
            elif isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType5):
                blocks_item = blocks_item_data.to_dict()
            elif isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType6):
                blocks_item = blocks_item_data.to_dict()
            elif isinstance(blocks_item_data, PostPublicEnvelopeAddBlocksBodyBlocksItemType7):
                blocks_item = blocks_item_data.to_dict()
            else:
                blocks_item = blocks_item_data.to_dict()

            blocks.append(blocks_item)



        workspace_uuid = self.workspace_uuid


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "envelopeUuid": envelope_uuid,
            "documentUuid": document_uuid,
            "blocks": blocks,
        })
        if workspace_uuid is not UNSET:
            field_dict["workspaceUuid"] = workspace_uuid

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_7 import PostPublicEnvelopeAddBlocksBodyBlocksItemType7
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_1 import PostPublicEnvelopeAddBlocksBodyBlocksItemType1
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_4 import PostPublicEnvelopeAddBlocksBodyBlocksItemType4
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_5 import PostPublicEnvelopeAddBlocksBodyBlocksItemType5
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_2 import PostPublicEnvelopeAddBlocksBodyBlocksItemType2
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_0 import PostPublicEnvelopeAddBlocksBodyBlocksItemType0
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_8 import PostPublicEnvelopeAddBlocksBodyBlocksItemType8
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_6 import PostPublicEnvelopeAddBlocksBodyBlocksItemType6
        from ..models.post_public_envelope_add_blocks_body_blocks_item_type_3 import PostPublicEnvelopeAddBlocksBodyBlocksItemType3
        d = dict(src_dict)
        envelope_uuid = d.pop("envelopeUuid")

        document_uuid = d.pop("documentUuid")

        blocks = []
        _blocks = d.pop("blocks")
        for blocks_item_data in (_blocks):
            def _parse_blocks_item(data: object) -> PostPublicEnvelopeAddBlocksBodyBlocksItemType0 | PostPublicEnvelopeAddBlocksBodyBlocksItemType1 | PostPublicEnvelopeAddBlocksBodyBlocksItemType2 | PostPublicEnvelopeAddBlocksBodyBlocksItemType3 | PostPublicEnvelopeAddBlocksBodyBlocksItemType4 | PostPublicEnvelopeAddBlocksBodyBlocksItemType5 | PostPublicEnvelopeAddBlocksBodyBlocksItemType6 | PostPublicEnvelopeAddBlocksBodyBlocksItemType7 | PostPublicEnvelopeAddBlocksBodyBlocksItemType8:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_0 = PostPublicEnvelopeAddBlocksBodyBlocksItemType0.from_dict(data)



                    return blocks_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_1 = PostPublicEnvelopeAddBlocksBodyBlocksItemType1.from_dict(data)



                    return blocks_item_type_1
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_2 = PostPublicEnvelopeAddBlocksBodyBlocksItemType2.from_dict(data)



                    return blocks_item_type_2
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_3 = PostPublicEnvelopeAddBlocksBodyBlocksItemType3.from_dict(data)



                    return blocks_item_type_3
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_4 = PostPublicEnvelopeAddBlocksBodyBlocksItemType4.from_dict(data)



                    return blocks_item_type_4
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_5 = PostPublicEnvelopeAddBlocksBodyBlocksItemType5.from_dict(data)



                    return blocks_item_type_5
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_6 = PostPublicEnvelopeAddBlocksBodyBlocksItemType6.from_dict(data)



                    return blocks_item_type_6
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    blocks_item_type_7 = PostPublicEnvelopeAddBlocksBodyBlocksItemType7.from_dict(data)



                    return blocks_item_type_7
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                blocks_item_type_8 = PostPublicEnvelopeAddBlocksBodyBlocksItemType8.from_dict(data)



                return blocks_item_type_8

            blocks_item = _parse_blocks_item(blocks_item_data)

            blocks.append(blocks_item)


        workspace_uuid = d.pop("workspaceUuid", UNSET)

        post_public_envelope_add_blocks_body = cls(
            envelope_uuid=envelope_uuid,
            document_uuid=document_uuid,
            blocks=blocks,
            workspace_uuid=workspace_uuid,
        )


        post_public_envelope_add_blocks_body.additional_properties = d
        return post_public_envelope_add_blocks_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
