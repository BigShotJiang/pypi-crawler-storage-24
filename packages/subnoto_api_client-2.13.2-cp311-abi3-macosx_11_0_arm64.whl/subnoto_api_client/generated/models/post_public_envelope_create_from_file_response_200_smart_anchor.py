from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_skipped_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem
  from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_blocks_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem
  from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_recipients_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem





T = TypeVar("T", bound="PostPublicEnvelopeCreateFromFileResponse200SmartAnchor")



@_attrs_define
class PostPublicEnvelopeCreateFromFileResponse200SmartAnchor:
    """ When detectSmartAnchors was enabled, contains blocks and recipients added from Smart Anchors and any skipped anchors
    with reasons.

        Attributes:
            blocks (list[PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem]):
            recipients (list[PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem]):
            skipped (list[PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem]):
     """

    blocks: list[PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem]
    recipients: list[PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem]
    skipped: list[PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem]





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_skipped_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_blocks_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_recipients_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem
        blocks = []
        for blocks_item_data in self.blocks:
            blocks_item = blocks_item_data.to_dict()
            blocks.append(blocks_item)



        recipients = []
        for recipients_item_data in self.recipients:
            recipients_item = recipients_item_data.to_dict()
            recipients.append(recipients_item)



        skipped = []
        for skipped_item_data in self.skipped:
            skipped_item = skipped_item_data.to_dict()
            skipped.append(skipped_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "blocks": blocks,
            "recipients": recipients,
            "skipped": skipped,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_skipped_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_blocks_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem
        from ..models.post_public_envelope_create_from_file_response_200_smart_anchor_recipients_item import PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem
        d = dict(src_dict)
        blocks = []
        _blocks = d.pop("blocks")
        for blocks_item_data in (_blocks):
            blocks_item = PostPublicEnvelopeCreateFromFileResponse200SmartAnchorBlocksItem.from_dict(blocks_item_data)



            blocks.append(blocks_item)


        recipients = []
        _recipients = d.pop("recipients")
        for recipients_item_data in (_recipients):
            recipients_item = PostPublicEnvelopeCreateFromFileResponse200SmartAnchorRecipientsItem.from_dict(recipients_item_data)



            recipients.append(recipients_item)


        skipped = []
        _skipped = d.pop("skipped")
        for skipped_item_data in (_skipped):
            skipped_item = PostPublicEnvelopeCreateFromFileResponse200SmartAnchorSkippedItem.from_dict(skipped_item_data)



            skipped.append(skipped_item)


        post_public_envelope_create_from_file_response_200_smart_anchor = cls(
            blocks=blocks,
            recipients=recipients,
            skipped=skipped,
        )

        return post_public_envelope_create_from_file_response_200_smart_anchor

