"""
The one and only place for the version number.
"""

VERSION = (0, 22, 2)

__version__ = ".".join(map(str, VERSION))
