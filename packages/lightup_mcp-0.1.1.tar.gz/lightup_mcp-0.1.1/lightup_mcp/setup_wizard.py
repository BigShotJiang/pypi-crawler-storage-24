"""
Lightup MCP Setup Wizard

Interactive setup: collects Lightup host/token + AI provider config,
tests connections, saves config, and auto-configures Claude Desktop.
"""

import json
import signal
import socket
import subprocess
from pathlib import Path

import httpx
import psutil
from lightup_mcp.config import AI_PROVIDERS, Config, save_config

CLAUDE_DESKTOP_CONFIG = (
    Path.home()
    / "Library"
    / "Application Support"
    / "Claude"
    / "claude_desktop_config.json"
)


def prompt(label: str, default: str = "", secret: bool = False) -> str:
    """Prompt user for input with optional default."""
    display = f"{label}"
    if default:
        display += f" [{default}]"
    display += ": "

    if secret:
        import getpass

        value = getpass.getpass(display)
    else:
        value = input(display).strip()

    return value or default


def pick_provider() -> tuple[str, str]:
    """Interactive AI provider selection. Returns (provider_key, model)."""
    print("\nChoose AI provider:")
    keys = list(AI_PROVIDERS.keys())
    for i, key in enumerate(keys, 1):
        info = AI_PROVIDERS[key]
        suffix = " (no API key needed)" if key == "ollama" else ""
        print(f"  {i}. {info['name']}{suffix}")

    while True:
        choice = input(f"\nSelect [1-{len(keys)}]: ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(keys):
            provider_key = keys[int(choice) - 1]
            model = AI_PROVIDERS[provider_key]["default_model"]
            return provider_key, model
        print(f"  Invalid choice, enter 1-{len(keys)}")


def test_lightup_connection(host: str, token: str) -> bool:
    """Ping Lightup backend to verify host + token."""
    try:
        resp = httpx.get(
            f"{host.rstrip('/')}/api/v0/workspaces/",
            headers={"Authorization": f"Token {token}"},
            timeout=10,
        )
        return resp.status_code in (200, 401, 403)  # reachable even if auth fails
    except Exception:
        return False


def test_ai_key(provider: str, api_key: str) -> bool:
    """Validate AI API key format."""
    if provider == "ollama":
        return True  # no key needed
    if not api_key:
        return False
    if provider == "claude":
        return api_key.startswith("sk-ant-")
    if provider == "openai":
        return api_key.startswith("sk-") or api_key.startswith("sk-proj-")
    if provider == "gemini":
        return api_key.startswith("AIza")
    return True


def configure_claude_desktop(config: Config) -> bool:
    """Auto-write lightup-mcp entry into Claude Desktop config."""
    if not CLAUDE_DESKTOP_CONFIG.exists():
        return False

    try:
        with open(CLAUDE_DESKTOP_CONFIG) as f:
            desktop_config = json.load(f)
    except Exception:
        desktop_config = {}

    desktop_config.setdefault("mcpServers", {})
    desktop_config["mcpServers"]["lightup-mcp"] = {
        "command": "lightup-mcp",
        "args": ["serve", "--stdio"],
    }

    with open(CLAUDE_DESKTOP_CONFIG, "w") as f:
        json.dump(desktop_config, f, indent=2)

    return True


def _port_in_use(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(("localhost", port)) == 0


def _kill_port(port: int) -> bool:
    """Kill any process listening on the given port. Returns True if killed."""
    for proc in psutil.process_iter(["pid"]):
        try:
            for conn in proc.net_connections():
                if conn.laddr.port == port and conn.status == "LISTEN":
                    proc.send_signal(signal.SIGTERM)
                    proc.wait(timeout=3)
                    return True
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            pass
    return False


def _configure_claude_code_mcp(port: int = 8000) -> None:
    """Auto-add lightup-mcp to Claude Code by writing ~/.claude.json directly."""
    claude_json = Path.home() / ".claude.json"
    if not claude_json.exists():
        print("  ℹ️  Claude Code: not installed")
        return

    try:
        with open(claude_json) as f:
            data = json.load(f)
    except Exception:
        data = {}

    data.setdefault("mcpServers", {})
    if "lightup-mcp" in data["mcpServers"]:
        print("  ✅ Claude Code: lightup-mcp already connected")
        return

    data["mcpServers"]["lightup-mcp"] = {
        "type": "sse",
        "url": f"http://localhost:{port}/sse",
    }

    try:
        with open(claude_json, "w") as f:
            json.dump(data, f, indent=2)
        print("  ✅ Claude Code: lightup-mcp connected")
        print("     → Restart Claude Code to apply changes")
    except Exception as e:
        print(f"  ⚠️  Claude Code: auto-config failed ({e})")
        print(
            f"       claude mcp add --transport sse lightup-mcp http://localhost:{port}/sse"
        )


def start_server(port: int = 8000) -> None:
    """Kill any existing server on the port and start a fresh one in background."""
    if _port_in_use(port):
        print(f"  Stopping existing server on port {port}...", end=" ", flush=True)
        if _kill_port(port):
            print("done")
        else:
            print("failed — server may still be running")
            return

    print(f"  Starting MCP server on port {port}...", end=" ", flush=True)
    import sys

    subprocess.Popen(
        [sys.executable, "-m", "lightup_mcp.server"],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    # Wait briefly and confirm it started
    import time

    time.sleep(2)
    if _port_in_use(port):
        print(f"✅  http://localhost:{port}/sse")
    else:
        print("⚠️  server did not start — run manually: lightup-mcp serve")


def run_doctor(config: Config) -> None:
    """Verify all components are working. Runs automatically after setup."""
    print("\n" + "─" * 60)
    print("Verification checks:")

    # Lightup host reachable
    try:
        httpx.get(f"{config.host.rstrip('/')}/api/v0/workspaces/", timeout=5)
        print(f"  ✅ Lightup host reachable: {config.host}")
    except Exception:
        print(f"  ❌ Cannot reach Lightup host: {config.host}")

    # MCP server running
    if _port_in_use(8000):
        print("  ✅ MCP server running: http://localhost:8000")
    else:
        print("  ❌ MCP server not running")

    # Claude Code MCP
    claude_json = Path.home() / ".claude.json"
    if claude_json.exists():
        try:
            with open(claude_json) as f:
                claude_config = json.load(f)
            servers = claude_config.get("mcpServers", {})
            if "lightup-mcp" in servers:
                print("  ✅ Claude Code: lightup-mcp connected")
            else:
                _configure_claude_code_mcp()
        except Exception:
            print("  ℹ️  Claude Code: config unreadable")
    else:
        print("  ℹ️  Claude Code: not installed")

    # Claude Desktop (optional)
    if CLAUDE_DESKTOP_CONFIG.exists():
        with open(CLAUDE_DESKTOP_CONFIG) as f:
            desktop = json.load(f)
        if "lightup-mcp" in desktop.get("mcpServers", {}):
            print("  ✅ Claude Desktop: configured")
        else:
            print("  ℹ️  Claude Desktop: not configured (optional)")

    print(f"  ✅ AI provider: {config.ai_provider} / {config.ai_model}")


def run_setup() -> Config:
    """Run the interactive setup wizard followed by verification checks."""
    from lightup_mcp.config import CONFIG_FILE

    # Clear stale config before starting
    if CONFIG_FILE.exists():
        CONFIG_FILE.unlink()

    print("\nWelcome to Lightup MCP Setup!\n")
    print("This will configure the Lightup MCP plugin on your machine.")
    print("─" * 60)

    # Lightup connection
    print("\nLightup connection:")
    host = prompt("  Lightup host (e.g. https://app.stage.lightup.ai)")
    token = prompt("  Lightup auth token", secret=True)

    while True:
        print("\n  Testing Lightup connection...", end=" ", flush=True)
        if test_lightup_connection(host, token):
            print("✅")
            break
        print("❌ Could not reach host.")
        host = prompt("  Lightup host", default=host)
        token = prompt("  Lightup auth token", secret=True)

    # AI provider
    print("\nAI provider:")
    provider, model = pick_provider()

    api_key = ""
    if provider != "ollama":
        key_hint = AI_PROVIDERS[provider]["key_hint"]
        while True:
            api_key = prompt(f"  API key ({key_hint})", secret=True)
            if not api_key:
                print("  ❌ API key is required. Please enter a valid key.")
                continue
            print("\n  Testing AI key...", end=" ", flush=True)
            if test_ai_key(provider, api_key):
                print("✅")
                break
            print("❌ Invalid key — please try again.")

    # Save config
    config = Config(
        {
            "host": host,
            "token": token,
            "ai_provider": provider,
            "ai_model": model,
            "ai_api_key": api_key,
        }
    )
    save_config(config)
    print("\n✅ Config saved to ~/.lightup-mcp/config.json")

    # Claude Desktop auto-config
    if configure_claude_desktop(config):
        print("✅ Claude Desktop configured automatically")
        print("   → Restart Claude Desktop to apply changes")
    else:
        print("ℹ️  Claude Desktop not found — skipping auto-config")

    # Claude Code auto-config
    _configure_claude_code_mcp()

    # Start MCP server in background
    print("\nStarting MCP server:")
    start_server()

    # Verify everything
    run_doctor(config)

    print("\n" + "─" * 60)
    print("Setup complete! Starting interactive chat...\n")
    print("  Type your question and press Enter.")
    print("  Type 'exit' or press Ctrl+C to quit.")
    print("─" * 60 + "\n")

    run_chat(config)

    return config


def _thinking_spinner(fn, *args, label: str = "AI") -> str:
    """Run fn(*args) in a thread while showing an animated thinking spinner."""
    import itertools
    import threading

    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    itertools.cycle(["Thinking", "Thinking.", "Thinking..", "Thinking..."])
    result = [None]
    error = [None]
    done = threading.Event()

    def worker():
        try:
            result[0] = fn(*args)
        except Exception as e:
            error[0] = e
        finally:
            done.set()

    thread = threading.Thread(target=worker)
    thread.start()

    spinner = itertools.cycle(frames)
    thinking = itertools.cycle(["Thinking", "Thinking.", "Thinking..", "Thinking..."])
    while not done.wait(0.1):
        print(f"\r  {next(spinner)} {next(thinking)}   ", end="", flush=True)

    print("\r" + " " * 30 + "\r", end="", flush=True)  # clear spinner line

    if error[0]:
        raise error[0]
    return result[0]


def run_chat(config: Config) -> None:
    """Interactive chat loop — runs after setup or via `lightup-mcp chat`."""
    from lightup_mcp.ai.factory import get_ai_provider

    mcp_url = "http://localhost:8000/sse"
    provider = get_ai_provider(config, mcp_url)
    messages = []

    while True:
        try:
            question = input("You: ").strip()
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit", "bye"):
            print("Goodbye!")
            break

        messages.append({"role": "user", "content": question})

        try:
            answer = _thinking_spinner(
                provider.chat, list(messages), config.ai_provider
            )
            print(f"\n{config.ai_provider.capitalize()}: {answer}")
            messages.append({"role": "assistant", "content": answer})
        except Exception as e:
            inner = e
            while hasattr(inner, "exceptions") and inner.exceptions:
                inner = inner.exceptions[0]
            print(f"❌ {inner}")

        print()
