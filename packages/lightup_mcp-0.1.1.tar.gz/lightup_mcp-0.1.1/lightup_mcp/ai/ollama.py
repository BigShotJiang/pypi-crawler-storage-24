"""
Ollama (local) AI provider — placeholder.
Wired up when Ollama support is added in v2.
"""

from lightup_mcp.ai.base import AIProvider


class OllamaProvider(AIProvider):
    def __init__(self, model: str, mcp_server_url: str):
        self._model = model
        self._mcp_server_url = mcp_server_url

    def chat(self, messages: list[dict], tools: list[dict] | None = None) -> str:
        raise NotImplementedError("Ollama provider coming in v2")
