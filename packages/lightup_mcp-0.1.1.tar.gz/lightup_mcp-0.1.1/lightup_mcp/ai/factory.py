"""
AI provider factory — returns the right provider from config.
"""

from lightup_mcp.ai.base import AIProvider
from lightup_mcp.ai.claude import ClaudeProvider
from lightup_mcp.ai.gemini import GeminiProvider
from lightup_mcp.ai.ollama import OllamaProvider
from lightup_mcp.ai.openai import OpenAIProvider
from lightup_mcp.config import Config


def get_ai_provider(config: Config, mcp_server_url: str) -> AIProvider:
    match config.ai_provider:
        case "claude":
            return ClaudeProvider(config.ai_api_key, config.ai_model, mcp_server_url)
        case "openai":
            return OpenAIProvider(config.ai_api_key, config.ai_model, mcp_server_url)
        case "gemini":
            return GeminiProvider(config.ai_api_key, config.ai_model, mcp_server_url)
        case "ollama":
            return OllamaProvider(config.ai_model, mcp_server_url)
        case _:
            raise ValueError(f"Unknown AI provider: {config.ai_provider}")
