"""
AI Provider base interface.

All providers implement chat() with the same signature so the
rest of the codebase is provider-agnostic.
"""

from abc import ABC, abstractmethod


class AIProvider(ABC):
    @abstractmethod
    def chat(self, messages: list[dict], tools: list[dict]) -> str:
        """
        Send messages to the AI and return the final text response.
        Handles the full agentic loop — tool calls are executed internally.
        """
        ...
