"""
Gemini (Google) AI provider.

Manual agentic loop — fetch tools from local MCP server via SSE,
pass to Gemini as function declarations, execute tool calls, return final answer.
"""

import asyncio

from google import genai
from google.genai import types
from lightup_mcp.ai.base import AIProvider
from mcp import ClientSession
from mcp.client.sse import sse_client


class GeminiProvider(AIProvider):
    def __init__(self, api_key: str, model: str, mcp_server_url: str):
        self._client = genai.Client(api_key=api_key)
        self._model_name = model
        self._mcp_server_url = mcp_server_url

    def chat(self, messages: list[dict], tools: list[dict] | None = None) -> str:
        return asyncio.run(self._chat_async(messages))

    async def _chat_async(self, messages: list[dict]) -> str:
        async with sse_client(self._mcp_server_url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()

                # Fetch tools from MCP server and convert to Gemini function declarations
                tools_result = await session.list_tools()
                gemini_tools = [
                    types.Tool(
                        function_declarations=[
                            types.FunctionDeclaration(
                                name=t.name,
                                description=t.description or "",
                                parameters=_mcp_schema_to_gemini(t.inputSchema),
                            )
                        ]
                    )
                    for t in tools_result.tools
                ]

                # Build conversation history
                gemini_contents = _to_gemini_contents(messages)

                system = (
                    "You are a helpful Lightup data quality assistant. "
                    "Respond in plain text only — no markdown, no headers, no bullet symbols, "
                    "no bold/italic formatting. Use plain sentences and simple line breaks."
                )

                # Agentic loop
                while True:
                    response = await asyncio.to_thread(
                        self._client.models.generate_content,
                        model=self._model_name,
                        contents=gemini_contents,
                        config=types.GenerateContentConfig(
                            tools=gemini_tools,
                            system_instruction=system,
                        ),
                    )

                    # Check for function calls
                    tool_calls = [
                        part.function_call
                        for part in response.candidates[0].content.parts
                        if part.function_call
                    ]

                    if not tool_calls:
                        return response.text

                    # Add model response to history
                    gemini_contents.append(response.candidates[0].content)

                    # Execute tool calls and collect results
                    tool_response_parts = []
                    for fc in tool_calls:
                        result = await session.call_tool(fc.name, dict(fc.args))
                        tool_response_parts.append(
                            types.Part(
                                function_response=types.FunctionResponse(
                                    name=fc.name,
                                    response={
                                        "result": result.content[0].text
                                        if result.content
                                        else ""
                                    },
                                )
                            )
                        )

                    # Feed results back to Gemini
                    gemini_contents.append(
                        types.Content(role="user", parts=tool_response_parts)
                    )


def _mcp_schema_to_gemini(schema: dict) -> types.Schema:
    """Convert MCP JSON schema to Gemini Schema."""
    props = {}
    for name, prop in schema.get("properties", {}).items():
        props[name] = types.Schema(
            type=types.Type.STRING,
            description=prop.get("description", ""),
        )
    return types.Schema(
        type=types.Type.OBJECT,
        properties=props,
        required=schema.get("required", []),
    )


def _to_gemini_contents(messages: list[dict]) -> list:
    """Convert OpenAI-style messages to Gemini contents format."""
    contents = []
    for msg in messages:
        role = "user" if msg["role"] == "user" else "model"
        contents.append(
            types.Content(role=role, parts=[types.Part(text=msg["content"])])
        )
    return contents
