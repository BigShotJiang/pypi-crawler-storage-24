---
title: "Quick Start"
slug: "quick-start"
excerpt: "If you're new to Lightup this Quick Start will help you jump right in."
hidden: false
metadata:
  title: "Quick Start"
  description: "The document provides a quick start guide for new users of the Lightup app, detailing its user interface, roles, and steps to set up data quality monitoring, including creating workspaces, connecting to data sources, adding schemas, enabling data profiling, creating metrics, and adding monitors."
  url: "https://docs.lightup.ai/docs/quick-start"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Start%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=The%20document%20provides%20a%20quick%20start%20guide%20for%20new%20users%20of%20the%20Lightup%20app%2C%20detailing%20its%20user%20interface%2C%20roles%2C%20and%20steps%20to%20set%20up%20data%20quality%20monitoring%2C%20including%20creating%20workspaces%2C%20connecting%20to%20data%20sources%2C%20adding%20schemas%2C%20enabling%20data%20profiling%2C%20creating%20metrics%2C%20and%20adding%20monitors.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Quick Start

If you're new to Lightup this Quick Start will help you jump right in.

# Get oriented in the UI

The Lightup app has three main areas:

![](https://files.readme.io/8d81403e7803aed7a2b5bdf1a8b3b0895da5a70f874f1a0ebfedfcfbea5fd521-Screenshot_2024-10-03_at_3.16.36_PM.webp)

1. The [top bar](https://docs.lightup.ai/docs/quick-start#the-top-bar-navigation) has a workspace switcher on the right to switch between workspaces. Workspace and Admin settings can be accessed by clicking on the configuration icon next to the user name. Other user actions are possible via clicking on the user icon (such as contact support, generate API credentials, and logout)
2. The [left pane](https://docs.lightup.ai/docs/quick-start#the-left-pane-app-settings-and-workspaces) lists the menu of data quality related actions you will be interested in accessing for the workspace selected.
3. The main page changes to reflect your choices on the left pane and the top bar. This is where you work with data quality components inside a specific workspace.

## The top pane: Workspace switcher, Admin and workspace settings

Your [app role](doc:roles#app-roles) establishes what you can do outside of workspaces. Workspaces also have [roles](https://docs.lightup.ai/docs/roles#workspace-roles) that determine what you can do inside of them. Look under the username icon to see which app role you have:

* ​If you're an App Admin, you'll notice an **Admin** menu right under the app logo. As an App Admin you can create and manage Lightup user accounts, roles, and workspaces.

  ![](https://files.readme.io/7076bc679b806e86c5c99ae3251f6181f3901ce3e1b66c88fc65263a39d333a9-Screenshot_2024-10-03_at_4.01.33_PM.webp)
  ![](https://files.readme.io/a183ce0202409b300e6ab4040b7ce6551e54dfe5ec14e632288ef317329a8e11-Screenshot_2024-10-03_at_3.54.09_PM.webp)
* ![](https://files.readme.io/6953fd9c0bea036e1fd5fd2e8c50ba833da500db4bd994cacae35324d35a0e65-Screenshot_2024-10-03_at_3.56.20_PM.webp)
* ​If you're an App Editor, you won't find an **Admin** setting, but you will notice the **Add New Workspace** in the workspace drop down. As an App Editor, you can create and manage workspaces, and can invite other Lightup app users to your workspaces. /im
* If you don't have an **Admin** menu or an **Add New Workspace** button, you're an App Viewer. You can be invited to join a workspace. In the left pane, you'll see a list of workspaces where you're a member. Select the arrow at the right edge of a listed workspace to open a menu of commands for that workspace.

## The left pane: navigation

The top bar offers a set of tabs you can select to focus on a specific quality monitoring process in a workspace.

* Select **Explorer** to manage data quality while viewing your data asset structure in your [Explorer tree](doc:managing-your-explorer-tree), which shows all of the workspace's datasources.
* Select **Metrics** to [focus on metrics](doc:create-and-edit-metrics) (the aggregated, periodic queries that measure data quality).
* Select **Monitors** to [focus on monitors](https://docs.lightup.ai/docs/monitor-a-metric) (the regular checking of metric values).
* Select **Incidents** to [review recent data quality incidents](doc:manage-incidents).
* Select **Dashboards** to open the workspace's [data quality](https://docs.lightup.ai/docs/data-quality-dashboards) or [incident](doc:incident-dashboards) dashboards.

## The main page: get stuff done

All data quality work you do in the Lightup app you do in the main page. When you pick a workspace its **Explorer** tab appears in the main page, displaying a tree view of your data assets on the left and asset-focused tabs with data quality analysis tools on the right. This combination lets you quickly set up your asset hierarchy for data quality analysis and health monitoring, from datasources down to individual columns.

The following section walks you through the process of setting up basic data quality monitoring.

# Start monitoring data quality

**Note:** you'll need at least the App Editor app role to follow along with all the steps in this section. If you're an App Viewer, you may still be able follow along with most of the steps, depending on your [workspace role](https://docs.lightup.ai/docs/roles#workspace-roles):

* If you have the Workspace Admin role in a workspace, you can start by [connecting to a datasource](https://docs.lightup.ai/docs/quick-start#connect-to-a-datasource).
* Or, if you have the Workspace Editor in a workspace that has at least one datasource connection available, you can start by [adding schemas to Explorer](https://docs.lightup.ai/docs/quick-start#add-schemas-to-explorer).

Now that you know how Lightup is laid out, you may be wondering, "What do I do next?". Using Lightup is easy, but you have to start somewhere. The following series of examples walks you through the process of setting up a data quality indicator. Once you've learned that basic flow, you're on your way to implementing an always-on observability platform that's customized for your data and business use cases.

## Create a workspace

The first step is creating the workspace where you'll set up your data quality objects— the data assets you will analyze, and the metrics and monitors you create to perform that analysis.

1. On the top pane, select **Create new workspace** from under the workspace switcher drop down.

   ![](https://files.readme.io/543a525293e758244b28b6d05d89893e58371894787ecdb06c9a1cfff76f66c4-Screenshot_2024-10-03_at_4.29.59_PM.webp)
2. On the **New Workspace** page, enter a **Workspace Name** and **Description**.
3. Select **Save** at the top right corner.

   ![](https://files.readme.io/fcd103c151fbba3786f32e16d446ac46d9c509f6fdc00f79963f3c03f6fa464d-Screenshot_2024-10-03_at_4.05.24_PM.webp)


## Connect to a datasource

To begin adding your data assets, you connect to a datasource— a source database. Note that the source database must be prepared before you can connect to it. These preparatory steps are provided and need only be performed once per source database.

You must have the [Workspace Admin role](doc:roles#workspace-roles) to connect to a datasource, or to edit an existing datasource connection. After you connect to a datasource it becomes available to others for data quality analysis.

A datasource exists within a workspace— it points to a source database. You can add a datasource connection in each workspace where you need it. This allows people working in different workspaces to independently analyze and monitor the same source databases.

Each type of datasource has its own inputs required for connecting to it. For steps, see the datasource's page in the following list.

* [Amazon S3 bucket (Beta)](doc:s3)
* [Athena](https://docs.lightup.ai/docs/connect-to-athena)
* [Azure Blob Storage (Beta)](doc:azure-blob-storage)
* [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
* [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
* [Dremio](doc:dremio)
* [Greenplum](https://docs.lightup.ai/docs/greenplum)
* [Hive](https://docs.lightup.ai/docs/connect-to-hive)
* [Incorta](https://docs.lightup.ai/docs/incorta)
* [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
* [MySQL](doc:mysql)
* [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
* [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
* [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
* [SAP HANA](https://docs.lightup.ai/docs/saphana)
* [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
* [Teradata](https://docs.lightup.ai/docs/saphana)

For example, here's how to connect to a new datasource using a Postgres database that's already prepared, with an example shown for a datasource connection in the Plans & Budgets workspace.

1. In the left pane, open a workspace menu and select **Datasources.**
2. In the main page select **Create Datasource +**.

![](https://files.readme.io/822813075706e8527e2e0b9e5b0680d4dc8cb3e0591c1f2a420e5611dc7c90d9-Screenshot_2024-10-03_at_4.07.49_PM.webp)

3. Enter a Datasource Name, then for Connector Type select Postgres.
4. Under Configure connector, provide the following inputs:

* **Host Name** - The hostname for the datasource (check the browser address bar; you want the string between **//** and **/**). Example: `https://`**`host.na.me`**`/`
* **Database Name** - The name of the database you're connecting to. Each datasource can only connect to one database. If you need to connect to more than one, you'll need to create a datasource for each.
* **Username** - Enter ***lightup***.
* **Password** - The username account's password.

5. After entering the required settings and any optional settings that apply, below the **Configure connector** section select **Test Connection**.
6. After a successful connection test, select **Save**.
7. Your new datasource appears in the list of available datasources. By default, these are listed in alphabetical order, so you might have to scroll or change the sort order to see your new datasource.

Here's our example new datasource connection, successfully tested:

![](https://files.readme.io/bd7e9e7-postgres-eg.png)
## Add schemas to Explorer

After you have a datasource, its schemas must be added to Explorer so you can begin data quality monitoring.

1. Select the datasource in the Explorer tree.
2. In the main page, select the **Manage Schemas** tab.
3. Turn on the **Active** toggles for each schema that has data you want to monitor.

![](https://files.readme.io/1d57ea4ae236a27d8298fdd8685006be670f0c6e9631e5dd5e52caccb83ff084-Screenshot_2024-10-03_at_4.11.50_PM.webp)

Note that each schema is scanned when you activate it, which can take some time to complete.

## Set up data profiles

To better understand your data and help enhance your data quality analysis, enable data profiling. Data profiling provides a static analysis of your tables that you can view in the Explorer tree. Data profiles are currently generated only for string, numeric, and time-oriented columns. Other data types such as boolean will be absent from the results.

You enable data profiling when you add data assets to Explorer. The initial data profile uses up to one million rows to create each table's data profile, as follows:

* For a table with under a million rows, the data profile covers the entire table.
* If Lightup can determine which timestamp column to use for time-range queries and the table has at least a million rows, the data profile covers the latest 30 days worth of data.
* If Lightup can't tell which timestamp column to use for time-range queries and the table has at least a million rows, the data profile covers one million randomly-selected rows.

If you aren't sure what types of data quality checks you want, we recommend you enable data profiling to learn about your data. Reviewing these data profiles will give you the info you need to proceed with your data quality journey.

1. Select the datasource in Explorer.
2. On the **Summary** tab, select **Enable All Data Profiles**. This will create data profiles for all the tables in the schemas you added from the datasource, and may take some time.:

![](https://files.readme.io/899e427ef814ff026e61860ec1bee5d2d188569a1969fafff0f11a11b38cc88c-Screenshot_2024-10-03_at_4.14.02_PM.webp)
### Review data profiles

After data profiles are generated, you can review them to help you plan your data quality analysis. For example, reviewing a table's profile will clarify which columns can be used for timestamps in metrics.

When you select a table in the Explorer tree, its **Data Profile** tab displays the table's current data profile:

![](https://files.readme.io/c089b244494f170169631de0b89720c815497d0ca2644fea6ee448fcdf610400-Screenshot_2024-10-03_at_4.18.14_PM.webp)

Each data profile is laid out in sections: Data profile, Table Schema, Timestamp Analysis, Sample Data, and profiled columns (section not labeled).

Review the sections of the data profiles to determine which tables you want to start monitoring. For more details, see [Profile your data](doc:set-up-data-profiling). Identify a table to focus on first, then proceed. :

* The Table Schema section shows the timestamp column, numeric value column and other columns making it suitable for any metric type..
* There are several other columns that are suitable for metric slices. Slices let you group by the values of a column in a metric to automatically create separate datapoints for each slice value.
* You can also view the detailed profile for each column.

![](https://files.readme.io/8ffc685e2eea6180b990c081f856f4f67ed02c9352ccfbaee137b1ba5d12f035-Screenshot_2024-10-03_at_4.21.23_PM.webp)
## Enable auto metrics

After you've identified a table, consider enabling its auto metrics.

Auto metrics provide a simple way to get started understanding your data quality. When you add data assets, you can enable their auto metrics. Lightup makes it possible for you to enable auto metrics at various levels in your data hierarchy, selectively or in bulk.

There are two kinds of auto metrics: metadata metrics that query system data, and deep auto metrics that query your business data.

For our example, we'll enable all the auto metrics on the table we've identified. There are several ways to do so— we'll use the Table Health tab.

1. With the table selected in Explorer, select its **Table Health** tab.

   ![](https://files.readme.io/491656d1168e5c04eb80da3094b3c6d5edda287ee49fc5281401bb7079aab4eb-Screenshot_2024-10-03_at_4.26.06_PM.webp)
2. Auto metrics are listed at the top of the Table Level Metrics section. To enable them:

* Select **Enable** beside the name of a metadata metric.
* Select **Configure table** beside the name of a deep auto metric— this is required because deep auto metrics query the table's data. Review the table configuration and make sure the fields are correctly populated, then click **Confirm and save** to return to the Table Health tab. Then, select **Enable** beside the name of the auto metric.

After you've enabled auto metrics, their names become menu links with three actions: View in Explorer, Monitor Metric, and Disable Metric. Note that at first the auto metric health indicators— the boxes just below the Auto Metrics section label— are gray. This is because until you add at least one monitor to a metric, its health is unknown.

![](https://files.readme.io/1835bade06420ccb1d54865990768c23ff95b11f8f899664c168bc4ba3c3e647-Screenshot_2024-10-03_at_4.27.18_PM.webp)
## Create a metric

It's a good practice to add monitors to your auto metrics and let them run for a while to establish basic monitoring of the timeliness, accuracy, and completeness of a table's data before you begin creating your own metrics for it. To keep things simple for this Quick Start, we'll go ahead and create a simple aggregation metric that measures the table we configured.

1. In the Explorer tree, select the data asset that you want to measure.
2. On the asset's Explorer menu select **+ Create Metric**:

   ![](https://files.readme.io/7d9c0cfc075f3464de687f74bf1569f0d7c61174ab638ef06a80481de974ec17-Screenshot_2024-10-03_at_4.28.39_PM.webp)
3. A new metric opens at Step 1 of the metric configuration form. Under **Metric Info**, select **Aggregation**.
4. Enter a **Metric name**, then select **Next** at the top right. **Step 2 (Configure Metric)** appears in the main form.
5. Under **Aggregation function**, select **Sum**— you may have to scroll down or use the arrow keys to find it in the list.
6. Select **Next**. **Step 3 (Preview)** appears in the main form. Previewing your metric shows you what it would look like with the current configuration, but it's optional so we'll skip it.
7. Select **Next**. **Step 4 (Related metrics)** appears in the main form. You can add related metrics to make them available in your analysis of incidents from the metric you're creating. It's optional so we'll skip it for now. You can always edit the metric later and add related metrics then.
8. Select **Save**. The configuration form closes and your new metric opens in Explorer.

## Add monitors

After you create a metric, you add monitors to detect when the metric value is out-of-bounds. The quickest way is to use the metric's Monitors menu. We'll use the following procedure to add a monitor to the metric we created.

1. With the metric open in Explorer, select its Monitors menu.
2. Choose **+ ADD**.

![](https://files.readme.io/81fb977-add-monitor-explorer.png)

Lightup opens the **Add monitor** modal, which usually has two tabs: **Threshold** and **Anomaly Detection** (both tabs depicted below).

![](https://files.readme.io/5372bf4-auto-monitor.png)Note that some metrics do not support both tabs, because they don't support both underlying monitor types. For example, Compare metrics only support manual thresholds, so the Anomaly Detection tab does not appear in the Add Monitor modal for them.

3. Select the **Anomaly Detection** tab, then click **OK**. Lightup adds a new monitor to the metric using the [default settings for an aggregation metric](https://docs.lightup.ai/docs/default-monitor-settings#aggregation-metric).

## Managing incidents

Congratulations! You've just prepared a data asset for data quality managment and created a monitored metric in Lightup. Because you chose to use anomaly detection, your monitor will intelligently determine when the metric's values are out-of-bounds and generate an incident accordingly. Because you just set it up, you won't have any incidents yet.

To learn more about handling data quality incidents, see [Manage incidents](https://docs.lightup.ai/docs/manage-incidents) and [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident).

# Learn more about Lightup

Now that you've seen the basic end-to-end flow, you might want to learn more about your options:

* [Explorer overview](doc:explorer-overview)
* [Metrics overview](doc:metric-overview)

Updated 6 months ago

---

[Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)[Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
