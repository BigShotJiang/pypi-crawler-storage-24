---
title: "Create a virtual timestamp"
slug: "create-a-virtual-timestamp"
excerpt: "If you find you have no timestamp column available but you know how to compute your timestamp using a suitable column, you can create a virtual timestamp."
hidden: false
metadata:
  title: "Create a virtual timestamp"
  description: "If you find you have no timestamp column available but you know how to compute your timestamp using a suitable column, you can create a virtual timestamp.

Select the timestamp setting, and then click Create Virtual Timestamp +.
In the form that appears, select a column with values you can turn into…"
  url: "https://docs.lightup.ai/docs/create-a-virtual-timestamp"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Create%20a%20virtual%20timestamp&projectTitle=Lightup%20Data%20User%20docs&description=If%20you%20find%20you%20have%20no%20timestamp%20column%20available%20but%20you%20know%20how%20to%20compute%20your%20timestamp%20using%20a%20suitable%20column%2C%20you%20can%20create%20a%20virtual%20timestamp.%0A%0ASelect%20the%20timestamp%20setting%2C%20and%20then%20click%20Create%20Virtual%20Timestamp%20%2B.%0AIn%20the%20form%20that%20appears%2C%20select%20a%20column%20with%20values%20you%20can%20turn%20into%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Create a virtual timestamp

If you find you have no timestamp column available but you know how to compute your timestamp using a suitable column, you can create a virtual timestamp.

1. Select the timestamp setting, and then click **Create Virtual Timestamp +**.
2. In the form that appears, select a column with values you can turn into a timestamp using functions.
3. Enter a function for converting the column's values into UTC-format timestamp values. For example, if you store timestamps as the epoch with millisecond precision, your input might be ***TO\_TIMESTAMP({column\_value}/1000)***.
4. Enter a function for converting UTC-format timestamp values into valid column values, then select **Save**. For example, your input might be ***EXTRACT(epoch FROM {timestamp\_value}) \*1000***.

# Virtual timestamp function examples

The following two tables lists functions you can use to transform a column value to and from a timestamp value in each datasource— one for numeric column values and one for string column values. You can use these as a starting point, adjusting the transformation as needed to accommodate your column values.

## Numeric column values

In these examples, the source column values are stored as the epoch with millisecond precision.

| Database | *columnToTimestamp* | *timestampToColumn* |
| --- | --- | --- |
| Athena | `FROM_UNIXTIME({column_value} / 1000)` | `TO_UNIXTIME({timestamp_value}) * 1000` |
| BigQuery | `TIMESTAMP_MILLIS({column_value})` | `UNIX_SECONDS({timestamp_value}) * 1000` |
| Databricks | `CAST(({column_value} / 1000) AS TIMESTAMP)` | `UNIX_TIMESTAMP({timestamp_value})::BIGINT * 1000` |
| Dremio | `TO_TIMESTAMP(CAST({column_value} AS BIGINT)/1000)` | `CAST(DATE_PART('EPOCH', {timestamp_value}) \* 1000 AS VARCHAR)` |
| Greenplum | `TO_TIMESTAMP({column_value} / 1000)` | `EXTRACT(epoch FROM {timestamp_value}) * 1000` |
| Hive | `FROM_UNIXTIME(CAST({column_value} / 1000 AS BIGINT))` | `UNIX_TIMESTAMP({timestamp_value}) * 1000` |
| Microsoft SQL | `DATEADD(s, {column_value} / 1000, '19700101')` | `CAST(DATEDIFF(s, '19700101', {timestamp_value}) <br><br>AS BIGINT) * 1000` |
| Oracle | `(timestamp '1970-01-01 00:00:00') + numtodsinterval({column_value} / 1000, 'second')` | `(CAST(SYS_EXTRACT_UTC({timestamp_value}) AS DATE) - DATE '1970-01-01' ) * 86400 * 1000` |
| Postgres | `TO_TIMESTAMP({column_value} / 1000)` | `EXTRACT(epoch FROM {timestamp_value}) * 1000` |
| Redshift | `TIMESTAMP 'epoch' + {column_value} / 1000 * interval '1 second'` | `EXTRACT(epoch FROM {timestamp_value})::bigint * 1000` |
| Snowflake | `TO_TIMESTAMP({column_value} / 1000)` | `EXTRACT(epoch FROM {timestamp_value}) * 1000` |
| Teradata | `TO_TIMESTAMP({column_value} / 1000)` | `CAST(((CAST(CAST({timestamp_value} AS TIMESTAMP) AS DATE AT 'GMT') - DATE '1970-01-01') * 86400 + (EXTRACT(HOUR FROM CAST({timestamp_value} AS TIMESTAMP) AT 'GMT') * 3600) + (EXTRACT(MINUTE FROM CAST({timestamp_value} AS TIMESTAMP) AT 'GMT') * 60) + (EXTRACT(SECOND FROM CAST({timestamp_value} AS TIMESTAMP)))) * 1000 AS BIGINT)` |

## String column values

In these examples, the source column values are stored as date/time strings with one-second precision, e.g., `2024-03-15 16:24:51`.

| Database | *columnToTimestamp* | *timestampToColumn* |
| --- | --- | --- |
| Athena | `CHAR_TO_TIMESTAMP('yyyy-MM-dd-hh-mm-ss','{column_value}')` | `TIMESTAMP_TO_CHAR(yyyy-MM-dd-hh-mm-ss,{timestamp_value});` |
| BigQuery | `CAST({column_value} AS TIMESTAMP FORMAT YYYY-MM-DD-HH24-MI-SS)` | `UNIX_{timestamp_value}` |
| Databricks | `CAST(({column_value}) AS TIMESTAMP)` | `UNIX_{timestamp_value})::BIGINT * 1000` |
| Dremio | `TO_TIMESTAMP(CAST({column_value} AS BIGINT)/1000)` | `CAST{timestamp_value}` |
| Greenplum | `TO_TIMESTAMP({column_value} / 1000)` | `EXTRACT{timestamp_value}` |
| Hive | `FROM_UNIXTIME(CAST({column_value} / 1000 AS BIGINT))` | `{timestamp_value}` |
| Microsoft SQL | `DATEADD(s, {column_value} / 1000, '19700101')` | `{timestamp_value}` |
| Oracle | `(timestamp '1970-01-01 00:00:00') + numtodsinterval({column_value} / 1000, 'second')` | `{timestamp_value}` |
| Postgres | `TO_TIMESTAMP({column_value} / 1000)` | `{timestamp_value}` |
| Redshift | `TIMESTAMP 'epoch' + {column_value} / 1000 * interval '1 second'` | `EXTRACT({timestamp_value}` |
| Snowflake | `TO_TIMESTAMP({column_value} / 1000)` | `EXTRACT {timestamp_value}` |
| Teradata | `TO_TIMESTAMP({column_value} / 1000)` | `{timestamp_value}` |

Updated 6 months ago

---

[Timestamp](https://docs.lightup.ai/docs/timestamp)[Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
