---
title: "Manage incidents"
slug: "manage-incidents"
excerpt: "When a monitor detects a variation that's out-of-bounds, it logs an incident. Each incident is specific to one monitor, and has a start time, a severity, a direction, a duration, and a status. When a monitor logs an incident, you can analyze the incident to determine its cause so you can address it in your production data."
hidden: false
metadata:
  title: "Manage incidents"
  description: "When a monitor detects a variation that's out-of-bounds, it logs an incident. Each incident is specific to one monitor, and has a start time, a severity, a direction, a duration, and a status. When a monitor logs an incident, you can analyze the incident to determine its cause so you can address it …"
  url: "https://docs.lightup.ai/docs/manage-incidents"
  image: ["https://cdn.readme.io/og-image/create?type=docs&title=Manage%20incidents&projectTitle=Lightup%20Data%20User%20docs&description=When%20a%20monitor%20detects%20a%20variation%20that's%20out-of-bounds%2C%20it%20logs%20an%20incident.%20Each%20incident%20is%20specific%20to%20one%20monitor%2C%20and%20has%20a%20start%20time%2C%20a%20severity%2C%20a%20direction%2C%20a%20duration%2C%20and%20a%20status.%20When%20a%20monitor%20logs%20an%20incident%2C%20you%20can%20analyze%20the%20incident%20to%20determine%20its%20cause%20so%20you%20can%20address%20it%20%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light"]
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Manage incidents

When a monitor detects a variation that's out-of-bounds, it logs an incident. Each incident is specific to one monitor, and has a start time, a severity, a direction, a duration, and a status. When a monitor logs an incident, you can [analyze the incident](doc:analyze-an-incident) to determine its cause so you can address it in your production data.

When you want to work *with* incidents as opposed to analyzing a specific one, you have several options:

* [The **Incidents list**](https://docs.lightup.ai/docs/manage-incidents#the-incidents-list) is a central place to work with all the incidents in the workspace. You can review all of an incident's details by selecting its ID in the Incidents list.
* [The **Incident dashboard**](https://docs.lightup.ai/docs/manage-incidents#the-incident-dashboard) provides summary information about a workspace's incidents, and links to the Incidents list so you can drill down.
* [The **Explorer tree**](doc:explorer-overview#the-explorer-tree) gives you a 7-day window into incidents on a metric. If a metric has incidents, they'll appear in Explorer, and clicking on the metric's **Incidents** menu opens a list of its incidents in the 7-day window. You can change the window to expand it, and from the list, you can select any incident to analyze it.
* [The **Table Health** tab](doc:tables#table-health-tab-beta) lists a table's metrics, and shows a count of incidents for each. You can select a listed metric's name and then select **View in Explorer**. You can then click on the metric's **Incidents** menu as in the preceding item.

# The Incidents list

With a workspace selected, select **Incidents** on the top bar to open the **Incidents** list.

![](https://files.readme.io/b8719c53fcd5a4325b6c461a3441251c7894cb724f5b79ef69030dcefb7fe80a-Screenshot_2024-10-03_at_5.20.21_PM.webp)

* Tiles across the top display summary information about incidents in the workspace
* **Search** applies list filters by id or by attribute. Click the Search box and type or scroll to find a search term, then select a term to filter the list to matching items. You can add multiple search terms to narrow down the displayed items more.
* You can click the ID of an incident to open it, and you can click the name of a metric to edit the metric or view it in Explorer.
* If you don't see the field you want, select the gear icon and select/deselect fields to display.
* Lightup updates the Status of an incident from *Unviewed* to *Viewed* when someone views the incident details— but you can set it back.
* The check boxes on the far left allow you to use bulk operations to change the Status of multiple incidents, or [validate multiple incidents](doc:analyze-an-incident#validate-an-incident-fix).

## Setting incident status

You can select a different Status for one or more incidents in the Incidents list. Most status changes don't affect how Lightup works— they are for your use to assist your team in managing incidents. There are two exceptions:

* If you set the status of an incident to *Rejected* it won't show up in Explorer views (e.g., the Incidents menu on [a metric chart](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds) won't include the incident in the count the Incident menu displays). Further, [if the monitor that detected the incident has Incident Learning enabled](doc:monitor-a-metric) , it ignores *Rejected* incidents when learning.
* If the incident stauts is *Unviewed* and anyone opens the incident details, Lightup changes the incident status to *Viewed*. You can set incident status back to *Unviewed*, which will persist until someone opens the incident details again.

# The Incident dashboard

For an overview of a workspace's incidents, on the **Dashboards** tab select **Incident**.

![](https://files.readme.io/467fd4c881c6fe8a18284bbf971e294b9a6b2b6ec7a431c6a2c82539e9735c7e-Screenshot_2024-10-04_at_12.00.20_AM.webp)

On the left, tiles indicate the number of incidents with various statuses. If the number isn't zero, the tile is also a filtered link to the Incidents list. Select a tile to open the Incidents list and display items with the indicated status. Note that **Resolved** is actually a validation status, so the filters have some overlap (e.g., an incident can be **Submitted** and **Resolved** at the same time).

On the right, you can specify a date range at the top, and review the following charts:

* **Incidents** plots the count of incidents over time.
* **Incidents by incident status** also shows counts over time, but as stacked bars (one per incident status). Select a status in the legend at the bottom of the chart to toggle the corresponding bars on or off. For example, if all statuses are displayed and you want to hide unviewed incidents, select **Unviewed** in the legend— select it again to unhide them.
* **Resolved incidents** plots the count of resolved incidents over time. For information about resolving incidents, see [validate an incident fix](doc:analyze-an-incident#validate-an-incident-fix).
* **Incidents by severity** shows counts of incidents over time as stacked bars (one per severity). Select a severity in the legend at the bottom of the chart to toggle the corresponding bars on or off.

# Recurring Incident Alerts

When an incident occurs, Lightup schedules alerts to be sent to all alerting channels that have been registered for the monitor. Alerting channels are created by creating an integration. They support the following functionality:

* The integration can be configured to send the alert immediately.
* Some integrations allow the user to specify that alerts should be sent hourly, daily or weekly. This is commonly referred to as a “digest” form. An integration that uses this digest format sends a periodic (hourly, daily, or weekly) summary of the number of incidents that have started, ended or are ongoing during the period.

Updated 6 months ago

---

[Review query history](https://docs.lightup.ai/docs/query-history)[Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
