---
title: "Welcome to Lightup!"
slug: "welcome-to-lightup!"
excerpt: "Lightup is a next-generation data quality and data observability platform. It empowers your team to quickly and easily perform continuous, comprehensive data quality checks. Workflows that are currently manual become automated, allowing you to achieve complete data coverage across all of your data assets, across all cloud and hybrid environments."
hidden: false
metadata:
  title: "Welcome to Lightup!"
  description: "Lightup is a data quality and observability platform that automates comprehensive data quality checks, enabling continuous monitoring and granular analysis through features like data profiling, slices, auto metrics, and customizable metrics. It supports both threshold-based and anomaly detection monitoring, providing a powerful and flexible solution for managing data quality across cloud and hybrid environments."
  url: "https://docs.lightup.ai/docs/welcome-to-lightup"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=LightUp%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=Lightup%20is%20a%20data%20quality%20and%20observability%20platform%20that%20automates%20comprehensive%20data%20quality%20checks%2C%20enabling%20continuous%20monitoring%20and%20granular%20analysis%20through%20features%20like%20data%20profiling%2C%20slices%2C%20auto%20metrics%2C%20and%20customizable%20metrics.%20It%20supports%20both%20threshold-based%20and%20anomaly%20detection%20monitoring%2C%20providing%20a%20powerful%20and%20flexible%20solution%20for%20managing%20data%20quality%20across%20cloud%20and%20hybrid%20environments.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Welcome to Lightup!

Lightup is a next-generation data quality and data observability platform. It empowers your team to quickly and easily perform continuous, comprehensive data quality checks. Workflows that are currently manual become automated, allowing you to achieve complete data coverage across all of your data assets, across all cloud and hybrid environments.

# Data profiles for quick insights

Data profiling is fundamental to data quality management. Knowing the shape of your data is crucial when you want to measure its quality. Lightup data profiling simplifies data quality analysis by illuminating that shape.

A data profile is a static analysis of a table. If the table is small, you can profile the whole table. For larger tables, you can profile a specified time range or a randomly selected set of rows.

Data profiling requires no input from you. You simply turn it on, and Lightup generates data profiles to help you understand your data. See [Profile your data](doc:set-up-data-profiling) for details.

# Data quality monitoring for ongoing quality management

When working with data, a variety of questions come up about the completeness, timeliness, and accuracy of your data. For example:

* Were my tables updated on time?
* If they were updated on time, did the expected volume of data show up in the tables?
* Was the data that appeared valid?
* Were there too many null values?
* For a categorical column, are the categories those that are expected, with the distribution expected?

Lightup enables you to answer these data quality questions via an automation platform that provides "always-on" data quality monitoring. It runs in the background, and generates routable alerts when incidents occur. See the data quality analysis [Overview](doc:data-quality-with-lightup) for details.

# Slices to streamline DQ for your business structure

Lightup supports slices to help you streamline data quality analysis to match the organization of your business. Slices let you define a metric so that each value of a selected column (the slice column) is measured separately, using the exact same query except for the slice value. Then you can monitor each slice separately, defining different expectations and detecting any incidents on a per-slice basis. For example, you might think about your sales by brand, market, or channel. Any columns that identify these groupings would be a good choice to use for slices.

Lightup enables you to understand data quality by slice, automatically detecting slices and tracking individual metrics and incidents for each. Slicing is a natural and powerful way to enable automated and granular data quality monitoring that represents the organization of your business data. See [Slices](doc:slices) for details.

# Auto metrics for common questions

Lightup includes auto metrics to handle many common data quality checks. These are turn-key metrics that can help you start managing data quality quickly, forming a basis on which you can build custom, more complex metrics. See [Auto metrics](doc:autometrics-1) for details.

# Create metrics to suit your needs

Answer more complex questions about your data's completeness, timeliness, accuracy, and other data quality dimensions, by creating your own metrics. From no-code to low-code to full-on SQL, Lightup's metrics give you power and flexibility to build and improve your data quality analysis. By adding slices to a metric, you can create one metric that measures the table's data quality and then independently track data quality for each value of the slice column. See [Create and edit metrics](doc:create-and-edit-metrics) for details.

# Monitor by thresholds or with anomaly detection

Lightup separates the metric (which measures quality) and the monitor (which establish rules to check metric values). This lets you create as many monitors as you want for a metric— for example, if your metric is sliced, you can add a different monitor to each of them.

When creating a monitor, you can set threshold values manually, or use automated anomaly detection to easily monitor when your data changes from its historical norm. See [Monitor a metric](doc:monitor-a-metric) for details.

# Powerful, flexible data quality management

With a wide variety of turn-key features as well as extensive customizability, Lightup empowers enterprises to innovate and make business decisions with confidence by providing data teams with the fastest and easiest way to create trust in their cloud and hybrid data at any scale.

# About this guide

This Lightup User's Guide is here to help you monitor your cloud data. Try the [Quick Start](doc:quick-start) to jump right in or dig into more in-depth content in the pages that follow.

Updated 6 months ago

---

[Quick Start](https://docs.lightup.ai/docs/quick-start)
