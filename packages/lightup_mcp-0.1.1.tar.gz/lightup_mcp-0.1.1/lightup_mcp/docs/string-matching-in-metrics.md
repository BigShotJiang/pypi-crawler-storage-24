---
title: "String matching in metrics"
slug: "string-matching-in-metrics"
excerpt: "You can use string matching to add conditions in conformity metrics and SQL metrics. Two types of pattern matching are supported: SQL patterns and regular expressions."
hidden: false
metadata:
  title: "String matching in metrics"
  description: "You can use string matching to add conditions in conformity metrics and SQL metrics. Two types of pattern matching are supported: SQL patterns and regular expressions.
SQL pattern matching
You can use SQL pattern matching to create conditions in conformity metrics and SQL metrics. You can include sp…"
  url: "https://docs.lightup.ai/docs/string-matching-in-metrics"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=String%20matching%20in%20metrics&projectTitle=Lightup%20Data%20User%20docs&description=You%20can%20use%20string%20matching%20to%20add%20conditions%20in%20conformity%20metrics%20and%20SQL%20metrics.%20Two%20types%20of%20pattern%20matching%20are%20supported%3A%20SQL%20patterns%20and%20regular%20expressions.%0ASQL%20pattern%20matching%0AYou%20can%20use%20SQL%20pattern%20matching%20to%20create%20conditions%20in%20conformity%20metrics%20and%20SQL%20metrics.%20You%20can%20include%20sp%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# String matching in metrics

You can use string matching to add conditions in conformity metrics and SQL metrics. Two types of pattern matching are supported: SQL patterns and regular expressions.

# SQL pattern matching

You can use SQL pattern matching to create conditions in conformity metrics and SQL metrics. You can include specific characters/strings, wildcards, or a combination.

* Use a specific character or character sequence to match it exactly, or in combination with wildcards. For example, **'North%'** matches any string that starts with *North*. Note that for some datasources specific characters are case-sensitive, while in others they are case-insensitive (potentially affecting your matches).
* There are two wildcards: an underscore (**\_**) matches any one character, and a percent sign (**%**) matches a string of any length. For example, **'North\_\_%'** (note the consecutive underscores) matches any string that begins with *North* and is at least seven characters long, such as *North 4th Street*.
* Enclose a set or range of characters inside square brackets to match any one of them. For example:
  + **'[a,b,c]'** evaluates one character and matches if it is *a*, *b*, or *c*.
  + **'[a-c]'** also evaluates one character and matches if it is *a*, *b*, or *c*.
  + **'D[a,o]%'** matches any string that begins with *Da* or *Do*.

Some datasources support more varieties of SQL pattern matching, such as including a caret (**^**) as the first character inside square brackets to exclude rather than match the values inside the brackets. Check your datasource documentation for more information about supported pattern matching options.

## SQL patterns in Conformity metrics

When you create a conformity metric, you must add at least one condition to check rows for conformity. If you choose *Does not match pattern* or *Match pattern*, the pattern you enter for comparisons is used with the LIKE operator as a single-quote delimited string in the metric query. For example, the following SQL returns the count of rows where the value of *Restaurant* begins with **D**:

SQL
```
SUM(
		CASE
			WHEN "Restaurant" LIKE 'D%' THEN 1
			ELSE 0
		END
	) AS "count",
```
## SQL patterns in SQL metrics

You can use SQL patterns with the LIKE operator anywhere in your SQL metric's query as part of a WHERE clause.

# Regular expression matching

You can use regular expressions to match strings inside metric queries. You can use [regex101.com](https://regex101.com/) to generate regular expressions, but not all datasources handle meta sequences the same. For example, if your expression contains the sequence **\d** (to match any digit), the datasource may require that you add a backslash in front of the sequence for it to work in a SELECT statement: to get **\d**, you enter **\\d**.

## Regex in Conformity metrics

When you create a conformity metric, you must add at least one condition to check rows for conformity. If you choose *Does not match regex* or *Match regex*, the pattern you enter for comparisons becomes a single-quote delimited string in the metric query. Because you cannot change the string delimiters, this can cause SQL errors when your pattern contains meta sequences, depending on the datasource.

## Regex in SQL metrics

You can use regular expressions in your SQL metrics as needed, but meta sequences might cause SQL errors depending on how you use them and the metric's datasource. In some cases, you can use specific string delimiters to avoid these errors. Otherwise, you can add escape characters in front of any meta sequences.

## Check your datasource's official help

Before you use a regular expression in a metric, consider referring to the official support content for the metric's datasource, in particular content using regular expressions in SELECT statements.

Updated 6 months ago

---

[SQL metrics](https://docs.lightup.ai/docs/sql-metrics)[Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
