---
title: "Add virtual tables on relational datasources"
slug: "add-virtual-tables-on-relational-datasources"
excerpt: "You can create a virtual table on certain datasources using SQL. This capability is useful if you want to create data quality checks on tables that you define in Lightup using SQL. Normally you would create views on the datasource to accomplish this, and let Lightup discover the view when it scans the datasource. However, sometimes you may either not have the permissions to create views on the datasource or you may not want to create views directly on the datasource. This capability gives you the flexibility to do that inside Lightup."
hidden: false
metadata:
  title: "Add virtual tables on relational datasources"
  description: "You can create virtual tables using SQL in Lightup to perform data quality checks without needing permissions to create views on the datasource, and this process involves defining, validating, configuring, previewing, and activating the virtual table before setting up metrics and monitors. Virtual tables are supported on Oracle and Postgres datasources."
  url: "https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Add%20virtual%20tables%20in%20relational%20datasources%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=You%20can%20create%20virtual%20tables%20using%20SQL%20in%20Lightup%20to%20perform%20data%20quality%20checks%20without%20needing%20permissions%20to%20create%20views%20on%20the%20datasource%2C%20and%20this%20process%20involves%20defining%2C%20validating%2C%20configuring%2C%20previewing%2C%20and%20activating%20the%20virtual%20table%20before%20setting%20up%20metrics%20and%20monitors.%20Virtual%20tables%20are%20supported%20on%20Oracle%20and%20Postgres%20datasources.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Add virtual tables on relational datasources

You can create a virtual table on certain datasources using SQL. This capability is useful if you want to create data quality checks on tables that you define in Lightup using SQL. Normally you would create views on the datasource to accomplish this, and let Lightup discover the view when it scans the datasource. However, sometimes you may either not have the permissions to create views on the datasource or you may not want to create views directly on the datasource. This capability gives you the flexibility to do that inside Lightup.

# Create

1. **From the schema context menu**

![](https://files.readme.io/70a17da-Screenshot_2024-07-31_at_1.52.49_PM.png)

2. **From the Table Configuration tab under a schema**

![](https://files.readme.io/4b16a94-Screenshot_2024-07-31_at_1.57.20_PM.png)

Once you enter the virtual table creation dialogue you can begin defining the virtual table, configure, preview and save it before you create data quality checks (metrics and monitors) on it.

![](https://files.readme.io/cc06f19-Screenshot_2024-08-01_at_4.14.25_AM.png)
# Define and Validate SQL

1. Add the name of the virtual table and choose its query scope. (["Incremental" or "Full Table"](https://docs.lightup.ai/docs/query-scope))
2. Write the SQL needed to create the virtual table. The requirements for creating the SQL for virtual tables are the same as documented on the [SQL metrics](https://docs.lightup.ai/docs/sql-metrics) page

   **Example**:
   1. SQL
      ```
      SELECT
      	*
      FROM
      	(
      		SELECT
      			*,
      			"timestamp" :: date as "order_date"
      		FROM
      			"testdata"."customer_orders_fact"
      		WHERE
      			"timestamp" >= `{start_ts}`
      			AND "timestamp" < `{end_ts}`
      	) as q1
      WHERE
      	"order_date" >= `{start_date}`
      	AND "order_date" < `{end_date}`
      ```
3. Validate the SQL using the "Validate Query" button. You cannot save the virtual table without successfully validating the SQL

# Configure

You can optionally add the required configuration parameters before saving in order to finish setting up a virtual table. The configuration parameters are the same as those you would setup for tables as listed in the [Configure tables page](https://docs.lightup.ai/docs/table-configuration).

While this step is optional during virtual table creation, you will eventually need to configure the virtual table when you activate it (see the [Activate](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources#activate) section) before setting up data quality checks on it.

Note that certain configuration fields are required for you to preview a virtual table of incremental query scope (see the [Preview](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources#preview) section)

# Preview

You can optionally preview a virtual table to see its column names, inferred data types as well as sample data retrieved by the SQL query you used to define the virtual table.

The following fields are needed for you to preview the data for [incremental query scope](https://docs.lightup.ai/docs/query-scope)

* Aggregation interval, aggregation timezone, timestamp column name, timestamp column type, timestamp timezone

# Activate

Once the virtual table has been saved, you need to finish setting up the configuration parameters (if you have not already done so as described in the [Configure](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources#configure) section) and activate the table from the schema "Table Configuration tab" by toggling the table on. Once this is done, the virtual table will appear in the Explorer panel under the chosen schema.

![](https://files.readme.io/3f9cbf2-Screenshot_2024-07-31_at_5.44.48_PM.png)
# Setup metrics

The following [auto metrics](https://docs.lightup.ai/docs/autometrics-1) are supported on virtual tables

| Metric type | Metric name | Support |
| --- | --- | --- |
| Table Auto metrics | Row count/Byte count | Not supported |
|  | Column activity | Not supported |
|  | Update delay | Not supported |
|  | Data delay | **Supported** |
|  | Data volume | **Supported** |
| Column Auto metrics | Category activity | **Supported** |
|  | Distribution | **Supported** |
|  | Null percent | **Supported** |
| Custom metrics | [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics) | **Supported** |
|  | [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics) | **Supported** |
|  | [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics) | **Supported** |
|  | [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics) | **Supported** |
|  | [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics) | **Supported** |
|  | [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics) | **Supported** |
|  | [SQL metrics](https://docs.lightup.ai/docs/sql-metrics) | **Supported** |

# Setup monitors

Once you have setup metrics on virtual tables, you can [enable monitors](https://docs.lightup.ai/docs/monitor-a-metric) as you would for other tables

# Supported datasources

Virtual tables are supported on the following datasources

* Oracle
* Postgres
* Incorta
* Snowflake
* Databricks

Updated 6 months ago

---

[Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)[Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
