---
title: "Configure tables"
slug: "configure-tables"
excerpt: "When you activate a table you can configure its settings, which are inherited by metrics that are based on the table. You can override these settings on a per-metric basis as needed."
hidden: false
metadata:
  title: "Configure tables"
  description: "When you activate a table you can configure its settings, which are inherited by metrics that are based on the table. You can override these settings on a per-metric basis as needed.
Note that these settings are not inherited by SQL metrics. With a SQL metric, you manage its settings via a combinati…"
  url: "https://docs.lightup.ai/docs/table-configuration"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Configure%20tables&projectTitle=Lightup%20Data%20User%20docs&description=When%20you%20activate%20a%20table%20you%20can%20configure%20its%20settings%2C%20which%20are%20inherited%20by%20metrics%20that%20are%20based%20on%20the%20table.%20You%20can%20override%20these%20settings%20on%20a%20per-metric%20basis%20as%20needed.%0ANote%20that%20these%20settings%20are%20not%20inherited%20by%20SQL%20metrics.%20With%20a%20SQL%20metric%2C%20you%20manage%20its%20settings%20via%20a%20combinati%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Configure tables

When you activate a table you can configure its settings, which are inherited by metrics that are based on the table. You can override these settings on a per-metric basis as needed.

Note that these settings are not inherited by SQL metrics. With a SQL metric, you manage its settings via a combination of configuration options and SQL.

Except for Query Scope, table settings can be changed after you save the table configuration. Any changes will be inherited by any metrics that are inheriting settings.

# Data Collection settings

The Data Collection settings you can select depend on how you set **Query Scope**, which can only be set for a table when you first configure it— you can't change this setting after you save the table's configuration. However, if you override inherited table settings in a metric, you can change the **Query Scope** for the metric.

If **Query Scope** is set to *Incremental*, your form will have the fields shown below:

![](https://files.readme.io/9b03a21-DC-incremental.png)

If **Query Scope** is set to *Full Table*, your form will instead have the fields shown below.

![](https://files.readme.io/1990c8b-image.png)The various **Data Collection** settings are described on the following pages:

* [Query scope](doc:query-scope)
* [Data collection schedule](doc:data-collection-schedule)
* [Data collection window](doc:data-collection-window)
* [Aggregation interval](doc:aggregation-interval)
* [Polling interval](doc:polling-interval)
* [Aggregation time zone](doc:aggregation-time-zone)
* [Polling timezone](doc:polling-timezone)
* [Evaluation delay](doc:evaluation-delay)
* [Polling delay](doc:polling-delay)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
* [Timestamp timezone](doc:timestamp-timezone)
* [Partitions](doc:partitions)

Updated 6 months ago

---

[Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)[Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
