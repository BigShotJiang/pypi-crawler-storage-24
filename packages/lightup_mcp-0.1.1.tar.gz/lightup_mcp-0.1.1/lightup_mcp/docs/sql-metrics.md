---
title: "SQL metrics"
slug: "sql-metrics"
excerpt: "Lightup's No-code and Low-code Data Quality metrics cover a significant amount of data quality requirements. However, there are times when a SQL metric is still need to be used:"
hidden: false
metadata:
  title: "SQL metrics"
  description: "Lightup's No-code and Low-code Data Quality metrics cover a significant amount of data quality requirements. However, there are times when a SQL metric is still need to be used:

Multi-column Aggregation
CASE statements
Multiple JOINs
Sub-queries or CTEs
Complex WHERE logic (i.e. OR or () are requir…"
  url: "https://docs.lightup.ai/docs/sql-metrics"
  image: ["https://cdn.readme.io/og-image/create?type=docs&title=SQL%20metrics&projectTitle=Lightup%20Data%20User%20docs&description=Lightup's%20No-code%20and%20Low-code%20Data%20Quality%20metrics%20cover%20a%20significant%20amount%20of%20data%20quality%20requirements.%20However%2C%20there%20are%20times%20when%20a%20SQL%20metric%20is%20still%20need%20to%20be%20used%3A%0A%0AMulti-column%20Aggregation%0ACASE%20statements%0AMultiple%20JOINs%0ASub-queries%20or%20CTEs%0AComplex%20WHERE%20logic%20(i.e.%20OR%20or%20()%20are%20requir%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light"]
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# SQL metrics

Lightup's No-code and Low-code Data Quality metrics cover a significant amount of data quality requirements. However, there are times when a SQL metric is still need to be used:

* Multi-column Aggregation
* CASE statements
* Multiple JOINs
* Sub-queries or CTEs
* Complex WHERE logic (i.e. OR or () are required)

Before starting with a SQL-based metric, it is important to understand what the desired outcome of the metric is and format the SQL query to get the outcome which Lightup is expecting.

# Know Before You SQL

### Format SQL for Lightup's Expected Outcome

The essential outcome of a SQL metric in Lightup is a single, numerical data point for a given [interval window](https://docs.lightup.ai/docs/aggregation-interval) (5 Minutes, Hourly, Daily, and so on).

> Example: Daily sum of values in a column should result in a single numerical data point per day

Therefore, the fundamental SQL requirements are a SELECT statement, an Aggregation function in the SELECT statement, and a GROUP BY.

The following SQL is an example of getting the count orders per hour:

sql
```
SELECT
	DATE_TRUNC('HOUR', order_timestamp) as "hourly_orders",
  COUNT(*)
FROM
  customer_orders_table
WHERE
	order_timestamp >= {start_ts}
  AND order_timestamp < {end_ts}
GROUP BY
  hourly_orders
```

Notice how the timestamp had to be truncated to the hour to get a total count of orders to match the [aggregation interval](https://docs.lightup.ai/docs/aggregation-interval) of an hour. The outcome of this query should get a maximum of 1 data point per hour.

The following SQL adds a slicing column to the previous SQL query:

sql
```
SELECT
	DATE_TRUNC('HOUR', order_timestamp) as "hourly_orders",
  city,
  COUNT(*)
FROM
  customer_orders_table
WHERE
	order_timestamp >= {start_ts}
  AND order_timestamp < {end_ts}
GROUP BY
  hourly_orders,
  city
```

By adding the City column in the SELECT and GROUP BY statements, Lightup will be able to slice the hourly count by distinct city value. In this scenario, if there are 10 cities, then Lightup expects a maximum of 1 data point per hour, per city.

### Lightup Variables for Incremental Metrics

Also, in both of these SQL queries, there is a WHERE clause that includes a very specific setup of parameters and operators:

* For an [Incremental Metric](https://docs.lightup.ai/docs/query-scope), Lightup will need to provide the start and end time for the desired [aggregation interval](https://docs.lightup.ai/docs/aggregation-interval). In the case of an Hourly interval, Lightup will give the beginning of the hour for `{start_ts}` and the beginning of the next hour for `{end_ts}`
* The operator for `{start_ts}` needs to be `>=` to get all records associated to the beginning of the hour. Whereas the operator for `{end_ts}` needs to be `<` in order to get all records associated to the desired hour

  + If the `=` operator is used for both, then the data point could be double-counting the records at the end of one hour and the beginning of the next hour
  + For example:

  | timestamp | order | city |
  | --- | --- | --- |
  | 01-01-2024 11:00:00 | 817473529374242 | Tampa |
  | 01-01-2024 11:00:00 | 124789092831237 | Sioux Falls |
  | 01-01-2024 12:00:00 | 423198128341982 | Dallas |
  | 01-01-2024 12:00:00 | 798429841794712 | Nashville |
  | 01-01-2024 13:00:00 | 3123172874812748 | Tampa |
  | 01-01-2024 13:00:00 | 019839817248298 | Salt Lake City |

  + In the above table, if the query is used to count all records with a start time >= 11:00:00 and an end time <= 12:00:00, then the count would return 4. However, if the start and end times in the query are increased an hour to 12:00:00 and 13:00:00, then the count would be 4, which would double-count the records at 12:00:00

Available variables for the incremental SQL metric are:

| Variable | Outcome | Example |
| --- | --- | --- |
| {start\_ts}/{end\_ts} | Timestamp | 2023-04-24 06:00:10 |
| {start\_date}/{end\_date} | Date | 2024-02-10 |
| {start\_datetime}/{end\_datetime} | Datetime | 2024-01-02T01:00:00 |

These variables need to match the expected outcome of the column that they are being used on (i.e. Date column cannot use `{start_ts}`).

### Full Table SQL

If the SQL query is intended to get an aggregate outcome of all records in a table, this is where a [Full Table](https://docs.lightup.ai/docs/query-scope) would be used:

sql
```
SELECT
  city,
  COUNT(*)
FROM
  customer_orders_table
GROUP BY
  city
```

This SQL shows how to get every order that each city has ever had. Depending on the [polling interval](https://docs.lightup.ai/docs/polling-interval) for the Full Table query, Lightup will expect a maximum of one data point per polling interval window.

### Timezones

In order for Lightup to execute a metric on the desired date range at the desired time, timezones must be correct. In the case of SQL metrics, there are multiple places for timezones to be specified and used:

1. [Aggregation Timezone](https://docs.lightup.ai/docs/aggregation-time-zone) is the timezone Lightup uses for the aggregation window and the scheduled execution. If the [Evaluation Delay](https://docs.lightup.ai/docs/evaluation-delay) of a daily metric is 2 Hours, then Lightup will execute the metric collection at 2 am according to the Aggregation Timezone
2. [Timestamp Timezone](https://docs.lightup.ai/docs/timestamp-timezone) is the timezone related to the timestamp that the SQL query returns.

If the Timezones are not aligned correctly, then you may get the following errors depending on the kind of mis-match:

`Please review the SQL. The following rows have unexpected timestamps (epoch in seconds) and slicing values that do not match the configured aggregation timezone and slice`

or `Please review the SQL. The configured aggregation interval of {...} seconds does not match with the time truncation interval of {..} seconds in SQL. The following rows have unexpected timestamps (epoch in seconds) that do not match the configured aggregation timezone {...}`

or `Please review the SQL. Duplicate timestamp (epoch in seconds) in row {row1_in_json} and row {row2_in_json}`

![](https://files.readme.io/4827174-image.png)

Please make sure that the timezone of the timestamp in the SQL query is correct aligned with what is in the metric configuration. One way of making sure this is correct is by leveraging a timezone conversion function in the SQL to convert the timestamp to a UTC timezone before it is returned to Lightup.

# Create a SQL metric

Note that blob storage datasources ([AWS S3](doc:s3), [Azure](doc:azure-blob-storage)) currently do not support SQL metrics.

1. In the Explorer tree, select the data asset that you want to measure.
2. On the asset's Explorer menu select **+ Create Metric**:

   ![](https://files.readme.io/034e4e0-create-new-metric.png)
3. The metric configuration form opens. Set **Metric type** to **SQL**.
4. Enter a **Metric name**.
5. By default, new metrics go Live shortly after you create them. If you want the metric to start off paused, under **Metric status**, set **Status** to *Paused*.
6. If desired, change the value of **Quality dimension**. Each data quality metric measures one dimension of data quality: accuracy, completeness, timeliness, or (if none of these applies), custom. You can sort and filter your metrics by dimension, and you can view them summarized by dimension in a [data quality dashboard](doc:data-quality-dashboards).
7. Select **Next** to proceed to **Step 2 (Configure Metric)**.

![](https://files.readme.io/5357d52-c-sql-step2.png)

8. Under **Select data asset** specify the data asset under which your metric will appear in the Explorer tree. This does not have an effect on the metric's source, just where it appears in the Explorer tree.
9. Enter your SQL in the **Custom SQL** box. To produce a metric, your SQL clauses must have certain elements:

* Your SQL must **SELECT** at least two values, the timestamp and the aggregated metric value that you want the metric to compute. After validating the query, you will have the opportunity to select this timestamp as your timestamp, and select the metric value as the column. The timestamp will become the X-axis of your metric chart and the aggregated metric value will become the y-axis of your metric chart. If you are creating a sliced metric, you will additionally need the slice column in your **SELECT**.
* The **WHERE** clause must specify a date range using the time-based column and two tags: one producing the start of the range and another for the end of the range. These tags reflect the kind of time-based column you have: (1) use *{start\_ts}* and *{end\_ts}* for a timestamp column, (2) use *{start\_date}* and *{end\_date}* for a date column, and (3) use *{start\_datetime}* and *{end\_datetime}* for a datetime column.
* The timestamp in your **SELECT** must match the aggregation interval that you choose in the drop down selection after you click **Validate Query**. For example, if your metric does a **SELECT** of a date, you cannot set **Aggregation Interval** to hourly.
* Your SQL must GROUP BY the timestamp column.
* If you want to create a sliced metric, you must add a **GROUP BY** clause on the intended slice columns. You can then choose them as the slice column after you validate your SQL in step 3 (the next numbered item, below). Note that the slice column can't include the column with aggregated metric values in your SELECT clause.
* Note that if you want your SQL metric's **Query Scope** to be *Full Table*, the query requirements change.
  + The SELECT clause doesn't need to select a timestamp.
  + The WHERE clause doesn't need start and end tags.
* See below for [SQL examples for each supported datasource](https://docs.lightup.ai/docs/sql-metrics#sql-examples).

10. When your SQL is ready, select **Validate Query**. If the query validates, a number of other fields in the form become active.
11. Because a SQL metric doesn't inherit Data Collection settings, you must set them. First, set [**Query Scope**](doc:query-scope)— your choice determines which other Data Collection settings appear.

| Data Collection settings | Query Scope |
| --- | --- |
| [Data collection schedule](doc:data-collection-schedule) | Incremental or Full Table |
| [Data collection window](doc:data-collection-window) | Incremental only |
| [Aggregation interval](doc:aggregation-interval) | Incremental only |
| [Aggregation time zone](doc:aggregation-time-zone) | Incremental only |
| [Evaluation delay](doc:evaluation-delay) | Incremental only |
| [Polling interval](doc:polling-interval) | Full Table only |
| [Polling timezone](doc:polling-timezone) | Full Table only |
| [Polling delay](doc:polling-delay) | Full Table only |
| [Timestamp](doc:timestamp) | Incremental only |
| [Timestamp timezone](doc:timestamp-timezone) | Incremental only |

12. Set **Column** to the aggregated metric value from your SELECT statement (the value the metric will track).
13. If your metric has *Incremental* query scope, set [**Timestamp**](doc:timestamp) to the timestamp in your **SELECT** statement. You may need to specify the [**Timestamp Timezone**](doc:timestamp-timezone) as well, depending on the timestamp format. If your timestamp's format includes the time zone, **Timestamp Timezone** is not editable and reads *Derived*.
14. If your SQL includes a GROUP BY clause on a non-timestamp column, select that column as your **Slice Column**.
15. Optionally:

* [Add seasonality](https://docs.lightup.ai/docs/seasonality)
* [Choose a missing value filling](doc:missing-value-filling)
* [Adjust the backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Add a failing records query](doc:failing-records-query)
* Add tags
* If your table has a date-based partition column, you can [optimize your query to query only the partitions](doc:partitions#use-partitions-to-optimize-an-sql-metric) where the data resides

## SQL examples

AthenaBigQueryDataBricksDremioGreenplumIncortaMS SQLMySQLOraclePostgresRedShiftSnowFlakeTeradata
```
SELECT
	date_trunc('hour', "timestamp") AS "event_ts",
	count(*) AS "cnt"
FROM
	"lightup_demo"."customer_orders_fact"
WHERE
	"timestamp" >= {start_ts}
	AND "timestamp" < {end_ts}
GROUP BY
	1
```
```
SELECT
	datetime_trunc(`Test_Time`, HOUR) AS `event_ts`,
	count(*) AS `cnt`
FROM
	`for_test_data_cache_v2.h06bbf7787854074cca66b9c8e3397593`
WHERE
	`Test_Time` >= {start_ts}
	AND `Test_Time` < {end_ts}
GROUP BY
	1
```
```
SELECT
	DATE_TRUNC('hour', `timestamp`) AS `event_ts`,
	count(*) AS `cnt`
FROM
	`lightup_demo`.`customer_orders_fact`
WHERE
	`datehour` >= {start_partition}
	AND `datehour` < {end_partition}
	AND `timestamp` >= {start_ts}
	AND `timestamp` < {end_ts}
GROUP BY
	1
```
```
SELECT
	"timestamp",
	AVG("order_value") AS "order_value"
FROM
	(
		SELECT
			DATE_TRUNC('hour', "timestamp") AS "timestamp",
			"order_value"
		FROM
			"lightup_redshift.testdb.producer"."customer_orders_fact"
		WHERE
			"timestamp" >= TO_TIMESTAMP(1696442400.0)
			AND "timestamp" < TO_TIMESTAMP(1696957200.0)
	) AS t
GROUP BY
	"timestamp"
ORDER BY
	"timestamp"
```
```
SELECT
	DATE_TRUNC('hour', `timestamp`) AS `event_ts`,
	count(*) AS `cnt`
FROM
	`lightup_demo`.`customer_orders_fact`
WHERE
	`datehour` >= {start_partition}
	AND `datehour` < {end_partition}
	AND `timestamp` >= {start_ts}
	AND `timestamp` < {end_ts}
GROUP BY
	1
```
```
SELECT
	date_trunc('hour', "timestamp") AS "event_ts",
	CAST(COUNT(*) AS INT) AS "cnt"
FROM
	"from_teradata"."customer_orders_fact"
WHERE
	"timestamp" >= {start_ts}
	AND "timestamp" < {end_ts}
GROUP BY
	1
```
```
SELECT
	"timestamp" AS "event_ts",
	count(*) AS "cnt"
FROM
	(
		SELECT
			dateadd(HOUR, datediff(HOUR, 0, "timestamp"), 0) AS "timestamp"
		FROM
			"testdata"."customer_orders_fact"
		WHERE
			"timestamp" >= {start_ts}
			AND "timestamp" < {end_ts}
	) AS t
GROUP BY
	"timestamp"
```
```
SELECT
	`timestamp`,
	MIN(`order_value`) AS `order_value`
FROM
	(
		SELECT
			UNIX_TIMESTAMP(
				CONVERT_TZ(
					DATE_FORMAT(
						CONVERT_TZ(`timestamp`, 'UTC', 'UTC'),
						'%Y-%m-%d %H:00:00'
					),
					'UTC',
					'UTC'
				)
			) AS `timestamp`,
			`order_value`
		FROM
			testdata.customer_orders_fact
		WHERE
			`timestamp` >= '2023-10-10 16:00:00.000000'
			AND `timestamp` < '2023-10-10 17:00:00.000000'
	) AS t
GROUP BY
	`timestamp`
ORDER BY
	`timestamp`
```
```
SELECT
	"timestamp" AS "event_ts",
	COUNT(*) AS "cnt"
FROM
	(
		SELECT
			ROUND(
				(
					CAST(
						SYS_EXTRACT_UTC(
							FROM_TZ(
								CAST(
									TRUNC("timestamp" AT TIME ZONE 'UTC', 'HH24') AS TIMESTAMP
								),
								'UTC'
							)
						) AS DATE
					) - DATE '1970-01-01'
				) * 86400
			) AS "timestamp"
		FROM
			"lightup_demo"."customer_orders_fact"
		WHERE
			"timestamp" >= {start_ts}
			AND "timestamp" < {end_ts}
	)
GROUP BY
	"timestamp"
```
```
SELECT
	date_trunc('hour', "timestamp") AS "event_ts",
	count(*) AS "cnt"
FROM
	"testdata"."customer_orders_fact"
WHERE
	"timestamp" >= {start_ts}
	AND "timestamp" < {end_ts}
GROUP BY
	1
```
```
SELECT
	date_trunc('hour', "timestamp") AS "event_ts",
	count(*) AS "cnt"
FROM
	"testdata"."rummy"
WHERE
	"timestamp" >= {start_ts}
	AND "timestamp" < {end_ts}
GROUP BY
	1
```
```
SELECT
	date_trunc('HOUR', "LAST_UPDATED_DATE") AS "event_ts",
	count(*) AS "cnt"
FROM
	"PUBLIC"."CT_US_COVID_TESTS"
WHERE
	"LAST_UPDATED_DATE" >= {start_ts}
	AND "LAST_UPDATED_DATE" < {end_ts}
GROUP BY
	1
```
```
SELECT
	"timestamp" AS "event_ts",
	COUNT(*) AS "cnt"
FROM
	(
		SELECT
			(
				(
					CAST(
						(
							CAST("timestamp" AS TIMESTAMP WITH TIME ZONE) AT TIME ZONE 'GMT'
						) AS DATE AT TIME ZONE 'GMT'
					) - DATE '1970-01-01'
				) * 86400 + (
					EXTRACT(
						HOUR
						FROM
							(
								CAST("timestamp" AS TIMESTAMP WITH TIME ZONE) AT TIME ZONE 'GMT'
							)
					) * 3600
				) + (
					EXTRACT(
						MINUTE
						FROM
							(
								CAST("timestamp" AS TIMESTAMP WITH TIME ZONE) AT TIME ZONE 'GMT'
							)
					) * 60
				) - (
					EXTRACT(
						MINUTE
						FROM
							(
								CAST("timestamp" AS TIMESTAMP WITH TIME ZONE) AT TIME ZONE 'GMT'
							)
					) * 60
				)
			) AS "timestamp"
		FROM
			"testdata"."customer_orders_fact"
		WHERE
			"timestamp" >= {start_ts}
			AND "timestamp" < {end_ts}
	) AS t
GROUP BY
	"timestamp"
```
# Preview

Once you have configured your metric you can preview it to view a live query without creating a datapoint. If the preview doesn't work the way you want, you can select the tab for a previous step and modify the configuration as needed.

1. On the **Step 3 (Preview)** tab, set the date range for the preview, then select **Preview**.
2. When you're happy with the result, select **Next** to continue.

You don't have to preview your metric— you can just click **Next** to proceed to Step 4 (Related metrics).

# Add Related metrics

You add related metrics at Step 4 of metric configuration. Related metrics always appear in the list of metrics available during incident analysis.

![](https://files.readme.io/d204fc4-related-metric.png)

* To add a related metric, select **Add +** and then choose a metric in the listbox that appears.
* Select **Show info** inside a related metric to display the metric's ID and data asset(s).
* When you've added the related metrics you want, select **Create** (for a new metric) or **Save**.
* During [incident analysis](doc:analyze-an-incident) of the metric, any related metrics appear in the metrics listed on the left. You can then easily add them to the Metrics of interest, making the metric chart available within the incident.

Updated 6 months ago

---

[Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)[String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
