---
title: "Review DQ in Alation"
slug: "review-dq-in-alation"
excerpt: "Alation is a Data Intelligence Platform that includes Data Catalog and Data Quality components to help you find the data you need and evaluate its fitness for your intended purposes. Lightup's Alation integration helps you understand your Alation data health at a glance, with links to perform deeper analysis on Lightup. If your workspace has an Alation integration set up, you can review DQ Health information about tables in supported datasources. For an introduction, see Alation's Help page, View Data Health."
hidden: false
metadata:
  title: "Review DQ in Alation"
  description: "Alation is a Data Intelligence Platform that includes Data Catalog and Data Quality components to help you find the data you need and evaluate its fitness for your intended purposes. Lightup's Alation integration helps you understand your Alation data health at a glance, with links to perform deeper…"
  url: "https://docs.lightup.ai/docs/review-dq-in-alation"
  image: ["https://cdn.readme.io/og-image/create?type=docs&title=Review%20DQ%20in%20Alation&projectTitle=Lightup%20Data%20User%20docs&description=Alation%20is%20a%20Data%20Intelligence%20Platform%20that%20includes%20Data%20Catalog%20and%20Data%20Quality%20components%20to%20help%20you%20find%20the%20data%20you%20need%20and%20evaluate%20its%20fitness%20for%20your%20intended%20purposes.%20Lightup's%20Alation%20integration%20helps%20you%20understand%20your%20Alation%20data%20health%20at%20a%20glance%2C%20with%20links%20to%20perform%20deeper%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light"]
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Review DQ in Alation

[Alation](https://www.alation.com/) is a Data Intelligence Platform that includes [Data Catalog](https://www.alation.com/product/data-catalog/) and [Data Quality](https://www.alation.com/product/data-quality/) components to help you find the data you need and evaluate its fitness for your intended purposes. Lightup's Alation integration helps you understand your Alation data health at a glance, with links to perform deeper analysis on Lightup. If your workspace has an Alation integration set up, you can review DQ Health information about tables in supported datasources. For an introduction, see Alation's Help page, [View Data Health](https://docs2.alationdata.com/en/latest/sources/WorkwithCatalogData/DataHealth.html#view-data-health).

In Alation, each Table page has tabs, several of which display data quality health information. In addition, the Table Trust Flag reflects the current health with a colored icon (red, yellow, green).

# Table **Health** tab

The **Health** tab shows the current data quality state of the Table and the related Columns. Lightup monitor information for these assets is visible in the Health tab's **Data Quality** section. Incidents generated by these monitors are highlighted in Alation with an appropriate color coded status, and a count of these incidents appears on the Health tab handle.

![](https://files.readme.io/94bee56-alation-health.png)
# Table **Overview** tab

Data health information appears on the Table **Overview** tab in the **Sample Columns** section:

![](https://files.readme.io/94b981b-alation-overview.png)
# Table **Columns** tab

Data health appears on the **Columns** tab in the **Health** column:

![](https://files.readme.io/b27adff-alation-columns.png)
# Table Trust Flag

The Table **Trust Flag** is a summary indicator of data health located just below the title, on the left:

![](https://files.readme.io/b6fa5e5-alation-table-trust.png)
# View Table Health

When you open a Lightup-integrated table in your Alation data catalog, corresponding incidents are listed in tabular format on the **Health** tab's **Data Quality** section.

* The **Rule** column has a link back to the relevant incident in Lightup, so you can perform deeper analysis there.
* Incident progress is indicated in the **Status** column— a red warning icon for ongoing incidents, and a yellow icon for completed incidents.
* Note that the **Health** tab label displays a count of ongoing incidents in red.

![](https://files.readme.io/b24bce0-alation-health-tab-selected.png)

For steps and more information, see Alation's [View Table Health](https://docs2.alationdata.com/en/latest/sources/WorkwithCatalogData/DataHealth.html#view-a-table-with-health-information).

# Interpret Alation Health information and take action

Monitors and incidents appear in Alation as messages: red deprecations, yellow warnings, and green endorsements.

These messages are based on the state (progress and status) of incidents generated in Lightup. When the incident progress or incident status changes in Lightup, that change is reflected by the related Alation message. The table below shows the mapping of Lightup incident state to Alation messages.

| Incident progress | Incident status | Alation Message |
| --- | --- | --- |
| Ongoing | Submitted | Deprecation |
|  | Viewed | Deprecation |
|  | Unviewed | Deprecation |
| Completed and still within incident window | Closed | Warning |
|  | Rejected | Warning |
|  | Submitted | Warning |
|  | Viewed | Warning |
|  | Unviewed | Warning |

These messages appear in three places in Alation.

* Incident progress and status are reflected by the message (warning or deprecation) for a table in your data catalog.
* Deprecations also appear in the [lineage](https://docs2.alationdata.com/en/latest/sources/Lineage/index.html#lineage) of assets in your catalog, so you can review them inline with other lineage information.
* Deprecations and warnings appear as popups when you run a query against the related asset while using [Compose](https://docs2.alationdata.com/en/latest/analyst/WriteQueries/ComposeToolbar.html).

# View messages in the data catalog

When you view a table in your Alation data catalog, if there are any Lightup incidents from the most recent incident window a message appears just below the title, next to the Trust Flag. The message color reflects the severity: a red deprecation for ongoing incidents, or a yellow warning for completed incidents.

![](https://files.readme.io/280d622-alation-message.png)
# Viewing incidents in a Lineage Diagram

When you select the **Lineage** tab in Alation, you can view related incidents for the asset.

![](https://files.readme.io/de8c20a-alation-lineage.png)

For help, see Alation's [Reading the Lineage Diagram](https://docs2.alationdata.com/en/latest/sources/Lineage/ReadLineageV2Diagram.html).

# Data health popups in Compose

When you run a query in Alation [Compose](https://docs2.alationdata.com/en/latest/analyst/WriteQueries/OpenQueriesinCompose.html), if there are ongoing incidents for a referenced asset a red deprecation titled **Don't Use This Table** appears and displays the associated message.

![](https://files.readme.io/c08d611-alation-compose-deprecation.png)

If there are incidents in the past, a yellow warning titled **Use with Caution** appears and displays the associated message.

![](https://files.readme.io/cff3d6f-alation-warning-compose.png)

Updated 6 months ago

---

[Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)[Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
