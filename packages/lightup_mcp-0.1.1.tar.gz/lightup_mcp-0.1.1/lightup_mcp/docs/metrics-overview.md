---
title: "Metrics overview"
slug: "metrics-overview"
excerpt: "Metrics are how you measure the quality of your data. Some metrics require no configuration— you can use them out of the box to gain fundamental insights about your data health. For the team that wants more customized data insights, Lightup supports a full spectrum of powerful metrics, from low-code template-driven metrics that answer common questions, to custom SQL metrics that answer questions specific to your business requirements."
hidden: false
metadata:
  title: "Metrics overview"
  description: "Lightup offers a range of metrics to measure data quality, from out-of-the-box options to customizable SQL metrics, covering column, comparison, table, and SQL-based metrics for comprehensive data insights."
  url: "https://docs.lightup.ai/docs/metric-overview"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Metrics%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=Lightup%20offers%20a%20range%20of%20metrics%20to%20measure%20data%20quality%2C%20from%20out-of-the-box%20options%20to%20customizable%20SQL%20metrics%2C%20covering%20column%2C%20comparison%2C%20table%2C%20and%20SQL-based%20metrics%20for%20comprehensive%20data%20insights.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Metrics overview

Metrics are how you measure the quality of your data. Some metrics require no configuration— you can use them out of the box to gain fundamental insights about your data health. For the team that wants more customized data insights, Lightup supports a full spectrum of powerful metrics, from low-code template-driven metrics that answer common questions, to custom SQL metrics that answer questions specific to your business requirements.

# Metric types

Lightup offers a full range of metrics, of four main types:

* [Column metrics](https://docs.lightup.ai/docs/metric-overview#column-metrics) answer questions about specific columns, and have the widest variety of configuration options.
* [Comparison metrics](https://docs.lightup.ai/docs/metric-overview#comparison-metrics) let you compare two tables (directly or through comparable metrics), helping you ensure ETL pipeline data quality.
* [Table metrics](https://docs.lightup.ai/docs/metric-overview#table-metrics) answer basic questions about your table's health, including low-cost metadata checks.
* [SQL metrics](https://docs.lightup.ai/docs/metric-overview#sql-metrics) let you answer arbitrary questions about your data by writing SQL.

See [Create and edit metrics](doc:create-and-edit-metrics) for details on how to create each type.

## Column metrics

### Aggregation

Calculate an aggregate function on a column's values for a set of rows

| Metric | Description | Data Type |
| --- | --- | --- |
| Avg | Returns the sum of values divided by number of rows. | Numeric |
| Count | Returns the count of values. | Any |
| Count Unique | Returns the count of distinct values. | Any (not recommended for ID columns) |
| Max | Returns the largest value. | Numeric |
| Median | Returns a number for which half of the values are smaller and half are larger. | Numeric |
| Min | Returns the smallest value. | Numeric |
| Percentile | Returns the value at or below which the specified fraction of values in its frequency distribution falls. | Numeric |
| St.Dev | Returns the standard deviation. | Numeric |
| Sum | Returns the sum of values. | Numeric |

### Conformity check

Calculate the percent of rows that conform to a condition

| Metric | Description | Data Type |
| --- | --- | --- |
| Contains/Does not contain string | Compares selected column's values with input string. | String |
| Equal/Not equal | Compares selected column's values with input. | Any |
| Greater than | Compares selected column's values with input number and matches if the column's value is greater. | Numeric |
| Greater than or equal to | Compares selected column's values with input number and matches if the column's value is greater. | Numeric |
| In/Not in | Compared selected column's values with an input set of values. | Any |
| In column/Not in column | Compares selected column's values with a second column's values. | Any |
| Is decreasing | Checks that column values are always decreasing. Returns 100% when current value is less than the previous value, and 0% when it is greater than or equal to the previous value. | Numeric |
| Is increasing | Checks that column values are always increasing. Returns 100% when current value is greater than the previous value, and 0% when it is less than or equal to the previous value. | Numeric |
| Is unique | Checks for unique values. | Any |
| Length equal to | Compares selected column's values with input number and matches if the length is equal. | String |
| Length greater than | Compares selected column's values with input number and matches if the length of the column value is greater. | String |
| Length greater than or equal to | Compares selected column's values with input number and matches if the length of the column value is equal or greater. | String |
| Length less than | Compares selected column's values with input number and matches if the length of the column value is smaller. | String |
| Length less than or equal to | Compares selected column's values with input number and matches if the length of the column value is equal or smaller. | String |
| Less than or equal to | Compares selected column's values with input number and matches if the column's value is greater. | Numeric |
| Match pattern/Does not match pattern | Compares selected column's values with input pattern. | String |
| Match regex/Does not match regex | Compares selected column's values with input regular expression. | Any |
| Null/Not null | Checks selected column's values for nulls. | Any |

### Distribution metrics

Calculate the distribution of a column's values

| Metric | Description | Data Type |
| --- | --- | --- |
| Categorical Distribution | Percentage of each unique value in a column | String |
| Numerical Distribution | Maximum, Minimum, Median, First Quartile, and Third Quartile | Numerical |

### Null Percent metrics

| Metric | Description |
| --- | --- |
| Null Percent | Measures the percentage of null values. |

## Comparison metrics

Calculate how much two similar objects match

| Metric | Description |
| --- | --- |
| Compare aggregate | Measures the degree to which two aggregate metrics match. |
| Row by Row | Measures the percentage of rows in two tables where the key columns match, and the values of attribute columns in those matching rows. |

## Table metrics

Measure characteristics of a table or its behavior

| Metric | Description | Supported datasources |
| --- | --- | --- |
| Data delay | Measures the time elapsed since the most recent data arrived. | All |
| Data volume | Measures the number of rows loaded. | All |
| Column activity | Columns added, altered (data type change), or dropped. | All |
| Update Delay | Time since the last data write. | BigQuery, Databricks, Incorta, MS-SQL, Redshift, Snowflake |
| Byte Count | The total number of bytes. | Databricks |
| Row Count | The total number of rows. | BigQuery, Incorta, MS-SQL, Oracle, Postgres, Redshift, Snowflake |

Note that Column activity, Update Delay, Byte Count and Row Count are metadata metrics.

## SQL metrics

SQL metrics support any valid SQL.

Updated 6 months ago

---

[Tables](https://docs.lightup.ai/docs/tables)[Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
