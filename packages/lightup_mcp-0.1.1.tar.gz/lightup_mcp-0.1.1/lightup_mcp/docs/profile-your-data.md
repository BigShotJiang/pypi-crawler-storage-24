---
title: "Profile your data"
slug: "profile-your-data"
excerpt: "To better understand your data and help enhance your data quality analysis, enable data profiling. Data profiling provides a static analysis of your tables that you can view in the Explorer tree. Data profiles are currently generated only for string, numeric, and time-oriented columns.  Other data types such as boolean will be absent from the results."
hidden: false
metadata:
  title: "Profile your data"
  description: "Enable data profiling in Explorer to analyze string, numeric, and time-oriented columns in your tables, helping you understand and improve data quality. Data profiles provide insights into table structure, timestamp analysis, sample data, and column-specific statistics, aiding in your data quality journey."
  url: "https://docs.lightup.ai/docs/set-up-data-profiling"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Data%20Profiling%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=Enable%20data%20profiling%20in%20Explorer%20to%20analyze%20string%2C%20numeric%2C%20and%20time-oriented%20columns%20in%20your%20tables%2C%20helping%20you%20understand%20and%20improve%20data%20quality.%20Data%20profiles%20provide%20insights%20into%20table%20structure%2C%20timestamp%20analysis%2C%20sample%20data%2C%20and%20column-specific%20statistics%2C%20aiding%20in%20your%20data%20quality%20journey.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Profile your data

To better understand your data and help enhance your data quality analysis, enable data profiling. Data profiling provides a static analysis of your tables that you can view in the Explorer tree. Data profiles are currently generated only for string, numeric, and time-oriented columns. Other data types such as boolean will be absent from the results.

You enable data profiling when you add data assets to Explorer. The initial data profile uses up to one million rows to create each table's data profile, as follows:

* For a table with under a million rows, the data profile covers the entire table.
* If Lightup can determine which timestamp column to use for time-range queries and the table has at least a million rows, the data profile covers the latest 30 days worth of data.
* If Lightup can't tell which timestamp column to use for time-range queries and the table has at least a million rows, the data profile covers one million randomly-selected rows.

If you aren't sure what types of data quality checks you want, we recommend you enable data profiling to learn about your data. Reviewing these data profiles will give you the info you need to proceed with your data quality journey.

# Enable data profiling

You enable data profiling in Explorer. You can enable the data profile for just one table, or you can enable all data profiles for the tables within a datasource or schema.

## Enable one table's data profile

1. Select a table in the Explorer tree.
2. On the **Data Profile** tab, select **Enable data profile**.

![](https://files.readme.io/b82a05a0a2f745781a2e82d0661b28778a2970ba6de41dbe5ea2e16622f22474-Screenshot_2024-10-03_at_5.30.34_PM.webp)
## Enable data profiling for all tables in a datasource or schema

When you add a datasource or a schema to the Explorer tree, you can then enable data profiling for all the tables within that datasource or schema. Note that enabling all data profiles for a datasource only affects tables inside of its active schemas.

1. Select the datasource or schema in the Explorer tree.
2. On the **Summary** tab, under **Enable all data profiles**, select **Enable all**.

# Pattern detection during column profiling

Lightup uses pattern detection to determine the contents of table columns. In addition to timestamps, Lightup detects UUIDs, phone numbers, e-mail addresses, US ZIP codes, SSNs, and URLs. You can hover over the label **Patterns Detected** on a column profile for a quick reminder.

# Review data profiles

After data profiles are generated, you can review them to help you plan your data quality analysis. For example, reviewing a table's profile will clarify which columns can be used for timestamps in metrics.

When you select a table in the Explorer tree, its **Data Profile** tab displays the table's current data profile:

![](https://files.readme.io/f8b283d6b0d675bdd3a21e97f193d3aa65662fb9d9ad5d7378b9dc6ee6ea26b4-Screenshot_2024-10-03_at_5.31.33_PM.webp)

Each data profile is laid out in sections: Data profile, Table Schema, Timestamp Analysis, Sample Data, and profiled columns (section not labeled).

## Data profile

The Data profile provides a list of basic facts about the table, as well as when the profile was generated.

You can also generate a new profile, replacing the current one. Only one data profile can exist for a table— there's no way to save a copy of or export a data profile.

### Generate a new profile

1. In the profile, next to **Data profile** select **Configure**. A subform appears just above the table summary.
2. Select a **Mode**:
   * **Full Table** - Use the entire table to create the data profile.
   * **Random Sample** - Use one million randomly-selected rows to create the data profile.
   * **Time Range** - Specify a period of time and a timestamp column, then use all rows having timestamps within that period to create the data profile.
3. Select **Update** to generate the new profile.

## Table Schema

The Table Schema section displays a list of the table's columns. For each column, it lists the column name, data type, and any detected metadata (currently, *is\_Indexed* and *is\_PartitionKey* are detected).

## Timestamp Analysis

The Timestamp Analysis displays a chart showing the row count (y-axis) associated with each timestamp value on the x-axis. You can hover over a timestamp value on the chart to see more details.

Below the chart is the timestamp data delay, which is the profile collection time minus the maximum timestamp value in the profiled data.

## Sample Data

Five rows of sample data are displayed to help you understand the table's contents. Data for all columns is included— you might need to scroll right to review them all.

## Profiled columns

Profiles for the table's timestamp, string, and numeric columns are displayed below the Sample Data, in the order they appear in the table. Columns with other data types are not profiled. Each column profile includes statistics about the column's data based on its data type. In addition, if Lightup [detects a pattern](https://docs.lightup.ai/docs/set-up-data-profiling#pattern-detection-during-column-profiling) in a string column, that pattern is noted in the column's profile. Note that more than one pattern might be detected— all detected patterns are listed in the profile.

To select specific profiled columns to display, click **Select column name** and then choose columns from the list that appears.

![](https://files.readme.io/04c70d9-profiled-columns.png)
### Column profile information

All column profiles display percentages of **Valid** and **Invalid** column values. Valid values are further broken down into **Unique** and **Nonunique** percentages. The only Invalid values are nulls (absent data), so **Null** is equal to **Invalid**. The sum of Valid and Invalid is always *100%*.

* ***Numeric column profiles*** display the **Min**, **Lower quartile (Q1)**, **Median**, **Mean**, **Upper quartile (Q3)**, and **Max** values (standard statistics that describe the distribution of values), a graph , as well as the percentages of column values that are **Zero %**, **Positive %**, **Negative %**, and **Nan%** (not a number). Below these statistics is a value-distribution chart for the column.
* ***String column profiles*** display the **Max string length**, **Min string length**, and **Mean string length**, as well as the **Zero Length Count** (the count of column values having zero length strings), any [**Patterns Detected**](https://docs.lightup.ai/docs/set-up-data-profiling#pattern-detection-during-column-profiling), and the **# of Distinct Values** (i.e., COUNT DISTINCT). Although there is no limit on the number of distinct values in a column profile, if there are fewer than 50 distinct values a chart displays the distribution of the top 20 values.
* ***Timestamp column profiles*** display the **Mean Interval** (the average time elapsed between two consecutive timestamps), **Min Interval** (the smallest amount of time elapsed between two consecutive timestamps), and **Max Interval** (the largest amount of time elapsed between two consecutive timestamps), the **Min Timestamp**, the **Max Timestamp**, and the **Future Date %** (the percent of values where the date is in the future). Below these statistics is a chart of recent timestamps— you can hover on the chart to see details.

Updated 6 months ago

---

[Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)[Column Masking](https://docs.lightup.ai/docs/column-masking)
