---
title: "Analyze an incident"
slug: "analyze-an-incident"
excerpt: "You can analyze an incident to understand the data quality issue behind it. Your analysis can (and often will) include other metrics and incidents that are relevant in some way— through time correlation, for example, or through sharing a metric."
hidden: false
metadata:
  title: "Analyze an incident"
  description: "The document outlines how to analyze data quality incidents using Lightup, including adding comments, submitting tickets, and incorporating related metrics. It also details how to manage incident information, validate fixes, and manually end incidents."
  url: "https://docs.lightup.ai/docs/analyze-an-incident"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Analyze%20an%20Incident%20in%20Lightup&projectTitle=Lightup%20Data%20User%20docs&description=The%20document%20outlines%20how%20to%20analyze%20data%20quality%20incidents%20using%20Lightup%2C%20including%20adding%20comments%2C%20submitting%20tickets%2C%20and%20incorporating%20related%20metrics.%20It%20also%20details%20how%20to%20manage%20incident%20information%2C%20validate%20fixes%2C%20and%20manually%20end%20incidents.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Analyze an incident

You can analyze an incident to understand the data quality issue behind it. Your analysis can (and often will) include other metrics and incidents that are relevant in some way— through time correlation, for example, or through sharing a metric.

* Lightup automatically identifies time-correlated incidents that you could include in your analysis.
* You can search for other metrics and add them to your analysis.
* You can add [related metrics](doc:related-metrics) during metric configuration— these become **Related Metrics** for incidents that come from the metric.

![](https://files.readme.io/678d8a2e853e96099692be7f9f19a0e1f72d6d76a1f59eace7fc27a78fb02a51-Screenshot_2024-10-04_at_12.03.06_AM.webp)
# Add a comment

You can add comments as part of analyzing an incidents. Comments appear on the incident's Activity tab.

1. On the incident details page, select the incident's menu, then choose **Add Comment**.

   ![](https://files.readme.io/fa335c0-add-comment.png)
2. Enter your comment, then select **Submit**. The **Activity** tab appears and displays your comment in chronological order.

## Edit or delete a comment

If you have sufficient permissions, you can edit and delete comments.

1. On the incident's **Activity** tab, select the comment.
2. On the right, select the **Edit** icon or the **Delete** icon.

# Submit a ticket

If your workspace has a suitable integration set up, you can submit a ticket to track the work associated with analyzing the incident.

1. On the incident details page, select the incident's menu, then choose **Submit Ticket**.

   ![](https://files.readme.io/28aa7c2-submit-ticket.png)
2. On the **Submit ticket** form, select a value for **Integration**. The form options change to reflect the integration you chose.
3. Verify or fill out the remaining fields, then at the top select **Submit**.

# Add metrics of interest

The collapsible left panel (which is closed when you first open the incident) lists groups of metrics that you can include in your analysis.

* **Metrics of interest** are metrics that you have chosen to compare with the incident. The charts for these metrics appear below the incident chart. You can select a metric of interest to open it in Explorer, hide its chart in the incident details, or remove it from **Metrics of interest**.
* **Related metrics** - You can add related metrics to a metric when you configure it (in Step 4 of metric configuration). Related metrics then appear in analysis of any incident from the metric. You can select a related metric to open it in Explorer or add it to **Metrics of interest**.
* **Time-correlated** - These are metrics that have incidents that occurred around the same time as the one you're analyzing. You can select a time-correlated metric to open it in Explorer or add it to **Metrics of interest**.
* You can hover over a metric's icon (just left of its name) in the panel to get more information.
* Sliced metrics show the count of slices with incidents and the total number of slices. You can expand a sliced metric to review the slices.

![](https://files.readme.io/62f001b-incident-metrics.png)
## Find a metric

1. At the top of the left panel, select **Actions > Find a metric**.
2. In the **Find any metric** pane, click **Search metric name** and then enter a search term. Matching items appear as you type.
3. When you find a metric you want to include, click **Add**. The chart for the selected metric appears on the **Charts** tab, below the incident chart.

# Incident analysis

Information about the incident is on four tabs:

* The **Chart** tab shows the incident chart at the top, and any metrics of interest you add.
* The **Summary** tab is a repository of information about the incident, with links to related components.
* The **Failing Records** tab shows the result of the failing records query associated with the metric. If no failing records query is present, the tab does not appear. If the query governance flag **Enable failing records count cache** is enabled, then failing records count are fetched and cached automatically when an incident is created. If that governance flag is enabled, and the incident is ongoing (has not ended) in subsequent metric collections, the failing records count is updated with the new count of failing records
* The **Activity** tab lists actions that have been taken that affect the incident.

## Chart

On the Chart tab, you can set a timeframe to include more data points in the displayed charts. The first chart is the incident chart. The charts for any metrics of interest you add appear below the incident chart. Within a chart, you can turn on threshold data to help you visualize how the metric deviated. On the chart for the incident, you can set the incident's Status.

### Set a timeframe

On the right just above the charts, click the dates to change them. You must confirm both dates even if you only change one (i.e., click **OK** twice).

### Turn on threshold data

You can view threshold data for the incident chart and for the metrics of interest charts you add. When you add the chart for a metric of interest that has multiple monitors, you must choose a monitor to turn on threshold data.

* Incident chart/Metric of interest chart with one monitor: In the chart where you want to see thresholds, on the metric's menu select **View Threshold**.
* Metric of interest chart with multiple monitors: In the chart, on the Monitors menu select a monitor, and then select **View This Monitor**. Threshold data will display on the chart when you choose a monitor. To hide it, on the same menu, select **Hide Threshold**.

### Hide or remove a metric of Interest

If you no longer want to see the chart for a metric of interest on the Chart tab, you can hide it (if you plan to display the chart again); or, you can remove the metric from the Metrics of Interest list (if you no longer want the chart to be available on the Chart tab).

* Hide: On the chart's **Actions** menu, select **Hide**.
* Remove: In the left panel, select the metric. Then on the panel's **Actions** menu select **Remove From Metrics Of Interest**.

### Set the incident Status

You can change the status of an incident to manage how it is handled. Most incident statuses don't affect how Lightup behaves, but you can use them to sort or filter the incidents you see. However, incidents with *Rejected* status don't show up in Explorer views.

## Summary

The Summary tab is organized into four columns: Incident Info, Metric Info, Monitor Info, and Data Asset Info. Select the **Metric Name** to edit the metric or to view it in Explorer. Select the **Monitor Name** to edit the monitor.

![](https://files.readme.io/7c3a8c4-small-incident-summary.png)
## Failing Records

A [failing records query](https://docs.lightup.ai/docs/failing-records-query) is a query you can use to select the records to analyze as part of the incident. If the incident's metric has a failing records query, you can review it on the **Failing Records** tab. [Null percent](doc:null-percent-metrics) and [Conformity](doc:conformity-metrics) metrics have default failing records queries, and you can create your own for any metric.

### Review the failing records query

1. In the incident, select the **Failings Records** tab.
2. At the top of the **Failing Records** tab the SQL for the query appears in a text box.

   ![](https://files.readme.io/f8b43ae-failing-records-tab.png)
3. By default, the query returns 100 rows. Just below the SQL box, you can enter a different value for **LIMIT** to return that many rows instead.
4. Select **Run Query** to see the results— the "failing records". These appear in a paginated list below the SQL box.
5. Click **Download** to download the results in .CSV format.
6. You also see a record of the count of failed rows.

   1. Note that when an incident is generated, the count of rows will have to be manually fetched using the "Get count" button when the Query governance flag "Enable failing records count cache" is disabled (default).
   2. When the "Enable failing records count cache" is enabled, the count of failed records is automatically generated (only for incidents that are newly generated after the flag has been enabled), and is updated if the incident is ongoing (hasn't ended yet), on subsequent metric collections.

## Activity

Activities taken on the incident are listed on the Activity tab. This helps you coordinate your analysis with your colleagues. If an activity was done by a person, their email address is included in its list item.

The following activities are listed:

* Incident started
* Incident ended
* Validation started
* Validation resolved
* Validation unresolved
* Validation error
* Someone adds a comment
* Someone submits a ticket (e.g., creates a task in Jira to track the incident)
* Someone changes the Status, such as by viewing an *Unviewed* incident

### Edit or delete comments

Comments listed on the Activity tab have the prefix ***Comment:***. If you have the right role, you can edit or delete a comment by using the icons to its right.

![](https://files.readme.io/d7ac9c9-comment-activity.png)
# Validate an incident fix

Validation is currently not supported for column activity metrics, compare aggregate metrics, data delay metrics, row by row compare metrics and table activity metrics

After you review an incident and take actions to correct the data quality issue, you can validate that your fix addresses the incident— that the data quality issue is resolved.

1. On the incident chart, select **Run validation**. Lightup begins checking to see whether the data quality incident is fixed, and the button text changes to **Running validation...**.
2. To cancel, select **... → Cancel validation**.
3. After validation finishes running, the button text changes again to reflect the outcome:
   * **Resolved** if the issue is fixed
   * **Unresolved** if the issue is still present
4. If validation indicates the incident is resolved, consider changing the incident status to **Closed**.

# End an incident

By default, an incident's Progress field will remain 'Active' until a sufficient number of metric datapoints are collected (according to the monitor's recovery duration) to return within the spec of the monitor threshold. If you desire to end an incident manually (and force a new incident to get created on the next collection cycle), you may do so using the 'End incident' action available in the incident menu. This will be captured in the activity log and the Progress will update to 'Completed' on the next data collection cycle.

Updated 6 months ago

---

[Manage incidents](https://docs.lightup.ai/docs/manage-incidents)[Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
