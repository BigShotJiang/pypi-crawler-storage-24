---
title: "Lightup Hybrid"
slug: "lightup-hybrid"
excerpt: "If you prefer to host Lightup in your own environment, Lightup Hybrid can be deployed to a dedicated VM or to an existing Kubernetes cluster (self-managed or cloud-managed)."
hidden: false
metadata:
  title: "Lightup Hybrid"
  description: "If you prefer to host Lightup in your own environment, Lightup Hybrid can be deployed to a dedicated VM or to an existing Kubernetes cluster (self-managed or cloud-managed).
Lightup Hybrid deployment keeps all data-oriented processes, such as metric collection, monitor training, integrations, and al…"
  url: "https://docs.lightup.ai/docs/lightup-hybrid-prereqs"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Lightup%20Hybrid&projectTitle=Lightup%20Data%20User%20docs&description=If%20you%20prefer%20to%20host%20Lightup%20in%20your%20own%20environment%2C%20Lightup%20Hybrid%20can%20be%20deployed%20to%20a%20dedicated%20VM%20or%20to%20an%20existing%20Kubernetes%20cluster%20(self-managed%20or%20cloud-managed).%0ALightup%20Hybrid%20deployment%20keeps%20all%20data-oriented%20processes%2C%20such%20as%20metric%20collection%2C%20monitor%20training%2C%20integrations%2C%20and%20al%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Lightup Hybrid

If you prefer to host Lightup in your own environment, Lightup Hybrid can be deployed to a dedicated VM or to an existing Kubernetes cluster (self-managed or cloud-managed).

[Lightup Hybrid deployment](https://docs.lightup.ai/docs/deployment-models#hybrid-deployment) keeps all data-oriented processes, such as metric collection, monitor training, integrations, and alerting, within your environment.

This page provides prerequisites to help you prepare for Lightup deployment. Please [support@lightup.ai](mailto:support@lightup.ai) to arrange for actual deployment.

# Prerequisites

## Outbound connectivity

Your system instance must always have access to the following internet services for the proper functioning of Lightup. You should modify your firewall rules if you cannot access any of these services.

| Service | Domains to whitelist |
| --- | --- |
| Linux package repositories (apt/yum repositories): For support packages needed on the VM host environment. | One of the following, depending on which Linux version you install:   * \*.fedoraproject.org (yum/dnf Repositories— enables RHEL/Fedora System Update Packages) * \*.ubuntu.com (apt Repositories— enables Ubuntu System Update Packages) |
| Replicated (replicated.com): Lightup application software is packaged and licensed using Replicated. The application bundle (Kubernetes binaries, Docker containers, license file) are pulled from Replicated during the installation sequence and subsequent upgrades. | - \*.replicated.com (enables Upstream Docker images via proxy.replicated.com. The on-prem docker client uses a license ID to authenticate to proxy.replicated.com. This domain is owned by Replicated, Inc., headquartered in Los Angeles, CA.)   * quay.io (source of replicated images for releases) * \*.gcr.io (source of replicated images for releases) * \*.docker.io (source of replicated images for releases) * k8s.kurl.sh (source of Kubernetes cluster installation scripts and artifacts: an application identifier is sent in a URL path, and bash scripts and binary executables are served from kurl.sh. This domain is owned by Replicated, Inc., headquartered in Los Angeles, CA) * amazonaws.com (source of tar.gz: packages are downloaded from Amazon S3. The IP ranges to whitelist for accessing these can be scraped dynamically from the AWS IP Address Ranges documentation.) |
| Datadog: Lightup uses Datadog for container logging, metric monitoring and Kubernetes pod health monitoring | * .datadoghq.com (enables Lightup monitoring) |
| Lightup AWS Services: Lightup leverages a dedicated single-tenant service for install and upgrade requirements. | * .lightup.ai (enables Lightup system updates and calls) |
| Auth0: Lightup uses Auth0 for best-in-class authentication, as well as integration with any SSO provider | * auth0.com (enables authentication) |

## Deployment environment

Note: Once the Lightup deployment is complete, you should not change the VM hostname, otherwise it could impact the proper functioning of Lightup

| Deployment target | Supported versions | Minimum hardware resources |
| --- | --- | --- |
| New Linux VM | Ubuntu 20.04 or RHEL8 | 8 vCPUs, 64GB RAM, and 200GB of persistent, flat, unpartitioned hard disk capacity (EBS or similar) |
| Existing k8s cluster | Kubernetes 1.24 through 1.28 | Each node: 4 vCPUs / 32 GB RAM Whole cluster: 8 vCPUs / 64GB RAM |

### Cloud-Managed Kubernetes (EKS, AKS, GKE)

If you’re using AWS EKS for your Kubernetes cluster, make sure that the following add-ons or equivalent have been installed:

* [Amazon VPC CNI](https://docs.aws.amazon.com/eks/latest/userguide/managing-vpc-cni.html) or equivalent
* [CoreDNS](https://docs.aws.amazon.com/eks/latest/userguide/managing-coredns.html)
* [kube-proxy](https://docs.aws.amazon.com/eks/latest/userguide/managing-kube-proxy.html)
* [Amazon EBS CSI](https://docs.aws.amazon.com/eks/latest/userguide/managing-ebs-csi.html) or equivalent

## Postgres Server 14

1. [Install Postgres Server 14](https://www.postgresql.org/download/) with the following resources:
   * 4 CPUs
   * 8 GB memory
   * 200 GB storage
   * 2000 IOPS
2. Set up daily backups.
3. When your Postgres instance is ready, log in and complete the following steps:

   a. Make note of the **Postgres host**, **TCP port**, **username** and **password** - you'll need them during the next installation step (when you bootstrap the Lightup data plane).

   b. Create three databases: *adb*, *sdb*, and *udb*.

   c. In each database, set *max\_connection* >= *500* and run the following code:

SQL
```
CREATE EXTENSION IF NOT EXISTS pg_stat_statements;
SELECT * FROM pg_stat_statements LIMIT 1;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
SELECT uuid_generate_v4();
```
## Set up a NAT gateway

If the Lightup application needs to use a singular, consistent IP address to access your datasources, you can configure a NAT gateway for your VM on any of the following platforms:

* [AWS](https://docs.aws.amazon.com/vpc/latest/userguide/vpc-nat-gateway.html)
* [GCP](https://cloud.google.com/nat/docs/overview)
* [Azure](https://learn.microsoft.com/en-us/azure/virtual-network/nat-gateway/nat-gateway-resource)

## Custom Lightup Access Point

Lightup exposes a NodePort on port 30443 that you can use to access the Lightup UI.

If the nodes in your kubernetes cluster have public IP addresses, then you can access the UI at `https\://<ip-address-or-host-name-of-your-VM>:30443`. If the nodes do not have a public IP address or if you want to configure a URL, you can use a Load Balancer to access the UI. Lightup only works with supported domains, so you'll need to provide Lightup support with your IP address / hostname / URL.

The following example shows how you'd access the Lightup UI at `https://lightup.my-company.com` using a Network Load Balancer in AWS:

1. Create a certificate for `lightup.my-company.com` with AWS Certificate Manager (ACM).
2. Verify the certificate with the option to create records in Route 53.
3. Copy the certificate ARN— you'll need this for the following step.
4. Update the following manifest for the Kubernetes service that will generate the NLB, and save it as a file named *lightup-nlb-service.yaml*:

   YAML
   ```
    apiVersion: v1
      kind: Service
      metadata:
        name: lightup-backend
        annotations:
          external-dns.alpha.kubernetes.io/hostname: lightup.my-company.com
          service.beta.kubernetes.io/aws-load-balancer-ssl-cert: YOUR_COPIED_CERTIFICATE_ARN
          service.beta.kubernetes.io/aws-load-balancer-ssl-negotiation-policy: ELBSecurityPolicy-FS-1-2-Res-2020-10
          service.beta.kubernetes.io/aws-load-balancer-type: nlb
        labels:
          app: backend
      spec:
        externalTrafficPolicy: Local
        loadBalancerSourceRanges:
   	 - 0.0.0.0/0
     ports:
      - name: backend
         port: 443
         protocol: TCP
         targetPort: 8000
     selector:
       app: backend
       release: backend
     type: LoadBalancer
   ```
5. Deploy the NLB using kubectl and the YAML file you saved:

   `kubectl apply -n lightup -f lightup-nlb-service.yaml`
6. Copy the generated NLB's URL.
7. Create a new Route 53 A record for `lightup.my-company.com` to route to the NLB's URL.

Updated 6 months ago

---

[Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)[Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
