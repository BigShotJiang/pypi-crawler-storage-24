---
title: "Tables"
slug: "tables"
excerpt: "Tables are at the center of your data asset hierarchy. When you select a table in the Explorer tree, tabs appear that let you focus on different aspects of the table's data quality."
hidden: false
metadata:
  title: "Tables"
  description: "The document outlines the various tabs available when selecting a table in the Explorer tree, including Table Health, Data Profile, Auto Metrics, Configuration, and Manage Columns, each providing different functionalities for monitoring and managing table data quality and metrics."
  url: "https://docs.lightup.ai/docs/tables"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Table%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=The%20document%20outlines%20the%20various%20tabs%20available%20when%20selecting%20a%20table%20in%20the%20Explorer%20tree%2C%20including%20Table%20Health%2C%20Data%20Profile%2C%20Auto%20Metrics%2C%20Configuration%2C%20and%20Manage%20Columns%2C%20each%20providing%20different%20functionalities%20for%20monitoring%20and%20managing%20table%20data%20quality%20and%20metrics.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Tables

Tables are at the center of your data asset hierarchy. When you select a table in the Explorer tree, [tabs](doc:explorer-overview#explorer-tabs) appear that let you focus on different aspects of the table's data quality.

# Table Health tab

When you select a table, the Table Health tab provides an overview of the table’s metrics and data. If no metrics are set up yet, you can enable auto metrics using controls on this tab.

![](https://files.readme.io/08ce4bbd3fa0edd593b98e3af43a6e8757f41dffc1b91502b5e20453fa84e87b-Screenshot_2024-10-03_at_4.35.49_PM.webp)
## Summary section

If the table has any monitored metrics, the Summary section of the Table Health tab provides a visual indicator of their overall status for the most recent completed day: a **% Healthy** score, a green bar indicating healthy metrics and a red bar indicating unhealthy metrics (metrics with incidents), plus the percent of monitored metrics that are healthy. Only working metrics with live monitors affect this summary.

Below the horizontal bars, vertical bars indicate the summary for each day of the past week— the last bar corresponds to the most recent completed day. You can click a bar to select that day, setting the scope for the remaining sections. Note that the dates are displayed in your local time zone, while internally these values are in UTC.

## Table Level Metrics section

The status of each of the table's metrics is indicated by a square at the top of the Table Level Metrics section: green squares for monitored metrics with no incidents, red squares for metrics with incidents, and gray squares for metrics that aren't producing health information— either the metric has an error or it doesn't have a live monitor. The status is as of the date currently selected in the Summary section (by default the most recent completed day). You can hover on a metric's square to see status details.

Below the squares, these metrics are also listed, with the number of monitors and incidents shown for each. You can click a square to focus on the corresponding metric in this section.

Auto metrics are listed even if they aren't enabled yet, and you can configure the table and enable its auto metrics from this section. User defined metrics appear in a section below the table's auto metrics.

## Column Health section

Any columns that are configured appear in the Column Health section. If no columns are configured yet, there's a button you can click to start the configuration process. Each of the configured columns is represented by a square: green if the column has monitored metrics with no incidents, red if there are incidents, and gray if there are no monitored metrics. As with tables, the status is for the currently selected day in the Summary section. You can hover over a square to see how many metrics are set up for the corresponding column.

## Table Info section

General information about the table appears in the Table Info section.

## Data Profile section

If a data profile exists for the table, the profile appears in the Data Profile section. If not, a button that lets you set up the data profile appears instead.

# Data Profile tab

On the Data Profile tab, you can enable the table's data profile, and you can review or update the data profile if it's already enabled.

![](https://files.readme.io/e4d65a35ceeba6d60d6b54649d7764b8c31669dcfdd7f7ee37c6ad295dff30c9-Screenshot_2024-10-03_at_4.36.54_PM.webp)
# Auto Metrics tab

On the Auto Metrics tab, you can enable and monitor the table's auto metrics. You can also configure the table to enable deep auto metrics. Note that metadata metrics don't have history, so after you enable them you'll want to let them run long enough to generate sufficient datapoints before you add and train any monitors.

![](https://files.readme.io/3095807a2d5603c0c6818e5fb493147a4b50cbc522c26c2059b5e17a33cb9681-Screenshot_2024-10-03_at_4.37.37_PM.webp)
# Configuration tab

On the Configuration tab, you can review and (if you have sufficient permissions) edit the table's configuration.

![](https://files.readme.io/8a59b4dbbe948cd56d510eb8af15bb4d6e74d7da54290019c3d032fc73ffaeb2-Screenshot_2024-10-03_at_4.38.39_PM.webp)
# Manage Columns tab

On the Manage Columns tab, you can activate the table's columns and then enable their auto metrics.

![](https://files.readme.io/1a6854dd1df7f66a70ddd2300f2ed0cb43ca0ae9ade74e35594064a60872a355-Screenshot_2024-10-03_at_4.39.18_PM.webp)

Updated 6 months ago

---

[Schemas](https://docs.lightup.ai/docs/schemas)[Metrics overview](https://docs.lightup.ai/docs/metric-overview)
