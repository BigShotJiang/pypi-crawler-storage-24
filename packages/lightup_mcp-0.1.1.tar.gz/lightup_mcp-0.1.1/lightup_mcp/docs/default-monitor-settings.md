---
title: "Default monitor settings"
slug: "default-monitor-settings"
excerpt: "When you add an anomaly detection monitor from Explorer without manually editing the monitor, the monitor uses default settings based on the metric type. Note that Compare metrics (Compare aggregates, Row by row) only support manual thresholds, which do not have defaults. Also note that default training periods depend on whether the metric has seasonality."
hidden: false
metadata:
  title: "Default monitor settings"
  description: "When you add an anomaly detection monitor from Explorer without manually editing the monitor, the monitor uses default settings based on the metric type. Note that Compare metrics (Compare aggregates, Row by row) only support manual thresholds, which do not have defaults. Also note that default trai…"
  url: "https://docs.lightup.ai/docs/default-monitor-settings"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Default%20monitor%20settings&projectTitle=Lightup%20Data%20User%20docs&description=When%20you%20add%20an%20anomaly%20detection%20monitor%20from%20Explorer%20without%20manually%20editing%20the%20monitor%2C%20the%20monitor%20uses%20default%20settings%20based%20on%20the%20metric%20type.%20Note%20that%20Compare%20metrics%20(Compare%20aggregates%2C%20Row%20by%20row)%20only%20support%20manual%20thresholds%2C%20which%20do%20not%20have%20defaults.%20Also%20note%20that%20default%20trai%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Default monitor settings

When you add an anomaly detection monitor from Explorer without manually editing the monitor, the monitor uses default settings based on the metric type. Note that Compare metrics (Compare aggregates, Row by row) only support manual thresholds, which do not have defaults. Also note that default training periods depend on whether the metric has seasonality.

# Aggregation metric

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Value |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Disabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval or Polling Interval:   * If the interval is *Hourly* or shorter, training period is one week * If the interval is *Daily*, training period is 30 days * If the interval is *Weekly*, training period is 120 days * If the interval is *Monthly* or longer, training period is 15 intervals |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval or Polling Interval |
| Aggressiveness | 1 |
| Drift direction | Both |
| Incident learning | Enabled |

# Conformity metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Value |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Disabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval or Polling Interval:   * If the interval is *Hourly* or shorter, training period is one week * If the interval is *Daily*, training period is 30 days * If the interval is *Weekly*, training period is 120 days * If the interval is *Monthly* or longer, training period is 15 intervals |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval or Polling Interval |
| Aggressiveness | 1 |
| Drift direction | Both |
| Incident learning | Enabled |

# Custom SQL metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Value |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Disabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval or Polling Interval:   * If the interval is *Hourly* or shorter, training period is one week * If the interval is *Daily*, training period is 30 days * If the interval is *Weekly*, training period is 120 days * If the interval is *Monthly* or longer, training period is 15 intervals |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval or Polling Interval |
| Aggressiveness | 1 |
| Drift direction | Both |
| Incident learning | Enabled |

# Data delay metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Value |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Disabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training period includes the data collection window one week before the most recent window. |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | 1h (one hour) |
| Aggressiveness | 5 |
| Drift direction | Up |
| Incident learning | Enabled |

# Data volume metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Percentage change |
| Compare against | Last sample |
| Bounds | tolerance interval |
| Account for trend | Enabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval or Polling Interval:   * If the interval is *Hourly* or shorter, training period is one week * If the interval is *Daily*, training period is 30 days * If the interval is *Weekly*, training period is 120 days * If the interval is *Monthly* or longer, training period is 15 intervals |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods plus one aggregation/polling interval into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval or Polling Interval |
| Aggressiveness | 7 |
| Drift direction | Down |
| Incident learning | Enabled |

# Distribution metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Value |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Disabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval or Polling Interval:   * If the interval is *Hourly* or shorter, training period is one week * If the interval is *Daily*, training period is 30 days * If the interval is *Weekly*, training period is 120 days * If the interval is *Monthly* or longer, training period is 15 intervals |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval or Polling Interval |
| Aggressiveness | 1 |
| Drift direction | Both |
| Incident learning | Enabled |

# Null percent metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Value |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Disabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval or Polling Interval:   * If the interval is *Hourly* or shorter, training period is one week * If the interval is *Daily*, training period is 30 days * If the interval is *Weekly*, training period is 120 days * If the interval is *Monthly* or longer, training period is 15 intervals |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval or Polling Interval |
| Aggressiveness | 1 |
| Drift direction | Both |
| Incident learning | Enabled |

# Row count/Byte count metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Percentage change |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Enabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval:   * If Aggregation Interval is *Hourly* or shorter, training period is one week plus one aggregation interval * If Aggregation Interval is *Daily*, training period is 31 days * If Aggregation Interval is *Weekly*, training period is 127 days * If Aggregation Interval is *Monthly* or longer, training period is 16 aggregation intervals |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods plus one aggregation interval into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval |
| Aggressiveness | 7 |
| Drift direction | Down |
| Incident learning | Enabled |

# Update delay metrics

| Option | Default setting |
| --- | --- |
| Symptom to detect | Value out of Expectations |
| Feature | Value |
| Compare against | N/A |
| Bounds | tolerance interval |
| Account for trend | Disabled |
| Forecasting | Disabled |
| Training period (no seasonality) | Default training periods include the most recent data collection, and extend into the past based on the metric's Aggregation Interval:   * If Aggregation Interval is *Hourly* or shorter, training period is one week * If Aggregation Interval is *Daily*, training period is 30 days * If Aggregation Interval is *Weekly*, training period is 120 days * If Aggregation Interval is *Monthly* or longer, training period is 15 \* Aggregation Interval |
| Training period (seasonal) | Default training period includes the most recent data collection, and extends 15 season periods into the past. |
| Drift duration | 0s (zero seconds) |
| Recovery duration | Equal to the Aggregation Interval |
| Aggressiveness | 5 |
| Drift direction | Up |
| Incident learning | Enabled |

Updated 6 months ago

---

[Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)[Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
