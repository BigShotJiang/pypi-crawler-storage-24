---
title: "Row by row metrics"
slug: "row-by-row-metrics"
excerpt: "Row by row metrics let you measure data value differences between a source table and a target table."
hidden: false
metadata:
  title: "Row by row metrics"
  description: "Row by row metrics let you measure data value differences between a source table and a target table.
Note: Backfill is not configurable for row by row metrics.The system chooses a backfill duration based on aggregation interval for incremental full compare metrics.
Create a row by row metric


In th…"
  url: "https://docs.lightup.ai/docs/row-by-row-metrics"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Row%20by%20row%20metrics&projectTitle=Lightup%20Data%20User%20docs&description=Row%20by%20row%20metrics%20let%20you%20measure%20data%20value%20differences%20between%20a%20source%20table%20and%20a%20target%20table.%0ANote%3A%20Backfill%20is%20not%20configurable%20for%20row%20by%20row%20metrics.The%20system%20chooses%20a%20backfill%20duration%20based%20on%20aggregation%20interval%20for%20incremental%20full%20compare%20metrics.%0ACreate%20a%20row%20by%20row%20metric%0A%0A%0AIn%20th%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Row by row metrics

Row by row metrics let you measure data value differences between a source table and a target table.

*Note: Backfill is not configurable for row by row metrics.The system chooses a backfill duration based on aggregation interval for incremental full compare metrics*.

# Create a row by row metric

1. In the Explorer tree, select the data asset that you want to measure.
2. On the asset's Explorer menu select **+ Create Metric**:

   ![](https://files.readme.io/034e4e0-create-new-metric.png)
3. The metric configuration form opens. Set **Metric type** to **Row by row**.
4. Enter a **Metric name**.
5. By default, new metrics go Live shortly after you create them. If you want the metric to start off paused, under **Metric status**, set **Status** to *Paused*.
6. If desired, change the value of **Quality dimension**. Each data quality metric measures one dimension of data quality: accuracy, completeness, timeliness, or (if none of these applies), custom. You can sort and filter your metrics by dimension, and you can view them summarized by dimension in a [data quality dashboard](doc:data-quality-dashboards).
7. Select Next to proceed to **Step 2 (Configure Metric)**.

![](https://files.readme.io/7377b5e-c-rxr-step2.png)

8. Under **Source**, select a datasource, a schema, and a table. Do the same under **Target**. These are the tables the metric will compare.
9. Choose **Join type** (full outer join, right outer join, left outer join)
10. Optionally, [add a WHERE clause](https://docs.lightup.ai/docs/where-clause) below one or both tables
11. Choose the **Key columns to compare**.

* Choose one or more pairs of key columns.
* When the metric is computed, the key columns in the source will be compared to the key columns in the target and the Match % will be displayed.
  + Single pair example: For example, if you choose *Customer Name* as the key column in the source and *Cust Name* as the key column in the target, the percentage or rows where *Customer Name* equals *Cust Name* will be displayed.
  + Two pair example: For example, if for the first pair you choose *Customer Name* (source) and *Cust Name* (target), and the second pair you choose *Order ID* (source) and *Sale Id* (target), the percentage of rows where *Customer Name* and *Order ID* (source) match *Cust Name* and *Sale Id* (target) will be displayed.
* If you select attribute columns, the key columns also identify the rows that will participate in the attribute column compare. For each row where the key columns match, Lightup will compare all attribute columns and display the Match %, which is the percentage of rows where the attribute columns match

11. Optionally choose **Attribute columns to compare**.
12. Under **Configure metric**, make selections for the various inputs. These selections mirror the selections you need to make during [Table configuration](doc:table-configuration), where you can find details on how to fill in these fields.
13. Optionally [add slices](https://docs.lightup.ai/docs/slices) for your source and target tables. Make sure slices use the same columns in the same order.
14. When you're ready, select **Next** at the top right corner to proceed to Step 3 and preview your metric.

# Preview

Once you have configured your metric you can preview it to view a live query without creating a datapoint. If the preview doesn't work the way you want, you can select the tab for a previous step and modify the configuration as needed.

1. On the **Step 3 (Preview)** tab, set the date range for the preview, then select **Preview**.
2. When you're happy with the result, select **Next** to continue.

You don't have to preview your metric— you can just click **Next** to proceed to Step 4 (Related metrics).

# Add Related metrics

You add related metrics at Step 4 of metric configuration. Related metrics always appear in the list of metrics available during incident analysis.

![](https://files.readme.io/d204fc4-related-metric.png)

* To add a related metric, select **Add +** and then choose a metric in the listbox that appears.
* Select **Show info** inside a related metric to display the metric's ID and data asset(s).
* When you've added the related metrics you want, select **Create** (for a new metric) or **Save**.
* During [incident analysis](doc:analyze-an-incident) of the metric, any related metrics appear in the metrics listed on the left. You can then easily add them to the Metrics of interest, making the metric chart available within the incident.

# Failing Records

When the metric detects a difference between source and target, in the Explorer you can see additional information about the source and target tables to help with triaging. Clicking on the "View" link will show you additional details of the records where there is a mismatch between source and taget.

![](https://files.readme.io/7fe5c64-Screenshot_2024-04-16_at_3.02.08_PM.png)
![](https://files.readme.io/c26e895-Screenshot_2024-04-16_at_3.25.14_PM.png)

You can also download the failing records as a CSV file. The CSV file has columns as follows:

Source\_key\_0\_keycolumn

Source\_attr\_0\_colmun0

Source\_attr\_1\_column1

Target\_key\_0\_keycolumn

Target\_attr\_0\_colmun0

Target\_attr\_1\_column1

column0\_check (with values TRUE or FALSE)

column1\_check with values TRUE or FALSE)

# Size restrictions and implications

Lightup can handle up to rows count \* row size (based on columns) up to 5GB for row by row comparison metrics. If the total memory occupied by both the source and target rows to be compared exceeds a memory allocation for the row by row compare collector service, Lightup will pause the metric.

Updated 6 months ago

---

[Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)[SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
