---
title: "Amazon S3 bucket (Beta)"
slug: "amazon-s3-bucket-(beta)"
excerpt: "If you are interested in using this feature, please contact Lightup Support."
hidden: false
metadata:
  title: "Amazon S3 bucket (Beta)"
  description: "To use Lightup's File Inspection feature, which is in Beta, you must meet specific conditions such as using parquet files under 4GB and following a date-time-oriented folder structure. Additionally, to connect to an S3 datasource, you need to set up an IAM user or role with appropriate permissions and configure the datasource in Lightup."
  url: "https://docs.lightup.ai/docs/s3"
  image: ["https://cdn.readme.io/og-image/create?type=docs&title=Configure%20Datasources%20-%20Amazon%20S3%20Bucket%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=To%20use%20Lightup's%20File%20Inspection%20feature%2C%20which%20is%20in%20Beta%2C%20you%20must%20meet%20specific%20conditions%20such%20as%20using%20parquet%20files%20under%204GB%20and%20following%20a%20date-time-oriented%20folder%20structure.%20Additionally%2C%20to%20connect%20to%20an%20S3%20datasource%2C%20you%20need%20to%20set%20up%20an%20IAM%20user%20or%20role%20with%20appropriate%20permissions%20and%20configure%20the%20datasource%20in%20Lightup.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light"]
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Amazon S3 bucket (Beta)

If you are interested in using this feature, please [support@lightup.ai](mailto:support@lightup.ai).

> 🚧
> ### As this feature is currently in Beta, there are certain conditions that must be met to leverage Lightup for File Inspection:
>
> 1. Lightup currently only supports parquet files
> 2. Files must be less than 4GB in size
> 3. Each file must contain all data relating to specific interval
>
>    Example: If the file is intended to represent hourly data, then all of the data for the hour must be in a single file, rather than spread across multiple files
> 4. The folder structure must be in a date-time-oriented, iterative naming convention (`data_subject/%Y/%m/%d/%H/file_name.parquet`)
>
>    Example: purchase\_data/2024/10/11/01/datapoints.parquet
> 5. Only raw parquet files are supported (no zip, gz, gzip, etc)

# Lightup user setup

Lightup needs an IAM user than can access the data you want to include in the datasource. If you're running Lightup Self-hosted or Hybrid, Amazon recommends that you [use an IAM role to grant permissions to applications running on Amazon EC2 instances](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_roles_use_switch-role-ec2.html), such as S3 datasources. To do so for your S3 datasource, follow Amazon's instructions (preceding link) to grant permissions with an IAM role. Workspace admins can then just select **Managed by IAM role** when they create a connection to the datasource— no other connector settings are required in this case.

Otherwise, use the following procedure to create an IAM user with an access key and a policy to enable read access, and attach the policy to the new account.

1. [Create a new IAM user](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_users_create.html) and [an IAM access key for it](https://docs.aws.amazon.com/IAM/latest/UserGuide/id_credentials_access-keys.html), and leave **Provide user access to the AWS Management Console** unchecked.

   **IMPORTANT:** To create a connection to this S3 datasource through an IAM user, workspace admins will need two strings from the IAM user's access key: the Access Key ID and the Secret Access Key— you should save a copy of them so you can provide this information as needed.
2. At Step 2 - Set permissions, select **Attach policies directly**, then **Create policy**.

![](https://files.readme.io/ce72b45-iam-perms-policy.png)

3. For **Policy editor**, select **JSON**.

![](https://files.readme.io/ed73324-iam-policy-json.png)

4. Use one of the following templates to create the new policy.

* Grant access to all buckets and files:

JSON
```
{
	"Version": "2012-10-17",
	"Statement": [
		{
			"Effect": "Allow",
			"Action": [
				"s3:GetBucketLocation",
				"s3:ListAllMyBuckets",
				"s3:ListBucket",
				"s3:GetObject"
			],
			"Resource": "arn:aws:s3:::*"
		}
	]
}
```

* Grant access to specific buckets (once for each bucket, replacing ***{bucket\_name}*** with the actual bucket name):

JSON
```
{
	"Version": "2012-10-17",
	"Statement": [
        // Necessary to list buckets
		{
			"Effect": "Allow",
			"Action": [
				"s3:GetBucketLocation",
				"s3:ListAllMyBuckets"
			],
			"Resource": "arn:aws:s3:::*"
		},
		{
            // Necessary to list and retrieve files from the allowed buckets
			"Effect": "Allow",
			"Action": [
				"s3:ListBucket",
				"s3:GetObject"
			],
			"Resource": [
				"arn:aws:s3:::{bucket-name}",
				"arn:aws:s3:::{bucket-name}/*"
			]
		}
	]
}
```

5. Name the policy *s3-read-only*, then select **Create policy**.
6. Back on the **Create User** page, refresh the policy list.
7. Select the **s3-read-only** policy, and then select **Next**.
8. Finish the **Create User** dialog.

# Connect to an S3 bucket

1. In the left pane, select **Datasources.**
2. In the main page select **Create Datasource +**.
3. Enter a **Datasource Name**, then for **Connector Type** select *Amazon S3 bucket*.
4. In the Configure connector section, do one of the following, based on whether there's an IAM role in place for the datasource:

* **Managed by IAM Role** — If an IAM Role is required for access to an S3 bucket then the IAM Role needs to be assigned to the Node/VM that Lightup is deployed on. After that is done, then the toggle switch for **Managed by IAM Role** to the right of **Configure connector** needs to be switched to the green position.

![](https://files.readme.io/32645d8-image.png)

**Access Keys** — If there is no IAM role in place, provide the following inputs:

* **Region** - Specify the AWS Region where your data is hosted, e.g. "us-west-2".
* **Access Key ID** - Part of the access key for the lightup user. If you didn't set up the lightup user account and don't know its Access Key ID, ask your system administrator for this information.
* **Secret Access Key** - Part of the access key for the lightup user. If you didn't set up the lightup user account and don't know its Secret Access Key, ask your system administrator for this information.

5. After entering the required settings and any optional settings that apply, below the **Configure connector** section select **Test Connection**.
6. After a successful connection test, select **Save**.
7. Your new datasource appears in the list of available datasources. By default, these are listed in alphabetical order, so you might have to scroll or change the sort order to see your new datasource.

Note that S3 datasources use [virtual tables](doc:managing-your-explorer-tree#add-virtual-tables) and not tables. You'll need information about the file paths used for each virtual table in order to configure them for data quality analysis.

## Advanced/Schema scan frequency

You can adjust how often scans run for a datasource.

* In section **3 - Advanced**, select a value for **Schema scan frequency**: *Hourly*, *Daily*, or *Weekly*.

# Query Governance

S3 datasources support the **Scheduling**, **Enable Data Storage**, **Maximum Backfill Duration** and **Maximum Distinct Values** query governance settings. For steps, see [Set query governance settings for a datasource](https://docs.lightup.ai/docs/query-governance).

# Metadata metrics

S3 datasources currently do not support metadata metrics.

# Date/time data types

These [S3 date/time data types](https://docs.aws.amazon.com/AmazonS3/latest/userguide/s3-select-sql-reference-data-types.html#s3-select-sql-reference-supported-data-types) are supported:

* DATE
* TIMESTAMP

# Object types

These S3 object types are supported:

* [Virtual tables](doc:managing-your-explorer-tree#add-virtual-tables)

# Partitions

S3 datasources support partitions.

# Deep metrics

S3 datasources support all deep metrics except for [row by row](doc:row-by-row-metrics) and [SQL](doc:sql-metrics) metrics. However, the following features are not supported:

* [WHERE clauses](doc:where-clause), except for [conformity metrics](doc:conformity-metrics)
* Multiple conditions in [conformity metrics](doc:conformity-metrics)
* [Seasonality](doc:seasonality) in [data delay metrics](doc:data-delay-metrics)
* [Failing records queries](doc:failing-records-query)
* Full Table [query scope](doc:table-configuration#query-scope)
* Validation of incident fixes

Updated 6 months ago

---

[Query Governance](https://docs.lightup.ai/docs/query-governance)[Athena](https://docs.lightup.ai/docs/connect-to-athena)
