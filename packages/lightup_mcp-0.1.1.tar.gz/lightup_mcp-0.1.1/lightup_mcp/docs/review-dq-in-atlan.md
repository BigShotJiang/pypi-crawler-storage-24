---
title: "Review DQ in Atlan"
slug: "review-dq-in-atlan"
excerpt: "Atlan is a data catalog that leverages asset data and metadata to help teams discover, trust, and understand data they care about. Data assets in your Atlan catalog support a range of basic metadata, and Atlan supports extending the knowledge available about those assets with custom metadata."
hidden: false
metadata:
  title: "Review DQ in Atlan"
  description: "Atlan is a data catalog that leverages asset data and metadata to help teams discover, trust, and understand data they care about. Data assets in your Atlan catalog support a range of basic metadata, and Atlan supports extending the knowledge available about those assets with custom metadata.
You ca…"
  url: "https://docs.lightup.ai/docs/review-dq-in-atlan"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Review%20DQ%20in%20Atlan&projectTitle=Lightup%20Data%20User%20docs&description=Atlan%20is%20a%20data%20catalog%20that%20leverages%20asset%20data%20and%20metadata%20to%20help%20teams%20discover%2C%20trust%2C%20and%20understand%20data%20they%20care%20about.%20Data%20assets%20in%20your%20Atlan%20catalog%20support%20a%20range%20of%20basic%20metadata%2C%20and%20Atlan%20supports%20extending%20the%20knowledge%20available%20about%20those%20assets%20with%20custom%20metadata.%0AYou%20ca%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Review DQ in Atlan

Atlan is a data catalog that leverages asset data and metadata to help teams discover, trust, and understand data they care about. Data assets in your Atlan catalog support a range of basic metadata, and Atlan supports extending the knowledge available about those assets with custom metadata.

You can [add your Atlan data catalog](doc:atlan) to Lightup, expanding the health metadata that your teams can use to evaluate trustworthiness of data (including its lineage), and even generating announcements for your Atlan catalog assets when Lightup detects incidents.

Before you begin, consider creating an Atlan [persona](https://ask.atlan.com/hc/en-us/articles/4413870860049-What-are-personas-#team-based-personalization-0-0) to grant Lightup's API token access to metadata and data for the connections you want to integrate. You can also create the persona when you create the API token, but if you create it ahead of time you can just add it to the token instead.

For example, the policies in this persona enable Lightup to send health information about three datasources:

![](https://files.readme.io/d599bcd-atlan-persona.png)

Note that before Atlan can be enabled for a datasource, you must first [grant the API token the necessary metadata and data access](https://ask.atlan.com/hc/en-us/articles/8312649180049#token-permissions-0-2) to the Atlan connection that corresponds to the Lightup datasource, using policies in a [persona](https://ask.atlan.com/hc/en-us/articles/4413870860049-What-are-personas-#team-based-personalization-0-0). This is required for each datasource.

# Using Lightup with Atlan

After Atlan is [enabled for a datasource](doc:add-datasources#enable-data-catalog-integration), Atlan and Lightup perform regular scans of each other to keep your catalog information in sync. Any incident that occurs in Lightup on a data asset in the datasource generates (or updates) an [Atlan announcement](https://ask.atlan.com/hc/en-us/articles/4414376339857-How-to-create-announcements).

* Your Atlan home page displays incident announcements for assets in the Recent Announcements feed.
* Lightup provides data quality information to Atlan so you can review an asset's health in the Atlan catalog. You can also use Lightup filters on your Atlan data catalog, so you can focus on assets that have Lightup data quality information.
* Lightup also adds data quality information to your Atlan Lineage diagram.

# Review Recent Announcements to keep aware of data quality issues

Each asset in Atlan can have an announcement associated with it. When Lightup detects an incident, it generates an announcement for the related Atlan asset. These announcements appear on the right side of your Atlan home page for any assets you can see in Atlan.

![](https://files.readme.io/213cd10-atlan-home-announcements.png)
# Check data health of assets in your Atlan catalog

The Assets tab of your Atlan catalog helps you find and evaluate suitable data assets for specific information needs. Lightup provides filters to help you find assets in Atlan that have Lightup data health information, and keeps that information updated for those assets to help you evaluate their health.

## Filter using Lightup information

When you select the Assets tab, by default Atlan lists all assets you can see. You can use one of the Lightup filters to narrow down the list so you only see assets that have Lightup data quality information.

![](https://files.readme.io/a4b96e8-atlan-filters.png)

For example, here's a list of assets that have at least one monitor on the corresponding table in Lightup, filtered using *Table monitored*:

![](https://files.readme.io/2a15258-atlan-filtered-table-monitered.png)

1. The Lightup filter, **Table monitored**, is set to *Yes*, limiting the list of assets.
2. On each asset, data health is indicated by a flag showing the asset's announcement, which reflects whether an incident occurred and (if so) its status.
3. Lightup custom metadata appears on the asset sidebar.

# View Lightup information in an asset's Lineage

When you select the [Lineage tab of an asset profile](https://ask.atlan.com/hc/en-us/articles/4413869736593-What-are-asset-profiles-#lineage-0-2) in Atlan, any Lightup health information appears as flags in the lineage of the asset, so you can see the source and impact of detected incidents. Details about the health of the asset appear in the asset sidebar.

Updated 6 months ago

---

[Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)[Work with system events](https://docs.lightup.ai/docs/system-events)
