---
title: "Data collection"
slug: "data-collection"
excerpt: "A Lightup metric tracks a series of aggregate measurements of your data. The aggregate measurement is collected by periodically querying rows in your data. The values are displayed as datapoints on a time series chart with time on the X axis and the aggregate value on the Y axis."
hidden: false
metadata:
  title: "Data collection"
  description: "Lightup metrics track aggregate measurements of data over time, with deep metrics involving configurable data collection processes and metadata metrics relying on system table queries during schema scans. Deep metrics can be scheduled, triggered, or custom-scheduled, while metadata metrics have fixed settings and include event-based metrics like Table Activity and Column Activity."
  url: "https://docs.lightup.ai/docs/data-collection"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Data%20Collection%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=Lightup%20metrics%20track%20aggregate%20measurements%20of%20data%20over%20time%2C%20with%20deep%20metrics%20involving%20configurable%20data%20collection%20processes%20and%20metadata%20metrics%20relying%20on%20system%20table%20queries%20during%20schema%20scans.%20Deep%20metrics%20can%20be%20scheduled%2C%20triggered%2C%20or%20custom-scheduled%2C%20while%20metadata%20metrics%20have%20fixed%20settings%20and%20include%20event-based%20metrics%20like%20Table%20Activity%20and%20Column%20Activity.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Data collection

A Lightup metric tracks a series of aggregate measurements of your data. The aggregate measurement is collected by periodically querying rows in your data. The values are displayed as datapoints on a time series chart with time on the X axis and the aggregate value on the Y axis.

Each metric datapoint is the result of a data collection process. Understanding the data collection process will help you optimize your metrics so they'll be collected at the time that's best for your ETL pipeline. It's important to note that data collection for deep metrics works differently from data collection for metadata metrics.

# Deep metrics data collection

The deep metrics data collection process has a large number of configuration parameters that affect the timing of data collection and which rows in the dataset are collected during each data collection.

All scheduled metrics follow the same basic data collection process: every collection interval, Lightup collects rows that fall within a collection window. Trigger metrics only collect data if they are triggered, and collect rows from all collection windows since the last time they were triggered.

A metric's **Data Collection** settings determine the extents of the collection window, how much data to aggregate to produce a metric value, and the frequency of data collection.

* [**Query Scope**](https://docs.lightup.ai/docs/query-scope) is either Incremental or Full Table:

  + Incremental - Data points are collected according to a time range (Example: New rows in the past hour)![](https://files.readme.io/d132bcb-incr-scope-chart.png)
  + Full Table - Data points are collected without regard to a time range (Example: All rows in the table)![](https://files.readme.io/a1af7f2-ft-scope-chart.png)
* [**Data Collection Schedule**](https://docs.lightup.ai/docs/data-collection-schedule) is either Scheduled, Triggered, or Custom Schedule:

  + Scheduled - Lightup will collect the metric data points on a repeating schedule, such as once an hour, once a day, and so on
  + Triggered - The metric will only run when an API call triggers that metric
  + Custom Schedule - A user can specify, using [CRON syntax](https://crontab.guru/), when the metric should run (Example: Run the metric every 6 hours)
* [**Data Collection Window**](https://docs.lightup.ai/docs/data-collection-window) is either Full Window or Partial Window:

  + Full Window - The metric data point is collected for the most recent complete Aggregation Window (Example: A daily metric is run at 12:05 am today. The most recent complete Day is yesterday)
  + Partial Window - The metric data point is collected in the assumption that the current Aggregation Window is complete (Example: A daily metric is run at 7:00 pm today. Lightup considers the data for today as "complete" and runs the metric collection on all data for today, even though there are 5 hours left in the day)
* [**Aggregation Interval**](https://docs.lightup.ai/docs/aggregation-interval) is the time range that Lightup uses for metric data point gathering (Example: All rows in the past hour)
* [**Evaluation Delay**](https://docs.lightup.ai/docs/evaluation-delay) is different depending on the Aggregation Interval:

  + For *Minute* or *Hourly* Aggregation Intervals, the Evaluation Delay tells Lightup the most recent hour to consider for the metric collection (Example: Evaluation Delay set to 2 Hours will tell Lightup to only consider the data from 2 hours ago, rather than the most recent hour. In the case of Lightup running the Metric at 10:05 am, the metric will look for data in the 7:00 am-8:00 am time range). This is useful if the data has an expected lag as to when it is added or updated.
  + For *Daily*, *Weekly*, and *Monthly* Aggregation Intervals, the Evaluation Delay will have different behaviors depending on the Evaluation Delay time object (i.e. Hour, Day, Week)
    - If the Evaluation Delay is set to *Hour*, *Minute*, or *Second*, then Lightup will collect the daily data point on the most recent full date. But the metric will only be run at the time related to the Evaluation (Example: Evaluation Delay is set to 7 hours. Lightup will run the metric collection at 7:00 am for the previous day's data)
    - If the Evaluation Delay is set to anything larger that *Hour*, then Lightup will collect the daily data point for that many *Days*, *Weeks*, or *Months* ago (Example: Evaluation Delay is set to 2 days. Lightup will run the metric collection at 12:00 am on January 3rd for data on January 1st)
* For Full Table metrics, there are alternatives to Evaluation Delay, which are Polling Delay and Polling Interval

  + [**Polling Delay**](https://docs.lightup.ai/docs/polling-delay) adds a delay to the start of data collection. Once the delay period has passed, the metric is scheduled to run. This delay may be exceeded depending on system load, but will always at least be met.
  + [**Polling Interval**](https://docs.lightup.ai/docs/polling-interval) determines how often data collection occurs if **Data Collection Schedule** is set to *Scheduled*.

# Metadata metrics data collection

Like deep metrics, metadata metrics periodically collect data to produce a datapoint, based on their data collection settings. Unlike deep metrics:

* Metadata metrics don't query your data assets during data collection. Instead, these metrics query system tables that are updated during schema scans (both scheduled and manual).
* Metadata metric data collection settings can't be changed.

## Event metrics

Two metadata metrics— Table Activity and Column Activity— are event-based: they expose system events that are detected during schema scans (both scheduled and manual). These activity metrics create datapoints that sum the system events detected by schema scans since their last data collection. Note that if multiple changes to the data asset occur between schema scans, some changes might not be detectable as events. For example, if a table is added and then dropped and no scan occurs between the two events, neither event is detectable by the Table Activity metric because the schema has the same tables before and after the events. However, if a table is added and a different table is dropped, both events are detectable.

Updated 6 months ago

---

[Auto metrics](https://docs.lightup.ai/docs/autometrics-1)[Charts](https://docs.lightup.ai/docs/charts)
