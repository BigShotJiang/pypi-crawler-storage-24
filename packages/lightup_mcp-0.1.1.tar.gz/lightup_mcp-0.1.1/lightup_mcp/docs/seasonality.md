---
title: "Seasonality"
slug: "seasonality"
excerpt: "Many data assets have regular behavior patterns. For example, a restaurant might have three rushes (breakfast, lunch, and dinner) that occur daily at all locations, each about an hour long. Data from one of the off-hours isn't really comparable to data from one of the rushes. Likewise, breakfast data might not normally look like dinner data. To account for these patterns, you need a way to make sure you compare the right data periods. In Lightup, this regular variation is called seasonality."
hidden: false
metadata:
  title: "Seasonality"
  description: "Many data assets have regular behavior patterns. For example, a restaurant might have three rushes (breakfast, lunch, and dinner) that occur daily at all locations, each about an hour long. Data from one of the off-hours isn't really comparable to data from one of the rushes. Likewise, breakfast dat…"
  url: "https://docs.lightup.ai/docs/seasonality"
  image: ["https://cdn.readme.io/og-image/create?type=docs&title=Seasonality&projectTitle=Lightup%20Data%20User%20docs&description=Many%20data%20assets%20have%20regular%20behavior%20patterns.%20For%20example%2C%20a%20restaurant%20might%20have%20three%20rushes%20(breakfast%2C%20lunch%2C%20and%20dinner)%20that%20occur%20daily%20at%20all%20locations%2C%20each%20about%20an%20hour%20long.%20Data%20from%20one%20of%20the%20off-hours%20isn't%20really%20comparable%20to%20data%20from%20one%20of%20the%20rushes.%20Likewise%2C%20breakfast%20dat%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light"]
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Seasonality

Many data assets have regular behavior patterns. For example, a restaurant might have three rushes (breakfast, lunch, and dinner) that occur daily at all locations, each about an hour long. Data from one of the off-hours isn't really comparable to data from one of the rushes. Likewise, breakfast data might not normally look like dinner data. To account for these patterns, you need a way to make sure you compare the right data periods. In Lightup, this regular variation is called seasonality.

When a metric runs, if seasonality is set up it will create separate profiles for each season. So in our example restaurant, every hour of the day is a season, and the metric creates profiles for each of them. Then when you add an anomaly detection monitor, it only compares seasons to each other— comparing lunch hours to lunch hours, etc.

Note that seasonality only impacts anomaly monitors. It does not impact a metric without any monitors, and it does not impact detection of incidents on metrics that have manual threshold monitors.

To set seasonality, you'll want to think about the operation of your business and identify the seasonality selection that fits best. If you're not sure, set seasonality to *No Seasonality* - as you get more familiar with the system you'll be better able to identify how seasonality settings will impact incident generation. If you think that your metric does have seasonality, but you aren't sure how to represent it, you can select *Auto seasonality*. When a monitor is associated with a metric that has *Auto seasonality*, it will perform seasonality discovery during monitor training and choose the seasonality that fits best.

# Set up seasonality

You set up seasonality on the **Configure Metric** tab of a metric.

Find the **Seasonality** drop down and select an option. The table below shows your choice of seasonality selections and the associated definition of the seasons.

| Seasonality | Number of seasons | Occurring every |
| --- | --- | --- |
| No seasonality | NA | NA |
| Auto seasonality | NA | NA |
| Daily with 15 minute seasons | 96 | Day |
| Daily with 1 hour seasons | 24 | Day |
| Daily with 8 hour seasons | 3 | Day |
| Weekly with 15 minute seasons | 672 | Week |
| Weekly with 1 hour seasons | 168 | Week |
| Weekly with 8 hour seasons | 21 | Week |
| Weekly with 1 day seasons | 7 | Week |

Except for *No Seasonality* and *Auto Seasonality*, each setting for **Seasonality** has two parts:

* The period of time over which all seasons occur— in our example restaurant, the seasons occur daily.
* The length of seasons— the individual chunks of time that have typical behavior. For our example, the seasons are one hour long.

So for our example restaurant, we'd set **Seasonality** to *Daily with 1 hour seasons*. By doing this, each hour of the day will have its own profile, and any given hour will generate an incident only if it violates the pattern seen in that same hour during the training period.

# Custom seasonality

If your data has seasonal patterns that are different from its typical seasonality— say, during summer or on New Year's Eve, you can customize your seasonality by adding one or more override periods. The basic seasonality still applies to these periods, but each gets its own profile. This lets you compare data within each override period separately, so that any monitors you add will only generate incidents by comparing these periods to each other, not to the rest of your data.

Continuing the restaurant example, you might typically have much larger crowds on New Year's Eve, and they might stay later than on a regular day. With daily one-hour seasons, a monitor might generate an incident when it shouldn't because the data from December 31st doesn't look like data from other days. To correctly assess your data, you would add a custom override for December 31st to your basic seasonality.

## Add a custom override

Before you can add an override, you must specify the seasonality— *Auto Seasonality* does not support overrides.

1. After picking a basic seasonality, select the Advanced button.
2. Under **Basic Seasonality**, select **Add +**.
3. Enter an **Override Season Name**.
4. At least one period is required— the fields to define it appear below the Override Season Name. You can add more periods to the override by clicking **Add +** just above the first override period.
5. For each override period in the override season, provide values for the following:
   * Choose a date/time for **Starts** and **Ends** to define the period itself.
   * Select how often the period repeats, and how many times it will occur.

     ![](https://files.readme.io/fe1dca8-custom-seasons.png)

Updated 6 months ago

---

[Schedules](https://docs.lightup.ai/docs/create-a-schedule)[Slices](https://docs.lightup.ai/docs/slices)
