---
title: "Athena"
slug: "athena"
excerpt: "Steps to prepare and connect to Athena"
hidden: false
metadata:
  title: "Athena"
  description: "This document provides a step-by-step guide to setting up Amazon Athena with Lightup, including creating an IAM user with specific policies, generating access keys, and configuring the Athena datasource in Lightup. It also covers advanced settings, query governance, supported data types, object types, and partitions."
  url: "https://docs.lightup.ai/docs/connect-to-athena"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Configure%20Datasources%20-%20Athena%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=This%20document%20provides%20a%20step-by-step%20guide%20to%20setting%20up%20Amazon%20Athena%20with%20Lightup%2C%20including%20creating%20an%20IAM%20user%20with%20specific%20policies%2C%20generating%20access%20keys%2C%20and%20configuring%20the%20Athena%20datasource%20in%20Lightup.%20It%20also%20covers%20advanced%20settings%2C%20query%20governance%2C%20supported%20data%20types%2C%20object%20types%2C%20and%20partitions.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Athena

Steps to prepare and connect to Athena

# Overview

More details about Athena can be found on the AWS website: [Interactive SQL - Amazon Athena](https://aws.amazon.com/athena/)

Athena needs to access S3 buckets where data is stored and also S3 buckets where the query results are stored.

Before you start, please note down the names of the buckets where data is stored as well as where the Athena result sets will be stored. Ideally, these should be 2 different buckets in order to keep the permissions separated. Please create a query results bucket if needed.

# Create an IAM User

In this example we are creating a user named **lightup-athena-read-only**

![](https://files.readme.io/42ab248-Screenshot_2024-04-18_at_9.09.30_AM.png)

Go to IAM/Users and click on Create User

Click: Next

# Attach Policies

We will attaching 2 policies to the user, this will include:

1. Access to S3 buckets
2. Access to Athena, Glue and other services needed by Athena

## Create and attach S3 bucket policy for data, query results

As discussed earlier, we need to create an S3 policy to allow user to access data bucket (read-only) as well as the query result set bucket (read-write)

Choose **Attach existing policies directly**

![](https://files.readme.io/073ecab-Screenshot_2024-04-18_at_9.09.59_AM.png)

Then click on **Create Policy, use JSON**

This will launch a separate tab or window so, after this step is done, you will have to go back to the create user workflow.

![](https://files.readme.io/ca3dc40-Screenshot_2024-04-18_at_9.10.15_AM.png)

Please paste in the JSON below (AFTER making the necessary edits). Please note that DATA\_BUCKET and RESULTS\_BUCKET keywords need to be replaced by the appropriate S3 bucket names that were described earlier in this doc:

Athena Policy
```
{
    "Version": "2012-10-17",
    "Statement": \[
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetObject",
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::DATA_BUCKET/*",
                "arn:aws:s3:::DATA_BUCKET"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:GetBucketLocation",
                "s3:GetObject",
                "s3:ListBucket",
                "s3:ListBucketMultipartUploads",
                "s3:ListMultipartUploadParts",
                "s3:AbortMultipartUpload",
                "s3:CreateBucket",
                "s3:PutObject",
                "s3:PutBucketPublicAccessBlock"
            ],
            "Resource": [
                "arn:aws:s3:::RESULTS_BUCKET/*",
                "arn:aws:s3:::RESULTS_BUCKET"
            ]
        }
    ]
}
```

Click Next and name the policy

![](https://files.readme.io/5cd3181-Screenshot_2024-04-18_at_9.10.42_AM.png)

Once the policy is created, go back to the tab or window where the user was being created.

Search for and attach this newly created policy. NOTE: You may need to refresh the policies to see the newly created policy.

## Attach AWSQuicksightAthenaAccess policy

Once the S3 policy is attached, search for and attach the AWS managed [AWSQuicksightAthenaAccess policy](https://docs.aws.amazon.com/aws-managed-policy/latest/reference/AWSQuicksightAthenaAccess.html). This allows the access to Athena as well to Glue for metadata.



![](https://files.readme.io/d5c6bb6-Screenshot_2024-04-18_at_9.17.43_AM.png)

Verify that both policies have been added

![](https://files.readme.io/748f4a9-Screenshot_2024-04-18_at_9.17.58_AM.png)

Save the user with these permissions.

# Generate access keys

Generate access keys for the user that was created.

![](https://files.readme.io/19efe41-Screenshot_2024-04-18_at_9.19.34_AM.png)

Remember the access key ID as well as the secret access key as it will be needed when Athena is configured in Lightup in the next step. Click **Download .csv** file to keep track of these keys.

# Configure Athena in Lightup

> 📘
> ### Workgroup support
>
> Lightup supports Athena workgroups, which can help you manage costs and performance. A workgroup must be in place before you connect to the Athena datasource in Lightup— you can't add a workgroup to an existing datasource.
>
> * For more information about Athena workgroups, please see the Athena help page, [Manage queries and control costs with workgroups](https://docs.aws.amazon.com/athena/latest/ug/manage-queries-control-costs-with-workgroups.html).
> * To use a workgroup when you connect, enter the workgroup name in the datasource's [Connector settings](https://docs.lightup.ai/docs/connect-to-athena#connector-settings).

1. In the left pane, open a workspace menu and select **Datasources.**
2. In the main page select **Create Datasource +**.
3. Enter a **Datasource Name**, then for **Connector Type** select *Athena*.
4. Under **Configure connector**, provide the following inputs:

* **Region** - Specify the AWS Region where your data is hosted, e.g. "us-west-2". Read more about [Athena Regions](https://docs.aws.amazon.com/athena/latest/ug/querying-across-regions.html).
* **Access Key ID** - Part of the access key for the lightup user. If you didn't set up the lightup user account and don't know its Access Key ID, ask your system administrator for this information.
* **Secret Access Key** - Part of the access key for the lightup user. If you didn't set up the lightup user account and don't know its Secret Access Key, ask your system administrator for this information.
* **Staging Directory** - Enter the S3 bucket for your Athena query results bucket. It should start with **s3://...**.
* **Workgroup** - If needed, enter a specific Athena workgroup to connect to.

Please note that Test Connection currently does not test the validity of the S3 staging directory as well as the workgroup so, please make sure that there are no typos.

5. After entering the required settings and any optional settings that apply, below the **Configure connector** section select **Test Connection**.
6. After a successful connection test, select **Save**.
7. Your new datasource appears in the list of available datasources. By default, these are listed in alphabetical order, so you might have to scroll or change the sort order to see your new datasource.

## Advanced/Schema scan frequency

You can adjust how often scans run for a datasource.

* In section **3 - Advanced**, select a value for **Schema scan frequency**: *Hourly*, *Daily*, or *Weekly*.

# Query Governance

Athena datasources support the **Scheduling**, **Enable data storage**, **Maximum backfill duration**, and **Maximum distinct values** settings. For steps, see [Set query governance settings for a datasource](https://docs.lightup.ai/docs/query-governance).

# Date/time data types

These [Athena date/time data types](https://docs.aws.amazon.com/athena/latest/ug/data-types.html) are supported:

* DATE
* TIMESTAMP

# Object types

These Athena object types are supported:

* Tables
* Views

# Partitions

[Athena datasources support partitions](https://docs.aws.amazon.com/athena/latest/ug/partitions.html), multi-partitions, and partition time zones.

# Supported Versions

Lightup currently supports:

* Athena SQL

Updated 6 months ago

---

[Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)[Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
