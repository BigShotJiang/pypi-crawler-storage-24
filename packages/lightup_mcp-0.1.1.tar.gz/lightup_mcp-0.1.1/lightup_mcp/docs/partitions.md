---
title: "Partitions"
slug: "partitions"
excerpt: "In the world of database administration, every ounce of available compute resources is precious. Queries that run too long or consume too much data can slow down the system significantly, or even lock it up altogether. There are multiple optimization techniques to solve for this problem, whether that is indexing, leveraging read-replicas, partitioning the data, or a combination of all of the above."
hidden: false
metadata:
  title: "Partitions"
  description: "In the world of database administration, every ounce of available compute resources is precious. Queries that run too long or consume too much data can slow down the system significantly, or even lock it up altogether. There are multiple optimization techniques to solve for this problem, whether tha…"
  url: "https://docs.lightup.ai/docs/partitions"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Partitions&projectTitle=Lightup%20Data%20User%20docs&description=In%20the%20world%20of%20database%20administration%2C%20every%20ounce%20of%20available%20compute%20resources%20is%20precious.%20Queries%20that%20run%20too%20long%20or%20consume%20too%20much%20data%20can%20slow%20down%20the%20system%20significantly%2C%20or%20even%20lock%20it%20up%20altogether.%20There%20are%20multiple%20optimization%20techniques%20to%20solve%20for%20this%20problem%2C%20whether%20tha%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Partitions

In the world of database administration, every ounce of available compute resources is precious. Queries that run too long or consume too much data can slow down the system significantly, or even lock it up altogether. There are multiple optimization techniques to solve for this problem, whether that is indexing, leveraging read-replicas, partitioning the data, or a combination of all of the above.

For many, the first step is setting up indexes on the data. This technique isn't anything particularly difficult to understand, since a data index operates the same as a book's index does. The database will organize the dataset in a certain order, track what that order is, and leverage that known order for future queries. Once an index is complete, the next step is partitioning the data.

A Partition is also easy to understand, since it behaves exactly as it sounds: You set up partitions in the dataset. Similar to how an index works (organize data in an order and keep track of that order), partitions separate out the data into groups, track where those groups are, and then only leverage the required groups for the query request.

Let's look at a quick example:

The dataset in question is a loyalty system dataset which tracks the first name, last name, loyalty number, purchase location, order amount, ordered items, and the transaction time.

As transactions happen, they are loaded into your database in the order they happened (generally speaking). If you wanted to look for a specific transaction from that last 10 days, your query might look like:

SQL
```
SELECT * FROM
  transaction_table
WHERE
  transaction_id = 0000000000019847
```

But querying a couple million rows for just that one transaction requires the database to go through every single row until it finds the transaction, which could take a long time. IF you index the entire dataset on transaction\_id, then the database would order the dataset in sequential order according to the transaction\_id. Now when you query the data, the database knows where the transaction\_id should generally be, making the query much faster. But, what if your data size continues to grow AND you want to do some analytics on the data? For example, you might want to get all of the revenue for the last day based on the store. That query would look something like:

SQL
```
SELECT
  SUM(order_amount) as revenue,
  *
  FROM
    transaction_table
  WHERE
    transaction_date LIKE '2023-08-23'
```

Even though you might have an index, all of the data in the whole dataset still has to be queried in order to get the SUM of the revenue. This is where partitions can be extremely helpful. If you setup an index on the transaction\_date column in the dataset and also partition the dataset on transaction\_date, then not only will the database order the transactions by the date, but now each day's worth of data is segmented. When the query is executed, the database can skip over all partitions that are not needed, load only the data in the appropriate partitions, and then finish out the analytics task. This massively speeds up how queries execute.

Lightup was built from the ground up to leverage these different optimization techniques so that all of the push-down queries are highly efficient. When the user configures a table or metric, they have the option of specifying the partition structure for Lightup to use. One thing to note is that, since Lightup is mainly executing time-range bound queries, the partitioning scheme that works is when the partition is set to a date/time oriented column.

# Add partitions

1. To add a partition column, click **Add +** and then select the column from the drop-down list. Partition columns are labelled *(partition)* in the list.
2. Specify the partition's format using [Python format codes](https://docs.python.org/3/library/datetime.html#strftime-and-strptime-format-codes). When Lightup generates a query for a time interval, it will convert the start and end of that time interval to the partition date format and generate a where clause that queries only the partitions where the data is expected to reside. Consider the following examples to better understand how partition formats work.
   * Example 1: If you have a partition column called *month* and it contains a two-digit month number, you can enter *%m* for the format. If Lightup is querying the date range 03/07/2023 through 03/13/2023, the following **WHERE** clause will be included in the query:
     SQL
     ```
     WHERE `month` in (03)
     ```
   * Example 2: If you have three partition columns called *year* (a four-digit year), *month* (a two-digit month), and *day* (a two-digit day), you can enter *%Y* for year, *%m* for month, and *%d* for day. If Lightup is querying the date range 03/07/2023 through 03/13/2023, the following **WHERE** clause will be included in the query:
     SQL
     ```
     WHERE
     			`year` in (2023)
     			AND `month` in (03)
     			AND `day` in (07, 08, 09, 10, 11, 12, 13)
     ```
   * Example 3: If you have a partition column called *datehour* that contains the date and hour, in a format such as 03/07/2023/18, you can enter *%y/%m/%d/%H* for the format. If Lightup is querying the time range 03/07/2023 18:00 through 03/08/2023 18:00, the following **WHERE** clause will be included in the query:
     SQL
     ```
     WHERE
     		CAST(`datehour` AS STRING) in (
     				'2023/03/07/18',
     				'2023/03/07/19'
             ...
             '2023/03/07/23',
             '2023/03/08/00',
             '2023/03/08/01',
             ...
             '2023/03/08/18'
     			)
     ```
3. Click **Advanced** to configure the **Timezone**, **Partition Offset Past** and **Partition Offset Future** settings for partitions. **Partition Offset Past** and **Partition Offset Future** let you add partition offsets to tell Lightup to query adjacent partitions associated with timestamps in the past or future.
   * In Example 2 above (with *year*, *month*, and *day* partitions), if **Partition Offset Past** is set to 2 days, the **WHERE** clause will include two additional days in the past (*05* and *06*):
     SQL
     ```
     WHERE
     			`year` in (2023)
     			AND `month` in (03)
     			AND `day` in (05, 06, 07, 08, 09, 10, 11, 12, 13)
     ```
   * In Example 3 above (with a partition column called *datehour*), if **Partition Offset Past** is set to 2 days in the past, the **WHERE** clause will include the full two-day period, hour by hour for the two days prior to the query period, resulting in:
     SQL
     ```
     WHERE
     		CAST(`datehour` AS STRING) in (
             '2023/03/05/18',
             ...
             '2023/03/05/23',
             '2023/03/06/00',
             ...
             '2023/03/06/23',
             '2023/03/07/00',
             ...
     				'2023/03/07/18',
     				'2023/03/07/19'
             ...
             '2023/03/07/23',
             '2023/03/08/00',
             '2023/03/08/01',
             ...
             '2023/03/08/18'
     			)
     ```

# Use partitions to optimize an SQL metric

If your table has a date-based partition column, you can optimize your query to query only the partitions where the data resides. To do this, you need to do two things:

1. Add conditions to your **WHERE** clause which restrict the query to querying only the partitions where you expect your data to reside. This is done by adding the special tags *{start\_partition}* and *{end\_partition}* to your **WHERE** clause
2. Specify the format of that will be generated for *{start\_partition}* and *{end\_partition}* by filling in the Partition format input.This enables Lightup to convert *{start\_partition}* and *{end\_partition}* into string representations of the start and end of the query period using the date format specified in the Partitions input

For example, if Partition is set to "%Y-%m-%d-%H" and the query time range is from 3/1/2023 15:00:00 to 3/4/2023 17:00:00, *{start\_partition}* will be set to 2023-03-01-15 and *{end\_partition}* will be set to 2023-03-04-17. Let's assume you have a column in your dataset that is in this format, called *datehour*. You could now restrict your query to look only in the appropriate partitions by adding the following to your **WHERE** clause:

```
AND `datehour` >= {start_partition}
AND `datehour` <= {end_partition}
```

This will resolve to

```
AND `datehour` >= '2023-03-01-15'
AND `datehour` <= '2023-03-04-17'
```

It's important to note that this is a string comparison. This means that the comparison is alphabetical and in order for it to match, the value of your column (*datehour* in this case) must be lexicographically ordered within the start and end range specified by *{start\_partition}* and *{end\_partition}*. If your *datehour* column has a format that is different from the format that you specify as the partition format, the results will not make sense. For example, if *datehour* has format *2023-Mar-01-15*, it will clearly not be found between *2023-03-01-15* and *2023-03-04-17*.

It's also important to note that in order to use >= and <= as shown in the example above, the partition format must be lexicographically sortable. For example, if your column has the format *2023-1-15* (single digit for month), you cannot specify this format as your partition format because a lexicographical sort would result in 2023-12-25 being found between 2023-1-15 and 2023-2-15, which is clearly not correct.

Updated 6 months ago

---

[Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)[Polling delay](https://docs.lightup.ai/docs/polling-delay)
