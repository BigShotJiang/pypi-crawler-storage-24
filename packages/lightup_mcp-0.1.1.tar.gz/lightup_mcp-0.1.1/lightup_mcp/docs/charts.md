---
title: "Charts"
slug: "charts"
excerpt: "Metrics produce charts of the data they collect. These charts appear in several places to help you with data quality analysis:"
hidden: false
metadata:
  title: "Charts"
  description: "Metrics generate charts for data quality analysis, which can be viewed in the Explorer tree, on data asset sub-tabs, and within incidents. These charts include various elements like axes, datapoints, incidents, and monitor thresholds, and can be sliced for detailed analysis."
  url: "https://docs.lightup.ai/docs/charts"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Charts%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=Metrics%20generate%20charts%20for%20data%20quality%20analysis%2C%20which%20can%20be%20viewed%20in%20the%20Explorer%20tree%2C%20on%20data%20asset%20sub-tabs%2C%20and%20within%20incidents.%20These%20charts%20include%20various%20elements%20like%20axes%2C%20datapoints%2C%20incidents%2C%20and%20monitor%20thresholds%2C%20and%20can%20be%20sliced%20for%20detailed%20analysis.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Charts

Metrics produce charts of the data they collect. These charts appear in several places to help you with data quality analysis:

* **In the Explorer tree** - When you expand a table in the Explorer tree, its metrics appear in the tree below it— select a metric in the tree to view its chart in the main page. In Explorer, a metric's chart includes menus for the metric and its monitors, and a button to open its incidents.

  ![](https://files.readme.io/d336844a32b37eb22bd03d876ef611273dd9cde59c3dbaac7ad070b68a0444fe-Screenshot_2024-10-03_at_4.45.25_PM.webp)
* **On a data asset's Explorer sub-tabs** - When you select a data asset in the Explorer tree, some of the asset's Explorer sub-tabs contain metric charts. These charts also include menus for performing data quality analysis, such as the Expand Incidents button, the Monitors menu and the Metric menu on the Data Delay metric chart depicted below.

  ![](https://files.readme.io/7544e2bbe02ef9faf0dd9b7fe8dfca42d52d73bb2d2a8ca09d37892d50e28177-Screenshot_2024-10-03_at_4.48.34_PM.png)
* **In incidents** - When you open a metric's Incidents menu, the metric's chart appears with all incidents marked, and also listed below the chart in a table. When you open an incident's details, the metric's chart appears on the incident's Chart tab. The metric's chart also includes menus to help you analyze the incident. If you add Metrics of Interest, their charts also appear on the Chart tab, below the chart of the incident's metric.

  ![](https://files.readme.io/5a2dfd8505e2c1dcea61aaa2fbbcd0ff35342d58d8da27eba8543804287c674d-Screenshot_2024-10-03_at_4.49.11_PM.png)

# Chart elements

All metrics except for comparison metrics have charts with an x-axis and a y-axis. Except for distribution metrics (which have multiple values per timestamp), each datapoint on a metric chart shows the metric's value at a point in time. For metrics with Incremental query scope, each datapoint is the metric value at a specific timestamp. For Full Table metrics, no timestamps exist, so datapoints show metric values at the time data was scheduled for collection.

![](https://files.readme.io/a365933-clean.png)
## Chart axes

The x-axis corresponds to time: the timestamp for Incremental metrics, and the scheduled collection time for Full Table metrics. Labels indicate the date of each datapoint.

The y-axis corresponds to the metric's values. On the left, these values are labeled to specify what is measured (in the preceding image, *Value*). On the right, if the chart includes monitor thresholds the label indicates the monitor type.

## Datapoints

A datapoint displays the metric value at a point in time. As depicted above, you can hover on a datapoint to see the value and time. Datapoints are connected to form a graph of your metric, making it easier to see patterns.

## Incidents

An incident appears on the metric chart as a vertical bar followed by a shaded area indicating the incident's duration. For example, the preceding image shows four incidents. The chart shows all incidents in the displayed time range. When you view an incident's detail, the chart zooms in on the period when the incident occurred (some other incidents might still appear on the chart).

## Monitor thresholds

You can choose to view the thresholds for a metric's monitor. If there are several monitors, you'll have to choose which one's thresholds to display. For information about the appearance of different monitor thresholds on metric charts, see [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds).

# Sliced charts

If a metric has slices, its chart is sliced as well. When you select a sliced metric in Explorer:

* Each chart slice has its own Incidents menu.
* Because the slices all share the same metric and monitors, the Monitors menu and the Actions menu appear above the chart slices, to the right of the metric's breadcrumb.
* Below the breadcrumb, you can use the search box to find and select slices to focus on.
* Below the search box, you can filter to only show slices with incidents.

![](https://files.readme.io/d1c7fdea1d5da565036c168c659e71150ea03c03c0905211f14963a563bb7344-Screenshot_2024-10-03_at_4.50.23_PM.webp)

Updated 6 months ago

---

[Data collection](https://docs.lightup.ai/docs/data-collection)[Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
