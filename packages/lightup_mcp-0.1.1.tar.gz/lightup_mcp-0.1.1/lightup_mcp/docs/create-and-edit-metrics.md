---
title: "Create and edit metrics"
slug: "create-and-edit-metrics"
excerpt: "Once you've added some data assets, you can create metrics to measure their data quality. All the metrics described here are deep metrics— metrics that you create to answer more specific data quality questions by querying your data. Typically, you create deep metrics after establishing which assets to focus on, through data profiling and auto metrics."
hidden: false
metadata:
  title: "Create and edit metrics"
  description: "Once you've added some data assets, you can create metrics to measure their data quality. All the metrics described here are deep metrics— metrics that you create to answer more specific data quality questions by querying your data. Typically, you create deep metrics after establishing which assets …"
  url: "https://docs.lightup.ai/docs/create-and-edit-metrics"
  image: ["https://cdn.readme.io/og-image/create?type=docs&title=Create%20and%20edit%20metrics&projectTitle=Lightup%20Data%20User%20docs&description=Once%20you've%20added%20some%20data%20assets%2C%20you%20can%20create%20metrics%20to%20measure%20their%20data%20quality.%20All%20the%20metrics%20described%20here%20are%20deep%20metrics%E2%80%94%20metrics%20that%20you%20create%20to%20answer%20more%20specific%20data%20quality%20questions%20by%20querying%20your%20data.%20Typically%2C%20you%20create%20deep%20metrics%20after%20establishing%20which%20assets%20%E2%80%A6&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light"]
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Create and edit metrics

Once you've added some data assets, you can create metrics to measure their data quality. All the metrics described here are deep metrics— [metrics](doc:metric-overview) that you create to answer more specific data quality questions by querying your data. Typically, you create deep metrics after establishing which assets to focus on, through [data profiling](doc:set-up-data-profiling) and [auto metrics](doc:autometrics-1).

# Create a metric

To create a metric, we recommend you start in Explorer. When you create a metric in Explorer, the data asset info is filled in for you, streamlining metric configuration.

Metric configuration is different for each type of metric. For steps, see below for a link to the page about the metric type you want to create:

## Column metrics

* [**Aggregation** metrics](https://docs.lightup.ai/docs/aggregation-metrics) measure changes in the result of an aggregate function that you select.
* [**Conformity** metrics](https://docs.lightup.ai/docs/conformity-metrics) measure the validity of data by checking whether values meet one or more conditions that you specify.
* [**Distribution** metrics](https://docs.lightup.ai/docs/distribution-metrics) measure the distribution of values in a specified column.
* [**Null percent** metrics](https://docs.lightup.ai/docs/null-percent-metrics) measure the percent of a column's values that are null.

## Comparison metrics

* [**Compare aggregate** metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics) let you compare one or more pairs of existing metrics for a source table and a target table.
* [**Row by row** metrics](https://docs.lightup.ai/docs/row-by-row-metrics) let you measure data value differences between a source table and a target table, by picking key fields (to match the rows) and which columns' values you want to compare.

## Table metrics

* [**Data delay** metrics](https://docs.lightup.ai/docs/data-delay-metrics) measure delay in the arrival of expected data into data assets. Available for use with tables and schemas.
* [**Data volume** metrics](https://docs.lightup.ai/docs/data-volume-metrics) measure deviations from expected data volumes. Available for use with tables and schemas.

## SQL metrics

[**SQL** metrics](https://docs.lightup.ai/docs/sql-metrics) measure whatever you model with valid SQL, but must include a SELECT statement that meets basic metric query requirements.

# Edit a metric

1. In the Explorer tree, select the data asset that the metric is based on.
2. On the right, find the chart for the metric you want to edit. Then, in its top-right corner select the three vertical dots, and then select **Edit**.

# The Metrics list

The **Metrics** list is an easy way to work with all the metrics in a workspace. To open it, select **Metrics** in the top bar.

![](https://files.readme.io/99f53e8-metrics-list.png)
## Assess metrics at a glance

Tiles across the top of the list display counts of metrics in the workspace:

* **Total** (all metrics)
* **Monitored** (metrics with at least one monitor attached)
* **Ongoing incidents** (metrics currently generating an incident)
* **Live** (metrics currently active)
* **Paused** (metrics currently paused for any reason)
* **Error** (metrics stopped by an exception, or after three query timeouts due to query governance settings)

## Using list controls

Just above the list items, controls let you work with the list:

* **Search** for a metric across columns by name or by attribute. Click the Search box and type or scroll to find a search term, then select a term to filter the list to matching items. You can add multiple search terms to narrow down the displayed items more.
* Create a new metric with **Create Metric +**.
* Select the number of rows to display per page by selecting **Show<n>**.
* Choose which columns to display by clicking on the gear icon. For example, you might want to display **Last Modified By** so you can filter and sort based who made the most recent change to the metric.
* Navigation arrows and page numbers let you jump around in the list.
* The left column lets you select items to perform bulk operations on them. Note that if you select specific items and then add search terms that exclude any of them, non-matching items won't be displayed but will still be selected— if you remove the relevant search terms the items will appear again.

## Working with list items

In the list header, you have more options for working with list items:

* Select the check box to select all items currently displayed on the page. If other pages exist, a banner appears just above the listed items with a link to select the rest of the items. For example, you might have 50 metrics listed per page, 200 live metrics, and 300 metrics total. To select all live metrics, you could search for *Status=Live*, select the check box to select the first page of 50, and then click the banner link to select the remaining live metrics.
* Select a column heading to sort the list using the column's values in ascending order. Select it again to reverse the sort order. Select it a third time to stop sorting using that column.
* Click a value in the **Name** column to open a context menu that lets you do a variety of operations on that metric.
* Select a value in the **Status** column to set the selected metric's status, e.g., to change it from *Live* to *Paused*.

Updated 6 months ago

---

[Configure tables](https://docs.lightup.ai/docs/table-configuration)[Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
