---
title: "Create a monitor manually"
slug: "create-a-monitor-manually"
excerpt: "There are a number of configuration options that you can use to customize your monitor. You access these options from the Add Monitor flow and you can enter this flow two ways:"
hidden: false
metadata:
  title: "Create a monitor manually"
  description: "To customize your monitor, access the **Add Monitor** flow via the **Monitors** List or Explorer, then configure settings in the **Define** and **Train** tabs to set metrics, thresholds, and alerting options before saving and training your monitor."
  url: "https://docs.lightup.ai/docs/create-a-monitor-manually"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Create%20a%20monitor%20manually%20in%20Lightup&projectTitle=Lightup%20Data%20User%20docs&description=To%20customize%20your%20monitor%2C%20access%20the%20**Add%20Monitor**%20flow%20via%20the%20**Monitors**%20List%20or%20Explorer%2C%20then%20configure%20settings%20in%20the%20**Define**%20and%20**Train**%20tabs%20to%20set%20metrics%2C%20thresholds%2C%20and%20alerting%20options%20before%20saving%20and%20training%20your%20monitor.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Create a monitor manually

There are a number of configuration options that you can use to customize your monitor. You access these options from the **Add Monitor** flow and you can enter this flow two ways:

* On the **Monitors** List, select **Add Monitor**.
* From Explorer, when you click **+ Add** you get a short form that lets you add a monitor with no configuration options. At the top of that form you'll see a blue link that says **Manually configure monitor**. This takes you into the **Add Monitor** flow with the metric name pre-filled, and you'll be able to perform all monitor configuration.

Once you enter the **Add Monitor** flow you will see the screen below. The top of the screen shows three tabs, **Define**, **Train**, and **Preview**.

# Define

![](https://files.readme.io/eed0ddf-manual-define-tab-w-status.png)

To create your monitor, in the **Define** pane:

1. If it's not already specified, select the monitor's metric.
2. Select the **Symptom to detect**. For definitions of the options, see [the table of **Define** tab settings](https://docs.lightup.ai/docs/create-a-monitor-manually#monitor-settings-define-tab).
3. If you're creating an anomaly monitor, you can enable **Account for trend** to allow the monitor to include trends in threshold calculations, or enable **Advanced forecasting** to have your monitor create metric forecasts. Note you can't enable both of these settings for the same monitor.
4. Name the monitor.
5. If you want the monitor to go live as soon as you save it, set **Monitor Status** to *Live*. Otherwise, the monitor will be *Paused* (you can then make the monitor *Live* when you view its metric in Explorer).
6. By default, a monitor starts generating incidents as of the moment it goes live. If you want the monitor to identify incidents in historical data, set the **Backfill Incidents Starting** date to have the monitor look for incidents in metric data starting from that date.
7. Optionally, choose an alerting channel and muting schedule. See [Schedules](doc:create-a-schedule) for details on creating a schedule. Select **Mute notifications** to mute notifications just for the monitor.
8. When you're done, select **Next** at the top right corner.

## Monitor settings: Define tab

| Setting | Use case | Options |
| --- | --- | --- |
| Metrics | Choose the metric/metric slice to monitor | Pick from a list of existing metrics/slices. |
| Symptom to Detect | Specify how monitors determine that metric values are out of bounds. | * *Manual threshold*: Select this if you want to set thresholds. * *Values out of expectation*: This is what you should select if you want a generic anomaly monitor. The monitor sets thresholds automatically. * *Sharp change*: An anomaly monitor that allows for gradual changes, generating incidents only when it detects a sudden change. |
| Account for trend | Include trends in anomaly calculations | Enable/disable. Mutually exclusive with Advanced forecasting. |
| Advanced forecasting | Forecasting of metric values | Enable/disable. Mutually exclusive with Account for trend. |
| Backfill Incidents Starting | Identify how far in the past incidents will be detected, once the monitor goes live | Select a date |
| Monitor status | Specify whether the monitor should be Live or Paused when saved | Select a status |
| Manage alerts | Identify a notification channel for incident alerts | Select a notification channel |
| Notifications muting schedule | Identify a schedule during which notifications will be muted | Select a schedule |
| Mute notifications | Turn off incident notifications for the monitor | Enable/disable |
|  |  |  |

# Train

On the **Train** pane, provide values for any relevant settings. The available settings depend on which **Symptom to detect** you chose in the preceding step.

## Manual threshold monitors

![](https://files.readme.io/490fecf-manual-train-tab.png)

1. If you chose *Manual threshold*, set your thresholds here. You can set one threshold, or both upper and lower thresholds, and can use **Values**, **Percent Change**, or **Change** as thresholds. If you choose **Percent Change** or **Change**, you'll also need to set the **Period**— the amount of time to compare against other periods when calculating the percent change.
2. To adjust the detection settings, click the pencil to the right of **Detection Settings** and then select the settings you want in the modal that opens. For help deciding, see [Monitor settings: Train tab](https://docs.lightup.ai/docs/create-a-monitor-manually#monitor-settings-train-tab).
3. Click **Save and train** at the top right corner.
4. After your monitor trains, click **Back** at the top left to return to the metric chart. If you set **Monitor Status** to *Live* on the **Define** tab, the monitor will begin logging new incidents. If the monitor is paused, you can select **Resume** on the metric chart **Monitors** menu to make it live.

Your monitor is now running. View the metric in Explorer and open the **Monitors** menu to see your new monitor in the dropdown. If it detects metric values outside of your thresholds, it generates an incident.

## Anomaly detection monitors

1. Add a training period by clicking **+** to the right of **Training**. A calendar opens where you can select a start date and an end date. An anomaly monitor needs at least two weeks of data to train. You can add multiple training periods. Training periods should only cover time ranges where your metric has known-good behavior. To identify these periods, review your metric's behavior in **Explorer** or in preview.
2. To adjust the detection settings, click the pencil to the right of **Detection Settings** and then select the settings you want in the modal that opens. For help deciding, see [Monitor settings: Train tab](https://docs.lightup.ai/docs/create-a-monitor-manually#monitor-settings-train-tab).
3. Click **Save and train** to train your monitor.
4. After your monitor trains, select **Back** at the top left to return to the metric chart. If **Monitor Status** is *Live*, the monitor will begin logging incidents. If you entered a **Backfill Incidents Starting** date, the monitor will check historical data for incidents as well as logging new incidents. All incidents, historical or otherwise, can be opened from the metric chart in Explorer.

After training has completed and your monitor is live, it starts monitoring. To see it in Explorer on the metric chart, select it from the **Monitors** menu: your new monitor appears in the dropdown. If Lightup's anomaly detection engine detects the metric is outside of bounds, an incident will be generated.

## Monitor settings: Train tab

| Setting | Threshold type | Use case | Options |
| --- | --- | --- | --- |
| Drift Duration | Any | Set the drift duration: the amount of time that a detected anomaly must last before a monitor will log an incident. | Specify an amount and a time unit, e.g., *10 seconds*. |
| Recovery Duration | Any | Set the recovery duration. Once a metric is within threshold, the recovery duration is the amount of time the metric must remain within threshold for the incident to end. Longer recovery durations can cause several short incidents to merge into one. | Specify an amount and a time unit, e.g., *10 seconds*. |
| Aggressiveness | Anomaly detection | Set how sensitive the monitor should be. Low aggressiveness causes the monitor to pad the actual thresholds, and high aggressiveness causes the monitor to detect incidents when metric values are somewhat inside thresholds. | Select a value from 1 to 10. A value of 7 causes the monitor to strictly obey thresholds. |
| Drift Direction | Anomaly detection | Set whether to detect upward/downward drift. | Select an arrow to enable/disable detection in that direction. |
| Incident Learning | Anomaly detection | Set whether to use incident resolution to adjust anomaly detection. | Enable/disable (recommended setting is enabled) |
| Training periods | Anomaly detection | Include training periods with only known-good metric values. | * Select **+** to add a new period * Select an existing training period to edit or delete it (to ensure it has known-good data) |
| Type | Manual thresholds | Set whether to use values or percentage change for thresholds. | * *Value* * *Percent Change* |
| Lower/Upper Threshold Value | Manual thresholds | Values/percentage changes of the thresholds, e.g., from 2 to 12 or from -2% to 10%. | Set at least one threshold. |
| Period | Manual thresholds | Only applies to Percent Change thresholds. Set the periods of time to compare to determine the percent change. | * *Day over Day* * *Week over Week* * *Sample over Sample* |

Updated 6 months ago

---

[Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)[Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
