---
title: "Add data assets to Explorer"
slug: "add-data-assets-to-explorer"
excerpt: "Explorer enables you to navigate and focus on your data asset hierarchy and see both data profiles and data quality metrics associated with those data assets."
hidden: false
metadata:
  title: "Add data assets to Explorer"
  description: "Explorer allows you to navigate your data asset hierarchy, view data profiles, and data quality metrics. You can add datasources, schemas, tables, and columns to the Explorer tree by using various **Manage** tabs to enable data profiles, auto metrics, and configure settings."
  url: "https://docs.lightup.ai/docs/managing-your-explorer-tree"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Explorer%20-%20Add%20data%20assets%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=Explorer%20allows%20you%20to%20navigate%20your%20data%20asset%20hierarchy%2C%20view%20data%20profiles%2C%20and%20data%20quality%20metrics.%20You%20can%20add%20datasources%2C%20schemas%2C%20tables%2C%20and%20columns%20to%20the%20Explorer%20tree%20by%20using%20various%20**Manage**%20tabs%20to%20enable%20data%20profiles%2C%20auto%20metrics%2C%20and%20configure%20settings.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Add data assets to Explorer

Explorer enables you to navigate and focus on your data asset hierarchy and see both data profiles and data quality metrics associated with those data assets.

When you connect to a datasource, it appears in the Explorer tree. To populate the rest of the Explorer tree, you select a data asset in the tree and then use its **Manage** tabs:

* For a datasource, use the **Manage Schemas** tab to add its schemas to the tree.
* For a schema, use the **Manage Data Profiles**, **Manage Auto Metrics**, or **Manage Tables** tab to add its tables to the tree. Tables are added to the tree when you enable their data profiles or metadata metrics, or when you configure them for deep metrics.
* For a table, use the **Manage Columns** tab to add its columns to the tree.

# Add datasources

At the top of the hierarchy are your datasources. To begin populating the Explorer tree, [add your datasources](doc:add-datasources).

# Add schemas

1. Select a datasource, and then select the **Manage Schemas** tab.

   ![](https://files.readme.io/d096f9c-add-schemas.png)
2. On the **Manage Schemas** tab, set toggles as needed:

   * Use the **Active** toggle to enable the schemas you want displayed in the Explorer tree.
   * If you want Lightup to track table changes in a schema, enable the **Table Activity** [auto metric](doc:autometrics-1).
   * Bulk operations are available in all **Manage** *<asset>*\*\* tabs. To enable or disable a setting for multiple data assets at once, select the check box in the left column for each asset you want to change. Then change the setting in any selected row to update all the selected data assets.

# Add tables

There are several ways to add a table to the Explorer tree: enable its data profile, enable any of its metadata metrics, or configure it. We recommend enabling data profiles and/or metadata metrics first to help you understand your tables before configuring them.

## Add all tables from a datasource or schema

If you want to add all the tables from a datasource or schema that's already in the Explorer tree, the quickest way is to select the datasource or schema and then use the buttons on its **Summary** tab to enable all data profiles or metadata metrics. Either action adds all the tables from the selected datasource or schema to Explorer.

![](https://files.readme.io/49f0167-explore-datasource.png)

Note that tables inside of inactive schemas aren't added when you use an **Enable all** button on a datasource. Tables that are already in the tree are unaffected.

## Add specific tables from a schema

To add specific tables to Explorer, you can use schema Explorer tabs (Manage Data Profiles, Manage Auto Metrics, Manage Tables) to add one table at a time, or to select several tables and add them at the same time. We recommend you start by enabling data profiles or metadata metrics, so you can get a better idea of how your table behaves before you configure it for deep metrics.

### Add tables by enabling data profiling

1. Select the schema, and then select its **Manage Data Profiles** tab.

   ![](https://files.readme.io/0e487e7-manage-dprofs.png)
2. For each table you want to profile, switch *on* the **Enable Data Profile** toggle. Note that you can select multiple tables using the checkboxes on the left, and then enable data profiles for them by switching on the toggle for any of the selected tables.

### Add tables by enabling auto metrics

1. Select the schema, and then select its **Manage Auto Metrics** tab.

   ![](https://files.readme.io/c12670e-manage-AM.png)
2. For each table you want to add to Explorer, switch *on* any active toggle. You can select multiple tables using the checkboxes on the left, and then enable metadata metrics for them by switching on the toggle for any of the selected tables. Note that metadata metrics don't have history, so after you enable one you'll want to wait for sufficient datapoints to be collected before you add and train any monitors for it.
3. To enable deep auto metrics, you must first configure the table. You can select **Not Configured** beside the name of any unconfigured table to configure it. After you save the table's configuration, its deep auto metrics toggles become active.

### Add tables by configuring them

1. Select the schema, and then select its **Manage Tables** tab. (Note that for blob storage datasources, you must instead [add a virtual table](doc:add-virtual-tables-blob-storage-only).)

   ![](https://files.readme.io/28445db-manage-tables.png)
2. For each table you want to work with, switch *on* the **Configure** toggle. The table's configuration opens so you can set defaults that metrics based on the table can inherit, such as the timestamp column, the data lag (evaluation delay), and partitions. These defaults are inherited by your data quality metrics. For help, see [Configure tables](doc:table-configuration).

# Add columns

1. Select a table in the Explorer tree, then select its **Manage Columns** tab.

   ![](https://files.readme.io/8a61bbe-manage-columns.png)
2. To add a column to the Explorer tree, switch *on* its **Active** toggle.
3. To change a column's data type, click the **A** or **#** under **Type**, and then select the new data type.
4. To enable the column's auto metrics, switch on the corresponding toggles: **Category Activity**, **Distribution**, and **Null Percent**. Note that the Category Activity auto metric is only available for text columns in tables with Incremental query scope.

Updated 6 months ago

---

[ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)[Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
