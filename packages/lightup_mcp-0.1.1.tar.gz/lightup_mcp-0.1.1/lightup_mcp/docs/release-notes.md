---
title: "Release notes"
slug: "release-notes"
excerpt: "Configure email integrations with flexible digest schedules: Hourly, Daily, or Weekly"
hidden: false
metadata:
  title: "Release notes"
  description: "**Summary:**

The document outlines the release notes for various versions of a software product, detailing new features, improvements, and bug fixes. Key updates include support for Data Profiling for Virtual Tables, enhancements to memory allocation, user experience improvements, and the addition of various integrations and data source supports."
  url: "https://docs.lightup.ai/docs/release-notes"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Release%20Notes%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=**Summary%3A**%0A%0AThe%20document%20outlines%20the%20release%20notes%20for%20various%20versions%20of%20a%20software%20product%2C%20detailing%20new%20features%2C%20improvements%2C%20and%20bug%20fixes.%20Key%20updates%20include%20support%20for%20Data%20Profiling%20for%20Virtual%20Tables%2C%20enhancements%20to%20memory%20allocation%2C%20user%20experience%20improvements%2C%20and%20the%20addition%20of%20various%20integrations%20and%20data%20source%20supports.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Release notes

# 4.23 (22/09/2025)

* **Performance & Enhancements**: Genie responses improvement, Query history cleanup improvement
* **Bug fixes**: Compare aggregate metrics percentage error round off, UI crash fix

# 4.22 (08/09/2025)

* **New api**: Added a new bulk api to update incident status, fetch deleted metrics via api
* **UI Performance & UX Enhancements**: Optimisation of incident listing, details and monitor details
* **Bug fixes**: Query history page related bug fixes, assorted UI fixes
* **Virtual tables**: Enabled virtual tables for Redshift
* **Incorta MV**: Enabled row count and update delay auto metrics for Incorta materialized views

# 4.21 (17/07/2025)

* **Snowflake Key Pair Authentication**: Added key pair authentication for enhanced security and compliance with modern authentication standards
* **UI Performance & UX Enhancements**: Moved metrics and monitors page counters from frontend to backend for faster page loads, added pagination to monitor lists, fixed multiple UI crashes, and introduced Observer role permissions for table sample previews

# 4.20 (10/06/2025)

* Configure email integrations with flexible digest schedules: Hourly, Daily, or Weekly

  ![](https://files.readme.io/72d067648d4cab1abbdbc066ca9d894af70abf7fc06738c6207b09d36f90c19a-Screenshot_2025-06-10_at_6.21.29_PM.png)
* Download comprehensive metrics data directly from the dashboard in CSV format
* Significantly improved load times for Metrics and Monitors listing pages
* Added key pair support for Snowflake authentication
* Reduced boot time for faster application initialization

# 4.19 (05/05/2025)

* Auto configuration is available which can be enabled via the Query governance option . See <https://docs.lightup.ai/docs/query-governance>
* Assorted bug fixes and general api latency improvement.

# 4.18 (04/01/2025)

* You can now setup monitors such that they discard bad (outlier) data and only consider training periods where there are no outliers in the metric data. See <https://docs.lightup.ai/docs/monitor-a-metric#outlier-detection>
* Fixed issues for certain cases where the Lightup explorer page was loading slowly with a large number of metrics

# 4.17 (03/06/2025)

* Support for left and right outer joins for row-by-row metric. Previously, only a full outer join between source and target was supported.
* Support for monitor approval. Now workspace admins can require approval to make changes to both metrics and monitors <https://docs.lightup.ai/docs/monitor-approval>

# 4.16 (01/09/2025)

* Additional metric types supported on Virtual Tables for datasources on which Virtual Tables are supported. See <https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources#setup-metrics>
* Bug fix for issue that was causing hourly summary alerts not to be received with Microsoft Teams integration, and other minor bug fixes

# 4.15 (12/05/2024)

Features

* Monitor improvement providing ability to add slice specific training periods and alerts. See <https://docs.lightup.ai/docs/slice-overrides>
* Minor changes to user interface for improved navigation. Moved action menu items to an overflow menu column on the right on all pages.

![](https://files.readme.io/5ddc8ebed1b72ecd8ae48987b3fbd3b41da80fc5fc7f01f5497648b0d42b83f2-Screenshot_2024-11-26_at_9.49.03_PM.png)

* Fixed a bug that was resulting in digest alerts not being sent

# 4.12 (10/16/2024)

Features

* Added Virtual Tables support for Snowflake and Databricks with row-by-row metric
* Added support for custom seasonality for custom SQL metrics
* Added "Failing records count" as a column on the incidents list page. This allows users to see the count of failing records for incidents that have failing records and to sort incidents by this count.
* Added "Select all" across pages on the Schema "Table configuration" tab

# 4.11 (10/04/2024)

Features

* Introduced a new home page UI that changes user navigation on the home screen

  + Switching between workspaces can now be done from the top panel on the right

    ![](https://files.readme.io/adcb5f68f5f28005aa62149842ad97891a430dcea8497ca40e00a92cc823cfc3-Screenshot_2024-10-04_at_8.56.17_AM.webp)
  + Admin (App admin actions) and workspace settings can be accessed using the config icon on the top panel

    ![](https://files.readme.io/1d88308dd14f4643957f187a59d5c13036bf9e24fea8a07db4060fd7aca75a59-Screenshot_2024-10-04_at_8.05.12_AM.webp)
  + The username icon on the top panel has other user actions and also lists user roles

    ![](https://files.readme.io/103a5100dfc72baa34449656717ca60d119b43abcf1cc1beb64a49546b7959cd-Screenshot_2024-10-04_at_9.18.11_AM.webp)
  + Navigation for data quality related actions such as explorer, list pages for metrics, monitors and incidents, dashboards and datasources can be accessed on the left panel
* Other features

  + Audit logs are now support for tables and views (previously this was only supported for virtual tables)

    ![](https://files.readme.io/ed560ee1a72f1bebfa077535cd8973d33f2c49702ad6c958c493e9098f8df249-Screenshot_2024-10-04_at_9.41.05_AM.webp)
  + Filename of the downloaded output of failing records now contain metric UUID or metric name
  + Incident validation is possible for full table metrics
  + Query governance and history are now available as tabs on individual datasources in explorer

# 4.10 (9/11/2024)

Features

* Added support for Audit logs for Virtual tables. Now you can see the change history that includes username, timestamp and changes to the configuration (including changes to the SQL). See [documentation](https://docs.lightup.ai/docs/audit-logs)
* Added support for Virtual Tables for Incorta with row-by-row metrics

# 4.9 (9/3/2024)

Features

* Added a governance capability that will enable workspace admins to require editors to seek approval before they make changes to metrics. See our [documentation](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics) for more details
* User experience improvements
  + Redesigned workspace tab to separate users and settings
  + Redesigned query governance tab to separate query history and settings

# 4.8 (8/15/2024)

Features

* Added support for Data Profiling for Virtual Tables
* Made improvements to memory allocation during schema scans to improve system performance
* Some user experience improvements
  + .Explorer tree can be collapsed for more horizontal space to view charts and configuration
  + Minor UI improvements to make summary information easily available for schemas and tables

# 4.7 (7/31/2024)

Features

* Added support for Virtual Tables. This capability is useful if you want to create data quality checks on tables that you define in Lightup using SQL. Normally you would create views on the datasource and let Lightup discover the view when it scans the datasource. However, sometimes you may either not have the permissions to create views on the datasource or you may not want to create views directly on the datasource. This capability gives you the flexibility to do that inside Lightup.
  + Only row by row custom metric is supported
  + Only certain auto metrics are supported
  + Only works on Oracle and Postgres

You can see the [documentation on Virtual tables](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources) for more details

# 4.6 (7/18/2024)

**Features**

* Fetch the count of failing records in an incident automatically
  + Introduction of a new query governance flag "Enable failing records count cache" that allows the count of failing records to be fetched and cached automatically. This flag is disabled by default. When disabled, the user has the option to use the "Get count" option inside the failing records tab of an incident to retrieve the failed records manually.
  + When the query governance flag is enabled, the count of failing records for an incident is automatically fetched

# 4.5 (7/2/2024)

**Features**

* Support for Materialized Views on the following datasources.
  + Snowflake
  + Databricks
  + AWS Redshift
  + Google BigQuery
* Removal of the default "ORDER BY" clause in the failing records SQL for an Incident, so that users may then use their own "ORDER BY" statements to retrieve failing records

# 4.4 (6/26/2024)

**Features**

* Onboarding process improvements - revised interfaces for activating and configuring schemas, tables, and columns.
* Pause datasource functionality - a datasource can be paused from the datasource menu. This will pause all metrics underneath.
* Added support for recurring alerts - this can be toggled on in integration settings to send a email if an incident persists out of bounds on new metric collections.

# 4.3 (5/30/2024)

**Features**

* Added support for external tables for Redshift
* Added a datasource onboarding checklist (top right of summary tabs in explorer) for easier tracking of setup actions
* Revised interface for enabling autometrics to better support bulk actions

**Improvements**

* Support for <, >, <=, >= for timestamp columns in low-code editor
* Support for custom schedules in compare aggregate metrics
* Improved Jira error messages for better troubleshooting. We will now mirror the error received from Jira if the integration fails.
* Fixed bugs in schema scans

# 4.2 (5/16/2024)

**Features**

* Support for end incident action
* Support external tables for BigQuery, Snowflake and Databricks
* File system events when there are integration errors.
* Search improvements - ID filter for data source and strict matching to resolve discrepancies between custom dashboards and associated report pages
* Support for custom field Lightup DQ Score in Alation
* Added optional garbage collection to keep up older query history, system events, data points for deleted metrics (this is behind a feature flag and can be enabled by your support team if necessary)

**API improvement**

* Support filtering by updated\_ts for incidents

# 4.1 (5/1/2024)

**Features**

* View support added for Oracle, Hive, Athena and Teradata
* Support added for Redshift Serverless
* Low-code where clause conditions updated to include 'In column' and 'Not in column'
* Updated monitor training logic to automatically identify, wait, and retry training when there is not enough data initially. The training status will reflect the monitor is waiting for additional data in this scenario. Previously, the system would error out if there was insufficient data in a period and require user intervention.
* Re-enabled on-premises Jira support

**Improvements**

* Schema scanning failures will not cause the rest of the scan to fail
* Added system events when there are insufficient resources for pods (ie. pods are in pending state for a long time).
* Added support for Teradata logmech credentials
* Allow viewers to update incident status to viewed when they load it
* Allow profiling to be rerun on a full table metric
* Support pagination on manage schemas, tables, columns page

**API changes**

* /usage endpoints changed from GET to POST since there were several arguments that it needed to support.

# 4.0 (4/17/24)

**Features**

* Low code metrics now support more complex where conditions - you can specify individual numbered conditions and then choose to AND, OR, Custom combine them together. Custom will let you specify a complex combination, such as (1 AND 2) OR 3
* Casting support was enhanced across all datasources (except file-based sources) to allow automatic casting of numeric to string data types and vice versa. This will affect results in the data profile, distribution metrics, and available low-code operators.

**Improvements**

* Custom schedules are now available on full-table metrics
* A navigation breadcrumb trail was added to the incident page
* Error messages (such as when debugging a custom SQL validation) now have a copy icon to copy the error text to your clipboard

# 3.25 (3/31/24)

**Features**

* SAP/HANA datasource support is available - please contact support if you would like this enabled in your environment.
* Column masking is now available! From a table's 'Manage Columns' interface, you can choose to mask columns, preventing them from outputting raw data within Lightup (in data profiles, sample data, and failing record queries).

**Improvements**

* Introduced two new toggles to the Query Governance section:
  + Enable Data Storage: Allows Lightup to save row level details currently used in storing row-by-row comparison failing records. This data can be viewed from the metric and downloaded as a csv.
  + Enable Data Samples: Disables capabilities that display row level data (sample data and failing record data)
* Increase max slice count to 60k
* When bulk editing metrics/monitors/incidents a selection banner now shows the number selected across pages and a quick clear option.

**Changes**

* Missing value filling only supports null and zero filling. Previously we supported nan which was found to be no different than null in practice. All metrics that had nan configured will be migrated to using null missing value filling.
* Minor efficiency improvements and security patches.

# 3.24 (3/14/24)

**Enhancements**

* **Multi-column slicing**: you can now leverage multiple columns when adding slicing to a metric.
* **List search improvements**: The list search has been overhauled on metric, monitor, and incident list pages to support more fields. You can add filters from the search dialog box by typing and/or scrolling

**Bug Fixes**

* Incident validations where no data is present are no longer marked as successful
* Added infrastructure monitoring to identify stuck alert channels

# 3.23 (2/29/24)

**Enhancements**

* The left pane is now resizable via drag.
* An optimization has been put in place to avoid “waking” the datasource when a SQL metric is edited. Previously, editing a SQL metric would access the datasource to identify the values for the **Columns** input. This access will no longer be made when you first edit a SQL metric. Instead, if you need to view the columns, at the time you open the **Columns** dropdown you’ll be prompted to first validate your SQL.
* Query scope for metadata metrics is now displayed as “metadata”, to indicate that the scope of the data queried is from metadata tables.
* System event notifications now include the workspace name.
* Minor updates to format of the incident **Activity** tab:
  + Comments are now prefaced with “Comment:”.
  + Activities now include the name of the user who generated them. (System-generated activities contain no username.)

# 3.22 (2/15/24)

**Enhancements**

* If a datasource is paused by a schedule, Connection Status in the Datasources List will now reflect this status:

![](https://files.readme.io/5b8fc90-image1.png)

* The incident activity tab of incident analysis now contains the full history of an incident. This includes when it started, ended, any status changes or validation performed, and comments.

![](https://files.readme.io/d8f188c-image2.png)

* The BigQuery datasource now supports views.
* Activity metrics can now be deleted, similar to all other metrics. Note: improvements in this area are still underway. In a future release you will be able to edit, pause, and resume these metrics.

**Bugs**

* An issue was fixed that restricted the user from specifying a limit on a failing record query on a full table metric. This has been fixed.

# 3.21 (2/1/24)

**Enhancements**

* **Query history**: You can now access the query history for a metric from both Explorer and Incident Analysis. From Explorer, click on the Metric menu to find the Query History menu item.

![](https://files.readme.io/c4f886a-image24.png "image_tooltip")

Similarly from incident analysis, click on the incident’s “...” menu:

![](https://files.readme.io/d0db798-image14.png)

* **Filtering for slices with incidents**: On a sliced metric, you can now select “Only Show Incidents” in Explorer to filter for only slices with incidents:

![](https://files.readme.io/16ba258-image11.png)

* **Failing records**
  + Failing records generated from a failing records query can now be sorted by column
  + You can now download up to 10,000 failing records. To specify the number of records to download, enter a number in the new Limit input box, click Run Query, then Download. Note that the records beyond 100 can be downloaded, but cannot be viewed in the UX.

![](https://files.readme.io/0199dc0-image7.png)

* **Table Activity, Column Activity, and Category Activity metrics:**
  Previously these metrics did not show up in the metric list - you will now see them there. You can additionally view details of the metrics via “Edit metric”. Note: improvements in this area are still underway. In a future release you will be able to delete these metrics from the metric list and edit the metric from “Edit metric”. Currently you can edit some fields but you will not be able to save the changes.
* **Opsgenie**: You can now integrate Lightup with Opsgenie

![](https://files.readme.io/939f9dd-image29.png)

* **Databricks Unity**: Databricks Unity catalog support has been added to Databricks Partner Connect

# 3.20 (1/18/24)

**Enhancements**

* Assignee field for Jira integration can now be selected via an autocomplete field that searches for assignee by name.
* Up to 10,000 failing records can now be downloaded to a csv file.

**Deprecations**

* We are no longer supporting Enterprise on-prem Jira servers (which has been end-of-lifed). Only cloud Jira is supported.

# 3.19 (12/29/23)

**Enhancements**

* Lightup’s new System Events panel provides an improved user experience for viewing asynchronous events that occur during system operation. Events are categorized by level - Error, Warning, or Info. You’ll find the System Events menu under your workspace in the left panel - where “Alerts” used to be. To see details of a system event, click on details and a slide in will appear with details of the errors. Fields in the “Info” section of the details slide in can be clicked on to take you to the object referenced.

![](https://files.readme.io/15a36c4-image12.png "image_tooltip")

You can be notified of system events in a manner similar to the notification system for incidents. From the System Events Configuration tab, select Error, Warning or Info and then select an alerting channel.

![](https://files.readme.io/bc49a09-image22.png "image_tooltip")

The Lightup [System Events documentation](https://docs.lightup.ai/docs/system-events) contains more details, including the list of events that are logged in the System Events panel.

* The Schedules UX has been improved - it now provides a more intuitive UX, particularly for the case where the schedule “never ends”
* Last login has been added to the admin Users page, allowing you to see when a user last logged in to Lightup.
* Clicking on Edit Datasource in Explorer now takes you directly to editing the datasource. Previously it took you to the datasources list page.
* Issues related to paused datasource causing an error popup have been fixed. If a datasource pause causes a query to fail (for example, sample data during preview or in a data profile), the chart will now reflect the reason, rather than an error popup.
* The UX for filling in the lower and upper thresholds in the manual threshold modal has been improved.
* Query Governance “Enforce Sort Key Timestamps” language will now reflect the terminology of the datasource.
* A new design for toasts has been introduced. Rather than the red outline box that disappears, you will now see a “color block” popup which requires you to click on it to close.

**Bugs**

* If incident validation fails after three attempts, an error will be displayed and the metric will be placed into an error state. Previously Lightup continued to try to run validation.

Updated 6 months ago

---

[Roles](https://docs.lightup.ai/docs/roles)[Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
