---
title: "BigQuery"
slug: "bigquery"
excerpt: "Steps to prepare and connect to BigQuery"
hidden: false
metadata:
  title: "BigQuery"
  description: "To set up a Lightup account with BigQuery, create a service account with specific roles and download the JSON key. Then, connect to a BigQuery datasource by uploading the key and configuring the connection settings."
  url: "https://docs.lightup.ai/docs/connect-to-bigquery"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=BigQuery%20connector%20%7C%20Lightup&projectTitle=Lightup%20Data%20User%20docs&description=To%20set%20up%20a%20Lightup%20account%20with%20BigQuery%2C%20create%20a%20service%20account%20with%20specific%20roles%20and%20download%20the%20JSON%20key.%20Then%2C%20connect%20to%20a%20BigQuery%20datasource%20by%20uploading%20the%20key%20and%20configuring%20the%20connection%20settings.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# BigQuery

Steps to prepare and connect to BigQuery

# Lightup account setup

Lightup needs a service account with a JSON key and these BigQuery roles:

* **BigQuery > BigQuery Data Viewer**
* **BigQuery > BigQuery Job User**
* **BigQuery > BigQuery Metadata Viewer**
* **BigQuery > BigQuery Read Session User**
* **BigQuery > BigQuery Resource Viewer**

To work with External Tables, Lightup needs the following additional role

* **Cloud Storage > Storage Object Use**r

## Create a service account and download the JSON credentials certificate

> ❗️
>
> You must have Google Cloud admin permissions to create a service account. Google has documentation on creating a [service account](https://cloud.google.com/iam/docs/service-accounts) and [generating a private key](https://cloud.google.com/storage/docs/authentication#generating-a-private-key).

1. Open the credentials page in the [Google Cloud Platform API Manager](https://console.cloud.google.com/apis/credentials) and, if necessary, select your project:

![](https://files.readme.io/f612d80-connector-open-bq-credentials-page.png "connector-open-bq-credentials-page.png")

2. Click **CREATE CREDENTIALS** and choose **Service account**:

![](https://files.readme.io/cc80458-connector-create-bq-credentials.png "connector-create-bq-credentials.png")

3. Enter a name for the new service account, optionally add a description, and click **CREATE**:

![](https://files.readme.io/7606d8e-connector-create-bq-credentials-name-create.png "connector-create-bq-credentials-name-create.png")

4. Your service account requires these Google BigQuery [predefined roles](https://cloud.google.com/bigquery/access-control#curated_roles_comparison_matrix):

   * **BigQuery > BigQuery Data Viewer**
   * **BigQuery > BigQuery Job User**
   * **BigQuery > BigQuery Metadata Viewer**
   * **BigQuery > BigQuery Read Session User**
   * **BigQuery > BigQuery Resource Viewer**

Select the first role in the **Select a role** field, then click **ADD ANOTHER ROLE** and select the next role.

Repeat to add the remaining roles, then click **CONTINUE.**

![](https://files.readme.io/9785171-bq-role-data-viewer.png "bq-role-data-viewer.png")

5. Click **+ ADD KEY** > **Create new key**.
6. Under **Key type**, select **JSON** and then click **CREATE**.

![](https://files.readme.io/6bce382-connector-BQ-create-File-key.png "connector-BQ-create-File-key.png")

7. The JSON key will be saved to your computer. **BE SURE TO REMEMBER WHERE IT IS SAVED.** After noting the download location, click **CLOSE**:

![](https://files.readme.io/287092b-connector-bq-save-private-key.png "connector-bq-save-private-key.png")

8. At the bottom left, click **DONE.**

# Connect to a BigQuery datasource

1. In the left pane select **Datasources\***
2. In the main page select **Create Datasource +**.
3. Enter a **Datasource Name**, then for **Connector Type** select *BigQuery*.
4. Under **Configure connector**, do one of the following using your [BigQuery service account key](https://cloud.google.com/iam/docs/service-accounts?hl=en#key-types):
   * Drag the service account key file to the **Upload** tab; or select **BROWSE** on the **Upload** tab and then browse to and select your key file.
   * Open the key and copy its JSON code into the **JSON** tab.
5. After entering the required settings and any optional settings that apply, below the **Configure connector** section select **Test Connection**.
6. After a successful connection test, select **Save**.
7. Your new datasource appears in the list of available datasources. By default, these are listed in alphabetical order, so you might have to scroll or change the sort order to see your new datasource.

## Advanced/Schema scan frequency

You can adjust how often scans run for a datasource.

* In section **3 - Advanced**, select a value for **Schema scan frequency**: *Hourly*, *Daily*, or *Weekly*.

# Query Governance

BigQuery datasources support the **Scheduling**, **Enable data storage**, **Maximum backfill duration**, and **Maximum distinct values** query governance settings. For steps, see [Set query governance settings for a datasource](https://docs.lightup.ai/docs/query-governance).

# Date/time data types

These [BigQuery date/time data types](https://cloud.google.com/bigquery/docs/reference/standard-sql/data-types) are supported:

* DATE
* DATETIME
* TIMESTAMP

# Object types

These BigQuery object types are supported:

* Tables
* Views
* Materialized Views
* External Tables

Updated 6 months ago

---

[Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)[Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
