---
title: "Enable table auto metrics"
slug: "enable-table-auto-metrics"
excerpt: "You can use Explorer to enable a table's auto metrics:"
hidden: false
metadata:
  title: "Enable table auto metrics"
  description: "You can enable auto metrics for tables in Explorer by using the Summary tab for all metadata metrics, the Table Health or Auto Metrics tabs for individual tables, and the Manage Auto Metrics tab for multiple tables within a schema."
  url: "https://docs.lightup.ai/docs/enable-table-auto-metrics"
  image: ['https://cdn.readme.io/og-image/create?type=docs&title=Table%20Auto%20Metrics%20%7C%20Lightup%20Docs&projectTitle=Lightup%20Data%20User%20docs&description=You%20can%20enable%20auto%20metrics%20for%20tables%20in%20Explorer%20by%20using%20the%20Summary%20tab%20for%20all%20metadata%20metrics%2C%20the%20Table%20Health%20or%20Auto%20Metrics%20tabs%20for%20individual%20tables%2C%20and%20the%20Manage%20Auto%20Metrics%20tab%20for%20multiple%20tables%20within%20a%20schema.&logoUrl=https%3A%2F%2Ffiles.readme.io%2F0076df6-small-LightUpLogo_light_2x_1.png&color=%233520D1&variant=light']
  robots: "index"
---


## Get Started

* [Welcome to Lightup!](https://docs.lightup.ai/docs/welcome-to-lightup)
* [Quick Start](https://docs.lightup.ai/docs/quick-start)
* [Workspaces](https://docs.lightup.ai/docs/working-in-workspaces)
* [Roles](https://docs.lightup.ai/docs/roles)
* [Release notes](https://docs.lightup.ai/docs/release-notes)
## Explorer

* [Explorer overview](https://docs.lightup.ai/docs/explorer-overview)
* [Datasources](https://docs.lightup.ai/docs/datasources-1)
* [Schemas](https://docs.lightup.ai/docs/schemas)
* [Tables](https://docs.lightup.ai/docs/tables)
## metrics

* [Metrics overview](https://docs.lightup.ai/docs/metric-overview)
* [Auto metrics](https://docs.lightup.ai/docs/autometrics-1)
* [Data collection](https://docs.lightup.ai/docs/data-collection)
* [Charts](https://docs.lightup.ai/docs/charts)
## Data Quality Analysis

* [Data Quality overview](https://docs.lightup.ai/docs/data-quality-with-lightup)
* [Configure datasources](https://docs.lightup.ai/docs/add-datasources)
  + [Query Governance](https://docs.lightup.ai/docs/query-governance)
  + [Amazon S3 bucket (Beta)](https://docs.lightup.ai/docs/s3)
  + [Athena](https://docs.lightup.ai/docs/connect-to-athena)
  + [Azure blob storage (Beta)](https://docs.lightup.ai/docs/azure-blob-storage)
  + [BigQuery](https://docs.lightup.ai/docs/connect-to-bigquery)
  + [Databricks](https://docs.lightup.ai/docs/connect-to-databricks)
  + [Dremio](https://docs.lightup.ai/docs/dremio)
  + [Greenplum](https://docs.lightup.ai/docs/greenplum)
  + [Hive](https://docs.lightup.ai/docs/connect-to-hive)
  + [Incorta](https://docs.lightup.ai/docs/incorta)
  + [Microsoft SQL](https://docs.lightup.ai/docs/connect-to-microsoft-sql)
  + [MySQL](https://docs.lightup.ai/docs/mysql)
  + [Oracle](https://docs.lightup.ai/docs/connect-to-oracle)
  + [Postgres](https://docs.lightup.ai/docs/connect-to-postgres)
  + [Redshift](https://docs.lightup.ai/docs/connect-to-redshift)
  + [SAP HANA](https://docs.lightup.ai/docs/saphana)
  + [Snowflake](https://docs.lightup.ai/docs/connect-to-snowflake)
  + [Teradata](https://docs.lightup.ai/docs/teradata)
  + [ksqlDB (Beta)](https://docs.lightup.ai/docs/ksqldb-streaming)
* [Add data assets to Explorer](https://docs.lightup.ai/docs/managing-your-explorer-tree)
  + [Add virtual tables (Amazon S3 and Azure blob storage)](https://docs.lightup.ai/docs/add-virtual-tables-blob-storage-only)
  + [Add virtual tables on relational datasources](https://docs.lightup.ai/docs/add-virtual-tables-for-relational-datasources)
* [Profile your data](https://docs.lightup.ai/docs/set-up-data-profiling)
* [Column Masking](https://docs.lightup.ai/docs/column-masking)
* [Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)
* [Enable table auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics)
* [Configure tables](https://docs.lightup.ai/docs/table-configuration)
* [Create and edit metrics](https://docs.lightup.ai/docs/create-and-edit-metrics)
  + [Aggregation metrics](https://docs.lightup.ai/docs/aggregation-metrics)
  + [Compare aggregate metrics](https://docs.lightup.ai/docs/compare-aggregate-metrics)
  + [Conformity metrics](https://docs.lightup.ai/docs/conformity-metrics)
  + [Data delay metrics](https://docs.lightup.ai/docs/data-delay-metrics)
  + [Data volume metrics](https://docs.lightup.ai/docs/data-volume-metrics)
  + [Distribution metrics](https://docs.lightup.ai/docs/distribution-metrics)
  + [Null percent metrics](https://docs.lightup.ai/docs/null-percent-metrics)
  + [Row by row metrics](https://docs.lightup.ai/docs/row-by-row-metrics)
  + [SQL metrics](https://docs.lightup.ai/docs/sql-metrics)
  + [String matching in metrics](https://docs.lightup.ai/docs/string-matching-in-metrics)
  + [Preview a metric](https://docs.lightup.ai/docs/preview-a-metric)
  + [Editing metadata metrics](https://docs.lightup.ai/docs/editing-metadata-metrics)
* [Monitor a metric](https://docs.lightup.ai/docs/monitor-a-metric)
  + [Create a monitor from Explorer](https://docs.lightup.ai/docs/create-a-monitor-from-explorer-1)
  + [Default monitor settings](https://docs.lightup.ai/docs/default-monitor-settings)
  + [Create a monitor manually](https://docs.lightup.ai/docs/create-a-monitor-manually)
  + [Viewing monitors and thresholds](https://docs.lightup.ai/docs/viewing-monitors-and-thresholds)
  + [Slice specific training periods and alerts](https://docs.lightup.ai/docs/slice-overrides)
* [Review query history](https://docs.lightup.ai/docs/query-history)
* [Manage incidents](https://docs.lightup.ai/docs/manage-incidents)
* [Analyze an incident](https://docs.lightup.ai/docs/analyze-an-incident)
* [Review DQ in Alation](https://docs.lightup.ai/docs/review-dq-in-alation)
* [Review DQ in Atlan](https://docs.lightup.ai/docs/review-dq-in-atlan)
* [Work with system events](https://docs.lightup.ai/docs/system-events)
## Data Lineage

* [View Data Lineage in Explorer (Beta)](https://docs.lightup.ai/docs/view-data-lineage-in-explorer)
## dashboards

* [Data Quality dashboards](https://docs.lightup.ai/docs/data-quality-dashboards)
* [Incident dashboards](https://docs.lightup.ai/docs/incident-dashboards)
## Administer lightup

* [Create a workspace](https://docs.lightup.ai/docs/prepare-a-workspace)
* [Add Lightup users](https://docs.lightup.ai/docs/manage-lightup-users)
* [Assign workspace roles](https://docs.lightup.ai/docs/workspace-roles)
* [Add a Data Catalog](https://docs.lightup.ai/docs/add-a-data-catalog)
  + [Alation](https://docs.lightup.ai/docs/alation)
  + [Atlan](https://docs.lightup.ai/docs/atlan)
  + [Collibra (Beta)](https://docs.lightup.ai/docs/collibra)
## Metric Configuration

* [Aggregation interval](https://docs.lightup.ai/docs/aggregation-interval)
* [Aggregation timezone](https://docs.lightup.ai/docs/aggregation-time-zone)
* [Backfill duration](https://docs.lightup.ai/docs/backfill-duration)
* [Data collection schedule](https://docs.lightup.ai/docs/data-collection-schedule)
* [Data collection window](https://docs.lightup.ai/docs/data-collection-window)
* [Evaluation delay](https://docs.lightup.ai/docs/evaluation-delay)
* [Failing records query](https://docs.lightup.ai/docs/failing-records-query)
* [Missing value filling](https://docs.lightup.ai/docs/missing-value-filling)
* [Partitions](https://docs.lightup.ai/docs/partitions)
* [Polling delay](https://docs.lightup.ai/docs/polling-delay)
* [Polling interval](https://docs.lightup.ai/docs/polling-interval)
* [Polling timezone](https://docs.lightup.ai/docs/polling-timezone)
* [Query scope](https://docs.lightup.ai/docs/query-scope)
* [Related metrics](https://docs.lightup.ai/docs/related-metrics)
* [Schedules](https://docs.lightup.ai/docs/create-a-schedule)
* [Seasonality](https://docs.lightup.ai/docs/seasonality)
* [Slices](https://docs.lightup.ai/docs/slices)
* [Timestamp](https://docs.lightup.ai/docs/timestamp)
  + [Create a virtual timestamp](https://docs.lightup.ai/docs/create-a-virtual-timestamp)
* [Timestamp timezone](https://docs.lightup.ai/docs/timestamp-timezone)
* [WHERE clause](https://docs.lightup.ai/docs/where-clause)
## Governance

* [Metric approval](https://docs.lightup.ai/docs/admin-approval-for-changes-to-metrics)
* [Metric & Monitor Approval](https://docs.lightup.ai/docs/monitor-approval)
* [Audit logs](https://docs.lightup.ai/docs/audit-logs)
## Integrations

* [Integrations overview](https://docs.lightup.ai/docs/integrations-overview)
* [Email List](https://docs.lightup.ai/docs/email-list)
* [Jira](https://docs.lightup.ai/docs/jira)
* [Microsoft Teams](https://docs.lightup.ai/docs/microsoft-teams)
* [OpsGenie](https://docs.lightup.ai/docs/opsgenie)
* [PagerDuty](https://docs.lightup.ai/docs/pagerduty)
* [ServiceNow](https://docs.lightup.ai/docs/servicenow)
* [Slack](https://docs.lightup.ai/docs/slack)
## Security and privacy

* [Key security features](https://docs.lightup.ai/docs/key-security-features)
* [Privacy policy](https://docs.lightup.ai/docs/privacy-policy)
## Deployment

* [Deployment models](https://docs.lightup.ai/docs/deployment-models)
* [Lightup Cloud](https://docs.lightup.ai/docs/lightup-cloud)
  + [Set up AWS PrivateLink](https://docs.lightup.ai/docs/set-up-aws-privatelink)
  + [Set up AWS VPC peering](https://docs.lightup.ai/docs/set-up-aws-vpc-peering)
* [Lightup Hybrid](https://docs.lightup.ai/docs/lightup-hybrid-prereqs)
* [Add your TLS certificate to Lightup](https://docs.lightup.ai/docs/add-your-tls-certificate-to-lightup)
## AI capabilities

* [Genie: Lightup's GenAI assistant (Beta)](https://docs.lightup.ai/docs/genie-ai-assistant-beta)
## Free Trial

* [Lightup Cloud Free Trial](https://docs.lightup.ai/docs/lightup-cloud-free-trial)
* [Databricks Partner Connect](https://docs.lightup.ai/docs/databricks-partner-connect-start-here)
## Further reading

* [Frequently Asked Questions (FAQ)](https://docs.lightup.ai/docs/faq)
## Python Developer Reference

* [Get Started Developing](https://docs.lightup.ai/docs/get-started-developing)
* [Install lightctl](https://docs.lightup.ai/docs/lightctl-installation)
* [HealthzClient](https://docs.lightup.ai/docs/healthzclient)
* [IncidentClient](https://docs.lightup.ai/docs/incidentclient)
* [MetricClient](https://docs.lightup.ai/docs/metricclient)
* [MonitorClient](https://docs.lightup.ai/docs/monitorclient)
* [ProfilerClient](https://docs.lightup.ai/docs/profilerclient)
* [SourceClient](https://docs.lightup.ai/docs/sourceclient)
* [UserClient](https://docs.lightup.ai/docs/userclient)
* [WorkspaceClient](https://docs.lightup.ai/docs/workspaceclient)
# Enable table auto metrics

You can use Explorer to enable a table's auto metrics:

* You can [enable all metadata metrics for tables inside active schemas](https://docs.lightup.ai/docs/enable-table-auto-metrics#enable-all-metadata-metrics-for-tables-in-active-schemas) by using the buttons on the Summary tab of a datasource or schema. Note that this method only enables metadata metrics— it doesn't provide a way to enable deep auto metrics.
* You can [enable any of one table's auto metrics](https://docs.lightup.ai/docs/enable-table-auto-metrics#enable-a-tables-auto-metrics) by selecting the table in the Explorer tree, and then using the buttons on its Table Health tab or on its Auto Metrics tab.
* You can [enable auto metrics for one or more tables in a schema](https://docs.lightup.ai/docs/enable-table-auto-metrics#enable-auto-metrics-for-tables-in-a-schema) by selecting the schema in the Explorer tree, and then using the toggles on the Manage Auto Metrics tab.

# Enable all metadata metrics for tables in active schemas

You can enable metadata metrics for all tables in a datasource or schema. For a datasource, only tables inside the datasource's active schemas are affected.

1. Select the datasource or schema in the Explorer tree, and then select its **Summary** tab.

   ![](https://files.readme.io/fed4421fe6009fcc2ca4274c1ce40f2c2dfcb3e24a90447df2ef84d635b7cfcf-Screenshot_2024-10-03_at_5.34.54_PM.webp)
2. On the **Summary** tab, under **Enable All Metadata Metrics**, select **Enable all**.

> 🚧
> ### Zero-config of auto metrics
>
> If you have chosen to Auto-configure metrics as part of the datasource governance settings, then auto metrics will get enabled automatically for the tables in any newly enabled schema. (Note: currently only metadata metrics will be auto-configured)

# Enable a table's auto metrics

Note: these procedures only work for tables that are already visible in the Explorer tree.

## Enable auto metrics on the Table Health tab

1. Select a table in the Explorer tree, and then select its **Table Health** tab.

   ![](https://files.readme.io/dd8c49c9bfe92b328bd18be28a826df334b102114ab2d23b2d46dfe75d05e736-Screenshot_2024-10-03_at_5.37.42_PM.webp)
2. In the **Table Level Metrics** section, under **Auto Metrics**, select **Enable** for each auto metric you want to enable. If the table isn't configured yet, first select **Configure table** beside a deep auto metric to configure the table. Then, after you save the table configuration, select **Enable** for each deep auto metric you want to enable.

## Enable auto metrics on the Auto Metrics tab

1. Select a table in the Explorer tree, and then select its **Auto Metrics** tab.

   ![](https://files.readme.io/723aa91fe27ce40864d0dcd041c9089d429d596eaaf6c473a65f9455e41bb794-Screenshot_2024-10-03_at_5.36.06_PM.webp)
2. Select the button for each auto metric you want to enable. For deep auto metrics, if the table isn't configured yet the button lets you configure it— then you can enable the auto metric. Charts for enabled auto metrics appear above the buttons you use to enable the remaining auto metrics, so you might have to scroll down.

   Note that for Microsoft SQL datasources, the Update delay auto metric is only reliable for indexed tables, so you should check each table's data profile to verfiy that it's indexed before you enable Update delay.

# Enable auto metrics for tables in a schema

1. Select a schema in the Explorer tree, and then select its **Manage Auto Metrics** tab.

   ![](https://files.readme.io/2498e88df35a3a7cbfaaa941c13bae86b9f9a526c7b3b20118f3c3d049aae122-Screenshot_2024-10-03_at_5.38.35_PM.webp)
2. For each auto metric you want to enable, switch *on* any active toggle. Note that you can select multiple tables using the checkboxes on the left, and then enable auto metrics for them by switching on the toggle for any of the selected tables.
3. To enable deep auto metrics, you must first configure the table. You can select **Not Configured** beside the name of any unconfigured table to configure it. After you save the table's configuration its deep auto metrics toggles become active.

Updated 6 months ago

---

[Casting between data types](https://docs.lightup.ai/docs/casting-between-data-types)[Configure tables](https://docs.lightup.ai/docs/table-configuration)
