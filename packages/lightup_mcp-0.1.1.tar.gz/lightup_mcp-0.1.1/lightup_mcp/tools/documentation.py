"""
MCP tool for fetching Lightup documentation from local docs folder.
Docs are sourced from S3 (lightup-docs-and-embeddings) and symlinked to docs/.
"""

from pathlib import Path

DOCS_DIR = Path(__file__).parent.parent / "docs"

# Map topics to relevant doc files
TOPIC_DOC_MAP = {
    "metric": [
        "metrics-overview.md",
        "create-and-edit-metrics.md",
        "aggregation-metrics.md",
        "conformity-metrics.md",
        "distribution-metrics.md",
        "null-percent-metrics.md",
        "data-volume-metrics.md",
        "data-delay-metrics.md",
        "sql-metrics.md",
        "compare-aggregate-metrics.md",
        "row-by-row-metrics.md",
        "preview-a-metric.md",
        "auto-metrics.md",
    ],
    "monitor": [
        "monitor-a-metric.md",
        "create-a-monitor-manually.md",
        "create-a-monitor-from-explorer.md",
        "viewing-monitors-and-thresholds.md",
        "default-monitor-settings.md",
    ],
    "datasource": [
        "datasources.md",
        "configure-datasources.md",
        "profile-your-data.md",
        "tables.md",
        "schemas.md",
    ],
    "incident": [
        "manage-incidents.md",
        "analyze-an-incident.md",
    ],
    "schedule": [
        "schedules.md",
        "data-collection-schedule.md",
        "data-collection.md",
    ],
    "slice": [
        "slices.md",
        "slice-specific-training-periods-and-alerts.md",
    ],
    "integration": [
        "integrations-overview.md",
        "slack.md",
        "jira.md",
        "pagerduty.md",
        "microsoft-teams.md",
        "opsgenie.md",
        "servicenow.md",
        "email-list.md",
    ],
}


def get_documentation(topic: str) -> str:
    """
    Fetch Lightup documentation for a given topic.
    Reads from local docs/ folder (symlinked from S3).

    Args:
        topic: Topic to look up. One of: metric, monitor, datasource,
               incident, schedule, slice, integration.
               Or a specific filename like 'sql-metrics.md'.

    Returns:
        Documentation content as a string.
    """
    topic_lower = topic.lower()

    # Check if it's a direct filename request
    if topic_lower.endswith(".md"):
        file_path = DOCS_DIR / topic_lower
        if file_path.exists():
            return _read_doc(file_path)
        return f"Doc file '{topic}' not found."

    # Match to topic group
    matched_files = []
    for key, files in TOPIC_DOC_MAP.items():
        if key in topic_lower:
            matched_files = files
            break

    # Fallback: search filenames for the topic keyword
    if not matched_files:
        matched_files = [
            f.name
            for f in DOCS_DIR.iterdir()
            if topic_lower.replace(" ", "-") in f.name
        ]

    if not matched_files:
        return f"No documentation found for topic: '{topic}'. Available topics: {list(TOPIC_DOC_MAP.keys())}"

    # Return content of matched files (first 2 to avoid overload)
    contents = []
    for filename in matched_files[:2]:
        file_path = DOCS_DIR / filename
        if file_path.exists():
            contents.append(f"### {filename}\n\n{_read_doc(file_path)}")

    return "\n\n---\n\n".join(contents)


def list_documentation_topics() -> list[str]:
    """List all available documentation files."""
    return sorted(f.name for f in DOCS_DIR.iterdir() if f.suffix == ".md")


def _read_doc(file_path: Path) -> str:
    """Read a doc file and strip the frontmatter/nav links."""
    content = file_path.read_text(encoding="utf-8")

    # Strip YAML frontmatter
    if content.startswith("---"):
        end = content.find("---", 3)
        if end != -1:
            content = content[end + 3 :].strip()

    # Strip the nav link section (repeated across all docs)
    # Nav ends before the first # heading that is the actual content
    lines = content.split("\n")
    content_start = 0
    for i, line in enumerate(lines):
        if line.startswith("# ") and i > 10:
            content_start = i
            break

    return "\n".join(lines[content_start:]).strip()
