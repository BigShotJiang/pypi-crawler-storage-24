"""
Lightup MCP Server

Exposes Lightup data engineering operations as MCP tools
for safe agentic/vibe coding workflows.

Runs as HTTP/SSE server on http://localhost:8000
"""

import logging
import sys

import mcp.types as types
import uvicorn
from lightup_mcp.tools.documentation import (
    DOCS_DIR,
    get_documentation,
    list_documentation_topics,
)
from mcp.server import Server
from mcp.server.sse import SseServerTransport
from starlette.applications import Starlette
from starlette.requests import Request
from starlette.responses import Response
from starlette.routing import Mount, Route

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

HOST = "0.0.0.0"
PORT = 8000

app = Server("lightup-mcp")


@app.list_tools()
async def list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name="get_documentation",
            description=(
                "Fetch Lightup product documentation for a given topic. "
                "Use this to answer questions about how Lightup works before calling any action tools. "
                "Topics: metric, monitor, datasource, incident, schedule, slice, integration. "
                "Or pass a specific filename like 'sql-metrics.md'."
            ),
            inputSchema={
                "type": "object",
                "required": ["topic"],
                "properties": {
                    "topic": {
                        "type": "string",
                        "description": "Topic or doc filename to look up (e.g. 'metric', 'monitor', 'sql-metrics.md')",
                    }
                },
            },
        ),
        types.Tool(
            name="list_documentation_topics",
            description="List all available Lightup documentation files.",
            inputSchema={"type": "object", "properties": {}},
        ),
    ]


@app.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    if name == "get_documentation":
        result = get_documentation(arguments["topic"])
        return [types.TextContent(type="text", text=result)]

    if name == "list_documentation_topics":
        topics = list_documentation_topics()
        return [types.TextContent(type="text", text="\n".join(topics))]

    raise ValueError(f"Unknown tool: {name}")


def create_starlette_app() -> Starlette:
    sse = SseServerTransport("/messages/")

    async def handle_sse(request: Request) -> Response:
        async with sse.connect_sse(
            request.scope, request.receive, request._send
        ) as streams:
            await app.run(streams[0], streams[1], app.create_initialization_options())
        return Response()

    return Starlette(
        routes=[
            Route("/sse", endpoint=handle_sse, methods=["GET"]),
            Mount("/messages/", app=sse.handle_post_message),
        ]
    )


def main():
    doc_count = len(list(DOCS_DIR.iterdir())) if DOCS_DIR.exists() else 0
    logger.info("Lightup MCP server starting...")
    logger.info(f"Docs directory: {DOCS_DIR} ({doc_count} files)")
    logger.info("Registered tools: get_documentation, list_documentation_topics")
    logger.info(f"SSE endpoint:  http://{HOST}:{PORT}/sse")
    logger.info(f"Messages endpoint: http://{HOST}:{PORT}/messages/")

    starlette_app = create_starlette_app()
    uvicorn.run(starlette_app, host=HOST, port=PORT)


if __name__ == "__main__":
    main()
