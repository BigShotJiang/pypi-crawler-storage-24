"""
Lightup MCP CLI

Entry point for the lightup-mcp command.

Usage:
    lightup-mcp setup               # interactive setup wizard
    lightup-mcp serve               # start HTTP/SSE server
    lightup-mcp serve --stdio       # start stdio server (used by Claude Desktop)
    lightup-mcp ask "question"      # ask a question via AI
    lightup-mcp config show         # show current config
    lightup-mcp config reset        # delete config
    lightup-mcp doctor              # verify setup
"""

import argparse
import sys


def cmd_setup(args):
    from lightup_mcp.setup_wizard import run_setup

    run_setup()


def cmd_serve(args):
    import uvicorn
    from lightup_mcp.server import HOST, create_starlette_app
    from lightup_mcp.setup_wizard import _kill_port, _port_in_use

    if args.stdio:
        # stdio mode — used by Claude Desktop (spawns process directly)
        import asyncio

        from lightup_mcp.server import app
        from mcp.server.stdio import stdio_server

        async def run():
            async with stdio_server() as (read, write):
                await app.run(read, write, app.create_initialization_options())

        asyncio.run(run())
    else:
        port = args.port
        if _port_in_use(port):
            print(
                f"Port {port} already in use — stopping existing server...",
                end=" ",
                flush=True,
            )
            if _kill_port(port):
                print("done")
            else:
                print("failed — try: lightup-mcp serve --port <other_port>")
                sys.exit(1)

        starlette_app = create_starlette_app()
        uvicorn.run(starlette_app, host=HOST, port=port)


def cmd_ask(args):
    from lightup_mcp.ai.factory import get_ai_provider
    from lightup_mcp.config import load_config

    config = load_config()
    if not config or not config.is_valid():
        print("❌ Not configured. Run: lightup-mcp setup")
        sys.exit(1)

    # MCP server must be running for AI to call tools
    mcp_url = "http://localhost:8000/sse"

    provider = get_ai_provider(config, mcp_url)
    messages = [{"role": "user", "content": args.question}]

    print(f"\nAsking {config.ai_provider}...\n")
    try:
        answer = provider.chat(messages)
        print(answer)
    except Exception as e:
        # Unwrap ExceptionGroup (from anyio TaskGroup) to get real error
        inner = e
        while hasattr(inner, "exceptions") and inner.exceptions:
            inner = inner.exceptions[0]

        msg = str(inner)
        if "credit balance is too low" in msg or "insufficient_quota" in msg:
            print(f"❌ Insufficient credits on your {config.ai_provider} account.")
            print("   Add credits at console.anthropic.com/settings/billing")
        elif "invalid_api_key" in msg or "authentication" in msg.lower():
            print("❌ Invalid API key. Run: lightup-mcp setup")
        elif "connection" in msg.lower() or "connect" in msg.lower():
            print("❌ MCP server not reachable. Run: lightup-mcp serve")
        else:
            print(f"❌ {msg}")
        sys.exit(1)


def cmd_config(args):
    from lightup_mcp.config import CONFIG_FILE, load_config

    if args.action == "show":
        config = load_config()
        if not config:
            print("No config found. Run: lightup-mcp setup")
            return
        # mask API key
        masked_key = (
            config.ai_api_key[:8] + "..." + config.ai_api_key[-4:]
            if len(config.ai_api_key) > 12
            else "***"
        )
        print(f"Host:        {config.host}")
        print(f"Token:       {'***' if config.token else '(not set)'}")
        print(f"AI provider: {config.ai_provider}")
        print(f"AI model:    {config.ai_model}")
        print(f"AI key:      {masked_key if config.ai_api_key else '(not set)'}")
        print(f"Config file: {CONFIG_FILE}")

    elif args.action == "reset":
        if CONFIG_FILE.exists():
            CONFIG_FILE.unlink()
            print("✅ Config deleted")
        else:
            print("No config found")


def cmd_doctor(args):
    from lightup_mcp.config import load_config
    from lightup_mcp.setup_wizard import run_doctor

    config = load_config()
    if not config or not config.is_valid():
        print("❌ Config missing or incomplete — run: lightup-mcp setup")
        return

    run_doctor(config)
    print()


def main():
    parser = argparse.ArgumentParser(
        prog="lightup-mcp",
        description="Lightup MCP — agentic data engineering assistant",
    )
    subparsers = parser.add_subparsers(dest="command")

    # setup
    subparsers.add_parser("setup", help="Interactive setup wizard")

    # serve
    serve_parser = subparsers.add_parser("serve", help="Start MCP server")
    serve_parser.add_argument(
        "--stdio", action="store_true", help="Use stdio transport (for Claude Desktop)"
    )
    serve_parser.add_argument("--host", default="0.0.0.0")
    serve_parser.add_argument("--port", type=int, default=8000)

    # ask
    ask_parser = subparsers.add_parser("ask", help="Ask a question")
    ask_parser.add_argument("question", help="Question to ask")

    # config
    config_parser = subparsers.add_parser("config", help="Manage config")
    config_parser.add_argument("action", choices=["show", "reset"])

    # chat
    subparsers.add_parser("chat", help="Start interactive chat")

    # doctor
    subparsers.add_parser("doctor", help="Verify setup")

    args = parser.parse_args()

    if args.command == "setup":
        cmd_setup(args)
    elif args.command == "serve":
        cmd_serve(args)
    elif args.command == "ask":
        cmd_ask(args)
    elif args.command == "chat":
        from lightup_mcp.config import load_config
        from lightup_mcp.setup_wizard import run_chat

        config = load_config()
        if not config or not config.is_valid():
            print("❌ Not configured. Run: lightup-mcp setup")
            sys.exit(1)
        run_chat(config)
    elif args.command == "config":
        cmd_config(args)
    elif args.command == "doctor":
        cmd_doctor(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
