# lightup-mcp

MCP server for safely vibe coding Lightup data engineering operations via the [Model Context Protocol (MCP)](https://modelcontextprotocol.io).

## What it does

Exposes Lightup platform operations (metrics, datasources, monitors, incidents) as MCP tools so AI coding assistants (Claude, Cursor, etc.) can safely interact with your Lightup workspace. Includes built-in Lightup documentation so Claude can answer product questions without external calls.

## Module structure

```
lightup-mcp/
├── lightup_mcp/
│   ├── server.py              # MCP server entry point
│   └── tools/
│       ├── documentation.py   # get_documentation tool — reads from docs/
│       ├── metrics.py         # metric tools (per use case)
│       ├── monitors.py        # monitor tools (per use case)
│       └── datasources.py     # datasource tools (per use case)
├── lightup_mcp_test/          # tests added per use case
├── skills/
│   ├── lightup-metric.skill.md
│   ├── lightup-monitor.skill.md
│   ├── lightup-datasource.skill.md
│   ├── lightup-incident.skill.md
│   └── lightup-recommend.skill.md
├── docs/                      # Lightup product documentation (132 md files)
├── client/
│   └── test_client.py         # local test client (no Claude Desktop needed)
├── pyproject.toml
└── uv.lock
```

## Setup

```bash
cd lightup-mcp
uv sync
```

## Running the MCP server

### Step 1 — Start the server

```bash
cd lightup-mcp
uv run python -m lightup_mcp.server
```

Server starts on `http://localhost:8000`:
```
INFO  Lightup MCP server starting...
INFO  Docs directory: .../docs (133 files)
INFO  Registered tools: get_documentation, list_documentation_topics
INFO  SSE endpoint:      http://0.0.0.0:8000/sse
INFO  Messages endpoint: http://0.0.0.0:8000/messages/
```

### Step 2 — Connect a client

#### Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "lightup-mcp": {
      "url": "http://localhost:8000/sse"
    }
  }
}
```

Restart Claude Desktop.

#### Cursor

Add to Cursor MCP settings:

```json
{
  "mcpServers": {
    "lightup-mcp": {
      "url": "http://localhost:8000/sse"
    }
  }
}
```

#### Test client (no Claude Desktop needed)

```bash
# Health check
uv run python client/test_client.py

# Ask a question
uv run python client/test_client.py --ask "what are the table level metrics?"

# Fetch a specific doc
uv run python client/test_client.py --doc "sql-metrics.md"

# List all available docs
uv run python client/test_client.py --list-docs

# Connect to remote server
uv run python client/test_client.py --url https://mcp.lightup.ai/sse --ask "what metrics are supported?"
```

## Available MCP tools

| Tool | Description |
|---|---|
| `get_documentation` | Fetch Lightup docs by topic (metric, monitor, datasource, incident, schedule, slice, integration) or filename |
| `list_documentation_topics` | List all 132 available documentation files |
| More tools coming per use case | metrics, monitors, datasources, incidents |

## Skills

Skills are in `skills/` and auto-trigger in Claude based on user prompt context:

| Skill | Triggers on |
|---|---|
| `lightup-metric` | metric questions and actions |
| `lightup-monitor` | monitor questions and actions |
| `lightup-datasource` | datasource exploration |
| `lightup-incident` | incident investigation and resolution |
| `lightup-recommend` | recommendations review and activation |

## Safety model

- Destructive tools (`delete_*`) default to `dry_run=True` — preview before applying
- Read-only tools (list/get) have no restrictions
- All mutations require explicit user confirmation

## Status

> Work in progress — Lightup API client wiring is pending. Documentation tools are fully working.
