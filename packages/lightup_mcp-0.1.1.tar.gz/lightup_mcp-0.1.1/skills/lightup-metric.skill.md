---
name: lightup-metric
description: Apply when user asks anything about Lightup metrics — listing, exploring, previewing, creating, or deleting metrics. Triggers on prompts like "create a metric", "what metrics are supported", "show metrics on this table", "delete a metric", "preview a metric", "aggregation metric", "SQL metric", "conformity metric", "null percent metric", "data volume metric".
allowed-tools: get_documentation, list_documentation_topics, list_metrics, get_metric, preview_metric, create_metric, delete_metric
---

# Lightup Metric Assistant

When the user asks about metrics:
1. Call `get_documentation` with topic `"metric"` to fetch accurate Lightup docs first
2. Use the documentation to answer knowledge questions
3. Use action tools (list_metrics, preview_metric, create_metric, delete_metric) to interact with the user's Lightup workspace

## Workflow rules
- Always call `get_documentation("metric")` before answering "what metrics are supported" type questions
- Always call `preview_metric` before `create_metric`
- Always use `dry_run=True` before `delete_metric`
- Ask for workspace_id if not provided
