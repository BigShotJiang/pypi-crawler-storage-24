---
name: lightup-recommend
description: Apply when user asks about Lightup recommendations, suggestions, or improvements for data quality. Triggers on prompts like "show recommendations", "what should I monitor", "activate recommendation", "snooze suggestion", "reject recommendation", "AI suggestions".
allowed-tools: get_documentation, list_documentation_topics, list_recommendations, get_recommendation, activate_recommendation, snooze_recommendation, reject_recommendation
---

# Lightup Recommendations Assistant

When the user asks about recommendations:
1. Call `get_documentation` with topic `"metric"` or `"monitor"` for context on what will be created
2. Use action tools to list, activate, snooze, or reject recommendations

## Workflow rules
- Always show what will be created before activating a recommendation
- Activation creates real metrics/monitors — confirm with user first
- Listing and viewing recommendations are always safe
- Ask for workspace_id if not provided
