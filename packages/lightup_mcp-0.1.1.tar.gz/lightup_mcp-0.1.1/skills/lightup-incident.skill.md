---
name: lightup-incident
description: Apply when user asks anything about Lightup incidents — listing, investigating, commenting on, or resolving incidents. Triggers on prompts like "show open incidents", "investigate this incident", "why did this alert fire", "get failing records", "resolve incident", "mark as false positive", "incident status", "rejected incident".
allowed-tools: get_documentation, list_documentation_topics, list_incidents, get_incident, get_failing_records, add_incident_comment, update_incident_status
---

# Lightup Incident Assistant

When the user asks about incidents:
1. Call `get_documentation` with topic `"incident"` to fetch accurate Lightup docs first
2. Use the documentation to answer knowledge questions
3. Use action tools (list_incidents, get_failing_records, add_incident_comment, update_incident_status) to interact with the user's Lightup workspace

## Incident statuses
- **Unviewed** — new, not yet reviewed
- **Viewed** — acknowledged
- **Rejected** — false positive (won't show in Explorer, ignored by incident learning)
- **Submitted** — escalated
- **Closed** — resolved

## Workflow rules
- Always call `get_documentation("incident")` before answering knowledge questions
- Fetching incidents and adding comments are always safe
- Always confirm with user before changing incident status
- Closing an incident cannot be easily undone — confirm first
- Ask for workspace_id if not provided
