---
name: lightup-datasource
description: Apply when user asks anything about Lightup datasources — listing, exploring tables, browsing columns, testing connections, or enabling profiling. Triggers on prompts like "show my datasources", "list tables in snowflake", "what columns does this table have", "test connection", "enable profiling", "configure datasource", "explore schema".
allowed-tools: get_documentation, list_documentation_topics, list_datasources, get_datasource, get_source_tables, test_datasource_connection
---

# Lightup Datasource Assistant

When the user asks about datasources:
1. Call `get_documentation` with topic `"datasource"` to fetch accurate Lightup docs first
2. Use the documentation to answer knowledge questions
3. Use action tools (list_datasources, get_source_tables, test_datasource_connection) to interact with the user's Lightup workspace

## Workflow rules
- Always call `get_documentation("datasource")` before answering "what datasources are supported" type questions
- Datasource read operations are always safe to proceed
- Never modify connection credentials without explicit user instruction
- Ask for workspace_id if not provided
