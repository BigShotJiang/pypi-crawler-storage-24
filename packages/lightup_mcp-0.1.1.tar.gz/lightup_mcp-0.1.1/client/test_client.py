"""
Lightup MCP Test Client

Connects to the MCP server via HTTP/SSE.
Start the server first: uv run python -m lightup_mcp.server

Usage:
    # Health check — list tools
    uv run python client/test_client.py

    # Ask a question
    uv run python client/test_client.py --ask "what are the table level metrics?"

    # Fetch a specific doc
    uv run python client/test_client.py --doc "sql-metrics.md"

    # List all available docs
    uv run python client/test_client.py --list-docs

    # Connect to a remote server
    uv run python client/test_client.py --url https://mcp.lightup.ai/sse --ask "what metrics are supported?"
"""

import argparse
import asyncio

from mcp import ClientSession
from mcp.client.sse import sse_client

DEFAULT_URL = "http://localhost:8000/sse"


async def health_check(session: ClientSession):
    tools = await session.list_tools()
    print("Server connected successfully")
    print(f"Available tools ({len(tools.tools)}):")
    for tool in tools.tools:
        print(f"  - {tool.name}: {tool.description}")


async def ask(session: ClientSession, question: str):
    topic = question.lower()
    for keyword in [
        "metric",
        "monitor",
        "datasource",
        "incident",
        "schedule",
        "slice",
        "integration",
    ]:
        if keyword in topic:
            topic = keyword
            break

    print(f"Fetching documentation for topic: '{topic}'...\n")
    result = await session.call_tool("get_documentation", {"topic": topic})
    print(result.content[0].text)


async def fetch_doc(session: ClientSession, filename: str):
    print(f"Fetching doc: {filename}\n")
    result = await session.call_tool("get_documentation", {"topic": filename})
    print(result.content[0].text)


async def list_docs(session: ClientSession):
    result = await session.call_tool("list_documentation_topics", {})
    print("Available documentation files:")
    print(result.content[0].text)


async def main():
    parser = argparse.ArgumentParser(description="Lightup MCP Test Client")
    parser.add_argument(
        "--url",
        type=str,
        default=DEFAULT_URL,
        help=f"MCP server SSE URL (default: {DEFAULT_URL})",
    )
    parser.add_argument("--ask", type=str, help="Ask a question about Lightup")
    parser.add_argument(
        "--doc", type=str, help="Fetch a specific doc file (e.g. sql-metrics.md)"
    )
    parser.add_argument(
        "--list-docs", action="store_true", help="List all available doc files"
    )
    args = parser.parse_args()

    print(f"Connecting to {args.url}...")

    async with sse_client(args.url) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            if args.ask:
                await ask(session, args.ask)
            elif args.doc:
                await fetch_doc(session, args.doc)
            elif args.list_docs:
                await list_docs(session)
            else:
                await health_check(session)


if __name__ == "__main__":
    asyncio.run(main())
