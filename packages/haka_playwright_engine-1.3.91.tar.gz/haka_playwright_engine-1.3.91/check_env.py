#!/usr/bin/env python3
from dotenv import load_dotenv
import os

load_dotenv()
print(f'SCREENSHOT_FULL_PAGE={os.getenv("SCREENSHOT_FULL_PAGE", "NOT_SET")}')
