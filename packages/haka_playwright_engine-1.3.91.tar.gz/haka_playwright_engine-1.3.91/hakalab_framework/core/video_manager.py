#!/usr/bin/env python3
"""
Gestor de videos para el framework Hakalab
Maneja automáticamente la grabación y guardado de videos según configuración
"""
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Optional

# Ruta del último video consolidado (con intro) — los plugins la leen
last_consolidated_video: Optional[str] = None


def clean_filename(filename: str) -> str:
    """Limpia un nombre de archivo para que sea válido en Windows y otros sistemas"""
    # Caracteres no permitidos en nombres de archivo
    invalid_chars = '<>:"/\\|?*'
    
    # Reemplazar caracteres inválidos
    for char in invalid_chars:
        filename = filename.replace(char, '_')
    
    # Reemplazar espacios múltiples con uno solo
    filename = ' '.join(filename.split())
    
    # Limitar longitud
    if len(filename) > 100:
        filename = filename[:100]
    
    return filename.strip()


def generate_video_name(feature_name: str, scenario_name: str, status: str = "") -> str:
    """Genera un nombre de video basado en feature y scenario"""
    # Limpiar nombres
    clean_feature = clean_filename(feature_name)
    clean_scenario = clean_filename(scenario_name)
    
    # Crear nombre base
    if status:
        video_name = f"{status}_{clean_feature}_{clean_scenario}"
    else:
        video_name = f"{clean_feature}_{clean_scenario}"
    
    # Agregar timestamp para evitar conflictos
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    video_name = f"{video_name}_{timestamp}"
    
    return video_name


def _get_ffmpeg_path() -> Optional[str]:
    """
    Busca el binario de ffmpeg. Primero intenta en el PATH del sistema,
    luego intenta obtenerlo desde imageio-ffmpeg (pip install imageio-ffmpeg).
    Retorna la ruta al binario o None si no se encuentra.
    """
    # 1. Intentar ffmpeg del sistema (PATH)
    try:
        subprocess.run(
            ['ffmpeg', '-version'],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=5
        )
        return 'ffmpeg'
    except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
        pass
    
    # 2. Intentar imageio-ffmpeg
    try:
        import imageio_ffmpeg
        ffmpeg_path = imageio_ffmpeg.get_ffmpeg_exe()
        if ffmpeg_path and os.path.exists(ffmpeg_path):
            return ffmpeg_path
    except (ImportError, Exception):
        pass
    
    return None


def _concatenate_with_intro(video_path: str, video_dir: str) -> Optional[str]:
    """
    Si existe base.mp4 en video_dir, concatena el intro con el video del scenario.
    Retorna la ruta del video final concatenado, o None si no se concatenó.
    """
    base_video = os.path.join(video_dir, 'base.mp4')
    
    if not os.path.exists(base_video):
        return None
    
    if os.getenv('VIDEO_INTRO_ENABLED', 'true').lower() == 'false':
        return None
    
    ffmpeg_bin = _get_ffmpeg_path()
    if not ffmpeg_bin:
        print("⚠️ ffmpeg no encontrado. Instala con: pip install imageio-ffmpeg")
        return None
    
    result = _concatenate_single_video(video_path, base_video, ffmpeg_bin)
    if result:
        print(f"🎬 Video intro añadido desde base.mp4 → {result}")
    return result


def _cleanup_temp_files(*paths):
    """Elimina archivos temporales de forma segura"""
    for p in paths:
        try:
            p_path = Path(p) if not isinstance(p, Path) else p
            if p_path.exists():
                p_path.unlink()
        except Exception:
            pass


def save_video_on_scenario_end(context, scenario):
    """
    Guarda el video al final del scenario según la configuración
    Esta función se llama automáticamente desde after_scenario
    """
    try:
        # Verificar si hay página y video habilitado
        if not (hasattr(context, 'page') and context.page and context.page.video):
            return
        
        # Obtener configuración de video
        video_mode = os.getenv('VIDEO_MODE', 'retain-on-failure')
        video_dir = os.getenv('VIDEO_DIR', 'videos')
        
        # Crear directorio si no existe
        os.makedirs(video_dir, exist_ok=True)
        
        # Determinar si guardar el video
        should_save = False
        status_prefix = ""
        
        if video_mode == 'on':
            # Guardar siempre
            should_save = True
            status_prefix = "PASSED" if scenario.status.name == 'passed' else "FAILED"
        elif video_mode == 'retain-on-failure' and scenario.status.name in ('failed', 'error'):
            # Guardar solo si falló
            should_save = True
            status_prefix = "FAILED"
        
        if should_save:
            # Obtener ruta del video temporal
            video_path = context.page.video.path()
            
            if video_path and os.path.exists(video_path):
                # Generar nombre final del video
                feature_name = scenario.feature.name if hasattr(scenario, 'feature') else "Unknown_Feature"
                scenario_name = scenario.name
                
                final_video_name = generate_video_name(feature_name, scenario_name, status_prefix)
                final_video_path = os.path.join(video_dir, f"{final_video_name}.webm")
                
                # Copiar video a ubicación final
                shutil.copy2(video_path, final_video_path)
                
                # Intentar concatenar con video intro (base.mp4)
                concatenated_path = _concatenate_with_intro(final_video_path, video_dir)
                if concatenated_path:
                    final_video_path = concatenated_path
                
                # Mensaje informativo
                if scenario.status.name in ('failed', 'error'):
                    print(f"📹 Video de fallo guardado: {final_video_path}")
                else:
                    print(f"📹 Video guardado: {final_video_path}")
                
                # Guardar ruta en contexto para referencia
                if not hasattr(context, 'saved_videos'):
                    context.saved_videos = []
                context.saved_videos.append(final_video_path)
        
        else:
            # Video no se guarda según configuración
            if video_mode == 'retain-on-failure' and scenario.status == 'passed':
                print("📹 Video no guardado (scenario exitoso, modo retain-on-failure)")
    
    except Exception as e:
        print(f"⚠️ Error guardando video: {e}")


def setup_video_name_for_scenario(context, scenario):
    """
    Configura el nombre del video para el scenario actual
    Esta función se llama automáticamente desde before_scenario
    """
    try:
        # Solo si video está habilitado
        if os.getenv('RECORD_VIDEO', 'false').lower() != 'true':
            return
        
        # Generar nombre base para el video
        feature_name = scenario.feature.name if hasattr(scenario, 'feature') else "Unknown_Feature"
        scenario_name = scenario.name
        
        video_name = generate_video_name(feature_name, scenario_name)
        context.video_name = video_name
        
        # Mensaje informativo (solo en modo debug)
        if os.getenv('HAKALAB_DEBUG', 'false').lower() == 'true':
            print(f"📹 Grabación de video iniciada: {video_name}")
    
    except Exception as e:
        print(f"⚠️ Error configurando nombre de video: {e}")


def get_video_summary(context) -> dict:
    """
    Obtiene un resumen de los videos generados
    """
    try:
        video_dir = os.getenv('VIDEO_DIR', 'videos')
        
        summary = {
            'total_videos': 0,
            'failed_videos': 0,
            'passed_videos': 0,
            'video_directory': video_dir,
            'videos_saved': []
        }
        
        # Contar videos guardados en esta ejecución
        if hasattr(context, 'saved_videos'):
            summary['videos_saved'] = context.saved_videos
            summary['total_videos'] = len(context.saved_videos)
            
            for video_path in context.saved_videos:
                if 'FAILED_' in os.path.basename(video_path):
                    summary['failed_videos'] += 1
                else:
                    summary['passed_videos'] += 1
        
        # Contar todos los videos en el directorio
        if os.path.exists(video_dir):
            all_videos = list(Path(video_dir).glob('*.webm')) + list(Path(video_dir).glob('*.mp4'))
            # Excluir base.mp4 del conteo
            all_videos = [v for v in all_videos if v.name != 'base.mp4']
            summary['total_videos_in_directory'] = len(all_videos)
        else:
            summary['total_videos_in_directory'] = 0
        
        return summary
    
    except Exception as e:
        print(f"⚠️ Error obteniendo resumen de videos: {e}")
        return {
            'total_videos': 0,
            'failed_videos': 0,
            'passed_videos': 0,
            'video_directory': video_dir,
            'videos_saved': [],
            'error': str(e)
        }


def cleanup_old_videos(video_dir: str = None, max_age_hours: int = None):
    """
    Limpia videos antiguos del directorio especificado
    """
    try:
        if video_dir is None:
            video_dir = os.getenv('VIDEO_DIR', 'videos')
        
        if max_age_hours is None:
            max_age_hours = int(os.getenv('VIDEO_MAX_AGE_HOURS', '168'))  # 7 días por defecto
        
        if not os.path.exists(video_dir):
            return
        
        max_age_seconds = max_age_hours * 3600
        current_time = time.time()
        
        video_path = Path(video_dir)
        deleted_count = 0
        
        for pattern in ('*.webm', '*.mp4'):
            for video_file in video_path.glob(pattern):
                # No eliminar base.mp4
                if video_file.name == 'base.mp4':
                    continue
                try:
                    file_age = current_time - video_file.stat().st_mtime
                    if file_age > max_age_seconds:
                        video_file.unlink()
                        deleted_count += 1
                except Exception as e:
                    print(f"⚠️ No se pudo eliminar video antiguo {video_file}: {e}")
        
        if deleted_count > 0:
            print(f"🧹 Videos antiguos eliminados: {deleted_count} archivos (más de {max_age_hours} horas)")
    
    except Exception as e:
        print(f"⚠️ Error limpiando videos antiguos: {e}")


def is_video_recording_enabled() -> bool:
    """
    Verifica si la grabación de video está habilitada
    """
    return os.getenv('RECORD_VIDEO', 'false').lower() == 'true'


def get_video_config() -> dict:
    """
    Obtiene la configuración actual de video
    """
    return {
        'enabled': is_video_recording_enabled(),
        'directory': os.getenv('VIDEO_DIR', 'videos'),
        'size': os.getenv('VIDEO_SIZE', '1280x720'),
        'mode': os.getenv('VIDEO_MODE', 'retain-on-failure'),
        'cleanup_enabled': os.getenv('CLEANUP_OLD_VIDEOS', 'true').lower() == 'true',
        'max_age_hours': int(os.getenv('VIDEO_MAX_AGE_HOURS', '168')),
        'intro_enabled': os.getenv('VIDEO_INTRO_ENABLED', 'true').lower() != 'false',
    }


def process_videos_with_intro(video_dir: str):
    """
    Busca todos los .webm en video_dir y los concatena con base.mp4 si existe.
    Se llama desde after_feature, después de que Playwright finaliza los videos.

    Playwright genera videos con nombres hash aleatorios (ej: a1b2c3d4e5f6.webm).
    Esta función los procesa y genera archivos .mp4 con el intro prepended.
    """
    base_video = os.path.join(video_dir, 'base.mp4')

    if not os.path.exists(base_video):
        return

    # Verificar variable de entorno para deshabilitar intro
    if os.getenv('VIDEO_INTRO_ENABLED', 'true').lower() == 'false':
        return

    ffmpeg_bin = _get_ffmpeg_path()
    if not ffmpeg_bin:
        print("⚠️ ffmpeg no encontrado. Instala con: pip install imageio-ffmpeg")
        return

    # Buscar todos los .webm que no hayan sido procesados
    video_path = Path(video_dir)
    webm_files = list(video_path.glob('*.webm'))

    if not webm_files:
        return

    processed_count = 0
    last_result = None
    for webm_file in webm_files:
        try:
            result = _concatenate_single_video(str(webm_file), base_video, ffmpeg_bin)
            if result:
                processed_count += 1
                last_result = result
        except Exception as e:
            print(f"⚠️ Error procesando video {webm_file.name}: {e}")

    # Renombrar el último video consolidado con nombre descriptivo
    if last_result and os.path.exists(last_result):
        global last_consolidated_video
        from datetime import datetime
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        ext = os.path.splitext(last_result)[1]
        new_name = os.path.join(video_dir, f"video_ejecucion_{timestamp}{ext}")
        try:
            os.rename(last_result, new_name)
            last_consolidated_video = new_name
            print(f"🎬 Video consolidado: {os.path.basename(new_name)}")
        except OSError:
            last_consolidated_video = last_result

    if processed_count > 0:
        print(f"🎬 {processed_count} video(s) procesado(s) con intro desde base.mp4")


def _concatenate_single_video(webm_path: str, base_video: str, ffmpeg_bin: str) -> Optional[str]:
    """
    Concatena base.mp4 (intro) + video.webm (test) en un solo .mp4.
    Usa filter_complex con xfade para una transición suave entre ambos.
    """
    try:
        video_path_obj = Path(webm_path)
        final_mp4 = video_path_obj.with_suffix('.mp4')

        # Primero obtener la duración del base.mp4 para calcular el offset del xfade
        probe_cmd = [
            ffmpeg_bin, '-i', base_video,
            '-show_entries', 'format=duration',
            '-v', 'quiet', '-of', 'csv=p=0'
        ]
        
        # Intentar con ffprobe primero, si no existe usar ffmpeg
        ffprobe_bin = ffmpeg_bin.replace('ffmpeg', 'ffprobe') if 'ffmpeg' in ffmpeg_bin else None
        base_duration = None
        
        if ffprobe_bin:
            try:
                result = subprocess.run(
                    [ffprobe_bin, '-i', base_video,
                     '-show_entries', 'format=duration',
                     '-v', 'quiet', '-of', 'csv=p=0'],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=10
                )
                if result.returncode == 0:
                    base_duration = float(result.stdout.decode().strip())
            except Exception:
                pass
        
        # Si no pudimos obtener la duración, usar 3 segundos como default
        if not base_duration:
            base_duration = 3.0
        
        # Offset del xfade: empieza 0.5s antes de que termine el base
        transition_duration = 0.5
        xfade_offset = max(0, base_duration - transition_duration)

        # filter_complex: escalar ambos a 1280x720, aplicar xfade entre ellos
        filter_str = (
            f'[0:v]scale=1280:720:force_original_aspect_ratio=decrease,'
            f'pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[v0];'
            f'[1:v]scale=1280:720:force_original_aspect_ratio=decrease,'
            f'pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30[v1];'
            f'[v0][v1]xfade=transition=fade:duration={transition_duration}:offset={xfade_offset}[outv]'
        )

        concat_cmd = [
            ffmpeg_bin, '-y',
            '-i', base_video,
            '-i', str(webm_path),
            '-filter_complex', filter_str,
            '-map', '[outv]',
            '-c:v', 'libx264', '-preset', 'fast',
            '-crf', '23', '-pix_fmt', 'yuv420p',
            '-movflags', '+faststart',
            '-an',
            str(final_mp4)
        ]

        result = subprocess.run(
            concat_cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=180
        )

        if result.returncode != 0:
            stderr_msg = result.stderr.decode('utf-8', errors='replace')[:300]
            print(f"⚠️ Error concatenando {video_path_obj.name}: {stderr_msg}")
            _cleanup_temp_files(final_mp4)
            return None

        # Verificar que el archivo final existe y tiene tamaño razonable
        if not final_mp4.exists() or final_mp4.stat().st_size < 1000:
            print(f"⚠️ Video concatenado inválido: {final_mp4}")
            _cleanup_temp_files(final_mp4)
            return None

        # Eliminar el .webm original
        try:
            os.remove(webm_path)
        except OSError:
            pass

        return str(final_mp4)

    except subprocess.TimeoutExpired:
        print(f"⚠️ Timeout procesando video {Path(webm_path).name}")
        return None
    except Exception as e:
        print(f"⚠️ Error concatenando video: {e}")
        return None

