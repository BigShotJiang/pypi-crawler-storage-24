#!/usr/bin/env python3
"""
Azure DevOps Manager - Integración con Azure DevOps
Permite actualizar work items y adjuntar reportes automáticamente
"""
import os
import json
import base64
import logging
from pathlib import Path
from typing import Optional, Dict, Any, List
from datetime import datetime

try:
    import requests
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    print("⚠️ requests no está instalado. Instala con: pip install requests")


class AzureDevOpsManager:
    """
    Gestor de integración con Azure DevOps
    
    Funcionalidades:
    - Actualizar campos de work items (test cases)
    - Adjuntar reportes a work items (tasks)
    - Completamente parametrizable desde .env
    """
    
    def __init__(self, context=None):
        """
        Inicializa el gestor de Azure DevOps
        
        Args:
            context: Contexto de Behave (opcional)
        """
        self.context = context
        self.logger = self._setup_logger()
        self.config = self._load_config()
        self.enabled = self.config.get('enabled', False)
        
        if self.enabled and not REQUESTS_AVAILABLE:
            self.logger.error("❌ Azure DevOps habilitado pero requests no está instalado")
            self.enabled = False
        
        if self.enabled:
            self._validate_config()
    
    def _setup_logger(self) -> logging.Logger:
        """Configura el logger"""
        logger = logging.getLogger('AzureDevOpsManager')
        if not logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            handler.setFormatter(formatter)
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)
        return logger
    
    def _load_config(self) -> Dict[str, Any]:
        """
        Carga la configuración desde variables de entorno
        
        Variables requeridas:
        - AZURE_DEVOPS_ENABLED: true/false
        - AZURE_DEVOPS_ORG: Nombre de la organización
        - AZURE_DEVOPS_PROJECT: Nombre del proyecto
        - AZURE_DEVOPS_PAT: Personal Access Token
        
        Variables opcionales:
        - AZURE_DEVOPS_STATUS_FIELD: Nombre del campo de estado (default: Custom.TestStatus)
        - AZURE_DEVOPS_STATUS_PASSED: Valor para test pasado (default: Passed)
        - AZURE_DEVOPS_STATUS_FAILED: Valor para test fallido (default: Failed)
        - AZURE_DEVOPS_ATTACH_REPORT: true/false (default: true)
        - AZURE_DEVOPS_ATTACH_VIDEO: true/false (default: false)
        - AZURE_DEVOPS_REPORT_PATH: Ruta del reporte (default: reports/report.html)
        """
        return {
            'enabled': os.getenv('AZURE_DEVOPS_ENABLED', 'false').lower() == 'true',
            'organization': os.getenv('AZURE_DEVOPS_ORG', ''),
            'project': os.getenv('AZURE_DEVOPS_PROJECT', ''),
            'pat': os.getenv('AZURE_DEVOPS_PAT', ''),
            'status_field': os.getenv('AZURE_DEVOPS_STATUS_FIELD', 'Custom.TestStatus'),
            'status_passed': os.getenv('AZURE_DEVOPS_STATUS_PASSED', 'Passed'),
            'status_failed': os.getenv('AZURE_DEVOPS_STATUS_FAILED', 'Failed'),
            'attach_report': os.getenv('AZURE_DEVOPS_ATTACH_REPORT', 'true').lower() == 'true',
            'attach_video': os.getenv('AZURE_DEVOPS_ATTACH_VIDEO', 'false').lower() == 'true',
            'report_path': os.getenv('AZURE_DEVOPS_REPORT_PATH', 'reports/report.html'),
            'api_version': os.getenv('AZURE_DEVOPS_API_VERSION', '7.1'),
        }
    
    def _validate_config(self):
        """Valida que la configuración sea correcta"""
        required_fields = ['organization', 'project', 'pat']
        missing_fields = [field for field in required_fields if not self.config.get(field)]
        
        if missing_fields:
            self.logger.error(
                f"❌ Configuración incompleta de Azure DevOps. Faltan: {', '.join(missing_fields)}"
            )
            self.enabled = False
            return
        
        self.logger.info("✅ Configuración de Azure DevOps validada correctamente")
    
    def _get_headers(self) -> Dict[str, str]:
        """Obtiene los headers para las peticiones a Azure DevOps API"""
        pat_encoded = base64.b64encode(f":{self.config['pat']}".encode()).decode()
        return {
            'Authorization': f'Basic {pat_encoded}',
            'Content-Type': 'application/json-patch+json',
            'Accept': 'application/json'
        }
    
    def _get_base_url(self) -> str:
        """Obtiene la URL base de la API de Azure DevOps"""
        org = self.config['organization']
        project = self.config['project']
        api_version = self.config['api_version']
        return f"https://dev.azure.com/{org}/{project}/_apis"
    
    def update_work_item_status(
        self, 
        work_item_id: int, 
        status: str,
        comment: Optional[str] = None
    ) -> bool:
        """
        Actualiza el estado de un work item
        
        Args:
            work_item_id: ID del work item
            status: Estado a establecer (Passed/Failed)
            comment: Comentario opcional
            
        Returns:
            True si se actualizó correctamente, False en caso contrario
        """
        if not self.enabled:
            return False
        
        try:
            url = f"{self._get_base_url()}/wit/workitems/{work_item_id}"
            url += f"?api-version={self.config['api_version']}"
            
            # Construir el body con las operaciones de actualización
            operations = [
                {
                    "op": "add",
                    "path": f"/fields/{self.config['status_field']}",
                    "value": status
                }
            ]
            
            # Agregar comentario si se proporciona
            if comment:
                operations.append({
                    "op": "add",
                    "path": "/fields/System.History",
                    "value": comment
                })
            
            response = requests.patch(
                url,
                headers=self._get_headers(),
                json=operations,
                timeout=30
            )
            
            if response.status_code in [200, 201]:
                self.logger.info(
                    f"✅ Work item {work_item_id} actualizado a estado: {status}"
                )
                return True
            else:
                self.logger.error(
                    f"❌ Error al actualizar work item {work_item_id}: "
                    f"{response.status_code} - {response.text}"
                )
                return False
                
        except Exception as e:
            self.logger.error(f"❌ Excepción al actualizar work item {work_item_id}: {e}")
            return False


    def update_work_item_field(
        self,
        work_item_id: int,
        field_path: str,
        value: str,
        comment: Optional[str] = None
    ) -> bool:
        """
        Actualiza un campo arbitrario de un work item.

        Args:
            work_item_id: ID del work item
            field_path: Ruta del campo (ej: Custom.Estado, System.State)
            value: Valor a establecer
            comment: Comentario opcional (se agrega a System.History)

        Returns:
            True si se actualizó correctamente
        """
        if not self.enabled:
            return False

        try:
            url = f"{self._get_base_url()}/wit/workitems/{work_item_id}"
            url += f"?api-version={self.config['api_version']}"

            operations = [
                {
                    "op": "add",
                    "path": f"/fields/{field_path}",
                    "value": value
                }
            ]

            if comment:
                operations.append({
                    "op": "add",
                    "path": "/fields/System.History",
                    "value": comment
                })

            response = requests.patch(
                url,
                headers=self._get_headers(),
                json=operations,
                timeout=30
            )

            if response.status_code in [200, 201]:
                self.logger.info(
                    f"✅ Work item {work_item_id} campo '{field_path}' = '{value}'"
                )
                return True
            else:
                self.logger.error(
                    f"❌ Error actualizando {field_path} de {work_item_id}: "
                    f"{response.status_code} - {response.text}"
                )
                return False

        except Exception as e:
            self.logger.error(f"❌ Excepción actualizando campo de {work_item_id}: {e}")
            return False

    def add_comment_to_work_item(
        self,
        work_item_id: int,
        comment: str
    ) -> bool:
        """
        Agrega solo un comentario a un work item (sin cambiar campos).

        Args:
            work_item_id: ID del work item
            comment: Texto del comentario

        Returns:
            True si se agregó correctamente
        """
        if not self.enabled:
            return False

        try:
            url = f"{self._get_base_url()}/wit/workitems/{work_item_id}"
            url += f"?api-version={self.config['api_version']}"

            operations = [
                {
                    "op": "add",
                    "path": "/fields/System.History",
                    "value": comment
                }
            ]

            response = requests.patch(
                url,
                headers=self._get_headers(),
                json=operations,
                timeout=30
            )

            if response.status_code in [200, 201]:
                self.logger.info(f"✅ Comentario agregado a work item {work_item_id}")
                return True
            else:
                self.logger.error(
                    f"❌ Error agregando comentario a {work_item_id}: "
                    f"{response.status_code} - {response.text}"
                )
                return False

        except Exception as e:
            self.logger.error(f"❌ Excepción agregando comentario a {work_item_id}: {e}")
            return False

    
    def create_work_item(
        self,
        work_item_type: str,
        title: str,
        description: str = "",
        area_path: str = "",
        iteration_path: str = "",
        extra_fields: Optional[Dict[str, str]] = None
    ) -> Optional[int]:
        """
        Crea un nuevo work item en Azure DevOps.

        Args:
            work_item_type: Tipo de work item (Bug, Task, User Story, etc.)
            title: Título del work item
            description: Descripción (HTML soportado)
            area_path: Area Path (opcional, usa el default del proyecto)
            iteration_path: Iteration Path (opcional)
            extra_fields: Campos adicionales {field_path: value}

        Returns:
            ID del work item creado o None si falla
        """
        if not self.enabled:
            return None

        try:
            # El tipo va en la URL con $
            wi_type_encoded = work_item_type.replace(" ", "%20")
            url = (
                f"{self._get_base_url()}/wit/workitems/${wi_type_encoded}"
                f"?api-version={self.config['api_version']}"
            )

            operations = [
                {"op": "add", "path": "/fields/System.Title", "value": title},
            ]

            if description:
                operations.append(
                    {"op": "add", "path": "/fields/System.Description", "value": description}
                )
            if area_path:
                operations.append(
                    {"op": "add", "path": "/fields/System.AreaPath", "value": area_path}
                )
            if iteration_path:
                operations.append(
                    {"op": "add", "path": "/fields/System.IterationPath", "value": iteration_path}
                )
            if extra_fields:
                for field_path, value in extra_fields.items():
                    operations.append(
                        {"op": "add", "path": f"/fields/{field_path}", "value": value}
                    )

            response = requests.post(
                url,
                headers=self._get_headers(),
                json=operations,
                timeout=30
            )

            if response.status_code in [200, 201]:
                wi_id = response.json().get("id")
                self.logger.info(
                    f"✅ Work item {wi_id} ({work_item_type}) creado: {title}"
                )
                return wi_id
            else:
                self.logger.error(
                    f"❌ Error creando work item ({work_item_type}): "
                    f"{response.status_code} - {response.text}"
                )
                return None

        except Exception as e:
            self.logger.error(f"❌ Excepción creando work item: {e}")
            return None

    def attach_file_to_work_item(
        self,
        work_item_id: int,
        file_path: str,
        comment: Optional[str] = None
    ) -> bool:
        """
        Adjunta un archivo a un work item
        
        Args:
            work_item_id: ID del work item
            file_path: Ruta del archivo a adjuntar
            comment: Comentario opcional
            
        Returns:
            True si se adjuntó correctamente, False en caso contrario
        """
        if not self.enabled:
            return False
        
        try:
            # Verificar que el archivo existe
            file_path_obj = Path(file_path)
            if not file_path_obj.exists():
                self.logger.error(f"❌ Archivo no encontrado: {file_path}")
                return False
            
            # Paso 1: Subir el archivo al attachment store
            upload_url = f"{self._get_base_url()}/wit/attachments"
            upload_url += f"?fileName={file_path_obj.name}&api-version={self.config['api_version']}"
            
            with open(file_path, 'rb') as f:
                file_content = f.read()
            
            upload_headers = {
                'Authorization': self._get_headers()['Authorization'],
                'Content-Type': 'application/octet-stream'
            }
            
            upload_response = requests.post(
                upload_url,
                headers=upload_headers,
                data=file_content,
                timeout=60
            )
            
            if upload_response.status_code not in [200, 201]:
                self.logger.error(
                    f"❌ Error al subir archivo: {upload_response.status_code} - {upload_response.text}"
                )
                return False
            
            attachment_url = upload_response.json().get('url')
            
            # Paso 2: Vincular el attachment al work item
            link_url = f"{self._get_base_url()}/wit/workitems/{work_item_id}"
            link_url += f"?api-version={self.config['api_version']}"
            
            operations = [
                {
                    "op": "add",
                    "path": "/relations/-",
                    "value": {
                        "rel": "AttachedFile",
                        "url": attachment_url,
                        "attributes": {
                            "comment": comment or f"Test report - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                        }
                    }
                }
            ]
            
            link_response = requests.patch(
                link_url,
                headers=self._get_headers(),
                json=operations,
                timeout=30
            )
            
            if link_response.status_code in [200, 201]:
                self.logger.info(
                    f"✅ Archivo adjuntado al work item {work_item_id}: {file_path_obj.name}"
                )
                return True
            else:
                self.logger.error(
                    f"❌ Error al vincular archivo: {link_response.status_code} - {link_response.text}"
                )
                return False
                
        except Exception as e:
            self.logger.error(f"❌ Excepción al adjuntar archivo: {e}")
            return False
    
    def attach_report_to_task(
        self,
        task_id: str,
        report_path: str,
        comment: Optional[str] = None
    ) -> bool:
        """
        Adjunta un reporte HTML a una task de Azure DevOps.
        
        Wrapper simplificado de attach_file_to_work_item para reportes.
        
        Args:
            task_id: ID de la task (puede incluir prefijo como TASK-123 o solo 123)
            report_path: Ruta del archivo de reporte HTML
            comment: Comentario opcional
            
        Returns:
            True si se adjuntó correctamente, False en caso contrario
        """
        # Extraer el ID numérico del tag
        work_item_id = self._extract_work_item_id(task_id)
        
        if not work_item_id:
            self.logger.error(f"❌ No se pudo extraer ID de: {task_id}")
            return False
        
        # Usar comentario por defecto si no se proporciona
        if not comment:
            from datetime import datetime
            comment = f"Test Report - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        return self.attach_file_to_work_item(
            work_item_id,
            report_path,
            comment
        )
    
    def process_scenario_tags(
        self,
        scenario,
        status: str,
        report_path: Optional[str] = None
    ) -> Dict[str, bool]:
        """
        Procesa los tags de un escenario para actualizar Azure DevOps
        
        Convención de tags:
        - Primer tag: ID del test case (ej: @TC-123)
        - Segundo tag: ID de la task para adjuntar reporte (ej: @TASK-456)
        
        Args:
            scenario: Escenario de Behave
            status: Estado del test (Passed/Failed)
            report_path: Ruta del reporte a adjuntar (opcional)
            
        Returns:
            Dict con resultados de las operaciones
        """
        if not self.enabled:
            return {'enabled': False}
        
        results = {
            'enabled': True,
            'test_case_updated': False,
            'report_attached': False,
            'test_case_id': None,
            'task_id': None
        }
        
        if not hasattr(scenario, 'tags') or len(scenario.tags) == 0:
            self.logger.info("ℹ️ Escenario sin tags, no se actualiza Azure DevOps")
            return results
        
        # Extraer IDs de los tags
        test_case_id = self._extract_work_item_id(scenario.tags[0]) if len(scenario.tags) >= 1 else None
        task_id = self._extract_work_item_id(scenario.tags[1]) if len(scenario.tags) >= 2 else None
        
        results['test_case_id'] = test_case_id
        results['task_id'] = task_id
        
        # Actualizar test case
        if test_case_id:
            comment = f"Test ejecutado: {scenario.name} - Estado: {status}"
            results['test_case_updated'] = self.update_work_item_status(
                test_case_id,
                status,
                comment
            )
        
        # Adjuntar reporte a la task
        if task_id and report_path:
            results['report_attached'] = self.attach_file_to_work_item(
                task_id,
                report_path,
                f"Reporte de test: {scenario.name}"
            )
        
        return results
    
    def _extract_work_item_id(self, tag: str) -> Optional[int]:
        """
        Extrae el ID numérico de un tag
        
        Soporta formatos:
        - @123
        - @TC-123
        - @TASK-123
        - @US-123
        
        Args:
            tag: Tag del escenario
            
        Returns:
            ID numérico o None si no se puede extraer
        """
        import re
        
        # Remover @ si existe
        tag = tag.lstrip('@')
        
        # Buscar números
        match = re.search(r'\d+', tag)
        if match:
            return int(match.group())
        
        return None
    
    def get_work_item_info(self, work_item_id: int) -> Optional[Dict[str, Any]]:
        """
        Obtiene información de un work item
        
        Args:
            work_item_id: ID del work item
            
        Returns:
            Diccionario con la información del work item o None
        """
        if not self.enabled:
            return None
        
        try:
            url = f"{self._get_base_url()}/wit/workitems/{work_item_id}"
            url += f"?api-version={self.config['api_version']}"
            
            response = requests.get(
                url,
                headers=self._get_headers(),
                timeout=30
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                self.logger.error(
                    f"❌ Error al obtener work item {work_item_id}: "
                    f"{response.status_code} - {response.text}"
                )
                return None
                
        except Exception as e:
            self.logger.error(f"❌ Excepción al obtener work item {work_item_id}: {e}")
            return None


# Funciones helper para usar en environment.py
def setup_azure_devops(context):
    """
    Configura Azure DevOps en el contexto
    Llamar desde before_all en environment.py
    """
    context.azure_devops = AzureDevOpsManager(context)
    if context.azure_devops.enabled:
        context.azure_devops.logger.info("🔵 Azure DevOps Manager inicializado")


def process_scenario_azure_devops(context, scenario):
    """
    Procesa un escenario después de su ejecución
    Llamar desde after_scenario en environment.py
    
    Args:
        context: Contexto de Behave
        scenario: Escenario ejecutado
    """
    if not hasattr(context, 'azure_devops') or not context.azure_devops.enabled:
        return
    
    # Determinar el estado del test
    status = context.azure_devops.config['status_passed']
    if scenario.status == 'failed':
        status = context.azure_devops.config['status_failed']
    
    # Obtener ruta del reporte (puede ser personalizada por proyecto)
    report_path = context.azure_devops.config.get('report_path')
    
    # Procesar tags y actualizar Azure DevOps
    results = context.azure_devops.process_scenario_tags(
        scenario,
        status,
        report_path
    )
    
    # Log de resultados
    if results.get('test_case_updated'):
        context.azure_devops.logger.info(
            f"✅ Test case {results['test_case_id']} actualizado en Azure DevOps"
        )
    
    if results.get('report_attached'):
        context.azure_devops.logger.info(
            f"✅ Reporte adjuntado a task {results['task_id']} en Azure DevOps"
        )
