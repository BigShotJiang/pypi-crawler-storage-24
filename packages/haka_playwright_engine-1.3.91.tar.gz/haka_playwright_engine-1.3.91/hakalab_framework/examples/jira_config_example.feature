# Ejemplo de uso de jira_config.json para configuración de Jira
#
# Requisitos:
#   1. Archivo jira_config.json en la raíz del proyecto
#   2. Variables de entorno: JIRA_ENABLED=true, JIRA_URL, JIRA_EMAIL, JIRA_API_TOKEN, JIRA_PROJECT
#
# CONVENCIÓN DE TAGS POR POSICIÓN:
#   Los tags Jira del escenario se mapean por posición a los tipos del JSON:
#
#   jira_config.json:
#     "tags": [
#       { "tipo": "Test", ... },      ← 1er tag Jira del escenario
#       { "tipo": "Historia", ... },   ← 2do tag Jira del escenario
#       { "tipo": "Bug", ... }         ← 3er tag Jira del escenario
#     ]
#
#   Ejemplo en el escenario:
#     @PROJ-100  @PROJ-200  @PROJ-300
#        ↓          ↓          ↓
#      Test     Historia      Bug

Feature: Ejemplo de configuración Jira desde JSON
  Como QA
  Quiero configurar la integración con Jira desde un archivo JSON
  Para controlar qué adjuntos y campos se envían a cada issue

  # ---------------------------------------------------------------
  # Uso automático con el plugin (tags posicionales)
  # ---------------------------------------------------------------

  @PROJ-100 @PROJ-200
  Scenario: Login exitoso reporta a Test y Historia
    # PROJ-100 = Test (1er tag) → se actualiza campo "estado" con "Passed"
    # PROJ-200 = Historia (2do tag) → se actualiza campo "tiene_cobertura" con "Sí"
    Given navego a "${ENV.BASE_URL}/login"
    Then debería ver el texto "Bienvenido"

  @PROJ-101 @PROJ-201 @PROJ-301
  Scenario: Login fallido reporta a Test, Historia y Bug
    # PROJ-101 = Test (1er tag) → se actualiza campo "estado" con "Failed"
    # PROJ-201 = Historia (2do tag) → se actualiza campo "tiene_cobertura"
    # PROJ-301 = Bug (3er tag) → se actualiza campo "prioridad"
    Given navego a "${ENV.BASE_URL}/login"
    Then debería ver el texto "Esto va a fallar"

  # ---------------------------------------------------------------
  # Steps manuales para verificar la configuración
  # ---------------------------------------------------------------

  Scenario: Verificar que la configuración de Jira se carga correctamente
    Given cargo la configuración de Jira por defecto
    Then verifico que la configuración de Jira está cargada correctamente
    And muestro la configuración completa de Jira

  Scenario: Verificar tipos de issue configurados
    Given cargo la configuración de Jira por defecto
    Then verifico que el tipo de issue "Test" existe en la configuración de Jira
    And verifico que el tipo de issue "Historia" existe en la configuración de Jira

  Scenario: Verificar valores permitidos por campo
    Given cargo la configuración de Jira por defecto
    Then verifico que el campo "estado" del tipo "Test" acepta el valor "Failed"
    And verifico que el campo "estado" del tipo "Test" acepta el valor "Passed"
    And verifico que el campo "tipo_test" del tipo "Test" acepta el valor "Automatizado"

  Scenario: Verificar configuración de adjuntos
    Given cargo la configuración de Jira por defecto
    Then verifico que adjuntar HTML está habilitado en la configuración de Jira
    And verifico que adjuntar video está habilitado en la configuración de Jira
