# Inventario Completo de Pasos - Haka Playwright Engine

Documento generado a partir del código fuente real del framework.
Cada paso fue verificado directamente en los archivos de la carpeta `steps/`.

---

## --- Navegación ---

step: voy a la url "{url}"
descripcion: Este paso permite navegar el navegador a una URL específica. Resuelve variables dinámicas en la URL (como ${ENV.BASE_URL}) antes de navegar. Soporta URLs absolutas con protocolo y también URLs relativas que se concatenan con la BASE_URL configurada en el archivo .env. Espera automáticamente a que la página termine de cargar según la configuración de WAIT_UNTIL.

step: voy a la url de la variable "{variable_name}"
descripcion: Este paso permite navegar a una URL almacenada previamente en una variable del framework. Recupera el valor de la variable indicada y lo usa como destino de navegación. Es útil cuando la URL se genera dinámicamente durante la ejecución del test o se extrae de un elemento de la página.

step: recargo la página
descripcion: Este paso permite recargar la página actual del navegador. Equivale a presionar F5 o el botón de recarga. Espera a que la página termine de cargar completamente después de la recarga.

step: voy hacia atrás en el navegador
descripcion: Este paso permite navegar hacia atrás en el historial del navegador, equivalente a presionar el botón de retroceso. Espera a que la página anterior termine de cargar.

step: voy hacia adelante en el navegador
descripcion: Este paso permite navegar hacia adelante en el historial del navegador, equivalente a presionar el botón de avance. Solo funciona si previamente se navegó hacia atrás.

step: la url actual debería ser "{expected_url}"
descripcion: Este paso permite verificar que la URL actual del navegador coincide exactamente con la URL esperada. Resuelve variables dinámicas en la URL esperada antes de comparar. Lanza un error de aserción si las URLs no coinciden.

step: la url actual debería contener "{url_part}"
descripcion: Este paso permite verificar que la URL actual del navegador contiene un texto parcial específico. Es útil para validar que se navegó a una sección correcta sin necesidad de verificar la URL completa.

step: el título de la página debería ser "{expected_title}"
descripcion: Este paso permite verificar que el título de la página actual coincide exactamente con el texto esperado. Compara el valor de document.title con el parámetro proporcionado.

step: el título de la página debería contener "{expected_text}"
descripcion: Este paso permite verificar que el título de la página actual contiene un texto parcial específico. Es útil cuando el título incluye contenido dinámico pero se quiere validar una parte fija.

---

## --- Interacción ---

step: hago click en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer click sobre un elemento web identificado por su localizador. Soporta selectores CSS, XPath, referencias a JSON POMs ($.ARCHIVO.elemento) y localizadores por tipo/valor. Espera automáticamente a que el elemento sea visible y clickeable antes de interactuar.

step: hago doble click en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer doble click sobre un elemento web. Utiliza el mismo sistema de localización que el click simple. Es útil para acciones que requieren doble click como editar celdas de tablas o seleccionar palabras.

step: hago click derecho en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer click derecho (menú contextual) sobre un elemento web. Útil para probar menús contextuales personalizados en aplicaciones web.

step: relleno el campo "{element_name}" con "{text}" con identificador "{identifier}"
descripcion: Este paso permite escribir texto en un campo de entrada (input, textarea). Primero limpia el contenido existente del campo y luego escribe el nuevo texto. Resuelve variables dinámicas en el texto antes de escribir.

step: limpio el campo "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite limpiar el contenido de un campo de entrada. Selecciona todo el texto del campo y lo elimina, dejando el campo vacío.

step: paso el mouse sobre el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite mover el cursor del mouse sobre un elemento web sin hacer click (hover). Es útil para activar tooltips, menús desplegables o efectos visuales que se activan al pasar el mouse.

step: marco el checkbox "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite marcar un checkbox si no está marcado. Verifica el estado actual del checkbox antes de interactuar para evitar desmarcarlo accidentalmente.

step: desmarco el checkbox "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite desmarcar un checkbox si está marcado. Verifica el estado actual antes de interactuar para evitar marcarlo accidentalmente.

step: selecciono la opción "{option}" del select "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite seleccionar una opción de un elemento select/dropdown por su texto visible. Localiza el select y usa la función select_option de Playwright para elegir la opción indicada.

step: selecciono la opción con valor "{value}" del select "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite seleccionar una opción de un elemento select/dropdown por su atributo value. Es útil cuando el texto visible difiere del valor interno de la opción.

step: subo el archivo "{file_path}" en el campo "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite subir un archivo a un campo de tipo file input. Recibe la ruta del archivo y la asigna al campo de carga. Soporta rutas relativas al directorio del proyecto.


---

## --- Aserciones ---

step: debería ver el texto "{text}" en la página
descripcion: Este paso permite verificar que un texto específico es visible en algún lugar de la página actual. Busca el texto en todo el contenido visible del DOM. Lanza un error de aserción si el texto no se encuentra.

step: no debería ver el texto "{text}" en la página
descripcion: Este paso permite verificar que un texto específico NO está visible en la página actual. Es útil para confirmar que mensajes de error desaparecieron o que contenido fue removido correctamente.

step: debería ver el texto "{text}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento específico contiene un texto determinado. Localiza el elemento por su identificador y compara su contenido de texto con el valor esperado.

step: el elemento "{element_name}" debería estar visible con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento web es visible en la página. Utiliza la función is_visible de Playwright para determinar si el elemento está renderizado y visible para el usuario.

step: el elemento "{element_name}" no debería estar visible con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento web NO es visible en la página. Es útil para confirmar que modales se cerraron, elementos se ocultaron o secciones colapsaron correctamente.

step: el elemento "{element_name}" debería estar habilitado con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento web está habilitado para interacción. Comprueba que el atributo disabled no está presente, lo que significa que el usuario puede interactuar con el elemento.

step: el elemento "{element_name}" debería estar deshabilitado con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento web está deshabilitado. Comprueba que el atributo disabled está presente, indicando que el elemento no acepta interacción del usuario.

step: el valor del campo "{element_name}" debería ser "{expected_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el valor actual de un campo de entrada coincide con el valor esperado. Obtiene el atributo value del elemento y lo compara con el parámetro proporcionado.

step: debería haber {count:d} elementos "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que existe un número exacto de elementos que coinciden con el selector proporcionado. Cuenta todos los elementos que coinciden y compara con el número esperado.

step: el checkbox "{element_name}" debería estar marcado con identificador "{identifier}"
descripcion: Este paso permite verificar que un checkbox está en estado marcado (checked). Utiliza la propiedad checked del elemento para determinar su estado actual.

step: el checkbox "{element_name}" no debería estar marcado con identificador "{identifier}"
descripcion: Este paso permite verificar que un checkbox NO está marcado. Es útil para confirmar que una opción fue desmarcada correctamente o que un formulario se reinició.

---

## --- Validaciones Avanzadas ---

step: deberia ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es visible en la página usando Playwright expect. Utiliza expect(locator).to_be_visible() para una verificación robusta con reintentos automáticos.

step: no deberia ver el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO es visible en la página. Utiliza expect(locator).not_to_be_visible() para confirmar que el elemento está oculto o no existe visualmente.

step: deberia ver que el elemento "{element_name}" existe con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento existe en el DOM de la página, independientemente de si es visible o no. Utiliza expect(locator).to_have_count() para confirmar la presencia del elemento.

step: no deberia ver que el elemento "{element_name}" existe con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO existe en el DOM de la página. Utiliza expect(locator).to_have_count(0) para confirmar que el elemento fue removido completamente.

step: verifico que el elemento "{element_name}" tiene la clase CSS "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene una clase CSS específica. Obtiene el atributo class del elemento y verifica que la clase indicada está presente en la lista de clases.

step: verifico que el elemento "{element_name}" no tiene la clase CSS "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento NO tiene una clase CSS específica. Es útil para confirmar que estados visuales como "active", "selected" o "error" fueron removidos.

step: verifico que el elemento "{element_name}" tiene el atributo "{attribute}" con valor "{expected_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un atributo HTML con un valor específico. Obtiene el valor del atributo indicado y lo compara con el valor esperado.

step: verifico que el texto del elemento "{element_name}" coincide con el patrón "{pattern}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento coincide con un patrón de expresión regular. Es útil para validar formatos como fechas, códigos o identificadores con estructura variable.

step: verifico que el texto del elemento "{element_name}" tiene formato de email válido con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento tiene un formato de email válido. Utiliza una expresión regular para validar la estructura básica de una dirección de correo electrónico.

step: verifico que el texto del elemento "{element_name}" es numérico con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto contenido en un elemento es un valor numérico. Intenta convertir el texto a número y lanza error si no es posible.

step: verifico que la longitud del texto del elemento "{element_name}" es "{expected_length}" con identificador "{identifier}"
descripcion: Este paso permite verificar que el texto de un elemento tiene una longitud exacta de caracteres. Es útil para validar campos con longitud fija como códigos postales o números de documento.

step: verifico que la longitud del texto del elemento "{element_name}" está entre "{min_length}" y "{max_length}" con identificador "{identifier}"
descripcion: Este paso permite verificar que la longitud del texto de un elemento está dentro de un rango específico. Es útil para validar campos con restricciones de longitud mínima y máxima.

step: verifico que el elemento "{element_name}" está dentro del viewport con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es visible dentro del área visible del navegador (viewport). Obtiene las coordenadas del elemento y las compara con las dimensiones del viewport.

step: verifico que el elemento "{element_name}" tiene el foco con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene el foco del teclado actualmente. Compara el elemento con document.activeElement para determinar si está enfocado.

step: verifico que el color de fondo del elemento "{element_name}" es "{expected_color}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un color de fondo específico. Obtiene la propiedad CSS background-color del elemento y la compara con el valor esperado.

step: verifico que la propiedad CSS "{property}" del elemento "{element_name}" es "{expected_value}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene una propiedad CSS específica con un valor exacto. Obtiene el valor computado de la propiedad CSS indicada y lo compara con el valor esperado.

step: guardo en la variable "{variable_name}" el valor de la propiedad CSS "{property}" del elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer el valor de una propiedad CSS de un elemento y guardarlo en una variable del framework para uso posterior en otros pasos del escenario.


---

## --- Esperas ---

step: espero {seconds:d} segundos
descripcion: Este paso permite pausar la ejecución del test durante un número específico de segundos. Se recomienda usar solo cuando sea estrictamente necesario, prefiriendo esperas condicionales que son más eficientes y confiables.

step: espero {milliseconds:d} milisegundos
descripcion: Este paso permite pausar la ejecución del test durante un número específico de milisegundos. Ofrece mayor precisión que la espera en segundos para pausas muy cortas.

step: espero a que el elemento "{element_name}" sea visible con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento sea visible en la página. Utiliza el mecanismo de espera de Playwright con timeout configurable. Es la forma recomendada de sincronizar la ejecución con la interfaz.

step: espero a que el elemento "{element_name}" esté oculto con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento deje de ser visible. Es útil para esperar que spinners de carga, overlays o modales desaparezcan antes de continuar.

step: espero a que el elemento "{element_name}" esté habilitado con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento esté habilitado para interacción. Es útil cuando botones o campos se habilitan dinámicamente después de completar ciertas condiciones.

step: espero a que el elemento "{element_name}" contenga el texto "{text}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento contenga un texto específico. Es útil para esperar que contenido dinámico se cargue o actualice en la página.

step: espero a que la url de la página contenga "{url_part}"
descripcion: Este paso permite esperar hasta que la URL del navegador contenga un texto parcial específico. Es útil para esperar redirecciones o cambios de ruta después de acciones como login o envío de formularios.

step: espero a que el título de la página sea "{title}"
descripcion: Este paso permite esperar hasta que el título de la página coincida con el texto esperado. Es útil para confirmar que una navegación se completó correctamente.

step: espero a que la red esté inactiva
descripcion: Este paso permite esperar hasta que no haya peticiones de red activas. Es útil para asegurar que todas las llamadas AJAX o fetch se completaron antes de continuar con validaciones.

step: espero a que el contenido del DOM esté cargado
descripcion: Este paso permite esperar hasta que el evento DOMContentLoaded se haya disparado, indicando que el HTML fue completamente parseado y el DOM está listo para interacción.

step: espero a que el elemento "{element_name}" sea clickeable con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento sea clickeable, es decir, que sea visible, esté habilitado y no esté cubierto por otro elemento. Combina múltiples condiciones de espera.

step: espero a que el select "{element_name}" tenga opciones con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento select tenga opciones cargadas (más de la opción por defecto). Es útil cuando las opciones se cargan dinámicamente desde una API.

step: espero a que el select "{element_name}" tenga al menos {count:d} opciones con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un select tenga al menos N opciones cargadas. Permite especificar un número mínimo de opciones esperadas.

step: espero a que la tabla "{element_name}" tenga filas con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que una tabla HTML tenga al menos una fila de datos cargada. Es útil cuando los datos de la tabla se cargan dinámicamente.

step: espero a que la tabla "{element_name}" tenga al menos {count:d} filas con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que una tabla tenga al menos N filas de datos. Permite especificar un número mínimo de filas esperadas antes de continuar.

step: espero a que la lista "{element_name}" tenga elementos con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que una lista HTML (ul/ol) tenga elementos li cargados. Es útil cuando los items de la lista se cargan dinámicamente.

step: espero a que el elemento "{element_name}" tenga elementos hijos con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento contenedor tenga elementos hijos cargados. Es una espera genérica para cualquier tipo de contenido dinámico.

step: espero a que el elemento "{element_name}" tenga el atributo "{attribute}" en identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento tenga un atributo HTML específico presente, sin importar su valor. Es útil para esperar que un atributo dinámico sea agregado al elemento.

step: espero a que el elemento "{element_name}" tenga el atributo "{attribute}" con valor "{value}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento tenga un atributo HTML con un valor específico. Es útil para esperar cambios de estado reflejados en atributos como data-status o aria-expanded.

step: espero a que el campo "{element_name}" tenga valor con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un campo de entrada tenga algún valor (no esté vacío). Es útil para esperar que campos se auto-completen o se llenen dinámicamente.

step: espero a que el campo "{element_name}" tenga el valor "{value}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un campo de entrada tenga un valor específico. Es útil para esperar que un campo se actualice con un valor calculado o proveniente de una API.

step: espero a que el elemento "{element_name}" tenga la clase "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento tenga una clase CSS específica. Es útil para esperar transiciones de estado visual como "active", "loaded" o "completed".

step: espero a que el elemento "{element_name}" no tenga la clase "{css_class}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento NO tenga una clase CSS específica. Es útil para esperar que termine una animación de carga (ej: esperar que se remueva la clase "loading").

step: espero a que haya al menos {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que haya al menos N elementos que coincidan con el selector proporcionado. Es útil para esperar que se carguen resultados de búsqueda o listas dinámicas.

step: espero a que haya exactamente {count:d} elementos que coinciden con "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que haya exactamente N elementos que coincidan con el selector. Es más estricto que la espera por mínimo y valida un conteo exacto.

step: espero a que el elemento "{element_name}" no esté vacío con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento tenga contenido de texto (textContent no vacío). Es útil para esperar que contenido dinámico se renderice dentro de un contenedor.

step: espero a que el elemento "{element_name}" deje de cambiar con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que el contenido de un elemento se estabilice y deje de cambiar. Es útil para contadores animados, loaders con texto dinámico o elementos que se actualizan frecuentemente.

step: espero a que el spinner de carga desaparezca con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un spinner o indicador de carga desaparezca de la página. Espera a que el elemento deje de ser visible, indicando que la operación de carga terminó.

step: espero a que el elemento "{element_name}" sea removido del DOM con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un elemento sea completamente removido del DOM, no solo ocultado. Utiliza waitForSelector con state='detached' para confirmar la remoción.


---

## --- Timing y Cronómetros ---

step: espero aleatoriamente entre {min_seconds:d} y {max_seconds:d} segundos
descripcion: Este paso permite esperar un tiempo aleatorio dentro de un rango especificado. Es útil para simular comportamiento humano realista en las pruebas, evitando patrones de tiempo predecibles.

step: espero hasta que el elemento "{selector}" sea visible
descripcion: Este paso permite esperar hasta que un elemento identificado por su selector sea visible en la página. Usa el timeout global configurado en el framework.

step: espero hasta que el elemento "{selector}" desaparezca
descripcion: Este paso permite esperar hasta que un elemento deje de ser visible. Es útil para esperar que indicadores de carga o overlays desaparezcan.

step: espero hasta que el elemento "{selector}" esté habilitado
descripcion: Este paso permite esperar hasta que un elemento esté habilitado para interacción del usuario. Verifica que el atributo disabled no esté presente.

step: espero hasta que el elemento "{selector}" contenga el texto "{expected_text}"
descripcion: Este paso permite esperar hasta que un elemento contenga un texto específico. Realiza polling periódico hasta que el texto aparezca o se agote el timeout.

step: espero hasta que la página termine de cargar
descripcion: Este paso permite esperar hasta que la página termine de cargar completamente, incluyendo todos los recursos como imágenes, scripts y hojas de estilo.

step: espero hasta que no haya requests de red pendientes
descripcion: Este paso permite esperar hasta que no haya actividad de red pendiente. Utiliza el estado networkidle de Playwright para determinar que todas las peticiones se completaron.

step: espero con timeout de {timeout:d} segundos hasta que "{selector}" sea visible
descripcion: Este paso permite esperar un elemento con un timeout personalizado diferente al global. Es útil para elementos que tardan más de lo normal en aparecer.

step: establezco el timeout global en {timeout:d} segundos
descripcion: Este paso permite cambiar el timeout global del framework durante la ejecución. Afecta a todas las operaciones posteriores que usen el timeout por defecto.

step: espero hasta que haya {count:d} elementos "{selector}"
descripcion: Este paso permite esperar hasta que exista un número específico de elementos que coincidan con el selector. Realiza polling periódico contando los elementos.

step: espero hasta que la URL contenga "{url_part}"
descripcion: Este paso permite esperar hasta que la URL del navegador contenga un texto parcial. Es útil para esperar redirecciones o cambios de ruta.

step: marco el tiempo de inicio como "{timer_name}"
descripcion: Este paso permite iniciar un cronómetro con un nombre específico. Registra el timestamp actual para poder medir el tiempo transcurrido posteriormente.

step: verifico que el cronómetro "{timer_name}" no exceda {max_seconds:d} segundos
descripcion: Este paso permite verificar que el tiempo transcurrido desde que se inició un cronómetro no excede un límite máximo. Es útil para pruebas de rendimiento y SLAs.

step: muestro el tiempo transcurrido del cronómetro "{timer_name}"
descripcion: Este paso permite mostrar en consola el tiempo transcurrido de un cronómetro específico. Es útil para debugging y análisis de rendimiento durante el desarrollo de tests.

step: espero progresivamente: {wait_pattern}
descripcion: Este paso permite esperar con un patrón progresivo de tiempos. Recibe una lista de segundos separados por comas (ej: "1,2,3,5") y espera cada intervalo secuencialmente. Es útil para implementar backoff progresivo.

---

## --- Variables ---

step: creo la variable "{variable_name}" con valor "{value}"
descripcion: Este paso permite crear una nueva variable en el contexto del framework con un nombre y valor específicos. La variable queda disponible para ser usada en pasos posteriores mediante la sintaxis ${variable_name}.

step: establezco la variable "{variable_name}" con el valor "{value}"
descripcion: Este paso permite crear o actualizar una variable con un valor específico. Si la variable ya existe, su valor se sobrescribe. Resuelve variables dinámicas en el valor proporcionado.

step: genero una variable "{variable_name}" con texto aleatorio de {length:d} caracteres
descripcion: Este paso permite generar una variable con una cadena de texto aleatorio de la longitud especificada. Es útil para crear datos únicos en cada ejecución como nombres de usuario o identificadores.

step: genero una variable "{variable_name}" con número aleatorio entre {min_val:d} y {max_val:d}
descripcion: Este paso permite generar una variable con un número entero aleatorio dentro del rango especificado (inclusive). Es útil para crear datos numéricos variables en cada ejecución.

step: genero una variable "{variable_name}" con timestamp actual
descripcion: Este paso permite generar una variable con el timestamp actual en formato Unix. Es útil para crear identificadores únicos basados en tiempo o para registrar momentos de ejecución.

step: genero una variable "{variable_name}" con fecha actual usando formato "{date_format}"
descripcion: Este paso permite generar una variable con la fecha actual formateada según el patrón especificado (ej: "%Y-%m-%d", "%d/%m/%Y"). Usa los códigos de formato de Python strftime.

step: obtengo la fecha actual y la guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener la fecha actual en formato por defecto y guardarla en una variable. Usa el formato estándar ISO si no se especifica otro.

step: concateno "{text1}" y "{text2}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite concatenar dos textos o valores de variables y guardar el resultado en una nueva variable. Resuelve variables dinámicas en ambos textos antes de concatenar.

step: incremento la variable numérica "{variable_name}" en {increment:d}
descripcion: Este paso permite incrementar el valor de una variable numérica existente en la cantidad especificada. La variable debe contener un valor numérico válido.

step: muestro el valor de la variable "{variable_name}"
descripcion: Este paso permite imprimir en consola el valor actual de una variable. Es útil para debugging durante el desarrollo de tests y para verificar valores intermedios.

step: verifico que la variable "{variable_name}" contiene "{expected_value}"
descripcion: Este paso permite verificar que el valor de una variable contiene un texto parcial específico. Realiza una búsqueda de subcadena en el valor de la variable.

step: verifico que la variable "{variable_name}" es igual a "{expected_value}"
descripcion: Este paso permite verificar que el valor de una variable es exactamente igual al valor esperado. Realiza una comparación estricta de strings.

step: guardo el texto del elemento "{selector}" en la variable "{variable_name}"
descripcion: Este paso permite extraer el texto visible de un elemento web y guardarlo en una variable del framework. Es útil para capturar valores dinámicos de la página para uso posterior.

step: guardo el atributo "{attribute}" del elemento "{selector}" en la variable "{variable_name}"
descripcion: Este paso permite extraer el valor de un atributo HTML de un elemento y guardarlo en una variable. Es útil para capturar valores como href, data-id, value, etc.

step: muestro todas las variables actuales
descripcion: Este paso permite mostrar en consola todas las variables actualmente almacenadas en el framework con sus valores. Es útil para debugging y para entender el estado del contexto.

step: limpio todas las variables del escenario
descripcion: Este paso permite eliminar todas las variables almacenadas en el contexto del escenario actual. Es útil para limpiar el estado entre escenarios o cuando se necesita un contexto limpio.

step: copio la variable "{source_var}" a "{target_var}"
descripcion: Este paso permite copiar el valor de una variable existente a una nueva variable. La variable original mantiene su valor intacto.

step: genero una variable "{variable_name}" con fecha actual en formato "{date_format}" sumando {days:d} días hábiles
descripcion: Este paso permite generar una fecha futura calculando días hábiles (lunes a viernes) a partir de la fecha actual. Es útil para calcular fechas de vencimiento o plazos laborales.


---

## --- Scroll ---

step: hago scroll al elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer scroll automático hasta que un elemento específico sea visible en el viewport. Utiliza scrollIntoView de JavaScript para desplazar la página hasta el elemento indicado.

step: hago scroll al inicio de la página
descripcion: Este paso permite hacer scroll hasta el inicio de la página. Equivale a presionar la tecla Home o desplazarse manualmente hasta arriba.

step: hago scroll al final de la página
descripcion: Este paso permite hacer scroll hasta el final de la página. Equivale a presionar la tecla End o desplazarse manualmente hasta abajo. Es útil para cargar contenido lazy-loaded.

step: hago scroll hacia abajo {pixels:d} píxeles
descripcion: Este paso permite hacer scroll hacia abajo un número específico de píxeles desde la posición actual. Es útil para desplazamientos parciales controlados.

step: hago scroll hacia arriba {pixels:d} píxeles
descripcion: Este paso permite hacer scroll hacia arriba un número específico de píxeles desde la posición actual.

step: hago scroll hacia la izquierda {pixels:d} píxeles
descripcion: Este paso permite hacer scroll horizontal hacia la izquierda un número específico de píxeles. Es útil para páginas con contenido que se extiende horizontalmente.

step: hago scroll hacia la derecha {pixels:d} píxeles
descripcion: Este paso permite hacer scroll horizontal hacia la derecha un número específico de píxeles.

step: hago scroll del elemento "{element_name}" hacia abajo {pixels:d} píxeles con identificador "{identifier}"
descripcion: Este paso permite hacer scroll dentro de un elemento contenedor específico (no de la página completa). Es útil para elementos con overflow scroll como listas o paneles con scroll independiente.

step: hago scroll del elemento "{element_name}" hacia arriba {pixels:d} píxeles con identificador "{identifier}"
descripcion: Este paso permite hacer scroll hacia arriba dentro de un elemento contenedor específico con scroll independiente.

---

## --- Ventanas y Alertas ---

step: cambio a la nueva ventana
descripcion: Este paso permite cambiar el foco del navegador a la ventana o pestaña más recientemente abierta. Es útil cuando una acción abre una nueva ventana o pestaña.

step: cierro la ventana actual
descripcion: Este paso permite cerrar la ventana o pestaña actual del navegador. Después de cerrar, el foco se mueve automáticamente a la ventana anterior.

step: cambio a la ventana con título "{title}"
descripcion: Este paso permite cambiar a una ventana específica buscándola por su título. Implementa reintentos automáticos para manejar casos donde la ventana tarda en cargar su título.

step: cambio a la ventana con url que contiene "{url_part}"
descripcion: Este paso permite cambiar a una ventana específica buscándola por una parte de su URL. Es útil cuando el título no es confiable pero la URL sí.

step: acepto la alerta simple
descripcion: Este paso permite aceptar una alerta de JavaScript (alert, confirm). Configura un listener que espera a que aparezca el diálogo y lo acepta automáticamente.

step: rechazo la alerta
descripcion: Este paso permite rechazar una alerta de JavaScript (dismiss en confirm/prompt). Configura un listener que espera el diálogo y lo rechaza.

step: acepto la alerta con texto "{text}"
descripcion: Este paso permite aceptar una alerta de tipo prompt enviando un texto como respuesta. Es útil para diálogos que solicitan entrada del usuario.

step: obtengo el texto de la alerta y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite capturar el texto de una alerta de JavaScript y guardarlo en una variable del framework para validación posterior.

step: el mensaje de la alerta debería ser "{expected_text}"
descripcion: Este paso permite verificar que el mensaje de la última alerta capturada coincide exactamente con el texto esperado.

step: el mensaje de la alerta debería contener "{expected_text}"
descripcion: Este paso permite verificar que el mensaje de la última alerta capturada contiene un texto parcial específico.

step: cambio al frame "{frame_name}" con identificador "{identifier}"
descripcion: Este paso permite cambiar el contexto de ejecución a un iframe específico dentro de la página. Todas las interacciones posteriores se realizarán dentro del iframe hasta que se cambie al contenido principal.

step: cambio al contenido principal
descripcion: Este paso permite volver al contenido principal de la página después de haber cambiado a un iframe. Restaura el contexto de ejecución al documento principal.

step: tomo una captura de pantalla y la guardo como "{filename}"
descripcion: Este paso permite tomar una captura de pantalla de la página actual y guardarla con un nombre específico. La captura se guarda en el directorio configurado en SCREENSHOTS_DIR.

step: tomo una captura del elemento "{element_name}" y la guardo como "{filename}" con identificador "{identifier}"
descripcion: Este paso permite tomar una captura de pantalla de un elemento específico de la página. Solo captura el área del elemento indicado, no la página completa.

step: extraigo el texto del diálogo lo guardo en la variable "{variable_name}" y cierro el diálogo
descripcion: Este paso permite extraer el texto de un diálogo JavaScript, guardarlo en una variable y cerrar el diálogo en una sola operación. Combina captura y cierre para mayor eficiencia.


---

## --- Modales ---

step: espero a que aparezca el modal "{modal_name}" con identificador "{identifier}"
descripcion: Este paso permite esperar hasta que un modal sea visible en la página. Utiliza espera con timeout configurable para manejar modales que aparecen con animación o delay.

step: cierro el modal "{modal_name}" con identificador "{identifier}"
descripcion: Este paso permite cerrar un modal haciendo click en su botón de cierre o en el overlay. Busca elementos comunes de cierre como botones con clase close o aria-label close.

step: verifico que el modal "{modal_name}" está visible con identificador "{identifier}"
descripcion: Este paso permite verificar que un modal está actualmente visible en la página. Comprueba que el elemento del modal tiene display visible.

step: verifico que el modal "{modal_name}" está cerrado con identificador "{identifier}"
descripcion: Este paso permite verificar que un modal no está visible en la página. Es útil para confirmar que un modal se cerró correctamente después de una acción.

step: hago click en el botón "{button_name}" del modal "{modal_name}" con identificador del modal "{modal_id}" e identificador del botón "{button_id}"
descripcion: Este paso permite hacer click en un botón específico dentro de un modal. Primero localiza el modal y luego busca el botón dentro de su contexto.

---

## --- Tablas ---

step: verifico que la tabla "{table_name}" tiene "{expected_rows}" filas con identificador "{identifier}"
descripcion: Este paso permite verificar que una tabla HTML tiene un número exacto de filas de datos. Cuenta las filas del tbody excluyendo el header.

step: verifico que la tabla "{table_name}" tiene "{expected_columns}" columnas con identificador "{identifier}"
descripcion: Este paso permite verificar que una tabla tiene un número exacto de columnas. Cuenta los elementos th o td del primer row.

step: hago click en la celda de la fila "{row}" columna "{column}" de la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite hacer click en una celda específica de una tabla identificada por número de fila y columna. Las filas y columnas se indexan desde 1.

step: verifico que la celda de la fila "{row}" columna "{column}" contiene "{expected_text}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una celda específica de una tabla contiene un texto determinado. Localiza la celda por fila y columna y compara su contenido.

step: ordeno la tabla "{table_name}" por la columna "{column_name}" con identificador "{identifier}"
descripcion: Este paso permite ordenar una tabla haciendo click en el header de una columna específica. Simula la acción del usuario de hacer click en el encabezado para ordenar.

step: filtro la tabla "{table_name}" por la columna "{column_name}" con valor "{filter_value}" con identificador "{identifier}"
descripcion: Este paso permite filtrar los datos de una tabla por una columna específica con un valor determinado. Busca el campo de filtro asociado a la columna y escribe el valor.

step: selecciono la fila "{row_number}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite seleccionar una fila específica de una tabla haciendo click en ella. Es útil para tablas con selección de filas.

step: obtengo el valor de la celda fila "{row}" columna "{column}" y lo guardo en la variable "{variable_name}" de la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer el texto de una celda específica de una tabla y guardarlo en una variable del framework para uso posterior.

step: guardo en la variable "{variable_name}" el valor de la columna "{column}" de la fila "{row}" en la tabla con identificador "{identifier}"
descripcion: Este paso permite guardar el valor de una celda de tabla en una variable, usando un formato alternativo de parámetros para mayor legibilidad.

step: edito la celda de la fila "{row}" columna "{column}" con valor "{new_value}" en la tabla "{table_name}" con identificador "{identifier}"
descripcion: Este paso permite editar el valor de una celda de tabla. Hace doble click en la celda para activar el modo edición, limpia el contenido y escribe el nuevo valor.

step: exporto los datos de la tabla "{table_name}" y los guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Este paso permite exportar todos los datos de una tabla HTML como una lista de diccionarios y guardarlos en una variable. Cada fila se convierte en un diccionario con las columnas como claves.

---

## --- Entrada Avanzada ---

step: escribo lentamente "{text}" en el campo "{element_name}" con identificador "{identifier}" con delay de {delay:d} milisegundos
descripcion: Este paso permite escribir texto carácter por carácter con un delay configurable entre cada tecla. Simula escritura humana realista para pruebas que requieren comportamiento natural.

step: escribo con errores "{text}" en el campo "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite escribir texto simulando errores de tipeo humanos. Introduce errores aleatorios y los corrige automáticamente con backspace, simulando comportamiento realista.

step: presiono la tecla "{key}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite presionar una tecla específica en un elemento. Soporta teclas especiales como Enter, Tab, Escape, ArrowDown, etc. usando los nombres de teclas de Playwright.

step: presiono la combinación de teclas "{keys}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite presionar una combinación de teclas (ej: "Control+A", "Shift+Tab", "Alt+F4") en un elemento específico. Usa la sintaxis de Playwright para combinaciones.

step: pego texto del portapapeles en el campo "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite pegar el contenido del portapapeles en un campo de entrada. Simula la acción Ctrl+V del usuario.

step: copio el texto del elemento "{element_name}" al portapapeles con identificador "{identifier}"
descripcion: Este paso permite copiar el texto de un elemento al portapapeles del sistema. Selecciona el texto del elemento y ejecuta la acción de copiar.


---

## --- Drag and Drop ---

step: arrastro el elemento "{source_name}" hacia "{target_name}" con identificadores "{source_id}" y "{target_id}"
descripcion: Este paso permite arrastrar un elemento y soltarlo sobre otro elemento. Utiliza múltiples estrategias de drag and drop incluyendo la API nativa de Playwright y fallbacks con JavaScript para máxima compatibilidad.

step: arrastro el elemento "{source_name}" y lo suelto en las coordenadas x={x:d} y={y:d} con identificador "{source_id}"
descripcion: Este paso permite arrastrar un elemento y soltarlo en coordenadas absolutas específicas de la página. Es útil cuando el destino no es un elemento sino una posición en un canvas o área de trabajo.

step: arrastro el elemento "{source_name}" desplazándolo {dx:d} píxeles en x y {dy:d} píxeles en y con identificador "{source_id}"
descripcion: Este paso permite arrastrar un elemento un desplazamiento relativo desde su posición actual. Es útil para sliders, redimensionamiento o movimiento libre de elementos.

---

## --- Archivos CSV ---

step: cargo el archivo CSV "{file_path}" en la variable "{variable_name}"
descripcion: Este paso permite cargar un archivo CSV completo en una variable del framework usando pandas. El contenido queda disponible como DataFrame para filtrado, ordenamiento y extracción de datos en pasos posteriores.

step: filtro el CSV "{csv_var}" donde "{column}" contiene "{value}" y guardo como "{result_var}"
descripcion: Este paso permite filtrar las filas de un CSV cargado donde una columna específica contiene un valor determinado. El resultado filtrado se guarda en una nueva variable como DataFrame.

step: ordeno el CSV "{csv_var}" por columna "{column}" de forma "{order}" y guardo como "{result_var}"
descripcion: Este paso permite ordenar un CSV cargado por una columna específica en orden ascendente o descendente. El resultado ordenado se guarda en una nueva variable.

step: obtengo el valor de la fila {row:d} columna "{column}" del CSV "{csv_var}" y lo guardo en "{variable_name}"
descripcion: Este paso permite extraer un valor específico de un CSV cargado indicando el número de fila (base 0) y el nombre de la columna. El valor se guarda en una variable.

step: exporto el CSV "{csv_var}" a "{file_path}"
descripcion: Este paso permite exportar un DataFrame (CSV cargado o filtrado) a un archivo CSV en disco. Es útil para guardar resultados de filtrado o transformación.

step: muestro un resumen del CSV "{csv_var}"
descripcion: Este paso permite mostrar en consola un resumen del CSV cargado incluyendo número de filas, columnas, tipos de datos y primeras filas. Es útil para debugging y verificación de datos.

step: busco en el CSV "{csv_var}" el valor "{value}" en la columna "{column}"
descripcion: Este paso permite buscar un valor específico en una columna de un CSV cargado y verificar si existe. Muestra las filas que coinciden con la búsqueda.

---

## --- Extracción de Datos ---

step: extraigo el texto del elemento "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer el texto visible de un elemento web y guardarlo en una variable del framework. Utiliza textContent para obtener todo el texto del elemento incluyendo hijos.

step: extraigo el valor del campo "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer el valor actual de un campo de entrada (input, textarea, select) y guardarlo en una variable. Obtiene el atributo value del elemento.

step: extraigo el atributo "{attribute}" del elemento "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer el valor de cualquier atributo HTML de un elemento y guardarlo en una variable. Soporta atributos estándar y data attributes.

step: extraigo el HTML del elemento "{element_name}" y lo guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer el HTML interno de un elemento y guardarlo en una variable. Es útil para capturar contenido estructurado o para validaciones complejas.

step: cuento los elementos "{element_name}" y guardo el resultado en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Este paso permite contar cuántos elementos coinciden con un selector y guardar el número en una variable. Es útil para verificar la cantidad de resultados, filas o items.

---

## --- Archivos ---

step: creo archivo de prueba "{filename}" con contenido "{content}"
descripcion: Este paso permite crear un archivo de texto con contenido específico en el sistema de archivos. Es útil para preparar archivos de prueba que serán subidos o procesados durante el test.

step: elimino archivo de prueba "{filename}"
descripcion: Este paso permite eliminar un archivo del sistema de archivos. Es útil para limpiar archivos temporales creados durante la ejecución del test.

step: verifico que el archivo "{filename}" existe en el directorio "{directory}"
descripcion: Este paso permite verificar que un archivo existe en un directorio específico. Lanza un error de aserción si el archivo no se encuentra.

step: inicio descarga haciendo click en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite iniciar una descarga de archivo haciendo click en un elemento. Configura un listener de descarga antes del click para capturar el archivo descargado.

step: espero a que complete la descarga
descripcion: Este paso permite esperar hasta que una descarga iniciada previamente se complete. Verifica que el archivo se descargó correctamente.

step: guardo la descarga como "{filename}"
descripcion: Este paso permite guardar el archivo descargado con un nombre específico en el directorio de descargas configurado.

step: verifico que existe el archivo descargado
descripcion: Este paso permite verificar que el último archivo descargado existe en el sistema de archivos. Confirma que la descarga se completó exitosamente.

---

## --- Teclado y Mouse ---

step: presiono la tecla "{key}"
descripcion: Este paso permite presionar una tecla específica a nivel de página (no en un elemento particular). Soporta teclas especiales como Enter, Escape, Tab, F1-F12, etc.

step: presiono la combinación de teclas "{keys}"
descripcion: Este paso permite presionar una combinación de teclas a nivel de página. Usa la sintaxis de Playwright como "Control+C", "Shift+Enter", "Alt+Tab".

step: mantengo presionada la tecla "{key}"
descripcion: Este paso permite mantener presionada una tecla sin soltarla. Es útil para combinaciones que requieren mantener una tecla mientras se realizan otras acciones.

step: suelto la tecla "{key}"
descripcion: Este paso permite soltar una tecla que fue previamente mantenida presionada. Completa la acción de mantener presionada una tecla.

step: muevo el mouse a las coordenadas x={x:d} y={y:d}
descripcion: Este paso permite mover el cursor del mouse a coordenadas absolutas específicas en la página. Es útil para interacciones que requieren posicionamiento preciso del cursor.

step: hago click en las coordenadas x={x:d} y={y:d}
descripcion: Este paso permite hacer click en coordenadas absolutas específicas de la página. Es útil cuando no hay un elemento específico para hacer click sino una posición en un canvas o mapa.

---

## --- Variables de Entorno ---

step: obtengo la variable de entorno "{env_var}" y la guardo en la variable "{variable_name}"
descripcion: Este paso permite leer el valor de una variable de entorno del sistema o del archivo .env y guardarlo en una variable del framework para uso en el test.

step: establezco la variable de entorno "{env_var}" con valor "{value}"
descripcion: Este paso permite establecer o modificar una variable de entorno durante la ejecución del test. El cambio afecta solo al proceso actual.

step: verifico que la variable de entorno "{env_var}" existe
descripcion: Este paso permite verificar que una variable de entorno está definida en el sistema. Lanza error si la variable no existe.

step: verifico que la variable de entorno "{env_var}" tiene el valor "{expected_value}"
descripcion: Este paso permite verificar que una variable de entorno tiene un valor específico. Compara el valor actual con el esperado.

---

## --- Iframes ---

step: cambio al iframe "{iframe_name}" con identificador "{identifier}"
descripcion: Este paso permite cambiar el contexto de ejecución a un iframe específico. Todas las interacciones posteriores se realizarán dentro del iframe hasta que se vuelva al contenido principal.

step: vuelvo al contenido principal desde el iframe
descripcion: Este paso permite salir del iframe actual y volver al contexto del documento principal. Restaura la capacidad de interactuar con elementos fuera del iframe.

step: verifico que el iframe "{iframe_name}" existe con identificador "{identifier}"
descripcion: Este paso permite verificar que un iframe existe en la página. Busca el elemento iframe por su identificador.

step: verifico que el iframe "{iframe_name}" está cargado con identificador "{identifier}"
descripcion: Este paso permite verificar que un iframe ha terminado de cargar su contenido. Espera a que el iframe esté listo para interacción.

---

## --- Combobox y Select ---

step: selecciono "{option}" del combobox "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite seleccionar una opción de un combobox o dropdown por su texto visible. Soporta tanto elementos select nativos como comboboxes personalizados con JavaScript.

step: selecciono la opción número {index:d} del combobox "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite seleccionar una opción de un combobox por su índice numérico (posición). El índice comienza desde 1.

step: verifico que el combobox "{element_name}" tiene la opción "{option}" seleccionada con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox tiene una opción específica seleccionada actualmente. Compara el texto de la opción seleccionada con el esperado.

step: verifico que el combobox "{element_name}" tiene {count:d} opciones con identificador "{identifier}"
descripcion: Este paso permite verificar que un combobox tiene un número exacto de opciones disponibles. Cuenta todas las opciones del select.

step: obtengo las opciones del combobox "{element_name}" y las guardo en la variable "{variable_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer todas las opciones disponibles de un combobox y guardarlas en una variable como lista. Es útil para validar el contenido del dropdown.

step: verifico que el combobox "{element_name}" contiene la opción "{option}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una opción específica existe dentro de las opciones disponibles de un combobox, sin importar si está seleccionada o no.



---

## --- API Testing ---

step: envío petición GET a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición HTTP GET a una URL específica y almacenar la respuesta completa en una variable. La respuesta incluye código de estado, headers y cuerpo. Soporta resolución de variables dinámicas en la URL.

step: envío petición POST a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición HTTP POST con un cuerpo JSON a una URL y guardar la respuesta. El cuerpo puede contener variables dinámicas que se resuelven antes del envío.

step: envío petición PUT a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición HTTP PUT con un cuerpo JSON para actualizar recursos en una API REST y guardar la respuesta.

step: envío petición DELETE a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición HTTP DELETE a una URL para eliminar un recurso y guardar la respuesta.

step: verifico que el código de estado de la respuesta API es "{expected_status}"
descripcion: Este paso permite verificar que el código de estado HTTP de la última respuesta API coincide con el esperado (200, 201, 404, etc.).

step: verifico que la respuesta API contiene "{key}" con valor "{expected_value}"
descripcion: Este paso permite verificar que la respuesta API contiene una clave específica con un valor esperado. Soporta notación de punto para acceder a campos anidados.

step: extraigo el valor de la respuesta API "{key}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer un valor específico de la respuesta API usando una clave y guardarlo en una variable para uso posterior.

step: establezco el header de API "{header_name}" a "{header_value}"
descripcion: Este paso permite establecer un header HTTP personalizado que se incluirá en las próximas peticiones API. Útil para autenticación, content-type, etc.

step: envío petición GET autenticada a "{url}" con token "{token}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición GET con autenticación Bearer token. Incluye automáticamente el header Authorization con el token proporcionado.

step: verifico que el tiempo de respuesta de la API es menor a "{max_seconds}" segundos
descripcion: Este paso permite verificar que el tiempo de respuesta de la última petición API no excede un límite máximo en segundos.

step: verifico que la respuesta API es JSON válido
descripcion: Este paso permite verificar que el cuerpo de la respuesta API es un JSON válido y parseable.

step: envío petición PATCH a "{url}" con cuerpo "{body}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición HTTP PATCH con un cuerpo JSON para actualización parcial de recursos.

step: envío petición HEAD a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición HTTP HEAD que obtiene solo los headers de respuesta sin el cuerpo.

step: envío petición OPTIONS a "{url}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición HTTP OPTIONS para consultar los métodos HTTP soportados por un endpoint.

step: verifico que el header de respuesta API "{header_name}" es igual a "{expected_value}"
descripcion: Este paso permite verificar que un header específico de la respuesta API tiene un valor exacto.

step: verifico que el header de respuesta API "{header_name}" contiene "{expected_text}"
descripcion: Este paso permite verificar que un header de respuesta API contiene un texto parcial específico.

step: verifico que el cuerpo de respuesta API contiene el texto "{expected_text}"
descripcion: Este paso permite verificar que el cuerpo de la respuesta API contiene un texto específico.

step: verifico que el array JSON de respuesta API tiene "{expected_length}" elementos
descripcion: Este paso permite verificar que un array JSON en la respuesta tiene una cantidad específica de elementos.

step: verifico que el elemento "{index}" del array JSON tiene "{key}" con valor "{expected_value}"
descripcion: Este paso permite verificar que un elemento específico de un array JSON tiene un campo con un valor esperado.

step: envío petición multipart form a "{url}" con campos "{fields}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición multipart/form-data con múltiples campos. Útil para envío de formularios con archivos.

step: subo archivo "{file_path}" al endpoint API "{url}" con nombre de campo "{field_name}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite subir un archivo a un endpoint API usando multipart/form-data.

step: establezco el timeout de API a "{timeout}" segundos
descripcion: Este paso permite establecer el tiempo máximo de espera para las peticiones API.

step: verifico que el estado de respuesta API está en el rango "{min_status}" a "{max_status}"
descripcion: Este paso permite verificar que el código de estado HTTP está dentro de un rango específico (ej: 200-299 para éxito).

step: verifico que el tipo de contenido de respuesta API es "{expected_content_type}"
descripcion: Este paso permite verificar el Content-Type de la respuesta API (ej: application/json, text/html).

step: guardo el cuerpo de respuesta API en el archivo "{file_path}"
descripcion: Este paso permite guardar el cuerpo completo de la respuesta API en un archivo local.

step: cargo el cuerpo de petición API del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"
descripcion: Este paso permite cargar el cuerpo de una petición desde un archivo y enviarlo como POST a una URL.

step: verifico que el esquema JSON de respuesta API coincide con el archivo "{schema_file}"
descripcion: Este paso permite validar que la estructura JSON de la respuesta coincide con un esquema JSON Schema definido en un archivo.

step: envío peticiones API en lote desde archivo "{requests_file}" y guardo resultados en variable "{variable_name}"
descripcion: Este paso permite enviar múltiples peticiones API definidas en un archivo de configuración y guardar todos los resultados.

step: verifico que la respuesta API coincide con la respuesta esperada del archivo "{expected_file}"
descripcion: Este paso permite comparar la respuesta API completa con una respuesta esperada almacenada en un archivo.

step: establezco la URL base de API a "{base_url}"
descripcion: Este paso permite establecer una URL base para las peticiones API, permitiendo usar endpoints relativos en pasos posteriores.

step: envío petición GET al endpoint "{endpoint}" y guardo la respuesta en la variable "{variable_name}"
descripcion: Este paso permite enviar una petición GET usando la URL base configurada más un endpoint relativo.

step: verifico que la respuesta API tiene paginación con total "{expected_total}" y página "{expected_page}"
descripcion: Este paso permite verificar la información de paginación en la respuesta API, validando el total de registros y la página actual.

step: verifico que los headers de rate limit están presentes en la respuesta API
descripcion: Este paso permite verificar que la respuesta API incluye headers de rate limiting (X-RateLimit-Limit, X-RateLimit-Remaining, etc.).

step: envío peticiones API concurrentes "{count}" veces a "{url}" y verifico que todas tengan éxito
descripcion: Este paso permite enviar múltiples peticiones concurrentes a una URL para testing de carga y verificar que todas respondan exitosamente.

step: verifico que el endpoint API "{endpoint}" soporta CORS
descripcion: Este paso permite verificar que un endpoint API soporta Cross-Origin Resource Sharing enviando una petición OPTIONS y validando los headers CORS.

step: creo datos de prueba API con plantilla "{template}" y valores "{values}" guardando en variable "{variable_name}"
descripcion: Este paso permite crear datos de prueba usando una plantilla con placeholders y valores específicos para testing de API.

step: verifico que la respuesta API sigue las convenciones REST para el método "{http_method}"
descripcion: Este paso permite verificar que la respuesta API sigue las convenciones REST estándar para el método HTTP utilizado.

step: mido el rendimiento de API para "{iterations}" peticiones a "{url}" y guardo métricas en variable "{variable_name}"
descripcion: Este paso permite medir el rendimiento de una API ejecutando múltiples peticiones y guardando métricas como tiempo promedio, mínimo y máximo.

step: verifico que la respuesta API tiene headers de seguridad
descripcion: Este paso permite verificar que la respuesta API incluye headers de seguridad importantes como X-Content-Type-Options, X-Frame-Options, etc.

step: limpio todos los datos de sesión API
descripcion: Este paso permite limpiar todos los datos de sesión API incluyendo headers, cookies y configuraciones previas.

step: inicio la escucha de llamadas a API
descripcion: Este paso permite iniciar la interceptación y registro de todas las llamadas a API que se realicen desde el navegador. Captura requests y responses en background.

step: detengo la escucha de llamadas a API
descripcion: Este paso permite detener la escucha activa de llamadas a API.

step: detengo la interceptación de llamadas a API
descripcion: Este paso permite detener la interceptación de llamadas a API y liberar los recursos asociados.

step: verifico que se realizó una llamada a la API en "{api_url}"
descripcion: Este paso permite verificar que se realizó al menos una llamada a una API específica durante la ejecución del test.

step: verifico que se realizó una llamada a la API "{api_url}" usando método "{method}"
descripcion: Este paso permite verificar que se realizó una llamada a una API específica con un método HTTP determinado (GET, POST, etc.).

step: verifico que la llamada a API contiene el parámetro "{parameter}" con valor "{value}"
descripcion: Este paso permite verificar que la última llamada a API interceptada contiene un parámetro de query string con un valor específico.

step: verifico que la llamada a API contiene el header "{header_name}" con valor "{header_value}"
descripcion: Este paso permite verificar que la última llamada a API interceptada incluye un header específico con un valor determinado.

step: verifico que el número de llamadas a la API "{api_url}" es "{expected_count}"
descripcion: Este paso permite verificar que se realizó un número exacto de llamadas a una API específica.

step: guardo los datos de la llamada a API en la variable "{variable_name}"
descripcion: Este paso permite guardar todos los datos de la última llamada a API interceptada en una variable.

step: verifico que NO se realizó una llamada a la API "{api_url}"
descripcion: Este paso permite verificar que no se realizó ninguna llamada a una API específica durante la ejecución.

step: limpio las llamadas a API interceptadas
descripcion: Este paso permite limpiar el registro de todas las llamadas a API interceptadas previamente.

step: obtengo el valor de la respuesta API capturada "{api_url}" en la ruta "{json_path}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer un valor específico de una respuesta API capturada en background usando una ruta JSON path.


---

## --- Validación JSON de API ---

step: verifico que el JSON de respuesta API coincide con el esquema del archivo "{schema_file}"
descripcion: Este paso permite validar que la respuesta JSON de una API coincide con un esquema JSON Schema (Draft 7) definido en un archivo. Verifica estructura, tipos de datos y campos requeridos.

step: verifico que el JSON de respuesta API coincide exactamente con el archivo "{expected_file}"
descripcion: Este paso permite verificar que la respuesta JSON es exactamente igual al contenido de un archivo de referencia. Compara campo por campo incluyendo orden de arrays.

step: verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando orden
descripcion: Este paso permite verificar que la respuesta JSON coincide con un archivo de referencia ignorando el orden de los elementos en arrays.

step: verifico que el JSON de respuesta API coincide con el archivo "{expected_file}" ignorando campos "{ignored_fields}"
descripcion: Este paso permite verificar que la respuesta JSON coincide con un archivo ignorando campos específicos como timestamps o IDs generados.

step: verifico que el JSON de respuesta API tiene el campo "{field_path}" con tipo "{expected_type}"
descripcion: Este paso permite verificar que un campo específico en la respuesta JSON tiene un tipo de dato esperado (string, number, boolean, array, object).

step: verifico que el campo "{field_path}" del JSON de respuesta API coincide con el patrón "{pattern}"
descripcion: Este paso permite verificar que un campo JSON coincide con una expresión regular específica.

step: verifico que el campo "{field_path}" del JSON de respuesta API está en el rango {min_value} a {max_value}
descripcion: Este paso permite verificar que un campo numérico de la respuesta JSON está dentro de un rango de valores específico.

step: verifico que el array "{array_path}" del JSON de respuesta API contiene un elemento con "{field}" igual a "{value}"
descripcion: Este paso permite verificar que un array en la respuesta JSON contiene al menos un elemento con un campo específico igual a un valor determinado.

step: verifico que todos los elementos del array "{array_path}" del JSON de respuesta API tienen el campo "{field}"
descripcion: Este paso permite verificar que todos los elementos de un array JSON tienen un campo específico presente.

step: verifico que el JSON de respuesta API no tiene valores nulos
descripcion: Este paso permite verificar que la respuesta JSON no contiene ningún valor null en ninguno de sus campos.

step: guardo el JSON de respuesta API en el archivo "{file_path}"
descripcion: Este paso permite guardar la respuesta JSON completa de la API en un archivo local para referencia o comparación futura.

step: cargo JSON del archivo "{file_path}" y envío POST a "{url}" guardando respuesta en variable "{variable_name}"
descripcion: Este paso permite cargar un JSON desde un archivo local y enviarlo como cuerpo de una petición POST a una URL, guardando la respuesta.

---

## --- Configuración Avanzada del Navegador ---

step: establezco el argumento del navegador "{argument}"
descripcion: Este paso permite agregar un argumento de línea de comandos al navegador (ej: --disable-gpu, --no-sandbox). Se aplica al iniciar el navegador.

step: establezco los argumentos del navegador desde la lista "{arguments_list}"
descripcion: Este paso permite establecer múltiples argumentos del navegador desde una lista separada por comas.

step: establezco la bandera de Chrome "{flag}" con valor "{value}"
descripcion: Este paso permite establecer una bandera específica de Chrome con un valor determinado.

step: habilito la característica experimental de Chrome "{feature}"
descripcion: Este paso permite habilitar una característica experimental de Chrome que no está activa por defecto.

step: deshabilito la característica experimental de Chrome "{feature}"
descripcion: Este paso permite deshabilitar una característica experimental de Chrome.

step: establezco la preferencia del navegador "{preference}" con valor "{value}"
descripcion: Este paso permite establecer una preferencia de configuración del navegador con un valor específico.

step: establezco el comportamiento de descarga del navegador a "{behavior}" con ruta "{download_path}"
descripcion: Este paso permite configurar el comportamiento de descarga del navegador, especificando si permite descargas y la ruta de destino.

step: establezco el proxy del navegador a "{proxy_server}"
descripcion: Este paso permite configurar un servidor proxy para todas las conexiones del navegador.

step: deshabilito las características de seguridad del navegador
descripcion: Este paso permite deshabilitar las características de seguridad del navegador como CORS y mixed content. Útil para testing en entornos controlados.

step: habilito el modo de rendimiento del navegador
descripcion: Este paso permite habilitar optimizaciones de rendimiento del navegador desactivando animaciones, GPU y otras características que consumen recursos.

step: establezco el límite de memoria del navegador a "{memory_mb}" MB
descripcion: Este paso permite establecer un límite de memoria máxima para el proceso del navegador.

step: configuro el navegador para testing móvil
descripcion: Este paso permite configurar el navegador con parámetros optimizados para simular un dispositivo móvil.

step: configuro el navegador para entorno CI/CD
descripcion: Este paso permite configurar el navegador con parámetros optimizados para ejecución en entornos de integración continua (headless, sin GPU, etc.).

step: cargo la configuración del navegador desde el archivo "{config_file}"
descripcion: Este paso permite cargar una configuración completa del navegador desde un archivo JSON.

step: guardo la configuración actual del navegador en el archivo "{config_file}"
descripcion: Este paso permite guardar la configuración actual del navegador en un archivo JSON para reutilización.

step: limpio todos los argumentos del navegador
descripcion: Este paso permite eliminar todos los argumentos de navegador configurados previamente.

step: limpio todas las preferencias del navegador
descripcion: Este paso permite eliminar todas las preferencias de navegador configuradas previamente.

step: muestro la configuración actual del navegador
descripcion: Este paso permite mostrar en consola la configuración actual del navegador incluyendo argumentos, preferencias y banderas.


---

## --- Control del Navegador ---

step: establezco la cookie "{name}" con valor "{value}"
descripcion: Este paso permite establecer una cookie en el navegador con un nombre y valor específicos.

step: obtengo la cookie "{name}" y la guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener el valor de una cookie del navegador y guardarlo en una variable.

step: elimino la cookie "{name}"
descripcion: Este paso permite eliminar una cookie específica del navegador.

step: limpio todas las cookies
descripcion: Este paso permite eliminar todas las cookies del navegador actual.

step: establezco el item de localStorage "{key}" con valor "{value}"
descripcion: Este paso permite establecer un item en el localStorage del navegador con una clave y valor específicos.

step: obtengo el item de localStorage "{key}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener un valor del localStorage del navegador y guardarlo en una variable.

step: elimino el item de localStorage "{key}"
descripcion: Este paso permite eliminar un item específico del localStorage del navegador.

step: limpio el localStorage
descripcion: Este paso permite limpiar completamente el localStorage del navegador.

step: establezco el item de sessionStorage "{key}" con valor "{value}"
descripcion: Este paso permite establecer un item en el sessionStorage del navegador.

step: obtengo el item de sessionStorage "{key}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener un valor del sessionStorage del navegador y guardarlo en una variable.

step: limpio el sessionStorage
descripcion: Este paso permite limpiar completamente el sessionStorage del navegador.

step: ejecuto JavaScript "{script}" y guardo el resultado en la variable "{variable_name}"
descripcion: Este paso permite ejecutar código JavaScript en el contexto de la página actual y guardar el resultado en una variable. Útil para interacciones avanzadas con el DOM.

step: ejecuto el siguiente JavaScript y guardo el resultado en la variable "{variable_name}"
descripcion: Este paso permite ejecutar un bloque de código JavaScript multilínea (definido en el texto del step) y guardar el resultado en una variable.

step: establezco el viewport del navegador a "{width}x{height}"
descripcion: Este paso permite cambiar el tamaño del viewport del navegador a dimensiones específicas en formato anchoxalto.

step: habilito JavaScript
descripcion: Este paso permite habilitar la ejecución de JavaScript en el navegador si fue deshabilitado previamente.

step: deshabilito JavaScript
descripcion: Este paso permite deshabilitar la ejecución de JavaScript en el navegador. Útil para testing de accesibilidad y progressive enhancement.

step: establezco el user agent a "{user_agent}"
descripcion: Este paso permite establecer un user agent personalizado para el navegador, simulando diferentes dispositivos o navegadores.

step: obtengo el user agent actual y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener el user agent actual del navegador y guardarlo en una variable.

step: simulo la condición de red "{condition}"
descripcion: Este paso permite simular diferentes condiciones de red como 3G lento, offline, etc. Útil para testing de rendimiento y manejo de errores de red.

step: limpio la caché del navegador
descripcion: Este paso permite limpiar la caché del navegador para asegurar que las páginas se cargan sin datos en caché.

step: bloqueo el tipo de recurso "{resource_type}"
descripcion: Este paso permite bloquear la carga de un tipo específico de recurso (imágenes, scripts, stylesheets, etc.) en el navegador.

step: desbloqueo todos los recursos
descripcion: Este paso permite desbloquear todos los tipos de recursos que fueron bloqueados previamente.

step: desactivo el navegador para esta prueba
descripcion: Este paso permite desactivar el navegador para el escenario actual. Útil para tests que no requieren navegador como pruebas de API o base de datos.

step: no necesito navegador para esta prueba
descripcion: Este paso permite indicar que el escenario actual no necesita navegador. Equivalente a desactivar el navegador.

step: reactivo el navegador
descripcion: Este paso permite reactivar el navegador después de haberlo desactivado en un escenario previo.

step: necesito el navegador ahora
descripcion: Este paso permite indicar que se necesita el navegador nuevamente después de haberlo desactivado.


---

## --- Base de Datos ---

step: me conecto a la base de datos "{db_name}"
descripcion: Este paso permite establecer una conexión a una base de datos usando el nombre de la base de datos. Soporta múltiples motores de base de datos.

step: me conecto a la base de datos SQLite "{db_path}"
descripcion: Este paso permite conectarse a una base de datos SQLite especificando la ruta del archivo de base de datos.

step: me conecto a la base de datos usando configuración del entorno
descripcion: Este paso permite conectarse a una base de datos usando las variables de entorno configuradas (DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD).

step: creo base de datos de prueba con datos de ejemplo
descripcion: Este paso permite crear una base de datos de prueba con tablas y datos de ejemplo para testing.

step: ejecuto la consulta SQL "{query}" y guardo el resultado en la variable "{variable_name}"
descripcion: Este paso permite ejecutar una consulta SQL SELECT y guardar los resultados en una variable como lista de diccionarios.

step: ejecuto la actualización SQL "{query}"
descripcion: Este paso permite ejecutar una sentencia SQL de modificación (INSERT, UPDATE, DELETE) en la base de datos.

step: verifico que el resultado de la consulta SQL tiene "{expected_count}" filas
descripcion: Este paso permite verificar que el resultado de la última consulta SQL tiene un número específico de filas.

step: verifico que el resultado SQL contiene una fila con "{column}" igual a "{expected_value}"
descripcion: Este paso permite verificar que el resultado SQL contiene al menos una fila donde una columna tiene un valor específico.

step: obtengo el valor del resultado SQL de la columna "{column}" fila "{row_index}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer un valor específico del resultado SQL por columna e índice de fila y guardarlo en una variable.

step: creo la tabla "{table_name}" con columnas "{columns_definition}"
descripcion: Este paso permite crear una nueva tabla en la base de datos con la definición de columnas especificada.

step: inserto datos de prueba en la tabla "{table_name}" con valores "{values}"
descripcion: Este paso permite insertar datos de prueba en una tabla existente de la base de datos.

step: elimino la tabla "{table_name}"
descripcion: Este paso permite eliminar (DROP) una tabla de la base de datos.

step: cierro la conexión a la base de datos
descripcion: Este paso permite cerrar la conexión activa a la base de datos y liberar los recursos asociados.

step: hago backup de la base de datos al archivo "{backup_file}"
descripcion: Este paso permite crear un backup de la base de datos actual en un archivo especificado.

---

## --- Email ---

step: envío email a "{recipient}" con asunto "{subject}" y cuerpo "{body}" usando SMTP "{smtp_server}" puerto "{port}"
descripcion: Este paso permite enviar un email a un destinatario específico usando un servidor SMTP con puerto configurado.

step: establezco las credenciales de email remitente="{sender}" contraseña="{password}"
descripcion: Este paso permite configurar las credenciales del remitente para el envío de emails.

step: me conecto al servidor IMAP "{imap_server}" puerto "{port}" con usuario "{username}" contraseña "{password}"
descripcion: Este paso permite conectarse a un servidor IMAP para leer emails, especificando servidor, puerto y credenciales.

step: selecciono la carpeta de email "{folder}"
descripcion: Este paso permite seleccionar una carpeta específica del buzón de correo (INBOX, Sent, etc.) para buscar emails.

step: busco emails con asunto que contiene "{subject_text}" y guardo el conteo en la variable "{variable_name}"
descripcion: Este paso permite buscar emails por asunto y guardar la cantidad de resultados encontrados en una variable.

step: obtengo el contenido del email más reciente y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite obtener el contenido completo del email más reciente y guardarlo en una variable.

step: verifico que se recibió un email con asunto "{subject}" dentro de "{timeout}" segundos
descripcion: Este paso permite verificar que se recibió un email con un asunto específico dentro de un tiempo límite, con reintentos automáticos.

step: elimino emails con asunto que contiene "{subject_text}"
descripcion: Este paso permite eliminar todos los emails cuyo asunto contenga un texto específico.

step: cierro la conexión de email
descripcion: Este paso permite cerrar la conexión activa al servidor de email y liberar los recursos.

step: extraigo el código de verificación del cuerpo del email y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer automáticamente un código de verificación numérico del cuerpo de un email y guardarlo en una variable.


---

## --- Manejo de Formularios ---

step: envío el formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite enviar un formulario web haciendo submit. Localiza el formulario por su identificador y ejecuta el envío.

step: reseteo el formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite resetear un formulario a sus valores iniciales, limpiando todos los campos modificados.

step: relleno el formulario con datos de la variable "{data_variable}" para formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite rellenar automáticamente un formulario completo usando datos almacenados en una variable (diccionario con nombre_campo: valor).

step: obtengo los datos del formulario y los guardo en la variable "{variable_name}" para formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite extraer todos los datos actuales de un formulario y guardarlos en una variable como diccionario.

step: valido el formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite ejecutar la validación nativa del formulario y verificar si todos los campos cumplen sus restricciones.

step: verifico los campos requeridos en el formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que todos los campos marcados como requeridos en un formulario tienen valores.

step: establezco el campo "{field_name}" como solo lectura en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"
descripcion: Este paso permite establecer un campo de formulario como solo lectura, impidiendo la edición por el usuario.

step: habilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"
descripcion: Este paso permite habilitar un campo de formulario que estaba deshabilitado.

step: deshabilito el campo "{field_name}" en formulario "{form_name}" con identificador de formulario "{form_id}" y identificador de campo "{field_id}"
descripcion: Este paso permite deshabilitar un campo de formulario, impidiendo la interacción del usuario.

step: auto-relleno el formulario "{form_name}" con datos de prueba usando identificador "{identifier}"
descripcion: Este paso permite rellenar automáticamente un formulario con datos de prueba generados según el tipo de cada campo (texto, email, número, etc.).

step: limpio todos los campos del formulario "{form_name}" con identificador "{identifier}"
descripcion: Este paso permite limpiar todos los campos de un formulario, dejándolos vacíos.

---

## --- GenAI Avanzado ---

step: valido que la respuesta del SUT está en idioma "{language}"
descripcion: Este paso permite validar que la respuesta generada por el sistema bajo prueba (SUT) está en el idioma esperado usando análisis de lenguaje natural.

step: valido que la respuesta del SUT es un JSON válido
descripcion: Este paso permite validar que la respuesta del sistema bajo prueba es un JSON válido y parseable.

step: valido que el JSON de respuesta tiene la estructura "{schema_file}"
descripcion: Este paso permite validar que el JSON de respuesta cumple con un esquema de estructura definido en un archivo.

step: valido que la intención de la respuesta es "{expected_intent}"
descripcion: Este paso permite validar que la intención detectada en la respuesta del SUT coincide con la esperada (ej: saludo, consulta, queja).

step: valido que la respuesta rechaza el prompt adversarial
descripcion: Este paso permite verificar que el sistema de IA rechaza correctamente intentos de jailbreaking o prompts adversariales.

step: valido que la respuesta no contiene alucinaciones según el contexto
descripcion: Este paso permite verificar que la respuesta de la IA no contiene información inventada o alucinaciones, comparando con el contexto proporcionado.

step: valido que la respuesta no contiene sesgos de "{bias_type}"
descripcion: Este paso permite verificar que la respuesta de la IA no contiene sesgos de un tipo específico (género, racial, cultural, etc.).

step: valido que la respuesta no contiene lenguaje tóxico
descripcion: Este paso permite verificar que la respuesta de la IA es profesional y no contiene lenguaje tóxico, ofensivo o inapropiado.

step: valido que las respuestas "{var1}" y "{var2}" son consistentes
descripcion: Este paso permite verificar que dos respuestas de la IA almacenadas en variables son consistentes entre sí, sin contradicciones.

step: valido que la respuesta cita fuentes correctamente
descripcion: Este paso permite verificar que la respuesta de la IA incluye citación de fuentes cuando es apropiado.

---

## --- Evaluación GenAI ---

step: el contexto de reglas de negocio "{context_name}" está cargado desde el archivo "{file_path}"
descripcion: Este paso permite cargar un archivo de contexto con reglas de negocio que servirá como referencia para evaluar las respuestas de la IA.

step: cambio al contexto de reglas de negocio "{context_name}"
descripcion: Este paso permite cambiar al contexto de reglas de negocio previamente cargado para las evaluaciones.

step: limpio todos los cachés de contexto
descripcion: Este paso permite limpiar todos los contextos de reglas de negocio cargados en caché.

step: interactúo con la IA con el prompt "{user_query}"
descripcion: Este paso permite enviar un prompt al sistema de IA y capturar su respuesta para evaluación posterior.

step: envío el prompt "{user_query}" a la IA
descripcion: Este paso permite enviar un prompt al sistema de IA. Equivalente a interactuar con la IA.

step: establezco la respuesta del SUT como "{response_text}"
descripcion: Este paso permite establecer manualmente la respuesta del sistema bajo prueba para evaluación sin necesidad de interactuar con la IA.

step: la respuesta del SUT es "{response_text}"
descripcion: Este paso permite establecer la respuesta del SUT directamente. Forma alternativa del paso anterior.

step: cargo la respuesta del SUT desde el archivo "{file_path}"
descripcion: Este paso permite cargar la respuesta del sistema bajo prueba desde un archivo de texto.

step: Gemini genera la respuesta para el prompt "{user_query}"
descripcion: Este paso permite usar Gemini como generador de respuestas para un prompt específico, guardando la respuesta para evaluación.

step: el Juez Gemini debe validar la respuesta con un umbral mínimo de {threshold:f}
descripcion: Este paso permite que Gemini actúe como juez evaluando la respuesta del SUT contra el contexto de reglas de negocio con un umbral de aprobación.

step: el Juez Gemini debe validar la respuesta
descripcion: Este paso permite que Gemini evalúe la respuesta del SUT usando el umbral por defecto.

step: el Juez Gemini debe validar la respuesta con criterios personalizados "{criteria}" y umbral {threshold:f}
descripcion: Este paso permite que Gemini evalúe la respuesta usando criterios de evaluación personalizados y un umbral específico.

step: valido con Gemini que según el contexto para la pregunta "{pregunta}" la respuesta "{respuesta}" es válida con umbral {threshold:f}
descripcion: Este paso permite validar en un solo paso que una respuesta es válida para una pregunta específica según el contexto cargado.

step: el Juez Gemini valida que para la pregunta "{pregunta}" la respuesta "{respuesta}" es correcta con umbral {threshold:f}
descripcion: Este paso permite que el Juez Gemini valide directamente una pregunta-respuesta con un umbral de aprobación.

step: guardo la evaluación del Juez en el archivo "{file_path}"
descripcion: Este paso permite guardar los resultados de la evaluación del Juez Gemini en un archivo para análisis posterior.

step: el score de la última evaluación debe ser mayor o igual a {min_score:f}
descripcion: Este paso permite verificar que el score de la última evaluación del Juez Gemini cumple con un mínimo requerido.


---

## --- Accesibilidad ---

step: verifico que el elemento "{element_name}" tiene etiqueta ARIA "{expected_label}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene una etiqueta ARIA específica (aria-label). Es fundamental para garantizar que los lectores de pantalla puedan identificar correctamente el elemento.

step: verifico que el elemento "{element_name}" tiene rol ARIA "{expected_role}" con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un rol ARIA específico (button, navigation, dialog, etc.). Los roles ARIA definen el propósito del elemento para tecnologías asistivas.

step: verifico que el elemento "{element_name}" es accesible por teclado con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento puede recibir foco y ser activado usando solo el teclado, sin necesidad de mouse.

step: verifico que el elemento "{element_name}" tiene texto alt "{expected_alt}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una imagen tiene un texto alternativo específico, esencial para usuarios que usan lectores de pantalla.

step: verifico que el elemento "{element_name}" tiene jerarquía de encabezados correcta con identificador "{identifier}"
descripcion: Este paso permite verificar que los encabezados (h1-h6) siguen una jerarquía correcta sin saltar niveles, lo cual es importante para la navegación con lectores de pantalla.

step: verifico que el formulario tiene etiquetas apropiadas para todos los campos
descripcion: Este paso permite verificar que todos los campos de un formulario tienen etiquetas (label) asociadas correctamente, ya sea mediante el atributo for o anidamiento.

step: verifico que el elemento "{element_name}" tiene contraste de color suficiente con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un ratio de contraste de color suficiente entre el texto y el fondo según las pautas de accesibilidad.

step: verifico que la página tiene estructura de documento apropiada
descripcion: Este paso permite verificar que la página tiene una estructura de documento apropiada con landmarks (header, main, nav, footer) y encabezados correctos.

step: verifico que el elemento "{element_name}" es anunciado por lector de pantalla con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento será anunciado apropiadamente por lectores de pantalla, verificando que tiene contenido accesible (texto, aria-label, etc.).

step: verifico que los elementos interactivos tienen indicadores de foco
descripcion: Este paso permite verificar que todos los elementos interactivos de la página (botones, enlaces, inputs) tienen indicadores de foco visibles al navegar con teclado.

step: verifico que el elemento "{element_name}" tiene texto de enlace descriptivo con identificador "{identifier}"
descripcion: Este paso permite verificar que un enlace tiene texto descriptivo y no genérico (evitando textos como "click aquí" o "leer más").

step: verifico que las imágenes tienen texto alternativo apropiado
descripcion: Este paso permite verificar que todas las imágenes de la página tienen texto alternativo apropiado, ya sea mediante alt text o aria-label.

---

## --- OCR ---

step: extraigo texto del screenshot "{screenshot_name}" usando OCR
descripcion: Este paso permite extraer todo el texto visible de un screenshot usando reconocimiento óptico de caracteres (OCR). El texto extraído queda disponible para validaciones posteriores.

step: debería encontrar el texto "{expected_text}" en los resultados OCR
descripcion: Este paso permite verificar que un texto específico fue encontrado en los resultados de la última extracción OCR.

step: no debería encontrar el texto "{unexpected_text}" en los resultados OCR
descripcion: Este paso permite verificar que un texto específico NO está presente en los resultados de la última extracción OCR.

step: verifico que la calidad del texto OCR es al menos "{min_confidence}" por ciento
descripcion: Este paso permite verificar que la confianza del reconocimiento OCR alcanza un porcentaje mínimo de calidad.

step: tomo screenshot y extraigo texto con OCR usando engine "{engine}"
descripcion: Este paso permite tomar un screenshot de la página actual y extraer el texto usando un engine OCR específico (tesseract, easyocr, etc.).

step: busco el texto "{search_text}" en la página actual usando OCR
descripcion: Este paso permite buscar un texto específico en la página actual usando OCR, útil cuando el texto no es accesible mediante selectores DOM.

step: verifico que el texto es legible en screenshot "{screenshot_name}" con confianza mínima "{min_confidence}"
descripcion: Este paso permite verificar que el texto en un screenshot es legible con un nivel mínimo de confianza OCR.

step: extraigo y guardo texto OCR del elemento "{element_name}" con identificador "{identifier}" en variable "{variable_name}"
descripcion: Este paso permite extraer texto OCR de un elemento específico de la página y guardarlo en una variable.

step: comparo texto OCR con texto esperado "{expected_text}" con umbral de similitud "{threshold}" por ciento
descripcion: Este paso permite comparar el texto extraído por OCR con un texto esperado usando un umbral de similitud porcentual.

step: guardo resultados OCR en archivo "{filename}"
descripcion: Este paso permite guardar los resultados completos de la extracción OCR en un archivo para análisis posterior.

---

## --- PDF ---

step: verifico que el archivo PDF "{filename}" contiene el texto "{text}"
descripcion: Este paso permite verificar que un archivo PDF contiene un texto específico en cualquiera de sus páginas.

step: verifico que el PDF "{filename}" de la carpeta "{directory}" contiene el texto "{text}"
descripcion: Este paso permite verificar que un PDF ubicado en una carpeta específica contiene un texto determinado.

step: verifico que el archivo PDF "{filename}" no contiene el texto "{text}"
descripcion: Este paso permite verificar que un archivo PDF NO contiene un texto específico.

step: verifico que el archivo PDF "{filename}" tiene "{expected_pages}" páginas
descripcion: Este paso permite verificar que un archivo PDF tiene un número exacto de páginas.

step: verifico que la página "{page_number}" del PDF "{filename}" contiene el texto "{text}"
descripcion: Este paso permite verificar que una página específica de un PDF contiene un texto determinado.

step: extraigo el texto del PDF "{filename}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer todo el texto de un archivo PDF y guardarlo en una variable para procesamiento posterior.

step: extraigo el texto de la página "{page_number}" del PDF "{filename}" y lo guardo en la variable "{variable_name}"
descripcion: Este paso permite extraer el texto de una página específica de un PDF y guardarlo en una variable.

step: verifico que el archivo PDF "{filename}" está encriptado
descripcion: Este paso permite verificar que un archivo PDF está protegido con encriptación.

step: verifico que el archivo PDF "{filename}" no está encriptado
descripcion: Este paso permite verificar que un archivo PDF NO está encriptado y es accesible sin contraseña.

step: verifico que el PDF "{filename}" tiene metadato "{key}" con valor "{value}"
descripcion: Este paso permite verificar que un PDF contiene metadatos específicos como autor, título, fecha de creación, etc.

step: verifico que el PDF "{filename}" contiene texto que coincide con el patrón "{pattern}"
descripcion: Este paso permite verificar que un PDF contiene texto que coincide con una expresión regular específica.


---

## --- Rendimiento ---

step: verifico que la página carga en menos de "{max_seconds}" segundos
descripcion: Este paso permite verificar que la página actual carga completamente dentro de un tiempo máximo especificado en segundos.

step: verifico que el elemento "{element_name}" aparece en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento específico aparece visible en la página dentro de un tiempo máximo.

step: verifico que el tiempo de respuesta del click en elemento "{element_name}" es menor a "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que la respuesta visual después de hacer click en un elemento ocurre dentro de un tiempo máximo.

step: mido y guardo el tiempo de carga de página en la variable "{variable_name}"
descripcion: Este paso permite medir el tiempo de carga de la página actual y guardarlo en una variable para análisis posterior.

step: verifico que las peticiones de red se completan en menos de "{max_seconds}" segundos
descripcion: Este paso permite verificar que todas las peticiones de red pendientes se completan dentro de un tiempo máximo.

step: verifico que el tiempo de respuesta del envío de formulario es menor a "{max_seconds}" segundos
descripcion: Este paso permite verificar que el envío de un formulario y su respuesta ocurren dentro de un tiempo máximo.

step: verifico que los resultados de búsqueda aparecen en menos de "{max_seconds}" segundos
descripcion: Este paso permite verificar que los resultados de una búsqueda aparecen en la página dentro de un tiempo máximo.

step: verifico que la imagen "{image_name}" carga en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que una imagen específica carga completamente dentro de un tiempo máximo.

step: verifico que la animación se completa en menos de "{max_seconds}" segundos en elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite verificar que una animación CSS o JavaScript en un elemento se completa dentro de un tiempo máximo.

step: verifico que el modal "{modal_name}" se abre en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que un modal se abre y es visible dentro de un tiempo máximo.

step: verifico que el dropdown "{dropdown_name}" se expande en menos de "{max_seconds}" segundos con identificador "{identifier}"
descripcion: Este paso permite verificar que un dropdown se expande completamente dentro de un tiempo máximo.

step: verifico que el rendimiento del scroll de página es suave
descripcion: Este paso permite verificar que el scroll de la página es suave y sin lag, midiendo el rendimiento de frames durante el scroll.

step: verifico que el uso de memoria es aceptable después de "{actions_count}" acciones
descripcion: Este paso permite verificar que el uso de memoria del navegador se mantiene en niveles aceptables después de realizar un número específico de acciones.

---

## --- Responsive ---

step: establezco el viewport a tamaño móvil "{width}x{height}"
descripcion: Este paso permite establecer el viewport del navegador a un tamaño de dispositivo móvil específico en formato anchoxalto.

step: establezco el viewport a tamaño tablet "{width}x{height}"
descripcion: Este paso permite establecer el viewport del navegador a un tamaño de tablet específico.

step: establezco el viewport a tamaño desktop "{width}x{height}"
descripcion: Este paso permite establecer el viewport del navegador a un tamaño de escritorio específico.

step: verifico que el elemento "{element_name}" es visible en móvil con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento es visible cuando el viewport está en tamaño móvil.

step: verifico que el elemento "{element_name}" está oculto en móvil con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento está oculto cuando el viewport está en tamaño móvil.

step: verifico que el elemento "{element_name}" se adapta a cambios de viewport con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento se adapta correctamente a diferentes tamaños de viewport sin desbordarse.

step: verifico que el menú de navegación se colapsa en móvil
descripcion: Este paso permite verificar que el menú de navegación se colapsa en un menú hamburguesa o similar en dispositivos móviles.

step: verifico que el texto es legible en tamaño móvil
descripcion: Este paso permite verificar que el texto de la página es legible en dispositivos móviles, verificando tamaños de fuente mínimos.

step: verifico que los botones son amigables al tacto en móvil
descripcion: Este paso permite verificar que los botones tienen un tamaño mínimo apropiado para interacción táctil en dispositivos móviles (mínimo 44x44 píxeles).

step: verifico que no hay scroll horizontal
descripcion: Este paso permite verificar que la página no tiene scroll horizontal, lo cual indica problemas de diseño responsive.

step: verifico que las imágenes se escalan apropiadamente en móvil
descripcion: Este paso permite verificar que las imágenes se escalan correctamente en dispositivos móviles sin desbordarse del contenedor.

step: verifico que el elemento "{element_name}" se apila verticalmente en móvil con identificador "{identifier}"
descripcion: Este paso permite verificar que elementos que están en fila en desktop se apilan verticalmente en dispositivos móviles.

step: verifico el comportamiento del breakpoint en "{width}" píxeles
descripcion: Este paso permite verificar el comportamiento del diseño responsive en un breakpoint específico, cambiando el viewport al ancho indicado.

step: verifico que el elemento "{element_name}" tiene tamaño de fuente responsive con identificador "{identifier}"
descripcion: Este paso permite verificar que un elemento tiene un tamaño de fuente que se adapta al tamaño del viewport.


---

## --- Salesforce ---

step: espero a que cargue Salesforce Lightning
descripcion: Este paso permite esperar a que Salesforce Lightning termine de cargar completamente, incluyendo todos los componentes dinámicos de la interfaz.

step: navego a la aplicación de Salesforce "{app_name}"
descripcion: Este paso permite navegar a una aplicación específica dentro de Salesforce usando el App Launcher.

step: navego al objeto de Salesforce "{object_name}"
descripcion: Este paso permite navegar a un objeto específico de Salesforce como Account, Contact, Opportunity, etc.

step: creo un nuevo registro de Salesforce para el objeto "{object_name}"
descripcion: Este paso permite iniciar la creación de un nuevo registro para un objeto específico de Salesforce.

step: relleno el campo de Salesforce "{field_name}" con "{value}"
descripcion: Este paso permite rellenar un campo específico en un formulario de Salesforce. Maneja diferentes tipos de campos (texto, fecha, lookup, picklist).

step: selecciono la opción "{option}" del picklist "{field_name}" de Salesforce
descripcion: Este paso permite seleccionar una opción de un campo picklist (lista desplegable) de Salesforce.

step: busco y selecciono el lookup "{field_name}" de Salesforce con "{search_term}"
descripcion: Este paso permite buscar y seleccionar un valor en un campo lookup de Salesforce usando un término de búsqueda.

step: guardo el registro de Salesforce
descripcion: Este paso permite guardar el registro actual en Salesforce haciendo click en el botón Save.

step: verifico que el campo "{field_name}" del registro de Salesforce contiene "{expected_value}"
descripcion: Este paso permite verificar que un campo específico de un registro de Salesforce tiene el valor esperado.

step: hago click en la pestaña "{tab_name}" de Salesforce
descripcion: Este paso permite hacer click en una pestaña específica dentro de un registro de Salesforce (Details, Related, etc.).

step: espero el mensaje toast de Salesforce "{message_type}"
descripcion: Este paso permite esperar a que aparezca un mensaje toast de Salesforce (success, error, warning, info).

step: cierro los mensajes toast de Salesforce
descripcion: Este paso permite cerrar todos los mensajes toast visibles en Salesforce.

step: cambio a la vista clásica de Salesforce
descripcion: Este paso permite cambiar de Salesforce Lightning a Salesforce Classic.

step: cambio a la vista Lightning de Salesforce
descripcion: Este paso permite cambiar de Salesforce Classic a Lightning Experience.

step: abro el registro "{record_id}" de Salesforce para el objeto "{object_name}"
descripcion: Este paso permite abrir un registro específico de Salesforce usando su ID y tipo de objeto.

step: edito el registro de Salesforce
descripcion: Este paso permite iniciar la edición del registro de Salesforce actualmente visible.

step: elimino el registro de Salesforce
descripcion: Este paso permite eliminar el registro de Salesforce actualmente visible.

step: busco en la búsqueda global de Salesforce con "{search_term}"
descripcion: Este paso permite realizar una búsqueda global en Salesforce usando un término de búsqueda.

---

## --- Validación Semántica ---

step: configuro el modelo semántico como "{model_name}"
descripcion: Este paso permite configurar el modelo de embeddings semánticos a utilizar para las comparaciones de similitud (ej: all-MiniLM-L6-v2).

step: establezco el umbral de similitud semántica en {threshold:f}
descripcion: Este paso permite establecer el umbral mínimo de similitud semántica para las validaciones. Valores entre 0.0 y 1.0.

step: uso la configuración semántica por defecto
descripcion: Este paso permite restablecer la configuración semántica a los valores por defecto del framework.

step: el texto "{actual_text}" debe ser semánticamente similar a "{expected_text}"
descripcion: Este paso permite verificar que dos textos son semánticamente similares usando embeddings de lenguaje natural, sin requerir coincidencia exacta.

step: el texto de la variable "{var_name}" debe ser semánticamente similar a "{expected_text}"
descripcion: Este paso permite verificar que el texto almacenado en una variable es semánticamente similar a un texto esperado.

step: calculo la similitud semántica entre "{text1}" y "{text2}" y la guardo en "{var_name}"
descripcion: Este paso permite calcular el score de similitud semántica entre dos textos y guardarlo en una variable para uso posterior.

step: el texto del elemento "{element_name}" con identificador "{locator}" debe ser semánticamente similar a "{expected_text}"
descripcion: Este paso permite verificar que el texto visible de un elemento web es semánticamente similar a un texto esperado.

---

## --- NLP Semántico ---

step: extraigo las entidades del texto "{text}" y las guardo en "{var_name}"
descripcion: Este paso permite extraer entidades nombradas (personas, organizaciones, lugares, fechas) de un texto usando procesamiento de lenguaje natural.

step: verifico que el texto "{text}" contiene una entidad de tipo "{entity_type}"
descripcion: Este paso permite verificar que un texto contiene al menos una entidad de un tipo específico (PERSON, ORG, LOC, DATE, etc.).

step: genero un resumen del texto "{text}" y lo guardo en "{var_name}"
descripcion: Este paso permite generar un resumen automático de un texto usando modelos de lenguaje natural y guardarlo en una variable.

step: genero un resumen de la variable "{var_name}" con máximo {max_words:d} palabras y lo guardo en "{output_var}"
descripcion: Este paso permite generar un resumen de un texto almacenado en una variable con un límite máximo de palabras.

step: traduzco el texto "{text}" de "{source_lang}" a "{target_lang}" y lo guardo en "{var_name}"
descripcion: Este paso permite traducir un texto de un idioma a otro usando modelos de traducción automática.

step: genero una respuesta para "{prompt}" y la guardo en "{var_name}"
descripcion: Este paso permite generar una respuesta de texto para un prompt usando modelos de lenguaje natural.

step: analizo la toxicidad del texto "{text}" y guardo el resultado en "{var_name}"
descripcion: Este paso permite analizar el nivel de toxicidad de un texto y guardar el resultado (score y categorías) en una variable.

step: verifico que el texto "{text}" no es tóxico
descripcion: Este paso permite verificar que un texto no contiene lenguaje tóxico según el análisis de NLP.

step: extraigo las palabras clave del texto "{text}" y las guardo en "{var_name}"
descripcion: Este paso permite extraer las palabras clave más relevantes de un texto usando técnicas de NLP.

step: agrupo los textos "{text_list}" en {num_clusters:d} clusters y guardo los resultados en "{var_name}"
descripcion: Este paso permite agrupar una lista de textos en clusters semánticos usando algoritmos de clustering.

step: respondo la pregunta "{question}" basándome en el contexto "{context_text}" y guardo la respuesta en "{var_name}"
descripcion: Este paso permite responder una pregunta basándose en un contexto de texto proporcionado usando modelos de question-answering.

---

## --- Análisis Semántico Avanzado ---

step: el sentimiento del texto "{text}" debe ser "{expected_sentiment}"
descripcion: Este paso permite verificar que el sentimiento de un texto coincide con el esperado (positivo, negativo, neutro).

step: el sentimiento de la variable "{var_name}" debe ser "{expected_sentiment}"
descripcion: Este paso permite verificar que el sentimiento del texto almacenado en una variable coincide con el esperado.

step: clasifico el texto "{text}" en las categorías "{categories}" y guardo el resultado en "{var_name}"
descripcion: Este paso permite clasificar un texto en categorías predefinidas usando modelos de clasificación de texto.

step: el texto "{text}" debe pertenecer a la categoría "{expected_category}" de "{categories}"
descripcion: Este paso permite verificar que un texto es clasificado en una categoría específica dentro de un conjunto de categorías.

step: detecto el idioma del texto "{text}" y lo guardo en "{var_name}"
descripcion: Este paso permite detectar automáticamente el idioma de un texto y guardar el resultado en una variable.

step: el idioma del texto "{text}" debe ser "{expected_language}"
descripcion: Este paso permite verificar que un texto está escrito en un idioma específico.

step: busco el texto más similar a "{query}" en la lista "{text_list}" y lo guardo en "{var_name}"
descripcion: Este paso permite buscar el texto más semánticamente similar a una consulta dentro de una lista de textos.

step: comparo el texto "{text}" con múltiples referencias "{references}" y muestro las similitudes
descripcion: Este paso permite comparar un texto con múltiples textos de referencia y mostrar los scores de similitud de cada comparación.


---

## --- Supabase y Vectores ---

step: me conecto a Supabase con URL "{supabase_url}" y key "{supabase_key}"
descripcion: Este paso permite establecer una conexión a Supabase proporcionando la URL del proyecto y la API key directamente.

step: me conecto a Supabase usando variables de entorno
descripcion: Este paso permite conectarse a Supabase usando las variables de entorno SUPABASE_URL y SUPABASE_KEY configuradas en el archivo .env.

step: busco en la tabla "{table_name}" el contexto más similar a "{query}" y lo guardo en "{variable_name}"
descripcion: Este paso permite realizar una búsqueda vectorial en una tabla de Supabase para encontrar el contexto más similar a una consulta, usando embeddings de Gemini.

step: busco en la tabla "{table_name}" los {count} contextos más similares a "{query}" y los guardo en "{variable_name}"
descripcion: Este paso permite buscar múltiples contextos similares en Supabase usando búsqueda vectorial con Gemini, retornando los N más relevantes.

step: cargo el contexto de Supabase tabla "{table_name}" para la query "{query}" en el contexto de Gemini "{context_name}"
descripcion: Este paso permite buscar contexto relevante en Supabase y cargarlo directamente en el contexto de Gemini para uso en evaluaciones.

step: consulto la tabla "{table_name}" en Supabase y guardo el resultado en "{variable_name}"
descripcion: Este paso permite consultar todos los registros de una tabla de Supabase y guardar el resultado en una variable.

step: consulto la tabla "{table_name}" filtrando por "{column}" igual a "{value}" y guardo en "{variable_name}"
descripcion: Este paso permite consultar una tabla de Supabase aplicando un filtro de igualdad en una columna específica.

---

## --- Elementos Web ---

step: establezco el atributo "{attribute}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite establecer o modificar un atributo HTML de un elemento web usando JavaScript.

step: elimino el atributo "{attribute}" del elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite eliminar un atributo HTML de un elemento web.

step: establezco el estilo CSS "{property}" con valor "{value}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite establecer una propiedad de estilo CSS directamente en un elemento web.

step: disparo el evento "{event}" en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite disparar un evento JavaScript específico (click, change, input, focus, etc.) en un elemento web.

step: enfoco el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite dar foco a un elemento web específico, equivalente a hacer click o navegar con Tab hasta el elemento.

step: desenfocar el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite quitar el foco de un elemento web específico, disparando el evento blur.

step: selecciono el texto del elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite seleccionar todo el texto contenido dentro de un elemento web.

step: limpio la selección en la página
descripcion: Este paso permite limpiar cualquier selección de texto activa en la página.

step: simulo mouse enter en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite simular el evento mouseenter en un elemento, útil para activar efectos hover.

step: simulo mouse leave en el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite simular el evento mouseleave moviendo el mouse fuera del elemento.

step: obtengo las dimensiones del elemento y las guardo en variables ancho="{width_var}" alto="{height_var}" para elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite obtener el ancho y alto de un elemento web y guardarlos en variables separadas.

step: obtengo la posición del elemento y la guardo en variables x="{x_var}" y="{y_var}" para elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite obtener las coordenadas x,y de un elemento web y guardarlas en variables separadas.

step: clono el elemento "{source_element}" y lo añado a "{target_element}" con identificadores "{source_id}" y "{target_id}"
descripcion: Este paso permite clonar un elemento del DOM y añadirlo como hijo de otro elemento.

step: elimino el elemento "{element_name}" con identificador "{identifier}"
descripcion: Este paso permite eliminar un elemento del DOM de la página.

---

## --- Avanzado ---

step: tomo una captura de pantalla simple
descripcion: Este paso permite tomar una captura de pantalla de la página actual con un nombre generado automáticamente basado en el timestamp.

step: tomo una captura de pantalla con nombre "{filename}"
descripcion: Este paso permite tomar una captura de pantalla de la página actual y guardarla con un nombre específico.

step: arrastro el elemento "{source_element}" al elemento "{target_element}" con identificador origen "{source_id}" e identificador destino "{target_id}"
descripcion: Este paso permite arrastrar un elemento y soltarlo sobre otro elemento usando drag and drop nativo del navegador.

step: simulo la combinación de teclas "{keys}"
descripcion: Este paso permite simular una combinación de teclas del teclado (ej: Ctrl+C, Alt+Tab, Shift+Enter).

step: establezco la geolocalización del navegador a latitud {latitude:f} y longitud {longitude:f}
descripcion: Este paso permite establecer una geolocalización simulada en el navegador, útil para testing de funcionalidades basadas en ubicación.

step: emulo el dispositivo "{device_name}"
descripcion: Este paso permite emular un dispositivo específico (iPhone, iPad, Pixel, etc.) configurando viewport, user agent y otras propiedades del dispositivo.

---

## --- Jira y Xray ---

step: verifico la conexión con Jira
descripcion: Este paso permite verificar que la conexión con Jira está configurada correctamente y es funcional.

step: verifico que la issue "{issue_key}" existe en Jira
descripcion: Este paso permite verificar que una issue específica existe en Jira usando su clave (ej: PROJ-123).

step: agrego un comentario "{comment}" a la issue "{issue_key}"
descripcion: Este paso permite agregar un comentario a una issue existente en Jira.

step: adjunto el archivo "{file_path}" a la issue "{issue_key}"
descripcion: Este paso permite adjuntar un archivo local a una issue de Jira.

step: verifico la configuración de Xray
descripcion: Este paso permite verificar que la configuración de Xray (plugin de testing para Jira) está correcta.

step: creo un test execution "{summary}" en Xray
descripcion: Este paso permite crear un nuevo Test Execution en Xray con un resumen específico.

step: agrego los tests "{test_keys}" al test execution actual
descripcion: Este paso permite agregar tests existentes al Test Execution actual en Xray.

step: actualizo el estado del test "{test_key}" a "{status}" en el test execution actual
descripcion: Este paso permite actualizar el estado de un test (PASS, FAIL, TODO) en el Test Execution actual de Xray.

step: verifico que el test "{test_key}" es de tipo Test en Jira
descripcion: Este paso permite verificar que una issue de Jira es de tipo Test (issue type de Xray).

step: busco issues en Jira con JQL "{jql}"
descripcion: Este paso permite buscar issues en Jira usando una consulta JQL (Jira Query Language).

step: verifico que la búsqueda JQL encontró "{expected_count}" issues
descripcion: Este paso permite verificar que una búsqueda JQL retornó un número específico de resultados.

step: muestro información de la integración Jira/Xray
descripcion: Este paso permite mostrar en consola la información de configuración actual de la integración con Jira y Xray.

step: si el escenario falla creo una issue de tipo "{issue_type}" con el título "{title}"
descripcion: Este paso permite configurar la creación automática de una issue en Jira si el escenario actual falla.

step: si el escenario falla creo una issue de tipo "{issue_type}" con título "{title}" y prioridad "{priority}"
descripcion: Este paso permite configurar la creación automática de una issue en Jira con prioridad específica si el escenario falla.

step: si el escenario falla creo una issue de tipo "{issue_type}" con título "{title}" y descripción "{description}"
descripcion: Este paso permite configurar la creación automática de una issue en Jira con descripción personalizada si el escenario falla.