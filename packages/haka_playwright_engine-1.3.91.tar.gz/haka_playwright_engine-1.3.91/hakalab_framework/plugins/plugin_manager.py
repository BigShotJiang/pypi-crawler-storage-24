"""
Gestor de plugins para Behave.
"""
from typing import List
from .base_plugin import BasePlugin
from .html_report_plugin import HtmlReportPlugin
from .ai_report_plugin import AIReportPlugin
from .soft_assertions_plugin import SoftAssertionsPlugin
from .screenshot_plugin import ScreenshotPlugin
from .jira_xray_plugin import JiraXrayPlugin
from .jira_config_plugin import JiraConfigPlugin
from .azure_devops_plugin import AzureDevOpsPlugin


class PluginManager:
    """Gestor centralizado de plugins del framework."""
    
    def __init__(self):
        """Inicializa el gestor con todos los plugins disponibles."""
        self.plugins: List[BasePlugin] = [
            HtmlReportPlugin(),
            AIReportPlugin(),
            SoftAssertionsPlugin(),
            ScreenshotPlugin(),
            JiraConfigPlugin(),   # Debe ir ANTES de JiraXrayPlugin
            JiraXrayPlugin(),
            AzureDevOpsPlugin(),
        ]
        
        # Filtrar solo plugins habilitados
        self.enabled_plugins = [p for p in self.plugins if p.enabled]
        
        # Log de plugins habilitados
        if self.enabled_plugins:
            plugin_names = [p.__class__.__name__ for p in self.enabled_plugins]
            print(f"🔌 Plugins habilitados: {', '.join(plugin_names)}")
    
    def before_all(self, context) -> None:
        """Ejecuta before_all en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.before_all(context)
    
    def after_all(self, context) -> None:
        """Ejecuta after_all en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.after_all(context)
    
    def before_feature(self, context, feature) -> None:
        """Ejecuta before_feature en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.before_feature(context, feature)
    
    def after_feature(self, context, feature) -> None:
        """Ejecuta after_feature en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.after_feature(context, feature)
    
    def before_scenario(self, context, scenario) -> None:
        """Ejecuta before_scenario en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.before_scenario(context, scenario)
    
    def after_scenario(self, context, scenario) -> None:
        """Ejecuta after_scenario en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.after_scenario(context, scenario)
    
    def before_step(self, context, step) -> None:
        """Ejecuta before_step en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.before_step(context, step)
    
    def after_step(self, context, step) -> None:
        """Ejecuta after_step en todos los plugins habilitados."""
        for plugin in self.enabled_plugins:
            plugin.after_step(context, step)
