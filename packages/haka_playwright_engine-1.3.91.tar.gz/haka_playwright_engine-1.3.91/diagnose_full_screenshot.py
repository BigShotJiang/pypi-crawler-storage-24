#!/usr/bin/env python3
"""
Script de diagnóstico completo para SCREENSHOT_FULL_PAGE
Verifica TODAS las funciones que capturan screenshots
"""
import os
import sys
import inspect
from dotenv import load_dotenv

# Cargar .env
load_dotenv()

print("=" * 80)
print("DIAGNÓSTICO COMPLETO DE SCREENSHOT_FULL_PAGE")
print("=" * 80)

# 1. Verificar versión instalada
print("\n1️⃣ VERSIÓN DEL FRAMEWORK:")
try:
    import hakalab_framework
    print(f"   📦 Versión: {hakalab_framework.__version__}")
    print(f"   📂 Ubicación: {hakalab_framework.__file__}")
except Exception as e:
    print(f"   ❌ Error: {e}")

# 2. Variable de entorno
print("\n2️⃣ VARIABLE DE ENTORNO:")
screenshot_full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'NOT_SET')
print(f"   📋 SCREENSHOT_FULL_PAGE = '{screenshot_full_page}'")
full_page_bool = screenshot_full_page.lower() == 'true' if screenshot_full_page != 'NOT_SET' else True
print(f"   🔍 Procesado como: {full_page_bool} ({'FULL PAGE' if full_page_bool else 'VIEWPORT'})")

# 3. Verificar código de screenshot_manager
print("\n3️⃣ CÓDIGO DE SCREENSHOT_MANAGER:")
try:
    from hakalab_framework.core import screenshot_manager
    
    # Verificar take_screenshot
    print("\n   📝 take_screenshot():")
    source = inspect.getsource(screenshot_manager.take_screenshot)
    for i, line in enumerate(source.split('\n'), 1):
        if 'SCREENSHOT_FULL_PAGE' in line:
            print(f"      Línea {i}: {line.strip()}")
    
    # Verificar take_screenshot_on_failure
    print("\n   📝 take_screenshot_on_failure():")
    source = inspect.getsource(screenshot_manager.take_screenshot_on_failure)
    for i, line in enumerate(source.split('\n'), 1):
        if 'SCREENSHOT_FULL_PAGE' in line:
            print(f"      Línea {i}: {line.strip()}")
    
    # Verificar take_step_screenshot
    print("\n   📝 take_step_screenshot():")
    source = inspect.getsource(screenshot_manager.take_step_screenshot)
    for i, line in enumerate(source.split('\n'), 1):
        if 'SCREENSHOT_FULL_PAGE' in line:
            print(f"      Línea {i}: {line.strip()}")
            
except Exception as e:
    print(f"   ❌ Error: {e}")

# 4. Verificar código de behave_html_integration
print("\n4️⃣ CÓDIGO DE BEHAVE_HTML_INTEGRATION:")
try:
    from hakalab_framework.core import behave_html_integration
    
    print("\n   📝 after_step_html():")
    source = inspect.getsource(behave_html_integration.after_step_html)
    
    # Contar cuántas veces aparece SCREENSHOT_FULL_PAGE
    count = source.count('SCREENSHOT_FULL_PAGE')
    print(f"      Apariciones de SCREENSHOT_FULL_PAGE: {count}")
    
    if count > 0:
        for i, line in enumerate(source.split('\n'), 1):
            if 'SCREENSHOT_FULL_PAGE' in line:
                print(f"      Línea {i}: {line.strip()}")
    else:
        print("      ⚠️ NO ENCONTRADO - Esto es el problema!")
        
except Exception as e:
    print(f"   ❌ Error: {e}")

# 5. Verificar plugins
print("\n5️⃣ CÓDIGO DE PLUGINS:")
try:
    from hakalab_framework.plugins import screenshot_plugin
    
    print("\n   📝 ScreenshotPlugin.after_step():")
    source = inspect.getsource(screenshot_plugin.ScreenshotPlugin.after_step)
    print(f"      Usa: take_screenshot() - {'✅' if 'take_screenshot' in source else '❌'}")
    
except Exception as e:
    print(f"   ❌ Error: {e}")

try:
    from hakalab_framework.plugins import html_report_plugin
    
    print("\n   📝 HtmlReportPlugin.after_step():")
    source = inspect.getsource(html_report_plugin.HtmlReportPlugin.after_step)
    print(f"      Usa: after_step_html() - {'✅' if 'after_step_html' in source else '❌'}")
    
except Exception as e:
    print(f"   ❌ Error: {e}")

# 6. Prueba real
print("\n6️⃣ PRUEBA REAL:")
try:
    from playwright.sync_api import sync_playwright
    from pathlib import Path
    
    test_dir = Path("test_diagnosis")
    test_dir.mkdir(exist_ok=True)
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page(viewport={'width': 1280, 'height': 720})
        page.goto('https://example.com')
        
        # Test con configuración
        screenshot_path = test_dir / 'test_config.png'
        full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'true').lower() == 'true'
        page.screenshot(path=str(screenshot_path), full_page=full_page)
        
        # Verificar tamaño
        from PIL import Image
        img = Image.open(screenshot_path)
        mode = "FULL PAGE" if full_page else "VIEWPORT"
        print(f"   📸 Screenshot: {img.size[0]}x{img.size[1]} - {mode}")
        
        if img.size[1] > 800:
            print(f"   ⚠️ PROBLEMA: Screenshot es muy alto ({img.size[1]}px) - parece FULL PAGE")
        else:
            print(f"   ✅ OK: Screenshot es viewport ({img.size[1]}px)")
        
        browser.close()
        
except Exception as e:
    print(f"   ❌ Error: {e}")

print("\n" + "=" * 80)
print("DIAGNÓSTICO COMPLETADO")
print("=" * 80)
