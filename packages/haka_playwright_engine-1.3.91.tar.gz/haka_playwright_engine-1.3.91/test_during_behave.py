#!/usr/bin/env python3
"""
Script para verificar qué pasa con SCREENSHOT_FULL_PAGE durante behave
"""
import os
import sys

# Simular lo que hace behave
print("=" * 80)
print("SIMULACIÓN DE BEHAVE")
print("=" * 80)

# 1. Antes de cargar dotenv
print("\n1️⃣ ANTES DE CARGAR .env:")
print(f"   SCREENSHOT_FULL_PAGE = {os.getenv('SCREENSHOT_FULL_PAGE', 'NOT_SET')}")

# 2. Cargar como lo hace el framework
from pathlib import Path
from dotenv import load_dotenv

current_dir = Path.cwd()
env_found = False

for parent in [current_dir] + list(current_dir.parents):
    env_path = parent / '.env'
    if env_path.exists():
        print(f"\n2️⃣ CARGANDO .env desde: {env_path}")
        load_dotenv(env_path)
        env_found = True
        break

if not env_found:
    print("\n2️⃣ NO SE ENCONTRÓ .env")

# 3. Después de cargar
print(f"\n3️⃣ DESPUÉS DE CARGAR .env:")
screenshot_full_page = os.getenv('SCREENSHOT_FULL_PAGE', 'NOT_SET')
print(f"   SCREENSHOT_FULL_PAGE = '{screenshot_full_page}'")

# 4. Procesar como lo hace el framework
if screenshot_full_page != 'NOT_SET':
    full_page = screenshot_full_page.lower() == 'true'
    print(f"   Procesado: {full_page} ({'FULL PAGE' if full_page else 'VIEWPORT'})")
else:
    print(f"   ⚠️ Variable no encontrada, usando default: True (FULL PAGE)")

# 5. Verificar contenido del .env
print(f"\n4️⃣ CONTENIDO DEL .env:")
if env_found:
    with open(env_path, 'r') as f:
        for line in f:
            if 'SCREENSHOT' in line.upper():
                print(f"   {line.rstrip()}")
