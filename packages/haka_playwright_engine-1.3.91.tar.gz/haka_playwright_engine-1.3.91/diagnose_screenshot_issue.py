#!/usr/bin/env python3
"""
Script de diagnóstico completo para el problema de screenshots
"""
import os
import sys
from dotenv import load_dotenv
from pathlib import Path

print("="*70)
print("DIAGNÓSTICO DE SCREENSHOTS - HAKA FRAMEWORK")
print("="*70)

# 1. Verificar versión del framework instalado
print("\n1️⃣ VERSIÓN DEL FRAMEWORK:")
try:
    import hakalab_framework
    print(f"   ✅ Versión instalada: {hakalab_framework.__version__}")
    if hakalab_framework.__version__ < "1.3.72":
        print(f"   ⚠️  ADVERTENCIA: Versión antigua detectada!")
        print(f"   💡 Ejecuta: pip install --upgrade haka-playwright-engine")
except Exception as e:
    print(f"   ❌ Error: {e}")

# 2. Cargar .env
print("\n2️⃣ ARCHIVO .ENV:")
if Path('.env').exists():
    load_dotenv('.env')
    print("   ✅ Archivo .env encontrado y cargado")
    
    # Mostrar contenido relevante
    with open('.env', 'r') as f:
        lines = f.readlines()
        for line in lines:
            if 'SCREENSHOT' in line:
                print(f"   📄 {line.strip()}")
else:
    print("   ❌ Archivo .env NO encontrado")

# 3. Leer variable de entorno
print("\n3️⃣ VARIABLE DE ENTORNO:")
screenshot_full_page_raw = os.getenv('SCREENSHOT_FULL_PAGE', 'NOT_SET')
print(f"   📋 Valor RAW: '{screenshot_full_page_raw}'")
print(f"   📋 Tipo: {type(screenshot_full_page_raw)}")

if screenshot_full_page_raw != 'NOT_SET':
    full_page = screenshot_full_page_raw.lower() == 'true'
    print(f"\n   🔍 Procesamiento:")
    print(f"      .lower() = '{screenshot_full_page_raw.lower()}'")
    print(f"      .lower() == 'true' = {full_page}")
    print(f"\n   {'✅' if not full_page else '❌'} Resultado: {'VIEWPORT' if not full_page else 'FULL PAGE'}")
else:
    print(f"\n   ⚠️  Variable NO definida")
    print(f"   💡 Default del framework: FULL PAGE")

# 4. Verificar código del framework instalado
print("\n4️⃣ CÓDIGO DEL FRAMEWORK:")
try:
    from hakalab_framework.core import screenshot_manager
    import inspect
    
    # Obtener el código de la función take_screenshot
    source = inspect.getsource(screenshot_manager.take_screenshot)
    
    # Buscar la línea donde se lee SCREENSHOT_FULL_PAGE
    for i, line in enumerate(source.split('\n'), 1):
        if 'SCREENSHOT_FULL_PAGE' in line:
            print(f"   📝 Línea {i}: {line.strip()}")
            break
    
    print(f"   ✅ Código del framework verificado")
    
except Exception as e:
    print(f"   ❌ Error: {e}")

# 5. Verificar si hay cache de Python
print("\n5️⃣ CACHE DE PYTHON:")
framework_path = None
try:
    import hakalab_framework
    framework_path = Path(hakalab_framework.__file__).parent
    print(f"   📂 Ubicación: {framework_path}")
    
    # Buscar archivos .pyc
    pyc_files = list(framework_path.rglob("*.pyc"))
    if pyc_files:
        print(f"   ⚠️  Encontrados {len(pyc_files)} archivos .pyc (cache)")
        print(f"   💡 Considera limpiar cache: python -m pip install --force-reinstall --no-cache-dir haka-playwright-engine")
    else:
        print(f"   ✅ No hay archivos .pyc")
        
except Exception as e:
    print(f"   ❌ Error: {e}")

# 6. Recomendaciones
print("\n6️⃣ RECOMENDACIONES:")
print("   1. Verifica que estás usando la versión 1.3.72 o superior")
print("   2. Asegúrate de que el .env tiene: SCREENSHOT_FULL_PAGE=false")
print("   3. Reinicia tu IDE/terminal después de actualizar")
print("   4. Si el problema persiste, reinstala el framework:")
print("      pip uninstall haka-playwright-engine")
print("      pip install haka-playwright-engine")

print("\n" + "="*70)
print("FIN DEL DIAGNÓSTICO")
print("="*70)
