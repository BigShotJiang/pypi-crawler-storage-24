"""Deception response engine."""

from __future__ import annotations

from typing import Any


class DeceptionEngine:
    """Generates operational deception actions from risk level."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        safety_cfg = config.get("safety", {})
        self.destructive_actions_enabled = bool(safety_cfg.get("destructive_actions_enabled", False))

    def evaluate(self, level: str) -> str:
        """Return an action message for given level."""
        safe_messages = {
            "LOW": "Continue passive monitoring.",
            "MEDIUM": "Increase decoy visibility.",
            "HIGH": "Deploy active deception traps.",
            "CRITICAL": "Escalate to full deception protocol (safe mode).",
        }
        destructive_messages = {
            "LOW": "Continue passive monitoring.",
            "MEDIUM": "Increase decoy visibility.",
            "HIGH": "Deploy active deception traps.",
            "CRITICAL": "Execute critical containment protocol.",
        }
        messages = destructive_messages if self.destructive_actions_enabled else safe_messages
        return messages.get(level, messages["LOW"])
