"""Network monitor that emits raw events (not decisions)."""

from __future__ import annotations

from typing import Any

from ..core.signals import Event

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None


class NetworkMonitor:
    """Collects local telemetry and emits signals."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        processing = config.get("processing", {})
        self.max_events_per_cycle = int(processing.get("max_events_per_cycle", 5000))

    def scan(self) -> list[Event]:
        """Return current events based on safe local checks."""
        events: list[Event] = []
        if psutil is None:
            return events

        cpu_percent = float(psutil.cpu_percent(interval=0.0))
        if cpu_percent > 90.0:
            events.append(
                Event(
                    source="network_monitor",
                    event_type="high_cpu",
                    severity=0.5,
                    payload={"cpu_percent": cpu_percent},
                )
            )
        return events[: self.max_events_per_cycle]
