"""File-over-DNS encoding and decoding via TXT records.

Protocol:
    Each file chunk is stored as a TXT record at <chunk_idx>.<subdomain>.
    The TXT record value is base32-encoded, containing: "idx:total:base64data"
    A metadata record at _meta.<subdomain> stores: "sha256:<hash>:chunks:<count>"
"""

import base64
import hashlib
import math

from gcnspack.resolver import resolve

# Max raw bytes per chunk before base64 encoding.
# TXT records can hold ~255 bytes per string. After base64 + base32 encoding
# with header overhead, 150 bytes of raw data per chunk is safe.
CHUNK_SIZE = 150


def encode_file(data: bytes) -> list[str]:
    """Encode file bytes into a list of base32 TXT record values.

    Args:
        data: Raw file bytes to encode.

    Returns:
        List of base32-encoded chunk strings, ordered by index.
    """
    if len(data) == 0:
        inner = f"0:1:{base64.b64encode(b'').decode()}"
        return [base64.b32encode(inner.encode()).decode()]

    total = math.ceil(len(data) / CHUNK_SIZE)
    chunks = []
    for i in range(total):
        start = i * CHUNK_SIZE
        end = start + CHUNK_SIZE
        chunk_data = data[start:end]
        b64 = base64.b64encode(chunk_data).decode()
        inner = f"{i}:{total}:{b64}"
        chunks.append(base64.b32encode(inner.encode()).decode())
    return chunks


def parse_txt_record(record: str) -> tuple[int, int, bytes]:
    """Parse a single base32-encoded TXT record value.

    Args:
        record: Base32-encoded string from a TXT record.

    Returns:
        Tuple of (chunk_index, total_chunks, raw_payload_bytes).

    Raises:
        ValueError: If the record cannot be decoded or has invalid format.
    """
    try:
        decoded = base64.b32decode(record).decode("ascii")
    except Exception as exc:
        raise ValueError(f"Failed to decode base32 TXT record: {exc}") from exc

    parts = decoded.split(":", 2)
    if len(parts) != 3:
        raise ValueError(f"Invalid chunk format: expected 'idx:total:data', got '{decoded}'")

    idx = int(parts[0])
    total = int(parts[1])
    payload = base64.b64decode(parts[2])
    return idx, total, payload


def decode_chunks(chunks: list[str]) -> bytes:
    """Decode a list of base32 TXT record values back to file bytes.

    Chunks can be in any order; they are sorted by index.

    Args:
        chunks: List of base32-encoded chunk strings.

    Returns:
        Reconstructed file bytes.
    """
    parsed = [parse_txt_record(chunk) for chunk in chunks]
    parsed.sort(key=lambda x: x[0])
    return b"".join(payload for _, _, payload in parsed)


def generate_zone_records(data: bytes, subdomain: str) -> list[str]:
    """Generate DNS zone-file TXT records for a file.

    Args:
        data: Raw file bytes to encode.
        subdomain: Base subdomain (e.g., "files.example.com").

    Returns:
        List of zone-file lines, including chunk records and a _meta record.
    """
    chunks = encode_file(data)
    total = len(chunks)
    sha256 = hashlib.sha256(data).hexdigest()

    records = []
    for i, chunk in enumerate(chunks):
        records.append(f'{i}.{subdomain}\tIN\tTXT\t"{chunk}"')

    meta = f"sha256:{sha256}:chunks:{total}"
    meta_b32 = base64.b32encode(meta.encode()).decode()
    records.append(f'_meta.{subdomain}\tIN\tTXT\t"{meta_b32}"')
    return records


def fetch_file(subdomain: str) -> bytes:
    """Fetch and reconstruct a file from DNS TXT records.

    Reads _meta.<subdomain> for chunk count, then fetches each chunk.

    Args:
        subdomain: The subdomain where chunks are stored.

    Returns:
        Reconstructed file bytes.

    Raises:
        RuntimeError: If metadata or chunks cannot be fetched.
    """
    meta_records = resolve(f"_meta.{subdomain}", "TXT")
    if not meta_records:
        raise RuntimeError(f"No metadata found at _meta.{subdomain}")

    meta_raw = meta_records[0].strip('"')
    try:
        meta_decoded = base64.b32decode(meta_raw).decode("ascii")
    except Exception as exc:
        raise RuntimeError(f"Failed to decode metadata: {exc}") from exc

    parts = meta_decoded.split(":")
    # Format: sha256:<hash>:chunks:<count>
    sha256_expected = parts[1]
    total_chunks = int(parts[3])

    chunks = []
    for i in range(total_chunks):
        txt = resolve(f"{i}.{subdomain}", "TXT")
        if not txt:
            raise RuntimeError(f"Missing chunk {i} at {i}.{subdomain}")
        chunks.append(txt[0].strip('"'))

    data = decode_chunks(chunks)

    sha256_actual = hashlib.sha256(data).hexdigest()
    if sha256_actual != sha256_expected:
        raise RuntimeError(f"Hash mismatch: expected {sha256_expected}, got {sha256_actual}")
    return data


def save_txt_file(subdomain: str, file_name: str) -> None:
    """Fetch a file from DNS TXT records and save it locally.

    Args:
        subdomain: The subdomain where chunks are stored.
        file_name: Local path to write the reconstructed file.
    """
    data = fetch_file(subdomain)
    with open(file_name, "wb") as f:
        f.write(data)
