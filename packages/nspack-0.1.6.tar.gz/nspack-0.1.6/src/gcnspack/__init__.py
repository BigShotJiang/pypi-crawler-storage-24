"""gcnspack - Simple DNS resolver and file-over-DNS transfer toolkit."""

__version__ = "0.1.6"

__all__ = [
    "create_resolver",
    "decode_chunks",
    "encode_file",
    "generate_zone_records",
    "resolve",
    "resolve_all",
    "rss",
    "save_txt_file",
]

from gcnspack.filedns import decode_chunks, encode_file, generate_zone_records, save_txt_file
from gcnspack.resolver import create_resolver, resolve, resolve_all, rss
