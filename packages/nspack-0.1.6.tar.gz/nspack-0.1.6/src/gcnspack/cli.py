"""CLI for gcnspack - DNS resolver and file-over-DNS toolkit."""

import sys
from pathlib import Path

import click

from gcnspack.filedns import generate_zone_records, save_txt_file
from gcnspack.resolver import create_resolver, resolve


@click.group()
@click.version_option()
def main():
    """gcnspack - Simple DNS resolver and file-over-DNS transfer toolkit."""


@main.command()
@click.argument("domain")
@click.option("-t", "--type", "rdtype", default="A", help="DNS record type")
@click.option("-n", "--nameserver", multiple=True, help="Custom nameserver(s)")
def resolve_cmd(domain: str, rdtype: str, nameserver: tuple[str, ...]):
    """Resolve DNS records for DOMAIN."""
    r = create_resolver(nameservers=list(nameserver)) if nameserver else None
    results = resolve(domain, rdtype, resolver=r)
    if not results:
        click.echo(f"No {rdtype} records found for {domain}", err=True)
        sys.exit(1)
    for record in results:
        click.echo(record)


# Register with the name "resolve" (click doesn't allow reusing Python names)
resolve_cmd.name = "resolve"


@main.command()
@click.argument("file", type=click.Path(exists=True))
@click.option("--subdomain", "-s", required=True, help="Base subdomain for TXT records")
@click.option("--output", "-o", type=click.Path(), help="Write zone records to file")
def encode(file: str, subdomain: str, output: str | None):
    """Encode FILE into DNS TXT zone records."""
    data = Path(file).read_bytes()
    records = generate_zone_records(data, subdomain)
    text = "\n".join(records) + "\n"
    if output:
        Path(output).write_text(text)
        click.echo(f"Wrote {len(records)} records to {output}")
    else:
        click.echo(text)


@main.command()
@click.argument("subdomain")
@click.option("--output", "-o", required=True, help="Output file path")
def fetch(subdomain: str, output: str):
    """Fetch and reconstruct a file from DNS TXT records at SUBDOMAIN."""
    try:
        save_txt_file(subdomain, output)
        click.echo(f"Saved file to {output}")
    except RuntimeError as exc:
        click.echo(f"Error: {exc}", err=True)
        sys.exit(1)
