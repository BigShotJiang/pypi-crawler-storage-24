"""
Simplified Insurance DB MCP Server - Minimal version for Baillian platform compatibility
"""
import json
import logging
import os

# 设置日志级别为DEBUG以获取更多详细信息
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger("insurance-db-mcp-simple")

try:
    from mcp.server.fastmcp import FastMCP
    logger.info("Successfully imported FastMCP")
except ImportError as e:
    logger.error(f"Failed to import FastMCP: {e}")
    # 如果导入失败，提供基本的错误响应
    def main():
        print("Error: Could not import required modules.")
        return
    raise

# 尝试导入数据库模块
try:
    from insurance_db_mcp.db import execute_query, test_connection, get_table_stats, SCHEMA_INFO, JSONEncoder
    logger.info("Successfully imported database modules")
except ImportError as e:
    logger.error(f"Failed to import database modules: {e}")
    raise

# 创建MCP Server实例
try:
    mcp = FastMCP(
        "insurance-db-mcp-simple",
        instructions="通过自然语言操作保险数据库的MCP工具。支持SQL执行、数据库Schema查看等功能。",
    )
    logger.info("Successfully created MCP instance")
except Exception as e:
    logger.error(f"Failed to create MCP instance: {e}")
    raise


@mcp.tool()
async def execute_sql_query(sql: str) -> str:
    """
    直接执行SQL查询语句。
    
    Args:
        sql: 要执行的SQL语句
    """
    try:
        logger.debug(f"Executing SQL query: {sql[:100]}...")  # 只记录前100个字符
        result = execute_query(sql)
        logger.debug(f"Query executed successfully, result keys: {result.keys() if isinstance(result, dict) else type(result)}")
        return json.dumps(result, ensure_ascii=False, indent=2, cls=JSONEncoder)
    except Exception as e:
        logger.error(f"Error executing SQL query: {str(e)}", exc_info=True)
        error_result = {
            "success": False,
            "error": str(e),
        }
        return json.dumps(error_result, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_database_schema() -> str:
    """
    获取数据库的完整结构信息。
    """
    try:
        logger.debug("Fetching database schema")
        return SCHEMA_INFO
    except Exception as e:
        logger.error(f"Error fetching schema: {str(e)}", exc_info=True)
        return f"Error getting schema: {str(e)}"


@mcp.tool()
async def test_db_connection() -> str:
    """
    测试数据库连接是否正常。
    """
    try:
        logger.debug("Testing database connection")
        connected = test_connection()
        result = {
            "success": True,
            "connected": connected,
            "message": "数据库连接正常" if connected else "数据库连接失败",
        }
        logger.debug(f"Connection test result: {connected}")
        return json.dumps(result, ensure_ascii=False, indent=2)
    except Exception as e:
        logger.error(f"Error testing connection: {str(e)}", exc_info=True)
        return json.dumps({
            "success": False,
            "connected": False,
            "error": str(e),
        }, ensure_ascii=False, indent=2)


def main():
    """Main entry point for the MCP server"""
    logger.info("Starting Insurance DB MCP Server Simple Version...")
    logger.info("Attempting to initialize with SSE transport for Baillian platform")
    
    try:
        # 直接尝试使用SSE传输协议
        from mcp.transport.sse import ServerSentEventsTransport
        logger.info("Successfully imported ServerSentEventsTransport")
        
        transport = ServerSentEventsTransport()
        logger.info("Successfully created transport instance")
        
        logger.info("Starting MCP server with SSE transport...")
        mcp.run(transport=transport)
        
    except ImportError as e:
        logger.error(f"SSE transport import failed: {e}", exc_info=True)
        logger.info("Falling back to default transport mode")
        
        try:
            logger.info("Starting MCP server with default transport...")
            mcp.run()
        except Exception as fallback_error:
            logger.error(f"Fallback execution failed: {fallback_error}", exc_info=True)
            raise
    
    except Exception as e:
        logger.error(f"MCP server startup failed: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
