import numpy as np
from typing import Tuple
from .algorithm import Algorithm

class GradientNesterovMomentum(Algorithm):
    r"""
    Gradient method with Nesterov-like momentum :cite:`nesterov2018lecturesconvexoptimization`.

    See :doc:`3. Algorithm representation </theory/algorithm_representation>`
    for mathematical notation and definitions.

    Notation-driven assumptions are declared by the user via
    :class:`~autolyap.problemclass.InclusionProblem`: when present, terms written with
    :math:`\nabla` use differentiable functions, terms written with
    :math:`\prox_{\gamma f}` use proper, lower semicontinuous, convex functions,
    and terms written with :math:`J_{\gamma G}` use maximally monotone operators.

    Standard form
    -------------


    For initial points :math:`x^{-1},x^0 \in \calH`, step size :math:`\gamma \in \reals_{++}`,
    and momentum parameter :math:`\delta \in \reals`,

    .. math::
        (\forall k \in \naturals)\quad
        \left[
        \begin{aligned}
            y^k &= x^k + \delta (x^k - x^{k-1}), \\
            x^{k+1} &= y^k - \gamma \nabla f(y^k).
        \end{aligned}
        \right.

    State-space representation
    --------------------------

    The update can be written in the algorithm representation with

    .. math::
        \bx^k = (x^k, x^{k-1}), \qquad
        \bu^k = \nabla f(y^k), \qquad
        \by^k = y^k.

    With this representation, the system matrices are

    .. math::
        \begin{aligned}
            A_k &=
            \begin{bmatrix}
            1+\delta & -\delta \\
            1 & 0
            \end{bmatrix}, &
            B_k &=
            \begin{bmatrix}
            -\gamma \\
            0
            \end{bmatrix}, \\
            C_k &=
            \begin{bmatrix}
            1+\delta & -\delta
            \end{bmatrix}, &
            D_k &= \begin{bmatrix} 0 \end{bmatrix}.
        \end{aligned}

    These are the system matrices returned by :meth:`~autolyap.algorithms.Algorithm.get_ABCD`.

    Structural parameters
    ---------------------

    .. math::
        n = 2,\quad m = 1,\quad (\bar{m}_i)_{i=1}^{m} = (1),\quad \bar{m} = 1.

    .. math::
        I_{\text{func}} = \{1\},\quad I_{\text{op}} = \varnothing.
    """
    def __init__(self, gamma: float, delta: float) -> None:
        r"""
        Initialize the method.

        Structural inputs passed to :class:`~autolyap.algorithms.Algorithm` are

        .. math::
            n = 2,\quad m = 1,\quad (\bar m_i)_{i=1}^{m} = (1),\quad \bar m = 1,\quad
            I_{\mathrm{func}} = \{1\},\quad I_{\mathrm{op}} = \varnothing.
        """
        super().__init__(2, 1, [1], [1], [])
        self.gamma = gamma
        self.delta = delta
    
    def set_gamma(self, gamma: float) -> None:
        r"""
        Set the step-size parameter :math:`\gamma`.

        Shared notation follows the class-level reference in
        :class:`~autolyap.algorithms.GradientNesterovMomentum`.

        **Parameters**

        - `gamma` (:class:`~typing.Union`\[:class:`int`, :class:`float`\]): The value corresponding to :math:`\gamma`.

        **Raises**

        - `ValueError`: If `gamma` is not a finite real number or if :math:`\gamma \le 0`.
        """
        gamma = self._validate_positive_finite_real(gamma, "gamma")
        self._set_dynamic_parameter("gamma", gamma)

    def set_delta(self, delta: float) -> None:
        r"""
        Set the momentum parameter :math:`\delta`.

        Shared notation follows the class-level reference in
        :class:`~autolyap.algorithms.GradientNesterovMomentum`.

        **Parameters**

        - `delta` (:class:`~typing.Union`\[:class:`int`, :class:`float`\]): The value corresponding to :math:`\delta`.

        **Raises**

        - `ValueError`: If `delta` is not a finite real number.
        """
        delta = self._validate_finite_real(delta, "delta")
        self._set_dynamic_parameter("delta", delta)
    
    def get_ABCD(self, k: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        A = np.array([[1+self.delta,-self.delta],[1,0]])
        B = np.array([[-self.gamma],[0]])
        C = np.array([[1+self.delta,-self.delta]])
        D = np.array([[0]])
        return (A, B, C, D)
