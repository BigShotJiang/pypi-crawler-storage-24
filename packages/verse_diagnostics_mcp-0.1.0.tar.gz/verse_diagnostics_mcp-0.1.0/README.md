# verse-diagnostics-mcp

MCP server that parses UEFN Verse build diagnostics from `UnrealEditorFortnite.log` and exposes structured error data to Claude Code, Cursor, VS Code, or any MCP client.

## Tools

| Tool | Description |
|------|-------------|
| `get_verse_diagnostics` | Parse Verse compile errors/warnings → structured JSON with file, line, column, code, message |
| `get_latest_build_session` | Get raw VerseBuild log lines from the most recent compile |
| `check_verse_log_freshness` | Check if the UEFN log was recently modified (build just ran?) |

## Quick Start

### Claude Code (uvx — recommended)

```bash
claude mcp add-json verse-diagnostics '{
  "type": "stdio",
  "command": "uvx",
  "args": ["verse-diagnostics-mcp"],
  "env": {
    "UEFN_LOG_PATH": "/mnt/c/Users/YOUR_USER/AppData/Local/UnrealEditorFortnite/Saved/Logs/UnrealEditorFortnite.log",
    "VERSE_PROJECT_ROOT": "C:/Users/YOUR_USER/Documents/Fortnite Projects"
  }
}' --scope user
```

### Claude Desktop / Cursor / VS Code

Add to your MCP config (`claude_desktop_config.json`, `.cursor/mcp.json`, etc.):

```json
{
  "mcpServers": {
    "verse-diagnostics": {
      "command": "uvx",
      "args": ["verse-diagnostics-mcp"],
      "env": {
        "UEFN_LOG_PATH": "C:\\Users\\YOUR_USER\\AppData\\Local\\UnrealEditorFortnite\\Saved\\Logs\\UnrealEditorFortnite.log",
        "VERSE_PROJECT_ROOT": "C:\\Users\\YOUR_USER\\Documents\\Fortnite Projects"
      }
    }
  }
}
```

### pip install

```bash
pip install verse-diagnostics-mcp
verse-diagnostics-mcp
```

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `UEFN_LOG_PATH` | Auto-detected (WSL/Windows) | Path to `UnrealEditorFortnite.log` |
| `VERSE_PROJECT_ROOT` | Auto-detected | Fortnite Projects directory (for relative paths in output) |

## Example Output

```json
{
  "ok": false,
  "source": "uefn-log",
  "error_count": 3,
  "warning_count": 0,
  "diagnostics": [
    {
      "file": "Berry/Content/hello_world_device.verse",
      "line": 25,
      "column": 17,
      "endLine": 25,
      "endColumn": 31,
      "severity": "error",
      "code": "VRS3506",
      "message": "Unknown identifier `switch_manager`",
      "timestamp": "2026-03-07T11:46:52+00:00"
    }
  ]
}
```

## How It Works

The server reads UEFN's `UnrealEditorFortnite.log` and parses `VerseBuild:` lines using regex. It extracts file paths, line/column ranges, error codes, and messages, deduplicates them (UEFN sometimes logs the same error twice with slightly different formatting), and returns structured JSON.

This is a **read-only log parser** — it cannot trigger builds. The user must compile from UEFN or VS Code (`verseWorkflow.compile`), then this server reads the results.

## CLAUDE.md Integration

Add this to your UEFN project's `CLAUDE.md`:

```md
## Verse diagnostics workflow
- After modifying any `.verse` file, use `get_verse_diagnostics` to check for errors.
- If diagnostics include errors, fix them and recheck until `"ok": true`.
- If an API is unfamiliar, verify against official Verse documentation before using it.
- Success = `"ok": true` in diagnostics output.
```

## License

MIT
