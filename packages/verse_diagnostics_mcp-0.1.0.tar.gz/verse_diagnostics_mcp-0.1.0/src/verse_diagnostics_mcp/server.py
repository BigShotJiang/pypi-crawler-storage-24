"""
verse_diagnostics_mcp - MCP server for parsing UEFN Verse build diagnostics.

Reads UnrealEditorFortnite.log to extract Verse compile errors/warnings,
normalizes them to structured JSON, and exposes tools for Claude Code.

Designed to run locally on the Windows machine (via WSL or native Python)
where UEFN writes its logs.
"""

import json
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List

from mcp.server.fastmcp import FastMCP
from pydantic import BaseModel, Field, ConfigDict

# ─────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────

# Default log path — override with UEFN_LOG_PATH env var
# WSL path to Windows log:
DEFAULT_LOG_PATH_WSL = (
    "/mnt/c/Users/marco/AppData/Local/UnrealEditorFortnite/Saved/Logs/UnrealEditorFortnite.log"
)
# Native Windows path:
DEFAULT_LOG_PATH_WIN = (
    r"C:\Users\marco\AppData\Local\UnrealEditorFortnite\Saved\Logs\UnrealEditorFortnite.log"
)

# Project root for making paths relative
DEFAULT_PROJECT_ROOT_WSL = "/mnt/c/Users/marco/Documents/Fortnite Projects"
DEFAULT_PROJECT_ROOT_WIN = r"C:\Users\marco\Documents\Fortnite Projects"


def _get_log_path() -> str:
    """Resolve the UEFN log path, supporting env override and WSL/Windows detection."""
    env_path = os.environ.get("UEFN_LOG_PATH")
    if env_path:
        return env_path
    # Detect WSL vs native Windows
    if os.path.exists("/mnt/c"):
        return DEFAULT_LOG_PATH_WSL
    return DEFAULT_LOG_PATH_WIN


def _get_project_root() -> str:
    """Resolve the Fortnite project root for relative path computation."""
    env_root = os.environ.get("VERSE_PROJECT_ROOT")
    if env_root:
        return env_root
    if os.path.exists("/mnt/c"):
        return DEFAULT_PROJECT_ROOT_WSL
    return DEFAULT_PROJECT_ROOT_WIN


# ─────────────────────────────────────────────
# Error format regex
# ─────────────────────────────────────────────
# Matches:
#   VerseBuild: Error: C:/path/file.verse(25,17, 25,31): Script error 3506: Unknown identifier `foo`.
#   VerseBuild: Error: C:/path/file.verse(25,17, 25,31) : Script error 3506: Unknown identifier `foo`.
#   VerseBuild: Warning: ...same format...

VERSE_DIAG_PATTERN = re.compile(
    r"VerseBuild:\s*(?P<severity>Error|Warning):\s*"
    r"(?P<filepath>[^(]+\.verse(?:test)?)"
    r"\((?P<start_line>\d+),(?P<start_col>\d+)"
    r"(?:,\s*(?P<end_line>\d+),(?P<end_col>\d+))?\)"
    r"\s*:\s*Script (?:error|warning)\s+(?P<code>\d+):\s*"
    r"(?P<message>.+?)\.?\s*$"
)

# Broader fallback for non-standard formats
VERSE_DIAG_FALLBACK = re.compile(
    r"VerseBuild:\s*(?P<severity>Error|Warning):\s*(?P<message>.+)"
)

# Timestamp pattern at start of UEFN log lines
LOG_TIMESTAMP = re.compile(r"^\[(\d{4}\.\d{2}\.\d{2}-\d{2}\.\d{2}\.\d{2}:\d{3})\]")


def _parse_log_timestamp(line: str) -> Optional[str]:
    """Extract ISO timestamp from UEFN log line."""
    m = LOG_TIMESTAMP.match(line)
    if not m:
        return None
    raw = m.group(1)  # e.g. 2026.03.07-11.46.52:160
    try:
        dt = datetime.strptime(raw.split(":")[0], "%Y.%m.%d-%H.%M.%S")
        return dt.replace(tzinfo=timezone.utc).isoformat()
    except ValueError:
        return None


def _make_relative(filepath: str, project_root: str) -> str:
    """Convert absolute path to project-relative, normalizing slashes."""
    normalized = filepath.replace("\\", "/").strip()
    root = project_root.replace("\\", "/").strip().rstrip("/")
    if normalized.lower().startswith(root.lower()):
        return normalized[len(root):].lstrip("/")
    return normalized


def _parse_diagnostics_from_lines(
    lines: list[str], project_root: str
) -> list[dict]:
    """Parse Verse diagnostics from log lines."""
    diagnostics = []
    seen = set()  # dedupe by (file, line, col, code, message)

    for line in lines:
        m = VERSE_DIAG_PATTERN.search(line)
        if m:
            filepath = _make_relative(m.group("filepath"), project_root)
            start_line = int(m.group("start_line"))
            start_col = int(m.group("start_col"))
            end_line = int(m.group("end_line")) if m.group("end_line") else start_line
            end_col = int(m.group("end_col")) if m.group("end_col") else start_col
            code = m.group("code")
            message = m.group("message").strip().rstrip(".")
            severity = m.group("severity").lower()

            dedup_key = (filepath, start_line, start_col, code, message)
            if dedup_key in seen:
                continue
            seen.add(dedup_key)

            timestamp = _parse_log_timestamp(line)

            diagnostics.append({
                "file": filepath,
                "line": start_line,
                "column": start_col,
                "endLine": end_line,
                "endColumn": end_col,
                "severity": severity,
                "code": f"VRS{code}",
                "message": message,
                "timestamp": timestamp,
                "raw": line.strip()[:500],
            })

    return diagnostics


def _read_log_tail(log_path: str, max_lines: int = 10000) -> list[str]:
    """Read the last N lines of the UEFN log efficiently."""
    try:
        with open(log_path, "r", encoding="utf-8", errors="replace") as f:
            # Seek to end, read backwards
            f.seek(0, 2)
            file_size = f.tell()
            # Read last ~2MB or whole file
            read_size = min(file_size, 2 * 1024 * 1024)
            f.seek(max(0, file_size - read_size))
            content = f.read()
            lines = content.splitlines()
            return lines[-max_lines:]
    except FileNotFoundError:
        return []
    except Exception:
        return []


# ─────────────────────────────────────────────
# MCP Server
# ─────────────────────────────────────────────

mcp = FastMCP("verse_diagnostics_mcp")


class GetDiagnosticsInput(BaseModel):
    """Input for get_verse_diagnostics tool."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    file_filter: Optional[str] = Field(
        default=None,
        description="Optional filename or path substring to filter diagnostics (e.g., 'hello_world_device.verse')",
    )
    severity_filter: Optional[str] = Field(
        default=None,
        description="Filter by severity: 'error', 'warning', or None for all",
    )
    max_results: Optional[int] = Field(
        default=50,
        description="Maximum number of diagnostics to return",
        ge=1,
        le=200,
    )
    tail_lines: Optional[int] = Field(
        default=10000,
        description="Number of log lines to read from the end of the UEFN log",
        ge=100,
        le=100000,
    )


@mcp.tool(
    name="get_verse_diagnostics",
    annotations={
        "title": "Get Verse Build Diagnostics",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def get_verse_diagnostics(params: GetDiagnosticsInput) -> str:
    """Get the latest Verse compile diagnostics from UEFN logs.

    Parses the UnrealEditorFortnite.log file for VerseBuild errors and warnings,
    deduplicates them, and returns structured JSON with file paths, line/column
    locations, error codes, and messages.

    Returns:
        str: JSON object with fields:
            - ok (bool): True if no errors found
            - source (str): Always "uefn-log"
            - error_count (int): Number of errors
            - warning_count (int): Number of warnings
            - diagnostics (list): Array of diagnostic objects with:
                - file, line, column, endLine, endColumn, severity, code, message, timestamp, raw
            - log_path (str): Path to the log file read
            - log_exists (bool): Whether the log file was found
    """
    log_path = _get_log_path()
    project_root = _get_project_root()
    log_exists = os.path.exists(log_path)

    if not log_exists:
        return json.dumps({
            "ok": False,
            "source": "uefn-log",
            "error_count": 0,
            "warning_count": 0,
            "diagnostics": [],
            "log_path": log_path,
            "log_exists": False,
            "message": f"UEFN log not found at {log_path}. Is UEFN running? Set UEFN_LOG_PATH env var to override.",
        }, indent=2)

    lines = _read_log_tail(log_path, max_lines=params.tail_lines or 10000)
    diagnostics = _parse_diagnostics_from_lines(lines, project_root)

    # Apply filters
    if params.file_filter:
        filt = params.file_filter.lower()
        diagnostics = [d for d in diagnostics if filt in d["file"].lower()]

    if params.severity_filter:
        sev = params.severity_filter.lower()
        diagnostics = [d for d in diagnostics if d["severity"] == sev]

    # Limit results
    max_r = params.max_results or 50
    diagnostics = diagnostics[:max_r]

    error_count = sum(1 for d in diagnostics if d["severity"] == "error")
    warning_count = sum(1 for d in diagnostics if d["severity"] == "warning")

    # Get log modification time
    try:
        mtime = os.path.getmtime(log_path)
        log_modified = datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat()
    except Exception:
        log_modified = None

    return json.dumps({
        "ok": error_count == 0,
        "source": "uefn-log",
        "error_count": error_count,
        "warning_count": warning_count,
        "diagnostics": diagnostics,
        "log_path": log_path,
        "log_exists": True,
        "log_modified": log_modified,
        "total_lines_scanned": len(lines),
    }, indent=2)


class GetBuildSessionInput(BaseModel):
    """Input for get_latest_build_session tool."""
    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    tail_lines: Optional[int] = Field(
        default=5000,
        description="Number of log lines to scan from the end",
        ge=100,
        le=50000,
    )


@mcp.tool(
    name="get_latest_build_session",
    annotations={
        "title": "Get Latest Verse Build Session",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def get_latest_build_session(params: GetBuildSessionInput) -> str:
    """Get all VerseBuild log lines from the most recent build session.

    Returns the raw VerseBuild output lines (both errors and info) from the
    latest compile session, useful for understanding the full build context.

    Returns:
        str: JSON with fields:
            - lines (list[str]): Raw VerseBuild log lines
            - count (int): Number of lines found
            - log_exists (bool): Whether the log file was found
    """
    log_path = _get_log_path()

    if not os.path.exists(log_path):
        return json.dumps({
            "lines": [],
            "count": 0,
            "log_exists": False,
            "message": f"Log not found at {log_path}",
        }, indent=2)

    all_lines = _read_log_tail(log_path, max_lines=params.tail_lines or 5000)

    # Extract all VerseBuild lines
    build_lines = [
        line.strip() for line in all_lines
        if "VerseBuild:" in line
    ]

    # Find the last build session boundary (look for build start markers)
    # Typically a new build starts after some gap or a specific log marker
    # For now, return all VerseBuild lines from the tail
    return json.dumps({
        "lines": build_lines[-100:],  # Last 100 build lines
        "count": len(build_lines),
        "log_exists": True,
    }, indent=2)


class WatchInput(BaseModel):
    """Input for check_verse_log_freshness tool."""
    model_config = ConfigDict(extra="forbid")


@mcp.tool(
    name="check_verse_log_freshness",
    annotations={
        "title": "Check UEFN Log Freshness",
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def check_verse_log_freshness(params: WatchInput) -> str:
    """Check when the UEFN log was last modified.

    Useful for determining if a build has completed since the last check.

    Returns:
        str: JSON with log_path, exists, modified_at, age_seconds
    """
    log_path = _get_log_path()

    if not os.path.exists(log_path):
        return json.dumps({
            "log_path": log_path,
            "exists": False,
        }, indent=2)

    mtime = os.path.getmtime(log_path)
    age = time.time() - mtime

    return json.dumps({
        "log_path": log_path,
        "exists": True,
        "modified_at": datetime.fromtimestamp(mtime, tz=timezone.utc).isoformat(),
        "age_seconds": round(age, 1),
        "is_fresh": age < 30,  # Modified in last 30 seconds
    }, indent=2)



