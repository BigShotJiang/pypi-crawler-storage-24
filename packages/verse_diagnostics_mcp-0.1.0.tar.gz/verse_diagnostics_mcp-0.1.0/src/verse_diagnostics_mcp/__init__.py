"""verse-diagnostics-mcp: MCP server for UEFN Verse build diagnostics."""

from .server import mcp


def main():
    """Entry point for the verse-diagnostics-mcp console script."""
    mcp.run()
