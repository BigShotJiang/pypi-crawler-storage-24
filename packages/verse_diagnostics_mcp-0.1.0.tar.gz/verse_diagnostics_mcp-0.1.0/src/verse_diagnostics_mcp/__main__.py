"""Allow running as python -m verse_diagnostics_mcp."""

from . import main

main()
