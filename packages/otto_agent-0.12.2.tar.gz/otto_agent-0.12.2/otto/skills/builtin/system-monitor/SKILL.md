---
name: system-monitor
description: A heartbeat skill that checks for system events or anomalies and triggers notifications.
heartbeat:
  entrypoint: monitor.py
  timeout_seconds: 15
---

# System Monitor

This skill runs autonomously as a heartbeat check. It checks the system for interesting events (like disk space running low, or a new file dropping in a watch directory) and dispatches alerts or tasks back to the agent if something needs attention.
