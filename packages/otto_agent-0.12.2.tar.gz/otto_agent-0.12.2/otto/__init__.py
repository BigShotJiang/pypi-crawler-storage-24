"""Otto — AI agent platform."""

__version__ = "0.12.1"
