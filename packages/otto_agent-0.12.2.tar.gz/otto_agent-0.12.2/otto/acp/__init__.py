"""ACP (Agent Client Protocol) integration for Otto.

Provides transport and client layers for spawning and communicating with
ACP agent subprocesses over bidirectional JSON-RPC 2.0 stdio.
"""

from __future__ import annotations

from typing import Any

from otto.acp.registry import (
    ACPAgentDef,
    get_acp_model_suffix,
    get_all_agents,
    is_acp_model,
    resolve_acp_agent,
)
from otto.acp.transport import ACPTransport
from otto.errors import OttoError

__all__ = [
    "ACPAgentDef",
    "ACPTransport",
    "ACPAgentNotFoundError",
    "ACPAgentCrashedError",
    "ACPAuthRequiredError",
    "ACPTransportError",
    "OttoMCPBridge",
    "get_acp_model_suffix",
    "get_all_agents",
    "is_acp_model",
    "resolve_acp_agent",
]


class ACPTransportError(OttoError):
    """Base exception for ACP transport failures."""


class ACPAgentNotFoundError(ACPTransportError):
    """Raised when the ACP agent binary cannot be found."""


class ACPAgentCrashedError(ACPTransportError):
    """Raised when the ACP agent process exits unexpectedly."""


class ACPAuthRequiredError(ACPTransportError):
    """Raised when the ACP agent requires authentication the client cannot provide.

    Attributes:
        auth_methods: The list of auth methods returned by the agent.
    """

    def __init__(self, message: str, auth_methods: list[Any] | None = None):
        super().__init__(message)
        self.auth_methods = auth_methods or []
