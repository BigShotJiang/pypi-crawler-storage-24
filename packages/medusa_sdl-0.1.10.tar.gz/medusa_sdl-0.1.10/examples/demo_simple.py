import logging
from pathlib import Path
from medusa import Medusa, MedusaDesigner
import time

logger = logging.getLogger("test")
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler())

# designer = MedusaDesigner()
# designer.new_design()
# exit()
# input()

base_path = Path(r"C:\Users\han\Downloads")
layout = input("New design name\n") + ".json"
medusa = Medusa(
    graph_layout=base_path/layout,
    logger=logger     
)

medusa.transfer_volumetric(source="water", target="Waste Vessel", pump_id="Pump1", volume= 1, transfer_type="liquid")
