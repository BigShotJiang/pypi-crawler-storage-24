from .normalization import normalize
from .tokenization import sentence_tokenize, word_tokenize
from .stopwords import remove_stopwords
from .utils import detect_script
from .roman import roman_to_shahmukhi
from collections import Counter


class PunjabiPipeline:
    def __init__(self, remove_stops=True):
        self.remove_stops = remove_stops

    def process(self, text, pretty=False):
        result = {}

        # Normalize text
        norm_text = normalize(text)

        # Roman → Shahmukhi conversion
        norm_text = roman_to_shahmukhi(norm_text)

        # Detect script AFTER processing
        script = detect_script(norm_text)

        result["script"] = script
        result["normalized_text"] = norm_text

        # Sentence tokenization
        sentences = sentence_tokenize(norm_text)
        result["sentences"] = sentences

        # Word tokenization
        tokens = word_tokenize(norm_text)

        # Remove stopwords
        if self.remove_stops:
            tokens = remove_stopwords(tokens)

        result["tokens"] = tokens
        result["token_count"] = len(tokens)

        # Frequency analysis
        result["frequency"] = dict(Counter(tokens))

        # Pretty output option
        if pretty:
            return self._format_output(result)

        return result

    # =========================
    # Pretty formatter 🔥
    # =========================
    def _format_output(self, result):
        return (
            f"Script: {result['script']}\n"
            f"Normalized: {result['normalized_text']}\n"
            f"Sentences: {', '.join(result['sentences'])}\n"
            f"Tokens: {'، '.join(result['tokens'])}\n"
            f"Token Count: {result['token_count']}"
        )

    # =========================
    # User-friendly print 🔥
    # =========================
    def pretty_print(self, text):
        print(self.process(text, pretty=True))