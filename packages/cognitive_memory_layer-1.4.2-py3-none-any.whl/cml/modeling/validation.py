"""Preflight and artifact validation for modeling train workflows."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import pandas as pd

from cml.modeling.token_training import load_token_task_split

_KNOWN_OBJECTIVES = {
    "classification",
    "pair_ranking",
    "single_regression",
    "token_classification",
}
_KNOWN_TRAINERS = {
    "classification",
    "pair_ranking",
    "single_regression",
    "token_classification",
    "embedding_pair",
    "transformer_text",
    "transformer_pair",
    "ordinal_threshold",
    "hierarchical_text",
    "hierarchical_transformer",
}
_KNOWN_FEATURE_BACKENDS = {"tfidf", "embedding_pair"}
_FAMILIES = {"router", "extractor", "pair"}


@dataclass(slots=True)
class TaskPreflightStatus:
    task_name: str
    family: str
    input_type: str
    objective: str
    enabled: bool
    status: str
    reason: str | None = None
    rows_found: int = 0
    valid_score_rows: int = 0


@dataclass(slots=True)
class PreflightValidationResult:
    ok: bool
    strict: bool
    errors: list[str]
    warnings: list[str]
    task_checks: list[TaskPreflightStatus]
    observed_tasks_by_family: dict[str, list[str]]
    coverage_vs_config: dict[str, dict[str, list[str]]]

    def as_dict(self) -> dict[str, Any]:
        return {
            "ok": self.ok,
            "strict": self.strict,
            "errors": self.errors,
            "warnings": self.warnings,
            "task_checks": [asdict(t) for t in self.task_checks],
            "observed_tasks_by_family": self.observed_tasks_by_family,
            "coverage_vs_config": self.coverage_vs_config,
        }


def _required_columns(*, input_type: str, objective: str) -> list[str]:
    if objective == "token_classification":
        return ["task", "text", "spans", "source", "language"]
    cols = ["task", "text_a", "text_b"] if input_type == "pair" else ["task", "text"]
    if objective == "single_regression":
        cols.append("score")
    else:
        cols.append("label")
    return cols


def _resolved_trainer(raw: dict[str, Any]) -> str:
    trainer = str(raw.get("trainer", "") or "").strip()
    if trainer:
        return trainer
    return str(raw.get("objective", "") or "").strip()


def _resolved_feature_backend(raw: dict[str, Any]) -> str:
    backend = str(raw.get("feature_backend", "") or "").strip()
    if backend:
        return backend
    if _resolved_trainer(raw) == "embedding_pair":
        return "embedding_pair"
    return "tfidf"


def _load_family_train_df(
    prepared_dir: Path, family: str
) -> tuple[pd.DataFrame | None, str | None]:
    path = prepared_dir / f"{family}_train.parquet"
    if not path.exists():
        return None, f"Missing prepared split: {path}"
    try:
        return pd.read_parquet(path), None
    except Exception as exc:  # pragma: no cover - depends on parquet engine/data files
        return None, f"Failed to read {path}: {exc}"


def run_preflight_validation(
    *,
    task_specs_raw: list[dict[str, Any]],
    prepared_dir: Path,
    strict: bool,
) -> PreflightValidationResult:
    errors: list[str] = []
    warnings: list[str] = []
    task_checks: list[TaskPreflightStatus] = []

    family_frames: dict[str, pd.DataFrame | None] = {}
    for family in _FAMILIES:
        df, err = _load_family_train_df(prepared_dir, family)
        family_frames[family] = df
        if err:
            errors.append(err)

    observed_by_family: dict[str, list[str]] = {}
    for family, df in family_frames.items():
        if df is None or "task" not in df.columns:
            observed_by_family[family] = []
            continue
        observed_by_family[family] = sorted(df["task"].dropna().astype(str).unique().tolist())

    enabled_tasks_by_family: dict[str, set[str]] = {f: set() for f in _FAMILIES}

    for raw in task_specs_raw:
        task_name = str(raw.get("task_name", "")).strip()
        family = str(raw.get("family", "")).strip()
        input_type = str(raw.get("input_type", "")).strip()
        objective = str(raw.get("objective", "")).strip()
        enabled = bool(raw.get("enabled", True))
        trainer = _resolved_trainer(raw)
        feature_backend = _resolved_feature_backend(raw)
        label_order = [str(x) for x in raw.get("label_order", []) if str(x).strip()]

        if (
            family in enabled_tasks_by_family
            and enabled
            and task_name
            and objective != "token_classification"
        ):
            enabled_tasks_by_family[family].add(task_name)

        if not task_name:
            errors.append(f"Configured task is missing task_name: {raw}")
            continue

        status = TaskPreflightStatus(
            task_name=task_name,
            family=family,
            input_type=input_type,
            objective=objective,
            enabled=enabled,
            status="ok",
        )

        if not enabled:
            status.status = "disabled"
            status.reason = "Task disabled in config"
            task_checks.append(status)
            continue

        if family not in _FAMILIES:
            status.status = "error"
            status.reason = f"Unknown family '{family}'"
            errors.append(f"[task:{task_name}] unknown family '{family}'")
            task_checks.append(status)
            continue

        if objective not in _KNOWN_OBJECTIVES:
            status.status = "error"
            status.reason = f"Unknown objective '{objective}'"
            errors.append(f"[task:{task_name}] unknown objective '{objective}'")
            task_checks.append(status)
            continue

        if trainer not in _KNOWN_TRAINERS:
            status.status = "error"
            status.reason = f"Unknown trainer '{trainer}'"
            errors.append(f"[task:{task_name}] unknown trainer '{trainer}'")
            task_checks.append(status)
            continue

        if feature_backend not in _KNOWN_FEATURE_BACKENDS:
            status.status = "error"
            status.reason = f"Unknown feature_backend '{feature_backend}'"
            errors.append(f"[task:{task_name}] unknown feature_backend '{feature_backend}'")
            task_checks.append(status)
            continue

        if input_type not in {"single", "pair"}:
            status.status = "error"
            status.reason = f"Invalid input_type '{input_type}'"
            errors.append(f"[task:{task_name}] invalid input_type '{input_type}'")
            task_checks.append(status)
            continue

        if trainer == "embedding_pair":
            cache_path = prepared_dir / "pair_text_embeddings.parquet"
            if input_type != "pair" or feature_backend != "embedding_pair":
                status.status = "error"
                status.reason = (
                    "embedding_pair trainer requires pair input_type and embedding_pair backend"
                )
                errors.append(
                    f"[task:{task_name}] embedding_pair trainer requires pair input_type and embedding_pair backend"
                )
                task_checks.append(status)
                continue
            if objective not in ("pair_ranking", "classification"):
                status.status = "error"
                status.reason = (
                    "embedding_pair trainer requires pair_ranking or classification objective"
                )
                errors.append(
                    f"[task:{task_name}] embedding_pair trainer requires objective pair_ranking or classification"
                )
                task_checks.append(status)
                continue
            if not cache_path.exists():
                status.status = "error"
                status.reason = f"Missing embedding cache: {cache_path.name}"
                errors.append(f"[task:{task_name}] missing embedding cache: {cache_path}")
                task_checks.append(status)
                continue

        if trainer == "transformer_pair":
            if input_type != "pair" or objective not in {"classification", "pair_ranking"}:
                status.status = "error"
                status.reason = "transformer_pair requires pair classification or pair_ranking"
                errors.append(
                    f"[task:{task_name}] transformer_pair requires pair input_type and classification/pair_ranking objective"
                )
                task_checks.append(status)
                continue

        if trainer == "transformer_text" and (
            objective != "classification" or input_type != "single"
        ):
            status.status = "error"
            status.reason = "transformer_text requires single-input classification"
            errors.append(
                f"[task:{task_name}] transformer_text requires objective=classification and input_type=single"
            )
            task_checks.append(status)
            continue

        if trainer == "ordinal_threshold":
            labels = [str(x) for x in raw.get("labels", []) if str(x).strip()]
            if objective != "classification" or input_type != "single":
                status.status = "error"
                status.reason = "ordinal_threshold requires single-input classification"
                errors.append(
                    f"[task:{task_name}] ordinal_threshold requires objective=classification and input_type=single"
                )
                task_checks.append(status)
                continue
            if not label_order or sorted(label_order) != sorted(labels):
                status.status = "error"
                status.reason = "label_order must contain the same labels as labels"
                errors.append(
                    f"[task:{task_name}] ordinal_threshold requires label_order matching labels"
                )
                task_checks.append(status)
                continue

        if trainer == "hierarchical_text" and (
            objective != "classification" or input_type != "single"
        ):
            status.status = "error"
            status.reason = "hierarchical_text requires single-input classification"
            errors.append(
                f"[task:{task_name}] hierarchical_text requires objective=classification and input_type=single"
            )
            task_checks.append(status)
            continue

        if trainer == "hierarchical_transformer" and (
            objective != "classification" or input_type != "single"
        ):
            status.status = "error"
            status.reason = "hierarchical_transformer requires single-input classification"
            errors.append(
                f"[task:{task_name}] hierarchical_transformer requires objective=classification and input_type=single"
            )
            task_checks.append(status)
            continue

        if objective == "token_classification":
            try:
                token_df = load_token_task_split(prepared_dir, task_name, "train")
            except Exception as exc:
                status.status = "error"
                status.reason = str(exc)
                errors.append(f"[task:{task_name}] {exc}")
                task_checks.append(status)
                continue

            required = _required_columns(input_type=input_type, objective=objective)
            missing_cols = [col for col in required if col not in token_df.columns]
            if missing_cols:
                status.status = "error"
                status.reason = (
                    f"Missing required columns in {task_name}_train.parquet: {missing_cols}"
                )
                errors.append(
                    f"[task:{task_name}] missing columns in {task_name}_train.parquet: {missing_cols}"
                )
                task_checks.append(status)
                continue

            subset = token_df[token_df["task"].astype(str) == task_name]
            status.rows_found = len(subset)
            if subset.empty:
                status.status = "error"
                status.reason = "No rows found for configured token task in prepared train split"
                errors.append(
                    f"[task:{task_name}] no prepared rows found in {task_name}_train.parquet"
                )
                task_checks.append(status)
                continue

            task_checks.append(status)
            continue

        df = family_frames.get(family)
        if df is None:
            status.status = "error"
            status.reason = f"Missing training split for family '{family}'"
            errors.append(f"[task:{task_name}] missing family split for '{family}'")
            task_checks.append(status)
            continue

        required = _required_columns(input_type=input_type, objective=objective)
        missing_cols = [col for col in required if col not in df.columns]
        if missing_cols:
            status.status = "error"
            status.reason = f"Missing required columns in {family}_train.parquet: {missing_cols}"
            errors.append(
                f"[task:{task_name}] missing columns in {family}_train.parquet: {missing_cols}"
            )
            task_checks.append(status)
            continue

        subset = df[df["task"].astype(str) == task_name]
        status.rows_found = len(subset)
        if subset.empty:
            status.status = "error"
            status.reason = "No rows found for configured task in prepared train split"
            errors.append(f"[task:{task_name}] no prepared rows found in {family}_train.parquet")
            task_checks.append(status)
            continue

        if objective == "single_regression":
            numeric = pd.to_numeric(subset["score"], errors="coerce")
            valid_rows = int(numeric.notna().sum())
            status.valid_score_rows = valid_rows
            if valid_rows == 0:
                status.status = "error"
                status.reason = "single_regression requires numeric score rows"
                errors.append(
                    f"[task:{task_name}] single_regression requires numeric score values in score column"
                )
                task_checks.append(status)
                continue

        task_checks.append(status)

    coverage: dict[str, dict[str, list[str]]] = {}
    for family in sorted(_FAMILIES):
        configured = sorted(enabled_tasks_by_family[family])
        observed = observed_by_family.get(family, [])
        missing = sorted(set(configured) - set(observed))
        coverage[family] = {
            "configured_enabled_tasks": configured,
            "observed_tasks": observed,
            "missing_configured_tasks": missing,
        }
        if missing:
            errors.append(
                f"[family:{family}] configured tasks missing from prepared data: {missing}"
            )

    if strict and errors:
        warnings.append("Strict mode enabled: preflight errors will fail training.")

    return PreflightValidationResult(
        ok=(len(errors) == 0),
        strict=strict,
        errors=errors,
        warnings=warnings,
        task_checks=task_checks,
        observed_tasks_by_family=observed_by_family,
        coverage_vs_config=coverage,
    )


def validate_manifest_artifacts(
    *,
    families_summary: dict[str, dict[str, Any]],
    task_summaries: dict[str, dict[str, Any]],
) -> list[str]:
    errors: list[str] = []

    for family, summary in families_summary.items():
        model_path = Path(str(summary.get("model_path", ""))).expanduser()
        if not model_path.exists():
            errors.append(f"[family:{family}] missing model artifact: {model_path}")

    for task_name, summary in task_summaries.items():
        model_path = Path(str(summary.get("model_path", ""))).expanduser()
        if not model_path.exists():
            errors.append(f"[task:{task_name}] missing model artifact: {model_path}")
        hf_model_dir = str(summary.get("hf_model_dir", "") or "").strip()
        if hf_model_dir:
            hf_path = Path(hf_model_dir).expanduser()
            if not hf_path.exists():
                errors.append(f"[task:{task_name}] missing HF model directory: {hf_path}")

    return errors
