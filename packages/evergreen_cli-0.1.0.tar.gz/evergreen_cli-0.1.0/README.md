# evergreen-cli

Agent-friendly CLI for the [Evergreen](https://evergreen.live) requirements platform.

## Install

```bash
pip install evergreen-cli
```

## Login

Evergreen is currently in alpha. Point the CLI at the alpha API when logging in:

```bash
evergreen login --url https://api.alpha.evergreen.live/api
```

This will prompt for your API key interactively (keeps it out of shell history). You can also pass the key directly for CI/scripting:

```bash
evergreen login --url https://api.alpha.evergreen.live/api --key evg_your_api_key
```

You can also set the URL via environment variable:

```bash
export EVERGREEN_API_URL=https://api.alpha.evergreen.live/api
```

## Usage

```bash
# List products
evergreen products

# Show requirement tree
evergreen <product_id> tree

# View backlog
evergreen <product_id> backlog

# View a requirement with comments
evergreen <product_id> requirement <id>

# Post a comment
evergreen <product_id> comment <requirement_id> "your message"

# List revisions (optionally filter by state)
evergreen <product_id> revisions
evergreen <product_id> revisions --state drafting

# View a revision with its changes
evergreen <product_id> revision <id>

# Create a new draft revision
evergreen <product_id> revision draft --title "My revision"

# Add a change to a draft revision
evergreen <product_id> revision <id> add-change --type create --title "New req"

# Discard a draft revision
evergreen <product_id> revision <id> discard
```

Run `evergreen --help` for the full command list.
