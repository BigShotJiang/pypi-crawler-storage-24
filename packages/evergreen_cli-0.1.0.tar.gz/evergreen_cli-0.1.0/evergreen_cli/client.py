"""Sync HTTP client for the Evergreen CLI."""

import os

import httpx

from evergreen_cli.config import load_config


class EvergreenClient:
    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
    ):
        config = load_config()
        self.base_url = (
            base_url
            or os.environ.get("EVERGREEN_API_URL")
            or config.get("api_url")
            or "http://localhost:8002/api"
        )
        self.api_key = (
            api_key
            or os.environ.get("EVERGREEN_API_KEY")
            or config.get("api_key")
            or ""
        )
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=30,
        )

    def _request(self, method: str, path: str, **kwargs) -> dict | list:
        resp = self._client.request(method, path, **kwargs)
        resp.raise_for_status()
        if resp.status_code == 204:
            return {}
        return resp.json()

    # --- Products ---

    def list_products(self) -> list:
        return self._request("GET", "/products")

    # --- Tree & Requirements (read-only) ---

    def get_tree(
        self, product_id: str, requirement_id: str | None = None
    ) -> list:
        if requirement_id:
            return self._request(
                "GET",
                f"/products/{product_id}/tree/{requirement_id}",
            )
        return self._request(
            "GET", f"/products/{product_id}/tree"
        )

    def get_backlog(self, product_id: str) -> list:
        return self._request("GET", f"/products/{product_id}/backlog")

    def get_requirement(
        self, product_id: str, requirement_id: str
    ) -> dict:
        return self._request(
            "GET",
            f"/products/{product_id}/requirements/{requirement_id}",
        )

    # --- Comments ---

    def get_comments(
        self, product_id: str, requirement_id: str
    ) -> list:
        return self._request(
            "GET",
            f"/products/{product_id}/requirements"
            f"/{requirement_id}/comments",
        )

    def create_comment(
        self, product_id: str, requirement_id: str, content: str
    ) -> dict:
        return self._request(
            "POST",
            f"/products/{product_id}/requirements"
            f"/{requirement_id}/comments",
            json={"content": content},
        )

    # --- Revisions ---

    def list_revisions(
        self, product_id: str, state: str | None = None
    ) -> list:
        params = {}
        if state:
            params["state"] = state
        return self._request(
            "GET",
            f"/products/{product_id}/revisions",
            params=params,
        )

    def get_revision(
        self, product_id: str, revision_id: str
    ) -> dict:
        return self._request(
            "GET",
            f"/products/{product_id}/revisions/{revision_id}",
        )

    def draft_revision(
        self, product_id: str, title: str | None = None
    ) -> dict:
        body: dict = {}
        if title:
            body["title"] = title
        return self._request(
            "POST",
            f"/products/{product_id}/revisions",
            json=body,
        )

    def add_change(
        self,
        product_id: str,
        revision_id: str,
        change_type: str,
        requirement_id: str | None = None,
        title: str | None = None,
        description: str | None = None,
        new_state: str | None = None,
        new_parent_id: str | None = None,
    ) -> dict:
        body: dict = {"type": change_type}
        if requirement_id:
            body["requirement_id"] = requirement_id
        if title:
            body["title"] = title
        if description:
            body["description"] = description
        if new_state:
            body["new_state"] = new_state
        if new_parent_id:
            body["new_parent_id"] = new_parent_id
        return self._request(
            "POST",
            f"/products/{product_id}/revisions/{revision_id}/changes",
            json=body,
        )

    def discard_revision(
        self,
        product_id: str,
        revision_id: str,
        reason: str | None = None,
    ) -> dict:
        body: dict = {}
        if reason:
            body["reason"] = reason
        return self._request(
            "POST",
            f"/products/{product_id}/revisions/{revision_id}/discard",
            json=body,
        )
