"""Persistent CLI configuration (API URL + key)."""

import json
import os
import sys
from pathlib import Path


def _default_config_dir() -> Path:
    if sys.platform == "win32":
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "evergreen"


def load_config(config_dir: Path | None = None) -> dict:
    path = (config_dir or _default_config_dir()) / "config.json"
    if not path.exists():
        return {}
    return json.loads(path.read_text())


def save_config(data: dict, config_dir: Path | None = None) -> Path:
    directory = config_dir or _default_config_dir()
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / "config.json"
    path.write_text(json.dumps(data, indent=2) + "\n")
    return path
