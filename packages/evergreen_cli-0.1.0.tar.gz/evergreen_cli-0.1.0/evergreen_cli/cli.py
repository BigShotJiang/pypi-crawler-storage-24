"""Evergreen CLI — agent-friendly interface to the Evergreen API."""

import argparse
import getpass
import sys

from evergreen_cli.client import EvergreenClient
from evergreen_cli.config import save_config

USAGE = """\
usage: evergreen <command> [args]

Global commands:
  login                          Save API credentials for repeat use
  products                       List products

Product-scoped commands (evergreen <product_id> <command>):
  tree [requirement_id] [--depth N]   Show requirement tree
  backlog                             Unsatisfied requirements
  requirement <id>                    View details + comments
  comment <requirement_id> <message>  Post a comment
  revisions [--state drafting]        List revisions
  revision <id>                       View revision with changes
  revision draft [--title "..."]      Create a new draft revision
  revision <id> add-change            Add a change to a draft revision
  revision <id> discard               Discard a draft revision
"""


def format_products(products: list) -> str:
    if not products:
        return "No products found."
    lines = ["PRODUCTS", "=" * 40]
    for p in products:
        lines.append(f"  {p['id']}  {p['name']}")
    return "\n".join(lines)


def format_tree(tree: list, max_depth: int | None = None) -> str:
    if not tree:
        return "No requirements found."
    lines = ["REQUIREMENT TREE", "=" * 60]

    def render_node(node: dict, depth: int):
        if max_depth is not None and depth > max_depth:
            return
        indent = "    " * depth
        state_label = f"[{node['state']}]"
        lines.append(
            f"  {indent}- {node['title']}  {state_label}"
        )
        lines.append(f"  {indent}  id: {node['id']}")
        for child in node.get("children", []):
            render_node(child, depth + 1)

    for root_node in tree:
        render_node(root_node, 0)

    return "\n".join(lines)


def format_backlog_flat(items: list) -> str:
    if not items:
        return "Backlog is empty — all requirements satisfied."
    lines = ["BACKLOG (unsatisfied)", "=" * 60]
    for rank, item in enumerate(items, 1):
        lines.append(f"  {rank}. {item['title']}")
        lines.append(f"     id: {item['id']}")
    return "\n".join(lines)


def format_requirement(requirement: dict, comments: list | None = None) -> str:
    title = requirement["title"]
    lines = [
        f"REQUIREMENT: {title}",
        "=" * 60,
        f"  ID:          {requirement['id']}",
        f"  State:       {requirement['state']}",
        f"  Children:    {requirement.get('children_count', 0)}",
        f"  Description: {requirement.get('description') or '(none)'}",
    ]
    if comments:
        lines.append("")
        lines.append(f"DISCUSSION ({len(comments)} comments)")
        lines.append("-" * 40)
        for c in comments:
            source_tag = f"[{c.get('author_source', 'human')}]"
            lines.append(
                f"  {c.get('author_name', 'unknown')} {source_tag}:"
                f" {c.get('content', '')}"
            )
    return "\n".join(lines)


def format_comment(comment: dict) -> str:
    name = comment.get("author_name", "unknown")
    content = comment.get("content", "")
    return f"Comment posted by {name}: {content}"


def format_revisions(revisions: list) -> str:
    if not revisions:
        return "No revisions found."
    lines = ["REVISIONS", "=" * 60]
    for r in revisions:
        state_label = f"[{r['state']}]"
        changes = r.get("change_count", 0)
        lines.append(
            f"  {r['title']}  {state_label}  ({changes} changes)"
        )
        lines.append(
            f"    id: {r['id']}  created: {r.get('created_at', '')}"
        )
    return "\n".join(lines)


def format_revision(revision: dict) -> str:
    lines = [
        f"REVISION: {revision['title']}",
        "=" * 60,
        f"  ID:      {revision['id']}",
        f"  State:   {revision['state']}",
    ]
    if revision.get("has_conflicts"):
        lines.append("  *** HAS CONFLICTS ***")
    changes = revision.get("changes", [])
    if changes:
        lines.append("")
        lines.append(f"CHANGES ({len(changes)})")
        lines.append("-" * 40)
        for c in changes:
            conflict_mark = " [CONFLICT]" if c.get("conflict") else ""
            label = c.get("requirement_title", c.get("title", ""))
            lines.append(f"  [{c['type']}] {label}{conflict_mark}")
            lines.append(f"    change_id: {c['change_id']}")
            if c.get("conflict"):
                lines.append(f"    conflict: {c['conflict']}")
    return "\n".join(lines)


def main(argv: list[str] | None = None):
    args = argv if argv is not None else sys.argv[1:]

    if not args or args[0] in ("--help", "-h"):
        print(USAGE)
        return

    # --- Global commands (no product scope) ---

    if args[0] == "login":
        parser = argparse.ArgumentParser(prog="evergreen login")
        parser.add_argument(
            "--url",
            default="https://api.evergreen.live/api",
            help="Evergreen API URL (default: production)",
        )
        parser.add_argument("--key", default=None, help="API key (evg_...)")
        parsed = parser.parse_args(args[1:])
        key = parsed.key or getpass.getpass("API key: ")
        if not key:
            print("Error: API key is required.", file=sys.stderr)
            sys.exit(1)
        save_config({"api_url": parsed.url, "api_key": key})
        print("Credentials saved.")
        print(f"  URL: {parsed.url}")
        print(f"  Key: {key}")
        return

    if args[0] == "products":
        client = EvergreenClient()
        try:
            products = client.list_products()
            print(format_products(products))
        except Exception as e:
            print(f"Error: {e}", file=sys.stderr)
            sys.exit(1)
        return

    # --- Product-scoped commands: <product_id> <command> [args...] ---

    if len(args) < 2 or args[1] in ("--help", "-h"):
        print(USAGE)
        return

    product_id = args[0]
    command = args[1]
    rest = args[2:]

    client = EvergreenClient()

    try:
        if command == "tree":
            parser = argparse.ArgumentParser(
                prog=f"evergreen {product_id} tree"
            )
            parser.add_argument(
                "requirement_id", nargs="?", default=None
            )
            parser.add_argument("--depth", type=int, default=None)
            parsed = parser.parse_args(rest)
            tree = client.get_tree(product_id, parsed.requirement_id)
            print(format_tree(tree, max_depth=parsed.depth))

        elif command == "backlog":
            items = client.get_backlog(product_id)
            print(format_backlog_flat(items))

        elif command == "requirement":
            if not rest:
                print(
                    f"Usage: evergreen {product_id}"
                    " requirement <id>"
                )
                sys.exit(1)
            requirement_id = rest[0]
            requirement = client.get_requirement(
                product_id, requirement_id
            )
            comments = client.get_comments(
                product_id, requirement_id
            )
            print(format_requirement(requirement, comments))

        elif command == "comment":
            parser = argparse.ArgumentParser(
                prog=f"evergreen {product_id} comment"
            )
            parser.add_argument("requirement_id")
            parser.add_argument("message")
            parsed = parser.parse_args(rest)
            comment = client.create_comment(
                product_id,
                parsed.requirement_id,
                parsed.message,
            )
            print(format_comment(comment))

        elif command == "revisions":
            parser = argparse.ArgumentParser(
                prog=f"evergreen {product_id} revisions"
            )
            parser.add_argument("--state", default=None)
            parsed = parser.parse_args(rest)
            revisions = client.list_revisions(
                product_id, parsed.state
            )
            print(format_revisions(revisions))

        elif command == "revision":
            if not rest:
                print(
                    f"Usage: evergreen {product_id}"
                    " revision <id|draft>"
                )
                sys.exit(1)

            if rest[0] == "draft":
                parser = argparse.ArgumentParser(
                    prog=f"evergreen {product_id} revision draft"
                )
                parser.add_argument("--title", default=None)
                parsed = parser.parse_args(rest[1:])
                result = client.draft_revision(
                    product_id, parsed.title
                )
                print(
                    f"Revision drafted:"
                    f" id={result['id']}"
                    f" state={result['state']}"
                )

            elif len(rest) >= 2 and rest[1] == "add-change":
                revision_id = rest[0]
                parser = argparse.ArgumentParser(
                    prog=(
                        f"evergreen {product_id}"
                        f" revision {revision_id} add-change"
                    )
                )
                parser.add_argument(
                    "--type",
                    required=True,
                    choices=[
                        "create",
                        "update",
                        "toggle",
                        "move",
                        "delete",
                    ],
                )
                parser.add_argument(
                    "--requirement-id", default=None
                )
                parser.add_argument("--title", default=None)
                parser.add_argument("--description", default=None)
                parser.add_argument("--new-state", default=None)
                parser.add_argument(
                    "--new-parent-id", default=None
                )
                parsed = parser.parse_args(rest[2:])
                result = client.add_change(
                    product_id,
                    revision_id,
                    parsed.type,
                    requirement_id=parsed.requirement_id,
                    title=parsed.title,
                    description=parsed.description,
                    new_state=parsed.new_state,
                    new_parent_id=parsed.new_parent_id,
                )
                ctype = result.get("type", "?")
                cid = result.get("change_id", "?")
                rid = result.get("requirement_id", "?")
                print(
                    f"Change added: type={ctype}"
                    f" change_id={cid}"
                    f" requirement_id={rid}"
                )

            elif len(rest) >= 2 and rest[1] == "discard":
                revision_id = rest[0]
                client.discard_revision(product_id, revision_id)
                print(f"Revision {revision_id} discarded.")

            else:
                revision_id = rest[0]
                revision = client.get_revision(
                    product_id, revision_id
                )
                print(format_revision(revision))

        else:
            print(f"Unknown command: {command}", file=sys.stderr)
            print(USAGE)
            sys.exit(1)

    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
