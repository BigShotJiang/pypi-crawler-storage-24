__all__ = []

import logging
from collections.abc import Iterable, Iterator, Mapping, Sequence, Sized
from dataclasses import dataclass
from enum import Flag
from functools import partial
from itertools import zip_longest
from typing import Any, TypedDict, cast

import numpy as np
from numpy.typing import NDArray

# Import calculators to trigger auto-registration
import dataeval.core._calculators._register  # noqa: F401
from dataeval.config import get_max_processes
from dataeval.core._calculators._cache import CalculatorCache
from dataeval.core._calculators._registry import CalculatorRegistry
from dataeval.flags import ImageStats
from dataeval.protocols import ArrayLike, Dataset, ObjectDetectionTarget, ProgressCallback
from dataeval.types import SourceIndex, StatsMap
from dataeval.utils._internal import PoolWrapper
from dataeval.utils.data import unzip_dataset
from dataeval.utils.preprocessing import BoundingBox, BoxLike, to_bounding_box

_logger = logging.getLogger(__name__)

SOURCE_INDEX = "source_index"


# Dependency mapping: stat -> required dependency
_STAT_DEPENDENCIES: dict[ImageStats, ImageStats] = {
    ImageStats.PIXEL_ENTROPY: ImageStats.PIXEL_HISTOGRAM,
    ImageStats.VISUAL_BRIGHTNESS: ImageStats.VISUAL_PERCENTILES,
    ImageStats.VISUAL_CONTRAST: ImageStats.VISUAL_PERCENTILES,
    ImageStats.VISUAL_DARKNESS: ImageStats.VISUAL_PERCENTILES,
}


def _resolve_dependencies(flags: Flag) -> Flag:
    resolved = flags
    changed = True

    # Iterate until no new dependencies are added
    while changed:
        old_resolved = resolved
        for stat, dependency in _STAT_DEPENDENCIES.items():
            if stat in resolved:
                resolved |= dependency
        changed = resolved != old_resolved

    return resolved


class StatsResult(TypedDict):
    """
    Type definition for calculation output.

    Attributes
    ----------
    source_index : Sequence[SourceIndex]
        Sequence of SourceIndex objects with image/box/channel info.
    object_count : Sequence[int]
        Sequence of object counts per image.
    invalid_box_count : Sequence[int]
        Sequence of invalid box counts per image.
    image_count : int
        Total number of images processed.
    stats : Mapping[str, NDArray[Any]]
        Mapping of statistic names to NumPy arrays of computed values.
        Keys are the names of statistics requested (e.g., 'mean', 'std', 'brightness').
        Values are NumPy arrays where each element corresponds to a source_index entry.
        String values (e.g., hashes) are stored as object dtype arrays.
    """

    source_index: Sequence[SourceIndex]
    object_count: Sequence[int]
    invalid_box_count: Sequence[int]
    image_count: int
    stats: Mapping[str, NDArray[Any]]


@dataclass
class DatumResult:
    """Result from processing a single image/box combination."""

    source_indices: list[SourceIndex]
    stats: dict[str, list[Any]]


@dataclass
class DatumBatchResult:
    """Output from processing multiple images."""

    results: list[DatumResult]
    object_count: int
    invalid_box_count: int
    warnings_list: list[str]


def _collect_calculator_stats(
    calculators: Iterable[tuple[type[Any], Flag]],
    datum: NDArray[Any],
    box: BoundingBox | None,
    per_channel: bool,
) -> tuple[list[dict[str, list[Any]]], dict[str, Any], list[str]]:
    """
    Collect stats from all calculators.

    Returns
    -------
    tuple[list[dict[str, list[Any]]], dict[str, Any], list[str]]
        A tuple of (stats_list, empty_values_map, warnings) where:
        - stats_list: List of computed stats from each calculator
        - empty_values_map: Mapping of stat names to their empty values (defaults to np.nan)
        - warnings: List of warning messages from calculators
    """
    stats_list = []
    empty_values_map: dict[str, Any] = {}
    warnings: list[str] = []
    processor = CalculatorCache(datum, box, per_channel)
    for calculator_cls, flags in calculators:
        calculator = calculator_cls(datum, processor, per_channel)
        stats_list.append(calculator.compute(flags))
        # Collect empty values from this calculator
        empty_values_map.update(calculator.get_empty_values())
        # Collect warnings from this calculator
        if hasattr(calculator, "warnings"):
            warnings.extend(calculator.warnings)
        del calculator
    return stats_list, empty_values_map, warnings


def _determine_channel_indices(calculator_output: list[dict[str, list[Any]]], num_channels: int) -> list[int | None]:
    """Determine what channel indices are needed based on processor outputs."""
    channel_indices_needed: set[int | None] = set()

    for output in calculator_output:
        first_stat_values = next(iter(output.values()))
        num_elements = len(first_stat_values)

        if num_elements == 1:
            # Single value per image/box - uses channel=None
            channel_indices_needed.add(None)
        elif num_elements == num_channels:
            # Per-channel values - uses channel=0,1,2,...
            channel_indices_needed.update(range(num_channels))
        else:
            # Unexpected case
            raise ValueError(
                f"Processor produced {num_elements} values but image has {num_channels} channels. "
                f"Expected either 1 (image-level) or {num_channels} (per-channel) values.",
            )

    # Return ordered list of channel indices (None first, then 0,1,2,...)
    return sorted(channel_indices_needed, key=lambda x: -1 if x is None else x)


def _reconcile_stats(
    calculator_output: list[dict[str, list[Any]]],
    sorted_channels: list[int | None],
    empty_values_map: dict[str, Any],
) -> dict[str, list[Any]]:
    """
    Reconcile stats from different processors into a unified structure.

    Uses empty values from empty_values_map for stats that don't apply to certain channels.
    Defaults to np.nan if a stat is not in the empty_values_map.
    """
    num_entries = len(sorted_channels)
    reconciled_stats: dict[str, list[Any]] = {}

    for output in calculator_output:
        first_stat_values = next(iter(output.values()))
        num_elements = len(first_stat_values)

        for stat_name, stat_values in output.items():
            if stat_name not in reconciled_stats:
                # Use the appropriate empty value for this stat (default to np.nan)
                empty_value = empty_values_map.get(stat_name, np.nan)
                reconciled_stats[stat_name] = [empty_value] * num_entries

            if num_elements == 1:
                # Single value goes to channel=None position
                none_idx = sorted_channels.index(None)
                reconciled_stats[stat_name][none_idx] = stat_values[0]
            else:
                # Per-channel values go to their respective positions
                for ch_idx, value in enumerate(stat_values):
                    ch_pos = sorted_channels.index(ch_idx)
                    reconciled_stats[stat_name][ch_pos] = value

    return reconciled_stats


def _get_items(
    boxes: list[BoundingBox] | None,
    per_image: bool,
    per_target: bool,
) -> list[tuple[int | None, BoundingBox | None]]:
    """Determine what to process based on per_image and per_target flags."""
    process_items: list[tuple[int | None, BoundingBox | None]] = []

    if boxes is None or len(boxes) == 0:
        # No boxes provided - only process full image if per_image is True
        if per_image:
            process_items.append((None, None))
    else:
        # Boxes are provided
        if per_image:
            # Add full image processing
            process_items.append((None, None))

        if per_target:
            # Add per-box processing
            process_items.extend((i_b, box) for i_b, box in enumerate(boxes))

    return process_items


def _compute_batch(
    args: tuple[int, NDArray[Any], list[BoundingBox] | None],
    calculators: Iterable[tuple[type[Any], Flag]],
    per_image: bool,
    per_target: bool,
    per_channel: bool,
) -> DatumBatchResult:
    i, datum, boxes = args
    results: list[DatumResult] = []
    box_count = 0
    invalid_box_count = 0
    warnings_list: list[str] = []

    # Determine the number of channels from the datum shape
    num_channels = datum.shape[-3] if len(datum.shape) >= 3 else 1

    # Determine what to process based on per_image and per_target flags
    items = _get_items(boxes, per_image, per_target)

    # Process each item (full image and/or boxes)
    for i_b, box in items:
        if box is not None:
            box_count += 1
            if not box.is_clippable():
                invalid_box_count += 1
                source = f"{i}[{i_b}]"
                warnings_list.append(f"{source}: Bounding box {box} for datum shape {datum.shape} is invalid")

        # Collect stats from all calculators
        calculator_stats, empty_values_map, calc_warnings = _collect_calculator_stats(
            calculators, datum, box, per_channel
        )

        # Thread calculator warnings with index context
        for w in calc_warnings:
            source = f"{i}" if box is None else f"{i}[{i_b}]"
            warnings_list.append(f"{source}: {w}")

        # Determine what channel indices are needed
        sorted_channels = _determine_channel_indices(calculator_stats, num_channels)

        # Reconcile stats into unified structure
        reconciled_stats = _reconcile_stats(calculator_stats, sorted_channels, empty_values_map)

        # Build index lists
        channel_indices = sorted_channels
        source = [SourceIndex(i, i_b if box is not None else None, c) for c in channel_indices]

        results.append(DatumResult(source_indices=source, stats=reconciled_stats))

    return DatumBatchResult(results, box_count, invalid_box_count, warnings_list)


def _enumerate_datum(
    images: Iterable[ArrayLike],
    boxes: Iterable[Iterable[BoxLike] | None] | None,
) -> Iterator[tuple[int, NDArray[Any], list[BoundingBox] | None]]:
    if boxes is None:
        for i, image in enumerate(images):
            yield i, np.asarray(image), None
    else:
        for i, (image, box) in enumerate(zip_longest(images, boxes, fillvalue=None)):
            if image is None:
                continue
            np_image = np.asarray(image)
            bboxes = [to_bounding_box(b, image_shape=np_image.shape) for b in box or ()]
            yield i, np_image, bboxes


def _sort(
    source_indices: list[SourceIndex],
    aggregated_stats: dict[str, list[Any]],
) -> tuple[list[SourceIndex], dict[str, NDArray[Any]]]:
    """Sort results by (item_index, box_index, channel_index) with None < 0 and convert to numpy arrays."""
    sort_indices = sorted(
        range(len(source_indices)),
        key=lambda i: (
            source_indices[i].item,
            -1 if source_indices[i].target is None else source_indices[i].target,
            -1 if source_indices[i].channel is None else source_indices[i].channel,
        ),
    )

    sorted_source_indices: list[SourceIndex] = [source_indices[i] for i in sort_indices]
    sorted_aggregated_stats: dict[str, NDArray[Any]] = {}
    for stat_name, stat_values in aggregated_stats.items():
        # Sort the values and convert to numpy array
        sorted_values = [stat_values[i] for i in sort_indices]
        np_array = np.array(sorted_values)
        # If the values are floats, convert to dtype float32 to save memory
        # while avoiding float16 overflow (max ~65504)
        if np.issubdtype(np_array.dtype, np.floating):
            np_array = np_array.astype(np.float32)
        sorted_aggregated_stats[stat_name] = np_array

    return sorted_source_indices, sorted_aggregated_stats


def _aggregate_batch(
    result: DatumBatchResult,
    source_indices: list[SourceIndex],
    aggregated_stats: dict[str, list[Any]],
    object_count: dict[int, int],
    invalid_box_count: dict[int, int],
    warning_list: list[str],
) -> None:
    """Extract and aggregate results from a single StatsProcessorOutput."""
    for r in result.results:
        source_indices.extend(r.source_indices)
        for stat_name, stat_values in r.stats.items():
            aggregated_stats.setdefault(stat_name, []).extend(stat_values)

    if result.results and result.results[0].source_indices:
        img_idx = result.results[0].source_indices[0].item
        object_count[img_idx] = result.object_count
        invalid_box_count[img_idx] = result.invalid_box_count

    warning_list.extend(result.warnings_list)


def compute_stats(
    data: Iterable[ArrayLike] | Dataset[ArrayLike] | Dataset[tuple[ArrayLike, Any, Any]],
    *,
    boxes: Iterable[Iterable[BoxLike] | None] | None = None,
    stats: Flag = ImageStats.ALL,
    per_image: bool = True,
    per_target: bool = True,
    per_channel: bool = False,
    progress_callback: ProgressCallback | None = None,
) -> StatsResult:
    """
    Compute specified statistics on a set of images, optionally within bounding boxes.

    Mixed-bit-depth datasets can produce misleading statistics when raw pixel values are
    compared directly. To avoid this, pixel values are normalized to [0, 1] based on each
    image's bit depth before any statistic is computed, keeping results meaningful and
    comparable across 8-bit, 16-bit, 32-bit, and other precision images.

    Parameters
    ----------
    data : Iterable[ArrayLike] | Dataset[ArrayLike] | Dataset[tuple[ArrayLike, Any, Any]]
        An iterable of images or a Dataset to compute statistics on.
    boxes : Iterable[Iterable[BoxLike] | None] | None
        Optional bounding boxes for each image. If None, defers to the data provided.
    stats : ImageStats, default ImageStats.ALL
        Flags indicating which statistics to compute. Can combine multiple flags
        using bitwise OR (|). Dependencies are resolved automatically.
    per_image : bool, default True
        If True, compute statistics for entire images. When boxes are provided
        and per_image=True, statistics are computed for both the full image and
        each box (if per_target=True).
    per_target : bool, default True
        If True and boxes are provided, compute statistics for each bounding box.
        Has no effect when boxes is None. At least one of per_image or per_target
        must be True.
    per_channel : bool, default False
        If True, compute per-channel statistics. If False, statistics are
        aggregated across all channels.
    progress_callback : ProgressCallback or None, default None
        Callback to report progress during calculation. Called after each image is processed
        with the current image count and total number of images (if known).

    Returns
    -------
    StatsResult
        Mapping containing computed statistics and metadata:

        - source_index: Sequence[SourceIndex] - SourceIndex objects with image/box/channel info
        - object_count: Sequence[int] - Object counts per image
        - invalid_box_count: Sequence[int] - Invalid box counts per image
        - image_count: int - Total number of images processed
        - stats: Mapping[str, Sequence[Any]] - Mapping of statistic names to sequences of computed values

        Output is sorted by (item_index, box_index, channel_index) ascending,
        with None values appearing before 0.

    Examples
    --------
    Compute all statistics:

    >>> from dataeval.flags import ImageStats
    >>> stats = compute_stats(images, boxes=boxes)

    Compute specific statistics:

    >>> stats = compute_stats(images, boxes=boxes, stats=ImageStats.PIXEL_MEAN | ImageStats.VISUAL_BRIGHTNESS)

    Use convenience groups:

    >>> stats = compute_stats(images, boxes=boxes, stats=ImageStats.PIXEL | ImageStats.VISUAL)
    >>> stats = compute_stats(images, boxes=boxes, stats=ImageStats.PIXEL_BASIC, per_channel=True)

    Compute statistics only for bounding boxes (not full images):

    >>> stats = compute_stats(images, boxes=boxes, per_image=False, per_target=True)

    Compute statistics for full images only (ignore boxes):

    >>> stats = compute_stats(images, boxes=boxes, per_image=True, per_target=False)

    Compute statistics for both full images and boxes with per-channel breakdown:

    >>> stats = compute_stats(images, boxes=boxes, per_image=True, per_target=True, per_channel=True)
    """
    source_indices: list[SourceIndex] = []
    aggregated_stats: dict[str, list[Any]] = {}
    object_count: dict[int, int] = {}
    invalid_box_count: dict[int, int] = {}
    image_count: int = 0
    warning_list: list[str] = []

    is_object_detection_dataset: bool = False

    if isinstance(data, Dataset) and len(data) > 0 and isinstance(data[0], tuple):
        datum = cast(tuple, data[0])
        if len(datum) == 3:
            is_object_detection_dataset = isinstance(datum[1], ObjectDetectionTarget)

    # `per_target` is True only if boxes are provided or data is an ObjectDetectionDataset
    per_target = per_target and (is_object_detection_dataset or boxes is not None)

    # Validate parameters
    if not per_image and not per_target:
        raise ValueError("At least one of 'per_image' or 'per_target' must be True")

    # Resolve dependencies
    stats = _resolve_dependencies(stats)

    # Get calculators from registry based on flags
    calculators = CalculatorRegistry.get_calculators(stats)

    # Log the individual flags that will be computed
    resolved_names = [
        f.name for f in type(stats) if f in stats and f.name and f.value and (f.value & (f.value - 1)) == 0
    ]
    _logger.info(
        "Starting compute_stats: %d stats [%s], per_image=%s, per_target=%s, per_channel=%s",
        len(resolved_names),
        ", ".join(resolved_names),
        per_image,
        per_target,
        per_channel,
    )

    total_images = len(data) if isinstance(data, Sized) else None

    images, boxes = (
        (data, boxes)
        if not isinstance(data, Dataset)
        else (unzip_dataset(data, per_target=False)[0], boxes)
        if boxes is not None
        else unzip_dataset(data, per_target=per_target)
    )

    # Build description for progress bar
    calculator_names = [c[0].__name__.removesuffix("Calculator") for c in calculators]
    _logger.debug("Using calculators: %s", calculator_names)

    with PoolWrapper(processes=get_max_processes()) as p:
        for result in p.imap_unordered(
            partial(
                _compute_batch,
                calculators=calculators,
                per_image=per_image,
                per_target=per_target,
                per_channel=per_channel,
            ),
            _enumerate_datum(images, boxes),
        ):
            _aggregate_batch(result, source_indices, aggregated_stats, object_count, invalid_box_count, warning_list)
            image_count += 1

            if progress_callback:
                progress_callback(image_count, total=total_images)

    # Aggregate warnings by message type, collecting indices per type
    grouped_warnings: dict[str, list[str]] = {}
    for w in warning_list:
        idx, _, msg = w.partition(": ")
        grouped_warnings.setdefault(msg, []).append(idx)
    for msg, indices in grouped_warnings.items():
        _logger.warning("%s — indices: %s", msg, ", ".join(indices))

    _logger.debug("Sorting %d source indices and %d stats", len(source_indices), len(aggregated_stats))
    sorted_source_indices, sorted_aggregated_stats = _sort(source_indices, aggregated_stats)

    total_boxes = sum(object_count.values())
    total_invalid = sum(invalid_box_count.values())
    _logger.info(
        "compute_stats complete: %d images processed, %d total boxes (%d invalid), %d stats computed",
        image_count,
        total_boxes,
        total_invalid,
        len(sorted_aggregated_stats),
    )

    return StatsResult(
        source_index=sorted_source_indices,
        object_count=[object_count.get(i, 0) for i in range(image_count)],
        invalid_box_count=[invalid_box_count.get(i, 0) for i in range(image_count)],
        image_count=image_count,
        stats=sorted_aggregated_stats,
    )


def combine_stats_results(
    results: StatsResult | Sequence[StatsResult],
) -> tuple[StatsMap, list[SourceIndex], list[int]]:
    """Combine one or more StatsResults into unified stats, source_index, and dataset_steps.

    For a single StatsResult, returns its stats and source_index directly
    with empty dataset_steps.

    For multiple results, concatenates stats arrays by key, applies cumulative
    item offsets to source_index entries (making item indices globally unique
    across datasets), and computes cumulative dataset_steps boundaries.

    Parameters
    ----------
    results : StatsResult or Sequence[StatsResult]
        A single result or sequence of results to combine.

    Returns
    -------
    tuple[StatsMap, list[SourceIndex], list[int]]
        - stats: Combined statistics mapping (arrays concatenated by key).
        - source_index: Combined source indices with globally unique item values.
        - dataset_steps: Cumulative boundaries where each dataset ends in the
          combined arrays. Empty list for a single result.

    Raises
    ------
    TypeError
        If an empty sequence is provided.
    """
    if isinstance(results, dict):
        return results["stats"], list(results["source_index"]), []

    if len(results) == 0:
        raise TypeError("Cannot combine empty sequence of stats.")

    if len(results) == 1:
        return results[0]["stats"], list(results[0]["source_index"]), []

    combined_stats: StatsMap = {}
    combined_source_index: list[SourceIndex] = []
    dataset_steps: list[int] = []
    offset = 0

    for r in results:
        stats = r["stats"]
        if not combined_stats:
            combined_stats = stats
        else:
            combined_stats = {k: np.concatenate([combined_stats[k], stats[k]]) for k in combined_stats if k in stats}

        combined_source_index.extend(
            SourceIndex(item=s.item + offset, target=s.target, channel=s.channel) for s in r["source_index"]
        )
        offset += len(r["source_index"])
        dataset_steps.append(offset)

    return combined_stats, combined_source_index, dataset_steps
