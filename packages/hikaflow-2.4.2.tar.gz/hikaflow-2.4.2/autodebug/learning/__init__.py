"""Learning from fixes module - RAG-enhanced fix generation.

This module provides:
- RAG-enhanced fix generation with embeddings
- Active learning from user feedback (Plan 59)
- Thompson Sampling integration for strategy selection
- Online learning with River for fix quality prediction
- Feedback tracking through fix lifecycle
- Cross-organization learning with privacy (Plan 65)
"""

from autodebug.learning.active_learner import (
    ActiveLearner,
    LearningSignal,
    PerformanceMonitor,
    RiverOnlineLearner,
    SimplePersistentLearner,
)
from autodebug.learning.cross_org_aggregator import (
    AnonymousPattern,
    CrossOrgAggregator,
    InMemoryPatternsDB,
)
from autodebug.learning.embeddings import EmbeddingService
from autodebug.learning.enhanced_prompt import EnhancedPromptBuilder
from autodebug.learning.feedback import FeedbackCollector
from autodebug.learning.feedback_tracker import (
    FeedbackEvent,
    FeedbackTracker,
)
from autodebug.learning.metrics_dashboard import (
    CalibrationMetrics,
    ExceptionTypeMetrics,
    LearningMetrics,
    StrategyMetrics,
)
from autodebug.learning.pattern_matcher import (
    PatternMatch,
    PatternMatcher,
    PatternRecommendationEngine,
)
from autodebug.learning.privacy import (
    DifferentialPrivacy,
    KAnonymityChecker,
    PrivacyAuditor,
    PrivacyBudgetExhausted,
    PrivacyConfig,
    hash_identifier,
)
from autodebug.learning.search import FixSearchService, SimilarFix

__all__ = [
    # RAG-enhanced generation
    "EmbeddingService",
    "FixSearchService",
    "SimilarFix",
    "FeedbackCollector",
    "EnhancedPromptBuilder",
    # Active learning (Plan 59)
    "ActiveLearner",
    "LearningSignal",
    "RiverOnlineLearner",
    "SimplePersistentLearner",
    "PerformanceMonitor",
    # Feedback tracking
    "FeedbackTracker",
    "FeedbackEvent",
    # Metrics dashboard
    "LearningMetrics",
    "StrategyMetrics",
    "ExceptionTypeMetrics",
    "CalibrationMetrics",
    # Cross-org learning (Plan 65)
    "PrivacyConfig",
    "PrivacyBudgetExhausted",
    "DifferentialPrivacy",
    "KAnonymityChecker",
    "PrivacyAuditor",
    "hash_identifier",
    "AnonymousPattern",
    "CrossOrgAggregator",
    "InMemoryPatternsDB",
    "PatternMatch",
    "PatternMatcher",
    "PatternRecommendationEngine",
]
