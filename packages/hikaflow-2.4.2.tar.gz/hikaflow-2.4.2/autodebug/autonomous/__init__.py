"""Autonomous debugging with LLM-powered hypothesis generation.

This package provides tools for automatically analyzing failures,
generating fix hypotheses using LLMs, and validating fixes against
deterministic replay harnesses.
"""

from autodebug.autonomous.analyzer import (
    FailureAnalysis,
    FailureCategory,
    analyze_failure,
    extract_context,
)
from autodebug.autonomous.hypothesis import (
    Hypothesis,
    Patch,
    generate_hypotheses,
)
from autodebug.autonomous.proof import (
    ProofCertificate,
    generate_proof_certificate,
    verify_proof_certificate,
)
from autodebug.autonomous.ranking import (
    RankedFix,
    rank_fixes,
)
from autodebug.autonomous.test_generator import (
    CodeAnalysis,
    FunctionInfo,
    TestCase,
    TestSuite,
    analyze_source_file,
    generate_tests,
    validate_generated_tests,
)
from autodebug.autonomous.validator import (
    ValidationResult,
    generate_patched_harness,
    validate_hypothesis,
)

__all__ = [
    # Analyzer
    "FailureCategory",
    "FailureAnalysis",
    "analyze_failure",
    "extract_context",
    # Hypothesis
    "Hypothesis",
    "Patch",
    "generate_hypotheses",
    # Validator
    "ValidationResult",
    "validate_hypothesis",
    "generate_patched_harness",
    # Proof
    "ProofCertificate",
    "generate_proof_certificate",
    "verify_proof_certificate",
    # Ranking
    "RankedFix",
    "rank_fixes",
    # Test Generation
    "TestCase",
    "TestSuite",
    "CodeAnalysis",
    "FunctionInfo",
    "analyze_source_file",
    "generate_tests",
    "validate_generated_tests",
]
