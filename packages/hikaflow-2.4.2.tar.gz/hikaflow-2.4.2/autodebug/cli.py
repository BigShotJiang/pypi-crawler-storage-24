"""Legacy CLI module — implementation moved to cli_commands.py.

This thin wrapper re-exports names that other modules depend on.
The canonical CLI is autodebug.cli_v2 (Typer-based).
"""

from __future__ import annotations

# Re-export the Click CLI group and utilities for backward compatibility
from autodebug.cli_commands import (  # noqa: F401
    _create_api_session,
    _read_jsonl_events,
    cli,
    # v2-imported command functions
    analyze_failure_cmd,
    auto_debug,
    detect_flaky_cmd,
    flakiness,
    heal_cmd,
    issues_delete_group,
    issues_group_error,
    issues_merge_group,
    optimize,
    patterns_add,
    patterns_contribute,
    patterns_delete,
    patterns_export,
    patterns_import,
    patterns_list,
    patterns_match,
    patterns_stats,
    replay_prod,
    run,
    session_chunk,
    session_create,
    session_download,
    session_finalize,
    session_open,
    session_share,
    session_upload,
)
