"""Pre-commit hooks for Hikaflow.

Provides shift-left prevention by catching flaky patterns before merge.
Uses the official pre-commit framework (https://pre-commit.com/).

Usage:
    # .pre-commit-config.yaml
    repos:
      - repo: https://github.com/hikaflow/hikaflow
        rev: v1.0.0
        hooks:
          - id: hikaflow-flaky-check
"""

from autodebug.hooks.pre_commit import main as check_flaky
from autodebug.hooks.scanner import FlakPatternScanner

__all__ = ["check_flaky", "FlakPatternScanner"]
