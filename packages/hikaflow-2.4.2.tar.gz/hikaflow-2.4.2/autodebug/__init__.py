"""AutoDebug CLI package."""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("hikaflow")
except PackageNotFoundError:
    try:
        __version__ = version("autodebug")
    except PackageNotFoundError:
        __version__ = "0.0.0-dev"
