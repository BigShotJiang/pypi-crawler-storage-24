"""Strategy selection for fix generation.

This module provides intelligent strategy selection using:
- Thompson Sampling bandit algorithm for explore/exploit balance
- Error-type specific strategy filtering
- Persistence of success/failure statistics for learning
- Named flakiness strategies (TimingStrategy, OrderingStrategy, etc.)
"""

from autodebug.strategies.bandit_selector import (
    ContextualThompsonSelector,
    StrategyStats,
    ThompsonSamplingSelector,
)
from autodebug.strategies.flakiness_strategies import (
    # Registry
    ALL_STRATEGIES,
    # Base
    BaseStrategy,
    ConcurrencyStrategy,
    DatabaseIsolationStrategy,
    EnvironmentStrategy,
    FlakinessCategory,
    FloatingPointStrategy,
    MockLeakageStrategy,
    NetworkStrategy,
    OrderingStrategy,
    PlatformStrategy,
    RandomnessStrategy,
    ResourceStrategy,
    SnapshotStrategy,
    StateStrategy,
    StrategyContext,
    StrategyFix,
    TimezoneStrategy,
    # Named strategies
    TimingStrategy,
    generate_all_fixes,
    get_strategies_for_category,
)
from autodebug.strategies.flakiness_strategies import (
    get_applicable_strategies as get_flakiness_strategies,
)
from autodebug.strategies.strategy_registry import (
    STRATEGIES,
    FixStrategy,
    get_applicable_strategies,
)
from autodebug.strategies.handlers import (
    HANDLERS,
    ExceptionHandler,
    HandlerContext,
    HandlerResult,
    get_handler,
    handle_exception,
)
from autodebug.strategies.strategy_selector import StrategySelector

__all__ = [
    # Bandit selector
    "ThompsonSamplingSelector",
    "StrategyStats",
    "ContextualThompsonSelector",
    # Strategy registry
    "FixStrategy",
    "STRATEGIES",
    "get_applicable_strategies",
    "StrategySelector",
    # Flakiness strategies (named)
    "BaseStrategy",
    "FlakinessCategory",
    "StrategyContext",
    "StrategyFix",
    "TimingStrategy",
    "OrderingStrategy",
    "ResourceStrategy",
    "StateStrategy",
    "NetworkStrategy",
    "ConcurrencyStrategy",
    "FloatingPointStrategy",
    "TimezoneStrategy",
    "MockLeakageStrategy",
    "SnapshotStrategy",
    "EnvironmentStrategy",
    "DatabaseIsolationStrategy",
    "RandomnessStrategy",
    "PlatformStrategy",
    "ALL_STRATEGIES",
    "get_strategies_for_category",
    "get_flakiness_strategies",
    "generate_all_fixes",
    # Exception handlers (from handlers/)
    "ExceptionHandler",
    "HandlerContext",
    "HandlerResult",
    "HANDLERS",
    "get_handler",
    "handle_exception",
]
