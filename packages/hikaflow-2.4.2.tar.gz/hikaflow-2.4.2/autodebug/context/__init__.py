"""Repository context module for understanding code relationships.

Provides tools for building and querying repository context,
including call graphs, type relationships, and similar code patterns.
"""

from autodebug.context.context_builder import (
    ContextBuilder,
    ContextItem,
    ContextResult,
    ContextType,
)
from autodebug.context.repo_indexer import (
    RepoIndexer,
    SymbolInfo,
    SymbolTable,
    SymbolType,
)
from autodebug.context.similarity_finder import (
    ASTPattern,
    SimilarCode,
    SimilarityFinder,
)

__all__ = [
    # Repository indexing
    "RepoIndexer",
    "SymbolTable",
    "SymbolInfo",
    "SymbolType",
    # Context building
    "ContextBuilder",
    "ContextResult",
    "ContextItem",
    "ContextType",
    # Similarity finding
    "SimilarityFinder",
    "SimilarCode",
    "ASTPattern",
]
