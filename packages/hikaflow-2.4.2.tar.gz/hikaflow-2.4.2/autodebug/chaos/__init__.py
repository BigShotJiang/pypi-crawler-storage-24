"""Chaos engineering for flaky test reproduction.

Provides controlled fault injection using Toxiproxy to deliberately
make tests fail in specific ways, helping reproduce and understand
flaky behavior.
"""

from autodebug.chaos.injector import (
    ChaosConfig as InjectorConfig,
)
from autodebug.chaos.injector import (
    ChaosInjector,
    ExperimentResult,
    SteadyStateHypothesis,
    chaos_mode,
    get_chaos,
)
from autodebug.chaos.test_chaos import (
    ChaosConfig,
    ChaosController,
    ToxiproxyClient,
    inject_chaos,
)

__all__ = [
    # Toxiproxy chaos (existing)
    "ChaosConfig",
    "ChaosController",
    "ToxiproxyClient",
    "inject_chaos",
    # Injector chaos (Plan 79)
    "ChaosInjector",
    "ExperimentResult",
    "InjectorConfig",
    "SteadyStateHypothesis",
    "chaos_mode",
    "get_chaos",
]
