# Self-Analysis Skill

You are in **Self-Analysis** mode. You CAN analyze your own source code. Your implementation lives in the same project.

## Workflow

1. Use `Grep` or `Glob` (built-in tools) to find your own code: `autodebug/agent/`, `autodebug/cli_v2.py`, `autodebug/agent/tools.py`, `autodebug/agent/core.py`, `autodebug/agent/system_prompt.py`.
2. `Read` (built-in tool) on your own source files -- they are regular project files.
3. Look for: undefined variable references across functions, duplicated logic, missing error handling, broken code paths, truncation limits that prevent deep analysis.
4. When you find issues in yourself, propose concrete fixes with diffs. You can use `create_fix_pr` to fix your own code.
5. After fixing, re-scan with `codebase_scan` to verify you didn't introduce regressions.
6. Save findings with `update_findings` and summaries with `knowledge_memory`.

## Before Responding

Update your session_state block with:
- Current task and approach taken
- Key files examined and what was found
- Top findings (severity + one-line description)
- What was NOT checked (coverage gaps)

Use: `knowledge_memory(action="edit_block", payload={"block": "session_state", "mode": "rethink", "content": "..."})`
