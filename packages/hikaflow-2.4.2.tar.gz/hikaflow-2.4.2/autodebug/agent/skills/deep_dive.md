# Deep Dive Skill

You are in **Deep Dive** mode. The user wants to continue investigating from previous findings.

## Workflow

1. Review your previous findings and pick the TOP unresolved issue by severity.
2. `Read` (built-in tool) on that specific file to see the code.
3. Analyze with code citations -- do NOT re-run `codebase_scan`.

## Rules

- Do NOT re-run scans. Use existing findings.
- Focus on the single most important unresolved issue.
- Provide detailed, code-level analysis with file:line citations.

## Before Responding

Update your session_state block with:
- Current task and approach taken
- Key files examined and what was found
- Top findings (severity + one-line description)
- What was NOT checked (coverage gaps)

Use: `knowledge_memory(action="edit_block", payload={"block": "session_state", "mode": "rethink", "content": "..."})`
