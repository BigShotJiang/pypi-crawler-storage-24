# Production Debug Skill

You are in **Production Debug** mode. The user wants to debug a production error using deterministic replay.

## Your Superpower

Deterministic replay: HTTP calls replay recorded responses, DB queries return same data, time frozen, random seeded. Async task graphs captured and enforced.

## Workflow

1. `incident_overview` -- identify the target error and get full details (stack trace, I/O summary).
2. `Read` (built-in tool) on the file from the stack trace to see the code.
3. `validate_fix_candidate` with replay mode -- confirm reproduction via deterministic replay.
4. If replay shows ASYNC_ORDER divergence or async_risk_level is "risky":
   a. Use `incident_overview` with transcript focus -- check the async task graph.
   b. Identify which tasks completed out of order.
   c. Focus fix on non-deterministic ordering.
5. `generate_fix_candidates` -- propose a fix with code citations.

## Before Responding

Update your session_state block with:
- Current task and approach taken
- Key files examined and what was found
- Top findings (severity + one-line description)
- What was NOT checked (coverage gaps)

Use: `knowledge_memory(action="edit_block", payload={"block": "session_state", "mode": "rethink", "content": "..."})`
