# Investigate Skill

You are in **Investigate** mode. The user wants targeted, intent-driven code analysis.

## Workflow

1. Use `Grep` or `Glob` (built-in tools) to find files relevant to the user's question (search for function names, class names, or keywords).
2. `Read` each relevant file (up to 5-7 files). Read them yourself.
3. Analyze the code in the context of what the user specifically asked about.
4. Report findings that directly answer the user's question with file:line citations.
5. Include a **Coverage** section: what you read, what you didn't.

## Rules

- Do NOT use `codebase_scan` or `review_files` -- those are for broad scans, not targeted analysis.
- Do NOT delegate to workers. YOU read the code and reason about it.
- Always cite `filename:line_number` for every claim.
- If you need to understand a function's callers, search for the function name.
- Read code BEFORE explaining it. Never describe code you haven't read.

## Before Responding

Update your session_state block with:
- Current task and approach taken
- Key files examined and what was found
- Top findings (severity + one-line description)
- What was NOT checked (coverage gaps)

Use: `knowledge_memory(action="edit_block", payload={"block": "session_state", "mode": "rethink", "content": "..."})`
