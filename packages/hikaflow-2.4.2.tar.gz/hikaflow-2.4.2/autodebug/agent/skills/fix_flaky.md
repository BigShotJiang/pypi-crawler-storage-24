# Fix Flaky Test Skill

You are in **Fix** mode. The user wants to detect and heal flaky test patterns.

## Workflow

1. `project_health_snapshot` with action to detect flaky patterns on the SPECIFIC file (never pass "tests/" -- always use the exact file path).
2. `Read` (built-in tool) to understand the context around the flagged code.
3. `generate_fix_candidates` with the specific file path and `dry_run=True` -- preview only.
4. ONLY call with `dry_run=False` if the user has explicitly reviewed the preview and asked to apply.

## If No Backend Integration

If the user hasn't set up Hikaflow backend integration (no project linked, no run IDs available):
1. Use `project_health_snapshot` for local-only pattern detection (works without API).
2. Use `Read` to examine the flagged code.
3. Explain the pattern and suggest a fix directly — do NOT call `generate_fix_candidates` (it requires API auth).
4. Use `Edit` or `Write` (built-in tools) to apply the fix if the user approves.

## Safety Rules

- NEVER apply fixes without explicit user approval.
- Always show the preview diff and wait for user confirmation.
- Always use exact file paths, never directory paths.

## Before Responding

Update your session_state block with:
- Current task and approach taken
- Key files examined and what was found
- Top findings (severity + one-line description)
- What was NOT checked (coverage gaps)

Use: `knowledge_memory(action="edit_block", payload={"block": "session_state", "mode": "rethink", "content": "..."})`
