"""Pydantic AI agent for Hikaflow interactive debugging.

This package provides an AI-powered debugging agent using Pydantic AI
that supports multiple LLM providers (OpenAI, Anthropic, Ollama, etc.).

Imports are lazy to avoid pulling in heavy dependencies (rich, pydantic_ai,
claude_agent_sdk, opentelemetry) when only lightweight submodules like
approval.py are needed. This lets the agent itself run:
    from autodebug.agent.approval import _is_safe_bash_command
without triggering the full dependency chain.
"""

__all__ = [
    # Core
    "HikaflowDeps",
    "create_agent",
    "run_agent",
    "HIKAFLOW_SYSTEM_PROMPT",
    # Base agent
    "AgentCapability",
    "AgentContext",
    "AgentResult",
    "AgentStatus",
    "BaseAgent",
    "CompositeAgent",
    "Tool",
    # Fix generator
    "FixConfidence",
    "FixGenerator",
    "FixGenerationResult",
    "FixStrategy",
    "GeneratedFix",
]

# Lazy imports: only resolve when the symbol is actually accessed.
# This avoids importing rich/pydantic_ai/opentelemetry at package load time.
_LAZY_IMPORTS = {
    # from autodebug.agent.base
    "AgentCapability": "autodebug.agent.base",
    "AgentContext": "autodebug.agent.base",
    "AgentResult": "autodebug.agent.base",
    "AgentStatus": "autodebug.agent.base",
    "BaseAgent": "autodebug.agent.base",
    "CompositeAgent": "autodebug.agent.base",
    "Tool": "autodebug.agent.base",
    # from autodebug.agent.core
    "HikaflowDeps": "autodebug.agent.core",
    "create_agent": "autodebug.agent.core",
    "run_agent": "autodebug.agent.core",
    # from autodebug.agent.fix_generator
    "FixConfidence": "autodebug.agent.fix_generator",
    "FixGenerationResult": "autodebug.agent.fix_generator",
    "FixGenerator": "autodebug.agent.fix_generator",
    "FixStrategy": "autodebug.agent.fix_generator",
    "GeneratedFix": "autodebug.agent.fix_generator",
    # from autodebug.agent.system_prompt
    "HIKAFLOW_SYSTEM_PROMPT": "autodebug.agent.system_prompt",
}


def __getattr__(name: str):
    if name in _LAZY_IMPORTS:
        import importlib
        module = importlib.import_module(_LAZY_IMPORTS[name])
        return getattr(module, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
