"""Synthetic data generation for privacy-safe testing.

This module provides utilities to generate synthetic data that matches
the shape of real data, enabling:
- Privacy-safe test sharing
- Realistic test data generation
- Data masking for replays
"""

from autodebug.synthetic.generator import (
    DataMasker,
    SyntheticGenerator,
    generate_synthetic_transcript,
    mask_sensitive_data,
)

__all__ = [
    "SyntheticGenerator",
    "DataMasker",
    "generate_synthetic_transcript",
    "mask_sensitive_data",
]
