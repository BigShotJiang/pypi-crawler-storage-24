"""Test Impact Analysis - Run only affected tests.

Integrates with pytest-testmon (open source, 71K+ weekly downloads)
for smart test selection based on code changes.

Features:
- Code dependency tracking via coverage data
- Historical failure correlation
- Change-based test prioritization
- 40-75% CI time reduction typical

Usage:
    # Enable with pytest
    pytest --testmon

    # Or via API
    POST /v1/projects/{id}/smart-test-selection
    {"changed_files": ["src/foo.py", "src/bar.py"]}
"""

from autodebug.impact.analyzer import TestImpactAnalyzer
from autodebug.impact.test_selector import (
    CoverageData,
    CoverageMapper,
    SmartTestSelector,
    TestSelectionResult,
)
from autodebug.impact.testmon import TestmonIntegration

__all__ = [
    "TestImpactAnalyzer",
    "TestmonIntegration",
    # New test selection (Plan 79)
    "CoverageMapper",
    "CoverageData",
    "SmartTestSelector",
    "TestSelectionResult",
]
