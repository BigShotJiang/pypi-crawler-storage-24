"""Module entrypoint for `python -m autodebug`."""

from autodebug.cli_v2 import app

if __name__ == "__main__":
    app()
