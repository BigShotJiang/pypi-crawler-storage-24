"""Visual regression testing - native Hikaflow implementation.

No external services required. Uses:
- Playwright for screenshot capture
- pixelmatch for perceptual diffing
- Supabase storage for baselines
- Hikaflow dashboard for review

Usage in tests:
    def test_checkout_page(page, visual):
        page.goto("/checkout")
        visual.snapshot("checkout-form")  # Captures + compares
"""

from autodebug.visual.capture import VisualCapture, VisualSnapshot
from autodebug.visual.diff import DiffResult, VisualDiff, compare_images
from autodebug.visual.pytest_plugin import visual_fixture
from autodebug.visual.storage import BaselineStorage

__all__ = [
    "VisualCapture",
    "VisualSnapshot",
    "VisualDiff",
    "compare_images",
    "DiffResult",
    "BaselineStorage",
    "visual_fixture",
]
