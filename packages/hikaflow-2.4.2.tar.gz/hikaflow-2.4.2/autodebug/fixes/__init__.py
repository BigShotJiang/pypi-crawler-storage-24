"""Fix application and generation utilities.

Provides:
- SEARCH/REPLACE format parsing and application (Aider-style)
- Layered matching for robust fix application
- Unified diff generation
"""

from autodebug.fixes.search_replace import (
    ApplyResult,
    LayeredMatcher,
    MatchType,
    SearchReplaceBlock,
    apply_blocks_to_file,
    blocks_to_unified_diff,
    parse_search_replace,
    parse_search_replace_relaxed,
)

__all__ = [
    "SearchReplaceBlock",
    "ApplyResult",
    "MatchType",
    "LayeredMatcher",
    "parse_search_replace",
    "parse_search_replace_relaxed",
    "apply_blocks_to_file",
    "blocks_to_unified_diff",
]
