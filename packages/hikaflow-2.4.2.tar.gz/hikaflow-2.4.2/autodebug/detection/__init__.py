"""Exception detection and classification.

This module provides comprehensive exception coverage using:
- Python's built-in exception hierarchy
- Domain-specific libraries (httpx, Pydantic, SQLAlchemy)
- APM-style fingerprinting for intelligent grouping
- Transcript analysis for I/O correlation (Plan 54)
- Timing analysis for performance detection (Plan 58)
"""

from autodebug.detection.adaptive_baselines import (
    AdaptiveTimingAnalyzer,
    BaselineStore,
    EndpointBaseline,
    build_baselines_from_transcripts,
    compute_baseline,
)
from autodebug.detection.correlation_analyzer import CorrelationAnalyzer
from autodebug.detection.early_flake import (
    EarlyFlakeDetector,
    EarlyFlakeReport,
    EarlyFlakeResult,
    NewTest,
    NewTestDetector,
)
from autodebug.detection.exception_classifier import ClassificationResult, ExceptionClassifier
from autodebug.detection.exception_fingerprinter import ExceptionFingerprinter
from autodebug.detection.exception_registry import ExceptionMetadata, ExceptionRegistry
from autodebug.detection.grpc_analyzer import GRPCAnalyzer
from autodebug.detection.http_analyzer import ErrorPatternDetector, HTTPAnalyzer, SchemaValidator
from autodebug.detection.io_sbfl import (
    IOOperation,
    IOSBFLAnalyzer,
    IOSBFLResult,
    extract_operations,
    rank_suspicious_io,
)
from autodebug.detection.issue_grouping import (
    IssueGroup,
    IssueGrouper,
    IssueLifecycle,
)
from autodebug.detection.llm_analyzer import (
    LLMAnalysisResult,
    LLMAnalyzer,
    RootCauseExplanation,
    build_analysis_prompt,
)
from autodebug.detection.redis_analyzer import RedisAnalyzer
from autodebug.detection.regression_detector import (
    Regression,
    RegressionDetector,
    RegressionReport,
)
from autodebug.detection.sbfl import (
    CoverageData as SBFLCoverageData,
)
from autodebug.detection.sbfl import (
    SBFLAnalyzer,
    SBFLFormula,
    SuspiciousLocation,
    rank_suspicious_locations,
)
from autodebug.detection.sbfl import (
    TestResult as SBFLTestResult,
)
from autodebug.detection.security_analyzer import SecurityAnalyzer
from autodebug.detection.sql_analyzer import SQLAnalyzer
from autodebug.detection.streaming_detector import (
    AlertLevel,
    StreamingAlert,
    StreamingDetector,
)
from autodebug.detection.timeout_predictor import (
    RiskLevel,
    TimeoutPrediction,
    TimeoutPredictor,
    TimeoutRisk,
    predict_timeouts,
)
from autodebug.detection.timing_analyzer import (
    TimingAnalyzer,
    TimingIssue,
    TimingThresholds,
    analyze_timing,
)
from autodebug.detection.transcript_analyzer import (
    ExceptionRecord,
    GRPCRecord,
    HTTPRecord,
    RedisRecord,
    SQLRecord,
    Transcript,
    TranscriptAnalyzer,
    TranscriptInsight,
    analyze_transcript,
)

__all__ = [
    # Exception classification (Plan 51)
    "ExceptionRegistry",
    "ExceptionMetadata",
    "ExceptionFingerprinter",
    "ExceptionClassifier",
    "ClassificationResult",
    # Transcript analysis (Plan 54)
    "TranscriptAnalyzer",
    "TranscriptInsight",
    "HTTPRecord",
    "SQLRecord",
    "ExceptionRecord",
    "Transcript",
    "analyze_transcript",
    "HTTPAnalyzer",
    "SchemaValidator",
    "ErrorPatternDetector",
    "RedisRecord",
    "GRPCRecord",
    "SQLAnalyzer",
    "RedisAnalyzer",
    "GRPCAnalyzer",
    "SecurityAnalyzer",
    "CorrelationAnalyzer",
    # Timing analysis (Plan 58)
    "TimingAnalyzer",
    "TimingIssue",
    "TimingThresholds",
    "analyze_timing",
    "TimeoutPredictor",
    "TimeoutRisk",
    "TimeoutPrediction",
    "RiskLevel",
    "predict_timeouts",
    # Adaptive baselines
    "AdaptiveTimingAnalyzer",
    "EndpointBaseline",
    "BaselineStore",
    "build_baselines_from_transcripts",
    "compute_baseline",
    # LLM analysis
    "LLMAnalyzer",
    "LLMAnalysisResult",
    "RootCauseExplanation",
    "build_analysis_prompt",
    # Regression detection
    "RegressionDetector",
    "RegressionReport",
    "Regression",
    # IO SBFL
    "IOSBFLAnalyzer",
    "IOSBFLResult",
    "IOOperation",
    "rank_suspicious_io",
    "extract_operations",
    # Streaming detection
    "StreamingDetector",
    "StreamingAlert",
    "AlertLevel",
    # Issue grouping
    "IssueGrouper",
    "IssueGroup",
    "IssueLifecycle",
    # Early flake detection (Plan 79)
    "EarlyFlakeDetector",
    "EarlyFlakeResult",
    "EarlyFlakeReport",
    "NewTestDetector",
    "NewTest",
    # SBFL fault localization (Plan 79)
    "SBFLAnalyzer",
    "SBFLFormula",
    "SuspiciousLocation",
    "SBFLTestResult",
    "SBFLCoverageData",
    "rank_suspicious_locations",
]
