"""Multi-stage repair pipeline for high-quality fixes.

Provides:
- RepairPipeline: Multi-stage pipeline for generating and validating fixes
- FixTester: Tests fixes by executing them
- FixRanker: Scores and ranks fixes by quality
- GenerationStrategies: Different fix generation approaches
"""

from autodebug.pipeline.fix_ranker import (
    FixRanker,
    RankingWeights,
)
from autodebug.pipeline.fix_tester import (
    FixTester,
    TestResult,
)
from autodebug.pipeline.generation_strategies import (
    STRATEGIES,
    GenerationStrategy,
    get_strategy,
)
from autodebug.pipeline.repair_pipeline import (
    FailureContext,
    GeneratedFix,
    PipelineConfig,
    PipelineFix,
    PipelineResult,
    PipelineStage,
    RepairPipeline,
)

__all__ = [
    # Core pipeline
    "RepairPipeline",
    "PipelineStage",
    "PipelineResult",
    "PipelineFix",
    "PipelineConfig",
    "FailureContext",
    "GeneratedFix",
    # Testing
    "FixTester",
    "TestResult",
    # Ranking
    "FixRanker",
    "RankingWeights",
    # Strategies
    "GenerationStrategy",
    "STRATEGIES",
    "get_strategy",
]
