"""Autonomous agent tools for LLM-First Debugging.

This module provides production-ready tool implementations for the
autonomous debugging agent. Each tool follows the BaseTool interface
and implements async execute() methods with proper error handling.

Tool Categories:
- File Tools: ReadFileTool, SearchCodeTool
- Analysis Tools: ReadTranscriptTool, ClassifyErrorTool
- Fix Tools: SearchSimilarFixesTool, GenerateFixTool
- Test Tools: RunTestTool, RunVerificationTool
- Output Tools: CreatePRTool
"""

from autodebug.llm_first.tools.analysis_tools import (
    ClassifyErrorTool,
    ReadTranscriptTool,
)
from autodebug.llm_first.tools.file_tools import (
    ReadFileTool,
    SearchCodeTool,
)
from autodebug.llm_first.tools.fix_tools import (
    GenerateFixTool,
    SearchSimilarFixesTool,
)
from autodebug.llm_first.tools.output_tools import (
    CreatePRTool,
)
from autodebug.llm_first.tools.test_tools import (
    RunTestTool,
    RunVerificationTool,
)

__all__ = [
    # File tools
    "ReadFileTool",
    "SearchCodeTool",
    # Analysis tools
    "ReadTranscriptTool",
    "ClassifyErrorTool",
    # Fix tools
    "SearchSimilarFixesTool",
    "GenerateFixTool",
    # Test tools
    "RunTestTool",
    "RunVerificationTool",
    # Output tools
    "CreatePRTool",
]
