"""LLM-First Debugging Architecture (Plan 80).

This module implements a comprehensive LLM-powered debugging system with:
- Enhanced RAG for fix retrieval
- Hybrid fault localization (SBFL + LLM)
- Multi-agent root cause debate
- Multi-hypothesis fix generation
- Iterative refinement
- Continuous learning
- Agentic tool system
- Execution grounding with runtime data
- Test minimization using delta debugging
- Self-consistency voting for reliability
- Feedback loop for continuous improvement
- Multi-run flakiness analysis
- Specification extraction from tests
- Template-based fix synthesis
- Speculative parallel fix racing
"""

# =============================================================================
# Core Models
# =============================================================================

# =============================================================================
# Autonomous Agent
# =============================================================================
from autodebug.llm_first.autonomous import AutonomousDebugAgent
from autodebug.llm_first.debate import DebateOrchestrator

# =============================================================================
# Execution Grounding (Runtime Data Integration)
# =============================================================================
from autodebug.llm_first.execution_grounding import (
    ExecutionGrounder,
    GroundedEvidence,
    IOTranscriptSummary,
    LocalsAtDivergence,
    ground_failure_context,
)

# =============================================================================
# Feedback Loop and Continuous Learning
# =============================================================================
from autodebug.llm_first.feedback import (
    AgentWeights,
    EmbeddingWeights,
    FeedbackCollector,
    FeedbackLearner,
    FixOutcome,
    StrategyPriorities,
    get_default_collector,
    get_default_learner,
    record_and_learn,
)

# =============================================================================
# Pipeline Components
# =============================================================================
from autodebug.llm_first.fix_embeddings import FixEmbeddingPipeline
from autodebug.llm_first.hybrid_localizer import HybridFaultLocalizer
from autodebug.llm_first.hybrid_search import HybridFixSearch
from autodebug.llm_first.iterative_refiner import IterativeRefiner
from autodebug.llm_first.models import (
    AgentHypothesis,
    DebugResult,
    FailureContext,
    FixEmbedding,
    FixHypothesis,
    FlakinessPrediction,
    GeneratedTest,
    RootCauseExplanation,
    SimilarFix,
    SuspiciousLocation,
)

# =============================================================================
# Fix Generation
# =============================================================================
from autodebug.llm_first.multi_hypothesis import MultiHypothesisFixer

# =============================================================================
# Multi-Run Flakiness Analysis
# =============================================================================
from autodebug.llm_first.multi_run_analyzer import (
    Correlation,
    FlakinessPattern,
    FlakinessStat,
    MultiRunAnalyzer,
    OrderDependency,
    full_flakiness_report,
    quick_flakiness_check,
)

# =============================================================================
# Specification Extraction
# =============================================================================
from autodebug.llm_first.spec_extractor import (
    Specification,
    SpecificationExtractor,
    SpecType,
)

# =============================================================================
# Specialist Agents
# =============================================================================
from autodebug.llm_first.specialists import (
    NetworkExpertAgent,
    OrderingExpertAgent,
    ResourceExpertAgent,
    StateExpertAgent,
    TimingExpertAgent,
)

# =============================================================================
# Speculative Parallel Fix Racing
# =============================================================================
from autodebug.llm_first.speculative import (
    AdaptiveRacer,
    RaceResult,
    SpeculativeFixer,
)

# =============================================================================
# Template-Based Fix Synthesis
# =============================================================================
from autodebug.llm_first.synthesis import (
    FixSynthesizer,
    FixTemplate,
    TransformationResult,
)

# =============================================================================
# Test Minimization (Delta Debugging)
# =============================================================================
from autodebug.llm_first.test_minimizer import (
    MinimizedTest,
    ParsedTest,
    TestElement,
    TestMinimizer,
    format_minimization_report,
    minimize_test_file,
)

# =============================================================================
# Self-Consistency Voting
# =============================================================================
from autodebug.llm_first.voting import (
    Cluster,
    SelfConsistencyVoter,
    VotedFix,
    VotedHypothesis,
)

# =============================================================================
# Agentic Tool System
# =============================================================================

# Tools module may not be present in all installations
try:
    from autodebug.llm_first.tools import (
        # Fix tools
        ApplyPatchTool,
        GetCoverageTool,
        GetStackTraceTool,
        GitBlameTool,
        # Git tools
        GitDiffTool,
        GitLogTool,
        GrepTool,
        # File and code tools
        ReadFileTool,
        # Analysis tools
        RunTestTool,
        SearchCodeTool,
        # Base tool infrastructure
        Tool,
        ToolRegistry,
        ToolResult,
        ValidateSyntaxTool,
        WriteFileTool,
    )
    _tools_available = True
except ImportError:
    _tools_available = False

# =============================================================================
# Public API
# =============================================================================

__all__ = [
    # Models
    "FailureContext",
    "FixEmbedding",
    "FixHypothesis",
    "SimilarFix",
    "SuspiciousLocation",
    "AgentHypothesis",
    "RootCauseExplanation",
    "DebugResult",
    "FlakinessPrediction",
    "GeneratedTest",
    # Pipeline components
    "FixEmbeddingPipeline",
    "HybridFixSearch",
    "HybridFaultLocalizer",
    # Agents
    "TimingExpertAgent",
    "StateExpertAgent",
    "OrderingExpertAgent",
    "NetworkExpertAgent",
    "ResourceExpertAgent",
    "DebateOrchestrator",
    # Fix generation
    "MultiHypothesisFixer",
    "IterativeRefiner",
    # Autonomous
    "AutonomousDebugAgent",
    # Execution Grounding
    "ExecutionGrounder",
    "GroundedEvidence",
    "IOTranscriptSummary",
    "LocalsAtDivergence",
    "ground_failure_context",
    # Test Minimization
    "TestMinimizer",
    "MinimizedTest",
    "TestElement",
    "ParsedTest",
    "minimize_test_file",
    "format_minimization_report",
    # Voting
    "SelfConsistencyVoter",
    "VotedHypothesis",
    "VotedFix",
    "Cluster",
    # Feedback Loop
    "FixOutcome",
    "EmbeddingWeights",
    "AgentWeights",
    "StrategyPriorities",
    "FeedbackCollector",
    "FeedbackLearner",
    "get_default_collector",
    "get_default_learner",
    "record_and_learn",
    # Multi-Run Analysis
    "MultiRunAnalyzer",
    "FlakinessPattern",
    "OrderDependency",
    "Correlation",
    "FlakinessStat",
    "quick_flakiness_check",
    "full_flakiness_report",
    # Specification Extraction
    "SpecificationExtractor",
    "Specification",
    "SpecType",
    # Fix Synthesis
    "FixSynthesizer",
    "FixTemplate",
    "TransformationResult",
    # Speculative Racing
    "SpeculativeFixer",
    "AdaptiveRacer",
    "RaceResult",
]

# Add tools to __all__ if available
if _tools_available:
    __all__.extend([
        # Tool infrastructure
        "Tool",
        "ToolRegistry",
        "ToolResult",
        # File and code tools
        "ReadFileTool",
        "WriteFileTool",
        "SearchCodeTool",
        "GrepTool",
        # Analysis tools
        "RunTestTool",
        "GetStackTraceTool",
        "GetCoverageTool",
        # Fix tools
        "ApplyPatchTool",
        "ValidateSyntaxTool",
        # Git tools
        "GitDiffTool",
        "GitBlameTool",
        "GitLogTool",
    ])
