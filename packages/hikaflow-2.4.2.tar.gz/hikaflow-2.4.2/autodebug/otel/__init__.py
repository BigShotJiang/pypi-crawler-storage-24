"""OpenTelemetry integration for flakiness signals.

Exports flakiness events as OpenTelemetry:
- Metrics: flake_rate, mttf, stability_score
- Traces: flaky test runs with divergence info
- Events: flakiness detection events
"""

from autodebug.otel.flakiness import (
    FlakinessSignals,
    get_flakiness_metrics,
    record_flake_detected,
    record_flake_fixed,
    record_flaky_run,
    start_flaky_test_span,
)

__all__ = [
    "FlakinessSignals",
    "record_flaky_run",
    "record_flake_detected",
    "record_flake_fixed",
    "get_flakiness_metrics",
    "start_flaky_test_span",
]
