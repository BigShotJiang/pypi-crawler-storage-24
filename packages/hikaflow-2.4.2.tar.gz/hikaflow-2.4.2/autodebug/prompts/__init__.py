"""Prompt engineering module for LLM-based fix generation.

Uses Instructor for structured outputs and few-shot examples
for improved fix quality and reliability. Also provides interactive
CLI prompts using questionary.
"""

import questionary

from autodebug.prompts.cli_prompts import (
    confirm_action,
    confirm_fix_application,
    confirm_pr_creation,
    input_password,
    input_text,
    select_debug_action,
    select_environment,
    select_error_to_debug,
    select_fix_strategy,
    select_model,
    select_multiple_errors,
    select_time_range,
)
from autodebug.prompts.instructor_client import (
    InstructorClient,
    create_instructor_client,
)
from autodebug.prompts.prompt_builder import PromptBuilder
from autodebug.prompts.structured_output import (
    Analysis,
    Fix,
    FixStrategy,
    HypothesisResponse,
    MultiHypothesisResponse,
    Verification,
)

__all__ = [
    # Structured output models
    "FixStrategy",
    "Analysis",
    "Fix",
    "Verification",
    "HypothesisResponse",
    "MultiHypothesisResponse",
    # Prompt builder
    "PromptBuilder",
    # Instructor client
    "InstructorClient",
    "create_instructor_client",
    # CLI prompts
    "questionary",
    "select_error_to_debug",
    "select_multiple_errors",
    "confirm_fix_application",
    "select_fix_strategy",
    "confirm_pr_creation",
    "select_environment",
    "select_time_range",
    "select_model",
    "confirm_action",
    "select_debug_action",
    "input_text",
    "input_password",
]
