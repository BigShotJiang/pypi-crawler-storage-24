"""Few-shot examples for TypeError fixes."""

TYPE_ERROR_EXAMPLES = [
    {
        "error": {
            "type": "TypeError",
            "message": "'NoneType' object is not subscriptable",
            "code": '''def get_first_item(data):
    result = fetch_data()
    return result["items"][0]''',
            "context": "fetch_data() can return None",
        },
        "analysis": {
            "root_cause": "fetch_data() returns None when no data is found, but the code assumes it always returns a dict.",
            "reasoning": "The error says 'NoneType' is not subscriptable, meaning we tried result['items'] when result is None. This happens when fetch_data() fails to find data.",
        },
        "fix": {
            "strategy": "add_none_check",
            "diff": '''--- a/data.py
+++ b/data.py
@@ -1,3 +1,5 @@
 def get_first_item(data):
     result = fetch_data()
+    if result is None:
+        return None
     return result["items"][0]''',
            "explanation": "Check for None before accessing result. Return None to propagate the 'not found' state to the caller.",
        },
    },
    {
        "error": {
            "type": "TypeError",
            "message": "unsupported operand type(s) for +: 'int' and 'str'",
            "code": '''def format_price(price, currency):
    return price + " " + currency''',
            "context": "price is an integer, not a string",
        },
        "analysis": {
            "root_cause": "The price parameter is an integer but the code tries to concatenate it with strings.",
            "reasoning": "The error shows int + str fails. Looking at the code, 'price + \" \"' fails because price is numeric. The function expects to format a price display.",
        },
        "fix": {
            "strategy": "add_type_check",
            "diff": '''--- a/format.py
+++ b/format.py
@@ -1,2 +1,2 @@
 def format_price(price, currency):
-    return price + " " + currency
+    return str(price) + " " + currency''',
            "explanation": "Convert price to string before concatenation. Alternatively, use f-strings: f'{price} {currency}'.",
        },
    },
    {
        "error": {
            "type": "TypeError",
            "message": "'NoneType' object is not callable",
            "code": '''def process(callback):
    callback = get_callback()
    callback()''',
            "context": "get_callback() may return None",
        },
        "analysis": {
            "root_cause": "get_callback() returns None when no callback is registered, but the code tries to call it as a function.",
            "reasoning": "The error 'NoneType' is not callable means we tried callback() when callback is None. This happens when no callback is configured.",
        },
        "fix": {
            "strategy": "add_none_check",
            "diff": '''--- a/process.py
+++ b/process.py
@@ -1,3 +1,4 @@
 def process(callback):
     callback = get_callback()
+    if callback is not None:
-    callback()
+        callback()''',
            "explanation": "Only call the callback if it's not None. This makes the callback optional.",
        },
    },
    {
        "error": {
            "type": "TypeError",
            "message": "can only concatenate list (not \"str\") to list",
            "code": '''def add_item(items, new_item):
    return items + new_item''',
            "context": "Trying to add string to list",
        },
        "analysis": {
            "root_cause": "The + operator for lists expects another list, not a string. new_item is a string but items is a list.",
            "reasoning": "List concatenation requires both operands to be lists. The function should append the item, not concatenate.",
        },
        "fix": {
            "strategy": "fix_logic",
            "diff": '''--- a/list_ops.py
+++ b/list_ops.py
@@ -1,2 +1,2 @@
 def add_item(items, new_item):
-    return items + new_item
+    return items + [new_item]''',
            "explanation": "Wrap new_item in a list to concatenate, or use items.append(new_item) if modifying in place.",
        },
    },
    {
        "error": {
            "type": "TypeError",
            "message": "argument of type 'NoneType' is not iterable",
            "code": '''def has_feature(config, feature):
    return feature in config.get("features")''',
            "context": "config.get('features') can return None",
        },
        "analysis": {
            "root_cause": "config.get('features') returns None when 'features' key doesn't exist, and 'in' operator can't check membership in None.",
            "reasoning": "The 'in' operator requires an iterable on the right side. When features is None, we can't check if feature is in it.",
        },
        "fix": {
            "strategy": "use_get_default",
            "diff": '''--- a/config.py
+++ b/config.py
@@ -1,2 +1,2 @@
 def has_feature(config, feature):
-    return feature in config.get("features")
+    return feature in config.get("features", [])''',
            "explanation": "Provide an empty list as default so the 'in' check works even when features is missing.",
        },
    },
]

TYPE_ERROR_NEGATIVE_EXAMPLES = [
    {
        "bad_fix": '''# DON'T DO THIS: Catch TypeError blindly
def get_first_item(data):
    try:
        result = fetch_data()
        return result["items"][0]
    except TypeError:
        return None''',
        "why_bad": "This hides the actual problem. The None check should happen at the source (after fetch_data), not catch the error downstream.",
    },
    {
        "bad_fix": '''# DON'T DO THIS: Type coercion without validation
def format_price(price, currency):
    return str(price) + " " + str(currency)''',
        "why_bad": "Converting everything to string hides type errors. If price is accidentally a list or dict, this produces nonsense output.",
    },
    {
        "bad_fix": '''# DON'T DO THIS: Overly broad isinstance check
def process(callback):
    callback = get_callback()
    if isinstance(callback, type(lambda: None)):
        callback()''',
        "why_bad": "Using type() comparison is fragile. Use 'callable()' or check 'is not None' instead.",
    },
]
