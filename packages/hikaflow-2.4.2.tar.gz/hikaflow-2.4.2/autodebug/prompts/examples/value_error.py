"""Few-shot examples for ValueError fixes."""

VALUE_ERROR_EXAMPLES = [
    {
        "error": {
            "type": "ValueError",
            "message": "invalid literal for int() with base 10: 'abc'",
            "code": '''def parse_age(age_str):
    return int(age_str)''',
            "context": "User input may not be a valid integer",
        },
        "analysis": {
            "root_cause": "The input string 'abc' cannot be converted to an integer because it contains non-numeric characters.",
            "reasoning": "int() raises ValueError when the string isn't a valid integer representation. This happens with user input that hasn't been validated.",
        },
        "fix": {
            "strategy": "add_validation",
            "diff": '''--- a/parse.py
+++ b/parse.py
@@ -1,2 +1,5 @@
 def parse_age(age_str):
+    if not age_str.strip().isdigit():
+        raise ValueError(f"Invalid age: {age_str!r}. Expected a positive integer.")
     return int(age_str)''',
            "explanation": "Validate input before conversion and provide a clear error message for invalid input.",
        },
    },
    {
        "error": {
            "type": "ValueError",
            "message": "not enough values to unpack (expected 3, got 2)",
            "code": '''def parse_date(date_str):
    year, month, day = date_str.split("-")
    return year, month, day''',
            "context": "Date string may have wrong format",
        },
        "analysis": {
            "root_cause": "The date string only has 2 parts when split by '-', but the code expects 3 parts (year, month, day).",
            "reasoning": "Unpacking expects exactly 3 values but split() returned 2. The date format is different than expected.",
        },
        "fix": {
            "strategy": "add_validation",
            "diff": '''--- a/date.py
+++ b/date.py
@@ -1,3 +1,6 @@
 def parse_date(date_str):
+    parts = date_str.split("-")
+    if len(parts) != 3:
+        raise ValueError(f"Invalid date format: {date_str!r}. Expected YYYY-MM-DD.")
-    year, month, day = date_str.split("-")
+    year, month, day = parts
     return year, month, day''',
            "explanation": "Check the number of parts before unpacking and provide a clear error message about the expected format.",
        },
    },
    {
        "error": {
            "type": "ValueError",
            "message": "list.remove(x): x not in list",
            "code": '''def remove_item(items, item):
    items.remove(item)
    return items''',
            "context": "Trying to remove item that may not exist",
        },
        "analysis": {
            "root_cause": "The item to be removed doesn't exist in the list, so list.remove() raises ValueError.",
            "reasoning": "remove() requires the item to be present. This can happen when the item was already removed or never added.",
        },
        "fix": {
            "strategy": "add_validation",
            "diff": '''--- a/list_ops.py
+++ b/list_ops.py
@@ -1,3 +1,4 @@
 def remove_item(items, item):
-    items.remove(item)
+    if item in items:
+        items.remove(item)
     return items''',
            "explanation": "Check if item exists before removing. Alternatively, use try/except or discard() for sets.",
        },
    },
    {
        "error": {
            "type": "ValueError",
            "message": "time data '2023/01/15' does not match format '%Y-%m-%d'",
            "code": '''from datetime import datetime

def parse_date(date_str):
    return datetime.strptime(date_str, "%Y-%m-%d")''',
            "context": "Date uses / instead of - as separator",
        },
        "analysis": {
            "root_cause": "The date string uses '/' as separator but the format string expects '-' as separator.",
            "reasoning": "strptime requires exact format match. The input has '/' but format specifies '-'.",
        },
        "fix": {
            "strategy": "add_validation",
            "diff": '''--- a/date.py
+++ b/date.py
@@ -1,3 +1,8 @@
 from datetime import datetime

 def parse_date(date_str):
+    # Support multiple date formats
+    for fmt in ["%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y"]:
+        try:
+            return datetime.strptime(date_str, fmt)
+        except ValueError:
+            continue
+    raise ValueError(f"Could not parse date: {date_str!r}")
-    return datetime.strptime(date_str, "%Y-%m-%d")''',
            "explanation": "Try multiple common date formats and raise a clear error if none match.",
        },
    },
    {
        "error": {
            "type": "ValueError",
            "message": "math domain error",
            "code": '''import math

def calculate_log(value):
    return math.log(value)''',
            "context": "Value may be zero or negative",
        },
        "analysis": {
            "root_cause": "math.log() was called with zero or a negative number, which is not in the domain of the logarithm function.",
            "reasoning": "Logarithm is only defined for positive numbers. The input value must have been <= 0.",
        },
        "fix": {
            "strategy": "add_validation",
            "diff": '''--- a/math_ops.py
+++ b/math_ops.py
@@ -1,3 +1,5 @@
 import math

 def calculate_log(value):
+    if value <= 0:
+        raise ValueError(f"Cannot calculate log of {value}. Value must be positive.")
     return math.log(value)''',
            "explanation": "Validate that the input is positive before calling log(). Provide a clear error message.",
        },
    },
]

VALUE_ERROR_NEGATIVE_EXAMPLES = [
    {
        "bad_fix": '''# DON'T DO THIS: Silently ignore invalid input
def parse_age(age_str):
    try:
        return int(age_str)
    except ValueError:
        return 0  # Default to 0''',
        "why_bad": "Defaulting to 0 hides the error. Invalid input should be rejected, not silently converted.",
    },
    {
        "bad_fix": '''# DON'T DO THIS: Overly permissive parsing
def parse_date(date_str):
    # Just try to extract any numbers
    import re
    nums = re.findall(r'\\d+', date_str)
    return nums[0], nums[1], nums[2]''',
        "why_bad": "This accepts any string with numbers, leading to incorrect parsing. Strict format validation is safer.",
    },
]
