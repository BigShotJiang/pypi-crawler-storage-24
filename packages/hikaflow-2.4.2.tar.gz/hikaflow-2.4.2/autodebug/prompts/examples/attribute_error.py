"""Few-shot examples for AttributeError fixes."""

ATTRIBUTE_ERROR_EXAMPLES = [
    {
        "error": {
            "type": "AttributeError",
            "message": "'NoneType' object has no attribute 'name'",
            "code": '''def get_user_name(user_id):
    user = find_user(user_id)
    return user.name''',
            "context": "find_user returns None when user not found",
        },
        "analysis": {
            "root_cause": "find_user() returns None when no user is found with the given ID, but the code assumes a user object is always returned.",
            "reasoning": "The error shows we tried to access .name on None. This happens when find_user(user_id) doesn't find a matching user.",
        },
        "fix": {
            "strategy": "add_none_check",
            "diff": '''--- a/user.py
+++ b/user.py
@@ -1,3 +1,5 @@
 def get_user_name(user_id):
     user = find_user(user_id)
+    if user is None:
+        raise ValueError(f"User not found: {user_id}")
     return user.name''',
            "explanation": "Check for None before accessing attributes. Raise a descriptive error so callers know why it failed.",
        },
    },
    {
        "error": {
            "type": "AttributeError",
            "message": "'list' object has no attribute 'items'",
            "code": '''def process_response(data):
    for key, value in data.items():
        print(f"{key}: {value}")''',
            "context": "API returns list instead of dict",
        },
        "analysis": {
            "root_cause": "The data parameter is a list, not a dictionary. The API changed its response format or this endpoint returns a list.",
            "reasoning": "The error shows .items() called on a list. Lists don't have .items() - that's a dict method. The code expects a dict but receives a list.",
        },
        "fix": {
            "strategy": "add_type_check",
            "diff": '''--- a/api.py
+++ b/api.py
@@ -1,3 +1,6 @@
 def process_response(data):
+    if isinstance(data, list):
+        data = {i: item for i, item in enumerate(data)}
     for key, value in data.items():
         print(f"{key}: {value}")''',
            "explanation": "Convert list to dict if needed, or handle both types appropriately based on the API contract.",
        },
    },
    {
        "error": {
            "type": "AttributeError",
            "message": "'str' object has no attribute 'append'",
            "code": '''def add_to_list(items, item):
    items.append(item)
    return items''',
            "context": "items was passed as a string instead of list",
        },
        "analysis": {
            "root_cause": "The items parameter is a string, not a list. The caller passed the wrong type.",
            "reasoning": "Strings don't have .append() method. The function expects a list but received a string, indicating a caller error.",
        },
        "fix": {
            "strategy": "add_validation",
            "diff": '''--- a/list_ops.py
+++ b/list_ops.py
@@ -1,3 +1,5 @@
 def add_to_list(items, item):
+    if not isinstance(items, list):
+        raise TypeError(f"Expected list, got {type(items).__name__}")
     items.append(item)
     return items''',
            "explanation": "Validate input type at the function boundary. This makes the error message clearer for callers.",
        },
    },
    {
        "error": {
            "type": "AttributeError",
            "message": "module 'json' has no attribute 'loads'",
            "code": '''import json

def parse(data):
    return json.loads(data)''',
            "context": "Local file named json.py shadows stdlib",
        },
        "analysis": {
            "root_cause": "There's a local file named 'json.py' that shadows the standard library json module.",
            "reasoning": "If json.loads doesn't exist, it means we imported the wrong module. A local json.py file would be imported instead of stdlib.",
        },
        "fix": {
            "strategy": "fix_import",
            "diff": '''# The fix is to rename the local json.py file to something else.
# For example, rename json.py to json_utils.py.
# No code change in this file - the import will work after renaming.''',
            "explanation": "Rename the local json.py file to avoid shadowing the standard library module.",
        },
    },
    {
        "error": {
            "type": "AttributeError",
            "message": "'Response' object has no attribute 'data'",
            "code": '''def get_data(url):
    response = requests.get(url)
    return response.data''',
            "context": "requests Response uses .json() not .data",
        },
        "analysis": {
            "root_cause": "The requests library Response object doesn't have a .data attribute. The correct attribute is .json() for JSON or .text/.content for raw data.",
            "reasoning": "This is an API misunderstanding. The requests library uses different attribute names than expected.",
        },
        "fix": {
            "strategy": "fix_logic",
            "diff": '''--- a/api.py
+++ b/api.py
@@ -1,3 +1,3 @@
 def get_data(url):
     response = requests.get(url)
-    return response.data
+    return response.json()''',
            "explanation": "Use .json() to parse JSON response, or .text for raw text, or .content for bytes.",
        },
    },
]

ATTRIBUTE_ERROR_NEGATIVE_EXAMPLES = [
    {
        "bad_fix": '''# DON'T DO THIS: Use getattr with None default
def get_user_name(user_id):
    user = find_user(user_id)
    return getattr(user, 'name', None)''',
        "why_bad": "This silently returns None on error, which propagates the problem. Better to fail fast with a clear error.",
    },
    {
        "bad_fix": '''# DON'T DO THIS: hasattr check without handling
def get_user_name(user_id):
    user = find_user(user_id)
    if hasattr(user, 'name'):
        return user.name''',
        "why_bad": "This returns None implicitly when hasattr is False. Either raise an error or explicitly return a default.",
    },
]
