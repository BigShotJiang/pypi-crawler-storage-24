"""Generic few-shot examples for fallback cases."""

GENERIC_EXAMPLES = [
    {
        "error": {
            "type": "IndexError",
            "message": "list index out of range",
            "code": '''def get_first(items):
    return items[0]''',
            "context": "List may be empty",
        },
        "analysis": {
            "root_cause": "The list is empty, so accessing index 0 fails.",
            "reasoning": "IndexError on index 0 means the list has no elements. The function doesn't handle empty lists.",
        },
        "fix": {
            "strategy": "add_bounds_check",
            "diff": '''--- a/list_ops.py
+++ b/list_ops.py
@@ -1,2 +1,4 @@
 def get_first(items):
+    if not items:
+        return None
     return items[0]''',
            "explanation": "Check if list is empty before accessing. Return None or raise a descriptive error.",
        },
    },
    {
        "error": {
            "type": "ZeroDivisionError",
            "message": "division by zero",
            "code": '''def calculate_average(values):
    return sum(values) / len(values)''',
            "context": "List may be empty",
        },
        "analysis": {
            "root_cause": "The values list is empty, so len(values) is 0, causing division by zero.",
            "reasoning": "Empty list has length 0, and division by 0 is undefined. The function needs to handle empty input.",
        },
        "fix": {
            "strategy": "add_validation",
            "diff": '''--- a/math_ops.py
+++ b/math_ops.py
@@ -1,2 +1,4 @@
 def calculate_average(values):
+    if not values:
+        raise ValueError("Cannot calculate average of empty list")
     return sum(values) / len(values)''',
            "explanation": "Check for empty input and raise a descriptive error rather than getting ZeroDivisionError.",
        },
    },
    {
        "error": {
            "type": "FileNotFoundError",
            "message": "[Errno 2] No such file or directory: 'config.json'",
            "code": '''def load_config():
    with open("config.json") as f:
        return json.load(f)''',
            "context": "Config file may not exist",
        },
        "analysis": {
            "root_cause": "The config.json file doesn't exist in the current directory.",
            "reasoning": "FileNotFoundError means the file doesn't exist. This happens when running from a different directory or before setup.",
        },
        "fix": {
            "strategy": "handle_error",
            "diff": '''--- a/config.py
+++ b/config.py
@@ -1,3 +1,7 @@
+from pathlib import Path
+
 def load_config():
-    with open("config.json") as f:
-        return json.load(f)
+    config_path = Path(__file__).parent / "config.json"
+    if not config_path.exists():
+        raise FileNotFoundError(f"Config not found at {config_path}")
+    with open(config_path) as f:
+        return json.load(f)''',
            "explanation": "Use Path relative to the script location. Check existence and provide a clear error message.",
        },
    },
    {
        "error": {
            "type": "RecursionError",
            "message": "maximum recursion depth exceeded",
            "code": '''def factorial(n):
    return n * factorial(n - 1)''',
            "context": "Missing base case in recursion",
        },
        "analysis": {
            "root_cause": "The factorial function has no base case to stop recursion when n reaches 0 or 1.",
            "reasoning": "Without a base case, the recursion continues forever until hitting the stack limit.",
        },
        "fix": {
            "strategy": "fix_logic",
            "diff": '''--- a/math_ops.py
+++ b/math_ops.py
@@ -1,2 +1,4 @@
 def factorial(n):
+    if n <= 1:
+        return 1
     return n * factorial(n - 1)''',
            "explanation": "Add base case for n <= 1. Also consider adding validation for negative n.",
        },
    },
    {
        "error": {
            "type": "AssertionError",
            "message": "assert response.status_code == 200",
            "code": '''def test_api_health():
    response = client.get("/health")
    assert response.status_code == 200''',
            "context": "Test assertion failed",
        },
        "analysis": {
            "root_cause": "The API /health endpoint returned a non-200 status code, but the test expects 200.",
            "reasoning": "The assertion shows expected 200 but got something else. Need to check if the API is actually unhealthy or if the test expectation is wrong.",
        },
        "fix": {
            "strategy": "fix_assertion",
            "diff": '''--- a/test_api.py
+++ b/test_api.py
@@ -1,3 +1,5 @@
 def test_api_health():
     response = client.get("/health")
-    assert response.status_code == 200
+    assert response.status_code == 200, \\
+        f"Expected 200, got {response.status_code}: {response.text}"''',
            "explanation": "Add a descriptive error message to the assertion to help debug failures.",
        },
    },
]

GENERIC_NEGATIVE_EXAMPLES = [
    {
        "bad_fix": '''# DON'T DO THIS: Catch all exceptions
try:
    result = some_operation()
except Exception:
    pass  # Silently ignore all errors''',
        "why_bad": "Catching and ignoring all exceptions hides bugs. Only catch specific, expected exceptions.",
    },
    {
        "bad_fix": '''# DON'T DO THIS: Use assertions for input validation
def process_data(data):
    assert data is not None
    assert isinstance(data, dict)
    # ... process data''',
        "why_bad": "Assertions are for debugging, not validation. They can be disabled with -O flag. Use if/raise instead.",
    },
]
