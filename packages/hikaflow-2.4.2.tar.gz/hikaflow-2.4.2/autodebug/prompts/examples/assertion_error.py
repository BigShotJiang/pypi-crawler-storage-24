"""Few-shot examples for AssertionError fixes (common in flaky tests)."""

ASSERTION_ERROR_EXAMPLES = [
    {
        "error": {
            "type": "AssertionError",
            "message": "assert ['b', 'a', 'c'] == ['a', 'b', 'c']",
            "code": '''def test_get_users():
    users = db.query("SELECT name FROM users")
    names = [u["name"] for u in users]
    assert names == ["a", "b", "c"]''',
            "context": "SQL query returns rows in non-deterministic order",
        },
        "analysis": {
            "root_cause": "The SQL query has no ORDER BY clause, so row order is non-deterministic. The assertion compares against a hardcoded list expecting a specific order.",
            "reasoning": "The AssertionError shows two lists with same elements in different order. The query 'SELECT name FROM users' doesn't specify ordering, so the database can return rows in any order. This is a classic ORDERING flakiness pattern.",
        },
        "fix": {
            "strategy": "add_order_by",
            "diff": '''--- a/test_users.py
+++ b/test_users.py
@@ -1,4 +1,4 @@
 def test_get_users():
-    users = db.query("SELECT name FROM users")
+    users = db.query("SELECT name FROM users ORDER BY name")
     names = [u["name"] for u in users]
     assert names == ["a", "b", "c"]''',
            "explanation": "Add ORDER BY to the SQL query to ensure deterministic row ordering. This fixes the root cause rather than sorting in the assertion.",
        },
    },
    {
        "error": {
            "type": "AssertionError",
            "message": "assert 2 == 3",
            "code": '''async def test_worker_processes():
    worker.start()
    await asyncio.sleep(0.1)
    results = worker.get_results()
    assert len(results) == 3''',
            "context": "Worker hasn't finished processing all items before assertion",
        },
        "analysis": {
            "root_cause": "The test uses a fixed sleep(0.1) instead of waiting for the worker to actually complete. Under load, the worker may not finish all 3 items in 100ms.",
            "reasoning": "The assertion expects 3 results but only got 2, meaning the worker was still processing when the assertion ran. The asyncio.sleep(0.1) is a timing-dependent wait that's too short under CI load.",
        },
        "fix": {
            "strategy": "replace_sleep_with_wait",
            "diff": '''--- a/test_worker.py
+++ b/test_worker.py
@@ -1,5 +1,5 @@
 async def test_worker_processes():
     worker.start()
-    await asyncio.sleep(0.1)
+    await worker.wait_complete(timeout=5.0)
     results = worker.get_results()
     assert len(results) == 3''',
            "explanation": "Replace the arbitrary sleep with an explicit wait for worker completion. This eliminates the timing dependency entirely.",
        },
    },
    {
        "error": {
            "type": "AssertionError",
            "message": "assert {'key': 'old_value'} == {'key': 'new_value'}",
            "code": '''def test_update_config(shared_config):
    shared_config["key"] = "new_value"
    result = get_config()
    assert result == {"key": "new_value"}''',
            "context": "Shared fixture leaking state from another test",
        },
        "analysis": {
            "root_cause": "The 'shared_config' fixture is shared across tests without reset. A previous test may have set 'key' to 'old_value', and get_config() returns the cached/shared state rather than the updated value.",
            "reasoning": "The assertion shows the config has 'old_value' instead of 'new_value'. This suggests shared mutable state between tests. The fixture likely doesn't reset between tests.",
        },
        "fix": {
            "strategy": "isolate_fixture",
            "diff": '''--- a/conftest.py
+++ b/conftest.py
@@ -1,4 +1,5 @@
 @pytest.fixture
 def shared_config():
-    return global_config
+    original = global_config.copy()
+    yield global_config
+    global_config.update(original)''',
            "explanation": "Save and restore the original config state after each test to prevent state pollution between tests.",
        },
    },
]

ASSERTION_ERROR_NEGATIVE_EXAMPLES = [
    {
        "bad_fix": '''def test_get_users():
    users = db.query("SELECT name FROM users")
    names = [u["name"] for u in users]
    assert sorted(names) == sorted(["a", "b", "c"])''',
        "why_bad": "Sorting both sides of the assertion masks the ordering bug in the SQL query. The query should have ORDER BY instead. If the test needs to verify order, this fix hides a real bug.",
    },
    {
        "bad_fix": '''@pytest.mark.flaky(reruns=3)
async def test_worker_processes():
    worker.start()
    await asyncio.sleep(0.1)
    results = worker.get_results()
    assert len(results) == 3''',
        "why_bad": "Adding @flaky or @retry decorators doesn't fix the race condition. It just makes the test pass more often by retrying. The underlying timing issue remains and will still cause CI failures.",
    },
]
