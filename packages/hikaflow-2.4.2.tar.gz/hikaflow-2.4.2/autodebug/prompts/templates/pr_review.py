"""PR review prompt templates.

Templates for AI-powered PR review focusing on flakiness detection.
"""

from __future__ import annotations

from typing import List

# System prompt for PR review
PR_REVIEW_SYSTEM_PROMPT = """You are an expert code reviewer specializing in test quality and reliability.

Your task is to review pull requests for patterns that cause flaky tests.

Flaky patterns to detect:
1. **Timing Issues**
   - time.sleep() without mocks
   - Short timeouts (< 1s)
   - Missing await on async calls
   - Race conditions in threads

2. **Ordering Issues**
   - SQL SELECT without ORDER BY
   - Dict/set iteration in assertions
   - Non-deterministic sorting

3. **Resource Issues**
   - Hardcoded ports or paths
   - Missing cleanup in teardown
   - File operations without with blocks

4. **State Issues**
   - Global variable mutations
   - Missing test isolation
   - Shared fixtures without reset

5. **Network Issues**
   - External API calls without mocks
   - No retry logic for HTTP calls
   - DNS-dependent code

Severity levels:
- CRITICAL: Will definitely cause flakiness
- HIGH: Very likely to cause issues
- MEDIUM: May cause intermittent failures
- LOW: Minor concern

For each finding, provide:
1. File and line number
2. Pattern name and description
3. Severity level
4. Suggested fix
"""


# Prompt for reviewing PR diff
PR_REVIEW_PROMPT = """Review this PR diff for flaky test patterns.

## Files Changed
{files_changed}

## Diff
```diff
{diff}
```

For each flaky pattern found:
1. Identify the file and line
2. Name the pattern
3. Explain why it's problematic
4. Suggest a fix
5. Rate severity (CRITICAL/HIGH/MEDIUM/LOW)

Findings:"""


# Prompt for reviewing test files specifically
TEST_FILE_REVIEW_PROMPT = """Review this test file for flaky patterns.

## Test File: {file_path}

```python
{code}
```

Focus on:
1. Test isolation (no shared state)
2. Deterministic assertions
3. Proper mocking of external dependencies
4. Cleanup in fixtures/teardown
5. No timing dependencies

Findings:"""


# Prompt for generating GitHub review comments
GITHUB_COMMENT_PROMPT = """Generate a GitHub review comment for this finding.

## Finding
Pattern: {pattern_name}
File: {file_path}
Line: {line_number}
Severity: {severity}
Description: {description}

## Code Context
```python
{code_context}
```

Generate a helpful, constructive comment that:
1. Explains the issue clearly
2. Shows why it can cause flakiness
3. Provides a concrete fix suggestion

Comment:"""


# Prompt for summarizing review findings
REVIEW_SUMMARY_PROMPT = """Summarize these PR review findings.

## Findings
{findings}

Generate a summary that:
1. Lists total findings by severity
2. Highlights the most critical issues
3. Provides an overall flakiness risk assessment
4. Recommends whether to merge or request changes

Summary:"""


# Prompt for detecting specific patterns
PATTERN_DETECTION_PROMPT = """Check if this code matches the pattern: {pattern_name}

## Pattern Description
{pattern_description}

## Code
```python
{code}
```

Does this code match the pattern? If yes, at what line?

Match:"""


def format_pr_review_prompt(
    files_changed: List[str],
    diff: str,
) -> str:
    """Format the PR review prompt."""
    return PR_REVIEW_PROMPT.format(
        files_changed="\n".join(f"- {f}" for f in files_changed),
        diff=diff,
    )


def format_test_file_review_prompt(
    file_path: str,
    code: str,
) -> str:
    """Format the test file review prompt."""
    return TEST_FILE_REVIEW_PROMPT.format(
        file_path=file_path,
        code=code,
    )


def format_github_comment_prompt(
    pattern_name: str,
    file_path: str,
    line_number: int,
    severity: str,
    description: str,
    code_context: str,
) -> str:
    """Format the GitHub comment prompt."""
    return GITHUB_COMMENT_PROMPT.format(
        pattern_name=pattern_name,
        file_path=file_path,
        line_number=line_number,
        severity=severity,
        description=description,
        code_context=code_context,
    )


def format_review_summary_prompt(findings: str) -> str:
    """Format the review summary prompt."""
    return REVIEW_SUMMARY_PROMPT.format(findings=findings)


def format_pattern_detection_prompt(
    pattern_name: str,
    pattern_description: str,
    code: str,
) -> str:
    """Format the pattern detection prompt."""
    return PATTERN_DETECTION_PROMPT.format(
        pattern_name=pattern_name,
        pattern_description=pattern_description,
        code=code,
    )
