"""Test generation prompt templates.

Templates for AI-powered test generation from replay transcripts.
"""

from __future__ import annotations

# System prompt for test generation
TEST_GENERATION_SYSTEM_PROMPT = """You are an expert software engineer specializing in writing tests.

Your task is to generate pytest tests from recorded I/O transcripts.

Guidelines:
1. Use pytest fixtures for setup/teardown
2. Mock external dependencies (HTTP, databases, Redis)
3. Write clear, descriptive test names
4. Include assertions for all expected behaviors
5. Follow the codebase's existing test patterns
6. Add docstrings explaining what's being tested

For HTTP mocking, use the `responses` library:
```python
import responses

@responses.activate
def test_api_call():
    responses.add(
        responses.GET,
        "https://api.example.com/data",
        json={"result": "success"},
        status=200,
    )
    ...
```

For database mocking, use fixtures or `pytest-postgresql`.

For Redis mocking, use `fakeredis`.
"""


# Prompt for generating pytest tests
GENERATE_PYTEST_PROMPT = """Generate a pytest test from this recorded behavior.

## Function Under Test
```python
{function_code}
```

## Recorded I/O
### HTTP Calls
{http_calls}

### SQL Queries
{sql_queries}

### Redis Commands
{redis_commands}

## Expected Outcome
{expected_outcome}

Generate a complete pytest test with:
1. Appropriate fixtures for mocking
2. Clear test function name
3. Comprehensive assertions
4. Docstring explaining the test

Test Code:"""


# Prompt for generating HTTP fixtures
HTTP_FIXTURE_PROMPT = """Generate pytest fixtures for these HTTP calls.

## Recorded HTTP Calls
{http_calls}

Generate:
1. A `responses` fixture that mocks all calls
2. Helper functions for common patterns
3. Parametrized variants if appropriate

Fixtures:"""


# Prompt for generating SQL fixtures
SQL_FIXTURE_PROMPT = """Generate pytest fixtures for these SQL queries.

## Recorded SQL Queries
{sql_queries}

## Database Schema (if available)
{schema}

Generate:
1. A database fixture with test data
2. Fixtures for each query's expected results
3. Transaction handling for isolation

Fixtures:"""


# Prompt for generating Redis fixtures
REDIS_FIXTURE_PROMPT = """Generate pytest fixtures for these Redis commands.

## Recorded Redis Commands
{redis_commands}

Generate:
1. A fakeredis fixture
2. Pre-populated data fixtures
3. Assertion helpers

Fixtures:"""


# Prompt for generating property-based tests
PBT_GENERATION_PROMPT = """Generate Hypothesis property-based tests from these observations.

## Function
```python
{function_code}
```

## Observed Behaviors
{observations}

## Invariants Detected
{invariants}

Generate:
1. Hypothesis strategies for inputs
2. Property tests for each invariant
3. Stateful tests if appropriate

Property Tests:"""


# Prompt for test name generation
TEST_NAME_PROMPT = """Generate a descriptive test name for this behavior.

## Function: {function_name}
## Input: {input_summary}
## Expected Output: {expected_output}
## Condition: {condition}

Format: test_{function_name}_{condition}_{expected_behavior}

Test Name:"""


def format_pytest_generation_prompt(
    function_code: str,
    http_calls: str,
    sql_queries: str,
    redis_commands: str,
    expected_outcome: str,
) -> str:
    """Format the pytest generation prompt."""
    return GENERATE_PYTEST_PROMPT.format(
        function_code=function_code,
        http_calls=http_calls or "None",
        sql_queries=sql_queries or "None",
        redis_commands=redis_commands or "None",
        expected_outcome=expected_outcome,
    )


def format_http_fixture_prompt(http_calls: str) -> str:
    """Format the HTTP fixture prompt."""
    return HTTP_FIXTURE_PROMPT.format(http_calls=http_calls)


def format_sql_fixture_prompt(sql_queries: str, schema: str = "") -> str:
    """Format the SQL fixture prompt."""
    return SQL_FIXTURE_PROMPT.format(
        sql_queries=sql_queries,
        schema=schema or "Not available",
    )


def format_redis_fixture_prompt(redis_commands: str) -> str:
    """Format the Redis fixture prompt."""
    return REDIS_FIXTURE_PROMPT.format(redis_commands=redis_commands)


def format_pbt_prompt(
    function_code: str,
    observations: str,
    invariants: str,
) -> str:
    """Format the property-based test prompt."""
    return PBT_GENERATION_PROMPT.format(
        function_code=function_code,
        observations=observations,
        invariants=invariants,
    )


def format_test_name_prompt(
    function_name: str,
    input_summary: str,
    expected_output: str,
    condition: str,
) -> str:
    """Format the test name generation prompt."""
    return TEST_NAME_PROMPT.format(
        function_name=function_name,
        input_summary=input_summary,
        expected_output=expected_output,
        condition=condition,
    )
