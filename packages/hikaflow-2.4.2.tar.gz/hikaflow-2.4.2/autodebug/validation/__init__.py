"""Fix compilation and validation module.

Provides validation that all generated fixes compile, type-check,
and can be applied cleanly before being suggested to users.

Also includes:
- Root cause verification (Plan 60)
- Symptom suppression detection
"""

from autodebug.validation.auto_fixer import AutoFixer
from autodebug.validation.fix_validator import (
    FixValidator,
    ValidationError,
    ValidationResult,
    ValidationWarning,
)
from autodebug.validation.root_cause_verifier import (
    HeuristicResult,
    RootCauseHeuristics,
    RootCauseVerification,
    RootCauseVerifier,
)
from autodebug.validation.symptom_detector import (
    PatternDefinition,
    SymptomDetector,
    SymptomPattern,
)
from autodebug.validation.ty_checker import MypyChecker, TyChecker

__all__ = [
    # Fix validation (Plan 52)
    "FixValidator",
    "ValidationResult",
    "ValidationError",
    "ValidationWarning",
    "TyChecker",
    "MypyChecker",
    "AutoFixer",
    # Root cause verification (Plan 60)
    "RootCauseVerifier",
    "RootCauseVerification",
    "RootCauseHeuristics",
    "HeuristicResult",
    # Symptom detection (Plan 60)
    "SymptomDetector",
    "SymptomPattern",
    "PatternDefinition",
]
