"""Static and dynamic analysis integration.

This module provides:
- Trunk.io for orchestrating multiple tools (Plan 55)
- Data flow analysis with Semgrep taint mode (Plan 57)
- Call graph construction with NetworkX (Plan 57)
- Dynamic analysis for runtime inspection (Plan 62)
- Fallback to direct tool invocation when tools unavailable
"""

from autodebug.analysis.call_graph import (
    CallGraph,
    FunctionInfo,
    build_call_graph,
    find_callers,
)
from autodebug.analysis.data_flow import (
    CodeLocation,
    DataFlowAnalyzer,
    DataFlowPath,
    DataOrigin,
    SemgrepTaintAnalyzer,
    Transformation,
    trace_data_flow,
)
from autodebug.analysis.dynamic_inspector import (
    DynamicContext,
    DynamicInspector,
    ExecutionFrame,
    VariableSnapshot,
    inspect_exception,
)
from autodebug.analysis.runtime_probe import (
    CapturedContext,
    ProbeContextManager,
    RuntimeProbe,
    capture_exception_context,
    get_global_probe,
    get_latest_context,
    install_global_hook,
    uninstall_global_hook,
)
from autodebug.analysis.trunk_analyzer import (
    DiffAnalysis,
    StaticAnalysisResult,
    TrunkAnalyzer,
    analyze_code,
    analyze_file,
)
from autodebug.analysis.type_inferrer import (
    TypeExpectation,
    TypeInferrer,
    TypeInfo,
    infer_types,
)

__all__ = [
    # Static analysis (Plan 55)
    "TrunkAnalyzer",
    "StaticAnalysisResult",
    "DiffAnalysis",
    "analyze_file",
    "analyze_code",
    # Data flow (Plan 57)
    "DataFlowAnalyzer",
    "SemgrepTaintAnalyzer",
    "DataFlowPath",
    "DataOrigin",
    "CodeLocation",
    "Transformation",
    "trace_data_flow",
    # Call graph (Plan 57)
    "CallGraph",
    "FunctionInfo",
    "build_call_graph",
    "find_callers",
    # Dynamic analysis (Plan 62)
    "DynamicInspector",
    "DynamicContext",
    "ExecutionFrame",
    "VariableSnapshot",
    "inspect_exception",
    "RuntimeProbe",
    "CapturedContext",
    "ProbeContextManager",
    "capture_exception_context",
    "get_global_probe",
    "install_global_hook",
    "uninstall_global_hook",
    "get_latest_context",
    "TypeInferrer",
    "TypeInfo",
    "TypeExpectation",
    "infer_types",
]
