"""Self-healing test system for automatic flaky test repair.

This module provides language-agnostic detection and repair of common
flaky test patterns including:
- Async wait issues (time.sleep, hardcoded delays)
- Order dependency (shared state, missing cleanup)
- Concurrency issues (race conditions, missing locks)
- Resource leaks (unclosed connections, file handles)
- Time-dependent tests (wall clock assumptions)
- Randomness issues (unseeded random)

Supported languages:
- Python (full support)
- TypeScript/JavaScript (full support)
- Go (detection + LLM repair)
- Java (detection + LLM repair)
"""

from autodebug.healing.detector import (
    DetectionResult,
    FlakyDetector,
    detect_flaky_patterns,
)
from autodebug.healing.healer import (
    HealingResult,
    HealingStrategy,
    TestHealer,
    heal_test,
)
from autodebug.healing.languages import (
    SUPPORTED_LANGUAGES,
    LanguageAdapter,
    get_adapter,
)
from autodebug.healing.patterns import (
    BUILTIN_PATTERNS,
    FlakyPattern,
    PatternCategory,
    PatternMatch,
)

__all__ = [
    # Patterns
    "FlakyPattern",
    "PatternMatch",
    "PatternCategory",
    "BUILTIN_PATTERNS",
    # Detection
    "FlakyDetector",
    "DetectionResult",
    "detect_flaky_patterns",
    # Healing
    "TestHealer",
    "HealingResult",
    "HealingStrategy",
    "heal_test",
    # Languages
    "LanguageAdapter",
    "get_adapter",
    "SUPPORTED_LANGUAGES",
]
