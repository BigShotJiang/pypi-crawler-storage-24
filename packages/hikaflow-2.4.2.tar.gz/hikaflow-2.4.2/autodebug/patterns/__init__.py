"""Pattern Database for learning from proven fixes.

This module provides a knowledge base that learns from validated repairs.
When a fix is proven to work, the pattern is stored (anonymized) and can
be matched against future failures for instant suggestions.

Key features:
- Automatic pattern extraction from proven fixes
- TraceSim-inspired similarity matching
- Cross-project learning (opt-in)
- Privacy-preserving anonymization

Based on research:
- TraceSim: https://arxiv.org/abs/2009.12590
- iFixFlakies: ISSTA 2019

Example usage:

    from autodebug.patterns import (
        get_pattern_store,
        extract_pattern_from_fix,
        find_similar_patterns,
    )

    # Store a proven fix
    pattern = extract_pattern_from_fix(
        exception_data={"exc_type": "KeyError", "message": "'user_id'", "stack": [...]},
        fix_diff="...",
        fix_description="Add null check before accessing key",
    )
    store = get_pattern_store()
    store.add_pattern(pattern)

    # Find similar patterns for a new failure
    matches = find_similar_patterns(
        exception_data={"exc_type": "KeyError", "message": "'account_id'", "stack": [...]},
    )
    for match in matches:
        print(f"Found similar pattern: {match.pattern.fix_type}")
        print(f"Success rate: {match.pattern.success_rate:.0%}")
"""

from autodebug.patterns.extractor import (
    anonymize_diff,
    anonymize_message,
    extract_exception_signature,
    extract_pattern_from_fix,
)
from autodebug.patterns.matcher import (
    MatchConfig,
    PatternMatcher,
    find_similar_patterns,
    format_match_report,
)
from autodebug.patterns.store import (
    CodePattern,
    ExceptionSignature,
    FixPattern,
    PatternMatch,
    PatternStore,
    StackFrame,
    get_pattern_store,
)

__all__ = [
    # Data models
    "StackFrame",
    "ExceptionSignature",
    "CodePattern",
    "FixPattern",
    "PatternMatch",
    # Storage
    "PatternStore",
    "get_pattern_store",
    # Extraction
    "extract_pattern_from_fix",
    "extract_exception_signature",
    "anonymize_message",
    "anonymize_diff",
    # Matching
    "MatchConfig",
    "PatternMatcher",
    "find_similar_patterns",
    "format_match_report",
]
