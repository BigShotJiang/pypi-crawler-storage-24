"""DSPy prompt optimization for Hikaflow."""

from autodebug.optimization.metrics import (
    combined_metric,
    fix_applies_cleanly,
    fix_compiles,
    fix_is_minimal,
)
from autodebug.optimization.modules import (
    ErrorAnalyzer,
    FixGenerator,
    HikaflowPipeline,
)
from autodebug.optimization.signatures import (
    AnalyzeError,
    ClassifyError,
    GenerateFix,
)

__all__ = [
    # Signatures
    "AnalyzeError",
    "GenerateFix",
    "ClassifyError",
    # Modules
    "ErrorAnalyzer",
    "FixGenerator",
    "HikaflowPipeline",
    # Metrics
    "fix_compiles",
    "fix_applies_cleanly",
    "fix_is_minimal",
    "combined_metric",
]
