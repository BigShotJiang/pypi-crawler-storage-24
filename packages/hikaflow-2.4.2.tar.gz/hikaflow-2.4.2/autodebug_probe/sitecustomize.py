"""AutoDebug probe auto-import hook for subprocesses."""

from autodebug_probe.runtime import initialize

initialize()
