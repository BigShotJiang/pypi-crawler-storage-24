"""AutoDebug probe package (instrumentation layer)."""
