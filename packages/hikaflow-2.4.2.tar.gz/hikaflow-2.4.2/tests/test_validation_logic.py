from worker.validate import compute_report


def test_validation_report_stable():
    results = [
        {"exit_code": 1, "exception": {"type": "ValueError", "message": "boom", "stack": []}},
        {"exit_code": 1, "exception": {"type": "ValueError", "message": "boom", "stack": []}},
    ]
    report = compute_report(results)
    assert report["stable"] is True
    assert report["determinism_score"] == 1.0


def test_validation_report_unstable():
    results = [
        {"exit_code": 1, "exception": {"type": "ValueError", "message": "boom", "stack": []}},
        {"exit_code": 1, "exception": {"type": "RuntimeError", "message": "oops", "stack": []}},
    ]
    report = compute_report(results)
    assert report["stable"] is False
    assert report["determinism_score"] == 0.5
