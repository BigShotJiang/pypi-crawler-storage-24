"""Tests for the autodebug export module."""



class TestExportToHar:
    """Tests for HAR export functionality."""

    def test_export_basic_request(self):
        """Test exporting a basic HTTP request to HAR format."""
        from autodebug.export import export_to_har

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url": "http://example.com/api",
                "status": 200,
                "ts": 1000.0,
            }
        ]

        har = export_to_har(records)

        assert har["log"]["version"] == "1.2"
        assert len(har["log"]["entries"]) == 1

        entry = har["log"]["entries"][0]
        assert entry["request"]["method"] == "GET"
        assert entry["request"]["url"] == "http://example.com/api"
        assert entry["response"]["status"] == 200

    def test_export_with_url_canonical(self):
        """Test exporting with url_canonical field (normalized records)."""
        from autodebug.export import export_to_har

        records = [
            {
                "type": "HTTP",
                "method": "POST",
                "url_canonical": "http://example.com/api/data",
                "status": 201,
                "ts": 1000.0,
            }
        ]

        har = export_to_har(records)

        entry = har["log"]["entries"][0]
        assert entry["request"]["url"] == "http://example.com/api/data"

    def test_export_with_headers(self):
        """Test exporting with request and response headers."""
        from autodebug.export import export_to_har

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url": "http://example.com/api",
                "status": 200,
                "ts": 1000.0,
                "request_headers": {"Content-Type": "application/json"},
                "response_headers": {"X-Custom": "value"},
            }
        ]

        har = export_to_har(records)

        entry = har["log"]["entries"][0]
        assert len(entry["request"]["headers"]) == 1
        assert entry["request"]["headers"][0]["name"] == "Content-Type"
        assert len(entry["response"]["headers"]) == 1

    def test_export_skips_non_http_records(self):
        """Test that non-HTTP records are skipped."""
        from autodebug.export import export_to_har

        records = [
            {"type": "SQL", "query": "SELECT 1"},
            {"type": "HTTP", "method": "GET", "url": "http://example.com", "status": 200, "ts": 1000.0},
            {"type": "TIME", "value": 123.456},
        ]

        har = export_to_har(records)
        assert len(har["log"]["entries"]) == 1

    def test_export_with_query_string(self):
        """Test parsing query string from URL."""
        from autodebug.export import export_to_har

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url": "http://example.com/api?foo=bar&baz=qux",
                "status": 200,
                "ts": 1000.0,
            }
        ]

        har = export_to_har(records)

        entry = har["log"]["entries"][0]
        assert len(entry["request"]["queryString"]) == 2
        assert entry["request"]["queryString"][0] == {"name": "foo", "value": "bar"}


class TestExportToCurl:
    """Tests for curl export functionality."""

    def test_export_get_request(self):
        """Test exporting a GET request to curl."""
        from autodebug.export import export_to_curl

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url": "http://example.com/api",
                "status": 200,
            }
        ]

        curl = export_to_curl(records)

        assert 'curl' in curl
        assert '"http://example.com/api"' in curl
        # GET is default, so -X GET should not be present
        assert '-X GET' not in curl

    def test_export_post_request(self):
        """Test exporting a POST request to curl."""
        from autodebug.export import export_to_curl

        records = [
            {
                "type": "HTTP",
                "method": "POST",
                "url": "http://example.com/api",
                "status": 200,
            }
        ]

        curl = export_to_curl(records)

        assert '-X POST' in curl

    def test_export_with_headers(self):
        """Test exporting with headers to curl."""
        from autodebug.export import export_to_curl

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url": "http://example.com/api",
                "status": 200,
                "request_headers": {"Authorization": "Bearer token123"},
            }
        ]

        curl = export_to_curl(records)

        assert '-H "Authorization: Bearer token123"' in curl

    def test_export_with_body(self):
        """Test exporting with request body to curl."""
        from autodebug.export import export_to_curl

        records = [
            {
                "type": "HTTP",
                "method": "POST",
                "url": "http://example.com/api",
                "status": 200,
                "request_body": '{"key": "value"}',
            }
        ]

        curl = export_to_curl(records)

        assert "-d " in curl
        assert '{"key": "value"}' in curl

    def test_export_with_url_canonical(self):
        """Test exporting with url_canonical field."""
        from autodebug.export import export_to_curl

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url_canonical": "http://example.com/normalized",
                "status": 200,
            }
        ]

        curl = export_to_curl(records)

        assert '"http://example.com/normalized"' in curl


class TestExportToPostman:
    """Tests for Postman export functionality."""

    def test_export_basic_request(self):
        """Test exporting a basic request to Postman format."""
        from autodebug.export import export_to_postman

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url": "http://example.com/api",
                "status": 200,
            }
        ]

        postman = export_to_postman(records)

        assert postman["info"]["schema"] == "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
        assert len(postman["item"]) == 1

        item = postman["item"][0]
        assert item["request"]["method"] == "GET"

    def test_export_with_custom_collection_name(self):
        """Test exporting with custom collection name."""
        from autodebug.export import export_to_postman

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url": "http://example.com/api",
                "status": 200,
            }
        ]

        postman = export_to_postman(records, collection_name="My API Tests")

        assert postman["info"]["name"] == "My API Tests"

    def test_export_with_url_canonical(self):
        """Test exporting with url_canonical field."""
        from autodebug.export import export_to_postman

        records = [
            {
                "type": "HTTP",
                "method": "GET",
                "url_canonical": "http://example.com/normalized",
                "status": 200,
            }
        ]

        postman = export_to_postman(records)

        item = postman["item"][0]
        assert item["request"]["url"]["raw"] == "http://example.com/normalized"
