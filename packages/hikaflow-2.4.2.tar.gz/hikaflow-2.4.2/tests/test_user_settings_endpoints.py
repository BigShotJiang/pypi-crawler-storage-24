"""Tests for user-level settings endpoints: notification preferences and API keys."""

from unittest.mock import patch

# The router imports functions directly from api.db.user_settings,
# so we must patch them at the import location in the router module.
_MOD = "api.routers.user_settings"


class TestGetNotificationPreferences:
    """Tests for GET /v1/user/notification-preferences."""

    def test_get_prefs_existing(self, client, auth_header):
        with patch(f"{_MOD}.get_user_notification_preferences") as mock_get:
            mock_get.return_value = {
                "failed_runs": True,
                "fix_generated": False,
                "weekly_report": True,
            }
            response = client.get(
                "/v1/user/notification-preferences", headers=auth_header,
            )
            assert response.status_code == 200
            data = response.json()
            assert data["failed_runs"] is True
            assert data["fix_generated"] is False
            assert data["weekly_report"] is True

    def test_get_prefs_defaults(self, client, auth_header):
        with patch(f"{_MOD}.get_user_notification_preferences") as mock_get:
            mock_get.return_value = None
            response = client.get(
                "/v1/user/notification-preferences", headers=auth_header,
            )
            assert response.status_code == 200
            data = response.json()
            assert data["failed_runs"] is True
            assert data["fix_generated"] is True
            assert data["weekly_report"] is False

    def test_get_prefs_unauthorized(self, client):
        response = client.get("/v1/user/notification-preferences")
        assert response.status_code == 401


class TestUpdateNotificationPreferences:
    """Tests for POST /v1/user/notification-preferences."""

    def test_update_prefs_success(self, client, auth_header):
        with patch(f"{_MOD}.upsert_user_notification_preferences") as mock_upsert:
            mock_upsert.return_value = {
                "failed_runs": False,
                "fix_generated": True,
                "weekly_report": True,
            }
            response = client.post(
                "/v1/user/notification-preferences",
                json={
                    "failed_runs": False,
                    "fix_generated": True,
                    "weekly_report": True,
                },
                headers=auth_header,
            )
            assert response.status_code == 200
            data = response.json()
            assert data["failed_runs"] is False
            assert data["weekly_report"] is True
            mock_upsert.assert_called_once()

    def test_update_prefs_unauthorized(self, client):
        response = client.post(
            "/v1/user/notification-preferences",
            json={"failed_runs": False},
        )
        assert response.status_code == 401


class TestGetApiKey:
    """Tests for GET /v1/user/api-key."""

    def test_get_api_key_existing(self, client, auth_header):
        with patch(f"{_MOD}.get_user_api_key") as mock_get:
            mock_get.return_value = {
                "key_prefix": "hf_sk_",
                "key_suffix": "7890",
                "created_at": "2025-01-15T10:00:00Z",
            }
            response = client.get("/v1/user/api-key", headers=auth_header)
            assert response.status_code == 200
            data = response.json()
            assert "api_key" in data
            assert "****" in data["api_key"]
            assert "created_at" in data

    def test_get_api_key_auto_create(self, client, auth_header):
        with patch(f"{_MOD}.get_user_api_key") as mock_get, \
             patch(f"{_MOD}.create_or_regenerate_api_key") as mock_create:
            mock_get.return_value = None
            mock_create.return_value = {
                "api_key": "hf_sk_full_key_here",
                "key_prefix": "hf_sk_",
                "key_suffix": "here",
                "created_at": "2025-01-15T10:00:00Z",
            }
            response = client.get("/v1/user/api-key", headers=auth_header)
            assert response.status_code == 200
            data = response.json()
            assert "****" in data["api_key"]

    def test_get_api_key_unauthorized(self, client):
        response = client.get("/v1/user/api-key")
        assert response.status_code == 401


class TestRegenerateApiKey:
    """Tests for POST /v1/user/api-key."""

    def test_regenerate_api_key_success(self, client, auth_header):
        with patch(f"{_MOD}.create_or_regenerate_api_key") as mock_regen:
            mock_regen.return_value = {
                "api_key": "hf_sk_new_full_key_12345",
                "created_at": "2025-01-15T12:00:00Z",
            }
            response = client.post("/v1/user/api-key", headers=auth_header)
            assert response.status_code == 200
            data = response.json()
            assert data["api_key"] == "hf_sk_new_full_key_12345"
            assert "message" in data

    def test_regenerate_api_key_unauthorized(self, client):
        response = client.post("/v1/user/api-key")
        assert response.status_code == 401
