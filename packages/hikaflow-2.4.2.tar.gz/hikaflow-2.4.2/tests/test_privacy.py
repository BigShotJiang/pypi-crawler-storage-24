from worker.privacy import detect_pii


def test_detect_pii_email():
    payload = {"message": "Contact me at user@example.com"}
    found, hits = detect_pii(payload)
    assert found is True
    assert any(hit["type"] == "email" for hit in hits)


def test_detect_pii_credit_card():
    payload = {"card": "4111 1111 1111 1111"}
    found, hits = detect_pii(payload)
    assert found is True
    assert any(hit["type"] == "credit_card" for hit in hits)


def test_no_pii():
    payload = {"message": "hello world", "meta": {"count": 3}}
    found, hits = detect_pii(payload)
    assert found is False
    assert hits == []
