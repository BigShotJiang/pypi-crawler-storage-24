from autodebug_probe.canonicalize import body_hash, canonical_url


def test_canonical_url_sorts_query():
    url = "https://example.com/path?b=2&a=1"
    assert canonical_url(url) == "https://example.com/path?a=1&b=2"


def test_body_hash_json_canonical():
    body = b'{"b":2,"a":1}'
    hashed = body_hash(body, "application/json")
    hashed_again = body_hash(b'{"a":1,"b":2}', "application/json")
    assert hashed == hashed_again
