from __future__ import annotations

from autodebug.agent import sdk_bridge
from autodebug.agent.tools import register_hikaflow_tools


class _FakeAgent:
    def __init__(self):
        self._function_tools = {}

    def tool(self, fn):
        self._function_tools[fn.__name__] = type("Tool", (), {"function": fn})()
        return fn


_COMPACT_EXPECTED = {
    "incident_overview",
    "failure_similarity_search",
    "review_files",
    "run_tests",
    "update_findings",
    "knowledge_memory",
}


def test_compact_schema_coverage_for_all_6_tools():
    fake = _FakeAgent()
    register_hikaflow_tools(fake)
    sdk_bridge.populate_registry_from_agent(fake, profile="compact")
    entries = {name: schema for name, _func, _desc, schema in sdk_bridge._TOOL_REGISTRY}

    assert set(entries.keys()) == _COMPACT_EXPECTED
    for tool_name in _COMPACT_EXPECTED:
        schema = entries[tool_name]
        assert isinstance(schema, dict), f"{tool_name} missing schema"
        assert schema.get("type") == "object", f"{tool_name} schema must be object"
        assert isinstance(schema.get("properties", {}), dict), f"{tool_name} schema properties missing"
        assert schema["properties"], f"{tool_name} schema properties empty"
