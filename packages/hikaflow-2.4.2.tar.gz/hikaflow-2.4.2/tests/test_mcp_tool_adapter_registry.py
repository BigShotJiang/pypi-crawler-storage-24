from __future__ import annotations

from autodebug.agent import sdk_bridge as _sdk_bridge
from mcp_server.adapters import ADAPTER_SPECS


def test_adapter_registry_has_all_12_compact_tools():
    expected = {
        "incident_overview",
        "failure_similarity_search",
        "generate_fix_candidates",
        "validate_fix_candidate",
        "create_fix_pr",
        "quarantine_control",
        "codebase_scan",
        "review_files",
        "run_tests",
        "update_findings",
        "knowledge_memory",
        "project_health_snapshot",
    }
    assert set(ADAPTER_SPECS.keys()) == expected


def test_adapter_contracts_exist():
    for spec in ADAPTER_SPECS.values():
        assert spec.contract_path.exists(), f"missing contract for {spec.tool_name}: {spec.contract_path}"


def test_adapter_flags_use_enable_mcp_prefix():
    for spec in ADAPTER_SPECS.values():
        assert spec.feature_flag.startswith("ENABLE_MCP_")


def test_sdk_bridge_contract_dir_exists():
    assert _sdk_bridge._PHASE2_CONTRACT_DIR.exists()
