from __future__ import annotations

import importlib.util
import sys
from pathlib import Path


def _load_module():
    root = Path(__file__).resolve().parent.parent
    mod_path = root / "scripts" / "run_eval_harness.py"
    spec = importlib.util.spec_from_file_location("run_eval_harness", mod_path)
    assert spec is not None and spec.loader is not None
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def test_parse_junit_single_testsuite(tmp_path: Path):
    mod = _load_module()
    xml = tmp_path / "junit.xml"
    xml.write_text(
        '<testsuite tests="5" failures="1" errors="0" skipped="2"></testsuite>',
        encoding="utf-8",
    )

    total, failures, errors, skipped = mod._parse_junit(xml)
    assert total == 5
    assert failures == 1
    assert errors == 0
    assert skipped == 2


def test_parse_junit_testsuites_aggregate(tmp_path: Path):
    mod = _load_module()
    xml = tmp_path / "junit.xml"
    xml.write_text(
        (
            '<testsuites>'
            '<testsuite tests="3" failures="1" errors="0" skipped="0"></testsuite>'
            '<testsuite tests="2" failures="0" errors="1" skipped="1"></testsuite>'
            '</testsuites>'
        ),
        encoding="utf-8",
    )

    total, failures, errors, skipped = mod._parse_junit(xml)
    assert total == 5
    assert failures == 1
    assert errors == 1
    assert skipped == 1


def test_load_config_requires_suites(tmp_path: Path):
    mod = _load_module()
    cfg = tmp_path / "cfg.json"
    cfg.write_text('{"suites": []}', encoding="utf-8")
    loaded = mod._load_config(cfg)
    assert loaded["suites"] == []


def test_suite_threshold_uses_profile_thresholds(tmp_path: Path):
    mod = _load_module()
    suite = {
        "name": "x",
        "thresholds": {"commit": 0.9, "stretch": 1.0},
        "min_pass_rate": 0.5,
    }
    assert mod._suite_threshold(suite, "commit") == 0.9
    assert mod._suite_threshold(suite, "stretch") == 1.0


def test_suite_threshold_falls_back_to_min_pass_rate(tmp_path: Path):
    mod = _load_module()
    suite = {"name": "x", "min_pass_rate": 0.85}
    assert mod._suite_threshold(suite, "commit") == 0.85
