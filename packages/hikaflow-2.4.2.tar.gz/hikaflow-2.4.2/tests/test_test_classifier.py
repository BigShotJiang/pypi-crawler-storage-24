"""Tests for the test classifier module."""

import pytest

from autodebug.healing.test_classifier import (
    NEVER_HEAL_TYPES,
    TestClassifier,
    TestType,
)


@pytest.fixture
def classifier():
    return TestClassifier()


class TestTestClassifier:
    """Test classification by name, path, and code."""

    def test_performance_by_name(self, classifier):
        assert classifier.classify("test_benchmark_sort") == TestType.PERFORMANCE

    def test_performance_by_path(self, classifier):
        assert classifier.classify("test_something", "tests/perf/test_load.py") == TestType.PERFORMANCE

    def test_security_by_name(self, classifier):
        assert classifier.classify("test_xss_prevention") == TestType.SECURITY

    def test_security_by_path(self, classifier):
        assert classifier.classify("test_login", "tests/security/test_auth.py") == TestType.SECURITY

    def test_property_based_by_name(self, classifier):
        assert classifier.classify("test_hypothesis_sorting") == TestType.PROPERTY_BASED

    def test_property_based_by_code(self, classifier):
        code = '''
@given(st.lists(st.integers()))
def test_sort_idempotent(xs):
    assert sorted(sorted(xs)) == sorted(xs)
'''
        assert classifier.classify("test_sort", test_code=code) == TestType.PROPERTY_BASED

    def test_e2e_by_name(self, classifier):
        assert classifier.classify("test_e2e_checkout_flow") == TestType.END_TO_END

    def test_integration_by_name(self, classifier):
        assert classifier.classify("test_integration_db") == TestType.INTEGRATION

    def test_snapshot_by_code(self, classifier):
        code = 'expect(component).toMatchSnapshot();'
        assert classifier.classify("test_render", test_code=code) == TestType.SNAPSHOT

    def test_unknown_by_default(self, classifier):
        assert classifier.classify("test_add_numbers") == TestType.UNKNOWN

    def test_code_markers_take_priority(self, classifier):
        """Code markers should override name patterns."""
        code = '''
@given(st.integers())
def test_benchmark_property(x):
    assert x == x
'''
        # Name says "benchmark" (PERFORMANCE), but code says @given (PROPERTY_BASED)
        result = classifier.classify("test_benchmark_property", test_code=code)
        assert result == TestType.PROPERTY_BASED


class TestShouldHeal:
    """Test healing eligibility."""

    def test_unit_test_can_heal(self, classifier):
        assert classifier.should_heal(TestType.UNIT) is True

    def test_integration_test_can_heal(self, classifier):
        assert classifier.should_heal(TestType.INTEGRATION) is True

    def test_performance_test_cannot_heal(self, classifier):
        assert classifier.should_heal(TestType.PERFORMANCE) is False

    def test_security_test_cannot_heal(self, classifier):
        assert classifier.should_heal(TestType.SECURITY) is False

    def test_property_based_test_cannot_heal(self, classifier):
        assert classifier.should_heal(TestType.PROPERTY_BASED) is False

    def test_unknown_test_can_heal(self, classifier):
        assert classifier.should_heal(TestType.UNKNOWN) is True


class TestNeverHealTypes:
    """Test the NEVER_HEAL_TYPES constant."""

    def test_contains_performance(self):
        assert TestType.PERFORMANCE in NEVER_HEAL_TYPES

    def test_contains_security(self):
        assert TestType.SECURITY in NEVER_HEAL_TYPES

    def test_contains_property_based(self):
        assert TestType.PROPERTY_BASED in NEVER_HEAL_TYPES

    def test_does_not_contain_unit(self):
        assert TestType.UNIT not in NEVER_HEAL_TYPES
