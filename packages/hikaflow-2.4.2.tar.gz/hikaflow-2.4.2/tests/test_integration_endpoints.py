"""Tests for Slack and Linear integration endpoints."""

from unittest.mock import AsyncMock, MagicMock, patch


class TestSlackWebhookTest:
    """Tests for POST /v1/integrations/slack/test."""

    def test_test_slack_success(self, client, auth_header):
        with patch("api.integrations.slack.SlackNotifier") as mock_notifier_cls:
            mock_notifier = MagicMock()
            mock_notifier.send_webhook = AsyncMock(return_value=True)
            mock_notifier_cls.return_value = mock_notifier
            response = client.post(
                "/v1/integrations/slack/test",
                json={
                    "webhook_url": "https://hooks.slack.com/services/test",
                    "message_type": "test",
                },
                headers=auth_header,
            )
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True

    def test_test_slack_failure(self, client, auth_header):
        with patch("api.integrations.slack.SlackNotifier") as mock_notifier_cls:
            mock_notifier = MagicMock()
            mock_notifier.send_webhook = AsyncMock(return_value=False)
            mock_notifier_cls.return_value = mock_notifier
            response = client.post(
                "/v1/integrations/slack/test",
                json={
                    "webhook_url": "https://hooks.slack.com/services/test",
                    "message_type": "test",
                },
                headers=auth_header,
            )
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is False

    def test_test_slack_unauthorized(self, client):
        response = client.post(
            "/v1/integrations/slack/test",
            json={"webhook_url": "https://hooks.slack.com/test"},
        )
        assert response.status_code == 401


class TestSlackSendNotification:
    """Tests for POST /v1/integrations/slack/send."""

    def test_send_flaky_alert(self, client, auth_header):
        with patch("api.integrations.slack.SlackNotifier") as mock_notifier_cls:
            mock_notifier = MagicMock()
            mock_notifier.build_flaky_alert_message = MagicMock(
                return_value=MagicMock(),
            )
            mock_notifier.send_webhook = AsyncMock(return_value=True)
            mock_notifier_cls.return_value = mock_notifier
            response = client.post(
                "/v1/integrations/slack/send",
                json={
                    "webhook_url": "https://hooks.slack.com/services/test",
                    "test_name": "test_login",
                    "project_name": "my-project",
                    "notification_type": "flaky_alert",
                    "flake_rate": 0.5,
                    "recent_failures": 10,
                },
                headers=auth_header,
            )
            assert response.status_code == 200

    def test_send_unknown_type(self, client, auth_header):
        with patch("api.integrations.slack.SlackNotifier"):
            response = client.post(
                "/v1/integrations/slack/send",
                json={
                    "webhook_url": "https://hooks.slack.com/services/test",
                    "test_name": "test_login",
                    "project_name": "my-project",
                    "notification_type": "unknown_type",
                },
                headers=auth_header,
            )
            assert response.status_code == 400

    def test_send_unauthorized(self, client):
        response = client.post(
            "/v1/integrations/slack/send",
            json={
                "webhook_url": "https://hooks.slack.com/test",
                "test_name": "test",
                "project_name": "proj",
                "notification_type": "test_failure",
            },
        )
        assert response.status_code == 401


class TestLinearTest:
    """Tests for POST /v1/integrations/linear/test."""

    def test_test_linear_success(self, client, auth_header):
        with patch("api.integrations.linear.LinearIntegration") as mock_int_cls:
            mock_int = MagicMock()
            mock_client = MagicMock()
            mock_int._get_client.return_value = mock_client
            mock_int_cls.return_value = mock_int
            response = client.post(
                "/v1/integrations/linear/test",
                json={"team_id": "team_123"},
                headers={
                    **auth_header,
                    "X-Linear-Api-Key": "lin_api_test_key",
                },
            )
            assert response.status_code == 200
            data = response.json()
            assert data["success"] is True

    def test_test_linear_no_api_key(self, client, auth_header):
        response = client.post(
            "/v1/integrations/linear/test",
            json={"team_id": "team_123"},
            headers=auth_header,
        )
        assert response.status_code == 422

    def test_test_linear_unauthorized(self, client):
        response = client.post(
            "/v1/integrations/linear/test",
            json={"team_id": "team_123"},
            headers={"X-Linear-Api-Key": "lin_api_test_key"},
        )
        assert response.status_code == 401


class TestLinearCreateIssue:
    """Tests for POST /v1/integrations/linear/issues."""

    def test_create_issue_success(self, client, auth_header):
        with patch("api.integrations.linear.LinearIntegration") as mock_int_cls:
            mock_int = MagicMock()
            mock_int.build_flaky_test_issue.return_value = (
                "Flaky: test_login",
                "Description of the issue",
            )
            mock_issue = MagicMock(
                id="issue_1", identifier="ENG-123",
                title="Flaky: test_login", url="https://linear.app/issue/ENG-123",
            )
            mock_int.create_issue = AsyncMock(return_value=mock_issue)
            mock_int_cls.return_value = mock_int
            response = client.post(
                "/v1/integrations/linear/issues",
                json={
                    "team_id": "team_123",
                    "test_name": "test_login",
                    "project_name": "my-project",
                    "flake_rate": 0.5,
                    "recent_failures": 10,
                },
                headers={
                    **auth_header,
                    "X-Linear-Api-Key": "lin_api_test_key",
                },
            )
            assert response.status_code == 200
            data = response.json()
            assert data["identifier"] == "ENG-123"

    def test_create_issue_unauthorized(self, client):
        response = client.post(
            "/v1/integrations/linear/issues",
            json={
                "team_id": "team_123",
                "test_name": "test_login",
                "project_name": "proj",
                "flake_rate": 0.5,
                "recent_failures": 5,
            },
            headers={"X-Linear-Api-Key": "lin_api_test_key"},
        )
        assert response.status_code == 401
