from autodebug.agent.tools import _extract_json_object


def test_extract_json_object_from_clean_json():
    payload = '{"results": [{"path": "a.py"}]}'
    result = _extract_json_object(payload)
    assert result is not None
    assert len(result["results"]) == 1


def test_extract_json_object_from_prefixed_logs():
    payload = "INFO: scanning repo\n{\"results\": [{\"path\": \"a.py\"}], \"errors\": []}"
    result = _extract_json_object(payload)
    assert result is not None
    assert result["results"][0]["path"] == "a.py"


def test_extract_json_object_returns_none_for_non_json():
    assert _extract_json_object("not json at all") is None


def test_extract_json_object_ignores_json_arrays():
    # Semgrep payloads are expected to be objects with a top-level "results" key.
    payload = '[{"not": "semgrep-format"}]'
    assert _extract_json_object(payload) is None
