"""Tests for OpenClaw evaluation helpers."""

from __future__ import annotations

import json

from autodebug.openclaw_eval import (
    build_openclaw_command,
    build_openclaw_prompt,
    parse_openclaw_output,
)


def test_build_openclaw_command_local_with_model() -> None:
    cmd = build_openclaw_command(
        "hello",
        model="openai/gpt-5.2",
        timeout_seconds=99,
        local=True,
    )
    assert cmd == [
        "openclaw",
        "agent",
        "--message",
        "hello",
        "--json",
        "--timeout",
        "99",
        "--local",
        "--model",
        "openai/gpt-5.2",
    ]


def test_build_openclaw_prompt_contains_required_schema_keys() -> None:
    prompt = build_openclaw_prompt({"run_id": "abc", "entry_cmd": ["pytest"]})
    for key in ("summary", "gaps", "improvements", "next_tests", "priority"):
        assert f'"{key}"' in prompt
    assert "run_id" in prompt


def test_parse_openclaw_output_with_reply_text_json() -> None:
    payload = {
        "summary": "Looks flaky",
        "gaps": ["No retry tests"],
        "improvements": ["Add deterministic seed checks"],
        "next_tests": ["Add integration test for replay timeout"],
        "priority": "high",
    }
    envelope = {"reply": {"text": json.dumps(payload)}}
    outer = json.dumps(envelope)

    parsed_envelope, parsed_payload = parse_openclaw_output(outer)
    assert parsed_envelope["reply"]["text"]
    assert parsed_payload == payload


def test_parse_openclaw_output_accepts_direct_payload() -> None:
    payload = {
        "summary": "ok",
        "gaps": [],
        "improvements": [],
        "next_tests": [],
        "priority": "low",
    }
    parsed_envelope, parsed_payload = parse_openclaw_output(json.dumps(payload))
    assert parsed_envelope == payload
    assert parsed_payload == payload
