from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


def test_phase5_compare_passes_with_improving_metrics(tmp_path: Path):
    before = {
        "scan": {
            "api_failures_per_run": 0.4,
            "semgrep_error_rate_per_run": 0.3,
            "fidelity_full_rate": 0.4,
            "confidence_high_rate": 0.4,
        },
        "agent": {"completion_rate": 0.5, "give_up_rate": 0.3},
        "replay": {"divergence_rate": 0.4},
    }
    after = {
        "scan": {
            "api_failures_per_run": 0.2,
            "semgrep_error_rate_per_run": 0.1,
            "fidelity_full_rate": 0.7,
            "confidence_high_rate": 0.7,
        },
        "agent": {"completion_rate": 0.6, "give_up_rate": 0.2},
        "replay": {"divergence_rate": 0.2},
    }
    before_path = tmp_path / "before.json"
    after_path = tmp_path / "after.json"
    before_path.write_text(json.dumps(before), encoding="utf-8")
    after_path.write_text(json.dumps(after), encoding="utf-8")

    result = subprocess.run(
        [
            sys.executable,
            "scripts/phase5_rollout.py",
            "compare",
            "--before",
            str(before_path),
            "--after",
            str(after_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0
    assert "Phase 5 KPI Delta" in result.stdout
    assert "RESULT: PASS" in result.stdout


def test_phase5_compare_fails_with_regressing_metrics(tmp_path: Path):
    before = {
        "scan": {
            "api_failures_per_run": 0.1,
            "semgrep_error_rate_per_run": 0.1,
            "fidelity_full_rate": 0.8,
            "confidence_high_rate": 0.8,
        },
        "agent": {"completion_rate": 0.7, "give_up_rate": 0.1},
        "replay": {"divergence_rate": 0.1},
    }
    after = {
        "scan": {
            "api_failures_per_run": 0.4,
            "semgrep_error_rate_per_run": 0.5,
            "fidelity_full_rate": 0.3,
            "confidence_high_rate": 0.3,
        },
        "agent": {"completion_rate": 0.5, "give_up_rate": 0.4},
        "replay": {"divergence_rate": 0.4},
    }
    before_path = tmp_path / "before.json"
    after_path = tmp_path / "after.json"
    before_path.write_text(json.dumps(before), encoding="utf-8")
    after_path.write_text(json.dumps(after), encoding="utf-8")

    result = subprocess.run(
        [
            sys.executable,
            "scripts/phase5_rollout.py",
            "compare",
            "--before",
            str(before_path),
            "--after",
            str(after_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 1
    assert "RESULT: FAIL" in result.stdout


def test_phase5_check_endpoints_requires_api_and_token():
    result = subprocess.run(
        [sys.executable, "scripts/phase5_rollout.py", "check-endpoints"],
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 2
    assert "--api-base and --token are required" in result.stdout
