from __future__ import annotations

import json
import subprocess
import sys


def test_report_reliability_delta_outputs_expected_rows(tmp_path):
    before = {
        "scan": {
            "api_failures_per_run": 0.6,
            "semgrep_error_rate_per_run": 0.4,
            "fidelity_full_rate": 0.4,
            "confidence_high_rate": 0.4,
        },
        "agent": {"completion_rate": 0.5, "give_up_rate": 0.3},
        "replay": {"divergence_rate": 0.4},
    }
    after = {
        "scan": {
            "api_failures_per_run": 0.3,
            "semgrep_error_rate_per_run": 0.2,
            "fidelity_full_rate": 0.7,
            "confidence_high_rate": 0.7,
        },
        "agent": {"completion_rate": 0.65, "give_up_rate": 0.2},
        "replay": {"divergence_rate": 0.25},
    }

    before_path = tmp_path / "before.json"
    after_path = tmp_path / "after.json"
    before_path.write_text(json.dumps(before), encoding="utf-8")
    after_path.write_text(json.dumps(after), encoding="utf-8")

    result = subprocess.run(
        [
            sys.executable,
            "scripts/report_reliability_delta.py",
            "--before",
            str(before_path),
            "--after",
            str(after_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0
    assert "scan.api_failures_per_run" in result.stdout
    assert "agent.completion_rate" in result.stdout
    assert "replay.divergence_rate" in result.stdout


def test_report_reliability_delta_missing_file_returns_clean_error(tmp_path):
    before_path = tmp_path / "missing-before.json"
    after_path = tmp_path / "missing-after.json"

    result = subprocess.run(
        [
            sys.executable,
            "scripts/report_reliability_delta.py",
            "--before",
            str(before_path),
            "--after",
            str(after_path),
        ],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 2
    assert "Snapshot file not found" in result.stdout
