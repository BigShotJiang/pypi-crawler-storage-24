# Hikaflow

**Find and fix bugs in Python and TypeScript with one command.**

Hikaflow scans your code with 8 engines (Ruff, Bandit, Semgrep, mypy, ESLint, Vulture, npm audit, AST), finds real bugs, and fixes them with AI — syntax-checked and linted before applying.

```bash
pip install hikaflow
hikaflow scan
```

No config needed. No login required for scanning.

## What it finds

- Security vulnerabilities (SQL injection, XSS, hardcoded secrets, eval usage)
- Type errors (wrong argument types, None dereference, missing attributes)
- Bugs (missing await, unchecked None, loose equality, empty catch blocks)
- Dead code and unused imports
- Dependency vulnerabilities (pip-audit, npm audit)
- Code smells (bare except, mutable defaults, type coercion)

## Quick start

### Scan your project

```bash
cd your-project
hikaflow scan
```

Output:

```
Scanning 142 files...

 CRITICAL  api/auth.py:47       SQL injection via string formatting
 HIGH      payments.ts:23       Missing await on async call
 HIGH      app.tsx:91           User input in dangerouslySetInnerHTML
 MEDIUM    utils.py:12          Bare except clause hides errors
 LOW       config.py:8          Unused import: os

Found 5 issues (1 critical, 2 high, 1 medium, 1 low)
```

### Fix issues with AI

```bash
hikaflow scan --fix
```

Select issues with arrow keys, preview the diff, and apply. Fixes are syntax-checked and linted before applying.

### Fix everything at once

```bash
hikaflow scan --fix-all
```

### Only scan changed files

```bash
hikaflow scan --changed
```

### Generate an HTML report

```bash
hikaflow scan --html report.html
```

## Supported languages

| Language | Engines |
|----------|---------|
| Python | Ruff, Bandit, Semgrep, mypy, Vulture, pip-audit, 13 AST specialists |
| TypeScript / JavaScript | ESLint, Semgrep, npm audit, 6 tree-sitter specialists |

## Configuration

Create `.hikaflow.yml` in your project root to suppress rules or paths:

```yaml
ignore_rules:
  - hardcoded-secret    # Suppress specific rules
  - unused-import

ignore_paths:
  - "vendor/*"          # Skip vendored code
  - "*.test.ts"         # Skip test files
  - "migrations/*"
```

## CI integration

```bash
hikaflow ci-setup
```

This generates:
- `.github/workflows/hikaflow.yml` — GitHub Action that runs on every PR
- `.hikaflow.yml` — default config
- Pre-commit hook (optional)

Or add manually to your workflow:

```yaml
- name: Install Hikaflow
  run: pip install hikaflow

- name: Scan for bugs
  run: hikaflow scan --json > hikaflow-results.json

- name: Fail on critical issues
  run: hikaflow scan --exit-code
```

## AI fixes (free tier)

Scanning is free and unlimited. AI fixes require a free account:

```bash
hikaflow login
hikaflow scan --fix
```

| Plan | AI fixes / month | Price |
|------|-----------------|-------|
| Free | 5 | $0 |
| Pro | 100 | $19/mo |
| Team | 1,000 | $49/mo |

Sign up at [debug.hikaflow.com](https://debug.hikaflow.com).

## Commands

| Command | Description |
|---------|-------------|
| `hikaflow scan` | Scan code for bugs and security issues |
| `hikaflow scan --fix` | Interactive AI fix mode |
| `hikaflow scan --fix-all` | Fix all issues automatically |
| `hikaflow scan --changed` | Only scan git-changed files |
| `hikaflow scan --html out.html` | Generate HTML report |
| `hikaflow ci-setup` | Generate CI config and pre-commit hooks |
| `hikaflow login` | Authenticate (required for AI fixes) |
| `hikaflow doctor` | Check environment and dependencies |

## Requirements

- Python 3.9+
- Node.js (optional, for ESLint/npm audit on JS/TS projects)

## Links

- [Website](https://debug.hikaflow.com)
- [PyPI](https://pypi.org/project/hikaflow/)
- [Issues](https://github.com/hikaflow-debug/hikaflow-debugger/issues)

## License

Proprietary - All rights reserved.
