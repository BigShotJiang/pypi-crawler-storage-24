from fastapi import FastAPI
from cachemind.core.cache import CacheMind

app = FastAPI()

cache = CacheMind()

@app.post("/query")
def query(q: str):
    return {"response": cache.query(q)}

@app.get("/metrics")
def get_metrics():
    return cache.metrics.get_stats()