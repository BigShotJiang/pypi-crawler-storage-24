import requests
import time


BASE_URL = "http://127.0.0.1:8000"

test_queries = [
    "What is artificial intelligence?",
    "Explain AI",
    "Define machine learning",
    "What is ML?",
    "What is deep learning?",
    "Explain neural networks",
    "How is AI different from ML?",
    "What is artificial intelligence?",
    "Explain AI again",   
]

def run_tests():
    print("Running Tests for CacheMind...\n")

    for i, query in enumerate(test_queries):
        print(f"Test {i+1}: {query}")

        response = requests.post(
            f"{BASE_URL}/query",
            params={"q": query}
        )

        print("Response:", response.json()["response"])
        print("-" * 50)

        time.sleep(0.5)

    print("\n📊 Fetching Metrics...\n")

    metrics = requests.get(f"{BASE_URL}/metrics").json()
    print(metrics)


if __name__ == "__main__":
    run_tests()