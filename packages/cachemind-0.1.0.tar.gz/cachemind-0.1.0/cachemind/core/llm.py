class DummyLLM:
    def generate(self, query: str):
        return f"LLM response: {query}"