class CachePolicy:
    def __init__(self, threshold=0.8):
        self.threshold= threshold
        self.history= []

    def should_hit(self, similarity):
        if similarity is None:
            return False

        self.history.append(similarity)

        return similarity > self.threshold

    def adjust_threshold(self, hit_rate):
        # if too few hits, then lower threshold
        if hit_rate < 0.3:
            self.threshold-= 0.02

        # if too many hits, then increase threshold
        elif hit_rate > 0.7:
            self.threshold+= 0.02

        self.threshold= max(0.6, min(0.95, self.threshold))