class Metrics:
    def __init__(self):
        self.total_queries= 0
        self.cache_hits= 0
        self.cache_misses= 0
        self.tokens_saved= 0
        self.tokens_used= 0

    def log_hit(self, tokens=0):
        self.total_queries+= 1
        self.cache_hits+= 1
        self.tokens_saved+= tokens

    def log_miss(self, tokens=0):
        self.total_queries+= 1
        self.cache_misses+= 1
        self.tokens_used+= tokens

    def get_stats(self):
        hit_rate = (
            self.cache_hits / self.total_queries
            if self.total_queries > 0 else 0
        )

        return {
            "total_queries": self.total_queries,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "hit_rate": round(hit_rate, 2),
            "tokens_saved": self.tokens_saved,
            "tokens_used": self.tokens_used
        }