from .embeddings import EmbeddingModel
from .vector_store import VectorStore
from .policy import CachePolicy


def resolve_embedding(embedding):
    if embedding is None:
        return EmbeddingModel()

    if not hasattr(embedding, "encode"):
        raise TypeError("Embedding must have an 'encode(text)' method")

    return embedding


def resolve_vector_store(store):
    if store is None:
        return VectorStore()

    if not hasattr(store, "search") or not hasattr(store, "add"):
        raise TypeError("Vector store must implement 'search' and 'add'")

    return store


def resolve_policy(policy, threshold):
    if policy is None:
        return CachePolicy(threshold=threshold)

    if not hasattr(policy, "should_hit"):
        raise TypeError("Policy must implement 'should_hit(similarity)'")

    return policy