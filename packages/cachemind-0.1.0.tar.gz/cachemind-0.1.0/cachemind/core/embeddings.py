from sentence_transformers import SentenceTransformer
import numpy as np


class EmbeddingModel:
    def __init__(self):
        self.model= SentenceTransformer('all-MiniLM-L6-v2')

    def encode(self, text: str):
        emb= self.model.encode(text)
        return emb / np.linalg.norm(emb)