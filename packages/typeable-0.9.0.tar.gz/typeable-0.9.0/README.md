# Typeable: A Python type casting at runtime

Cast a value to a type.

`typeable.typecast` provides an extensible runtime implementation of `typing.cast`. 
**`typecast(T, v)`** returns the value obtained by recursively converting `v` to type `T`.
This process performs validation and conversion. 
The principle is to support standard library and user-defined types as-is.
It does not force the use of a specific base class.
In other words, it adheres to the principle of **non-interference**.

This can also be applied to function calls. 
**`typecast.apply(f, v)`** performs a function call roughly equivalent to `f(**v)`. 
It performs validation and conversion on all annotated arguments before the call.

Too simple? 
Yes, that's my goal.

The code is currently at the alpha stage. 
Although `typeable.typecast` understands and casts generic types, it is still lacking in consistency and completeness.

Typeable requires Python 3.10+.

Installation:

```
pip install typeable
```

## Supported Types

The list below summarizes the `T` types supported by `typecast(T, v)`.
Generic types are denoted by `[]`.
`@` denotes types with the specified decoration applied.
This list is non-exhaustive.

- `bool`
- `bytearray`
- `bytes`
- `complex`
- `dict`
- `dict[]`
- `float`
- `frozenset`
- `frozenset[]`
- `int`
- `list`
- `list[]`
- `object`
- `set`
- `set[]`
- `str`
- `tuple`
- `tuple[]`
- `type`
- `type[]`
- `collections.Counter`
- `collections.Counter[]`
- `collections.defaultdict`
- `collections.defaultdict[]`
- `collections.namedtuple`
- `collections.OrderedDict`
- `collections.OrderedDict[]`
- `collections.abc.Callable`
- `collections.abc.Callable[]`
- `@dataclasses.dataclass`
- `datetime.date`
- `datetime.datetime`
- `datetime.time`
- `datetime.timedelta`
- `enum.Enum`
- `enum.Flag`
- `enum.IntEnum`
- `enum.IntFlag`
- `typeable.JsonValue`
- `types.NoneType`
- `typing.Annotated[]`
- `typing.Any`
- `typing.Callable`
- `typing.Callable[]`
- `typing.Counter`
- `typing.Counter[]`
- `typing.DefaultDict`
- `typing.DefaultDict[]`
- `typing.Dict`
- `typing.Dict[]`
- `typing.FrozenSet`
- `typing.FrozenSet[]`
- `typing.List`
- `typing.List[]`
- `typing.Literal[]`
- `typing.NamedTuple`
- `typing.Optional[]`
- `typing.OrderedDict`
- `typing.OrderedDict[]`
- `typing.Set`
- `typing.Set[]`
- `typing.Tuple`
- `typing.Tuple[]`
- `typing.Type`
- `typing.Type[]`
- `typing.TypedDict`
- `typing.Union[]`
