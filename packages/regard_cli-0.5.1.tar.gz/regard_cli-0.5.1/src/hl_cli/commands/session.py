"""Session commands — context management and trading analysis.

Reads Claude Code session transcripts (~/.claude/projects/<encoded-cwd>/*.jsonl),
extracts trades, research chains, tilt signals, and session context.

Commands: gm, gg, cope, pnl, tilt, what
"""

import json
import os
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import List, Optional

import typer

session_app = typer.Typer(
    name="session",
    no_args_is_help=True,
    help="Session commands — context management and trading analysis.",
)


# --- Session discovery ---

UUID_RE = re.compile(r'^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.jsonl$')


def _get_session_base_path():
    """Derive session directory from CWD."""
    cwd = os.getcwd()
    encoded = cwd.replace("/", "-")
    session_dir = Path.home() / ".claude" / "projects" / encoded
    return str(session_dir) if session_dir.is_dir() else None


def _find_session_files(base_path):
    """Session JSONL files sorted by modification time, newest first."""
    try:
        files = [
            os.path.join(base_path, f) for f in os.listdir(base_path)
            if UUID_RE.match(f)
        ]
    except OSError:
        return []
    files.sort(key=lambda f: os.path.getmtime(f), reverse=True)
    return files


# --- Entry parsing ---

def _extract_entries(filepath):
    """Parse session JSONL into (timestamp, role, text) tuples.

    Roles: U=user, A=assistant, T=tool_use, R=tool_result
    """
    entries = []
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                    ts = e.get("timestamp", "")
                    t = e.get("type")

                    if t == "user":
                        c = e.get("message", {}).get("content", "")
                        if isinstance(c, str) and c.strip():
                            if "<command-name>" not in c[:50]:
                                entries.append((ts, "U", c))
                        elif isinstance(c, list):
                            for item in c:
                                if item.get("type") == "text":
                                    entries.append((ts, "U", item.get("text", "")))
                                elif item.get("type") == "tool_result":
                                    content = item.get("content", "")
                                    if isinstance(content, list):
                                        content = " ".join(
                                            b.get("text", str(b)) if isinstance(b, dict) else str(b)
                                            for b in content
                                        )
                                    entries.append((ts, "R", content))

                    elif t == "assistant":
                        for b in e.get("message", {}).get("content", []) or []:
                            if b.get("type") == "text":
                                entries.append((ts, "A", b.get("text", "")))
                            elif b.get("type") == "tool_use":
                                n = b.get("name", "")
                                inp = json.dumps(b.get("input", {}))
                                entries.append((ts, "T", f"{n}: {inp}"))
                except (json.JSONDecodeError, KeyError):
                    pass
    except (OSError, IOError):
        pass
    return entries


def _load_entries(session_files, max_sessions=5):
    """Load and merge entries from multiple session files."""
    all_entries = []
    for sf in session_files[:max_sessions]:
        all_entries.extend(_extract_entries(sf))
    all_entries.sort(key=lambda x: x[0])
    return all_entries


# --- Trade & research extraction ---

RESEARCH_SKILLS = frozenset({
    'chans-research', 'discord-research', 'dune', 'x',
    'substack-research', 'telegram-research', 'reddit-chainstack',
    'search-obsidian', 'youtube-transcript',
})


def _extract_hl_command(text):
    """Extract regard hl command string from a Bash tool call entry."""
    m = re.search(r'"command":\s*"(regard hl [^"]+)"', text)
    return m.group(1) if m else None


def _is_hl_order(text):
    return text.startswith("Bash:") and '"regard hl order' in text


def _parse_hl_order(cmd):
    """Parse 'regard hl order ASSET SIDE SIZE [PRICE] [--flags]' into dict."""
    parts = cmd.split()
    if len(parts) < 6:
        return None
    # regard=0, hl=1, order=2, ASSET=3, SIDE=4, SIZE=5
    return {
        'asset': parts[3],
        'side': parts[4],
        'size': parts[5],
        'price': parts[6] if len(parts) > 6 and not parts[6].startswith('--') else None,
        'market': '--market' in cmd,
        'reduce_only': '--reduce-only' in cmd,
    }


def _extract_trades(entries):
    """Find all regard hl order calls with their results."""
    trades = []
    for i, (ts, role, text) in enumerate(entries):
        if role != "T" or not _is_hl_order(text):
            continue
        cmd = _extract_hl_command(text)
        if not cmd:
            continue
        info = _parse_hl_order(cmd)
        if not info:
            continue
        info['timestamp'] = ts
        info['index'] = i
        info['raw'] = cmd
        # Find result (next R entry within 10 entries)
        for j in range(i + 1, min(i + 10, len(entries))):
            if entries[j][1] == "R":
                try:
                    raw = json.loads(entries[j][2])
                    # Unwrap output envelope if present
                    if isinstance(raw, dict) and raw.get("ok") and "data" in raw:
                        info['result'] = raw["data"]
                    else:
                        info['result'] = raw
                except (json.JSONDecodeError, TypeError):
                    info['result_raw'] = entries[j][2][:500]
                break
        trades.append(info)
    return trades


def _extract_research(entries):
    """Find research skill invocations and web searches."""
    research = []
    for i, (ts, role, text) in enumerate(entries):
        if role != "T":
            continue
        if text.startswith("Skill:"):
            m = re.search(r'"skill":\s*"([^"]+)"', text)
            if m:
                name = m.group(1).split(':')[0]
                if name in RESEARCH_SKILLS:
                    research.append({'timestamp': ts, 'skill': m.group(1), 'index': i})
        elif text.startswith(("WebSearch:", "WebFetch:")):
            research.append({'timestamp': ts, 'skill': text.split(':')[0], 'index': i})
    return research


def _get_context_window(entries, trade_index):
    """Entries between previous trade (or start) and this trade."""
    prev = 0
    for i in range(trade_index - 1, -1, -1):
        if entries[i][1] == "T" and _is_hl_order(entries[i][2]):
            prev = i + 1
            break
    return entries[prev:trade_index]


def _find_last_command_response(entries, command):
    """Find last user message matching command and the assistant response after it."""
    last_idx = None
    for i, (ts, role, text) in enumerate(entries):
        if role == "U" and text.strip().lower() == command:
            last_idx = i
    if last_idx is None:
        return None
    for j in range(last_idx + 1, len(entries)):
        if entries[j][1] == "A":
            return {'timestamp': entries[last_idx][0], 'response': entries[j][2]}
    return None


# --- Time helpers ---

def _parse_ts(ts):
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _parse_time_modifier(mod):
    """Parse pnl modifier into (start, end) UTC datetimes."""
    now = datetime.now(timezone.utc)
    today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    if not mod or mod == '1d':
        return today_start, now
    if mod == 'max':
        return datetime.min.replace(tzinfo=timezone.utc), now
    if mod == 'ytd':
        return now.replace(month=1, day=1, hour=0, minute=0, second=0, microsecond=0), now

    m = re.match(r'^(\d+)([dwmy])$', mod)
    if m:
        n, u = int(m.group(1)), m.group(2)
        delta = {'d': timedelta(days=n), 'w': timedelta(weeks=n),
                 'm': timedelta(days=n * 30), 'y': timedelta(days=n * 365)}[u]
        return now - delta, now

    m = re.match(r'^(\d{1,2}/\d{1,2})-(\d{1,2}/\d{1,2})$', mod)
    if m:
        y = now.year
        start = datetime.strptime(f"{y}/{m.group(1)}", "%Y/%m/%d").replace(tzinfo=timezone.utc)
        end = datetime.strptime(f"{y}/{m.group(2)}", "%Y/%m/%d").replace(
            hour=23, minute=59, second=59, tzinfo=timezone.utc)
        return start, end

    return today_start, now


def _filter_by_time(entries, start, end):
    return [(ts, r, t) for ts, r, t in entries
            if (dt := _parse_ts(ts)) and start <= dt <= end]


def _today_entries(entries):
    today = datetime.now().date()
    return [(ts, r, t) for ts, r, t in entries
            if (dt := _parse_ts(ts)) and dt.astimezone().date() == today]


# --- Formatting ---

def _fmt_trade(t):
    """One-line trade summary."""
    r = t.get('result', {})
    price = r.get('avg_price', t.get('price', '?')) if isinstance(r, dict) else t.get('price', '?')
    status = r.get('status', '?') if isinstance(r, dict) else '?'
    close = ' (close)' if t.get('reduce_only') else ''
    return f"[{t['timestamp']}] {t['side']} {t['size']} {t['asset']} @ {price} [{status}]{close}"


# --- Session loading helper ---

# Scan depth per command
_DEPTHS = {
    'gm': 10,
    'gg': 3,
    'cope': 20,
    'pnl': 30,
    'tilt': 3,
    'what': 5,
}


def _load_session(command: str, pnl_max: bool = False):
    """Load session entries, exit with error if none found."""
    base_path = _get_session_base_path()
    if not base_path:
        print("[!] No session directory found for CWD.", file=sys.stderr)
        raise SystemExit(1)

    session_files = _find_session_files(base_path)
    if not session_files:
        print("[!] No session files found.", file=sys.stderr)
        raise SystemExit(1)

    if pnl_max:
        return _load_entries(session_files, max_sessions=len(session_files))
    return _load_entries(session_files, max_sessions=_DEPTHS.get(command, 5))


# --- Commands ---

@session_app.command()
def gm():
    """Pick up where you left off — context re-hydration from last gg."""
    entries = _load_session('gm')
    result = _find_last_command_response(entries, "gg")
    if result:
        print(f"[gm] Last gg: {result['timestamp']}")
        print()
        print(result['response'])
    else:
        print("[gm] No previous gg found — first session.")


@session_app.command()
def gg():
    """Wrap session — compress context and build scorecard."""
    entries = _load_session('gg')
    today = _today_entries(entries)
    if not today:
        print("[gg] No activity today.")
        return

    trades = _extract_trades(today)
    research = _extract_research(today)

    print(f"[gg] {len(trades)} trades, {len(research)} research actions")
    print()

    if trades:
        print("## Trades")
        for t in trades:
            print(f"  {_fmt_trade(t)}")
        print()

    if research:
        print("## Research")
        for r in research:
            print(f"  [{r['timestamp']}] {r['skill']}")
        print()

    msgs = [(ts, text) for ts, role, text in today if role == "U" and len(text.strip()) > 20]
    if msgs:
        print("## Key messages")
        for ts, text in msgs[-10:]:
            print(f"  [{ts}] {text.replace(chr(10), ' ')[:200]}")


@session_app.command()
def cope(
    assets: List[str] = typer.Argument(None, help="Assets to check thesis for"),
):
    """Thesis check — re-evaluate open positions against original reasoning."""
    if not assets:
        print("[cope] No assets specified.")
        return

    entries = _load_session('cope')
    trades = _extract_trades(entries)

    for asset in assets:
        au = asset.upper()
        opening = None
        for t in reversed(trades):
            if t['asset'].upper() == au and not t.get('reduce_only'):
                opening = t
                break

        if not opening:
            print(f"[cope:{au}] No opening trade found in transcripts.")
            print()
            continue

        r = opening.get('result', {})
        price = r.get('avg_price', opening.get('price', '?')) if isinstance(r, dict) else '?'
        print(f"[cope:{au}] Opened {opening['side']} {opening['size']} @ {price} — {opening['timestamp']}")
        print()

        ctx = _get_context_window(entries, opening['index'])
        if not ctx:
            print("  No conversation context found before this trade.")
            print()
            continue

        print(f"  Context ({len(ctx)} entries):")
        for ts, role, text in ctx:
            text_clean = text.replace('\n', ' ')
            if role == "U":
                print(f"  [User] {text_clean[:300]}")
            elif role == "A":
                print(f"  [Assistant] {text_clean[:300]}")
            elif role == "T":
                print(f"  [Tool] {text_clean[:200]}")
            elif role == "R":
                print(f"  [Result] {text_clean[:200]}")
        print()


@session_app.command()
def pnl(
    modifier: Optional[str] = typer.Argument(None, help="Time range: 1d, 5d, 1m, ytd, max, MM/DD-MM/DD"),
):
    """P&L for a time range."""
    entries = _load_session('pnl', pnl_max=(modifier == 'max'))
    start, end = _parse_time_modifier(modifier)
    filtered = _filter_by_time(entries, start, end)
    trades = _extract_trades(filtered)

    balance_calls = []
    for ts, role, text in filtered:
        if role == "T":
            cmd = _extract_hl_command(text)
            if cmd and (cmd.startswith('regard hl balance') or cmd.startswith('regard hl status')):
                balance_calls.append(ts)

    label = modifier or '1d'
    print(f"[pnl:{label}] {len(trades)} trades, {len(balance_calls)} balance checks")
    print()
    if trades:
        for t in trades:
            print(f"  {_fmt_trade(t)}")


@session_app.command()
def tilt():
    """Session health check — data-driven tilt detection."""
    entries = _load_session('tilt')
    today = _today_entries(entries)
    trades = _extract_trades(today)

    if len(trades) < 2:
        print(f"[tilt] GREEN — {len(trades)} trade(s), need 2+ to assess")
        print("  session_health: 100")
        return

    timestamps = [dt for t in trades if (dt := _parse_ts(t['timestamp']))]
    intervals = [(timestamps[i] - timestamps[i - 1]).total_seconds()
                 for i in range(1, len(timestamps))]

    freq_factor = 0.0
    if len(intervals) >= 3:
        avg_iv = sum(intervals) / len(intervals)
        if intervals[-1] > 0 and avg_iv > 0:
            freq_factor = max(0, (avg_iv / intervals[-1]) - 1)

    sizes = []
    for t in trades:
        try:
            sizes.append(float(t['size']))
        except (ValueError, TypeError):
            pass

    size_dev = 0.0
    if len(sizes) >= 3:
        avg_sz = sum(sizes) / len(sizes)
        if avg_sz > 0:
            size_dev = max(0, ((sizes[-1] / avg_sz) - 1) * 100)

    revenge = 0
    for i in range(1, len(trades)):
        prev, curr = trades[i - 1], trades[i]
        if (curr['asset'].upper() == prev['asset'].upper()
                and curr['side'] == prev['side']):
            t1, t2 = _parse_ts(prev['timestamp']), _parse_ts(curr['timestamp'])
            if t1 and t2 and (t2 - t1).total_seconds() < 300:
                revenge += 1

    health = 100 - freq_factor * 15 - size_dev * 0.5 - revenge * 20
    health = max(0, min(100, health))

    indicators = []
    if freq_factor >= 1.0:
        indicators.append(f"frequency: {freq_factor:.1f}x faster than avg")
    if size_dev >= 50:
        indicators.append(f"size: +{size_dev:.0f}% vs avg")
    if revenge > 0:
        indicators.append(f"revenge: {revenge} re-entry(s) <5min")

    n = len(indicators)
    level = "RED" if n >= 3 else "ORANGE" if n >= 2 else "YELLOW" if n >= 1 else "GREEN"

    print(f"[tilt] {level} — {n} indicator(s)")
    print(f"  session_health: {health:.0f}")
    print(f"  trades_today: {len(trades)}")

    if intervals:
        print(f"  avg_interval: {sum(intervals) / len(intervals) / 60:.1f}min")
        print(f"  last_interval: {intervals[-1] / 60:.1f}min")
    if sizes:
        print(f"  avg_size: {sum(sizes) / len(sizes):.4f}")
        print(f"  last_size: {sizes[-1]:.4f}")
    for ind in indicators:
        print(f"  ! {ind}")

    print()
    print("  [consecutive losses needs live regard hl fills]")


@session_app.command()
def what():
    """Session context for open-ended trading interview."""
    entries = _load_session('what')
    today = _today_entries(entries)
    if not today:
        today = entries[-100:] if len(entries) > 100 else entries

    trades = _extract_trades(today)
    research = _extract_research(today)

    print(f"[what] {len(today)} entries, {len(trades)} trades, {len(research)} research")
    print()

    for ts, role, text in today[-50:]:
        text_clean = text.replace('\n', ' ')
        if role == "U":
            print(f"[User] {text_clean[:500]}")
        elif role == "A":
            print(f"[Assistant] {text_clean[:500]}")
        elif role == "T" and ('regard hl ' in text or
              any(s in text for s in RESEARCH_SKILLS) or
              text.startswith(("WebSearch:", "WebFetch:", "Skill:"))):
            print(f"[Tool] {text_clean[:200]}")


@session_app.command()
def ctx():
    """Context estimate — rough session weight from transcript data."""
    base_path = _get_session_base_path()
    if not base_path:
        print("[!] No session directory found for CWD.", file=sys.stderr)
        raise SystemExit(1)

    session_files = _find_session_files(base_path)
    if not session_files:
        print("[!] No session files found.", file=sys.stderr)
        raise SystemExit(1)

    # Read the current (most recent) session file raw
    current = session_files[0]

    user_msgs = 0
    assistant_msgs = 0
    tool_calls = 0
    tool_results = 0
    thinking_blocks = 0
    total_chars = 0
    first_ts = None
    last_ts = None

    try:
        with open(current, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                    ts = e.get("timestamp", "")
                    t = e.get("type")

                    if ts:
                        if first_ts is None:
                            first_ts = ts
                        last_ts = ts

                    if t == "user":
                        c = e.get("message", {}).get("content", "")
                        if isinstance(c, str):
                            total_chars += len(c)
                            user_msgs += 1
                        elif isinstance(c, list):
                            for item in c:
                                if item.get("type") == "text":
                                    total_chars += len(item.get("text", ""))
                                    user_msgs += 1
                                elif item.get("type") == "tool_result":
                                    content = item.get("content", "")
                                    if isinstance(content, str):
                                        total_chars += len(content)
                                    elif isinstance(content, list):
                                        for b in content:
                                            if isinstance(b, dict):
                                                total_chars += len(b.get("text", ""))
                                    tool_results += 1

                    elif t == "assistant":
                        for b in e.get("message", {}).get("content", []) or []:
                            if b.get("type") == "text":
                                total_chars += len(b.get("text", ""))
                                assistant_msgs += 1
                            elif b.get("type") == "tool_use":
                                total_chars += len(json.dumps(b.get("input", {})))
                                tool_calls += 1
                            elif b.get("type") == "thinking":
                                total_chars += len(b.get("thinking", ""))
                                thinking_blocks += 1

                except (json.JSONDecodeError, KeyError):
                    pass
    except (OSError, IOError):
        pass

    # Rough token estimate: ~4 chars per token for English/code mix
    est_tokens = total_chars // 4

    # Duration
    duration = ""
    t1 = _parse_ts(first_ts)
    t2 = _parse_ts(last_ts)
    if t1 and t2:
        delta = t2 - t1
        hours = int(delta.total_seconds() // 3600)
        mins = int((delta.total_seconds() % 3600) // 60)
        if hours > 0:
            duration = f"{hours}h {mins}m"
        else:
            duration = f"{mins}m"

    print(f"[ctx] ~{est_tokens:,} tokens (ballpark, ~4 chars/token)")
    print(f"  messages:  {user_msgs} user, {assistant_msgs} assistant")
    print(f"  tools:     {tool_calls} calls, {tool_results} results")
    if thinking_blocks:
        print(f"  thinking:  {thinking_blocks} blocks")
    if duration:
        print(f"  duration:  {duration}")
