"""regard — AI trading partner for the unified speculator."""

from importlib.metadata import version as pkg_version
from typing import Optional

import typer


def _version_callback(value: bool):
    if value:
        print(pkg_version("regard-cli"))
        raise typer.Exit()


app = typer.Typer(
    name="regard",
    add_completion=False,
    no_args_is_help=True,
    help="AI trading partner for the unified speculator.",
)

hl_app = typer.Typer(
    name="hl",
    no_args_is_help=True,
    help="Hyperliquid perp trading. JSON output by default.",
)


@app.callback()
def main(
    ctx: typer.Context,
    version: bool = typer.Option(False, "--version", callback=_version_callback, is_eager=True, help="Show version and exit"),
    fields: Optional[str] = typer.Option(None, "--fields", help="Comma-separated field projection"),
    verbose: bool = typer.Option(False, "--verbose", help="Debug info to stderr"),
):
    """Regard CLI — multi-venue trading."""
    ctx.ensure_object(dict)
    ctx.obj["fields"] = fields
    ctx.obj["verbose"] = verbose


@hl_app.callback()
def hl_main(
    ctx: typer.Context,
    testnet: bool = typer.Option(False, "--testnet", help="Use testnet endpoints"),
):
    """Hyperliquid perp trading CLI."""
    ctx.ensure_object(dict)
    ctx.obj["testnet"] = testnet


app.add_typer(hl_app)

# Session commands (top-level, not venue-specific)
from hl_cli.commands.session import session_app  # noqa: E402
app.add_typer(session_app)

# Register all hl venue commands — must be after hl_app is defined
from hl_cli.commands import orient, research, act, review  # noqa: E402, F401
