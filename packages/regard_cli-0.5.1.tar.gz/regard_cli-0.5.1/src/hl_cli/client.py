"""SDK client factory — creates Info and Exchange instances."""

import os

import eth_account
from hyperliquid.exchange import Exchange
from hyperliquid.info import Info
from hyperliquid.utils.constants import MAINNET_API_URL

from hl_cli.output import die

TESTNET_API_URL = "https://api.hyperliquid-testnet.xyz"


def _base_url(testnet: bool) -> str:
    return TESTNET_API_URL if testnet else MAINNET_API_URL


def _get_key():
    key = os.environ.get("HYPERLIQUID_AGENT_KEY") or os.environ.get("HYPERLIQUID_PRIVATE_KEY")
    if not key:
        die(
            "auth_error", "NO_KEY",
            "No trading key set",
            hint="Set HYPERLIQUID_AGENT_KEY (agent wallet) or HYPERLIQUID_PRIVATE_KEY (master wallet)",
            exit_code=3,
        )
    return key


def _resolve_master_address(info: Info, agent_address: str) -> str:
    """Look up the master account for an agent wallet via userRole API."""
    try:
        result = info.post("/info", {"type": "userRole", "user": agent_address})
        role = result.get("role")
        if role == "agent":
            return result["data"]["user"]
        if role == "user":
            return agent_address  # key IS the master key
    except Exception:
        pass
    return agent_address  # fallback: assume key is master


def get_address(explicit: str = None, testnet: bool = False) -> str:
    """Get account address for queries.

    Priority: explicit arg > HYPERLIQUID_ACCOUNT_ADDRESS > auto-resolve via userRole API > derived from key.
    """
    if explicit:
        return explicit
    addr = os.environ.get("HYPERLIQUID_ACCOUNT_ADDRESS")
    if addr:
        return addr
    key = os.environ.get("HYPERLIQUID_AGENT_KEY") or os.environ.get("HYPERLIQUID_PRIVATE_KEY")
    if key:
        agent_address = eth_account.Account.from_key(key).address
        if os.environ.get("HYPERLIQUID_AGENT_KEY"):
            info = Info(_base_url(testnet), skip_ws=True)
            return _resolve_master_address(info, agent_address)
        return agent_address
    die(
        "auth_error", "NO_ADDRESS",
        "No address available",
        hint="Set HYPERLIQUID_AGENT_KEY or use --address",
        exit_code=3,
    )


def get_info(testnet: bool = False) -> Info:
    """Create Info client (default perps only, dexes loaded lazily by resolver)."""
    return Info(_base_url(testnet), skip_ws=True)


def get_exchange(testnet: bool = False) -> Exchange:
    """Create Exchange client.

    Supports two modes:
    - Agent mode: HYPERLIQUID_AGENT_KEY (signs) + HYPERLIQUID_ACCOUNT_ADDRESS (queries master account)
    - Direct mode: HYPERLIQUID_PRIVATE_KEY (signs and queries same account)
    """
    key = _get_key()
    wallet = eth_account.Account.from_key(key)
    account_address = get_address()
    return Exchange(wallet, _base_url(testnet), account_address=account_address)


def get_all_mids(info: Info) -> dict:
    """Get all mid prices including HIP-3 deployer assets."""
    mids = info.all_mids()
    try:
        dex_list = info.post("/info", {"type": "perpDexs"})
        for dex_info in dex_list[1:]:
            dex_mids = info.post("/info", {"type": "allMids", "dex": dex_info["name"]})
            mids.update(dex_mids)
    except Exception:
        pass
    return mids
