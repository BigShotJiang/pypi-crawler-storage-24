"""Tests for research commands — assets, prices, book, funding, candles."""

import json

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


class TestAssets:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "assets"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_search(self, runner, patched):
        result = runner.invoke(app, ["hl", "assets", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_sort_name(self, runner, patched):
        result = runner.invoke(app, ["hl", "assets", "--sort", "name"])
        assert result.exit_code == 0
        d = data(result)
        names = [a["asset"] for a in d]
        assert names == sorted(names)


class TestPrices:
    def test_all_mids(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "prices"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_specific(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "prices", "BTC"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_multiple(self, runner, patched):
        result = runner.invoke(app, ["hl", "prices", "BTC", "ETH"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 2
        assert {r["asset"] for r in d} == {"BTC", "ETH"}

    def test_unknown_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "prices", "FAKECOIN"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "UNKNOWN_ASSET"


class TestBook:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "book", "BTC"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_depth(self, runner, patched):
        result = runner.invoke(app, ["hl", "book", "BTC", "--depth", "2"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d["bids"]) == 2
        assert len(d["asks"]) == 2


class TestFunding:
    def test_current_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "funding"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_current_specific(self, runner, patched):
        result = runner.invoke(app, ["hl", "funding", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_history(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "funding", "BTC", "--history", "--limit", "3"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_history_requires_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "funding", "--history"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "MISSING_ARGUMENT"


class TestCandles:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "candles", "BTC", "1h", "--limit", "2"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_invalid_interval(self, runner, patched):
        result = runner.invoke(app, ["hl", "candles", "BTC", "2d"])
        assert result.exit_code == 2
        assert parse(result)["error"]["code"] == "INVALID_INTERVAL"
