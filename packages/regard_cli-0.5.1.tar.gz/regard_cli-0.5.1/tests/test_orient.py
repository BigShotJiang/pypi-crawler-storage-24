"""Tests for orient commands — status, balance, positions, orders."""

import json

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


class TestStatus:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "status"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_fields(self, runner, patched):
        result = runner.invoke(app, ["--fields", "account_value,withdrawable", "hl", "status"])
        assert result.exit_code == 0
        d = data(result)
        assert set(d.keys()) == {"account_value", "withdrawable"}


class TestBalance:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "balance"])
        assert result.exit_code == 0
        assert data(result) == snapshot


class TestPositions:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "positions"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "positions", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_empty(self, runner, patched):
        patched["info"].user_state.return_value = {
            "crossMarginSummary": {"accountValue": "100.00"},
            "withdrawable": "100.00",
            "assetPositions": [],
        }
        result = runner.invoke(app, ["hl", "positions"])
        assert result.exit_code == 0
        assert data(result) == []


class TestOrders:
    def test_all(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "orders"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "orders", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_trigger_order_tif_none(self, runner, patched):
        """Regression: trigger orders (TP/SL) return tif=None from API."""
        patched["info"].frontend_open_orders.return_value = [
            {
                "coin": "BTC",
                "oid": 100003,
                "side": "A",
                "limitPx": "80000.0",
                "sz": "0.001",
                "orderType": "Take Profit Market",
                "tif": None,
                "reduceOnly": True,
                "timestamp": 1773000000000,
            }
        ]
        result = runner.invoke(app, ["hl", "orders"])
        assert result.exit_code == 0
        d = data(result)
        assert d[0]["tif"] is None
        assert d[0]["type"] == "take profit market"
