"""Tests for review commands — fills, trades."""

import json

from hl_cli.main import app


def parse(result):
    return json.loads(result.output)


def data(result):
    return parse(result)["data"]


class TestFills:
    def test_basic(self, runner, patched, snapshot):
        result = runner.invoke(app, ["hl", "fills"])
        assert result.exit_code == 0
        assert data(result) == snapshot

    def test_filter_asset(self, runner, patched):
        result = runner.invoke(app, ["hl", "fills", "BTC"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
        assert d[0]["asset"] == "BTC"

    def test_limit(self, runner, patched):
        result = runner.invoke(app, ["hl", "fills", "--limit", "1"])
        assert result.exit_code == 0
        d = data(result)
        assert len(d) == 1
