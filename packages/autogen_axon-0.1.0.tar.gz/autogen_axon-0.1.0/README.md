# autogen-axon

AutoGen plugin for [Axon](https://axonfi.xyz) — treasury and payment infrastructure for autonomous AI agents.

Gives AutoGen agents the ability to send payments, swap tokens, execute DeFi protocols, and check vault balances through Axon's non-custodial vault system. Bots never hold funds or pay gas.

## Prerequisites

Before using this plugin, you need an Axon vault:

1. **Go to [app.axonfi.xyz](https://app.axonfi.xyz)** and connect your wallet
2. **Deploy a vault** - this is your non-custodial treasury. Only you (the owner) can withdraw.
3. **Register a bot key** - generate a new key pair in the dashboard or bring your own. This is the key your AutoGen agent will sign with. Set a `maxPerTxAmount` to cap what the bot can spend per transaction.
4. **Fund the vault** - deposit USDC (or any ERC-20) into your vault address.
5. **Copy your credentials**:
   - `vault_address` - your deployed vault address
   - `bot_private_key` - the bot's private key (the one registered in step 3)
   - `chain_id` - 8453 (Base), 42161 (Arbitrum), or 84532 (Base Sepolia for testing)

Your bot signs payment intents. It never holds funds, never pays gas, and can only spend within the limits you set. If the bot key is compromised, the attacker is capped by `maxPerTxAmount` and can only send to whitelisted destinations.

## Installation

```bash
pip install autogen-axon
```

## Quick Start

```python
import asyncio

from autogen_agentchat.agents import AssistantAgent
from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_axon import get_axon_tools

# Initialize Axon tools
tools = get_axon_tools(
    relayer_url="https://relay.axonfi.xyz",
    bot_private_key="0xYOUR_BOT_PRIVATE_KEY",
    vault_address="0xYOUR_VAULT_ADDRESS",
    chain_id=8453,  # Base mainnet
)

# Create an AutoGen agent with Axon tools
agent = AssistantAgent(
    name="treasury_agent",
    model_client=OpenAIChatCompletionClient(model="gpt-4o"),
    tools=tools,
    system_message=(
        "You are a treasury management agent. You can send payments, "
        "swap tokens, and check vault balances using Axon."
    ),
)


async def main():
    response = await agent.run(task="Check my vault balance and total value")
    print(response.messages[-1].content)


asyncio.run(main())
```

## Available Tools

| Tool | Description | Parameters |
|------|-------------|------------|
| `pay` | Send a USDC payment from the vault | `to` (address), `amount` ("5.00"), `memo` (optional) |
| `swap` | Swap tokens within the vault | `from_token` ("USDC"), `to_token` ("WETH"), `amount` ("100.00") |
| `execute_protocol` | Execute a DeFi protocol call | `target` (address), `calldata` (hex) |
| `get_balance` | Check vault token balance | `token` ("USDC", default) |
| `get_vault_value` | Total vault USD value | (none) |

All amounts are human-readable (e.g. `"5.00"` for 5 USDC, not `"5000000"`).

## How It Works

1. **`get_axon_tools()`** creates a shared `AxonClientSync` and returns a list of `FunctionTool` instances
2. Pass the tools list to any AutoGen `AssistantAgent`
3. When the agent calls a tool, the SDK signs an EIP-712 intent and submits it to the Axon relayer
4. The relayer validates policies, runs AI verification if needed, and executes on-chain
5. The tool returns a human-readable result (TX hash, pending review ID, or rejection reason)

## Payment Flow

Payments go through Axon's full pipeline:

- **Fast path**: approved instantly, TX hash returned
- **AI review**: flagged by spending limits or anomaly detection (~30s)
- **Human review**: owner notified, must approve/reject manually

```python
tools = get_axon_tools(
    relayer_url="https://relay.axonfi.xyz",
    bot_private_key="0x...",
    vault_address="0x...",
    chain_id=8453,
)

# The agent decides when and how to use each tool
agent = AssistantAgent(
    name="defi_agent",
    model_client=OpenAIChatCompletionClient(model="gpt-4o"),
    tools=tools,
    system_message="You manage a DeFi treasury. Pay invoices, rebalance tokens, and monitor balances.",
)
```

## Supported Chains

| Chain | Chain ID |
|-------|----------|
| Base | 8453 |
| Arbitrum One | 42161 |
| Base Sepolia (testnet) | 84532 |

## Links

- [Axon Documentation](https://axonfi.xyz/docs)
- [Python SDK (`axonfi`)](https://pypi.org/project/axonfi/)
- [AutoGen Documentation](https://microsoft.github.io/autogen/)
