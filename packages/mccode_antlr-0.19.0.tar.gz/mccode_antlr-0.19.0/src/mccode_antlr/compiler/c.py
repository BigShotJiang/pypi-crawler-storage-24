"""Handles compilation of C translated instruments into usable binaries"""
from __future__ import annotations

from enum import Flag, auto
from typing import Union
from pathlib import Path
from mccode_antlr.instr import Instr
from mccode_antlr.translators.c import CTargetVisitor
from loguru import logger
from .check import compiled, gpu_only, mpi_only
from mccode_antlr import Flavor

class CBinaryTarget:
    class Type(Flag):
        single = auto()
        acc = auto()
        mpi = auto()
        nexus = auto()

    def __init__(self, mpi: bool = False, acc: bool = False, count: int = 1, nexus: bool = False):
        self.count = count
        if mpi and acc:
            self.type = CBinaryTarget.Type.acc | CBinaryTarget.Type.mpi
        elif mpi:
            self.type = CBinaryTarget.Type.mpi
        elif acc:
            self.type = CBinaryTarget.Type.acc
        else:
            self.type = CBinaryTarget.Type.single
        # completely orthogonal, probably a bad idea to include here at all:
        if nexus:
            self.type |= CBinaryTarget.Type.nexus

    def update(self, d: dict):
        self.count = d.get('count', self.count)
        d_mpi = d.get('mpi', self.type & CBinaryTarget.Type.mpi)
        d_acc = d.get('acc', self.type & CBinaryTarget.Type.acc)
        if d_mpi and d_acc:
            self.type = CBinaryTarget.Type.acc | CBinaryTarget.Type.mpi
        elif d_mpi:
            self.type = CBinaryTarget.Type.mpi
        elif d_acc:
            self.type = CBinaryTarget.Type.acc
        else:
            self.type = CBinaryTarget.Type.single
        if d.get('nexus', self.type & CBinaryTarget.Type.nexus):
            self.type |= CBinaryTarget.Type.nexus

    @property
    def compiler(self) -> str:
        from mccode_antlr.config import config
        if self.type & CBinaryTarget.Type.acc:
            # acc *or* acc + mpi uses the OpenACC compiler
            return config['acc'].as_str_expanded()
        elif self.type & CBinaryTarget.Type.mpi:
            # mpi (no-acc) uses the OpenMPI compiler
            return config['mpi']['cc'].as_str_expanded()
        # otherwise use the standard C compiler
        return config['cc'].as_str_expanded()

    @property
    def flags(self) -> list[str]:
        from mccode_antlr.config import config
        if self.type & CBinaryTarget.Type.acc:
            # acc *or* acc + mpi uses the OpenACC compiler *and* flags
            return config['flags']['acc'].as_str_expanded().split()
        # otherwise use the standard compiler flags
        return config['flags']['cc'].as_str_expanded().split()

    @property
    def linker_flags(self) -> list[str]:
        from mccode_antlr.config import config
        return config['flags']['ld'].as_str_expanded().split()

    @property
    def extra_flags(self) -> list[str]:
        """Only a little confusing ..."""
        from mccode_antlr.config import config
        extras = []
        if self.type & CBinaryTarget.Type.mpi:
            extras.extend(config['flags']['mpi'].as_str_expanded().split())
        if self.type & CBinaryTarget.Type.nexus:
            extras.extend(config['flags']['nexus'].as_str_expanded().split())
        return extras


def instrument_source(instrument: Instr, flavor: Flavor, config: dict, verbose: bool = None):
    if verbose is None:
        verbose = config.get('verbose', False)
    # TargetVisitor to uses instrument.registries (and the CTargetVisitor *appends* its LIBC_REGISTRY if necessary)
    visitor = CTargetVisitor(instrument, flavor=flavor, config=config, verbose=verbose)
    # Does the conversion by 'visiting' the instrument, then returns the full string of the generated source code
    return visitor.contents()


def linux_split_flags(instrument: Instr, target: CBinaryTarget):
    # the type of binary requested determines (some of) the required flags:
    compiler_flags = target.flags + target.extra_flags
    linker_flags = target.linker_flags
    # Classify each token from decoded DEPENDENCY flag strings.
    # Linker tokens: -l<lib>, -L<dir>, -Wl,<linker-opts>, and bare library files.
    # Everything else (-I, -D, -std, -x, -fopenmp, -fPIC, …) is a compiler flag
    # and must appear before the stdin source marker ('-') in the command.
    _linker_starts = ('-l', '-L', '-Wl,')
    _lib_suffixes  = ('.so', '.a', '.dylib')
    for flag in instrument.decoded_flags():
       for word in flag.split():
           if word.startswith(_linker_starts) or word.endswith(_lib_suffixes):
               linker_flags.append(word)
           else:
               compiler_flags.append(word)

    # Workaround: NeXus headers on some systems require __GNUC__ to be defined,
    # but the OpenACC compiler (PGI/NVHPC) does not define it by default.
    # Check both lists: -DOPENACC lands in compiler_flags; -lNeXus lands in linker_flags.
    all_flags = compiler_flags + linker_flags
    if any('OPENACC' in w for w in all_flags) and any('NeXus' in w for w in all_flags):
       compiler_flags.append('-D__GNUC__')
    return compiler_flags, linker_flags


def windows_split_flags(instrument, target):
    compiler_flags = target.flags + target.extra_flags
    linker_flags = target.linker_flags

    linker_prefixes = ('link', 'LIBPATH', 'SUBSYSTEM', 'ENTRY', 'STACK', 'HEAP',
                        'MACHINE', 'MANIFEST', 'INCREMENTAL', 'NODEFAULTLIB',
                        'OPT', 'LTCG', 'DEBUG', 'PDB', 'NATVIS', 'DYNAMICBASE')

    for decoded in instrument.decoded_flags():
        for flag in decoded.split():
            flag = flag.strip()
            stem = flag[1:] if (flag.startswith('/') or flag.startswith('-')) else ''

            if not stem:  # bare path or .lib
                linker_flags.append(flag)
            elif flag.lower().endswith('.lib'):  # explicit .lib
                linker_flags.append(flag)
            elif stem.lower().startswith('l') or any(
                    stem.upper().startswith(p) for p in linker_prefixes):
                linker_flags.append(flag)  # linker options
            else:
                # std: needs /std:c11 → /std:c11 (replace = with :)
                if stem.lower().startswith('std') and '=' in flag:
                    flag = flag.replace('=', ':')
                compiler_flags.append(flag)  # default: compiler

    return compiler_flags, linker_flags


def linux_compile(compiler, compiler_flags, target, linker_flags, source):
    from subprocess import run
    # The solitary '-' specifies *where* the stdin source should be processed, which is critical for getting
    # linking flags right on (some) Linux systems
    command = [compiler, *compiler_flags, '-o', str(target), '-', *linker_flags]
    result = run(command, input=source, text=True, capture_output=True)
    return command, result


def windows_compile(compiler, compiler_flags, target, linker_flags, source):
    from subprocess import run
    parent = target.parent
    if not parent.is_dir():
        parent.mkdir(parents=True)
    write_to = target.with_suffix('.c')
    with write_to.open('w') as file:
        file.writelines(source)
    if '/link' not in linker_flags:
        linker_flags = ['/link'] + linker_flags
    # Specifying either of
    #   obj = [] if parent == Path() else [f'/Fo"{parent}\\"']
    # as *obj, would move generated object files next to the executable, but breaks
    # some aspect of compilation when done from Python (but not the command line)
    # FIXME Re-evaluate the need/advisability for no compiler warnings
    command = [compiler, *compiler_flags, str(write_to), '/W0', *linker_flags, f'/out:{target}']
    result = run(command, capture_output=True)
    return command, result


def _compile_instrument(
        instrument: Instr,
        target: CBinaryTarget,
        output: Union[str, Path] = None,
        replace: bool = False,
        dump_source: bool = False,
        source_file: str | None = None,
        **kwargs
):
    """Do the actual compilation -- should not be called directly by users

    Note
    ----
    If you are a user of the mccode-antlr module, call the `compile_instrument`
    gateway method instead to enable a cached check that your system compiler is
    configured correctly.
    """
    from os import R_OK, access
    from subprocess import run, CalledProcessError
    from platform import system
    from mccode_antlr.config import config
    logger.info(f'Compile {instrument.name}')
    # determine a name and location for the binary file
    if output is None:
        # use the current working directory if nothing provided
        output = Path()
    if not isinstance(output, Path):
        # allow for a string input to be interpreted as a path
        output = Path(output)
    if output.is_dir():
        # allow for the user to specify only the output *directory*
        output = output.joinpath(instrument.name).with_suffix(config['ext'].get(str))

    if output.exists() and not replace:
        return output

    source = instrument_source(instrument, **kwargs)
    if source_file or ('Windows' != system() and dump_source):
        source_file = source_file or Path().joinpath(output.parts[-1]).with_suffix('.c')
        logger.info(f'Source written in {source_file}')
        with open(source_file, 'w') as cfile:
            cfile.write(source)

    _compile = windows_compile if 'Windows' == system() else linux_compile
    _handle_flags = windows_split_flags if 'Windows' == system() else linux_split_flags
    compiler_flags, linker_flags = _handle_flags(instrument, target)
    command, result = _compile(target.compiler, compiler_flags, output, linker_flags, source)

    if result.returncode:
        stdout = result.stdout.decode() if isinstance(result.stdout, bytes) else result.stdout
        stderr = result.stderr.decode() if isinstance(result.stderr, bytes) else result.stderr
        raise RuntimeError(f"Compilation\n{' '.join(command)}\nfailed with output\n{stdout}\nand error\n{stderr}")
    if not output.exists():
        raise RuntimeError(f"Compilation should have produced {output}, but it does not appear to exist")
    if not access(output, R_OK):
        raise RuntimeError(f"{output} exists but is not an executable")
    return output


@gpu_only
def compile_acc_instrument(*args, **kwargs):
    return _compile_instrument(*args, **kwargs)


@mpi_only
def compile_mpi_instrument(*args, **kwargs):
    return _compile_instrument(*args, **kwargs)


@compiled
def compile_c_instrument(*args, **kwargs):
    return _compile_instrument(*args, **kwargs)


def compile_instrument(
        instrument: Instr,
        target: CBinaryTarget,
        output: Union[str, Path] = None,
        replace: bool = False,
        dump_source: bool = False,
        **kwargs
):
    """Compile an Instr object to one of the possible C targets

    Parameters
    ----------
    instrument: Instr
        The Instr to turn into a compiled binary
    target: CBinaryTarget
        The type of binary to produce: C99, OpenACC, MPI, etc.
    output:
        The path (and optionally name) where to store the produced binary
    replace:
        If true compilation will proceed even if a same-named path exists already
    dump_source:
        A diagnostic mode that outputs the generated C code into the current working
        directory
    """
    if target.type & CBinaryTarget.Type.acc:
        return compile_acc_instrument(instrument, target, output, replace, dump_source, **kwargs)
    if target.type & CBinaryTarget.Type.mpi:
        return compile_mpi_instrument(instrument, target, output, replace, dump_source, **kwargs)
    return compile_c_instrument(instrument, target, output, replace, dump_source, **kwargs)


def cflags_from_c_source(source: str) -> list[str]:
    """Extract CFLAGS recorded in the header comment of a generated McCode C file.

    The translator writes::

        * CFLAGS=<space-separated flags>

    as part of the opening block comment.  Returns an empty list when the line
    is absent or contains no flags.
    """
    import re
    match = re.search(r'^\s*\*\s*CFLAGS=(.*)$', source, re.MULTILINE)
    if match:
        flags = match.group(1).strip()
        return flags.split() if flags else []
    return []


def _split_raw_flags(raw_flags: list[str], target: CBinaryTarget, *, windows: bool = False):
    """Like linux_split_flags / windows_split_flags but accepts a plain list instead of Instr."""
    compiler_flags = target.flags + target.extra_flags
    linker_flags = target.linker_flags
    if windows:
        linker_prefixes = ('link', 'LIBPATH', 'SUBSYSTEM', 'ENTRY', 'STACK', 'HEAP',
                           'MACHINE', 'MANIFEST', 'INCREMENTAL', 'NODEFAULTLIB',
                           'OPT', 'LTCG', 'DEBUG', 'PDB', 'NATVIS', 'DYNAMICBASE')
        for flag in raw_flags:
            for word in flag.split():
                word = word.strip()
                stem = word[1:] if (word.startswith('/') or word.startswith('-')) else ''
                if not stem or word.lower().endswith('.lib'):
                    linker_flags.append(word)
                elif stem.lower().startswith('l') or any(
                        stem.upper().startswith(p) for p in linker_prefixes):
                    linker_flags.append(word)
                else:
                    if stem.lower().startswith('std') and '=' in word:
                        word = word.replace('=', ':')
                    compiler_flags.append(word)
    else:
        _linker_starts = ('-l', '-L', '-Wl,')
        _lib_suffixes = ('.so', '.a', '.dylib')
        for flag in raw_flags:
            for word in flag.split():
                if word.startswith(_linker_starts) or word.endswith(_lib_suffixes):
                    linker_flags.append(word)
                else:
                    compiler_flags.append(word)
        all_flags = compiler_flags + linker_flags
        if any('OPENACC' in w for w in all_flags) and any('NeXus' in w for w in all_flags):
            compiler_flags.append('-D__GNUC__')
    return compiler_flags, linker_flags


@compiled
def compile_c_file(
        c_file: Union[str, Path],
        target: CBinaryTarget,
        output: Union[str, Path] = None,
        replace: bool = False,
):
    """Compile a pre-generated McCode C source file directly to a binary.

    This is the compile-only counterpart to :func:`compile_instrument` for the
    case where the C translation step has already been performed (e.g. by
    ``mcstas-antlr``).  CFLAGS are read from the ``* CFLAGS=`` line in the
    file's opening block comment.

    Parameters
    ----------
    c_file:
        Path to the ``.c`` source file.
    target:
        The type of binary to produce.
    output:
        Destination path or directory for the binary.  Defaults to the current
        working directory using the C file's stem as the binary name.
    replace:
        If ``True``, recompile even when the output already exists.
    """
    from os import R_OK, access
    from platform import system
    from mccode_antlr.config import config

    c_file = Path(c_file)
    source = c_file.read_text()
    name = c_file.stem

    if output is None:
        output = Path()
    if not isinstance(output, Path):
        output = Path(output)
    if output.is_dir():
        output = output / name
    if not output.suffix:
        output = output.with_suffix(config['ext'].get(str))

    if output.exists() and not replace:
        return output

    logger.info(f'Compile {name} from {c_file}')
    raw_flags = cflags_from_c_source(source)
    is_windows = 'Windows' == system()
    _compile = windows_compile if is_windows else linux_compile
    compiler_flags, linker_flags = _split_raw_flags(raw_flags, target, windows=is_windows)
    command, result = _compile(target.compiler, compiler_flags, output, linker_flags, source)

    if result.returncode:
        stdout = result.stdout.decode() if isinstance(result.stdout, bytes) else result.stdout
        stderr = result.stderr.decode() if isinstance(result.stderr, bytes) else result.stderr
        raise RuntimeError(f"Compilation\n{' '.join(command)}\nfailed with output\n{stdout}\nand error\n{stderr}")
    if not output.exists():
        raise RuntimeError(f"Compilation should have produced {output}, but it does not appear to exist")
    if not access(output, R_OK):
        raise RuntimeError(f"{output} exists but is not an executable")
    return output


def run_compiled_instrument(binary: Path, target: CBinaryTarget, options: str, capture=False, dry_run: bool = False):
    from subprocess import run, CalledProcessError
    from platform import system
    from mccode_antlr.config import config

    # If NeXus output is requested and the InstrumentDescriptionFile is needed, run a different script entirely...
    #   TODO think about actually doing this?
    # if target.flags & CBinaryTarget.Type.nexus and idf_required:
    #     run([config['idfgen'].get(str), str(binary), *options])

    command = []
    if target.type & CBinaryTarget.Type.mpi:
        # is the available MPI OpenMPI, mpich, or something else?
        res = run(['mpirun', '--version'], capture_output=True)
        if res.returncode != 0:
            raise RuntimeError(f"mpirun is not installed, MPI compilation failed")
        is_open_mpi = 'Open MPI' in res.stdout.decode()

        # we execute mpirun
        command.append(config['mpi']['run'].as_str_expanded())
        # which takes optional flags
        if target.count == 0 and not is_open_mpi:
            print("Using system default number of mpirun processes")
        else:
            # Even if zero, OpenMPI needs this to avoid interpreting options flags
            # for the binary as if they were for it.
            command.extend(['-np', str(target.count)])
        if config['machinefile'].exists():
            # --machinefile is only an OpenMPI option. mpich uses -f?
            machinefile = config['machinefile'].as_str_expanded()
            command.extend(['--machinefile' if is_open_mpi else '-f', machinefile])
        # and requires trickery if we want to restrict the GPU used
        if target.type & CBinaryTarget.Type.acc and 'Windows' != system():
            # Each worker should have the environment variable CUDA_VISIBLE_DEVICES defined as the value of
            # OMPI_COMM_WORLD_LOCAL_RANK, which gets sent by MPI to the worker. This assigment must take place
            # *on* the worker, which requires hijacking the executable that MPI runs
            command.append('acc_gpu_bind')
            raise NotImplementedError('CUDA GPU binding not yet implemented')
        if is_open_mpi:
            # mpich, at least, does not accept '--' between options and binary
            command.extend(['--'])

    binary = binary.resolve()
    if not binary.exists():
        raise RuntimeError(f'Can not execute {binary} since it does not exist.')

    # In normal operation, the binary is provided with options
    command.extend([str(binary), *options.split()])
    # which we then execute:
    if dry_run:
        logger.info(f'Would execute {command}')
        return ""
    result = run(command, capture_output=capture)
    if result.returncode and capture:
        raise RuntimeError(f'Execution of {command} failed with output\n{result.stdout}\n and error\n{result.stderr}')
    elif result.returncode:
        raise RuntimeError(f'Execution of {command} failed, see above for error message(s)')

    return (result.stdout + result.stderr) if capture else ""
