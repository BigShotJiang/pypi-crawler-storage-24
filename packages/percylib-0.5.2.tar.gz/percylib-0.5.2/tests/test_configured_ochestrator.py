from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace
from typing import cast

import pytest

from percylib.external.models import (
    BatchStartJobEventVariant,
    FolderFileSource,
    FolderV1FileSourceVariant,
    JobBatchConfiguration,
    JobPersistenceConfig,
    JobSpecification,
    JobSpecVariant,
    LanguageModelType,
    LlmDocExtractIterationSpec,
    LlmDocExtractSpec,
    LlmDocExtractV1Input,
    LlmDocExtractV1JobSpecificationVariant,
    LlmDocExtractV1Output,
    ObjectPropertyDefinition,
    ObjectSchema,
    ObjectSchemaVariant,
    PercyJobLanguageModelSpecVariant,
    PercyLanguageModelSpec,
    SqliteJobPersistenceVariant,
    SqlitePersistenceConfig,
    StringSchema,
    StringSchemaVariant,
)
from percylib.jobs import BaseJob, BaseJobExecutor, BaseJobLoader, MemoryPersister
from percylib.jobs.ai.doc_extract_v1 import FolderDocExtractJobLoader
from percylib.jobs.configured_ochestrator import (
    create_executor_from_spec,
    create_job_loader_from_spec,
    create_orchestrator_from_config,
    create_orchestrator_from_config_json,
    create_orchestrator_from_config_path,
    create_persister_from_config,
)
from percylib.jobs.orchestrator import DefaultJobOrchestrator
from percylib.jobs.sqlite import SqliteJobPersister


def _percy_model_spec() -> PercyJobLanguageModelSpecVariant:
    return PercyJobLanguageModelSpecVariant(
        type="percy",
        value=PercyLanguageModelSpec(model=LanguageModelType.openai_4_1),
    )


def _make_doc_extract_spec() -> LlmDocExtractV1JobSpecificationVariant:
    return LlmDocExtractV1JobSpecificationVariant(
        type="llmDocExtractV1",
        value=LlmDocExtractSpec(
            source=FolderV1FileSourceVariant(
                type="folderV1",
                value=FolderFileSource(
                    path="/tmp/test-docs",
                    includePatterns=["**/*.pdf"],
                    excludePatterns=[],
                ),
            ),
            iterations=[LlmDocExtractIterationSpec(model=_percy_model_spec())],
            prompt="Extract values",
            outputSchema=ObjectSchemaVariant(
                type="object",
                value=ObjectSchema(
                    properties=[
                        ObjectPropertyDefinition(
                            key="name",
                            optional=False,
                            schema=StringSchemaVariant(
                                type="string",
                                value=StringSchema(),
                            ),
                        )
                    ]
                ),
            ),
        ),
    )


def _make_config(
    *,
    source_path: str = "/tmp/test-docs",
    persistence: JobPersistenceConfig | None = None,
) -> JobBatchConfiguration:
    spec = _make_doc_extract_spec()
    spec.value.source.value.path = source_path
    return JobBatchConfiguration(
        persistence=persistence,
        job=JobSpecification(variant=spec),
    )


class TestCreateExecutorFromSpec:
    def test_returns_executor_for_doc_extract_spec(self) -> None:
        executor = create_executor_from_spec(_make_doc_extract_spec())
        assert isinstance(executor, BaseJobExecutor)

    def test_raises_for_unsupported_spec(self) -> None:
        unsupported = cast(
            JobSpecVariant,
            SimpleNamespace(type="unsupported", value=SimpleNamespace()),
        )

        with pytest.raises(ValueError, match="Unsupported job spec type"):
            create_executor_from_spec(unsupported)


class TestCreateJobLoaderFromSpec:
    def test_returns_folder_loader_for_doc_extract_spec(self) -> None:
        loader = create_job_loader_from_spec(_make_doc_extract_spec())
        assert isinstance(loader, FolderDocExtractJobLoader)
        assert isinstance(loader, BaseJobLoader)

    def test_raises_for_unsupported_spec(self) -> None:
        unsupported = cast(
            JobSpecVariant,
            SimpleNamespace(type="unsupported", value=SimpleNamespace()),
        )

        with pytest.raises(ValueError, match="Unsupported job spec type"):
            create_job_loader_from_spec(unsupported)


class TestCreatePersisterFromConfig:
    def test_returns_memory_persister_when_persistence_missing(self) -> None:
        persister = create_persister_from_config(None, _make_doc_extract_spec())
        assert isinstance(persister, MemoryPersister)

    def test_returns_sqlite_persister_for_sqlite_config(self, tmp_path: Path) -> None:
        persister = create_persister_from_config(
            JobPersistenceConfig(
                variant=SqliteJobPersistenceVariant(
                    type="sqlite",
                    value=SqlitePersistenceConfig(path=str(tmp_path / "jobs.sqlite")),
                )
            ),
            _make_doc_extract_spec(),
        )
        assert isinstance(persister, SqliteJobPersister)

    def test_raises_when_sqlite_path_is_missing(self) -> None:
        with pytest.raises(ValueError, match="requires an explicit path"):
            create_persister_from_config(
                JobPersistenceConfig(
                    variant=SqliteJobPersistenceVariant(type="sqlite", value=None)
                ),
                _make_doc_extract_spec(),
            )


class TestCreateOrchestratorFromConfig:
    def test_returns_configured_orchestrator(self) -> None:
        orchestrator = create_orchestrator_from_config("batch-1", _make_config())
        assert isinstance(orchestrator, DefaultJobOrchestrator)
        assert isinstance(orchestrator._loader, FolderDocExtractJobLoader)
        assert isinstance(orchestrator._persister, MemoryPersister)
        assert orchestrator._event_sink is None

    def test_uses_stderr_event_sink_when_percy_proc_is_set(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("PERCY_PROC", "1")

        orchestrator = create_orchestrator_from_config("batch-1", _make_config())

        assert orchestrator._event_sink is not None
        assert orchestrator._event_sink.__class__.__name__ == "StderrEventSink"

    def test_passes_display_name_and_description_to_batch_start_event(
        self, tmp_path: Path
    ) -> None:
        orchestrator = create_orchestrator_from_config(
            "batch-1",
            _make_config(source_path=str(tmp_path)),
            display_name="Visible Batch Name",
            description="Batch description",
        )

        events = list(orchestrator.run())
        batch_start = events[0].variant

        assert isinstance(batch_start, BatchStartJobEventVariant)
        assert batch_start.value.info.displayName == "Visible Batch Name"
        assert batch_start.value.info.description == "Batch description"


class TestConfiguredTypeCompatibility:
    def test_executor_output_uses_configured_model_type(self) -> None:
        executor = create_executor_from_spec(_make_doc_extract_spec())
        typed_executor: BaseJobExecutor[
            BaseJob[LlmDocExtractV1Input], LlmDocExtractV1Output
        ] = executor

        assert typed_executor is executor


class TestCreateOrchestratorFromConfigPath:
    def test_loads_config_from_json_file(self, tmp_path: Path) -> None:
        config = _make_config()
        config_path = tmp_path / "config.json"
        config_path.write_text(config.model_dump_json(by_alias=True))

        orchestrator = create_orchestrator_from_config_path(
            "batch-path", str(config_path)
        )
        assert isinstance(orchestrator, DefaultJobOrchestrator)

    def test_passes_display_name_and_description(self, tmp_path: Path) -> None:
        config = _make_config()
        config_path = tmp_path / "config.json"
        config_path.write_text(config.model_dump_json(by_alias=True))

        orchestrator = create_orchestrator_from_config_path(
            "batch-path",
            str(config_path),
            display_name="My Batch",
            description="A batch",
        )
        assert isinstance(orchestrator, DefaultJobOrchestrator)

    def test_raises_for_missing_file(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError):
            create_orchestrator_from_config_path(
                "batch-path", str(tmp_path / "nonexistent.json")
            )


class TestCreateOrchestratorFromConfigJson:
    def test_creates_from_dict(self) -> None:
        config = _make_config()
        data = config.model_dump(by_alias=True)

        orchestrator = create_orchestrator_from_config_json("batch-json", data)
        assert isinstance(orchestrator, DefaultJobOrchestrator)

    def test_creates_from_json_string(self) -> None:
        config = _make_config()
        json_str = config.model_dump_json(by_alias=True)

        orchestrator = create_orchestrator_from_config_json("batch-json", json_str)
        assert isinstance(orchestrator, DefaultJobOrchestrator)

    def test_raises_for_invalid_json_string(self) -> None:
        with pytest.raises(json.JSONDecodeError):
            create_orchestrator_from_config_json("batch-json", "not valid json")

    def test_passes_display_name_and_description(self) -> None:
        config = _make_config()
        data = config.model_dump(by_alias=True)

        orchestrator = create_orchestrator_from_config_json(
            "batch-json",
            data,
            display_name="My Batch",
            description="A batch",
        )
        assert isinstance(orchestrator, DefaultJobOrchestrator)
