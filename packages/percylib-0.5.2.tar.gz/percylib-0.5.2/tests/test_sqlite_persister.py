from __future__ import annotations

import sqlite3
from pathlib import Path

from percylib.jobs.sqlite import create_migrated_jobs_sqlite


class TestCreateMigratedJobsSqlite:
    def test_creates_sqlite_file(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.sqlite"
        assert not db_path.exists()
        create_migrated_jobs_sqlite(db_path)
        assert db_path.exists()

    def test_creates_expected_tables(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.sqlite"
        create_migrated_jobs_sqlite(db_path)

        conn = sqlite3.connect(str(db_path))
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        )
        tables = {row[0] for row in cursor.fetchall()}
        conn.close()

        assert "job_groups" in tables
        assert "jobs" in tables

    def test_table_columns_job_groups(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.sqlite"
        create_migrated_jobs_sqlite(db_path)

        conn = sqlite3.connect(str(db_path))
        cursor = conn.execute("PRAGMA table_info(job_groups)")
        cols = {row[1] for row in cursor.fetchall()}
        conn.close()

        assert cols == {"id", "validation_score"}

    def test_table_columns_jobs(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.sqlite"
        create_migrated_jobs_sqlite(db_path)

        conn = sqlite3.connect(str(db_path))
        cursor = conn.execute("PRAGMA table_info(jobs)")
        cols = {row[1] for row in cursor.fetchall()}
        conn.close()

        assert cols == {"id", "group_id", "status", "input", "output"}

    def test_idempotent(self, tmp_path: Path) -> None:
        db_path = tmp_path / "test.sqlite"
        create_migrated_jobs_sqlite(db_path)
        create_migrated_jobs_sqlite(db_path)  # second call must not error

        conn = sqlite3.connect(str(db_path))
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        )
        tables = {row[0] for row in cursor.fetchall()}
        conn.close()

        assert "job_groups" in tables
        assert "jobs" in tables

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        db_path = tmp_path / "sub" / "nested" / "test.sqlite"
        create_migrated_jobs_sqlite(db_path)
        assert db_path.exists()
