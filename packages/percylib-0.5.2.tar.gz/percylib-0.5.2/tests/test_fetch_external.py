import json
import pathlib
import sys
import zipfile
from datetime import datetime
from unittest.mock import MagicMock, patch

import pytest

from scripts.fetch_external import (
    _ensure_repo_import_paths,
    fetch_release_asset,
    fetch_run_artifact,
    main,
    parse_url,
    write_metadata,
)

# -- parse_url ---------------------------------------------------------------


def test_parse_url_run():
    url = "https://github.com/PercivalTech/percylib/actions/runs/12345"
    assert parse_url(url) == ("run", "PercivalTech/percylib", "12345")


def test_parse_url_release():
    url = "https://github.com/PercivalTech/percylib/releases/tag/v1.0.0"
    assert parse_url(url) == ("release", "PercivalTech/percylib", "v1.0.0")


def test_parse_url_release_complex_tag():
    url = "https://github.com/owner/repo/releases/tag/2024.01.15-rc1"
    assert parse_url(url) == ("release", "owner/repo", "2024.01.15-rc1")


def test_parse_url_invalid():
    with pytest.raises(ValueError, match="Unrecognized GitHub URL format"):
        parse_url("https://example.com/not-a-github-url")


def test_ensure_repo_import_paths_adds_repo_root_and_src(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path
) -> None:
    script_path = tmp_path / "scripts" / "fetch_external.py"
    script_path.parent.mkdir()
    script_path.write_text("")

    monkeypatch.setattr(sys, "path", ["/existing/path"])

    _ensure_repo_import_paths(script_path)
    _ensure_repo_import_paths(script_path)

    assert sys.path[:3] == [
        str(tmp_path),
        str(tmp_path / "src"),
        "/existing/path",
    ]


# -- write_metadata -----------------------------------------------------------


def test_write_metadata_run(tmp_path):
    path = tmp_path / "external_metadata.json"
    write_metadata(path, "run", "98765")
    data = json.loads(path.read_text())
    assert data["runId"] == "98765"
    datetime.fromisoformat(data["timestamp"])


def test_write_metadata_release(tmp_path):
    path = tmp_path / "external_metadata.json"
    write_metadata(path, "release", "v2.0.0")
    data = json.loads(path.read_text())
    assert data["tag"] == "v2.0.0"
    datetime.fromisoformat(data["timestamp"])


# -- fetch_run_artifact -------------------------------------------------------


@patch("scripts.fetch_external.subprocess.run")
def test_fetch_run_artifact(mock_run, tmp_path):
    output_dir = tmp_path / "external"
    output_dir.mkdir()

    def side_effect(cmd, **kwargs):
        # When gh run download is called, create a fake zip in the tmpdir
        if cmd[0] == "gh":
            tmpdir = pathlib.Path(cmd[-1])
            zip_path = tmpdir / "external.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("run_file.txt", "run content")
        return MagicMock(returncode=0)

    mock_run.side_effect = side_effect
    fetch_run_artifact("owner/repo", "111", output_dir)

    assert (output_dir / "run_file.txt").read_text() == "run content"


# -- fetch_release_asset ------------------------------------------------------


@patch("scripts.fetch_external.subprocess.run")
def test_fetch_release_asset(mock_run, tmp_path):
    output_dir = tmp_path / "external"
    output_dir.mkdir()

    def side_effect(cmd, **kwargs):
        # When gh release download is called, create a fake zip in the tmpdir
        if cmd[0] == "gh":
            tmpdir = pathlib.Path(cmd[-1])
            zip_path = tmpdir / "external.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("hello.txt", "hello world")
        return MagicMock(returncode=0)

    mock_run.side_effect = side_effect
    fetch_release_asset("owner/repo", "v1.0.0", output_dir)

    assert (output_dir / "hello.txt").read_text() == "hello world"


# -- main (integration) -------------------------------------------------------


@patch("scripts.fetch_external.get_repo_root")
@patch("scripts.fetch_external.subprocess.run")
def test_main_run_artifact(mock_run, mock_root, tmp_path):
    mock_root.return_value = tmp_path
    url = "https://github.com/owner/repo/actions/runs/42"

    def side_effect(cmd, **kwargs):
        if cmd[0] == "gh":
            tmpdir = pathlib.Path(cmd[-1])
            zip_path = tmpdir / "external.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("run_data.txt", "run data")
        return MagicMock(returncode=0)

    mock_run.side_effect = side_effect

    main([url])

    mock_run.assert_called_once()
    args = mock_run.call_args
    assert args[0][0][0] == "gh"
    assert args[0][0][1] == "run"

    metadata = json.loads((tmp_path / "external_metadata.json").read_text())
    assert metadata["runId"] == "42"
    datetime.fromisoformat(metadata["timestamp"])
    assert (tmp_path / "external").is_dir()
    assert (tmp_path / "external" / "run_data.txt").read_text() == "run data"


@patch("scripts.fetch_external.get_repo_root")
@patch("scripts.fetch_external.subprocess.run")
def test_main_release_artifact(mock_run, mock_root, tmp_path):
    mock_root.return_value = tmp_path
    url = "https://github.com/owner/repo/releases/tag/v3.0.0"

    def side_effect(cmd, **kwargs):
        if cmd[0] == "gh":
            tmpdir = pathlib.Path(cmd[-1])
            zip_path = tmpdir / "external.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("data.txt", "content")
        return MagicMock(returncode=0)

    mock_run.side_effect = side_effect

    main([url])

    metadata = json.loads((tmp_path / "external_metadata.json").read_text())
    assert metadata["tag"] == "v3.0.0"
    datetime.fromisoformat(metadata["timestamp"])
    assert (tmp_path / "external").is_dir()
    assert (tmp_path / "external" / "data.txt").read_text() == "content"


# -- --generate flag ----------------------------------------------------------


@patch("scripts.generate_models.generate_all_models")
@patch("scripts.fetch_external.get_repo_root")
@patch("scripts.fetch_external.subprocess.run")
def test_main_with_generate_flag(mock_run, mock_root, mock_gen, tmp_path):
    mock_root.return_value = tmp_path
    url = "https://github.com/owner/repo/actions/runs/99"

    def side_effect(cmd, **kwargs):
        if cmd[0] == "gh":
            tmpdir = pathlib.Path(cmd[-1])
            zip_path = tmpdir / "external.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("file.txt", "data")
        return MagicMock(returncode=0)

    mock_run.side_effect = side_effect

    main([url, "--generate"])

    mock_gen.assert_called_once_with(tmp_path)


@patch("scripts.fetch_external.get_repo_root")
@patch("scripts.fetch_external.subprocess.run")
def test_main_without_generate_flag_does_not_generate(mock_run, mock_root, tmp_path):
    mock_root.return_value = tmp_path
    url = "https://github.com/owner/repo/actions/runs/99"

    def side_effect(cmd, **kwargs):
        if cmd[0] == "gh":
            tmpdir = pathlib.Path(cmd[-1])
            zip_path = tmpdir / "external.zip"
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("file.txt", "data")
        return MagicMock(returncode=0)

    mock_run.side_effect = side_effect

    # Should not raise even without generate_models available
    main([url])
