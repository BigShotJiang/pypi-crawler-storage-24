from __future__ import annotations

from percylib.external.models import DeepDiffValidation, MaxExactMatchValidation
from percylib.jobs import BaseJobGroupValidator
from percylib.jobs.validators import DeepDiffValidator, MaxExactMatchValidator

# ── MaxExactMatchValidator ──────────────────────────────────────


class TestMaxExactMatchValidator:
    def test_is_base_job_group_validator(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        assert isinstance(validator, BaseJobGroupValidator)

    def test_all_identical_returns_one(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        assert validator.validate([{"a": 1}, {"a": 1}, {"a": 1}]) == 1.0

    def test_all_different_returns_one_over_n(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        assert validator.validate([{"a": 1}, {"a": 2}, {"a": 3}]) == 1 / 3

    def test_majority_match(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        outputs = [{"x": 10}, {"x": 10}, {"x": 99}]
        assert validator.validate(outputs) == 2 / 3

    def test_single_output_returns_one(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        assert validator.validate([{"a": 1}]) == 1.0

    def test_empty_list_returns_one(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        assert validator.validate([]) == 1.0

    def test_ignore_order_true(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=True)
        validator = MaxExactMatchValidator(config)
        outputs = [{"items": [1, 2, 3]}, {"items": [3, 2, 1]}]
        assert validator.validate(outputs) == 1.0

    def test_ignore_order_false(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        outputs = [{"items": [1, 2, 3]}, {"items": [3, 2, 1]}]
        assert validator.validate(outputs) == 0.5

    def test_nested_structures(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        obj = {"a": {"b": [1, 2]}, "c": "hello"}
        outputs = [obj, obj, {"a": {"b": [1, 2]}, "c": "hello"}]
        assert validator.validate(outputs) == 1.0

    def test_primitive_values(self) -> None:
        config = MaxExactMatchValidation(ignoreOrder=False)
        validator = MaxExactMatchValidator(config)
        assert validator.validate(["abc", "abc", "xyz"]) == 2 / 3


# ── DeepDiffValidator ───────────────────────────────────────────


class TestDeepDiffValidator:
    def test_is_base_job_group_validator(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        assert isinstance(validator, BaseJobGroupValidator)

    def test_all_identical_returns_one(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        assert validator.validate([{"a": 1}, {"a": 1}, {"a": 1}]) == 1.0

    def test_single_output_returns_one(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        assert validator.validate([{"a": 1}]) == 1.0

    def test_empty_list_returns_one(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        assert validator.validate([]) == 1.0

    def test_different_outputs_score_below_one(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        score = validator.validate([{"a": 1}, {"a": 2}])
        assert 0.0 <= score < 1.0

    def test_ignore_order_true_lists(self) -> None:
        config = DeepDiffValidation(ignoreOrder=True, maxComparisons=100)
        validator = DeepDiffValidator(config)
        score = validator.validate([{"items": [1, 2, 3]}, {"items": [3, 2, 1]}])
        assert score == 1.0

    def test_ignore_order_false_lists(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        score = validator.validate([{"items": [1, 2, 3]}, {"items": [3, 2, 1]}])
        assert score < 1.0

    def test_max_comparisons_limits_pairs(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=2)
        validator = DeepDiffValidator(config)
        outputs = [{"a": i} for i in range(10)]
        score = validator.validate(outputs)
        # With 10 items, C(10,2) = 45 pairs, but we sample only 2
        assert 0.0 <= score <= 1.0

    def test_max_comparisons_not_exceeded(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        # Only 3 pairs, well under maxComparisons
        outputs = [{"a": 1}, {"a": 1}, {"a": 2}]
        score = validator.validate(outputs)
        assert 0.0 <= score <= 1.0

    def test_score_in_valid_range(self) -> None:
        config = DeepDiffValidation(ignoreOrder=False, maxComparisons=100)
        validator = DeepDiffValidator(config)
        outputs = [{"x": i, "y": "hello"} for i in range(5)]
        score = validator.validate(outputs)
        assert 0.0 <= score <= 1.0
