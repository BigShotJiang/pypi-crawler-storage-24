import json

from percylib import get_data_source_path, get_workspace_path, resolve_file_path


def test_get_workspace_path_found(tmp_path, monkeypatch):
    (tmp_path / ".percy").mkdir()
    monkeypatch.chdir(tmp_path)
    assert get_workspace_path() == str(tmp_path)


def test_get_workspace_path_not_found(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert get_workspace_path() is None


def test_get_data_source_path(tmp_path, monkeypatch):
    percy_dir = tmp_path / ".percy"
    percy_dir.mkdir()
    config = {"sources": {"my_source": {"path": "/data/source"}}}
    (percy_dir / "current-sources.json").write_text(json.dumps(config))
    monkeypatch.chdir(tmp_path)
    assert get_data_source_path("my_source") == "/data/source"


def test_get_data_source_path_missing_source(tmp_path, monkeypatch):
    percy_dir = tmp_path / ".percy"
    percy_dir.mkdir()
    config = {"sources": {}}
    (percy_dir / "current-sources.json").write_text(json.dumps(config))
    monkeypatch.chdir(tmp_path)
    assert get_data_source_path("nonexistent") is None


def test_get_data_source_path_no_workspace(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert get_data_source_path("any") is None


def test_resolve_file_path_workspace(tmp_path, monkeypatch):
    (tmp_path / ".percy").mkdir()
    monkeypatch.chdir(tmp_path)
    result = resolve_file_path(None, "data/file.csv")
    assert result == str((tmp_path / "data" / "file.csv").resolve())


def test_resolve_file_path_with_source(tmp_path, monkeypatch):
    percy_dir = tmp_path / ".percy"
    percy_dir.mkdir()
    external = tmp_path / "external"
    external.mkdir()
    config = {"sources": {"my_source": {"path": str(external)}}}
    (percy_dir / "current-sources.json").write_text(json.dumps(config))
    monkeypatch.chdir(tmp_path)
    result = resolve_file_path("my_source", "file.csv")
    assert result == str((external / "file.csv").resolve())


def test_resolve_file_path_missing_source(tmp_path, monkeypatch):
    percy_dir = tmp_path / ".percy"
    percy_dir.mkdir()
    config = {"sources": {}}
    (percy_dir / "current-sources.json").write_text(json.dumps(config))
    monkeypatch.chdir(tmp_path)
    assert resolve_file_path("nonexistent", "file.csv") is None
