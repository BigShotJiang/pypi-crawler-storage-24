import json
import pathlib
import sys
from unittest.mock import MagicMock, patch

import pytest

from scripts.generate_models import (
    _ensure_repo_import_paths,
    generate_all_models,
    generate_db_models,
    generate_models,
)


def _write_schema(directory: pathlib.Path) -> None:
    """Write a minimal schema.json for testing."""
    schema = {
        "$schema": "https://json-schema.org/draft/2020-12/schema",
        "$defs": {
            "Greeting": {
                "type": "object",
                "properties": {"message": {"type": "string"}},
                "required": ["message"],
                "additionalProperties": False,
            }
        },
    }
    external_dir = directory / "external"
    external_dir.mkdir(parents=True, exist_ok=True)
    (external_dir / "schema.json").write_text(json.dumps(schema))


def _mock_generated_models_write(output_path: pathlib.Path) -> MagicMock:
    def fake_run(*args: object, **kwargs: object) -> MagicMock:
        output_path.write_text("from pydantic import BaseModel\n")
        return MagicMock(returncode=0)

    return MagicMock(side_effect=fake_run)


# -- generate_models ----------------------------------------------------------


def test_ensure_repo_import_paths_adds_repo_root_and_src(
    monkeypatch: pytest.MonkeyPatch, tmp_path: pathlib.Path
) -> None:
    script_path = tmp_path / "scripts" / "generate_models.py"
    script_path.parent.mkdir()
    script_path.write_text("")

    monkeypatch.setattr(sys, "path", ["/existing/path"])

    _ensure_repo_import_paths(script_path)
    _ensure_repo_import_paths(script_path)

    assert sys.path[:3] == [
        str(tmp_path),
        str(tmp_path / "src"),
        "/existing/path",
    ]


@patch("scripts.generate_models.subprocess.run")
def test_generate_models_calls_datamodel_codegen(
    mock_run: MagicMock, tmp_path: pathlib.Path
) -> None:
    _write_schema(tmp_path)
    output_path = tmp_path / "src" / "percylib" / "external" / "models.py"
    output_path.parent.mkdir(parents=True)

    mock_run.side_effect = _mock_generated_models_write(output_path).side_effect
    generate_models(tmp_path)

    mock_run.assert_called_once()
    cmd = mock_run.call_args[0][0]
    assert "-m" in cmd
    assert "datamodel_code_generator" in cmd
    assert str(tmp_path / "external" / "schema.json") in cmd
    assert str(tmp_path / "src" / "percylib" / "external" / "models.py") in cmd
    assert "--use-type-alias" in cmd


def test_generate_models_missing_schema(tmp_path: pathlib.Path) -> None:
    """generate_models exits with an error when schema.json is missing."""
    with pytest.raises(SystemExit):
        generate_models(tmp_path)


def test_generate_models_creates_output_dir(tmp_path: pathlib.Path) -> None:
    """generate_models creates the output directory if it doesn't exist."""
    _write_schema(tmp_path)
    # Don't create the output directory ahead of time

    with patch("scripts.generate_models.subprocess.run") as mock_run:
        output_path = tmp_path / "src" / "percylib" / "external" / "models.py"
        mock_run.side_effect = _mock_generated_models_write(output_path).side_effect
        generate_models(tmp_path)

    assert (tmp_path / "src" / "percylib" / "external").is_dir()


# -- generate_db_models -------------------------------------------------------

_MOCK_TABLES = ["job_groups", "jobs"]


@patch("scripts.generate_models.subprocess.run")
@patch("percylib.jobs.sqlite.create_migrated_jobs_sqlite")
@patch(
    "scripts.generate_models._get_non_yoyo_tables",
    return_value=_MOCK_TABLES,
)
def test_generate_db_models_calls_sqlacodegen(
    mock_tables: MagicMock,
    mock_migrate: MagicMock,
    mock_run: MagicMock,
    tmp_path: pathlib.Path,
) -> None:
    mock_run.return_value = MagicMock(returncode=0)
    generate_db_models(tmp_path)

    mock_migrate.assert_called_once()
    mock_run.assert_called_once()
    cmd = mock_run.call_args[0][0]
    assert "-m" in cmd
    assert "sqlacodegen" in cmd
    assert "--generator" in cmd
    assert "declarative" in cmd
    assert "--tables" in cmd
    tables_idx = cmd.index("--tables")
    assert cmd[tables_idx + 1] == "job_groups,jobs"
    output_path = str(
        tmp_path / "src" / "percylib" / "jobs" / "sqlite" / "db_models.py"
    )
    assert output_path in cmd


@patch("scripts.generate_models.subprocess.run")
@patch("percylib.jobs.sqlite.create_migrated_jobs_sqlite")
@patch(
    "scripts.generate_models._get_non_yoyo_tables",
    return_value=_MOCK_TABLES,
)
def test_generate_db_models_creates_output_dir(
    mock_tables: MagicMock,
    mock_migrate: MagicMock,
    mock_run: MagicMock,
    tmp_path: pathlib.Path,
) -> None:
    """generate_db_models creates the output directory if it doesn't exist."""
    mock_run.return_value = MagicMock(returncode=0)
    generate_db_models(tmp_path)

    assert (tmp_path / "src" / "percylib" / "jobs" / "sqlite").is_dir()


@patch("scripts.generate_models.subprocess.run")
@patch("percylib.jobs.sqlite.create_migrated_jobs_sqlite")
@patch(
    "scripts.generate_models._get_non_yoyo_tables",
    return_value=_MOCK_TABLES,
)
def test_generate_db_models_uses_temp_sqlite(
    mock_tables: MagicMock,
    mock_migrate: MagicMock,
    mock_run: MagicMock,
    tmp_path: pathlib.Path,
) -> None:
    """generate_db_models creates a temporary SQLite file for migrations."""
    mock_run.return_value = MagicMock(returncode=0)
    generate_db_models(tmp_path)

    # The migration function should be called with a temporary path
    db_path = mock_migrate.call_args[0][0]
    assert str(db_path).endswith(".sqlite")

    # The sqlacodegen URL should reference the same temporary db
    cmd = mock_run.call_args[0][0]
    url_arg = [a for a in cmd if a.startswith("sqlite:///")]
    assert len(url_arg) == 1
    assert url_arg[0] == f"sqlite:///{db_path}"


@patch("scripts.generate_models.generate_db_models")
@patch("scripts.generate_models.generate_models")
def test_generate_all_models_runs_both_generators(
    mock_generate_models: MagicMock,
    mock_generate_db_models: MagicMock,
    tmp_path: pathlib.Path,
) -> None:
    generate_all_models(tmp_path)

    mock_generate_models.assert_called_once_with(tmp_path)
    mock_generate_db_models.assert_called_once_with(tmp_path)
