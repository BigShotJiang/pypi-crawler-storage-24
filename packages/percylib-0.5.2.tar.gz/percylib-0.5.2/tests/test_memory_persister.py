from __future__ import annotations

from typing import Any, Optional

from percylib.jobs import BaseJob, MemoryPersister


class _SimpleJob(BaseJob[str]):
    """Minimal concrete job for testing."""

    def __init__(self, job_id: str, payload: str, group: str | None = None) -> None:
        self._id = job_id
        self._payload = payload
        self._group = group

    def id(self) -> str:
        return self._id

    def job_group(self) -> Optional[str]:
        return self._group

    def input(self) -> str:
        return self._payload


# ── Upsert tests ────────────────────────────────────────────────────


class TestUpsertJobs:
    def test_add_single_job(self) -> None:
        persister = MemoryPersister()
        result = persister.upsert_jobs([_SimpleJob("j1", "payload")])
        assert result == [True]

    def test_add_multiple_jobs(self) -> None:
        persister = MemoryPersister()
        jobs: list[BaseJob[Any]] = [_SimpleJob(f"j{i}", f"data{i}") for i in range(5)]
        result = persister.upsert_jobs(jobs)
        assert result == [True] * 5

    def test_returns_false_for_existing_job(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "original")])
        result = persister.upsert_jobs([_SimpleJob("j1", "updated")])
        assert result == [False]

    def test_does_not_overwrite_existing_job(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "original")])
        persister.upsert_jobs([_SimpleJob("j1", "updated")])
        job = persister.pop_pending()
        assert job is not None
        assert job.input() == "original"

    def test_mixed_new_and_existing(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "a")])
        result = persister.upsert_jobs(
            [_SimpleJob("j1", "a"), _SimpleJob("j2", "b"), _SimpleJob("j3", "c")]
        )
        assert result == [False, True, True]

    def test_upsert_preserves_group(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "data", group="grp1")])
        job = persister.pop_pending()
        assert job is not None
        assert job.job_group() == "grp1"


# ── Pop pending tests ──────────────────────────────────────────────


class TestPopPending:
    def test_pop_returns_pending_job(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "hello")])
        job = persister.pop_pending()
        assert job is not None
        assert job.id() == "j1"
        assert job.input() == "hello"

    def test_pop_empty_returns_none(self) -> None:
        persister = MemoryPersister()
        assert persister.pop_pending() is None

    def test_pop_does_not_return_running_jobs(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "a")])
        persister.pop_pending()
        assert persister.pop_pending() is None

    def test_pop_preserves_insertion_order(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "a"), _SimpleJob("j2", "b")])
        first = persister.pop_pending()
        second = persister.pop_pending()
        assert first is not None and first.id() == "j1"
        assert second is not None and second.id() == "j2"


# ── Save success tests ─────────────────────────────────────────────


class TestSaveSuccess:
    def test_save_success_marks_job(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "x")])
        persister.pop_pending()
        persister.save_success("j1", "RESULT")
        assert persister.get_status("j1") == "success"
        assert persister.get_output("j1") == "RESULT"

    def test_save_success_nonexistent_job_is_noop(self) -> None:
        persister = MemoryPersister()
        persister.save_success("nonexistent", "value")


# ── Save failure tests ─────────────────────────────────────────────


class TestSaveFailure:
    def test_save_failure_marks_job(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "x")])
        persister.pop_pending()
        persister.save_failure("j1", RuntimeError("boom"))
        assert persister.get_status("j1") == "failure"
        assert persister.get_output("j1") == "boom"

    def test_save_failure_nonexistent_job_is_noop(self) -> None:
        persister = MemoryPersister()
        persister.save_failure("nonexistent", RuntimeError("oops"))


# ── Mark running as pending tests ──────────────────────────────────


class TestMarkRunningAsPending:
    def test_resets_running_to_pending(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "a"), _SimpleJob("j2", "b")])
        persister.pop_pending()
        persister.pop_pending()
        persister.mark_running_as_pending()
        assert persister.get_status("j1") == "pending"
        assert persister.get_status("j2") == "pending"

    def test_does_not_affect_other_statuses(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "a"), _SimpleJob("j2", "b")])
        persister.pop_pending()
        persister.save_success("j1", "done")
        persister.pop_pending()
        persister.mark_running_as_pending()
        assert persister.get_status("j1") == "success"
        assert persister.get_status("j2") == "pending"


# ── Execution loop test ────────────────────────────────────────────


class TestExecutionLoop:
    def test_process_all_jobs(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "hello"), _SimpleJob("j2", "world")])
        job = persister.pop_pending()
        while job is not None:
            persister.save_success(job.id(), job.input().upper())
            job = persister.pop_pending()
        assert persister.get_output("j1") == "HELLO"
        assert persister.get_output("j2") == "WORLD"


# ── Already-completed jobs are not re-inserted ─────────────────────


class TestUpsertIdempotence:
    def test_completed_job_not_re_inserted(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "a")])
        persister.pop_pending()
        persister.save_success("j1", "done")
        result = persister.upsert_jobs([_SimpleJob("j1", "a")])
        assert result == [False]

    def test_failed_job_not_re_inserted(self) -> None:
        persister = MemoryPersister()
        persister.upsert_jobs([_SimpleJob("j1", "a")])
        persister.pop_pending()
        persister.save_failure("j1", RuntimeError("err"))
        result = persister.upsert_jobs([_SimpleJob("j1", "a")])
        assert result == [False]
