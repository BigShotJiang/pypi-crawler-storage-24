from __future__ import annotations

from pathlib import Path

from sqlalchemy import create_engine, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from percylib.jobs.sqlite import create_migrated_jobs_sqlite
from percylib.jobs.sqlite.db_models import Base, JobGroups, Jobs


class TestDbModels:
    """Integration tests that verify the generated SQLAlchemy models
    work against a real migrated SQLite database."""

    def _create_engine(self, tmp_path: Path) -> Engine:
        db_path = tmp_path / "test.sqlite"
        create_migrated_jobs_sqlite(db_path)
        return create_engine(f"sqlite:///{db_path}")

    def test_models_bind_to_migrated_db(self, tmp_path: Path) -> None:
        """Models can bind to a migrated database without errors."""
        engine = self._create_engine(tmp_path)
        # Verify model metadata matches the existing schema
        Base.metadata.reflect(bind=engine)

    def test_insert_and_query_job_group(self, tmp_path: Path) -> None:
        """A JobGroups row can be inserted and queried back."""
        engine = self._create_engine(tmp_path)
        with Session(engine) as session:
            group = JobGroups(id="g1", validation_score=0.95)
            session.add(group)
            session.commit()

            result = session.execute(
                select(JobGroups).where(JobGroups.id == "g1")
            ).scalar_one()
            assert result.id == "g1"
            assert result.validation_score == 0.95

    def test_insert_and_query_job(self, tmp_path: Path) -> None:
        """A Jobs row can be inserted and queried back."""
        engine = self._create_engine(tmp_path)
        with Session(engine) as session:
            job = Jobs(
                id="j1",
                status="pending",
                input='{"key": "value"}',
                output=None,
            )
            session.add(job)
            session.commit()

            result = session.execute(select(Jobs).where(Jobs.id == "j1")).scalar_one()
            assert result.id == "j1"
            assert result.status == "pending"
            assert result.input == '{"key": "value"}'
            assert result.output is None

    def test_job_group_relationship(self, tmp_path: Path) -> None:
        """A Job linked to a JobGroup can navigate the relationship."""
        engine = self._create_engine(tmp_path)
        with Session(engine) as session:
            group = JobGroups(id="g1", validation_score=0.8)
            job = Jobs(
                id="j1",
                status="success",
                input="data",
                output="result",
                group=group,
            )
            session.add_all([group, job])
            session.commit()

            loaded_job = session.execute(
                select(Jobs).where(Jobs.id == "j1")
            ).scalar_one()
            assert loaded_job.group is not None
            assert loaded_job.group.id == "g1"
            assert loaded_job.group_id == "g1"

            loaded_group = session.execute(
                select(JobGroups).where(JobGroups.id == "g1")
            ).scalar_one()
            assert len(loaded_group.jobs) == 1
            assert loaded_group.jobs[0].id == "j1"
