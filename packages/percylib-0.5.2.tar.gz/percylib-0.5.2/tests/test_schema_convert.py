from __future__ import annotations

import random
from typing import Any

import pytest
from jsonschema.exceptions import SchemaError
from jsonschema.validators import validator_for

from percylib.external.models import (
    ArraySchema,
    ArraySchemaVariant,
    BooleanSchema,
    BooleanSchemaVariant,
    EnumSchema,
    EnumSchemaVariant,
    NumberSchema,
    NumberSchemaVariant,
    ObjectPropertyDefinition,
    ObjectSchema,
    ObjectSchemaVariant,
    RecordSchema,
    RecordSchemaVariant,
    StringSchema,
    StringSchemaVariant,
    ValueSchema,
)
from percylib.schemas.schema_convert import value_schema_to_json_schema


def is_valid_json_schema(schema: dict[str, Any]) -> bool:
    try:
        validator_for(schema).check_schema(schema)
        return True
    except SchemaError:
        return False


def _random_value_schema(rng: random.Random, depth: int = 0) -> ValueSchema:
    """Generate a random valid ValueSchema from a seeded RNG."""
    max_depth = 3
    if depth >= max_depth:
        choices = ["number", "boolean", "string", "enum"]
    else:
        choices = ["number", "boolean", "string", "enum", "array", "object", "record"]

    kind = rng.choice(choices)

    if kind == "number":
        return NumberSchemaVariant(
            type="number",
            value=NumberSchema(integerOnly=rng.choice([True, False])),
        )

    if kind == "boolean":
        return BooleanSchemaVariant(type="boolean", value=BooleanSchema())

    if kind == "string":
        return StringSchemaVariant(type="string", value=StringSchema())

    if kind == "enum":
        n_options = rng.randint(1, 5)
        options = [f"opt_{i}" for i in range(n_options)]
        return EnumSchemaVariant(type="enum", value=EnumSchema(options=options))

    if kind == "array":
        item = _random_value_schema(rng, depth + 1)
        return ArraySchemaVariant(type="array", value=ArraySchema(item=item))

    if kind == "object":
        n_props = rng.randint(0, 4)
        properties: list[ObjectPropertyDefinition] = []
        for i in range(n_props):
            prop_data: dict[str, object] = {
                "key": f"prop_{i}",
                "optional": rng.choice([True, False]),
                "schema": _random_value_schema(rng, depth + 1),
            }
            if rng.choice([True, False]):
                prop_data["description"] = f"Description for prop_{i}"
            properties.append(ObjectPropertyDefinition.model_validate(prop_data))
        return ObjectSchemaVariant(
            type="object",
            value=ObjectSchema(properties=properties),
        )

    return RecordSchemaVariant(
        type="record",
        value=RecordSchema(valueSchema=_random_value_schema(rng, depth + 1)),
    )


class TestValueSchemaToJsonSchema:
    def test_number_schema(self) -> None:
        vs = NumberSchemaVariant(
            type="number",
            value=NumberSchema(integerOnly=False),
        )
        result = value_schema_to_json_schema(vs)
        assert result == {"type": "number"}
        assert is_valid_json_schema(result)

    def test_integer_schema(self) -> None:
        vs = NumberSchemaVariant(
            type="number",
            value=NumberSchema(integerOnly=True),
        )
        result = value_schema_to_json_schema(vs)
        assert result == {"type": "integer"}
        assert is_valid_json_schema(result)

    def test_boolean_schema(self) -> None:
        vs = BooleanSchemaVariant(type="boolean", value=BooleanSchema())
        result = value_schema_to_json_schema(vs)
        assert result == {"type": "boolean"}
        assert is_valid_json_schema(result)

    def test_string_schema(self) -> None:
        vs = StringSchemaVariant(type="string", value=StringSchema())
        result = value_schema_to_json_schema(vs)
        assert result == {"type": "string"}
        assert is_valid_json_schema(result)

    def test_enum_schema(self) -> None:
        vs = EnumSchemaVariant(
            type="enum",
            value=EnumSchema(options=["a", "b", "c"]),
        )
        result = value_schema_to_json_schema(vs)
        assert result == {"type": "string", "enum": ["a", "b", "c"]}
        assert is_valid_json_schema(result)

    def test_array_schema(self) -> None:
        vs = ArraySchemaVariant(
            type="array",
            value=ArraySchema(
                item=StringSchemaVariant(type="string", value=StringSchema())
            ),
        )
        result = value_schema_to_json_schema(vs)
        assert result == {"type": "array", "items": {"type": "string"}}
        assert is_valid_json_schema(result)

    def test_object_schema_all_required(self) -> None:
        vs = ObjectSchemaVariant(
            type="object",
            value=ObjectSchema(
                properties=[
                    ObjectPropertyDefinition.model_validate(
                        {
                            "key": "name",
                            "optional": False,
                            "schema": StringSchemaVariant(
                                type="string",
                                value=StringSchema(),
                            ),
                        }
                    ),
                    ObjectPropertyDefinition.model_validate(
                        {
                            "key": "age",
                            "optional": False,
                            "schema": NumberSchemaVariant(
                                type="number",
                                value=NumberSchema(integerOnly=True),
                            ),
                        }
                    ),
                ]
            ),
        )
        result = value_schema_to_json_schema(vs)
        assert result["type"] == "object"
        assert result["properties"]["name"] == {"type": "string"}
        assert result["properties"]["age"] == {"type": "integer"}
        assert set(result["required"]) == {"name", "age"}
        assert result["additionalProperties"] is False
        assert is_valid_json_schema(result)

    def test_object_schema_with_optional_properties(self) -> None:
        vs = ObjectSchemaVariant(
            type="object",
            value=ObjectSchema(
                properties=[
                    ObjectPropertyDefinition.model_validate(
                        {
                            "key": "name",
                            "optional": False,
                            "schema": StringSchemaVariant(
                                type="string",
                                value=StringSchema(),
                            ),
                        }
                    ),
                    ObjectPropertyDefinition.model_validate(
                        {
                            "key": "nickname",
                            "optional": True,
                            "schema": StringSchemaVariant(
                                type="string",
                                value=StringSchema(),
                            ),
                        }
                    ),
                ]
            ),
        )
        result = value_schema_to_json_schema(vs)
        assert result["type"] == "object"
        assert result["properties"]["name"] == {"type": "string"}
        assert result["properties"]["nickname"] == {
            "anyOf": [{"type": "string"}, {"type": "null"}],
        }
        assert "name" in result["required"]
        assert "nickname" in result["required"]
        assert is_valid_json_schema(result)

    def test_object_schema_empty_properties(self) -> None:
        vs = ObjectSchemaVariant(
            type="object",
            value=ObjectSchema(properties=[]),
        )
        result = value_schema_to_json_schema(vs)
        assert result["type"] == "object"
        assert result["properties"] == {}
        assert result["additionalProperties"] is False
        assert "required" not in result
        assert is_valid_json_schema(result)

    def test_record_schema(self) -> None:
        vs = RecordSchemaVariant(
            type="record",
            value=RecordSchema(
                valueSchema=NumberSchemaVariant(
                    type="number",
                    value=NumberSchema(integerOnly=False),
                )
            ),
        )
        result = value_schema_to_json_schema(vs)
        assert result == {
            "type": "object",
            "additionalProperties": {"type": "number"},
        }
        assert is_valid_json_schema(result)

    def test_nested_array_of_objects(self) -> None:
        vs = ArraySchemaVariant(
            type="array",
            value=ArraySchema(
                item=ObjectSchemaVariant(
                    type="object",
                    value=ObjectSchema(
                        properties=[
                            ObjectPropertyDefinition.model_validate(
                                {
                                    "key": "id",
                                    "optional": False,
                                    "schema": NumberSchemaVariant(
                                        type="number",
                                        value=NumberSchema(integerOnly=True),
                                    ),
                                }
                            ),
                        ]
                    ),
                )
            ),
        )
        result = value_schema_to_json_schema(vs)
        assert result["type"] == "array"
        assert result["items"]["type"] == "object"
        assert result["items"]["properties"]["id"] == {"type": "integer"}
        assert is_valid_json_schema(result)

    def test_object_schema_with_description(self) -> None:
        vs = ObjectSchemaVariant(
            type="object",
            value=ObjectSchema(
                properties=[
                    ObjectPropertyDefinition.model_validate(
                        {
                            "key": "name",
                            "optional": False,
                            "description": "The user's full name",
                            "schema": StringSchemaVariant(
                                type="string",
                                value=StringSchema(),
                            ),
                        }
                    ),
                    ObjectPropertyDefinition.model_validate(
                        {
                            "key": "age",
                            "optional": False,
                            "schema": NumberSchemaVariant(
                                type="number",
                                value=NumberSchema(integerOnly=True),
                            ),
                        }
                    ),
                ]
            ),
        )
        result = value_schema_to_json_schema(vs)
        assert result["properties"]["name"] == {
            "type": "string",
            "description": "The user's full name",
        }
        assert result["properties"]["age"] == {"type": "integer"}
        assert is_valid_json_schema(result)

    def test_object_schema_optional_with_description(self) -> None:
        vs = ObjectSchemaVariant(
            type="object",
            value=ObjectSchema(
                properties=[
                    ObjectPropertyDefinition.model_validate(
                        {
                            "key": "nickname",
                            "optional": True,
                            "description": "An optional nickname",
                            "schema": StringSchemaVariant(
                                type="string",
                                value=StringSchema(),
                            ),
                        }
                    ),
                ]
            ),
        )
        result = value_schema_to_json_schema(vs)
        assert result["properties"]["nickname"] == {
            "anyOf": [{"type": "string"}, {"type": "null"}],
            "description": "An optional nickname",
        }
        assert is_valid_json_schema(result)

    @pytest.mark.parametrize("seed", range(50))
    def test_random_value_schemas_produce_valid_json_schema(self, seed: int) -> None:
        rng = random.Random(seed)
        vs = _random_value_schema(rng)
        result = value_schema_to_json_schema(vs)
        assert isinstance(result, dict)
        assert is_valid_json_schema(result), (
            f"Seed {seed} produced invalid JSON schema: {result}"
        )
