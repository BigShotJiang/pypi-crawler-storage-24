from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Optional, Protocol, cast

from pydantic_ai.models import Model
from pydantic_ai.settings import ModelSettings

from percylib.external.models import (
    JobLanguageModelSpec,
    LanguageModelType,
    PercyJobLanguageModelSpecVariant,
)

DEFAULT_PERCY_BASE_URL = "https://percy.percivaltech.com"


class AiModelProvider(Protocol):
    """Build a Pydantic AI model from a Percy job model spec."""

    def get_model(self, spec: JobLanguageModelSpec) -> Model:
        """Return a model for the given Percy job model specification."""
        ...


@dataclass(frozen=True)
class _ResolvedModel:
    provider: str
    model_name: str
    settings: Optional[dict[str, Any]] = None


def _openai_model(
    model_name: str, *, reasoning_effort: Optional[str] = None
) -> _ResolvedModel:
    settings: Optional[dict[str, Any]] = None
    if reasoning_effort is not None:
        settings = {"openai_reasoning_effort": reasoning_effort}
    return _ResolvedModel(provider="openai", model_name=model_name, settings=settings)


def _gemini_model(model_name: str) -> _ResolvedModel:
    return _ResolvedModel(provider="gemini", model_name=model_name)


def _anthropic_model(
    model_name: str, *, thinking_budget_tokens: Optional[int] = None
) -> _ResolvedModel:
    settings: Optional[dict[str, Any]] = None
    if thinking_budget_tokens is not None:
        settings = {
            "anthropic_thinking": {
                "type": "enabled",
                "budget_tokens": thinking_budget_tokens,
            }
        }
    return _ResolvedModel(
        provider="anthropic",
        model_name=model_name,
        settings=settings,
    )


_PERCY_MODEL_SPECS = {
    LanguageModelType.openai_4_1: _openai_model("gpt-4.1"),
    LanguageModelType.openai_4_1_mini: _openai_model("gpt-4.1-mini"),
    LanguageModelType.openai_4_1_nano: _openai_model("gpt-4.1-nano"),
    LanguageModelType.openai_5: _openai_model("gpt-5"),
    LanguageModelType.openai_5_minimal: _openai_model(
        "gpt-5", reasoning_effort="minimal"
    ),
    LanguageModelType.openai_5_low: _openai_model("gpt-5", reasoning_effort="low"),
    LanguageModelType.openai_5_high: _openai_model("gpt-5", reasoning_effort="high"),
    LanguageModelType.openai_5_mini: _openai_model("gpt-5-mini"),
    LanguageModelType.openai_5_mini_minimal: _openai_model(
        "gpt-5-mini", reasoning_effort="minimal"
    ),
    LanguageModelType.openai_5_mini_low: _openai_model(
        "gpt-5-mini", reasoning_effort="low"
    ),
    LanguageModelType.openai_5_mini_high: _openai_model(
        "gpt-5-mini", reasoning_effort="high"
    ),
    LanguageModelType.openai_5_nano: _openai_model("gpt-5-nano"),
    LanguageModelType.openai_5_codex: _openai_model("gpt-5-codex"),
    LanguageModelType.openai_5_codex_minimal: _openai_model(
        "gpt-5-codex", reasoning_effort="minimal"
    ),
    LanguageModelType.openai_5_codex_low: _openai_model(
        "gpt-5-codex", reasoning_effort="low"
    ),
    LanguageModelType.openai_5_codex_high: _openai_model(
        "gpt-5-codex", reasoning_effort="high"
    ),
    LanguageModelType.openai_5_2: _openai_model("gpt-5.2"),
    LanguageModelType.openai_5_2_codex: _openai_model("gpt-5.2-codex"),
    LanguageModelType.openai_5_3_codex: _openai_model("gpt-5.3-codex"),
    LanguageModelType.openai_5_4: _openai_model("gpt-5.4"),
    LanguageModelType.gemini_2_5_flash: _gemini_model("gemini-2.5-flash"),
    LanguageModelType.gemini_2_5_pro: _gemini_model("gemini-2.5-pro"),
    LanguageModelType.gemini_3_1_pro_preview: _gemini_model("gemini-3.1-pro-preview"),
    LanguageModelType.gemini_3_1_pro_preview_customtools: _gemini_model(
        "gemini-3.1-pro-preview"
    ),
    LanguageModelType.gemini_3_1_flash_lite_preview: _gemini_model(
        "gemini-3.1-flash-lite-preview"
    ),
    LanguageModelType.gemini_3_pro_preview: _gemini_model("gemini-3-pro-preview"),
    LanguageModelType.gemini_3_flash_preview: _gemini_model("gemini-3-flash-preview"),
    LanguageModelType.claude_sonnet_4_5: _anthropic_model("claude-sonnet-4-5"),
    LanguageModelType.claude_sonnet_4_5_thinking: _anthropic_model(
        "claude-sonnet-4-5", thinking_budget_tokens=1024
    ),
    LanguageModelType.claude_sonnet_4_6: _anthropic_model("claude-sonnet-4-6"),
    LanguageModelType.claude_sonnet_4_6_thinking: _anthropic_model(
        "claude-sonnet-4-6", thinking_budget_tokens=1024
    ),
    LanguageModelType.claude_haiku_4_5: _anthropic_model("claude-haiku-4-5"),
    LanguageModelType.claude_opus_4_5: _anthropic_model("claude-opus-4-5"),
    LanguageModelType.claude_opus_4_6: _anthropic_model("claude-opus-4-6"),
}

_PROXY_PATHS = {
    "openai": "/proxy/openai",
    "gemini": "/proxy/gemini",
    "anthropic": "/proxy/anthropic",
}


class DefaultAiModelProvider:
    """Resolve Percy model specs to Pydantic AI model instances."""

    def get_model(self, spec: JobLanguageModelSpec) -> Model:
        if spec.type == "custom":
            raise ValueError(
                "Custom model specs are not supported by DefaultAiModelProvider."
            )

        percy_spec = cast(PercyJobLanguageModelSpecVariant, spec)
        resolved = _PERCY_MODEL_SPECS.get(percy_spec.value.model)
        if resolved is None:
            raise ValueError(
                f"Percy model {percy_spec.value.model.value!r} is not supported by "
                "DefaultAiModelProvider."
            )

        auth_token = _get_percy_auth_token()
        base_url = _build_proxy_base_url(resolved.provider)

        if resolved.provider == "openai":
            return _create_openai_model(
                model_name=resolved.model_name,
                base_url=base_url,
                auth_token=auth_token,
                settings=resolved.settings,
            )
        if resolved.provider == "gemini":
            return _create_google_model(
                model_name=resolved.model_name,
                base_url=base_url,
                auth_token=auth_token,
                settings=resolved.settings,
            )
        if resolved.provider == "anthropic":
            return _create_anthropic_model(
                model_name=resolved.model_name,
                base_url=base_url,
                auth_token=auth_token,
                settings=resolved.settings,
            )

        raise ValueError(
            f"Unsupported Percy model provider {resolved.provider!r} "
            "for DefaultAiModelProvider."
        )


def _get_percy_auth_token() -> str:
    auth_token = os.getenv("PERCY_AUTH_TOKEN")
    if not auth_token:
        raise ValueError(
            "PERCY_AUTH_TOKEN environment variable is required to create Percy AI "
            "models."
        )
    return auth_token


def _build_proxy_base_url(provider: str) -> str:
    base_url = os.getenv("PERCY_BASE_URL") or DEFAULT_PERCY_BASE_URL
    return f"{base_url.rstrip('/')}{_PROXY_PATHS[provider]}"


def _create_openai_model(
    *,
    model_name: str,
    base_url: str,
    auth_token: str,
    settings: Optional[dict[str, Any]],
) -> Model:
    from openai import AsyncOpenAI
    from pydantic_ai.models.openai import OpenAIResponsesModel
    from pydantic_ai.providers.openai import OpenAIProvider

    client = AsyncOpenAI(
        api_key=auth_token,
        base_url=base_url,
        default_headers={"Authorization": f"Bearer {auth_token}"},
    )
    provider = OpenAIProvider(openai_client=client)
    return OpenAIResponsesModel(
        model_name,
        provider=provider,
        settings=cast(Optional[ModelSettings], settings),
    )


def _create_google_model(
    *,
    model_name: str,
    base_url: str,
    auth_token: str,
    settings: Optional[dict[str, Any]],
) -> Model:
    from google.genai import Client
    from pydantic_ai.models.google import GoogleModel
    from pydantic_ai.providers.google import GoogleProvider

    client = Client(
        vertexai=False,
        api_key=auth_token,
        http_options={
            "base_url": base_url,
            "headers": {"Authorization": f"Bearer {auth_token}"},
        },
    )
    provider = GoogleProvider(client=client)
    return GoogleModel(
        model_name,
        provider=provider,
        settings=cast(Optional[ModelSettings], settings),
    )


def _create_anthropic_model(
    *,
    model_name: str,
    base_url: str,
    auth_token: str,
    settings: Optional[dict[str, Any]],
) -> Model:
    from anthropic import AsyncAnthropic
    from pydantic_ai.models.anthropic import AnthropicModel
    from pydantic_ai.providers.anthropic import AnthropicProvider

    client = AsyncAnthropic(
        auth_token=auth_token,
        base_url=base_url,
        default_headers={"Authorization": f"Bearer {auth_token}"},
    )
    provider = AnthropicProvider(anthropic_client=client)
    return AnthropicModel(
        model_name,
        provider=provider,
        settings=cast(Optional[ModelSettings], settings),
    )
