CREATE TABLE `job_groups` (
	`id` text PRIMARY KEY,
	`validation_score` real
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` text PRIMARY KEY,
	`group_id` text,
	`status` text NOT NULL,
	`input` text NOT NULL,
	`output` text,
	CONSTRAINT `fk_jobs_group_id_job_groups_id_fk` FOREIGN KEY (`group_id`) REFERENCES `job_groups`(`id`)
);
