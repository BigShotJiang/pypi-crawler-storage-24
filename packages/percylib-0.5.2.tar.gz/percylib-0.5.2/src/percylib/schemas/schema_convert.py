from __future__ import annotations

from pydantic.json_schema import JsonSchemaValue

from percylib.external.models import (
    ArraySchemaVariant,
    BooleanSchemaVariant,
    EnumSchemaVariant,
    NumberSchemaVariant,
    ObjectSchemaVariant,
    RecordSchemaVariant,
    StringSchemaVariant,
    ValueSchema,
)


def value_schema_to_json_schema(value_schema: ValueSchema) -> JsonSchemaValue:
    """Convert a ValueSchema to a valid JSON Schema (JsonSchemaValue).

    Properties that are optional in the ValueSchema are represented as nullable
    in the JSON schema but still marked as required.
    """
    return _convert_variant(value_schema)


def _convert_variant(
    variant: (
        NumberSchemaVariant
        | BooleanSchemaVariant
        | StringSchemaVariant
        | EnumSchemaVariant
        | ArraySchemaVariant
        | ObjectSchemaVariant
        | RecordSchemaVariant
    ),
) -> JsonSchemaValue:
    if isinstance(variant, NumberSchemaVariant):
        if variant.value.integerOnly:
            return {"type": "integer"}
        return {"type": "number"}

    if isinstance(variant, BooleanSchemaVariant):
        return {"type": "boolean"}

    if isinstance(variant, StringSchemaVariant):
        return {"type": "string"}

    if isinstance(variant, EnumSchemaVariant):
        return {"type": "string", "enum": list(variant.value.options)}

    if isinstance(variant, ArraySchemaVariant):
        return {
            "type": "array",
            "items": value_schema_to_json_schema(variant.value.item),
        }

    if isinstance(variant, ObjectSchemaVariant):
        properties: dict[str, JsonSchemaValue] = {}
        required: list[str] = []
        for prop_def in variant.value.properties:
            inner_schema = value_schema_to_json_schema(prop_def.schema_)
            if prop_def.optional:
                # Nullable but still required
                prop_schema: JsonSchemaValue = {
                    "anyOf": [inner_schema, {"type": "null"}],
                }
            else:
                prop_schema = inner_schema
            if prop_def.description is not None:
                prop_schema["description"] = prop_def.description
            properties[prop_def.key] = prop_schema
            required.append(prop_def.key)

        result: JsonSchemaValue = {
            "type": "object",
            "properties": properties,
            "additionalProperties": False,
        }
        if required:
            result["required"] = required
        return result

    # RecordSchemaVariant
    return {
        "type": "object",
        "additionalProperties": value_schema_to_json_schema(variant.value.valueSchema),
    }
