from __future__ import annotations

from typing import Any

from percylib.jobs import BaseJobPersister, JobT, SuccessT


class MemoryPersister(BaseJobPersister[JobT, SuccessT]):
    """In-memory job persister for testing.

    Stores all job state in plain Python data structures with no
    external dependencies.  Useful for unit tests and quick
    experiments that don't need durable storage.

    Generic over the job type and success type, so original job
    objects are preserved as-is (no serialization).
    """

    def __init__(self) -> None:
        self._pending: list[JobT] = []
        self._running: list[JobT] = []
        self._successes: dict[str, SuccessT] = {}
        self._failures: dict[str, Exception] = {}

    def upsert_jobs(self, jobs: list[JobT]) -> list[bool]:
        """Upsert a list of jobs with status ``pending``.

        Returns a list of booleans parallel to *jobs*: ``True`` when the
        job was newly added, ``False`` when it already existed (in which
        case the existing record is left unchanged).
        """
        results: list[bool] = []
        existing_ids = {j.id() for j in self._pending + self._running}
        existing_ids |= set(self._successes) | set(self._failures)
        for job in jobs:
            if job.id() in existing_ids:
                results.append(False)
            else:
                self._pending.append(job)
                existing_ids.add(job.id())
                results.append(True)
        return results

    def pop_pending(self) -> JobT | None:
        """Pop a pending job, mark it as running, and return it."""
        if not self._pending:
            return None
        job = self._pending.pop(0)
        self._running.append(job)
        return job

    def save_success(self, job_id: str, value: SuccessT) -> None:
        """Mark a job as successful and store its output."""
        self._running = [j for j in self._running if j.id() != job_id]
        self._successes[job_id] = value

    def save_failure(self, job_id: str, error: Exception) -> None:
        """Mark a job as failed and store the error message."""
        self._running = [j for j in self._running if j.id() != job_id]
        self._failures[job_id] = error

    def mark_running_as_pending(self) -> None:
        """Reset all running jobs back to pending."""
        self._pending.extend(self._running)
        self._running.clear()

    # ── Query helpers (useful in tests) ─────────────────────────────

    def get_status(self, job_id: str) -> str | None:
        """Return the status of a job, or ``None`` if it doesn't exist."""
        if job_id in self._successes:
            return "success"
        if job_id in self._failures:
            return "failure"
        if any(j.id() == job_id for j in self._running):
            return "running"
        if any(j.id() == job_id for j in self._pending):
            return "pending"
        return None

    def get_output(self, job_id: str) -> Any:
        """Return the output stored for a job, or ``None`` if not found."""
        if job_id in self._successes:
            return self._successes[job_id]
        if job_id in self._failures:
            return str(self._failures[job_id])
        return None
