from typing import List, Optional

from sqlalchemy import ForeignKey, REAL, Text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship

class Base(DeclarativeBase):
    pass


class JobGroups(Base):
    __tablename__ = 'job_groups'

    id: Mapped[Optional[str]] = mapped_column(Text, primary_key=True)
    validation_score: Mapped[Optional[float]] = mapped_column(REAL)

    jobs: Mapped[List['Jobs']] = relationship('Jobs', back_populates='group')


class Jobs(Base):
    __tablename__ = 'jobs'

    status: Mapped[str] = mapped_column(Text)
    input: Mapped[str] = mapped_column(Text)
    id: Mapped[Optional[str]] = mapped_column(Text, primary_key=True)
    group_id: Mapped[Optional[str]] = mapped_column(ForeignKey('job_groups.id'))
    output: Mapped[Optional[str]] = mapped_column(Text)

    group: Mapped[Optional['JobGroups']] = relationship('JobGroups', back_populates='jobs')
