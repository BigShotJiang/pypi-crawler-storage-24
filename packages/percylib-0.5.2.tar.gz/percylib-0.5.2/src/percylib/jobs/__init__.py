from __future__ import annotations

import sys
from abc import ABC, abstractmethod
from collections.abc import Iterator
from typing import Any, Generic, Literal, Optional, TypeVar

from percylib.external.models import JobEvent

InputT = TypeVar("InputT")

JobStatus = Literal["pending", "running", "success", "failure"]


class BaseJob(ABC, Generic[InputT]):
    """An atomic unit of work that cannot be further subdivided."""

    @abstractmethod
    def id(self) -> str:
        """Return a unique identifier for this job."""
        ...

    @abstractmethod
    def job_group(self) -> Optional[str]:
        """Return a job group if this job is one iteration in a group.

        Useful when running an LLM against the same input for
        robustness, for example.
        """
        ...

    @abstractmethod
    def input(self) -> InputT:
        """Return information about the input for this job."""
        ...


JobT = TypeVar("JobT", bound=BaseJob[Any])
OutputT = TypeVar("OutputT")
SuccessT = TypeVar("SuccessT")


class BaseJobLoader(ABC, Generic[JobT]):
    """Loads jobs from an external source."""

    @abstractmethod
    def load_jobs(self) -> Iterator[JobT]:
        """Load and yield jobs one at a time."""
        ...


class BaseJobExecutor(ABC, Generic[JobT, OutputT]):
    """Executes a given job, producing an output."""

    @abstractmethod
    def execute_job(self, job: JobT) -> OutputT:
        """Execute a single job and return its output."""
        ...


class BaseJobPersister(ABC, Generic[JobT, SuccessT]):
    """Persist and manage the lifecycle of jobs."""

    @abstractmethod
    def upsert_jobs(self, jobs: list[JobT]) -> list[bool]:
        """Upsert a list of jobs.

        Returns a list of booleans parallel to *jobs*: ``True`` when the
        job was newly added, ``False`` when it already existed (in which
        case the existing record is left unchanged).
        """
        ...

    @abstractmethod
    def pop_pending(self) -> JobT | None:
        """Pop a pending job from the queue and mark it as running.

        The implementation must mark the returned job as running.
        """
        ...

    @abstractmethod
    def save_success(self, job_id: str, value: SuccessT) -> None:
        """Save a successful job result."""
        ...

    @abstractmethod
    def save_failure(self, job_id: str, error: Exception) -> None:
        """Save that a job failed."""
        ...

    @abstractmethod
    def mark_running_as_pending(self) -> None:
        """Mark all running jobs as pending."""
        ...


class BaseJobGroupValidator(ABC, Generic[OutputT]):
    """Calculate a validation score in [0, 1] based on a list of job outputs

    A higher score should represent better consistency among the outputs.
    If all of the inputs are identical, the score MUST be 1.
    """

    @abstractmethod
    def validate(self, outputs: list[OutputT]) -> float:
        """Calculate a validation score for a group of job outputs."""
        ...


class BaseEventSink(ABC):
    """Abstract base class for consuming job events."""

    @abstractmethod
    def consume_event(self, event: JobEvent) -> None:
        """Consume a single job event."""
        ...


class StderrEventSink(BaseEventSink):
    """Event sink that writes events to stderr as modified JSONL lines."""

    def consume_event(self, event: JobEvent) -> None:
        """Write the event to stderr in the format: #percy#<json>"""
        json_str = event.model_dump_json()
        sys.stderr.write(f"#percy#{json_str}\n")


# Re-export MemoryPersister so users can do:
#   from percylib.jobs import MemoryPersister
from percylib.jobs.memory_persister import MemoryPersister  # noqa: E402

__all__ = [
    "BaseEventSink",
    "BaseJob",
    "BaseJobExecutor",
    "BaseJobGroupValidator",
    "BaseJobLoader",
    "BaseJobPersister",
    "InputT",
    "JobStatus",
    "JobT",
    "MemoryPersister",
    "OutputT",
    "StderrEventSink",
    "SuccessT",
]
