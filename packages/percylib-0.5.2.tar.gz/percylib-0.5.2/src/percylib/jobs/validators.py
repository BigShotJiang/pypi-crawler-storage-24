from __future__ import annotations

import random
from collections import Counter
from math import comb
from typing import Any

from deepdiff import DeepDiff, DeepHash

from percylib.external.models import DeepDiffValidation, MaxExactMatchValidation
from percylib.jobs import BaseJobGroupValidator


class MaxExactMatchValidator(BaseJobGroupValidator[Any]):
    """Calculate a validation score based on the max number of exact matches.

    Uses DeepHash to compute deep hashes, then counts how many outputs
    share the most common hash.  Score = max_count / total_count.
    """

    def __init__(self, config: MaxExactMatchValidation) -> None:
        self._config = config

    def validate(self, outputs: list[Any]) -> float:
        if len(outputs) <= 1:
            return 1.0

        counts: Counter[str] = Counter()
        for output in outputs:
            h = DeepHash(output, ignore_iterable_order=self._config.ignoreOrder)
            counts[h[output]] += 1

        return counts.most_common(1)[0][1] / len(outputs)


class DeepDiffValidator(BaseJobGroupValidator[Any]):
    """Calculate a validation score via pairwise deep-distance comparisons.

    Uses DeepDiff's deep distance to compute the average pairwise distance
    among job outputs.  Score = 1 - average_distance.

    When the number of pairs exceeds *maxComparisons*, a random sample of
    *maxComparisons* pairs is used instead of the full set.
    """

    def __init__(self, config: DeepDiffValidation) -> None:
        self._config = config

    def validate(self, outputs: list[Any]) -> float:
        n = len(outputs)
        if n <= 1:
            return 1.0

        pairs: list[tuple[int, int]] = [
            (i, j) for i in range(n) for j in range(i + 1, n)
        ]

        total_pairs = comb(n, 2)
        if total_pairs > self._config.maxComparisons:
            pairs = random.sample(pairs, self._config.maxComparisons)

        total_distance = 0.0
        for i, j in pairs:
            diff = DeepDiff(
                outputs[i],
                outputs[j],
                ignore_order=self._config.ignoreOrder,
                get_deep_distance=True,
            )
            total_distance += diff.get("deep_distance", 0)

        avg_distance = total_distance / len(pairs)
        return 1.0 - avg_distance
