"""Bump the version in pyproject.toml.

Usage:
    python scripts/bump_version.py patch|minor|major
    python scripts/bump_version.py --override 1.2.3

Prints the new version (prefixed with 'v') to stdout.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

import semver
import tomlkit


def _get_repo_root() -> Path:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
        check=True,
    )
    return Path(result.stdout.strip())


def _read_pyproject(pyproject: Path) -> tomlkit.TOMLDocument:
    return tomlkit.parse(pyproject.read_text())


def _get_current_version(doc: tomlkit.TOMLDocument) -> semver.Version:
    raw = doc.get("project", {}).get("version")
    if not raw:
        print("Error: could not find version in pyproject.toml", file=sys.stderr)
        sys.exit(1)
    try:
        return semver.Version.parse(raw)
    except ValueError:
        print(
            f"Error: '{raw}' is not a valid semver string",
            file=sys.stderr,
        )
        sys.exit(1)


def _bump_semver(version: semver.Version, bump_type: str) -> semver.Version:
    return version.next_version(part=bump_type)


def _write_version(
    pyproject: Path, doc: tomlkit.TOMLDocument, new_version: semver.Version
) -> None:
    doc["project"]["version"] = str(new_version)  # type: ignore[index]
    pyproject.write_text(tomlkit.dumps(doc))


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Bump the percylib version.")
    parser.add_argument(
        "bump_type",
        nargs="?",
        choices=["patch", "minor", "major"],
        default="patch",
        help="Semver bump type (default: patch)",
    )
    parser.add_argument(
        "--override",
        default=None,
        help="Explicit version string (takes precedence over bump_type)",
    )

    args = parser.parse_args(argv)

    repo_root = _get_repo_root()
    pyproject = repo_root / "pyproject.toml"
    doc = _read_pyproject(pyproject)
    current = _get_current_version(doc)

    if args.override:
        try:
            new_version = semver.Version.parse(args.override)
        except ValueError:
            print(
                f"Error: '{args.override}' is not a valid semver string",
                file=sys.stderr,
            )
            sys.exit(1)
    else:
        new_version = _bump_semver(current, args.bump_type)

    _write_version(pyproject, doc, new_version)
    print(f"v{new_version}")


if __name__ == "__main__":
    main()
