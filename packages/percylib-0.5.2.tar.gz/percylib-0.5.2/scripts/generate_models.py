#!/usr/bin/env python3
"""Generate models from external schemas and database migrations.

Usage:
    python scripts/generate_models.py
"""

from __future__ import annotations

import pathlib
import sqlite3
import subprocess
import sys
import tempfile


def _ensure_repo_import_paths(script_path: pathlib.Path | None = None) -> None:
    """Add the repository root and ``src/`` to ``sys.path`` for direct execution."""
    if script_path is None:
        script_path = pathlib.Path(__file__).resolve()

    repo_root = script_path.parent.parent
    for path in reversed((repo_root, repo_root / "src")):
        path_str = str(path)
        if path_str not in sys.path:
            sys.path.insert(0, path_str)


_ensure_repo_import_paths()


def get_repo_root() -> pathlib.Path:
    """Return the root directory of the current git repository."""
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
        check=True,
    )
    return pathlib.Path(result.stdout.strip())


def generate_models(repo_root: pathlib.Path | None = None) -> None:
    """Generate Pydantic models from the external schema.

    Reads ``external/schema.json`` and writes the generated models to
    ``src/percylib/external/models.py``.
    """
    if repo_root is None:
        repo_root = get_repo_root()

    schema_path = repo_root / "external" / "schema.json"
    output_path = repo_root / "src" / "percylib" / "external" / "models.py"

    if not schema_path.exists():
        print(f"Schema file not found: {schema_path}", file=sys.stderr)
        sys.exit(1)

    output_path.parent.mkdir(parents=True, exist_ok=True)

    subprocess.run(
        [
            sys.executable,
            "-m",
            "datamodel_code_generator",
            "--input",
            str(schema_path),
            "--input-file-type",
            "jsonschema",
            "--output",
            str(output_path),
            "--output-model-type",
            "pydantic_v2.BaseModel",
            "--use-type-alias",
        ],
        check=True,
    )

    print(f"Generated models at {output_path}")


def _get_non_yoyo_tables(db_path: pathlib.Path) -> list[str]:
    """Return table names from a SQLite database, excluding yoyo tables."""
    with sqlite3.connect(str(db_path)) as conn:
        cursor = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
        )
        return [
            row[0]
            for row in cursor.fetchall()
            if not row[0].lower().startswith(("_yoyo", "yoyo"))
        ]


def generate_db_models(repo_root: pathlib.Path | None = None) -> None:
    """Generate SQLAlchemy models from database migrations.

    Creates a temporary SQLite database, applies migrations via
    :func:`~percylib.jobs.sqlite.create_migrated_jobs_sqlite`, then
    uses ``sqlacodegen`` to produce declarative ORM models at
    ``src/percylib/jobs/sqlite/db_models.py``.

    Tables created by yoyo-migrations (prefixed with ``_yoyo`` or
    ``yoyo``) are excluded from the generated output.
    """
    if repo_root is None:
        repo_root = get_repo_root()

    from percylib.jobs.sqlite import create_migrated_jobs_sqlite

    output_path = repo_root / "src" / "percylib" / "jobs" / "sqlite" / "db_models.py"
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory() as tmpdir:
        db_path = pathlib.Path(tmpdir) / "jobs.sqlite"
        create_migrated_jobs_sqlite(db_path)

        tables = _get_non_yoyo_tables(db_path)

        subprocess.run(
            [
                sys.executable,
                "-m",
                "sqlacodegen",
                f"sqlite:///{db_path}",
                "--generator",
                "declarative",
                "--tables",
                ",".join(tables),
                "--outfile",
                str(output_path),
            ],
            check=True,
        )

    print(f"Generated db models at {output_path}")


def generate_all_models(repo_root: pathlib.Path | None = None) -> None:
    """Generate both external schema models and database models."""
    if repo_root is None:
        repo_root = get_repo_root()

    generate_models(repo_root)
    generate_db_models(repo_root)


def main(argv: list[str] | None = None) -> None:
    generate_all_models()


if __name__ == "__main__":
    main()
