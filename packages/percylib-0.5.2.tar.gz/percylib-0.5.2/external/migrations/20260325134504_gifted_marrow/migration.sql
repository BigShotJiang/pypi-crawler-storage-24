CREATE TABLE `job_groups` (
	`id` text PRIMARY KEY,
	`validation_score` real
);
--> statement-breakpoint
CREATE TABLE `jobs` (
	`id` text PRIMARY KEY,
	`group_id` text,
	`status` text NOT NULL,
	`input` text NOT NULL,
	`output` text,
	`priority` integer,
	CONSTRAINT `fk_jobs_group_id_job_groups_id_fk` FOREIGN KEY (`group_id`) REFERENCES `job_groups`(`id`)
);
--> statement-breakpoint
CREATE INDEX `idx_jobs_status_priority` ON `jobs` (`status`,`priority`);--> statement-breakpoint
CREATE INDEX `idx_jobs_group_id_status` ON `jobs` (`group_id`,`status`);