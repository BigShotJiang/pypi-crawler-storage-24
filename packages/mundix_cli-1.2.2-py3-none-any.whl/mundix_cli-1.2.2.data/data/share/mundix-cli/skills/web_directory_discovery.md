---
name: web_directory_discovery
phase: 2_scanning_enumeration
tools: [gobuster, feroxbuster, ffuf]
dependencies: [web_service_identified]
mitre_tactic: TA0043 (Reconnaissance), TA0007 (Discovery)
---

# Objetivo
Descobrir diretórios, arquivos e endpoints ocultos em servidores web que não estão linkados publicamente, revelando painéis administrativos, APIs internas, backups e configurações expostas.

# Condições de Execução
- O alvo possui um serviço web acessível (HTTP/HTTPS).
- A URL base do alvo foi identificada.

# Comandos e Sintaxe

## 1. Gobuster (Diretórios e Arquivos)
```bash
gobuster dir -u https://{target_url} -w /usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt -t 50 -x php,html,txt,bak,old,zip,sql,js,json -o {workspace}/gobuster_results.txt --no-error
```

## 2. Feroxbuster (Recursivo - Mais Profundo)
Se o Gobuster encontrar diretórios interessantes, use o Feroxbuster para varredura recursiva.
```bash
feroxbuster -u https://{target_url} -w /usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt -t 50 -d 3 --auto-tune -o {workspace}/feroxbuster_results.txt
```

## 3. FFUF (Fuzzing de Parâmetros e Virtual Hosts)
```bash
ffuf -u https://{target_url}/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -mc 200,301,302,403 -o {workspace}/ffuf_results.json -of json
```

## 4. Busca de Backups e Arquivos Sensíveis
```bash
ffuf -u https://{target_url}/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common-and-sensitive.txt -mc 200 -o {workspace}/sensitive_files.json -of json
```

# Análise de Resultados
- **Status 200 em `/admin`, `/login`, `/dashboard`:** Painel administrativo encontrado. Acione a skill `bruteforce_authentication`.
- **Status 200 em `/api/`, `/v1/`, `/graphql`:** API exposta. Acione a skill `api_security_testing`.
- **Status 200 em `.bak`, `.old`, `.zip`, `.sql`:** Backup ou dump de banco de dados. Baixe e analise imediatamente.
- **Status 403 em diretórios:** Diretório existe mas está protegido. Tente bypass com a skill `403_bypass_techniques`.
- **Status 301/302 (Redirect):** Siga o redirect e registre o destino.

# Próximos Passos
- Registre todos os endpoints descobertos no Knowledge Graph.
- Para cada endpoint web descoberto, acione a skill `web_vulnerability_scan`.

# Tratamento de Erros
- Se `gobuster` não estiver instalado: `sudo apt install gobuster -y`.
- Se a wordlist não existir, use: `sudo apt install seclists -y`.
- Se o servidor retornar muitos falsos positivos (tudo 200), filtre pelo tamanho da resposta: adicione `-fs {tamanho_da_pagina_404}`.
- Se o WAF bloquear a varredura, diminua threads (`-t 10`) e adicione delay (`--delay 500ms`).
