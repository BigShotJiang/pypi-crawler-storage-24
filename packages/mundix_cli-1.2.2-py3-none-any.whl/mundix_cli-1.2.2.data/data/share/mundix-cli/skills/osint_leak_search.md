---
name: osint_leak_search
phase: 1_reconnaissance
tools: [curl, grep]
dependencies: [target_domain_identified]
mitre_tactic: TA0043 (Reconnaissance), TA0006 (Credential Access)
---

# Objetivo
Buscar credenciais vazadas, senhas expostas e informações sensíveis do domínio alvo em bases de dados de vazamentos públicos e repositórios de código.

# Condições de Execução
- O domínio principal do alvo foi confirmado.
- O escopo permite coleta passiva de credenciais vazadas.

# Comandos e Sintaxe

## 1. GitHub Dorks (Busca de Segredos em Repositórios)
Execute buscas manuais no GitHub por credenciais e configurações expostas.
```bash
DORKS=(
  "\"password\" \"{target_domain}\""
  "\"api_key\" \"{target_domain}\""
  "\"secret\" \"{target_domain}\""
  "filename:.env \"{target_domain}\""
  "filename:wp-config.php \"{target_domain}\""
  "filename:id_rsa \"{target_domain}\""
)
for dork in "${DORKS[@]}"; do
  echo "=== Searching: $dork ===" >> {workspace}/github_dorks.txt
  curl -sH "Accept: application/vnd.github.v3+json" "https://api.github.com/search/code?q=$dork" | jq '.items[].html_url' >> {workspace}/github_dorks.txt 2>/dev/null
  sleep 2
done
```

## 2. Verificação de Vazamentos de E-mail (HaveIBeenPwned - se API key disponível)
```bash
if [ -f {workspace}/emails_found.txt ]; then
  while read email; do
    echo "=== $email ===" >> {workspace}/breach_check.txt
    curl -s -H "hibp-api-key: {hibp_key}" "https://haveibeenpwned.com/api/v3/breachedaccount/$email" >> {workspace}/breach_check.txt
    sleep 1.5
  done < {workspace}/emails_found.txt
fi
```

## 3. Google Dorks (Busca de Arquivos Sensíveis)
```bash
echo "Google Dorks para busca manual:" > {workspace}/google_dorks.txt
echo "site:{target_domain} filetype:pdf" >> {workspace}/google_dorks.txt
echo "site:{target_domain} filetype:xls OR filetype:xlsx" >> {workspace}/google_dorks.txt
echo "site:{target_domain} filetype:sql" >> {workspace}/google_dorks.txt
echo "site:{target_domain} inurl:admin" >> {workspace}/google_dorks.txt
echo "site:{target_domain} intitle:\"index of\"" >> {workspace}/google_dorks.txt
echo "site:{target_domain} ext:log" >> {workspace}/google_dorks.txt
```

# Análise de Resultados
- Se encontrar credenciais válidas em repositórios GitHub, registre-as e tente autenticação nos serviços descobertos.
- Se encontrar e-mails em vazamentos de dados, as senhas podem ter sido reutilizadas. Acione a skill `bruteforce_authentication` com as senhas encontradas.
- Se encontrar arquivos `.env`, `wp-config.php` ou chaves SSH expostas, priorize a exploração desses vetores.

# Próximos Passos
- Credenciais encontradas devem ser testadas com a skill `bruteforce_authentication`.
- Arquivos sensíveis encontrados devem ser baixados e analisados.

# Tratamento de Erros
- Se a API do GitHub retornar rate limit (403), aguarde 60 segundos e tente novamente.
- Se a API do HIBP retornar 401, a chave API está inválida ou ausente. Pule esta etapa.
