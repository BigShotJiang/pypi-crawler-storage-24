---
name: cve_search_engine
phase: 3_vulnerability_analysis
tools: [searchsploit, nmap-vulners, curl]
dependencies: [service_version_identified]
mitre_tactic: TA0043 (Reconnaissance), TA0001 (Initial Access)
---

# Objetivo
Buscar vulnerabilidades conhecidas (CVEs) e exploits públicos para os serviços e versões identificados durante a fase de varredura, priorizando aqueles com exploits disponíveis.

# Condições de Execução
- Pelo menos um serviço com versão identificada foi encontrado na fase de varredura.
- O Exploit-DB (searchsploit) está atualizado.

# Comandos e Sintaxe

## 1. Atualizar Exploit-DB
```bash
searchsploit -u 2>&1 | tail -5
```

## 2. Buscar Exploits por Serviço/Versão
Para cada serviço encontrado, execute:
```bash
searchsploit "{service_name} {version}" --json | tee {workspace}/exploitdb_{service_name}.json
searchsploit "{service_name} {version}" | tee -a {workspace}/exploitdb_results.txt
```

## 3. Nmap Vulners Script (Scan de CVEs Automatizado)
```bash
nmap -sV --script vulners -p {ports} -Pn {target_ip} -oN {workspace}/nmap_vulners.txt
```

## 4. Busca na API do NIST NVD
```bash
curl -s "https://services.nvd.nist.gov/rest/json/cves/2.0?keywordSearch={service_name}+{version}&resultsPerPage=10" | jq '.vulnerabilities[].cve | {id: .id, description: .descriptions[0].value, cvss: .metrics.cvssMetricV31[0].cvssData.baseScore}' > {workspace}/nvd_results.json
```

# Análise de Resultados
- **CVSS >= 9.0 (Crítico):** Prioridade máxima. Se houver exploit disponível no Exploit-DB, acione a skill de exploração correspondente.
- **CVSS >= 7.0 (Alto):** Prioridade alta. Verifique se há PoC (Proof of Concept) disponível.
- **Exploit com "Remote Code Execution" ou "Authentication Bypass":** Estes são os vetores de entrada mais valiosos. Acione a skill `metasploit_auto_exploit` ou tente o exploit manualmente.
- **Sem exploits públicos mas CVE existe:** Registre no relatório como vulnerabilidade identificada sem exploit público.

# Próximos Passos
- Para cada CVE com exploit disponível, acione a skill de exploração correspondente (ex: `sql_injection_exploitation`, `metasploit_auto_exploit`).
- Registre todas as CVEs no Knowledge Graph com CVSS score.

# Tratamento de Erros
- Se `searchsploit` retornar "Exploit-DB not found", instale: `sudo apt install exploitdb -y`.
- Se a API do NVD retornar rate limit (403), aguarde 30 segundos entre requisições.
- Se `nmap vulners` não encontrar resultados, os scripts podem estar desatualizados: `nmap --script-updatedb`.
