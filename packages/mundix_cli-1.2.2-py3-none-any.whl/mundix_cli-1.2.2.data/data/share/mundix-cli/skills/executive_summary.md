---
name: executive_summary
phase: 6_reporting
tools: [python3, pandoc]
dependencies: [engagement_has_findings]
mitre_tactic: N/A
---

# Objetivo
Gerar um relatorio executivo nao-tecnico do engajamento de pentest, incluindo classificacao de riscos, impacto ao negocio, prioridades de remediacao e timeline de acoes recomendadas, em formato adequado para apresentacao a stakeholders e C-level.

# Condicoes de Execucao
- O engajamento possui achados documentados e classificados.
- Os resultados das fases anteriores estao disponiveis no workspace.
- Python3 e pandoc estao disponiveis para geracao do relatorio.

# Comandos e Sintaxe

## 1. Coletar e Classificar Achados
```bash
python3 -c "
import json, os, glob
from datetime import datetime

workspace = '{workspace}'
target = '{target}'

findings = {
    'critical': [], 'high': [], 'medium': [], 'low': [], 'informational': []
}

severity_keywords = {
    'critical': ['rce', 'remote code execution', 'os-shell', 'meterpreter', 'system shell', 'root shell', 'domain admin'],
    'high': ['sql injection', 'sqli', 'privilege escalation', 'privesc', 'credential', 'password', 'hash dump', 'lateral movement', 'admin access'],
    'medium': ['xss', 'cross-site', 'ssrf', 'lfi', 'file inclusion', 'upload', 'misconfiguration', 'missing header'],
    'low': ['information disclosure', 'version disclosure', 'directory listing', 'verbose error'],
    'informational': ['open port', 'service detected', 'technology identified', 'dns record']
}

result_files = glob.glob(os.path.join(workspace, '*.txt')) + glob.glob(os.path.join(workspace, '*.json'))

for filepath in result_files:
    try:
        with open(filepath, 'r', errors='ignore') as f:
            content = f.read().lower()
        for severity, keywords in severity_keywords.items():
            for kw in keywords:
                if kw in content:
                    findings[severity].append({'source': os.path.basename(filepath), 'keyword': kw, 'severity': severity})
                    break
    except Exception:
        pass

summary = {
    'target': target,
    'date': datetime.now().strftime('%Y-%m-%d'),
    'total_findings': sum(len(v) for v in findings.values()),
    'by_severity': {k: len(v) for k, v in findings.items()},
    'details': findings
}

output_path = os.path.join(workspace, 'findings_classified.json')
with open(output_path, 'w') as f:
    json.dump(summary, f, indent=2)
print(json.dumps(summary, indent=2))
" 2>&1 | tee {workspace}/classify_output.txt
```

## 2. Gerar Relatorio Executivo em Markdown
```bash
python3 -c "
import json, os
from datetime import datetime

workspace = '{workspace}'
target = '{target}'
client_name = '{client_name}'

findings_file = os.path.join(workspace, 'findings_classified.json')
if os.path.exists(findings_file):
    with open(findings_file) as f:
        data = json.load(f)
else:
    data = {'total_findings': 0, 'by_severity': {}, 'date': datetime.now().strftime('%Y-%m-%d')}

severity_counts = data.get('by_severity', {})
total = data.get('total_findings', 0)
critical = severity_counts.get('critical', 0)
high = severity_counts.get('high', 0)
medium = severity_counts.get('medium', 0)
low = severity_counts.get('low', 0)
info = severity_counts.get('informational', 0)

risk_score = (critical * 40) + (high * 25) + (medium * 10) + (low * 3) + (info * 1)
if risk_score >= 200: overall_risk = 'CRITICO'
elif risk_score >= 100: overall_risk = 'ALTO'
elif risk_score >= 40: overall_risk = 'MEDIO'
else: overall_risk = 'BAIXO'

today = datetime.now()
report = []
report.append('# Relatorio Executivo - Teste de Penetracao\n')
report.append('## Informacoes do Engajamento\n')
report.append('| Campo | Valor |')
report.append('|-------|-------|')
report.append('| **Cliente** | %s |' % client_name)
report.append('| **Alvo** | %s |' % target)
report.append('| **Data do Teste** | %s |' % data.get('date', today.strftime('%Y-%m-%d')))
report.append('| **Classificacao** | CONFIDENCIAL |\n')
report.append('## Resumo de Risco\n')
report.append('### Nivel de Risco Geral: %s\n' % overall_risk)
report.append('**Score de Risco:** %d pontos\n' % risk_score)
report.append('| Severidade | Quantidade | Impacto |')
report.append('|-----------|-----------|---------|')
report.append('| Critico | %d | Comprometimento total do sistema |' % critical)
report.append('| Alto | %d | Acesso nao autorizado a dados sensiveis |' % high)
report.append('| Medio | %d | Exploracao com condicoes especificas |' % medium)
report.append('| Baixo | %d | Boas praticas nao seguidas |' % low)
report.append('| Informativo | %d | Informacoes para hardening |\n' % info)
report.append('## Impacto ao Negocio\n')
report.append('1. **Confidencialidade:** %s' % ('Dados sensiveis expostos.' if critical + high > 0 else 'Risco limitado.'))
report.append('2. **Integridade:** %s' % ('Atacantes podem modificar dados.' if critical > 0 else 'Parcialmente preservada.'))
report.append('3. **Disponibilidade:** %s\n' % ('Servicos podem ser interrompidos.' if critical > 0 else 'Nao impactada significativamente.'))
report.append('## Prioridades de Remediacao\n')
report.append('### Imediato (0-48 horas)')
report.append('- Corrigir vulnerabilidades **Criticas**.')
report.append('- Isolar sistemas comprometidos.')
report.append('- Rotacionar credenciais expostas.')
report.append('- Aplicar patches pendentes.\n')
report.append('### Curto Prazo (1-2 semanas)')
report.append('- Corrigir vulnerabilidades **Altas**.')
report.append('- Implementar segmentacao de rede.')
report.append('- Fortalecer politicas de autenticacao.')
report.append('- Habilitar logging e monitoramento.\n')
report.append('### Medio Prazo (1-3 meses)')
report.append('- Corrigir vulnerabilidades **Medias**.')
report.append('- Implementar WAF.')
report.append('- Treinamento de seguranca para devs.')
report.append('- Programa de gestao de vulnerabilidades.\n')
report.append('### Longo Prazo (3-6 meses)')
report.append('- Corrigir vulnerabilidades **Baixas**.')
report.append('- Pentest recorrente (trimestral/semestral).')
report.append('- Adotar framework (NIST CSF, ISO 27001).')
report.append('- DevSecOps no SDLC.\n')
report.append('## Timeline de Acoes Recomendadas\n')
report.append('| Prazo | Acao | Responsavel | Status |')
report.append('|-------|------|-------------|--------|')
report.append('| 48h | Patch vulns criticas | Infra/DevOps | Pendente |')
report.append('| 48h | Rotacao de credenciais | Seguranca | Pendente |')
report.append('| 1 sem | Correcao vulns altas | Dev | Pendente |')
report.append('| 2 sem | Implementacao WAF | Infra | Pendente |')
report.append('| 1 mes | Revisao politicas acesso | Seguranca | Pendente |')
report.append('| 2 meses | Treinamento seguranca | RH | Pendente |')
report.append('| 3 meses | Programa gestao vulns | Seguranca | Pendente |')
report.append('| 6 meses | Retest completo | Seguranca | Pendente |\n')
report.append('## Conclusao\n')
report.append('O teste revelou nivel de risco **%s** (Score: %d).' % (overall_risk, risk_score))
if critical > 0:
    report.append('Vulnerabilidades criticas devem ser corrigidas imediatamente.')
if high > 0:
    report.append('Acoes de curto prazo sao fortemente recomendadas.')
report.append('Um programa continuo de seguranca e essencial.\n')
report.append('---\n*CONFIDENCIAL - Distribuicao nao autorizada e proibida.*')

output_path = os.path.join(workspace, 'executive_summary.md')
with open(output_path, 'w') as f:
    f.write('\n'.join(report))
print('Executive summary generated:', output_path)
print('Risk Level: %s (Score: %d)' % (overall_risk, risk_score))
" 2>&1 | tee {workspace}/report_gen_output.txt
```

## 3. Converter para PDF com Pandoc
```bash
pandoc {workspace}/executive_summary.md -o {workspace}/executive_summary.pdf --pdf-engine=xelatex -V geometry:margin=2.5cm -V fontsize=11pt -V mainfont="DejaVu Sans" --highlight-style=tango --toc --toc-depth=2 -V colorlinks=true 2>&1 | tee {workspace}/pandoc_pdf.txt
```

### Alternativa: Converter para HTML
```bash
pandoc {workspace}/executive_summary.md -o {workspace}/executive_summary.html --standalone --toc --toc-depth=2 --metadata title="Relatorio Executivo - Pentest" 2>&1 | tee {workspace}/pandoc_html.txt
```

### Alternativa: Converter para DOCX
```bash
pandoc {workspace}/executive_summary.md -o {workspace}/executive_summary.docx --toc --toc-depth=2 2>&1 | tee {workspace}/pandoc_docx.txt
```

## 4. Gerar Grafico de Severidade (ASCII)
```bash
python3 -c "
import json, os

workspace = '{workspace}'
findings_file = os.path.join(workspace, 'findings_classified.json')

if os.path.exists(findings_file):
    with open(findings_file) as f:
        data = json.load(f)
    severity = data.get('by_severity', {})
else:
    severity = {}

print('')
print('=== DISTRIBUICAO DE VULNERABILIDADES ===')
print('')
max_val = max(severity.values()) if severity else 1

for sev, label in [('critical', 'CRITICO  '), ('high', 'ALTO     '), ('medium', 'MEDIO    '), ('low', 'BAIXO    '), ('informational', 'INFO     ')]:
    count = severity.get(sev, 0)
    bar_len = int((count / max_val) * 40) if max_val > 0 else 0
    bar = '#' * bar_len
    print('  %s | %s (%d)' % (label, bar, count))

total = sum(severity.values()) if severity else 0
print('')
print('  Total: %d' % total)
" 2>&1 | tee {workspace}/severity_chart.txt
```

## 5. Validar Relatorio Gerado
```bash
wc -l {workspace}/executive_summary.md | tee {workspace}/report_stats.txt
python3 -c "
with open('{workspace}/executive_summary.md') as f:
    content = f.read()
required = ['Resumo de Risco', 'Impacto ao Negocio', 'Prioridades de Remediacao', 'Timeline', 'Conclusao']
for section in required:
    status = 'OK' if section in content else 'MISSING'
    print('  [%s] %s' % (status, section))
"
```

# Analise de Resultados
- **Relatorio gerado com todas as secoes:** Pronto para revisao e entrega ao cliente.
- **Risk score alto (>=200):** Engajamento revelou problemas criticos. Reforcar urgencia na apresentacao.
- **Risk score medio (40-199):** Vulnerabilidades significativas, mas sem comprometimento total.
- **Risk score baixo (<40):** Postura de seguranca razoavel, foco em melhorias incrementais.
- **PDF gerado com sucesso:** Relatorio formatado profissionalmente para entrega.

# Proximos Passos
- Revisar o relatorio gerado antes de entregar ao cliente.
- Complementar com screenshots e evidencias das fases anteriores.
- Agendar apresentacao executiva com stakeholders.
- Acionar `generate_pentest_report` para o relatorio tecnico detalhado.

# Tratamento de Erros
- Se `pandoc` nao estiver instalado, o relatorio Markdown pode ser convertido manualmente ou entregue como esta.
- Se `xelatex` nao estiver disponivel para PDF, use `--pdf-engine=wkhtmltopdf` ou gere HTML.
- Se o workspace nao contiver achados, o relatorio sera gerado com valores zerados - adicionar achados manualmente.
- Se o Python falhar na leitura de arquivos, verifique encoding com `file -i {workspace}/*.txt`.
- Se o pandoc gerar PDF com caracteres quebrados, adicione `-V mainfont="DejaVu Sans"` para suporte UTF-8.
