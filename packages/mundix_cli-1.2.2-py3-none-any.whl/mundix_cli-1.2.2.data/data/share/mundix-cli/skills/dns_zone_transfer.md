---
name: dns_zone_transfer
phase: 2_scanning_enumeration
tools: [dig, fierce, dnsrecon]
dependencies: [target_domain_identified]
mitre_tactic: TA0043 (Reconnaissance)
---

# Objetivo
Tentar transferência de zona DNS (AXFR) e enumeração de registros DNS para descobrir hosts internos, servidores de e-mail, registros TXT com informações sensíveis e a topologia da rede.

# Condições de Execução
- O domínio do alvo foi confirmado.
- Porta 53 (DNS) está acessível no nameserver do alvo.

# Comandos e Sintaxe

## 1. Identificar Nameservers
```bash
dig NS {target_domain} +short | tee {workspace}/nameservers.txt
```

## 2. Tentar Zone Transfer (AXFR)
```bash
while read ns; do
  echo "=== Zone Transfer: $ns ===" >> {workspace}/zone_transfer.txt
  dig AXFR {target_domain} @$ns >> {workspace}/zone_transfer.txt 2>&1
done < {workspace}/nameservers.txt
```

## 3. Enumeração de Registros DNS
```bash
dig ANY {target_domain} +noall +answer | tee {workspace}/dns_any.txt
dig MX {target_domain} +short | tee {workspace}/dns_mx.txt
dig TXT {target_domain} +short | tee {workspace}/dns_txt.txt
dig SOA {target_domain} +short | tee {workspace}/dns_soa.txt
```

## 4. DNSRecon (Enumeração Avançada)
```bash
dnsrecon -d {target_domain} -t std,brt,axfr -o {workspace}/dnsrecon_results.csv 2>&1 | tee {workspace}/dnsrecon_output.txt
```

# Análise de Resultados
- **Zone Transfer bem-sucedida (AXFR):** Vulnerabilidade crítica! Todos os registros DNS foram expostos. Extraia hosts internos, IPs privados e registros de serviço.
- **Registros MX:** Identifique o provedor de e-mail (Exchange on-premise, Office 365, Google Workspace). Se for on-premise, pode ser um vetor de ataque.
- **Registros TXT:** Procure por SPF, DKIM, DMARC (configurações fracas permitem spoofing de e-mail), e tokens de verificação de serviços.
- **Registros A/AAAA internos:** IPs privados (10.x, 172.16.x, 192.168.x) indicam hosts internos expostos no DNS público.

# Próximos Passos
- Se a zone transfer revelar hosts internos, adicione-os ao escopo e acione a skill `network_port_scan`.
- Se SPF/DMARC estiverem ausentes ou fracos, registre como vulnerabilidade para o relatório.

# Tratamento de Erros
- Se `dig` retornar "Transfer failed", a zone transfer está bloqueada (comportamento esperado e seguro).
- Se `dnsrecon` não estiver instalado: `sudo apt install dnsrecon -y`.
