---
name: osint_email_harvesting
phase: 1_reconnaissance
tools: [theHarvester, hunter.io]
dependencies: [target_domain_identified]
mitre_tactic: TA0043 (Reconnaissance)
---

# Objetivo
Coletar endereços de e-mail, nomes de funcionários e metadados associados ao domínio alvo para uso em ataques de phishing, password spraying ou enumeração de usuários.

# Condições de Execução
- O domínio principal do alvo foi confirmado.
- O escopo permite coleta passiva de informações.

# Comandos e Sintaxe

## 1. theHarvester (Multi-Source)
Busca e-mails, subdomínios e IPs em múltiplas fontes públicas.
```bash
theHarvester -d {target_domain} -b all -l 500 -f {workspace}/harvester_results
```

## 2. Extração de E-mails do LinkedIn (via theHarvester)
```bash
theHarvester -d {target_domain} -b linkedin -l 200 -f {workspace}/linkedin_emails
```

## 3. Consolidação
```bash
cat {workspace}/harvester_results.json | jq -r '.emails[]' 2>/dev/null | sort -u > {workspace}/emails_found.txt
wc -l {workspace}/emails_found.txt
```

# Análise de Resultados
- Se encontrar padrão de e-mail (ex: `nome.sobrenome@empresa.com`), registre o padrão para gerar listas de e-mails a partir de nomes de funcionários.
- Se encontrar e-mails de serviços (ex: `noreply@`, `support@`, `admin@`), estes podem indicar sistemas internos expostos.
- Se encontrar poucos resultados, tente buscar em vazamentos de dados com a skill `osint_leak_search`.

# Próximos Passos
- Acione a skill `bruteforce_authentication` se credenciais de login forem encontradas.
- Use os e-mails para enumeração de usuários em portais web (OWA, VPN, etc.).

# Tratamento de Erros
- Se o theHarvester falhar com "API key required", configure as chaves em `/etc/theHarvester/api-keys.yaml`.
- Se a busca retornar 0 resultados, tente fontes individuais: `-b google`, `-b bing`, `-b dnsdumpster`.
