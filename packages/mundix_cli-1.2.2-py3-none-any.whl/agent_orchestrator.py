"""
MundiX Agent Orchestrator — The autonomous decision loop for pentesting.

This module is the "brain" of the MundiX autonomous pentesting agent.
It uses the SkillLoader to plan which skills to execute, the AIProvider
to analyze results and make decisions, and the Project to track state.

Architecture:
    ┌─────────────────────────────────────────────┐
    │              Agent Orchestrator              │
    │  ┌─────────┐  ┌──────────┐  ┌───────────┐  │
    │  │  Skill   │  │    AI    │  │  Project  │  │
    │  │  Loader  │  │ Provider │  │   State   │  │
    │  └─────────┘  └──────────┘  └───────────┘  │
    │  ┌─────────┐  ┌──────────┐  ┌───────────┐  │
    │  │ AutoPilot│  │ Executor │  │  Reporter │  │
    │  └─────────┘  └──────────┘  └───────────┘  │
    └─────────────────────────────────────────────┘

Flow (Autopilot 5 — Full Autonomy):
    1. User provides target → Orchestrator creates engagement
    2. Load skills → Generate pentest plan
    3. For each phase:
       a. Select skills for current phase
       b. For each skill:
          - Generate agent prompt with current context
          - AI decides which commands to run
          - Execute commands (respecting autopilot level)
          - Parse output → update findings
          - AI analyzes results → decides next action
       c. Phase complete → advance to next phase
    4. Generate final report

Usage:
    from agent_orchestrator import AgentOrchestrator

    orchestrator = AgentOrchestrator(
        skills_dir="/opt/mundix-cli/skills",
        ai_provider=ai_provider_instance,
        project=project_instance,
        autopilot=autopilot_instance,
    )

    # Start a full autonomous pentest
    await orchestrator.start_engagement("example.com", engagement_type="web")

    # Or run a single skill
    await orchestrator.run_skill("network_port_scan", target="10.0.0.1")
"""

import os
import re
import sys
import json
import time
import asyncio
import subprocess
import shlex
from enum import Enum
from typing import List, Dict, Optional, Callable, Tuple, Any
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime

from skill_loader import SkillRegistry, Skill, SkillCommand

try:
    from threat_intel import ThreatIntel
except ImportError:
    ThreatIntel = None

try:
    from knowledge_graph import KnowledgeGraph
except ImportError:
    KnowledgeGraph = None

try:
    from osint_monitor import OSINTMonitor
except ImportError:
    OSINTMonitor = None

try:
    from findings_db import FindingsDB
except ImportError:
    FindingsDB = None


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

SKILLS_DIR = os.environ.get("MUNDIX_SKILLS_DIR", None)
if not SKILLS_DIR:
    # Try common locations in priority order
    _candidates = [
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "skills"),  # Git / editable install
        os.path.join(sys.prefix, "share", "mundix-cli", "skills"),          # pip data_files
        "/opt/mundix-cli/skills",                                            # Fallback hardcoded
    ]
    for _c in _candidates:
        if os.path.isdir(_c):
            SKILLS_DIR = _c
            break
    if not SKILLS_DIR:
        SKILLS_DIR = _candidates[0]  # Default even if missing

# Maximum time (seconds) a single command can run before being killed
COMMAND_TIMEOUT = 300  # 5 minutes

# Maximum retries for a failed command
MAX_COMMAND_RETRIES = 3

# Maximum time (seconds) for an entire skill execution
SKILL_TIMEOUT = 1800  # 30 minutes

# How many lines of command output to keep for AI context
MAX_OUTPUT_LINES = 200

# Engagement types map to which phases to run
ENGAGEMENT_PROFILES = {
    "web": {
        "description": "Web Application Penetration Test",
        "phases": [
            "1_reconnaissance",
            "2_scanning_enumeration",
            "3_vulnerability_analysis",
            "4_exploitation",
            "5_post_exploitation",
            "6_reporting",
        ],
        "skip_skills": [],
        "required_vars": ["target_domain"],
    },
    "internal": {
        "description": "Internal Network Penetration Test",
        "phases": [
            "1_reconnaissance",
            "2_scanning_enumeration",
            "3_vulnerability_analysis",
            "4_exploitation",
            "5_post_exploitation",
            "6_reporting",
        ],
        "skip_skills": ["osint_domain_enumeration", "osint_email_harvesting"],
        "required_vars": ["target_ip", "target_range"],
    },
    "app": {
        "description": "Application Security Assessment",
        "phases": [
            "1_reconnaissance",
            "2_scanning_enumeration",
            "3_vulnerability_analysis",
            "4_exploitation",
            "6_reporting",
        ],
        "skip_skills": [
            "smb_rpc_enumeration", "dns_zone_transfer",
            "linux_privilege_escalation", "windows_privilege_escalation",
            "lateral_movement_psexec", "hash_dumping_and_cracking",
        ],
        "required_vars": ["target_domain"],
    },
}


# ---------------------------------------------------------------------------
# Enums and Data Classes
# ---------------------------------------------------------------------------

class EngagementStatus(str, Enum):
    """Status of the current engagement."""
    IDLE = "idle"
    PLANNING = "planning"
    RUNNING = "running"
    PAUSED = "paused"
    WAITING_INPUT = "waiting_input"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


class SkillStatus(str, Enum):
    """Status of a skill execution."""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class CommandResult:
    """Result of executing a single command."""
    def __init__(self, command: str, stdout: str, stderr: str,
                 returncode: int, duration: float):
        self.command = command
        self.stdout = stdout
        self.stderr = stderr
        self.returncode = returncode
        self.duration = duration
        self.timestamp = datetime.now().isoformat()

    @property
    def success(self) -> bool:
        return self.returncode == 0

    @property
    def output(self) -> str:
        """Combined output (stdout + stderr), truncated for AI context."""
        combined = self.stdout
        if self.stderr:
            combined += f"\n[STDERR]\n{self.stderr}"
        lines = combined.split('\n')
        if len(lines) > MAX_OUTPUT_LINES:
            half = MAX_OUTPUT_LINES // 2
            lines = lines[:half] + [f"\n... ({len(lines) - MAX_OUTPUT_LINES} lines truncated) ...\n"] + lines[-half:]
        return '\n'.join(lines)

    def to_dict(self) -> Dict:
        return {
            "command": self.command,
            "returncode": self.returncode,
            "success": self.success,
            "duration": round(self.duration, 2),
            "stdout_lines": len(self.stdout.split('\n')),
            "stderr_lines": len(self.stderr.split('\n')) if self.stderr else 0,
            "timestamp": self.timestamp,
        }


@dataclass
class SkillExecution:
    """Tracks the execution state of a single skill."""
    skill_name: str
    status: SkillStatus = SkillStatus.PENDING
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    commands_executed: List[Dict] = field(default_factory=list)
    findings: List[str] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    ai_decisions: List[str] = field(default_factory=list)
    output_files: List[str] = field(default_factory=list)
    skip_reason: Optional[str] = None

    def start(self):
        self.status = SkillStatus.RUNNING
        self.started_at = datetime.now().isoformat()

    def complete(self, findings: List[str] = None):
        self.status = SkillStatus.COMPLETED
        self.completed_at = datetime.now().isoformat()
        if findings:
            self.findings.extend(findings)

    def fail(self, error: str):
        self.status = SkillStatus.FAILED
        self.completed_at = datetime.now().isoformat()
        self.errors.append(error)

    def skip(self, reason: str):
        self.status = SkillStatus.SKIPPED
        self.skip_reason = reason

    def to_dict(self) -> Dict:
        return {
            "skill": self.skill_name,
            "status": self.status.value,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "commands_count": len(self.commands_executed),
            "findings_count": len(self.findings),
            "findings": self.findings,
            "errors": self.errors,
            "ai_decisions": self.ai_decisions,
            "output_files": self.output_files,
        }


@dataclass
class EngagementState:
    """Full state of the current pentest engagement."""
    target: str
    engagement_type: str
    status: EngagementStatus = EngagementStatus.IDLE
    workspace: str = ""
    variables: Dict[str, str] = field(default_factory=dict)
    current_phase: str = ""
    current_skill: str = ""
    plan: List[Dict] = field(default_factory=list)
    skill_executions: Dict[str, SkillExecution] = field(default_factory=dict)
    findings: Dict[str, bool] = field(default_factory=dict)
    discovered_hosts: List[str] = field(default_factory=list)
    discovered_ports: List[Dict] = field(default_factory=list)
    discovered_vulns: List[Dict] = field(default_factory=list)
    discovered_creds: List[Dict] = field(default_factory=list)
    timeline: List[Dict] = field(default_factory=list)
    started_at: Optional[str] = None
    completed_at: Optional[str] = None

    def start(self):
        self.status = EngagementStatus.RUNNING
        self.started_at = datetime.now().isoformat()

    def complete(self):
        self.status = EngagementStatus.COMPLETED
        self.completed_at = datetime.now().isoformat()

    def add_timeline_event(self, event_type: str, description: str, data: Dict = None):
        self.timeline.append({
            "timestamp": datetime.now().isoformat(),
            "type": event_type,
            "description": description,
            "data": data or {},
        })

    def get_completed_skills(self) -> List[str]:
        return [
            name for name, ex in self.skill_executions.items()
            if ex.status == SkillStatus.COMPLETED
        ]

    def get_progress(self) -> Dict:
        total = len(self.plan)
        completed = len(self.get_completed_skills())
        failed = len([e for e in self.skill_executions.values() if e.status == SkillStatus.FAILED])
        skipped = len([e for e in self.skill_executions.values() if e.status == SkillStatus.SKIPPED])
        return {
            "total": total,
            "completed": completed,
            "failed": failed,
            "skipped": skipped,
            "remaining": total - completed - failed - skipped,
            "percent": round((completed / total) * 100, 1) if total > 0 else 0,
            "current_phase": self.current_phase,
            "current_skill": self.current_skill,
        }

    def get_context_summary(self) -> str:
        """Generate a context summary for the AI to understand current state."""
        lines = []
        lines.append(f"## Engagement State")
        lines.append(f"**Target:** {self.target}")
        lines.append(f"**Type:** {self.engagement_type}")
        lines.append(f"**Phase:** {self.current_phase}")
        lines.append(f"**Progress:** {self.get_progress()['percent']}%")
        lines.append("")

        if self.discovered_hosts:
            lines.append(f"**Discovered Hosts:** {', '.join(self.discovered_hosts[:20])}")
        if self.discovered_ports:
            lines.append(f"**Open Ports:** {len(self.discovered_ports)} found")
            for p in self.discovered_ports[:15]:
                lines.append(f"  - {p.get('host', '?')}:{p.get('port', '?')} "
                             f"({p.get('service', 'unknown')})")
        if self.discovered_vulns:
            lines.append(f"**Vulnerabilities:** {len(self.discovered_vulns)} found")
            for v in self.discovered_vulns[:10]:
                lines.append(f"  - [{v.get('severity', '?')}] {v.get('name', 'unknown')}")
        if self.discovered_creds:
            lines.append(f"**Credentials:** {len(self.discovered_creds)} found")

        # Recent findings
        completed_skills = self.get_completed_skills()
        if completed_skills:
            lines.append(f"\n**Completed Skills:** {', '.join(completed_skills[-5:])}")
            # Last skill's findings
            last_skill = completed_skills[-1]
            last_exec = self.skill_executions.get(last_skill)
            if last_exec and last_exec.findings:
                lines.append(f"**Last Findings:**")
                for f in last_exec.findings[-5:]:
                    lines.append(f"  - {f}")

        return '\n'.join(lines)

    def save(self, filepath: str):
        """Save engagement state to JSON file."""
        data = {
            "target": self.target,
            "engagement_type": self.engagement_type,
            "status": self.status.value,
            "workspace": self.workspace,
            "variables": self.variables,
            "current_phase": self.current_phase,
            "current_skill": self.current_skill,
            "findings": self.findings,
            "discovered_hosts": self.discovered_hosts,
            "discovered_ports": self.discovered_ports,
            "discovered_vulns": self.discovered_vulns,
            "discovered_creds": self.discovered_creds,
            "timeline": self.timeline,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "skill_executions": {
                k: v.to_dict() for k, v in self.skill_executions.items()
            },
            "progress": self.get_progress(),
        }
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    @classmethod
    def load(cls, filepath: str) -> 'EngagementState':
        """Load engagement state from JSON file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)

        state = cls(
            target=data["target"],
            engagement_type=data["engagement_type"],
        )
        state.status = EngagementStatus(data.get("status", "idle"))
        state.workspace = data.get("workspace", "")
        state.variables = data.get("variables", {})
        state.current_phase = data.get("current_phase", "")
        state.current_skill = data.get("current_skill", "")
        state.findings = data.get("findings", {})
        state.discovered_hosts = data.get("discovered_hosts", [])
        state.discovered_ports = data.get("discovered_ports", [])
        state.discovered_vulns = data.get("discovered_vulns", [])
        state.discovered_creds = data.get("discovered_creds", [])
        state.timeline = data.get("timeline", [])
        state.started_at = data.get("started_at")
        state.completed_at = data.get("completed_at")
        return state


# ---------------------------------------------------------------------------
# Command Executor
# ---------------------------------------------------------------------------

class CommandExecutor:
    """
    Executes shell commands with timeout, output capture, and safety checks.
    Integrates with AutoPilot for execution permission.
    """

    # Commands that should NEVER be auto-executed
    DESTRUCTIVE_PATTERNS = [
        r'rm\s+-rf\s+/',
        r'mkfs\.',
        r'dd\s+if=.*of=/dev/',
        r':\(\)\{.*\}',  # fork bomb
        r'chmod\s+-R\s+777\s+/',
        r'shutdown',
        r'reboot',
        r'init\s+0',
        r'halt',
    ]

    # Commands that require elevated caution
    DANGEROUS_PATTERNS = [
        r'rm\s+-rf',
        r'rm\s+-r',
        r'exploit',
        r'msfconsole',
        r'msfvenom',
        r'reverse.?shell',
        r'bind.?shell',
        r'nc\s+-[le]',  # netcat listener
        r'python.*-c.*socket',  # python reverse shell
        r'bash\s+-i\s+>&',  # bash reverse shell
    ]

    def __init__(self, autopilot=None, on_output: Callable = None,
                 on_ask_permission: Callable = None):
        """
        Args:
            autopilot: AutoPilot instance for permission checks
            on_output: Callback for real-time output streaming (line: str) -> None
            on_ask_permission: Callback to ask user permission (cmd: str, reason: str) -> bool
        """
        self.autopilot = autopilot
        self.on_output = on_output
        self.on_ask_permission = on_ask_permission

    def is_destructive(self, command: str) -> bool:
        """Check if a command matches destructive patterns."""
        for pattern in self.DESTRUCTIVE_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return True
        return False

    def is_dangerous(self, command: str) -> bool:
        """Check if a command matches dangerous patterns."""
        for pattern in self.DANGEROUS_PATTERNS:
            if re.search(pattern, command, re.IGNORECASE):
                return True
        return False

    def should_execute(self, command: str) -> Tuple[bool, str]:
        """
        Determine if a command should be executed based on AutoPilot level.
        Returns (should_execute: bool, reason: str).
        """
        if self.is_destructive(command):
            if self.autopilot and self.autopilot.level < 5:
                return False, f"DESTRUCTIVE command blocked (AP level {self.autopilot.level})"
            # Level 5: even destructive commands run
            return True, "AUTOPILOT: destructive command allowed"

        if self.is_dangerous(command):
            if self.autopilot:
                if self.autopilot.should_skip_dangerous_confirm():
                    return True, "AGGRESSIVE/AUTOPILOT: dangerous command auto-approved"
                else:
                    # Need to ask user
                    return False, "DANGEROUS command requires confirmation"
            return False, "DANGEROUS command (no autopilot configured)"

        # Safe command
        if self.autopilot and self.autopilot.should_auto_execute():
            return True, "Auto-execute (safe command)"

        return False, "Manual mode: requires confirmation"

    def execute(self, command: str, timeout: int = COMMAND_TIMEOUT,
                cwd: str = None, env: Dict = None) -> CommandResult:
        """
        Execute a shell command and return the result.

        Args:
            command: The shell command to execute
            timeout: Maximum seconds to wait
            cwd: Working directory
            env: Additional environment variables
        """
        start_time = time.time()

        # Merge environment
        cmd_env = os.environ.copy()
        if env:
            cmd_env.update(env)

        try:
            process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=cwd,
                env=cmd_env,
                text=True,
                bufsize=1,
            )

            stdout_lines = []
            stderr_lines = []

            # Read output with timeout
            try:
                stdout, stderr = process.communicate(timeout=timeout)
                stdout_lines = stdout.split('\n') if stdout else []
                stderr_lines = stderr.split('\n') if stderr else []

                # Stream output if callback provided
                if self.on_output:
                    for line in stdout_lines:
                        if line.strip():
                            self.on_output(line)

            except subprocess.TimeoutExpired:
                process.kill()
                stdout, stderr = process.communicate()
                return CommandResult(
                    command=command,
                    stdout=stdout or "",
                    stderr=f"TIMEOUT: Command exceeded {timeout}s limit\n{stderr or ''}",
                    returncode=-1,
                    duration=timeout,
                )

            duration = time.time() - start_time

            return CommandResult(
                command=command,
                stdout='\n'.join(stdout_lines),
                stderr='\n'.join(stderr_lines),
                returncode=process.returncode,
                duration=duration,
            )

        except Exception as e:
            duration = time.time() - start_time
            return CommandResult(
                command=command,
                stdout="",
                stderr=f"EXECUTION ERROR: {str(e)}",
                returncode=-2,
                duration=duration,
            )

    def execute_with_permission(self, command: str, timeout: int = COMMAND_TIMEOUT,
                                 cwd: str = None) -> Tuple[Optional[CommandResult], str]:
        """
        Execute a command with autopilot permission checks.
        Returns (result or None, status_message).
        """
        should_run, reason = self.should_execute(command)

        if should_run:
            result = self.execute(command, timeout=timeout, cwd=cwd)
            return result, reason

        # Need permission
        if self.on_ask_permission:
            is_dangerous = self.is_dangerous(command)
            granted = self.on_ask_permission(
                command,
                "DANGEROUS" if is_dangerous else "DESTRUCTIVE"
            )
            if granted:
                result = self.execute(command, timeout=timeout, cwd=cwd)
                return result, "User approved execution"
            else:
                return None, "User denied execution"

        return None, reason


# ---------------------------------------------------------------------------
# Output Parser — Extracts structured data from command output
# ---------------------------------------------------------------------------

class OutputParser:
    """Parses command output to extract hosts, ports, vulnerabilities, etc."""

    @staticmethod
    def parse_nmap_output(output: str) -> Dict:
        """Extract hosts, ports, and services from nmap output."""
        results = {"hosts": [], "ports": [], "os_matches": []}

        # Parse open ports: "80/tcp   open  http    Apache httpd 2.4.41"
        port_re = re.compile(
            r'(\d+)/(tcp|udp)\s+(open|filtered)\s+(\S+)\s*(.*)',
            re.IGNORECASE
        )
        current_host = None

        for line in output.split('\n'):
            # Host detection
            host_match = re.search(r'Nmap scan report for\s+(\S+)', line)
            if host_match:
                current_host = host_match.group(1)
                # Extract IP if hostname(IP) format
                ip_match = re.search(r'\((\d+\.\d+\.\d+\.\d+)\)', current_host)
                if ip_match:
                    results["hosts"].append({
                        "hostname": current_host.split('(')[0],
                        "ip": ip_match.group(1),
                    })
                else:
                    results["hosts"].append({"hostname": current_host, "ip": current_host})

            # Port detection
            port_match = port_re.search(line)
            if port_match:
                results["ports"].append({
                    "host": current_host or "unknown",
                    "port": int(port_match.group(1)),
                    "protocol": port_match.group(2),
                    "state": port_match.group(3),
                    "service": port_match.group(4),
                    "version": port_match.group(5).strip(),
                })

            # OS detection
            os_match = re.search(r'OS details?:\s+(.+)', line)
            if os_match:
                results["os_matches"].append(os_match.group(1).strip())

        return results

    @staticmethod
    def parse_gobuster_output(output: str) -> Dict:
        """Extract discovered directories and files from gobuster output."""
        results = {"directories": [], "files": []}

        for line in output.split('\n'):
            # Match: /admin (Status: 200) [Size: 1234]
            match = re.search(r'(/\S+)\s+\(Status:\s*(\d+)\)\s*\[Size:\s*(\d+)\]', line)
            if match:
                path = match.group(1)
                status = int(match.group(2))
                size = int(match.group(3))
                entry = {"path": path, "status": status, "size": size}
                if path.endswith('/') or '.' not in path.split('/')[-1]:
                    results["directories"].append(entry)
                else:
                    results["files"].append(entry)

        return results

    @staticmethod
    def parse_nuclei_output(output: str) -> List[Dict]:
        """Extract vulnerabilities from nuclei output."""
        vulns = []

        for line in output.split('\n'):
            # Nuclei format: [severity] [template-id] [protocol] url
            match = re.search(
                r'\[(\w+)\]\s+\[([^\]]+)\]\s+\[([^\]]+)\]\s+(.+)',
                line
            )
            if match:
                vulns.append({
                    "severity": match.group(1).lower(),
                    "template": match.group(2),
                    "protocol": match.group(3),
                    "url": match.group(4).strip(),
                    "raw": line.strip(),
                })

        return vulns

    @staticmethod
    def parse_sqlmap_output(output: str) -> Dict:
        """Extract SQLi findings from sqlmap output."""
        results = {
            "injectable": False,
            "parameters": [],
            "databases": [],
            "dbms": None,
        }

        for line in output.split('\n'):
            if "is vulnerable" in line.lower() or "injectable" in line.lower():
                results["injectable"] = True
            param_match = re.search(r"Parameter:\s+(\S+)", line)
            if param_match:
                results["parameters"].append(param_match.group(1))
            db_match = re.search(r"available databases.*:\s*\[.*\]\s*(.*)", line)
            if db_match:
                results["databases"].extend(
                    [d.strip().strip("'\"") for d in db_match.group(1).split(',')]
                )
            dbms_match = re.search(r"back-end DBMS:\s+(.+)", line)
            if dbms_match:
                results["dbms"] = dbms_match.group(1).strip()

        return results

    @staticmethod
    def parse_hydra_output(output: str) -> List[Dict]:
        """Extract cracked credentials from hydra output."""
        creds = []

        for line in output.split('\n'):
            # [22][ssh] host: 10.0.0.1   login: admin   password: password123
            match = re.search(
                r'\[\d+\]\[(\w+)\]\s+host:\s+(\S+)\s+login:\s+(\S+)\s+password:\s+(\S+)',
                line
            )
            if match:
                creds.append({
                    "service": match.group(1),
                    "host": match.group(2),
                    "username": match.group(3),
                    "password": match.group(4),
                })

        return creds

    def auto_parse(self, command: str, output: str) -> Dict:
        """Automatically detect the tool and parse its output."""
        cmd_lower = command.lower().split()[0] if command else ""

        if "nmap" in cmd_lower:
            return {"type": "nmap", "data": self.parse_nmap_output(output)}
        elif "gobuster" in cmd_lower or "feroxbuster" in cmd_lower or "dirb" in cmd_lower:
            return {"type": "directory_scan", "data": self.parse_gobuster_output(output)}
        elif "nuclei" in cmd_lower or "nikto" in cmd_lower:
            return {"type": "vuln_scan", "data": self.parse_nuclei_output(output)}
        elif "sqlmap" in cmd_lower:
            return {"type": "sqli", "data": self.parse_sqlmap_output(output)}
        elif "hydra" in cmd_lower or "medusa" in cmd_lower:
            return {"type": "bruteforce", "data": self.parse_hydra_output(output)}
        else:
            return {"type": "raw", "data": {"output": output[:5000]}}


# ---------------------------------------------------------------------------
# Agent Orchestrator — The Brain
# ---------------------------------------------------------------------------

class AgentOrchestrator:
    """
    The autonomous pentesting agent that orchestrates skill execution.

    This is the main class that:
    1. Plans the pentest based on target and engagement type
    2. Loads and sequences skills from the SkillLoader
    3. Generates AI prompts with full context
    4. Executes commands via CommandExecutor
    5. Parses output and updates engagement state
    6. Makes decisions about next steps via AI
    7. Generates the final report
    """

    def __init__(
        self,
        skills_dir: str = SKILLS_DIR,
        ai_provider=None,
        project=None,
        autopilot=None,
        on_status: Callable = None,
        on_output: Callable = None,
        on_finding: Callable = None,
        on_ask_permission: Callable = None,
        on_phase_change: Callable = None,
    ):
        """
        Args:
            skills_dir: Path to the skills/ directory
            ai_provider: AIProvider instance for LLM calls
            project: Project instance for engagement state
            autopilot: AutoPilot instance for execution control
            on_status: Callback for status updates (msg: str) -> None
            on_output: Callback for command output streaming (line: str) -> None
            on_finding: Callback when a finding is discovered (finding: dict) -> None
            on_ask_permission: Callback to ask user (cmd: str, reason: str) -> bool
            on_phase_change: Callback when phase changes (phase: str) -> None
        """
        # Core components
        self.registry = SkillRegistry(skills_dir)
        self.registry.load_all()
        self.parser = OutputParser()
        self.executor = CommandExecutor(
            autopilot=autopilot,
            on_output=on_output,
            on_ask_permission=on_ask_permission,
        )

        # External integrations
        self.ai_provider = ai_provider
        self.project = project
        self.autopilot = autopilot

        # Callbacks
        self.on_status = on_status or (lambda msg: None)
        self.on_output = on_output or (lambda line: None)
        self.on_finding = on_finding or (lambda finding: None)
        self.on_ask_permission = on_ask_permission
        self.on_phase_change = on_phase_change or (lambda phase: None)

        # State
        self.state: Optional[EngagementState] = None
        self._abort_requested = False
        self.threat_intel = ThreatIntel() if ThreatIntel else None
        self.knowledge_graph: Optional['KnowledgeGraph'] = None
        self.osint_monitor: Optional['OSINTMonitor'] = None
        self.findings_db = FindingsDB() if FindingsDB else None
        self._engagement_db_id: Optional[str] = None

    # --- Public API ---

    def start_engagement(
        self,
        target: str,
        engagement_type: str = "web",
        variables: Dict[str, str] = None,
        workspace: str = None,
    ) -> EngagementState:
        """
        Start a new pentest engagement.

        Args:
            target: The target (domain, IP, or URL)
            engagement_type: "web", "internal", or "app"
            variables: Additional variables for skill templates
            workspace: Directory for output files (auto-created if None)
        """
        self._abort_requested = False

        # Validate engagement type
        if engagement_type not in ENGAGEMENT_PROFILES:
            raise ValueError(f"Unknown engagement type: {engagement_type}. "
                             f"Valid: {list(ENGAGEMENT_PROFILES.keys())}")

        profile = ENGAGEMENT_PROFILES[engagement_type]

        # Setup workspace
        if not workspace:
            safe_target = re.sub(r'[^\w.-]', '_', target)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            workspace = f"/tmp/mundix_pentest/{safe_target}_{timestamp}"
        os.makedirs(workspace, exist_ok=True)

        # Setup variables — smart target type detection
        vars_dict = variables or {}
        import ipaddress as _ipaddress

        # Classify what the user gave us
        _target_clean = target.strip().rstrip("/")
        _is_url = _target_clean.startswith(("http://", "https://"))
        _is_cidr = "/" in _target_clean and not _is_url
        _is_ip = False
        _extracted_host = _target_clean

        if _is_url:
            from urllib.parse import urlparse
            _extracted_host = urlparse(_target_clean).hostname or _target_clean
        if _is_cidr:
            _extracted_host = _target_clean.split("/")[0]

        try:
            _ipaddress.ip_address(_extracted_host)
            _is_ip = True
        except ValueError:
            pass

        # Validate: target must be IP, domain, URL, or CIDR — never "unknown"
        if not _is_ip and not _is_url and not _is_cidr:
            # Check if it looks like a domain (has dots or is localhost)
            if "." not in _extracted_host and _extracted_host not in ("localhost",):
                self.on_status(f"[WARN] Target '{target}' doesn't look like a valid IP/domain/URL")

        if "target_domain" not in vars_dict:
            vars_dict["target_domain"] = _extracted_host if not _is_ip else target
        if "target_ip" not in vars_dict:
            vars_dict["target_ip"] = _extracted_host if _is_ip else target
        if "target_range" not in vars_dict:
            vars_dict["target_range"] = _target_clean if _is_cidr else _extracted_host
        if "target_url" not in vars_dict:
            if _is_url:
                vars_dict["target_url"] = _target_clean
            else:
                vars_dict["target_url"] = f"https://{_extracted_host}"
        vars_dict["workspace"] = workspace

        # Create engagement state
        self.state = EngagementState(
            target=target,
            engagement_type=engagement_type,
            workspace=workspace,
            variables=vars_dict,
        )

        # Build execution plan
        plan = []
        for phase_id in profile["phases"]:
            skills = self.registry.get_by_phase(phase_id)
            for skill in skills:
                if skill.name not in profile.get("skip_skills", []):
                    plan.append({
                        "phase": phase_id,
                        "skill": skill.name,
                        "tools": skill.tools,
                        "commands": len(skill.commands),
                    })
                    # Initialize skill execution tracker
                    self.state.skill_executions[skill.name] = SkillExecution(
                        skill_name=skill.name
                    )

        self.state.plan = plan
        self.state.start()
        self.state.add_timeline_event("engagement_started", f"Target: {target}, Type: {engagement_type}")

        self.on_status(f"[ORCHESTRATOR] Engagement started: {target} ({engagement_type})")
        self.on_status(f"[ORCHESTRATOR] Plan: {len(plan)} skills across {len(profile['phases'])} phases")
        self.on_status(f"[ORCHESTRATOR] Workspace: {workspace}")

        # Initialize Knowledge Graph
        if KnowledgeGraph:
            self.knowledge_graph = KnowledgeGraph(target)
            self.on_status(f"[ORCHESTRATOR] Knowledge Graph initialized for {target}")
        else:
            self.knowledge_graph = None

        # Initialize FindingsDB and load prior intelligence
        if self.findings_db:
            self._engagement_db_id = self.findings_db.start_engagement(
                target=target, engagement_type=engagement_type,
                metadata={"workspace": workspace, "plan_size": len(plan)},
            )
            prior_intel = self.findings_db.format_as_ai_context(target)
            if prior_intel:
                self.state.variables["prior_intelligence"] = prior_intel
                self.on_status(f"[ORCHESTRATOR] 🧠 Prior intelligence loaded for {target}")
            self.on_status(f"[ORCHESTRATOR] FindingsDB tracking engagement {self._engagement_db_id}")

        return self.state

    def run_plan(self) -> EngagementState:
        """
        Execute the pentest plan with ADAPTIVE intelligence.
        
        Unlike sequential execution, this:
        1. Groups skills by phase and executes phases in order
        2. Between phases, asks AI to re-evaluate and reprioritize
        3. Detects WAFs and adapts tactics
        4. Retries failed commands with intelligent modifications
        5. Dynamically adds/skips skills based on findings
        """
        if not self.state:
            raise RuntimeError("No engagement started. Call start_engagement() first.")

        current_phase = None
        failed_count = 0
        max_consecutive_failures = 5  # Abort phase if too many failures

        # Group plan by phase for adaptive inter-phase decisions
        phase_skills = {}
        for step in self.state.plan:
            phase_skills.setdefault(step["phase"], []).append(step["skill"])

        for phase_id in phase_skills:
            if self._abort_requested:
                self.state.status = EngagementStatus.ABORTED
                self.state.add_timeline_event("aborted", "User requested abort")
                break

            # Phase transition
            self.state.current_phase = phase_id
            self.on_phase_change(phase_id)
            self.on_status(f"\n{'='*60}")
            self.on_status(f"[PHASE] {phase_id.replace('_', ' ').upper()}")
            self.on_status(f"{'='*60}")
            self.state.add_timeline_event("phase_started", f"Phase: {phase_id}")
            failed_count = 0

            # Get skills for this phase (may include dynamically added ones)
            skill_names = list(phase_skills[phase_id])

            # AI inter-phase decision: reprioritize skills based on current findings
            if self.ai_provider and self.state.get_completed_skills():
                adapted_skills = self._ai_adapt_phase(phase_id, skill_names)
                if adapted_skills:
                    skill_names = adapted_skills

            for skill_name in skill_names:
                if self._abort_requested:
                    break

                if failed_count >= max_consecutive_failures:
                    self.on_status(f"[ADAPT] Too many failures in {phase_id}. Moving to next phase.")
                    self.state.add_timeline_event("phase_skipped", 
                        f"Phase {phase_id}: {failed_count} consecutive failures")
                    break

                self.state.current_skill = skill_name
                self.on_status(f"\n[SKILL] Starting: {skill_name}")

                try:
                    self._execute_skill(skill_name)
                    exec_state = self.state.skill_executions.get(skill_name)
                    if exec_state and exec_state.status == SkillStatus.COMPLETED:
                        failed_count = 0  # Reset on success
                    elif exec_state and exec_state.status == SkillStatus.FAILED:
                        failed_count += 1
                except Exception as e:
                    self.on_status(f"[ERROR] Skill {skill_name} failed: {e}")
                    self.state.skill_executions[skill_name].fail(str(e))
                    self.state.add_timeline_event("skill_failed", f"{skill_name}: {e}")
                    failed_count += 1

                # Save state after each skill
                state_file = os.path.join(self.state.workspace, "engagement_state.json")
                self.state.save(state_file)

            # Post-phase: check for WAF and adapt
            if self.state.findings.get("waf_detected") and phase_id.startswith("2_"):
                self.on_status(f"\n[ADAPT] ⚡ WAF detected! Adjusting tactics for exploitation phase.")
                self.state.variables["waf_evasion"] = "true"
                self.state.add_timeline_event("adaptation", "WAF detected — enabling evasion tactics")

            # Post-scanning: enrich discovered services with threat intel
            if phase_id.startswith("2_") and self.threat_intel and self.state.discovered_ports:
                self._enrich_with_threat_intel()

            # Start OSINT monitor after scanning phase for continuous intel
            if phase_id.startswith("2_") and OSINTMonitor and self.knowledge_graph and not self.osint_monitor:
                try:
                    self.osint_monitor = OSINTMonitor(
                        self.knowledge_graph,
                        target=self.state.target,
                        on_alert=lambda sev, msg, data: self.on_status(f"  [OSINT-{sev.upper()}] {msg}"),
                        skills_dir=self.registry.skills_dir if hasattr(self.registry, 'skills_dir') else None,
                    )
                    self.osint_monitor.start(interval=180)
                    self.on_status(f"[OSINT] 📡 Background OSINT monitor started (auto-skill generation ACTIVE)")
                except Exception as e:
                    self.on_status(f"[OSINT] Could not start monitor: {e}")

            # Hot-reload skills (picks up auto-generated ones from OSINT monitor)
            new_skills = self.registry.reload_if_changed()
            if new_skills > 0:
                self.on_status(f"[SKILLS] 🔄 {new_skills} new skill(s) loaded (auto-generated)")
                # Add new skills to the plan if they match upcoming phases
                for skill in self.registry.get_all():
                    if skill.name not in [s["skill"] for s in self.state.plan]:
                        if skill.metadata.raw.get("auto_generated"):
                            remaining_phases = list(phase_skills.keys())
                            idx = remaining_phases.index(phase_id) if phase_id in remaining_phases else -1
                            for remaining in remaining_phases[idx + 1:]:
                                if skill.phase == remaining:
                                    self.state.plan.append({
                                        "phase": skill.phase,
                                        "skill": skill.name,
                                        "tools": skill.tools,
                                        "commands": len(skill.commands),
                                    })
                                    phase_skills.setdefault(skill.phase, []).append(skill.name)
                                    self.state.skill_executions[skill.name] = SkillExecution(skill_name=skill.name)
                                    self.on_status(f"  [AUTO] ➕ Added auto-skill: {skill.name} → phase {remaining}")
                                    break

            # Post-exploitation: auto-detect lateral movement opportunities
            if phase_id.startswith("4_") and self.knowledge_graph:
                self._check_lateral_movement_opportunities(phase_skills)

        # Engagement complete
        if not self._abort_requested:
            self.state.complete()
            self.state.add_timeline_event("engagement_completed", "All phases finished")
            self.on_status(f"\n{'='*60}")
            self.on_status(f"[COMPLETE] Engagement finished!")
            self.on_status(f"[RESULTS] {json.dumps(self.state.get_progress(), indent=2)}")

            # Save learnings to memory if available
            self._save_engagement_learnings()

            # Stop OSINT monitor
            if self.osint_monitor:
                monitor_status = self.osint_monitor.get_status()
                self.osint_monitor.stop()
                self.on_status(f"[OSINT] Monitor stopped: {monitor_status['findings']} findings "
                               f"from {monitor_status['checks']} checks")
                self.osint_monitor = None

            # Save Knowledge Graph
            if self.knowledge_graph:
                kg_path = os.path.join(self.state.workspace, "knowledge_graph.json")
                self.knowledge_graph.save(kg_path)
                self.on_status(f"[KG] Knowledge Graph saved: {kg_path} "
                               f"({len(self.knowledge_graph.nodes)} nodes, "
                               f"{len(self.knowledge_graph.edges)} edges)")
                chains = self.knowledge_graph.find_attack_chains()
                if chains:
                    self.on_status(f"[KG] 🎯 {len(chains)} attack chain(s) discovered!")
                    for i, chain in enumerate(chains[:3], 1):
                        labels = [self.knowledge_graph.nodes[n].label
                                  for n in chain if n in self.knowledge_graph.nodes]
                        self.on_status(f"  Chain {i}: {' → '.join(labels)}")

                    # Persist attack chains to DB
                    if self.findings_db and self._engagement_db_id:
                        for chain in chains:
                            labels = [self.knowledge_graph.nodes[n].label
                                      for n in chain if n in self.knowledge_graph.nodes]
                            self.findings_db.save_attack_chain(
                                self._engagement_db_id,
                                chain_path=chain, chain_labels=labels,
                            )

            # Complete engagement in FindingsDB
            if self.findings_db and self._engagement_db_id:
                risk_score = 0.0
                if self.knowledge_graph:
                    risk_score = self.knowledge_graph.get_attack_surface_score().get("risk_score", 0.0)
                report_path = os.path.join(self.state.workspace, "pentest_report.md")
                self.findings_db.complete_engagement(
                    self._engagement_db_id,
                    risk_score=risk_score,
                    report_path=report_path,
                )
                stats = self.findings_db.get_stats()
                self.on_status(f"[DB] 💾 Engagement persisted — "
                               f"{stats.get('findings', 0)} total findings in DB, "
                               f"{stats.get('hosts', 0)} hosts, "
                               f"{stats.get('auto_skills', 0)} auto-generated skills")

        return self.state

    def _ai_adapt_phase(self, phase_id: str, planned_skills: List[str]) -> Optional[List[str]]:
        """
        Ask the AI Brain to reprioritize skills for a phase based on findings so far.
        
        For exploitation/post-exploitation phases, uses KG attack chains and CVE risk
        scores to guide prioritization (not just fixed phase order).
        
        Returns reordered/filtered skill list, or None to keep original order.
        """
        try:
            context = self.state.get_context_summary()
            kg_context = ""
            attack_chain_context = ""
            if self.knowledge_graph:
                kg_context = f"\n\nKnowledge Graph State:\n{self.knowledge_graph.to_ai_context()}\n"

                # For exploitation phases, inject attack chain intelligence
                if phase_id.startswith(("4_", "5_")):
                    chains = self.knowledge_graph.find_attack_chains()
                    score = self.knowledge_graph.get_attack_surface_score()
                    if chains or score:
                        attack_chain_context = "\n\n## Attack Chain Intelligence (KG-Driven)\n"
                        attack_chain_context += f"Risk Score: {score.get('risk_score', 0)}/100\n"
                        attack_chain_context += f"CVEs found: {score.get('cve_count', 0)} "
                        attack_chain_context += f"(Critical: {score.get('critical_cves', 0)}, High: {score.get('high_cves', 0)})\n"
                        attack_chain_context += f"Exploits available: {score.get('exploit_count', 0)}\n"
                        attack_chain_context += f"Credentials found: {score.get('credential_count', 0)}\n"
                        if chains:
                            attack_chain_context += f"\nDiscovered Attack Chains ({len(chains)}):\n"
                            for i, chain in enumerate(chains[:5], 1):
                                labels = [self.knowledge_graph.nodes[n].label
                                          for n in chain if n in self.knowledge_graph.nodes]
                                attack_chain_context += f"  Chain {i}: {' → '.join(labels)}\n"
                            attack_chain_context += (
                                "\nPRIORITIZE skills that advance the most promising attack chain. "
                                "If credentials exist, prioritize lateral movement. "
                                "If high-CVSS CVEs have exploits, prioritize those exploits first.\n"
                            )

                    # Add CVE-to-skill mapping for intelligent routing
                    from knowledge_graph import NodeType
                    cve_nodes = self.knowledge_graph.get_nodes_by_type(NodeType.CVE)
                    if cve_nodes:
                        attack_chain_context += "\nKnown CVEs (prioritize by CVSS):\n"
                        sorted_cves = sorted(cve_nodes,
                                            key=lambda n: n.properties.get("cvss", 0), reverse=True)
                        for cve in sorted_cves[:10]:
                            cvss = cve.properties.get("cvss", 0)
                            desc = cve.properties.get("description", "")[:60]
                            attack_chain_context += f"  - {cve.label} (CVSS {cvss}): {desc}\n"

            prior_intel = ""
            if self.state.variables.get("prior_intelligence"):
                prior_intel = f"\n\nPrior Intelligence (from past engagements):\n{self.state.variables['prior_intelligence']}\n"

            # Skill effectiveness data from DB
            effectiveness_context = ""
            if self.findings_db:
                learnings = self.findings_db.get_learnings("skill_effectiveness", min_confidence=0.5)
                if learnings:
                    effectiveness_context = "\n\nSkill Effectiveness (from past runs):\n"
                    for learn in learnings[:10]:
                        effectiveness_context += f"  - {learn['key']}: {learn['value']}\n"

            prompt = (
                f"You are the MundiX Pentesting Agent strategist.\n\n"
                f"We are about to start phase '{phase_id}' with these planned skills:\n"
                f"{json.dumps(planned_skills)}\n\n"
                f"Current engagement state:\n{context}\n"
                f"{kg_context}"
                f"{attack_chain_context}"
                f"{prior_intel}"
                f"{effectiveness_context}"
                f"Based on ALL intelligence above, you MUST:\n"
                f"1. REORDER skills by exploitability (highest CVSS + available exploit FIRST)\n"
                f"2. SKIP skills that are irrelevant to the discovered attack surface\n"
                f"3. If credentials exist and we're in post-exploitation, put lateral_movement FIRST\n"
                f"4. If a specific CVE has a known exploit, prioritize the matching skill\n\n"
                f"Output ONLY a JSON array of skill names in the order they should execute.\n"
                f"Remove skills that should be skipped. Keep the skill names EXACTLY as listed.\n"
                f"Example: [\"sql_injection_exploitation\", \"bruteforce_authentication\"]\n"
                f"Output ONLY the JSON array."
            )

            response = self.ai_provider.chat_sync(prompt, tier="brain")
            json_match = re.search(r'\[.*\]', response, re.DOTALL)
            if json_match:
                adapted = json.loads(json_match.group())
                if isinstance(adapted, list) and all(isinstance(s, str) for s in adapted):
                    # Validate: only keep skills that actually exist
                    valid = [s for s in adapted if s in planned_skills]
                    if valid and len(valid) >= len(planned_skills) // 2:
                        if valid != planned_skills:
                            self.on_status(f"  [ADAPT] AI reprioritized: {len(valid)} skills"
                                           f" (was {len(planned_skills)})")
                            self.state.add_timeline_event("adaptation",
                                f"Phase {phase_id} reprioritized by AI: {valid}")
                        return valid
        except Exception as e:
            self.on_status(f"  [ADAPT] AI reprioritization failed: {e}. Using KG-based fallback.")

        # Deterministic fallback: KG-based prioritization (no AI needed)
        return self._kg_prioritize_skills(phase_id, planned_skills)

    def _kg_prioritize_skills(self, phase_id: str, planned_skills: List[str]) -> Optional[List[str]]:
        """
        Deterministic skill prioritization based on Knowledge Graph state.
        No AI needed — uses risk scores and attack chain proximity.
        """
        if not self.knowledge_graph or not phase_id.startswith(("3_", "4_", "5_")):
            return None

        kg = self.knowledge_graph
        findings = self.state.findings

        # Build a priority score for each skill based on KG state
        skill_scores = {}
        for skill_name in planned_skills:
            score = 0.0
            skill = self.registry.get(skill_name)
            if not skill:
                skill_scores[skill_name] = 0
                continue

            # Boost skills whose dependencies are met
            if self._check_dependencies(skill):
                score += 10.0

            # Boost exploit skills if matching CVEs have high CVSS
            if "sql_injection" in skill_name and findings.get("sqli_vulnerability_identified"):
                score += 30.0
            if "bruteforce" in skill_name and findings.get("login_endpoint_identified"):
                score += 15.0
            if "metasploit" in skill_name and findings.get("cves_found"):
                score += 20.0
            if "file_upload" in skill_name and findings.get("web_service_found"):
                score += 10.0

            # Boost lateral movement if credentials exist
            if "lateral" in skill_name and findings.get("credentials_found"):
                score += 35.0
            if "privilege_escalation" in skill_name and findings.get("shell_obtained"):
                score += 25.0

            # Boost based on attack chain proximity
            chains = kg.find_attack_chains(max_depth=5)
            if chains:
                # Skills that advance the chain get bonus
                for chain in chains[:3]:
                    chain_labels_lower = [kg.nodes[n].label.lower() for n in chain if n in kg.nodes]
                    for tool in (skill.tools if skill else []):
                        if any(tool.lower() in label for label in chain_labels_lower):
                            score += 5.0

            # Auto-generated skills targeting specific CVEs get a boost
            if skill_name.startswith("auto_"):
                score += 8.0  # Targeted exploits are valuable

            skill_scores[skill_name] = score

        # Sort by score (descending), keep original order for ties
        sorted_skills = sorted(planned_skills, key=lambda s: skill_scores.get(s, 0), reverse=True)

        if sorted_skills != planned_skills:
            self.on_status(f"  [KG-ADAPT] Reordered {len(sorted_skills)} skills by risk priority")
            top_scores = [(s, skill_scores.get(s, 0)) for s in sorted_skills[:3]]
            for name, sc in top_scores:
                if sc > 0:
                    self.on_status(f"    🎯 {name}: priority {sc:.0f}")
            return sorted_skills

        return None

    def _check_lateral_movement_opportunities(self, phase_skills: Dict[str, List[str]]):
        """After exploitation, auto-detect and queue lateral movement if conditions are met."""
        kg = self.knowledge_graph
        findings = self.state.findings

        has_shell = findings.get("shell_obtained") or findings.get("meterpreter_session")
        has_creds = findings.get("credentials_found") or findings.get("valid_credentials")
        multiple_hosts = len(self.state.discovered_ports) > 1

        if not (has_shell or has_creds):
            return

        self.on_status("\n[KG-LATERAL] 🔍 Checking lateral movement opportunities...")

        # Check if lateral_movement_psexec is already planned
        all_planned = [s for phase in phase_skills.values() for s in phase]
        if "lateral_movement_psexec" in all_planned:
            return

        # Check KG for lateral paths
        try:
            from knowledge_graph import NodeType
            hosts = kg.get_nodes_by_type(NodeType.IP)
            shells = [n for n in kg.nodes.values()
                      if n.node_type.name == "SHELL"]
            cred_nodes = [n for n in kg.nodes.values()
                          if n.node_type.name == "CREDENTIAL"]

            if (shells or has_shell) and (cred_nodes or has_creds) and (len(hosts) > 1 or multiple_hosts):
                self.on_status("[KG-LATERAL] 🎯 Shell + credentials + multiple hosts detected!")
                self.on_status("[KG-LATERAL] Auto-queuing lateral_movement_psexec for phase 5")

                lateral_skill = self.registry.get("lateral_movement_psexec")
                if lateral_skill:
                    target_phase = "5_post_exploitation"
                    phase_skills.setdefault(target_phase, [])
                    if "lateral_movement_psexec" not in phase_skills[target_phase]:
                        phase_skills[target_phase].insert(0, "lateral_movement_psexec")
                        self.state.skill_executions["lateral_movement_psexec"] = SkillExecution(
                            skill_name="lateral_movement_psexec")
                        self.state.add_timeline_event("auto_lateral",
                            "KG detected lateral movement opportunity — auto-queued psexec")
                else:
                    self.on_status("[KG-LATERAL] ⚠ lateral_movement_psexec skill not found")
            elif shells or has_shell:
                self.on_status("[KG-LATERAL] Shell obtained but no credentials/extra hosts for lateral movement")
        except Exception as e:
            self.on_status(f"[KG-LATERAL] Check failed: {e}")

    def run_single_skill(self, skill_name: str, variables: Dict[str, str] = None) -> SkillExecution:
        """Run a single skill outside of a full engagement."""
        skill = self.registry.get(skill_name)
        if not skill:
            raise ValueError(f"Skill not found: {skill_name}")

        # Create minimal state if needed
        if not self.state:
            target = (variables or {}).get("target_domain", "unknown")
            self.start_engagement(target, variables=variables)

        if variables:
            self.state.variables.update(variables)

        self._execute_skill(skill_name)
        return self.state.skill_executions.get(skill_name)

    def abort(self):
        """Request abort of the current engagement."""
        self._abort_requested = True
        self.on_status("[ORCHESTRATOR] Abort requested. Finishing current command...")

    def pause(self):
        """Pause the engagement."""
        if self.state:
            self.state.status = EngagementStatus.PAUSED
            self.state.add_timeline_event("paused", "Engagement paused by user")
            self.on_status("[ORCHESTRATOR] Engagement paused.")

    def resume(self):
        """Resume a paused engagement."""
        if self.state and self.state.status == EngagementStatus.PAUSED:
            self.state.status = EngagementStatus.RUNNING
            self.state.add_timeline_event("resumed", "Engagement resumed")
            self.on_status("[ORCHESTRATOR] Engagement resumed.")

    def get_progress(self) -> Dict:
        """Get current progress."""
        if self.state:
            return self.state.get_progress()
        return {"status": "idle"}

    # --- Internal Methods ---

    def _execute_skill(self, skill_name: str):
        """Execute a single skill with all its commands."""
        skill = self.registry.get(skill_name)
        if not skill:
            raise ValueError(f"Skill not found: {skill_name}")

        execution = self.state.skill_executions.get(skill_name)
        if not execution:
            execution = SkillExecution(skill_name=skill_name)
            self.state.skill_executions[skill_name] = execution

        execution.start()

        # Check dependencies
        if not self._check_dependencies(skill):
            execution.skip("Dependencies not met")
            self.on_status(f"[SKIP] {skill_name}: dependencies not met")
            return

        # Generate the AI prompt for this skill
        agent_prompt = skill.to_agent_prompt(self.state.variables)

        # Add engagement context
        context = self.state.get_context_summary()
        kg_ctx = ""
        if self.knowledge_graph:
            kg_ctx = f"\n\n{self.knowledge_graph.to_ai_context()}"
        full_prompt = f"{agent_prompt}\n\n---\n\n{context}{kg_ctx}"

        # If we have an AI provider, let the AI decide which commands to run
        if self.ai_provider:
            commands_to_run = self._ai_plan_commands(skill, full_prompt)
        else:
            # Fallback: run all commands from the skill sequentially
            commands_to_run = []
            for cmd in skill.commands:
                try:
                    commands_to_run.append(
                        cmd.render(self.state.variables) if self.state.variables else cmd.raw
                    )
                except ValueError as e:
                    self.on_status(f"  [WARN] Placeholder issue: {e}. Using raw command.")
                    commands_to_run.append(cmd.raw)

        # Execute each command
        for i, command in enumerate(commands_to_run):
            if self._abort_requested:
                break

            self.on_status(f"  [{i+1}/{len(commands_to_run)}] $ {command}")

            # Execute with permission check
            result, reason = self.executor.execute_with_permission(
                command,
                cwd=self.state.workspace,
            )

            if result is None:
                self.on_status(f"  [BLOCKED] {reason}")
                execution.ai_decisions.append(f"Command blocked: {reason}")
                continue

            # Log the execution
            execution.commands_executed.append(result.to_dict())

            if result.success:
                self.on_status(f"  [OK] Completed in {result.duration:.1f}s")
            else:
                self.on_status(f"  [FAIL] Exit code {result.returncode} ({result.duration:.1f}s)")

                # Adaptive retry loop with intelligent error handling
                retries = 0
                fixed = False
                while retries < MAX_COMMAND_RETRIES and not fixed:
                    retries += 1
                    # Try auto-fix (install missing tool, sudo, WAF evasion)
                    if self.autopilot and self.autopilot.should_auto_fix():
                        fixed_result = self._try_auto_fix(command, result, skill)
                        if fixed_result and fixed_result.success:
                            result = fixed_result
                            fixed = True
                            self.on_status(f"  [AUTO-FIX] Succeeded on retry {retries}!")
                        elif fixed_result:
                            result = fixed_result  # Update for next retry
                            self.on_status(f"  [RETRY {retries}/{MAX_COMMAND_RETRIES}] Still failing...")
                        else:
                            break  # No fix available
                    else:
                        break

                if not fixed and retries > 0:
                    self.on_status(f"  [EXHAUST] All {retries} retries failed for: {command[:80]}")

            # Parse output and update state
            self._process_output(skill, command, result)

        # Skill complete — let AI analyze results if available
        if self.ai_provider and not self._abort_requested:
            findings = self._ai_analyze_results(skill, execution)
            execution.complete(findings)
        else:
            execution.complete()

        self.state.add_timeline_event(
            "skill_completed",
            f"{skill_name}: {len(execution.commands_executed)} commands, "
            f"{len(execution.findings)} findings",
        )

        # Track skill effectiveness in FindingsDB
        self._track_skill_effectiveness(skill_name, execution)

    def _track_skill_effectiveness(self, skill_name: str, execution):
        """Track skill effectiveness for future prioritization."""
        if not self.findings_db:
            return
        try:
            success = len(execution.findings) > 0
            # For auto-generated skills, track in the auto_skills table
            if skill_name.startswith("auto_"):
                self.findings_db.increment_skill_usage(skill_name, success=success)

            # Save effectiveness as a learning
            key = f"{skill_name}_effectiveness"
            existing = self.findings_db.get_learnings("skill_effectiveness")
            prev = next((l for l in existing if l["key"] == key), None)
            if prev:
                try:
                    data = json.loads(prev["value"])
                except Exception:
                    data = {"used": 0, "success": 0}
            else:
                data = {"used": 0, "success": 0}

            data["used"] = data.get("used", 0) + 1
            if success:
                data["success"] = data.get("success", 0) + 1
            rate = data["success"] / data["used"] if data["used"] > 0 else 0
            data["rate"] = round(rate, 2)

            confidence = min(0.9, 0.3 + (data["used"] * 0.1))
            self.findings_db.save_learning(
                "skill_effectiveness", key,
                json.dumps(data), confidence=confidence
            )
        except Exception:
            pass

    def _check_dependencies(self, skill: Skill) -> bool:
        """Check if a skill's dependencies are met."""
        for dep in skill.metadata.dependencies:
            # Special handling for common dependencies
            if dep == "target_domain_identified":
                if self.state.variables.get("target_domain"):
                    continue
                return False
            elif dep == "target_ip_identified":
                if self.state.variables.get("target_ip"):
                    continue
                return False
            elif dep == "open_ports_identified":
                if self.state.discovered_ports:
                    continue
                # Still allow if we haven't scanned yet
                return True
            elif dep in self.state.findings:
                if not self.state.findings[dep]:
                    return False
            # Unknown dependency — allow by default
        return True

    def _ai_plan_commands(self, skill: Skill, prompt: str) -> List[str]:
        """
        Ask the AI to plan which commands to execute for this skill.
        Falls back to skill's default commands if AI is unavailable.
        
        CRITICAL: Pre-renders commands with actual target values AND locks
        the target in the prompt to prevent AI from hallucinating IPs.
        """
        try:
            # Pre-render all commands with actual variables
            pre_rendered = []
            for cmd in skill.commands:
                try:
                    rendered = cmd.render(self.state.variables)
                    pre_rendered.append(rendered)
                except ValueError:
                    pre_rendered.append(cmd.raw)

            target = self.state.target
            target_ip = self.state.variables.get("target_ip", target)
            target_domain = self.state.variables.get("target_domain", target)
            target_url = self.state.variables.get("target_url", f"https://{target}")
            workspace = self.state.variables.get("workspace", "/tmp/mundix_pentest")

            planning_prompt = (
                f"You are the MundiX Pentesting Agent executor.\n\n"
                f"## MANDATORY TARGET VALUES — DO NOT CHANGE THESE:\n"
                f"  target_ip     = {target_ip}\n"
                f"  target_domain = {target_domain}\n"
                f"  target_url    = {target_url}\n"
                f"  workspace     = {workspace}\n\n"
                f"⚠️  NEVER substitute different IPs, domains, or URLs.\n"
                f"⚠️  NEVER use 192.168.x.x, 10.x.x.x, or any other IP unless listed above.\n"
                f"⚠️  NEVER invent example targets. Use ONLY the values above.\n\n"
                f"## Pre-Rendered Commands (already have correct target values):\n"
            )
            for i, cmd in enumerate(pre_rendered, 1):
                planning_prompt += f"  {i}. {cmd}\n"

            planning_prompt += (
                f"\n## Your Task:\n"
                f"Review the pre-rendered commands above and the engagement context below.\n"
                f"Output the commands to execute, one per line. You may:\n"
                f"- Reorder commands for efficiency\n"
                f"- Skip commands not relevant to current findings\n"
                f"- Add additional commands using ONLY the target values above\n"
                f"- Modify flags/options for better results\n\n"
                f"Output ONLY executable bash commands, one per line.\n"
                f"No explanations, no markdown, no numbering.\n\n"
                f"## Context:\n{prompt}"
            )

            response = self.ai_provider.chat_sync(planning_prompt, tier="brain")

            # Extract commands from response — strict filtering
            commands = []
            for line in response.split('\n'):
                line = line.strip()
                if not line or line.startswith('#') or line.startswith('```'):
                    continue
                # Strip numbered list prefixes
                if re.match(r'^\d+[\.\)]\s+', line):
                    line = re.sub(r'^\d+[\.\)]\s+', '', line)
                if line.startswith('$ '):
                    line = line[2:]
                # Skip explanatory text
                explanation_patterns = [
                    'Note:', 'This ', 'The ', 'We ', 'I ', 'You ', 'First,',
                    'Next,', 'Then,', 'Finally,', 'Now ', 'Here ', 'Let ',
                    'After ', 'Before ', 'Make sure', 'Remember', 'Important',
                    'Output:', 'Result:', 'Expected:', 'Warning:', 'Step ',
                    'Update ', 'Replace ', 'yes', 'ok', 'Ok', 'Yes',
                ]
                if any(line.startswith(w) for w in explanation_patterns):
                    continue
                if not re.match(r'^[a-zA-Z0-9_/\.\-]', line):
                    continue
                # Reject pure sentences
                words = line.split()
                if len(words) > 2 and not any(
                    w.startswith('-') or '|' in line or '>' in line or
                    '/' in words[0] or '=' in line or '$' in line
                    for w in words
                ):
                    if line[0].isupper() and line[-1] in '.!:':
                        continue

                # SAFETY: reject/fix commands targeting out-of-scope IPs
                ip_matches = re.findall(r'\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}(?:/\d{1,2})?)\b', line)
                if ip_matches:
                    allowed_ips = {target_ip, target_domain,
                                   self.state.variables.get("target_range", "")}
                    allowed_ips.update(self.state.discovered_hosts)
                    allowed_ips.discard("")
                    for ip in ip_matches:
                        if ip not in allowed_ips and ip != "127.0.0.1":
                            self.on_status(
                                f"  [SAFETY] ⚠️ Replaced out-of-scope IP {ip} → {target_ip}")
                            line = line.replace(ip, target_ip)

                commands.append(line)

            if commands:
                return commands

        except Exception as e:
            self.on_status(f"  [AI] Planning failed: {e}. Using default commands.")

        # Fallback: use skill's default commands
        commands = []
        for cmd in skill.commands:
            try:
                rendered = cmd.render(self.state.variables)
                commands.append(rendered)
            except ValueError:
                commands.append(cmd.raw)
        return commands

    def _ai_analyze_results(self, skill: Skill, execution: SkillExecution) -> List[str]:
        """Ask the AI to analyze the results of a skill execution."""
        try:
            # Build context from execution results
            results_summary = []
            for cmd_result in execution.commands_executed[-5:]:  # Last 5 commands
                results_summary.append(
                    f"Command: {cmd_result['command']}\n"
                    f"Exit code: {cmd_result['returncode']}\n"
                    f"Output lines: {cmd_result['stdout_lines']}"
                )

            analysis_prompt = (
                f"Analyze the results of the '{skill.name}' skill execution.\n\n"
                f"## Skill Analysis Guide\n{skill.analysis_guide}\n\n"
                f"## Execution Results\n" + '\n---\n'.join(results_summary) + "\n\n"
                f"## Current Engagement State\n{self.state.get_context_summary()}\n\n"
                f"Output a JSON array of findings. Each finding should be a short string "
                f"describing what was discovered. Example:\n"
                f'["Port 80 open running Apache 2.4.41", "Port 22 open running OpenSSH 8.2"]\n'
                f"Output ONLY the JSON array, nothing else."
            )

            response = self.ai_provider.chat_sync(analysis_prompt, tier="specialist")

            # Parse JSON findings
            try:
                json_match = re.search(r'\[.*\]', response, re.DOTALL)
                if json_match:
                    findings = json.loads(json_match.group())
                    if isinstance(findings, list):
                        for f in findings:
                            self.on_finding({"skill": skill.name, "finding": f})
                        return [str(f) for f in findings]
                    else:
                        self.on_status(f"  [AI] Analysis returned non-list JSON, ignoring")
                else:
                    self.on_status(f"  [AI] No JSON found in analysis response ({len(response)} chars)")
            except json.JSONDecodeError as e:
                self.on_status(f"  [AI] Analysis JSON parse error: {e}")

        except Exception as e:
            self.on_status(f"  [AI] Analysis failed: {e}")

        return []

    def _process_output(self, skill: Skill, command: str, result: CommandResult):
        """Parse command output and update engagement state."""
        if not result.success and not result.stdout:
            return

        parsed = self.parser.auto_parse(command, result.stdout)

        if parsed["type"] == "nmap":
            data = parsed["data"]
            for host in data.get("hosts", []):
                if host not in self.state.discovered_hosts:
                    self.state.discovered_hosts.append(host.get("ip", host.get("hostname", "")))
            for port in data.get("ports", []):
                self.state.discovered_ports.append(port)
                # Update variables for next skills
                if port["service"] == "http" or port["port"] in [80, 443, 8080, 8443]:
                    self.state.findings["web_service_found"] = True
                if port["service"] == "ssh" or port["port"] == 22:
                    self.state.findings["ssh_found"] = True
                if port["service"] in ["smb", "microsoft-ds"] or port["port"] in [139, 445]:
                    self.state.findings["smb_found"] = True

        elif parsed["type"] == "vuln_scan":
            for vuln in parsed["data"]:
                self.state.discovered_vulns.append(vuln)
                if vuln.get("severity") in ["critical", "high"]:
                    self.state.findings["critical_vuln_found"] = True

        elif parsed["type"] == "sqli":
            data = parsed["data"]
            if data.get("injectable"):
                self.state.findings["sqli_vulnerability_identified"] = True
                self.state.discovered_vulns.append({
                    "name": "SQL Injection",
                    "severity": "critical",
                    "parameters": data.get("parameters", []),
                    "dbms": data.get("dbms"),
                })

        elif parsed["type"] == "bruteforce":
            for cred in parsed["data"]:
                self.state.discovered_creds.append(cred)
                self.state.findings["credentials_found"] = True

        # Detect WAF indicators from any output
        waf_keywords = ["cloudflare", "akamai", "incapsula", "sucuri", "mod_security",
                        "barracuda", "f5 big-ip", "imperva", "aws waf", "fortiweb"]
        combined_lower = (result.stdout + result.stderr).lower()
        for waf in waf_keywords:
            if waf in combined_lower:
                self.state.findings["waf_detected"] = True
                self.state.variables["waf_type"] = waf
                self.on_status(f"  [DETECT] 🛡️ WAF detected: {waf}")
                self.state.add_timeline_event("waf_detected", f"WAF: {waf}")
                if self.knowledge_graph:
                    self.knowledge_graph.add_waf(self.state.target, waf, source=skill.name)
                break

        # Feed Knowledge Graph with parsed data
        self._feed_knowledge_graph(skill, parsed)

        # Persist findings to database
        self._persist_findings(skill, parsed)

    def _feed_knowledge_graph(self, skill: Skill, parsed: Dict[str, Any]):
        """Feed parsed results into the Knowledge Graph."""
        if not self.knowledge_graph:
            return

        kg = self.knowledge_graph
        target = self.state.target

        if parsed["type"] == "nmap":
            data = parsed["data"]
            for host_info in data.get("hosts", []):
                ip = host_info.get("ip", host_info.get("hostname", ""))
                if ip:
                    kg.add_host(ip, hostname=host_info.get("hostname", ""), source=skill.name)
            for port_info in data.get("ports", []):
                kg.add_port(
                    host=port_info.get("host", target),
                    port=port_info.get("port", 0),
                    protocol=port_info.get("protocol", "tcp"),
                    service=port_info.get("service", ""),
                    version=port_info.get("version", ""),
                    source=skill.name,
                )

        elif parsed["type"] == "vuln_scan":
            for vuln in parsed["data"]:
                cve_id = vuln.get("name", vuln.get("template", ""))
                host = vuln.get("host", target)
                port = vuln.get("port", 0)
                if cve_id.startswith("CVE-"):
                    kg.add_cve(host, port, cve_id,
                               cvss=vuln.get("cvss", 0.0),
                               severity=vuln.get("severity", "unknown"),
                               description=vuln.get("description", ""),
                               source=skill.name)

        elif parsed["type"] == "sqli":
            data = parsed["data"]
            if data.get("injectable"):
                kg.add_cve(target, 80, "SQLi-Manual",
                           cvss=9.0, severity="critical",
                           description=f"SQL Injection: {data.get('dbms', 'unknown')} DBMS",
                           source=skill.name)

        elif parsed["type"] == "bruteforce":
            for cred in parsed["data"]:
                kg.add_credential(
                    service=cred.get("service", "unknown"),
                    host=cred.get("host", target),
                    username=cred.get("username", ""),
                    password=cred.get("password", ""),
                    source=skill.name,
                )

    def _persist_findings(self, skill: Skill, parsed: Dict[str, Any]):
        """Persist findings to FindingsDB for cross-engagement intelligence."""
        if not self.findings_db or not self._engagement_db_id:
            return

        db = self.findings_db
        eng_id = self._engagement_db_id

        try:
            if parsed["type"] == "nmap":
                data = parsed["data"]
                for host_data in data.get("hosts", []):
                    ip = host_data.get("ip", host_data.get("hostname", ""))
                    hostname = host_data.get("hostname", "")
                    host_id = db.save_host(eng_id, ip=ip, hostname=hostname, source="nmap")
                for port_data in data.get("ports", []):
                    host_ip = port_data.get("host", self.state.target)
                    host_id = db.save_host(eng_id, ip=host_ip, source="nmap")
                    db.save_service(
                        host_id,
                        port=port_data.get("port", 0),
                        protocol=port_data.get("protocol", "tcp"),
                        service=port_data.get("service", ""),
                        version=port_data.get("version", ""),
                        source="nmap",
                    )

            elif parsed["type"] == "vuln_scan":
                for vuln in parsed["data"]:
                    db.save_finding(
                        eng_id,
                        finding_type="vulnerability",
                        title=vuln.get("name", vuln.get("template", "Unknown Vuln")),
                        description=vuln.get("description", ""),
                        severity=vuln.get("severity", "medium"),
                        cve_id=vuln.get("cve_id"),
                        evidence=vuln.get("matched_at", ""),
                        skill_name=skill.name,
                    )

            elif parsed["type"] == "sqli":
                data = parsed["data"]
                if data.get("injectable"):
                    db.save_finding(
                        eng_id,
                        finding_type="vulnerability",
                        title=f"SQL Injection ({data.get('dbms', 'unknown')})",
                        severity="critical",
                        cvss=9.8,
                        evidence=json.dumps(data.get("parameters", [])),
                        skill_name=skill.name,
                    )

            elif parsed["type"] == "bruteforce":
                for cred in parsed["data"]:
                    host_ip = cred.get("host", self.state.target)
                    host_id = db.save_host(eng_id, ip=host_ip, source="bruteforce")
                    db.save_credential(
                        eng_id, host_id=host_id,
                        service=cred.get("service", ""),
                        username=cred.get("username", ""),
                        password_clear=cred.get("password", ""),
                        source="bruteforce",
                    )

            # Save learnings from this skill
            if self.state.discovered_vulns:
                db.save_learning(
                    "skill_effectiveness", skill.name,
                    json.dumps({"vulns_found": len(self.state.discovered_vulns)}),
                    confidence=0.7,
                )
        except Exception:
            pass  # DB persistence should never break the pentest

    def _try_auto_fix(self, command: str, result: CommandResult,
                      skill: Skill = None) -> Optional[CommandResult]:
        """
        Intelligently fix failed commands with multiple strategies:
        1. Missing tool → auto-install
        2. Permission denied → sudo
        3. WAF/rate-limit → adjust parameters
        4. Timeout → reduce scope
        5. AI-driven → ask AI for alternative command
        """
        stderr = result.stderr.lower()
        stdout = result.stdout.lower()
        combined = stderr + stdout

        # --- Strategy 1: Command not found → auto-install ---
        if result.returncode == 127 or "command not found" in stderr:
            cmd_name = command.split()[0]
            if cmd_name == "sudo" and len(command.split()) > 1:
                cmd_name = command.split()[1]

            self.on_status(f"  [AUTO-FIX] Installing missing tool: {cmd_name}")
            install_result = self.executor.execute(
                f"apt-get install -y {cmd_name}",
                timeout=120,
            )
            if install_result.success:
                return self.executor.execute(command, cwd=self.state.workspace)

        # --- Strategy 2: Permission denied → sudo ---
        if "permission denied" in stderr and not command.startswith("sudo"):
            self.on_status(f"  [AUTO-FIX] Retrying with sudo")
            return self.executor.execute(f"sudo {command}", cwd=self.state.workspace)

        # --- Strategy 3: WAF/Rate-limit detection → adapt ---
        waf_indicators = ["403 forbidden", "429 too many", "waf", "blocked",
                          "access denied", "cloudflare", "rate limit", "captcha"]
        if any(ind in combined for ind in waf_indicators):
            self.state.findings["waf_detected"] = True
            self.on_status(f"  [ADAPT] ⚡ WAF/rate-limit detected! Adjusting...")
            self.state.add_timeline_event("waf_detected", f"WAF detected on: {command[:60]}")

            # Apply common evasion tactics
            adapted_cmd = self._apply_waf_evasion(command)
            if adapted_cmd != command:
                self.on_status(f"  [ADAPT] New command: {adapted_cmd[:80]}")
                return self.executor.execute(adapted_cmd, cwd=self.state.workspace)

        # --- Strategy 4: Timeout → reduce scope ---
        if "timed out" in combined or result.duration >= COMMAND_TIMEOUT * 0.9:
            self.on_status(f"  [AUTO-FIX] Command timed out. Reducing scope...")
            reduced = self._reduce_command_scope(command)
            if reduced != command:
                return self.executor.execute(reduced, cwd=self.state.workspace,
                                             timeout=COMMAND_TIMEOUT)

        # --- Strategy 5: AI-driven fix (last resort) ---
        if self.ai_provider and skill:
            return self._ai_fix_command(command, result, skill)

        return None

    def _apply_waf_evasion(self, command: str) -> str:
        """Apply WAF evasion tactics to a command based on tool type."""
        parts = command.split()
        if not parts:
            return command

        tool = parts[0].replace("sudo", "").strip()
        if tool == "sudo" and len(parts) > 1:
            tool = parts[1]

        if tool in ("gobuster", "feroxbuster", "ffuf"):
            # Slow down and add random user-agent
            if "-t " not in command:
                command += " -t 5"
            else:
                command = re.sub(r'-t\s+\d+', '-t 5', command)
            if "--delay" not in command:
                command += " --delay 1s"
            return command

        if tool == "nuclei":
            if "-rl" not in command:
                command += " -rl 10 -c 3"
            return command

        if tool == "sqlmap":
            if "--tamper" not in command:
                command += " --tamper=space2comment,between,randomcase"
            if "--random-agent" not in command:
                command += " --random-agent"
            if "--delay" not in command:
                command += " --delay=2"
            return command

        if tool == "nmap":
            if "--max-rate" not in command:
                command += " --max-rate 100"
            if "-T" in command:
                command = re.sub(r'-T\d', '-T2', command)
            return command

        if tool == "hydra":
            if "-t " not in command:
                command += " -t 2"
            else:
                command = re.sub(r'-t\s+\d+', '-t 2', command)
            if "-W " not in command:
                command += " -W 3"
            return command

        return command

    def _reduce_command_scope(self, command: str) -> str:
        """Reduce command scope when it times out (fewer ports, smaller ranges)."""
        # Nmap: reduce port range
        if "nmap" in command and "-p-" in command:
            return command.replace("-p-", "-p 1-10000")
        if "nmap" in command and "-p 1-10000" in command:
            return command.replace("-p 1-10000", "-p 1-1000")

        # Gobuster/ffuf: use smaller wordlist
        if any(t in command for t in ["gobuster", "ffuf", "feroxbuster"]):
            big_lists = [
                "/usr/share/wordlists/dirbuster/directory-list-2.3-big.txt",
                "/usr/share/wordlists/dirbuster/directory-list-2.3-medium.txt",
            ]
            small = "/usr/share/wordlists/dirbuster/directory-list-2.3-small.txt"
            for big in big_lists:
                if big in command:
                    return command.replace(big, small)

        return command

    def _ai_fix_command(self, command: str, result: CommandResult,
                        skill: Skill) -> Optional[CommandResult]:
        """Ask AI to suggest an alternative command when all else fails."""
        try:
            error_section = skill.error_handling if hasattr(skill, 'error_handling') else ""
            prompt = (
                f"A pentesting command failed. Suggest ONE alternative command.\n\n"
                f"Original command: {command}\n"
                f"Exit code: {result.returncode}\n"
                f"Stderr: {result.stderr[:500]}\n"
                f"Stdout: {result.stdout[:500]}\n\n"
                f"Skill error handling guide:\n{error_section}\n\n"
                f"Output ONLY the fixed bash command. No explanation. One line."
            )
            response = self.ai_provider.chat_sync(prompt, tier="executor")
            fixed_cmd = response.strip().split('\n')[0].strip()
            # Sanity check: must look like a command
            if fixed_cmd and not fixed_cmd.startswith(('#', 'Note', 'The', 'I ', 'Try')):
                self.on_status(f"  [AI-FIX] Trying: {fixed_cmd[:80]}")
                return self.executor.execute(fixed_cmd, cwd=self.state.workspace)
        except Exception:
            pass
        return None

    def _enrich_with_threat_intel(self):
        """Enrich discovered ports/services with NVD CVEs, ExploitDB, and CISA KEV."""
        if not self.threat_intel:
            return

        self.on_status(f"\n[THREAT-INTEL] 🔍 Enriching {len(self.state.discovered_ports)} "
                       f"services with CVE/exploit data...")

        try:
            summary = self.threat_intel.get_enrichment_summary(self.state.discovered_ports)

            # Store enrichment in state context
            self.state.variables["threat_intel_summary"] = summary

            # Count what we found
            enriched = self.threat_intel.enrich_ports(self.state.discovered_ports)
            total_cves = sum(len(p.get("cves", [])) for p in enriched)
            total_exploits = sum(len(p.get("exploits", [])) for p in enriched)
            kev_count = sum(1 for p in enriched if p.get("kev_match"))

            self.on_status(f"[THREAT-INTEL] Found: {total_cves} CVEs, "
                           f"{total_exploits} exploits, {kev_count} CISA KEV matches")

            if kev_count > 0:
                self.on_status(f"[THREAT-INTEL] 🔥 {kev_count} actively exploited vulns — prioritizing!")
                self.state.findings["kev_vulns_found"] = True

            self.state.add_timeline_event("threat_intel_enrichment",
                f"Enriched: {total_cves} CVEs, {total_exploits} exploits, {kev_count} KEV",
                data={"cves": total_cves, "exploits": total_exploits, "kev": kev_count})

            # Add to context summary for AI planning
            self.on_finding({
                "skill": "threat_intel",
                "finding": f"Threat intel: {total_cves} CVEs, {total_exploits} exploits, "
                           f"{kev_count} actively exploited (CISA KEV)",
            })

        except Exception as e:
            self.on_status(f"[THREAT-INTEL] Enrichment error: {e}")

    def _save_engagement_learnings(self):
        """Save engagement findings and techniques to memory for future use."""
        try:
            from memory import Memory
            mem = Memory()

            # Save summary of what worked
            completed = self.state.get_completed_skills()
            failed = [n for n, e in self.state.skill_executions.items()
                      if e.status == SkillStatus.FAILED]

            tags = [
                f"target:{self.state.target}",
                f"type:{self.state.engagement_type}",
            ]
            if self.state.findings.get("waf_detected"):
                tags.append(f"waf:{self.state.variables.get('waf_type', 'unknown')}")

            # Save what was discovered
            summary_parts = [
                f"Pentest engagement on {self.state.target} ({self.state.engagement_type}).",
                f"Completed skills: {', '.join(completed[:10])}.",
            ]
            if failed:
                summary_parts.append(f"Failed skills: {', '.join(failed[:5])}.")
            if self.state.discovered_vulns:
                vulns = [v.get('name', '?') for v in self.state.discovered_vulns[:5]]
                summary_parts.append(f"Vulns found: {', '.join(vulns)}.")
            if self.state.discovered_ports:
                ports = [str(p.get('port', '?')) for p in self.state.discovered_ports[:10]]
                summary_parts.append(f"Open ports: {', '.join(ports)}.")

            mem.save_interaction(
                query=f"Pentest {self.state.target} ({self.state.engagement_type})",
                response=' '.join(summary_parts),
                commands_executed=[],
                was_useful=True,
                tags=tags,
            )
            self.on_status(f"  [MEMORY] Engagement learnings saved to collective memory.")
        except Exception as e:
            self.on_status(f"  [MEMORY] Could not save learnings: {e}")

    # --- Report Generation ---

    def generate_report(self, output_format: str = "markdown") -> str:
        """Generate the final pentest report."""
        if not self.state:
            return "No engagement data available."

        lines = []
        lines.append(f"# MundiX Penetration Test Report")
        lines.append(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**Target:** {self.state.target}")
        lines.append(f"**Type:** {self.state.engagement_type}")
        lines.append(f"**Duration:** {self.state.started_at} → {self.state.completed_at or 'ongoing'}")
        lines.append("")

        # Executive Summary
        progress = self.state.get_progress()
        lines.append(f"## Executive Summary")
        lines.append(f"This penetration test was conducted against **{self.state.target}** "
                      f"using the MundiX autonomous pentesting agent. "
                      f"A total of **{progress['completed']}** skills were executed across "
                      f"**{len(set(s['phase'] for s in self.state.plan))}** phases.")
        lines.append("")

        # Key Findings
        lines.append(f"## Key Findings")
        lines.append("")
        lines.append(f"| Category | Count |")
        lines.append(f"|---|---|")
        lines.append(f"| Hosts Discovered | {len(self.state.discovered_hosts)} |")
        lines.append(f"| Open Ports | {len(self.state.discovered_ports)} |")
        lines.append(f"| Vulnerabilities | {len(self.state.discovered_vulns)} |")
        lines.append(f"| Credentials | {len(self.state.discovered_creds)} |")
        lines.append("")

        # Vulnerabilities
        if self.state.discovered_vulns:
            lines.append(f"## Vulnerabilities")
            lines.append("")
            lines.append(f"| Severity | Name | Details |")
            lines.append(f"|---|---|---|")
            for vuln in self.state.discovered_vulns:
                severity = vuln.get("severity", "info").upper()
                name = vuln.get("name", vuln.get("template", "Unknown"))
                details = vuln.get("url", vuln.get("raw", ""))[:80]
                lines.append(f"| {severity} | {name} | {details} |")
            lines.append("")

        # Open Ports
        if self.state.discovered_ports:
            lines.append(f"## Open Ports")
            lines.append("")
            lines.append(f"| Host | Port | Protocol | Service | Version |")
            lines.append(f"|---|---|---|---|---|")
            for port in self.state.discovered_ports[:50]:
                lines.append(
                    f"| {port.get('host', '?')} | {port.get('port', '?')} | "
                    f"{port.get('protocol', '?')} | {port.get('service', '?')} | "
                    f"{port.get('version', '')} |"
                )
            lines.append("")

        # Credentials
        if self.state.discovered_creds:
            lines.append(f"## Discovered Credentials")
            lines.append("")
            lines.append(f"| Service | Host | Username | Password |")
            lines.append(f"|---|---|---|---|")
            for cred in self.state.discovered_creds:
                lines.append(
                    f"| {cred.get('service', '?')} | {cred.get('host', '?')} | "
                    f"{cred.get('username', '?')} | {cred.get('password', '***')} |"
                )
            lines.append("")

        # Skill Execution Details
        lines.append(f"## Skill Execution Details")
        lines.append("")
        lines.append(f"| Skill | Status | Commands | Findings | Duration |")
        lines.append(f"|---|---|---|---|---|")
        for name, ex in self.state.skill_executions.items():
            duration = ""
            if ex.started_at and ex.completed_at:
                try:
                    start = datetime.fromisoformat(ex.started_at)
                    end = datetime.fromisoformat(ex.completed_at)
                    duration = f"{(end - start).total_seconds():.0f}s"
                except (ValueError, TypeError):
                    pass
            lines.append(
                f"| {name} | {ex.status.value} | {len(ex.commands_executed)} | "
                f"{len(ex.findings)} | {duration} |"
            )
        lines.append("")

        # Timeline
        lines.append(f"## Timeline")
        lines.append("")
        for event in self.state.timeline:
            lines.append(f"- **{event['timestamp']}** [{event['type']}] {event['description']}")
        lines.append("")

        # Knowledge Graph Attack Chains
        if self.knowledge_graph:
            score = self.knowledge_graph.get_attack_surface_score()
            lines.append(f"## Attack Surface Analysis")
            lines.append(f"**Risk Score:** {score['risk_score']}/100")
            lines.append("")
            narrative = self.knowledge_graph.to_report_narrative()
            if narrative:
                lines.append(narrative)
                lines.append("")

        report = '\n'.join(lines)

        # Save report
        if self.state.workspace:
            report_path = os.path.join(self.state.workspace, "pentest_report.md")
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write(report)
            self.on_status(f"[REPORT] Saved to: {report_path}")

        return report


# ---------------------------------------------------------------------------
# CLI Entry Point (for testing)
# ---------------------------------------------------------------------------

def main():
    """CLI entry point for testing the orchestrator."""
    import sys

    skills_dir = sys.argv[1] if len(sys.argv) > 1 else SKILLS_DIR
    target = sys.argv[2] if len(sys.argv) > 2 else "example.com"

    def status_callback(msg):
        print(msg)

    def output_callback(line):
        print(f"    {line}")

    def finding_callback(finding):
        print(f"  [FINDING] {finding}")

    orchestrator = AgentOrchestrator(
        skills_dir=skills_dir,
        on_status=status_callback,
        on_output=output_callback,
        on_finding=finding_callback,
    )

    # Start engagement
    state = orchestrator.start_engagement(target, engagement_type="web")

    # Print plan
    print(f"\n{'='*60}")
    print(f"PENTEST PLAN ({len(state.plan)} skills)")
    print(f"{'='*60}")
    for step in state.plan:
        print(f"  [{step['phase']}] {step['skill']} ({step['commands']} cmds)")

    # Print progress
    print(f"\nProgress: {json.dumps(state.get_progress(), indent=2)}")

    # Print engagement profiles
    print(f"\nAvailable Engagement Types:")
    for name, profile in ENGAGEMENT_PROFILES.items():
        print(f"  {name}: {profile['description']} ({len(profile['phases'])} phases)")

    print(f"\n[OK] Orchestrator initialized successfully.")
    print(f"     Skills: {len(orchestrator.registry.get_all())}")
    print(f"     Plan steps: {len(state.plan)}")
    print(f"     Workspace: {state.workspace}")


if __name__ == "__main__":
    main()
