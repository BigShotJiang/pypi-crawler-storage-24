# bb2gh-core

> This is the **private source repository**. The public-facing repo is at [n8group-oss/bb2gh](https://github.com/n8group-oss/bb2gh).

[![CI](https://github.com/n8group-oss/bb2gh-core/actions/workflows/ci.yml/badge.svg)](https://github.com/n8group-oss/bb2gh-core/actions/workflows/ci.yml)
[![Security](https://github.com/n8group-oss/bb2gh-core/actions/workflows/security.yml/badge.svg)](https://github.com/n8group-oss/bb2gh-core/actions/workflows/security.yml)
[![License: BSL-1.1](https://img.shields.io/badge/License-BSL--1.1-blue.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)

**Bitbucket to GitHub migration tool** — source code, tests, CI/CD, and internal documentation.

## Repository Split

bb2gh uses a split-repo architecture:

- **[n8group-oss/bb2gh](https://github.com/n8group-oss/bb2gh)** (public) — Documentation, issue tracking, community files
- **n8group-oss/bb2gh-core** (private) — Source code, tests, CI/CD, internal docs

### Sync mechanism

A GitHub Action (`.github/workflows/sync-to-public.yml`) automatically pushes doc changes to the public repo on every push to main. The sync is authenticated via a GitHub App (`bb2gh-sync`). See `.sync-config.yml` for which files are synced.

### Issue flow

External users file issues on the public repo. A GitHub Action syncs new issues to Linear automatically with the `public:issue` label.

## Development

```bash
# Clone the repository
git clone https://github.com/n8group-oss/bb2gh-core.git
cd bb2gh-core

# Install Hatch (build system / environment manager)
pip install hatch

# Create the development environment (installs Python 3.11+ and all dependencies)
hatch env create

# Install pre-commit hooks
hatch run pre-commit install

# Run tests
hatch run test

# Run tests with coverage
hatch run test-cov

# Run linting
hatch run lint

# Run type checking
hatch run type-check

# Run all checks (lint + format-check + type-check + tests)
hatch run all
```

## Documentation

Full documentation is available at **[n8-group.gitbook.io/bb2gh](https://n8-group.gitbook.io/bb2gh/)**

Documentation source lives in `docs/gitbook/` and is synced to the public repo on every push to main.

## License

Business Source License 1.1 — see [LICENSE](LICENSE) for details.

The license allows free use for any purpose except offering a competing migration service. After 4 years from each release, that version converts to Apache 2.0.
