"""License sync service for CLI auto-refresh."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import httpx
import structlog

if TYPE_CHECKING:
    from bb2gh.models.license import LicenseSyncMeta

logger = structlog.get_logger()

_SYNC_TIMEOUT = 3.0  # seconds


@dataclass(frozen=True)
class SyncCheckResult:
    """Result of checking for a license update."""

    status: str  # 'up_to_date' | 'update_available' | 'no_active_license' | 'error'
    signed_token: str | None = None
    license_id: str | None = None
    tier: str | None = None
    repo_limit: int | None = None
    expires_at: str | None = None
    error_message: str | None = None


class LicenseSyncService:
    """Handles license sync checks and pending license management."""

    def __init__(
        self,
        bb2gh_dir: Path | None = None,
        api_base_url: str = "https://api.bb2gh.dev/functions/v1",
    ) -> None:
        self.bb2gh_dir = bb2gh_dir or Path.home() / ".bb2gh"
        self.bb2gh_dir.mkdir(parents=True, exist_ok=True)
        self._api_base_url = api_base_url
        self._meta_path = self.bb2gh_dir / "license_meta.json"
        self._pending_path = self.bb2gh_dir / "pending_license"

    def load_meta(self) -> LicenseSyncMeta:
        """Load sync metadata from disk."""
        from bb2gh.models.license import LicenseSyncMeta

        if not self._meta_path.exists():
            return LicenseSyncMeta()
        try:
            return LicenseSyncMeta.model_validate_json(self._meta_path.read_text())
        except Exception:
            logger.warning("corrupt_license_meta", path=str(self._meta_path))
            return LicenseSyncMeta()

    def save_meta(self, meta: LicenseSyncMeta) -> None:
        """Save sync metadata to disk."""
        self._meta_path.write_text(meta.model_dump_json())

    async def check_for_update(self, email: str, license_id: str) -> SyncCheckResult:
        """Check the license server for a newer license."""
        try:
            async with httpx.AsyncClient(timeout=_SYNC_TIMEOUT) as client:
                response = await client.get(
                    f"{self._api_base_url}/license-check",
                    params={"email": email, "lid": license_id},
                )

            if response.status_code == 404:
                return SyncCheckResult(status="not_found")

            if response.status_code == 429:
                return SyncCheckResult(status="rate_limited")

            if response.status_code != 200:
                return SyncCheckResult(
                    status="error",
                    error_message=f"HTTP {response.status_code}",
                )

            data = response.json()
            status = data.get("status")

            allowed_statuses = {"up_to_date", "update_available", "error"}
            if status not in allowed_statuses:
                return SyncCheckResult(
                    status="error",
                    error_message=f"Unknown status: {status}",
                )

            if status == "update_available" and not data.get("signed_token"):
                return SyncCheckResult(
                    status="error",
                    error_message="Missing signed_token for update_available status",
                )

            return SyncCheckResult(
                status=status,
                signed_token=data.get("signed_token"),
                license_id=data.get("license_id"),
                tier=data.get("tier"),
                repo_limit=data.get("repo_limit"),
                expires_at=data.get("expires_at"),
            )
        except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout, OSError) as exc:
            logger.debug("license_sync_network_error", error=str(exc))
            return SyncCheckResult(status="error", error_message=str(exc))

    def write_pending_license(self, signed_token: str) -> None:
        """Write a pending license for pickup on next CLI invocation."""
        self._pending_path.write_text(signed_token)

    def read_pending_license(self) -> str | None:
        """Read pending license if it exists."""
        if not self._pending_path.exists():
            return None
        return self._pending_path.read_text().strip()

    def clear_pending_license(self) -> None:
        """Remove pending license file."""
        self._pending_path.unlink(missing_ok=True)
