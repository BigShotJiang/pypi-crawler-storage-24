"""Webhook notification service for bb2gh.

Sends webhook notifications for migration lifecycle events.
Supports retry with exponential backoff and event filtering.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import httpx
import structlog

if TYPE_CHECKING:
    from bb2gh.models.config import MigrationEvent, WebhookConfig

logger = structlog.get_logger(__name__)

_MAX_ATTEMPTS = 3
_BACKOFF_BASE_SECONDS = 1.0
_REQUEST_TIMEOUT_SECONDS = 30.0


class WebhookNotifier:
    """Sends webhook notifications for migration events.

    Delivers POST requests with JSON payloads to configured webhook
    endpoints. Supports event filtering (only matching events are sent)
    and retry with exponential backoff on failure.

    Webhook URLs are never logged in plain text since they may contain
    authentication tokens in query parameters.
    """

    def __init__(
        self,
        *,
        webhooks: list[WebhookConfig],
        backoff_base: float = _BACKOFF_BASE_SECONDS,
        ssl_verify: str | bool = True,
    ) -> None:
        """Initialize the notifier with webhook configurations.

        Args:
            webhooks: List of webhook configurations to notify.
            backoff_base: Base delay in seconds for exponential backoff
                between retry attempts. Defaults to 1.0.
            ssl_verify: SSL verification setting for httpx clients.
        """
        self._webhooks = webhooks
        self._backoff_base = backoff_base
        self._ssl_verify = ssl_verify

    async def notify(self, event: MigrationEvent) -> None:
        """Send notification to all webhooks matching the event.

        Notifications are best-effort: failures are logged but never
        raised. Each webhook is processed independently so a failure
        on one does not block others.

        Args:
            event: The migration event to broadcast.
        """
        if not self._webhooks:
            return

        for webhook in self._webhooks:
            if event.event not in webhook.events:
                continue
            await self._send_webhook(webhook, event)

    async def _send_webhook(
        self,
        webhook: WebhookConfig,
        event: MigrationEvent,
    ) -> None:
        """Send a single webhook notification with retry.

        Retries up to ``_MAX_ATTEMPTS`` times with exponential backoff
        (1s, 2s, 4s) on HTTP errors or connection failures.

        Args:
            webhook: The webhook configuration.
            event: The migration event payload.
        """
        payload = event.model_dump()

        for attempt in range(1, _MAX_ATTEMPTS + 1):
            try:
                async with httpx.AsyncClient(
                    timeout=_REQUEST_TIMEOUT_SECONDS,
                    verify=self._ssl_verify,
                ) as client:
                    response = await client.post(
                        webhook.url,
                        json=payload,
                        headers=webhook.headers,
                    )
                    response.raise_for_status()

                logger.info(
                    "Webhook notification sent",
                    event_type=event.event,
                    migration_id=event.migration_id,
                    attempt=attempt,
                )
                return

            except httpx.HTTPError as exc:
                logger.warning(
                    "Webhook notification failed",
                    event_type=event.event,
                    migration_id=event.migration_id,
                    attempt=attempt,
                    max_attempts=_MAX_ATTEMPTS,
                    error=str(exc),
                )

                if attempt < _MAX_ATTEMPTS:
                    backoff = self._backoff_base * (2 ** (attempt - 1))
                    await asyncio.sleep(backoff)

        logger.error(
            "Webhook notification exhausted all retries",
            event_type=event.event,
            migration_id=event.migration_id,
            max_attempts=_MAX_ATTEMPTS,
        )
