"""Credential store abstraction for bb2gh.

Supports multiple backends:
- KEYRING: OS-level secure storage via python-keyring
- ENV: Environment variables (read-only, for CI/CD)

Secrets are keyed as "bb2gh:{profile}:{source|target}:{field}".
"""

from __future__ import annotations

import os
from enum import StrEnum
from typing import Any


class StorageBackend(StrEnum):
    """Credential storage backend type."""

    KEYRING = "keyring"
    ENV = "env"


def _keyring_available() -> bool:
    """Check if python-keyring is installed and functional."""
    try:
        import keyring
        from keyring.backends.fail import Keyring as FailKeyring

        backend = keyring.get_keyring()
        return not isinstance(backend, FailKeyring)
    except ImportError:
        return False


SERVICE_NAME = "bb2gh"


class CredentialStore:
    """Abstraction over credential storage backends.

    Supports two backends:
    - ``StorageBackend.KEYRING``: Uses the OS keychain via python-keyring.
      Requires the ``keyring`` package (install with ``pip install bb2gh[secure]``).
    - ``StorageBackend.ENV``: Reads from environment variables (read-only).

    The ``_keyring`` parameter accepts a keyring-compatible module for
    dependency injection in tests. At runtime, the real ``keyring`` module
    is used via ``auto_detect()``.
    """

    def __init__(
        self,
        backend: StorageBackend = StorageBackend.ENV,
        _keyring: Any = None,
    ) -> None:
        self.backend = backend
        self._keyring = _keyring

    @classmethod
    def auto_detect(cls) -> CredentialStore:
        """Create a CredentialStore with the best available backend.

        Prefers keyring when available; falls back to environment variables.
        """
        if _keyring_available():
            import keyring

            return cls(backend=StorageBackend.KEYRING, _keyring=keyring)
        return cls(backend=StorageBackend.ENV)

    def get_secret(self, key: str) -> str | None:
        """Retrieve a secret by key.

        For the KEYRING backend, the key format is ``bb2gh:{username}``
        where ``{username}`` is the portion after the service name prefix.
        For the ENV backend, the key is used directly as an environment
        variable name.

        Returns:
            The secret value, or None if not found.
        """
        if self.backend == StorageBackend.ENV:
            return os.environ.get(key)
        if self.backend == StorageBackend.KEYRING:
            username = key.removeprefix(f"{SERVICE_NAME}:")
            result: str | None = self._keyring.get_password(SERVICE_NAME, username)
            return result
        return None

    def set_secret(self, key: str, value: str) -> None:
        """Store a secret.

        Only supported by the KEYRING backend. The ENV backend raises
        ``NotImplementedError`` since environment variables should be
        set externally.

        Raises:
            NotImplementedError: If the backend does not support writing.
        """
        if self.backend == StorageBackend.ENV:
            raise NotImplementedError(
                "ENV backend is read-only. Use keyring or set env vars manually."
            )
        if self.backend == StorageBackend.KEYRING:
            username = key.removeprefix(f"{SERVICE_NAME}:")
            self._keyring.set_password(SERVICE_NAME, username, value)

    def delete_secret(self, key: str) -> None:
        """Delete a stored secret.

        Only supported by the KEYRING backend.

        Raises:
            NotImplementedError: If the backend does not support deletion.
        """
        if self.backend == StorageBackend.ENV:
            raise NotImplementedError("ENV backend is read-only.")
        if self.backend == StorageBackend.KEYRING:
            username = key.removeprefix(f"{SERVICE_NAME}:")
            self._keyring.delete_password(SERVICE_NAME, username)
