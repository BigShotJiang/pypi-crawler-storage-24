"""Pipe mapping registry for Bitbucket-to-GitHub Actions classification.

Contains the mapping table of 32 Bitbucket pipes to their GitHub Actions
equivalents. Derived from GitHub Actions Importer documentation (MIT license).

Usage:
    level, mapping = classify_pipe("atlassian/aws-s3-deploy:0.6.0")
    if mapping:
        print(mapping.gh_actions)  # ["aws-actions/configure-aws-credentials", "run"]
"""

from __future__ import annotations

from dataclasses import dataclass, field

from bb2gh.models.pipeline import PipeSupportLevel


@dataclass(frozen=True)
class PipeMapping:
    """Mapping from a Bitbucket pipe to GitHub Actions equivalent(s)."""

    bitbucket_pipe: str
    gh_actions: list[str] = field(default_factory=list)
    unsupported_options: list[str] = field(default_factory=list)
    support_level: PipeSupportLevel = PipeSupportLevel.SUPPORTED


def _m(
    pipe: str,
    actions: list[str],
    *,
    unsupported: list[str] | None = None,
) -> PipeMapping:
    """Shorthand factory for PipeMapping entries."""
    opts = unsupported or []
    return PipeMapping(
        bitbucket_pipe=pipe,
        gh_actions=actions,
        unsupported_options=opts,
        support_level=PipeSupportLevel.PARTIALLY_SUPPORTED if opts else PipeSupportLevel.SUPPORTED,
    )


# ---------------------------------------------------------------------------
# Registry — 32 pipes from GH Actions Importer docs (MIT)
# Source: https://github.com/github/gh-actions-importer/tree/main/docs/bitbucket
# ---------------------------------------------------------------------------
PIPE_REGISTRY: dict[str, PipeMapping] = {
    # AWS
    "atlassian/aws-cloudformation-deploy": _m(
        "atlassian/aws-cloudformation-deploy",
        ["aws-actions/configure-aws-credentials", "aws-actions/aws-cloudformation-github-deploy"],
        unsupported=[
            "WAIT",
            "WAIT_INTERVAL",
            "WITH_DEFAULT_TAGS",
            "OUTPUTS_FILENAME",
            "EXTRA_PARAMS",
            "DEBUG",
        ],
    ),
    "atlassian/aws-cloudfront-invalidate": _m(
        "atlassian/aws-cloudfront-invalidate",
        ["aws-actions/configure-aws-credentials", "run"],
        unsupported=["DEBUG"],
    ),
    "atlassian/aws-code-deploy": _m(
        "atlassian/aws-code-deploy",
        ["aws-actions/configure-aws-credentials", "run"],
        unsupported=["WAIT", "WAIT_INTERVAL", "DEBUG"],
    ),
    "atlassian/aws-ecs-deploy": _m(
        "atlassian/aws-ecs-deploy",
        [
            "aws-actions/configure-aws-credentials",
            "aws-actions/amazon-ecs-render-task-definition",
            "aws-actions/amazon-ecs-deploy-task-definition",
        ],
        unsupported=["DEBUG", "WAIT"],
    ),
    "atlassian/aws-elasticbeanstalk-deploy": _m(
        "atlassian/aws-elasticbeanstalk-deploy",
        ["aws-actions/configure-aws-credentials", "run"],
        unsupported=["WAIT", "WAIT_INTERVAL", "WARMUP_INTERVAL", "DEBUG"],
    ),
    "atlassian/aws-lambda-deploy": _m(
        "atlassian/aws-lambda-deploy",
        ["aws-actions/configure-aws-credentials", "run"],
        unsupported=["WAIT", "WAIT_INTERVAL", "DEBUG"],
    ),
    "atlassian/aws-s3-deploy": _m(
        "atlassian/aws-s3-deploy",
        ["aws-actions/configure-aws-credentials", "run"],
        unsupported=["DEBUG", "PRE_EXECUTION_SCRIPT"],
    ),
    "atlassian/aws-sam-deploy": _m(
        "atlassian/aws-sam-deploy",
        ["aws-actions/setup-sam", "aws-actions/configure-aws-credentials", "run"],
    ),
    # Azure
    "atlassian/azure-aca-deploy": _m(
        "atlassian/azure-aca-deploy",
        ["azure/login", "azure/container-apps-deploy-action"],
        unsupported=["DEBUG"],
    ),
    "atlassian/azure-acr-push-image": _m(
        "atlassian/azure-acr-push-image",
        ["azure/docker-login", "run"],
        unsupported=["DEBUG"],
    ),
    "atlassian/azure-arm-deploy": _m(
        "atlassian/azure-arm-deploy",
        ["azure/login", "azure/cli", "azure/arm-deploy"],
        unsupported=["DEBUG"],
    ),
    "atlassian/azure-cli-run": _m(
        "atlassian/azure-cli-run",
        ["azure/login", "azure/cli"],
        unsupported=["DEBUG"],
    ),
    "atlassian/azure-functions-deploy": _m(
        "atlassian/azure-functions-deploy",
        ["azure/login", "azure/functions-action"],
        unsupported=["DEBUG"],
    ),
    "atlassian/azure-storage-deploy": _m(
        "atlassian/azure-storage-deploy",
        ["azure/login", "run"],
    ),
    "atlassian/azure-web-apps-containers-deploy": _m(
        "atlassian/azure-web-apps-containers-deploy",
        ["azure/login", "run"],
    ),
    "atlassian/azure-web-apps-deploy": _m(
        "atlassian/azure-web-apps-deploy",
        ["azure/login", "azure/webapps-deploy"],
        unsupported=["DEBUG"],
    ),
    # Bitbucket / CI utilities
    "atlassian/bitbucket-upload-file": _m(
        "atlassian/bitbucket-upload-file",
        ["actions/upload-artifact"],
        unsupported=[
            "DEBUG",
            "ACCOUNT",
            "REPOSITORY",
            "BITBUCKET_USERNAME",
            "BITBUCKET_APP_PASSWORD",
            "BITBUCKET_ACCESS_TOKEN",
        ],
    ),
    "atlassian/checkstyle-report": _m(
        "atlassian/checkstyle-report",
        ["jwgmeligmeyling/checkstyle-github-action"],
        unsupported=["REPORT_FAIL_SEVERITY", "CHECKSTYLE_REPORT_ID"],
    ),
    "atlassian/firebase-deploy": _m(
        "atlassian/firebase-deploy",
        ["FirebaseExtended/action-hosting-deploy"],
        unsupported=[
            "KEY_FILE",
            "FIREBASE_TOKEN",
            "NODE_JS_VERSION",
            "MESSAGE",
            "EXTRA_ARGS",
            "MULTI_SITES_CONFIG",
            "DEBUG",
        ],
    ),
    "atlassian/ftp-deploy": _m(
        "atlassian/ftp-deploy",
        ["run"],
    ),
    "atlassian/git-secrets-scan": _m(
        "atlassian/git-secrets-scan",
        ["actions/checkout", "run"],
        unsupported=[
            "CUSTOM_PATTERN_ARGS",
            "FILES_IGNORED",
            "ANNOTATION_SUMMARY",
            "ANNOTATION_DESCRIPTION",
            "DEBUG",
        ],
    ),
    # Google Cloud
    "atlassian/google-app-engine-deploy": _m(
        "atlassian/google-app-engine-deploy",
        [
            "actions/checkout",
            "google-github-actions/auth",
            "google-github-actions/setup-gcloud",
            "run",
        ],
        unsupported=["DEBUG", "CLOUD_BUILD_TIMEOUT"],
    ),
    "atlassian/google-cloud-storage-deploy": _m(
        "atlassian/google-cloud-storage-deploy",
        ["google-github-actions/auth", "google-github-actions/upload-cloud-storage"],
        unsupported=["DEBUG", "STORAGE_CLASS", "EXTRA_ARGS"],
    ),
    "atlassian/google-gke-kubectl-run": _m(
        "atlassian/google-gke-kubectl-run",
        ["google-github-actions/auth", "google-github-actions/setup-gcloud", "run"],
        unsupported=["DEBUG"],
    ),
    # Hosting / Deployment
    "atlassian/heroku-deploy": _m(
        "atlassian/heroku-deploy",
        ["AkhileshNS/heroku-deploy"],
        unsupported=["ACTION", "ZIP_FILE", "WAIT", "CONFIG_VARS", "DEBUG"],
    ),
    # Package publishing
    "atlassian/npm-publish": _m(
        "atlassian/npm-publish",
        ["actions/setup-node", "run"],
        unsupported=["DEBUG"],
    ),
    "atlassian/pypi-publish": _m(
        "atlassian/pypi-publish",
        ["actions/setup-python", "pypa/gh-action-pypi-publish"],
        unsupported=["DEBUG"],
    ),
    # File transfer
    "atlassian/rsync-deploy": _m(
        "atlassian/rsync-deploy",
        ["Burnett01/rsync-deployments"],
        unsupported=["SSH_KEY", "EXTRA_ARGS", "SSH_ARGS", "DELETE_FLAG", "DEBUG"],
    ),
    "atlassian/sftp-deploy": _m(
        "atlassian/sftp-deploy",
        ["shimataro/ssh-key-action", "run"],
        unsupported=["DEBUG", "SSH_KEY"],
    ),
    # Serverless
    "atlassian/serverless-deploy": _m(
        "atlassian/serverless-deploy",
        ["serverless/github-action", "run"],
        unsupported=["DEBUG"],
    ),
    # Notifications
    "atlassian/slack-notify": _m(
        "atlassian/slack-notify",
        ["slackapi/slack-github-action"],
        unsupported=["DEBUG"],
    ),
    # Triggering
    "atlassian/trigger-pipeline": _m(
        "atlassian/trigger-pipeline",
        ["run"],
        unsupported=[
            "BITBUCKET_USERNAME",
            "BITBUCKET_APP_PASSWORD",
            "BITBUCKET_ACCESS_TOKEN",
            "CUSTOM_PIPELINE_NAME",
            "REF_TYPE",
            "WAIT",
            "WAIT_MAX_TIMEOUT",
            "DEBUG",
        ],
    ),
}


def classify_pipe(pipe_reference: str) -> tuple[PipeSupportLevel, PipeMapping | None]:
    """Classify a Bitbucket pipe reference against the registry.

    Strips the version suffix (e.g. "atlassian/aws-s3-deploy:0.6.0" →
    "atlassian/aws-s3-deploy") and looks up in PIPE_REGISTRY.

    Args:
        pipe_reference: Full pipe reference string from bitbucket-pipelines.yml.

    Returns:
        Tuple of (support level, PipeMapping or None if unsupported).
    """
    # Strip version suffix
    pipe_name = pipe_reference.split(":")[0] if ":" in pipe_reference else pipe_reference

    mapping = PIPE_REGISTRY.get(pipe_name)
    if mapping is None:
        return PipeSupportLevel.UNSUPPORTED, None

    return mapping.support_level, mapping
