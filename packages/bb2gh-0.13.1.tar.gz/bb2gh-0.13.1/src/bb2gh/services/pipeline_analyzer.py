"""Pipeline analyzer service for bb2gh discovery.

Parses bitbucket-pipelines.yml and produces a PipelineAnalysis with
per-step classification and migration complexity scoring.

All functions are pure (no I/O) — the adapter layer handles file fetching.
"""

from __future__ import annotations

from typing import Any

import structlog
import yaml  # type: ignore[import-untyped]

from bb2gh.models.pipeline import (
    PipelineAnalysis,
    PipelineDefinitionInfo,
    PipelineMigrationComplexity,
    PipelineStepInfo,
    PipeSupportLevel,
)
from bb2gh.services.pipe_registry import classify_pipe

logger = structlog.get_logger(__name__)

# Mapping from bitbucket-pipelines.yml top-level keys to trigger types
_TRIGGER_TYPE_MAP: dict[str, str] = {
    "default": "default",
    "branches": "branch",
    "tags": "tag",
    "pull-requests": "pull-request",
    "custom": "custom",
    "bookmarks": "bookmark",
}


def _empty_analysis(*, notes: list[str] | None = None) -> PipelineAnalysis:
    """Create an empty PipelineAnalysis for repos without pipelines."""
    return PipelineAnalysis(
        has_pipelines=False,
        pipeline_count=0,
        total_step_count=0,
        pipelines=[],
        supported_step_count=0,
        partially_supported_step_count=0,
        unsupported_step_count=0,
        script_step_count=0,
        uses_caches=False,
        uses_services=False,
        uses_artifacts=False,
        uses_deployment_environments=False,
        uses_parallel_steps=False,
        uses_conditions=False,
        migration_complexity=PipelineMigrationComplexity.TRIVIAL,
        migration_notes=notes or [],
    )


def _parse_step(step_dict: dict[str, Any]) -> tuple[list[PipelineStepInfo], dict[str, bool]]:
    """Parse a single step dict into PipelineStepInfo list + detected features.

    A step may contain multiple pipe references in its script list.
    Each pipe is emitted as a separate PipelineStepInfo so that per-pipe
    classification and counting works correctly.  If no pipes are found the
    step is returned as a single SCRIPT entry.
    """
    name = step_dict.get("name")
    features: dict[str, bool] = {
        "caches": "caches" in step_dict,
        "services": "services" in step_dict,
        "artifacts": "artifacts" in step_dict,
        "docker": "image" in step_dict,
        "conditions": "condition" in step_dict,
        "deployment": "deployment" in step_dict,
    }

    # Collect all pipe references from the script list
    scripts = step_dict.get("script", [])
    pipe_refs: list[str] = []
    for entry in scripts:
        if isinstance(entry, dict) and "pipe" in entry:
            pipe_refs.append(entry["pipe"])

    if pipe_refs:
        infos: list[PipelineStepInfo] = []
        for pipe_ref in pipe_refs:
            level, mapping = classify_pipe(pipe_ref)
            infos.append(
                PipelineStepInfo(
                    name=name,
                    pipe=pipe_ref,
                    support_level=level,
                    unsupported_options=mapping.unsupported_options if mapping else [],
                    gh_actions_equivalent=mapping.gh_actions[0] if mapping else None,
                )
            )
        return infos, features
    else:
        return [
            PipelineStepInfo(
                name=name,
                pipe=None,
                support_level=PipeSupportLevel.SCRIPT,
                unsupported_options=[],
                gh_actions_equivalent=None,
            )
        ], features


def _parse_step_list(
    steps_list: list[Any],
) -> tuple[list[PipelineStepInfo], dict[str, bool]]:
    """Parse a list of steps (may include parallel groups)."""
    all_steps: list[PipelineStepInfo] = []
    agg_features: dict[str, bool] = {
        "caches": False,
        "services": False,
        "artifacts": False,
        "docker": False,
        "parallel": False,
        "conditions": False,
        "deployment": False,
    }

    for item in steps_list:
        if not isinstance(item, dict):
            continue

        if "parallel" in item:
            agg_features["parallel"] = True
            parallel_steps = item["parallel"]
            if isinstance(parallel_steps, list):
                for pitem in parallel_steps:
                    if isinstance(pitem, dict) and "step" in pitem:
                        step_infos, features = _parse_step(pitem["step"])
                        all_steps.extend(step_infos)
                        for k, v in features.items():
                            if v:
                                agg_features[k] = True
        elif "step" in item:
            step_infos, features = _parse_step(item["step"])
            all_steps.extend(step_infos)
            for k, v in features.items():
                if v:
                    agg_features[k] = True

    return all_steps, agg_features


def _parse_pipeline_section(
    section_key: str,
    section_value: object,
    trigger_type: str,
) -> list[PipelineDefinitionInfo]:
    """Parse a pipeline section (default, branches, tags, etc.)."""
    definitions: list[PipelineDefinitionInfo] = []

    if trigger_type == "default" and isinstance(section_value, list):
        steps, features = _parse_step_list(section_value)
        definitions.append(
            PipelineDefinitionInfo(
                name="default",
                trigger_type="default",
                step_count=len(steps),
                steps=steps,
                uses_caches=features.get("caches", False),
                uses_services=features.get("services", False),
                uses_artifacts=features.get("artifacts", False),
                uses_docker=features.get("docker", False),
                uses_parallel=features.get("parallel", False),
                uses_conditions=features.get("conditions", False),
                uses_deployment=features.get("deployment", False),
            )
        )
    elif isinstance(section_value, dict):
        for pattern, step_list in section_value.items():
            if not isinstance(step_list, list):
                continue
            steps, features = _parse_step_list(step_list)
            definitions.append(
                PipelineDefinitionInfo(
                    name=f"{section_key}/{pattern}",
                    trigger_type=trigger_type,
                    step_count=len(steps),
                    steps=steps,
                    uses_caches=features.get("caches", False),
                    uses_services=features.get("services", False),
                    uses_artifacts=features.get("artifacts", False),
                    uses_docker=features.get("docker", False),
                    uses_parallel=features.get("parallel", False),
                    uses_conditions=features.get("conditions", False),
                    uses_deployment=features.get("deployment", False),
                )
            )

    return definitions


def calculate_pipeline_migration_complexity(
    *,
    total_steps: int,
    supported: int,
    partially_supported: int,
    unsupported: int,
    script: int,
    feature_count: int,
) -> PipelineMigrationComplexity:
    """Calculate overall pipeline migration complexity.

    Thresholds:
    - TRIVIAL: all steps supported/script, no special features
    - LOW: >80% supported (including script), <=2 special features
    - MEDIUM: 50-80% supported, or >2 special features
    - HIGH: <50% supported, or heavy feature usage (>4)
    """
    if total_steps == 0:
        return PipelineMigrationComplexity.TRIVIAL

    convertible = supported + script + partially_supported
    convertible_ratio = convertible / total_steps

    if unsupported == 0 and feature_count == 0:
        return PipelineMigrationComplexity.TRIVIAL

    if convertible_ratio > 0.8 and feature_count <= 2:
        return PipelineMigrationComplexity.LOW

    if convertible_ratio < 0.5 or feature_count > 4:
        return PipelineMigrationComplexity.HIGH

    return PipelineMigrationComplexity.MEDIUM


def parse_pipeline_config(raw_yaml: str) -> PipelineAnalysis:
    """Parse a bitbucket-pipelines.yml string into a PipelineAnalysis."""
    try:
        data = yaml.safe_load(raw_yaml)
    except yaml.YAMLError as e:
        logger.warning("pipeline_yaml_parse_error", error=str(e))
        return _empty_analysis(notes=[f"Failed to parse pipeline YAML: {e}"])

    if not isinstance(data, dict):
        return _empty_analysis(notes=["Pipeline file is not a valid YAML mapping"])

    pipelines_section = data.get("pipelines")
    if not pipelines_section or not isinstance(pipelines_section, dict):
        return _empty_analysis()

    # Parse all pipeline sections
    all_definitions: list[PipelineDefinitionInfo] = []
    for section_key, trigger_type in _TRIGGER_TYPE_MAP.items():
        if section_key in pipelines_section:
            defs = _parse_pipeline_section(
                section_key, pipelines_section[section_key], trigger_type
            )
            all_definitions.extend(defs)

    if not all_definitions:
        return _empty_analysis()

    # Aggregate metrics
    total_steps = sum(d.step_count for d in all_definitions)
    supported = sum(
        1 for d in all_definitions for s in d.steps if s.support_level == PipeSupportLevel.SUPPORTED
    )
    partially = sum(
        1
        for d in all_definitions
        for s in d.steps
        if s.support_level == PipeSupportLevel.PARTIALLY_SUPPORTED
    )
    unsupported = sum(
        1
        for d in all_definitions
        for s in d.steps
        if s.support_level == PipeSupportLevel.UNSUPPORTED
    )
    script = sum(
        1 for d in all_definitions for s in d.steps if s.support_level == PipeSupportLevel.SCRIPT
    )

    # Aggregate feature flags
    uses_caches = any(d.uses_caches for d in all_definitions)
    uses_services = any(d.uses_services for d in all_definitions)
    uses_artifacts = any(d.uses_artifacts for d in all_definitions)
    uses_deployment = any(d.uses_deployment for d in all_definitions)
    uses_parallel = any(d.uses_parallel for d in all_definitions)
    uses_conditions = any(d.uses_conditions for d in all_definitions)

    feature_count = sum(
        [
            uses_caches,
            uses_services,
            uses_artifacts,
            uses_deployment,
            uses_parallel,
            uses_conditions,
        ]
    )

    complexity = calculate_pipeline_migration_complexity(
        total_steps=total_steps,
        supported=supported,
        partially_supported=partially,
        unsupported=unsupported,
        script=script,
        feature_count=feature_count,
    )

    # Generate migration notes
    notes: list[str] = []
    if unsupported > 0:
        unsupported_pipes = {
            s.pipe
            for d in all_definitions
            for s in d.steps
            if s.support_level == PipeSupportLevel.UNSUPPORTED and s.pipe
        }
        notes.append(
            f"{unsupported} unsupported pipe(s) require manual conversion: "
            + ", ".join(sorted(unsupported_pipes))
        )
    if partially > 0:
        notes.append(f"{partially} partially supported pipe(s) have unsupported options")
    if uses_caches:
        notes.append("Uses caches — review GH Actions cache configuration")
    if uses_services:
        notes.append("Uses services — convert to GH Actions service containers")
    if uses_deployment:
        notes.append("Uses deployment environments — configure GH Environments")
    if uses_conditions:
        notes.append("Uses conditions — convert to GH Actions 'if' expressions")

    return PipelineAnalysis(
        has_pipelines=True,
        pipeline_count=len(all_definitions),
        total_step_count=total_steps,
        pipelines=all_definitions,
        supported_step_count=supported,
        partially_supported_step_count=partially,
        unsupported_step_count=unsupported,
        script_step_count=script,
        uses_caches=uses_caches,
        uses_services=uses_services,
        uses_artifacts=uses_artifacts,
        uses_deployment_environments=uses_deployment,
        uses_parallel_steps=uses_parallel,
        uses_conditions=uses_conditions,
        migration_complexity=complexity,
        migration_notes=notes,
    )
