"""Discovery service for bb2gh.

Provides repository analysis and complexity scoring for migration planning.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import structlog

from bb2gh.models.inventory import (
    ComplexityLevel,
    ComplexityScore,
    LargeFileInfo,
    LFSInfo,
    RepositoryInventoryItem,
)
from bb2gh.models.pipeline import PipelineAnalysis
from bb2gh.services.pipeline_analyzer import parse_pipeline_config

if TYPE_CHECKING:
    from bb2gh.adapters.base import BitbucketSourceAdapter
    from bb2gh.models.repository import Repository

logger = structlog.get_logger(__name__)


# Complexity scoring thresholds
@dataclass(frozen=True)
class SizeThresholds:
    """Size thresholds for complexity scoring."""

    simple_max_mb: float = 100.0  # Up to 100MB is simple
    moderate_max_mb: float = 1024.0  # 100MB-1GB is moderate
    # Above 1GB is complex


@dataclass(frozen=True)
class BranchThresholds:
    """Branch count thresholds for complexity scoring."""

    simple_max: int = 10  # Up to 10 branches is simple
    moderate_max: int = 50  # 10-50 branches is moderate
    # Above 50 is complex


@dataclass(frozen=True)
class PRThresholds:
    """Pull request count thresholds for complexity scoring."""

    simple_max: int = 50  # Up to 50 PRs is simple
    moderate_max: int = 200  # 50-200 PRs is moderate
    # Above 200 is complex


# Score weights for each factor
SCORE_WEIGHTS = {
    "size": 30,  # Size contributes up to 30 points
    "branches": 25,  # Branches contribute up to 25 points
    "prs": 25,  # PRs contribute up to 25 points
    "lfs": 20,  # LFS contributes up to 20 points
}


def calculate_size_score(size_bytes: int | None) -> tuple[int, ComplexityLevel]:
    """Calculate complexity score contribution from repository size.

    Args:
        size_bytes: Repository size in bytes, or None if unknown.

    Returns:
        Tuple of (score contribution, complexity level for this factor).
    """
    if size_bytes is None:
        return 0, ComplexityLevel.SIMPLE

    size_mb = size_bytes / (1024 * 1024)
    thresholds = SizeThresholds()

    if size_mb <= thresholds.simple_max_mb:
        # Simple: 0-10 points based on size within range
        score = int((size_mb / thresholds.simple_max_mb) * 10)
        return score, ComplexityLevel.SIMPLE
    elif size_mb <= thresholds.moderate_max_mb:
        # Moderate: 10-20 points
        ratio = (size_mb - thresholds.simple_max_mb) / (
            thresholds.moderate_max_mb - thresholds.simple_max_mb
        )
        score = 10 + int(ratio * 10)
        return score, ComplexityLevel.MODERATE
    else:
        # Complex: 20-30 points (caps at 30)
        # Scale from 1GB to 5GB for the 20-30 range
        extra_gb = (size_mb - thresholds.moderate_max_mb) / 1024
        score = 20 + min(int(extra_gb * 2.5), 10)
        return score, ComplexityLevel.COMPLEX


def calculate_branch_score(branch_count: int | None) -> tuple[int, ComplexityLevel]:
    """Calculate complexity score contribution from branch count.

    Args:
        branch_count: Number of branches, or None if unknown.

    Returns:
        Tuple of (score contribution, complexity level for this factor).
    """
    if branch_count is None:
        return 0, ComplexityLevel.SIMPLE

    thresholds = BranchThresholds()

    if branch_count <= thresholds.simple_max:
        # Simple: 0-8 points
        score = int((branch_count / thresholds.simple_max) * 8)
        return score, ComplexityLevel.SIMPLE
    elif branch_count <= thresholds.moderate_max:
        # Moderate: 8-17 points
        ratio = (branch_count - thresholds.simple_max) / (
            thresholds.moderate_max - thresholds.simple_max
        )
        score = 8 + int(ratio * 9)
        return score, ComplexityLevel.MODERATE
    else:
        # Complex: 17-25 points
        extra = branch_count - thresholds.moderate_max
        score = 17 + min(int(extra / 10), 8)
        return score, ComplexityLevel.COMPLEX


def calculate_pr_score(pr_count: int | None) -> tuple[int, ComplexityLevel]:
    """Calculate complexity score contribution from pull request count.

    Args:
        pr_count: Number of pull requests, or None if unknown.

    Returns:
        Tuple of (score contribution, complexity level for this factor).
    """
    if pr_count is None:
        return 0, ComplexityLevel.SIMPLE

    thresholds = PRThresholds()

    if pr_count <= thresholds.simple_max:
        # Simple: 0-8 points
        score = int((pr_count / thresholds.simple_max) * 8)
        return score, ComplexityLevel.SIMPLE
    elif pr_count <= thresholds.moderate_max:
        # Moderate: 8-17 points
        ratio = (pr_count - thresholds.simple_max) / (
            thresholds.moderate_max - thresholds.simple_max
        )
        score = 8 + int(ratio * 9)
        return score, ComplexityLevel.MODERATE
    else:
        # Complex: 17-25 points
        extra = pr_count - thresholds.moderate_max
        score = 17 + min(int(extra / 50), 8)
        return score, ComplexityLevel.COMPLEX


def calculate_lfs_score(has_lfs: bool) -> tuple[int, ComplexityLevel]:
    """Calculate complexity score contribution from LFS usage.

    Args:
        has_lfs: Whether repository uses LFS.

    Returns:
        Tuple of (score contribution, complexity level for this factor).
    """
    if has_lfs:
        # LFS adds complexity: 20 points and COMPLEX level
        return 20, ComplexityLevel.COMPLEX
    return 0, ComplexityLevel.SIMPLE


def calculate_complexity(
    *,
    size_bytes: int | None = None,
    branch_count: int | None = None,
    pr_count: int | None = None,
    has_lfs: bool = False,
    has_large_files: bool = False,
) -> ComplexityScore:
    """Calculate overall complexity score for a repository.

    The scoring algorithm considers:
    - Repository size (0-30 points)
    - Number of branches (0-25 points)
    - Number of pull requests (0-25 points)
    - LFS usage (0-20 points)

    Overall level is determined by:
    - SIMPLE: score < 25
    - MODERATE: 25 <= score < 50
    - COMPLEX: score >= 50

    Args:
        size_bytes: Repository size in bytes.
        branch_count: Number of branches.
        pr_count: Number of pull requests.
        has_lfs: Whether repository uses LFS.
        has_large_files: Whether repository has large files (>100MB).

    Returns:
        ComplexityScore with level, score, factors, and notes.
    """
    factors: dict[str, int] = {}
    notes: list[str] = []
    factor_levels: list[ComplexityLevel] = []

    # Calculate each factor
    size_score, size_level = calculate_size_score(size_bytes)
    factors["size"] = size_score
    factor_levels.append(size_level)

    branch_score, branch_level = calculate_branch_score(branch_count)
    factors["branches"] = branch_score
    factor_levels.append(branch_level)

    pr_score, pr_level = calculate_pr_score(pr_count)
    factors["prs"] = pr_score
    factor_levels.append(pr_level)

    lfs_score, lfs_level = calculate_lfs_score(has_lfs)
    factors["lfs"] = lfs_score
    factor_levels.append(lfs_level)

    # Calculate total score
    total_score = sum(factors.values())

    # Determine overall level based on score
    if total_score < 25:
        overall_level = ComplexityLevel.SIMPLE
    elif total_score < 50:
        overall_level = ComplexityLevel.MODERATE
    else:
        overall_level = ComplexityLevel.COMPLEX

    # Bump to MODERATE if any factor is complex but overall score is SIMPLE
    if ComplexityLevel.COMPLEX in factor_levels and overall_level == ComplexityLevel.SIMPLE:
        overall_level = ComplexityLevel.MODERATE

    # Generate notes
    if size_bytes is not None:
        size_mb = size_bytes / (1024 * 1024)
        if size_mb > 1024:
            notes.append(f"Large repository: {size_mb / 1024:.1f} GB")
        elif size_mb > 100:
            notes.append(f"Medium repository: {size_mb:.0f} MB")

    if branch_count is not None and branch_count > 50:
        notes.append(f"Many branches: {branch_count}")

    if pr_count is not None and pr_count > 200:
        notes.append(f"Many pull requests: {pr_count}")

    if has_lfs:
        notes.append("Uses Git LFS")

    if has_large_files and not has_lfs:
        notes.append("Has large files - run bb2gh cleanup analyze before migration")

    return ComplexityScore(
        level=overall_level,
        score=total_score,
        factors=factors,
        notes=notes,
    )


async def analyze_repository(
    adapter: BitbucketSourceAdapter,
    repo: Repository,
    *,
    workspace: str,
    analyze_large_files: bool = True,
    analyze_lfs: bool = True,
) -> RepositoryInventoryItem:
    """Analyze a repository and create an inventory item with complexity scoring.

    Args:
        adapter: Bitbucket adapter for API calls.
        repo: Repository to analyze.
        workspace: Workspace name.
        analyze_large_files: Whether to analyze for large files.
        analyze_lfs: Whether to check for LFS configuration.

    Returns:
        RepositoryInventoryItem with complexity score and analysis results.
    """
    logger.debug(
        "analyzing_repository",
        repo=repo.full_name,
    )

    # Gather metrics
    branch_count: int | None = None
    pr_count: int | None = None
    large_files: list[LargeFileInfo] = []
    lfs_info = LFSInfo()
    warnings: list[str] = []

    try:
        # Count branches
        branch_count = await adapter.count_branches(repo.full_name)
    except Exception as e:
        logger.warning("branch_count_failed", repo=repo.full_name, error=str(e))
        warnings.append(f"Could not count branches: {e}")

    try:
        # Count PRs (all states)
        pr_count = await adapter.count_pull_requests(repo.full_name)
    except Exception as e:
        logger.warning("pr_count_failed", repo=repo.full_name, error=str(e))
        warnings.append(f"Could not count pull requests: {e}")

    # Analyze large files if requested
    if analyze_large_files:
        try:
            large_files_result = await adapter.analyze_large_files(
                repo.full_name,
                branch=repo.default_branch,
            )
            large_files = [
                LargeFileInfo(path=f.path, size_bytes=f.size_bytes)
                for f in large_files_result.large_files
            ]
            if large_files:
                warnings.append(f"Found {len(large_files)} files over 100MB threshold")
        except Exception as e:
            logger.warning("large_files_analysis_failed", repo=repo.full_name, error=str(e))

    # Check LFS if requested
    if analyze_lfs:
        try:
            lfs_result = await adapter.detect_lfs_patterns(
                repo.full_name,
                branch=repo.default_branch,
            )
            lfs_info = LFSInfo(
                has_lfs=lfs_result.has_lfs,
                patterns=lfs_result.patterns,
            )
        except Exception as e:
            logger.warning("lfs_detection_failed", repo=repo.full_name, error=str(e))

    # Analyze pipelines (always runs, not gated by flags)
    pipeline_analysis: PipelineAnalysis | None = None
    try:
        pipeline_yaml = await adapter.get_pipeline_config(
            repo.full_name,
            branch=repo.default_branch,
        )
        if pipeline_yaml is not None:
            pipeline_analysis = parse_pipeline_config(pipeline_yaml)
        else:
            pipeline_analysis = PipelineAnalysis(has_pipelines=False)
    except Exception as e:
        logger.warning("pipeline_analysis_failed", repo=repo.full_name, error=str(e))
        pipeline_analysis = None

    # Calculate complexity
    complexity = calculate_complexity(
        size_bytes=repo.size_bytes,
        branch_count=branch_count,
        pr_count=pr_count,
        has_lfs=lfs_info.has_lfs,
        has_large_files=len(large_files) > 0,
    )

    logger.debug(
        "repository_analyzed",
        repo=repo.full_name,
        complexity_level=complexity.level.value,
        complexity_score=complexity.score,
    )

    return RepositoryInventoryItem(
        id=repo.id,
        name=repo.name,
        full_name=repo.full_name,
        description=repo.description,
        source=repo.source,
        workspace=workspace,
        project=repo.project,
        private=repo.private,
        archived=repo.archived,
        fork=repo.fork,
        default_branch=repo.default_branch,
        size_bytes=repo.size_bytes,
        branch_count=branch_count,
        pr_count=pr_count,
        clone_url_https=repo.clone_url_https,
        clone_url_ssh=repo.clone_url_ssh,
        created_at=repo.created_at,
        updated_at=repo.updated_at,
        complexity=complexity,
        large_files=large_files,
        lfs=lfs_info,
        pipelines=pipeline_analysis,
        warnings=warnings,
    )
