"""GEI Archive Generator for bb2gh.

Creates migration archives compatible with GitHub Enterprise Importer (GEI).
This allows using the Enterprise Importer API for PR migrations with full
historical state preservation.
"""

from __future__ import annotations

import json
import tarfile
import tempfile
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog

if TYPE_CHECKING:
    from bb2gh.models.pull_request import PullRequest

logger = structlog.get_logger(__name__)

# GEI Archive Schema Version
SCHEMA_VERSION = "1.2.0"


class GEIArchiveGenerator:
    """Generates migration archives compatible with GitHub Enterprise Importer.

    The archive format follows the GEI specification with:
    - schema.json - Schema version and metadata
    - repositories_000001.json - Repository metadata
    - pull_requests_000001.json - Pull request data
    - users_000001.json - User mappings
    """

    def __init__(
        self,
        source_workspace: str,
        source_repo: str,
        target_org: str,
        target_repo: str,
        *,
        work_dir: Path | None = None,
    ) -> None:
        """Initialize the archive generator.

        Args:
            source_workspace: Bitbucket workspace name.
            source_repo: Source repository name.
            target_org: Target GitHub organization.
            target_repo: Target repository name.
            work_dir: Working directory for archive creation.
        """
        self.source_workspace = source_workspace
        self.source_repo = source_repo
        self.target_org = target_org
        self.target_repo = target_repo
        self._work_dir = work_dir or Path(tempfile.mkdtemp(prefix="gei_archive_"))
        self._users: dict[str, dict[str, Any]] = {}
        self._pull_requests: list[dict[str, Any]] = []
        self._issues: list[dict[str, Any]] = []
        self._comments: list[dict[str, Any]] = []

    def add_user(
        self,
        username: str,
        display_name: str | None = None,
        email: str | None = None,
        source_id: str | None = None,
        source_type: str = "bitbucket",
    ) -> int:
        """Add a user to the archive.

        Args:
            username: Source username.
            display_name: User display name.
            email: User email.
            source_id: Source system user ID (e.g., Bitbucket account_id) for mannequin mapping.
            source_type: Source system type (default: "bitbucket").

        Returns:
            User ID for reference.
        """
        if username in self._users:
            # If user exists but doesn't have source_id and we're providing one, update it
            existing_user = self._users[username]
            if source_id and not existing_user.get("source_id"):
                existing_user["source_id"] = source_id
                existing_user["source_type"] = source_type
            return int(existing_user["id"])

        user_id = len(self._users) + 1
        self._users[username] = {
            "id": user_id,
            "login": username,
            "name": display_name or username,
            "email": email,
            "type": "user",
            "source_id": source_id,
            "source_type": source_type if source_id else None,
        }
        return user_id

    def add_pull_request(
        self,
        pr: PullRequest,
        *,
        comments: list[dict[str, Any]] | None = None,
    ) -> None:
        """Add a pull request to the archive.

        Args:
            pr: PullRequest object from source.
            comments: Optional list of comment dicts.
        """
        # Ensure author is in users
        author_id = self.add_user(
            pr.author.username,
            pr.author.display_name,
            pr.author.email,
            source_id=pr.author.account_id,
            source_type="bitbucket",
        )

        # Map state to GEI format
        state_map = {
            "open": "open",
            "merged": "merged",
            "declined": "closed",
            "superseded": "closed",
            "closed": "closed",
        }

        pr_numeric_id = int(pr.id) if pr.id.isdigit() else hash(pr.id) % 1000000
        pr_data = {
            "type": "pull_request",
            "id": pr_numeric_id,
            "number": pr_numeric_id,
            "state": state_map.get(pr.state.value, "closed"),
            "title": pr.title,
            "body": pr.description or "",
            "user": author_id,
            "head": {
                "ref": pr.source_branch.name,
                "sha": pr.source_branch.commit_hash or "",
                "repo": f"{self.source_workspace}/{self.source_repo}",
            },
            "base": {
                "ref": pr.target_branch.name,
                "sha": pr.target_branch.commit_hash or "",
                "repo": f"{self.source_workspace}/{self.source_repo}",
            },
            "created_at": pr.created_at.isoformat() if pr.created_at else None,
            "updated_at": pr.updated_at.isoformat() if pr.updated_at else None,
            "closed_at": pr.closed_at.isoformat() if pr.closed_at else None,
            "merged_at": pr.merged_at.isoformat() if pr.merged_at else None,
            "merge_commit_sha": pr.merge_commit_hash,
            "merged": pr.is_merged,
            "mergeable": None,
            "labels": [{"name": label} for label in pr.labels],
            "milestone": None,
            "assignees": [],
            "requested_reviewers": [{"login": r.username} for r in pr.reviewers],
        }

        # Add reviewers as users
        for reviewer in pr.reviewers:
            self.add_user(reviewer.username, reviewer.display_name)

        self._pull_requests.append(pr_data)

        # Add comments
        if comments:
            for comment in comments:
                self._add_pr_comment(pr_numeric_id, comment)

    def _add_pr_comment(self, pr_id: int, comment: dict[str, Any]) -> None:
        """Add a comment to a pull request.

        Args:
            pr_id: Pull request ID.
            comment: Comment dict with 'author', 'content', 'created_at'.
        """
        author = comment.get("author", {})
        author_id = self.add_user(
            author.get("username", "unknown"),
            author.get("display_name"),
        )

        self._comments.append(
            {
                "type": "issue_comment",
                "id": len(self._comments) + 1,
                "pull_request": pr_id,
                "user": author_id,
                "body": comment.get("content", ""),
                "created_at": comment.get("created_at"),
                "updated_at": comment.get("updated_at"),
            }
        )

    def generate_archive(self) -> Path:
        """Generate the migration archive.

        Returns:
            Path to the generated .tar.gz archive.
        """
        archive_dir = self._work_dir / "archive"
        archive_dir.mkdir(parents=True, exist_ok=True)

        # Generate schema.json
        self._write_schema(archive_dir)

        # Generate users file
        self._write_users(archive_dir)

        # Generate repository metadata
        self._write_repository(archive_dir)

        # Generate pull requests
        self._write_pull_requests(archive_dir)

        # Generate comments
        self._write_comments(archive_dir)

        # Create tar.gz archive
        timestamp = datetime.now(UTC).strftime("%Y%m%d-%H%M%S")
        archive_name = f"migration-{self.source_repo}-{timestamp}.tar.gz"
        archive_path = self._work_dir / archive_name

        with tarfile.open(archive_path, "w:gz") as tar:
            for file_path in archive_dir.iterdir():
                tar.add(file_path, arcname=file_path.name)

        logger.info(
            "gei_archive_created",
            archive_path=str(archive_path),
            pull_requests=len(self._pull_requests),
            users=len(self._users),
        )

        return archive_path

    def _write_schema(self, archive_dir: Path) -> None:
        """Write schema.json file."""
        schema = {
            "version": SCHEMA_VERSION,
            "source": "bb2gh",
            "generated_at": datetime.now(UTC).isoformat() + "Z",
        }
        self._write_json(archive_dir / "schema.json", schema)

    def _write_users(self, archive_dir: Path) -> None:
        """Write users file."""
        users_list = list(self._users.values())
        self._write_json(archive_dir / "users_000001.json", users_list)

    def _write_repository(self, archive_dir: Path) -> None:
        """Write repository metadata."""
        repo_data = [
            {
                "type": "repository",
                "name": self.target_repo,
                "full_name": f"{self.target_org}/{self.target_repo}",
                "private": True,
                "description": f"Migrated from {self.source_workspace}/{self.source_repo}",
                "default_branch": "main",
            }
        ]
        self._write_json(archive_dir / "repositories_000001.json", repo_data)

    def _write_pull_requests(self, archive_dir: Path) -> None:
        """Write pull requests file."""
        if self._pull_requests:
            self._write_json(archive_dir / "pull_requests_000001.json", self._pull_requests)

    def _write_comments(self, archive_dir: Path) -> None:
        """Write comments file."""
        if self._comments:
            self._write_json(archive_dir / "issue_comments_000001.json", self._comments)

    def _write_json(self, path: Path, data: Any) -> None:
        """Write JSON data to a file."""
        with path.open("w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, default=str)

    def cleanup(self) -> None:
        """Clean up temporary files."""
        import shutil

        if self._work_dir.exists():
            shutil.rmtree(self._work_dir, ignore_errors=True)
