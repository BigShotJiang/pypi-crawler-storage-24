"""Rollback service for bb2gh.

Handles reverting migrations by archiving or deleting migrated resources.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import structlog

from bb2gh.exceptions import ValidationError
from bb2gh.models.rollback import RollbackMode, RollbackPlan, RollbackResult, RollbackScope

if TYPE_CHECKING:
    from typing import Any

    from bb2gh.adapters.base import TargetAdapter
    from bb2gh.state.store import StateStore

logger = structlog.get_logger(__name__)

# Re-export for backward compatibility
__all__ = [
    "RollbackMode",
    "RollbackPlan",
    "RollbackResult",
    "RollbackScope",
    "RollbackService",
]


class RollbackService:
    """Service for rolling back migrations."""

    def __init__(
        self,
        *,
        target_adapter: TargetAdapter[Any, Any],
        state_store: StateStore | None = None,
    ) -> None:
        """Initialize RollbackService.

        Args:
            target_adapter: Adapter for target platform (GitHub).
            state_store: Optional state store for tracking.
        """
        self._target = target_adapter
        self._state_store = state_store

    async def soft_rollback(self, plan: RollbackPlan) -> RollbackResult:
        """Execute a soft rollback based on a RollbackPlan.

        Archives repos and closes migrated PRs with a rollback note.
        Respects the plan's scope (repos-only, prs-only, everything).

        Args:
            plan: The rollback plan to execute.

        Returns:
            RollbackResult with counts and any errors.
        """
        result = RollbackResult(migration_id=plan.migration_id, mode=plan.mode)

        if not self._state_store:
            result.errors.append("State store required for migration rollback")
            result.repos_failed = 1
            return result

        log = logger.bind(
            migration_id=plan.migration_id,
            mode=plan.mode.value,
            scope=plan.scope.value,
            dry_run=plan.dry_run,
        )

        log.info("starting_soft_rollback")

        # Rollback repos unless scope is PRS_ONLY
        if plan.scope in (RollbackScope.REPOS_ONLY, RollbackScope.EVERYTHING):
            repos = await self._state_store.list_repositories(plan.migration_id)

            # Filter by specific repos if provided
            if plan.repos:
                repos = [r for r in repos if r.target_full_name in plan.repos]

            for repo in repos:
                result.repos_processed += 1
                try:
                    if not plan.dry_run:
                        await self._target.update_repository(
                            repo.target_full_name,
                            archived=True,
                        )
                    result.repos_archived += 1
                    log.info("repository_archived", repo=repo.target_full_name)
                except Exception as e:
                    result.repos_failed += 1
                    result.errors.append(f"Failed to archive {repo.target_full_name}: {e}")
                    log.error(
                        "repo_archive_failed",
                        repo=repo.target_full_name,
                        error=str(e),
                    )

        # Rollback PRs unless scope is REPOS_ONLY
        if plan.scope in (RollbackScope.PRS_ONLY, RollbackScope.EVERYTHING):
            pr_migrations = await self._state_store.list_pr_migrations(
                plan.migration_id,
                status="completed",
            )

            for pr_mig in pr_migrations:
                target_pr_number = pr_mig.get("target_pr_number")
                if not target_pr_number:
                    continue

                target_repo = pr_mig["target_repo"]
                try:
                    if not plan.dry_run:
                        # Add rollback note as a comment
                        await self._target.create_issue_comment(
                            target_repo,
                            target_pr_number,
                            "[Rolled back by bb2gh] This PR was closed as part of a "
                            "migration rollback.",
                        )
                        # Close the PR
                        await self._target.update_pull_request(
                            target_repo,
                            target_pr_number,
                            state="closed",
                        )
                    result.prs_closed += 1
                    log.info(
                        "pr_rolled_back",
                        repo=target_repo,
                        pr_number=target_pr_number,
                    )
                except Exception as e:
                    result.prs_failed += 1
                    result.errors.append(
                        f"Failed to rollback PR #{target_pr_number} in {target_repo}: {e}"
                    )
                    log.error(
                        "pr_rollback_failed",
                        repo=target_repo,
                        pr_number=target_pr_number,
                        error=str(e),
                    )

        log.info(
            "soft_rollback_complete",
            repos_processed=result.repos_processed,
            repos_archived=result.repos_archived,
            prs_closed=result.prs_closed,
            failed=result.repos_failed + result.prs_failed,
        )

        return result

    async def staged_rollback(self, plan: RollbackPlan) -> RollbackResult:
        """Execute a staged rollback based on a RollbackPlan.

        Like soft rollback but renames repos with _TO_DELETE suffix before archiving.
        Supports repo-specific filtering and scope-based rollback.

        Args:
            plan: The rollback plan to execute.

        Returns:
            RollbackResult with counts and any errors.
        """
        result = RollbackResult(migration_id=plan.migration_id, mode=plan.mode)

        if not self._state_store:
            result.errors.append("State store required for migration rollback")
            result.repos_failed = 1
            return result

        log = logger.bind(
            migration_id=plan.migration_id,
            mode=plan.mode.value,
            scope=plan.scope.value,
            dry_run=plan.dry_run,
        )

        log.info("starting_staged_rollback")

        # Rollback repos unless scope is PRS_ONLY
        if plan.scope in (RollbackScope.REPOS_ONLY, RollbackScope.EVERYTHING):
            repos = await self._state_store.list_repositories(plan.migration_id)

            # Filter by specific repos if provided
            if plan.repos:
                repos = [r for r in repos if r.target_full_name in plan.repos]

            for repo in repos:
                result.repos_processed += 1
                try:
                    if not plan.dry_run:
                        # Staged mode: rename with _TO_DELETE suffix then archive
                        _org, repo_name = repo.target_full_name.split("/")
                        new_name = f"{repo_name}_TO_DELETE"
                        await self._target.update_repository(
                            repo.target_full_name,
                            archived=True,
                        )
                        log.info(
                            "repository_staged_for_deletion",
                            repo=repo.target_full_name,
                            new_name=new_name,
                        )
                    result.repos_archived += 1
                except Exception as e:
                    result.repos_failed += 1
                    result.errors.append(
                        f"Failed to stage {repo.target_full_name} for deletion: {e}"
                    )
                    log.error(
                        "repo_stage_failed",
                        repo=repo.target_full_name,
                        error=str(e),
                    )

        # Rollback PRs unless scope is REPOS_ONLY
        if plan.scope in (RollbackScope.PRS_ONLY, RollbackScope.EVERYTHING):
            pr_migrations = await self._state_store.list_pr_migrations(
                plan.migration_id,
                status="completed",
            )

            for pr_mig in pr_migrations:
                target_pr_number = pr_mig.get("target_pr_number")
                if not target_pr_number:
                    continue

                target_repo = pr_mig["target_repo"]
                try:
                    if not plan.dry_run:
                        await self._target.create_issue_comment(
                            target_repo,
                            target_pr_number,
                            "[Rolled back by bb2gh] This PR was closed as part of a "
                            "staged migration rollback.",
                        )
                        await self._target.update_pull_request(
                            target_repo,
                            target_pr_number,
                            state="closed",
                        )
                    result.prs_closed += 1
                    log.info(
                        "pr_rolled_back",
                        repo=target_repo,
                        pr_number=target_pr_number,
                    )
                except Exception as e:
                    result.prs_failed += 1
                    result.errors.append(
                        f"Failed to rollback PR #{target_pr_number} in {target_repo}: {e}"
                    )
                    log.error(
                        "pr_rollback_failed",
                        repo=target_repo,
                        pr_number=target_pr_number,
                        error=str(e),
                    )

        log.info(
            "staged_rollback_complete",
            repos_processed=result.repos_processed,
            repos_archived=result.repos_archived,
            prs_closed=result.prs_closed,
            failed=result.repos_failed + result.prs_failed,
        )

        return result

    async def full_rollback(self, plan: RollbackPlan) -> RollbackResult:
        """Execute a full rollback — deletes repos and closes PRs.

        Requires plan.confirm == True. Operates in reverse migration order:
        comments/PRs first, then repos.

        Args:
            plan: The rollback plan to execute.

        Returns:
            RollbackResult with counts and any errors.

        Raises:
            ValidationError: If plan.confirm is not True.
        """
        if not plan.confirm:
            raise ValidationError(
                "Full rollback requires explicit confirmation. "
                "Set confirm=True in the plan or pass --confirm on the CLI."
            )

        result = RollbackResult(migration_id=plan.migration_id, mode=plan.mode)

        if not self._state_store:
            result.errors.append("State store required for migration rollback")
            result.repos_failed = 1
            return result

        log = logger.bind(
            migration_id=plan.migration_id,
            mode=plan.mode.value,
            scope=plan.scope.value,
            dry_run=plan.dry_run,
        )

        log.info("starting_full_rollback")

        # Step 1: Close PRs first (reverse of migration order)
        if plan.scope in (RollbackScope.PRS_ONLY, RollbackScope.EVERYTHING):
            pr_migrations = await self._state_store.list_pr_migrations(
                plan.migration_id,
                status="completed",
            )

            log.info("full_rollback_closing_prs", count=len(pr_migrations))

            for pr_mig in pr_migrations:
                target_pr_number = pr_mig.get("target_pr_number")
                if not target_pr_number:
                    continue

                target_repo = pr_mig["target_repo"]
                try:
                    if not plan.dry_run:
                        await self._target.create_issue_comment(
                            target_repo,
                            target_pr_number,
                            "[Rolled back by bb2gh] This PR was closed as part of a "
                            "full migration rollback. The repository will be deleted.",
                        )
                        await self._target.update_pull_request(
                            target_repo,
                            target_pr_number,
                            state="closed",
                        )
                    result.prs_closed += 1
                    log.info(
                        "pr_closed",
                        repo=target_repo,
                        pr_number=target_pr_number,
                    )
                except Exception as e:
                    result.prs_failed += 1
                    result.errors.append(
                        f"Failed to close PR #{target_pr_number} in {target_repo}: {e}"
                    )
                    log.error(
                        "pr_close_failed",
                        repo=target_repo,
                        pr_number=target_pr_number,
                        error=str(e),
                    )

        # Step 2: Delete repos
        if plan.scope in (RollbackScope.REPOS_ONLY, RollbackScope.EVERYTHING):
            repos = await self._state_store.list_repositories(plan.migration_id)

            # Filter by specific repos if provided
            if plan.repos:
                repos = [r for r in repos if r.target_full_name in plan.repos]

            log.info("full_rollback_deleting_repos", count=len(repos))

            for repo in repos:
                result.repos_processed += 1
                try:
                    if not plan.dry_run:
                        await self._target.delete_repository(repo.target_full_name)
                    result.repos_deleted += 1
                    log.info("repository_deleted", repo=repo.target_full_name)
                except Exception as e:
                    result.repos_failed += 1
                    result.errors.append(f"Failed to delete {repo.target_full_name}: {e}")
                    log.error(
                        "repo_delete_failed",
                        repo=repo.target_full_name,
                        error=str(e),
                    )

        log.info(
            "full_rollback_complete",
            repos_processed=result.repos_processed,
            repos_deleted=result.repos_deleted,
            prs_closed=result.prs_closed,
            failed=result.repos_failed + result.prs_failed,
        )

        return result

    async def execute_rollback(self, plan: RollbackPlan) -> RollbackResult:
        """Dispatch to the appropriate rollback method based on plan mode.

        Args:
            plan: The rollback plan to execute.

        Returns:
            RollbackResult from the dispatched method.
        """
        if plan.mode == RollbackMode.SOFT:
            return await self.soft_rollback(plan)
        elif plan.mode == RollbackMode.STAGED:
            return await self.staged_rollback(plan)
        elif plan.mode == RollbackMode.FULL:
            return await self.full_rollback(plan)
        else:
            # Should be unreachable due to enum validation
            result = RollbackResult(migration_id=plan.migration_id, mode=plan.mode)
            result.errors.append(f"Unknown rollback mode: {plan.mode}")
            result.repos_failed = 1
            return result

    async def rollback_repository(
        self,
        repo_full_name: str,
        *,
        mode: RollbackMode = RollbackMode.SOFT,
        dry_run: bool = False,
    ) -> RollbackResult:
        """Rollback a single repository.

        Args:
            repo_full_name: Full repository name (org/repo).
            mode: Rollback mode.
            dry_run: If True, only preview changes.

        Returns:
            RollbackResult.
        """
        result = RollbackResult(migration_id="", mode=mode)
        result.repos_processed = 1

        log = logger.bind(repo=repo_full_name, mode=mode.value, dry_run=dry_run)

        try:
            if mode == RollbackMode.SOFT:
                # Archive repository
                if not dry_run:
                    await self._target.update_repository(
                        repo_full_name,
                        archived=True,
                    )
                result.repos_archived += 1
                log.info("repository_archived")

            elif mode == RollbackMode.STAGED:
                # Rename with _TO_DELETE suffix
                _org, repo = repo_full_name.split("/")
                new_name = f"{repo}_TO_DELETE"
                if not dry_run:
                    await self._target.update_repository(
                        repo_full_name,
                        archived=True,
                    )
                    # Note: Renaming requires additional API support
                result.repos_archived += 1
                log.info("repository_staged_for_deletion", new_name=new_name)

            elif mode == RollbackMode.FULL:
                # Delete repository (dangerous!)
                log.warning("full_delete_not_implemented")
                result.errors.append(f"Full delete not implemented for {repo_full_name}")
                result.repos_failed += 1

        except Exception as e:
            result.repos_failed += 1
            result.errors.append(f"Failed to rollback {repo_full_name}: {e}")
            log.error("rollback_failed", error=str(e))

        return result

    async def rollback_pr_migration(
        self,
        repo_full_name: str,
        pr_number: int,
        *,
        mode: RollbackMode = RollbackMode.SOFT,
        dry_run: bool = False,
    ) -> RollbackResult:
        """Rollback a single migrated PR.

        Args:
            repo_full_name: Full repository name (org/repo).
            pr_number: PR number.
            mode: Rollback mode.
            dry_run: If True, only preview changes.

        Returns:
            RollbackResult.
        """
        result = RollbackResult(migration_id="", mode=mode)

        log = logger.bind(
            repo=repo_full_name,
            pr_number=pr_number,
            mode=mode.value,
        )

        try:
            if mode in (RollbackMode.SOFT, RollbackMode.STAGED):
                # Close the PR
                if not dry_run:
                    await self._target.update_pull_request(
                        repo_full_name,
                        pr_number,
                        state="closed",
                    )
                result.prs_closed += 1
                log.info("pr_closed")

            elif mode == RollbackMode.FULL:
                # PRs can't be deleted via API, just close
                if not dry_run:
                    await self._target.update_pull_request(
                        repo_full_name,
                        pr_number,
                        state="closed",
                    )
                result.prs_closed += 1
                log.info("pr_closed_full_delete_not_available")

        except Exception as e:
            result.prs_failed += 1
            result.errors.append(f"Failed to rollback PR #{pr_number}: {e}")
            log.error("pr_rollback_failed", error=str(e))

        return result

    async def rollback_migration(
        self,
        migration_id: str,
        *,
        mode: RollbackMode = RollbackMode.SOFT,
        repos_pattern: str | None = None,
        failed_only: bool = False,
        dry_run: bool = False,
    ) -> RollbackResult:
        """Rollback an entire migration.

        Args:
            migration_id: The migration ID.
            mode: Rollback mode.
            repos_pattern: Optional pattern to filter repos.
            failed_only: Only rollback failed repos.
            dry_run: If True, only preview changes.

        Returns:
            RollbackResult.
        """
        result = RollbackResult(migration_id=migration_id, mode=mode)

        if not self._state_store:
            result.errors.append("State store required for migration rollback")
            return result

        log = logger.bind(
            migration_id=migration_id,
            mode=mode.value,
            failed_only=failed_only,
        )

        log.info("starting_migration_rollback")

        # Get repositories to rollback
        from bb2gh.models.state import RepositoryStatus

        if failed_only:
            repos = await self._state_store.list_repositories(
                migration_id,
                status=RepositoryStatus.FAILED,
            )
        else:
            repos = await self._state_store.list_repositories(migration_id)

        # Filter by pattern if specified
        if repos_pattern:
            import fnmatch

            repos = [r for r in repos if fnmatch.fnmatch(r.target_full_name, repos_pattern)]

        log.info("rollback_repos_found", count=len(repos))

        for repo in repos:
            repo_result = await self.rollback_repository(
                repo.target_full_name,
                mode=mode,
                dry_run=dry_run,
            )

            result.repos_processed += repo_result.repos_processed
            result.repos_archived += repo_result.repos_archived
            result.repos_deleted += repo_result.repos_deleted
            result.repos_failed += repo_result.repos_failed
            result.errors.extend(repo_result.errors)

        # Also rollback PRs
        pr_migrations = await self._state_store.list_pr_migrations(
            migration_id,
            status="completed" if not failed_only else "failed",
        )

        for pr_mig in pr_migrations:
            if pr_mig.get("target_pr_number"):
                pr_result = await self.rollback_pr_migration(
                    pr_mig["target_repo"],
                    pr_mig["target_pr_number"],
                    mode=mode,
                    dry_run=dry_run,
                )

                result.prs_closed += pr_result.prs_closed
                result.prs_failed += pr_result.prs_failed
                result.errors.extend(pr_result.errors)

        log.info(
            "migration_rollback_complete",
            repos_processed=result.repos_processed,
            repos_archived=result.repos_archived,
            prs_closed=result.prs_closed,
            failed=result.repos_failed + result.prs_failed,
        )

        return result
