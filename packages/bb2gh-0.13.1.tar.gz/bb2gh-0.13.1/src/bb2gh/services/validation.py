"""Validation service for bb2gh.

Verifies migration completeness by comparing source and target repositories.
"""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Any

import httpx
import structlog

if TYPE_CHECKING:
    from bb2gh.models.plan import MigrationPlan

logger = structlog.get_logger(__name__)


class ValidationStatus(StrEnum):
    """Status of a validation check."""

    PASSED = "passed"
    FAILED = "failed"
    SKIPPED = "skipped"
    WARNING = "warning"


@dataclass
class BranchValidation:
    """Validation result for a single branch."""

    name: str
    source_commits: int
    target_commits: int
    status: ValidationStatus
    message: str | None = None


@dataclass
class RepositoryValidation:
    """Validation result for a single repository."""

    source_full_name: str
    target_full_name: str
    status: ValidationStatus

    # Branch/tag counts
    source_branches: int = 0
    target_branches: int = 0
    source_tags: int = 0
    target_tags: int = 0

    # Commit counts
    source_commits: int = 0
    target_commits: int = 0

    # LFS validation
    source_has_lfs: bool = False
    target_has_lfs: bool = False
    source_lfs_files: int = 0
    target_lfs_files: int = 0
    lfs_issues: list[str] = field(default_factory=list)

    # Detailed branch validation
    branch_validations: list[BranchValidation] = field(default_factory=list)

    # Issues found
    missing_branches: list[str] = field(default_factory=list)
    missing_tags: list[str] = field(default_factory=list)
    message: str | None = None


@dataclass
class PRValidation:
    """Validation result for a PR migration."""

    source_pr_id: str
    source_repo: str
    target_pr_number: int | None
    target_repo: str
    status: ValidationStatus
    source_state: str | None = None
    target_state: str | None = None
    comments_expected: int = 0
    comments_migrated: int = 0
    message: str | None = None


@dataclass
class CommentValidationReport:
    """Validation report for comment migration completeness."""

    total_prs: int = 0
    prs_with_all_comments: int = 0
    prs_with_missing_comments: int = 0
    total_comments_expected: int = 0
    total_comments_migrated: int = 0
    total_comments_failed: int = 0

    @property
    def success_rate(self) -> float:
        """Percentage of comments successfully migrated."""
        if self.total_comments_expected == 0:
            return 0.0
        return (self.total_comments_migrated / self.total_comments_expected) * 100

    @property
    def status(self) -> ValidationStatus:
        """Overall comment validation status."""
        if self.total_prs == 0:
            return ValidationStatus.SKIPPED
        if self.total_comments_failed > 0:
            return ValidationStatus.WARNING
        return ValidationStatus.PASSED

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON export."""
        return {
            "total_prs": self.total_prs,
            "prs_with_all_comments": self.prs_with_all_comments,
            "prs_with_missing_comments": self.prs_with_missing_comments,
            "comments": {
                "expected": self.total_comments_expected,
                "migrated": self.total_comments_migrated,
                "failed": self.total_comments_failed,
            },
            "success_rate": self.success_rate,
            "status": self.status.value,
        }


@dataclass
class AttributionValidationReport:
    """Validation report for user attribution accuracy."""

    total_prs: int = 0
    prs_with_mapped_author: int = 0
    prs_with_ghost_author: int = 0
    ghost_usernames: list[str] = field(default_factory=list)

    @property
    def mapping_rate(self) -> float:
        """Percentage of PRs with correctly mapped authors."""
        if self.total_prs == 0:
            return 0.0
        return (self.prs_with_mapped_author / self.total_prs) * 100

    @property
    def status(self) -> ValidationStatus:
        """Overall attribution validation status."""
        if self.total_prs == 0:
            return ValidationStatus.SKIPPED
        if self.prs_with_ghost_author > 0:
            return ValidationStatus.WARNING
        return ValidationStatus.PASSED

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON export."""
        return {
            "total_prs": self.total_prs,
            "prs_with_mapped_author": self.prs_with_mapped_author,
            "prs_with_ghost_author": self.prs_with_ghost_author,
            "mapping_rate": self.mapping_rate,
            "ghost_usernames": self.ghost_usernames,
            "status": self.status.value,
        }


@dataclass
class PRValidationReport:
    """Validation report for PR migrations."""

    migration_id: str | None = None
    source_repo: str | None = None
    target_repo: str | None = None
    total: int = 0
    passed: int = 0
    failed: int = 0
    warnings: int = 0
    pr_validations: list[PRValidation] = field(default_factory=list)
    comment_report: CommentValidationReport | None = None
    attribution_report: AttributionValidationReport | None = None

    @property
    def status(self) -> ValidationStatus:
        """Overall validation status."""
        if self.failed > 0:
            return ValidationStatus.FAILED
        if self.warnings > 0:
            return ValidationStatus.WARNING
        if self.passed == 0:
            return ValidationStatus.SKIPPED
        return ValidationStatus.PASSED

    def to_dict(self) -> dict[str, Any]:
        """Convert report to dictionary for JSON export."""
        result: dict[str, Any] = {
            "migration_id": self.migration_id,
            "source_repo": self.source_repo,
            "target_repo": self.target_repo,
            "status": self.status.value,
            "summary": {
                "total": self.total,
                "passed": self.passed,
                "failed": self.failed,
                "warnings": self.warnings,
            },
            "prs": [
                {
                    "source_pr_id": pr.source_pr_id,
                    "source_repo": pr.source_repo,
                    "target_pr_number": pr.target_pr_number,
                    "target_repo": pr.target_repo,
                    "status": pr.status.value,
                    "source_state": pr.source_state,
                    "target_state": pr.target_state,
                    "comments": {
                        "expected": pr.comments_expected,
                        "migrated": pr.comments_migrated,
                    },
                    "message": pr.message,
                }
                for pr in self.pr_validations
            ],
        }

        if self.comment_report:
            result["comment_validation"] = self.comment_report.to_dict()

        if self.attribution_report:
            result["attribution_validation"] = self.attribution_report.to_dict()

        return result


@dataclass
class ValidationReport:
    """Overall validation report."""

    migration_id: str | None = None
    total: int = 0
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    warnings: int = 0
    repositories: list[RepositoryValidation] = field(default_factory=list)
    pr_report: PRValidationReport | None = None

    @property
    def status(self) -> ValidationStatus:
        """Overall validation status."""
        if self.failed > 0:
            return ValidationStatus.FAILED
        if self.warnings > 0:
            return ValidationStatus.WARNING
        if self.passed == 0:
            return ValidationStatus.SKIPPED
        return ValidationStatus.PASSED

    def to_dict(self) -> dict[str, Any]:
        """Convert report to dictionary for JSON export."""
        result: dict[str, Any] = {
            "migration_id": self.migration_id,
            "status": self.status.value,
            "summary": {
                "total": self.total,
                "passed": self.passed,
                "failed": self.failed,
                "skipped": self.skipped,
                "warnings": self.warnings,
            },
            "repositories": [
                {
                    "source": repo.source_full_name,
                    "target": repo.target_full_name,
                    "status": repo.status.value,
                    "branches": {
                        "source": repo.source_branches,
                        "target": repo.target_branches,
                        "missing": repo.missing_branches,
                    },
                    "tags": {
                        "source": repo.source_tags,
                        "target": repo.target_tags,
                        "missing": repo.missing_tags,
                    },
                    "commits": {
                        "source": repo.source_commits,
                        "target": repo.target_commits,
                    },
                    "lfs": {
                        "source_has_lfs": repo.source_has_lfs,
                        "target_has_lfs": repo.target_has_lfs,
                        "source_files": repo.source_lfs_files,
                        "target_files": repo.target_lfs_files,
                        "issues": repo.lfs_issues,
                    },
                    "message": repo.message,
                }
                for repo in self.repositories
            ],
        }

        if self.pr_report:
            result["pr_validation"] = self.pr_report.to_dict()

        return result


class ValidationService:
    """Service for validating migrations.

    Compares source and target repositories to verify migration completeness.
    """

    def __init__(
        self,
        *,
        work_dir: Path | str | None = None,
        source_auth_token: str | None = None,
        target_auth_token: str | None = None,
        ssl_verify: str | bool = True,
    ) -> None:
        """Initialize ValidationService.

        Args:
            work_dir: Working directory for git operations.
            source_auth_token: Auth token for source HTTPS URLs.
            target_auth_token: Auth token for target HTTPS URLs.
            ssl_verify: SSL verification setting for httpx clients.
        """
        self._work_dir = Path(work_dir) if work_dir else Path.cwd() / ".bb2gh" / "validate"
        self._source_auth = source_auth_token
        self._target_auth = target_auth_token
        self._ssl_verify = ssl_verify

    async def validate_repository(
        self,
        source_clone_url: str,
        target_clone_url: str,
        *,
        source_full_name: str,
        target_full_name: str,
        quick: bool = False,  # noqa: ARG002
        source_has_lfs: bool | None = None,
    ) -> RepositoryValidation:
        """Validate a single repository migration.

        Args:
            source_clone_url: Clone URL for source repository.
            target_clone_url: Clone URL for target repository.
            source_full_name: Full name of source repository.
            target_full_name: Full name of target repository.
            quick: If True, only check counts without fetching (reserved for future use).
            source_has_lfs: If known from plan, whether source uses LFS.

        Returns:
            RepositoryValidation with validation results.
        """
        result = RepositoryValidation(
            source_full_name=source_full_name,
            target_full_name=target_full_name,
            status=ValidationStatus.SKIPPED,
        )

        log = logger.bind(
            source=source_full_name,
            target=target_full_name,
        )

        try:
            # Get source repository info
            source_info = await self._get_repo_info(
                source_clone_url,
                auth_token=self._source_auth,
            )

            # Get target repository info
            target_info = await self._get_repo_info(
                target_clone_url,
                auth_token=self._target_auth,
            )

            # Compare branches
            result.source_branches = len(source_info["branches"])
            result.target_branches = len(target_info["branches"])

            source_branch_set = set(source_info["branches"])
            target_branch_set = set(target_info["branches"])
            result.missing_branches = list(source_branch_set - target_branch_set)

            # Compare tags
            result.source_tags = len(source_info["tags"])
            result.target_tags = len(target_info["tags"])

            source_tag_set = set(source_info["tags"])
            target_tag_set = set(target_info["tags"])
            result.missing_tags = list(source_tag_set - target_tag_set)

            # Compare commit counts
            result.source_commits = source_info["commit_count"]
            result.target_commits = target_info["commit_count"]

            # Check LFS status
            try:
                # Use source LFS info from plan if available (more reliable)
                if source_has_lfs is not None:
                    result.source_has_lfs = source_has_lfs
                    # File count not available from plan, but presence is known
                    result.source_lfs_files = 1 if source_has_lfs else 0
                else:
                    # Fallback to API check
                    source_lfs = await self._check_lfs_files(
                        source_clone_url, auth_token=self._source_auth
                    )
                    result.source_has_lfs = source_lfs["has_lfs"]
                    result.source_lfs_files = source_lfs["file_count"]

                # Always check target LFS via API
                target_lfs = await self._check_lfs_files(
                    target_clone_url, auth_token=self._target_auth
                )
                result.target_has_lfs = target_lfs["has_lfs"]
                result.target_lfs_files = target_lfs["file_count"]

                # Check for LFS issues
                if result.source_has_lfs and not result.target_has_lfs:
                    result.lfs_issues.append("Source has LFS but target does not")
                elif result.source_has_lfs and result.target_has_lfs:
                    # Both have LFS - good
                    pass
            except Exception as lfs_err:
                log.debug("lfs_check_failed", error=str(lfs_err))
                # LFS check failure is non-fatal

            # Determine status
            issues = []

            if result.missing_branches:
                issues.append(f"{len(result.missing_branches)} missing branches")

            if result.missing_tags:
                issues.append(f"{len(result.missing_tags)} missing tags")

            if result.source_commits != result.target_commits:
                issues.append(
                    f"commit count mismatch: {result.source_commits} vs {result.target_commits}"
                )

            # LFS issues are warnings, not failures
            warnings = result.lfs_issues.copy()

            if issues:
                result.status = ValidationStatus.FAILED
                result.message = "; ".join(issues)
                log.warning("validation_failed", issues=issues)
            elif warnings:
                result.status = ValidationStatus.WARNING
                result.message = "; ".join(warnings)
                log.warning("validation_warning", warnings=warnings)
            else:
                result.status = ValidationStatus.PASSED
                log.info("validation_passed")

        except Exception as e:
            result.status = ValidationStatus.FAILED
            result.message = str(e)
            log.error("validation_error", error=str(e))

        return result

    async def _get_repo_info(
        self,
        clone_url: str,
        *,
        auth_token: str | None = None,
    ) -> dict[str, Any]:
        """Get repository information using git ls-remote.

        Args:
            clone_url: Clone URL for the repository.
            auth_token: Optional auth token for HTTPS URLs.

        Returns:
            Dictionary with branches, tags, and commit count.
        """
        # Inject auth token into URL if provided
        if auth_token and clone_url.startswith("https://"):
            # Check if URL already has credentials (contains @ before the host)
            url_without_scheme = clone_url[8:]  # Remove "https://"
            has_credentials = "@" in url_without_scheme.split("/")[0]

            if has_credentials:
                # URL has embedded username, inject token as password
                # Format: https://username:token@host/path
                at_index = url_without_scheme.index("@")
                user_part = url_without_scheme[:at_index]
                rest_of_url = url_without_scheme[at_index + 1 :]
                # Check if there's already a password
                if ":" in user_part:
                    # Replace existing password with token
                    username = user_part.split(":")[0]
                    clone_url = f"https://{username}:{auth_token}@{rest_of_url}"
                else:
                    # Add token as password
                    clone_url = f"https://{user_part}:{auth_token}@{rest_of_url}"
            else:
                # No existing credentials, inject token
                if "github.com" in clone_url:
                    clone_url = clone_url.replace(
                        "https://", f"https://x-access-token:{auth_token}@"
                    )
                elif "bitbucket.org" in clone_url:
                    clone_url = clone_url.replace("https://", f"https://x-token-auth:{auth_token}@")

        # Use git ls-remote to get refs without cloning
        proc = await asyncio.create_subprocess_exec(
            "git",
            "ls-remote",
            "--refs",
            clone_url,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()

        if proc.returncode != 0:
            raise RuntimeError(f"git ls-remote failed: {stderr.decode()}")

        branches = []
        tags = []
        commits = set()  # Use set to count unique commits

        for line in stdout.decode().strip().split("\n"):
            if not line:
                continue

            parts = line.split("\t", 1)
            if len(parts) != 2:
                continue

            commit_hash, ref = parts
            commits.add(commit_hash)

            if ref.startswith("refs/heads/"):
                branch_name = ref[len("refs/heads/") :]
                branches.append(branch_name)
            elif ref.startswith("refs/tags/"):
                tag_name = ref[len("refs/tags/") :]
                tags.append(tag_name)

        return {
            "branches": branches,
            "tags": tags,
            "commit_count": len(commits),
        }

    async def _check_lfs_files(
        self,
        clone_url: str,
        *,
        auth_token: str | None = None,
    ) -> dict[str, Any]:
        """Check for LFS files in a repository.

        Args:
            clone_url: Clone URL for the repository.
            auth_token: Optional auth token for HTTPS URLs.

        Returns:
            Dictionary with has_lfs and file_count.
        """
        result = {"has_lfs": False, "file_count": 0}

        # Try to fetch .gitattributes via API (more reliable than git archive)
        api_result = await self._check_lfs_via_api(clone_url, auth_token=auth_token)
        if api_result["has_lfs"] or api_result.get("checked"):
            return api_result

        # Fallback to git archive (works for Bitbucket)
        auth_clone_url = clone_url
        if auth_token and clone_url.startswith("https://"):
            url_without_scheme = clone_url[8:]
            has_credentials = "@" in url_without_scheme.split("/")[0]

            if has_credentials:
                at_index = url_without_scheme.index("@")
                user_part = url_without_scheme[:at_index]
                rest_of_url = url_without_scheme[at_index + 1 :]
                if ":" in user_part:
                    username = user_part.split(":")[0]
                    auth_clone_url = f"https://{username}:{auth_token}@{rest_of_url}"
                else:
                    auth_clone_url = f"https://{user_part}:{auth_token}@{rest_of_url}"
            else:
                if "bitbucket.org" in clone_url:
                    auth_clone_url = clone_url.replace(
                        "https://", f"https://x-token-auth:{auth_token}@"
                    )

        try:
            proc = await asyncio.create_subprocess_exec(
                "git",
                "archive",
                "--remote",
                auth_clone_url,
                "HEAD",
                ".gitattributes",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()

            if proc.returncode == 0 and stdout:
                content = stdout.decode(errors="ignore")
                if "filter=lfs" in content:
                    result["has_lfs"] = True
                    result["file_count"] = content.count("filter=lfs")
        except Exception as e:
            logger.debug("git_archive_failed", error=str(e))

        return result

    async def _check_lfs_via_api(
        self,
        clone_url: str,
        *,
        auth_token: str | None = None,
    ) -> dict[str, Any]:
        """Check for LFS via GitHub/Bitbucket API.

        Args:
            clone_url: Clone URL for the repository.
            auth_token: Optional auth token.

        Returns:
            Dictionary with has_lfs, file_count, and checked flag.
        """
        result = {"has_lfs": False, "file_count": 0, "checked": False}

        # Extract repo info from clone URL
        if "github.com" in clone_url:
            # GitHub: https://github.com/owner/repo.git
            match = re.search(r"github\.com[/:]([^/]+)/([^/.]+)", clone_url)
            if match:
                owner, repo = match.groups()
                result = await self._check_lfs_github(owner, repo, auth_token)
        elif "bitbucket.org" in clone_url:
            # Bitbucket: https://username@bitbucket.org/workspace/repo.git
            # Extract username from URL if present for Basic auth
            username = None
            user_match = re.search(r"https://([^@:]+)@bitbucket\.org", clone_url)
            if user_match:
                username = user_match.group(1)

            match = re.search(r"bitbucket\.org[/:]([^/]+)/([^/.]+)", clone_url)
            if match:
                workspace, repo = match.groups()
                result = await self._check_lfs_bitbucket(
                    workspace, repo, auth_token, username=username
                )

        return result

    async def _check_lfs_github(
        self,
        owner: str,
        repo: str,
        auth_token: str | None = None,
    ) -> dict[str, Any]:
        """Check for LFS via GitHub API.

        Args:
            owner: Repository owner.
            repo: Repository name.
            auth_token: GitHub token.

        Returns:
            Dictionary with has_lfs, file_count, and checked flag.
        """
        result = {"has_lfs": False, "file_count": 0, "checked": False}

        headers = {"Accept": "application/vnd.github.v3.raw"}
        if auth_token:
            headers["Authorization"] = f"Bearer {auth_token}"

        try:
            async with httpx.AsyncClient(verify=self._ssl_verify) as client:
                # Try to fetch .gitattributes from default branch
                url = f"https://api.github.com/repos/{owner}/{repo}/contents/.gitattributes"
                response = await client.get(url, headers=headers, timeout=30)

                result["checked"] = True

                if response.status_code == 404:
                    # No .gitattributes file
                    return result

                if response.status_code != 200:
                    logger.debug(
                        "github_api_error",
                        owner=owner,
                        repo=repo,
                        status=response.status_code,
                    )
                    return result

                # Parse response - could be raw content or JSON
                content = response.text
                if response.headers.get("content-type", "").startswith("application/json"):
                    # Need to decode base64 content
                    import base64
                    import json

                    data = json.loads(content)
                    if "content" in data:
                        content = base64.b64decode(data["content"]).decode(errors="ignore")

                # Parse .gitattributes for LFS patterns
                lfs_patterns = []
                for line in content.splitlines():
                    line = line.strip()
                    if "filter=lfs" in line:
                        parts = line.split()
                        if parts:
                            lfs_patterns.append(parts[0])

                result["has_lfs"] = len(lfs_patterns) > 0
                result["file_count"] = len(lfs_patterns)

                logger.debug(
                    "github_lfs_check",
                    owner=owner,
                    repo=repo,
                    has_lfs=result["has_lfs"],
                    patterns=len(lfs_patterns),
                )

        except Exception as e:
            logger.debug("github_lfs_check_failed", owner=owner, repo=repo, error=str(e))

        return result

    async def _check_lfs_bitbucket(
        self,
        workspace: str,
        repo: str,
        auth_token: str | None = None,
        *,
        username: str | None = None,
    ) -> dict[str, Any]:
        """Check for LFS via Bitbucket API.

        Args:
            workspace: Bitbucket workspace.
            repo: Repository name.
            auth_token: Bitbucket token (app password).
            username: Bitbucket username for Basic auth.

        Returns:
            Dictionary with has_lfs, file_count, and checked flag.
        """
        import base64

        result = {"has_lfs": False, "file_count": 0, "checked": False}

        headers = {}
        if auth_token:
            if username:
                # Bitbucket app password requires Basic auth
                credentials = f"{username}:{auth_token}"
                encoded = base64.b64encode(credentials.encode()).decode()
                headers["Authorization"] = f"Basic {encoded}"
            else:
                # Fallback to Bearer (for OAuth tokens)
                headers["Authorization"] = f"Bearer {auth_token}"

        try:
            async with httpx.AsyncClient(verify=self._ssl_verify) as client:
                # Fetch .gitattributes from default branch
                url = f"https://api.bitbucket.org/2.0/repositories/{workspace}/{repo}/src/HEAD/.gitattributes"
                response = await client.get(url, headers=headers, timeout=30)

                result["checked"] = True

                if response.status_code == 404:
                    return result

                if response.status_code != 200:
                    logger.debug(
                        "bitbucket_api_error",
                        workspace=workspace,
                        repo=repo,
                        status=response.status_code,
                    )
                    return result

                content = response.text

                # Parse .gitattributes for LFS patterns
                lfs_patterns = []
                for line in content.splitlines():
                    line = line.strip()
                    if "filter=lfs" in line:
                        parts = line.split()
                        if parts:
                            lfs_patterns.append(parts[0])

                result["has_lfs"] = len(lfs_patterns) > 0
                result["file_count"] = len(lfs_patterns)

                logger.debug(
                    "bitbucket_lfs_check",
                    workspace=workspace,
                    repo=repo,
                    has_lfs=result["has_lfs"],
                    patterns=len(lfs_patterns),
                )

        except Exception as e:
            logger.debug("bitbucket_lfs_check_failed", workspace=workspace, repo=repo, error=str(e))

        return result

    async def validate_plan(
        self,
        plan: MigrationPlan,
        *,
        migration_id: str | None = None,
        quick: bool = False,
    ) -> ValidationReport:
        """Validate all repositories in a migration plan.

        Args:
            plan: Migration plan to validate.
            migration_id: Optional migration ID.
            quick: If True, only check counts.

        Returns:
            ValidationReport with overall results.
        """
        report = ValidationReport(
            migration_id=migration_id,
            total=len(plan.repositories),
        )

        logger.info(
            "validation_started",
            total=report.total,
            migration_id=migration_id,
        )

        for mapping in plan.repositories:
            # Build URLs
            source_url = mapping.source_clone_url
            if not source_url:
                report.skipped += 1
                continue
            target_url = f"https://github.com/{mapping.target_full_name}.git"

            result = await self.validate_repository(
                source_url,
                target_url,
                source_full_name=mapping.source_full_name,
                target_full_name=mapping.target_full_name,
                quick=quick,
                source_has_lfs=mapping.has_lfs,
            )

            report.repositories.append(result)

            if result.status == ValidationStatus.PASSED:
                report.passed += 1
            elif result.status == ValidationStatus.FAILED:
                report.failed += 1
            elif result.status == ValidationStatus.WARNING:
                report.warnings += 1
            else:
                report.skipped += 1

        logger.info(
            "validation_finished",
            passed=report.passed,
            failed=report.failed,
            status=report.status.value,
        )

        return report

    async def validate_pr_migration(
        self,
        source_repo: str,
        target_repo: str,
        pr_mapping: dict[str, Any],
    ) -> PRValidation:
        """Validate a single PR migration.

        Args:
            source_repo: Source repository name.
            target_repo: Target repository name.
            pr_mapping: PR migration state dict from state store.

        Returns:
            PRValidation result.
        """
        result = PRValidation(
            source_pr_id=pr_mapping.get("source_pr_id", ""),
            source_repo=source_repo,
            target_pr_number=pr_mapping.get("target_pr_number"),
            target_repo=target_repo,
            status=ValidationStatus.SKIPPED,
            source_state=pr_mapping.get("pr_state"),
            comments_expected=0,  # Would need to fetch from source
            comments_migrated=pr_mapping.get("comments_migrated", 0),
        )

        log = logger.bind(
            source_pr=result.source_pr_id,
            target_pr=result.target_pr_number,
        )

        try:
            # Check if PR was migrated
            if pr_mapping.get("status") != "completed":
                result.status = ValidationStatus.FAILED
                result.message = f"PR not migrated: {pr_mapping.get('status')}"
                log.warning("pr_validation_failed", reason="not_migrated")
                return result

            if not result.target_pr_number:
                result.status = ValidationStatus.FAILED
                result.message = "No target PR number"
                log.warning("pr_validation_failed", reason="no_target")
                return result

            # PR was migrated successfully
            result.status = ValidationStatus.PASSED

            # Check for comment migration issues
            comments_failed = pr_mapping.get("comments_failed", 0)
            if comments_failed > 0:
                result.status = ValidationStatus.WARNING
                result.message = f"{comments_failed} comments failed to migrate"
                log.warning("pr_validation_warning", comments_failed=comments_failed)
            else:
                log.info("pr_validation_passed")

        except Exception as e:
            result.status = ValidationStatus.FAILED
            result.message = str(e)
            log.error("pr_validation_error", error=str(e))

        return result

    async def validate_pr_migrations(
        self,
        source_repo: str,
        target_repo: str,
        pr_mappings: list[dict[str, Any]],
        *,
        migration_id: str | None = None,
    ) -> PRValidationReport:
        """Validate all PR migrations for a repository.

        Includes comment count validation and attribution accuracy checks.

        Args:
            source_repo: Source repository name.
            target_repo: Target repository name.
            pr_mappings: List of PR migration state dicts.
            migration_id: Optional migration ID.

        Returns:
            PRValidationReport with comment and attribution sub-reports.
        """
        report = PRValidationReport(
            migration_id=migration_id,
            source_repo=source_repo,
            target_repo=target_repo,
            total=len(pr_mappings),
        )

        logger.info(
            "pr_validation_started",
            source_repo=source_repo,
            target_repo=target_repo,
            total=report.total,
        )

        for pr_mapping in pr_mappings:
            result = await self.validate_pr_migration(
                source_repo,
                target_repo,
                pr_mapping,
            )

            report.pr_validations.append(result)

            if result.status == ValidationStatus.PASSED:
                report.passed += 1
            elif result.status == ValidationStatus.FAILED:
                report.failed += 1
            elif result.status == ValidationStatus.WARNING:
                report.warnings += 1

        # Comment count validation
        report.comment_report = await self.validate_comment_counts(pr_mappings)

        # Attribution validation
        report.attribution_report = await self.validate_attributions(pr_mappings)

        logger.info(
            "pr_validation_finished",
            passed=report.passed,
            failed=report.failed,
            warnings=report.warnings,
            status=report.status.value,
        )

        return report

    async def validate_comment_counts(
        self,
        pr_mappings: list[dict[str, Any]],
    ) -> CommentValidationReport:
        """Validate comment migration completeness.

        Checks comments_migrated and comments_failed from state DB
        for each completed PR migration.

        Args:
            pr_mappings: List of PR migration state dicts.

        Returns:
            CommentValidationReport with aggregated counts.
        """
        report = CommentValidationReport()

        for pr_mapping in pr_mappings:
            if pr_mapping.get("status") != "completed":
                continue

            report.total_prs += 1
            migrated = pr_mapping.get("comments_migrated", 0)
            failed = pr_mapping.get("comments_failed", 0)
            expected = migrated + failed

            report.total_comments_expected += expected
            report.total_comments_migrated += migrated
            report.total_comments_failed += failed

            if failed > 0:
                report.prs_with_missing_comments += 1
            else:
                report.prs_with_all_comments += 1

        logger.info(
            "comment_validation_finished",
            total_prs=report.total_prs,
            comments_expected=report.total_comments_expected,
            comments_migrated=report.total_comments_migrated,
            comments_failed=report.total_comments_failed,
            status=report.status.value,
        )

        return report

    async def validate_attributions(
        self,
        pr_mappings: list[dict[str, Any]],
    ) -> AttributionValidationReport:
        """Validate user attribution accuracy.

        Checks author_mapped and author_username from state DB
        for each completed PR migration.

        Args:
            pr_mappings: List of PR migration state dicts.

        Returns:
            AttributionValidationReport with mapping statistics.
        """
        report = AttributionValidationReport()
        ghost_set: set[str] = set()

        for pr_mapping in pr_mappings:
            if pr_mapping.get("status") != "completed":
                continue

            report.total_prs += 1

            if pr_mapping.get("author_mapped"):
                report.prs_with_mapped_author += 1
            else:
                report.prs_with_ghost_author += 1
                username = pr_mapping.get("author_username")
                if username:
                    ghost_set.add(username)

        report.ghost_usernames = sorted(ghost_set)

        logger.info(
            "attribution_validation_finished",
            total_prs=report.total_prs,
            mapped=report.prs_with_mapped_author,
            ghost=report.prs_with_ghost_author,
            mapping_rate=report.mapping_rate,
            status=report.status.value,
        )

        return report
