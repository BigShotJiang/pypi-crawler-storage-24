"""PR comment migration service for bb2gh.

Handles fetching PR comments from Bitbucket and creating them in GitHub.
"""

from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

import structlog

from bb2gh.models.pull_request import (
    PRAuthor,
    PRComment,
    PRCommentMigrationResult,
    PRCommentMigrationStats,
    PRCommentType,
)

if TYPE_CHECKING:
    from collections.abc import AsyncIterator
    from typing import Any

    from bb2gh.adapters.base import BitbucketSourceAdapter, TargetAdapter
    from bb2gh.models.user_mapping import UserMappingStore

logger = structlog.get_logger(__name__)


class PRCommentMigrationService:
    """Service for migrating PR comments from Bitbucket to GitHub."""

    def __init__(
        self,
        *,
        source_adapter: BitbucketSourceAdapter,
        target_adapter: TargetAdapter[Any, Any],
        user_mapping: UserMappingStore | None = None,
    ) -> None:
        """Initialize PRCommentMigrationService.

        Args:
            source_adapter: Adapter for source platform (Bitbucket).
            target_adapter: Adapter for target platform (GitHub).
            user_mapping: User mapping store for attribution.
        """
        self._source = source_adapter
        self._target = target_adapter
        self._user_mapping = user_mapping

    async def fetch_pr_comments(
        self,
        repo_full_name: str,
        pr_id: str,
    ) -> AsyncIterator[PRComment]:
        """Fetch all comments for a PR.

        Args:
            repo_full_name: Full repository name (workspace/repo).
            pr_id: Pull request ID.

        Yields:
            PRComment objects.
        """
        logger.debug("fetching_pr_comments", repo=repo_full_name, pr_id=pr_id)

        async for comment_data in self._source.list_pr_comments(repo_full_name, pr_id):
            comment = self._parse_bitbucket_comment(comment_data, pr_id)
            yield comment

    def _parse_bitbucket_comment(
        self,
        comment_data: dict[str, Any],
        _pr_id: str,
    ) -> PRComment:
        """Parse Bitbucket comment API response into PRComment model.

        Args:
            comment_data: Raw comment data from Bitbucket API.
            _pr_id: Pull request ID (unused, available for future use).

        Returns:
            PRComment model.
        """
        # Parse author
        user_data = comment_data.get("user", {})
        author = PRAuthor(
            username=user_data.get("username", user_data.get("account_id", "unknown")),
            display_name=user_data.get("display_name"),
            account_id=user_data.get("account_id"),
        )

        # Determine comment type
        inline = comment_data.get("inline")
        if inline:
            comment_type = PRCommentType.INLINE
            file_path = inline.get("path")
            line_number = inline.get("to") or inline.get("from")
        else:
            comment_type = PRCommentType.GENERAL
            file_path = None
            line_number = None

        # Parse timestamps
        created_at = None
        updated_at = None
        if comment_data.get("created_on"):
            created_at = datetime.fromisoformat(comment_data["created_on"].replace("Z", "+00:00"))
        if comment_data.get("updated_on"):
            updated_at = datetime.fromisoformat(comment_data["updated_on"].replace("Z", "+00:00"))

        # Get parent ID for threaded comments
        parent = comment_data.get("parent")
        parent_id = str(parent.get("id")) if parent else None

        return PRComment(
            id=str(comment_data.get("id")),
            content=comment_data.get("content", {}).get("raw", ""),
            author=author,
            created_at=created_at,
            updated_at=updated_at,
            comment_type=comment_type,
            file_path=file_path,
            line_number=line_number,
            parent_id=parent_id,
            html_url=comment_data.get("links", {}).get("html", {}).get("href"),
        )

    async def migrate_comment(
        self,
        comment: PRComment,
        target_repo: str,
        target_pr_number: int,
        *,
        parent_author_username: str | None = None,
    ) -> PRCommentMigrationResult:
        """Migrate a single comment to GitHub.

        For inline comments, attempts to create a review comment at the
        original file/line position. Falls back to an issue comment with
        metadata if the position no longer exists.

        Args:
            comment: Source comment to migrate.
            target_repo: Target repository (org/repo).
            target_pr_number: Target PR number.
            parent_author_username: Username of parent comment author for reply prefix.

        Returns:
            PRCommentMigrationResult.
        """
        result = PRCommentMigrationResult(
            source_comment_id=comment.id,
            source_pr_id=str(target_pr_number),
        )

        log = logger.bind(
            comment_id=comment.id,
            target_repo=target_repo,
            pr_number=target_pr_number,
        )

        try:
            # Build comment body with attribution
            body = self._build_comment_body(
                comment, result, parent_author_username=parent_author_username
            )

            gh_comment: dict[str, Any] | None = None

            # Try review comment for inline comments with position info
            if (
                comment.comment_type == PRCommentType.INLINE
                and comment.file_path
                and comment.line_number
                and hasattr(self._target, "create_review_comment")
            ):
                try:
                    gh_comment = await self._target.create_review_comment(
                        target_repo,
                        target_pr_number,
                        body=body,
                        path=comment.file_path,
                        line=comment.line_number,
                        commit_id=comment.commit_hash,
                    )
                    log.debug(
                        "inline_comment_created_as_review",
                        file=comment.file_path,
                        line=comment.line_number,
                    )
                except Exception as review_err:
                    log.debug(
                        "review_comment_failed_falling_back",
                        error=str(review_err),
                        file=comment.file_path,
                    )
                    # Fall through to issue comment

            # Fall back to issue comment
            if gh_comment is None:
                gh_comment = await self._target.create_issue_comment(
                    target_repo,
                    target_pr_number,
                    body,
                )

            if gh_comment is None:
                raise RuntimeError("GitHub comment creation returned no result")

            result.target_comment_id = gh_comment.get("id")
            result.success = True
            log.debug("comment_migrated", gh_comment_id=result.target_comment_id)

        except Exception as e:
            result.error_message = str(e)
            log.error("comment_migration_failed", error=str(e))

        return result

    def _build_comment_body(
        self,
        comment: PRComment,
        result: PRCommentMigrationResult,
        *,
        parent_author_username: str | None = None,
    ) -> str:
        """Build comment body with attribution.

        Args:
            comment: Source comment.
            result: Migration result to update with attribution info.
            parent_author_username: Username of the parent comment's author
                for adding [Reply to @user] prefix.

        Returns:
            Formatted comment body.
        """
        parts = []

        # Reply prefix for threaded comments
        if comment.parent_id and parent_author_username:
            parts.append(f"*[Reply to @{parent_author_username}]*")
            parts.append("")

        # Attribution header
        target_user, attribution = self._resolve_user(comment.author.username)
        if attribution:
            parts.append(f"*{attribution}*")
            parts.append("")
        else:
            result.author_mapped = True
            result.author_username = target_user

        # Original content
        parts.append(comment.content)

        # Metadata footer for inline comments
        if comment.comment_type == PRCommentType.INLINE and comment.file_path:
            parts.append("")
            parts.append("---")
            parts.append(f"*Originally on `{comment.file_path}`")
            if comment.line_number:
                parts[-1] += f" line {comment.line_number}"
            parts[-1] += "*"

        # Timestamp in user-friendly format
        if comment.created_at:
            ts = comment.created_at.strftime("%Y-%m-%d %H:%M UTC")
            parts.append(f"*Originally posted on {ts}*")

        return "\n".join(parts)

    def _resolve_user(self, bb_username: str) -> tuple[str | None, str | None]:
        """Resolve a Bitbucket username to GitHub username.

        Args:
            bb_username: Bitbucket username.

        Returns:
            Tuple of (github_username, attribution_note).
        """
        if self._user_mapping:
            return self._user_mapping.resolve_user(bb_username)

        # No mapping available - use attribution note
        return None, f"[Migrated from Bitbucket: @{bb_username}]"

    async def migrate_pr_comments(
        self,
        source_repo: str,
        source_pr_id: str,
        target_repo: str,
        target_pr_number: int,
    ) -> PRCommentMigrationStats:
        """Migrate all comments from a PR.

        Comments are sorted so parents are migrated before their replies,
        and reply comments get a [Reply to @author] prefix for context.

        Args:
            source_repo: Source repository (workspace/repo).
            source_pr_id: Source PR ID.
            target_repo: Target repository (org/repo).
            target_pr_number: Target PR number.

        Returns:
            PRCommentMigrationStats.
        """
        stats = PRCommentMigrationStats()

        logger.info(
            "migrating_pr_comments",
            source_repo=source_repo,
            source_pr=source_pr_id,
            target_pr=target_pr_number,
        )

        # Collect all comments first so we can sort parents before children
        comments: list[PRComment] = []
        async for comment in self.fetch_pr_comments(source_repo, source_pr_id):
            comments.append(comment)

        # Sort: parents first (no parent_id), then children
        # Within each group, preserve original order (by created_at or insertion)
        comments = self._sort_parents_first(comments)

        # Track parent comment authors for reply prefixes
        comment_authors: dict[str, str] = {}

        for comment in comments:
            stats.total += 1

            # Look up parent author for reply prefix
            parent_author = comment_authors.get(comment.parent_id or "")

            result = await self.migrate_comment(
                comment,
                target_repo,
                target_pr_number,
                parent_author_username=parent_author,
            )
            stats.results.append(result)

            # Track this comment's author for potential replies
            comment_authors[comment.id] = comment.author.username

            if result.success:
                stats.migrated += 1
                if comment.comment_type == PRCommentType.INLINE:
                    stats.inline_migrated += 1
                else:
                    stats.general_migrated += 1
            else:
                stats.failed += 1

        logger.info(
            "pr_comments_migrated",
            source_pr=source_pr_id,
            total=stats.total,
            migrated=stats.migrated,
            failed=stats.failed,
        )

        return stats

    @staticmethod
    def _sort_parents_first(comments: list[PRComment]) -> list[PRComment]:
        """Sort comments so parents come before their children.

        Uses a simple two-pass approach: first all root comments (no parent),
        then all replies, preserving relative order within each group.

        Args:
            comments: Unsorted list of comments.

        Returns:
            Sorted list with parents before children.
        """
        roots = [c for c in comments if not c.parent_id]
        children = [c for c in comments if c.parent_id]
        return roots + children
