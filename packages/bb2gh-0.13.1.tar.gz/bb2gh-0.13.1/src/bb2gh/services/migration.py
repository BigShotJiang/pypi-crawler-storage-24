"""Migration service for bb2gh.

Orchestrates the migration of repositories from source to target.
"""

from __future__ import annotations

import asyncio
import traceback
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

import structlog

from bb2gh.exceptions import BB2GHError
from bb2gh.models.plan import (
    MigrationPlan,
    MigrationStatus,
    RepositoryMapping,
)
from bb2gh.models.state import MigrationRunStatus, RepositoryStatus
from bb2gh.services.git import CloneResult, GitProgress, GitService, PushResult

if TYPE_CHECKING:
    from pathlib import Path
    from typing import Any

    from bb2gh.adapters.base import BitbucketSourceAdapter, TargetAdapter
    from bb2gh.cleanup.service import CleanupService
    from bb2gh.state.store import StateStore

logger = structlog.get_logger(__name__)


class MigrationError(BB2GHError):
    """Migration operation failed."""

    pass


@dataclass
class MigrationResult:
    """Result of a single repository migration."""

    source_name: str
    target_name: str
    success: bool
    clone_result: CloneResult | None = None
    push_result: PushResult | None = None
    error_message: str | None = None
    error_traceback: str | None = None
    branches_migrated: int = 0
    tags_migrated: int = 0
    lfs_migrated: bool = False


@dataclass
class MigrationStats:
    """Statistics for a migration run."""

    total: int = 0
    completed: int = 0
    failed: int = 0
    skipped: int = 0
    in_progress: int = 0
    results: list[MigrationResult] = field(default_factory=list)

    @property
    def pending(self) -> int:
        """Number of pending repositories."""
        return self.total - self.completed - self.failed - self.skipped - self.in_progress


# Type alias for progress callback
MigrationProgressCallback = Callable[[str, str, float], None]


class MigrationService:
    """Service for migrating repositories.

    Orchestrates the full migration workflow:
    1. Create target repository (if needed)
    2. Clone from source
    3. Push to target
    4. Migrate LFS objects (if applicable)
    5. Verify migration

    Supports checkpoint/resume via optional StateStore integration.
    """

    def __init__(
        self,
        *,
        target_adapter: TargetAdapter[Any, Any],
        source_adapter: BitbucketSourceAdapter | None = None,
        git_service: GitService | None = None,
        work_dir: Path | str | None = None,
        source_auth_token: str | None = None,
        target_auth_token: str | None = None,
        state_store: StateStore | None = None,
        migrate_branch_protection: bool = False,
        cleanup_service: CleanupService | None = None,
    ) -> None:
        """Initialize MigrationService.

        Args:
            target_adapter: Adapter for the target system (GitHub).
            source_adapter: Optional source adapter (needed for branch protection).
            git_service: Optional GitService instance (created if not provided).
            work_dir: Working directory for git operations.
            source_auth_token: Auth token for source (Bitbucket) HTTPS URLs.
            target_auth_token: Auth token for target (GitHub) HTTPS URLs.
            state_store: Optional StateStore for checkpoint/resume capability.
            migrate_branch_protection: Whether to migrate branch protection rules.
        """
        self._target_adapter = target_adapter
        self._source_adapter = source_adapter
        self._git_service = git_service or GitService(work_dir=work_dir)
        self._source_auth = source_auth_token
        self._target_auth = target_auth_token
        self._owns_git_service = git_service is None
        self._state_store = state_store
        self._current_migration_id: str | None = None
        self._migrate_branch_protection = migrate_branch_protection
        self._cleanup_service = cleanup_service

    async def __aenter__(self) -> MigrationService:
        """Async context manager entry."""
        if self._owns_git_service:
            await self._git_service.__aenter__()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Async context manager exit."""
        if self._owns_git_service:
            await self._git_service.__aexit__(exc_type, exc_val, exc_tb)

    async def migrate_repository(
        self,
        mapping: RepositoryMapping,
        *,
        progress_callback: MigrationProgressCallback | None = None,
    ) -> MigrationResult:
        """Migrate a single repository.

        Args:
            mapping: Repository mapping configuration.
            progress_callback: Optional callback for progress updates.
                Called with (repo_name, phase, percent).

        Returns:
            MigrationResult with migration details.
        """
        result = MigrationResult(
            source_name=mapping.source_full_name,
            target_name=mapping.target_full_name,
            success=False,
        )

        log = logger.bind(
            source=mapping.source_full_name,
            target=mapping.target_full_name,
        )

        try:
            # Phase 1: Create target repository if needed
            if mapping.create_if_not_exists:
                if progress_callback:
                    progress_callback(mapping.source_name, "creating_target", 0)

                await self._ensure_target_repo(mapping)
                log.info("target_repo_ready")

            # Phase 2: Clone from source
            if progress_callback:
                progress_callback(mapping.source_name, "cloning", 10)

            def clone_progress(p: GitProgress) -> None:
                if progress_callback:
                    # Map git progress to overall progress (10-50%)
                    pct = 10 + (p.percent * 0.4)
                    progress_callback(mapping.source_name, f"cloning:{p.phase}", pct)

            if not mapping.source_clone_url:
                raise ValueError(f"No clone URL for {mapping.source_name}")

            clone_result = await self._git_service.clone_mirror(
                mapping.source_clone_url,
                repo_name=mapping.source_name,
                auth_token=self._source_auth,
                progress_callback=clone_progress,
            )
            result.clone_result = clone_result
            result.branches_migrated = clone_result.branch_count
            result.tags_migrated = clone_result.tag_count

            log.info(
                "clone_complete",
                branches=clone_result.branch_count,
                tags=clone_result.tag_count,
                commits=clone_result.commit_count,
            )

            # Phase 2.5: Cleanup (if configured)
            if mapping.cleanup.enabled:
                if self._cleanup_service is None:
                    from bb2gh.exceptions import ConfigError

                    raise ConfigError(
                        "Cleanup enabled but CleanupService not injected into MigrationService"
                    )
                if progress_callback:
                    progress_callback(mapping.source_name, "cleanup", 45)

                cleanup_result = await self._cleanup_service.fix(
                    repo_path=clone_result.local_path,
                    config=mapping.cleanup,
                    confirm=True,
                )
                if not cleanup_result.success:
                    from bb2gh.exceptions import CleanupError

                    raise CleanupError(
                        f"Cleanup failed for {mapping.source_name}: "
                        f"{cleanup_result.operation.error_message}"
                    )
                log.info(
                    "cleanup_complete",
                    engine=cleanup_result.operation.engine_used,
                    strategy=cleanup_result.operation.strategy,
                )

            # Phase 3: Fetch LFS objects (if applicable)
            if mapping.migrate_lfs and clone_result.has_lfs:
                if progress_callback:
                    progress_callback(mapping.source_name, "fetching_lfs", 50)

                def lfs_fetch_progress(p: GitProgress) -> None:
                    if progress_callback:
                        # Map LFS fetch progress to 50-60%
                        pct = 50 + (p.percent * 0.1)
                        # Show LFS-specific phase info
                        phase = p.phase if p.phase != "unknown" else "downloading"
                        msg = f"fetching_lfs:{phase}"
                        if p.current > 0 and p.total > 0:
                            msg = f"fetching_lfs ({p.current}/{p.total})"
                        progress_callback(mapping.source_name, msg, pct)

                lfs_fetched = await self._git_service.fetch_lfs(
                    clone_result.local_path,
                    source_url=mapping.source_clone_url,
                    auth_token=self._source_auth,
                    progress_callback=lfs_fetch_progress,
                )
                result.lfs_migrated = lfs_fetched
                log.info("lfs_fetched", success=lfs_fetched)

            # Phase 4: Push to target
            if progress_callback:
                progress_callback(mapping.source_name, "pushing", 60)

            def push_progress(p: GitProgress) -> None:
                if progress_callback:
                    # Map git progress to overall progress (60-90%)
                    pct = 60 + (p.percent * 0.3)
                    progress_callback(mapping.source_name, f"pushing:{p.phase}", pct)

            # Build target URL
            target_url = self._build_target_url(mapping)

            push_result = await self._git_service.push_mirror(
                clone_result.local_path,
                target_url,
                auth_token=self._target_auth,
                transfer_mode=mapping.transfer_mode,
                progress_callback=push_progress,
            )
            result.push_result = push_result

            if not push_result.success:
                result.error_message = push_result.error_message
                log.error("push_failed", error=push_result.error_message)
                return result

            log.info(
                "push_complete",
                branches=push_result.branches_pushed,
                tags=push_result.tags_pushed,
            )

            # Phase 5: Push LFS objects (if applicable)
            if mapping.migrate_lfs and clone_result.has_lfs and result.lfs_migrated:
                if progress_callback:
                    progress_callback(mapping.source_name, "pushing_lfs", 90)

                def lfs_push_progress(p: GitProgress) -> None:
                    if progress_callback:
                        # Map LFS push progress to 90-98%
                        pct = 90 + (p.percent * 0.08)
                        # Show LFS-specific phase info
                        phase = p.phase if p.phase != "unknown" else "uploading"
                        msg = f"pushing_lfs:{phase}"
                        if p.current > 0 and p.total > 0:
                            msg = f"pushing_lfs ({p.current}/{p.total})"
                        progress_callback(mapping.source_name, msg, pct)

                lfs_pushed = await self._git_service.push_lfs(
                    clone_result.local_path,
                    target_url,
                    auth_token=self._target_auth,
                    progress_callback=lfs_push_progress,
                )

                if not lfs_pushed:
                    log.warning("lfs_push_failed")
                    # LFS push failure is not fatal, continue

            # Phase 6: Update default branch if needed
            if mapping.default_branch != "main":
                await self._set_default_branch(mapping)

            # Phase 7: Branch protection migration (best-effort)
            if self._migrate_branch_protection and self._source_adapter is not None:
                try:
                    if progress_callback:
                        progress_callback(mapping.source_name, "branch_protection", 95)

                    await self._migrate_branch_protection_rules(mapping, log)
                except Exception as bp_err:
                    # Branch protection errors are non-fatal
                    log.warning(
                        "branch_protection_migration_failed",
                        error=str(bp_err),
                    )

            # Success!
            if progress_callback:
                progress_callback(mapping.source_name, "complete", 100)

            result.success = True
            log.info("migration_complete")

        except Exception as e:
            result.error_message = str(e)
            result.error_traceback = traceback.format_exc()
            log.error("migration_failed", error=str(e))

        return result

    async def _ensure_target_repo(self, mapping: RepositoryMapping) -> None:
        """Ensure target repository exists.

        Args:
            mapping: Repository mapping configuration.

        Raises:
            MigrationError: If repository creation fails.
        """
        # Check if repo already exists
        existing = await self._target_adapter.get_repository(mapping.target_full_name)
        if existing:
            logger.debug("target_repo_exists", repo=mapping.target_full_name)
            return

        # Create the repository
        visibility = mapping.visibility == "public"
        await self._target_adapter.create_repository(
            name=mapping.target_name,
            organization=mapping.target_org,
            private=not visibility,
        )

    def _build_target_url(self, mapping: RepositoryMapping) -> str:
        """Build the target clone URL for pushing.

        Args:
            mapping: Repository mapping configuration.

        Returns:
            HTTPS clone URL for the target repository.
        """
        # Default to github.com, but could be configured
        return f"https://github.com/{mapping.target_full_name}.git"

    async def _set_default_branch(self, mapping: RepositoryMapping) -> None:
        """Set the default branch on the target repository.

        Args:
            mapping: Repository mapping configuration.
        """
        try:
            await self._target_adapter.update_repository(
                mapping.target_full_name,
                default_branch=mapping.default_branch,
            )
            logger.debug(
                "default_branch_set",
                repo=mapping.target_full_name,
                branch=mapping.default_branch,
            )
        except Exception as e:
            # Non-fatal error
            logger.warning(
                "failed_to_set_default_branch",
                repo=mapping.target_full_name,
                branch=mapping.default_branch,
                error=str(e),
            )

    async def _migrate_branch_protection_rules(
        self,
        mapping: RepositoryMapping,
        log: Any,
    ) -> None:
        """Migrate branch protection rules for a repository.

        Best-effort: errors are logged but don't fail the migration.

        Args:
            mapping: Repository mapping configuration.
            log: Bound logger instance.
        """
        from bb2gh.services.branch_protection import BranchProtectionService

        service = BranchProtectionService(
            source_adapter=self._source_adapter,
            target_adapter=self._target_adapter,
        )

        plan = await service.plan(
            mapping.source_full_name,
            mapping.target_full_name,
        )

        if not plan.rulesets:
            log.debug("no_branch_protection_rules", source=mapping.source_full_name)
            return

        results = await service.apply(plan)

        log.info(
            "branch_protection_migrated",
            rulesets_created=len(results),
            rulesets_planned=len(plan.rulesets),
        )

    async def _build_parallel_pending(
        self,
        plan: MigrationPlan,
    ) -> list[tuple[int, RepositoryMapping]]:
        """Return pending repositories sorted by descending size.

        Skips repos that are already completed or skipped in the plan,
        and repos completed in the state store (for resume).

        Args:
            plan: Migration plan to filter.

        Returns:
            List of (original_index, mapping) tuples sorted by size_bytes descending.
        """
        pending: list[tuple[int, RepositoryMapping]] = []

        for i, mapping in enumerate(plan.repositories):
            # Skip state-store completed repos when resuming
            if self._state_store and self._current_migration_id:
                repo_state = await self._state_store.get_repository(
                    self._current_migration_id, mapping.source_id
                )
                if repo_state and repo_state.status == RepositoryStatus.COMPLETED:
                    continue

            # Skip plan-level completed/skipped
            if mapping.status in (MigrationStatus.COMPLETED, MigrationStatus.SKIPPED):
                continue

            pending.append((i, mapping))

        # Sort by size_bytes descending (largest first), None treated as 0
        pending.sort(key=lambda item: item[1].size_bytes or 0, reverse=True)
        return pending

    async def _run_parallel(
        self,
        plan: MigrationPlan,
        workers: int,
        *,
        progress_callback: MigrationProgressCallback | None = None,
        stop_on_error: bool = False,
    ) -> MigrationStats:
        """Execute migrations in parallel using asyncio worker tasks.

        Args:
            plan: Migration plan to execute.
            workers: Number of concurrent worker tasks.
            progress_callback: Optional callback for progress updates.
            stop_on_error: Whether to stop on first error.

        Returns:
            MigrationStats with overall results.
        """
        stats = MigrationStats(total=len(plan.repositories))

        # Build sorted pending list and count skipped
        pending = await self._build_parallel_pending(plan)
        stats.skipped = stats.total - len(pending)

        if not pending:
            return stats

        # Feed work into an asyncio queue
        queue: asyncio.Queue[tuple[int, RepositoryMapping]] = asyncio.Queue()
        for item in pending:
            queue.put_nowait(item)

        stop_event = asyncio.Event()

        async def worker_loop() -> None:
            # stop_event prevents workers from picking up new items,
            # but does not cancel already-in-flight migrations.
            while not stop_event.is_set():
                try:
                    _, mapping = queue.get_nowait()
                except asyncio.QueueEmpty:
                    return

                # Mark in-progress in state store
                if self._state_store and self._current_migration_id:
                    await self._state_store.update_repository_status(
                        self._current_migration_id,
                        mapping.source_id,
                        RepositoryStatus.IN_PROGRESS,
                    )

                mapping.status = MigrationStatus.IN_PROGRESS

                # Completion-count-based progress to prevent backward jumps
                def repo_progress(
                    name: str, phase: str, pct: float, _total: int = stats.total
                ) -> None:
                    if progress_callback:
                        done = stats.completed + stats.skipped + stats.failed
                        overall_pct = ((done + pct / 100) / _total) * 100
                        progress_callback(name, phase, overall_pct)

                try:
                    result = await self.migrate_repository(
                        mapping,
                        progress_callback=repo_progress,
                    )
                except Exception as exc:
                    result = MigrationResult(
                        source_name=mapping.source_full_name,
                        target_name=mapping.target_full_name,
                        success=False,
                        error_message=str(exc),
                        error_traceback=traceback.format_exc(),
                    )

                stats.results.append(result)
                queue.task_done()

                if result.success:
                    mapping.status = MigrationStatus.COMPLETED
                    stats.completed += 1

                    if self._state_store and self._current_migration_id:
                        await self._state_store.update_repository_status(
                            self._current_migration_id,
                            mapping.source_id,
                            RepositoryStatus.COMPLETED,
                        )
                else:
                    mapping.status = MigrationStatus.FAILED
                    mapping.error_message = result.error_message
                    stats.failed += 1

                    if self._state_store and self._current_migration_id:
                        await self._state_store.update_repository_status(
                            self._current_migration_id,
                            mapping.source_id,
                            RepositoryStatus.FAILED,
                            error_message=result.error_message,
                            error_traceback=self._format_error_traceback(result),
                        )

                    if stop_on_error:
                        logger.warning(
                            "migration_stopped",
                            reason="stop_on_error",
                            completed=stats.completed,
                            failed=stats.failed,
                        )
                        stop_event.set()
                        return

        # Launch N worker tasks
        worker_tasks = [asyncio.create_task(worker_loop()) for _ in range(workers)]
        await asyncio.gather(*worker_tasks)

        return stats

    async def migrate_plan(
        self,
        plan: MigrationPlan,
        *,
        plan_file: str | None = None,
        progress_callback: MigrationProgressCallback | None = None,
        stop_on_error: bool = False,
        resume_migration_id: str | None = None,
        resume: bool = False,
        workers: int = 1,
    ) -> MigrationStats:
        """Migrate all repositories in a plan.

        Args:
            plan: Migration plan to execute.
            plan_file: Path to the plan file (for state tracking).
            progress_callback: Optional callback for progress updates.
            stop_on_error: Whether to stop on first error.
            resume_migration_id: Migration ID to resume from.
            resume: If True, find and resume the latest migration for this plan file.
            workers: Number of concurrent workers (1 = sequential, >1 = parallel).

        Returns:
            MigrationStats with overall results.
        """
        if workers < 1:
            raise ValueError(f"workers must be >= 1, got {workers}")

        # If resume=True, get the latest migration ID for this plan
        effective_resume_id = resume_migration_id
        if resume and not resume_migration_id and self._state_store and plan_file:
            latest = await self._state_store.get_latest_migration(plan_file)
            if latest:
                effective_resume_id = latest.migration_id

        # Initialize state tracking if store is available
        if self._state_store:
            await self._init_migration_state(
                plan,
                plan_file=plan_file,
                resume_migration_id=effective_resume_id,
            )

        logger.info(
            "migration_started",
            total=len(plan.repositories),
            stop_on_error=stop_on_error,
            migration_id=self._current_migration_id,
        )

        # If resuming, update migration status to in_progress
        if self._state_store and self._current_migration_id:
            await self._state_store.update_migration_status(
                self._current_migration_id,
                status=MigrationRunStatus.IN_PROGRESS,
            )

        if workers > 1:
            stats = await self._run_parallel(
                plan,
                workers,
                progress_callback=progress_callback,
                stop_on_error=stop_on_error,
            )
        else:
            stats = await self._run_sequential(
                plan,
                progress_callback=progress_callback,
                stop_on_error=stop_on_error,
            )

        # Update final migration status
        if self._state_store and self._current_migration_id:
            final_status = (
                MigrationRunStatus.COMPLETED if stats.failed == 0 else MigrationRunStatus.FAILED
            )
            await self._state_store.update_migration_status(
                self._current_migration_id,
                status=final_status,
            )

        logger.info(
            "migration_finished",
            completed=stats.completed,
            failed=stats.failed,
            skipped=stats.skipped,
            migration_id=self._current_migration_id,
        )

        return stats

    async def _run_sequential(
        self,
        plan: MigrationPlan,
        *,
        progress_callback: MigrationProgressCallback | None = None,
        stop_on_error: bool = False,
    ) -> MigrationStats:
        """Execute migrations sequentially (original path).

        Args:
            plan: Migration plan to execute.
            progress_callback: Optional callback for progress updates.
            stop_on_error: Whether to stop on first error.

        Returns:
            MigrationStats with overall results.
        """
        stats = MigrationStats(total=len(plan.repositories))

        for i, mapping in enumerate(plan.repositories):
            # Check if repo is already completed in state store (for resume)
            if self._state_store and self._current_migration_id:
                repo_state = await self._state_store.get_repository(
                    self._current_migration_id, mapping.source_id
                )
                if repo_state and repo_state.status == RepositoryStatus.COMPLETED:
                    logger.debug(
                        "skipping_completed_repo",
                        source=mapping.source_full_name,
                    )
                    # Only count as skipped, not completed (was completed in previous run)
                    stats.skipped += 1
                    continue

            if mapping.status == MigrationStatus.COMPLETED:
                # Repo was already completed (from plan status), just skip it
                stats.skipped += 1
                continue

            if mapping.status == MigrationStatus.SKIPPED:
                stats.skipped += 1
                continue

            # Update status
            mapping.status = MigrationStatus.IN_PROGRESS
            stats.in_progress += 1

            # Update state store status to in_progress
            if self._state_store and self._current_migration_id:
                await self._state_store.update_repository_status(
                    self._current_migration_id,
                    mapping.source_id,
                    RepositoryStatus.IN_PROGRESS,
                )

            # Create a wrapper progress callback that includes repo index
            def repo_progress(
                name: str, phase: str, pct: float, _i: int = i, _total: int = stats.total
            ) -> None:
                if progress_callback:
                    overall_pct = ((_i + pct / 100) / _total) * 100
                    progress_callback(name, phase, overall_pct)

            result = await self.migrate_repository(
                mapping,
                progress_callback=repo_progress,
            )

            stats.results.append(result)
            stats.in_progress -= 1

            if result.success:
                mapping.status = MigrationStatus.COMPLETED
                stats.completed += 1

                # Checkpoint: save completed state
                if self._state_store and self._current_migration_id:
                    await self._state_store.update_repository_status(
                        self._current_migration_id,
                        mapping.source_id,
                        RepositoryStatus.COMPLETED,
                    )
            else:
                mapping.status = MigrationStatus.FAILED
                mapping.error_message = result.error_message
                stats.failed += 1

                # Checkpoint: save failed state with error details
                if self._state_store and self._current_migration_id:
                    await self._state_store.update_repository_status(
                        self._current_migration_id,
                        mapping.source_id,
                        RepositoryStatus.FAILED,
                        error_message=result.error_message,
                        error_traceback=self._format_error_traceback(result),
                    )

                if stop_on_error:
                    logger.warning(
                        "migration_stopped",
                        reason="stop_on_error",
                        completed=stats.completed,
                        failed=stats.failed,
                    )
                    break

        return stats

    async def _init_migration_state(
        self,
        plan: MigrationPlan,
        *,
        plan_file: str | None = None,
        resume_migration_id: str | None = None,
    ) -> None:
        """Initialize migration state in the store.

        Creates a new migration record or resumes an existing one.

        Args:
            plan: Migration plan to track.
            plan_file: Path to the plan file.
            resume_migration_id: Migration ID to resume from.
        """
        if not self._state_store:
            return

        plan_path = plan_file or "unknown"

        if resume_migration_id:
            # Resume existing migration
            migration = await self._state_store.get_migration(resume_migration_id)
            if migration:
                self._current_migration_id = migration.migration_id
                logger.info(
                    "resuming_migration",
                    migration_id=resume_migration_id,
                )
                return
            else:
                logger.warning(
                    "migration_not_found",
                    migration_id=resume_migration_id,
                )

        # Create new migration
        migration = await self._state_store.create_migration(
            plan_file=plan_path,
            source_workspace=plan.metadata.source_workspace,
            target_org=plan.metadata.target_org,
        )
        self._current_migration_id = migration.migration_id

        # Add all repositories to state
        for mapping in plan.repositories:
            await self._state_store.add_repository(
                migration_id=migration.migration_id,
                source_id=mapping.source_id,
                source_name=mapping.source_name,
                source_full_name=mapping.source_full_name,
                target_full_name=mapping.target_full_name,
            )

        logger.info(
            "migration_state_initialized",
            migration_id=migration.migration_id,
            repos=len(plan.repositories),
        )

    def _format_error_traceback(self, result: MigrationResult) -> str | None:
        """Format error traceback for storage."""
        return result.error_traceback

    @property
    def migration_id(self) -> str | None:
        """Get the current migration ID."""
        return self._current_migration_id
