"""Adapter base classes for bb2gh.

Wraps the shared migration-core adapter contracts and extends the source side
with Bitbucket-specific operations used by bb2gh services.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from migration_core.adapters.base import SourceAdapter, TargetAdapter

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

    from bb2gh.models.analysis import LargeFilesResult, LFSResult
    from bb2gh.models.branch_protection import RepoBranchProtection
else:
    Repository = Any
    User = Any


class BitbucketSourceAdapter(SourceAdapter[Any, Any]):
    """Shared Bitbucket source adapter contract for bb2gh."""

    async def list_workspace_members(self, workspace: str) -> AsyncIterator[dict[str, Any]]:
        """List members of a workspace."""
        users = await self.list_users(workspace=workspace)
        for user in users:
            yield {
                "username": user.username,
                "email": user.email,
                "display_name": user.display_name,
                "account_id": user.id,
                "avatar_url": user.avatar_url,
            }

    async def list_pull_requests(
        self,
        repo_full_name: str,  # noqa: ARG002
        *,
        state: str = "OPEN",  # noqa: ARG002
    ) -> AsyncIterator[dict[str, Any]]:
        """List pull requests for a repository."""
        raise NotImplementedError("list_pull_requests not implemented")
        yield

    async def list_pr_comments(
        self,
        repo_full_name: str,  # noqa: ARG002
        pr_id: str,  # noqa: ARG002
    ) -> AsyncIterator[dict[str, Any]]:
        """List comments on a pull request."""
        raise NotImplementedError("list_pr_comments not implemented")
        yield

    async def list_pr_activity(
        self,
        repo_full_name: str,  # noqa: ARG002
        pr_id: str,  # noqa: ARG002
    ) -> AsyncIterator[dict[str, Any]]:
        """List activity entries for a pull request."""
        raise NotImplementedError("list_pr_activity not implemented")
        yield

    async def get_branch_protection(self, repo_id: str) -> RepoBranchProtection | None:
        """Fetch branch protection data for a repository."""
        raise NotImplementedError("get_branch_protection not implemented")

    async def verify_credentials(self) -> bool:
        """Verify that credentials are valid."""
        raise NotImplementedError("verify_credentials not implemented")

    async def count_branches(self, repo_id: str) -> int:
        """Count branches in a repository."""
        raise NotImplementedError("count_branches not implemented")

    async def count_pull_requests(
        self,
        repo_id: str,
        *,
        state: str | None = None,
    ) -> int:
        """Count pull requests in a repository."""
        raise NotImplementedError("count_pull_requests not implemented")

    async def analyze_large_files(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
        threshold_bytes: int = 100_000_000,
    ) -> LargeFilesResult:
        """Analyze a repository for large files."""
        raise NotImplementedError("analyze_large_files not implemented")

    async def detect_lfs_patterns(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> LFSResult:
        """Detect LFS configuration from .gitattributes."""
        raise NotImplementedError("detect_lfs_patterns not implemented")

    async def get_pipeline_config(
        self,
        repo_id: str,
        *,
        branch: str | None = None,
    ) -> str | None:
        """Fetch raw pipeline configuration file content."""
        raise NotImplementedError("get_pipeline_config not implemented")


__all__ = ["BitbucketSourceAdapter", "SourceAdapter", "TargetAdapter"]
