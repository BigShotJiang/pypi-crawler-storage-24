"""Bitbucket Data Center adapter.

Implements SourceAdapter for Bitbucket DC 7.x/8.x REST API.
Normalizes DC responses into Cloud-shaped dicts so existing service
parsers (_parse_bitbucket_pr, _parse_activity) remain unchanged.
"""

from __future__ import annotations

from datetime import UTC, datetime
from typing import TYPE_CHECKING, Any

import structlog

from bb2gh.adapters.base import BitbucketSourceAdapter
from bb2gh.adapters.dc_client import DCClient
from bb2gh.exceptions import APIError, AuthenticationError
from bb2gh.models.analysis import LargeFilesResult, LFSResult
from bb2gh.models.repository import Repository
from bb2gh.models.user import User

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

logger = structlog.get_logger(__name__)

# DC uses "OPEN", "MERGED", "DECLINED". Cloud also has "SUPERSEDED" which DC
# does not support — the DC API silently returns empty for unknown states.
_DC_SUPPORTED_PR_STATES = {"OPEN", "MERGED", "DECLINED"}


class BitbucketDCAdapter(BitbucketSourceAdapter):
    """Bitbucket Data Center source adapter.

    Implements the SourceAdapter interface for Bitbucket DC REST API.
    Context manager support is inherited from SourceAdapter (calls close()).
    """

    def __init__(self, base_url: str, token: str, verify_ssl: str | bool = True) -> None:
        self._client = DCClient(base_url=base_url, token=token, verify_ssl=verify_ssl)
        self._base_url = base_url.rstrip("/")

    # -- SourceAdapter abstract methods --

    async def list_repositories(
        self,
        *,
        workspace: str | None = None,
        project: str | None = None,
        page: int = 1,  # noqa: ARG002
        page_size: int = 100,
    ) -> list[Repository]:
        """List repositories in a DC project.

        Note: DC pagination uses start/limit internally. The ``page`` parameter
        is accepted for SourceAdapter compatibility but DC always returns all
        repositories via the paginator. The ``page_size`` controls the per-request
        batch size sent to the DC API.
        """
        if workspace is None:
            raise ValueError("workspace (project key) is required for DC")
        project_key = project or workspace
        repos: list[Repository] = []
        async for value in self._client.paginate(
            f"/projects/{project_key}/repos",
            limit=page_size,
        ):
            repos.append(self._map_repo(value, project_key))
        return repos

    async def get_repository(self, repo_id: str) -> Repository | None:
        """Get a single repository by 'PROJECT/slug' identifier."""
        project_key, slug = self._parse_repo_full_name(repo_id)
        data = await self._client.get_json(f"/projects/{project_key}/repos/{slug}")
        return self._map_repo(data, project_key)

    async def list_users(
        self,
        *,
        workspace: str | None = None,  # noqa: ARG002
        page: int = 1,  # noqa: ARG002
        page_size: int = 100,
    ) -> list[User]:
        """List all users from the DC instance."""
        users: list[User] = []
        async for value in self._client.paginate("/users", limit=page_size):
            users.append(self._map_user(value))
        return users

    async def get_user(self, user_id: str) -> User | None:
        """Get a single user by username."""
        data = await self._client.get_json(f"/users/{user_id}")
        return self._map_user(data)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.close()

    # -- DC-specific methods --

    async def verify_credentials(self) -> bool:
        """Verify DC credentials by fetching projects."""
        await self._client.get_json("/projects", params={"start": 0, "limit": 1})
        return True

    # -- Discovery parity methods (Task 5) --

    async def count_branches(self, repo_full_name: str) -> int:
        """Count branches using DC's size field (avoids full pagination)."""
        project_key, slug = self._parse_repo_full_name(repo_full_name)
        data = await self._client.get_json(
            f"/projects/{project_key}/repos/{slug}/branches",
            params={"start": 0, "limit": 1},
        )
        return int(data.get("size", len(data.get("values", []))))

    async def count_pull_requests(
        self,
        repo_full_name: str,
        *,
        state: str | None = None,
    ) -> int:
        """Count all PRs using DC's size field."""
        project_key, slug = self._parse_repo_full_name(repo_full_name)
        params: dict[str, int | str] = {"start": 0, "limit": 1}
        if state:
            params["state"] = state
        else:
            params["state"] = "ALL"
        data = await self._client.get_json(
            f"/projects/{project_key}/repos/{slug}/pull-requests",
            params=params,
        )
        return int(data.get("size", len(data.get("values", []))))

    async def analyze_large_files(
        self,
        repo_full_name: str,  # noqa: ARG002
        *,
        branch: str | None = None,  # noqa: ARG002
        threshold_bytes: int = 100_000_000,  # noqa: ARG002
    ) -> LargeFilesResult:
        """DC has no file-size API — returns empty result."""
        return LargeFilesResult()

    async def detect_lfs_patterns(
        self,
        repo_full_name: str,
        *,
        branch: str | None = None,  # noqa: ARG002
    ) -> LFSResult:
        """Detect LFS patterns by reading .gitattributes via DC browse API."""
        project_key, slug = self._parse_repo_full_name(repo_full_name)
        path = f"/projects/{project_key}/repos/{slug}/browse/.gitattributes"
        try:
            data = await self._client.get_json(path)
        except APIError:
            return LFSResult()

        patterns: list[str] = []
        for line_obj in data.get("lines", []):
            text = line_obj.get("text", "")
            if "filter=lfs" in text:
                pattern = text.split()[0] if text.split() else ""
                if pattern:
                    patterns.append(pattern)

        return LFSResult(has_lfs=len(patterns) > 0, patterns=patterns, gitattributes_found=True)

    async def get_pipeline_config(
        self,
        repo_id: str,  # noqa: ARG002
        *,
        branch: str | None = None,  # noqa: ARG002
    ) -> str | None:
        """DC pipeline config discovery not yet supported.

        Returns None — Bitbucket DC pipeline support requires a separate
        implementation path.
        """
        logger.debug("pipeline_config_not_supported", adapter="bitbucket-dc")
        return None

    # -- PR normalization (Task 6) --

    async def list_pull_requests(
        self,
        repo_full_name: str,
        *,
        state: str = "OPEN",
    ) -> AsyncIterator[dict[str, Any]]:
        """List PRs normalized to Cloud shape."""
        if state and state.upper() not in _DC_SUPPORTED_PR_STATES:
            logger.debug(
                "dc_unsupported_pr_state",
                state=state,
                supported=_DC_SUPPORTED_PR_STATES,
            )
            return

        project_key, slug = self._parse_repo_full_name(repo_full_name)
        async for value in self._client.paginate(
            f"/projects/{project_key}/repos/{slug}/pull-requests",
            limit=25,
            params={"state": state} if state else None,
        ):
            yield self._normalize_pr(value, project_key, slug)

    # -- PR activity normalization (Task 7) --

    async def list_pr_activity(
        self,
        repo_full_name: str,
        pr_id: str,
    ) -> AsyncIterator[dict[str, Any]]:
        """List PR activities normalized to Cloud shape."""
        project_key, slug = self._parse_repo_full_name(repo_full_name)
        async for value in self._client.paginate(
            f"/projects/{project_key}/repos/{slug}/pull-requests/{pr_id}/activities",
            limit=25,
        ):
            yield self._normalize_activity(value)

    # -- Version detection (Task 8) --

    async def get_server_version(self) -> str | None:
        """Detect DC server version. Returns None if endpoint is inaccessible."""
        try:
            data = await self._client.get_json("/application-properties")
            version = data.get("version")
            if version:
                logger.info("dc_server_version", version=version)
            return version
        except (APIError, AuthenticationError):
            logger.warning("dc_version_detection_failed")
            return None

    # -- Mapping helpers --

    def _parse_repo_full_name(self, repo_full_name: str) -> tuple[str, str]:
        """Parse 'PROJECT_KEY/slug' into (project_key, slug)."""
        if "/" not in repo_full_name:
            raise ValueError(f"DC repo_full_name must be 'project/slug', got: {repo_full_name}")
        project_key, slug = repo_full_name.split("/", 1)
        return project_key, slug

    def _map_repo(self, data: dict[str, Any], project_key: str) -> Repository:
        """Convert DC repo JSON to Repository model."""
        slug = data.get("slug", "")
        project = (data.get("project") or {}).get("key", project_key)
        return Repository(
            id=str(data.get("id", slug)),
            name=slug,
            full_name=f"{project}/{slug}",
            description=data.get("description"),
            private=not data.get("public", False),
            default_branch=(data.get("defaultBranch") or {}).get("displayId", "main"),
            clone_url_https=self._extract_clone_url(data, "http"),
            clone_url_ssh=self._extract_clone_url(data, "ssh"),
            size_bytes=None,
            owner=project,
            project=project,
            created_at=None,
            updated_at=None,
            archived=data.get("archived", False),
            fork=data.get("origin") is not None,
            source="bitbucket",
        )

    def _map_user(self, data: dict[str, Any]) -> User:
        """Convert DC user JSON to User model."""
        return User(
            id=str(data.get("id", data.get("name", ""))),
            username=data.get("name") or data.get("slug") or "",
            display_name=data.get("displayName"),
            email=data.get("emailAddress"),
            source="bitbucket",
            account_id=None,
        )

    def _extract_clone_url(self, data: dict[str, Any], protocol: str) -> str | None:
        """Extract clone URL from DC links.

        DC uses "http" (not "https") as the link name for HTTPS clone URLs.
        Some DC versions may use "https" instead, so we check both for http protocol.
        """
        for link in (data.get("links") or {}).get("clone", []):
            link_name = link.get("name", "")
            if protocol == "http" and link_name in ("http", "https"):
                href: str | None = link.get("href")
                return href
            if link_name == protocol:
                href_val: str | None = link.get("href")
                return href_val
        return None

    # -- PR normalization helpers --

    def _normalize_pr(self, data: dict[str, Any], project_key: str, slug: str) -> dict[str, Any]:
        """Normalize DC PR JSON to Cloud-shaped dict."""
        from_ref = data.get("fromRef") or {}
        to_ref = data.get("toRef") or {}
        props = data.get("properties") or {}

        return {
            "id": data.get("id"),
            "state": data.get("state"),
            "title": data.get("title"),
            "description": data.get("description"),
            "author": self._normalize_user_dict((data.get("author") or {}).get("user")),
            "source": {
                "branch": {"name": from_ref.get("displayId")},
                "commit": {"hash": from_ref.get("latestCommit")},
            },
            "destination": {
                "branch": {"name": to_ref.get("displayId")},
                "commit": {"hash": to_ref.get("latestCommit")},
            },
            "created_on": self._to_iso(data.get("createdDate")),
            "updated_on": self._to_iso(data.get("updatedDate")),
            "reviewers": self._normalize_reviewers(data.get("reviewers", [])),
            "participants": self._normalize_participants(data.get("reviewers", [])),
            "links": {"html": {"href": self._pr_html_url(project_key, slug, data.get("id"))}},
            "merge_commit": {
                "hash": props.get("mergeCommit", {}).get("id") if isinstance(props, dict) else None
            },
            "properties": [],  # Must be list (not dict) — Cloud parser iterates
            "comment_count": 0,  # DC doesn't return count; int required
        }

    def _normalize_activity(self, data: dict[str, Any]) -> dict[str, Any]:
        """Normalize a single DC activity to Cloud shape."""
        action = (data.get("action") or "").upper()

        if action == "COMMENTED":
            comment = data.get("comment") or {}
            anchor = comment.get("commentAnchor") or {}
            return {
                "type": "comment",
                "comment": {
                    "id": comment.get("id"),
                    "content": {"raw": comment.get("text", "")},
                    "created_on": self._to_iso(comment.get("createdDate")),
                    "user": self._normalize_user_dict(comment.get("author")),
                    "inline": {
                        "path": anchor.get("path"),
                        "to": anchor.get("line"),
                        "from": anchor.get("line"),
                    }
                    if anchor.get("path")
                    else None,
                },
            }

        if action == "APPROVED":
            return {
                "type": "approval",
                "approval": {
                    "user": self._normalize_user_dict(data.get("user")),
                    "date": self._to_iso(data.get("createdDate")),
                },
            }

        # DECLINED, MERGED, RESCOPED, UPDATED, etc. → generic update
        return {
            "type": "update",
            "update": {
                "author": self._normalize_user_dict(data.get("user")),
                "date": self._to_iso(data.get("createdDate")),
            },
        }

    def _normalize_user_dict(self, data: dict[str, Any] | None) -> dict[str, Any]:
        """Normalize DC user to Cloud-shaped dict for PR/activity normalization."""
        if not data:
            return {
                "username": "unknown",
                "display_name": None,
                "account_id": None,
            }
        return {
            "username": data.get("name") or data.get("slug") or "unknown",
            "display_name": data.get("displayName"),
            "account_id": None,
        }

    def _normalize_reviewers(self, reviewers: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize DC reviewers list."""
        results: list[dict[str, Any]] = []
        for reviewer in reviewers:
            user = reviewer.get("user") or {}
            results.append(
                {
                    "username": user.get("name") or user.get("slug") or "",
                    "display_name": user.get("displayName"),
                }
            )
        return results

    def _normalize_participants(self, reviewers: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize DC reviewers to Cloud participants format."""
        results: list[dict[str, Any]] = []
        for reviewer in reviewers:
            user = reviewer.get("user") or {}
            results.append(
                {
                    "approved": reviewer.get("approved", False),
                    "user": {
                        "username": user.get("name") or user.get("slug") or "",
                    },
                }
            )
        return results

    def _to_iso(self, epoch_ms: int | None) -> str | None:
        """Convert epoch milliseconds to ISO 8601 string."""
        if epoch_ms is None:
            return None
        return datetime.fromtimestamp(epoch_ms / 1000, tz=UTC).isoformat()

    def _pr_html_url(self, project_key: str, slug: str, pr_id: int | None) -> str | None:
        """Build the HTML URL for a DC pull request."""
        if pr_id is None:
            return None
        return f"{self._base_url}/projects/{project_key}/repos/{slug}/pull-requests/{pr_id}"
