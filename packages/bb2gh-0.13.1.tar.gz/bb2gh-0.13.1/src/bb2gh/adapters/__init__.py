"""bb2gh adapters package - source and target system adapters."""

from migration_core.adapters.github import (
    GitHubBaseAdapter,
    GitHubCloudAdapter,
    GitHubCloudDRAdapter,
    GitHubServerAdapter,
)
from migration_core.adapters.github.multi_app import GitHubAppConfig, MultiAppGitHubAdapter

from bb2gh.adapters.base import BitbucketSourceAdapter, SourceAdapter, TargetAdapter
from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
from bb2gh.adapters.bitbucket_dc import BitbucketDCAdapter

__all__ = [
    "BitbucketCloudAdapter",
    "BitbucketDCAdapter",
    "BitbucketSourceAdapter",
    "GitHubAppConfig",
    "GitHubBaseAdapter",
    "GitHubCloudAdapter",
    "GitHubCloudDRAdapter",
    "GitHubServerAdapter",
    "MultiAppGitHubAdapter",
    "SourceAdapter",
    "TargetAdapter",
]
