"""Bitbucket Data Center low-level HTTP client.

Handles auth, pagination, retries, and error normalization for the DC REST API.
"""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import AsyncIterator

import httpx
import structlog

from bb2gh.exceptions import APIError, AuthenticationError

logger = structlog.get_logger(__name__)


class DCClient:
    """Low-level HTTP client for Bitbucket Data Center REST API.

    Responsibilities:
    - Bearer-token authentication
    - start/limit pagination with defensive parsing
    - Retry with exponential backoff on 429 (rate-limited)
    - Error normalization to ``APIError`` / ``AuthenticationError``

    Usage::

        client = DCClient(base_url="https://bb.example.com", token="tkn", verify_ssl=True)
        async for project in client.paginate("/projects"):
            print(project["key"])
        await client.close()
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        verify_ssl: str | bool,
    ) -> None:
        self._base = base_url.rstrip("/")
        self._token = token
        self._verify = verify_ssl
        self._client: httpx.AsyncClient | None = None
        self._max_retries = 3
        self._base_backoff = 1.0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(30.0),
                follow_redirects=True,
                verify=self._verify,
            )
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _url(self, path: str) -> str:
        return f"{self._base}/rest/api/latest{path}"

    async def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        """Send an HTTP request with rate-limit retry logic."""
        client = self._get_client()
        url = self._url(path)

        for attempt in range(self._max_retries + 1):
            response = await client.request(
                method,
                url,
                headers={"Authorization": f"Bearer {self._token}"},
                **kwargs,
            )
            if response.status_code != 429:
                return response

            if attempt >= self._max_retries:
                raise APIError("Rate limit exceeded", status_code=429)

            retry_after = response.headers.get("Retry-After")
            wait_time = float(retry_after) if retry_after else self._base_backoff * (2**attempt)
            logger.warning("dc_rate_limited", attempt=attempt, wait=wait_time)
            await asyncio.sleep(wait_time)

        # Unreachable — the loop always returns or raises — but keeps mypy happy.
        raise APIError("Rate limit handling failed", status_code=429)  # pragma: no cover

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    async def paginate(
        self,
        path: str,
        *,
        limit: int = 25,
        params: dict[str, Any] | None = None,
    ) -> AsyncIterator[dict[str, Any]]:
        """Paginate a DC REST API endpoint using ``start`` / ``limit``.

        Handles defensively:
        - ``values: null`` -> empty list (no crash)
        - ``isLastPage`` as bool **or** string ``"true"`` / ``"false"``
        - Missing ``nextPageStart`` -> stop
        - Max-page guard (10 000 pages) to prevent infinite loops
        """
        start = 0
        pages = 0
        max_pages = 10_000

        while True:
            request_params: dict[str, Any] = {
                "limit": limit,
                "start": start,
            }
            if params:
                request_params.update(params)

            response = await self._request("GET", path, params=request_params)

            if response.status_code == 401:
                raise AuthenticationError("Bitbucket DC authentication failed")
            if response.status_code >= 400:
                raise APIError(
                    f"DC API error: {response.status_code}",
                    status_code=response.status_code,
                )

            data: dict[str, Any] = response.json()
            values: list[dict[str, Any]] = data.get("values") or []
            for value in values:
                yield value

            # isLastPage may be a bool or a string like "true"
            if str(data.get("isLastPage", "")).lower() == "true":
                return

            next_start = data.get("nextPageStart")
            if next_start is None:
                logger.warning(
                    "dc_pagination_missing_next_start",
                    path=path,
                    page=pages,
                )
                return

            start = int(next_start)
            pages += 1
            if pages > max_pages:
                raise APIError("DC pagination exceeded max pages; aborting")

    async def get_json(self, path: str, **kwargs: Any) -> dict[str, Any]:
        """GET a single resource and return parsed JSON."""
        response = await self._request("GET", path, **kwargs)

        if response.status_code == 401:
            raise AuthenticationError("Bitbucket DC authentication failed")
        if response.status_code >= 400:
            raise APIError(
                f"DC API error: {response.status_code}",
                status_code=response.status_code,
            )

        result: dict[str, Any] = response.json()
        return result
