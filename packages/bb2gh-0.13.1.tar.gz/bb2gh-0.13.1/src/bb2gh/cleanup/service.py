"""Cleanup workflow orchestrator."""

from __future__ import annotations

import fnmatch
import shutil
from datetime import UTC, datetime
from typing import TYPE_CHECKING
from uuid import uuid4

import structlog

from bb2gh.cleanup.models import (
    AnalysisResult,
    CleanupConfig,
    CleanupOperation,
    CleanupResult,
    GitHubPlanLimits,
    VerificationResult,
)
from bb2gh.exceptions import (
    CleanupError,
    EngineNotAvailableError,
    InsufficientDiskSpaceError,
    LFSLimitExceededError,
)

if TYPE_CHECKING:
    from pathlib import Path

    from bb2gh.cleanup.analysis import AnalysisService
    from bb2gh.cleanup.lfs_conversion import LFSConversionService
    from bb2gh.cleanup.registry import EngineRegistry
    from bb2gh.services.git import GitService
    from bb2gh.state.store import StateStore

logger = structlog.get_logger(__name__)

DISK_SPACE_MULTIPLIER = 3


def _get_repo_size(repo_path: Path) -> int:
    """Return the repository size on disk in bytes."""
    total = 0
    for file_path in repo_path.rglob("*"):
        if file_path.is_file():
            total += file_path.stat().st_size
    return total


class CleanupService:
    """Coordinate analyze, fix, and verify cleanup workflows."""

    def __init__(
        self,
        *,
        git_service: GitService,
        engine_registry: EngineRegistry,
        analysis_service: AnalysisService,
        lfs_conversion_service: LFSConversionService,
        state_store: StateStore | None = None,
    ) -> None:
        self._git = git_service
        self._registry = engine_registry
        self._analysis = analysis_service
        self._lfs = lfs_conversion_service
        self._state_store = state_store

    async def analyze(self, repo_path: Path, config: CleanupConfig) -> AnalysisResult:
        """Delegate repository analysis to the shared analysis service."""
        return await self._analysis.scan_history(
            repo_path=repo_path,
            threshold_bytes=config.threshold_bytes,
        )

    async def fix(
        self,
        repo_path: Path,
        config: CleanupConfig,
        *,
        confirm: bool = False,
        backup_dir: Path | None = None,
    ) -> CleanupResult:
        """Run the configured cleanup strategy for a repository."""
        dry_run = not confirm
        backup_path: Path | None = None
        operation: CleanupOperation | None = None

        if not dry_run:
            await self._preflight_checks(repo_path, config)
            backup_path = await self._create_backup(repo_path, backup_dir)
            logger.info("cleanup.backup_created", backup_path=str(backup_path))

        operation = CleanupOperation(
            id=str(uuid4()),
            repo_name=repo_path.name,
            engine_used=config.engine,
            strategy=config.strategy,
            status="in_progress",
            backup_path=backup_path if not dry_run else None,
            started_at=datetime.now(tz=UTC),
        )

        if not dry_run and self._state_store is not None:
            await self._state_store.record_cleanup_operation(operation)

        try:
            if config.strategy == "lfs":
                result = await self._lfs.convert_to_lfs(
                    repo_path=repo_path,
                    patterns=config.patterns,
                    dry_run=dry_run,
                )
            else:
                engine = await self._registry.get_engine(config.engine)
                if config.patterns:
                    result = await engine.strip_by_pattern(
                        repo_path=repo_path,
                        patterns=config.patterns,
                        dry_run=dry_run,
                    )
                else:
                    result = await engine.strip_large_files(
                        repo_path=repo_path,
                        threshold_bytes=config.threshold_bytes,
                        dry_run=dry_run,
                    )

            operation.engine_used = result.operation.engine_used
            operation.status = "completed" if result.success else "failed"
            operation.object_map_path = result.operation.object_map_path
            operation.blobs_removed = result.operation.blobs_removed
            operation.blobs_converted_to_lfs = result.operation.blobs_converted_to_lfs
            operation.bytes_freed = result.operation.bytes_freed
            operation.branches_rewritten = result.operation.branches_rewritten
            operation.tags_rewritten = result.operation.tags_rewritten
            operation.completed_at = datetime.now(tz=UTC)
            operation.error_message = result.operation.error_message
            result.operation = operation
        except Exception as exc:
            operation.status = "failed"
            operation.error_message = str(exc)
            operation.completed_at = datetime.now(tz=UTC)
            raise
        finally:
            if not dry_run and self._state_store is not None:
                await self._state_store.record_cleanup_operation(operation)

        return result

    async def verify(
        self,
        repo_path: Path,
        threshold_bytes: int = 100_000_000,
    ) -> VerificationResult:
        """Verify no oversized blobs remain after cleanup."""
        result = await self._analysis.scan_history(
            repo_path=repo_path,
            threshold_bytes=threshold_bytes,
        )
        branches = await self._analysis._list_branches(repo_path)
        tags = await self._analysis._list_tags(repo_path)

        issues: list[str] = []
        if result.has_large_files:
            issues.append(
                f"{len(result.large_blobs)} file(s) still exceed "
                f"{threshold_bytes / (1024**2):.0f} MB threshold"
            )

        return VerificationResult(
            passed=not result.has_large_files,
            remaining_large_blobs=result.large_blobs,
            branches_intact=len(branches),
            branches_expected=len(branches),
            tags_intact=len(tags),
            tags_expected=len(tags),
            issues=issues,
        )

    async def _preflight_checks(self, repo_path: Path, config: CleanupConfig) -> None:
        """Run destructive-operation safety checks before cleanup."""
        returncode, stdout, _ = await self._git._run_git(
            ["rev-parse", "--is-bare-repository"],
            cwd=repo_path,
        )
        if returncode != 0 or stdout.strip() != "true":
            raise CleanupError(
                f"{repo_path} is not a bare/mirror clone. "
                "History rewriting must operate on a mirror clone "
                "(git clone --mirror). Running on a working tree can "
                "corrupt the repository."
            )

        repo_size = _get_repo_size(repo_path)
        required_space = repo_size * DISK_SPACE_MULTIPLIER
        disk_usage = shutil.disk_usage(repo_path)
        if disk_usage.free < required_space:
            raise InsufficientDiskSpaceError(
                f"Need {required_space / (1024**3):.1f} GB free "
                f"(~3x repo size), have {disk_usage.free / (1024**3):.1f} GB"
            )

        if config.strategy == "lfs":
            returncode, _, _ = await self._git._run_git(
                ["lfs", "version"],
                cwd=repo_path,
            )
            if returncode != 0:
                raise EngineNotAvailableError(
                    "git-lfs not installed. Required for LFS conversion strategy."
                )

        if config.strategy == "lfs" and config.patterns:
            limits = GitHubPlanLimits()
            analysis = await self._analysis.scan_history(
                repo_path=repo_path,
                threshold_bytes=limits.max_lfs_file_bytes,
            )
            oversized = [
                blob
                for blob in analysis.large_blobs
                if any(fnmatch.fnmatch(blob.path, pattern) for pattern in config.patterns)
            ]
            if oversized:
                names = ", ".join(f"{blob.path} ({blob.size_mb:.0f} MB)" for blob in oversized[:5])
                raise LFSLimitExceededError(
                    f"{len(oversized)} file(s) exceed GitHub LFS per-file "
                    f"limit of {limits.max_lfs_file_bytes / (1024**3):.0f} GB: "
                    f"{names}. Use 'remove' strategy or upgrade GitHub plan."
                )

    async def _create_backup(self, repo_path: Path, backup_dir: Path | None = None) -> Path:
        """Create and validate a mirror backup before destructive changes."""
        if backup_dir is None:
            backup_dir = repo_path.parent / f"{repo_path.name}.backup"

        logger.info("cleanup.creating_backup", source=str(repo_path), backup=str(backup_dir))
        await self._git._run_git(
            ["clone", "--mirror", str(repo_path), str(backup_dir)],
            cwd=repo_path.parent,
        )

        returncode, _, stderr = await self._git._run_git(
            ["fsck", "--no-dangling"],
            cwd=backup_dir,
        )
        if returncode != 0:
            logger.error("cleanup.backup_fsck_failed", stderr=stderr)
            raise RuntimeError(f"Backup verification failed: {stderr}")

        return backup_dir
