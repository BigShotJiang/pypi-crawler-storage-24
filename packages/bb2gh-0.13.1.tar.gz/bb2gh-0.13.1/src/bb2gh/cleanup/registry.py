"""Engine registry with auto-detection and selection."""

from __future__ import annotations

from typing import TYPE_CHECKING

import structlog

from bb2gh.exceptions import EngineNotAvailableError

if TYPE_CHECKING:
    from bb2gh.cleanup.engine import CleanupEngine
    from bb2gh.cleanup.models import EngineInfo

logger = structlog.get_logger(__name__)

ENGINE_PREFERENCE: tuple[str, ...] = ("filter-repo", "bfg")


class EngineRegistry:
    """Manage available cleanup engines with simple preference ordering."""

    def __init__(self, engines: dict[str, CleanupEngine]) -> None:
        """Initialize the registry with known engine implementations."""
        self._engines = engines

    async def detect_engines(self) -> list[EngineInfo]:
        """Return availability information for all registered engines."""
        infos: list[EngineInfo] = []
        for engine in self._engines.values():
            infos.append(await engine.get_info())
        return infos

    async def get_engine(self, preference: str = "auto") -> CleanupEngine:
        """Return a named engine or auto-select the best available engine."""
        if preference == "auto":
            return await self._auto_detect()

        if preference not in self._engines:
            raise EngineNotAvailableError(
                f"Unknown engine: {preference}. Available: {', '.join(self._engines.keys())}"
            )

        engine = self._engines[preference]
        info = await engine.get_info()
        if not info.available:
            raise EngineNotAvailableError(
                f"{info.name} is not available: {info.unavailable_reason}"
            )
        return engine

    async def _auto_detect(self) -> CleanupEngine:
        """Select the best available engine based on preference order."""
        for name in ENGINE_PREFERENCE:
            if name in self._engines:
                engine = self._engines[name]
                info = await engine.get_info()
                if info.available:
                    logger.info("cleanup.engine.auto_selected", engine=info.name)
                    return engine

        for engine in self._engines.values():
            info = await engine.get_info()
            if info.available:
                logger.info("cleanup.engine.auto_selected", engine=info.name)
                return engine

        raise EngineNotAvailableError(
            "No cleanup engine available. Install git-filter-repo: pip install git-filter-repo"
        )
