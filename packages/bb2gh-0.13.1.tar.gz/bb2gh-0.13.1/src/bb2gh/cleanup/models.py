"""Data models for cleanup analysis and execution."""

from __future__ import annotations

from datetime import datetime  # noqa: TC003 - needed at runtime by Pydantic
from enum import StrEnum
from pathlib import Path  # noqa: TC003 - needed at runtime by Pydantic
from typing import Literal

from pydantic import BaseModel, Field, computed_field

GB = 1024**3
MB = 1024**2


class CleanupCapability(StrEnum):
    """Capabilities exposed by cleanup engines."""

    STRIP_BY_SIZE = "strip_by_size"
    STRIP_BY_PATTERN = "strip_by_pattern"
    STRIP_BY_PATH = "strip_by_path"
    REPLACE_TEXT = "replace_text"
    ANALYZE_REPORT = "analyze_report"


class LargeBlob(BaseModel):
    """A large blob discovered in repository history."""

    sha: str
    path: str
    size_bytes: int
    commit_sha: str
    commit_date: datetime
    still_in_head: bool
    branch_refs: list[str]
    tag_refs: list[str] = Field(default_factory=list)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def size_mb(self) -> float:
        """Return the blob size in MiB."""
        return self.size_bytes / MB


class AnalysisResult(BaseModel):
    """Results from scanning full git history for large files."""

    repo_name: str
    commits_scanned: int
    objects_scanned: int
    threshold_bytes: int
    large_blobs: list[LargeBlob]
    total_large_bytes: int
    branches_affected: list[str]
    tags_affected: list[str]
    scan_duration_seconds: float

    @computed_field  # type: ignore[prop-decorator]
    @property
    def has_large_files(self) -> bool:
        """Whether the scan found blobs above the threshold."""
        return len(self.large_blobs) > 0

    @computed_field  # type: ignore[prop-decorator]
    @property
    def estimated_savings_mb(self) -> float:
        """Estimated space savings in MiB."""
        return self.total_large_bytes / MB


class CleanupConfig(BaseModel):
    """Per-repository cleanup configuration."""

    enabled: bool = False
    strategy: Literal["remove", "lfs"] = "remove"
    patterns: list[str] = Field(default_factory=list)
    threshold_bytes: int = 100_000_000
    engine: Literal["auto", "filter-repo", "bfg"] = "auto"


class CleanupOperation(BaseModel):
    """State recorded for a cleanup execution."""

    id: str
    repo_name: str
    engine_used: str
    strategy: Literal["remove", "lfs"]
    status: Literal["pending", "in_progress", "completed", "failed", "skipped"]
    backup_path: Path | None = None
    object_map_path: Path | None = None
    blobs_removed: int = 0
    blobs_converted_to_lfs: int = 0
    bytes_freed: int = 0
    branches_rewritten: int = 0
    tags_rewritten: int = 0
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error_message: str | None = None


class CleanupResult(BaseModel):
    """Outcome of a cleanup fix operation."""

    success: bool
    dry_run: bool
    operation: CleanupOperation
    warnings: list[str] = Field(default_factory=list)


class VerificationResult(BaseModel):
    """Outcome of post-cleanup verification."""

    passed: bool
    remaining_large_blobs: list[LargeBlob]
    branches_intact: int
    branches_expected: int
    tags_intact: int
    tags_expected: int
    issues: list[str] = Field(default_factory=list)


class EngineInfo(BaseModel):
    """Metadata about an available cleanup engine."""

    name: str
    version: str | None
    capabilities: set[CleanupCapability]
    available: bool
    unavailable_reason: str | None = None


class GitHubPlanLimits(BaseModel):
    """GitHub plan limits used for cleanup decisions."""

    max_file_bytes: int = 100 * MB
    max_lfs_file_bytes: int = 2 * GB
    lfs_storage_bytes: int = 10 * GB
    lfs_bandwidth_bytes: int = 10 * GB
    max_push_bytes: int = 2 * GB
    max_branches: int = 5_000

    @classmethod
    def for_plan(cls, plan: str) -> GitHubPlanLimits:
        """Return plan-specific limits, falling back to defaults."""
        configs: dict[str, dict[str, int]] = {
            "free": {
                "max_lfs_file_bytes": 2 * GB,
                "lfs_storage_bytes": 10 * GB,
            },
            "pro": {
                "max_lfs_file_bytes": 2 * GB,
                "lfs_storage_bytes": 10 * GB,
            },
            "team": {
                "max_lfs_file_bytes": 4 * GB,
                "lfs_storage_bytes": 250 * GB,
            },
            "enterprise": {
                "max_lfs_file_bytes": 5 * GB,
                "lfs_storage_bytes": 250 * GB,
            },
        }
        return cls(**configs.get(plan.lower(), {}))
