"""Engine-independent repository analysis for large files in git history."""

from __future__ import annotations

import time
from datetime import UTC, datetime
from typing import TYPE_CHECKING

import structlog

from bb2gh.cleanup.models import AnalysisResult, LargeBlob

if TYPE_CHECKING:
    from pathlib import Path

    from bb2gh.services.git import GitService, ProgressCallback

logger = structlog.get_logger(__name__)


class AnalysisService:
    """Scan git history for large blobs using raw git commands."""

    def __init__(self, git_service: GitService) -> None:
        """Initialize the analysis service with a GitService dependency."""
        self._git = git_service

    async def scan_history(
        self,
        repo_path: Path,
        threshold_bytes: int = 100_000_000,
        *,
        progress_callback: ProgressCallback | None = None,  # noqa: ARG002
    ) -> AnalysisResult:
        """Scan full git history for blobs exceeding the configured threshold."""
        start_time = time.monotonic()
        log = logger.bind(repo_path=str(repo_path), threshold_mb=threshold_bytes / (1024**2))
        log.info("cleanup.analysis.starting")

        object_paths = await self._enumerate_objects(repo_path)
        blob_sizes = await self._get_blob_sizes(repo_path, list(object_paths))
        large_shas = {
            sha: size
            for sha, size in blob_sizes.items()
            if size >= threshold_bytes and sha in object_paths
        }

        large_blobs: list[LargeBlob] = []
        for sha, size in sorted(large_shas.items(), key=lambda item: item[1], reverse=True):
            large_blobs.append(
                await self._build_large_blob(repo_path, sha, object_paths[sha], size)
            )

        total_large_bytes = sum(blob.size_bytes for blob in large_blobs)
        branches_affected = sorted({ref for blob in large_blobs for ref in blob.branch_refs})
        tags_affected = sorted({ref for blob in large_blobs for ref in blob.tag_refs})
        duration = round(time.monotonic() - start_time, 2)

        log.info(
            "cleanup.analysis.complete",
            large_files=len(large_blobs),
            total_large_mb=total_large_bytes / (1024**2),
            duration_seconds=duration,
        )

        return AnalysisResult(
            repo_name=repo_path.name,
            commits_scanned=len(object_paths),
            objects_scanned=len(blob_sizes),
            threshold_bytes=threshold_bytes,
            large_blobs=large_blobs,
            total_large_bytes=total_large_bytes,
            branches_affected=branches_affected,
            tags_affected=tags_affected,
            scan_duration_seconds=duration,
        )

    async def _enumerate_objects(self, repo_path: Path) -> dict[str, str]:
        """Map object SHAs to file paths using git rev-list."""
        returncode, stdout, _ = await self._git._run_git(
            ["rev-list", "--objects", "--all"],
            cwd=repo_path,
        )
        if returncode != 0:
            return {}

        objects: dict[str, str] = {}
        for line in stdout.strip().splitlines():
            parts = line.split(maxsplit=1)
            if len(parts) == 2:
                sha, path = parts
                objects[sha] = path
        return objects

    async def _get_blob_sizes(self, repo_path: Path, shas: list[str]) -> dict[str, int]:
        """Get object sizes via git cat-file, piping SHAs over stdin."""
        if not shas:
            return {}

        sha_input = "\n".join(shas)
        returncode, stdout, _ = await self._git._run_git(
            ["cat-file", "--batch-check"],
            cwd=repo_path,
            input=sha_input,
        )
        if returncode != 0:
            return {}

        sizes: dict[str, int] = {}
        for line in stdout.strip().splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[1] == "blob":
                try:
                    sizes[parts[0]] = int(parts[2])
                except ValueError:
                    continue
        return sizes

    async def _find_introducing_commit(self, repo_path: Path, sha: str) -> tuple[str, datetime]:
        """Find the commit that introduced a specific blob object."""
        returncode, stdout, _ = await self._git._run_git(
            [
                "log",
                "--all",
                f"--find-object={sha}",
                "--format=%H %aI",
                "-n",
                "1",
            ],
            cwd=repo_path,
        )
        if returncode != 0 or not stdout.strip():
            return ("unknown", datetime.now(tz=UTC))

        parts = stdout.strip().splitlines()[0].split(maxsplit=1)
        if len(parts) != 2:
            return ("unknown", datetime.now(tz=UTC))

        try:
            commit_date = datetime.fromisoformat(parts[1])
        except ValueError:
            commit_date = datetime.now(tz=UTC)

        return (parts[0], commit_date)

    async def _build_large_blob(
        self,
        repo_path: Path,
        sha: str,
        path: str,
        size: int,
    ) -> LargeBlob:
        """Build the LargeBlob record for a threshold-exceeding object."""
        commit_sha, commit_date = await self._find_introducing_commit(repo_path, sha)
        branch_refs = await self._find_refs_containing(repo_path, sha, "refs/heads/")
        tag_refs = await self._find_refs_containing(repo_path, sha, "refs/tags/")
        still_in_head = await self._is_in_head(repo_path, path)

        return LargeBlob(
            sha=sha,
            path=path,
            size_bytes=size,
            commit_sha=commit_sha,
            commit_date=commit_date,
            still_in_head=still_in_head,
            branch_refs=branch_refs,
            tag_refs=tag_refs,
        )

    async def _find_refs_containing(
        self,
        repo_path: Path,
        sha: str,
        prefix: str = "refs/heads/",
    ) -> list[str]:
        """List branch or tag refs that contain the given object."""
        returncode, stdout, _ = await self._git._run_git(
            [
                "for-each-ref",
                f"--contains={sha}",
                "--format=%(refname:short)",
                prefix,
            ],
            cwd=repo_path,
        )
        if returncode != 0:
            return []

        return [line.strip() for line in stdout.strip().splitlines() if line.strip()]

    async def _is_in_head(self, repo_path: Path, path: str) -> bool:
        """Check whether a file still exists in HEAD."""
        returncode, stdout, _ = await self._git._run_git(
            ["ls-tree", "HEAD", "--", path],
            cwd=repo_path,
        )
        return returncode == 0 and bool(stdout.strip())

    async def _list_branches(self, repo_path: Path) -> list[str]:
        """List all branches in the repository."""
        returncode, stdout, _ = await self._git._run_git(
            ["for-each-ref", "--format=%(refname:short)", "refs/heads/"],
            cwd=repo_path,
        )
        if returncode != 0:
            return []
        return [line.strip() for line in stdout.strip().splitlines() if line.strip()]

    async def _list_tags(self, repo_path: Path) -> list[str]:
        """List all tags in the repository."""
        returncode, stdout, _ = await self._git._run_git(
            ["tag", "--list"],
            cwd=repo_path,
        )
        if returncode != 0:
            return []
        return [line.strip() for line in stdout.strip().splitlines() if line.strip()]
