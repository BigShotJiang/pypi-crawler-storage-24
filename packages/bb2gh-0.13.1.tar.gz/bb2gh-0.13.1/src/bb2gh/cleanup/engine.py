"""Abstract interface for cleanup engines."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pathlib import Path

    from bb2gh.cleanup.models import CleanupResult, EngineInfo
    from bb2gh.services.git import ProgressCallback


class CleanupEngine(ABC):
    """Abstract interface for history rewriting engines."""

    @abstractmethod
    async def get_info(self) -> EngineInfo:
        """Return engine metadata including capabilities and availability."""

    @abstractmethod
    async def strip_large_files(
        self,
        repo_path: Path,
        threshold_bytes: int,
        *,
        dry_run: bool = True,
        progress_callback: ProgressCallback | None = None,
    ) -> CleanupResult:
        """Remove files exceeding the threshold from repository history."""

    @abstractmethod
    async def strip_by_pattern(
        self,
        repo_path: Path,
        patterns: list[str],
        *,
        dry_run: bool = True,
        progress_callback: ProgressCallback | None = None,
    ) -> CleanupResult:
        """Remove files matching the given patterns from repository history."""
