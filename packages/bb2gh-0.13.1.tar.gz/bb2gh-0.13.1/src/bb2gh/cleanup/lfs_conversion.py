"""LFS conversion service using git lfs migrate."""

from __future__ import annotations

from typing import TYPE_CHECKING
from uuid import uuid4

import structlog

from bb2gh.cleanup.models import CleanupOperation, CleanupResult

if TYPE_CHECKING:
    from pathlib import Path

    from bb2gh.services.git import GitService, ProgressCallback

logger = structlog.get_logger(__name__)


class LFSConversionService:
    """Convert matching files to LFS pointers across full git history."""

    def __init__(self, git_service: GitService) -> None:
        """Initialize the LFS conversion service with a GitService dependency."""
        self._git = git_service

    async def convert_to_lfs(
        self,
        repo_path: Path,
        patterns: list[str],
        *,
        dry_run: bool = True,
        progress_callback: ProgressCallback | None = None,  # noqa: ARG002
    ) -> CleanupResult:
        """Convert matching files to LFS pointers in all history."""
        log = logger.bind(repo_path=str(repo_path), patterns=patterns, dry_run=dry_run)
        operation = CleanupOperation(
            id=str(uuid4()),
            repo_name=repo_path.name,
            engine_used="git-lfs-migrate",
            strategy="lfs",
            status="in_progress",
        )
        include_arg = ",".join(patterns)

        if dry_run:
            log.info("cleanup.lfs.dry_run")
            returncode, _, _ = await self._git._run_git(
                [
                    "lfs",
                    "migrate",
                    "info",
                    "--everything",
                    f"--include={include_arg}",
                ],
                cwd=repo_path,
            )
            operation.status = "completed"
            return CleanupResult(
                success=returncode == 0,
                dry_run=True,
                operation=operation,
            )

        log.info("cleanup.lfs.converting")
        returncode, _, stderr = await self._git._run_git(
            [
                "lfs",
                "migrate",
                "import",
                "--everything",
                f"--include={include_arg}",
                "--yes",
            ],
            cwd=repo_path,
        )

        if returncode == 0:
            operation.status = "completed"
            log.info("cleanup.lfs.conversion_complete")
        else:
            operation.status = "failed"
            operation.error_message = stderr
            log.error("cleanup.lfs.conversion_failed", stderr=stderr)

        return CleanupResult(
            success=returncode == 0,
            dry_run=False,
            operation=operation,
        )
