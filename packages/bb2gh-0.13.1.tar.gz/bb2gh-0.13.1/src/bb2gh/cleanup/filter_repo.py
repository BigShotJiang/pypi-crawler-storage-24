"""git-filter-repo engine implementation."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import uuid4

import structlog

from bb2gh.cleanup.engine import CleanupEngine
from bb2gh.cleanup.models import (
    CleanupCapability,
    CleanupOperation,
    CleanupResult,
    EngineInfo,
)

if TYPE_CHECKING:
    from bb2gh.services.git import GitService, ProgressCallback

logger = structlog.get_logger(__name__)

ALL_CAPABILITIES = {
    CleanupCapability.STRIP_BY_SIZE,
    CleanupCapability.STRIP_BY_PATTERN,
    CleanupCapability.STRIP_BY_PATH,
    CleanupCapability.REPLACE_TEXT,
    CleanupCapability.ANALYZE_REPORT,
}


def _check_filter_repo_available() -> bool:
    """Check if git-filter-repo is installed."""
    return shutil.which("git-filter-repo") is not None


def _get_filter_repo_version() -> str | None:
    """Return the installed git-filter-repo version when available."""
    try:
        import importlib.metadata

        return importlib.metadata.version("git-filter-repo")
    except Exception:
        return None


class FilterRepoEngine(CleanupEngine):
    """Wrap git-filter-repo through subprocess calls."""

    def __init__(self, git_service: GitService) -> None:
        """Initialize the engine with a GitService dependency."""
        self._git = git_service

    async def get_info(self) -> EngineInfo:
        """Return availability and capability metadata for git-filter-repo."""
        available = _check_filter_repo_available()
        version = _get_filter_repo_version() if available else None
        return EngineInfo(
            name="filter-repo",
            version=version,
            capabilities=ALL_CAPABILITIES if available else set(),
            available=available,
            unavailable_reason=(
                None
                if available
                else "git-filter-repo not found. Install: pip install git-filter-repo"
            ),
        )

    async def strip_large_files(
        self,
        repo_path: Path,
        threshold_bytes: int,
        *,
        dry_run: bool = True,
        progress_callback: ProgressCallback | None = None,  # noqa: ARG002
    ) -> CleanupResult:
        """Strip blobs above the size threshold from repository history."""
        operation = CleanupOperation(
            id=str(uuid4()),
            repo_name=repo_path.name,
            engine_used="filter-repo",
            strategy="remove",
            status="in_progress",
        )
        log = logger.bind(
            repo_path=str(repo_path),
            threshold_mb=threshold_bytes / (1024**2),
            dry_run=dry_run,
        )

        if dry_run:
            log.info("cleanup.filter_repo.dry_run")
            returncode, _, stderr = await self._git._run_git(
                ["filter-repo", "--analyze"],
                cwd=repo_path,
            )
            if returncode != 0:
                operation.status = "failed"
                operation.error_message = stderr
                log.error("cleanup.filter_repo.analyze_failed", stderr=stderr)
                return CleanupResult(
                    success=False,
                    dry_run=True,
                    operation=operation,
                )
            operation.status = "completed"
            return CleanupResult(
                success=True,
                dry_run=True,
                operation=operation,
                warnings=self._parse_analyze_report(repo_path),
            )

        returncode, _, stderr = await self._git._run_git(
            [
                "filter-repo",
                f"--strip-blobs-bigger-than={threshold_bytes}",
                "--force",
            ],
            cwd=repo_path,
        )
        if returncode == 0:
            operation.object_map_path = self._save_object_map(repo_path)
            operation.status = "completed"
            log.info("cleanup.filter_repo.strip_complete")
            return CleanupResult(success=True, dry_run=False, operation=operation)

        operation.status = "failed"
        operation.error_message = stderr
        log.error("cleanup.filter_repo.strip_failed", stderr=stderr)
        return CleanupResult(success=False, dry_run=False, operation=operation)

    async def strip_by_pattern(
        self,
        repo_path: Path,
        patterns: list[str],
        *,
        dry_run: bool = True,
        progress_callback: ProgressCallback | None = None,  # noqa: ARG002
    ) -> CleanupResult:
        """Strip files matching glob patterns from repository history."""
        operation = CleanupOperation(
            id=str(uuid4()),
            repo_name=repo_path.name,
            engine_used="filter-repo",
            strategy="remove",
            status="in_progress",
        )
        log = logger.bind(repo_path=str(repo_path), patterns=patterns, dry_run=dry_run)

        if dry_run:
            log.info("cleanup.filter_repo.dry_run_patterns")
            analyze_rc, _, analyze_stderr = await self._git._run_git(
                ["filter-repo", "--analyze"],
                cwd=repo_path,
            )
            if analyze_rc != 0:
                operation.status = "failed"
                operation.error_message = analyze_stderr
                log.error("cleanup.filter_repo.analyze_failed", stderr=analyze_stderr)
                return CleanupResult(
                    success=False,
                    dry_run=True,
                    operation=operation,
                )
            warnings = self._parse_analyze_report(repo_path)
            for pattern in patterns:
                returncode, stdout, _ = await self._git._run_git(
                    ["ls-files", "--", pattern],
                    cwd=repo_path,
                )
                if returncode == 0 and stdout.strip():
                    matched = stdout.strip().splitlines()
                    warnings.append(
                        f"Pattern '{pattern}' matches {len(matched)} file(s) in HEAD: "
                        f"{', '.join(matched[:10])}" + ("..." if len(matched) > 10 else "")
                    )
            operation.status = "completed"
            return CleanupResult(
                success=True,
                dry_run=True,
                operation=operation,
                warnings=warnings,
            )

        args = ["filter-repo", "--force", "--invert-paths"]
        for pattern in patterns:
            args.extend(["--path-glob", pattern])

        returncode, _, stderr = await self._git._run_git(args, cwd=repo_path)
        if returncode == 0:
            operation.object_map_path = self._save_object_map(repo_path)
            operation.status = "completed"
            log.info("cleanup.filter_repo.strip_by_pattern_complete")
            return CleanupResult(success=True, dry_run=False, operation=operation)

        operation.status = "failed"
        operation.error_message = stderr
        log.error("cleanup.filter_repo.strip_by_pattern_failed", stderr=stderr)
        return CleanupResult(success=False, dry_run=False, operation=operation)

    @staticmethod
    def _git_dir(repo_path: Path) -> Path:
        """Return the repository metadata directory for bare and standard clones."""
        dot_git = repo_path / ".git"
        return dot_git if dot_git.is_dir() else repo_path

    def _parse_analyze_report(self, repo_path: Path) -> list[str]:
        """Parse filter-repo analyze output into user-facing warnings."""
        git_dir = self._git_dir(repo_path)
        blob_report = git_dir / "filter-repo" / "analysis" / "blob-shas-and-paths.txt"
        if not blob_report.exists():
            return []
        return [f"Analyze report:\n{blob_report.read_text()[:2000]}"]

    def _save_object_map(self, repo_path: Path) -> Path | None:
        """Persist the filter-repo commit map for later SHA traceability."""
        git_dir = self._git_dir(repo_path)
        commit_map_file = git_dir / "filter-repo" / "commit-map"
        if not commit_map_file.exists():
            logger.warning("cleanup.filter_repo.no_commit_map", path=str(commit_map_file))
            return None

        output_dir = Path(".bb2gh") / "cleanup" / repo_path.name
        output_dir.mkdir(parents=True, exist_ok=True)
        output_path = output_dir / "object-map.csv"
        output_path.write_text(commit_map_file.read_text())
        logger.info("cleanup.filter_repo.object_map_saved", path=str(output_path))
        return output_path
