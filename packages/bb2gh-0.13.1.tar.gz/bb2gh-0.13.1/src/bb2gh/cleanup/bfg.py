"""BFG Repo-Cleaner engine stub."""

from __future__ import annotations

import shutil
from typing import TYPE_CHECKING

from bb2gh.cleanup.engine import CleanupEngine
from bb2gh.cleanup.models import CleanupCapability, CleanupResult, EngineInfo

if TYPE_CHECKING:
    from pathlib import Path

    from bb2gh.services.git import ProgressCallback

BFG_CAPABILITIES: set[CleanupCapability] = {
    CleanupCapability.STRIP_BY_SIZE,
    CleanupCapability.STRIP_BY_PATTERN,
    CleanupCapability.REPLACE_TEXT,
}


def _detect_bfg_jar() -> bool:
    """Check whether a BFG executable is available."""
    return shutil.which("bfg") is not None


class BFGEngine(CleanupEngine):
    """BFG Repo-Cleaner engine via subprocess.

    This is an interface-only stub. Full BFG integration lands later.
    """

    async def get_info(self) -> EngineInfo:
        """Return BFG availability and capability metadata."""
        java_available = shutil.which("java") is not None
        bfg_available = _detect_bfg_jar() if java_available else False

        if not java_available:
            return EngineInfo(
                name="bfg",
                version=None,
                capabilities=set(),
                available=False,
                unavailable_reason="Java 11+ not found. Install Java to use BFG.",
            )

        if not bfg_available:
            return EngineInfo(
                name="bfg",
                version=None,
                capabilities=set(),
                available=False,
                unavailable_reason=(
                    "BFG Repo-Cleaner not found. "
                    "Download from https://rtyley.github.io/bfg-repo-cleaner/"
                ),
            )

        return EngineInfo(
            name="bfg",
            version=None,
            capabilities=BFG_CAPABILITIES,
            available=True,
        )

    async def strip_large_files(
        self,
        repo_path: Path,
        threshold_bytes: int,
        *,
        dry_run: bool = True,
        progress_callback: ProgressCallback | None = None,
    ) -> CleanupResult:
        """Stub out BFG size-based cleanup until the full implementation exists."""
        raise NotImplementedError("BFG engine not yet implemented")

    async def strip_by_pattern(
        self,
        repo_path: Path,
        patterns: list[str],
        *,
        dry_run: bool = True,
        progress_callback: ProgressCallback | None = None,
    ) -> CleanupResult:
        """Stub out BFG pattern-based cleanup until the full implementation exists."""
        raise NotImplementedError("BFG engine not yet implemented")
