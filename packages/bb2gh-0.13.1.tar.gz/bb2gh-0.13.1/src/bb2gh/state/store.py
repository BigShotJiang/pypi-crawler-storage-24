"""SQLite state store for migration tracking.

Provides async SQLite-based storage for migration state with
concurrent access support using aiosqlite.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import aiosqlite
import structlog

from bb2gh.cleanup.models import CleanupOperation
from bb2gh.models.state import (
    MigrationRecord,
    MigrationRunStatus,
    RepositoryState,
    RepositoryStatus,
)

logger = structlog.get_logger(__name__)

# SQL for creating tables
CREATE_MIGRATIONS_TABLE = """
CREATE TABLE IF NOT EXISTS migrations (
    migration_id TEXT PRIMARY KEY,
    plan_file TEXT NOT NULL,
    source_workspace TEXT NOT NULL,
    target_org TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    total_repos INTEGER NOT NULL DEFAULT 0,
    completed_repos INTEGER NOT NULL DEFAULT 0,
    failed_repos INTEGER NOT NULL DEFAULT 0,
    skipped_repos INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    started_at TEXT,
    completed_at TEXT,
    error_message TEXT
)
"""

CREATE_REPOSITORIES_TABLE = """
CREATE TABLE IF NOT EXISTS repositories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    migration_id TEXT NOT NULL,
    source_id TEXT NOT NULL,
    source_name TEXT NOT NULL,
    source_full_name TEXT NOT NULL,
    target_full_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    started_at TEXT,
    completed_at TEXT,
    error_message TEXT,
    error_traceback TEXT,
    retry_count INTEGER NOT NULL DEFAULT 0,
    metadata TEXT,
    FOREIGN KEY (migration_id) REFERENCES migrations(migration_id),
    UNIQUE (migration_id, source_id)
)
"""

CREATE_INDEX_MIGRATION_ID = """
CREATE INDEX IF NOT EXISTS idx_repositories_migration_id
ON repositories(migration_id)
"""

CREATE_INDEX_STATUS = """
CREATE INDEX IF NOT EXISTS idx_repositories_status
ON repositories(migration_id, status)
"""

# PR migration state tables
CREATE_PR_MIGRATIONS_TABLE = """
CREATE TABLE IF NOT EXISTS pr_migrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    migration_id TEXT NOT NULL,
    source_repo TEXT NOT NULL,
    target_repo TEXT NOT NULL,
    source_pr_id TEXT NOT NULL,
    source_pr_url TEXT,
    target_pr_number INTEGER,
    target_pr_url TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    pr_state TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT,
    error_message TEXT,
    author_mapped INTEGER DEFAULT 0,
    author_username TEXT,
    comments_migrated INTEGER DEFAULT 0,
    comments_failed INTEGER DEFAULT 0,
    FOREIGN KEY (migration_id) REFERENCES migrations(migration_id),
    UNIQUE (migration_id, source_repo, source_pr_id)
)
"""

CREATE_INDEX_PR_MIGRATIONS = """
CREATE INDEX IF NOT EXISTS idx_pr_migrations_repo
ON pr_migrations(migration_id, source_repo)
"""

# Branch protection migration tables
CREATE_BRANCH_PROTECTION_MIGRATIONS_TABLE = """
CREATE TABLE IF NOT EXISTS branch_protection_migrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    migration_id TEXT NOT NULL,
    source_repo TEXT NOT NULL,
    target_repo TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    plan_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT,
    error_message TEXT,
    FOREIGN KEY (migration_id) REFERENCES migrations(migration_id),
    UNIQUE (migration_id, source_repo)
)
"""

CREATE_RULESETS_CREATED_TABLE = """
CREATE TABLE IF NOT EXISTS rulesets_created (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    migration_id TEXT NOT NULL,
    source_repo TEXT NOT NULL,
    target_repo TEXT NOT NULL,
    ruleset_id INTEGER NOT NULL,
    ruleset_name TEXT NOT NULL,
    scope TEXT NOT NULL DEFAULT 'repository',
    target TEXT NOT NULL DEFAULT 'branch',
    enforcement TEXT NOT NULL DEFAULT 'evaluate',
    created_at TEXT NOT NULL,
    FOREIGN KEY (migration_id) REFERENCES migrations(migration_id)
)
"""

CREATE_INDEX_BP_MIGRATIONS = """
CREATE INDEX IF NOT EXISTS idx_bp_migrations_repo
ON branch_protection_migrations(migration_id, source_repo)
"""

CREATE_INDEX_RULESETS_CREATED = """
CREATE INDEX IF NOT EXISTS idx_rulesets_created_migration
ON rulesets_created(migration_id, source_repo)
"""

CREATE_CLEANUP_OPERATIONS_TABLE = """
CREATE TABLE IF NOT EXISTS cleanup_operations (
    id TEXT PRIMARY KEY,
    repo_name TEXT NOT NULL,
    engine_used TEXT NOT NULL,
    strategy TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    backup_path TEXT,
    object_map_path TEXT,
    blobs_removed INTEGER NOT NULL DEFAULT 0,
    blobs_converted_to_lfs INTEGER NOT NULL DEFAULT 0,
    bytes_freed INTEGER NOT NULL DEFAULT 0,
    branches_rewritten INTEGER NOT NULL DEFAULT 0,
    tags_rewritten INTEGER NOT NULL DEFAULT 0,
    started_at TEXT,
    completed_at TEXT,
    error_message TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at TEXT NOT NULL DEFAULT (datetime('now'))
)
"""

CREATE_INDEX_CLEANUP_REPO = """
CREATE INDEX IF NOT EXISTS idx_cleanup_operations_repo
ON cleanup_operations(repo_name, updated_at)
"""


class StateStore:
    """SQLite state store for migration tracking.

    Provides async context manager interface for safe database access
    with concurrent write support.

    Usage:
        async with StateStore("/path/to/state.db") as store:
            migration = await store.create_migration(...)
            await store.add_repository(...)
    """

    def __init__(self, db_path: Path | str) -> None:
        """Initialize the state store.

        Args:
            db_path: Path to the SQLite database file.
        """
        self._db_path = Path(db_path)
        self._db: aiosqlite.Connection | None = None

    async def __aenter__(self) -> StateStore:
        """Async context manager entry."""
        await self._connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        """Async context manager exit."""
        await self._disconnect()

    async def _connect(self) -> None:
        """Connect to the database and initialize tables."""
        # Ensure parent directory exists
        self._db_path.parent.mkdir(parents=True, exist_ok=True)

        self._db = await aiosqlite.connect(self._db_path)
        # Enable WAL mode for better concurrent access
        await self._db.execute("PRAGMA journal_mode=WAL")
        # Enable foreign keys
        await self._db.execute("PRAGMA foreign_keys=ON")

        # Create tables
        await self._db.execute(CREATE_MIGRATIONS_TABLE)
        await self._db.execute(CREATE_REPOSITORIES_TABLE)
        await self._db.execute(CREATE_INDEX_MIGRATION_ID)
        await self._db.execute(CREATE_INDEX_STATUS)
        await self._db.execute(CREATE_PR_MIGRATIONS_TABLE)
        await self._db.execute(CREATE_INDEX_PR_MIGRATIONS)
        await self._db.execute(CREATE_BRANCH_PROTECTION_MIGRATIONS_TABLE)
        await self._db.execute(CREATE_RULESETS_CREATED_TABLE)
        await self._db.execute(CREATE_INDEX_BP_MIGRATIONS)
        await self._db.execute(CREATE_INDEX_RULESETS_CREATED)
        await self._db.execute(CREATE_CLEANUP_OPERATIONS_TABLE)
        await self._db.execute(CREATE_INDEX_CLEANUP_REPO)
        await self._db.commit()

        logger.debug("state_store_connected", db_path=str(self._db_path))

    async def _disconnect(self) -> None:
        """Disconnect from the database."""
        if self._db:
            await self._db.close()
            self._db = None
            logger.debug("state_store_disconnected")

    def _ensure_connected(self) -> aiosqlite.Connection:
        """Ensure we have an active database connection."""
        if self._db is None:
            raise RuntimeError("StateStore is not connected. Use 'async with StateStore(...)'")
        return self._db

    # Migration operations

    async def create_migration(
        self,
        *,
        plan_file: str,
        source_workspace: str,
        target_org: str,
        migration_id: str | None = None,
    ) -> MigrationRecord:
        """Create a new migration run.

        Args:
            plan_file: Path to the migration plan file.
            source_workspace: Source Bitbucket workspace.
            target_org: Target GitHub organization.
            migration_id: Optional migration ID. If not provided, one will be generated.

        Returns:
            The created MigrationRecord.
        """
        db = self._ensure_connected()

        if migration_id is None:
            migration_id = f"mig_{uuid.uuid4().hex[:12]}"
        now = datetime.now(UTC).isoformat()

        await db.execute(
            """
            INSERT INTO migrations (
                migration_id, plan_file, source_workspace, target_org,
                status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (migration_id, plan_file, source_workspace, target_org, "pending", now, now),
        )
        await db.commit()

        logger.info(
            "migration_created",
            migration_id=migration_id,
            plan_file=plan_file,
        )

        return MigrationRecord(
            migration_id=migration_id,
            plan_file=plan_file,
            source_workspace=source_workspace,
            target_org=target_org,
            status=MigrationRunStatus.PENDING,
            created_at=datetime.fromisoformat(now),
            updated_at=datetime.fromisoformat(now),
        )

    async def get_migration(self, migration_id: str) -> MigrationRecord | None:
        """Get a migration by ID.

        Args:
            migration_id: The migration ID.

        Returns:
            The MigrationRecord or None if not found.
        """
        db = self._ensure_connected()

        async with db.execute(
            "SELECT * FROM migrations WHERE migration_id = ?",
            (migration_id,),
        ) as cursor:
            row = await cursor.fetchone()
            description = cursor.description

        if row is None or description is None:
            return None

        return self._row_to_migration(tuple(row), description)

    async def get_latest_migration(self, plan_file: str) -> MigrationRecord | None:
        """Get the latest migration for a plan file.

        Args:
            plan_file: Path to the migration plan file.

        Returns:
            The latest MigrationRecord or None if not found.
        """
        db = self._ensure_connected()

        async with db.execute(
            """
            SELECT * FROM migrations
            WHERE plan_file = ?
            ORDER BY created_at DESC
            LIMIT 1
            """,
            (plan_file,),
        ) as cursor:
            row = await cursor.fetchone()
            description = cursor.description

        if row is None or description is None:
            return None

        return self._row_to_migration(tuple(row), description)

    async def list_migrations(
        self,
        *,
        limit: int = 20,
        plan_file: str | None = None,
    ) -> list[MigrationRecord]:
        """List all migrations, optionally filtered by plan file.

        Args:
            limit: Maximum number of migrations to return.
            plan_file: Optional plan file path to filter by.

        Returns:
            List of MigrationRecord objects, most recent first.
        """
        db = self._ensure_connected()

        if plan_file:
            query = """
                SELECT * FROM migrations
                WHERE plan_file = ?
                ORDER BY created_at DESC
                LIMIT ?
            """
            params: tuple[Any, ...] = (plan_file, limit)
        else:
            query = """
                SELECT * FROM migrations
                ORDER BY created_at DESC
                LIMIT ?
            """
            params = (limit,)

        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            description = cursor.description

        assert description is not None
        return [self._row_to_migration(tuple(row), description) for row in rows]

    async def update_migration_status(
        self,
        migration_id: str,
        *,
        status: MigrationRunStatus,
        error_message: str | None = None,
    ) -> None:
        """Update migration status.

        Args:
            migration_id: The migration ID.
            status: New status.
            error_message: Optional error message.
        """
        db = self._ensure_connected()

        now = datetime.now(UTC).isoformat()
        completed_at = (
            now if status in (MigrationRunStatus.COMPLETED, MigrationRunStatus.FAILED) else None
        )
        started_at = now if status == MigrationRunStatus.IN_PROGRESS else None

        if started_at:
            await db.execute(
                """
                UPDATE migrations
                SET status = ?, updated_at = ?, started_at = COALESCE(started_at, ?), error_message = ?
                WHERE migration_id = ?
                """,
                (status.value, now, started_at, error_message, migration_id),
            )
        elif completed_at:
            await db.execute(
                """
                UPDATE migrations
                SET status = ?, updated_at = ?, completed_at = ?, error_message = ?
                WHERE migration_id = ?
                """,
                (status.value, now, completed_at, error_message, migration_id),
            )
        else:
            await db.execute(
                """
                UPDATE migrations
                SET status = ?, updated_at = ?, error_message = ?
                WHERE migration_id = ?
                """,
                (status.value, now, error_message, migration_id),
            )

        await db.commit()

        logger.debug(
            "migration_status_updated",
            migration_id=migration_id,
            status=status.value,
        )

    def _row_to_migration(
        self, row: tuple[Any, ...], description: tuple[Any, ...]
    ) -> MigrationRecord:
        """Convert a database row to MigrationRecord."""
        col_names = [col[0] for col in description]
        data = dict(zip(col_names, row, strict=True))

        return MigrationRecord(
            migration_id=data["migration_id"],
            plan_file=data["plan_file"],
            source_workspace=data["source_workspace"],
            target_org=data["target_org"],
            status=MigrationRunStatus(data["status"]),
            total_repos=data["total_repos"],
            completed_repos=data["completed_repos"],
            failed_repos=data["failed_repos"],
            skipped_repos=data["skipped_repos"],
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
            started_at=datetime.fromisoformat(data["started_at"]) if data["started_at"] else None,
            completed_at=datetime.fromisoformat(data["completed_at"])
            if data["completed_at"]
            else None,
            error_message=data["error_message"],
        )

    # Repository operations

    async def add_repository(
        self,
        *,
        migration_id: str,
        source_id: str,
        source_name: str,
        source_full_name: str,
        target_full_name: str,
    ) -> RepositoryState:
        """Add a repository to a migration.

        Args:
            migration_id: The migration ID.
            source_id: Source repository UUID.
            source_name: Source repository name.
            source_full_name: Full source path.
            target_full_name: Full target path.

        Returns:
            The created RepositoryState.
        """
        db = self._ensure_connected()

        now = datetime.now(UTC).isoformat()

        await db.execute(
            """
            INSERT INTO repositories (
                migration_id, source_id, source_name, source_full_name, target_full_name,
                status, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                migration_id,
                source_id,
                source_name,
                source_full_name,
                target_full_name,
                "pending",
                now,
                now,
            ),
        )
        await db.commit()

        logger.debug(
            "repository_added",
            migration_id=migration_id,
            source_id=source_id,
        )

        return RepositoryState(
            source_id=source_id,
            source_name=source_name,
            source_full_name=source_full_name,
            target_full_name=target_full_name,
            status=RepositoryStatus.PENDING,
            created_at=datetime.fromisoformat(now),
            updated_at=datetime.fromisoformat(now),
        )

    async def get_repository(
        self,
        migration_id: str,
        source_id: str,
    ) -> RepositoryState | None:
        """Get a repository state.

        Args:
            migration_id: The migration ID.
            source_id: Source repository UUID.

        Returns:
            The RepositoryState or None if not found.
        """
        db = self._ensure_connected()

        async with db.execute(
            """
            SELECT * FROM repositories
            WHERE migration_id = ? AND source_id = ?
            """,
            (migration_id, source_id),
        ) as cursor:
            row = await cursor.fetchone()
            description = cursor.description

        if row is None or description is None:
            return None

        return self._row_to_repository(tuple(row), description)

    async def update_repository_status(
        self,
        migration_id: str,
        source_id: str,
        status: RepositoryStatus,
        *,
        error_message: str | None = None,
        error_traceback: str | None = None,
    ) -> None:
        """Update repository status.

        Args:
            migration_id: The migration ID.
            source_id: Source repository UUID.
            status: New status.
            error_message: Optional error message.
            error_traceback: Optional error traceback.
        """
        db = self._ensure_connected()

        now = datetime.now(UTC).isoformat()

        # Determine timestamp updates based on status
        if status == RepositoryStatus.IN_PROGRESS:
            await db.execute(
                """
                UPDATE repositories
                SET status = ?, updated_at = ?, started_at = COALESCE(started_at, ?)
                WHERE migration_id = ? AND source_id = ?
                """,
                (status.value, now, now, migration_id, source_id),
            )
        elif status == RepositoryStatus.COMPLETED:
            await db.execute(
                """
                UPDATE repositories
                SET status = ?, updated_at = ?, completed_at = ?
                WHERE migration_id = ? AND source_id = ?
                """,
                (status.value, now, now, migration_id, source_id),
            )
        elif status == RepositoryStatus.FAILED:
            # Increment retry count on failure
            await db.execute(
                """
                UPDATE repositories
                SET status = ?, updated_at = ?, error_message = ?,
                    error_traceback = ?, retry_count = retry_count + 1
                WHERE migration_id = ? AND source_id = ?
                """,
                (status.value, now, error_message, error_traceback, migration_id, source_id),
            )
        else:
            await db.execute(
                """
                UPDATE repositories
                SET status = ?, updated_at = ?
                WHERE migration_id = ? AND source_id = ?
                """,
                (status.value, now, migration_id, source_id),
            )

        await db.commit()

        logger.debug(
            "repository_status_updated",
            migration_id=migration_id,
            source_id=source_id,
            status=status.value,
        )

    async def list_repositories(
        self,
        migration_id: str,
        *,
        status: RepositoryStatus | None = None,
    ) -> list[RepositoryState]:
        """List repositories in a migration.

        Args:
            migration_id: The migration ID.
            status: Optional status filter.

        Returns:
            List of RepositoryState objects.
        """
        db = self._ensure_connected()

        if status is not None:
            query = """
                SELECT * FROM repositories
                WHERE migration_id = ? AND status = ?
                ORDER BY created_at
            """
            repo_params: tuple[Any, ...] = (migration_id, status.value)
        else:
            query = """
                SELECT * FROM repositories
                WHERE migration_id = ?
                ORDER BY created_at
            """
            repo_params = (migration_id,)

        async with db.execute(query, repo_params) as cursor:
            rows = await cursor.fetchall()
            description = cursor.description

        assert description is not None
        return [self._row_to_repository(tuple(row), description) for row in rows]

    async def get_migration_progress(
        self,
        migration_id: str,
    ) -> dict[str, int]:
        """Get migration progress summary.

        Args:
            migration_id: The migration ID.

        Returns:
            Dictionary with progress counts.
        """
        db = self._ensure_connected()

        async with db.execute(
            """
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(CASE WHEN status = 'skipped' THEN 1 ELSE 0 END) as skipped
            FROM repositories
            WHERE migration_id = ?
            """,
            (migration_id,),
        ) as cursor:
            row = await cursor.fetchone()

        assert row is not None
        return {
            "total": row[0] or 0,
            "completed": row[1] or 0,
            "failed": row[2] or 0,
            "in_progress": row[3] or 0,
            "pending": row[4] or 0,
            "skipped": row[5] or 0,
        }

    def _row_to_repository(
        self, row: tuple[Any, ...], description: tuple[Any, ...]
    ) -> RepositoryState:
        """Convert a database row to RepositoryState."""
        col_names = [col[0] for col in description]
        data = dict(zip(col_names, row, strict=True))

        return RepositoryState(
            source_id=data["source_id"],
            source_name=data["source_name"],
            source_full_name=data["source_full_name"],
            target_full_name=data["target_full_name"],
            status=RepositoryStatus(data["status"]),
            created_at=datetime.fromisoformat(data["created_at"]),
            updated_at=datetime.fromisoformat(data["updated_at"]),
            started_at=datetime.fromisoformat(data["started_at"]) if data["started_at"] else None,
            completed_at=datetime.fromisoformat(data["completed_at"])
            if data["completed_at"]
            else None,
            error_message=data["error_message"],
            error_traceback=data["error_traceback"],
            retry_count=data["retry_count"],
        )

    # Cleanup operations

    async def record_cleanup_operation(self, operation: CleanupOperation) -> None:
        """Insert or update a cleanup operation record."""
        db = self._ensure_connected()
        now = datetime.now(UTC).isoformat()

        await db.execute(
            """
            INSERT INTO cleanup_operations (
                id, repo_name, engine_used, strategy, status,
                backup_path, object_map_path, blobs_removed, blobs_converted_to_lfs,
                bytes_freed, branches_rewritten, tags_rewritten,
                started_at, completed_at, error_message, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET
                repo_name = excluded.repo_name,
                engine_used = excluded.engine_used,
                strategy = excluded.strategy,
                status = excluded.status,
                backup_path = excluded.backup_path,
                object_map_path = excluded.object_map_path,
                blobs_removed = excluded.blobs_removed,
                blobs_converted_to_lfs = excluded.blobs_converted_to_lfs,
                bytes_freed = excluded.bytes_freed,
                branches_rewritten = excluded.branches_rewritten,
                tags_rewritten = excluded.tags_rewritten,
                started_at = excluded.started_at,
                completed_at = excluded.completed_at,
                error_message = excluded.error_message,
                updated_at = excluded.updated_at
            """,
            (
                operation.id,
                operation.repo_name,
                operation.engine_used,
                operation.strategy,
                operation.status,
                str(operation.backup_path) if operation.backup_path is not None else None,
                str(operation.object_map_path) if operation.object_map_path is not None else None,
                operation.blobs_removed,
                operation.blobs_converted_to_lfs,
                operation.bytes_freed,
                operation.branches_rewritten,
                operation.tags_rewritten,
                operation.started_at.isoformat() if operation.started_at is not None else None,
                operation.completed_at.isoformat() if operation.completed_at is not None else None,
                operation.error_message,
                now,
                now,
            ),
        )
        await db.commit()

    async def get_cleanup_operation(self, operation_id: str) -> CleanupOperation | None:
        """Retrieve a cleanup operation by ID."""
        db = self._ensure_connected()

        async with db.execute(
            "SELECT * FROM cleanup_operations WHERE id = ?",
            (operation_id,),
        ) as cursor:
            row = await cursor.fetchone()
            description = cursor.description

        if row is None or description is None:
            return None
        return self._row_to_cleanup_operation(tuple(row), description)

    async def list_cleanup_operations(
        self,
        repo_name: str | None = None,
    ) -> list[CleanupOperation]:
        """List cleanup operations, optionally filtered by repository name."""
        db = self._ensure_connected()

        if repo_name is None:
            query = "SELECT * FROM cleanup_operations ORDER BY updated_at DESC"
            params: tuple[Any, ...] = ()
        else:
            query = """
                SELECT * FROM cleanup_operations
                WHERE repo_name = ?
                ORDER BY updated_at DESC
            """
            params = (repo_name,)

        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            description = cursor.description

        assert description is not None
        return [self._row_to_cleanup_operation(tuple(row), description) for row in rows]

    def _row_to_cleanup_operation(
        self,
        row: tuple[Any, ...],
        description: tuple[Any, ...],
    ) -> CleanupOperation:
        """Convert a database row to CleanupOperation."""
        col_names = [col[0] for col in description]
        data = dict(zip(col_names, row, strict=True))

        return CleanupOperation(
            id=data["id"],
            repo_name=data["repo_name"],
            engine_used=data["engine_used"],
            strategy=data["strategy"],
            status=data["status"],
            backup_path=Path(data["backup_path"]) if data["backup_path"] else None,
            object_map_path=Path(data["object_map_path"]) if data["object_map_path"] else None,
            blobs_removed=data["blobs_removed"],
            blobs_converted_to_lfs=data["blobs_converted_to_lfs"],
            bytes_freed=data["bytes_freed"],
            branches_rewritten=data["branches_rewritten"],
            tags_rewritten=data["tags_rewritten"],
            started_at=datetime.fromisoformat(data["started_at"]) if data["started_at"] else None,
            completed_at=(
                datetime.fromisoformat(data["completed_at"]) if data["completed_at"] else None
            ),
            error_message=data["error_message"],
        )

    # PR migration operations

    async def add_pr_migration(
        self,
        *,
        migration_id: str,
        source_repo: str,
        target_repo: str,
        source_pr_id: str,
        source_pr_url: str | None = None,
        pr_state: str | None = None,
    ) -> dict[str, str]:
        """Add a PR to migration tracking.

        Args:
            migration_id: The migration ID.
            source_repo: Source repository (workspace/repo).
            target_repo: Target repository (org/repo).
            source_pr_id: Source PR ID.
            source_pr_url: Source PR URL.
            pr_state: Original PR state (open, merged, etc).

        Returns:
            Dict with PR migration state.
        """
        db = self._ensure_connected()

        now = datetime.now(UTC).isoformat()

        try:
            await db.execute(
                """
                INSERT INTO pr_migrations (
                    migration_id, source_repo, target_repo, source_pr_id,
                    source_pr_url, pr_state, status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    migration_id,
                    source_repo,
                    target_repo,
                    source_pr_id,
                    source_pr_url,
                    pr_state,
                    "pending",
                    now,
                    now,
                ),
            )
            await db.commit()
        except aiosqlite.IntegrityError:
            # Already exists, that's OK
            pass

        logger.debug(
            "pr_migration_added",
            migration_id=migration_id,
            source_pr=source_pr_id,
        )

        return {
            "migration_id": migration_id,
            "source_repo": source_repo,
            "source_pr_id": source_pr_id,
            "status": "pending",
        }

    async def update_pr_migration_status(
        self,
        migration_id: str,
        source_repo: str,
        source_pr_id: str,
        *,
        status: str,
        target_pr_number: int | None = None,
        target_pr_url: str | None = None,
        error_message: str | None = None,
        author_mapped: bool = False,
        author_username: str | None = None,
        comments_migrated: int = 0,
        comments_failed: int = 0,
    ) -> None:
        """Update PR migration status.

        Args:
            migration_id: The migration ID.
            source_repo: Source repository.
            source_pr_id: Source PR ID.
            status: New status (pending, in_progress, completed, failed).
            target_pr_number: GitHub PR number.
            target_pr_url: GitHub PR URL.
            error_message: Error message if failed.
            author_mapped: Whether author was mapped.
            author_username: Mapped author username.
            comments_migrated: Number of comments migrated.
            comments_failed: Number of comments failed.
        """
        db = self._ensure_connected()

        now = datetime.now(UTC).isoformat()
        completed_at = now if status in ("completed", "failed") else None

        await db.execute(
            """
            UPDATE pr_migrations
            SET status = ?, updated_at = ?, completed_at = ?,
                target_pr_number = COALESCE(?, target_pr_number),
                target_pr_url = COALESCE(?, target_pr_url),
                error_message = ?,
                author_mapped = ?,
                author_username = COALESCE(?, author_username),
                comments_migrated = comments_migrated + ?,
                comments_failed = comments_failed + ?
            WHERE migration_id = ? AND source_repo = ? AND source_pr_id = ?
            """,
            (
                status,
                now,
                completed_at,
                target_pr_number,
                target_pr_url,
                error_message,
                1 if author_mapped else 0,
                author_username,
                comments_migrated,
                comments_failed,
                migration_id,
                source_repo,
                source_pr_id,
            ),
        )
        await db.commit()

        logger.debug(
            "pr_migration_updated",
            migration_id=migration_id,
            source_pr=source_pr_id,
            status=status,
        )

    async def get_pr_migration(
        self,
        migration_id: str,
        source_repo: str,
        source_pr_id: str,
    ) -> dict[str, Any] | None:
        """Get PR migration state.

        Args:
            migration_id: The migration ID.
            source_repo: Source repository.
            source_pr_id: Source PR ID.

        Returns:
            Dict with PR state or None if not found.
        """
        db = self._ensure_connected()

        async with db.execute(
            """
            SELECT * FROM pr_migrations
            WHERE migration_id = ? AND source_repo = ? AND source_pr_id = ?
            """,
            (migration_id, source_repo, source_pr_id),
        ) as cursor:
            row = await cursor.fetchone()
            if row is None:
                return None
            description = cursor.description

        assert description is not None
        col_names = [col[0] for col in description]
        return dict(zip(col_names, row, strict=True))

    async def list_pr_migrations(
        self,
        migration_id: str,
        source_repo: str | None = None,
        *,
        status: str | None = None,
    ) -> list[dict[str, Any]]:
        """List PR migrations.

        Args:
            migration_id: The migration ID.
            source_repo: Optional source repository filter.
            status: Optional status filter.

        Returns:
            List of PR migration dicts.
        """
        db = self._ensure_connected()

        query = "SELECT * FROM pr_migrations WHERE migration_id = ?"
        params: list[str] = [migration_id]

        if source_repo:
            query += " AND source_repo = ?"
            params.append(source_repo)

        if status:
            query += " AND status = ?"
            params.append(status)

        query += " ORDER BY created_at"

        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            description = cursor.description

        assert description is not None
        col_names = [col[0] for col in description]
        return [dict(zip(col_names, row, strict=True)) for row in rows]

    async def get_pr_migration_progress(
        self,
        migration_id: str,
        source_repo: str | None = None,
    ) -> dict[str, int]:
        """Get PR migration progress summary.

        Args:
            migration_id: The migration ID.
            source_repo: Optional source repository filter.

        Returns:
            Dictionary with progress counts.
        """
        db = self._ensure_connected()

        query = """
            SELECT
                COUNT(*) as total,
                SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
                SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress,
                SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
                SUM(comments_migrated) as comments_migrated,
                SUM(comments_failed) as comments_failed
            FROM pr_migrations
            WHERE migration_id = ?
        """
        pr_params: list[str] = [migration_id]

        if source_repo:
            query = query.replace(
                "WHERE migration_id = ?", "WHERE migration_id = ? AND source_repo = ?"
            )
            pr_params.append(source_repo)

        async with db.execute(query, pr_params) as cursor:
            row = await cursor.fetchone()

        assert row is not None
        return {
            "total": row[0] or 0,
            "completed": row[1] or 0,
            "failed": row[2] or 0,
            "in_progress": row[3] or 0,
            "pending": row[4] or 0,
            "comments_migrated": row[5] or 0,
            "comments_failed": row[6] or 0,
        }

    async def reset_failed_pr_migrations(
        self,
        migration_id: str,
        source_repo: str | None = None,
    ) -> int:
        """Reset failed PR migrations to pending for retry.

        Args:
            migration_id: The migration ID.
            source_repo: Optional source repository filter.

        Returns:
            Number of PRs reset.
        """
        db = self._ensure_connected()

        now = datetime.now(UTC).isoformat()

        if source_repo:
            result = await db.execute(
                """
                UPDATE pr_migrations
                SET status = 'pending', updated_at = ?, error_message = NULL
                WHERE migration_id = ? AND source_repo = ? AND status = 'failed'
                """,
                (now, migration_id, source_repo),
            )
        else:
            result = await db.execute(
                """
                UPDATE pr_migrations
                SET status = 'pending', updated_at = ?, error_message = NULL
                WHERE migration_id = ? AND status = 'failed'
                """,
                (now, migration_id),
            )

        await db.commit()
        return result.rowcount

    # Branch protection operations

    async def save_branch_protection_plan(
        self,
        *,
        migration_id: str,
        source_repo: str,
        target_repo: str,
        plan_json: str,
    ) -> None:
        """Save a branch protection migration plan.

        Args:
            migration_id: The migration ID.
            source_repo: Source BB repo.
            target_repo: Target GH repo.
            plan_json: Serialized plan JSON.
        """
        db = self._ensure_connected()
        now = datetime.now(UTC).isoformat()

        try:
            await db.execute(
                """
                INSERT INTO branch_protection_migrations (
                    migration_id, source_repo, target_repo, plan_json,
                    status, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (migration_id, source_repo, target_repo, plan_json, "pending", now, now),
            )
        except aiosqlite.IntegrityError:
            # Update existing
            await db.execute(
                """
                UPDATE branch_protection_migrations
                SET plan_json = ?, status = 'pending', updated_at = ?
                WHERE migration_id = ? AND source_repo = ?
                """,
                (plan_json, now, migration_id, source_repo),
            )
        await db.commit()

    async def get_branch_protection_plan(
        self,
        migration_id: str,
        source_repo: str,
    ) -> dict[str, Any] | None:
        """Get a saved branch protection plan.

        Args:
            migration_id: The migration ID.
            source_repo: Source BB repo.

        Returns:
            Dict with plan data or None.
        """
        db = self._ensure_connected()

        async with db.execute(
            """
            SELECT * FROM branch_protection_migrations
            WHERE migration_id = ? AND source_repo = ?
            """,
            (migration_id, source_repo),
        ) as cursor:
            row = await cursor.fetchone()
            if row is None:
                return None
            description = cursor.description

        assert description is not None
        col_names = [col[0] for col in description]
        return dict(zip(col_names, row, strict=True))

    async def save_created_ruleset(
        self,
        *,
        migration_id: str,
        source_repo: str,
        target_repo: str,
        ruleset_id: int,
        ruleset_name: str,
        scope: str = "repository",
        target: str = "branch",
        enforcement: str = "evaluate",
    ) -> None:
        """Record a created ruleset for tracking and rollback.

        Args:
            migration_id: The migration ID.
            source_repo: Source BB repo.
            target_repo: Target GH repo.
            ruleset_id: GitHub ruleset ID.
            ruleset_name: Ruleset name.
            scope: repository or organization.
            target: branch or tag.
            enforcement: evaluate, active, or disabled.
        """
        db = self._ensure_connected()
        now = datetime.now(UTC).isoformat()

        await db.execute(
            """
            INSERT INTO rulesets_created (
                migration_id, source_repo, target_repo,
                ruleset_id, ruleset_name, scope, target, enforcement,
                created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                migration_id,
                source_repo,
                target_repo,
                ruleset_id,
                ruleset_name,
                scope,
                target,
                enforcement,
                now,
            ),
        )
        await db.commit()

    async def get_created_rulesets(
        self,
        migration_id: str,
        source_repo: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get all rulesets created during a migration.

        Args:
            migration_id: The migration ID.
            source_repo: Optional source repo filter.

        Returns:
            List of ruleset records.
        """
        db = self._ensure_connected()

        query = "SELECT * FROM rulesets_created WHERE migration_id = ?"
        params: list[str] = [migration_id]

        if source_repo:
            query += " AND source_repo = ?"
            params.append(source_repo)

        query += " ORDER BY created_at"

        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
            description = cursor.description

        assert description is not None
        col_names = [col[0] for col in description]
        return [dict(zip(col_names, row, strict=True)) for row in rows]

    async def update_branch_protection_status(
        self,
        migration_id: str,
        source_repo: str,
        *,
        status: str,
        error_message: str | None = None,
    ) -> None:
        """Update branch protection migration status.

        Args:
            migration_id: The migration ID.
            source_repo: Source BB repo.
            status: New status (pending, in_progress, completed, failed).
            error_message: Optional error message.
        """
        db = self._ensure_connected()
        now = datetime.now(UTC).isoformat()
        completed_at = now if status in ("completed", "failed") else None

        await db.execute(
            """
            UPDATE branch_protection_migrations
            SET status = ?, updated_at = ?, completed_at = ?, error_message = ?
            WHERE migration_id = ? AND source_repo = ?
            """,
            (status, now, completed_at, error_message, migration_id, source_repo),
        )
        await db.commit()
