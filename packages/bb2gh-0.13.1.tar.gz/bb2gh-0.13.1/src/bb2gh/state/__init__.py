"""State management for bb2gh migrations.

Provides SQLite-based state tracking for migration progress,
checkpoint/resume capability, and error logging.
"""

from bb2gh.state.store import StateStore

__all__ = ["StateStore"]
