"""Licensing decorators for bb2gh.

Provides decorators to gate functions behind license requirements.
"""

from __future__ import annotations

import functools
import inspect
from collections.abc import Callable
from typing import Any, TypeVar

import structlog

from bb2gh.exceptions import BB2GHError, ExitCode, LimitExceededError
from bb2gh.models.license import TIER_FEATURES, Feature, Tier

logger = structlog.get_logger(__name__)

F = TypeVar("F", bound=Callable[..., Any])

# Features that require a paid license (not in free tier)
_PAID_FEATURES: frozenset[Feature] = frozenset(Feature) - TIER_FEATURES[Tier.FREE]


class LicenseRequiredError(BB2GHError):
    """Raised when a paid feature is used without a valid license."""

    def __init__(
        self,
        feature: Feature | None = None,
        message: str | None = None,
    ):
        self.feature = feature
        if message is None:
            if feature is not None:
                message = (
                    f"Feature '{feature.value}' requires Pro or Ultimate tier. "
                    "Contact sales@n8-group.com to upgrade."
                )
            else:
                message = "No license found. Register for a free license: bb2gh license register"
        super().__init__(message, exit_code=ExitCode.USER_ERROR)


def requires_feature(feature: Feature | str) -> Callable[[F], F]:
    """Decorator to gate a function behind a license requirement.

    Args:
        feature: Required feature (Feature enum or string).

    Returns:
        Decorator function.

    Example:
        @requires_feature(Feature.DISTRIBUTED_WORKERS)
        async def scale_workers():
            ...
    """
    # Convert string to Feature enum
    if isinstance(feature, str):
        feature = Feature(feature)

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            _check_license(feature)
            return func(*args, **kwargs)

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            _check_license(feature)
            return await func(*args, **kwargs)

        # Return appropriate wrapper based on function type
        import inspect

        if inspect.iscoroutinefunction(func):
            return async_wrapper  # type: ignore[return-value]
        return sync_wrapper  # type: ignore[return-value]

    return decorator


# Backward compatibility alias
requires_license = requires_feature


def check_limit(limit_name: str, count: int) -> Callable[[F], F]:
    """Decorator to gate a function behind a quantitative license limit.

    Checks that the given count does not exceed the limit for `limit_name`
    from the effective license limits. A limit of 0 means unlimited.

    Args:
        limit_name: Name of the limit to check (e.g., "repos", "workers").
        count: The count to check against the limit.

    Returns:
        Decorator function.

    Raises:
        LimitExceededError: If count exceeds the limit.

    Example:
        @check_limit("repos", repo_count)
        def migrate_repos():
            ...
    """

    def decorator(func: F) -> F:
        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            limits = _get_effective_limits()
            max_limit = limits.get(limit_name, 0)
            if max_limit > 0 and count > max_limit:
                raise LimitExceededError(limit_name, count, max_limit)
            return func(*args, **kwargs)

        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            limits = _get_effective_limits()
            max_limit = limits.get(limit_name, 0)
            if max_limit > 0 and count > max_limit:
                raise LimitExceededError(limit_name, count, max_limit)
            return await func(*args, **kwargs)

        if inspect.iscoroutinefunction(func):
            return async_wrapper  # type: ignore[return-value]
        return sync_wrapper  # type: ignore[return-value]

    return decorator


def _get_effective_limits() -> dict[str, int]:
    """Get the effective quantitative limits based on the current license.

    Thin wrapper around features._get_effective_limits() that adds
    license-status validation (raises LicenseRequiredError for unusable
    statuses).  The canonical limit-resolution logic lives in
    ``bb2gh.licensing.features._get_effective_limits``.

    Returns:
        Dict of limit name to limit value (0 = unlimited).

    Raises:
        LicenseRequiredError: If no license is found.
    """
    from bb2gh.licensing.features import (
        _get_effective_limits as _features_get_effective_limits,
    )
    from bb2gh.licensing.features import ensure_license
    from bb2gh.models.license import LicenseStatus

    license_info = ensure_license()

    if license_info.status not in (LicenseStatus.VALID, LicenseStatus.EXPIRED):
        logger.warning(
            "license_denied",
            status=license_info.status.value,
            action="_get_effective_limits",
        )
        raise LicenseRequiredError(
            message=("No valid license found. Register for a free license: bb2gh license register")
        )

    return _features_get_effective_limits(license_info)


def _check_license(feature: Feature) -> None:
    """Check if feature is licensed and handle gracefully.

    SECURITY: Uses default-deny allowlist — only VALID and EXPIRED pass.
    Any future LicenseStatus value is automatically rejected.

    Args:
        feature: Required feature.

    Raises:
        LicenseRequiredError: If feature is not licensed.
    """
    from bb2gh.licensing.features import ensure_license, is_feature_enabled
    from bb2gh.models.license import LicenseStatus

    # Free-tier features are always allowed if there's a valid or expired license
    if feature not in _PAID_FEATURES:
        license_info = ensure_license()
        if license_info.status not in (LicenseStatus.VALID, LicenseStatus.EXPIRED):
            raise LicenseRequiredError(
                message=(
                    "No valid license found. Register for a free license: bb2gh license register"
                )
            )
        return

    # Paid feature — requires valid + enabled
    if not is_feature_enabled(feature):
        license_info = ensure_license()

        logger.warning(
            "paid_feature_blocked",
            feature=feature.value,
            license_status=license_info.status.value,
        )

        raise LicenseRequiredError(feature=feature)


def get_feature_description(feature: Feature) -> str:
    """Get a user-friendly description of a feature.

    Args:
        feature: Feature to describe.

    Returns:
        Description string.
    """
    descriptions = {
        Feature.DISCOVER: "Discover Bitbucket workspaces and repositories",
        Feature.PLAN: "Generate migration plans",
        Feature.MIGRATE_REPOS: "Migrate repository contents (git history, branches, tags)",
        Feature.MIGRATE_PRS: "Migrate pull requests",
        Feature.MIGRATE_COMMENTS: "Migrate PR comments and reviews",
        Feature.LFS: "Git LFS object migration",
        Feature.ROLLBACK: "Roll back failed migrations",
        Feature.VALIDATE: "Post-migration validation",
        Feature.PARALLEL_WORKERS: "Parallel workers for faster migrations",
        Feature.BATCH_WAVES: "Batch wave execution for phased migrations",
        Feature.SECRETS_MANAGEMENT: "Secrets inventory and migration",
        Feature.DISTRIBUTED_WORKERS: (
            "Redis-based distributed workers for massive scale migrations"
        ),
        Feature.COMPLIANCE_REPORTS: (
            "Professional PDF compliance reports for regulated industries"
        ),
        Feature.CLEANUP_MODULE: "Repository cleanup tools for large files and secrets",
        Feature.INFISICAL: "Infisical integration for secure secrets management",
    }
    return descriptions.get(feature, f"Feature: {feature.value}")


def get_feature_benefits(feature: Feature) -> list[str]:
    """Get list of benefits for a feature.

    Args:
        feature: Feature to get benefits for.

    Returns:
        List of benefit strings.
    """
    benefits: dict[Feature, list[str]] = {
        Feature.PARALLEL_WORKERS: [
            "Run multiple migration workers in parallel",
            "Faster migration of large workspaces",
            "Configurable worker count",
        ],
        Feature.BATCH_WAVES: [
            "Phased migration execution",
            "Risk-based wave ordering",
            "Pause and resume between waves",
        ],
        Feature.SECRETS_MANAGEMENT: [
            "Inventory secrets across repositories",
            "Secure secrets migration",
            "Audit trail for secrets handling",
        ],
        Feature.DISTRIBUTED_WORKERS: [
            "Scale to 10+ worker nodes",
            "Migrate thousands of repos in parallel",
            "Kubernetes and Docker support",
            "Automatic failover and recovery",
        ],
        Feature.COMPLIANCE_REPORTS: [
            "Professional PDF reports for auditors",
            "SOC2/GDPR compliance documentation",
            "Detailed audit trails",
            "Discrepancy analysis",
        ],
        Feature.CLEANUP_MODULE: [
            "Large file detection and removal",
            "Secret scanning before migration",
            "BFG Repo-Cleaner integration",
            "History rewriting tools",
        ],
        Feature.INFISICAL: [
            "Centralized secrets management",
            "Sync secrets through Infisical vault",
            "Full audit trail",
            "GitHub Actions integration",
        ],
    }
    return benefits.get(feature, [f"Access to {feature.value}"])
