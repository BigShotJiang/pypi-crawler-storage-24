"""License key generation and validation for bb2gh.

Uses Ed25519 for cryptographic signing of license payloads.
Key format: BB2GH-1-<base64url-encoded-payload>.<base64url-encoded-signature>
"""

from __future__ import annotations

import base64
import json
from datetime import UTC, datetime

import structlog
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

from bb2gh.models.license import (
    Feature,
    License,
    LicenseInfo,
    LicensePayload,
    LicenseStatus,
    Tier,
)

logger = structlog.get_logger(__name__)

# Version prefix for the license key format
_LICENSE_PREFIX = "BB2GH-1-"


def _b64url_encode(data: bytes) -> str:
    """Base64url-encode bytes without padding.

    Args:
        data: Raw bytes to encode.

    Returns:
        Base64url-encoded string without padding.
    """
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


def _b64url_decode(data: str) -> bytes:
    """Base64url-decode a string, restoring padding as needed.

    Handles input with or without existing = padding.
    """
    data = data.rstrip("=")
    padded = data + "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(padded)


def generate_keypair() -> tuple[bytes, bytes]:
    """Generate a new Ed25519 keypair.

    Returns:
        Tuple of (private_key_pem, public_key_pem).
    """
    private_key = Ed25519PrivateKey.generate()
    public_key = private_key.public_key()

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )

    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    logger.info("keypair_generated")

    return private_pem, public_pem


def sign_license(
    payload: LicensePayload,
    private_key_pem: bytes,
) -> License:
    """Sign a license payload.

    Args:
        payload: License payload to sign.
        private_key_pem: PEM-encoded Ed25519 private key.

    Returns:
        Signed License object with base64url-encoded signature.
    """
    payload = payload.model_copy(deep=True)

    # Set issued time if not set
    if payload.iat is None:
        payload.iat = datetime.now(UTC)

    # Serialize payload for signing (to_canonical_json returns deterministic JSON string)
    payload_bytes = payload.to_canonical_json().encode("utf-8")

    # Load private key and sign
    private_key = serialization.load_pem_private_key(
        private_key_pem,
        password=None,
    )
    if not isinstance(private_key, Ed25519PrivateKey):
        msg = "Expected Ed25519 private key"
        raise TypeError(msg)

    signature = private_key.sign(payload_bytes)
    signature_b64url = _b64url_encode(signature)

    logger.info(
        "license_signed",
        org=payload.org,
        tier=payload.tier.value,
        features=[f.value for f in payload.features],
        exp=payload.exp.isoformat(),
    )

    return License(
        payload=payload,
        signature=signature_b64url,
    )


def encode_license(license: License) -> str:
    """Encode a license to the versioned format string.

    Format: BB2GH-1-<base64url-payload>.<base64url-signature>

    The payload is the canonical JSON of the license payload, base64url-encoded
    without padding. The signature is the raw Ed25519 signature bytes, base64url-encoded
    without padding.

    Args:
        license: License to encode.

    Returns:
        Versioned license string in BB2GH-1- format.
    """
    payload_json = license.payload.to_canonical_json()
    payload_b64url = _b64url_encode(payload_json.encode("utf-8"))
    sig_b64url = license.signature  # Already base64url-encoded from sign_license

    return f"{_LICENSE_PREFIX}{payload_b64url}.{sig_b64url}"


def validate_license(
    license_str: str,
    public_key_pem: bytes,
) -> LicenseInfo:
    """Validate a license string in the BB2GH-1- format.

    Parses the versioned format, verifies the Ed25519 signature using the provided
    public key, and checks expiration.

    Args:
        license_str: License string in BB2GH-1-<payload>.<sig> format.
        public_key_pem: PEM-encoded Ed25519 public key for verification.

    Returns:
        LicenseInfo with validation status.
    """
    # Normalize: strip BOM and whitespace (policies #21, #27)
    license_str = license_str.lstrip("\ufeff").strip()

    # Size cap: reject before any parsing (policy #35)
    from bb2gh.licensing.features import _MAX_LICENSE_LENGTH

    if len(license_str) > _MAX_LICENSE_LENGTH:
        return LicenseInfo(
            status=LicenseStatus.PARSE_ERROR,
            error=(
                f"License string too large ({len(license_str)} bytes, max {_MAX_LICENSE_LENGTH})"
            ),
        )

    try:
        # Check version prefix
        if not license_str.startswith(_LICENSE_PREFIX):
            logger.warning("license_invalid_prefix")
            return LicenseInfo(
                status=LicenseStatus.PARSE_ERROR,
                error="Invalid license format: missing BB2GH-1- prefix",
            )

        # Strip prefix and split on dot
        rest = license_str[len(_LICENSE_PREFIX) :]
        parts = rest.split(".")
        if len(parts) != 2 or not parts[0] or not parts[1]:
            logger.warning("license_invalid_structure")
            return LicenseInfo(
                status=LicenseStatus.PARSE_ERROR,
                error="Invalid license format: expected <payload>.<signature>",
            )

        payload_b64url, sig_b64url = parts

        # Decode payload and signature
        payload_bytes = _b64url_decode(payload_b64url)
        signature_bytes = _b64url_decode(sig_b64url)

        # Parse payload JSON
        payload_json = payload_bytes.decode("utf-8")
        payload_data = json.loads(payload_json)

        # Reconstruct the LicensePayload
        payload = LicensePayload(
            v=payload_data.get("v", 1),
            kid=payload_data["kid"],
            lid=payload_data["lid"],
            tier=Tier(payload_data["tier"]),
            org=payload_data["org"],
            sub=payload_data["sub"],
            features=[Feature(f) for f in payload_data.get("features", [])],
            exp=datetime.fromisoformat(payload_data["exp"]),
            iat=(datetime.fromisoformat(payload_data["iat"]) if payload_data.get("iat") else None),
            limits=payload_data.get("limits", {}),
            metadata=payload_data.get("metadata", {}),
        )

        license = License(
            payload=payload,
            signature=sig_b64url,
        )

        # Verify signature against the canonical JSON bytes
        loaded_public_key = serialization.load_pem_public_key(public_key_pem)
        if not isinstance(loaded_public_key, Ed25519PublicKey):
            msg = "Expected Ed25519 public key"
            raise TypeError(msg)
        loaded_public_key.verify(signature_bytes, payload_bytes)

        # Check expiration
        if license.is_expired:
            logger.warning("license_expired", org=license.org)
            return LicenseInfo(
                status=LicenseStatus.EXPIRED,
                license=license,
            )

        logger.info(
            "license_valid",
            org=license.org,
            tier=license.tier.value,
            features=[f.value for f in license.features],
        )

        return LicenseInfo(
            status=LicenseStatus.VALID,
            license=license,
        )

    except json.JSONDecodeError as e:
        logger.warning("license_parse_error", error=str(e))
        return LicenseInfo(
            status=LicenseStatus.PARSE_ERROR,
            error=f"Invalid JSON: {e}",
        )
    except InvalidSignature:
        logger.warning("license_invalid_signature")
        return LicenseInfo(
            status=LicenseStatus.INVALID_SIGNATURE,
            error="Signature verification failed",
        )
    except (KeyError, ValueError, TypeError, UnicodeDecodeError) as e:
        logger.warning("license_parse_error", error=str(e))
        return LicenseInfo(
            status=LicenseStatus.PARSE_ERROR,
            error=f"Invalid license format: {e}",
        )
