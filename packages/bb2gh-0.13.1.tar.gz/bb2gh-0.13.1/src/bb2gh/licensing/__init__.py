"""Licensing module for bb2gh.

Handles license generation, validation, and feature gating for enterprise features.
"""

from bb2gh.exceptions import LimitExceededError
from bb2gh.licensing.decorators import (
    LicenseRequiredError,
    check_limit,
    requires_feature,
    requires_license,
)
from bb2gh.licensing.features import (
    check_repo_limit,
    check_worker_limit,
    get_license,
    is_feature_enabled,
    require_license,
)
from bb2gh.licensing.keys import generate_keypair, sign_license, validate_license

__all__ = [
    "LicenseRequiredError",
    "LimitExceededError",
    "check_limit",
    "check_repo_limit",
    "check_worker_limit",
    "generate_keypair",
    "get_license",
    "is_feature_enabled",
    "require_license",
    "requires_feature",
    "requires_license",
    "sign_license",
    "validate_license",
]
