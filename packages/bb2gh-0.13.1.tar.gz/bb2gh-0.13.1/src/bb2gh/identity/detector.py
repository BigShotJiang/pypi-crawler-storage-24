"""Scenario auto-detection for identity resolution.

Probes available APIs to determine the best matching strategy
based on what identity data sources are accessible.
"""

from __future__ import annotations

import structlog

from bb2gh.identity import enterprise_feature
from bb2gh.identity.config import IdentityConfig, IdPMode, MigrationScenario

logger = structlog.get_logger(__name__)


@enterprise_feature("identity_resolution")
class ScenarioDetector:
    """Detects the IdP migration scenario by probing available APIs.

    Determines source and target IdP modes, whether they share the
    same IdP instance, and which matching stages should be active.
    """

    async def detect(
        self,
        config: IdentityConfig,
    ) -> MigrationScenario:
        """Detect the migration scenario from available configuration.

        Probes configured APIs to determine what identity data is
        available, then selects the appropriate matching stages.

        Args:
            config: Identity configuration with API credentials.

        Returns:
            Detected MigrationScenario.
        """
        source_idp = await self._detect_source_idp(config)
        target_idp = await self._detect_target_idp(config)
        same_instance = self._detect_same_instance(config, source_idp, target_idp)
        active_stages = self._determine_active_stages(source_idp, target_idp, same_instance)

        scenario = MigrationScenario(
            source_idp=source_idp,
            target_idp=target_idp,
            same_idp_instance=same_instance,
            active_stages=active_stages,
        )

        logger.info(
            "scenario_detected",
            source_idp=source_idp.value,
            target_idp=target_idp.value,
            same_instance=same_instance,
            active_stages=active_stages,
        )

        return scenario

    async def _detect_source_idp(self, config: IdentityConfig) -> IdPMode:
        """Detect source (Atlassian/Bitbucket) IdP mode."""
        if (
            config.atlassian_scim_directory_id
            and config.atlassian_scim_api_key
            and await self._probe_atlassian_scim(config)
        ):
            return IdPMode.SCIM

        if (
            config.atlassian_org_id
            and config.atlassian_org_api_key
            and await self._probe_atlassian_org(config)
        ):
            return IdPMode.SAML_SSO

        return IdPMode.NONE

    async def _detect_target_idp(self, config: IdentityConfig) -> IdPMode:
        """Detect target (GitHub) IdP mode."""
        if config.github_enterprise:
            # Enterprise configured — might be EMU
            return IdPMode.EMU

        if config.github_org:
            # Org configured — check for SAML
            return IdPMode.SAML_SSO

        return IdPMode.NONE

    @staticmethod
    def _detect_same_instance(
        _config: IdentityConfig,
        source_idp: IdPMode,
        target_idp: IdPMode,
    ) -> bool:
        """Determine if source and target use the same IdP instance.

        This is a heuristic — true same-instance detection requires
        comparing externalId values. For now, both having SCIM and
        explicit configuration is enough.
        """
        if source_idp == IdPMode.NONE or target_idp == IdPMode.NONE:
            return False

        # Both sides have IdP — assume same if both SCIM
        return source_idp == IdPMode.SCIM and target_idp in (IdPMode.SCIM, IdPMode.EMU)

    @staticmethod
    def _determine_active_stages(
        source_idp: IdPMode,
        target_idp: IdPMode,
        same_instance: bool,
    ) -> list[int]:
        """Determine which matching stages to activate."""
        stages: list[int] = []

        # Stage 1: externalId — only when same IdP instance
        if same_instance:
            stages.append(1)

        # Stage 2: IdP email — when either side has IdP
        if source_idp != IdPMode.NONE or target_idp != IdPMode.NONE:
            stages.append(2)

        # Stage 3: Platform email — always available
        stages.append(3)

        # Stage 4: Git commit email — always available
        stages.append(4)

        # Stage 5: Fuzzy — always available
        stages.append(5)

        return stages

    async def _probe_atlassian_scim(self, config: IdentityConfig) -> bool:
        """Check if Atlassian SCIM API is accessible."""
        try:
            from bb2gh.identity.atlassian_scim import AtlassianSCIMClient

            async with AtlassianSCIMClient(
                config.atlassian_scim_directory_id or "",
                config.atlassian_scim_api_key or "",
            ) as client:
                # Try a small request to verify access
                await client.list_users()
                return True
        except Exception:
            logger.debug("atlassian_scim_probe_failed")
            return False

    async def _probe_atlassian_org(self, config: IdentityConfig) -> bool:
        """Check if Atlassian Org API is accessible."""
        try:
            from bb2gh.identity.atlassian_org import AtlassianOrgClient

            async with AtlassianOrgClient(
                config.atlassian_org_id or "",
                config.atlassian_org_api_key or "",
            ) as client:
                await client.list_directories()
                return True
        except Exception:
            logger.debug("atlassian_org_probe_failed")
            return False
