"""Identity Resolution Engine — 5-stage matching waterfall.

Matches source (Bitbucket) users to target (GitHub) users using a
priority-ordered waterfall of matching strategies. First match wins
per user; unmatched users pass to the next stage.

Stages:
1. SCIM externalId (same IdP instance) → DEFINITIVE
2. IdP email (from SCIM/SAML) → HIGH
3. Platform email (from BB/GH profiles) → HIGH
4. Git commit email (from repos) → MEDIUM
5. Fuzzy (username + name similarity) → LOW-MEDIUM
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import structlog

from bb2gh.identity import enterprise_feature
from bb2gh.identity.config import MigrationScenario  # noqa: TC001
from bb2gh.models.user_mapping import (
    MatchConfidence,
    MatchType,
    SourceUser,
    TargetUser,
    UserMapping,
)

logger = structlog.get_logger(__name__)


@dataclass
class ResolutionResult:
    """Result of identity resolution across all users."""

    mappings: list[UserMapping] = field(default_factory=list)
    scenario: MigrationScenario | None = None

    @property
    def total(self) -> int:
        return len(self.mappings)

    @property
    def matched(self) -> int:
        return sum(1 for m in self.mappings if m.target_username is not None)

    @property
    def unmatched(self) -> int:
        return sum(1 for m in self.mappings if m.target_username is None)


@enterprise_feature("identity_resolution")
class IdentityResolver:
    """5-stage waterfall identity resolver.

    Matches source users to target users using progressively less
    reliable strategies. First match wins per user.
    """

    def __init__(self, similarity_threshold: float = 0.6) -> None:
        self._similarity_threshold = similarity_threshold

    def resolve(
        self,
        source_users: list[SourceUser],
        target_users: list[TargetUser],
        scenario: MigrationScenario,
        *,
        git_emails_source: dict[str, set[str]] | None = None,
        git_emails_target: dict[str, set[str]] | None = None,
    ) -> ResolutionResult:
        """Resolve source users to target users using the waterfall.

        Args:
            source_users: Users from source system (Bitbucket).
            target_users: Users from target system (GitHub).
            scenario: Detected migration scenario with active stages.
            git_emails_source: Mapping of git email → set of source identifiers.
            git_emails_target: Mapping of git email → set of target usernames.

        Returns:
            ResolutionResult with mappings for all source users.
        """
        active = set(scenario.active_stages)
        result = ResolutionResult(scenario=scenario)

        # Build lookup indexes
        indexes = self._build_indexes(target_users, git_emails_target)

        # Track which source users are already matched
        unmatched_sources = list(source_users)
        matched_mappings: list[UserMapping] = []

        # Stage 1: SCIM externalId
        if 1 in active:
            unmatched_sources, stage_mappings = self._stage_1_external_id(
                unmatched_sources, indexes
            )
            matched_mappings.extend(stage_mappings)

        # Stage 2: IdP email
        if 2 in active:
            unmatched_sources, stage_mappings = self._stage_2_idp_email(unmatched_sources, indexes)
            matched_mappings.extend(stage_mappings)

        # Stage 3: Platform email
        if 3 in active:
            unmatched_sources, stage_mappings = self._stage_3_platform_email(
                unmatched_sources, indexes
            )
            matched_mappings.extend(stage_mappings)

        # Stage 4: Git commit email
        if 4 in active and git_emails_source and git_emails_target:
            unmatched_sources, stage_mappings = self._stage_4_git_email(
                unmatched_sources, indexes, git_emails_source, git_emails_target
            )
            matched_mappings.extend(stage_mappings)

        # Stage 5: Fuzzy (username + name)
        if 5 in active:
            unmatched_sources, stage_mappings = self._stage_5_fuzzy(unmatched_sources, indexes)
            matched_mappings.extend(stage_mappings)

        # Remaining unmatched users
        for source in unmatched_sources:
            matched_mappings.append(
                UserMapping(
                    source_username=source.username,
                    source_email=source.email,
                    match_type=MatchType.UNMAPPED,
                    confidence=MatchConfidence.LOW,
                )
            )

        result.mappings = matched_mappings

        logger.info(
            "identity_resolution_complete",
            total=result.total,
            matched=result.matched,
            unmatched=result.unmatched,
            stages_active=sorted(active),
        )

        return result

    def _build_indexes(
        self,
        target_users: list[TargetUser],
        git_emails_target: dict[str, set[str]] | None = None,
    ) -> dict[str, Any]:
        """Build lookup indexes for efficient matching."""
        by_external_id: dict[str, TargetUser] = {}
        by_idp_email: dict[str, TargetUser] = {}
        by_email: dict[str, TargetUser] = {}
        by_username: dict[str, TargetUser] = {}

        for user in target_users:
            if user.external_id:
                by_external_id[user.external_id] = user
            if user.idp_email:
                by_idp_email[user.idp_email.lower()] = user
            if user.email:
                by_email[user.email.lower()] = user
            by_username[user.username.lower()] = user

        return {
            "by_external_id": by_external_id,
            "by_idp_email": by_idp_email,
            "by_email": by_email,
            "by_username": by_username,
            "all_targets": target_users,
            "git_emails_target": git_emails_target or {},
        }

    def _stage_1_external_id(
        self,
        sources: list[SourceUser],
        indexes: dict[str, Any],
    ) -> tuple[list[SourceUser], list[UserMapping]]:
        """Stage 1: Match by SCIM externalId (same IdP)."""
        by_ext = indexes["by_external_id"]
        unmatched: list[SourceUser] = []
        mappings: list[UserMapping] = []

        for source in sources:
            if source.external_id and source.external_id in by_ext:
                target = by_ext[source.external_id]
                mappings.append(
                    UserMapping(
                        source_username=source.username,
                        source_email=source.email,
                        target_username=target.username,
                        target_email=target.email,
                        match_type=MatchType.SCIM_EXTERNAL_ID,
                        confidence=MatchConfidence.DEFINITIVE,
                        match_stage=1,
                        match_rule=f"SCIM externalId={source.external_id}",
                    )
                )
            else:
                unmatched.append(source)

        return unmatched, mappings

    def _stage_2_idp_email(
        self,
        sources: list[SourceUser],
        indexes: dict[str, Any],
    ) -> tuple[list[SourceUser], list[UserMapping]]:
        """Stage 2: Match by IdP email (from SCIM/SAML)."""
        by_idp = indexes["by_idp_email"]
        by_email = indexes["by_email"]
        unmatched: list[SourceUser] = []
        mappings: list[UserMapping] = []

        for source in sources:
            if not source.idp_email:
                unmatched.append(source)
                continue

            email_lower = source.idp_email.lower()
            # Try IdP email index first, then platform email index
            target = by_idp.get(email_lower) or by_email.get(email_lower)
            if target:
                mappings.append(
                    UserMapping(
                        source_username=source.username,
                        source_email=source.email,
                        target_username=target.username,
                        target_email=target.email,
                        match_type=MatchType.IDP_EMAIL,
                        confidence=MatchConfidence.HIGH,
                        match_stage=2,
                        match_rule=f"IdP email={source.idp_email}",
                    )
                )
            else:
                unmatched.append(source)

        return unmatched, mappings

    def _stage_3_platform_email(
        self,
        sources: list[SourceUser],
        indexes: dict[str, Any],
    ) -> tuple[list[SourceUser], list[UserMapping]]:
        """Stage 3: Match by platform email (from BB/GH profiles)."""
        by_email = indexes["by_email"]
        by_idp = indexes["by_idp_email"]
        unmatched: list[SourceUser] = []
        mappings: list[UserMapping] = []

        for source in sources:
            if not source.email:
                unmatched.append(source)
                continue

            email_lower = source.email.lower()
            target = by_email.get(email_lower) or by_idp.get(email_lower)
            if target:
                mappings.append(
                    UserMapping(
                        source_username=source.username,
                        source_email=source.email,
                        target_username=target.username,
                        target_email=target.email,
                        match_type=MatchType.PLATFORM_EMAIL,
                        confidence=MatchConfidence.HIGH,
                        match_stage=3,
                        match_rule=f"Platform email={source.email}",
                    )
                )
            else:
                unmatched.append(source)

        return unmatched, mappings

    def _stage_4_git_email(
        self,
        sources: list[SourceUser],
        indexes: dict[str, Any],
        git_emails_source: dict[str, set[str]],
        git_emails_target: dict[str, set[str]],
    ) -> tuple[list[SourceUser], list[UserMapping]]:
        """Stage 4: Match by git commit email."""
        by_username = indexes["by_username"]
        unmatched: list[SourceUser] = []
        mappings: list[UserMapping] = []

        # Build reverse: source id → git emails used
        source_to_emails: dict[str, set[str]] = {}
        for email, identifiers in git_emails_source.items():
            for identifier in identifiers:
                if identifier not in source_to_emails:
                    source_to_emails[identifier] = set()
                source_to_emails[identifier].add(email)

        # Build reverse: target username → git emails used
        target_to_emails: dict[str, set[str]] = {}
        for email, usernames in git_emails_target.items():
            for username in usernames:
                if username not in target_to_emails:
                    target_to_emails[username] = set()
                target_to_emails[username].add(email)

        # Build email → target username for lookup
        email_to_target: dict[str, str] = {}
        for email, usernames in git_emails_target.items():
            for username in usernames:
                email_to_target[email] = username

        for source in sources:
            identifier = source.account_id or source.username
            source_emails = source_to_emails.get(identifier, set())

            matched = False
            for email in source_emails:
                target_username = email_to_target.get(email)
                if target_username and target_username.lower() in by_username:
                    target = by_username[target_username.lower()]
                    mappings.append(
                        UserMapping(
                            source_username=source.username,
                            source_email=source.email,
                            target_username=target.username,
                            target_email=target.email,
                            match_type=MatchType.GIT_EMAIL,
                            confidence=MatchConfidence.MEDIUM,
                            match_stage=4,
                            match_rule=f"Git commit email={email}",
                        )
                    )
                    matched = True
                    break

            if not matched:
                unmatched.append(source)

        return unmatched, mappings

    def _stage_5_fuzzy(
        self,
        sources: list[SourceUser],
        indexes: dict[str, Any],
    ) -> tuple[list[SourceUser], list[UserMapping]]:
        """Stage 5: Fuzzy matching (username + name similarity)."""
        by_username: dict[str, TargetUser] = indexes["by_username"]
        all_targets: list[TargetUser] = indexes["all_targets"]
        unmatched: list[SourceUser] = []
        mappings: list[UserMapping] = []

        for source in sources:
            # Try exact username match first
            if source.username:
                target = by_username.get(source.username.lower())
                if target:
                    mappings.append(
                        UserMapping(
                            source_username=source.username,
                            source_email=source.email,
                            target_username=target.username,
                            target_email=target.email,
                            match_type=MatchType.USERNAME,
                            confidence=MatchConfidence.MEDIUM,
                            match_stage=5,
                            match_rule=f"Username={source.username}",
                        )
                    )
                    continue

            # Try fuzzy name match
            if source.display_name:
                best_target, best_score = self._find_best_name_match(
                    source.display_name, all_targets
                )
                if best_target and best_score >= self._similarity_threshold:
                    mappings.append(
                        UserMapping(
                            source_username=source.username,
                            source_email=source.email,
                            target_username=best_target.username,
                            target_email=best_target.email,
                            match_type=MatchType.NAME,
                            confidence=MatchConfidence.MEDIUM,
                            match_stage=5,
                            match_rule=f"Name similarity={best_score:.2f}",
                            notes=f"Source: {source.display_name} → Target: {best_target.name}",
                        )
                    )
                    continue

            unmatched.append(source)

        return unmatched, mappings

    @staticmethod
    def _find_best_name_match(
        source_name: str,
        targets: list[TargetUser],
    ) -> tuple[TargetUser | None, float]:
        """Find best name match using Jaccard word similarity."""
        best_target = None
        best_score = 0.0
        source_words = set(source_name.lower().split())

        for target in targets:
            if not target.name:
                continue
            target_words = set(target.name.lower().split())
            if not source_words or not target_words:
                continue
            intersection = len(source_words & target_words)
            union = len(source_words | target_words)
            score = intersection / union if union > 0 else 0.0
            if score > best_score:
                best_score = score
                best_target = target

        return best_target, best_score
