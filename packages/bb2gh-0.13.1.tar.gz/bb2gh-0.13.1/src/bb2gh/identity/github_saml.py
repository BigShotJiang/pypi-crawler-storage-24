"""GitHub SAML identity client for identity resolution.

Queries the GitHub GraphQL API to retrieve SAML external identities
for an organization, mapping GitHub logins to SAML nameId/emails.

Auth: PAT with `read:org` scope (uses existing GitHub credentials).
Endpoint: GraphQL — organization.samlIdentityProvider.externalIdentities
"""

from __future__ import annotations

from typing import Any

import httpx
import structlog

from bb2gh.identity import enterprise_feature

logger = structlog.get_logger(__name__)

SAML_IDENTITIES_QUERY = """
query($org: String!, $after: String) {
  organization(login: $org) {
    samlIdentityProvider {
      externalIdentities(first: 100, after: $after) {
        pageInfo {
          hasNextPage
          endCursor
        }
        edges {
          node {
            guid
            samlIdentity {
              nameId
              emails
            }
            scimIdentity {
              username
              emails
            }
            user {
              login
              name
              email
            }
          }
        }
      }
    }
  }
}
"""


@enterprise_feature("identity_resolution")
class GitHubSAMLClient:
    """Client for GitHub SAML external identities via GraphQL.

    Retrieves the mapping between GitHub logins and their SAML identity
    (nameId, emails) for organizations with SAML SSO configured.
    """

    def __init__(
        self, token: str, api_url: str = "https://api.github.com", *, ssl_verify: str | bool = True
    ) -> None:
        self._token = token
        self._graphql_url = f"{api_url}/graphql"
        self._ssl_verify = ssl_verify
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> GitHubSAMLClient:
        self._client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {self._token}",
                "Accept": "application/vnd.github+json",
            },
            timeout=30.0,
            verify=self._ssl_verify,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Client not initialized — use 'async with'")
        return self._client

    async def list_users(self, org: str | None = None) -> list[dict[str, Any]]:
        """List SAML external identities for an organization.

        Args:
            org: GitHub organization name. Required.

        Returns:
            List of identity records mapping GitHub login to SAML identity.
        """
        if not org:
            return []

        client = self._get_client()
        identities: list[dict[str, Any]] = []
        after: str | None = None

        while True:
            variables: dict[str, Any] = {"org": org}
            if after:
                variables["after"] = after

            response = await client.post(
                self._graphql_url,
                json={"query": SAML_IDENTITIES_QUERY, "variables": variables},
            )
            response.raise_for_status()
            data = response.json()

            # Navigate the GraphQL response
            org_data = data.get("data", {}).get("organization")
            if not org_data:
                break

            provider = org_data.get("samlIdentityProvider")
            if not provider:
                break

            ext_identities = provider.get("externalIdentities", {})
            edges = ext_identities.get("edges", [])

            for edge in edges:
                node = edge.get("node", {})
                identities.append(self._parse_identity(node))

            page_info = ext_identities.get("pageInfo", {})
            if not page_info.get("hasNextPage"):
                break
            after = page_info.get("endCursor")

        logger.debug("github_saml_identities_listed", org=org, count=len(identities))
        return identities

    async def get_user_by_external_id(self, _external_id: str) -> dict[str, Any] | None:
        """Not directly supported by SAML GraphQL API.

        Use list_users() and filter client-side by nameId.
        """
        return None

    @staticmethod
    def _parse_identity(node: dict[str, Any]) -> dict[str, Any]:
        """Parse a SAML external identity node."""
        saml = node.get("samlIdentity") or {}
        scim = node.get("scimIdentity") or {}
        user = node.get("user") or {}

        saml_emails = saml.get("emails") or []
        scim_emails = scim.get("emails") or []

        return {
            "guid": node.get("guid", ""),
            "github_login": user.get("login"),
            "github_name": user.get("name"),
            "github_email": user.get("email"),
            "saml_name_id": saml.get("nameId"),
            "saml_emails": saml_emails,
            "scim_username": scim.get("username"),
            "scim_emails": scim_emails,
            "email": saml.get("nameId") or (saml_emails[0] if saml_emails else None),
        }
