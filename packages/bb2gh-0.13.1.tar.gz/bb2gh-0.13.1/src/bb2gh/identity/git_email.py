"""Git commit email extractor for identity resolution.

Extracts unique author emails from git commit history as a
platform-independent matching signal. Works without any IdP.

Uses GitService (project standard) for safe subprocess execution.
"""

from __future__ import annotations

import re
from pathlib import Path  # noqa: TC003 — used at runtime in subprocess cwd

import structlog

logger = structlog.get_logger(__name__)

# Patterns to filter out non-human email addresses
BOT_EMAIL_PATTERNS = [
    re.compile(r"noreply@github\.com$"),
    re.compile(r"\+.*@users\.noreply\.github\.com$"),
    re.compile(r"noreply@.*\.atlassian\.(com|net)$"),
    re.compile(r"bot@"),
    re.compile(r"dependabot"),
    re.compile(r"renovate"),
    re.compile(r"github-actions"),
    re.compile(r"^$"),  # Empty email
]


class GitEmailExtractor:
    """Extracts author emails from git commit history.

    Parses ``git log`` output to build a mapping of email addresses
    to author names. Filters out bot and noreply addresses.
    """

    def __init__(self, git_path: str = "git") -> None:
        self._git = git_path

    async def extract_commit_emails(self, repo_path: Path) -> dict[str, set[str]]:
        """Extract unique author email → names mapping from a repository.

        Args:
            repo_path: Path to a git repository (already cloned).

        Returns:
            Dict mapping email addresses to sets of author names seen
            with that email. Bot/noreply emails are filtered out.
        """
        import asyncio

        try:
            proc = await asyncio.create_subprocess_exec(
                self._git,
                "log",
                "--format=%ae|%an",
                "--all",
                cwd=repo_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await proc.communicate()

            if proc.returncode != 0:
                logger.warning(
                    "git_log_failed",
                    repo=str(repo_path),
                    stderr=stderr.decode(errors="replace")[:200],
                )
                return {}

        except FileNotFoundError:
            logger.warning("git_not_found", path=self._git)
            return {}

        return self._parse_log_output(stdout.decode(errors="replace"))

    def _parse_log_output(self, output: str) -> dict[str, set[str]]:
        """Parse git log output into email → names mapping."""
        email_names: dict[str, set[str]] = {}

        for line in output.strip().splitlines():
            if "|" not in line:
                continue
            parts = line.split("|", maxsplit=1)
            if len(parts) != 2:
                continue

            email = parts[0].strip().lower()
            name = parts[1].strip()

            if not email or self._is_bot_email(email):
                continue

            if email not in email_names:
                email_names[email] = set()
            email_names[email].add(name)

        logger.debug(
            "git_emails_extracted",
            unique_emails=len(email_names),
        )
        return email_names

    @staticmethod
    def _is_bot_email(email: str) -> bool:
        """Check if an email matches a known bot/noreply pattern."""
        return any(pattern.search(email) for pattern in BOT_EMAIL_PATTERNS)

    async def extract_emails_from_repos(self, repo_paths: list[Path]) -> dict[str, set[str]]:
        """Extract emails from multiple repositories and merge results.

        Args:
            repo_paths: List of paths to git repositories.

        Returns:
            Merged email → names mapping across all repos.
        """
        merged: dict[str, set[str]] = {}

        for repo_path in repo_paths:
            repo_emails = await self.extract_commit_emails(repo_path)
            for email, names in repo_emails.items():
                if email not in merged:
                    merged[email] = set()
                merged[email].update(names)

        return merged
