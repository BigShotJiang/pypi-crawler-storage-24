"""Atlassian Organization API client for identity resolution.

Queries the Atlassian admin API to retrieve managed users, directories,
and verified domains for an organization.

Auth: Bearer token (Organization API key).
Endpoint: https://api.atlassian.com/admin/v2/orgs/{orgId}/...
"""

from __future__ import annotations

from typing import Any

import httpx
import structlog

from bb2gh.identity import enterprise_feature

logger = structlog.get_logger(__name__)


@enterprise_feature("identity_resolution")
class AtlassianOrgClient:
    """Client for Atlassian Organization REST API.

    Provides access to managed users, directories, and verified domains.
    Used for enriching Bitbucket users with managed email addresses.
    """

    BASE_URL = "https://api.atlassian.com/admin/v2/orgs"

    def __init__(self, org_id: str, api_key: str, *, ssl_verify: str | bool = True) -> None:
        self._org_id = org_id
        self._api_key = api_key
        self._ssl_verify = ssl_verify
        self._client: httpx.AsyncClient | None = None

    async def __aenter__(self) -> AtlassianOrgClient:
        self._client = httpx.AsyncClient(
            base_url=f"{self.BASE_URL}/{self._org_id}",
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Accept": "application/json",
            },
            timeout=30.0,
            verify=self._ssl_verify,
        )
        return self

    async def __aexit__(self, *args: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None:
            raise RuntimeError("Client not initialized — use 'async with'")
        return self._client

    async def list_users(self) -> list[dict[str, Any]]:
        """List managed users in the organization.

        Handles cursor-based pagination.

        Returns:
            List of managed user records.
        """
        client = self._get_client()
        users: list[dict[str, Any]] = []
        cursor: str | None = None

        while True:
            params: dict[str, Any] = {}
            if cursor:
                params["cursor"] = cursor

            response = await client.get("/users", params=params)
            response.raise_for_status()
            data = response.json()

            for user_data in data.get("data", []):
                users.append(
                    {
                        "account_id": user_data.get("account_id", ""),
                        "email": user_data.get("email"),
                        "name": user_data.get("name", ""),
                        "account_status": user_data.get("account_status", ""),
                        "account_type": user_data.get("account_type", ""),
                    }
                )

            # Check for next page
            links = data.get("links", {})
            next_link = links.get("next")
            if not next_link:
                break
            # Extract cursor from next URL
            from urllib.parse import parse_qs, urlparse

            parsed = urlparse(next_link)
            cursor_values = parse_qs(parsed.query).get("cursor", [])
            cursor = cursor_values[0] if cursor_values else None
            if not cursor:
                break

        logger.debug("atlassian_org_users_listed", count=len(users))
        return users

    async def list_directories(self) -> list[dict[str, Any]]:
        """List identity directories for the organization.

        Returns:
            List of directory records (id, name, type).
        """
        client = self._get_client()
        response = await client.get("/directories")
        response.raise_for_status()
        data = response.json()

        return [
            {
                "id": d.get("id", ""),
                "name": d.get("name", ""),
                "type": d.get("type", ""),
            }
            for d in data.get("data", [])
        ]

    async def list_domains(self) -> list[dict[str, Any]]:
        """List verified domains for the organization.

        Returns:
            List of domain records.
        """
        client = self._get_client()
        response = await client.get("/domains")
        response.raise_for_status()
        data = response.json()

        return [
            {
                "id": d.get("id", ""),
                "name": d.get("name", ""),
                "claim_status": d.get("claim", {}).get("status", ""),
            }
            for d in data.get("data", [])
        ]
