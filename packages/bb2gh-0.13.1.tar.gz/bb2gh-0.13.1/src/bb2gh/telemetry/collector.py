"""Telemetry event collection.

Collects anonymous usage events for product analytics.
"""

from __future__ import annotations

import platform

import structlog

from bb2gh.models.telemetry import (
    CommandEvent,
    DiscoveryEvent,
    FeatureEvent,
    MigrationEvent,
    PlanEvent,
    TelemetryConfig,
    TelemetryEvent,
    ValidationEvent,
    get_repo_count_range,
)
from bb2gh.telemetry.privacy import is_telemetry_enabled

logger = structlog.get_logger(__name__)


class TelemetryCollector:
    """Collects telemetry events.

    Respects user opt-out preferences and never collects PII.
    """

    def __init__(self, config: TelemetryConfig | None = None):
        """Initialize collector.

        Args:
            config: Telemetry configuration.
        """
        self.config = config or TelemetryConfig()
        self._queue: list[TelemetryEvent] = []
        self._version = self._get_version()
        self._platform = self._get_platform()

    def collect(self, event: TelemetryEvent) -> None:
        """Collect a telemetry event.

        Args:
            event: Event to collect.
        """
        if not is_telemetry_enabled():
            return

        # Enrich event with context
        event.anonymous_id = self.config.anonymous_id
        event.version = self._version
        event.platform = self._platform

        self._queue.append(event)

        logger.debug(
            "telemetry_event_collected",
            event_type=event.event_type.value,
            queue_size=len(self._queue),
        )

        # Auto-flush if batch size reached
        if len(self._queue) >= self.config.batch_size:
            self.flush()

    def command_start(self, command: str) -> None:
        """Record command start event.

        Args:
            command: Command name (not parameters).
        """
        if not self.config.collect_command_events:
            return

        event = CommandEvent.start(command, self.config.anonymous_id)
        self.collect(event)

    def command_success(self, command: str, duration_ms: int = 0) -> None:
        """Record command success event.

        Args:
            command: Command name.
            duration_ms: Duration in milliseconds.
        """
        if not self.config.collect_command_events:
            return

        event = CommandEvent.success(command, self.config.anonymous_id, duration_ms)
        self.collect(event)

    def command_failure(self, command: str, error_type: str = "") -> None:
        """Record command failure event.

        Args:
            command: Command name.
            error_type: Type of error (not message).
        """
        if not self.config.collect_command_events:
            return

        event = CommandEvent.failure(command, self.config.anonymous_id, error_type)
        self.collect(event)

    def migration_start(
        self,
        repo_count: int,
        *,
        total_size_mb: int = 0,
        repos_with_lfs: int = 0,
        total_prs: int = 0,
        branch_protection_rules: int = 0,
        source_type: str = "bitbucket",
        target_type: str = "github",
    ) -> None:
        """Record migration start event.

        Args:
            repo_count: Number of repositories.
            total_size_mb: Aggregate size in megabytes.
            repos_with_lfs: Number of repos using LFS.
            total_prs: Total PRs to migrate.
            branch_protection_rules: Number of branch protection rules.
            source_type: Source platform identifier.
            target_type: Target platform identifier.
        """
        if not self.config.collect_migration_events:
            return

        repo_range = get_repo_count_range(repo_count)
        event = MigrationEvent.start(
            self.config.anonymous_id,
            repo_range,
            repo_count=repo_count,
            total_size_mb=total_size_mb,
            repos_with_lfs=repos_with_lfs,
            total_prs=total_prs,
            branch_protection_rules=branch_protection_rules,
            source_type=source_type,
            target_type=target_type,
        )
        self.collect(event)

    def migration_success(
        self,
        repo_count: int,
        duration_ms: int = 0,
        *,
        repos_completed: int = 0,
        repos_failed: int = 0,
        total_size_mb: int = 0,
        branches_migrated: int = 0,
        tags_migrated: int = 0,
        prs_migrated: int = 0,
        prs_failed: int = 0,
        comments_migrated: int = 0,
        lfs_repos_migrated: int = 0,
        protection_rules_created: int = 0,
    ) -> None:
        """Record migration success event.

        Args:
            repo_count: Number of repositories.
            duration_ms: Duration in milliseconds.
            repos_completed: Repos that completed successfully.
            repos_failed: Repos that failed.
            total_size_mb: Aggregate size in megabytes.
            branches_migrated: Total branches migrated.
            tags_migrated: Total tags migrated.
            prs_migrated: Total PRs migrated.
            prs_failed: Total PRs that failed.
            comments_migrated: Total comments migrated.
            lfs_repos_migrated: Repos with LFS migrated.
            protection_rules_created: Branch protection rules created.
        """
        if not self.config.collect_migration_events:
            return

        repo_range = get_repo_count_range(repo_count)
        event = MigrationEvent.success(
            self.config.anonymous_id,
            repo_range,
            duration_ms,
            repo_count=repo_count,
            repos_completed=repos_completed,
            repos_failed=repos_failed,
            total_size_mb=total_size_mb,
            branches_migrated=branches_migrated,
            tags_migrated=tags_migrated,
            prs_migrated=prs_migrated,
            prs_failed=prs_failed,
            comments_migrated=comments_migrated,
            lfs_repos_migrated=lfs_repos_migrated,
            protection_rules_created=protection_rules_created,
        )
        self.collect(event)

    def migration_failure(
        self,
        repo_count: int,
        *,
        repos_completed: int = 0,
        repos_failed: int = 0,
        error_type: str = "",
        duration_ms: int = 0,
    ) -> None:
        """Record migration failure event.

        Args:
            repo_count: Number of repositories.
            repos_completed: Repos that completed before failure.
            repos_failed: Repos that failed.
            error_type: Type of error (not message).
            duration_ms: Duration in milliseconds.
        """
        if not self.config.collect_migration_events:
            return

        repo_range = get_repo_count_range(repo_count)
        event = MigrationEvent.failure(
            self.config.anonymous_id,
            repo_range,
            repo_count=repo_count,
            repos_completed=repos_completed,
            repos_failed=repos_failed,
            error_type=error_type,
            duration_ms=duration_ms,
        )
        self.collect(event)

    def discovery_completed(
        self,
        *,
        repo_count: int = 0,
        total_size_mb: int = 0,
        repos_with_lfs: int = 0,
        complexity_simple: int = 0,
        complexity_moderate: int = 0,
        complexity_complex: int = 0,
        total_prs: int = 0,
    ) -> None:
        """Record discovery completed event.

        Args:
            repo_count: Number of repos discovered.
            total_size_mb: Aggregate size in megabytes.
            repos_with_lfs: Repos using LFS.
            complexity_simple: Repos with simple complexity.
            complexity_moderate: Repos with moderate complexity.
            complexity_complex: Repos with complex complexity.
            total_prs: Total PRs found.
        """
        if not self.config.collect_migration_events:
            return

        event = DiscoveryEvent.completed(
            self.config.anonymous_id,
            repo_count=repo_count,
            total_size_mb=total_size_mb,
            repos_with_lfs=repos_with_lfs,
            complexity_simple=complexity_simple,
            complexity_moderate=complexity_moderate,
            complexity_complex=complexity_complex,
            total_prs=total_prs,
        )
        self.collect(event)

    def plan_created(
        self,
        *,
        repo_count: int = 0,
        total_size_mb: int = 0,
        repos_with_lfs: int = 0,
        renamed_count: int = 0,
        repos_with_warnings: int = 0,
    ) -> None:
        """Record plan created event.

        Args:
            repo_count: Number of repos in the plan.
            total_size_mb: Aggregate size in megabytes.
            repos_with_lfs: Repos using LFS.
            renamed_count: Number of renamed repos.
            repos_with_warnings: Repos with warnings.
        """
        if not self.config.collect_migration_events:
            return

        event = PlanEvent.created(
            self.config.anonymous_id,
            repo_count=repo_count,
            total_size_mb=total_size_mb,
            repos_with_lfs=repos_with_lfs,
            renamed_count=renamed_count,
            repos_with_warnings=repos_with_warnings,
        )
        self.collect(event)

    def validation_completed(
        self,
        *,
        repos_validated: int = 0,
        repos_passed: int = 0,
        repos_failed: int = 0,
        repos_warnings: int = 0,
        branches_match_rate: float = 0.0,
        tags_match_rate: float = 0.0,
        prs_validated: int = 0,
        comments_match_rate: float = 0.0,
    ) -> None:
        """Record validation completed event.

        Args:
            repos_validated: Repos validated.
            repos_passed: Repos that passed validation.
            repos_failed: Repos that failed validation.
            repos_warnings: Repos with warnings.
            branches_match_rate: Branch match percentage.
            tags_match_rate: Tag match percentage.
            prs_validated: PRs validated.
            comments_match_rate: Comment match percentage.
        """
        if not self.config.collect_migration_events:
            return

        event = ValidationEvent.completed(
            self.config.anonymous_id,
            repos_validated=repos_validated,
            repos_passed=repos_passed,
            repos_failed=repos_failed,
            repos_warnings=repos_warnings,
            branches_match_rate=branches_match_rate,
            tags_match_rate=tags_match_rate,
            prs_validated=prs_validated,
            comments_match_rate=comments_match_rate,
        )
        self.collect(event)

    def feature_used(self, feature: str) -> None:
        """Record feature usage event.

        Args:
            feature: Feature name.
        """
        if not self.config.collect_feature_events:
            return

        event = FeatureEvent.used(self.config.anonymous_id, feature)
        self.collect(event)

    def flush(self) -> list[TelemetryEvent]:
        """Flush queued events.

        Returns:
            Flushed events.
        """
        if not self._queue:
            return []

        events = self._queue.copy()
        self._queue.clear()

        logger.debug("telemetry_events_flushed", count=len(events))

        return events

    def get_queue_size(self) -> int:
        """Get current queue size."""
        return len(self._queue)

    def _get_version(self) -> str:
        """Get CLI version."""
        try:
            from importlib.metadata import version

            return version("bb2gh")
        except Exception:
            return "unknown"

    def _get_platform(self) -> str:
        """Get platform identifier (no sensitive info)."""
        return f"{platform.system()}-{platform.machine()}"


# Global collector instance
_collector: TelemetryCollector | None = None


def get_collector() -> TelemetryCollector:
    """Get the global telemetry collector.

    Returns:
        Global collector instance.
    """
    global _collector
    if _collector is None:
        _collector = TelemetryCollector()
    return _collector


def collect_event(event: TelemetryEvent) -> None:
    """Collect a telemetry event using global collector.

    Args:
        event: Event to collect.
    """
    get_collector().collect(event)
