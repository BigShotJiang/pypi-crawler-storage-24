"""Telemetry event sender.

Sends collected events to analytics backend (PostHog) using the official SDK.
"""

from __future__ import annotations

import platform
from typing import Any

import structlog
from posthog import Posthog

from bb2gh.models.telemetry import TelemetryConfig, TelemetryEvent

logger = structlog.get_logger(__name__)

# Keys that should never appear in telemetry events
_SENSITIVE_KEY_FRAGMENTS = ("path", "url", "token", "secret", "password", "key", "credential")


class PostHogSender:
    """Sends telemetry events to PostHog using the official SDK.

    Uses background thread for async batching. Never blocks CLI execution.
    """

    def __init__(self, config: TelemetryConfig | None = None):
        """Initialize sender.

        Args:
            config: Telemetry configuration.
        """
        self.config = config or TelemetryConfig()
        self._client: Posthog | None = None

    def _get_client(self) -> Posthog:
        """Get or create the PostHog client (lazy initialization)."""
        if self._client is None:
            self._client = Posthog(
                project_api_key=self.config.api_key,
                host=self.config.endpoint,
                disabled=not self.config.enabled,
                disable_geoip=True,
                sync_mode=False,
                flush_at=self.config.batch_size,
                flush_interval=self.config.flush_interval_seconds,
                on_error=_on_error,
                super_properties={
                    "app_name": "bb2gh",
                    "app_version": _get_version(),
                    "platform": f"{platform.system()}-{platform.machine()}",
                    "$process_person_profile": False,
                },
            )
            self._client.debug = self.config.debug
        return self._client

    def capture(self, event: TelemetryEvent) -> None:
        """Send a single event to PostHog.

        Args:
            event: The telemetry event to send.
        """
        client = self._get_client()
        properties = _sanitize_properties(event.properties)
        properties["$process_person_profile"] = False
        client.capture(
            distinct_id=event.anonymous_id,
            event=event.event_type.value,
            properties=properties,
        )

    def flush(self) -> None:
        """Flush pending events in the PostHog SDK queue.

        Forces the SDK to send all queued events immediately.
        """
        if self._client is not None:
            self._client.flush()  # type: ignore[no-untyped-call]
            logger.debug("posthog_sender_flushed")

    def shutdown(self) -> None:
        """Flush pending events and shut down the SDK.

        Should be called on process exit to ensure all events are sent.
        """
        if self._client is not None:
            self.flush()
            self._client.shutdown()  # type: ignore[no-untyped-call]
            logger.debug("posthog_sender_shutdown")


def _on_error(error: Exception, items: list[Any]) -> None:
    """Silent error handler — never block CLI."""
    logger.debug("posthog_send_error", error=str(error), item_count=len(items))


def _get_version() -> str:
    """Get CLI version."""
    try:
        from importlib.metadata import version

        return version("bb2gh")
    except Exception:
        return "unknown"


def _sanitize_properties(properties: dict[str, Any]) -> dict[str, Any]:
    """Strip any accidentally included PII from event properties.

    Args:
        properties: Original event properties.

    Returns:
        Sanitized copy with sensitive keys removed.
    """
    sanitized = {}
    for key, value in properties.items():
        key_lower = key.lower()
        if any(fragment in key_lower for fragment in _SENSITIVE_KEY_FRAGMENTS):
            continue
        sanitized[key] = value
    return sanitized


class TelemetryQueue:
    """Background queue for telemetry events.

    Stores events until they can be sent.
    """

    def __init__(self, max_size: int = 1000):
        """Initialize queue.

        Args:
            max_size: Maximum queue size.
        """
        self.max_size = max_size
        self._events: list[TelemetryEvent] = []

    def add(self, event: TelemetryEvent) -> None:
        """Add event to queue.

        Args:
            event: Event to add.
        """
        if len(self._events) >= self.max_size:
            # Drop oldest event
            self._events.pop(0)

        self._events.append(event)

    def get_batch(self, size: int = 10) -> list[TelemetryEvent]:
        """Get a batch of events.

        Args:
            size: Batch size.

        Returns:
            Batch of events.
        """
        batch = self._events[:size]
        self._events = self._events[size:]
        return batch

    def clear(self) -> None:
        """Clear all events."""
        self._events.clear()

    @property
    def size(self) -> int:
        """Get queue size."""
        return len(self._events)


# API documentation for landing page integration
LANDING_PAGE_API_SPEC = """
# Landing Page Stats API

## Endpoint
GET /api/stats

## Response
{
    "total_migrations": 1234,
    "repos_migrated": "100+",
    "success_rate_percent": 99.5,
    "popular_features": ["parallel", "waves", "validation"],
    "last_updated": "2024-01-15T12:00:00Z"
}

## Notes
- Stats are aggregated daily from PostHog
- No individual user data is exposed
- Ranges are used instead of exact numbers for privacy
- Website implementation is a separate project
- Contact devops@ for API access
"""
