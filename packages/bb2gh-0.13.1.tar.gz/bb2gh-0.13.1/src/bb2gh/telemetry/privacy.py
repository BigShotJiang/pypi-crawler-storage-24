"""Telemetry privacy controls.

Provides opt-out mechanism for telemetry collection.
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

import structlog

logger = structlog.get_logger(__name__)

# Environment variables
TELEMETRY_ENV_VAR = "BB2GH_TELEMETRY_ENABLED"
CI_ENV_VARS = [
    "CI",
    "CONTINUOUS_INTEGRATION",
    "GITHUB_ACTIONS",
    "GITLAB_CI",
    "CIRCLECI",
    "JENKINS_URL",
    "TRAVIS",
    "BITBUCKET_BUILD_NUMBER",
]

# Config file location
CONFIG_DIR = Path.home() / ".bb2gh"
TELEMETRY_OPT_OUT_FILE = CONFIG_DIR / "telemetry-disabled"
TELEMETRY_NOTICE_FILE = CONFIG_DIR / "telemetry-notice-shown"


@lru_cache(maxsize=1)
def is_telemetry_enabled() -> bool:
    """Check if telemetry collection is enabled.

    Telemetry is disabled if:
    1. DO_NOT_TRACK=1 in environment (https://consoledonottrack.com/)
    2. BB2GH_TELEMETRY_ENABLED=false in environment
    3. ~/.bb2gh/telemetry-disabled file exists
    4. Running in CI environment (auto-detected)

    Returns:
        True if telemetry is enabled.
    """
    # Check DO_NOT_TRACK standard (https://consoledonottrack.com/)
    dnt = os.environ.get("DO_NOT_TRACK", "").lower()
    if dnt in ("1", "true", "yes"):
        logger.debug("telemetry_disabled_by_dnt")
        return False

    # Check environment variable
    env_value = os.environ.get(TELEMETRY_ENV_VAR, "").lower()
    if env_value in ("false", "0", "no", "off"):
        logger.debug("telemetry_disabled_by_env")
        return False

    # Check opt-out file
    if TELEMETRY_OPT_OUT_FILE.exists():
        logger.debug("telemetry_disabled_by_file")
        return False

    # Check if running in CI
    if _is_ci_environment():
        logger.debug("telemetry_disabled_ci_detected")
        return False

    return True


def _is_ci_environment() -> bool:
    """Detect if running in a CI environment.

    Returns:
        True if CI environment detected.
    """
    return any(os.environ.get(env_var) for env_var in CI_ENV_VARS)


def opt_out() -> None:
    """Opt out of telemetry collection.

    Creates the opt-out file and clears the cache.
    """
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TELEMETRY_OPT_OUT_FILE.touch()

    # Clear the cached result
    is_telemetry_enabled.cache_clear()

    logger.info("telemetry_opted_out")


def opt_in() -> None:
    """Opt in to telemetry collection.

    Removes the opt-out file and clears the cache.
    """
    if TELEMETRY_OPT_OUT_FILE.exists():
        TELEMETRY_OPT_OUT_FILE.unlink()

    # Clear the cached result
    is_telemetry_enabled.cache_clear()

    logger.info("telemetry_opted_in")


def get_anonymous_id() -> str:
    """Get or generate anonymous user ID.

    Returns:
        Anonymous ID (UUID stored in config).
    """
    id_file = CONFIG_DIR / "anonymous-id"

    if id_file.exists():
        return id_file.read_text().strip()

    # Generate new ID
    from uuid import uuid4

    anonymous_id = str(uuid4())

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    id_file.write_text(anonymous_id)

    logger.debug("anonymous_id_generated")

    return anonymous_id


def clear_privacy_cache() -> None:
    """Clear cached privacy settings (for testing)."""
    is_telemetry_enabled.cache_clear()


def get_privacy_status() -> dict[str, bool]:
    """Get current privacy status.

    Returns:
        Dict with privacy settings.
    """
    return {
        "telemetry_enabled": is_telemetry_enabled(),
        "opt_out_file_exists": TELEMETRY_OPT_OUT_FILE.exists(),
        "is_ci_environment": _is_ci_environment(),
        "env_var_set": bool(os.environ.get(TELEMETRY_ENV_VAR)),
    }


TELEMETRY_NOTICE = """\
bb2gh collects anonymous usage statistics to improve the tool.
No personal information is collected. Disable with:
  export BB2GH_TELEMETRY_ENABLED=false
  # or
  bb2gh config telemetry disable
"""


def show_telemetry_notice() -> None:
    """Show a one-time telemetry notice on first run.

    Prints the notice to stderr and creates a marker file so
    it is not shown again.
    """
    if TELEMETRY_NOTICE_FILE.exists():
        return

    import sys

    print(TELEMETRY_NOTICE, file=sys.stderr)

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TELEMETRY_NOTICE_FILE.touch()

    logger.debug("telemetry_notice_shown")
