"""Telemetry event definitions.

Defines all event types and their schemas.
"""

from __future__ import annotations

from typing import Any

from bb2gh.models.telemetry import (
    EventType,
    TelemetryEvent,
)


def create_session_start_event(anonymous_id: str) -> TelemetryEvent:
    """Create a session start event.

    Args:
        anonymous_id: Anonymous user ID.

    Returns:
        Session start event.
    """
    return TelemetryEvent(
        event_type=EventType.SESSION_START,
        anonymous_id=anonymous_id,
    )


def create_session_end_event(
    anonymous_id: str,
    duration_seconds: int = 0,
    commands_run: int = 0,
) -> TelemetryEvent:
    """Create a session end event.

    Args:
        anonymous_id: Anonymous user ID.
        duration_seconds: Session duration.
        commands_run: Number of commands run.

    Returns:
        Session end event.
    """
    return TelemetryEvent(
        event_type=EventType.SESSION_END,
        anonymous_id=anonymous_id,
        properties={
            "duration_seconds": duration_seconds,
            "commands_run": commands_run,
        },
    )


def create_error_event(
    anonymous_id: str,
    error_type: str,
    command: str | None = None,
) -> TelemetryEvent:
    """Create an error event.

    Note: Only records error type, never the message or stack trace.

    Args:
        anonymous_id: Anonymous user ID.
        error_type: Type/class of error.
        command: Command that caused the error.

    Returns:
        Error event.
    """
    properties: dict[str, Any] = {"error_type": error_type}
    if command:
        properties["command"] = command

    return TelemetryEvent(
        event_type=EventType.ERROR_OCCURRED,
        anonymous_id=anonymous_id,
        properties=properties,
    )


def create_feature_licensed_event(
    anonymous_id: str,
    feature: str,
) -> TelemetryEvent:
    """Create a feature licensed event.

    Args:
        anonymous_id: Anonymous user ID.
        feature: Feature that was licensed.

    Returns:
        Feature licensed event.
    """
    return TelemetryEvent(
        event_type=EventType.FEATURE_LICENSED,
        anonymous_id=anonymous_id,
        properties={"feature": feature},
    )


# Event schemas for documentation
EVENT_SCHEMAS = {
    EventType.COMMAND_START: {
        "description": "CLI command started",
        "properties": {
            "command": "string - Command name (e.g., 'migrate', 'validate')",
        },
    },
    EventType.COMMAND_SUCCESS: {
        "description": "CLI command completed successfully",
        "properties": {
            "command": "string - Command name",
            "duration_ms": "int - Duration in milliseconds",
        },
    },
    EventType.COMMAND_FAILURE: {
        "description": "CLI command failed",
        "properties": {
            "command": "string - Command name",
            "error_type": "string - Type of error (not message)",
        },
    },
    EventType.MIGRATION_START: {
        "description": "Migration operation started",
        "properties": {
            "repo_count_range": "string - Repository count range (1-10, 11-50, etc.)",
            "repo_count": "int - Exact repository count",
            "total_size_mb": "int - Aggregate size in megabytes",
            "repos_with_lfs": "int - Repos using LFS",
            "total_prs": "int - PRs to migrate",
            "branch_protection_rules": "int - Branch protection rules count",
            "source_type": "string - Source platform",
            "target_type": "string - Target platform",
        },
    },
    EventType.MIGRATION_SUCCESS: {
        "description": "Migration operation completed successfully",
        "properties": {
            "repo_count_range": "string - Repository count range",
            "duration_ms": "int - Duration in milliseconds",
            "repo_count": "int - Exact repository count",
            "repos_completed": "int - Repos completed successfully",
            "repos_failed": "int - Repos that failed",
            "total_size_mb": "int - Aggregate size in megabytes",
            "branches_migrated": "int - Branches migrated",
            "tags_migrated": "int - Tags migrated",
            "prs_migrated": "int - PRs migrated",
            "prs_failed": "int - PRs that failed",
            "comments_migrated": "int - Comments migrated",
            "lfs_repos_migrated": "int - LFS repos migrated",
            "protection_rules_created": "int - Branch protection rules created",
        },
    },
    EventType.MIGRATION_FAILURE: {
        "description": "Migration operation failed",
        "properties": {
            "repo_count_range": "string - Repository count range",
            "repo_count": "int - Exact repository count",
            "repos_completed": "int - Repos completed before failure",
            "repos_failed": "int - Repos that failed",
            "error_type": "string - Type of error",
            "duration_ms": "int - Duration in milliseconds",
        },
    },
    EventType.DISCOVERY_COMPLETED: {
        "description": "Discovery operation completed",
        "properties": {
            "repo_count": "int - Repos discovered",
            "total_size_mb": "int - Aggregate size in megabytes",
            "repos_with_lfs": "int - Repos using LFS",
            "complexity_simple": "int - Simple complexity repos",
            "complexity_moderate": "int - Moderate complexity repos",
            "complexity_complex": "int - Complex complexity repos",
            "total_prs": "int - Total PRs found",
        },
    },
    EventType.PLAN_CREATED: {
        "description": "Migration plan created",
        "properties": {
            "repo_count": "int - Repos in plan",
            "total_size_mb": "int - Aggregate size in megabytes",
            "repos_with_lfs": "int - Repos using LFS",
            "renamed_count": "int - Renamed repos",
            "repos_with_warnings": "int - Repos with warnings",
        },
    },
    EventType.VALIDATION_COMPLETED: {
        "description": "Validation operation completed",
        "properties": {
            "repos_validated": "int - Repos validated",
            "repos_passed": "int - Repos passed",
            "repos_failed": "int - Repos failed",
            "repos_warnings": "int - Repos with warnings",
            "branches_match_rate": "float - Branch match percentage",
            "tags_match_rate": "float - Tag match percentage",
            "prs_validated": "int - PRs validated",
            "comments_match_rate": "float - Comment match percentage",
        },
    },
    EventType.FEATURE_USED: {
        "description": "Feature was used",
        "properties": {
            "feature": "string - Feature name",
        },
    },
    EventType.FEATURE_LICENSED: {
        "description": "Enterprise feature was licensed",
        "properties": {
            "feature": "string - Feature name",
        },
    },
    EventType.ERROR_OCCURRED: {
        "description": "An error occurred",
        "properties": {
            "error_type": "string - Error type/class",
            "command": "string - Command that caused error (optional)",
        },
    },
    EventType.SESSION_START: {
        "description": "CLI session started",
        "properties": {},
    },
    EventType.SESSION_END: {
        "description": "CLI session ended",
        "properties": {
            "duration_seconds": "int - Session duration",
            "commands_run": "int - Number of commands run",
        },
    },
}


def get_event_schema(event_type: EventType) -> dict[str, Any]:
    """Get the schema for an event type.

    Args:
        event_type: Event type.

    Returns:
        Schema dictionary.
    """
    return EVENT_SCHEMAS.get(event_type, {})
