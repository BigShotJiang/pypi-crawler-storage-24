"""User model for bb2gh.

Represents a user from source or target systems.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class User(BaseModel):
    """User data model.

    Represents a user in source (Bitbucket) or target (GitHub) systems.
    Used for user mapping during migration.
    """

    model_config = ConfigDict(frozen=True)

    id: str = Field(description="Unique identifier in the source/target system")
    username: str = Field(
        description="Username/login. For Bitbucket users this holds the 'nickname' field "
        "(BB removed 'username' in 2019 GDPR). For GitHub users this is the 'login'."
    )
    display_name: str | None = Field(default=None, description="Display name")
    email: str | None = Field(default=None, description="Email address (if available)")
    avatar_url: str | None = Field(default=None, description="Avatar/profile image URL")

    source: Literal["bitbucket", "github"] = Field(description="Source system")

    # For user mapping during migration
    account_id: str | None = Field(default=None, description="Account ID (Bitbucket Cloud UUID)")
