"""Pipeline analysis models for bb2gh discovery.

Defines the schema for Bitbucket Pipeline analysis results including
per-step classification against GitHub Actions equivalents.
"""

from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field


class PipeSupportLevel(StrEnum):
    """Support level for a Bitbucket pipe's migration to GitHub Actions."""

    SUPPORTED = "supported"
    PARTIALLY_SUPPORTED = "partially_supported"
    UNSUPPORTED = "unsupported"
    SCRIPT = "script"


class PipelineMigrationComplexity(StrEnum):
    """Overall complexity of migrating a repository's pipelines to GitHub Actions."""

    TRIVIAL = "trivial"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class PipelineStepInfo(BaseModel):
    """A single step within a pipeline definition."""

    model_config = ConfigDict(extra="forbid")

    name: str | None = Field(default=None, description="Step name if provided")
    pipe: str | None = Field(
        default=None,
        description="Pipe reference (e.g. 'atlassian/aws-s3-deploy:0.6.0'), None for script steps",
    )
    support_level: PipeSupportLevel = Field(
        description="Migration support level for this step",
    )
    unsupported_options: list[str] = Field(
        default_factory=list,
        description="Pipe options that cannot be auto-converted",
    )
    gh_actions_equivalent: str | None = Field(
        default=None,
        description="Primary GitHub Actions equivalent (e.g. 'aws-actions/configure-aws-credentials')",
    )


class PipelineDefinitionInfo(BaseModel):
    """A single pipeline definition (e.g. 'default', 'branches/main')."""

    model_config = ConfigDict(extra="forbid")

    name: str = Field(description="Pipeline key (e.g. 'default', 'branches/main', 'custom/deploy')")
    trigger_type: str = Field(
        description="Trigger type: default, branch, tag, pull-request, custom, bookmark",
    )
    step_count: int = Field(ge=0, description="Number of steps in this pipeline")
    steps: list[PipelineStepInfo] = Field(
        default_factory=list,
        description="Steps in this pipeline",
    )
    uses_caches: bool = Field(default=False, description="Whether any step uses caches")
    uses_services: bool = Field(default=False, description="Whether any step uses services")
    uses_artifacts: bool = Field(default=False, description="Whether any step uses artifacts")
    uses_docker: bool = Field(
        default=False, description="Whether any step uses a custom Docker image"
    )
    uses_parallel: bool = Field(
        default=False, description="Whether pipeline has parallel step groups"
    )
    uses_conditions: bool = Field(default=False, description="Whether any step has conditions")
    uses_deployment: bool = Field(
        default=False, description="Whether any step references a deployment environment"
    )


class PipelineAnalysis(BaseModel):
    """Complete pipeline analysis for a repository."""

    model_config = ConfigDict(extra="forbid")

    has_pipelines: bool = Field(description="Whether the repository has a bitbucket-pipelines.yml")
    file_path: str = Field(
        default="bitbucket-pipelines.yml",
        description="Pipeline configuration file path",
    )
    pipeline_count: int = Field(default=0, ge=0, description="Number of pipeline definitions")
    total_step_count: int = Field(default=0, ge=0, description="Total steps across all pipelines")
    pipelines: list[PipelineDefinitionInfo] = Field(
        default_factory=list,
        description="Individual pipeline definitions",
    )

    # Aggregate step counts
    supported_step_count: int = Field(
        default=0, ge=0, description="Steps with full GH Actions support"
    )
    partially_supported_step_count: int = Field(
        default=0, ge=0, description="Steps with partial GH Actions support"
    )
    unsupported_step_count: int = Field(
        default=0, ge=0, description="Steps with no GH Actions equivalent"
    )
    script_step_count: int = Field(
        default=0, ge=0, description="Raw script steps (always convertible)"
    )

    # Feature usage flags
    uses_caches: bool = Field(default=False, description="Any pipeline uses caches")
    uses_services: bool = Field(default=False, description="Any pipeline uses services")
    uses_artifacts: bool = Field(default=False, description="Any pipeline uses artifacts")
    uses_deployment_environments: bool = Field(
        default=False, description="Any pipeline references deployment environments"
    )
    uses_parallel_steps: bool = Field(default=False, description="Any pipeline uses parallel steps")
    uses_conditions: bool = Field(default=False, description="Any pipeline uses conditional steps")

    # Assessment
    migration_complexity: PipelineMigrationComplexity = Field(
        default=PipelineMigrationComplexity.TRIVIAL,
        description="Overall migration complexity assessment",
    )
    migration_notes: list[str] = Field(
        default_factory=list,
        description="Human-readable migration notes",
    )
