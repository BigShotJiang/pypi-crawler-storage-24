"""State models for migration tracking.

Defines models for tracking migration progress, repository states,
and error information in the SQLite state store.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import StrEnum

from pydantic import BaseModel, Field


class RepositoryStatus(StrEnum):
    """Status of a repository in the migration."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class MigrationRunStatus(StrEnum):
    """Status of a migration run."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class RepositoryState(BaseModel):
    """State of a single repository in a migration run.

    Tracks the progress, timestamps, and error details for each
    repository being migrated.
    """

    # Identification
    source_id: str = Field(description="Source repository UUID")
    source_name: str = Field(description="Source repository name")
    source_full_name: str = Field(description="Full source path (workspace/repo)")
    target_full_name: str = Field(description="Full target path (org/repo)")

    # Status tracking
    status: RepositoryStatus = Field(
        default=RepositoryStatus.PENDING,
        description="Current migration status",
    )

    # Timestamps
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When the repository was added to the migration",
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When the repository state was last updated",
    )
    started_at: datetime | None = Field(
        default=None,
        description="When migration started for this repository",
    )
    completed_at: datetime | None = Field(
        default=None,
        description="When migration completed (success or failure)",
    )

    # Error tracking
    error_message: str | None = Field(
        default=None,
        description="Error message if migration failed",
    )
    error_traceback: str | None = Field(
        default=None,
        description="Full traceback if migration failed",
    )
    retry_count: int = Field(
        default=0,
        ge=0,
        description="Number of retry attempts",
    )

    # Metadata
    metadata: dict[str, str] | None = Field(
        default=None,
        description="Additional metadata (branches, tags, etc.)",
    )


class MigrationRecord(BaseModel):
    """Record of a migration run.

    Represents a single execution of a migration plan, tracking
    overall progress and status.
    """

    # Identification
    migration_id: str = Field(description="Unique migration run ID")
    plan_file: str = Field(description="Path to the migration plan file")

    # Source/target info
    source_workspace: str = Field(description="Source Bitbucket workspace")
    target_org: str = Field(description="Target GitHub organization")

    # Status
    status: MigrationRunStatus = Field(
        default=MigrationRunStatus.PENDING,
        description="Overall migration status",
    )

    # Progress tracking
    total_repos: int = Field(
        default=0,
        ge=0,
        description="Total repositories in the migration",
    )
    completed_repos: int = Field(
        default=0,
        ge=0,
        description="Successfully migrated repositories",
    )
    failed_repos: int = Field(
        default=0,
        ge=0,
        description="Failed repositories",
    )
    skipped_repos: int = Field(
        default=0,
        ge=0,
        description="Skipped repositories",
    )

    # Timestamps
    created_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When the migration was created",
    )
    updated_at: datetime = Field(
        default_factory=lambda: datetime.now(UTC),
        description="When the migration was last updated",
    )
    started_at: datetime | None = Field(
        default=None,
        description="When the migration started",
    )
    completed_at: datetime | None = Field(
        default=None,
        description="When the migration completed",
    )

    # Error tracking
    error_message: str | None = Field(
        default=None,
        description="Error message if migration failed",
    )
