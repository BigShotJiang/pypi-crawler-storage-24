"""Pydantic models for Bitbucket DC projects and repositories."""

from __future__ import annotations

from pydantic import BaseModel


class DCProject(BaseModel):
    """Bitbucket DC project."""

    key: str
    name: str | None = None
    description: str | None = None
    public: bool = False


class DCRepository(BaseModel):
    """Bitbucket DC repository (raw API shape)."""

    slug: str
    name: str | None = None
    description: str | None = None
    public: bool = False
    archived: bool = False
