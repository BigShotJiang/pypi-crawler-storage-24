"""Telemetry models for anonymous usage tracking."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any
from uuid import uuid4

from pydantic import BaseModel, Field


class EventType(StrEnum):
    """Telemetry event types."""

    # Command events
    COMMAND_START = "command_start"
    COMMAND_SUCCESS = "command_success"
    COMMAND_FAILURE = "command_failure"

    # Migration events
    MIGRATION_START = "migration_start"
    MIGRATION_SUCCESS = "migration_success"
    MIGRATION_FAILURE = "migration_failure"

    # Feature events
    FEATURE_USED = "feature_used"
    FEATURE_LICENSED = "feature_licensed"

    # Error events
    ERROR_OCCURRED = "error_occurred"

    # Discovery events
    DISCOVERY_COMPLETED = "discovery_completed"

    # Plan events
    PLAN_CREATED = "plan_created"

    # Validation events
    VALIDATION_COMPLETED = "validation_completed"

    # Session events
    SESSION_START = "session_start"
    SESSION_END = "session_end"


class RepoCountRange(StrEnum):
    """Repository count ranges for privacy."""

    RANGE_1_10 = "1-10"
    RANGE_11_50 = "11-50"
    RANGE_51_100 = "51-100"
    RANGE_100_PLUS = "100+"


def get_repo_count_range(count: int) -> RepoCountRange:
    """Get the range for a repository count.

    Args:
        count: Actual repository count.

    Returns:
        Range category.
    """
    if count <= 10:
        return RepoCountRange.RANGE_1_10
    elif count <= 50:
        return RepoCountRange.RANGE_11_50
    elif count <= 100:
        return RepoCountRange.RANGE_51_100
    else:
        return RepoCountRange.RANGE_100_PLUS


class TelemetryEvent(BaseModel):
    """A telemetry event.

    Contains only anonymous, non-PII data.
    """

    id: str = Field(default_factory=lambda: str(uuid4()))
    event_type: EventType
    timestamp: datetime = Field(default_factory=lambda: datetime.now())

    # Anonymous user ID (random, not tied to identity)
    anonymous_id: str = ""

    # Event properties (never contains PII)
    properties: dict[str, Any] = Field(default_factory=dict)

    # Context
    version: str = ""  # CLI version
    platform: str = ""  # os/platform

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for sending."""
        return {
            "id": self.id,
            "event": self.event_type.value,
            "timestamp": self.timestamp.isoformat(),
            "anonymous_id": self.anonymous_id,
            "properties": self.properties,
            "context": {
                "version": self.version,
                "platform": self.platform,
            },
        }


class TelemetryConfig(BaseModel):
    """Telemetry configuration."""

    enabled: bool = True
    anonymous_id: str = Field(default_factory=lambda: str(uuid4()))
    endpoint: str = "https://eu.i.posthog.com"
    api_key: str = "phc_i8O0de7YDSDBOMLssiutSiGXVFMslAXfwZb0XT2DzOo"
    batch_size: int = 10
    flush_interval_seconds: int = 60
    debug: bool = False

    # Feature flags
    collect_command_events: bool = True
    collect_migration_events: bool = True
    collect_feature_events: bool = True
    collect_error_events: bool = False  # Opt-in for error details

    @classmethod
    def from_env(cls) -> TelemetryConfig:
        """Create config with environment variable overrides."""
        import os

        config = cls()
        env_key = os.environ.get("BB2GH_POSTHOG_KEY")
        if env_key:
            config.api_key = env_key
        return config


class TelemetryStats(BaseModel):
    """Aggregated telemetry statistics (public-safe)."""

    total_migrations: int = 0
    repos_migrated_range: RepoCountRange | None = None
    total_commands: int = 0
    success_rate: float = 0.0
    popular_features: list[str] = Field(default_factory=list)

    # Time-based stats
    last_updated: datetime | None = None

    def to_public_dict(self) -> dict[str, Any]:
        """Convert to public-safe dictionary.

        Safe for exposure on landing page.
        """
        return {
            "total_migrations": self.total_migrations,
            "repos_migrated": self.repos_migrated_range.value
            if self.repos_migrated_range
            else None,
            "success_rate_percent": round(self.success_rate * 100, 1),
            "popular_features": self.popular_features[:5],
            "last_updated": self.last_updated.isoformat() if self.last_updated else None,
        }


class CommandEvent(TelemetryEvent):
    """Event for CLI command execution."""

    event_type: EventType = EventType.COMMAND_START

    @classmethod
    def start(cls, command: str, anonymous_id: str) -> CommandEvent:
        """Create a command start event.

        Args:
            command: Command name (e.g., "migrate", "validate").
            anonymous_id: Anonymous user ID.

        Returns:
            Command start event.
        """
        return cls(
            event_type=EventType.COMMAND_START,
            anonymous_id=anonymous_id,
            properties={"command": command},
        )

    @classmethod
    def success(cls, command: str, anonymous_id: str, duration_ms: int = 0) -> CommandEvent:
        """Create a command success event."""
        return cls(
            event_type=EventType.COMMAND_SUCCESS,
            anonymous_id=anonymous_id,
            properties={"command": command, "duration_ms": duration_ms},
        )

    @classmethod
    def failure(cls, command: str, anonymous_id: str, error_type: str = "") -> CommandEvent:
        """Create a command failure event."""
        return cls(
            event_type=EventType.COMMAND_FAILURE,
            anonymous_id=anonymous_id,
            properties={"command": command, "error_type": error_type},
        )


class MigrationEvent(TelemetryEvent):
    """Event for migration operations."""

    @classmethod
    def start(
        cls,
        anonymous_id: str,
        repo_count_range: RepoCountRange,
        *,
        repo_count: int = 0,
        total_size_mb: int = 0,
        repos_with_lfs: int = 0,
        total_prs: int = 0,
        branch_protection_rules: int = 0,
        source_type: str = "bitbucket",
        target_type: str = "github",
    ) -> MigrationEvent:
        """Create a migration start event."""
        return cls(
            event_type=EventType.MIGRATION_START,
            anonymous_id=anonymous_id,
            properties={
                "repo_count_range": repo_count_range.value,
                "repo_count": repo_count,
                "total_size_mb": total_size_mb,
                "repos_with_lfs": repos_with_lfs,
                "total_prs": total_prs,
                "branch_protection_rules": branch_protection_rules,
                "source_type": source_type,
                "target_type": target_type,
            },
        )

    @classmethod
    def success(
        cls,
        anonymous_id: str,
        repo_count_range: RepoCountRange,
        duration_ms: int = 0,
        *,
        repo_count: int = 0,
        repos_completed: int = 0,
        repos_failed: int = 0,
        total_size_mb: int = 0,
        branches_migrated: int = 0,
        tags_migrated: int = 0,
        prs_migrated: int = 0,
        prs_failed: int = 0,
        comments_migrated: int = 0,
        lfs_repos_migrated: int = 0,
        protection_rules_created: int = 0,
    ) -> MigrationEvent:
        """Create a migration success event."""
        return cls(
            event_type=EventType.MIGRATION_SUCCESS,
            anonymous_id=anonymous_id,
            properties={
                "repo_count_range": repo_count_range.value,
                "duration_ms": duration_ms,
                "repo_count": repo_count,
                "repos_completed": repos_completed,
                "repos_failed": repos_failed,
                "total_size_mb": total_size_mb,
                "branches_migrated": branches_migrated,
                "tags_migrated": tags_migrated,
                "prs_migrated": prs_migrated,
                "prs_failed": prs_failed,
                "comments_migrated": comments_migrated,
                "lfs_repos_migrated": lfs_repos_migrated,
                "protection_rules_created": protection_rules_created,
            },
        )

    @classmethod
    def failure(
        cls,
        anonymous_id: str,
        repo_count_range: RepoCountRange,
        *,
        repo_count: int = 0,
        repos_completed: int = 0,
        repos_failed: int = 0,
        error_type: str = "",
        duration_ms: int = 0,
    ) -> MigrationEvent:
        """Create a migration failure event."""
        return cls(
            event_type=EventType.MIGRATION_FAILURE,
            anonymous_id=anonymous_id,
            properties={
                "repo_count_range": repo_count_range.value,
                "repo_count": repo_count,
                "repos_completed": repos_completed,
                "repos_failed": repos_failed,
                "error_type": error_type,
                "duration_ms": duration_ms,
            },
        )


class DiscoveryEvent(TelemetryEvent):
    """Event for discovery operations."""

    @classmethod
    def completed(
        cls,
        anonymous_id: str,
        *,
        repo_count: int = 0,
        total_size_mb: int = 0,
        repos_with_lfs: int = 0,
        complexity_simple: int = 0,
        complexity_moderate: int = 0,
        complexity_complex: int = 0,
        total_prs: int = 0,
    ) -> DiscoveryEvent:
        """Create a discovery completed event."""
        return cls(
            event_type=EventType.DISCOVERY_COMPLETED,
            anonymous_id=anonymous_id,
            properties={
                "repo_count": repo_count,
                "total_size_mb": total_size_mb,
                "repos_with_lfs": repos_with_lfs,
                "complexity_simple": complexity_simple,
                "complexity_moderate": complexity_moderate,
                "complexity_complex": complexity_complex,
                "total_prs": total_prs,
            },
        )


class ValidationEvent(TelemetryEvent):
    """Event for validation operations."""

    @classmethod
    def completed(
        cls,
        anonymous_id: str,
        *,
        repos_validated: int = 0,
        repos_passed: int = 0,
        repos_failed: int = 0,
        repos_warnings: int = 0,
        branches_match_rate: float = 0.0,
        tags_match_rate: float = 0.0,
        prs_validated: int = 0,
        comments_match_rate: float = 0.0,
    ) -> ValidationEvent:
        """Create a validation completed event."""
        return cls(
            event_type=EventType.VALIDATION_COMPLETED,
            anonymous_id=anonymous_id,
            properties={
                "repos_validated": repos_validated,
                "repos_passed": repos_passed,
                "repos_failed": repos_failed,
                "repos_warnings": repos_warnings,
                "branches_match_rate": branches_match_rate,
                "tags_match_rate": tags_match_rate,
                "prs_validated": prs_validated,
                "comments_match_rate": comments_match_rate,
            },
        )


class PlanEvent(TelemetryEvent):
    """Event for plan operations."""

    @classmethod
    def created(
        cls,
        anonymous_id: str,
        *,
        repo_count: int = 0,
        total_size_mb: int = 0,
        repos_with_lfs: int = 0,
        renamed_count: int = 0,
        repos_with_warnings: int = 0,
    ) -> PlanEvent:
        """Create a plan created event.

        Args:
            anonymous_id: Anonymous user ID.
            repo_count: Number of repos in the plan.
            total_size_mb: Aggregate size in megabytes.
            repos_with_lfs: Repos using LFS.
            renamed_count: Number of renamed repos.
            repos_with_warnings: Repos with warnings.

        Returns:
            Plan created event.
        """
        return cls(
            event_type=EventType.PLAN_CREATED,
            anonymous_id=anonymous_id,
            properties={
                "repo_count": repo_count,
                "total_size_mb": total_size_mb,
                "repos_with_lfs": repos_with_lfs,
                "renamed_count": renamed_count,
                "repos_with_warnings": repos_with_warnings,
            },
        )


class FeatureEvent(TelemetryEvent):
    """Event for feature usage."""

    @classmethod
    def used(cls, anonymous_id: str, feature: str) -> FeatureEvent:
        """Create a feature used event."""
        return cls(
            event_type=EventType.FEATURE_USED,
            anonymous_id=anonymous_id,
            properties={"feature": feature},
        )
