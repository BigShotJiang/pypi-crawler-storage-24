"""License models for bb2gh.

Models for representing software licenses with three-tier licensing (Free/Pro/Ultimate).
"""

from __future__ import annotations

import json
from datetime import UTC, datetime, timedelta
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator


class Tier(StrEnum):
    """License tier levels."""

    FREE = "free"
    PRO = "pro"
    ULTIMATE = "ultimate"


class Feature(StrEnum):
    """Gatable features across license tiers."""

    # Core features (all tiers)
    DISCOVER = "discover"
    PLAN = "plan"
    MIGRATE_REPOS = "migrate_repos"
    MIGRATE_PRS = "migrate_prs"
    MIGRATE_COMMENTS = "migrate_comments"
    LFS = "lfs"
    ROLLBACK = "rollback"
    VALIDATE = "validate"

    # Pro+ features
    PARALLEL_WORKERS = "parallel_workers"

    # Ultimate only
    BATCH_WAVES = "batch_waves"
    SECRETS_MANAGEMENT = "secrets_management"
    DISTRIBUTED_WORKERS = "distributed_workers"
    COMPLIANCE_REPORTS = "compliance_reports"
    CLEANUP_MODULE = "cleanup_module"
    INFISICAL = "infisical"


class ExpiryStatus(StrEnum):
    """Expiry status of a license."""

    VALID = "valid"
    EXPIRING_SOON = "expiring_soon"  # Within 30 days
    EXPIRED = "expired"


# Features enabled for each tier
_CORE_FEATURES: frozenset[Feature] = frozenset(
    {
        Feature.DISCOVER,
        Feature.PLAN,
        Feature.MIGRATE_REPOS,
        Feature.MIGRATE_PRS,
        Feature.MIGRATE_COMMENTS,
        Feature.LFS,
        Feature.ROLLBACK,
        Feature.VALIDATE,
    }
)

TIER_FEATURES: dict[Tier, frozenset[Feature]] = {
    Tier.FREE: _CORE_FEATURES,
    Tier.PRO: _CORE_FEATURES | frozenset({Feature.PARALLEL_WORKERS}),
    Tier.ULTIMATE: frozenset(Feature),
}

# Default quantitative limits per tier (0 = unlimited)
# For Pro tier, this is the minimum default; actual Pro licenses carry the
# purchased repo count in limits.repos, which overrides this via _get_effective_limits().
TIER_LIMITS: dict[Tier, dict[str, int]] = {
    Tier.FREE: {"repos": 50, "workers": 1},
    Tier.PRO: {"repos": 50, "workers": 4},
    Tier.ULTIMATE: {"repos": 0, "workers": 0},
}

# Predefined repo breakpoints for Pro tier pricing slider.
# Used by license generation tool and website — enforcement reads limits.repos
# from the signed token, not from this constant.
PRO_REPO_BREAKPOINTS: tuple[int, ...] = (50, 100, 150, 200, 300, 500, 1000, 2000)

# Expiring-soon threshold
_EXPIRING_SOON_DAYS = 30


class LicensePayload(BaseModel):
    """Payload content of a license (signed data)."""

    model_config = ConfigDict(extra="forbid")

    v: int = 1  # Format version
    kid: str = Field(min_length=1)  # Key ID for rotation (e.g., "2026-01")
    lid: str = Field(min_length=1)  # Unique license ID (e.g., "lic_a1b2c3d4")
    tier: Tier
    org: str = Field(min_length=1)  # Organization name
    sub: str = Field(min_length=1)  # Subscriber email
    features: list[Feature] = Field(default_factory=list)
    exp: datetime  # Expiration timestamp
    iat: datetime | None = None  # Issued-at timestamp
    limits: dict[str, int] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)

    @field_validator("exp")
    @classmethod
    def _exp_must_be_tz_aware(cls, v: datetime) -> datetime:
        """Reject timezone-naive expiry datetimes."""
        if v.tzinfo is None or v.tzinfo.utcoffset(v) is None:
            msg = "exp must be timezone-aware (use UTC)"
            raise ValueError(msg)
        return v

    @field_validator("limits")
    @classmethod
    def _reject_negative_limits(cls, v: dict[str, int]) -> dict[str, int]:
        """Reject negative limit values (0 = unlimited, positive = cap)."""
        for key, value in v.items():
            if value < 0:
                msg = f"Limit '{key}' must be >= 0 (0 = unlimited), got {value}"
                raise ValueError(msg)
        return v

    def is_expired(self) -> bool:
        """Check if license is expired using tz-aware comparison."""
        return self.expiry_status() == ExpiryStatus.EXPIRED

    def expiry_status(self) -> ExpiryStatus:
        """Compute the expiry status of this license payload."""
        now = datetime.now(UTC)
        if now > self.exp:
            return ExpiryStatus.EXPIRED
        if self.exp - now <= timedelta(days=_EXPIRING_SOON_DAYS):
            return ExpiryStatus.EXPIRING_SOON
        return ExpiryStatus.VALID

    def has_feature(self, feature: Feature) -> bool:
        """Check if license includes a feature override."""
        return feature in self.features

    def to_canonical_json(self) -> str:
        """Serialize to deterministic JSON string for signing.

        Returns:
            Compact JSON string with sorted keys and no whitespace.
        """
        data = {
            "exp": self.exp.isoformat(),
            "features": [f.value for f in self.features],
            "iat": self.iat.isoformat() if self.iat else None,
            "kid": self.kid,
            "lid": self.lid,
            "limits": self.limits,
            "metadata": self.metadata,
            "org": self.org,
            "sub": self.sub,
            "tier": self.tier.value,
            "v": self.v,
        }
        return json.dumps(data, sort_keys=True, separators=(",", ":"))


class License(BaseModel):
    """A signed software license."""

    payload: LicensePayload
    signature: str  # Base64-encoded Ed25519 signature
    key_id: str | None = None  # Optional key identifier

    @property
    def org(self) -> str:
        """Get organization name."""
        return self.payload.org

    @property
    def sub(self) -> str:
        """Get subscriber email."""
        return self.payload.sub

    @property
    def tier(self) -> Tier:
        """Get license tier."""
        return self.payload.tier

    @property
    def features(self) -> list[Feature]:
        """Get enabled features."""
        return self.payload.features

    @property
    def exp(self) -> datetime:
        """Get expiration date."""
        return self.payload.exp

    @property
    def is_expired(self) -> bool:
        """Check if license is expired."""
        return self.payload.is_expired()

    @property
    def expiry_status(self) -> ExpiryStatus:
        """Get the expiry status of this license."""
        return self.payload.expiry_status()

    def has_feature(self, feature: Feature) -> bool:
        """Check if license includes a feature."""
        return self.payload.has_feature(feature)


class LicenseStatus(StrEnum):
    """Status of license validation."""

    VALID = "valid"
    EXPIRED = "expired"
    INVALID_SIGNATURE = "invalid_signature"
    NOT_FOUND = "not_found"
    PARSE_ERROR = "parse_error"


class LicenseInfo(BaseModel):
    """Information about current license status."""

    status: LicenseStatus
    license: License | None = None
    error: str | None = None

    @property
    def is_valid(self) -> bool:
        """Check if license is valid and active."""
        return self.status == LicenseStatus.VALID

    @property
    def expiry_status(self) -> ExpiryStatus | None:
        """Get the expiry status of the license, or None if no license."""
        if self.license is not None:
            return self.license.expiry_status
        return None

    def get_enabled_features(self) -> list[Feature]:
        """Get list of enabled features (tier-implied + explicit overrides).

        For a full evaluation that also accounts for license status (expired
        licenses fall back to FREE tier, invalid licenses get nothing), use
        ``bb2gh.licensing.features.get_enabled_features()`` instead.

        Returns:
            Sorted list of Feature values enabled by this license's tier
            plus any explicit feature overrides on the license payload.
            Empty list when no license is attached.
        """
        if self.license:
            tier_features = TIER_FEATURES.get(self.license.tier, frozenset())
            all_features = tier_features | set(self.license.features)
            return sorted(all_features, key=lambda f: f.value)
        return []

    def get_feature_overrides(self) -> list[Feature]:
        """Get only the explicit feature overrides on the license payload.

        These are features explicitly listed in the license's ``features``
        field, NOT the features implied by the tier.

        Returns:
            List of explicitly overridden Feature values, or empty list.
        """
        if self.license:
            return list(self.license.features)
        return []


class LicenseSyncMeta(BaseModel):
    """Metadata for CLI license sync throttling."""

    last_sync_check: datetime | None = None
    last_sync_result: str | None = None  # 'up_to_date' | 'updated' | 'error'

    def should_check(self, interval_hours: int = 24) -> bool:
        """Return True if enough time has passed since last check."""
        if self.last_sync_check is None:
            return True
        elapsed = datetime.now(UTC) - self.last_sync_check
        return elapsed.total_seconds() > interval_hours * 3600
