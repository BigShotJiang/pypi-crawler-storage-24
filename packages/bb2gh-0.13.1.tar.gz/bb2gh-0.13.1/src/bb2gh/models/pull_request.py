"""Pull Request models for bb2gh.

Models for representing and migrating Pull Requests from Bitbucket to GitHub.
"""

from __future__ import annotations

from datetime import datetime  # noqa: TC003
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class PRState(StrEnum):
    """State of a Pull Request."""

    OPEN = "open"
    MERGED = "merged"
    DECLINED = "declined"
    SUPERSEDED = "superseded"
    CLOSED = "closed"  # GitHub uses 'closed' for both merged and declined


class PRReviewerState(StrEnum):
    """State of a PR reviewer."""

    PENDING = "pending"
    APPROVED = "approved"
    CHANGES_REQUESTED = "changes_requested"


class PRActivityType(StrEnum):
    """Type of PR activity."""

    COMMENT = "comment"
    APPROVAL = "approval"
    CHANGES_REQUESTED = "changes_requested"
    UPDATE = "update"
    MERGE = "merge"
    DECLINE = "decline"


class PRAuthor(BaseModel):
    """Author of a Pull Request."""

    username: str
    display_name: str | None = None
    email: str | None = None
    account_id: str | None = None


class PRReviewer(BaseModel):
    """Reviewer on a Pull Request."""

    username: str
    display_name: str | None = None
    state: PRReviewerState = PRReviewerState.PENDING


class PRBranch(BaseModel):
    """Branch reference in a Pull Request."""

    name: str
    commit_hash: str | None = None
    repository: str | None = None  # For cross-repo PRs


class PullRequest(BaseModel):
    """A Pull Request from the source system."""

    id: str
    title: str
    description: str | None = None
    state: PRState
    author: PRAuthor
    source_branch: PRBranch
    target_branch: PRBranch
    reviewers: list[PRReviewer] = Field(default_factory=list)
    labels: list[str] = Field(default_factory=list)

    # Timestamps
    created_at: datetime | None = None
    updated_at: datetime | None = None
    merged_at: datetime | None = None
    closed_at: datetime | None = None

    # Merge info
    merge_commit_hash: str | None = None
    merged_by: str | None = None

    # Links
    html_url: str | None = None

    # Source metadata
    source_repo_full_name: str | None = None
    comment_count: int = 0

    # Decline info (for declined PRs)
    decline_reason: str | None = None

    @property
    def is_open(self) -> bool:
        """Check if PR is open."""
        return self.state == PRState.OPEN

    @property
    def is_merged(self) -> bool:
        """Check if PR is merged."""
        return self.state == PRState.MERGED

    @property
    def is_closed(self) -> bool:
        """Check if PR is closed (declined, merged, superseded)."""
        return self.state in (PRState.MERGED, PRState.DECLINED, PRState.SUPERSEDED, PRState.CLOSED)


class PRMigrationResult(BaseModel):
    """Result of migrating a single Pull Request."""

    source_pr_id: str
    source_pr_url: str | None = None
    target_pr_number: int | None = None
    target_pr_url: str | None = None
    success: bool = False
    error_message: str | None = None

    # Migration type (True if created as Issue because branch was missing)
    migrated_as_issue: bool = False

    # Attribution
    author_mapped: bool = False
    author_username: str | None = None
    attribution_note: str | None = None

    # Reviewers
    reviewers_requested: int = 0
    reviewers_skipped: int = 0

    # Labels
    labels_applied: int = 0

    # Comments migrated
    comments_migrated: int = 0


class PRMigrationStats(BaseModel):
    """Statistics for PR migration."""

    total: int = 0
    migrated: int = 0
    failed: int = 0
    skipped: int = 0

    # By state
    open_migrated: int = 0
    merged_migrated: int = 0
    declined_migrated: int = 0

    # By migration type
    migrated_as_prs: int = 0  # Created as actual PRs
    migrated_as_issues: int = 0  # Created as Issues (branch missing)

    # Details
    results: list[PRMigrationResult] = Field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Calculate success rate as percentage."""
        if self.total == 0:
            return 0.0
        return (self.migrated / self.total) * 100


class GitHubPRCreateRequest(BaseModel):
    """Request to create a PR in GitHub."""

    title: str
    body: str
    head: str  # Source branch
    base: str  # Target branch
    draft: bool = False
    maintainer_can_modify: bool = True


class GitHubPRResponse(BaseModel):
    """Response from creating a PR in GitHub."""

    number: int
    id: int
    html_url: str
    state: str
    title: str
    body: str | None = None
    head: dict[str, Any] | None = None
    base: dict[str, Any] | None = None
    created_at: str | None = None
    merged_at: str | None = None


class PRCommentType(StrEnum):
    """Type of PR comment."""

    GENERAL = "general"  # General PR comment (issue comment)
    INLINE = "inline"  # Code review inline comment
    REVIEW = "review"  # Review summary comment


class PRComment(BaseModel):
    """A comment on a Pull Request."""

    id: str
    content: str
    author: PRAuthor
    created_at: datetime | None = None
    updated_at: datetime | None = None
    comment_type: PRCommentType = PRCommentType.GENERAL

    # For inline comments
    file_path: str | None = None
    line_number: int | None = None
    commit_hash: str | None = None

    # Parent comment for replies
    parent_id: str | None = None

    # Links
    html_url: str | None = None


class PRActivity(BaseModel):
    """An activity event on a Pull Request."""

    id: str
    activity_type: PRActivityType
    author: PRAuthor
    created_at: datetime | None = None

    # For comment activities
    content: str | None = None

    # For update activities
    commit_hash: str | None = None

    # For inline comments
    file_path: str | None = None
    line_number: int | None = None

    # Link to original
    html_url: str | None = None


class PRCommentMigrationResult(BaseModel):
    """Result of migrating a single PR comment."""

    source_comment_id: str
    source_pr_id: str
    target_comment_id: int | None = None
    success: bool = False
    error_message: str | None = None

    # Attribution
    author_mapped: bool = False
    author_username: str | None = None


class PRCommentMigrationStats(BaseModel):
    """Statistics for PR comment migration."""

    total: int = 0
    migrated: int = 0
    failed: int = 0

    # By type
    general_migrated: int = 0
    inline_migrated: int = 0

    # Details
    results: list[PRCommentMigrationResult] = Field(default_factory=list)

    @property
    def success_rate(self) -> float:
        """Calculate success rate as percentage."""
        if self.total == 0:
            return 0.0
        return (self.migrated / self.total) * 100
