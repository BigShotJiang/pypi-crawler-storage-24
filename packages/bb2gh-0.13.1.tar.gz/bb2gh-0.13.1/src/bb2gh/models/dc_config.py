"""Configuration model for Bitbucket Data Center connections."""

from __future__ import annotations

from pydantic import BaseModel, field_validator


class DCConnectionConfig(BaseModel):
    """Connection configuration for Bitbucket Data Center."""

    base_url: str
    verify_ssl: str | bool = True

    @field_validator("base_url")
    @classmethod
    def _normalize_base_url(cls, value: str) -> str:
        return value.rstrip("/").removesuffix("/rest/api/1.0").removesuffix("/rest/api/latest")
