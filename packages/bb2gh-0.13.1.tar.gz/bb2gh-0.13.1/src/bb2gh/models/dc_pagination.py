"""Pydantic models for Bitbucket DC paginated responses."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field, field_validator


class DCPaginatedResponse(BaseModel):
    """Bitbucket DC paginated response envelope."""

    values: list[dict[str, Any]] = Field(default_factory=list)
    is_last_page: bool = Field(default=False, alias="isLastPage")
    next_page_start: int | None = Field(default=None, alias="nextPageStart")
    size: int | None = None

    model_config = {"populate_by_name": True}

    @field_validator("values", mode="before")
    @classmethod
    def _coerce_null_values(cls, v: Any) -> list[dict[str, Any]]:
        return v if v is not None else []

    @field_validator("is_last_page", mode="before")
    @classmethod
    def _coerce_string_bool(cls, v: Any) -> bool:
        if isinstance(v, str):
            return v.lower() == "true"
        return bool(v) if v is not None else False
