"""Worker models for parallel execution."""

from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class WorkerStatus(StrEnum):
    """Worker status values."""

    IDLE = "idle"
    RUNNING = "running"
    STOPPED = "stopped"
    ERROR = "error"


class TaskStatus(StrEnum):
    """Task status values."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    RETRY = "retry"


class TaskPriority(StrEnum):
    """Task priority levels."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    URGENT = "urgent"


class WorkerTask(BaseModel):
    """A task to be executed by a worker."""

    id: str
    repository: str
    task_type: str = "migrate"
    priority: TaskPriority = TaskPriority.NORMAL
    status: TaskStatus = TaskStatus.PENDING
    worker_id: str | None = None
    attempt: int = 0
    max_attempts: int = 3
    created_at: datetime = Field(default_factory=lambda: datetime.now())
    started_at: datetime | None = None
    completed_at: datetime | None = None
    error: str | None = None
    result: dict[str, Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    def mark_started(self, worker_id: str) -> None:
        """Mark task as started by a worker."""
        self.status = TaskStatus.IN_PROGRESS
        self.worker_id = worker_id
        self.started_at = datetime.now()
        self.attempt += 1

    def mark_completed(self, result: dict[str, Any] | None = None) -> None:
        """Mark task as completed."""
        self.status = TaskStatus.COMPLETED
        self.completed_at = datetime.now()
        self.result = result

    def mark_failed(self, error: str) -> None:
        """Mark task as failed."""
        self.completed_at = datetime.now()
        self.error = error
        if self.attempt < self.max_attempts:
            self.status = TaskStatus.RETRY
        else:
            self.status = TaskStatus.FAILED

    def can_retry(self) -> bool:
        """Check if task can be retried."""
        return self.status == TaskStatus.RETRY and self.attempt < self.max_attempts

    @property
    def duration(self) -> float | None:
        """Get task duration in seconds."""
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


class Worker(BaseModel):
    """A worker process for parallel execution."""

    id: str
    name: str
    status: WorkerStatus = WorkerStatus.IDLE
    current_task: WorkerTask | None = None
    tasks_completed: int = 0
    tasks_failed: int = 0
    started_at: datetime = Field(default_factory=lambda: datetime.now())
    last_heartbeat: datetime | None = None
    error: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def is_alive(self) -> bool:
        """Check if worker is alive."""
        return self.status in (WorkerStatus.IDLE, WorkerStatus.RUNNING)

    @property
    def is_busy(self) -> bool:
        """Check if worker is busy."""
        return self.status == WorkerStatus.RUNNING and self.current_task is not None

    def heartbeat(self) -> None:
        """Update last heartbeat time."""
        self.last_heartbeat = datetime.now()


class WorkerPoolStats(BaseModel):
    """Statistics for a worker pool."""

    total_workers: int = 0
    active_workers: int = 0
    idle_workers: int = 0
    stopped_workers: int = 0
    tasks_pending: int = 0
    tasks_in_progress: int = 0
    tasks_completed: int = 0
    tasks_failed: int = 0
    started_at: datetime | None = None
    current_rate_limit: float | None = None

    @property
    def total_tasks(self) -> int:
        """Get total task count."""
        return (
            self.tasks_pending + self.tasks_in_progress + self.tasks_completed + self.tasks_failed
        )

    @property
    def progress_percent(self) -> float:
        """Get progress as percentage."""
        if self.total_tasks == 0:
            return 0.0
        return (self.tasks_completed / self.total_tasks) * 100


class RateLimitState(BaseModel):
    """Shared rate limit state."""

    api_name: str
    tokens: float
    max_tokens: float
    refill_rate: float  # tokens per second
    last_refill: datetime = Field(default_factory=lambda: datetime.now())

    def refill(self) -> float:
        """Refill tokens based on elapsed time. Returns available tokens."""
        now = datetime.now()
        elapsed = (now - self.last_refill).total_seconds()
        self.tokens = min(self.max_tokens, self.tokens + elapsed * self.refill_rate)
        self.last_refill = now
        return self.tokens

    def consume(self, amount: float = 1.0) -> bool:
        """Try to consume tokens. Returns True if successful."""
        self.refill()
        if self.tokens >= amount:
            self.tokens -= amount
            return True
        return False

    def wait_time(self, amount: float = 1.0) -> float:
        """Get wait time in seconds to acquire tokens."""
        self.refill()
        if self.tokens >= amount:
            return 0.0
        needed = amount - self.tokens
        return needed / self.refill_rate
