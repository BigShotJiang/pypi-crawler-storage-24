"""Secret models for bb2gh.

Models for representing secrets and their inventories during migration.
"""

from __future__ import annotations

from datetime import datetime  # noqa: TC003 - needed at runtime by Pydantic
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, Field


class SecretType(StrEnum):
    """Type of secret."""

    PIPELINE_VARIABLE = "pipeline_variable"
    DEPLOYMENT_VARIABLE = "deployment_variable"
    WORKSPACE_VARIABLE = "workspace_variable"
    REPOSITORY_SECRET = "repository_secret"
    ENVIRONMENT_SECRET = "environment_secret"
    ORGANIZATION_SECRET = "organization_secret"


class SecretScope(StrEnum):
    """Scope of a secret."""

    REPOSITORY = "repository"
    ENVIRONMENT = "environment"
    WORKSPACE = "workspace"
    ORGANIZATION = "organization"


class SecretVisibility(StrEnum):
    """Visibility status of a secret."""

    SECURED = "secured"  # Value is hidden/encrypted
    PLAINTEXT = "plaintext"  # Value is visible (not recommended)


class Secret(BaseModel):
    """A secret from a platform (never contains actual values)."""

    name: str
    secret_type: SecretType
    scope: SecretScope
    visibility: SecretVisibility = SecretVisibility.SECURED

    # Context
    repository: str | None = None  # For repo-scoped secrets
    environment: str | None = None  # For environment-scoped secrets
    workspace: str | None = None  # For workspace-scoped secrets

    # Metadata
    description: str | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None

    def to_csv_row(self) -> dict[str, str]:
        """Convert to CSV row dict."""
        return {
            "name": self.name,
            "type": self.secret_type.value,
            "scope": self.scope.value,
            "visibility": self.visibility.value,
            "repository": self.repository or "",
            "environment": self.environment or "",
            "workspace": self.workspace or "",
            "description": self.description or "",
        }


class SecretInventory(BaseModel):
    """Inventory of secrets from a source platform."""

    source_workspace: str
    source_platform: str = "bitbucket"
    secrets: list[Secret] = Field(default_factory=list)
    discovered_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    @property
    def total_count(self) -> int:
        """Total number of secrets."""
        return len(self.secrets)

    @property
    def secured_count(self) -> int:
        """Number of secured secrets."""
        return sum(1 for s in self.secrets if s.visibility == SecretVisibility.SECURED)

    @property
    def by_scope(self) -> dict[str, int]:
        """Count secrets by scope."""
        counts: dict[str, int] = {}
        for secret in self.secrets:
            counts[secret.scope.value] = counts.get(secret.scope.value, 0) + 1
        return counts

    @property
    def by_type(self) -> dict[str, int]:
        """Count secrets by type."""
        counts: dict[str, int] = {}
        for secret in self.secrets:
            counts[secret.secret_type.value] = counts.get(secret.secret_type.value, 0) + 1
        return counts

    def get_repository_secrets(self, repo: str) -> list[Secret]:
        """Get secrets for a specific repository."""
        return [s for s in self.secrets if s.repository == repo]

    def get_environment_secrets(self, env: str) -> list[Secret]:
        """Get secrets for a specific environment."""
        return [s for s in self.secrets if s.environment == env]

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for JSON export."""
        return {
            "source_workspace": self.source_workspace,
            "source_platform": self.source_platform,
            "discovered_at": self.discovered_at.isoformat() if self.discovered_at else None,
            "summary": {
                "total": self.total_count,
                "secured": self.secured_count,
                "by_scope": self.by_scope,
                "by_type": self.by_type,
            },
            "secrets": [
                {
                    "name": s.name,
                    "type": s.secret_type.value,
                    "scope": s.scope.value,
                    "visibility": s.visibility.value,
                    "repository": s.repository,
                    "environment": s.environment,
                }
                for s in self.secrets
            ],
        }


class SecretMigrationStatus(StrEnum):
    """Status of a secret migration."""

    PENDING = "pending"
    SCAFFOLDED = "scaffolded"
    POPULATED = "populated"
    VERIFIED = "verified"
    FAILED = "failed"


class SecretMigrationItem(BaseModel):
    """Tracking item for secret migration checklist."""

    source_name: str
    source_type: SecretType
    source_scope: SecretScope
    target_scope: SecretScope
    target_name: str | None = None
    status: SecretMigrationStatus = SecretMigrationStatus.PENDING
    repository: str | None = None
    environment: str | None = None
    notes: str | None = None

    def to_csv_row(self) -> dict[str, str]:
        """Convert to CSV row for checklist."""
        return {
            "repo": self.repository or "",
            "secret_name": self.source_name,
            "secret_type": self.source_type.value,
            "source_scope": self.source_scope.value,
            "target_scope": self.target_scope.value,
            "status": self.status.value,
            "notes": self.notes or "",
        }


class SecretValidationResult(BaseModel):
    """Result of validating secrets between source and target."""

    source_count: int = 0
    target_count: int = 0
    missing_secrets: list[str] = Field(default_factory=list)  # In source but not target
    extra_secrets: list[str] = Field(default_factory=list)  # In target but not source
    scope_mismatches: list[str] = Field(default_factory=list)  # Wrong scope

    @property
    def is_valid(self) -> bool:
        """Check if validation passed."""
        return len(self.missing_secrets) == 0 and len(self.scope_mismatches) == 0

    @property
    def total_issues(self) -> int:
        """Total number of issues found."""
        return len(self.missing_secrets) + len(self.extra_secrets) + len(self.scope_mismatches)
