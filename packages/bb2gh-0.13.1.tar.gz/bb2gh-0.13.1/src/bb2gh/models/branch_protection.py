"""Branch protection models for bb2gh.

Models for representing Bitbucket Cloud branch restrictions,
GitHub Enterprise Cloud rulesets, and the mapping between them.
"""

from __future__ import annotations

from enum import StrEnum
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, Field, model_validator

if TYPE_CHECKING:
    from migration_core.models.github_rulesets import GitHubRulesetConfig, RulesetRule


def _rebuild_github_forward_refs() -> None:
    from migration_core.models.github_rulesets import GitHubRulesetConfig as _GitHubRulesetConfig
    from migration_core.models.github_rulesets import RulesetRule as _RulesetRule

    RestrictionMapping.model_rebuild(_types_namespace={"RulesetRule": _RulesetRule})
    BranchProtectionPlan.model_rebuild(
        _types_namespace={
            "GitHubRulesetConfig": _GitHubRulesetConfig,
            "RestrictionMapping": RestrictionMapping,
        }
    )


# ---------------------------------------------------------------------------
# Source Models (Bitbucket Cloud)
# ---------------------------------------------------------------------------


class BranchRestrictionKind(StrEnum):
    """Bitbucket Cloud branch restriction kind.

    All 16 valid `kind` values from the BB Cloud branch-restrictions API.
    """

    PUSH = "push"
    RESTRICT_MERGES = "restrict_merges"
    FORCE = "force"
    DELETE = "delete"
    REQUIRE_APPROVALS_TO_MERGE = "require_approvals_to_merge"
    REQUIRE_DEFAULT_REVIEWER_APPROVALS_TO_MERGE = "require_default_reviewer_approvals_to_merge"
    REQUIRE_PASSING_BUILDS_TO_MERGE = "require_passing_builds_to_merge"
    REQUIRE_TASKS_TO_BE_COMPLETED = "require_tasks_to_be_completed"
    REQUIRE_NO_CHANGES_REQUESTED = "require_no_changes_requested"
    REQUIRE_ALL_DEPENDENCIES_MERGED = "require_all_dependencies_merged"
    RESET_PULLREQUEST_APPROVALS_ON_CHANGE = "reset_pullrequest_approvals_on_change"
    SMART_RESET_PULLREQUEST_APPROVALS = "smart_reset_pullrequest_approvals"
    RESET_PULLREQUEST_CHANGES_REQUESTED_ON_CHANGE = "reset_pullrequest_changes_requested_on_change"
    REQUIRE_COMMITS_BEHIND = "require_commits_behind"
    ENFORCE_MERGE_CHECKS = "enforce_merge_checks"
    ALLOW_AUTO_MERGE_WHEN_BUILDS_PASS = "allow_auto_merge_when_builds_pass"


class BranchMatchKind(StrEnum):
    """How a branch restriction matches branches."""

    GLOB = "glob"
    BRANCHING_MODEL = "branching_model"


class BranchType(StrEnum):
    """Bitbucket branching model branch types."""

    FEATURE = "feature"
    BUGFIX = "bugfix"
    RELEASE = "release"
    HOTFIX = "hotfix"
    DEVELOPMENT = "development"
    PRODUCTION = "production"


class BranchRestrictionUser(BaseModel):
    """A user referenced in a Bitbucket branch restriction."""

    uuid: str
    display_name: str | None = None
    account_id: str | None = None


class BranchRestrictionGroup(BaseModel):
    """A group referenced in a Bitbucket branch restriction."""

    slug: str
    owner_username: str


class BranchRestriction(BaseModel):
    """A single Bitbucket Cloud branch restriction rule.

    Represents one entry from the ``/branch-restrictions`` API endpoint.
    """

    id: int
    kind: BranchRestrictionKind
    branch_match_kind: BranchMatchKind
    pattern: str | None = None
    branch_type: BranchType | None = None
    value: int | None = None
    users: list[BranchRestrictionUser] = Field(default_factory=list)
    groups: list[BranchRestrictionGroup] = Field(default_factory=list)

    @model_validator(mode="after")
    def _validate_match_kind_fields(self) -> BranchRestriction:
        """Ensure branching_model has branch_type, glob has pattern."""
        if self.branch_match_kind == BranchMatchKind.BRANCHING_MODEL:
            if self.branch_type is None:
                msg = "branch_type is required when branch_match_kind is 'branching_model'"
                raise ValueError(msg)
        elif self.branch_match_kind == BranchMatchKind.GLOB and self.pattern is None:
            msg = "pattern is required when branch_match_kind is 'glob'"
            raise ValueError(msg)
        return self


class DefaultReviewer(BaseModel):
    """A default reviewer from Bitbucket (repo or project level)."""

    uuid: str
    display_name: str | None = None
    reviewer_type: str = Field(
        description="Source level: 'repository' or 'project'",
    )


class RepoBranchProtection(BaseModel):
    """Container for all branch protection data for a single repository.

    Aggregates restrictions, branching model, and default reviewers.
    """

    repo_full_name: str
    restrictions: list[BranchRestriction] = Field(default_factory=list)
    branching_model: dict[str, Any] | None = None
    default_reviewers: list[DefaultReviewer] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Mapping Models
# ---------------------------------------------------------------------------


class MappingStatus(StrEnum):
    """Status of a BB → GH restriction mapping."""

    MAPPED = "mapped"
    APPROXIMATE = "approximate"
    UNMAPPED = "unmapped"
    IMPLICIT = "implicit"


class RestrictionMapping(BaseModel):
    """Mapping from a single BB restriction to a GH ruleset rule."""

    source: BranchRestriction
    target_rule: RulesetRule | None = None
    status: MappingStatus
    notes: str | None = None
    warnings: list[str] = Field(default_factory=list)


class BranchProtectionPlan(BaseModel):
    """Complete branch protection migration plan for one repository.

    Contains the source-to-target mapping and the generated rulesets.
    """

    source_repo: str
    target_repo: str
    mappings: list[RestrictionMapping] = Field(default_factory=list)
    rulesets: list[GitHubRulesetConfig] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    requires_manual_review: bool = False
    codeowners_content: str | None = None
    enable_auto_merge: bool = False


_rebuild_github_forward_refs()
