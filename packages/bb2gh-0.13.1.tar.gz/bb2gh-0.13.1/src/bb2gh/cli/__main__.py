"""Allow running the CLI package as a module: python -m bb2gh.cli."""

from bb2gh.cli.app import app

if __name__ == "__main__":
    app()
