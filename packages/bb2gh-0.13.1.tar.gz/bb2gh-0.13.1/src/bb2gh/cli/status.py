"""Status command implementation for bb2gh.

Shows migration progress from the SQLite state database.
"""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import Any

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_info
from bb2gh.models.state import MigrationRunStatus, RepositoryStatus

logger = structlog.get_logger(__name__)

# Default state database location
DEFAULT_STATE_DIR = Path(".bb2gh")
DEFAULT_STATE_DB = DEFAULT_STATE_DIR / "state.db"


async def _get_migration_status(
    migration_id: str | None,
    *,
    state_db: Path,
    failed_only: bool = False,
) -> dict[str, Any] | None:
    """Get migration status from state store.

    Args:
        migration_id: Migration ID to check. If None, get latest.
        state_db: Path to state database.
        failed_only: Only return failed repositories.

    Returns:
        Dictionary with migration status or None if not found.
    """
    from bb2gh.state.store import StateStore

    if not state_db.exists():
        return None

    async with StateStore(state_db) as store:
        if migration_id:
            migration = await store.get_migration(migration_id)
        else:
            # Get the most recent migration
            # For now, we need to know the plan file - this is a limitation
            return None

        if not migration:
            return None

        progress = await store.get_migration_progress(migration.migration_id)

        repos = []
        if failed_only:
            repos = await store.list_repositories(
                migration.migration_id,
                status=RepositoryStatus.FAILED,
            )
        else:
            repos = await store.list_repositories(migration.migration_id)

        return {
            "migration": migration,
            "progress": progress,
            "repositories": repos,
        }


def _print_migration_status(
    status: dict[str, Any],
    *,
    failed_only: bool = False,
) -> None:
    """Print migration status to console.

    Args:
        status: Migration status dictionary.
        failed_only: Whether to show only failed repos.
    """
    from rich.panel import Panel
    from rich.table import Table

    console = get_shared_console()
    migration = status["migration"]
    progress = status["progress"]
    repos = status["repositories"]

    # Overview panel
    overview = Table(show_header=False, box=None, padding=(0, 2))
    overview.add_column("Label", style="dim")
    overview.add_column("Value", style="cyan")

    overview.add_row("Migration ID", migration.migration_id)
    overview.add_row("Plan file", migration.plan_file)
    overview.add_row("Source", migration.source_workspace)
    overview.add_row("Target", migration.target_org)

    # Status with color
    status_color = {
        MigrationRunStatus.PENDING: "yellow",
        MigrationRunStatus.IN_PROGRESS: "cyan",
        MigrationRunStatus.COMPLETED: "green",
        MigrationRunStatus.FAILED: "red",
        MigrationRunStatus.CANCELLED: "dim",
    }.get(migration.status, "white")
    overview.add_row("Status", f"[{status_color}]{migration.status.value}[/{status_color}]")

    if migration.started_at:
        overview.add_row("Started", str(migration.started_at))
    if migration.completed_at:
        overview.add_row("Completed", str(migration.completed_at))

    console.print(Panel(overview, title="[bold]Migration Overview[/bold]", border_style="blue"))

    # Progress panel
    total = progress["total"]
    if total > 0:
        completed = progress["completed"]
        failed = progress["failed"]
        in_progress = progress["in_progress"]
        pending = progress["pending"]
        skipped = progress["skipped"]

        progress_table = Table(show_header=False, box=None, padding=(0, 2))
        progress_table.add_column("Label", style="dim")
        progress_table.add_column("Value")

        progress_table.add_row("Total", str(total))
        progress_table.add_row("Completed", f"[green]{completed}[/green]")
        if failed > 0:
            progress_table.add_row("Failed", f"[red]{failed}[/red]")
        else:
            progress_table.add_row("Failed", "0")
        progress_table.add_row("In Progress", f"[cyan]{in_progress}[/cyan]")
        progress_table.add_row("Pending", f"[yellow]{pending}[/yellow]")
        if skipped > 0:
            progress_table.add_row("Skipped", str(skipped))

        # Progress bar
        pct_complete = (completed + failed + skipped) / total * 100
        progress_table.add_row("Progress", f"{pct_complete:.1f}%")

        console.print(Panel(progress_table, title="[bold]Progress[/bold]", border_style="blue"))

    # Repository details (if any)
    if repos:
        title = (
            "[bold red]Failed Repositories[/bold red]"
            if failed_only
            else "[bold]Repositories[/bold]"
        )
        border = "red" if failed_only else "blue"

        repo_table = Table(show_header=True, box=None, padding=(0, 1))
        repo_table.add_column("Repository", style="cyan")
        repo_table.add_column("Status")
        repo_table.add_column("Target")
        if failed_only:
            repo_table.add_column("Error")
            repo_table.add_column("Retries")

        for repo in repos:
            status_color = {
                RepositoryStatus.PENDING: "yellow",
                RepositoryStatus.IN_PROGRESS: "cyan",
                RepositoryStatus.COMPLETED: "green",
                RepositoryStatus.FAILED: "red",
                RepositoryStatus.SKIPPED: "dim",
            }.get(repo.status, "white")

            if failed_only:
                repo_table.add_row(
                    repo.source_full_name,
                    f"[{status_color}]{repo.status.value}[/{status_color}]",
                    repo.target_full_name,
                    repo.error_message or "Unknown",
                    str(repo.retry_count),
                )
            else:
                repo_table.add_row(
                    repo.source_full_name,
                    f"[{status_color}]{repo.status.value}[/{status_color}]",
                    repo.target_full_name,
                )

        console.print(Panel(repo_table, title=title, border_style=border))


def run_status(
    migration_id: str,
    *,
    failed: bool = False,
    watch: bool = False,
    state_db: str | None = None,
) -> None:
    """Show migration status.

    Args:
        migration_id: Migration ID to check.
        failed: Show only failed repositories.
        watch: Live refresh status.
        state_db: Path to state database file.

    Raises:
        typer.Exit: On error.
    """
    console = get_shared_console()

    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    db_path = Path(state_db) if state_db else DEFAULT_STATE_DB

    if not db_path.exists():
        print_error(f"State database not found: {db_path}")
        print_info("Run a migration first to create the state database.")
        raise typer.Exit(1)

    def display_status() -> dict[str, Any] | None:
        """Display status once."""
        status = asyncio.run(
            _get_migration_status(
                migration_id,
                state_db=db_path,
                failed_only=failed,
            )
        )

        if status is None:
            print_error(f"Migration not found: {migration_id}")
            raise typer.Exit(1)

        _print_migration_status(status, failed_only=failed)
        return status

    if watch:
        console.print("[dim]Press Ctrl+C to exit watch mode[/dim]\n")
        try:
            while True:
                console.clear()
                status = display_status()

                if status is None:
                    break

                # Check if migration is complete
                migration = status["migration"]
                if migration.status in (
                    MigrationRunStatus.COMPLETED,
                    MigrationRunStatus.FAILED,
                    MigrationRunStatus.CANCELLED,
                ):
                    console.print("\n[dim]Migration finished. Exiting watch mode.[/dim]")
                    break

                time.sleep(2)  # Refresh every 2 seconds
        except KeyboardInterrupt:
            console.print("\n[dim]Watch mode interrupted.[/dim]")
    else:
        display_status()
