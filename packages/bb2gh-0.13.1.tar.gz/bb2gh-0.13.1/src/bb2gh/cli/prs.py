"""PR migration command implementation for bb2gh.

Migrate pull requests from Bitbucket to GitHub with full attribution.
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_info, print_success, progress_context

if TYPE_CHECKING:
    from rich.console import Console

    from bb2gh.adapters import GitHubCloudAdapter
    from bb2gh.adapters.base import BitbucketSourceAdapter
    from bb2gh.models.pull_request import PRMigrationResult
    from bb2gh.state.store import StateStore

logger = structlog.get_logger(__name__)


def _get_adapters() -> tuple[BitbucketSourceAdapter, GitHubCloudAdapter]:
    """Create source and target adapters from environment configuration.

    Uses credential resolver for source adapter dispatch (Cloud vs DC).

    Returns:
        Tuple of (source_adapter, target_adapter).

    Raises:
        ValueError: If required credentials are missing.
    """
    from bb2gh.cli.credential_resolver import (
        resolve_bitbucket_credentials,
        resolve_github_credentials,
    )
    from bb2gh.exceptions import ConfigurationError

    bb_creds = resolve_bitbucket_credentials()
    gh_creds = resolve_github_credentials()

    # GitHub target adapter
    from bb2gh.adapters import GitHubCloudAdapter

    gh_token = gh_creds.get("token")
    if not gh_token:
        raise ValueError("GitHub credentials not found. Set GH_TOKEN or GITHUB_TOKEN.")
    target = GitHubCloudAdapter(token=gh_token)

    # Source adapter dispatch
    from bb2gh.models.config import BB2GHSettings
    from bb2gh.services.ssl import resolve_ssl_verify

    settings = BB2GHSettings()
    ssl_verify = resolve_ssl_verify(settings.ssl_ca_bundle)

    if bb_creds.get("source_type") == "bitbucket-dc":
        from bb2gh.adapters.bitbucket_dc import BitbucketDCAdapter

        if bb_creds.get("auth_method") != "pat":
            raise ConfigurationError(
                "Bitbucket DC requires PAT authentication.\n"
                " Run 'bb2gh auth dc' or set BB_DC_TOKEN and BB_DC_URL."
            )
        source: BitbucketSourceAdapter = BitbucketDCAdapter(
            base_url=bb_creds["base_url"],
            token=bb_creds["token"],
            verify_ssl=bb_creds.get("ssl_verify", ssl_verify),
        )
    else:
        from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter

        if bb_creds.get("auth_method") == "api-token":
            source = BitbucketCloudAdapter(
                username=bb_creds.get("username", ""),
                api_token=bb_creds["api_token"],
                ssl_verify=ssl_verify,
            )
        elif bb_creds.get("auth_method") == "oauth2":
            source = BitbucketCloudAdapter(
                client_id=bb_creds["client_id"],
                client_secret=bb_creds["client_secret"],
                ssl_verify=ssl_verify,
            )
        else:
            raise ValueError(
                "Bitbucket credentials not found. Set BB_API_TOKEN or BB_APP_PASSWORD."
            )

    return source, target


async def _store_pr_migration_results(
    state_store: StateStore,
    migration_id: str,
    source_repo: str,
    target_repo: str,
    results: list[PRMigrationResult],
    pr_state: str = "open",
) -> None:
    """Store PR migration results in the state database.

    Args:
        state_store: State store instance.
        migration_id: Migration ID.
        source_repo: Source repository (workspace/repo).
        target_repo: Target repository (org/repo).
        results: List of PR migration results.
        pr_state: PR state (open, merged, declined).
    """
    for result in results:
        try:
            # Add the PR to tracking
            await state_store.add_pr_migration(
                migration_id=migration_id,
                source_repo=source_repo,
                target_repo=target_repo,
                source_pr_id=result.source_pr_id,
                source_pr_url=result.source_pr_url,
                pr_state=pr_state,
            )

            # Update with the result
            status = "completed" if result.success else "failed"
            await state_store.update_pr_migration_status(
                migration_id=migration_id,
                source_repo=source_repo,
                source_pr_id=result.source_pr_id,
                status=status,
                target_pr_number=result.target_pr_number,
                target_pr_url=result.target_pr_url,
                error_message=result.error_message,
                author_mapped=result.author_mapped,
                author_username=result.author_username,
            )
        except Exception as e:
            logger.warning("pr_state_store_error", source_pr_id=result.source_pr_id, error=str(e))


async def _migrate_open_prs(
    source_repo: str,
    target_repo: str,
    *,
    user_mapping_file: Path | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Migrate open PRs from Bitbucket to GitHub.

    Args:
        source_repo: Source repository (workspace/repo).
        target_repo: Target repository (org/repo).
        user_mapping_file: Optional user mapping CSV file.
        dry_run: If True, only preview without creating PRs.

    Returns:
        Migration stats dict.
    """
    from bb2gh.models.user_mapping import UserMappingStore
    from bb2gh.services.pr_migration import PRMigrationService

    source, target = _get_adapters()

    # Load user mapping if provided
    user_mapping = None
    if user_mapping_file and user_mapping_file.exists():
        user_mapping = UserMappingStore.from_csv(user_mapping_file)

    console = get_shared_console()

    async with source, target:
        service = PRMigrationService(
            source_adapter=source,
            target_adapter=target,
            user_mapping=user_mapping,
        )

        if dry_run:
            # Preview mode - just count PRs
            count = 0
            async for pr in service.fetch_open_prs(source_repo):
                count += 1
                console.print(
                    f"  PR #{pr.id}: {pr.title} "
                    f"([cyan]{pr.source_branch.name}[/cyan] → [green]{pr.target_branch.name}[/green])"
                )
            return {"total": count, "migrated": 0, "failed": 0, "dry_run": True}

        # Migrate PRs
        stats = await service.migrate_repository_prs(
            source_repo,
            target_repo,
            include_closed=False,
        )

        return {
            "total": stats.total,
            "migrated": stats.migrated,
            "failed": stats.failed,
            "open_migrated": stats.open_migrated,
            "results": stats.results,
        }


async def _migrate_closed_prs(
    source_repo: str,
    target_repo: str,
    *,
    user_mapping_file: Path | None = None,
    since: datetime | None = None,
    _gei_archive_url: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    """Migrate closed/merged PRs from Bitbucket to GitHub.

    Uses Enterprise Importer (GEI) for GitHub Enterprise targets when available,
    falls back to standard API with Issue fallback for regular GitHub.

    Args:
        source_repo: Source repository (workspace/repo).
        target_repo: Target repository (org/repo).
        user_mapping_file: Optional user mapping CSV file.
        since: Only migrate PRs updated after this date.
        _gei_archive_url: Base URL for GEI archive uploads (Enterprise only).
        dry_run: If True, only preview without creating PRs.

    Returns:
        Migration stats dict.
    """
    from bb2gh.models.user_mapping import UserMappingStore
    from bb2gh.services.pr_migration import PRMigrationService

    source, target = _get_adapters()

    # Load user mapping if provided
    user_mapping = None
    if user_mapping_file and user_mapping_file.exists():
        user_mapping = UserMappingStore.from_csv(user_mapping_file)

    console = get_shared_console()

    async with source, target:
        service = PRMigrationService(
            source_adapter=source,
            target_adapter=target,
            user_mapping=user_mapping,
        )

        if dry_run:
            # Preview mode - just count PRs
            count = 0
            async for pr in service.fetch_closed_prs(source_repo, since=since):
                count += 1
                state_color = "green" if pr.is_merged else "red"
                console.print(
                    f"  PR #{pr.id}: {pr.title} [{state_color}]{pr.state.value}[/{state_color}]"
                )
            return {"total": count, "migrated": 0, "failed": 0, "dry_run": True}

        # Manual migration of closed PRs
        from bb2gh.models.pull_request import PRMigrationStats

        stats = PRMigrationStats()
        pr_states: dict[str, str] = {}  # Track PR state for each PR ID

        async for pr in service.fetch_closed_prs(source_repo, since=since):
            stats.total += 1
            result = await service.create_closed_github_pr(pr, target_repo)
            stats.results.append(result)

            # Track PR state for state DB
            pr_states[result.source_pr_id] = "merged" if pr.is_merged else "declined"

            if result.success:
                stats.migrated += 1
                if pr.is_merged:
                    stats.merged_migrated += 1
                else:
                    stats.declined_migrated += 1
                # Track migration type
                if result.migrated_as_issue:
                    stats.migrated_as_issues += 1
                else:
                    stats.migrated_as_prs += 1
            else:
                stats.failed += 1

        return {
            "total": stats.total,
            "migrated": stats.migrated,
            "failed": stats.failed,
            "merged_migrated": stats.merged_migrated,
            "declined_migrated": stats.declined_migrated,
            "migrated_as_prs": stats.migrated_as_prs,
            "migrated_as_issues": stats.migrated_as_issues,
            "results": stats.results,
            "pr_states": pr_states,
        }


def run_migrate_prs(
    source_repo: str,
    target_repo: str,
    *,
    user_mapping: str | None = None,
    dry_run: bool = False,
) -> None:
    """Migrate open PRs from source to target.

    Args:
        source_repo: Source repository (workspace/repo).
        target_repo: Target repository (org/repo).
        user_mapping: Path to user mapping CSV file.
        dry_run: Preview without creating PRs.

    Raises:
        typer.Exit: On error.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    console = get_shared_console()

    console.print("\n[bold]Migrating open PRs[/bold]")
    console.print(f"  Source: [cyan]{source_repo}[/cyan]")
    console.print(f"  Target: [cyan]{target_repo}[/cyan]")
    if user_mapping:
        console.print(f"  User mapping: [cyan]{user_mapping}[/cyan]")
    if dry_run:
        console.print("  [yellow]DRY RUN - no changes will be made[/yellow]")
    console.print()

    try:
        mapping_path = Path(user_mapping) if user_mapping else None

        with progress_context(console=console) as progress:
            task = progress.add_task("[cyan]Migrating PRs...", total=None)

            stats = asyncio.run(
                _migrate_open_prs(
                    source_repo,
                    target_repo,
                    user_mapping_file=mapping_path,
                    dry_run=dry_run,
                )
            )

            progress.update(
                task,
                description=f"[green]Migration complete: {stats['migrated']}/{stats['total']}",
            )

        # Summary
        if dry_run:
            print_info(f"Would migrate {stats['total']} open PRs")
        else:
            _print_pr_summary(console, stats)

            if stats["failed"] > 0:
                print_error(f"{stats['failed']} PRs failed to migrate")
                raise typer.Exit(1)

            print_success(f"Migrated {stats['migrated']} PRs successfully!")

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except typer.Exit:
        raise
    except Exception as e:
        logger.exception("pr_migration_failed")
        print_error(f"PR migration failed: {e}")
        raise typer.Exit(2) from None


def run_migrate_closed_prs(
    source_repo: str,
    target_repo: str,
    *,
    user_mapping: str | None = None,
    since: str | None = None,
    dry_run: bool = False,
) -> None:
    """Migrate closed/merged PRs from source to target.

    Args:
        source_repo: Source repository (workspace/repo).
        target_repo: Target repository (org/repo).
        user_mapping: Path to user mapping CSV file.
        since: Only migrate PRs updated after this date (ISO format).
        dry_run: Preview without creating PRs.

    Raises:
        typer.Exit: On error.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    console = get_shared_console()

    # Parse since date
    since_dt = None
    if since:
        try:
            since_dt = datetime.fromisoformat(since)
        except ValueError:
            print_error(f"Invalid date format: {since}. Use ISO format (e.g., 2024-01-15)")
            raise typer.Exit(1) from None

    console.print("\n[bold]Migrating closed/merged PRs[/bold]")
    console.print(f"  Source: [cyan]{source_repo}[/cyan]")
    console.print(f"  Target: [cyan]{target_repo}[/cyan]")
    if user_mapping:
        console.print(f"  User mapping: [cyan]{user_mapping}[/cyan]")
    if since:
        console.print(f"  Since: [cyan]{since}[/cyan]")
    if dry_run:
        console.print("  [yellow]DRY RUN - no changes will be made[/yellow]")
    console.print()

    try:
        mapping_path = Path(user_mapping) if user_mapping else None

        with progress_context(console=console) as progress:
            task = progress.add_task("[cyan]Migrating closed PRs...", total=None)

            stats = asyncio.run(
                _migrate_closed_prs(
                    source_repo,
                    target_repo,
                    user_mapping_file=mapping_path,
                    since=since_dt,
                    dry_run=dry_run,
                )
            )

            progress.update(
                task,
                description=f"[green]Migration complete: {stats['migrated']}/{stats['total']}",
            )

        # Summary
        if dry_run:
            print_info(f"Would migrate {stats['total']} closed PRs")
        else:
            _print_pr_summary(console, stats, closed=True)

            if stats["failed"] > 0:
                print_error(f"{stats['failed']} PRs failed to migrate")
                raise typer.Exit(1)

            print_success(f"Migrated {stats['migrated']} closed PRs successfully!")

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except typer.Exit:
        raise
    except Exception as e:
        logger.exception("closed_pr_migration_failed")
        print_error(f"Closed PR migration failed: {e}")
        raise typer.Exit(2) from None


def run_migrate_all_prs(
    plan_file: str,
    *,
    user_mapping: str | None = None,
    include_closed: bool = False,
    dry_run: bool = False,
    state_db: str | None = None,
) -> None:
    """Migrate PRs for all repositories in a migration plan.

    Args:
        plan_file: Path to migration plan file.
        user_mapping: Path to user mapping CSV file.
        include_closed: Also migrate closed/merged PRs.
        dry_run: Preview without creating PRs.
        state_db: Path to state database for tracking migrations.

    Raises:
        typer.Exit: On error.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    from bb2gh.models.plan import MigrationPlan, MigrationStatus
    from bb2gh.state.store import StateStore

    console = get_shared_console()

    # Load plan
    plan_path = Path(plan_file)
    if not plan_path.exists():
        print_error(f"Plan file not found: {plan_file}")
        raise typer.Exit(1)

    try:
        plan = MigrationPlan.from_json_file(plan_path)
    except Exception as e:
        print_error(f"Failed to load plan: {e}")
        raise typer.Exit(1) from None

    # Get completed repositories (only migrate PRs for completed repos)
    completed_repos = [r for r in plan.repositories if r.status == MigrationStatus.COMPLETED]

    if not completed_repos:
        print_info("No completed repositories found in plan. Run 'bb2gh migrate' first.")
        raise typer.Exit(0)

    # Determine state DB path
    db_path = Path(state_db) if state_db else Path(".bb2gh") / "state.db"

    # Generate migration ID for PR tracking
    migration_id = f"pr_{uuid.uuid4().hex[:12]}"

    console.print("\n[bold]Batch PR Migration[/bold]")
    console.print(f"  Plan: [cyan]{plan_file}[/cyan]")
    console.print(f"  Repositories: [cyan]{len(completed_repos)}[/cyan] (completed)")
    console.print(f"  Migration ID: [cyan]{migration_id}[/cyan]")
    if user_mapping:
        console.print(f"  User mapping: [cyan]{user_mapping}[/cyan]")
    if include_closed:
        console.print("  [cyan]Including closed/merged PRs[/cyan]")
    if dry_run:
        console.print("  [yellow]DRY RUN - no changes will be made[/yellow]")
    console.print()

    mapping_path = Path(user_mapping) if user_mapping else None

    async def _run_batch_migration() -> dict[str, int]:
        """Async inner function for batch PR migration with state tracking."""
        total_prs = 0
        migrated_prs = 0
        failed_prs = 0
        migrated_as_prs = 0
        migrated_as_issues = 0
        merged_migrated = 0
        declined_migrated = 0
        repos_processed = 0

        async with StateStore(db_path) as state_store:
            # Create a migration record for PR migration tracking
            await state_store.create_migration(
                plan_file=plan_file,
                source_workspace=plan.metadata.source_workspace,
                target_org=plan.metadata.target_org,
                migration_id=migration_id,
            )

            with progress_context(console=console) as progress:
                task = progress.add_task(
                    f"[cyan]Migrating PRs for {len(completed_repos)} repositories...",
                    total=len(completed_repos),
                )

                for repo in completed_repos:
                    source_repo = repo.source_full_name
                    target_repo = repo.target_full_name

                    progress.update(
                        task,
                        description=f"[cyan]PRs: {source_repo}",
                    )

                    try:
                        # Migrate open PRs
                        stats = await _migrate_open_prs(
                            source_repo,
                            target_repo,
                            user_mapping_file=mapping_path,
                            dry_run=dry_run,
                        )
                        total_prs += stats.get("total", 0)
                        migrated_prs += stats.get("migrated", 0)
                        failed_prs += stats.get("failed", 0)
                        migrated_as_prs += stats.get("migrated", 0)

                        # Store open PR results in state DB
                        if not dry_run and stats.get("results"):
                            await _store_pr_migration_results(
                                state_store,
                                migration_id,
                                source_repo,
                                target_repo,
                                stats["results"],
                                pr_state="open",
                            )

                        # Migrate closed PRs if requested
                        if include_closed:
                            closed_stats = await _migrate_closed_prs(
                                source_repo,
                                target_repo,
                                user_mapping_file=mapping_path,
                                dry_run=dry_run,
                            )
                            total_prs += closed_stats.get("total", 0)
                            migrated_prs += closed_stats.get("migrated", 0)
                            failed_prs += closed_stats.get("failed", 0)
                            migrated_as_prs += closed_stats.get("migrated_as_prs", 0)
                            migrated_as_issues += closed_stats.get("migrated_as_issues", 0)
                            merged_migrated += closed_stats.get("merged_migrated", 0)
                            declined_migrated += closed_stats.get("declined_migrated", 0)

                            # Store closed PR results in state DB
                            logger.debug(
                                "closed_pr_results",
                                dry_run=dry_run,
                                results_count=len(closed_stats.get("results", [])),
                            )
                            if not dry_run and closed_stats.get("results"):
                                # Determine state for each result
                                for result in closed_stats["results"]:
                                    pr_state = closed_stats.get("pr_states", {}).get(
                                        result.source_pr_id, "closed"
                                    )
                                    await _store_pr_migration_results(
                                        state_store,
                                        migration_id,
                                        source_repo,
                                        target_repo,
                                        [result],
                                        pr_state=pr_state,
                                    )

                    except Exception as e:
                        logger.warning("pr_migration_failed", repo=source_repo, error=str(e))
                        console.print(
                            f"  [yellow]Warning: PR migration failed for {source_repo}: {e}[/yellow]"
                        )

                    repos_processed += 1
                    progress.update(task, completed=repos_processed)

        return {
            "total": total_prs,
            "migrated": migrated_prs,
            "failed": failed_prs,
            "migrated_as_prs": migrated_as_prs,
            "migrated_as_issues": migrated_as_issues,
            "merged_migrated": merged_migrated,
            "declined_migrated": declined_migrated,
            "repos_processed": repos_processed,
        }

    try:
        result = asyncio.run(_run_batch_migration())

        # Summary
        console.print()
        _print_pr_summary(console, result, closed=include_closed)

        if dry_run:
            print_info(
                f"Would migrate {result['total']} PRs across {result['repos_processed']} repositories"
            )
        elif result["failed"] > 0:
            print_error(f"{result['failed']} PRs failed to migrate")
            raise typer.Exit(1)
        else:
            print_success(
                f"Migrated {result['migrated']} PRs across {result['repos_processed']} repositories!"
            )

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except typer.Exit:
        raise
    except Exception as e:
        logger.exception("batch_pr_migration_failed")
        print_error(f"Batch PR migration failed: {e}")
        raise typer.Exit(2) from None


def _print_pr_summary(console: Console, stats: dict[str, Any], *, closed: bool = False) -> None:
    """Print PR migration summary.

    Args:
        console: Rich console.
        stats: Migration stats dict.
        closed: Whether these are closed PRs.
    """
    from rich.panel import Panel
    from rich.table import Table

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Label", style="dim")
    table.add_column("Value", style="cyan")

    table.add_row("Total PRs", str(stats["total"]))
    table.add_row("Migrated", f"[green]{stats['migrated']}[/green]")
    table.add_row("Failed", f"[red]{stats['failed']}[/red]" if stats["failed"] > 0 else "0")

    if closed:
        if "merged_migrated" in stats:
            table.add_row("Merged", str(stats.get("merged_migrated", 0)))
        if "declined_migrated" in stats:
            table.add_row("Declined", str(stats.get("declined_migrated", 0)))
        # Show migration type breakdown
        as_prs = stats.get("migrated_as_prs", 0)
        as_issues = stats.get("migrated_as_issues", 0)
        if as_prs > 0 or as_issues > 0:
            table.add_row("", "")  # Spacer
            table.add_row("[dim]Migration Type[/dim]", "")
            table.add_row("  As PRs", str(as_prs))
            if as_issues > 0:
                table.add_row("  As Issues", f"[yellow]{as_issues}[/yellow] (branch missing)")
    else:
        if "open_migrated" in stats:
            table.add_row("Open", str(stats.get("open_migrated", 0)))

    title = (
        "[bold]Closed PR Migration Summary[/bold]"
        if closed
        else "[bold]PR Migration Summary[/bold]"
    )
    console.print(Panel(table, title=title, border_style="blue"))

    # Show failed PRs
    if stats.get("failed", 0) > 0 and stats.get("results"):
        failed_table = Table(show_header=True, box=None, padding=(0, 2))
        failed_table.add_column("PR ID", style="cyan")
        failed_table.add_column("Error", style="red")

        for result in stats["results"]:
            if not result.success:
                failed_table.add_row(
                    result.source_pr_id,
                    result.error_message or "Unknown error",
                )

        console.print(
            Panel(failed_table, title="[bold red]Failed PRs[/bold red]", border_style="red")
        )
