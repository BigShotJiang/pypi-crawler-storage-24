"""Plan command implementation for bb2gh.

Generates a migration plan from a discovery inventory, with support for
filtering, renaming, and organization mapping.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import TYPE_CHECKING

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_info, print_success, print_warning
from bb2gh.exceptions import ConfigurationError, ValidationError

if TYPE_CHECKING:
    from rich.console import Console

    from bb2gh.models.inventory import Inventory, RepositoryInventoryItem
    from bb2gh.models.plan import MigrationPlan, RepositoryPlanItem

logger = structlog.get_logger(__name__)


def _load_inventory(path: str) -> Inventory:
    """Load inventory from a JSON file.

    Args:
        path: Path to inventory file.

    Returns:
        Loaded Inventory instance.

    Raises:
        ConfigurationError: If file doesn't exist or is invalid.
    """
    from bb2gh.models.inventory import Inventory

    inventory_path = Path(path)
    if not inventory_path.exists():
        raise ConfigurationError(f"Inventory file not found: {path}")

    try:
        return Inventory.from_json_file(inventory_path)
    except Exception as e:
        raise ConfigurationError(f"Invalid inventory file: {e}") from e


def _inventory_item_to_plan_item(
    item: RepositoryInventoryItem,
    *,
    target_org: str,
    rename_mappings: dict[str, str] | None = None,
    org_mappings: dict[str, str] | None = None,
) -> RepositoryPlanItem:
    """Convert an inventory item to a plan item.

    Args:
        item: Repository inventory item from discovery.
        target_org: Default target GitHub organization.
        rename_mappings: Optional dictionary of old_name -> new_name mappings.
        org_mappings: Optional dictionary of project -> org mappings.

    Returns:
        RepositoryPlanItem for the migration plan.
    """
    from bb2gh.models.plan import RepositoryPlanItem
    from bb2gh.services.planning import get_target_org_for_repo

    # Determine target org (may be overridden by project mapping)
    actual_target_org = get_target_org_for_repo(item.project, target_org, org_mappings)

    # Check for rename mapping
    rename_mappings = rename_mappings or {}
    renamed = item.name in rename_mappings
    target_name = rename_mappings.get(item.name, item.name)
    target_full_name = f"{actual_target_org}/{target_name}"

    return RepositoryPlanItem(
        source_id=item.id,
        source_name=item.name,
        source_full_name=item.full_name,
        source_workspace=item.workspace,
        source_project=item.project,
        source_clone_url=item.clone_url_https,
        target_name=target_name,
        target_org=actual_target_org,
        target_full_name=target_full_name,
        private=item.private,
        default_branch=item.default_branch,
        size_bytes=item.size_bytes,
        branch_count=item.branch_count,
        has_lfs=item.lfs.has_lfs if item.lfs else False,
        complexity_level=item.complexity.level.value if item.complexity else None,
        warnings=list(item.warnings),
        renamed=renamed,
        original_name=item.name if renamed else None,
    )


def _format_size(size_bytes: int | None) -> str:
    """Format size in bytes to human-readable string."""
    if size_bytes is None:
        return "unknown"
    if size_bytes >= 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
    elif size_bytes >= 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.2f} MB"
    elif size_bytes >= 1024:
        return f"{size_bytes / 1024:.2f} KB"
    return f"{size_bytes} B"


def _print_plan_preview(
    console: Console,
    plan: MigrationPlan,
) -> None:
    """Print a preview of the migration plan.

    Args:
        console: Rich console instance.
        plan: Migration plan to preview.
    """
    from rich.panel import Panel
    from rich.table import Table

    # Overview stats
    console.print()
    overview = Table(show_header=False, box=None, padding=(0, 2))
    overview.add_column("Label", style="dim")
    overview.add_column("Value", style="cyan")

    overview.add_row("Total repositories", str(plan.summary.total_repositories))
    overview.add_row("Total size", _format_size(plan.summary.total_size_bytes))
    overview.add_row("Private", str(plan.summary.private_count))
    overview.add_row("Public", str(plan.summary.public_count))

    if plan.summary.renamed_count > 0:
        overview.add_row("Renamed", str(plan.summary.renamed_count))

    console.print(Panel(overview, title="[bold]Plan Overview[/bold]", border_style="blue"))

    # Repository mapping table
    if plan.repositories:
        repo_table = Table(title="Repository Mappings", show_lines=False)
        repo_table.add_column("Source", style="cyan")
        repo_table.add_column("Target", style="green")
        repo_table.add_column("Size", justify="right")
        repo_table.add_column("Notes", style="dim")

        for repo in plan.repositories[:20]:  # Limit to first 20 for preview
            notes: list[str] = []
            if repo.renamed:
                notes.append("renamed")
            if repo.warnings:
                notes.append(f"{len(repo.warnings)} warnings")

            repo_table.add_row(
                repo.source_full_name,
                repo.target_full_name,
                _format_size(repo.size_bytes),
                ", ".join(notes) if notes else "",
            )

        if len(plan.repositories) > 20:
            repo_table.add_row(
                f"... and {len(plan.repositories) - 20} more",
                "",
                "",
                "",
            )

        console.print()
        console.print(repo_table)

    # Warnings summary
    if plan.summary.repos_with_warnings > 0:
        console.print()
        warnings_table = Table(show_header=False, box=None, padding=(0, 2))
        warnings_table.add_column("Issue", style="dim")
        warnings_table.add_column("Count", style="yellow", justify="right")

        warnings_table.add_row(
            "Repositories with warnings",
            str(plan.summary.repos_with_warnings),
        )
        warnings_table.add_row(
            "Total warnings",
            str(plan.summary.total_warnings),
        )

        console.print(
            Panel(warnings_table, title="[bold]Potential Issues[/bold]", border_style="yellow")
        )


def _print_validation_result(
    console: Console,
    plan: MigrationPlan,
) -> None:
    """Print validation results.

    Args:
        console: Rich console instance.
        plan: Migration plan with validation result.
    """
    if plan.validation is None:
        return

    console.print()
    if plan.validation.valid:
        print_success("Plan validation passed")
    else:
        print_error("Plan validation failed")

    if plan.validation.errors:
        console.print("\n[bold red]Errors (must be fixed):[/bold red]")
        for error in plan.validation.errors:
            console.print(f"  [red]\u2022[/red] {error}")

    if plan.validation.warnings:
        console.print("\n[bold yellow]Warnings (review recommended):[/bold yellow]")
        for warning in plan.validation.warnings:
            console.print(f"  [yellow]\u2022[/yellow] {warning}")


def run_plan(
    inventory: str,
    target_org: str,
    output: str,
    *,
    include_patterns: list[str] | None = None,
    exclude_patterns: list[str] | None = None,
    project_filter: str | None = None,
    rename_args: list[str] | None = None,
    rename_file: str | None = None,
    org_mapping_args: list[str] | None = None,
    preview: bool = False,
    check_target: bool = True,
    on_conflict: str = "fail",
) -> MigrationPlan | None:
    """Run the planning process.

    Args:
        inventory: Path to inventory file from discover.
        target_org: Default target GitHub organization.
        output: Output file path for migration plan.
        include_patterns: Glob patterns to include repositories.
        exclude_patterns: Glob patterns to exclude repositories.
        project_filter: Filter by Bitbucket project key.
        rename_args: List of 'old:new' rename specifications.
        rename_file: Path to CSV file with rename mappings.
        org_mapping_args: List of 'PROJECT:org' org mapping specifications.
        preview: If True, show preview without saving.
        check_target: If True, check if target repos exist in GitHub.
        on_conflict: Action when target exists: 'fail', 'skip', or 'update'.

    Returns:
        MigrationPlan if successful and not preview mode, None otherwise.

    Raises:
        typer.Exit: On error.
    """
    import asyncio
    import os

    from bb2gh.models.plan import MigrationPlan, MigrationStatus, ValidationResult
    from bb2gh.services.planning import (
        build_org_mappings,
        build_rename_mappings,
        check_target_repos_exist,
        filter_repositories,
        validate_org_mappings,
        validate_plan,
        validate_rename_mappings,
    )

    console = get_shared_console()

    console.print("\n[bold]Generating migration plan[/bold]")
    console.print(f"  Inventory: [cyan]{inventory}[/cyan]")
    console.print(f"  Target org: [cyan]{target_org}[/cyan]")
    if include_patterns:
        console.print(f"  Include: [cyan]{', '.join(include_patterns)}[/cyan]")
    if exclude_patterns:
        console.print(f"  Exclude: [cyan]{', '.join(exclude_patterns)}[/cyan]")
    if project_filter:
        console.print(f"  Project: [cyan]{project_filter}[/cyan]")
    if rename_args:
        console.print(f"  Renames: [cyan]{len(rename_args)} from CLI[/cyan]")
    if rename_file:
        console.print(f"  Rename file: [cyan]{rename_file}[/cyan]")
    if org_mapping_args:
        console.print(f"  Org mappings: [cyan]{len(org_mapping_args)} project(s)[/cyan]")
    if not preview:
        console.print(f"  Output: [cyan]{output}[/cyan]")
    else:
        console.print("  Mode: [cyan]preview (no file will be saved)[/cyan]")
    console.print()

    start_time = time.monotonic()

    try:
        # Check license before proceeding
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()

        # Load inventory
        print_info("Loading inventory...")
        inv = _load_inventory(inventory)
        print_success(f"Loaded {inv.summary.total_repositories} repositories from inventory")

        # Apply filters
        filtered_repos = filter_repositories(
            inv.repositories,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
            project_filter=project_filter,
        )

        if len(filtered_repos) < len(inv.repositories):
            print_info(
                f"Filtered to {len(filtered_repos)} repositories "
                f"(excluded {len(inv.repositories) - len(filtered_repos)})"
            )

        if not filtered_repos:
            print_warning("No repositories match the specified filters")
            raise typer.Exit(0)

        # Build org mappings
        org_mappings: dict[str, str] = {}
        if org_mapping_args:
            org_mappings = build_org_mappings(org_mapping_args)
            if org_mappings:
                print_info(f"Loaded {len(org_mappings)} org mappings")

                # Validate org mappings
                project_keys = {r.project for r in filtered_repos}
                warnings = validate_org_mappings(org_mappings, project_keys)
                for warning in warnings:
                    print_warning(warning)

        # Build rename mappings
        rename_mappings: dict[str, str] = {}
        if rename_args or rename_file:
            rename_mappings = build_rename_mappings(
                rename_args=rename_args,
                rename_file=rename_file,
            )
            if rename_mappings:
                print_info(f"Loaded {len(rename_mappings)} rename mappings")

                # Validate rename mappings
                repo_names = {r.name for r in filtered_repos}
                warnings = validate_rename_mappings(rename_mappings, repo_names)
                for warning in warnings:
                    print_warning(warning)

        # Convert inventory items to plan items
        plan_items: list[RepositoryPlanItem] = []
        for item in filtered_repos:
            plan_item = _inventory_item_to_plan_item(
                item,
                target_org=target_org,
                rename_mappings=rename_mappings,
                org_mappings=org_mappings,
            )
            plan_items.append(plan_item)

        # Check if target repos already exist in GitHub
        if check_target:
            github_token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
            if github_token:
                print_info("Checking target repositories in GitHub...")
                existing_repos = asyncio.run(check_target_repos_exist(plan_items, github_token))

                # Update plan items and handle conflicts
                existing_count = 0
                for plan_item in plan_items:
                    if existing_repos.get(plan_item.target_full_name, False):
                        plan_item.target_exists = True
                        existing_count += 1

                        if on_conflict == "skip":
                            plan_item.status = MigrationStatus.SKIPPED
                            plan_item.target_exists_action = "skip"
                            plan_item.warnings.append(
                                f"Target repo '{plan_item.target_full_name}' exists - will be skipped"
                            )
                        elif on_conflict == "update":
                            plan_item.target_exists_action = "update"
                            plan_item.warnings.append(
                                f"Target repo '{plan_item.target_full_name}' exists - will push updates"
                            )
                        else:  # fail
                            plan_item.target_exists_action = None

                if existing_count > 0:
                    if on_conflict == "fail":
                        print_error(
                            f"{existing_count} target repo(s) already exist in GitHub. "
                            "Use --on-conflict=skip to skip, --on-conflict=update to push, "
                            "or --rename 'repo:new-name' to use a different target name."
                        )
                    else:
                        print_warning(
                            f"{existing_count} target repo(s) already exist (action: {on_conflict})"
                        )
            else:
                print_warning(
                    "No GitHub token found - cannot check if target repos exist. "
                    "Set GH_TOKEN or GITHUB_TOKEN environment variable."
                )

        # Validate plan
        print_info("Validating plan...")
        validation_errors, validation_warnings = validate_plan(
            plan_items,
            inventory_items=filtered_repos,
        )

        # Create validation result
        validation = ValidationResult(
            valid=len(validation_errors) == 0,
            errors=validation_errors,
            warnings=validation_warnings,
        )

        # Create plan
        plan = MigrationPlan.from_repositories(
            plan_items,
            source_workspace=inv.metadata.workspace,
            target_org=target_org,
            inventory_file=inventory,
            source_type=inv.metadata.source_type,
            include_patterns=include_patterns,
            exclude_patterns=exclude_patterns,
            project_filter=project_filter,
            validation=validation,
        )

        # Print preview
        _print_plan_preview(console, plan)

        # Print validation results
        _print_validation_result(console, plan)

        # Check for validation errors
        if validation_errors:
            print_error(f"Plan has {len(validation_errors)} validation error(s) that must be fixed")
            if not preview:
                console.print("\n[dim]Plan was not saved due to validation errors[/dim]")
                raise typer.Exit(1)

        if preview:
            console.print("\n[dim]Preview mode - plan was not saved[/dim]")
            return None

        # Save plan
        plan.to_json_file(output)

        console.print()
        print_success("Plan generated successfully!")
        console.print(f"\n  Plan saved to: [green]{output}[/green]")

        logger.info(
            "plan_generated",
            inventory=inventory,
            target_org=target_org,
            repository_count=plan.summary.total_repositories,
            output_file=output,
        )

        # Emit telemetry
        from bb2gh.cli import telemetry_helpers

        elapsed_ms = int((time.monotonic() - start_time) * 1000)
        telemetry_helpers.emit_plan_created(
            repo_count=plan.summary.total_repositories,
            total_size_mb=(plan.summary.total_size_bytes or 0) // (1024 * 1024),
            renamed_count=plan.summary.renamed_count,
            repos_with_warnings=plan.summary.repos_with_warnings,
        )
        telemetry_helpers.emit_command_success("plan", duration_ms=elapsed_ms)

        return plan

    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except typer.Exit:
        # Re-raise typer.Exit without catching - it's an expected exit
        raise
    except ConfigurationError as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("plan", error_type="ConfigurationError")
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1) from None
    except ValidationError as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("plan", error_type="ValidationError")
        print_error(f"Validation error: {e}")
        raise typer.Exit(1) from None
    except Exception as e:
        from bb2gh.cli import telemetry_helpers

        telemetry_helpers.emit_command_failure("plan", error_type=type(e).__name__)
        logger.exception("plan_failed", inventory=inventory, target_org=target_org)
        print_error(f"Planning failed: {e}")
        raise typer.Exit(2) from None
