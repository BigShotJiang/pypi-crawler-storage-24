"""Global error handling for bb2gh CLI.

Provides consistent error display and exit code management.
"""

from __future__ import annotations

import sys
import traceback
from typing import TYPE_CHECKING

from bb2gh.cli.console import get_shared_console
from bb2gh.exceptions import BB2GHError, ExitCode

if TYPE_CHECKING:
    from types import TracebackType

    from rich.console import Console


def handle_exception(
    exc: BaseException,
    *,
    console: Console | None = None,
    debug: bool = False,
) -> int:
    """Handle an exception and return the appropriate exit code.

    Args:
        exc: The exception to handle.
        console: Optional Rich console for output.
        debug: If True, show full stack trace.

    Returns:
        Exit code for the CLI.
    """
    if console is None:
        console = get_shared_console()

    if isinstance(exc, BB2GHError):
        # Known bb2gh error - show user-friendly message
        console.print(f"[red]Error:[/red] {exc.message}")

        if debug:
            console.print("\n[dim]Stack trace:[/dim]")
            console.print(traceback.format_exc())

        return exc.exit_code

    # Unexpected error
    console.print(f"[red]Unexpected error:[/red] {exc}")

    if debug:
        console.print("\n[dim]Stack trace:[/dim]")
        console.print(traceback.format_exc())
    else:
        console.print("[dim]Run with --debug for more details.[/dim]")

    return ExitCode.SYSTEM_ERROR


def install_exception_handler(debug: bool = False) -> None:
    """Install a global exception handler for uncaught exceptions.

    Args:
        debug: If True, show full stack traces.
    """

    def handler(
        exc_type: type[BaseException],
        exc_value: BaseException,
        exc_tb: TracebackType | None,
    ) -> None:
        # Don't handle KeyboardInterrupt
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return

        exit_code = handle_exception(exc_value, debug=debug)
        sys.exit(exit_code)

    sys.excepthook = handler
