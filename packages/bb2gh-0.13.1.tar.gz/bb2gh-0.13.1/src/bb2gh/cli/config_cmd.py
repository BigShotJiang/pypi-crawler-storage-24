"""Config command for bb2gh CLI.

Provides `bb2gh config show` and `bb2gh config init` subcommands.
"""

from __future__ import annotations

from pathlib import Path  # noqa: TC003 - Path needed at runtime by Typer

import typer
import yaml  # type: ignore[import-untyped]

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_success, print_warning
from bb2gh.models.config import BB2GHSettings
from bb2gh.utils.config import config_to_display_dict, create_default_config, get_settings

config_app = typer.Typer(
    name="config",
    help="Manage bb2gh configuration.",
    no_args_is_help=True,
)


@config_app.command("show")
def show(
    config_file: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to config file. Defaults to ~/.bb2gh/config.yaml",
    ),
) -> None:
    """Show current configuration (secrets masked)."""
    console = get_shared_console()

    # Determine config file path
    if config_file is None:
        settings = BB2GHSettings()
        config_file = settings.config_file

    # Load settings
    settings = get_settings(config_file if config_file.exists() else None)

    # Show config file status
    if config_file.exists():
        console.print(f"[dim]Config file: {config_file}[/dim]")
    else:
        print_warning(f"No config file found at {config_file}")
        console.print("[dim]Using defaults and environment variables[/dim]")

    console.print()

    # Display configuration
    display_dict = config_to_display_dict(settings)
    console.print(yaml.dump(display_dict, default_flow_style=False, sort_keys=False))


@config_app.command("init")
def init(
    config_file: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to config file. Defaults to ~/.bb2gh/config.yaml",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite existing config file.",
    ),
) -> None:
    """Initialize a new configuration file with defaults."""
    console = get_shared_console()

    # Determine config file path
    if config_file is None:
        settings = BB2GHSettings()
        config_file = settings.config_file

    # Check if exists
    if config_file.exists() and not force:
        print_error(f"Config file already exists: {config_file}")
        console.print("Use --force to overwrite.")
        raise typer.Exit(1)

    # Remove existing file if force
    if config_file.exists() and force:
        config_file.unlink()

    # Create the config file
    create_default_config(config_file)
    print_success(f"Created config file: {config_file}")
    console.print("\nEdit this file to configure your Bitbucket and GitHub credentials.")
