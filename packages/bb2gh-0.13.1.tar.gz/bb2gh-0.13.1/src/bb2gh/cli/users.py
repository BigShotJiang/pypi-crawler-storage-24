"""Users command implementation for bb2gh.

Export, map, and manage user mappings for PR attribution.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from typing import TYPE_CHECKING

import structlog
import typer

from bb2gh.cli.console import get_shared_console
from bb2gh.cli.output import print_error, print_info, print_success, progress_context

if TYPE_CHECKING:
    from bb2gh.adapters.base import BitbucketSourceAdapter

logger = structlog.get_logger(__name__)


def _get_bitbucket_adapter() -> BitbucketSourceAdapter:
    """Create Bitbucket adapter using credential resolver (Cloud or DC)."""
    from bb2gh.cli.credential_resolver import resolve_bitbucket_credentials
    from bb2gh.exceptions import ConfigurationError
    from bb2gh.models.config import BB2GHSettings
    from bb2gh.services.ssl import resolve_ssl_verify

    creds = resolve_bitbucket_credentials()
    settings = BB2GHSettings()
    ssl_verify = resolve_ssl_verify(settings.ssl_ca_bundle)

    if creds.get("source_type") == "bitbucket-dc":
        from bb2gh.adapters.bitbucket_dc import BitbucketDCAdapter

        if creds.get("auth_method") != "pat":
            raise ConfigurationError(
                "Bitbucket DC requires PAT authentication.\n"
                " Run 'bb2gh auth dc' or set BB_DC_TOKEN and BB_DC_URL."
            )
        return BitbucketDCAdapter(
            base_url=creds["base_url"],
            token=creds["token"],
            verify_ssl=creds.get("ssl_verify", ssl_verify),
        )

    from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter

    if creds.get("auth_method") == "api-token":
        return BitbucketCloudAdapter(
            username=creds.get("username", ""),
            api_token=creds["api_token"],
            ssl_verify=ssl_verify,
        )
    elif creds.get("auth_method") == "oauth2":
        return BitbucketCloudAdapter(
            client_id=creds["client_id"],
            client_secret=creds["client_secret"],
            ssl_verify=ssl_verify,
        )
    else:
        raise ConfigurationError(
            "Bitbucket credentials not found.\n"
            " Run 'bb2gh auth login' or set BB_USERNAME and BB_API_TOKEN."
        )


async def _export_bitbucket_users(
    workspace: str,
    output: Path,
) -> int:
    """Export Bitbucket workspace users to CSV.

    Args:
        workspace: Bitbucket workspace slug.
        output: Output CSV file path.

    Returns:
        Number of users exported.
    """
    from bb2gh.services.user_mapping import UserMappingService

    adapter = _get_bitbucket_adapter()

    async with adapter:
        service = UserMappingService(source_adapter=adapter)
        users = await service.export_bitbucket_users(workspace)
        service.export_users_to_csv(users, output, source="bitbucket")
        return len(users)


async def _export_github_users(
    org: str,
    output: Path,
) -> int:
    """Export GitHub organization users to CSV.

    Args:
        org: GitHub organization name.
        output: Output CSV file path.

    Returns:
        Number of users exported.
    """
    from bb2gh.adapters import GitHubCloudAdapter
    from bb2gh.services.user_mapping import UserMappingService

    token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")

    if not token:
        raise ValueError("GitHub credentials not found. Set GH_TOKEN or GITHUB_TOKEN.")

    async with GitHubCloudAdapter(token=token) as adapter:
        service = UserMappingService(target_adapter=adapter)
        users = await service.export_github_users(org)
        service.export_users_to_csv(users, output, source="github")
        return len(users)


def run_export(
    source: str,
    *,
    workspace: str | None = None,
    org: str | None = None,
    output: str | None = None,
) -> None:
    """Export users from a platform.

    Args:
        source: Source platform ('bitbucket' or 'github').
        workspace: Bitbucket workspace (required for bitbucket).
        org: GitHub organization (required for github).
        output: Output CSV file path.

    Raises:
        typer.Exit: On error.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    console = get_shared_console()

    if source == "bitbucket":
        if not workspace:
            print_error("--workspace is required for Bitbucket export")
            raise typer.Exit(1)
        output_path = Path(output) if output else Path(f"users-bb-{workspace}.csv")
        target_name = workspace
    elif source == "github":
        if not org:
            print_error("--org is required for GitHub export")
            raise typer.Exit(1)
        output_path = Path(output) if output else Path(f"users-gh-{org}.csv")
        target_name = org
    else:
        print_error(f"Unknown source: {source}. Must be 'bitbucket' or 'github'.")
        raise typer.Exit(1)

    console.print(f"\n[bold]Exporting users from {source}[/bold]")
    console.print(f"  Target: [cyan]{target_name}[/cyan]")
    console.print(f"  Output: [cyan]{output_path}[/cyan]")
    console.print()

    try:
        with progress_context(console=console) as progress:
            task = progress.add_task(f"[cyan]Exporting {source} users...", total=None)

            if source == "bitbucket":
                assert workspace is not None  # validated above
                count = asyncio.run(_export_bitbucket_users(workspace, output_path))
            else:
                assert org is not None  # validated above
                count = asyncio.run(_export_github_users(org, output_path))

            progress.update(task, description=f"[green]Exported {count} users")

        print_success(f"Exported {count} users to {output_path}")

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except Exception as e:
        logger.exception("export_failed", source=source)
        print_error(f"Export failed: {e}")
        raise typer.Exit(2) from None


def run_map(
    bb_users: str,
    gh_users: str,
    *,
    output: str | None = None,
    load: str | None = None,
) -> None:
    """Generate or load user mappings.

    Args:
        bb_users: Path to Bitbucket users CSV.
        gh_users: Path to GitHub users CSV.
        output: Output path for mapping CSV.
        load: Path to existing mapping to load and update.

    Raises:
        typer.Exit: On error.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    from bb2gh.models.user_mapping import SourceUser, TargetUser
    from bb2gh.services.user_mapping import UserMappingService

    console = get_shared_console()

    bb_path = Path(bb_users)
    gh_path = Path(gh_users)

    if not bb_path.exists():
        print_error(f"Bitbucket users file not found: {bb_users}")
        raise typer.Exit(1)

    if not gh_path.exists():
        print_error(f"GitHub users file not found: {gh_users}")
        raise typer.Exit(1)

    output_path = Path(output) if output else Path("user-mapping.csv")

    console.print("\n[bold]Mapping users[/bold]")
    console.print(f"  Bitbucket users: [cyan]{bb_users}[/cyan]")
    console.print(f"  GitHub users: [cyan]{gh_users}[/cyan]")
    console.print(f"  Output: [cyan]{output_path}[/cyan]")

    if load:
        console.print(f"  Loading existing: [cyan]{load}[/cyan]")
    console.print()

    try:
        import csv

        # Load Bitbucket users
        bb_users_list = []
        with bb_path.open(encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                bb_users_list.append(
                    SourceUser(
                        username=row["username"],
                        email=row.get("email") or None,
                        display_name=row.get("display_name") or None,
                        account_id=row.get("account_id") or None,
                    )
                )

        # Load GitHub users
        gh_users_list = []
        with gh_path.open(encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                gh_users_list.append(
                    TargetUser(
                        username=row["username"],
                        email=row.get("email") or None,
                        name=row.get("name") or None,
                        id=int(row["id"]) if row.get("id") else None,
                    )
                )

        console.print(f"  Loaded {len(bb_users_list)} Bitbucket users")
        console.print(f"  Loaded {len(gh_users_list)} GitHub users")

        service = UserMappingService()

        if load:
            # Load existing mapping and update
            mappings = service.import_from_csv(Path(load))
            console.print(f"  Loaded {len(mappings)} existing mappings")
        else:
            # Auto-match users
            with progress_context(console=console) as progress:
                task = progress.add_task("[cyan]Matching users...", total=None)
                results = service.auto_match_users(bb_users_list, gh_users_list)
                mappings = service.results_to_mappings(results)
                progress.update(task, description="[green]Matching complete")

        # Validate mappings
        errors = service.validate_mappings(mappings)
        if errors:
            for error in errors:
                console.print(f"  [yellow]Warning: {error}[/yellow]")

        # Export mappings
        service.export_to_csv(mappings, output_path)

        # Summary
        from rich.table import Table

        table = Table(show_header=True, box=None, padding=(0, 2))
        table.add_column("Match Type", style="dim")
        table.add_column("Count", style="cyan")

        from collections import Counter

        type_counts = Counter(m.match_type.value for m in mappings)
        for match_type, count in sorted(type_counts.items()):
            table.add_row(match_type, str(count))

        console.print(table)

        mapped = sum(1 for m in mappings if m.is_mapped)
        unmapped = len(mappings) - mapped

        print_success(f"Created mapping with {mapped} matched, {unmapped} unmapped users")
        console.print(f"[dim]Edit {output_path} to manually map remaining users[/dim]")

    except Exception as e:
        logger.exception("mapping_failed")
        print_error(f"Mapping failed: {e}")
        raise typer.Exit(2) from None


def run_validate(
    mapping_file: str,
) -> None:
    """Validate a user mapping file.

    Args:
        mapping_file: Path to mapping CSV file.

    Raises:
        typer.Exit: On error.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    from bb2gh.services.user_mapping import UserMappingService

    console = get_shared_console()
    mapping_path = Path(mapping_file)

    if not mapping_path.exists():
        print_error(f"Mapping file not found: {mapping_file}")
        raise typer.Exit(1)

    console.print(f"\n[bold]Validating mapping[/bold]: [cyan]{mapping_file}[/cyan]")

    try:
        service = UserMappingService()
        mappings = service.import_from_csv(mapping_path)

        errors = service.validate_mappings(mappings)

        if errors:
            print_error(f"Found {len(errors)} validation errors:")
            for error in errors:
                console.print(f"  - {error}")
            raise typer.Exit(1)

        mapped = sum(1 for m in mappings if m.is_mapped)
        unmapped = len(mappings) - mapped

        console.print(f"  Total users: {len(mappings)}")
        console.print(f"  Mapped: [green]{mapped}[/green]")
        console.print(f"  Unmapped: [yellow]{unmapped}[/yellow]")

        print_success("Mapping file is valid!")

    except typer.Exit:
        raise
    except Exception as e:
        logger.exception("validation_failed")
        print_error(f"Validation failed: {e}")
        raise typer.Exit(2) from None


async def _export_mannequins(
    workspace: str,
    output: Path,
) -> int:
    """Export Bitbucket workspace users to mannequin CSV.

    Args:
        workspace: Bitbucket workspace slug.
        output: Output CSV file path.

    Returns:
        Number of users exported.
    """
    from bb2gh.adapters.bitbucket_cloud import BitbucketCloudAdapter
    from bb2gh.services.mannequin import MannequinService

    token = (
        os.environ.get("BB_API_TOKEN")
        or os.environ.get("BB_APP_PASSWORD")
        or os.environ.get("BITBUCKET_API_TOKEN")
        or os.environ.get("BITBUCKET_APP_PASSWORD")
    )
    username = os.environ.get("BB_USERNAME") or os.environ.get("BITBUCKET_USERNAME")

    if not token:
        raise ValueError("Bitbucket credentials not found. Set BB_API_TOKEN or BB_APP_PASSWORD.")

    cloud_adapter = BitbucketCloudAdapter(
        username=username or "",
        app_password=token,
    )
    async with cloud_adapter:
        # Fetch users from workspace
        users_data = []
        async for member in cloud_adapter.list_workspace_members(workspace):
            users_data.append(
                {
                    "source_username": member.get("username", member.get("account_id", "")),
                    "source_id": member.get("account_id", member.get("uuid", "")),
                    "display_name": member.get("display_name", ""),
                    "email": member.get("email", ""),
                }
            )

        if not users_data:
            return 0

        # Export CSV
        service = MannequinService()
        service.export_mannequin_csv(users_data, output)

        return len(users_data)


def run_export_mannequins(
    source_workspace: str,
    output: str = "mannequins.csv",
) -> None:
    """Export mannequin mapping CSV from Bitbucket workspace users.

    This generates a CSV file that can be used with 'gh gei reclaim-mannequin'
    after a GEI migration to properly attribute content to real GitHub users.

    Args:
        source_workspace: Bitbucket workspace to export users from.
        output: Output CSV file path.

    Raises:
        typer.Exit: On error.
    """
    # Check license before proceeding
    try:
        from bb2gh.licensing.decorators import LicenseRequiredError
        from bb2gh.licensing.features import require_license

        require_license()
    except LicenseRequiredError as e:
        print_error(str(e))
        raise typer.Exit(1) from None

    console = get_shared_console()
    output_path = Path(output)

    console.print("\n[bold]Exporting Mannequin Mapping CSV[/bold]")
    console.print(f"  Workspace: [cyan]{source_workspace}[/cyan]")
    console.print(f"  Output: [cyan]{output}[/cyan]")
    console.print()

    try:
        with progress_context(console=console) as progress:
            task = progress.add_task("[cyan]Exporting workspace users...", total=None)

            count = asyncio.run(_export_mannequins(source_workspace, output_path))

            progress.update(task, description=f"[green]Exported {count} users")

        if count == 0:
            print_info("No users found in workspace")
            return

        print_success(f"Exported {count} users to {output}")
        print_info(
            "Next steps:\n"
            "  1. Fill in the 'target-user' column with GitHub usernames\n"
            "  2. Run: gh gei reclaim-mannequin --csv " + output
        )

    except ValueError as e:
        print_error(str(e))
        raise typer.Exit(1) from None
    except Exception as e:
        logger.exception("mannequin_export_failed", workspace=source_workspace)
        print_error(f"Export failed: {e}")
        raise typer.Exit(2) from None
