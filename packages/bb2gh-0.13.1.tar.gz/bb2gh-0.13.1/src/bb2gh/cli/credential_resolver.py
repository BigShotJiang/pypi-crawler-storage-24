"""Credential resolution for CLI commands.

Resolution order:
1. Environment variables (highest priority)
2. OS keyring (via CredentialStore)
3. Profile config (non-secrets only)
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from bb2gh.models.config import MigrationProfile
    from bb2gh.services.credential_store import CredentialStore


def _get_credential_store() -> CredentialStore:
    """Create a CredentialStore with auto-detected backend."""
    from bb2gh.services.credential_store import CredentialStore

    return CredentialStore.auto_detect()


def _get_profile(profile_name: str) -> MigrationProfile | None:
    """Load a migration profile by name from the config file.

    Args:
        profile_name: Name of the profile to load.

    Returns:
        The MigrationProfile if found, or None.
    """
    from bb2gh.models.config import BB2GHSettings
    from bb2gh.utils.config import load_profiles_from_config

    settings = BB2GHSettings()
    profiles = load_profiles_from_config(settings.config_file)
    return profiles.get(profile_name)


def _resolve_dc_ssl_verify() -> str | bool:
    """Resolve SSL verification setting for Bitbucket DC from environment.

    Checks BB_DC_SSL_VERIFY first, then falls back to BB2GH_SSL_CA_BUNDLE.
    String values "true"/"false" are converted to booleans; anything else is
    treated as a CA bundle file path.

    Returns:
        True (default), False, or a string path to a CA bundle.
    """
    raw_ssl = os.environ.get("BB_DC_SSL_VERIFY") or None
    if raw_ssl is None:
        ca_bundle = os.environ.get("BB2GH_SSL_CA_BUNDLE") or None
        return ca_bundle if ca_bundle else True
    if raw_ssl.lower() == "true":
        return True
    if raw_ssl.lower() == "false":
        return False
    return raw_ssl  # Treat as CA bundle path


def resolve_bitbucket_credentials(
    *,
    profile_name: str = "default",
) -> dict[str, Any]:
    """Resolve Bitbucket credentials from all sources.

    Resolution order:
    1. Environment variables (BB_DC_TOKEN + BB_DC_URL for DC, or
       BB_USERNAME + BB_API_TOKEN / OAuth for Cloud)
    2. Profile keyring (via CredentialStore)
    3. Profile config file (non-secrets only)

    Args:
        profile_name: Name of the migration profile to consult.

    Returns:
        Dict with credential fields including ``source_type``, or empty dict
        if nothing found.
    """
    # 1a. Environment variables — DC PAT
    dc_token = os.environ.get("BB_DC_TOKEN")
    dc_url = os.environ.get("BB_DC_URL")
    if dc_token and dc_url:
        return {
            "token": dc_token,
            "base_url": dc_url,
            "auth_method": "pat",
            "source_type": "bitbucket-dc",
            "ssl_verify": _resolve_dc_ssl_verify(),
        }

    # 1b. Environment variables — Cloud API token / OAuth
    username = os.environ.get("BB_USERNAME") or os.environ.get("BITBUCKET_USERNAME")
    api_token = (
        os.environ.get("BB_API_TOKEN")
        or os.environ.get("BB_APP_PASSWORD")
        or os.environ.get("BITBUCKET_API_TOKEN")
        or os.environ.get("BITBUCKET_APP_PASSWORD")
    )
    client_id = os.environ.get("BB_CLIENT_ID") or os.environ.get("BITBUCKET_CLIENT_ID")
    client_secret = os.environ.get("BB_CLIENT_SECRET") or os.environ.get("BITBUCKET_CLIENT_SECRET")

    if username and api_token:
        return {
            "username": username,
            "api_token": api_token,
            "auth_method": "api-token",
            "source_type": "bitbucket-cloud",
        }
    if client_id and client_secret:
        return {
            "client_id": client_id,
            "client_secret": client_secret,
            "auth_method": "oauth2",
            "source_type": "bitbucket-cloud",
        }

    # 2. Profile + keyring
    profile = _get_profile(profile_name)
    if profile is None:
        return {}

    store = _get_credential_store()

    if profile.source.auth_method == "pat":
        kr_token = store.get_secret(f"bb2gh:{profile_name}:source:pat")
        if kr_token:
            return {
                "token": kr_token,
                "base_url": profile.source.base_url,
                "auth_method": "pat",
                "source_type": "bitbucket-dc",
                "ssl_verify": profile.source.ssl_verify,
            }
    elif profile.source.auth_method == "api-token":
        kr_token = store.get_secret(f"bb2gh:{profile_name}:source:api_token")
        if profile.source.username and kr_token:
            return {
                "username": profile.source.username,
                "api_token": kr_token,
                "auth_method": "api-token",
                "source_type": "bitbucket-cloud",
            }
    elif profile.source.auth_method == "oauth2":
        kr_secret = store.get_secret(f"bb2gh:{profile_name}:source:client_secret")
        if profile.source.client_id and kr_secret:
            return {
                "client_id": profile.source.client_id,
                "client_secret": kr_secret,
                "auth_method": "oauth2",
                "source_type": "bitbucket-cloud",
            }

    return {}


def resolve_github_credentials(
    *,
    profile_name: str = "default",
) -> dict[str, Any]:
    """Resolve GitHub credentials from all sources.

    Resolution order:
    1. Environment variables (GH_TOKEN / GITHUB_TOKEN, or App vars)
    2. Profile keyring (via CredentialStore)
    3. Profile config file (non-secrets only)

    Args:
        profile_name: Name of the migration profile to consult.

    Returns:
        Dict with credential fields, or empty dict if nothing found.
    """
    # 1. Environment variables — PAT
    token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    if token:
        return {"token": token, "auth_method": "pat"}

    # 1b. Environment variables — GitHub App
    app_id = os.environ.get("GH_APP_ID")
    private_key_env = os.environ.get("GH_APP_PRIVATE_KEY")
    private_key_file = os.environ.get("GH_APP_PRIVATE_KEY_FILE")
    installation_id = os.environ.get("GH_APP_INSTALLATION_ID")

    if app_id and installation_id and (private_key_env or private_key_file):
        result: dict[str, Any] = {
            "app_id": int(app_id),
            "installation_id": int(installation_id),
            "auth_method": "app",
        }
        if private_key_env:
            result["private_key"] = private_key_env
        elif private_key_file:
            from pathlib import Path

            key_path = Path(private_key_file).expanduser()
            if key_path.exists():
                result["private_key"] = key_path.read_text()
        return result

    # 2. Profile + keyring
    profile = _get_profile(profile_name)
    if profile is None:
        return {}

    store = _get_credential_store()

    if profile.target.auth_method == "pat":
        kr_token = store.get_secret(f"bb2gh:{profile_name}:target:token")
        if kr_token:
            return {"token": kr_token, "auth_method": "pat"}
    elif profile.target.auth_method == "app":
        if profile.target.app_id and profile.target.installation_id:
            result = {
                "app_id": profile.target.app_id,
                "installation_id": profile.target.installation_id,
                "auth_method": "app",
            }
            if profile.target.app_private_key_file:
                key_path = profile.target.app_private_key_file.expanduser()
                if key_path.exists():
                    result["private_key"] = key_path.read_text()
                    return result

    return {}


def store_dc_credentials(
    *,
    base_url: str,
    token: str,
    verify_ssl: str | bool,
    profile_name: str = "default",
    config_dir: Path | None = None,
) -> None:
    """Store DC credentials in keyring and profile config.

    Args:
        base_url: DC server base URL.
        token: Personal Access Token.
        verify_ssl: SSL verification setting (bool or CA bundle path).
        profile_name: Profile to store credentials under.
        config_dir: Config directory. Defaults to ~/.bb2gh.
    """
    from bb2gh.models.config import MigrationProfile, SourceProfile, TargetProfile
    from bb2gh.utils.config import save_profile_to_config

    store = _get_credential_store()
    store.set_secret(f"bb2gh:{profile_name}:source:pat", token)

    source_profile = SourceProfile(
        type="bitbucket-dc",
        auth_method="pat",
        base_url=base_url,
        ssl_verify=verify_ssl,
    )

    # Preserve existing target profile if present
    existing = _get_profile(profile_name)
    target_profile = existing.target if existing else TargetProfile()

    migration_profile = MigrationProfile(source=source_profile, target=target_profile)

    cfg_dir = config_dir if config_dir else Path.home() / ".bb2gh"
    config_path = cfg_dir / "config.yaml"
    save_profile_to_config(config_path, profile_name, migration_profile)
