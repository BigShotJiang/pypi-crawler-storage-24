"""Output helpers for bb2gh CLI.

Provides consistent formatting for progress bars, tables, and status messages.
"""

from __future__ import annotations

import json
from contextlib import contextmanager
from typing import IO, TYPE_CHECKING, Any, Protocol, runtime_checkable

from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskID,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
    TimeRemainingColumn,
)
from rich.table import Table

from bb2gh.cli.console import get_shared_console

if TYPE_CHECKING:
    from collections.abc import Iterator, Sequence

    from rich.console import Console


def print_success(message: str, *, console: Console | None = None) -> None:
    """Print a success message in green.

    Args:
        message: The message to print.
        console: Optional console instance. Uses shared console if not provided.
    """
    if console is None:
        console = get_shared_console()
    console.print(f"[green]{message}[/green]")


def print_error(message: str, *, console: Console | None = None) -> None:
    """Print an error message in red.

    Args:
        message: The message to print.
        console: Optional console instance. Uses shared console if not provided.
    """
    if console is None:
        console = get_shared_console()
    console.print(f"[red]{message}[/red]")


def print_warning(message: str, *, console: Console | None = None) -> None:
    """Print a warning message in yellow.

    Args:
        message: The message to print.
        console: Optional console instance. Uses shared console if not provided.
    """
    if console is None:
        console = get_shared_console()
    console.print(f"[yellow]{message}[/yellow]")


def print_info(message: str, *, console: Console | None = None) -> None:
    """Print an info message in blue.

    Args:
        message: The message to print.
        console: Optional console instance. Uses shared console if not provided.
    """
    if console is None:
        console = get_shared_console()
    console.print(f"[blue]{message}[/blue]")


def status_table(
    title: str,
    columns: Sequence[str],
    rows: Sequence[dict[str, Any]],
    row_key_order: Sequence[str],
) -> Table:
    """Create a Rich table for displaying status information.

    Args:
        title: The table title.
        columns: Column header names.
        rows: List of row data as dictionaries.
        row_key_order: Keys to extract from each row dict, in column order.

    Returns:
        A configured Rich Table instance.
    """
    table = Table(title=title)

    for column in columns:
        table.add_column(column)

    for row in rows:
        values = [str(row.get(key, "")) for key in row_key_order]
        table.add_row(*values)

    return table


@contextmanager
def progress_context(
    *,
    console: Console | None = None,
    transient: bool = False,
) -> Iterator[Progress]:
    """Create a progress bar context manager.

    Args:
        console: Optional console instance. Uses shared console if not provided.
        transient: If True, progress bar disappears after completion.

    Yields:
        A Rich Progress instance for tracking progress.

    Example:
        with progress_context() as progress:
            task = progress.add_task("Processing...", total=100)
            for i in range(100):
                # do work
                progress.advance(task)
    """
    if console is None:
        console = get_shared_console()

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
        transient=transient,
    )

    with progress:
        yield progress


@runtime_checkable
class MigrationProgressCallback(Protocol):
    """Protocol for services to report migration progress.

    Defines the interface for progress reporting at three nested levels:
    repository, pull request, and comments.
    """

    def start_repo(self, repo_name: str, repo_index: int, total_repos: int) -> None:
        """Signal the start of migrating a repository.

        Args:
            repo_name: Name of the repository being migrated.
            repo_index: 1-based index of the current repository.
            total_repos: Total number of repositories to migrate.
        """
        ...

    def start_pr(self, pr_title: str, pr_index: int, total_prs: int) -> None:
        """Signal the start of migrating a pull request.

        Args:
            pr_title: Title of the pull request being migrated.
            pr_index: 1-based index of the current PR within the repo.
            total_prs: Total number of PRs in the current repo.
        """
        ...

    def advance_comments(self, count: int = 1) -> None:
        """Advance the comment migration progress.

        Args:
            count: Number of comments to advance by. Defaults to 1.
        """
        ...

    def set_comment_total(self, total: int) -> None:
        """Set the total number of comments for the current PR.

        Args:
            total: Total number of comments to migrate for this PR.
        """
        ...

    def finish_pr(self) -> None:
        """Signal that the current PR migration is complete."""
        ...

    def finish_repo(self) -> None:
        """Signal that the current repo migration is complete."""
        ...


class _RichProgressCallback:
    """Rich-based implementation of MigrationProgressCallback.

    Displays a nested progress UI with three levels:
    - Top: ``[Repo X/N] repo-name``
    - Middle: ``[PR Y/M] PR title``
    - Bottom: ``[Comments Z/K]``
    """

    def __init__(self, progress: Progress) -> None:
        self._progress = progress
        self._repo_task_id: TaskID | None = None
        self._pr_task_id: TaskID | None = None
        self._comment_task_id: TaskID | None = None

    def start_repo(self, repo_name: str, repo_index: int, total_repos: int) -> None:
        """Signal the start of migrating a repository."""
        description = f"[bold blue]\\[Repo {repo_index}/{total_repos}] {repo_name}"
        if self._repo_task_id is not None:
            self._progress.update(
                self._repo_task_id,
                description=description,
                total=total_repos,
                completed=repo_index - 1,
            )
        else:
            self._repo_task_id = self._progress.add_task(
                description,
                total=total_repos,
                completed=repo_index - 1,
            )

    def start_pr(self, pr_title: str, pr_index: int, total_prs: int) -> None:
        """Signal the start of migrating a pull request."""
        # Truncate long PR titles
        display_title = pr_title[:50] + "..." if len(pr_title) > 50 else pr_title
        description = f"  [cyan]\\[PR {pr_index}/{total_prs}] {display_title}"
        if self._pr_task_id is not None:
            self._progress.update(
                self._pr_task_id,
                description=description,
                total=total_prs,
                completed=pr_index - 1,
            )
        else:
            self._pr_task_id = self._progress.add_task(
                description,
                total=total_prs,
                completed=pr_index - 1,
            )
        # Reset comment task for new PR
        if self._comment_task_id is not None:
            self._progress.update(
                self._comment_task_id,
                description="    [dim]\\[Comments]",
                total=0,
                completed=0,
                visible=True,
            )

    def advance_comments(self, count: int = 1) -> None:
        """Advance the comment migration progress."""
        if self._comment_task_id is not None:
            self._progress.advance(self._comment_task_id, advance=count)

    def set_comment_total(self, total: int) -> None:
        """Set the total number of comments for the current PR."""
        description = f"    [dim]\\[Comments 0/{total}]"
        if self._comment_task_id is not None:
            self._progress.update(
                self._comment_task_id,
                description=description,
                total=total,
                completed=0,
            )
        else:
            self._comment_task_id = self._progress.add_task(
                description,
                total=total,
                completed=0,
            )

    def finish_pr(self) -> None:
        """Signal that the current PR migration is complete."""
        if self._pr_task_id is not None:
            completed = self._progress.tasks[self._pr_task_id].completed
            self._progress.update(self._pr_task_id, completed=completed + 1)

    def finish_repo(self) -> None:
        """Signal that the current repo migration is complete."""
        if self._repo_task_id is not None:
            completed = self._progress.tasks[self._repo_task_id].completed
            self._progress.update(self._repo_task_id, completed=completed + 1)


@contextmanager
def migration_progress_context(
    *,
    console: Console | None = None,
    transient: bool = False,
) -> Iterator[_RichProgressCallback]:
    """Create a nested Rich progress display for migration.

    Displays three levels of progress:
    - Top: ``[Repo X/N] repo-name``
    - Middle: ``[PR Y/M] PR title``
    - Bottom: ``[Comments Z/K]``

    Args:
        console: Optional console instance. Uses shared console if not provided.
        transient: If True, progress display disappears after completion.

    Yields:
        A callback object implementing MigrationProgressCallback for reporting
        migration progress at the repo, PR, and comment levels.

    Example:
        with migration_progress_context() as callback:
            callback.start_repo("my-repo", repo_index=1, total_repos=3)
            callback.start_pr("Fix bug", pr_index=1, total_prs=5)
            callback.set_comment_total(10)
            for _ in range(10):
                callback.advance_comments()
            callback.finish_pr()
            callback.finish_repo()
    """
    if console is None:
        console = get_shared_console()

    progress = Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=transient,
    )

    with progress:
        yield _RichProgressCallback(progress)


def print_migration_summary(
    *,
    repos_migrated: int,
    repos_failed: int,
    prs_migrated: int,
    prs_failed: int,
    comments_migrated: int,
    console: Console | None = None,
) -> None:
    """Print a summary table of migration results.

    Displays a formatted table showing the count of migrated and failed
    repositories, pull requests, and comments.

    Args:
        repos_migrated: Number of repositories successfully migrated.
        repos_failed: Number of repositories that failed migration.
        prs_migrated: Number of pull requests successfully migrated.
        prs_failed: Number of pull requests that failed migration.
        comments_migrated: Number of comments successfully migrated.
        console: Optional console instance. Uses shared console if not provided.
    """
    if console is None:
        console = get_shared_console()

    table = Table(title="Migration Summary")
    table.add_column("Resource", style="bold")
    table.add_column("Migrated", justify="right", style="green")
    table.add_column("Failed", justify="right", style="red")

    table.add_row("Repositories", str(repos_migrated), str(repos_failed))
    table.add_row("Pull Requests", str(prs_migrated), str(prs_failed))
    table.add_row("Comments", str(comments_migrated), "—")

    console.print(table)


class JsonProgressReporter:
    """JSON Lines progress reporter for CI/non-interactive mode.

    Writes one JSON object per line to the given output stream for each
    progress event. Suitable for machine consumption when ``--output=json``
    is used.

    Args:
        output: Writable text stream for JSON Lines output. Defaults to stdout.
    """

    def __init__(self, output: IO[str] | None = None) -> None:
        if output is None:
            import sys

            output = sys.stdout
        self._output = output

    def _emit(self, data: dict[str, object]) -> None:
        """Write a JSON object as a single line."""
        self._output.write(json.dumps(data) + "\n")

    def start_repo(self, repo_name: str, repo_index: int, total_repos: int) -> None:
        """Emit repo_start event."""
        self._emit(
            {
                "event": "repo_start",
                "repo_name": repo_name,
                "repo_index": repo_index,
                "total_repos": total_repos,
            }
        )

    def start_pr(self, pr_title: str, pr_index: int, total_prs: int) -> None:
        """Emit pr_start event."""
        self._emit(
            {
                "event": "pr_start",
                "pr_title": pr_title,
                "pr_index": pr_index,
                "total_prs": total_prs,
            }
        )

    def advance_comments(self, count: int = 1) -> None:
        """Emit comments_progress event."""
        self._emit(
            {
                "event": "comments_progress",
                "count": count,
            }
        )

    def set_comment_total(self, total: int) -> None:
        """Emit comment_total event."""
        self._emit(
            {
                "event": "comment_total",
                "total": total,
            }
        )

    def finish_pr(self) -> None:
        """Emit pr_finish event."""
        self._emit({"event": "pr_finish"})

    def finish_repo(self) -> None:
        """Emit repo_finish event."""
        self._emit({"event": "repo_finish"})
