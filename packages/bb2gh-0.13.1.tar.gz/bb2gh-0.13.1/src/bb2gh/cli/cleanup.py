"""CLI commands for repository cleanup and history rewriting."""

from __future__ import annotations

import asyncio
from enum import StrEnum
from pathlib import Path
from typing import TYPE_CHECKING, Annotated

import typer
from rich.console import Console
from rich.table import Table

if TYPE_CHECKING:
    from bb2gh.cleanup.models import AnalysisResult, VerificationResult
    from bb2gh.cleanup.service import CleanupService

cleanup_app = typer.Typer(
    name="cleanup",
    help="Repository cleanup and history rewriting.",
    no_args_is_help=True,
)
console = Console()


class Strategy(StrEnum):
    """Supported cleanup strategies."""

    REMOVE = "remove"
    LFS = "lfs"


class Engine(StrEnum):
    """Supported cleanup engines."""

    AUTO = "auto"
    FILTER_REPO = "filter-repo"
    BFG = "bfg"


@cleanup_app.command("analyze")
def analyze(
    repo_slug: Annotated[str, typer.Argument(help="Repository slug to analyze")],
    threshold: Annotated[str, typer.Option(help="Size threshold (e.g. 100MB)")] = "100MB",
    output: Annotated[
        Path | None,
        typer.Option(help="Save report to a JSON file"),
    ] = None,
) -> None:
    """Scan repository history for files exceeding the threshold."""
    result = _run_analyze(repo_slug=repo_slug, threshold=threshold)

    table = Table(title=f"Large Files in {result.repo_name}")
    table.add_column("Path", style="cyan")
    table.add_column("Size", justify="right")
    table.add_column("Commit", style="dim")
    table.add_column("In HEAD?", justify="center")

    for blob in result.large_blobs:
        table.add_row(
            blob.path,
            f"{blob.size_mb:.1f} MB",
            blob.commit_sha[:7],
            "Yes" if blob.still_in_head else "No",
        )

    console.print(table)
    console.print(f"\n[bold]Repository:[/bold] {result.repo_name}")
    console.print(f"[bold]Objects enumerated:[/bold] {result.commits_scanned:,}")
    console.print(f"[bold]Estimated savings:[/bold] {result.estimated_savings_mb:.1f} MB")

    if output is not None:
        output.write_text(result.model_dump_json(indent=2), encoding="utf-8")
        console.print(f"[green]Report saved to {output}[/green]")


@cleanup_app.command("fix")
def fix(
    repo_slug: Annotated[str, typer.Argument(help="Repository slug to clean")],
    strategy: Annotated[Strategy, typer.Option(help="Cleanup strategy")] = Strategy.REMOVE,
    engine: Annotated[Engine, typer.Option(help="Cleanup engine")] = Engine.AUTO,
    pattern: Annotated[
        list[str] | None,
        typer.Option(help="File patterns to target"),
    ] = None,
    threshold: Annotated[str, typer.Option(help="Size threshold")] = "100MB",
    confirm: Annotated[bool, typer.Option(help="Execute instead of dry-run")] = False,
    backup_dir: Annotated[
        Path | None,
        typer.Option(help="Backup directory"),
    ] = None,
) -> None:
    """Remove or convert files in repository history."""
    _run_fix(
        repo_slug=repo_slug,
        strategy=strategy,
        engine=engine,
        patterns=pattern,
        threshold=threshold,
        confirm=confirm,
        backup_dir=backup_dir,
    )


@cleanup_app.command("verify")
def verify(
    repo_slug: Annotated[str, typer.Argument(help="Repository slug to verify")],
    threshold: Annotated[str, typer.Option(help="Size threshold")] = "100MB",
) -> None:
    """Verify no oversized blobs remain after cleanup."""
    result = _run_verify(repo_slug=repo_slug, threshold=threshold)

    if result.passed:
        console.print("[green]Verification passed![/green]")
        console.print(f"Branches: {result.branches_intact}/{result.branches_expected}")
        console.print(f"Tags: {result.tags_intact}/{result.tags_expected}")
        return

    console.print("[red]Verification failed[/red]")
    for issue in result.issues:
        console.print(f"- {issue}")


def _run_analyze(*, repo_slug: str, threshold: str) -> AnalysisResult:
    """Bridge the synchronous CLI command to async cleanup analysis."""
    from bb2gh.cleanup.analysis import AnalysisService
    from bb2gh.services.git import GitService

    async def _run() -> AnalysisResult:
        git_service = GitService()
        analysis_service = AnalysisService(git_service=git_service)
        return await analysis_service.scan_history(
            repo_path=Path(f".bb2gh/repos/{repo_slug}.git"),
            threshold_bytes=_parse_size(threshold),
        )

    return asyncio.run(_run())


def _run_fix(
    *,
    repo_slug: str,
    strategy: Strategy,
    engine: Engine,
    patterns: list[str] | None,
    threshold: str,
    confirm: bool,
    backup_dir: Path | None,
) -> None:
    """Bridge the synchronous CLI command to async cleanup execution."""
    from bb2gh.cleanup.models import CleanupConfig

    config = CleanupConfig.model_validate(
        {
            "enabled": True,
            "strategy": strategy.value,
            "engine": engine.value,
            "patterns": patterns or [],
            "threshold_bytes": _parse_size(threshold),
        }
    )

    if not confirm:
        console.print("[yellow][DRY RUN][/yellow] Preview mode. Use --confirm to execute.")

    async def _run() -> None:
        service = _build_cleanup_service()
        result = await service.fix(
            repo_path=Path(f".bb2gh/repos/{repo_slug}.git"),
            config=config,
            confirm=confirm,
            backup_dir=backup_dir,
        )

        if result.success:
            console.print("[green]Cleanup completed successfully.[/green]")
            if result.operation.object_map_path is not None:
                console.print(f"Object map: {result.operation.object_map_path}")
        else:
            console.print(f"[red]Cleanup failed:[/red] {result.operation.error_message}")

    asyncio.run(_run())


def _run_verify(*, repo_slug: str, threshold: str) -> VerificationResult:
    """Bridge the synchronous CLI command to async cleanup verification."""

    async def _run() -> VerificationResult:
        service = _build_cleanup_service()
        return await service.verify(
            repo_path=Path(f".bb2gh/repos/{repo_slug}.git"),
            threshold_bytes=_parse_size(threshold),
        )

    return asyncio.run(_run())


def _build_cleanup_service() -> CleanupService:
    """Build a cleanup service with local dependencies for CLI usage."""
    from bb2gh.cleanup.analysis import AnalysisService
    from bb2gh.cleanup.bfg import BFGEngine
    from bb2gh.cleanup.filter_repo import FilterRepoEngine
    from bb2gh.cleanup.lfs_conversion import LFSConversionService
    from bb2gh.cleanup.registry import EngineRegistry
    from bb2gh.cleanup.service import CleanupService
    from bb2gh.services.git import GitService

    git_service = GitService()
    engine_registry = EngineRegistry(
        engines={
            "filter-repo": FilterRepoEngine(git_service=git_service),
            "bfg": BFGEngine(),
        }
    )
    analysis_service = AnalysisService(git_service=git_service)
    lfs_service = LFSConversionService(git_service=git_service)
    return CleanupService(
        git_service=git_service,
        engine_registry=engine_registry,
        analysis_service=analysis_service,
        lfs_conversion_service=lfs_service,
    )


def _parse_size(size_str: str) -> int:
    """Parse a human-readable size string into bytes."""
    normalized = size_str.strip().upper()
    multipliers = {"GB": 1024**3, "MB": 1024**2, "KB": 1024, "B": 1}

    for suffix, multiplier in multipliers.items():
        if normalized.endswith(suffix):
            value = normalized[: -len(suffix)].strip()
            return int(float(value) * multiplier)

    return int(normalized)
