"""Base worker pool abstraction."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

import structlog

if TYPE_CHECKING:
    from bb2gh.models.worker import Worker, WorkerPoolStats, WorkerTask

logger = structlog.get_logger(__name__)


class WorkerPool(ABC):
    """Abstract base class for worker pools.

    Defines the interface for managing worker pools that execute
    migration tasks in parallel.
    """

    def __init__(self, num_workers: int = 1):
        """Initialize worker pool.

        Args:
            num_workers: Number of workers to spawn.
        """
        self.num_workers = num_workers
        self._workers: dict[str, Worker] = {}
        self._running = False

    @abstractmethod
    async def start(self) -> None:
        """Start the worker pool."""

    @abstractmethod
    async def stop(self, graceful: bool = True) -> None:
        """Stop the worker pool.

        Args:
            graceful: If True, wait for current tasks to complete.
        """

    @abstractmethod
    async def submit_task(self, task: WorkerTask) -> None:
        """Submit a task to the pool.

        Args:
            task: Task to execute.
        """

    @abstractmethod
    async def get_stats(self) -> WorkerPoolStats:
        """Get pool statistics.

        Returns:
            Current pool statistics.
        """

    @abstractmethod
    async def wait_for_completion(self) -> None:
        """Wait for all tasks to complete."""

    @property
    def is_running(self) -> bool:
        """Check if pool is running."""
        return self._running

    @property
    def workers(self) -> list[Worker]:
        """Get list of workers."""
        return list(self._workers.values())

    async def get_worker(self, worker_id: str) -> Worker | None:
        """Get a specific worker by ID.

        Args:
            worker_id: Worker ID.

        Returns:
            Worker if found, None otherwise.
        """
        return self._workers.get(worker_id)
