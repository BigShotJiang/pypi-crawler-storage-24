"""Local asyncio worker pool.

Provides parallel migration using asyncio tasks within a single process.
"""

from __future__ import annotations

import asyncio
import signal
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable

import structlog

from bb2gh.models.worker import Worker, WorkerPoolStats, WorkerStatus, WorkerTask
from bb2gh.workers.distributor import WorkQueue
from bb2gh.workers.pool import WorkerPool
from bb2gh.workers.rate_limiter import SharedRateLimiter

logger = structlog.get_logger(__name__)

# Store references to background tasks to prevent garbage collection
_background_tasks: set[asyncio.Task[Any]] = set()


class LocalWorkerPool(WorkerPool):
    """Local asyncio worker pool.

    Runs worker coroutines that execute tasks from a shared queue.
    Uses asyncio for concurrent I/O within a single process.
    """

    def __init__(
        self,
        num_workers: int = 1,
        work_queue: WorkQueue | None = None,
        rate_limiter: SharedRateLimiter | None = None,
        task_handler: Callable[[WorkerTask, SharedRateLimiter], Any] | None = None,
    ):
        """Initialize local worker pool.

        Args:
            num_workers: Number of concurrent worker tasks.
            work_queue: Work queue for task distribution.
            rate_limiter: Shared rate limiter.
            task_handler: Function to execute tasks.
        """
        super().__init__(num_workers)
        self.work_queue = work_queue or WorkQueue()
        self.rate_limiter = rate_limiter or SharedRateLimiter()
        self._task_handler = task_handler
        self._shutdown_event = asyncio.Event()
        self._started_at: datetime | None = None

    async def start(self) -> None:
        """Start the worker pool."""
        if self._running:
            logger.warning("pool_already_running")
            return

        self._running = True
        self._started_at = datetime.now()
        self._shutdown_event.clear()

        # Set up signal handlers for graceful shutdown
        self._setup_signal_handlers()

        # Spawn worker tasks
        for i in range(self.num_workers):
            worker_id = f"worker-{i:02d}-{uuid.uuid4().hex[:8]}"
            worker = Worker(
                id=worker_id,
                name=f"Worker {i + 1}",
                status=WorkerStatus.IDLE,
            )
            self._workers[worker_id] = worker

            logger.info("worker_spawned", worker_id=worker_id, worker_num=i + 1)

        # Start worker coroutines
        for worker_id in self._workers:
            worker_task = asyncio.create_task(self._worker_loop(worker_id))
            _background_tasks.add(worker_task)
            worker_task.add_done_callback(_background_tasks.discard)

        logger.info(
            "pool_started",
            num_workers=self.num_workers,
            started_at=self._started_at.isoformat(),
        )

    async def stop(self, graceful: bool = True) -> None:
        """Stop the worker pool.

        Args:
            graceful: If True, wait for current tasks to complete.
        """
        if not self._running:
            return

        logger.info("pool_stopping", graceful=graceful)

        self._shutdown_event.set()

        if graceful:
            # Wait for workers to finish current tasks
            await self._wait_for_workers()

        # Stop all workers
        for worker_id, worker in self._workers.items():
            worker.status = WorkerStatus.STOPPED
            logger.debug("worker_stopped", worker_id=worker_id)

        self._running = False
        logger.info("pool_stopped")

    async def submit_task(self, task: WorkerTask) -> None:
        """Submit a task to the pool.

        Args:
            task: Task to execute.
        """
        await self.work_queue.enqueue(task)

    async def submit_tasks(self, tasks: list[WorkerTask]) -> None:
        """Submit multiple tasks to the pool.

        Args:
            tasks: Tasks to execute.
        """
        await self.work_queue.enqueue_many(tasks)

    async def get_stats(self) -> WorkerPoolStats:
        """Get pool statistics.

        Returns:
            Current pool statistics.
        """
        active = sum(1 for w in self._workers.values() if w.status == WorkerStatus.RUNNING)
        idle = sum(1 for w in self._workers.values() if w.status == WorkerStatus.IDLE)
        stopped = sum(1 for w in self._workers.values() if w.status == WorkerStatus.STOPPED)

        queue_stats = self.work_queue.get_stats()

        # Get GitHub rate limit status
        github_status = self.rate_limiter.get_status("github")
        rate_limit = github_status.get("percent_available") if github_status else None

        return WorkerPoolStats(
            total_workers=len(self._workers),
            active_workers=active,
            idle_workers=idle,
            stopped_workers=stopped,
            tasks_pending=queue_stats["pending"],
            tasks_in_progress=queue_stats["in_progress"],
            tasks_completed=queue_stats["completed"],
            tasks_failed=queue_stats["failed"],
            started_at=self._started_at,
            current_rate_limit=rate_limit,
        )

    async def wait_for_completion(self) -> None:
        """Wait for all tasks to complete."""
        while not self.work_queue.is_empty():
            await asyncio.sleep(0.1)

    async def _worker_loop(self, worker_id: str) -> None:
        """Main loop for a worker.

        Args:
            worker_id: Worker ID.
        """
        worker = self._workers[worker_id]

        while not self._shutdown_event.is_set():
            # Try to get a task
            task = await self.work_queue.dequeue(worker_id)

            if task is None:
                # No work available, idle briefly
                worker.status = WorkerStatus.IDLE
                worker.current_task = None
                await asyncio.sleep(0.1)
                continue

            # Execute the task
            worker.status = WorkerStatus.RUNNING
            worker.current_task = task
            worker.heartbeat()

            try:
                logger.info(
                    "worker_executing_task",
                    worker_id=worker_id,
                    task_id=task.id,
                    repository=task.repository,
                    attempt=task.attempt,
                )

                if self._task_handler:
                    result = await self._execute_task(task)
                    await self.work_queue.complete_task(
                        task.id,
                        success=True,
                        result=result,
                    )
                    worker.tasks_completed += 1
                else:
                    # No handler - simulate completion
                    await asyncio.sleep(0.01)
                    await self.work_queue.complete_task(
                        task.id,
                        success=True,
                        result={"status": "simulated"},
                    )
                    worker.tasks_completed += 1

            except Exception as e:
                logger.error(
                    "worker_task_failed",
                    worker_id=worker_id,
                    task_id=task.id,
                    error=str(e),
                )
                await self.work_queue.complete_task(
                    task.id,
                    success=False,
                    error=str(e),
                )
                worker.tasks_failed += 1

            finally:
                worker.current_task = None
                worker.heartbeat()

        worker.status = WorkerStatus.STOPPED

    async def _execute_task(self, task: WorkerTask) -> dict[str, Any]:
        """Execute a task with rate limiting.

        Args:
            task: Task to execute.

        Returns:
            Task result.
        """
        # Acquire rate limit tokens before making API calls
        await self.rate_limiter.acquire("github", tokens=1.0)
        await self.rate_limiter.acquire("bitbucket", tokens=1.0)

        # Execute the task handler
        handler = self._task_handler
        if handler is None:
            return {"result": None}
        if asyncio.iscoroutinefunction(handler):
            result: Any = await handler(task, self.rate_limiter)
        else:
            result = handler(task, self.rate_limiter)
        return dict(result) if isinstance(result, dict) else {"result": result}

    async def _wait_for_workers(self) -> None:
        """Wait for workers to finish current tasks."""
        max_wait = 30.0  # seconds
        waited = 0.0

        while waited < max_wait:
            active = sum(1 for w in self._workers.values() if w.status == WorkerStatus.RUNNING)
            if active == 0:
                break
            await asyncio.sleep(0.5)
            waited += 0.5

    def _setup_signal_handlers(self) -> None:
        """Set up signal handlers for graceful shutdown."""
        try:
            loop = asyncio.get_running_loop()

            def handle_signal(sig: signal.Signals) -> None:
                logger.info("signal_received", signal=sig.name)
                self._shutdown_event.set()

            for sig in (signal.SIGINT, signal.SIGTERM):
                loop.add_signal_handler(sig, handle_signal, sig)
        except Exception as e:
            # Signal handlers may not work in all environments
            logger.debug("signal_handler_setup_failed", error=str(e))


def spawn_workers(
    num_workers: int,
    work_queue: WorkQueue,
    rate_limiter: SharedRateLimiter,
    task_handler: Callable[[WorkerTask, SharedRateLimiter], Any],
) -> LocalWorkerPool:
    """Create and return a configured worker pool.

    Args:
        num_workers: Number of workers to spawn.
        work_queue: Work queue for tasks.
        rate_limiter: Shared rate limiter.
        task_handler: Function to handle tasks.

    Returns:
        Configured LocalWorkerPool.
    """
    return LocalWorkerPool(
        num_workers=num_workers,
        work_queue=work_queue,
        rate_limiter=rate_limiter,
        task_handler=task_handler,
    )
