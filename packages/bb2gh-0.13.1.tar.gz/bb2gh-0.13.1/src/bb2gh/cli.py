"""bb2gh CLI - Backward compatibility shim.

This module re-exports from the new cli package location.
Import from bb2gh.cli.app for new code.
"""

from bb2gh.cli.app import app

__all__ = ["app"]
