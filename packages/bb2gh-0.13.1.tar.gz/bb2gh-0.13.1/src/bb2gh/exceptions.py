"""Custom exceptions for bb2gh.

Most exception types are shared with migration-core so adapters and CLI layers
raise and catch a single common hierarchy.
"""

from __future__ import annotations

from migration_core.exceptions import (
    APIError,
    AuthenticationError,
    ConfigError,
    ExitCode,
    GitError,
    MigrationError,
    StateError,
    ValidationError,
)

BB2GHError = MigrationError


class LimitExceededError(BB2GHError):
    """Raised when a quantitative license limit is exceeded."""

    def __init__(
        self,
        limit_name: str,
        current: int,
        max_limit: int,
        *,
        message: str | None = None,
        exit_code: ExitCode = ExitCode.USER_ERROR,
    ) -> None:
        if message is None:
            message = (
                f"License limit exceeded for '{limit_name}': "
                f"{current} requested but limit is {max_limit}. "
                "Contact sales@n8-group.com to upgrade."
            )
        super().__init__(message, exit_code=exit_code)
        self.limit_name = limit_name
        self.current = current
        self.max_limit = max_limit


ConfigurationError = ConfigError

__all__ = [
    "APIError",
    "AuthenticationError",
    "BB2GHError",
    "CleanupError",
    "CleanupVerificationError",
    "ConfigError",
    "ConfigurationError",
    "EngineNotAvailableError",
    "ExitCode",
    "GitError",
    "InsufficientDiskSpaceError",
    "LFSLimitExceededError",
    "LimitExceededError",
    "StateError",
    "ValidationError",
]


class CleanupError(BB2GHError):
    """Base error for cleanup operations."""

    def __init__(
        self,
        message: str,
        *,
        exit_code: ExitCode = ExitCode.SYSTEM_ERROR,
    ) -> None:
        """Initialize cleanup error."""
        super().__init__(message, exit_code=exit_code)


class EngineNotAvailableError(CleanupError):
    """Cleanup engine not found on the system."""

    def __init__(self, message: str) -> None:
        """Initialize engine availability error."""
        super().__init__(message, exit_code=ExitCode.USER_ERROR)


class InsufficientDiskSpaceError(CleanupError):
    """Not enough disk space for cleanup to proceed safely."""

    def __init__(self, message: str) -> None:
        """Initialize insufficient disk space error."""
        super().__init__(message, exit_code=ExitCode.USER_ERROR)


class LFSLimitExceededError(CleanupError):
    """Files exceed GitHub LFS per-file size limit."""

    def __init__(self, message: str) -> None:
        """Initialize LFS limit exceeded error."""
        super().__init__(message, exit_code=ExitCode.USER_ERROR)


class CleanupVerificationError(CleanupError):
    """Post-cleanup verification failed."""

    def __init__(self, message: str) -> None:
        """Initialize cleanup verification error."""
        super().__init__(message, exit_code=ExitCode.SYSTEM_ERROR)
