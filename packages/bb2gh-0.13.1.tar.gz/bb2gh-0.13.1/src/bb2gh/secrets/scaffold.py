"""Secrets scaffolding service for bb2gh.

Creates placeholder secrets in GitHub based on source inventory.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import structlog

from bb2gh.models.secret import (
    Secret,
    SecretInventory,
    SecretScope,
)

if TYPE_CHECKING:
    from typing import Any

    from bb2gh.adapters.base import TargetAdapter

logger = structlog.get_logger(__name__)

# Placeholder value for scaffolded secrets
PLACEHOLDER_VALUE = "PLACEHOLDER_NEEDS_VALUE_FROM_BITBUCKET"


@dataclass
class ScaffoldResult:
    """Result of scaffolding secrets."""

    created: int = 0
    skipped: int = 0
    failed: int = 0
    secrets_created: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)

    @property
    def success(self) -> bool:
        """Check if scaffolding was successful."""
        return self.failed == 0


class SecretsScaffoldService:
    """Service for scaffolding secrets in target platform."""

    def __init__(
        self,
        *,
        target_adapter: TargetAdapter[Any, Any],
    ) -> None:
        """Initialize SecretsScaffoldService.

        Args:
            target_adapter: Adapter for target platform (GitHub).
        """
        self._target = target_adapter

    async def scaffold_secrets(
        self,
        inventory: SecretInventory,
        *,
        target_org: str,
        repo_mapping: dict[str, str] | None = None,
        dry_run: bool = False,
    ) -> ScaffoldResult:
        """Scaffold placeholder secrets in GitHub.

        Args:
            inventory: Secret inventory from source.
            target_org: Target GitHub organization.
            repo_mapping: Optional mapping of source to target repo names.
            dry_run: If True, only preview without creating.

        Returns:
            ScaffoldResult with counts and details.
        """
        result = ScaffoldResult()

        log = logger.bind(
            target_org=target_org,
            total_secrets=len(inventory.secrets),
            dry_run=dry_run,
        )
        log.info("scaffolding_secrets")

        for secret in inventory.secrets:
            try:
                # Determine target repository
                target_repo = self._resolve_target_repo(
                    secret,
                    target_org,
                    repo_mapping,
                )

                if dry_run:
                    result.created += 1
                    result.secrets_created.append(f"{target_repo}/{secret.name}")
                    continue

                # Create secret based on scope
                if secret.scope == SecretScope.REPOSITORY:
                    await self._create_repository_secret(target_repo, secret)
                elif secret.scope == SecretScope.ENVIRONMENT:
                    await self._create_environment_secret(
                        target_repo,
                        secret.environment or "production",
                        secret,
                    )
                elif secret.scope == SecretScope.ORGANIZATION:
                    await self._create_org_secret(target_org, secret)
                else:
                    # Workspace-level secrets become org secrets
                    await self._create_org_secret(target_org, secret)

                result.created += 1
                result.secrets_created.append(f"{target_repo}/{secret.name}")
                logger.debug("secret_scaffolded", secret=secret.name, repo=target_repo)

            except Exception as e:
                result.failed += 1
                result.errors.append(f"{secret.name}: {e}")
                logger.warning("secret_scaffold_failed", secret=secret.name, error=str(e))

        log.info(
            "secrets_scaffolded",
            created=result.created,
            failed=result.failed,
        )

        return result

    def _resolve_target_repo(
        self,
        secret: Secret,
        target_org: str,
        repo_mapping: dict[str, str] | None,
    ) -> str:
        """Resolve target repository for a secret.

        Args:
            secret: The secret to resolve for.
            target_org: Target organization.
            repo_mapping: Optional source to target repo mapping.

        Returns:
            Target repository full name (org/repo).
        """
        if not secret.repository:
            return target_org

        # Apply mapping if available
        if repo_mapping and secret.repository in repo_mapping:
            return repo_mapping[secret.repository]

        # Default: use same repo name in target org
        _, repo_name = secret.repository.split("/", 1)
        return f"{target_org}/{repo_name}"

    async def _create_repository_secret(
        self,
        repo: str,
        secret: Secret,
    ) -> None:
        """Create a repository secret.

        Args:
            repo: Repository full name (org/repo).
            secret: Secret to create.
        """
        if hasattr(self._target, "create_repository_secret"):
            await self._target.create_repository_secret(
                repo,
                secret.name,
                PLACEHOLDER_VALUE,
            )
        else:
            raise NotImplementedError("create_repository_secret not available")

    async def _create_environment_secret(
        self,
        repo: str,
        environment: str,
        secret: Secret,
    ) -> None:
        """Create an environment secret.

        Args:
            repo: Repository full name (org/repo).
            environment: Environment name.
            secret: Secret to create.
        """
        if hasattr(self._target, "create_environment_secret"):
            await self._target.create_environment_secret(
                repo,
                environment,
                secret.name,
                PLACEHOLDER_VALUE,
            )
        else:
            raise NotImplementedError("create_environment_secret not available")

    async def _create_org_secret(
        self,
        org: str,
        secret: Secret,
    ) -> None:
        """Create an organization secret.

        Args:
            org: Organization name.
            secret: Secret to create.
        """
        if hasattr(self._target, "create_org_secret"):
            await self._target.create_org_secret(
                org,
                secret.name,
                PLACEHOLDER_VALUE,
            )
        else:
            raise NotImplementedError("create_org_secret not available")
