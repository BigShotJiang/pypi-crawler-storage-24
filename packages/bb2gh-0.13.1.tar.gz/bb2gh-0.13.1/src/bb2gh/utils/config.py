"""Configuration loading utilities for bb2gh.

Handles loading configuration from YAML files and merging with environment variables.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

import yaml  # type: ignore[import-untyped]

from bb2gh.models.config import BB2GHSettings

if TYPE_CHECKING:
    from bb2gh.models.config import MigrationProfile


def load_yaml_config(path: Path) -> dict[str, Any]:
    """Load configuration from a YAML file.

    Args:
        path: Path to the YAML config file.

    Returns:
        Dictionary of configuration values.

    Raises:
        FileNotFoundError: If the file doesn't exist.
        yaml.YAMLError: If the file contains invalid YAML.
    """
    with path.open() as f:
        return yaml.safe_load(f) or {}


def get_settings(config_file: Path | None = None) -> BB2GHSettings:
    """Load settings from config file and environment.

    Configuration precedence (highest to lowest):
    1. Environment variables (BB2GH_*)
    2. Config file (if provided)
    3. Defaults

    Args:
        config_file: Optional path to YAML config file.

    Returns:
        Configured BB2GHSettings instance.
    """
    init_values: dict[str, Any] = {}

    # Load from config file if provided and exists
    if config_file and config_file.exists():
        init_values = load_yaml_config(config_file)

    # Create settings - env vars automatically override via pydantic-settings
    return BB2GHSettings(**init_values)


def create_default_config(path: Path) -> None:
    """Create a default configuration file.

    Args:
        path: Path where the config file should be created.

    Raises:
        FileExistsError: If the file already exists.
    """
    if path.exists():
        raise FileExistsError(f"Config file already exists: {path}")

    # Ensure parent directory exists
    path.parent.mkdir(parents=True, exist_ok=True)

    default_config = """\
# bb2gh configuration file
# See: https://n8-group.gitbook.io/bb2gh/getting-started/configuration

# Profiles allow separate credentials per workspace pair.
# Run 'bb2gh auth login' for interactive setup.

# default_profile: default
# profiles:
#   default:
#     source:
#       type: bitbucket-cloud
#       username: your-username
#       workspace: your-workspace
#       auth_method: api-token  # or oauth2
#     target:
#       type: github-cloud
#       organization: your-org
#       auth_method: pat  # or app

# Legacy flat config (still works, profiles take precedence):
bitbucket:
  # username: your-username
  # api_token: your-api-token  # replaces app_password (deprecated June 2026)

github:
  # token: ghp_your-token

logging:
  level: INFO
  format: console
"""
    path.write_text(default_config)


def config_to_display_dict(settings: BB2GHSettings) -> dict[str, Any]:
    """Convert settings to a display-safe dictionary (secrets masked).

    Args:
        settings: The settings to convert.

    Returns:
        Dictionary with secrets masked as "***".
    """
    data = settings.model_dump()

    # Mask secrets
    def mask_secrets(d: dict[str, Any]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in d.items():
            if isinstance(value, dict):
                result[key] = mask_secrets(value)
            elif (
                "password" in key.lower()
                or "secret" in key.lower()
                or "token" in key.lower()
                or "key" in key.lower()
            ):
                result[key] = "***" if value else None
            else:
                result[key] = str(value) if isinstance(value, Path) else value
        return result

    return mask_secrets(data)


def save_profile_to_config(
    config_path: Path,
    profile_name: str,
    profile: MigrationProfile,
) -> None:
    """Save a migration profile to the config file.

    Merges the profile into the existing config, creating the file and
    parent directories if necessary.

    Args:
        config_path: Path to the YAML config file.
        profile_name: Name of the profile to save.
        profile: The migration profile to persist.
    """
    config_path.parent.mkdir(parents=True, exist_ok=True)
    existing: dict[str, Any] = load_yaml_config(config_path) if config_path.exists() else {}

    if "profiles" not in existing:
        existing["profiles"] = {}

    existing["profiles"][profile_name] = profile.model_dump(exclude_none=True)

    with config_path.open("w") as f:
        yaml.dump(existing, f, default_flow_style=False, sort_keys=False)


def load_profiles_from_config(
    config_path: Path,
) -> dict[str, MigrationProfile]:
    """Load all migration profiles from the config file.

    Args:
        config_path: Path to the YAML config file.

    Returns:
        Dictionary mapping profile names to MigrationProfile instances.
        Returns an empty dict if the file does not exist or has no profiles.
    """
    from bb2gh.models.config import MigrationProfile

    if not config_path.exists():
        return {}

    data = load_yaml_config(config_path)
    profiles_data = data.get("profiles", {})

    return {name: MigrationProfile(**profile_data) for name, profile_data in profiles_data.items()}
