"""Logging configuration for bb2gh using structlog.

Provides structured logging with support for:
- Console format (human-readable, colored)
- JSON format (machine-parseable)
- Context binding (migration_id, repo_name, etc.)
"""

from __future__ import annotations

import logging
import os
import sys
from typing import IO, Literal

import structlog

# Track if logging has been configured
_logging_configured = False


def configure_logging(
    level: str = "INFO",
    log_format: Literal["console", "json"] | None = None,
    stream: IO[str] | None = None,
) -> None:
    """Configure structlog for the application.

    Args:
        level: Log level (DEBUG, INFO, WARNING, ERROR).
        log_format: Output format. If None, reads from BB2GH_LOG_FORMAT env var.
        stream: Output stream. Defaults to sys.stderr.
    """
    global _logging_configured

    # Read format from environment if not specified
    if log_format is None:
        log_format = os.environ.get("BB2GH_LOG_FORMAT", "console")  # type: ignore[assignment]
        if log_format not in ("console", "json"):
            log_format = "console"

    # Use stderr by default
    if stream is None:
        stream = sys.stderr

    # Convert level string to logging constant
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    # Configure standard library logging
    logging.basicConfig(
        format="%(message)s",
        level=numeric_level,
        stream=stream,
        force=True,
    )

    # Shared processors for both formats
    shared_processors: list[structlog.typing.Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    if log_format == "json":
        # JSON format for production/machine parsing
        processors: list[structlog.typing.Processor] = [
            *shared_processors,
            structlog.processors.format_exc_info,
            structlog.processors.JSONRenderer(),
        ]
    else:
        # Console format for development
        processors = [
            *shared_processors,
            structlog.dev.ConsoleRenderer(
                colors=stream.isatty() if hasattr(stream, "isatty") else False
            ),
        ]

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.stdlib.BoundLogger,
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    _logging_configured = True


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Get a configured structlog logger.

    Args:
        name: Optional logger name. Defaults to "bb2gh".

    Returns:
        A bound structlog logger.

    Example:
        logger = get_logger()
        logger.info("Starting migration", repo="my-repo")

        # With context binding
        logger = logger.bind(migration_id="mig_123")
        logger.info("Processing repository", repo="my-repo")
    """
    global _logging_configured

    # Auto-configure if not done yet
    if not _logging_configured:
        configure_logging()

    if name is None:
        name = "bb2gh"

    return structlog.get_logger(name)  # type: ignore[no-any-return]


def reset_logging() -> None:
    """Reset logging configuration.

    Useful for testing to ensure clean state between tests.
    """
    global _logging_configured
    _logging_configured = False
    structlog.reset_defaults()
