"""bb2gh - Bitbucket to GitHub migration tool."""

from bb2gh.__about__ import __version__

__all__ = ["__version__"]
