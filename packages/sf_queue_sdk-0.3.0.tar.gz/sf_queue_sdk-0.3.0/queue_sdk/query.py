"""QueryClient - direct Redis key lookups."""

from typing import Optional

import redis as redis_lib


class QueryClient:
    """Direct Redis key lookups (GET, MGET)."""

    def __init__(self, redis_client: redis_lib.Redis):
        self._redis = redis_client

    def get(self, key: str) -> Optional[str]:
        """Fetch a single key from Redis."""
        return self._redis.get(key)

    def get_many(self, keys: list[str]) -> list[Optional[str]]:
        """Fetch multiple keys from Redis in a single MGET call."""
        if not keys:
            return []
        return self._redis.mget(*keys)
