"""QueueClient - main entry point for the Python SDK."""

from queue_sdk.query import QueryClient
from queue_sdk.queues.email_queue import EmailQueue
from queue_sdk.queues.pdf_to_image_queue import PdfToImageQueue
from queue_sdk.queues.recommendation_queue import RecommendationQueue
from queue_sdk.queues.tool_assignment_queue import ToolAssignmentQueue
from queue_sdk.queues.topic_assignment_queue import TopicAssignmentQueue
from queue_sdk.redis_client import create_redis_client
from queue_sdk.types import QueueClientConfig


class QueueClient:
    """Main entry point for the sf-queue Python SDK.

    Initialize with Redis connection details and environment,
    then use typed queue properties to send messages.

    Usage:
        client = QueueClient(
            redis_url="redis://localhost:6379",
            redis_password="your-password",
            environment="staging",
        )

        # Fire and forget
        result = client.email.send(
            to="user@example.com",
            preview="Welcome!",
            subject="Welcome!",
            paragraphs=["Hello!", "Welcome to our platform."],
        )

        # Send and wait for confirmation
        response = client.email.send_and_wait(
            to="user@example.com",
            preview="Welcome!",
            subject="Welcome!",
            paragraphs=["Hello!"],
            timeout=30,
        )

        # Convert PDF to image
        result = client.pdf_to_image.convert_and_wait(
            url="https://example.com/document.pdf",
            page=1,
            format="webp",
        )
    """

    def __init__(
        self,
        redis_url: str,
        redis_password: str,
        environment: str,
    ):
        config = QueueClientConfig(
            redis_url=redis_url,
            redis_password=redis_password,
            environment=environment,
        )
        self._redis = create_redis_client(config)
        self._environment = environment

        # Initialize queue instances
        self.email = EmailQueue(self._redis, self._environment)
        self.topic_assignment = TopicAssignmentQueue(self._redis, self._environment)
        self.tool_assignment = ToolAssignmentQueue(self._redis, self._environment)
        self.pdf_to_image = PdfToImageQueue(self._redis, self._environment)
        self.recommendations = RecommendationQueue(self._redis, self._environment)
        self.query = QueryClient(self._redis)

    def disconnect(self) -> None:
        """Close the Redis connection."""
        self._redis.close()
