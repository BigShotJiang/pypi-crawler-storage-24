"""Topic assignment queue with typed methods."""

from typing import Any, Optional

import redis as redis_lib

from queue_sdk.queues.base_queue import BaseQueue
from queue_sdk.types import (
    BatchQueueResponse,
    QueueResponse,
    SendResult,
)


class TopicAssignmentQueue(BaseQueue):
    """Typed methods for topic assignment changes via the queue."""

    def __init__(self, redis_client: redis_lib.Redis, environment: str):
        super().__init__(redis_client, environment, "topic-assignment")

    def send(
        self,
        topic_vector_id: str,
        topic_id: str,
        user_id: str,
        current_assignment: Optional[str],
        new_assignment: str,
    ) -> SendResult:
        """Enqueue a topic assignment change (fire and forget)."""
        payload = self._build_payload(
            topic_vector_id, topic_id, user_id, current_assignment, new_assignment
        )
        message_id = self._enqueue(payload)
        return SendResult(message_id=message_id)

    def send_and_wait(
        self,
        topic_vector_id: str,
        topic_id: str,
        user_id: str,
        current_assignment: Optional[str],
        new_assignment: str,
        timeout: Optional[int] = None,
    ) -> QueueResponse:
        """Enqueue a topic assignment and wait for processing confirmation."""
        payload = self._build_payload(
            topic_vector_id, topic_id, user_id, current_assignment, new_assignment
        )
        return self._enqueue_and_wait(payload, timeout)

    def send_batch(
        self,
        assignments: list[dict[str, Any]],
    ) -> SendResult:
        """Enqueue multiple topic assignment changes (fire and forget)."""
        self._validate_batch(assignments)
        payload = self._build_batch_payload(assignments)
        message_id = self._enqueue(payload)
        return SendResult(message_id=message_id)

    def send_batch_and_wait(
        self,
        assignments: list[dict[str, Any]],
        timeout: Optional[int] = None,
    ) -> BatchQueueResponse:
        """Enqueue multiple topic assignments and wait for processing confirmation."""
        self._validate_batch(assignments)
        payload = self._build_batch_payload(assignments)
        response = self._enqueue_and_wait(payload, timeout)

        return BatchQueueResponse(
            success=response.success,
            message_id=response.message_id,
            error=response.error,
            processed_at=response.processed_at,
            total=getattr(response, "total", len(assignments)),
            successful=getattr(response, "successful", len(assignments) if response.success else 0),
            failed=getattr(response, "failed", 0 if response.success else len(assignments)),
        )

    @staticmethod
    def _build_payload(
        topic_vector_id: str,
        topic_id: str,
        user_id: str,
        current_assignment: Optional[str],
        new_assignment: str,
    ) -> dict[str, Any]:
        """Build the topic assignment payload."""
        return {
            "topicVectorId": topic_vector_id,
            "topicId": topic_id,
            "userId": user_id,
            "currentAssignment": current_assignment or "",
            "newAssignment": new_assignment,
        }

    @staticmethod
    def _build_batch_payload(assignments: list[dict[str, Any]]) -> dict[str, Any]:
        """Build the batch topic assignment payload."""
        return {
            "batch": True,
            "assignments": [
                {
                    "topicVectorId": a.get("topic_vector_id", ""),
                    "topicId": a.get("topic_id", ""),
                    "userId": a.get("user_id", ""),
                    "currentAssignment": a.get("current_assignment") or "",
                    "newAssignment": a.get("new_assignment", ""),
                }
                for a in assignments
            ],
        }

    @staticmethod
    def _validate_batch(assignments: list[dict[str, Any]]) -> None:
        """Validate batch constraints."""
        if len(assignments) == 0:
            raise ValueError("At least one assignment is required")
