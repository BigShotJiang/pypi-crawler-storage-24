"""Recommendation queue with typed methods."""

from datetime import datetime, timezone
from typing import Any, Optional

import redis as redis_lib

from queue_sdk.queues.base_queue import BaseQueue
from queue_sdk.types import (
    BatchRecommendationResponse,
    RecommendationResponse,
    SendResult,
)


class RecommendationQueue(BaseQueue):
    """Typed methods for creating recommendation requests via the queue."""

    def __init__(self, redis_client: redis_lib.Redis, environment: str):
        super().__init__(redis_client, environment, "recommendation-requests")

    def create(
        self,
        user_id: str,
        topic_id: str,
        limit: Optional[int] = None,
    ) -> SendResult:
        """Enqueue a recommendation request (fire and forget)."""
        self._validate(user_id, topic_id)
        payload = self._build_payload(user_id, topic_id, limit)
        message_id = self._enqueue(payload)
        return SendResult(message_id=message_id)

    def create_and_wait(
        self,
        user_id: str,
        topic_id: str,
        limit: Optional[int] = None,
        timeout: Optional[int] = None,
    ) -> RecommendationResponse:
        """Enqueue a recommendation request and wait for the result."""
        self._validate(user_id, topic_id)
        payload = self._build_payload(user_id, topic_id, limit)
        response = self._enqueue_and_wait(payload, timeout)

        return RecommendationResponse(
            success=response.success,
            message_id=response.message_id,
            error=response.error,
            processed_at=response.processed_at,
        )

    def create_batch(
        self,
        requests: list[dict[str, Any]],
    ) -> SendResult:
        """Enqueue multiple recommendation requests (fire and forget)."""
        self._validate_batch(requests)
        payload = self._build_batch_payload(requests)
        message_id = self._enqueue(payload)
        return SendResult(message_id=message_id)

    def create_batch_and_wait(
        self,
        requests: list[dict[str, Any]],
        timeout: Optional[int] = None,
    ) -> BatchRecommendationResponse:
        """Enqueue multiple recommendation requests and wait for confirmation."""
        self._validate_batch(requests)
        payload = self._build_batch_payload(requests)
        response = self._enqueue_and_wait(payload, timeout)

        return BatchRecommendationResponse(
            success=response.success,
            message_id=response.message_id,
            error=response.error,
            processed_at=response.processed_at,
            total=getattr(response, "total", len(requests)),
            successful=getattr(
                response, "successful", len(requests) if response.success else 0
            ),
            failed=getattr(response, "failed", 0 if response.success else len(requests)),
        )

    def _build_payload(
        self,
        user_id: str,
        topic_id: str,
        limit: Optional[int],
    ) -> dict[str, Any]:
        """Build the recommendation request payload."""
        payload: dict[str, Any] = {
            "userId": user_id,
            "topicId": topic_id,
            "requestedAt": datetime.now(timezone.utc).isoformat(),
            "key": f"{user_id}-{topic_id}",
        }
        if limit is not None:
            payload["limit"] = limit
        return payload

    def _build_batch_payload(
        self, requests: list[dict[str, Any]]
    ) -> dict[str, Any]:
        """Build the batch recommendation request payload."""
        return {
            "batch": True,
            "requests": [
                self._build_payload(
                    r.get("user_id", ""),
                    r.get("topic_id", ""),
                    r.get("limit"),
                )
                for r in requests
            ],
        }

    @staticmethod
    def _validate(user_id: str, topic_id: str) -> None:
        """Validate the recommendation request."""
        if not user_id:
            raise ValueError("user_id is required")
        if not topic_id:
            raise ValueError("topic_id is required")

    def _validate_batch(self, requests: list[dict[str, Any]]) -> None:
        """Validate the batch of recommendation requests."""
        if len(requests) == 0:
            raise ValueError("At least one request is required")
        if len(requests) > 100:
            raise ValueError("Maximum 100 requests allowed per batch")
        for r in requests:
            self._validate(
                r.get("user_id", ""),
                r.get("topic_id", ""),
            )
