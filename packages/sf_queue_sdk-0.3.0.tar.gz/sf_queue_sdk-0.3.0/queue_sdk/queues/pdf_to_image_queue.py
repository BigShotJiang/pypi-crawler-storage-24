"""PDF to Image queue with typed methods."""

from typing import Any, Optional

import redis as redis_lib

from queue_sdk.queues.base_queue import BaseQueue
from queue_sdk.types import ConvertResponse, SendResult


class PdfToImageQueue(BaseQueue):
    """Typed methods for converting PDFs/videos to images via the queue."""

    def __init__(self, redis_client: redis_lib.Redis, environment: str):
        super().__init__(redis_client, environment, "pdf-to-image-queue")

    def convert(
        self,
        url: str,
        page: Optional[int] = None,
        format: Optional[str] = None,
        quality: Optional[int] = None,
    ) -> SendResult:
        """Enqueue a conversion request (fire and forget)."""
        self._validate(url, page, format, quality)
        payload = self._build_payload(url, page, format, quality)
        message_id = self._enqueue(payload)
        return SendResult(message_id=message_id)

    def convert_and_wait(
        self,
        url: str,
        page: Optional[int] = None,
        format: Optional[str] = None,
        quality: Optional[int] = None,
        timeout: Optional[int] = None,
    ) -> ConvertResponse:
        """Enqueue a conversion request and wait for the result."""
        self._validate(url, page, format, quality)
        payload = self._build_payload(url, page, format, quality)
        response = self._enqueue_and_wait(payload, timeout)

        return ConvertResponse(
            success=response.success,
            message_id=response.message_id,
            image_url=getattr(response, "imageUrl", None) or getattr(response, "image_url", None),
            format=getattr(response, "format", None),
            filename=getattr(response, "filename", None),
            error=response.error,
            processed_at=response.processed_at,
        )

    def _build_payload(
        self,
        url: str,
        page: Optional[int],
        format: Optional[str],
        quality: Optional[int],
    ) -> dict[str, Any]:
        """Build the conversion payload."""
        payload: dict[str, Any] = {"url": url}

        if page is not None:
            payload["page"] = page

        if format is not None:
            payload["format"] = format

        if quality is not None:
            payload["quality"] = quality

        return payload

    @staticmethod
    def _validate(
        url: str,
        page: Optional[int],
        format: Optional[str],
        quality: Optional[int],
    ) -> None:
        """Validate the conversion request."""
        if not url:
            raise ValueError("url is required")

        if page is not None and (page < 1 or not isinstance(page, int)):
            raise ValueError("page must be a positive integer")

        if format is not None and format not in ("png", "webp"):
            raise ValueError("format must be 'png' or 'webp'")

        if quality is not None and (quality < 1 or quality > 100):
            raise ValueError("quality must be between 1 and 100")
