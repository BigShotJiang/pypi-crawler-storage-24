from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional

DESCRIPTOR: _descriptor.FileDescriptor

class WorkflowStepRequest(_message.Message):
    __slots__ = ("step_execution_id",)
    STEP_EXECUTION_ID_FIELD_NUMBER: _ClassVar[int]
    step_execution_id: str
    def __init__(self, step_execution_id: _Optional[str] = ...) -> None: ...

class WorkflowStepResponse(_message.Message):
    __slots__ = ("success", "step_execution_id", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    STEP_EXECUTION_ID_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    step_execution_id: str
    error: str
    def __init__(self, success: _Optional[bool] = ..., step_execution_id: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...

class WorkflowEventRequest(_message.Message):
    __slots__ = ("event_type", "person_id", "workspace_id", "properties")
    class PropertiesEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    EVENT_TYPE_FIELD_NUMBER: _ClassVar[int]
    PERSON_ID_FIELD_NUMBER: _ClassVar[int]
    WORKSPACE_ID_FIELD_NUMBER: _ClassVar[int]
    PROPERTIES_FIELD_NUMBER: _ClassVar[int]
    event_type: str
    person_id: str
    workspace_id: str
    properties: _containers.ScalarMap[str, str]
    def __init__(self, event_type: _Optional[str] = ..., person_id: _Optional[str] = ..., workspace_id: _Optional[str] = ..., properties: _Optional[_Mapping[str, str]] = ...) -> None: ...

class WorkflowEventResponse(_message.Message):
    __slots__ = ("success", "workflows_resumed", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    WORKFLOWS_RESUMED_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    workflows_resumed: int
    error: str
    def __init__(self, success: _Optional[bool] = ..., workflows_resumed: _Optional[int] = ..., error: _Optional[str] = ...) -> None: ...
