from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ToolAssignmentRequest(_message.Message):
    __slots__ = ("tool_id", "user_id", "topic_id", "current_assignment", "new_assignment")
    TOOL_ID_FIELD_NUMBER: _ClassVar[int]
    USER_ID_FIELD_NUMBER: _ClassVar[int]
    TOPIC_ID_FIELD_NUMBER: _ClassVar[int]
    CURRENT_ASSIGNMENT_FIELD_NUMBER: _ClassVar[int]
    NEW_ASSIGNMENT_FIELD_NUMBER: _ClassVar[int]
    tool_id: str
    user_id: str
    topic_id: str
    current_assignment: str
    new_assignment: str
    def __init__(self, tool_id: _Optional[str] = ..., user_id: _Optional[str] = ..., topic_id: _Optional[str] = ..., current_assignment: _Optional[str] = ..., new_assignment: _Optional[str] = ...) -> None: ...

class BatchToolAssignmentRequest(_message.Message):
    __slots__ = ("assignments",)
    ASSIGNMENTS_FIELD_NUMBER: _ClassVar[int]
    assignments: _containers.RepeatedCompositeFieldContainer[ToolAssignmentRequest]
    def __init__(self, assignments: _Optional[_Iterable[_Union[ToolAssignmentRequest, _Mapping]]] = ...) -> None: ...

class ToolAssignmentResponse(_message.Message):
    __slots__ = ("success", "message_id", "error")
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_ID_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    success: bool
    message_id: str
    error: str
    def __init__(self, success: _Optional[bool] = ..., message_id: _Optional[str] = ..., error: _Optional[str] = ...) -> None: ...
