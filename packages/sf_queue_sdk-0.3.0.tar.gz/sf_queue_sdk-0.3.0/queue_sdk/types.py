"""Type definitions for the queue SDK."""

from dataclasses import dataclass
from typing import Optional


@dataclass
class QueueClientConfig:
    """Configuration for the QueueClient."""

    redis_url: str
    redis_password: str
    environment: str


@dataclass
class EmailButton:
    """CTA button for email."""

    text: str
    href: str


@dataclass
class EmailImage:
    """Optional image for email."""

    src: str
    alt: str = ""
    width: Optional[int] = None
    height: Optional[int] = None


@dataclass
class EmailData:
    """Data for a single email."""

    to: str
    preview: str
    subject: str
    paragraphs: list[str]
    button: Optional[EmailButton] = None
    reply_to: Optional[str] = None
    image: Optional[EmailImage] = None
    service: Optional[str] = None
    template: Optional[str] = None
    html: Optional[str] = None


@dataclass
class BatchEmailData:
    """Data for a batch email (same content to multiple recipients)."""

    to: list[str]
    preview: str
    subject: str
    paragraphs: list[str]
    button: Optional[EmailButton] = None
    reply_to: Optional[str] = None
    image: Optional[EmailImage] = None
    service: Optional[str] = None
    template: Optional[str] = None
    html: Optional[str] = None


@dataclass
class SendResult:
    """Result of a fire-and-forget send."""

    message_id: str


@dataclass
class EmailResponse:
    """Response from a processed email."""

    success: bool
    message_id: str
    error: Optional[str] = None
    processed_at: Optional[str] = None


@dataclass
class BatchEmailResponse:
    """Response from a processed batch email."""

    success: bool
    message_id: str
    total: int
    successful: int
    failed: int
    error: Optional[str] = None
    processed_at: Optional[str] = None


# Generic response aliases (used by non-email queues)
QueueResponse = EmailResponse
BatchQueueResponse = BatchEmailResponse


@dataclass
class TopicAssignmentData:
    """Data for a single topic assignment change."""

    topic_vector_id: str
    topic_id: str
    user_id: str
    current_assignment: Optional[str]
    new_assignment: str


@dataclass
class BatchTopicAssignmentData:
    """Data for multiple topic assignment changes."""

    assignments: list[TopicAssignmentData]


@dataclass
class ToolAssignmentData:
    """Data for a single tool assignment change."""

    tool_id: str
    user_id: str
    topic_id: str
    current_assignment: Optional[str]
    new_assignment: str


@dataclass
class BatchToolAssignmentData:
    """Data for multiple tool assignment changes."""

    assignments: list[ToolAssignmentData]


@dataclass
class RecommendationRequestData:
    """Data for a recommendation request (mirrors Kafka recommendationRequests)."""

    user_id: str
    topic_id: str
    limit: Optional[int] = None


@dataclass
class RecommendationResponse:
    """Response from a processed recommendation request."""

    success: bool
    message_id: str
    error: Optional[str] = None
    processed_at: Optional[str] = None


@dataclass
class BatchRecommendationRequestData:
    """Data for multiple recommendation requests."""

    requests: list[dict]


@dataclass
class BatchRecommendationResponse:
    """Response from a processed batch of recommendation requests."""

    success: bool
    message_id: str
    total: int
    successful: int
    failed: int
    error: Optional[str] = None
    processed_at: Optional[str] = None


@dataclass
class ConvertData:
    """Data for a PDF/video to image conversion request."""

    url: str
    page: Optional[int] = None
    format: Optional[str] = None
    quality: Optional[int] = None


@dataclass
class ConvertResponse:
    """Response from a processed conversion request."""

    success: bool
    message_id: str
    image_url: Optional[str] = None
    format: Optional[str] = None
    filename: Optional[str] = None
    error: Optional[str] = None
    processed_at: Optional[str] = None
