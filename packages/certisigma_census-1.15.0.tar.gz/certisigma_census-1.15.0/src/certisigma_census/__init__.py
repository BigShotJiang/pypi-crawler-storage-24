"""CertiSigma Census — Cryptographic file inventory and exfiltration detection."""

__version__ = "1.15.0"
