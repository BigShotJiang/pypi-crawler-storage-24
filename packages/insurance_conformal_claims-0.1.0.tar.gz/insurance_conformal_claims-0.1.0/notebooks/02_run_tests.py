# Databricks notebook source
# MAGIC %md
# MAGIC # insurance-conformal-claims: Test Runner
# MAGIC
# MAGIC Installs from workspace source, then runs pytest.

# COMMAND ----------

# MAGIC %pip install scikit-learn catboost matplotlib pytest

# COMMAND ----------

import subprocess, sys, os

# Install the library from workspace source
result = subprocess.run(
    [sys.executable, "-m", "pip", "install", "-e",
     "/Workspace/insurance-conformal-claims"],
    capture_output=True, text=True
)
print(result.stdout[-2000:] if result.stdout else "")
print(result.stderr[-1000:] if result.stderr else "")
print("pip install return code:", result.returncode)

# COMMAND ----------

# Run pytest
result = subprocess.run(
    [sys.executable, "-m", "pytest", "-v", "--tb=short",
     "/Workspace/insurance-conformal-claims/tests/"],
    capture_output=True,
    text=True,
    cwd="/Workspace/insurance-conformal-claims",
    env={**os.environ, "PYTHONPATH": "/Workspace/insurance-conformal-claims/src"},
)
print(result.stdout)
if result.stderr:
    print("STDERR:", result.stderr[-2000:])

# COMMAND ----------

print(f"pytest return code: {result.returncode}")
dbutils.notebook.exit("PASSED" if result.returncode == 0 else "FAILED")
