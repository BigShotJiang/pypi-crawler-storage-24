# Databricks notebook source
# MAGIC %md
# MAGIC # insurance-conformal-claims: Full Workflow Demo
# MAGIC
# MAGIC This notebook demonstrates the full workflow on synthetic Tweedie compound
# MAGIC Poisson-Gamma data. It covers:
# MAGIC
# MAGIC 1. Data generation (realistic insurance claims DGP)
# MAGIC 2. HongConformal — model-free intervals with the order-statistic shortcut
# MAGIC 3. HongTransformConformal — narrower intervals with a regression model
# MAGIC 4. TweedePearsonScore — split conformal with Tweedie-specific score
# MAGIC 5. TwoStageLWConformal — auto-fitted spread model via CatBoost
# MAGIC 6. SCRReport — Solvency II 99.5% capital requirement
# MAGIC 7. Diagnostics — conditional coverage gap, calibration plot

# COMMAND ----------

# MAGIC %pip install insurance-conformal-claims[all] scikit-learn catboost matplotlib

# COMMAND ----------

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from insurance_conformal_claims import (
    HongConformal,
    HongTransformConformal,
    TweedePearsonScore,
    TwoStageLWConformal,
    SCRReport,
    conditional_coverage_gap,
    calibration_plot,
    calibration_plot_data,
    width_by_covariate,
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Synthetic Data: Tweedie Compound Poisson-Gamma
# MAGIC
# MAGIC The data generating process:
# MAGIC - 6 covariates (age, exposure, vehicle class, region, ncb, limit)
# MAGIC - Log-linear mean: mu = exp(beta_0 + X @ beta)
# MAGIC - Y ~ Tweedie(mu, phi=1, p=1.5) = sum_{k=1}^N G_k, N ~ Poisson, G_k ~ Gamma
# MAGIC - ~40% zero claims (typical UK motor book)

# COMMAND ----------

def simulate_motor_claims(n: int, seed: int = 42):
    """Simulate UK-style motor claims with 6 covariates."""
    rng = np.random.default_rng(seed)

    # Covariates
    age = rng.uniform(18, 75, n)              # driver age
    exposure = rng.uniform(0.1, 1.0, n)       # years at risk
    vehicle_class = rng.integers(1, 5, n)     # 1-4 (telematics tier)
    region = rng.integers(1, 12, n)           # UK rating region
    ncb = rng.integers(0, 6, n)               # no-claims bonus years
    limit = rng.choice([50_000, 100_000, 250_000], size=n)  # cover limit

    X = np.column_stack([age, exposure, vehicle_class, region, ncb, limit / 1e5])

    # Log-linear mean
    beta = np.array([0.02, 0.5, 0.15, 0.03, -0.08, 0.01])
    log_mu = 1.8 + X @ beta
    mu = np.exp(log_mu)

    # Tweedie simulation (p=1.5)
    p = 1.5
    alpha_g = (2 - p) / (p - 1)  # = 1.0
    y = np.zeros(n)
    for i in range(n):
        lam = mu[i] ** (2 - p) / (2 - p)
        k = rng.poisson(lam)
        if k > 0:
            scale = mu[i] ** (p - 1) * (p - 1)
            y[i] = rng.gamma(alpha_g * k, scale)

    return X, y

# COMMAND ----------

N_TRAIN = 1000
N_CAL = 400
N_TEST = 300

X_all, y_all = simulate_motor_claims(N_TRAIN + N_CAL + N_TEST, seed=42)
X_train, y_train = X_all[:N_TRAIN], y_all[:N_TRAIN]
X_cal, y_cal = X_all[N_TRAIN:N_TRAIN + N_CAL], y_all[N_TRAIN:N_TRAIN + N_CAL]
X_test, y_test = X_all[N_TRAIN + N_CAL:], y_all[N_TRAIN + N_CAL:]

print(f"Training:    {N_TRAIN} observations, {(y_train == 0).mean():.1%} zero claims")
print(f"Calibration: {N_CAL}  observations, {(y_cal == 0).mean():.1%} zero claims")
print(f"Test:        {N_TEST}  observations, {(y_test == 0).mean():.1%} zero claims")
print(f"Mean claim (non-zero): £{y_train[y_train > 0].mean():,.0f}")
print(f"Max claim:             £{y_train.max():,.0f}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. HongConformal — Model-Free Order-Statistic Shortcut
# MAGIC
# MAGIC No GLM. No distributional assumption. Finite-sample valid for all n.

# COMMAND ----------

hc = HongConformal(batch_size=500)
hc.fit(X_train, y_train)
print(hc)

# COMMAND ----------

# Coverage at multiple alpha levels
print("\nHongConformal coverage diagnostics:")
print(f"{'Alpha':>8} {'Nominal':>10} {'Empirical':>12} {'Mean Width':>12}")
print("-" * 46)
for alpha in [0.005, 0.01, 0.05, 0.10, 0.20]:
    diag = hc.coverage_diagnostic(X_test, y_test, alpha=alpha)
    print(
        f"{alpha:>8.3f} {diag['nominal_coverage']:>10.1%} "
        f"{diag['empirical_coverage']:>12.1%} {diag['mean_width']:>12,.1f}"
    )

# COMMAND ----------

# Show some example intervals
intervals = hc.predict_interval(X_test[:10], alpha=0.005)
print("\nExample 99.5% prediction intervals (first 10 test observations):")
for i in range(10):
    y_actual = y_test[i]
    upper = intervals[i, 1]
    covered = "YES" if y_actual <= upper else "NO "
    print(f"  Obs {i+1:3d}: actual=£{y_actual:8,.0f}  upper=£{upper:10,.0f}  covered={covered}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 3. HongTransformConformal — h-Transformation with Ridge Regression
# MAGIC
# MAGIC A linear h reduces interval width by ~25% while keeping the coverage guarantee.

# COMMAND ----------

from sklearn.linear_model import Ridge, Lasso
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline

ridge_h = Pipeline([("scaler", StandardScaler()), ("ridge", Ridge(alpha=1.0))])

htc = HongTransformConformal(h_model=ridge_h)
htc.fit(X_train, y_train, X_cal, y_cal)
print(htc)

# COMMAND ----------

print("\nHongTransformConformal (Ridge h) coverage diagnostics:")
print(f"{'Alpha':>8} {'Nominal':>10} {'Empirical':>12} {'Mean Width':>12}")
print("-" * 46)
for alpha in [0.005, 0.01, 0.05, 0.10]:
    diag = htc.coverage_diagnostic(X_test, y_test, alpha=alpha)
    print(
        f"{alpha:>8.3f} {diag['nominal_coverage']:>10.1%} "
        f"{diag['empirical_coverage']:>12.1%} {diag['mean_width']:>12,.1f}"
    )

# Compare widths at 95%
hc_diag = hc.coverage_diagnostic(X_test, y_test, alpha=0.05)
htc_diag = htc.coverage_diagnostic(X_test, y_test, alpha=0.05)
width_reduction = (hc_diag["mean_width"] - htc_diag["mean_width"]) / hc_diag["mean_width"]
print(f"\nWidth reduction from h-transformation: {width_reduction:.1%}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 4. Tweedie Nonconformity Scores — Direct Usage

# COMMAND ----------

from insurance_conformal_claims import TweedieDevianceScore, TweedieAnscombeScore

# Split conformal with Pearson score (manual)
# Stage 1: fit mean model on training data
from sklearn.ensemble import GradientBoostingRegressor
mean_model = GradientBoostingRegressor(n_estimators=100, random_state=42)
mean_model.fit(X_train, y_train)

mu_cal = mean_model.predict(X_cal)
mu_test = mean_model.predict(X_test)

print("Comparing Tweedie nonconformity scores at alpha=0.05:")
print(f"{'Score':>20} {'Empirical Coverage':>20} {'Mean Width':>12}")
print("-" * 56)

for ScoreClass, name in [
    (TweedePearsonScore, "Pearson"),
    (TweedieDevianceScore, "Deviance"),
    (TweedieAnscombeScore, "Anscombe"),
]:
    score = ScoreClass(p=1.5)
    cal_scores = score.score(y_cal, mu_cal)

    # Conformal quantile
    n_cal = len(cal_scores)
    k = int(np.ceil(0.95 * (n_cal + 1)))
    k = min(k, n_cal)
    q = float(np.sort(cal_scores)[k - 1])

    upper = score.inverse(q, mu_test, upper=True)
    lower = score.inverse(q, mu_test, upper=False)
    covered = (y_test >= lower) & (y_test <= upper)
    width = float((upper - lower).mean())
    print(f"{name:>20} {covered.mean():>20.1%} {width:>12,.1f}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 5. TwoStageLWConformal — Auto-Fitted CatBoost Spread Model

# COMMAND ----------

from catboost import CatBoostRegressor

mean_model_cb = CatBoostRegressor(
    loss_function="Tweedie:variance_power=1.5",
    iterations=500,
    learning_rate=0.05,
    depth=5,
    verbose=0,
    random_seed=42,
)

lw = TwoStageLWConformal(mean_model=mean_model_cb, p=1.5)
lw.fit(X_train, y_train)
lw.calibrate(X_cal, y_cal)
print(lw)

# COMMAND ----------

print("\nTwoStageLWConformal coverage diagnostics:")
print(f"{'Alpha':>8} {'Nominal':>10} {'Empirical':>12} {'Mean Width':>12}")
print("-" * 46)
for alpha in [0.005, 0.01, 0.05, 0.10]:
    diag = lw.coverage_diagnostic(X_test, y_test, alpha=alpha)
    print(
        f"{alpha:>8.3f} {diag['nominal_coverage']:>10.1%} "
        f"{diag['empirical_coverage']:>12.1%} {diag['mean_width']:>12,.1f}"
    )

# COMMAND ----------

# MAGIC %md
# MAGIC ## 6. SCRReport — Solvency II Capital Requirement

# COMMAND ----------

report = SCRReport(hc)
scr = report.solvency_capital_requirement(X_test, alpha=0.005)
agg_reserve = report.aggregate_reserve(X_test, alpha=0.005)

print(f"Solvency II SCR (99.5% VaR, single risk):    £{scr:>12,.0f}")
print(f"Aggregate reserve (sum of upper bounds):      £{agg_reserve:>12,.0f}")
print(f"N portfolio risks:                             {len(X_test):>12,}")
print(f"Average upper bound per risk:                 £{agg_reserve/len(X_test):>12,.0f}")

# COMMAND ----------

df_coverage = report.coverage_table(X_test, y_test)
print("\nCoverage table:")
display(df_coverage)

# COMMAND ----------

# Generate HTML report
html = report.to_html(title="Motor Claims SCR Report — Synthetic Data")
with open("/tmp/scr_report.html", "w") as f:
    f.write(html)
print("HTML report written to /tmp/scr_report.html")

# COMMAND ----------

# MAGIC %md
# MAGIC ## 7. Diagnostics

# COMMAND ----------

# Calibration plot
fig, ax = plt.subplots(figsize=(7, 6))
calibration_plot(hc, X_test, y_test, ax=ax)
ax.set_title("HongConformal Calibration — Synthetic Motor Claims")
plt.tight_layout()
plt.savefig("/tmp/calibration_plot.png", dpi=120)
plt.show()

# COMMAND ----------

# Conditional coverage gap by vehicle class
vehicle_class = X_test[:, 2].astype(int)
result = conditional_coverage_gap(
    hc, X_test, y_test, alpha=0.10, groups=vehicle_class
)

print(f"Overall coverage: {result['overall_coverage']:.1%} (nominal: {result['nominal_coverage']:.1%})")
print(f"Max coverage gap: {result['max_gap']:+.1%}")
print(f"Min coverage gap: {result['min_gap']:+.1%}")
print("\nPer-group results:")
display(result["group_results"])

# COMMAND ----------

# Width by age covariate
df_width = width_by_covariate(hc, X_test, y_test, alpha=0.05, covariate_idx=0, n_bins=8)
print("Interval width by driver age quantile bin:")
display(df_width[["bin_centre", "mean_width", "mean_coverage", "n"]])

# COMMAND ----------

# MAGIC %md
# MAGIC ## 8. Comparison: Conformal vs GLM Intervals Under Misspecification
# MAGIC
# MAGIC Reproducing the spirit of Table 2 from Hong (2025): GLM intervals collapse
# MAGIC under distributional misspecification; conformal intervals remain valid.

# COMMAND ----------

from sklearn.linear_model import LinearRegression

# Simulate data from a heavy-tailed distribution
rng = np.random.default_rng(99)
n_mis = 500
X_mis = rng.normal(size=(n_mis, 3))
# True DGP: Pareto with heavy tail
alpha_pareto = 2.5
y_mis = (rng.pareto(alpha_pareto, size=n_mis) + 1) * 5.0  # shift to positive

X_train_mis, y_train_mis = X_mis[:300], y_mis[:300]
X_test_mis, y_test_mis = X_mis[300:], y_mis[300:]

# GLM (log-normal assumption — wrong)
log_y = np.log(y_train_mis + 1e-6)
glm = LinearRegression().fit(X_train_mis, log_y)
mu_log_test = glm.predict(X_test_mis)
sigma_est = np.std(log_y - glm.predict(X_train_mis))
# 99.5% log-normal interval
from scipy import stats
z_995 = stats.norm.ppf(0.995)
upper_glm = np.exp(mu_log_test + z_995 * sigma_est)
glm_coverage = float((y_test_mis <= upper_glm).mean())

# Conformal (model-free, no distribution assumption)
hc_mis = HongConformal().fit(X_train_mis, y_train_mis)
diag_mis = hc_mis.coverage_diagnostic(X_test_mis, y_test_mis, alpha=0.005)

print("Coverage under distributional misspecification (Pareto DGP, log-normal assumed):")
print(f"{'Method':>25} {'Actual Coverage':>18} {'Nominal':>10}")
print("-" * 55)
print(f"{'Conformal (HongConformal)':>25} {diag_mis['empirical_coverage']:>18.1%} {'99.5%':>10}")
print(f"{'GLM (log-normal, wrong)':>25} {glm_coverage:>18.1%} {'99.5%':>10}")
print()
print("The GLM assumes a distribution that doesn't hold. Conformal does not.")

# COMMAND ----------

print("\nAll cells completed successfully.")
print("Library: insurance-conformal-claims")
print("Methods: HongConformal, HongTransformConformal, TweedePearsonScore,")
print("         TwoStageLWConformal, SCRReport, diagnostics")
