# Databricks notebook source
# MAGIC %pip install scikit-learn catboost matplotlib pytest hatchling

# COMMAND ----------

import subprocess, sys, os

# Copy project to /tmp where pycache writing is allowed
subprocess.run(["cp", "-r", "/Workspace/insurance-conformal-claims", "/tmp/icc"], capture_output=True)
print("Copied to /tmp/icc")

# Install library from /tmp copy
result = subprocess.run(
    [sys.executable, "-m", "pip", "install", "-e", "/tmp/icc"],
    capture_output=True, text=True
)
print("pip rc:", result.returncode)
if result.returncode != 0:
    print("pip stderr:", result.stderr[-1000:])

# COMMAND ----------

import subprocess, sys, os

env = dict(os.environ)
env["PYTHONPATH"] = "/tmp/icc/src:/tmp/icc/tests:" + env.get("PYTHONPATH", "")
env["PYTHONDONTWRITEBYTECODE"] = "1"

result = subprocess.run(
    [sys.executable, "-m", "pytest", "-v", "--tb=short",
     "/tmp/icc/tests/"],
    capture_output=True, text=True,
    cwd="/tmp/icc",
    env=env,
)
with open("/tmp/pytest_output.txt", "w") as f:
    f.write(result.stdout + "\n--- STDERR ---\n" + result.stderr)

rc = result.returncode
print("pytest rc:", rc)

# COMMAND ----------

with open("/tmp/pytest_output.txt") as f:
    content = f.read()

for i in range(0, len(content), 4000):
    print(content[i:i+4000])

# COMMAND ----------

dbutils.notebook.exit(f"rc={result.returncode}|||" + content[-3000:])
