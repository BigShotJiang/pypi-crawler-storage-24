# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class JobSpec:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'type': 'str',
        'cluster_uid': 'str',
        'resource_id': 'str',
        'resource_name': 'str',
        'extend_param': 'dict(str, str)',
        'sub_jobs': 'list[Job]'
    }

    attribute_map = {
        'type': 'type',
        'cluster_uid': 'clusterUID',
        'resource_id': 'resourceID',
        'resource_name': 'resourceName',
        'extend_param': 'extendParam',
        'sub_jobs': 'subJobs'
    }

    def __init__(self, type=None, cluster_uid=None, resource_id=None, resource_name=None, extend_param=None, sub_jobs=None):
        r"""JobSpec

        The model defined in huaweicloud sdk

        :param type: **参数解释**： 任务的类型。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type type: str
        :param cluster_uid: **参数解释**： 任务所在的集群的ID。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type cluster_uid: str
        :param resource_id: **参数解释**： 任务操作的资源ID。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type resource_id: str
        :param resource_name: **参数解释**： 任务操作的资源名称。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type resource_name: str
        :param extend_param: **参数解释**： 扩展参数 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type extend_param: dict(str, str)
        :param sub_jobs: **参数解释**： 子任务的列表。 - 包含了所有子任务的详细信息 - 在创建集群、节点等场景下，通常会由多个子任务共同组成创建任务，在子任务都完成后，任务才会完成  **约束限制**： 不涉及 
        :type sub_jobs: list[:class:`huaweicloudsdkcce.v3.Job`]
        """
        
        

        self._type = None
        self._cluster_uid = None
        self._resource_id = None
        self._resource_name = None
        self._extend_param = None
        self._sub_jobs = None
        self.discriminator = None

        if type is not None:
            self.type = type
        if cluster_uid is not None:
            self.cluster_uid = cluster_uid
        if resource_id is not None:
            self.resource_id = resource_id
        if resource_name is not None:
            self.resource_name = resource_name
        if extend_param is not None:
            self.extend_param = extend_param
        if sub_jobs is not None:
            self.sub_jobs = sub_jobs

    @property
    def type(self):
        r"""Gets the type of this JobSpec.

        **参数解释**： 任务的类型。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The type of this JobSpec.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this JobSpec.

        **参数解释**： 任务的类型。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param type: The type of this JobSpec.
        :type type: str
        """
        self._type = type

    @property
    def cluster_uid(self):
        r"""Gets the cluster_uid of this JobSpec.

        **参数解释**： 任务所在的集群的ID。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The cluster_uid of this JobSpec.
        :rtype: str
        """
        return self._cluster_uid

    @cluster_uid.setter
    def cluster_uid(self, cluster_uid):
        r"""Sets the cluster_uid of this JobSpec.

        **参数解释**： 任务所在的集群的ID。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param cluster_uid: The cluster_uid of this JobSpec.
        :type cluster_uid: str
        """
        self._cluster_uid = cluster_uid

    @property
    def resource_id(self):
        r"""Gets the resource_id of this JobSpec.

        **参数解释**： 任务操作的资源ID。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The resource_id of this JobSpec.
        :rtype: str
        """
        return self._resource_id

    @resource_id.setter
    def resource_id(self, resource_id):
        r"""Sets the resource_id of this JobSpec.

        **参数解释**： 任务操作的资源ID。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param resource_id: The resource_id of this JobSpec.
        :type resource_id: str
        """
        self._resource_id = resource_id

    @property
    def resource_name(self):
        r"""Gets the resource_name of this JobSpec.

        **参数解释**： 任务操作的资源名称。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The resource_name of this JobSpec.
        :rtype: str
        """
        return self._resource_name

    @resource_name.setter
    def resource_name(self, resource_name):
        r"""Sets the resource_name of this JobSpec.

        **参数解释**： 任务操作的资源名称。 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param resource_name: The resource_name of this JobSpec.
        :type resource_name: str
        """
        self._resource_name = resource_name

    @property
    def extend_param(self):
        r"""Gets the extend_param of this JobSpec.

        **参数解释**： 扩展参数 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The extend_param of this JobSpec.
        :rtype: dict(str, str)
        """
        return self._extend_param

    @extend_param.setter
    def extend_param(self, extend_param):
        r"""Sets the extend_param of this JobSpec.

        **参数解释**： 扩展参数 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param extend_param: The extend_param of this JobSpec.
        :type extend_param: dict(str, str)
        """
        self._extend_param = extend_param

    @property
    def sub_jobs(self):
        r"""Gets the sub_jobs of this JobSpec.

        **参数解释**： 子任务的列表。 - 包含了所有子任务的详细信息 - 在创建集群、节点等场景下，通常会由多个子任务共同组成创建任务，在子任务都完成后，任务才会完成  **约束限制**： 不涉及 

        :return: The sub_jobs of this JobSpec.
        :rtype: list[:class:`huaweicloudsdkcce.v3.Job`]
        """
        return self._sub_jobs

    @sub_jobs.setter
    def sub_jobs(self, sub_jobs):
        r"""Sets the sub_jobs of this JobSpec.

        **参数解释**： 子任务的列表。 - 包含了所有子任务的详细信息 - 在创建集群、节点等场景下，通常会由多个子任务共同组成创建任务，在子任务都完成后，任务才会完成  **约束限制**： 不涉及 

        :param sub_jobs: The sub_jobs of this JobSpec.
        :type sub_jobs: list[:class:`huaweicloudsdkcce.v3.Job`]
        """
        self._sub_jobs = sub_jobs

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, JobSpec):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
