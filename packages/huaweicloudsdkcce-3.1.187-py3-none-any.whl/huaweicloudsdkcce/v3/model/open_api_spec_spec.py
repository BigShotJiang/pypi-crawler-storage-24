# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class OpenAPISpecSpec:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'eip': 'EipSpec',
        'is_dynamic': 'bool'
    }

    attribute_map = {
        'eip': 'eip',
        'is_dynamic': 'IsDynamic'
    }

    def __init__(self, eip=None, is_dynamic=None):
        r"""OpenAPISpecSpec

        The model defined in huaweicloud sdk

        :param eip: 
        :type eip: :class:`huaweicloudsdkcce.v3.EipSpec`
        :param is_dynamic: **参数解释**： 是否动态创建 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type is_dynamic: bool
        """
        
        

        self._eip = None
        self._is_dynamic = None
        self.discriminator = None

        if eip is not None:
            self.eip = eip
        if is_dynamic is not None:
            self.is_dynamic = is_dynamic

    @property
    def eip(self):
        r"""Gets the eip of this OpenAPISpecSpec.

        :return: The eip of this OpenAPISpecSpec.
        :rtype: :class:`huaweicloudsdkcce.v3.EipSpec`
        """
        return self._eip

    @eip.setter
    def eip(self, eip):
        r"""Sets the eip of this OpenAPISpecSpec.

        :param eip: The eip of this OpenAPISpecSpec.
        :type eip: :class:`huaweicloudsdkcce.v3.EipSpec`
        """
        self._eip = eip

    @property
    def is_dynamic(self):
        r"""Gets the is_dynamic of this OpenAPISpecSpec.

        **参数解释**： 是否动态创建 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The is_dynamic of this OpenAPISpecSpec.
        :rtype: bool
        """
        return self._is_dynamic

    @is_dynamic.setter
    def is_dynamic(self, is_dynamic):
        r"""Sets the is_dynamic of this OpenAPISpecSpec.

        **参数解释**： 是否动态创建 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param is_dynamic: The is_dynamic of this OpenAPISpecSpec.
        :type is_dynamic: bool
        """
        self._is_dynamic = is_dynamic

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, OpenAPISpecSpec):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
