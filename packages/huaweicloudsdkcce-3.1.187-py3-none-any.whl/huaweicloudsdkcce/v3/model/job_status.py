# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class JobStatus:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'phase': 'str',
        'reason': 'str'
    }

    attribute_map = {
        'phase': 'phase',
        'reason': 'reason'
    }

    def __init__(self, phase=None, reason=None):
        r"""JobStatus

        The model defined in huaweicloud sdk

        :param phase: **参数解释**： 任务的状态 **约束限制**： 不涉及 **取值范围**： - Initializing：初始化 - Running：运行中 - Failed：失败 - Success：成功  **默认取值**： 不涉及
        :type phase: str
        :param reason: **参数解释**： 任务变为当前状态的原因 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 
        :type reason: str
        """
        
        

        self._phase = None
        self._reason = None
        self.discriminator = None

        if phase is not None:
            self.phase = phase
        if reason is not None:
            self.reason = reason

    @property
    def phase(self):
        r"""Gets the phase of this JobStatus.

        **参数解释**： 任务的状态 **约束限制**： 不涉及 **取值范围**： - Initializing：初始化 - Running：运行中 - Failed：失败 - Success：成功  **默认取值**： 不涉及

        :return: The phase of this JobStatus.
        :rtype: str
        """
        return self._phase

    @phase.setter
    def phase(self, phase):
        r"""Sets the phase of this JobStatus.

        **参数解释**： 任务的状态 **约束限制**： 不涉及 **取值范围**： - Initializing：初始化 - Running：运行中 - Failed：失败 - Success：成功  **默认取值**： 不涉及

        :param phase: The phase of this JobStatus.
        :type phase: str
        """
        self._phase = phase

    @property
    def reason(self):
        r"""Gets the reason of this JobStatus.

        **参数解释**： 任务变为当前状态的原因 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :return: The reason of this JobStatus.
        :rtype: str
        """
        return self._reason

    @reason.setter
    def reason(self, reason):
        r"""Sets the reason of this JobStatus.

        **参数解释**： 任务变为当前状态的原因 **约束限制**： 不涉及 **取值范围**： 不涉及 **默认取值**： 不涉及 

        :param reason: The reason of this JobStatus.
        :type reason: str
        """
        self._reason = reason

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, JobStatus):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
