from echon.extractor import MemoryExtractor
from echon.models import MemoryType


class TestRuleExtract:
    def setup_method(self):
        self.extractor = MemoryExtractor()

    def test_preference_chinese(self):
        results = self.extractor.extract("我喜欢简洁的代码风格")
        assert len(results) > 0
        assert results[0]["memory_type"] == MemoryType.PREFERENCE

    def test_preference_english(self):
        results = self.extractor.extract("I prefer clean code")
        assert len(results) > 0
        assert results[0]["memory_type"] == MemoryType.PREFERENCE

    def test_fact_chinese(self):
        results = self.extractor.extract("我是一名数据科学家")
        assert len(results) > 0
        assert results[0]["memory_type"] == MemoryType.FACT

    def test_event_chinese(self):
        results = self.extractor.extract("今天完成了项目的部署工作")
        assert len(results) > 0
        assert results[0]["memory_type"] == MemoryType.EVENT

    def test_no_match(self):
        results = self.extractor.extract("hello")
        assert len(results) == 0


class TestLLMResultParsing:
    def setup_method(self):
        self.extractor = MemoryExtractor()

    def test_parse_valid(self):
        result = "fact|用户是一名工程师|0.8\npreference|喜欢Python|0.6"
        items = self.extractor._parse_llm_result(result)
        assert len(items) == 2
        assert items[0]["content"] == "用户是一名工程师"
        assert items[0]["memory_type"] == MemoryType.FACT
        assert items[0]["importance"] == 0.8

    def test_parse_empty(self):
        assert self.extractor._parse_llm_result("无") == []
        assert self.extractor._parse_llm_result("") == []

    def test_parse_invalid_type(self):
        result = "unknown|some content|0.5"
        items = self.extractor._parse_llm_result(result)
        assert len(items) == 1
        assert items[0]["memory_type"] == MemoryType.FACT  # fallback

    def test_parse_importance_clamped(self):
        result = "fact|内容A|2.5\nfact|内容B|-0.3"
        items = self.extractor._parse_llm_result(result)
        assert items[0]["importance"] == 1.0
        assert items[1]["importance"] == 0.0
