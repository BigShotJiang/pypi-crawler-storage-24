import hashlib
from typing import List

from maque.embedding.base import BaseEmbedding


class FakeEmbedding(BaseEmbedding):
    """测试用假 Embedding，基于文本 hash 生成确定性向量"""

    DIM = 16

    def embed(self, inputs: List[str], **kwargs) -> List[List[float]]:
        return [self._text_to_vec(t) for t in inputs]

    async def aembed(self, inputs: List[str], **kwargs) -> List[List[float]]:
        return self.embed(inputs)

    @property
    def dimension(self) -> int:
        return self.DIM

    def _text_to_vec(self, text: str) -> List[float]:
        """用 hash 生成确定性伪向量，相同文本 → 相同向量"""
        h = hashlib.md5(text.encode()).hexdigest()
        vec = [int(c, 16) / 15.0 for c in h[: self.DIM]]
        # 归一化
        norm = sum(x * x for x in vec) ** 0.5
        return [x / norm for x in vec]
