import math
import tempfile
import time

import pytest

from echon.config import EchonConfig
from echon.evolution import EvolutionEngine
from echon.models import MemoryItem, MemoryType
from echon.store import MemoryStore
from helpers import FakeEmbedding


@pytest.fixture
def env():
    with tempfile.TemporaryDirectory() as tmpdir:
        emb = FakeEmbedding()
        store = MemoryStore("test_evo", tmpdir, emb)
        config = EchonConfig()
        engine = EvolutionEngine(store, config)
        yield store, engine, config
        store.close()


class TestEffectiveImportance:
    def test_fresh_memory(self, env):
        _, engine, _ = env
        item = MemoryItem(content="test", importance=1.0)
        eff = engine.effective_importance(item)
        # 刚创建，衰减极小，access_count=0 → freq_boost=1.0
        assert eff == pytest.approx(1.0, abs=0.01)

    def test_decayed_memory(self, env):
        _, engine, config = env
        item = MemoryItem(content="test", importance=1.0)
        hours = 30 * 24
        future = item.updated_at + hours * 3600
        eff = engine.effective_importance(item, now=future)
        expected = math.exp(-config.decay_lambda * hours)
        assert eff == pytest.approx(expected, abs=0.01)

    def test_access_boost(self, env):
        _, engine, _ = env
        item = MemoryItem(content="test", importance=1.0, access_count=10)
        eff = engine.effective_importance(item)
        freq_boost = min(1 + math.log2(11) * 0.1, 1.5)
        assert eff == pytest.approx(freq_boost, abs=0.01)


class TestDeduplicateOrMerge:
    def test_no_similar_adds(self, env):
        store, engine, _ = env
        item = MemoryItem(content="独特的内容ABC")
        action, result = engine.deduplicate_or_merge(item)
        assert action == "added"

    def test_duplicate_detection(self, env):
        store, engine, _ = env
        # 存储一条记忆
        existing = MemoryItem(content="用户喜欢Python编程", importance=0.5)
        store.save(existing)

        # 完全相同内容 → 相同向量 → 去重
        new = MemoryItem(content="用户喜欢Python编程", importance=0.3)
        action, result = engine.deduplicate_or_merge(new)
        assert action == "deduplicated"
        assert result.id == existing.id
        assert result.access_count == 1


class TestDecayCheck:
    def test_removes_low_importance(self, env):
        store, engine, config = env
        old_item = MemoryItem(content="forgotten memory", importance=0.1)
        old_item.updated_at = time.time() - 90 * 24 * 3600
        store.save(old_item)

        removed = engine.decay_check()
        assert old_item.id in removed
        assert store.get(old_item.id) is None

    def test_keeps_important(self, env):
        store, engine, _ = env
        item = MemoryItem(content="important memory", importance=1.0)
        store.save(item)

        removed = engine.decay_check()
        assert len(removed) == 0
        assert store.get(item.id) is not None
