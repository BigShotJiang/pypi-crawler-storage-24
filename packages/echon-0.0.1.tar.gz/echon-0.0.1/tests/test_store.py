import tempfile

import pytest

from echon.models import MemoryItem, MemoryType
from echon.store import MemoryStore
from helpers import FakeEmbedding


@pytest.fixture
def store():
    with tempfile.TemporaryDirectory() as tmpdir:
        emb = FakeEmbedding()
        s = MemoryStore("test_db", tmpdir, emb)
        yield s
        s.close()


def _make_item(content="test", **kwargs):
    return MemoryItem(content=content, **kwargs)


class TestCRUD:
    def test_save_and_get(self, store):
        item = _make_item("hello world")
        store.save(item)
        got = store.get(item.id)
        assert got is not None
        assert got.content == "hello world"
        assert got.id == item.id

    def test_get_missing(self, store):
        assert store.get("nonexistent") is None

    def test_delete(self, store):
        item = _make_item("to delete")
        store.save(item)
        assert store.get(item.id) is not None
        store.delete(item.id)
        assert store.get(item.id) is None

    def test_all_memories(self, store):
        items = [_make_item(f"item {i}") for i in range(3)]
        for item in items:
            store.save(item)
        all_items = store.all_memories()
        assert len(all_items) == 3

    def test_count(self, store):
        assert store.count() == 0
        store.save(_make_item("a"))
        assert store.count() == 1
        store.save(_make_item("b"))
        assert store.count() == 2


class TestVectorSearch:
    def test_search_similar(self, store):
        store.save(_make_item("Python 是一种编程语言"))
        store.save(_make_item("Java 也是一种编程语言"))
        store.save(_make_item("今天天气很好"))

        results = store.search_similar("编程语言有哪些", top_k=3)
        assert len(results) > 0
        # 返回 (id, score) 格式
        assert isinstance(results[0], tuple)
        assert isinstance(results[0][1], float)

    def test_search_empty(self, store):
        results = store.search_similar("anything", top_k=5)
        assert results == []

    def test_search_returns_saved_items(self, store):
        item = _make_item("独特的测试内容12345")
        store.save(item)
        results = store.search_similar("独特的测试内容12345", top_k=1)
        assert len(results) == 1
        assert results[0][0] == item.id
