import tempfile
import time
from unittest.mock import patch, MagicMock

import pytest

from echon import Memory, MemoryType, MemoryItem, EchonConfig
from helpers import FakeEmbedding


@pytest.fixture
def mem():
    with tempfile.TemporaryDirectory() as tmpdir:
        fake_emb = FakeEmbedding()
        with patch("echon.memory.TextEmbedding", return_value=fake_emb):
            m = Memory("test-agent", db_path=tmpdir)
            yield m
            m.close()


class TestMemoryBasic:
    def test_add_and_len(self, mem):
        assert len(mem) == 0
        mid = mem.add("用户喜欢Python", memory_type="preference")
        assert len(mem) == 1
        assert isinstance(mid, str)

    def test_getitem(self, mem):
        mid = mem.add("事实记忆", importance=0.9)
        item = mem[mid]
        assert item is not None
        assert item.content == "事实记忆"
        assert item.importance == 0.9

    def test_recall(self, mem):
        mem.add("用户喜欢简洁代码", memory_type="preference", importance=0.8)
        mem.add("用户是高级工程师", memory_type="fact", importance=0.7)

        results = mem.recall("代码风格")
        assert len(results) > 0
        assert "content" in results[0]
        assert "score" in results[0]

    def test_context_manager(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            fake_emb = FakeEmbedding()
            with patch("echon.memory.TextEmbedding", return_value=fake_emb):
                with Memory("ctx-test", db_path=tmpdir) as m:
                    m.add("test")
                    assert len(m) == 1


class TestDeduplication:
    def test_duplicate_not_stored_twice(self, mem):
        mem.add("用户喜欢Python")
        mem.add("用户喜欢Python")
        assert len(mem) == 1

    def test_different_content_stored(self, mem):
        mem.add("记忆A关于编程")
        mem.add("记忆B关于音乐")
        assert len(mem) == 2


class TestExtract:
    def test_extract_from_text(self, mem):
        ids = mem.extract("我喜欢使用简洁的代码风格来编写程序")
        assert len(ids) > 0
        assert len(mem) > 0


class TestMemoryItemPostInit:
    def test_str_to_memorytype(self):
        item = MemoryItem(content="test", memory_type="fact")
        assert item.memory_type is MemoryType.FACT

    def test_memorytype_stays(self):
        item = MemoryItem(content="test", memory_type=MemoryType.EVENT)
        assert item.memory_type is MemoryType.EVENT

    def test_invalid_type_raises(self):
        with pytest.raises(ValueError):
            MemoryItem(content="test", memory_type="invalid")

    def test_roundtrip_dict(self):
        item = MemoryItem(content="hello", memory_type="preference", importance=0.8)
        d = item.to_dict()
        restored = MemoryItem.from_dict(d)
        assert restored.memory_type is MemoryType.PREFERENCE
        assert restored.content == "hello"


class TestIngest:
    def test_ingest_creates_default_parser(self, mem):
        """未设置 parser 时 ingest 自动创建。"""
        assert mem._parser is None
        with patch("echon.document.DocumentParser") as mock_cls:
            mock_instance = MagicMock()
            mock_instance.parse.return_value = []
            mock_cls.return_value = mock_instance

            mem.ingest("test.pdf")
            mock_cls.assert_called_once()
            assert mem._parser is mock_instance


class TestIngestReal:
    """端到端测试：真实文件 → ingest → recall 检索（使用 markitdown 后端）。"""

    def test_ingest_pdf_and_recall(self, mem, sample_pdf):
        from echon.document import DocumentParser
        mem._parser = DocumentParser(backend="markitdown")

        ids = mem.ingest(sample_pdf, importance=0.7)
        assert len(ids) > 0
        assert len(mem) > 0

        item = mem[ids[0]]
        assert item.source == "sample.pdf"
        assert item.importance == 0.7

        results = mem.recall("Redis")
        assert len(results) > 0

    def test_ingest_docx_and_recall(self, mem, sample_docx):
        from echon.document import DocumentParser
        mem._parser = DocumentParser(backend="markitdown")

        ids = mem.ingest(sample_docx)
        assert len(ids) > 0

        item = mem[ids[0]]
        assert item.source == "sample.docx"

        results = mem.recall("缓存优化")
        assert len(results) > 0


class TestInputValidation:
    def test_empty_content_raises(self, mem):
        with pytest.raises(ValueError, match="不能为空"):
            mem.add("")

    def test_whitespace_content_raises(self, mem):
        with pytest.raises(ValueError, match="不能为空"):
            mem.add("   ")

    def test_importance_too_high_raises(self, mem):
        with pytest.raises(ValueError, match="0-1"):
            mem.add("内容", importance=1.5)

    def test_importance_negative_raises(self, mem):
        with pytest.raises(ValueError, match="0-1"):
            mem.add("内容", importance=-0.1)

    def test_importance_boundary_ok(self, mem):
        mem.add("边界值0", importance=0.0)
        mem.add("边界值1", importance=1.0)
        assert len(mem) == 2


class TestCleanup:
    def test_cleanup(self, mem):
        mid = mem.add("旧记忆内容", importance=0.1)
        item = mem[mid]
        item.updated_at = time.time() - 200 * 24 * 3600
        mem._store.save(item)

        removed = mem.cleanup()
        assert mid in removed
