import shutil
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

from echon.document import DocumentParser
from conftest import SAMPLE_TEXT_ZH


# ─── 初始化 & 参数校验 ───────────────────────────────────────────

class TestDocumentParserInit:
    def test_default_backend(self):
        parser = DocumentParser()
        assert parser.backend == "mineru"
        assert parser.chunk_size == 512

    def test_custom_params(self):
        parser = DocumentParser(backend="markitdown", chunk_size=1024)
        assert parser.backend == "markitdown"
        assert parser.chunk_size == 1024

    def test_invalid_backend(self):
        with pytest.raises(ValueError, match="不支持的解析后端"):
            DocumentParser(backend="invalid")


class TestImportErrors:
    @pytest.fixture
    def txt_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("some text\n" * 10, encoding="utf-8")
        return str(f)

    def test_markitdown_not_installed(self, txt_file):
        parser = DocumentParser(backend="markitdown")
        with patch.dict("sys.modules", {"markitdown": None}):
            with pytest.raises(ImportError, match="markitdown 未安装"):
                parser.parse(txt_file)

    def test_chonkie_not_installed(self, txt_file):
        mock_result = MagicMock()
        mock_result.text_content = "一些文本"
        mock_md_cls = MagicMock()
        mock_md_instance = MagicMock()
        mock_md_instance.convert.return_value = mock_result
        mock_md_cls.return_value = mock_md_instance

        with patch.dict("sys.modules", {
            "markitdown": MagicMock(MarkItDown=mock_md_cls),
            "chonkie": None,
        }):
            parser = DocumentParser(backend="markitdown")
            with pytest.raises(ImportError, match="chonkie 未安装"):
                parser.parse(txt_file)


class TestFileNotFound:
    def test_parse_missing_file(self):
        parser = DocumentParser(backend="markitdown")
        with pytest.raises(FileNotFoundError, match="文件不存在"):
            parser.parse("/nonexistent/file.pdf")

    def test_extract_text_missing_file(self):
        parser = DocumentParser(backend="markitdown")
        with pytest.raises(FileNotFoundError, match="文件不存在"):
            parser.extract_text("/nonexistent/file.pdf")

    def test_parse_empty_result(self, tmp_path):
        """解析结果为空文本时返回空列表。"""
        f = tmp_path / "empty.txt"
        f.write_text("   ", encoding="utf-8")
        mock_result = MagicMock()
        mock_result.text_content = "   "
        mock_md_cls = MagicMock()
        mock_md_instance = MagicMock()
        mock_md_instance.convert.return_value = mock_result
        mock_md_cls.return_value = mock_md_instance

        with patch.dict("sys.modules", {
            "markitdown": MagicMock(MarkItDown=mock_md_cls),
        }):
            parser = DocumentParser(backend="markitdown")
            chunks = parser.parse(str(f))
            assert chunks == []


# ─── Markitdown 真实解析 ─────────────────────────────────────────

class TestMarkitdownReal:
    def test_parse_pdf(self, sample_pdf):
        parser = DocumentParser(backend="markitdown")
        chunks = parser.parse(sample_pdf)
        assert len(chunks) > 0
        full = " ".join(chunks)
        assert "Redis" in full or "cache" in full

    def test_parse_docx(self, sample_docx):
        parser = DocumentParser(backend="markitdown")
        chunks = parser.parse(sample_docx)
        assert len(chunks) > 0
        full = " ".join(chunks)
        assert "Redis" in full

    def test_parse_html(self, sample_html):
        parser = DocumentParser(backend="markitdown")
        chunks = parser.parse(sample_html)
        assert len(chunks) > 0
        full = " ".join(chunks)
        assert "Redis" in full

    def test_extract_text_pdf(self, sample_pdf):
        parser = DocumentParser(backend="markitdown")
        text = parser.extract_text(sample_pdf)
        assert isinstance(text, str)
        assert len(text) > 0
        assert "Redis" in text or "cache" in text

    def test_chunk_size_affects_output(self, sample_docx):
        """不同 chunk_size 应产生不同数量的片段（或至少不报错）。"""
        parser_big = DocumentParser(backend="markitdown", chunk_size=2048)
        parser_small = DocumentParser(backend="markitdown", chunk_size=64)
        chunks_big = parser_big.parse(sample_docx)
        chunks_small = parser_small.parse(sample_docx)
        assert len(chunks_small) >= len(chunks_big)


# ─── MinerU 真实解析 ─────────────────────────────────────────────

def _check_mineru():
    """检查 mineru 是否真正可用（CLI 存在且 torch 等运行时依赖齐全）。"""
    if not shutil.which("mineru"):
        return False
    try:
        import torch  # noqa: F401 — mineru 运行时必需
        return True
    except ImportError:
        return False


_mineru_available = _check_mineru()

_DATA_DIR = Path(__file__).parent.parent / "data"
_real_pdf = _DATA_DIR / "cn_ai_risk_governance_2024.pdf"


@pytest.mark.skipif(not _mineru_available, reason="mineru 不可用（未安装或缺少依赖如 torch）")
@pytest.mark.skipif(not _real_pdf.exists(), reason=f"测试 PDF 不存在: {_real_pdf}")
class TestMineruReal:
    def test_parse_pdf_mineru(self):
        parser = DocumentParser(backend="mineru")
        chunks = parser.parse(str(_real_pdf))
        assert len(chunks) > 0
        full = " ".join(chunks)
        assert "人工智能" in full or "风险" in full
