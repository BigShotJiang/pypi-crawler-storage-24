"""测试 fixtures — 动态生成样本文件。"""

import pytest
from fpdf import FPDF
from docx import Document


SAMPLE_TEXT_ZH = "Redis 缓存优化是提升系统性能的关键技术手段"


@pytest.fixture
def sample_pdf(tmp_path):
    """生成含中文文本的 PDF 文件。"""
    pdf = FPDF()
    pdf.add_page()
    # 使用内置字体写 ASCII 可检测文本 + 中文部分用 unicode 字体
    font_path = _find_cjk_font()
    if font_path:
        pdf.add_font("CJK", "", font_path)
        pdf.set_font("CJK", size=12)
        pdf.multi_cell(0, 10, text=SAMPLE_TEXT_ZH)
    else:
        # fallback: 写纯 ASCII 特征文本
        pdf.set_font("Helvetica", size=12)
        pdf.multi_cell(0, 10, text="Redis cache optimization is a key technique")
    out = tmp_path / "sample.pdf"
    pdf.output(str(out))
    return str(out)


@pytest.fixture
def sample_docx(tmp_path):
    """生成含中文文本的 DOCX 文件。"""
    doc = Document()
    doc.add_heading("测试文档", level=1)
    doc.add_paragraph(SAMPLE_TEXT_ZH)
    doc.add_paragraph("本文档用于验证 echon 文档解析功能的正确性。")
    out = tmp_path / "sample.docx"
    doc.save(str(out))
    return str(out)


@pytest.fixture
def sample_html(tmp_path):
    """生成 HTML 文件。"""
    html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>测试</title></head>
<body>
<h1>技术文档</h1>
<p>{SAMPLE_TEXT_ZH}</p>
<p>本文档用于验证解析功能。</p>
</body></html>"""
    out = tmp_path / "sample.html"
    out.write_text(html, encoding="utf-8")
    return str(out)


def _find_cjk_font():
    """查找系统中可用的 CJK 字体。"""
    from pathlib import Path
    candidates = [
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf",
    ]
    for c in candidates:
        if Path(c).exists():
            return c
    return None
