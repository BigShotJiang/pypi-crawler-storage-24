"""记忆演化：展示衰减和清理机制

用法：
    uv run python examples/evolution_demo.py [--embedding-url URL] [--embedding-model MODEL]
"""

import shutil
import tempfile
import time

from _common import parse_args, check_service

args = parse_args()
check_service(args)

tmpdir = tempfile.mkdtemp(prefix="echon_evo_")
try:
    from echon import Memory, EchonConfig

    # 自定义配置：加快衰减以便演示
    config = EchonConfig(
        decay_lambda=0.01,       # 衰减更快（正常为 0.001）
        forget_threshold=0.3,    # 提高遗忘阈值以便观察
        cleanup_interval=5,      # 每 5 次 recall 自动检查
    )

    with Memory("evo-demo", db_path=tmpdir, config=config,
                embedding_url=args.embedding_url,
                embedding_model=args.embedding_model) as mem:
        # 添加不同重要性的记忆
        id_low = mem.add("临时讨论了天气", importance=0.2)
        id_mid = mem.add("用户偏好暗色主题", memory_type="preference", importance=0.6)
        id_high = mem.add("用户是公司 CTO", memory_type="fact", importance=1.0)
        print(f"初始记忆数: {len(mem)}")

        # 模拟时间推移：手动修改 updated_at
        low_item = mem[id_low]
        low_item.updated_at = time.time() - 30 * 24 * 3600  # 30 天前
        mem._store.save(low_item)

        mid_item = mem[id_mid]
        mid_item.updated_at = time.time() - 15 * 24 * 3600  # 15 天前
        mem._store.save(mid_item)

        # 手动清理
        removed = mem.cleanup()
        print(f"清理后记忆数: {len(mem)}, 清除了 {len(removed)} 条")

        # 查看剩余记忆
        print("\n剩余记忆:")
        for r in mem.recall("所有信息", top_k=10):
            print(f"  {r['content']}  (importance={r['importance']}, eff={r['effective_importance']})")
finally:
    shutil.rmtree(tmpdir, ignore_errors=True)
