"""RAG 实战示例：文档检索增强生成

流程：ingest → recall → prompt → generate

用法：
    # 交互模式
    uv run python examples/rag_demo.py

    # 自动评估模式
    uv run python examples/rag_demo.py --eval

    # 自定义参数
    uv run python examples/rag_demo.py --llm-model qwen3-vl-8b --top-k 5
"""

import argparse
import os
import shutil
import sys
import tempfile

from _common import EMBEDDING_URL, EMBEDDING_MODEL, check_service


EVAL_QUESTIONS = [
    "中国AI治理框架的核心原则是什么？",
    "AI安全治理框架提出了哪些具体措施？",
    "红队测试的数据生成方法有哪些？",
    "What information should GPAI model documentation include?",
    "What is Tree-GRPO and how does it improve reasoning?",
]

SYSTEM_PROMPT = (
    "你是知识库问答助手。根据提供的参考资料回答问题。"
    "如果资料中没有相关信息，请如实说明。"
)


def parse_args():
    parser = argparse.ArgumentParser(description="RAG 实战示例")
    parser.add_argument("--embedding-url", default=EMBEDDING_URL)
    parser.add_argument("--embedding-model", default=EMBEDDING_MODEL)
    parser.add_argument("--llm-model", default="qwen3-vl-8b")
    parser.add_argument("--data-dir", default="./data")
    parser.add_argument("--eval", action="store_true", help="自动运行预设问题")
    parser.add_argument("--top-k", type=int, default=5, help="检索数量")
    return parser.parse_args()


def build_context(results: list[dict]) -> str:
    """将检索结果拼接为参考资料文本。"""
    parts = []
    for i, r in enumerate(results, 1):
        source = r.get("source") or "未知"
        parts.append(f"[{i}] (来源: {source}) {r['content']}")
    return "\n\n".join(parts)


def ask_llm(llm, context: str, question: str) -> str:
    """拼接 prompt 并调用 LLM。"""
    user_msg = f"参考资料：\n{context}\n\n问题：{question}"
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_msg},
    ]
    return llm.chat_completions_sync(messages)


def ingest_documents(mem, data_dir: str):
    """将 data_dir 下所有文档摄入记忆库。"""
    files = sorted(
        f for f in os.listdir(data_dir)
        if os.path.isfile(os.path.join(data_dir, f))
        and not f.startswith(".")
    )
    if not files:
        print(f"错误: {data_dir} 下没有文档")
        sys.exit(1)

    print(f"发现 {len(files)} 篇文档，开始摄入...")
    for fname in files:
        fpath = os.path.join(data_dir, fname)
        ids = mem.ingest(fpath, importance=0.7)
        print(f"  {fname}: {len(ids)} 条片段")
    print(f"摄入完成，记忆库共 {len(mem)} 条记录\n")


def run_query(mem, llm, question: str, top_k: int):
    """执行单次 RAG 查询：检索 + 生成。"""
    results = mem.recall(question, top_k=top_k)
    if not results:
        print("未检索到相关内容。\n")
        return

    context = build_context(results)
    answer = ask_llm(llm, context, question)

    print(f"\n回答：\n{answer}\n")
    print("引用来源：")
    sources = {r.get("source") or "未知" for r in results}
    for s in sorted(sources):
        print(f"  - {s}")
    print()


def main():
    import warnings
    warnings.filterwarnings("ignore", message=".*AsyncLimiter.*re-used across loops.*")

    args = parse_args()
    check_service(args)

    from flexllm import LLMClient
    from echon import Memory, DocumentParser

    llm = LLMClient.from_config(model=args.llm_model)
    parser = DocumentParser(backend="markitdown")

    tmpdir = tempfile.mkdtemp(prefix="echon_rag_")
    try:
        with Memory(
            "rag-agent",
            db_path=tmpdir,
            embedding_url=args.embedding_url,
            embedding_model=args.embedding_model,
            parser=parser,
        ) as mem:
            ingest_documents(mem, args.data_dir)

            if args.eval:
                # 自动评估模式
                for i, q in enumerate(EVAL_QUESTIONS, 1):
                    print(f"{'='*60}")
                    print(f"问题 {i}: {q}")
                    run_query(mem, llm, q, args.top_k)
            else:
                # 交互模式
                print("输入问题开始问答（输入 q 退出）：")
                while True:
                    try:
                        question = input("\n问题：").strip()
                    except (EOFError, KeyboardInterrupt):
                        break
                    if not question or question.lower() == "q":
                        break
                    run_query(mem, llm, question, args.top_k)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)

    print("已退出。")


if __name__ == "__main__":
    main()
