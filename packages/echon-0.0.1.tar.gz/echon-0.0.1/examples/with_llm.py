"""结合 LLM：使用 flexllm 实现智能合并和提取

前置条件：
    pip install echon[llm]
    配置 flexllm: ~/.flexllm/config.yaml

用法：
    uv run python examples/with_llm.py [--embedding-url URL] [--embedding-model MODEL] [--llm-model MODEL]
"""

import argparse
import shutil
import sys
import tempfile

from _common import EMBEDDING_URL, EMBEDDING_MODEL, check_service

parser = argparse.ArgumentParser()
parser.add_argument("--embedding-url", default=EMBEDDING_URL)
parser.add_argument("--embedding-model", default=EMBEDDING_MODEL)
parser.add_argument("--llm-model", default="qwen3_coder_next", help="flexllm 中配置的模型名称")
args = parser.parse_args()

check_service(args)

try:
    from flexllm import LLMClient
except ImportError:
    print("错误: flexllm 未安装，请执行 pip install echon[llm]")
    sys.exit(1)

tmpdir = tempfile.mkdtemp(prefix="echon_llm_")
try:
    from echon import Memory

    llm = LLMClient.from_config(model=args.llm_model)

    with Memory("llm-demo", db_path=tmpdir, llm=llm,
                embedding_url=args.embedding_url,
                embedding_model=args.embedding_model) as mem:
        # 1. LLM 辅助提取：对话中不明显的信息也能被 LLM 提取
        conversation = """
        用户: 我们团队有 5 个人，上周刚从 MySQL 迁到了 PostgreSQL。
        每周三下午有技术分享会，这周讨论的是缓存策略。
        """
        ids = mem.extract(conversation, source="团队周会")
        print(f"LLM 提取了 {len(ids)} 条记忆:")
        for mid in ids:
            item = mem[mid]
            print(f"  [{item.memory_type.value}] {item.content}")

        # 2. 智能合并：相似但不完全相同的记忆会被 LLM 合并
        mem.add("用户的团队使用 PostgreSQL 数据库", memory_type="fact", importance=0.7)
        mem.add("用户团队之前用 MySQL，最近迁移到了 PostgreSQL", memory_type="fact", importance=0.8)
        # LLM 会将两条合并为一条更完整的记忆

        print(f"\n当前记忆数: {len(mem)}")
        print("\n--- 检索: 团队技术栈 ---")
        for r in mem.recall("团队用什么数据库"):
            print(f"  {r['content']}  (score={r['score']})")
finally:
    shutil.rmtree(tmpdir, ignore_errors=True)
