"""示例公共配置：embedding 服务参数和可用性检查。"""

import argparse
import sys

EMBEDDING_URL = "http://localhost:8023/v1"
EMBEDDING_MODEL = "KaLM-embedding-multilingual-mini-instruct-v2.5"


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--embedding-url", default=EMBEDDING_URL)
    parser.add_argument("--embedding-model", default=EMBEDDING_MODEL)
    return parser.parse_args()


def check_service(args):
    """检查 embedding 服务是否可用，不可用则退出。"""
    import requests

    try:
        resp = requests.get(f"{args.embedding_url}/models", timeout=3)
        if resp.status_code == 200:
            return
    except Exception:
        pass
    print(f"错误: embedding 服务未启动 ({args.embedding_url})")
    sys.exit(1)
