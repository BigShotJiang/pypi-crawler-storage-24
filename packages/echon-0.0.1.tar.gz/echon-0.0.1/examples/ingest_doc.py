"""文档摄入示例：将文档解析为记忆片段并存入记忆库

前置条件：
    pip install echon[doc]

用法：
    uv run python examples/ingest_doc.py [--embedding-url URL] [--embedding-model MODEL]
"""

import os
import shutil
import sys
import tempfile

from _common import parse_args, check_service

args = parse_args()
check_service(args)

try:
    from echon import Memory, DocumentParser
except ImportError:
    print("错误: 需要安装 doc 依赖: pip install echon[doc]")
    sys.exit(1)

tmpdir = tempfile.mkdtemp(prefix="echon_ingest_")
try:
    # 创建一个测试 HTML 文件（模拟真实文档）
    html_path = os.path.join(tmpdir, "perf_report.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write("""<html><body>
        <h1>系统性能优化报告</h1>
        <h2>1. 缓存优化</h2>
        <p>通过引入 Redis 分布式缓存，热点数据的查询延迟从 200ms 降低到 5ms。
        缓存命中率稳定在 95% 以上，显著减少了数据库压力。</p>
        <h2>2. 数据库优化</h2>
        <p>对核心查询添加了复合索引，慢查询数量减少了 80%。
        同时将大表进行了分区处理，提升了数据归档效率。</p>
        <h2>3. 异步处理</h2>
        <p>将耗时的邮件发送和报表生成改为异步任务队列处理，
        API 响应时间从平均 2s 降低到 200ms，用户体验大幅提升。</p>
        </body></html>""")

    # 1. 直接使用 DocumentParser 解析
    parser = DocumentParser(chunk_size=256)
    chunks = parser.parse(html_path)
    print(f"解析为 {len(chunks)} 个片段")
    for i, chunk in enumerate(chunks[:3]):
        print(f"  [{i}] {chunk[:80]}...")

    # 2. 通过 Memory.ingest() 一步完成解析+存储
    db_path = os.path.join(tmpdir, "db")
    with Memory("doc-agent", db_path=db_path,
                embedding_url=args.embedding_url,
                embedding_model=args.embedding_model) as mem:
        ids = mem.ingest(html_path, importance=0.7, chunk_size=256)
        print(f"\n摄入 {len(ids)} 条记忆")

        # 3. 检索验证
        print("\n--- 检索: 缓存相关优化 ---")
        results = mem.recall("缓存优化效果")
        for r in results:
            print(f"  [{r['score']:.3f}] {r['content'][:80]}...")

        print("\n--- 检索: 数据库性能 ---")
        results = mem.recall("数据库性能改进")
        for r in results:
            print(f"  [{r['score']:.3f}] {r['content'][:80]}...")
finally:
    shutil.rmtree(tmpdir, ignore_errors=True)
