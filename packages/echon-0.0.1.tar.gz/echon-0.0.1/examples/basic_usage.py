"""基本用法：添加、检索、去重

用法：
    uv run python examples/basic_usage.py [--embedding-url URL] [--embedding-model MODEL]
"""

import shutil
import tempfile

from _common import parse_args, check_service

args = parse_args()
check_service(args)

tmpdir = tempfile.mkdtemp(prefix="echon_basic_")
try:
    from echon import Memory

    with Memory("demo-agent", db_path=tmpdir,
                embedding_url=args.embedding_url,
                embedding_model=args.embedding_model) as mem:
        # 1. 添加记忆
        mem.add("用户是一名后端工程师，主要使用 Python", memory_type="fact", importance=0.9)
        mem.add("用户喜欢简洁的代码风格", memory_type="preference", importance=0.8)
        mem.add("用户不喜欢过度设计", memory_type="preference", importance=0.7)
        mem.add("今天讨论了微服务拆分方案", memory_type="event", importance=0.6)
        print(f"当前记忆数: {len(mem)}")

        # 2. 检索相关记忆
        results = mem.recall("代码怎么写比较好", top_k=3)
        print("\n--- 检索: 代码怎么写比较好 ---")
        for r in results:
            print(f"  [{r['memory_type']}] {r['content']}  (score={r['score']})")

        # 3. 去重验证：添加语义相同的记忆不会重复存储
        before = len(mem)
        mem.add("用户是一名后端工程师，主要使用 Python")  # 重复内容
        after = len(mem)
        print(f"\n去重验证: 添加重复记忆前={before}, 后={after}")

        # 4. 通过 id 访问
        mid = mem.add("项目使用 FastAPI 框架", memory_type="fact")
        item = mem[mid]
        print(f"\n直接访问: {item.content} (type={item.memory_type.value})")
finally:
    shutil.rmtree(tmpdir, ignore_errors=True)
