"""端到端验证：一键验证 echon 全部核心能力。

用法：
    uv run python examples/verify.py [--embedding-url URL] [--embedding-model MODEL]

默认使用 http://localhost:8023/v1 的 vllm embedding 服务。
"""

import shutil
import tempfile
import time
import os
import sys
import requests


EMBEDDING_URL = "http://localhost:8023/v1"
EMBEDDING_MODEL = "KaLM-embedding-multilingual-mini-instruct-v2.5"


def check_embedding_service(url=EMBEDDING_URL):
    """检查 embedding 服务是否可用。"""
    try:
        resp = requests.get(f"{url}/models", timeout=3)
        return resp.status_code == 200
    except Exception:
        return False


def verify_add_and_recall(mem):
    """验证：添加记忆 + 语义检索"""
    mem.add("用户是一名后端工程师，主要使用 Python", memory_type="fact", importance=0.9)
    mem.add("用户喜欢简洁的代码风格", memory_type="preference", importance=0.8)
    mem.add("用户不喜欢过度设计", memory_type="preference", importance=0.7)
    mem.add("今天讨论了微服务拆分方案", memory_type="event", importance=0.6)
    assert len(mem) == 4, f"期望 4 条记忆，实际 {len(mem)}"

    results = mem.recall("代码怎么写比较好", top_k=3)
    assert len(results) > 0, "检索应返回结果"
    # 最相关的应该是关于代码风格的记忆
    contents = [r["content"] for r in results]
    assert any("代码" in c or "设计" in c for c in contents), f"检索结果不相关: {contents}"
    print(f"  添加 4 条记忆，检索 top3:")
    for r in results:
        print(f"    [{r['memory_type']}] {r['content']}  (score={r['score']})")


def verify_dedup(mem):
    """验证：语义去重"""
    before = len(mem)
    mem.add("用户是一名后端工程师，主要使用 Python")  # 完全相同内容
    after = len(mem)
    assert before == after, f"去重失败: 前={before}, 后={after}"
    print(f"  重复添加后记忆数不变: {before} → {after}")


def verify_extract(mem):
    """验证：从对话自动提取记忆"""
    conversation = "我是一名数据科学家，最近在做推荐系统。我喜欢用 PyTorch 做模型训练。"
    before = len(mem)
    ids = mem.extract(conversation, source="对话")
    assert len(ids) > 0, "应提取出至少一条记忆"
    after = len(mem)
    assert after > before, f"提取后记忆数应增加: 前={before}, 后={after}"
    print(f"  从对话提取了 {len(ids)} 条记忆:")
    for mid in ids:
        item = mem[mid]
        print(f"    [{item.memory_type.value}] {item.content}")


def verify_decay(mem):
    """验证：记忆衰减清理"""
    from echon import EchonConfig
    # 添加一条低重要性记忆并模拟时间推移
    mid = mem.add("临时聊了天气", importance=0.1)
    item = mem[mid]
    item.updated_at = time.time() - 200 * 24 * 3600  # 200 天前
    mem._store.save(item)

    removed = mem.cleanup()
    assert mid in removed, f"低重要性旧记忆应被清除: {mid}"
    assert mem[mid] is None, "清除后应无法获取"
    print(f"  低重要性旧记忆被清除: {mid}")


def verify_ingest(mem, tmpdir):
    """验证：文档解析 + 摄入"""
    from echon import DocumentParser

    # 创建测试 HTML 文件
    html_path = os.path.join(tmpdir, "test_report.html")
    paragraphs = "".join(
        f"<p>第{i}章：讨论了系统在高并发场景下的性能优化策略，包括缓存、限流和异步处理。</p>"
        for i in range(20)
    )
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(f"<html><body><h1>性能优化报告</h1>{paragraphs}</body></html>")

    # DocumentParser 单独解析
    parser = DocumentParser(chunk_size=256)
    chunks = parser.parse(html_path)
    assert len(chunks) > 0, "解析应返回片段"
    print(f"  DocumentParser: {html_path} → {len(chunks)} 个片段")

    # Memory.ingest 解析+存储
    before = len(mem)
    ids = mem.ingest(html_path, importance=0.7, chunk_size=256)
    assert len(ids) > 0, "摄入应返回 id"
    assert len(mem) > before, f"摄入后记忆数应增加"
    print(f"  Memory.ingest: 摄入 {len(ids)} 条记忆")

    # 检索验证
    results = mem.recall("性能优化", top_k=2)
    assert len(results) > 0, "应能检索到文档内容"
    assert any("性能" in r["content"] or "优化" in r["content"] for r in results)
    print(f"  检索文档内容:")
    for r in results:
        print(f"    (score={r['score']:.3f}) {r['content'][:60]}...")


def main():
    # 支持命令行参数覆盖
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--embedding-url", default=EMBEDDING_URL)
    parser.add_argument("--embedding-model", default=EMBEDDING_MODEL)
    args = parser.parse_args()

    if not check_embedding_service(args.embedding_url):
        print(f"错误: embedding 服务未启动 ({args.embedding_url})")
        sys.exit(1)
    print(f"Embedding: {args.embedding_url} model={args.embedding_model}")

    from echon import Memory

    tmpdir = tempfile.mkdtemp(prefix="echon_verify_")
    db_path = os.path.join(tmpdir, "db")

    try:
        with Memory("verify", db_path=db_path,
                     embedding_url=args.embedding_url,
                     embedding_model=args.embedding_model) as mem:
            tests = [
                ("添加 + 检索", lambda: verify_add_and_recall(mem)),
                ("语义去重", lambda: verify_dedup(mem)),
                ("对话提取", lambda: verify_extract(mem)),
                ("记忆衰减", lambda: verify_decay(mem)),
                ("文档摄入", lambda: verify_ingest(mem, tmpdir)),
            ]

            passed = 0
            for name, fn in tests:
                print(f"\n[{name}]")
                try:
                    fn()
                    print(f"  ✓ 通过")
                    passed += 1
                except Exception as e:
                    print(f"  ✗ 失败: {e}")

            print(f"\n{'='*40}")
            print(f"结果: {passed}/{len(tests)} 通过")
            if passed == len(tests):
                print("echon 全部核心能力验证通过!")
            else:
                sys.exit(1)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    main()
