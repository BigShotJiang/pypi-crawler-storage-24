"""自动提取：从对话文本中自动提取并存储记忆

用法：
    uv run python examples/auto_extract.py [--embedding-url URL] [--embedding-model MODEL]
"""

import shutil
import tempfile

from _common import parse_args, check_service

args = parse_args()
check_service(args)

tmpdir = tempfile.mkdtemp(prefix="echon_extract_")
try:
    from echon import Memory

    with Memory("extract-demo", db_path=tmpdir,
                embedding_url=args.embedding_url,
                embedding_model=args.embedding_model) as mem:
        # 模拟一段对话
        conversation = """
        用户: 我是一名数据科学家，最近在做推荐系统相关的项目。
        我喜欢用 PyTorch 做模型训练，不喜欢 TensorFlow 的 API 设计。
        昨天完成了特征工程的部分，效果还不错。
        """

        # 自动提取记忆
        ids = mem.extract(conversation, source="对话记录")
        print(f"从对话中提取了 {len(ids)} 条记忆:\n")

        for mid in ids:
            item = mem[mid]
            print(f"  [{item.memory_type.value}] {item.content}")

        # 提取后可以检索
        print("\n--- 检索: 用户的技术栈 ---")
        for r in mem.recall("用户擅长什么技术"):
            print(f"  {r['content']}  (score={r['score']})")
finally:
    shutil.rmtree(tmpdir, ignore_errors=True)
