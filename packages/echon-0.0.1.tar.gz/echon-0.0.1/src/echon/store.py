import logging

from flaxkv2 import FlaxKV
from maque.embedding.base import BaseEmbedding
from maque.retriever import LanceRetriever, Document

from .models import MemoryItem

logger = logging.getLogger(__name__)


class MemoryStore:
    """flaxkv2 存元数据 + LanceRetriever 存向量"""

    def __init__(self, db_name: str, db_path: str, embedding: BaseEmbedding):
        self._db = FlaxKV(db_name, db_path)
        self._retriever = LanceRetriever(
            embedding, persist_dir=db_path, table_name=db_name
        )

    def save(self, item: MemoryItem):
        """保存到 flaxkv2 + Lance（含向量更新）"""
        self._db[f"mem:{item.id}"] = item.to_dict()
        doc = Document(
            id=item.id,
            content=item.content,
            metadata={"memory_type": item.memory_type.value},
        )
        self._retriever.upsert(doc)

    def save_batch(self, items: list[MemoryItem]):
        """批量保存到 flaxkv2 + Lance（批量 embedding）"""
        docs = []
        for item in items:
            self._db[f"mem:{item.id}"] = item.to_dict()
            docs.append(Document(
                id=item.id,
                content=item.content,
                metadata={"memory_type": item.memory_type.value},
            ))
        if docs:
            self._retriever.upsert_batch(docs, show_progress=False)

    def save_metadata(self, item: MemoryItem):
        """仅更新元数据到 flaxkv2，不写向量库。

        用于访问计数等不涉及内容变更的更新。
        """
        self._db[f"mem:{item.id}"] = item.to_dict()

    def get(self, memory_id: str) -> MemoryItem | None:
        data = self._db.get(f"mem:{memory_id}")
        if data is None:
            return None
        return MemoryItem.from_dict(data)

    def delete(self, memory_id: str):
        key = f"mem:{memory_id}"
        if key in self._db:
            del self._db[key]
        try:
            self._retriever.delete(memory_id)
        except Exception:
            logger.warning(f"从向量索引删除 {memory_id} 失败", exc_info=True)

    def all_memories(self) -> list[MemoryItem]:
        items = []
        for key, value in self._db.items():
            if isinstance(key, str) and key.startswith("mem:"):
                items.append(MemoryItem.from_dict(value))
        return items

    def search_similar(
        self, query: str, top_k: int = 10
    ) -> list[tuple[str, float]]:
        """文本检索，返回 [(memory_id, similarity), ...]"""
        results = self._retriever.search(query, top_k=top_k)
        return [(r.id, r.score) for r in results]

    def search_by_vector(
        self, vector: list[float], top_k: int = 10
    ) -> list[tuple[str, float]]:
        """向量检索，返回 [(memory_id, similarity), ...]"""
        results = self._retriever.search_by_vector(vector, top_k=top_k)
        return [(r.id, r.score) for r in results]

    def count(self) -> int:
        return sum(
            1
            for key in self._db.keys()
            if isinstance(key, str) and key.startswith("mem:")
        )

    def close(self):
        self._db.close()
