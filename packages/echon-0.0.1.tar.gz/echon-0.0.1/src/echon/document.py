"""文档解析与切分模块。

支持 PDF/Word/PPT/Excel/HTML 等格式解析为文本，并切分为记忆片段。
需要安装可选依赖：pip install echon[doc]
"""

import json
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

# 段落合并的最小长度，短于此值的相邻段落会被合并
_MIN_BLOCK_LEN = 64


class DocumentParser:
    """文档解析器：解析文档为 Markdown 文本，再切分为片段。

    Args:
        backend: 解析后端，"mineru"（默认，高精度）或 "markitdown"（轻量）
        chunk_size: 切分片段大小（字符数）
    """

    def __init__(
        self,
        backend: str = "mineru",
        chunk_size: int = 512,
    ):
        if backend not in ("markitdown", "mineru"):
            raise ValueError(f"不支持的解析后端: {backend}")
        self.backend = backend
        self.chunk_size = chunk_size

    def parse(
        self,
        file_path: str,
        chunk_size: int | None = None,
    ) -> list[str]:
        """解析文档并切分，返回文本片段列表。"""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")

        if self.backend == "mineru":
            return self._parse_mineru(str(path), chunk_size or self.chunk_size)

        text = self._extract_text(str(path))
        if not text.strip():
            return []
        return self._chunk(text, chunk_size or self.chunk_size)

    def extract_text(self, file_path: str) -> str:
        """仅解析文档为文本，不切分。"""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"文件不存在: {file_path}")
        return self._extract_text(str(path))

    def _extract_text(self, file_path: str) -> str:
        if self.backend == "markitdown":
            return self._extract_markitdown(file_path)
        elif self.backend == "mineru":
            return self._extract_mineru_text(file_path)
        raise ValueError(f"不支持的解析后端: {self.backend}")

    def _extract_markitdown(self, file_path: str) -> str:
        try:
            from markitdown import MarkItDown
        except ImportError:
            raise ImportError(
                "markitdown 未安装。请运行: pip install echon[doc]"
            )
        md = MarkItDown()
        result = md.convert(file_path)
        return result.text_content

    # ── MinerU ──────────────────────────────────────────────

    def _run_mineru(self, file_path: str) -> Path:
        """运行 MinerU CLI，返回输出目录。"""
        import subprocess
        import tempfile

        try:
            subprocess.run(
                ["mineru", "--version"],
                capture_output=True,
                check=True,
            )
        except FileNotFoundError:
            raise ImportError(
                "mineru 未安装。请参考 MinerU 文档安装: pip install echon[doc-heavy]"
            )

        tmpdir = tempfile.mkdtemp()
        cmd = ["mineru", "-p", file_path, "-o", tmpdir, "-b", "pipeline"]
        logger.info(f"运行 MinerU: {' '.join(cmd)}")
        subprocess.run(cmd, capture_output=True, check=True)
        return Path(tmpdir)

    def _parse_mineru(self, file_path: str, chunk_size: int) -> list[str]:
        """利用 MinerU 的结构化输出（content_list.json）直接提取段落。"""
        out_dir = self._run_mineru(file_path)

        # 查找 content_list.json
        cl_files = list(out_dir.rglob("*_content_list.json"))
        if not cl_files:
            # fallback: 读 md 文件再切分
            md_files = list(out_dir.rglob("*.md"))
            if not md_files:
                raise RuntimeError(f"MinerU 未生成输出文件，目录: {out_dir}")
            text = md_files[0].read_text(encoding="utf-8")
            return self._chunk(text, chunk_size) if text.strip() else []

        blocks = json.loads(cl_files[0].read_text(encoding="utf-8"))
        # 提取 text 类型块，过滤空内容
        paragraphs = [
            b["text"].strip()
            for b in blocks
            if b.get("type") == "text" and b.get("text", "").strip()
        ]

        # 合并相邻短段落，使每个片段不低于 _MIN_BLOCK_LEN 且不超过 chunk_size
        return self._merge_short_blocks(paragraphs, chunk_size)

    def _extract_mineru_text(self, file_path: str) -> str:
        """MinerU 提取纯文本（用于 extract_text 接口）。"""
        out_dir = self._run_mineru(file_path)
        md_files = list(out_dir.rglob("*.md"))
        if not md_files:
            raise RuntimeError(f"MinerU 未生成输出文件，目录: {out_dir}")
        return md_files[0].read_text(encoding="utf-8")

    @staticmethod
    def _merge_short_blocks(paragraphs: list[str], chunk_size: int) -> list[str]:
        """将相邻短段落合并，每个片段 >= _MIN_BLOCK_LEN 且 <= chunk_size。"""
        merged = []
        buf = ""
        for p in paragraphs:
            if buf and len(buf) + len(p) + 1 > chunk_size:
                merged.append(buf)
                buf = p
            else:
                buf = f"{buf}\n{p}" if buf else p
        if buf.strip():
            merged.append(buf)

        # 过滤掉过短的片段（纯标题/页码噪音）
        return [m for m in merged if len(m) >= _MIN_BLOCK_LEN]

    # ── 通用切分 ────────────────────────────────────────────

    def _chunk(self, text: str, chunk_size: int) -> list[str]:
        try:
            from chonkie import RecursiveChunker
        except ImportError:
            raise ImportError(
                "chonkie 未安装。请运行: pip install echon[doc]"
            )
        chunker = RecursiveChunker(chunk_size=chunk_size)
        chunks = chunker(text)
        return [c.text for c in chunks if c.text.strip()]
