import re
import logging

from .models import MemoryType

logger = logging.getLogger(__name__)

# 规则提取模式
_PATTERNS = {
    MemoryType.PREFERENCE: [
        re.compile(r"(?:我|用户)(?:喜欢|偏好|倾向|希望|想要|不喜欢|讨厌|不想)(.+)"),
        re.compile(r"(?:prefer|like|dislike|want|hate)\s+(.+)", re.IGNORECASE),
    ],
    MemoryType.FACT: [
        re.compile(r"(?:我是|用户是|我的|用户的)(.+)"),
        re.compile(r"(?:我在|用户在|我用|用户用)(.+)"),
        re.compile(r"(?:I am|I'm|my)\s+(.+)", re.IGNORECASE),
    ],
    MemoryType.EVENT: [
        re.compile(r"(?:今天|昨天|刚才|最近)(.+)"),
        re.compile(r"(?:发生了|完成了|做了)(.+)"),
    ],
}

_LLM_EXTRACT_PROMPT = """从以下对话文本中提取值得记忆的关键信息。
每条记忆一行，格式为：类型|内容|重要性(0-1)
类型只能是：fact, event, preference

对话文本：
{text}

提取的记忆（如果没有值得记忆的内容，回复"无"）："""


class MemoryExtractor:
    """记忆提取：规则 + LLM"""

    def __init__(self, llm=None):
        self._llm = llm

    def extract(self, text: str) -> list[dict]:
        """
        从文本中提取记忆。
        返回 [{"content": str, "memory_type": MemoryType, "importance": float}, ...]
        """
        results = self._rule_extract(text)
        if not results and self._llm is not None:
            results = self._llm_extract(text)
        return results

    def _rule_extract(self, text: str) -> list[dict]:
        results = []
        for memory_type, patterns in _PATTERNS.items():
            for pattern in patterns:
                for match in pattern.finditer(text):
                    content = match.group(0).strip()
                    if len(content) > 5:  # 过短的无意义
                        results.append(
                            {
                                "content": content,
                                "memory_type": memory_type,
                                "importance": 0.5,
                            }
                        )
        return results

    def _llm_extract(self, text: str) -> list[dict]:
        try:
            prompt = _LLM_EXTRACT_PROMPT.format(text=text)
            result = self._llm.chat_completions_sync(prompt)
            return self._parse_llm_result(result)
        except Exception as e:
            logger.warning(f"LLM 提取失败: {e}")
            return []

    def _parse_llm_result(self, result: str) -> list[dict]:
        if not result or "无" in result.strip():
            return []
        items = []
        for line in result.strip().split("\n"):
            line = line.strip()
            if not line or "|" not in line:
                continue
            parts = line.split("|")
            if len(parts) < 2:
                continue
            type_str = parts[0].strip().lower()
            content = parts[1].strip()
            importance = 0.5
            if len(parts) >= 3:
                try:
                    importance = max(0.0, min(1.0, float(parts[2].strip())))
                except ValueError:
                    pass
            try:
                memory_type = MemoryType(type_str)
            except ValueError:
                memory_type = MemoryType.FACT
            if content:
                items.append(
                    {
                        "content": content,
                        "memory_type": memory_type,
                        "importance": importance,
                    }
                )
        return items
