"""echon CLI 入口"""

import argparse


def main():
    parser = argparse.ArgumentParser(description="echon — RAG 记忆服务")
    sub = parser.add_subparsers(dest="command")

    sp = sub.add_parser("serve", help="启动 RAG HTTP 服务")
    sp.add_argument("--port", type=int, default=8080)
    sp.add_argument("--host", default="0.0.0.0")
    sp.add_argument("--llm-model", default="qwen3-vl-8b")
    sp.add_argument("--embedding-url", default="http://localhost:8023/v1")
    sp.add_argument(
        "--embedding-model",
        default="KaLM-embedding-multilingual-mini-instruct-v2.5",
    )
    sp.add_argument("--db-path", default="./echon_data")
    sp.add_argument("--data-dir", help="启动时摄入指定目录的文档")
    sp.add_argument("--top-k", type=int, default=5)
    sp.add_argument("--title", default="echon")
    sp.add_argument(
        "--thinking",
        nargs="?",
        const=True,
        default=None,
        help="启用思考模式",
    )

    args = parser.parse_args()

    if args.command == "serve":
        from echon.serve import RagServer, RagServerConfig

        config = RagServerConfig(
            port=args.port,
            host=args.host,
            title=args.title,
            llm_model=args.llm_model,
            db_path=args.db_path,
            embedding_url=args.embedding_url,
            embedding_model=args.embedding_model,
            top_k=args.top_k,
            thinking=args.thinking,
        )
        server = RagServer(config, data_dir=args.data_dir)
        server.run()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
