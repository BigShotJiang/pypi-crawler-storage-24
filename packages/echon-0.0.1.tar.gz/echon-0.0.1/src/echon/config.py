from dataclasses import dataclass


@dataclass
class EchonConfig:
    """echon 配置"""

    # 向量相似度阈值
    duplicate_threshold: float = 0.95  # 去重阈值
    merge_threshold: float = 0.92  # 合并阈值

    # 衰减参数
    decay_lambda: float = 0.001  # 指数衰减系数（每小时）
    forget_threshold: float = 0.05  # 遗忘阈值

    # 触发频率
    cleanup_interval: int = 10  # 每 N 次 recall 触发一次衰减检查

    # 检索参数
    similarity_weight: float = 0.7  # 相似度权重
    importance_weight: float = 0.3  # 重要性权重
