import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class MemoryType(str, Enum):
    FACT = "fact"
    EVENT = "event"
    PREFERENCE = "preference"


@dataclass
class MemoryItem:
    content: str
    memory_type: MemoryType = MemoryType.FACT
    importance: float = 0.5
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)
    accessed_at: float = field(default_factory=time.time)
    access_count: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)
    source: str = ""

    def __post_init__(self):
        if not isinstance(self.memory_type, MemoryType):
            self.memory_type = MemoryType(self.memory_type)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "content": self.content,
            "memory_type": self.memory_type.value,
            "importance": self.importance,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "accessed_at": self.accessed_at,
            "access_count": self.access_count,
            "metadata": self.metadata,
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MemoryItem":
        data = dict(data)
        data["memory_type"] = MemoryType(data["memory_type"])
        return cls(**data)
