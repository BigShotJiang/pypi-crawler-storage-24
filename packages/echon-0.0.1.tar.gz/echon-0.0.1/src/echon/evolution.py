import math
import time
import logging

from .config import EchonConfig
from .models import MemoryItem
from .store import MemoryStore

logger = logging.getLogger(__name__)


class EvolutionEngine:
    """记忆演化引擎：去重、合并、衰减、清除"""

    def __init__(self, store: MemoryStore, config: EchonConfig, llm=None):
        self.store = store
        self.config = config
        self._llm = llm

    def effective_importance(self, item: MemoryItem, now: float | None = None) -> float:
        """计算有效重要性 = importance * 时间衰减 * 访问频率加成"""
        now = now or time.time()
        hours = (now - item.updated_at) / 3600
        time_decay = math.exp(-self.config.decay_lambda * hours)
        freq_boost = min(1 + math.log2(1 + item.access_count) * 0.1, 1.5)
        return item.importance * time_decay * freq_boost

    def find_similar(
        self, content: str, threshold: float
    ) -> list[tuple[MemoryItem, float]]:
        """找到相似度超过 threshold 的记忆"""
        results = self.store.search_similar(content, top_k=20)
        similar = []
        for mem_id, sim in results:
            if sim >= threshold:
                item = self.store.get(mem_id)
                if item:
                    similar.append((item, sim))
        return similar

    def deduplicate_or_merge(
        self, new_item: MemoryItem
    ) -> tuple[str, MemoryItem]:
        """
        对新记忆执行去重/合并检查。
        返回 (action, result_item):
          - ("added", item): 新增
          - ("deduplicated", existing): 去重（刷新访问时间）
          - ("merged", merged): 合并
        """
        similar = self.find_similar(
            new_item.content, self.config.merge_threshold
        )
        if not similar:
            return "added", new_item

        # 按相似度排序，取最高的
        similar.sort(key=lambda x: x[1], reverse=True)
        best_match, best_sim = similar[0]

        if best_sim >= self.config.duplicate_threshold:
            # 去重：刷新访问时间
            best_match.accessed_at = time.time()
            best_match.access_count += 1
            if new_item.importance > best_match.importance:
                best_match.importance = new_item.importance
            self.store.save(best_match)
            return "deduplicated", best_match

        # 合并：新覆盖旧
        merged = self._merge(best_match, new_item)
        self.store.delete(best_match.id)
        return "merged", merged

    def _merge(self, old: MemoryItem, new: MemoryItem) -> MemoryItem:
        """合并两条记忆。先尝试 LLM 合并，无 LLM 则新覆盖旧"""
        if self._llm is not None:
            merged_content = self._llm_merge(old.content, new.content)
            if merged_content:
                new.content = merged_content

        new.importance = max(old.importance, new.importance)
        new.access_count = old.access_count + new.access_count
        new.updated_at = time.time()
        return new

    def _llm_merge(self, old_content: str, new_content: str) -> str | None:
        """用 LLM 合并两条记忆内容"""
        try:
            prompt = (
                "请将以下两条记忆合并为一条简洁的记忆，保留所有关键信息：\n\n"
                f"旧记忆：{old_content}\n"
                f"新记忆：{new_content}\n\n"
                "合并后的记忆："
            )
            result = self._llm.chat_completions_sync(prompt)
            return result.strip() if result else None
        except Exception as e:
            logger.warning(f"LLM 合并失败: {e}")
            return None

    def decay_check(self) -> list[str]:
        """执行衰减检查，返回被清除的记忆 id 列表"""
        now = time.time()
        removed = []
        for item in self.store.all_memories():
            eff = self.effective_importance(item, now)
            if eff < self.config.forget_threshold:
                self.store.delete(item.id)
                removed.append(item.id)
                logger.info(
                    f"记忆衰减清除: {item.id} (importance={eff:.4f})"
                )
        return removed
