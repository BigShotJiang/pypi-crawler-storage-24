"""RAG HTTP 服务 + Web 聊天界面

提供 Web 聊天界面和 API 端点，基于 echon Memory 实现检索增强生成。

用法:
    echon serve --data-dir ./data --llm-model qwen3-vl-8b
"""

from __future__ import annotations

import asyncio
import json
import os
from dataclasses import dataclass
from pathlib import Path

from aiohttp import web

THINK_OPEN = "<think>"
THINK_CLOSE = "</think>"


@dataclass
class RagServerConfig:
    # 服务
    port: int = 8080
    host: str = "0.0.0.0"
    title: str = "echon"
    # LLM
    llm_model: str = ""
    temperature: float = 0.7
    max_tokens: int = 2048
    thinking: bool | str | int | None = None
    # 记忆库
    db_path: str = "./echon_data"
    embedding_url: str = "http://localhost:8023/v1"
    embedding_model: str = "KaLM-embedding-multilingual-mini-instruct-v2.5"
    # 检索
    top_k: int = 5
    system_prompt: str = (
        "你是知识库问答助手。根据提供的参考资料回答问题。"
        "如果资料中没有相关信息，请如实说明。"
    )


class ThinkTagParser:
    """流式解析 <think>...</think> 标签，将 content 拆分为 thinking 和 content 事件。"""

    def __init__(self):
        self._in_think = False
        self._buffer = ""

    def feed(self, event: dict) -> list[dict]:
        if event["type"] != "content":
            return [event]

        text = event["content"]
        self._buffer += text
        results = []

        while self._buffer:
            if not self._in_think:
                idx = self._buffer.find(THINK_OPEN)
                if idx == -1:
                    safe, self._buffer = self._flush_safe(self._buffer, THINK_OPEN)
                    if safe:
                        results.append({"type": "content", "content": safe})
                    break
                else:
                    before = self._buffer[:idx]
                    if before:
                        results.append({"type": "content", "content": before})
                    self._buffer = self._buffer[idx + len(THINK_OPEN) :]
                    self._in_think = True
            else:
                idx = self._buffer.find(THINK_CLOSE)
                if idx == -1:
                    safe, self._buffer = self._flush_safe(self._buffer, THINK_CLOSE)
                    if safe:
                        results.append({"type": "thinking", "content": safe})
                    break
                else:
                    before = self._buffer[:idx]
                    if before:
                        results.append({"type": "thinking", "content": before})
                    self._buffer = self._buffer[idx + len(THINK_CLOSE) :]
                    self._in_think = False

        return results

    def flush(self) -> list[dict]:
        if not self._buffer:
            return []
        event_type = "thinking" if self._in_think else "content"
        result = [{"type": event_type, "content": self._buffer}]
        self._buffer = ""
        return result

    @staticmethod
    def _flush_safe(buf: str, tag: str) -> tuple[str, str]:
        max_prefix = len(tag) - 1
        if len(buf) <= max_prefix:
            for i in range(len(buf)):
                if tag.startswith(buf[i:]):
                    return buf[:i], buf[i:]
            return buf, ""
        safe_end = len(buf) - max_prefix
        tail = buf[safe_end:]
        for i in range(len(tail)):
            if tag.startswith(tail[i:]):
                return buf[: safe_end + i], tail[i:]
        return buf, ""


class RagServer:
    def __init__(self, config: RagServerConfig, data_dir: str | None = None):
        self.config = config
        self._data_dir = data_dir
        self._memory = None
        self._llm_client = None

    def _create_app(self) -> web.Application:
        app = web.Application()
        app.router.add_get("/", self._handle_index)
        app.router.add_get("/api/config", self._handle_config)
        app.router.add_post("/api/chat", self._handle_chat)
        app.router.add_post("/api/ask", self._handle_ask)
        app.router.add_get("/health", self._handle_health)
        app.on_startup.append(self._on_startup)
        app.on_cleanup.append(self._on_cleanup)
        return app

    async def _on_startup(self, app: web.Application):
        from flexllm import LLMClient

        from echon import DocumentParser, Memory

        self._memory = Memory(
            "rag-server",
            db_path=self.config.db_path,
            embedding_url=self.config.embedding_url,
            embedding_model=self.config.embedding_model,
            parser=DocumentParser(backend="markitdown"),
        )

        if self._data_dir:
            await asyncio.to_thread(self._ingest_data, self._data_dir)

        self._llm_client = LLMClient.from_config(model=self.config.llm_model)

    def _ingest_data(self, data_dir: str):
        files = sorted(
            f
            for f in os.listdir(data_dir)
            if os.path.isfile(os.path.join(data_dir, f)) and not f.startswith(".")
        )
        if not files:
            print(f"警告: {data_dir} 下没有文档")
            return
        print(f"发现 {len(files)} 篇文档，开始摄入...")
        for fname in files:
            fpath = os.path.join(data_dir, fname)
            ids = self._memory.ingest(fpath, importance=0.7)
            print(f"  {fname}: {len(ids)} 条片段")
        print(f"摄入完成，记忆库共 {len(self._memory)} 条记录")

    async def _on_cleanup(self, app: web.Application):
        if self._memory:
            self._memory.close()
        if self._llm_client:
            await self._llm_client.aclose()

    async def _handle_index(self, request: web.Request) -> web.Response:
        html_path = Path(__file__).parent / "data" / "chat_web.html"
        return web.Response(
            text=html_path.read_text(encoding="utf-8"), content_type="text/html"
        )

    async def _handle_config(self, request: web.Request) -> web.Response:
        return web.json_response(
            {
                "model": self.config.llm_model,
                "temperature": self.config.temperature,
                "title": self.config.title,
                "memory_count": len(self._memory) if self._memory else 0,
            }
        )

    async def _handle_health(self, request: web.Request) -> web.Response:
        return web.json_response({"status": "ok"})

    def _build_context(self, results: list[dict]) -> str:
        parts = []
        for i, r in enumerate(results, 1):
            source = r.get("source") or "未知"
            parts.append(f"[{i}] (来源: {source}) {r['content']}")
        return "\n\n".join(parts)

    def _build_sources(self, results: list[dict]) -> list[dict]:
        """从检索结果中提取来源，按文档名去重取最高分。"""
        seen: dict[str, float] = {}
        for r in results:
            name = r.get("source") or "未知"
            score = r["score"]
            if name not in seen or score > seen[name]:
                seen[name] = score
        sources = [{"name": n, "score": round(s, 4)} for n, s in seen.items()]
        sources.sort(key=lambda x: x["score"], reverse=True)
        return sources

    def _inject_context(self, messages: list[dict], context: str) -> list[dict]:
        """将 RAG 上下文注入 system prompt。"""
        system_content = self.config.system_prompt
        if context:
            system_content += f"\n\n参考资料：\n{context}"

        if messages and messages[0].get("role") == "system":
            messages = [{"role": "system", "content": system_content}] + messages[1:]
        else:
            messages = [{"role": "system", "content": system_content}] + messages
        return messages

    async def _handle_chat(self, request: web.Request) -> web.StreamResponse:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON"}, status=400)

        messages = data.get("messages", [])
        if not messages:
            return web.json_response({"error": "messages is required"}, status=400)

        # 取最后一条 user message 作为检索 query
        query = ""
        for msg in reversed(messages):
            if msg.get("role") == "user":
                query = msg.get("content", "")
                break

        # 检索
        results = (
            await asyncio.to_thread(self._memory.recall, query, self.config.top_k)
            if query
            else []
        )

        # 构建 RAG messages
        context = self._build_context(results) if results else ""
        rag_messages = self._inject_context(messages, context)

        # SSE 流式响应
        response = web.StreamResponse(
            status=200,
            headers={
                "Content-Type": "text/event-stream",
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )
        await response.prepare(request)

        try:
            stream_kwargs = dict(
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                return_usage=True,
            )
            if self.config.thinking is not None:
                stream_kwargs["thinking"] = self.config.thinking

            parser = ThinkTagParser()

            async for event in self._llm_client.chat_completions_stream(
                rag_messages, **stream_kwargs
            ):
                for parsed in parser.feed(event):
                    if parsed["type"] in ("content", "thinking"):
                        sse = json.dumps(parsed, ensure_ascii=False)
                        await response.write(f"data: {sse}\n\n".encode("utf-8"))

            for parsed in parser.flush():
                if parsed["type"] in ("content", "thinking"):
                    sse = json.dumps(parsed, ensure_ascii=False)
                    await response.write(f"data: {sse}\n\n".encode("utf-8"))

            # 发送引用来源
            if results:
                sources = self._build_sources(results)
                sources_event = json.dumps(
                    {"type": "sources", "sources": sources}, ensure_ascii=False
                )
                await response.write(f"data: {sources_event}\n\n".encode("utf-8"))

            done_event = json.dumps({"type": "done"})
            await response.write(f"data: {done_event}\n\n".encode("utf-8"))
        except Exception as e:
            error_event = json.dumps(
                {"type": "error", "message": str(e)}, ensure_ascii=False
            )
            await response.write(f"data: {error_event}\n\n".encode("utf-8"))

        await response.write_eof()
        return response

    async def _handle_ask(self, request: web.Request) -> web.Response:
        try:
            data = await request.json()
        except Exception:
            return web.json_response({"error": "invalid JSON"}, status=400)

        question = data.get("question", "").strip()
        if not question:
            return web.json_response({"error": "question is required"}, status=400)

        results = await asyncio.to_thread(
            self._memory.recall, question, self.config.top_k
        )

        context = self._build_context(results) if results else ""
        messages = self._inject_context(
            [{"role": "user", "content": question}], context
        )

        # 收集流式结果
        full_content = ""
        async for chunk in self._llm_client.chat_completions_stream(
            messages,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
        ):
            full_content += chunk

        return web.json_response(
            {
                "answer": full_content,
                "sources": self._build_sources(results),
            }
        )

    def run(self):
        app = self._create_app()
        print(f"启动 RAG 服务: http://{self.config.host}:{self.config.port}")
        web.run_app(app, host=self.config.host, port=self.config.port)
