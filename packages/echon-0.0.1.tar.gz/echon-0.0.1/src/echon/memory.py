import os
import time
import logging
from typing import Any

from maque.embedding import TextEmbedding

from .config import EchonConfig
from .evolution import EvolutionEngine
from .extractor import MemoryExtractor
from .models import MemoryItem, MemoryType
from .store import MemoryStore

logger = logging.getLogger(__name__)


class Memory:
    """echon 记忆模块主入口"""

    def __init__(
        self,
        agent_id: str,
        db_path: str = "./echon_data",
        embedding_model: str = "BAAI/bge-m3",
        embedding_url: str = "http://localhost:8001/v1",
        llm=None,
        config: EchonConfig | None = None,
        parser=None,
    ):
        self.agent_id = agent_id
        self.config = config or EchonConfig()

        embedding = TextEmbedding(
            base_url=embedding_url,
            model=embedding_model,
        )
        self._store = MemoryStore(f"echon_{agent_id}", db_path, embedding)
        self._llm = llm
        self._evolution = EvolutionEngine(self._store, self.config, llm=llm)
        self._extractor = MemoryExtractor(llm=llm)
        self._parser = parser  # DocumentParser | None
        self._recall_count = 0

    def add(
        self,
        content: str,
        memory_type: str | MemoryType = "fact",
        importance: float = 0.5,
        metadata: dict[str, Any] | None = None,
        source: str = "",
    ) -> str:
        """添加一条记忆，返回 memory_id"""
        if not content or not content.strip():
            raise ValueError("记忆内容不能为空")
        if not 0 <= importance <= 1:
            raise ValueError(f"importance 必须在 0-1 之间，收到: {importance}")
        item = MemoryItem(
            content=content,
            memory_type=memory_type,
            importance=importance,
            metadata=metadata or {},
            source=source,
        )

        # 去重/合并（内部通过 Lance 检索相似记忆）
        action, result_item = self._evolution.deduplicate_or_merge(item)
        if action == "added":
            self._store.save(item)
            logger.debug(f"新增记忆: {item.id}")
            return item.id
        elif action == "merged":
            self._store.save(result_item)
            logger.debug(f"合并记忆: {result_item.id}")
            return result_item.id
        else:
            # deduplicated
            logger.debug(f"去重记忆: {result_item.id}")
            return result_item.id

    def recall(
        self, query: str, top_k: int = 5, min_score: float = 0.0
    ) -> list[dict]:
        """
        检索相关记忆。
        返回 [{"id", "content", "score", "memory_type", "importance", ...}, ...]
        """
        self._recall_count += 1

        # 定期衰减检查
        if self._recall_count % self.config.cleanup_interval == 0:
            self._evolution.decay_check()

        candidates = self._store.search_similar(query, top_k=top_k * 2)
        now = time.time()
        results = []
        for mem_id, similarity in candidates:
            item = self._store.get(mem_id)
            if item is None:
                continue

            eff_imp = self._evolution.effective_importance(item, now)
            score = (
                similarity * self.config.similarity_weight
                + eff_imp * self.config.importance_weight
            )
            if score < min_score:
                continue

            # 更新访问信息（仅元数据，不重写向量）
            item.accessed_at = now
            item.access_count += 1
            self._store.save_metadata(item)

            results.append(
                {
                    "id": item.id,
                    "content": item.content,
                    "score": round(score, 4),
                    "similarity": round(similarity, 4),
                    "memory_type": item.memory_type.value,
                    "importance": item.importance,
                    "effective_importance": round(eff_imp, 4),
                    "metadata": item.metadata,
                    "source": item.source,
                }
            )

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:top_k]

    def extract(self, text: str, source: str = "") -> list[str]:
        """从文本中自动提取记忆并添加，返回存活的 memory_id 列表。

        注意：提取的多条记忆可能因语义相似而触发合并，
        后添加的记忆可能 merge 掉先添加的，因此只返回最终存活的 id。
        """
        extracted = self._extractor.extract(text)
        ids = []
        for item in extracted:
            mid = self.add(
                content=item["content"],
                memory_type=item["memory_type"],
                importance=item["importance"],
                source=source,
            )
            ids.append(mid)
        # 过滤掉被后续 merge 删除的 id
        return [mid for mid in dict.fromkeys(ids) if self._store.get(mid) is not None]

    def ingest(
        self,
        file_path: str,
        memory_type: str | MemoryType = "fact",
        importance: float = 0.5,
        chunk_size: int | None = None,
        **kwargs,
    ) -> list[str]:
        """解析文档并将切分后的片段添加为记忆。

        先批量写入（embedding + 向量库），再统一去重合并。

        Args:
            file_path: 文档路径（支持 PDF/Word/PPT/Excel/HTML 等）
            memory_type: 记忆类型
            importance: 重要性
            chunk_size: 切分大小，None 使用 parser 默认值
            **kwargs: 传递给 add() 的额外参数

        Returns:
            新增的 memory_id 列表
        """
        if self._parser is None:
            from .document import DocumentParser
            self._parser = DocumentParser()

        chunks = self._parser.parse(file_path, chunk_size=chunk_size)
        source = os.path.basename(file_path)

        items = []
        for chunk in chunks:
            if not chunk or not chunk.strip():
                continue
            items.append(MemoryItem(
                content=chunk,
                memory_type=memory_type,
                importance=importance,
                metadata=kwargs.get("metadata", {}),
                source=source,
            ))
        if not items:
            return []
        self._store.save_batch(items)

        surviving = self.deduplicate([item.id for item in items])
        logger.info(f"从 {source} 摄入 {len(surviving)} 条记忆")
        return surviving

    def deduplicate(self, ids: list[str] | None = None) -> list[str]:
        """对记忆库执行去重合并，返回存活的 id 列表。

        Args:
            ids: 要检查的记忆 id 列表。None 则对全库去重。
        """
        if ids is not None:
            items = [self._store.get(mid) for mid in ids]
            items = [item for item in items if item is not None]
        else:
            items = self._store.all_memories()

        check_ids = {item.id for item in items}
        removed = set()
        for item in items:
            if item.id in removed:
                continue
            similar = self._evolution.find_similar(
                item.content, self.config.merge_threshold
            )
            # 排除自身和同批次条目，只与已有记忆去重
            similar = [(m, s) for m, s in similar if m.id not in check_ids]
            if not similar:
                continue
            similar.sort(key=lambda x: x[1], reverse=True)
            best_match, best_sim = similar[0]
            if best_sim >= self.config.duplicate_threshold:
                best_match.accessed_at = time.time()
                best_match.access_count += 1
                if item.importance > best_match.importance:
                    best_match.importance = item.importance
                self._store.save(best_match)
                self._store.delete(item.id)
                removed.add(item.id)
            elif best_sim >= self.config.merge_threshold:
                merged = self._evolution._merge(best_match, item)
                self._store.save(merged)
                self._store.delete(item.id)
                removed.add(item.id)

        surviving = [item.id for item in items if item.id not in removed]
        if removed:
            logger.info(f"去重合并: {len(removed)} 条被移除, {len(surviving)} 条存活")
        return surviving

    def cleanup(self) -> list[str]:
        """手动清理过期记忆，返回被清除的 id 列表"""
        return self._evolution.decay_check()

    def close(self):
        self._store.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __len__(self) -> int:
        return self._store.count()

    def __getitem__(self, memory_id: str) -> MemoryItem | None:
        return self._store.get(memory_id)
