import json
import os
import shlex
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from harbor.agents.installed.base import BaseInstalledAgent, ExecInput
from harbor.agents.utils import get_api_key_var_names_from_model_name
from harbor.models.agent.context import AgentContext
from harbor.models.agent.name import AgentName
from harbor.models.trajectories import (
    Agent,
    FinalMetrics,
    Metrics,
    Observation,
    ObservationResult,
    Step,
    ToolCall,
    Trajectory,
)
from harbor.models.trial.paths import EnvironmentPaths
from harbor.utils.logger import logger


def _normalize_content(raw_content: Any) -> str:
    """Normalize message content which may be a string, list of parts, or None."""
    if raw_content is None:
        return ""
    if isinstance(raw_content, str):
        return raw_content
    if isinstance(raw_content, list):
        parts = []
        for part in raw_content:
            if isinstance(part, dict):
                parts.append(part.get("text", str(part)))
            else:
                parts.append(str(part))
        return "\n".join(parts)
    return str(raw_content)


def _add_observation_to_last_agent_step(
    steps: list[Step], content: str, _logger: Any, message_index: int
) -> None:
    """Add observation content to the most recent agent step."""
    if steps and steps[-1].source == "agent":
        prev_step = steps[-1]
        if prev_step.observation and prev_step.observation.results:
            prev_step.observation.results.append(ObservationResult(content=content))
        else:
            prev_step.observation = Observation(
                results=[ObservationResult(content=content)]
            )
    else:
        _logger.warning(f"Message at index {message_index} has no preceding agent step")


def _build_step_metrics(
    prompt_tokens: int,
    completion_tokens: int,
    cached_tokens: int,
    prompt_tokens_details: dict[str, Any],
    completion_tokens_details: dict[str, Any],
    total_cost_usd: float,
    total_completion_tokens: int,
) -> Metrics | None:
    """Build metrics for an individual step."""
    if prompt_tokens == 0 and completion_tokens == 0:
        return None

    step_cost = None
    if total_cost_usd > 0 and total_completion_tokens > 0 and completion_tokens > 0:
        step_cost = (completion_tokens / total_completion_tokens) * total_cost_usd

    extra_metrics: dict[str, Any] = {}
    if prompt_tokens_details:
        extra_metrics["prompt_tokens_details"] = prompt_tokens_details
    if completion_tokens_details:
        extra_metrics["completion_tokens_details"] = completion_tokens_details

    return Metrics(
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        cached_tokens=cached_tokens if cached_tokens > 0 else None,
        cost_usd=step_cost if step_cost and step_cost > 0 else None,
        extra=extra_metrics if extra_metrics else None,
    )


def _parse_tool_calls(
    message: dict[str, Any], content: str, step_id: int
) -> tuple[list[ToolCall] | None, str | None]:
    """Parse tool calls from an assistant message into ATIF ToolCall objects."""
    message_tool_calls = message.get("tool_calls")
    if not message_tool_calls:
        return None, content if content else None

    tool_calls: list[ToolCall] = []
    for tc in message_tool_calls:
        tc_id = tc.get("id", f"call_{step_id}_{len(tool_calls) + 1}")
        func = tc.get("function") or {}
        func_name = func.get("name", "bash")
        raw_args = func.get("arguments", "{}")
        if isinstance(raw_args, str):
            try:
                arguments = json.loads(raw_args)
            except (json.JSONDecodeError, TypeError):
                arguments = {"command": raw_args}
        elif isinstance(raw_args, dict):
            arguments = raw_args
        else:
            arguments = {"command": str(raw_args)}
        tool_calls.append(
            ToolCall(
                tool_call_id=tc_id,
                function_name=func_name,
                arguments=arguments,
            )
        )

    # In tool-calling mode, the content is typically reasoning/thinking
    reasoning = content if content else None
    return tool_calls if tool_calls else None, reasoning


def convert_mini_swe_agent_to_atif(
    mini_swe_agent_trajectory: dict[str, Any],
    session_id: str,
) -> Trajectory:
    """
    Convert mini-swe-agent v2 trajectory format to ATIF format.

    Expects the v2 native tool-calling format where assistant messages
    contain a ``tool_calls`` array and tool results use ``role: "tool"``.

    Args:
        mini_swe_agent_trajectory: The mini-swe-agent trajectory data
        session_id: The session ID for the ATIF trajectory

    Returns:
        Trajectory: The converted ATIF trajectory
    """
    _logger = logger.getChild(__name__)

    # Extract metadata
    info = mini_swe_agent_trajectory.get("info") or {}
    config = info.get("config") or {}
    model_config = config.get("model") or {}
    agent_config = config.get("agent") or {}

    model_name = model_config.get("model_name") or "unknown"
    mini_version = info.get("mini_version") or "unknown"
    trajectory_format = mini_swe_agent_trajectory.get("trajectory_format", "unknown")

    messages = mini_swe_agent_trajectory.get("messages") or []

    steps: list[Step] = []
    step_id = 1

    # Track cumulative token counts
    total_prompt_tokens = 0
    total_completion_tokens = 0
    total_cached_tokens = 0
    total_reasoning_tokens = 0
    total_cost_usd = (info.get("model_stats") or {}).get("instance_cost") or 0.0

    # First pass: count total completion tokens for cost apportioning
    for message in messages:
        extra = message.get("extra") or {}
        response_data = extra.get("response") or {}
        usage = response_data.get("usage") or {}
        total_completion_tokens += usage.get("completion_tokens") or 0

    # Process messages
    for i, message in enumerate(messages):
        role = message.get("role")
        content = _normalize_content(message.get("content"))
        extra = message.get("extra") or {}

        # Extract token usage
        response_data = extra.get("response") or {}
        usage = response_data.get("usage") or {}

        prompt_tokens = usage.get("prompt_tokens") or 0
        completion_tokens = usage.get("completion_tokens") or 0
        prompt_tokens_details = usage.get("prompt_tokens_details") or {}
        completion_tokens_details = usage.get("completion_tokens_details") or {}
        cached_tokens = prompt_tokens_details.get("cached_tokens") or 0
        reasoning_tokens = completion_tokens_details.get("reasoning_tokens") or 0

        total_prompt_tokens += prompt_tokens
        total_cached_tokens += cached_tokens
        total_reasoning_tokens += reasoning_tokens

        if role == "system":
            steps.append(
                Step(
                    step_id=step_id,
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    source="system",
                    message=content,
                )
            )
            step_id += 1

        elif role == "user":
            if i == 1:
                steps.append(
                    Step(
                        step_id=step_id,
                        timestamp=datetime.now(timezone.utc).isoformat(),
                        source="user",
                        message=content,
                    )
                )
                step_id += 1
            else:
                _add_observation_to_last_agent_step(steps, content, _logger, i)

        elif role == "tool":
            _add_observation_to_last_agent_step(steps, content, _logger, i)

        elif role == "assistant":
            tool_calls, reasoning = _parse_tool_calls(message, content, step_id)

            metrics = _build_step_metrics(
                prompt_tokens=prompt_tokens,
                completion_tokens=completion_tokens,
                cached_tokens=cached_tokens,
                prompt_tokens_details=prompt_tokens_details,
                completion_tokens_details=completion_tokens_details,
                total_cost_usd=total_cost_usd,
                total_completion_tokens=total_completion_tokens,
            )

            steps.append(
                Step(
                    step_id=step_id,
                    timestamp=datetime.now(timezone.utc).isoformat(),
                    source="agent",
                    model_name=model_name,
                    message=content,
                    reasoning_content=reasoning,
                    tool_calls=tool_calls,
                    metrics=metrics,
                )
            )
            step_id += 1

    # Build final metrics
    final_extra: dict[str, Any] = {}
    if total_reasoning_tokens > 0:
        final_extra["total_reasoning_tokens"] = total_reasoning_tokens

    final_metrics = FinalMetrics(
        total_prompt_tokens=total_prompt_tokens,
        total_completion_tokens=total_completion_tokens,
        total_cached_tokens=total_cached_tokens if total_cached_tokens > 0 else None,
        total_cost_usd=total_cost_usd if total_cost_usd > 0 else None,
        extra=final_extra if final_extra else None,
    )

    agent = Agent(
        name="mini-swe-agent",
        version=mini_version,
        model_name=model_name,
        extra={
            "original_format": trajectory_format,
            "agent_config": agent_config,
        },
    )

    return Trajectory(
        schema_version="ATIF-v1.2",
        session_id=session_id,
        agent=agent,
        steps=steps,
        final_metrics=final_metrics,
        notes="Converted from mini-swe-agent trajectory format to ATIF",
    )


def convert_and_save_trajectory(
    mini_swe_agent_trajectory_path: Path,
    atif_trajectory_path: Path,
    session_id: str,
) -> None:
    """
    Convert mini-swe-agent trajectory file to ATIF format and save it.

    Args:
        mini_swe_agent_trajectory_path: Path to mini-swe-agent trajectory.json
        atif_trajectory_path: Path to save the ATIF trajectory.json
        session_id: The session ID for the ATIF trajectory
    """
    _logger = logger.getChild(__name__)

    try:
        mini_swe_agent_trajectory = json.loads(
            mini_swe_agent_trajectory_path.read_text()
        )

        atif_trajectory = convert_mini_swe_agent_to_atif(
            mini_swe_agent_trajectory,
            session_id,
        )

        atif_trajectory_path.write_text(
            json.dumps(atif_trajectory.to_json_dict(), indent=2)
        )

        _logger.info(
            f"Successfully converted trajectory to ATIF format: {atif_trajectory_path}"
        )

    except Exception as e:
        _logger.error(f"Failed to convert trajectory: {e}")
        raise


class MiniSweAgent(BaseInstalledAgent):
    """
    The Mini SWE Agent uses the mini-swe-agent tool to solve tasks.
    """

    SUPPORTS_ATIF: bool = True

    @staticmethod
    def name() -> str:
        return AgentName.MINI_SWE_AGENT.value

    @property
    def _install_agent_template_path(self) -> Path:
        return Path(__file__).parent / "install-mini-swe-agent.sh.j2"

    @property
    def _mini_swe_agent_trajectory_path(self) -> Path:
        """Path where mini-swe-agent writes its own trajectory format."""
        return EnvironmentPaths.agent_dir / "mini-swe-agent.trajectory.json"

    @property
    def _atif_trajectory_path(self) -> Path:
        """Path where we write the ATIF-formatted trajectory."""
        return EnvironmentPaths.agent_dir / "trajectory.json"

    def populate_context_post_run(self, context: AgentContext) -> None:
        # Read the mini-swe-agent trajectory
        mini_trajectory_path = self.logs_dir / "mini-swe-agent.trajectory.json"

        if not mini_trajectory_path.exists():
            print(
                f"Mini-swe-agent trajectory file {mini_trajectory_path} does not exist"
            )
            return

        try:
            mini_trajectory = json.loads(mini_trajectory_path.read_text())
        except Exception as e:
            print(f"Failed to load mini-swe-agent trajectory: {e}")
            return

        # Extract token usage from mini-swe-agent format
        n_input_tokens = 0
        n_output_tokens = 0
        n_cache_tokens = 0
        total_cost = ((mini_trajectory.get("info") or {}).get("model_stats") or {}).get(
            "instance_cost"
        ) or 0
        for message in mini_trajectory.get("messages") or []:
            usage = ((message.get("extra") or {}).get("response") or {}).get(
                "usage"
            ) or {}

            prompt_tokens_details = usage.get("prompt_tokens_details") or {}
            n_cache_tokens += prompt_tokens_details.get("cached_tokens") or 0

            n_input_tokens += usage.get("prompt_tokens") or 0
            n_output_tokens += usage.get("completion_tokens") or 0

        context.n_input_tokens = n_input_tokens
        context.n_output_tokens = n_output_tokens
        context.n_cache_tokens = n_cache_tokens
        context.cost_usd = total_cost

        # Convert mini-swe-agent trajectory to ATIF format
        atif_trajectory_path = self.logs_dir / "trajectory.json"
        session_id = str(uuid.uuid4())
        try:
            convert_and_save_trajectory(
                mini_swe_agent_trajectory_path=mini_trajectory_path,
                atif_trajectory_path=atif_trajectory_path,
                session_id=session_id,
            )
        except Exception as e:
            print(f"Failed to convert trajectory to ATIF format: {e}")

    def create_run_agent_commands(self, instruction: str) -> list[ExecInput]:
        escaped_instruction = shlex.quote(instruction)

        if not self.model_name or "/" not in self.model_name:
            raise ValueError("Model name must be in the format provider/model_name")

        env = {
            "MSWEA_CONFIGURED": "true",  # Disable interactive setup
        }

        if "MSWEA_API_KEY" in os.environ:
            env["MSWEA_API_KEY"] = os.environ["MSWEA_API_KEY"]
        else:
            try:
                api_key_vars = get_api_key_var_names_from_model_name(self.model_name)
                for api_key_var in api_key_vars:
                    if api_key_var in os.environ:
                        env[api_key_var] = os.environ[api_key_var]
                    else:
                        raise ValueError(
                            f"Unset API variable for model {self.model_name}. "
                            f"Please set {api_key_var} or MSWEA_API_KEY environment variable"
                        )
            except ValueError as e:
                raise ValueError(
                    f"Unable to determine API key for model {self.model_name}: {e}. "
                    "Please set MSWEA_API_KEY environment variable as fallback"
                )

        # Pass through common API base configurations if present
        if "OPENAI_API_BASE" in os.environ:
            env["OPENAI_API_BASE"] = os.environ["OPENAI_API_BASE"]

        return [
            ExecInput(
                command=(
                    '. "$HOME/.local/bin/env"; '
                    f"mini-swe-agent --yolo --model={self.model_name} --task={escaped_instruction} "
                    f"--output={self._mini_swe_agent_trajectory_path} --cost-limit=0 "
                    f"--exit-immediately 2>&1 </dev/null | stdbuf -oL tee /logs/agent/mini-swe-agent.txt"
                ),
                env=env,
            )
        ]
