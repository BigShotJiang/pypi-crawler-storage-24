# Fizko CLI

CLI para consultar datos tributarios y contables desde la API de Fizko.

## Instalación

```bash
pip install fizko-cli
```

## Autenticación

```bash
fizko login
```

Se abrirá tu navegador para iniciar sesión con tu cuenta Fizko. Las credenciales se guardan en `~/.config/fizko/credentials.json`.

También puedes usar una API key directamente:

```bash
export FIZKO_API_KEY=fizko_xxxxx
```

## Uso

```bash
# Empresas
fizko companies list
fizko companies get <company-uuid>

# Documentos tributarios
fizko tax purchases --company <uuid>
fizko tax sales --company <uuid> --period-year 2026 --period-month 1
fizko tax f29 --company-id <uuid>
fizko tax summary --company-id <uuid> --period 2026-01
fizko tax documents --company-id <uuid> --period 2026-01

# Contabilidad
fizko accounting accounts --company <uuid>
fizko accounting balance-report --company-id <uuid> --period-from 2026-01 --period-to 2026-12
fizko accounting income-statement --company-id <uuid> --period-from 2026-01 --period-to 2026-12
fizko accounting general-ledger --company-id <uuid> --period-from 2026-01 --period-to 2026-12

# Estado de sesión
fizko status
fizko logout
```

Todos los comandos devuelven JSON. Usa `--help` en cualquier comando para ver las opciones disponibles.
