"""Persistent config for Fizko CLI credentials."""

import json
import os
from pathlib import Path
from typing import Optional


def _config_dir() -> Path:
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = Path(xdg) if xdg else Path.home() / ".config"
    d = base / "fizko"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _config_path() -> Path:
    return _config_dir() / "credentials.json"


def save(api_key: str, email: str, base_url: str) -> Path:
    """Save credentials. Returns the config file path."""
    path = _config_path()
    path.write_text(json.dumps({
        "api_key": api_key,
        "email": email,
        "base_url": base_url,
    }, indent=2))
    path.chmod(0o600)
    return path


def load() -> Optional[dict]:
    """Load saved credentials, or None if not logged in."""
    path = _config_path()
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def clear() -> None:
    """Remove saved credentials."""
    path = _config_path()
    if path.exists():
        path.unlink()
