"""HTTP client for the Fizko API."""

import os
import sys
import json
from typing import Optional

import httpx

from fizko_cli import config

DEFAULT_BASE_URL = "https://api.fizko.ai"

# Global flag — set by --compact in main.py
_compact = False


def set_compact(value: bool) -> None:
    global _compact
    _compact = value


def _get_credentials() -> tuple:
    """Return (api_key, base_url). Env vars take precedence over saved config."""
    env_key = os.environ.get("FIZKO_API_KEY", "")
    env_url = os.environ.get("FIZKO_API_URL", "")

    if env_key:
        return env_key, (env_url or DEFAULT_BASE_URL).rstrip("/")

    saved = config.load()
    if saved and saved.get("api_key"):
        url = env_url or saved.get("base_url", DEFAULT_BASE_URL)
        return saved["api_key"], url.rstrip("/")

    print(json.dumps({"error": "Not authenticated. Run: fizko login"}), file=sys.stderr)
    raise SystemExit(1)


def get(path: str, params: Optional[dict] = None) -> dict:
    """GET request to the Fizko API. Returns parsed JSON."""
    api_key, base_url = _get_credentials()
    url = f"{base_url}{path}"
    clean_params = {k: v for k, v in (params or {}).items() if v is not None}
    resp = httpx.get(
        url,
        params=clean_params,
        headers={"X-API-Key": api_key},
        timeout=30,
    )
    if resp.status_code >= 400:
        try:
            err = resp.json()
        except Exception:
            err = {"error": resp.text, "status_code": resp.status_code}
        print(json.dumps(err, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
    return resp.json()


def post(path: str, data: Optional[dict] = None, api_key: Optional[str] = None, base_url: Optional[str] = None) -> dict:
    """POST request. If api_key/base_url not given, uses saved credentials."""
    if not api_key:
        api_key, base_url = _get_credentials()
    elif not base_url:
        base_url = os.environ.get("FIZKO_API_URL", DEFAULT_BASE_URL).rstrip("/")
    url = f"{base_url}{path}"
    resp = httpx.post(
        url,
        json=data or {},
        headers={"X-API-Key": api_key} if api_key else {},
        timeout=30,
    )
    if resp.status_code >= 400:
        try:
            err = resp.json()
        except Exception:
            err = {"error": resp.text, "status_code": resp.status_code}
        print(json.dumps(err, ensure_ascii=False), file=sys.stderr)
        raise SystemExit(1)
    return resp.json()


def raw_get(url: str, params: Optional[dict] = None) -> dict:
    """GET request to a full URL (no auth). For polling."""
    resp = httpx.get(url, params=params, timeout=10)
    return resp.json()


def raw_post(url: str, data: Optional[dict] = None) -> dict:
    """POST request to a full URL (no auth). For initiate."""
    resp = httpx.post(url, json=data or {}, timeout=10)
    return resp.json()


def output(data) -> None:
    """Print JSON to stdout. Uses compact mode (no indent) when --compact is set."""
    indent = None if _compact else 2
    print(json.dumps(data, indent=indent, ensure_ascii=False, default=str))
