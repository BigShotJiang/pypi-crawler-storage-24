"""Machine-readable schema of all CLI commands for AI agent discovery."""

SCHEMA = {
    "name": "fizko",
    "description": "CLI for the Fizko API. Query tax documents, accounting reports, and company data for Chilean businesses. All commands output JSON to stdout. Errors go to stderr as JSON with exit code 1.",
    "auth": "Run 'fizko login' to authenticate, or set FIZKO_API_KEY env var. Credentials are stored in ~/.config/fizko/credentials.json.",
    "global_flags": {
        "--compact": "Output JSON without indentation (smaller output for programmatic use)"
    },
    "tip": "Start with 'fizko companies list' to get company UUIDs, then use those UUIDs in other commands.",
    "commands": {
        "companies list": {
            "description": "List all companies the authenticated user has access to. Returns array of companies with id, rut, business_name, tax_info.",
            "options": {
                "--page": {"type": "int", "required": False, "description": "Page number for pagination"}
            },
            "example": "fizko companies list"
        },
        "companies get": {
            "description": "Get full detail of a single company including tax_info, settings, and representatives.",
            "args": {
                "company_id": {"type": "UUID", "required": True, "description": "Company UUID"}
            },
            "example": "fizko companies get 550e8400-e29b-41d4-a716-446655440000"
        },
        "tax purchases": {
            "description": "List purchase documents (facturas de compra). Returns paginated list with supplier info, amounts, IVA, document type, and period.",
            "options": {
                "--company": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period-year": {"type": "int", "required": False, "description": "Filter by year (e.g. 2026)"},
                "--period-month": {"type": "int", "required": False, "description": "Filter by month (1-12)"},
                "--document-type": {"type": "str", "required": False, "description": "DTE type code (33=factura, 34=exenta, 61=nota credito)"},
                "--page": {"type": "int", "required": False, "description": "Page number"}
            },
            "example": "fizko tax purchases --company UUID --period-year 2026 --period-month 1"
        },
        "tax purchase": {
            "description": "Get full detail of a single purchase document.",
            "args": {
                "purchase_id": {"type": "UUID", "required": True, "description": "Purchase document UUID"}
            },
            "example": "fizko tax purchase 550e8400-e29b-41d4-a716-446655440000"
        },
        "tax sales": {
            "description": "List sales documents (facturas de venta). Returns paginated list with customer info, amounts, IVA, document type, and period.",
            "options": {
                "--company": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period-year": {"type": "int", "required": False, "description": "Filter by year"},
                "--period-month": {"type": "int", "required": False, "description": "Filter by month (1-12)"},
                "--document-type": {"type": "str", "required": False, "description": "DTE type code"},
                "--page": {"type": "int", "required": False, "description": "Page number"}
            },
            "example": "fizko tax sales --company UUID --period-year 2026 --period-month 3"
        },
        "tax sale": {
            "description": "Get full detail of a single sales document.",
            "args": {
                "sale_id": {"type": "UUID", "required": True, "description": "Sales document UUID"}
            },
            "example": "fizko tax sale UUID"
        },
        "tax contacts": {
            "description": "List tax contacts (suppliers and customers). Returns business_name, rut, is_supplier, is_customer.",
            "options": {
                "--company": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--page": {"type": "int", "required": False, "description": "Page number"}
            },
            "example": "fizko tax contacts --company UUID"
        },
        "tax documents": {
            "description": "List ALL tax documents unified (purchases + sales + honorarios) sorted by date. Best for getting a complete view of transactions.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": False, "description": "Period YYYY-MM"},
                "--start-date": {"type": "str", "required": False, "description": "Start date YYYY-MM-DD"},
                "--end-date": {"type": "str", "required": False, "description": "End date YYYY-MM-DD"},
                "--limit": {"type": "int", "required": False, "description": "Results per page (default 100)"},
                "--offset": {"type": "int", "required": False, "description": "Pagination offset"}
            },
            "example": "fizko tax documents --company-id UUID --period 2026-01"
        },
        "tax document": {
            "description": "Get full detail of any tax document by its UUID (purchase, sale, or honorario).",
            "args": {
                "document_id": {"type": "UUID", "required": True, "description": "Document UUID"}
            },
            "example": "fizko tax document UUID"
        },
        "tax documents-summary": {
            "description": "Get transaction count summary by document type for the last 3 months. Useful for understanding transaction volume.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"}
            },
            "example": "fizko tax documents-summary --company-id UUID"
        },
        "tax f29": {
            "description": "List Form 29 tax declarations (monthly VAT/income tax) grouped by period. Includes both local and SII-downloaded versions.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--year": {"type": "int", "required": False, "description": "Filter by year"},
                "--page": {"type": "int", "required": False, "description": "Page number"}
            },
            "example": "fizko tax f29 --company-id UUID --year 2026"
        },
        "tax f29-export": {
            "description": "Export documents contributing to a specific F29 code as CSV data.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--code": {"type": "str", "required": True, "description": "F29 code to export"},
                "--period": {"type": "str", "required": True, "description": "Period YYYY-MM"}
            },
            "example": "fizko tax f29-export --company-id UUID --code 538 --period 2026-01"
        },
        "tax f29-codes": {
            "description": "List all F29 codes that have exportable documents for a period.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": True, "description": "Period YYYY-MM"}
            },
            "example": "fizko tax f29-codes --company-id UUID --period 2026-01"
        },
        "tax summary": {
            "description": "Get tax summary for a period from Form 29 data. Includes IVA debito/credito, PPM, retention amounts.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": True, "description": "Period YYYY-MM"}
            },
            "example": "fizko tax summary --company-id UUID --period 2026-01"
        },
        "tax iva": {
            "description": "Get IVA (VAT) summary for a period. Shows IVA debito, credito, and balance.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": True, "description": "Period YYYY-MM"}
            },
            "example": "fizko tax iva --company-id UUID --period 2026-01"
        },
        "tax timeline": {
            "description": "Get tax timeline for the last 12 months. Shows monthly totals for purchases, sales, IVA.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"}
            },
            "example": "fizko tax timeline --company-id UUID"
        },
        "tax honorarios": {
            "description": "List boletas de honorarios (freelance receipts). Shows issuer, amount, retention, dates.",
            "options": {
                "--company": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period-year": {"type": "int", "required": False, "description": "Filter by year"},
                "--period-month": {"type": "int", "required": False, "description": "Filter by month (1-12)"}
            },
            "example": "fizko tax honorarios --company UUID --period-year 2026"
        },
        "tax ddjj": {
            "description": "List declaraciones juradas (annual sworn statements). Shows DJ number, status, year.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--year": {"type": "int", "required": False, "description": "Tax year"}
            },
            "example": "fizko tax ddjj --company-id UUID --year 2025"
        },
        "tax checker-tributario": {
            "description": "Compare SII purchase/sales books vs Fizko accounting records. Shows discrepancies between declared and booked documents.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": True, "description": "Period YYYY-MM"}
            },
            "example": "fizko tax checker-tributario --company-id UUID --period 2026-01"
        },
        "tax checker-impuestos": {
            "description": "Compare taxes declared in F29 vs taxes booked in Fizko accounting. Shows discrepancies per tax line.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": True, "description": "Period YYYY-MM"}
            },
            "example": "fizko tax checker-impuestos --company-id UUID --period 2026-01"
        },
        "accounting accounts": {
            "description": "List chart of accounts (plan de cuentas). Returns account code, name, type, balance. Use --tree for hierarchical structure.",
            "options": {
                "--company": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--tree": {"type": "bool", "required": False, "description": "Return as tree structure instead of flat list"}
            },
            "example": "fizko accounting accounts --company UUID --tree"
        },
        "accounting journal-entries": {
            "description": "List journal entries (asientos contables). Returns entry date, description, lines with debit/credit amounts.",
            "options": {
                "--company": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": False, "description": "Period YYYY-MM"},
                "--limit": {"type": "int", "required": False, "description": "Results limit"},
                "--offset": {"type": "int", "required": False, "description": "Pagination offset"}
            },
            "example": "fizko accounting journal-entries --company UUID --period 2026-01"
        },
        "accounting journal-entry": {
            "description": "Get full detail of a journal entry including all debit/credit lines.",
            "args": {
                "entry_id": {"type": "UUID", "required": True, "description": "Journal entry UUID"}
            },
            "example": "fizko accounting journal-entry UUID"
        },
        "accounting balance-report": {
            "description": "Balance de 8 columnas (Eight-Column Balance Sheet). Shows opening balances, movements, sums, and closing balances per account.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period-from": {"type": "str", "required": True, "description": "Start period YYYY-MM"},
                "--period-to": {"type": "str", "required": True, "description": "End period YYYY-MM"},
                "--cost-center-id": {"type": "UUID", "required": False, "description": "Filter by cost center"}
            },
            "example": "fizko accounting balance-report --company-id UUID --period-from 2026-01 --period-to 2026-12"
        },
        "accounting income-statement": {
            "description": "Estado de Resultados (Income Statement / EERR). Shows revenue, costs, expenses, and net income by category.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period-from": {"type": "str", "required": True, "description": "Start period YYYY-MM"},
                "--period-to": {"type": "str", "required": True, "description": "End period YYYY-MM"},
                "--cost-center-id": {"type": "UUID", "required": False, "description": "Filter by cost center"}
            },
            "example": "fizko accounting income-statement --company-id UUID --period-from 2026-01 --period-to 2026-12"
        },
        "accounting general-journal": {
            "description": "Libro Diario (General Journal). Lists all posted journal entries for a period with line detail.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": True, "description": "Period YYYY-MM"},
                "--page": {"type": "int", "required": False, "description": "Page number"},
                "--page-size": {"type": "int", "required": False, "description": "Results per page"}
            },
            "example": "fizko accounting general-journal --company-id UUID --period 2026-01"
        },
        "accounting general-ledger": {
            "description": "Libro Mayor (General Ledger). Shows all movements per account for a period range.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period-from": {"type": "str", "required": True, "description": "Start period YYYY-MM"},
                "--period-to": {"type": "str", "required": True, "description": "End period YYYY-MM"},
                "--account-id": {"type": "UUID", "required": False, "description": "Filter by specific account"}
            },
            "example": "fizko accounting general-ledger --company-id UUID --period-from 2026-01 --period-to 2026-12"
        },
        "accounting classified-balance": {
            "description": "Balance Clasificado (Classified Balance Sheet). Groups accounts by clasificacion_balance categories.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": False, "description": "Single period YYYY-MM (or use period-from/period-to)"},
                "--period-from": {"type": "str", "required": False, "description": "Start period YYYY-MM"},
                "--period-to": {"type": "str", "required": False, "description": "End period YYYY-MM"},
                "--cost-center-id": {"type": "UUID", "required": False, "description": "Filter by cost center"}
            },
            "example": "fizko accounting classified-balance --company-id UUID --period 2026-12"
        },
        "accounting rli-balance": {
            "description": "Balance RLI (Renta Liquida Imponible). Shows taxable income calculation for Operacion Renta.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period-from": {"type": "str", "required": True, "description": "Start period YYYY-MM"},
                "--period-to": {"type": "str", "required": True, "description": "End period YYYY-MM"}
            },
            "example": "fizko accounting rli-balance --company-id UUID --period-from 2026-01 --period-to 2026-12"
        },
        "accounting progress": {
            "description": "Accounting progress metrics. Shows how many documents are booked vs pending for a period.",
            "options": {
                "--company-id": {"type": "UUID", "required": True, "description": "Company UUID"},
                "--period": {"type": "str", "required": False, "description": "Period YYYY-MM"}
            },
            "example": "fizko accounting progress --company-id UUID --period 2026-01"
        }
    }
}
