"""Tax document commands."""

from typing import Optional

import typer

from fizko_cli import client

app = typer.Typer(help="Documentos tributarios, F29, resúmenes e indicadores.")


# ---------------------------------------------------------------------------
# Purchases / Sales / Contacts
# ---------------------------------------------------------------------------

@app.command()
def purchases(
    company: str = typer.Option(..., help="UUID de la empresa"),
    period_year: Optional[int] = typer.Option(None, help="Año (ej: 2026)"),
    period_month: Optional[int] = typer.Option(None, help="Mes (1-12)"),
    document_type: Optional[str] = typer.Option(None, help="Tipo de documento (ej: 33, 34)"),
    page: Optional[int] = typer.Option(None, help="Número de página"),
):
    """Listar documentos de compra."""
    data = client.get("/api/tax/purchases", {
        "company": company,
        "period_year": period_year,
        "period_month": period_month,
        "document_type": document_type,
        "page": page,
    })
    client.output(data)


@app.command()
def purchase(
    purchase_id: str = typer.Argument(help="UUID del documento de compra"),
):
    """Obtener detalle de un documento de compra."""
    data = client.get(f"/api/tax/purchases/{purchase_id}")
    client.output(data)


@app.command()
def sales(
    company: str = typer.Option(..., help="UUID de la empresa"),
    period_year: Optional[int] = typer.Option(None, help="Año (ej: 2026)"),
    period_month: Optional[int] = typer.Option(None, help="Mes (1-12)"),
    document_type: Optional[str] = typer.Option(None, help="Tipo de documento"),
    page: Optional[int] = typer.Option(None, help="Número de página"),
):
    """Listar documentos de venta."""
    data = client.get("/api/tax/sales", {
        "company": company,
        "period_year": period_year,
        "period_month": period_month,
        "document_type": document_type,
        "page": page,
    })
    client.output(data)


@app.command()
def sale(
    sale_id: str = typer.Argument(help="UUID del documento de venta"),
):
    """Obtener detalle de un documento de venta."""
    data = client.get(f"/api/tax/sales/{sale_id}")
    client.output(data)


@app.command()
def contacts(
    company: str = typer.Option(..., help="UUID de la empresa"),
    page: Optional[int] = typer.Option(None, help="Número de página"),
):
    """Listar contactos tributarios (proveedores/clientes)."""
    data = client.get("/api/tax/contacts", {
        "company": company,
        "page": page,
    })
    client.output(data)


# ---------------------------------------------------------------------------
# Unified documents
# ---------------------------------------------------------------------------

@app.command()
def documents(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: Optional[str] = typer.Option(None, help="Período YYYY-MM"),
    start_date: Optional[str] = typer.Option(None, help="Fecha inicio YYYY-MM-DD"),
    end_date: Optional[str] = typer.Option(None, help="Fecha fin YYYY-MM-DD"),
    limit: Optional[int] = typer.Option(None, help="Documentos por página"),
    offset: Optional[int] = typer.Option(None, help="Offset de paginación"),
):
    """Listar todos los documentos tributarios (compras + ventas + honorarios)."""
    data = client.get("/api/tax/documents", {
        "company_id": company_id,
        "period": period,
        "start_date": start_date,
        "end_date": end_date,
        "limit": limit,
        "offset": offset,
    })
    client.output(data)


@app.command()
def document(
    document_id: str = typer.Argument(help="UUID del documento"),
):
    """Obtener detalle de un documento tributario."""
    data = client.get(f"/api/tax/documents/{document_id}")
    client.output(data)


@app.command(name="documents-summary")
def documents_summary(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
):
    """Resumen de transacciones por tipo de documento (últimos 3 meses)."""
    data = client.get("/api/tax/documents/summary", {"company_id": company_id})
    client.output(data)


# ---------------------------------------------------------------------------
# Form 29
# ---------------------------------------------------------------------------

@app.command()
def f29(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    year: Optional[int] = typer.Option(None, help="Año"),
    page: Optional[int] = typer.Option(None, help="Número de página"),
):
    """Listar declaraciones F29 (locales + SII) agrupadas por período."""
    data = client.get("/api/tax/form29", {
        "company_id": company_id,
        "year": year,
        "page": page,
    })
    client.output(data)


@app.command(name="f29-export")
def f29_export(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    code: str = typer.Option(..., help="Código F29 a exportar"),
    period: str = typer.Option(..., help="Período YYYY-MM"),
):
    """Exportar documentos de un código F29 específico a CSV."""
    data = client.get("/api/tax/f29/export-csv", {
        "company_id": company_id,
        "code": code,
        "period": period,
    })
    client.output(data)


@app.command(name="f29-codes")
def f29_codes(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: str = typer.Option(..., help="Período YYYY-MM"),
):
    """Listar códigos F29 exportables."""
    data = client.get("/api/tax/f29/exportable-codes", {
        "company_id": company_id,
        "period": period,
    })
    client.output(data)


# ---------------------------------------------------------------------------
# Summaries
# ---------------------------------------------------------------------------

@app.command()
def summary(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: str = typer.Option(..., help="Período YYYY-MM"),
):
    """Resumen tributario para un período (desde F29)."""
    data = client.get("/api/tax/summary", {
        "company_id": company_id,
        "period": period,
    })
    client.output(data)


@app.command()
def iva(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: str = typer.Option(..., help="Período YYYY-MM"),
):
    """Resumen de IVA para un período."""
    data = client.get("/api/tax/summary/iva", {
        "company_id": company_id,
        "period": period,
    })
    client.output(data)


@app.command()
def timeline(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
):
    """Línea de tiempo tributaria (últimos 12 meses)."""
    data = client.get("/api/tax/summary/timeline", {
        "company_id": company_id,
    })
    client.output(data)


# ---------------------------------------------------------------------------
# Honorarios & DDJJ
# ---------------------------------------------------------------------------

@app.command()
def honorarios(
    company: str = typer.Option(..., help="UUID de la empresa"),
    period_year: Optional[int] = typer.Option(None, help="Año"),
    period_month: Optional[int] = typer.Option(None, help="Mes (1-12)"),
):
    """Listar boletas de honorarios."""
    data = client.get("/api/tax/honorarios", {
        "company": company,
        "period_year": period_year,
        "period_month": period_month,
    })
    client.output(data)


@app.command()
def ddjj(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    year: Optional[int] = typer.Option(None, help="Año tributario"),
):
    """Listar declaraciones juradas."""
    data = client.get("/api/tax/ddjj", {
        "company_id": company_id,
        "year": year,
    })
    client.output(data)


# ---------------------------------------------------------------------------
# Checkers
# ---------------------------------------------------------------------------

@app.command(name="checker-tributario")
def checker_tributario(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: str = typer.Option(..., help="Período YYYY-MM"),
):
    """Comparar libro de compras/ventas SII vs documentos contabilizados en Fizko."""
    data = client.get("/api/tax/checker-tributario", {
        "company_id": company_id,
        "period": period,
    })
    client.output(data)


@app.command(name="checker-impuestos")
def checker_impuestos(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: str = typer.Option(..., help="Período YYYY-MM"),
):
    """Comparar impuestos declarados en F29 vs contabilizados en Fizko."""
    data = client.get("/api/tax/checker-impuestos-mensuales", {
        "company_id": company_id,
        "period": period,
    })
    client.output(data)
