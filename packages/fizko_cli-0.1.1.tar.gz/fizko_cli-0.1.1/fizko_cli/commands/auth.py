"""Login / logout commands."""

import os
import time
import webbrowser
from typing import Optional

import typer
from rich.console import Console

from fizko_cli import client, config

app = typer.Typer(help="Autenticación.")
console = Console(stderr=True)

DEFAULT_BASE_URL = "http://localhost:8080"
DEFAULT_WEB_URL = "http://localhost:3000"


@app.command()
def login(
    api_url: Optional[str] = typer.Option(
        None,
        envvar="FIZKO_API_URL",
        help="URL de la API (default: https://api.fizko.ai)",
    ),
    web_url: Optional[str] = typer.Option(
        None,
        envvar="FIZKO_WEB_URL",
        help="URL del dashboard (default: https://admin.fizko.ai)",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="No abrir el navegador automáticamente",
    ),
):
    """Iniciar sesión con tu cuenta Fizko."""
    base_url = (api_url or DEFAULT_BASE_URL).rstrip("/")
    dashboard_url = (web_url or DEFAULT_WEB_URL).rstrip("/")

    # Check if already logged in
    saved = config.load()
    if saved and saved.get("api_key"):
        console.print(f"Ya autenticado como [bold]{saved.get('email', '?')}[/bold].")
        if not typer.confirm("¿Quieres iniciar sesión con otra cuenta?", default=False):
            raise typer.Exit()

    # 1. Initiate device code flow
    console.print("Iniciando autenticación...\n")
    resp = client.raw_post(f"{base_url}/api/auth/cli/initiate")
    device_code = resp["device_code"]
    user_code = resp["user_code"]
    poll_interval = resp.get("poll_interval", 2)
    expires_in = resp.get("expires_in", 600)

    # 2. Show code and open browser
    auth_url = f"{dashboard_url}/cli-auth?code={user_code}"

    console.print(f"Tu código de verificación: [bold green]{user_code}[/bold green]\n")
    console.print(f"Abriendo: {auth_url}\n")

    if not no_browser:
        webbrowser.open(auth_url)
    else:
        console.print("Abre este link en tu navegador para autorizar.")

    console.print("Esperando autorización...", end="")

    # 3. Poll until authorized or expired
    deadline = time.time() + expires_in
    while time.time() < deadline:
        time.sleep(poll_interval)
        poll_resp = client.raw_get(
            f"{base_url}/api/auth/cli/poll",
            params={"device_code": device_code},
        )
        poll_status = poll_resp.get("status")

        if poll_status == "authorized":
            api_key = poll_resp["api_key"]
            user_email = poll_resp.get("user_email", "")

            # Save credentials
            path = config.save(
                api_key=api_key,
                email=user_email,
                base_url=base_url,
            )

            console.print(f"\n\n[bold green]Autenticado como {user_email}[/bold green]")
            console.print(f"Credenciales guardadas en {path}")
            raise typer.Exit()

        if poll_status == "expired":
            console.print("\n\n[bold red]Código expirado.[/bold red] Intenta de nuevo con: fizko login")
            raise typer.Exit(code=1)

        console.print(".", end="")

    console.print("\n\n[bold red]Tiempo agotado.[/bold red] Intenta de nuevo con: fizko login")
    raise typer.Exit(code=1)


@app.command()
def logout():
    """Cerrar sesión y eliminar credenciales guardadas."""
    saved = config.load()
    if not saved:
        console.print("No hay sesión activa.")
        raise typer.Exit()

    config.clear()
    console.print(f"Sesión de [bold]{saved.get('email', '?')}[/bold] cerrada.")


@app.command()
def status():
    """Mostrar estado de autenticación."""
    saved = config.load()
    env_key = os.environ.get("FIZKO_API_KEY")

    if env_key:
        console.print(f"Autenticado via FIZKO_API_KEY (env var)")
    elif saved and saved.get("api_key"):
        console.print(f"Autenticado como [bold]{saved.get('email', '?')}[/bold]")
        console.print(f"API: {saved.get('base_url', DEFAULT_BASE_URL)}")
    else:
        console.print("No autenticado. Ejecuta: fizko login")
