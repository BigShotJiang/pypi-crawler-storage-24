"""Company commands."""

from typing import Optional

import typer

from fizko_cli import client

app = typer.Typer(help="Empresas y sesiones.")


@app.command()
def list(
    page: Optional[int] = typer.Option(None, help="Número de página"),
):
    """Listar empresas del usuario."""
    params = {"page": page}
    data = client.get("/api/companies", params)
    client.output(data)


@app.command()
def get(
    company_id: str = typer.Argument(help="UUID de la empresa"),
):
    """Obtener detalle de una empresa."""
    data = client.get(f"/api/companies/{company_id}")
    client.output(data)
