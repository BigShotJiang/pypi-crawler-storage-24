"""Accounting commands."""

from typing import Optional

import typer

from fizko_cli import client

app = typer.Typer(help="Contabilidad: plan de cuentas, asientos, reportes financieros.")


# ---------------------------------------------------------------------------
# Chart of accounts
# ---------------------------------------------------------------------------

@app.command()
def accounts(
    company: str = typer.Option(..., help="UUID de la empresa"),
    tree: bool = typer.Option(False, help="Devolver en estructura de árbol"),
):
    """Listar plan de cuentas."""
    params = {"company": company}
    if tree:
        params["tree"] = "1"
    data = client.get("/api/accounting/accounts", params)
    client.output(data)


# ---------------------------------------------------------------------------
# Journal entries
# ---------------------------------------------------------------------------

@app.command(name="journal-entries")
def journal_entries(
    company: str = typer.Option(..., help="UUID de la empresa"),
    period: Optional[str] = typer.Option(None, help="Período YYYY-MM"),
    limit: Optional[int] = typer.Option(None, help="Límite de resultados"),
    offset: Optional[int] = typer.Option(None, help="Offset de paginación"),
):
    """Listar asientos contables."""
    data = client.get("/api/accounting/journal-entries", {
        "company": company,
        "period": period,
        "limit": limit,
        "offset": offset,
    })
    client.output(data)


@app.command(name="journal-entry")
def journal_entry(
    entry_id: str = typer.Argument(help="UUID del asiento contable"),
):
    """Obtener detalle de un asiento contable."""
    data = client.get(f"/api/accounting/journal-entries/{entry_id}")
    client.output(data)


# ---------------------------------------------------------------------------
# Financial reports
# ---------------------------------------------------------------------------

@app.command(name="balance-report")
def balance_report(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period_from: str = typer.Option(..., help="Período inicio YYYY-MM"),
    period_to: str = typer.Option(..., help="Período fin YYYY-MM"),
    cost_center_id: Optional[str] = typer.Option(None, help="UUID centro de costo"),
):
    """Balance de 8 columnas."""
    data = client.get("/api/accounting/balance-report", {
        "company_id": company_id,
        "period_from": period_from,
        "period_to": period_to,
        "cost_center_id": cost_center_id,
    })
    client.output(data)


@app.command(name="income-statement")
def income_statement(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period_from: str = typer.Option(..., help="Período inicio YYYY-MM"),
    period_to: str = typer.Option(..., help="Período fin YYYY-MM"),
    cost_center_id: Optional[str] = typer.Option(None, help="UUID centro de costo"),
):
    """Estado de resultados (EERR)."""
    data = client.get("/api/accounting/reports/income-statement", {
        "company_id": company_id,
        "period_from": period_from,
        "period_to": period_to,
        "cost_center_id": cost_center_id,
    })
    client.output(data)


@app.command(name="general-journal")
def general_journal(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: str = typer.Option(..., help="Período YYYY-MM"),
    page: Optional[int] = typer.Option(None, help="Número de página"),
    page_size: Optional[int] = typer.Option(None, help="Tamaño de página"),
):
    """Libro diario."""
    data = client.get("/api/accounting/reports/general-journal", {
        "company_id": company_id,
        "period": period,
        "page": page,
        "page_size": page_size,
    })
    client.output(data)


@app.command(name="general-ledger")
def general_ledger(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period_from: str = typer.Option(..., help="Período inicio YYYY-MM"),
    period_to: str = typer.Option(..., help="Período fin YYYY-MM"),
    account_id: Optional[str] = typer.Option(None, help="UUID de cuenta específica"),
):
    """Libro mayor."""
    data = client.get("/api/accounting/reports/general-ledger", {
        "company_id": company_id,
        "period_from": period_from,
        "period_to": period_to,
        "account_id": account_id,
    })
    client.output(data)


@app.command(name="classified-balance")
def classified_balance(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: Optional[str] = typer.Option(None, help="Período YYYY-MM (o usar period_from/period_to)"),
    period_from: Optional[str] = typer.Option(None, help="Período inicio YYYY-MM"),
    period_to: Optional[str] = typer.Option(None, help="Período fin YYYY-MM"),
    cost_center_id: Optional[str] = typer.Option(None, help="UUID centro de costo"),
):
    """Balance clasificado."""
    data = client.get("/api/accounting/reports/classified-balance", {
        "company_id": company_id,
        "period": period,
        "period_from": period_from,
        "period_to": period_to,
        "cost_center_id": cost_center_id,
    })
    client.output(data)


@app.command(name="rli-balance")
def rli_balance(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period_from: str = typer.Option(..., help="Período inicio YYYY-MM"),
    period_to: str = typer.Option(..., help="Período fin YYYY-MM"),
):
    """Balance RLI (Renta Líquida Imponible)."""
    data = client.get("/api/accounting/reports/rli-balance", {
        "company_id": company_id,
        "period_from": period_from,
        "period_to": period_to,
    })
    client.output(data)


# ---------------------------------------------------------------------------
# Progress
# ---------------------------------------------------------------------------

@app.command()
def progress(
    company_id: str = typer.Option(..., help="UUID de la empresa"),
    period: Optional[str] = typer.Option(None, help="Período YYYY-MM"),
):
    """Avance contable de la empresa."""
    data = client.get("/api/accounting/progress", {
        "company_id": company_id,
        "period": period,
    })
    client.output(data)
