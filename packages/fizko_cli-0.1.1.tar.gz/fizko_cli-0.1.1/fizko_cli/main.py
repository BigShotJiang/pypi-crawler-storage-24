"""Fizko CLI - Tax and accounting data for Chilean businesses."""

import json
from typing import Optional

import typer

from fizko_cli import client
from fizko_cli.commands import auth, companies, tax, accounting
from fizko_cli.schema import SCHEMA

app = typer.Typer(
    name="fizko",
    help=(
        "CLI for the Fizko API. Query tax documents, accounting reports, and company data.\n\n"
        "All commands output JSON to stdout. Errors go to stderr as JSON.\n\n"
        "Quick start:\n\n"
        "  fizko login                              # authenticate\n\n"
        "  fizko companies list                     # get company UUIDs\n\n"
        "  fizko tax purchases --company <uuid>     # query data\n\n"
        "  fizko schema                             # show all commands as JSON (for AI agents)"
    ),
    no_args_is_help=True,
)


def _compact_callback(value: bool) -> None:
    if value:
        client.set_compact(True)


@app.callback()
def main(
    compact: bool = typer.Option(
        False,
        "--compact",
        help="Output JSON without indentation",
        is_eager=True,
        callback=_compact_callback,
    ),
):
    """Fizko CLI"""
    pass


@app.command()
def schema():
    """Print machine-readable schema of all commands as JSON. Designed for AI agents to discover available operations in a single call."""
    client.output(SCHEMA)


# Auth commands at top level
app.command(name="login")(auth.login)
app.command(name="logout")(auth.logout)
app.command(name="status")(auth.status)

# Data commands as sub-groups
app.add_typer(companies.app, name="companies", help="List and inspect companies.")
app.add_typer(tax.app, name="tax", help="Tax documents, F29, summaries, checkers.")
app.add_typer(accounting.app, name="accounting", help="Chart of accounts, journal entries, financial reports.")


if __name__ == "__main__":
    app()
