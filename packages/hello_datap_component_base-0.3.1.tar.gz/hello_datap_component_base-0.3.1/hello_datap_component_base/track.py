"""
数据跟踪模块 - 上报数据处理跟踪信息到 MNS 顺序队列

环境变量：
    DATA_TRACK_PIPELINE_ID: 流水线 ID
    DATA_TRACK_PIPELINE_INSTANCE_ID: 流水线实例 ID
    DATA_TRACK_NODE_ID: 组件 ID
    DATA_TRACK_NODE_TASK_ID: 任务 ID
    DATA_TRACK_COMPONENT_VERSION: 组件版本号
    DATA_TRACK_PRIORITY: 优先级 (1=低 2=中 3=高 4=紧急)
    DATA_TRACK_EXECUTOR: 执行人
    DATA_TRACK_RUN_TYPE: 运行类型 (1=手动 2=定时 3=流式)
    DATA_TRACK_MNS_QUEUE_NAME: 跟踪队列名称（默认 aiinfra-data-process-component-bag-track）

使用方法：
    from hello_datap_component_base import track

    track.log(data=bag_path)                  # 任务开始（插入记录）
    track.log(data=bag_path, status=1)        # 任务成功（更新记录）
    track.log(data=bag_path, status=2)        # 任务失败（更新记录）
"""

import json
import os
import time
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional
from urllib.parse import urlencode, quote

logger = logging.getLogger(__name__)

DEFAULT_TRACK_QUEUE = "aiinfra-data-process-component-bag-track"

_track_queue = None
_track_initialized = False
_Message = None


def _safe_int(value, default=None):
    if value is None:
        return default
    try:
        return int(value)
    except (ValueError, TypeError):
        return default


def _init_track_queue():
    """初始化跟踪 MNS 队列（延迟加载，仅初始化一次）"""
    global _track_queue, _track_initialized, _Message

    if _track_initialized:
        return

    _track_initialized = True

    try:
        from mns.account import Account
        from mns.queue import Message

        _Message = Message

        endpoint = os.environ.get('MNS_ENDPOINT')
        access_key_id = os.environ.get('MNS_ACCESS_KEY_ID')
        access_key_secret = os.environ.get('MNS_ACCESS_KEY_SECRET')

        if not all([endpoint, access_key_id, access_key_secret]):
            logger.warning("MNS 认证信息不完整，数据跟踪将不可用")
            return

        queue_name = os.environ.get('DATA_TRACK_MNS_QUEUE_NAME', DEFAULT_TRACK_QUEUE)

        account = Account(endpoint, access_key_id, access_key_secret)
        _track_queue = account.get_queue(queue_name)
        logger.info(f"数据跟踪队列初始化成功: {queue_name}")

    except ImportError:
        logger.warning("未安装阿里云 MNS SDK，数据跟踪将不可用。请安装: pip install aliyun-mns")
    except Exception as e:
        logger.error(f"初始化数据跟踪队列失败: {e}")


def _is_retryable(e: Exception) -> bool:
    """判断异常是否可重试"""
    s = str(e) + type(e).__name__
    keywords = [
        'NetworkException', 'NetWorkException',
        'Connection reset', 'timeout', 'ConnectionError',
        'Errno 104', 'Errno 111', 'Errno 110',
        'referenced before assignment',
    ]
    return any(kw in s for kw in keywords)


def _send_track_message(message_body: str, message_group_id: str) -> bool:
    """
    发送跟踪消息到 MNS 顺序队列

    Args:
        message_body: JSON 格式的消息字符串
        message_group_id: 顺序队列的消息分组标识，使用 data 值
    """
    global _track_queue, _Message

    _init_track_queue()

    if not _track_queue or not _Message:
        return False

    max_retries = int(os.environ.get('MNS_MAX_RETRIES', 3))
    retry_delay = float(os.environ.get('MNS_RETRY_DELAY', 1.0))
    retry_backoff = float(os.environ.get('MNS_RETRY_BACKOFF', 2.0))

    delay = retry_delay

    for attempt in range(max_retries + 1):
        try:
            msg = _Message(message_body)
            # 顺序队列需要 MessageGroupId，确保同一 data 的消息按序处理
            try:
                msg.message_group_id = message_group_id
            except AttributeError:
                pass

            _track_queue.send_message(msg)

            if attempt > 0:
                logger.info(f"跟踪消息已发送（第 {attempt + 1} 次尝试）")
            else:
                logger.debug("跟踪消息已发送")
            return True

        except Exception as e:
            if not _is_retryable(e):
                logger.error(f"发送跟踪消息失败（不可重试）: {e}")
                return False

            if attempt < max_retries:
                logger.warning(
                    f"发送跟踪消息失败（第 {attempt + 1} 次）: {e}，"
                    f"{delay:.1f}s 后重试..."
                )
                time.sleep(delay)
                delay *= retry_backoff
            else:
                logger.error(f"发送跟踪消息失败（已重试 {max_retries} 次）: {e}")

    return False


def _read_env_context() -> dict:
    """读取环境变量中的跟踪上下文"""
    return {
        "pipeline_id": _safe_int(os.environ.get("DATA_TRACK_PIPELINE_ID")),
        "pipeline_instance_id": _safe_int(os.environ.get("DATA_TRACK_PIPELINE_INSTANCE_ID")),
        "node_id": os.environ.get("DATA_TRACK_NODE_ID"),
        "node_task_id": os.environ.get("DATA_TRACK_NODE_TASK_ID"),
        "component_version": os.environ.get("DATA_TRACK_COMPONENT_VERSION"),
        "priority": _safe_int(os.environ.get("DATA_TRACK_PRIORITY")),
        "executor": os.environ.get("DATA_TRACK_EXECUTOR"),
        "run_type": _safe_int(os.environ.get("DATA_TRACK_RUN_TYPE")),
    }


def log(
    data: str,
    data_type: str = "bag",
    status: Optional[int] = None,
    **kwargs,
):
    """
    上报数据跟踪信息到 MNS 顺序队列

    两段式处理（通过 data + data_type + pipeline_instance_id + node_task_id 判断插入/更新）：
    - 第一次调用（任务开始）：track.log(data=bag_path)，插入新记录
    - 第二次调用（任务完成）：track.log(data=bag_path, status=1)，更新记录

    Args:
        data: 数据标识（如 bag 路径、clip 路径），必填
        data_type: 数据类型，枚举值：bag、clip，默认 "bag"
        status: 状态，1=成功 2=失败，None 表示第一次调用（不设置状态）
        **kwargs: 可覆盖或补充任意字段，如 pipeline_id=99, executor="lisi"
    """
    try:
        now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        env = _read_env_context()

        if status is None:
            # ---- 第一次发送（任务开始）：全量字段 ----
            message = {
                "data": data,
                "data_type": data_type,
                "datetime": now,
            }
            for key, value in env.items():
                if value is not None:
                    message[key] = value
        else:
            # ---- 第二次发送（任务完成）：四元组 + status + datetime ----
            message = {
                "data": data,
                "data_type": data_type,
                "status": status,
                "datetime": now,
            }
            if env["pipeline_instance_id"] is not None:
                message["pipeline_instance_id"] = env["pipeline_instance_id"]
            if env["node_task_id"] is not None:
                message["node_task_id"] = env["node_task_id"]

        # kwargs 优先级最高，可覆盖以上所有字段
        message.update(kwargs)

        message_body = json.dumps(message, ensure_ascii=False)

        # 使用 data 作为 MessageGroupId，保证同一数据的消息按序处理
        success = _send_track_message(message_body, message_group_id=data)

        if success:
            status_desc = f", status={status}" if status is not None else ""
            logger.info(f"数据跟踪已上报: data={data}{status_desc}")
        else:
            logger.warning(f"数据跟踪上报失败: data={data}")

    except Exception as e:
        # track.log 绝不能影响用户的业务逻辑
        logger.error(f"数据跟踪异常: {e}", exc_info=True)


def _get_api_base_url() -> Optional[str]:
    """获取数据处理平台 API 地址"""
    url = os.environ.get('DATA_PROCESS_API_URL')
    if not url:
        logger.warning("未设置 DATA_PROCESS_API_URL 环境变量，数据跟踪查询不可用")
        return None
    return url.rstrip('/')


def _skip_ssl_verify() -> bool:
    return os.environ.get('SKIP_SSL_VERIFY', '').lower() in ('true', '1', 'yes')


def get_summary(data: str, **kwargs) -> Optional[List[Dict[str, Any]]]:
    """
    查询数据跟踪摘要

    根据数据标识查询该数据经过了哪些流水线、哪些节点、哪些版本及最终状态。

    Args:
        data: 数据标识（如 bag 路径），精确匹配

    Returns:
        成功返回跟踪记录列表，失败返回 None
    """
    try:
        import requests
    except ImportError:
        logger.error("未安装 requests，请安装: pip install requests")
        return None

    base_url = _get_api_base_url()
    if not base_url:
        return None

    try:
        url = f"{base_url}/open-api/v1/data-track/summary"
        params = {"data": data}
        params.update(kwargs)
        resp = requests.get(url, params=params, timeout=30, verify=not _skip_ssl_verify())
        resp.raise_for_status()
        body = resp.json()

        if body.get("code") == 200:
            return body.get("data")
        else:
            logger.warning(f"查询数据跟踪摘要失败: {body.get('message', 'unknown error')}")
            return None
    except Exception as e:
        logger.error(f"查询数据跟踪摘要异常: {e}", exc_info=True)
        return None


def check_processed(
    data: str,
    expand: Optional[Dict[str, Any]] = None,
    **kwargs
) -> tuple:
    """
    查询数据是否已处理

    根据数据标识 + 流水线 + 节点 + 版本精确查询，判断该数据在指定节点版本下是否处理成功。
    pipelineId、nodeId、componentVersion 从环境变量自动获取。

    Args:
        data: 数据标识（如 bag 路径）
        expand: 可选，扩展字段查询条件（dict），如 {"city": "shanghai"}

    Returns:
        (processed, data_info) 元组：
        - processed: bool，是否已处理成功
        - data_info: dict 或 None，最新的成功记录详情
        查询失败时返回 (False, None)
    """
    try:
        import requests
    except ImportError:
        logger.error("未安装 requests，请安装: pip install requests")
        return False, None

    base_url = _get_api_base_url()
    if not base_url:
        return False, None

    pipeline_id = os.environ.get('DATA_TRACK_PIPELINE_ID')
    node_id = os.environ.get('DATA_TRACK_NODE_ID')
    component_version = os.environ.get('DATA_TRACK_COMPONENT_VERSION')

    if not all([pipeline_id, node_id, component_version]):
        logger.warning(
            "环境变量不完整，check_processed 需要: "
            "DATA_TRACK_PIPELINE_ID, DATA_TRACK_NODE_ID, DATA_TRACK_COMPONENT_VERSION"
        )
        return False, None

    try:
        url = f"{base_url}/open-api/v1/data-track/check-processed"
        params: Dict[str, str] = {
            "data": data,
            "pipelineId": pipeline_id,
            "nodeId": node_id,
            "componentVersion": component_version,
        }
        if expand is not None:
            params["expand"] = json.dumps(expand, ensure_ascii=False)

        params.update(kwargs)

        resp = requests.get(url, params=params, timeout=30, verify=not _skip_ssl_verify())
        resp.raise_for_status()
        body = resp.json()

        if body.get("code") == 200:
            result = body.get("data", {})
            return result.get("processed", False), result.get("data_info")
        else:
            logger.warning(f"查询数据是否已处理失败: {body.get('message', 'unknown error')}")
            return False, None
    except Exception as e:
        logger.error(f"查询数据是否已处理异常: {e}", exc_info=True)
        return False, None
