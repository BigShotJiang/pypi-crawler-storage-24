"""
工具函数模块

提供环境变量提取、bag 路径解析等通用工具方法。

使用方法：
    from hello_datap_component_base import tools

    env_vars = tools.extract_specific_env_vars()
    vehicle_id = tools.get_vehicle_id_from_bag("oss://bucket/.../1_002_20260119-151708_0.db3")
    date = tools.get_date_from_bag("oss://bucket/.../1_002_20260119-151708_0.db3")
    package = tools.get_package_name_from_bag("oss://bucket/.../1_002_20260119-151708/1_002_20260119-151708_0.db3")
"""

import os
import re
import logging
from pathlib import Path, PurePosixPath
from typing import Dict

logger = logging.getLogger(__name__)


def extract_specific_env_vars() -> Dict[str, str]:
    """
    从 os.environ 中提取框架相关的环境变量

    Returns:
        包含指定环境变量的字典
    """
    env_vars = {}

    # MNS 相关配置
    env_vars["MNS_ENDPOINT"] = os.environ.get("MNS_ENDPOINT", "")
    env_vars["MNS_ACCESS_KEY_ID"] = os.environ.get("MNS_ACCESS_KEY_ID", "")
    env_vars["MNS_ACCESS_KEY_SECRET"] = os.environ.get("MNS_ACCESS_KEY_SECRET", "")
    env_vars["MNS_QUEUE_NAME"] = os.environ.get("MNS_QUEUE_NAME", "")

    # OSS 日志配置
    oss_endpoint = os.environ.get("OSS_ENDPOINT_FOR_LOG", "")
    if not oss_endpoint and (oss_endpoint_raw := os.environ.get("OSS_ENDPOINT")):
        oss_endpoint = f"https://{oss_endpoint_raw}"
    env_vars["OSS_ENDPOINT_FOR_LOG"] = oss_endpoint

    env_vars["OSS_BUCKET_NAME_FOR_LOG"] = os.environ.get("OSS_BUCKET_NAME_FOR_LOG", "")
    env_vars["OSS_LOG_PATH_PREFIX"] = os.environ.get("OSS_LOG_PATH_PREFIX", "")

    oss_access_key_id = os.environ.get("OSS_ACCESS_KEY_ID_FOR_LOG")
    oss_access_key_secret = os.environ.get("OSS_ACCESS_KEY_SECRET_FOR_LOG")
    if oss_access_key_id and oss_access_key_id.strip():
        env_vars["OSS_ACCESS_KEY_ID_FOR_LOG"] = oss_access_key_id.strip()
    if oss_access_key_secret and oss_access_key_secret.strip():
        env_vars["OSS_ACCESS_KEY_SECRET_FOR_LOG"] = oss_access_key_secret.strip()

    # 数据跟踪环境变量
    env_vars["DATA_TRACK_MNS_QUEUE_NAME"] = os.environ.get("DATA_TRACK_MNS_QUEUE_NAME", "")
    env_vars["DATA_TRACK_PIPELINE_ID"] = os.environ.get("DATA_TRACK_PIPELINE_ID", "")
    env_vars["DATA_TRACK_PIPELINE_INSTANCE_ID"] = os.environ.get("DATA_TRACK_PIPELINE_INSTANCE_ID", "")
    env_vars["DATA_TRACK_COMPONENT_VERSION"] = os.environ.get("DATA_TRACK_COMPONENT_VERSION", "")
    env_vars["DATA_TRACK_PRIORITY"] = os.environ.get("DATA_TRACK_PRIORITY", "")
    env_vars["DATA_TRACK_EXECUTOR"] = os.environ.get("DATA_TRACK_EXECUTOR", "")
    env_vars["DATA_TRACK_RUN_TYPE"] = os.environ.get("DATA_TRACK_RUN_TYPE", "")
    env_vars["DATA_TRACK_NODE_ID"] = os.environ.get("DATA_TRACK_NODE_ID", "")
    env_vars["DATA_TRACK_NODE_TASK_ID"] = os.environ.get("DATA_TRACK_NODE_TASK_ID", "")

    # 数据平台接口
    env_vars["BAG_DATA_APP_KEY"] = os.environ.get("BAG_DATA_APP_KEY", "")
    env_vars["BAG_DATA_API_URL"] = os.environ.get("BAG_DATA_API_URL", "")
    env_vars["DATA_PROCESS_API_URL"] = os.environ.get("DATA_PROCESS_API_URL", "")

    return env_vars


def get_vehicle_id_from_bag(bag_path: str) -> str:
    """
    从 bag 路径中提取 vehicle_id

    支持的路径格式：
    - oss://bucket/path/1_002/1_002_20260119-151708/1_002_20260119-151708_0.db3
    - s3://bucket/path/1_002/1_002_20260119-151708/1_002_20260119-151708_0.db3
    - /local/path/1_002_20260119-151708_0.db3

    提取规则：
    1. 从文件名提取：1_002_20260119-151708_0.db3 -> 1_002
    2. 文件名格式：{vehicle_id}_{date}-{time}_{index}.db3

    Returns:
        vehicle_id 字符串，如 "1_002"，提取失败返回空字符串
    """
    try:
        filename = Path(bag_path).stem

        # 匹配 vehicle_id：数字_数字（如 1_002, 1_022）
        match = re.match(r'^(\d+_\d+)_', filename)
        if match:
            return match.group(1)

        # 回退：从路径目录中查找独立的 vehicle_id 段
        parts = bag_path.replace("\\", "/").split("/")
        for part in parts:
            if re.match(r'^\d+_\d+$', part):
                return part

        return ""
    except Exception as e:
        logger.error(f"提取 vehicle_id 失败: {bag_path}, 错误: {e}")
        return ""


def get_date_from_bag(bag_path: str) -> str:
    """
    从 bag 路径中提取日期（YYYYMMDD）

    文件名格式：1_002_20251219-164135_0.db3 -> 20251219

    Returns:
        日期字符串 "YYYYMMDD"，提取失败返回空字符串
    """
    try:
        stem = Path(bag_path).stem
        match = re.match(r"^\d+_\d+_(\d{8})", stem)
        if match:
            return match.group(1)
        return ""
    except Exception as e:
        logger.error(f"提取日期失败: {bag_path}, 错误: {e}")
        return ""


def get_package_name_from_bag(bag_path: str) -> str:
    """
    从 bag 路径中提取 package 名称（文件的上一级目录名）

    示例：
    - bag_path: oss://bucket/.../1_063_20260120-100608/1_063_20260120-100608_0.db3
    - package: 1_063_20260120-100608

    Returns:
        package 名称，如 "1_063_20260120-100608"，提取失败返回空字符串
    """
    try:
        parent_dir = Path(bag_path).parent.name
        return parent_dir
    except Exception as e:
        logger.error(f"提取 package 名称失败: {bag_path}, 错误: {e}")
        return ""


def extract_filename(file_path: str) -> str:
    """
    从路径中提取文件名（不含扩展名）

    支持 oss://、s3:// 等远程路径和本地路径。

    Args:
        file_path: 完整文件路径

    Returns:
        文件名（不含扩展名）
    """
    return PurePosixPath(file_path).stem
