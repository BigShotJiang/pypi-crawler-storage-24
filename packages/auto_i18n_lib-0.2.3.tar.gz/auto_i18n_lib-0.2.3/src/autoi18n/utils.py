import json
import os
import re
import tempfile
from typing import Any, Dict, Tuple


WHITESPACE_ONLY_RE = re.compile(r"^\s*$")
NUMBER_LIKE_RE = re.compile(r"^[\d\s\.,:/\-]+$")
HEX_LIKE_RE = re.compile(r"^[A-Fa-f0-9\-]{8,}$")
PURE_LATIN_TECH_RE = re.compile(r"^[A-Za-z0-9_\-\s\.:/@#%+=]+$")


def split_preserve_whitespace(text: str) -> Tuple[str, str, str]:
    match = re.match(r"^(\s*)(.*?)(\s*)$", text, flags=re.DOTALL)
    if not match:
        return "", text, ""
    return match.group(1), match.group(2), match.group(3)


def should_translate(text: str, attr_name: str = None) -> bool:
    if text is None:
        return False

    raw = text
    text = text.strip()

    if not text:
        return False

    if WHITESPACE_ONLY_RE.fullmatch(raw):
        return False

    if text.isdigit():
        return False

    if NUMBER_LIKE_RE.fullmatch(text):
        return False

    if HEX_LIKE_RE.fullmatch(text):
        return False

    if PURE_LATIN_TECH_RE.fullmatch(text):
        if attr_name in {"placeholder", "title", "alt", "aria-label", "value"}:
            words = text.split()
            if len(words) >= 2:
                return True
        return False

    return True


def safe_json_load(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def safe_json_save(path: str, data: Dict[str, Any]) -> None:
    directory = os.path.dirname(path) or "."
    os.makedirs(directory, exist_ok=True)

    fd, tmp_path = tempfile.mkstemp(
        prefix=".tmp_autoi18n_",
        suffix=".json",
        dir=directory,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, sort_keys=True)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, path)
    finally:
        if os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def extract_json(text: str):
    text = text.strip()
    if not text:
        raise ValueError("Empty model response")

    try:
        return json.loads(text)
    except Exception:
        pass

    start_obj = text.find("{")
    end_obj = text.rfind("}")
    if start_obj != -1 and end_obj != -1 and end_obj > start_obj:
        candidate = text[start_obj:end_obj + 1]
        try:
            return json.loads(candidate)
        except Exception:
            pass

    start_arr = text.find("[")
    end_arr = text.rfind("]")
    if start_arr != -1 and end_arr != -1 and end_arr > start_arr:
        candidate = text[start_arr:end_arr + 1]
        return json.loads(candidate)

    raise ValueError("JSON not found in model response")