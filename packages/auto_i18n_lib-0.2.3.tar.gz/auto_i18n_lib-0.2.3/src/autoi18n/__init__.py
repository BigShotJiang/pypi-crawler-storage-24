# src/autoi18n/__init__.py
from .translator import Translator

__all__ = ["Translator"]
__version__ = "0.2.3"