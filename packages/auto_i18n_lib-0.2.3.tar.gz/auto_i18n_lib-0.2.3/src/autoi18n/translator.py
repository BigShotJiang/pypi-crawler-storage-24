import json
import os
import threading
import time
from typing import Callable, Dict, List, Optional, Tuple

from openai import OpenAI

from .html_parser import SimpleHTMLTranslator, collect_translatable_items
from .page_registry import PageRegistry
from .utils import extract_json, safe_json_load, safe_json_save, should_translate, split_preserve_whitespace


class Translator:
    def __init__(
        self,
        cache_dir: str = "./translations",
        api_key: Optional[str] = None,
        source_lang: Optional[str] = None,
        model: str = "gpt-4o-mini",
    ):
        self.source_lang = source_lang or os.getenv("SOURCE_LANG", "ru")
        self.cache_dir = cache_dir
        self.client = OpenAI(api_key=api_key or os.getenv("OPENAI_API_KEY"))
        self.model = model

        self._registry = PageRegistry()
        self._lock = threading.RLock()

    def _legacy_file_path(self, page_name: str, lang: str) -> str:
        return os.path.join(self.cache_dir, f"{page_name}.{lang}.json")

    def _file_path(self, lang: str) -> str:
        return os.path.join(self.cache_dir, f"{lang}.json")

    def _load_storage(self, page_name: str, lang: str) -> Dict[str, str]:
        target_path = self._file_path(lang)
        cache = safe_json_load(target_path)

        legacy_path = self._legacy_file_path(page_name, lang)
        legacy_cache = safe_json_load(legacy_path)

        if legacy_cache:
            merged = dict(cache)
            for key, value in legacy_cache.items():
                if key not in merged and isinstance(value, str):
                    merged[key] = value
            if merged != cache:
                safe_json_save(target_path, merged)
            return merged

        return cache

    def _save_storage(self, lang: str, cache: Dict[str, str]) -> None:
        safe_json_save(self._file_path(lang), cache)

    def _build_single_prompt(self, text: str, target_lang: str, prompt_type: str = "normal") -> str:
        if prompt_type == "button":
            return (
                f"Translate the UI button label from {self.source_lang} to {target_lang}. "
                f"Return only the translation, without explanations.\n\n{text}"
            )

        if prompt_type == "attr":
            return (
                f"Translate the UI attribute text from {self.source_lang} to {target_lang}. "
                f"Return only the translation, without explanations.\n\n{text}"
            )

        return (
            f"Translate the text from {self.source_lang} to {target_lang}. "
            f"Return only the translation, without explanations.\n\n{text}"
        )

    def _translate_via_api(self, prompt: str) -> str:
        response = self.client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
        )
        return (response.choices[0].message.content or "").strip()

    def _translate_single(self, text: str, target_lang: str, prompt_type: str = "normal") -> str:
        prompt = self._build_single_prompt(text, target_lang, prompt_type)
        translated = self._translate_via_api(prompt)
        return translated or text

    def _translate_batch(self, items: List[Tuple[str, str]], target_lang: str) -> Dict[str, str]:
        if not items:
            return {}

        payload = [
            {"id": i, "text": text, "kind": prompt_type}
            for i, (text, prompt_type) in enumerate(items, start=1)
        ]

        prompt = (
            f"Translate each item from {self.source_lang} to {target_lang}.\n"
            f"Rules:\n"
            f"- Return STRICT JSON object only.\n"
            f"- Format: {{\"items\": [{{\"id\": 1, \"translated\": \"...\"}}]}}\n"
            f"- Keep meaning precise.\n"
            f"- For buttons and UI labels keep text concise.\n"
            f"- Do not omit any item.\n"
            f"- Do not add comments.\n\n"
            f"Input JSON:\n{json.dumps(payload, ensure_ascii=False)}"
        )

        raw = self._translate_via_api(prompt)
        parsed = extract_json(raw)

        result: Dict[str, str] = {}
        translated_items = parsed.get("items", []) if isinstance(parsed, dict) else []

        by_id = {}
        for item in translated_items:
            if not isinstance(item, dict):
                continue
            item_id = item.get("id")
            translated = item.get("translated")
            if isinstance(item_id, int) and isinstance(translated, str):
                by_id[item_id] = translated.strip()

        for idx, (text, _) in enumerate(items, start=1):
            result[text] = by_id.get(idx) or text

        return result

    def register_page(
        self,
        page_name: str,
        html_getter: Callable[..., str],
        target_langs: List[str],
        context: Optional[Dict] = None,
    ) -> None:
        self._registry.register_page(
            page_name=page_name,
            html_getter=html_getter,
            target_langs=target_langs,
            context=context,
        )

    def _render_registered_page_html(self, page_name: str) -> str:
        page = self._registry.get_page(page_name)
        context = page.context or {}

        if context:
            html = page.html_getter(**context)
        else:
            html = page.html_getter()

        if not isinstance(html, str):
            raise ValueError(f"html_getter for page '{page_name}' must return str")

        return html

    def scan_page(
        self,
        page_name: str,
        target_lang: str,
    ) -> List[Tuple[str, str]]:
        if not target_lang or target_lang == self.source_lang:
            return []

        html = self._render_registered_page_html(page_name)
        items = collect_translatable_items(html)
        cache = self._load_storage(page_name, target_lang)

        missing: List[Tuple[str, str]] = []
        seen = set()

        for text, prompt_type in items:
            if not text:
                continue
            if text in cache:
                continue
            key = (text, prompt_type)
            if key in seen:
                continue
            seen.add(key)
            missing.append(key)

        return missing

    def scan_all_pages(self) -> Dict[str, Dict[str, List[Tuple[str, str]]]]:
        result: Dict[str, Dict[str, List[Tuple[str, str]]]] = {}

        for page in self._registry.list_pages():
            page_result: Dict[str, List[Tuple[str, str]]] = {}
            for lang in page.target_langs:
                if lang == self.source_lang:
                    continue
                missing = self.scan_page(page.page_name, lang)
                page_result[lang] = missing
            result[page.page_name] = page_result

        return result

    def process_page_translations(
        self,
        page_name: str,
        target_lang: str,
        batch_size: int = 50,
    ) -> int:
        if not target_lang or target_lang == self.source_lang:
            return 0

        with self._lock:
            missing = self.scan_page(page_name, target_lang)
            if not missing:
                return 0

            cache = self._load_storage(page_name, target_lang)
            processed_total = 0

            for i in range(0, len(missing), batch_size):
                batch = missing[i:i + batch_size]
                short_items = []
                long_items = []

                for text, prompt_type in batch:
                    if len(text) > 3000:
                        long_items.append((text, prompt_type))
                    else:
                        short_items.append((text, prompt_type))

                translated_map: Dict[str, str] = {}

                if short_items:
                    translated_map.update(self._translate_batch(short_items, target_lang))

                for text, prompt_type in long_items:
                    translated_map[text] = self._translate_single(
                        text=text,
                        target_lang=target_lang,
                        prompt_type=prompt_type,
                    )

                if translated_map:
                    cache.update(translated_map)
                    self._save_storage(target_lang, cache)
                    processed_total += len(batch)

            return processed_total

    def process_all_translations(self, batch_size: int = 50) -> Dict[str, Dict[str, int]]:
        report: Dict[str, Dict[str, int]] = {}

        for page in self._registry.list_pages():
            page_report: Dict[str, int] = {}

            for lang in page.target_langs:
                if lang == self.source_lang:
                    continue

                try:
                    processed = self.process_page_translations(
                        page_name=page.page_name,
                        target_lang=lang,
                        batch_size=batch_size,
                    )
                except Exception:
                    processed = 0

                page_report[lang] = processed

            report[page.page_name] = page_report

        return report

    def run_translation_loop(
        self,
        interval: int = 300,
        stop_event: Optional[threading.Event] = None,
        batch_size: int = 50,
    ) -> None:
        if interval <= 0:
            raise ValueError("interval must be > 0")

        while True:
            if stop_event and stop_event.is_set():
                break

            try:
                self.process_all_translations(batch_size=batch_size)
            except Exception:
                pass

            if stop_event and stop_event.is_set():
                break

            time.sleep(interval)

    def translate_text(
        self,
        text: str,
        target_lang: str,
        page_name: str = "page",
        prompt_type: str = "normal",
    ) -> str:
        if text is None:
            return text

        if target_lang == self.source_lang:
            return text

        leading, core, trailing = split_preserve_whitespace(text)
        if not core:
            return text

        if not should_translate(core):
            return text

        cache = self._load_storage(page_name, target_lang)
        translated = cache.get(core)

        if not translated:
            return text

        return f"{leading}{translated}{trailing}"

    def translate_html(self, html: str, target_lang: str, page_name: str = "page") -> str:
        if target_lang == self.source_lang:
            return html

        cache = self._load_storage(page_name, target_lang)

        def renderer(text: str, tag: Optional[str], attr_name: Optional[str]) -> str:
            return cache.get(text, text)

        parser = SimpleHTMLTranslator(translate_callback=renderer)
        parser.feed(html)
        parser.close()
        return parser.get_html()

    def detect_browser_lang(self, accept_language: str) -> str:
        if not accept_language:
            return self.source_lang
        return accept_language.split(",")[0].split("-")[0].strip().lower()

    def get_alternative_lang(self, current_lang: str, browser_lang: str) -> str:
        current_lang = (current_lang or "").strip().lower()
        browser_lang = (browser_lang or "").strip().lower()

        if not browser_lang:
            return "en" if current_lang == self.source_lang else self.source_lang

        if current_lang == browser_lang:
            return "en" if current_lang != "en" else self.source_lang

        return browser_lang