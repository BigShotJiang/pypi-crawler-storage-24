## `README.md`

# auto-i18n-lib

Lightweight file-cache HTML translation for Python projects.

`auto-i18n-lib` translates already rendered HTML without requiring template markup changes, translation catalogs, or business-logic refactoring.

The library works in two separate modes:

1. **render mode** — the page is translated only from ready JSON cache files;
2. **background mode** — the library scans registered pages, finds missing strings, translates them in batches, and updates language caches.

That means the page opens immediately, while cache completion happens independently in the background.

---

## Why this library

Most i18n solutions require you to:

- mark strings in templates;
- rebuild template structure;
- maintain catalog files;
- refactor business logic;
- keep translation workflow inside the application.

This library uses a different approach:

1. render HTML as usual;
2. pass final HTML through the translator;
3. return translated HTML from ready cache;
4. let the background worker keep caches up to date.

This makes it practical for:

- existing projects;
- legacy systems;
- admin panels;
- internal tools;
- rapidly evolving SaaS interfaces;
- projects where full classic i18n integration is too expensive.

---

## Main idea

### During page render

- no synchronous translation calls are made;
- the library reads only ready translations from JSON cache files;
- untranslated strings remain as-is until background processing fills them.

### In background

- the library scans all registered pages;
- extracts translatable strings from page HTML;
- compares them with the existing cache for each target language;
- translates only missing strings;
- appends them to existing language files.

This model keeps page rendering fast and makes cache completion independent from user requests.

---

## Features

- Post-render HTML translation
- Fast page rendering from ready cache only
- Background scan of registered pages
- Batch translation of missing strings
- Per-language JSON cache
- Reuse of translations across different pages
- Legacy page-cache compatibility
- Translation of:
  - text nodes
  - button labels
  - selected attributes:
    - `placeholder`
    - `title`
    - `alt`
    - `aria-label`
    - `value` for button-like inputs
- Skip rules for technical and non-human-readable values
- Minimal project integration

---

## Installation

```bash
pip install auto-i18n-lib


---

## Requirements

* Python 3.9+
* OpenAI API key

---

## Environment variables

You can configure the translator through constructor arguments or environment variables.

### Supported environment variables

* `OPENAI_API_KEY` — OpenAI API key
* `SOURCE_LANG` — source language of your project content

Example:

```bash
export OPENAI_API_KEY="your_key"
export SOURCE_LANG="ru"
```

Windows PowerShell:

```powershell
$env:OPENAI_API_KEY="your_key"
$env:SOURCE_LANG="ru"
```

---

## Quick start

```python
from autoi18n import Translator

translator = Translator(
    api_key="YOUR_OPENAI_API_KEY",
    cache_dir="./translations",
    source_lang="ru",
)

def render_home():
    return """
    <h1>Главная</h1>
    <p>Добро пожаловать в систему</p>
    <button>Сохранить</button>
    <input type="text" placeholder="Введите имя">
    """

translator.register_page(
    page_name="home",
    html_getter=render_home,
    target_langs=["en", "az", "tr", "zh-hans", "zh-hant", "zh-hk"],
)

translator.process_all_translations(batch_size=50)

html = render_home()
translated_html = translator.translate_html(
    html=html,
    target_lang="en",
    page_name="home",
)

print(translated_html)
```

---

## Typical workflow

### 1. Register pages for background scanning

```python
translator.register_page(
    page_name="dashboard",
    html_getter=render_dashboard_html,
    target_langs=["en", "az", "tr"],
)
```

### 2. Run background translation processing

```python
translator.process_all_translations(batch_size=50)
```

Or run continuous background loop:

```python
translator.run_translation_loop(interval=300, batch_size=50)
```

### 3. Render pages from ready cache

```python
html = render_dashboard_html()

translated_html = translator.translate_html(
    html=html,
    target_lang="en",
    page_name="dashboard",
)
```

---

## Public API

## `Translator(...)`

```python
Translator(
    cache_dir="./translations",
    api_key=None,
    source_lang=None,
    model="gpt-4o-mini",
)
```

### Parameters

* `cache_dir` — directory for translation cache files
* `api_key` — OpenAI API key
* `source_lang` — source language of original project content
* `model` — OpenAI model used for translation

---

## `register_page(page_name, html_getter, target_langs, context=None)`

Registers a page for background scanning.

### Parameters

* `page_name` — logical page name
* `html_getter` — callable that returns rendered HTML string
* `target_langs` — list of target languages for this page
* `context` — optional dictionary passed to `html_getter(**context)`

### Example

```python
def render_profile(user_id: int):
    return f"<h1>Профиль пользователя {user_id}</h1>"

translator.register_page(
    page_name="profile",
    html_getter=render_profile,
    target_langs=["en", "az"],
    context={"user_id": 15},
)
```

---

## `scan_page(page_name, target_lang)`

Scans one registered page and returns only missing translatable items for the given target language.

### Returns

List of tuples:

```python
[(text, prompt_type), ...]
```

### Example

```python
missing = translator.scan_page("home", "en")
print(missing)
```

---

## `scan_all_pages()`

Scans all registered pages for all configured target languages.

### Returns

Dictionary in the form:

```python
{
    "home": {
        "en": [("Главная", "normal")],
        "az": [("Сохранить", "button")]
    }
}
```

---

## `process_page_translations(page_name, target_lang, batch_size=50)`

Processes missing translations for one page and one language.

### Behavior

* scans page HTML;
* detects missing strings;
* translates only missing entries;
* appends new values to language cache file.

### Returns

Number of processed items.

---

## `process_all_translations(batch_size=50)`

Processes all registered pages and all target languages.

### Returns

Dictionary report in the form:

```python
{
    "home": {
        "en": 12,
        "az": 10
    },
    "dashboard": {
        "en": 5
    }
}
```

---

## `run_translation_loop(interval=300, stop_event=None, batch_size=50)`

Runs continuous background processing loop.

### Parameters

* `interval` — scan interval in seconds
* `stop_event` — optional `threading.Event` for graceful stop
* `batch_size` — batch size for translation requests

### Behavior

* scans all registered pages repeatedly;
* updates missing translations;
* does not stop the whole loop because of one page error.

---

## `translate_text(text, target_lang, page_name="page", prompt_type="normal")`

Returns translation for a single text only from existing cache.

### Important

This method does **not** call translation API during render.
If translation is absent in cache, original text is returned.

---

## `translate_html(html, target_lang, page_name="page")`

Translates already rendered HTML using only ready cache entries.

### Important

This method does **not** create missing translations on the fly.
If a string is not yet present in cache, it stays unchanged until background processing adds it.

---

## `detect_browser_lang(accept_language)`

Extracts the primary browser language from the `Accept-Language` header.

### Example

```python
lang = translator.detect_browser_lang("en-US,en;q=0.9,ru;q=0.8")
print(lang)  # en
```

---

## `get_alternative_lang(current_lang, browser_lang)`

Returns a helper language value for language-switch logic.

---

## FastAPI example

```python
import threading

from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse

from autoi18n import Translator

app = FastAPI()

translator = Translator(
    api_key="YOUR_OPENAI_API_KEY",
    cache_dir="./translations",
    source_lang="ru",
)

def render_index():
    return """
    <h1>Главная страница</h1>
    <p>Добро пожаловать в систему</p>
    <button>Продолжить</button>
    """

translator.register_page(
    page_name="index",
    html_getter=render_index,
    target_langs=["en", "az", "tr", "zh-hans", "zh-hant", "zh-hk"],
)

@app.on_event("startup")
async def startup_event():
    thread = threading.Thread(
        target=translator.run_translation_loop,
        kwargs={"interval": 300, "batch_size": 50},
        daemon=True,
    )
    thread.start()

@app.get("/", response_class=HTMLResponse)
async def index(request: Request):
    html = render_index()
    accept_language = request.headers.get("accept-language", "")
    target_lang = translator.detect_browser_lang(accept_language)

    return translator.translate_html(
        html=html,
        target_lang=target_lang,
        page_name="index",
    )
```

---

## Flask example

```python
import threading

from flask import Flask, request

from autoi18n import Translator

app = Flask(__name__)

translator = Translator(
    api_key="YOUR_OPENAI_API_KEY",
    cache_dir="./translations",
    source_lang="ru",
)

def render_dashboard():
    return """
    <h1>Панель управления</h1>
    <p>Здесь отображается основная информация</p>
    <input type="submit" value="Сохранить">
    """

translator.register_page(
    page_name="dashboard",
    html_getter=render_dashboard,
    target_langs=["en", "az", "tr"],
)

threading.Thread(
    target=translator.run_translation_loop,
    kwargs={"interval": 300, "batch_size": 50},
    daemon=True,
).start()

@app.route("/")
def index():
    html = render_dashboard()
    accept_language = request.headers.get("Accept-Language", "")
    target_lang = translator.detect_browser_lang(accept_language)

    return translator.translate_html(
        html=html,
        target_lang=target_lang,
        page_name="dashboard",
    )
```

---

## Cache behavior

Translations are stored as JSON files in the cache directory.

### Current cache format

One file per target language:

* `translations/en.json`
* `translations/az.json`
* `translations/tr.json`
* `translations/zh-hans.json`

This allows reuse of the same translated strings across different pages.

### Cache update strategy

Background processing:

* does not recreate cache from scratch;
* does not delete existing translations;
* only appends missing keys.

### Legacy cache compatibility

Older versions could store cache as page-based files such as:

* `home.en.json`
* `profile.az.json`

Current logic can read legacy page-based cache and merge it into language-level cache.

---

## What is translated

The parser processes:

* visible text nodes;
* button text;
* useful UI attributes;
* `value` for button-like inputs.

This is intended for practical UI translation of rendered HTML.

---

## What is skipped

The parser intentionally skips:

* `script`
* `style`
* `noscript`

It also skips elements with:

* `translate="no"`
* `data-translate="no"`
* `id="langSwitch"`

And values that look like:

* empty or whitespace-only content;
* pure numbers;
* number-like strings;
* UUID/hash-like strings;
* many technical Latin-only identifiers, paths, and codes.

---

## Recommended integration pattern

Use the library like this:

1. keep your existing page rendering unchanged;
2. register important pages in the translator;
3. run background cache completion loop;
4. return translated HTML from ready cache.

This keeps:

* templates unchanged;
* business logic unchanged;
* database schema unchanged;
* user response time independent from translation API latency.

---

## Supported language examples

Target languages are defined explicitly by your application, for example:

* `ru`
* `en`
* `az`
* `tr`
* `zh-hans`
* `zh-hant`
* `zh-hk`

---

## Migration notes for 0.2.3

Version `0.2.3` changes the background logic model.

### Old model

Previous versions relied on pending queue accumulation during user-triggered render flow.

### New model

The new version uses:

* page registry;
* repeated scan of registered pages;
* missing-string detection by cache comparison;
* background cache completion independent from user requests.

### Practical effect

* page render uses only ready file cache;
* new strings are not translated synchronously during render;
* caches become complete after background scan passes.

---

## Limitations

* The library translates rendered HTML, not templates.
* Translation quality depends on source text quality.
* Very fragmented or unstable HTML reduces cache reuse efficiency.
* Page registration requires an HTML getter callable for background scanning.
* If a page is never registered, background processing will not scan it.

---

## License

MIT

