"""Tests for user feedback collection and routing integration."""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from vyane.routing import invalidate_routing_cache


@pytest.fixture(autouse=True)
def _clear_routing_cache():
    """Clear routing cache before each test to avoid cross-test contamination."""
    invalidate_routing_cache()
    yield
    invalidate_routing_cache()


class TestLogFeedback:
    """Test feedback persistence."""

    def test_basic_log(self, tmp_path):
        from vyane.feedback import log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("run-123", "codex", 5)

        entries = [json.loads(l) for l in fb_file.read_text().strip().split("\n")]
        assert len(entries) == 1
        assert entries[0]["run_id"] == "run-123"
        assert entries[0]["provider"] == "codex"
        assert entries[0]["rating"] == 5

    def test_with_category_and_comment(self, tmp_path):
        from vyane.feedback import log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("run-456", "gemini", 3, category="analysis", comment="decent")

        entries = [json.loads(l) for l in fb_file.read_text().strip().split("\n")]
        assert entries[0]["category"] == "analysis"
        assert entries[0]["comment"] == "decent"

    def test_invalid_rating_rejected(self, tmp_path):
        from vyane.feedback import log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            with pytest.raises(ValueError):
                log_feedback("run-789", "codex", 0)
            with pytest.raises(ValueError):
                log_feedback("run-789", "codex", 6)

    def test_multiple_entries(self, tmp_path):
        from vyane.feedback import log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("run-1", "codex", 5)
            log_feedback("run-2", "gemini", 2)
            log_feedback("run-3", "codex", 4)

        entries = [json.loads(l) for l in fb_file.read_text().strip().split("\n")]
        assert len(entries) == 3


class TestReadFeedback:
    """Test feedback querying."""

    def test_read_all(self, tmp_path):
        from vyane.feedback import log_feedback, read_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("run-1", "codex", 5)
            log_feedback("run-2", "gemini", 3)
            entries = read_feedback()

        assert len(entries) == 2

    def test_filter_by_provider(self, tmp_path):
        from vyane.feedback import log_feedback, read_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("run-1", "codex", 5)
            log_feedback("run-2", "gemini", 3)
            log_feedback("run-3", "codex", 4)
            entries = read_feedback(provider="codex")

        assert len(entries) == 2
        assert all(e["provider"] == "codex" for e in entries)

    def test_empty_file(self, tmp_path):
        from vyane.feedback import read_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            entries = read_feedback()

        assert entries == []

    def test_blank_lines_skipped(self, tmp_path):
        """Empty/blank lines in the JSONL file are skipped gracefully."""
        from vyane.feedback import read_feedback

        fb_file = tmp_path / "feedback.jsonl"
        fb_file.write_text(
            '{"ts":1,"run_id":"r1","provider":"codex","rating":5}\n'
            "\n"
            "   \n"
            '{"ts":2,"run_id":"r2","provider":"gemini","rating":3}\n'
        )
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            entries = read_feedback()

        assert len(entries) == 2

    def test_malformed_json_skipped(self, tmp_path):
        """Lines with invalid JSON are silently skipped."""
        from vyane.feedback import read_feedback

        fb_file = tmp_path / "feedback.jsonl"
        fb_file.write_text(
            '{"ts":1,"run_id":"r1","provider":"codex","rating":5}\n'
            "NOT VALID JSON\n"
            '{"ts":2,"run_id":"r2","provider":"gemini","rating":3}\n'
        )
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            entries = read_feedback()

        assert len(entries) == 2

    def test_time_window_filter(self, tmp_path):
        """Entries older than the time window are filtered out."""
        import time

        from vyane.feedback import read_feedback

        fb_file = tmp_path / "feedback.jsonl"
        now = time.time()
        # One entry from 2 hours ago, one from now
        fb_file.write_text(
            json.dumps({"ts": now - 7200, "run_id": "old", "provider": "codex", "rating": 3}) + "\n"
            + json.dumps({"ts": now, "run_id": "new", "provider": "codex", "rating": 5}) + "\n"
        )
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            entries = read_feedback(hours=1)

        assert len(entries) == 1
        assert entries[0]["run_id"] == "new"

    def test_oserror_returns_empty(self, tmp_path):
        """OSError while reading the file returns an empty list."""
        from vyane.feedback import read_feedback

        fb_file = tmp_path / "feedback.jsonl"
        fb_file.write_text('{"ts":1,"run_id":"r1","provider":"codex","rating":5}\n')
        with patch("vyane.feedback._feedback_file", return_value=fb_file), \
             patch("builtins.open", side_effect=OSError("permission denied")):
            entries = read_feedback()

        assert entries == []


class TestLogFeedbackImportError:
    """Test log_feedback when routing module is unavailable."""

    def test_import_error_handled(self, tmp_path):
        """ImportError on invalidate_routing_cache is silently caught."""
        from vyane.feedback import log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file), \
             patch.dict("sys.modules", {"vyane.routing": None}):
            # Should not raise even though vyane.routing import will fail
            log_feedback("run-err", "codex", 4)

        entries = [json.loads(l) for l in fb_file.read_text().strip().split("\n")]
        assert len(entries) == 1


class TestFeedbackScores:
    """Test feedback score computation for routing."""

    def test_basic_scores(self, tmp_path):
        from vyane.feedback import feedback_scores, log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            # codex gets high ratings
            log_feedback("r1", "codex", 5)
            log_feedback("r2", "codex", 4)
            # gemini gets low ratings
            log_feedback("r3", "gemini", 2)
            log_feedback("r4", "gemini", 1)

            scores = feedback_scores(["codex", "gemini"])

        assert scores["codex"] > scores["gemini"]
        # codex avg: 4.5/5 = 0.9
        assert abs(scores["codex"] - 0.9) < 0.01
        # gemini avg: 1.5/5 = 0.3
        assert abs(scores["gemini"] - 0.3) < 0.01

    def test_neutral_for_no_feedback(self, tmp_path):
        from vyane.feedback import feedback_scores

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            scores = feedback_scores(["codex", "gemini"])

        assert scores["codex"] == 0.5
        assert scores["gemini"] == 0.5

    def test_neutral_for_insufficient_data(self, tmp_path):
        from vyane.feedback import feedback_scores, log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("r1", "codex", 5)  # only 1 rating
            scores = feedback_scores(["codex", "gemini"])

        # 1 rating is not enough (need >=2)
        assert scores["codex"] == 0.5
        assert scores["gemini"] == 0.5

    def test_category_filter(self, tmp_path):
        from vyane.feedback import feedback_scores, log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("r1", "codex", 5, category="generation")
            log_feedback("r2", "codex", 5, category="generation")
            log_feedback("r3", "codex", 1, category="analysis")
            log_feedback("r4", "codex", 1, category="analysis")

            gen_scores = feedback_scores(["codex"], category="generation")
            ana_scores = feedback_scores(["codex"], category="analysis")

        assert gen_scores["codex"] > ana_scores["codex"]

    def test_perfect_score(self, tmp_path):
        from vyane.feedback import feedback_scores, log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("r1", "codex", 5)
            log_feedback("r2", "codex", 5)
            log_feedback("r3", "codex", 5)

            scores = feedback_scores(["codex"])

        assert abs(scores["codex"] - 1.0) < 0.01

    def test_unknown_provider_entries_ignored(self, tmp_path):
        """Entries from providers not in the requested list are skipped."""
        from vyane.feedback import feedback_scores, log_feedback

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            log_feedback("r1", "codex", 5)
            log_feedback("r2", "codex", 4)
            log_feedback("r3", "ollama", 1)  # not requested
            log_feedback("r4", "ollama", 1)

            scores = feedback_scores(["codex"])

        assert "ollama" not in scores
        assert abs(scores["codex"] - 0.9) < 0.01


class TestRoutingWithFeedback:
    """Test that feedback integrates into smart_route."""

    def test_feedback_influences_routing(self, tmp_path):
        from vyane.feedback import log_feedback
        from vyane.routing import smart_route

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            # Give gemini consistently high feedback for frontend tasks
            for i in range(5):
                log_feedback(f"r{i}", "gemini", 5, category="generation")
                log_feedback(f"r{i+10}", "codex", 2, category="generation")

            best, scores = smart_route(
                "create a React component",
                ["codex", "gemini"],
            )

        # gemini should rank higher due to both keyword match and feedback
        assert scores["gemini"].feedback_score > scores["codex"].feedback_score

    def test_no_feedback_neutral(self, tmp_path):
        from vyane.routing import smart_route

        fb_file = tmp_path / "feedback.jsonl"
        with patch("vyane.feedback._feedback_file", return_value=fb_file):
            _, scores = smart_route(
                "implement an algorithm",
                ["codex", "gemini"],
            )

        # Both should have neutral feedback scores
        assert scores["codex"].feedback_score == 0.5
        assert scores["gemini"].feedback_score == 0.5
