"""Tests for the shared i18n helpers."""

from __future__ import annotations

import importlib


def test_set_lang_normalizes_and_falls_back():
    import vyane.i18n as i18n

    i18n.set_lang("zh_CN.UTF-8")
    assert i18n.get_lang() == "zh"
    assert i18n.t("status_running") == "运行中"

    i18n.set_lang("fr")
    assert i18n.get_lang() == "en"
    assert i18n.t("status_running") == "Running"


def test_toggle_lang_switches_both_directions():
    import vyane.i18n as i18n

    i18n.set_lang("en")
    assert i18n.toggle_lang() == "zh"
    assert i18n.t("check_providers") == "可用模型"

    assert i18n.toggle_lang() == "en"
    assert i18n.t("check_providers") == "Providers"


def test_detect_lang_prefers_vyane_lang(monkeypatch):
    import vyane.i18n as i18n

    monkeypatch.setenv("VYANE_LANG", "zh_CN.UTF-8")
    monkeypatch.setenv("LANG", "en_US.UTF-8")
    importlib.reload(i18n)

    assert i18n.get_lang() == "zh"
    assert i18n.t("status_no_active") == "当前没有活跃任务"

    monkeypatch.delenv("VYANE_LANG", raising=False)
    monkeypatch.setenv("LANG", "en_US.UTF-8")
    importlib.reload(i18n)
    assert i18n.get_lang() == "en"
