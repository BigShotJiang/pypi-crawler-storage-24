"""Tests for the monitor TUI i18n behavior."""

from __future__ import annotations

import time
from unittest.mock import patch

import pytest

textual = pytest.importorskip("textual", reason="textual not installed")
from textual.widgets import DataTable  # noqa: E402

from vyane.i18n import set_lang  # noqa: E402
from vyane.monitor import VyaneMonitor  # noqa: E402
from vyane.status import DispatchStatus, write_status  # noqa: E402


@pytest.mark.asyncio
async def test_toggle_lang_preserves_selected_row_and_translates_status(tmp_path):
    set_lang("en")
    now = time.time()

    with patch("vyane.status._status_dir", return_value=tmp_path):
        write_status(
            DispatchStatus(
                run_id="run-1",
                provider="codex",
                task_summary="first task",
                status="pending",
                started_at=now - 20,
            )
        )
        write_status(
            DispatchStatus(
                run_id="run-2",
                provider="gemini",
                task_summary="second task",
                status="running",
                started_at=now - 10,
            )
        )

        app = VyaneMonitor()
        async with app.run_test() as pilot:
            await pilot.pause()
            table = app.query_one("#task-table", DataTable)
            assert table.row_count == 2

            await pilot.press("down")
            await pilot.pause()
            assert app._selected_run_id == "run-2"

            await pilot.press("l")
            await pilot.pause()

            table = app.query_one("#task-table", DataTable)
            row = table.get_row_at(1)
            assert app.title == "Vyane Monitor · 偃"
            assert app._selected_run_id == "run-2"
            assert table.cursor_row == 1
            assert str(row[4]) == "运行中"

    set_lang("en")
