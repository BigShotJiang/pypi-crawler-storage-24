"""Tests for Monitor v2 features: output streaming, session grouping, task control."""

import json
import time
from unittest.mock import patch

import pytest

from vyane.status import (
    DispatchStatus,
    cancel_status,
    list_active,
    pause_status,
    read_status,
    resume_status,
    write_status,
)


class TestSessionIdField:
    """DispatchStatus now includes session_id for session grouping."""

    def test_default_session_id_empty(self):
        status = DispatchStatus()
        assert status.session_id == ""

    def test_session_id_set(self):
        status = DispatchStatus(run_id="r1", session_id="sess-abc")
        assert status.session_id == "sess-abc"

    def test_session_id_round_trip(self, tmp_path):
        """session_id survives write/read cycle."""
        with patch("vyane.status._status_dir", return_value=tmp_path):
            status = DispatchStatus(
                run_id="rt1",
                provider="codex",
                session_id="sess-xyz",
                status="running",
                started_at=time.time(),
            )
            write_status(status)
            loaded = read_status("rt1")

        assert loaded is not None
        assert loaded.session_id == "sess-xyz"

    def test_session_id_in_list_active(self, tmp_path):
        now = time.time()
        data = {
            "run_id": "s1",
            "provider": "gemini",
            "session_id": "sess-group",
            "status": "running",
            "started_at": now,
        }
        (tmp_path / "s1.json").write_text(json.dumps(data))

        with patch("vyane.status._status_dir", return_value=tmp_path):
            result = list_active()

        assert len(result) == 1
        assert result[0].session_id == "sess-group"

    def test_backward_compat_no_session_id(self, tmp_path):
        """Old status files without session_id still load fine."""
        data = {
            "run_id": "old1",
            "provider": "test",
            "status": "running",
            "started_at": time.time(),
        }
        (tmp_path / "old1.json").write_text(json.dumps(data))

        with patch("vyane.status._status_dir", return_value=tmp_path):
            result = list_active()

        assert len(result) == 1
        assert result[0].session_id == ""


class TestCancelStatus:
    def test_cancel_running_task(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(run_id="c1", status="running", started_at=time.time())
            )
            assert cancel_status("c1") is True
            updated = read_status("c1")
            assert updated is not None
            assert updated.status == "cancelled"

    def test_cancel_nonexistent(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            assert cancel_status("nope") is False

    def test_cancel_already_completed(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(run_id="done1", status="success", started_at=time.time())
            )
            assert cancel_status("done1") is False

    def test_cancel_pending_task(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(run_id="p1", status="pending", started_at=time.time())
            )
            assert cancel_status("p1") is True
            updated = read_status("p1")
            assert updated.status == "cancelled"


class TestPauseStatus:
    def test_pause_running_task(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(run_id="pr1", status="running", started_at=time.time())
            )
            assert pause_status("pr1") is True
            updated = read_status("pr1")
            assert updated.paused is True

    def test_pause_nonexistent(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            assert pause_status("nope") is False

    def test_pause_non_running(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(run_id="nr1", status="success", started_at=time.time())
            )
            assert pause_status("nr1") is False


class TestResumeStatus:
    def test_resume_paused_task(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(
                    run_id="rp1",
                    status="running",
                    paused=True,
                    started_at=time.time(),
                )
            )
            assert resume_status("rp1") is True
            updated = read_status("rp1")
            assert updated.paused is False

    def test_resume_not_paused(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(run_id="np1", status="running", started_at=time.time())
            )
            assert resume_status("np1") is False

    def test_resume_nonexistent(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            assert resume_status("nope") is False


class TestCancelClearsPaused:
    """Regression: cancelling a paused task must clear the paused flag,
    and a cancelled task must not be resumable."""

    def test_cancel_clears_paused_flag(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(
                    run_id="cp1",
                    status="running",
                    paused=True,
                    started_at=time.time(),
                )
            )
            assert cancel_status("cp1") is True
            updated = read_status("cp1")
            assert updated is not None
            assert updated.status == "cancelled"
            assert updated.paused is False

    def test_cancelled_task_cannot_be_resumed(self, tmp_path):
        with patch("vyane.status._status_dir", return_value=tmp_path):
            write_status(
                DispatchStatus(
                    run_id="cr1",
                    status="running",
                    paused=True,
                    started_at=time.time(),
                )
            )
            cancel_status("cr1")
            # Task is now cancelled with paused=False; resume must fail
            assert resume_status("cr1") is False

    def test_resume_rejects_terminal_status(self, tmp_path):
        """Even if paused flag were somehow True on a terminal task,
        resume should refuse."""
        with patch("vyane.status._status_dir", return_value=tmp_path):
            # Manually write a corrupted state: cancelled + paused
            write_status(
                DispatchStatus(
                    run_id="tr1",
                    status="cancelled",
                    paused=True,
                    started_at=time.time(),
                )
            )
            assert resume_status("tr1") is False


try:
    import textual  # noqa: F401

    _HAS_TEXTUAL = True
except ImportError:
    _HAS_TEXTUAL = False

_skip_no_textual = pytest.mark.skipif(not _HAS_TEXTUAL, reason="textual not installed")


@_skip_no_textual
class TestMonitorImports:
    """Ensure monitor module imports and key classes exist."""

    def test_import_monitor(self):
        from vyane.monitor import NotificationBar, OutputPanel, VyaneMonitor

        assert VyaneMonitor is not None
        assert OutputPanel is not None
        assert NotificationBar is not None

    def test_run_monitor_exists(self):
        from vyane.monitor import run_monitor

        assert callable(run_monitor)

    def test_i18n_function(self):
        from vyane.i18n import set_lang
        from vyane.monitor import _t

        # English
        set_lang("en")
        en_text = _t("select_task").lower()
        assert "task" in en_text or "select" in en_text
        # Chinese
        set_lang("zh")
        zh = _t("select_task")
        assert len(zh) > 0
        set_lang("en")

    def test_i18n_with_kwargs(self):
        from vyane.i18n import set_lang
        from vyane.monitor import _t

        set_lang("en")
        result = _t("cancelled_ok", run_id="abc123")
        assert "abc123" in result

    def test_fmt_elapsed(self):
        from vyane.monitor import _fmt_elapsed

        assert _fmt_elapsed(30) == "30s"
        assert _fmt_elapsed(90) == "1m30s"
        assert _fmt_elapsed(3661) == "61m01s"

    def test_bindings_include_controls(self):
        from vyane.monitor import VyaneMonitor

        binding_keys = [b.key for b in VyaneMonitor.BINDINGS]
        assert "c" in binding_keys  # cancel
        assert "p" in binding_keys  # pause
        assert "u" in binding_keys  # resume
        assert "s" in binding_keys  # session toggle
        assert "q" in binding_keys  # quit
        assert "r" in binding_keys  # refresh
