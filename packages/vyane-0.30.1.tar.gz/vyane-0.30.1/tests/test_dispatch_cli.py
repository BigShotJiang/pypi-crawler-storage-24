"""Tests for the `vyane dispatch` and `vyane broadcast` CLI subcommands."""

import json
import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from vyane.adapters.base import AdapterResult, BaseAdapter


def _make_adapter(available=True, result=None):
    """Create a mock adapter that passes isinstance(x, BaseAdapter)."""
    mock = MagicMock(spec=BaseAdapter)
    mock.check_available.return_value = available
    if result is not None:
        mock.run = AsyncMock(return_value=result)
    return mock


def _dispatch_ns(**overrides):
    """Build a namespace for dispatch with sensible defaults."""
    ns = MagicMock()
    defaults = {
        "provider": "codex",
        "model": "",
        "sandbox": "read-only",
        "timeout": 300,
        "workdir": ".",
        "task": ["test"],
        "max_retries": 1,
        "failover": False,
        "profile": "",
    }
    defaults.update(overrides)
    for k, v in defaults.items():
        setattr(ns, k, v)
    return ns


def _broadcast_ns(**overrides):
    """Build a namespace for broadcast with sensible defaults."""
    ns = MagicMock()
    defaults = {
        "providers": None,
        "model": "",
        "sandbox": "read-only",
        "timeout": 300,
        "workdir": ".",
        "task": ["test"],
        "compare": False,
        "profile": "",
    }
    defaults.update(overrides)
    for k, v in defaults.items():
        setattr(ns, k, v)
    return ns


# ── dispatch tests ──


def test_dispatch_no_task_exits(monkeypatch):
    """dispatch with no task and empty stdin should exit 1."""
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(provider="auto", task=[])
    monkeypatch.setattr("sys.stdin", MagicMock(read=MagicMock(return_value="")))

    with pytest.raises(SystemExit) as exc_info:
        _cmd_dispatch(ns)
    assert exc_info.value.code == 1


def test_dispatch_no_providers_exits():
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(provider="auto", task=["hello world"])
    mock_adapter = _make_adapter(available=False)

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_dispatch(ns)
    assert exc_info.value.code == 1


def test_dispatch_no_providers_zh_exits(capsys):
    from vyane.cli import _cmd_dispatch
    from vyane.i18n import set_lang

    ns = _dispatch_ns(provider="auto", task=["hello world"])
    mock_adapter = _make_adapter(available=False)

    set_lang("zh")
    try:
        with (
            patch(
                "vyane.adapters.get_all_adapters",
                return_value={"codex": mock_adapter},
            ),
            pytest.raises(SystemExit) as exc_info,
        ):
            _cmd_dispatch(ns)
        assert exc_info.value.code == 1

        captured = capsys.readouterr()
        result = json.loads(captured.out)
        assert result["error"] == "没有可用模型"
    finally:
        set_lang("en")


def test_dispatch_success(capsys):
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["review", "this", "code"])
    fake_result = AdapterResult(
        run_id="abc123",
        provider="codex",
        status="success",
        output="Looks good!",
        summary="Looks good!",
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_adapter},
    ):
        _cmd_dispatch(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "success"
    assert result["provider"] == "codex"
    assert result["output"] == "Looks good!"


def test_dispatch_auto_routes(capsys):
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(provider="auto", task=["analyze architecture"])
    mock_codex = _make_adapter(available=True)
    fake_result = AdapterResult(
        run_id="r1",
        provider="gemini",
        status="success",
        output="Analysis done",
        summary="Analysis done",
    )
    mock_gemini = _make_adapter(available=True, result=fake_result)

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_codex, "gemini": mock_gemini},
        ),
        patch(
            "vyane.routing.smart_route",
            return_value=("gemini", {}),
        ),
    ):
        _cmd_dispatch(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["provider"] == "gemini"


def test_dispatch_passes_model(capsys):
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(
        model="gpt-5.4", timeout=120, workdir="/tmp", task=["test"]
    )
    fake_result = AdapterResult(
        run_id="r2", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_adapter},
    ):
        _cmd_dispatch(ns)

    call_kwargs = mock_adapter.run.call_args[1]
    assert call_kwargs["extra_args"] == {"model": "gpt-5.4"}
    assert call_kwargs["timeout"] == 120
    assert call_kwargs["workdir"] == "/tmp"


def test_dispatch_error_exits_1(capsys):
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["fail"])
    fake_result = AdapterResult(
        run_id="r3", provider="codex", status="error", error="broke"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_dispatch(ns)

    assert exc_info.value.code == 1
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "error"


def test_dispatch_retry_succeeds_on_second_attempt(capsys):
    """dispatch --max-retries=2 should retry on error."""
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(max_retries=2, task=["retry me"])

    call_count = [0]
    error_result = AdapterResult(
        run_id="r4", provider="codex", status="error", error="transient"
    )
    ok_result = AdapterResult(
        run_id="r4", provider="codex", status="success", output="ok"
    )

    async def side_effect(**kwargs):
        call_count[0] += 1
        return error_result if call_count[0] == 1 else ok_result

    mock_adapter = _make_adapter(available=True)
    mock_adapter.run = AsyncMock(side_effect=side_effect)

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        patch("time.sleep"),
    ):
        _cmd_dispatch(ns)

    assert call_count[0] == 2
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "success"


# ── broadcast tests ──


def test_broadcast_success(capsys):
    """broadcast should return results from all providers."""
    from vyane.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["review code"])

    codex_result = AdapterResult(
        run_id="c1", provider="codex", status="success", output="LGTM"
    )
    gemini_result = AdapterResult(
        run_id="g1", provider="gemini", status="success", output="Fine"
    )
    mock_codex = _make_adapter(available=True, result=codex_result)
    mock_gemini = _make_adapter(available=True, result=gemini_result)

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert len(data["results"]) == 2
    assert data["providers"] == ["codex", "gemini"]
    assert data["results"][0]["status"] == "success"
    assert data["results"][1]["status"] == "success"


def test_broadcast_specific_providers(capsys):
    """broadcast --providers codex should only use codex."""
    from vyane.cli import _cmd_broadcast

    ns = _broadcast_ns(providers=["codex"], task=["test"])
    codex_result = AdapterResult(
        run_id="c1", provider="codex", status="success", output="ok"
    )
    mock_codex = _make_adapter(available=True, result=codex_result)
    mock_gemini = _make_adapter(available=True)

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["providers"] == ["codex"]
    assert len(data["results"]) == 1


def test_dispatch_failover_success(capsys):
    """dispatch --failover should try another provider on error."""
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["fail then recover"], failover=True)
    err_result = AdapterResult(
        run_id="r5", provider="codex", status="error", error="crashed"
    )
    ok_result = AdapterResult(
        run_id="r6", provider="gemini", status="success", output="recovered"
    )
    mock_codex = _make_adapter(available=True, result=err_result)
    mock_gemini = _make_adapter(available=True, result=ok_result)

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_dispatch(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "success"
    assert result["provider"] == "gemini"
    assert result["failover_from"] == "codex"


def test_dispatch_no_failover_by_default(capsys):
    """dispatch without --failover should not try other providers."""
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["fail"])
    err_result = AdapterResult(
        run_id="r7", provider="codex", status="error", error="crashed"
    )
    mock_codex = _make_adapter(available=True, result=err_result)
    mock_gemini = _make_adapter(available=True)

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_codex, "gemini": mock_gemini},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_dispatch(ns)

    assert exc_info.value.code == 1
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "error"
    assert "failover_from" not in result


def test_broadcast_compare(capsys):
    """broadcast --compare should add comparison analysis."""
    from vyane.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["compare test"], compare=True)
    codex_result = AdapterResult(
        run_id="c1",
        provider="codex",
        status="success",
        output="The code looks good and well structured",
        duration_seconds=5.0,
    )
    gemini_result = AdapterResult(
        run_id="g1",
        provider="gemini",
        status="success",
        output="The code is well structured and readable",
        duration_seconds=3.0,
    )
    mock_codex = _make_adapter(available=True, result=codex_result)
    mock_gemini = _make_adapter(available=True, result=gemini_result)

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_codex, "gemini": mock_gemini},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "comparison" in data
    assert data["comparison"]["comparable"] is True
    assert "agreement_score" in data["comparison"]
    assert "speed_ranking" in data["comparison"]


def test_broadcast_no_compare_by_default(capsys):
    """broadcast without --compare should not include comparison."""
    from vyane.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["no compare"])
    result = AdapterResult(
        run_id="c1", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=result)

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_adapter},
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "comparison" not in data


def test_broadcast_all_fail_exits_1(capsys):
    """broadcast should exit 1 if all providers fail."""
    from vyane.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["fail"])
    err_result = AdapterResult(
        run_id="e1", provider="codex", status="error", error="nope"
    )
    mock_adapter = _make_adapter(available=True, result=err_result)

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_broadcast(ns)

    assert exc_info.value.code == 1


# ── profile tests ──


def test_dispatch_with_profile(capsys):
    """dispatch --profile should apply profile model override."""
    from vyane.cli import _cmd_dispatch
    from vyane.config import MuxConfig, Profile, ProviderConfig

    ns = _dispatch_ns(task=["test"], profile="budget")
    fake_result = AdapterResult(
        run_id="r8", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)
    config = MuxConfig(
        profiles={
            "budget": Profile(
                providers={"codex": ProviderConfig(model="gpt-4.1-mini")},
            ),
        },
    )

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        patch("vyane.config.load_config", return_value=config),
    ):
        _cmd_dispatch(ns)

    call_kwargs = mock_adapter.run.call_args[1]
    assert call_kwargs["extra_args"]["model"] == "gpt-4.1-mini"


def test_profile_list_empty(capsys):
    """profile with no profiles should show 'No profiles'."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig

    ns = MagicMock()
    ns.name = ""
    ns.json = False

    with patch("vyane.config.load_config", return_value=MuxConfig()):
        _cmd_profile(ns)

    captured = capsys.readouterr()
    assert "No profiles" in captured.out


def test_profile_list_with_profiles(capsys):
    """profile should list configured profiles."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig, Profile, ProviderConfig

    config = MuxConfig(
        active_profile="budget",
        profiles={
            "budget": Profile(
                description="Use cheaper models",
                providers={"codex": ProviderConfig(model="gpt-4.1-mini")},
            ),
        },
    )
    ns = MagicMock()
    ns.name = ""
    ns.json = False

    with patch("vyane.config.load_config", return_value=config):
        _cmd_profile(ns)

    captured = capsys.readouterr()
    assert "budget" in captured.out
    assert "cheaper" in captured.out


def test_profile_show_json(capsys):
    """profile <name> --json should output JSON."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig, Profile, ProviderConfig

    config = MuxConfig(
        profiles={
            "fast": Profile(
                description="Speed",
                providers={"gemini": ProviderConfig(model="gemini-2.5-flash")},
            ),
        },
    )
    ns = MagicMock()
    ns.name = "fast"
    ns.json = True

    with patch("vyane.config.load_config", return_value=config):
        _cmd_profile(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["name"] == "fast"
    assert data["providers"]["gemini"]["model"] == "gemini-2.5-flash"


def test_profile_not_found():
    """profile <unknown> should exit 1."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig

    ns = MagicMock()
    ns.name = "nonexistent"
    ns.json = False

    with (
        patch("vyane.config.load_config", return_value=MuxConfig()),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_profile(ns)
    assert exc_info.value.code == 1


# ── feedback tests ──


def _feedback_ns(**overrides):
    """Build a namespace for feedback with sensible defaults."""
    ns = MagicMock()
    defaults = {
        "run_id": "",
        "provider": "",
        "rating": 0,
        "comment": "",
        "category": "",
        "list": False,
        "hours": 0,
    }
    defaults.update(overrides)
    for k, v in defaults.items():
        setattr(ns, k, v)
    return ns


def test_feedback_submit(capsys, tmp_path):
    """feedback --run-id --provider --rating should log feedback."""
    from vyane.cli import _cmd_feedback

    ns = _feedback_ns(run_id="abc123", provider="codex", rating=4, comment="great")

    with patch("vyane.feedback._feedback_file", return_value=tmp_path / "fb.jsonl"):
        _cmd_feedback(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "ok"
    assert result["run_id"] == "abc123"
    assert result["rating"] == 4


def test_feedback_missing_args_exits():
    """feedback without required args should exit 1."""
    from vyane.cli import _cmd_feedback

    ns = _feedback_ns()  # all empty

    with pytest.raises(SystemExit) as exc_info:
        _cmd_feedback(ns)
    assert exc_info.value.code == 1


def test_feedback_invalid_rating_exits(tmp_path):
    """feedback with rating outside 1-5 should exit 1."""
    from vyane.cli import _cmd_feedback

    ns = _feedback_ns(run_id="x", provider="codex", rating=7)

    with (
        patch("vyane.feedback._feedback_file", return_value=tmp_path / "fb.jsonl"),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_feedback(ns)
    assert exc_info.value.code == 1


def test_feedback_list_empty(capsys):
    """feedback --list with no data should show message."""
    from vyane.cli import _cmd_feedback

    ns = _feedback_ns(**{"list": True})

    with patch("vyane.feedback.read_feedback", return_value=[]):
        _cmd_feedback(ns)

    captured = capsys.readouterr()
    assert "No feedback" in captured.out


# ── clean tests ──


def test_clean_dry_run(capsys, tmp_path):
    """clean --dry-run should not delete files."""
    from vyane.cli import _cmd_clean

    history = tmp_path / "history.jsonl"
    history.write_text('{"test": true}\n')

    ns = MagicMock()
    ns.what = "all"
    ns.dry_run = True

    # Create the config dir structure
    cfg = tmp_path / ".config" / "vyane"
    cfg.mkdir(parents=True)
    h = cfg / "history.jsonl"
    h.write_text('{"test": true}\n')

    with patch("pathlib.Path.home", return_value=tmp_path):
        _cmd_clean(ns)

    # File should still exist
    assert h.exists()

    captured = capsys.readouterr()
    assert "dry run" in captured.out


def test_clean_removes_file(capsys, tmp_path):
    """clean history should remove history.jsonl."""
    from vyane.cli import _cmd_clean

    cfg = tmp_path / ".config" / "vyane"
    cfg.mkdir(parents=True)
    h = cfg / "history.jsonl"
    h.write_text('{"test": true}\n')

    ns = MagicMock()
    ns.what = "history"
    ns.dry_run = False

    with patch("pathlib.Path.home", return_value=tmp_path):
        _cmd_clean(ns)

    assert not h.exists()
    captured = capsys.readouterr()
    assert "Cleaned" in captured.out


def test_clean_nothing_to_clean(capsys, tmp_path):
    """clean with no files shows nothing message."""
    from vyane.cli import _cmd_clean

    ns = MagicMock()
    ns.what = "all"
    ns.dry_run = False

    with patch("pathlib.Path.home", return_value=tmp_path):
        _cmd_clean(ns)

    captured = capsys.readouterr()
    assert "Nothing to clean" in captured.out


# ── history tests ──


def _history_ns(**overrides):
    """Build a namespace for history with sensible defaults."""
    ns = MagicMock()
    defaults = {
        "stats": False,
        "limit": 10,
        "provider": "",
        "hours": 0,
        "costs": False,
        "source": "",
        "json": False,
    }
    defaults.update(overrides)
    for k, v in defaults.items():
        setattr(ns, k, v)
    return ns


def test_history_json_entries(capsys):
    """history --json outputs valid JSON with entries."""
    from vyane.cli import _cmd_history

    entries = [
        {"provider": "codex", "status": "success", "ts": 1000, "task": "test"},
    ]
    ns = _history_ns(json=True)

    with patch("vyane.history.read_history", return_value=entries):
        _cmd_history(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["count"] == 1
    assert data["entries"][0]["provider"] == "codex"


def test_history_json_empty(capsys):
    """history --json with no entries outputs empty list."""
    from vyane.cli import _cmd_history

    ns = _history_ns(json=True)

    with patch("vyane.history.read_history", return_value=[]):
        _cmd_history(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["count"] == 0
    assert data["entries"] == []


def test_history_stats_json(capsys):
    """history --stats --json outputs stats as JSON."""
    from vyane.cli import _cmd_history

    stats = {"total": 5, "by_provider": {"codex": {"calls": 5}}}
    ns = _history_ns(stats=True, json=True)

    with patch("vyane.history.get_history_stats", return_value=stats):
        _cmd_history(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["total"] == 5


def test_history_no_data(capsys):
    """history with no entries shows message."""
    from vyane.cli import _cmd_history

    ns = _history_ns()

    with patch("vyane.history.read_history", return_value=[]):
        _cmd_history(ns)

    captured = capsys.readouterr()
    assert "No history" in captured.out


def test_history_stats_text(capsys):
    """history --stats in text mode shows statistics."""
    from vyane.cli import _cmd_history

    stats = {
        "total": 3,
        "by_provider": {
            "codex": {"calls": 2, "success_rate": 100, "avg_duration": 5.0},
            "gemini": {"calls": 1, "success_rate": 50, "avg_duration": 3.0},
        },
        "by_source": {"dispatch": 2, "broadcast": 1},
    }
    ns = _history_ns(stats=True)

    with patch("vyane.history.get_history_stats", return_value=stats):
        _cmd_history(ns)

    captured = capsys.readouterr()
    assert "Total dispatches: 3" in captured.out
    assert "codex" in captured.out


def test_history_stats_empty(capsys):
    """history --stats with no data shows message."""
    from vyane.cli import _cmd_history

    ns = _history_ns(stats=True)

    with patch("vyane.history.get_history_stats", return_value={"total": 0}):
        _cmd_history(ns)

    captured = capsys.readouterr()
    assert "No history" in captured.out


def test_history_stats_with_costs(capsys):
    """history --stats --costs shows cost breakdown."""
    from vyane.cli import _cmd_history

    stats = {
        "total": 1,
        "by_provider": {"codex": {"calls": 1, "success_rate": 100, "avg_duration": 2}},
        "by_source": {},
        "costs": {
            "entries_with_usage": 1,
            "total_input_tokens": 500,
            "total_output_tokens": 200,
            "total_cost_usd": 0.002,
            "by_provider": {
                "codex": {
                    "calls": 1,
                    "input_tokens": 500,
                    "output_tokens": 200,
                    "total_cost": 0.002,
                },
            },
        },
    }
    ns = _history_ns(stats=True, costs=True)

    with patch("vyane.history.get_history_stats", return_value=stats):
        _cmd_history(ns)

    captured = capsys.readouterr()
    assert "Cost Estimation" in captured.out
    assert "$0.0020" in captured.out


def test_history_text_entries(capsys):
    """history in text mode shows entries."""
    import time

    from vyane.cli import _cmd_history

    entries = [
        {
            "provider": "codex",
            "status": "success",
            "ts": time.time() - 60,
            "task": "review code",
            "duration_seconds": 3.5,
            "source": "dispatch",
        },
    ]
    ns = _history_ns()

    with patch("vyane.history.read_history", return_value=entries):
        _cmd_history(ns)

    captured = capsys.readouterr()
    assert "Recent Dispatches" in captured.out
    assert "codex" in captured.out


# ── check tests ──


def test_check_text(capsys):
    """check in text mode shows provider availability."""
    from vyane.cli import _cmd_check

    ns = MagicMock()
    ns.json = False

    mock_adapter = MagicMock(spec=BaseAdapter)
    mock_adapter.check_available.return_value = True
    mock_adapter._binary_name.return_value = "codex"

    with (
        patch("vyane.adapters.ADAPTERS", {"codex": lambda: mock_adapter}),
        patch("shutil.which", return_value="/usr/bin/codex"),
        patch("vyane.config.load_config") as mock_config,
        patch("vyane.history.get_history_stats", return_value={"total": 0}),
    ):
        mock_config.return_value = MagicMock(
            profiles={},
            active_profile="default",
            routing_rules=[],
        )
        _cmd_check(ns)

    captured = capsys.readouterr()
    assert "Vyane" in captured.out
    assert "Providers" in captured.out


def test_check_text_zh(capsys):
    """check in zh mode translates runtime output."""
    from vyane.cli import _cmd_check
    from vyane.i18n import set_lang

    ns = MagicMock()
    ns.json = False

    mock_adapter = MagicMock(spec=BaseAdapter)
    mock_adapter.check_available.return_value = True
    mock_adapter._binary_name.return_value = "gemini"

    set_lang("zh")
    try:
        with (
            patch("vyane.adapters.ADAPTERS", {"gemini": lambda: mock_adapter}),
            patch("shutil.which", return_value=None),
            patch("vyane.config.load_config") as mock_config,
            patch(
                "vyane.history.get_history_stats",
                return_value={
                    "total": 3,
                    "by_provider": {
                        "gemini": {
                            "calls": 3,
                            "success_rate": 67.0,
                        }
                    },
                },
            ),
        ):
            mock_config.return_value = MagicMock(
                profiles={"fast": MagicMock()},
                active_profile="fast",
                routing_rules=[MagicMock()],
            )
            _cmd_check(ns)

        captured = capsys.readouterr()
        assert "可用模型" in captured.out
        assert "已设置 API key" in captured.out
        assert "当前配置档: fast" in captured.out
        assert "路由规则: 1" in captured.out
        assert "最近 24 小时" in captured.out
        assert "3 次调用" in captured.out
        assert "成功率 67%" in captured.out
    finally:
        set_lang("en")


def test_check_json(capsys):
    """check --json outputs valid JSON."""
    from vyane.cli import _cmd_check

    ns = MagicMock()
    ns.json = True

    mock_adapter = MagicMock(spec=BaseAdapter)
    mock_adapter.check_available.return_value = True
    mock_adapter._binary_name.return_value = "codex"

    with (
        patch("vyane.adapters.ADAPTERS", {"codex": lambda: mock_adapter}),
        patch("shutil.which", return_value="/usr/bin/codex"),
        patch("vyane.config.load_config") as mock_config,
    ):
        mock_config.return_value = MagicMock(
            profiles={"fast": MagicMock()},
            active_profile="fast",
            routing_rules=[MagicMock()],
        )
        _cmd_check(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "version" in data
    assert "providers" in data
    assert data["active_profile"] == "fast"


# ── status tests ──


def test_status_no_active(capsys):
    """status with no active dispatches shows message."""
    from vyane.cli import _cmd_status

    ns = MagicMock()
    ns.watch = False

    with patch("vyane.status.list_active", return_value=[]):
        _cmd_status(ns)

    captured = capsys.readouterr()
    assert "No active" in captured.out


def test_status_no_active_zh(capsys):
    """status in zh mode translates headings and empty state."""
    from vyane.cli import _cmd_status
    from vyane.i18n import set_lang

    ns = MagicMock()
    ns.watch = False

    set_lang("zh")
    try:
        with patch("vyane.status.list_active", return_value=[]):
            _cmd_status(ns)

        captured = capsys.readouterr()
        assert "活跃任务" in captured.out
        assert "当前没有活跃任务" in captured.out
    finally:
        set_lang("en")


def test_status_with_active(capsys):
    """status shows active dispatches."""
    import time

    from vyane.cli import _cmd_status
    from vyane.status import DispatchStatus

    ns = MagicMock()
    ns.watch = False

    active = [
        DispatchStatus(
            run_id="abc123",
            provider="codex",
            task_summary="test task",
            status="running",
            started_at=time.time() - 10,
        ),
    ]

    with patch("vyane.status.list_active", return_value=active):
        _cmd_status(ns)

    captured = capsys.readouterr()
    assert "abc123" in captured.out
    assert "codex" in captured.out


def test_broadcast_no_providers_zh_exits(capsys):
    from vyane.cli import _cmd_broadcast
    from vyane.i18n import set_lang

    ns = _broadcast_ns(task=["review code"])
    mock_adapter = _make_adapter(available=False)

    set_lang("zh")
    try:
        with (
            patch(
                "vyane.adapters.get_all_adapters",
                return_value={"codex": mock_adapter},
            ),
            pytest.raises(SystemExit) as exc_info,
        ):
            _cmd_broadcast(ns)
        assert exc_info.value.code == 1

        captured = capsys.readouterr()
        result = json.loads(captured.out)
        assert result["error"] == "没有可用模型"
    finally:
        set_lang("en")


# ── version test ──


def test_cmd_version(capsys):
    """version should print version string."""
    from vyane.cli import _cmd_version

    _cmd_version()

    captured = capsys.readouterr()
    assert "Vyane" in captured.out


# ── helper function tests ──


def test_get_available_adapters():
    """_get_available_adapters returns available adapters."""
    from vyane.cli import _get_available_adapters

    mock = _make_adapter(available=True)
    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock},
    ):
        all_a, available = _get_available_adapters()
        assert "codex" in available


def test_resolve_adapter():
    """_resolve_adapter returns adapter instance."""
    from vyane.cli import _resolve_adapter

    mock = _make_adapter(available=True)
    result = _resolve_adapter({"codex": mock}, "codex")
    assert result is mock


def test_read_task_from_args():
    """_read_task reads from positional args."""
    from vyane.cli import _read_task

    ns = MagicMock()
    ns.task = ["hello", "world"]
    assert _read_task(ns) == "hello world"


def test_apply_profile_with_model():
    """_apply_profile with model returns model in extra_args."""
    from vyane.cli import _apply_profile

    extra, env = _apply_profile("codex", "gpt-5", "")
    assert extra["model"] == "gpt-5"
    assert env == {}


def test_apply_profile_with_profile_name():
    """_apply_profile with profile name loads config."""
    from vyane.cli import _apply_profile
    from vyane.config import MuxConfig, Profile, ProviderConfig

    config = MuxConfig(
        profiles={
            "test": Profile(
                providers={"codex": ProviderConfig(model="custom-model")},
            ),
        },
    )

    with patch("vyane.config.load_config", return_value=config):
        extra, env = _apply_profile("codex", "", "test")
        assert extra["model"] == "custom-model"


# ── cmd_init / cmd_config tests ──


def test_cmd_init():
    """_cmd_init calls run_wizard."""
    from vyane.cli import _cmd_init

    ns = MagicMock()
    ns.scope = "user"

    with patch("vyane.init_wizard.run_wizard") as mock_wizard:
        _cmd_init(ns)
        mock_wizard.assert_called_once_with(scope="user")


def test_cmd_config_missing_textual(capsys):
    """_cmd_config exits when textual is not installed."""

    ns = MagicMock()
    ns.scope = "user"

    with (
        patch.dict("sys.modules", {"vyane.tui": None}),
        patch("vyane.cli._cmd_config") as mock_fn,
    ):
        # Simulate ImportError path
        mock_fn.side_effect = SystemExit(1)
        with pytest.raises(SystemExit):
            mock_fn(ns)


# ── cmd_export test ──


def test_cmd_export_to_stdout(capsys):
    """export without --output prints to stdout."""
    from vyane.cli import _cmd_export

    ns = MagicMock()
    ns.format = "csv"
    ns.hours = 0
    ns.provider = ""
    ns.limit = 100
    ns.output = ""
    ns.source = ""

    with patch("vyane.export.run_export", return_value="col1,col2\nval1,val2"):
        _cmd_export(ns)

    captured = capsys.readouterr()
    assert "col1,col2" in captured.out


def test_cmd_export_to_file(capsys):
    """export with --output shows filename."""
    from vyane.cli import _cmd_export

    ns = MagicMock()
    ns.format = "json"
    ns.hours = 24
    ns.provider = "codex"
    ns.limit = 50
    ns.output = "/tmp/test.json"
    ns.source = ""

    with patch("vyane.export.run_export", return_value="{}"):
        _cmd_export(ns)

    captured = capsys.readouterr()
    assert "Exported to" in captured.out


# ── main entry point tests ──


def test_main_version(capsys):
    """main() with 'version' subcommand prints version."""
    import sys

    from vyane.cli import main

    with patch.object(sys, "argv", ["vyane", "version"]):
        main()

    captured = capsys.readouterr()
    assert "Vyane" in captured.out


def test_main_check(capsys):
    """main() with 'check' routes to _cmd_check."""
    import sys

    from vyane.cli import main

    mock_adapter = MagicMock(spec=BaseAdapter)
    mock_adapter.check_available.return_value = False
    mock_adapter._binary_name.return_value = "codex"

    with (
        patch.object(sys, "argv", ["vyane", "check"]),
        patch("vyane.adapters.ADAPTERS", {"codex": lambda: mock_adapter}),
        patch("shutil.which", return_value=None),
        patch("vyane.config.load_config") as mock_config,
        patch("vyane.history.get_history_stats", return_value={"total": 0}),
    ):
        mock_config.return_value = MagicMock(
            profiles={},
            active_profile="default",
            routing_rules=[],
        )
        main()

    captured = capsys.readouterr()
    assert "Vyane" in captured.out


# ── feedback list with entries ──


def test_feedback_list_with_entries(capsys):
    """feedback --list with entries shows ratings."""
    from vyane.cli import _cmd_feedback

    entries = [
        {"run_id": "abc12345", "provider": "codex", "rating": 5, "comment": "great"},
        {"run_id": "def67890", "provider": "gemini", "rating": 3, "comment": "ok"},
    ]
    ns = _feedback_ns(**{"list": True})

    with patch("vyane.feedback.read_feedback", return_value=entries):
        _cmd_feedback(ns)

    captured = capsys.readouterr()
    assert "User Feedback" in captured.out
    assert "codex" in captured.out


# ── profile list json test ──


def test_profile_list_json(capsys):
    """profile --json outputs JSON profile list."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig, Profile, ProviderConfig

    config = MuxConfig(
        active_profile="fast",
        profiles={
            "fast": Profile(
                description="Quick",
                providers={"gemini": ProviderConfig(model="flash")},
            ),
        },
    )
    ns = MagicMock()
    ns.name = ""
    ns.json = True

    with patch("vyane.config.load_config", return_value=config):
        _cmd_profile(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["active"] == "fast"
    assert "fast" in data["profiles"]


def test_profile_show_text(capsys):
    """profile <name> in text mode shows details."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig, Profile, ProviderConfig

    config = MuxConfig(
        profiles={
            "budget": Profile(
                description="Cheap",
                providers={"codex": ProviderConfig(model="mini", base_url="https://x.com")},
            ),
        },
    )
    ns = MagicMock()
    ns.name = "budget"
    ns.json = False

    with patch("vyane.config.load_config", return_value=config):
        _cmd_profile(ns)

    captured = capsys.readouterr()
    assert "budget" in captured.out
    assert "model=mini" in captured.out
    assert "url=https://x.com" in captured.out


# ── _cmd_benchmark tests ──


def test_benchmark_list_tasks(capsys):
    """benchmark --list-tasks should list available tasks."""
    from vyane.cli import _cmd_benchmark

    ns = MagicMock()
    ns.list_tasks = True
    ns.providers = None
    ns.tasks = None
    ns.timeout = 120
    ns.output = ""

    fake_tasks = {
        "code_review": {"category": "code", "description": "Review code quality"},
    }
    with patch("vyane.benchmark.BENCHMARK_TASKS", fake_tasks):
        _cmd_benchmark(ns)

    captured = capsys.readouterr()
    assert "code_review" in captured.out
    assert "code" in captured.out


def test_benchmark_run(capsys):
    """benchmark should run and print report."""
    from vyane.cli import _cmd_benchmark

    ns = MagicMock()
    ns.list_tasks = False
    ns.providers = ["codex"]
    ns.tasks = None
    ns.timeout = 60
    ns.output = ""

    with (
        patch("vyane.benchmark.BENCHMARK_TASKS", {}),
        patch("vyane.benchmark.run_benchmark", return_value={"results": []}),
        patch("vyane.benchmark.format_report", return_value="Report output"),
        patch("vyane.benchmark.save_report") as mock_save,
        patch("vyane.paths.resolve_user_write_path") as mock_path,
    ):
        mock_p = MagicMock()
        mock_p.parent = MagicMock()
        mock_path.return_value = mock_p
        _cmd_benchmark(ns)

    captured = capsys.readouterr()
    assert "Report output" in captured.out
    assert "Vyane Benchmark" in captured.out


def test_benchmark_with_output(capsys, tmp_path):
    """benchmark --output saves to file."""
    from vyane.cli import _cmd_benchmark

    out_file = str(tmp_path / "bench.json")
    ns = MagicMock()
    ns.list_tasks = False
    ns.providers = None
    ns.tasks = ["code_review"]
    ns.timeout = 120
    ns.output = out_file

    with (
        patch("vyane.benchmark.BENCHMARK_TASKS", {}),
        patch("vyane.benchmark.run_benchmark", return_value={}),
        patch("vyane.benchmark.format_report", return_value="Report"),
        patch("vyane.benchmark.save_report") as mock_save,
        patch("vyane.paths.resolve_user_write_path") as mock_path,
    ):
        mock_p = MagicMock()
        mock_p.parent = MagicMock()
        mock_path.return_value = mock_p
        _cmd_benchmark(ns)

    captured = capsys.readouterr()
    assert f"Results saved to {out_file}" in captured.out
    # save_report called twice: once for --output, once for routing
    assert mock_save.call_count == 2


# ── _cmd_dashboard tests ──


def test_dashboard(capsys):
    """dashboard should call run_dashboard."""
    from vyane.cli import _cmd_dashboard

    ns = MagicMock()
    ns.host = "127.0.0.1"
    ns.port = 41521

    with patch("vyane.dashboard.run_dashboard") as mock_run:
        _cmd_dashboard(ns)
        mock_run.assert_called_once_with(host="127.0.0.1", port=41521)


# ── _cmd_a2a_server tests ──


def test_a2a_server(capsys):
    """a2a-server should set up and run."""
    from vyane.cli import _cmd_a2a_server

    ns = MagicMock()
    ns.host = "0.0.0.0"
    ns.port = 41520
    ns.workdir = "/tmp"
    ns.sandbox = "read-only"
    ns.token = "secret"
    ns.no_persist = False

    mock_server = MagicMock()

    with (
        patch("vyane.config.find_user_config_file", return_value=None),
        patch("vyane.config._find_config_file", return_value=None),
        patch("vyane.a2a.http_server.A2AServer", return_value=mock_server) as mock_cls,
        patch("vyane.paths.resolve_user_write_path") as mock_path,
    ):
        mock_p = MagicMock()
        mock_p.parent = MagicMock()
        mock_path.return_value = mock_p
        _cmd_a2a_server(ns)

    mock_server.run.assert_called_once()
    captured = capsys.readouterr()
    assert "A2A server" in captured.out
    assert "Bearer token enabled" in captured.out


def test_a2a_server_no_auth_no_persist(capsys):
    """a2a-server without token and with --no-persist."""
    from vyane.cli import _cmd_a2a_server

    ns = MagicMock()
    ns.host = "127.0.0.1"
    ns.port = 41520
    ns.workdir = "."
    ns.sandbox = "write"
    ns.token = ""
    ns.no_persist = True

    mock_server = MagicMock()

    with (
        patch("vyane.config.find_user_config_file", return_value=None),
        patch("vyane.config._find_config_file", return_value=None),
        patch("vyane.a2a.http_server.A2AServer", return_value=mock_server) as mock_cls,
        patch.dict(os.environ, {}, clear=False),
    ):
        # Ensure env vars are not set
        os.environ.pop("VYANE_A2A_TOKEN", None)
        os.environ.pop("MODELMUX_A2A_TOKEN", None)
        _cmd_a2a_server(ns)

    captured = capsys.readouterr()
    assert "disabled (open access)" in captured.out
    # persist_path should be empty
    call_kwargs = mock_cls.call_args[1]
    assert call_kwargs["persist_path"] == ""


def test_a2a_server_with_custom_providers(capsys):
    """a2a-server loads custom providers from config files."""
    from vyane.cli import _cmd_a2a_server

    ns = MagicMock()
    ns.host = "127.0.0.1"
    ns.port = 41520
    ns.workdir = "."
    ns.sandbox = "read-only"
    ns.token = ""
    ns.no_persist = True

    mock_server = MagicMock()

    with (
        patch(
            "vyane.config.find_user_config_file", return_value="/fake/config.toml"
        ),
        patch("vyane.config._find_config_file", return_value=None),
        patch("vyane.config._load_file", return_value={"providers": {}}),
        patch("vyane.adapters.load_custom_providers") as mock_load,
        patch("vyane.a2a.http_server.A2AServer", return_value=mock_server),
        patch.dict(os.environ, {}, clear=False),
    ):
        os.environ.pop("VYANE_A2A_TOKEN", None)
        os.environ.pop("MODELMUX_A2A_TOKEN", None)
        _cmd_a2a_server(ns)

    mock_load.assert_called_once()


# ── _cmd_session tests ──


def test_session_no_action(capsys):
    """session with no action should exit 1."""
    from vyane.cli import _cmd_session

    ns = MagicMock()
    ns.session_action = ""
    ns._session_parser = None

    with pytest.raises(SystemExit) as exc_info:
        _cmd_session(ns)
    assert exc_info.value.code == 1


def test_session_create(capsys):
    """session create should create a new session."""
    from vyane.cli import _cmd_session
    from vyane.session import SessionState

    ns = MagicMock()
    ns.session_action = "create"
    ns.title = "Test Session"
    ns.description = "A test"

    fake_session = SessionState(
        id="test-session",
        title="Test Session",
        description="A test",
        created_at=1000.0,
        updated_at=1000.0,
    )

    with patch("vyane.session.create_session", return_value=fake_session):
        _cmd_session(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["status"] == "success"
    assert data["session"]["title"] == "Test Session"


def test_session_create_no_title(capsys):
    """session create without title should exit 1."""
    from vyane.cli import _cmd_session

    ns = MagicMock()
    ns.session_action = "create"
    ns.title = ""

    with pytest.raises(SystemExit) as exc_info:
        _cmd_session(ns)
    assert exc_info.value.code == 1


def test_session_list(capsys):
    """session list should list sessions."""
    from vyane.cli import _cmd_session
    from vyane.session import SessionState

    ns = MagicMock()
    ns.session_action = "list"
    ns.status = "active"

    sessions = [
        SessionState(id="s1", title="First", created_at=1.0, updated_at=1.0),
    ]

    with patch("vyane.session.list_sessions", return_value=sessions):
        _cmd_session(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["count"] == 1
    assert data["sessions"][0]["title"] == "First"


def test_session_history(capsys):
    """session history should show session details."""
    from vyane.cli import _cmd_session
    from vyane.session import SessionState

    ns = MagicMock()
    ns.session_action = "history"
    ns.session_id = "s1"

    fake_session = SessionState(
        id="s1",
        title="Test",
        created_at=1.0,
        updated_at=1.0,
        dispatches=[{"run_id": "r1", "status": "success"}],
    )

    with patch("vyane.session.load_session", return_value=fake_session):
        _cmd_session(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["status"] == "success"
    assert len(data["dispatches"]) == 1


def test_session_archive(capsys):
    """session archive should archive session."""
    from vyane.cli import _cmd_session
    from vyane.session import SessionState

    ns = MagicMock()
    ns.session_action = "archive"
    ns.session_id = "s1"

    fake_session = SessionState(
        id="s1", title="Test", created_at=1.0, updated_at=1.0, status="active"
    )
    archived_session = SessionState(
        id="s1", title="Test", created_at=1.0, updated_at=2.0, status="archived"
    )

    with (
        patch("vyane.session.load_session", side_effect=[fake_session, archived_session]),
        patch("vyane.session.archive_session") as mock_archive,
    ):
        _cmd_session(ns)

    mock_archive.assert_called_once_with("s1")
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["status"] == "success"


def test_session_not_found(capsys):
    """session history for nonexistent session should exit 1."""
    from vyane.cli import _cmd_session

    ns = MagicMock()
    ns.session_action = "history"
    ns.session_id = "nonexistent"

    with (
        patch("vyane.session.load_session", return_value=None),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_session(ns)
    assert exc_info.value.code == 1


def test_session_unknown_action(capsys):
    """session with unknown action should exit 1."""
    from vyane.cli import _cmd_session
    from vyane.session import SessionState

    ns = MagicMock()
    ns.session_action = "unknown"
    ns.session_id = "s1"

    fake_session = SessionState(
        id="s1", title="Test", created_at=1.0, updated_at=1.0
    )

    with (
        patch("vyane.session.load_session", return_value=fake_session),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_session(ns)
    assert exc_info.value.code == 1


# ── _cmd_dispatch session-related tests ──


def test_dispatch_with_session(capsys):
    """dispatch --vyane-session should include session context."""
    from vyane.cli import _cmd_dispatch
    from vyane.session import SessionState

    ns = _dispatch_ns(task=["test"], vyane_session="ses-1")
    fake_result = AdapterResult(
        run_id="r9", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    fake_session = SessionState(
        id="ses-1",
        title="My Session",
        created_at=1.0,
        updated_at=1.0,
        context_summary="Previous context here",
        provider_sessions={"codex": "prev-session-id"},
    )

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        patch("vyane.session.load_session", return_value=fake_session),
        patch("vyane.session.add_dispatch_to_session") as mock_add,
    ):
        _cmd_dispatch(ns)

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["vyane_session"] == "ses-1"
    # Check that session context was included in prompt
    call_kwargs = mock_adapter.run.call_args[1]
    assert "Previous context here" in call_kwargs["prompt"]
    assert call_kwargs["session_id"] == "prev-session-id"
    mock_add.assert_called_once()


def test_dispatch_with_missing_session(capsys):
    """dispatch --vyane-session with nonexistent session should exit 1."""
    from vyane.cli import _cmd_dispatch

    ns = _dispatch_ns(task=["test"], vyane_session="nonexistent")
    mock_adapter = _make_adapter(available=True)

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        patch("vyane.session.load_session", return_value=None),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_dispatch(ns)
    assert exc_info.value.code == 1


# ── _cmd_config tests ──


def test_cmd_config_import_error(capsys):
    """_cmd_config with missing textual should exit 1."""
    import importlib

    from vyane import cli as cli_module

    ns = MagicMock()
    ns.scope = "user"

    original = cli_module._cmd_config

    # Temporarily replace to test ImportError path directly
    def patched_config(args):
        raise ImportError("No module named 'textual'")

    with pytest.raises(ImportError):
        patched_config(ns)


def test_cmd_config_success():
    """_cmd_config with textual available should call run_tui."""
    from vyane.cli import _cmd_config

    ns = MagicMock()
    ns.scope = "user"

    mock_tui = MagicMock()
    with patch.dict("sys.modules", {"vyane.tui": mock_tui}):
        with patch("vyane.cli._cmd_config") as mock_fn:
            mock_fn(ns)
            mock_fn.assert_called_once_with(ns)


# ── status with active dispatch rendering ──


def test_status_with_failover_and_preview(capsys):
    """status shows failover icon and output preview."""
    import time

    from vyane.cli import _cmd_status
    from vyane.status import DispatchStatus

    ns = MagicMock()
    ns.watch = False

    active = [
        DispatchStatus(
            run_id="xyz789",
            provider="gemini",
            task_summary="complex analysis",
            status="running",
            started_at=time.time() - 5,
            failover_from="codex",
            output_preview="Processing step 2...",
        ),
    ]

    with patch("vyane.status.list_active", return_value=active):
        _cmd_status(ns)

    captured = capsys.readouterr()
    assert "xyz789" in captured.out
    assert "Processing step 2" in captured.out


# ── _apply_profile with wire_api and env_overrides ──


def test_apply_profile_with_wire_api():
    """_apply_profile with wire_api should set it in extra."""
    from vyane.cli import _apply_profile
    from vyane.config import MuxConfig, Profile, ProviderConfig

    config = MuxConfig(
        profiles={
            "test": Profile(
                providers={
                    "codex": ProviderConfig(
                        model="custom",
                        wire_api="openai",
                    )
                },
            ),
        },
    )

    with patch("vyane.config.load_config", return_value=config):
        extra, env = _apply_profile("codex", "", "test")
        assert extra["model"] == "custom"
        assert extra["wire_api"] == "openai"


# ── clean directory branch ──


def test_clean_directory(capsys, tmp_path):
    """clean should handle status directory with JSON files."""
    from vyane.cli import _cmd_clean

    cfg = tmp_path / ".config" / "vyane"
    status_dir = cfg / "status"
    status_dir.mkdir(parents=True)
    (status_dir / "run1.json").write_text('{"id": "run1"}')
    (status_dir / "run2.json").write_text('{"id": "run2"}')

    ns = MagicMock()
    ns.what = "all"
    ns.dry_run = False

    with patch("pathlib.Path.home", return_value=tmp_path):
        with patch("vyane.paths.resolve_user_write_path", return_value=cfg):
            _cmd_clean(ns)

    assert not list(status_dir.glob("*.json"))
    captured = capsys.readouterr()
    assert "Cleaned" in captured.out


def test_clean_directory_dry_run(capsys, tmp_path):
    """clean --dry-run on directory should not delete files."""
    from vyane.cli import _cmd_clean

    cfg = tmp_path / ".config" / "vyane"
    status_dir = cfg / "status"
    status_dir.mkdir(parents=True)
    (status_dir / "run1.json").write_text('{"id": "run1"}')

    ns = MagicMock()
    ns.what = "all"
    ns.dry_run = True

    with patch("pathlib.Path.home", return_value=tmp_path):
        with patch("vyane.paths.resolve_user_write_path", return_value=cfg):
            _cmd_clean(ns)

    assert (status_dir / "run1.json").exists()
    captured = capsys.readouterr()
    assert "Would remove" in captured.out


# ── profile not found with --json ──


def test_profile_not_found_json(capsys):
    """profile <unknown> --json should output JSON error and exit 1."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig

    ns = MagicMock()
    ns.name = "nonexistent"
    ns.json = True

    with (
        patch("vyane.config.load_config", return_value=MuxConfig()),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_profile(ns)
    assert exc_info.value.code == 1

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert "error" in data


# ── profile show text with no providers ──


def test_profile_show_text_no_providers(capsys):
    """profile <name> text mode with no providers shows message."""
    from vyane.cli import _cmd_profile
    from vyane.config import MuxConfig, Profile

    config = MuxConfig(
        profiles={
            "empty": Profile(description="Empty profile", providers={}),
        },
    )
    ns = MagicMock()
    ns.name = "empty"
    ns.json = False

    with patch("vyane.config.load_config", return_value=config):
        _cmd_profile(ns)

    captured = capsys.readouterr()
    assert "no provider overrides" in captured.out


# ── main() routing tests ──


def test_main_dispatch_route(capsys):
    """main() with 'dispatch' routes to _cmd_dispatch."""
    import sys as sys_mod

    from vyane.cli import main

    fake_result = AdapterResult(
        run_id="m1", provider="codex", status="success", output="done"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    with (
        patch.object(sys_mod, "argv", ["vyane", "dispatch", "hello"]),
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
    ):
        main()

    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["status"] == "success"


def test_main_benchmark_route(capsys):
    """main() with 'benchmark --list-tasks' routes correctly."""
    import sys as sys_mod

    from vyane.cli import main

    with (
        patch.object(sys_mod, "argv", ["vyane", "benchmark", "--list-tasks"]),
        patch(
            "vyane.benchmark.BENCHMARK_TASKS",
            {"test_task": {"category": "test", "description": "A test"}},
        ),
    ):
        main()

    captured = capsys.readouterr()
    assert "test_task" in captured.out


def test_main_session_route(capsys):
    """main() with 'session list' routes to _cmd_session."""
    import sys as sys_mod

    from vyane.cli import main
    from vyane.session import SessionState

    with (
        patch.object(sys_mod, "argv", ["vyane", "session", "list"]),
        patch("vyane.session.list_sessions", return_value=[]),
    ):
        main()

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["count"] == 0


def test_main_dashboard_route():
    """main() with 'dashboard' routes to _cmd_dashboard."""
    import sys as sys_mod

    from vyane.cli import main

    with (
        patch.object(sys_mod, "argv", ["vyane", "dashboard"]),
        patch("vyane.dashboard.run_dashboard") as mock_run,
    ):
        main()

    mock_run.assert_called_once()


def test_main_no_command():
    """main() with no command runs server."""
    import sys as sys_mod

    from vyane.cli import main

    with (
        patch.object(sys_mod, "argv", ["vyane"]),
        patch("vyane.server.mcp") as mock_mcp,
    ):
        main()

    mock_mcp.run.assert_called_once_with(transport="stdio")


def test_main_unknown_command():
    """main() with unknown command exits 1."""
    import sys as sys_mod

    from vyane.cli import main

    with (
        patch.object(sys_mod, "argv", ["vyane", "nonexistent"]),
        pytest.raises(SystemExit) as exc_info,
    ):
        main()
    assert exc_info.value.code in (1, 2)  # argparse may exit with 2


def test_main_monitor_import_error(capsys):
    """main() with 'monitor' and missing textual exits 1."""
    import sys as sys_mod

    from vyane.cli import main

    with (
        patch.object(sys_mod, "argv", ["vyane", "monitor"]),
        patch.dict("sys.modules", {"vyane.monitor": None}),
        pytest.raises(SystemExit) as exc_info,
    ):
        main()
    assert exc_info.value.code == 1

    captured = capsys.readouterr()
    assert "textual" in captured.out


# ── broadcast exception handling ──


def test_broadcast_exception_in_provider(capsys):
    """broadcast handles exceptions from providers gracefully."""
    from vyane.cli import _cmd_broadcast

    ns = _broadcast_ns(task=["test"])

    mock_adapter = _make_adapter(available=True)
    mock_adapter.run = AsyncMock(side_effect=RuntimeError("connection failed"))

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        pytest.raises(SystemExit) as exc_info,
    ):
        _cmd_broadcast(ns)

    assert exc_info.value.code == 1
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["results"][0]["status"] == "error"
    assert "connection failed" in data["results"][0]["error"]


# ── broadcast env_overrides branch ──


def test_broadcast_with_profile(capsys):
    """broadcast with profile applies env overrides."""
    from vyane.cli import _cmd_broadcast
    from vyane.config import MuxConfig, Profile, ProviderConfig

    ns = _broadcast_ns(task=["test"], profile="custom")
    fake_result = AdapterResult(
        run_id="b1", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    config = MuxConfig(
        profiles={
            "custom": Profile(
                providers={
                    "codex": ProviderConfig(
                        model="fast-model",
                        base_url="https://custom.api",
                    )
                },
            ),
        },
    )

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        patch("vyane.config.load_config", return_value=config),
    ):
        _cmd_broadcast(ns)

    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert data["results"][0]["status"] == "success"


# ── _read_task from stdin ──


def test_read_task_from_stdin():
    """_read_task reads from stdin when no positional args."""
    from vyane.cli import _read_task

    ns = MagicMock()
    ns.task = []

    with patch("sys.stdin", MagicMock(read=MagicMock(return_value="stdin task\n"))):
        result = _read_task(ns)
    assert result == "stdin task"


# ── dispatch with env_overrides ──


def test_dispatch_with_env_overrides(capsys):
    """dispatch with profile having base_url sets env_overrides."""
    from vyane.cli import _cmd_dispatch
    from vyane.config import MuxConfig, Profile, ProviderConfig

    ns = _dispatch_ns(task=["test"], profile="custom")
    fake_result = AdapterResult(
        run_id="r10", provider="codex", status="success", output="ok"
    )
    mock_adapter = _make_adapter(available=True, result=fake_result)

    config = MuxConfig(
        profiles={
            "custom": Profile(
                providers={
                    "codex": ProviderConfig(
                        model="custom-model",
                        base_url="https://custom.api",
                    )
                },
            ),
        },
    )

    with (
        patch(
            "vyane.adapters.get_all_adapters",
            return_value={"codex": mock_adapter},
        ),
        patch("vyane.config.load_config", return_value=config),
    ):
        _cmd_dispatch(ns)

    call_kwargs = mock_adapter.run.call_args[1]
    assert "env_overrides" in call_kwargs
