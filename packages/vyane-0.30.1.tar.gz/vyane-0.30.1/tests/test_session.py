"""Tests for persistent Vyane task sessions."""

import fcntl
import json
import threading
import time
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from vyane.adapters.base import AdapterResult, BaseAdapter


@pytest.fixture
def session_state_dir(tmp_path, monkeypatch):
    """Redirect persistent session storage into a temporary directory."""
    import vyane.session as session_module

    session_dir = tmp_path / "sessions"
    monkeypatch.setattr(session_module, "_session_state_dir", lambda: session_dir)
    monkeypatch.setattr(session_module, "_session_search_dirs", lambda: (session_dir,))
    return session_dir


class FakeContext:
    """Minimal MCP context for server tool tests."""

    def __init__(self):
        self._request_context = None
        self.session = None
        self._messages = []

    async def info(self, msg):
        self._messages.append(("info", msg))

    async def warning(self, msg):
        self._messages.append(("warning", msg))


class CaptureAdapter(BaseAdapter):
    """Adapter stub that records prompts and session ids."""

    provider_name = "codex"

    def __init__(self, output="session ok", status="success", session_id="sess-new"):
        self.output = output
        self.status = status
        self.session_id = session_id
        self.calls = []

    def _binary_name(self):
        return "codex"

    def check_available(self):
        return True

    def build_command(
        self,
        prompt,
        workdir,
        sandbox="",
        session_id="",
        extra_args=None,
    ):
        return ["echo", prompt]

    def parse_output(self, lines):
        return "\n".join(lines), "", ""

    async def run(self, prompt="", **kwargs):
        self.calls.append({"prompt": prompt, **kwargs})
        return AdapterResult(
            run_id="run-1",
            provider=self.provider_name,
            status=self.status,
            output=self.output,
            summary=self.output,
            session_id=self.session_id,
            duration_seconds=1.2,
        )


def _dispatch_ns(**overrides):
    defaults = {
        "provider": "codex",
        "model": "",
        "sandbox": "read-only",
        "timeout": 300,
        "workdir": ".",
        "task": ["test"],
        "max_retries": 1,
        "failover": False,
        "profile": "",
        "vyane_session": "",
    }
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def test_create_load_list_archive(session_state_dir):
    from vyane.session import (
        archive_session,
        create_session,
        list_sessions,
        load_session,
        update_context_summary,
    )

    session = create_session("MER 96 Session", description="track follow-up")
    assert (session_state_dir / f"{session.id}.json").exists()
    assert session.status == "active"

    update_context_summary(session.id, "previous work and decisions")

    loaded = load_session(session.id)
    assert loaded is not None
    assert loaded.title == "MER 96 Session"
    assert loaded.description == "track follow-up"
    assert loaded.context_summary == "previous work and decisions"

    active_sessions = list_sessions()
    assert [item.id for item in active_sessions] == [session.id]

    archive_session(session.id)
    archived = load_session(session.id)
    assert archived is not None
    assert archived.status == "archived"
    assert list_sessions() == []
    assert [item.id for item in list_sessions(status="archived")] == [session.id]


def test_add_dispatch_to_session_updates_history_and_provider_sessions(
    session_state_dir,
):
    from vyane.session import add_dispatch_to_session, create_session, load_session

    session = create_session("Dispatch History")
    dispatch = {
        "run_id": "run-123",
        "provider": "codex",
        "status": "success",
        "summary": "done",
        "output": "done",
        "session_id": "thread-abc",
    }

    add_dispatch_to_session(session.id, dispatch)

    loaded = load_session(session.id)
    assert loaded is not None
    assert loaded.dispatches == [dispatch]
    assert loaded.provider_sessions == {"codex": "thread-abc"}


def test_add_dispatch_to_session_waits_for_session_lock(session_state_dir):
    import vyane.session as session_module
    from vyane.session import add_dispatch_to_session, create_session, load_session

    session = create_session("Locked Dispatch")
    dispatch = {
        "run_id": "run-lock",
        "provider": "codex",
        "status": "success",
        "summary": "done",
        "output": "done",
        "session_id": "thread-lock",
    }
    started = threading.Event()
    finished = threading.Event()

    def worker():
        started.set()
        add_dispatch_to_session(session.id, dispatch)
        finished.set()

    lock_path = session_module._session_lock_path(session.id)
    with lock_path.open("a+", encoding="utf-8") as lock_file:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        thread = threading.Thread(target=worker)
        thread.start()
        assert started.wait(timeout=1)
        time.sleep(0.2)

        loaded = load_session(session.id)
        assert loaded is not None
        assert loaded.dispatches == []
        assert not finished.is_set()

        fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)

    thread.join(timeout=1)
    assert finished.is_set()

    loaded = load_session(session.id)
    assert loaded is not None
    assert loaded.dispatches == [dispatch]
    assert loaded.provider_sessions == {"codex": "thread-lock"}


@pytest.mark.asyncio
async def test_server_dispatch_injects_session_context_and_persists_history(
    session_state_dir,
):
    from vyane.server import mux_dispatch
    from vyane.session import (
        add_dispatch_to_session,
        create_session,
        load_session,
        update_context_summary,
    )

    session = create_session("Server Session")
    update_context_summary(session.id, "shared design context")
    add_dispatch_to_session(
        session.id,
        {
            "run_id": "run-old",
            "provider": "codex",
            "status": "success",
            "output": "before",
            "summary": "before",
            "session_id": "sess-old",
        },
    )

    adapter = CaptureAdapter(output="server result", session_id="sess-new")
    ctx = FakeContext()

    with (
        patch("vyane.server._ensure_custom_providers_loaded"),
        patch(
            "vyane.server.load_config",
            return_value=MagicMock(
                active_profile="default",
                profiles={},
                disabled_providers=[],
                routing_rules=[],
                default_provider="codex",
                auto_exclude_caller=True,
                caller_override="",
            ),
        ),
        patch(
            "vyane.server._detect_and_build_exclusions",
            return_value=(
                SimpleNamespace(provider="", client_name="test", platform=""),
                [],
            ),
        ),
        patch("vyane.server.classify_intent") as mock_intent,
        patch("vyane.server.get_category_binding", return_value=None),
        patch("vyane.server.load_policy", return_value=MagicMock(security={})),
        patch("vyane.server.check_policy", return_value=MagicMock(allowed=True)),
        patch("vyane.server.count_recent", return_value=0),
        patch(
            "vyane.server.scan_task",
            return_value=MagicMock(passed=True, findings=[], action=None),
        ) as mock_scan,
        patch("vyane.server._get_adapter", return_value=adapter),
        patch("vyane.server.write_status"),
        patch("vyane.server.remove_status"),
        patch("vyane.server.log_dispatch"),
        patch("vyane.server.log_result"),
    ):
        mock_intent.return_value = SimpleNamespace(
            primary=SimpleNamespace(value="analysis"),
            confidence=0.0,
            signals=[],
        )
        result = await mux_dispatch(
            provider="codex",
            task="continue the implementation",
            ctx=ctx,
            vyane_session=session.id,
        )

    data = json.loads(result)
    assert data["status"] == "success"
    assert data["vyane_session"] == session.id

    adapter_call = adapter.calls[0]
    expected_prompt = "[Context: shared design context]\n\ncontinue the implementation"
    assert adapter_call["prompt"] == expected_prompt
    assert adapter_call["session_id"] == "sess-old"
    mock_intent.assert_called_once_with(expected_prompt)
    mock_scan.assert_called_once_with(expected_prompt, policy_overrides={})

    loaded = load_session(session.id)
    assert loaded is not None
    assert len(loaded.dispatches) == 2
    assert loaded.dispatches[-1]["output"] == "server result"
    assert loaded.provider_sessions["codex"] == "sess-new"


@pytest.mark.asyncio
async def test_server_dispatch_auto_decompose_persists_session_history(
    session_state_dir,
):
    from vyane.server import mux_dispatch
    from vyane.session import create_session, load_session

    session = create_session("Decompose Session")
    ctx = FakeContext()
    adapter = MagicMock()
    adapter.check_available.return_value = True
    decompose_result = json.dumps(
        {
            "status": "success",
            "provider": "codex",
            "decomposed": True,
            "output": "merged plan",
            "summary": "merged plan",
            "session_id": "decomp-sess",
        }
    )

    with (
        patch("vyane.server._ensure_custom_providers_loaded"),
        patch(
            "vyane.server.load_config",
            return_value=MagicMock(
                active_profile="default",
                profiles={},
                disabled_providers=[],
                routing_rules=[],
                default_provider="codex",
                auto_exclude_caller=True,
                caller_override="",
            ),
        ),
        patch(
            "vyane.server._detect_and_build_exclusions",
            return_value=(
                SimpleNamespace(provider="", client_name="test", platform=""),
                [],
            ),
        ),
        patch("vyane.server._get_adapter", return_value=adapter),
        patch("vyane.server.classify_intent") as mock_intent,
        patch("vyane.server.get_category_binding", return_value=None),
        patch("vyane.server.load_policy", return_value=MagicMock(security={})),
        patch("vyane.server.check_policy", return_value=MagicMock(allowed=True)),
        patch("vyane.server.count_recent", return_value=0),
        patch(
            "vyane.server.scan_task",
            return_value=MagicMock(passed=True, findings=[], action=None),
        ),
        patch(
            "vyane.server._auto_decompose_task",
            return_value=decompose_result,
        ),
    ):
        mock_intent.return_value = SimpleNamespace(
            primary=SimpleNamespace(value="analysis"),
            confidence=0.0,
            signals=[],
        )
        result = await mux_dispatch(
            provider="codex",
            task="complex task",
            ctx=ctx,
            auto_decompose=True,
            vyane_session=session.id,
        )

    data = json.loads(result)
    assert data["decomposed"] is True
    assert data["vyane_session"] == session.id

    loaded = load_session(session.id)
    assert loaded is not None
    assert loaded.dispatches[-1]["output"] == "merged plan"
    assert loaded.provider_sessions["codex"] == "decomp-sess"


@pytest.mark.asyncio
async def test_server_dispatch_failover_clears_provider_session_resume_id(
    session_state_dir,
):
    from vyane.server import mux_dispatch
    from vyane.session import add_dispatch_to_session, create_session, load_session

    session = create_session("Failover Session")
    add_dispatch_to_session(
        session.id,
        {
            "run_id": "run-gemini-old",
            "provider": "gemini",
            "status": "success",
            "output": "old output",
            "summary": "old output",
            "session_id": "gemini-old",
        },
    )

    failing = CaptureAdapter(output="", status="error", session_id="")
    failing.provider_name = "codex"
    fallback = CaptureAdapter(output="recovered", session_id="gemini-new")
    fallback.provider_name = "gemini"
    ctx = FakeContext()

    def mock_get_adapter(name):
        if name == "codex":
            return failing
        return fallback

    with (
        patch("vyane.server._ensure_custom_providers_loaded"),
        patch(
            "vyane.server.load_config",
            return_value=MagicMock(
                active_profile="default",
                profiles={},
                disabled_providers=[],
                routing_rules=[],
                default_provider="codex",
                auto_exclude_caller=True,
                caller_override="",
            ),
        ),
        patch(
            "vyane.server._detect_and_build_exclusions",
            return_value=(
                SimpleNamespace(provider="", client_name="test", platform=""),
                [],
            ),
        ),
        patch("vyane.server.classify_intent") as mock_intent,
        patch("vyane.server.get_category_binding", return_value=None),
        patch("vyane.server.load_policy", return_value=MagicMock(security={})),
        patch("vyane.server.check_policy", return_value=MagicMock(allowed=True)),
        patch("vyane.server.count_recent", return_value=0),
        patch(
            "vyane.server.scan_task",
            return_value=MagicMock(passed=True, findings=[], action=None),
        ),
        patch("vyane.server._get_adapter", side_effect=mock_get_adapter),
        patch("vyane.server.write_status"),
        patch("vyane.server.remove_status"),
        patch("vyane.server.log_dispatch"),
        patch("vyane.server.log_result"),
        patch("vyane.server._get_fallback_candidates", return_value=["gemini"]),
    ):
        mock_intent.return_value = SimpleNamespace(
            primary=SimpleNamespace(value="analysis"),
            confidence=0.0,
            signals=[],
        )
        result = await mux_dispatch(
            provider="codex",
            task="retry elsewhere",
            ctx=ctx,
            failover=True,
            vyane_session=session.id,
        )

    data = json.loads(result)
    assert data["status"] == "success"
    assert data["failover_from"] == "codex"
    assert fallback.calls[0]["session_id"] == ""

    loaded = load_session(session.id)
    assert loaded is not None
    assert loaded.provider_sessions["gemini"] == "gemini-new"


def test_cli_session_subcommands(session_state_dir, capsys):
    from vyane.cli import _cmd_session

    _cmd_session(
        SimpleNamespace(
            session_action="create",
            title="CLI Session",
            description="from cli",
        )
    )
    created = json.loads(capsys.readouterr().out)
    session_id = created["session"]["id"]

    _cmd_session(SimpleNamespace(session_action="list", status="active"))
    listed = json.loads(capsys.readouterr().out)
    assert listed["count"] == 1
    assert listed["sessions"][0]["id"] == session_id

    _cmd_session(SimpleNamespace(session_action="history", session_id=session_id))
    history = json.loads(capsys.readouterr().out)
    assert history["session"]["id"] == session_id
    assert history["dispatches"] == []

    _cmd_session(SimpleNamespace(session_action="archive", session_id=session_id))
    archived = json.loads(capsys.readouterr().out)
    assert archived["session"]["status"] == "archived"


def test_cli_session_without_action_prints_help_and_exits(session_state_dir):
    from vyane.cli import _cmd_session

    session_parser = MagicMock()

    with pytest.raises(SystemExit) as exc:
        _cmd_session(
            SimpleNamespace(
                session_action=None,
                session_id="",
                _session_parser=session_parser,
            )
        )

    assert exc.value.code == 1
    session_parser.print_help.assert_called_once_with()


def test_cli_dispatch_uses_persistent_session(session_state_dir, capsys):
    from vyane.cli import _cmd_dispatch
    from vyane.session import (
        add_dispatch_to_session,
        create_session,
        load_session,
        update_context_summary,
    )

    session = create_session("CLI Dispatch Session")
    update_context_summary(session.id, "existing topic context")
    add_dispatch_to_session(
        session.id,
        {
            "run_id": "run-old",
            "provider": "codex",
            "status": "success",
            "output": "old",
            "summary": "old",
            "session_id": "cli-sess-old",
        },
    )

    mock_adapter = MagicMock(spec=BaseAdapter)
    mock_adapter.check_available.return_value = True
    mock_adapter.run = AsyncMock(
        return_value=AdapterResult(
            run_id="run-new",
            provider="codex",
            status="success",
            output="cli result",
            summary="cli result",
            session_id="cli-sess-new",
            duration_seconds=0.8,
        )
    )

    with patch(
        "vyane.adapters.get_all_adapters",
        return_value={"codex": mock_adapter},
    ):
        _cmd_dispatch(
            _dispatch_ns(
                task=["finish", "the", "task"],
                vyane_session=session.id,
            )
        )

    output = json.loads(capsys.readouterr().out)
    assert output["status"] == "success"
    assert output["vyane_session"] == session.id

    call_kwargs = mock_adapter.run.call_args.kwargs
    assert call_kwargs["prompt"] == (
        "finish the task\n\n[Context: existing topic context]"
    )
    assert call_kwargs["session_id"] == "cli-sess-old"

    loaded = load_session(session.id)
    assert loaded is not None
    assert loaded.dispatches[-1]["output"] == "cli result"
    assert loaded.provider_sessions["codex"] == "cli-sess-new"


@pytest.mark.asyncio
async def test_mux_session_list_accepts_status_filter(session_state_dir):
    from vyane.server import mux_session
    from vyane.session import archive_session, create_session

    active = create_session("Active Session")
    archived = create_session("Archived Session")
    archive_session(archived.id)

    active_result = json.loads(await mux_session(action="list"))
    archived_result = json.loads(await mux_session(action="list", status="archived"))

    assert active_result["count"] == 1
    assert active_result["sessions"][0]["id"] == active.id
    assert archived_result["count"] == 1
    assert archived_result["sessions"][0]["id"] == archived.id


def test_atomic_write_and_id_validation(session_state_dir, monkeypatch):
    import vyane.session as session_module

    replace_calls = []
    real_replace = session_module.os.replace

    def spy_replace(src, dst):
        replace_calls.append((src, dst))
        return real_replace(src, dst)

    monkeypatch.setattr(session_module.os, "replace", spy_replace)

    session = session_module.create_session("Atomic Session")
    assert replace_calls
    temp_path, final_path = replace_calls[0]
    assert session_state_dir == final_path.parent
    assert session_state_dir == temp_path.parent
    assert final_path == session_state_dir / f"{session.id}.json"
    assert temp_path != final_path

    with pytest.raises(ValueError):
        session_module._validate_session_id("bad_id")
    with pytest.raises(ValueError):
        session_module._save_session(
            session_module.SessionState(id="../escape", title="invalid")
        )
    assert session_module.load_session("../escape") is None
