"""JSONL persistence for mux_orchestrate tasks."""

from __future__ import annotations

import copy
import fcntl
import json
import logging
import os
import re
import tempfile
from collections import OrderedDict
from pathlib import Path
from typing import Iterable

from vyane.orchestrate import OrchestratedTask
from vyane.paths import resolve_user_write_path

logger = logging.getLogger(__name__)


def _store_file() -> Path:
    return resolve_user_write_path("orchestrate_tasks.jsonl")


class OrchestrateStore:
    """JSONL task store with atomic latest-snapshot persistence."""

    def __init__(self, path: Path | None = None, max_bytes: int = 5 * 1024 * 1024):
        self._path = path or _store_file()
        self._max_bytes = max_bytes
        self._tasks: dict[str, OrchestratedTask] = {}
        self._loaded = False

    def next_task_id(self) -> str:
        """Generate the next T### identifier."""
        self._ensure_loaded()
        current_max = 0
        for task_id in self._tasks:
            match = re.fullmatch(r"T(\d+)", task_id)
            if match:
                current_max = max(current_max, int(match.group(1)))
        return f"T{current_max + 1:03d}"

    def upsert(self, task: OrchestratedTask) -> OrchestratedTask:
        """Persist the latest snapshot for a task."""
        self._ensure_loaded()
        stored = copy.deepcopy(task)
        try:
            self._append_snapshot(stored)
        except OSError:
            logger.warning(
                "Failed to persist orchestrate task %s to %s",
                stored.task_id,
                self._path,
                exc_info=True,
            )
            raise
        self._tasks[stored.task_id] = stored
        return copy.deepcopy(stored)

    def get(self, task_id: str) -> OrchestratedTask | None:
        """Fetch a single task by id."""
        self._ensure_loaded()
        task = self._tasks.get(task_id)
        return copy.deepcopy(task) if task else None

    def find_by_branch(self, branch: str) -> OrchestratedTask | None:
        """Fetch the most recent task associated with a branch."""
        self._ensure_loaded()
        matches = [task for task in self._tasks.values() if task.branch == branch]
        if not matches:
            return None
        latest = max(matches, key=lambda item: item.updated_at)
        return copy.deepcopy(latest)

    def list(self, limit: int = 20, state: str = "") -> list[OrchestratedTask]:
        """List tasks, newest first, with optional state filter."""
        self._ensure_loaded()
        items = sorted(
            self._tasks.values(),
            key=lambda item: item.updated_at,
            reverse=True,
        )
        if state:
            items = [item for item in items if item.state.value == state]
        return [copy.deepcopy(item) for item in items[:limit]]

    def state_counts(self) -> dict[str, int]:
        """Return a count of tasks per state."""
        self._ensure_loaded()
        counts: dict[str, int] = {}
        for task in self._tasks.values():
            counts[task.state.value] = counts.get(task.state.value, 0) + 1
        return counts

    def _ensure_loaded(self) -> None:
        if self._loaded:
            return

        if self._path.exists():
            try:
                self._tasks = dict(self._read_latest_snapshots())
            except OSError:
                logger.warning(
                    "Failed to load orchestrate tasks from %s",
                    self._path,
                    exc_info=True,
                )

        self._loaded = True

    def _append_snapshot(self, task: OrchestratedTask) -> None:
        self._append_line(json.dumps(task.to_dict(), ensure_ascii=False) + "\n")
        try:
            self._maybe_rotate()
        except OSError:
            logger.warning(
                "Failed to compact orchestrate store %s",
                self._path,
                exc_info=True,
            )

    def _append_line(self, line: str) -> None:
        """Append a single JSONL line with cross-process file locking."""
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "a", encoding="utf-8") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            try:
                handle.write(line)
                handle.flush()
                os.fsync(handle.fileno())
            finally:
                fcntl.flock(handle, fcntl.LOCK_UN)

    def _maybe_rotate(self) -> None:
        if not self._path.exists() or self._path.stat().st_size <= self._max_bytes:
            return

        self._write_snapshots(self._read_latest_snapshots().values())

    def _read_latest_snapshots(self) -> OrderedDict[str, OrchestratedTask]:
        latest_snapshots: OrderedDict[str, OrchestratedTask] = OrderedDict()
        if not self._path.exists():
            return latest_snapshots

        with open(self._path, encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                try:
                    task = self._load_snapshot(line)
                except Exception as exc:
                    logger.warning(
                        "Skipping invalid orchestrate snapshot %s:%s: %s",
                        self._path,
                        line_number,
                        exc,
                    )
                    continue

                if task is None:
                    continue
                if task.task_id in latest_snapshots:
                    del latest_snapshots[task.task_id]
                latest_snapshots[task.task_id] = task

        return latest_snapshots

    def _write_snapshots(self, tasks: Iterable[OrchestratedTask]) -> None:
        payload = "\n".join(
            json.dumps(task.to_dict(), ensure_ascii=False) for task in tasks
        )
        if payload:
            payload += "\n"
        self._write_text_atomic(payload)

    def _write_text_atomic(self, payload: str) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        temp_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                "w",
                dir=self._path.parent,
                encoding="utf-8",
                delete=False,
            ) as tmp:
                tmp.write(payload)
                tmp.flush()
                os.fsync(tmp.fileno())
                temp_path = Path(tmp.name)
            os.replace(temp_path, self._path)
        finally:
            if temp_path and temp_path.exists():
                temp_path.unlink(missing_ok=True)

    def _load_snapshot(self, line: str) -> OrchestratedTask | None:
        line = line.strip()
        if not line:
            return None

        record = json.loads(line)
        if not isinstance(record, dict):
            raise ValueError("snapshot is not a JSON object")
        task = OrchestratedTask.from_dict(record)
        if not task.task_id:
            raise ValueError("snapshot task_id is required")
        return task
