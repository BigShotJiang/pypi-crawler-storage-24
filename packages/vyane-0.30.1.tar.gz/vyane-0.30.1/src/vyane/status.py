"""Real-time dispatch status tracking.

Writes status files to ~/.config/vyane/status/ for each active
dispatch. Enables external monitoring (TUI, tmux panes, dashboards)
to observe multi-model calls in progress.

Status files are automatically cleaned up after completion.
"""

from __future__ import annotations

import fcntl
import json
import time
from dataclasses import asdict, dataclass
from pathlib import Path

from vyane.paths import resolve_user_write_path


def _status_dir() -> Path:
    return resolve_user_write_path("status")


@dataclass
class DispatchStatus:
    """Real-time status of a single dispatch call."""

    run_id: str = ""
    provider: str = ""
    task_summary: str = ""
    status: str = "pending"  # pending | running | success | error | timeout | cancelled
    started_at: float = 0.0
    elapsed_seconds: float = 0.0
    output_preview: str = ""
    output_lines: int = 0
    error: str = ""
    failover_from: str = ""
    async_mode: bool = False
    paused: bool = False
    result: dict | None = None
    session_id: str = ""


def _safe_filename(run_id: str) -> str:
    """Ensure run_id is safe for use as a filename (no path traversal)."""
    import re

    return re.sub(r"[^a-zA-Z0-9_-]", "", run_id)[:32]


def write_status(status: DispatchStatus) -> None:
    """Write or update a dispatch status file."""
    try:
        d = _status_dir()
        d.mkdir(parents=True, exist_ok=True)
        safe_id = _safe_filename(status.run_id)
        if not safe_id:
            return
        path = d / f"{safe_id}.json"
        path.write_text(
            json.dumps(asdict(status), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
    except OSError:
        pass


def remove_status(run_id: str) -> None:
    """Remove a completed dispatch status file."""
    try:
        safe_id = _safe_filename(run_id)
        if not safe_id:
            return
        path = _status_dir() / f"{safe_id}.json"
        path.unlink(missing_ok=True)
    except OSError:
        pass


def read_status(run_id: str) -> DispatchStatus | None:
    """Read status for a specific run_id. Returns None if not found."""
    try:
        safe_id = _safe_filename(run_id)
        if not safe_id:
            return None
        path = _status_dir() / f"{safe_id}.json"
        if not path.exists():
            return None
        data = json.loads(path.read_text(encoding="utf-8"))
        return DispatchStatus(
            **{
                k: v
                for k, v in data.items()
                if k in DispatchStatus.__dataclass_fields__
            }
        )
    except (json.JSONDecodeError, OSError, TypeError):
        return None


def _locked_modify(
    run_id: str,
    modifier: callable,
) -> bool:
    """Read-modify-write a status file under an exclusive file lock.

    ``modifier`` receives a ``DispatchStatus`` and returns ``True`` if
    changes were made (and should be written), ``False`` otherwise.
    """
    safe_id = _safe_filename(run_id)
    if not safe_id:
        return False
    path = _status_dir() / f"{safe_id}.json"
    lock_path = path.with_suffix(".lock")
    try:
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        with open(lock_path, "w") as lock_fh:
            fcntl.flock(lock_fh, fcntl.LOCK_EX)
            try:
                if not path.exists():
                    return False
                data = json.loads(path.read_text(encoding="utf-8"))
                status = DispatchStatus(
                    **{
                        k: v
                        for k, v in data.items()
                        if k in DispatchStatus.__dataclass_fields__
                    }
                )
                if not modifier(status):
                    return False
                path.write_text(
                    json.dumps(asdict(status), ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8",
                )
                return True
            finally:
                fcntl.flock(lock_fh, fcntl.LOCK_UN)
    except OSError:
        return False


def cancel_status(run_id: str) -> bool:
    """Mark a task as cancelled by updating its status file.

    This is used by external processes (e.g., TUI monitor) to request
    cancellation. The MCP server will pick up the status change.
    Returns True if the status was updated, False otherwise.
    """
    return _locked_modify(run_id, _do_cancel)


def _do_cancel(status: DispatchStatus) -> bool:
    if status.status in ("success", "error", "timeout", "cancelled"):
        return False
    status.status = "cancelled"
    status.paused = False
    return True


def pause_status(run_id: str) -> bool:
    """Mark a task as paused by updating its status file.

    Returns True if the status was updated, False otherwise.
    """
    return _locked_modify(run_id, _do_pause)


def _do_pause(status: DispatchStatus) -> bool:
    if status.status != "running":
        return False
    status.paused = True
    return True


def resume_status(run_id: str) -> bool:
    """Clear pause flag on a task by updating its status file.

    Returns True if the status was updated, False otherwise.
    """
    return _locked_modify(run_id, _do_resume)


def _do_resume(status: DispatchStatus) -> bool:
    if not status.paused:
        return False
    # Do not resume tasks in terminal states
    if status.status in ("success", "error", "timeout", "cancelled"):
        return False
    status.paused = False
    return True


def list_active() -> list[DispatchStatus]:
    """List all currently active dispatch statuses."""
    d = _status_dir()
    if not d.exists():
        return []

    statuses: list[DispatchStatus] = []
    now = time.time()
    for path in d.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            # GC: remove stale entries (>10 min) and completed async
            # tasks older than 1 hour
            started = data.get("started_at", 0)
            status_val = data.get("status", "")
            is_terminal = status_val in ("success", "error", "timeout", "cancelled")
            age = now - started if started else 0
            if started and age > 600 and not data.get("async_mode"):
                path.unlink(missing_ok=True)
                continue
            if is_terminal and age > 3600:
                path.unlink(missing_ok=True)
                continue
            statuses.append(
                DispatchStatus(
                    **{
                        k: v
                        for k, v in data.items()
                        if k in DispatchStatus.__dataclass_fields__
                    }
                )
            )
        except (json.JSONDecodeError, OSError, TypeError):
            continue

    return sorted(statuses, key=lambda s: s.started_at)
