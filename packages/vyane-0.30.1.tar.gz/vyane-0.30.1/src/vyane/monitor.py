"""Vyane Monitor v2 — real-time TUI for active dispatch tasks.

Launch with: vyane monitor
Requires: Python 3.10+, uv pip install vyane[tui]  (textual dependency)

Features:
  - Live output streaming panel for selected task
  - Session grouping (tasks grouped by session_id)
  - Interactive task control (cancel/pause/resume)
  - i18n: English/Chinese toggle (l key)
  - Keyboard shortcuts (c=cancel, p=pause, r=refresh, u=resume, s=sessions, l=lang)
"""

from __future__ import annotations

import time

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.reactive import reactive
from textual.timer import Timer
from textual.widgets import DataTable, Footer, Header, Static

from vyane.status import (
    DispatchStatus,
    cancel_status,
    list_active,
    pause_status,
    read_status,
    resume_status,
)

# Status -> display emoji
_STATUS_ICON = {
    "pending": "[dim]\u23f3[/]",
    "running": "[green]\u25b6[/]",
    "success": "[green]\u2713[/]",
    "error": "[red]\u2717[/]",
    "timeout": "[yellow]\u23f1[/]",
    "cancelled": "[dim]\u2298[/]",
    "paused": "[yellow]\u23f8[/]",
}

# i18n strings (EN/ZH bilingual)
_I18N = {
    "title": {
        "en": "Vyane Monitor",
        "zh": "Vyane Monitor · 偃",
    },
    "select_task": {
        "en": "Select a task to view details",
        "zh": "\u9009\u62e9\u4e00\u4e2a\u4efb\u52a1\u67e5\u770b\u8be6\u60c5",
    },
    "task_not_found": {
        "en": "Task {run_id} not found",
        "zh": "\u4efb\u52a1 {run_id} \u672a\u627e\u5230",
    },
    "output_streaming": {
        "en": "Output",
        "zh": "\u8f93\u51fa",
    },
    "no_output": {
        "en": "No output yet...",
        "zh": "\u6682\u65e0\u8f93\u51fa...",
    },
    "tasks": {
        "en": "tasks",
        "zh": "\u4e2a\u4efb\u52a1",
    },
    "running": {
        "en": "running",
        "zh": "\u8fd0\u884c\u4e2d",
    },
    "paused": {
        "en": "paused",
        "zh": "\u5df2\u6682\u505c",
    },
    "cancelled_ok": {
        "en": "Task {run_id} cancelled",
        "zh": "\u4efb\u52a1 {run_id} \u5df2\u53d6\u6d88",
    },
    "cancelled_fail": {
        "en": "Cannot cancel {run_id} (not running)",
        "zh": "\u65e0\u6cd5\u53d6\u6d88 {run_id}\uff08\u975e\u8fd0\u884c\uff09",
    },
    "paused_ok": {
        "en": "Task {run_id} paused",
        "zh": "\u4efb\u52a1 {run_id} \u5df2\u6682\u505c",
    },
    "paused_fail": {
        "en": "Cannot pause {run_id}",
        "zh": "\u65e0\u6cd5\u6682\u505c {run_id}",
    },
    "resumed_ok": {
        "en": "Task {run_id} resumed",
        "zh": "\u4efb\u52a1 {run_id} \u5df2\u6062\u590d",
    },
    "resumed_fail": {
        "en": "Cannot resume {run_id}",
        "zh": "\u65e0\u6cd5\u6062\u590d {run_id}",
    },
    "session_group": {
        "en": "Session",
        "zh": "\u4f1a\u8bdd",
    },
    "no_session": {
        "en": "(no session)",
        "zh": "\uff08\u65e0\u4f1a\u8bdd\uff09",
    },
    "no_tasks": {
        "en": "No active tasks",
        "zh": "无活动任务",
    },
    "status_pending": {
        "en": "pending",
        "zh": "等待中",
    },
    "status_running": {
        "en": "running",
        "zh": "运行中",
    },
    "status_success": {
        "en": "success",
        "zh": "成功",
    },
    "status_error": {
        "en": "error",
        "zh": "失败",
    },
    "status_timeout": {
        "en": "timeout",
        "zh": "超时",
    },
    "status_cancelled": {
        "en": "cancelled",
        "zh": "已取消",
    },
    "status_paused": {
        "en": "paused",
        "zh": "已暂停",
    },
}


def _t(key: str, **kwargs: str) -> str:
    """Get translated string using global i18n language."""
    from vyane.i18n import get_lang

    lang = get_lang()
    entry = _I18N.get(key, {})
    text = entry.get(lang, entry.get("en", key))
    if kwargs:
        text = text.format(**kwargs)
    return text


def _t_status(status: str) -> str:
    """Translate a status string."""
    return _t(f"status_{status}")


def _fmt_elapsed(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    m, s = divmod(int(seconds), 60)
    return f"{m}m{s:02d}s"


class OutputPanel(Static):
    """Bottom panel showing live streaming output for selected task."""

    selected_run_id: reactive[str] = reactive("")
    _last_output: str = ""
    _auto_refresh_timer: Timer | None = None

    def on_mount(self) -> None:
        self._auto_refresh_timer = self.set_interval(1.0, self._refresh_output)

    def watch_selected_run_id(self, run_id: str) -> None:
        self._last_output = ""
        self._refresh_output()

    def _refresh_output(self) -> None:
        run_id = self.selected_run_id
        if not run_id:
            self.update(f"[dim]{_t('select_task')}[/]")
            return

        status = read_status(run_id)
        if not status:
            self.update(f"[dim]{_t('task_not_found', run_id=run_id)}[/]")
            return

        # Build header with task info
        icon = _STATUS_ICON.get(status.status, "?")
        if status.paused:
            icon = _STATUS_ICON["paused"]

        header_parts = [
            f"{icon} [bold]{status.run_id}[/] | "
            f"[cyan]{status.provider}[/] | "
            f"{status.status} | "
            f"{_fmt_elapsed(status.elapsed_seconds)}",
        ]
        if status.paused:
            header_parts.append(" [yellow bold]\u23f8 PAUSED[/]")
        if status.failover_from:
            header_parts.append(f" | failover from {status.failover_from}")

        header = "".join(header_parts)

        # Task summary
        lines = [header, ""]
        if status.task_summary:
            lines.append(f"[bold]Task:[/] {status.task_summary[:200]}")
            lines.append("")

        # Error display
        if status.error:
            lines.append(f"[bold red]Error:[/] {status.error[:500]}")
            lines.append("")

        # Live output
        output = status.output_preview or ""
        if output:
            lines.append(f"[bold]{_t('output_streaming')}:[/]")
            lines.append(output[:4000])
        else:
            lines.append(f"[dim]{_t('no_output')}[/]")

        content = "\n".join(lines)
        if content != self._last_output:
            self._last_output = content
            self.update(content)
            # Auto-scroll to bottom
            self.scroll_end(animate=False)


class NotificationBar(Static):
    """Transient notification bar for action feedback."""

    _clear_timer: Timer | None = None

    def show_message(self, message: str, duration: float = 3.0) -> None:
        self.update(message)
        if self._clear_timer is not None:
            self._clear_timer.stop()
        self._clear_timer = self.set_timer(duration, self._clear)

    def _clear(self) -> None:
        self.update("")


class VyaneMonitor(App):
    """Vyane real-time task monitor v2."""

    TITLE = "Vyane Monitor"
    CSS = """
    #task-table {
        height: 1fr;
        min-height: 8;
    }
    #output-panel {
        height: 2fr;
        border-top: solid $accent;
        padding: 1 2;
        overflow-y: auto;
    }
    #status-bar {
        dock: bottom;
        height: 1;
        background: $surface;
        padding: 0 1;
    }
    #notification-bar {
        dock: bottom;
        height: 1;
        background: $warning-darken-3;
        padding: 0 1;
    }
    """

    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("r", "refresh", "Refresh"),
        Binding("c", "cancel_task", "Cancel"),
        Binding("p", "pause_task", "Pause"),
        Binding("u", "resume_task", "Resume"),
        Binding("s", "toggle_session", "Sessions"),
        Binding("l", "toggle_lang", "Lang"),
        Binding("j", "cursor_down", "Down", show=False),
        Binding("k", "cursor_up", "Up", show=False),
    ]

    _refresh_timer: Timer | None = None
    _selected_run_id: str = ""
    _session_view: bool = False

    def compose(self) -> ComposeResult:
        yield Header()
        yield DataTable(id="task-table")
        yield OutputPanel(id="output-panel")
        yield NotificationBar(id="notification-bar")
        yield Static("", id="status-bar")
        yield Footer()

    def on_mount(self) -> None:
        table = self.query_one("#task-table", DataTable)
        self._setup_table_columns(table)
        table.cursor_type = "row"
        self._refresh_tasks()
        self._refresh_timer = self.set_interval(2.0, self._refresh_tasks)

    def _setup_table_columns(self, table: DataTable) -> None:
        """Configure table columns based on current view mode."""
        table.clear(columns=True)
        if self._session_view:
            table.add_columns(
                "", "Session", "Run ID", "Provider", "Task", "Status", "Elapsed"
            )
        else:
            table.add_columns("", "Run ID", "Provider", "Task", "Status", "Elapsed")

    def _refresh_tasks(self) -> None:
        table = self.query_one("#task-table", DataTable)
        statuses = list_active()
        now = time.time()

        # Remember selection
        old_cursor = table.cursor_row

        table.clear()

        if self._session_view:
            self._render_session_view(table, statuses, now)
        else:
            self._render_flat_view(table, statuses, now)

        # Restore cursor position
        row_count = table.row_count
        if row_count > 0 and old_cursor is not None:
            try:
                table.move_cursor(row=min(old_cursor, row_count - 1))
            except Exception:
                pass

        # Update status bar
        running = sum(1 for s in statuses if s.status == "running")
        paused = sum(1 for s in statuses if s.paused)
        total = len(statuses)
        bar = f" {total} {_t('tasks')}"
        if running:
            bar += f" | [green]{running} {_t('running')}[/]"
        if paused:
            bar += f" | [yellow]{paused} {_t('paused')}[/]"
        view_mode = " | [cyan]session view[/]" if self._session_view else ""
        bar += view_mode
        bar += " | [dim]auto-refresh 2s[/]"
        self.query_one("#status-bar", Static).update(bar)

    def _render_flat_view(
        self, table: DataTable, statuses: list[DispatchStatus], now: float
    ) -> None:
        """Render tasks as a flat list."""
        for s in statuses:
            elapsed = s.elapsed_seconds or (now - s.started_at if s.started_at else 0)
            icon = _STATUS_ICON.get(s.status, "?")
            if s.paused:
                icon = _STATUS_ICON["paused"]
            # Visual hint for completed tasks
            if s.status == "success":
                icon = "[bold green]\u2713[/]"
            elif s.status == "error":
                icon = "[bold red]\u2717[/]"

            summary = (s.task_summary or "")[:50]
            table.add_row(
                icon,
                s.run_id,
                s.provider,
                summary,
                _t_status(s.status),
                _fmt_elapsed(elapsed),
                key=s.run_id,
            )

    def _render_session_view(
        self, table: DataTable, statuses: list[DispatchStatus], now: float
    ) -> None:
        """Render tasks grouped by session_id."""
        # Group by session
        sessions: dict[str, list[DispatchStatus]] = {}
        for s in statuses:
            sid = s.session_id or ""
            sessions.setdefault(sid, []).append(s)

        for session_id, tasks in sessions.items():
            session_label = session_id[:12] if session_id else _t("no_session")
            for i, s in enumerate(tasks):
                elapsed = s.elapsed_seconds or (
                    now - s.started_at if s.started_at else 0
                )
                icon = _STATUS_ICON.get(s.status, "?")
                if s.paused:
                    icon = _STATUS_ICON["paused"]
                if s.status == "success":
                    icon = "[bold green]\u2713[/]"
                elif s.status == "error":
                    icon = "[bold red]\u2717[/]"

                summary = (s.task_summary or "")[:50]
                # Show session label only on first row of each group
                display_session = f"[bold]{session_label}[/]" if i == 0 else ""
                table.add_row(
                    icon,
                    display_session,
                    s.run_id,
                    s.provider,
                    summary,
                    _t_status(s.status),
                    _fmt_elapsed(elapsed),
                    key=s.run_id,
                )

    def on_data_table_row_highlighted(self, event: DataTable.RowHighlighted) -> None:
        if event.row_key:
            self._selected_run_id = str(event.row_key.value)
            self.query_one(
                "#output-panel", OutputPanel
            ).selected_run_id = self._selected_run_id

    def _notify_action(self, message: str) -> None:
        """Show a transient notification."""
        self.query_one("#notification-bar", NotificationBar).show_message(message)

    def action_refresh(self) -> None:
        self._refresh_tasks()

    def action_cursor_down(self) -> None:
        self.query_one("#task-table", DataTable).action_cursor_down()

    def action_cursor_up(self) -> None:
        self.query_one("#task-table", DataTable).action_cursor_up()

    def action_toggle_lang(self) -> None:
        """Toggle UI language between English and Chinese."""
        from vyane.i18n import toggle_lang

        toggle_lang()
        self.title = _t("title")
        table = self.query_one("#task-table", DataTable)
        # Preserve selection across rebuild
        saved_run_id = self._selected_run_id
        self._setup_table_columns(table)
        self._refresh_tasks()
        # Restore cursor to the row with saved run_id (using row keys)
        if saved_run_id:
            for idx, key in enumerate(table.rows):
                if str(key.value) == saved_run_id:
                    table.move_cursor(row=idx)
                    self._selected_run_id = saved_run_id
                    break

    def action_toggle_session(self) -> None:
        """Toggle between flat and session-grouped view."""
        self._session_view = not self._session_view
        table = self.query_one("#task-table", DataTable)
        self._setup_table_columns(table)
        self._refresh_tasks()

    def action_cancel_task(self) -> None:
        """Cancel the currently selected task."""
        if not self._selected_run_id:
            return
        run_id = self._selected_run_id
        if cancel_status(run_id):
            self._notify_action(f"[yellow]{_t('cancelled_ok', run_id=run_id)}[/]")
        else:
            self._notify_action(f"[dim]{_t('cancelled_fail', run_id=run_id)}[/]")
        self._refresh_tasks()

    def action_pause_task(self) -> None:
        """Pause the currently selected task."""
        if not self._selected_run_id:
            return
        run_id = self._selected_run_id
        if pause_status(run_id):
            self._notify_action(f"[yellow]{_t('paused_ok', run_id=run_id)}[/]")
        else:
            self._notify_action(f"[dim]{_t('paused_fail', run_id=run_id)}[/]")
        self._refresh_tasks()

    def action_resume_task(self) -> None:
        """Resume the currently selected paused task."""
        if not self._selected_run_id:
            return
        run_id = self._selected_run_id
        if resume_status(run_id):
            self._notify_action(f"[green]{_t('resumed_ok', run_id=run_id)}[/]")
        else:
            self._notify_action(f"[dim]{_t('resumed_fail', run_id=run_id)}[/]")
        self._refresh_tasks()


def run_monitor() -> None:
    """Entry point for ``vyane monitor``."""
    app = VyaneMonitor()
    app.run()
