"""Shared config/data path helpers for Vyane."""

from __future__ import annotations

from pathlib import Path


def user_config_dir() -> Path:
    """Return Vyane's primary user config directory."""
    return Path.home() / ".config" / "vyane"


def user_config_search_dirs() -> tuple[Path]:
    """Return user config directories in lookup order."""
    return (user_config_dir(),)


def resolve_user_read_path(*parts: str) -> Path:
    """Resolve a user data path under the Vyane config directory."""
    return user_config_dir().joinpath(*parts)


def resolve_user_write_path(*parts: str) -> Path:
    """Resolve where new data should be written."""
    return user_config_dir().joinpath(*parts)
