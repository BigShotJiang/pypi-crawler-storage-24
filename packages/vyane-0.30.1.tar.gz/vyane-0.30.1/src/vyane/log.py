"""Centralized logging configuration for vyane.

Usage:
    from vyane.log import setup_logging
    setup_logging()  # reads VYANE_LOG_LEVEL env var

Supports:
    - VYANE_LOG_LEVEL env var
    - VYANE_LOG_FORMAT env var
    - Programmatic configuration via setup_logging(level=, fmt=)
"""

from __future__ import annotations

import json
import logging
import os
import time


class JSONFormatter(logging.Formatter):
    """Structured JSON log formatter for machine parsing."""

    def format(self, record: logging.LogRecord) -> str:
        entry = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime(record.created)),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if record.exc_info and record.exc_info[1]:
            entry["error"] = str(record.exc_info[1])
        return json.dumps(entry, ensure_ascii=False)


_TEXT_FORMAT = "%(asctime)s %(levelname)-7s [%(name)s] %(message)s"
_DATE_FORMAT = "%H:%M:%S"

_configured = False


def setup_logging(
    level: str = "",
    fmt: str = "",
) -> None:
    """Configure the Vyane logger hierarchy.

    Args:
        level: Log level (DEBUG/INFO/WARNING/ERROR). Defaults to
            VYANE_LOG_LEVEL, then WARNING.
        fmt: Format type ("text" or "json"). Defaults to
            VYANE_LOG_FORMAT, then "text".
    """
    global _configured
    if _configured:
        return
    _configured = True

    level = level or os.environ.get("VYANE_LOG_LEVEL", "WARNING")
    fmt = fmt or os.environ.get("VYANE_LOG_FORMAT", "text")

    log_level = getattr(logging, level.upper(), logging.WARNING)
    root_logger = logging.getLogger("vyane")
    root_logger.setLevel(log_level)

    if root_logger.handlers:
        # Apply level/format to existing handlers so config takes effect
        formatter: logging.Formatter
        if fmt == "json":
            formatter = JSONFormatter()
        else:
            formatter = logging.Formatter(_TEXT_FORMAT, datefmt=_DATE_FORMAT)
        for h in root_logger.handlers:
            h.setLevel(log_level)
            h.setFormatter(formatter)
        return

    handler = logging.StreamHandler()
    handler.setLevel(log_level)

    if fmt == "json":
        handler.setFormatter(JSONFormatter())
    else:
        handler.setFormatter(logging.Formatter(_TEXT_FORMAT, datefmt=_DATE_FORMAT))

    root_logger.addHandler(handler)
