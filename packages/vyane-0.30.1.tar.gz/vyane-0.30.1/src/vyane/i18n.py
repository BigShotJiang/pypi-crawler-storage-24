"""Vyane i18n helpers for English and Simplified Chinese."""

from __future__ import annotations

import os


def _normalize_lang(lang: str | None) -> str:
    value = (lang or "").strip().lower()
    return "zh" if value.startswith("zh") else "en"


def _detect_lang() -> str:
    return _normalize_lang(os.environ.get("VYANE_LANG") or os.environ.get("LANG"))


_LANG = _detect_lang()

_STRINGS = {
    "en": {
        "title": "Vyane Monitor",
        "select_task": "Select a task to view details",
        "task_not_found": "Task {run_id} not found",
        "run_id": "Run ID",
        "provider": "Provider",
        "status": "Status",
        "elapsed": "Elapsed",
        "task": "Task",
        "paused": "PAUSED",
        "failover_from": "Failover from",
        "error": "Error",
        "task_desc": "Task",
        "output_preview": "Output preview",
        "quit": "Quit",
        "refresh": "Refresh",
        "lang": "Lang",
        "tasks_count": "{total} tasks",
        "running": "{n} running",
        "paused_count": "{n} paused",
        "auto_refresh": "auto-refresh 2s",
        "col_run_id": "Run ID",
        "col_provider": "Provider",
        "col_task": "Task",
        "col_status": "Status",
        "col_elapsed": "Elapsed",
        "status_pending": "Pending",
        "status_running": "Running",
        "status_success": "Success",
        "status_error": "Error",
        "status_timeout": "Timeout",
        "status_cancelled": "Cancelled",
        "status_paused": "Paused",
        "status_blocked": "Blocked",
        "check_title": "Vyane v{version}",
        "check_providers": "Providers",
        "check_available": "available",
        "check_not_found": "not found",
        "check_api_key_set": "API key set",
        "check_config": "Config",
        "check_active_profile": "Active profile",
        "check_routing_rules": "routing rules",
        "check_profiles": "Profiles",
        "check_last_24h": "Last 24h",
        "check_dispatches": "Dispatches",
        "check_calls": "{calls} calls",
        "check_ok_rate": "{rate:.0f}% ok",
        "status_title": "Active Dispatches",
        "status_no_active": "No active dispatches",
        "status_watch_title": "Vyane — Live Dispatch Monitor",
        "status_stop_hint": "Ctrl+C to stop",
        "status_stopped": "Stopped.",
        "cli_desc": "Vyane — multi-model AI collaboration",
        "error_no_providers": "No providers available",
        "error_policy_blocked": "Policy denied: {reason}",
        "error_policy_blocked_provider": (
            "Policy denied provider '{provider}': {reason}"
        ),
        "error_security_blocked": "Security check failed: {category}",
        "shortcuts": "q {quit} | r {refresh} | l {lang}",
    },
    "zh": {
        "title": "Vyane Monitor · 偃",
        "select_task": "选个任务看详情",
        "task_not_found": "找不到任务 {run_id}",
        "run_id": "任务 ID",
        "provider": "模型",
        "status": "状态",
        "elapsed": "耗时",
        "task": "任务",
        "paused": "已暂停",
        "failover_from": "回退自",
        "error": "错误",
        "task_desc": "任务描述",
        "output_preview": "输出预览",
        "quit": "退出",
        "refresh": "刷新",
        "lang": "语言",
        "tasks_count": "共 {total} 个任务",
        "running": "{n} 个运行中",
        "paused_count": "{n} 个已暂停",
        "auto_refresh": "每 2 秒自动刷新",
        "col_run_id": "任务 ID",
        "col_provider": "模型",
        "col_task": "任务",
        "col_status": "状态",
        "col_elapsed": "耗时",
        "status_pending": "等待中",
        "status_running": "运行中",
        "status_success": "成功",
        "status_error": "错误",
        "status_timeout": "超时",
        "status_cancelled": "已取消",
        "status_paused": "已暂停",
        "status_blocked": "已拦截",
        "check_title": "Vyane v{version}",
        "check_providers": "可用模型",
        "check_available": "可用",
        "check_not_found": "未找到",
        "check_api_key_set": "已设置 API key",
        "check_config": "配置",
        "check_active_profile": "当前配置档",
        "check_routing_rules": "路由规则",
        "check_profiles": "配置档",
        "check_last_24h": "最近 24 小时",
        "check_dispatches": "任务数",
        "check_calls": "{calls} 次调用",
        "check_ok_rate": "成功率 {rate:.0f}%",
        "status_title": "活跃任务",
        "status_no_active": "当前没有活跃任务",
        "status_watch_title": "Vyane — 实时任务监控",
        "status_stop_hint": "按 Ctrl+C 停止",
        "status_stopped": "已停止。",
        "cli_desc": "Vyane — 多模型 AI 协作",
        "error_no_providers": "没有可用模型",
        "error_policy_blocked": "策略拒绝: {reason}",
        "error_policy_blocked_provider": "策略拒绝模型 '{provider}': {reason}",
        "error_security_blocked": "安全检查失败: {category}",
        "shortcuts": "q {quit} | r {refresh} | l {lang}",
    },
}


def t(key: str, **kwargs: object) -> str:
    """Return the translated string for the current language."""
    lang_strings = _STRINGS.get(_LANG, _STRINGS["en"])
    template = lang_strings.get(key, _STRINGS["en"].get(key, key))
    try:
        return template.format(**kwargs)
    except (IndexError, KeyError, ValueError):
        return template


def set_lang(lang: str) -> None:
    """Switch language at runtime."""
    global _LANG
    _LANG = _normalize_lang(lang)


def get_lang() -> str:
    """Return the active language code."""
    return _LANG


def toggle_lang() -> str:
    """Toggle and return the new language code."""
    set_lang("zh" if _LANG == "en" else "en")
    return _LANG
