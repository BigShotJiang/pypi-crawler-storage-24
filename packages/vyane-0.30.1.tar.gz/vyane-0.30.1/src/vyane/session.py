"""Persistent Vyane task sessions."""

from __future__ import annotations

import fcntl
import json
import logging
import os
import re
import tempfile
import time
import uuid
from collections.abc import Callable
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from vyane.paths import resolve_user_write_path, user_config_search_dirs

logger = logging.getLogger(__name__)

_SESSION_ID_RE = re.compile(r"^[a-zA-Z0-9-]+$")
_SLUG_RE = re.compile(r"[^a-zA-Z0-9]+")


@dataclass
class SessionState:
    """Persistent state for a topic-level task session."""

    id: str
    title: str
    description: str = ""
    created_at: float = 0.0
    updated_at: float = 0.0
    dispatches: list[dict[str, Any]] = field(default_factory=list)
    context_summary: str = ""
    provider_sessions: dict[str, str] = field(default_factory=dict)
    status: str = "active"


def _session_state_dir() -> Path:
    return resolve_user_write_path("sessions")


def _session_search_dirs() -> tuple[Path, ...]:
    return tuple(base / "sessions" for base in user_config_search_dirs())


def _validate_session_id(session_id: str) -> str:
    """Reject session ids that could escape the state directory."""
    if not isinstance(session_id, str):
        raise ValueError("session_id must be a string")
    if not _SESSION_ID_RE.fullmatch(session_id):
        raise ValueError("session_id must contain only letters, numbers, and hyphens")
    return session_id


def _slugify_title(title: str) -> str:
    slug = _SLUG_RE.sub("-", title).strip("-").lower()
    return slug or "session"


def _generate_session_id(title: str) -> str:
    return f"{_slugify_title(title)}-{uuid.uuid4().hex[:8]}"


def _session_to_dict(session: SessionState) -> dict[str, Any]:
    return asdict(session)


def _session_from_dict(data: dict[str, Any]) -> SessionState:
    return SessionState(
        id=data["id"],
        title=data["title"],
        description=data.get("description", ""),
        created_at=data.get("created_at", 0.0),
        updated_at=data.get("updated_at", 0.0),
        dispatches=list(data.get("dispatches", [])),
        context_summary=data.get("context_summary", ""),
        provider_sessions=dict(data.get("provider_sessions", {})),
        status=data.get("status", "active"),
    )


def _save_session(session: SessionState) -> Path:
    """Persist a session to disk as JSON with an atomic rename."""
    base = _session_state_dir()
    base.mkdir(parents=True, exist_ok=True)
    path = base / f"{_validate_session_id(session.id)}.json"
    session.updated_at = time.time()
    payload = json.dumps(_session_to_dict(session), indent=2, ensure_ascii=False)
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            dir=base,
            encoding="utf-8",
            delete=False,
        ) as tmp:
            tmp.write(payload)
            tmp.flush()
            os.fsync(tmp.fileno())
            temp_path = Path(tmp.name)
        os.replace(temp_path, path)
    finally:
        if temp_path and temp_path.exists():
            temp_path.unlink(missing_ok=True)
    return path


def _session_lock_path(session_id: str) -> Path:
    """Return the advisory lock file for a session mutation."""
    base = _session_state_dir()
    base.mkdir(parents=True, exist_ok=True)
    safe_session_id = _validate_session_id(session_id)
    return base / f"{safe_session_id}.lock"


def _mutate_session(
    session_id: str, mutate: Callable[[SessionState], None]
) -> SessionState:
    """Load, modify, and persist a session while holding an advisory lock."""
    lock_path = _session_lock_path(session_id)
    with lock_path.open("a+", encoding="utf-8") as lock_file:
        fcntl.flock(lock_file.fileno(), fcntl.LOCK_EX)
        try:
            session = _require_session(session_id)
            mutate(session)
            _save_session(session)
            return session
        finally:
            fcntl.flock(lock_file.fileno(), fcntl.LOCK_UN)


def _require_session(session_id: str) -> SessionState:
    session = load_session(session_id)
    if session is None:
        raise ValueError(f"No session found with id '{session_id}'.")
    return session


def create_session(title: str, description: str = "") -> SessionState:
    """Create and persist a new session."""
    clean_title = title.strip() or "Untitled Session"
    now = time.time()
    session = SessionState(
        id=_generate_session_id(clean_title),
        title=clean_title,
        description=description.strip(),
        created_at=now,
        updated_at=now,
    )
    _save_session(session)
    return session


def load_session(session_id: str) -> SessionState | None:
    """Load a session from disk, or None if not found."""
    try:
        safe_session_id = _validate_session_id(session_id)
    except ValueError as exc:
        logger.warning("Rejected invalid session id %r: %s", session_id, exc)
        return None

    for base in _session_search_dirs():
        path = base / f"{safe_session_id}.json"
        if not path.exists():
            continue
        try:
            return _session_from_dict(json.loads(path.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            logger.warning("Failed to load session state %s: %s", path, exc)
            return None
    return None


def list_sessions(status: str = "active") -> list[SessionState]:
    """List persisted sessions, optionally filtered by status."""
    sessions: list[SessionState] = []
    seen_ids: set[str] = set()
    for base in _session_search_dirs():
        if not base.exists():
            continue
        for path in sorted(base.glob("*.json")):
            try:
                session = _session_from_dict(
                    json.loads(path.read_text(encoding="utf-8"))
                )
            except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
                logger.warning("Skipping invalid session state %s: %s", path, exc)
                continue
            if session.id in seen_ids:
                continue
            if status and status != "all" and session.status != status:
                continue
            sessions.append(session)
            seen_ids.add(session.id)
    sessions.sort(key=lambda item: item.updated_at, reverse=True)
    return sessions


def add_dispatch_to_session(session_id: str, dispatch_result: Any) -> None:
    """Append a dispatch result to a persisted session."""
    if hasattr(dispatch_result, "to_dict"):
        record = dict(dispatch_result.to_dict())
    elif isinstance(dispatch_result, dict):
        record = dict(dispatch_result)
    else:
        raise TypeError("dispatch_result must be a dict or support to_dict()")

    def _append_dispatch(session: SessionState) -> None:
        session.dispatches.append(record)
        provider = str(record.get("provider", "")).strip()
        provider_session_id = str(record.get("session_id", "")).strip()
        if provider and provider_session_id:
            session.provider_sessions[provider] = provider_session_id

    _mutate_session(session_id, _append_dispatch)


def update_context_summary(session_id: str, summary: str) -> None:
    """Replace the stored accumulated context summary."""
    _mutate_session(
        session_id,
        lambda session: setattr(session, "context_summary", summary.strip()),
    )


def archive_session(session_id: str) -> None:
    """Mark a session as archived."""
    _mutate_session(session_id, lambda session: setattr(session, "status", "archived"))
