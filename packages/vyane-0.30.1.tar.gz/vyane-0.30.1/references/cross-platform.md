# Cross-Platform Configuration Guide

## Claude Code

### MCP Server Registration

```bash
claude mcp add vyane -s user --transport stdio -- \
  uvx --from /path/to/vyane vyane
```

### Auto-Approve Tool Calls (optional, common subset)

Add to `~/.claude/settings.json`:

```json
{
  "permissions": {
    "allow": [
      "mcp__vyane__mux_dispatch",
      "mcp__vyane__mux_broadcast",
      "mcp__vyane__mux_check"
    ]
  }
}
```

If you use review/consensus flows regularly, append the other tool names you want
to auto-approve. Otherwise, leave them out and let Claude confirm them case by case.

### Skill Installation

```bash
mkdir -p ~/.claude/skills/vyane
cp SKILL.md ~/.claude/skills/vyane/SKILL.md
```

---

## Codex CLI

### MCP Server Configuration

Add to `~/.codex/config.toml`:

```toml
[mcp_servers.vyane]
command = "uvx"
args = ["--from", "/path/to/vyane", "vyane"]
required = false
tool_timeout_sec = 600
startup_timeout_sec = 30
```

Leave `enabled_tools` unset if you want Codex CLI to see the full Vyane tool
surface. Add it only when you intentionally want to restrict the available tools.

### Skill Installation

```bash
mkdir -p .agents/skills/vyane
cp SKILL.md .agents/skills/vyane/SKILL.md
```

---

## Gemini CLI

### MCP Server Configuration

Add to `~/.gemini/settings.json`:

```json
{
  "mcpServers": {
    "vyane": {
      "command": "uvx",
      "args": ["--from", "/path/to/vyane", "vyane"],
      "timeout": 30000
    }
  }
}
```

### Skill Installation

```bash
mkdir -p .gemini/skills/vyane
cp SKILL.md .gemini/skills/vyane/SKILL.md
```

---

## IDE Integration

### VS Code (Cline / Continue)

Add to MCP settings (`.vscode/mcp.json` or extension settings):

```json
{
  "servers": {
    "vyane": {
      "command": "uvx",
      "args": ["--from", "/path/to/vyane", "vyane"],
      "transport": "stdio"
    }
  }
}
```

### Cursor

Add to `.cursor/mcp.json`:

```json
{
  "mcpServers": {
    "vyane": {
      "command": "uvx",
      "args": ["--from", "/path/to/vyane", "vyane"]
    }
  }
}
```

### Windsurf

Add to Windsurf MCP configuration:

```json
{
  "mcpServers": {
    "vyane": {
      "command": "uvx",
      "args": ["--from", "/path/to/vyane", "vyane"]
    }
  }
}
```

---

## Troubleshooting

### vyane not connecting

1. Check uvx is installed: `uvx --version`
2. Check the package builds: `cd /path/to/vyane && uvx --from . vyane --help`
3. Check MCP registration: `claude mcp list` / check config files

### Model CLI not found

1. Check CLI is on PATH: `which codex`, `which gemini`, `which claude`
2. Use `mux_check()` to verify availability
3. If installed via npm, ensure npm global bin is in PATH

### Timeout issues

- Default timeout is 300 seconds
- Increase via `timeout` parameter: `mux_dispatch(..., timeout=600)`
- Complex tasks may need longer timeouts
