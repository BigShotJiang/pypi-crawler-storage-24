# Vyane · 偃

Multi-model AI collaboration server. Smart routing, unified CLI, TUI monitor.

> *Inspired by Yan Shi (偃师), who crafted the first automaton for King Mu of Zhou circa 1000 BCE.*

CLI command: `vyane`.

## Cross-Agent Collaboration

本项目与 clawmux 通过共享文档协调：

- **`agents/knowledge/specs/modelmux-clawmux.md`** — 接口约定、状态同步、联动优先级
- **`agents/knowledge/specs/modelmux-a2a-integration.md`** — A2A 集成指南（面向 clawmux）

**重要**: 接口变更时同步更新共享文档。

## Quick Reference

- **Package**: repo root (pyproject.toml, src/vyane/)
- **Install**: `uvx vyane` or `claude mcp add vyane -s user -- uvx vyane`
- **Python**: Use `uv`, not system python. Requires 3.10+
- **Tests**: `uv run --with pytest --with pytest-asyncio python -m pytest tests/ --ignore=tests/test_e2e.py`
- **Lint**: `uv run ruff check src/ && uv run ruff format src/`
- **Build**: `uv build`
- **CI**: GitHub Actions (matrix 3.10-3.12 x ubuntu/macos), auto-publish on tag

## Architecture

```
MCP Client → Vyane (FastMCP server, stdio)
  ├── mux_dispatch     → single provider dispatch (auto-route, failover, auto_decompose)
  ├── mux_broadcast    → parallel multi-provider dispatch (provider/model syntax)
  ├── mux_collaborate  → A2A iterative multi-agent collaboration
  ├── mux_workflow     → multi-step pipeline orchestration
  ├── mux_feedback     → user quality ratings for routing improvement
  ├── mux_history      → query result history & analytics (costs)
  └── mux_check        → availability & config status
      │
      ├── CodexAdapter     → codex exec --json
      ├── GeminiAdapter    → gemini -p -o stream-json
      ├── ClaudeAdapter    → claude -p
      ├── OllamaAdapter    → ollama run <model>
      ├── DashScopeAdapter → OpenAI-compatible API (coding.dashscope.aliyuncs.com)
      └── A2ARemoteAdapter → external A2A agents (via httpx)

A2A HTTP Server (vyane a2a-server)
  ├── GET  /.well-known/agent.json  → Agent Card
  ├── POST / (JSON-RPC 2.0)
  │   ├── tasks/send          → synchronous (+ push notification)
  │   ├── tasks/get           → query task state
  │   ├── tasks/cancel        → cancel running task
  │   └── tasks/sendSubscribe → SSE streaming (+ push notification)
  └── TaskStore (in-memory + JSONL persistence)

Web Dashboard (vyane dashboard --port 41521)
  ├── GET  /                → monitoring UI (SSE real-time + polling fallback)
  ├── GET  /api/status      → active dispatches
  ├── GET  /api/history     → dispatch history
  ├── GET  /api/stats       → aggregated statistics
  ├── GET  /api/providers   → provider availability
  ├── GET  /api/costs       → cost breakdown
  ├── GET  /api/feedback    → user feedback scores
  └── GET  /api/events      → SSE stream (2s push)

CLI (vyane dispatch / broadcast / feedback / profile / clean / monitor)
  └── Same adapters + smart routing, JSON output for scripts & CI
```

## Key Files

| File | Purpose |
|------|---------|
| `server.py` | MCP tools (dispatch, broadcast, collaborate, history, check) |
| `adapters/base.py` | Threaded subprocess runner, canonical result schema |
| `adapters/{codex,gemini,claude,ollama,dashscope}.py` | Provider-specific adapters |
| `a2a/` | A2A protocol implementation |
| `routing.py` | Smart routing v4 (keyword + history + benchmark + feedback) |
| `security.py` | Prompt injection + credential leak detection pipeline |
| `config.py` | Profile loading, routing rules, category bindings |
| `monitor.py` | TUI real-time task monitor (Textual) |
| `paths.py` | Config directory resolution |
| `workflow.py` | Multi-step pipeline + step-file persistence |
| `status.py` | Real-time dispatch status tracking |
| `audit.py` | JSONL audit log (policy rate-limiting) |
| `history.py` | Full result storage (history.jsonl) |
| `policy.py` | Policy engine (rate limits, blocks) |
| `cli.py` | CLI entry point (dispatch/broadcast/monitor/feedback/profile/clean) |

## Dev Workflow

1. Edit `src/vyane/` files
2. `uv sync` (if deps changed)
3. Run tests + lint
4. **Create `docs/releases/vX.Y.Z.md`** — bilingual release notes (from CHANGELOG)
5. Commit → push → tag `vX.Y.Z` → auto-publish to PyPI + GitHub Release

## Conventions

- Adapters inherit `BaseAdapter`, implement `build_command()` and `parse_output()`
- All dispatch results use `AdapterResult` canonical schema
- Config files: `~/.config/vyane/` (user), `.vyane/` (project)
- Status files: `~/.config/vyane/status/{run_id}.json`
- Chinese for internal docs, bilingual for public docs

## Multi-Model Collaboration Protocol

**复杂决策和架构设计必须与 GPT 和 Gemini 共同讨论**。具体要求：

- **何时协作**: 涉及架构设计、协议选型、关键算法决策、竞品调研等复杂问题时，
  必须通过 `mux_broadcast` 或 `mux_collaborate` 与其他模型共同讨论
- **推荐配置**:
  - GPT (Codex): `provider="codex"`, model="gpt-5.4", reasoning_effort="xhigh"
  - Gemini: `provider="gemini"`, model="gemini-3.1-pro-preview"
- **超时设置**: 深度研究任务超时可设为数小时甚至一天，不做严格限制
- **代码审查**: 关键功能的代码审查可委托给 codex 和 gemini 共同完成

### 后台并行执行（推荐）

使用 Bash 工具的 `run_in_background` 参数可以让 codex/gemini 在后台执行，不阻塞 Claude Code 主线程。

**模式**: 发起后台任务 → 继续主线工作 → 后台完成时收到通知 → 读取结果

```bash
# 后台发起 Codex 代码审查（run_in_background=true）
codex exec --json -- "Review this code for security issues: $(cat src/file.py)" \
  > /tmp/codex-review.log 2>&1

# 后台发起 Gemini 架构分析（run_in_background=true）
gemini -p "Analyze the architecture of: $(cat CLAUDE.md)" \
  > /tmp/gemini-analysis.log 2>&1
```

## Documentation & Knowledge Management

- **CHANGELOG**: 每个版本发布时更新 `docs/CHANGELOG.md`
- **调研文档**: 有价值的调研结果保存到 `docs/research/` 目录
- **架构决策**: 重大架构决策记录到 `docs/decisions/` 目录 (ADR 格式)

See `docs/ROADMAP.md` for feature planning, `docs/CHANGELOG.md` for version history.
