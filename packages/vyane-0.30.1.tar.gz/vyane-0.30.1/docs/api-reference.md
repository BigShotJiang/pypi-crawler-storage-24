# Vyane API Reference

Complete reference for Vyane's MCP tools, CLI commands, and configuration format.

---

## MCP Tools

Vyane exposes its functionality as MCP (Model Context Protocol) tools. Any MCP-compatible client (Claude Code, Codex CLI, Gemini CLI, IDEs) can invoke these tools.

### mux_dispatch

Dispatch a task to an AI model CLI and return the result.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `provider` | `str` | *(required)* | Which model to use — `"auto"` (smart routing), `"codex"`, `"gemini"`, `"claude"`, `"ollama"`, `"dashscope"`, or `"provider/model"` syntax (e.g. `"dashscope/kimi-k2.5"`, `"codex/gpt-4.1-mini"`). |
| `task` | `str` | *(required)* | The task description / prompt to send to the model. |
| `workdir` | `str` | `"."` | Working directory for the model to operate in. |
| `sandbox` | `"read-only" \| "write" \| "full"` | `"read-only"` | Security level — `"read-only"` (safe), `"write"` (can modify files), `"full"` (unrestricted). |
| `session_id` | `str` | `""` | Resume a previous session for multi-turn conversation. Pass the `session_id` from a previous result to continue. |
| `vyane_session` | `str` | `""` | Persistent Vyane topic session id. When set, loads stored `context_summary`, injects it into the prompt, and records the dispatch into the session history. |
| `timeout` | `int` | `300` | Maximum seconds to wait. |
| `model` | `str` | `""` | Override the specific model version (e.g. `"gpt-5.4"`, `"gemini-2.5-pro"`, `"claude-sonnet-4-6"`). If empty, uses the CLI's default or the active profile's model setting. |
| `profile` | `str` | `""` | Named profile from user config (e.g. `"budget"`, `"china"`). Overrides `active_profile` from config file. |
| `reasoning_effort` | `str` | `""` | Codex reasoning effort level — `"low"`, `"medium"`, `"high"`, `"xhigh"`. Only applies to `provider="codex"`. |
| `failover` | `bool` | `True` | Auto-retry with another provider on execution error. Disabled when `session_id` is set (sessions are provider-specific). |
| `max_retries` | `int` | `1` | Maximum attempts for the same provider before failover (1 = single attempt, no retry). Uses exponential backoff: 2s, 4s, 8s. Max value: 5. |
| `auto_decompose` | `bool` | `False` | Automatically decompose complex tasks into subtasks, route each to the best-suited provider, and merge results. |
| `async_mode` | `bool` | `False` | Run dispatch in background and return immediately with a `run_id`. Use `mux_task_status` to poll and `mux_task_cancel` to cancel. |

**Returns:** JSON string with fields:

| Field | Description |
|-------|-------------|
| `run_id` | Unique identifier for this dispatch |
| `provider` | Provider that handled the task |
| `status` | `"success"` or `"error"` |
| `output` | Model response text (on success) |
| `error` | Error message (on failure) |
| `duration_seconds` | Execution time |
| `session_id` | Session id for multi-turn continuation |
| `failover_from` | Original provider if failover occurred |

**Example:**

```json
{
  "provider": "auto",
  "task": "Write a Python function to merge two sorted lists"
}
```

---

### mux_broadcast

Broadcast a task to multiple AI models in parallel and return all results. Use for consensus reviews, multi-perspective analysis, or A/B comparisons.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `task` | `str` | *(required)* | The task description / prompt to send to all models. |
| `providers` | `list[str] \| None` | `None` | List of providers, e.g. `["codex", "gemini"]`. Supports `"provider/model"` syntax. If omitted, auto-selects all available providers (excluding the caller). |
| `workdir` | `str` | `"."` | Working directory for the models. |
| `sandbox` | `"read-only" \| "write" \| "full"` | `"read-only"` | Security level. |
| `timeout` | `int` | `300` | Maximum seconds per provider. |
| `model` | `str` | `""` | Override model version for all providers. |
| `profile` | `str` | `""` | Named profile from user config. |
| `compare` | `bool` | `False` | Add structured comparison analysis (similarity scores, speed ranking, unique terms per provider). |

**Returns:** JSON string with fields:

| Field | Description |
|-------|-------------|
| `broadcast` | Always `true` |
| `providers` | List of provider names used |
| `results` | Array of per-provider result objects |
| `summary.total` | Total number of providers |
| `summary.success` | Number of successful results |
| `summary.error` | Number of failed results |
| `comparison` | Comparison analysis (only when `compare=True`) |

---

### mux_collaborate

Run a multi-agent collaboration with iterative feedback loops. Unlike `mux_dispatch` (single prompt) or `mux_workflow` (linear pipeline), this enables true agent-to-agent collaboration where agents review each other's work and iterate until convergence.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `task` | `str` | *(required)* | The goal/task for the collaboration session. |
| `pattern` | `str` | *(required)* | Collaboration pattern: `"review"` (implement/review/revise loop), `"consensus"` (multi-perspective parallel analysis + synthesis), or `"debate"` (adversarial debate with arbiter verdict). |
| `providers` | `str` | `""` | Optional role-to-provider mapping as JSON string, e.g. `'{"implementer": "codex", "reviewer": "gemini"}'`. If empty, uses pattern defaults. |
| `workdir` | `str` | `"."` | Working directory for all agents. |
| `sandbox` | `"read-only" \| "write" \| "full"` | `"read-only"` | Security level for all agent operations. |
| `max_rounds` | `int` | `0` | Override max collaboration rounds (0 = pattern default). |
| `timeout` | `int` | `1800` | Max wall-clock seconds for entire collaboration. |
| `list_patterns` | `bool` | `False` | If `True`, return available patterns instead of running. |

---

### mux_workflow

Execute a multi-step workflow pipeline across multiple AI models. Steps run sequentially, and each step can reference outputs from previous steps. State is persisted to disk after each step for recovery.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `workflow` | `str` | *(required)* | Workflow name (e.g. `"review"`, `"consensus"`). |
| `task` | `str` | *(required)* | The input task/prompt that starts the pipeline. |
| `workdir` | `str` | `"."` | Working directory for all steps. |
| `list_workflows` | `bool` | `False` | If `True`, return available workflow definitions and persisted states. |
| `resume_id` | `str` | `""` | Resume a persisted workflow by its ID instead of starting fresh. |

**Returns:** JSON string with fields:

| Field | Description |
|-------|-------------|
| `workflow` | Workflow name |
| `workflow_id` | Unique workflow run identifier |
| `description` | Workflow description |
| `steps` | Array of per-step results |
| `summary.total_steps` | Number of steps executed |
| `summary.success` | Successful step count |
| `summary.total_duration` | Total wall-clock time |
| `summary.resumable` | Whether the workflow can be resumed |

---

### mux_session

Manage persistent Vyane topic sessions.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `action` | `"create" \| "list" \| "history" \| "archive"` | *(required)* | Session operation. |
| `session_id` | `str` | `""` | Session id (required for `"history"` and `"archive"`). |
| `title` | `str` | `""` | Session title (required for `"create"`). |
| `description` | `str` | `""` | Optional session description (for `"create"`). |
| `status` | `"active" \| "archived" \| "all"` | `"active"` | Filter for `"list"` action. |

---

### mux_task_status

Query the status of an async dispatch task.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `run_id` | `str` | *(required)* | The `run_id` returned by `mux_dispatch` with `async_mode=True`. |
| `include_output` | `bool` | `False` | Include the full output in the response when the task has completed. |

---

### mux_task_cancel

Cancel a running async dispatch task.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `run_id` | `str` | *(required)* | The `run_id` of the async task to cancel. |

---

### mux_task_pause

Pause a running async dispatch task. Sets a pause flag that prevents the task from continuing after the current adapter call completes.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `run_id` | `str` | *(required)* | The `run_id` of the async task to pause. |

---

### mux_task_resume

Resume a paused async dispatch task.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `run_id` | `str` | *(required)* | The `run_id` of the async task to resume. |

---

### mux_task_list

List all currently active async dispatch tasks. Takes no parameters.

**Returns:** JSON with `total` count and `tasks` array. Each task includes `run_id`, `provider`, `status`, `paused`, `elapsed_seconds`, and `task_summary`.

---

### mux_check

Check which model CLIs are available and show active configuration.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `diagnose` | `str` | `""` | Optional task prompt to diagnose routing. When provided, shows the four-signal score breakdown for each provider. |

**Returns:** JSON with per-provider availability, caller detection info, active config, policy summary, active dispatches, audit stats, and routing diagnostics.

---

### mux_history

Query dispatch history and analytics.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `limit` | `int` | `20` | Max number of entries to return. |
| `provider` | `str` | `""` | Filter by provider name (e.g. `"codex"`). |
| `status` | `str` | `""` | Filter by status (`"success"` or `"error"`). |
| `hours` | `float` | `0` | Only include entries from the last N hours (0 = all time). |
| `stats_only` | `bool` | `False` | Return aggregated statistics instead of individual entries. |
| `costs` | `bool` | `False` | Include cost estimation breakdown (token usage + estimated USD). |

---

### mux_feedback

Submit feedback on a dispatch result to improve routing quality. Ratings are aggregated to automatically adjust provider routing preferences.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `run_id` | `str` | *(required)* | The `run_id` from a dispatch result. |
| `rating` | `int` | *(required)* | Quality rating 1-5 (1=terrible, 3=ok, 5=excellent). |
| `provider` | `str` | `""` | Provider name (auto-detected from `run_id` if omitted). |
| `comment` | `str` | `""` | Optional text feedback. |
| `list_recent` | `bool` | `False` | If `True`, show recent feedback entries instead of submitting. |

---

### mux_orchestrate

Manage Phase 1 orchestration tasks and lifecycle state.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `action` | `str` | *(required)* | One of `"plan"`, `"assign"`, `"status"`, `"review"`, `"merge"`. |
| `task` | `str` | `""` | Task description (used when `action="plan"`). |
| `task_id` | `str` | `""` | Stored task id, e.g. `"T001"`. Required for `"assign"` unless a branch can identify the task. |
| `role` | `str` | `""` | Role template (used by `action="assign"`). |
| `branch` | `str` | `""` | Branch name tracked for review/merge state transitions. |
| `agent` | `str` | `""` | Assigned agent name (used by `action="assign"`). |
| `limit` | `int` | `20` | Max number of tasks returned by `"status"`. |

---

## CLI Commands

All CLI commands are invoked via the `vyane` binary.

### vyane (no subcommand)

Start the MCP server on stdio transport. This is the default mode when no subcommand is given.

```bash
vyane
```

---

### vyane dispatch

Run a single task via a provider and print the JSON result.

```
vyane dispatch [OPTIONS] [TASK ...]
```

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `-p, --provider` | `auto` | Provider to use (`auto` = smart routing) |
| `-m, --model` | | Specific model override |
| `--sandbox` | `read-only` | Sandbox level: `read-only`, `write`, `full` |
| `-t, --timeout` | `300` | Timeout in seconds |
| `-w, --workdir` | `.` | Working directory |
| `-r, --max-retries` | `1` | Max attempts for same provider (max: 5) |
| `--profile` | | Named profile (e.g. `budget`, `china`) |
| `--session` | | Persistent Vyane session id |
| `--failover` | `false` | Try other providers if primary fails |

Task can be passed as positional arguments or piped via stdin.

**Example:**

```bash
vyane dispatch -p codex "Write a Python quicksort"
echo "Explain TCP handshake" | vyane dispatch -p gemini
```

---

### vyane broadcast

Broadcast a task to multiple providers in parallel.

```
vyane broadcast [OPTIONS] [TASK ...]
```

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `--providers` | *(all available)* | Providers to use (space-separated) |
| `-m, --model` | | Model override for all providers |
| `--sandbox` | `read-only` | Sandbox level |
| `-t, --timeout` | `300` | Timeout per provider in seconds |
| `-w, --workdir` | `.` | Working directory |
| `--profile` | | Named profile |
| `--compare` | `false` | Add structured comparison analysis |

**Example:**

```bash
vyane broadcast --providers codex gemini "Review this algorithm"
vyane broadcast --compare "Explain monads"
```

---

### vyane session

Manage persistent task sessions.

```
vyane session {create,list,history,archive} ...
```

**Subcommands:**

| Subcommand | Arguments | Description |
|------------|-----------|-------------|
| `create` | `TITLE [--description DESC]` | Create a new session |
| `list` | `[--status active\|archived\|all]` | List sessions |
| `history` | `SESSION_ID` | Show dispatch history for a session |
| `archive` | `SESSION_ID` | Archive a session |

---

### vyane check

Check which model CLIs are available.

```
vyane check [--json]
```

**Options:**

| Flag | Description |
|------|-------------|
| `--json` | Output as JSON (for scripts and CI) |

---

### vyane status

Monitor active dispatches.

```
vyane status [-w]
```

**Options:**

| Flag | Description |
|------|-------------|
| `-w, --watch` | Live-refresh mode (updates every second) |

---

### vyane history

View dispatch history and statistics.

```
vyane history [OPTIONS]
```

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `--stats` | `false` | Show aggregated statistics |
| `-n, --limit` | `10` | Number of entries |
| `--provider` | | Filter by provider |
| `--hours` | `0` | Only last N hours (0 = all) |
| `--costs` | `false` | Include cost estimation breakdown |
| `--source` | | Filter by source (`dispatch`, `broadcast`, `cli-dispatch`, `cli-broadcast`) |
| `--json` | `false` | Output as JSON |

---

### vyane benchmark

Run the provider benchmark suite.

```
vyane benchmark [OPTIONS]
```

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `--providers` | *(auto-detect)* | Providers to test (space-separated) |
| `--tasks` | *(all)* | Task names to run (space-separated) |
| `--timeout` | `120` | Per-task timeout in seconds |
| `-o, --output` | | Save results to JSON file |
| `--list-tasks` | `false` | List available benchmark tasks |

---

### vyane export

Export history to CSV, JSON, or Markdown.

```
vyane export [OPTIONS]
```

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `-f, --format` | `csv` | Output format: `csv`, `json`, `md` |
| `--hours` | `0` | Only last N hours |
| `--provider` | | Filter by provider |
| `-n, --limit` | `1000` | Max entries |
| `-o, --output` | | Write to file instead of stdout |
| `--source` | | Filter by source |

---

### vyane dashboard

Start the web monitoring dashboard.

```
vyane dashboard [OPTIONS]
```

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `--host` | `127.0.0.1` | Bind address |
| `--port` | `41521` | Port number |

The dashboard provides real-time monitoring at `http://localhost:41521` with endpoints for status, history, stats, providers, costs, feedback, and SSE events.

---

### vyane a2a-server

Start the A2A (Agent-to-Agent) HTTP server.

```
vyane a2a-server [OPTIONS]
```

**Options:**

| Flag | Default | Description |
|------|---------|-------------|
| `--host` | `127.0.0.1` | Bind address (use `0.0.0.0` for network access) |
| `--port` | `41520` | Port number |
| `--workdir` | `.` | Working directory for agents |
| `--sandbox` | `read-only` | Sandbox level: `read-only`, `write`, `full` |
| `--token` | | Bearer token for authentication (or set `VYANE_A2A_TOKEN` env var) |
| `--no-persist` | `false` | Disable task persistence (in-memory only) |

**Endpoints:**

| Method | Path | Description |
|--------|------|-------------|
| GET | `/.well-known/agent.json` | Agent Card |
| POST | `/` (JSON-RPC 2.0) | `tasks/send`, `tasks/get`, `tasks/cancel`, `tasks/sendSubscribe` |

---

### vyane init

Interactive configuration wizard.

```
vyane init [--scope user|project|auto]
```

---

### vyane config

TUI configuration panel (requires `vyane[tui]`).

```
vyane config [--scope user|project]
```

---

### vyane profile

List or show configuration profiles.

```
vyane profile [NAME] [--json]
```

---

### vyane feedback

Submit or view user feedback for routing quality.

```
vyane feedback [OPTIONS]
```

**Options:**

| Flag | Description |
|------|-------------|
| `--run-id` | Run ID to rate |
| `--provider` | Provider that produced the result |
| `--rating` | Rating 1-5 (1=terrible, 5=excellent) |
| `--comment` | Optional comment |
| `--category` | Task category (analysis/generation/reasoning/language) |
| `--list` | List recent feedback entries |
| `--hours` | Filter by time window (for `--list`) |

---

### vyane clean

Clean up data files.

```
vyane clean [WHAT] [--dry-run]
```

**Arguments:**

| Argument | Default | Description |
|----------|---------|-------------|
| `WHAT` | `all` | What to clean: `all`, `history`, `audit`, `feedback`, `status`, `benchmark` |

**Options:**

| Flag | Description |
|------|-------------|
| `--dry-run` | Show what would be removed without deleting |

---

### vyane monitor

Real-time TUI task monitor (requires `vyane[tui]`).

```
vyane monitor
```

---

### vyane version

Show version.

```
vyane version
```

---

## Configuration

Vyane uses TOML or JSON configuration files. Config files are searched in the following order:

1. **Project-level:** `.vyane/config.toml` (or `.json`, `.yaml`)
2. **User-level:** `~/.config/vyane/config.toml`
3. **Legacy fallback:** `~/.config/modelmux/` and `.modelmux/`

### Configuration Structure

```toml
# General settings
active_profile = "default"
default_provider = "codex"
disabled_providers = []
auto_exclude_caller = true
caller_override = ""          # Force caller identity

# Routing rules — evaluated in priority order
[[routing_rules]]
provider = "codex"
keywords = ["write", "implement", "code"]
file_ext = [".py", ".ts"]
regex = ""
priority = 10

[[routing_rules]]
provider = "gemini"
keywords = ["frontend", "css", "html"]

# Profiles — named configuration presets
[profiles.default]
description = "Default profile"

[profiles.default.providers.codex]
model = "gpt-5.4"

[profiles.default.providers.gemini]
model = "gemini-2.5-pro"

[profiles.budget]
description = "Cost-optimized profile"

[profiles.budget.providers.codex]
model = "gpt-4.1-mini"

[profiles.budget.providers.dashscope]
model = "qwen-plus"
base_url = "https://coding.dashscope.aliyuncs.com/compatible-mode/v1"
api_key_env = "DASHSCOPE_CODING_API_KEY"

# Category bindings — map task intent to model + prompt
[profiles.default.category_bindings.code-gen]
preferred_model = "codex/o3-pro"
prompt_template = "Write clean, production-ready code."

[profiles.default.category_bindings.review]
preferred_model = "claude"
prompt_template = "Focus on correctness and security."

# Workflow definitions
[workflows.review]
description = "Code review pipeline"

[[workflows.review.steps]]
name = "implement"
provider = "codex"
task = "Implement: {input}"
timeout = 600

[[workflows.review.steps]]
name = "review"
provider = "claude"
task = "Review the implementation:\n{implement}"
timeout = 300
```

### Provider Config Fields

| Field | Description |
|-------|-------------|
| `model` | Model version override |
| `base_url` | Custom API endpoint |
| `api_key_env` | Environment variable name holding the API key |
| `wire_api` | Codex-specific: `"responses"` or `"chat"` |
| `extra_env` | Additional environment variables for the subprocess |

### Category Binding Fields

Available categories: `code-gen`, `review`, `analysis`, `debug`, `docs`, `research`, `refactor`, `test`.

| Field | Description |
|-------|-------------|
| `preferred_model` | Provider/model to use (e.g. `"codex/o3-pro"`) |
| `prompt_template` | System prompt prepended to the task |
| `parameters` | Extra parameters (e.g. `sandbox`, `timeout`) |

### Data Directories

| Path | Content |
|------|---------|
| `~/.config/vyane/config.toml` | User-level configuration |
| `~/.config/vyane/history.jsonl` | Full dispatch result history |
| `~/.config/vyane/audit.jsonl` | Audit log (rate-limiting data) |
| `~/.config/vyane/feedback.jsonl` | User feedback entries |
| `~/.config/vyane/benchmark.json` | Benchmark results (routing signal) |
| `~/.config/vyane/status/` | Active dispatch status files |
| `~/.config/vyane/sessions/` | Persistent session data |
| `~/.config/vyane/workflows/` | Persisted workflow states |
