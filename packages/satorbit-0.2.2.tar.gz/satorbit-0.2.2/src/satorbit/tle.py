import os
import logging
import collections.abc
import requests
import numpy as np
import pandas as pd
import configparser
from sgp4.api import Satrec
from sgp4.api import SGP4_ERRORS
from astropy.time import Time
from astropy.coordinates import CartesianDifferential, CartesianRepresentation
from astropy.coordinates import TEME, ITRS
from astropy import units as u

logger = logging.getLogger(__name__)


# --- Credentials ---

_credentials: dict | None = None


def set_credentials(username: str, password: str) -> None:
    """Set space-track.org credentials programmatically."""
    global _credentials
    _credentials = {'identity': username, 'password': password}


def _get_credentials() -> dict:
    """Get credentials, loading from config file if not set programmatically."""
    global _credentials
    if _credentials is None:
        config = configparser.ConfigParser()
        config.read(os.path.expanduser("~/.spacetrackorg.txt"))
        _credentials = {
            'identity': config.get("default", "username"),
            'password': config.get("default", "password"),
        }
    return _credentials


# --- Constants ---

base_url = "https://www.space-track.org"
login_request = "/ajaxauth/login"


# --- Space-Track API functions ---

def satcat_objects_by_name(name):
    """Query SATCAT for objects matching a name pattern. Returns a DataFrame."""
    satcat_request = ("/basicspacedata/query/class/satcat/OBJECT_NAME/"
                      f"~~{name.upper()}/orderby/NORAD_CAT_ID%20asc")

    with requests.Session() as session:
        resp = session.post(base_url + login_request,
                            data=_get_credentials())
        if resp.status_code != 200:
            logger.error("Logging in to space-track.org failed")
        resp = session.get(base_url + satcat_request)
        if resp.status_code != 200:
            logger.error("Satcat query failed: %s%s (status %d): %s",
                         base_url, satcat_request, resp.status_code, resp.text)

    df_out = pd.read_json(resp.text, convert_dates=['LAUNCH', 'DECAY'])
    return df_out


def satcat_by_norad_id(norad_id):
    """Query SATCAT for a single object by NORAD catalog ID.

    Returns dict with OBJECT_NAME, NORAD_CAT_ID, OBJECT_TYPE, LAUNCH,
    DECAY, etc. Returns None if not found.
    """
    satcat_request = ("/basicspacedata/query/class/satcat/NORAD_CAT_ID/"
                      f"{norad_id}/emptyresult/show")

    with requests.Session() as session:
        resp = session.post(base_url + login_request,
                            data=_get_credentials())
        if resp.status_code != 200:
            logger.error("Logging in to space-track.org failed")
            return None
        resp = session.get(base_url + satcat_request)
        if resp.status_code != 200:
            logger.error("Satcat query failed: %s%s (status %d): %s",
                         base_url, satcat_request, resp.status_code, resp.text)
            return None

    rows = resp.json()
    if not rows:
        return None

    row = rows[0]
    # Parse date fields
    for date_field in ('LAUNCH', 'DECAY'):
        if row.get(date_field):
            try:
                row[date_field] = pd.to_datetime(row[date_field])
            except (ValueError, TypeError):
                pass
    return row


def tip_by_noradid(noradid):
    """Query Tracking and Impact Prediction (TIP) messages by NORAD ID. Returns a DataFrame."""
    satcat_request = ("/basicspacedata/query/class/tip/NORAD_CAT_ID/"
                      f"{noradid}/WINDOW/1/orderby/MSG_EPOCH%20asc/"
                      "emptyresult/show")

    with requests.Session() as session:
        resp = session.post(base_url + login_request,
                            data=_get_credentials())
        if resp.status_code != 200:
            logger.error("Logging in to space-track.org failed")
        resp = session.get(base_url + satcat_request)
        if resp.status_code != 200:
            logger.error("TIP query failed: %s%s (status %d): %s",
                         base_url, satcat_request, resp.status_code, resp.text)

    df_out = pd.read_json(resp.text, convert_dates=['MSG_EPOCH',
                                                    'INSERT_EPOCH',
                                                    'DECAY_EPOCH'])
    return df_out


# --- TLE parsing ---

def line1_epoch_timestamp(line1):
    """Parse TLE line 1 epoch field and return a UTC pandas Timestamp."""
    year = int(line1[18:20])
    day = int(line1[20:23])
    secday = float(line1[23:32])*86400
    return (pd.to_datetime(f'{year:02d}{day:03d}', format='%y%j', utc=True) +
            pd.to_timedelta(secday, 'sec'))


def tles_by_id(norad_id, tstart, tend, outfile=None, overwrite=False):
    """Fetch TLE history for a NORAD ID over a time range from space-track.org.

    Returns a DataFrame with columns: line1, line2, epoch, norad_id, intldes.
    """
    satcat_request = ("/basicspacedata/query/class/gp_history/"
                      f"NORAD_CAT_ID/{norad_id}/orderby/TLE_LINE1%20ASC/"
                      f"EPOCH/{tstart.strftime('%Y-%m-%d')}"
                      f"--{tend.strftime('%Y-%m-%d')}/format/tle")

    with requests.Session() as session:
        resp = session.post(base_url + login_request,
                            data=_get_credentials())
        if resp.status_code != 200:
            logger.error("Logging in to space-track.org failed")
            return pd.DataFrame()
        resp = session.get(base_url + satcat_request)
        if resp.status_code != 200:
            logger.error("TLE query failed: %s%s", base_url, satcat_request)
            return pd.DataFrame()

    tles = []
    lines = [line.strip() for line in resp.text.split('\n')]
    numtles = int(len(lines)/2)
    for itle in range(numtles):
        tles.append(lines[itle*2:(itle+1)*2])

    df_tle = pd.DataFrame(tles, columns=['line1', 'line2'])

    df_tle['epoch'] = df_tle['line1'].map(line1_epoch_timestamp)
    df_tle['norad_id'] = df_tle['line1'].str[2:7]
    df_tle['intldes'] = df_tle['line1'].str[9:17]
    return df_tle


# --- SGP4 propagation ---

def tle_to_teme(line1: str, line2: str, time) -> tuple[np.ndarray, np.ndarray]:
    """Propagate TLE to TEME position and velocity.

    Returns:
        (position_km, velocity_km_s) as numpy arrays [x, y, z]
        Position in km, velocity in km/s, TEME frame
    """
    satellite = Satrec.twoline2rv(line1, line2)
    t = Time(time)
    error_code, teme_p, teme_v = satellite.sgp4(t.jd1, t.jd2)
    if error_code != 0:
        raise RuntimeError(SGP4_ERRORS[error_code])
    return np.array(teme_p), np.array(teme_v)


def teme_to_itrs(teme_p, teme_v, time):
    """Convert TEME position/velocity to ITRS using astropy.

    Args:
        teme_p: Position in km [x, y, z]
        teme_v: Velocity in km/s [vx, vy, vz]
        time: Observation time (anything astropy.time.Time accepts)

    Returns:
        astropy ITRS object with position and velocity
    """
    t = Time(time)
    teme_p = CartesianRepresentation(teme_p * u.km)
    teme_v = CartesianDifferential(teme_v * u.km / u.s)
    teme = TEME(teme_p.with_differentials(teme_v), obstime=t)
    return teme.transform_to(ITRS(obstime=t))


def tle_to_itrs(line1, line2, time):
    """Propagate TLE to ITRS (backward-compatible wrapper)."""
    teme_p, teme_v = tle_to_teme(line1, line2, time)
    return teme_to_itrs(teme_p, teme_v, time)


# --- High-level orbit functions ---

def orbit_from_tle(norad_id, times, max_time_difference=86400,
                   include_teme=True, include_itrf=True,
                   include_geodetic=True):
    """Propagate TLE orbit with selectable output frames.

    Args:
        norad_id: NORAD catalog ID
        times: DatetimeIndex or list of timestamps
        max_time_difference: Max seconds between TLE epoch and evaluation time.
            Can be a scalar (symmetric) or a (min, max) tuple.
        include_teme: Include TEME (approx GEI) position/velocity columns
        include_itrf: Include ITRF (approx GEO) position/velocity columns
        include_geodetic: Include lat, lon, height columns

    Returns:
        DataFrame with columns based on flags:
          - TEME: x_teme, y_teme, z_teme, vx_teme, vy_teme, vz_teme
          - ITRF: x_itrf, y_itrf, z_itrf, vx_itrf, vy_itrf, vz_itrf
          - Geodetic: lat, lon, height
          - Always: time, tle_epoch
    """
    # Need ITRF for geodetic
    need_itrf = include_itrf or include_geodetic

    # Fetch TLEs with margin
    tle_starttime = times[0] - pd.to_timedelta(2, 'D')
    tle_stoptime = times[-1] + pd.to_timedelta(2, 'D')
    tles = tles_by_id(norad_id, tle_starttime, tle_stoptime, overwrite=True)
    if len(tles) == 0:
        return pd.DataFrame()

    records = []
    old_e = None
    for time in times:
        # Find closest TLE epoch
        result_index = tles['epoch'].sub(time).abs().idxmin()
        tle = tles.iloc[result_index]
        time_difference = (tle['epoch'] - time).total_seconds()

        # Check time difference
        if isinstance(max_time_difference, collections.abc.Sequence):
            if (time_difference < max_time_difference[0] or
                    time_difference > max_time_difference[1]):
                continue
        elif abs(time_difference) > max_time_difference:
            continue

        try:
            teme_p, teme_v = tle_to_teme(tle['line1'], tle['line2'], time)
        except RuntimeError as e:
            if e != old_e:
                logger.warning("Error evaluating TLE with epoch "
                               "%s for time %s: %s", tle['epoch'], time, e)
            old_e = e
            continue

        record = {'time': time, 'tle_epoch': tle['epoch']}

        if include_teme:
            record.update({
                'x_teme': teme_p[0], 'y_teme': teme_p[1],
                'z_teme': teme_p[2],
                'vx_teme': teme_v[0], 'vy_teme': teme_v[1],
                'vz_teme': teme_v[2],
            })

        if need_itrf:
            try:
                itrs = teme_to_itrs(teme_p, teme_v, time)
            except Exception as e:
                if e != old_e:
                    logger.warning("Error converting to ITRS for time %s: %s",
                                   time, e)
                old_e = e
                continue

            if include_itrf:
                record.update({
                    'x_itrf': itrs.x.value, 'y_itrf': itrs.y.value,
                    'z_itrf': itrs.z.value,
                    'vx_itrf': itrs.v_x.value, 'vy_itrf': itrs.v_y.value,
                    'vz_itrf': itrs.v_z.value,
                })

            if include_geodetic:
                geodetic = itrs.earth_location.to_geodetic()
                record.update({
                    'lat': geodetic.lat.value,
                    'lon': geodetic.lon.value,
                    'height': geodetic.height.value,
                })

        records.append(record)

    df = pd.DataFrame(records)
    if len(df) > 0:
        df.index = df['time']
    return df


def geodetic_orbit_from_tle(norad_id, times, max_time_difference=86400):
    """Compute geodetic orbit from TLEs for a NORAD ID over given times.

    Returns a DataFrame with lat, lon, height, ITRF position/velocity, and tle_epoch.
    """
    # First get the TLEs for the time interval, with a few days margin
    tle_starttime = times[0] - pd.to_timedelta(2, 'D')
    tle_stoptime = times[-1] + pd.to_timedelta(2, 'D')
    tles = tles_by_id(norad_id, tle_starttime, tle_stoptime, overwrite=True)
    if len(tles) == 0:
        return pd.DataFrame()
    # Loop over the times to evaluate the TLEs
    geodetic_orbit = []
    old_e = None
    for time in times:
        logger.debug("Processing time %s", time)
        # Find the closest TLE epoch
        result_index = tles['epoch'].sub(time).abs().idxmin()
        tle = tles.iloc[result_index]
        time_difference = (tle['epoch'] - time).total_seconds()
        # Check the time difference, first if a tuple is supplied:
        if isinstance(max_time_difference, collections.abc.Sequence):
            if (time_difference < max_time_difference[0] or
                time_difference > max_time_difference[1]):
                continue
        elif (abs(time_difference) > max_time_difference):
            continue
        try:
            itrs = tle_to_itrs(tle['line1'], tle['line2'], time)
            geodetic = itrs.earth_location.to_geodetic()
            geodetic_orbit.append({'time': time,
                                   'height': geodetic.height.value,
                                   'lat': geodetic.lat.value,
                                   'lon': geodetic.lon.value,
                                   'x_itrf': itrs.x.value,
                                   'y_itrf': itrs.y.value,
                                   'z_itrf': itrs.z.value,
                                   'vx_itrf': itrs.v_x.value,
                                   'vy_itrf': itrs.v_y.value,
                                   'vz_itrf': itrs.v_z.value,
                                   'tle_epoch': tle['epoch']})
        except RuntimeError as e:
            if e != old_e:
                logger.warning("Error evaluating TLE with epoch "
                               "%s for time %s: %s", tle['epoch'], time, e)
            old_e = e
            continue
    df = pd.DataFrame(geodetic_orbit)
    if len(df) > 0:
        df.index = df['time']
    return df


def geodetic_orbit_from_tlelines(tleline1,
                                 tleline2,
                                 start_offset='-86400s',
                                 stop_offset='86400s',
                                 freq='1min'):
    """Compute geodetic orbit from a single TLE line pair.

    Propagates the TLE over a time range centered on the TLE epoch.
    Returns a DataFrame with lat, lon, height, and ITRF position/velocity.
    """
    geodetic_orbit = []
    old_e = None
    tle_epoch = line1_epoch_timestamp(tleline1)
    tstart = tle_epoch.round('min') + pd.to_timedelta(start_offset)
    tstop  = tle_epoch.round('min') + pd.to_timedelta(stop_offset)
    times = pd.date_range(tstart, tstop, freq=freq)
    for time in times:
        logger.debug("Processing time %s", time)
        try:
            itrs = tle_to_itrs(tleline1, tleline2, time)
            geodetic = itrs.earth_location.to_geodetic()
            geodetic_orbit.append({'time': time,
                                   'height': geodetic.height.value,
                                   'lat': geodetic.lat.value,
                                   'lon': geodetic.lon.value,
                                   'x_itrf': itrs.x.value,
                                   'y_itrf': itrs.y.value,
                                   'z_itrf': itrs.z.value,
                                   'vx_itrf': itrs.v_x.value,
                                   'vy_itrf': itrs.v_y.value,
                                   'vz_itrf': itrs.v_z.value,
                                   'tle_epoch': tle_epoch})
        except RuntimeError as e:
            if e != old_e:
                logger.warning("Error evaluating TLE with epoch "
                               "%s for time %s: %s", tle_epoch, time, e)
            old_e = e
            continue
    df = pd.DataFrame(geodetic_orbit)
    df.index = df['time']
    return df.drop(['time'], axis=1)
