import logging
import warnings

import numpy as np
import pandas as pd
import apexpy
from astropy.time import Time
import astropy.coordinates as coord
from astropy.coordinates import CartesianRepresentation
from astropy import units as u
from scipy.interpolate import BarycentricInterpolator

logger = logging.getLogger(__name__)

'''
This module provides routines for converting between various representations
of orbit ephemeris. The routines take pandas dataframes as input and return
an expanded dataframe as output. A naming convention is used for the columns.
'''

SPHERICAL_COLUMNS = {
    'lon', 'lat', 'height', 'lon_qd', 'lat_qd', 'mlt',
    'solar_elevation', 'solar_azimuth',
}

# Lat/lon column groups: (lat_col, lon_col, height_col or None, prefix, lon_unsigned)
_SPHERE_GROUPS = [
    ('lat', 'lon', 'height', '_geo', False),
    ('lat_qd', 'lon_qd', None, '_qd', False),
    ('solar_elevation', 'solar_azimuth', None, '_solar', True),
]

# Circular angle groups: (angle_col, period, prefix)
_CIRCLE_GROUPS = [
    ('mlt', 24.0, '_mlt'),
]


def _prepare_for_interpolation(df_orbit):
    """Convert spherical/angular columns to Cartesian for interpolation.

    Lat/lon pairs are projected onto a unit sphere. Height (if present) and
    other scalar columns are kept as-is. Circular quantities like MLT are
    decomposed into cos/sin components.

    Returns (df_cartesian, conv_info) for later use by
    _restore_from_interpolation.
    """
    df_out = df_orbit.copy()
    conv_info = []

    for lat_col, lon_col, height_col, prefix, lon_unsigned in _SPHERE_GROUPS:
        if lat_col not in df_out.columns or lon_col not in df_out.columns:
            continue
        lat_rad = np.radians(df_out[lat_col].values)
        lon_rad = np.radians(df_out[lon_col].values)
        df_out[f'{prefix}_x'] = np.cos(lat_rad) * np.cos(lon_rad)
        df_out[f'{prefix}_y'] = np.cos(lat_rad) * np.sin(lon_rad)
        df_out[f'{prefix}_z'] = np.sin(lat_rad)
        df_out = df_out.drop(columns=[lat_col, lon_col])
        has_height = height_col is not None and height_col in df_orbit.columns
        conv_info.append(('sphere', lat_col, lon_col,
                          height_col if has_height else None,
                          prefix, lon_unsigned))

    for angle_col, period, prefix in _CIRCLE_GROUPS:
        if angle_col not in df_out.columns:
            continue
        angle_rad = df_out[angle_col].values * (2 * np.pi / period)
        df_out[f'{prefix}_x'] = np.cos(angle_rad)
        df_out[f'{prefix}_y'] = np.sin(angle_rad)
        df_out = df_out.drop(columns=[angle_col])
        conv_info.append(('circle', angle_col, period, prefix))

    return df_out, conv_info


def _restore_from_interpolation(df_interp, conv_info, original_columns):
    """Convert temporary Cartesian columns back to spherical/angular.

    Restores original column names and ordering.
    """
    df_out = df_interp.copy()

    for info in conv_info:
        if info[0] == 'sphere':
            _, lat_col, lon_col, height_col, prefix, lon_unsigned = info
            x_col, y_col, z_col = f'{prefix}_x', f'{prefix}_y', f'{prefix}_z'
            if x_col not in df_out.columns:
                continue
            x = df_out[x_col].values
            y = df_out[y_col].values
            z = df_out[z_col].values
            r = np.sqrt(x**2 + y**2 + z**2)
            lon_deg = np.degrees(np.arctan2(y, x))
            if lon_unsigned:
                lon_deg = lon_deg % 360
            df_out[lon_col] = lon_deg
            df_out[lat_col] = np.degrees(np.arcsin(np.clip(z / r, -1, 1)))
            df_out = df_out.drop(columns=[x_col, y_col, z_col])
        elif info[0] == 'circle':
            _, angle_col, period, prefix = info
            x_col, y_col = f'{prefix}_x', f'{prefix}_y'
            if x_col not in df_out.columns:
                continue
            x = df_out[x_col].values
            y = df_out[y_col].values
            df_out[angle_col] = (np.arctan2(y, x) * period / (2 * np.pi)) % period
            df_out = df_out.drop(columns=[x_col, y_col])

    ordered_cols = [c for c in original_columns if c in df_out.columns]
    return df_out[ordered_cols]


def itrf_to_geodetic(df_itrf):
    """Convert ITRF positions to geodetic coordinates (WGS84). Adds lon, lat, height columns."""
    x = df_itrf['x_itrf'].values
    y = df_itrf['y_itrf'].values
    z = df_itrf['z_itrf'].values

    valid = ~(np.isnan(x) | np.isnan(y) | np.isnan(z))
    lon = np.full_like(x, np.nan)
    lat = np.full_like(x, np.nan)
    height = np.full_like(x, np.nan)

    if np.any(valid):
        itrs = coord.ITRS(CartesianRepresentation(
            x[valid] * u.km, y[valid] * u.km, z[valid] * u.km))
        geo = itrs.earth_location.to_geodetic('WGS84')
        lon[valid] = geo.lon.value
        lat[valid] = geo.lat.value
        height[valid] = geo.height.to(u.m).value

    df_out = df_itrf.copy()
    df_out['lon'] = lon
    df_out['lat'] = lat
    df_out['height'] = height
    return df_out


def geodetic_to_qd(df_geod):
    """Convert geodetic coordinates to Quasi-Dipole magnetic coordinates. Adds lat_qd, lon_qd, mlt columns."""
    A = apexpy.Apex(df_geod.index[0])
    lat_qd, lon_qd = A.geo2qd(glat=df_geod['lat'],
                              glon=df_geod['lon'],
                              height=df_geod['height']/1e3)
    mlt = A.mlon2mlt(lon_qd, df_geod.index.values)
    df_new = df_geod.copy()
    df_new['lon_qd'] = lon_qd
    df_new['lat_qd'] = lat_qd
    df_new['mlt'] = mlt
    return df_new


def itrf_to_sun_angles(df_itrf):
    """Compute solar elevation and azimuth angles for ITRF positions. Adds solar_elevation, solar_azimuth columns."""
    x = df_itrf['x_itrf'].values
    y = df_itrf['y_itrf'].values
    z = df_itrf['z_itrf'].values

    valid = ~(np.isnan(x) | np.isnan(y) | np.isnan(z))
    solar_elevation = np.full_like(x, np.nan)
    solar_azimuth = np.full_like(x, np.nan)

    if np.any(valid):
        times = Time(df_itrf.index[valid])
        itrs = coord.ITRS(CartesianRepresentation(
            x[valid] * u.km, y[valid] * u.km, z[valid] * u.km),
            obstime=times)
        locations = itrs.earth_location
        altaz_frames = coord.AltAz(location=locations, obstime=times)
        sun = coord.get_sun(times)
        sun_altaz = sun.transform_to(altaz_frames)
        solar_elevation[valid] = sun_altaz.alt.deg
        solar_azimuth[valid] = sun_altaz.az.deg

    df_out = df_itrf.copy()
    df_out['solar_elevation'] = solar_elevation
    df_out['solar_azimuth'] = solar_azimuth
    return df_out


def itrs_to_igrs(df_itrs):
    """Transform ITRS (Earth-fixed) to GCRS (inertial) frame. Adds x/y/z_gcrs and vx/vy/vz_gcrs columns."""
    t = Time(df_itrs.index)
    df_out = df_itrs.copy()
    itrs = coord.ITRS(x=df_itrs['x_itrf'].values*u.km,
                      y=df_itrs['y_itrf'].values*u.km,
                      z=df_itrs['z_itrf'].values*u.km,
                      v_x=df_itrs['vx_itrf'].values*u.km/u.second,
                      v_y=df_itrs['vy_itrf'].values*u.km/u.second,
                      v_z=df_itrs['vz_itrf'].values*u.km/u.second,
                      obstime=df_itrs.index)
    gcrs_instance = coord.GCRS(obstime=t)
    gcrs = itrs.transform_to(gcrs_instance)
    df_out['x_gcrs'] = gcrs.cartesian.x.to_value()
    df_out['y_gcrs'] = gcrs.cartesian.y.to_value()
    df_out['z_gcrs'] = gcrs.cartesian.z.to_value()
    df_out['vx_gcrs'] = gcrs.velocity.d_x.to_value()
    df_out['vy_gcrs'] = gcrs.velocity.d_y.to_value()
    df_out['vz_gcrs'] = gcrs.velocity.d_z.to_value()
    return df_out


def igrs_to_itrs(df_igrs):
    """Transform GCRS (inertial) to ITRS (Earth-fixed) frame. Adds x/y/z_itrf and vx/vy/vz_itrf columns."""
    t = Time(df_igrs.index)
    df_out = df_igrs.copy()
    igrs = coord.GCRS(representation_type='cartesian',
                      differential_type='cartesian',
                      x=df_igrs['x_gcrs'].values*u.km,
                      y=df_igrs['y_gcrs'].values*u.km,
                      z=df_igrs['z_gcrs'].values*u.km,
                      v_x=df_igrs['vx_gcrs'].values*u.km/u.second,
                      v_y=df_igrs['vy_gcrs'].values*u.km/u.second,
                      v_z=df_igrs['vz_gcrs'].values*u.km/u.second,
                      obstime=df_igrs.index)
    itrs_instance = coord.ITRS(obstime=t)
    itrs = igrs.transform_to(itrs_instance)
    df_out['x_itrf'] = itrs.cartesian.x.to_value()
    df_out['y_itrf'] = itrs.cartesian.y.to_value()
    df_out['z_itrf'] = itrs.cartesian.z.to_value()
    df_out['vx_itrf'] = itrs.velocity.d_x.to_value()
    df_out['vy_itrf'] = itrs.velocity.d_y.to_value()
    df_out['vz_itrf'] = itrs.velocity.d_z.to_value()
    return df_out


def interpolate_orbit_to_freq(df_orbit, index, order=7, freq='10ms'):
    """Interpolate orbit around a given index to a higher time frequency using Lagrange polynomials."""
    df_cart, conv_info = _prepare_for_interpolation(df_orbit)
    nlagrange = int((order-1)/2)
    if (index-nlagrange) < 0 or index+nlagrange >= len(df_cart):
        raise IndexError("Trying to interpolate out of bounds of input orbit")
    new_index = pd.date_range(df_cart.index[index-nlagrange],
                              df_cart.index[index+nlagrange], freq=freq)
    x = (df_cart.index[index-nlagrange:index+nlagrange+1] -
         df_cart.index[index])/pd.to_timedelta('1s')
    newx = (new_index - df_cart.index[index])/pd.to_timedelta('1s')
    data = {}
    for column in [col for col in df_cart.columns
                   if df_cart.dtypes[col] == float]:
        w = df_cart[index-nlagrange:index+nlagrange+1][column].values
        f = BarycentricInterpolator(x, w)
        data[column] = f(newx)
    result = pd.DataFrame(data=data, index=new_index)
    return _restore_from_interpolation(result, conv_info, df_orbit.columns)


def interpolate_orbit_to_timestamp(df_orbit, timestamp, order=7):
    """Interpolate orbit to a single timestamp using Lagrange polynomials."""
    df_cart, conv_info = _prepare_for_interpolation(df_orbit)
    nlagrange = int((order-1)/2)
    [index] = df_cart.index.get_indexer([timestamp], method='nearest')
    if (index-nlagrange) < 0 or index+nlagrange >= len(df_cart):
        raise IndexError("Trying to interpolate out of bounds of input orbit")
    newx = (timestamp - df_cart.index[index])/pd.to_timedelta('1s')
    x = (df_cart.index[index-nlagrange:index+nlagrange+1] -
         df_cart.index[index]) / pd.to_timedelta('1s')
    data = {}
    for column in [col for col in df_cart.columns
                   if df_cart.dtypes[col] == float]:
        w = df_cart[index-nlagrange:index+nlagrange+1][column].values
        f = BarycentricInterpolator(x, w)
        data[column] = f(newx)
    result = pd.DataFrame(data=data, index=[timestamp])
    return _restore_from_interpolation(result, conv_info, df_orbit.columns)


def _vectorized_lagrange(x_all, values, newx_all, nearest_indices, order):
    """Evaluate Lagrange interpolation for all target points at once.

    Parameters
    ----------
    x_all : ndarray (N,)
        Source coordinates (seconds from epoch).
    values : ndarray (N, C)
        Source values, C columns.
    newx_all : ndarray (M,)
        Target coordinates (seconds from epoch).
    nearest_indices : ndarray (M,)
        Index into x_all of the nearest source point for each target.
    order : int
        Lagrange polynomial order (number of nodes per window).

    Returns
    -------
    result : ndarray (M, C)
        Interpolated values at each target point.
    """
    M = len(newx_all)
    N = len(x_all)
    C = values.shape[1]
    nlagrange = (order - 1) // 2

    # Compute window start (lo) for every target point — vectorized clamp
    lo = nearest_indices - nlagrange
    hi = lo + order

    # Clamp: if lo < 0, shift window right
    under = lo < 0
    if np.any(under):
        lo[under] = 0
        hi[under] = np.minimum(order, N)

    # Clamp: if hi > N, shift window left
    over = hi > N
    if np.any(over):
        hi[over] = N
        lo[over] = np.maximum(0, N - order)

    # Build index array for gathering: (M, order)
    offsets = np.arange(order)  # (order,)
    idx = lo[:, np.newaxis] + offsets  # (M, order)

    # Gather source x and y windows
    x_windows = x_all[idx]                    # (M, order)
    y_windows = values[idx]                    # (M, order, C)

    # Target points column vector
    xt = newx_all[:, np.newaxis]               # (M, 1)

    # Node differences: (M, order, order) — diffs[m, i, j] = x_windows[m, i] - x_windows[m, j]
    xw_col = x_windows[:, :, np.newaxis]       # (M, order, 1)
    xw_row = x_windows[:, np.newaxis, :]       # (M, 1, order)
    diffs = xw_col - xw_row                    # (M, order, order)

    # Set diagonal to 1 to avoid division by zero
    eye = np.eye(order, dtype=bool)
    diffs[:, eye] = 1.0

    # Barycentric weights: product along last axis of 1/diffs
    # w[m, j] = prod_{i != j} 1 / (x_j - x_i)
    inv_diffs = 1.0 / diffs                    # (M, order, order)
    inv_diffs[:, eye] = 1.0                    # neutralise diagonal for product
    weights = np.prod(inv_diffs, axis=2)       # (M, order)

    # Basis functions: L_j(xt) = w_j * prod_{i != j} (xt - x_i)
    # Numerator terms: (xt - x_i) for all i
    terms = xt - x_windows                     # (M, order)

    # Check for exact hits (target == source node)
    exact = terms == 0.0                       # (M, order)
    has_exact = np.any(exact, axis=1)          # (M,)

    # Product of all terms per target point
    # For basis j, we need product of terms excluding j
    # prod_all = product of all (xt - x_i)
    # Then L_j = w_j * prod_all / (xt - x_j)
    # But (xt - x_j) could be zero. Handle via exact-hit path.

    # For non-exact points: compute prod_all, then basis_j = w_j * prod_all / terms_j
    prod_all = np.prod(terms, axis=1, keepdims=True)  # (M, 1)
    # Avoid division by zero for exact hits — will be overwritten
    safe_terms = np.where(exact, 1.0, terms)
    basis = weights * prod_all / safe_terms             # (M, order)

    # Evaluate: result = sum_j basis_j * y_j
    result = np.einsum('mj,mjc->mc', basis, y_windows)

    # Handle exact hits: just copy the source value
    if np.any(has_exact):
        exact_rows = np.where(has_exact)[0]
        exact_cols = np.argmax(exact[has_exact], axis=1)
        result[exact_rows] = y_windows[exact_rows, exact_cols]

    return result


def interpolate_orbit_to_datetimeindex(df_orbit, datetimeindex, order=7,
                                       **kwargs):
    """Interpolate orbit to a DatetimeIndex using sliding-window Lagrange polynomials."""
    if 'kind' in kwargs:
        warnings.warn(
            "The 'kind' parameter is deprecated. "
            "interpolate_orbit_to_datetimeindex now uses Lagrange interpolation "
            "with the 'order' parameter (default 7).",
            DeprecationWarning,
            stacklevel=2,
        )
    df_cart, conv_info = _prepare_for_interpolation(df_orbit)
    if not np.all(df_cart.dtypes == float):
        raise ValueError("Can only interpolate orbit if all columns are float")

    nlagrange = int((order - 1) / 2)

    if len(datetimeindex) > 0 and len(df_cart) > 0:
        t_min = datetimeindex.min()
        t_max = datetimeindex.max()
        # The orbit must have at least nlagrange source points beyond each
        # edge of the target range to guarantee a symmetric interpolation
        # window around every target point.
        safe_start = df_cart.index[min(nlagrange, len(df_cart) - 1)]
        safe_end = df_cart.index[max(-nlagrange - 1, -len(df_cart))]
        if t_min < safe_start or t_max > safe_end:
            raise IndexError(
                f"Target timestamps [{t_min}, {t_max}] require orbit data "
                f"with {nlagrange} points of margin beyond each edge. "
                f"Safe interpolation range is [{safe_start}, {safe_end}] "
                f"(orbit covers [{df_cart.index[0]}, {df_cart.index[-1]}]). "
                f"Extend the orbit data or increase the fetch margin."
            )

    t0 = df_cart.index[0]
    x_all = ((df_cart.index - t0) / pd.to_timedelta('1s')).values
    newx_all = ((datetimeindex - t0) / pd.to_timedelta('1s')).values
    nearest_indices = df_cart.index.get_indexer(datetimeindex, method='nearest')

    result = _vectorized_lagrange(x_all, df_cart.values, newx_all,
                                  nearest_indices, order)

    result_df = pd.DataFrame(data=result,
                             index=datetimeindex,
                             columns=df_cart.columns)
    return _restore_from_interpolation(result_df, conv_info, df_orbit.columns)


def find_zero_crossings(df, column, resolution='10s'):
    """Find zero crossings of a column by interpolating to higher resolution."""
    before_zero_indices = np.where(np.diff(np.signbit(df[column])))[0]
    zero_crossings_datetimes = []
    for index in before_zero_indices:
        try:
            highfreq_df = interpolate_orbit_to_freq(df, index, freq=resolution)
            before_zero_indices2 = np.where(np.diff(np.signbit(
                                            highfreq_df[column])))[0]
            for index2 in before_zero_indices2:
                if (highfreq_df.iloc[index2][column]
                        < highfreq_df.iloc[index2+1][column]):
                    zero_crossings_datetimes.append(highfreq_df.iloc[index2])
                else:
                    zero_crossings_datetimes.append(highfreq_df.iloc[index2+1])
        except IndexError:
            logger.warning("Zero crossing too close to edge of input orbit.")
    return pd.DataFrame(zero_crossings_datetimes)


def itrf_find_poles_and_nodes(df):
    """Find orbital poles (N/S latitude extrema) and ascending/descending nodes from ITRF orbit data."""
    columns = ['x_itrf', 'y_itrf', 'z_itrf', 'vx_itrf', 'vy_itrf', 'vz_itrf']
    df_poles = find_zero_crossings(df[columns], column='vz_itrf', resolution='10ms')
    if len(df_poles) == 0:
        return pd.DataFrame()
    df_poles['type'] = df_poles.apply(lambda row: 'N'
                                      if row['z_itrf'] > 0
                                      else 'S', axis=1)
    df_equator = find_zero_crossings(df[columns], column='z_itrf', resolution='10ms')
    df_equator['type'] = df_equator.apply(lambda row: 'A'
                                          if row['vz_itrf'] > 0
                                          else 'D', axis=1)
    df_out = pd.concat([df_poles, df_equator], axis=0).sort_index()
    df_out = itrf_to_geodetic(df_out)[['type', 'lon', 'lat', 'height']]
    astropy_times = Time(pd.to_datetime(df_out.index, utc=True))
    sunlons = coord.get_sun(astropy_times).itrs.spherical.lon.value
    df_out['lst'] = (12 + ((df_out['lon'] - sunlons) / 15)) % 24
    return df_out


def itrf_orbit_arcs(df_itrf):
    """Split ITRF orbit into ascending, descending, and hemisphere arcs."""
    df_poles_and_nodes = itrf_find_poles_and_nodes(df_itrf)
    lastn = None
    lasts = None
    lastan = None
    lastdn = None
    lastan_lon = None
    lastdn_lon = None
    lastn_lon = None
    lasts_lon = None
    lastan_lst = None
    lastdn_lst = None
    lastn_lst = None
    lasts_lst = None
    lastan_h = None
    lastdn_h = None
    lastn_h = None
    lasts_h = None
    orbital_period = pd.to_timedelta(60*100, 'min')
    arcs = []
    for t, row in df_poles_and_nodes.iterrows():
        if row['type'] == 'S':
            lasts = t
            lasts_lon = row['lon']
            lasts_lst = row['lst']
            lasts_h = row['height']
            if lastn is not None and abs(lasts - lastn) < orbital_period:
                arcs.append({'type': 'D',
                             't0': lastn,
                             'tmid': lastdn,
                             'lonmid': lastdn_lon,
                             'lstmid': lastdn_lst,
                             'hmid': lastdn_h,
                             't1': lasts,
                             'duration': lasts - lastn})
        elif row['type'] == 'N':
            lastn = t
            lastn_lon = row['lon']
            lastn_lst = row['lst']
            lastn_h = row['height']
            if lasts is not None and abs(lasts - lastn) < orbital_period:
                arcs.append({'type': 'A',
                             't0': lasts,
                             'tmid': lastan,
                             'lonmid': lastan_lon,
                             'lstmid': lastan_lst,
                             'hmid': lastan_h,
                             't1': lastn,
                             'duration': lastn - lasts})
        elif row['type'] == 'A':
            lastan = t
            lastan_lon = row['lon']
            lastan_lst = row['lst']
            lastan_h = row['height']
            if lastdn is not None and abs(lastdn - lastan) < orbital_period:
                arcs.append({'type': 'SH',
                             't0': lastdn,
                             'tmid': lasts,
                             'lonmid': lasts_lon,
                             'lstmid': lasts_lst,
                             'hmid': lasts_h,
                             't1': lastan,
                             'duration': lastan - lastdn})
        elif row['type'] == 'D':
            lastdn = t
            lastdn_lon = row['lon']
            lastdn_lst = row['lst']
            lastdn_h = row['height']
            if lastan is not None and abs(lastdn - lastan) < orbital_period:
                arcs.append({'type': 'NH',
                             't0': lastan,
                             'tmid': lastn,
                             'lonmid': lastn_lon,
                             'lstmid': lastn_lst,
                             'hmid': lastn_h,
                             't1': lastdn,
                             'duration': lastdn - lastan})
    return pd.DataFrame(arcs)
