"""
satorbit - Satellite orbit tools

A Python package for satellite orbit handling including:
- TLE (Two-Line Element) parsing and SGP4 propagation
- SP3 orbit file parsing
- Coordinate transformations (ITRF, geodetic, Quasi-Dipole)
- Keplerian orbital mechanics with J2 perturbations
"""

from satorbit import tle
from satorbit import sp3
from satorbit import transforms
from satorbit import kepler

# TLE functions
from satorbit.tle import (
    satcat_objects_by_name,
    satcat_by_norad_id,
    tip_by_noradid,
    tles_by_id,
    tle_to_teme,
    teme_to_itrs,
    tle_to_itrs,
    orbit_from_tle,
    set_credentials,
    geodetic_orbit_from_tle,
    geodetic_orbit_from_tlelines,
    line1_epoch_timestamp,
)

# SP3 functions
from satorbit.sp3 import sp3_to_itrf_df

# Transform functions
from satorbit.transforms import (
    SPHERICAL_COLUMNS,
    itrf_to_geodetic,
    geodetic_to_qd,
    itrf_to_sun_angles,
    itrs_to_igrs,
    igrs_to_itrs,
    interpolate_orbit_to_freq,
    interpolate_orbit_to_timestamp,
    interpolate_orbit_to_datetimeindex,
    find_zero_crossings,
    itrf_find_poles_and_nodes,
    itrf_orbit_arcs,
)

# Kepler functions
from satorbit.kepler import (
    kepler_to_cartesian,
    true_anomaly_from_mean_anomaly,
    unperturbed_mean_motion,
    perturbed_mean_motion,
    unperturbed_orbitalperiod,
    d_raan_j2_dM,
    d_argper_j2_dM,
    simulate_orbit,
)

__version__ = "0.2.2"
__all__ = [
    # Modules
    "tle",
    "sp3",
    "transforms",
    "kepler",
    # TLE
    "satcat_objects_by_name",
    "satcat_by_norad_id",
    "tip_by_noradid",
    "tles_by_id",
    "tle_to_teme",
    "teme_to_itrs",
    "tle_to_itrs",
    "orbit_from_tle",
    "set_credentials",
    "geodetic_orbit_from_tle",
    "geodetic_orbit_from_tlelines",
    "line1_epoch_timestamp",
    # SP3
    "sp3_to_itrf_df",
    # Transforms
    "itrf_to_geodetic",
    "geodetic_to_qd",
    "itrf_to_sun_angles",
    "itrs_to_igrs",
    "igrs_to_itrs",
    "interpolate_orbit_to_freq",
    "interpolate_orbit_to_timestamp",
    "interpolate_orbit_to_datetimeindex",
    "find_zero_crossings",
    "itrf_find_poles_and_nodes",
    "itrf_orbit_arcs",
    # Kepler
    "kepler_to_cartesian",
    "true_anomaly_from_mean_anomaly",
    "unperturbed_mean_motion",
    "perturbed_mean_motion",
    "unperturbed_orbitalperiod",
    "d_raan_j2_dM",
    "d_argper_j2_dM",
    "simulate_orbit",
]
