# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2026-03-20

### Fixed
- Updated repository URLs to new GitLab location
- Merged upstream improvements (docstrings, logging, dependency version pins)

## [0.2.0] - 2026-03-20

### Added
- Smart interpolation of spherical/angular columns: geodetic (lon, lat, height),
  quasi-dipole magnetic (lat_qd, lon_qd), solar angles (solar_elevation,
  solar_azimuth), and magnetic local time (mlt) are automatically converted to
  Cartesian representation before interpolation, eliminating singularities at
  the antimeridian and poles
- `order` parameter for `interpolate_orbit_to_datetimeindex` (default 7),
  replacing the `kind` parameter
- Bounds checking in `interpolate_orbit_to_timestamp`
- `SPHERICAL_COLUMNS` constant listing all columns with special handling
- Test suite with 30 tests covering interpolation accuracy, boundary handling,
  column validation, and spherical coordinate handling
- pytest as optional test dependency (`pip install satorbit[test]`)

### Fixed
- Off-by-one error: order=7 Lagrange interpolation now uses 7 points instead of 6
- Bounds check in `interpolate_orbit_to_freq` (`>` changed to `>=`)
- All three interpolation functions now use the same method (sliding-window
  Lagrange via `BarycentricInterpolator`), replacing the inconsistent mix of
  `scipy.interpolate.lagrange` and cubic spline

### Changed
- `interpolate_orbit_to_datetimeindex` now uses sliding-window Lagrange
  interpolation instead of global cubic spline
- Replaced numerically unstable `scipy.interpolate.lagrange` (monomial basis)
  with `scipy.interpolate.BarycentricInterpolator`

### Deprecated
- `kind` parameter in `interpolate_orbit_to_datetimeindex`; use `order` instead

## [0.1.0] - 2026-03-19

### Added
- Initial release
- TLE parsing and SGP4 propagation
- SP3 orbit file parsing
- Coordinate transformations (ITRF, geodetic, quasi-dipole)
- Keplerian orbital mechanics with J2 perturbations
- Orbit interpolation functions
