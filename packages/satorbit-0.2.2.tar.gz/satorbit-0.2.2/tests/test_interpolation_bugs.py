"""Tests that demonstrate the bugs fixed in the interpolation code.

These tests verify that:
1. order=7 Lagrange uses 7 points (not 6)
2. Output dates don't extend beyond the fitted polynomial nodes
3. All three interpolation functions agree
4. Spherical columns are handled via unit sphere conversion (not rejected)
5. Direct spherical interpolation produces wrong results (motivation for handling)
"""

import numpy as np
import pandas as pd
import pytest

from conftest import make_orbit_df, truth_at_times
from satorbit.transforms import (
    interpolate_orbit_to_freq,
    interpolate_orbit_to_timestamp,
    interpolate_orbit_to_datetimeindex,
    itrf_to_geodetic,
)


class TestOffByOneFix:
    """Verify the off-by-one bug is fixed: order=7 uses 7 data points."""

    def test_lagrange_window_has_correct_point_count(self, kepler_iss):
        df = make_orbit_df(kepler_iss, n_points=50)
        index = 25
        order = 7
        nlagrange = (order - 1) // 2

        result = interpolate_orbit_to_freq(df, index, order=order, freq="1s")

        # All 7 input timestamps that fall within the output range must be exact
        for i in range(index - nlagrange, index + nlagrange + 1):
            t = df.index[i]
            if t in result.index:
                for col in df.columns:
                    np.testing.assert_allclose(
                        result.loc[t, col], df.iloc[i][col], rtol=1e-10,
                    )

    def test_no_extrapolation_beyond_window(self, kepler_iss):
        df = make_orbit_df(kepler_iss, n_points=50)
        index = 25
        order = 7
        nlagrange = (order - 1) // 2

        result = interpolate_orbit_to_freq(df, index, order=order, freq="1s")

        assert result.index[0] >= df.index[index - nlagrange]
        assert result.index[-1] <= df.index[index + nlagrange]


class TestConsistencyFix:

    def test_interpolation_at_input_points_is_exact(self, kepler_iss):
        df = make_orbit_df(kepler_iss, n_points=50)
        index = 25
        t = df.index[index]

        result = interpolate_orbit_to_timestamp(df, t, order=7)
        for col in df.columns:
            np.testing.assert_allclose(
                result[col].values[0], df.iloc[index][col], rtol=1e-10,
            )

    def test_all_three_functions_agree(self, kepler_iss):
        df = make_orbit_df(kepler_iss, n_points=50)
        index = 25
        order = 7

        freq_result = interpolate_orbit_to_freq(df, index, order=order, freq="1s")
        mid_idx = len(freq_result) // 2
        t = freq_result.index[mid_idx]

        ts_result = interpolate_orbit_to_timestamp(df, t, order=order)
        dti_result = interpolate_orbit_to_datetimeindex(
            df, pd.DatetimeIndex([t]), order=order,
        )

        for col in df.columns:
            np.testing.assert_allclose(
                freq_result.loc[t, col], ts_result[col].values[0], rtol=1e-10,
            )
            np.testing.assert_allclose(
                freq_result.loc[t, col], dti_result[col].values[0], rtol=1e-10,
            )


class TestSphericalColumnHandling:
    """Verify that spherical columns are handled automatically."""

    def test_handles_geodetic_columns(self, kepler_iss):
        """All three functions accept DataFrames with geodetic columns."""
        df = make_orbit_df(kepler_iss, n_points=50)
        df_with_geo = itrf_to_geodetic(df)
        index = 25

        result_freq = interpolate_orbit_to_freq(df_with_geo, index)
        assert "lon" in result_freq.columns
        assert "lat" in result_freq.columns
        assert "height" in result_freq.columns

        result_ts = interpolate_orbit_to_timestamp(df_with_geo, df.index[index])
        assert "lon" in result_ts.columns

        result_dti = interpolate_orbit_to_datetimeindex(
            df_with_geo, pd.DatetimeIndex([df.index[index]]),
        )
        assert "lon" in result_dti.columns

    def test_geodetic_exact_at_input_points(self, kepler_iss):
        """Geodetic columns should be exact at input timestamps."""
        df = make_orbit_df(kepler_iss, n_points=50)
        df_with_geo = itrf_to_geodetic(df)
        indices = [15, 25, 35]
        timestamps = df.index[indices]

        result = interpolate_orbit_to_datetimeindex(
            df_with_geo, timestamps, order=7,
        )

        for i, idx in enumerate(indices):
            np.testing.assert_allclose(
                result.iloc[i]["lon"], df_with_geo.iloc[idx]["lon"], atol=1e-10,
            )
            np.testing.assert_allclose(
                result.iloc[i]["lat"], df_with_geo.iloc[idx]["lat"], atol=1e-10,
            )
            np.testing.assert_allclose(
                result.iloc[i]["height"], df_with_geo.iloc[idx]["height"],
                rtol=1e-10,
            )


class TestSphericalInterpolationProblems:
    """Demonstrate why spherical columns need special handling."""

    def test_longitude_wrapping_error(self):
        """Direct interpolation of longitude near antimeridian gives wrong result."""
        lons = np.array([170.0, 175.0, 179.0, -179.0, -175.0, -170.0])
        t = np.arange(len(lons), dtype=float)
        interp_lon = np.interp(2.5, t, lons)
        # Should be ~180, but linear interp gives ~0
        assert abs(interp_lon) < 90

    def test_polar_longitude_error(self):
        """Near the poles, longitude changes rapidly and direct interp fails."""
        lons = np.array([0.0, 30.0, 60.0, 150.0, -170.0, -120.0])
        t = np.arange(len(lons), dtype=float)
        interp_lon = np.interp(3.5, t, lons)
        # Should be ~-160 but direct interpolation gives wrong value
        assert abs(interp_lon - (-160.0)) > 50

    def test_round_trip_cartesian_geodetic(self, kepler_iss):
        """Interpolating geodetic directly matches ITRF->geodetic approach."""
        from satorbit.kepler import unperturbed_orbitalperiod

        df = make_orbit_df(kepler_iss, n_points=200, n_periods=1)
        df_geo = itrf_to_geodetic(df)
        period = unperturbed_orbitalperiod(kepler_iss)

        step = period / 200
        mid_times_sec = np.array([step * (i + 0.5) for i in range(10, 20)])
        df_truth = truth_at_times(kepler_iss.copy(), mid_times_sec)
        truth_geo = itrf_to_geodetic(df_truth)

        # Approach 1: interpolate ITRF, then convert
        result_itrf = interpolate_orbit_to_datetimeindex(
            df, df_truth.index, order=7,
        )
        for col in ["x_itrf", "y_itrf", "z_itrf"]:
            error_km = np.abs(result_itrf[col].values - df_truth[col].values)
            assert np.max(error_km) < 0.01

        # Approach 2: interpolate geodetic directly (smart handling)
        result_geo = interpolate_orbit_to_datetimeindex(
            df_geo, df_truth.index, order=7,
        )
        np.testing.assert_allclose(
            result_geo["lat"].values, truth_geo["lat"].values, atol=0.01,
        )
