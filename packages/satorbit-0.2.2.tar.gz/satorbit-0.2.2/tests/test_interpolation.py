"""Comprehensive tests for the interpolation functions after bug fixes."""

import warnings

import numpy as np
import pandas as pd
import pytest

from conftest import make_orbit_df, truth_at_times
from satorbit.kepler import unperturbed_orbitalperiod
from satorbit.transforms import (
    interpolate_orbit_to_freq,
    interpolate_orbit_to_timestamp,
    interpolate_orbit_to_datetimeindex,
    itrf_to_geodetic,
)


class TestInterpolationAccuracy:

    def test_interpolation_accuracy_position(self, kepler_iss):
        """Kepler truth at 30s cadence -> interpolate to 1s offsets -> error < 1 mm."""
        period = unperturbed_orbitalperiod(kepler_iss)
        n_points = int(period / 30)
        df = make_orbit_df(kepler_iss, n_points=n_points, n_periods=1)

        step = period / n_points
        mid_times = np.array([step * i + 1.0 for i in range(20, 30)])
        df_truth = truth_at_times(kepler_iss.copy(), mid_times)

        df_interp = interpolate_orbit_to_datetimeindex(df, df_truth.index, order=7)

        for col in ["x_itrf", "y_itrf", "z_itrf"]:
            error_km = np.abs(df_interp[col].values - df_truth[col].values)
            assert np.max(error_km) < 1e-6, (
                f"Position error for {col}: {np.max(error_km) * 1e6:.1f} mm"
            )

    def test_interpolation_accuracy_velocity(self, kepler_iss):
        """Velocity interpolation error should be < 1e-6 km/s."""
        period = unperturbed_orbitalperiod(kepler_iss)
        n_points = int(period / 30)
        df = make_orbit_df(kepler_iss, n_points=n_points, n_periods=1)

        step = period / n_points
        mid_times = np.array([step * i + 1.0 for i in range(20, 30)])
        df_truth = truth_at_times(kepler_iss.copy(), mid_times)

        df_interp = interpolate_orbit_to_datetimeindex(df, df_truth.index, order=7)

        for col in ["vx_itrf", "vy_itrf", "vz_itrf"]:
            error = np.abs(df_interp[col].values - df_truth[col].values)
            assert np.max(error) < 1e-6, (
                f"Velocity error for {col}: {np.max(error):.2e} km/s"
            )


class TestExactness:

    def test_interpolation_at_input_points_exact(self, kepler_iss):
        """Interpolating at existing timestamps returns input to machine precision."""
        df = make_orbit_df(kepler_iss, n_points=50)
        indices = [10, 20, 30, 40]
        timestamps = df.index[indices]

        result = interpolate_orbit_to_datetimeindex(df, timestamps, order=7)

        for i, idx in enumerate(indices):
            for col in df.columns:
                np.testing.assert_allclose(
                    result.iloc[i][col], df.iloc[idx][col], rtol=1e-12,
                )

    def test_no_time_shift(self, kepler_iss):
        """Error at t+dt and t-dt from a data point should be approximately equal."""
        period = unperturbed_orbitalperiod(kepler_iss)
        n_points = int(period / 30)
        df = make_orbit_df(kepler_iss, n_points=n_points, n_periods=1)

        mid_idx = n_points // 2
        step = period / n_points

        times_plus = np.array([step * mid_idx + 5.0])
        times_minus = np.array([step * mid_idx - 5.0])

        truth_plus = truth_at_times(kepler_iss.copy(), times_plus)
        truth_minus = truth_at_times(kepler_iss.copy(), times_minus)

        t_mid = df.index[mid_idx]
        dt = pd.Timedelta(seconds=5)

        interp_plus = interpolate_orbit_to_datetimeindex(
            df, pd.DatetimeIndex([t_mid + dt]), order=7,
        )
        interp_minus = interpolate_orbit_to_datetimeindex(
            df, pd.DatetimeIndex([t_mid - dt]), order=7,
        )

        for col in ["x_itrf", "y_itrf", "z_itrf"]:
            err_plus = abs(interp_plus[col].values[0] - truth_plus[col].values[0])
            err_minus = abs(interp_minus[col].values[0] - truth_minus[col].values[0])
            if max(err_plus, err_minus) > 0:
                ratio = max(err_plus, err_minus) / max(min(err_plus, err_minus), 1e-20)
                assert ratio < 10, (
                    f"Asymmetric error for {col}: "
                    f"+dt={err_plus:.2e}, -dt={err_minus:.2e}"
                )


class TestFunctionConsistency:

    def test_three_functions_consistent(self, kepler_iss):
        """All three interpolation functions return identical results."""
        df = make_orbit_df(kepler_iss, n_points=50)
        index = 25
        order = 7

        freq_result = interpolate_orbit_to_freq(df, index, order=order, freq="1s")
        t = freq_result.index[len(freq_result) // 2]

        ts_result = interpolate_orbit_to_timestamp(df, t, order=order)
        dti_result = interpolate_orbit_to_datetimeindex(
            df, pd.DatetimeIndex([t]), order=order,
        )

        for col in df.columns:
            val_freq = freq_result.loc[t, col]
            val_ts = ts_result[col].values[0]
            val_dti = dti_result[col].values[0]
            np.testing.assert_allclose(val_freq, val_ts, rtol=1e-10)
            np.testing.assert_allclose(val_freq, val_dti, rtol=1e-10)


class TestBoundaryHandling:

    def test_safe_boundary_interpolation(self, kepler_iss):
        """_to_datetimeindex works at the safe boundary (nlagrange from edge)."""
        df = make_orbit_df(kepler_iss, n_points=50)
        order = 7
        nlagrange = (order - 1) // 2  # 3

        # Target at exactly the safe boundary points
        edge_times = pd.DatetimeIndex([df.index[nlagrange], df.index[-nlagrange - 1]])
        result = interpolate_orbit_to_datetimeindex(df, edge_times, order=order)

        assert not result.isna().any().any()

        for col in df.columns:
            np.testing.assert_allclose(
                result.iloc[0][col], df.iloc[nlagrange][col], rtol=1e-10,
            )
            np.testing.assert_allclose(
                result.iloc[1][col], df.iloc[-nlagrange - 1][col], rtol=1e-10,
            )

    def test_insufficient_margin_raises_error(self, kepler_iss):
        """_to_datetimeindex raises IndexError when orbit lacks margin for symmetric window."""
        df = make_orbit_df(kepler_iss, n_points=50)
        order = 7
        nlagrange = (order - 1) // 2  # 3

        # Target at the edge source points — not enough margin
        before = pd.DatetimeIndex([df.index[nlagrange - 1]])
        with pytest.raises(IndexError, match="require orbit data"):
            interpolate_orbit_to_datetimeindex(df, before, order=order)

        after = pd.DatetimeIndex([df.index[-nlagrange]])
        with pytest.raises(IndexError, match="require orbit data"):
            interpolate_orbit_to_datetimeindex(df, after, order=order)

    def test_extrapolation_raises_error(self, kepler_iss):
        """_to_datetimeindex raises IndexError for timestamps outside orbit range."""
        df = make_orbit_df(kepler_iss, n_points=50)

        before = pd.DatetimeIndex([df.index[0] - pd.Timedelta(seconds=1)])
        with pytest.raises(IndexError, match="require orbit data"):
            interpolate_orbit_to_datetimeindex(df, before)

        after = pd.DatetimeIndex([df.index[-1] + pd.Timedelta(seconds=1)])
        with pytest.raises(IndexError, match="require orbit data"):
            interpolate_orbit_to_datetimeindex(df, after)

    def test_boundary_error_to_freq(self, kepler_iss):
        """_to_freq raises IndexError at edges."""
        df = make_orbit_df(kepler_iss, n_points=50)

        with pytest.raises(IndexError):
            interpolate_orbit_to_freq(df, 0, order=7)

        with pytest.raises(IndexError):
            interpolate_orbit_to_freq(df, len(df) - 1, order=7)


class TestColumnValidation:

    def test_handles_spherical_columns(self, kepler_iss):
        """Spherical columns are handled automatically via unit sphere."""
        df = make_orbit_df(kepler_iss, n_points=50)
        df_geo = itrf_to_geodetic(df)

        result = interpolate_orbit_to_datetimeindex(
            df_geo, pd.DatetimeIndex([df.index[25]]), order=7,
        )
        assert "lon" in result.columns
        assert "lat" in result.columns
        assert "height" in result.columns
        assert not result.isna().any().any()

    def test_accepts_cartesian_only(self, kepler_iss):
        """No error for x_itrf/y_itrf/z_itrf only."""
        df = make_orbit_df(kepler_iss, n_points=50)
        df_cart = df[["x_itrf", "y_itrf", "z_itrf"]]

        result = interpolate_orbit_to_datetimeindex(
            df_cart, pd.DatetimeIndex([df.index[25]]), order=7,
        )
        assert not result.isna().any().any()


class TestCartesianVsSpherical:

    def test_round_trip_itrf_geodetic(self, kepler_iss):
        """Both ITRF->geodetic and direct geodetic interpolation are accurate."""
        period = unperturbed_orbitalperiod(kepler_iss)
        df = make_orbit_df(kepler_iss, n_points=200, n_periods=1)
        df_geo = itrf_to_geodetic(df)

        step = period / 200
        mid_times = np.array([step * (i + 0.5) for i in range(50, 60)])
        df_truth = truth_at_times(kepler_iss.copy(), mid_times)
        truth_geo = itrf_to_geodetic(df_truth)

        # Approach 1: interpolate ITRF, convert to geodetic
        df_interp = interpolate_orbit_to_datetimeindex(df, df_truth.index, order=7)
        interp_geo = itrf_to_geodetic(df_interp)

        np.testing.assert_allclose(
            interp_geo["lat"].values, truth_geo["lat"].values, atol=0.01,
        )

        # Approach 2: interpolate geodetic directly (smart handling)
        result_geo = interpolate_orbit_to_datetimeindex(
            df_geo, df_truth.index, order=7,
        )
        np.testing.assert_allclose(
            result_geo["lat"].values, truth_geo["lat"].values, atol=0.01,
        )

    def test_antimeridian_cartesian_vs_spherical(self):
        """Direct lon interpolation fails near 180 deg; Cartesian works."""
        lons = np.array([170.0, 175.0, 179.0, -179.0, -175.0, -170.0])
        t = np.arange(len(lons), dtype=float)

        # Direct interpolation is wrong
        interp_lon = np.interp(2.5, t, lons)
        assert abs(interp_lon) < 90  # ~0 instead of ~180

        # Cartesian approach works
        x = np.cos(np.radians(lons))
        y = np.sin(np.radians(lons))
        ix = np.interp(2.5, t, x)
        iy = np.interp(2.5, t, y)
        cart_lon = np.degrees(np.arctan2(iy, ix))
        assert abs(abs(cart_lon) - 180) < 5

    def test_polar_cartesian_vs_spherical(self):
        """Direct lon interpolation fails near poles; Cartesian works."""
        lons = np.array([0.0, 30.0, 60.0, 150.0, -170.0, -120.0])
        t = np.arange(len(lons), dtype=float)

        interp_lon = np.interp(3.5, t, lons)
        assert abs(interp_lon - (-160.0)) > 50


class TestSphericalInterpolation:
    """Tests for the automatic spherical/angular column handling."""

    def test_geodetic_interpolation_accurate(self, kepler_iss):
        """Geodetic columns interpolated via unit sphere are accurate."""
        period = unperturbed_orbitalperiod(kepler_iss)
        df = make_orbit_df(kepler_iss, n_points=200, n_periods=1)
        df_geo = itrf_to_geodetic(df)

        step = period / 200
        mid_times_sec = np.array([step * (i + 0.5) for i in range(50, 60)])
        df_truth = truth_at_times(kepler_iss.copy(), mid_times_sec)
        truth_geo = itrf_to_geodetic(df_truth)

        result = interpolate_orbit_to_datetimeindex(df_geo, df_truth.index, order=7)

        np.testing.assert_allclose(
            result["lat"].values, truth_geo["lat"].values, atol=0.01,
        )
        np.testing.assert_allclose(
            result["height"].values, truth_geo["height"].values, atol=10,
        )

    def test_lon_interpolation_across_antimeridian(self):
        """Longitude interpolation across +/-180 boundary works correctly."""
        times = pd.date_range("2024-01-01", periods=13, freq="30s")
        df = pd.DataFrame({
            "lon": [140.0, 150.0, 155.0,
                    170.0, 175.0, 179.0, -179.0, -175.0, -170.0, -165.0,
                    -155.0, -150.0, -140.0],
            "lat": [0.0] * 13,
        }, index=times)

        mid_time = times[5] + (times[6] - times[5]) / 2
        result = interpolate_orbit_to_datetimeindex(
            df, pd.DatetimeIndex([mid_time]), order=7,
        )

        # Should be near +/-180, not near 0
        assert abs(result["lon"].values[0]) > 170

    def test_lon_interpolation_near_poles(self):
        """Longitude interpolation near poles produces stable latitudes."""
        times = pd.date_range("2024-01-01", periods=11, freq="30s")
        df = pd.DataFrame({
            "lon": [-60.0, -30.0,
                    0.0, 30.0, 60.0, 150.0, -170.0, -120.0, -90.0,
                    -60.0, -30.0],
            "lat": [70.0, 75.0,
                    80.0, 85.0, 88.0, 89.5, 88.0, 85.0, 80.0,
                    75.0, 70.0],
        }, index=times)

        mid_times = pd.DatetimeIndex([
            times[4] + pd.Timedelta(seconds=15),
            times[5] + pd.Timedelta(seconds=15),
        ])
        result = interpolate_orbit_to_datetimeindex(df, mid_times, order=5)

        # Latitudes near the pole should still be high
        assert all(result["lat"].values > 85)

    def test_mlt_interpolation_near_midnight(self):
        """MLT interpolation near 0/24 boundary wraps correctly."""
        times = pd.date_range("2024-01-01", periods=11, freq="30s")
        df = pd.DataFrame({
            "mlt": [18.0, 19.0, 22.0, 23.0, 23.5, 0.5, 1.0, 2.0, 3.0, 4.0, 5.0],
            "x_itrf": np.linspace(0, 1, 11),
        }, index=times)

        mid_time = times[4] + (times[5] - times[4]) / 2
        result = interpolate_orbit_to_datetimeindex(
            df, pd.DatetimeIndex([mid_time]), order=5,
        )

        # Should be near midnight (0 or 24), not near noon (12)
        mlt = result["mlt"].values[0]
        assert mlt > 23 or mlt < 1

    def test_column_order_preserved(self, kepler_iss):
        """Output columns match input column order after spherical conversion."""
        df = make_orbit_df(kepler_iss, n_points=50)
        df_geo = itrf_to_geodetic(df)

        result = interpolate_orbit_to_datetimeindex(
            df_geo, pd.DatetimeIndex([df.index[25]]), order=7,
        )
        assert list(result.columns) == list(df_geo.columns)

    def test_geodetic_exact_at_input_points(self, kepler_iss):
        """Geodetic columns are exact at input timestamps after round-trip."""
        df = make_orbit_df(kepler_iss, n_points=50)
        df_geo = itrf_to_geodetic(df)

        indices = [10, 20, 30, 40]
        timestamps = df.index[indices]
        result = interpolate_orbit_to_datetimeindex(df_geo, timestamps, order=7)

        for i, idx in enumerate(indices):
            for col in ["lon", "lat", "height"]:
                np.testing.assert_allclose(
                    result.iloc[i][col], df_geo.iloc[idx][col], atol=1e-10,
                )

    def test_qd_columns_handled(self):
        """QD magnetic columns (lat_qd, lon_qd) are interpolated via unit sphere."""
        times = pd.date_range("2024-01-01", periods=20, freq="30s")
        t = np.linspace(0, 2 * np.pi, 20)
        df = pd.DataFrame({
            "x_itrf": np.cos(t) * 6778,
            "lat_qd": 60 * np.sin(t),
            "lon_qd": np.degrees(t) % 360 - 180,
        }, index=times)

        mid_times = times[5:15:2] + pd.Timedelta(seconds=15)
        result = interpolate_orbit_to_datetimeindex(df, mid_times, order=7)

        assert "lat_qd" in result.columns
        assert "lon_qd" in result.columns
        assert not result.isna().any().any()

    def test_solar_angles_handled(self):
        """Solar elevation/azimuth are interpolated via unit sphere."""
        times = pd.date_range("2024-01-01", periods=20, freq="30s")
        t = np.linspace(0, 2 * np.pi, 20)
        df = pd.DataFrame({
            "x_itrf": np.cos(t) * 6778,
            "solar_elevation": 45 * np.sin(t),
            "solar_azimuth": np.degrees(t) % 360,
        }, index=times)

        mid_times = times[5:15:2] + pd.Timedelta(seconds=15)
        result = interpolate_orbit_to_datetimeindex(df, mid_times, order=7)

        assert "solar_elevation" in result.columns
        assert "solar_azimuth" in result.columns
        # Azimuth should stay in [0, 360] range
        assert all(result["solar_azimuth"].values >= 0)
        assert all(result["solar_azimuth"].values <= 360)


class TestDeprecationWarning:

    def test_kind_parameter_deprecated(self, kepler_iss):
        """Passing kind= should emit DeprecationWarning."""
        df = make_orbit_df(kepler_iss, n_points=50)
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            interpolate_orbit_to_datetimeindex(
                df, pd.DatetimeIndex([df.index[25]]), kind="cubic",
            )
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)
            assert "kind" in str(w[0].message).lower()
