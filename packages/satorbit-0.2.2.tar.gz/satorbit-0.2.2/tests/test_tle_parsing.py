"""Tests for TLE parsing functions (no network access required)."""

import pandas as pd
import pytest

from satorbit.tle import line1_epoch_timestamp


# ISS TLE (sample from a known epoch)
ISS_LINE1 = "1 25544U 98067A   21275.52359873  .00001540  00000-0  38012-4 0  9990"
ISS_LINE2 = "2 25544  51.6448 175.3652 0004208 306.6848 180.1558 15.48919755304547"


class TestLine1EpochTimestamp:
    def test_iss_epoch_year(self):
        """The ISS TLE epoch should be in 2021."""
        ts = line1_epoch_timestamp(ISS_LINE1)
        assert ts.year == 2021

    def test_iss_epoch_is_utc(self):
        ts = line1_epoch_timestamp(ISS_LINE1)
        assert str(ts.tzinfo) == "UTC"

    def test_iss_epoch_day(self):
        """Day 275 of 2021 is October 2."""
        ts = line1_epoch_timestamp(ISS_LINE1)
        assert ts.month == 10
        assert ts.day == 2

    def test_returns_timestamp(self):
        ts = line1_epoch_timestamp(ISS_LINE1)
        assert isinstance(ts, pd.Timestamp)


class TestTleToTeme:
    def test_iss_propagation(self):
        """Propagate ISS TLE to its own epoch and verify reasonable position."""
        from satorbit.tle import tle_to_teme
        epoch = line1_epoch_timestamp(ISS_LINE1)
        pos, vel = tle_to_teme(ISS_LINE1, ISS_LINE2, epoch)
        # ISS orbit radius should be ~6700-6800 km
        import numpy as np
        r = np.linalg.norm(pos)
        assert 6500 < r < 7000
        # Velocity should be ~7.5 km/s
        v = np.linalg.norm(vel)
        assert 7.0 < v < 8.0
