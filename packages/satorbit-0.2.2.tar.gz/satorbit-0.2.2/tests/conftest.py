import numpy as np
import pandas as pd
import pytest
from satorbit.kepler import simulate_orbit, unperturbed_orbitalperiod


def _make_kepler(semimajoraxis, eccentricity, inclination_deg):
    """Create a Kepler elements dict for Earth orbit."""
    return {
        "semimajoraxis": semimajoraxis,
        "eccentricity": eccentricity,
        "inclination": np.radians(inclination_deg),
        "argumentofperigee": np.radians(90.0),
        "raan": np.radians(0.0),
        "initial_mean_anomaly": 0.0,
        "mu": 398600.4415,
        "re": 6378.1363,
        "j2": 1082.6357e-6,
    }


@pytest.fixture
def kepler_iss():
    """ISS-like orbit: i=51.6 deg, nearly circular, ~400 km altitude."""
    return _make_kepler(
        semimajoraxis=6378.137 + 400,
        eccentricity=0.001,
        inclination_deg=51.6,
    )


@pytest.fixture
def kepler_polar():
    """Near-polar orbit: i=87 deg, ~500 km altitude."""
    return _make_kepler(
        semimajoraxis=6378.137 + 500,
        eccentricity=0.001,
        inclination_deg=87.0,
    )


def make_orbit_df(kepler, n_points=200, n_periods=1):
    """Generate a DataFrame with ITRF columns and DatetimeIndex."""
    period = unperturbed_orbitalperiod(kepler)
    times_sec = np.linspace(0, n_periods * period, n_points, endpoint=False)
    start_time = pd.Timestamp("2024-01-01T00:00:00")
    time_index = start_time + pd.to_timedelta(times_sec, "s")

    data = simulate_orbit(kepler.copy(), times_sec)
    columns = ["x_itrf", "y_itrf", "z_itrf", "vx_itrf", "vy_itrf", "vz_itrf"]
    return pd.DataFrame(data=data, index=time_index, columns=columns)


def truth_at_times(kepler, times_sec):
    """Return exact Kepler state at arbitrary times (seconds from epoch)."""
    data = simulate_orbit(kepler.copy(), times_sec)
    columns = ["x_itrf", "y_itrf", "z_itrf", "vx_itrf", "vy_itrf", "vz_itrf"]
    start_time = pd.Timestamp("2024-01-01T00:00:00")
    time_index = start_time + pd.to_timedelta(times_sec, "s")
    return pd.DataFrame(data=data, index=time_index, columns=columns)
