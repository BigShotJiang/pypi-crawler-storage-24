"""Tests for vectorized coordinate transforms."""

import numpy as np
import pandas as pd
import pytest

from satorbit.transforms import itrf_to_geodetic, itrf_to_sun_angles


def _make_itrf_df(x, y, z, times=None):
    """Create a test ITRF DataFrame."""
    if times is None:
        times = pd.date_range("2025-06-21 12:00", periods=len(x), freq="1s")
    return pd.DataFrame(
        {"x_itrf": x, "y_itrf": y, "z_itrf": z},
        index=times,
    )


class TestITRFToGeodetic:
    """Tests for vectorized itrf_to_geodetic."""

    def test_known_coordinates(self):
        """Test with a known position near the equator at zero longitude."""
        # Point on the equator at lon=0: x ~ R_earth, y=0, z=0
        r_km = 6378.137  # WGS84 equatorial radius
        df = _make_itrf_df([r_km], [0.0], [0.0])
        result = itrf_to_geodetic(df)

        assert abs(result["lat"].iloc[0]) < 0.01  # near equator
        assert abs(result["lon"].iloc[0]) < 0.01  # near prime meridian
        assert abs(result["height"].iloc[0]) < 1.0  # near surface (meters)

    def test_north_pole(self):
        """Test position above the north pole."""
        r_km = 6356.752  # WGS84 polar radius
        altitude_km = 500
        df = _make_itrf_df([0.0], [0.0], [r_km + altitude_km])
        result = itrf_to_geodetic(df)

        assert result["lat"].iloc[0] > 89.0  # near north pole
        # Height should be approximately 500km = 500000m
        assert abs(result["height"].iloc[0] - 500_000) < 10_000  # within 10km

    def test_multiple_points(self):
        """Test vectorized computation with multiple points."""
        r_km = 6800.0
        angles = np.radians([0, 45, 90, -45])
        x = r_km * np.cos(angles)
        y = np.zeros(4)
        z = r_km * np.sin(angles)
        df = _make_itrf_df(x, y, z)
        result = itrf_to_geodetic(df)

        assert len(result) == 4
        assert all(col in result.columns for col in ["lon", "lat", "height"])
        assert not result["lat"].isna().any()

    def test_nan_handling(self):
        """Test that NaN ITRF values produce NaN output."""
        df = _make_itrf_df(
            [6800.0, np.nan, 6800.0],
            [0.0, 0.0, np.nan],
            [0.0, 0.0, 0.0],
        )
        result = itrf_to_geodetic(df)

        # First row: valid
        assert not np.isnan(result["lat"].iloc[0])
        # Second row: NaN x -> NaN output
        assert np.isnan(result["lat"].iloc[1])
        assert np.isnan(result["lon"].iloc[1])
        assert np.isnan(result["height"].iloc[1])
        # Third row: NaN y -> NaN output
        assert np.isnan(result["lat"].iloc[2])

    def test_preserves_original_columns(self):
        """Test that original columns are preserved in output."""
        df = _make_itrf_df([6800.0], [0.0], [0.0])
        result = itrf_to_geodetic(df)

        assert "x_itrf" in result.columns
        assert "y_itrf" in result.columns
        assert "z_itrf" in result.columns

    def test_all_nan(self):
        """Test with all-NaN input."""
        df = _make_itrf_df([np.nan], [np.nan], [np.nan])
        result = itrf_to_geodetic(df)

        assert np.isnan(result["lon"].iloc[0])
        assert np.isnan(result["lat"].iloc[0])
        assert np.isnan(result["height"].iloc[0])


class TestITRFToSunAngles:
    """Tests for vectorized itrf_to_sun_angles."""

    def test_basic_computation(self):
        """Test that sun angles are computed without errors."""
        df = _make_itrf_df(
            [6800.0, 6800.0],
            [0.0, 0.0],
            [0.0, 0.0],
            times=pd.date_range("2025-06-21 12:00", periods=2, freq="1s"),
        )
        result = itrf_to_sun_angles(df)

        assert "solar_elevation" in result.columns
        assert "solar_azimuth" in result.columns
        assert not result["solar_elevation"].isna().any()
        assert not result["solar_azimuth"].isna().any()

    def test_elevation_range(self):
        """Test that elevation is in valid range [-90, 90]."""
        r_km = 6800.0
        n = 10
        angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
        x = r_km * np.cos(angles)
        y = r_km * np.sin(angles)
        z = np.zeros(n)
        df = _make_itrf_df(x, y, z,
                           times=pd.date_range("2025-06-21 00:00", periods=n, freq="2h"))
        result = itrf_to_sun_angles(df)

        assert (result["solar_elevation"] >= -90).all()
        assert (result["solar_elevation"] <= 90).all()

    def test_azimuth_range(self):
        """Test that azimuth is in valid range [0, 360]."""
        r_km = 6800.0
        n = 10
        angles = np.linspace(0, 2 * np.pi, n, endpoint=False)
        x = r_km * np.cos(angles)
        y = r_km * np.sin(angles)
        z = np.zeros(n)
        df = _make_itrf_df(x, y, z,
                           times=pd.date_range("2025-06-21 00:00", periods=n, freq="2h"))
        result = itrf_to_sun_angles(df)

        assert (result["solar_azimuth"] >= 0).all()
        assert (result["solar_azimuth"] <= 360).all()

    def test_nan_handling(self):
        """Test that NaN ITRF values produce NaN sun angles."""
        df = _make_itrf_df(
            [6800.0, np.nan],
            [0.0, 0.0],
            [0.0, 0.0],
        )
        result = itrf_to_sun_angles(df)

        assert not np.isnan(result["solar_elevation"].iloc[0])
        assert np.isnan(result["solar_elevation"].iloc[1])
        assert np.isnan(result["solar_azimuth"].iloc[1])

    def test_preserves_original_columns(self):
        """Test that original columns are preserved."""
        df = _make_itrf_df([6800.0], [0.0], [0.0])
        result = itrf_to_sun_angles(df)

        assert "x_itrf" in result.columns
        assert "y_itrf" in result.columns
        assert "z_itrf" in result.columns
