"""Tests for Keplerian orbit mechanics (pure math, no external services)."""

import numpy as np
import pytest

from satorbit.kepler import (
    kepler_to_cartesian,
    true_anomaly_from_mean_anomaly,
    unperturbed_mean_motion,
    unperturbed_orbitalperiod,
    perturbed_mean_motion,
    d_raan_j2_dM,
    d_argper_j2_dM,
    simulate_orbit,
)


# Standard Earth parameters
EARTH_KEPLER = {
    "mu": 398600.4415,
    "re": 6378.1363,
    "j2": 1082.6357e-6,
    "semimajoraxis": 7000.0,
    "eccentricity": 0.001,
    "inclination": np.radians(51.6),
    "argumentofperigee": np.radians(0.0),
    "raan": np.radians(0.0),
}


class TestKeplerToCartesian:
    def test_circular_orbit_radius(self):
        """For a near-circular orbit, r should be approximately equal to a."""
        kepler = EARTH_KEPLER.copy()
        kepler["eccentricity"] = 0.0
        vec = kepler_to_cartesian(kepler, 0.0)
        r = np.linalg.norm(vec[:3])
        assert abs(r - kepler["semimajoraxis"]) < 1e-6

    def test_circular_orbit_velocity_magnitude(self):
        """Velocity magnitude should match the circular orbit formula v = sqrt(mu/a)."""
        kepler = EARTH_KEPLER.copy()
        kepler["eccentricity"] = 0.0
        vec = kepler_to_cartesian(kepler, 0.0)
        v = np.linalg.norm(vec[3:])
        v_expected = np.sqrt(kepler["mu"] / kepler["semimajoraxis"])
        assert abs(v - v_expected) / v_expected < 1e-6

    def test_output_shape(self):
        vec = kepler_to_cartesian(EARTH_KEPLER, np.radians(45.0))
        assert vec.shape == (6,)

    def test_position_at_anomaly_180(self):
        """At true anomaly = pi, the satellite should be at apogee for non-circular orbit."""
        kepler = EARTH_KEPLER.copy()
        kepler["eccentricity"] = 0.1
        vec = kepler_to_cartesian(kepler, np.pi)
        r = np.linalg.norm(vec[:3])
        r_apogee = kepler["semimajoraxis"] * (1 + kepler["eccentricity"])
        assert abs(r - r_apogee) / r_apogee < 1e-6


class TestTrueAnomalyFromMeanAnomaly:
    def test_circular_orbit(self):
        """For e~0, true anomaly should approximately equal mean anomaly."""
        M = np.radians(45.0)
        theta = true_anomaly_from_mean_anomaly(M, 0.001)
        assert abs(theta - M) < 0.01

    def test_known_case_e01(self):
        """Test a known case with e=0.1."""
        M = np.radians(90.0)
        theta = true_anomaly_from_mean_anomaly(M, 0.1)
        # True anomaly should be greater than mean anomaly for 0 < M < pi
        assert theta > M
        # Should be within a reasonable range
        assert 0 < theta < np.pi

    def test_zero_mean_anomaly(self):
        """At M=0, theta should also be 0."""
        theta = true_anomaly_from_mean_anomaly(0.0, 0.1)
        assert abs(theta) < 1e-6


class TestMeanMotionAndPeriod:
    def test_period_mean_motion_relationship(self):
        """Verify n = 2*pi/T."""
        n = unperturbed_mean_motion(EARTH_KEPLER)
        T = unperturbed_orbitalperiod(EARTH_KEPLER)
        assert abs(n - 2 * np.pi / T) / n < 1e-10

    def test_perturbed_differs_from_unperturbed(self):
        """Perturbed mean motion should differ from unperturbed for non-zero J2."""
        n_unpert = unperturbed_mean_motion(EARTH_KEPLER)
        n_pert = perturbed_mean_motion(EARTH_KEPLER)
        assert n_pert != n_unpert

    def test_iss_like_period(self):
        """ISS-like orbit (~400 km) should have period ~92 minutes."""
        kepler = EARTH_KEPLER.copy()
        kepler["semimajoraxis"] = 6378.0 + 400.0
        T = unperturbed_orbitalperiod(kepler)
        T_minutes = T / 60.0
        assert 90 < T_minutes < 95


class TestJ2Rates:
    def test_raan_regression_prograde(self):
        """RAAN should regress (negative rate) for prograde orbits (i < 90)."""
        kepler = EARTH_KEPLER.copy()
        kepler["inclination"] = np.radians(51.6)
        assert d_raan_j2_dM(kepler) < 0

    def test_raan_advance_retrograde(self):
        """RAAN should advance (positive rate) for retrograde orbits (i > 90)."""
        kepler = EARTH_KEPLER.copy()
        kepler["inclination"] = np.radians(100.0)
        assert d_raan_j2_dM(kepler) > 0

    def test_raan_zero_at_90deg(self):
        """RAAN rate should be zero for polar orbits (i = 90)."""
        kepler = EARTH_KEPLER.copy()
        kepler["inclination"] = np.radians(90.0)
        assert abs(d_raan_j2_dM(kepler)) < 1e-15

    def test_argper_sign_low_inclination(self):
        """Argument of perigee should advance for low inclination orbits."""
        kepler = EARTH_KEPLER.copy()
        kepler["inclination"] = np.radians(10.0)
        assert d_argper_j2_dM(kepler) > 0

    def test_argper_sign_high_inclination(self):
        """Argument of perigee should regress for high inclination orbits."""
        kepler = EARTH_KEPLER.copy()
        kepler["inclination"] = np.radians(80.0)
        assert d_argper_j2_dM(kepler) < 0


class TestSimulateOrbit:
    def test_output_length(self):
        kepler = EARTH_KEPLER.copy()
        kepler["initial_mean_anomaly"] = 0.0
        times = np.linspace(0, 5400, 100)
        result = simulate_orbit(kepler, times)
        assert len(result) == 100

    def test_output_vectors_have_6_elements(self):
        kepler = EARTH_KEPLER.copy()
        kepler["initial_mean_anomaly"] = 0.0
        times = np.linspace(0, 5400, 10)
        result = simulate_orbit(kepler, times)
        for vec in result:
            assert len(vec) == 6
