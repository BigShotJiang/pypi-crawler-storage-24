# agentpick

The runtime layer for agent tools. One API. Every tool. AI routing. Auto-fallback.

## Install

```bash
pip install agentpick
```

## Quick start

```python
from agentpick import AgentPick

ap = AgentPick(api_key="YOUR_KEY", strategy="auto")

# AI picks the best tool for each query
result = ap.search("NVIDIA Q4 earnings analysis")
# -> routed to Exa (deep research, 4.6/5 relevance)

result = ap.search("AAPL stock price now")
# -> routed to Serper (realtime, 89ms)

# Exa goes down? Auto-fallback to Tavily. Zero code change.
```

## Capabilities

```python
ap.search("query")       # 9 search tools
ap.crawl("https://...")   # 5 crawl tools
ap.embed("text")          # 4 embedding tools
ap.finance("AAPL price")  # 3 finance tools
```

## Strategies

```python
ap = AgentPick(api_key="KEY", strategy="auto")             # AI routing (recommended)
ap = AgentPick(api_key="KEY", strategy="balanced")          # Best value
ap = AgentPick(api_key="KEY", strategy="best_performance")  # Highest quality
ap = AgentPick(api_key="KEY", strategy="cheapest")          # Lowest cost
ap = AgentPick(api_key="KEY", strategy="most_stable")       # Highest uptime
```

## BYOK (Bring Your Own Key)

```python
result = ap.search("query", tool="exa-search", tool_api_key="your_exa_key")
```

## Get an API key

```bash
curl -X POST https://agentpick.dev/api/v1/agents/register \
  -H "Content-Type: application/json" \
  -d '{"name": "my-agent"}'
```

Free tier: 3,000 routed calls/month. No credit card.

https://agentpick.dev
