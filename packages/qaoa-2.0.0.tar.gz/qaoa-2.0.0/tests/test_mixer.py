import unittest
import sys
import numpy as np
import networkx as nx

sys.path.append("../")

from Mixer import *


class TestBandAdjacencyModuloN(unittest.TestCase):
    """
    Unit tests for modulo-n band adjacency.
    Degree is defined as number of nonzero entries per row,
    and must match NetworkX degree for an undirected graph.
    """

    def test_degree_matches_networkx(self):
        test_cases = [
            (4, 2**4),
            (8, 1),
            (8, 2),
            (10, 3),
            (12, 4),
        ]

        for n, d in test_cases:
            with self.subTest(n=n, d=d):
                A = band_adjacency_mod_n(n, d)
                G = nx.from_numpy_array(A)

                row_deg = A.sum(axis=1)
                nx_deg = np.array([deg for _, deg in G.degree()])

                np.testing.assert_array_equal(
                    row_deg,
                    nx_deg,
                    err_msg=f"Row-sum and NetworkX degree differ for n={n}, d={d}",
                )


if __name__ == "__main__":
    unittest.main()

