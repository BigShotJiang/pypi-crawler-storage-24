# goCLI

Terminal error detection and auto-fix assistant. Runs as an interactive shell wrapper, watches for errors in command output, queries an AI for a fix, and applies it if you confirm.

Works on Windows, macOS, and Linux. Available in Python and Go.

## Install

### Python

```
pip install gocli-terminal
```

The `gocli` command is available globally after install.

### Go (macOS / Linux)

```
curl -fsSL https://raw.githubusercontent.com/nopedal/cmd-tree/main/go/install.sh | sh
```

### Go (Windows, PowerShell)

```powershell
irm https://raw.githubusercontent.com/nopedal/cmd-tree/main/go/install.ps1 | iex
```

Both install scripts download the right pre-built binary for your platform from GitHub Releases. No Go installation required.

## Publish a new release (Go)

The Go repo can stay private. Users download pre-built binaries from GitHub Releases — they never see the source.

1. In the `go/` directory, run the build script:

```
# Windows
release.bat

# macOS / Linux
chmod +x release.sh && ./release.sh
```

2. Go to `github.com/nopedal/cmd-tree/releases/new`
3. Create a tag (e.g. `v0.1.0`)
4. Upload all files from `go/dist/`
5. Publish the release

Users can then install with the one-liners above.

## Publish to PyPI (Python)

```
# Windows
publish.bat

# macOS / Linux
chmod +x publish.sh && ./publish.sh
```

You need a PyPI account and API token. Create one at https://pypi.org/manage/account/token/

## Configure

Set your Gemini API key as an environment variable:

```
# Linux / macOS
export GOCLI_API_KEY="your-api-key"

# Windows (cmd)
set GOCLI_API_KEY=your-api-key

# Windows (PowerShell)
$env:GOCLI_API_KEY = "your-api-key"
```

A default key is included for testing. Replace it with your own for production use.

To use a different Gemini model:

```
export GOCLI_MODEL="gemini-flash-latest"
```

## Use

Start a goCLI session:

```
gocli
```

Use it like a normal terminal. When a command fails and goCLI recognises the error pattern, it queries the AI and shows:

```
  goCLI  detected an error
         fix  pip install requests
         run? [Y/n]
```

Press Enter or Y to apply the fix. Press N to skip.

Type `exit` or `quit` to leave the session.

## Auto-start

To wrap every new terminal session automatically:

### Linux / macOS (.bashrc or .zshrc)

```
if command -v gocli &> /dev/null && [ -z "$GOCLI_ACTIVE" ]; then
    export GOCLI_ACTIVE=1
    exec gocli
fi
```

### Windows (PowerShell profile)

```powershell
if ((Get-Command gocli -ErrorAction SilentlyContinue) -and -not $env:GOCLI_ACTIVE) {
    $env:GOCLI_ACTIVE = "1"
    gocli
    exit
}
```

## Error detection

goCLI recognises these error categories out of the box:

- Python missing module and import errors
- Node.js missing package errors
- Permission denied errors
- Command not found errors (including Windows "not recognized" errors)
- Port already in use errors
- Docker errors
- Git errors
- Rust compiler errors
- Python tracebacks

The error patterns live in `watcher.py` (Python) or `internal/watcher/watcher.go` (Go) and can be extended.

## Architecture

### Python

```
gocli/
  __init__.py
  main.py       entry point, command-loop shell wrapper
  watcher.py    error pattern detection
  ai.py         Gemini API integration
  fix.py        suggestion UI and command execution
  config.py     API key, colours, constants, Windows ANSI setup
```

### Go

```
go/
  cmd/gocli/main.go              entry point, command-loop shell wrapper
  internal/config/config.go       API key, colours, constants
  internal/config/ansi_windows.go Windows ANSI setup (build-tagged)
  internal/config/ansi_other.go   no-op on Unix (build-tagged)
  internal/watcher/watcher.go     error pattern detection
  internal/ai/ai.go               Gemini API integration
  internal/fix/fix.go             suggestion UI and command execution
  install.sh                      macOS / Linux installer
  install.ps1                     Windows installer
  release.sh / release.bat        build all platform binaries for release
```

The AI backend is isolated in a single file. To swap from Gemini to another provider, replace `ai.py` or `internal/ai/ai.go` while keeping the same function signature.

## Dependencies

### Python

None beyond the standard library.

### Go

None beyond the standard library. Zero external modules.

## License

MIT
