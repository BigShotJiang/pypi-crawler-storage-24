"""
goCLI configuration.

Stores the API key, ANSI color codes, and user preferences.
All terminal styling is defined here as raw ANSI escape sequences.
Cross-platform: enables ANSI support on Windows 10+ automatically.
"""

from __future__ import annotations

import os
import sys
import platform
from typing import Final


# ---------------------------------------------------------------------------
# Windows ANSI support
# ---------------------------------------------------------------------------

def _enable_windows_ansi() -> None:
    """Enable virtual terminal processing on Windows 10+ so ANSI codes work."""
    if platform.system() != "Windows":
        return
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
        # STD_OUTPUT_HANDLE = -11, STD_ERROR_HANDLE = -12
        for handle_id in (-11, -12):
            handle = kernel32.GetStdHandle(handle_id)
            mode = ctypes.c_ulong()
            kernel32.GetConsoleMode(handle, ctypes.byref(mode))
            # ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
            kernel32.SetConsoleMode(handle, mode.value | 0x0004)
    except Exception:
        pass


_enable_windows_ansi()


# ---------------------------------------------------------------------------
# Platform detection
# ---------------------------------------------------------------------------

IS_WINDOWS: Final[bool] = platform.system() == "Windows"


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

GEMINI_API_KEY: Final[str] = os.environ.get(
    "GOCLI_API_KEY",
    "AIzaSyAw0tMVd4Jk_eoH8tGyTe11MYGo8x1ErN0",
)

GEMINI_MODEL: Final[str] = os.environ.get(
    "GOCLI_MODEL",
    "gemini-flash-latest",
)

GEMINI_ENDPOINT: Final[str] = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    "{model}:generateContent"
)

# ---------------------------------------------------------------------------
# ANSI colour palette  –  inspired by Anthropic / Claude
# ---------------------------------------------------------------------------

RESET: Final[str] = "\033[0m"

# Coral / orange accent  (#D85A30)
CORAL: Final[str] = "\033[38;2;216;90;48m"

# Warm off-white for normal text  (#F5F0EB)
OFF_WHITE: Final[str] = "\033[38;2;245;240;235m"

# Muted gray for secondary information  (#8B8685)
MUTED: Final[str] = "\033[38;2;139;134;133m"

# Bold modifier
BOLD: Final[str] = "\033[1m"

# ---------------------------------------------------------------------------
# UI constants
# ---------------------------------------------------------------------------

LABEL: Final[str] = f"{BOLD}{CORAL}goCLI{RESET}"

# How many recent commands to send as context to the AI.
CONTEXT_WINDOW: Final[int] = 5

# Seconds to wait for the AI response before timing out.
AI_TIMEOUT: Final[int] = 15
