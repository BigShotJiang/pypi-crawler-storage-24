from typing import Any


class DataDIDApiError(Exception):
    """Error raised when a DataDID API call fails."""

    def __init__(self, message: str, status_code: int, response_body: Any = None) -> None:
        super().__init__(message)
        self.status_code: int = status_code
        """HTTP status code (e.g. 401, 500)."""
        self.response_body: Any = response_body
        """Raw response body from the server."""

    def __repr__(self) -> str:
        return f"DataDIDApiError(message={str(self)!r}, status_code={self.status_code!r})"
