from dataclasses import dataclass, field
from typing import List


@dataclass
class DIDClientOptions:
    """Options for creating a DIDClient."""

    base_url: str
    """Base URL of the DID API server."""


@dataclass
class SigMsgResponse:
    """Response from GET /did/createsigmsg and GET /did/deletesigmsg."""

    msg: str


@dataclass
class CreateDIDResponse:
    """Response from POST /did/create, POST /did/createadmin, POST /did/createton."""

    did: str


@dataclass
class DeleteDIDResponse:
    """Response from POST /did/delete."""

    did: str
    status: str


@dataclass
class DIDChainInfo:
    """Chain-specific info within a DID info response."""

    address: str
    balance: str
    chain: str


@dataclass
class DIDInfoResponse:
    """Response from GET /did/info."""

    did: str
    info: List[DIDChainInfo] = field(default_factory=list)
