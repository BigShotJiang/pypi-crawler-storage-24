from dataclasses import dataclass
from typing import Optional


@dataclass
class DataClientOptions:
    """Options for creating a DataClient."""

    base_url: str
    """Base URL of the Data-BE server."""

    disable_auto_token: bool = False
    """If True, login methods will NOT auto-set the access token on the client."""


@dataclass
class AuthTokens:
    """Tokens returned by login endpoints."""

    access_token: str
    refresh_token: str


@dataclass
class EvmLoginResult(AuthTokens):
    """EVM login returns tokens + DID info."""

    did: str = ""
    number: str = ""


@dataclass
class AuthMeResponse:
    """User info from GET /v2/auth/me."""

    uid: str
    email: str
    username: str
    role: str


@dataclass
class PiInfo:
    """Pi account info."""

    pi_id: str
    pi_user_name: str
    pi_address: str


@dataclass
class TwitterInfo:
    """Twitter account info."""

    twitter_id: str
    twitter_name: str
    twitter_user_name: str


@dataclass
class TelegramInfo:
    """Telegram account info."""

    telegram_id: int
    telegram_first_name: str
    telegram_last_name: str
    telegram_user_name: str
    telegram_photo: str


@dataclass
class DiscordInfo:
    """Discord account info."""

    discord_id: str
    discord_name: str
    discord_user_name: str
    discord_email: str


@dataclass
class UserInfo:
    """Full user info from GET /v2/user/info."""

    name: str
    icon: str
    address: str
    did: str
    email: Optional[str] = None
    pi_info: Optional[PiInfo] = None
    twitter_info: Optional[TwitterInfo] = None
    telegram_info: Optional[TelegramInfo] = None
    discord_info: Optional[DiscordInfo] = None
    wechat_info: Optional[bool] = None


@dataclass
class ActionRecord:
    """Action record from GET /v2/data/record/:actionID."""

    action: int
    points: int
    time: int
