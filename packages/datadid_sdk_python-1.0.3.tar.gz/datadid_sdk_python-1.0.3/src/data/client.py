from __future__ import annotations

from typing import Any, Optional

import httpx

from ..errors import DataDIDApiError
from .types import (
    ActionRecord,
    AuthMeResponse,
    AuthTokens,
    DataClientOptions,
    DiscordInfo,
    EvmLoginResult,
    PiInfo,
    TelegramInfo,
    TwitterInfo,
    UserInfo,
)

_PRODUCTION_URL = "https://data-be.metamemo.one"
_TEST_URL = "https://test-data-be-v2.memolabs.net"


class DataClient:
    """
    Async REST client for the DataDID platform API (data-be).

    Wraps authentication, user info, and action record endpoints.
    """

    def __init__(self, options: DataClientOptions) -> None:
        self._base_url: str = options.base_url.rstrip("/")
        self._access_token: Optional[str] = None
        self._disable_auto_token: bool = options.disable_auto_token

    @classmethod
    def production(cls) -> DataClient:
        """Create a client pointing to production (https://data-be.metamemo.one)."""
        return cls(DataClientOptions(base_url=_PRODUCTION_URL))

    @classmethod
    def testnet(cls) -> DataClient:
        """Create a client pointing to the test server (https://test-data-be-v2.memolabs.net)."""
        return cls(DataClientOptions(base_url=_TEST_URL))

    def set_access_token(self, token: str) -> None:
        """Manually set the access token for authenticated requests."""
        self._access_token = token

    def get_access_token(self) -> Optional[str]:
        """Return the currently stored access token, or None."""
        return self._access_token

    # ── Auth endpoints ───────────────────────────────────────────

    async def send_email_code(self, email: str) -> None:
        """
        Send a login verification code to the given email.

        POST /v2/login/email/code
        """
        await self._request("POST", "/v2/login/email/code", {"email": email})

    async def login_with_email(
        self,
        email: str,
        code: str,
        source: str,
        useragent: Optional[str] = None,
    ) -> AuthTokens:
        """
        Log in with email and verification code.

        POST /v2/login/email
        """
        body: dict[str, Any] = {"email": email, "code": code, "source": source}
        if useragent is not None:
            body["useragent"] = useragent
        data = await self._request("POST", "/v2/login/email", body)
        tokens = self._extract_tokens(data)
        self._auto_set_token(tokens.access_token)
        return tokens

    async def register_with_email(
        self,
        email: str,
        code: str,
        password: str,
        source: str,
        useragent: Optional[str] = None,
    ) -> AuthTokens:
        """
        Register a new user with email, verification code, and password.

        POST /v2/login/email/register
        """
        body: dict[str, Any] = {
            "email": email,
            "code": code,
            "password": password,
            "source": source,
        }
        if useragent is not None:
            body["useragent"] = useragent
        data = await self._request("POST", "/v2/login/email/register", body)
        tokens = self._extract_tokens(data)
        self._auto_set_token(tokens.access_token)
        return tokens

    async def login_with_email_password(self, email: str, password: str) -> AuthTokens:
        """
        Log in with email and password.

        POST /v2/login/email/password
        """
        data = await self._request(
            "POST",
            "/v2/login/email/password",
            {"email": email, "password": password},
        )
        tokens = self._extract_tokens(data)
        self._auto_set_token(tokens.access_token)
        return tokens

    async def reset_password(self, email: str, code: str, new_password: str) -> None:
        """
        Reset password with email and verification code.

        POST /v2/login/email/password/reset
        """
        await self._request(
            "POST",
            "/v2/login/email/password/reset",
            {"email": email, "code": code, "new_password": new_password},
        )

    async def login_with_telegram(
        self,
        initdata: str,
        source: str,
        useragent: Optional[str] = None,
    ) -> AuthTokens:
        """
        Log in with Telegram init data.

        POST /v2/login/telegram
        """
        body: dict[str, Any] = {"initdata": initdata, "source": source}
        if useragent is not None:
            body["useragent"] = useragent
        data = await self._request("POST", "/v2/login/telegram", body)
        tokens = self._extract_tokens(data)
        self._auto_set_token(tokens.access_token)
        return tokens

    async def login_with_pi(
        self,
        pi_access_token: str,
        source: str,
        useragent: Optional[str] = None,
    ) -> AuthTokens:
        """
        Log in with Pi browser access token.

        POST /v2/login/pi
        """
        body: dict[str, Any] = {"source": source}
        if useragent is not None:
            body["useragent"] = useragent
        data = await self._request(
            "POST",
            "/v2/login/pi",
            body,
            extra_headers={"Authorization": pi_access_token},
        )
        tokens = self._extract_tokens(data)
        self._auto_set_token(tokens.access_token)
        return tokens

    async def get_evm_challenge(
        self,
        address: str,
        chain_id: Optional[int] = None,
        origin: Optional[str] = None,
    ) -> str:
        """
        Get the sign-in challenge message for EVM wallet login.

        GET /v2/login/evm/challenge
        """
        params: dict[str, str] = {"address": address}
        if chain_id is not None:
            params["chainid"] = str(chain_id)
        query = "&".join(f"{k}={v}" for k, v in params.items())
        headers: dict[str, str] = {}
        if origin is not None:
            headers["Origin"] = origin
        data = await self._request(
            "GET",
            f"/v2/login/evm/challenge?{query}",
            extra_headers=headers or None,
        )
        return str(data)

    async def login_with_evm(
        self,
        message: str,
        signature: str,
        source: str,
        useragent: Optional[str] = None,
    ) -> EvmLoginResult:
        """
        Log in with EVM wallet signature.

        POST /v2/login/evm
        """
        body: dict[str, Any] = {
            "message": message,
            "signature": signature,
            "source": source,
        }
        if useragent is not None:
            body["useragent"] = useragent
        data = await self._request("POST", "/v2/login/evm", body)
        result = EvmLoginResult(
            access_token=(
                data.get("access_token")
                or data.get("accessToken")
                or data.get("AccessToken")
                or ""
            ),
            refresh_token=(
                data.get("refresh_token")
                or data.get("refreshToken")
                or data.get("RefreshToken")
                or ""
            ),
            did=data.get("did", ""),
            number=data.get("number", ""),
        )
        self._auto_set_token(result.access_token)
        return result

    async def refresh_token(self, refresh_token: str) -> str:
        """
        Get a new access token using the refresh token.

        POST /v2/login/refresh
        """
        data = await self._request(
            "POST",
            "/v2/login/refresh",
            extra_headers={"Authorization": refresh_token},
        )
        new_token = (
            data.get("access_token")
            or data.get("accessToken")
            or data.get("AccessToken")
            or ""
        )
        self._auto_set_token(new_token)
        return new_token

    # ── User endpoints ───────────────────────────────────────────

    async def get_me(self) -> AuthMeResponse:
        """
        Validate access token and get current user's basic info.

        GET /v2/auth/me
        """
        data = await self._authenticated_request("GET", "/v2/auth/me")
        return AuthMeResponse(
            uid=data.get("uid", ""),
            email=data.get("email", ""),
            username=data.get("username", ""),
            role=data.get("role", ""),
        )

    async def get_user_info(self) -> UserInfo:
        """
        Get the current logged-in user's full info.

        GET /v2/user/info
        """
        data = await self._authenticated_request("GET", "/v2/user/info")

        pi_raw = data.get("pi_info")
        pi_info = (
            PiInfo(
                pi_id=pi_raw.get("pi_id", ""),
                pi_user_name=pi_raw.get("pi_user_name", ""),
                pi_address=pi_raw.get("pi_address", ""),
            )
            if pi_raw
            else None
        )

        tw_raw = data.get("twitter_info")
        twitter_info = (
            TwitterInfo(
                twitter_id=tw_raw.get("twitter_id", ""),
                twitter_name=tw_raw.get("twitter_name", ""),
                twitter_user_name=tw_raw.get("twitter_user_name", ""),
            )
            if tw_raw
            else None
        )

        tg_raw = data.get("telegram_info")
        telegram_info = (
            TelegramInfo(
                telegram_id=tg_raw.get("telegram_id", 0),
                telegram_first_name=tg_raw.get("telegram_first_name", ""),
                telegram_last_name=tg_raw.get("telegram_last_name", ""),
                telegram_user_name=tg_raw.get("telegram_user_name", ""),
                telegram_photo=tg_raw.get("telegram_photo", ""),
            )
            if tg_raw
            else None
        )

        dc_raw = data.get("discord_info")
        discord_info = (
            DiscordInfo(
                discord_id=dc_raw.get("discord_id", ""),
                discord_name=dc_raw.get("discord_name", ""),
                discord_user_name=dc_raw.get("discord_user_name", ""),
                discord_email=dc_raw.get("discord_email", ""),
            )
            if dc_raw
            else None
        )

        return UserInfo(
            name=data.get("name", ""),
            icon=data.get("icon", ""),
            address=data.get("address", ""),
            did=data.get("did", ""),
            email=data.get("email"),
            pi_info=pi_info,
            twitter_info=twitter_info,
            telegram_info=telegram_info,
            discord_info=discord_info,
            wechat_info=data.get("wechat_info"),
        )

    # ── Action record endpoints ───────────────────────────────────

    async def get_action_record(self, action_id: int) -> Optional[ActionRecord]:
        """
        Get the current user's completion record for the given action ID.
        Returns None if no record exists.

        GET /v2/data/record/:actionID
        """
        data = await self._authenticated_request("GET", f"/v2/data/record/{action_id}")
        if not data:
            return None
        return ActionRecord(
            action=data.get("action", 0),
            points=data.get("points", 0),
            time=data.get("time", 0),
        )

    async def add_action_record(self, action_id: int, opts: Any = None) -> None:
        """
        Add one action completion record for the current user.

        POST /v2/data/record/add
        """
        body: dict[str, Any] = {"actionid": action_id}
        if opts is not None:
            body["opts"] = opts
        await self._authenticated_request("POST", "/v2/data/record/add", body)

    # ── Internal helpers ─────────────────────────────────────────

    def _auto_set_token(self, token: str) -> None:
        if not self._disable_auto_token and token:
            self._access_token = token

    @staticmethod
    def _extract_tokens(data: Any) -> AuthTokens:
        return AuthTokens(
            access_token=(
                data.get("access_token")
                or data.get("accessToken")
                or data.get("AccessToken")
                or ""
            ),
            refresh_token=(
                data.get("refresh_token")
                or data.get("refreshToken")
                or data.get("RefreshToken")
                or ""
            ),
        )

    async def _authenticated_request(
        self,
        method: str,
        path: str,
        body: Optional[dict[str, Any]] = None,
    ) -> Any:
        if not self._access_token:
            raise RuntimeError(
                "No access token set. "
                "Call a login method first, or use set_access_token()."
            )
        return await self._request(
            method,
            path,
            body,
            extra_headers={"Authorization": f"Bearer {self._access_token}"},
        )

    async def _request(
        self,
        method: str,
        path: str,
        body: Optional[dict[str, Any]] = None,
        extra_headers: Optional[dict[str, str]] = None,
    ) -> Any:
        url = f"{self._base_url}{path}"
        headers: dict[str, str] = dict(extra_headers or {})
        if body is not None:
            headers["Content-Type"] = "application/json"

        async with httpx.AsyncClient() as http:
            response = await http.request(method, url, headers=headers, json=body)

        try:
            json_body = response.json()
        except Exception:
            if not response.is_success:
                raise DataDIDApiError(
                    f"HTTP {response.status_code} {response.reason_phrase}",
                    response.status_code,
                )
            return None

        # Two response formats:
        # 1. { "result": 1, "data": ... }     — most endpoints
        # 2. { "success": true, "data": ... } — /v2/auth/me
        if json_body.get("success") is False:
            raise DataDIDApiError(
                json_body.get("error") or "Request failed",
                response.status_code,
                json_body,
            )
        result_val = json_body.get("result")
        if result_val is not None and result_val != 1:
            raise DataDIDApiError(
                json_body.get("message") or f"API returned result={result_val}",
                response.status_code,
                json_body,
            )
        if (
            not response.is_success
            and result_val is None
            and json_body.get("success") is None
        ):
            raise DataDIDApiError(
                json_body.get("message")
                or json_body.get("error")
                or f"HTTP {response.status_code}",
                response.status_code,
                json_body,
            )

        return json_body.get("data")
