# ── Shared ────────────────────────────────────────────────────
from .errors import DataDIDApiError

# ── Data API (data-be.metamemo.one) ───────────────────────────
from .data.client import DataClient
from .data.types import (
    DataClientOptions,
    AuthTokens,
    EvmLoginResult,
    AuthMeResponse,
    UserInfo,
    PiInfo,
    TwitterInfo,
    TelegramInfo,
    DiscordInfo,
    ActionRecord,
)

# ── DID API (prodidapi.memolabs.org) ──────────────────────────
from .did.client import DIDClient
from .did.types import (
    DIDClientOptions,
    SigMsgResponse,
    CreateDIDResponse,
    DeleteDIDResponse,
    DIDInfoResponse,
    DIDChainInfo,
)

__all__ = [
    "DataDIDApiError",
    "DataClient",
    "DataClientOptions",
    "AuthTokens",
    "EvmLoginResult",
    "AuthMeResponse",
    "UserInfo",
    "PiInfo",
    "TwitterInfo",
    "TelegramInfo",
    "DiscordInfo",
    "ActionRecord",
    "DIDClient",
    "DIDClientOptions",
    "SigMsgResponse",
    "CreateDIDResponse",
    "DeleteDIDResponse",
    "DIDInfoResponse",
    "DIDChainInfo",
]
