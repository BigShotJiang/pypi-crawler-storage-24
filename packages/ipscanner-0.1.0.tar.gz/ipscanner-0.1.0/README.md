# Local IP Finder (`ipscanner`)

A professional, cross-platform, fast concurrent local network scanner written in Python.

This tool automatically detects your local IP address and scans your entire `/24` subnet using concurrency (`ThreadPoolExecutor`) for optimal performance, finding all active devices connected to your network.

## Features

- **Auto-detection**: Automatically finds your machine's base network so no hardcoding is necessary.
- **Concurrent Scanning**: Uses high-performance threading to ping multiple IPs up to 254 times concurrently.
- **Cross-Platform**: Configures `ping` commands based on the OS (Windows, macOS, Linux).
- **Graceful Interruptions**: Supports fast exit with clean cancellation of threads during `Ctrl+C`.
- **Customizable**: Allows defining explicit subnets, thread pool sizing, and timeouts.
- **ARP Resolution**: Lists the ARP table at the end of the scan to map IPs to MAC addresses.

## Output Example

```text
2026-03-11 11:20:05 [INFO] Auto-detected local IP: 10.121.186.162 (Base network: 10.121.186)
2026-03-11 11:20:05 [INFO] Scanning network 10.121.186.0/24 with 50 concurrent threads...
2026-03-11 11:20:06 [INFO] Active IP found: 10.121.186.1
2026-03-11 11:20:06 [INFO] Active IP found: 10.121.186.39
2026-03-11 11:20:07 [INFO] Scan complete. Found 2 active devices.

Retrieving ARP table mapping...
...
```

## Installation

You can install the tool directly from PyPI using pip:

```bash
pip install ipscanner
```

## Usage

You can run the script right away to auto-scan your local subnet:

```bash
ipscanner
```

### Advanced Usage

You can also use command-line arguments to customize behavior:

```bash
usage: ipscanner [-h] [-n NETWORK] [-t THREADS] [--timeout TIMEOUT]

A professional, fast concurrent local network scanner.

options:
  -h, --help            show this help message and exit
  -n NETWORK, --network NETWORK
                        Base network to scan (e.g., '192.168.1'). Auto-detected if not provided.
  -t THREADS, --threads THREADS
                        Number of concurrent threads for pinging (default: 50).
  --timeout TIMEOUT     Ping timeout in milliseconds (default: 1000).
```

Example setting custom threads and network segment:
```bash
ipscanner -n 192.168.0 -t 100 --timeout 500
```
