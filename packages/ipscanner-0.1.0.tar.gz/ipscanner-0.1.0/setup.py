from setuptools import setup, find_packages

setup(
    name="ipscanner",
    version="0.1.0",
    description="A professional, fast concurrent local network scanner.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Nix",
    packages=find_packages(),
    install_requires=[],
    entry_points={
        "console_scripts": [
            "ipscanner=ipscanner.cli:main",
        ]
    },
    python_requires=">=3.6",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)
