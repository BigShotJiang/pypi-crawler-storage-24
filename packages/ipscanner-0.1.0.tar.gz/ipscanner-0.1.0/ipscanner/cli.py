import argparse
import concurrent.futures
import logging
import socket
import subprocess
import platform
import sys
import re
from typing import List, Optional

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger(__name__)

def get_local_ip() -> str:
    """Get the local IP address of the machine."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # Doesn't even have to be reachable to discover local interface IP
        s.connect(('10.254.254.254', 1))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

def get_network_base(ip: str) -> str:
    """Extract the base network address from an IP (assuming /24 subnet)."""
    return ".".join(ip.split(".")[:-1])

def ping_ip(ip: str, timeout_ms: int = 1000) -> Optional[str]:
    """Ping an IP address to check if it is active."""
    # Determine the ping command based on the OS
    system_name = platform.system().lower()
    
    if system_name == "windows":
        # Windows ping: -n for count, -w for timeout in milliseconds
        cmd = ['ping', '-n', '1', '-w', str(timeout_ms), ip]
    elif system_name == "darwin":  # macOS
        # macOS ping: -c for count, -W for timeout in milliseconds
        cmd = ['ping', '-c', '1', '-W', str(timeout_ms), ip]
    else:
        # Linux ping: -c for count, -W for timeout in seconds
        # Using at least 1 second as default for backwards compatibility
        timeout_sec = max(1, timeout_ms // 1000)
        cmd = ['ping', '-c', '1', '-W', str(timeout_sec), ip]

    try:
        output = subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if output.returncode == 0:
            return ip
    except Exception as e:
        logger.debug(f"Failed to ping {ip}: {e}")
        
    return None

def scan_network(base_ip: str, max_workers: int, timeout_ms: int) -> List[str]:
    """Scan the /24 network for active hosts concurrently."""
    ips_to_ping = [f"{base_ip}.{i}" for i in range(1, 255)]
    active_ips = []
    
    logger.info(f"Scanning network {base_ip}.0/24 with {max_workers} concurrent threads...")
    
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Bind the timeout directly to the function
            futures = {executor.submit(ping_ip, ip, timeout_ms): ip for ip in ips_to_ping}
            
            for future in concurrent.futures.as_completed(futures):
                result = future.result()
                if result:
                    logger.info(f"Active IP found: {result}")
                    active_ips.append(result)
    except KeyboardInterrupt:
        logger.warning("\nScan interrupted by user. Stopping threads...")
        executor.shutdown(wait=False, cancel_futures=True)
        sys.exit(1)
        
    # Sort IPs properly
    return sorted(active_ips, key=lambda ip: int(ip.split(".")[-1]))

def display_arp_table(active_ips: List[str]):
    """Display the local ARP table to map active IP addresses to MAC addresses."""
    logger.info("Retrieving ARP table mapping...")
    try:
        output = subprocess.run(['arp', '-a'], capture_output=True, text=True, check=True)
        arp_output = output.stdout
        
        # Regex to find IP and MAC address pairs. 
        # Handles formats like:
        # ? (192.168.1.1) at 00:11:22:33:44:55
        # 192.168.1.1       00-11-22-33-44-55
        pattern = re.compile(r'(?:[\(\b])?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?:[\)\b])?\s+(?:at\s+)?([0-9a-fA-F:\-]+)(?!\s*incomplete)')
        
        mac_mapping = {}
        for line in arp_output.splitlines():
            line = line.strip()
            # Ignore incomplete entries explicitly mapped in macOS/Linux
            if 'incomplete' in line:
                continue
                
            match = pattern.search(line)
            if match:
                ip, mac = match.groups()
                # Unify MAC format (replace hyphens with colons)
                mac = mac.replace('-', ':').lower()
                mac_mapping[ip] = mac

        # Print a beautiful table
        print("\n" + "=" * 55)
        print(f"| {'IP Address':<20} | {'MAC Address':<26} |")
        print("+" + "-" * 53 + "+")
        
        found_macs = 0
        for ip in active_ips:
            mac = mac_mapping.get(ip)
            if mac:
                print(f"| {ip:<20} | {mac:<26} |")
                found_macs += 1
            else:
                print(f"| {ip:<20} | {'Unknown (or self)':<26} |")
                
        print("=" * 55 + "\n")
        logger.info(f"Mapped {found_macs} out of {len(active_ips)} active IPs to MAC addresses.")
        
    except Exception as e:
        logger.error(f"Failed to get ARP table: {e}")

def main():
    parser = argparse.ArgumentParser(
        description="A professional, fast concurrent local network scanner."
    )
    parser.add_argument(
        "-n", "--network",
        help="Base network to scan (e.g., '192.168.1'). Auto-detected if not provided.",
        type=str,
        default=None
    )
    parser.add_argument(
        "-t", "--threads",
        help="Number of concurrent threads for pinging (default: 50).",
        type=int,
        default=50
    )
    parser.add_argument(
        "--timeout",
        help="Ping timeout in milliseconds (default: 1000).",
        type=int,
        default=1000
    )
    
    args = parser.parse_args()
    
    # Identify the base network
    if args.network:
        base_ip = args.network
        logger.info(f"Using explicitly provided base network: {base_ip}.x")
    else:
        local_ip = get_local_ip()
        if local_ip == '127.0.0.1':
            logger.error("Could not auto-detect local network IP. Please provide one using --network.")
            sys.exit(1)
            
        base_ip = get_network_base(local_ip)
        logger.info(f"Auto-detected local IP: {local_ip} (Base network: {base_ip})")

    # Perform the scan
    active_devices = scan_network(base_ip, max_workers=args.threads, timeout_ms=args.timeout)
    
    logger.info(f"Scan complete. Found {len(active_devices)} active devices.")
    
    # Request ARP table 
    print()
    display_arp_table(active_devices)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.warning("\nProcess interrupted by user. Exiting...")
        sys.exit(1)
