# kickoff — project memory

## What this is
A Python CLI tool: `kickoff "I want to build a REST API"`
Installed via `pip install -e .` from the project root.

## Key facts
- Entry point: `kickoff.cli:main` (configured in pyproject.toml)
- Package: `kickoff/` directory at the repo root
- All terminal output goes through `display.py` only
- `ai.py` returns `None` on failure; cli.py silently falls back to recipe mode
- Block-character logo requires UTF-8: prefix with `PYTHONIOENCODING=utf-8` when using `python -c` or Click test runner on Windows
- Recipe confidence = -1 signals AI mode to `print_recipe()`

## File roles
- `recipes.py` — offline knowledge base (RECIPES dict)
- `matcher.py` — exact keyword scan then thefuzz fuzzy match; fallback to "generic" if score < 50
- `display.py` — all Rich rendering (logo, panels, colours)
- `ai.py`      — raw httpx call to Anthropic, normalises JSON to recipe shape
- `cli.py`     — Click entry, routing, edge-case errors
