"""
All Rich terminal-rendering logic for kickoff.

Nothing in this module performs business logic — it just takes a recipe
dict and renders it beautifully.
"""

from __future__ import annotations

import sys

from rich import box
from rich.align import Align
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

# Force UTF-8 on Windows so the block-character logo renders correctly.
# Rich also auto-detects the terminal's true capabilities.
console = Console(highlight=False)

# Reconfigure stdout to UTF-8 when the shell doesn't support it (common on
# Windows with the default CP1252 code page).
if hasattr(sys.stdout, "reconfigure"):
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ── ASCII logo ─────────────────────────────────────────────────────────────
# Generated with a box-drawing block font, aligned to 58 columns.
LOGO = """\
 ██╗  ██╗ ██╗  ██████╗ ██╗  ██╗ ██████╗ ███████╗███████╗
 ██║ ██╔╝ ██║ ██╔════╝ ██║ ██╔╝██╔═══██╗██╔════╝██╔════╝
 █████╔╝  ██║ ██║      █████╔╝ ██║   ██║█████╗  █████╗
 ██╔═██╗  ██║ ██║      ██╔═██╗ ██║   ██║██╔══╝  ██╔══╝
 ██║  ██╗ ██║ ╚██████╗ ██║  ██╗╚██████╔╝██║     ██║
 ╚═╝  ╚═╝ ╚═╝  ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═╝     ╚═╝     \
"""

TAGLINE = "Turn a vague idea into concrete first steps — instantly."


def _print_logo() -> None:
    """Render the big KICKOFF logo and tagline."""
    console.print(Text(LOGO, style="bold cyan"))
    console.print(Align.center(f"[dim]{TAGLINE}[/dim]"))
    console.print()


def print_recipe(recipe: dict, confidence: int, footer_note: str = "") -> None:
    """Render a full recipe to the terminal.

    Args:
        recipe:      The matched recipe dictionary.
        confidence:  0–100 confidence score; pass -1 to show "AI generated".
        footer_note: Optional parenthetical added next to the footer label,
                     e.g. "fell back to offline mode".
    """
    _print_logo()

    # ── Header: detected project type ─────────────────────────────────────
    header = Text()
    header.append("Detected project type: ", style="dim")
    header.append(recipe["name"], style="bold bright_green")
    console.print(Panel(header, box=box.ROUNDED, border_style="bright_blue"))
    console.print()

    # ── Recommended libraries ──────────────────────────────────────────────
    console.print("[bold bright_cyan]📦  Recommended Libraries[/bold bright_cyan]")
    console.print()
    for lib_name, reason in recipe["libraries"]:
        line = Text()
        line.append(f"  {lib_name}", style="bold yellow")
        line.append("  —  ", style="dim")
        line.append(reason, style="white")
        console.print(line)
    console.print()

    # ── First 5 terminal commands ──────────────────────────────────────────
    steps_text = Text()
    for i, step in enumerate(recipe["steps"], start=1):
        steps_text.append(f"  {i}.  ", style="bold bright_cyan")
        steps_text.append(step, style="bold green")
        if i < len(recipe["steps"]):
            steps_text.append("\n")

    console.print(
        Panel(
            steps_text,
            title="[bold bright_cyan]⚡  First 5 Commands[/bold bright_cyan]",
            border_style="green",
            box=box.ROUNDED,
        )
    )
    console.print()

    # ── Folder structure ───────────────────────────────────────────────────
    console.print(
        Panel(
            f"[dim]{recipe['structure']}[/dim]",
            title="[bold bright_cyan]📁  Folder Structure[/bold bright_cyan]",
            border_style="blue",
            box=box.ROUNDED,
        )
    )
    console.print()

    # ── Common gotcha (yellow warning) ────────────────────────────────────
    gotcha_text = Text()
    gotcha_text.append("⚠   ", style="bold yellow")
    gotcha_text.append(recipe["gotcha"])
    console.print(
        Panel(
            gotcha_text,
            title="[bold yellow]Common Gotcha[/bold yellow]",
            border_style="yellow",
            box=box.ROUNDED,
        )
    )
    console.print()

    # ── Footer ─────────────────────────────────────────────────────────────
    if confidence == -1:
        footer_label = "AI generated"
    else:
        footer_label = f"match confidence: {confidence}%"

    if footer_note:
        footer_label = f"{footer_label}  ({footer_note})"

    console.print(Align.right(f"[dim]{footer_label}[/dim]"))


def print_error(message: str, title: str = "Error") -> None:
    """Show a friendly Rich error panel instead of a raw traceback."""
    console.print()
    console.print(
        Panel(
            message,
            title=f"[bold red]{title}[/bold red]",
            border_style="red",
            box=box.ROUNDED,
        )
    )
    console.print()
