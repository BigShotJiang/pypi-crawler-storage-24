"""
Fuzzy matching logic for kickoff.

Strategy:
  1. Exact keyword match  — if any recipe keyword appears verbatim in the
     user's input, return that recipe with 100 % confidence.
  2. Fuzzy match          — compare the full input against each recipe's
     keywords (joined as a space-separated string) using thefuzz.
  3. Generic fallback     — if the best fuzzy score is below 50, nothing
     meaningful was matched; return the generic "Software Project" recipe.
"""

from __future__ import annotations

from thefuzz import fuzz

from .recipes import RECIPES


def match_recipe(user_input: str) -> tuple[dict, int]:
    """Return *(recipe, confidence)* for the given user input.

    confidence is 0–100. 100 means an exact keyword hit; lower values come
    from fuzzy matching. The generic fallback recipe is returned whenever
    nothing scores ≥ 50.
    """
    user_lower = user_input.lower().strip()

    # ── Step 1: exact keyword scan ────────────────────────────────────────
    for key, recipe in RECIPES.items():
        if key == "generic":
            continue
        for keyword in recipe["keywords"]:
            if keyword in user_lower:
                return recipe, 100

    # ── Step 2: fuzzy match against each recipe's keyword string ─────────
    best_score = 0
    best_recipe = RECIPES["generic"]

    for key, recipe in RECIPES.items():
        if key == "generic":
            continue

        # Concatenate all keywords so thefuzz can compare holistically
        keyword_string = " ".join(recipe["keywords"])
        score = fuzz.partial_ratio(user_lower, keyword_string)

        if score > best_score:
            best_score = score
            best_recipe = recipe

    # ── Step 3: confidence gate ───────────────────────────────────────────
    if best_score < 50:
        return RECIPES["generic"], best_score

    return best_recipe, best_score
