"""kickoff — Turn vague project ideas into concrete first steps."""

__version__ = "0.1.0"
