"""
Recipe database for kickoff.

Each recipe maps a project type to the keywords that trigger it, the
libraries you should reach for, five real terminal commands to get started,
a folder-layout sketch, and the one gotcha that trips up beginners.
"""

# fmt: off
RECIPES: dict = {

    # ------------------------------------------------------------------
    "rest_api": {
        "name": "REST API",
        "keywords": ["api", "rest", "fastapi", "flask", "endpoint", "backend", "server"],
        "libraries": [
            ("fastapi",       "Modern async web framework with auto-generated docs"),
            ("uvicorn",       "ASGI server needed to actually run a FastAPI app"),
            ("pydantic",      "Data validation and parsing via Python type hints"),
            ("python-dotenv", "Load secrets and config from .env files safely"),
            ("httpx",         "Async-capable HTTP client for calling external APIs"),
        ],
        "steps": [
            "mkdir my_api && cd my_api",
            "python -m venv venv && source venv/bin/activate",
            "pip install fastapi uvicorn pydantic python-dotenv",
            "touch main.py models.py .env .gitignore",
            "uvicorn main:app --reload --port 8000",
        ],
        "structure": (
            "my_api/\n"
            "├── main.py          # FastAPI app + route definitions\n"
            "├── models.py        # Pydantic request / response models\n"
            "├── routes/\n"
            "│   └── items.py     # Grouped route handlers\n"
            "├── .env             # DATABASE_URL, API keys, etc.\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Forgetting CORS middleware before your frontend calls the API — every "
            "browser request will be silently blocked. Fix: add "
            "`app.add_middleware(CORSMiddleware, allow_origins=['*'])` right after "
            "creating your FastAPI instance, before any route is defined."
        ),
    },

    # ------------------------------------------------------------------
    "web_scraper": {
        "name": "Web Scraper",
        "keywords": ["scrape", "scraper", "crawl", "spider", "beautifulsoup", "playwright", "scraping"],
        "libraries": [
            ("httpx",         "Async HTTP client — much faster than requests for bulk fetching"),
            ("beautifulsoup4","Parse and navigate HTML/XML documents with ease"),
            ("playwright",    "Full browser automation for JS-heavy or login-gated pages"),
            ("lxml",          "Blazing-fast HTML parser to use as BeautifulSoup's backend"),
            ("tenacity",      "Retry failed requests automatically with exponential backoff"),
        ],
        "steps": [
            "mkdir my_scraper && cd my_scraper",
            "python -m venv venv && source venv/bin/activate",
            "pip install httpx beautifulsoup4 lxml tenacity",
            "touch scraper.py parser.py output.json",
            "python scraper.py",
        ],
        "structure": (
            "my_scraper/\n"
            "├── scraper.py       # HTTP requests and pagination logic\n"
            "├── parser.py        # BeautifulSoup HTML parsing helpers\n"
            "├── storage.py       # Save results to JSON / CSV / SQLite\n"
            "├── output/\n"
            "│   └── data.json    # Scraped results land here\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Sending requests as fast as possible with no delays — the server detects "
            "the traffic spike and bans your IP within minutes. Fix: add "
            "`await asyncio.sleep(random.uniform(1, 3))` between requests and rotate "
            "User-Agent headers with each call."
        ),
    },

    # ------------------------------------------------------------------
    "cli_tool": {
        "name": "CLI Tool",
        "keywords": ["cli", "command line", "terminal", "argparse", "click", "tool", "command-line"],
        "libraries": [
            ("click",        "Build beautiful CLIs with decorators — zero boilerplate"),
            ("rich",         "Colorful output, progress bars, tables, and panels"),
            ("typer",        "Type-hint-driven CLI framework built on top of Click"),
            ("shellingham",  "Auto-detect the user's shell for smarter integration"),
            ("pyinstaller",  "Package the CLI into a standalone binary"),
        ],
        "steps": [
            "mkdir my_tool && cd my_tool",
            "python -m venv venv && source venv/bin/activate",
            "pip install click rich",
            "touch cli.py __main__.py",
            "pip install -e . && my-tool --help",
        ],
        "structure": (
            "my_tool/\n"
            "├── my_tool/\n"
            "│   ├── __init__.py\n"
            "│   ├── __main__.py  # Enables `python -m my_tool`\n"
            "│   └── cli.py       # Click commands and options\n"
            "├── tests/\n"
            "│   └── test_cli.py\n"
            "└── pyproject.toml   # Entry point config"
        ),
        "gotcha": (
            "Not creating a `__main__.py` in your package directory. Without it, "
            "`python -m your_tool` silently fails even though `your-tool` works fine. "
            "Fix: create `__main__.py` with just `from .cli import main; main()`."
        ),
    },

    # ------------------------------------------------------------------
    "data_pipeline": {
        "name": "Data Pipeline",
        "keywords": ["data", "pipeline", "etl", "pandas", "csv", "process", "transform", "dataframe"],
        "libraries": [
            ("pandas",             "The go-to library for tabular data manipulation"),
            ("polars",             "10–100× faster than pandas for large datasets"),
            ("duckdb",             "Run SQL queries directly on CSV and Parquet files"),
            ("pyarrow",            "Fast columnar storage with Parquet file support"),
            ("great-expectations", "Automated data-quality validation with reports"),
        ],
        "steps": [
            "mkdir my_pipeline && cd my_pipeline",
            "python -m venv venv && source venv/bin/activate",
            "pip install pandas polars duckdb pyarrow",
            "mkdir -p data/raw data/processed",
            "python pipeline.py",
        ],
        "structure": (
            "my_pipeline/\n"
            "├── pipeline.py      # Main ETL orchestration\n"
            "├── transforms.py    # Cleaning and transformation logic\n"
            "├── validate.py      # Data-quality checks\n"
            "├── data/\n"
            "│   ├── raw/         # Original input files (never modify)\n"
            "│   └── processed/   # Cleaned output files\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Using `df.iterrows()` to process rows — it is 100× slower than vectorised "
            "operations. Fix: use `df['col'].apply(fn)` or, better yet, pure vectorised "
            "pandas like `df['col'] = df['col'] * 2`, which operates on the entire "
            "column in one C-level loop."
        ),
    },

    # ------------------------------------------------------------------
    "discord_bot": {
        "name": "Discord Bot",
        "keywords": ["discord", "bot", "slash command", "discord bot", "guild"],
        "libraries": [
            ("discord.py",    "The standard async Discord API wrapper for Python"),
            ("python-dotenv", "Keep your bot token out of source control"),
            ("aiohttp",       "Async HTTP used internally by discord.py"),
            ("motor",         "Async MongoDB driver for storing user / server data"),
            ("apscheduler",   "Schedule recurring tasks like daily announcements"),
        ],
        "steps": [
            "mkdir my_bot && cd my_bot",
            "python -m venv venv && source venv/bin/activate",
            'pip install "discord.py[voice]" python-dotenv',
            "touch bot.py .env",
            "python bot.py",
        ],
        "structure": (
            "my_bot/\n"
            "├── bot.py           # Bot setup and event loop entry point\n"
            "├── cogs/\n"
            "│   ├── moderation.py\n"
            "│   └── fun.py       # Slash command groups\n"
            "├── .env             # DISCORD_TOKEN=your_token_here\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Not enabling the required Gateway Intents in the Discord Developer Portal. "
            "Your bot will silently fail to receive messages or member events with no "
            "error. Fix: enable 'Message Content Intent' and 'Server Members Intent' "
            "at discord.com/developers, then pass `intents=discord.Intents.all()` "
            "to your `commands.Bot()` constructor."
        ),
    },

    # ------------------------------------------------------------------
    "telegram_bot": {
        "name": "Telegram Bot",
        "keywords": ["telegram", "bot", "telegram bot"],
        "libraries": [
            ("python-telegram-bot", "Feature-complete async Telegram bot framework"),
            ("python-dotenv",       "Store your bot token securely in .env"),
            ("aiohttp",             "Async HTTP for webhook handling"),
            ("redis",               "Store conversation state across restarts"),
            ("apscheduler",         "Schedule timed messages and reminders"),
        ],
        "steps": [
            "mkdir my_tg_bot && cd my_tg_bot",
            "python -m venv venv && source venv/bin/activate",
            'pip install "python-telegram-bot[job-queue]" python-dotenv',
            "touch bot.py .env",
            "python bot.py",
        ],
        "structure": (
            "my_tg_bot/\n"
            "├── bot.py           # Application setup and handler registration\n"
            "├── handlers/\n"
            "│   ├── commands.py  # /start, /help, and custom commands\n"
            "│   └── messages.py  # Text and media message handlers\n"
            "├── .env             # BOT_TOKEN=your_token_here\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Calling `updater.start_polling()` inside an existing async context (e.g. "
            "inside FastAPI) crashes with 'event loop already running'. Fix: use "
            "`application.run_polling()` only as the top-level entry point of your "
            "program, or switch to webhook mode and mount the bot as an ASGI app."
        ),
    },

    # ------------------------------------------------------------------
    "machine_learning": {
        "name": "Machine Learning Model",
        "keywords": [
            "ml", "machine learning", "model", "train", "sklearn",
            "pytorch", "tensorflow", "neural", "deep learning", "predict",
        ],
        "libraries": [
            ("scikit-learn", "Classic ML: regression, classification, clustering"),
            ("torch",        "PyTorch for building and training neural networks"),
            ("pandas",       "Load and preprocess your training datasets"),
            ("matplotlib",   "Plot training curves and visualise model performance"),
            ("mlflow",       "Track experiments, metrics, and model versions"),
        ],
        "steps": [
            "mkdir my_model && cd my_model",
            "python -m venv venv && source venv/bin/activate",
            "pip install scikit-learn pandas matplotlib mlflow",
            "mkdir -p data models notebooks",
            "python train.py",
        ],
        "structure": (
            "my_model/\n"
            "├── train.py         # Training loop and evaluation metrics\n"
            "├── data_prep.py     # Feature engineering and splitting\n"
            "├── model.py         # Model architecture definition\n"
            "├── data/\n"
            "│   ├── raw/\n"
            "│   └── processed/\n"
            "├── models/          # Saved checkpoints (.pkl / .pt)\n"
            "└── notebooks/       # Exploratory data analysis"
        ),
        "gotcha": (
            "Not shuffling before splitting into train / test sets. If rows are sorted "
            "by time or label, your model reports high accuracy but fails in production "
            "because it memorised the split pattern. Fix: always call "
            "`train_test_split(X, y, shuffle=True, random_state=42)` and verify "
            "class distribution is balanced in both splits."
        ),
    },

    # ------------------------------------------------------------------
    "web_app": {
        "name": "Web Application",
        "keywords": [
            "web app", "website", "frontend", "django", "streamlit",
            "gradio", "web application", "webapp",
        ],
        "libraries": [
            ("streamlit",   "Build interactive data apps in pure Python — no HTML"),
            ("django",      "Full-featured framework with ORM, admin, and auth built in"),
            ("htmx",        "Add dynamic behaviour to plain HTML with zero JavaScript"),
            ("tailwindcss", "Utility-first CSS for rapid, consistent UI styling"),
            ("whitenoise",  "Serve static files from Django without a CDN"),
        ],
        "steps": [
            "mkdir my_webapp && cd my_webapp",
            "python -m venv venv && source venv/bin/activate",
            "pip install streamlit",
            "touch app.py",
            "streamlit run app.py",
        ],
        "structure": (
            "my_webapp/\n"
            "├── app.py           # Main Streamlit / Django entry point\n"
            "├── pages/           # Multi-page app sections\n"
            "│   └── dashboard.py\n"
            "├── components/      # Reusable UI widgets\n"
            "├── static/          # CSS, images, JS\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Storing user state in global Python variables in Streamlit. Every browser "
            "tab is an independent session, so globals cause data from one user to bleed "
            "into another. Fix: use `st.session_state['key']` for all per-user data — "
            "never module-level variables."
        ),
    },

    # ------------------------------------------------------------------
    "database": {
        "name": "Database-Backed App",
        "keywords": [
            "database", "postgres", "sqlite", "sql", "orm",
            "sqlalchemy", "db", "mysql", "postgresql",
        ],
        "libraries": [
            ("sqlalchemy",      "ORM and query builder supporting all major SQL databases"),
            ("alembic",         "Schema migration tool for SQLAlchemy — tracks every change"),
            ("psycopg2-binary", "Fast, battle-tested PostgreSQL adapter for Python"),
            ("asyncpg",         "Ultra-fast async PostgreSQL driver for high-throughput apps"),
            ("redis",           "In-memory key-value store for caching and job queues"),
        ],
        "steps": [
            "mkdir my_db_app && cd my_db_app",
            "python -m venv venv && source venv/bin/activate",
            "pip install sqlalchemy alembic psycopg2-binary python-dotenv",
            "alembic init migrations",
            "alembic revision --autogenerate -m 'initial schema'",
        ],
        "structure": (
            "my_db_app/\n"
            "├── models.py        # SQLAlchemy table definitions\n"
            "├── database.py      # Engine, session factory, connection setup\n"
            "├── crud.py          # Create / read / update / delete helpers\n"
            "├── migrations/      # Alembic migration scripts\n"
            "├── .env             # DATABASE_URL=postgresql://...\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Not closing database sessions after each request, causing connection-pool "
            "exhaustion after a few hundred requests — new requests hang forever. Fix: "
            "always wrap database calls in a context manager: "
            "`with Session() as session: ...` or use SQLAlchemy's `scoped_session`."
        ),
    },

    # ------------------------------------------------------------------
    "automation": {
        "name": "Automation Script",
        "keywords": [
            "automate", "automation", "schedule", "cron",
            "script", "task", "workflow", "batch",
        ],
        "libraries": [
            ("schedule",    "Human-friendly cron-like job scheduling in pure Python"),
            ("apscheduler", "Advanced scheduler with cron, interval, and date triggers"),
            ("watchdog",    "Monitor filesystem events and trigger actions on change"),
            ("plyer",       "Cross-platform desktop notifications"),
            ("loguru",      "Dead-simple logging with colors, rotation, and serialisation"),
        ],
        "steps": [
            "mkdir my_automation && cd my_automation",
            "python -m venv venv && source venv/bin/activate",
            "pip install schedule loguru python-dotenv",
            "touch run.py tasks.py .env",
            "python run.py",
        ],
        "structure": (
            "my_automation/\n"
            "├── run.py           # Entry point and scheduler setup\n"
            "├── tasks.py         # Individual automation functions\n"
            "├── config.py        # Timing, thresholds, and settings\n"
            "├── logs/\n"
            "│   └── app.log      # Loguru rotated log file\n"
            "└── .env             # Secrets and API tokens"
        ),
        "gotcha": (
            "Using `time.sleep(86400)` to 'schedule' daily tasks. This blocks the "
            "entire thread, cannot be interrupted cleanly, and skips every run if the "
            "process restarts at the wrong time. Fix: use the `schedule` library with "
            "`while True: schedule.run_pending(); time.sleep(60)`, or deploy the "
            "script as a real OS cron job."
        ),
    },

    # ------------------------------------------------------------------
    # Fallback: used when nothing else matches
    "generic": {
        "name": "Software Project",
        "keywords": [],
        "libraries": [
            ("rich",          "Beautiful terminal output: colours, tables, progress bars"),
            ("click",         "Build CLIs with minimal code and great UX"),
            ("python-dotenv", "Manage environment variables cleanly and safely"),
            ("loguru",        "Effortless structured logging with sane defaults"),
            ("pytest",        "The standard testing framework for Python projects"),
        ],
        "steps": [
            "mkdir my_project && cd my_project",
            "python -m venv venv && source venv/bin/activate",
            "pip install rich click python-dotenv loguru pytest",
            "touch main.py .env .gitignore",
            "python main.py",
        ],
        "structure": (
            "my_project/\n"
            "├── main.py          # Entry point\n"
            "├── utils.py         # Shared helper functions\n"
            "├── config.py        # Settings and constants\n"
            "├── tests/\n"
            "│   └── test_main.py\n"
            "├── .env\n"
            "└── requirements.txt"
        ),
        "gotcha": (
            "Installing packages globally with `pip install` instead of inside a "
            "virtual environment. This pollutes your system Python and creates version "
            "conflicts across all your projects. Fix: always start with "
            "`python -m venv venv && source venv/bin/activate` before installing "
            "anything."
        ),
    },
}
# fmt: on
