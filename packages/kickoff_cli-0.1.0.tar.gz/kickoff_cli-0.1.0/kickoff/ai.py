"""
Anthropic API integration for kickoff's --ai mode.

Uses raw httpx (no SDK) so the only dependency is httpx, which is already
in the project's requirements. On any failure the function returns None and
the caller silently falls back to offline recipe mode.
"""

from __future__ import annotations

import json
import os
from typing import Optional

import httpx

# ── Prompts ────────────────────────────────────────────────────────────────

_SYSTEM_PROMPT = (
    "You are a developer tool. Always respond with valid JSON only. "
    "No markdown, no explanation, no backticks."
)

_USER_PROMPT_TEMPLATE = """\
The user wants to start a project: "{user_input}"

Return ONLY this JSON structure:
{{
  "project_type": "short name for what this is",
  "libraries": [{{"name": "x", "reason": "under 10 words"}}],
  "steps": ["exact terminal cmd 1", "cmd 2", "cmd 3", "cmd 4", "cmd 5"],
  "structure": "folder/\\n  file.py\\n  subfolder/",
  "gotcha": "one specific mistake beginners make"
}}
Rules: steps must be real runnable terminal commands, assume Python, \
keep reasons under 10 words.\
"""

_MODEL = "claude-haiku-4-5-20251001"
_API_URL = "https://api.anthropic.com/v1/messages"


# ── Public helpers ─────────────────────────────────────────────────────────

def get_api_key() -> Optional[str]:
    """Return the Anthropic API key from the environment, or None."""
    return os.environ.get("ANTHROPIC_API_KEY")


def call_ai(user_input: str) -> Optional[dict]:
    """Call the Anthropic API and return a normalised recipe dict.

    Returns None silently on any failure (network error, bad JSON, missing
    key, etc.) so the caller can fall back to offline recipe mode.
    """
    api_key = get_api_key()
    if not api_key:
        return None

    payload = {
        "model": _MODEL,
        "max_tokens": 1024,
        "system": _SYSTEM_PROMPT,
        "messages": [
            {
                "role": "user",
                "content": _USER_PROMPT_TEMPLATE.format(user_input=user_input),
            }
        ],
    }

    try:
        with httpx.Client(timeout=30.0) as client:
            response = client.post(
                _API_URL,
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json=payload,
            )
            response.raise_for_status()

        data = response.json()
        raw_text = data["content"][0]["text"]
        parsed = json.loads(raw_text)

        # Normalise to the same shape that display.print_recipe() expects
        return {
            "name": parsed.get("project_type", "Custom Project"),
            "keywords": [],
            "libraries": [
                (lib["name"], lib["reason"])
                for lib in parsed.get("libraries", [])
            ],
            "steps": parsed.get("steps", []),
            "structure": parsed.get("structure", ""),
            "gotcha": parsed.get("gotcha", ""),
        }

    except Exception:
        # Any failure — network, HTTP error, JSON parse, key error — returns None
        return None
