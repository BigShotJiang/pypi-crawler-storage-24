"""
Entry point for the kickoff CLI.

Handles argument parsing, input validation, --ai mode orchestration, and
delegates all output to display.py.
"""

from __future__ import annotations

import sys

import click
from rich.console import Console

from .ai import call_ai, get_api_key
from .display import print_error, print_recipe
from .matcher import match_recipe

console = Console()

# Inputs shorter than this are almost certainly accidents
_MIN_INPUT_LEN = 3


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.argument("idea", required=False)
@click.option(
    "--ai",
    is_flag=True,
    default=False,
    help="Use Claude AI for a custom response (requires ANTHROPIC_API_KEY).",
)
def main(idea: str, ai: bool) -> None:
    """kickoff — Turn a vague project idea into concrete first steps.

    \b
    Examples:
      kickoff "I want to build a REST API"
      kickoff "something with bots and discord" --ai
    """

    # ── Edge case: no input ────────────────────────────────────────────────
    if not idea or not idea.strip():
        print_error(
            "Please describe your project idea.\n\n"
            '  [bold]kickoff "I want to build a web scraper"[/bold]',
            title="No Input Provided",
        )
        sys.exit(1)

    # ── Edge case: input too short to mean anything ────────────────────────
    if len(idea.strip()) < _MIN_INPUT_LEN:
        print_error(
            f"Input [bold]{idea!r}[/bold] is too short to match anything useful.\n\n"
            '  Try: [bold]kickoff "build a discord bot"[/bold]',
            title="Input Too Short",
        )
        sys.exit(1)

    # ── AI mode ───────────────────────────────────────────────────────────
    if ai:
        api_key = get_api_key()

        if not api_key:
            print_error(
                "The [bold]ANTHROPIC_API_KEY[/bold] environment variable is not set.\n\n"
                "To get one:\n"
                "  1. Visit [link=https://console.anthropic.com]console.anthropic.com[/link]\n"
                "  2. Create an account and generate an API key\n"
                "  3. Export it:  [bold]export ANTHROPIC_API_KEY=sk-ant-...[/bold]",
                title="API Key Missing",
            )
            sys.exit(1)

        console.print("[dim]  Calling Claude AI …[/dim]\n")
        ai_recipe = call_ai(idea)

        if ai_recipe:
            print_recipe(ai_recipe, confidence=-1)
            return

        # AI call failed — fall back silently
        recipe, score = match_recipe(idea)
        print_recipe(recipe, score, footer_note="fell back to offline mode")
        return

    # ── Offline recipe mode ───────────────────────────────────────────────
    recipe, score = match_recipe(idea)
    print_recipe(recipe, score)
