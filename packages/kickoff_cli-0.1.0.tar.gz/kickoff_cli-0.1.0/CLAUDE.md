# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```bash
# Install in editable mode (run once after cloning)
pip install -e .

# Run the tool
kickoff "I want to build a REST API"
kickoff "build a discord bot" --ai

# Run via python module (requires __main__.py — not present by design;
# use the installed script above)
PYTHONIOENCODING=utf-8 python -c "from kickoff.cli import main; main()" -- "your idea"

# Test specific behaviour with Click's test runner
PYTHONIOENCODING=utf-8 python -c "
from kickoff.cli import main
from click.testing import CliRunner
result = CliRunner().invoke(main, ['your idea here'])
print(result.output)
"
```

> **Windows note:** prefix every run with `PYTHONIOENCODING=utf-8` or the
> block-character logo will crash on the default CP1252 code page. The
> `display.py` module calls `sys.stdout.reconfigure(encoding='utf-8')`
> automatically when running as an installed script, but the Python `-c` and
> test-runner paths may still need the env var.

## Architecture

```
kickoff/
├── cli.py       # Click entry point — argument parsing, mode routing, error handling
├── recipes.py   # RECIPES dict: the entire offline knowledge base
├── matcher.py   # Two-stage matching: exact keyword scan → thefuzz fuzzy score
├── display.py   # All Rich output (logo, panels, colours) — no logic here
└── ai.py        # Anthropic API call via raw httpx; returns same shape as a recipe
```

**Data flow:**
```
user input → cli.py → matcher.py → display.py
                  └─ (--ai) → ai.py → display.py
                                  └─ (failure) → matcher.py → display.py
```

### Key design decisions

- **display.py is the only output layer.** Nothing in cli.py, matcher.py, or
  ai.py prints anything directly — all rendering goes through `print_recipe()`
  and `print_error()`.

- **ai.py returns `None` on any failure**, never raises. This lets cli.py do
  a clean silent fallback to recipe mode without try/except at the call site.

- **Recipes and the display format are decoupled.** `ai.py` normalises the
  Claude JSON response into the same dict shape that RECIPES uses, so
  `print_recipe()` never needs to know whether the data came from offline or
  AI mode. The only difference is passing `confidence=-1` for AI-generated
  output (which prints "AI generated" instead of a percentage).

- **match confidence of -1 signals AI mode** to `print_recipe()`. Any value
  0–100 is treated as a fuzzy-match score.

## Adding a recipe

Edit `kickoff/recipes.py`. Each entry in `RECIPES` must have:
- `name` — display string
- `keywords` — list of lowercase trigger words
- `libraries` — list of `(package_name, one_line_reason)` tuples
- `steps` — **exactly 5** real, runnable terminal commands
- `structure` — multiline folder-layout string using `├──` / `└──`
- `gotcha` — one specific non-generic beginner mistake

The generic fallback key must stay `"generic"` — `matcher.py` references it
by name.
