"""Tests for sentence.py."""

from __future__ import annotations

import pytest

from routeros.sentence import Pair, Sentence


class TestSentenceFromWords:
    def test_empty_words(self):
        s = Sentence.from_words([])
        assert s.word == ""
        assert s.tag == ""
        assert s.pairs == []
        assert s.map == {}

    def test_command_only(self):
        s = Sentence.from_words(["/ip/address"])
        assert s.word == "/ip/address"

    def test_response_word(self):
        s = Sentence.from_words(["!re"])
        assert s.word == "!re"

    def test_tag_word(self):
        s = Sentence.from_words(["!re", ".tag=r42"])
        assert s.tag == "r42"

    def test_key_value_pair(self):
        s = Sentence.from_words(["!re", "=address=10.0.0.1/24"])
        assert s.map["address"] == "10.0.0.1/24"
        assert s.pairs == [Pair("address", "10.0.0.1/24")]

    def test_key_without_value(self):
        s = Sentence.from_words(["!re", "=running"])
        assert s.map["running"] == ""
        assert s.pairs == [Pair("running", "")]

    def test_value_contains_equals(self):
        """Values that themselves contain '=' must be preserved."""
        s = Sentence.from_words(["!re", "=comment=a=b=c"])
        assert s.map["comment"] == "a=b=c"

    def test_multiple_pairs(self):
        s = Sentence.from_words(["!re", "=a=1", "=b=2", "=c=3"])
        assert s.map == {"a": "1", "b": "2", "c": "3"}
        assert [p.key for p in s.pairs] == ["a", "b", "c"]

    def test_invalid_word_raises(self):
        with pytest.raises(ValueError, match="invalid RouterOS sentence word"):
            Sentence.from_words(["!re", "badword"])

    def test_str_representation(self):
        s = Sentence.from_words(["!re", ".tag=r1", "=key=val"])
        rep = str(s)
        assert "!re" in rep
        assert "r1" in rep


class TestPair:
    def test_str(self):
        p = Pair("address", "192.168.1.1/24")
        assert "address" in str(p)
        assert "192.168.1.1/24" in str(p)
