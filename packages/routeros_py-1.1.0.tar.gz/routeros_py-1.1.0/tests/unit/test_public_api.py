"""Tests for the public API surface exposed by routeros.__init__."""

from __future__ import annotations

import routeros


class TestPublicExports:
    """Every symbol listed in __all__ must be importable."""

    def test_all_symbols_exported(self):
        for name in routeros.__all__:
            assert hasattr(routeros, name), f"{name} missing from routeros package"

    def test_version_string(self):
        assert isinstance(routeros.__version__, str)
        parts = routeros.__version__.split(".")
        assert len(parts) >= 2

    def test_dial_is_callable(self):
        assert callable(routeros.dial)

    def test_dial_tls_is_callable(self):
        assert callable(routeros.dial_tls)

    def test_cast_is_callable(self):
        assert callable(routeros.cast)

    def test_cast_optional_is_callable(self):
        assert callable(routeros.cast_optional)

    def test_typed_map_is_callable(self):
        assert callable(routeros.typed_map)

    def test_error_classes_are_exceptions(self):
        for name in [
            "RouterOSError",
            "DeviceError",
            "UnknownReplyError",
            "LoginError",
            "NoChallengeReceivedError",
            "InvalidChallengeReceivedError",
            "AlreadyAsyncError",
            "AsyncLoopEndedError",
        ]:
            cls = getattr(routeros, name)
            assert issubclass(cls, Exception)

    def test_sentence_and_pair_importable(self):
        assert routeros.Sentence is not None
        assert routeros.Pair is not None

    def test_reply_and_listen_reply_importable(self):
        assert routeros.Reply is not None
        assert routeros.ListenReply is not None
