"""Root conftest – loaded by pytest before any tests.

Registers custom markers so pytest does not warn about unknown marks.
"""


def pytest_configure(config):
    config.addinivalue_line("markers", "unit: fast unit tests, no network required")
    config.addinivalue_line(
        "markers",
        "integration: tests that require a live RouterOS device or Docker container",
    )
