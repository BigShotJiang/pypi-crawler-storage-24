"""RouterOS Python client library.

A pure-Python client for Mikrotik RouterOS devices using the RouterOS API
binary protocol.  Mirrors the Go ``github.com/go-routeros/routeros/v3``
library with Python-idiomatic additions:

* Python type casting via :func:`~routeros.cast.cast` and
  :func:`~routeros.cast.typed_map`.
* Keys and values stored in a plain :class:`dict` on every
  :class:`~routeros.sentence.Sentence`.
* Source address / port specification on :func:`dial` and :func:`dial_tls`.
* TLS/SSL support via :class:`ssl.SSLContext`.
* Standard :mod:`logging` integration (``logging.getLogger("routeros")``).

Quick start::

    import routeros

    with routeros.dial("192.168.1.1:8728", "admin", "") as c:
        reply = c.run("/ip/address/print")
        for s in reply.re:
            print(s.map)

Public API
----------
"""

from routeros.cast import cast, cast_optional, typed_map
from routeros.client import Client, dial, dial_tls
from routeros.errors import (
    AlreadyAsyncError,
    AsyncLoopEndedError,
    DeviceError,
    InvalidChallengeReceivedError,
    LoginError,
    NoChallengeReceivedError,
    RouterOSError,
    UnknownReplyError,
)
from routeros.introspect import discover_api, load_api_schema
from routeros.reply import ListenReply, Reply
from routeros.sentence import Pair, Sentence

__all__ = [
    # Factory
    "dial",
    "dial_tls",
    # Core types
    "Client",
    "Reply",
    "ListenReply",
    "Sentence",
    "Pair",
    # Type casting
    "cast",
    "cast_optional",
    "typed_map",
    # Introspection
    "discover_api",
    "load_api_schema",
    # Errors
    "RouterOSError",
    "DeviceError",
    "UnknownReplyError",
    "LoginError",
    "NoChallengeReceivedError",
    "InvalidChallengeReceivedError",
    "AlreadyAsyncError",
    "AsyncLoopEndedError",
]

__version__ = "1.1.0"
