# Quick Start

## Installation

```bash
# Recommended – uv
uv add routeros-python

# pip
pip install routeros-python
```

**Requirements:** Python ≥ 3.10, no third-party runtime dependencies.

---

## Your First Connection

```python
import routeros

with routeros.dial("192.168.1.1:8728", "admin", "") as c:
    reply = c.run("/system/identity/print")
    print(reply.re[0].map["name"])   # e.g. "MikroTik"
```

`dial()` returns a `Client` that is:
- Already authenticated (login runs automatically)
- Usable as a context manager (`with` statement closes the socket on exit)

---

## Reading Data

RouterOS returns data as **sentences**. Each `!re` sentence is one row.

```python
reply = c.run("/ip/address/print")

for s in reply.re:
    # s.map is a plain dict[str, str]
    print(s.map["address"], "on", s.map["interface"])
```

`reply.re` — list of `!re` sentences (the data rows)
`reply.done` — the final `!done` sentence

---

## Passing Parameters

Any RouterOS command words can be passed as extra arguments:

```python
# Filter by interface
reply = c.run("/ip/address/print", "?interface=ether1")

# Limit returned properties
reply = c.run("/interface/print", "=.proplist=name,type,mtu")

# Set a value
c.run("/system/identity/set", "=name=MyRouter")
```

---

## Error Handling

```python
from routeros import DeviceError

try:
    c.run("/nonexistent/command")
except DeviceError as e:
    print("Device error:", e.message)
except routeros.RouterOSError as e:
    print("Library error:", e)
```

---

## Next Steps

| Topic | Guide |
|---|---|
| Type casting | [type-casting.md](type-casting.md) |
| Concurrent requests | [async.md](async.md) |
| Real-time streaming | [listener.md](listener.md) |
| TLS / SSL | [tls-ssl.md](tls-ssl.md) |
| Full API reference | [api-reference.md](api-reference.md) |
| Docker test setup | [docker-testing.md](docker-testing.md) |
