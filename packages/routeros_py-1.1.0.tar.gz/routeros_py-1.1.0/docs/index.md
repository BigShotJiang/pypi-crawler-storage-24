# routeros-python Documentation

Pure-Python client library for Mikrotik RouterOS devices.

## Contents

| Document | Description |
|---|---|
| [quickstart.md](quickstart.md) | Installation and first steps |
| [api-reference.md](api-reference.md) | Complete API reference |
| [introspect.md](introspect.md) | API schema discovery and `inspect.json` format |
| [type-casting.md](type-casting.md) | Casting RouterOS strings to Python types |
| [async.md](async.md) | Concurrent/asynchronous request mode |
| [listener.md](listener.md) | Real-time streaming with listeners |
| [tls-ssl.md](tls-ssl.md) | TLS/SSL encrypted connections |
| [docker-testing.md](docker-testing.md) | Running RouterOS in Docker for tests |
| [integration-testing.md](integration-testing.md) | Running the integration test suite |

## Package features at a glance

```
routeros.dial()              → connect via TCP
routeros.dial_tls()          → connect via TLS/SSL

Client.run()                 → synchronous command
Client.async_start()         → enable concurrent mode
Client.listen()              → streaming real-time events

cast(value, type)            → convert RouterOS string to Python type
typed_map(sentence, schema)  → convert whole sentence at once

routeros.discover_api(c)     → discover & cache full API schema (nested tree)
routeros.load_api_schema(v)  → load a saved schema from disk
```
