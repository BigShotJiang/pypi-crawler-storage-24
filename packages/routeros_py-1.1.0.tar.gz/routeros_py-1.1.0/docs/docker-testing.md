# Docker Test Environment

The `docker/` directory contains a Docker Compose setup that runs a
RouterOS VM so you can run integration tests without a physical device.

---

## Prerequisites

- Docker Desktop (Windows/macOS) or Docker Engine (Linux)
- `docker compose` v2+

---

## Starting the container

```bash
cd routeros/docker

# (Optional) copy and edit the env file
cp ../. env.example ../.env

docker compose up -d
```

RouterOS takes **~60 seconds** to boot fully.  The health check waits
until port 8728 is reachable before the container is marked `healthy`.

```bash
# Watch health status
docker compose ps
# Wait until Status shows "(healthy)"
```

---

## Running integration tests

```bash
# From the routeros/ project root:
cp .env.example .env
# Edit .env – the defaults match the Docker Compose network:
#   ROUTEROS_HOST=127.0.0.1
#   ROUTEROS_PORT=8728
#   ROUTEROS_USER=admin
#   ROUTEROS_PASSWORD=

uv run pytest tests/integration/ -v -m integration
```

---

## Environment variables (docker/.env)

The Docker Compose file reads these from the project-root `.env`:

| Variable | Default | Description |
|---|---|---|
| `ROUTEROS_IMAGE` | `evilfreelancer/docker-routeros:latest` | Docker image |
| `CONTAINER_NAME` | `routeros` | Container name |
| `API_PORT` | `8728` | Host port for the plain API |
| `API_SSL_PORT` | `8729` | Host port for API-SSL |
| `WINBOX_PORT` | `8291` | Host port for Winbox |
| `SSH_PORT` | `22` | Host port for SSH |
| `ROUTEROS_IP` | `172.20.0.2` | Container IP |
| `NETWORK_SUBNET` | `172.20.0.0/24` | Docker bridge subnet |

---

## Stopping and cleaning up

```bash
docker compose down          # stop container, keep volume
docker compose down -v       # stop and remove persistent volume
```

---

## Troubleshooting

**Container exits immediately:**
- RouterOS requires `privileged: true` and `/dev/net/tun` access.
  Make sure Docker has these capabilities.

**Health check never passes:**
- Run `docker compose logs routeros` to see the boot log.
- The first boot may take up to 2–3 minutes on slow machines.

**Integration tests skip:**
- Check that `ROUTEROS_HOST` and `ROUTEROS_PORT` in `.env` match the
  exposed Docker port (default `127.0.0.1:8728`).
- Run `docker compose ps` to confirm the container is healthy.
