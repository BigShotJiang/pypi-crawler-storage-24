"""Configuration and credential management for Autotapeout CLI."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

# Default server
DEFAULT_SERVER = "https://autotapeout.com"

CONFIG_DIR = Path.home() / ".autotapeout"
CONFIG_FILE = CONFIG_DIR / "config.json"
CREDENTIALS_FILE = CONFIG_DIR / "credentials.json"


def _ensure_dir():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load configuration from disk."""
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
    return {}


def save_config(cfg: dict):
    """Persist configuration to disk."""
    _ensure_dir()
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2), encoding="utf-8")


def get_server() -> str:
    """Return the configured server URL."""
    return os.environ.get("AUTOTAPEOUT_SERVER") or load_config().get("server", DEFAULT_SERVER)


def set_server(url: str):
    """Set the server URL."""
    cfg = load_config()
    cfg["server"] = url.rstrip("/")
    save_config(cfg)


def get_token() -> Optional[str]:
    """Retrieve the stored authentication token."""
    env_token = os.environ.get("AUTOTAPEOUT_TOKEN")
    if env_token:
        return env_token
    if CREDENTIALS_FILE.exists():
        creds = json.loads(CREDENTIALS_FILE.read_text(encoding="utf-8"))
        return creds.get("token")
    return None


def save_token(token: str):
    """Store authentication token on disk."""
    _ensure_dir()
    # Restrict file permissions on Unix-like systems
    CREDENTIALS_FILE.write_text(
        json.dumps({"token": token}, indent=2), encoding="utf-8"
    )
    try:
        CREDENTIALS_FILE.chmod(0o600)
    except OSError:
        pass  # Windows doesn't support Unix permissions


def clear_token():
    """Remove stored credentials."""
    if CREDENTIALS_FILE.exists():
        CREDENTIALS_FILE.unlink()


def get_output_dir() -> Path:
    """Return the default output directory for downloaded files."""
    cfg = load_config()
    d = Path(cfg.get("output_dir", "."))
    d.mkdir(parents=True, exist_ok=True)
    return d


def set_output_dir(path: str):
    """Set the default output directory."""
    cfg = load_config()
    cfg["output_dir"] = str(Path(path).resolve())
    save_config(cfg)
