"""Autotapeout — AI Silicon Compiler CLI"""

__version__ = "1.0.1"
