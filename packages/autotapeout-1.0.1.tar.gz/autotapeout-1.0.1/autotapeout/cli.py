"""Autotapeout CLI — AI Silicon Compiler.

Usage:
    autotapeout compile "Design a RISC-V CPU with UART and GPIO"
    autotapeout compile --file my_design.v --name my_chip
    autotapeout templates
    autotapeout template uart_full | autotapeout compile --name uart_soc --stdin
    autotapeout status <job_id>
    autotapeout jobs
    autotapeout download <job_id>
"""

from __future__ import annotations

import os
import sys
import asyncio
import getpass
import time
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskID
from rich.live import Live
from rich.text import Text
from rich.markdown import Markdown
from rich import box

from . import __version__
from .client import Client, AutotapeoutError, AuthenticationError, APIError
from .config import (
    get_server, set_server, get_token, save_token, clear_token,
    get_output_dir, set_output_dir,
)

console = Console()

# ── Detect if terminal supports Unicode ──────────────────────────────────

def _supports_unicode() -> bool:
    """Check if the terminal can render Unicode characters."""
    import sys
    try:
        encoding = sys.stdout.encoding or ""
        return encoding.lower() in ("utf-8", "utf8", "utf-16", "utf-32", "cp65001")
    except Exception:
        return False

_UNICODE = _supports_unicode()

# ── Pipeline stage display ───────────────────────────────────────────────

if _UNICODE:
    STAGE_LABELS = {
        "queued": ("⏳", "Queued"),
        "llm_generation": ("🧠", "Generating RTL"),
        "parsing": ("📄", "Parsing"),
        "synthesis": ("⚙️", "Synthesis"),
        "floorplan": ("📐", "Floorplan"),
        "placement": ("📍", "Placement"),
        "cts": ("🕐", "Clock Tree"),
        "routing": ("🔀", "Routing"),
        "padframe": ("🔲", "Padframe"),
        "signoff": ("✅", "Signoff"),
        "gds": ("💾", "GDS Export"),
        "complete": ("🎉", "Complete"),
        "failed": ("❌", "Failed"),
    }
    SYM_OK = "✓"
    SYM_FAIL = "✗"
    SYM_DOT = "●"
    SYM_DIAMOND = "◆"
else:
    STAGE_LABELS = {
        "queued": ("[.]", "Queued"),
        "llm_generation": ("[>]", "Generating RTL"),
        "parsing": ("[>]", "Parsing"),
        "synthesis": ("[>]", "Synthesis"),
        "floorplan": ("[>]", "Floorplan"),
        "placement": ("[>]", "Placement"),
        "cts": ("[>]", "Clock Tree"),
        "routing": ("[>]", "Routing"),
        "padframe": ("[>]", "Padframe"),
        "signoff": ("[>]", "Signoff"),
        "gds": ("[>]", "GDS Export"),
        "complete": ("[+]", "Complete"),
        "failed": ("[X]", "Failed"),
    }
    SYM_OK = "[OK]"
    SYM_FAIL = "[X]"
    SYM_DOT = "*"
    SYM_DIAMOND = "*"

STAGE_ORDER = [
    "queued", "llm_generation", "parsing", "synthesis", "floorplan",
    "placement", "cts", "routing", "padframe", "signoff", "gds", "complete",
]


def _get_client() -> Client:
    """Build a Client from stored config/credentials."""
    return Client(server=get_server(), token=get_token())


def _run(coro):
    """Run an async coroutine."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop and loop.is_running():
        # Shouldn't happen in CLI context, but handle gracefully
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return pool.submit(asyncio.run, coro).result()
    return asyncio.run(coro)


# ── CLI Group ────────────────────────────────────────────────────────────

@click.group(invoke_without_command=True)
@click.version_option(__version__, prog_name="autotapeout")
@click.pass_context
def main(ctx):
    """Autotapeout — AI Silicon Compiler.

    Compile chip designs from English prompts or Verilog files.
    Outputs fab-ready GDSII layouts via cloud synthesis.

    Get started:

    \b
      autotapeout login
      autotapeout compile "Design a UART controller"
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


# ── Auth Commands ────────────────────────────────────────────────────────

@main.command()
@click.option("--email", prompt="Email", help="Your Autotapeout account email.")
def login(email: str):
    """Authenticate with the Autotapeout server."""
    password = getpass.getpass("Password: ")

    async def _login():
        async with _get_client() as c:
            token = await c.login(email, password)
            save_token(token)
            user = await c.whoami()
            return user

    try:
        user = _run(_login())
        console.print(f"\n[bold green]{SYM_OK}[/] Logged in as [bold]{user.get('email', email)}[/]")
        console.print(f"  Token saved to [dim]~/.autotapeout/credentials.json[/]")
    except AuthenticationError:
        console.print(f"[bold red]{SYM_FAIL}[/] Invalid credentials. Check your email and password.")
        raise SystemExit(1)
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


@main.command()
def logout():
    """Remove stored credentials."""
    clear_token()
    console.print(f"[bold green]{SYM_OK}[/] Credentials removed.")


@main.command()
def whoami():
    """Show the current authenticated user."""
    async def _whoami():
        async with _get_client() as c:
            return await c.whoami()

    try:
        user = _run(_whoami())
        console.print(f"[bold]{user.get('email', 'unknown')}[/]")
        console.print(f"  Role: {user.get('role', 'user')}")
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


# ── Server Config ────────────────────────────────────────────────────────

@main.command()
@click.argument("url", required=False)
def server(url: Optional[str]):
    """Show or set the Autotapeout server URL.

    \b
    Examples:
      autotapeout server                         # show current server
      autotapeout server https://autotapeout.com  # set server
    """
    if url:
        set_server(url)
        console.print(f"[bold green]{SYM_OK}[/] Server set to [bold]{url}[/]")
    else:
        console.print(f"Server: [bold]{get_server()}[/]")


@main.command()
def health():
    """Check server connectivity and GPU status."""
    async def _health():
        async with _get_client() as c:
            return await c.health()

    try:
        h = _run(_health())
        status = h.get("status", "unknown")
        color = "green" if status == "healthy" else "red"
        console.print(f"\n[bold {color}]{SYM_DOT}[/] Server: [bold]{get_server()}[/]")
        console.print(f"  Status: [bold {color}]{status}[/]")
        if "gpu_available" in h:
            gpu = "available" if h["gpu_available"] else "unavailable"
            gpu_color = "green" if h["gpu_available"] else "yellow"
            console.print(f"  GPU: [bold {gpu_color}]{gpu}[/]")
        if "active_jobs" in h:
            console.print(f"  Active jobs: {h['active_jobs']}")
        console.print()
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] Cannot reach server: {e}")
        raise SystemExit(1)
    except Exception as e:
        console.print(f"[bold red]{SYM_FAIL}[/] Connection failed: {e}")
        console.print(f"  Server: {get_server()}")
        console.print(f"  Check your connection or run: [bold]autotapeout server <url>[/]")
        raise SystemExit(1)


# ── Templates ────────────────────────────────────────────────────────────

@main.command()
def templates():
    """List all available IP templates.

    \b
    Templates are pre-verified Verilog IP blocks you can synthesize
    directly without writing any code.

    \b
    Examples:
      autotapeout templates
      autotapeout template uart_full
      autotapeout compile --template uart_full --name my_uart
    """
    async def _templates():
        async with _get_client() as c:
            return await c.list_templates()

    try:
        tpls = _run(_templates())
        if not tpls:
            console.print("[dim]No templates available.[/]")
            return

        table = Table(
            title="Available IP Templates",
            box=box.ROUNDED,
            title_style="bold cyan",
            header_style="bold",
        )
        table.add_column("Name", style="bold green")
        table.add_column("Module", style="cyan")
        table.add_column("Category", style="yellow")
        table.add_column("Description")
        table.add_column("Cells", justify="right", style="magenta")
        table.add_column("Verified", justify="center")

        for t in tpls:
            cells = str(t.get("verified_cells", "—")) if t.get("verified_cells") else "—"
            verified = f"[green]{SYM_OK}[/]" if t.get("verified") else "[dim]-[/]"
            table.add_row(
                t["name"], t.get("module", "—"), t.get("category", "—"),
                t.get("description", "")[:60], cells, verified,
            )

        console.print(table)
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


@main.command()
@click.argument("name")
@click.option("--rtl", is_flag=True, help="Print only the raw Verilog code (for piping).")
def template(name: str, rtl: bool):
    """Show details for a specific IP template.

    \b
    Examples:
      autotapeout template uart_full           # show info + RTL
      autotapeout template uart_full --rtl     # print raw Verilog only
      autotapeout template uart_full --rtl > uart.v  # save to file
    """
    async def _template():
        async with _get_client() as c:
            return await c.get_template(name)

    try:
        data = _run(_template())
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)

    rtl_code = data.get("rtl_code", "")
    tpl = data.get("template", {})

    if rtl:
        # Raw output for piping
        click.echo(rtl_code)
        return

    console.print(f"\n[bold cyan]{name}[/]")
    console.print(f"  Module:   [bold]{tpl.get('module', '—')}[/]")
    console.print(f"  Category: {tpl.get('category', '—')}")
    console.print(f"  {tpl.get('description', '')}")
    if tpl.get("parameters"):
        console.print(f"\n  [bold]Parameters:[/]")
        for k, v in tpl["parameters"].items():
            console.print(f"    {k}: {v}")
    if rtl_code:
        console.print(f"\n  [dim]{len(rtl_code.splitlines())} lines of Verilog[/]")
        console.print(f"  [dim]Use --rtl to print the code, or pipe to compile:[/]")
        console.print(f"  [bold]autotapeout compile --template {name} --name {name}_chip[/]\n")


# ── Compile (the main command) ───────────────────────────────────────────

@main.command()
@click.argument("prompt", required=False)
@click.option("--name", "-n", "design_name", help="Design name (alphanumeric + underscore).")
@click.option("--file", "-f", "verilog_file", type=click.Path(exists=True), help="Path to a Verilog (.v) file.")
@click.option("--template", "-t", "template_name", help="Use an IP template by name.")
@click.option("--freq", default=100.0, show_default=True, help="Target frequency in MHz.")
@click.option("--width", "die_w", default=1000.0, help="Die width in µm (auto-sized if omitted).")
@click.option("--height", "die_h", default=1000.0, help="Die height in µm (auto-sized if omitted).")
@click.option("--opt", type=click.Choice(["area", "speed", "power", "balanced"]), default="balanced", show_default=True, help="Optimization target.")
@click.option("--output", "-o", "output_dir", type=click.Path(), help="Output directory for downloaded files.")
@click.option("--no-download", is_flag=True, help="Don't auto-download GDS on completion.")
@click.option("--stdin", is_flag=True, help="Read Verilog from stdin.")
def compile(
    prompt: Optional[str],
    design_name: Optional[str],
    verilog_file: Optional[str],
    template_name: Optional[str],
    freq: float,
    die_w: float,
    die_h: float,
    opt: str,
    output_dir: Optional[str],
    no_download: bool,
    stdin: bool,
):
    """Compile a chip design — from English or Verilog to GDSII.

    \b
    Submit a natural language prompt:
      autotapeout compile "Design a UART controller with FIFO buffers"

    \b
    Submit a Verilog file:
      autotapeout compile --file alu.v --name my_alu

    \b
    Use a pre-built template:
      autotapeout compile --template uart_full --name uart_chip

    \b
    Pipe Verilog from another command:
      cat design.v | autotapeout compile --name my_design --stdin

    \b
    The CLI will stream live synthesis progress and automatically
    download the GDSII file when compilation completes.
    """
    # Require authentication
    if not get_token():
        console.print(f"[bold red]{SYM_FAIL}[/] Not logged in. Run [bold]autotapeout login[/] first.")
        raise SystemExit(1)

    # Determine input mode
    rtl_code = None
    if stdin:
        rtl_code = sys.stdin.read()
        if not rtl_code.strip():
            console.print(f"[bold red]{SYM_FAIL}[/] No input received from stdin.")
            raise SystemExit(1)
    elif verilog_file:
        rtl_code = Path(verilog_file).read_text(encoding="utf-8")
        if not design_name:
            design_name = Path(verilog_file).stem
    elif template_name:
        # Fetch template RTL
        async def _fetch_tpl():
            async with _get_client() as c:
                return await c.get_template(template_name)
        try:
            tpl_data = _run(_fetch_tpl())
            rtl_code = tpl_data.get("rtl_code", "")
            if not design_name:
                design_name = template_name
        except AutotapeoutError as e:
            console.print(f"[bold red]{SYM_FAIL}[/] Template error: {e}")
            raise SystemExit(1)
    elif not prompt:
        console.print(f"[bold red]{SYM_FAIL}[/] Provide a prompt, --file, --template, or --stdin.")
        console.print("  Run [bold]autotapeout compile --help[/] for usage.")
        raise SystemExit(1)

    if not design_name:
        # Auto-generate from prompt
        words = (prompt or "design").split()[:3]
        design_name = "_".join(w.lower() for w in words if w.isalnum())[:32] or "design"
        # Ensure it starts with a letter
        if not design_name[0].isalpha():
            design_name = "d_" + design_name

    out_dir = Path(output_dir) if output_dir else Path.cwd()

    # Print header
    console.print()
    console.print(Panel(
        f"[bold]Design:[/] {design_name}\n"
        + (f"[bold]Prompt:[/] {prompt[:80]}{'...' if prompt and len(prompt) > 80 else ''}\n" if prompt else "")
        + (f"[bold]Source:[/] {verilog_file or template_name or 'stdin'}\n" if rtl_code else "")
        + f"[bold]Freq:[/] {freq} MHz  [bold]Opt:[/] {opt}  [bold]Tech:[/] Sky130",
        title=f"[bold green]{SYM_DIAMOND} Autotapeout Compile[/]",
        border_style="green",
        width=80,
    ))

    async def _compile_and_watch():
        async with _get_client() as c:
            # Submit
            try:
                if rtl_code:
                    job = await c.submit_verilog(
                        design_name, rtl_code,
                        frequency_mhz=freq, die_width_um=die_w,
                        die_height_um=die_h, optimization=opt,
                    )
                else:
                    job = await c.submit_prompt(
                        design_name, prompt,
                        frequency_mhz=freq, die_width_um=die_w,
                        die_height_um=die_h, optimization=opt,
                    )
            except AutotapeoutError as e:
                console.print(f"\n[bold red]{SYM_FAIL}[/] Submission failed: {e}")
                raise SystemExit(1)

            job_id = job["job_id"]
            console.print(f"\n  [dim]Job ID:[/] [bold]{job_id}[/]")
            console.print(f"  [dim]Track:[/] autotapeout status {job_id}")
            console.print()

            # Live progress
            final_stage = await _watch_progress(c, job_id)

            # Download on success
            if final_stage == "complete" and not no_download:
                await _download_outputs(c, job_id, design_name, out_dir)

            return final_stage

    try:
        result = _run(_compile_and_watch())
        if result == "failed":
            raise SystemExit(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted.[/] Job is still running on the server.")
        console.print("  Resume watching with: [bold]autotapeout status <job_id>[/]")
        raise SystemExit(130)


async def _watch_progress(client: Client, job_id: str) -> str:
    """Stream live progress updates. Returns final stage."""
    start_time = time.time()
    last_stage = ""
    last_progress = 0.0

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=40, complete_style="green", finished_style="bold green"),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TextColumn("[dim]{task.fields[elapsed]}[/]"),
        console=console,
        transient=False,
    ) as progress:
        task = progress.add_task("Starting...", total=100, elapsed="0s")

        try:
            async for update in client.watch(job_id):
                stage = update.get("stage", last_stage)
                pct = float(update.get("progress", last_progress)) * 100
                msg = update.get("message", "")
                elapsed = f"{time.time() - start_time:.0f}s"

                icon, label = STAGE_LABELS.get(stage, ("", stage))
                description = f"{icon} {label}"
                if msg and len(msg) < 60:
                    description += f" — [dim]{msg}[/]"

                progress.update(task, completed=pct, description=description, elapsed=elapsed)
                last_stage = stage
                last_progress = float(update.get("progress", last_progress))

                if stage in ("complete", "failed"):
                    break
        except Exception:
            # WebSocket failed — fall back to polling
            pass

        # If WebSocket didn't finish, poll until done
        if last_stage not in ("complete", "failed"):
            while True:
                try:
                    status = await client.get_status(job_id)
                    stage = status.get("stage", last_stage)
                    pct = float(status.get("progress", 0)) * 100
                    msg = status.get("message", "")
                    elapsed = f"{time.time() - start_time:.0f}s"

                    icon, label = STAGE_LABELS.get(stage, ("", stage))
                    description = f"{icon} {label}"
                    if msg and len(msg) < 60:
                        description += f" — [dim]{msg}[/]"

                    progress.update(task, completed=pct, description=description, elapsed=elapsed)
                    last_stage = stage

                    if stage in ("complete", "failed"):
                        break
                except Exception:
                    pass
                await asyncio.sleep(3)

        # Final update
        elapsed = f"{time.time() - start_time:.0f}s"
        if last_stage == "complete":
            icon_c, label_c = STAGE_LABELS["complete"]
            progress.update(task, completed=100, description=f"[bold green]{icon_c} {label_c}[/]", elapsed=elapsed)
        elif last_stage == "failed":
            icon_f, label_f = STAGE_LABELS["failed"]
            progress.update(task, completed=pct, description=f"[bold red]{icon_f} {label_f}[/]", elapsed=elapsed)

    # Print result
    console.print()
    if last_stage == "complete":
        # Fetch final metrics
        try:
            status = await client.get_status(job_id)
            metrics = status.get("metrics", {})
            if metrics:
                _print_signoff(metrics)
        except Exception:
            pass
    elif last_stage == "failed":
        try:
            status = await client.get_status(job_id)
            console.print(f"  [red]Error:[/] {status.get('message', 'Unknown error')}")
        except Exception:
            pass
        console.print()

    return last_stage


def _print_signoff(metrics: dict):
    """Print synthesis signoff results."""
    table = Table(box=box.SIMPLE_HEAVY, title="Signoff Results", title_style="bold")

    table.add_column("Metric", style="bold")
    table.add_column("Value", justify="right")
    table.add_column("Status", justify="center")

    cells = metrics.get("cell_count", "—")
    area = metrics.get("die_area_um2", metrics.get("area_um2", "—"))
    drc = metrics.get("drc_violations", "—")
    lvs = metrics.get("lvs_pass", None)
    wns = metrics.get("wns_ns", "—")
    tns = metrics.get("tns_ns", "—")
    fab = metrics.get("fab_ready", False)

    table.add_row("Cells", str(cells), "")
    if area != "—":
        table.add_row("Die Area", f"{float(area):,.0f} µm²", "")

    drc_status = f"[green]{SYM_OK} Clean[/]" if drc == 0 else f"[red]{drc} violations[/]"
    table.add_row("DRC", str(drc), drc_status)

    lvs_status = f"[green]{SYM_OK} Match[/]" if lvs else f"[red]{SYM_FAIL} Mismatch[/]"
    table.add_row("LVS", "Pass" if lvs else "Fail", lvs_status)

    wns_status = f"[green]{SYM_OK} Met[/]" if isinstance(wns, (int, float)) and wns >= 0 else f"[red]{SYM_FAIL} Violation[/]"
    table.add_row("WNS", f"{wns} ns" if wns != "—" else "—", wns_status)
    table.add_row("TNS", f"{tns} ns" if tns != "—" else "—", "")

    console.print(table)

    if fab:
        console.print(Panel(
            "[bold green]FAB READY[/] — Design passes all signoff checks",
            border_style="green", width=60,
        ))
    console.print()


async def _download_outputs(client: Client, job_id: str, design_name: str, out_dir: Path):
    """Download all available output files."""
    out_dir.mkdir(parents=True, exist_ok=True)

    files_to_try = [
        ("gds", f"{design_name}.gds"),
        ("def", f"{design_name}.def"),
        ("rtl", f"{design_name}.v"),
        ("netlist", f"{design_name}.synthesis.v"),
        ("report", f"{design_name}_report.json"),
        ("log", f"{design_name}_synthesis.log"),
    ]

    console.print("[bold]Downloading outputs...[/]")

    downloaded = []
    for file_type, filename in files_to_try:
        dest = out_dir / filename
        try:
            await client.download(job_id, file_type, dest)
            size = dest.stat().st_size
            if size > 1_000_000:
                size_str = f"{size / 1_000_000:.1f} MB"
            elif size > 1_000:
                size_str = f"{size / 1_000:.1f} KB"
            else:
                size_str = f"{size} B"
            console.print(f"  [green]{SYM_OK}[/] {filename} [dim]({size_str})[/]")
            downloaded.append(dest)
        except APIError:
            pass  # File not available — skip silently

    if downloaded:
        gds = out_dir / f"{design_name}.gds"
        if gds.exists():
            console.print(f"\n[bold green]{SYM_DIAMOND} GDS ready:[/] {gds.resolve()}")
    else:
        console.print("  [yellow]No output files available yet.[/]")
    console.print()


# ── Status & Jobs ────────────────────────────────────────────────────────

@main.command()
@click.argument("job_id")
@click.option("--watch", "-w", "watch_live", is_flag=True, help="Stream live updates until completion.")
@click.option("--download", "-d", is_flag=True, help="Download outputs if job is complete.")
def status(job_id: str, watch_live: bool, download: bool):
    """Check the status of a synthesis job.

    \b
    Examples:
      autotapeout status abc-123-def
      autotapeout status abc-123-def --watch     # live updates
      autotapeout status abc-123-def --download   # download outputs
    """
    async def _status():
        async with _get_client() as c:
            s = await c.get_status(job_id)

            stage = s.get("stage", "unknown")
            icon, label = STAGE_LABELS.get(stage, ("", stage))
            pct = float(s.get("progress", 0)) * 100

            console.print(f"\n  [bold]{s.get('design_name', '—')}[/] [{job_id}]")
            console.print(f"  {icon} {label} — {pct:.0f}%")
            console.print(f"  {s.get('message', '')}")

            metrics = s.get("metrics", {})
            if metrics:
                _print_signoff(metrics)

            if watch_live and stage not in ("complete", "failed"):
                console.print()
                await _watch_progress(c, job_id)

            if download and stage == "complete":
                name = s.get("design_name", "design")
                await _download_outputs(c, job_id, name, Path.cwd())

    try:
        _run(_status())
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


@main.command()
@click.option("--limit", "-l", default=20, show_default=True, help="Number of jobs to show.")
def jobs(limit: int):
    """List recent synthesis jobs.

    \b
    Examples:
      autotapeout jobs
      autotapeout jobs --limit 50
    """
    async def _jobs():
        async with _get_client() as c:
            return await c.list_jobs(limit=limit)

    try:
        data = _run(_jobs())
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)

    jobs_list = data.get("jobs", [])
    total = data.get("total", 0)

    if not jobs_list:
        console.print("[dim]No jobs found.[/]")
        return

    table = Table(
        title=f"Recent Jobs ({total} total)",
        box=box.ROUNDED,
        title_style="bold cyan",
        header_style="bold",
    )
    table.add_column("Job ID", style="dim", max_width=12)
    table.add_column("Design", style="bold")
    table.add_column("Stage", style="cyan")
    table.add_column("Progress", justify="right")
    table.add_column("Created", style="dim")

    for j in jobs_list:
        stage = j.get("stage", "—")
        icon, label = STAGE_LABELS.get(stage, ("", stage))
        pct = float(j.get("progress", 0)) * 100
        jid = j.get("id", j.get("job_id", "—"))

        # Color by stage
        if stage == "complete":
            stage_text = f"[green]{icon} {label}[/]"
        elif stage == "failed":
            stage_text = f"[red]{icon} {label}[/]"
        else:
            stage_text = f"{icon} {label}"

        table.add_row(
            str(jid)[:12],
            j.get("design_name", "—"),
            stage_text,
            f"{pct:.0f}%",
            str(j.get("created_at", "—"))[:19],
        )

    console.print(table)


# ── Download ─────────────────────────────────────────────────────────────

@main.command()
@click.argument("job_id")
@click.option("--type", "-t", "file_type", help="Specific file: gds, def, rtl, netlist, log, report")
@click.option("--output", "-o", "output_dir", type=click.Path(), default=".", help="Output directory.")
def download(job_id: str, file_type: Optional[str], output_dir: str):
    """Download synthesis output files.

    \b
    Examples:
      autotapeout download abc-123        # download all outputs
      autotapeout download abc-123 -t gds # download GDS only
      autotapeout download abc-123 -o ./outputs/
    """
    async def _dl():
        async with _get_client() as c:
            s = await c.get_status(job_id)
            name = s.get("design_name", "design")
            out = Path(output_dir)

            if file_type:
                ext_map = {
                    "gds": ".gds", "def": ".def", "rtl": ".v",
                    "netlist": ".synthesis.v", "log": "_synthesis.log",
                    "report": "_report.json",
                }
                ext = ext_map.get(file_type, f".{file_type}")
                dest = out / f"{name}{ext}"
                await c.download(job_id, file_type, dest)
                size = dest.stat().st_size
                console.print(f"[green]{SYM_OK}[/] Downloaded {dest} ({size:,} bytes)")
            else:
                await _download_outputs(c, job_id, name, out)

    try:
        _run(_dl())
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


# ── Cancel ───────────────────────────────────────────────────────────────

@main.command()
@click.argument("job_id")
def cancel(job_id: str):
    """Cancel a running synthesis job."""
    async def _cancel():
        async with _get_client() as c:
            return await c.cancel_job(job_id)

    try:
        _run(_cancel())
        console.print(f"[bold green]{SYM_OK}[/] Job {job_id} cancelled.")
    except AutotapeoutError as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


# ── Config ───────────────────────────────────────────────────────────────

@main.command()
@click.argument("key", required=False)
@click.argument("value", required=False)
def config(key: Optional[str], value: Optional[str]):
    """Show or set CLI configuration.

    \b
    Keys:
      server      — API server URL
      output_dir  — Default download directory

    \b
    Examples:
      autotapeout config                           # show all
      autotapeout config server https://my-server
      autotapeout config output_dir ./my_outputs
    """
    if not key:
        console.print(f"  server:     [bold]{get_server()}[/]")
        console.print(f"  output_dir: [bold]{get_output_dir()}[/]")
        console.print(f"  logged_in:  {'[green]yes[/]' if get_token() else '[dim]no[/]'}")
        return

    if key == "server":
        if value:
            set_server(value)
            console.print(f"[bold green]{SYM_OK}[/] server = {value}")
        else:
            console.print(get_server())
    elif key == "output_dir":
        if value:
            set_output_dir(value)
            console.print(f"[bold green]{SYM_OK}[/] output_dir = {value}")
        else:
            console.print(str(get_output_dir()))
    else:
        console.print(f"[red]Unknown config key: {key}[/]")
        raise SystemExit(1)


# ── Notifications ────────────────────────────────────────────────────────

@main.group()
def notify():
    """Manage notification channels (Slack, Discord, Telegram, webhooks).

    \b
    Configure where GDS completion alerts are sent.

    \b
    Examples:
      autotapeout notify add slack --channel C0123456 --token xoxb-...
      autotapeout notify add discord --webhook https://discord.com/api/webhooks/...
      autotapeout notify add telegram --chat 123456 --token bot-token
      autotapeout notify add webhook --url https://myserver.com/hooks/gds
      autotapeout notify list
      autotapeout notify test <key>
      autotapeout notify remove <key>
    """


@notify.command("add")
@click.argument("channel_type", type=click.Choice(["slack", "discord", "telegram", "webhook"]))
@click.option("--channel", help="Slack channel ID (C0123456...).")
@click.option("--token", help="Bot token (Slack xoxb-... or Telegram bot token).")
@click.option("--webhook", help="Discord webhook URL.")
@click.option("--chat", help="Telegram chat ID.")
@click.option("--url", help="Webhook URL.")
@click.option("--label", help="Friendly name for this channel.")
def notify_add(channel_type: str, channel: str, token: str, webhook: str, chat: str, url: str, label: str):
    """Add a notification channel."""
    # Determine channel_id based on type
    if channel_type == "slack":
        channel_id = channel
        if not channel_id:
            console.print(f"[bold red]{SYM_FAIL}[/] --channel is required for Slack (e.g., C0123456789)")
            raise SystemExit(1)
        if not token:
            console.print(f"[bold red]{SYM_FAIL}[/] --token is required for Slack (xoxb-...)")
            raise SystemExit(1)
    elif channel_type == "discord":
        channel_id = webhook or channel
        if not channel_id:
            console.print(f"[bold red]{SYM_FAIL}[/] --webhook URL is required for Discord")
            raise SystemExit(1)
        token = token or ""
    elif channel_type == "telegram":
        channel_id = chat
        if not channel_id:
            console.print(f"[bold red]{SYM_FAIL}[/] --chat ID is required for Telegram")
            raise SystemExit(1)
        if not token:
            console.print(f"[bold red]{SYM_FAIL}[/] --token is required for Telegram (from @BotFather)")
            raise SystemExit(1)
    elif channel_type == "webhook":
        channel_id = url
        if not channel_id:
            console.print(f"[bold red]{SYM_FAIL}[/] --url is required for webhook")
            raise SystemExit(1)
        token = token or ""

    async def _add():
        async with _get_client() as c:
            return await c._post("/notifications/channels", json={
                "channel_type": channel_type,
                "channel_id": channel_id,
                "token": token,
                "label": label or f"{channel_type}",
            })

    try:
        result = _run(_add())
        key = result.get("channel_key", "?")
        console.print(f"[bold green]{SYM_OK}[/] {channel_type} notification channel registered (key: {key})")
        console.print(f"  Test it: [bold]autotapeout notify test {key}[/]")
    except Exception as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


@notify.command("list")
def notify_list():
    """List all notification channels."""
    async def _list():
        async with _get_client() as c:
            return await c._get("/notifications/channels")

    try:
        data = _run(_list())
        channels = data.get("channels", [])
        if not channels:
            console.print("[dim]No notification channels configured.[/]")
            console.print("  Add one: [bold]autotapeout notify add slack --channel C0123 --token xoxb-...[/]")
            return

        table = Table(title="Notification Channels", box=box.ROUNDED, header_style="bold")
        table.add_column("Key", style="dim")
        table.add_column("Type", style="cyan")
        table.add_column("Target")
        table.add_column("Label")
        table.add_column("Events", style="green")

        for ch in channels:
            table.add_row(
                ch.get("key", "?"),
                ch.get("type", "?"),
                ch.get("channel_id", "?"),
                ch.get("label", ""),
                ", ".join(ch.get("events", [])),
            )

        console.print(table)
    except Exception as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


@notify.command("test")
@click.argument("channel_key")
def notify_test(channel_key: str):
    """Send a test notification to a channel."""
    async def _test():
        async with _get_client() as c:
            return await c._post(f"/notifications/test/{channel_key}")

    try:
        _run(_test())
        console.print(f"[bold green]{SYM_OK}[/] Test notification sent.")
    except Exception as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


@notify.command("remove")
@click.argument("channel_key")
def notify_remove(channel_key: str):
    """Remove a notification channel."""
    async def _remove():
        async with _get_client() as c:
            return (await c._request("DELETE", f"/notifications/channels/{channel_key}")).json()

    try:
        _run(_remove())
        console.print(f"[bold green]{SYM_OK}[/] Channel removed.")
    except Exception as e:
        console.print(f"[bold red]{SYM_FAIL}[/] {e}")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
