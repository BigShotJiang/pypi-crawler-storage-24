"""Autotapeout API client — handles all server communication."""

from __future__ import annotations

import json
import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, AsyncIterator

import httpx
import websockets


class AutotapeoutError(Exception):
    """Base error for Autotapeout operations."""


class AuthenticationError(AutotapeoutError):
    """Raised when authentication fails."""


class APIError(AutotapeoutError):
    """Raised when the API returns an error."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"HTTP {status_code}: {detail}")


class Client:
    """Autotapeout API client.

    Parameters
    ----------
    server : str
        Base URL of the Autotapeout server (e.g. https://autotapeout.com).
    token : str, optional
        Authentication token. If not provided, requests are unauthenticated.
    timeout : float
        HTTP request timeout in seconds.
    """

    def __init__(self, server: str, token: Optional[str] = None, timeout: float = 30.0):
        self.server = server.rstrip("/")
        self.token = token
        self._http = httpx.AsyncClient(
            base_url=f"{self.server}/api",
            timeout=timeout,
            headers=self._headers(),
            follow_redirects=True,
        )

    def _headers(self) -> Dict[str, str]:
        h = {"User-Agent": f"autotapeout-cli/1.0.0"}
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    async def close(self):
        await self._http.aclose()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        await self.close()

    # ── helpers ──────────────────────────────────────────────────────────

    async def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        resp = await self._http.request(method, path, **kwargs)
        if resp.status_code == 401:
            raise AuthenticationError(
                "Authentication failed. Run `autotapeout login` to re-authenticate."
            )
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise APIError(resp.status_code, detail)
        return resp

    async def _get(self, path: str, **kwargs) -> Any:
        return (await self._request("GET", path, **kwargs)).json()

    async def _post(self, path: str, **kwargs) -> Any:
        return (await self._request("POST", path, **kwargs)).json()

    # ── auth ─────────────────────────────────────────────────────────────

    async def login(self, email: str, password: str) -> str:
        """Authenticate and return a session token."""
        data = await self._post("/auth/login", json={"email": email, "password": password})
        self.token = data.get("token", "")
        self._http.headers["Authorization"] = f"Bearer {self.token}"
        return self.token

    async def whoami(self) -> Dict[str, Any]:
        """Return the authenticated user's profile."""
        return await self._get("/auth/me")

    # ── health ───────────────────────────────────────────────────────────

    async def health(self) -> Dict[str, Any]:
        """Check server health."""
        return await self._get("/health")

    # ── templates ────────────────────────────────────────────────────────

    async def list_templates(self) -> list:
        """List all available IP templates."""
        return await self._get("/templates")

    async def get_template(self, name: str) -> Dict[str, Any]:
        """Get template details and RTL code."""
        return await self._get(f"/templates/{name}")

    # ── design submission ────────────────────────────────────────────────

    async def submit_prompt(
        self,
        design_name: str,
        prompt: str,
        *,
        frequency_mhz: float = 100.0,
        die_width_um: float = 1000.0,
        die_height_um: float = 1000.0,
        optimization: str = "balanced",
    ) -> Dict[str, Any]:
        """Submit a natural-language design prompt for RTL-to-GDS synthesis."""
        return await self._post(
            "/design/submit",
            json={
                "design_name": design_name,
                "prompt": prompt,
                "target_frequency_mhz": frequency_mhz,
                "die_width_um": die_width_um,
                "die_height_um": die_height_um,
                "optimization_target": optimization,
            },
        )

    async def submit_verilog(
        self,
        design_name: str,
        rtl_code: str,
        *,
        frequency_mhz: float = 100.0,
        die_width_um: float = 1000.0,
        die_height_um: float = 1000.0,
        optimization: str = "balanced",
    ) -> Dict[str, Any]:
        """Submit Verilog RTL code directly for synthesis."""
        return await self._post(
            "/design/submit",
            json={
                "design_name": design_name,
                "rtl_code": rtl_code,
                "target_frequency_mhz": frequency_mhz,
                "die_width_um": die_width_um,
                "die_height_um": die_height_um,
                "optimization_target": optimization,
            },
        )

    async def submit_file(
        self,
        design_name: str,
        file_path: Path,
        *,
        frequency_mhz: float = 100.0,
        die_width_um: float = 1000.0,
        die_height_um: float = 1000.0,
        optimization: str = "balanced",
    ) -> Dict[str, Any]:
        """Submit a Verilog file for synthesis."""
        rtl_code = file_path.read_text(encoding="utf-8")
        return await self.submit_verilog(
            design_name,
            rtl_code,
            frequency_mhz=frequency_mhz,
            die_width_um=die_width_um,
            die_height_um=die_height_um,
            optimization=optimization,
        )

    # ── job management ───────────────────────────────────────────────────

    async def get_status(self, job_id: str) -> Dict[str, Any]:
        """Get current job status."""
        return await self._get(f"/design/{job_id}/status")

    async def list_jobs(self, limit: int = 50, offset: int = 0) -> Dict[str, Any]:
        """List jobs with pagination."""
        return await self._get("/jobs", params={"limit": limit, "offset": offset})

    async def cancel_job(self, job_id: str) -> Dict[str, Any]:
        """Cancel a running job."""
        return (await self._request("DELETE", f"/design/{job_id}")).json()

    # ── downloads ────────────────────────────────────────────────────────

    async def download(self, job_id: str, file_type: str, dest: Path) -> Path:
        """Download synthesis output file.

        file_type : one of gds, def, rtl, netlist, sdc, log, report
        """
        resp = await self._request("GET", f"/design/{job_id}/download/{file_type}")
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(resp.content)
        return dest

    # ── WebSocket live updates ───────────────────────────────────────────

    async def watch(self, job_id: str) -> AsyncIterator[Dict[str, Any]]:
        """Stream real-time job status updates via WebSocket.

        Yields dicts with keys: type, job_id, stage, progress, message.
        Terminates when job reaches 'complete' or 'failed'.
        """
        ws_scheme = "wss" if self.server.startswith("https") else "ws"
        ws_url = f"{ws_scheme}://{self.server.split('://', 1)[1]}/ws/{job_id}"

        extra_headers = {}
        if self.token:
            extra_headers["Authorization"] = f"Bearer {self.token}"

        async for ws in websockets.connect(ws_url, additional_headers=extra_headers):
            try:
                async for raw in ws:
                    data = json.loads(raw)
                    yield data
                    stage = data.get("stage", "")
                    if stage in ("complete", "failed"):
                        return
            except websockets.ConnectionClosed:
                return
