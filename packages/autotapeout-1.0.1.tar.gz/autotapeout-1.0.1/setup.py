"""Autotapeout CLI — AI Silicon Compiler"""

from setuptools import setup, find_packages
from pathlib import Path

here = Path(__file__).parent
long_description = (here / "README.md").read_text(encoding="utf-8")

setup(
    name="autotapeout",
    version="1.0.1",
    description="AI Silicon Compiler — from English to GDSII in minutes",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://autotapeout.com",
    author="Autotapeout Team",
    author_email="hello@autotapeout.com",
    license="Proprietary",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Electronic Design Automation (EDA)",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    keywords="eda gds silicon compiler rtl synthesis verilog asic",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[
        "httpx>=0.24.0",
        "websockets>=11.0",
        "rich>=13.0",
        "click>=8.0",
        "keyring>=24.0",
    ],
    entry_points={
        "console_scripts": [
            "autotapeout=autotapeout.cli:main",
        ],
    },
)
