# Autotapeout CLI

**AI Silicon Compiler — from English to GDSII in minutes.**

Autotapeout compiles chip designs from natural language prompts or Verilog source into fab-ready GDSII layouts. The CLI connects to the Autotapeout cloud synthesis engine, streams live progress, and downloads output files automatically.

```
$ autotapeout compile "Design a UART controller with 16-byte TX/RX FIFOs"

  ◆ Autotapeout Compile
  Design: uart_controller
  Prompt: Design a UART controller with 16-byte TX/RX FIFOs
  Freq:   100 MHz  Opt: balanced  Tech: Sky130

  🧠 Generating RTL ████████████████████████████████████░░░░  90%  12s
  ⚙️  Synthesis      ████████████████████████████████████████ 100%  45s
  📐 Floorplan       ████████████████████████████████████████ 100%  48s
  🔀 Routing         ████████████████████████████████████████ 100%  92s
  🎉 Complete        ████████████████████████████████████████ 100% 138s

  ┃ Metric    ┃   Value ┃ Status    ┃
  ┃ Cells     ┃   1,247 ┃           ┃
  ┃ DRC       ┃       0 ┃ ✓ Clean   ┃
  ┃ LVS       ┃    Pass ┃ ✓ Match   ┃
  ┃ WNS       ┃ 2.31 ns ┃ ✓ Met     ┃

  ╭──────────────────────────────────────────────╮
  │ FAB READY — Design passes all signoff checks │
  ╰──────────────────────────────────────────────╯

  ✓ uart_controller.gds (2.4 MB)
  ✓ uart_controller.v (847 B)

  ◆ GDS ready: /home/user/uart_controller.gds
```

---

## Installation

```bash
pip install autotapeout
```

If the above doesn't work (PyPI pending), install from source:

```bash
pip install git+https://github.com/fidel-makatia/LMToolsCloudVersion.git#subdirectory=cli
```

Or with pipx:

```bash
pipx install git+https://github.com/fidel-makatia/LMToolsCloudVersion.git#subdirectory=cli
```

### Verify installation

```bash
autotapeout --version
autotapeout health
```

---

## Quick Start

### 1. Configure server (optional — defaults to autotapeout.com)

```bash
autotapeout server https://autotapeout.com
```

### 2. Authenticate

```bash
autotapeout login
# Email: your@email.com
# Password: ********
```

### 3. Compile your first chip

```bash
autotapeout compile "Design an 8-bit ALU with add, subtract, AND, OR, XOR operations"
```

The CLI will:
1. Submit your prompt to the AI synthesis engine
2. Stream live progress through all pipeline stages
3. Print signoff results (DRC, LVS, timing)
4. Download the GDSII file to your current directory

---

## Usage

### Compile from a prompt

```bash
# Simple design
autotapeout compile "Design a 4-bit counter with enable and reset"

# Complex SoC
autotapeout compile "Design a RISC-V RV32I CPU with UART, SPI, GPIO, timer, and interrupt controller"

# With options
autotapeout compile "Design a pipelined multiplier" \
  --name multiplier_v2 \
  --freq 200 \
  --opt speed \
  --output ./builds/
```

### Compile from a Verilog file

```bash
# Your own RTL
autotapeout compile --file my_design.v --name my_chip

# With custom parameters
autotapeout compile --file cpu.v --name risc_cpu --freq 150 --opt speed
```

### Use pre-built IP templates

```bash
# List available templates
autotapeout templates

# View template details
autotapeout template uart_full

# Compile a template directly
autotapeout compile --template uart_full --name my_uart

# Save template RTL to a file
autotapeout template uart_full --rtl > uart.v
```

### Pipe Verilog from stdin

```bash
# Pipe from another tool
cat design.v | autotapeout compile --name piped_design --stdin

# Chain with template command
autotapeout template register_file --rtl | autotapeout compile --name regfile --stdin
```

### Monitor jobs

```bash
# Check status of a running job
autotapeout status <job_id>

# Watch live progress
autotapeout status <job_id> --watch

# List all jobs
autotapeout jobs
autotapeout jobs --limit 50
```

### Download outputs

```bash
# Download all outputs from a completed job
autotapeout download <job_id>

# Download only the GDS file
autotapeout download <job_id> --type gds

# Download to a specific directory
autotapeout download <job_id> --output ./my_outputs/
```

### Cancel a job

```bash
autotapeout cancel <job_id>
```

---

## Output Files

After a successful compilation, the following files are downloaded:

| File | Description |
|------|-------------|
| `<name>.gds` | Fab-ready GDSII layout (open in KLayout, Magic, or Calibre) |
| `<name>.def` | Design Exchange Format — placed & routed layout |
| `<name>.v` | Verilog RTL source (generated or submitted) |
| `<name>.synthesis.v` | Post-synthesis gate-level netlist |
| `<name>_report.json` | Full synthesis metrics (cells, area, timing, DRC, LVS) |
| `<name>_synthesis.log` | Detailed synthesis log |

---

## Configuration

Configuration is stored in `~/.autotapeout/`.

```bash
# View all settings
autotapeout config

# Set server URL
autotapeout config server https://autotapeout.com

# Set default output directory
autotapeout config output_dir ~/tapeouts

# View current server
autotapeout config server
```

### Config files

| File | Purpose |
|------|---------|
| `~/.autotapeout/config.json` | Server URL, output directory |
| `~/.autotapeout/credentials.json` | Auth token (chmod 600) |

---

## Synthesis Pipeline

Every design goes through these stages:

```
Prompt → LLM Generation → Parsing → Synthesis → Floorplan →
Placement → Clock Tree → Routing → Padframe → Signoff → GDS
```

| Stage | What happens |
|-------|-------------|
| **LLM Generation** | AI generates Verilog RTL from your English prompt |
| **Parsing** | Validates Verilog syntax, fixes SystemVerilog constructs |
| **Synthesis** | Yosys converts RTL to gate-level netlist (Sky130 PDK) |
| **Floorplan** | Die area sizing and power grid planning |
| **Placement** | Standard cell placement via OpenROAD |
| **Clock Tree** | Clock tree synthesis for timing closure |
| **Routing** | Signal routing with DRC-clean metal layers |
| **Padframe** | I/O pad ring generation and pin routing |
| **Signoff** | DRC, LVS, and static timing analysis |
| **GDS** | Final GDSII layout export via Magic |

---

## Technology

- **PDK:** SkyWater 130nm (Sky130A)
- **Synthesis:** Yosys
- **Place & Route:** OpenROAD
- **GDS Export:** Magic VLSI
- **Signoff:** DRC (Magic), LVS (Netgen), STA (OpenROAD)

---

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `AUTOTAPEOUT_SERVER` | Server URL | `https://autotapeout.com` |
| `AUTOTAPEOUT_TOKEN` | Auth token (alternative to `login`) | — |

```bash
# Use environment variables instead of config files
export AUTOTAPEOUT_SERVER=https://autotapeout.com
export AUTOTAPEOUT_TOKEN=your-token-here
autotapeout compile "Design a counter"
```

---

## Requirements

- Python 3.9+
- Internet connection to reach the Autotapeout server

---

## Support

- Documentation: [https://docs.autotapeout.com](https://docs.autotapeout.com)
- Web UI: [https://autotapeout.com](https://autotapeout.com)
- Support: hello@autotapeout.com

---

© 2026 Autotapeout Inc. All rights reserved.
