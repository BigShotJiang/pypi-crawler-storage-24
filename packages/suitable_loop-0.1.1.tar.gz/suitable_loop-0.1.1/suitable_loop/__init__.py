"""Suitable Loop — Local Production Engineering Platform."""

__version__ = "0.1.1"
