"""A composed source element that generates fake GW noise with injections.

This module provides the InjectedNoiseSource class, a composed source element
that combines GWDataNoiseSource (fake detector noise) with SimInspiralSource
(gravitational wave injections) using an Adder to produce realistic test data.

Example:
    >>> source = InjectedNoiseSource(
    ...     name="test_data",
    ...     ifos=["H1", "L1"],
    ...     channel_dict={"H1": "STRAIN", "L1": "STRAIN"},
    ...     start=1126259460,
    ...     duration=64.0,
    ...     test_mode="bbh",
    ... )
    >>> # Use in pipeline
    >>> pipeline = Pipeline()
    >>> pipeline.connect(source.element, sink)
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Any, ClassVar, Dict, Optional, Set

from sgnts.compose import TSCompose, TSComposedSourceElement
from sgnts.transforms import Adder

from sgnligo.base import now
from sgnligo.sources.composed_base import ComposedSourceBase
from sgnligo.sources.datasource_v2.cli_mixins import (
    ChannelOptionsMixin,
    GPSOptionsFlexibleMixin,
    InjectionFileMixin,
    VerboseOptionsMixin,
)
from sgnligo.sources.datasource_v2.composed_registry import register_composed_source
from sgnligo.sources.gwdata_noise_source import GWDataNoiseSource
from sgnligo.sources.sim_inspiral_source import SimInspiralSource

# GWDataNoiseSource sample rate is fixed by the PSD (16384 Hz)
SAMPLE_RATE = 16384


@register_composed_source
@dataclass(kw_only=True)
class InjectedNoiseSource(
    ComposedSourceBase,
    ChannelOptionsMixin,
    GPSOptionsFlexibleMixin,
    InjectionFileMixin,
    VerboseOptionsMixin,
):
    """Composed source generating fake GW noise with injections.

    Combines GWDataNoiseSource (colored detector noise) with SimInspiralSource
    (gravitational wave signals) to produce realistic test data.

    Supports both offline (batch) and real-time modes via the `real_time` flag:
    - Offline (default): Requires start and end (or duration)
    - Real-time: GPS times optional, generates data synchronized with wall clock

    Fields inherited from mixins:
        ifos: List of detector prefixes (from ChannelOptionsMixin)
        channel_dict: Dict mapping IFO to channel name (from ChannelOptionsMixin)
        start: GPS start time (from GPSOptionsFlexibleMixin)
        end: GPS end time (from GPSOptionsFlexibleMixin)
        duration: Duration in seconds, alternative to end (from GPSOptionsFlexibleMixin)
        real_time: Enable real-time mode (from GPSOptionsFlexibleMixin)
        injection_file: Path to injection file (from InjectionFileMixin)
        test_mode: Test mode for injections (from InjectionFileMixin)
        verbose: Enable verbose output (from VerboseOptionsMixin)

    Additional fields:
        f_min: Minimum frequency for waveform generation in Hz
        approximant_override: Override waveform approximant for all injections

    Example:
        >>> # With test mode (automatic BBH injections every 30s)
        >>> source = InjectedNoiseSource(
        ...     name="test_data",
        ...     ifos=["H1", "L1"],
        ...     channel_dict={"H1": "STRAIN", "L1": "STRAIN"},
        ...     start=1126259460,
        ...     duration=64.0,
        ...     test_mode="bbh",
        ... )

        >>> # With injection file
        >>> source = InjectedNoiseSource(
        ...     name="injected_data",
        ...     ifos=["H1", "L1"],
        ...     channel_dict={"H1": "STRAIN", "L1": "STRAIN"},
        ...     start=1126259460,
        ...     duration=3600.0,
        ...     injection_file="my_injections.xml",
        ...     f_min=15.0,
        ... )

        >>> # Real-time mode
        >>> source = InjectedNoiseSource(
        ...     name="realtime_data",
        ...     ifos=["H1"],
        ...     channel_dict={"H1": "STRAIN"},
        ...     real_time=True,
        ...     test_mode="bns",
        ...     verbose=True,
        ... )

        >>> # Use in pipeline
        >>> from sgn.apps import Pipeline
        >>> from sgn.sinks import CollectSink
        >>> pipeline = Pipeline()
        >>> sink = CollectSink(name="sink", sink_pad_names=["H1:STRAIN"])
        >>> pipeline.connect(source.element, sink)
        >>> pipeline.run()
    """

    # Additional fields not covered by mixins
    f_min: float = 20.0
    approximant_override: Optional[str] = None

    # Class metadata
    source_type: ClassVar[str] = "injected-noise"
    description: ClassVar[str] = "Colored noise with GW injections"

    # =========================================================================
    # CLI support for fields not covered by mixins
    # =========================================================================

    @classmethod
    def add_cli_arguments(cls, parser: argparse.ArgumentParser) -> None:
        """Add CLI arguments for InjectedNoiseSource-specific fields."""
        group = parser.add_argument_group("Injected Noise Options")
        group.add_argument(
            "--f-min",
            type=float,
            default=20.0,
            metavar="HZ",
            help="Minimum frequency for waveform generation (default: 20.0)",
        )
        group.add_argument(
            "--approximant-override",
            metavar="APPROX",
            help="Override waveform approximant for all injections",
        )

    @classmethod
    def get_cli_arg_names(cls) -> Set[str]:
        """Return CLI argument names for InjectedNoiseSource-specific fields."""
        return {"f_min", "approximant_override"}

    @classmethod
    def process_cli_args(cls, args: argparse.Namespace) -> Dict[str, Any]:
        """Convert CLI args to field values for InjectedNoiseSource-specific fields."""
        result: Dict[str, Any] = {}

        f_min = getattr(args, "f_min", None)
        if f_min is not None:
            result["f_min"] = f_min

        approximant_override = getattr(args, "approximant_override", None)
        if approximant_override is not None:
            result["approximant_override"] = approximant_override

        return result

    def _validate(self) -> None:
        """Validate injection source and time specification."""
        # Validate GPS options based on real_time mode
        self._validate_gps_options()

        # Validate channel_dict keys match ifos
        if set(self.channel_dict.keys()) != set(self.ifos):
            raise ValueError("channel_dict keys must match ifos")

        # Validate injection source specification
        if self.injection_file is None and self.test_mode is None:
            raise ValueError("Must specify either injection_file or test_mode")
        if self.injection_file is not None and self.test_mode is not None:
            raise ValueError("Cannot specify both injection_file and test_mode")

    def _build(self) -> TSComposedSourceElement:
        """Build the composed source element."""
        # Compute actual start (use current GPS time if not specified)
        actual_start = self.start if self.start is not None else int(now())

        # Compute end time from duration using actual_start (self.start may be None)
        if self.end is not None:
            end_time = self.end
        elif self.duration is not None:
            end_time = actual_start + self.duration
        else:
            end_time = None

        # Build channel dictionaries for internal elements
        # Noise source uses {ifo}:FAKE-STRAIN internally
        noise_channel_dict = {ifo: f"{ifo}:FAKE-STRAIN" for ifo in self.ifos}

        # Output channel names from channel_dict (e.g., H1:STRAIN)
        output_channels = {ifo: f"{ifo}:{self.channel_dict[ifo]}" for ifo in self.ifos}

        # Create the noise source
        noise_source = GWDataNoiseSource(
            name=f"{self.name}_noise",
            channel_dict=noise_channel_dict,
            start=actual_start,
            end=end_time,
            real_time=self.real_time,
            verbose=self.verbose,
        )

        # Create the injection source
        inj_source = SimInspiralSource(
            name=f"{self.name}_injections",
            ifos=self.ifos,
            start=actual_start,
            end=end_time,
            injection_file=self.injection_file,
            test_mode=self.test_mode,
            sample_rate=SAMPLE_RATE,
            f_min=self.f_min,
            approximant_override=self.approximant_override,
        )

        # Create one Adder per IFO to keep detector outputs separate
        adders = []
        for ifo in self.ifos:
            noise_pad = f"{ifo}:FAKE-STRAIN"
            inj_pad = f"{ifo}:INJ-STRAIN"
            out_channel = output_channels[ifo]

            adder = Adder(
                name=f"{self.name}_adder_{ifo}",
                sink_pad_names=(noise_pad, inj_pad),
                source_pad_names=(out_channel,),
            )
            adders.append(adder)

        # Build the composed element using TSCompose
        compose = TSCompose()

        # Connect noise source and injection source to each adder
        # Implicit linking works because pad names match (e.g., H1:FAKE-STRAIN)
        for adder in adders:
            compose.connect(noise_source, adder)
            compose.connect(inj_source, adder)

        return compose.as_source(name=self.name)
