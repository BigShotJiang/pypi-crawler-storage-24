"""A source element to emit injection metadata synchronized to pipeline time.

This module provides the InjectionFileSource class which reads injection parameters
from XML (LIGOLW) files or generates them dynamically in test mode, and emits
injection row metadata as EventFrames when the injection time arrives in pipeline time.

The EventFrame output allows synchronization with TSFrame-producing elements
in TSTransform pipelines.
"""

from __future__ import annotations

import logging
import math
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

import lal
from sgn.base import SourcePad
from sgn.sources import SignalEOS
from sgnts.base import EventBuffer, EventFrame, Offset, TSSource
from sgnts.utils import gpsnow

# Import from unified injection_params module
from sgnligo.sources.injection_params import (
    TEST_INJECTION_INTERVAL,
    TEST_MODE_PARAMS,
    InjectionParams,
    create_test_injection,
    load_injections_from_ligolw_xml,
)

logger = logging.getLogger("sgn")


@dataclass
class InjectionFileSource(TSSource, SignalEOS):
    """Source element that emits injection metadata as EventFrames.

    Reads injection parameters from XML (LIGOLW SimInspiralTable) files or
    generates them dynamically in test mode, and emits EventFrames containing
    injection data when the injection's geocent_end_time falls within the
    current time window.

    The EventFrame output is compatible with TSTransform synchronization,
    allowing injections to be aligned with strain data in downstream transforms.

    Supports multiple modes:
    - File mode: Load injections from XML file
    - Test mode: Generate periodic test injections (BNS, NSBH, or BBH) every
      30 seconds, synchronized with SimInspiralSource test mode
    - Offline mode (real_time=False): Advances through pipeline time as fast as
      the pipeline runs. Suitable for offline analysis and testing.
    - Real-time mode (real_time=True): Paces emission to match wall clock time.
      Blocks if pipeline is ahead of real time. Suitable for live analysis.

    Args:
        injection_file: Path to injection file (XML or gzipped XML). Mutually
            exclusive with test_mode.
        test_mode: Generate test injections instead of loading from file.
            Valid values: "bns" (100 Mpc), "nsbh" (200 Mpc), "bbh" (500 Mpc).
            Mutually exclusive with injection_file.
        time_offset: Offset to add to injection times (default: 0.0). Use this
            to shift injection times when replaying historical data. Only
            applicable when using injection_file.
        real_time: If True, pace emission to match wall clock time (default: False)
        output_format: Format for emitted injection dicts. Options:
            - "ligolw": LIGOLW naming with astrophysical units (default)
            - "lal": LAL naming with SI units

    Output:
        EventFrame containing EventBuffer with injection dicts. Gap frames
        (empty EventFrame) are emitted when no injection is in the window.

    Example:
        >>> # File mode (offline)
        >>> source = InjectionFileSource(
        ...     name="Injections",
        ...     injection_file="injections.xml",
        ...     start=1234567890,
        ...     end=1234567900,
        ... )
        >>>
        >>> # Test mode (synchronized with SimInspiralSource)
        >>> source = InjectionFileSource(
        ...     name="Injections",
        ...     test_mode="bbh",
        ...     start=1234567890,
        ...     end=1234567900,
        ... )
        >>>
        >>> # Real-time mode with file
        >>> source = InjectionFileSource(
        ...     name="Injections",
        ...     injection_file="injections.xml",
        ...     real_time=True,
        ... )
    """

    injection_file: Optional[str] = None
    test_mode: Optional[str] = None
    time_offset: float = 0.0
    real_time: bool = False
    output_format: str = "ligolw"  # "ligolw" or "lal"

    # Internal state
    _injections: List[InjectionParams] = field(
        init=False, repr=False, default_factory=list
    )
    _next_injection_idx: int = field(init=False, repr=False, default=0)
    _current_offset: int = field(init=False, repr=False, default=0)

    # Real-time mode state
    _gps_start: float = field(init=False, repr=False, default=0.0)
    _wall_start: float = field(init=False, repr=False, default=0.0)

    # Test mode state
    _generated_test_times: Set[float] = field(
        init=False, repr=False, default_factory=set
    )

    def __post_init__(self):
        """Initialize the source."""
        # Validate mutual exclusivity of injection_file and test_mode
        if self.injection_file and self.test_mode:
            raise ValueError("Cannot specify both injection_file and test_mode")
        if not self.injection_file and not self.test_mode:
            raise ValueError("Must specify either injection_file or test_mode")

        # Validate test_mode value
        if self.test_mode:
            test_mode_lower = self.test_mode.lower()
            if test_mode_lower not in TEST_MODE_PARAMS:
                raise ValueError(
                    f"Invalid test_mode '{self.test_mode}'. "
                    f"Must be one of: {list(TEST_MODE_PARAMS.keys())}"
                )
            # Normalize to lowercase
            self.test_mode = test_mode_lower

        # Validate output_format
        if self.output_format not in ("ligolw", "lal"):
            raise ValueError(
                f"output_format must be 'ligolw' or 'lal', got '{self.output_format}'"
            )

        # Set source pad name
        self.source_pad_names = ["injections"]

        # Load injections from file or start empty for test mode
        if self.injection_file:
            self._injections = load_injections_from_ligolw_xml(self.injection_file)
            logger.info(
                "InjectionFileSource: Loaded %d injections from %s",
                len(self._injections),
                self.injection_file,
            )

            # Apply time offset to all injection times (only for file mode)
            if self.time_offset != 0.0:
                adjusted_injections = []
                for inj in self._injections:
                    # Get current params and adjust time
                    params = inj.to_lal()
                    old_time = params["t_co_gps"]
                    new_time = old_time + self.time_offset
                    params["t_co_gps"] = new_time

                    # Shift RA to account for Earth rotation
                    gmsstart = lal.GreenwichMeanSiderealTime(lal.LIGOTimeGPS(old_time))
                    gmst1 = lal.GreenwichMeanSiderealTime(lal.LIGOTimeGPS(new_time))
                    dgmst = gmst1 - gmsstart
                    params["ra"] = params["ra"] + dgmst

                    adjusted_injections.append(InjectionParams.from_lal(params))

                self._injections = adjusted_injections

            # Sort by coalescence time
            self._injections.sort(key=lambda x: x.t_co_gps)
        else:
            # Test mode: injections will be generated dynamically
            self._injections = []
            logger.info(
                "InjectionFileSource: Test mode '%s', injections every %.0f seconds",
                self.test_mode,
                TEST_INJECTION_INTERVAL,
            )

        # Initialize real-time mode state
        if self.real_time:
            self._gps_start = float(gpsnow())
            self._wall_start = time.time()
            logger.info(
                "InjectionFileSource: Real-time mode, starting at GPS %.3f",
                self._gps_start,
            )

        # Call parent's post_init (handles start/end and offset tracking)
        super().__post_init__()

        # Initialize current offset from start_offset (set by TSSource)
        self._current_offset = self.start_offset

        # Skip injections before start time (only for file mode)
        if self.injection_file:
            start_time = float(self.start) if self.start else 0.0
            while (
                self._next_injection_idx < len(self._injections)
                and self._injections[self._next_injection_idx].t_co_gps < start_time
            ):
                skipped = self._injections[self._next_injection_idx]
                logger.debug(
                    "InjectionFileSource: Skipping old injection at %.3f",
                    skipped.t_co_gps,
                )
                self._next_injection_idx += 1

    def _current_gps(self) -> float:
        """Get current GPS time based on wall clock (real-time mode only)."""
        return self._gps_start + (time.time() - self._wall_start)

    def _ensure_test_injections_for_range(
        self, start_gps: float, end_gps: float
    ) -> None:
        """Generate test injections for the given time range.

        For test mode, this method dynamically creates injections at every
        TEST_INJECTION_INTERVAL seconds (aligned to absolute GPS boundaries).
        This ensures synchronization with SimInspiralSource test mode.

        Args:
            start_gps: Start of the time range (GPS seconds)
            end_gps: End of the time range (GPS seconds)
        """
        if not self.test_mode:
            return

        # Find the first 30-second boundary at or after start_gps
        first_t_co = (
            math.ceil(start_gps / TEST_INJECTION_INTERVAL) * TEST_INJECTION_INTERVAL
        )

        t_co = first_t_co
        while t_co < end_gps:
            if t_co not in self._generated_test_times:
                self._generated_test_times.add(t_co)
                # Generate the injection using shared factory
                inj = create_test_injection(self.test_mode, t_co)
                # Add to injections list (maintain sorted order by appending)
                self._injections.append(inj)
                logger.debug(
                    "InjectionFileSource: Generated test injection at %.3f", t_co
                )
            t_co += TEST_INJECTION_INTERVAL

    def _injection_to_output_dict(self, inj: InjectionParams) -> Dict[str, Any]:
        """Convert InjectionParams to output dict in configured format."""
        if self.output_format == "ligolw":
            result = inj.to_ligolw()
            # Add convenience float time field
            result["geocent_end_time_float"] = inj.t_co_gps
            return result
        else:
            return inj.to_lal()

    def new(self, pad: SourcePad) -> EventFrame:
        """Emit EventFrame with injections in the current time window.

        This method is called by the pipeline to get new data. It checks if any
        injections are due within the current time window and emits them as
        EventBuffers within an EventFrame.

        In real-time mode, this method will block if the pipeline is ahead of
        wall clock time, ensuring injections are emitted at the correct time.

        Args:
            pad: Source pad requesting new data

        Returns:
            EventFrame containing injection metadata or empty (gap) EventFrame
        """
        # Check for signal-based EOS
        if self.signaled_eos():
            return EventFrame(offset=0, noffset=0, EOS=True)

        # Get current window from offset tracking
        window_offset: int = self._current_offset
        window_noffset = Offset.SAMPLE_STRIDE_AT_MAX_RATE  # Standard stride

        window_start_sec = Offset.tosec(window_offset)
        window_end_sec = Offset.tosec(window_offset + window_noffset)

        # In real-time mode, wait if we're ahead of wall clock
        if self.real_time:
            current_gps = self._current_gps()
            if window_start_sec > current_gps:
                wait_time = window_start_sec - current_gps
                if wait_time > 0:
                    logger.debug(
                        "InjectionFileSource: Waiting %.3f seconds for real-time",
                        wait_time,
                    )
                    time.sleep(wait_time)

        # Check for EOS based on end time
        end_time = float(self.end) if self.end else float("inf")
        if window_start_sec >= end_time:
            return EventFrame(offset=window_offset, noffset=window_noffset, EOS=True)

        # For test mode, ensure we have injections for this time range
        if self.test_mode:
            self._ensure_test_injections_for_range(window_start_sec, window_end_sec)

        # Collect all injections within this time window
        ready_injections = []
        while self._next_injection_idx < len(self._injections):
            inj = self._injections[self._next_injection_idx]
            inj_time = inj.t_co_gps

            if inj_time < window_end_sec:
                ready_injections.append(self._injection_to_output_dict(inj))
                self._next_injection_idx += 1
                logger.debug(
                    "InjectionFileSource: Emitting injection at %.3f "
                    "(window %.3f - %.3f)",
                    inj_time,
                    window_start_sec,
                    window_end_sec,
                )
            else:
                break

        # Advance offset for next call
        self._current_offset = window_offset + window_noffset

        if ready_injections:
            # Create EventBuffer containing the injection dicts
            event_buffer = EventBuffer(
                offset=window_offset,
                noffset=window_noffset,
                data=ready_injections,
            )
            return EventFrame(
                data=[event_buffer],
                EOS=False,
            )
        else:
            # Return gap EventFrame (no injections in this window)
            return EventFrame(
                offset=window_offset,
                noffset=window_noffset,
                EOS=False,
            )

    @property
    def remaining_injections(self) -> int:
        """Number of injections not yet emitted."""
        return len(self._injections) - self._next_injection_idx

    def get_injection_times(self) -> List[float]:
        """Get list of all injection times (after time offset).

        Useful for coordinating with other sources like MockGWEventSource.

        Returns:
            List of geocentric end times in GPS seconds
        """
        return [inj.t_co_gps for inj in self._injections]
