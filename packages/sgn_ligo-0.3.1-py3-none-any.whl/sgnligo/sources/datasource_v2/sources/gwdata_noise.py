"""GWData noise composed source class.

Generates colored Gaussian noise with realistic LIGO PSDs,
suitable for testing and development without real detector data.

Supports both offline (batch) and real-time modes via the `real_time` flag:
- Offline (default): Requires start and end (or duration)
- Real-time: GPS times optional, generates data synchronized with wall clock

Example:
    >>> # Offline mode
    >>> source = GWDataNoiseComposedSource(
    ...     name="noise",
    ...     ifos=["H1", "L1"],
    ...     channel_dict={"H1": "FAKE-STRAIN", "L1": "FAKE-STRAIN"},
    ...     start=1000,
    ...     end=1010,
    ... )
    >>>
    >>> # Real-time mode
    >>> source = GWDataNoiseComposedSource(
    ...     name="noise",
    ...     ifos=["H1"],
    ...     channel_dict={"H1": "FAKE-STRAIN"},
    ...     real_time=True,
    ... )
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import ClassVar, Optional, Tuple

import numpy as np
from sgnts.compose import TSCompose, TSComposedSourceElement
from sgnts.sources import SegmentSource

from sgnligo.base import read_segments_and_values_from_file
from sgnligo.sources.composed_base import ComposedSourceBase
from sgnligo.sources.datasource_v2.cli_mixins import (
    ChannelOptionsMixin,
    GPSOptionsFlexibleMixin,
    StateVectorOnDictOnlyMixin,
    VerboseOptionsMixin,
)
from sgnligo.sources.datasource_v2.composed_registry import register_composed_source
from sgnligo.sources.datasource_v2.sources.utils import add_state_vector_gating
from sgnligo.sources.gwdata_noise_source import GWDataNoiseSource


@register_composed_source
@dataclass(kw_only=True)
class GWDataNoiseComposedSource(
    ComposedSourceBase,
    ChannelOptionsMixin,
    GPSOptionsFlexibleMixin,
    StateVectorOnDictOnlyMixin,
    VerboseOptionsMixin,
):
    """Colored Gaussian noise source with optional state vector gating.

    Generates colored Gaussian noise with LIGO PSD. Supports both offline
    and real-time modes, with optional segment-based state vector gating.

    Fields inherited from mixins:
        ifos: List of detector prefixes (from ChannelOptionsMixin)
        channel_dict: Dict mapping IFO to channel name (from ChannelOptionsMixin)
        start: GPS start time (from GPSOptionsFlexibleMixin)
        end: GPS end time (from GPSOptionsFlexibleMixin)
        duration: Duration in seconds, alternative to end (from GPSOptionsFlexibleMixin)
        real_time: Enable real-time mode (from GPSOptionsFlexibleMixin)
        state_vector_on_dict: Bitmask dict (from StateVectorOnDictOnlyMixin)
        state_segments_file: State segments file (from StateVectorOnDictOnlyMixin)
        state_sample_rate: State vector sample rate (from StateVectorOnDictOnlyMixin)
        verbose: Enable verbose output (from VerboseOptionsMixin)

    Example:
        >>> # Offline mode
        >>> source = GWDataNoiseComposedSource(
        ...     name="noise",
        ...     ifos=["H1", "L1"],
        ...     channel_dict={"H1": "FAKE-STRAIN", "L1": "FAKE-STRAIN"},
        ...     start=1000,
        ...     end=1010,
        ... )
        >>>
        >>> # Real-time mode
        >>> source = GWDataNoiseComposedSource(
        ...     name="noise",
        ...     ifos=["H1"],
        ...     channel_dict={"H1": "FAKE-STRAIN"},
        ...     real_time=True,
        ... )
    """

    # Class metadata
    source_type: ClassVar[str] = "gwdata-noise"
    description: ClassVar[str] = "Colored Gaussian noise with LIGO PSD"

    def _validate(self) -> None:
        """Validate parameters."""
        # Validate GPS options based on real_time mode
        self._validate_gps_options()

        # Validate channel_dict keys match ifos
        if set(self.channel_dict.keys()) != set(self.ifos):
            raise ValueError("channel_dict keys must match ifos")

        # Validate state segments file
        if self.state_segments_file is not None:
            if not os.path.exists(self.state_segments_file):
                raise ValueError(
                    f"State segments file does not exist: {self.state_segments_file}"
                )

        # Validate state_vector_on_dict
        if self.state_vector_on_dict is not None:
            if set(self.state_vector_on_dict.keys()) != set(self.ifos):
                raise ValueError("state_vector_on_dict keys must match ifos")

    def _load_state_segments(
        self,
        end_time: Optional[float],
    ) -> Tuple[Optional[Tuple[Tuple[int, int], ...]], Optional[Tuple[int, ...]]]:
        """Load state segments from file or create defaults.

        Returns:
            Tuple of (segments, values) where segments is a tuple of (start_ns, end_ns)
            pairs and values is a tuple of state vector values. Returns (None, None)
            if state vector gating is not configured.
        """
        if self.state_vector_on_dict is None:
            return None, None

        if self.state_segments_file is not None:
            state_segments, state_values = read_segments_and_values_from_file(
                self.state_segments_file, self.verbose
            )
        else:
            # Default: single segment covering entire time range with value 3
            if self.start is not None:
                start_ns = int(self.start * 1e9)
                if end_time is not None:
                    end_ns = int(end_time * 1e9)
                else:
                    # For real-time mode without end time
                    end_ns = int(np.iinfo(np.int32).max * 1e9)
                state_segments = ((start_ns, end_ns),)
                state_values = (3,)  # Default: bits 0 and 1 set
                if self.verbose:
                    print("Using default state segments: single segment with value 3")
            else:
                raise ValueError(
                    "Must provide either state_segments_file or start "
                    "when using state vector gating"
                )

        return state_segments, state_values

    def _build(self) -> TSComposedSourceElement:
        """Build the GWData noise source."""
        # Get computed end time (may be calculated from duration)
        end_time = self._get_computed_end()

        # Build full channel names for internal use
        full_channel_dict = {
            ifo: f"{ifo}:{self.channel_dict[ifo]}" for ifo in self.ifos
        }

        # Create the noise source
        noise_source = GWDataNoiseSource(
            name=f"{self.name}_noise",
            channel_dict=full_channel_dict,
            start=self.start,
            end=end_time,
            real_time=self.real_time,
            verbose=self.verbose,
        )

        compose = TSCompose()

        # Check if we need state vector gating
        if self.state_vector_on_dict is not None:
            state_segments, state_values = self._load_state_segments(end_time)
            assert state_segments is not None
            assert state_values is not None

            # Determine end time for SegmentSource (doesn't support None)
            seg_end = (
                end_time if end_time is not None else float(np.iinfo(np.int32).max)
            )

            for ifo in self.ifos:
                full_channel = full_channel_dict[ifo]

                # Create segment source for state vector
                state_source = SegmentSource(
                    name=f"{self.name}_{ifo}_state",
                    source_pad_names=("state",),
                    rate=self.state_sample_rate,
                    start=self.start,
                    end=seg_end,
                    segments=state_segments,
                    values=state_values,
                )

                gate = add_state_vector_gating(
                    compose=compose,
                    strain_source=noise_source,
                    state_source=state_source,
                    ifo=ifo,
                    bit_mask=self.state_vector_on_dict[ifo],
                    strain_pad=full_channel,
                    state_pad="state",
                    output_pad=full_channel,
                )

                # Add latency tracking if configured
                self._add_latency_tracking(compose, ifo, gate, full_channel)

                if self.verbose:
                    print(
                        f"Added state vector gating for {ifo} with mask "
                        f"{self.state_vector_on_dict[ifo]}"
                    )
        else:
            # No gating - just expose noise source directly
            compose.insert(noise_source)

            # Add latency tracking for each IFO
            for ifo in self.ifos:
                full_channel = full_channel_dict[ifo]
                self._add_latency_tracking(compose, ifo, noise_source, full_channel)

        return compose.as_source(
            name=self.name,
            also_expose_source_pads=self._also_expose_pads,
        )
