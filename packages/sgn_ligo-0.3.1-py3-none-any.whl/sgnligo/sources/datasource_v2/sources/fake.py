"""Fake signal source classes (white, sin, impulse).

These sources generate synthetic test signals for pipeline development
and testing without requiring real detector data.

Supports both offline (batch) and real-time modes via the `real_time` flag:
- Offline (default): Requires start and end (or duration)
- Real-time: GPS times optional, generates data synchronized with wall clock

Example:
    >>> # Offline mode (default)
    >>> source = WhiteComposedSource(
    ...     name="noise",
    ...     ifos=["H1", "L1"],
    ...     channel_dict={"H1": "FAKE-STRAIN", "L1": "FAKE-STRAIN"},
    ...     sample_rate=4096,
    ...     start=1000,
    ...     end=1010,
    ... )
    >>>
    >>> # Real-time mode
    >>> source = WhiteComposedSource(
    ...     name="noise",
    ...     ifos=["H1"],
    ...     channel_dict={"H1": "FAKE-STRAIN"},
    ...     sample_rate=4096,
    ...     real_time=True,
    ... )
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import ClassVar, Dict, List, Optional

import igwn_segments as segments
from igwn_ligolw import utils as ligolw_utils
from igwn_ligolw.utils import segments as ligolw_segments
from lal import LIGOTimeGPS
from sgnts.base import TSSource, TSTransform
from sgnts.compose import TSCompose, TSComposedSourceElement
from sgnts.sources import FakeSeriesSource, SegmentSource
from sgnts.transforms import Gate

from sgnligo.sources.composed_base import ComposedSourceBase
from sgnligo.sources.datasource_v2.cli_mixins import (
    ChannelOptionsMixin,
    GPSOptionsFlexibleMixin,
    ImpulsePositionOptionsMixin,
    SampleRateOptionsMixin,
    SegmentsOptionsMixin,
    VerboseOptionsMixin,
)
from sgnligo.sources.datasource_v2.composed_registry import register_composed_source


@dataclass(kw_only=True)
class FakeSourceBase(
    ComposedSourceBase,
    ChannelOptionsMixin,
    SampleRateOptionsMixin,
    GPSOptionsFlexibleMixin,
    SegmentsOptionsMixin,
    VerboseOptionsMixin,
):
    """Base class for fake signal sources.

    Generates synthetic signals for pipeline testing. Supports both offline
    and real-time modes, with optional segment-based gating for offline mode.

    Fields inherited from mixins:
        ifos: List of detector prefixes (from ChannelOptionsMixin)
        channel_dict: Dict mapping IFO to channel name (from ChannelOptionsMixin)
        sample_rate: Sample rate in Hz (from SampleRateOptionsMixin)
        start: GPS start time (from GPSOptionsFlexibleMixin)
        end: GPS end time (from GPSOptionsFlexibleMixin)
        duration: Duration in seconds, alternative to end (from GPSOptionsFlexibleMixin)
        real_time: Enable real-time mode (from GPSOptionsFlexibleMixin)
        segments_file: Path to LIGO XML segments file (from SegmentsOptionsMixin)
        segments_name: Name of segments to extract (from SegmentsOptionsMixin)
        verbose: Enable verbose output (from VerboseOptionsMixin)

    Example:
        >>> # Offline mode
        >>> source = WhiteComposedSource(
        ...     name="noise",
        ...     ifos=["H1"],
        ...     channel_dict={"H1": "FAKE-STRAIN"},
        ...     sample_rate=4096,
        ...     start=1000,
        ...     end=1010,
        ... )
        >>>
        >>> # Real-time mode
        >>> source = WhiteComposedSource(
        ...     name="noise",
        ...     ifos=["H1"],
        ...     channel_dict={"H1": "FAKE-STRAIN"},
        ...     sample_rate=4096,
        ...     real_time=True,
        ... )
    """

    # Subclasses override this
    signal_type: ClassVar[str] = "white"

    def _validate(self) -> None:
        """Validate parameters."""
        # Validate GPS options based on real_time mode
        self._validate_gps_options()

        if self.sample_rate <= 0:
            raise ValueError("sample_rate must be positive")

        # Validate channel_dict keys match ifos
        if set(self.channel_dict.keys()) != set(self.ifos):
            raise ValueError("channel_dict keys must match ifos")

        # Validate segments options (only applicable in offline mode)
        if self.segments_file is not None:
            if self.real_time:
                raise ValueError("Segment gating not supported in real-time mode")
            if self.segments_name is None:
                raise ValueError("Must specify segments_name when segments_file is set")
            if not os.path.exists(self.segments_file):
                raise ValueError(f"Segments file does not exist: {self.segments_file}")

    def _load_segments(self) -> Optional[Dict[str, List]]:
        """Load and process segments from XML file."""
        if self.segments_file is None or self.segments_name is None:
            return None

        # Get computed end time
        end_time = self._get_computed_end()

        loaded_segments = ligolw_segments.segmenttable_get_by_name(
            ligolw_utils.load_filename(
                self.segments_file,
                contenthandler=ligolw_segments.LIGOLWContentHandler,
            ),
            self.segments_name,
        ).coalesce()

        # Clip to requested time range
        seg = segments.segment(LIGOTimeGPS(self.start), LIGOTimeGPS(end_time))
        clipped_segments = segments.segmentlistdict(
            (ifo, seglist & segments.segmentlist([seg]))
            for ifo, seglist in loaded_segments.items()
        )

        # Convert to nanoseconds
        segments_dict = {}
        for ifo, segs in clipped_segments.items():
            segments_dict[ifo] = [segments.segment(s[0].ns(), s[1].ns()) for s in segs]
        return segments_dict

    def _build(self) -> TSComposedSourceElement:
        """Build the fake signal source."""
        compose = TSCompose()

        # Get computed end time (may be calculated from duration)
        end_time = self._get_computed_end()

        # Load segments only in offline mode
        segments_dict = None if self.real_time else self._load_segments()

        for ifo in self.ifos:
            # Full channel name for output pad
            channel_name = f"{ifo}:{self.channel_dict[ifo]}"

            source = FakeSeriesSource(
                name=f"{self.name}_{ifo}",
                source_pad_names=(channel_name,),
                rate=self.sample_rate,
                signal_type=self.signal_type,
                impulse_position=getattr(self, "impulse_position", -1),
                real_time=self.real_time,
                start=self.start,
                end=end_time,
            )

            # Track the final output element and pad for latency tracking
            final_source: TSSource | TSTransform = source
            final_pad = channel_name

            # Add segment gating if configured (offline mode only)
            if segments_dict is not None and ifo in segments_dict:
                ifo_segments = segments_dict[ifo]

                if ifo_segments:
                    seg_source = SegmentSource(
                        name=f"{self.name}_{ifo}_seg",
                        source_pad_names=("control",),
                        rate=self.sample_rate,
                        start=self.start,
                        end=end_time,
                        segments=ifo_segments,  # type: ignore[arg-type]
                    )

                    gate = Gate(
                        name=f"{self.name}_{ifo}_gate",
                        sink_pad_names=("strain", "control"),
                        control="control",
                        source_pad_names=(channel_name,),
                    )

                    compose.connect(source, gate, link_map={"strain": channel_name})
                    compose.connect(seg_source, gate, link_map={"control": "control"})

                    final_source = gate
                    final_pad = channel_name

                    if self.verbose:
                        print(f"Added segment gating for {ifo}")
                else:
                    compose.insert(source)
            else:
                compose.insert(source)

            # Add latency tracking if configured
            self._add_latency_tracking(compose, ifo, final_source, final_pad)

        return compose.as_source(
            name=self.name,
            also_expose_source_pads=self._also_expose_pads,
        )


@register_composed_source
@dataclass(kw_only=True)
class WhiteComposedSource(FakeSourceBase):
    """Gaussian white noise source.

    Generates uncorrelated Gaussian white noise for each IFO channel.
    Useful for basic pipeline testing where spectral characteristics
    don't matter.

    Supports both offline and real-time modes:
    - Offline (default): Specify start and end (or duration)
    - Real-time: Set real_time=True, GPS times become optional

    Example:
        >>> # Offline mode
        >>> source = WhiteComposedSource(
        ...     name="noise",
        ...     ifos=["H1", "L1"],
        ...     channel_dict={"H1": "FAKE-STRAIN", "L1": "FAKE-STRAIN"},
        ...     sample_rate=4096,
        ...     start=1000,
        ...     end=1010,
        ... )
        >>>
        >>> # Real-time mode
        >>> source = WhiteComposedSource(
        ...     name="noise",
        ...     ifos=["H1"],
        ...     channel_dict={"H1": "FAKE-STRAIN"},
        ...     sample_rate=4096,
        ...     real_time=True,
        ... )
    """

    source_type: ClassVar[str] = "white"
    description: ClassVar[str] = "Gaussian white noise"
    signal_type: ClassVar[str] = "white"


@register_composed_source
@dataclass(kw_only=True)
class SinComposedSource(FakeSourceBase):
    """Sinusoidal test signal source.

    Generates a sinusoidal signal for each IFO channel.
    Useful for testing frequency-domain processing.

    Supports both offline and real-time modes.

    Example:
        >>> source = SinComposedSource(
        ...     name="sine",
        ...     ifos=["H1"],
        ...     channel_dict={"H1": "FAKE-STRAIN"},
        ...     sample_rate=4096,
        ...     start=1000,
        ...     end=1010,
        ... )
    """

    source_type: ClassVar[str] = "sin"
    description: ClassVar[str] = "Sinusoidal test signal"
    signal_type: ClassVar[str] = "sin"


@register_composed_source
@dataclass(kw_only=True)
class ImpulseComposedSource(FakeSourceBase, ImpulsePositionOptionsMixin):
    """Impulse test signal source.

    Generates an impulse signal (single spike) for each IFO channel.
    Useful for testing impulse response.

    Supports both offline and real-time modes.

    Fields inherited from mixins:
        impulse_position: Sample index for impulse (-1 for random)

    Example:
        >>> source = ImpulseComposedSource(
        ...     name="impulse",
        ...     ifos=["H1"],
        ...     channel_dict={"H1": "FAKE-STRAIN"},
        ...     sample_rate=4096,
        ...     start=1000,
        ...     end=1010,
        ...     impulse_position=100,
        ... )
    """

    source_type: ClassVar[str] = "impulse"
    description: ClassVar[str] = "Impulse test signal"
    signal_type: ClassVar[str] = "impulse"
