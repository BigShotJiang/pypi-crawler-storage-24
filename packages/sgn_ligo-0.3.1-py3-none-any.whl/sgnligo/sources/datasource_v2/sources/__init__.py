"""Composable data source classes for LIGO pipelines.

This package provides dataclass-based source elements that can be instantiated
directly or via the DataSource dispatcher.

Example:
    >>> from sgnligo.sources.datasource_v2.sources import WhiteComposedSource
    >>> source = WhiteComposedSource(
    ...     name="noise",
    ...     ifos=["H1", "L1"],
    ...     channel_dict={"H1": "FAKE-STRAIN", "L1": "FAKE-STRAIN"},
    ...     sample_rate=4096,
    ...     start=1000,
    ...     end=1010,
    ... )
    >>> pipeline.connect(source.element, sink)
"""

from sgnligo.sources.datasource_v2.sources.devshm import DevShmComposedSource
from sgnligo.sources.datasource_v2.sources.fake import (
    ImpulseComposedSource,
    SinComposedSource,
    WhiteComposedSource,
)
from sgnligo.sources.datasource_v2.sources.frames import FramesComposedSource
from sgnligo.sources.datasource_v2.sources.gwdata_noise import GWDataNoiseComposedSource

# Arrakis is optional (requires sgn_arrakis)
try:
    from sgnligo.sources.datasource_v2.sources.arrakis import (  # noqa: F401
        ArrakisComposedSource,
    )

    _HAS_ARRAKIS = True
except ImportError:
    _HAS_ARRAKIS = False

__all__ = [
    # Fake sources (support both offline and real-time via real_time flag)
    "WhiteComposedSource",
    "SinComposedSource",
    "ImpulseComposedSource",
    # GWData noise source (supports both offline and real-time via real_time flag)
    "GWDataNoiseComposedSource",
    # Frame sources
    "FramesComposedSource",
    # DevShm sources
    "DevShmComposedSource",
]

# Add Arrakis if available
if _HAS_ARRAKIS:
    __all__.append("ArrakisComposedSource")
