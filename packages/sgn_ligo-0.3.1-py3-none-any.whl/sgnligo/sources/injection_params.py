"""Unified injection parameter handling with LALDict as canonical format.

This module provides:
1. LALDict as the canonical internal format (SI units)
2. Bidirectional conversion to/from LIGOLW format (astrophysical units)
3. JSON serialization for both formats (wire transport)
4. Shared constants and utilities for CBC simulation

Format Summary:
--------------
                    LALDict (canonical)     LIGOLW
Field names:        ra, dec, psi, phi_ref   longitude, latitude, polarization, coa_phase
Mass units:         kg (SI)                 solar masses
Distance units:     meters (SI)             Mpc
Time format:        t_co_gps (float)        geocent_end_time + geocent_end_time_ns
Approximant:        approximant             waveform

Conversion paths:
----------------
    LALDict (lal.Dict, SI)
        |-- to_lal_dict() / from_lal_dict() -->
    LALParams (Python dict, SI, LAL naming)
        |-- to_json() / from_json() -->
    JSON-LAL (str)

    LALDict (lal.Dict, SI)
        |-- to_ligolw_dict() / from_ligolw_dict() -->
    LIGOLWParams (Python dict, astro units, LIGOLW naming)
        |-- to_json() / from_json() -->
    JSON-LIGOLW (str)
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple, Union

import lal

# =============================================================================
# Unit Conversion Constants
# =============================================================================

MSUN_SI = lal.MSUN_SI  # kg per solar mass
MPC_SI = 1e6 * lal.PC_SI  # meters per Mpc

# =============================================================================
# Shared Location Constants
# =============================================================================

# State College, PA coordinates (default overhead position for testing)
STATE_COLLEGE_LAT_DEG = 40.7934
STATE_COLLEGE_LON_DEG = -77.8600  # West is negative
STATE_COLLEGE_LAT_RAD = math.radians(STATE_COLLEGE_LAT_DEG)
STATE_COLLEGE_LON_RAD = math.radians(STATE_COLLEGE_LON_DEG)

# =============================================================================
# Source Type Parameters (for test mode and mock events)
# =============================================================================

# Fixed parameters for test mode injections (SimInspiralSource)
TEST_MODE_PARAMS: Dict[str, Dict[str, float]] = {
    "bns": {"mass1": 1.4, "mass2": 1.4, "distance": 100.0},
    "nsbh": {"mass1": 10.0, "mass2": 1.4, "distance": 200.0},
    "bbh": {"mass1": 30.0, "mass2": 30.0, "distance": 500.0},
}

# Range parameters for mock event generation (MockGWEventSource)
SOURCE_TYPE_RANGES: Dict[str, Dict[str, Tuple[float, float]]] = {
    "bns": {
        "mass1_range": (1.0, 2.5),
        "mass2_range": (1.0, 2.5),
        "distance_range": (10.0, 300.0),
    },
    "nsbh": {
        "mass1_range": (3.0, 30.0),
        "mass2_range": (1.0, 2.5),
        "distance_range": (50.0, 500.0),
    },
    "bbh": {
        "mass1_range": (5.0, 80.0),
        "mass2_range": (5.0, 80.0),
        "distance_range": (100.0, 2000.0),
    },
}

# Interval between test injections in seconds
TEST_INJECTION_INTERVAL = 30.0

# =============================================================================
# Shared Utility Functions
# =============================================================================


def calculate_overhead_ra(gps_time: float, longitude_rad: float) -> float:
    """Calculate the right ascension for a source directly overhead at a location.

    For a source to be at zenith (directly overhead), its right ascension must
    equal the local sidereal time (LST) at the observer's location.

    LST = GMST + longitude (where longitude is positive east, negative west)

    Args:
        gps_time: GPS time of observation (e.g., coalescence time)
        longitude_rad: Observer longitude in radians (negative for west)

    Returns:
        Right ascension in radians, normalized to [0, 2*pi)
    """
    gmst = lal.GreenwichMeanSiderealTime(gps_time)
    ra = (gmst + longitude_rad) % (2 * math.pi)
    return ra


# =============================================================================
# Schema Definitions
# =============================================================================

# Required fields in LAL format
LAL_REQUIRED_FIELDS = [
    "mass1",  # kg
    "mass2",  # kg
    "distance",  # meters
    "ra",  # radians
    "dec",  # radians
    "psi",  # radians
    "t_co_gps",  # GPS seconds (float)
    "approximant",  # e.g., "IMRPhenomD"
]

# Optional fields in LAL format with defaults
LAL_OPTIONAL_DEFAULTS: Dict[str, float] = {
    "spin1x": 0.0,
    "spin1y": 0.0,
    "spin1z": 0.0,
    "spin2x": 0.0,
    "spin2y": 0.0,
    "spin2z": 0.0,
    "inclination": 0.0,
    "phi_ref": 0.0,
    "f_ref": 20.0,
    "eccentricity": 0.0,
    "long_asc_nodes": 0.0,
    "mean_per_ano": 0.0,
}

# Field name mapping: LAL -> LIGOLW
LAL_TO_LIGOLW_FIELDS = {
    "ra": "longitude",
    "dec": "latitude",
    "psi": "polarization",
    "phi_ref": "coa_phase",
    "approximant": "waveform",
    "f_ref": "f_lower",
    # t_co_gps handled specially (split to int + ns)
}

# Reverse mapping: LIGOLW -> LAL
LIGOLW_TO_LAL_FIELDS = {v: k for k, v in LAL_TO_LIGOLW_FIELDS.items()}

# Fields requiring unit conversion (LAL SI -> LIGOLW astro)
# Format: field_name -> (si_unit, astro_unit, conversion_factor)
# To convert SI -> astro: divide by factor
# To convert astro -> SI: multiply by factor
UNIT_CONVERSIONS = {
    "mass1": ("kg", "Msun", MSUN_SI),
    "mass2": ("kg", "Msun", MSUN_SI),
    "distance": ("m", "Mpc", MPC_SI),
}

# Type aliases for documentation
LALParams = Dict[str, Any]  # LAL naming, SI units
LIGOLWParams = Dict[str, Any]  # LIGOLW naming, astrophysical units


# =============================================================================
# Core Conversion Functions
# =============================================================================


def lal_to_ligolw(params: LALParams) -> LIGOLWParams:
    """Convert LAL format (SI) to LIGOLW format (astrophysical units).

    Args:
        params: Dictionary with LAL naming and SI units

    Returns:
        Dictionary with LIGOLW naming and astrophysical units
    """
    result: Dict[str, Any] = {}

    for key, value in params.items():
        # Handle time specially: float -> int + ns
        if key == "t_co_gps":
            result["geocent_end_time"] = int(value)
            result["geocent_end_time_ns"] = int((value - int(value)) * 1e9)
            continue

        # Apply field name mapping
        out_key = LAL_TO_LIGOLW_FIELDS.get(key, key)

        # Apply unit conversion if needed
        if key in UNIT_CONVERSIONS:
            _, _, factor = UNIT_CONVERSIONS[key]
            result[out_key] = value / factor
        else:
            result[out_key] = value

    return result


def ligolw_to_lal(params: LIGOLWParams) -> LALParams:
    """Convert LIGOLW format (astrophysical) to LAL format (SI units).

    Args:
        params: Dictionary with LIGOLW naming and astrophysical units

    Returns:
        Dictionary with LAL naming and SI units
    """
    result: Dict[str, Any] = {}

    # Handle time specially: int + ns -> float
    if "geocent_end_time" in params:
        ns = params.get("geocent_end_time_ns", 0)
        result["t_co_gps"] = float(params["geocent_end_time"]) + float(ns) * 1e-9

    for key, value in params.items():
        # Skip time fields (handled above)
        if key in ("geocent_end_time", "geocent_end_time_ns"):
            continue

        # Skip None values
        if value is None:
            continue

        # Apply field name mapping
        out_key = LIGOLW_TO_LAL_FIELDS.get(key, key)

        # Apply unit conversion if needed (reverse direction)
        if out_key in UNIT_CONVERSIONS:
            _, _, factor = UNIT_CONVERSIONS[out_key]
            result[out_key] = value * factor
        else:
            result[out_key] = value

    return result


# =============================================================================
# LALDict Conversion (the canonical internal format)
# =============================================================================


def to_lal_dict(params: LALParams) -> lal.Dict:
    """Convert Python dict (LAL format) to lal.Dict.

    This is the canonical internal format for all LALSimulation calculations.

    Args:
        params: Dictionary with LAL naming and SI units

    Returns:
        lal.Dict ready for LALSimulation functions
    """
    d = lal.CreateDict()

    for key, value in params.items():
        if value is None:
            continue
        if isinstance(value, str):
            lal.DictInsertStringValue(d, key, value)
        elif isinstance(value, (int, float)):
            lal.DictInsertREAL8Value(d, key, float(value))

    return d


def from_lal_dict(d: lal.Dict, keys: Optional[List[str]] = None) -> LALParams:
    """Convert lal.Dict to Python dict (LAL format).

    Args:
        d: LAL dictionary
        keys: Specific keys to extract (if None, extracts all known fields)

    Returns:
        Dictionary with LAL naming and SI units
    """
    if keys is None:
        keys = LAL_REQUIRED_FIELDS + list(LAL_OPTIONAL_DEFAULTS.keys())

    result: Dict[str, Any] = {}

    for key in keys:
        try:
            if key == "approximant":
                result[key] = lal.DictLookupStringValue(d, key)
            else:
                result[key] = lal.DictLookupREAL8Value(d, key)
        except (KeyError, RuntimeError):
            # Field not present, use default if available
            if key in LAL_OPTIONAL_DEFAULTS:
                result[key] = LAL_OPTIONAL_DEFAULTS[key]

    return result


def get_lal_dict_value(d: lal.Dict, key: str, default: Optional[float] = None) -> float:
    """Get REAL8 value from LAL dict with optional default.

    Args:
        d: LAL dictionary
        key: Key to look up
        default: Value to return if key not found

    Returns:
        The value from the dict, or default if not found
    """
    try:
        return lal.DictLookupREAL8Value(d, key)
    except (KeyError, RuntimeError):
        if default is not None:
            return default
        return LAL_OPTIONAL_DEFAULTS.get(key, 0.0)


def get_lal_dict_string(d: lal.Dict, key: str, default: str = "") -> str:
    """Get string value from LAL dict with optional default.

    Args:
        d: LAL dictionary
        key: Key to look up
        default: Value to return if key not found

    Returns:
        The value from the dict, or default if not found
    """
    try:
        return lal.DictLookupStringValue(d, key)
    except (KeyError, RuntimeError):
        return default


# =============================================================================
# JSON Serialization
# =============================================================================


class Format(Enum):
    """Serialization format identifier."""

    LAL = "lal"  # LAL naming, SI units
    LIGOLW = "ligolw"  # LIGOLW naming, astrophysical units


@dataclass
class InjectionParams:
    """Wrapper class for injection parameters with format-aware serialization.

    Internally stores parameters in LAL format (SI units). Provides
    conversion to/from LIGOLW format and JSON serialization in either format.

    Examples:
        # Create from LAL format dict
        inj = InjectionParams.from_lal({
            "mass1": 2.78e30,  # kg
            "mass2": 2.78e30,
            "distance": 3.086e24,  # meters
            "ra": 1.5, "dec": 0.5, "psi": 0.0,
            "t_co_gps": 1234567890.5,
            "approximant": "IMRPhenomD",
        })

        # Create from lal.Dict
        inj = InjectionParams.from_lal(lal_dict_obj)

        # Create from LIGOLW format
        inj = InjectionParams.from_ligolw({
            "mass1": 1.4,  # solar masses
            "mass2": 1.4,
            "distance": 100.0,  # Mpc
            "longitude": 1.5, "latitude": 0.5,
            "polarization": 0.0,
            "geocent_end_time": 1234567890,
            "geocent_end_time_ns": 500000000,
            "waveform": "IMRPhenomD",
        })

        # Get as lal.Dict for calculations
        lal_d = inj.to_lal_dict()

        # Serialize to JSON (LAL format)
        json_str = inj.to_json(Format.LAL)

        # Serialize to JSON (LIGOLW format for compatibility)
        json_str = inj.to_json(Format.LIGOLW)

        # Deserialize from JSON
        inj = InjectionParams.from_json(json_str)
    """

    _params: LALParams  # Internal storage: LAL naming, SI units

    @classmethod
    def from_lal(cls, params: Union[LALParams, lal.Dict]) -> "InjectionParams":
        """Create from LAL format (SI units).

        Args:
            params: Either a Python dict with LAL naming/SI units,
                   or a lal.Dict object

        Returns:
            InjectionParams instance
        """
        if isinstance(params, dict):
            return cls(_params=params.copy())
        else:
            # It's a lal.Dict
            return cls(_params=from_lal_dict(params))

    @classmethod
    def from_ligolw(cls, params: LIGOLWParams) -> "InjectionParams":
        """Create from LIGOLW format (astrophysical units).

        Args:
            params: Dictionary with LIGOLW naming and astrophysical units

        Returns:
            InjectionParams instance
        """
        return cls(_params=ligolw_to_lal(params))

    def to_lal_dict(self) -> lal.Dict:
        """Get as lal.Dict for LALSimulation calculations.

        Returns:
            lal.Dict ready for LALSimulation functions
        """
        return to_lal_dict(self._params)

    def to_lal(self) -> LALParams:
        """Get as Python dict in LAL format (SI units).

        Returns:
            Dictionary with LAL naming and SI units
        """
        return self._params.copy()

    def to_ligolw(self) -> LIGOLWParams:
        """Get as Python dict in LIGOLW format (astrophysical units).

        Returns:
            Dictionary with LIGOLW naming and astrophysical units
        """
        return lal_to_ligolw(self._params)

    def to_json(self, fmt: Format = Format.LAL) -> str:
        """Serialize to JSON string.

        Args:
            fmt: Output format (LAL or LIGOLW)

        Returns:
            JSON string with format marker for deserialization
        """
        if fmt == Format.LAL:
            data = {"_format": "lal", "params": self._params}
        else:
            data = {"_format": "ligolw", "params": self.to_ligolw()}
        return json.dumps(data)

    @classmethod
    def from_json(cls, json_str: str) -> "InjectionParams":
        """Deserialize from JSON string.

        Automatically detects format from the _format marker.

        Args:
            json_str: JSON string (from to_json())

        Returns:
            InjectionParams instance
        """
        data = json.loads(json_str)
        fmt = data.get("_format", "lal")
        params = data["params"]

        if fmt == "ligolw":
            return cls.from_ligolw(params)
        else:
            return cls.from_lal(params)

    def with_defaults(self) -> "InjectionParams":
        """Return a copy with all optional fields filled with defaults.

        Returns:
            New InjectionParams with defaults applied
        """
        params = self._params.copy()
        for key, default in LAL_OPTIONAL_DEFAULTS.items():
            if key not in params:
                params[key] = default
        return InjectionParams(_params=params)

    def validate(self) -> None:
        """Validate that all required fields are present.

        Raises:
            ValueError: If any required field is missing
        """
        missing = [f for f in LAL_REQUIRED_FIELDS if f not in self._params]
        if missing:
            raise ValueError(f"Missing required fields: {', '.join(missing)}")

    # -------------------------------------------------------------------------
    # Convenience property accessors
    # -------------------------------------------------------------------------

    @property
    def mass1(self) -> float:
        """Primary mass in kg."""
        return self._params["mass1"]

    @property
    def mass2(self) -> float:
        """Secondary mass in kg."""
        return self._params["mass2"]

    @property
    def mass1_msun(self) -> float:
        """Primary mass in solar masses."""
        return self._params["mass1"] / MSUN_SI

    @property
    def mass2_msun(self) -> float:
        """Secondary mass in solar masses."""
        return self._params["mass2"] / MSUN_SI

    @property
    def distance(self) -> float:
        """Luminosity distance in meters."""
        return self._params["distance"]

    @property
    def distance_mpc(self) -> float:
        """Luminosity distance in Mpc."""
        return self._params["distance"] / MPC_SI

    @property
    def t_co_gps(self) -> float:
        """Coalescence GPS time."""
        return self._params["t_co_gps"]

    @property
    def ra(self) -> float:
        """Right ascension in radians."""
        return self._params["ra"]

    @property
    def dec(self) -> float:
        """Declination in radians."""
        return self._params["dec"]

    @property
    def psi(self) -> float:
        """Polarization angle in radians."""
        return self._params["psi"]

    @property
    def inclination(self) -> float:
        """Inclination angle in radians."""
        return self._params.get("inclination", 0.0)

    @property
    def phi_ref(self) -> float:
        """Reference phase in radians."""
        return self._params.get("phi_ref", 0.0)

    @property
    def approximant(self) -> str:
        """Waveform approximant name."""
        return self._params["approximant"]

    @property
    def mchirp(self) -> float:
        """Chirp mass in kg."""
        m1, m2 = self.mass1, self.mass2
        return (m1 * m2) ** (3.0 / 5.0) / (m1 + m2) ** (1.0 / 5.0)

    @property
    def mchirp_msun(self) -> float:
        """Chirp mass in solar masses."""
        return self.mchirp / MSUN_SI

    @property
    def eta(self) -> float:
        """Symmetric mass ratio."""
        m1, m2 = self.mass1, self.mass2
        return (m1 * m2) / (m1 + m2) ** 2


# =============================================================================
# Batch Operations (for lists of injections)
# =============================================================================


def load_injections_from_ligolw_xml(filepath: str) -> List[InjectionParams]:
    """Load injections from LIGOLW XML file.

    Args:
        filepath: Path to XML file (.xml or .xml.gz)

    Returns:
        List of InjectionParams objects
    """
    from igwn_ligolw import lsctables
    from igwn_ligolw import utils as ligolw_utils

    xmldoc = ligolw_utils.load_filename(filepath, verbose=False)
    sim_table = lsctables.SimInspiralTable.get_table(xmldoc)

    injections = []
    for row in sim_table:
        ligolw_params = _sim_inspiral_row_to_ligolw(row)
        injections.append(InjectionParams.from_ligolw(ligolw_params))

    return injections


def load_injections_from_lal_hdf5(filepath: str) -> List[InjectionParams]:
    """Load injections from LAL HDF5 file.

    Args:
        filepath: Path to LAL-format HDF5 file

    Returns:
        List of InjectionParams objects
    """
    import lalsimulation as lalsim

    seq = lalsim.SimInspiralInjectionSequenceFromH5File(filepath)
    return [
        InjectionParams.from_lal(lal.DictSequenceGet(seq, i)) for i in range(seq.length)
    ]


def load_injections(filepath: str) -> List[InjectionParams]:
    """Load injections from XML or LAL HDF5 file with auto-detection.

    Supports LIGOLW XML (.xml, .xml.gz) and LAL HDF5 (.h5, .hdf5, .hdf) formats.

    Args:
        filepath: Path to injection file

    Returns:
        List of InjectionParams objects
    """
    if filepath.endswith((".xml", ".xml.gz")):
        return load_injections_from_ligolw_xml(filepath)
    elif filepath.endswith((".hdf5", ".h5", ".hdf")):
        return load_injections_from_lal_hdf5(filepath)
    else:
        # Try XML first, then LAL H5
        try:
            return load_injections_from_ligolw_xml(filepath)
        except Exception:
            return load_injections_from_lal_hdf5(filepath)


def _sim_inspiral_row_to_ligolw(row) -> LIGOLWParams:
    """Convert SimInspiral table row to LIGOLW dict.

    Args:
        row: lsctables.SimInspiral row

    Returns:
        Dictionary with LIGOLW naming and astrophysical units
    """
    return {
        "mass1": row.mass1,
        "mass2": row.mass2,
        "spin1x": row.spin1x,
        "spin1y": row.spin1y,
        "spin1z": row.spin1z,
        "spin2x": row.spin2x,
        "spin2y": row.spin2y,
        "spin2z": row.spin2z,
        "distance": row.distance,
        "inclination": row.inclination,
        "coa_phase": row.coa_phase,
        "polarization": row.polarization,
        "longitude": row.longitude,
        "latitude": row.latitude,
        "geocent_end_time": int(row.geocent_end_time),
        "geocent_end_time_ns": int(row.geocent_end_time_ns),
        "waveform": row.waveform or "IMRPhenomD",
        "f_lower": getattr(row, "f_lower", 20.0) or 20.0,
        "eccentricity": getattr(row, "eccentricity", 0.0) or 0.0,
        "long_asc_nodes": getattr(row, "long_asc_nodes", 0.0) or 0.0,
        "mean_per_ano": getattr(row, "mean_per_ano", 0.0) or 0.0,
    }


# =============================================================================
# Factory Functions for Test Injections
# =============================================================================


def create_test_injection(
    test_mode: str,
    t_co_gps: float,
    latitude_rad: float = STATE_COLLEGE_LAT_RAD,
    longitude_rad: float = STATE_COLLEGE_LON_RAD,
) -> InjectionParams:
    """Generate a test injection for the given GPS coalescence time.

    Creates an InjectionParams with parameters for a test signal positioned
    directly overhead of the specified location at coalescence time.

    Args:
        test_mode: Type of injection ("bns", "nsbh", or "bbh")
        t_co_gps: GPS coalescence time
        latitude_rad: Observer latitude in radians (default: State College, PA)
        longitude_rad: Observer longitude in radians (default: State College, PA)

    Returns:
        InjectionParams with test injection parameters (SI units internally)

    Raises:
        ValueError: If test_mode is not valid
    """
    test_mode_lower = test_mode.lower()
    if test_mode_lower not in TEST_MODE_PARAMS:
        raise ValueError(
            f"Invalid test_mode '{test_mode}'. "
            f"Must be one of: {list(TEST_MODE_PARAMS.keys())}"
        )

    mode_params = TEST_MODE_PARAMS[test_mode_lower]
    ra = calculate_overhead_ra(t_co_gps, longitude_rad)

    # Build in LAL format (SI units)
    lal_params: LALParams = {
        # Masses - convert from solar masses to SI (kg)
        "mass1": mode_params["mass1"] * MSUN_SI,
        "mass2": mode_params["mass2"] * MSUN_SI,
        # Distance - convert from Mpc to SI (meters)
        "distance": mode_params["distance"] * MPC_SI,
        # Sky position - overhead means dec = latitude, ra = LST
        "ra": ra,
        "dec": latitude_rad,
        # Polarization angle
        "psi": 0.0,
        # Coalescence time
        "t_co_gps": t_co_gps,
        # Approximant
        "approximant": "IMRPhenomD",
    }

    # Add optional fields with defaults
    for key, default in LAL_OPTIONAL_DEFAULTS.items():
        if key not in lal_params:
            lal_params[key] = default

    return InjectionParams(_params=lal_params)
