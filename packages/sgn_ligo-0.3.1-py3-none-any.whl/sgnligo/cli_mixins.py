"""Shared CLI option mixins for sgnligo.

This module provides CLI mixins that are shared across multiple subsystems
(e.g., datasource_v2 and condition_v2). Placing them here avoids cross-package
imports and prevents duplicate CLI argument registration when combining parsers.

All mixins use `@dataclass(kw_only=True)` to avoid field ordering issues when
combining multiple mixins via multiple inheritance.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
from typing import Any, Dict, List, Protocol, Set

# =============================================================================
# Base Protocol for CLI Mixins
# =============================================================================


class CLIMixinProtocol(Protocol):
    """Protocol defining the interface for CLI mixins.

    All mixins should implement:
    - add_cli_arguments(parser): Add CLI arguments to the parser
    - get_cli_arg_names(): Return set of CLI arg names (for duplicate detection)
    - process_cli_args(args): Convert CLI args to field values
    """

    @classmethod
    def add_cli_arguments(cls, parser: argparse.ArgumentParser) -> None:
        """Add CLI arguments for this mixin."""
        ...  # pragma: no cover

    @classmethod
    def get_cli_arg_names(cls) -> Set[str]:
        """Return set of CLI argument names defined by this mixin."""
        ...  # pragma: no cover

    @classmethod
    def process_cli_args(cls, args: argparse.Namespace) -> Dict[str, Any]:
        """Convert CLI args to field values."""
        ...  # pragma: no cover


# =============================================================================
# IFO Options
# =============================================================================


@dataclass(kw_only=True)
class IfosOnlyMixin:
    """Mixin for components that need an IFO list.

    Used by data sources (fake sources, GW data sources) and condition
    transforms that operate per-detector.

    Fields:
        ifos: List of detector prefixes (e.g., ["H1", "L1"])
    """

    ifos: List[str]

    @classmethod
    def add_cli_arguments(cls, parser: argparse.ArgumentParser) -> None:
        """Add IFO list CLI argument."""
        parser.add_argument(
            "--ifos",
            action="append",
            metavar="IFO",
            help="Detector prefix (repeatable, e.g., H1 L1)",
        )

    @classmethod
    def get_cli_arg_names(cls) -> Set[str]:
        return {"ifos"}

    @classmethod
    def process_cli_args(cls, args: argparse.Namespace) -> Dict[str, Any]:
        """Convert --ifos args to ifos list.

        Also derives ifos from channel_name if --ifos not provided,
        for backward compatibility with pipelines that use --channel-name.
        """
        from sgnligo.base import parse_list_to_dict

        ifos = getattr(args, "ifos", None)
        if ifos:
            return {"ifos": ifos}

        # Fallback: derive ifos from channel_name if provided
        channel_name = getattr(args, "channel_name", None)
        if channel_name:
            channel_dict = parse_list_to_dict(channel_name)
            return {"ifos": sorted(channel_dict.keys())}

        return {}


# =============================================================================
# Utility Functions
# =============================================================================


def get_existing_parser_args(parser: argparse.ArgumentParser) -> Set[str]:
    """Get set of argument destination names already registered in a parser.

    This is useful for checking if an argument has already been added
    before attempting to add it again (which would raise an error).

    Args:
        parser: The argument parser to inspect

    Returns:
        Set of argument destination names (e.g., {"ifos", "start", "end"})
    """
    existing = set()
    for action in parser._actions:
        if action.dest and action.dest != "help":
            existing.add(action.dest)
    return existing


def _collect_mixin_arg_names(cls: type, protocol_cls: type) -> Set[str]:
    """Collect CLI arg names from all mixins in a class's MRO.

    Args:
        cls: The composed source/transform class
        protocol_cls: The CLIMixinProtocol class to skip

    Returns:
        Set of CLI arg names handled by this class's mixins
    """
    arg_names: Set[str] = set()
    for base in cls.__mro__:
        if base is protocol_cls:
            continue
        if "get_cli_arg_names" in getattr(base, "__dict__", {}):
            arg_names.update(base.get_cli_arg_names())  # type: ignore[attr-defined]
    return arg_names


def check_unconsumed_cli_args(
    args: argparse.Namespace,
    selected_type: str,
    selected_cls: type,
    registry: Dict[str, type],
    protocol_cls: type,
    type_flag: str,
    parser: argparse.ArgumentParser,
) -> None:
    """Raise an error if the user provided CLI args that the selected type ignores.

    Compares args consumed by the selected class's mixins against args
    from all registered classes.  Any arg that belongs to another type's
    mixin, is not consumed by the selected type, and was explicitly set
    by the user (i.e., differs from the parser default) triggers a
    ValueError.

    Args:
        args: Parsed argparse namespace
        selected_type: The selected type name (e.g., "frames", "standard")
        selected_cls: The selected composed class
        registry: Full registry of all composed classes
        protocol_cls: The CLIMixinProtocol class to skip
        type_flag: The CLI flag that selects the type (e.g., "--data-source")
        parser: The ArgumentParser used to parse args (for default comparison)

    Raises:
        ValueError: If unconsumed args were explicitly set
    """
    consumed = _collect_mixin_arg_names(selected_cls, protocol_cls)

    all_args: Set[str] = set()
    for cls in registry.values():
        all_args.update(_collect_mixin_arg_names(cls, protocol_cls))

    unconsumed = all_args - consumed
    bad = []
    for arg_name in sorted(unconsumed):
        value = getattr(args, arg_name, None)
        default = parser.get_default(arg_name)
        if value == default:
            continue
        bad.append(f"--{arg_name.replace('_', '-')}")

    if bad:
        raise ValueError(
            f"{', '.join(bad)} {'has' if len(bad) == 1 else 'have'} no effect "
            f"with {type_flag} {selected_type}"
        )


# =============================================================================
# Exports
# =============================================================================


__all__ = [
    # Protocol
    "CLIMixinProtocol",
    # IFO options
    "IfosOnlyMixin",
    # Utilities
    "get_existing_parser_args",
    "check_unconsumed_cli_args",
]
