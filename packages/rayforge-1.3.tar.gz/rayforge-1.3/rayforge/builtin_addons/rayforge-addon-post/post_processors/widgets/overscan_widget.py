from typing import TYPE_CHECKING

from gi.repository import Adw, Gtk
from gettext import gettext as _

from rayforge.ui_gtk.doceditor.step_settings.base import (
    StepComponentSettingsWidget,
)
from rayforge.context import get_context
from ..transformers import OverscanTransformer
from rayforge.shared.util.glib import DebounceMixin
from rayforge.ui_gtk.shared.unit_spin_row import UnitSpinRowHelper

if TYPE_CHECKING:
    from rayforge.core.step import Step
    from rayforge.doceditor.editor import DocEditor


class OverscanSettingsWidget(DebounceMixin, StepComponentSettingsWidget):
    """UI for configuring the OverscanTransformer."""

    def __init__(
        self,
        editor: "DocEditor",
        title: str,
        transformer: OverscanTransformer,
        page: Adw.PreferencesPage,
        step: "Step",
        **kwargs,
    ):
        super().__init__(
            editor,
            title,
            component=transformer,
            page=page,
            step=step,
            description=transformer.description,
            **kwargs,
        )

        self._previous_cut_speed = step.cut_speed
        step.updated.connect(self._on_step_updated)

        # Listen to machine changes to catch acceleration updates immediately
        machine = get_context().machine
        if machine:
            machine.changed.connect(self._on_machine_changed)

        # Main toggle switch
        switch_row = Adw.SwitchRow(title=_("Enable Overscan"))
        switch_row.set_active(transformer.enabled)
        self.add(switch_row)

        # Auto mode toggle
        self.auto_row = Adw.SwitchRow(
            title=_("Automatic Distance"),
            subtitle=_(
                "Calculate distance based on speed and acceleration with "
                "safety factor"
            ),
        )
        self.auto_row.set_active(transformer.auto)
        self.add(self.auto_row)

        # Distance setting with unit support
        distance_adj = Gtk.Adjustment(
            lower=0.0, upper=50.0, step_increment=0.1, page_increment=1.0
        )
        distance_row = Adw.SpinRow(
            title=_("Overscan Distance"),
            adjustment=distance_adj,
            digits=2,
        )
        distance_row.set_subtitle(_("Manual distance setting"))
        self.add(distance_row)
        self.distance_row = distance_row  # Store reference for later access

        # Add unit conversion helper for length
        self.distance_helper = UnitSpinRowHelper(
            spin_row=distance_row, quantity="length", max_value_in_base=50.0
        )
        self.distance_helper.set_value_in_base_units(transformer.distance_mm)

        # Connect signals
        switch_row.connect("notify::active", self._on_enable_toggled)
        self.auto_row.connect("notify::active", self._on_auto_toggled)
        distance_row.connect(
            "changed",
            lambda r: self._debounce(self._on_distance_changed, r),
        )

        # Set initial sensitivity
        is_sensitive = transformer.enabled and not transformer.auto
        distance_row.set_sensitive(is_sensitive)
        switch_row.connect(
            "notify::active",
            lambda w, _: self._update_sensitivity(),
        )
        self.auto_row.connect(
            "notify::active",
            lambda w, _: self._update_sensitivity(),
        )

    def _set_step_param(self, key, new_value, name):
        """Helper method to set a step parameter with standard callback."""
        self.editor.step.set_step_param(
            target_dict=self.target_dict,
            key=key,
            new_value=new_value,
            name=name,
            on_change_callback=lambda: self.step.updated.send(self.step),
        )

    def _update_sensitivity(self):
        """Update the sensitivity of UI elements based on current state."""
        enabled = self.target_dict.get("enabled", True)
        auto = self.target_dict.get("auto", True)

        # Use the stored references to the rows
        self.distance_row.set_sensitive(enabled and not auto)
        self.auto_row.set_sensitive(enabled)

    def _on_enable_toggled(self, row, pspec):
        new_value = row.get_active()
        self._set_step_param("enabled", new_value, _("Toggle Overscan"))
        self._update_sensitivity()

    def _on_auto_toggled(self, row, pspec):
        new_value = row.get_active()
        self._set_step_param("auto", new_value, _("Toggle Auto Overscan"))

        # If auto is enabled, recalculate the distance
        if new_value:
            self._recalculate_distance()

        self._update_sensitivity()

    def _recalculate_distance(self):
        """Recalculate the overscan distance based on current step settings."""
        machine = get_context().machine
        if not machine:
            return

        # Calculate new distance
        new_distance = OverscanTransformer.calculate_auto_distance(
            self.step.cut_speed, machine.acceleration
        )

        # Update the distance
        self._set_step_param(
            "distance_mm", new_distance, _("Auto Calculate Overscan Distance")
        )

        # Update the UI
        self.distance_helper.set_value_in_base_units(new_distance)

    def _on_step_updated(self, step: "Step"):
        """Handle step updates to recalculate overscan distance if needed."""
        if self.target_dict.get("auto", True):
            if step.cut_speed != self._previous_cut_speed:
                self._previous_cut_speed = step.cut_speed
                self._recalculate_distance()

    def _on_machine_changed(self, machine):
        """
        Handle machine updates (e.g. acceleration) to recalculate overscan.
        """
        if self.target_dict.get("auto", True):
            self._recalculate_distance()

    def _on_distance_changed(self, spin_row):
        # Get the value in base units directly from the helper
        new_value = self.distance_helper.get_value_in_base_units()

        # If auto is currently enabled, disable it when user manually changes
        # the distance (via +/- buttons or typing)
        if self.target_dict.get("auto", True):
            self._set_step_param("auto", False, _("Disable Auto Overscan"))

        self._set_step_param(
            "distance_mm", new_value, _("Change Overscan Distance")
        )
