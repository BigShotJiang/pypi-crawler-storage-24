import pytest
import numpy as np
from scipy.optimize import check_grad
from types import SimpleNamespace
from unittest.mock import MagicMock
from sketcher.core import Sketch
from sketcher.core.selection import SketchSelection
from sketcher.core.constraints import DistanceConstraint
from sketcher.core.params import ParameterContext
from sketcher.core.registry import EntityRegistry


@pytest.fixture
def setup_env():
    reg = EntityRegistry()
    params = ParameterContext()
    return reg, params


def test_distance_constraint(setup_env):
    reg, params = setup_env
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(10, 0)

    # Target is 10, actual is 10. Error should be 10 - 10 = 0.
    c = DistanceConstraint(p1, p2, 10.0)
    assert c.error(reg, params) == pytest.approx(0.0)
    assert c.user_visible is True

    # Target is 5, actual is 10. Error should be 10 - 5 = 5.
    c2 = DistanceConstraint(p1, p2, 5.0)
    assert c2.error(reg, params) == pytest.approx(5.0)


def test_distance_constraint_user_visible(setup_env):
    reg, params = setup_env
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(10, 0)

    c = DistanceConstraint(p1, p2, 10.0, user_visible=False)
    assert c.user_visible is False

    c2 = DistanceConstraint(p1, p2, 10.0, user_visible=True)
    assert c2.user_visible is True


def test_distance_constrains_radius_method(setup_env):
    reg, params = setup_env
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(10, 0)
    c = DistanceConstraint(p1, p2, 10.0)

    # Distance constraint doesn't constrain radius of an entity
    assert c.constrains_radius(reg, 999) is False
    assert c.constrains_radius(reg, p1) is False


def test_distance_targets_segment(setup_env):
    reg, params = setup_env
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(10, 0)
    p3 = reg.add_point(5, 5)

    c = DistanceConstraint(p1, p2, 10.0)

    # Should match exact pair (order independent)
    assert c.targets_segment(p1, p2, None) is True
    assert c.targets_segment(p2, p1, None) is True

    # Should not match subset or disjoint
    assert c.targets_segment(p1, p3, None) is False
    assert c.targets_segment(p3, p2, None) is False

    # Entity ID is ignored by DistanceConstraint logic (it only tracks points)
    assert c.targets_segment(p1, p2, 999) is True


def test_distance_constraint_with_expression(setup_env):
    reg, params = setup_env
    # Mimic context values
    ctx = {"width": 20.0}

    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(10, 0)

    c = DistanceConstraint(p1, p2, "width")

    # Sync value
    c.update_from_context(ctx)

    # Actual dist is 10, Target dist is 20. Error is 10 - 20 = -10.
    assert c.error(reg, params) == pytest.approx(-10.0)


def test_distance_constraint_gradient(setup_env):
    """
    Uses scipy.optimize.check_grad to numerically verify the analytical
    gradient of DistanceConstraint.
    """
    reg, params = setup_env
    p1_id = reg.add_point(1, 2)
    p2_id = reg.add_point(5, 6)
    mutable_pids = [p1_id, p2_id]

    constraint = DistanceConstraint(p1=p1_id, p2=p2_id, value=10.0)

    pid_to_idx_map = {pid: i for i, pid in enumerate(mutable_pids)}

    def update_state_from_vec(x_vec):
        for pid, i in pid_to_idx_map.items():
            pt = reg.get_point(pid)
            pt.x = x_vec[i * 2]
            pt.y = x_vec[i * 2 + 1]

    def func_wrapper(x_vec):
        update_state_from_vec(x_vec)
        return constraint.error(reg, params)

    def grad_wrapper(x_vec):
        update_state_from_vec(x_vec)
        grad_map = constraint.gradient(reg, params)
        grad_vec = np.zeros_like(x_vec)
        for pid, grads in grad_map.items():
            if pid in pid_to_idx_map:
                idx = pid_to_idx_map[pid] * 2
                dx, dy = grads[0]
                grad_vec[idx] = dx
                grad_vec[idx + 1] = dy
        return grad_vec

    x0 = np.array([1, 2, 5, 6], dtype=float)
    diff = check_grad(func_wrapper, grad_wrapper, x0, epsilon=1e-6)
    assert diff < 1e-5


def test_distance_constraint_serialization_round_trip(setup_env):
    reg, params = setup_env
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(10, 0)

    # Create original constraint
    original = DistanceConstraint(p1, p2, 5.0)

    # Serialize to dict
    serialized = original.to_dict()

    # Deserialize from dict
    restored = DistanceConstraint.from_dict(serialized)

    # Check that the restored constraint has the same error
    assert original.error(reg, params) == restored.error(reg, params)
    assert original.user_visible == restored.user_visible


def test_distance_constraint_serialization_round_trip_with_expression(
    setup_env,
):
    reg, params = setup_env
    ctx = {"width": 20.0}
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(10, 0)

    # Create original constraint with expression
    original = DistanceConstraint(p1, p2, "width")
    original.update_from_context(ctx)

    # Serialize to dict
    serialized = original.to_dict()

    # Deserialize from dict
    restored = DistanceConstraint.from_dict(serialized)

    # Must sync restored constraint too
    restored.update_from_context(ctx)

    # Check that the restored constraint has the same error
    assert original.error(reg, params) == restored.error(reg, params)


def test_distance_is_hit(setup_env):
    reg, params = setup_env
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(100, 0)
    c = DistanceConstraint(p1, p2, 100)

    def to_screen(pos):
        return pos

    mock_element = SimpleNamespace()
    threshold = 15.0

    # Hit on the line segment (at midpoint)
    assert c.is_hit(50, 0, reg, to_screen, mock_element, threshold) is True

    # Hit on the line segment (not at midpoint)
    assert c.is_hit(70, 0, reg, to_screen, mock_element, threshold) is True

    # Hit near the line segment (within threshold)
    assert c.is_hit(50, 10, reg, to_screen, mock_element, threshold) is True

    # Miss - far from the line segment (beyond threshold)
    assert c.is_hit(50, 20, reg, to_screen, mock_element, threshold) is False


def test_distance_draw(setup_env):
    reg, params = setup_env
    p1 = reg.add_point(0, 0)
    p2 = reg.add_point(100, 0)
    c = DistanceConstraint(p1, p2, 100)

    ctx = MagicMock()

    def to_screen(pos):
        return pos

    c.draw(ctx, reg, to_screen)
    c.draw(ctx, reg, to_screen, is_selected=True)
    c.draw(ctx, reg, to_screen, is_hovered=True)
    c.draw(ctx, reg, to_screen, point_radius=10.0)


def test_distance_can_apply_to_two_points():
    sketch = Sketch()
    p1 = sketch.add_point(0, 0)
    p2 = sketch.add_point(10, 0)

    selection = SketchSelection()
    selection.point_ids = [p1, p2]
    selection.entity_ids = []
    assert DistanceConstraint.can_apply_to(selection, sketch) is True


def test_distance_can_apply_to_single_line():
    sketch = Sketch()
    p1 = sketch.add_point(0, 0)
    p2 = sketch.add_point(10, 0)
    line_id = sketch.add_line(p1, p2)

    selection = SketchSelection()
    selection.point_ids = []
    selection.entity_ids = [line_id]
    assert DistanceConstraint.can_apply_to(selection, sketch) is True


def test_distance_can_apply_to_multiple_lines():
    sketch = Sketch()
    p1 = sketch.add_point(0, 0)
    p2 = sketch.add_point(10, 0)
    p3 = sketch.add_point(20, 0)
    p4 = sketch.add_point(30, 0)
    line1_id = sketch.add_line(p1, p2)
    line2_id = sketch.add_line(p3, p4)

    selection = SketchSelection()
    selection.point_ids = []
    selection.entity_ids = [line1_id, line2_id]
    assert DistanceConstraint.can_apply_to(selection, sketch) is False
