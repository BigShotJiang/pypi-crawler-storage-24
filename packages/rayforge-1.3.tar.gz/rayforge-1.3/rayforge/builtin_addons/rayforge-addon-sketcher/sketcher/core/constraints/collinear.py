from __future__ import annotations
from typing import Dict, Any, List, Optional, TYPE_CHECKING
from gettext import gettext as _
from rayforge.core.geo import Point
from .base import Constraint
from ..types import EntityID

if TYPE_CHECKING:
    from ..params import ParameterContext
    from ..registry import EntityRegistry
    from ..selection import SketchSelection
    from ..sketch import Sketch


class CollinearConstraint(Constraint):
    """Enforces that three points (p1, p2, p3) lie on the same line."""

    def __init__(
        self,
        p1: EntityID,
        p2: EntityID,
        p3: EntityID,
        user_visible: bool = True,
    ):
        super().__init__(user_visible=user_visible)
        self.p1: EntityID = p1
        self.p2: EntityID = p2
        self.p3: EntityID = p3

    @classmethod
    def can_apply_to(
        cls, selection: "SketchSelection", sketch: Optional["Sketch"] = None
    ) -> bool:
        return len(selection.point_ids) == 3 and not selection.entity_ids

    @staticmethod
    def get_type_name() -> str:
        """Returns to human-readable name of this constraint type."""
        return _("Collinear")

    def get_title(self) -> str:
        """Returns a human-readable title for this constraint."""
        return self.get_type_name()

    def get_subtitle(self, registry: "EntityRegistry") -> str:
        """Returns a human-readable subtitle describing constrained points."""
        p1 = registry.get_point(self.p1)
        p2 = registry.get_point(self.p2)
        p3 = registry.get_point(self.p3)
        if p1 and p2 and p3:
            return _("{}, {}, {}").format(
                self._format_coord(p1.x, p1.y),
                self._format_coord(p2.x, p2.y),
                self._format_coord(p3.x, p3.y),
            )
        return ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "type": "CollinearConstraint",
            "p1": self.p1,
            "p2": self.p2,
            "p3": self.p3,
            "user_visible": self.user_visible,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CollinearConstraint":
        return cls(
            p1=data["p1"],
            p2=data["p2"],
            p3=data["p3"],
            user_visible=data.get("user_visible", True),
        )

    def error(
        self, reg: "EntityRegistry", params: "ParameterContext"
    ) -> float:
        pt1 = reg.get_point(self.p1)
        pt2 = reg.get_point(self.p2)
        pt3 = reg.get_point(self.p3)
        # Cross product of (p2 - p1) and (p3 - p1)
        return (pt2.x - pt1.x) * (pt3.y - pt1.y) - (pt2.y - pt1.y) * (
            pt3.x - pt1.x
        )

    def gradient(
        self, reg: "EntityRegistry", params: "ParameterContext"
    ) -> Dict[EntityID, List[Point]]:
        p1 = reg.get_point(self.p1)
        p2 = reg.get_point(self.p2)
        p3 = reg.get_point(self.p3)

        # E = (p2x - p1x) * (p3y - p1y) - (p2y - p1y) * (p3x - p1x)
        # dE/dp1x = -(p3y - p1y) + (p2y - p1y) = p2y - p3y
        # dE/dp1y = -(p2x - p1x) + (p3x - p1x) = p3x - p2x
        # dE/dp2x = (p3y - p1y)
        # dE/dp2y = -(p3x - p1x)
        # dE/dp3x = -(p2y - p1y)
        # dE/dp3y = (p2x - p1x)

        return {
            self.p1: [(p2.y - p3.y, p3.x - p2.x)],
            self.p2: [(p3.y - p1.y, -(p3.x - p1.x))],
            self.p3: [(-(p2.y - p1.y), p2.x - p1.x)],
        }
