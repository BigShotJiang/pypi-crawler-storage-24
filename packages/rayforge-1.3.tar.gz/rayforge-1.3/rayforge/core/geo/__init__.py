"""
The path module contains shared, stateless utility functions for manipulating
path-like data structures (such as Ops and Geometry). These functions are
generic and have no knowledge of the high-level objects that use them.
"""

from . import analysis
from . import contours
from . import fitting
from . import intersect
from . import linearize
from . import minkowski
from . import polygon
from . import primitives
from . import query
from . import smooth
from . import text
from . import transform

from .types import (
    Edge,
    IntPoint,
    IntPolygon,
    Point,
    Point2DOr3D,
    Point3D,
    Polygon,
    Rect,
)
from .constants import (
    CMD_TYPE_MOVE,
    CMD_TYPE_LINE,
    CMD_TYPE_ARC,
    CMD_TYPE_BEZIER,
    COL_TYPE,
    COL_X,
    COL_Y,
    COL_Z,
    COL_I,
    COL_J,
    COL_CW,
    COL_C1X,
    COL_C1Y,
    COL_C2X,
    COL_C2Y,
    GEO_ARRAY_COLS,
)
from .font_config import FontConfig
from .geometry import Geometry

__all__ = [
    "Edge",
    "IntPoint",
    "IntPolygon",
    "Point",
    "Point2DOr3D",
    "Point3D",
    "Polygon",
    "analysis",
    "contours",
    "fitting",
    "intersect",
    "linearize",
    "minkowski",
    "polygon",
    "primitives",
    "query",
    "smooth",
    "text",
    "transform",
    "FontConfig",
    "Geometry",
    "Rect",
    "CMD_TYPE_MOVE",
    "CMD_TYPE_LINE",
    "CMD_TYPE_ARC",
    "CMD_TYPE_BEZIER",
    "COL_TYPE",
    "COL_X",
    "COL_Y",
    "COL_Z",
    "COL_I",
    "COL_J",
    "COL_CW",
    "COL_C1X",
    "COL_C1Y",
    "COL_C2X",
    "COL_C2Y",
    "GEO_ARRAY_COLS",
]
