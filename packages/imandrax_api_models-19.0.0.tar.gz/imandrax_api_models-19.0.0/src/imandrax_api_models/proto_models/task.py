from __future__ import annotations

from enum import Enum

import imandrax_api.bindings.task_pb2 as xtask_pb2
from pydantic import Field

from ..proto_utils import BaseModel


class TaskKind(Enum):
    TASK_UNSPECIFIED = 'TASK_UNSPECIFIED'
    TASK_EVAL = 'TASK_EVAL'
    TASK_CHECK_PO = 'TASK_CHECK_PO'
    TASK_PROOF_CHECK = 'TASK_PROOF_CHECK'
    TASK_DECOMP = 'TASK_DECOMP'


class TaskID(BaseModel):
    id: str = Field(description='The task identifier')


class Task(BaseModel):
    id: TaskID | None = Field(default=None)
    kind: TaskKind

    def to_proto(self) -> xtask_pb2.Task:
        task_id = None
        if self.id is not None:
            task_id = xtask_pb2.TaskID(id=self.id.id)
        return xtask_pb2.Task(id=task_id, kind=self.kind.value)


class Origin(BaseModel):
    from_sym: str = Field(description='Symbol from which the task originated')
    count: int = Field(description='A counter for tasks for this symbol')
