from collections.abc import Mapping
from typing import Union
from unittest import mock

import pandas as pd
import pytest
import requests
from requests.auth import HTTPBasicAuth

from owi.metadatabase._utils.exceptions import (
    APIConnectionError,
    InvalidParameterError,
)
from owi.metadatabase.io import API, PostprocessData


class TestAPIAuth:
    """Tests of authentication setup."""

    @pytest.mark.parametrize(
        "header",
        [
            ({"Authorization": "Token 12345"}),
            ({"Authorization": "token 12345"}),
            ({"Authorization": "token12345"}),
            ({"Authorization": "Token12345"}),
            ({"Authorization": "12345"}),
        ],
    )
    def test_API_header(self, api_root: str, header) -> None:
        """Test parent API class with header that it initializes everything correctly."""
        header_expected = {"Authorization": "Token 12345"}
        api_test = API(api_root, header=header)
        assert api_test.api_root == api_root
        assert api_test.header == header_expected
        assert api_test.uname is None
        assert api_test.password is None
        assert api_test.auth is None

    def test_API_user(self, api_root: str) -> None:
        """Test parent API class with user credentials that it initializes everything correctly."""
        name = "test"
        pswd = "12345"
        api_test = API(api_root, uname=name, password=pswd)
        assert api_test.api_root == api_root
        assert api_test.header is None
        assert api_test.uname == name
        assert api_test.password == pswd
        assert api_test.auth == HTTPBasicAuth(name, pswd)

    def test_API_token(self, api_root: str) -> None:
        """Test parent API class with header that it initializes everything correctly."""
        token = "12345"
        header = {"Authorization": "Token 12345"}
        api_test = API(api_root, token=token)
        assert api_test.api_root == api_root
        assert api_test.header == header
        assert api_test.uname is None
        assert api_test.password is None
        assert api_test.auth is None


def test_send_request_with_token(mock_requests_get: mock.Mock, api_root: str) -> None:
    header = {"Authorization": "Token 12345"}
    url_data_type = "/test/"
    url_params: Mapping[str, Union[str, float, int]] = {
        "test1": "test",
        "test2": 1,
        "test3": 1.0,
    }
    api_test = API(api_root, header=header)
    response = api_test.send_request(url_data_type, url_params)
    assert isinstance(response, requests.models.Response)


def test_send_request_with_name_pass(mock_requests_get: mock.Mock, api_root: str) -> None:
    name = "test"
    pswd = "12345"
    url_data_type = "/test/"
    url_params = {"test": "test"}
    api_test = API(api_root, uname=name, password=pswd)
    response = api_test.send_request(url_data_type, url_params)
    assert isinstance(response, requests.models.Response)


def test_check_request_health() -> None:
    response = requests.Response()
    response.status_code = 200
    API.check_request_health(response)
    response.status_code = 404
    with pytest.raises(APIConnectionError):
        API.check_request_health(response)


def test_output_to_df() -> None:
    response = requests.Response()
    response._content = b'[{"col_1": 11, "col_2": 12, "col_3": 13}, {"col_1": 21, "col_2": 22, "col_3": 23}]'
    df = API.output_to_df(response)
    assert isinstance(df, pd.DataFrame)
    assert df["col_1"][0] == 11
    assert df["col_1"][1] == 21
    assert df["col_2"][0] == 12
    assert df["col_2"][1] == 22
    assert df["col_3"][0] == 13
    assert df["col_3"][1] == 23


@pytest.mark.parametrize(
    "df, output_type, expected_result, expected_exception",
    [
        (
            pd.DataFrame([]),
            "single",
            {"existance": False, "id": None, "response": None},
            None,
        ),
        (
            pd.DataFrame([{"id": 239, "col_test": "text test"}]),
            "single",
            {"existance": True, "id": 239, "response": None},
            None,
        ),
        (
            pd.DataFrame(
                [
                    {"id": 1, "col_test": "text 1"},
                    {"id": 2, "col_test": "text 2"},
                ]
            ),
            "single",
            None,
            InvalidParameterError,
        ),
        (
            pd.DataFrame([]),
            "list",
            {"existance": False, "id": None, "response": None},
            None,
        ),
        (
            pd.DataFrame([{"id": 239, "col_test": "text test"}]),
            "list",
            {"existance": True, "id": None, "response": None},
            None,
        ),
        (
            pd.DataFrame(
                [
                    {"id": 1, "col_test": "text 1"},
                    {"id": 2, "col_test": "text 2"},
                ]
            ),
            "list",
            {"existance": True, "id": None, "response": None},
            None,
        ),
        (
            pd.DataFrame([{"id": 239, "col_test": "text test"}]),
            "multiple",
            None,
            InvalidParameterError,
        ),
    ],
)
def test_postprocess_data(
    df: pd.DataFrame,
    output_type: str,
    expected_result: PostprocessData,
    expected_exception: None,
) -> None:
    if expected_exception is not None:
        with pytest.raises(expected_exception):
            API.postprocess_data(df, output_type)
    else:
        result = API.postprocess_data(df, output_type)
        assert result == expected_result


def test_process_data(api_root: str, header: dict[str, str], mock_requests_get_advanced: mock.Mock) -> None:
    header = header
    url_data_type = "/test/"
    url_params: Mapping[str, Union[str, float, int]] = {
        "test1": "test",
        "test2": 1,
        "test3": 1.0,
    }
    output_type = "list"
    api_test = API(api_root, header=header)
    df, df_add = api_test.process_data(url_data_type, url_params, output_type)
    assert isinstance(df, pd.DataFrame)
    assert isinstance(df_add, dict)
    assert isinstance(df_add["existance"], bool)
