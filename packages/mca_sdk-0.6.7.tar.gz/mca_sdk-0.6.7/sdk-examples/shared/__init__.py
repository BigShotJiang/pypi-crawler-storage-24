"""Shared utilities for SDK examples."""

from .gcp_helpers import (
    verify_gcp_auth,
    test_collector_connectivity,
    print_gcp_auth_status,
    print_collector_status,
)
from .verification import verify_cloud_logging, verify_cloud_trace
from .config import (
    COLLECTOR_HTTP_ENDPOINT,
    COLLECTOR_GRPC_ENDPOINT,
    REGISTRY_URL,
    DEFAULT_MODEL_ID,
)

__all__ = [
    "verify_gcp_auth",
    "test_collector_connectivity",
    "print_gcp_auth_status",
    "print_collector_status",
    "verify_cloud_logging",
    "verify_cloud_trace",
    "COLLECTOR_HTTP_ENDPOINT",
    "COLLECTOR_GRPC_ENDPOINT",
    "REGISTRY_URL",
    "DEFAULT_MODEL_ID",
]
