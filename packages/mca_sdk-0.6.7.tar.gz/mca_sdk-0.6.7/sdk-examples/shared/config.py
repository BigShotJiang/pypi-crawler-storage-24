"""Standard configuration constants for SDK examples."""

COLLECTOR_HTTP_ENDPOINT = "http://10.164.76.8:4318"
COLLECTOR_GRPC_ENDPOINT = "10.164.76.8:4317"
REGISTRY_URL = "https://emms-registration-api-dev-rlaptra7zq-ue.a.run.app"
DEFAULT_MODEL_ID = "256c8edd-1abe-4ec3-9cc6-18a760be5718"
