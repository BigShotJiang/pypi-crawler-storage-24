"""PHI masking validation tests for GCP Cloud Logging.

Story 6.2 - Task 5: Verify no PHI reaches Cloud Logging unmasked.

The SDK implements automatic PHI masking as a defense-in-depth measure for common
patterns (SSN, MRN, DOB, phone, email, names, addresses). Applications should still
sanitize domain-specific PHI before logging, as regex-based masking cannot catch all
PHI patterns.
"""

import pytest
from unittest.mock import Mock, MagicMock, patch


class TestPHIMaskingValidation:
    """Validate PHI protection in GCP Cloud Logging exporter."""

    def test_exporter_does_not_log_credentials(self):
        """Test that credentials are not logged or exposed."""
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter

        mock_cloud_logging = MagicMock()
        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            mock_creds = Mock()
            mock_creds.__str__ = Mock(return_value="SENSITIVE_CREDENTIAL")

            exporter = CloudLoggingExporter(
                project_id="test-project", log_name="test-log", credentials=mock_creds
            )

            # Verify credentials object is stored but not logged
            assert exporter.credentials is mock_creds
            # The exporter should never call str() or repr() on credentials

    def test_exporter_passes_through_safe_data(self):
        """Test that exporter preserves safe (non-PHI) data.

        This test verifies that:
        1. The exporter does not add any PHI to logs
        2. Pre-sanitized/safe data is exported correctly
        3. The masking doesn't break normal logging
        """
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter
        from opentelemetry.sdk._logs.export import LogExportResult

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            # Create log record with pre-sanitized data
            log_record = Mock()
            log_record.body = Mock(value="Patient [REDACTED] admitted")
            log_record.severity_text = "INFO"
            log_record.attributes = {
                "patient_id": "hash_abc123",  # Pre-hashed by application
                "mrn": "[REDACTED]",  # Pre-masked by application
            }
            log_record.resource = Mock(attributes={"service.name": "test-service"})

            result = exporter.export([log_record])

            assert result == LogExportResult.SUCCESS

            # Verify the exported data matches user input (no SDK-added PHI)
            call_args = mock_logger.log_struct.call_args
            exported_data = call_args[0][0]

            assert exported_data["message"] == "Patient [REDACTED] admitted"
            assert exported_data["labels"]["patient_id"] == "hash_abc123"
            assert exported_data["labels"]["mrn"] == "[REDACTED]"

    def test_automatic_phi_masking_for_common_patterns(self):
        """Test that exporter automatically masks common PHI patterns.

        The SDK implements defense-in-depth PHI masking for common patterns.
        This provides a safety net if applications accidentally log PHI.
        """
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter
        from opentelemetry.sdk._logs.export import LogExportResult

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            # Application accidentally logs cleartext PHI
            log_record = Mock()
            log_record.body = Mock(value="Patient John Doe admitted with SSN 123-45-6789")
            log_record.severity_text = "INFO"
            log_record.attributes = {
                "ssn": "123-45-6789",
                "phone": "555-123-4567",
                "email": "patient@example.com",
            }
            log_record.resource = Mock(attributes={})

            result = exporter.export([log_record])

            assert result == LogExportResult.SUCCESS

            # Verify PHI was masked by the exporter
            call_args = mock_logger.log_struct.call_args
            exported_data = call_args[0][0]

            # Message should have PHI masked
            assert "[NAME-REDACTED]" in exported_data["message"]
            assert "[SSN-REDACTED]" in exported_data["message"]
            assert "John Doe" not in exported_data["message"]
            assert "123-45-6789" not in exported_data["message"]

            # Attributes should have PHI masked
            assert exported_data["labels"]["ssn"] == "[SSN-REDACTED]"
            assert exported_data["labels"]["phone"] == "[PHONE-REDACTED]"
            assert exported_data["labels"]["email"] == "[EMAIL-REDACTED]"

    def test_phi_masking_multiple_patterns(self):
        """Test that multiple PHI patterns are masked in a single log."""
        from mca_sdk.exporters.gcp_logging import CloudLoggingExporter
        from opentelemetry.sdk._logs.export import LogExportResult

        mock_cloud_logging = MagicMock()
        mock_client = Mock()
        mock_logger = Mock()
        mock_client.logger.return_value = mock_logger
        mock_cloud_logging.Client.return_value = mock_client

        with patch.dict("sys.modules", {"google.cloud.logging": mock_cloud_logging}):
            exporter = CloudLoggingExporter(project_id="test-project", log_name="test-log")

            # Log with multiple PHI patterns
            log_record = Mock()
            log_record.body = Mock(
                value="Contact John Doe at 555-123-4567 or john@example.com. DOB: 01/15/1980"
            )
            log_record.severity_text = "INFO"
            log_record.attributes = {}
            log_record.resource = Mock(attributes={})

            result = exporter.export([log_record])

            assert result == LogExportResult.SUCCESS

            call_args = mock_logger.log_struct.call_args
            exported_data = call_args[0][0]
            message = exported_data["message"]

            # All PHI patterns should be masked
            assert "[NAME-REDACTED]" in message
            assert "[PHONE-REDACTED]" in message
            assert "[EMAIL-REDACTED]" in message
            assert "[DATE-REDACTED]" in message

            # Original PHI should not be present
            assert "John Doe" not in message
            assert "555-123-4567" not in message
            assert "john@example.com" not in message
            assert "01/15/1980" not in message
