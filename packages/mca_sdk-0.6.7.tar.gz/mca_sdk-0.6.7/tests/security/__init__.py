"""Security testing module for MCA SDK."""
