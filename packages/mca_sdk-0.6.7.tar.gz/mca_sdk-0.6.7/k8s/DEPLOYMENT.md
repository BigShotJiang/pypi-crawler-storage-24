# OpenTelemetry Collector Deployment Guide

Reference deployment manifests for testing the MCA SDK with OpenTelemetry Collector on Kubernetes.

## ⚠️ Important: Scope of These Manifests

These manifests are **development and testing resources** for the MCA SDK repository. They are:

✅ **Suitable for:**
- Local SDK development
- Integration testing
- Demonstrating collector architecture
- Learning Kubernetes deployment patterns
- Testing SDK → Collector → Backends flow

❌ **NOT suitable for:**
- Production deployments
- HIPAA-compliant environments (missing compliance controls)
- Multi-tenant clusters (missing isolation)
- Enterprise production use (missing operational integration)

**For production deployments**, work with your infrastructure team who will provide:
- Terraform/Helm configurations with organization policies
- Proper secret management integration
- Monitoring/alerting setup
- Compliance controls
- Operational runbooks

## Purpose

These manifests help SDK developers and data scientists:
- Test SDK integrations with a real collector
- Understand collector architecture and configuration
- Run integration tests locally or in development clusters
- See a working example of SDK → Collector → Backends flow

## Quick Start (Development)

### Prerequisites

- Kubernetes 1.24+ (local cluster like kind/minikube, or GKE dev cluster)
- kubectl configured
- Helm 3.8+ (for Helm chart deployment, **recommended**)
- Namespace `monitoring` created

### Deploy

**Recommended: Using Helm Chart**

```bash
# Deploy with Helm (recommended approach)
cd mca-prototype
helm install mca-collector helm/mca-collector/ \
  --namespace monitoring \
  --create-namespace

# Verify deployment
helm status mca-collector -n monitoring
kubectl get pods -n monitoring -l app.kubernetes.io/name=mca-collector
```

See [../helm/mca-collector/README.md](../helm/mca-collector/README.md) for complete Helm chart documentation.

**Alternative: Using Kustomize**

```bash
# Create namespace
kubectl create namespace monitoring

# Deploy development configuration
kubectl apply -k mca-prototype/k8s/overlays/dev

# Verify deployment
kubectl get pods -n monitoring -l app=otel-collector
```

Expected output:
```
NAME               READY   STATUS    RESTARTS   AGE
otel-collector-0   1/1     Running   0          2m
otel-collector-1   1/1     Running   0          2m
otel-collector-2   1/1     Running   0          1m
```

### Test SDK Integration

```bash
# Get LoadBalancer/NodePort endpoint
kubectl get svc -n monitoring otel-collector-external

# Set endpoint in your model code
export MCA_OTEL_ENDPOINT="http://<EXTERNAL-IP>:4318"

# Run your instrumented model
python your_model.py

# Verify telemetry received
kubectl logs -n monitoring -l app=otel-collector --tail=50
```

## Architecture

```
MCA SDK → LoadBalancer → StatefulSet (3 replicas) → Exporters
                         ├─ otel-collector-0 (10Gi PVC)
                         ├─ otel-collector-1 (10Gi PVC)
                         └─ otel-collector-2 (10Gi PVC)
```

### Key Features

- **3 replicas** with pod anti-affinity for HA testing
- **Persistent queues** (10Gi PVC per pod) for resilience testing
- **HPA** (3-10 replicas) for load testing
- **Security hardening** (non-root, read-only filesystem, dropped capabilities)
- **Health checks** (liveness, readiness, startup probes)

## Manifests

| File | Description |
|------|-------------|
| [`base/statefulset.yaml`](base/statefulset.yaml) | 3 replicas, resource limits, security context |
| [`base/configmap.yaml`](base/configmap.yaml) | Base collector configuration |
| [`base/service.yaml`](base/service.yaml) | ClusterIP service for internal access |
| [`base/external-service.yaml`](base/external-service.yaml) | LoadBalancer for external SDK access |
| [`base/hpa.yaml`](base/hpa.yaml) | Autoscaler (3-10 replicas, CPU 70%, memory 80%) |
| [`base/pdb.yaml`](base/pdb.yaml) | Disruption budget (min 2 available) |
| [`overlays/dev/`](overlays/dev/) | Development config with debug exporter |
| [`overlays/prod/`](overlays/prod/) | Production-like config with GCP exporters |

## Configuration Overlays

### Development Overlay

**Purpose:** Local testing, SDK development, troubleshooting

**Features:**
- Debug exporter (logs all telemetry to stdout)
- Debug log level
- No GCP credentials required

**Deploy:**
```bash
kubectl apply -k mca-prototype/k8s/overlays/dev
```

### Production Overlay

**Purpose:** Reference implementation showing production exporters

**Features:**
- Prometheus, Cloud Logging, Cloud Trace, Langfuse exporters
- Requires GCP service account secret
- Info log level

**Note:** This is a **reference configuration**. Production deployments should be managed by your infrastructure team with organization-specific policies.

**Deploy (for testing only):**
```bash
# 1. Create secrets from template
cp mca-prototype/k8s/base/secret.yaml.example secret.yaml
# Edit secret.yaml with actual credentials (DO NOT COMMIT)
vi secret.yaml

# 2. Apply secret
kubectl apply -f secret.yaml -n monitoring

# 3. Deploy collector
kubectl apply -k mca-prototype/k8s/overlays/prod
```

## Testing

### Health Check

```bash
kubectl exec -n monitoring otel-collector-0 -- curl -s http://localhost:13133/
```

### Send Test Metrics

```bash
LB_IP=$(kubectl get svc -n monitoring otel-collector-external -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

curl -X POST http://${LB_IP}:4318/v1/metrics \
  -H "Content-Type: application/json" \
  -d '{"resourceMetrics":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"test"}}]},"scopeMetrics":[{"metrics":[{"name":"test.metric","gauge":{"dataPoints":[{"asDouble":42.0}]}}]}]}]}'
```

### Run Integration Tests

```bash
cd mca-prototype
pytest tests/integration/test_k8s_deployment.py -v
```

## Common Issues

**Pods stuck in Pending:**
- Check node capacity: `kubectl describe nodes`
- Check PVC status: `kubectl get pvc -n monitoring`

**Pods crashing:**
- Check logs: `kubectl logs -n monitoring otel-collector-0`
- Verify ConfigMap: `kubectl get configmap -n monitoring otel-collector-config -o yaml`

**No telemetry received:**
- Verify LoadBalancer IP: `kubectl get svc -n monitoring otel-collector-external`
- Test connectivity: `curl http://<LB-IP>:13133/`
- Check SDK endpoint: `echo $MCA_OTEL_ENDPOINT`

## Configuration Updates

To modify collector configuration:

```bash
# Edit the overlay patch
vi mca-prototype/k8s/overlays/dev/configmap-patch.yaml

# Apply changes
kubectl apply -k mca-prototype/k8s/overlays/dev

# Restart collectors (ConfigMap changes don't auto-restart)
kubectl rollout restart statefulset -n monitoring otel-collector
```

## Cleaning Up

```bash
# Delete collector resources
kubectl delete -k mca-prototype/k8s/overlays/dev

# Delete namespace (removes everything)
kubectl delete namespace monitoring
```

## Secret Management

### Development/Testing

**Option 1: Using secret.yaml.example template (recommended for local testing)**

```bash
# Copy the example template
cp mca-prototype/k8s/base/secret.yaml.example secret.yaml

# Edit with your credentials (DO NOT COMMIT)
vi secret.yaml

# Apply
kubectl apply -f secret.yaml -n monitoring
```

**Option 2: Using kubectl create secret (quick testing only)**

```bash
kubectl create secret generic otel-collector-secrets -n monitoring \
  --from-file=gcp-service-account.json=/path/to/sa.json \
  --from-literal=langfuse-public-key=pk-lf-your-key \
  --from-literal=langfuse-secret-key=sk-lf-your-secret \
  --from-literal=otlp-backend-endpoint=https://backend.example.com:4317
```

### Production

**DO NOT use kubectl create secret or commit secrets in production.**

Use proper secret management:

**External Secrets Operator (recommended):**
Sync from GCP Secret Manager, AWS Secrets Manager, or Vault

```yaml
apiVersion: external-secrets.io/v1beta1
kind: ExternalSecret
metadata:
  name: otel-collector-secrets
  namespace: monitoring
spec:
  refreshInterval: 1h
  secretStoreRef:
    name: gcp-secret-manager
    kind: SecretStore
  target:
    name: otel-collector-secrets
  data:
    - secretKey: gcp-service-account.json
      remoteRef:
        key: otel-collector-sa-key
    - secretKey: langfuse-public-key
      remoteRef:
        key: langfuse-public-key
    - secretKey: langfuse-secret-key
      remoteRef:
        key: langfuse-secret-key
```

**Sealed Secrets:**
Encrypt secrets for git storage

```bash
# Install sealed-secrets controller
kubectl apply -f https://github.com/bitnami-labs/sealed-secrets/releases/download/v0.18.0/controller.yaml

# Seal your secret
kubeseal -f secret.yaml -w sealed-secret.yaml

# Commit sealed-secret.yaml (safe to commit)
git add sealed-secret.yaml
```

**GCP Workload Identity (best for GKE):**
Avoid storing credentials entirely

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: otel-collector
  namespace: monitoring
  annotations:
    iam.gke.io/gcp-service-account: otel-collector@PROJECT_ID.iam.gserviceaccount.com
```

See your infrastructure team for secret management procedures.

## Security Considerations

### What This Configuration Provides

These manifests include several security hardening measures:

✅ **Container Security:**
- Non-root containers (UID 10001)
- Read-only root filesystem
- Dropped capabilities (ALL)
- Seccomp profile (RuntimeDefault)
- No privilege escalation

✅ **Network Security:**
- NetworkPolicy for ingress/egress filtering (base/networkpolicy.yaml)
- Restricts collector to only necessary ports
- Allows OTLP traffic from all namespaces (required for SDK access)
- Limits egress to DNS, HTTPS, and monitoring backends

✅ **Resource Management:**
- Memory limits prevent DoS via resource exhaustion
- CPU limits ensure fair scheduling
- Memory limiter processor prevents OOM

✅ **PHI Protection:**
- Attribute processor deletes sensitive HTTP headers
- Authorization, cookies, and custom PHI headers removed
- See configmap.yaml lines 31-40 for header deletion rules

### What's Missing for Production

These manifests are development/testing resources and lack several production security requirements:

❌ **Authentication & Encryption:**
- mTLS between SDK and collector (see Story 6-4 for implementation)
- Encryption at rest for persistent volumes
- Pod-to-pod encryption

❌ **Access Control:**
- Pod Security Standards/Policies enforcement
- RBAC for service accounts (currently minimal permissions)
- Admission controllers (OPA, Gatekeeper)

❌ **Audit & Compliance:**
- Audit logging integration
- SIEM integration
- Compliance controls (HIPAA audit trails, SOC2 evidence)
- Data retention policies

❌ **Secret Management:**
- Automatic secret rotation
- Secret access audit trails
- Workload Identity integration
- Secrets scanning in CI/CD

❌ **Monitoring & Detection:**
- Security monitoring integration
- Anomaly detection
- Intrusion detection system (IDS)
- Runtime security (Falco, etc.)

### Security Recommendations

**For Production Deployment:**

1. **Enable mTLS (Story 6-4)**
   - Implement mutual TLS for SDK ↔ Collector communication
   - Use cert-manager for certificate lifecycle
   - See `_bmad-output/implementation-artifacts/6-4-implement-mtls-for-sdk-to-collector-communication.md`

2. **Apply Organization NetworkPolicies**
   - Refine namespace selectors for your environment
   - Add egress filtering for specific backend IPs
   - Deny all traffic by default, allow explicitly

3. **Use Workload Identity Instead of Service Account Keys**
   - Eliminate credential files entirely
   - Automatic credential rotation
   - Reduced attack surface

4. **Enable Audit Logging**
   - Log all secret access
   - Log configuration changes
   - Log authentication events
   - Integrate with SIEM

5. **Scan Images for Vulnerabilities**
   - Use Trivy, Grype, or similar in CI/CD
   - Block high/critical vulnerabilities
   - Regularly update base images
   - See "Vulnerability Scanning" section in README.md

6. **Apply Pod Security Standards**
   - Enforce restricted profile at namespace level
   - Use admission controllers to prevent misconfigurations
   - See https://kubernetes.io/docs/concepts/security/pod-security-standards/

### Testing Security Configuration

```bash
# Verify non-root user
kubectl exec -n monitoring otel-collector-0 -- id
# Should show: uid=10001 gid=10001

# Verify read-only root filesystem
kubectl exec -n monitoring otel-collector-0 -- touch /test
# Should fail: Read-only file system

# Verify NetworkPolicy applied
kubectl get networkpolicy -n monitoring otel-collector -o yaml

# Verify no privileged containers
kubectl get pod -n monitoring otel-collector-0 -o jsonpath='{.spec.containers[*].securityContext}'
```

## Production Deployment

**These manifests are for development and testing only.**

For production deployments, your infrastructure team should provide:

### Infrastructure as Code
- Terraform or Helm configurations with organization policies
- Multi-region deployment for disaster recovery
- Proper capacity planning and resource sizing

### Security
- mTLS between SDK and collector
- Pod Security Standards enforcement
- NetworkPolicies specific to your environment
- Vulnerability scanning in CI/CD
- Secret management integration (External Secrets, Vault)
- Workload Identity or IRSA

### Monitoring & Operations
- Prometheus scraping configuration
- Grafana dashboards
- Alertmanager rules and PagerDuty integration
- SLOs and error budgets
- Runbooks for common incidents
- Backup and restore procedures

### Compliance
- HIPAA audit logging
- SOC2 evidence collection
- Data retention and deletion policies
- Encryption at rest and in transit
- Business Associate Agreement (BAA) coverage

Contact your infrastructure team or see your organization's infrastructure repository for production deployment procedures.

## References

- [OpenTelemetry Collector Documentation](https://opentelemetry.io/docs/collector/)
- [MCA SDK Examples](../sdk-examples/) - SDK usage examples
- [Exporter Configuration](../../docs/exporter-configuration.md) - Exporter setup guide
- [Story 4-8 Implementation](../../_bmad-output/implementation-artifacts/4-8-implement-multi-instance-collector-support-ha-ready.md) - Multi-instance collector context
