# OpenTelemetry Collector Kubernetes Deployment

This directory contains the Kubernetes manifests for deploying the OpenTelemetry Collector in a high-availability configuration.

## ⚠️ Important: Development Resources

These Kubernetes manifests are **development and testing resources** for the MCA SDK. They demonstrate collector deployment architecture and support SDK integration testing.

**For production deployments**, consult your infrastructure team for:
- Organization-specific Terraform/Helm configurations
- Security policies and compliance controls
- Production secret management
- Monitoring/alerting integration
- Operational runbooks

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed information about the scope and limitations of these manifests.

## 📚 Documentation

- **[DEPLOYMENT.md](DEPLOYMENT.md)** - Comprehensive deployment guide with architecture, troubleshooting, and production checklist
- **[Exporter Configuration](../docs/exporter-configuration.md)** - Guide for configuring exporters (debug, GCP, Prometheus, etc.)
- **[Integration Tests](../tests/integration/test_k8s_deployment.py)** - Automated test suite for HA deployment

## Quick Start

### Prerequisites

- Kubernetes 1.24+
- kubectl configured
- Kustomize installed (or use `kubectl kustomize`)
- Namespace `monitoring` created

### Deploy

This project uses a Kustomize-based approach with overlays for different environments.

**Development Deployment (with debug exporter):**
```bash
# Create namespace
kubectl create namespace monitoring

# Deploy 'dev' overlay
kubectl apply -k mca-prototype/k8s/overlays/dev

# Verify deployment
kubectl get statefulset -n monitoring otel-collector
kubectl get pods -n monitoring -l app=otel-collector
```

**Production Deployment:**
```bash
# Create namespace
kubectl create namespace monitoring

# Deploy 'prod' overlay
kubectl apply -k mca-prototype/k8s/overlays/prod
```

### Verify

```bash
# Check health
kubectl exec -n monitoring otel-collector-0 -- curl -s http://localhost:13133/

# Send test telemetry
kubectl run -n monitoring test-client --rm -it --image=curlimages/curl --restart=Never -- \
  curl -X POST http://otel-collector-external:4318/v1/metrics \
  -H "Content-Type: application/json" \
  -d '{"resourceMetrics":[{"resource":{"attributes":[{"key":"service.name","value":{"stringValue":"test"}}]},"scopeMetrics":[{"metrics":[{"name":"test.metric","gauge":{"dataPoints":[{"asDouble":1.0}]}}]}]}]}'
```

## Manifests

The base manifests are located in [`mca-prototype/k8s/base`](base/). Overlays for `dev` and `prod` environments are in [`mca-prototype/k8s/overlays`](overlays/).

| File | Description |
|------|-------------|
| [`storageclass.yaml`](base/storageclass.yaml) | Encrypted SSD storage with GCP KMS for persistent queues |
| [`serviceaccount.yaml`](base/serviceaccount.yaml) | ServiceAccount with minimal RBAC permissions |
| [`configmap.yaml`](base/configmap.yaml) | Collector configuration (receivers, processors, exporters) |
| [`headless-service.yaml`](base/headless-service.yaml) | Headless service for StatefulSet pod discovery |
| [`service.yaml`](base/service.yaml) | ClusterIP service for internal access |
| [`external-service.yaml`](base/external-service.yaml) | LoadBalancer service for external model containers |
| [`statefulset.yaml`](base/statefulset.yaml) | StatefulSet with 3 replicas, persistent storage, security |
| [`hpa.yaml`](base/hpa.yaml) | Horizontal Pod Autoscaler (3-10 replicas, 70% CPU, 5-min scale-down) |
| [`pdb.yaml`](base/pdb.yaml) | Pod Disruption Budget (min 2 available) |
| [`pubsub/`](pubsub/) | Dead Letter Queue (DLQ) scripts and documentation |

## High Availability Features (Story 4-10)

This deployment includes production-grade HA features:

### 1. Horizontal Pod Autoscaler (HPA)
- **Auto-scaling**: 3-10 replicas based on CPU (70%) and memory (80%)
- **Fast scale-up**: Immediate response to load spikes (double capacity or +2 pods)
- **Gradual scale-down**: 5-minute stabilization window to prevent flapping
- **Cost optimization**: Scales down to minimum 3 replicas during low load

### 2. Persistent Volumes with Encryption
- **Data persistence**: 10Gi SSD per pod for queue storage
- **Encryption at rest**: GCP KMS customer-managed keys (CMEK)
- **Crash recovery**: Queue data survives pod restarts and evictions
- **HIPAA compliance**: Encrypted storage meets regulatory requirements

### 3. Dead Letter Queue (DLQ)
- **No data loss**: Failed exports after max retries go to GCP Pub/Sub DLQ
- **Investigation**: DLQ messages include error reason and timestamp
- **Replay mechanism**: Python script to reprocess DLQ messages after issues resolved
- **Monitoring**: Alert on DLQ messages for on-call response

See [`pubsub/README.md`](pubsub/README.md) for DLQ setup and usage.

### 4. Resilience Features
- **Persistent queue**: File-backed queue survives collector restarts
- **Retry logic**: Exponential backoff (1s → 30s, max 5 minutes)
- **Circuit breaker**: Prevents cascading failures to backends
- **Graceful termination**: 30s grace period for queue drainage

### Testing HA Features
```bash
# Run HA integration tests
pytest tests/integration/test_ha_features.py -v -m integration

# Test HPA scaling manually
kubectl run load-generator -n monitoring --image=busybox --restart=Never -- \
  /bin/sh -c 'while true; do wget -q -O- http://otel-collector-external:4318/v1/metrics; done'

# Watch HPA scale-up
kubectl get hpa -n monitoring otel-collector-hpa --watch

# Test persistent volume recovery
kubectl delete pod -n monitoring otel-collector-0
kubectl wait --for=condition=ready pod/otel-collector-0 -n monitoring --timeout=120s
```

## Architecture

```
Model Containers → LoadBalancer → StatefulSet (3 replicas) → GCP Backends
                                   ├─ otel-collector-0 (10Gi SSD)
                                   ├─ otel-collector-1 (10Gi SSD)
                                   └─ otel-collector-2 (10Gi SSD)
```

## Configuration Management

### Kustomize Overlay Strategy

This deployment uses **strategic merge patches** to manage environment-specific configurations. Due to Kustomize limitations, ConfigMap data fields (which are opaque strings) cannot be partially patched using JSON Patch operations. Therefore, each overlay contains a complete `configmap-patch.yaml` file that includes the full configuration.

**Structure:**
```
k8s/
├── base/
│   ├── configmap.yaml          # Base configuration (shared settings)
│   ├── kustomization.yaml      # Base resources
│   └── ...
├── overlays/
│   ├── dev/
│   │   ├── kustomization.yaml  # Uses 'patches' directive
│   │   └── configmap-patch.yaml # Complete config with debug exporter
│   └── prod/
│       ├── kustomization.yaml  # Uses 'patches' directive
│       └── configmap-patch.yaml # Complete config with GCP exporters
```

### Important: Configuration Synchronization

**CRITICAL:** When modifying the base configuration in [`base/configmap.yaml`](base/configmap.yaml:1), you **MUST** manually propagate changes to both overlay patch files:
- [`overlays/dev/configmap-patch.yaml`](overlays/dev/configmap-patch.yaml:1)
- [`overlays/prod/configmap-patch.yaml`](overlays/prod/configmap-patch.yaml:1)

This is a known limitation of Kustomize when working with ConfigMap string values. The overlay patches use Strategic Merge which replaces the entire `config.yaml` data field. While this requires duplication, it ensures:
- **Explicit configuration**: Each environment's config is self-contained and reviewable
- **No hidden inheritance**: What you see in the patch file is exactly what gets deployed
- **Maintainability**: Changes to shared settings are visible in all environments

### Environment-Specific Differences

**Development overlay** ([`overlays/dev/`](overlays/dev/)):
- Uses `debug` exporter with detailed verbosity
- Sets `environment: development` attribute
- Enables debug-level logging (`level: debug`)
- Suitable for local testing and troubleshooting

**Production overlay** ([`overlays/prod/`](overlays/prod/)):
- Uses production exporters:
  - `prometheus` - Prometheus for metrics
  - `googlecloud/logs` - Cloud Logging for logs
  - `googlecloud/trace` - Cloud Trace for distributed traces
  - `langfuse` - Langfuse for LLM observability
- Sets `environment: production` attribute
- Enables info-level logging (`level: info`)
- Configures production project ID: `bhsf-model-monitoring-prod`
- Includes retry logic and persistent queues for all exporters

### Updating Configuration

To update the configuration:

```bash
# 1. Edit the base configuration (if changing shared settings)
vi mca-prototype/k8s/base/configmap.yaml

# 2. Propagate changes to BOTH overlay patches
vi mca-prototype/k8s/overlays/dev/configmap-patch.yaml
vi mca-prototype/k8s/overlays/prod/configmap-patch.yaml

# 3. Test the build
kubectl kustomize mca-prototype/k8s/overlays/dev
kubectl kustomize mca-prototype/k8s/overlays/prod

# 4. Apply changes to the desired environment
kubectl apply -k mca-prototype/k8s/overlays/prod

# 5. Rolling restart (if ConfigMap changed)
kubectl rollout restart statefulset -n monitoring otel-collector

# 6. Monitor rollout
kubectl rollout status statefulset -n monitoring otel-collector
```

### Recommended: Helm Charts

**For simplified deployment and configuration management, use the Helm chart** (Story 6-21 completed):

```bash
# Install with default development configuration
helm install mca-collector ../helm/mca-collector/ --namespace monitoring --create-namespace

# Install with production configuration
helm install mca-collector ../helm/mca-collector/ \
  --values ../helm/mca-collector/values-prod.yaml \
  --namespace monitoring --create-namespace
```

See [../helm/mca-collector/README.md](../helm/mca-collector/README.md) for complete Helm chart documentation.

The Helm chart provides:
- True parameterized configuration (no duplication)
- Environment-specific values files (dev, staging, prod)
- Simplified upgrades and rollbacks
- Built-in validation and linting

## Vulnerability Scanning

It is mandatory to scan the `otel/opentelemetry-collector-contrib:0.146.1` image for known vulnerabilities as part of the CI/CD pipeline before any deployment. Use tools like Trivy or Grype to automate this process.

Example with Trivy:
```bash
trivy image otel/opentelemetry-collector-contrib:0.146.1
```

For production deployments, block deployment if high or critical vulnerabilities are found:
```bash
trivy image --severity HIGH,CRITICAL --exit-code 1 otel/opentelemetry-collector-contrib:0.146.1
```

## Testing

Run the integration test suite:

```bash
cd mca-prototype
./tests/integration/run_k8s_tests.sh
```

Tests verify:
- StatefulSet deployment (3 replicas, stable names, node distribution)
- Persistent storage (PVC provisioning, writability)
- Health checks (endpoints, probes)
- Services (headless, ClusterIP, LoadBalancer)
- Telemetry flow (OTLP HTTP/gRPC)
- Failover (pod deletion recovery, PDB)
- Security (non-root, read-only filesystem)
- Resource management (memory/CPU limits, HPA)

## Troubleshooting

See [DEPLOYMENT.md](DEPLOYMENT.md#troubleshooting) for detailed troubleshooting guide.

**Common issues:**

- **Pods stuck in Pending**: Check node capacity, PVC provisioning, anti-affinity constraints
- **Pods crashing**: Check ConfigMap syntax, memory limits, logs
- **Health check failures**: Check collector startup, extension configuration
- **No telemetry received**: Check LoadBalancer IP, firewall rules, SDK endpoint

**Health Check Limitations:**

The liveness and readiness probes check `http://localhost:13133/` which validates that the health_check extension is running. However, this does NOT verify:
- Pipeline is actively processing data
- Exporters are successfully sending data to backends
- Queue is not stuck or full
- Backend connections are healthy

For production monitoring, supplement with:
- Collector self-monitoring metrics (port 8888)
- Prometheus alerts on queue depth, exporter failures, and dropped spans
- End-to-end synthetic tests that verify telemetry reaches backends

## References

- [OpenTelemetry Collector Documentation](https://opentelemetry.io/docs/collector/)
- [Kustomize Documentation](https://kustomize.io/)
- [Kustomize ConfigMap Limitations](https://github.com/kubernetes-sigs/kustomize/issues/1256)
- [GKE StatefulSet Best Practices](https://cloud.google.com/kubernetes-engine/docs/concepts/statefulset)
- [Story 4-8 Implementation](../../_bmad-output/implementation-artifacts/4-8-implement-multi-instance-collector-support-ha-ready.md)
