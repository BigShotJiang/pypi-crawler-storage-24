#!/usr/bin/env bash
# Create GCP Pub/Sub Dead Letter Queue for OTel Collector
# Handles permanently failed telemetry exports for investigation and replay
set -euo pipefail

PROJECT_ID="${GCP_PROJECT_ID:-bhsf-model-monitoring-prod}"
DLQ_TOPIC="${DLQ_TOPIC_NAME:-otel-collector-dlq}"
DLQ_SUBSCRIPTION="${DLQ_SUBSCRIPTION_NAME:-otel-collector-dlq-sub}"
REGION="${GCP_REGION:-us-central1}"
# Service account - configurable to support different naming conventions
COLLECTOR_SA="${COLLECTOR_SERVICE_ACCOUNT:-otel-collector@${PROJECT_ID}.iam.gserviceaccount.com}"

echo "Creating Dead Letter Queue infrastructure..."
echo "Project: ${PROJECT_ID}"
echo "Topic: ${DLQ_TOPIC}"
echo "Subscription: ${DLQ_SUBSCRIPTION}"
echo "Service Account: ${COLLECTOR_SA}"

# Create DLQ topic
echo "Creating Pub/Sub topic..."
gcloud pubsub topics create "${DLQ_TOPIC}" \
  --project="${PROJECT_ID}" \
  --message-retention-duration=7d \
  --labels=component=otel-collector,purpose=dlq,environment=production \
  || echo "Topic ${DLQ_TOPIC} already exists"

# Create DLQ subscription
echo "Creating Pub/Sub subscription..."
gcloud pubsub subscriptions create "${DLQ_SUBSCRIPTION}" \
  --topic="${DLQ_TOPIC}" \
  --project="${PROJECT_ID}" \
  --ack-deadline=60 \
  --message-retention-duration=7d \
  --expiration-period=never \
  || echo "Subscription ${DLQ_SUBSCRIPTION} already exists"

# Grant Collector service account permission to publish to DLQ
echo "Granting ${COLLECTOR_SA} permission to publish to DLQ..."
gcloud pubsub topics add-iam-policy-binding "${DLQ_TOPIC}" \
  --project="${PROJECT_ID}" \
  --member="serviceAccount:${COLLECTOR_SA}" \
  --role="roles/pubsub.publisher"

echo ""
echo "✅ Dead Letter Queue created successfully!"
echo ""
echo "Topic: projects/${PROJECT_ID}/topics/${DLQ_TOPIC}"
echo "Subscription: projects/${PROJECT_ID}/subscriptions/${DLQ_SUBSCRIPTION}"
echo ""
echo "Next steps:"
echo "1. Configure OTel Collector exporters to use DLQ (see configmap-patch.yaml)"
echo "2. Set up monitoring alerts for DLQ messages"
echo "3. Use dlq-replay-processor.py to replay messages after issues are resolved"
