#!/usr/bin/env python3
"""
Replay messages from Dead Letter Queue to OTel Collector

This script pulls failed telemetry from the DLQ Pub/Sub topic and replays
it to the Collector's OTLP endpoint after issues have been resolved.

Usage:
    python dlq-replay-processor.py --project PROJECT_ID --subscription DLQ_SUB --collector-url http://otel-collector:4318

Environment Variables:
    GCP_PROJECT_ID: GCP project ID (default: bhsf-model-monitoring-prod)
    DLQ_SUBSCRIPTION: DLQ subscription name (default: otel-collector-dlq-sub)
    COLLECTOR_ENDPOINT: OTel Collector OTLP endpoint (default: http://otel-collector:4318)
"""
import argparse
import json
import logging
import os
import sys
import time
from typing import Dict, Any

try:
    from google.cloud import pubsub_v1
    import requests
except ImportError:
    print("ERROR: Missing dependencies. Install with:")
    print("  pip install google-cloud-pubsub requests")
    sys.exit(1)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s'
)
logger = logging.getLogger(__name__)


class DLQReplayProcessor:
    """Replays DLQ messages to OTel Collector"""

    def __init__(self, project_id: str, subscription_id: str, collector_endpoint: str):
        self.project_id = project_id
        self.subscription_id = subscription_id
        self.collector_endpoint = collector_endpoint
        self.subscriber = pubsub_v1.SubscriberClient()
        self.subscription_path = self.subscriber.subscription_path(project_id, subscription_id)

        # Statistics
        self.stats = {
            "received": 0,
            "replayed_success": 0,
            "replayed_failure": 0,
            "parse_errors": 0
        }

    def _parse_dlq_message(self, message: pubsub_v1.subscriber.message.Message) -> Dict[str, Any]:
        """Parse DLQ message and extract telemetry data.

        Handles both custom JSON wrapper format and native OTLP payloads (JSON or Protobuf).
        """
        attributes = message.attributes

        # Try to detect format from attributes or content
        is_json = False
        is_protobuf = False
        signal_type = attributes.get("signal_type", "metrics")

        # Attempt JSON parsing first
        try:
            data = json.loads(message.data.decode('utf-8'))
            is_json = True

            # Check if it's wrapped format (custom) or native OTLP JSON
            if "telemetry" in data and "error_reason" in data:
                # Custom wrapper format
                return {
                    "telemetry": data.get("telemetry"),
                    "error_reason": data.get("error_reason"),
                    "failed_at": data.get("failed_at"),
                    "signal_type": data.get("signal_type", signal_type),
                    "original_endpoint": data.get("original_endpoint"),
                    "format": "json",
                    "is_wrapped": True
                }
            else:
                # Native OTLP JSON format
                return {
                    "telemetry": data,
                    "error_reason": attributes.get("error_reason", "Unknown"),
                    "failed_at": attributes.get("failed_at", "Unknown"),
                    "signal_type": signal_type,
                    "original_endpoint": attributes.get("original_endpoint"),
                    "format": "json",
                    "is_wrapped": False
                }
        except (json.JSONDecodeError, UnicodeDecodeError):
            # Not JSON, assume Protobuf
            is_protobuf = True
            return {
                "telemetry": message.data,  # Raw bytes
                "error_reason": attributes.get("error_reason", "Unknown"),
                "failed_at": attributes.get("failed_at", "Unknown"),
                "signal_type": signal_type,
                "original_endpoint": attributes.get("original_endpoint"),
                "format": "protobuf",
                "is_wrapped": False
            }

    def _replay_to_collector(self, parsed_data: Dict[str, Any]) -> bool:
        """Resend telemetry to OTel Collector with correct content type."""
        signal_type = parsed_data["signal_type"]
        telemetry = parsed_data["telemetry"]
        data_format = parsed_data["format"]

        # Map signal type to OTLP endpoint
        endpoint_map = {
            "metrics": f"{self.collector_endpoint}/v1/metrics",
            "logs": f"{self.collector_endpoint}/v1/logs",
            "traces": f"{self.collector_endpoint}/v1/traces"
        }

        endpoint = endpoint_map.get(signal_type, f"{self.collector_endpoint}/v1/metrics")

        try:
            # Set appropriate headers and data based on format
            if data_format == "json":
                response = requests.post(
                    endpoint,
                    json=telemetry,
                    headers={"Content-Type": "application/json"},
                    timeout=10
                )
            else:  # protobuf
                response = requests.post(
                    endpoint,
                    data=telemetry,
                    headers={"Content-Type": "application/x-protobuf"},
                    timeout=10
                )

            if response.status_code in (200, 202):
                logger.info(f"✅ Successfully replayed {signal_type} ({data_format}) to {endpoint}")
                return True
            else:
                logger.error(f"❌ Failed to replay {signal_type}: HTTP {response.status_code} - {response.text}")
                return False

        except requests.RequestException as e:
            logger.error(f"❌ Network error replaying {signal_type}: {e}")
            return False

    def _message_callback(self, message: pubsub_v1.subscriber.message.Message):
        """Process each DLQ message"""
        self.stats["received"] += 1
        logger.info(f"Processing message {message.message_id} (#{self.stats['received']})")

        try:
            # Parse DLQ message
            parsed = self._parse_dlq_message(message)
            signal_type = parsed["signal_type"]
            error_reason = parsed["error_reason"]
            failed_at = parsed["failed_at"]
            data_format = parsed["format"]

            logger.info(f"  Signal: {signal_type}")
            logger.info(f"  Format: {data_format}")
            logger.info(f"  Error: {error_reason}")
            logger.info(f"  Failed At: {failed_at}")

            # Replay to Collector
            if self._replay_to_collector(parsed):
                self.stats["replayed_success"] += 1
                message.ack()
                logger.info(f"  ✅ Message {message.message_id} acknowledged")
            else:
                self.stats["replayed_failure"] += 1
                message.nack()
                logger.warning(f"  ❌ Message {message.message_id} not acknowledged (will retry)")

        except Exception as e:
            logger.error(f"❌ Error processing message {message.message_id}: {e}")
            self.stats["replayed_failure"] += 1
            message.nack()

    def run(self):
        """Start listening for DLQ messages"""
        logger.info("=" * 80)
        logger.info("DLQ Replay Processor Starting")
        logger.info(f"  Project: {self.project_id}")
        logger.info(f"  Subscription: {self.subscription_id}")
        logger.info(f"  Collector: {self.collector_endpoint}")
        logger.info("=" * 80)

        streaming_pull_future = self.subscriber.subscribe(
            self.subscription_path,
            callback=self._message_callback
        )

        logger.info(f"Listening for messages on {self.subscription_path}...")
        logger.info("Press Ctrl+C to stop")

        try:
            streaming_pull_future.result()
        except KeyboardInterrupt:
            logger.info("\n🛑 Stopping DLQ replay processor...")
            streaming_pull_future.cancel()
            streaming_pull_future.result()  # Wait for cancellation

        # Print statistics
        logger.info("=" * 80)
        logger.info("DLQ Replay Statistics:")
        logger.info(f"  Messages Received:    {self.stats['received']}")
        logger.info(f"  Successfully Replayed: {self.stats['replayed_success']}")
        logger.info(f"  Failed to Replay:     {self.stats['replayed_failure']}")
        logger.info(f"  Parse Errors:         {self.stats['parse_errors']}")
        logger.info("=" * 80)


def main():
    parser = argparse.ArgumentParser(description="Replay DLQ messages to OTel Collector")
    parser.add_argument(
        "--project",
        default=os.getenv("GCP_PROJECT_ID", "bhsf-model-monitoring-prod"),
        help="GCP project ID"
    )
    parser.add_argument(
        "--subscription",
        default=os.getenv("DLQ_SUBSCRIPTION", "otel-collector-dlq-sub"),
        help="DLQ subscription name"
    )
    parser.add_argument(
        "--collector-url",
        default=os.getenv("COLLECTOR_ENDPOINT", "http://otel-collector:4318"),
        help="OTel Collector OTLP endpoint"
    )

    args = parser.parse_args()

    processor = DLQReplayProcessor(
        project_id=args.project,
        subscription_id=args.subscription,
        collector_endpoint=args.collector_url
    )

    processor.run()


if __name__ == "__main__":
    main()
