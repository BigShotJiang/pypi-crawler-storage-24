# Deploying Collector with Prometheus Pull Model

This guide explains the OTel Collector configuration for Prometheus metrics using the pull model.

## Architecture

```
SDK → OTel Collector (OTLP :4318) → Prometheus Endpoint (:8889)
                                     ↑
                              Prometheus scrapes here
```

## Deployment Steps

### 1. Apply Configuration

```bash
# Apply the updated configmap
kubectl apply -k k8s/overlays/dev/

# Restart collector to pick up changes
kubectl rollout restart statefulset/otel-collector -n monitoring

# Verify collector is running
kubectl get pods -n monitoring
kubectl logs -f statefulset/otel-collector -n monitoring
```

### 2. Verify Prometheus Endpoint

Test the collector's Prometheus endpoint:

```bash
# From within the cluster
curl http://otel-collector.monitoring.svc.cluster.local:8889/metrics

# From outside (if accessible)
curl http://10.164.76.8:8889/metrics
```

Look for SDK metrics with `emms_genai_` prefix.

### 3. Configure Prometheus Scraping

Add scrape config to your Prometheus server:

```yaml
scrape_configs:
  - job_name: 'mca-otel-collector'
    scrape_interval: 15s
    static_configs:
      - targets:
          - '10.164.76.8:8889'
```

## Architecture

```
SDK → OTel Collector → Cloud Logging
                   ├─→ Cloud Trace
                   └─→ Prometheus Endpoint (:8889) ← Prometheus scrapes
```

### Metrics Pipeline

1. **SDK** sends metrics via OTLP HTTP to collector (port 4318)
2. **Collector** processes metrics and exports to:
   - **Local Prometheus endpoint** (:8889) - for Prometheus to scrape
   - **Debug logs** - for troubleshooting
3. **Prometheus** scrapes metrics from collector endpoint

## Configuration Details

### Exporter Configuration

**Local Prometheus Scrape** (port 8889):
```yaml
prometheus:
  endpoint: "0.0.0.0:8889"
  namespace: mca
```


### Metric Naming

Metrics exported to GCP Managed Prometheus (namespace: `emms`):

**SDK GenAI Metrics (from MCA SDK):**
- `emms_genai_requests_total` - Total GenAI requests
- `emms_genai_latency_seconds` - GenAI request latency
- `emms_genai_tokens_total` - Token usage counts
- `emms_genai_cost_dollars` - GenAI costs in USD

In GCP, they appear as:
```
prometheus.googleapis.com/emms_genai_requests_total
prometheus.googleapis.com/emms_genai_latency_seconds
prometheus.googleapis.com/emms_genai_tokens_total
prometheus.googleapis.com/emms_genai_cost_dollars
```

**Note:** Other metrics with `emms_` prefix (model_predictions_total, drift_refresh_total, evidently_up, etc.) come from different monitoring services and are not related to the MCA SDK.

## Troubleshooting

### Issue: Cannot access :8889/metrics endpoint

**Cause**: Port 8889 is blocked by firewall or not exposed

**Fix**:
```bash
# Verify collector is exposing the endpoint
kubectl get svc otel-collector -n monitoring

# Port-forward for testing
kubectl port-forward -n monitoring svc/otel-collector 8889:8889

# Test locally
curl http://localhost:8889/metrics
```

### Issue: No metrics at endpoint

**Cause**: Prometheus exporter not configured or no data received

**Debug**:
```bash
# Check collector logs
kubectl logs statefulset/otel-collector -n monitoring | grep -i "prometheus\|error"

# Verify SDK is sending telemetry
kubectl logs statefulset/otel-collector -n monitoring | grep -i "otlp"
```

## Security Notes

1. **Network Access**: Prometheus endpoint (:8889) should only be accessible to Prometheus server
2. **No Authentication**: Prometheus pull endpoint has no built-in auth (use NetworkPolicies)
3. **TLS**: Consider enabling TLS for the Prometheus endpoint in production

## References

- [OTel Prometheus Exporter](https://github.com/open-telemetry/opentelemetry-collector-contrib/tree/main/exporter/prometheusexporter)
- [Prometheus Scraping](https://prometheus.io/docs/prometheus/latest/configuration/configuration/#scrape_config)
- [OTel Collector Configuration](https://opentelemetry.io/docs/collector/configuration/)
