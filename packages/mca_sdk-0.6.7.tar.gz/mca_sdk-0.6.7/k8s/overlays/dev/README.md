# Development Overlay

**Purpose:** Local development and testing of the MCA SDK with OTel Collector.

**NOT for production use.**

## Configuration

- **Replicas:** 3 (can be reduced to 1 for local testing)
- **Exporter:** Debug (logs to stdout)
- **Log Level:** Debug
- **Environment:** development
- **Region:** us-central1

## What This Overlay Does

This overlay patches the base configuration to add:
- Debug exporter for easy troubleshooting
- Development environment attributes
- Debug-level logging for detailed output

## Usage

```bash
# Deploy to local/development cluster
kubectl apply -k mca-prototype/k8s/overlays/dev

# Verify deployment
kubectl get pods -n monitoring -l app=otel-collector

# View telemetry output (debug exporter logs to stdout)
kubectl logs -n monitoring -l app=otel-collector --tail=50
```

## Testing SDK Integration

This overlay is designed for:
- Testing SDK instrumentation locally
- Debugging telemetry flow
- Verifying collector configuration
- Running integration tests

## Example: Test with SDK

```bash
# Get collector endpoint
COLLECTOR_IP=$(kubectl get svc -n monitoring otel-collector-external -o jsonpath='{.status.loadBalancer.ingress[0].ip}')

# Set SDK environment
export MCA_OTEL_ENDPOINT="http://${COLLECTOR_IP}:4318"

# Run instrumented model
python sdk-examples/internal-model/instrumented_model.py

# Check logs for telemetry
kubectl logs -n monitoring otel-collector-0 --tail=100
```

## Reducing Replicas for Local Testing

For local Minikube/kind clusters with limited resources:

```bash
# Create patch to reduce replicas
cat <<EOF > local-patch.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: otel-collector
spec:
  replicas: 1
EOF

# Deploy with local patch
kubectl apply -k mca-prototype/k8s/overlays/dev
kubectl patch statefulset -n monitoring otel-collector --patch-file local-patch.yaml
```
