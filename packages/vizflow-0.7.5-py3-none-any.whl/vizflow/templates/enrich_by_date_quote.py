#!/usr/bin/env python
"""Template: Enrich one date with quote-based forward merge -> Delta Lake.

Pipeline (stays lazy until merge_forward):
  scan_trade -> parse_time                            (lazy)
  scan_quote -> parse_time                            (lazy)
  merge_forward(trade, quote, ref_cols, horizons)     (collect here)
  base/forward split -> Delta Lake

Uses real tick-by-tick quote data (stock_sorted_t5ob FST) as the reference
source for merge_forward, instead of downsampled alpha. This gives denser
price snapshots and more accurate forward markouts.

Trade schema: eric_v20260205 (feather, fill_qty is per-fill incremental)
Quote schema: stock_sorted_t5ob (FST, prices stored as px * 10000)

Forward table format: semi-wide (one row per trade × horizon).
  Each ref_col is a separate column with its native type (no melt).
  Partition: [data_date, horizon_ms]

Delta Lake write strategy:
  - Partition-level overwrite via predicate (concurrent-safe, idempotent)
  - Incremental: auto-detects missing horizons, only computes what's needed
  - Use --force to reprocess even if complete

To use this template:
  1. Copy: vf.templates.copy_template("enrich_by_date_quote.py", "my_enrich.py")
  2. Edit CONFIG section with your data paths
  3. Edit FORWARD MERGE CONFIG with your horizons and ref_cols
  4. Run: python my_enrich.py --date 20240827

Adding new horizons: append to HORIZONS list, re-run — only new horizons
are computed. Adding new ref_cols: append to REF_COLS list, re-run with
--force (schema change requires full reprocess for affected dates).

Output: enriched/base/ and enriched/forward/ (Delta Lake)

Requires: pip install deltalake vizflow[fst]
"""
from __future__ import annotations

import argparse
from collections.abc import Sequence
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    from deltalake import DeltaTable, write_deltalake
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG — edit for your environment
# ═══════════════════════════════════════════════════════════════
TRADE_DIR = Path("/cpfs/user2/ylu/projects/.../data/ordlog13/sc_8")
TRADE_PATTERN = "{date}_orders.feather"
TRADE_SCHEMA = "eric_v20260205"

QUOTE_DIR = Path("/gpfs/.../stock_sorted_t5ob")
QUOTE_PATTERN = "{date}.fst"
QUOTE_SCHEMA = "stock_sorted_t5ob"

OUTPUT_DIR = Path("./enriched")
MARKET = "CN"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG — edit for your analysis
# ═══════════════════════════════════════════════════════════════
HORIZONS = [-10, -5, -1, 0, 1, 5, 10, 30, 60, 120, 180, 300, 600, 1200, 1800, 2400, 3600]
REF_COLS = ["bid_px0", "ask_px0", "bid_size0", "ask_size0"]

TRADE_TIME_COL = "update_exchange_ts"
CREATE_TIME_COL = "create_exchange_ts"
QUOTE_TIME_COL = "ticktime"


# ═══════════════════════════════════════════════════════════════
# DELTA LAKE HELPERS
# ═══════════════════════════════════════════════════════════════
def _missing_horizons(
    forward_path: str,
    date_iso: str,
    horizons: Sequence[float],
) -> list[float]:
    """Return horizons (seconds) not yet written for this date (metadata-only)."""
    try:
        dt = DeltaTable(forward_path)
    except Exception:
        return list(horizons)
    parts = dt.partitions()
    existing_ms = {p["horizon_ms"] for p in parts if p["data_date"] == date_iso}
    return [h for h in horizons if str(vf.horizon_ms(h)) not in existing_ms]


def _write_delta(
    df: pl.DataFrame,
    table_path: str,
    partition_by: list[str],
    predicate: str,
) -> None:
    """Write DataFrame to Delta Lake with partition-level overwrite."""
    if not DeltaTable.is_deltatable(table_path):
        write_deltalake(table_path, df.to_arrow(), partition_by=partition_by, mode="error")
    else:
        write_deltalake(table_path, df.to_arrow(), mode="overwrite", predicate=predicate)


# ═══════════════════════════════════════════════════════════════
# PROCESS ONE DATE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str, horizons: Sequence[float]) -> tuple[pl.DataFrame, pl.DataFrame]:
    """Process one date: merge forward quote prices to each trade fill.

    Args:
        date: Date string in YYYYMMDD format.
        horizons: Horizons (seconds) to compute. May be a subset of HORIZONS
            when only missing horizons need to be filled in.

    Returns:
        (df_base, df_forward) tuple
    """
    elapsed_trade = f"elapsed_{TRADE_TIME_COL}"
    elapsed_quote = f"elapsed_{QUOTE_TIME_COL}"

    elapsed_create = f"elapsed_{CREATE_TIME_COL}"

    # Load trade (lazy) — all events, sorted for cum_sum correctness
    lf_trade = (
        vf.scan_trade(date)
        .pipe(vf.parse_time, TRADE_TIME_COL)
        .pipe(vf.parse_time, CREATE_TIME_COL)
        .sort(["ukey", elapsed_trade])
        .with_columns(
            pl.col("fill_qty").cum_sum().over(["data_date", "ukey", "order_id"]).alias("cum_fill_qty"),
        )
        .with_columns(
            (pl.col("order_qty") - pl.col("cum_fill_qty")).alias("remaining_qty"),
            (pl.col(elapsed_trade) - pl.col(elapsed_create)).alias("duration"),
        )
    )

    # Load quote (lazy) — t5ob schema: prices auto-scaled /10000
    lf_quote = (
        vf.scan_quote(date, columns=["ukey", QUOTE_TIME_COL] + REF_COLS)
        .pipe(vf.parse_time, QUOTE_TIME_COL)
    )

    # Forward merge: quote snapshots at each horizon around trade time
    df = vf.merge_forward(
        lf_trade, lf_quote,
        ref_cols=REF_COLS,
        horizons=horizons,
        trade_time_col=elapsed_trade,
        ref_time_col=elapsed_quote,
    )

    # Base table: trade-level columns (no forward columns)
    forward_col_names = [
        f"{col}_{vf.horizon_suffix(h)}" for col in REF_COLS for h in horizons
    ]
    base_cols = [c for c in df.columns if c not in forward_col_names]
    df_base = df.select(base_cols)

    # Forward table: semi-wide (one row per trade × horizon, ref_cols keep native types)
    id_cols = ["seq", "data_date"]
    frames = []
    for h in horizons:
        suffix = vf.horizon_suffix(h)
        rename_map = {f"{rc}_{suffix}": rc for rc in REF_COLS}
        frame = (
            df.select(id_cols + list(rename_map.keys()))
            .rename(rename_map)
            .with_columns(pl.lit(vf.horizon_ms(h)).cast(pl.Int64).alias("horizon_ms"))
        )
        frames.append(frame)
    df_forward = pl.concat(frames)

    return df_base, df_forward


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    parser.add_argument("--force", action="store_true",
                        help="Force reprocess even if date is complete")
    args = parser.parse_args()

    vf.set_config(vf.Config(
        trade_dir=TRADE_DIR,
        trade_pattern=TRADE_PATTERN,
        trade_schema=TRADE_SCHEMA,
        quote_dir=QUOTE_DIR,
        quote_pattern=QUOTE_PATTERN,
        quote_schema=QUOTE_SCHEMA,
        market=MARKET,
    ))

    # YYYYMMDD -> YYYY-MM-DD (Delta Lake partition format for pl.Date)
    date_iso = f"{args.date[:4]}-{args.date[4:6]}-{args.date[6:8]}"
    base_path = str(OUTPUT_DIR / "base")
    forward_path = str(OUTPUT_DIR / "forward")

    # Determine which horizons need processing
    if args.force:
        missing = list(HORIZONS)
    else:
        missing = _missing_horizons(forward_path, date_iso, HORIZONS)

    if not missing:
        print(f"  skip {args.date} (complete)")
        return

    print(f"Processing {args.date}... ({len(missing)}/{len(HORIZONS)} horizons)")
    df_base, df_forward = process_date(args.date, horizons=missing)
    print(f"  {len(df_base)} fills, {len(df_base.columns)} base columns")
    print(f"  {len(df_forward)} forward rows ({len(missing)} horizons × {len(df_base)} trades)")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Base: idempotent overwrite for this date
    base_predicate = f"data_date = '{date_iso}'"
    _write_delta(df_base, base_path, ["data_date"], base_predicate)

    # Forward: per-horizon write (safe for incremental append)
    if len(df_forward) > 0:
        for h in missing:
            h_ms = vf.horizon_ms(h)
            df_h = df_forward.filter(pl.col("horizon_ms") == h_ms)
            predicate = f"data_date = '{date_iso}' AND horizon_ms = {h_ms}"
            _write_delta(df_h, forward_path, ["data_date", "horizon_ms"], predicate)

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
