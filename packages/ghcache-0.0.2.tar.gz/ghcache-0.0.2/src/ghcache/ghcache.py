class GithubCache:
  def __init__(self):
    pass
