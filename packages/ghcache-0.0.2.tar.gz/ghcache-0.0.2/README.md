# ghcache

A GitHub API client with file-based caching.

This is an initial skeleton release published to establish the package name and validate the packaging/release workflow. The library is not functional yet.
