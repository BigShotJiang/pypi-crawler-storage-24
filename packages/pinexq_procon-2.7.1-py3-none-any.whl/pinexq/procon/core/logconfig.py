import json
import logging
from contextlib import contextmanager
from contextvars import ContextVar
from logging import DEBUG, INFO, WARNING
from typing import Any

from rich.logging import RichHandler

# Context variable to store job-related logging context
_log_context: ContextVar[dict[str, Any] | None] = ContextVar('log_context', default=None)


@contextmanager
def logging_context(**kwargs):
    """Context manager to set logging context fields.

    All log messages within this context will include the provided fields
    when using JSON logging format.

    Usage:
        with logging_context(job_id="123", context_id="abc"):
            log.info("Processing started") # Includes job_id, context_id in JSON

    Args:
        **kwargs: Key-value pairs to include in all log messages
    """
    token = _log_context.set(kwargs)
    try:
        yield
    finally:
        _log_context.reset(token)


def get_logging_context() -> dict[str, Any] | None:
    """Get the current logging context dictionary.

    Returns:
        The current context dict or None if no context is set.
    """
    return _log_context.get()


class JsonFormatter(logging.Formatter):
    """JSON formatter that automatically includes context from contextvars.

    Output format:
    {
        "timestamp": "2024-01-15T10:30:45",
        "level": "INFO",
        "logger": "pinexq.procon.runtime.job",
        "message": "Start processing Job",
        "job_id": "550e8400-e29b-41d4-a716-446655440000",
        "context_id": "ctx-123"
    }
    """

    def format(self, record: logging.LogRecord) -> str:
        try:
            message = record.getMessage()
        except (TypeError, ValueError):
            # Some libraries (e.g. httpx_caching) pass positional args
            # without matching %-format placeholders in the message string.
            message = f"{record.msg} {' '.join(str(a) for a in record.args)}" if record.args else str(record.msg)

        log_dict = {
            "timestamp": self.formatTime(record, self.datefmt),
            "level": record.levelname,
            "logger": record.name,
            "message": message,
        }

        # Add context from contextvar if available
        ctx = _log_context.get()
        if ctx:
            log_dict.update(ctx)

        # Add exception info if present
        if record.exc_info:
            log_dict["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_dict, default=str)


def configure_logging(
        debug: bool = False,
        rich: bool = False,
        json_format: bool = False,
):
    """Configure logging for the ProCon framework.

    Args:
        debug: Enable debug-level logging for internal packages
        rich: Use rich handler for colored console output (development)
        json_format: Output logs as JSON with context (production)

    Note:
        json_format and rich are mutually exclusive; rich takes precedence.
        When json_format is enabled, context fields (job_id, context_id) are
        automatically included in all log messages within a logging_context().
    """
    # Define log-levels for external (and internal) packages we depend on
    if debug:
        log_levels = {
            "aiormq": INFO,
            "aio_pika": INFO,
            "httpcore": INFO,
            "procon": DEBUG,
        }
    else:
        log_levels = {
            "aiormq": WARNING,
            "aio_pika": WARNING,
            "httpcore": WARNING,
            "procon": INFO,
        }

    config_options = {}

    # Create logger configuration options depending on CLI parameters
    if rich:
        # Use `rich` for colored, more structured formatting
        import aiormq, aio_pika, asyncio, click, httpcore  # noqa: E401, I001
        handlers = [
            RichHandler(
                rich_tracebacks=True,
                tracebacks_suppress=[click, aiormq, aio_pika, asyncio, httpcore]
            )
        ]
        config_options["handlers"] = handlers

    elif json_format:
        # JSON mode - structured logging for production/container environments
        handler = logging.StreamHandler()
        handler.setFormatter(JsonFormatter(datefmt="%Y-%m-%dT%H:%M:%S"))
        config_options["handlers"] = [handler]

    else:
        # Use plain formatting
        config_options["format"] = "%(asctime)s %(levelname)s %(message)s"
        config_options["datefmt"] = "%d-%m-%y %H:%M:%S"

    logging.captureWarnings(True)  # Warnings are converted to log.warning messages
    config_options["force"] = True  # Override existing logging configurations
    config_options["level"] = DEBUG if debug else INFO
    logging.basicConfig(**config_options)

    for logger, level in log_levels.items():
        logging.getLogger(logger).setLevel(level)
