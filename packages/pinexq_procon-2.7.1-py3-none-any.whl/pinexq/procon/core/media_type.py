import re
import warnings
from collections.abc import Callable
from dataclasses import dataclass
from typing import TypeVar

_T = TypeVar("_T", bound=type)

_SEGMENT_PATTERN = re.compile(r"^[a-z][a-z0-9\-]*$")
_SUFFIX_PATTERN = re.compile(r"^[a-z][a-z0-9]*$")

_SUBTYPE_HARD_LIMIT = 127
_SUBTYPE_RECOMMENDED_LIMIT = 64


def _validate_segment(value: str, parameter_name: str) -> str:
    """Validate and normalize a MIME type segment (name, namespace, or vendor).

    The value is normalized to lowercase. Must match ``[a-z][a-z0-9\\-]*``:
    starts with a letter, followed by lowercase alphanumeric characters or hyphens.

    Raises:
        TypeError: If value is not a string.
        ValueError: If value does not match the expected pattern.
    """
    if not isinstance(value, str):
        raise TypeError(f"'{parameter_name}' must be a string, got {type(value).__name__}")
    normalized = value.lower()
    if not _SEGMENT_PATTERN.match(normalized):
        raise ValueError(
            f"'{parameter_name}' must start with a letter and contain only "
            f"lowercase letters, digits, or hyphens (pattern: [a-z][a-z0-9\\-]*), "
            f"got '{value}'"
        )
    return normalized


def _validate_version(version: int) -> int:
    """Validate the version number.

    Must be a positive integer (>= 1).

    Raises:
        TypeError: If version is not an integer.
        ValueError: If version is less than 1.
    """
    if not isinstance(version, int) or isinstance(version, bool):
        raise TypeError(f"'version' must be an integer, got {type(version).__name__}")
    if version < 1:
        raise ValueError(f"'version' must be >= 1, got {version}")
    return version


def _validate_suffix(suffix: str) -> str:
    """Validate and normalize the structured syntax suffix.

    The value is normalized to lowercase. Must match ``[a-z][a-z0-9]*``:
    starts with a letter, followed by lowercase alphanumeric characters (no hyphens).

    Raises:
        TypeError: If suffix is not a string.
        ValueError: If suffix does not match the expected pattern.
    """
    if not isinstance(suffix, str):
        raise TypeError(f"'suffix' must be a string, got {type(suffix).__name__}")
    normalized = suffix.lower()
    if not _SUFFIX_PATTERN.match(normalized):
        raise ValueError(
            f"'suffix' must start with a letter and contain only lowercase letters "
            f"or digits (pattern: [a-z][a-z0-9]*), got '{suffix}'"
        )
    return normalized


def _validate_subtype_length(subtype: str) -> None:
    """Check the subtype length against RFC 6838 limits.

    Raises:
        ValueError: If the subtype exceeds 127 characters (hard limit).

    Warns:
        UserWarning: If the subtype exceeds 64 characters (recommended limit).
    """
    length = len(subtype)
    if length > _SUBTYPE_HARD_LIMIT:
        raise ValueError(
            f"MIME subtype exceeds RFC 6838 hard limit of {_SUBTYPE_HARD_LIMIT} characters "
            f"({length} characters): '{subtype}'"
        )
    if length > _SUBTYPE_RECOMMENDED_LIMIT:
        warnings.warn(
            f"MIME subtype exceeds RFC 6838 recommended limit of {_SUBTYPE_RECOMMENDED_LIMIT} "
            f"characters ({length} characters): '{subtype}'",
            UserWarning,
            stacklevel=4,
        )


@dataclass(frozen=True)
class _MediaTypeInfo:
    """Internal metadata attached to classes decorated with ``@media_type_def``.

    Stores the individual segments and a precomputed MIME type string
    following the vendor MIME type format from RFC 6838::

        application/vnd.<vendor>.<namespace>.<name>.v<version>+<suffix>
    """

    name: str
    version: int
    namespace: str
    vendor: str
    suffix: str
    media_type: str


def _build_media_type(
    name: str, version: int, namespace: str, vendor: str, suffix: str,
) -> str:
    """Build the full MIME type string from validated segments."""
    return f"application/vnd.{vendor}.{namespace}.{name}.v{version}+{suffix}"


_SENTINEL = object()


def _create_decorator(
    name: str,
    version: int,
    namespace: str,
    vendor: str = "pinexq",
    suffix: str = "json",
) -> Callable[[_T], _T]:
    """Validate parameters, build MIME string, and return the class decorator."""
    validated_name = _validate_segment(name, "name")
    validated_namespace = _validate_segment(namespace, "namespace")
    validated_vendor = _validate_segment(vendor, "vendor")
    validated_version = _validate_version(version)
    validated_suffix = _validate_suffix(suffix)

    media_type = _build_media_type(
        validated_name, validated_version, validated_namespace,
        validated_vendor, validated_suffix,
    )
    subtype = media_type.split("/", maxsplit=1)[1]
    _validate_subtype_length(subtype)

    info = _MediaTypeInfo(
        name=validated_name,
        version=validated_version,
        namespace=validated_namespace,
        vendor=validated_vendor,
        suffix=validated_suffix,
        media_type=media_type,
    )

    def decorator(cls: _T) -> _T:
        if hasattr(cls, "_media_type_info"):
            raise TypeError(
                f"Class '{cls.__name__}' is already decorated with @media_type_def. "
                f"Each class can only have one media type — create a separate class "
                f"for each version."
            )
        cls._media_type_info = info  # type: ignore[attr-defined]
        return cls

    return decorator


class _MediaTypeDef:
    """Callable that acts as both a decorator factory and a defaults factory.

    Used as ``media_type_def(...)`` to decorate classes, and as
    ``media_type_def.with_defaults(...)`` to create a pre-configured decorator.
    """

    def __call__(
        self,
        name: str,
        version: int,
        namespace: str,
        vendor: str = "pinexq",
        suffix: str = "json",
    ) -> Callable[[_T], _T]:
        """Define a custom vendor MIME type for a class.

        Decorates a class (typically a Pydantic model or dataclass) with media type
        metadata, generating a MIME type string following RFC 6838 vendor tree
        conventions::

            application/vnd.<vendor>.<namespace>.<name>.v<version>+<suffix>

        The generated MIME type can be retrieved with :func:`get_media_type` and
        used directly in ``@dataslot.input()``, ``@dataslot.output()``, etc.

        Args:
            name: Logical name for this data schema (e.g., ``"gasprices"``).
                Must match ``[a-z][a-z0-9\\-]*`` — lowercase, starts with a letter,
                alphanumeric and hyphens only, no dots. Normalized to lowercase.
            version: Schema version number. Must be a positive integer (>= 1).
                Each breaking change to the schema should increment this number.
            namespace: Namespace to group schemas under (e.g., project, team, or
                domain name). Same naming rules as ``name``.
            vendor: Vendor prefix, the first segment after ``vnd.`` in the MIME
                type. Same naming rules as ``name``. Defaults to ``"pinexq"``.
            suffix: Structured syntax suffix (e.g., ``"json"``, ``"xml"``,
                ``"csv"``). Must match ``[a-z][a-z0-9]*`` — no hyphens. Determines
                file mode inference (text vs binary). Defaults to ``"json"``.

        Returns:
            A class decorator that attaches media type metadata to the class.

        Raises:
            TypeError: If the class is already decorated with ``@media_type_def``.
            ValueError: If any parameter fails validation or the resulting MIME
                subtype exceeds 127 characters (RFC 6838 hard limit).

        .. note::
            A ``UserWarning`` is emitted if the subtype exceeds 64 characters
            (RFC 6838 recommended limit).

        Examples::

            @media_type_def(name="gasprices", version=1, namespace="mynamespace")
            class GasPricesV1(BaseModel):
                date: str
                price: float
                currency: str

            get_media_type(GasPricesV1)
            # → "application/vnd.pinexq.mynamespace.gasprices.v1+json"

            # Custom vendor and suffix:
            @media_type_def(
                name="report", version=1, namespace="analytics",
                vendor="acme", suffix="xml",
            )
            class AcmeReportV1(BaseModel):
                ...
            # → "application/vnd.acme.analytics.report.v1+xml"
        """
        return _create_decorator(name, version, namespace, vendor, suffix)

    def with_defaults(
        self,
        namespace: str | None = None,
        vendor: str | None = None,
        suffix: str | None = None,
    ) -> "_MediaTypeDefWithDefaults":
        """Create a pre-configured decorator with default parameter values.

        Returns a callable that behaves like ``@media_type_def(...)`` but with
        the specified parameters pre-filled. Individual calls can still override
        any pre-filled value.

        Args:
            namespace: Default namespace for all decorated classes.
            vendor: Default vendor prefix. If not given, falls back to
                ``"pinexq"``.
            suffix: Default structured syntax suffix. If not given, falls back
                to ``"json"``.

        Returns:
            A decorator factory with the given defaults pre-filled.

        Examples::

            my_schema = media_type_def.with_defaults(namespace="mynamespace")

            @my_schema(name="gasprices", version=1)
            class GasPricesV1(BaseModel):
                ...
            # → "application/vnd.pinexq.mynamespace.gasprices.v1+json"

            @my_schema(name="temperatures", version=1)
            class TemperaturesV1(BaseModel):
                ...
            # → "application/vnd.pinexq.mynamespace.temperatures.v1+json"

            # Override a pre-filled value:
            @my_schema(name="report", version=1, vendor="acme")
            class AcmeReportV1(BaseModel):
                ...
            # → "application/vnd.acme.mynamespace.report.v1+json"
        """
        return _MediaTypeDefWithDefaults(
            namespace=namespace, vendor=vendor, suffix=suffix,
        )


class _MediaTypeDefWithDefaults:
    """Decorator factory with pre-filled default parameters."""

    def __init__(
        self,
        namespace: str | None = None,
        vendor: str | None = None,
        suffix: str | None = None,
    ) -> None:
        self._namespace = namespace
        self._vendor = vendor
        self._suffix = suffix

    def __call__(
        self,
        name: str,
        version: int,
        namespace: str | object = _SENTINEL,
        vendor: str | object = _SENTINEL,
        suffix: str | object = _SENTINEL,
    ) -> Callable[[_T], _T]:
        """Create a media type decorator, using pre-filled defaults for omitted parameters.

        Args:
            name: Logical name for this data schema.
            version: Schema version number (>= 1).
            namespace: Overrides the pre-filled namespace.
            vendor: Overrides the pre-filled vendor.
            suffix: Overrides the pre-filled suffix.

        Returns:
            A class decorator that attaches media type metadata.
        """
        resolved_namespace = namespace if namespace is not _SENTINEL else self._namespace
        resolved_vendor = vendor if vendor is not _SENTINEL else self._vendor
        resolved_suffix = suffix if suffix is not _SENTINEL else self._suffix

        kwargs: dict[str, str | int] = {"name": name, "version": version}
        if resolved_namespace is not None:
            kwargs["namespace"] = resolved_namespace  # type: ignore[assignment]
        if resolved_vendor is not None:
            kwargs["vendor"] = resolved_vendor  # type: ignore[assignment]
        if resolved_suffix is not None:
            kwargs["suffix"] = resolved_suffix  # type: ignore[assignment]

        return _create_decorator(**kwargs)  # type: ignore[arg-type]


media_type_def = _MediaTypeDef()


def get_media_type(cls: type) -> str:
    """Return the custom MIME type string for a class decorated with :func:`media_type_def`.

    Args:
        cls: A class that has been decorated with ``@media_type_def``.

    Returns:
        The full MIME type string, e.g.
        ``"application/vnd.pinexq.mynamespace.gasprices.v1+json"``.

    Raises:
        TypeError: If the class has no ``@media_type_def`` annotation.

    Examples::

        @media_type_def(name="gasprices", version=1, namespace="mynamespace")
        class GasPricesV1(BaseModel):
            ...

        get_media_type(GasPricesV1)
        # → "application/vnd.pinexq.mynamespace.gasprices.v1+json"

        # Use in dataslot decorators:
        @dataslot.input("prices", reader=json.load, media_type=get_media_type(GasPricesV1))
        def process_prices(self, prices: list[GasPricesV1]) -> dict:
            ...
    """
    info = getattr(cls, "_media_type_info", None)
    if not isinstance(info, _MediaTypeInfo):
        raise TypeError(
            f"Class '{cls.__name__}' has no @media_type_def annotation. "
            f"Decorate it with @media_type_def(...) first."
        )
    return info.media_type
