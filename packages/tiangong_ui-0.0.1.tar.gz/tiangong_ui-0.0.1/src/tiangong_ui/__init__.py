"""
TianGong UI -- Frontend components and dashboard for the TianGong platform.
"""
__version__ = "0.0.1"
