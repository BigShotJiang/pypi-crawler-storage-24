"""Ports (protocols / ABCs) for dependency inversion."""
