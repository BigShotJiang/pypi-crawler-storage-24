from __future__ import annotations

from pathlib import Path
from typing import Protocol

from protocol_pack.domain.models import BuiltTree


class TargetEmitterPort(Protocol):
    """Writes a built tree into a staging directory for a specific target."""

    target_id: str

    def emit(
        self,
        tree: BuiltTree,
        staging_root: Path,
        profile: str,
        *,
        validate_rules: bool = True,
        generate_router: bool = False,
        merge_router: bool = False,
        emit_provenance: bool = False,
    ) -> None: ...
