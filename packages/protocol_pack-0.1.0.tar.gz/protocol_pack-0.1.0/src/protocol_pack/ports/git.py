from __future__ import annotations

from pathlib import Path
from typing import Protocol


class GitPort(Protocol):
    """Clone/fetch packages (Phase 1+)."""

    def ensure_clone(
        self,
        url: str,
        ref: str,
        dest: Path,
        *,
        offline: bool = False,
    ) -> str: ...

    def get_sha(self, repo: Path) -> str: ...
