"""Protocol Pack CLI — resolve, compose, and emit agent-facing artifacts."""

from protocol_pack.__version__ import __version__

__all__ = ["__version__"]
