"""Package version (kept in sync with pyproject.toml for runtime introspection)."""

__version__ = "0.1.0"
