from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

import frontmatter  # type: ignore[import-untyped]

from protocol_pack.domain.models import BuiltTree, ProtocolSourceAsset
from protocol_pack.domain.protocol_outline import (
    DEFAULT_SECTION_ORDER,
    PREAMBLE_SECTION_ID,
    MergeStrategy,
)
from protocol_pack.exceptions import CompositionError
from protocol_pack.ports.filesystem import FilesystemPort

_SECTION_MARKER = re.compile(
    r"^<!--\s*protocol-pack-section:\s*([a-zA-Z0-9_-]+)\s*-->\s*$",
    re.MULTILINE,
)


@dataclass(frozen=True)
class _ParsedLayer:
    path: Path
    metadata: dict[str, Any]
    sections: dict[str, str]
    extends: str | None
    section_merge: dict[str, MergeStrategy]


def _coerce_section_merge(raw: object, source: Path) -> dict[str, MergeStrategy]:
    if raw is None:
        return {}
    if not isinstance(raw, dict):
        raise CompositionError(f"section_merge must be a mapping in {source}")
    out: dict[str, MergeStrategy] = {}
    for key, val in raw.items():
        s = str(val).lower().strip()
        if s not in ("append", "replace"):
            raise CompositionError(
                f"Invalid section_merge value for {key!r} in {source}: "
                f"expected 'append' or 'replace', got {val!r}"
            )
        out[str(key)] = s  # type: ignore[assignment]
    return out


def _split_sections(body: str, source: Path) -> dict[str, str]:
    text = body.replace("\r\n", "\n").replace("\r", "\n")
    matches = list(_SECTION_MARKER.finditer(text))
    if not matches:
        return {PREAMBLE_SECTION_ID: text.rstrip()}

    sections: dict[str, str] = {}
    first = matches[0].start()
    preamble = text[:first].strip()
    sections[PREAMBLE_SECTION_ID] = preamble

    for i, m in enumerate(matches):
        sid = m.group(1)
        start = m.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
        chunk = text[start:end].strip()
        if sid in sections:
            raise CompositionError(f"Duplicate protocol-pack-section {sid!r} in {source}")
        sections[sid] = chunk
    return sections


def _coerce_extends(meta: dict[str, Any], source: Path) -> str | None:
    raw = meta.get("extends")
    if raw is None:
        return None
    if isinstance(raw, str):
        s = raw.strip()
        return s or None
    raise CompositionError(
        f"extends must be a single string path in {source} (lists are not supported yet)"
    )


def _parse_layer(path: Path, raw: str) -> _ParsedLayer:
    post = frontmatter.loads(raw)
    meta = dict(post.metadata or {})
    body = post.content if post.content is not None else ""
    extends = _coerce_extends(meta, path)
    section_merge = _coerce_section_merge(meta.get("section_merge"), path)
    sections = _split_sections(body, path)
    return _ParsedLayer(path, meta, sections, extends, section_merge)


def _resolve_extends_target(
    ref: str,
    package_root: Path,
    abstract_index: Mapping[str, Path],
    fs: FilesystemPort,
) -> Path:
    ref_norm = ref.replace("\\", "/").strip().lstrip("./")
    candidates = [
        package_root / ref_norm,
        package_root / "protocols" / ref_norm,
        package_root / "protocols" / "abstract" / ref_norm,
    ]
    for c in candidates:
        try:
            resolved = c.resolve()
        except OSError as e:
            raise CompositionError(f"Invalid extends path {ref!r}: {e}") from e
        if fs.exists(resolved) and fs.is_file(resolved):
            return resolved

    if ref_norm in abstract_index:
        return abstract_index[ref_norm]

    matches: list[tuple[str, Path]] = []
    base = ref_norm.split("/")[-1]
    for name, p in abstract_index.items():
        if name == ref_norm or name.endswith("/" + ref_norm) or name.endswith("/" + base):
            matches.append((name, p))
    if not matches:
        raise CompositionError(
            f"Could not resolve extends {ref!r} under {package_root} or in merged abstract sources"
        )
    matches.sort(key=lambda kv: (len(kv[0]), kv[0]))
    best_len = len(matches[0][0])
    tied = [m for m in matches if len(m[0]) == best_len]
    if len(tied) > 1:
        names = ", ".join(repr(k) for k, _ in tied[:6])
        raise CompositionError(f"Ambiguous extends {ref!r}; matches: {names}")
    return tied[0][1]


def _load_chain(
    leaf_path: Path,
    package_root: Path,
    abstract_index: Mapping[str, Path],
    fs: FilesystemPort,
    visiting: set[Path] | None = None,
) -> list[_ParsedLayer]:
    if visiting is None:
        visiting = set()
    canon = leaf_path.resolve()
    if canon in visiting:
        raise CompositionError(f"extends cycle involving {canon}")
    visiting.add(canon)

    raw = fs.read_text(leaf_path)
    layer = _parse_layer(leaf_path, raw)
    if layer.extends is None:
        visiting.remove(canon)
        return [layer]

    base_path = _resolve_extends_target(layer.extends, package_root, abstract_index, fs)
    base_chain = _load_chain(base_path, package_root, abstract_index, fs, visiting)
    visiting.remove(canon)
    return base_chain + [layer]


def _merge_section_dicts(
    base: dict[str, str],
    overlay: dict[str, str],
    strategies: dict[str, MergeStrategy],
    *,
    base_desc: str,
    overlay_desc: str,
) -> dict[str, str]:
    out = dict(base)
    for sid, raw_child in overlay.items():
        child_stripped = raw_child.strip()
        if not child_stripped:
            continue
        parent_raw = out.get(sid, "")
        parent_stripped = parent_raw.strip()
        if not parent_stripped:
            out[sid] = raw_child.strip()
            continue
        strat = strategies.get(sid)
        if strat == "append":
            out[sid] = parent_stripped + "\n\n" + child_stripped
        elif strat == "replace":
            out[sid] = raw_child.strip()
        else:
            raise CompositionError(
                f"Section {sid!r} conflicts when merging {overlay_desc} over {base_desc}; "
                f"set section_merge.{sid} to 'append' or 'replace' in the extending file "
                f"({overlay_desc})."
            )
    return out


def _render_merged_sections(sections: dict[str, str]) -> str:
    parts: list[str] = []
    pre = sections.get(PREAMBLE_SECTION_ID, "").strip()
    if pre:
        parts.append(pre)
        parts.append("")

    tail_ids = [s for s in DEFAULT_SECTION_ORDER if s != PREAMBLE_SECTION_ID]
    extras = sorted(set(sections) - set(DEFAULT_SECTION_ORDER))
    for sid in tail_ids + extras:
        content = sections.get(sid, "").strip()
        if not content:
            continue
        parts.append(f"<!-- protocol-pack-section: {sid} -->")
        parts.append("")
        parts.append(content)
        parts.append("")

    text = "\n".join(parts).rstrip() + "\n"
    return text


def _strip_composer_keys(meta: dict[str, Any]) -> dict[str, Any]:
    m = dict(meta)
    m.pop("extends", None)
    m.pop("section_merge", None)
    return m


def _compose_one(
    asset: ProtocolSourceAsset,
    abstract_index: Mapping[str, Path],
    fs: FilesystemPort,
) -> ProtocolSourceAsset:
    raw = fs.read_text(asset.source_path)
    layer0 = _parse_layer(asset.source_path, raw)
    if layer0.extends is None:
        return asset

    chain = _load_chain(asset.source_path, asset.package_root.resolve(), abstract_index, fs)
    merged_sections = chain[0].sections
    for i in range(1, len(chain)):
        merged_sections = _merge_section_dicts(
            merged_sections,
            chain[i].sections,
            chain[i].section_merge,
            base_desc=str(chain[i - 1].path),
            overlay_desc=str(chain[i].path),
        )

    body = _render_merged_sections(merged_sections)
    out_meta = _strip_composer_keys(chain[-1].metadata)
    post = frontmatter.Post(body, **out_meta)
    composed = frontmatter.dumps(post)
    return ProtocolSourceAsset(
        source_path=asset.source_path,
        relative_name=asset.relative_name,
        package_root=asset.package_root,
        source_package=asset.source_package,
        composed_body=composed,
    )


def abstract_source_index(tree: BuiltTree) -> dict[str, Path]:
    """Map abstract relative_name (merged) to source path."""
    return {a.relative_name: a.source_path for a in tree.abstract_sources}


def compose_protocol_tree(tree: BuiltTree, fs: FilesystemPort) -> BuiltTree:
    """
    Expand extends / section merges for each concrete protocol.

    Files without ``extends`` are unchanged (emitter reads from disk).
    """
    if not tree.protocol_sources:
        return tree

    index = abstract_source_index(tree)
    new_proto: list[ProtocolSourceAsset] = []
    for p in tree.protocol_sources:
        new_proto.append(_compose_one(p, index, fs))

    return replace(tree, protocol_sources=tuple(new_proto))
