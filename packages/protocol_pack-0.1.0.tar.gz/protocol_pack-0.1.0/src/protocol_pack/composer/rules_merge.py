from __future__ import annotations

from collections.abc import Sequence

from protocol_pack.domain.models import (
    BuiltTree,
    ProtocolSourceAsset,
    RuleAsset,
    SkillAsset,
    WorkspaceConfig,
)


def merge_ordered_trees(workspace: WorkspaceConfig, trees: Sequence[BuiltTree]) -> BuiltTree:
    """
    Merge composer outputs in declaration order: later packages override rule_id / paths.

    Phase 1: rules and protocol/abstract sources use replace-by-key semantics (design §7.1).
    """
    merged_rules: dict[str, RuleAsset] = {}
    merged_skills: dict[str, SkillAsset] = {}
    merged_proto: dict[str, ProtocolSourceAsset] = {}
    merged_abs: dict[str, ProtocolSourceAsset] = {}

    for tree in trees:
        for r in tree.rules:
            merged_rules[r.rule_id] = r
        for s in tree.skills:
            merged_skills[s.skill_id] = s
        for p in tree.protocol_sources:
            merged_proto[p.relative_name] = p
        for a in tree.abstract_sources:
            merged_abs[a.relative_name] = a

    return BuiltTree(
        workspace=workspace,
        rules=tuple(sorted(merged_rules.values(), key=lambda x: x.rule_id)),
        skills=tuple(sorted(merged_skills.values(), key=lambda x: x.skill_id)),
        protocol_sources=tuple(sorted(merged_proto.values(), key=lambda x: x.relative_name)),
        abstract_sources=tuple(sorted(merged_abs.values(), key=lambda x: x.relative_name)),
    )
