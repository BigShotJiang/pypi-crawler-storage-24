"""Merge rules and protocol sources (Phase 0: passthrough; Phase 1+: ordered merge)."""
