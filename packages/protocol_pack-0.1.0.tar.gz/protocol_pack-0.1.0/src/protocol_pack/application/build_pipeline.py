from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import replace
from pathlib import Path

from protocol_pack.application.merge_report import write_merge_report
from protocol_pack.composer.protocols_merge import compose_protocol_tree
from protocol_pack.composer.rules_merge import merge_ordered_trees
from protocol_pack.domain.models import (
    BuiltTree,
    ProtocolSourceAsset,
    ResolvedGraph,
    ResolvedPackage,
    RuleAsset,
    SkillAsset,
    WorkspaceConfig,
)
from protocol_pack.exceptions import EmitError, ManifestError
from protocol_pack.infrastructure.lockfile import write_lockfile
from protocol_pack.ports.emitter import TargetEmitterPort
from protocol_pack.ports.filesystem import FilesystemPort
from protocol_pack.ports.git import GitPort
from protocol_pack.resolver.resolve import resolve_workspace

logger = logging.getLogger(__name__)

DEFAULT_STAGING = Path(".protocol-pack") / "build"


def _strip_path_prefix(parts: tuple[str, ...], prefix: tuple[str, ...]) -> Path | None:
    if len(parts) >= len(prefix) and parts[: len(prefix)] == prefix:
        tail = parts[len(prefix) :]
        return Path(*tail) if tail else None
    return None


def _concrete_staging_relpath(package_root: Path, path: Path) -> str:
    rel = path.resolve().relative_to(package_root.resolve())
    stripped = _strip_path_prefix(rel.parts, ("protocols",))
    if stripped is not None and str(stripped) != ".":
        return stripped.as_posix()
    return rel.as_posix()


def _abstract_staging_relpath(package_root: Path, path: Path) -> str:
    rel = path.resolve().relative_to(package_root.resolve())
    for prefix in (("protocols", "abstract"), ("abstract",)):
        stripped = _strip_path_prefix(rel.parts, prefix)
        if stripped is not None and str(stripped) != ".":
            return stripped.as_posix()
    return rel.as_posix()


def _rule_relative_dest(package_root: Path, file_path: Path) -> Path:
    root = package_root.resolve()
    rel = file_path.resolve().relative_to(root)
    parts = rel.parts
    if len(parts) >= 2 and parts[0] == ".cursor" and parts[1] == "rules":
        return Path(*parts[2:]) if len(parts) > 2 else Path(file_path.name)
    return Path(*parts)


def _skill_relative_dest(package_root: Path, file_path: Path) -> Path:
    root = package_root.resolve()
    rel = file_path.resolve().relative_to(root)
    parts = rel.parts
    if len(parts) >= 3 and parts[0] == ".cursor" and parts[1] == "skills":
        return Path(*parts[2:]) if len(parts) > 2 else Path(file_path.name)
    return Path(*parts)


def _stable_rule_id(package_root: Path, file_path: Path) -> str:
    root = package_root.resolve()
    return file_path.resolve().relative_to(root).as_posix()


def _normalize_glob_pattern(pattern: str) -> str:
    """
    pathlib treats a trailing ``**`` as matching directories only; append ``/*`` so nested
    files (e.g. ``.cursor/skills/foo/SKILL.md``) are included.
    """
    stripped = pattern.rstrip("/")
    if stripped.endswith("/**"):
        return stripped + "/*"
    return pattern


def _collect_glob_assets(
    fs: FilesystemPort,
    package: ResolvedPackage,
    patterns: tuple[str, ...],
) -> list[Path]:
    seen: dict[Path, Path] = {}
    root = package.root_path
    for pattern in patterns:
        pattern = _normalize_glob_pattern(pattern)
        for path in fs.glob_files(root, pattern):
            resolved = path.resolve()
            if not fs.is_file(resolved):
                continue
            if resolved not in seen:
                seen[resolved] = path
    return sorted(seen.values(), key=lambda p: p.as_posix())


def compose_phase0_single_package(
    fs: FilesystemPort,
    package: ResolvedPackage,
    workspace: WorkspaceConfig,
) -> BuiltTree:
    """Expand provides globs into a flat built tree (no merge)."""
    rule_paths = _collect_glob_assets(fs, package, package.provides.rules)
    skill_paths = _collect_glob_assets(fs, package, package.provides.skills)
    concrete_paths = _collect_glob_assets(fs, package, package.provides.concrete_sources)
    abstract_paths = _collect_glob_assets(fs, package, package.provides.abstract)

    rules: list[RuleAsset] = []
    seen_ids: set[str] = set()
    for path in rule_paths:
        rid = _stable_rule_id(package.root_path, path)
        if rid in seen_ids:
            raise ManifestError(f"Duplicate rule id {rid!r} from glob overlap")
        seen_ids.add(rid)
        rules.append(
            RuleAsset(
                rule_id=rid,
                source_path=path,
                relative_dest=_rule_relative_dest(package.root_path, path),
            )
        )

    skills: list[SkillAsset] = []
    seen_skill_ids: set[str] = set()
    for path in skill_paths:
        sid = _stable_rule_id(package.root_path, path)
        if sid in seen_skill_ids:
            raise ManifestError(f"Duplicate skill id {sid!r} from glob overlap")
        seen_skill_ids.add(sid)
        skills.append(
            SkillAsset(
                skill_id=sid,
                source_path=path,
                relative_dest=_skill_relative_dest(package.root_path, path),
            )
        )

    protocols: list[ProtocolSourceAsset] = []
    for path in concrete_paths:
        protocols.append(
            ProtocolSourceAsset(
                source_path=path,
                relative_name=_concrete_staging_relpath(package.root_path, path),
                package_root=package.root_path,
                source_package=package.name,
            )
        )

    abstracts: list[ProtocolSourceAsset] = []
    for path in abstract_paths:
        abstracts.append(
            ProtocolSourceAsset(
                source_path=path,
                relative_name=_abstract_staging_relpath(package.root_path, path),
                package_root=package.root_path,
                source_package=package.name,
            )
        )

    return BuiltTree(
        workspace=workspace,
        rules=tuple(rules),
        skills=tuple(skills),
        protocol_sources=tuple(protocols),
        abstract_sources=tuple(abstracts),
    )


def compose_phase1_multi_package(
    fs: FilesystemPort,
    graph: ResolvedGraph,
) -> BuiltTree:
    """Expand and merge all packages in resolver order (replace-by-id for rules)."""
    trees = [
        compose_phase0_single_package(fs, package, graph.workspace) for package in graph.packages
    ]
    return merge_ordered_trees(graph.workspace, trees)


def run_build(
    workspace_root: Path,
    fs: FilesystemPort,
    emitter: TargetEmitterPort,
    *,
    clean: bool = False,
    staging_subdir: Path | None = None,
    layout_profile_override: str | None = None,
    offline: bool = False,
    git_port: GitPort | None = None,
    tarball_fetch: Callable[[str], bytes] | None = None,
    merge_report_path: Path | None = None,
    validate_rules: bool = True,
    generate_router: bool = False,
    merge_router: bool = False,
    emit_provenance: bool = False,
) -> Path:
    """
    Resolve → compose (Phase 0) → emit to staging.

    Returns the absolute staging root.
    """
    root = workspace_root.resolve()
    graph = resolve_workspace(
        root,
        offline=offline,
        git_port=git_port,
        tarball_fetch=tarball_fetch,
    )
    write_lockfile(root, graph)
    ws_config = graph.workspace
    if layout_profile_override is not None:
        ws_config = replace(ws_config, layout_profile=layout_profile_override)

    staging = root / (staging_subdir or DEFAULT_STAGING)
    if clean:
        logger.info("Removing staging tree %s", staging)
        fs.remove_tree(staging)

    tree = compose_phase1_multi_package(fs, replace(graph, workspace=ws_config))
    tree = compose_protocol_tree(tree, fs)
    if merge_report_path is not None:
        report_path = merge_report_path
        if not report_path.is_absolute():
            report_path = root / report_path
        write_merge_report(report_path.resolve(), tree, graph)
    profile = ws_config.layout_profile
    if emitter.target_id != ws_config.target:
        raise EmitError(
            f"Emitter target {emitter.target_id!r} does not match "
            f"manifest target {ws_config.target!r}"
        )

    logger.info("Emitting to %s (profile=%s)", staging, profile)
    emitter.emit(
        tree,
        staging,
        profile,
        validate_rules=validate_rules,
        generate_router=generate_router,
        merge_router=merge_router,
        emit_provenance=emit_provenance,
    )
    return staging
