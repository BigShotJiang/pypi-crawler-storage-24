from __future__ import annotations

import logging
import shutil
from pathlib import Path

from protocol_pack.exceptions import EmitError
from protocol_pack.targets.cursor import layout_profiles

logger = logging.getLogger(__name__)


def _symlink_file(src_file: Path, dest_file: Path) -> None:
    """Create ``dest_file`` as a symlink to absolute ``src_file`` (must be a file)."""
    src_resolved = src_file.resolve()
    dest_file.parent.mkdir(parents=True, exist_ok=True)
    if dest_file.is_symlink() or dest_file.is_file():
        dest_file.unlink()
    elif dest_file.exists():
        raise EmitError(
            f"Install target exists but is not a replaceable file or symlink: {dest_file}"
        )
    dest_file.symlink_to(src_resolved, target_is_directory=False)


def _copy_protocols_skip_abstract(proto_src: Path, proto_dst: Path) -> None:
    """Install merged concrete protocols only (design §7.2: no abstract workflows on disk)."""
    proto_src = proto_src.resolve()
    for path in sorted(proto_src.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(proto_src)
        if rel.parts and rel.parts[0] == "abstract":
            continue
        dest = proto_dst / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, dest)


def _symlink_protocols_skip_abstract(
    proto_src: Path,
    proto_dst: Path,
    *,
    dry_run: bool,
    actions: list[str],
) -> None:
    """Like ``_copy_protocols_skip_abstract`` but symlinks each file into the workspace."""
    proto_src = proto_src.resolve()
    for path in sorted(proto_src.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(proto_src)
        if rel.parts and rel.parts[0] == "abstract":
            continue
        dest = proto_dst / rel
        actions.append(f"symlink {dest} -> {path.resolve()}")
        if not dry_run:
            _symlink_file(path, dest)


def _install_cursor_tree(
    cursor_src: Path,
    cursor_dst: Path,
    *,
    dry_run: bool,
    use_symlinks: bool,
    actions: list[str],
) -> None:
    cursor_src = cursor_src.resolve()
    if not cursor_src.is_dir():
        return
    if use_symlinks:
        for path in sorted(cursor_src.rglob("*")):
            if not path.is_file():
                continue
            rel = path.relative_to(cursor_src)
            dest = cursor_dst / rel
            actions.append(f"symlink {dest} -> {path.resolve()}")
            if not dry_run:
                _symlink_file(path, dest)
    else:
        actions.append(f"copy {cursor_src} -> {cursor_dst}")
        if not dry_run:
            shutil.copytree(cursor_src, cursor_dst, dirs_exist_ok=True)


def install_staged_tree(
    workspace_root: Path,
    staging_root: Path,
    layout_profile: str,
    *,
    dry_run: bool = False,
    use_symlinks: bool = False,
) -> list[str]:
    """
    Copy or symlink emitted staging (``.cursor/`` and protocol tree) into the workspace.

    Returns human-readable action lines (for ``--dry-run`` or logging).
    """
    workspace_root = workspace_root.resolve()
    staging_root = staging_root.resolve()
    actions: list[str] = []

    cursor_src = staging_root / ".cursor"
    cursor_dst = workspace_root / ".cursor"
    if cursor_src.is_dir():
        _install_cursor_tree(
            cursor_src,
            cursor_dst,
            dry_run=dry_run,
            use_symlinks=use_symlinks,
            actions=actions,
        )

    try:
        proto_rel = Path(layout_profiles.protocols_dir_under_staging(layout_profile))
    except ValueError as e:
        raise EmitError(str(e)) from e

    proto_src = staging_root / proto_rel
    proto_dst = workspace_root / proto_rel
    if proto_src.is_dir():
        if use_symlinks:
            _symlink_protocols_skip_abstract(proto_src, proto_dst, dry_run=dry_run, actions=actions)
        else:
            actions.append(
                f"copy {proto_src} -> {proto_dst} (concrete protocols only; skip abstract/)"
            )
            if not dry_run:
                _copy_protocols_skip_abstract(proto_src, proto_dst)

    if dry_run:
        logger.info("Dry-run install: %s", "; ".join(actions) if actions else "(nothing to copy)")
    return actions
