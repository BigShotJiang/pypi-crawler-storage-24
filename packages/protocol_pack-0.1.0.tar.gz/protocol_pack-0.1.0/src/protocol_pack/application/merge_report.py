from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from protocol_pack.domain.models import BuiltTree, ResolvedGraph


def _package_name_for_file(graph: ResolvedGraph, file_path: Path) -> str:
    path = file_path.resolve()
    best_name = "unknown"
    best_depth = -1
    for pkg in graph.packages:
        root = pkg.root_path.resolve()
        try:
            path.relative_to(root)
        except ValueError:
            continue
        depth = len(root.parts)
        if depth > best_depth:
            best_depth = depth
            best_name = pkg.name
    return best_name


def _package_name_for_root(graph: ResolvedGraph, package_root: Path) -> str:
    r = package_root.resolve()
    for pkg in graph.packages:
        if pkg.root_path.resolve() == r:
            return pkg.name
    return "unknown"


def build_merge_report_document(tree: BuiltTree, graph: ResolvedGraph) -> dict[str, Any]:
    """Structured merge report (design §7.2 / plan §23)."""
    ws = tree.workspace
    return {
        "merge_report_format": 1,
        "workspace": {
            "name": ws.name,
            "layout_profile": ws.layout_profile,
            "target": ws.target,
        },
        "packages_merge_order": [p.name for p in graph.packages],
        "rules": [
            {
                "rule_id": r.rule_id,
                "relative_dest": r.relative_dest.as_posix(),
                "source_path": r.source_path.resolve().as_posix(),
                "package": _package_name_for_file(graph, r.source_path),
            }
            for r in tree.rules
        ],
        "skills": [
            {
                "skill_id": s.skill_id,
                "relative_dest": s.relative_dest.as_posix(),
                "source_path": s.source_path.resolve().as_posix(),
                "package": _package_name_for_file(graph, s.source_path),
            }
            for s in tree.skills
        ],
        "protocols": [
            {
                "relative_name": p.relative_name,
                "source_path": p.source_path.resolve().as_posix(),
                "package": _package_name_for_root(graph, p.package_root),
                "composed": p.composed_body is not None,
            }
            for p in tree.protocol_sources
        ],
        "abstracts": [
            {
                "relative_name": a.relative_name,
                "source_path": a.source_path.resolve().as_posix(),
                "package": _package_name_for_root(graph, a.package_root),
            }
            for a in tree.abstract_sources
        ],
    }


def write_merge_report(path: Path, tree: BuiltTree, graph: ResolvedGraph) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    doc = build_merge_report_document(tree, graph)
    path.write_text(json.dumps(doc, indent=2) + "\n", encoding="utf-8")
