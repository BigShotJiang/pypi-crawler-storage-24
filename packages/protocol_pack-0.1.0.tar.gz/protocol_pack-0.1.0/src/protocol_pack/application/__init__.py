"""Use cases orchestrating domain logic and ports."""
