"""Stable section ordering for composed protocol markdown (product design §7.2)."""

from __future__ import annotations

from typing import Literal

# Preamble / body before the first explicit section marker.
PREAMBLE_SECTION_ID = "_preamble"

MergeStrategy = Literal["append", "replace"]

# Sections listed first in composed output; any other ids follow in sorted order.
DEFAULT_SECTION_ORDER: tuple[str, ...] = (
    PREAMBLE_SECTION_ID,
    "purpose",
    "when_to_use",
    "steps",
    "applicable_rules",
    "verifier",
)
