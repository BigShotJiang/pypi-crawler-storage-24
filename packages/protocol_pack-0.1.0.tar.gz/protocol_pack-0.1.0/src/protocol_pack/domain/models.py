from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal


@dataclass(frozen=True)
class WorkspaceConfig:
    """Workspace-level settings from the root manifest."""

    name: str
    layout_profile: str = "cursor.protocols_root"
    target: str = "cursor"


@dataclass(frozen=True)
class PackageMeta:
    """Package identity from a package manifest."""

    name: str
    version: str = "0.1.0"
    description: str = ""
    # Other packages (by [package].name) that must appear earlier in merge order.
    depends: tuple[str, ...] = ()


@dataclass(frozen=True)
class ProvidesSpec:
    """Glob lists relative to the package root."""

    rules: tuple[str, ...] = ()
    abstract: tuple[str, ...] = ()
    concrete_sources: tuple[str, ...] = ()
    skills: tuple[str, ...] = ()


@dataclass(frozen=True)
class WorkspacePackageSourceRef:
    """One workspace [[packages]] / [[extensions]] source (path, git, or tarball URL)."""

    kind: Literal["path", "git", "tarball"]
    path: str | None = None
    git_url: str | None = None
    git_ref: str | None = None
    # Monorepo: directory under the clone that holds protocol-pack.toml
    git_subpath: str | None = None
    tarball_url: str | None = None
    tarball_sha256: str | None = None
    # Root directory inside the extracted archive (like git_subpath)
    tarball_subpath: str | None = None


@dataclass(frozen=True)
class DeclaredPackageRef:
    """Ordered workspace declaration (packages then extensions)."""

    declaration_index: int
    source: WorkspacePackageSourceRef


@dataclass(frozen=True)
class ResolvedPackage:
    """One package in deterministic merge order after path or git resolution."""

    name: str
    root_path: Path
    meta: PackageMeta
    provides: ProvidesSpec
    # Declaration index in workspace (packages then extensions); lower = lower merge precedence.
    declaration_index: int = 0
    source_kind: Literal["path", "git", "tarball"] = "path"
    git_url: str | None = None
    git_ref: str | None = None
    git_subpath: str | None = None
    tarball_url: str | None = None
    tarball_sha256: str | None = None
    tarball_subpath: str | None = None
    # Git: commit SHA; tarball: SHA-256 hex of downloaded archive bytes
    resolved_sha: str | None = None


@dataclass(frozen=True)
class RuleAsset:
    """A rule file to emit (Phase 0: no merge; one entry per matched file)."""

    rule_id: str
    source_path: Path
    # Path relative to `.cursor/rules/` inside the staging tree.
    relative_dest: Path


@dataclass(frozen=True)
class SkillAsset:
    """A skill file or resource under Cursor project skills (`.cursor/skills/`)."""

    skill_id: str
    source_path: Path
    # Path relative to `.cursor/skills/` inside the staging tree.
    relative_dest: Path


@dataclass(frozen=True)
class ProtocolSourceAsset:
    """A concrete protocol markdown file to copy to staging."""

    source_path: Path
    relative_name: str
    # Package root that contained this file (for resolving extends paths).
    package_root: Path
    # Winning package name after merge (for provenance / reports).
    source_package: str = ""
    # When set, emitter writes this UTF-8 text instead of reading source_path.
    composed_body: str | None = None


@dataclass(frozen=True)
class BuiltTree:
    """Composer output before target-specific emit."""

    workspace: WorkspaceConfig
    rules: tuple[RuleAsset, ...] = ()
    skills: tuple[SkillAsset, ...] = ()
    protocol_sources: tuple[ProtocolSourceAsset, ...] = ()
    abstract_sources: tuple[ProtocolSourceAsset, ...] = ()


@dataclass(frozen=True)
class ResolvedGraph:
    """Ordered packages after resolution."""

    workspace: WorkspaceConfig
    packages: tuple[ResolvedPackage, ...] = field(default_factory=tuple)
