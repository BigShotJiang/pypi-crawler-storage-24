from __future__ import annotations

import logging
from typing import Annotated

import typer

from protocol_pack.cli.commands.add_cmd import register_add
from protocol_pack.cli.commands.build_cmd import register_build
from protocol_pack.cli.commands.doctor_cmd import register_doctor
from protocol_pack.cli.commands.init_cmd import register_init
from protocol_pack.cli.commands.install_cmd import register_install
from protocol_pack.cli.commands.update_cmd import register_update

app = typer.Typer(
    name="protocol-pack",
    help="Resolve, compose, stage, and install agent protocol packs (Cursor target).",
    no_args_is_help=True,
)


def _configure_logging(verbose: bool) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(level=level, format="%(levelname)s %(name)s: %(message)s")


@app.callback()
def _main_callback(
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable debug logging."),
    ] = False,
) -> None:
    _configure_logging(verbose)


register_build(app)
register_init(app)
register_doctor(app)
register_install(app)
register_add(app)
register_update(app)


def main() -> None:
    app()


if __name__ == "__main__":
    main()
