from __future__ import annotations

import logging
from pathlib import Path
from typing import Annotated

import typer

from protocol_pack.application.build_pipeline import run_build
from protocol_pack.exceptions import ProtocolPackError
from protocol_pack.infrastructure.fs_local import LocalFilesystem
from protocol_pack.targets.cursor.emitter import CursorEmitter

logger = logging.getLogger(__name__)


def register_build(app: typer.Typer) -> None:
    @app.command("build")
    def build(
        workspace: Annotated[
            Path | None,
            typer.Option(
                "--workspace",
                "-w",
                help="Workspace root containing protocol-pack.toml (default: cwd).",
            ),
        ] = None,
        clean: Annotated[
            bool,
            typer.Option("--clean", help="Remove staging directory before building."),
        ] = False,
        target: Annotated[
            str,
            typer.Option("--target", "-t", help="Emit target id (Phase 0: cursor only)."),
        ] = "cursor",
        profile: Annotated[
            str | None,
            typer.Option(
                "--profile",
                "-p",
                help="Override workspace layout_profile for this build.",
            ),
        ] = None,
        offline: Annotated[
            bool,
            typer.Option("--offline", help="Disallow git network fetches (use local cache only)."),
        ] = False,
        strict: Annotated[
            bool,
            typer.Option("--strict", help="Stricter validation (reserved; no-op in Phase 0)."),
        ] = False,
        merge_report: Annotated[
            Path | None,
            typer.Option(
                "--merge-report",
                help="Write JSON merge report (rules, protocols, package provenance) to this path.",
            ),
        ] = None,
        no_validate_rules: Annotated[
            bool,
            typer.Option(
                "--no-validate-rules",
                help="Skip .mdc frontmatter checks (migration / non-Cursor rules).",
            ),
        ] = False,
        generate_router: Annotated[
            bool,
            typer.Option(
                "--generate-router",
                help="Emit protocol-pack-router.mdc (Rule-0) for the active layout profile.",
            ),
        ] = False,
        merge_router: Annotated[
            bool,
            typer.Option(
                "--merge-router",
                help="Merge generated router into staged protocol-first-workflow.mdc when present.",
            ),
        ] = False,
        emit_provenance: Annotated[
            bool,
            typer.Option(
                "--emit-provenance",
                help="Prepend HTML provenance comment to each emitted concrete protocol.",
            ),
        ] = False,
    ) -> None:
        """Resolve and emit a staging tree under .protocol-pack/build/."""
        _ = strict
        root = (workspace or Path.cwd()).resolve()
        fs = LocalFilesystem()
        if target != "cursor":
            msg = f"Unsupported target {target!r} (Phase 0: cursor only)."
            typer.secho(msg, fg=typer.colors.RED)
            raise typer.Exit(code=1)

        emitter = CursorEmitter(fs=fs)
        try:
            staging = run_build(
                root,
                fs,
                emitter,
                clean=clean,
                layout_profile_override=profile,
                offline=offline,
                merge_report_path=merge_report,
                validate_rules=not no_validate_rules,
                generate_router=generate_router,
                merge_router=merge_router,
                emit_provenance=emit_provenance,
            )
            typer.secho(f"Build complete: {staging}", fg=typer.colors.GREEN)
        except ProtocolPackError as e:
            typer.secho(str(e), fg=typer.colors.RED)
            raise typer.Exit(code=1) from e
