from __future__ import annotations

import logging
import shutil
import subprocess
import sys
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Annotated

import typer
from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from protocol_pack.exceptions import ProtocolPackError
from protocol_pack.infrastructure.cache import protocol_pack_cache_root
from protocol_pack.infrastructure.lockfile import LOCKFILE_NAME, read_lockfile_summary
from protocol_pack.resolver.resolve import resolve_workspace
from protocol_pack.targets.cursor import layout_profiles

logger = logging.getLogger(__name__)


def _cli_version() -> str:
    try:
        return version("protocol-pack")
    except PackageNotFoundError:
        return "unknown"


def register_doctor(app: typer.Typer) -> None:
    @app.command("doctor")
    def doctor(
        workspace: Annotated[
            Path | None,
            typer.Option(
                "--workspace",
                "-w",
                help="Workspace root containing protocol-pack.toml (default: cwd).",
            ),
        ] = None,
    ) -> None:
        """Print resolved package order, lockfile status, and environment hints."""
        console = Console()
        root = (workspace or Path.cwd()).resolve()
        manifest = root / "protocol-pack.toml"
        if not manifest.is_file():
            console.print(f"[red]Missing workspace manifest:[/red] {manifest}")
            raise typer.Exit(code=1)

        try:
            graph = resolve_workspace(root, offline=True)
        except ProtocolPackError as e:
            console.print(f"[red]{e}[/red]")
            raise typer.Exit(code=1) from e

        ws = graph.workspace
        profile_hint = layout_profiles.describe_layout_profile(ws.layout_profile)
        profile_line = ws.layout_profile
        if profile_hint:
            profile_line = f"{profile_line}\n[dim]{profile_hint}[/dim]"

        console.print(
            Panel.fit(
                f"[bold]protocol-pack[/bold] {_cli_version()}\n"
                f"[bold]Workspace[/bold] {ws.name}\n"
                f"[bold]Target[/bold] {ws.target}\n"
                f"[bold]Layout profile[/bold]\n{profile_line}",
                title="Workspace",
                border_style="blue",
            )
        )

        table = Table(
            title="Packages (merge order; later overrides earlier)",
            box=box.ROUNDED,
            show_lines=False,
        )
        table.add_column("#", justify="right", style="dim")
        table.add_column("Package", style="bold")
        table.add_column("Root", overflow="fold")
        table.add_column("Source", style="cyan")
        table.add_column("Git ref / SHA", style="dim", overflow="fold")

        for i, pkg in enumerate(graph.packages, start=1):
            src = pkg.source_kind
            ref_col = "—"
            if pkg.source_kind == "git":
                ref = pkg.git_ref or "?"
                sha = f" ({pkg.resolved_sha[:7]}...)" if pkg.resolved_sha else ""
                ref_col = f"{ref}{sha}"
            elif pkg.source_kind == "tarball":
                ref_col = f"sha256 {pkg.resolved_sha[:12]}…" if pkg.resolved_sha else "?"
            table.add_row(
                str(i),
                pkg.name,
                str(pkg.root_path),
                src,
                ref_col,
            )
        console.print(table)

        lock_path = root / LOCKFILE_NAME
        summary = read_lockfile_summary(root)
        if summary is None:
            console.print(
                f"[yellow]Lockfile missing[/yellow]: {lock_path} — "
                "run [bold]protocol-pack build[/bold]"
            )
        else:
            fmt, _pkgs = summary
            console.print(f"[green]Lockfile[/green] {lock_path} (format [bold]{fmt}[/bold])")

        cache_root = protocol_pack_cache_root()
        console.print(f"[dim]Cache directory[/dim] {cache_root}")

        console.print(
            f"[dim]Python[/dim] {sys.version.split()[0]} — {sys.executable}",
        )

        git = shutil.which("git")
        if git:
            try:
                out = subprocess.run(
                    [git, "--version"],
                    check=True,
                    capture_output=True,
                    text=True,
                    timeout=5,
                ).stdout.strip()
                console.print(f"[dim]Git[/dim] {out}")
            except (OSError, subprocess.TimeoutExpired, subprocess.CalledProcessError) as e:
                logger.debug("git --version failed: %s", e)
                console.print("[yellow]Git present but --version failed[/yellow]")
        else:
            console.print("[yellow]Git not found on PATH[/yellow]")
