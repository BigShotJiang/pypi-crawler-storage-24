from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from protocol_pack.exceptions import ProtocolPackError
from protocol_pack.infrastructure.lockfile import write_lockfile
from protocol_pack.resolver.resolve import resolve_workspace


def register_update(app: typer.Typer) -> None:
    @app.command("update")
    def update(
        workspace: Annotated[
            Path | None,
            typer.Option(
                "--workspace",
                "-w",
                help="Workspace root containing protocol-pack.toml (default: cwd).",
            ),
        ] = None,
        offline: Annotated[
            bool,
            typer.Option("--offline", help="Disallow git network fetches (use cache only)."),
        ] = False,
    ) -> None:
        """Re-resolve packages and rewrite protocol-pack.lock.json."""
        root = (workspace or Path.cwd()).resolve()
        manifest = root / "protocol-pack.toml"
        if not manifest.is_file():
            typer.secho(f"Missing {manifest}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        try:
            graph = resolve_workspace(root, offline=offline)
            path = write_lockfile(root, graph)
        except ProtocolPackError as e:
            typer.secho(str(e), fg=typer.colors.RED)
            raise typer.Exit(code=1) from e

        typer.secho(f"Lockfile refreshed: {path}", fg=typer.colors.GREEN)
