from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Annotated

import tomli_w
import typer

from protocol_pack.exceptions import ProtocolPackError
from protocol_pack.infrastructure.lockfile import write_lockfile
from protocol_pack.resolver.resolve import resolve_workspace


def _is_probably_git_source(source: str) -> bool:
    s = source.strip()
    return (
        s.startswith("git@")
        or s.startswith("https://")
        or s.startswith("http://")
        or s.startswith("file:")
    )


def register_add(app: typer.Typer) -> None:
    @app.command("add")
    def add(
        source: Annotated[str, typer.Argument(help="Filesystem path or git URL.")],
        workspace: Annotated[
            Path | None,
            typer.Option(
                "--workspace",
                "-w",
                help="Workspace root containing protocol-pack.toml (default: cwd).",
            ),
        ] = None,
        ref: Annotated[
            str | None,
            typer.Option("--ref", help="Git ref (branch, tag, or SHA); required for git URLs."),
        ] = None,
        path: Annotated[
            str | None,
            typer.Option(
                "--path",
                help="Package directory inside the repository (monorepo layout).",
            ),
        ] = None,
    ) -> None:
        """Append a [[packages]] entry and refresh the lockfile."""
        root = (workspace or Path.cwd()).resolve()
        manifest_path = root / "protocol-pack.toml"
        if not manifest_path.is_file():
            typer.secho(f"Missing {manifest_path}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        raw_text = manifest_path.read_text(encoding="utf-8")
        try:
            data = tomllib.loads(raw_text)
        except tomllib.TOMLDecodeError as e:
            typer.secho(f"Invalid TOML in {manifest_path}: {e}", fg=typer.colors.RED)
            raise typer.Exit(code=1) from e

        if not isinstance(data, dict):
            raise typer.BadParameter("Manifest root must be a table")

        if data.get("package") is not None:
            typer.secho(
                "This workspace uses an inline [package] block; add [[packages]] is unsupported.",
                fg=typer.colors.RED,
            )
            raise typer.Exit(code=1)

        pkgs = data.get("packages")
        if pkgs is None:
            data["packages"] = []
            pkgs = data["packages"]
        if not isinstance(pkgs, list):
            typer.secho("[packages] must be a table array.", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        git = _is_probably_git_source(source)
        if git:
            if not ref or not ref.strip():
                typer.secho("--ref is required for git sources.", fg=typer.colors.RED)
                raise typer.Exit(code=1)
            src_table: dict[str, object] = {"git": source.strip(), "ref": ref.strip()}
            if path is not None and path.strip():
                src_table["path"] = path.strip().strip("/").replace("\\", "/")
            pkgs.append({"source": src_table})
        else:
            if ref is not None or path is not None:
                typer.secho("--ref and --path apply only to git sources.", fg=typer.colors.YELLOW)
            pkgs.append({"path": source.strip()})

        manifest_path.write_text(tomli_w.dumps(data), encoding="utf-8")
        typer.secho(f"Updated {manifest_path}", fg=typer.colors.GREEN)

        try:
            graph = resolve_workspace(root)
            write_lockfile(root, graph)
        except ProtocolPackError as e:
            typer.secho(str(e), fg=typer.colors.RED)
            raise typer.Exit(code=1) from e

        typer.secho(f"Wrote {root / 'protocol-pack.lock.json'}", fg=typer.colors.GREEN)
