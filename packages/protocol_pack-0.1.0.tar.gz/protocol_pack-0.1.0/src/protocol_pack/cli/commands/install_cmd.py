from __future__ import annotations

import logging
from pathlib import Path
from typing import Annotated

import typer

from protocol_pack.application.build_pipeline import run_build
from protocol_pack.application.install_use_case import install_staged_tree
from protocol_pack.exceptions import EmitError, ProtocolPackError
from protocol_pack.infrastructure.fs_local import LocalFilesystem
from protocol_pack.infrastructure.toml_loader import load_workspace_manifest
from protocol_pack.targets.cursor.emitter import CursorEmitter

logger = logging.getLogger(__name__)


def register_install(app: typer.Typer) -> None:
    @app.command("install")
    def install(
        workspace: Annotated[
            Path | None,
            typer.Option(
                "--workspace",
                "-w",
                help="Workspace root containing protocol-pack.toml (default: cwd).",
            ),
        ] = None,
        clean: Annotated[
            bool,
            typer.Option("--clean", help="Remove staging directory before building."),
        ] = False,
        target: Annotated[
            str,
            typer.Option("--target", "-t", help="Emit target id (cursor only)."),
        ] = "cursor",
        profile: Annotated[
            str | None,
            typer.Option(
                "--profile",
                "-p",
                help="Override workspace layout_profile for this install.",
            ),
        ] = None,
        offline: Annotated[
            bool,
            typer.Option("--offline", help="Disallow git network fetches (use cache only)."),
        ] = False,
        dry_run: Annotated[
            bool,
            typer.Option("--dry-run", help="Print copy actions without writing."),
        ] = False,
        link: Annotated[
            bool,
            typer.Option(
                "--link",
                help="Symlink into workspace pointing at staging (dev); rebuild refreshes targets.",
            ),
        ] = False,
        strict: Annotated[
            bool,
            typer.Option("--strict", help="Reserved for stricter install checks."),
        ] = False,
    ) -> None:
        """Build staging, then copy into ``.cursor/`` and protocol directories."""
        _ = strict
        root = (workspace or Path.cwd()).resolve()
        manifest = root / "protocol-pack.toml"
        if not manifest.is_file():
            typer.secho(f"Missing workspace manifest: {manifest}", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        fs = LocalFilesystem()
        if target != "cursor":
            typer.secho(f"Unsupported target {target!r} (cursor only).", fg=typer.colors.RED)
            raise typer.Exit(code=1)

        emitter = CursorEmitter(fs=fs)
        try:
            staging = run_build(
                root,
                fs,
                emitter,
                clean=clean,
                layout_profile_override=profile,
                offline=offline,
            )
            _ws, _raw = load_workspace_manifest(manifest)
            layout_profile = profile if profile is not None else _ws.layout_profile
            actions = install_staged_tree(
                root,
                staging,
                layout_profile,
                dry_run=dry_run,
                use_symlinks=link,
            )
        except (EmitError, ProtocolPackError) as e:
            typer.secho(str(e), fg=typer.colors.RED)
            raise typer.Exit(code=1) from e

        for line in actions:
            typer.echo(line)
        typer.secho(
            "Install complete." if not dry_run else "Dry-run complete.",
            fg=typer.colors.GREEN,
        )
