from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from protocol_pack.targets.cursor import layout_profiles


def _init_template(layout_profile: str) -> str:
    layout_profiles.validate_layout_profile(layout_profile)
    pr, cs = (
        layout_profiles.PROFILE_PROTOCOLS_ROOT,
        layout_profiles.PROFILE_CURSOR_SUBTREE,
    )
    line_pr = f"#   {pr} — {layout_profiles.describe_layout_profile(pr)}"
    line_cs = f"#   {cs} — {layout_profiles.describe_layout_profile(cs)}"
    return f"""[workspace]
name = "my-project"
# Layout (pick one; default matches common Rule-0 examples):
{line_pr}
{line_cs}
layout_profile = "{layout_profile}"
target = "cursor"

[package]
name = "my-project.local"
version = "0.1.0"
description = "Local protocol pack"

[provides]
rules = []
abstract = []
concrete_sources = []
"""


GITIGNORE_SNIPPET = """
# protocol-pack (local staging and cache)
.protocol-pack/
"""


def register_init(app: typer.Typer) -> None:
    @app.command("init")
    def init(
        workspace: Annotated[
            Path | None,
            typer.Option(
                "--workspace",
                "-w",
                help="Directory to scaffold (default: cwd).",
            ),
        ] = None,
        force: Annotated[
            bool,
            typer.Option("--force", "-f", help="Overwrite an existing protocol-pack.toml."),
        ] = False,
        profile: Annotated[
            str,
            typer.Option(
                "--profile",
                "-p",
                help=(
                    "Workspace layout_profile: cursor.protocols_root (default) or "
                    "cursor.cursor_subtree."
                ),
            ),
        ] = layout_profiles.PROFILE_PROTOCOLS_ROOT,
    ) -> None:
        """Create protocol-pack.toml and ensure .gitignore ignores .protocol-pack/."""
        try:
            layout_profiles.validate_layout_profile(profile)
        except ValueError as e:
            typer.secho(str(e), fg=typer.colors.RED)
            raise typer.Exit(code=1) from e

        root = (workspace or Path.cwd()).resolve()
        manifest = root / "protocol-pack.toml"
        if manifest.exists() and not force:
            typer.secho(
                f"{manifest} already exists. Pass --force to overwrite.",
                fg=typer.colors.RED,
            )
            raise typer.Exit(code=1)

        manifest.write_text(_init_template(profile), encoding="utf-8")
        typer.secho(f"Wrote {manifest}", fg=typer.colors.GREEN)

        gitignore = root / ".gitignore"
        if gitignore.exists():
            text = gitignore.read_text(encoding="utf-8")
            if ".protocol-pack/" in text:
                typer.secho(".gitignore already mentions .protocol-pack/", fg=typer.colors.YELLOW)
            else:
                suffix = GITIGNORE_SNIPPET if text.endswith("\n") else f"\n{GITIGNORE_SNIPPET}"
                gitignore.write_text(text + suffix, encoding="utf-8")
                typer.secho(f"Updated {gitignore}", fg=typer.colors.GREEN)
        else:
            gitignore.write_text(GITIGNORE_SNIPPET.lstrip("\n"), encoding="utf-8")
            typer.secho(f"Created {gitignore}", fg=typer.colors.GREEN)
