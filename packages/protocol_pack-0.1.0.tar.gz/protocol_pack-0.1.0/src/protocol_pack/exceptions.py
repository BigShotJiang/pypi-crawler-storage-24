"""Error taxonomy for the CLI."""


class ProtocolPackError(Exception):
    """Base error for user-facing failures."""


class ManifestError(ProtocolPackError):
    """Invalid or unsupported manifest content."""


class ResolveError(ProtocolPackError):
    """Package resolution failed."""


class GitError(ProtocolPackError):
    """Git subprocess or configuration failure."""


class CompositionError(ProtocolPackError):
    """Merge / composition conflict or invariant violation."""


class EmitError(ProtocolPackError):
    """Staging / emit step failed."""
