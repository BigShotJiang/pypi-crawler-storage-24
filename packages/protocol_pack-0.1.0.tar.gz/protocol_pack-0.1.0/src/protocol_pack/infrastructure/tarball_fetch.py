from __future__ import annotations

import hashlib
import io
import json
import shutil
import sys
import tarfile
import zipfile
from collections.abc import Callable
from pathlib import Path

from protocol_pack.exceptions import ResolveError
from protocol_pack.infrastructure.cache import tarball_cache_dir

_META = "resolved.json"


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def extract_archive_to(data: bytes, dest: Path) -> None:
    """Extract ``.zip`` or ``.tar.gz`` / ``.tgz`` bytes into ``dest``."""
    if len(data) >= 4 and data[:4] == b"PK\x03\x04":
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            zf.extractall(dest)
        return
    if len(data) >= 2 and data[:2] == b"\x1f\x8b":
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as tf:
            _tar_extractall(tf, dest)
        return
    try:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:*") as tf:
            _tar_extractall(tf, dest)
    except tarfile.TarError as e:
        raise ResolveError(f"Unsupported or corrupt archive (use .zip or .tar.gz): {e}") from e


def _tar_extractall(tf: tarfile.TarFile, dest: Path) -> None:
    if sys.version_info >= (3, 12):
        tf.extractall(dest, filter="data")
    else:
        tf.extractall(dest)


def _find_manifest_parent(extract_root: Path, manifest_name: str) -> Path:
    cands = sorted(
        extract_root.rglob(manifest_name),
        key=lambda p: len(p.parts),
    )
    if not cands:
        raise ResolveError(f"No {manifest_name!r} found in extracted archive under {extract_root}")
    return cands[0].parent.resolve()


def default_http_fetch(url: str) -> bytes:
    import httpx

    with httpx.Client(follow_redirects=True, timeout=120.0) as client:
        r = client.get(url)
        r.raise_for_status()
        return r.content


def ensure_tarball_resolved(
    url: str,
    *,
    tarball_subpath: str | None,
    expected_sha256: str | None,
    offline: bool,
    fetch: Callable[[str], bytes],
    manifest_name: str = "protocol-pack.toml",
) -> tuple[Path, str]:
    """
    Download (unless cached), verify optional sha256, extract, return package root + content hash.
    """
    cache_base = tarball_cache_dir(url)
    meta_path = cache_base / _META
    extract_root = cache_base / "extracted"

    if meta_path.is_file() and extract_root.is_dir():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            meta = {}
        pr = meta.get("package_root")
        sh = meta.get("sha256")
        if isinstance(pr, str) and isinstance(sh, str):
            pack_path = Path(pr)
            mf = pack_path / manifest_name
            if pack_path.is_dir() and mf.is_file():
                if expected_sha256 is None or sh.lower() == expected_sha256.lower():
                    return pack_path.resolve(), sh

    if offline:
        raise ResolveError(
            f"Tarball cache miss for {url!r} while offline; run install once online."
        )

    data = fetch(url)
    digest = _sha256_bytes(data)
    if expected_sha256 is not None and digest.lower() != expected_sha256.lower():
        raise ResolveError(
            f"Tarball sha256 mismatch for {url!r}: expected {expected_sha256}, got {digest}"
        )

    cache_base.mkdir(parents=True, exist_ok=True)
    if extract_root.exists():
        shutil.rmtree(extract_root)
    extract_root.mkdir(parents=True)
    extract_archive_to(data, extract_root)

    if tarball_subpath:
        pack_root = (extract_root / tarball_subpath).resolve()
    else:
        pack_root = _find_manifest_parent(extract_root, manifest_name)

    if not pack_root.is_dir() or not (pack_root / manifest_name).is_file():
        raise ResolveError(
            f"Package manifest not found for tarball {url!r} at {pack_root / manifest_name}"
        )

    meta_path.write_text(
        json.dumps(
            {"sha256": digest, "package_root": str(pack_root.resolve())},
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return pack_root.resolve(), digest
