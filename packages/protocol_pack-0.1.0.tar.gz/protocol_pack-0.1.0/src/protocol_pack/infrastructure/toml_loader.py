from __future__ import annotations

import tomllib
from pathlib import Path
from typing import Any

from protocol_pack.domain.models import (
    DeclaredPackageRef,
    PackageMeta,
    ProvidesSpec,
    WorkspaceConfig,
    WorkspacePackageSourceRef,
)
from protocol_pack.exceptions import ManifestError


def load_toml_file(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    try:
        return tomllib.loads(raw.decode("utf-8"))
    except tomllib.TOMLDecodeError as e:
        raise ManifestError(f"Invalid TOML: {path}: {e}") from e


def _require_table(data: dict[str, Any], key: str, path: Path) -> dict[str, Any]:
    val = data.get(key)
    if not isinstance(val, dict):
        raise ManifestError(f"Missing or invalid [{key}] table in {path}")
    return val


def _parse_workspace(table: dict[str, Any], path: Path) -> WorkspaceConfig:
    name = table.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ManifestError(f"[workspace].name is required (non-empty string) in {path}")
    layout = table.get("layout_profile", "cursor.protocols_root")
    if not isinstance(layout, str):
        raise ManifestError(f"[workspace].layout_profile must be a string in {path}")
    target = table.get("target", "cursor")
    if not isinstance(target, str):
        raise ManifestError(f"[workspace].target must be a string in {path}")
    return WorkspaceConfig(name=name.strip(), layout_profile=layout, target=target)


def _parse_depends(table: dict[str, Any], path: Path) -> tuple[str, ...]:
    raw = table.get("depends")
    if raw is None:
        return ()
    if not isinstance(raw, list):
        raise ManifestError(f"[package].depends must be a list of strings in {path}")
    out: list[str] = []
    for item in raw:
        if not isinstance(item, str) or not item.strip():
            raise ManifestError(f"[package].depends entries must be non-empty strings in {path}")
        out.append(item.strip())
    return tuple(out)


def _parse_package_meta(table: dict[str, Any], path: Path) -> PackageMeta:
    name = table.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ManifestError(f"[package].name is required in {path}")
    version = table.get("version", "0.1.0")
    if not isinstance(version, str):
        raise ManifestError(f"[package].version must be a string in {path}")
    desc = table.get("description", "")
    if not isinstance(desc, str):
        raise ManifestError(f"[package].description must be a string in {path}")
    depends = _parse_depends(table, path)
    return PackageMeta(
        name=name.strip(),
        version=version,
        description=desc,
        depends=depends,
    )


def _parse_provides(table: dict[str, Any] | None, path: Path) -> ProvidesSpec:
    if table is None:
        return ProvidesSpec()

    def as_str_tuple(key: str) -> tuple[str, ...]:
        val = table.get(key, [])
        if val is None:
            return ()
        if not isinstance(val, list):
            raise ManifestError(f"[provides].{key} must be a list of strings in {path}")
        out: list[str] = []
        for item in val:
            if not isinstance(item, str) or not item.strip():
                raise ManifestError(f"[provides].{key} entries must be non-empty strings in {path}")
            out.append(item.strip())
        return tuple(out)

    return ProvidesSpec(
        rules=as_str_tuple("rules"),
        abstract=as_str_tuple("abstract"),
        concrete_sources=as_str_tuple("concrete_sources"),
        skills=as_str_tuple("skills"),
    )


def _parse_workspace_package_source(
    entry: dict[str, Any],
    index: int,
    manifest_path: Path,
) -> WorkspacePackageSourceRef:
    """Parse one [[packages]] / [[extensions]] table."""
    top_path = entry.get("path")
    src = entry.get("source")
    if isinstance(src, dict):
        git_url = src.get("git")
        ref = src.get("ref")
        src_path = src.get("path")
        if git_url is not None:
            if not isinstance(git_url, str) or not git_url.strip():
                raise ManifestError(
                    f"[[...]] entry {index}: source.git must be a non-empty string "
                    f"in {manifest_path}"
                )
            if not isinstance(ref, str) or not ref.strip():
                raise ManifestError(
                    f"[[...]] entry {index}: source.ref is required for git sources "
                    f"in {manifest_path}"
                )
            subpath: str | None = None
            if src_path is not None:
                if not isinstance(src_path, str) or not src_path.strip():
                    raise ManifestError(
                        f"[[...]] entry {index}: source.path (monorepo subdir) "
                        f"must be a non-empty string in {manifest_path}"
                    )
                subpath = src_path.strip().strip("/").replace("\\", "/") or None
            if top_path is not None:
                raise ManifestError(
                    f"[[...]] entry {index}: cannot mix top-level path= with source.git "
                    f"in {manifest_path}"
                )
            return WorkspacePackageSourceRef(
                kind="git",
                git_url=git_url.strip(),
                git_ref=ref.strip(),
                git_subpath=subpath,
            )
        tarball_url = src.get("url")
        if tarball_url is not None:
            if not isinstance(tarball_url, str) or not tarball_url.strip():
                raise ManifestError(
                    f"[[...]] entry {index}: source.url must be a non-empty string "
                    f"in {manifest_path}"
                )
            u = tarball_url.strip()
            if not u.startswith(("http://", "https://")):
                raise ManifestError(
                    f"[[...]] entry {index}: source.url must start with http:// or https:// "
                    f"in {manifest_path}"
                )
            if top_path is not None:
                raise ManifestError(
                    f"[[...]] entry {index}: cannot mix top-level path= with source.url "
                    f"in {manifest_path}"
                )
            sha_raw = src.get("sha256")
            sha256: str | None = None
            if sha_raw is not None:
                if not isinstance(sha_raw, str) or not sha_raw.strip():
                    raise ManifestError(
                        f"[[...]] entry {index}: source.sha256 must be a non-empty string "
                        f"in {manifest_path}"
                    )
                h = sha_raw.strip().lower()
                if len(h) != 64 or any(c not in "0123456789abcdef" for c in h):
                    raise ManifestError(
                        f"[[...]] entry {index}: source.sha256 must be 64 hex chars "
                        f"in {manifest_path}"
                    )
                sha256 = h
            subpath_tb: str | None = None
            if src_path is not None:
                if not isinstance(src_path, str) or not src_path.strip():
                    raise ManifestError(
                        f"[[...]] entry {index}: source.path (archive subdir) "
                        f"must be a non-empty string in {manifest_path}"
                    )
                subpath_tb = src_path.strip().strip("/").replace("\\", "/") or None
            return WorkspacePackageSourceRef(
                kind="tarball",
                tarball_url=u,
                tarball_sha256=sha256,
                tarball_subpath=subpath_tb,
            )
        # source.path only
        if isinstance(src_path, str) and src_path.strip():
            if top_path is not None:
                raise ManifestError(
                    f"[[...]] entry {index}: cannot set both path= and source.path "
                    f"in {manifest_path}"
                )
            return WorkspacePackageSourceRef(kind="path", path=src_path.strip())
    if isinstance(top_path, str) and top_path.strip():
        return WorkspacePackageSourceRef(kind="path", path=top_path.strip())
    raise ManifestError(
        f"[[...]] entry {index}: expected path=, source.path, source.git+ref, or source.url "
        f"in {manifest_path}"
    )


def load_workspace_manifest(path: Path) -> tuple[WorkspaceConfig, dict[str, Any]]:
    """Load root workspace manifest. Returns workspace config and raw document for resolver."""
    data = load_toml_file(path)
    ws = _parse_workspace(_require_table(data, "workspace", path), path)
    return ws, data


def load_package_manifest(path: Path) -> tuple[PackageMeta, ProvidesSpec, dict[str, Any]]:
    """Load a package manifest (workspace root or nested package)."""
    data = load_toml_file(path)
    pkg = _parse_package_meta(_require_table(data, "package", path), path)
    provides_raw = data.get("provides")
    if provides_raw is not None and not isinstance(provides_raw, dict):
        raise ManifestError(f"[provides] must be a table in {path}")
    provides = _parse_provides(provides_raw if isinstance(provides_raw, dict) else None, path)
    return pkg, provides, data


def collect_workspace_package_refs(
    data: dict[str, Any],
    manifest_path: Path,
) -> list[DeclaredPackageRef]:
    """
    Return [[packages]] then [[extensions]] in order, each with a monotonically increasing
    declaration_index (extensions win merge ties last).
    """
    out: list[DeclaredPackageRef] = []
    idx = 0
    for section in ("packages", "extensions"):
        block = data.get(section)
        if block is None:
            continue
        if not isinstance(block, list):
            raise ManifestError(f"[[{section}]] must be a list of tables in {manifest_path}")
        for i, entry in enumerate(block):
            if not isinstance(entry, dict):
                raise ManifestError(f"[[{section}]] entry {i} must be a table in {manifest_path}")
            source = _parse_workspace_package_source(entry, i, manifest_path)
            out.append(DeclaredPackageRef(declaration_index=idx, source=source))
            idx += 1
    return out


def list_package_path_refs(data: dict[str, Any], manifest_path: Path) -> list[str]:
    """Return declared [[packages]] path refs only (raises if any entry is git)."""
    paths: list[str] = []
    for section in ("packages",):
        block = data.get(section)
        if block is None:
            continue
        if not isinstance(block, list):
            raise ManifestError(f"[[{section}]] must be a list of tables in {manifest_path}")
        for i, entry in enumerate(block):
            if not isinstance(entry, dict):
                raise ManifestError(f"[[{section}]] entry {i} must be a table in {manifest_path}")
            src = _parse_workspace_package_source(entry, i, manifest_path)
            if src.kind != "path" or not src.path:
                raise ManifestError(
                    f"list_package_path_refs: non-path source in [[{section}]] at {manifest_path}"
                )
            paths.append(src.path)
    return paths


def list_extension_path_refs(data: dict[str, Any], manifest_path: Path) -> list[str]:
    """Return declared [[extensions]] path refs only (raises if any entry is git)."""
    paths: list[str] = []
    for section in ("extensions",):
        block = data.get(section)
        if block is None:
            continue
        if not isinstance(block, list):
            raise ManifestError(f"[[{section}]] must be a list of tables in {manifest_path}")
        for i, entry in enumerate(block):
            if not isinstance(entry, dict):
                raise ManifestError(f"[[{section}]] entry {i} must be a table in {manifest_path}")
            src = _parse_workspace_package_source(entry, i, manifest_path)
            if src.kind != "path" or not src.path:
                raise ManifestError(
                    f"list_extension_path_refs: non-path source in [[{section}]] at {manifest_path}"
                )
            paths.append(src.path)
    return paths


def workspace_declares_inline_package(data: dict[str, Any]) -> bool:
    """True if root manifest has a [package] table (inline workspace package)."""
    pkg = data.get("package")
    return isinstance(pkg, dict)
