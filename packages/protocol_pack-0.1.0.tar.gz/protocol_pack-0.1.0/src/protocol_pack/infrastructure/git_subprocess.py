from __future__ import annotations

import logging
import shutil
import subprocess
from pathlib import Path

from protocol_pack.exceptions import GitError

logger = logging.getLogger(__name__)


def _run_git(args: list[str], *, cwd: Path | None = None) -> str:
    try:
        proc = subprocess.run(
            args,
            cwd=cwd,
            check=False,
            capture_output=True,
            text=True,
            timeout=600,
            shell=False,
        )
    except (OSError, subprocess.TimeoutExpired) as e:
        raise GitError(f"git failed to start: {e}") from e
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "").strip()
        raise GitError(f"git {' '.join(args[1:3])}... failed ({proc.returncode}): {err}")
    return proc.stdout


class GitSubprocess:
    """Git on PATH; list argv only, no shell."""

    def ensure_clone(self, url: str, ref: str, dest: Path, *, offline: bool = False) -> str:
        """
        Ensure ``dest`` contains a checkout of ``url`` at ``ref``.

        Returns resolved commit SHA for HEAD after checkout.
        """
        if shutil.which("git") is None:
            raise GitError("git executable not found on PATH")

        dest = dest.resolve()
        git_dir = dest / ".git"
        if not git_dir.exists():
            if offline:
                raise GitError(
                    f"Offline mode: no git cache at {dest} for {url!r}; "
                    "run build without --offline once to populate cache."
                )
            dest.parent.mkdir(parents=True, exist_ok=True)
            logger.debug("git clone %s -> %s", url, dest)
            _run_git(["git", "clone", "--", url, str(dest)])
        else:
            if not offline:
                logger.debug("git fetch --all in %s", dest)
                _run_git(["git", "-C", str(dest), "fetch", "--all", "--prune"])

        # Do not pass ``--`` before ``ref``: for ref ``HEAD`` git would treat it as a path.
        _run_git(["git", "-C", str(dest), "checkout", "-q", ref])
        sha_out = _run_git(["git", "-C", str(dest), "rev-parse", "HEAD"])
        sha = sha_out.strip()
        if len(sha) < 7:
            raise GitError(f"Unexpected rev-parse output for {dest}: {sha_out!r}")
        return sha

    def get_sha(self, repo: Path) -> str:
        repo = repo.resolve()
        sha_out = _run_git(["git", "-C", str(repo), "rev-parse", "HEAD"])
        return sha_out.strip()
