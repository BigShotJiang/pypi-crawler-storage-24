from __future__ import annotations

import shutil
from collections.abc import Iterable
from pathlib import Path


class LocalFilesystem:
    """Pathlib-backed filesystem port."""

    def read_text(self, path: Path) -> str:
        return path.read_text(encoding="utf-8")

    def write_text(self, path: Path, content: str) -> None:
        self.mkdir_parent(path)
        path.write_text(content, encoding="utf-8", newline="\n")

    def mkdir_parent(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)

    def exists(self, path: Path) -> bool:
        return path.exists()

    def is_file(self, path: Path) -> bool:
        return path.is_file()

    def is_dir(self, path: Path) -> bool:
        return path.is_dir()

    def glob_files(self, root: Path, pattern: str) -> Iterable[Path]:
        if not root.is_dir():
            return ()
        return sorted(root.glob(pattern))

    def remove_tree(self, path: Path) -> None:
        if path.exists():
            shutil.rmtree(path)
