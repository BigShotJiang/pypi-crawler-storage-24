"""Adapters for filesystem, git, TOML, cache, lockfile (incremental)."""
