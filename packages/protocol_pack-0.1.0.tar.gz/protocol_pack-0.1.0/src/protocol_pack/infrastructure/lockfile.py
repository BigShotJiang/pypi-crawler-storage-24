from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from protocol_pack.domain.models import ResolvedGraph, ResolvedPackage
from protocol_pack.exceptions import ManifestError

LOCKFILE_NAME = "protocol-pack.lock.json"
LOCKFILE_FORMAT = 2


def _package_entry(workspace_root: Path, pkg: ResolvedPackage) -> dict[str, Any]:
    if pkg.source_kind == "git":
        src: dict[str, Any] = {
            "kind": "git",
            "url": pkg.git_url,
            "ref": pkg.git_ref,
            "sha": pkg.resolved_sha,
        }
        if pkg.git_subpath:
            src["path"] = pkg.git_subpath
        return {
            "name": pkg.name,
            "declaration_index": pkg.declaration_index,
            "source": src,
        }

    if pkg.source_kind == "tarball":
        src_tb: dict[str, Any] = {
            "kind": "tarball",
            "url": pkg.tarball_url,
            "sha256": pkg.resolved_sha,
        }
        if pkg.tarball_subpath:
            src_tb["path"] = pkg.tarball_subpath
        if pkg.tarball_sha256:
            src_tb["expected_sha256"] = pkg.tarball_sha256
        return {
            "name": pkg.name,
            "declaration_index": pkg.declaration_index,
            "source": src_tb,
        }

    wr = workspace_root.resolve()
    resolved = pkg.root_path.resolve()
    try:
        rel = resolved.relative_to(wr)
        path_str = rel.as_posix()
    except ValueError:
        path_str = resolved.as_posix()
    return {
        "name": pkg.name,
        "declaration_index": pkg.declaration_index,
        "source": {"kind": "path", "path": path_str},
    }


def write_lockfile(workspace_root: Path, graph: ResolvedGraph) -> Path:
    """Write ``protocol-pack.lock.json`` with the resolved path package graph."""
    path = workspace_root.resolve() / LOCKFILE_NAME
    packages = [_package_entry(workspace_root, p) for p in graph.packages]
    payload = {
        "lockfile_format": LOCKFILE_FORMAT,
        "packages": packages,
    }
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return path


def read_lockfile_summary(workspace_root: Path) -> tuple[int, list[dict[str, Any]]] | None:
    """Return (format, packages) or None if missing. Raises ManifestError on invalid JSON."""
    path = workspace_root.resolve() / LOCKFILE_NAME
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as e:
        raise ManifestError(f"Invalid lockfile JSON {path}: {e}") from e
    if not isinstance(data, dict):
        raise ManifestError(f"Lockfile root must be an object: {path}")
    fmt = data.get("lockfile_format")
    if not isinstance(fmt, int):
        raise ManifestError(f"lockfile_format must be an integer in {path}")
    pkgs = data.get("packages")
    if not isinstance(pkgs, list):
        raise ManifestError(f"packages must be a list in {path}")
    return fmt, pkgs
