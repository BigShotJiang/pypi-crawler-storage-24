from __future__ import annotations

import hashlib
import os
from pathlib import Path


def protocol_pack_cache_root() -> Path:
    """User cache root for clones and future artifacts (XDG or ~/.cache)."""
    base = os.environ.get("XDG_CACHE_HOME")
    if base:
        return Path(base) / "protocol-pack"
    return Path.home() / ".cache" / "protocol-pack"


def git_repo_cache_dir(git_url: str) -> Path:
    """Stable directory under cache for a remote URL (short hash suffix)."""
    digest = hashlib.sha256(git_url.encode("utf-8")).hexdigest()[:16]
    return protocol_pack_cache_root() / "repos" / digest


def tarball_cache_dir(tarball_url: str) -> Path:
    digest = hashlib.sha256(tarball_url.encode("utf-8")).hexdigest()[:16]
    return protocol_pack_cache_root() / "tarballs" / digest
