"""Resolve packages into a deterministic ordered graph."""
