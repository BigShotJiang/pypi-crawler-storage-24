from __future__ import annotations

from collections.abc import Callable
from pathlib import Path
from typing import Any

from protocol_pack.domain.models import (
    DeclaredPackageRef,
    ResolvedGraph,
    ResolvedPackage,
    WorkspaceConfig,
)
from protocol_pack.exceptions import ManifestError, ResolveError
from protocol_pack.infrastructure.cache import git_repo_cache_dir
from protocol_pack.infrastructure.git_subprocess import GitSubprocess
from protocol_pack.infrastructure.tarball_fetch import (
    default_http_fetch,
    ensure_tarball_resolved,
)
from protocol_pack.infrastructure.toml_loader import (
    collect_workspace_package_refs,
    list_extension_path_refs,
    list_package_path_refs,
    load_package_manifest,
    load_workspace_manifest,
    workspace_declares_inline_package,
)
from protocol_pack.ports.git import GitPort

MANIFEST_NAME = "protocol-pack.toml"


def resolve_workspace(
    workspace_root: Path,
    *,
    git_port: GitPort | None = None,
    offline: bool = False,
    tarball_fetch: Callable[[str], bytes] | None = None,
) -> ResolvedGraph:
    """
    Resolve path- and git-based packages: inline workspace package, or
    ``[[packages]]`` / ``[[extensions]]``.

    Merge order is a topological sort of [package].depends (dependency first), with stable
    tie-break: declaration order (packages then extensions), then package name.
    """
    root_manifest = workspace_root / MANIFEST_NAME
    if not root_manifest.is_file():
        raise ResolveError(f"Missing workspace manifest: {root_manifest}")

    workspace, raw = load_workspace_manifest(root_manifest)
    declared = collect_workspace_package_refs(raw, root_manifest)

    if workspace_declares_inline_package(raw) and declared:
        raise ManifestError(
            f"{root_manifest}: cannot combine [package] at workspace root with "
            "[[packages]] or [[extensions]]; use either inline package or external paths."
        )

    if not declared:
        return _resolve_inline_workspace_package(workspace_root, root_manifest, workspace)

    return _resolve_multi_package_workspace(
        workspace_root,
        root_manifest,
        workspace,
        declared,
        git_impl=git_port or GitSubprocess(),
        offline=offline,
        http_fetch=tarball_fetch or default_http_fetch,
    )


def resolve_phase0(workspace_root: Path) -> ResolvedGraph:
    """Backward-compatible alias for :func:`resolve_workspace`."""
    return resolve_workspace(workspace_root)


def _resolve_inline_workspace_package(
    workspace_root: Path,
    manifest_path: Path,
    workspace: WorkspaceConfig,
) -> ResolvedGraph:
    pkg_meta, provides, _ = load_package_manifest(manifest_path)
    node = ResolvedPackage(
        name=pkg_meta.name,
        root_path=workspace_root.resolve(),
        meta=pkg_meta,
        provides=provides,
        declaration_index=0,
    )
    return ResolvedGraph(workspace=workspace, packages=(node,))


def _assert_package_root_inside_clone(clone_root: Path, package_root: Path) -> None:
    cr = clone_root.resolve()
    pr = package_root.resolve()
    if not pr.is_relative_to(cr):
        raise ResolveError(
            f"Monorepo path escapes clone root: {package_root} not under {clone_root}"
        )


def _resolve_declared_to_node(
    workspace_root: Path,
    root_manifest: Path,
    decl: DeclaredPackageRef,
    git_impl: GitPort,
    *,
    offline: bool,
    http_fetch: Callable[[str], bytes],
) -> ResolvedPackage:
    src = decl.source
    if src.kind == "path":
        assert src.path is not None
        pack_root = (workspace_root / src.path).resolve()
        child = pack_root / MANIFEST_NAME
        if not child.is_file():
            raise ResolveError(f"Package manifest not found for path {src.path!r}: {child}")
        pkg_meta, provides, raw_child = load_package_manifest(child)
        _assert_no_nested_packages(raw_child, child, root_manifest)
        return ResolvedPackage(
            name=pkg_meta.name,
            root_path=pack_root,
            meta=pkg_meta,
            provides=provides,
            declaration_index=decl.declaration_index,
        )

    if src.kind == "git":
        assert src.git_url is not None and src.git_ref is not None
        cache_dest = git_repo_cache_dir(src.git_url)
        sha = git_impl.ensure_clone(src.git_url, src.git_ref, cache_dest, offline=offline)
        clone_root = cache_dest.resolve()
        if src.git_subpath:
            pack_root = (clone_root / src.git_subpath).resolve()
            _assert_package_root_inside_clone(clone_root, pack_root)
        else:
            pack_root = clone_root

        child = pack_root / MANIFEST_NAME
        if not child.is_file():
            raise ResolveError(
                f"Package manifest not found in git checkout {src.git_url!r} "
                f"(ref {src.git_ref!r}) at {child}"
            )
        pkg_meta, provides, raw_child = load_package_manifest(child)
        _assert_no_nested_packages(raw_child, child, root_manifest)
        return ResolvedPackage(
            name=pkg_meta.name,
            root_path=pack_root,
            meta=pkg_meta,
            provides=provides,
            declaration_index=decl.declaration_index,
            source_kind="git",
            git_url=src.git_url,
            git_ref=src.git_ref,
            git_subpath=src.git_subpath,
            resolved_sha=sha,
        )

    if src.kind == "tarball":
        assert src.tarball_url is not None
        pack_root, digest = ensure_tarball_resolved(
            src.tarball_url,
            tarball_subpath=src.tarball_subpath,
            expected_sha256=src.tarball_sha256,
            offline=offline,
            fetch=http_fetch,
        )
        child = pack_root / MANIFEST_NAME
        pkg_meta, provides, raw_child = load_package_manifest(child)
        _assert_no_nested_packages(raw_child, child, root_manifest)
        return ResolvedPackage(
            name=pkg_meta.name,
            root_path=pack_root,
            meta=pkg_meta,
            provides=provides,
            declaration_index=decl.declaration_index,
            source_kind="tarball",
            tarball_url=src.tarball_url,
            tarball_sha256=src.tarball_sha256,
            tarball_subpath=src.tarball_subpath,
            resolved_sha=digest,
        )

    raise ResolveError(f"Unsupported package source kind {src.kind!r}")


def _resolve_multi_package_workspace(
    workspace_root: Path,
    root_manifest: Path,
    workspace: WorkspaceConfig,
    declared: list[DeclaredPackageRef],
    *,
    git_impl: GitPort,
    offline: bool,
    http_fetch: Callable[[str], bytes],
) -> ResolvedGraph:
    nodes: dict[str, ResolvedPackage] = {}
    name_to_decl: dict[str, int] = {}

    for decl in declared:
        pkg = _resolve_declared_to_node(
            workspace_root,
            root_manifest,
            decl,
            git_impl,
            offline=offline,
            http_fetch=http_fetch,
        )
        name = pkg.name
        if name in nodes:
            raise ManifestError(
                f"Duplicate package name {name!r} in workspace "
                f"(declared from {root_manifest} and nested manifests)"
            )
        name_to_decl[name] = pkg.declaration_index
        nodes[name] = pkg

    for pname, pkg in nodes.items():
        for dep in pkg.meta.depends:
            if dep not in nodes:
                raise ResolveError(
                    f"Package {pname!r} depends on {dep!r}, which is not among the "
                    f"resolved workspace packages in {root_manifest}"
                )

    ordered = _topological_package_order(nodes, name_to_decl)
    return ResolvedGraph(workspace=workspace, packages=tuple(ordered))


def _topological_package_order(
    nodes: dict[str, ResolvedPackage],
    name_to_decl: dict[str, int],
) -> list[ResolvedPackage]:
    """Dependency before dependent; tie-break by declaration index then name."""
    successors: dict[str, list[str]] = {n: [] for n in nodes}
    indegree: dict[str, int] = {n: 0 for n in nodes}
    for n, pkg in nodes.items():
        for dep in pkg.meta.depends:
            successors[dep].append(n)
            indegree[n] += 1

    remaining = set(nodes)
    result: list[ResolvedPackage] = []
    while remaining:
        ready = [n for n in remaining if indegree[n] == 0]
        if not ready:
            raise ResolveError(
                "Cycle detected in [package].depends graph; fix dependency cycle and retry."
            )
        ready.sort(key=lambda n: (name_to_decl[n], n))
        u = ready[0]
        remaining.remove(u)
        result.append(nodes[u])
        for v in successors[u]:
            indegree[v] -= 1
    return result


def _assert_no_nested_packages(
    raw: dict[str, Any],
    child_manifest: Path,
    root_manifest: Path,
) -> None:
    nested_pkg = list_package_path_refs(raw, child_manifest)
    nested_ext = list_extension_path_refs(raw, child_manifest)
    if nested_pkg or nested_ext:
        raise ManifestError(
            f"Nested [[packages]]/[[extensions]] in {child_manifest} is not supported "
            f"(referenced from {root_manifest})"
        )
