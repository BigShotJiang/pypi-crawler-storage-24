"""Cursor layout profile identifiers and staging path helpers."""

PROFILE_PROTOCOLS_ROOT = "cursor.protocols_root"
PROFILE_CURSOR_SUBTREE = "cursor.cursor_subtree"

ALL_LAYOUT_PROFILES: tuple[str, ...] = (PROFILE_PROTOCOLS_ROOT, PROFILE_CURSOR_SUBTREE)

_PROFILE_DESCRIPTIONS: dict[str, str] = {
    PROFILE_PROTOCOLS_ROOT: (
        "Concrete protocols at repo root: protocols/*.md (matches common Rule-0 layouts)."
    ),
    PROFILE_CURSOR_SUBTREE: (
        "Concrete protocols under .cursor/protocols/*.md (router paths differ)."
    ),
}


def validate_layout_profile(profile: str) -> str:
    if profile not in ALL_LAYOUT_PROFILES:
        allowed = ", ".join(repr(p) for p in ALL_LAYOUT_PROFILES)
        raise ValueError(f"Unknown layout_profile {profile!r}; expected one of: {allowed}")
    return profile


def describe_layout_profile(profile: str) -> str:
    return _PROFILE_DESCRIPTIONS.get(profile, "")


def protocols_dir_under_staging(profile: str) -> str:
    """Directory (relative to staging root) for concrete protocol markdown."""
    if profile == PROFILE_CURSOR_SUBTREE:
        return ".cursor/protocols"
    if profile == PROFILE_PROTOCOLS_ROOT:
        return "protocols"
    raise ValueError(f"Unknown layout profile: {profile!r}")


def abstract_dir_under_staging(profile: str) -> str:
    """Directory for abstract contract markdown in the staging tree (mirror of common repos)."""
    base = protocols_dir_under_staging(profile)
    return f"{base}/abstract"
