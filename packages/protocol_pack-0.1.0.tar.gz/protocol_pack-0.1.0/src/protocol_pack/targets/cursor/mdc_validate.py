from __future__ import annotations

from pathlib import Path

import frontmatter  # type: ignore[import-untyped]

from protocol_pack.exceptions import EmitError


def _normalize_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


def validate_cursor_rule_mdc(path: Path, content: str) -> None:
    """
    Minimal Cursor `.mdc` checks (product design §8.3).

    Requires YAML frontmatter with a non-empty description (or title) and either
    ``alwaysApply: true`` or non-empty ``globs``.
    """
    text = _normalize_newlines(content).lstrip("\ufeff")
    if not text.startswith("---"):
        raise EmitError(
            f"{path}: .mdc must begin with YAML frontmatter (opening ---). "
            "Use `protocol-pack build --no-validate-rules` to skip."
        )

    try:
        post = frontmatter.loads(text)
    except Exception as e:
        raise EmitError(f"{path}: invalid YAML frontmatter in .mdc: {e}") from e

    meta = post.metadata
    if not isinstance(meta, dict) or not meta:
        raise EmitError(f"{path}: .mdc frontmatter must be a non-empty YAML mapping")

    desc = meta.get("description")
    if desc is None:
        desc = meta.get("title")
    if not isinstance(desc, str) or not desc.strip():
        raise EmitError(
            f"{path}: .mdc frontmatter needs non-empty 'description' (or legacy 'title')"
        )

    always = meta.get("alwaysApply")
    globs = meta.get("globs")
    has_always = always is True
    has_globs = _globs_non_empty(globs)
    if not has_always and not has_globs:
        raise EmitError(
            f"{path}: .mdc frontmatter needs alwaysApply: true or non-empty globs "
            "(Cursor needs a scope for the rule)"
        )


def _globs_non_empty(globs: object) -> bool:
    if isinstance(globs, str):
        return bool(globs.strip())
    if isinstance(globs, list):
        return any(isinstance(g, str) and g.strip() for g in globs)
    return False
