from __future__ import annotations

import json
from pathlib import Path

from protocol_pack.domain.models import BuiltTree
from protocol_pack.exceptions import EmitError
from protocol_pack.infrastructure.fs_local import LocalFilesystem
from protocol_pack.ports.filesystem import FilesystemPort
from protocol_pack.targets.cursor import layout_profiles, mdc_validate
from protocol_pack.targets.cursor.router_rule import (
    build_router_rule_mdc,
    merge_generated_router_into_mdc,
)


def normalize_newlines(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n")


class CursorEmitter:
    """Minimal Cursor target: copy rules and protocol sources into a staging tree."""

    target_id = "cursor"

    def __init__(self, fs: FilesystemPort | None = None) -> None:
        self._fs = fs or LocalFilesystem()

    def emit(
        self,
        tree: BuiltTree,
        staging_root: Path,
        profile: str,
        *,
        validate_rules: bool = True,
        generate_router: bool = False,
        merge_router: bool = False,
        emit_provenance: bool = False,
    ) -> None:
        try:
            protocols_rel = layout_profiles.protocols_dir_under_staging(profile)
            abstract_rel = layout_profiles.abstract_dir_under_staging(profile)
        except ValueError as e:
            raise EmitError(str(e)) from e

        for asset in tree.rules:
            dest = staging_root / ".cursor" / "rules" / asset.relative_dest
            content = normalize_newlines(self._fs.read_text(asset.source_path))
            if validate_rules:
                mdc_validate.validate_cursor_rule_mdc(asset.source_path, content)
            self._fs.write_text(dest, content)

        for sk in tree.skills:
            dest = staging_root / ".cursor" / "skills" / sk.relative_dest
            content = normalize_newlines(self._fs.read_text(sk.source_path))
            self._fs.write_text(dest, content)

        for src in tree.protocol_sources:
            dest = staging_root / protocols_rel / src.relative_name
            raw = (
                src.composed_body
                if src.composed_body is not None
                else self._fs.read_text(src.source_path)
            )
            content = normalize_newlines(raw)
            if emit_provenance and src.source_package:
                prov = {
                    "package": src.source_package,
                    "relative_name": src.relative_name,
                    "source_path": str(src.source_path.resolve()),
                }
                tag = json.dumps(prov, separators=(",", ":"), ensure_ascii=False)
                content = f"<!-- protocol-pack-provenance: {tag} -->\n" + content
            self._fs.write_text(dest, content)

        # Phase 0: copy abstract inputs to staging for inspection / future composition.
        for abs_asset in tree.abstract_sources:
            dest = staging_root / abstract_rel / abs_asset.relative_name
            content = normalize_newlines(self._fs.read_text(abs_asset.source_path))
            self._fs.write_text(dest, content)

        if generate_router or merge_router:
            workflow = staging_root / ".cursor" / "rules" / "protocol-first-workflow.mdc"
            if merge_router and workflow.is_file():
                cur = normalize_newlines(self._fs.read_text(workflow))
                merged = normalize_newlines(merge_generated_router_into_mdc(cur, profile))
                if validate_rules:
                    mdc_validate.validate_cursor_rule_mdc(workflow, merged)
                self._fs.write_text(workflow, merged)
            else:
                router_dest = staging_root / ".cursor" / "rules" / "protocol-pack-router.mdc"
                router_body = normalize_newlines(build_router_rule_mdc(profile))
                self._fs.write_text(router_dest, router_body)
