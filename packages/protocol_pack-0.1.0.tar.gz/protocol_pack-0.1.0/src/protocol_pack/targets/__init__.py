"""Target-specific emitters (Cursor, …)."""
