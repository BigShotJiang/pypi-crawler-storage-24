# Protocol Pack

CLI to resolve, compose, and stage **agent protocol packs** for Cursor (more targets later). Tool pointer: [`docs/protocol_pack_tool.md`](docs/protocol_pack_tool.md). Agent model (Rule-0): [`docs/agent_protocol_spec.md`](docs/agent_protocol_spec.md). Release polish: [`docs/polish_and_publish_plan.md`](docs/polish_and_publish_plan.md).

## Install

```bash
pipx install protocol-pack
# or, from a clone:
pip install -e ".[dev]"
```

## Quickstart

```bash
protocol-pack init
# Optional: protocol-pack init --profile cursor.cursor_subtree
# Edit protocol-pack.toml [provides] globs, then:
protocol-pack build
protocol-pack doctor
```

Build output is written to `.protocol-pack/build/` (adds `.protocol-pack/` to `.gitignore` on `init`).

- **`--merge-report path.json`** — JSON provenance (rules, protocols, packages).
- **`--generate-router`** — emit `protocol-pack-router.mdc` (Rule-0 text for the active layout profile).
- **`--merge-router`** — merge that router text into staged `protocol-first-workflow.mdc` when it exists (idempotent marker block).
- **`--emit-provenance`** — prepend an HTML comment with package + source path on each emitted concrete protocol.
- **`--no-validate-rules`** — skip `.mdc` frontmatter checks (legacy packs); by default rules must have valid Cursor frontmatter.
- **Tarball packages** — `source = { url = "https://.../pack.tgz" }` (zip or tar.gz), optional `sha256` and `path` (root inside archive).
- **`install --link`** — symlink installed files to the staging tree (dev).

## For pack authors

Drop-in README text for consumers: [`docs/pack_readme_authoring_snippet.md`](docs/pack_readme_authoring_snippet.md). Example CI workflow: [`docs/ci/github-actions.example.yml`](docs/ci/github-actions.example.yml).

## Status

Core CLI features described in the README are **implemented** (resolve, compose, Cursor emit, lockfile, tarball sources, router merge, provenance, skills, `install --link`). Further work is **release/packaging** and optional product hardening—see [`docs/polish_and_publish_plan.md`](docs/polish_and_publish_plan.md).

## Develop

Requires **Python 3.11+**. [`.github/workflows/ci.yml`](.github/workflows/ci.yml) runs **3.11**, **3.12**, and **3.13** on every push and pull request.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
pytest -q
ruff check src tests && ruff format --check src tests
mypy src/protocol_pack
```

## Changelog

Release notes: [`CHANGELOG.md`](CHANGELOG.md).
