"""Async HTTP client for the Prodigy REST API."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import anyio
import httpx

logger = logging.getLogger(__name__)

MAX_RETRIES = 5


@dataclass(frozen=True)
class ServerAuth:
    base_url: str
    login_url: str | None = None


class ProdigyClient:
    """Async wrapper around a Prodigy annotation server."""

    def __init__(self, server: ServerAuth | str, session: str):
        if isinstance(server, str):
            self.base_url = server.rstrip("/")
            self.login_url = None
        else:
            self.base_url = server.base_url.rstrip("/")
            self.login_url = server.login_url
        self.session = session
        self.http = httpx.AsyncClient(
            base_url=self.base_url,
            timeout=30,
            follow_redirects=True,
        )

    async def aclose(self) -> None:
        await self.http.aclose()

    async def __aenter__(self) -> ProdigyClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()

    async def authenticate(self) -> None:
        """Establish cookies for OIDC-protected task servers when needed."""
        if self.login_url is None:
            return
        resp = await self.http.get(self.login_url)
        resp.raise_for_status()

    async def get_config(self) -> dict[str, Any]:
        """Fetch the project config from the Prodigy server."""
        resp = await self.http.get("/project")
        resp.raise_for_status()
        return resp.json()

    async def get_tasks(self) -> tuple[list[dict[str, Any]], float]:
        """Fetch the next batch of tasks. Returns (tasks, progress)."""
        payload: dict[str, Any] = {}
        if self.login_url is None:
            payload["session_id"] = self.session
        resp = await self.http.post(
            "/get_session_questions",
            json=payload,
        )
        resp.raise_for_status()
        data = resp.json()
        progress = data.get("progress")
        return data["tasks"], progress if progress is not None else 0.0

    async def submit_answers(self, answers: list[dict[str, Any]]) -> float:
        """Submit annotated answers with retry logic. Returns progress."""
        payload: dict[str, Any] = {"answers": answers}
        if self.login_url is None:
            payload["session_id"] = self.session
        annotator_id = _shared_annotator_id(answers)
        if annotator_id is not None:
            payload["annotator_id"] = annotator_id
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                resp = await self.http.post(
                    "/give_answers",
                    json=payload,
                )
                resp.raise_for_status()
                progress = resp.json().get("progress")
                return progress if progress is not None else 0.0
            except httpx.HTTPError:
                logger.warning(
                    "Submit attempt %d/%d failed",
                    attempt,
                    MAX_RETRIES,
                    exc_info=True,
                )
                await anyio.sleep(attempt)
        logger.error("Submit failed after %d retries — dropping batch.", MAX_RETRIES)
        return 0.0


def _shared_annotator_id(answers: list[dict[str, Any]]) -> str | None:
    annotator_ids = {
        annotator_id
        for answer in answers
        if isinstance((annotator_id := answer.get("_annotator_id")), str)
        and annotator_id
    }
    if len(annotator_ids) == 1:
        return next(iter(annotator_ids))
    return None
