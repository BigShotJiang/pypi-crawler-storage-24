"""Core event loop for the annotation agent.

Top-level flow:
  1. Discover Prodigy servers for tasks assigned to this agent.
  2. Fan out: poll each server concurrently (staggered start).
  3. Each server loop: fetch tasks, annotate via LLM, submit answers.
"""

from __future__ import annotations

import inspect
import logging
from collections.abc import Awaitable, Callable
from typing import Any

import anyio
import httpx

from .client import ProdigyClient, ServerAuth
from .discovery import discover_servers
from .llm import LLM, LLMError
from .prompts import detect_task_type, format_prompt, parse_response

logger = logging.getLogger(__name__)

MAX_EMPTY_POLLS = 10
MAX_CONNECT_RETRIES = 6
STARTUP_RETRY_BASE_SECONDS = 2.0
RETRYABLE_STARTUP_STATUS_CODES = frozenset({404, 502, 503, 504})
Annotator = Callable[
    [dict[str, Any], dict[str, Any]],
    dict[str, Any] | Awaitable[dict[str, Any]],
]


async def run(llm: LLM, poll_interval: float, session: str) -> None:
    """Discover servers, annotate their tasks, repeat."""
    await run_annotator(
        lambda task, config: annotate(task, config, llm),
        poll_interval,
        session,
    )


async def run_annotator(
    annotate_task: Annotator,
    poll_interval: float,
    session: str,
) -> None:
    """Discover servers and drive one annotator across all task servers."""
    servers = await discover_servers()
    if not servers:
        logger.warning("No servers discovered — nothing to annotate.")
        return
    logger.info("Discovered %d server(s)", len(servers))
    async with anyio.create_task_group() as tg:
        for server in servers:
            tg.start_soon(poll_server, server, session, annotate_task, poll_interval)
            await anyio.sleep(poll_interval)


async def poll_server(
    server: ServerAuth,
    session: str,
    annotate_task: Annotator,
    poll_interval: float,
) -> None:
    """Fetch-annotate-submit loop for one Prodigy server."""
    async with ProdigyClient(server, session) as client:
        url = server.base_url
        # The task server may still be starting up; retry on connection errors.
        config = None
        for attempt in range(1, MAX_CONNECT_RETRIES + 1):
            try:
                await client.authenticate()
                config = await client.get_config()
                break
            except httpx.HTTPError as exc:
                if not _is_retryable_startup_error(exc):
                    raise
                logger.warning(
                    "[%s] Startup probe failed (attempt %d/%d), retrying…",
                    url,
                    attempt,
                    MAX_CONNECT_RETRIES,
                    exc_info=True,
                )
                await anyio.sleep(_startup_retry_delay_seconds(poll_interval, attempt))
        if config is None:
            logger.error(
                "[%s] Could not connect after %d attempts, giving up.",
                url,
                MAX_CONNECT_RETRIES,
            )
            return
        empty_polls = 0
        total = 0
        while empty_polls < MAX_EMPTY_POLLS:
            try:
                tasks, progress = await client.get_tasks()
            except httpx.HTTPError:
                logger.warning("[%s] Fetch failed, retrying…", url, exc_info=True)
                await anyio.sleep(poll_interval * 2)
                continue
            if not tasks:
                empty_polls += 1
                await anyio.sleep(poll_interval)
                continue
            empty_polls = 0
            answers = [
                await call_annotator(annotate_task, task, config) for task in tasks
            ]
            progress = await client.submit_answers(answers)
            total += len(answers)
            logger.info(
                "[%s] Submitted %d answers (total %d, %.0f%%)",
                url,
                len(answers),
                total,
                progress * 100,
            )
            if progress >= 1.0:
                break
            await anyio.sleep(poll_interval)
        logger.info("[%s] Done. %d annotations.", url, total)


def _is_retryable_startup_error(exc: httpx.HTTPError) -> bool:
    if isinstance(exc, httpx.ConnectError):
        return True
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in RETRYABLE_STARTUP_STATUS_CODES
    return False


def _startup_retry_delay_seconds(poll_interval: float, attempt: int) -> float:
    return max(STARTUP_RETRY_BASE_SECONDS, poll_interval) * attempt


async def call_annotator(
    annotate_task: Annotator,
    task: dict[str, Any],
    config: dict[str, Any],
) -> dict[str, Any]:
    answer = annotate_task(task, config)
    if inspect.isawaitable(answer):
        return await answer
    return answer


async def annotate(
    task: dict[str, Any], config: dict[str, Any], llm: LLM
) -> dict[str, Any]:
    """Detect task type, prompt the LLM, parse its response."""
    task_type = detect_task_type(task)
    prompt = format_prompt(task, task_type, config)
    try:
        raw = await llm.ask(prompt)
    except LLMError as exc:
        logger.warning(
            "LLM failed for task %s: %s",
            task.get("_task_hash", "?"),
            exc,
        )
        return {**task, "answer": "ignore"}
    return parse_response(raw, task, task_type, model_name=llm.model_name)
