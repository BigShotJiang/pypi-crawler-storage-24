"""Server discovery: find Prodigy servers for tasks assigned to this agent.

The agent doesn't receive task URLs directly. Instead it queries PAM
for its related tasks and resolves each task's Prodigy server URL.

Task URLs follow the path-based convention:
  ``https://{broker_address}/tasks/{task_id}``
"""

from __future__ import annotations

import logging
from typing import cast
from urllib.parse import quote
from uuid import UUID

import httpx
from prodigy_teams_recipes_sdk.prodigy_teams_pam_sdk.client.full_client import Client
from prodigy_teams_recipes_sdk.prodigy_teams_pam_sdk.models import AgentDetail
from prodigy_teams_recipes_sdk.prodigy_teams_pam_sdk.recipe_client import Settings

from .client import ServerAuth

TASKS_PATH_SEGMENT = "tasks"

logger = logging.getLogger(__name__)


async def discover_servers() -> list[ServerAuth]:
    """Query PAM for tasks assigned to this agent and return their server URLs."""
    settings = Settings()
    if not settings.is_valid():
        raise RuntimeError(
            "Missing PRODIGY_TEAMS_* environment variables — "
            "is this running on the cluster?"
        )
    pam = await Client.from_job_token(settings.pam_host, settings.job_token)
    agent = cast(AgentDetail, await pam.agent.read_async(id=settings.job_id))
    task_ids: list[UUID] = agent.related_tasks
    if not task_ids:
        logger.info("Agent has no related tasks.")
        return []
    broker = await pam.broker.read_async(id=settings.broker_id)
    broker_token = await _get_broker_token(
        pam_host=settings.pam_host,
        broker_address=broker.address,
        pam_access_token=pam.access_token,
    )
    urls: list[ServerAuth] = []
    for task_id in task_ids:
        url = _task_url(broker.address, task_id)
        try:
            login_url = await _task_login_url(
                broker_address=broker.address,
                broker_token=broker_token,
                task_id=task_id,
            )
        except httpx.ReadTimeout:
            logger.warning(
                "Skipping task %s for agent discovery: broker prodigy-login timed out",
                task_id,
            )
            continue
        except httpx.HTTPStatusError as exc:
            if exc.response.status_code in {404, 503}:
                logger.warning(
                    "Skipping task %s for agent discovery: broker prodigy-login returned %s",
                    task_id,
                    exc.response.status_code,
                )
                continue
            raise
        urls.append(ServerAuth(base_url=url, login_url=login_url))
    return urls


def _task_url(broker_address: str, task_id: UUID) -> str:
    """Build the task URL using the path-based convention."""
    return f"https://{broker_address}/{TASKS_PATH_SEGMENT}/{task_id}"


async def _get_broker_token(
    *,
    pam_host: str,
    broker_address: str,
    pam_access_token: str,
) -> str:
    async with httpx.AsyncClient(timeout=30.0) as http:
        response = await http.post(
            f"https://{pam_host}/api/v1/broker/token",
            headers={"Authorization": f"Bearer {pam_access_token}"},
            json={"address": f"https://{broker_address}"},
        )
        response.raise_for_status()
        pam_broker_token = response.json()["access_token"]
        exchange = await http.post(
            f"https://{broker_address}/api/v1/token/exchange",
            json={"token": pam_broker_token},
        )
        exchange.raise_for_status()
        return exchange.json()["access_token"]


async def _task_login_url(
    *,
    broker_address: str,
    broker_token: str,
    task_id: UUID,
) -> str:
    async with httpx.AsyncClient(timeout=30.0) as http:
        response = await http.get(
            f"https://{broker_address}/api/v1/jobs/prodigy-login",
            headers={"Authorization": f"Bearer {broker_token}"},
            params={"task_id": str(task_id), "wait_for_route": "false"},
        )
        response.raise_for_status()
        payload = response.json()
    task_url = str(payload["task_url"]).rstrip("/")
    login_token = quote(str(payload["login_token"]), safe="")
    return f"{task_url}/login?login_token={login_token}"
