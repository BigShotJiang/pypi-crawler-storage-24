"""Property-based tests for prodigy_teams_recipes.recipes.train."""

import dataclasses

import srsly
from hypothesis import assume, given
from hypothesis import strategies as st

from prodigy_teams_recipes.recipes.train import (
    ComponentData,
    Data,
    _parse_config_overrides,
    _parse_override,
)

from .strategies import (
    component_data,
    config_overrides_list,
    config_value_str,
    data_instance,
    invalid_override,
    json_values,
    non_json_text,
)


class TestParseOverride:
    """Properties of _parse_override."""

    @given(value=json_values)
    def test_agrees_with_json_loads(self, value):
        """_parse_override agrees with srsly.json_loads on valid JSON strings."""
        serialized = srsly.json_dumps(value)
        result = _parse_override(serialized)
        expected = srsly.json_loads(serialized)
        assert result == expected

    @given(text=non_json_text)
    def test_non_json_returns_string(self, text):
        """Non-JSON text is returned as-is (string fallback)."""
        result = _parse_override(text)
        assert result == text
        assert isinstance(result, str)

    @given(text=non_json_text)
    def test_string_fallback_idempotent(self, text):
        """Applying _parse_override twice to a non-JSON string is idempotent."""
        first = _parse_override(text)
        second = _parse_override(first)
        assert first == second

    @given(n=st.integers(min_value=-(2**53), max_value=2**53))
    def test_integers_preserved(self, n):
        """Integer values are preserved exactly through _parse_override."""
        result = _parse_override(str(n))
        assert result == n

    @given(b=st.booleans())
    def test_booleans_preserved(self, b):
        """JSON booleans (true/false) are parsed correctly."""
        result = _parse_override(srsly.json_dumps(b))
        assert result is b


class TestParseConfigOverrides:
    """Properties of _parse_config_overrides."""

    @given(overrides=config_overrides_list)
    def test_output_keys_subset_of_input_keys(self, overrides):
        """Every key in the result was present in some input override string."""
        result = _parse_config_overrides(overrides)
        input_keys = {s.split("=", 1)[0] for s in overrides}
        assert set(result.keys()) <= input_keys

    @given(overrides=config_overrides_list)
    def test_output_size_bounded(self, overrides):
        """Result has at most as many entries as input overrides (dedup by key)."""
        result = _parse_config_overrides(overrides)
        assert len(result) <= len(overrides)

    @given(overrides=config_overrides_list)
    def test_unique_keys_give_exact_count(self, overrides):
        """When all input keys are unique, result length equals input length."""
        unique_keys = {s.split("=", 1)[0] for s in overrides}
        result = _parse_config_overrides(overrides)
        assert len(result) == len(unique_keys)

    @given(overrides=config_overrides_list)
    def test_last_value_wins(self, overrides):
        """For duplicate keys, the last override's value is used."""
        result = _parse_config_overrides(overrides)
        # Build expected by iterating in order (last write wins)
        expected = {}
        for s in overrides:
            key, val = s.split("=", 1)
            expected[key] = _parse_override(val)
        for key in result:
            assert srsly.json_dumps(result[key]) == srsly.json_dumps(expected[key])

    @given(bad=invalid_override)
    def test_missing_equals_raises(self, bad):
        """Strings without '=' raise RecipeError."""
        import pytest
        from prodigy.errors import RecipeError

        with pytest.raises(RecipeError):
            _parse_config_overrides([bad])

    @given(value_str=config_value_str)
    def test_empty_key(self, value_str):
        """An override with key '' and any value still parses (no crash)."""
        # The function doesn't validate key format, just splits on '='
        result = _parse_config_overrides([f"={value_str}"])
        assert "" in result


class TestComponentDataLoad:
    """Properties of ComponentData.load()."""

    @given(cd=component_data())
    def test_training_names_length(self, cd: ComponentData):
        """Training names list has same length as training datasets."""
        train_names, _ = cd.load()
        assert len(train_names) == len(cd.training)

    @given(cd=component_data())
    def test_training_names_match(self, cd: ComponentData):
        """Training names are the dataset .name attributes in order."""
        train_names, _ = cd.load()
        expected = [str(d.name) for d in cd.training]
        assert train_names == expected

    @given(cd=component_data())
    def test_eval_none_gives_empty(self, cd: ComponentData):
        """When evaluation is None, the eval names list is empty."""
        if cd.evaluation is not None:
            assume(False)
        _, eval_names = cd.load()
        assert eval_names == []

    @given(cd=component_data())
    def test_eval_names_length(self, cd: ComponentData):
        """When evaluation is set, eval names list matches its length."""
        if cd.evaluation is None:
            assume(False)
        _, eval_names = cd.load()
        assert len(eval_names) == len(cd.evaluation)

    @given(cd=component_data())
    def test_eval_names_match(self, cd: ComponentData):
        """Eval names are the dataset .name attributes in order."""
        if cd.evaluation is None:
            assume(False)
        _, eval_names = cd.load()
        expected = [str(d.name) for d in cd.evaluation]
        assert eval_names == expected


class TestDataLoad:
    """Properties of Data.load()."""

    @given(data=data_instance())
    def test_keys_are_valid_field_names(self, data: Data):
        """All keys in the result are valid Data field names."""
        result = data.load()
        valid_names = {f.name for f in dataclasses.fields(Data)}
        assert set(result.keys()) <= valid_names

    @given(data=data_instance())
    def test_only_non_none_fields(self, data: Data):
        """Only fields that are non-None appear in the result."""
        result = data.load()
        for field in dataclasses.fields(Data):
            value = getattr(data, field.name)
            if value is None:
                assert field.name not in result
            else:
                assert field.name in result

    @given(data=data_instance())
    def test_at_least_one_key(self, data: Data):
        """data_instance strategy guarantees at least one component is set."""
        result = data.load()
        assert len(result) >= 1

    @given(data=data_instance())
    def test_values_are_tuples_of_lists(self, data: Data):
        """Each value is a (list[str], list[str]) tuple."""
        result = data.load()
        for key, (train, eval_) in result.items():
            assert isinstance(train, list)
            assert isinstance(eval_, list)
            assert all(isinstance(s, str) for s in train)
            assert all(isinstance(s, str) for s in eval_)

    @given(data=data_instance())
    def test_load_is_deterministic(self, data: Data):
        """Calling load() twice on the same Data gives identical results."""
        r1 = data.load()
        r2 = data.load()
        assert r1 == r2
