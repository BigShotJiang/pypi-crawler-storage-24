# Sero Telegram MCP

Read-only Telegram intelligence for Claude — by Serotonin.

> **This is not a bot.** Most Telegram MCP servers use the Bot API, limiting access to chats a bot has been invited to. Sero Telegram MCP uses the Telegram User API (MTProto), giving Claude read access to your full Telegram presence — every group, channel, and DM you're already in.

## Quick start

```bash
bash setup.sh
```

The setup script installs everything, authenticates your Telegram account, and configures Claude Desktop. Under 2 minutes.

## What Claude can do

All operations are **read-only**. Claude cannot send messages, modify chats, or take any action on your behalf.

### Chat discovery
- **ListDialogs** — List all chats, groups, and channels with unread counts
- **GetChat** — Detailed info about a specific chat (member count, description, admins)

### Messages
- **ListMessages** — Read messages from any chat (newest first, with unread filter)
- **SearchMessages** — Full-text search within a specific chat
- **SearchGlobal** — Search across all your chats at once
- **GetMessagesByDate** — Retrieve messages within a date range
- **GetPinnedMessages** — Get all pinned messages in a chat
- **GetMessageContext** — Get messages surrounding a specific message for context

### Members
- **GetParticipants** — List all members in a group or channel
- **GetAdmins** — List admins in a group or channel

### Contacts
- **ListContacts** — Your full Telegram address book
- **SearchContacts** — Search contacts by name or username

### User info
- **GetMe** — Your own profile information
- **GetUserStatus** — Check if a user is online/offline
- **ResolveUsername** — Convert a @username to a numeric ID

### Discovery
- **SearchPublicChats** — Find public channels, groups, and bots

### Media & metadata
- **GetMediaInfo** — Info about photos, documents, or links in a message
- **GetDrafts** — All unsent draft messages across your chats
- **GetInviteLink** — Get the invite link for a group you admin

## Use cases

- "Summarize my unread Telegram messages"
- "What's been discussed in the Moonwell community chat this week?"
- "Find any messages mentioning token launch in the last 3 days"
- "Who are the most active members in this group?"
- "Search all my chats for messages about the partnership announcement"

## Prerequisites

- Python 3.11+
- [`uv`](https://docs.astral.sh/uv/getting-started/installation/) (installed automatically by the setup script)

## Installation

### Option A: Setup script (recommended)

```bash
bash setup.sh
```

Handles everything — installs dependencies, authenticates Telegram, configures Claude Desktop.

### Option B: Manual install

```bash
# Install from PyPI
uv tool install sero-telegram-mcp

# Authenticate with Telegram
sero-telegram-mcp sign-in --api-id <your-api-id> --api-hash <your-api-hash> --phone-number <your-phone-number>
```

Then add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "sero-telegram": {
      "command": "sero-telegram-mcp",
      "args": ["run"],
      "env": {
        "TELEGRAM_API_ID": "<your-api-id>",
        "TELEGRAM_API_HASH": "<your-api-hash>"
      }
    }
  }
}
```

Restart Claude Desktop.

## Telegram API setup

Before installing, you need Telegram API credentials (one-time, 5 minutes):

1. Go to **https://my.telegram.org** and log in with your phone number
2. Enter the confirmation code Telegram sends to your device
3. Click **API development tools**
4. Fill in the form — App title and Short name can be anything
5. Click **Create application**
6. Note your **api_id** and **api_hash**

> **Important:** The api_hash is secret and Telegram will not let you revoke it. Do not post it anywhere public.

## Uninstall

```bash
sero-telegram-mcp logout        # Sign out of Telegram
uv tool uninstall sero-telegram-mcp  # Remove the tool
```

## License

MIT