from __future__ import annotations

import json
import logging
import sys
import typing as t
from datetime import datetime
from functools import singledispatch

from mcp.types import EmbeddedResource, ImageContent, TextContent, Tool
from pydantic import BaseModel, ConfigDict, Field
from telethon import custom, functions, types  # type: ignore[import-untyped]
from telethon.tl.types import (  # type: ignore[import-untyped]
    Channel,
    Chat,
    Message,
    MessageMediaDocument,
    MessageMediaPhoto,
    MessageMediaWebPage,
    User,
)

from .telegram import create_client

logger = logging.getLogger(__name__)


class ToolArgs(BaseModel):
    model_config = ConfigDict()


@singledispatch
async def tool_runner(
    args,  # noqa: ANN001
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    raise NotImplementedError(f"Unsupported type: {type(args)}")


def tool_description(args: type[ToolArgs]) -> Tool:
    return Tool(
        name=args.__name__,
        description=args.__doc__,
        inputSchema=args.model_json_schema(),
    )


def tool_args(tool: Tool, *args, **kwargs) -> ToolArgs:  # noqa: ANN002, ANN003
    return sys.modules[__name__].__dict__[tool.name](*args, **kwargs)


def _text(msg: str) -> TextContent:
    return TextContent(type="text", text=msg)


def _parse_date(value: str, *, field_name: str) -> datetime:
    try:
        return datetime.strptime(value, "%Y-%m-%d")
    except ValueError as exc:
        raise ValueError(f"{field_name} must use YYYY-MM-DD format") from exc


def _format_entity(entity: t.Any) -> str:  # noqa: ANN401
    """Format a Telethon entity into a readable string."""
    if isinstance(entity, User):
        name = f"{entity.first_name or ''} {entity.last_name or ''}".strip()
        username = f" (@{entity.username})" if entity.username else ""
        return f"id={entity.id} name='{name}'{username} bot={entity.bot or False}"
    if isinstance(entity, (Chat, Channel)):
        title = getattr(entity, "title", "Unknown")
        username = f" (@{entity.username})" if getattr(entity, "username", None) else ""
        entity_type = "channel" if isinstance(entity, Channel) else "group"
        return f"id={entity.id} title='{title}'{username} type={entity_type}"
    return f"id={getattr(entity, 'id', '?')} type={type(entity).__name__}"


def _format_message(message: Message) -> str:
    """Format a message into a readable string."""
    sender = getattr(message, "sender_id", "?")
    date = message.date.strftime("%Y-%m-%d %H:%M:%S") if message.date else "?"
    text = message.text or ""
    media = ""

    if message.media:
        if isinstance(message.media, MessageMediaPhoto):
            media = " [photo]"
        elif isinstance(message.media, MessageMediaDocument):
            media = " [document]"
        elif isinstance(message.media, MessageMediaWebPage):
            media = " [webpage]"
        else:
            media = f" [{type(message.media).__name__}]"

    if len(text) > 500:
        text = text[:500] + "..."

    return f"[{date}] sender={sender} id={message.id}{media}: {text}"


def _coerce_messages(messages: t.Any) -> list[custom.Message]:  # noqa: ANN401
    if messages is None:
        return []
    if isinstance(messages, list):
        return [message for message in messages if isinstance(message, custom.Message)]
    if isinstance(messages, custom.Message):
        return [messages]
    return []


class ListDialogs(ToolArgs):
    """List available dialogs, chats and channels. Returns names, IDs, and unread counts."""

    unread: bool = False
    archived: bool = False
    ignore_pinned: bool = False


@tool_runner.register
async def list_dialogs(args: ListDialogs) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[ListDialogs] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        async for dialog in client.iter_dialogs(archived=args.archived, ignore_pinned=args.ignore_pinned):
            if args.unread and dialog.unread_count == 0:
                continue
            response.append(
                _text(
                    f"name='{dialog.name}' id={dialog.id} "
                    f"unread={dialog.unread_count} mentions={dialog.unread_mentions_count}"
                )
            )

    return response


class GetChat(ToolArgs):
    """Get detailed information about a specific chat, group, or channel by its ID."""

    chat_id: int


@tool_runner.register
async def get_chat(args: GetChat) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetChat] args[%s]", args)

    async with create_client() as client:
        entity = await client.get_entity(args.chat_id)
        details: list[str] = [_format_entity(entity)]

        try:
                    if isinstance(entity, Channel):
                        full = await client(functions.channels.GetFullChannelRequest(entity))
                        fc = full.full_chat
                        details.append(f"about='{getattr(fc, 'about', '') or ''}'")
                        details.append(f"members={getattr(fc, 'participants_count', '?')}")
                        details.append(f"admins={getattr(fc, 'admins_count', '?')}")
                    elif isinstance(entity, Chat):
                        full = await client(functions.messages.GetFullChatRequest(entity.id))
                        fc = full.full_chat
                        details.append(f"about='{getattr(fc, 'about', '') or ''}'")
                        details.append(f"members={getattr(fc, 'participants_count', '?')}")
        except Exception:  # noqa: BLE001
                pass  # Return basic entity info without full chat details

    return [_text(" ".join(details))]


class ListMessages(ToolArgs):
    """
    List messages in a given dialog, chat or channel. Messages are listed newest to oldest.

    If `unread` is true, only unread messages are listed.
    Use `limit` to control how many messages are returned.
    """

    dialog_id: int
    unread: bool = False
    limit: int = Field(default=50, ge=1, le=100)


@tool_runner.register
async def list_messages(args: ListMessages) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[ListMessages] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        result = await client(functions.messages.GetPeerDialogsRequest(peers=[args.dialog_id]))
        if not isinstance(result, types.messages.PeerDialogs):
            return [_text(f"Dialog not found: {args.dialog_id}")]

        iter_args: dict[str, t.Any] = {"entity": args.dialog_id, "reverse": False}
        if args.unread:
            unread_count = result.dialogs[0].unread_count if result.dialogs else 0
            iter_args["limit"] = min(unread_count, args.limit)
        else:
            iter_args["limit"] = args.limit

        async for message in client.iter_messages(**iter_args):
            if isinstance(message, custom.Message) and message.text:
                response.append(_text(_format_message(message)))

    return response


class SearchMessages(ToolArgs):
    """Search for messages containing a query string within a specific chat."""

    chat_id: int
    query: str
    limit: int = Field(default=20, ge=1, le=100)


@tool_runner.register
async def search_messages(args: SearchMessages) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[SearchMessages] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        async for message in client.iter_messages(args.chat_id, search=args.query, limit=args.limit):
            if isinstance(message, custom.Message) and message.text:
                response.append(_text(_format_message(message)))

    if not response:
        return [_text(f"No messages found matching '{args.query}'")]
    return response


class SearchGlobal(ToolArgs):
    """Search for messages across all chats and channels you have access to."""

    query: str
    limit: int = Field(default=20, ge=1, le=100)


@tool_runner.register
async def search_global(args: SearchGlobal) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[SearchGlobal] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        async for message in client.iter_messages(None, search=args.query, limit=args.limit):
            if not isinstance(message, custom.Message) or not message.text:
                continue

            chat = message.chat
            if chat is None:
                try:
                    chat = await message.get_chat()
                except Exception:  # noqa: BLE001
                    chat = None

            chat_name = getattr(chat, "title", None) or getattr(chat, "first_name", "DM")
            response.append(_text(f"[{chat_name}] {_format_message(message)}"))

    if not response:
        return [_text(f"No messages found matching '{args.query}'")]
    return response


class GetMessagesByDate(ToolArgs):
    """Get messages from a chat within a date range. Dates should be YYYY-MM-DD format."""

    chat_id: int
    after: str = Field(description="Start date in YYYY-MM-DD format")
    before: str | None = Field(default=None, description="End date in YYYY-MM-DD format")
    limit: int = Field(default=50, ge=1, le=200)


@tool_runner.register
async def get_messages_by_date(
    args: GetMessagesByDate,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetMessagesByDate] args[%s]", args)
    response: list[TextContent] = []

    after_date = _parse_date(args.after, field_name="after")
    before_date = _parse_date(args.before, field_name="before") if args.before else None
    if before_date and before_date < after_date:
        raise ValueError("before must be on or after after")

    async with create_client() as client:
        async for message in client.iter_messages(
            args.chat_id,
            offset_date=before_date,
            limit=args.limit,
            reverse=True,
        ):
            if not isinstance(message, custom.Message):
                continue
            if message.date and message.date.replace(tzinfo=None) < after_date:
                continue
            if message.text:
                response.append(_text(_format_message(message)))

    if not response:
        return [_text("No messages found in date range")]
    return response


class GetPinnedMessages(ToolArgs):
    """Get all pinned messages in a chat."""

    chat_id: int


@tool_runner.register
async def get_pinned_messages(
    args: GetPinnedMessages,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetPinnedMessages] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        async for message in client.iter_messages(args.chat_id, filter=types.InputMessagesFilterPinned()):
            if isinstance(message, custom.Message):
                response.append(_text(_format_message(message)))

    if not response:
        return [_text("No pinned messages found")]
    return response


class GetMessageContext(ToolArgs):
    """Get messages around a specific message ID for context. Returns messages before and after."""

    chat_id: int
    message_id: int
    context_size: int = Field(default=10, ge=1, le=50)


@tool_runner.register
async def get_message_context(
    args: GetMessageContext,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetMessageContext] args[%s]", args)
    ids = list(range(args.message_id - args.context_size, args.message_id + args.context_size + 1))

    async with create_client() as client:
        messages = _coerce_messages(await client.get_messages(args.chat_id, ids=ids))

    response = []
    for message in sorted(messages, key=lambda item: item.id or 0):
        if not message.text:
            continue
        marker = " <<<" if message.id == args.message_id else ""
        response.append(_text(_format_message(message) + marker))

    return response or [_text("No messages found around that ID")]


class GetParticipants(ToolArgs):
    """Get the list of members or participants in a group or channel."""

    chat_id: int
    limit: int = Field(default=100, ge=1, le=500)


@tool_runner.register
async def get_participants(
    args: GetParticipants,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetParticipants] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        async for user in client.iter_participants(args.chat_id, limit=args.limit):
            response.append(_text(_format_entity(user)))

    if not response:
        return [_text("No participants found (you may not have permission to view them)")]
    return response


class GetAdmins(ToolArgs):
    """Get the list of admins in a group or channel."""

    chat_id: int


@tool_runner.register
async def get_admins(args: GetAdmins) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetAdmins] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        async for user in client.iter_participants(args.chat_id, filter=types.ChannelParticipantsAdmins()):
            response.append(_text(_format_entity(user)))

    if not response:
        return [_text("No admins found or insufficient permissions")]
    return response


class ListContacts(ToolArgs):
    """Get all contacts in your Telegram address book."""


@tool_runner.register
async def list_contacts(args: ListContacts) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[ListContacts] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        result = await client(functions.contacts.GetContactsRequest(hash=0))
        for user in result.users:
            response.append(_text(_format_entity(user)))

    if not response:
        return [_text("No contacts found")]
    return response


class SearchContacts(ToolArgs):
    """Search your contacts by name or username."""

    query: str


@tool_runner.register
async def search_contacts(
    args: SearchContacts,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[SearchContacts] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        result = await client(functions.contacts.SearchRequest(q=args.query, limit=20))
        for user in result.users:
            response.append(_text(_format_entity(user)))

    if not response:
        return [_text(f"No contacts found matching '{args.query}'")]
    return response


class GetMe(ToolArgs):
    """Get your own Telegram profile information."""


@tool_runner.register
async def get_me(args: GetMe) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetMe] args[%s]", args)

    async with create_client() as client:
        me = await client.get_me()

    return [_text(_format_entity(me))]


class GetUserStatus(ToolArgs):
    """Check the online or offline status of a user by their ID."""

    user_id: int


@tool_runner.register
async def get_user_status(
    args: GetUserStatus,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetUserStatus] args[%s]", args)

    async with create_client() as client:
        entity = await client.get_entity(args.user_id)

    if isinstance(entity, User):
        status = entity.status
        status_name = type(status).__name__ if status else "Unknown"
        return [_text(f"user={entity.id} name='{entity.first_name}' status={status_name}")]
    return [_text(f"Entity {args.user_id} is not a user")]


class ResolveUsername(ToolArgs):
    """Resolve a username to a numeric Telegram ID and entity info."""

    username: str = Field(description="Username with or without the @ symbol")


@tool_runner.register
async def resolve_username(
    args: ResolveUsername,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[ResolveUsername] args[%s]", args)
    username = args.username.lstrip("@")

    async with create_client() as client:
        entity = await client.get_entity(username)

    return [_text(_format_entity(entity))]


class SearchPublicChats(ToolArgs):
    """Search for public channels, groups, or bots by keyword."""

    query: str


@tool_runner.register
async def search_public_chats(
    args: SearchPublicChats,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[SearchPublicChats] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        result = await client(functions.contacts.SearchRequest(q=args.query, limit=20))
        for entity in [*result.users, *result.chats]:
            response.append(_text(_format_entity(entity)))

    if not response:
        return [_text(f"No public chats found matching '{args.query}'")]
    return response


class GetMediaInfo(ToolArgs):
    """Get information about media attached to a specific message."""

    chat_id: int
    message_id: int


@tool_runner.register
async def get_media_info(
    args: GetMediaInfo,
) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetMediaInfo] args[%s]", args)

    async with create_client() as client:
        message = await client.get_messages(args.chat_id, ids=args.message_id)

    messages = _coerce_messages(message)
    if not messages:
        return [_text(f"Message {args.message_id} not found")]

    selected_message = messages[0]
    if not selected_message.media:
        return [_text("No media in this message")]

    media = selected_message.media
    info: dict[str, t.Any] = {"type": type(media).__name__}

    if isinstance(media, MessageMediaPhoto):
        info["type"] = "photo"
    elif isinstance(media, MessageMediaDocument):
        document = media.document
        if document:
            info["type"] = "document"
            info["size_bytes"] = document.size
            info["mime_type"] = document.mime_type
            for attr in document.attributes:
                file_name = getattr(attr, "file_name", None)
                if file_name:
                    info["file_name"] = file_name
                    break
    elif isinstance(media, MessageMediaWebPage):
        webpage = media.webpage
        if webpage and hasattr(webpage, "url"):
            info["type"] = "webpage"
            info["url"] = webpage.url
            info["title"] = getattr(webpage, "title", "")

    return [_text(json.dumps(info, indent=2, default=str))]


class GetDrafts(ToolArgs):
    """Get all unsent draft messages across all chats."""


@tool_runner.register
async def get_drafts(args: GetDrafts) -> t.Sequence[TextContent | ImageContent | EmbeddedResource]:
    logger.info("method[GetDrafts] args[%s]", args)
    response: list[TextContent] = []

    async with create_client() as client:
        drafts = await client.get_drafts()
        for draft in drafts:
            chat_name = getattr(draft.entity, "title", None) or getattr(draft.entity, "first_name", "?")
            response.append(_text(f"chat='{chat_name}' id={draft.entity.id} text='{draft.text}'"))

    if not response:
        return [_text("No drafts found")]
    return response

