"""
DEPRECATED: Standalone FinOps argparse CLI.

Use `runbooks finops` instead. This entry point will be removed in a future release.

All FinOps functionality has been migrated to the unified `runbooks` Click CLI:
    runbooks finops dashboard       — Cost dashboard (replaces default mode)
    runbooks finops scenario        — Business scenario dispatch (replaces --scenario)
    runbooks finops sprint1         — Sprint 1 cost optimization (replaces --sprint1-analysis)
    runbooks finops optimize        — Resource optimization
    runbooks finops export          — Report export
    runbooks finops validate        — MCP cross-validation (replaces --validate-mcp)
    runbooks finops infrastructure  — Infrastructure cost analysis

Legacy flag mapping:
    --trend        → runbooks finops dashboard --trend (built-in)
    --audit        → runbooks finops dashboard --audit (built-in)
    --config-file  → runbooks finops dashboard --config-file (built-in)
    --scenario X   → runbooks finops scenario --name X
    --sprint1-analysis → runbooks finops sprint1
    --validate-mcp → runbooks finops validate
"""

import sys
import warnings

from runbooks.common.rich_utils import console


def main() -> int:
    """Deprecated entry point — delegates to `runbooks finops`."""
    warnings.warn(
        "The 'runbooks-finops' command is deprecated. Use 'runbooks finops' instead.",
        DeprecationWarning,
        stacklevel=1,
    )
    console.print("[bold yellow]WARNING:[/] 'runbooks-finops' is deprecated. Use 'runbooks finops' instead.\n")

    # Delegate to the unified CLI
    from runbooks.main import main as runbooks_main

    sys.argv[0] = "runbooks"
    sys.argv.insert(1, "finops")
    return runbooks_main(standalone_mode=False)


if __name__ == "__main__":
    sys.exit(main())
