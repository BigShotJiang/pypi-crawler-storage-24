"""
CFAT Architecture Review Manager.

Provides ArchitectureReviewManager as expected by
src/runbooks/cli/commands/cfat.py (lines 292-325).

Interface contract (from cfat.py):
    ArchitectureReviewManager(
        profile, region, workload_name, review_type,
        stakeholders=None, include_recommendations=True
    )
    .conduct_architecture_review() -> dict
        Returns: {"findings_count": int, "recommendations_count": int, ...}
"""

from datetime import datetime
from typing import Dict, List, Optional

from runbooks.common.rich_utils import print_info, print_success, print_warning


class ArchitectureReviewManager:
    """
    Architecture review manager for Well-Architected workload reviews.

    Conducts structured architecture reviews following AWS Well-Architected
    Framework principles with stakeholder collaboration support.
    """

    def __init__(
        self,
        profile: str,
        region: str = "ap-southeast-2",
        workload_name: str = "Default Workload",
        review_type: str = "milestone",
        stakeholders: Optional[List[str]] = None,
        include_recommendations: bool = True,
    ):
        """
        Initialize architecture review manager.

        Args:
            profile: AWS profile name for authentication.
            region: AWS region (default: ap-southeast-2).
            workload_name: Name of the workload under review.
            review_type: One of "initial", "milestone", "continuous".
            stakeholders: List of stakeholder names or email addresses.
            include_recommendations: Include remediation recommendations.
        """
        self.profile = profile
        self.region = region
        self.workload_name = workload_name
        self.review_type = review_type
        self.stakeholders = stakeholders or []
        self.include_recommendations = include_recommendations

    def conduct_architecture_review(self) -> Dict:
        """
        Conduct structured architecture review.

        Delegates to CloudFoundationsAssessment where available and
        adapts the output to the dict schema expected by cfat.py:
            {
                "findings_count": int,
                "recommendations_count": int,
                "review_type": str,
                "workload_name": str,
                "stakeholders": list,
                "findings": list,
                "recommendations": list,
                "timestamp": str,
            }

        Returns:
            dict with architecture review results.
        """
        print_info(f"Conducting {self.review_type} architecture review for: {self.workload_name}")
        print_info(f"Profile: {self.profile} | Region: {self.region}")
        if self.stakeholders:
            print_info(f"Stakeholders: {', '.join(self.stakeholders)}")

        findings = self._gather_findings()
        recommendations = self._generate_recommendations(findings) if self.include_recommendations else []

        print_success(f"Architecture review complete: {len(findings)} findings, {len(recommendations)} recommendations")

        return {
            "findings_count": len(findings),
            "recommendations_count": len(recommendations),
            "review_type": self.review_type,
            "workload_name": self.workload_name,
            "stakeholders": self.stakeholders,
            "findings": findings,
            "recommendations": recommendations,
            "timestamp": datetime.now().isoformat(),
        }

    def _gather_findings(self) -> List[Dict]:
        """Gather architecture findings via CloudFoundationsAssessment."""
        findings = []

        try:
            from runbooks.cfat.assessment.runner import CloudFoundationsAssessment

            engine = CloudFoundationsAssessment(profile=self.profile, region=self.region)
            report = engine.run_assessment()

            for result in report.results:
                status_val = result.status.value if hasattr(result.status, "value") else str(result.status)
                severity_val = result.severity.value if hasattr(result.severity, "value") else str(result.severity)

                findings.append(
                    {
                        "check_name": result.check_name,
                        "category": result.check_category,
                        "status": status_val,
                        "severity": severity_val,
                        "message": result.message,
                    }
                )

        except Exception as exc:
            print_warning(f"Assessment engine unavailable for review: {exc}")
            # Return a minimal informational finding so the CLI does not crash.
            findings.append(
                {
                    "check_name": "architecture_review_baseline",
                    "category": "general",
                    "status": "INFO",
                    "severity": "info",
                    "message": (
                        f"Architecture review initiated for workload '{self.workload_name}'. "
                        "Install full CFAT dependencies for detailed findings."
                    ),
                }
            )

        return findings

    def _generate_recommendations(self, findings: List[Dict]) -> List[str]:
        """Generate recommendations from findings."""
        recommendations = []

        failed_findings = [f for f in findings if f.get("status") in ("FAIL", "ERROR")]

        for finding in failed_findings:
            recommendations.append(f"Remediate {finding['check_name']} ({finding['category']}): {finding['message']}")

        # Add standard Well-Architected recommendations for the review type.
        if self.review_type == "initial":
            recommendations.append("Establish baseline security controls and monitoring before first deployment.")
        elif self.review_type == "milestone":
            recommendations.append("Validate compliance posture against milestone acceptance criteria.")
        elif self.review_type == "continuous":
            recommendations.append("Automate continuous compliance checks via AWS Config Rules.")

        return recommendations


__all__ = ["ArchitectureReviewManager"]
