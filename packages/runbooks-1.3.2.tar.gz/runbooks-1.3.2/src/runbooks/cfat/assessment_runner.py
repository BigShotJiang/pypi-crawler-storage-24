"""
CFAT Assessment Runner Adapter.

Thin adapter that exposes WellArchitectedAssessment as expected by
src/runbooks/cli/commands/cfat.py while delegating to the existing
CloudFoundationsAssessment engine in cfat/assessment/runner.py.

Interface contract (from cfat.py lines 200-235):
    WellArchitectedAssessment(
        profile, region, pillars=None, all_pillars=False,
        workload_name="Default Workload", assessment_depth="comprehensive"
    )
    .run_well_architected_assessment() -> dict
    .export_results(results: dict, format: str) -> None
"""

import json
import os
from datetime import datetime
from typing import Dict, List, Optional

from runbooks.common.rich_utils import print_info, print_success, print_warning


class WellArchitectedAssessment:
    """
    Well-Architected Framework assessment adapter.

    Wraps CloudFoundationsAssessment and adapts its AssessmentReport
    output to the dict schema expected by cfat.py:
        {
            "total_checks": int,
            "passed_checks": int,
            "failed_checks": int,
            "results": list,
        }
    """

    def __init__(
        self,
        profile: str,
        region: str = "ap-southeast-2",
        pillars: Optional[List[str]] = None,
        all_pillars: bool = False,
        workload_name: str = "Default Workload",
        assessment_depth: str = "comprehensive",
    ):
        """
        Initialize Well-Architected assessment.

        Args:
            profile: AWS profile name for authentication.
            region: AWS region (default: ap-southeast-2).
            pillars: Specific Well-Architected pillars to assess.
            all_pillars: Assess all six Well-Architected pillars.
            workload_name: Name of the workload being assessed.
            assessment_depth: One of "basic", "comprehensive", "enterprise".
        """
        self.profile = profile
        self.region = region
        self.pillars = pillars or []
        self.all_pillars = all_pillars
        self.workload_name = workload_name
        self.assessment_depth = assessment_depth

        # Lazy-import the heavy engine to keep import fast at CLI startup.
        self._engine = None

    def _get_engine(self):
        """Lazily initialise the underlying CloudFoundationsAssessment engine."""
        if self._engine is None:
            try:
                from runbooks.cfat.assessment.runner import CloudFoundationsAssessment

                self._engine = CloudFoundationsAssessment(
                    profile=self.profile,
                    region=self.region,
                )
            except Exception as exc:
                print_warning(f"CloudFoundationsAssessment engine unavailable: {exc}")
                self._engine = None
        return self._engine

    def run_well_architected_assessment(self) -> Dict:
        """
        Execute Well-Architected Framework assessment.

        Returns:
            dict with keys:
                total_checks  – int
                passed_checks – int
                failed_checks – int
                results       – list of per-check dicts
        """
        print_info(f"Starting Well-Architected assessment for workload: {self.workload_name}")
        print_info(f"Profile: {self.profile} | Region: {self.region} | Depth: {self.assessment_depth}")

        engine = self._get_engine()

        if engine is not None:
            try:
                report = engine.run_assessment()
                return self._adapt_report(report)
            except Exception as exc:
                print_warning(f"Assessment engine error: {exc}. Returning baseline results.")

        # Fallback: return a minimal valid structure so the CLI does not crash.
        return self._fallback_results()

    def _adapt_report(self, report) -> Dict:
        """Adapt AssessmentReport to the dict schema cfat.py expects."""
        summary = report.summary
        results = []

        for r in report.results:
            results.append(
                {
                    "check_name": r.check_name,
                    "check_category": r.check_category,
                    "status": r.status.value if hasattr(r.status, "value") else str(r.status),
                    "severity": r.severity.value if hasattr(r.severity, "value") else str(r.severity),
                    "message": r.message,
                    "recommendations": r.recommendations,
                    "execution_time": r.execution_time,
                }
            )

        return {
            "total_checks": summary.total_checks,
            "passed_checks": summary.passed_checks,
            "failed_checks": summary.failed_checks,
            "results": results,
            "workload_name": self.workload_name,
            "assessment_depth": self.assessment_depth,
            "pillars": self.pillars if self.pillars else ["all"],
            "timestamp": datetime.now().isoformat(),
        }

    def _fallback_results(self) -> Dict:
        """Return a safe minimal result dict when the engine is unavailable."""
        return {
            "total_checks": 0,
            "passed_checks": 0,
            "failed_checks": 0,
            "results": [],
            "workload_name": self.workload_name,
            "assessment_depth": self.assessment_depth,
            "pillars": self.pillars if self.pillars else ["all"],
            "timestamp": datetime.now().isoformat(),
            "note": "Assessment engine unavailable; install full CFAT dependencies.",
        }

    def export_results(self, results: Dict, format: str = "json") -> None:
        """
        Export assessment results to file.

        Args:
            results: Dict returned by run_well_architected_assessment().
            format:  One of "json", "csv", "pdf", "html".
        """
        workload_safe = self.workload_name.replace(" ", "_").lower()
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = f"cfat_assessment_{workload_safe}_{timestamp}"

        format_lower = format.lower()

        if format_lower == "json":
            output_file = f"{base_name}.json"
            try:
                with open(output_file, "w") as fh:
                    json.dump(results, fh, indent=2, default=str)
                print_success(f"Assessment results exported to {output_file}")
            except Exception as exc:
                print_warning(f"Failed to export JSON: {exc}")

        elif format_lower == "csv":
            output_file = f"{base_name}.csv"
            try:
                import csv

                with open(output_file, "w", newline="") as fh:
                    writer = csv.writer(fh)
                    writer.writerow(["check_name", "category", "status", "severity", "message"])
                    for r in results.get("results", []):
                        writer.writerow(
                            [
                                r.get("check_name", ""),
                                r.get("check_category", ""),
                                r.get("status", ""),
                                r.get("severity", ""),
                                r.get("message", ""),
                            ]
                        )
                print_success(f"Assessment results exported to {output_file}")
            except Exception as exc:
                print_warning(f"Failed to export CSV: {exc}")

        else:
            print_info(
                f"Export format '{format}' noted. Full {format.upper()} export requires additional dependencies."
            )
            print_info(f"JSON fallback: call export_results(results, format='json') for immediate output.")


__all__ = ["WellArchitectedAssessment"]
