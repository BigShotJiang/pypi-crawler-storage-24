"""
DEPRECATED: Direct CFAT CLI interface.

Use `runbooks cfat` instead. This entry point will be removed in a future release.
All CFAT functionality is available via the unified `runbooks` CLI.

Examples:
    runbooks cfat assess --output html --severity CRITICAL
    runbooks cfat version
    runbooks cfat status
"""

import sys
import warnings

import click


def main():
    """Deprecated entry point — delegates to `runbooks cfat`."""
    warnings.warn(
        "The 'cfat' and 'runbooks-cfat' commands are deprecated. Use 'runbooks cfat' instead.",
        DeprecationWarning,
        stacklevel=1,
    )
    click.echo(
        click.style("WARNING: ", fg="yellow", bold=True) + "'cfat' is deprecated. Use 'runbooks cfat' instead.\n"
    )

    # Delegate to the unified CLI
    from runbooks.main import main as runbooks_main

    sys.argv[0] = "runbooks"
    sys.argv.insert(1, "cfat")
    runbooks_main(standalone_mode=False)


if __name__ == "__main__":
    main()
