"""
CFAT Report Generator Adapter.

Provides CFATReportGenerator as expected by
src/runbooks/cli/commands/cfat.py (lines 378-400).

Interface contract (from cfat.py):
    CFATReportGenerator(
        profile, output_dir, executive_summary,
        include_remediation, workload_filter=None
    )
    .generate_report(format: str) -> dict

The existing HTML report engine lives in runbooks/cfat/report.py
(HTMLReportGenerator) and requires an AssessmentReport object.
This adapter bridges the CLI's flat constructor + format-dispatch
pattern to the existing engine, with graceful fallback when a
previous AssessmentReport is unavailable.
"""

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

from runbooks.common.rich_utils import print_info, print_success, print_warning


class CFATReportGenerator:
    """
    CFAT report generator with multi-format output support.

    Delegates HTML generation to HTMLReportGenerator in cfat/report.py
    when an AssessmentReport is available.  Falls back to standalone
    JSON/Markdown output for formats that do not require the full
    AssessmentReport object.
    """

    def __init__(
        self,
        profile: str,
        output_dir: str = "./cfat_reports",
        executive_summary: bool = False,
        include_remediation: bool = True,
        workload_filter: Optional[str] = None,
    ):
        """
        Initialize CFAT report generator.

        Args:
            profile: AWS profile name (used when running fresh assessment).
            output_dir: Directory for report output files.
            executive_summary: Include executive summary section.
            include_remediation: Include remediation roadmap.
            workload_filter: Filter reports by workload name.
        """
        self.profile = profile
        self.output_dir = output_dir
        self.executive_summary = executive_summary
        self.include_remediation = include_remediation
        self.workload_filter = workload_filter

        # Ensure output directory exists.
        Path(self.output_dir).mkdir(parents=True, exist_ok=True)

    def generate_report(self, format: str = "json") -> Dict:
        """
        Generate report in the specified format.

        Args:
            format: One of "pdf", "html", "markdown", "json".

        Returns:
            dict with keys:
                format        – str, the requested format
                output_file   – str, path to generated file (or None)
                status        – "success" | "partial" | "error"
                message       – human-readable status message
        """
        format_lower = format.lower()
        print_info(f"Generating CFAT report in {format_lower.upper()} format...")

        dispatch = {
            "html": self._generate_html_report,
            "json": self._generate_json_report,
            "markdown": self._generate_markdown_report,
            "pdf": self._generate_pdf_report,
        }

        handler = dispatch.get(format_lower, self._generate_json_report)
        return handler()

    # ------------------------------------------------------------------
    # Format handlers
    # ------------------------------------------------------------------

    def _generate_html_report(self) -> Dict:
        """Generate HTML report, delegating to HTMLReportGenerator."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = os.path.join(self.output_dir, f"cfat_report_{timestamp}.html")

        try:
            # Attempt to run a fresh assessment and feed it to the HTML engine.
            from runbooks.cfat.assessment.runner import CloudFoundationsAssessment
            from runbooks.cfat.report import HTMLReportGenerator

            engine = CloudFoundationsAssessment(profile=self.profile)
            report = engine.run_assessment()

            if self.workload_filter:
                print_info(f"Workload filter applied: {self.workload_filter}")

            html_gen = HTMLReportGenerator(report)
            html_gen.generate(output_file)

            print_success(f"HTML report written to {output_file}")
            return {"format": "html", "output_file": output_file, "status": "success", "message": "Report generated."}

        except Exception as exc:
            print_warning(f"HTML engine unavailable: {exc}. Generating minimal HTML.")
            return self._write_minimal_html(output_file)

    def _generate_json_report(self) -> Dict:
        """Generate JSON report with assessment metadata."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = os.path.join(self.output_dir, f"cfat_report_{timestamp}.json")

        payload: Dict = {
            "report_type": "cfat_assessment",
            "profile": self.profile,
            "generated_at": datetime.now().isoformat(),
            "executive_summary": self.executive_summary,
            "include_remediation": self.include_remediation,
            "workload_filter": self.workload_filter,
            "results": [],
        }

        try:
            from runbooks.cfat.assessment.runner import CloudFoundationsAssessment

            engine = CloudFoundationsAssessment(profile=self.profile)
            report = engine.run_assessment()
            payload["results"] = [
                {
                    "check_name": r.check_name,
                    "status": r.status.value if hasattr(r.status, "value") else str(r.status),
                    "severity": r.severity.value if hasattr(r.severity, "value") else str(r.severity),
                    "message": r.message,
                }
                for r in report.results
            ]
            payload["summary"] = {
                "total_checks": report.summary.total_checks,
                "passed_checks": report.summary.passed_checks,
                "failed_checks": report.summary.failed_checks,
            }
        except Exception as exc:
            print_warning(f"Assessment engine unavailable: {exc}")
            payload["note"] = "Install full CFAT dependencies for assessment data."

        try:
            with open(output_file, "w") as fh:
                json.dump(payload, fh, indent=2, default=str)
            print_success(f"JSON report written to {output_file}")
            return {"format": "json", "output_file": output_file, "status": "success", "message": "Report generated."}
        except Exception as exc:
            return {"format": "json", "output_file": None, "status": "error", "message": str(exc)}

    def _generate_markdown_report(self) -> Dict:
        """Generate Markdown report."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = os.path.join(self.output_dir, f"cfat_report_{timestamp}.md")

        lines = [
            "# CFAT Assessment Report",
            "",
            f"**Profile**: {self.profile}",
            f"**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        ]
        if self.workload_filter:
            lines.append(f"**Workload Filter**: {self.workload_filter}")

        lines += ["", "## Results", ""]

        try:
            from runbooks.cfat.assessment.runner import CloudFoundationsAssessment

            engine = CloudFoundationsAssessment(profile=self.profile)
            report = engine.run_assessment()
            lines.append(f"| Check | Status | Severity | Message |")
            lines.append(f"|-------|--------|----------|---------|")
            for r in report.results:
                status = r.status.value if hasattr(r.status, "value") else str(r.status)
                severity = r.severity.value if hasattr(r.severity, "value") else str(r.severity)
                lines.append(f"| {r.check_name} | {status} | {severity} | {r.message} |")
        except Exception as exc:
            print_warning(f"Assessment engine unavailable: {exc}")
            lines.append("Assessment engine unavailable. Install full CFAT dependencies.")

        try:
            with open(output_file, "w") as fh:
                fh.write("\n".join(lines))
            print_success(f"Markdown report written to {output_file}")
            return {
                "format": "markdown",
                "output_file": output_file,
                "status": "success",
                "message": "Report generated.",
            }
        except Exception as exc:
            return {"format": "markdown", "output_file": None, "status": "error", "message": str(exc)}

    def _generate_pdf_report(self) -> Dict:
        """Generate PDF report (stub — requires reportlab or weasyprint)."""
        print_info("PDF export requires 'reportlab' or 'weasyprint'. Falling back to JSON.")
        result = self._generate_json_report()
        result["format"] = "pdf"
        result["message"] = "PDF not available; JSON fallback generated. Install reportlab for PDF support."
        result["status"] = "partial"
        return result

    def _write_minimal_html(self, output_file: str) -> Dict:
        """Write a minimal HTML fallback when the full engine is unavailable."""
        html = (
            "<!DOCTYPE html><html><head><title>CFAT Report</title></head>"
            f"<body><h1>CFAT Assessment Report</h1>"
            f"<p>Profile: {self.profile}</p>"
            f"<p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>"
            "<p>Install full CFAT dependencies for complete report.</p>"
            "</body></html>"
        )
        try:
            with open(output_file, "w") as fh:
                fh.write(html)
            return {
                "format": "html",
                "output_file": output_file,
                "status": "partial",
                "message": "Minimal HTML generated; full engine unavailable.",
            }
        except Exception as exc:
            return {"format": "html", "output_file": None, "status": "error", "message": str(exc)}


__all__ = ["CFATReportGenerator"]
