"""
Shared profile types for multi-account AWS profile resolution.

This module contains pure data definitions (enums, dataclasses) used by both
profile_resolver_v2.py and any future profile resolution consumers.

Extracted from: runbooks.finops.profile_resolver_v2
Bug fix: ProfileResolutionContext.cli_flags annotation corrected from `any` to `Any`
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional


# ============================================================================
# ENUMS
# ============================================================================


class ProfileMode(Enum):
    """Profile resolution mode for dashboard execution."""

    SINGLE_ACCOUNT = "single_account"  # Single AWS account analysis
    MULTI_ACCOUNT = "multi_account"  # Multiple accounts via Organizations API

    def __str__(self) -> str:
        return self.value


class ProfileCapability(Enum):
    """AWS API capabilities for profile validation."""

    ORGANIZATIONS_READ = "organizations:ListAccounts"
    COST_EXPLORER_READ = "ce:GetCostAndUsage"
    EC2_READ = "ec2:DescribeInstances"

    def __str__(self) -> str:
        return self.value


# ============================================================================
# DATACLASSES
# ============================================================================


@dataclass
class ProfileValidationResult:
    """Structured validation result with actionable feedback."""

    passed: bool
    mode: ProfileMode
    profiles_used: Dict[str, str]  # {operation_type: profile_name}
    errors: List[str]
    warnings: List[str]
    setup_instructions: Optional[str] = None
    fallback_available: bool = False
    fallback_mode: Optional[ProfileMode] = None

    def __str__(self) -> str:
        """Human-readable summary for logging."""
        if self.passed:
            return f"Validation passed: {self.mode} mode with {len(self.profiles_used)} profiles"
        else:
            error_summary = f"Validation failed: {len(self.errors)} errors"
            if self.fallback_available:
                error_summary += f" (fallback to {self.fallback_mode} available)"
            return error_summary


@dataclass
class ProfileResolutionContext:
    """Complete context for profile resolution decision."""

    cli_flags: Dict[str, Any]  # {profile, all_profile, all_accounts} — fixed: `any` → `Any`
    env_vars: Dict[str, str]  # {AWS_PROFILE, MANAGEMENT_PROFILE, BILLING_PROFILE, ...}
    available_profiles: List[str]  # From ~/.aws/config
    detected_mode: ProfileMode
    validation_result: Optional[ProfileValidationResult] = None
