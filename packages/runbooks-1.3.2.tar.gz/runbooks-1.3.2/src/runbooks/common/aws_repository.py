"""Port/Adapter pattern for AWS service access.

Enables testing without AWS credentials by providing Protocol interfaces
and in-memory test doubles.
"""

from typing import Any, Dict, Optional, Protocol, runtime_checkable


@runtime_checkable
class CostExplorerPort(Protocol):
    """Port interface for Cost Explorer operations."""

    def get_cost_and_usage(self, **kwargs: Any) -> Dict[str, Any]:
        """Retrieve cost and usage data from AWS Cost Explorer."""
        ...


class AWSCostRepository:
    """Concrete adapter using boto3 Cost Explorer client."""

    def __init__(
        self,
        profile: Optional[str] = None,
        region: Optional[str] = None,
        endpoint_url: Optional[str] = None,
    ) -> None:
        from runbooks.common.aws_client_factory import create_cost_explorer_client

        self._client = create_cost_explorer_client(
            profile=profile,
            region=region or "ap-southeast-2",
            endpoint_url=endpoint_url,
        )

    def get_cost_and_usage(self, **kwargs: Any) -> Dict[str, Any]:
        """Delegate to boto3 Cost Explorer client."""
        return self._client.get_cost_and_usage(**kwargs)


class InMemoryCostRepository:
    """Test double for unit tests without AWS credentials."""

    def __init__(self, fixture_data: Optional[Dict[str, Any]] = None) -> None:
        self._data: Dict[str, Any] = fixture_data or {"ResultsByTime": []}

    def get_cost_and_usage(self, **kwargs: Any) -> Dict[str, Any]:
        """Return pre-loaded fixture data regardless of query parameters."""
        return self._data
