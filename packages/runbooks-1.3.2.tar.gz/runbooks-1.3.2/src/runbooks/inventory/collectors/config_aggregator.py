"""
Config Aggregator Collector - Org-wide resource discovery via AWS Config.

COS1-02: HITL runs `runbooks inventory collect --config-aggregator`
and gets EC2/RDS/S3/Lambda counts across all accounts in <30s.

Pattern: Generalized from list_rds_snapshots_aggregator.py:260-335
"""

import json
import logging
import time
from typing import Any, Dict, List, Optional

import boto3
from botocore.exceptions import ClientError

from runbooks.common.rich_utils import console

logger = logging.getLogger(__name__)

# Config resource type mapping
CONFIG_RESOURCE_TYPES = {
    "ec2": "AWS::EC2::Instance",
    "rds": "AWS::RDS::DBInstance",
    "s3": "AWS::S3::Bucket",
    "lambda": "AWS::Lambda::Function",
}


def detect_aggregator(session: boto3.Session, region: str = "ap-southeast-2") -> Optional[str]:
    """Auto-detect Config Aggregator name in management account."""
    try:
        config_client = session.client("config", region_name=region)
        response = config_client.describe_configuration_aggregators()
        aggregators = response.get("ConfigurationAggregators", [])
        if aggregators:
            name = aggregators[0]["ConfigurationAggregatorName"]
            logger.info("Auto-detected Config Aggregator: %s", name)
            return name
        return None
    except ClientError as e:
        logger.debug("Config Aggregator detection failed: %s", e)
        return None


def query_config_resources(
    session: boto3.Session,
    aggregator_name: str,
    resource_type: str,
    region: str = "ap-southeast-2",
) -> List[Dict[str, Any]]:
    """Query Config Aggregator for resources of a specific type.

    Uses select_aggregate_resource_config with SQL-like query.
    Handles pagination automatically.
    """
    config_client = session.client("config", region_name=region)

    query = f"""
    SELECT
        resourceId,
        resourceName,
        accountId,
        awsRegion,
        resourceType,
        configuration,
        tags,
        resourceCreationTime
    WHERE
        resourceType = '{resource_type}'
    """

    resources = []
    next_token = None

    while True:
        params: Dict[str, Any] = {
            "ConfigurationAggregatorName": aggregator_name,
            "Expression": query,
            "Limit": 100,
        }
        if next_token:
            params["NextToken"] = next_token

        try:
            response = config_client.select_aggregate_resource_config(**params)
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code in ("AccessDeniedException", "NoSuchConfigurationAggregatorException"):
                logger.warning("Config query failed for %s: %s", resource_type, error_code)
                return []
            raise

        for result_str in response.get("Results", []):
            try:
                resources.append(json.loads(result_str))
            except json.JSONDecodeError:
                logger.warning("Failed to parse Config result")

        next_token = response.get("NextToken")
        if not next_token:
            break

    return resources


def normalize_config_result(resource: Dict[str, Any], resource_category: str) -> Dict[str, Any]:
    """Normalize Config Aggregator result to match per-account collector output format."""
    return {
        "resource_id": resource.get("resourceId", ""),
        "resource_name": resource.get("resourceName", ""),
        "account_id": resource.get("accountId", ""),
        "region": resource.get("awsRegion", ""),
        "resource_type": resource_category,
        "source": "config-aggregator",
        "tags": resource.get("tags", {}),
        "creation_time": resource.get("resourceCreationTime", ""),
    }


def collect_via_aggregator(
    session: boto3.Session,
    aggregator_name: str,
    resource_types: Optional[List[str]] = None,
    region: str = "ap-southeast-2",
) -> Dict[str, Any]:
    """Collect resources across all accounts via Config Aggregator.

    Args:
        session: boto3 session
        aggregator_name: Config Aggregator name
        resource_types: List of short names (ec2, rds, s3, lambda). None = all.
        region: AWS region for Config API

    Returns:
        Dict with resources, summary, execution_time_seconds
    """
    start_time = time.time()

    types_to_query = resource_types or list(CONFIG_RESOURCE_TYPES.keys())
    all_resources: List[Dict[str, Any]] = []
    summary: Dict[str, Any] = {}

    console.print(f"\n[bold cyan]Config Aggregator Discovery[/] [dim](aggregator: {aggregator_name})[/]")

    for category in types_to_query:
        config_type = CONFIG_RESOURCE_TYPES.get(category)
        if not config_type:
            logger.warning("Unknown resource category: %s", category)
            continue

        try:
            raw_resources = query_config_resources(session, aggregator_name, config_type, region)
            normalized = [normalize_config_result(r, category) for r in raw_resources]
            all_resources.extend(normalized)

            accounts = {r["account_id"] for r in normalized}
            summary[category] = {
                "count": len(normalized),
                "accounts": len(accounts),
                "config_type": config_type,
            }
            console.print(
                f"  [green]v[/] {category.upper()}: {len(normalized)} resources across {len(accounts)} accounts"
            )

        except Exception as e:
            logger.error("Failed to collect %s via aggregator: %s", category, e)
            summary[category] = {"count": 0, "accounts": 0, "error": str(e)}

    execution_time = round(time.time() - start_time, 2)
    total = len(all_resources)
    total_accounts = len({r["account_id"] for r in all_resources}) if all_resources else 0

    console.print(f"[green]Total: {total} resources across {total_accounts} accounts[/] [dim]({execution_time}s)[/]")

    return {
        "resources": all_resources,
        "summary": summary,
        "total_resources": total,
        "total_accounts": total_accounts,
        "aggregator_name": aggregator_name,
        "source": "config-aggregator",
        "execution_time_seconds": execution_time,
    }
