"""
ReconNinja Plugin — VaultHound Integration
Runs VaultHound secret scanning against discovered web targets.

Drop into ReconNinja/plugins/ to enable.
Requires VaultHound installed at ~/.vaulthound/ or in PATH.
"""

PLUGIN_NAME    = "vaulthound"
PLUGIN_VERSION = "1.0"


def run(target, out_folder, result, config):
    """Run VaultHound against all discovered web URLs."""
    import subprocess
    import sys
    from pathlib import Path

    web_urls = [wf.url for wf in result.web_findings]
    if not web_urls:
        return

    vh_out = Path(out_folder) / "vaulthound"
    vh_out.mkdir(exist_ok=True)

    # Try to find vaulthound.py
    vh_path = Path.home() / ".vaulthound" / "vaulthound.py"
    if not vh_path.exists():
        result.errors.append("vaulthound plugin: VaultHound not found at ~/.vaulthound/")
        return

    for url in web_urls[:5]:  # cap at 5 URLs
        try:
            subprocess.run(
                [sys.executable, str(vh_path), "-u", url, "--output", str(vh_out), "-y",
                 "--severity", "medium", "--no-report"],
                timeout=120,
                capture_output=True,
            )
        except subprocess.TimeoutExpired:
            result.errors.append(f"vaulthound: timeout scanning {url}")
        except Exception as e:
            result.errors.append(f"vaulthound: {e}")
