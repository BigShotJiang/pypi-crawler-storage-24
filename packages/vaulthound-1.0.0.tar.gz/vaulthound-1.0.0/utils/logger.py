"""
utils/logger.py — VaultHound v1.0.0
Rich terminal logger.
"""

from __future__ import annotations

import logging
import threading
from pathlib import Path

from rich.console import Console
from rich.theme import Theme

THEME = Theme({
    "success":  "bold green",
    "danger":   "bold red",
    "warning":  "yellow",
    "info":     "cyan",
    "dim":      "dim white",
    "header":   "bold magenta",
    "phase":    "bold cyan",
    "critical": "bold red",
    "high":     "orange1",
    "medium":   "yellow",
    "low":      "green",
})

console     = Console(theme=THEME, highlight=False)
_PRINT_LOCK = threading.Lock()

log = logging.getLogger("vaulthound")
log.setLevel(logging.DEBUG)


def safe_print(msg: str) -> None:
    with _PRINT_LOCK:
        console.print(msg)


def setup_file_logger(path: Path) -> None:
    fh = logging.FileHandler(path, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    log.addHandler(fh)
