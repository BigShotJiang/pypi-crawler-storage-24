# ⚡ VaultHound

[![Version](https://img.shields.io/badge/Version-1.0.0-00d4ff?style=for-the-badge&logo=buffer&logoColor=white)](https://github.com/ExploitCraft/VaultHound/releases)
[![Python](https://img.shields.io/badge/Python-3.10+-7c3aed?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![License](https://img.shields.io/badge/License-MIT-44ff88?style=for-the-badge)](LICENSE)
[![ExploitCraft](https://img.shields.io/badge/ExploitCraft-Tool-ff6b6b?style=for-the-badge)](https://github.com/ExploitCraft)

**Secret & Credential Scanner** — Hunts API keys, passwords, tokens, and hardcoded secrets in live URLs, local directories, and git history.

> Part of the **ExploitCraft** toolkit. Pairs with [ReconNinja](https://github.com/ExploitCraft/ReconNinja) — ReconNinja finds the attack surface, VaultHound extracts the secrets buried in it.

> ⚠️ **Authorized use only.** Only scan targets you own or have explicit written permission to test.

---

## Features

- **URL Mode** — fetches HTML, JS files, API responses, and probes 15 common secret-exposing paths
- **Directory Mode** — recursively scans repos, configs, and source files across 25+ file types
- **Git History Mode** — walks commit diffs to catch secrets that were committed then deleted
- **43 detection patterns** — AWS, GCP, Azure, GitHub, Stripe, OpenAI, Anthropic, Slack, private keys, JWT, DB connection strings, and more
- **Entropy validation** — eliminates placeholder/example false positives
- **Dark-mode HTML report** — same aesthetic as ReconNinja, works standalone
- **JSON + text reports** — machine-readable output for pipeline integration
- **ReconNinja plugin** — drop `plugins/vaulthound_plugin.py` to run VaultHound as a ReconNinja phase

---

## Quick Start

```bash
git clone https://github.com/ExploitCraft/VaultHound.git
cd VaultHound
pip install rich
python3 vaulthound.py
```

---

## Usage

```bash
# Scan a live URL (HTML + JS + 15 sensitive path probes)
python3 vaulthound.py -u https://example.com

# Scan a local directory
python3 vaulthound.py -d /path/to/repo

# Scan directory + full git history
python3 vaulthound.py -d /path/to/repo --git

# Deep JS scanning (fetch all linked scripts)
python3 vaulthound.py -u https://example.com --js

# Only show critical and high findings
python3 vaulthound.py -d . --severity high

# Custom output directory
python3 vaulthound.py -d . --output /tmp/results

# Skip interactive confirmation (for scripting)
python3 vaulthound.py -d . -y
```

---

## Detection Patterns

| Category | Patterns |
|---|---|
| ☁️ Cloud | AWS Access Key, AWS Secret, GCP API Key, GCP Service Account, Azure Storage Key, Azure Connection String |
| 💳 Payment | Stripe (live/restricted), Square, PayPal/Braintree |
| 📡 Communication | Twilio, SendGrid, Mailgun, Slack (bot/user/webhook), Discord |
| 🐙 Source Control | GitHub PAT/OAuth/App Token, GitLab Token, NPM Token, PyPI Token |
| 🤖 AI/LLM | OpenAI, Anthropic/Claude, Groq, HuggingFace |
| 🗄️ Database | Connection strings (MySQL/Postgres/MongoDB/Redis), MongoDB Atlas |
| 🔑 Private Keys | RSA, EC, OpenSSH, PGP |
| 🎫 Tokens | JWT, generic API keys, generic passwords, generic tokens |
| 🌐 Infrastructure | Internal IPs, hardcoded internal URLs |

---

## Output

Reports saved to `vaulthound_reports/<target>_<timestamp>/`:

```
report.html    ← Dark-mode HTML dashboard (open in browser)
report.json    ← Machine-readable findings
report.txt     ← Plain text summary
vaulthound.log ← Full debug log
scan_config.json
```

---

## ReconNinja Integration

Use VaultHound as a ReconNinja plugin — runs automatically after web discovery:

```bash
cp plugins/vaulthound_plugin.py /path/to/ReconNinja/plugins/
python3 reconninja.py -t example.com --profile web_only -y
```

---

## Test Suite

```bash
pip install pytest
pytest tests/ -v
```

---

---

## Part of the HackerInc/ExploitCraft Ecosystem

| Tool | Description |
|------|-------------|
| [envleaks](https://github.com/ExploitCraft/envleaks) | Codebase & git history scanner |
| [gitdork](https://github.com/ExploitCraft/gitdork) | Google/Shodan dork generator |
| [wifi-passview](https://github.com/ExploitCraft/wifi-passview) | Cross-platform WiFi credential dumper |
| [ReconNinja](https://github.com/ExploitCraft/ReconNinja) | ReconNinja v6 — 21-phase recon framework |
| **VaultHound** | Secret & credential scanner (this repo) |

---

---

**Made by [ExploitCraft](https://github.com/ExploitCraft)**
