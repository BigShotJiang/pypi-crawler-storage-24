from typing import Tuple
from v0.relationalai.semantics.lqp import lqp_bundle

def mk_and(args: list[lqp_bundle.ir.Formula]) -> lqp_bundle.ir.Formula:
    # Flatten nested conjunctions
    if any(isinstance(arg, lqp_bundle.ir.Conjunction) for arg in args):
        final_args = []
        for arg in args:
            if isinstance(arg, lqp_bundle.ir.Conjunction):
                final_args.extend(arg.args)
            else:
                final_args.append(arg)
        args = final_args

    if len(args) == 1:
        return args[0]

    return lqp_bundle.ir.Conjunction(args=args, meta=None)

def mk_or(args: list[lqp_bundle.ir.Formula]) -> lqp_bundle.ir.Formula:
    # Flatten nested disjunctions
    if any(isinstance(arg, lqp_bundle.ir.Disjunction) for arg in args):
        final_args = []
        for arg in args:
            if isinstance(arg, lqp_bundle.ir.Disjunction):
                final_args.extend(arg.args)
            else:
                final_args.append(arg)
        args = final_args

    if len(args) == 1:
        return args[0]

    return lqp_bundle.ir.Disjunction(args=args, meta=None)

def mk_abstraction(vars: list[Tuple[lqp_bundle.ir.Var, lqp_bundle.ir.Type]], value: lqp_bundle.ir.Formula) -> lqp_bundle.ir.Abstraction:
    return lqp_bundle.ir.Abstraction(vars=vars, value=value, meta=None)

def mk_exists(vars: list[Tuple[lqp_bundle.ir.Var, lqp_bundle.ir.Type]], value: lqp_bundle.ir.Formula) -> lqp_bundle.ir.Formula:
    if len(vars) == 0:
        return value
    abstr = mk_abstraction(vars, value)
    return lqp_bundle.ir.Exists(body=abstr, meta=None)

def mk_specialized_value(value) -> lqp_bundle.ir.SpecializedValue:
    return lqp_bundle.ir.SpecializedValue(value=value, meta=None)

def mk_value(value) -> lqp_bundle.ir.Value:
    return lqp_bundle.ir.Value(value=value, meta=None)

def mk_type(typename: lqp_bundle.ir.TypeName, parameters: list[lqp_bundle.ir.Value]=[]) -> lqp_bundle.ir.Type:
    return lqp_bundle.ir.Type(type_name=typename, parameters=parameters, meta=None)

def mk_primitive(name: str, terms: list[lqp_bundle.ir.RelTerm]) -> lqp_bundle.ir.Primitive:
    return lqp_bundle.ir.Primitive(name=name, terms=terms, meta=None)

def mk_pragma(name: str, terms: list[lqp_bundle.ir.Var]) -> lqp_bundle.ir.Pragma:
    return lqp_bundle.ir.Pragma(name=name, terms=terms, meta=None)

def mk_attribute(name: str, args: list[lqp_bundle.ir.Value]) -> lqp_bundle.ir.Attribute:
    return lqp_bundle.ir.Attribute(name=name, args=args, meta=None)

def mk_transaction(
    epochs: list[lqp_bundle.ir.Epoch],
    configure: lqp_bundle.ir.Configure = lqp_bundle.construct_configure({}, None),
    sync = None
) -> lqp_bundle.ir.Transaction:
    return lqp_bundle.ir.Transaction(epochs=epochs, configure=configure, sync=sync, meta=None)
