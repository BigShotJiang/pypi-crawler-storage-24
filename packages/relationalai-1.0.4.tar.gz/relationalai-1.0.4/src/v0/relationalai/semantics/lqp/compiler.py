#--------------------------------------------------
# Compiler
#--------------------------------------------------

from v0.relationalai.semantics.lqp import lqp_bundle
from v0.relationalai.semantics.lqp import model2lqp
from v0.relationalai.semantics.lqp.utils import TranslationCtx, UniqueNames, ExportInfo
from v0.relationalai.semantics.lqp.passes import lqp_passes
from v0.relationalai.semantics.metamodel import ir, compiler as c

from typing import Optional

class Compiler(c.Compiler):
    def __init__(self, passes: Optional[list[c.Pass]] = None):
        super().__init__(passes if passes is not None else lqp_passes())
        self.def_names = UniqueNames()

    def do_compile(self, model: ir.Model, options:dict={}) -> tuple[Optional[ExportInfo], lqp_bundle.ir.Epoch]:
        fragment_id: bytes = options.get("fragment_id", bytes(404))
        # Reset the var context for each compilation
        # TODO: Change to unique var names per lookup
        # TODO: Have our needs realigned with NameCache?
        return model2lqp.to_lqp(model, fragment_id, TranslationCtx(self.def_names))
