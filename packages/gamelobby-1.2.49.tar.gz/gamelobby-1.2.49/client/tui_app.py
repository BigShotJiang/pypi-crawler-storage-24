"""
Textual TUI 主应用 — 极简终端风格
"""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.screen import Screen
from textual.widgets import Static, RichLog
from textual.containers import Vertical, Horizontal
from textual.binding import Binding
from textual.message import Message
from textual import work

from .config import PORT, DEFAULT_HOST
from .network import NetworkManager
from .vim_mode import VimMode, Mode
from .message_handler import (
    parse_server_message,
    LoginPrompt, LoginSuccess,
    SystemMessage, GameMessage, ChatMessage, ChatHistory,
    StatusUpdate, OnlineUsers, GameInvite,
    RoomUpdate, RoomLeave, GameQuit, LocationUpdate,
    GameEvent, ActionCommand,
)
from .game_handler import GameHandlerContext, get_handler
from .tui_layout import (
    LayoutNode, PaneNode, SplitNode,
    get_default_layout, get_game_layout, serialize, deserialize,
    all_panes, find_pane, find_module_pane,
    split_pane, close_pane, navigate, next_pane_id, resize_pane,
)
from .tui_canvas import Canvas, PaneWrapper
from .tui_widgets import ChatPanel, CommandPanel, BoardPanel, StatusPanel, OnlineUsersPanel, LoginPanel
from .module_state import ModuleStateManager
from .game_registry import get_renderer

# 导入渲染器包触发自动注册
from . import renderers  # noqa: F401
# 导入游戏处理器包触发自动注册
from . import handlers   # noqa: F401

try:
    from .config import VERSION
except ImportError:
    VERSION = None


# ═══════════════════════════════════════════════════════
#  自定义消息
# ═══════════════════════════════════════════════════════

class ServerMsg(Message):
    def __init__(self, data: dict) -> None:
        super().__init__()
        self.data = data


class Disconnected(Message):
    pass


# ═══════════════════════════════════════════════════════
#  GameScreen — NVim 风格动态窗口
# ═══════════════════════════════════════════════════════

class GameScreen(Screen):
    BINDINGS = [Binding("escape", "enter_normal", "", show=False)]

    def __init__(self, layout_data: dict | None = None, **kw):
        super().__init__(**kw)
        self.logged_in = False
        self.current_location = "lobby"
        self.current_room_id = None
        self._input_buffer = ""
        self._focused_pane_id = ""
        self._which_key = None        # None / "top" / "window" / "modules"
        self._picker_selected = 0     # 模块选择器当前选中
        # 状态层：独立于 Widget，持久化保存所有模块数据
        self.state = ModuleStateManager()
        self._layout_loaded = False  # 是否已从服务端加载布局
        # 恢复或创建默认布局
        tree = None
        if layout_data:
            tree = deserialize(layout_data)
            self._layout_loaded = True
        if tree is None:
            tree = get_default_layout()
        self._layout_tree = tree

    def compose(self) -> ComposeResult:
        yield Canvas(self._layout_tree, id="canvas")
        with Vertical(id="which-key-overlay"):
            yield Static("", id="which-key-content")
        with Horizontal(id="footer-bar"):
            yield Static(" NORMAL ", id="mode-indicator")
            yield Static("大厅", id="location-indicator")
            yield Static(f"v{VERSION}" if VERSION else "", id="connection-status")

    def on_mount(self) -> None:
        # 聚焦到第一个可输入窗格（login 或 cmd 优先）
        panes = all_panes(self._layout_tree)
        focus_id = ""
        for p in panes:
            if p.module in ('login', 'cmd'):
                focus_id = p.pane_id
                break
        if not focus_id and panes:
            focus_id = panes[0].pane_id
        if focus_id:
            self._set_focused_pane(focus_id)
        # 初始化面板标题
        self._init_panel_titles()
        # 登录阶段自动进入输入模式
        self._enter_insert()

    def _init_panel_titles(self):
        """初始化各模块面板标题并从 State 恢复内容"""
        self._restore_all_modules()

    async def _apply_saved_layout(self):
        """从服务端获取的布局重建画面"""
        await self.canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        panes = all_panes(self._layout_tree)
        for p in panes:
            if p.module == 'cmd':
                self._set_focused_pane(p.pane_id)
                return
        if panes:
            self._set_focused_pane(panes[0].pane_id)

    async def _rebuild_to_game_layout(self):
        """登录成功后从 login 面板切换到游戏布局"""
        self._layout_tree = get_game_layout()
        await self.canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        panes = all_panes(self._layout_tree)
        for p in panes:
            if p.module == 'cmd':
                self._set_focused_pane(p.pane_id)
                return
        if panes:
            self._set_focused_pane(panes[0].pane_id)

    # ── 画布与面板访问 ──

    @property
    def canvas(self) -> Canvas:
        return self.query_one("#canvas", Canvas)

    def _get_module(self, module_name: str):
        """获取指定模块的 Widget 实例"""
        return self.canvas.get_module_widget(module_name)

    def _get_pane_for_module(self, module_name: str) -> PaneNode | None:
        return find_module_pane(self._layout_tree, module_name)

    @property
    def vim(self) -> VimMode:
        return self.app.vim

    # ── 焦点管理 ──

    def _set_focused_pane(self, pane_id: str):
        self._focused_pane_id = pane_id
        canvas = self.canvas
        for p in all_panes(self._layout_tree):
            wrapper = canvas.get_pane(p.pane_id)
            if wrapper:
                if p.pane_id == pane_id:
                    wrapper.add_class("--focused")
                else:
                    wrapper.remove_class("--focused")

    def _focused_module(self) -> str | None:
        pane = find_pane(self._layout_tree, self._focused_pane_id)
        return pane.module if pane else None

    @property
    def _input_target(self) -> str:
        mod = self._focused_module()
        if mod == 'chat':
            return 'chat'
        if mod == 'cmd':
            return 'cmd'
        if mod == 'login':
            return 'login'
        return ''

    def _can_input(self) -> bool:
        return self._input_target in ('chat', 'cmd', 'login')

    # ── 模式切换 ──

    def action_enter_normal(self):
        self._hide_which_key()
        if self.vim.mode == Mode.INSERT:
            self._input_buffer = ""
            self._hide_panel_prompt()
        self.vim.enter_normal()
        self._update_mode_indicator()
        self.set_focus(None)

    def _enter_insert(self):
        if not self._can_input():
            return
        self._input_buffer = ""
        self.vim.enter_insert()
        self._update_mode_indicator()
        self._show_panel_prompt("")

    def _update_mode_indicator(self):
        indicator = self.query_one("#mode-indicator", Static)
        mode = self.vim.mode
        if mode == Mode.NORMAL:
            indicator.update(" NORMAL ")
        elif mode == Mode.INSERT:
            indicator.update(" INSERT ")

    # ── 面板内输入提示 ──

    def _show_panel_prompt(self, text: str):
        mod = self._focused_module()
        widget = self._get_module(mod) if mod else None
        if isinstance(widget, (ChatPanel, CommandPanel, LoginPanel)):
            widget.show_prompt(text)

    def _update_panel_prompt(self, text: str):
        mod = self._focused_module()
        widget = self._get_module(mod) if mod else None
        if isinstance(widget, (ChatPanel, CommandPanel, LoginPanel)):
            widget.update_prompt(text)

    def _hide_panel_prompt(self):
        for mod in ('chat', 'cmd', 'login'):
            widget = self._get_module(mod)
            if isinstance(widget, (ChatPanel, CommandPanel, LoginPanel)):
                widget.hide_prompt()

    # ── Which-key 菜单（屏幕中央浮动） ──

    def _show_which_key(self, level: str):
        from .module_registry import get_module_names, get_module_labels
        from rich.text import Text
        overlay = self.query_one("#which-key-overlay")
        content = self.query_one("#which-key-content", Static)
        lines = []
        if level == "top":
            overlay.border_title = "菜单"
            lines.append("  [b]e[/b]  模块")
            lines.append("  [b]w[/b]  窗口")
            lines.append("  [b]q[/b]  退出")
        elif level == "window":
            overlay.border_title = "窗口"
            lines.append("  [b]/[/b]      横分")
            lines.append("  [b]-[/b]      纵分")
            lines.append("  [b]h j k l[/b]  导航")
            lines.append("  [b]H / L[/b]  横向缩放")
            lines.append("  [b]J / K[/b]  纵向缩放")
            lines.append("  [b]q[/b]      关闭")
        elif level == "modules":
            overlay.border_title = "模块"
            modules = get_module_names()
            labels = get_module_labels()
            for i, mod in enumerate(modules):
                label = labels.get(mod, mod)
                if i == self._picker_selected:
                    lines.append(f"  [reverse] {label} [/]")
                else:
                    lines.append(f"    {label}")
            lines.append("")
            lines.append("  [dim]j/k 选择  Enter 确认  Esc 取消[/dim]")
        content.update("\n".join(lines))
        overlay.add_class("visible")

    def _hide_which_key(self):
        self._which_key = None
        overlay = self.query_one("#which-key-overlay")
        overlay.remove_class("visible")

    # ── 模块选择确认 ──

    def _picker_confirm(self):
        from .module_registry import get_module_names
        modules = get_module_names()
        module_name = modules[self._picker_selected]
        self._hide_which_key()
        self.call_later(self._do_open_module, module_name)

    async def _do_open_module(self, module_name: str):
        """打开模块：空窗格直接设置，已有模块的窗格先自动 split"""
        canvas = self.canvas
        # 如果该模块已在其他窗格打开，清除旧位置
        existing = find_module_pane(self._layout_tree, module_name)
        if existing and existing.pane_id != self._focused_pane_id:
            existing.module = None
        # 当前窗格已有模块 → 自动横向 split，在新窗格中打开
        current = find_pane(self._layout_tree, self._focused_pane_id)
        target_pane_id = self._focused_pane_id
        if current and current.module is not None:
            self._layout_tree = split_pane(self._layout_tree, self._focused_pane_id, 'h')
            # 找到新创建的空窗格
            for p in all_panes(self._layout_tree):
                if p.module is None:
                    target_pane_id = p.pane_id
                    break
        # 在目标窗格设置模块（布局树层面）
        target = find_pane(self._layout_tree, target_pane_id)
        if target:
            target.module = module_name
        # 整体 rebuild + 恢复全部状态
        await canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        self._set_focused_pane(target_pane_id)
        self._save_layout()

    def _restore_all_modules(self):
        """从 State 层恢复所有已打开模块的完整内容"""
        for pane in all_panes(self._layout_tree):
            if pane.module:
                self._restore_module(pane.module)

    def _restore_module(self, module_name: str):
        """从 State 恢复单个模块的完整内容到 Widget（通用）"""
        widget = self._get_module(module_name)
        if not widget:
            return
        if hasattr(widget, 'restore'):
            widget.restore(self.state)

    # ── 布局操作 ──

    async def _do_split(self, direction: str):
        self._layout_tree = split_pane(self._layout_tree, self._focused_pane_id, direction)
        await self.canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        self._set_focused_pane(self._focused_pane_id)
        self._save_layout()

    async def _do_close_pane(self):
        panes = all_panes(self._layout_tree)
        if len(panes) <= 1:
            return  # 不关闭最后一个
        # 找到下一个窗格
        ids = [p.pane_id for p in panes]
        idx = ids.index(self._focused_pane_id) if self._focused_pane_id in ids else 0
        next_id = ids[(idx + 1) % len(ids)] if len(ids) > 1 else ""
        if next_id == self._focused_pane_id:
            next_id = ids[(idx - 1) % len(ids)]
        result = close_pane(self._layout_tree, self._focused_pane_id)
        if result is None:
            return
        self._layout_tree = result
        await self.canvas.rebuild(self._layout_tree)
        self._restore_all_modules()
        if next_id:
            self._set_focused_pane(next_id)
        self._save_layout()

    def _resize_focused(self, delta: float, direction: str = 'h'):
        """调整当前焦点窗格的权重，direction='h'横向/'v'纵向"""
        if resize_pane(self._layout_tree, self._focused_pane_id, delta, direction):
            self.canvas.sync_weights(self._layout_tree)
            self._save_layout()

    def _save_layout(self):
        """序列化布局并发送到服务端保存"""
        if not self.logged_in:
            return
        layout_data = serialize(self._layout_tree)
        self.app.network.send({"type": "save_layout", "layout": layout_data})

    def _update_location(self, location: str, location_path: str | None = None):
        old_location = self.current_location
        self.current_location = location
        self.state.board.location = location

        # 判断是否切换了游戏上下文（如 chess→lobby 需要清除，chess→chess_playing 不需要）
        old_game = old_location.split('_')[0] if old_location else ''
        new_game = location.split('_')[0] if location else ''
        game_changed = old_game != new_game

        board = self._get_module('board')
        if isinstance(board, BoardPanel):
            board.set_location(location)
            if game_changed:
                board.update_table(None)

        if game_changed:
            # 离开旧游戏：触发 handler 钩子
            if old_game:
                old_handler = get_handler(old_game)
                if old_handler:
                    ctx = GameHandlerContext(self.state, self._get_module, self.app.set_timer)
                    old_handler.on_leave_game(ctx)

            self.state.board.map_data = None
            self.state.board.room_data = None
            self.state.status.clear_game()
            status = self._get_module('status')
            if isinstance(status, StatusPanel):
                status.clear()

            # 进入新游戏：触发 handler 钩子
            new_handler = get_handler(new_game)
            if new_handler:
                ctx = GameHandlerContext(self.state, self._get_module, self.app.set_timer)
                new_handler.on_enter_game(ctx)

        indicator = self.query_one("#location-indicator", Static)
        display = location_path or location
        indicator.update(display)

    # ── 键位处理 ──

    def on_key(self, event) -> None:
        vim = self.vim

        # ── INSERT 模式 ──
        if vim.mode == Mode.INSERT:
            event.prevent_default()
            event.stop()

            if event.key == "escape":
                self.action_enter_normal()
            elif event.key == "enter":
                self._submit_input()
            elif event.key == "tab":
                self._complete_command()
            elif event.key == "ctrl+left":
                self._hint_prev_tab()
            elif event.key == "ctrl+right":
                self._hint_next_tab()
            elif event.key == "backspace":
                self._input_buffer = self._input_buffer[:-1]
                self._update_panel_prompt(self._input_buffer)
            elif event.key == "space":
                self._input_buffer += " "
                self._update_panel_prompt(self._input_buffer)
            else:
                ch = event.character
                if ch and ch.isprintable():
                    self._input_buffer += ch
                    self._update_panel_prompt(self._input_buffer)
            return

        # ── NORMAL 模式 ──
        event.prevent_default()
        event.stop()
        key = event.key

        # 前缀键
        if vim.pending_key == "g":
            vim.pending_key = ""
            if key == "g":
                self._scroll_focused_top()
            return

        # which-key 菜单
        if self._which_key is not None:
            if key == "escape":
                self._hide_which_key()
            elif self._which_key == "top":
                if key == "e":
                    self._which_key = "modules"
                    self._picker_selected = 0
                    self._show_which_key("modules")
                elif key == "w":
                    self._which_key = "window"
                    self._show_which_key("window")
                elif key == "q":
                    self._hide_which_key()
                    self._send_command("/back")
                else:
                    self._hide_which_key()
            elif self._which_key == "modules":
                from .module_registry import get_module_names
                _modules = get_module_names()
                if key == "j":
                    self._picker_selected = (self._picker_selected + 1) % len(_modules)
                    self._show_which_key("modules")
                elif key == "k":
                    self._picker_selected = (self._picker_selected - 1) % len(_modules)
                    self._show_which_key("modules")
                elif key == "enter":
                    self._picker_confirm()
                else:
                    self._hide_which_key()
            elif self._which_key == "window":
                self._hide_which_key()
                if key == "slash":
                    self.call_later(self._do_split, 'h')
                elif key == "minus":
                    self.call_later(self._do_split, 'v')
                elif key in ("h", "j", "k", "l"):
                    new_id = navigate(self._layout_tree, self._focused_pane_id, key)
                    self._set_focused_pane(new_id)
                elif key == "H":
                    self._resize_focused(-0.25, 'h')
                elif key == "L":
                    self._resize_focused(0.25, 'h')
                elif key == "J":
                    self._resize_focused(0.25, 'v')
                elif key == "K":
                    self._resize_focused(-0.25, 'v')
                elif key == "q":
                    self.call_later(self._do_close_pane)
            return

        # 单键
        if key == "space":
            self._which_key = "top"
            self._show_which_key("top")
        elif key == "i":
            self._enter_insert()
        elif key == "j":
            self._scroll_focused_down()
        elif key == "k":
            self._scroll_focused_up()
        elif key == "G":
            self._scroll_focused_bottom()
        elif key == "g":
            vim.pending_key = "g"
        elif key == "q":
            self._send_command("/back")
        elif key == "tab":
            self._cycle_channel()
        elif event.character and event.character.isdigit() and event.character != "0":
            self._send_command(f"/{event.character}")

    # ── 输入提交 ──

    def _submit_input(self):
        text = self._input_buffer.strip()
        self._input_buffer = ""
        self._hide_panel_prompt()
        self.vim.enter_normal()
        self._update_mode_indicator()

        if not text and self._input_target != 'login':
            return

        if self._input_target == 'login':
            if not self.app.network.connected:
                # 输入服务器地址并连接
                ip = text or DEFAULT_HOST
                login = self._get_module('login')
                if isinstance(login, LoginPanel):
                    login.add_message(f"正在连接 {ip}…")
                self.app.connect_to_server(ip)
            elif text:
                # 已连接：发送用户名/密码
                self._send_command(text)
        elif self._input_target == "chat":
            chat = self._get_module('chat')
            ch = chat.current_channel if isinstance(chat, ChatPanel) else 1
            self._send_chat(text, ch)
        else:
            if not self.logged_in:
                self._send_command(text)
            else:
                if not text.startswith("/"):
                    text = "/" + text
                self._send_command(text)
        if not self.logged_in:
            self._enter_insert()

    # ── 滚动 ──

    def _get_focused_log(self) -> RichLog | None:
        pane = find_pane(self._layout_tree, self._focused_pane_id)
        if not pane or not pane.module:
            return None
        widget = self._get_module(pane.module)
        if widget is None:
            return None
        # 找到该 widget 内的 RichLog
        try:
            logs = widget.query(RichLog)
            return logs.first() if logs else None
        except Exception:
            return None

    def _scroll_focused_down(self):
        log = self._get_focused_log()
        if log:
            log.scroll_down(animate=False)

    def _scroll_focused_up(self):
        log = self._get_focused_log()
        if log:
            log.scroll_up(animate=False)

    def _scroll_focused_bottom(self):
        log = self._get_focused_log()
        if log:
            log.scroll_end(animate=False)

    def _scroll_focused_top(self):
        log = self._get_focused_log()
        if log:
            log.scroll_home(animate=False)

    # ── 指令发送 ──

    def _send_command(self, text: str):
        self.app.send_command(text)

    def _send_chat(self, text: str, channel: int):
        self.app.send_chat(text, channel)

    def _cycle_channel(self):
        chat = self._get_module('chat')
        if not isinstance(chat, ChatPanel):
            return
        ch = chat.current_channel
        new_ch = 2 if ch == 1 else 1
        self.state.chat.switch_channel(new_ch)
        chat.switch_channel(new_ch)
        self.app.switch_channel(new_ch)

    # ── 指令补全 ──

    def _complete_command(self):
        """Tab 补全：将第一个匹配指令填入输入缓冲"""
        if self._input_target != 'cmd':
            return
        buf = self._input_buffer
        from .command_registry import filter_commands
        prefix = buf.split()[0] if buf else ""
        if not prefix:
            return
        matches = filter_commands(prefix)
        if matches and matches[0].command != prefix:
            self._input_buffer = matches[0].command + " "
            self._update_panel_prompt(self._input_buffer)

    def _update_hint_bar(self):
        """更新指令提示栏的标签页（位置变更时调用）"""
        from .command_registry import get_command_tabs
        tabs = get_command_tabs()
        cmd = self._get_module('cmd')
        if isinstance(cmd, CommandPanel):
            cmd.update_hint_tabs(tabs)

    def _hint_next_tab(self):
        cmd = self._get_module('cmd')
        if isinstance(cmd, CommandPanel):
            cmd.hint_next_tab()

    def _hint_prev_tab(self):
        cmd = self._get_module('cmd')
        if isinstance(cmd, CommandPanel):
            cmd.hint_prev_tab()


# ═══════════════════════════════════════════════════════
#  GameLobbyApp — 主应用
# ═══════════════════════════════════════════════════════


class GameLobbyApp(App):
    """游戏大厅 TUI 客户端"""

    TITLE = "游戏大厅"
    CSS_PATH = "theme.tcss"

    BINDINGS = [
        Binding("ctrl+c", "quit", "退出", show=True, priority=True),
    ]

    def __init__(self, **kw):
        super().__init__(**kw)
        self.network = NetworkManager(PORT)
        self.vim = VimMode()
        self.player_data: dict = {}
        self._pending_messages: list[dict] = []
        self._current_channel = 1
        self._saved_layout: dict | None = None

    def on_mount(self) -> None:
        self.push_screen(GameScreen())

    # ── 网络 ──

    def connect_to_server(self, ip: str):
        """建立服务器连接"""
        screen = self.screen
        try:
            self.network.connect(ip)
        except Exception as e:
            if isinstance(screen, GameScreen):
                login = screen._get_module('login')
                if isinstance(login, LoginPanel):
                    login.add_message(f"[dim]连接失败: {e}[/]")
            return

        self._start_receive_worker()

        # 处理缓冲消息
        for msg in self._pending_messages:
            self.post_message(ServerMsg(msg))
        self._pending_messages.clear()

    @work(thread=True)
    def _start_receive_worker(self):
        """后台线程：接收服务器消息并投递到事件循环"""
        buffer = ""
        import json
        while self.network.connected:
            try:
                data = self.network.socket.recv(4096)
                if not data:
                    break
                buffer += data.decode("utf-8")
                while "\n" in buffer:
                    msg_str, buffer = buffer.split("\n", 1)
                    if msg_str:
                        try:
                            msg = json.loads(msg_str)
                            self.post_message(ServerMsg(msg))
                        except Exception:
                            pass
            except Exception:
                break

        self.network.connected = False
        self.post_message(Disconnected())

    def _on_disconnect(self):
        self.post_message(Disconnected())

    def on_disconnected(self, _msg: Disconnected) -> None:
        """处理连接断开"""
        screen = self.screen
        if isinstance(screen, GameScreen):
            # 写到 login 面板或 cmd 面板
            login = screen._get_module('login')
            if isinstance(login, LoginPanel):
                login.add_message("[dim]连接已断开[/]")
            else:
                screen.state.cmd.add_line("[dim]连接已断开[/]")
                cmd = screen._get_module('cmd')
                if isinstance(cmd, CommandPanel):
                    cmd.add_message("[dim]连接已断开[/]")
            try:
                conn = screen.query_one("#connection-status", Static)
                conn.update("已断开")
            except Exception:
                pass

    # ── 消息处理 ──

    def on_server_msg(self, event: ServerMsg) -> None:
        """统一处理服务器消息"""
        screen = self.screen
        if not isinstance(screen, GameScreen):
            self._pending_messages.append(event.data)
            return

        parsed = parse_server_message(event.data)
        gs = screen
        st = gs.state

        # 便捷方法：State + Widget 同步
        def _cmd_add(text, **kw):
            st.cmd.add_line(text)
            w = gs._get_module('cmd')
            if isinstance(w, CommandPanel):
                w.add_message(text, **kw)

        def _chat() -> ChatPanel | None:
            w = gs._get_module('chat')
            return w if isinstance(w, ChatPanel) else None

        def _board() -> BoardPanel | None:
            w = gs._get_module('board')
            return w if isinstance(w, BoardPanel) else None

        def _status() -> StatusPanel | None:
            w = gs._get_module('status')
            return w if isinstance(w, StatusPanel) else None

        def _online() -> OnlineUsersPanel | None:
            w = gs._get_module('online')
            return w if isinstance(w, OnlineUsersPanel) else None

        if isinstance(parsed, LoginPrompt):
            # 登录阶段：写到 login 面板
            login = gs._get_module('login')
            if isinstance(login, LoginPanel):
                login.add_message(parsed.text)
            else:
                _cmd_add(parsed.text)

        elif isinstance(parsed, LoginSuccess):
            gs.logged_in = True
            st.cmd.add_line(parsed.text)
            gs.call_later(gs._rebuild_to_game_layout)

        elif isinstance(parsed, SystemMessage):
            st.chat.add_system_message(parsed.text)
            chat = _chat()
            if chat:
                chat.add_system_message(parsed.text)

        elif isinstance(parsed, GameMessage):
            st.cmd.add_line(parsed.text)
            w = gs._get_module('cmd')
            if isinstance(w, CommandPanel):
                w.add_message(parsed.text, update_last=parsed.update_last)

        elif isinstance(parsed, ChatMessage):
            st.chat.add_message(parsed.name, parsed.text, parsed.channel, parsed.time)
            chat = _chat()
            if chat:
                chat.add_message(parsed.name, parsed.text, parsed.channel, parsed.time)

        elif isinstance(parsed, ChatHistory):
            st.chat.set_history(parsed.messages, parsed.channel)
            chat = _chat()
            if chat:
                chat.show_history(parsed.messages, parsed.channel)

        elif isinstance(parsed, StatusUpdate):
            self.player_data = parsed.data
            st.board.player_data = parsed.data
            if parsed.map_data:
                st.board.map_data = parsed.map_data
            # 更新位置显示
            if parsed.location_path:
                try:
                    indicator = gs.query_one("#location-indicator", Static)
                    indicator.update(parsed.location_path)
                except Exception:
                    pass
            # 保存布局数据，首次登录时应用
            layout_data = parsed.data.get('window_layout')
            if layout_data:
                self._saved_layout = layout_data
                if not gs._layout_loaded:
                    tree = deserialize(layout_data)
                    if tree:
                        gs._layout_loaded = True
                        gs._layout_tree = tree
                        gs.call_later(gs._apply_saved_layout)
            board = _board()
            if board:
                board.update_status(parsed.data)
            if parsed.map_data and board:
                board.update_map(parsed.map_data)

        elif isinstance(parsed, OnlineUsers):
            st.online.users = parsed.users
            st.chat.update_online_count(parsed.users)
            chat = _chat()
            if chat:
                chat.update_online_users(parsed.users)
            online = _online()
            if online:
                online.update_users(parsed.users)

        elif isinstance(parsed, GameInvite):
            inv = parsed.raw
            invite_text = f"[b]游戏邀请[/b]: {inv.get('from', '?')} 邀请你加入 {inv.get('game', '?')}"
            _cmd_add(invite_text)

        elif isinstance(parsed, RoomUpdate):
            if parsed.room_data:
                st.board.room_data = parsed.room_data
                board = _board()
                if board:
                    board.update_table(parsed.room_data)
                room_id = parsed.room_data.get("room_id")
                if room_id:
                    gs.current_room_id = room_id
                game_type = parsed.room_data.get("game_type", "")
                state = parsed.room_data.get("state", "waiting")
                # 通用：有对局状态时更新状态面板
                if state == "playing":
                    st.status.update_game_status(game_type, parsed.room_data)
                    status = _status()
                    if status:
                        status.update_game_status(game_type, parsed.room_data)
            if parsed.message:
                _cmd_add(parsed.message)

        elif isinstance(parsed, (RoomLeave, GameQuit)):
            st.board.room_data = None
            st.status.clear_game()
            board = _board()
            if board:
                board.update_table(None)
            status = _status()
            if status:
                status.clear()
            gs.current_room_id = None
            if parsed.location:
                if hasattr(parsed, 'commands') and parsed.commands:
                    from .command_registry import set_commands
                    set_commands(parsed.commands)
                    gs._update_hint_bar()
                path = getattr(parsed, 'location_path', None)
                gs._update_location(parsed.location, path)

        elif isinstance(parsed, LocationUpdate):
            from .command_registry import set_commands
            set_commands(parsed.commands)
            gs._update_hint_bar()
            gs._update_location(parsed.location, parsed.location_path)

        elif isinstance(parsed, GameEvent):
            handler = get_handler(parsed.game_type)
            if handler:
                ctx = GameHandlerContext(
                    state=st,
                    get_module=gs._get_module,
                    set_timer=self.set_timer,
                )
                handler.handle_event(parsed.event, parsed.data, ctx)

        elif isinstance(parsed, ActionCommand):
            action = parsed.action
            if action == "clear":
                st.cmd.clear()
                w = gs._get_module('cmd')
                if w and hasattr(w, 'clear'):
                    w.clear()
            elif action == "version":
                sv = parsed.raw.get("server_version", "未知")
                cv = VERSION or "开发版"
                ver_text = f"版本信息\n客户端: v{cv}\n服务器: v{sv}"
                _cmd_add(ver_text)
            elif action == "exit":
                self.network.disconnect()
                self.exit()
            elif action == "maintenance":
                maint_text = "[b]系统维护[/b]: 服务器正在维护，请稍后重连。"
                _cmd_add(maint_text)
                self.network.disconnect()

    # ── 发送 ──

    def send_command(self, text: str):
        self.network.send({"type": "command", "text": text})

    def send_chat(self, text: str, channel: int):
        self.network.send({"type": "chat", "text": text, "channel": channel})

    def switch_channel(self, channel_id: int):
        self._current_channel = channel_id
        self.network.send({"type": "switch_channel", "channel": channel_id})

    # ── 退出 ──

    def action_quit(self) -> None:
        self.network.disconnect()
        self.exit()


def _check_version() -> bool:
    """检查是否最新版，返回 True 表示可以启动"""
    import json
    import urllib.request
    current = VERSION or "0.0.0"
    print(f"gamelobby v{current}")
    print("正在检查更新...")
    try:
        req = urllib.request.Request(
            "https://pypi.org/pypi/gamelobby/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            latest = json.loads(resp.read().decode())["info"]["version"]
        cur = tuple(int(x) for x in current.split("."))
        lat = tuple(int(x) for x in latest.split("."))
        if lat > cur:
            print(f"\n发现新版本 v{latest}（当前 v{current}）")
            print(f"请运行以下命令更新:\n")
            print(f"  pip install --upgrade gamelobby\n")
    except Exception:
        pass
    print()
    return True


def main():
    """CLI 入口点"""
    if not _check_version():
        return
    app = GameLobbyApp()
    app.run()
