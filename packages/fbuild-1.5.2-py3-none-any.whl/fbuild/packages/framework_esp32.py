"""ESP32 Framework Management.

This module handles downloading, extracting, and managing the Arduino-ESP32 framework
and ESP-IDF libraries needed for ESP32 builds.

Framework Download Process:
    1. Download Arduino-ESP32 core (framework-arduinoespressif32)
    2. Download ESP-IDF precompiled libraries (framework-arduinoespressif32-libs)
    3. Extract both archives (.tar.xz format)
    4. Provide access to cores/, variants/, libraries/, and tools/

Framework Structure (after extraction):
    framework-arduinoespressif32/
    ├── cores/
    │   └── esp32/              # Arduino core implementation
    │       ├── Arduino.h
    │       ├── main.cpp
    │       ├── wiring.c
    │       └── ...
    ├── variants/
    │   └── esp32c6/            # Board-specific variant
    │       ├── pins_arduino.h
    │       └── ...
    ├── libraries/              # Built-in libraries (Wire, SPI, WiFi, etc.)
    │   ├── WiFi/
    │   ├── Wire/
    │   ├── SPI/
    │   └── ...
    ├── tools/                  # Build tools and SDKs
    │   └── sdk/
    │       └── esp32c6/
    │           ├── include/    # ESP-IDF headers
    │           └── lib/        # Precompiled libraries
    └── package.json            # Framework metadata

ESP-IDF Libraries Structure:
    framework-arduinoespressif32-libs/
    └── esp32c6/
        ├── include/            # ESP-IDF headers
        │   ├── esp_system/
        │   ├── freertos/
        │   └── ...
        └── lib/                # Precompiled .a libraries
            ├── libesp_system.a
            ├── libfreertos.a
            └── ...
"""

import _thread
import json
from pathlib import Path
from typing import Any, Dict, List, Optional

from fbuild.packages.archive_utils import ArchiveExtractor, URLVersionExtractor
from fbuild.packages.cache import Cache
from fbuild.packages.downloader import DownloadError, ExtractionError, PackageDownloader
from fbuild.packages.framework_patches import ESP32_FRAMEWORK_PATCHES, apply_framework_patches
from fbuild.packages.package import IFramework, PackageError
from fbuild.packages.sdk_utils import SDKPathResolver
from fbuild.packages.staged_install import cleanup_stale_staging_dirs, staged_install


class FrameworkErrorESP32(PackageError):
    """Raised when ESP32 framework operations fail."""

    pass


class FrameworkESP32(IFramework):
    """Manages ESP32 framework download, extraction, and access.

    This class handles the Arduino-ESP32 framework which includes:
    - Arduino core for ESP32 family (cores/, variants/)
    - Built-in Arduino libraries (WiFi, Wire, SPI, etc.)
    - ESP-IDF precompiled libraries
    - Tools and SDKs for ESP32 development
    """

    def __init__(
        self,
        cache: Cache,
        framework_url: str,
        libs_url: str,
        skeleton_lib_url: Optional[str] = None,
        show_progress: bool = True,
    ):
        """Initialize ESP32 framework manager.

        Args:
            cache: Cache manager instance
            framework_url: URL to Arduino-ESP32 core package (.tar.xz)
            libs_url: URL to ESP-IDF precompiled libraries (.tar.xz)
            skeleton_lib_url: Optional URL to MCU-specific skeleton library
            show_progress: Whether to show download/extraction progress
        """
        self.cache = cache
        self.framework_url = framework_url
        self.libs_url = libs_url
        self.skeleton_lib_url = skeleton_lib_url
        self.show_progress = show_progress
        self.archive_extractor = ArchiveExtractor(show_progress=show_progress)

        # Extract version from URL (e.g., "3.3.4" from release tag)
        self.version = URLVersionExtractor.extract_version_from_url(framework_url, prefix="esp32-")

        # Get framework paths from cache
        # We'll use a combined hash for all URLs to keep them together
        combined_url = f"{framework_url}|{libs_url}|{skeleton_lib_url or ''}"
        self.framework_path = cache.get_platform_path(combined_url, self.version)

    def ensure_package(self) -> Path:
        """Ensure framework is downloaded and extracted.

        Returns:
            Path to the extracted framework directory

        Raises:
            FrameworkErrorESP32: If download or extraction fails
        """
        return self.ensure_framework()

    def ensure_framework(self) -> Path:
        """Ensure framework is downloaded and extracted.

        Uses staged_install: all work is done in a temp dir, and only the final
        step renames it to the real location. If cancelled mid-install, the staging
        dir is left as an orphan that can be garbage-collected later.

        Returns:
            Path to the extracted framework directory

        Raises:
            FrameworkErrorESP32: If download or extraction fails
        """
        if self.is_installed():
            if self.show_progress:
                print(f"Using cached ESP32 framework {self.version}")
            self._post_install_apply_patches()  # idempotent, fixes existing caches
            return self.framework_path

        try:
            if self.show_progress:
                print(f"Downloading ESP32 framework {self.version}...")

            self.cache.ensure_directories()
            cleanup_stale_staging_dirs(self.cache.platforms_dir)

            with staged_install(self.framework_path, self.cache.platforms_dir) as install_dir:
                self._download_framework_components_parallel(install_dir)
                self._post_install_apply_patches(install_dir)

            if self.show_progress:
                print(f"ESP32 framework installed to {self.framework_path}")

            return self.framework_path

        except (DownloadError, ExtractionError) as e:
            raise FrameworkErrorESP32(f"Failed to install ESP32 framework: {e}")
        except KeyboardInterrupt as ke:
            from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

            handle_keyboard_interrupt_properly(ke)
            raise  # Never reached, but satisfies type checker
        except Exception as e:
            raise FrameworkErrorESP32(f"Unexpected error installing framework: {e}")

    def _download_framework_components_parallel(self, install_dir: "Path") -> None:
        """Download all archives in parallel, extract to temp dirs, then copytree-merge.

        All work targets install_dir (a staging directory). Downloads are cached in
        install_dir's parent so they survive across attempts. Each archive is extracted
        to its own temp dir in parallel, then merged into install_dir via copytree
        (dirs_exist_ok=True) which never deletes — no race conditions.

        Args:
            install_dir: Staging directory to install into (will be renamed to
                        framework_path by the caller after success)

        Raises:
            DownloadError: If any download fails
            ExtractionError: If any extraction fails
        """
        import shutil
        import tarfile
        from concurrent.futures import ThreadPoolExecutor, as_completed

        # Cache downloaded archives in parent dir (outside install_dir) so they
        # persist across retries and don't get cleaned up with staging dirs
        cache_dir = install_dir.parent

        # Build task list: (name, url, target_subdir_within_install, description)
        tasks: list[tuple[str, str, "Path", str]] = []
        tasks.append(("core", self.framework_url, install_dir, "Arduino-ESP32 core"))

        if self.libs_url:
            sdk_dir = install_dir / "tools" / "sdk"
            tasks.append(("libs", self.libs_url, sdk_dir, "ESP-IDF libraries"))

        if self.skeleton_lib_url:
            sdk_dir = install_dir / "tools" / "sdk"
            tasks.append(("skeleton", self.skeleton_lib_url, sdk_dir, "Skeleton library"))

        def _download_and_extract_to_temp(name: str, url: str, desc: str) -> tuple[str, "Path"]:
            """Download archive (if not cached) and extract to a temp dir. Returns (name, source_dir).

            If extraction fails (e.g. corrupted download), deletes the cached archive and
            retries once with a fresh download.
            """
            archive_name = Path(url).name
            archive_path = cache_dir / archive_name
            max_attempts = 2

            for attempt in range(max_attempts):
                # Download if not cached
                if not archive_path.exists():
                    if self.show_progress:
                        print(f"Downloading {desc}...")
                    archive_path.parent.mkdir(parents=True, exist_ok=True)
                    downloader = PackageDownloader()
                    downloader.download(url, archive_path, show_progress=self.show_progress)
                else:
                    if self.show_progress:
                        print(f"Using cached {desc} archive")

                # Validate the archive is not obviously corrupt (e.g. HTML error page or truncated)
                try:
                    file_size = archive_path.stat().st_size
                    if file_size < 1024:
                        raise ValueError(f"Archive too small ({file_size} bytes), likely a failed download")
                    # Check magic bytes: XZ files start with 0xFD377A585A00
                    if archive_name.endswith((".tar.xz", ".txz")):
                        with open(archive_path, "rb") as f:
                            magic = f.read(6)
                        if magic != b"\xfd7zXZ\x00":
                            raise ValueError(f"Not a valid XZ file (magic bytes: {magic[:6]!r})")
                except (ValueError, OSError) as e:
                    if attempt < max_attempts - 1:
                        if self.show_progress:
                            print(f"WARNING: {desc} archive is corrupt ({e}), re-downloading...")
                        archive_path.unlink(missing_ok=True)
                        continue
                    raise

                # Extract to a temp dir (in cache_dir, outside install_dir)
                temp_dir = cache_dir / f"_temp_extract_{name}"
                if temp_dir.exists():
                    shutil.rmtree(temp_dir)
                temp_dir.mkdir(parents=True)

                try:
                    if self.show_progress:
                        print(f"Extracting {desc}...")
                    with tarfile.open(archive_path, "r:xz") as tar:
                        tar.extractall(temp_dir)
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    # Extraction failed — likely a corrupted download
                    if temp_dir.exists():
                        shutil.rmtree(temp_dir, ignore_errors=True)
                    if attempt < max_attempts - 1:
                        if self.show_progress:
                            print(f"WARNING: Extraction of {desc} failed ({e}), deleting cached archive and retrying...")
                        archive_path.unlink(missing_ok=True)
                        continue
                    raise

                # Strip single top-level directory (archives typically have one)
                items = list(temp_dir.iterdir())
                if len(items) == 1 and items[0].is_dir():
                    return (name, items[0])
                return (name, temp_dir)

            # Should never reach here, but satisfy type checker
            raise FrameworkErrorESP32(f"Failed to download and extract {desc} after {max_attempts} attempts")

        # Phase 1: Download + extract all archives in parallel
        extracted: dict[str, "Path"] = {}

        if len(tasks) == 1:
            rname, rpath = _download_and_extract_to_temp(tasks[0][0], tasks[0][1], tasks[0][3])
            extracted[rname] = rpath
        else:
            errors: list[Exception] = []
            with ThreadPoolExecutor(max_workers=len(tasks)) as executor:
                future_to_name = {}
                for name, url, _target, desc in tasks:
                    future = executor.submit(_download_and_extract_to_temp, name, url, desc)
                    future_to_name[future] = name

                for future in as_completed(future_to_name):
                    fname = future_to_name[future]
                    try:
                        rname, rpath = future.result()
                        extracted[rname] = rpath
                    except KeyboardInterrupt:
                        raise
                    except Exception as e:
                        errors.append(e)
                        if self.show_progress:
                            print(f"Failed to download/extract {fname}: {e}")

            if errors:
                raise errors[0]

        # Phase 2: Merge each extracted tree into install_dir via copytree.
        # copytree with dirs_exist_ok=True merges without deleting — no conflicts.
        try:
            for name, _url, target_dir, _desc in tasks:
                source = extracted[name]
                target_dir.mkdir(parents=True, exist_ok=True)
                shutil.copytree(str(source), str(target_dir), dirs_exist_ok=True)
        finally:
            # Clean up extraction temp dirs
            for name in extracted:
                temp_root = cache_dir / f"_temp_extract_{name}"
                if temp_root.exists():
                    shutil.rmtree(temp_root, ignore_errors=True)

    def _post_install_apply_patches(self, target_path: "Path | None" = None) -> None:
        """Apply framework patches to fix known upstream bugs after installation.

        This post-install step applies patches to fix bugs in the Arduino ESP32 framework
        that come from upstream ESP-IDF. Patches are version-specific and only applied
        if the framework version matches the patch constraints.

        The patches are permanent (survive across builds) and self-documenting.

        Args:
            target_path: Path to apply patches to (defaults to self.framework_path)
        """
        patch_dir = target_path or self.framework_path
        try:
            if self.show_progress:
                print("[patches] Checking for required framework patches...")

            apply_framework_patches(patch_dir, ESP32_FRAMEWORK_PATCHES, self.version, self.show_progress)

        except KeyboardInterrupt:
            _thread.interrupt_main()
            raise
        except Exception as e:
            # Don't fail the entire installation if patching fails
            if self.show_progress:
                print(f"[patches] Warning: Post-install patching failed: {e}")

    def is_installed(self) -> bool:
        """Check if framework is already installed.

        Returns:
            True if framework directory exists with key files
        """
        if not self.framework_path.exists():
            return False

        # Verify essential framework directories exist
        required_paths = [
            self.framework_path / "cores",
            self.framework_path / "variants",
            self.framework_path / "tools" / "sdk",
        ]

        return all(p.exists() for p in required_paths)

    def get_cores_dir(self) -> Path:
        """Get path to cores directory.

        Returns:
            Path to cores directory containing Arduino core implementation
        """
        return self.framework_path / "cores"

    def get_core_dir(self, core_name: str = "esp32") -> Path:
        """Get path to specific core directory.

        Args:
            core_name: Core name (default: "esp32")

        Returns:
            Path to the core directory

        Raises:
            FrameworkErrorESP32: If core directory doesn't exist
        """
        core_path = self.get_cores_dir() / core_name
        if not core_path.exists():
            raise FrameworkErrorESP32(f"Core '{core_name}' not found at {core_path}")
        return core_path

    def get_variants_dir(self) -> Path:
        """Get path to variants directory.

        Returns:
            Path to variants directory containing board-specific configurations
        """
        return self.framework_path / "variants"

    def get_variant_dir(self, variant_name: str) -> Path:
        """Get path to specific variant directory.

        Args:
            variant_name: Variant name (e.g., "esp32c6")

        Returns:
            Path to the variant directory

        Raises:
            FrameworkErrorESP32: If variant directory doesn't exist
        """
        variant_path = self.get_variants_dir() / variant_name
        if not variant_path.exists():
            raise FrameworkErrorESP32(f"Variant '{variant_name}' not found at {variant_path}")
        return variant_path

    def get_libraries_dir(self) -> Path:
        """Get path to built-in libraries directory.

        Returns:
            Path to libraries directory
        """
        return self.framework_path / "libraries"

    def list_libraries(self) -> List[str]:
        """List all available built-in libraries.

        Returns:
            List of library names
        """
        libs_dir = self.get_libraries_dir()
        if not libs_dir.exists():
            return []

        return [d.name for d in libs_dir.iterdir() if d.is_dir() and not d.name.startswith(".")]

    def get_library_dir(self, library_name: str) -> Optional[Path]:
        """Get path to a specific library.

        Args:
            library_name: Library name (e.g., "WiFi", "Wire")

        Returns:
            Path to library directory or None if not found
        """
        lib_path = self.get_libraries_dir() / library_name
        return lib_path if lib_path.exists() else None

    def get_sdk_dir(self) -> Path:
        """Get path to ESP-IDF SDK directory.

        Returns:
            Path to SDK directory containing ESP-IDF headers and libraries
        """
        return self.framework_path / "tools" / "sdk"

    def get_sdk_includes(self, mcu: str) -> List[Path]:
        """Get list of ESP-IDF include directories for a specific MCU.

        This method reads the SDK's own includes file which lists the exact
        include paths used by ESP-IDF, avoiding C++ stdlib conflicts that
        occur when recursively discovering paths.

        Args:
            mcu: MCU type (e.g., "esp32c6", "esp32s3")

        Returns:
            List of include directory paths (305 paths for esp32c6)
        """
        sdk_resolver = SDKPathResolver(self.get_sdk_dir(), self.show_progress)
        return sdk_resolver.get_sdk_includes(mcu)

    def get_sdk_libs(self, mcu: str, flash_mode: str = "qio", psram_mode: str = "qspi") -> List[Path]:
        """Get list of ESP-IDF precompiled libraries for a specific MCU.

        Args:
            mcu: MCU type (e.g., "esp32c6", "esp32s3")
            flash_mode: Flash mode (e.g., "qio", "dio") - determines flash library variant
            psram_mode: PSRAM mode (e.g., "qspi", "opi") - determines PSRAM library variant.
                       For boards without PSRAM, use "qspi" to get non-PSRAM SDK libraries.

        Returns:
            List of .a library file paths
        """
        sdk_resolver = SDKPathResolver(self.get_sdk_dir(), self.show_progress)
        return sdk_resolver.get_sdk_libs(mcu, flash_mode, psram_mode)

    def get_sdk_flags_dir(self, mcu: str) -> Path:
        """Get path to SDK flags directory for a specific MCU.

        Args:
            mcu: MCU type (e.g., "esp32c6", "esp32s3")

        Returns:
            Path to flags directory
        """
        sdk_resolver = SDKPathResolver(self.get_sdk_dir(), self.show_progress)
        return sdk_resolver.get_sdk_flags_dir(mcu)

    def get_tools_dir(self) -> Path:
        """Get path to tools directory.

        Returns:
            Path to tools directory
        """
        return self.framework_path / "tools"

    def get_package_json(self) -> Dict[str, Any]:
        """Load and parse package.json metadata.

        Returns:
            Dictionary containing package metadata

        Raises:
            FrameworkErrorESP32: If package.json doesn't exist or is invalid
        """
        package_json_path = self.framework_path / "package.json"

        if not package_json_path.exists():
            raise FrameworkErrorESP32(f"package.json not found at {package_json_path}. " + "Ensure framework is downloaded first.")

        try:
            with open(package_json_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            raise FrameworkErrorESP32(f"Failed to parse package.json: {e}")
        except KeyboardInterrupt as ke:
            from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

            handle_keyboard_interrupt_properly(ke)
            raise  # Never reached, but satisfies type checker
        except Exception as e:
            raise FrameworkErrorESP32(f"Failed to read package.json: {e}")

    def list_variants(self) -> List[str]:
        """List all available board variants.

        Returns:
            List of variant names
        """
        variants_dir = self.get_variants_dir()
        if not variants_dir.exists():
            return []

        return [d.name for d in variants_dir.iterdir() if d.is_dir() and not d.name.startswith(".")]

    def list_cores(self) -> List[str]:
        """List all available cores.

        Returns:
            List of core names
        """
        cores_dir = self.get_cores_dir()
        if not cores_dir.exists():
            return []

        return [d.name for d in cores_dir.iterdir() if d.is_dir() and not d.name.startswith(".")]

    def get_core_sources(self, core_name: str = "esp32") -> List[Path]:
        """Get all source files in a core.

        Args:
            core_name: Core name (default: "esp32")

        Returns:
            List of .c and .cpp source file paths
        """
        core_dir = self.get_core_dir(core_name)
        sources = []
        sources.extend(core_dir.glob("*.c"))
        sources.extend(core_dir.glob("*.cpp"))
        # Also search in subdirectories
        sources.extend(core_dir.glob("**/*.c"))
        sources.extend(core_dir.glob("**/*.cpp"))
        # Remove duplicates
        return list(set(sources))

    def get_package_info(self) -> Dict[str, Any]:
        """Get information about the installed framework.

        Returns:
            Dictionary with framework information
        """
        return self.get_framework_info()

    def get_framework_info(self) -> Dict[str, Any]:
        """Get information about the installed framework.

        Returns:
            Dictionary with framework information
        """
        info = {
            "version": self.version,
            "path": str(self.framework_path),
            "framework_url": self.framework_url,
            "libs_url": self.libs_url,
            "installed": self.is_installed(),
        }

        if self.is_installed():
            info["cores_dir"] = str(self.get_cores_dir())
            info["variants_dir"] = str(self.get_variants_dir())
            info["libraries_dir"] = str(self.get_libraries_dir())
            info["sdk_dir"] = str(self.get_sdk_dir())
            info["available_cores"] = self.list_cores()
            info["available_variants"] = self.list_variants()
            info["available_libraries"] = self.list_libraries()

            # Get package information
            try:
                package_json = self.get_package_json()
                info["package_version"] = package_json.get("version")
                info["package_name"] = package_json.get("name")
            except FrameworkErrorESP32:
                pass

        return info
