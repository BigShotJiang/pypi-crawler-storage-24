"""ESP32 library dependency management.

This module handles downloading and compiling external libraries for ESP32 builds.
It uses the PlatformIO registry to resolve and download libraries, then compiles
them with the ESP32 toolchain.

GCC response files (@file) are used to avoid Windows' 32K command-line length limit.
"""

import json
import logging
import multiprocessing
import platform
import subprocess
import time
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path
from typing import List, Optional

from fbuild.build.response_file import write_response_file
from fbuild.output import log_detail
from fbuild.packages.platformio_registry import (
    LibrarySpec,
    PlatformIORegistry,
    RegistryError,
)
from fbuild.subprocess_utils import safe_popen, safe_run

logger = logging.getLogger(__name__)

# C++-only flags that must not be passed to gcc when compiling .c files
_CXX_ONLY_PREFIXES = ("-std=gnu++", "-std=c++", "-fno-rtti", "-fuse-cxa-atexit")


def _is_cxx_only_flag(flag: str) -> bool:
    """Check if a compiler flag is only valid for C++ (not C)."""
    return any(flag.startswith(p) for p in _CXX_ONLY_PREFIXES)


def _compile_single_file(job: tuple) -> tuple[Path, str]:
    """Compile a single source file (module-level function for thread pool execution).

    Uses Popen with stdout=PIPE and stderr redirected to a file to avoid the
    double-pump deadlock problem (reading two pipes from one process can deadlock
    when one pipe's buffer fills while the reader is blocked on the other).

    On success the stderr file is deleted. On failure it is kept for debugging.

    Args:
        job: Tuple of (source_path, obj_file, cmd, stderr_dir)
              stderr_dir is the directory where per-file stderr logs are written.

    Returns:
        Tuple of (obj_file, stderr_text)

    Raises:
        LibraryErrorESP32: If compilation fails
    """
    source, obj_file, cmd, stderr_dir = job

    # Create a per-file stderr log named after the object file to avoid collisions
    stderr_file = stderr_dir / f"{obj_file.stem}.stderr"
    stderr_file.parent.mkdir(parents=True, exist_ok=True)

    with open(stderr_file, "wb") as stderr_fh:
        proc = safe_popen(cmd, stdout=subprocess.PIPE, stderr=stderr_fh)
        stdout_bytes, _ = proc.communicate()

    # Read stderr from file (UTF-8 with replacement for malformed sequences)
    stderr_text = ""
    if stderr_file.exists() and stderr_file.stat().st_size > 0:
        stderr_text = stderr_file.read_text(encoding="utf-8", errors="replace")

    stdout_text = stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else ""

    if proc.returncode != 0:
        # Keep stderr file for debugging
        raise LibraryErrorESP32(f"Failed to compile {source.name}:\n{stderr_text}{stdout_text}")

    # Success — clean up stderr file
    try:
        stderr_file.unlink(missing_ok=True)
    except OSError:
        pass  # Best-effort cleanup

    return obj_file, stderr_text


def create_stderr_dir(build_dir: Path) -> Path:
    """Create a per-build-run stderr directory for compiler stderr output.

    Args:
        build_dir: The build directory for this run

    Returns:
        Path to the stderr directory (created and ready to use)
    """
    stderr_dir = build_dir / ".compile_stderr"
    stderr_dir.mkdir(parents=True, exist_ok=True)
    return stderr_dir


def cleanup_stderr_dir(stderr_dir: Path) -> None:
    """Best-effort cleanup of a stderr directory.

    Removes the directory and all contents. Silently ignores errors
    (e.g., files locked by another process, force-killed build).

    Args:
        stderr_dir: Path to the stderr directory to clean up
    """
    import shutil

    try:
        if stderr_dir.exists():
            shutil.rmtree(stderr_dir, ignore_errors=True)
    except OSError:
        pass


def garbage_collect_stderr_dirs(build_root: Path, max_age_hours: int) -> None:
    """Remove old stderr directories that are older than max_age_hours.

    Called periodically to clean up stderr dirs from builds that were
    force-killed and couldn't clean up after themselves.

    Args:
        build_root: Root directory containing build dirs to scan
        max_age_hours: Maximum age in hours before a stderr dir is removed
    """
    import shutil

    cutoff = time.time() - (max_age_hours * 3600)
    try:
        for stderr_dir in build_root.glob("**/.compile_stderr"):
            try:
                if stderr_dir.stat().st_mtime < cutoff:
                    shutil.rmtree(stderr_dir, ignore_errors=True)
            except OSError:
                pass
    except OSError:
        pass


class LibraryErrorESP32(Exception):
    """Exception for ESP32 library management errors."""

    pass


class LibraryESP32:
    """Represents a downloaded and compiled ESP32 library."""

    def __init__(self, lib_dir: Path, name: str):
        """Initialize ESP32 library.

        Args:
            lib_dir: Root directory for the library
            name: Library name
        """
        self.lib_dir = lib_dir
        self.name = name
        self.src_dir = lib_dir / "src"
        self.info_file = lib_dir / "library.json"
        self.archive_file = lib_dir / f"lib{name}.a"
        self.build_info_file = lib_dir / "build_info.json"

    @property
    def exists(self) -> bool:
        """Check if library is downloaded and compiled."""
        return self.lib_dir.exists() and self.src_dir.exists() and self.info_file.exists()

    @property
    def is_compiled(self) -> bool:
        """Check if library is compiled."""
        return self.archive_file.exists() and self.build_info_file.exists()

    def get_source_files(self) -> List[Path]:
        """Find all source files (.c, .cpp, .cc, .cxx) in the library.

        Returns:
            List of source file paths
        """
        if not self.src_dir.exists():
            return []

        sources = []

        # Check for src/src/ structure (some libraries have this)
        src_src = self.src_dir / "src"
        search_dir = src_src if (src_src.exists() and src_src.is_dir()) else self.src_dir

        # Find all source files recursively
        for pattern in ["**/*.c", "**/*.cpp", "**/*.cc", "**/*.cxx"]:
            for path in search_dir.glob(pattern):
                # Skip examples and tests (check relative path only)
                rel_path = str(path.relative_to(search_dir)).lower()
                if "example" not in rel_path and "test" not in rel_path:
                    sources.append(path)

        return sources

    def get_include_dirs(self) -> List[Path]:
        """Get include directories for this library.

        Returns:
            List of include directory paths
        """
        include_dirs = []

        if not self.src_dir.exists():
            logger.warning(f"[INCLUDE_DEBUG] src_dir does not exist: {self.src_dir}")
            return include_dirs

        # Check for src/src/ structure
        src_src = self.src_dir / "src"
        if src_src.exists() and src_src.is_dir():
            logger.debug(f"[INCLUDE_DEBUG] Found nested src/, adding: {src_src}")
            include_dirs.append(src_src)
        else:
            logger.debug(f"[INCLUDE_DEBUG] No nested src/, adding base: {self.src_dir}")
            include_dirs.append(self.src_dir)

        # Look for additional include directories
        for name in ["include", "Include", "INCLUDE"]:
            inc_dir = self.lib_dir / name
            if inc_dir.exists():
                logger.debug(f"[INCLUDE_DEBUG] Found additional include dir: {inc_dir}")
                include_dirs.append(inc_dir)

        logger.debug(f"[INCLUDE_DEBUG] Final include_dirs for {self.name}: {include_dirs}")
        return include_dirs


class LibraryManagerESP32:
    """Manages ESP32 library dependencies."""

    def __init__(self, build_dir: Path, registry: Optional[PlatformIORegistry] = None, project_dir: Optional[Path] = None):
        """Initialize library manager.

        Args:
            build_dir: Build directory (.fbuild/build/{board})
            registry: Optional registry client
            project_dir: Optional project directory (for resolving relative local library paths)
        """
        self.build_dir = Path(build_dir)
        self.libs_dir = self.build_dir / "libs"
        self.registry = registry or PlatformIORegistry()
        self.project_dir = Path(project_dir) if project_dir else None

        # Ensure libs directory exists
        self.libs_dir.mkdir(parents=True, exist_ok=True)

    def _sanitize_name(self, name: str) -> str:
        """Sanitize library name for filesystem.

        Args:
            name: Library name

        Returns:
            Sanitized name
        """
        return name.lower().replace("/", "_").replace("@", "_")

    def _find_toolchain_compilers(self, toolchain_path: Path) -> tuple[Path, Path]:
        """Find GCC and G++ compilers in the toolchain directory.

        ESP32 uses different toolchains depending on the MCU architecture:
        - Xtensa (ESP32, ESP32-S2, ESP32-S3): xtensa-esp32-elf-gcc, xtensa-esp32-elf-g++
        - RISC-V (ESP32-C3, C6, H2): riscv32-esp-elf-gcc, riscv32-esp-elf-g++

        This method auto-detects which toolchain is available.

        Args:
            toolchain_path: Path to toolchain bin directory

        Returns:
            Tuple of (gcc_path, gxx_path)

        Raises:
            LibraryErrorESP32: If no suitable compiler is found
        """
        # Check for Xtensa toolchain first (more common for ESP32)
        exe_suffix = ".exe" if platform.system() == "Windows" else ""

        # Xtensa toolchain (ESP32, S2, S3)
        xtensa_gcc = toolchain_path / f"xtensa-esp32-elf-gcc{exe_suffix}"
        xtensa_gxx = toolchain_path / f"xtensa-esp32-elf-g++{exe_suffix}"

        if xtensa_gcc.exists() and xtensa_gxx.exists():
            logger.debug(f"[TOOLCHAIN] Using Xtensa toolchain: {xtensa_gcc}")
            return xtensa_gcc, xtensa_gxx

        # RISC-V toolchain (ESP32-C3, C6, H2)
        riscv_gcc = toolchain_path / f"riscv32-esp-elf-gcc{exe_suffix}"
        riscv_gxx = toolchain_path / f"riscv32-esp-elf-g++{exe_suffix}"

        if riscv_gcc.exists() and riscv_gxx.exists():
            logger.debug(f"[TOOLCHAIN] Using RISC-V toolchain: {riscv_gcc}")
            return riscv_gcc, riscv_gxx

        # Fallback: try to find any gcc/g++ pattern
        gcc_files = list(toolchain_path.glob(f"*-gcc{exe_suffix}"))
        gxx_files = list(toolchain_path.glob(f"*-g++{exe_suffix}"))

        if gcc_files and gxx_files:
            logger.debug(f"[TOOLCHAIN] Using discovered toolchain: {gcc_files[0]}")
            return gcc_files[0], gxx_files[0]

        raise LibraryErrorESP32(f"No suitable ESP32 toolchain found in {toolchain_path}. Expected xtensa-esp32-elf-gcc or riscv32-esp-elf-gcc")

    def _find_toolchain_ar(self, toolchain_path: Path, prefer_gcc_ar: bool = True) -> Path:
        """Find ar archiver in the toolchain directory.

        For LTO support, prefer gcc-ar over regular ar. gcc-ar is an LTO-aware
        wrapper that creates proper symbol indices for archives containing
        LTO bytecode objects (-flto -fno-fat-lto-objects).

        Args:
            toolchain_path: Path to toolchain bin directory
            prefer_gcc_ar: If True, prefer gcc-ar over regular ar for LTO support

        Returns:
            Path to ar binary

        Raises:
            LibraryErrorESP32: If no suitable ar is found
        """
        exe_suffix = ".exe" if platform.system() == "Windows" else ""

        if prefer_gcc_ar:
            # Try gcc-ar first for LTO support
            # Check for Xtensa gcc-ar
            xtensa_gcc_ar = toolchain_path / f"xtensa-esp32-elf-gcc-ar{exe_suffix}"
            if xtensa_gcc_ar.exists():
                logger.debug(f"[TOOLCHAIN] Using Xtensa gcc-ar for LTO: {xtensa_gcc_ar}")
                return xtensa_gcc_ar

            # Check for RISC-V gcc-ar
            riscv_gcc_ar = toolchain_path / f"riscv32-esp-elf-gcc-ar{exe_suffix}"
            if riscv_gcc_ar.exists():
                logger.debug(f"[TOOLCHAIN] Using RISC-V gcc-ar for LTO: {riscv_gcc_ar}")
                return riscv_gcc_ar

            # Fallback: try to find any gcc-ar pattern
            gcc_ar_files = list(toolchain_path.glob(f"*-gcc-ar{exe_suffix}"))
            if gcc_ar_files:
                logger.debug(f"[TOOLCHAIN] Using discovered gcc-ar: {gcc_ar_files[0]}")
                return gcc_ar_files[0]

        # Fall back to regular ar
        # Check for Xtensa ar
        xtensa_ar = toolchain_path / f"xtensa-esp32-elf-ar{exe_suffix}"
        if xtensa_ar.exists():
            return xtensa_ar

        # Check for RISC-V ar
        riscv_ar = toolchain_path / f"riscv32-esp-elf-ar{exe_suffix}"
        if riscv_ar.exists():
            return riscv_ar

        # Fallback: try to find any ar pattern
        ar_files = list(toolchain_path.glob(f"*-ar{exe_suffix}"))
        if ar_files:
            return ar_files[0]

        raise LibraryErrorESP32(f"No suitable ar archiver found in {toolchain_path}. Expected xtensa-esp32-elf-ar or riscv32-esp-elf-ar")

    def get_library(self, spec: LibrarySpec) -> LibraryESP32:
        """Get a library instance for a specification.

        Args:
            spec: Library specification

        Returns:
            LibraryESP32 instance
        """
        lib_name = self._sanitize_name(spec.name)
        lib_dir = self.libs_dir / lib_name
        return LibraryESP32(lib_dir, lib_name)

    def _handle_local_library(self, spec: LibrarySpec, show_progress: bool = True) -> LibraryESP32:
        """Handle a local library specification (file:// or relative path).

        Args:
            spec: Library specification with is_local=True
            show_progress: Whether to show progress

        Returns:
            LibraryESP32 instance

        Raises:
            LibraryErrorESP32: If local library setup fails
        """
        import logging

        logger = logging.getLogger(__name__)

        logger.debug(f"[LOCAL_LIB] Step 1: Starting _handle_local_library for spec: {spec}")

        if not spec.local_path:
            raise LibraryErrorESP32(f"Local library spec has no path: {spec}")

        logger.debug(f"[LOCAL_LIB] Step 2: spec.local_path = {spec.local_path}")

        library = self.get_library(spec)
        logger.debug(f"[LOCAL_LIB] Step 3: Created library instance, lib_dir = {library.lib_dir}")

        # On Windows, local libraries are copies (not symlinks) due to MSYS cross-compiler
        # issues. When the library already exists, we smart-sync to pick up source changes
        # without modifying timestamps on unchanged files (avoids unnecessary recompilation).
        # On Unix, symlinks point to the original source so changes are visible automatically.
        if library.exists and platform.system() == "Windows":
            logger.debug("[LOCAL_LIB] Step 4: Library exists on Windows, running smart sync")
            local_path = spec.local_path
            if local_path and not local_path.is_absolute():
                base_dir = self.project_dir if self.project_dir else Path.cwd()
                local_path = base_dir / local_path
            if local_path:
                local_path = local_path.resolve()
                source_path = local_path / "src" if (local_path / "src").is_dir() else local_path
                from fbuild.packages.dirsync import sync_directory

                files_changed = sync_directory(source_path, library.src_dir)
                if files_changed:
                    logger.debug("[LOCAL_LIB] Smart sync detected changes, invalidating compiled archive")
                    if show_progress:
                        log_detail(f"Local library '{spec.name}' sources updated")
                    # Invalidate compiled archive so needs_rebuild() triggers recompilation
                    if library.archive_file.exists():
                        library.archive_file.unlink()
                    if library.build_info_file.exists():
                        library.build_info_file.unlink()
                else:
                    logger.debug("[LOCAL_LIB] Smart sync: no changes detected")
                    if show_progress:
                        log_detail(f"Local library '{spec.name}' already set up")
            return library

        # Skip if already set up (Unix with symlinks, or remote libraries)
        if library.exists:
            logger.debug("[LOCAL_LIB] Step 4: Library already exists, returning early")
            if show_progress:
                log_detail(f"Local library '{spec.name}' already set up")
            return library

        logger.debug("[LOCAL_LIB] Step 5: Library doesn't exist, need to set up")

        # Resolve the local path (relative to project directory if available, otherwise cwd)
        local_path = spec.local_path
        logger.debug(f"[LOCAL_LIB] Step 6: local_path before absolute check: {local_path}, is_absolute={local_path.is_absolute()}")

        if not local_path.is_absolute():
            # Make absolute relative to project directory (where platformio.ini is)
            # If project_dir not set, fall back to current working directory
            base_dir = self.project_dir if self.project_dir else Path.cwd()
            logger.debug(f"[LOCAL_LIB] Step 7: Converting to absolute, base_dir = {base_dir}")
            local_path = base_dir / local_path
            logger.debug(f"[LOCAL_LIB] Step 8: After joining: local_path = {local_path}")

        # Normalize path (resolve .. and .)
        logger.debug(f"[LOCAL_LIB] Step 9: Before resolve(), local_path = {local_path}")
        local_path = local_path.resolve()
        logger.debug(f"[LOCAL_LIB] Step 10: After resolve(), local_path = {local_path}")

        # Verify library exists
        logger.debug(f"[LOCAL_LIB] Step 11: Checking if local_path exists: {local_path}")
        if not local_path.exists():
            raise LibraryErrorESP32(f"Local library path does not exist: {local_path}")

        logger.debug("[LOCAL_LIB] Step 12: Path exists, checking if directory")
        if not local_path.is_dir():
            raise LibraryErrorESP32(f"Local library path is not a directory: {local_path}")

        logger.debug("[LOCAL_LIB] Step 13: Checking for library.json or library.properties")
        # Look for library.json (Arduino library metadata)
        library_json = local_path / "library.json"
        library_properties = local_path / "library.properties"

        if not library_json.exists() and not library_properties.exists():
            # Check if there's a src subdirectory (common Arduino structure)
            logger.debug("[LOCAL_LIB] Step 14: No metadata files, checking for src/ directory")
            src_dir = local_path / "src"
            if not src_dir.exists():
                raise LibraryErrorESP32(f"Local library has no library.json, library.properties, or src/ directory: {local_path}")

        logger.debug("[LOCAL_LIB] Step 15: Library structure validated")
        if show_progress:
            log_detail(f"Setting up local library '{spec.name}' from {local_path}")

        # Create library directory structure
        logger.debug(f"[LOCAL_LIB] Step 16: Creating library directory: {library.lib_dir}")
        library.lib_dir.mkdir(parents=True, exist_ok=True)

        # Create a symlink or copy to the source directory
        # On Windows, force copy instead of symlink due to MSYS/cross-compiler incompatibility
        # MSYS creates /c/Users/... symlinks that ESP32 cross-compiler can't follow when
        # include paths use Windows format (C:/Users/...)
        import os
        import shutil

        is_windows = platform.system() == "Windows"
        logger.debug(f"[LOCAL_LIB] Step 17: Platform detected: {platform.system()} (is_windows={is_windows})")

        # Check if local_path has a src/ subdirectory (Arduino library structure)
        # If so, copy from local_path/src instead of local_path to avoid path duplication
        source_path = local_path / "src" if (local_path / "src").is_dir() else local_path
        logger.debug(f"[LOCAL_LIB] Step 17.5: Source path for copy/symlink: {source_path}")

        if is_windows:
            # Windows: Always copy to avoid MSYS symlink issues with ESP32 cross-compiler
            logger.debug("[LOCAL_LIB] Step 18: Windows detected, forcing copy (no symlink)")
            if show_progress:
                log_detail(f"Copying library files from {source_path}...", indent=8)

            if library.src_dir.exists():
                logger.debug("[LOCAL_LIB] Step 19: Removing existing src_dir before copy")
                shutil.rmtree(library.src_dir)

            # Define ignore function to exclude build artifacts and version control
            # This prevents recursive .fbuild directories and other unnecessary files
            def ignore_build_artifacts(directory: str, contents: list[str]) -> list[str]:
                ignored = []
                for name in contents:
                    if name in {".fbuild", ".pio", ".git", ".venv", "__pycache__", ".pytest_cache", "node_modules", ".cache", "build", ".build", ".vscode", ".idea"}:
                        ignored.append(name)
                        logger.debug(f"[LOCAL_LIB] Ignoring: {os.path.join(directory, name)}")
                return ignored

            logger.debug("[LOCAL_LIB] Step 20: Calling shutil.copytree() with symlinks=False and ignore filter")
            # symlinks=False: Dereference any symlinks in source tree (important for nested dependencies)
            # ignore: Skip build artifacts, version control, and cache directories
            shutil.copytree(source_path, library.src_dir, symlinks=False, ignore=ignore_build_artifacts)
            logger.debug("[LOCAL_LIB] Step 21: Copy completed successfully")
            if show_progress:
                log_detail(f"Copied library files to {library.src_dir}", indent=8)
        else:
            # Unix: Use symlink for efficiency (actual files stay in original location)
            logger.debug(f"[LOCAL_LIB] Step 18: Unix platform, attempting symlink from {library.src_dir} to {source_path}")
            try:
                # Try to create symlink first (faster, no disk space duplication)
                if library.src_dir.exists():
                    logger.debug("[LOCAL_LIB] Step 19: Removing existing src_dir")
                    library.src_dir.unlink()
                logger.debug("[LOCAL_LIB] Step 20: Calling os.symlink()")
                os.symlink(str(source_path), str(library.src_dir), target_is_directory=True)
                logger.debug("[LOCAL_LIB] Step 21: Symlink created successfully")
                if show_progress:
                    log_detail(f"Created symlink to {source_path}", indent=8)
            except OSError as e:
                # Symlink failed (maybe no permissions), fall back to copying
                logger.debug(f"[LOCAL_LIB] Step 22: Symlink failed with error: {e}, falling back to copy")
                if show_progress:
                    log_detail("Symlink failed, copying library files...", indent=8)

                if library.src_dir.exists():
                    logger.debug("[LOCAL_LIB] Step 23: Removing existing src_dir before copy")
                    shutil.rmtree(library.src_dir)

                # Define ignore function to exclude build artifacts and version control
                def ignore_build_artifacts(directory: str, contents: list[str]) -> list[str]:
                    ignored = []
                    for name in contents:
                        if name in {".fbuild", ".pio", ".git", ".venv", "__pycache__", ".pytest_cache", "node_modules", ".cache", "build", ".build", ".vscode", ".idea"}:
                            ignored.append(name)
                            logger.debug(f"[LOCAL_LIB] Ignoring: {os.path.join(directory, name)}")
                    return ignored

                logger.debug("[LOCAL_LIB] Step 24: Calling shutil.copytree() with symlinks=False and ignore filter")
                shutil.copytree(source_path, library.src_dir, symlinks=False, ignore=ignore_build_artifacts)
                logger.debug("[LOCAL_LIB] Step 25: Copy completed successfully")
                if show_progress:
                    log_detail(f"Copied library files to {library.src_dir}", indent=8)

        # Create library.json metadata
        import json

        logger.debug("[LOCAL_LIB] Step 25: Creating library.json metadata")

        lib_name = spec.name
        lib_version = "local"

        # Try to read version from existing metadata
        logger.debug(f"[LOCAL_LIB] Step 26: Checking if source library.json exists: {library_json}")
        if library_json.exists():
            logger.debug("[LOCAL_LIB] Step 27: Reading metadata from source library.json")
            try:
                with open(library_json, "r", encoding="utf-8") as f:
                    metadata = json.load(f)
                    lib_name = metadata.get("name", spec.name)
                    lib_version = metadata.get("version", "local")
                logger.debug(f"[LOCAL_LIB] Step 28: Read metadata: name={lib_name}, version={lib_version}")
            except KeyboardInterrupt as ke:
                from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

                handle_keyboard_interrupt_properly(ke)
                raise  # Never reached
            except Exception as e:
                logger.debug(f"[LOCAL_LIB] Step 29: Failed to read metadata: {e}, using defaults")
                pass  # Use defaults

        # Save library info in the expected location
        info_file = library.lib_dir / "library.json"
        logger.debug(f"[LOCAL_LIB] Step 30: Writing library info to: {info_file}")
        with open(info_file, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "name": lib_name,
                    "owner": "local",
                    "version": lib_version,
                    "local_path": str(local_path),
                    "is_local": True,
                },
                f,
                indent=2,
            )

        logger.debug("[LOCAL_LIB] Step 31: Local library setup completed successfully")
        if show_progress:
            log_detail(f"Local library '{spec.name}' set up successfully")

        return library

    def _resolve_transitive_deps(
        self,
        libraries: List[LibraryESP32],
        already_downloaded: set,
        show_progress: bool,
        lib_ignore: Optional[set[str]] = None,
    ) -> List[LibraryESP32]:
        """Resolve and download transitive dependencies from library.json files.

        Scans each downloaded library for a library.json with a 'dependencies'
        section and downloads any that aren't already present.

        For registry-downloaded libraries, the original library.json (with dependencies)
        ends up at lib_dir/src/library.json, while lib_dir/library.json is build metadata.
        For GitHub-downloaded libraries, the original is at lib_dir/library.json directly.
        We check both locations.

        Args:
            libraries: Already-downloaded libraries to scan for dependencies
            already_downloaded: Set of lowercase library names already downloaded
            show_progress: Whether to show progress
            lib_ignore: Optional set of lowercase library names to skip

        Returns:
            List of newly downloaded transitive dependency libraries
        """
        new_libs: List[LibraryESP32] = []
        queue = list(libraries)

        while queue:
            lib = queue.pop(0)

            # Look for library.json in multiple locations:
            # 1. lib_dir/library.json (GitHub downloads, or build metadata for registry)
            # 2. lib_dir/src/library.json (original library.json for registry downloads)
            deps: list = []
            for candidate in [lib.src_dir / "library.json", lib.lib_dir / "library.json"]:
                if not candidate.exists():
                    continue
                try:
                    data = json.loads(candidate.read_text(encoding="utf-8"))
                except KeyboardInterrupt:
                    raise
                except Exception:
                    continue
                candidate_deps = data.get("dependencies", [])
                if candidate_deps:
                    deps = candidate_deps
                    break  # Found deps, use this file

            if isinstance(deps, dict):
                deps = [deps]

            for dep in deps:
                if not isinstance(dep, dict):
                    continue

                # Filter by platform — only download dependencies compatible with ESP32
                dep_platforms = dep.get("platforms")
                if dep_platforms:
                    if isinstance(dep_platforms, str):
                        dep_platforms = [dep_platforms]
                    # Skip if dep declares platforms and none match espressif32
                    if not any(p in ("espressif32", "*") for p in dep_platforms):
                        continue

                dep_name = dep.get("name", "")
                dep_owner = dep.get("owner", "")
                dep_version = dep.get("version")

                if not dep_name or dep_name.lower() in already_downloaded:
                    continue

                # Skip libraries in the lib_ignore list
                if lib_ignore and dep_name.lower() in lib_ignore:
                    if show_progress:
                        log_detail(f"Skipping ignored transitive dependency: {dep_name}")
                    continue

                # Build spec string
                spec_str = f"{dep_owner}/{dep_name}" if dep_owner else dep_name
                if dep_version:
                    spec_str += f" @ {dep_version}"

                if show_progress:
                    log_detail(f"Resolving transitive dependency: {spec_str}")

                try:
                    spec = LibrarySpec.parse(spec_str)
                    dep_lib = self.download_library(spec, show_progress)
                    new_libs.append(dep_lib)
                    already_downloaded.add(dep_name.lower())
                    queue.append(dep_lib)  # Scan this lib for its deps too
                except KeyboardInterrupt:
                    raise
                except Exception as e:
                    if show_progress:
                        log_detail(f"Warning: Could not resolve transitive dependency '{spec_str}': {e}")

        return new_libs

    def _download_github_library(self, spec: LibrarySpec, library: LibraryESP32, show_progress: bool) -> None:
        """Download a library directly from a GitHub repository URL.

        Downloads the repository as a zip archive from GitHub's archive endpoint
        and extracts it into library.src_dir (lib_dir/src/) to match the
        structure used by registry downloads.

        Args:
            spec: Library specification with github_url set
            library: Target library instance
            show_progress: Whether to show progress
        """
        import shutil
        import tempfile

        url = spec.github_url
        if not url:
            raise LibraryErrorESP32(f"No GitHub URL for library {spec.name}")

        # GitHub provides zip archives at /archive/refs/heads/main.zip
        archive_url = url.rstrip("/")
        if archive_url.endswith(".git"):
            archive_url = archive_url[:-4]

        if show_progress:
            log_detail(f"Downloading {spec.name} from GitHub: {url}")

        from fbuild.packages.downloader import PackageDownloader

        downloader = PackageDownloader()
        library.lib_dir.mkdir(parents=True, exist_ok=True)

        for branch in ["main", "master"]:
            zip_url = f"{archive_url}/archive/refs/heads/{branch}.zip"
            archive_path = library.lib_dir / "library.zip"
            try:
                downloader.download(zip_url, archive_path, show_progress=show_progress)
                with tempfile.TemporaryDirectory() as temp_dir:
                    import zipfile

                    temp_path = Path(temp_dir)
                    with zipfile.ZipFile(archive_path) as zf:
                        zf.extractall(temp_path)

                    # Strip single top-level directory (e.g., RemoteDebug-main/)
                    entries = list(temp_path.iterdir())
                    if len(entries) == 1 and entries[0].is_dir():
                        source_dir = entries[0]
                    else:
                        source_dir = temp_path

                    # Move extracted contents into lib_dir/src/ to match registry structure
                    if library.src_dir.exists():
                        shutil.rmtree(library.src_dir)
                    shutil.move(str(source_dir), str(library.src_dir))

                # Clean up archive
                archive_path.unlink(missing_ok=True)

                # Create build metadata library.json (like registry downloads do)
                info_file = library.lib_dir / "library.json"
                if not info_file.exists():
                    # No library.json from repo — create minimal metadata
                    with open(info_file, "w", encoding="utf-8") as f:
                        json.dump(
                            {
                                "name": spec.name,
                                "owner": spec.owner,
                                "version": "github",
                                "github_url": url,
                            },
                            f,
                            indent=2,
                        )

                if show_progress:
                    log_detail(f"Library '{spec.name}' downloaded from GitHub")
                return
            except KeyboardInterrupt:
                raise
            except Exception:
                archive_path.unlink(missing_ok=True)
                continue

        raise LibraryErrorESP32(f"Failed to download {spec.name} from GitHub: {url} (tried main and master branches)")

    def download_library(self, spec: LibrarySpec, show_progress: bool = True) -> LibraryESP32:
        """Download a library from PlatformIO registry or set up local library.

        Args:
            spec: Library specification
            show_progress: Whether to show progress

        Returns:
            LibraryESP32 instance

        Raises:
            LibraryErrorESP32: If download or setup fails
        """
        try:
            # Check if this is a local library first
            if spec.is_local:
                return self._handle_local_library(spec, show_progress)

            # Remote library - use existing registry logic
            library = self.get_library(spec)

            # Skip if already downloaded
            if library.exists:
                if show_progress:
                    log_detail(f"Library '{spec.name}' already downloaded (cached)")
                return library

            # GitHub URL libraries — clone directly instead of using PlatformIO registry
            if spec.github_url:
                self._download_github_library(spec, library, show_progress)
                return library

            # Download from registry
            self.registry.download_library(spec, library.lib_dir, show_progress=show_progress)

            return library

        except RegistryError as e:
            raise LibraryErrorESP32(f"Failed to download library {spec}: {e}") from e

    def needs_rebuild(self, library: LibraryESP32, compiler_flags: List[str]) -> tuple[bool, str]:
        """Check if a library needs to be rebuilt.

        Args:
            library: Library to check
            compiler_flags: Current compiler flags

        Returns:
            Tuple of (needs_rebuild, reason)
        """
        if not library.archive_file.exists():
            return True, "Archive not found"

        if not library.build_info_file.exists():
            return True, "Build info missing"

        try:
            with open(library.build_info_file, "r", encoding="utf-8") as f:
                build_info = json.load(f)

            # Check if compiler flags changed
            stored_flags = build_info.get("compiler_flags", [])
            if stored_flags != compiler_flags:
                return True, "Compiler flags changed"

        except KeyboardInterrupt as ke:
            from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

            handle_keyboard_interrupt_properly(ke)
            raise  # Never reached, but satisfies type checker
        except Exception:
            return True, "Could not load build info"

        return False, ""

    def compile_library(
        self,
        library: LibraryESP32,
        toolchain_path: Path,
        compiler_flags: List[str],
        include_paths: List[Path],
        show_progress: bool = True,
    ) -> Path:
        """Compile a library into a static archive.

        Args:
            library: Library to compile
            toolchain_path: Path to toolchain bin directory
            compiler_flags: Compiler flags
            include_paths: Include directories
            show_progress: Whether to show progress

        Returns:
            Path to compiled archive file

        Raises:
            LibraryErrorESP32: If compilation fails
        """
        try:
            log_detail(f"Compiling library: {library.name}")

            # Get source files
            sources = library.get_source_files()
            if not sources:
                # Header-only library (e.g., ArduinoJson) — no compilation needed
                log_detail(f"Library '{library.name}' is header-only (no source files), skipping compilation")
                # Save build info so needs_rebuild() returns False next time
                build_info = {"compiler_flags": compiler_flags, "source_count": 0, "object_files": [], "header_only": True}
                with open(library.build_info_file, "w", encoding="utf-8") as f:
                    json.dump(build_info, f, indent=2)
                return library.archive_file

            log_detail(f"Found {len(sources)} source file(s)", indent=8)

            # Get library's own include directories
            lib_includes = library.get_include_dirs()
            all_includes = list(include_paths) + lib_includes

            # Auto-detect toolchain prefix from available binaries
            # ESP32/S2/S3 use xtensa, C3/C6/H2 use RISC-V
            gcc_path, gxx_path = self._find_toolchain_compilers(toolchain_path)

            # Create include flags and write to a response file to avoid Windows 32K limit
            include_flags_list = [f"-I{str(inc).replace(chr(92), '/')}" for inc in all_includes]
            rsp_dir = library.src_dir / ".rsp"
            rsp_arg = write_response_file(rsp_dir, include_flags_list, library.name)

            # Prepare compilation jobs
            compile_jobs = []
            # C++-only flags that must not be passed to gcc for .c files
            c_flags = [f for f in compiler_flags if not _is_cxx_only_flag(f)]
            for source in sources:
                # Determine compiler and flags based on extension
                if source.suffix in [".cpp", ".cc", ".cxx"]:
                    compiler = gxx_path
                    flags_for_file = compiler_flags
                else:
                    compiler = gcc_path
                    flags_for_file = c_flags

                # Output object file - maintain directory structure relative to src_dir
                # This prevents name collisions and keeps .d files organized
                rel_path = source.relative_to(library.src_dir)
                obj_file = library.src_dir / rel_path.with_suffix(".o")

                # Ensure output directory exists
                obj_file.parent.mkdir(parents=True, exist_ok=True)

                # Build compile command using response file for includes (avoids 32K limit)
                cmd = [str(compiler), "-c"]
                cmd.extend(flags_for_file)
                cmd.append(rsp_arg)
                cmd.extend(["-o", str(obj_file), str(source)])

                compile_jobs.append((source, obj_file, cmd))

            # Compile all source files in parallel
            object_files = []
            num_workers = multiprocessing.cpu_count()
            completed_count = 0
            total_count = len(compile_jobs)

            # Create per-build stderr directory for compiler output
            stderr_dir = create_stderr_dir(library.lib_dir)

            executor = ThreadPoolExecutor(max_workers=num_workers)
            try:
                # Submit all jobs with stderr_dir, keep ordered list
                ordered_futures: list[tuple[Future[tuple[Path, str]], Path]] = []
                for source, obj_file, cmd in compile_jobs:
                    job = (source, obj_file, cmd, stderr_dir)
                    future = executor.submit(_compile_single_file, job)
                    ordered_futures.append((future, source))

                # Iterate in submission order for deterministic stdout
                for future, source in ordered_futures:
                    completed_count += 1
                    try:
                        result_obj_file, _stderr = future.result()
                        object_files.append(result_obj_file)

                        if show_progress:
                            rel_path = source.relative_to(library.src_dir)
                            log_detail(f"[{completed_count}/{total_count}] {rel_path}", indent=8)
                    except KeyboardInterrupt:
                        raise
                    except Exception as e:
                        executor.shutdown(wait=False, cancel_futures=True)
                        raise LibraryErrorESP32(f"Failed to compile {source.name}: {e}")

            except KeyboardInterrupt as ke:
                executor.shutdown(wait=False, cancel_futures=True)
                from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

                handle_keyboard_interrupt_properly(ke)
                raise  # Never reached
            finally:
                executor.shutdown(wait=False)
                cleanup_stderr_dir(stderr_dir)

            # Create static archive using ar
            ar_path = self._find_toolchain_ar(toolchain_path)

            log_detail(f"Creating archive: {library.archive_file.name}", indent=8)

            # Remove old archive if exists
            if library.archive_file.exists():
                library.archive_file.unlink()

            # Create new archive
            cmd = [str(ar_path), "rcs", str(library.archive_file)]
            cmd.extend([str(obj) for obj in object_files])

            result = safe_run(cmd, capture_output=True, text=True, encoding="utf-8")

            if result.returncode != 0:
                raise LibraryErrorESP32(f"Failed to create archive for {library.name}:\n{result.stderr}")

            # Save build info
            build_info = {
                "compiler_flags": compiler_flags,
                "source_count": len(sources),
                "object_files": [str(obj) for obj in object_files],
            }
            with open(library.build_info_file, "w", encoding="utf-8") as f:
                json.dump(build_info, f, indent=2)

            log_detail(f"Library '{library.name}' compiled successfully")

            return library.archive_file

        except subprocess.CalledProcessError as e:
            raise LibraryErrorESP32(f"Compilation failed for library '{library.name}': {e}") from e
        except KeyboardInterrupt as ke:
            from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

            handle_keyboard_interrupt_properly(ke)
            raise  # Never reached, but satisfies type checker
        except Exception as e:
            raise LibraryErrorESP32(f"Failed to compile library '{library.name}': {e}") from e

    def prepare_compile_jobs(
        self,
        library: LibraryESP32,
        toolchain_path: Path,
        compiler_flags: List[str],
        include_paths: List[Path],
    ) -> List[tuple[Path, Path, list[str]]]:
        """Prepare compilation jobs for a library without executing them.

        Used by parallel compilation to flatten all source files across
        multiple libraries into a single thread pool.

        Args:
            library: Library to prepare jobs for
            toolchain_path: Path to toolchain bin directory
            compiler_flags: Compiler flags
            include_paths: Include directories

        Returns:
            List of (source_path, obj_file_path, compile_command) tuples.
            Returns empty list for header-only libraries.
        """
        sources = library.get_source_files()
        if not sources:
            # Header-only library — save build info so needs_rebuild() returns False
            build_info = {"compiler_flags": compiler_flags, "source_count": 0, "object_files": [], "header_only": True}
            with open(library.build_info_file, "w", encoding="utf-8") as f:
                json.dump(build_info, f, indent=2)
            return []

        lib_includes = library.get_include_dirs()
        all_includes = list(include_paths) + lib_includes

        gcc_path, gxx_path = self._find_toolchain_compilers(toolchain_path)

        include_flags_list = [f"-I{str(inc).replace(chr(92), '/')}" for inc in all_includes]
        rsp_dir = library.src_dir / ".rsp"
        rsp_arg = write_response_file(rsp_dir, include_flags_list, library.name)

        c_flags = [f for f in compiler_flags if not _is_cxx_only_flag(f)]
        compile_jobs: List[tuple[Path, Path, list[str]]] = []

        for source in sources:
            if source.suffix in [".cpp", ".cc", ".cxx"]:
                compiler_bin = gxx_path
                flags_for_file = compiler_flags
            else:
                compiler_bin = gcc_path
                flags_for_file = c_flags

            rel_path = source.relative_to(library.src_dir)
            obj_file = library.src_dir / rel_path.with_suffix(".o")
            obj_file.parent.mkdir(parents=True, exist_ok=True)

            cmd = [str(compiler_bin), "-c"]
            cmd.extend(flags_for_file)
            cmd.append(rsp_arg)
            cmd.extend(["-o", str(obj_file), str(source)])
            compile_jobs.append((source, obj_file, cmd))

        return compile_jobs

    def archive_library(
        self,
        library: LibraryESP32,
        toolchain_path: Path,
        object_files: List[Path],
        compiler_flags: List[str],
    ) -> Path:
        """Create a static archive from pre-compiled object files.

        Used by parallel compilation after all source files have been compiled.

        Args:
            library: Library to archive
            toolchain_path: Path to toolchain bin directory
            object_files: List of compiled .o files
            compiler_flags: Compiler flags (saved to build info for cache invalidation)

        Returns:
            Path to the created archive file

        Raises:
            LibraryErrorESP32: If archiving fails
        """
        ar_path = self._find_toolchain_ar(toolchain_path)

        if library.archive_file.exists():
            library.archive_file.unlink()

        cmd = [str(ar_path), "rcs", str(library.archive_file)]
        cmd.extend([str(obj) for obj in object_files])

        result = safe_run(cmd, capture_output=True, text=True, encoding="utf-8")
        if result.returncode != 0:
            raise LibraryErrorESP32(f"Failed to create archive for {library.name}:\n{result.stderr}")

        build_info = {
            "compiler_flags": compiler_flags,
            "source_count": len(object_files),
            "object_files": [str(obj) for obj in object_files],
        }
        with open(library.build_info_file, "w", encoding="utf-8") as f:
            json.dump(build_info, f, indent=2)

        return library.archive_file

    def ensure_libraries(
        self,
        lib_specs: List[str],
        toolchain_path: Path,
        compiler_flags: List[str],
        include_paths: List[Path],
        show_progress: bool = True,
        lib_ignore: Optional[set[str]] = None,
    ) -> List[LibraryESP32]:
        """Ensure all library dependencies are downloaded and compiled.

        Args:
            lib_specs: List of library specification strings
            toolchain_path: Path to toolchain bin directory
            compiler_flags: Compiler flags
            include_paths: Include directories
            show_progress: Whether to show progress
            lib_ignore: Optional set of lowercase library names to skip during transitive resolution

        Returns:
            List of compiled LibraryESP32 instances
        """
        libraries: List[LibraryESP32] = []
        downloaded_names: set[str] = set()

        # Parse all library specs upfront
        parsed_specs = [LibrarySpec.parse(spec_str) for spec_str in lib_specs]

        # Download all libraries in parallel (network I/O bound)
        max_download_workers = min(len(parsed_specs), 8)

        if max_download_workers <= 1:
            # Single library, no threading overhead needed
            for spec in parsed_specs:
                library = self.download_library(spec, show_progress)
                libraries.append(library)
                downloaded_names.add(library.name.lower())
        else:
            from concurrent.futures import Future

            if show_progress:
                log_detail(f"Downloading {len(parsed_specs)} libraries in parallel ({max_download_workers} workers)...")

            download_errors: list[Exception] = []

            dl_executor = ThreadPoolExecutor(max_workers=max_download_workers)
            try:
                # Submit all downloads, keep ordered list
                ordered_dl: list[tuple[Future[LibraryESP32], LibrarySpec]] = []
                for spec in parsed_specs:
                    future = dl_executor.submit(self.download_library, spec, show_progress)
                    ordered_dl.append((future, spec))

                # Iterate in order for deterministic output
                for future, spec in ordered_dl:
                    try:
                        lib = future.result()
                        libraries.append(lib)
                        downloaded_names.add(lib.name.lower())
                    except KeyboardInterrupt:
                        raise
                    except Exception as e:
                        download_errors.append(e)
            except KeyboardInterrupt as ke:
                dl_executor.shutdown(wait=False, cancel_futures=True)
                from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

                handle_keyboard_interrupt_properly(ke)
                raise  # Never reached
            finally:
                dl_executor.shutdown(wait=False)

            if download_errors:
                raise download_errors[0]

        # Resolve transitive dependencies from library.json files
        transitive_libs = self._resolve_transitive_deps(libraries, downloaded_names, show_progress, lib_ignore=lib_ignore)
        libraries.extend(transitive_libs)

        # Build augmented include paths with all library includes upfront
        # so that inter-library dependencies resolve (e.g., Adafruit GFX -> Adafruit BusIO)
        all_lib_includes: List[Path] = []
        for library in libraries:
            all_lib_includes.extend(library.get_include_dirs())
        augmented_includes = list(include_paths) + all_lib_includes

        # Compile all libraries using flat pool - all source files across all
        # libraries in one ThreadPoolExecutor for optimal CPU utilization
        libs_needing_compile: list[LibraryESP32] = []
        for library in libraries:
            needs_rebuild_flag, reason = self.needs_rebuild(library, compiler_flags)
            if needs_rebuild_flag:
                if reason:
                    log_detail(f"Rebuilding library '{library.name}': {reason}")
                libs_needing_compile.append(library)
            else:
                log_detail(f"Library '{library.name}' is up to date (cached)")

        if libs_needing_compile:
            # Phase 1: Prepare compile jobs for all libraries
            lib_compile_info: dict[str, tuple[LibraryESP32, list[Path]]] = {}
            all_jobs: list[tuple[str, Path, Path, list[str]]] = []

            for library in libs_needing_compile:
                jobs = self.prepare_compile_jobs(library, toolchain_path, compiler_flags, augmented_includes)
                if not jobs:
                    log_detail(f"Library '{library.name}' is header-only, skipping compilation")
                    continue
                lib_compile_info[library.name] = (library, [])
                for source, obj_file, cmd in jobs:
                    all_jobs.append((library.name, source, obj_file, cmd))

            # Phase 2: Compile ALL source files in one flat pool
            if all_jobs:
                num_workers = multiprocessing.cpu_count()
                total = len(all_jobs)
                completed_count = 0

                if show_progress:
                    log_detail(f"Compiling {total} source files across {len(lib_compile_info)} libraries ({num_workers} workers)")

                # Create per-build stderr directory for compiler output
                stderr_dir = create_stderr_dir(self.libs_dir)

                executor = ThreadPoolExecutor(max_workers=num_workers)
                try:
                    ordered_futures: list[tuple[Future[tuple[Path, str]], str, Path]] = []
                    for lib_name, source, obj_file, cmd in all_jobs:
                        future = executor.submit(_compile_single_file, (source, obj_file, cmd, stderr_dir))
                        ordered_futures.append((future, lib_name, source))

                    # Iterate in submission order for deterministic stdout
                    for future, lib_name, source in ordered_futures:
                        completed_count += 1
                        try:
                            result_obj, _stderr = future.result()
                            lib_compile_info[lib_name][1].append(result_obj)
                            if show_progress:
                                log_detail(f"[{completed_count}/{total}] {lib_name}/{source.name}", indent=8)
                        except KeyboardInterrupt:
                            raise
                        except Exception as e:
                            executor.shutdown(wait=False, cancel_futures=True)
                            raise LibraryErrorESP32(f"Failed to compile {source.name} in {lib_name}: {e}")

                except KeyboardInterrupt as ke:
                    executor.shutdown(wait=False, cancel_futures=True)
                    from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

                    handle_keyboard_interrupt_properly(ke)
                    raise  # Never reached
                finally:
                    executor.shutdown(wait=False)
                    cleanup_stderr_dir(stderr_dir)

            # Phase 3: Archive each library in parallel
            archive_tasks = [(name, lib, objs) for name, (lib, objs) in lib_compile_info.items() if objs]
            if len(archive_tasks) <= 1:
                for _name, lib, objs in archive_tasks:
                    self.archive_library(lib, toolchain_path, objs, compiler_flags)
            elif archive_tasks:
                ar_executor = ThreadPoolExecutor(max_workers=min(len(archive_tasks), 4))
                try:
                    ar_ordered = [(ar_executor.submit(self.archive_library, lib, toolchain_path, objs, compiler_flags), name) for name, lib, objs in archive_tasks]
                    for future, _name in ar_ordered:
                        future.result()
                except KeyboardInterrupt as ke:
                    ar_executor.shutdown(wait=False, cancel_futures=True)
                    from fbuild.interrupt_utils import handle_keyboard_interrupt_properly

                    handle_keyboard_interrupt_properly(ke)
                    raise  # Never reached
                finally:
                    ar_executor.shutdown(wait=False)

        return libraries

    def get_library_archives(self) -> List[Path]:
        """Get paths to all compiled library archives.

        Returns:
            List of .a archive file paths
        """
        archives = []
        if self.libs_dir.exists():
            for lib_dir in self.libs_dir.iterdir():
                if lib_dir.is_dir():
                    archive = lib_dir / f"lib{lib_dir.name}.a"
                    if archive.exists():
                        archives.append(archive)
        return archives

    def get_library_include_paths(self) -> List[Path]:
        """Get all include paths from downloaded libraries.

        Returns:
            List of include directory paths
        """
        include_paths = []
        if self.libs_dir.exists():
            for lib_dir in self.libs_dir.iterdir():
                if lib_dir.is_dir():
                    library = LibraryESP32(lib_dir, lib_dir.name)
                    if library.exists:
                        include_paths.extend(library.get_include_dirs())
        return include_paths
