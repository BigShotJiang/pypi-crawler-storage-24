"""UAI utility helpers."""
