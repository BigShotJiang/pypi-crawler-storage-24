"""UAI CLI package."""
