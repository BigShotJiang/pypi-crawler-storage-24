"""UAI CLI commands."""
