"""UAI core components."""
