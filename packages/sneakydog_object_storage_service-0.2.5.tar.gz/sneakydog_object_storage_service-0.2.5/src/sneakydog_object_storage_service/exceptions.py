"""自定义异常类"""


class OSSClientError(Exception):
    """基础异常"""

    pass


class ObjectNotFoundError(OSSClientError):
    """对象不存在"""

    pass


class PermissionDeniedError(OSSClientError):
    """权限拒绝"""

    pass


class ConfigError(OSSClientError):
    """配置错误"""

    pass


class BackendNotSupportedError(OSSClientError):
    """后端不支持"""

    pass


class UploadError(OSSClientError):
    """上传失败"""

    pass


class DownloadError(OSSClientError):
    """下载失败"""

    pass
