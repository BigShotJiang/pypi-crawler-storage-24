"""OSS Client SDK"""

from sneakydog_object_storage_service.async_client import AsyncOSSClient
from sneakydog_object_storage_service.base import ObjectInfo, StorageConfig
from sneakydog_object_storage_service.client import OSSClient
from sneakydog_object_storage_service.config import OSSConfig
from sneakydog_object_storage_service.exceptions import (
    BackendNotSupportedError,
    ConfigError,
    DownloadError,
    ObjectNotFoundError,
    OSSClientError,
    PermissionDeniedError,
    UploadError,
)

__version__ = "0.2.5"

__all__ = [
    "OSSClient",
    "AsyncOSSClient",
    "OSSConfig",
    "ObjectInfo",
    "StorageConfig",
    "OSSClientError",
    "ObjectNotFoundError",
    "PermissionDeniedError",
    "ConfigError",
    "BackendNotSupportedError",
    "UploadError",
    "DownloadError",
]
