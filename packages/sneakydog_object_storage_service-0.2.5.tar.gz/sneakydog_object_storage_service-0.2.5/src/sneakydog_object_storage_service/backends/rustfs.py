from sneakydog_object_storage_service.backends.s3 import S3Storage
from sneakydog_object_storage_service.base import StorageConfig


class RustFSStorage(S3Storage):
    """RustFS 兼容 S3 后端存储"""

    def __init__(self, config: StorageConfig):
        # 可以保留 RustFS 特有的 base_url 或 api_key 配置
        # 但底层客户端直接用 S3Storage 的 boto3 client
        super().__init__(config)
