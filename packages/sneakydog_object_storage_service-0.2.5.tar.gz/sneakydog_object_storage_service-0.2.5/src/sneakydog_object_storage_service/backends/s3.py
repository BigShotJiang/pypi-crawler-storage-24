from datetime import timedelta
from io import BytesIO

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from mypy_boto3_s3 import S3Client

from sneakydog_object_storage_service.base import ObjectInfo, StorageBackend, StorageConfig
from sneakydog_object_storage_service.exceptions import (
    ConfigError,
    DownloadError,
    ObjectNotFoundError,
    UploadError,
)


class S3Storage(StorageBackend):
    """S3/MinIO 存储后端 (boto3 实现)"""

    def __init__(self, config: StorageConfig):
        super().__init__(config)
        cfg = config.config

        access_key = cfg.get("access_key")
        secret_key = cfg.get("secret_key")
        endpoint = cfg.get("endpoint")
        secure = cfg.get("secure", True)

        if not access_key or not secret_key:
            raise ConfigError("S3Storage requires access_key and secret_key")

        self.client: S3Client = boto3.client(
            "s3",
            endpoint_url=f"https://{endpoint}" if secure else f"http://{endpoint}",
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=cfg.get("region", "us-east-1"),
            config=Config(
                signature_version="s3v4",
                s3={"addressing_style": "path"},
                connect_timeout=cfg.get("connect_timeout", 30),
                read_timeout=cfg.get("read_timeout", 30),
                retries={"max_attempts": cfg.get("max_retries", 3)},
            ),
        )

        self.bucket_name = cfg.get("bucket_name")

        if cfg.get("create_bucket_if_not_exists", False):
            self._ensure_bucket_exists()

    def _ensure_bucket_exists(self):
        try:
            self.client.head_bucket(Bucket=self.bucket_name)
        except ClientError as e:
            code = e.response["Error"]["Code"]
            if code == "404":
                region = self.client.meta.region_name
                if region == "us-east-1":
                    self.client.create_bucket(Bucket=self.bucket_name)
                else:
                    self.client.create_bucket(
                        Bucket=self.bucket_name,
                        CreateBucketConfiguration={"LocationConstraint": region},
                    )
            elif code == "403":
                pass
            else:
                raise

    # ========== 上传 / 下载 ==========

    def put_object(
        self,
        key: str,
        bytes_data,
        content_type: str | None = None,
        metadata: dict[str, str] | None = None,
    ) -> bool:
        try:
            extra_args = {}
            if content_type:
                extra_args["ContentType"] = content_type
            if metadata:
                extra_args["Metadata"] = metadata

            self.client.put_object(
                Bucket=self.bucket_name, Key=key, Body=BytesIO(bytes_data), **extra_args
            )
            return True
        except ClientError as e:
            raise UploadError(f"S3 upload failed: {str(e)}")

    def get_object(self, key: str) -> bytes:
        try:
            response = self.client.get_object(Bucket=self.bucket_name, Key=key)
            return response["Body"].read()
        except ClientError as e:
            if e.response["Error"]["Code"] in ("NoSuchKey", "404"):
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise DownloadError(f"S3 download failed: {str(e)}")

    def fget_object(self, key: str, local_path: str) -> bool:
        try:
            self.client.download_file(Bucket=self.bucket_name, Key=key, Filename=local_path)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] in ("NoSuchKey", "404"):
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise DownloadError(f"S3 download failed: {str(e)}")

    def delete(self, key: str) -> bool:
        try:
            self.client.delete_object(Bucket=self.bucket_name, Key=key)
            return True
        except ClientError as e:
            if e.response["Error"]["Code"] in ("NoSuchKey", "404"):
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise Exception(f"S3 delete failed: {str(e)}")

    def exists(self, key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket_name, Key=key)
            return True
        except ClientError:
            return False

    def list_objects(self, prefix: str | None = None, max_keys: int = 1000) -> list[ObjectInfo]:
        objects: list[ObjectInfo] = []
        try:
            paginator = self.client.get_paginator("list_objects_v2")
            page_iterator = paginator.paginate(
                Bucket=self.bucket_name, Prefix=prefix or "", MaxKeys=max_keys
            )
            for page in page_iterator:
                for obj in page.get("Contents", []):
                    objects.append(
                        ObjectInfo(
                            key=obj["Key"],
                            size=obj["Size"],
                            last_modified=obj["LastModified"],
                            etag=obj.get("ETag", "").strip('"'),
                            content_type=None,
                        )
                    )
                    if len(objects) >= max_keys:
                        break
                if len(objects) >= max_keys:
                    break
        except ClientError as e:
            raise Exception(f"S3 list failed: {str(e)}")
        return objects

    def get_object_info(self, key: str) -> ObjectInfo:
        try:
            resp = self.client.head_object(Bucket=self.bucket_name, Key=key)
            return ObjectInfo(
                key=key,
                size=resp["ContentLength"],
                last_modified=resp["LastModified"],
                etag=resp.get("ETag", "").strip('"'),
                content_type=resp.get("ContentType"),
                metadata=resp.get("Metadata", {}),
            )
        except ClientError as e:
            if e.response["Error"]["Code"] in ("NoSuchKey", "404"):
                raise ObjectNotFoundError(f"Object not found: {key}")
            raise Exception(f"S3 get_object_info failed: {str(e)}")

    def presigned_url(self, key: str, expires_in: timedelta = timedelta(days=7)) -> str:
        try:
            return self.client.generate_presigned_url(
                "get_object",
                Params={"Bucket": self.bucket_name, "Key": key},
                ExpiresIn=expires_in.total_seconds(),
            )
        except ClientError as e:
            raise Exception(f"S3 presigned URL failed: {str(e)}")
