"""配置管理"""

import json
import os
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field


class BackendConfig(BaseModel):
    """后端配置"""

    type: str
    extra_config: Any


class OSSConfig(BaseModel):
    """OSS 客户端配置"""

    default_backend: str = Field(default="local")
    backends: dict[str, dict[str, Any]] = Field(default_factory=dict)

    @classmethod
    def from_file(cls, path: str) -> "OSSConfig":
        """从文件加载配置"""
        path = Path(path)
        if path.suffix == ".json":
            with open(path) as f:
                data = json.load(f)
        elif path.suffix == ".toml":
            import toml

            with open(path) as f:
                data = toml.load(f)
        else:
            raise ValueError(f"Unsupported config file type: {path.suffix}")

        return cls(**data)

    @classmethod
    def from_env(cls) -> "OSSConfig":
        """从环境变量加载配置"""
        return cls(
            default_backend=os.getenv("OSS_DEFAULT_BACKEND", "local"),
            backends={
                "local": {"type": "local", "root_path": os.getenv("OSS_LOCAL_PATH", "./storage")},
                "minio": {
                    "type": "minio",
                    "endpoint": os.getenv("MINIO_ENDPOINT"),
                    "access_key": os.getenv("MINIO_ACCESS_KEY"),
                    "secret_key": os.getenv("MINIO_SECRET_KEY"),
                    "bucket_name": os.getenv("MINIO_BUCKET", "oss-client"),
                    "secure": os.getenv("MINIO_SECURE", "true").lower() == "true",
                },
            },
        )

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "OSSConfig":
        """从字典创建配置"""
        return cls(**data)

    def to_file(self, path: str):
        """保存配置到文件"""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)

        with open(path, "w") as f:
            json.dump(self.model_dump(), f, indent=2)
