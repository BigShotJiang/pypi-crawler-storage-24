"""分片上传工具"""

import hashlib
import os
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from typing import Callable, Optional

DEFAULT_CHUNK_SIZE = 5 * 1024 * 1024  # 5MB
MIN_CHUNK_SIZE = 5 * 1024 * 1024  # S3 最小 5MB
MAX_CHUNK_SIZE = 5 * 1024 * 1024 * 100  # 100MB


@dataclass
class UploadPart:
    """分片信息"""

    part_number: int
    etag: str
    size: int


@dataclass
class MultipartUploadResult:
    """分片上传结果"""

    key: str
    upload_id: str
    parts: list[UploadPart]
    total_size: int
    etag: Optional[str] = None


class MultipartUploader:
    """分片上传管理器"""

    def __init__(self, backend, chunk_size: int = DEFAULT_CHUNK_SIZE, max_workers: int = 4):
        """
        Args:
            backend: 存储后端实例
            chunk_size: 分片大小 (字节)
            max_workers: 并发上传线程数
        """
        self.backend = backend
        self.chunk_size = max(chunk_size, MIN_CHUNK_SIZE)
        self.max_workers = max_workers
        self.progress_callback: Optional[Callable[[int, int], None]] = None

    def set_progress_callback(self, callback: Callable[[int, int], None]):
        """设置进度回调 (uploaded_bytes, total_bytes)"""
        self.progress_callback = callback

    def _calculate_md5(self, data: bytes) -> str:
        """计算 MD5"""
        return hashlib.md5(data).hexdigest()

    def _upload_part(self, key: str, upload_id: str, part_number: int, data: bytes) -> UploadPart:
        """上传单个分片"""
        # 不同后端的分片上传实现不同，这里以 S3 为例
        if hasattr(self.backend, "upload_part"):
            etag = self.backend.upload_part(key, upload_id, part_number, data)
        else:
            # 降级为普通上传 (带分片标识)
            part_key = f"{key}.part{part_number}"
            self.backend.upload(part_key, data)
            etag = self._calculate_md5(data)

        return UploadPart(part_number=part_number, etag=etag, size=len(data))

    def upload(
        self,
        key: str,
        file_path: str,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> MultipartUploadResult:
        """
        分片上传文件

        Args:
            key: 对象键
            file_path: 本地文件路径
            content_type: 内容类型
            metadata: 元数据

        Returns:
            MultipartUploadResult
        """
        file_size = os.path.getsize(file_path)

        # 小文件直接上传
        if file_size <= self.chunk_size:
            with open(file_path, "rb") as f:
                data = f.read()
            self.backend.upload(key, data, content_type, metadata)
            return MultipartUploadResult(
                key=key,
                upload_id="",
                parts=[],
                total_size=file_size,
                etag=self._calculate_md5(data),
            )

        # 初始化分片上传
        if hasattr(self.backend, "initiate_multipart_upload"):
            upload_id = self.backend.initiate_multipart_upload(key, content_type, metadata)
        else:
            upload_id = hashlib.md5(f"{key}{file_size}".encode()).hexdigest()

        parts = []
        uploaded_bytes = 0
        part_number = 1

        with open(file_path, "rb") as f:
            with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
                futures = []

                while True:
                    data = f.read(self.chunk_size)
                    if not data:
                        break

                    future = executor.submit(self._upload_part, key, upload_id, part_number, data)
                    futures.append((future, len(data), part_number))
                    part_number += 1

                # 收集结果
                for future, size, pnum in futures:
                    part = future.result()
                    parts.append(part)
                    uploaded_bytes += size

                    if self.progress_callback:
                        self.progress_callback(uploaded_bytes, file_size)

        # 完成分片上传
        if hasattr(self.backend, "complete_multipart_upload"):
            etag = self.backend.complete_multipart_upload(key, upload_id, parts)
        else:
            etag = None

        return MultipartUploadResult(
            key=key, upload_id=upload_id, parts=parts, total_size=file_size, etag=etag
        )

    def upload_from_bytes(
        self,
        key: str,
        bytes,
        content_type: Optional[str] = None,
        metadata: Optional[dict[str, str]] = None,
    ) -> MultipartUploadResult:
        """从字节数据分片上传"""
        import tempfile

        with tempfile.NamedTemporaryFile(delete=False) as f:
            f.write(bytes)
            temp_path = f.name

        try:
            return self.upload(key, temp_path, content_type, metadata)
        finally:
            os.unlink(temp_path)
