from fastapi import APIRouter, Depends, HTTPException, Form
from typing import List, Optional
from pydantic import BaseModel
from ..dependencies import get_oss_client
from ..schemas import ErrorResponse

router = APIRouter(prefix="/api/v1/upload/multipart", tags=["Multipart Upload"])

class PartInfo(BaseModel):
    part_number: int
    etag: str

class CompleteMultipartRequest(BaseModel):
    upload_id: str
    key: str
    parts: List[PartInfo]

@router.post("/init")
async def init_multipart(
    key: str = Form(...),
    content_type: str = Form("application/octet-stream"),
    backend: str = Form("minio"),
    oss_client = Depends(get_oss_client)
):
    """
    1. 初始化分片上传
    返回 upload_id 供前端后续使用
    """
    try:
        backend_instance = oss_client.get_backend(backend)
        
        # 调用后端的原生分片初始化
        upload_id = backend_instance.initiate_multipart_upload(
            key=key,
            content_type=content_type
        )
        
        return {
            "success": True,
            "upload_id": upload_id,
            "key": key,
            "backend": backend
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.put("/part/{part_number}")
async def upload_part(
    part_number: int,
    upload_id: str = Form(...),
    key: str = Form(...),
    chunk = Form(...),  # 实际场景中通常是文件流
    backend: str = Form("minio"),
    oss_client = Depends(get_oss_client)
):
    """
    2. 上传单个分片
    前端分片后逐个调用此接口
    """
    try:
        backend_instance = oss_client.get_backend(backend)
        content = await chunk.read()
        
        # 调用后端的原生分片上传
        etag = backend_instance.upload_part(
            key=key,
            upload_id=upload_id,
            part_number=part_number,
            data=content
        )
        
        return {
            "success": True,
            "part_number": part_number,
            "etag": etag
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/complete")
async def complete_multipart(
    request: CompleteMultipartRequest,
    backend: str = Form("minio"),
    oss_client = Depends(get_oss_client)
):
    """
    3. 完成分片上传
    所有分片上传完成后调用，合并文件
    """
    try:
        backend_instance = oss_client.get_backend(backend)
        
        # 转换格式
        parts = [{"part_number": p.part_number, "etag": p.etag} for p in request.parts]
        
        backend_instance.complete_multipart_upload(
            key=request.key,
            upload_id=request.upload_id,
            parts=parts
        )
        
        return {
            "success": True,
            "key": request.key,
            "message": "Multipart upload completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))