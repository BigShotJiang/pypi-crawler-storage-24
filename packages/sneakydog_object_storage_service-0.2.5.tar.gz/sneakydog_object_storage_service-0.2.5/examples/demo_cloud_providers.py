"""多云厂商存储示例"""

from sneakydog_object_storage_service import OSSClient, OSSConfig
from sneakydog_object_storage_service.utils.progress import format_size, format_time
import os


def main():
    # 从环境变量或配置文件加载
    config = OSSConfig(
        default_backend="local",
        backends={
            # 本地存储 (测试用)
            "local": {"type": "local", "root_path": "./storage"},
            # AWS S3
            "aws": {
                "type": "aws_s3",
                "access_key": os.getenv("AWS_ACCESS_KEY"),
                "secret_key": os.getenv("AWS_SECRET_KEY"),
                "region": "us-east-1",
                "bucket_name": os.getenv("AWS_BUCKET", "your-bucket"),
            },
            # 华为云 OBS
            "huawei": {
                "type": "huawei_obs",
                "access_key_id": os.getenv("HUAWEI_AK"),
                "secret_access_key": os.getenv("HUAWEI_SK"),
                "endpoint": "obs.cn-north-1.myhuaweicloud.com",
                "region": "cn-north-1",
                "bucket_name": os.getenv("HUAWEI_BUCKET", "your-obs-bucket"),
            },
            # 阿里云 OSS
            "aliyun": {
                "type": "aliyun",
                "endpoint": "oss-cn-hangzhou.aliyuncs.com",
                "access_key_id": os.getenv("ALIYUN_AK"),
                "access_key_secret": os.getenv("ALIYUN_SK"),
                "bucket_name": os.getenv("ALIYUN_BUCKET", "your-oss-bucket"),
            },
            # 腾讯云 COS
            "tencent": {
                "type": "tencent",
                "region": "ap-guangzhou",
                "secret_id": os.getenv("TENCENT_ID"),
                "secret_key": os.getenv("TENCENT_KEY"),
                "bucket_name": os.getenv("TENCENT_BUCKET", "your-cos-bucket"),
            },
        },
    )

    client = OSSClient(config=config)

    # ========== 测试文件 ==========
    test_key = "demo/test_file.txt"
    test_data = b"Hello Multi-Cloud Storage!"

    print("=" * 60)
    print("🌍 多云存储测试")
    print("=" * 60)

    # 测试各个后端
    backends_to_test = ["local", "aws", "huawei", "aliyun", "tencent"]

    for backend_name in backends_to_test:
        try:
            backend = client.get_backend(backend_name)

            # 上传
            print(f"\n📤 测试 {backend_name} 上传...")
            client.put_object(test_key, test_data, backend=backend_name)
            print(f"   ✅ 上传成功")

            # 检查存在
            print(f"🔍 检查存在...")
            exists = client.exists(test_key, backend=backend_name)
            print(f"   ✅ 存在：{exists}")

            # 获取元信息
            print(f"📊 获取元信息...")
            info = client.get_object_info(test_key, backend=backend_name)
            print(f"   大小：{format_size(info.size)}")
            print(f"   时间：{info.last_modified}")

            # 下载
            print(f"📥 下载测试...")
            data = client.get_object(test_key, backend=backend_name)
            print(f"   ✅ 下载成功：{data.decode()}")

            # 预签名 URL
            print(f"🔗 生成预签名 URL...")
            url = client.presigned_url(test_key, expires_in=3600, backend=backend_name)
            print(f"   URL: {url[:80]}...")

            # 删除
            print(f"🗑️  清理测试文件...")
            client.delete(test_key, backend=backend_name)
            print(f"   ✅ 删除成功")

        except Exception as e:
            print(f"   ❌ {backend_name} 测试失败：{e}")

    # ========== 跨云复制 ==========
    print("\n" + "=" * 60)
    print("🔄 跨云复制测试")
    print("=" * 60)

    try:
        # 先上传到本地
        client.put_object("demo/source.txt", b"Cross-cloud data", backend="local")

        # 复制到 AWS
        client.copy_to_backend("demo/source.txt", "local", "aws", "demo/aws_copy.txt")
        print("✅ 本地 → AWS S3 复制成功")

        # 复制到华为云
        client.copy_to_backend("demo/source.txt", "local", "huawei", "demo/huawei_copy.txt")
        print("✅ 本地 → 华为 OBS 复制成功")

        # 清理
        client.delete("demo/source.txt", backend="local")
        client.delete("demo/aws_copy.txt", backend="aws")
        client.delete("demo/huawei_copy.txt", backend="huawei")

    except Exception as e:
        print(f"❌ 跨云复制失败：{e}")

    print("\n" + "=" * 60)
    print("✅ 测试完成!")
    print("=" * 60)


if __name__ == "__main__":
    main()
