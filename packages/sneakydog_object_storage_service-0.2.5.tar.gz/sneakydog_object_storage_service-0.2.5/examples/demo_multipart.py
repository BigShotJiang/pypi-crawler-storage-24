"""分片上传示例"""

import sys

from sneakydog_object_storage_service import OSSClient, OSSConfig
from sneakydog_object_storage_service.utils.multipart import MultipartUploader
from sneakydog_object_storage_service.utils.progress import ProgressTracker, format_size, format_time


def progress_callback(progress):
    """进度回调"""
    bar_length = 40
    filled = int(bar_length * progress.percent / 100)
    bar = "█" * filled + "░" * (bar_length - filled)

    print(
        f"\r[{bar}] {progress.percent:.1f}% | "
        f"{format_size(progress.uploaded)}/{format_size(progress.total)} | "
        f"{format_size(progress.speed)}/s | "
        f"ETA: {format_time(progress.eta)}",
        end="",
        flush=True,
    )

    if progress.percent >= 100:
        print()


def main():
    # 初始化客户端
    config = OSSConfig(
        default_backend="minio",
        backends={
            "minio": {
                "type": "minio",
                "endpoint": "play.min.io",
                "access_key": "Q3AM3UQ867SPQQA43P2F",
                "secret_key": "zuf+tfteSlswRu7BJ86wekitnifILbZam1KYY3TG",
                "bucket_name": "my-bucket",
                "secure": True,
            }
        },
    )

    client = OSSClient(config=config)
    backend = client.get_backend("minio")

    # 大文件路径
    file_path = sys.argv[1] if len(sys.argv) > 1 else "./large_file.zip"
    key = "uploads/large_file.zip"

    print(f"Uploading {file_path} to {key}...")

    # 创建分片上传器
    uploader = MultipartUploader(
        backend,
        chunk_size=10 * 1024 * 1024,  # 10MB per chunk
        max_workers=4,
    )

    # 设置进度回调
    def on_progress(uploaded, total):
        progress = ProgressTracker(total)
        progress.uploaded = uploaded
        # 简单进度显示
        percent = uploaded / total * 100
        print(f"\rProgress: {percent:.1f}%", end="", flush=True)

    uploader.set_progress_callback(on_progress)

    # 执行分片上传
    result = uploader.upload(key, file_path)

    print(f"\n✅ Upload complete!")
    print(f"   Key: {result.key}")
    print(f"   Size: {format_size(result.total_size)}")
    print(f"   Parts: {len(result.parts)}")
    print(f"   ETag: {result.etag}")


if __name__ == "__main__":
    main()
