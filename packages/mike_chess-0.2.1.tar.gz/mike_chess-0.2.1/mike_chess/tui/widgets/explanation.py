"""Explanation widget for opening trainer modes."""

from __future__ import annotations

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static


class ExplanationWidget(Static):
    """Displays the explanation for the current opening move."""

    DEFAULT_CSS = """
    ExplanationWidget {
        width: 100%;
        height: auto;
        min-height: 3;
        padding: 1;
        border: round $primary-background;
        background: $surface;
    }
    """

    move_san: reactive[str] = reactive("")
    explanation: reactive[str] = reactive("")

    def render(self) -> Text:
        text = Text()
        if self.move_san:
            text.append(self.move_san, style="bold")
            text.append("\n")
        if self.explanation:
            text.append(self.explanation)
        elif self.move_san:
            text.append("(Opponent's move)", style="dim")
        return text

    def watch_move_san(self, _value: str) -> None:
        self.refresh()

    def watch_explanation(self, _value: str) -> None:
        self.refresh()
