"""Widget displaying player info with captured pieces and eval."""

from __future__ import annotations

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static


class PlayerInfoWidget(Static):
    """Displays player name, captured pieces, and optional eval info."""

    DEFAULT_CSS = """
    PlayerInfoWidget {
        width: 100%;
        height: auto;
        padding: 0 2 0 2;
        margin: 1 1 0 1;
    }
    """

    player_name: reactive[str] = reactive("Player")
    is_white: reactive[bool] = reactive(True)
    captured_text: reactive[str] = reactive("")
    eval_text: reactive[str] = reactive("")
    is_active: reactive[bool] = reactive(False)

    def render(self) -> Text:
        """Render player info as Rich Text.

        Line 1: {active_indicator}{piece_icon} {player_name}    {eval_text}
        Line 2: captured pieces in dim style (if any)
        """
        piece_icon = "\u2659" if self.is_white else "\u265f"
        active_indicator = "\u25b8 " if self.is_active else "  "

        line1 = Text()
        line1.append(active_indicator)
        line1.append(f"{piece_icon} ")
        line1.append(self.player_name, style="bold")

        if self.eval_text:
            line1.append(f"    {self.eval_text}")

        result = line1

        if self.captured_text:
            result.append("\n")
            result.append(self.captured_text, style="dim")

        return result
