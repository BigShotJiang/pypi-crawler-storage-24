"""Modal dialog prompting the user to download Stockfish."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label


class StockfishModal(ModalScreen[bool]):
    """Modal asking whether to download the Stockfish engine.

    Dismisses with ``True`` to download or ``False`` to skip.
    """

    DEFAULT_CSS = """
    StockfishModal {
        align: center middle;
        background: rgba(0, 0, 0, 0.6);
    }

    StockfishModal #sf-container {
        width: auto;
        max-width: 52;
        height: auto;
        padding: 1 2;
        background: $surface;
        border: thick $primary;
    }

    StockfishModal #sf-title {
        width: 100%;
        text-align: center;
        text-style: bold;
        margin-bottom: 1;
    }

    StockfishModal #sf-body {
        width: 100%;
        text-align: center;
        margin-bottom: 1;
    }

    StockfishModal #sf-buttons {
        width: auto;
        height: auto;
        align-horizontal: center;
    }

    StockfishModal #sf-buttons Button {
        margin: 0 1;
        min-width: 16;
    }
    """

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", show=False),
    ]

    def compose(self) -> ComposeResult:
        with Vertical(id="sf-container"):
            yield Label("Stockfish Not Found", id="sf-title")
            yield Label(
                "Stockfish is required to play chess.\n"
                "Download it automatically?\n"
                "(~50 MB, installs to ~/.config/mike-chess/)",
                id="sf-body",
            )
            with Horizontal(id="sf-buttons"):
                yield Button("Download", id="btn-download", variant="primary")
                yield Button("Cancel", id="btn-cancel")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "btn-download":
            self.dismiss(True)
        else:
            self.dismiss(False)

    def action_cancel(self) -> None:
        self.dismiss(False)
