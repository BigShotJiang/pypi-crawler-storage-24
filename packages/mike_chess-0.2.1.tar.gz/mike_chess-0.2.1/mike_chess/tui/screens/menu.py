"""Main menu screen — hub for navigating to settings, learning, and play."""

from __future__ import annotations

import shutil

from rich.text import Text
from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.reactive import reactive
from textual.screen import Screen
from textual.widgets import Button, Footer, Header, Static

from mike_chess.main import VERSION
from mike_chess.settings import load_settings

# ── Constants ────────────────────────────────────────────────────────

ASCII_TITLE = """\
      ♚  M I K E   C H E S S
         ━━━━━━━━━━━━━━━━━━━"""

# Grid layout for two-column navigation: [row][col]
_GRID = [
    ["btn-engine", "btn-openings"],
    ["btn-lichess", "btn-play"],
    [None, "btn-analyze"],
]
_ALL_BUTTONS = [b for row in _GRID for b in row if b]


class MenuScreen(Screen):
    """Main menu — hub for navigating to subpages."""

    DEFAULT_CSS = """
MenuScreen {
    align: center middle;
}

#menu-container {
    width: 70;
    height: auto;
    max-height: 100%;
    border: heavy $primary;
    padding: 2 3;
    background: $surface;
    overflow-y: auto;
}

#menu-title {
    text-align: center;
    width: 100%;
    margin-bottom: 1;
    color: $text;
}

#menu-columns {
    width: 100%;
    height: auto;
}

.menu-col {
    width: 1fr;
    height: auto;
    padding: 0 6;
}

.section-header {
    width: 100%;
    height: 1;
    color: $text-muted;
    margin: 1 0 1 0;
    padding: 0 1;
}

.menu-col Button {
    width: 100%;
    margin-top: 1;
}

#status-bar {
    width: 100%;
    height: 1;
    margin-top: 2;
    color: $text-muted;
    padding: 0 1;
}
"""

    BINDINGS = [
        ("up", "nav_up", "Up"),
        ("down", "nav_down", "Down"),
        ("left", "nav_left", "Left"),
        ("right", "nav_right", "Right"),
        ("enter", "select", "Select"),
        ("q", "quit", "Quit"),
    ]

    _row: reactive[int] = reactive(0)
    _col: reactive[int] = reactive(0)

    def compose(self) -> ComposeResult:
        yield Header(show_clock=False)
        with Vertical(id="menu-container"):
            yield Static(ASCII_TITLE, id="menu-title")
            with Horizontal(id="menu-columns"):
                with Vertical(classes="menu-col"):
                    yield Static("── Settings ──", classes="section-header")
                    yield Button("⚙ Engine Settings", id="btn-engine")
                    yield Button("🌐 Lichess Settings", id="btn-lichess")
                with Vertical(classes="menu-col"):
                    yield Static("── Play & Learn ──", classes="section-header")
                    yield Button("♞ Learn Openings", id="btn-openings", variant="success")
                    yield Button("♚ Play Game", id="btn-play", variant="primary")
                    yield Button("♛ Analyze PGN", id="btn-analyze")
            yield Static("", id="status-bar")
        yield Footer()

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def on_mount(self) -> None:
        self._render_status_bar()
        self._update_highlight()

    # ------------------------------------------------------------------
    # Focus navigation
    # ------------------------------------------------------------------

    @property
    def _current_id(self) -> str | None:
        return _GRID[self._row][self._col]

    def _update_highlight(self) -> None:
        current = self._current_id
        for btn_id in _ALL_BUTTONS:
            try:
                btn = self.query_one(f"#{btn_id}", Button)
                if btn_id == current:
                    btn.focus()
                    btn.add_class("highlighted")
                else:
                    btn.remove_class("highlighted")
            except Exception:
                pass

    def watch__row(self, value: int) -> None:
        self._update_highlight()

    def watch__col(self, value: int) -> None:
        self._update_highlight()

    def action_nav_up(self) -> None:
        col = self._col
        row = self._row
        for _ in range(len(_GRID)):
            row = (row - 1) % len(_GRID)
            if _GRID[row][col] is not None:
                self._row = row
                return

    def action_nav_down(self) -> None:
        col = self._col
        row = self._row
        for _ in range(len(_GRID)):
            row = (row + 1) % len(_GRID)
            if _GRID[row][col] is not None:
                self._row = row
                return

    def action_nav_left(self) -> None:
        row = self._row
        col = self._col
        for _ in range(len(_GRID[0])):
            col = (col - 1) % len(_GRID[0])
            if _GRID[row][col] is not None:
                self._col = col
                return

    def action_nav_right(self) -> None:
        row = self._row
        col = self._col
        for _ in range(len(_GRID[0])):
            col = (col + 1) % len(_GRID[0])
            if _GRID[row][col] is not None:
                self._col = col
                return

    def action_select(self) -> None:
        current_id = self._current_id
        if current_id is None:
            return
        self._dispatch_button(current_id)

    # ------------------------------------------------------------------
    # Button handler
    # ------------------------------------------------------------------

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id:
            self._dispatch_button(event.button.id)

    def _dispatch_button(self, btn_id: str) -> None:
        if btn_id == "btn-engine":
            self._open_engine_settings()
        elif btn_id == "btn-lichess":
            self._open_lichess_settings()
        elif btn_id == "btn-openings":
            self._open_openings()
        elif btn_id == "btn-play":
            self._open_play()
        elif btn_id == "btn-analyze":
            self._action_analyze()

    # ------------------------------------------------------------------
    # Navigation
    # ------------------------------------------------------------------

    def _open_engine_settings(self) -> None:
        from mike_chess.tui.screens.engine_settings import EngineSettingsScreen
        self.app.push_screen(EngineSettingsScreen())

    def _open_lichess_settings(self) -> None:
        from mike_chess.tui.screens.lichess_settings import \
            LichessSettingsScreen
        self.app.push_screen(LichessSettingsScreen())

    def _open_openings(self) -> None:
        from mike_chess.tui.screens.opening_select import OpeningSelectScreen
        self.app.push_screen(OpeningSelectScreen())

    def _open_play(self) -> None:
        from mike_chess.tui.screens.play import PlayScreen
        self.app.push_screen(PlayScreen())

    def _action_analyze(self) -> None:
        self.notify("Analysis from file not yet implemented")

    def action_quit(self) -> None:
        self.app.exit()

    # ------------------------------------------------------------------
    # Status bar
    # ------------------------------------------------------------------

    def _render_status_bar(self) -> None:
        text = Text()
        text.append(f"v{VERSION}", style="dim")
        text.append("          ", style="dim")
        # Stockfish status
        from mike_chess.stockfish_manager import get_stockfish_path

        sf_found = get_stockfish_path() is not None
        text.append("Stockfish: ", style="dim")
        text.append(
            "\u2713 detected" if sf_found else "\u2717 not found",
            style="green" if sf_found else "red",
        )
        text.append("   ", style="dim")
        # Lichess token status
        settings = load_settings()
        has_token = bool(settings.lichess_api_token)
        text.append("Lichess: ", style="dim")
        text.append(
            "\u2713 ready" if has_token else "\u2717 no token",
            style="green" if has_token else "red",
        )
        try:
            self.query_one("#status-bar", Static).update(text)
        except Exception:
            pass
