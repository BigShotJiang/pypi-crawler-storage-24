"""London System opening data."""

import chess

from mike_chess.openings.models import Opening, OpeningNode

OPENING = Opening(
    name="London System",
    slug="london-system",
    color=chess.WHITE,
    description="A solid d4 opening with early Bf4 development",
    root=OpeningNode(
        move="d4",
        explanation="Control the center with the queen's pawn. The London System begins with d4, aiming for a solid, system-based approach.",
        children=[
            OpeningNode(
                move="d5",
                explanation="Black mirrors the central control.",
                children=[
                    OpeningNode(
                        move="Bf4",
                        explanation="Develop the dark-squared bishop before playing e3. This is the defining move of the London System — the bishop is placed on its best diagonal before the pawn blocks it in.",
                        children=[
                            OpeningNode(
                                move="Nf6",
                                explanation="Black develops a knight to a natural square.",
                                children=[
                                    OpeningNode(
                                        move="e3",
                                        explanation="Solidify the d4 pawn and open the diagonal for the light-squared bishop. Playing e3 after Bf4 (not before) is key — the bishop is already outside the pawn chain.",
                                        children=[
                                            OpeningNode(
                                                move="c5",
                                                explanation="Black challenges White's center immediately.",
                                                children=[
                                                    OpeningNode(
                                                        move="c3",
                                                        explanation="Support the d4 pawn. This is more resilient than Nc3 because the pawn holds the center even if pieces trade off.",
                                                        children=[
                                                            OpeningNode(
                                                                move="Nc6",
                                                                explanation="Black develops the knight, adding pressure to d4.",
                                                                children=[
                                                                    OpeningNode(
                                                                        move="Nd2",
                                                                        explanation="Develop the knight to d2 rather than c3. From d2 it can go to f3 without blocking the c-pawn, and supports a future e4 push.",
                                                                        children=[
                                                                            OpeningNode(
                                                                                move="e6",
                                                                                explanation="Black locks in the light-squared bishop to develop it later.",
                                                                                children=[
                                                                                    OpeningNode(
                                                                                        move="Ngf3",
                                                                                        explanation="Complete kingside development. The knight goes to f3 to control e5 and prepare short castling. White's setup is nearly complete.",
                                                                                        children=[
                                                                                            OpeningNode(
                                                                                                move="Bd6",
                                                                                                explanation="Black develops the bishop and challenges White's London bishop.",
                                                                                                children=[
                                                                                                    OpeningNode(
                                                                                                        move="Bg3",
                                                                                                        explanation="Retreat the bishop to g3 rather than trading. From g3 it still controls key dark squares and avoids giving Black the bishop pair.",
                                                                                                        children=[],
                                                                                                    ),
                                                                                                ],
                                                                                            ),
                                                                                        ],
                                                                                    ),
                                                                                ],
                                                                            ),
                                                                        ],
                                                                    ),
                                                                ],
                                                            ),
                                                        ],
                                                    ),
                                                ],
                                            ),
                                        ],
                                    ),
                                ],
                            ),
                        ],
                    ),
                ],
            ),
        ],
    ),
)
