"""Detect and download the Stockfish chess engine binary."""

from __future__ import annotations

import io
import os
import platform
import shutil
import stat
import tarfile
import zipfile
from pathlib import Path


_STOCKFISH_VERSION = "sf_18"
_GITHUB_BASE = (
    f"https://github.com/official-stockfish/Stockfish/releases/download/{_STOCKFISH_VERSION}"
)

_ASSET_MAP: dict[tuple[str, str], str] = {
    ("Darwin", "arm64"): "stockfish-macos-m1-apple-silicon.tar",
    ("Darwin", "x86_64"): "stockfish-macos-x86-64.tar",
    ("Linux", "x86_64"): "stockfish-ubuntu-x86-64.tar",
    ("Windows", "AMD64"): "stockfish-windows-x86-64.zip",
    ("Windows", "x86_64"): "stockfish-windows-x86-64.zip",
}


def _get_bin_dir() -> Path:
    base = os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))
    return Path(base) / "mike-chess" / "bin"


def _local_binary_path() -> Path:
    name = "stockfish.exe" if platform.system() == "Windows" else "stockfish"
    return _get_bin_dir() / name


def get_stockfish_path() -> str | None:
    """Return a path to Stockfish if available, or None.

    Checks system PATH first, then the local app binary directory.
    """
    system_path = shutil.which("stockfish")
    if system_path:
        return system_path

    local = _local_binary_path()
    if local.is_file():
        return str(local)

    return None


def _get_asset_name() -> str:
    system = platform.system()
    machine = platform.machine()
    key = (system, machine)
    asset = _ASSET_MAP.get(key)
    if asset is None:
        raise RuntimeError(
            f"No Stockfish binary available for {system} {machine}. "
            "Install Stockfish manually and ensure it is on your PATH."
        )
    return asset


def download_stockfish() -> Path:
    """Download the Stockfish binary for the current platform.

    Returns the path to the installed binary.
    Raises RuntimeError on unsupported platform or download failure.
    """
    import httpx

    asset_name = _get_asset_name()
    url = f"{_GITHUB_BASE}/{asset_name}"

    bin_dir = _get_bin_dir()
    bin_dir.mkdir(parents=True, exist_ok=True)

    with httpx.Client(follow_redirects=True, timeout=120) as client:
        resp = client.get(url)
        resp.raise_for_status()
        data = resp.content

    dest = _local_binary_path()

    if asset_name.endswith(".tar"):
        with tarfile.open(fileobj=io.BytesIO(data)) as tf:
            for member in tf.getmembers():
                if member.isfile() and member.name.split("/")[-1].startswith("stockfish"):
                    f = tf.extractfile(member)
                    if f:
                        dest.write_bytes(f.read())
                        break
            else:
                raise RuntimeError("Stockfish binary not found in archive")
    elif asset_name.endswith(".zip"):
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            for name in zf.namelist():
                basename = name.split("/")[-1]
                if basename.startswith("stockfish") and not name.endswith("/"):
                    dest.write_bytes(zf.read(name))
                    break
            else:
                raise RuntimeError("Stockfish binary not found in archive")
    else:
        dest.write_bytes(data)

    if platform.system() != "Windows":
        dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    return dest
