# Mike Chess — Reference

## Difficulty Presets (Stockfish 18)

| Preset | ELO |
|--------|-----|
| Newcomer | 1320 |
| Beginner | 1400 |
| Novice | 1500 |
| Amateur | 1600 |
| Casual | 1700 |
| Intermediate | 1800 |
| Proficient | 1900 |
| Skilled | 2000 |
| Advanced | 2100 |
| Strong | 2200 |
| Expert | 2300 |
| Candidate | 2400 |
| Master | 2500 |
| Veteran | 2600 |
| Grandmaster | 2700 |
| Champion | 2800 |
| Elite | 2900 |
| Legendary | 3000 |
| Supreme | 3100 |
| Maximum | Full strength |

## Analysis Classification

| Classification | CP Loss Threshold | Color |
|---------------|-------------------|-------|
| Best | 0 | Green |
| Excellent | < 10 | Green |
| Good | < 30 | White |
| Inaccuracy | 30-80 | Yellow |
| Mistake | 80-200 | Orange |
| Blunder | > 200 | Red |

Accuracy formula: `max(0, 100 - ACPL / 3)`

## In-Game Commands

**Game/Practice:** `help`, `moves`, `undo`, `resign`, `draw`, `eval`, `pgn`, `save [file]`, `quit`

**Drill:** `hint`, `restart`, `quit`, `help`
