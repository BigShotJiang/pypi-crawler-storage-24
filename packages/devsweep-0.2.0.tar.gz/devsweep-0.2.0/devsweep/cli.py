from __future__ import annotations

import json
import secrets
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

import typer

try:
    from send2trash import send2trash
except ImportError:  # pragma: no cover
    send2trash = None

app = typer.Typer(help="Clean up heavy dev artifacts under a root directory.")


@dataclass
class Entry:
    path: str
    size_bytes: int


def iter_node_modules(root: Path) -> Iterable[Path]:
    for path in root.rglob("node_modules"):
        if path.is_dir():
            yield path


def folder_size_bytes(path: Path) -> int:
    total = 0
    for p in path.rglob("*"):
        try:
            if p.is_file():
                total += p.stat().st_size
        except OSError:
            continue
    return total


def human_bytes(num: int) -> str:
    step = 1024.0
    for unit in ["B", "KB", "MB", "GB", "TB"]:
        if num < step:
            return f"{num:.2f} {unit}"
        num /= step
    return f"{num:.2f} PB"


def format_table(entries: List[Entry]) -> str:
    if not entries:
        return "No node_modules found."
    name_width = max(len(e.path) for e in entries)
    size_width = max(len(human_bytes(e.size_bytes)) for e in entries)
    lines = []
    header = f"{'path'.ljust(name_width)}  {'size'.rjust(size_width)}"
    lines.append(header)
    lines.append("-" * len(header))
    for e in entries:
        lines.append(f"{e.path.ljust(name_width)}  {human_bytes(e.size_bytes).rjust(size_width)}")
    total = sum(e.size_bytes for e in entries)
    lines.append("-" * len(header))
    lines.append(f"{'TOTAL'.ljust(name_width)}  {human_bytes(total).rjust(size_width)}")
    return "\n".join(lines)


def confirm_and_delete(paths: List[Path], label: str) -> None:
    if not paths:
        typer.echo(f"No {label} found.")
        return

    code = secrets.token_hex(3)
    typer.echo(
        f"\nDelete mode requested. This will move {len(paths)} {label} items to trash."
    )
    typer.echo(f"Type the confirmation code to proceed: {code}")
    typed = typer.prompt("Confirmation code")
    if typed.strip() != code:
        typer.echo("Confirmation code did not match. Aborting.")
        raise typer.Exit(code=1)

    if send2trash is None:
        typer.echo("send2trash not available; aborting for safety.")
        raise typer.Exit(code=1)

    deleted = 0
    skipped: list[str] = []
    for path in paths:
        if not path.exists():
            skipped.append(str(path))
            continue
        try:
            send2trash(str(path))
            deleted += 1
        except OSError:
            skipped.append(str(path))

    typer.echo(f"Deleted {deleted} items.")
    if skipped:
        typer.echo("Skipped missing or protected paths:")
        for item in skipped:
            typer.echo(f"- {item}")


@app.command("node")
def node_cleanup(
    root: Path = typer.Argument(..., exists=True, file_okay=False, dir_okay=True),
    format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json, txt."
    ),
    limit: int | None = typer.Option(
        None, "--limit", min=1, help="Limit number of rows returned."
    ),
    delete: bool = typer.Option(
        False,
        "--delete",
        help="Move discovered node_modules folders to trash (requires confirmation).",
    ),
) -> None:
    entries: List[Entry] = []
    for path in iter_node_modules(root):
        size = folder_size_bytes(path)
        entries.append(Entry(path=str(path), size_bytes=size))

    entries.sort(key=lambda e: e.size_bytes, reverse=True)
    if limit:
        entries = entries[:limit]

    fmt = format.lower()
    if delete:
        confirm_and_delete([Path(e.path) for e in entries], "node_modules")
        return

    if fmt == "json":
        payload = [
            {"path": e.path, "size_bytes": e.size_bytes, "size": human_bytes(e.size_bytes)}
            for e in entries
        ]
        typer.echo(json.dumps(payload, indent=2))
        return

    if fmt == "txt":
        lines = [f"{e.path}\t{e.size_bytes}" for e in entries]
        typer.echo("\n".join(lines) if lines else "")
        return

    if fmt == "table":
        typer.echo(format_table(entries))
        return

    raise typer.BadParameter("format must be one of: table, json, txt")


def iter_named(root: Path, names: set[str]) -> Iterable[Path]:
    for path in root.rglob("*"):
        if path.is_dir() and path.name in names:
            yield path


def iter_pycache_files(root: Path) -> Iterable[Path]:
    for path in root.rglob("*.pyc"):
        if path.is_file():
            yield path


def iter_r_files(root: Path) -> Iterable[Path]:
    for pattern in [".Rhistory", ".RData"]:
        for path in root.rglob(pattern):
            if path.is_file():
                yield path


@app.command("python")
def python_cleanup(
    root: Path = typer.Argument(..., exists=True, file_okay=False, dir_okay=True),
    format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json, txt."
    ),
    delete: bool = typer.Option(False, "--delete", help="Move Python caches to trash."),
) -> None:
    targets = list(
        iter_named(root, {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", ".tox", ".nox"})
    )
    targets.extend(iter_pycache_files(root))
    targets.extend(list(root.rglob(".coverage")))
    targets.extend(list(root.rglob(".coverage.*")))

    if delete:
        confirm_and_delete(list(dict.fromkeys(targets)), "python cache")
        return

    fmt = format.lower()
    unique = list(dict.fromkeys(targets))
    sized = [
        (item, folder_size_bytes(item) if item.is_dir() else item.stat().st_size)
        for item in unique
        if item.exists()
    ]

    if fmt == "json":
        payload = [
            {"path": str(item), "size_bytes": size, "size": human_bytes(size)}
            for item, size in sized
        ]
        typer.echo(json.dumps(payload, indent=2))
        return

    if fmt == "txt":
        typer.echo("\n".join(f"{item}\t{size}" for item, size in sized))
        return

    if fmt == "table":
        if not sized:
            typer.echo("No python cache found.")
            return
        width = max(len(str(item)) for item, _ in sized)
        size_width = max(len(human_bytes(size)) for _, size in sized)
        lines = [f"{'path'.ljust(width)}  {'size'.rjust(size_width)}", "-" * (width + 2 + size_width)]
        for item, size in sized:
            lines.append(f"{str(item).ljust(width)}  {human_bytes(size).rjust(size_width)}")
        total = sum(size for _, size in sized)
        lines.append("-" * (width + 2 + size_width))
        lines.append(f"{'TOTAL'.ljust(width)}  {human_bytes(total).rjust(size_width)}")
        typer.echo("\n".join(lines))
        return

    raise typer.BadParameter("format must be one of: table, json, txt")


@app.command("r")
def r_cleanup(
    root: Path = typer.Argument(..., exists=True, file_okay=False, dir_okay=True),
    format: str = typer.Option(
        "table", "--format", "-f", help="Output format: table, json, txt."
    ),
    delete: bool = typer.Option(False, "--delete", help="Move R caches to trash."),
) -> None:
    targets = list(iter_named(root, {".Rproj.user"}))
    targets.extend(iter_r_files(root))
    targets.extend(list(root.rglob("renv/library")))
    targets.extend(list(root.rglob("renv/staging")))
    targets.extend(list(root.rglob("renv/.cache")))

    if delete:
        confirm_and_delete(list(dict.fromkeys(targets)), "R cache")
        return

    fmt = format.lower()
    unique = list(dict.fromkeys(targets))
    sized = [
        (item, folder_size_bytes(item) if item.is_dir() else item.stat().st_size)
        for item in unique
        if item.exists()
    ]

    if fmt == "json":
        payload = [
            {"path": str(item), "size_bytes": size, "size": human_bytes(size)}
            for item, size in sized
        ]
        typer.echo(json.dumps(payload, indent=2))
        return

    if fmt == "txt":
        typer.echo("\n".join(f"{item}\t{size}" for item, size in sized))
        return

    if fmt == "table":
        if not sized:
            typer.echo("No R cache found.")
            return
        width = max(len(str(item)) for item, _ in sized)
        size_width = max(len(human_bytes(size)) for _, size in sized)
        lines = [f"{'path'.ljust(width)}  {'size'.rjust(size_width)}", "-" * (width + 2 + size_width)]
        for item, size in sized:
            lines.append(f"{str(item).ljust(width)}  {human_bytes(size).rjust(size_width)}")
        total = sum(size for _, size in sized)
        lines.append("-" * (width + 2 + size_width))
        lines.append(f"{'TOTAL'.ljust(width)}  {human_bytes(total).rjust(size_width)}")
        typer.echo("\n".join(lines))
        return

    raise typer.BadParameter("format must be one of: table, json, txt")


if __name__ == "__main__":
    app()
