#!/usr/bin/env bash
set -euo pipefail

if [[ -f .env ]]; then
  # shellcheck disable=SC1091
  source .env
fi

if [[ -z "${PYPI_API_TOKEN:-}" ]]; then
  echo "PYPI_API_TOKEN not set. Add it to .env or export it in your shell." >&2
  exit 1
fi

uv pip install --upgrade build twine
uv run -- python -m build
uv run -- twine upload -u __token__ -p "$PYPI_API_TOKEN" dist/* --verbose
