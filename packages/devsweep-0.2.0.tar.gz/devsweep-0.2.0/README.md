# devsweep (dc)

Clean up heavy dev artifacts under a root directory: `node_modules`, Python caches, and R caches.

## Install / run with uv

```bash
uv sync
uv run dc node /path/to/root --format table
```

## Publish to PyPI (local)

```bash
cp .env.example .env
# add PYPI_API_TOKEN to .env
uv sync
./scripts/publish.sh
```

## Examples

```bash
# Node.js node_modules size report
uv run dc node ~/Documents --format table
uv run dc node ~/Documents --format json
uv run dc node ~/Documents --format txt --limit 50

# Delete node_modules (moves to trash, requires confirmation code)
uv run dc node ~/Documents --delete

# Python cleanup (removes __pycache__, .pytest_cache, *.pyc, etc.)
uv run dc python ~/Documents --delete

# R cleanup (removes .Rhistory, .RData, .Rproj.user, renv library caches)
uv run dc r ~/Documents --delete
```
