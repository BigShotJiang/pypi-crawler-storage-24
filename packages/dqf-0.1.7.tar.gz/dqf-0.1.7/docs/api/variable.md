# Variable

::: dqf.Variable
