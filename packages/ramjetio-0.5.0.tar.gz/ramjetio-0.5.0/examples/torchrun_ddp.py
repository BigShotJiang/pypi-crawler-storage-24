"""
Example: Integrating RAMJET with torchrun DDP training.

This example shows how to use RAMJET distributed cache in a typical
PyTorch DDP training script launched with torchrun.

Run with:
    export RAMJET_API_KEY="your_key"
    torchrun --nproc_per_node=2 examples/torchrun_ddp.py
"""

import os
import torch
import torch.nn as nn
import torch.distributed as dist
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import Dataset, DataLoader
from torch.utils.data.distributed import DistributedSampler

import ramjetio


# =============================================================================
# Your Model (example)
# =============================================================================

class SimpleModel(nn.Module):
    """Simple CNN for demonstration."""
    
    def __init__(self, num_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(3, 32, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
            nn.Conv2d(32, 64, 3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2),
        )
        self.classifier = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(64, num_classes),
        )
    
    def forward(self, x):
        x = self.features(x)
        x = self.classifier(x)
        return x


# =============================================================================
# Your Dataset (example)
# =============================================================================

class SyntheticDataset(Dataset):
    """Synthetic dataset for demonstration.
    
    In real use, replace this with your actual dataset.
    """
    
    def __init__(self, size=1000, img_size=64, num_classes=10):
        self.size = size
        self.img_size = img_size
        self.num_classes = num_classes
    
    def __len__(self):
        return self.size
    
    def __getitem__(self, idx):
        # Simulate slow preprocessing
        import time
        time.sleep(0.01)
        
        # Generate random image and label
        image = torch.randn(3, self.img_size, self.img_size)
        label = idx % self.num_classes
        return image, label


# =============================================================================
# Training
# =============================================================================

def train():
    # -------------------------------------------------------------------------
    # Step 1: Initialize distributed (torchrun sets env vars)
    # -------------------------------------------------------------------------
    dist.init_process_group("nccl")
    
    rank = dist.get_rank()
    world_size = dist.get_world_size()
    local_rank = int(os.environ["LOCAL_RANK"])
    
    torch.cuda.set_device(local_rank)
    device = torch.device(f"cuda:{local_rank}")
    
    if rank == 0:
        print(f"Training with {world_size} GPUs")
    
    # -------------------------------------------------------------------------
    # Step 2: Initialize RAMJET (after DDP init)
    # -------------------------------------------------------------------------
    ramjetio.init()
    
    # -------------------------------------------------------------------------
    # Step 3: Create model with DDP
    # -------------------------------------------------------------------------
    model = SimpleModel(num_classes=10).to(device)
    model = DDP(model, device_ids=[local_rank])
    
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()
    
    # -------------------------------------------------------------------------
    # Step 4: Create cached dataset with distributed sampler
    # -------------------------------------------------------------------------
    base_dataset = SyntheticDataset(size=1000)
    
    # Wrap with RAMJET cache
    dataset = ramjetio.CachedDataset(
        base_dataset,
        cache=ramjetio.get_cache(),
        key_fn=lambda idx: f"sample_{idx}",
    )
    
    # DDP sampler
    sampler = DistributedSampler(
        dataset,
        num_replicas=world_size,
        rank=rank,
        shuffle=True,
    )
    
    loader = DataLoader(
        dataset,
        batch_size=32,
        sampler=sampler,
        num_workers=4,
        pin_memory=True,
    )
    
    # -------------------------------------------------------------------------
    # Step 5: Training loop
    # -------------------------------------------------------------------------
    num_epochs = 5
    
    for epoch in range(num_epochs):
        sampler.set_epoch(epoch)  # Important for shuffling
        model.train()
        
        total_loss = 0
        for batch_idx, (images, labels) in enumerate(loader):
            images = images.to(device)
            labels = labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            
            # Log progress
            if rank == 0 and batch_idx % 10 == 0:
                print(f"Epoch {epoch+1}/{num_epochs}, Batch {batch_idx}, Loss: {loss.item():.4f}")
        
        # Print cache stats
        if rank == 0:
            stats = dataset.get_cache_stats()
            print(f"Epoch {epoch+1} complete. "
                  f"Avg Loss: {total_loss/len(loader):.4f}, "
                  f"Cache: {stats['cache_hits']} hits, {stats['cache_misses']} misses, "
                  f"Hit rate: {stats['hit_rate']:.1f}%")
    
    # -------------------------------------------------------------------------
    # Cleanup
    # -------------------------------------------------------------------------
    ramjetio.shutdown()
    dist.destroy_process_group()
    
    if rank == 0:
        print("Training complete!")


if __name__ == "__main__":
    train()
