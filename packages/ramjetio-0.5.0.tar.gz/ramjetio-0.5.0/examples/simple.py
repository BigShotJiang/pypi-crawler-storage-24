"""
Example: Simple RAMJET usage.

This is the simplest way to use RAMJET in your training script.
"""

import ramjetio
from torch.utils.data import Dataset, DataLoader


class YourDataset(Dataset):
    """Replace with your actual dataset."""
    
    def __init__(self, size=1000):
        self.size = size
    
    def __len__(self):
        return self.size
    
    def __getitem__(self, idx):
        import torch
        import time
        
        # Simulate slow preprocessing
        time.sleep(0.01)
        
        data = torch.randn(3, 64, 64)
        label = idx % 10
        return data, label


def main():
    # Step 1: Initialize RAMJET
    ramjetio.init()
    
    # Step 2: Wrap your dataset with cache
    dataset = ramjetio.CachedDataset(YourDataset(), ramjetio.get_cache())
    
    # Step 3: Create DataLoader as usual
    loader = DataLoader(dataset, batch_size=32, num_workers=4)
    
    # Step 4: Train (first epoch populates cache, next epochs are fast)
    for epoch in range(3):
        print(f"\nEpoch {epoch + 1}")
        for batch_idx, (data, labels) in enumerate(loader):
            # Your training code here
            if batch_idx % 10 == 0:
                print(f"  Batch {batch_idx}")
        
        stats = dataset.get_cache_stats()
        print(f"  Cache stats: {stats}")
    
    # Step 5: Cleanup
    ramjetio.shutdown()


if __name__ == "__main__":
    main()
