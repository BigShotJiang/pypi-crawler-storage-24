"""
Example: Using RAMJET with HuggingFace Accelerate.
"""

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

import ramjetio

# Accelerate import (install with: pip install accelerate)
try:
    from accelerate import Accelerator
except ImportError:
    print("Accelerate not installed. Run: pip install accelerate")
    exit(1)


class SimpleModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 10),
        )
    
    def forward(self, x):
        return self.layers(x.view(x.size(0), -1))


class YourDataset(Dataset):
    def __init__(self, size=1000):
        self.size = size
    
    def __len__(self):
        return self.size
    
    def __getitem__(self, idx):
        import time
        time.sleep(0.01)  # Simulate slow preprocessing
        data = torch.randn(256)
        label = idx % 10
        return data, label


def main():
    # Initialize Accelerator
    accelerator = Accelerator()
    
    # Initialize RAMJET
    ramjetio.init()
    
    # Create model
    model = SimpleModel()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()
    
    # Wrap dataset with RAMJET cache
    dataset = ramjetio.CachedDataset(YourDataset(), ramjetio.get_cache())
    loader = DataLoader(dataset, batch_size=32, num_workers=4)
    
    # Prepare with Accelerate
    model, optimizer, loader = accelerator.prepare(model, optimizer, loader)
    
    # Training loop
    for epoch in range(3):
        model.train()
        for batch_idx, (data, labels) in enumerate(loader):
            optimizer.zero_grad()
            outputs = model(data)
            loss = criterion(outputs, labels)
            accelerator.backward(loss)
            optimizer.step()
            
            if batch_idx % 10 == 0:
                print(f"Epoch {epoch}, Batch {batch_idx}, Loss: {loss.item():.4f}")
        
        print(f"Epoch {epoch} cache stats: {dataset.get_cache_stats()}")
    
    ramjetio.shutdown()


if __name__ == "__main__":
    main()
