"""
Example: Using RAMJET with DeepSpeed.
"""

import os
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

import ramjetio

# DeepSpeed import (install with: pip install deepspeed)
try:
    import deepspeed
except ImportError:
    print("DeepSpeed not installed. Run: pip install deepspeed")
    exit(1)


class SimpleModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, 10),
        )
    
    def forward(self, x):
        return self.layers(x.view(x.size(0), -1))


class YourDataset(Dataset):
    def __init__(self, size=1000):
        self.size = size
    
    def __len__(self):
        return self.size
    
    def __getitem__(self, idx):
        import time
        time.sleep(0.01)  # Simulate slow preprocessing
        data = torch.randn(256)
        label = idx % 10
        return data, label


def main():
    # Initialize RAMJET
    ramjetio.init()
    
    # Create model
    model = SimpleModel()
    
    # Wrap dataset with RAMJET cache
    dataset = ramjetio.CachedDataset(YourDataset(), ramjetio.get_cache())
    
    # DeepSpeed config
    ds_config = {
        "train_batch_size": 32,
        "gradient_accumulation_steps": 1,
        "optimizer": {
            "type": "Adam",
            "params": {"lr": 0.001}
        },
        "fp16": {"enabled": False},
        "zero_optimization": {"stage": 0},
    }
    
    # Initialize DeepSpeed
    model_engine, optimizer, _, _ = deepspeed.initialize(
        model=model,
        model_parameters=model.parameters(),
        training_data=dataset,
        config=ds_config,
    )
    
    # Training loop
    for epoch in range(3):
        for batch_idx, (data, labels) in enumerate(model_engine.training_dataloader):
            data = data.to(model_engine.device)
            labels = labels.to(model_engine.device)
            
            outputs = model_engine(data)
            loss = nn.CrossEntropyLoss()(outputs, labels)
            
            model_engine.backward(loss)
            model_engine.step()
            
            if batch_idx % 10 == 0:
                print(f"Epoch {epoch}, Batch {batch_idx}, Loss: {loss.item():.4f}")
        
        print(f"Epoch {epoch} cache stats: {dataset.get_cache_stats()}")
    
    ramjetio.shutdown()


if __name__ == "__main__":
    main()
