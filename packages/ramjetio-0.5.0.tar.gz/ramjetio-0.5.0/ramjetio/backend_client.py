"""
RAMJET Backend Client

gRPC client for connecting to RAMJET backend.
Handles node registration, heartbeat, and metrics push.

Usage:
    # API key is read from environment: RAMJET_API_KEY
    from ramjetio.backend_client import BackendClient
    
    client = BackendClient(node_port=9000)
    if client.connect():
        client.start_heartbeat(get_metrics_fn)
"""

import os
import grpc
import time
import socket
import threading
import logging
from typing import Optional, Dict, Any, Callable

from ramjetio.config import (
    RAMJET_BACKEND_URL,
    RAMJET_BACKEND_USE_SSL,
    get_api_key,
    is_configured,
    HEARTBEAT_INTERVAL,
    RECONNECT_INTERVAL,
    MAX_RECONNECT_ATTEMPTS,
)

logger = logging.getLogger(__name__)


def mask_api_key(api_key: str) -> str:
    """Mask API key for safe logging."""
    if not api_key or len(api_key) < 12:
        return "***"
    return f"{api_key[:8]}...{api_key[-4:]}"


class BackendClient:
    """
    Client for communicating with RAMJET backend.
    
    Handles:
    - Node registration on startup
    - Periodic heartbeat with metrics
    - Configuration updates from backend
    
    The backend URL is hardcoded - users only need to set RAMJET_API_KEY.
    """
    
    def __init__(
        self,
        node_port: int = 9000,
        api_key: Optional[str] = None,
    ):
        """
        Initialize backend client.
        
        Args:
            node_port: Port this cache server is running on
            api_key: API key (if not provided, reads from RAMJET_API_KEY env var)
        """
        self.api_key = api_key or get_api_key()
        self.node_port = node_port
        # Use RAMJET_NODE_HOSTNAME env override, or resolve the IP address.
        # socket.gethostname() returns Docker container IDs which aren't
        # resolvable by other machines on the network.
        self.hostname = os.environ.get('RAMJET_NODE_HOSTNAME') or self._resolve_hostname()
        
        # Connection state
        self.node_id: Optional[str] = None
        self.cluster_id: Optional[str] = None
        self.cluster_config: Optional[Dict] = None
        self._connected = False
        
        # Background threads
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._reconnect_thread: Optional[threading.Thread] = None
        self._running = False
        self._get_metrics_fn: Optional[Callable] = None
        
        # Config change callback (called when backend pushes new config)
        self._on_config_changed: Optional[Callable[[Dict[str, Any]], None]] = None
        
        # gRPC channel and stub
        self._channel: Optional[grpc.Channel] = None
        self._stub = None
        self._pb2 = None
    
    @staticmethod
    def _resolve_hostname() -> str:
        """Resolve a routable hostname/IP for this node."""
        # Try to get external-facing IP by connecting to a remote address
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(1)
            s.connect(('8.8.8.8', 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            pass
        # Fallback to gethostname
        return socket.gethostname()
        
    @property
    def is_connected(self) -> bool:
        """Check if connected to backend."""
        return self._connected and self.node_id is not None
    
    def connect(self) -> bool:
        """
        Connect to backend and register this node.
        
        Returns:
            True if connected successfully, False otherwise
        """
        if not self.api_key:
            logger.warning(
                "RAMJET API key not configured. "
                "Set RAMJET_API_KEY environment variable. "
                "Metrics will not be sent to backend."
            )
            return False
        
        # API key format: {cluster_name}_{secret}
        if '_' not in self.api_key or len(self.api_key) < 10:
            logger.warning("Invalid API key format. API key should be in format: clustername_secret")
            return False
        
        try:
            # Create gRPC channel
            if RAMJET_BACKEND_USE_SSL:
                credentials = grpc.ssl_channel_credentials()
                self._channel = grpc.secure_channel(RAMJET_BACKEND_URL, credentials)
            else:
                self._channel = grpc.insecure_channel(RAMJET_BACKEND_URL)
            
            # Import generated proto (will fail gracefully if not available)
            try:
                from ramjetio.proto import ramjet_pb2, ramjet_pb2_grpc
            except ImportError:
                logger.warning(
                    "Proto files not generated. Run 'python -m grpc_tools.protoc' to generate. "
                    "Backend connection disabled."
                )
                return False
            
            self._stub = ramjet_pb2_grpc.NodeServiceStub(self._channel)
            self._pb2 = ramjet_pb2
            
            # Register node (mask API key in logs)
            logger.info(
                f"Registering node {self.hostname}:{self.node_port} with backend "
                f"(key: {mask_api_key(self.api_key)})..."
            )
            
            response = self._stub.RegisterNode(ramjet_pb2.RegisterNodeRequest(
                api_key=self.api_key,
                hostname=self.hostname,
                port=self.node_port,
                version=self._get_version(),
            ), timeout=10)
            
            self.node_id = response.node_id
            self.cluster_id = response.cluster_id
            self.cluster_config = self._parse_config(response.config)
            self._connected = True
            
            logger.info(
                f"✓ Registered with backend: node_id={self.node_id}, "
                f"cluster_id={self.cluster_id}"
            )
            
            return True
            
        except grpc.RpcError as e:
            status_code = e.code()
            if status_code == grpc.StatusCode.UNAUTHENTICATED:
                logger.error(f"Invalid API key ({mask_api_key(self.api_key)}). Please check your RAMJET_API_KEY.")
            elif status_code == grpc.StatusCode.UNAVAILABLE:
                logger.error(f"Backend unavailable at {RAMJET_BACKEND_URL}. Will retry...")
            else:
                logger.error(f"Failed to connect to backend: {e.details()}")
            return False
            
        except Exception as e:
            logger.error(f"Unexpected error connecting to backend: {e}")
            return False
    
    def start_heartbeat(
        self, 
        get_metrics_fn: Callable[[], Dict[str, Any]], 
        interval: float = HEARTBEAT_INTERVAL,
        auto_reconnect: bool = True,
        on_config_changed: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> None:
        """
        Start background heartbeat thread.
        
        Args:
            get_metrics_fn: Function that returns current metrics dict
            interval: Seconds between heartbeats (default: 2.0)
            auto_reconnect: Whether to automatically reconnect on connection loss
            on_config_changed: Callback invoked when backend pushes new config
        """
        if self._running:
            logger.warning("Heartbeat already running")
            return
        
        self._get_metrics_fn = get_metrics_fn
        self._on_config_changed = on_config_changed
        self._running = True
        
        # Start heartbeat if already connected
        if self.is_connected:
            self._heartbeat_thread = threading.Thread(
                target=self._heartbeat_loop,
                args=(interval,),
                daemon=True,
                name="ramjet-heartbeat"
            )
            self._heartbeat_thread.start()
            logger.info(f"Started heartbeat (interval: {interval}s)")
        
        # Start reconnect loop if enabled
        if auto_reconnect:
            self._reconnect_thread = threading.Thread(
                target=self._reconnect_loop,
                args=(interval,),
                daemon=True,
                name="ramjet-reconnect"
            )
            self._reconnect_thread.start()
    
    def stop(self) -> None:
        """Stop heartbeat and disconnect from backend."""
        self._running = False
        
        if self._channel:
            try:
                # Unregister node
                if self.is_connected and self._stub and self._pb2:
                    self._stub.UnregisterNode(self._pb2.UnregisterNodeRequest(
                        api_key=self.api_key,
                        node_id=self.node_id,
                    ), timeout=5)
                    logger.info("Unregistered from backend")
            except:
                pass
            
            self._channel.close()
            self._channel = None
        
        self._connected = False
        self.node_id = None
        logger.info("Disconnected from backend")
    
    def _reconnect_loop(self, heartbeat_interval: float) -> None:
        """Background loop attempting to reconnect if disconnected."""
        reconnect_attempts = 0
        
        while self._running:
            # Check if we need to reconnect
            if not self.is_connected and self.api_key:
                reconnect_attempts += 1
                
                # Check max attempts (0 = unlimited)
                if MAX_RECONNECT_ATTEMPTS > 0 and reconnect_attempts > MAX_RECONNECT_ATTEMPTS:
                    logger.error(f"Max reconnect attempts ({MAX_RECONNECT_ATTEMPTS}) reached. Giving up.")
                    break
                
                logger.info(f"Attempting to reconnect to backend (attempt {reconnect_attempts})...")
                
                if self.connect():
                    reconnect_attempts = 0
                    # Start heartbeat thread if not running
                    if not self._heartbeat_thread or not self._heartbeat_thread.is_alive():
                        self._heartbeat_thread = threading.Thread(
                            target=self._heartbeat_loop,
                            args=(heartbeat_interval,),
                            daemon=True,
                            name="ramjet-heartbeat"
                        )
                        self._heartbeat_thread.start()
                        logger.info("Heartbeat thread restarted")
                else:
                    logger.warning(f"Reconnect failed. Will retry in {RECONNECT_INTERVAL}s...")
            
            time.sleep(RECONNECT_INTERVAL)
    
    def _heartbeat_loop(self, interval: float) -> None:
        """Background loop sending heartbeats with metrics."""
        consecutive_failures = 0
        max_failures = 5
        
        while self._running and self.is_connected:
            try:
                metrics = self._get_metrics_fn() if self._get_metrics_fn else {}
                
                response = self._stub.Heartbeat(self._pb2.HeartbeatRequest(
                    api_key=self.api_key,
                    node_id=self.node_id,
                    metrics=self._pb2.NodeMetrics(
                        cache_hit_ratio=metrics.get('hit_ratio', 0.0),
                        cache_size_bytes=int(metrics.get('cache_size_bytes', 0)),
                        cache_items_count=int(metrics.get('cache_items', 0)),
                        total_hits=int(metrics.get('hits', 0)),
                        total_misses=int(metrics.get('misses', 0)),
                        total_sets=int(metrics.get('sets', 0)),
                        throughput_mbps=metrics.get('throughput_mbps', 0.0),
                        avg_latency_ms=metrics.get('avg_latency_ms', 0.0),
                        disk_total_bytes=int(metrics.get('disk_total', 0)),
                        disk_used_bytes=int(metrics.get('disk_used', 0)),
                        disk_free_bytes=int(metrics.get('disk_free', 0)),
                        # Memory metrics
                        ram_total_bytes=int(metrics.get('ram_total', 0)),
                        ram_used_bytes=int(metrics.get('ram_used', 0)),
                        ram_free_bytes=int(metrics.get('ram_free', 0)),
                        # GPU metrics
                        gpu_memory_total_bytes=int(metrics.get('gpu_memory_total', 0)),
                        gpu_memory_used_bytes=int(metrics.get('gpu_memory_used', 0)),
                        gpu_memory_free_bytes=int(metrics.get('gpu_memory_free', 0)),
                        gpu_name=metrics.get('gpu_name', ''),
                        gpu_count=int(metrics.get('gpu_count', 0)),
                        # Training status
                        is_training=bool(metrics.get('is_training', False)),
                        training_phase=metrics.get('training_phase', 'idle'),
                        current_epoch=int(metrics.get('current_epoch', 0)),
                        total_epochs=int(metrics.get('total_epochs', 0)),
                        current_step=int(metrics.get('current_step', 0)),
                        total_steps=int(metrics.get('total_steps', 0)),
                        epoch_progress=float(metrics.get('epoch_progress', 0.0)),
                        training_loss=float(metrics.get('training_loss', 0.0)),
                        training_task=metrics.get('training_task', ''),
                        training_started_at=int(metrics.get('training_started_at', 0)),
                        samples_per_second=float(metrics.get('samples_per_second', 0.0)),
                    ),
                ), timeout=5)
                
                # Reset failure counter on success
                consecutive_failures = 0
                
                # Check if config changed
                if response.config_changed and response.config:
                    self.cluster_config = self._parse_config(response.config)
                    logger.info("Received updated cluster config from backend")
                    # Notify callback so running server can hot-reload settings
                    if self._on_config_changed:
                        try:
                            self._on_config_changed(self.cluster_config)
                        except Exception as cb_err:
                            logger.warning(f"Config change callback error: {cb_err}")
                    
            except grpc.RpcError as e:
                consecutive_failures += 1
                if consecutive_failures <= 3:
                    logger.warning(f"Heartbeat failed: {e.details()}")
                elif consecutive_failures == max_failures:
                    logger.error(
                        f"Heartbeat failed {max_failures} times. "
                        "Marking as disconnected for reconnect."
                    )
                    self._connected = False
                    break  # Exit loop, reconnect thread will handle reconnection
                    
            except Exception as e:
                consecutive_failures += 1
                logger.warning(f"Heartbeat error: {e}")
            
            time.sleep(interval)
        
        logger.debug("Heartbeat loop ended")
    
    def _get_version(self) -> str:
        """Get ramjet package version."""
        try:
            from ramjetio import __version__
            return __version__
        except:
            return "unknown"
    
    def _parse_config(self, proto_config) -> Dict[str, Any]:
        """Parse protobuf config to dict."""
        if not proto_config:
            return {}
        
        config = {
            'replication_factor': proto_config.replication_factor,
            'max_cache_size_bytes': proto_config.max_cache_size_bytes,
            'ttl_seconds': proto_config.ttl_seconds,
            'auto_eviction': proto_config.auto_eviction,
        }
        
        # Parse data source if present
        if proto_config.data_source:
            ds = proto_config.data_source
            config['data_source'] = {
                'type': ds.type,
                's3_endpoint': ds.s3_endpoint,
                's3_access_key': ds.s3_access_key,
                's3_secret_key': ds.s3_secret_key,  # BUG FIX: was missing!
                's3_bucket': ds.s3_bucket,
                's3_region': ds.s3_region,
                's3_use_ssl': ds.s3_use_ssl,
                's3_path_style': ds.s3_path_style,
                'local_path': ds.local_path,
                'http_url': ds.http_url,
                'http_auth_header': ds.http_auth_header,  # Also was missing
                'prefix': ds.prefix,
            }
            logger.info(f"[BackendClient] Parsed data_source: has_secret={bool(ds.s3_secret_key)}, len={len(ds.s3_secret_key)}")
        
        return config
    
    def get_data_source(self) -> Optional[Dict[str, Any]]:
        """
        Get data source configuration from cluster config.
        
        Returns:
            Data source dict with type and connection parameters, or None
        """
        if not self.cluster_config:
            return None
        return self.cluster_config.get('data_source')
    
    def get_cluster_config(self) -> Optional[Dict[str, Any]]:
        """
        Get full cluster configuration.
        
        Returns:
            Cluster config dict, or None if not connected
        """
        return self.cluster_config
    
    def get_cluster_nodes(self, online_only: bool = True) -> list:
        """
        Get list of nodes in the cluster.
        
        Args:
            online_only: If True, return only online nodes (default: True)
            
        Returns:
            List of node dicts with hostname, port, status
        """
        if not self.api_key:
            logger.warning("[BackendClient] No API key, cannot get cluster nodes")
            return []
        
        try:
            if self._stub is None or self._pb2 is None:
                # Need to connect first
                if not self.connect():
                    return []
            
            request = self._pb2.GetClusterNodesRequest(
                api_key=self.api_key,
                online_only=online_only
            )
            response = self._stub.GetClusterNodes(request, timeout=10)
            
            nodes = []
            for node in response.nodes:
                nodes.append({
                    'id': node.id,
                    'hostname': node.hostname,
                    'port': node.port,
                    'status': 'online' if node.status == 2 else 'offline',
                })
            
            logger.info(f"[BackendClient] Got {len(nodes)} nodes from backend")
            return nodes
            
        except grpc.RpcError as e:
            logger.error(f"[BackendClient] Failed to get cluster nodes: {e.code()} - {e.details()}")
            return []
        except Exception as e:
            logger.error(f"[BackendClient] Error getting cluster nodes: {e}")
            return []


# Data source type constants (match proto enum)
DATA_SOURCE_TYPE_NONE = 0
DATA_SOURCE_TYPE_S3 = 1
DATA_SOURCE_TYPE_LOCAL = 2
DATA_SOURCE_TYPE_HTTP = 3


def get_data_source_config(api_key: Optional[str] = None, node_port: int = 9000) -> Optional[Dict[str, Any]]:
    """
    Convenience function to get data source configuration from backend.
    
    This connects to the backend, gets config, and disconnects.
    Useful for training scripts that just need the data source config.
    
    Args:
        api_key: API key (if not provided, reads from RAMJET_API_KEY env var)
        node_port: Port to use for registration (default: 9000)
        
    Returns:
        Data source config dict, or None if not available
        
    Example:
        >>> from ramjetio.backend_client import get_data_source_config
        >>> ds = get_data_source_config()
        >>> if ds and ds['type'] == DATA_SOURCE_TYPE_HTTP:
        ...     print(f"HTTP URL: {ds['http_url']}")
    """
    client = BackendClient(node_port=node_port, api_key=api_key)
    
    try:
        if not client.connect():
            return None
        
        data_source = client.get_data_source()
        return data_source
    finally:
        # Always clean up — close channel without unregistering node
        try:
            if client._channel:
                client._channel.close()
        except Exception:
            pass


# Singleton instance for convenience
_default_client: Optional[BackendClient] = None


def get_backend_client() -> Optional[BackendClient]:
    """Get the default backend client instance."""
    return _default_client


def init_backend(node_port: int = 9000) -> BackendClient:
    """
    Initialize and connect to backend.
    
    This is a convenience function that creates a singleton client.
    
    Args:
        node_port: Port this cache server is running on
        
    Returns:
        BackendClient instance (may not be connected if API key not set)
    """
    global _default_client
    
    if _default_client is None:
        _default_client = BackendClient(node_port=node_port)
        _default_client.connect()
    
    return _default_client


def get_cluster_nodes(api_key: Optional[str] = None, online_only: bool = True) -> list:
    """
    Convenience function to get list of cluster nodes from backend.
    
    This connects to the backend, gets nodes, and disconnects.
    Useful for training scripts to get cache server addresses.
    
    Args:
        api_key: API key (if not provided, reads from RAMJET_API_KEY env var)
        online_only: If True, return only online nodes (default: True)
        
    Returns:
        List of node dicts with hostname, port, status
        
    Example:
        >>> from ramjetio import get_cluster_nodes
        >>> nodes = get_cluster_nodes()
        >>> cache_servers = [(n['hostname'], n['port']) for n in nodes]
    """
    client = BackendClient(api_key=api_key)
    
    nodes = client.get_cluster_nodes(online_only=online_only)
    
    # Close channel
    if client._channel:
        client._channel.close()
    
    return nodes
