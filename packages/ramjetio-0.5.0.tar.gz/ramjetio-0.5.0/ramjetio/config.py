"""
RAMJET Configuration Constants

This module contains hardcoded configuration for connecting to RAMJET backend.
Users only need to provide their API key - the backend URL is fixed.
"""

import os

# ============================================================================
# BACKEND CONFIGURATION
# ============================================================================

# Production backend URL - this is where ramjet-server sends metrics and heartbeats
# Format: host:port (gRPC, not HTTP)
RAMJET_BACKEND_HOST = os.environ.get("RAMJET_BACKEND_HOST", "api.ramjet.io")
RAMJET_BACKEND_PORT = int(os.environ.get("RAMJET_BACKEND_PORT", "443"))
RAMJET_BACKEND_URL = f"{RAMJET_BACKEND_HOST}:{RAMJET_BACKEND_PORT}"

# Use TLS for production (AWS ALB terminates TLS)
RAMJET_BACKEND_USE_SSL = os.environ.get("RAMJET_BACKEND_USE_SSL", "true").lower() == "true"

# ============================================================================
# USER CONFIGURATION (from environment)
# ============================================================================

def get_api_key() -> str | None:
    """
    Get RAMJET API key from environment variable.
    
    Users should set this via:
        export RAMJET_API_KEY="ramjet_xxxxx..."
    
    Returns:
        API key string or None if not configured
    """
    return os.environ.get("RAMJET_API_KEY")


def is_configured() -> bool:
    """Check if RAMJET is properly configured with an API key."""
    api_key = get_api_key()
    # Accept any non-empty API key (prefixes: ramjet_, odin_, cluster_, etc.)
    return api_key is not None and len(api_key) > 10


# ============================================================================
# CACHE SERVER DEFAULTS
# ============================================================================

DEFAULT_CACHE_PORT = 9000
DEFAULT_CACHE_CAPACITY = "100GB"
DEFAULT_STORAGE_PATH = "/tmp/ramjet_cache"

# Heartbeat interval (seconds) - more frequent for better real-time updates
HEARTBEAT_INTERVAL = 3.0

# Metrics push interval (seconds)  
METRICS_PUSH_INTERVAL = 3.0

# Reconnect settings
RECONNECT_INTERVAL = 30.0  # Seconds between reconnect attempts
MAX_RECONNECT_ATTEMPTS = 0  # 0 = unlimited retries
