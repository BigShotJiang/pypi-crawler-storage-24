"""
PyTorch integration utilities.

This module provides PyTorch-specific utilities for integrating the distributed
cache into training workflows.
"""

import logging
import multiprocessing
from typing import Any, Callable, Optional

import torch
from torch.utils.data import Dataset

from ramjetio.cache import DistributedCache

logger = logging.getLogger(__name__)


class CachedDataset(Dataset):
    """
    PyTorch Dataset wrapper with distributed caching.
    
    Wraps an existing dataset and caches items in the distributed cache
    for faster repeated access. Particularly useful for expensive data
    preprocessing operations.
    
    Args:
        dataset: Original PyTorch dataset to wrap
        cache: DistributedCache instance
        key_fn: Function to generate cache keys from indices (default: f"{dataset_name}:{idx}")
        cache_on_miss: Whether to cache items on cache miss (default: True)
        ttl: Time-to-live for cached items in seconds (optional)
        dataset_name: Namespace prefix to avoid key collisions when multiple
            datasets share the same cache (default: auto-generated from class name)
    
    Example:
        >>> from torch.utils.data import DataLoader
        >>> cache = DistributedCache(["node1:9000", "node2:9000"])
        >>> dataset = CachedDataset(original_dataset, cache, dataset_name="cifar10")
        >>> loader = DataLoader(dataset, batch_size=32)
    """
    
    def __init__(
        self,
        dataset: Dataset,
        cache: DistributedCache,
        key_fn: Optional[Callable[[int], str]] = None,
        cache_on_miss: bool = True,
        ttl: Optional[int] = None,
        dataset_name: Optional[str] = None,
    ):
        """Initialize the cached dataset."""
        self.dataset = dataset
        self.cache = cache
        # Auto-generate namespace from dataset class name if not provided
        self.dataset_name = dataset_name or dataset.__class__.__name__
        self.key_fn = key_fn or (lambda idx: f"{self.dataset_name}:{idx}")
        self.cache_on_miss = cache_on_miss
        self.ttl = ttl
        
        # Shared statistics — use multiprocessing.Value so counters
        # are visible from forked DataLoader workers back to the main process.
        self._cache_hits = multiprocessing.Value('i', 0)
        self._cache_misses = multiprocessing.Value('i', 0)
    
    @property
    def cache_hits(self) -> int:
        """Get cache hit count."""
        return self._cache_hits.value
    
    @property
    def cache_misses(self) -> int:
        """Get cache miss count."""
        return self._cache_misses.value
    
    def __len__(self) -> int:
        """Return the length of the underlying dataset."""
        return len(self.dataset)
    
    def __getitem__(self, idx: int) -> Any:
        """
        Get an item from the cache or underlying dataset.
        
        Args:
            idx: Dataset index
            
        Returns:
            Dataset item
        """
        # Generate cache key
        key = self.key_fn(idx)
        
        # Try to get from cache
        cached_item = self.cache.get(key)
        
        if cached_item is not None:
            with self._cache_hits.get_lock():
                self._cache_hits.value += 1
            return cached_item
        
        # Cache miss - get from original dataset
        with self._cache_misses.get_lock():
            self._cache_misses.value += 1
        item = self.dataset[idx]
        
        # Cache the item if enabled
        if self.cache_on_miss:
            try:
                self.cache.set(key, item, ttl=self.ttl)
            except Exception as e:
                logger.warning(f"Failed to cache item {idx}: {e}")
        
        return item
    
    def get_cache_stats(self) -> dict:
        """
        Get cache hit/miss statistics.
        
        Returns:
            Dictionary with cache statistics
        """
        total = self._cache_hits.value + self._cache_misses.value
        hit_rate = (self._cache_hits.value / total * 100) if total > 0 else 0
        
        return {
            "cache_hits": self._cache_hits.value,
            "cache_misses": self._cache_misses.value,
            "total_accesses": total,
            "hit_rate": hit_rate,
        }
    
    def reset_stats(self) -> None:
        """Reset cache statistics."""
        with self._cache_hits.get_lock():
            self._cache_hits.value = 0
        with self._cache_misses.get_lock():
            self._cache_misses.value = 0


class CacheCheckpoint:
    """
    Helper for caching PyTorch model checkpoints.
    
    Provides utilities for storing and retrieving model checkpoints
    in the distributed cache.
    
    Args:
        cache: DistributedCache instance
        prefix: Prefix for checkpoint keys (default: "checkpoint")
    
    Example:
        >>> cache = DistributedCache(["node1:9000", "node2:9000"])
        >>> checkpoint_mgr = CacheCheckpoint(cache)
        >>> checkpoint_mgr.save(model.state_dict(), "epoch_10")
        >>> state_dict = checkpoint_mgr.load("epoch_10")
    """
    
    def __init__(self, cache: DistributedCache, prefix: str = "checkpoint"):
        """Initialize checkpoint manager."""
        self.cache = cache
        self.prefix = prefix
    
    def _make_key(self, name: str) -> str:
        """Generate cache key for checkpoint."""
        return f"{self.prefix}:{name}"
    
    def save(
        self,
        state_dict: dict,
        name: str,
        ttl: Optional[int] = None,
    ) -> bool:
        """
        Save a model checkpoint to cache.
        
        Args:
            state_dict: Model state dictionary
            name: Checkpoint name
            ttl: Time-to-live in seconds (optional)
            
        Returns:
            True if successful, False otherwise
        """
        key = self._make_key(name)
        
        try:
            return self.cache.set(key, state_dict, ttl=ttl)
        except Exception as e:
            logger.error(f"Failed to save checkpoint '{name}': {e}")
            return False
    
    def load(self, name: str) -> Optional[dict]:
        """
        Load a model checkpoint from cache.
        
        Args:
            name: Checkpoint name
            
        Returns:
            State dictionary, or None if not found
        """
        key = self._make_key(name)
        
        try:
            return self.cache.get(key)
        except Exception as e:
            logger.error(f"Failed to load checkpoint '{name}': {e}")
            return None
    
    def delete(self, name: str) -> bool:
        """
        Delete a checkpoint from cache.
        
        Args:
            name: Checkpoint name
            
        Returns:
            True if successful, False otherwise
        """
        key = self._make_key(name)
        
        try:
            return self.cache.delete(key)
        except Exception as e:
            logger.error(f"Failed to delete checkpoint '{name}': {e}")
            return False
    
    def exists(self, name: str) -> bool:
        """
        Check if a checkpoint exists in cache.
        
        Args:
            name: Checkpoint name
            
        Returns:
            True if exists, False otherwise
        """
        key = self._make_key(name)
        return self.cache.exists(key)


def cache_forward_hook(cache: DistributedCache, key_prefix: str = "activation"):
    """
    Create a PyTorch forward hook for caching intermediate activations.
    
    Args:
        cache: DistributedCache instance
        key_prefix: Prefix for activation cache keys
        
    Returns:
        Hook function that can be registered with model.register_forward_hook()
    
    Example:
        >>> cache = DistributedCache(["node1:9000"])
        >>> hook = cache_forward_hook(cache, "layer1_activation")
        >>> model.layer1.register_forward_hook(hook)
    """
    def hook(module, input, output):
        # Generate key based on module name and input
        key = f"{key_prefix}:{id(module)}"
        
        # Cache the output activation
        if isinstance(output, torch.Tensor):
            try:
                cache.set(key, output.detach().cpu())
            except Exception as e:
                logger.warning(f"Failed to cache activation: {e}")
        
        return output
    
    return hook
