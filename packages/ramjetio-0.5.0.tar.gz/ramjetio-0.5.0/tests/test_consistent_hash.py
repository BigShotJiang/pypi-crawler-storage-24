"""
Tests for consistent hashing implementation.
"""

import pytest
from ramjetio.consistent_hash import ConsistentHash


class TestConsistentHash:
    """Test cases for ConsistentHash class."""
    
    def test_initialization(self):
        """Test hash ring initialization."""
        nodes = ["node1:9000", "node2:9000", "node3:9000"]
        ch = ConsistentHash(nodes=nodes, virtual_nodes=100)
        
        assert len(ch) == 3
        assert set(ch.get_all_nodes()) == set(nodes)
    
    def test_add_node(self):
        """Test adding a node to the ring."""
        ch = ConsistentHash()
        assert len(ch) == 0
        
        ch.add_node("node1:9000")
        assert len(ch) == 1
        assert "node1:9000" in ch.get_all_nodes()
    
    def test_remove_node(self):
        """Test removing a node from the ring."""
        ch = ConsistentHash(nodes=["node1:9000", "node2:9000"])
        assert len(ch) == 2
        
        ch.remove_node("node1:9000")
        assert len(ch) == 1
        assert "node1:9000" not in ch.get_all_nodes()
    
    def test_get_node(self):
        """Test getting a node for a key."""
        ch = ConsistentHash(nodes=["node1:9000", "node2:9000", "node3:9000"])
        
        node = ch.get_node("test_key")
        assert node in ch.get_all_nodes()
        
        # Same key should always map to same node
        for _ in range(10):
            assert ch.get_node("test_key") == node
    
    def test_get_nodes_multiple(self):
        """Test getting multiple nodes for replication."""
        ch = ConsistentHash(nodes=["node1:9000", "node2:9000", "node3:9000"])
        
        nodes = ch.get_nodes("test_key", count=2)
        assert len(nodes) == 2
        assert len(set(nodes)) == 2  # No duplicates
    
    def test_distribution(self):
        """Test key distribution across nodes."""
        ch = ConsistentHash(nodes=["node1:9000", "node2:9000", "node3:9000"])
        
        distribution = ch.get_distribution(num_keys=1000)
        
        # Each node should get roughly 1/3 of keys (with some variance)
        for node, count in distribution.items():
            assert 200 < count < 500  # Roughly 333 ± ~150
    
    def test_minimal_redistribution(self):
        """Test that adding a node causes minimal key redistribution."""
        ch = ConsistentHash(nodes=["node1:9000", "node2:9000"])
        
        # Get initial key mappings
        initial_mappings = {}
        for i in range(1000):
            key = f"key_{i}"
            initial_mappings[key] = ch.get_node(key)
        
        # Add a new node
        ch.add_node("node3:9000")
        
        # Check how many keys were remapped
        remapped = 0
        for key, old_node in initial_mappings.items():
            new_node = ch.get_node(key)
            if new_node != old_node:
                remapped += 1
        
        # Should remap roughly 1/3 of keys (added 1 node to 2 existing)
        assert 200 < remapped < 500
