"""
Shared test fixtures for ramjetio tests.
"""

import pytest
from unittest.mock import Mock, MagicMock


@pytest.fixture
def mock_cache_nodes():
    """Standard test nodes for cache tests."""
    return ["node1:9000", "node2:9000", "node3:9000"]


@pytest.fixture
def mock_response_ok():
    """Mock HTTP 200 response."""
    resp = Mock()
    resp.status_code = 200
    resp.content = b""
    return resp


@pytest.fixture
def mock_response_404():
    """Mock HTTP 404 response."""
    resp = Mock()
    resp.status_code = 404
    return resp
