"""
Tests for distributed cache client.
"""

import pytest
import torch
from unittest.mock import Mock, patch, MagicMock

from ramjetio.cache import DistributedCache


class TestDistributedCache:
    """Test cases for DistributedCache class."""
    
    def test_initialization(self):
        """Test cache initialization."""
        nodes = ["node1:9000", "node2:9000"]
        cache = DistributedCache(nodes=nodes)
        
        assert len(cache.nodes) == 2
        assert cache.timeout == 30
        assert cache.retry_attempts == 3
    
    def test_initialization_no_nodes(self):
        """Test that initialization fails with no nodes."""
        with pytest.raises(ValueError):
            DistributedCache(nodes=[])
    
    def test_set_success(self):
        """Test setting a value in cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        
        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.post.return_value = mock_response
        
        success = cache.set("test_key", "test_value")
        
        assert success
        assert cache._session.post.called
    
    def test_get_success(self):
        """Test getting a value from cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.content = b"test_value"
        
        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.get.return_value = mock_response
        
        # Mock the deserialization
        with patch('ramjetio.cache.deserialize_tensor', side_effect=Exception()), \
             patch('pickle.loads', return_value="test_value"):
            value = cache.get("test_key")
        
        assert value == "test_value"
        assert cache._session.get.called
    
    def test_get_not_found(self):
        """Test getting a non-existent key."""
        mock_response = Mock()
        mock_response.status_code = 404
        
        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.get.return_value = mock_response
        
        value = cache.get("nonexistent_key")
        
        assert value is None
    
    def test_delete_success(self):
        """Test deleting a value from cache."""
        mock_response = Mock()
        mock_response.status_code = 200
        
        cache = DistributedCache(nodes=["node1:9000"])
        import os
        cache._session = Mock()
        cache._session_pid = os.getpid()
        cache._session.delete.return_value = mock_response
        
        success = cache.delete("test_key")
        
        assert success
        assert cache._session.delete.called
    
    def test_add_node(self):
        """Test adding a node to the cache cluster."""
        cache = DistributedCache(nodes=["node1:9000"])
        cache.add_node("node2:9000")
        
        assert len(cache.nodes) == 2
        assert "node2:9000" in cache.nodes
    
    def test_remove_node(self):
        """Test removing a node from the cache cluster."""
        cache = DistributedCache(nodes=["node1:9000", "node2:9000"])
        cache.remove_node("node1:9000")
        
        assert len(cache.nodes) == 1
        assert "node1:9000" not in cache.nodes
