from ch_analytics_mcp.server import main

main()
