"""Database helpers for ch-analytics-mcp.

Provides connection management, query execution, identifier sanitisation,
and environment resolution. All tools in server.py depend on this module.
"""

import os
import re
from contextlib import contextmanager
from typing import Generator
from urllib.parse import urlparse

import clickhouse_connect

# ── Config ────────────────────────────────────────────────────────────────────

ENVS: dict[str, str] = {}
for _env, _var in [
    ("local", "CH_LOCAL_URL"),
    ("dev", "CH_DEV_URL"),
    ("stg", "CH_STG_URL"),
    ("prod", "CH_PROD_URL"),
]:
    _url = os.environ.get(_var, "")
    if _url:
        ENVS[_env] = _url

if not ENVS:
    raise RuntimeError(
        "No ClickHouse URLs configured. Set CH_LOCAL_URL, CH_DEV_URL, CH_STG_URL, or CH_PROD_URL."
    )

AVAILABLE_ENVS = list(ENVS.keys())
DEFAULT_ENV = AVAILABLE_ENVS[0]

INTERNAL_DATABASES = {
    "system",
    "information_schema",
    "INFORMATION_SCHEMA",
    "_temporary_and_external_tables",
}

# ── Database filtering ─────────────────────────────────────────────────────
# CH_INCLUDE_DATABASES=core,trading  → only scan these databases (allowlist)
# CH_IGNORE_DATABASES=tmp,scratch    → skip these databases in addition to internal ones
# If both set, CH_INCLUDE_DATABASES takes precedence.

_include_raw = os.environ.get("CH_INCLUDE_DATABASES", "").strip()
_ignore_raw = os.environ.get("CH_IGNORE_DATABASES", "").strip()

INCLUDE_DATABASES: set[str] | None = (
    {s.strip() for s in _include_raw.split(",") if s.strip()} if _include_raw else None
)
EXCLUDED_DATABASES: set[str] = INTERNAL_DATABASES | (
    {s.strip() for s in _ignore_raw.split(",") if s.strip()} if _ignore_raw else set()
)


# ── Fail table tracking (opt-in) ──────────────────────────────────────────
# CH_FAIL_DATABASE=pipeline → enables pipeline_fail_* tools for that database
# Tables must match *_fails and have columns: run_id, stage, comment, failed_at

FAIL_DATABASE: str | None = os.environ.get("CH_FAIL_DATABASE", "").strip() or None


def database_filter(col: str = "database") -> str:
    """Return a SQL fragment for WHERE clause filtering databases.

    Values are validated via safe_ident and inlined — no params needed
    because clickhouse-connect uses different parameter styles.
    """
    safe_ident(col.split(".")[-1])  # validate identifier
    if INCLUDE_DATABASES:
        values = ", ".join(f"'{_escape_string(d)}'" for d in sorted(INCLUDE_DATABASES))
        return f"{col} IN ({values})"
    values = ", ".join(f"'{_escape_string(d)}'" for d in sorted(EXCLUDED_DATABASES))
    return f"{col} NOT IN ({values})"


def _escape_string(s: str) -> str:
    """Escape single quotes for ClickHouse string literals."""
    return s.replace("\\", "\\\\").replace("'", "\\'")


# ── Identifier safety ────────────────────────────────────────────────────────

_IDENT_RE = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")


def safe_ident(name: str) -> str:
    """Validate and quote a SQL identifier to prevent injection."""
    if not _IDENT_RE.match(name):
        raise ValueError(f"Invalid SQL identifier: {name!r}")
    return f"`{name}`"


# ── Environment resolution ───────────────────────────────────────────────────


def resolve_env(env: str) -> str:
    env = env.lower()
    if env not in ENVS:
        raise ValueError(
            f"Unknown environment '{env}'. Available: {', '.join(AVAILABLE_ENVS)}"
        )
    return env


# ── URL parsing ──────────────────────────────────────────────────────────────


def _parse_ch_url(url: str) -> dict:
    """Parse a ClickHouse URL into connection parameters.

    Supports: clickhouse://user:pass@host:port/database
              https://user:pass@host:port/database
              http://user:pass@host:port/database
    """
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()

    if scheme in ("https",):
        interface = "https"
        default_port = 8443
    else:
        interface = "http"
        default_port = 8123

    return {
        "host": parsed.hostname or "localhost",
        "port": parsed.port or default_port,
        "username": parsed.username or "default",
        "password": parsed.password or "",
        "database": (parsed.path.lstrip("/") or "default"),
        "interface": interface,
    }


# ── Connection & query ───────────────────────────────────────────────────────


@contextmanager
def get_client(
    env: str, timeout_s: int = 0
) -> Generator[clickhouse_connect.driver.Client, None, None]:
    """Open a ClickHouse client connection. Optional query timeout in seconds."""
    params = _parse_ch_url(ENVS[env])
    settings = {}
    if timeout_s > 0:
        settings["max_execution_time"] = timeout_s

    client = clickhouse_connect.get_client(
        host=params["host"],
        port=params["port"],
        username=params["username"],
        password=params["password"],
        database=params["database"],
        interface=params["interface"],
        settings=settings,
    )
    try:
        yield client
    finally:
        client.close()


def query(env: str, sql: str, params: dict | None = None, timeout_s: int = 0) -> list[dict]:
    """Execute a read-only query and return rows as dicts."""
    with get_client(env, timeout_s=timeout_s) as client:
        result = client.query(sql, parameters=params)
        columns = result.column_names
        return [dict(zip(columns, row)) for row in result.result_rows]
