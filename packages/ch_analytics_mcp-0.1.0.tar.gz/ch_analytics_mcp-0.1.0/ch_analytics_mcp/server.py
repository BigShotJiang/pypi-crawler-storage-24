"""ch-analytics-mcp — ClickHouse analytics MCP server.

A general-purpose "DBA-lite" MCP server that provides semantic tools for
schema discovery, data exploration, storage & engine analysis, performance
analysis, and data quality checks on any ClickHouse database.

Environment variables:
    CH_LOCAL_URL         — ClickHouse URL for LOCAL (optional)
    CH_DEV_URL           — ClickHouse URL for DEV   (at least one URL required)
    CH_STG_URL           — ClickHouse URL for STG   (optional)
    CH_PROD_URL          — ClickHouse URL for PROD  (optional)
    CH_INCLUDE_DATABASES — comma-separated allowlist of databases to scan (optional)
    CH_IGNORE_DATABASES  — comma-separated databases to skip (optional)
    CH_FAIL_DATABASE     — enables pipeline_fail_* tools for a given database (optional)
    CH_READ_ONLY         — reserved for future write tools (not yet used)
"""

import re

from fastmcp import FastMCP

from ch_analytics_mcp.db import (
    AVAILABLE_ENVS,
    DEFAULT_ENV,
    EXCLUDED_DATABASES,
    FAIL_DATABASE,
    INCLUDE_DATABASES,
    INTERNAL_DATABASES,
    database_filter,
    query,
    resolve_env,
    safe_ident,
)

# ── MCP server ───────────────────────────────────────────────────────────────

mcp = FastMCP(
    "ch-analytics",
    instructions=(
        f"ClickHouse analytics tools. Available environments: {', '.join(AVAILABLE_ENVS)}. "
        f"Default environment: {DEFAULT_ENV}. "
        "Use database_summary for an overview, describe_table for column details, "
        "find_tables/find_columns to search, table_engines for engine info, "
        "recent_rows to peek at data, and column_stats/null_report for data quality.\n\n"
        "When working with tool results, write down any important information you might need later "
        "in your response, as the original tool result may be cleared later.\n\n"
        "IMPORTANT: Always present results and analysis in English, regardless of the user's language."
    ),
)

# ── Limits ───────────────────────────────────────────────────────────────────

MAX_ROW_LIMIT = 100
MAX_AGG_LIMIT = 200
QUERY_TIMEOUT_S = 30


def _clamp_row(limit: int) -> int:
    return max(1, min(limit, MAX_ROW_LIMIT))


def _clamp_agg(limit: int) -> int:
    return max(1, min(limit, MAX_AGG_LIMIT))


# ═════════════════════════════════════════════════════════════════════════════
# Schema Discovery
# ═════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def database_summary(env: str = DEFAULT_ENV) -> dict:
    """Get a high-level overview of the ClickHouse instance: database count,
    table count, view count, engine distribution, total compressed/uncompressed
    size, and compression ratio.

    Respects CH_INCLUDE_DATABASES / CH_IGNORE_DATABASES filtering.
    """
    env = resolve_env(env)
    db_filt = database_filter("database")

    summary = {}

    r = query(
        env,
        f"SELECT count(DISTINCT database) AS v FROM system.tables WHERE {db_filt}",
    )
    summary["database_count"] = r[0]["v"]

    r = query(
        env,
        f"SELECT count() AS v FROM system.tables WHERE engine NOT IN ('View', 'MaterializedView') AND {db_filt}",
    )
    summary["table_count"] = r[0]["v"]

    r = query(
        env,
        f"SELECT count() AS v FROM system.tables WHERE engine IN ('View', 'MaterializedView') AND {db_filt}",
    )
    summary["view_count"] = r[0]["v"]

    r = query(
        env,
        f"""
        SELECT
            formatReadableSize(sum(total_bytes)) AS total_compressed_size,
            formatReadableSize(sum(total_rows * (data_uncompressed_bytes / nullIf(total_rows, 0)))) AS estimated_uncompressed_size,
            round(sum(data_uncompressed_bytes) / nullIf(sum(data_compressed_bytes), 0), 2) AS compression_ratio
        FROM system.tables
        WHERE {db_filt}
        """,
    )
    summary["total_compressed_size"] = r[0]["total_compressed_size"]
    summary["estimated_uncompressed_size"] = r[0]["estimated_uncompressed_size"]
    summary["compression_ratio"] = r[0]["compression_ratio"]

    engines = query(
        env,
        f"""
        SELECT engine, count() AS cnt
        FROM system.tables
        WHERE {db_filt}
        GROUP BY engine
        ORDER BY cnt DESC
        """,
    )
    summary["engine_distribution"] = {e["engine"]: e["cnt"] for e in engines}
    summary["env"] = env

    if INCLUDE_DATABASES:
        summary["database_filter"] = f"include: {', '.join(sorted(INCLUDE_DATABASES))}"
    elif EXCLUDED_DATABASES - INTERNAL_DATABASES:
        summary["database_filter"] = (
            f"ignore: {', '.join(sorted(EXCLUDED_DATABASES - INTERNAL_DATABASES))}"
        )

    return summary


@mcp.tool()
def scan_databases(env: str = DEFAULT_ENV) -> list[dict]:
    """Scan all user databases and return row counts for every table.

    Uses ClickHouse metadata (instant, no COUNT(*) per table).
    Returns a list of {database, table, engine, row_count} sorted by database and table.
    Respects CH_INCLUDE_DATABASES / CH_IGNORE_DATABASES filtering.
    """
    env = resolve_env(env)
    db_filt = database_filter("database")

    rows = query(
        env,
        f"""
        SELECT
            database,
            name AS table,
            engine,
            total_rows AS row_count
        FROM system.tables
        WHERE engine NOT IN ('View', 'MaterializedView')
          AND {db_filt}
        ORDER BY database, name
        """,
    )

    return [
        {
            "env": env,
            "database": r["database"],
            "table": r["table"],
            "engine": r["engine"],
            "row_count": r["row_count"],
            "status": "populated" if r["row_count"] and r["row_count"] > 0 else "empty",
        }
        for r in rows
    ]


@mcp.tool()
def describe_table(
    table: str, database: str = "default", env: str = DEFAULT_ENV
) -> list[dict]:
    """Describe a table's columns: name, data type, default expression,
    compression codec, comment, and whether nullable.
    """
    env = resolve_env(env)
    safe_ident(database)
    safe_ident(table)

    return query(
        env,
        f"""
        SELECT
            name AS column_name,
            type AS data_type,
            position AS ordinal_position,
            default_kind,
            default_expression,
            compression_codec,
            comment,
            CASE WHEN type LIKE 'Nullable(%' THEN 'YES' ELSE 'NO' END AS is_nullable
        FROM system.columns
        WHERE database = '{database}' AND table = '{table}'
        ORDER BY position
        """,
    )


@mcp.tool()
def table_sizes(
    database: str | None = None, env: str = DEFAULT_ENV, limit: int = 50
) -> list[dict]:
    """Show table sizes (compressed + uncompressed) ordered by total size descending.

    Includes compression ratio. Optionally filter by database. Returns up to `limit` rows (max 200).
    """
    env = resolve_env(env)
    limit = _clamp_agg(limit)
    db_filt = database_filter("database")

    where_parts = [db_filt]
    if database:
        safe_ident(database)
        where_parts.append(f"database = '{database}'")

    where = " AND ".join(where_parts)

    return query(
        env,
        f"""
        SELECT
            database,
            name AS table,
            engine,
            formatReadableSize(total_bytes) AS total_size,
            total_bytes AS total_size_bytes,
            formatReadableSize(data_compressed_bytes) AS data_compressed_size,
            formatReadableSize(data_uncompressed_bytes) AS data_uncompressed_size,
            round(data_uncompressed_bytes / nullIf(data_compressed_bytes, 0), 2) AS compression_ratio,
            total_rows AS estimated_rows
        FROM system.tables
        WHERE {where}
          AND engine NOT IN ('View', 'MaterializedView')
        ORDER BY total_bytes DESC
        LIMIT {limit}
        """,
    )


@mcp.tool()
def find_tables(pattern: str, env: str = DEFAULT_ENV) -> list[dict]:
    """Find tables whose name matches a LIKE pattern (case-insensitive).

    Example: find_tables('%price%') returns all tables with 'price' in the name.
    """
    env = resolve_env(env)
    db_filt = database_filter("database")
    return query(
        env,
        f"""
        SELECT database, name AS table, engine, total_rows
        FROM system.tables
        WHERE name ILIKE %(pattern)s
          AND {db_filt}
        ORDER BY database, name
        """,
        {"pattern": pattern},
    )


@mcp.tool()
def find_columns(column_pattern: str, env: str = DEFAULT_ENV) -> list[dict]:
    """Find all tables that have a column matching a LIKE pattern (case-insensitive).

    Example: find_columns('%email%') finds every table with an email-like column.
    """
    env = resolve_env(env)
    db_filt = database_filter("database")
    return query(
        env,
        f"""
        SELECT
            database, table, name AS column_name, type AS data_type,
            CASE WHEN type LIKE 'Nullable(%' THEN 'YES' ELSE 'NO' END AS is_nullable
        FROM system.columns
        WHERE name ILIKE %(pattern)s
          AND {db_filt}
        ORDER BY database, table, position
        """,
        {"pattern": column_pattern},
    )


@mcp.tool()
def list_empty_tables(env: str = DEFAULT_ENV) -> list[dict]:
    """Return all tables with 0 rows in the given environment."""
    env = resolve_env(env)
    db_filt = database_filter("database")

    return query(
        env,
        f"""
        SELECT database, name AS table, engine
        FROM system.tables
        WHERE total_rows = 0
          AND engine NOT IN ('View', 'MaterializedView')
          AND {db_filt}
        ORDER BY database, name
        """,
    )


@mcp.tool()
def list_environments() -> list[dict]:
    """List all configured ClickHouse environments."""
    return [{"env": env, "configured": True} for env in AVAILABLE_ENVS]


# ═════════════════════════════════════════════════════════════════════════════
# Data Exploration
# ═════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def recent_rows(
    table: str,
    database: str = "default",
    env: str = DEFAULT_ENV,
    limit: int = 20,
    order_by: str | None = None,
    order_dir: str = "DESC",
) -> list[dict]:
    """Fetch the most recent rows from a table.

    If order_by is not specified, the tool auto-detects a timestamp column
    (inserted_at, created_at, updated_at, timestamp) or falls back to the
    sorting key from the table engine.
    order_dir must be ASC or DESC.
    """
    env = resolve_env(env)
    limit = _clamp_row(limit)

    if order_dir.upper() not in ("ASC", "DESC"):
        raise ValueError("order_dir must be ASC or DESC")
    order_dir = order_dir.upper()

    d, t = safe_ident(database), safe_ident(table)

    if order_by:
        order_col = safe_ident(order_by)
    else:
        # Auto-detect ordering column
        candidates = query(
            env,
            f"""
            SELECT name FROM system.columns
            WHERE database = '{database}' AND table = '{table}'
              AND name IN ('inserted_at', 'created_at', 'updated_at', 'timestamp')
            ORDER BY position
            LIMIT 1
            """,
        )

        if candidates:
            order_col = safe_ident(candidates[0]["name"])
        else:
            # Fall back to sorting key
            sk = query(
                env,
                f"""
                SELECT sorting_key
                FROM system.tables
                WHERE database = '{database}' AND name = '{table}'
                """,
            )
            if sk and sk[0]["sorting_key"]:
                # Use the first column of the sorting key
                first_key = sk[0]["sorting_key"].split(",")[0].strip()
                if first_key:
                    order_col = safe_ident(first_key)
                else:
                    order_col = None
            else:
                order_col = None

    order_clause = f"ORDER BY {order_col} {order_dir}" if order_col else ""
    return query(env, f"SELECT * FROM {d}.{t} {order_clause} LIMIT {limit}")


@mcp.tool()
def column_value_counts(
    table: str,
    column: str,
    database: str = "default",
    env: str = DEFAULT_ENV,
    limit: int = 50,
) -> list[dict]:
    """Show distinct values and their frequency for a column.

    Useful for understanding cardinality and data distribution.
    """
    env = resolve_env(env)
    limit = _clamp_agg(limit)
    d, t, c = safe_ident(database), safe_ident(table), safe_ident(column)

    return query(
        env,
        f"""
        SELECT {c} AS value, count() AS count,
               round(count() * 100.0 / nullIf(sum(count()) OVER (), 0), 2) AS pct
        FROM {d}.{t}
        GROUP BY {c}
        ORDER BY count DESC
        LIMIT {limit}
        """,
        timeout_s=QUERY_TIMEOUT_S,
    )


@mcp.tool()
def column_stats(
    table: str,
    column: str,
    database: str = "default",
    env: str = DEFAULT_ENV,
) -> dict:
    """Get statistics for a column: min, max, avg (numeric), null count, distinct count, total rows."""
    env = resolve_env(env)
    d, t, c = safe_ident(database), safe_ident(table), safe_ident(column)

    rows = query(
        env,
        f"""
        SELECT
            count() AS total_rows,
            count({c}) AS non_null_count,
            count() - count({c}) AS null_count,
            round((count() - count({c})) * 100.0 / nullIf(count(), 0), 2) AS null_pct,
            count(DISTINCT {c}) AS distinct_count,
            toString(min({c})) AS min_value,
            toString(max({c})) AS max_value
        FROM {d}.{t}
        """,
        timeout_s=QUERY_TIMEOUT_S,
    )

    result = rows[0]

    # Try numeric avg
    try:
        avg_rows = query(
            env,
            f"SELECT round(avg(toFloat64OrNull(toString({c}))), 4) AS avg_value FROM {d}.{t}",
            timeout_s=QUERY_TIMEOUT_S,
        )
        result["avg_value"] = (
            str(avg_rows[0]["avg_value"])
            if avg_rows[0]["avg_value"] is not None
            else None
        )
    except Exception:
        result["avg_value"] = None

    return result


# ═════════════════════════════════════════════════════════════════════════════
# Storage & Engines
# ═════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def table_engines(
    database: str | None = None,
    env: str = DEFAULT_ENV,
    engine: str | None = None,
) -> list[dict]:
    """List tables with their engine type, sorting key, partition key, and primary key.

    Optionally filter by database or engine name.
    """
    env = resolve_env(env)
    db_filt = database_filter("database")

    where_parts = [db_filt]
    if database:
        safe_ident(database)
        where_parts.append(f"database = '{database}'")
    if engine:
        # Validate engine name — only allow safe identifiers
        if not re.match(r"^[a-zA-Z][a-zA-Z0-9_]*$", engine):
            raise ValueError(f"Invalid engine name: {engine!r}")
        where_parts.append(f"engine = '{engine}'")

    where = " AND ".join(where_parts)

    return query(
        env,
        f"""
        SELECT
            database,
            name AS table,
            engine,
            sorting_key,
            partition_key,
            primary_key,
            total_rows,
            formatReadableSize(total_bytes) AS total_size
        FROM system.tables
        WHERE {where}
          AND engine NOT IN ('View', 'MaterializedView')
        ORDER BY database, name
        """,
    )


@mcp.tool()
def partition_info(
    table: str,
    database: str = "default",
    env: str = DEFAULT_ENV,
) -> list[dict]:
    """Get partition details for a table: part count, rows, compressed/uncompressed size,
    and date range per partition.
    """
    env = resolve_env(env)
    safe_ident(database)
    safe_ident(table)

    return query(
        env,
        f"""
        SELECT
            partition,
            count() AS part_count,
            sum(rows) AS total_rows,
            formatReadableSize(sum(data_compressed_bytes)) AS compressed_size,
            formatReadableSize(sum(data_uncompressed_bytes)) AS uncompressed_size,
            round(sum(data_uncompressed_bytes) / nullIf(sum(data_compressed_bytes), 0), 2) AS compression_ratio,
            min(min_date) AS min_date,
            max(max_date) AS max_date
        FROM system.parts
        WHERE database = '{database}' AND table = '{table}' AND active = 1
        GROUP BY partition
        ORDER BY partition
        """,
    )


@mcp.tool()
def compare_envs(table: str, database: str = "default") -> list[dict]:
    """Compare row counts for a table across all configured environments.

    Returns [{env, row_count, status}] for each available environment.
    """
    results = []
    for env in AVAILABLE_ENVS:
        try:
            d, t = safe_ident(database), safe_ident(table)
            rows = query(env, f"SELECT count() AS cnt FROM {d}.{t}")
            count = rows[0]["cnt"]
            results.append(
                {"env": env, "database": database, "table": table, "row_count": count}
            )
        except Exception as e:
            results.append(
                {"env": env, "database": database, "table": table, "error": str(e)}
            )
    return results


# ═════════════════════════════════════════════════════════════════════════════
# Performance
# ═════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def data_skipping_indices(
    database: str | None = None,
    env: str = DEFAULT_ENV,
) -> list[dict]:
    """List data skipping indices (minmax, set, bloom_filter, etc.) across tables.

    Optionally filter by database.
    """
    env = resolve_env(env)
    db_filt = database_filter("database")

    where_parts = [db_filt]
    if database:
        safe_ident(database)
        where_parts.append(f"database = '{database}'")

    where = " AND ".join(where_parts)

    return query(
        env,
        f"""
        SELECT
            database,
            table,
            name AS index_name,
            type AS index_type,
            expr AS expression,
            granularity
        FROM system.data_skipping_indices
        WHERE {where}
        ORDER BY database, table, name
        """,
    )


@mcp.tool()
def slow_query_candidates(
    env: str = DEFAULT_ENV,
    min_duration_s: float = 1.0,
    limit: int = 50,
) -> list[dict]:
    """Find recent slow queries from system.query_log.

    Returns queries that took longer than min_duration_s seconds,
    ordered by duration descending.
    """
    env = resolve_env(env)
    limit = _clamp_agg(limit)

    return query(
        env,
        f"""
        SELECT
            query_id,
            user,
            query_duration_ms / 1000.0 AS duration_s,
            read_rows,
            formatReadableSize(read_bytes) AS read_size,
            result_rows,
            formatReadableSize(memory_usage) AS memory_usage,
            event_time,
            substring(query, 1, 200) AS query_preview
        FROM system.query_log
        WHERE type = 'QueryFinish'
          AND query_duration_ms >= {int(min_duration_s * 1000)}
          AND event_time >= now() - INTERVAL 7 DAY
        ORDER BY query_duration_ms DESC
        LIMIT {limit}
        """,
    )


@mcp.tool()
def parts_analysis(
    database: str | None = None,
    env: str = DEFAULT_ENV,
    min_parts: int = 10,
) -> list[dict]:
    """Analyse part counts and compression per table. Tables with many active parts
    may benefit from OPTIMIZE or indicate merge pressure.

    Optionally filter by database. Returns tables with at least min_parts active parts.
    """
    env = resolve_env(env)
    db_filt = database_filter("database")

    where_parts = [db_filt, "active = 1"]
    if database:
        safe_ident(database)
        where_parts.append(f"database = '{database}'")

    where = " AND ".join(where_parts)

    return query(
        env,
        f"""
        SELECT
            database,
            table,
            count() AS active_parts,
            sum(rows) AS total_rows,
            formatReadableSize(sum(data_compressed_bytes)) AS compressed_size,
            formatReadableSize(sum(data_uncompressed_bytes)) AS uncompressed_size,
            round(sum(data_uncompressed_bytes) / nullIf(sum(data_compressed_bytes), 0), 2) AS compression_ratio,
            max(modification_time) AS last_modified
        FROM system.parts
        WHERE {where}
        GROUP BY database, table
        HAVING count() >= {min_parts}
        ORDER BY active_parts DESC
        LIMIT 200
        """,
    )


# ═════════════════════════════════════════════════════════════════════════════
# Data Quality
# ═════════════════════════════════════════════════════════════════════════════


@mcp.tool()
def table_health(table: str, database: str = "default", env: str = DEFAULT_ENV) -> dict:
    """Get health stats for a specific table: row count, last inserted_at, last updated_at.

    Returns {env, database, table, row_count, last_inserted_at, last_updated_at}.
    """
    env = resolve_env(env)

    d, t = safe_ident(database), safe_ident(table)

    rows = query(env, f"SELECT count() AS cnt FROM {d}.{t}")
    row_count = rows[0]["cnt"]

    cols = query(
        env,
        f"""
        SELECT name
        FROM system.columns
        WHERE database = '{database}' AND table = '{table}'
          AND name IN ('inserted_at', 'updated_at', 'source_updated_at')
        """,
    )
    col_names = {r["name"] for r in cols}

    last_inserted_at = None
    last_updated_at = None

    if row_count > 0:
        if "inserted_at" in col_names:
            r = query(env, f"SELECT max(inserted_at) AS v FROM {d}.{t}")
            last_inserted_at = str(r[0]["v"]) if r[0]["v"] else None
        if "updated_at" in col_names:
            r = query(env, f"SELECT max(updated_at) AS v FROM {d}.{t}")
            last_updated_at = str(r[0]["v"]) if r[0]["v"] else None

    return {
        "env": env,
        "database": database,
        "table": table,
        "row_count": row_count,
        "status": "populated" if row_count > 0 else "empty",
        "last_inserted_at": last_inserted_at,
        "last_updated_at": last_updated_at,
    }


@mcp.tool()
def null_report(
    table: str, database: str = "default", env: str = DEFAULT_ENV
) -> list[dict]:
    """For every column in a table, report the null count and null percentage.

    Useful for spotting data quality issues.
    """
    env = resolve_env(env)
    d, t = safe_ident(database), safe_ident(table)

    cols = query(
        env,
        f"""
        SELECT name FROM system.columns
        WHERE database = '{database}' AND table = '{table}'
        ORDER BY position
        """,
    )

    if not cols:
        return [{"error": f"Table {database}.{table} not found or has no columns"}]

    # Build a single query that checks all columns at once
    parts = []
    for col in cols:
        c = safe_ident(col["name"])
        parts.append(
            f"countIf({c} IS NULL) AS {safe_ident('null_' + col['name'])}"
        )

    count_sql = f"SELECT count() AS total, {', '.join(parts)} FROM {d}.{t}"
    row = query(env, count_sql, timeout_s=QUERY_TIMEOUT_S)[0]
    total = row["total"]

    results = []
    for col in cols:
        null_count = row[f"null_{col['name']}"]
        results.append(
            {
                "column": col["name"],
                "null_count": null_count,
                "null_pct": round(null_count * 100.0 / total, 2) if total > 0 else 0,
                "total_rows": total,
            }
        )

    return sorted(results, key=lambda r: r["null_pct"], reverse=True)


@mcp.tool()
def duplicate_check(
    table: str,
    columns: list[str],
    database: str = "default",
    env: str = DEFAULT_ENV,
    limit: int = 20,
) -> list[dict]:
    """Check for duplicate rows based on a set of columns.

    Returns groups of values that appear more than once, with their count.
    """
    env = resolve_env(env)
    limit = _clamp_row(limit)

    safe_cols = [safe_ident(c) for c in columns]
    col_list = ", ".join(safe_cols)
    d, t = safe_ident(database), safe_ident(table)

    return query(
        env,
        f"""
        SELECT {col_list}, count() AS duplicate_count
        FROM {d}.{t}
        GROUP BY {col_list}
        HAVING count() > 1
        ORDER BY duplicate_count DESC
        LIMIT {limit}
        """,
        timeout_s=QUERY_TIMEOUT_S,
    )


# ═════════════════════════════════════════════════════════════════════════════
# Fail Table Tracking (opt-in via CH_FAIL_DATABASE)
# ═════════════════════════════════════════════════════════════════════════════

_UUID_RE = re.compile(r"^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}$", re.I)


def _validate_uuid(value: str) -> str:
    """Validate UUID format, raise ValueError if invalid."""
    if not _UUID_RE.match(value):
        raise ValueError(f"Invalid UUID format: {value}")
    return value


def _clamp_days(days: int) -> int:
    """Clamp days to 1-90 range."""
    return max(1, min(days, 90))


if FAIL_DATABASE:
    _FAIL_DB_SAFE = safe_ident(FAIL_DATABASE)

    def _discover_fail_tables(env: str) -> list[dict]:
        """Discover *_fails tables with required metadata columns."""
        rows = query(
            env,
            f"""
            SELECT t.name AS table_name
            FROM system.tables t
            WHERE t.database = '{FAIL_DATABASE}'
              AND t.name LIKE '%\\_fails'
              AND (
                  SELECT count()
                  FROM system.columns c
                  WHERE c.database = t.database
                    AND c.table = t.name
                    AND c.name IN ('run_id', 'stage', 'comment', 'failed_at')
              ) = 4
            ORDER BY t.name
            """,
        )
        return [
            {
                "table": r["table_name"],
                "entity": r["table_name"].removesuffix("_fails"),
            }
            for r in rows
        ]

    @mcp.tool()
    def pipeline_fail_tables(env: str = DEFAULT_ENV) -> list[dict]:
        """Discover all *_fails tables and their stats.

        Returns per table: entity, table, row_count, latest_failure, oldest_failure,
        distinct_stages, distinct_runs.
        """
        env = resolve_env(env)
        tables = _discover_fail_tables(env)
        if not tables:
            return [{"info": f"No *_fails tables found in {FAIL_DATABASE} database"}]

        results = []
        for t in tables:
            tname = safe_ident(t["table"])
            rows = query(
                env,
                f"""
                SELECT count() AS row_count,
                       max(failed_at) AS latest_failure,
                       min(failed_at) AS oldest_failure,
                       count(DISTINCT stage) AS distinct_stages,
                       count(DISTINCT run_id) AS distinct_runs
                FROM {_FAIL_DB_SAFE}.{tname}
                """,
            )
            row = rows[0]
            results.append(
                {
                    "entity": t["entity"],
                    "table": f"{FAIL_DATABASE}.{t['table']}",
                    "row_count": row["row_count"],
                    "latest_failure": str(row["latest_failure"])
                    if row["latest_failure"]
                    else None,
                    "oldest_failure": str(row["oldest_failure"])
                    if row["oldest_failure"]
                    else None,
                    "distinct_stages": row["distinct_stages"],
                    "distinct_runs": row["distinct_runs"],
                }
            )
        return results

    @mcp.tool()
    def pipeline_fail_summary(
        env: str = DEFAULT_ENV,
        days: int = 7,
        group_by: str = "entity",
    ) -> list[dict]:
        """Summarise failures across all *_fails tables.

        Groups by 'entity', 'stage', or 'entity_stage'. Looks back `days` days (1-90).
        """
        env = resolve_env(env)
        days = _clamp_days(days)

        if group_by not in ("entity", "stage", "entity_stage"):
            raise ValueError("group_by must be 'entity', 'stage', or 'entity_stage'")

        tables = _discover_fail_tables(env)
        if not tables:
            return [{"info": f"No *_fails tables found in {FAIL_DATABASE} database"}]

        unions = []
        for t in tables:
            tname = safe_ident(t["table"])
            entity_literal = t["entity"].replace("'", "\\'")
            unions.append(
                f"SELECT '{entity_literal}' AS entity, stage, run_id, failed_at "
                f"FROM {_FAIL_DB_SAFE}.{tname} "
                f"WHERE failed_at >= now() - INTERVAL {days} DAY"
            )

        union_sql = " UNION ALL ".join(unions)

        if group_by == "entity":
            select = "entity"
            group = "entity"
        elif group_by == "stage":
            select = "stage"
            group = "stage"
        else:
            select = "entity, stage"
            group = "entity, stage"

        sql = f"""
            SELECT {select},
                   count() AS total_failures,
                   count(DISTINCT run_id) AS distinct_runs,
                   min(failed_at) AS earliest,
                   max(failed_at) AS latest
            FROM ({union_sql}) sub
            GROUP BY {group}
            ORDER BY total_failures DESC
            LIMIT 200
        """
        rows = query(env, sql)
        for r in rows:
            if r.get("earliest"):
                r["earliest"] = str(r["earliest"])
            if r.get("latest"):
                r["latest"] = str(r["latest"])
        return rows

    @mcp.tool()
    def pipeline_fail_details(
        entity: str,
        env: str = DEFAULT_ENV,
        limit: int = 50,
        stage: str | None = None,
        run_id: str | None = None,
        days: int | None = None,
    ) -> list[dict]:
        """Drill into failure details for a specific entity's fail table.

        Optional filters: stage, run_id (UUID), days (time window).
        """
        env = resolve_env(env)
        limit = _clamp_row(limit)

        table_name = f"{entity}_fails"
        safe_table = safe_ident(table_name)

        exists = query(
            env,
            f"""
            SELECT 1 FROM system.tables
            WHERE database = '{FAIL_DATABASE}' AND name = '{table_name}'
            """,
        )
        if not exists:
            return [
                {
                    "error": f"Table {FAIL_DATABASE}.{table_name} not found in this environment"
                }
            ]

        where_parts: list[str] = []

        if stage:
            safe_ident(stage)
            where_parts.append(f"stage = '{stage}'")

        if run_id:
            _validate_uuid(run_id)
            where_parts.append(f"run_id = '{run_id}'")

        if days is not None:
            days = _clamp_days(days)
            where_parts.append(f"failed_at >= now() - INTERVAL {days} DAY")

        where = ("WHERE " + " AND ".join(where_parts)) if where_parts else ""

        return query(
            env,
            f"SELECT * FROM {_FAIL_DB_SAFE}.{safe_table} {where} ORDER BY failed_at DESC LIMIT {limit}",
        )

    @mcp.tool()
    def pipeline_fail_runs(
        env: str = DEFAULT_ENV,
        entity: str | None = None,
        limit: int = 50,
        days: int = 7,
    ) -> list[dict]:
        """Analyse which runs generated the most failures.

        Optionally scope to a single entity. Looks back `days` days (1-90).
        Returns: run_id, entities_affected, total_failures, stages, earliest_failure, latest_failure.
        """
        env = resolve_env(env)
        limit = _clamp_agg(limit)
        days = _clamp_days(days)

        if entity:
            table_name = f"{entity}_fails"
            safe_table = safe_ident(table_name)
            exists = query(
                env,
                f"""
                SELECT 1 FROM system.tables
                WHERE database = '{FAIL_DATABASE}' AND name = '{table_name}'
                """,
            )
            if not exists:
                return [{"error": f"Table {FAIL_DATABASE}.{table_name} not found"}]

            entity_literal = entity.replace("'", "\\'")
            unions = [
                f"SELECT '{entity_literal}' AS entity, run_id, stage, failed_at "
                f"FROM {_FAIL_DB_SAFE}.{safe_table} "
                f"WHERE failed_at >= now() - INTERVAL {days} DAY"
            ]
        else:
            tables = _discover_fail_tables(env)
            if not tables:
                return [{"info": f"No *_fails tables found in {FAIL_DATABASE} database"}]
            unions = []
            for t in tables:
                tname = safe_ident(t["table"])
                entity_literal = t["entity"].replace("'", "\\'")
                unions.append(
                    f"SELECT '{entity_literal}' AS entity, run_id, stage, failed_at "
                    f"FROM {_FAIL_DB_SAFE}.{tname} "
                    f"WHERE failed_at >= now() - INTERVAL {days} DAY"
                )

        union_sql = " UNION ALL ".join(unions)

        sql = f"""
            SELECT run_id,
                   count(DISTINCT entity) AS entities_affected,
                   count() AS total_failures,
                   arrayStringConcat(arraySort(groupUniqArray(stage)), ', ') AS stages,
                   min(failed_at) AS earliest_failure,
                   max(failed_at) AS latest_failure
            FROM ({union_sql}) sub
            GROUP BY run_id
            ORDER BY total_failures DESC
            LIMIT {limit}
        """
        rows = query(env, sql)
        for r in rows:
            if r.get("run_id"):
                r["run_id"] = str(r["run_id"])
            if r.get("earliest_failure"):
                r["earliest_failure"] = str(r["earliest_failure"])
            if r.get("latest_failure"):
                r["latest_failure"] = str(r["latest_failure"])
        return rows


# ── Entrypoint ────────────────────────────────────────────────────────────────


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
