"""ch-analytics-mcp — ClickHouse analytics MCP server."""
