# bm-preprocessing Usage Guide

## Installation

```bash
pip install bm-preprocessing
```

---

## Usage in Python File

Create a file `example.py`:

```python
# Import modules
from bm_preprocessing.IR import all
from bm_preprocessing.DM import adaboost, apriori, bagging, hash, hunts, hunts_test, id3, id3_test, preprocessing

# Print the source code
print("=== IR All Module ===")
print(all)

print("\n=== DM Apriori Module ===")
print(apriori)

print("\n=== DM AdaBoost Module ===")
print(adaboost)

print("\n=== DM Bagging Module ===")
print(bagging)

print("\n=== DM Hash Module ===")
print(hash)

print("\n=== DM Hunts Module ===")
print(hunts)

print("\n=== DM Hunts Test Module ===")
print(hunts_test)

print("\n=== DM ID3 Module ===")
print(id3)

print("\n=== DM ID3 Test Module ===")
print(id3_test)

print("\n=== DM Preprocessing Module ===")
print(preprocessing)
```

Run it:
```bash
python example.py
```

---

## Usage in Terminal (Interactive Python)

```bash
python
```

Then in the Python REPL:

```python
>>> from bm_preprocessing.IR import all
>>> print(all)
# Prints entire IR/all.py source code

>>> from bm_preprocessing.DM import apriori
>>> print(apriori)
# Prints entire DM/apriori.py source code

>>> from bm_preprocessing.DM import adaboost
>>> print(adaboost)
# Prints entire DM/adaboost.py source code

>>> from bm_preprocessing.DM import bagging
>>> print(bagging)
# Prints entire DM/bagging.py source code

>>> from bm_preprocessing.DM import hunts, hunts_test
>>> print(hunts)
# Prints entire DM/hunts.py source code
>>> print(hunts_test)
# Prints entire DM/hunts_test.py source code

>>> from bm_preprocessing.DM import id3, id3_test
>>> print(id3)
# Prints entire DM/id3.py source code
>>> print(id3_test)
# Prints entire DM/id3_test.py source code
```

---

## One-liner in Terminal

```bash
python -c "from bm_preprocessing.IR import all; print(all)"
python -c "from bm_preprocessing.DM import apriori; print(apriori)"
python -c "from bm_preprocessing.DM import adaboost; print(adaboost)"
python -c "from bm_preprocessing.DM import bagging; print(bagging)"
python -c "from bm_preprocessing.DM import hash; print(hash)"
python -c "from bm_preprocessing.DM import hunts; print(hunts)"
python -c "from bm_preprocessing.DM import hunts_test; print(hunts_test)"
python -c "from bm_preprocessing.DM import id3; print(id3)"
python -c "from bm_preprocessing.DM import id3_test; print(id3_test)"
python -c "from bm_preprocessing.DM import preprocessing; print(preprocessing)"
```

---

## Available Modules

| Import | Description |
|--------|-------------|
| `from bm_preprocessing.IR import all` | Information Retrieval (BM25, TF-IDF, Boolean) |
| `from bm_preprocessing.DM import all` | Data Mining algorithms |
| `from bm_preprocessing.DM import apriori` | Apriori algorithm |
| `from bm_preprocessing.DM import adaboost` | Bagging & AdaBoost ensemble classifiers |
| `from bm_preprocessing.DM import bagging` | Bagging ensemble classifier |
| `from bm_preprocessing.DM import hash` | Hash-based mining |
| `from bm_preprocessing.DM import hunts` | Hunt's decision tree algorithm |
| `from bm_preprocessing.DM import hunts_test` | Hunt's decision tree with visualization |
| `from bm_preprocessing.DM import id3` | ID3 decision tree algorithm |
| `from bm_preprocessing.DM import id3_test` | ID3 decision tree with visualization |
| `from bm_preprocessing.DM import preprocessing` | Data preprocessing utilities |
