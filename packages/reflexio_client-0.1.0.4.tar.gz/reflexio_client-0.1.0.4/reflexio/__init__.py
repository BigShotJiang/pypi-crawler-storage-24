from importlib.metadata import PackageNotFoundError, version

__package_name__ = "reflexio-client"

try:
    __version__ = version(__package_name__)
except PackageNotFoundError:
    # Package is not installed (e.g., running from source without installing)
    __version__ = "0.0.0-dev"


from reflexio_commons.api_schema.retriever_schema import (
    ConversationTurn,
    GetSkillsRequest,
    GetSkillsResponse,
    SearchInteractionRequest,
    SearchInteractionResponse,
    SearchSkillsRequest,
    SearchSkillsResponse,
    SearchUserProfileRequest,
    SearchUserProfileResponse,
)
from reflexio_commons.api_schema.service_schemas import (
    AddRawFeedbackRequest,
    AddRawFeedbackResponse,
    BlockingIssue,
    BlockingIssueKind,
    BulkDeleteResponse,
    DeleteFeedbacksByIdsRequest,
    DeleteProfilesByIdsRequest,
    DeleteRawFeedbacksByIdsRequest,
    DeleteRequestsByIdsRequest,
    DeleteUserInteractionRequest,
    DeleteUserInteractionResponse,
    DeleteUserProfileRequest,
    DeleteUserProfileResponse,
    FeedbackStatus,
    Interaction,
    InteractionData,
    ProfileTimeToLive,
    PublishUserInteractionRequest,
    PublishUserInteractionResponse,
    RawFeedback,
    RerunFeedbackGenerationRequest,
    RerunFeedbackGenerationResponse,
    RerunProfileGenerationRequest,
    RerunProfileGenerationResponse,
    Status,
    ToolUsed,
    UserActionType,
    UserProfile,
)
from reflexio_commons.config_schema import (
    AgentFeedbackConfig,
    AgentSuccessConfig,
    Config,
    FeedbackAggregatorConfig,
    ProfileExtractorConfig,
    StorageConfig,
    StorageConfigLocal,
    StorageConfigSQLite,
    StorageConfigSupabase,
    StorageConfigTest,
    ToolUseConfig,
)

from .client import ReflexioClient

debug = False
log = None  # Set to either 'debug' or 'info', controls console logging


__all__ = [
    "ReflexioClient",
    "UserActionType",
    "ProfileTimeToLive",
    "InteractionData",
    "Interaction",
    "UserProfile",
    "PublishUserInteractionRequest",
    "PublishUserInteractionResponse",
    "DeleteUserProfileRequest",
    "DeleteUserProfileResponse",
    "DeleteUserInteractionRequest",
    "DeleteUserInteractionResponse",
    "RawFeedback",
    "BlockingIssue",
    "BlockingIssueKind",
    "AddRawFeedbackRequest",
    "AddRawFeedbackResponse",
    "RerunProfileGenerationRequest",
    "RerunProfileGenerationResponse",
    "RerunFeedbackGenerationRequest",
    "RerunFeedbackGenerationResponse",
    "ConversationTurn",
    "SearchInteractionRequest",
    "SearchUserProfileRequest",
    "SearchInteractionResponse",
    "SearchUserProfileResponse",
    "StorageConfigTest",
    "StorageConfigLocal",
    "StorageConfigSQLite",
    "StorageConfigSupabase",
    "StorageConfig",
    "ProfileExtractorConfig",
    "FeedbackAggregatorConfig",
    "AgentFeedbackConfig",
    "AgentSuccessConfig",
    "ToolUseConfig",
    "Config",
    "Status",
    "FeedbackStatus",
    "ToolUsed",
    "BulkDeleteResponse",
    "DeleteRequestsByIdsRequest",
    "DeleteProfilesByIdsRequest",
    "DeleteFeedbacksByIdsRequest",
    "DeleteRawFeedbacksByIdsRequest",
    "GetSkillsRequest",
    "GetSkillsResponse",
    "SearchSkillsRequest",
    "SearchSkillsResponse",
]
