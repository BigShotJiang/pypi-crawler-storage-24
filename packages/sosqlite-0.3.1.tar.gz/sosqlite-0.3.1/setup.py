import setuptools
from pathlib import Path


setuptools.setup(
    name="sosqlite",
    version="0.3.1",
    author="Ricardo Ander-Egg Aguilar; Peter Kerpedjiev",
    author_email="rsubacc@gmail.com;pkerpedjiev@gmail.com",
    description="Query SQLite databases on S3 using s3fs or smart_open",
    long_description=Path("README.md").read_text(),
    long_description_content_type="text/markdown",
    url="https://github.com/pkerpedjiev/sosqlite",
    py_modules=["sosqlite"],
    classifiers=[
        "Operating System :: OS Independent",
    ],
    install_requires=["fsspec", "apsw", "s3fs", "boto3", "smart_open"],
    python_requires=">=3.7",
    license_files=(),
)
