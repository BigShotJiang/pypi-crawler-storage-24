"""
Order management functionality

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

from typing import Optional, Dict, Any, List

from .client import BinanceClient


class OrderManager:
    """Order management operations"""
    
    def __init__(self, client: BinanceClient):
        self.client = client
    
    def get_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        Get order details
        
        Args:
            symbol: Trading pair
            order_id: Order ID
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'orderId': order_id
        }
        return self.client.get('/api/v3/order', params, signed=True)
    
    def get_all_open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get all open orders
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            List of open orders
        """
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self.client.get('/api/v3/openOrders', params, signed=True)
    
    def get_history(
        self,
        symbol: str,
        limit: int = 500,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get order history
        
        Args:
            symbol: Trading pair
            limit: Number of orders to return (max 1000)
            start_time: Start time in milliseconds
            end_time: End time in milliseconds
            
        Returns:
            List of historical orders
        """
        params = {
            'symbol': symbol,
            'limit': min(limit, 1000)
        }
        if start_time:
            params['startTime'] = start_time
        if end_time:
            params['endTime'] = end_time
        return self.client.get('/api/v3/allOrders', params, signed=True)
    
    def cancel(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        Cancel an order
        
        Args:
            symbol: Trading pair
            order_id: Order ID
            
        Returns:
            Cancellation result
        """
        params = {
            'symbol': symbol,
            'orderId': order_id
        }
        return self.client.delete('/api/v3/order', params, signed=True)
    
    def cancel_all(self, symbol: str) -> List[Dict[str, Any]]:
        """
        Cancel all orders for a symbol
        
        Args:
            symbol: Trading pair
            
        Returns:
            List of cancellation results
        """
        params = {'symbol': symbol}
        return self.client.delete('/api/v3/openOrders', params, signed=True)
    
    def get_trades(
        self,
        symbol: str,
        limit: int = 500,
        from_id: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """
        Get trades for a specific order or symbol
        
        Args:
            symbol: Trading pair
            limit: Number of trades to return
            from_id: Trade ID to fetch from
            
        Returns:
            List of trades
        """
        params = {
            'symbol': symbol,
            'limit': limit
        }
        if from_id:
            params['fromId'] = from_id
        return self.client.get('/api/v3/myTrades', params, signed=True)
