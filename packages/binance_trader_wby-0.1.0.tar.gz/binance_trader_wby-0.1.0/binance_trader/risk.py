"""
Risk management module

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

from typing import Optional, Dict, Any

from .trader import BinanceTrader


class RiskManager:
    """Risk management utilities"""
    
    def __init__(self, trader: BinanceTrader):
        self.trader = trader
    
    def calculate_position_size(
        self,
        symbol: str,
        risk_percent: float,
        stop_loss_percent: float,
        account_balance: Optional[float] = None
    ) -> float:
        """
        Calculate position size based on risk percentage
        
        Args:
            symbol: Trading pair
            risk_percent: Percentage of account to risk (e.g., 2.0 for 2%)
            stop_loss_percent: Stop loss percentage (e.g., 5.0 for 5%)
            account_balance: Optional account balance (fetched if not provided)
            
        Returns:
            Recommended position size
        """
        if account_balance is None:
            balance_info = self.trader.get_balance()
            # Extract USDT balance
            for asset in balance_info.get('balances', []):
                if asset['asset'] == 'USDT':
                    account_balance = float(asset['free'])
                    break
            if account_balance is None:
                raise ValueError("Could not determine account balance")
        
        # Calculate risk amount
        risk_amount = account_balance * (risk_percent / 100)
        
        # Calculate position size based on stop loss
        position_size = risk_amount / (stop_loss_percent / 100)
        
        return position_size
    
    def place_order_with_stop_loss(
        self,
        symbol: str,
        side: str,
        risk_percent: float,
        stop_loss_percent: float,
        take_profit_percent: Optional[float] = None
    ) -> Dict[str, Any]:
        """
        Place an order with stop loss and optional take profit
        
        Args:
            symbol: Trading pair
            side: 'BUY' or 'SELL'
            risk_percent: Risk percentage
            stop_loss_percent: Stop loss percentage
            take_profit_percent: Optional take profit percentage
            
        Returns:
            Order details
        """
        # Get current price
        price_info = self.trader.market.get_price(symbol)
        current_price = float(price_info['price'])
        
        # Calculate position size
        position_size = self.calculate_position_size(
            symbol,
            risk_percent,
            stop_loss_percent
        )
        
        # Place main order
        if side == 'BUY':
            order = self.trader.spot.buy_market(symbol, position_size / current_price)
            stop_price = current_price * (1 - stop_loss_percent / 100)
        else:
            order = self.trader.spot.sell_market(symbol, position_size / current_price)
            stop_price = current_price * (1 + stop_loss_percent / 100)
        
        # Note: Stop loss orders would be implemented here
        # This is a simplified version
        
        return {
            'main_order': order,
            'stop_loss_price': stop_price,
            'risk_amount': position_size * (risk_percent / 100)
        }
    
    def get_portfolio_allocation(self) -> Dict[str, float]:
        """
        Get current portfolio allocation
        
        Returns:
            Dictionary of asset allocations
        """
        balance = self.trader.get_balance()
        allocations = {}
        
        total_value = 0
        for asset in balance.get('balances', []):
            free = float(asset['free'])
            locked = float(asset['locked'])
            total = free + locked
            if total > 0:
                allocations[asset['asset']] = total
                total_value += total
        
        # Convert to percentages
        if total_value > 0:
            for asset in allocations:
                allocations[asset] = (allocations[asset] / total_value) * 100
        
        return allocations
    
    def check_drawdown(self, peak_balance: float) -> Dict[str, Any]:
        """
        Check current drawdown from peak
        
        Args:
            peak_balance: Historical peak balance
            
        Returns:
            Drawdown information
        """
        balance = self.trader.get_balance()
        current_balance = sum(
            float(asset['free']) + float(asset['locked'])
            for asset in balance.get('balances', [])
        )
        
        drawdown = peak_balance - current_balance
        drawdown_percent = (drawdown / peak_balance) * 100 if peak_balance > 0 else 0
        
        return {
            'peak_balance': peak_balance,
            'current_balance': current_balance,
            'drawdown': drawdown,
            'drawdown_percent': drawdown_percent
        }
