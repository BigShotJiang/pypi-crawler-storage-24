"""
Binance Trader - A Python library for Binance cryptocurrency trading

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

__version__ = "0.1.0"
__author__ = "Wu Boyuan"
__email__ = "328241614@qq.com"

from .client import BinanceClient
from .trader import BinanceTrader
from .spot import SpotTrading
from .futures import FuturesTrading
from .orders import OrderManager
from .market import MarketData

__all__ = [
    "BinanceClient",
    "BinanceTrader",
    "SpotTrading",
    "FuturesTrading",
    "OrderManager",
    "MarketData",
]