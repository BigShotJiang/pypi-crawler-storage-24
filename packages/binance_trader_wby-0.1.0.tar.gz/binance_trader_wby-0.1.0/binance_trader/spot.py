"""
Spot trading functionality

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

from typing import Optional, Dict, Any, List

from .client import BinanceClient


class SpotTrading:
    """Spot trading operations"""
    
    def __init__(self, client: BinanceClient):
        self.client = client
    
    def buy_market(self, symbol: str, quantity: float) -> Dict[str, Any]:
        """
        Place market buy order
        
        Args:
            symbol: Trading pair (e.g., 'BTCUSDT')
            quantity: Amount to buy
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'side': 'BUY',
            'type': 'MARKET',
            'quantity': quantity
        }
        return self.client.post('/api/v3/order', params, signed=True)
    
    def sell_market(self, symbol: str, quantity: float) -> Dict[str, Any]:
        """
        Place market sell order
        
        Args:
            symbol: Trading pair (e.g., 'BTCUSDT')
            quantity: Amount to sell
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'side': 'SELL',
            'type': 'MARKET',
            'quantity': quantity
        }
        return self.client.post('/api/v3/order', params, signed=True)
    
    def buy_limit(
        self,
        symbol: str,
        quantity: float,
        price: float,
        time_in_force: str = 'GTC'
    ) -> Dict[str, Any]:
        """
        Place limit buy order
        
        Args:
            symbol: Trading pair
            quantity: Amount to buy
            price: Limit price
            time_in_force: Time in force (GTC, IOC, FOK)
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'side': 'BUY',
            'type': 'LIMIT',
            'quantity': quantity,
            'price': price,
            'timeInForce': time_in_force
        }
        return self.client.post('/api/v3/order', params, signed=True)
    
    def sell_limit(
        self,
        symbol: str,
        quantity: float,
        price: float,
        time_in_force: str = 'GTC'
    ) -> Dict[str, Any]:
        """
        Place limit sell order
        
        Args:
            symbol: Trading pair
            quantity: Amount to sell
            price: Limit price
            time_in_force: Time in force
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'side': 'SELL',
            'type': 'LIMIT',
            'quantity': quantity,
            'price': price,
            'timeInForce': time_in_force
        }
        return self.client.post('/api/v3/order', params, signed=True)
    
    def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get open orders
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            List of open orders
        """
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self.client.get('/api/v3/openOrders', params, signed=True)
    
    def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        Cancel an order
        
        Args:
            symbol: Trading pair
            order_id: Order ID to cancel
            
        Returns:
            Cancellation result
        """
        params = {
            'symbol': symbol,
            'orderId': order_id
        }
        return self.client.delete('/api/v3/order', params, signed=True)
    
    def cancel_all_orders(self, symbol: str) -> List[Dict[str, Any]]:
        """
        Cancel all orders for a symbol
        
        Args:
            symbol: Trading pair
            
        Returns:
            List of cancellation results
        """
        params = {'symbol': symbol}
        return self.client.delete('/api/v3/openOrders', params, signed=True)
    
    def get_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        Get order status
        
        Args:
            symbol: Trading pair
            order_id: Order ID
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'orderId': order_id
        }
        return self.client.get('/api/v3/order', params, signed=True)
    
    def get_trade_history(
        self,
        symbol: str,
        limit: int = 500
    ) -> List[Dict[str, Any]]:
        """
        Get trade history for a symbol
        
        Args:
            symbol: Trading pair
            limit: Number of trades to return
            
        Returns:
            List of trades
        """
        params = {
            'symbol': symbol,
            'limit': limit
        }
        return self.client.get('/api/v3/myTrades', params, signed=True)
