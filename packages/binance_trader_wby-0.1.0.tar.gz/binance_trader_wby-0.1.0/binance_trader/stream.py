"""
WebSocket streaming functionality

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

import json
import threading
from typing import Callable, Optional, Dict, Any

from .trader import BinanceTrader


class BinanceStream:
    """WebSocket streaming for real-time data"""
    
    def __init__(self, trader: BinanceTrader):
        self.trader = trader
        self.callbacks = {}
        self.running = False
        self.ws = None
        self.thread = None
    
    def subscribe_trade(self, symbol: str, callback: Callable[[Dict], None]):
        """
        Subscribe to trade updates
        
        Args:
            symbol: Trading pair
            callback: Function to call with trade data
        """
        self.callbacks[f"trade_{symbol.lower()}"] = callback
    
    def subscribe_kline(self, symbol: str, interval: str, callback: Callable[[Dict], None]):
        """
        Subscribe to kline/candlestick updates
        
        Args:
            symbol: Trading pair
            interval: Kline interval
            callback: Function to call with kline data
        """
        self.callbacks[f"kline_{symbol.lower()}_{interval}"] = callback
    
    def subscribe_order_book(self, symbol: str, callback: Callable[[Dict], None]):
        """
        Subscribe to order book updates
        
        Args:
            symbol: Trading pair
            callback: Function to call with order book data
        """
        self.callbacks[f"depth_{symbol.lower()}"] = callback
    
    def subscribe_ticker(self, symbol: str, callback: Callable[[Dict], None]):
        """
        Subscribe to 24hr ticker updates
        
        Args:
            symbol: Trading pair
            callback: Function to call with ticker data
        """
        self.callbacks[f"ticker_{symbol.lower()}"] = callback
    
    def start(self):
        """Start the WebSocket connection"""
        try:
            import websocket
        except ImportError:
            raise ImportError("websocket-client package required for streaming")
        
        self.running = True
        
        # Build stream URL
        streams = []
        for key in self.callbacks.keys():
            if key.startswith('trade_'):
                symbol = key.replace('trade_', '')
                streams.append(f"{symbol}@trade")
            elif key.startswith('kline_'):
                parts = key.split('_')
                symbol = parts[1]
                interval = parts[2]
                streams.append(f"{symbol}@kline_{interval}")
            elif key.startswith('depth_'):
                symbol = key.replace('depth_', '')
                streams.append(f"{symbol}@depth")
            elif key.startswith('ticker_'):
                symbol = key.replace('ticker_', '')
                streams.append(f"{symbol}@ticker")
        
        if not streams:
            raise ValueError("No subscriptions added")
        
        stream_path = '/'.join(streams)
        base_url = (
            'wss://testnet.binance.vision/ws'
            if self.trader.testnet
            else 'wss://stream.binance.com:9443/ws'
        )
        url = f"{base_url}/{stream_path}"
        
        def on_message(ws, message):
            data = json.loads(message)
            stream = data.get('stream', '')
            
            # Find and call appropriate callback
            for key, callback in self.callbacks.items():
                if stream.startswith(key.replace('_', '')):
                    callback(data.get('data', data))
                    break
        
        def on_error(ws, error):
            print(f"WebSocket error: {error}")
        
        def on_close(ws, close_status_code, close_msg):
            print("WebSocket closed")
            self.running = False
        
        def on_open(ws):
            print("WebSocket connected")
        
        self.ws = websocket.WebSocketApp(
            url,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close
        )
        
        self.thread = threading.Thread(target=self.ws.run_forever)
        self.thread.daemon = True
        self.thread.start()
    
    def stop(self):
        """Stop the WebSocket connection"""
        self.running = False
        if self.ws:
            self.ws.close()
        if self.thread:
            self.thread.join(timeout=5)
