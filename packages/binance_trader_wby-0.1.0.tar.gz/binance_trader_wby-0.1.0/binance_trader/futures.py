"""
Futures trading functionality

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

from typing import Optional, Dict, Any, List

from .client import BinanceClient


class FuturesTrading:
    """Futures trading operations"""
    
    def __init__(self, client: BinanceClient):
        self.client = client
    
    def _futures_request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        signed: bool = False
    ) -> Dict[str, Any]:
        """Make futures API request"""
        base_url = (
            self.client.FUTURES_TESTNET_URL
            if self.client.testnet
            else self.client.FUTURES_BASE_URL
        )
        return self.client.request(method, endpoint, params, signed, base_url)
    
    def set_leverage(self, symbol: str, leverage: int) -> Dict[str, Any]:
        """
        Set leverage for a symbol
        
        Args:
            symbol: Trading pair
            leverage: Leverage level (1-125)
            
        Returns:
            Leverage setting result
        """
        params = {
            'symbol': symbol,
            'leverage': leverage
        }
        return self._futures_request(
            'POST',
            '/fapi/v1/leverage',
            params,
            signed=True
        )
    
    def open_long(self, symbol: str, quantity: float) -> Dict[str, Any]:
        """
        Open long position (buy)
        
        Args:
            symbol: Trading pair
            quantity: Position size
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'side': 'BUY',
            'type': 'MARKET',
            'quantity': quantity
        }
        return self._futures_request(
            'POST',
            '/fapi/v1/order',
            params,
            signed=True
        )
    
    def open_short(self, symbol: str, quantity: float) -> Dict[str, Any]:
        """
        Open short position (sell)
        
        Args:
            symbol: Trading pair
            quantity: Position size
            
        Returns:
            Order details
        """
        params = {
            'symbol': symbol,
            'side': 'SELL',
            'type': 'MARKET',
            'quantity': quantity
        }
        return self._futures_request(
            'POST',
            '/fapi/v1/order',
            params,
            signed=True
        )
    
    def close_position(self, symbol: str) -> Dict[str, Any]:
        """
        Close position for a symbol
        
        Args:
            symbol: Trading pair
            
        Returns:
            Order details
        """
        # Get current position
        position = self.get_position(symbol)
        if not position or float(position.get('positionAmt', 0)) == 0:
            raise ValueError(f"No open position for {symbol}")
        
        position_amt = float(position['positionAmt'])
        
        # Determine close side
        side = 'SELL' if position_amt > 0 else 'BUY'
        
        params = {
            'symbol': symbol,
            'side': side,
            'type': 'MARKET',
            'quantity': abs(position_amt),
            'reduceOnly': 'true'
        }
        return self._futures_request(
            'POST',
            '/fapi/v1/order',
            params,
            signed=True
        )
    
    def get_position(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Get position information
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            Position details
        """
        params = {}
        if symbol:
            params['symbol'] = symbol
        
        positions = self._futures_request(
            'GET',
            '/fapi/v2/positionRisk',
            params,
            signed=True
        )
        
        if symbol and positions:
            for pos in positions:
                if pos['symbol'] == symbol:
                    return pos
            return {}
        return positions
    
    def get_account_info(self) -> Dict[str, Any]:
        """Get futures account information"""
        return self._futures_request(
            'GET',
            '/fapi/v2/account',
            signed=True
        )
    
    def get_open_orders(self, symbol: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get open futures orders
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            List of open orders
        """
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self._futures_request(
            'GET',
            '/fapi/v1/openOrders',
            params,
            signed=True
        )
    
    def cancel_order(self, symbol: str, order_id: int) -> Dict[str, Any]:
        """
        Cancel a futures order
        
        Args:
            symbol: Trading pair
            order_id: Order ID
            
        Returns:
            Cancellation result
        """
        params = {
            'symbol': symbol,
            'orderId': order_id
        }
        return self._futures_request(
            'DELETE',
            '/fapi/v1/order',
            params,
            signed=True
        )
