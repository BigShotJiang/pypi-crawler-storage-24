"""
Core client for Binance API

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

import hashlib
import hmac
import time
from typing import Dict, Optional, Any
import requests


class BinanceClient:
    """Base client for Binance API"""
    
    SPOT_BASE_URL = "https://api.binance.com"
    SPOT_TESTNET_URL = "https://testnet.binance.vision"
    FUTURES_BASE_URL = "https://fapi.binance.com"
    FUTURES_TESTNET_URL = "https://testnet.binancefuture.com"
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        testnet: bool = False,
        timeout: int = 30
    ):
        """
        Initialize Binance client
        
        Args:
            api_key: Binance API key
            api_secret: Binance API secret
            testnet: Use testnet environment
            timeout: Request timeout in seconds
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.testnet = testnet
        self.timeout = timeout
        
        self.session = requests.Session()
        if self.api_key:
            self.session.headers.update({
                'X-MBX-APIKEY': self.api_key
            })
    
    def _generate_signature(self, query_string: str) -> str:
        """Generate HMAC signature for request"""
        if not self.api_secret:
            raise ValueError("API secret is required for signed requests")
        return hmac.new(
            self.api_secret.encode('utf-8'),
            query_string.encode('utf-8'),
            hashlib.sha256
        ).hexdigest()
    
    def _get_timestamp(self) -> int:
        """Get current timestamp in milliseconds"""
        return int(time.time() * 1000)
    
    def _prepare_params(self, params: Optional[Dict] = None) -> Dict:
        """Prepare parameters with timestamp"""
        if params is None:
            params = {}
        params['timestamp'] = self._get_timestamp()
        return params
    
    def _sign_request(self, params: Dict) -> str:
        """Sign request parameters"""
        query_string = '&'.join([f"{k}={v}" for k, v in params.items()])
        params['signature'] = self._generate_signature(query_string)
        return query_string
    
    def request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict] = None,
        signed: bool = False,
        base_url: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Make API request
        
        Args:
            method: HTTP method (GET, POST, DELETE)
            endpoint: API endpoint
            params: Request parameters
            signed: Whether to sign the request
            base_url: Custom base URL
            
        Returns:
            API response as dictionary
        """
        if base_url is None:
            base_url = self.SPOT_TESTNET_URL if self.testnet else self.SPOT_BASE_URL
        
        url = f"{base_url}{endpoint}"
        
        if params is None:
            params = {}
        
        if signed:
            params = self._prepare_params(params)
            self._sign_request(params)
        
        response = self.session.request(
            method=method,
            url=url,
            params=params if method == 'GET' else None,
            data=params if method != 'GET' else None,
            timeout=self.timeout
        )
        
        response.raise_for_status()
        return response.json()
    
    def get(self, endpoint: str, params: Optional[Dict] = None, **kwargs) -> Dict:
        """Make GET request"""
        return self.request('GET', endpoint, params, **kwargs)
    
    def post(self, endpoint: str, params: Optional[Dict] = None, **kwargs) -> Dict:
        """Make POST request"""
        return self.request('POST', endpoint, params, **kwargs)
    
    def delete(self, endpoint: str, params: Optional[Dict] = None, **kwargs) -> Dict:
        """Make DELETE request"""
        return self.request('DELETE', endpoint, params, **kwargs)
