"""
Market data functionality

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

from typing import Optional, Dict, Any, List

from .client import BinanceClient


class MarketData:
    """Market data operations"""
    
    def __init__(self, client: BinanceClient):
        self.client = client
    
    def get_price(self, symbol: str) -> Dict[str, Any]:
        """
        Get current price for a symbol
        
        Args:
            symbol: Trading pair
            
        Returns:
            Price information
        """
        return self.client.get('/api/v3/ticker/price', {'symbol': symbol})
    
    def get_24h_stats(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Get 24 hour price change statistics
        
        Args:
            symbol: Trading pair (if None, returns all symbols)
            
        Returns:
            24h statistics
        """
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self.client.get('/api/v3/ticker/24hr', params)
    
    def get_order_book(self, symbol: str, limit: int = 100) -> Dict[str, Any]:
        """
        Get order book for a symbol
        
        Args:
            symbol: Trading pair
            limit: Depth limit (5, 10, 20, 50, 100, 500, 1000, 5000)
            
        Returns:
            Order book data
        """
        params = {
            'symbol': symbol,
            'limit': limit
        }
        return self.client.get('/api/v3/depth', params)
    
    def get_recent_trades(self, symbol: str, limit: int = 500) -> List[Dict[str, Any]]:
        """
        Get recent trades
        
        Args:
            symbol: Trading pair
            limit: Number of trades to return (max 1000)
            
        Returns:
            List of recent trades
        """
        params = {
            'symbol': symbol,
            'limit': min(limit, 1000)
        }
        return self.client.get('/api/v3/trades', params)
    
    def get_klines(
        self,
        symbol: str,
        interval: str = '1h',
        limit: int = 500,
        start_time: Optional[int] = None,
        end_time: Optional[int] = None
    ) -> List[List]:
        """
        Get klines/candlestick data
        
        Args:
            symbol: Trading pair
            interval: Kline interval (1m, 3m, 5m, 15m, 30m, 1h, 2h, 4h, 6h, 8h, 12h, 1d, 3d, 1w, 1M)
            limit: Number of klines to return (max 1000)
            start_time: Start time in milliseconds
            end_time: End time in milliseconds
            
        Returns:
            List of klines [open_time, open, high, low, close, volume, close_time, ...]
        """
        params = {
            'symbol': symbol,
            'interval': interval,
            'limit': min(limit, 1000)
        }
        if start_time:
            params['startTime'] = start_time
        if end_time:
            params['endTime'] = end_time
        return self.client.get('/api/v3/klines', params)
    
    def get_exchange_info(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Get exchange information
        
        Args:
            symbol: Optional symbol filter
            
        Returns:
            Exchange information including trading rules and symbol info
        """
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self.client.get('/api/v3/exchangeInfo', params)
    
    def get_avg_price(self, symbol: str) -> Dict[str, Any]:
        """
        Get average price for a symbol (5 minute average)
        
        Args:
            symbol: Trading pair
            
        Returns:
            Average price information
        """
        return self.client.get('/api/v3/avgPrice', {'symbol': symbol})
    
    def get_book_ticker(self, symbol: Optional[str] = None) -> Dict[str, Any]:
        """
        Get best price/qty on the order book
        
        Args:
            symbol: Trading pair (if None, returns all symbols)
            
        Returns:
            Best bid and ask information
        """
        params = {}
        if symbol:
            params['symbol'] = symbol
        return self.client.get('/api/v3/ticker/bookTicker', params)
    
    def get_all_prices(self) -> List[Dict[str, Any]]:
        """
        Get all symbol prices
        
        Returns:
            List of all symbol prices
        """
        return self.client.get('/api/v3/ticker/price')
