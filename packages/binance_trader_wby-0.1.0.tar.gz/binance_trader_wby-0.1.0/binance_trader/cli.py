"""
Command line interface for binance-trader

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

import argparse
import json
import sys
from typing import Optional

from . import BinanceTrader


def main():
    """Main CLI entry point"""
    parser = argparse.ArgumentParser(
        description='Binance Trader CLI',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
Examples:
  binance-trader balance                    # Get account balance
  binance-trader price BTCUSDT              # Get current price
  binance-trader buy BTCUSDT 0.001          # Buy 0.001 BTC
  binance-trader sell BTCUSDT 0.001         # Sell 0.001 BTC
  binance-trader orders BTCUSDT             # List open orders
        '''
    )
    
    parser.add_argument(
        '--testnet',
        action='store_true',
        help='Use testnet'
    )
    parser.add_argument(
        '--config',
        type=str,
        help='Path to config file'
    )
    
    subparsers = parser.add_subparsers(dest='command', help='Commands')
    
    # Balance command
    subparsers.add_parser('balance', help='Get account balance')
    
    # Price command
    price_parser = subparsers.add_parser('price', help='Get symbol price')
    price_parser.add_argument('symbol', help='Trading pair (e.g., BTCUSDT)')
    
    # Buy command
    buy_parser = subparsers.add_parser('buy', help='Place buy order')
    buy_parser.add_argument('symbol', help='Trading pair')
    buy_parser.add_argument('quantity', type=float, help='Quantity to buy')
    buy_parser.add_argument('--limit', type=float, help='Limit price (optional)')
    
    # Sell command
    sell_parser = subparsers.add_parser('sell', help='Place sell order')
    sell_parser.add_argument('symbol', help='Trading pair')
    sell_parser.add_argument('quantity', type=float, help='Quantity to sell')
    sell_parser.add_argument('--limit', type=float, help='Limit price (optional)')
    
    # Orders command
    orders_parser = subparsers.add_parser('orders', help='List orders')
    orders_parser.add_argument('symbol', nargs='?', help='Filter by symbol')
    
    # Cancel command
    cancel_parser = subparsers.add_parser('cancel', help='Cancel order')
    cancel_parser.add_argument('symbol', help='Trading pair')
    cancel_parser.add_argument('order_id', type=int, help='Order ID')
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        sys.exit(1)
    
    try:
        # Initialize trader
        trader = BinanceTrader(
            testnet=args.testnet,
            config_file=args.config
        )
        
        # Execute command
        if args.command == 'balance':
            balance = trader.get_balance()
            print(json.dumps(balance, indent=2))
        
        elif args.command == 'price':
            price = trader.market.get_price(args.symbol)
            print(f"{args.symbol}: {price['price']}")
        
        elif args.command == 'buy':
            if args.limit:
                order = trader.spot.buy_limit(args.symbol, args.quantity, args.limit)
            else:
                order = trader.spot.buy_market(args.symbol, args.quantity)
            print(json.dumps(order, indent=2))
        
        elif args.command == 'sell':
            if args.limit:
                order = trader.spot.sell_limit(args.symbol, args.quantity, args.limit)
            else:
                order = trader.spot.sell_market(args.symbol, args.quantity)
            print(json.dumps(order, indent=2))
        
        elif args.command == 'orders':
            orders = trader.orders.get_all_open_orders(args.symbol)
            print(json.dumps(orders, indent=2))
        
        elif args.command == 'cancel':
            result = trader.orders.cancel(args.symbol, args.order_id)
            print(json.dumps(result, indent=2))
    
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
