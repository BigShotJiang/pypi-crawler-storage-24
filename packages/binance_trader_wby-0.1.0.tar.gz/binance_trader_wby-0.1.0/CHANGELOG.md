# Changelog

All notable changes to this project will be documented in this file.

**Author:** WUBOYUAN  
**Contact:** wuboyuan92@126.com

## [0.1.0] - 2026-03-15

### Added
- Initial release
- Spot trading support (market and limit orders)
- Futures trading support with leverage
- Order management (create, cancel, query)
- Market data (prices, order book, klines)
- Risk management utilities
- WebSocket streaming for real-time data
- Command line interface
- Comprehensive documentation (English and Chinese)

### Features
- `BinanceTrader` - Main trading interface
- `SpotTrading` - Spot market operations
- `FuturesTrading` - Futures/contract operations
- `OrderManager` - Order management
- `MarketData` - Market data queries
- `RiskManager` - Position sizing and risk control
- `BinanceStream` - Real-time WebSocket streams

### Security
- Environment variable support for API keys
- Config file support
- Testnet support for safe testing
