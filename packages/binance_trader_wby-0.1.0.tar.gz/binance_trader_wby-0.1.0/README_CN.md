# Binance Trader

币安加密货币交易 Python 库，支持现货、合约和订单管理。

**作者：** WUBOYUAN  
**联系方式：** wuboyuan92@126.com

## 功能特性

- **现货交易**: 在币安现货市场买卖加密货币
- **合约交易**: 使用杠杆交易永续合约
- **订单管理**: 检查订单状态、取消订单、查看历史
- **实时数据**: 获取市场数据、价格和订单簿
- **风险管理**: 内置仓位规模和风险控制

## 安装

```bash
pip install binance-trader
```

## 快速开始

```python
from binance_trader import BinanceTrader

# 初始化交易者
trader = BinanceTrader(
    api_key='你的API密钥',
    api_secret='你的API密钥',
    testnet=True  # 使用测试网进行测试
)

# 获取账户余额
balance = trader.get_balance()
print(balance)

# 下现货订单
order = trader.spot.buy(
    symbol='BTCUSDT',
    quantity=0.001,
    order_type='MARKET'
)
print(order)
```

## 配置

### 使用环境变量（推荐）

```bash
export BINANCE_API_KEY='你的API密钥'
export BINANCE_API_SECRET='你的API密钥'
```

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()  # 自动从环境变量加载
```

### 使用配置文件

创建 `~/.binance_trader/config.json`:

```json
{
    "api_key": "你的API密钥",
    "api_secret": "你的API密钥",
    "testnet": true
}
```

## 使用示例

### 现货交易

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# 市价买入
order = trader.spot.buy_market('BTCUSDT', quantity=0.001)

# 限价买入
order = trader.spot.buy_limit('BTCUSDT', quantity=0.001, price=50000)

# 卖出
order = trader.spot.sell_market('BTCUSDT', quantity=0.001)

# 获取未完成订单
orders = trader.spot.get_open_orders('BTCUSDT')

# 取消订单
trader.spot.cancel_order('BTCUSDT', order_id=123456)
```

### 合约交易

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# 设置杠杆
trader.futures.set_leverage('BTCUSDT', leverage=10)

# 开多仓
order = trader.futures.open_long('BTCUSDT', quantity=0.01)

# 开空仓
order = trader.futures.open_short('BTCUSDT', quantity=0.01)

# 平仓
order = trader.futures.close_position('BTCUSDT')

# 获取仓位信息
position = trader.futures.get_position('BTCUSDT')
```

### 订单管理

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# 查询特定订单
order = trader.orders.get_order('BTCUSDT', order_id=123456)

# 获取所有未完成订单
orders = trader.orders.get_all_open_orders()

# 获取订单历史
history = trader.orders.get_history('BTCUSDT', limit=100)

# 取消某个交易对的所有订单
trader.orders.cancel_all('BTCUSDT')
```

### 市场数据

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# 获取当前价格
price = trader.market.get_price('BTCUSDT')

# 获取订单簿
depth = trader.market.get_order_book('BTCUSDT', limit=10)

# 获取最近成交
trades = trader.market.get_recent_trades('BTCUSDT', limit=50)

# 获取K线/蜡烛图数据
klines = trader.market.get_klines('BTCUSDT', interval='1h', limit=100)
```

## 高级用法

### 风险管理

```python
from binance_trader import BinanceTrader
from binance_trader.risk import RiskManager

trader = BinanceTrader()
risk = RiskManager(trader)

# 基于风险百分比计算仓位规模
size = risk.calculate_position_size(
    symbol='BTCUSDT',
    risk_percent=2.0,  # 账户风险 2%
    stop_loss_percent=5.0  # 5% 止损
)

# 带风险管理下单
order = risk.place_order_with_stop_loss(
    symbol='BTCUSDT',
    side='BUY',
    risk_percent=2.0,
    stop_loss_percent=5.0
)
```

### WebSocket 流（实时数据）

```python
from binance_trader import BinanceTrader
from binance_trader.stream import BinanceStream

trader = BinanceTrader()
stream = BinanceStream(trader)

# 订阅价格更新
def on_price_update(data):
    print(f"价格更新: {data}")

stream.subscribe_trade('BTCUSDT', on_price_update)
stream.start()
```

## API 参考

详细 API 文档请参见 [API 文档](docs/api.md)。

## 测试

使用币安测试网进行测试，无需真实资金：

```python
from binance_trader import BinanceTrader

trader = BinanceTrader(testnet=True)
# 所有操作使用测试网资金
```

获取测试网 API 密钥：https://testnet.binance.vision/

## 环境要求

- Python 3.8+
- requests
- websocket-client
- python-dotenv

## 许可证

MIT 许可证 - 详见 [LICENSE](LICENSE) 文件

## 免责声明

本库仅供教育目的。加密货币交易涉及重大风险。使用风险自负。

## 支持

- GitHub Issues: https://github.com/wuboyuan/binance-trader/issues
- 文档: https://github.com/wuboyuan/binance-trader/wiki

## 更新日志

版本历史请参见 [CHANGELOG.md](CHANGELOG.md)。
