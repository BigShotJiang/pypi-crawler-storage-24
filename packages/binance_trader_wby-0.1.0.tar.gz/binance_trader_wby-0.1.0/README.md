# Binance Trader

A Python library for Binance cryptocurrency trading API with support for spot, futures, and order management.

**Author:** WUBOYUAN  
**Contact:** wuboyuan92@126.com

## Features

- **Spot Trading**: Buy and sell cryptocurrencies on Binance spot market
- **Futures Trading**: Trade perpetual contracts with leverage
- **Order Management**: Check order status, cancel orders, view history
- **Real-time Data**: Get market data, prices, and order book
- **Risk Management**: Built-in position sizing and risk controls

## Installation

```bash
pip install binance-trader
```

## Quick Start

```python
from binance_trader import BinanceTrader

# Initialize trader
trader = BinanceTrader(
    api_key='your_api_key',
    api_secret='your_api_secret',
    testnet=True  # Use testnet for testing
)

# Get account balance
balance = trader.get_balance()
print(balance)

# Place a spot order
order = trader.spot.buy(
    symbol='BTCUSDT',
    quantity=0.001,
    order_type='MARKET'
)
print(order)
```

## Configuration

### Using Environment Variables (Recommended)

```bash
export BINANCE_API_KEY='your_api_key'
export BINANCE_API_SECRET='your_api_secret'
```

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()  # Automatically loads from environment
```

### Using Config File

Create `~/.binance_trader/config.json`:

```json
{
    "api_key": "your_api_key",
    "api_secret": "your_api_secret",
    "testnet": true
}
```

## Usage Examples

### Spot Trading

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# Market buy
order = trader.spot.buy_market('BTCUSDT', quantity=0.001)

# Limit buy
order = trader.spot.buy_limit('BTCUSDT', quantity=0.001, price=50000)

# Sell
order = trader.spot.sell_market('BTCUSDT', quantity=0.001)

# Get open orders
orders = trader.spot.get_open_orders('BTCUSDT')

# Cancel order
trader.spot.cancel_order('BTCUSDT', order_id=123456)
```

### Futures Trading

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# Set leverage
trader.futures.set_leverage('BTCUSDT', leverage=10)

# Open long position
order = trader.futures.open_long('BTCUSDT', quantity=0.01)

# Open short position
order = trader.futures.open_short('BTCUSDT', quantity=0.01)

# Close position
order = trader.futures.close_position('BTCUSDT')

# Get position info
position = trader.futures.get_position('BTCUSDT')
```

### Order Management

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# Check specific order
order = trader.orders.get_order('BTCUSDT', order_id=123456)

# Get all open orders
orders = trader.orders.get_all_open_orders()

# Get order history
history = trader.orders.get_history('BTCUSDT', limit=100)

# Cancel all orders for a symbol
trader.orders.cancel_all('BTCUSDT')
```

### Market Data

```python
from binance_trader import BinanceTrader

trader = BinanceTrader()

# Get current price
price = trader.market.get_price('BTCUSDT')

# Get order book
depth = trader.market.get_order_book('BTCUSDT', limit=10)

# Get recent trades
trades = trader.market.get_recent_trades('BTCUSDT', limit=50)

# Get klines/candlestick data
klines = trader.market.get_klines('BTCUSDT', interval='1h', limit=100)
```

## Advanced Usage

### Risk Management

```python
from binance_trader import BinanceTrader
from binance_trader.risk import RiskManager

trader = BinanceTrader()
risk = RiskManager(trader)

# Calculate position size based on risk percentage
size = risk.calculate_position_size(
    symbol='BTCUSDT',
    risk_percent=2.0,  # Risk 2% of account
    stop_loss_percent=5.0  # 5% stop loss
)

# Place order with risk management
order = risk.place_order_with_stop_loss(
    symbol='BTCUSDT',
    side='BUY',
    risk_percent=2.0,
    stop_loss_percent=5.0
)
```

### WebSocket Streams (Real-time Data)

```python
from binance_trader import BinanceTrader
from binance_trader.stream import BinanceStream

trader = BinanceTrader()
stream = BinanceStream(trader)

# Subscribe to price updates
def on_price_update(data):
    print(f"Price update: {data}")

stream.subscribe_trade('BTCUSDT', on_price_update)
stream.start()
```

## API Reference

See [API Documentation](docs/api.md) for detailed API reference.

## Testing

Use Binance testnet for testing without real money:

```python
from binance_trader import BinanceTrader

trader = BinanceTrader(testnet=True)
# All operations use testnet funds
```

Get testnet API keys at: https://testnet.binance.vision/

## Requirements

- Python 3.8+
- requests
- websocket-client
- python-dotenv

## License

MIT License - see [LICENSE](LICENSE) file

## Disclaimer

This library is for educational purposes. Cryptocurrency trading involves significant risk. Use at your own risk.

## Support

- GitHub Issues: https://github.com/wuboyuan/binance-trader/issues
- Documentation: https://github.com/wuboyuan/binance-trader/wiki

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.
