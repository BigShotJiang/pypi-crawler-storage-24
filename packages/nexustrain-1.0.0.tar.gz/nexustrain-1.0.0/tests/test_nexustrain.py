"""
NexusTrain — Test Paketi
Author: Ömür Bera Işık
"""
import math
import pytest
import torch
import torch.nn as nn


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def tiny_model():
    """Hızlı test için küçük transformer benzeri model."""
    model = nn.Sequential(
        nn.Linear(64, 128),
        nn.ReLU(),
        nn.Linear(128, 64),
        nn.ReLU(),
        nn.Linear(64, 32),
    )
    return model


@pytest.fixture
def tiny_cfg():
    from nexustrain.config import NexusConfig
    return NexusConfig(
        power                   = 1.0,
        crystal_warmup_steps    = 2,
        crystal_min_freq        = 2,
        morph_history_len       = 8,
        spectra_history         = 8,
        warmup_steps            = 5,
        profiler_window         = 4,
        waste_detect_steps      = 2,
        precision_analysis_steps= 3,
        harmonic_noise          = 0.001,
        harmonic_compress       = 0.0,
        device                  = "cpu",
        dtype                   = "float32",
        verbose                 = False,
    )


# ── Config ────────────────────────────────────────────────────────────────────

class TestNexusConfig:
    def test_default_init(self):
        from nexustrain.config import NexusConfig
        cfg = NexusConfig()
        assert 0.0 <= cfg.power <= 1.0
        assert cfg.device in ("cpu", "cuda")
        assert cfg.dtype in ("float32", "float16", "bfloat16")

    def test_power_clamp(self):
        from nexustrain.config import NexusConfig
        cfg = NexusConfig(power=2.0)
        assert cfg.power == 1.0
        cfg2 = NexusConfig(power=-1.0)
        assert cfg2.power == 0.0

    def test_effective(self):
        from nexustrain.config import NexusConfig
        cfg = NexusConfig(power=0.5)
        assert cfg.effective(True)  == 0.5
        assert cfg.effective(False) == 0.0

    def test_torch_dtype(self):
        from nexustrain.config import NexusConfig
        cfg = NexusConfig(dtype="float32")
        assert cfg.torch_dtype == torch.float32

    def test_summary(self):
        from nexustrain.config import NexusConfig
        s = NexusConfig().summary()
        assert "NexusConfig" in s
        assert "CrystalCore" in s


# ── Errors ────────────────────────────────────────────────────────────────────

class TestNexusError:
    def setup_method(self):
        from nexustrain.errors import NexusError
        NexusError.clear()

    def test_report_does_not_raise(self):
        from nexustrain.errors import NexusError
        NexusError.report("TEST", "test hata", "test neden", "test çözüm")
        assert len(NexusError._registry) == 1

    def test_guard_catches_exception(self):
        from nexustrain.errors import NexusError
        with NexusError.guard("TEST_GUARD", "guard testi"):
            raise ValueError("test exception")
        assert len(NexusError._registry) == 1

    def test_fatal_raises(self):
        from nexustrain.errors import NexusError
        with pytest.raises(RuntimeError):
            NexusError.report("FATAL", "fatal test", "x", "y", fatal=True)

    def test_summary_empty(self, capsys):
        from nexustrain.errors import NexusError
        NexusError.summary()
        captured = capsys.readouterr()
        assert "Sıfır hata" in captured.out or True  # log'a gidiyor


# ── SpectraOptimizer ──────────────────────────────────────────────────────────

class TestSpectraOptimizer:
    def test_basic_step(self, tiny_model):
        from nexustrain.modules.spectra_optimizer import SpectraOptimizer
        opt = SpectraOptimizer(tiny_model.parameters(), lr=1e-3, power=1.0)
        x   = torch.randn(4, 64)
        out = tiny_model(x)
        loss= out.sum()
        loss.backward()
        opt.step()
        opt.zero_grad()

    def test_spectral_damping_zero(self, tiny_model):
        from nexustrain.modules.spectra_optimizer import SpectraOptimizer
        opt = SpectraOptimizer(tiny_model.parameters(), lr=1e-3,
                               spectral_damping=0.0, power=1.0)
        x = torch.randn(4, 64)
        tiny_model(x).sum().backward()
        opt.step()

    def test_multiple_steps(self, tiny_model):
        from nexustrain.modules.spectra_optimizer import SpectraOptimizer
        opt = SpectraOptimizer(tiny_model.parameters(), lr=1e-3,
                               history_len=8, power=1.0)
        for _ in range(15):
            opt.zero_grad()
            tiny_model(torch.randn(4, 64)).sum().backward()
            opt.step()
        assert opt._step_count == 15

    def test_weight_decay(self, tiny_model):
        from nexustrain.modules.spectra_optimizer import SpectraOptimizer
        params_before = [p.data.clone() for p in tiny_model.parameters()]
        opt = SpectraOptimizer(tiny_model.parameters(), lr=1e-3,
                               weight_decay=0.1, power=1.0)
        tiny_model(torch.randn(4, 64)).sum().backward()
        opt.step()
        changed = any(not torch.equal(p.data, pb)
                      for p, pb in zip(tiny_model.parameters(), params_before))
        assert changed


# ── ResonanceScheduler ────────────────────────────────────────────────────────

class TestResonanceScheduler:
    def test_warmup_phase(self, tiny_model, tiny_cfg):
        from nexustrain.modules.spectra_optimizer import SpectraOptimizer
        from nexustrain.modules.resonance_scheduler import ResonanceScheduler, TrainingPhase
        opt   = SpectraOptimizer(tiny_model.parameters(), lr=1e-3)
        sched = ResonanceScheduler(opt, tiny_cfg)
        sched.step(1.0, 0.5)
        assert sched.current_phase == TrainingPhase.WARMUP

    def test_lr_increases_during_warmup(self, tiny_model, tiny_cfg):
        from nexustrain.modules.spectra_optimizer import SpectraOptimizer
        from nexustrain.modules.resonance_scheduler import ResonanceScheduler
        opt   = SpectraOptimizer(tiny_model.parameters(), lr=tiny_cfg.base_lr)
        sched = ResonanceScheduler(opt, tiny_cfg)
        lrs   = []
        for i in range(tiny_cfg.warmup_steps):
            sched.step(1.0 - i*0.01, 0.5)
            lrs.append(sched.current_lr)
        assert lrs[-1] > lrs[0]

    def test_unstable_detection(self, tiny_model, tiny_cfg):
        from nexustrain.modules.spectra_optimizer import SpectraOptimizer
        from nexustrain.modules.resonance_scheduler import ResonanceScheduler, TrainingPhase
        tiny_cfg.warmup_steps = 1
        opt   = SpectraOptimizer(tiny_model.parameters(), lr=1e-3)
        sched = ResonanceScheduler(opt, tiny_cfg)
        for i in range(10):
            sched.step(1.0, 0.1)
        lr_before = sched.current_lr
        sched.step(1.0, 100.0)  # ani gradient patlaması
        assert sched.current_phase == TrainingPhase.UNSTABLE
        assert sched.current_lr <= lr_before


# ── GradientHarmonics ─────────────────────────────────────────────────────────

class TestGradientHarmonics:
    def test_process_preserves_shape(self, tiny_cfg):
        from nexustrain.modules.gradient_harmonics import GradientHarmonics
        gh   = GradientHarmonics(tiny_cfg)
        grad = torch.randn(64, 128)
        out  = gh.process(grad, "test.weight")
        assert out.shape == grad.shape

    def test_process_preserves_dtype(self, tiny_cfg):
        from nexustrain.modules.gradient_harmonics import GradientHarmonics
        gh   = GradientHarmonics(tiny_cfg)
        grad = torch.randn(32, 64, dtype=torch.float32)
        out  = gh.process(grad)
        assert out.dtype == grad.dtype

    def test_small_tensor_passthrough(self, tiny_cfg):
        from nexustrain.modules.gradient_harmonics import GradientHarmonics
        gh   = GradientHarmonics(tiny_cfg)
        grad = torch.randn(4)  # < 8 eleman
        out  = gh.process(grad)
        assert torch.equal(out, grad)

    def test_register_hooks(self, tiny_model, tiny_cfg):
        from nexustrain.modules.gradient_harmonics import GradientHarmonics
        gh    = GradientHarmonics(tiny_cfg)
        hooks = gh.register_hooks(tiny_model)
        assert len(hooks) > 0
        for h in hooks: h.remove()

    def test_compression(self, tiny_cfg):
        from nexustrain.modules.gradient_harmonics import GradientHarmonics
        tiny_cfg.harmonic_compress = 0.5
        gh   = GradientHarmonics(tiny_cfg)
        grad = torch.randn(128)
        out  = gh.process(grad)
        assert out.shape == grad.shape


# ── MorphicMemory ─────────────────────────────────────────────────────────────

class TestMorphicMemory:
    def test_allocate(self, tiny_cfg):
        from nexustrain.modules.morphic_memory import MorphicMemory
        mm = MorphicMemory(tiny_cfg, torch.device("cpu"))
        t  = mm.allocate((16, 32), torch.float32)
        assert t.shape == (16, 32)
        assert t.dtype == torch.float32

    def test_reincarnation(self, tiny_cfg):
        from nexustrain.modules.morphic_memory import MorphicMemory
        mm = MorphicMemory(tiny_cfg, torch.device("cpu"))
        t1 = mm.allocate((64,), torch.float32)
        mm.free(t1)
        t2 = mm.allocate((64,), torch.float32)
        assert t2.shape == (64,)

    def test_markov_prediction(self, tiny_cfg):
        from nexustrain.modules.morphic_memory import MarkovMemoryPredictor
        pred = MarkovMemoryPredictor(history_len=16, order=2)
        for _ in range(10):
            pred.observe(1024)
            pred.observe(2048)
        result = pred.predict_next()
        assert result is not None


# ── CrystalCore ───────────────────────────────────────────────────────────────

class TestCrystalCore:
    def test_wrap_function(self, tiny_cfg):
        from nexustrain.modules.crystal_core import CrystalCore
        cc   = CrystalCore(tiny_cfg)
        called = {"n": 0}
        def my_fn(x): called["n"] += 1; return x * 2
        wrapped = cc.wrap(my_fn)
        for _ in range(5):
            cc.step()
            wrapped(torch.randn(4))
        assert called["n"] == 5

    def test_inject_model(self, tiny_model, tiny_cfg):
        from nexustrain.modules.crystal_core import CrystalCore
        cc = CrystalCore(tiny_cfg)
        cc.inject_model(tiny_model)
        # model hâlâ çalışıyor olmalı
        out = tiny_model(torch.randn(2, 64))
        assert out.shape == (2, 32)


# ── NexusTrain entegrasyon testi ──────────────────────────────────────────────

class TestNexusTrainIntegration:
    def test_init_cpu(self, tiny_model, tiny_cfg):
        from nexustrain.core import NexusTrain
        nt = NexusTrain(tiny_model, cfg=tiny_cfg)
        assert nt.model is tiny_model

    def test_engage(self, tiny_model, tiny_cfg):
        from nexustrain.core import NexusTrain
        nt = NexusTrain(tiny_model, cfg=tiny_cfg)
        result = nt.engage()
        assert result is nt
        assert nt._engaged

    def test_manual_step(self, tiny_model, tiny_cfg):
        from nexustrain.core import NexusTrain
        nt = NexusTrain(tiny_model, cfg=tiny_cfg)
        nt.engage()
        nt._on_step_begin(0)
        x = torch.randn(2, 64)
        tiny_model(x).sum().backward()
        nt._on_step_end(0, 1.23)
        assert len(nt._step_times) == 1

    def test_cleanup(self, tiny_model, tiny_cfg):
        from nexustrain.core import NexusTrain
        nt = NexusTrain(tiny_model, cfg=tiny_cfg)
        nt.engage()
        nt.cleanup()  # hata fırlatmamalı

    def test_repr(self, tiny_model, tiny_cfg):
        from nexustrain.core import NexusTrain
        nt   = NexusTrain(tiny_model, cfg=tiny_cfg)
        repr_str = repr(nt)
        assert "NexusTrain" in repr_str
        assert "Ömür Bera Işık" in repr_str

    def test_power_zero_disables_all(self, tiny_model):
        from nexustrain.core import NexusTrain
        from nexustrain.config import NexusConfig
        cfg = NexusConfig(power=0.0, device="cpu", dtype="float32")
        nt  = NexusTrain(tiny_model, cfg=cfg)
        assert nt.crystal_core     is None
        assert nt.morphic_memory   is None
        assert nt.spectra_opt      is None
        assert nt.resonance_sched  is None
        assert nt.grad_harmonics   is None

    def test_async_checkpoint(self, tiny_model, tiny_cfg, tmp_path):
        from nexustrain.core import NexusTrain
        tiny_cfg.checkpoint_dir = str(tmp_path)
        nt = NexusTrain(tiny_model, cfg=tiny_cfg)
        nt.engage()
        nt.async_checkpoint()
        import time; time.sleep(0.5)  # async thread'in yazmasını bekle


# ── nexus_wrap yardımcısı ─────────────────────────────────────────────────────

class TestNexusWrap:
    def test_wrap_returns_tuple(self, tiny_model):
        from nexustrain.utils import nexus_wrap
        nt, model = nexus_wrap(tiny_model, power=0.5,
                               device="cpu", dtype="float32")
        from nexustrain.core import NexusTrain
        assert isinstance(nt, NexusTrain)
        assert model is tiny_model

    def test_wrap_power(self, tiny_model):
        from nexustrain.utils import nexus_wrap
        nt, _ = nexus_wrap(tiny_model, power=0.3,
                           device="cpu", dtype="float32")
        assert nt.cfg.power == pytest.approx(0.3)
