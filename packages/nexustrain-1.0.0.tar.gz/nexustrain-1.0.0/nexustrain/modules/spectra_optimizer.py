"""
NexusTrain — SpectraOptimizer™ Modülü
Frekans Alanında Çalışan Optimizer
Author: Ömür Bera Işık
"""
from __future__ import annotations

import math
import logging
from typing import List, Tuple

import torch
from torch.optim import Optimizer

log = logging.getLogger("NexusTrain")


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def _to_float(x: torch.Tensor) -> float:
    return x.detach().float().mean().item()


def _fft_spectrum(signal: List[float]) -> List[float]:
    """Numpy yoksa saf Python DFT kullanır — sıfır bağımlılık."""
    n = len(signal)
    if n == 0: return []
    try:
        import numpy as np
        return list(abs(np.fft.fft(signal)[:n // 2]))
    except ImportError:
        result = []
        for k in range(n // 2):
            re = sum(signal[t] * math.cos(2 * math.pi * k * t / n) for t in range(n))
            im = sum(signal[t] * math.sin(2 * math.pi * k * t / n) for t in range(n))
            result.append(math.sqrt(re * re + im * im))
        return result


class SpectraOptimizer(Optimizer):
    """
    SpectraOptimizer™ — Frekans Alanı Farkındalıklı Optimizer

    AdamW üzerine iki spektral katman:
    1. Gradient geçmişine FFT — rezonant frekansları söndürür.
    2. Per-parameter spektral LR ölçekleme.
    """

    def __init__(self, params, lr: float = 2e-4,
                 betas: Tuple[float, float] = (0.9, 0.999),
                 eps: float = 1e-8,
                 weight_decay: float = 0.01,
                 spectral_damping: float = 0.1,
                 history_len: int = 64,
                 power: float = 1.0):
        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay,
                        spectral_damping=spectral_damping,
                        history_len=history_len, power=power)
        super().__init__(params, defaults)
        self._step_count = 0
        log.info(f"SpectraOpt   : 🎵  lr={lr:.2e}, spectral_damping={spectral_damping}")

    @torch.no_grad()
    def step(self, closure=None):
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            beta1, beta2 = group["betas"]
            eps   = group["eps"]
            lr    = group["lr"]
            wd    = group["weight_decay"]
            sdamp = group["spectral_damping"] * group["power"]
            hlen  = group["history_len"]

            for p in group["params"]:
                if p.grad is None: continue
                grad = p.grad
                if grad.is_sparse: continue

                state = self.state[p]
                if len(state) == 0:
                    state["step"]         = 0
                    state["exp_avg"]      = torch.zeros_like(p)
                    state["exp_avg_sq"]   = torch.zeros_like(p)
                    state["grad_history"] = []

                state["step"]   += 1
                exp_avg         = state["exp_avg"]
                exp_avg_sq      = state["exp_avg_sq"]

                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

                bias_c1   = 1 - beta1 ** state["step"]
                bias_c2   = 1 - beta2 ** state["step"]
                step_size = lr * math.sqrt(bias_c2) / bias_c1
                denom     = exp_avg_sq.sqrt().add_(eps)

                # Spektral Momentum Düzeltmesi
                if sdamp > 0 and state["step"] > 10:
                    try:
                        state["grad_history"].append(_to_float(grad))
                        if len(state["grad_history"]) > hlen:
                            state["grad_history"].pop(0)
                        if len(state["grad_history"]) >= 8:
                            spectrum = _fft_spectrum(state["grad_history"])
                            if spectrum:
                                dominant     = spectrum.index(max(spectrum))
                                freq_ratio   = dominant / len(spectrum)
                                spectral_scale = _clamp(1.0 - sdamp * freq_ratio, 0.1, 1.0)
                                p.addcdiv_(exp_avg * spectral_scale, denom, value=-step_size)
                            else:
                                p.addcdiv_(exp_avg, denom, value=-step_size)
                        else:
                            p.addcdiv_(exp_avg, denom, value=-step_size)
                    except Exception:
                        p.addcdiv_(exp_avg, denom, value=-step_size)
                else:
                    p.addcdiv_(exp_avg, denom, value=-step_size)

                if wd != 0:
                    p.mul_(1 - lr * wd)

        self._step_count += 1
        return loss
