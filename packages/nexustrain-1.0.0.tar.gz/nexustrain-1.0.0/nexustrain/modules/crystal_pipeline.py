"""
NexusTrain — CrystalPipeline™
Öz-Yeniden-Yapılandıran Eğitim Boru Hattı
Author: Ömür Bera Işık
"""
from __future__ import annotations
import logging, math, os, queue, random, threading
from typing import Dict, List, Optional
import torch
import torch.nn as nn
from nexustrain.errors import NexusError

log = logging.getLogger("NexusTrain")


class CrystalPipeline:
    """
    CrystalPipeline™ — 3 özellik:
    1. Dinamik gradient accumulation (VRAM durumuna göre)
    2. Lookahead pipeline planlama
    3. Async checkpoint (eğitim durmadan)
    """
    def __init__(self, cfg):
        self.cfg          = cfg
        self._grad_accum  = 1
        self._ckpt_q      = queue.Queue()
        self._ckpt_thread = threading.Thread(
            target=self._checkpoint_worker, daemon=True)
        self._ckpt_thread.start()
        self._step = 0
        log.info(f"CrystalPipeline: 🔮  lookahead={cfg.pipeline_lookahead}, "
                 f"max_grad_accum={cfg.max_grad_accum}")

    def adapt_grad_accum(self, vram_used_pct: float, loss_stability: float) -> int:
        if not self.cfg.dynamic_grad_accum: return self._grad_accum
        if vram_used_pct > 0.9:
            self._grad_accum = max(1, self._grad_accum - 1)
        elif vram_used_pct < 0.6 and loss_stability > 0.7:
            self._grad_accum = min(self.cfg.max_grad_accum, self._grad_accum + 1)
        return self._grad_accum

    def plan_next_steps(self, current_step: int, step_times: List[float]) -> Dict:
        n = self.cfg.pipeline_lookahead
        if len(step_times) < 2: return {"lookahead": n, "actions": []}
        avg_ms = sum(step_times[-min(8, len(step_times)):]) / min(8, len(step_times))
        std_ms = math.sqrt(sum((t-avg_ms)**2 for t in step_times[-4:])/4 + 1e-6)
        actions = []
        for i in range(1, n+1):
            est = avg_ms + random.gauss(0, std_ms * 0.1)
            action = {"step": current_step + i, "est_ms": est}
            if est > avg_ms * 1.5: action["preempt"] = "prefetch_gc"
            actions.append(action)
        return {"lookahead": n, "actions": actions}

    def queue_checkpoint(self, model: nn.Module, path: str, step: int):
        state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
        self._ckpt_q.put({"state": state, "path": path, "step": step})
        log.info(f"CrystalPipeline: 🔮  Checkpoint kuyruğa eklendi (step={step})")

    def _checkpoint_worker(self):
        while True:
            try:
                item = self._ckpt_q.get(timeout=1)
                if item is None: break
                os.makedirs(os.path.dirname(item["path"]) or ".", exist_ok=True)
                torch.save(item["state"], item["path"])
                log.info(f"CrystalPipeline: 💾  Checkpoint → {item['path']}")
            except queue.Empty: continue
            except Exception as e:
                NexusError.report("CKPT_FAIL", "Async checkpoint başarısız",
                                  str(e), "Manuel kaydetme deneyin", exc=e)

    def step(self): self._step += 1

    def report(self):
        log.info(f"CrystalPipeline: 🔮  grad_accum={self._grad_accum}, "
                 f"kuyruk={self._ckpt_q.qsize()}")
