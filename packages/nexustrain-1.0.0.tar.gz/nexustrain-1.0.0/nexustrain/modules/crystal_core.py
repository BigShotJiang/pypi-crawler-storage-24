"""
NexusTrain — CrystalCore™ Modülü
Runtime Kernel Kristalizasyon Motoru
Author: Ömür Bera Işık
"""
from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
from functools import wraps
from typing import Callable, Dict, List, Optional, Tuple

import torch
import torch.nn as nn

from nexustrain.errors import NexusError

log = logging.getLogger("NexusTrain")
_HAS_COMPILE = tuple(int(x) for x in torch.__version__.split(".")[:2]) >= (2, 0)


class OperationSignature:
    __slots__ = ("_hash", "ops", "shapes", "dtype")

    def __init__(self, ops: List[str], shapes: List[Tuple], dtype: str):
        self.ops = ops; self.shapes = shapes; self.dtype = dtype
        raw = json.dumps({"ops": ops, "shapes": shapes, "dtype": dtype}, sort_keys=True)
        self._hash = hashlib.md5(raw.encode()).hexdigest()[:12]

    def __hash__(self): return hash(self._hash)
    def __eq__(self, o): return isinstance(o, OperationSignature) and self._hash == o._hash
    def __repr__(self): return f"OpSig({self._hash})"


class CrystalKernel:
    def __init__(self, sig: OperationSignature, fn: Callable, compile_mode: str, min_freq: int):
        self.sig        = sig
        self._fn        = fn
        self._mode      = compile_mode
        self._min_freq  = min_freq
        self.call_count = 0
        self.total_ms   = 0.0
        self._compiled  = None
        self._crystallized = False

    def __call__(self, *args, **kwargs):
        if self._crystallized and self._compiled is not None:
            return self._compiled(*args, **kwargs)
        t0 = time.perf_counter()
        result = self._fn(*args, **kwargs)
        self.total_ms  += (time.perf_counter() - t0) * 1000
        self.call_count += 1
        if self.call_count >= self._min_freq and not self._crystallized and _HAS_COMPILE:
            self._crystallize()
        return result

    def _crystallize(self):
        try:
            self._compiled     = torch.compile(self._fn, mode=self._mode, fullgraph=False)
            self._crystallized = True
            log.info(f"CrystalCore  : 💎  {self.sig} kristalize "
                     f"(ort.{self.total_ms/max(self.call_count,1):.1f}ms, {self.call_count}x)")
        except Exception as e:
            NexusError.report("CRYSTAL_FAIL", f"Kristalizasyon başarısız: {self.sig}",
                              str(e), "Ham fonksiyon kullanılıyor", exc=e)

    @property
    def avg_ms(self) -> float:
        return self.total_ms / max(self.call_count, 1)


class CrystalCore:
    """
    CrystalCore™ — Runtime Kernel Kristalizasyon Motoru

    Sık çalışan operasyonları otomatik olarak torch.compile ile
    kristalize eder. Warmup sonrası 2x–5x hız kazanımı sağlar.
    """

    def __init__(self, cfg):
        self.cfg    = cfg
        self._store: Dict[OperationSignature, CrystalKernel] = {}
        self._step  = 0
        self._lock  = threading.Lock()
        self._stats = dict(crystallized=0, calls=0, evaporized=0)
        log.info(f"CrystalCore  : 💎  warmup={cfg.crystal_warmup_steps}, "
                 f"min_freq={cfg.crystal_min_freq}")

    def register(self, fn: Callable, ops: List[str],
                 shapes: List[Tuple], dtype: str) -> CrystalKernel:
        sig = OperationSignature(ops, shapes, dtype)
        with self._lock:
            if sig not in self._store:
                if len(self._store) >= self.cfg.crystal_max_kernels:
                    self._evaporate_lru()
                self._store[sig] = CrystalKernel(
                    sig, fn, self.cfg.compile_mode, self.cfg.crystal_min_freq)
                self._stats["crystallized"] += 1
        return self._store[sig]

    def step(self): self._step += 1

    def _evaporate_lru(self):
        if not self._store: return
        lru = min(self._store, key=lambda s: self._store[s].call_count)
        del self._store[lru]
        self._stats["evaporized"] += 1

    def wrap(self, fn: Callable) -> Callable:
        @wraps(fn)
        def _wrapper(*args, **kwargs):
            if self._step < self.cfg.crystal_warmup_steps:
                return fn(*args, **kwargs)
            shapes = [tuple(a.shape) for a in args if isinstance(a, torch.Tensor)]
            dtype  = str(args[0].dtype) if args and isinstance(args[0], torch.Tensor) else "?"
            kernel = self.register(fn, [fn.__name__], shapes, dtype)
            self._stats["calls"] += 1
            return kernel(*args, **kwargs)
        return _wrapper

    def inject_model(self, model: nn.Module) -> nn.Module:
        patched = 0
        for _, module in model.named_modules():
            if isinstance(module, (nn.Linear, nn.Embedding)):
                try:
                    module.forward = self.wrap(module.forward)
                    patched += 1
                except Exception:
                    pass
        log.info(f"CrystalCore  : 💎  {patched} modül bağlandı")
        return model

    def report(self):
        total        = len(self._store)
        crystallized = sum(1 for k in self._store.values() if k._crystallized)
        log.info(f"CrystalCore  : {crystallized}/{total} kernel kristalize, "
                 f"{self._stats['calls']} çağrı")
