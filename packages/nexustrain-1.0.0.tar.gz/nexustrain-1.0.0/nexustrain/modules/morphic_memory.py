"""
NexusTrain — MorphicMemory™ Modülü
Markov Zinciri Tabanlı Tahminli Bellek Morfizm Sistemi
Author: Ömür Bera Işık
"""
from __future__ import annotations

import gc
import logging
import math
from typing import Dict, List, Optional, Tuple

import torch

from nexustrain.errors import NexusError

log = logging.getLogger("NexusTrain")


def _mem_gb(device=None) -> Tuple[float, float]:
    if not torch.cuda.is_available(): return 0.0, 0.0
    d = device or torch.device("cuda")
    return (torch.cuda.memory_allocated(d) / 1e9,
            torch.cuda.get_device_properties(d).total_memory / 1e9)


class TensorReincarnator:
    """Ölü tensor'ları şekil değiştirerek yeniden doğurur."""

    def __init__(self, max_pool: int = 512):
        self._pool: List[torch.Tensor] = []
        self._max  = max_pool
        self._stats = dict(reincarnated=0, fresh=0, saved_bytes=0)

    def acquire(self, shape: Tuple, dtype: torch.dtype, device: torch.device) -> torch.Tensor:
        numel = 1
        for s in shape: numel *= s

        best_idx, best_diff = -1, float("inf")
        for i, t in enumerate(self._pool):
            if t.dtype == dtype and t.device == device:
                diff = abs(t.numel() - numel)
                if diff < best_diff and diff < numel * 0.1:
                    best_diff = diff; best_idx = i

        if best_idx >= 0:
            t = self._pool.pop(best_idx)
            self._stats["reincarnated"] += 1
            self._stats["saved_bytes"]  += t.numel() * t.element_size()
            flat = t.flatten()
            if flat.numel() >= numel:
                return flat[:numel].reshape(shape).zero_()

        self._stats["fresh"] += 1
        return torch.empty(shape, dtype=dtype, device=device)

    def release(self, t: torch.Tensor):
        if len(self._pool) < self._max:
            self._pool.append(t.detach())

    def report(self):
        saved_mb = self._stats["saved_bytes"] / 1e6
        total    = self._stats["reincarnated"] + self._stats["fresh"]
        rate     = self._stats["reincarnated"] / max(total, 1) * 100
        log.info(f"Reincarnator : ♻️   {self._stats['reincarnated']} yeniden doğuş, "
                 f"%{rate:.0f} kazanım, {saved_mb:.1f}MB tasarruf")


class MarkovMemoryPredictor:
    """Markov zinciri ile bir sonraki allocation'ı tahmin eder."""

    def __init__(self, history_len: int = 128, order: int = 2):
        self.order       = order
        self.history_len = history_len
        self._history: List[int] = []
        self._transitions: Dict[Tuple, Dict[int, int]] = {}
        self._stats = dict(prefetched=0)

    def observe(self, size_bytes: int):
        self._history.append(size_bytes)
        if len(self._history) > self.history_len:
            self._history.pop(0)
        if len(self._history) >= self.order + 1:
            state = tuple(self._history[-self.order - 1:-1])
            nxt   = self._history[-1]
            if state not in self._transitions:
                self._transitions[state] = {}
            self._transitions[state][nxt] = self._transitions[state].get(nxt, 0) + 1

    def predict_next(self) -> Optional[int]:
        if len(self._history) < self.order: return None
        state = tuple(self._history[-self.order:])
        if state not in self._transitions: return None
        return max(self._transitions[state], key=self._transitions[state].get)

    def prefetch(self, device: torch.device, dtype: torch.dtype):
        size = self.predict_next()
        if size is None: return
        elem_size = torch.tensor([], dtype=dtype).element_size()
        numel = max(1, size // elem_size)
        try:
            torch.empty(numel, dtype=dtype, device=device)
            self._stats["prefetched"] += 1
        except Exception:
            pass

    def report(self):
        log.info(f"MarkovPredict: 🔮  {self._stats['prefetched']} ön-tahsis yapıldı")


class MorphicMemory:
    """
    MorphicMemory™ — Uyarlanabilir Bellek Morfizm Sistemi

    Markov zinciri tahmini + tensor reincarnation + OOM öncesi otomatik GC.
    """

    def __init__(self, cfg, device: torch.device):
        self.cfg          = cfg
        self.device       = device
        self.predictor    = MarkovMemoryPredictor(cfg.morph_history_len)
        self.reincarnator = TensorReincarnator() if cfg.tensor_reincarnation else None
        self._pressure_threshold = 0.85
        self._gc_count    = 0
        self._step        = 0
        log.info(f"MorphicMemory: 🧬  havuz={cfg.morph_pool_gb:.1f}GB, "
                 f"Markov geçmişi={cfg.morph_history_len}")

    def allocate(self, shape: Tuple, dtype: torch.dtype) -> torch.Tensor:
        elem_size = torch.tensor([], dtype=dtype).element_size()
        nbytes = elem_size
        for s in shape: nbytes *= s
        self.predictor.observe(nbytes)
        self._check_pressure()
        if self.reincarnator:
            return self.reincarnator.acquire(shape, dtype, self.device)
        return torch.empty(shape, dtype=dtype, device=self.device)

    def free(self, t: torch.Tensor):
        if self.reincarnator:
            self.reincarnator.release(t)

    def _check_pressure(self):
        used, total = _mem_gb(self.device)
        if total > 0 and used / total > self._pressure_threshold:
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
            self._gc_count += 1

    def step(self):
        self._step += 1
        if self._step % 10 == 0:
            dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
            self.predictor.prefetch(self.device, dtype)

    def report(self):
        used, total = _mem_gb(self.device)
        log.info(f"MorphicMemory: 🧬  VRAM {used:.1f}/{total:.1f}GB, "
                 f"{self._gc_count} otomatik GC")
        self.predictor.report()
        if self.reincarnator:
            self.reincarnator.report()
