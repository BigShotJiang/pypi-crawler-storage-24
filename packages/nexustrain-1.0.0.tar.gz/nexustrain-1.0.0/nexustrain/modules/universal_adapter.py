"""
NexusTrain — UniversalAdapter™
Framework-Agnostic Evrensel Uyumluluk Katmanı
Author: Ömür Bera Işık
"""
from nexustrain.modules.zero_waste_adapter import FrameworkDetector, UniversalAdapter
__all__ = ["FrameworkDetector", "UniversalAdapter"]
