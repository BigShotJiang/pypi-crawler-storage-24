"""
NexusTrain — CLI
nexustrain-check komutu için giriş noktası
Author: Ömür Bera Işık
"""


def check_environment():
    """pip install nexustrain sonra terminalde: nexustrain-check"""
    from nexustrain.utils import nexus_check
    nexus_check()


if __name__ == "__main__":
    check_environment()
