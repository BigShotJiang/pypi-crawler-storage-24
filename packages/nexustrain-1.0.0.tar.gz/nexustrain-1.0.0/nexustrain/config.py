"""
NexusTrain — Yapılandırma Modülü
Author: Ömür Bera Işık
"""
from __future__ import annotations

import torch
from dataclasses import dataclass, field
from typing import List

_HAS_BF16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


@dataclass
class NexusConfig:
    """
    NexusTrain yapılandırması.

    Her özellik True/False ile açılır/kapatılır.
    power=0.0 → tüm modüller pasif, power=1.0 → tam kapasite.

    Örnek:
        cfg = NexusConfig(power=1.0)                    # hepsi açık
        cfg = NexusConfig(power=1.0, crystal_core=False) # sadece CrystalCore kapalı
    """

    # ── Global ────────────────────────────────────────────────────────────────
    power: float = 1.0
    """0.0 – 1.0 arası global güç çarpanı. Tüm modülleri etkiler."""

    # ── CrystalCore™ ──────────────────────────────────────────────────────────
    crystal_core: bool          = True
    crystal_warmup_steps: int   = 50
    crystal_min_freq: int       = 5
    crystal_max_kernels: int    = 32
    compile_mode: str           = "reduce-overhead"

    # ── MorphicMemory™ ────────────────────────────────────────────────────────
    morphic_memory: bool        = True
    morph_pool_gb: float        = 1.0
    morph_history_len: int      = 128
    tensor_reincarnation: bool  = True

    # ── SpectraOptimizer™ ─────────────────────────────────────────────────────
    spectra_optimizer: bool     = True
    spectra_beta1: float        = 0.9
    spectra_beta2: float        = 0.999
    spectra_eps: float          = 1e-8
    spectra_weight_decay: float = 0.01
    spectral_damping: float     = 0.1
    spectra_history: int        = 64

    # ── ResonanceScheduler™ ───────────────────────────────────────────────────
    resonance_scheduler: bool       = True
    base_lr: float                  = 2e-4
    min_lr: float                   = 1e-6
    resonance_sensitivity: float    = 0.5
    warmup_steps: int               = 100

    # ── ChromaticPrecision™ ───────────────────────────────────────────────────
    chromatic_precision: bool           = True
    precision_analysis_steps: int       = 30
    force_fp32_layers: List[str]        = field(
        default_factory=lambda: ["lm_head", "embed"])

    # ── GradientHarmonics™ ────────────────────────────────────────────────────
    gradient_harmonics: bool    = True
    harmonic_levels: int        = 3
    harmonic_noise: float       = 0.001
    harmonic_compress: float    = 0.0

    # ── NeuralProfiler™ ───────────────────────────────────────────────────────
    neural_profiler: bool       = True
    profiler_window: int        = 32
    profiler_alert_ms: float    = 500.0

    # ── CrystalPipeline™ ──────────────────────────────────────────────────────
    crystal_pipeline: bool      = True
    pipeline_lookahead: int     = 4
    dynamic_grad_accum: bool    = True
    max_grad_accum: int         = 16

    # ── ZeroWaste™ ────────────────────────────────────────────────────────────
    zero_waste: bool            = True
    waste_detect_steps: int     = 20

    # ── UniversalAdapter™ ─────────────────────────────────────────────────────
    auto_detect_framework: bool = True
    patch_attention: bool       = True
    patch_norm: bool            = True

    # ── Genel ─────────────────────────────────────────────────────────────────
    device: str                 = "auto"
    dtype: str                  = "auto"
    seed: int                   = 42
    verbose: bool               = True
    checkpoint_dir: str         = "./nexus_checkpoints"
    telemetry_file: str         = "./nexus_telemetry.jsonl"

    # ── Eğitim parametreleri (trainer'sız kullanım için) ──────────────────────
    learning_rate: float              = 2e-4
    num_train_epochs: int             = 3
    max_steps: int                    = -1
    per_device_train_batch_size: int  = 2
    gradient_accumulation_steps: int  = 4
    max_seq_length: int               = 2048
    weight_decay: float               = 0.01
    max_grad_norm: float              = 1.0
    warmup_ratio: float               = 0.03
    lr_scheduler_type: str            = "cosine"
    logging_steps: int                = 10
    save_steps: int                   = 200
    output_dir: str                   = "./nexus_output"
    dataloader_num_workers: int       = 0
    save_total_limit: int             = 3

    def effective(self, feature_enabled: bool) -> float:
        return self.power if feature_enabled else 0.0

    def __post_init__(self):
        self.power = _clamp(self.power, 0.0, 1.0)
        if self.device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        if self.dtype == "auto":
            if torch.cuda.is_available():
                self.dtype = "bfloat16" if _HAS_BF16 else "float16"
            else:
                self.dtype = "float32"

    @property
    def torch_dtype(self) -> torch.dtype:
        return {
            "bfloat16": torch.bfloat16,
            "float16":  torch.float16,
            "float32":  torch.float32,
        }.get(self.dtype, torch.float32)

    def summary(self) -> str:
        lines = [f"\n  NexusConfig (power={self.power:.0%}):"]
        modules = [
            ("CrystalCore™",        self.crystal_core),
            ("MorphicMemory™",      self.morphic_memory),
            ("SpectraOptimizer™",   self.spectra_optimizer),
            ("ResonanceScheduler™", self.resonance_scheduler),
            ("ChromaticPrecision™", self.chromatic_precision),
            ("GradientHarmonics™",  self.gradient_harmonics),
            ("NeuralProfiler™",     self.neural_profiler),
            ("CrystalPipeline™",    self.crystal_pipeline),
            ("ZeroWaste™",          self.zero_waste),
            ("UniversalAdapter™",   self.auto_detect_framework),
        ]
        for name, enabled in modules:
            sym = "✅" if enabled and self.power > 0 else "⬜"
            lines.append(f"    {sym}  {name}")
        return "\n".join(lines)
