"""
NexusTrain — Yardımcı Fonksiyonlar
Author: Ömür Bera Işık
"""
from __future__ import annotations
import torch
from typing import Optional, Tuple
from nexustrain.config import NexusConfig


def nexus_wrap(model, tokenizer=None,
               power: float = 1.0, **kwargs) -> Tuple:
    """
    Tek satır NexusTrain kurulumu.

        nt, model = nexus_wrap(model, tokenizer, power=1.0)
        trainer   = nt.patch_trainer(trainer)
        nt.engage()
    """
    from nexustrain.core import NexusTrain
    cfg = NexusConfig(power=power, **kwargs)
    nt  = NexusTrain(model, tokenizer, cfg)
    return nt, model


def nexus_check():
    """Ortam kontrolü — tüm bağımlılıklar ve donanım."""
    from nexustrain.modules.zero_waste_adapter import FrameworkDetector, _HAS_BF16, _HAS_SDPA
    try: import flash_attn; _flash = True
    except: _flash = False
    try: import triton; _triton = True
    except: _triton = False

    env = FrameworkDetector.detect()
    _TORCH_VER = tuple(int(x) for x in torch.__version__.split(".")[:2])

    print("\n[NexusTrain v1.0] Ortam Kontrolü — Ömür Bera Işık")
    print("─"*52)
    print(f"PyTorch       : {torch.__version__}")
    print(f"CUDA          : {'✅ ' + str(torch.version.cuda) if torch.cuda.is_available() else '✗'}")
    print(f"torch.compile : {'✅' if _TORCH_VER >= (2,0) else '✗ (2.0+ gerekli)'}")
    print(f"BF16          : {'✅' if _HAS_BF16 else '✗'}")
    print(f"SDPA          : {'✅' if _HAS_SDPA else '✗'}")
    print(f"Flash Attn    : {'✅' if _flash else '✗'}")
    print(f"Triton        : {'✅' if _triton else '✗'}")
    if "gpu_name" in env:
        print(f"\nGPU           : {env['gpu_name']}")
        print(f"VRAM          : {env.get('vram_gb',0):.1f} GB")
    print()
    pkgs = ["transformers","peft","trl","bitsandbytes","accelerate","deepspeed","optuna","wandb"]
    print("Paketler:")
    for pkg in pkgs:
        try:
            import importlib.metadata
            ver = importlib.metadata.version(pkg)
            print(f"  ✅  {pkg:<18} {ver}")
        except Exception:
            print(f"  ✗   {pkg}")
    print()
