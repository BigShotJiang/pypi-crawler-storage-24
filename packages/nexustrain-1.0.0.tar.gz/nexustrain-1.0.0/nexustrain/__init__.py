"""
NexusTrain — The World's First Self-Crystallizing Neural Training Engine
========================================================================
Author  : Ömür Bera Işık
License : MIT
Version : 1.0.0

pip install nexustrain
pip install nexustrain[full]      # + HuggingFace ekosistemi
pip install nexustrain[all]       # her şey
"""

from nexustrain.config import NexusConfig
from nexustrain.core import NexusTrain
from nexustrain.modules.crystal_core import CrystalCore
from nexustrain.modules.morphic_memory import MorphicMemory
from nexustrain.modules.spectra_optimizer import SpectraOptimizer
from nexustrain.modules.resonance_scheduler import ResonanceScheduler, TrainingPhase
from nexustrain.modules.chromatic_precision import ChromaticPrecision
from nexustrain.modules.gradient_harmonics import GradientHarmonics
from nexustrain.modules.neural_profiler import NeuralProfiler
from nexustrain.modules.crystal_pipeline import CrystalPipeline
from nexustrain.modules.zero_waste import ZeroWaste
from nexustrain.modules.universal_adapter import UniversalAdapter
from nexustrain.utils import nexus_wrap, nexus_check

__version__ = "1.0.0"
__author__  = "Ömür Bera Işık"
__license__ = "MIT"

__all__ = [
    # Ana sınıflar
    "NexusTrain",
    "NexusConfig",
    # Modüller (tek tek kullanım için)
    "CrystalCore",
    "MorphicMemory",
    "SpectraOptimizer",
    "ResonanceScheduler",
    "TrainingPhase",
    "ChromaticPrecision",
    "GradientHarmonics",
    "NeuralProfiler",
    "CrystalPipeline",
    "ZeroWaste",
    "UniversalAdapter",
    # Yardımcılar
    "nexus_wrap",
    "nexus_check",
]
