"""Gaol - Cross-platform container and VM management tool."""

__version__ = "2026.3.5"
