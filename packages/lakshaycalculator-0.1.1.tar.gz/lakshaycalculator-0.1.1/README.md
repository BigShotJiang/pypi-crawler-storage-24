# Calculator

A simple Python calculator package that provides basic arithmetic operations such as addition, subtraction, multiplication, division, and power.

This package can be used both as a **Python library** and as a **command-line tool**.

---

## Features

* Addition of multiple numbers
* Subtraction of two numbers
* Multiplication of multiple numbers
* Division
* Power calculation
* Simple and lightweight Python package

---

## Installation

Install the package using pip:

```bash
pip install lakshaycalculator
```

Or install locally:

```bash
pip install .
```

---

## Usage (Python)

You can import the functions directly in Python.

```python
from lakshayCalculator.calculator import add, subtract, multiply, division, power

print(add(1,2,3,4))
print(subtract(10,5))
print(multiply(2,3,4))
print(division(10,2))
print(power(2,3))
```

### Output

```
10
5
24
5.0
8
```

---

## Usage (CLI)

After installation, you can run the calculator from the terminal:

```bash
calculator
```

This command runs the `main()` function defined in the package.

---

## Available Functions

### add

Adds multiple numbers.

```python
add(1,2,3)
```

---

### subtract

Subtracts two numbers.

```python
subtract(10,5)
```

---

### multiply

Multiplies multiple numbers.

```python
multiply(2,3,4)
```

---

### division

Divides two numbers.

```python
division(10,2)
```

---

### power

Calculates power of a number.

```python
power(2,3)
```

---

## Requirements

* Python 3.8 or higher

---

## Author

Lakshya Varshney
Email: [lakshyavarshney62@gmail.com](mailto:lakshyavarshney62@gmail.com)

---

## License

MIT License
