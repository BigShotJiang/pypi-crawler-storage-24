def add(*args):
    """This is the add the numbers"""
    sum=0
    for i in args:
        sum+=i
    return sum   

def subtract(a,b):
    """This is for subtracting the number""" 
    return a-b

def multiply(*args):
    """This is for the multiplication of the numbers"""
    mul=1
    for i in args:
        mul*=i
    return mul

def division(a,b)->float:
    """This is for the division of the numbers"""
    return a/b
    
def power(a,b):
    """This is for the power of the number"""
    return a**b
