from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="lakshaycalculator",
    version="0.1.1",
    author="Lakshya Varshney",
    author_email="lakshyavarshney62@gmail.com",
    description="A simple calculator built in Python",
    
    long_description=long_description,
    long_description_content_type="text/markdown",

    packages=find_packages(),

    python_requires=">=3.8",

    install_requires=[],

    entry_points={
        "console_scripts": [
            "calculator=lakshayCalculator.calculator:main"
        ]
    },

    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
)