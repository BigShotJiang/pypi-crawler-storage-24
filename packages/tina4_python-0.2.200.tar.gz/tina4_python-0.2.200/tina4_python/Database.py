#
# Tina4 - This is not a 4ramework.
# Copy-right 2007 - current Tina4
# License: MIT https://opensource.org/licenses/MIT
#
# flake8: noqa: E501
"""Multi-driver database abstraction layer for Tina4.

This module provides the ``Database`` class — a unified interface for
connecting to and querying relational databases. Driver selection is
automatic based on the connection-string prefix:

Supported drivers:
    - ``sqlite`` — SQLite 3 (built-in, file-based)
    - ``mysql`` — MySQL / MariaDB via ``mysql-connector-python``
    - ``postgres`` — PostgreSQL via ``psycopg2``
    - ``firebird`` — Firebird via ``firebirdsql``
    - ``mssql`` — Microsoft SQL Server via ``pymssql``
    - ``odbc`` — Generic ODBC via ``pyodbc``

Key features:
    - Connection-string parsing (``driver:host/port:schema``)
    - Parameter-based queries with ``?`` placeholders
    - Built-in pagination via ``fetch(sql, limit, skip)``
    - Full-text search across specified columns
    - CRUD helpers: ``insert``, ``update``, ``delete``
    - Transaction support: ``begin``, ``commit``, ``rollback``
    - Metadata introspection: ``get_database_tables``, ``get_table_info``
    - Automatic JSON/Decimal/datetime serialisation in results

Example::

    from tina4_python.Database import Database

    db = Database("sqlite:my_app.db")
    result = db.fetch("select * from users", limit=10, skip=0)
    for row in result:
        print(row)
"""

__all__ = ["Database"]

import base64
import os
import re
import sys
import importlib
import json
from decimal import Decimal
from tina4_python import Debug
from tina4_python.DatabaseResult import DatabaseResult
from tina4_python.DatabaseTypes import *
from tina4_python.FieldTypes import get_field_type_values
from tina4_python.SQLToMongo import SQLToMongo
import datetime

class Database:

    def __init__(self, connection_string, username="", password="", charset=""):
        """
        Initializes a database connection
        :param connection_string:
        :param username:
        :param password:
        :param charset: Character set for the connection (e.g. "UTF8", "WIN1252")
        """
        # split out the connection string
        # driver:host/port:schema/path
        params = connection_string.split(":", 1)

        try:
            if connection_string is None:
                connection_string = os.environ.get("DATABASE_PATH", None)
            if username == "":
                username = os.environ.get("DATABASE_USERNAME", "")
            if password == "":
                password = os.environ.get("DATABASE_PASSWORD", "")
            if charset == "":
                charset = os.environ.get("DATABASE_CHARSET", "")

            if connection_string is None:
                from tina4_python import Messages
                raise Exception(Messages.MSG_DB_MISSING_CONNECTION)

            self.database_module = importlib.import_module(params[0])
        except Exception as e:
            from tina4_python import Messages
            install_message = Messages.MSG_DB_UNIMPLEMENTED.format(driver=params[0])
            if params[0] == SQLITE:
                install_message = Messages.MSG_DB_MISSING_SQLITE
            elif params[0] == MYSQL:
                install_message = Messages.MSG_DB_MISSING_MYSQL.format(install_cmd=MYSQL_INSTALL)
            elif params[0] == POSTGRES:
                install_message = Messages.MSG_DB_MISSING_POSTGRES.format(install_cmd=POSTGRES_INSTALL)
            elif params[0] == FIREBIRD:
                install_message = Messages.MSG_DB_MISSING_FIREBIRD.format(install_cmd=FIREBIRD_INSTALL)
            elif params[0] == MSSQL:
                install_message = Messages.MSG_DB_MISSING_MSSQL.format(install_cmd=MSSQL_INSTALL)
            elif params[0] == MONGODB:
                install_message = f"Please install pymongo: {MONGODB_INSTALL}"

            sys.exit(Messages.MSG_DB_DRIVER_NOT_FOUND.format(driver=params[0]) + "\n" + install_message + "\n" + str(e))


        self.database_engine = params[0]
        self.database_path = params[1]
        self.username = username
        self.password = password
        self.charset = charset

        if self.database_engine == SQLITE:
            self.dba = self.database_module.connect(self.database_path)
            self.port = None
            self.host = None

            # we need to register data adapters for sqlite3 due to deprecations in python3.12
            def adapt_date_iso(val):
                """Adapt datetime.date to ISO 8601 date."""
                return val.isoformat()

            def adapt_datetime_iso(val):
                """Adapt datetime.datetime to timezone-naive ISO 8601 date."""
                return val.isoformat()

            def adapt_datetime_epoch(val):
                """Adapt datetime.datetime to Unix timestamp."""
                return int(val.timestamp())

            self.database_module.register_adapter(datetime.date, adapt_date_iso)
            self.database_module.register_adapter(datetime.datetime, adapt_datetime_iso)
            self.database_module.register_adapter(datetime.datetime, adapt_datetime_epoch)

            def convert_date(val):
                """Convert ISO 8601 date to datetime.date object."""
                return datetime.date.fromisoformat(val.decode())

            def convert_datetime(val):
                """Convert ISO 8601 datetime to datetime.datetime object."""
                return datetime.datetime.fromisoformat(val.decode())

            def convert_timestamp(val):
                """Convert Unix epoch timestamp to datetime.datetime object."""
                return datetime.datetime.fromtimestamp(int(val))

            self.database_module.register_converter("date", convert_date)
            self.database_module.register_converter("datetime", convert_datetime)
            self.database_module.register_converter("timestamp", convert_timestamp)
        else:
            # <host>/<port>:<file>
            temp_params = self.database_path.split(":", 1)
            host_port = temp_params[0].split("/", 1)
            self.host = host_port[0]
            if len(host_port) > 1:
                self.port = int(host_port[1])
            else:
                self.port = 3050

            self.database_path = temp_params[1]

            if self.database_engine == FIREBIRD:
                firebird_dsn = self.host + "/" + str(self.port) + ":" + self.database_path
                firebird_args = {
                    "user": self.username,
                    "password": self.password,
                }
                if self.charset:
                    firebird_args["charset"] = self.charset
                self.dba = self.database_module.connect(firebird_dsn, **firebird_args)
            elif self.database_engine == MYSQL:
                mysql_args = {
                    "database": self.database_path,
                    "port": self.port,
                    "host": self.host,
                    "user": self.username,
                    "password": self.password,
                    "consume_results": True,
                }
                if self.charset:
                    mysql_args["charset"] = self.charset
                self.dba = self.database_module.connect(**mysql_args)
            elif self.database_engine == POSTGRES:
                postgres_args = {
                    "dbname": self.database_path,
                    "port": self.port,
                    "host": self.host,
                    "user": self.username,
                    "password": self.password,
                }
                if self.charset:
                    postgres_args["client_encoding"] = self.charset
                self.dba = self.database_module.connect(**postgres_args)
            elif self.database_engine == MSSQL:
                self.dba = self.database_module.connect(
                    server=self.host,
                    port=self.port,
                    user=self.username,
                    password=self.password,
                    database=self.database_path
                )
                self.dba.autocommit(False)
            elif self.database_engine == MONGODB:
                # pymongo: MongoClient → Database
                mongo_args = {"host": self.host, "port": self.port}
                if self.username:
                    mongo_args["username"] = self.username
                if self.password:
                    mongo_args["password"] = self.password
                self._mongo_client = self.database_module.MongoClient(**mongo_args)
                self.dba = self._mongo_client[self.database_path]
                self._mongo_session = None
            else:
                sys.exit("Could not load database driver for " + params[0])

        Debug.debug("DATABASE:", self.database_module.__name__, self.host, self.port, self.database_path, self.username)

    def table_exists(self, table_name):
        """
        Checks if a table exists in the database
        :param str table_name: Name of the table
        :return: bool : True if table exists, else False
        """

        if self.database_engine == MONGODB:
            return table_name in self.dba.list_collection_names()
        elif self.database_engine == MSSQL:
            sql = "select count(*) as count_table from sys.tables WHERE name = '" + table_name.upper() + "'"
        elif self.database_engine == SQLITE:
            sql = "SELECT count(*) as count_table FROM sqlite_master WHERE type='table' AND name='" + table_name + "'"
        elif self.database_engine == MYSQL:
            sql = "SELECT count(*) as count_table FROM information_schema.tables WHERE table_schema = '" + self.database_path + "' AND table_name = '" + table_name + "'"
        elif self.database_engine == POSTGRES:
            sql = """SELECT count(*) as count_table FROM pg_catalog.pg_class c
                        JOIN   pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                        WHERE  c.relname = '""" + table_name + """'
                        AND    c.relkind = 'r'        """
        elif self.database_engine == FIREBIRD:
            sql = "SELECT count(*) as count_table FROM RDB$RELATIONS WHERE RDB$RELATION_NAME = upper('" + table_name + "')"
        else:
            return False

        try:
            record = self.fetch_one(sql)
        except Exception as e:
            raise Exception(f"Error checking if table {table_name} exists: " + str(e))

        if record:
            if record["count_table"] > 0:
                return True
            else:
                return False
        else:
            return False

    def get_next_id(self, table_name, column_name="id"):
        """
        Gets the next id using max method in SQL for databases which don't have good sequences
        :param str table_name: Name of the table
        :param str column_name: Name of the column in that table to increment
        :return: int : The next id in the sequence
        """
        try:
            if self.database_engine == MONGODB:
                coll = self.dba[table_name]
                doc = coll.find_one(sort=[(column_name, -1)], projection={column_name: 1})
                max_val = doc[column_name] if doc and column_name in doc else 0
                return int(max_val) + 1

            sql = "select max(" + column_name + ") as \"max_id\" from " + table_name
            record = self.fetch_one(sql)
            if record["max_id"] is None:
                record = {"max_id": 0}

            next_id = int(record["max_id"]) + 1
            return next_id
        except Exception as e:
            Debug.error("Get next id", str(e))
            return None

    def database_exists(self, database_name):

        return True

    def current_timestamp(self):
        """
        Gets the current timestamp based on the database being used
        :return:
        """
        if self.database_engine == FIREBIRD:
            return datetime.datetime.now().strftime("%d/%m/%Y %H:%M:%S")
        elif self.database_engine == SQLITE:
            return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        else:
            return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def get_database_result(self, cursor, counter, limit, skip, sql):
        """
        Get database results
        :param sql:
        :param cursor:
        :param counter:
        :param limit:
        :param skip:
        :return:
        """
        columns = [column[0].lower() for column in cursor.description]
        records = cursor.fetchall()
        rows = [dict(zip(columns, row)) for row in records]
        cursor.close()
        return DatabaseResult(rows, columns, None, counter, limit, skip, sql, self)

    def is_json(self, myjson):
        """
        Checks if a JSON string is valid
        :param myjson:
        :return:
        """
        try:
            json.loads(myjson)
        except Exception:
            return False
        return True

    def check_connected(self):
        """
        Checks if the database connection is established
        :return:
        """
        if self.database_engine == MYSQL:
            self.dba.ping(reconnect=True, attempts=1, delay=0)
        elif self.database_engine == MONGODB:
            # pymongo auto-reconnects; ping to confirm
            try:
                self._mongo_client.admin.command('ping')
            except Exception:
                pass
        else:
            # implement other database requirements if needed
            pass

    def fetch(self, sql, params=None, limit=10, skip=0, search=None, search_columns=None):
        """
        Enhanced fetch with optional full-text search + correct pagination
        :param sql:
        :param params:
        :param limit:
        :param skip:
        :param search:
        :param search_columns:
        :return:
        """
        if params is None:
            params = []
        if isinstance(params, list):
            params = params.copy()
        else:
            params = list(params)

        self.check_connected()

        # --- MongoDB: translate SQL to MongoDB queries ---
        if self.database_engine == MONGODB:
            return self._mongo_fetch(sql, params, limit, skip, search, search_columns)

        final_sql = sql
        final_params = params

        if search and search.strip():
            search = search.strip()

            # which columns are searchable?
            cols = search_columns or getattr(self, "columns", None)
            if not cols:
                # fallback – try to extract column names from SELECT
                m = re.search(r"SELECT\s+([\s\S]*?)\s+FROM", final_sql, re.I)
                if m:
                    raw = re.split(r',\s*(?=[a-zA-Z_`"\[\]])', m.group(1))
                    cols = []
                    for c in raw:
                        name = c.strip().split()[-1].split(".")[-1]
                        name = re.sub(r'^[`"\[(].*[`"\])]$', '', name).strip('`"[]')
                        if name and name != "*":
                            cols.append(name)

            if cols:
                if self.database_engine == POSTGRES:
                    like_op = "ILIKE"
                else:
                    like_op = "LIKE"

                conditions = []
                for col in cols:
                    col_name = f'"{col}"' if " " not in col else col
                    conditions.append(f"cast({col_name} as varchar(1000)) {like_op} ?")
                    final_params.append(f"%{search}%")

                where_clause = " WHERE (" + " OR ".join(conditions) + ")"
                final_sql = sql + where_clause

        # 3. TOTAL COUNT — strip ORDER BY (doesn't affect count, breaks MSSQL subqueries)
        count_inner = re.sub(r"(?i)\s+order\s+by\s+.+?$", "", final_sql, flags=re.DOTALL).strip()
        count_sql = f"SELECT COUNT(*) AS count_records FROM ({count_inner}) AS t"
        counter = self.dba.cursor()
        try:
            counter.execute(self.parse_place_holders(count_sql), final_params)
            total = counter.fetchone()[0]
        except Exception as e:
            Debug.error("COUNT ERROR", count_sql, final_params, str(e))
            try:
                self.dba.rollback()
            except Exception:
                pass
            total = 0
        finally:
            counter.close()

        # 4. PAGINATED DATA query
        if self.database_engine == FIREBIRD:
            final_sql = f"SELECT FIRST {limit} SKIP {skip} * FROM ({final_sql}) AS t"
        elif self.database_engine == MSSQL:
            inner = final_sql.strip()
            order_by_match = re.search(r"(?i)\border\s+by\s+.+?$", inner, re.DOTALL)
            has_order_by = order_by_match is not None
            if has_order_by:
                inner_clean = re.sub(r"(?i)\s+order\s+by\s+.+?$", "", inner, flags=re.DOTALL).strip()
                order_by_part = order_by_match.group(0)
                # Strip table aliases from ORDER BY columns (e.g. "e.salary" -> "salary")
                # since the inner query is wrapped as subquery "t"
                order_by_part = re.sub(r'(\b\w+)\.(\w+)', r'\2', order_by_part)
            else:
                inner_clean = inner
                order_by_part = "ORDER BY (SELECT NULL)"
            final_sql = f"SELECT * FROM ({inner_clean}) AS t {order_by_part} OFFSET {skip} ROWS FETCH NEXT {limit} ROWS ONLY"
        else:
            # SQLite, MySQL, PostgreSQL
            final_sql = f"SELECT * FROM ({final_sql}) AS t LIMIT {limit} OFFSET {skip}"

        final_sql = self.parse_place_holders(final_sql)

        # 5. Execute the data query
        cursor = self.dba.cursor()
        try:
            cursor.execute(final_sql, final_params)
            return self.get_database_result(cursor, total, limit, skip, final_sql)
        except Exception as e:
            Debug.error("FETCH ERROR", final_sql, final_params, str(e))
            try:
                self.dba.rollback()
            except Exception:
                pass
            return DatabaseResult(None, [], str(e))
        finally:
            cursor.close()

    def fetch_one(self, sql, params=None, skip=0):
        """
        Fetch a single record based on a SQL statement, take note that BLOB and byte record data is converted into base64 automatically
        :param str sql: A plain SQL statement or one with params in it designated by ?
        :param list params: A list of params in order of precedence
        :param int skip: Offset of records to skip
        :return: dict : A dictionary containing the single record
        """
        if params is None:
            params = []
        # Calling the fetch method with limit as 1 and returning the result
        record = self.fetch(sql, params=params, limit=1, skip=skip)
        if record.error is None and record.count == 1:
            data = {}
            for key in record.records[0]:
                if isinstance(record.records[0][key], Decimal):
                    data[key] = float(record.records[0][key])
                elif isinstance(record.records[0][key], (datetime.date, datetime.datetime)):
                    data[key] = record.records[0][key].isoformat()
                elif isinstance(record.records[0][key], bytes):
                    data[key] = base64.b64encode(record.records[0][key]).decode('utf-8')
                elif isinstance(record.records[0][key], str) and self.is_json(record.records[0][key]):
                    data[key] = json.loads(record.records[0][key])
                else:
                    data[key] = record.records[0][key]
            return data
        else:
            return None

    def parse_place_holders(self, sql):
        """
        Sanitizes a SQL statement to replace param chars with the appropriate placeholders
        MYSQL expects %s and firebird, PostgresSQL and sqlite expect ?
        :param sql:
        :return:
        """
        if self.database_engine == MONGODB:
            return sql  # MongoDB doesn't use SQL placeholders
        elif self.database_engine == MYSQL or self.database_engine == POSTGRES or self.database_engine == MSSQL:
            return sql.replace("?", "%s")
        else:
            return sql.replace("%s", "?")

    @staticmethod
    def _has_returning_clause(sql):
        """Detect a SQL RETURNING clause without false positives.

        Strips string literals and comments first, then checks that RETURNING
        appears as a standalone keyword at the end of an INSERT, UPDATE, or
        DELETE statement.  This avoids matching column names, table names, or
        values that happen to contain the word "returning".
        """
        # Strip single-quoted string literals ('' escapes inside)
        cleaned = re.sub(r"'(?:[^']|'')*'", "''", sql)
        # Strip double-quoted identifiers
        cleaned = re.sub(r'"(?:[^"]|"")*"', '""', cleaned)
        # Strip block comments
        cleaned = re.sub(r'/\*.*?\*/', ' ', cleaned, flags=re.DOTALL)
        # Strip line comments
        cleaned = re.sub(r'--[^\n]*', ' ', cleaned)

        # Check the statement type is INSERT, UPDATE, or DELETE
        stripped = cleaned.strip()
        if not re.match(r'(?i)^(INSERT|UPDATE|DELETE)\b', stripped):
            return False

        # Look for RETURNING as a standalone keyword (word boundary on both sides)
        # It should appear after the main clause, not as part of an identifier
        return bool(re.search(r'\bRETURNING\b', cleaned, re.IGNORECASE))

    def _emulate_returning(self, sql, params, cursor):
        """Emulate RETURNING for engines that don't support it natively.

        MySQL and MSSQL don't support the RETURNING clause directly.
        - For INSERT: uses lastrowid to fetch the inserted row back.
        - For UPDATE/DELETE: extracts the RETURNING columns and the WHERE
          clause to SELECT the affected rows before executing the mutation.

        Returns a DatabaseResult, or None if emulation isn't needed/possible.
        """
        cleaned_sql = sql.strip()
        upper_sql = cleaned_sql.upper()

        # Extract the RETURNING column list
        ret_match = re.search(r'\bRETURNING\b\s+(.+)$', cleaned_sql, re.IGNORECASE | re.DOTALL)
        if not ret_match:
            return None
        returning_cols = ret_match.group(1).strip().rstrip(';')

        # SQL without the RETURNING clause
        base_sql = cleaned_sql[:ret_match.start()].strip()

        if upper_sql.startswith('INSERT'):
            # Execute the INSERT (without RETURNING)
            base_parsed = self.parse_place_holders(base_sql)
            cursor.execute(base_parsed, params)

            # Fetch the inserted row using lastrowid
            last_id = cursor.lastrowid
            if last_id is not None and last_id > 0:
                # Extract table name from INSERT INTO <table>
                table_match = re.match(r'(?i)INSERT\s+INTO\s+(\S+)', base_sql)
                if table_match:
                    table_name = table_match.group(1)
                    # For MSSQL use different ID retrieval
                    if self.database_engine == MSSQL:
                        select_sql = f"SELECT {returning_cols} FROM {table_name} WHERE id = @@IDENTITY"
                        cursor.execute(select_sql)
                    else:
                        select_sql = self.parse_place_holders(
                            f"SELECT {returning_cols} FROM {table_name} WHERE id = ?"
                        )
                        cursor.execute(select_sql, [last_id])
                    return self.get_database_result(cursor, 1, 1, 0, sql)

            # Fallback: return lastrowid as "id"
            return DatabaseResult([{"id": last_id}], [], None, 1, 1, 0, sql, self)

        elif upper_sql.startswith('UPDATE') or upper_sql.startswith('DELETE'):
            # For UPDATE/DELETE: extract WHERE clause, SELECT matching rows first,
            # then execute the mutation
            where_match = re.search(r'\bWHERE\b\s+(.+)$', base_sql, re.IGNORECASE | re.DOTALL)

            if upper_sql.startswith('UPDATE'):
                table_match = re.match(r'(?i)UPDATE\s+(\S+)', base_sql)
            else:
                table_match = re.match(r'(?i)DELETE\s+FROM\s+(\S+)', base_sql)

            if table_match and where_match:
                table_name = table_match.group(1)
                where_clause = where_match.group(1).strip()
                # SELECT the rows that will be affected
                select_sql = self.parse_place_holders(
                    f"SELECT {returning_cols} FROM {table_name} WHERE {where_clause}"
                )
                cursor.execute(select_sql, params)
                rows = cursor.fetchall()
                columns = [col[0].lower() for col in cursor.description]
                result_rows = [dict(zip(columns, row)) for row in rows]

                # Now execute the actual mutation
                base_parsed = self.parse_place_holders(base_sql)
                cursor.execute(base_parsed, params)

                return DatabaseResult(result_rows, columns, None, len(result_rows), len(result_rows), 0, sql, self)

        return None

    # -------------------------------------------------------------------
    # MongoDB helpers
    # -------------------------------------------------------------------

    def _mongo_fetch(self, sql, params, limit, skip, search, search_columns):
        """Execute a SQL SELECT against MongoDB via SQLToMongo translation."""
        try:
            op = SQLToMongo.translate(sql, params)
        except Exception as e:
            Debug.error("MONGO SQL PARSE ERROR", sql, str(e))
            return DatabaseResult(None, [], str(e))

        collection = self.dba[op["collection"]]
        mongo_filter = op.get("filter", {})

        # Add search conditions
        if search and search.strip():
            search_filter = self._mongo_search_filter(search, search_columns, op)
            if search_filter:
                if mongo_filter:
                    mongo_filter = {"$and": [mongo_filter, search_filter]}
                else:
                    mongo_filter = search_filter

        try:
            if op["type"] == "count":
                total = collection.count_documents(mongo_filter)
                return DatabaseResult([{"count_records": total}], ["count_records"], None, 1, 1, 0, sql, self)

            # Total count
            total = collection.count_documents(mongo_filter)

            # Build find kwargs
            find_kwargs = {}
            projection = op.get("projection")
            if projection:
                find_kwargs["projection"] = projection
                # Always exclude _id unless explicitly requested
                if "_id" not in projection:
                    find_kwargs["projection"]["_id"] = 0
            else:
                find_kwargs["projection"] = {"_id": 0}

            cursor = collection.find(mongo_filter, **find_kwargs)

            sort = op.get("sort")
            if sort:
                cursor = cursor.sort(list(sort.items()))

            # Use pagination from the op if present, otherwise use method params
            actual_skip = op.get("skip", skip)
            actual_limit = op.get("limit", limit)
            cursor = cursor.skip(actual_skip).limit(actual_limit)

            rows = list(cursor)
            columns = list(rows[0].keys()) if rows else []

            return DatabaseResult(rows, columns, None, total, actual_limit, actual_skip, sql, self)

        except Exception as e:
            Debug.error("MONGO FETCH ERROR", sql, str(e))
            return DatabaseResult(None, [], str(e))

    def _mongo_execute(self, sql, params):
        """Execute a SQL INSERT/UPDATE/DELETE/CREATE/DROP against MongoDB."""
        try:
            op = SQLToMongo.translate(sql, params)
        except Exception as e:
            Debug.error("MONGO SQL PARSE ERROR", sql, str(e))
            return DatabaseResult(None, [], str(e))

        try:
            op_type = op["type"]
            collection_name = op["collection"]

            if op_type == "insert":
                coll = self.dba[collection_name]
                doc = op["document"]
                result = coll.insert_one(doc)
                # Build a result that includes the inserted doc
                return_doc = dict(doc)
                if "_id" in return_doc:
                    return_doc["_id"] = str(return_doc["_id"])
                columns = list(return_doc.keys())
                return DatabaseResult([return_doc], columns, None, 1, 1, 0, sql, self)

            elif op_type == "update":
                coll = self.dba[collection_name]
                mongo_filter = op.get("filter", {})
                update_doc = op["update"]

                if op.get("returning"):
                    # Fetch matching docs before update for RETURNING emulation
                    pre_docs = list(coll.find(mongo_filter, {"_id": 0}))

                result = coll.update_many(mongo_filter, update_doc)

                if op.get("returning"):
                    columns = list(pre_docs[0].keys()) if pre_docs else []
                    return DatabaseResult(pre_docs, columns, None, len(pre_docs), len(pre_docs), 0, sql, self)

                return DatabaseResult(None, [], None, result.modified_count, 0, 0, sql, self)

            elif op_type == "delete":
                coll = self.dba[collection_name]
                mongo_filter = op.get("filter", {})

                if op.get("returning"):
                    # Fetch matching docs before delete for RETURNING emulation
                    pre_docs = list(coll.find(mongo_filter, {"_id": 0}))

                result = coll.delete_many(mongo_filter)

                if op.get("returning"):
                    columns = list(pre_docs[0].keys()) if pre_docs else []
                    return DatabaseResult(pre_docs, columns, None, len(pre_docs), len(pre_docs), 0, sql, self)

                return DatabaseResult(None, [], None, result.deleted_count, 0, 0, sql, self)

            elif op_type == "create_collection":
                if collection_name not in self.dba.list_collection_names():
                    self.dba.create_collection(collection_name)
                return DatabaseResult(None, [], None, 0, 0, 0, sql, self)

            elif op_type == "drop_collection":
                if collection_name in self.dba.list_collection_names():
                    self.dba.drop_collection(collection_name)
                return DatabaseResult(None, [], None, 0, 0, 0, sql, self)

            else:
                return DatabaseResult(None, [], f"Unsupported MongoDB operation: {op_type}")

        except Exception as e:
            Debug.error("MONGO EXECUTE ERROR", sql, str(e))
            return DatabaseResult(None, [], str(e))

    def _mongo_search_filter(self, search, search_columns, op):
        """Build a MongoDB $or filter for full-text search across columns."""
        cols = search_columns
        if not cols:
            # Try to get columns from the projection
            proj = op.get("projection", {})
            cols = [k for k in proj if k != "_id" and proj[k] == 1]

        if not cols:
            # Fallback: search all fields (not ideal but workable)
            return {"$where": f"JSON.stringify(this).toLowerCase().indexOf('{search.lower()}') !== -1"}

        conditions = []
        for col in cols:
            conditions.append({col: {"$regex": re.escape(search), "$options": "i"}})

        return {"$or": conditions} if conditions else {}

    def execute(self, sql, params=None):
        """
        Execute a query based on a SQL statement
        :param str sql: A plain SQL statement or one with params in it designated by ?
        :param list params: A list of params in order of precedence
        :return: DatabaseResult
        """
        if params is None:
            params = []

        self.check_connected()

        # --- MongoDB: route through SQLToMongo ---
        if self.database_engine == MONGODB:
            return self._mongo_execute(sql, params)

        if params != []:
            sql = self.parse_place_holders(sql)
        cursor = self.dba.cursor()
        # Running an execute statement and committing any changes to the database
        try:
            if params != []:
                params = get_field_type_values(params)

            has_returning = self._has_returning_clause(sql)

            if has_returning and self.database_engine in (MYSQL, MSSQL):
                # Emulate RETURNING for engines that don't support it natively
                result = self._emulate_returning(sql, params, cursor)
                if result is not None:
                    return result

            cursor.execute(sql, params)

            if has_returning:
                # Native RETURNING support (PostgreSQL, SQLite, Firebird)
                return self.get_database_result(cursor, 1, 1, 0, sql)
            else:
                # see if we are mysql and if we are insert statement to get the last record
                if "insert" in sql.lower() and (self.database_engine == MYSQL or self.database_engine == MSSQL):
                    return DatabaseResult([{"id": cursor.lastrowid}], [], None, 1, 1, 0, sql, self)

                # On success return an empty result set with no error
                return DatabaseResult(None, [], None, 0, 0, 0, sql, self)
        except Exception as e:
            Debug.error("EXECUTE ERROR:", sql, str(e))
            try:
                self.dba.rollback()
            except Exception:
                pass
            # Return the error in the result
            return DatabaseResult(None, [], str(e))
        finally:
            cursor.close()

    def execute_many(self, sql, params=None):
        """
        Execute a query based on a single SQL statement with a different number of params
        :param sql: A plain SQL statement or one with params in it designated by ?
        :param params: A list of params in order of precedence
        :return: DatabaseResult
        """
        if params is None:
            params = []

        self.check_connected()

        if params != []:
            sql = self.parse_place_holders(sql)

        cursor = self.dba.cursor()
        # Running an execute statement and committing any changes to the database
        try:
            if params != []:
                params = get_field_type_values(params)
            cursor.executemany(sql, params)
            # On success return an empty result set with no error
            return DatabaseResult(None, [], None)
        except Exception as e:
            Debug.error("EXECUTE MANY ERROR:", sql, str(e))
            try:
                self.dba.rollback()
            except Exception:
                pass
            # Return the error in the result
            return DatabaseResult(None, [], str(e))
        finally:
            cursor.close()

    def start_transaction(self):
        """
        Starts a transaction
        :return:
        """
        try:
            self.check_connected()
            if self.database_engine == SQLITE:
                self.dba.execute("BEGIN TRANSACTION")
            elif self.database_engine == FIREBIRD:
                self.dba.begin()
            elif self.database_engine == MYSQL:
                self.dba.start_transaction()
            elif self.database_engine == MSSQL:
                self.dba.execute("BEGIN TRANSACTION")
            elif self.database_engine == POSTGRES:
                self.dba.rollback()  # start fresh
            elif self.database_engine == MONGODB:
                self._mongo_session = self._mongo_client.start_session()
                self._mongo_session.start_transaction()
            else:
                Debug.error("START TRANSACTION ERROR:", "Database engine unrecognised/not supported")
        except Exception as e:
            Debug.error("START TRANSACTION ERROR:", str(e))

    def commit(self):
        """
        Commit transaction
        :return:
        """
        try:
            if self.database_engine == MONGODB:
                if self._mongo_session:
                    self._mongo_session.commit_transaction()
                    self._mongo_session.end_session()
                    self._mongo_session = None
                # MongoDB auto-commits individual operations; no-op otherwise
            else:
                self.dba.commit()
        except Exception as e:
            Debug.error("COMMIT TRANSACTION ERROR:", str(e))

    def rollback(self):
        """
        Rollback transaction
        :return:
        """
        try:
            if self.database_engine == MONGODB:
                if self._mongo_session:
                    self._mongo_session.abort_transaction()
                    self._mongo_session.end_session()
                    self._mongo_session = None
            else:
                self.dba.rollback()
        except Exception as e:
            Debug.error("ROLLBACK TRANSACTION ERROR:", str(e))

    def close(self):
        """
        Close database connection
        :return:
        """
        try:
            if self.database_engine == MONGODB:
                self._mongo_client.close()
            else:
                self.dba.close()
        except Exception as e:
            Debug.error("DATABASE CLOSE ERROR:", str(e))

    def sanitize(self, record):
        """
        Changes dictionaries and list values into JSON for updating and inserting
        :param record:
        :return:
        """
        for key in record:
            if isinstance(record[key], list) or isinstance(record[key], dict):
                record[key] = json.dumps(record[key])
        return record

    def insert(self, table_name, data:dict|list, primary_key="id"):
        """
        Insert data based on table name and data provided - single or multiple records
        :param str table_name: Name of table
        :param None data: List or Dictionary containing the data to be inserted
        :param str primary_key: The name of the primary key of the table
        """
        if isinstance(data, dict):
            data = [data]

        if isinstance(data, list):
            records = DatabaseResult()

            result = None
            for record in data:
                columns = ", ".join(record.keys())
                placeholders = ", ".join(['?'] * len(record))

                # Determine if we need to auto-generate the primary key
                need_auto_id = (
                        primary_key not in columns or
                        (primary_key in record and (record[primary_key] is None or record[primary_key] == ""))
                )

                if need_auto_id:
                    record[primary_key] = self.get_next_id(table_name, primary_key)
                    if primary_key not in columns:
                        columns += f", {primary_key}"
                        placeholders += ", ?"


                sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"

                if self.database_engine == FIREBIRD or self.database_engine == SQLITE or self.database_engine == POSTGRES:
                    sql += f" returning ({primary_key})"

                record = self.sanitize(record)
                if self.database_engine == MSSQL:
                    self.execute(f"SET IDENTITY_INSERT {table_name} ON")
                result = self.execute(sql, list(record.values()))
                if self.database_engine == MSSQL:
                    self.execute(f"SET IDENTITY_INSERT {table_name} OFF")
                records.records += result.records
                if result.error is not None:
                    Debug.error("INSERT ERROR:", sql, result.error)
                    return False

            records.columns = result.columns
            records.count = len(records.records)
            records.sql = sql
            records.dba = self

            return records
        else:
            return False

    def delete(self, table_name, filter=None):
        """
        Delete data based on table name and filter provided - single or multiple filters
        :param str table_name: Name of table
        :param str filter: Expression for deleting records
        """
        placeholder = "?"

        if filter is not None:
            # Updating a single record - record passed in is a dictionary
            if isinstance(filter, dict):
                filter = [filter]

            # Updating multiple records - records passed in is a list
            if isinstance(filter, list):
                sql = ""
                result = None
                for record in filter:
                    pk_value = []
                    condition_records = []

                    for column, value in record.items():
                        condition_records.append(f"{column} = {placeholder}")
                        pk_value.append(value)

                    condition_records = " and ".join(condition_records)

                    sql = f"DELETE FROM {table_name} WHERE {condition_records}"

                    params = pk_value

                    result = self.execute(sql, params)
                    if result.error is not None:
                        break

                if result.error is None:
                    return True
                else:
                    Debug.error("DELETE ERROR:", sql, result.error)
                    return False

        return False

    def update(self, table_name, data:dict|list, primary_key="id"):
        """
        Update data based on table name and record/primary key provided - single or multiple records
        :param str table_name: Name of table
        :param None data: List or Dictionary containing the data to be inserted
        :param str primary_key: The name of the primary key of the table
        """
        placeholder = "?"

        if data is not None:
            # Updating a single record - record passed in is a dictionary
            if isinstance(data, dict):
                data = [data]

            # Updating multiple records - records passed in is a list
            if isinstance(data, list):
                sql = ""
                result = None
                for record in data:
                    pk_value = None
                    condition_records = ""
                    set_clause_list = []
                    set_values = []

                    for column, value in record.items():
                        if column == primary_key:
                            condition_records = f"{column} = {placeholder}"
                            pk_value = value
                        else:
                            set_clause_list.append(f"{column} = {placeholder}")
                            if isinstance(value, list) or isinstance(value, dict):
                                set_values.append(json.dumps(value))
                            else:
                                set_values.append(value)

                    set_clause = ", ".join(set_clause_list)

                    sql = f"UPDATE {table_name} SET {set_clause} WHERE {condition_records}"

                    params = set_values + [pk_value]

                    result = self.execute(sql, params)
                    if result.error is not None:
                        break

                if result.error is None:
                    return True
                else:
                    Debug.error("UPDATE ERROR:", sql, result.error)
                    return False

        return False
