"""Data models for voicetest."""
