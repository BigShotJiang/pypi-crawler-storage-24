"""dojigiri-ai — LLM-powered deep scan plugin for dojigiri.

This package registers as a ``dojigiri.plugins`` entry_point and exposes
all LLM capabilities (deep scan, fix generation, PR review, etc.) to the
base dojigiri package via the plugin loader.

When installed, ``dojigiri.plugin.get_llm_plugin()`` returns the object
produced by ``register()`` below, which proxies all public symbols from
``dojigiri.llm``.
"""

from __future__ import annotations


def register():
    """Entry point called by dojigiri's plugin loader.

    Returns the ``dojigiri.llm`` module so that the base package can
    access LLM functions (analyze_chunk, CostTracker, etc.) without
    hardcoding the import.

    This is the bridge: dojigiri-ai depends on dojigiri (for the llm
    modules that currently live there), and dojigiri discovers dojigiri-ai
    via entry_points. Once the LLM files are physically moved into this
    package, this function will return the local module instead.
    """
    import dojigiri.llm

    return dojigiri.llm
