"""Single-pass AST extraction layer for semantic analysis.

Walks the tree-sitter AST once per file and extracts assignments, references,
function definitions, function calls, class definitions, and scope information.
All other semantic modules operate on these extracted data structures.
Returns None when tree-sitter is not installed (graceful degradation).

Called by: detector.py, fixer.py, mcp_server.py
Calls into: semantic/lang_config.py
Data in → Data out: (source bytes, filepath, language) → FileSemantics
"""

from __future__ import annotations

import logging
from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger(__name__)

# tree-sitter Node has no public type stubs; alias keeps the single Any import
# contained and documents intent throughout the module.
TSNode = Any  # noqa: Any — tree-sitter node (no stubs available)

from .lang_config import LanguageConfig, get_config

# ─── Data structures ─────────────────────────────────────────────────


@dataclass
class Assignment:
    name: str
    line: int
    scope_id: int
    value_node_type: str
    value_text: str
    is_parameter: bool
    is_augmented: bool


@dataclass
class NameReference:
    name: str
    line: int
    scope_id: int
    context: str  # "read", "call", "attribute_access"
    receiver: str | None = None  # object in obj.attr (e.g. "self" for self.foo)


@dataclass
class FunctionDef:
    name: str
    qualified_name: str  # "Class.method" or just "func"
    line: int
    end_line: int
    params: list[str]
    scope_id: int
    parent_class: str | None
    has_varargs: bool = False


@dataclass
class FunctionCall:
    name: str
    line: int
    scope_id: int
    arg_count: int
    receiver: str | None  # "obj" in obj.method()


@dataclass
class ClassDef:
    name: str
    line: int
    end_line: int
    method_count: int
    attribute_names: list[str]
    scope_id: int


@dataclass
class ScopeInfo:
    scope_id: int
    parent_id: int | None
    kind: str  # "module", "function", "class", "block"
    start_line: int
    end_line: int
    name: str | None


@dataclass
class FileSemantics:
    filepath: str
    language: str
    assignments: list[Assignment] = field(default_factory=list)
    references: list[NameReference] = field(default_factory=list)
    function_defs: list[FunctionDef] = field(default_factory=list)
    function_calls: list[FunctionCall] = field(default_factory=list)
    class_defs: list[ClassDef] = field(default_factory=list)
    scopes: list[ScopeInfo] = field(default_factory=list)
    # Per-scope nonlocal declarations: {scope_id: {name, ...}}
    nonlocal_names: dict[int, set[str]] = field(default_factory=dict)
    # Source lines (1-indexed: source_lines[0] is line 1) for effective-line counting
    source_lines: list[str] = field(default_factory=list, repr=False)
    # Cached tree-sitter root node (v0.9.0) — avoids double parsing for CFG
    _tree_root: object = field(default=None, repr=False)


# ─── Helpers ─────────────────────────────────────────────────────────

from ._utils import _end_line, _get_text, _line  # noqa: E402

# ─── Extraction engine ───────────────────────────────────────────────


class _Extractor:
    """Walks the AST once, maintaining a scope stack."""

    def __init__(self, source_bytes: bytes, config: LanguageConfig, filepath: str, language: str):
        self.src = source_bytes
        self.config = config
        self.filepath = filepath
        self.language = language

        self.result = FileSemantics(filepath=filepath, language=language)
        self._scope_counter = 0
        self._scope_stack: list[int] = []
        self._scope_info: dict[int, ScopeInfo] = {}
        self._current_class: str | None = None  # doji:ignore(null-dereference)

        # Sets for fast lookup
        self._assignment_types = set(config.assignment_node_types)
        self._call_types = set(config.call_node_types)
        self._class_types = set(config.class_node_types)
        self._func_types = set(config.function_node_types)
        self._for_types = set(config.cfg_for_node_types)
        self._scope_boundary_types = set(config.scope_boundary_types)
        self._attr_types = set(config.attribute_access_types)
        self._block_types = set(config.block_node_types)

    @property
    def _current_scope(self) -> int:
        return self._scope_stack[-1] if self._scope_stack else 0

    def _push_scope(self, kind: str, node, name: str | None = None) -> int:
        self._scope_counter += 1
        sid = self._scope_counter
        parent = self._current_scope
        info = ScopeInfo(
            scope_id=sid,
            parent_id=parent if parent != 0 or kind != "module" else None,
            kind=kind,
            start_line=_line(node),
            end_line=_end_line(node),
            name=name,
        )
        self._scope_info[sid] = info
        self.result.scopes.append(info)
        self._scope_stack.append(sid)
        return sid

    def _pop_scope(self) -> None:
        if self._scope_stack:
            self._scope_stack.pop()

    def extract(self, root_node: TSNode) -> None:
        # Module scope
        self._push_scope("module", root_node, name=self.filepath)
        self._walk(root_node)
        self._pop_scope()

    def _walk(self, node: TSNode) -> None:
        ntype = node.type

        # ── Function definitions ──────────────────────────────────
        if ntype in self._func_types and node.is_named:
            self._handle_function(node)
            return  # children handled inside

        # ── Class definitions ─────────────────────────────────────
        if ntype in self._class_types:
            self._handle_class(node)
            return

        # ── Assignments ───────────────────────────────────────────
        if ntype in self._assignment_types:
            self._handle_assignment(node)

        # ── For-loop variables (treated as assignments) ───────────
        if ntype in self._for_types:
            self._handle_for_loop_var(node)

        # ── With-statement targets (with X as Y → Y is an assignment) ──
        if ntype == "with_statement":
            self._handle_with_statement(node)

        # ── Nonlocal declarations (nonlocal x → x is from outer scope) ──
        if ntype == "nonlocal_statement":
            self._handle_nonlocal(node)

        # ── Function calls ────────────────────────────────────────
        if ntype in self._call_types:
            self._handle_call(node)

        # ── Identifier references ─────────────────────────────────
        if ntype == "identifier":
            self._handle_identifier(node)

        # ── Block scoping (for block-scoped languages) ────────────
        if self.config.block_scoped and ntype in self._block_types:
            # Only create block scope if parent is not a function/class
            # (those already pushed their own scope)
            parent_type = node.parent.type if node.parent else ""
            if parent_type not in self._func_types and parent_type not in self._class_types:
                self._push_scope("block", node)
                for child in node.children:
                    self._walk(child)
                self._pop_scope()
                return

        # Recurse children
        for child in node.children:
            self._walk(child)

    def _handle_function(self, node: TSNode) -> None:
        name_node = node.child_by_field_name("name")
        name = _get_text(name_node, self.src) if name_node else "<anonymous>"

        # Build qualified name
        if self._current_class:
            qualified = f"{self._current_class}.{name}"
        else:
            qualified = name

        # Extract parameters
        params = self._extract_params(node)
        has_varargs = self._has_varargs(node)

        fdef = FunctionDef(
            name=name,
            qualified_name=qualified,
            line=_line(node),
            end_line=_end_line(node),
            params=params,
            scope_id=self._current_scope,
            parent_class=self._current_class,
            has_varargs=has_varargs,
        )
        self.result.function_defs.append(fdef)

        # Record function name as an assignment in the *enclosing* scope
        # (a `def foo():` statement binds `foo` in the scope where it appears)
        if name != "<anonymous>":
            self.result.assignments.append(
                Assignment(
                    name=name,
                    line=_line(node),
                    scope_id=self._current_scope,
                    value_node_type="function_def",
                    value_text="",
                    is_parameter=False,
                    is_augmented=False,
                )
            )

        # Push function scope and record params as assignments
        self._push_scope("function", node, name=qualified)
        fn_scope = self._current_scope

        for pname in params:
            self.result.assignments.append(
                Assignment(
                    name=pname,
                    line=_line(node),
                    scope_id=fn_scope,
                    value_node_type="parameter",
                    value_text="",
                    is_parameter=True,
                    is_augmented=False,
                )
            )

        # Walk function body
        for child in node.children:
            self._walk(child)

        self._pop_scope()

    def _handle_class(self, node: TSNode) -> None:
        name_node = node.child_by_field_name("name")
        name = _get_text(name_node, self.src) if name_node else "<anonymous>"

        prev_class = self._current_class
        self._current_class = name

        self._push_scope("class", node, name=name)

        # Walk children to discover methods and attributes
        attribute_names = []

        for child in node.children:
            self._walk(child)

        # Count methods and attributes from what we collected
        class_scope = self._current_scope
        for asgn in self.result.assignments:
            if asgn.scope_id == class_scope and not asgn.is_parameter:
                if asgn.name not in attribute_names:
                    attribute_names.append(asgn.name)

        actual_methods = sum(1 for fd in self.result.function_defs if fd.parent_class == name)

        # Collect self.attr assignments as class attributes
        self_kw = self.config.self_keyword
        if self_kw:
            for asgn in self.result.assignments:
                if asgn.value_node_type == "self_attr" and asgn.name not in attribute_names:
                    attribute_names.append(asgn.name)

        cdef = ClassDef(
            name=name,
            line=_line(node),
            end_line=_end_line(node),
            method_count=actual_methods,
            attribute_names=attribute_names,
            scope_id=self._scope_stack[-2] if len(self._scope_stack) >= 2 else 0,
        )
        self.result.class_defs.append(cdef)

        self._pop_scope()
        self._current_class = prev_class

    def _handle_assignment(self, node: TSNode) -> None:
        is_augmented = "augmented" in node.type or "compound" in node.type
        lang = self.language

        if lang == "python":
            self._handle_python_assignment(node, is_augmented)
        elif lang in ("javascript", "typescript"):
            self._handle_js_assignment(node, is_augmented)
        elif lang == "go":
            self._handle_go_assignment(node, is_augmented)
        elif lang == "rust":
            self._handle_rust_assignment(node, is_augmented)
        elif lang == "java":
            self._handle_java_assignment(node, is_augmented)
        elif lang == "csharp":
            self._handle_csharp_assignment(node, is_augmented)

    def _handle_for_loop_var(self, node: TSNode) -> None:
        """Extract for-loop target variable as an assignment.

        Python: for item in items → 'left' field is the loop variable
        JS/TS:  for (var x of items) → 'left' field
        Java:   for (Type x : items) → enhanced_for, name field
        Go:     for i, v := range items → 'left' field
        """
        # Try 'left' field first (Python, JS, Go)
        left = node.child_by_field_name("left")
        if left is None:
            # Java enhanced_for: try 'name' field
            left = node.child_by_field_name("name")
        if left is None:
            return

        # Extract the iterable expression for taint propagation
        # Python/JS/Go: 'right' field; Java enhanced_for: 'value' field
        iter_node = node.child_by_field_name("right") or node.child_by_field_name("value")
        iter_text = _get_text(iter_node, self.src)[:100] if iter_node else ""

        # Extract identifier(s) from the loop target
        if left.type == "identifier":
            name = _get_text(left, self.src)
            self.result.assignments.append(
                Assignment(
                    name=name,
                    line=_line(node),
                    scope_id=self._current_scope,
                    value_node_type="loop_variable",
                    value_text=iter_text,
                    is_parameter=False,
                    is_augmented=False,
                )
            )
        elif left.type in ("pattern_list", "tuple_pattern", "expression_list"):
            # Tuple unpacking in for: for a, b in items
            for child in left.children:
                if child.type == "identifier":
                    name = _get_text(child, self.src)
                    self.result.assignments.append(
                        Assignment(
                            name=name,
                            line=_line(node),
                            scope_id=self._current_scope,
                            value_node_type="loop_variable",
                            value_text="",
                            is_parameter=False,
                            is_augmented=False,
                        )
                    )

    def _handle_with_statement(self, node: TSNode) -> None:
        """Extract 'with X as Y' targets as assignments.

        Python tree-sitter: with_statement has with_clause children,
        each with_clause has a with_item child that may have an 'alias' field.
        Or directly: with_item nodes with value + alias fields.
        """
        for child in self._walk_all(node):
            if child.type == "as_pattern":
                # Python 3.10+ match-style: `with expr as name`
                # The alias is the last named child
                alias = child.child_by_field_name("alias")
                if alias and alias.type == "as_pattern_target":
                    for sub in alias.children:
                        if sub.type == "identifier":
                            self._record_assignment(
                                _get_text(sub, self.src), sub,
                                value_node_type="with_clause",
                            )
                elif alias and alias.type == "identifier":
                    self._record_assignment(
                        _get_text(alias, self.src), alias,
                        value_node_type="with_clause",
                    )
            # Some tree-sitter Python versions use with_item node
            # with 'value' and 'alias' fields directly
            if child.type == "with_item":
                alias = child.child_by_field_name("alias")
                if alias:
                    if alias.type == "identifier":
                        self._record_assignment(
                            _get_text(alias, self.src), alias,
                            value_node_type="with_clause",
                        )
                    else:
                        # Tuple unpacking: with X as (a, b)
                        for sub in alias.children:
                            if sub.type == "identifier":
                                self._record_assignment(
                                    _get_text(sub, self.src), sub,
                                    value_node_type="with_clause",
                                )

    def _handle_nonlocal(self, node: TSNode) -> None:
        """Track nonlocal declarations: nonlocal x, y → record names per scope."""
        scope_id = self._current_scope
        for child in node.children:
            if child.type == "identifier":
                name = _get_text(child, self.src)
                self.result.nonlocal_names.setdefault(scope_id, set()).add(name)

    def _record_assignment(
        self,
        name: str,
        node: TSNode,
        rhs_type: str = "",
        rhs_text: str = "",
        is_augmented: bool = False,
        value_node_type: str | None = None,
    ) -> None:
        """Record a variable assignment. Shared by all language handlers."""
        self.result.assignments.append(
            Assignment(
                name=name,
                line=_line(node),
                scope_id=self._current_scope,
                value_node_type=value_node_type or rhs_type,
                value_text=rhs_text,
                is_parameter=False,
                is_augmented=is_augmented,
            )
        )

    def _extract_lhs_rhs(self, node: TSNode) -> tuple[TSNode | None, TSNode | None]:
        """Extract left/right children from an assignment node."""
        left = node.child_by_field_name("left")
        right = node.child_by_field_name("right")
        return left, right

    def _rhs_info(self, right: TSNode) -> tuple[str, str]:
        """Extract type and text from an RHS node."""
        rhs_type = right.type if right else ""
        rhs_text = _get_text(right, self.src)[:500] if right else ""
        return rhs_type, rhs_text

    def _handle_python_assignment(self, node: TSNode, is_augmented: bool) -> None:
        if is_augmented:
            left, _ = self._extract_lhs_rhs(node)
            if left and left.type == "identifier":
                name = _get_text(left, self.src)
                self._record_assignment(name, node, value_node_type="augmented", is_augmented=True)
                self.result.references.append(
                    NameReference(
                        name=name,
                        line=_line(node),
                        scope_id=self._current_scope,
                        context="read",
                    )
                )
        else:
            left, right = self._extract_lhs_rhs(node)

            if left is None:
                children = [c for c in node.children if c.is_named]
                if len(children) >= 2:
                    left, right = children[0], children[-1]

            if left is None:
                return

            rhs_type, rhs_text = self._rhs_info(right)

            # Check for self.attr = ...
            self_kw = self.config.self_keyword
            if left.type in self._attr_types and self_kw:
                obj_node = left.child_by_field_name("object")
                attr_node = left.child_by_field_name("attribute")
                if obj_node and _get_text(obj_node, self.src) == self_kw and attr_node:
                    attr_name = _get_text(attr_node, self.src)
                    self._record_assignment(attr_name, node, rhs_text=rhs_text, value_node_type="self_attr")
                    return

            if left.type == "identifier":
                self._record_assignment(_get_text(left, self.src), node, rhs_type, rhs_text)
            elif left.type in ("pattern_list", "tuple_pattern"):
                for child in left.children:
                    if child.type == "identifier":
                        self._record_assignment(_get_text(child, self.src), node, rhs_type, rhs_text)

    def _handle_js_assignment(self, node: TSNode, is_augmented: bool) -> None:
        if node.type == "variable_declarator":
            name_node = node.child_by_field_name("name")
            value_node = node.child_by_field_name("value")
            if name_node and name_node.type == "identifier":
                rhs_type, rhs_text = self._rhs_info(value_node)
                self._record_assignment(_get_text(name_node, self.src), node, rhs_type, rhs_text)
        elif node.type in ("assignment_expression", "augmented_assignment_expression"):
            left, right = self._extract_lhs_rhs(node)
            if left and left.type == "identifier":
                rhs_type, rhs_text = self._rhs_info(right)
                self._record_assignment(_get_text(left, self.src), node, rhs_type, rhs_text, is_augmented)

    def _handle_go_assignment(self, node: TSNode, is_augmented: bool) -> None:
        left, right = self._extract_lhs_rhs(node)
        if left:
            rhs_type, rhs_text = self._rhs_info(right)
            for child in left.children:
                if child.type == "identifier":
                    self._record_assignment(
                        _get_text(child, self.src),
                        node,
                        rhs_type,
                        rhs_text,
                        is_augmented=(is_augmented and node.type != "short_var_declaration"),
                    )

    def _handle_rust_assignment(self, node: TSNode, is_augmented: bool) -> None:
        if node.type == "let_declaration":
            pat = node.child_by_field_name("pattern")
            value = node.child_by_field_name("value")
            if pat and pat.type == "identifier":
                rhs_type = value.type if value else ""
                self._record_assignment(_get_text(pat, self.src), node, rhs_type)
        elif node.type in ("assignment_expression", "compound_assignment_expr"):
            left, _ = self._extract_lhs_rhs(node)
            if left and left.type == "identifier":
                self._record_assignment(_get_text(left, self.src), node, is_augmented=is_augmented)

    def _handle_java_assignment(self, node: TSNode, is_augmented: bool) -> None:
        if node.type == "local_variable_declaration":
            for child in node.children:
                if child.type == "variable_declarator":
                    name_node = child.child_by_field_name("name")
                    value_node = child.child_by_field_name("value")
                    if name_node and name_node.type == "identifier":
                        rhs_type, rhs_text = self._rhs_info(value_node)
                        self._record_assignment(
                            _get_text(name_node, self.src), node, rhs_type, rhs_text,
                        )
        elif node.type == "assignment_expression":
            left, right = self._extract_lhs_rhs(node)
            if left and left.type == "identifier":
                rhs_type, rhs_text = self._rhs_info(right)
                self._record_assignment(
                    _get_text(left, self.src), node, rhs_type, rhs_text,
                    is_augmented=is_augmented,
                )

    def _handle_csharp_assignment(self, node: TSNode, is_augmented: bool) -> None:
        if node.type == "variable_declarator":
            name_node = node.child_by_field_name("name") or (
                node.children[0] if node.children and node.children[0].type == "identifier" else None
            )
            value_node = node.child_by_field_name("value") or (
                node.children[-1] if len(node.children) > 1 else None
            )
            if name_node and name_node.type == "identifier":
                rhs_type, rhs_text = self._rhs_info(value_node) if value_node else ("", "")
                self._record_assignment(
                    _get_text(name_node, self.src), node, rhs_type, rhs_text,
                )
        elif node.type == "assignment_expression":
            left, right = self._extract_lhs_rhs(node)
            if left and left.type == "identifier":
                rhs_type, rhs_text = self._rhs_info(right)
                self._record_assignment(
                    _get_text(left, self.src), node, rhs_type, rhs_text,
                    is_augmented=is_augmented,
                )

    def _handle_call(self, node: TSNode) -> None:
        # Handle Java/C# constructor calls: new Foo(...)
        if node.type == "object_creation_expression":
            self._handle_constructor_call(node)
            return

        func_node = node.child_by_field_name("function")
        if func_node is None:
            # Java method_invocation uses "name" and "object" fields
            func_node = node.child_by_field_name("name")

        if func_node is None:
            return

        receiver = None
        name = ""

        if func_node.type == "identifier":
            name = _get_text(func_node, self.src)
        elif func_node.type in self._attr_types:
            # obj.method()
            # Go uses "operand"/"field", others use "object"/"attribute"
            obj = func_node.child_by_field_name("object") or func_node.child_by_field_name("operand")
            attr = func_node.child_by_field_name("attribute") or func_node.child_by_field_name("field")
            if obj:
                receiver = _get_text(obj, self.src)
            if attr:
                name = _get_text(attr, self.src)
            else:
                name = _get_text(func_node, self.src)
        else:
            name = _get_text(func_node, self.src)

        # For Java, also check "object" field on the method_invocation itself
        if not receiver and node.type == "method_invocation":
            obj = node.child_by_field_name("object")
            if obj:
                receiver = _get_text(obj, self.src)

        # Count arguments
        args_node = node.child_by_field_name("arguments")
        arg_count = 0
        if args_node:
            for child in args_node.children:
                if child.is_named and child.type not in ("(", ")", ","):
                    arg_count += 1

        self.result.function_calls.append(
            FunctionCall(
                name=name,
                line=_line(node),
                scope_id=self._current_scope,
                arg_count=arg_count,
                receiver=receiver,
            )
        )

    def _handle_constructor_call(self, node: TSNode) -> None:
        """Handle Java/C# constructor calls: new Foo(...) or new pkg.Foo(...)."""
        # Extract class name from the type child
        type_node = node.child_by_field_name("type")
        if type_node is None:
            # Fallback: look for type_identifier or scoped_type_identifier
            for child in node.children:
                if child.type in ("type_identifier", "scoped_type_identifier",
                                  "generic_type"):
                    type_node = child
                    break
        if type_node is None:
            return

        class_name = _get_text(type_node, self.src)
        # Strip package qualifier for matching (java.io.File → File)
        simple_name = class_name.rsplit(".", 1)[-1] if "." in class_name else class_name
        # Build "new ClassName(" to match taint sink patterns
        name = f"new {simple_name}("

        # Count arguments
        args_node = node.child_by_field_name("arguments")
        arg_count = 0
        if args_node:
            for child in args_node.children:
                if child.is_named and child.type not in ("(", ")", ","):
                    arg_count += 1

        self.result.function_calls.append(
            FunctionCall(
                name=name,
                line=_line(node),
                scope_id=self._current_scope,
                arg_count=arg_count,
                receiver=None,
            )
        )

    # Parent types where the identifier is part of a declaration/import
    _SKIP_PARENTS = frozenset((
        "import_statement",
        "import_from_statement",
        "import_specifier",
        "import_clause",
        "dotted_name",
        "aliased_import",
        "import_declaration",
        "import_spec",
        "use_declaration",
        "using_directive",
    ))

    # Parent types where the identifier is a parameter name
    _PARAM_PARENTS = frozenset((
        "parameters",
        "formal_parameters",
        "parameter_list",
        "typed_parameter",
        "default_parameter",
        "typed_default_parameter",
        "parameter",
        "formal_parameter",
        "required_parameter",
    ))

    # Parent types where the identifier is the "name" field and should be skipped
    _NAME_FIELD_SKIP_PARENTS = frozenset((
        "keyword_argument",
        "variable_declarator",
    ))

    def _should_skip_identifier(self, node: TSNode, parent: TSNode) -> bool:
        """Return True if this identifier is a declaration/LHS that should not be recorded."""
        parent_type = parent.type

        if parent_type in self._SKIP_PARENTS:
            return True

        if parent_type in self._PARAM_PARENTS:
            return True

        # Name field of function/class definition
        if parent_type in self._func_types or parent_type in self._class_types:
            return self._is_name_field(node, parent)

        # LHS of assignment
        if parent_type in self._assignment_types:
            return self._is_assignment_lhs(node, parent)

        # Parent types where we check the "name" field
        if parent_type in self._NAME_FIELD_SKIP_PARENTS:
            return self._is_name_field(node, parent)

        # let_declaration pattern
        if parent_type == "let_declaration":
            pat = parent.child_by_field_name("pattern")
            return pat is not None and pat.id == node.id

        # short_var_declaration left side
        if parent_type == "short_var_declaration":
            left = parent.child_by_field_name("left")
            if left:
                return any(child.id == node.id for child in left.children)

        return False

    @staticmethod
    def _is_name_field(node: TSNode, parent: TSNode) -> bool:
        """Check if node is the 'name' field of its parent."""
        name_field = parent.child_by_field_name("name")
        return name_field is not None and name_field.id == node.id

    def _is_assignment_lhs(self, node: TSNode, parent: TSNode) -> bool:
        """Check if node is the left-hand side of an assignment."""
        left = parent.child_by_field_name("left")
        if left and left.id == node.id:
            return True
        if parent.type == "assignment":
            children = [c for c in parent.children if c.is_named]
            if children and children[0].id == node.id:
                return True
        return False

    def _resolve_identifier_context(self, node: TSNode, parent: TSNode) -> tuple[str, str | None]:
        """Determine context ('read', 'call', 'attribute_access') and receiver for an identifier."""
        parent_type = parent.type
        context = "read"
        receiver: str | None = None

        if parent_type in self._call_types:
            func = parent.child_by_field_name("function")
            if func and func.id == node.id:
                context = "call"

        if parent_type in self._attr_types:
            attr_node = parent.child_by_field_name("attribute") or parent.child_by_field_name("field")
            if attr_node and attr_node.id == node.id:
                context = "attribute_access"
                obj_node = parent.child_by_field_name("object") or parent.child_by_field_name("operand")
                if obj_node and obj_node.type == "identifier":
                    receiver = _get_text(obj_node, self.src)
            else:
                context = "read"

        return context, receiver

    def _handle_identifier(self, node: TSNode) -> None:
        parent = node.parent
        if parent is None:
            return

        if self._should_skip_identifier(node, parent):
            return

        name = _get_text(node, self.src)
        context, receiver = self._resolve_identifier_context(node, parent)

        self.result.references.append(
            NameReference(
                name=name,
                line=_line(node),
                scope_id=self._current_scope,
                context=context,
                receiver=receiver,
            )
        )

    def _extract_params(self, func_node) -> list[str]:
        """Extract parameter names from a function node."""
        params: list[str] = []
        for child in func_node.children:
            if child.type in ("parameters", "formal_parameters", "parameter_list"):
                self._collect_param_names(child, params)
                break
        return params

    # Compound parameter node types where the first identifier child is the name
    _COMPOUND_PARAM_TYPES = frozenset((
        "typed_parameter",
        "default_parameter",
        "typed_default_parameter",
        "parameter",
        "formal_parameter",
        "required_parameter",
    ))

    # Splat/rest pattern types where we extract the identifier child
    _SPLAT_PARAM_TYPES = frozenset((
        "list_splat_pattern", "dictionary_splat_pattern", "rest_pattern",
    ))

    def _collect_param_names(self, param_list: TSNode, params: list[str]) -> None:
        """Recursively collect parameter names."""
        for child in param_list.children:
            if child.type in self._COMPOUND_PARAM_TYPES:
                self._collect_param_names(child, params)
                continue

            if child.type in self._SPLAT_PARAM_TYPES:
                # *args, **kwargs in Python / ...rest in JS
                for sub in child.children:
                    if sub.type == "identifier":
                        params.append(_get_text(sub, self.src))
                continue

            if child.type != "identifier":
                continue

            parent_type = child.parent.type if child.parent else ""

            # Direct child of parameter list — simple parameter name
            if parent_type in ("parameters", "formal_parameters", "parameter_list"):
                params.append(_get_text(child, self.src))
                continue

            if parent_type not in self._COMPOUND_PARAM_TYPES:
                continue

            # Compound parameter — use name field or first-identifier heuristic
            name_field = child.parent.child_by_field_name("name")
            if name_field is not None:
                if name_field.id == child.id:
                    params.append(_get_text(child, self.src))
                continue

            # Fallback: first identifier child is the name (tree-sitter Python)
            first_id = next(
                (c for c in child.parent.children if c.type == "identifier"),
                None,
            )
            if first_id is not None and first_id.id == child.id:
                params.append(_get_text(child, self.src))

    def _has_varargs(self, func_node) -> bool:
        """Check if function has *args/**kwargs or ...rest."""
        for child in func_node.children:
            if child.type in ("parameters", "formal_parameters", "parameter_list"):
                for param in self._walk_all(child):
                    if param.type in (
                        "list_splat_pattern",
                        "dictionary_splat_pattern",
                        "rest_pattern",
                        "spread_element",
                    ):
                        return True
        return False

    def _walk_all(self, node: TSNode) -> Iterator[TSNode]:
        """Simple tree walker."""
        yield node
        for child in node.children:
            yield from self._walk_all(child)


# ─── Entry point ─────────────────────────────────────────────────────


def extract_semantics(content: str, filepath: str, language: str) -> FileSemantics | None:
    """Single-pass extraction. Returns None if tree-sitter unavailable."""
    config = get_config(language)
    if config is None:
        return None

    # Need at least assignment or call types to do anything useful
    if not config.assignment_node_types and not config.call_node_types:
        return None

    try:
        from tree_sitter_language_pack import get_parser
    except ImportError:
        return None

    try:
        parser = get_parser(config.ts_language_name)  # type: ignore[arg-type]  # tree-sitter-language-pack has no stubs
    except (LookupError, ValueError, RuntimeError):
        return None

    source_bytes = content.encode("utf-8")
    try:
        tree = parser.parse(source_bytes)
    except (MemoryError, RecursionError):
        logger.warning("Tree-sitter parsing failed (resource limit) for %s", filepath)
        return None

    # Guard against pathologically deep ASTs
    def _tree_depth(node: object, max_depth: int = 1000) -> int:
        """Iterative DFS to find actual maximum tree depth."""
        max_seen = 0
        stack = [(node, 0)]
        while stack:
            current, depth = stack.pop()
            if depth > max_seen:
                max_seen = depth
                if max_seen > max_depth:
                    return max_seen
            if current.child_count > 0:
                for child in current.children:
                    stack.append((child, depth + 1))
        return max_seen

    if _tree_depth(tree.root_node) > 1000:
        logger.warning("AST too deep (>1000) for %s, skipping semantic analysis", filepath)
        return None

    extractor = _Extractor(source_bytes, config, filepath, language)
    extractor.extract(tree.root_node)
    # Store source lines (1-indexed via dummy at [0]) for effective-line counting
    extractor.result.source_lines = [""] + content.splitlines()
    # Cache tree root to avoid double parsing in CFG construction
    extractor.result._tree_root = tree.root_node
    return extractor.result
