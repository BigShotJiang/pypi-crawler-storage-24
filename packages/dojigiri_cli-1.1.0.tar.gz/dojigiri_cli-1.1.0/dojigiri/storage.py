"""Persistent JSON reports and file hash caching for incremental scans.

Saves scan results to timestamped JSON files and maintains a SHA-256 hash
cache so unchanged files can be skipped on subsequent runs.

Called by: analyzer.py, __main__.py.
Calls into: config.py (report paths only).
Data in → Data out: ScanReport / file paths in → JSON files + SHA-256 cache out.
"""

from __future__ import annotations  # noqa

import hashlib
import json
import logging
import os
import re
import subprocess
import sys

logger = logging.getLogger(__name__)
from datetime import datetime
from pathlib import Path

from . import __version__
from .config import CACHE_FILE, REPORTS_DIR, STORAGE_DIR
from .types import ScanReport


def ensure_dirs() -> None:
    """Create storage directories if they don't exist."""
    STORAGE_DIR.mkdir(parents=True, exist_ok=True)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    # Restrict permissions (owner-only access to scan reports)
    if sys.platform != "win32":
        os.chmod(STORAGE_DIR, 0o700)
        os.chmod(REPORTS_DIR, 0o700)
    else:
        # Windows: restrict via icacls (best-effort)
        # SECURITY: Validate USERNAME to prevent ACL poisoning.
        # A malicious USERNAME env var (e.g. "Everyone") would grant
        # unintended principals full control over scan report directories.
        try:
            username = os.environ.get("USERNAME", "")
            if username and re.match(r"^[a-zA-Z0-9._\- ]+$", username) and len(username) <= 104:
                # Reject well-known group names that would widen access
                _DANGEROUS_PRINCIPALS = {
                    "everyone",
                    "users",
                    "authenticated users",
                    "guests",
                    "domain users",
                    "network",
                    "interactive",
                    "system",
                    "local service",
                    "network service",
                    "anonymous logon",
                }
                if username.lower().strip() not in _DANGEROUS_PRINCIPALS:
                    for d in (STORAGE_DIR, REPORTS_DIR):
                        subprocess.run(
                            ["icacls", str(d), "/inheritance:r", "/grant:r", f"{username}:(OI)(CI)F"],
                            capture_output=True,
                            timeout=5,
                        )
                else:
                    logger.warning(
                        "Refusing to grant ACL to dangerous principal '%s' — "
                        "scan reports directory left with inherited permissions",
                        username,
                    )
        except (OSError, subprocess.TimeoutExpired) as e:
            logger.debug("Failed to set directory permissions: %s", e)


def file_hash(filepath: str) -> str:
    """Compute SHA256 hash of file contents."""
    h = hashlib.sha256()
    with open(filepath, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def load_cache() -> dict:
    """Load file hash cache from disk. Invalidates if version changed."""
    if CACHE_FILE.exists():
        try:
            data = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {"__version__": __version__}
        # Invalidate cache if version changed
        if data.get("__version__") != __version__:
            return {"__version__": __version__}
        return data
    return {"__version__": __version__}


def save_cache(cache: dict) -> None:
    """Save file hash cache to disk."""
    ensure_dirs()
    cache["__version__"] = __version__
    CACHE_FILE.write_text(json.dumps(cache, indent=2), encoding="utf-8")


def save_report(report: ScanReport) -> Path:
    """Save scan report as JSON."""
    ensure_dirs()
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report.timestamp = datetime.now().isoformat()
    filename = f"scan_{timestamp}.json"
    filepath = REPORTS_DIR / filename

    data = report.to_dict()
    filepath.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # Also save as "latest"
    latest = REPORTS_DIR / "latest.json"
    latest.write_text(json.dumps(data, indent=2), encoding="utf-8")

    # Auto-prune: keep only last 50 reports
    _prune_reports(max_keep=50)

    return filepath


def _prune_reports(max_keep: int = 50) -> None:
    """Remove old reports, keeping only the most recent max_keep."""
    reports = sorted(REPORTS_DIR.glob("scan_*.json"), reverse=True)
    for old in reports[max_keep:]:
        try:
            old.unlink()
        except OSError as e:
            logger.debug("Failed to delete old report: %s", e)


def load_latest_report() -> dict | None:
    """Load the most recent scan report."""
    latest = REPORTS_DIR / "latest.json"
    if latest.exists():
        try:
            return json.loads(latest.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return None
    return None


def load_baseline_report(baseline: str) -> dict | None:
    """Load a baseline report for comparison.

    Args:
        baseline: Either "latest" or a path to a specific report file.
                  Path must be under REPORTS_DIR or cwd to prevent
                  reading arbitrary files.

    Returns:
        Baseline report dict or None if not found/invalid
    """
    if baseline == "latest":
        return load_latest_report()

    # Validate: baseline path must resolve under REPORTS_DIR or cwd.
    # Without this, --baseline could read any JSON file on disk.
    baseline_path = Path(baseline).resolve()
    cwd = Path.cwd().resolve()
    reports_dir = REPORTS_DIR.resolve()
    if not (baseline_path.is_relative_to(reports_dir) or baseline_path.is_relative_to(cwd)):
        logger.warning(
            "Rejecting baseline path '%s' — must be under reports dir (%s) or cwd (%s)",
            baseline,
            reports_dir,
            cwd,
        )
        return None

    if not baseline_path.exists():
        return None

    try:
        return json.loads(baseline_path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def list_reports() -> list[Path]:
    """List all saved reports, most recent first."""
    ensure_dirs()
    reports = sorted(REPORTS_DIR.glob("scan_*.json"), reverse=True)
    return reports
