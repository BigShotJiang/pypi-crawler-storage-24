from typing import Any, Optional
from abc import ABC, abstractmethod

from vicentin.utils import Dispatcher
from vicentin.utils.logging import info, debug

disp_kernel_backend = Dispatcher()
disp_eye = Dispatcher()

try:
    from .kernel_np import KernelBackendNumpy
    import numpy as np

    disp_kernel_backend.register("numpy", KernelBackendNumpy)
    disp_eye.register("numpy", lambda n, x: np.eye(n, dtype=x.dtype))
except ImportError:
    pass

try:
    from .kernel_torch import KernelBackendTorch
    import torch

    disp_kernel_backend.register("torch", KernelBackendTorch)
    disp_eye.register(
        "torch", lambda n, x: torch.eye(n, device=x.device, dtype=x.dtype)
    )
except ImportError:
    pass


class Kernel(ABC):
    def __init__(
        self,
        X: Optional[Any] = None,
        alpha: float = 1e-6,
        chunk_size: Optional[int] = None,
        backend_verbose: bool = False,
        backend: Optional[str] = None,
    ) -> None:
        super().__init__()

        self.is_dense = chunk_size is None

        self._alpha = alpha
        self._chunk_size = chunk_size
        self._disp_backend = backend
        self._backend_verbose = backend_verbose
        self._trace = None

        self.X = None

        if X is not None:
            self.set_X(X)

    def set_X(self, X: Any):
        if X is None:
            raise ValueError("X is None.")

        ctx = disp_kernel_backend.detect_backend(X, self._disp_backend)
        X = disp_kernel_backend.cast_values(ctx, X)

        ctx.debug_level = not self._backend_verbose

        debug(f"Initializing {type(self).__name__} with backend: {ctx.backend}")
        self.backend = disp_kernel_backend(
            ctx, self._compute, X, self._alpha, self._chunk_size
        )

        self.X = self.backend.X
        self.N = self.backend.N
        self._trace = None

        info(
            f"Kernel bound to data with N={self.N}. Mode: {'Dense' if self.is_dense else 'Chunked'}"
        )

    def center(self):
        return CenteredKernel(self)

    @abstractmethod
    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        pass

    def __setattr__(self, name: str, value: Any) -> None:
        if (
            type(value).__name__ == "Parameter"
            and "torch" in type(value).__module__
        ):
            if hasattr(self, "backend") and hasattr(
                self.backend, "register_parameter"
            ):
                self.backend.register_parameter(name, value)

        super().__setattr__(name, value)

    def apply(self, X: Any, v: Any) -> Any:
        return self.backend.apply_v(X, v)

    def trace(self) -> float:
        if self._trace is None:
            debug(f"Computing trace for {type(self).__name__}...")
            self._trace = self.backend.trace()
            debug(f"Trace computed: {self._trace:.4f}")

        return self._trace

    @property
    def T(self):
        return self

    def __getitem__(self, key) -> Any:
        return self.backend[key]

    def __matmul__(self, v) -> Any:
        return self.backend @ v

    def __call__(self, x: Any, y: Optional[Any] = None) -> Any:
        return self.backend(x, y)

    def __add__(self, other):
        debug(
            f"Composing SumKernel: {type(self).__name__} + {type(other).__name__}"
        )
        if isinstance(other, Kernel):
            return SumKernel(self, other)
        elif isinstance(other, (int, float)):
            return SumKernel(self, ConstantKernel(self.backend.X, other))

        return SumKernel(self, MatrixKernel(other))

    def __radd__(self, other):
        return self.__add__(other)

    def __mul__(self, other):
        if isinstance(other, Kernel):
            debug(
                f"Composing ProductKernel: {type(self).__name__} * {type(other).__name__}"
            )
            return ProductKernel(self, other)

        debug(f"Scaling {type(self).__name__} by {other}")
        return ScaledKernel(self, other)

    def __pow__(self, exponent):
        debug(f"Raising {type(self).__name__} to power {exponent}")
        return PowerKernel(self, exponent)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            return ScaledKernel(self, float(1 / other))

        return NotImplemented

    @property
    def shape(self):
        return (self.N, self.N)


class SumKernel(Kernel):
    def __init__(self, k1: Kernel, k2: Kernel, **kwargs):
        self.k1 = k1
        self.k2 = k2

        kwargs.setdefault("chunk_size", k1._chunk_size)
        kwargs.setdefault("alpha", k1._alpha)

        super().__init__(k1.X, **kwargs)

    def set_X(self, X: Any):
        super().set_X(X)

        self.k1.set_X(X)
        self.k2.set_X(X)

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.k1(x, y) + self.k2(x, y)


class ProductKernel(Kernel):
    def __init__(self, k1: Kernel, k2: Kernel, **kwargs):
        self.k1 = k1
        self.k2 = k2

        kwargs.setdefault("chunk_size", k1._chunk_size)
        kwargs.setdefault("alpha", k1._alpha)

        super().__init__(k1.X, **kwargs)

    def set_X(self, X: Any):
        super().set_X(X)

        self.k1.set_X(X)
        self.k2.set_X(X)

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.k1(x, y) * self.k2(x, y)


class ConstantKernel(Kernel):
    def __init__(self, X: Any, c: float, **kwargs):
        super().__init__(X, **kwargs)
        self.c = float(c)

        self.disp_full = Dispatcher()

        try:
            import numpy as np

            self.disp_full.register("numpy", np.full)
        except ImportError:
            pass

        try:
            import torch

            self.disp_full.register("torch", torch.full)
        except ImportError:
            pass

    def _compute(self, x: Any, y: Optional[Any] = None):
        ctx = self.disp_full.detect_backend(x)
        ctx.verbose = False

        n_x = x.shape[0] if getattr(x, "ndim", 0) > 0 else 1
        n_y = y.shape[0] if y is not None else n_x

        return self.disp_full(ctx, (n_x, n_y), self.c)


class ScaledKernel(Kernel):
    def __init__(self, K: Kernel, c: float, **kwargs):
        self.K = K
        self.c = c

        super().__init__(K.X, **kwargs)

    def set_X(self, X: Any):
        super().set_X(X)
        self.K.set_X(X)

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.c * self.K(x, y)


class PowerKernel(Kernel):
    def __init__(self, K: Kernel, d: float, **kwargs):
        self.K = K
        self.d = d

        super().__init__(K.X, **kwargs)

    def set_X(self, X: Any):
        super().set_X(X)
        self.K.set_X(X)

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.K(x, y) ** self.d


class CenteredKernel(Kernel):
    def __init__(self, K: Kernel, **kwargs):
        self.K = K
        self.row_means = None
        self.mean = None

        super().__init__(K.X, **kwargs)

    def set_X(self, X: Any):
        super().set_X(X)
        self.K.set_X(X)

        self.row_means = None
        self.mean = None

    def _compute_training_statistics(self):
        n = self.N
        debug(f"Centering kernel: computing statistics for N={n}")
        if "torch" in str(type(self.X)):
            import torch

            ones = torch.ones((n, 1), device=self.X.device, dtype=self.X.dtype)
        else:
            import numpy as np

            ones = np.ones((n, 1))

        sum_rows = self.K @ ones
        self.row_means = sum_rows.squeeze() / n
        self.mean = self.row_means.mean()

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        if self.row_means is None or self.mean is None:
            self._compute_training_statistics()

        K_xy = self.K(x, y)

        if x is self.X:
            x_means = self.row_means[:, None]
        else:
            x_means = self.K(x, self.X).mean(axis=1)[:, None]

        if y is None or y is self.X:
            y_means = self.row_means[None, :]
        else:
            y_means = self.K(self.X, y).mean(axis=0)[None, :]

        return K_xy - x_means - y_means + self.mean

    def trace(self) -> float:
        if self.mean is None:
            self._compute_training_statistics()
        return self.K.trace() - (self.N * self.mean)


class MatrixKernel(Kernel):
    def __init__(self, M: Any, **kwargs):
        super().__init__(None, **kwargs)
        self.M = M
        self._index_map = None
        self.disp_slice = Dispatcher()

        try:
            import numpy as np

            self.disp_slice.register("numpy", lambda m, i, j: m[np.ix_(i, j)])
        except ImportError:
            pass

        try:
            self.disp_slice.register("torch", lambda m, i, j: m[i][:, j])
        except ImportError:
            pass

    def set_X(self, X: Any):
        super().set_X(X)

        if "torch" in str(type(X)):
            self._index_map = {
                tuple(row.tolist()): i for i, row in enumerate(X)
            }
        else:
            self._index_map = {tuple(row): i for i, row in enumerate(X)}

    def _get_indices(self, data: Any):
        indices = []
        for row in data:
            row_tuple = (
                tuple(row.tolist()) if hasattr(row, "tolist") else tuple(row)
            )
            idx = self._index_map.get(row_tuple)
            if idx is None:
                raise ValueError("Point not found in MatrixKernel index.")
            indices.append(idx)
        return indices

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        ctx = self.disp_slice.detect_backend(x)
        i = self._get_indices(x)

        if y is None:
            return self.M[i]

        j = self._get_indices(y)

        return self.disp_slice(ctx, self.M, i, j)
