"""Pre-built domain libraries."""
