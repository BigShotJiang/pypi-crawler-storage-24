"""Core generation engine."""
