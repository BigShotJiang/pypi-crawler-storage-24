"""
Example Django settings configuration for django-rw-router.

This demonstrates how to configure django-rw-router in your Django project.
"""

# Database Configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'myapp',
        'USER': 'db_user',
        'PASSWORD': 'db_password',
        'HOST': 'primary-db.example.com',
        'PORT': '5432',
    },
    'readonly': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'myapp',
        'USER': 'readonly_user',
        'PASSWORD': 'readonly_password',
        'HOST': 'replica-db.example.com',
        'PORT': '5432',
    },
}

# Router Configuration - Choose one based on your needs

# Option 1: Basic read-write separation
DATABASE_ROUTERS = [
    'django_rw_router.routers.PrimaryReplicaRouter',
]

# Option 2: Transaction-aware routing (Recommended)
# DATABASE_ROUTERS = [
#     'django_rw_router.routers.TransactionPrimaryReplicaRouter',
# ]

# Option 3: Consistent hash routing for monotonic reads
# DATABASE_ROUTERS = [
#     'django_rw_router.routers.hash.HashPrimaryReplicaRouter',
# ]

# Middleware Configuration
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    # Add RequestContextMiddleware for hash routing support
    'django_rw_router.middleware.RequestContextMiddleware',
]

# Optional: Custom configuration for django-rw-router

# Configure read replicas (single string or list)
DJANGO_RW_ROUTER_READ_DBS = ['readonly']

# Configure write database
DJANGO_RW_ROUTER_WRITE_DB = 'default'

# Configure hash ring virtual nodes (only for HashPrimaryReplicaRouter)
DJANGO_RW_ROUTER_HASH_VIRTUAL_NODES = 40

# Configure how to extract user_id from request (nested attributes supported)
DJANGO_RW_ROUTER_USER_ID_ATTR = 'user.id'

# Configure how to extract request_id from request
DJANGO_RW_ROUTER_REQUEST_ID_ATTR = 'id'

# QuerySet configuration (optional)
# Force all PrimaryQuerySet reads to use primary database
# DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE = True

# Enable @use_primary_db decorator for specific methods
# DJANGO_RW_ROUTER_METHOD_USING_ENABLE = True
