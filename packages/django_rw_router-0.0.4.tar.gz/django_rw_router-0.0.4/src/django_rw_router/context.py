"""Request context management for database routing.

This module provides a thread-safe context storage using Python's contextvars
for managing request-scoped data like user_id and request_id.
"""

from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any


@dataclass
class RequestContextData:
    """Request context data stored in context variables.

    Attributes:
        user_id: User identifier for consistent hash routing
        request_id: Unique request identifier for tracing
        orm_write: Flag indicating if ORM write operation occurred
        using: Database alias being used
        extra: Additional metadata as key-value pairs
    """

    user_id: int | None = None
    request_id: str | None = None
    orm_write: bool = False
    using: str | None = None
    extra: dict[str, Any] = field(default_factory=dict)


_context_var: ContextVar[RequestContextData | None] = ContextVar(
    "django_rw_router_context", default=None
)


class RequestContext:
    """Thread-safe request context manager using contextvars.

    This class provides static methods for managing request-scoped context
    across async and sync code. The context is automatically propagated
    using Python's contextvars module.

    Example:
        ```python
        # Set context at request start
        RequestContext.set_context(user_id=123, request_id="abc")

        # Get context anywhere in the request handling
        ctx = RequestContext.get_context()
        if ctx:
            print(ctx.user_id)

        # Clear context at request end
        RequestContext.reset()
        ```
    """

    @staticmethod
    def set_context(
        user_id: int | None = None, request_id: str | None = None, **kwargs
    ) -> None:
        """Set a new request context.

        Args:
            user_id: User identifier for consistent hash routing
            request_id: Unique request identifier
            **kwargs: Additional context key-value pairs, including 'extra' dict
        """
        # Extract extra from kwargs to prevent nesting
        extra = kwargs.pop("extra", {})
        _context_var.set(
            RequestContextData(user_id=user_id, request_id=request_id, extra=extra)
        )

    @staticmethod
    def get_context() -> RequestContextData | None:
        """Get the current request context.

        Returns:
            RequestContextData if context is set, None otherwise
        """
        return _context_var.get()

    @staticmethod
    def reset() -> None:
        """Clear the current request context.

        This should be called at the end of each request to prevent
        context leakage between requests.
        """
        _context_var.set(None)

    @staticmethod
    def update_context(**kwargs) -> None:
        """Update the current request context with new values.

        Args:
            **kwargs: Key-value pairs to update in the context.
                Special handling for 'extra' key which updates the extra dict
                rather than replacing it.
        """
        current_context = _context_var.get()
        if not current_context:
            return

        # Handle extra dict merge
        if "extra" in kwargs:
            extra = kwargs.pop("extra")
            if isinstance(extra, dict):
                current_context.extra.update(extra)

        # Update other attributes
        for key, value in kwargs.items():
            if hasattr(current_context, key):
                setattr(current_context, key, value)

        _context_var.set(current_context)
