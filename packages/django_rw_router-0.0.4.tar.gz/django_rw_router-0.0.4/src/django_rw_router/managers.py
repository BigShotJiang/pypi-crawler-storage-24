"""Django managers for forcing primary database reads.

This module provides custom QuerySet and Manager classes that can force
read operations to use the primary database. This is useful when you need
to ensure data consistency for specific queries.

Two configuration strategies are supported:

1. **Global Configuration**: Enable for all models via settings
2. **Decorator-based**: Enable for specific methods

Configuration:
    ```python
    # settings.py

    # Strategy 1: All PrimaryQuerySet reads use primary database
    DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE = True

    # Strategy 2: Only methods decorated with @use_primary_db use primary
    DJANGO_RW_ROUTER_METHOD_USING_ENABLE = True
    ```

Usage:
    ```python
    from django.db import models
    from django_rw_router.managers import PrimaryManager

    class MyModel(models.Model):
        objects = PrimaryManager()  # Use PrimaryQuerySet by default
    ```
"""

import logging
from functools import wraps
from typing import Callable, TypeVar

from django.conf import settings
from django.db import models
from django.db.models.manager import BaseManager

logger = logging.getLogger(__name__)

F = TypeVar("F", bound=Callable[..., object])

# Default configuration
QUERYSET_USING_ENABLED = False
METHOD_USING_ENABLED = False

# Settings keys
QUERYSET_USING_KEY = "DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE"
METHOD_USING_KEY = "DJANGO_RW_ROUTER_METHOD_USING_ENABLE"


def _get_queryset_using_enabled() -> bool:
    """Get the global QuerySet using-enabled setting.

    Returns:
        True if QuerySet reads should use primary database
    """
    return getattr(settings, QUERYSET_USING_KEY, QUERYSET_USING_ENABLED)


def _get_method_using_enabled() -> bool:
    """Get the method-level using-enabled setting.

    Returns:
        True if decorated methods should use primary database
    """
    return getattr(settings, METHOD_USING_KEY, METHOD_USING_ENABLED)


def use_primary_db(func: F) -> F:
    """Decorator to force QuerySet methods to use primary database.

    When enabled via ``DJANGO_RW_ROUTER_METHOD_USING_ENABLE` setting,
    the decorated method will route reads to the primary database.

    This is useful for methods like ``first()``, ``last()``, ``exists()``,
    and ``count()`` where you often need consistent data.

    Example:
        ```python
        class MyQuerySet(models.QuerySet):
            @use_primary_db
            def first(self):
                return super().first()
        ```

    Args:
        func: The QuerySet method to decorate

    Returns:
        Wrapped function that routes to primary database when enabled
    """

    @wraps(func)
    def wrapper(self=None, *args, **kwargs):
        enabled = _get_method_using_enabled()
        if enabled:
            logger.info(
                f"use_primary_db: {func.__name__} routing to primary database"
            )
            # Only apply .using() if self looks like a QuerySet
            if self is not None and hasattr(self, "using"):
                self = self.using("default")
        return func(self, *args, **kwargs) if self is not None else func(*args, **kwargs)

    return wrapper  # type: ignore[return-value]


class PrimaryQuerySet(models.QuerySet):
    """QuerySet that can force reads to use the primary database.

    When ``DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE`` is True, all read
    operations through this QuerySet will use the primary database.

    Key methods (``first()``, ``last()``, ``exists()``, ``count()``) are
    decorated with ``@use_primary_db`` for optional primary routing.

    Example:
        ```python
        from django.db import models
        from django_rw_router.managers import PrimaryQuerySet, PrimaryManager

        class MyModel(models.Model):
            objects = PrimaryManager()  # Uses PrimaryQuerySet

        # All reads use primary when enabled
        MyModel.objects.filter(active=True).first()
        ```
    """

    def __init__(self, model=None, query=None, using=None, hints=None):
        """Initialize the QuerySet with optional primary database routing.

        If ``DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE`` is True and no explicit
        ``using`` is provided, the QuerySet will use the primary database.

        Args:
            model: Model class
            query: Query instance
            using: Database alias to use
            hints: Query hints
        """
        super().__init__(model=model, query=query, using=using, hints=hints)
        self._apply_primary_routing(using)

    def _apply_primary_routing(self, using: str | None = None) -> None:
        """Apply primary database routing if enabled and no explicit using.

        Args:
            using: Database alias provided by user
        """
        # Don't override if user explicitly specified a database
        if using:
            return

        # Apply primary routing if enabled
        if _get_queryset_using_enabled():
            self._db = "default"

    @use_primary_db
    def first(self):
        """Get the first object, optionally using primary database."""
        return super().first()

    @use_primary_db
    def last(self):
        """Get the last object, optionally using primary database."""
        return super().last()

    @use_primary_db
    def exists(self):
        """Check if any objects exist, optionally using primary database."""
        return super().exists()

    @use_primary_db
    def count(self):
        """Count objects, optionally using primary database."""
        return super().count()


class PrimaryManager(BaseManager.from_queryset(PrimaryQuerySet)):
    """Manager that uses PrimaryQuerySet for queries.

    This manager provides all the functionality of Django's default manager
    with the addition of optional primary database routing.

    Example:
        ```python
        from django.db import models
        from django_rw_router.managers import PrimaryManager

        class MyModel(models.Model):
            objects = PrimaryManager()

        # Use like normal Django ORM
        obj = MyModel.objects.get(id=1)
        qs = MyModel.objects.filter(active=True)
        ```
    """

    pass
