"""Django middleware for request context management.

This module provides middleware for automatically managing request context
throughout the request lifecycle. The context is set at the beginning of
each request and cleared at the end.

Configuration:
    ```python
    # settings.py
    MIDDLEWARE = [
        ...
        'django_rw_router.middleware.RequestContextMiddleware',
    ]

    # Optional: Configure how to extract user_id and request_id
    DJANGO_RW_ROUTER_USER_ID_ATTR = 'user.id'  # Default
    DJANGO_RW_ROUTER_REQUEST_ID_ATTR = 'id'  # Default
    ```
"""

import logging
from typing import Any

from django.http import HttpRequest, HttpResponse

from django_rw_router.context import RequestContext

logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_USER_ID_ATTR = "user.id"
DEFAULT_REQUEST_ID_ATTR = "id"


def _get_nested_attr(obj: object, attr_path: str) -> Any:
    """Get a nested attribute from an object.

    Args:
        obj: Object to get attribute from
        attr_path: Dot-separated attribute path (e.g., 'user.id')

    Returns:
        Attribute value or None if not found
    """
    current = obj
    for attr in attr_path.split("."):
        if current is None:
            return None
        current = getattr(current, attr, None)
    return current


def _get_user_id(request: HttpRequest) -> int | None:
    """Extract user_id from the request.

    Args:
        request: HttpRequest object

    Returns:
        User ID or None
    """
    from django.conf import settings

    attr = getattr(settings, "DJANGO_RW_ROUTER_USER_ID_ATTR", DEFAULT_USER_ID_ATTR)
    return _get_nested_attr(request, attr)


def _get_request_id(request: HttpRequest) -> str | None:
    """Extract request_id from the request.

    Args:
        request: HttpRequest object

    Returns:
        Request ID or None
    """
    from django.conf import settings

    attr = getattr(
        settings, "DJANGO_RW_ROUTER_REQUEST_ID_ATTR", DEFAULT_REQUEST_ID_ATTR
    )
    result = _get_nested_attr(request, attr)
    return str(result) if result is not None else None


class RequestContextMiddleware:
    """Middleware for managing request context.

    This middleware:
    1. Sets RequestContext at the start of each request
    2. Clears RequestContext at the end of each request

    The context is used by routers like ``HashPrimaryReplicaRouter`` to
    provide consistent routing based on user_id.

    Example:
        ```python
        # settings.py
        MIDDLEWARE = [
            'django_rw_router.middleware.RequestContextMiddleware',
            # ... other middleware
        ]
        ```
    """

    def __init__(self, get_response):
        """Initialize the middleware.

        Args:
            get_response: The next middleware or view in the chain
        """
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        """Process the request and response.

        Args:
            request: The incoming HTTP request

        Returns:
            HTTP response from the view
        """
        # Set context for this request
        user_id = _get_user_id(request)
        request_id = _get_request_id(request)

        RequestContext.set_context(user_id=user_id, request_id=request_id)

        if logger.isEnabledFor(logging.DEBUG):
            logger.debug(
                f"RequestContextMiddleware: set context user_id={user_id} request_id={request_id}"
            )

        try:
            response = self.get_response(request)
            return response
        finally:
            # Always clear context, even if exception occurred
            RequestContext.reset()
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug("RequestContextMiddleware: cleared context")