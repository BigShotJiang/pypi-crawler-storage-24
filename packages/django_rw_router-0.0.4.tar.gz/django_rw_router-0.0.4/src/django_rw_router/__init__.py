"""Django Read-Write Router - Database read-write separation for Django.

This package provides database routers for Django that implement read-write
separation with various strategies:

- **PrimaryReplicaRouter**: Basic read-write separation
- **TransactionPrimaryReplicaRouter**: Transaction-aware routing
- **HashPrimaryReplicaRouter**: Consistent hash-based routing for monotonic reads
- **PrimaryManager/PrimaryQuerySet**: Force reads to primary database

Quick Start:
    ```python
    # settings.py
    DATABASE_ROUTERS = [
        'django_rw_router.routers.TransactionPrimaryReplicaRouter',
    ]

    DATABASES = {
        'default': {...},      # Primary (write)
        'readonly': {...},     # Replica (read)
    }

    MIDDLEWARE = [
        'django_rw_router.middleware.RequestContextMiddleware',
    ]
    ```
"""

__version__ = "0.0.4"

# Core context management
from django_rw_router.context import RequestContext, RequestContextData

# Managers for forcing primary database
from django_rw_router.managers import PrimaryManager, PrimaryQuerySet, use_primary_db

# Middleware
from django_rw_router.middleware import RequestContextMiddleware

# Routers
from django_rw_router.routers import (
    HashPrimaryReplicaRouter,
    PrimaryReplicaRouter,
    PrimaryReplicaRouterWithCtx,
    TransactionPrimaryReplicaRouter,
)

__all__ = [
    # Version
    "__version__",
    # Context
    "RequestContext",
    "RequestContextData",
    # Managers
    "PrimaryManager",
    "PrimaryQuerySet",
    "use_primary_db",
    # Middleware
    "RequestContextMiddleware",
    # Routers
    "PrimaryReplicaRouter",
    "TransactionPrimaryReplicaRouter",
    "HashPrimaryReplicaRouter",
    "PrimaryReplicaRouterWithCtx",
]


def setup(settings):
    """Configure django-rw-router from Django settings.

    This is a convenience function for one-time configuration.

    Args:
        settings: Django settings module or dict-like object
    """
    # This function can be expanded to perform any necessary setup
    # Currently, configuration is done via Django settings directly
    pass
