"""Hash-based database routing for consistent reads.

This module provides routers that use consistent hashing to route
read requests, ensuring the same user always reads from the same
replica (monotonic reads).
"""

import logging

from uhashring import HashRing

from django_rw_router.context import RequestContext
from django_rw_router.routers.base import TransactionPrimaryReplicaRouter

logger = logging.getLogger(__name__)


class HashPrimaryReplicaRouter(TransactionPrimaryReplicaRouter):
    """Router using consistent hash for read replica selection.

    This router ensures that the same user_id always routes to the same
    read replica, providing monotonic read consistency. This is especially
    useful in scenarios where:
    - Replication lag is non-zero
    - The same user performs multiple reads
    - You want to avoid "jumping" between replicas with different data

    The router uses the user_id from RequestContext to perform consistent
    hashing against available read replicas.

    Configuration:
        ```python
        # settings.py
        DATABASE_ROUTERS = [
            'django_rw_router.routers.hash.HashPrimaryReplicaRouter'
        ]

        # Optional: Configure hash ring parameters
        DJANGO_RW_ROUTER_HASH_VIRTUAL_NODES = 40  # Default virtual nodes
        ```
    """

    def __init__(self):
        """Initialize router with hash ring for read databases."""
        super().__init__()
        self._hash_ring: HashRing | None = None

    @property
    def hash_ring(self) -> HashRing:
        """Get or create the hash ring for read databases.

        Returns:
            HashRing instance configured with read databases
        """
        if self._hash_ring is None:
            from django.conf import settings

            virtual_nodes = getattr(
                settings, "DJANGO_RW_ROUTER_HASH_VIRTUAL_NODES", 40
            )
            self._hash_ring = HashRing(
                self._config.read_dbs, virtual_nodes=virtual_nodes
            )
        return self._hash_ring

    def db_for_write(self, model, **hints) -> str:
        """Route write operations and update RequestContext.

        Args:
            model: Model class being written
            **hints: Additional routing hints

        Returns:
            Database alias for write operations
        """
        ctx = RequestContext.get_context()
        if ctx and ctx.user_id:
            RequestContext.update_context(extra={str(model): True}, orm_write=True)
            logger.info(
                f"HashPrimaryReplicaRouter write for user_id={ctx.user_id} to {self._config.write_db}"
            )
        return super().db_for_write(model, **hints)

    def db_for_read(self, model, **hints) -> str:
        """Route read operations based on consistent hash of user_id.

        Falls back to transaction-aware behavior if:
        - Currently in a transaction block (reads from primary)
        - No user_id in RequestContext (reads from random replica)

        Args:
            model: Model class being read
            **hints: Additional routing hints

        Returns:
            Database alias for read operations
        """
        # First check if in transaction (reads from primary)
        in_atomic = self._check_in_atomic()
        if in_atomic:
            logger.debug("HashPrimaryReplicaRouter in transaction, reading from primary")
            return self._config.write_db

        # Try to get consistent replica for user
        ctx = RequestContext.get_context()
        if not ctx or not ctx.user_id:
            logger.debug("HashPrimaryReplicaRouter no user_id, fallback to random replica")
            return super().db_for_read(model, **hints)

        # Use consistent hash to select replica
        db = self.hash_ring.get_node(str(ctx.user_id))
        logger.info(
            f"HashPrimaryReplicaRouter read for user_id={ctx.user_id} routed to {db}"
        )
        return db

    def _check_in_atomic(self) -> bool:
        """Check if currently in a transaction block.

        Returns:
            True if in atomic block, False otherwise
        """
        from django_rw_router.routers.base import check_in_atomic_block

        return check_in_atomic_block()
