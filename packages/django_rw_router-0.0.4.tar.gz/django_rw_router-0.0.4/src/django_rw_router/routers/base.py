"""Core database router implementations for read-write separation."""

import logging
import random

from django.conf import settings
from django.db.transaction import get_connection

from django_rw_router.context import RequestContext

logger = logging.getLogger(__name__)

# Default configuration
DEFAULT_READ_DB_ALIAS = "readonly"
DEFAULT_WRITE_DB_ALIAS = "default"


class RouterConfig:
    """Configuration for database routers.

    Attributes:
        read_dbs: List of read replica database aliases
        write_db: Primary database alias for writes
    """

    def __init__(self, read_dbs: list[str] | None = None, write_db: str | None = None):
        """Initialize router configuration.

        Args:
            read_dbs: List of read database aliases. Defaults to ["readonly"]
            write_db: Write database alias. Defaults to "default"
        """
        self._read_dbs = read_dbs or [
            getattr(settings, "DJANGO_RW_ROUTER_READ_DB", DEFAULT_READ_DB_ALIAS)
        ]
        # Support both single string and list from settings
        read_from_settings = getattr(settings, "DJANGO_RW_ROUTER_READ_DBS", None)
        if read_from_settings:
            if isinstance(read_from_settings, str):
                self._read_dbs = [read_from_settings]
            elif isinstance(read_from_settings, list):
                self._read_dbs = read_from_settings

        self._write_db = write_db or getattr(
            settings, "DJANGO_RW_ROUTER_WRITE_DB", DEFAULT_WRITE_DB_ALIAS
        )

    @property
    def read_dbs(self) -> list[str]:
        """Get list of read database aliases."""
        return self._read_dbs

    @property
    def write_db(self) -> str:
        """Get write database alias."""
        return self._write_db

    @property
    def all_dbs(self) -> list[str]:
        """Get all database aliases (write + read)."""
        return [self._write_db] + self._read_dbs


def check_in_atomic_block(using: str | None = None) -> bool:
    """Check if currently in a transaction block.

    Args:
        using: Database alias to check. None uses default connection.

    Returns:
        True if in atomic block, False otherwise
    """
    conn = get_connection(using)
    conn.validate_thread_sharing()
    return conn.in_atomic_block


class PrimaryReplicaRouter:
    """Basic read-write separation router.

    Writes always go to the primary database, reads are distributed
    randomly among read replicas.

    Configuration:
        ```python
        # settings.py
        DATABASE_ROUTERS = ['django_rw_router.routers.PrimaryReplicaRouter']

        # Optional configuration
        DJANGO_RW_ROUTER_READ_DBS = ['readonly', 'readonly2']
        DJANGO_RW_ROUTER_WRITE_DB = 'default'
        ```
    """

    def __init__(self):
        """Initialize router with default configuration."""
        self._config = RouterConfig()

    def db_for_read(self, model, **hints) -> str:
        """Route read operations to a random read replica.

        Args:
            model: Model class being read
            **hints: Additional routing hints

        Returns:
            Database alias for read operations
        """
        db = random.choice(self._config.read_dbs)
        logger.debug(f"PrimaryReplicaRouter routing read to {db}")
        return db

    def db_for_write(self, model, **hints) -> str:
        """Route write operations to the primary database.

        Args:
            model: Model class being written
            **hints: Additional routing hints

        Returns:
            Database alias for write operations
        """
        logger.debug(f"PrimaryReplicaRouter routing write to {self._config.write_db}")
        return self._config.write_db

    def allow_relation(self, obj1, obj2, **hints) -> bool | None:
        """Allow relations between objects in the primary/replica pool.

        Args:
            obj1: First model instance
            obj2: Second model instance
            **hints: Additional hints

        Returns:
            True if both objects are in the database pool, None otherwise
        """
        db1 = obj1._state.db
        db2 = obj2._state.db
        if db1 in self._config.all_dbs and db2 in self._config.all_dbs:
            return True
        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints) -> bool:
        """Allow migrations on all databases.

        Args:
            db: Database alias
            app_label: Application label
            model_name: Model name
            **hints: Additional hints

        Returns:
            True to allow migration
        """
        return db in self._config.all_dbs


class TransactionPrimaryReplicaRouter(PrimaryReplicaRouter):
    """Transaction-aware read-write separation router.

    Extends PrimaryReplicaRouter to route reads to the primary database
    when inside a transaction block. This prevents reading stale data
    from replicas due to replication lag.

    Use this router when:
    - You frequently perform write followed by read operations
    - You need to read data immediately after writing it
    - Your replication has non-zero lag

    Configuration:
        ```python
        # settings.py
        DATABASE_ROUTERS = [
            'django_rw_router.routers.TransactionPrimaryReplicaRouter'
        ]
        ```
    """

    def db_for_read(self, model, **hints) -> str:
        """Route read operations based on transaction state.

        When in a transaction block, routes reads to the primary database
        to ensure reading the latest data. Otherwise routes to a read replica.

        Args:
            model: Model class being read
            **hints: Additional routing hints

        Returns:
            Database alias for read operations
        """
        in_atomic = check_in_atomic_block()
        logger.debug(
            f"TransactionPrimaryReplicaRouter in_atomic_block: {in_atomic}"
        )
        if in_atomic:
            logger.debug("TransactionPrimaryReplicaRouter routing read to primary")
            return self._config.write_db
        return super().db_for_read(model, **hints)


class PrimaryReplicaRouterWithCtx(PrimaryReplicaRouter):
    """Router that tracks write operations via RequestContext.

    This router updates the RequestContext when write operations occur,
    enabling tracking of which models have been written to during the request.

    Configuration:
        ```python
        # settings.py
        DATABASE_ROUTERS = [
            'django_rw_router.routers.PrimaryReplicaRouterWithCtx'
        ]
        ```
    """

    def db_for_write(self, model, **hints) -> str:
        """Route write operations and update RequestContext.

        Args:
            model: Model class being written
            **hints: Additional routing hints

        Returns:
            Database alias for write operations
        """
        ctx = RequestContext.get_context()
        if ctx:
            ctx.using = True
            ctx.extra[str(model)] = True
        return super().db_for_write(model, **hints)
