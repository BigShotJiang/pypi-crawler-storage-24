"""Database routers for Django read-write separation.

This module provides various router implementations for database read-write
separation with different strategies:

- PrimaryReplicaRouter: Basic read-write separation
- TransactionPrimaryReplicaRouter: Transaction-aware routing
- HashPrimaryReplicaRouter: Consistent hash-based routing
- PrimaryReplicaRouterWithCtx: Context-tracking router

Example configuration:
    ```python
    # settings.py
    DATABASE_ROUTERS = [
        'django_rw_router.routers.PrimaryReplicaRouter',
    ]
    ```
"""

from django_rw_router.routers.base import (
    PrimaryReplicaRouter,
    PrimaryReplicaRouterWithCtx,
    TransactionPrimaryReplicaRouter,
)
from django_rw_router.routers.hash import HashPrimaryReplicaRouter

__all__ = [
    "PrimaryReplicaRouter",
    "TransactionPrimaryReplicaRouter",
    "HashPrimaryReplicaRouter",
    "PrimaryReplicaRouterWithCtx",
]
