"""Tests for RequestContext module."""

import pytest


class TestRequestContextData:
    """Test RequestContextData dataclass."""

    def test_default_values(self):
        """Test RequestContextData initializes with default values."""
        from django_rw_router.context import RequestContextData

        data = RequestContextData()
        assert data.user_id is None
        assert data.request_id is None
        assert data.orm_write is False
        assert data.using is None
        assert data.extra == {}

    def test_with_values(self):
        """Test RequestContextData with provided values."""
        from django_rw_router.context import RequestContextData

        data = RequestContextData(
            user_id=123, request_id="abc", orm_write=True, using="default", extra={"key": "value"}
        )
        assert data.user_id == 123
        assert data.request_id == "abc"
        assert data.orm_write is True
        assert data.using == "default"
        assert data.extra == {"key": "value"}


class TestRequestContext:
    """Test RequestContext context management."""

    def test_set_and_get_context(self):
        """Test setting and getting request context."""
        from django_rw_router.context import RequestContext

        RequestContext.set_context(user_id=123, request_id="abc")

        ctx = RequestContext.get_context()
        assert ctx is not None
        assert ctx.user_id == 123
        assert ctx.request_id == "abc"

        RequestContext.reset()

    def test_get_context_returns_none_when_not_set(self):
        """Test get_context returns None when context is not set."""
        from django_rw_router.context import RequestContext

        # Ensure context is cleared
        RequestContext.reset()

        ctx = RequestContext.get_context()
        assert ctx is None

    def test_reset_clears_context(self):
        """Test reset clears the request context."""
        from django_rw_router.context import RequestContext

        RequestContext.set_context(user_id=123, request_id="abc")
        RequestContext.reset()

        ctx = RequestContext.get_context()
        assert ctx is None

    def test_update_context(self):
        """Test update_context modifies existing context."""
        from django_rw_router.context import RequestContext

        RequestContext.set_context(user_id=123, request_id="abc")
        RequestContext.update_context(user_id=456, orm_write=True)

        ctx = RequestContext.get_context()
        assert ctx.user_id == 456
        assert ctx.request_id == "abc"
        assert ctx.orm_write is True

        RequestContext.reset()

    def test_update_context_with_extra(self):
        """Test update_context merges extra dict."""
        from django_rw_router.context import RequestContext

        RequestContext.set_context(user_id=123, extra={"key1": "value1"})
        RequestContext.update_context(extra={"key2": "value2"})

        ctx = RequestContext.get_context()
        assert ctx.extra == {"key1": "value1", "key2": "value2"}

        RequestContext.reset()

    def test_update_context_when_no_context(self):
        """Test update_context does nothing when no context exists."""
        from django_rw_router.context import RequestContext

        RequestContext.reset()
        RequestContext.update_context(user_id=123)

        ctx = RequestContext.get_context()
        assert ctx is None

    def test_context_isolation(self):
        """Test that context is properly isolated between calls."""
        from django_rw_router.context import RequestContext

        RequestContext.set_context(user_id=111, request_id="req1")
        ctx1 = RequestContext.get_context()
        assert ctx1.user_id == 111

        RequestContext.set_context(user_id=222, request_id="req2")
        ctx2 = RequestContext.get_context()
        assert ctx2.user_id == 222
        assert ctx2.request_id == "req2"

        RequestContext.reset()
