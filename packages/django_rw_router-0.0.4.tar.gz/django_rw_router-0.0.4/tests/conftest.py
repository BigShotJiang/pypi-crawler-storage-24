"""Pytest configuration and fixtures for django-rw-router tests."""

import pytest


@pytest.fixture
def django_db_setup():
    """Configure Django settings for tests."""
    from django.conf import settings

    if not settings.configured:
        settings.configure(
            DEBUG=True,
            DATABASES={
                "default": {
                    "ENGINE": "django.db.backends.sqlite3",
                    "NAME": ":memory:",
                },
                "readonly": {
                    "ENGINE": "django.db.backends.sqlite3",
                    "NAME": ":memory:",
                },
            },
            INSTALLED_APPS=[
                "django.contrib.contenttypes",
                "django.contrib.auth",
                "tests.router_testapp",
            ],
            DATABASE_ROUTERS=[],
            SECRET_KEY="test-secret-key",
            EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend",
        )
        import django

        django.setup()
        from django.core import mail
        from django.core.management import call_command

        mail.get_connection()
        call_command("migrate", verbosity=0)

    return settings


@pytest.fixture
def test_model(django_db_setup):
    """Provide TestModel from router_testapp (single definition, no re-registration)."""
    from tests.router_testapp.models import TestModel

    return TestModel


@pytest.fixture
def mock_model(django_db_setup):
    """Create a mock model for router tests (no DB needed)."""
    from unittest.mock import Mock

    model = Mock()
    model.__name__ = "TestModel"
    return model


@pytest.fixture
def mock_request(django_db_setup):
    """Create a mock request with user and request_id."""
    from unittest.mock import Mock

    request = Mock()
    request.user = Mock()
    request.user.id = 12345
    request.id = "test-request-123"
    return request
