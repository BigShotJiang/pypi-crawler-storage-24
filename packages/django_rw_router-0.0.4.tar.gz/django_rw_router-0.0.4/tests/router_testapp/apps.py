"""App config for router test app."""

from django.apps import AppConfig


class RouterTestappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "tests.router_testapp"
    label = "router_testapp"
