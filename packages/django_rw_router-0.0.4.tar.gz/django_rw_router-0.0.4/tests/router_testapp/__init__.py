"""Minimal Django app for router testing."""
