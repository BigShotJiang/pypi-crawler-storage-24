"""Test models for router tests."""

from django.db import models


class TestModel(models.Model):
    """Minimal model for router tests."""

    name = models.CharField(max_length=100)

    class Meta:
        app_label = "router_testapp"
