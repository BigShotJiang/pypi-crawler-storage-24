"""Tests for RequestContextMiddleware."""

import pytest
from unittest.mock import Mock


class TestGetNestedAttr:
    """Test _get_nested_attr helper."""

    def test_simple_attr(self, django_db_setup):
        """Test getting simple attribute."""
        from django_rw_router.middleware import _get_nested_attr

        obj = Mock()
        obj.foo = 42
        assert _get_nested_attr(obj, "foo") == 42

    def test_nested_attr(self, django_db_setup):
        """Test getting nested attribute via dot path."""
        from django_rw_router.middleware import _get_nested_attr

        obj = Mock()
        obj.user = Mock()
        obj.user.id = 123
        assert _get_nested_attr(obj, "user.id") == 123

    def test_missing_attr_returns_none(self, django_db_setup):
        """Test returns None for missing attribute."""
        from django_rw_router.middleware import _get_nested_attr

        obj = Mock(spec=[])
        assert _get_nested_attr(obj, "missing") is None

    def test_none_in_chain_returns_none(self, django_db_setup):
        """Test returns None when intermediate attr is None."""
        from django_rw_router.middleware import _get_nested_attr

        obj = Mock()
        obj.user = None
        assert _get_nested_attr(obj, "user.id") is None


class TestRequestContextMiddleware:
    """Test RequestContextMiddleware."""

    def test_sets_and_clears_context(self, django_db_setup):
        """Test middleware sets context at start and clears at end."""
        from django_rw_router.context import RequestContext
        from django_rw_router.middleware import RequestContextMiddleware

        def get_response(request):
            ctx = RequestContext.get_context()
            assert ctx is not None
            assert ctx.user_id == 12345
            assert ctx.request_id == "test-request-123"
            return Mock(status_code=200)

        middleware = RequestContextMiddleware(get_response)
        request = Mock()
        request.user = Mock()
        request.user.id = 12345
        request.id = "test-request-123"

        response = middleware(request)

        assert response.status_code == 200
        assert RequestContext.get_context() is None

    def test_clears_context_on_exception(self, django_db_setup):
        """Test context is cleared even when view raises."""
        from django_rw_router.context import RequestContext
        from django_rw_router.middleware import RequestContextMiddleware

        def get_response(request):
            raise ValueError("view error")

        middleware = RequestContextMiddleware(get_response)
        request = Mock()
        request.user = Mock()
        request.user.id = 1
        request.id = "req-1"

        with pytest.raises(ValueError, match="view error"):
            middleware(request)

        assert RequestContext.get_context() is None

    def test_handles_missing_user_id(self, django_db_setup):
        """Test middleware works when user_id cannot be extracted."""
        from django_rw_router.context import RequestContext
        from django_rw_router.middleware import RequestContextMiddleware

        def get_response(request):
            ctx = RequestContext.get_context()
            assert ctx is not None
            assert ctx.user_id is None
            return Mock(status_code=200)

        middleware = RequestContextMiddleware(get_response)
        request = Mock()
        request.user = None
        request.id = "req-1"

        response = middleware(request)
        assert response.status_code == 200
