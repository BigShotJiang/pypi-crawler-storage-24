"""
DDIA 读写分离一致性场景测试 (Designing Data-Intensive Applications)

参考 DDIA 第五章 Replication 中讨论的复制滞后导致的四种读一致性问题：
1. Read Your Writes (读己之写)
2. Monotonic Reads (单调读)
3. Consistent Prefix Reads (一致前缀读)
4. Eventual Consistency (最终一致性)
"""

import pytest
from unittest.mock import Mock


class TestDDIA_1_ReadYourWrites:
    """
    Scenario 1: Read Your Writes (读己之写)

    用户写入后立即读取，应能读到刚写入的数据。
    复现滞后时，若读走从库可能读到旧数据。解决：事务内读写均走主库。
    """

    def test_transaction_router_reads_from_primary_inside_transaction(
        self, django_db_setup, test_model
    ):
        """TransactionPrimaryReplicaRouter: 事务内读走主库，确保写后读可见。"""
        from django.db import transaction
        from django_rw_router.routers import TransactionPrimaryReplicaRouter

        router = TransactionPrimaryReplicaRouter()

        with transaction.atomic(using="default"):
            db = router.db_for_read(test_model)
            assert db == "default", "事务内应读主库以实现 Read Your Writes"

    def test_hash_router_reads_from_primary_inside_transaction(
        self, django_db_setup, test_model
    ):
        """HashPrimaryReplicaRouter: 事务内同样走主库。"""
        from django.db import transaction
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import HashPrimaryReplicaRouter

        RequestContext.set_context(user_id=123)
        router = HashPrimaryReplicaRouter()

        with transaction.atomic(using="default"):
            db = router.db_for_read(test_model)
            assert db == "default", "事务内应读主库"

        RequestContext.reset()


class TestDDIA_2_MonotonicReads:
    """
    Scenario 2: Monotonic Reads (单调读)

    同一用户多次读，不应出现"时光倒流"——先读到新值再读到旧值。
    解决：同一 user_id 始终路由到同一从库。
    """

    def test_hash_router_same_user_same_replica(self, django_db_setup, mock_model):
        """HashPrimaryReplicaRouter: 同一 user_id 多次读应命中同一从库。"""
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import HashPrimaryReplicaRouter

        router = HashPrimaryReplicaRouter()

        for _ in range(10):
            RequestContext.set_context(user_id=999)
            db = router.db_for_read(mock_model)
            assert db in ["readonly"], "应从配置的从库中选择"
            RequestContext.reset()

        # 多次设置相同 user_id，应得到相同 db
        RequestContext.set_context(user_id=888)
        db1 = router.db_for_read(mock_model)
        RequestContext.set_context(user_id=888)
        db2 = router.db_for_read(mock_model)
        assert db1 == db2, "同一 user_id 应路由到同一从库 (Monotonic Reads)"

        RequestContext.reset()

    def test_different_users_can_differ_replicas(self, django_db_setup, mock_model):
        """不同 user_id 可路由到不同从库（单从库时相同）。"""
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import HashPrimaryReplicaRouter

        router = HashPrimaryReplicaRouter()

        RequestContext.set_context(user_id=100)
        db100 = router.db_for_read(mock_model)
        RequestContext.set_context(user_id=200)
        db200 = router.db_for_read(mock_model)

        assert db100 in ["readonly"] and db200 in ["readonly"]
        RequestContext.reset()


class TestDDIA_3_ConsistentPrefixReads:
    """
    Scenario 3: Consistent Prefix Reads (一致前缀读)

    读取有序数据时，不应看到"父在子后"——如看到回复却看不到原问题。
    解决：有因果关系的读应来自同一时间线；Hash 路由使同一用户读同一从库。
    """

    def test_hash_router_consistent_prefix_same_user(self, django_db_setup, mock_model):
        """同一用户的多次读走同一从库，保证一致前缀。"""
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import HashPrimaryReplicaRouter

        router = HashPrimaryReplicaRouter()

        # 模拟连续读取有因果关系的两条数据
        RequestContext.set_context(user_id=42)
        db_parent = router.db_for_read(mock_model)
        db_child = router.db_for_read(mock_model)

        assert db_parent == db_child, "同一请求内多次读应走同一从库 (Consistent Prefix)"

        RequestContext.reset()


class TestDDIA_4_EventualConsistency:
    """
    Scenario 4: Eventual Consistency (最终一致性)

    写走主库，读可走从库，存在复制滞后，系统呈最终一致性。
    PrimaryReplicaRouter 随机选从库，不保证上述三种强一致性。
    """

    def test_primary_replica_router_write_always_primary(self, django_db_setup, mock_model):
        """PrimaryReplicaRouter: 写始终走主库。"""
        from django_rw_router.routers import PrimaryReplicaRouter

        router = PrimaryReplicaRouter()
        db = router.db_for_write(mock_model)
        assert db == "default", "写应始终走主库"

    def test_primary_replica_router_read_may_replica(self, django_db_setup, mock_model):
        """PrimaryReplicaRouter: 读可走从库，接受最终一致性。"""
        from django_rw_router.routers import PrimaryReplicaRouter

        router = PrimaryReplicaRouter()
        db = router.db_for_read(mock_model)
        assert db in ["readonly"], "读可走从库，存在复制滞后"

    def test_outside_transaction_read_goes_to_replica(self, django_db_setup, mock_model):
        """TransactionPrimaryReplicaRouter: 事务外读走从库。"""
        from django_rw_router.routers import TransactionPrimaryReplicaRouter

        router = TransactionPrimaryReplicaRouter()
        db = router.db_for_read(mock_model)
        assert db in ["readonly"], "事务外读走从库"
