"""Tests for database routers."""

import pytest


class TestRouterConfig:
    """Test RouterConfig class."""

    def test_default_config(self, django_db_setup):
        """Test RouterConfig with default values."""
        from django_rw_router.routers.base import RouterConfig

        config = RouterConfig()
        assert config.read_dbs == ["readonly"]
        assert config.write_db == "default"
        assert config.all_dbs == ["default", "readonly"]

    def test_custom_config(self, django_db_setup):
        """Test RouterConfig with custom values."""
        from django_rw_router.routers.base import RouterConfig

        config = RouterConfig(read_dbs=["replica1", "replica2"], write_db="primary")
        assert config.read_dbs == ["replica1", "replica2"]
        assert config.write_db == "primary"
        assert config.all_dbs == ["primary", "replica1", "replica2"]


class TestPrimaryReplicaRouter:
    """Test PrimaryReplicaRouter class."""

    def test_db_for_write_returns_default(self, django_db_setup, mock_model):
        """Test db_for_write returns the write database."""
        from django_rw_router.routers import PrimaryReplicaRouter

        router = PrimaryReplicaRouter()
        db = router.db_for_write(mock_model)
        assert db == "default"

    def test_db_for_read_returns_readonly(self, django_db_setup, mock_model):
        """Test db_for_read returns a read database."""
        from django_rw_router.routers import PrimaryReplicaRouter

        router = PrimaryReplicaRouter()
        db = router.db_for_read(mock_model)
        assert db in ["readonly"]

    def test_allow_relation_same_dbs(self, django_db_setup):
        """Test allow_relation returns True for objects in configured databases."""
        from unittest.mock import Mock
        from django_rw_router.routers import PrimaryReplicaRouter

        router = PrimaryReplicaRouter()

        obj1 = Mock()
        obj1._state.db = "default"
        obj2 = Mock()
        obj2._state.db = "readonly"

        result = router.allow_relation(obj1, obj2)
        assert result is True

    def test_allow_relation_different_dbs(self, django_db_setup):
        """Test allow_relation returns None for objects outside configured databases."""
        from unittest.mock import Mock
        from django_rw_router.routers import PrimaryReplicaRouter

        router = PrimaryReplicaRouter()

        obj1 = Mock()
        obj1._state.db = "default"
        obj2 = Mock()
        obj2._state.db = "other_db"

        result = router.allow_relation(obj1, obj2)
        assert result is None

    def test_allow_migrate(self, django_db_setup):
        """Test allow_migrate for configured databases."""
        from django_rw_router.routers import PrimaryReplicaRouter

        router = PrimaryReplicaRouter()

        assert router.allow_migrate("default", "test") is True
        assert router.allow_migrate("readonly", "test") is True
        assert router.allow_migrate("other", "test") is False


class TestTransactionPrimaryReplicaRouter:
    """Test TransactionPrimaryReplicaRouter class."""

    def test_db_for_read_outside_transaction(self, django_db_setup, mock_model):
        """Test db_for_read returns replica when outside transaction."""
        from django_rw_router.routers import TransactionPrimaryReplicaRouter

        router = TransactionPrimaryReplicaRouter()
        db = router.db_for_read(mock_model)
        assert db in ["readonly"]

    def test_db_for_read_inside_transaction(self, django_db_setup, mock_model):
        """Test db_for_read returns primary when inside transaction."""
        from django.db import transaction
        from django_rw_router.routers import TransactionPrimaryReplicaRouter

        router = TransactionPrimaryReplicaRouter()

        with transaction.atomic(using="default"):
            db = router.db_for_read(mock_model)
            assert db == "default"


class TestPrimaryReplicaRouterWithCtx:
    """Test PrimaryReplicaRouterWithCtx class."""

    def test_db_for_write_updates_context(self, django_db_setup, test_model, mock_model):
        """Test db_for_write updates RequestContext with model key in extra."""
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import PrimaryReplicaRouterWithCtx

        RequestContext.set_context(user_id=123)
        router = PrimaryReplicaRouterWithCtx()

        db = router.db_for_write(test_model)
        assert db == "default"

        ctx = RequestContext.get_context()
        assert ctx is not None
        assert ctx.using is True
        model_key = str(test_model)
        assert model_key in ctx.extra and ctx.extra[model_key] is True

        RequestContext.reset()

    def test_db_for_write_without_context(self, django_db_setup, mock_model):
        """Test db_for_write works without RequestContext."""
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import PrimaryReplicaRouterWithCtx

        RequestContext.reset()
        router = PrimaryReplicaRouterWithCtx()

        db = router.db_for_write(mock_model)
        assert db == "default"


class TestHashPrimaryReplicaRouter:
    """Test HashPrimaryReplicaRouter class."""

    def test_db_for_read_without_context(self, django_db_setup, mock_model):
        """Test db_for_read falls back without RequestContext."""
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import HashPrimaryReplicaRouter

        RequestContext.reset()
        router = HashPrimaryReplicaRouter()

        db = router.db_for_read(mock_model)
        assert db in ["readonly"]

    def test_db_for_read_with_user_id(self, django_db_setup, mock_model):
        """Test db_for_read routes consistently for same user_id."""
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import HashPrimaryReplicaRouter

        router = HashPrimaryReplicaRouter()

        # Same user_id should route to same database
        RequestContext.set_context(user_id=123)
        db1 = router.db_for_read(mock_model)

        RequestContext.set_context(user_id=123)
        db2 = router.db_for_read(mock_model)

        assert db1 == db2
        assert db1 in ["readonly"]

        RequestContext.reset()

    def test_db_for_read_in_transaction(self, django_db_setup, mock_model):
        """Test db_for_read routes to primary when in transaction."""
        from django.db import transaction
        from django_rw_router.context import RequestContext
        from django_rw_router.routers import HashPrimaryReplicaRouter

        RequestContext.set_context(user_id=123)
        router = HashPrimaryReplicaRouter()

        with transaction.atomic(using="default"):
            db = router.db_for_read(mock_model)
            assert db == "default"

        RequestContext.reset()
