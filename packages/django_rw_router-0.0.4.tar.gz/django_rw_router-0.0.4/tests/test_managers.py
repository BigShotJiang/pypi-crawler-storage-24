"""Tests for PrimaryManager and PrimaryQuerySet."""

import pytest


class TestUsePrimaryDb:
    """Test use_primary_db decorator."""

    def test_decorator_wraps_function(self, django_db_setup):
        """Test decorator preserves function attributes."""
        from django_rw_router.managers import use_primary_db

        @use_primary_db
        def sample_function():
            """Sample function docstring."""
            return 42

        assert sample_function.__name__ == "sample_function"
        assert sample_function() == 42


class TestPrimaryQuerySet:
    """Test PrimaryQuerySet class."""

    def test_queryset_initialization(self, test_model):
        """Test PrimaryQuerySet can be initialized."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model)
        assert qs.model is test_model

    def test_queryset_with_using(self, test_model):
        """Test PrimaryQuerySet with explicit using parameter."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model, using="readonly")
        # When using is explicitly provided, it should be respected
        assert qs._db == "readonly"

    def test_first_method_exists(self, test_model):
        """Test first method is available."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model)
        assert hasattr(qs, "first")
        assert callable(qs.first)

    def test_last_method_exists(self, test_model):
        """Test last method is available."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model)
        assert hasattr(qs, "last")
        assert callable(qs.last)

    def test_exists_method_exists(self, test_model):
        """Test exists method is available."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model)
        assert hasattr(qs, "exists")
        assert callable(qs.exists)

    def test_count_method_exists(self, test_model):
        """Test count method is available."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model)
        assert hasattr(qs, "count")
        assert callable(qs.count)


class TestPrimaryManager:
    """Test PrimaryManager class."""

    def test_manager_creation(self, test_model):
        """Test PrimaryManager can be attached to a model."""
        from django_rw_router.managers import PrimaryManager

        manager = PrimaryManager()
        assert manager.model is None  # Not bound yet

    def test_manager_has_queryset(self, test_model):
        """Test PrimaryManager returns PrimaryQuerySet."""
        from django_rw_router.managers import PrimaryManager

        manager = PrimaryManager()
        assert hasattr(manager, "get_queryset")

    def test_manager_standard_methods(self, test_model):
        """Test PrimaryManager has standard QuerySet methods."""
        from django_rw_router.managers import PrimaryManager

        manager = PrimaryManager()
        # Check for common manager methods
        assert hasattr(manager, "all")
        assert hasattr(manager, "filter")
        assert hasattr(manager, "get")


class TestPrimaryQuerySetRouting:
    """Test primary database routing behavior."""

    def test_apply_primary_routing_disabled(self, django_db_setup, test_model):
        """Test primary routing is disabled by default."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model)
        # By default, routing should not be applied
        assert qs._db is None

    def test_apply_primary_routing_with_explicit_using(self, django_db_setup, test_model):
        """Test explicit using is not overridden."""
        from django_rw_router.managers import PrimaryQuerySet

        qs = PrimaryQuerySet(model=test_model, using="readonly")
        qs._apply_primary_routing("readonly")
        # Explicit using should be preserved (not None)
        assert qs._db == "readonly"


class TestMethodUsingEnabled:
    """Test method-level primary database routing."""

    def test_get_method_using_enabled_default(self, django_db_setup):
        """Test method using enabled defaults to False."""
        from django_rw_router.managers import _get_method_using_enabled

        assert _get_method_using_enabled() is False

    def test_get_queryset_using_enabled_default(self, django_db_setup):
        """Test queryset using enabled defaults to False."""
        from django_rw_router.managers import _get_queryset_using_enabled

        assert _get_queryset_using_enabled() is False

    def test_queryset_using_enabled_applies_primary(self, django_db_setup, test_model):
        """When DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE=True, QuerySet 应使用主库。"""
        from django.test import override_settings
        from django_rw_router.managers import PrimaryQuerySet

        with override_settings(DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE=True):
            qs = PrimaryQuerySet(model=test_model)
            assert qs._db == "default"

    def test_explicit_using_overrides_setting(self, django_db_setup, test_model):
        """显式 using 不应被配置覆盖。"""
        from django.test import override_settings
        from django_rw_router.managers import PrimaryQuerySet

        with override_settings(DJANGO_RW_ROUTER_QUERYSET_USING_ENABLE=True):
            qs = PrimaryQuerySet(model=test_model, using="readonly")
            assert qs._db == "readonly"
