#!/usr/bin/env python

import collections
import json
import re
import traceback
from datetime import datetime
from enum import Enum
from pathlib import Path

import click
from pluginbase import PluginBase

from clk.click_helpers import click_get_current_context_safe
from clk.lib import (
    copy,
    createfile,
    ensure_unicode,
    glob,
    json_dump_file,
    json_file,
    makedirs,
    move,
    part_of_day,
    rm,
)
from clk.log import get_logger

LOGGER = get_logger(__name__)
plugin_base = PluginBase(package="clk.plugins")


def on_command_loading_error():
    LOGGER.develop(traceback.format_exc())
    from clk.config import config

    if config.debug_on_command_load_error_callback:
        import sys

        import ipdb

        ipdb.post_mortem(sys.exc_info()[2])


class ActivationLevel(Enum):
    local = "local"
    global_ = "global"


class ProfileFactory:
    directory_profile_cls = None
    directory_profile_cache = {}

    preset_profile_cls = None
    preset_profile_used = False

    @classmethod
    def register_directory_profile(klass, cls):
        assert not klass.directory_profile_cache, (
            f"A new class ({cls}) was registered after the first instantiation"
            f" of a directory profile with class ({klass.directory_profile_cls})"
            f" This would cause unstable behavior"
        )
        klass.directory_profile_cls = cls
        return cls

    @classmethod
    def register_preset_profile(klass, cls):
        assert not klass.preset_profile_used, (
            f"A new class ({cls}) was registered after the first instantiation"
            f" of a preset profile with class ({klass.preset_profile_cls})"
            f" This would cause unstable behavior"
        )
        klass.preset_profile_cls = cls
        return cls

    @classmethod
    def create_or_get_by_location(klass, location, *args, **kwargs):
        if "name" not in kwargs:
            kwargs["name"] = "unnamed"
        if location not in klass.directory_profile_cache:
            profile = klass.directory_profile_cls(location, *args, **kwargs)
            klass.directory_profile_cache[location] = profile
        return klass.directory_profile_cache[location]

    @classmethod
    def create_preset_profile(
        klass,
        name,
        settings=None,
        explicit=True,
        isroot=True,
        activation_level=ActivationLevel.global_,
        default_color=None,
        isextension=False,
        readonly=False,
    ):
        return klass.preset_profile_cls(
            name,
            settings,
            explicit=explicit,
            isroot=isroot,
            activation_level=activation_level,
            default_color=default_color,
            isextension=isextension,
            readonly=readonly,
        )


def load_settings(path):
    if path is not None and Path(path).exists():
        with open(path) as f:
            try:
                return json.load(f)
            except ValueError:
                # just give up on the data in the file
                LOGGER.warning(f"Can't read settings from {path}")
    return {}


def write_settings(settings_path, settings, dry_run):
    # don't pollute the settings by removing all the ones that have no
    # values. This helps having more homogeneous settings.
    for key in list(settings.keys()):
        if settings[key] == {}:
            del settings[key]
    if dry_run:
        return
    parent_dir = Path(settings_path).parent
    if not parent_dir.exists():
        makedirs(parent_dir)
    json_dump_file(settings_path, settings, internal=True)


class Profile:
    def __repr__(self):
        return f"<{self.__class__.__name__}: {self.name}>"

    @property
    def short_name(self):
        if "/" in self.name:
            profile_name, extension_name = self.name.split("/")
            return extension_name
        else:
            return self.name

    @property
    def executable_paths(self):
        return []

    @property
    def python_paths(self):
        return []

    def contains(self, path):
        return False

    @property
    def alternative_groups(self):
        return self.settings.get("alternative-groups")


plugin_sources = {}


@ProfileFactory.register_directory_profile
class DirectoryProfile(Profile):
    extension_extra_chars = ".@[]:><"
    extension_name_re = r"[a-zA-Z0-9_" + re.escape(extension_extra_chars) + r"-]+"
    extension_name_hint = (
        "An extension's name must contain only letters, digits, _ -"
        " or " + " ".join(extension_extra_chars)
    )
    JSON_FILE_EXTENSION = ".json"

    def describe(self):
        print(
            f"The extension {self.name}"
            f" is located at {self.location} ."
            " Let's try to see what it has to offer."
        )
        print("##########")
        enable_argument = f" --extension {self.short_name}" if self.isextension else ""
        for setting, command in [
            ("alias", "alias"),
            ("parameters", "parameter"),
            ("flowdeps", "flowdep"),
            ("triggers", "trigger"),
            ("value", "value"),
            ("recipe", "extension"),
            ("environment", "env"),
        ]:
            if self.settings.get(setting):
                print(
                    f"I found some {command}, try running"
                    f" `clk{enable_argument} {command} {' '.join(profile_name_to_commandline(self.name))} show`"
                    " to know more."
                )
        if any(
            [
                next(Path(path).iterdir())
                for path in (self.executable_paths + self.python_paths)
            ]
        ):
            print(
                f"I found some executable commands, try running"
                f" `clk{enable_argument} command {' '.join(profile_name_to_commandline(self.name))} list`"
                " to know more."
            )
        if plugins := self.plugin_source.list_plugins():
            print(f"I found some plugins called {', '.join(plugins)}")
        if remaining_config := set(self.settings.keys()) - {
            "alias",
            "parameters",
            "flowdeps",
            "triggers",
            "value",
            "recipe",
            "plugins",
            "environment",
            "customcommands",
        }:
            print(
                f"I also found some settings that I cannot explain: {', '.join(remaining_config)}."
                " They might have been set by other plugins, custom commands or extensions."
            )

    def __gt__(self, other):
        return self.name < other.name

    def extension_location(self, name):
        name = self.extension_short_name(name)
        return str(Path(self.location) / "extensions" / name)

    def contains(self, path):
        """Indicate whether or not this profile contains this path"""
        canonlocation = Path(self.location).resolve()
        canonpath = Path(path).resolve()
        try:
            canonpath.relative_to(canonlocation)
            return True
        except ValueError:
            return False

    @property
    def executable_paths(self):
        return [
            str(Path(self.location) / d)
            for d in [
                "script",
                "bin",
                "scripts",
                "Scripts",
                "Bin",
                "Script",
            ]
            if (Path(self.location) / d).exists()
        ]

    @property
    def custom_command_paths(self):
        return {
            "pythonpaths": self.python_paths,
            "executablepaths": self.executable_paths,
        }

    @property
    def requirements_path(self):
        return Path(self.location) / "python" / "requirements.txt"

    @property
    def python_paths(self):
        return [
            str(Path(self.location) / d)
            for d in ["python"]
            if (Path(self.location) / "python").exists()
        ]

    def create_extension(self, name, mkdir=True):
        name = self.extension_full_name(name)
        if not re.match(f"^{self.name}/{self.extension_name_re}$", name):
            raise click.UsageError(
                f"Invalid extension name: {name}. {self.extension_name_hint}"
            )
        location = self.extension_location(name)
        if Path(location).exists():
            raise click.UsageError(f"{location} already exists")
        p = ProfileFactory.create_or_get_by_location(
            location, name=name, app_name=self.app_name, explicit=True
        )
        if mkdir:
            p.write_settings()
        return p

    def extension_full_name(self, name):
        if name.startswith(self.name + "/"):
            return name
        else:
            return self.name + "/" + name

    def extension_short_name(self, name):
        if name.startswith(self.name + "/"):
            return name[len(self.name) + 1 :]
        else:
            return name

    def remove_extension(self, name):
        r = self.get_extension(name)
        rm(r.location)

    def has_extension(self, name):
        name = self.extension_full_name(name)
        candidates = [
            extension for extension in self.extensions if extension.name == name
        ]
        return candidates

    def get_extension(self, name):
        name = self.extension_full_name(name)
        candidates = [
            extension for extension in self.extensions if extension.name == name
        ]
        if not candidates:
            return self.create_extension(name, mkdir=False)
        else:
            return candidates[0]

    @property
    def extensions(self):
        if self.isextension:
            return []
        extensions_dir = Path(self.location) / "extensions"
        if not extensions_dir.exists():
            return []
        res = sorted(
            [
                ProfileFactory.create_or_get_by_location(
                    str(location),
                    name=self.name + "/" + location.name,
                    app_name=self.app_name,
                    isroot=False,
                    explicit=True,
                )
                for location in extensions_dir.iterdir()
                if location.is_dir()
                and not location.name.endswith(self.JSON_FILE_EXTENSION)
                and not location.name.endswith("_backup")
            ],
            key=lambda r: r.name,
        )
        return res

    @property
    def extension_names(self):
        return [r.name for r in self.extensions]

    @property
    def friendly_name(self):
        return self.name

    @property
    def parent_name(self):
        if "/" in self.name:
            profile_name, extension_name = self.name.split("/")
            return profile_name
        else:
            return None

    def __init__(
        self,
        location,
        app_name,
        dry_run=False,
        name=None,
        explicit=True,
        isroot=True,
        activation_level=ActivationLevel.global_,
        readonly=False,
        default_color=None,
    ):
        self.app_name = app_name
        self.default_color = default_color
        self.readonly = readonly
        self.activation_level = activation_level
        self.explicit = explicit
        self.isroot = isroot
        self.migrate_from = [
            self.alias_has_documentation,
            self.stack_of_git_records,
            self.extensions_instead_of_settings_level,
            self.extensions_instead_of_profiles,
            self.remove_with_legend,
            self.hooks_to_trigger,
            self.customcommand_to_executable,
            self.recipe_to_extension,
        ]
        self._version = None
        self.location = location
        self._location_path = Path(location)
        self.settings_path = str(self._location_path / f"{self.app_name}.json")
        self.dry_run = dry_run
        self.name = name

        def file_name_if_exists(file_name):
            return Path(file_name).exists() and file_name or None

        self.persist = True
        self.prevented_persistence = False
        self.pluginsdir = str(self._location_path / "plugins")
        self.frozen_during_migration = False
        self.plugin_cache = set()
        self.old_version = self.version
        if self.version > self.max_version:
            LOGGER.error(
                f"The profile at location {self.location} is at version {self.old_version}."
                f" I can only manage till version {self.max_version}."
                " It will be ignored."
                f" Please upgrade {self.app_name} and try again."
            )
            self.frozen_during_migration = True
        self.computed_location = None
        self.compute_settings()
        self.backup_location = self.location + "_backup"
        if Path(self.backup_location).exists():
            LOGGER.warning(
                f"The backup directory for profile in location {self.location} already exist"
            )
        self.migration_impact = (
            [
                Path(self.version_file_name).name,
            ]
            + [Path(f).name for f in glob(self.location + f"/{self.app_name}*json")]
            + ["extensions"]
        )

    @property
    def plugin_source(self):
        if self.name not in plugin_sources:
            plugin_sources[self.name] = plugin_base.make_plugin_source(
                searchpath=[self.pluginsdir]
            )
            plugin_sources[self.name].persist = True
        return plugin_sources[self.name]

    def plugin_doc(self, plugin):
        try:
            mod = self.plugin_source.load_plugin(plugin)
            if hasattr(mod, "__doc__"):
                return ensure_unicode(mod.__doc__)
        except Exception:
            pass
        return None

    def plugin_short_doc(self, plugin):
        doc = self.plugin_doc(plugin)
        if doc:
            doc = doc.splitlines()[0]
        return doc

    def load_plugins(self):
        for plugin in set(self.plugin_source.list_plugins()) - self.plugin_cache:
            try:
                before = datetime.now()
                mod = self.plugin_source.load_plugin(plugin)
                if hasattr(mod, "load_plugin"):
                    mod.load_plugin()
                after = datetime.now()
                spent_time = (after - before).total_seconds()
                LOGGER.develop(f"Plugin {plugin} loaded in {spent_time} seconds")
                threshold = 0.1
                if spent_time > threshold:
                    LOGGER.debug(
                        f"Plugin {plugin} took more than {threshold} seconds to load ({spent_time})."
                        " You might consider disabling the plugin when you don't use it."
                        " Or contribute to its dev to make it load faster."
                    )
            except Exception as e:
                ctx = click_get_current_context_safe()
                if ctx is None or not ctx.resilient_parsing:
                    plugin_name = plugin.replace("_", "/")
                    LOGGER.warning(
                        f"Error when loading plugin {plugin_name}"
                        " (if the plugin is no more useful,"
                        f" consider uninstalling the plugins {plugin_name}): {e}"
                    )
                    on_command_loading_error()
            self.plugin_cache.add(plugin)

    def get_settings(self, section):
        assert self.settings_path is not None
        if section not in self.settings:
            self.settings[section] = {}
        return self.settings[section]

    @property
    def version_file_name(self):
        return str(self._location_path / "version.txt")

    @property
    def version(self):
        if self._version is not None:
            return self._version
        loc = self._location_path
        if not loc.exists() or not any(loc.iterdir()):
            return self.max_version
        version_file = Path(self.version_file_name)
        if not version_file.exists():
            return 0
        else:
            return int(version_file.read_text())

    @property
    def max_version(self):
        return len(self.migrate_from)

    def compute_settings(self):
        if self.location == self.computed_location:
            return
        if self.version > self.max_version:
            self.settings = {}
        else:
            self.settings = (
                load_settings(self.settings_path)
                if Path(self.settings_path).exists()
                else {}
            )
        self.computed_location = self.location

    @property
    def isextension(self):
        return self._location_path.parent.name == "extensions"

    def alias_has_documentation(self):
        for settings_file in glob(self.location + f"/{self.app_name}*json"):
            with json_file(settings_file) as settings:
                if "alias" not in settings:
                    continue

                aliases = settings["alias"]
                new_aliases = {
                    alias: {
                        "commands": commands,
                        "documentation": None,
                    }
                    for alias, commands in aliases.items()
                }
                settings["alias"] = new_aliases
        self.computed_location = None
        self.compute_settings()
        return True

    def stack_of_git_records(self):
        for settings_file in glob(self.location + f"/{self.app_name}*json"):
            with json_file(settings_file) as settings:
                if "git_record" not in settings:
                    continue

                git_records = settings["git_record"]
                new_git_records = {key: [record] for key, record in git_records.items()}
                settings["git_record"] = new_git_records
        self.computed_location = None
        self.compute_settings()
        return True

    def extensions_instead_of_profiles(self):
        if not self.isextension:
            self._extensions_instead_of_profiles()
        return True

    def _extensions_instead_of_profiles(self):
        extensions_dir = self.location + "/extensions/"
        warn = False
        for profile in glob(self.location + "/../.csm-*"):
            profile_name = re.sub("^.+csm-(.+)$", r"\1", profile)
            extension_location = extensions_dir + "/" + profile_name + "_from_profile"
            move(profile, extension_location)
            warn = True
        if warn:
            LOGGER.warning(
                "The profiles were migrated as extensions."
                " As we could not maintain backward compatibility,"
                " please see with SLO or GLE to understand how"
                " to make use of this new setup"
            )

    def extensions_instead_of_settings_level(self):
        if not self.isextension:
            self._extensions_instead_of_settings_level()
        return True

    def _extensions_instead_of_settings_level(self):
        extensions_dir = self.location + "/extensions/"

        def migrate_settings_to_extension(settings_level_file, name):
            if open(settings_level_file, "rb").read().decode("utf-8").strip() == "{}":
                return False
            makedirs(extensions_dir + "/" + name)
            enabled = (
                not json.load(open(settings_level_file))
                .get("_self", {})
                .get("disabled", False)
            )
            order = (
                json.load(open(settings_level_file)).get("_self", {}).get("order", 100)
            )
            move(
                settings_level_file,
                extensions_dir + "/" + name + f"/{self.app_name}.json",
            )
            createfile(
                extensions_dir + "/" + name + "/version.txt", str(self.version + 1)
            )
            createfile(
                extensions_dir + "/" + name + self.JSON_FILE_EXTENSION,
                json.dumps(
                    {
                        "enabled": enabled,
                        "order": order,
                    }
                ),
            )
            return True

        migrate_something = False
        for settings_level_file in glob(self.location + f"/{self.app_name}-*.json"):
            name = re.sub(
                f".+{self.app_name}-([a-zA-Z-]+).json$",
                r"\1",
                settings_level_file,
            )
            name = name.replace("-", "_")
            if name == "private":
                continue
            migrate_something |= migrate_settings_to_extension(
                settings_level_file, name + "_from_settings"
            )
        private = Path(self.location) / f"{self.app_name}-private.json"
        local = Path(self.location) / f"{self.app_name}.json"
        if private.exists():
            if private.read_text().strip() != "{}":
                migrate_something = True
            else:
                rm(private)
        if migrate_something is True:
            name = "migrated_local"
            if local.exists() and local.read_text().strip() != "{}":
                migrate_settings_to_extension(str(local), name)
            if private.exists():
                move(private, local)
            with json_file(local) as values:
                extensions = values.get("recipe", {})
                local_order = extensions.get(name, {})
                local_order["order"] = 0
                extensions[name] = local_order
                values["recipe"] = extensions
            self.computed_location = None
            self.compute_settings()

    def remove_with_legend(self):
        for settings_file in glob(self.location + f"/{self.app_name}*json"):
            content = open(settings_file, "rb").read().decode("utf-8")
            content = content.replace("--with-legend", "--legend")
            open(settings_file, "wb").write(content.encode("utf-8"))
        self.computed_location = None
        self.compute_settings()
        return True

    def hooks_to_trigger(self):
        with json_file(self.settings_path) as settings:
            if "hooks" in settings:
                settings["triggers"] = settings["hooks"]
                del settings["hooks"]
        self.computed_location = None
        self.compute_settings()
        return True

    def customcommand_to_executable(self):
        with json_file(self.settings_path) as settings:
            if "customcommands" in settings:
                customcommands = settings["customcommands"]
                if "externalpaths" in customcommands:
                    customcommands["executablepaths"] = customcommands["externalpaths"]
                    del customcommands["externalpaths"]
        self.computed_location = None
        self.compute_settings()
        return True

    def recipe_to_extension(self):
        recipes_dir = Path(self.location) / "recipes"
        if recipes_dir.exists():
            extensions_dir = Path(self.location) / "extensions"
            move(recipes_dir, extensions_dir)
            for recipe in glob(f"{extensions_dir}/clk_recipe_*"):
                extension = re.sub("/clk_recipe_([^/]+)", r"/clk_extension_\1", recipe)
                move(recipe, extension)
        return True

    def write_settings(self):
        if self.readonly:
            raise click.UsageError(f"Cannot write into {self.name}. It is read only.")
        if self.frozen_during_migration:
            raise click.UsageError(
                "You cannot edit the configuration if the migration is not persisted"
            )
        makedirs(self.location)
        self.write_version()
        return write_settings(self.settings_path, self.settings, self.dry_run)

    def write_version(self):
        if self.frozen_during_migration:
            raise click.UsageError(
                "You cannot edit the configuration if the migration is not persisted"
            )
        makedirs(self.location)
        version = self.version
        createfile(
            self.version_file_name, ensure_unicode(str(version) + "\n"), internal=True
        )

    def migrate_if_needed(self, persist=True):
        self.persist = persist
        if self.version < self.max_version or (
            self.persist and self.prevented_persistence
        ):
            if self.persist and self.old_version != 0:
                LOGGER.warning(
                    f"Profile in {self.location} is obsolete."
                    f" It has the version {self.old_version} and current version is {self.max_version}."
                    " Migration started."
                )
            if self.migrate(persist=self.persist) or (
                self.prevented_persistence and self.persist
            ):
                if self.persist:
                    self.frozen_during_migration = False
                    self.prevented_persistence = False
                    self.write_settings()
                    self.write_version()
                else:
                    self.frozen_during_migration = True
                    self.prevented_persistence = True
                    LOGGER.debug("Migration not persisted")

    def migrate(self, persist=True):
        LOGGER.action(f"migrate profile in {self.location}")
        if self.dry_run:
            return False
        backup_path = Path(self.backup_location)
        loc_path = self._location_path
        if backup_path.exists():
            LOGGER.error(f"{self.backup_location} already exists. Cannot migrate.")
            return False
        makedirs(self.backup_location)
        for name in self.migration_impact:
            src = loc_path / name
            if src.exists():
                copy(src, backup_path / name)
        try:
            res = self._migrate(persist)
        except Exception as e:
            import traceback

            LOGGER.error(e)
            LOGGER.develop(traceback.format_exc())
            res = False
        if res:
            rm(self.backup_location)
        else:
            if persist:
                LOGGER.warning(
                    f"The migration of {self.location} did not go well,"
                    f" Restoring backup from {self.backup_location}"
                )
            for name in self.migration_impact:
                backup_file = backup_path / name
                loc_file = loc_path / name
                if backup_file.exists():
                    if loc_file.exists():
                        rm(loc_file)
                    copy(backup_file, loc_file)
            rm(self.backup_location)
        return res

    def _migrate(self, persist):
        for version, migrator in enumerate(self.migrate_from):
            if self.version == version:
                next_version = version + 1
                if persist:
                    LOGGER.info(
                        f"Migrating from version {version} to version {next_version}"
                    )
                if migrator():
                    self._version = next_version
                else:
                    LOGGER.error(
                        "Something went wrong"
                        " when migrating from "
                        f"version {version} to version {next_version}"
                    )
                    return False
        if persist:
            LOGGER.status(f"Migration successful. Have a nice {part_of_day()} :-).")
        return True


@ProfileFactory.register_preset_profile
class PresetProfile(Profile):
    def __init__(
        self,
        name,
        settings,
        explicit=True,
        isroot=True,
        activation_level=ActivationLevel.global_,
        default_color=None,
        isextension=False,
        readonly=False,
    ):
        self.name = name
        self.default_color = default_color
        self.settings = settings
        self.extensions = []
        self.isroot = isroot
        self.explicit = explicit
        self.activation_level = activation_level
        self.isextension = isextension
        self.readonly = readonly

    def get_settings(self, section):
        if section not in self.settings and not isinstance(
            self.settings, collections.defaultdict
        ):
            self.settings[section] = {}
        return self.settings[section]

    def set_settings(self, section, settings):
        self.settings[section] = settings

    def migrate_if_needed(self, persist=True):
        pass

    def has_extension(self, name):
        return False

    @property
    def friendly_name(self):
        return self.name

    def write_settings(self):
        click.UsageError("A preset profile cannot be written to")

    def compute_settings(self):
        pass


def profile_name_to_commandline(name):
    profile, *extension = name.split("/")
    res = [f"--{profile}"]
    if extension:
        res += ["--extension", extension[0]]
    return res
