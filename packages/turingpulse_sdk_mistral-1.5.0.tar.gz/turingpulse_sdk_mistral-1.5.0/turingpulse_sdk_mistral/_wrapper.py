"""Mistral AI monkey-patch instrumentation for TuringPulse."""

from __future__ import annotations

import logging
import os
from contextvars import ContextVar
from typing import Any, Optional

from turingpulse_sdk import instrument, GovernanceDirective
from turingpulse_sdk.config import MAX_FIELD_SIZE
from turingpulse_sdk.context import current_context
from turingpulse_sdk.exceptions import ConfigurationError

logger = logging.getLogger("turingpulse.sdk.mistral")

_INSTRUMENTING: ContextVar[bool] = ContextVar("_tp_mistral_instrumenting", default=False)

_ORIGINAL_COMPLETE: Any = None


def patch_mistral(
    *,
    name: str | None = None,
    governance: Optional[GovernanceDirective] = None,
) -> None:
    """Monkey-patch ``mistralai.Mistral.chat.complete``."""
    global _ORIGINAL_COMPLETE

    effective_name = name or os.getenv("TP_WORKFLOW_NAME", "")
    if not effective_name:
        raise ConfigurationError(
            "patch_mistral() requires name= or TP_WORKFLOW_NAME to be set."
        )

    try:
        from mistralai import Mistral
    except ImportError as exc:
        raise ImportError("mistralai package is required: pip install mistralai>=0.4.0") from exc

    if _ORIGINAL_COMPLETE is not None:
        logger.warning("Mistral is already patched — skipping")
        return

    chat_cls = getattr(Mistral, "chat", None)
    if chat_cls is None:
        try:
            from mistralai.chat import Chat
            chat_cls = Chat
        except ImportError:
            logger.warning(
                "Cannot locate Mistral.chat or Chat class — Mistral SDK version may be incompatible. Skipping patch."
            )
            return

    _ORIGINAL_COMPLETE = getattr(chat_cls, "complete", None)
    if _ORIGINAL_COMPLETE is None or not callable(_ORIGINAL_COMPLETE):
        _ORIGINAL_COMPLETE = None
        logger.warning(
            "Cannot locate Chat.complete — Mistral SDK version may be incompatible. Skipping patch."
        )
        return

    @instrument(name=effective_name, governance=governance)
    def _patched_complete(self_chat, *args: Any, **kwargs: Any) -> Any:
        if _INSTRUMENTING.get(False):
            return _ORIGINAL_COMPLETE(self_chat, *args, **kwargs)
        token = _INSTRUMENTING.set(True)
        try:
            response = _ORIGINAL_COMPLETE(self_chat, *args, **kwargs)
            _record_mistral_span(response, kwargs)
            return response
        finally:
            _INSTRUMENTING.reset(token)

    try:
        chat_cls.complete = _patched_complete
    except (AttributeError, TypeError) as exc:
        _ORIGINAL_COMPLETE = None
        logger.warning("Failed to patch Chat.complete: %s", type(exc).__name__)
        return
    logger.info("Mistral patched for TuringPulse instrumentation")


def unpatch_mistral() -> None:
    """Restore original Mistral methods."""
    global _ORIGINAL_COMPLETE
    if _ORIGINAL_COMPLETE is None:
        return
    try:
        from mistralai.chat import Chat
        Chat.complete = _ORIGINAL_COMPLETE
    except ImportError:
        try:
            from mistralai import Mistral
            if hasattr(Mistral, "chat"):
                Mistral.chat.complete = _ORIGINAL_COMPLETE
        except ImportError:
            pass
    _ORIGINAL_COMPLETE = None
    logger.info("Mistral unpatched — original methods restored")


def _record_mistral_span(response: Any, kwargs: dict) -> None:
    ctx = current_context()
    if not ctx:
        return
    ctx.framework = "mistral"
    ctx.node_type = "llm"

    usage = getattr(response, "usage", None)
    if usage:
        ctx.set_tokens(
            getattr(usage, "prompt_tokens", 0) or 0,
            getattr(usage, "completion_tokens", 0) or 0,
        )

    ctx.set_model(kwargs.get("model", getattr(response, "model", "unknown")), "mistral")

    messages = kwargs.get("messages", [])
    if messages:
        last_user = next(
            (m for m in reversed(messages) if (m.get("role") if isinstance(m, dict) else getattr(m, "role", "")) == "user"),
            None,
        )
        if last_user:
            content = last_user.get("content", "") if isinstance(last_user, dict) else getattr(last_user, "content", "")
            ctx.set_prompt(str(content)[:MAX_FIELD_SIZE])

    tools_def = kwargs.get("tools")
    if tools_def:
        tool_names = []
        for t in tools_def:
            func = t.get("function") if isinstance(t, dict) else getattr(t, "function", None)
            if func:
                tname = func.get("name") if isinstance(func, dict) else getattr(func, "name", None)
                if tname:
                    tool_names.append(tname)
        if tool_names:
            ctx.available_tools = tool_names

    choices = getattr(response, "choices", [])
    if choices:
        message = getattr(choices[0], "message", None)
        if message:
            content = getattr(message, "content", "")
            if content:
                ctx.set_io(output_data=str(content)[:MAX_FIELD_SIZE])

            tool_calls = getattr(message, "tool_calls", None)
            if tool_calls:
                for tc in tool_calls:
                    func = getattr(tc, "function", None)
                    if func:
                        ctx.add_tool_call(
                            tool_name=getattr(func, "name", "unknown"),
                            tool_args={"arguments": getattr(func, "arguments", "")},
                            tool_id=getattr(tc, "id", None),
                        )
