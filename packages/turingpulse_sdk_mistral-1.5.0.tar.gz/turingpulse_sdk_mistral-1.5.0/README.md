# turingpulse-sdk-mistral

TuringPulse SDK integration for Mistral AI — automatic tracing for Mistral Large and Mixtral models.

## Installation

```bash
pip install turingpulse-sdk-mistral
```

## Quick Start

```python
from mistralai import Mistral
from turingpulse_sdk import init, TuringPulseConfig
from turingpulse_sdk_mistral import patch_mistral

init(TuringPulseConfig(api_key="sk_live_...", workflow_name="my-project"))
patch_mistral(name="my-project")

client = Mistral(api_key="...")
response = client.chat.complete(
    model="mistral-large-latest",
    messages=[{"role": "user", "content": "Hello!"}]
)
```

## Documentation

Full documentation: [turingpulse.ai/docs/sdk/mistral](https://turingpulse.ai/docs/sdk/mistral)

## Requirements

- Python >= 3.11
- turingpulse-sdk >= 1.0.0
- mistralai >= 0.4.0
