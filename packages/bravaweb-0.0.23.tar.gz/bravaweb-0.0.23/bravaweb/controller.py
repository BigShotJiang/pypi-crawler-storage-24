# -*- coding: utf-8 -*-

from bravaweb.security.methods import *
from bravaweb.security.decorator import require
from bravaweb.utils import ResponseType, ResponseCode, RequestMethod
from bravaweb.response import *

from datetime import datetime
import decimal

import configuration

class Controller(object):

    def __init__(self, environment=None, **kwargs):
        self.environment = environment or kwargs.get('envirom') or kwargs.get('enviroment')
        super(Controller, self).__init__()

    # TODO VERIFICAR SE ESTA USANDO ELE, O ENTER OU EXIT
    def __del__(self):
        pass

    async def NotAllowed(self):

        content = "405: Method not allowed".encode(configuration.api.encoding)

        _headers = [
            (b'content-type', b'text/html; charset=utf-8'),
            (b"Content-Length", str(len(content)).encode(configuration.api.encoding)),
            (b"Accept-Ranges", b"bytes"),
            (b"X-Frame-Options", b"Deny")
        ]

        if self.environment.origin:
            _headers.append((b"Access-Control-Allow-Origin", self.environment.origin.encode(configuration.api.encoding)))

        await self.environment.send({
            'type': 'http.response.start',
            'status': ResponseCode.MethodNotAllowed.code,
            'headers': _headers
        })

        await self.environment.send({
            'type': 'http.response.body',
            'body': content
        })

    async def Unauthorized(self):

        content = "401: Unauthorized".encode(configuration.api.encoding)

        _headers = [
            (b'content-type', b'text/html; charset=utf-8'),
            (b"Content-Length", str(len(content)).encode(configuration.api.encoding)),
            (b"Accept-Ranges", b"bytes"),
            (b"X-Frame-Options", b"Deny")
        ]

        if self.environment.origin:
            _headers.append((b"Access-Control-Allow-Origin", self.environment.origin.encode(configuration.api.encoding)))

        await self.environment.send({
            'type': 'http.response.start',
            'status': ResponseCode.Unauthorized.code,
            'headers': _headers
        })

        await self.environment.send({
            'type': 'http.response.body',
            'body': content
        })

    async def NotFound(self):

        content = "404: Not Found".encode(configuration.api.encoding)

        _headers = [
            (b'content-type', b'text/html; charset=utf-8'),
            (b"Content-Length", str(len(content)).encode(configuration.api.encoding)),
            (b"Accept-Ranges", b"bytes"),
            (b"X-Frame-Options", b"Deny")
        ]

        if self.environment.origin:
            _headers.append((b"Access-Control-Allow-Origin", self.environment.origin.encode(configuration.api.encoding)))

        await self.environment.send({
            'type': 'http.response.start',
            'status': ResponseCode.NotFound.code,
            'headers': _headers
        })

        await self.environment.send({
            'type': 'http.response.body',
            'body': content
        })

    async def NoContent(self):

        content = "204: No Content".encode(configuration.api.encoding)

        _headers = [
            (b'content-type', b'text/html; charset=utf-8'),
            (b"Content-Length", str(len(content)).encode(configuration.api.encoding)),
            (b"Accept-Ranges", b"bytes"),
            (b"X-Frame-Options", b"Deny")
        ]

        if self.environment.origin:
            _headers.append((b"Access-Control-Allow-Origin", self.environment.origin.encode(configuration.api.encoding)))

        await self.environment.send({
            'type': 'http.response.start',
            'status': ResponseCode.NoContent.code,
            'headers': _headers
        })

        await self.environment.send({
            'type': 'http.response.body',
            'body': content
        })

    async def PreconditionFailed(self, errors):

        if errors:
            Error("Precondition Failed", errors, traceback=False)

        debug = getattr(configuration.api, "debug", False)
        if debug:
            content = Json().Response(errors, success=False, error="Precondition Failed")
            _content_type = b'application/json; charset=utf-8'
        else:
            content = "412: Precondition Failed".encode(configuration.api.encoding)
            _content_type = b'text/html; charset=utf-8'

        _headers = [
            (b'content-type', _content_type),
            (b"Content-Length", str(len(content)).encode(configuration.api.encoding)),
            (b"Accept-Ranges", b"bytes"),
            (b"X-Frame-Options", b"Deny")
        ]

        if self.environment.origin:
            _headers.append((b"Access-Control-Allow-Origin", self.environment.origin.encode(configuration.api.encoding)))

        await self.environment.send({
            'type': 'http.response.start',
            'status': ResponseCode.PreconditionFailed.code,
            'headers': _headers
        })

        await self.environment.send({
            'type': 'http.response.body',
            'body': content
        })

    async def InternalError(self, e=None):

        debug = getattr(configuration.api, "debug", False)
        if debug:
            import traceback
            error_details = {
                "message": str(e) if e else "Internal Server Error",
                "traceback": traceback.format_exc()
            }
            content = Json().Response(error_details, success=False, error="Internal Error")
            _content_type = b'application/json; charset=utf-8'
        else:
            content = "500: Internal Error".encode(configuration.api.encoding)
            _content_type = b'text/html; charset=utf-8'

        _headers = [
            (b'content-type', _content_type),
            (b"Content-Length", str(len(content)).encode(configuration.api.encoding)),
            (b"Accept-Ranges", b"bytes"),
            (b"X-Frame-Options", b"Deny")
        ]

        if self.environment and hasattr(self.environment, 'origin') and self.environment.origin:
            _headers.append((b"Access-Control-Allow-Origin", self.environment.origin.encode(configuration.api.encoding)))

        await self.environment.send({
            'type': 'http.response.start',
            'status': ResponseCode.InternalError.code,
            'headers': _headers
        })

        await self.environment.send({
            'type': 'http.response.body',
            'body': content
        })
