Xml = "<xml> \
        <token/>\
        <success/>\
        <date/>\
        <items/>\
        <data/>\
       </xml>"

Json = {
    "token": "",
    "success": True,
    "date": "",
    "items": 0,
    "data": [],
}
