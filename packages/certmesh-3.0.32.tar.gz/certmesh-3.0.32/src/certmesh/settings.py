"""
certmesh.settings
==================

Environment-variable-first configuration layer.

Precedence (lowest -> highest):
  defaults < YAML file < environment variables (``CM_*``)
"""

from __future__ import annotations

import logging
import os
from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml

from certmesh import JsonDict
from certmesh.exceptions import ConfigurationError

logger = logging.getLogger(__name__)

# =============================================================================
# Built-in defaults
# =============================================================================

_DEFAULTS: JsonDict = {
    "vault": {
        "url": "",
        "auth_method": "approle",
        "tls_verify": True,
        "timeout_seconds": 30,
        "approle": {
            "role_id_env": "CM_VAULT_ROLE_ID",
            "secret_id_env": "CM_VAULT_SECRET_ID",
        },
        "ldap": {
            "username_env": "CM_VAULT_LDAP_USERNAME",
            "password_env": "CM_VAULT_LDAP_PASSWORD",
            "mount_point": "ldap",
        },
        "aws_iam": {
            "role": "",
            "mount_point": "aws",
            "region": None,
            "header_value": None,
        },
        "kv_version": 2,
        "pki": {
            "mount_point": "pki",
            "role_name": "",
            "ttl": "8760h",
            "max_ttl": "",
        },
        "paths": {
            "digicert_api_key": "secret/certmesh/digicert/api_key",
            "venafi_credentials": "secret/certmesh/venafi/credentials",
        },
    },
    "digicert": {
        "base_url": "https://www.digicert.com/services/v2",
        "timeout_seconds": 30,
        "tls_verify": True,
        "ca_bundle": "",
        "connection_pool": {
            "pool_connections": 10,
            "pool_maxsize": 20,
        },
        "output": {
            "destination": "filesystem",
            "base_path": "/etc/certmesh/tls/digicert",
            "cert_filename": "{order_id}_cert.pem",
            "key_filename": "{order_id}_key.pem",
            "chain_filename": "{order_id}_chain.pem",
            "vault_path_template": "secret/certmesh/tls/digicert/{order_id}",
            "sm_secret_name_template": "",
            "sm_region": "",
        },
        "certificate": {
            "key_size": 4096,
            "product_name_id": "ssl_plus",
            "validity_years": 1,
            "signature_hash": "sha256",
            "organization_id": None,
            "subject": {
                "country": "US",
                "state": "",
                "locality": "",
                "organisation": "",
                "organisational_unit": "",
            },
        },
        "polling": {
            "interval_seconds": 15,
            "max_wait_seconds": 1800,
        },
        "retry": {
            "max_attempts": 5,
            "wait_min_seconds": 2,
            "wait_max_seconds": 60,
            "wait_multiplier": 1.5,
        },
        "circuit_breaker": {
            "failure_threshold": 5,
            "recovery_timeout_seconds": 120,
        },
    },
    "venafi": {
        "base_url": "",
        "auth_method": "oauth",
        "oauth_client_id": "certapi",
        "oauth_scope": "certificate:manage",
        "tls_verify": True,
        "timeout_seconds": 30,
        "output": {
            "destination": "filesystem",
            "base_path": "/etc/certmesh/tls/venafi",
            "cert_filename": "{guid}_cert.pem",
            "key_filename": "{guid}_key.pem",
            "chain_filename": "{guid}_chain.pem",
            "vault_path_template": "secret/certmesh/tls/venafi/{guid}",
            "sm_secret_name_template": "",
            "sm_region": "",
        },
        "certificate": {
            "key_size": 4096,
            "pkcs12_export_passphrase_env": "CM_VENAFI_PKCS12_PASSPHRASE",
        },
        "approval": {
            "reason": "Automated renewal approved by certmesh",
        },
        "polling": {
            "interval_seconds": 15,
            "max_wait_seconds": 1800,
        },
        "retry": {
            "max_attempts": 5,
            "wait_min_seconds": 2,
            "wait_max_seconds": 60,
            "wait_multiplier": 1.5,
        },
        "circuit_breaker": {
            "failure_threshold": 5,
            "recovery_timeout_seconds": 120,
        },
    },
    "acm": {
        "region": "",
        "timeout_seconds": 30,
        "output": {
            "destination": "filesystem",
            "base_path": "/etc/certmesh/tls/acm",
            "cert_filename": "{cert_arn_short}_cert.pem",
            "key_filename": "{cert_arn_short}_key.pem",
            "chain_filename": "{cert_arn_short}_chain.pem",
            "sm_secret_name_template": "",
            "sm_region": "",
        },
        "certificate": {
            "key_algorithm": "RSA_2048",
            "validation_method": "DNS",
            "idempotency_token": "",
        },
        "private_ca": {
            "ca_arn": "",
            "signing_algorithm": "SHA256WITHRSA",
            "validity_days": 365,
            "template_arn": "",
        },
        "polling": {
            "interval_seconds": 10,
            "max_wait_seconds": 600,
        },
    },
    "remote": {
        "url": "",
        "timeout_seconds": 30,
        "ca_cert": "",
        "verify_tls": True,
        "retry_attempts": 3,
        "retry_backoff_multiplier": 1.0,
        "circuit_breaker_threshold": 5,
        "circuit_breaker_recovery_seconds": 30,
    },
    "logging": {
        "level": "INFO",
        "format": ("%(asctime)s [%(levelname)s] %(name)s - %(funcName)s:%(lineno)d - %(message)s"),
        "datefmt": "%Y-%m-%dT%H:%M:%S",
        "log_format": "json",
    },
}


# =============================================================================
# Public API
# =============================================================================


def build_config(config_file: str | Path | None = None) -> JsonDict:
    """Build the complete application configuration."""
    cfg = deepcopy(_DEFAULTS)

    if config_file is not None:
        path = Path(config_file).resolve()
        if not path.exists():
            raise ConfigurationError(f"Config file specified but not found: {path}")
        try:
            with path.open(encoding="utf-8") as fh:
                from_file: JsonDict = yaml.safe_load(fh) or {}
        except yaml.YAMLError as exc:
            raise ConfigurationError(f"Failed to parse config YAML at '{path}': {exc}") from exc
        if not isinstance(from_file, dict):
            raise ConfigurationError(
                f"Config file '{path}' does not contain a YAML mapping at the top level."
            )
        cfg = _deep_merge(cfg, from_file)
        logger.debug("Loaded config file '%s'.", path)

    cfg = _deep_merge(cfg, _env_overrides())
    logger.debug("Configuration built (file=%s).", config_file)
    return cfg


def configure_logging(logging_cfg: JsonDict) -> None:
    """Apply structured logging from the logging config section."""
    import sys as _sys

    level_name: str = logging_cfg.get("level", "INFO").upper()
    level = getattr(logging, level_name, logging.INFO)
    logging.basicConfig(
        level=level,
        format=logging_cfg.get(
            "format",
            "%(asctime)s [%(levelname)s] %(name)s - %(message)s",
        ),
        datefmt=logging_cfg.get("datefmt"),
        stream=_sys.stderr,
        force=True,
    )
    logger.debug("Logging configured at level '%s'.", level_name)


# =============================================================================
# Environment variable -> config path mappings
# =============================================================================

# Each entry is (config_path, env_var, converter).
# ``str`` entries use the raw env value; ``"bool"`` / ``"int"`` apply
# ``safe_bool`` / ``safe_int`` with ``default=None`` so that unset vars
# produce ``None`` and are skipped by ``_sset``.
_ENV_MAPPINGS: list[tuple[list[str], str, str]] = [
    # --- Vault ---
    (["vault", "url"], "CM_VAULT_URL", "str"),
    (["vault", "auth_method"], "CM_VAULT_AUTH_METHOD", "str"),
    (["vault", "tls_verify"], "CM_VAULT_TLS_VERIFY", "bool"),
    (["vault", "timeout_seconds"], "CM_VAULT_TIMEOUT", "int"),
    (["vault", "ldap", "mount_point"], "CM_VAULT_LDAP_MOUNT_POINT", "str"),
    (["vault", "aws_iam", "role"], "CM_VAULT_AWS_ROLE", "str"),
    (["vault", "aws_iam", "mount_point"], "CM_VAULT_AWS_MOUNT_POINT", "str"),
    (["vault", "aws_iam", "region"], "CM_VAULT_AWS_REGION", "str"),
    (["vault", "aws_iam", "header_value"], "CM_VAULT_AWS_HEADER_VALUE", "str"),
    (["vault", "kv_version"], "CM_VAULT_KV_VERSION", "int"),
    (["vault", "pki", "mount_point"], "CM_VAULT_PKI_MOUNT", "str"),
    (["vault", "pki", "role_name"], "CM_VAULT_PKI_ROLE", "str"),
    (["vault", "pki", "ttl"], "CM_VAULT_PKI_TTL", "str"),
    (["vault", "paths", "digicert_api_key"], "CM_VAULT_PATH_DIGICERT", "str"),
    (["vault", "paths", "venafi_credentials"], "CM_VAULT_PATH_VENAFI", "str"),
    # --- DigiCert ---
    (["digicert", "base_url"], "CM_DIGICERT_BASE_URL", "str"),
    (["digicert", "timeout_seconds"], "CM_DIGICERT_TIMEOUT", "int"),
    (["digicert", "tls_verify"], "CM_DIGICERT_TLS_VERIFY", "bool"),
    (["digicert", "ca_bundle"], "CM_DIGICERT_CA_BUNDLE", "str"),
    (["digicert", "connection_pool", "pool_connections"], "CM_DIGICERT_POOL_CONNECTIONS", "int"),
    (["digicert", "connection_pool", "pool_maxsize"], "CM_DIGICERT_POOL_MAXSIZE", "int"),
    (["digicert", "output", "destination"], "CM_DIGICERT_OUTPUT_DEST", "str"),
    (["digicert", "output", "base_path"], "CM_DIGICERT_OUTPUT_PATH", "str"),
    (["digicert", "output", "vault_path_template"], "CM_DIGICERT_VAULT_PATH", "str"),
    (["digicert", "output", "sm_secret_name_template"], "CM_DIGICERT_SM_SECRET_NAME", "str"),
    (["digicert", "output", "sm_region"], "CM_DIGICERT_SM_REGION", "str"),
    (["digicert", "certificate", "key_size"], "CM_DIGICERT_KEY_SIZE", "int"),
    (["digicert", "certificate", "product_name_id"], "CM_DIGICERT_PRODUCT", "str"),
    (["digicert", "certificate", "validity_years"], "CM_DIGICERT_VALIDITY_YEARS", "int"),
    (["digicert", "certificate", "organization_id"], "CM_DIGICERT_ORG_ID", "str"),
    (["digicert", "certificate", "subject", "organisation"], "CM_DIGICERT_SUBJECT_ORG", "str"),
    (
        ["digicert", "certificate", "subject", "organisational_unit"],
        "CM_DIGICERT_SUBJECT_OU",
        "str",
    ),
    (["digicert", "certificate", "subject", "country"], "CM_DIGICERT_SUBJECT_COUNTRY", "str"),
    (["digicert", "certificate", "subject", "state"], "CM_DIGICERT_SUBJECT_STATE", "str"),
    (["digicert", "certificate", "subject", "locality"], "CM_DIGICERT_SUBJECT_LOCALITY", "str"),
    (["digicert", "polling", "interval_seconds"], "CM_DIGICERT_POLL_INTERVAL", "int"),
    (["digicert", "polling", "max_wait_seconds"], "CM_DIGICERT_POLL_MAX_WAIT", "int"),
    (["digicert", "retry", "max_attempts"], "CM_DIGICERT_RETRY_ATTEMPTS", "int"),
    # --- Venafi ---
    (["venafi", "base_url"], "CM_VENAFI_BASE_URL", "str"),
    (["venafi", "auth_method"], "CM_VENAFI_AUTH_METHOD", "str"),
    (["venafi", "oauth_client_id"], "CM_VENAFI_OAUTH_CLIENT_ID", "str"),
    (["venafi", "oauth_scope"], "CM_VENAFI_OAUTH_SCOPE", "str"),
    (["venafi", "tls_verify"], "CM_VENAFI_TLS_VERIFY", "bool"),
    (["venafi", "timeout_seconds"], "CM_VENAFI_TIMEOUT", "int"),
    (["venafi", "output", "destination"], "CM_VENAFI_OUTPUT_DEST", "str"),
    (["venafi", "output", "base_path"], "CM_VENAFI_OUTPUT_PATH", "str"),
    (["venafi", "output", "vault_path_template"], "CM_VENAFI_VAULT_PATH", "str"),
    (["venafi", "output", "sm_secret_name_template"], "CM_VENAFI_SM_SECRET_NAME", "str"),
    (["venafi", "output", "sm_region"], "CM_VENAFI_SM_REGION", "str"),
    (["venafi", "certificate", "key_size"], "CM_VENAFI_KEY_SIZE", "int"),
    (["venafi", "approval", "reason"], "CM_VENAFI_APPROVAL_REASON", "str"),
    # --- ACM ---
    (["acm", "region"], "CM_ACM_REGION", "str"),
    (["acm", "output", "destination"], "CM_ACM_OUTPUT_DEST", "str"),
    (["acm", "output", "base_path"], "CM_ACM_OUTPUT_PATH", "str"),
    (["acm", "output", "sm_secret_name_template"], "CM_ACM_SM_SECRET_NAME", "str"),
    (["acm", "output", "sm_region"], "CM_ACM_SM_REGION", "str"),
    (["acm", "certificate", "key_algorithm"], "CM_ACM_KEY_ALGORITHM", "str"),
    (["acm", "certificate", "validation_method"], "CM_ACM_VALIDATION_METHOD", "str"),
    (["acm", "private_ca", "ca_arn"], "CM_ACM_PCA_ARN", "str"),
    (["acm", "private_ca", "signing_algorithm"], "CM_ACM_PCA_SIGNING_ALGORITHM", "str"),
    (["acm", "private_ca", "validity_days"], "CM_ACM_PCA_VALIDITY_DAYS", "int"),
    # --- Remote ---
    (["remote", "url"], "CM_REMOTE_URL", "str"),
    (["remote", "timeout_seconds"], "CM_REMOTE_TIMEOUT", "int"),
    (["remote", "ca_cert"], "CM_REMOTE_CA_CERT", "str"),
    (["remote", "verify_tls"], "CM_REMOTE_TLS_VERIFY", "bool"),
    (["remote", "retry_attempts"], "CM_REMOTE_RETRY_ATTEMPTS", "int"),
    # --- Logging ---
    (["logging", "level"], "CM_LOG_LEVEL", "str"),
    (["logging", "log_format"], "CM_LOG_FORMAT", "str"),
]


def _env_overrides() -> JsonDict:
    """Read all ``CM_*`` environment variables and return as a partial config dict.

    Uses the declarative ``_ENV_MAPPINGS`` table to map env vars to config
    paths with automatic type conversion.  ``_sset`` skips ``None`` values
    so unset env vars do not pollute the config.
    """
    overrides: JsonDict = {}
    for path, env_var, converter in _ENV_MAPPINGS:
        raw = os.environ.get(env_var)
        if converter == "bool":
            value = safe_bool(raw, default=None)
        elif converter == "int":
            value = safe_int(raw, default=None)
        else:
            value = raw
        _sset(overrides, path, value)
    return overrides


# =============================================================================
# Configuration validation
# =============================================================================

_VAULT_AUTH_METHODS: frozenset[str] = frozenset({"approle", "ldap", "aws_iam"})
_VENAFI_AUTH_METHODS: frozenset[str] = frozenset({"oauth", "ldap"})
_OUTPUT_DESTINATIONS: frozenset[str] = frozenset({"filesystem", "vault", "both"})
_VALID_DESTINATION_VALUES: frozenset[str] = frozenset({"filesystem", "vault", "secrets_manager"})


def normalize_destinations(raw: str | list[str]) -> list[str]:
    """Normalise the ``output.destination`` value to a list of destination strings.

    Accepted inputs:
    - Legacy string ``"filesystem"`` / ``"vault"`` / ``"both"``
    - New-style list ``["filesystem", "vault", "secrets_manager"]``
    """
    if isinstance(raw, list):
        result = [str(d).strip() for d in raw if str(d).strip()]
    elif raw == "both":
        result = ["filesystem", "vault"]
    else:
        result = [str(raw).strip()] if str(raw).strip() else []

    invalid = set(result) - _VALID_DESTINATION_VALUES
    if invalid:
        raise ConfigurationError(
            f"Invalid output destination(s): {sorted(invalid)}. "
            f"Supported: {sorted(_VALID_DESTINATION_VALUES)}."
        )
    return result


def validate_config(cfg: JsonDict) -> None:
    """Validate a fully merged configuration dictionary."""
    _validate_vault(cfg.get("vault", {}))
    _validate_digicert(cfg.get("digicert", {}))
    _validate_venafi(cfg.get("venafi", {}))


def _validate_vault(vault: JsonDict) -> None:
    if not vault.get("url"):
        raise ConfigurationError(
            "vault.url is required. Set CM_VAULT_URL or vault.url in the config file."
        )
    auth_method: str = vault.get("auth_method", "")
    if auth_method not in _VAULT_AUTH_METHODS:
        raise ConfigurationError(
            f"vault.auth_method '{auth_method}' is not supported. "
            f"Supported: {sorted(_VAULT_AUTH_METHODS)}. Set CM_VAULT_AUTH_METHOD."
        )
    if auth_method == "aws_iam" and not vault.get("aws_iam", {}).get("role"):
        raise ConfigurationError(
            "vault.auth_method is 'aws_iam' but no role is configured. Set CM_VAULT_AWS_ROLE."
        )


def _validate_digicert(digicert: JsonDict) -> None:
    output = digicert.get("output", {})
    dest = output.get("destination", "filesystem")
    # Validate destination: accept both legacy strings and list format
    if not isinstance(dest, list) and dest not in _OUTPUT_DESTINATIONS:
        raise ConfigurationError(
            f"digicert.output.destination '{dest}' is invalid. "
            f"Supported: {sorted(_OUTPUT_DESTINATIONS)}."
        )
    destinations = normalize_destinations(dest)
    if "vault" in destinations and not output.get("vault_path_template"):
        raise ConfigurationError(
            "digicert output destination includes 'vault' but no vault_path_template is set."
        )
    if "secrets_manager" in destinations and not output.get("sm_secret_name_template"):
        raise ConfigurationError(
            "digicert output destination includes 'secrets_manager' but no "
            "sm_secret_name_template is set."
        )


def _validate_venafi(venafi: JsonDict) -> None:
    # venafi.base_url is only required when the venafi section has been
    # explicitly configured (auth_method overridden or output destination set).
    # This avoids failing validation for users who only use ACM or DigiCert.
    output = venafi.get("output", {})
    dest = output.get("destination", "filesystem")
    has_venafi_config = (
        venafi.get("auth_method") != "oauth"
        or (isinstance(dest, str) and dest != "filesystem")
        or isinstance(dest, list)
    )
    if has_venafi_config and not venafi.get("base_url"):
        raise ConfigurationError("venafi.base_url is required. Set CM_VENAFI_BASE_URL.")
    auth_method: str = venafi.get("auth_method", "oauth")
    if auth_method not in _VENAFI_AUTH_METHODS:
        raise ConfigurationError(
            f"venafi.auth_method '{auth_method}' is not supported. "
            f"Supported: {sorted(_VENAFI_AUTH_METHODS)}."
        )
    # Validate destination: accept both legacy strings and list format
    destinations = normalize_destinations(dest)
    if not isinstance(dest, list) and dest not in _OUTPUT_DESTINATIONS:
        raise ConfigurationError(
            f"venafi.output.destination '{dest}' is invalid. "
            f"Supported: {sorted(_OUTPUT_DESTINATIONS)}."
        )
    # Validate required templates for vault/secrets_manager destinations
    if "vault" in destinations and not output.get("vault_path_template"):
        raise ConfigurationError(
            "venafi output destination includes 'vault' but no vault_path_template is set."
        )
    if "secrets_manager" in destinations and not output.get("sm_secret_name_template"):
        raise ConfigurationError(
            "venafi output destination includes 'secrets_manager' but no "
            "sm_secret_name_template is set."
        )


# =============================================================================
# Helpers
# =============================================================================


def _deep_merge(base: JsonDict, override: JsonDict) -> JsonDict:
    """Recursively merge ``override`` into a copy of ``base``."""
    result = deepcopy(base)
    for key, value in override.items():
        if value is None:
            continue
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = deepcopy(value)
    return result


def _sset(d: JsonDict, path: list[str], value: Any) -> None:
    """Set a value at a nested dict path only when ``value`` is not ``None``."""
    if value is None:
        return
    node = d
    for key in path[:-1]:
        node = node.setdefault(key, {})
    node[path[-1]] = value


def safe_bool(raw: str | None, default: bool | None = False) -> bool | None:
    """Convert a string env var to bool with a default.

    Returns *default* when *raw* is ``None`` (env var unset).
    Pass ``default=None`` to return ``None`` for unset variables.
    """
    if raw is None:
        return default
    return raw.strip().lower() in ("1", "true", "yes", "on")


def safe_int(raw: str | None, default: int | None = 0) -> int | None:
    """Convert a string to int, returning *default* on ``None`` or parse failure.

    Pass ``default=None`` to return ``None`` for unset variables.
    """
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError:
        if default is not None:
            logger.warning(
                "Could not convert env var value '%s' to int; using default %d.", raw, default
            )
        else:
            logger.warning("Could not convert env var value '%s' to int; ignoring.", raw)
        return default
