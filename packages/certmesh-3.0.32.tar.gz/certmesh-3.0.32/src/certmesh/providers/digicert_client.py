"""
certmesh.digicert_client
==========================

DigiCert CertCentral Services API v2 client supporting the full
certificate lifecycle: list, search, describe, order, download,
revoke, and duplicate.

API reference
    https://dev.digicert.com/en/certcentral-apis.html
Base URL
    ``https://www.digicert.com/services/v2``
EU base URL
    ``https://certcentral.eu.digicert.com/services/v2``
Authentication
    ``X-DC-DEVKEY`` header carrying a CertCentral API key.
    API keys **do not expire**; they can be revoked via
    *CertCentral → Automation → API Keys*.
Rate limits
    * 1 000 requests per 3 minutes (global)
    * 100 requests per 5 seconds (burst)
    * **No rate-limit headers** are returned by the API.
Certificate validity
    Max 199 days (as of Feb 2026; dropping to 100 days from Mar 2027).
    Use the ``order_validity`` object (``years`` or ``days`` key) instead
    of the legacy ``validity_years`` / ``validity_days`` top-level fields.
"""

from __future__ import annotations

import io
import logging
import os
import time
import uuid
import zipfile
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

import hvac
import requests
from requests.adapters import HTTPAdapter
from tenacity import (
    RetryError,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from certmesh import JsonDict
from certmesh import certificate_utils as cu
from certmesh import credentials as creds
from certmesh.certificate_utils import CertificateBundle, SubjectInfo
from certmesh.circuit_breaker import create_circuit_breaker
from certmesh.exceptions import (
    DigiCertAPIError,
    DigiCertAuthenticationError,
    DigiCertCertificateNotReadyError,
    DigiCertDownloadError,
    DigiCertError,
    DigiCertOrderNotFoundError,
    DigiCertPollingTimeoutError,
    DigiCertRateLimitError,
)

logger = logging.getLogger(__name__)

# DigiCert date format used in most API responses.
_DIGICERT_DATE_FMT = "%Y-%m-%d"

# Maximum number of bytes from an error response body included in exception messages.
_MAX_ERROR_BODY: int = 500

# Valid DigiCert revocation reasons per CertCentral API v2 spec.
# Ref: PUT /certificate/{id}/revoke — ``revocation_reason`` field.
# NOTE: ``ca_compromise`` is NOT a valid CertCentral reason.
# NOTE: The spec uses ``affiliation_change`` (no trailing "d").
_VALID_REVOCATION_REASONS: frozenset[str] = frozenset(
    {
        "unspecified",
        "key_compromise",
        "affiliation_change",
        "superseded",
        "cessation_of_operation",
    }
)


# =============================================================================
# Data models
# =============================================================================


@dataclass(slots=True, frozen=True)
class OrderRequest:
    """Parameters for a new DigiCert CertCentral certificate order.

    Spec reference: ``POST /order/certificate/{product_name_id}``

    The ``order_validity`` object (either ``years`` or ``days``) replaces the
    legacy ``validity_years`` / ``validity_days`` top-level fields.  When
    ``validity_days`` is set it takes precedence over ``validity_years``.

    ``skip_approval`` must be ``True`` for automated (non-interactive)
    workflows — otherwise the order is held for admin approval.
    """

    common_name: str
    san_dns_names: list[str] = field(default_factory=list)
    organisation: str = ""
    organisational_unit: str = ""
    country: str = "US"
    state: str = ""
    locality: str = ""
    product_name_id: str = "ssl_plus"
    validity_years: int = 1
    validity_days: int | None = None  # Alternative: max 199 days (Feb 2026 policy)
    signature_hash: str = "sha256"
    organization_id: int | None = None
    key_size: int = 4096
    comments: str = ""
    payment_method: str = "balance"  # "balance" (account) or "card"
    skip_approval: bool = True  # bypass admin approval for automation
    dcv_method: str = ""  # "dns-txt-token", "dns-cname-token", "email", "http-token"


@dataclass(slots=True, frozen=True)
class IssuedCertificateSummary:
    """Condensed representation of a certificate returned by list / search."""

    certificate_id: int
    order_id: int
    common_name: str
    serial_number: str
    status: str
    valid_from: str
    valid_till: str
    product_name: str


@dataclass(slots=True, frozen=True)
class DigiCertCertificateDetail:
    """Full detail for a single certificate from the ``/certificate/{id}`` endpoint."""

    certificate_id: int
    order_id: int
    common_name: str
    serial_number: str
    status: str
    valid_from: str
    valid_till: str
    product_name: str
    sans: list[str]
    organization: str
    signature_hash: str
    key_size: int
    thumbprint: str
    raw: JsonDict


# =============================================================================
# HTTP helpers
# =============================================================================


class _RequestIDAdapter(HTTPAdapter):
    """HTTPAdapter that injects a unique ``X-Request-ID`` into every request.

    Also logs every outbound request and response for operational visibility,
    and attaches the request ID and endpoint URL to the response object so that
    the error handler can include them in exception messages.
    """

    def send(  # type: ignore[override]
        self,
        request: requests.PreparedRequest,
        *args: Any,
        **kwargs: Any,
    ) -> requests.Response:
        rid = str(uuid.uuid4())
        request.headers["X-Request-ID"] = rid  # type: ignore[index]
        logger.debug(
            "DigiCert >>> request sent.",
            extra={"method": request.method, "url": request.url, "request_id": rid},
        )
        response = super().send(request, *args, **kwargs)
        response.certmesh_request_id = rid  # type: ignore[attr-defined]
        response.certmesh_endpoint = str(request.url)  # type: ignore[attr-defined]
        logger.debug(
            "DigiCert <<< response received.",
            extra={
                "status_code": response.status_code,
                "request_id": rid,
                "url": request.url,
                "elapsed": str(response.elapsed),
            },
        )
        return response


def _resolve_ca_bundle(digicert_cfg: JsonDict) -> str | bool:
    """Determine the TLS CA bundle to use for outbound requests.

    Resolution order (first non-empty wins):
    1. ``digicert.ca_bundle`` config key (explicit path to a CA bundle file)
    2. ``CM_CA_BUNDLE`` environment variable
    3. ``REQUESTS_CA_BUNDLE`` — natively supported by *requests*
    4. ``SSL_CERT_FILE`` — used by OpenSSL-based stacks
    5. ``CURL_CA_BUNDLE`` — natively supported by *requests*
    6. ``digicert.tls_verify`` config key (bool or path)

    Returns ``True`` to use the default *certifi* CA bundle, ``False`` to
    disable verification entirely, or a filesystem path string pointing to a
    PEM CA bundle or directory.
    """
    # Explicit config path takes highest priority.
    ca_bundle: str = digicert_cfg.get("ca_bundle", "")
    if ca_bundle:
        logger.debug(
            "Using CA bundle from config (digicert.ca_bundle).", extra={"ca_bundle": ca_bundle}
        )
        return ca_bundle

    # certmesh-specific env var.
    for env_var in ("CM_CA_BUNDLE", "REQUESTS_CA_BUNDLE", "SSL_CERT_FILE", "CURL_CA_BUNDLE"):
        value = os.environ.get(env_var, "")
        if value:
            logger.debug(
                "Using CA bundle from environment variable.",
                extra={"env_var": env_var, "value": value},
            )
            return value

    # Fall back to the tls_verify toggle (True / False / path string).
    tls_verify = digicert_cfg.get("tls_verify", True)
    if isinstance(tls_verify, str):
        logger.debug(
            "Using CA bundle from digicert.tls_verify (path).", extra={"tls_verify": tls_verify}
        )
        return tls_verify
    return bool(tls_verify)


def _build_session(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
) -> requests.Session:
    """Build an authenticated ``requests.Session`` for the DigiCert API.

    The session is equipped with:
    * ``X-DC-DEVKEY`` header for DigiCert authentication.
    * ``_RequestIDAdapter`` for per-request UUID correlation, connection
      pooling, and request/response logging.
    * Configurable TLS verification and CA bundle resolution.
    * Transparent proxy support via standard environment variables
      (``HTTP_PROXY``, ``HTTPS_PROXY``, ``NO_PROXY``, ``ALL_PROXY``).
    """
    api_key: str = creds.resolve_digicert_api_key(vault_cfg, vault_cl)
    session = requests.Session()
    session.headers.update(
        {
            "X-DC-DEVKEY": api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
    )
    session.certmesh_timeout = int(digicert_cfg.get("timeout_seconds", 30))  # type: ignore[attr-defined]

    # ----- TLS verification / CA bundle -----
    session.verify = _resolve_ca_bundle(digicert_cfg)
    if session.verify is False:
        logger.warning(
            "TLS certificate verification DISABLED for DigiCert API — "
            "this is insecure and should only be used for testing.",
        )

    # ----- Forward proxy support -----
    # requests.Session automatically reads HTTP_PROXY, HTTPS_PROXY,
    # NO_PROXY, and ALL_PROXY from the environment.  We log the effective
    # proxy configuration for operational visibility.
    env_proxies = {
        k: os.environ[k]
        for k in (
            "HTTP_PROXY",
            "HTTPS_PROXY",
            "NO_PROXY",
            "ALL_PROXY",
            "http_proxy",
            "https_proxy",
            "no_proxy",
            "all_proxy",
        )
        if k in os.environ
    }
    if env_proxies:
        logger.info("Proxy environment detected.", extra={"proxies": env_proxies})

    # ----- Connection pooling + request ID injection -----
    pool_cfg: JsonDict = digicert_cfg.get("connection_pool", {})
    adapter = _RequestIDAdapter(
        pool_connections=int(pool_cfg.get("pool_connections", 10)),
        pool_maxsize=int(pool_cfg.get("pool_maxsize", 20)),
        max_retries=0,  # retries are handled by tenacity, not urllib3
    )
    session.mount("https://", adapter)
    session.mount("http://", adapter)

    return session


def _raise_for_digicert_error(resp: requests.Response) -> None:
    """Inspect a DigiCert HTTP response and raise the appropriate exception.

    Every error message includes the request ID, endpoint URL, and a
    remediation hint so that operators can quickly identify the root cause.

    * 401 / 403 → ``DigiCertAuthenticationError``
    * 404       → ``DigiCertOrderNotFoundError``
    * 429       → ``DigiCertRateLimitError`` (fixed 60s backoff; DigiCert
      does **not** return ``Retry-After`` headers)
    * 4xx / 5xx → ``DigiCertAPIError``
    """
    if resp.ok:
        return

    status = resp.status_code
    body = resp.text[:_MAX_ERROR_BODY]
    request_id = getattr(resp, "certmesh_request_id", "unknown")
    endpoint = getattr(resp, "certmesh_endpoint", "unknown")

    if status in (401, 403):
        raise DigiCertAuthenticationError(
            f"DigiCert authentication failed (HTTP {status}). "
            f"endpoint={endpoint}, request_id={request_id}. "
            "Remediation: verify your API key is valid and has the required "
            "permissions — DigiCert API keys do not expire but can be "
            "revoked in CertCentral > Automation > API Keys. "
            "Check CM_DIGICERT_API_KEY or the Vault path in "
            "vault.paths.digicert_api_key."
        )

    if status == 404:
        raise DigiCertOrderNotFoundError(
            f"DigiCert resource not found (HTTP 404). "
            f"endpoint={endpoint}, request_id={request_id}. "
            f"Response: {body}. "
            "Remediation: verify the certificate or order ID exists in "
            "CertCentral and that the API key has access to it."
        )

    if status == 429:
        # DigiCert does NOT return Retry-After headers.
        # Rate limits: 1000 req/3min (global), 100 req/5s (burst).
        # Use a fixed 60s backoff as a safe default.
        default_backoff = "60"
        logger.warning(
            "DigiCert rate limit hit (HTTP 429).",
            extra={
                "retry_after_seconds": default_backoff,
                "request_id": request_id,
                "endpoint": endpoint,
            },
        )
        raise DigiCertRateLimitError(
            f"DigiCert rate limit exceeded (HTTP 429). "
            f"endpoint={endpoint}, request_id={request_id}. "
            "DigiCert enforces 1000 req/3min and 100 req/5s limits "
            "but does not return rate-limit headers. "
            f"Using fixed {default_backoff}s backoff. "
            "Remediation: reduce request frequency and add jitter.",
            retry_after=default_backoff,
        )

    raise DigiCertAPIError(
        f"DigiCert API error (HTTP {status}). "
        f"endpoint={endpoint}, request_id={request_id}. "
        f"Response: {body}. "
        "Remediation: check the DigiCert status page "
        "(https://status.digicert.com) or contact DigiCert support "
        "with the request_id above.",
        status_code=status,
        body=body,
    )


def _request_timeout(session: requests.Session) -> int:
    """Return the timeout value stored on the session during construction."""
    return getattr(session, "certmesh_timeout", 30)


def _base_url(digicert_cfg: JsonDict) -> str:
    """Return the base URL, stripping any trailing slash."""
    return digicert_cfg.get("base_url", "https://www.digicert.com/services/v2").rstrip("/")


# =============================================================================
# Date parsing / client-side filtering helpers
# =============================================================================


def _parse_digicert_date(date_str: str) -> datetime:
    """Parse a DigiCert date string (``YYYY-MM-DD``) into a tz-aware datetime."""
    return datetime.strptime(date_str, _DIGICERT_DATE_FMT).replace(tzinfo=timezone.utc)


def _filter_by_expiry(
    certs: list[IssuedCertificateSummary],
    *,
    expires_before: datetime | None = None,
    expires_after: datetime | None = None,
) -> list[IssuedCertificateSummary]:
    """Client-side filter on ``valid_till``."""
    result: list[IssuedCertificateSummary] = []
    for cert in certs:
        try:
            expiry = _parse_digicert_date(cert.valid_till)
        except ValueError:
            # Unparseable dates pass through so callers still see the cert.
            result.append(cert)
            continue

        if expires_before and expiry >= expires_before:
            continue
        if expires_after and expiry <= expires_after:
            continue
        result.append(cert)
    return result


# =============================================================================
# ZIP / PEM extraction
# =============================================================================


def _extract_pem_from_zip(zip_bytes: bytes) -> tuple[bytes, bytes | None]:
    """Extract leaf certificate PEM and optional chain PEM from a ``pem_all`` ZIP.

    DigiCert's ``/certificate/{id}/download/format/pem_all`` endpoint returns
    a ZIP archive containing the server certificate and intermediate(s).

    Returns:
        ``(cert_pem, chain_pem)`` where *chain_pem* may be ``None`` if the
        archive contains no intermediates.
    """
    try:
        zf = zipfile.ZipFile(io.BytesIO(zip_bytes))
    except zipfile.BadZipFile as exc:
        raise DigiCertDownloadError(
            f"Downloaded content is not a valid ZIP archive: {exc}"
        ) from exc

    with zf:
        pem_files: list[str] = [n for n in zf.namelist() if n.lower().endswith(".pem")]
        if not pem_files:
            raise DigiCertDownloadError(
                "ZIP archive from DigiCert does not contain any .pem files."
            )

        cert_pem: bytes | None = None
        chain_parts: list[bytes] = []

        for name in sorted(pem_files):
            content = zf.read(name)
            lower = name.lower()
            # Heuristic: the server cert file usually does not contain "intermediate"
            # or "chain" or "ca" in its name.
            if any(kw in lower for kw in ("intermediate", "chain", "root", "ca-bundle")):
                chain_parts.append(content)
            elif cert_pem is None:
                cert_pem = content
            else:
                # Additional PEMs that aren't obviously chain go to chain.
                chain_parts.append(content)

    if cert_pem is None:
        raise DigiCertDownloadError(
            "Could not identify the server certificate PEM in the ZIP archive. "
            f"Files found: {pem_files}"
        )

    chain_pem = b"\n".join(chain_parts) if chain_parts else None
    return cert_pem, chain_pem


# =============================================================================
# Summary builder
# =============================================================================


def _cert_summary_from_dict(data: JsonDict) -> IssuedCertificateSummary:
    """Build an ``IssuedCertificateSummary`` from a raw DigiCert API dict."""
    return IssuedCertificateSummary(
        certificate_id=int(data.get("id", data.get("certificate_id", 0))),
        order_id=int(data.get("order_id", 0)),
        common_name=data.get("common_name", ""),
        serial_number=data.get("serial_number", ""),
        status=data.get("status", ""),
        valid_from=data.get("valid_from", ""),
        valid_till=data.get("valid_till", ""),
        product_name=data.get("product", {}).get("name", "")
        if isinstance(data.get("product"), dict)
        else str(data.get("product_name", "")),
    )


# =============================================================================
# Response validation
# =============================================================================


def _validate_response_json(
    data: JsonDict,
    required_keys: set[str],
    *,
    context: str = "",
    request_id: str = "",
) -> None:
    """Validate that expected keys are present in a JSON response.

    Raises ``DigiCertAPIError`` with actionable detail when required keys
    are missing, which typically indicates a malformed response or an API
    version mismatch.
    """
    missing = required_keys - data.keys()
    if missing:
        raise DigiCertAPIError(
            f"DigiCert API returned a malformed response: "
            f"missing expected key(s) {sorted(missing)}. "
            f"Received keys: {sorted(data.keys())}. "
            f"Context: {context}. request_id={request_id}. "
            "Remediation: this may indicate an API version mismatch or "
            "a transient server issue. Retry the request, or contact "
            "DigiCert support with the request_id above."
        )


# =============================================================================
# Retry / circuit-breaker factory
# =============================================================================


def _make_retry_decorator(digicert_cfg: JsonDict) -> Any:
    """Build a tenacity retry decorator from the ``digicert.retry`` config.

    The custom wait strategy honours the ``Retry-After`` header returned by
    DigiCert on HTTP 429 responses.  If the header is absent or unparseable,
    the decorator falls back to exponential backoff.
    """
    retry_cfg: JsonDict = digicert_cfg.get("retry", {})

    exp_wait = wait_exponential(
        multiplier=float(retry_cfg.get("wait_multiplier", 1.5)),
        min=float(retry_cfg.get("wait_min_seconds", 2)),
        max=float(retry_cfg.get("wait_max_seconds", 60)),
    )

    def _retry_after_or_exponential(retry_state: Any) -> float:
        """Honour Retry-After if present, otherwise exponential backoff."""
        exc = retry_state.outcome.exception()
        if isinstance(exc, DigiCertRateLimitError):
            seconds = exc.retry_after_seconds()
            if seconds is not None and seconds > 0:
                logger.info(
                    "Honouring Retry-After header: waiting before retry.",
                    extra={"retry_after_seconds": seconds},
                )
                return seconds
        return exp_wait(retry_state=retry_state)

    return retry(
        retry=retry_if_exception_type(
            (
                DigiCertRateLimitError,
                requests.exceptions.ConnectionError,
                requests.exceptions.Timeout,
            )
        ),
        stop=stop_after_attempt(int(retry_cfg.get("max_attempts", 5))),
        wait=_retry_after_or_exponential,
        reraise=True,
    )


def _make_circuit_breaker(digicert_cfg: JsonDict, name: str) -> Any:
    """Build a circuit breaker decorator from the ``digicert.circuit_breaker`` config."""
    cb_cfg: JsonDict = digicert_cfg.get("circuit_breaker", {})
    return create_circuit_breaker(
        failure_threshold=int(cb_cfg.get("failure_threshold", 5)),
        recovery_timeout_seconds=float(cb_cfg.get("recovery_timeout_seconds", 120)),
        name=name,
    )


# =============================================================================
# Shared pagination helper
# =============================================================================


def _paginate_orders(
    fetch_page: Callable[[int], JsonDict],
    *,
    page_size: int,
    max_pages: int,
    operation_label: str,
) -> list[IssuedCertificateSummary]:
    """Paginate through DigiCert ``/order/certificate`` responses.

    Shared by :func:`list_issued_certificates` and :func:`search_certificates`
    to avoid duplicating the pagination loop.
    """
    all_certs: list[IssuedCertificateSummary] = []
    offset = 0
    for _ in range(max_pages):
        try:
            payload = fetch_page(offset)
        except RetryError as exc:
            raise DigiCertAPIError(f"Failed to {operation_label} after retries: {exc}") from exc

        orders: list[JsonDict] = payload.get("orders", [])
        for order in orders:
            cert_data: JsonDict = order.get("certificate", {})
            if not cert_data:
                continue
            cert_data.setdefault("order_id", order.get("id", 0))
            cert_data.setdefault("product", order.get("product", {}))
            all_certs.append(_cert_summary_from_dict(cert_data))

        page_info: JsonDict = payload.get("page", {})
        total: int = int(page_info.get("total", 0))
        offset += page_size
        if offset >= total:
            break

    return all_certs


# =============================================================================
# Public API: list_issued_certificates
# =============================================================================


def list_issued_certificates(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
    *,
    page_size: int = 100,
    max_pages: int = 50,
    status: str | None = None,
    expires_before: datetime | None = None,
    expires_after: datetime | None = None,
) -> list[IssuedCertificateSummary]:
    """Retrieve all issued certificates from CertCentral, with optional filtering.

    Spec: ``GET /order/certificate`` with ``limit`` / ``offset`` pagination.
    Server-side filters: ``filters[status]``.
    Client-side filters: ``expires_before``, ``expires_after``.

    Args:
        digicert_cfg: The ``digicert`` section of the application config.
        vault_cfg: The ``vault`` section of the application config.
        vault_cl: An authenticated ``hvac.Client`` (or ``None`` if env-based).
        page_size: Number of certificates per page (max 1000).
        max_pages: Safety limit on the number of pages to fetch.
        status: Optional status filter (e.g. ``"issued"``).
        expires_before: Client-side: only certs expiring before this date.
        expires_after: Client-side: only certs expiring after this date.

    Returns:
        List of ``IssuedCertificateSummary`` objects.
    """
    session = _build_session(digicert_cfg, vault_cfg, vault_cl)
    base = _base_url(digicert_cfg)
    url = f"{base}/order/certificate"

    retry_dec = _make_retry_decorator(digicert_cfg)
    cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-list-certs")

    @cb_dec
    @retry_dec
    def _fetch_page(offset: int) -> JsonDict:
        params: dict[str, Any] = {
            "limit": page_size,
            "offset": offset,
        }
        if status:
            params["filters[status]"] = status
        resp = session.get(url, params=params, timeout=_request_timeout(session))
        _raise_for_digicert_error(resp)
        return resp.json()

    try:
        all_certs = _paginate_orders(
            _fetch_page,
            page_size=page_size,
            max_pages=max_pages,
            operation_label="list certificates",
        )

        logger.info("DigiCert: listed certificates.", extra={"count": len(all_certs)})

        if expires_before or expires_after:
            all_certs = _filter_by_expiry(
                all_certs,
                expires_before=expires_before,
                expires_after=expires_after,
            )
            logger.debug(
                "DigiCert: certificates after expiry filtering.",
                extra={"count": len(all_certs)},
            )

        return all_certs
    finally:
        session.close()


# =============================================================================
# Public API: search_certificates
# =============================================================================


def _build_search_params(
    common_name: str | None,
    serial_number: str | None,
    status: str | None,
    page_size: int,
    offset: int,
) -> dict[str, Any]:
    """Build the query-parameter dict for a ``GET /order/certificate`` page request.

    Only includes optional ``filters[…]`` keys when the corresponding
    argument is truthy, keeping the caller free of conditional logic.
    """
    params: dict[str, Any] = {
        "limit": page_size,
        "offset": offset,
    }
    if common_name:
        params["filters[common_name]"] = common_name
    if serial_number:
        params["filters[serial_number]"] = serial_number
    if status:
        params["filters[status]"] = status
    return params


def search_certificates(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
    *,
    common_name: str | None = None,
    serial_number: str | None = None,
    status: str | None = None,
    product_name_id: str | None = None,
    expires_before: datetime | None = None,
    expires_after: datetime | None = None,
    page_size: int = 100,
    max_pages: int = 50,
) -> list[IssuedCertificateSummary]:
    """Search certificates using server-side and client-side filters.

    Spec: ``GET /order/certificate`` with ``filters[common_name]``,
    ``filters[serial_number]``, ``filters[status]`` query parameters.

    Server-side filters forwarded to the API: ``common_name``,
    ``serial_number``, ``status``.

    Client-side filters applied after retrieval: ``product_name_id``,
    ``expires_before``, ``expires_after``.

    Args:
        digicert_cfg: The ``digicert`` section of the application config.
        vault_cfg: The ``vault`` section of the application config.
        vault_cl: An authenticated ``hvac.Client`` (or ``None`` if env-based).
        common_name: Filter by CN (server-side, substring match).
        serial_number: Filter by serial number (server-side, exact match).
        status: Filter by status (server-side, e.g. ``"issued"``).
        product_name_id: Filter by product type (client-side).
        expires_before: Client-side: only certs expiring before this date.
        expires_after: Client-side: only certs expiring after this date.
        page_size: Number of results per page.
        max_pages: Safety limit on the number of pages to fetch.

    Returns:
        List of matching ``IssuedCertificateSummary`` objects.
    """
    session = _build_session(digicert_cfg, vault_cfg, vault_cl)
    base = _base_url(digicert_cfg)
    url = f"{base}/order/certificate"

    retry_dec = _make_retry_decorator(digicert_cfg)
    cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-search-certs")

    @cb_dec
    @retry_dec
    def _fetch_page(offset: int) -> JsonDict:
        params = _build_search_params(common_name, serial_number, status, page_size, offset)
        resp = session.get(url, params=params, timeout=_request_timeout(session))
        _raise_for_digicert_error(resp)
        return resp.json()

    try:
        all_certs = _paginate_orders(
            _fetch_page,
            page_size=page_size,
            max_pages=max_pages,
            operation_label="search certificates",
        )

        # Client-side: product_name_id filter.
        if product_name_id:
            all_certs = [c for c in all_certs if product_name_id.lower() in c.product_name.lower()]

        # Client-side: expiry filter.
        if expires_before or expires_after:
            all_certs = _filter_by_expiry(
                all_certs,
                expires_before=expires_before,
                expires_after=expires_after,
            )

        logger.info(
            "DigiCert: search returned certificates.",
            extra={"count": len(all_certs), "common_name": common_name, "status": status},
        )
        return all_certs
    finally:
        session.close()


# =============================================================================
# Public API: describe_certificate
# =============================================================================


def describe_certificate(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
    certificate_id: int,
) -> DigiCertCertificateDetail:
    """Retrieve full detail for a single certificate.

    Calls ``GET /certificate/{certificate_id}``.

    Args:
        digicert_cfg: The ``digicert`` section of the application config.
        vault_cfg: The ``vault`` section of the application config.
        vault_cl: An authenticated ``hvac.Client`` (or ``None``).
        certificate_id: The DigiCert certificate ID.

    Returns:
        A ``DigiCertCertificateDetail`` with all available metadata.
    """
    session = _build_session(digicert_cfg, vault_cfg, vault_cl)
    base = _base_url(digicert_cfg)
    url = f"{base}/certificate/{certificate_id}"

    retry_dec = _make_retry_decorator(digicert_cfg)
    cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-describe-cert")

    @cb_dec
    @retry_dec
    def _fetch() -> JsonDict:
        resp = session.get(url, timeout=_request_timeout(session))
        _raise_for_digicert_error(resp)
        return resp.json()

    try:
        try:
            data = _fetch()
        except RetryError as exc:
            raise DigiCertAPIError(
                f"Failed to describe certificate {certificate_id} after retries: {exc}"
            ) from exc

        sans_list: list[str] = []
        for san_entry in data.get("dns_names", []):
            if isinstance(san_entry, str):
                sans_list.append(san_entry)
            elif isinstance(san_entry, dict):
                sans_list.append(san_entry.get("name", ""))

        detail = DigiCertCertificateDetail(
            certificate_id=int(data.get("id", certificate_id)),
            order_id=int(data.get("order_id", 0)),
            common_name=data.get("common_name", ""),
            serial_number=data.get("serial_number", ""),
            status=data.get("status", ""),
            valid_from=data.get("valid_from", ""),
            valid_till=data.get("valid_till", ""),
            product_name=data.get("product", {}).get("name", "")
            if isinstance(data.get("product"), dict)
            else "",
            sans=sans_list,
            organization=data.get("organization", {}).get("name", "")
            if isinstance(data.get("organization"), dict)
            else "",
            signature_hash=data.get("signature_hash", ""),
            key_size=int(data.get("key_size", 0)),
            thumbprint=data.get("thumbprint", ""),
            raw=data,
        )

        logger.info(
            "DigiCert: described certificate.",
            extra={
                "certificate_id": certificate_id,
                "common_name": detail.common_name,
                "status": detail.status,
            },
        )
        return detail
    finally:
        session.close()


# =============================================================================
# Public API: download_issued_certificate
# =============================================================================


def download_issued_certificate(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
    certificate_id: int,
    private_key_pem: str,
) -> CertificateBundle:
    """Download an issued certificate from DigiCert in ``pem_all`` ZIP format.

    Spec: ``GET /certificate/{certificate_id}/download/platform``
    Format types: ``pem_all``, ``pem_noroot``, ``apache``, ``nginx``, etc.

    Args:
        digicert_cfg: The ``digicert`` section of the application config.
        vault_cfg: The ``vault`` section of the application config.
        vault_cl: An authenticated ``hvac.Client`` (or ``None``).
        certificate_id: The DigiCert certificate ID to download.
        private_key_pem: The PEM-encoded private key (generated locally).

    Returns:
        A ``CertificateBundle`` ready for persistence.
    """
    session = _build_session(digicert_cfg, vault_cfg, vault_cl)
    base = _base_url(digicert_cfg)
    url = f"{base}/certificate/{certificate_id}/download/format/pem_all"

    retry_dec = _make_retry_decorator(digicert_cfg)
    cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-download-cert")

    @cb_dec
    @retry_dec
    def _download() -> bytes:
        resp = session.get(
            url, headers={"Accept": "application/zip"}, timeout=_request_timeout(session)
        )
        _raise_for_digicert_error(resp)
        if not resp.content:
            raise DigiCertDownloadError(
                f"DigiCert returned empty body for certificate {certificate_id} download."
            )
        return resp.content

    try:
        try:
            zip_bytes = _download()
        except RetryError as exc:
            raise DigiCertDownloadError(
                f"Failed to download certificate {certificate_id} after retries: {exc}"
            ) from exc

        cert_pem, chain_pem = _extract_pem_from_zip(zip_bytes)

        bundle = cu.assemble_bundle(
            cert_pem=cert_pem,
            private_key_pem=private_key_pem.encode("utf-8"),
            chain_pem=chain_pem,
            source_id=str(certificate_id),
        )

        logger.info(
            "DigiCert: downloaded certificate.",
            extra={
                "certificate_id": certificate_id,
                "common_name": bundle.common_name,
                "serial": bundle.serial_number,
            },
        )
        return bundle
    finally:
        session.close()


# =============================================================================
# Private helper: _poll_order_until_issued
# =============================================================================


def _poll_order_until_issued(
    session: requests.Session,
    status_url: str,
    order_id: int,
    cb_dec: Any,
    retry_dec: Any,
    poll_interval: int,
    max_wait: int,
) -> int:
    """Poll the order status URL until it reaches ``"issued"``, then return the certificate ID.

    Args:
        session: Authenticated ``requests.Session``.
        status_url: ``GET /order/certificate/{order_id}`` URL.
        order_id: The DigiCert order ID (used only in log/error messages).
        cb_dec: Circuit-breaker decorator.
        retry_dec: Tenacity retry decorator.
        poll_interval: Seconds to sleep between polls.
        max_wait: Maximum total seconds to wait.

    Returns:
        The integer certificate ID once the order status is ``"issued"``.

    Raises:
        DigiCertPollingTimeoutError: If ``max_wait`` elapses without issuance.
        DigiCertAPIError: If the order transitions to a terminal failure state or
            the status check fails after retries.
    """

    @cb_dec
    @retry_dec
    def _check_order_status() -> JsonDict:
        resp = session.get(status_url, timeout=_request_timeout(session))
        _raise_for_digicert_error(resp)
        return resp.json()

    start = time.monotonic()
    while (elapsed := time.monotonic() - start) < max_wait:
        try:
            status_resp = _check_order_status()
        except RetryError as exc:
            raise DigiCertAPIError(
                f"Failed to check order {order_id} status after retries: {exc}"
            ) from exc

        order_status: str = status_resp.get("status", "")
        cert_data: JsonDict = status_resp.get("certificate", {})

        if order_status == "issued" and cert_data.get("id"):
            certificate_id = int(cert_data["id"])
            logger.info(
                "DigiCert: order is issued.",
                extra={"order_id": order_id, "certificate_id": certificate_id},
            )
            return certificate_id

        if order_status in ("rejected", "revoked", "canceled"):
            raise DigiCertAPIError(
                f"DigiCert order {order_id} was {order_status}.",
                body=str(status_resp)[:200],
            )

        logger.debug(
            "DigiCert: order polling.",
            extra={
                "order_id": order_id,
                "status": order_status,
                "interval_seconds": poll_interval,
                "elapsed_seconds": elapsed,
                "max_wait_seconds": max_wait,
            },
        )
        time.sleep(poll_interval)

    raise DigiCertPollingTimeoutError(
        f"Timed out after {max_wait}s waiting for DigiCert order {order_id} to be issued."
    )


# =============================================================================
# Public API: order_and_await_certificate
# =============================================================================


def order_and_await_certificate(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
    order_request: OrderRequest,
) -> CertificateBundle:
    """Submit a certificate order, poll until issued, then download the bundle.

    Spec: ``POST /order/certificate/{product_name_id}``

    The order body uses the ``order_validity`` object (``years`` or ``days``)
    instead of the legacy ``validity_years`` field, sets ``skip_approval: true``
    for automation, and includes ``payment_method``.

    Steps:
        1. Generate an RSA private key and CSR.
        2. Submit the order to ``POST /order/certificate/{product_name_id}``.
        3. Poll ``GET /order/certificate/{order_id}`` until the order status
           is ``"issued"`` or the configured timeout elapses.
        4. Download the certificate via ``download_issued_certificate``.

    Args:
        digicert_cfg: The ``digicert`` section of the application config.
        vault_cfg: The ``vault`` section of the application config.
        vault_cl: An authenticated ``hvac.Client`` (or ``None``).
        order_request: An ``OrderRequest`` describing the desired certificate.

    Returns:
        A ``CertificateBundle`` containing the certificate, key, and chain.

    Raises:
        DigiCertPollingTimeoutError: If issuance does not complete in time.
        DigiCertAPIError: On unexpected API failures.
    """
    # ---- 1. Key + CSR generation ----
    subject = SubjectInfo(
        common_name=order_request.common_name,
        san_dns_names=order_request.san_dns_names,
        organisation=order_request.organisation,
        organisational_unit=order_request.organisational_unit,
        country=order_request.country,
        state=order_request.state,
        locality=order_request.locality,
    )

    private_key = cu.generate_rsa_private_key(key_size=order_request.key_size)
    private_key_pem = cu.private_key_to_pem(private_key).decode("utf-8")
    csr = cu.build_csr(private_key, subject)
    csr_pem = cu.csr_to_pem(csr)

    # ---- 2. Submit order ----
    session = _build_session(digicert_cfg, vault_cfg, vault_cl)
    base = _base_url(digicert_cfg)
    url = f"{base}/order/certificate/{order_request.product_name_id}"

    # Build the order body per CertCentral API v2 spec.
    # Ref: POST /order/certificate/{product_name_id}
    #
    # ``order_validity`` replaces the legacy ``validity_years`` field.
    # ``skip_approval`` is required for automated workflows.
    # ``payment_method`` specifies how the order is charged.
    if order_request.validity_days is not None:
        order_validity: JsonDict = {"days": order_request.validity_days}
    else:
        order_validity = {"years": order_request.validity_years}

    order_body: JsonDict = {
        "certificate": {
            "common_name": order_request.common_name,
            "csr": csr_pem,
            "signature_hash": order_request.signature_hash,
        },
        "order_validity": order_validity,
        "payment_method": order_request.payment_method,
        "skip_approval": order_request.skip_approval,
    }

    if order_request.san_dns_names:
        order_body["certificate"]["dns_names"] = order_request.san_dns_names

    if order_request.organization_id:
        order_body["organization"] = {"id": order_request.organization_id}

    if order_request.dcv_method:
        order_body["dcv_method"] = order_request.dcv_method

    if order_request.comments:
        order_body["comments"] = order_request.comments

    retry_dec = _make_retry_decorator(digicert_cfg)
    cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-order-cert")

    @cb_dec
    @retry_dec
    def _submit_order() -> JsonDict:
        resp = session.post(url, json=order_body, timeout=_request_timeout(session))
        _raise_for_digicert_error(resp)
        return resp.json()

    try:
        try:
            order_resp = _submit_order()
        except RetryError as exc:
            raise DigiCertAPIError(
                f"Failed to submit certificate order after retries: {exc}"
            ) from exc

        order_id: int = int(order_resp.get("id", 0))
        if not order_id:
            raise DigiCertAPIError(
                "DigiCert order response did not contain an order ID.",
                body=str(order_resp)[:200],
            )

        logger.info(
            "DigiCert: submitted order.",
            extra={
                "order_id": order_id,
                "common_name": order_request.common_name,
                "product": order_request.product_name_id,
            },
        )

        # ---- 3. Poll for issuance ----
        polling_cfg: JsonDict = digicert_cfg.get("polling", {})
        poll_interval: int = int(polling_cfg.get("interval_seconds", 15))
        max_wait: int = int(polling_cfg.get("max_wait_seconds", 1800))
        status_url = f"{base}/order/certificate/{order_id}"

        certificate_id = _poll_order_until_issued(
            session=session,
            status_url=status_url,
            order_id=order_id,
            cb_dec=cb_dec,
            retry_dec=retry_dec,
            poll_interval=poll_interval,
            max_wait=max_wait,
        )
    finally:
        session.close()

    # ---- 4. Download ----
    bundle = download_issued_certificate(
        digicert_cfg,
        vault_cfg,
        vault_cl,
        certificate_id,
        private_key_pem,
    )

    return bundle


# =============================================================================
# Public API: revoke_certificate
# =============================================================================


def revoke_certificate(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
    *,
    certificate_id: int | None = None,
    order_id: int | None = None,
    reason: str = "unspecified",
    comments: str = "",
) -> JsonDict:
    """Revoke a DigiCert certificate.

    Spec: ``PUT /certificate/{certificate_id}/revoke``

    The request body uses ``revocation_reason`` (not ``reason``) per the
    CertCentral API v2 spec, and sets ``skip_approval: true`` for automation.

    Either ``certificate_id`` or ``order_id`` must be supplied.  When only
    ``order_id`` is given the function fetches the order detail to resolve
    the ``certificate_id``.

    Args:
        digicert_cfg: The ``digicert`` section of the application config.
        vault_cfg: The ``vault`` section of the application config.
        vault_cl: An authenticated ``hvac.Client`` (or ``None``).
        certificate_id: The DigiCert certificate ID.
        order_id: The DigiCert order ID (used to look up the certificate).
        reason: Revocation reason. One of: ``"unspecified"``,
            ``"key_compromise"``, ``"affiliation_change"``,
            ``"superseded"``, ``"cessation_of_operation"``.
        comments: Optional free-text comment attached to the request.

    Returns:
        The JSON response body from DigiCert (typically empty on success,
        or status confirmation).

    Raises:
        DigiCertError: If neither ``certificate_id`` nor ``order_id`` is given.
        DigiCertAPIError: On unexpected API failures.
    """
    if certificate_id is None and order_id is None:
        raise DigiCertError(
            "Either certificate_id or order_id must be provided to revoke a certificate."
        )

    if reason not in _VALID_REVOCATION_REASONS:
        raise DigiCertError(
            f"Invalid revocation reason '{reason}'. "
            f"Valid reasons: {sorted(_VALID_REVOCATION_REASONS)}"
        )

    session = _build_session(digicert_cfg, vault_cfg, vault_cl)
    base = _base_url(digicert_cfg)

    try:
        # Resolve certificate_id from order if needed.
        if certificate_id is None:
            certificate_id = _resolve_certificate_id_from_order(
                session,
                base,
                order_id,
                digicert_cfg,  # type: ignore[arg-type]
            )

        url = f"{base}/certificate/{certificate_id}/revoke"

        # Build revocation body per CertCentral API v2 spec.
        # Ref: PUT /certificate/{id}/revoke
        # Field name is ``revocation_reason`` (not ``reason``).
        # ``skip_approval`` bypasses admin approval for automated workflows.
        revoke_body: JsonDict = {
            "revocation_reason": reason,
            "skip_approval": True,
        }
        if comments:
            revoke_body["comments"] = comments

        retry_dec = _make_retry_decorator(digicert_cfg)
        cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-revoke-cert")

        @cb_dec
        @retry_dec
        def _revoke() -> JsonDict:
            resp = session.put(url, json=revoke_body, timeout=_request_timeout(session))
            _raise_for_digicert_error(resp)
            # DigiCert returns 204 No Content on successful revocation.
            if resp.status_code == 204 or not resp.content:
                return {"status": "revoked", "certificate_id": certificate_id}
            return resp.json()

        try:
            result = _revoke()
        except RetryError as exc:
            raise DigiCertAPIError(
                f"Failed to revoke certificate {certificate_id} after retries: {exc}"
            ) from exc

        logger.info(
            "DigiCert: revoked certificate.",
            extra={"certificate_id": certificate_id, "reason": reason},
        )
        return result
    finally:
        session.close()


def _resolve_certificate_id_from_order(
    session: requests.Session,
    base_url: str,
    order_id: int,
    digicert_cfg: JsonDict,
) -> int:
    """Look up the certificate_id for a given order_id."""
    url = f"{base_url}/order/certificate/{order_id}"

    retry_dec = _make_retry_decorator(digicert_cfg)
    cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-resolve-order")

    @cb_dec
    @retry_dec
    def _fetch() -> JsonDict:
        resp = session.get(url, timeout=_request_timeout(session))
        _raise_for_digicert_error(resp)
        return resp.json()

    try:
        data = _fetch()
    except RetryError as exc:
        raise DigiCertAPIError(
            f"Failed to resolve certificate for order {order_id} after retries: {exc}"
        ) from exc

    cert_data: JsonDict = data.get("certificate", {})
    cert_id = cert_data.get("id")
    if not cert_id:
        raise DigiCertCertificateNotReadyError(
            f"Order {order_id} does not have an issued certificate yet. "
            f"Order status: {data.get('status', 'unknown')}."
        )

    return int(cert_id)


# =============================================================================
# Public API: duplicate_certificate
# =============================================================================


def duplicate_certificate(
    digicert_cfg: JsonDict,
    vault_cfg: JsonDict,
    vault_cl: hvac.Client | None,
    order_id: int,
    csr_pem: str,
    *,
    common_name: str | None = None,
    san_dns_names: list[str] | None = None,
    signature_hash: str = "sha256",
    comments: str = "",
) -> JsonDict:
    """Request a duplicate certificate for an existing order.

    Spec: ``POST /order/certificate/{order_id}/duplicate``

    A duplicate reuses the validation from the original order but issues
    a new certificate with a potentially different CSR, CN, or SANs.

    Args:
        digicert_cfg: The ``digicert`` section of the application config.
        vault_cfg: The ``vault`` section of the application config.
        vault_cl: An authenticated ``hvac.Client`` (or ``None``).
        order_id: The DigiCert order ID to duplicate.
        csr_pem: PEM-encoded CSR for the duplicate certificate.
        common_name: Optional new CN (defaults to the original order's CN).
        san_dns_names: Optional new SAN list.
        signature_hash: Signature hash algorithm (default ``"sha256"``).
        comments: Optional free-text comment.

    Returns:
        The DigiCert API response dict containing the duplicate order info,
        typically including ``id`` (new order/request ID) and ``certificate_id``.

    Raises:
        DigiCertAPIError: On unexpected API failures.
        DigiCertOrderNotFoundError: If the original order cannot be found.
    """
    session = _build_session(digicert_cfg, vault_cfg, vault_cl)
    base = _base_url(digicert_cfg)
    url = f"{base}/order/certificate/{order_id}/duplicate"

    dup_body: JsonDict = {
        "certificate": {
            "csr": csr_pem,
            "signature_hash": signature_hash,
        },
    }

    if common_name:
        dup_body["certificate"]["common_name"] = common_name
    if san_dns_names:
        dup_body["certificate"]["dns_names"] = san_dns_names
    if comments:
        dup_body["comments"] = comments

    retry_dec = _make_retry_decorator(digicert_cfg)
    cb_dec = _make_circuit_breaker(digicert_cfg, "digicert-duplicate-cert")

    @cb_dec
    @retry_dec
    def _submit_duplicate() -> JsonDict:
        resp = session.post(url, json=dup_body, timeout=_request_timeout(session))
        _raise_for_digicert_error(resp)
        return resp.json()

    try:
        try:
            result = _submit_duplicate()
        except RetryError as exc:
            raise DigiCertAPIError(
                f"Failed to submit duplicate for order {order_id} after retries: {exc}"
            ) from exc

        logger.info(
            "DigiCert: submitted duplicate request for order.",
            extra={"order_id": order_id, "common_name": common_name or "(original)"},
        )
        return result
    finally:
        session.close()
