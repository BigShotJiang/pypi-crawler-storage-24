"""LangChain toolkit that bundles all Mesh Cognition tools."""

from langchain_core.tools import BaseTool

from .tools import MeshContext, MeshMemorySearch, MeshMemoryWrite, MeshStatus
from .wrapper import MeshCognitionAPIWrapper


class MeshCognitionToolkit:
    """Toolkit that gives any LangChain agent mesh memory capabilities.

    Usage:
        from langchain_mesh_cognition import MeshCognitionToolkit

        toolkit = MeshCognitionToolkit()
        tools = toolkit.get_tools()

        # Add to any LangChain agent
        agent = create_react_agent(llm, tools)
    """

    def __init__(self, base_url: str = "http://127.0.0.1:18790"):
        self.api = MeshCognitionAPIWrapper(base_url=base_url)

    def get_tools(self) -> list[BaseTool]:
        """Return all mesh cognition tools configured with the same API wrapper."""
        return [
            MeshMemoryWrite(api=self.api),
            MeshMemorySearch(api=self.api),
            MeshStatus(api=self.api),
            MeshContext(api=self.api),
        ]
