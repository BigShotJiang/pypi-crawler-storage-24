"""LangChain integration for Mesh Cognition — distributed memory across agents.

Give any LangChain agent the ability to share memory across devices.
What one agent learns, all agents can recall.

Quick start:
    from langchain_mesh_cognition import MeshCognitionToolkit

    toolkit = MeshCognitionToolkit()
    tools = toolkit.get_tools()

    # Add to any LangChain agent
    agent = create_react_agent(llm, tools)

Requires mesh-cognition-service running:
    npm install -g mesh-cognition-service
    mesh-cognition start --daemon
"""

from .toolkit import MeshCognitionToolkit
from .tools import MeshContext, MeshMemorySearch, MeshMemoryWrite, MeshStatus
from .wrapper import MeshCognitionAPIWrapper

__all__ = [
    "MeshCognitionToolkit",
    "MeshCognitionAPIWrapper",
    "MeshMemoryWrite",
    "MeshMemorySearch",
    "MeshStatus",
    "MeshContext",
]
