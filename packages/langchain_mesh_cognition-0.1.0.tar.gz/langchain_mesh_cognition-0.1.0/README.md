# langchain-mesh-cognition

Give any LangChain agent distributed memory across devices. What one agent learns, all agents can recall.

[![PyPI](https://img.shields.io/pypi/v/langchain-mesh-cognition)](https://pypi.org/project/langchain-mesh-cognition/)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue)](https://github.com/sym-bot/mesh-cognition-sdk/blob/main/LICENSE)

## Install

```bash
pip install langchain-mesh-cognition
```

**Prerequisite:** the mesh service must be running on each device:

```bash
npm install -g mesh-cognition-service
mesh-cognition start --daemon
```

## Quick Start

### Use tools directly (no LLM needed)

The tools work standalone — no API keys, no LLM costs:

```python
from langchain_mesh_cognition import MeshMemoryWrite, MeshMemorySearch

# Write a memory — broadcasts to all mesh peers
MeshMemoryWrite().invoke({"content": "Team standup moved to 10am Monday", "tags": "meeting,standup"})

# Search from any device on the mesh
print(MeshMemorySearch().invoke({"query": "standup"}))
# → [Hongweis-MacBook-Air.local] Team standup moved to 10am Monday (tags: meeting, standup)
```

### Use with a LangChain agent (optional)

Add mesh memory to a conversational agent that decides when to read/write:

```python
from langchain_mesh_cognition import MeshCognitionToolkit
from langchain_openai import ChatOpenAI
from langgraph.prebuilt import create_react_agent

agent = create_react_agent(ChatOpenAI(model="gpt-4o"), MeshCognitionToolkit().get_tools())
agent.invoke({"messages": [("user", "What meetings do I have?")]})
# → Agent calls mesh_memory_search, finds meetings stored by any device on the mesh
```

## Tools

| Tool | Description |
|------|-------------|
| `mesh_memory_write` | Store a memory and broadcast to all mesh peers |
| `mesh_memory_search` | Search memories across all devices on the mesh |
| `mesh_status` | Check mesh health — peer count, Kuramoto r(t), uptime |
| `mesh_context` | Get context from aligned peers for enriched reasoning |

## Use Individual Tools

```python
from langchain_mesh_cognition import MeshMemoryWrite, MeshMemorySearch

# Add specific tools to any agent
tools = [MeshMemoryWrite(), MeshMemorySearch()]
```

## Custom Service URL

```python
toolkit = MeshCognitionToolkit(base_url="http://192.168.1.100:18790")
```

## Multi-Agent with LangGraph

```python
from langchain_mesh_cognition import MeshCognitionToolkit
from langgraph.prebuilt import create_react_agent

# Two agents sharing the same mesh
research_agent = create_react_agent(llm, MeshCognitionToolkit().get_tools())
writing_agent = create_react_agent(llm, MeshCognitionToolkit().get_tools())

# Research agent stores findings → writing agent recalls them
research_agent.invoke({"messages": [("user", "Research quantum computing trends")]})
writing_agent.invoke({"messages": [("user", "Write a summary using mesh memory")]})
```

For cross-device mesh, start `mesh-cognition` on each machine. Agents on different devices share memory automatically via Bonjour/mDNS discovery.

## How It Works

```
LangChain Agent
    ↓ uses tools
MeshCognitionToolkit
    ↓ HTTP calls
mesh-cognition-service (localhost:18790)
    ↓ TCP + Bonjour
Other mesh nodes on the network
```

The agent doesn't need to know about networking, discovery, or coupling. It just reads and writes memories — the mesh handles distribution.

## Links

- [Mesh Cognition SDK](https://github.com/sym-bot/mesh-cognition-sdk)
- [mesh-cognition-service](https://www.npmjs.com/package/mesh-cognition-service) (npm)
- [Whitepaper](https://sym.bot/research/mesh-cognition)

---

**[SYM.BOT Ltd](https://sym.bot)** · Apache 2.0
