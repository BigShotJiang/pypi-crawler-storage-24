"""
Detection Evaluation Pipeline Adapter.

Full evaluation for detection: inference + mAP computation +
training loss curves + bbox visualization + structured report.
"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from types import MappingProxyType
from typing import TYPE_CHECKING, Any

import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from torchmetrics.detection import MeanAveragePrecision

from ...core import LOGGER_NAME
from ...core.paths import METRIC_LOSS, METRIC_MAP, METRIC_MAP_50, METRIC_MAP_75
from ...core.paths.constants import LogStyle
from ...evaluation.detection_visualization import show_detections
from ...evaluation.plot_context import PlotContext
from ...evaluation.reporting import create_structured_report
from ...evaluation.visualization import plot_training_curves
from .helpers import to_cpu

if TYPE_CHECKING:  # pragma: no cover
    from ...core.config import (
        AugmentationConfig,
        DatasetConfig,
        EvaluationConfig,
        TrainingConfig,
    )
    from ...core.paths import RunPaths
    from ...tracking import TrackerProtocol

logger = logging.getLogger(LOGGER_NAME)


class DetectionEvalPipelineAdapter:
    """Orchestrates detection inference, mAP computation, and reporting."""

    def run_evaluation(
        self,
        model: nn.Module,
        test_loader: DataLoader[Any],
        train_losses: list[float],
        val_metrics_history: list[Mapping[str, float]],
        class_names: list[str],
        paths: RunPaths,
        training: TrainingConfig,
        dataset: DatasetConfig,
        augmentation: AugmentationConfig,  # noqa: ARG002
        evaluation: EvaluationConfig,
        arch_name: str,
        aug_info: str = "N/A",  # pragma: no mutate  # noqa: ARG002
        tracker: TrackerProtocol | None = None,
    ) -> Mapping[str, float]:
        """
        Run detection evaluation pipeline.

        Computes mAP metrics on the test set, plots training loss curves,
        and optionally logs metrics to the experiment tracker.

        Args:
            model: Trained detection model (already on target device).
            test_loader: DataLoader for test set.
            train_losses: Training loss history per epoch.
            val_metrics_history: Validation metrics history per epoch.
            class_names: List of class label strings.
            paths: RunPaths for artifact output.
            training: Training sub-config.
            dataset: Dataset sub-config.
            augmentation: Augmentation sub-config.
            evaluation: Evaluation sub-config.
            arch_name: Architecture identifier.
            aug_info: Augmentation description string.
            tracker: Optional experiment tracker for final metrics.

        Returns:
            Mapping of detection metric names to float values.
        """
        device = next(model.parameters()).device  # pragma: no mutate

        # Inference + mAP computation
        model.eval()
        metric = MeanAveragePrecision(iou_type="bbox")

        with torch.no_grad():
            for images, targets in test_loader:
                images_on_device = [img.to(device) for img in images]  # pragma: no mutate
                predictions = model(images_on_device)
                metric.update(
                    [to_cpu(p) for p in predictions],
                    [to_cpu(t) for t in targets],
                )

        result = metric.compute()
        test_metrics = {
            METRIC_MAP: float(result["map"]),
            METRIC_MAP_50: float(result["map_50"]),
            METRIC_MAP_75: float(result["map_75"]),
        }

        # Log results
        logger.info(
            "%s%s %-18s: mAP=%.4f  mAP@50=%.4f  mAP@75=%.4f",
            LogStyle.INDENT,
            LogStyle.ARROW,
            "Test Metrics",
            test_metrics[METRIC_MAP],
            test_metrics[METRIC_MAP_50],
            test_metrics[METRIC_MAP_75],
        )

        # Bbox visualization grid
        if evaluation.save_predictions_grid:
            show_detections(
                model=model,
                loader=test_loader,
                device=device,
                classes=class_names,
                save_path=paths.figures
                / f"detection_samples_{arch_name}_{dataset.resolution}.png",  # pragma: no mutate
                ctx=PlotContext(  # pragma: no mutate
                    arch_name=arch_name,
                    resolution=dataset.resolution,
                    fig_dpi=evaluation.fig_dpi,
                    plot_style=evaluation.plot_style,
                    cmap_confusion=evaluation.cmap_confusion,
                    grid_cols=evaluation.grid_cols,
                    n_samples=evaluation.n_samples,
                    fig_size_predictions=evaluation.fig_size_predictions,
                    mean=dataset.mean,
                    std=dataset.std,
                ),
            )

        # Training curves — plot mAP instead of loss (METRIC_LOSS is a 0.0 sentinel)
        val_map = [m.get(METRIC_MAP, 0.0) for m in val_metrics_history]
        ctx = PlotContext(  # pragma: no mutate
            arch_name=arch_name,
            resolution=dataset.resolution,
            fig_dpi=evaluation.fig_dpi,
            plot_style=evaluation.plot_style,
            cmap_confusion=evaluation.cmap_confusion,
            grid_cols=evaluation.grid_cols,
            n_samples=evaluation.n_samples,
            fig_size_predictions=evaluation.fig_size_predictions,
        )
        plot_training_curves(
            train_losses=train_losses,
            val_metric_values=val_map,
            out_path=paths.figures / "training_curves.png",  # pragma: no mutate
            ctx=ctx,
            val_label="Validation mAP",  # pragma: no mutate
        )

        # Structured report (Excel/CSV/JSON) — args tested in test_reporting.py
        report = create_structured_report(  # pragma: no mutate
            val_metrics=val_metrics_history,
            test_metrics=test_metrics,
            train_losses=train_losses,
            best_path=paths.best_model_path,
            log_path=paths.logs / "session.log",  # pragma: no mutate
            arch_name=arch_name,
            dataset=dataset,
            training=training,
            task_type="detection",  # pragma: no mutate
        )
        report.save(paths.final_report_path, fmt=evaluation.report_format)  # pragma: no mutate

        # Tracker logging
        if tracker is not None:
            full_metrics = {METRIC_LOSS: 0.0, **test_metrics}  # sentinel for tracker schema
            tracker.log_test_metrics(full_metrics)

        return MappingProxyType(test_metrics)
