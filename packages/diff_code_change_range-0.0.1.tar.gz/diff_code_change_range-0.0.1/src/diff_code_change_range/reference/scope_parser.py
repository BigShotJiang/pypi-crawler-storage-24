"""Parser for flattening affected scope tree into qualified node list."""

from typing import List, Optional, Tuple
from .models import AffectedNode, AffectedScope, NodeType, QualifiedNode


class ScopeParser:
    """Parses affected scope and generates qualified paths for nodes."""

    def __init__(self, scope: AffectedScope):
        self.scope = scope

    def get_all_qualified_nodes(self) -> Tuple[List[QualifiedNode], List[QualifiedNode]]:
        """Get all qualified nodes for before and after scopes."""
        before_nodes = self._flatten_nodes(self.scope.before)
        after_nodes = self._flatten_nodes(self.scope.after)
        return before_nodes, after_nodes

    def _flatten_nodes(
        self,
        nodes: List[AffectedNode],
        parent_path: str = "",
        file_path: str = ""
    ) -> List[QualifiedNode]:
        """Recursively flatten node tree into qualified nodes."""
        result = []
        
        for node in nodes:
            current_path, current_file = self._build_path(node, parent_path, file_path)
            
            # Create qualified node if it has a line range
            if node.line_range:
                qualified = QualifiedNode(
                    qualified_path=current_path,
                    name=node.name,
                    node_type=node.type,
                    line_range=node.line_range,
                    file_path=current_file,
                    container_path=parent_path if parent_path else None
                )
                result.append(qualified)
            
            # Process children
            if node.children:
                result.extend(self._flatten_nodes(node.children, current_path, current_file))
        
        return result

    def _build_path(
        self,
        node: AffectedNode,
        parent_path: str,
        file_path: str
    ) -> Tuple[str, str]:
        """Build qualified path for a node."""
        if node.type == NodeType.FILE:
            # File node: path is just the file path
            return node.name, node.name
        
        if not parent_path:
            # Top-level node (function, class, etc.)
            return f"{file_path}#{node.name}", file_path
        
        # Check if parent_path already contains # or $
        if '#' in parent_path:
            # Nested node: append to parent path with $ separator
            return f"{parent_path}${node.name}", file_path
        else:
            # parent_path is just a file path
            return f"{parent_path}#{node.name}", file_path

    def get_nodes_by_file(self, nodes: List[QualifiedNode]) -> dict:
        """Group qualified nodes by file path."""
        result = {}
        for node in nodes:
            if node.file_path not in result:
                result[node.file_path] = []
            result[node.file_path].append(node)
        return result
