"""Reference differ for computing added and removed references."""

from typing import List, Set
from .models import Reference, ReferenceResult


class ReferenceDiffer:
    """Computes differences between before and after reference sets."""

    @staticmethod
    def compute_diff(
        before_refs: List[Reference],
        after_refs: List[Reference]
    ) -> ReferenceResult:
        """
        Compute added and removed references.
        
        Two references are considered equal if they have the same source,
        target, and type. Line numbers are ignored.
        
        Args:
            before_refs: References from before version
            after_refs: References from after version
            
        Returns:
            ReferenceResult with before, after, added, and removed references
        """
        # Convert to sets for comparison (Reference.__eq__ ignores line number)
        before_set = set(before_refs)
        after_set = set(after_refs)
        
        # Compute differences
        added = after_set - before_set
        removed = before_set - after_set
        
        # Convert back to lists, preserving original line numbers from after/before
        added_list = ReferenceDiffer._restore_line_numbers(
            list(added), after_refs
        )
        removed_list = ReferenceDiffer._restore_line_numbers(
            list(removed), before_refs
        )
        
        return ReferenceResult(
            before_references=before_refs,
            after_references=after_refs,
            added_references=added_list,
            removed_references=removed_list
        )

    @staticmethod
    def _restore_line_numbers(
        diff_refs: List[Reference],
        original_refs: List[Reference]
    ) -> List[Reference]:
        """
        Restore line numbers from original references.
        
        When we convert to sets, we lose the original line numbers.
        This restores them from the original list.
        """
        # Build lookup from original refs
        original_map = {}
        for ref in original_refs:
            key = (ref.source, ref.target, ref.type)
            original_map[key] = ref.line
        
        # Restore line numbers
        result = []
        for ref in diff_refs:
            key = (ref.source, ref.target, ref.type)
            line = original_map.get(key, ref.line)
            result.append(Reference(
                source=ref.source,
                target=ref.target,
                type=ref.type,
                line=line
            ))
        
        return result
