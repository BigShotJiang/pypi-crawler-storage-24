"""Code slicer for extracting code snippets by line range."""

from typing import Optional, Tuple


class CodeSlicer:
    """Extracts code snippets from source code by line range."""

    @staticmethod
    def extract(source_code: str, line_range: Tuple[int, int]) -> str:
        """
        Extract code lines from source by line range (1-based, inclusive).
        
        Args:
            source_code: The full source code
            line_range: Tuple of (start_line, end_line) - 1-based, inclusive
            
        Returns:
            Extracted code snippet
        """
        if not source_code:
            return ""
        
        lines = source_code.split('\n')
        start_line, end_line = line_range
        
        # Handle edge cases
        if start_line < 1:
            start_line = 1
        if end_line > len(lines):
            end_line = len(lines)
        if start_line > end_line:
            return ""
        
        # Extract lines (convert to 0-based indexing)
        extracted = lines[start_line - 1:end_line]
        return '\n'.join(extracted)

    @staticmethod
    def get_line_at(source_code: str, line_number: int) -> Optional[str]:
        """
        Get a specific line from source code.
        
        Args:
            source_code: The full source code
            line_number: 1-based line number
            
        Returns:
            The line content or None if out of bounds
        """
        if not source_code or line_number < 1:
            return None
        
        lines = source_code.split('\n')
        if line_number > len(lines):
            return None
        
        return lines[line_number - 1]
