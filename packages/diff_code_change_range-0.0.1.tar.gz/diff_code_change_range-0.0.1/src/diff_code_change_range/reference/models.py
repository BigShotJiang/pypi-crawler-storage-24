"""Data models for reference extraction."""

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional, Tuple


class ReferenceType(Enum):
    """Types of references between code nodes."""
    METHOD_CALL = "method_call"
    FIELD_ACCESS = "field_access"
    TYPE_REFERENCE = "type_reference"
    INSTANTIATION = "instantiation"
    ANNOTATION = "annotation"
    INHERITANCE = "inheritance"
    IMPLEMENTATION = "implementation"


class NodeType(Enum):
    """Types of code nodes."""
    FILE = "file"
    CLASS = "class"
    INTERFACE = "interface"
    OBJECT = "object"
    ENUM = "enum"
    FUNCTION = "function"
    METHOD = "method"
    MEMBER = "member"
    VARIABLE = "variable"


@dataclass
class Reference:
    """Represents a reference from one code node to another."""
    source: str  # Fully qualified path of source node
    target: str  # Fully qualified path of target node
    type: ReferenceType
    line: Optional[int] = None  # Line number where reference occurs

    def __hash__(self):
        # For diffing purposes, ignore line number
        return hash((self.source, self.target, self.type))

    def __eq__(self, other):
        if not isinstance(other, Reference):
            return False
        return (self.source == other.source and 
                self.target == other.target and 
                self.type == other.type)


@dataclass
class ReferenceResult:
    """Result of reference extraction containing before/after references."""
    before_references: List[Reference] = field(default_factory=list)
    after_references: List[Reference] = field(default_factory=list)
    added_references: List[Reference] = field(default_factory=list)
    removed_references: List[Reference] = field(default_factory=list)


@dataclass
class AffectedNode:
    """Represents a node in the affected scope tree."""
    name: str
    type: NodeType
    line_range: Optional[Tuple[int, int]] = None
    children: Optional[List['AffectedNode']] = None


@dataclass
class AffectedScope:
    """Container for before and after affected scope trees."""
    before: List[AffectedNode]
    after: List[AffectedNode]


@dataclass
class QualifiedNode:
    """Flattened representation of an affected node with its qualified path."""
    qualified_path: str
    name: str
    node_type: NodeType
    line_range: Tuple[int, int]
    file_path: str
    container_path: Optional[str] = None  # Path of parent class/object
