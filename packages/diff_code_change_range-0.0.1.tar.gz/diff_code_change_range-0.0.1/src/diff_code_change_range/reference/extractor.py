"""Main reference extractor orchestrating the analysis pipeline."""

import sys
from typing import Dict, List, Optional

from .models import (
    Reference,
    ReferenceResult,
    AffectedScope,
    AffectedNode,
    QualifiedNode,
    NodeType,
)
from .scope_parser import ScopeParser
from .analyzer import ReferenceAnalyzer
from .differ import ReferenceDiffer


def extract_references(
    before_code: Dict[str, str],
    after_code: Dict[str, str],
    affected_scope: AffectedScope
) -> ReferenceResult:
    """
    Extract references between affected nodes in before and after code versions.
    
    Args:
        before_code: Map of file path -> source code for before version
        after_code: Map of file path -> source code for after version
        affected_scope: Affected scope trees for before and after
        
    Returns:
        ReferenceResult containing before/after references and their differences
    """
    # Parse scope to get qualified nodes
    parser = ScopeParser(affected_scope)
    before_nodes, after_nodes = parser.get_all_qualified_nodes()
    
    # Filter to only leaf nodes (methods, functions, members) that can contain references
    before_leaf_nodes = _filter_leaf_nodes(before_nodes)
    after_leaf_nodes = _filter_leaf_nodes(after_nodes)
    
    # Analyze before version
    before_refs = _analyze_version(
        before_code,
        before_leaf_nodes,
        before_nodes,  # All nodes as potential targets
        "before"
    )
    
    # Analyze after version
    after_refs = _analyze_version(
        after_code,
        after_leaf_nodes,
        after_nodes,  # All nodes as potential targets
        "after"
    )
    
    # Compute differences
    result = ReferenceDiffer.compute_diff(before_refs, after_refs)
    
    return result


def _filter_leaf_nodes(nodes: List[QualifiedNode]) -> List[QualifiedNode]:
    """Filter to only leaf nodes that can contain references (methods, functions, members)."""
    leaf_types = {
        NodeType.METHOD,
        NodeType.FUNCTION,
        NodeType.MEMBER,
        NodeType.VARIABLE,
    }
    return [n for n in nodes if n.node_type in leaf_types]


def _analyze_version(
    code_map: Dict[str, str],
    source_nodes: List[QualifiedNode],
    all_nodes: List[QualifiedNode],
    version: str
) -> List[Reference]:
    """
    Analyze one version (before or after) and extract references.
    
    Args:
        code_map: Map of file path -> source code
        source_nodes: List of nodes to analyze as sources (leaf nodes)
        all_nodes: List of all nodes as potential targets
        version: "before" or "after" (for logging)
        
    Returns:
        List of references found
    """
    all_references = []
    
    # Group nodes by file
    nodes_by_file: Dict[str, List[QualifiedNode]] = {}
    for node in source_nodes:
        if node.file_path not in nodes_by_file:
            nodes_by_file[node.file_path] = []
        nodes_by_file[node.file_path].append(node)
    
    # Analyze each file
    for file_path, nodes in nodes_by_file.items():
        if file_path not in code_map:
            continue
        
        source_code = code_map[file_path]
        if not source_code:
            continue
        
        # Create analyzer with all nodes as potential targets
        # (within the same version)
        analyzer = ReferenceAnalyzer(all_nodes, file_path)
        
        # Analyze each node in the file
        for node in nodes:
            try:
                refs = analyzer.analyze(source_code, node)
                # Filter out self-references (source == target)
                refs = [r for r in refs if r.source != r.target]
                all_references.extend(refs)
            except Exception as e:
                print(
                    f"Warning: Failed to analyze {node.qualified_path} in {version}: {e}",
                    file=sys.stderr
                )
                continue
    
    return all_references
