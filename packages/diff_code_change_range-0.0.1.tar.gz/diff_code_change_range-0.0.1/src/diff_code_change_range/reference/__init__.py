"""Reference extraction module for analyzing relationships between affected code nodes.

This module provides functionality to extract reference relationships (method calls,
field accesses, type references, etc.) between code nodes that are within the
affected scope of a code change.

Example usage:
    from diff_code_change_range.reference import extract_references, AffectedScope
    
    before_code = {"File.kt": "source code..."}
    after_code = {"File.kt": "modified code..."}
    scope = AffectedScope(before=[...], after=[...])
    
    result = extract_references(before_code, after_code, scope)
    print(result.added_references)    # New references in after version
    print(result.removed_references)  # References removed in after version

Supported reference types:
    - METHOD_CALL: Method or function invocation
    - FIELD_ACCESS: Field or property access
    - TYPE_REFERENCE: Type usage (variable declarations, parameters, etc.)
    - INSTANTIATION: Object creation via constructor
    - ANNOTATION: Annotation usage
    - INHERITANCE: Class inheritance (extends)
    - IMPLEMENTATION: Interface implementation (implements)

Supported languages:
    - Kotlin (.kt files)
    - Java (.java files)
    - Python (.py files)

Limitations:
    - Uses Tree-sitter AST analysis with heuristic matching (not full semantic analysis)
    - Only detects references where both source and target are in affectedScope
    - System classes (java.lang.*, kotlin.*, etc.) are filtered out
    - Method overloading is matched by name + argument count heuristic
"""

from .models import (
    Reference,
    ReferenceResult,
    ReferenceType,
    AffectedScope,
    AffectedNode,
    NodeType,
    QualifiedNode,
)
from .extractor import extract_references

__all__ = [
    "Reference",
    "ReferenceResult",
    "ReferenceType",
    "AffectedScope",
    "AffectedNode",
    "NodeType",
    "QualifiedNode",
    "extract_references",
]
