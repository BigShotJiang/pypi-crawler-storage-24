"""YAML reporter module for outputting affected code structures."""

import sys
from typing import List, Optional, Dict, Any

import yaml

from .structure_extractor import CodeNode, NodeType


def generate_yaml_report(
    before_structures: List[Optional[CodeNode]],
    after_structures: List[Optional[CodeNode]]
) -> str:
    """
    Generate a YAML report of affected code structures.
    
    Args:
        before_structures: List of affected structures for before version
        after_structures: List of affected structures for after version
        
    Returns:
        YAML string with `before` and `after` root keys
    """
    # Filter out None values
    before_list = [s for s in before_structures if s is not None]
    after_list = [s for s in after_structures if s is not None]
    
    # Build the report structure
    report = {
        "before": [_serialize_node(s) for s in before_list],
        "after": [_serialize_node(s) for s in after_list]
    }
    
    # Output as YAML
    return yaml.dump(report, default_flow_style=False, sort_keys=False, allow_unicode=True)


def _serialize_node(node: CodeNode) -> Dict[str, Any]:
    """
    Serialize a CodeNode to a dictionary for YAML output.
    
    Args:
        node: The CodeNode to serialize
        
    Returns:
        Dictionary with name, type, line_range, and optionally children
    """
    result = {
        "name": node.name,
        "type": node.node_type.value,
        "line_range": list(node.line_range)  # Convert tuple to list
    }
    
    # Add children for container nodes (if there are any)
    if node.children:
        result["children"] = [_serialize_node(child) for child in node.children]
    
    return result


def write_report(report: str, output_stream=None):
    """
    Write the YAML report to the specified output stream.
    
    Args:
        report: The YAML report string
        output_stream: Stream to write to (default: stdout)
    """
    if output_stream is None:
        output_stream = sys.stdout
    output_stream.write(report)


def generate_and_write_report(
    before_structures: List[Optional[CodeNode]],
    after_structures: List[Optional[CodeNode]],
    output_stream=sys.stdout
):
    """
    Generate and write the YAML report in one step.
    
    Args:
        before_structures: List of affected structures for before version
        after_structures: List of affected structures for after version
        output_stream: Stream to write to (default: stdout)
    """
    report = generate_yaml_report(before_structures, after_structures)
    write_report(report, output_stream)
