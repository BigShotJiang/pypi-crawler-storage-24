"""Affected node marker module for identifying changed code structures."""

from typing import Set, Optional, List
from .diff_parser import FileChange
from .structure_extractor import CodeNode, NodeType


def mark_affected_nodes(
    structure: Optional[CodeNode],
    file_change: FileChange,
    is_before: bool
) -> Optional[CodeNode]:
    """
    Mark affected nodes in a code structure based on changed lines.
    
    Args:
        structure: The code structure tree (can be None for deleted/added files)
        file_change: The file change information
        is_before: If True, use changed_old_lines; else use changed_new_lines
        
    Returns:
        Filtered structure containing only affected nodes, or None if no nodes affected
    """
    if structure is None:
        return None
    
    # Determine which changed lines to use
    if is_before:
        changed_lines = file_change.changed_old_lines
    else:
        changed_lines = file_change.changed_new_lines
    
    # Handle pure add/delete files - mark all nodes as affected
    if file_change.is_added or file_change.is_removed:
        return _mark_all_affected(structure)
    
    # For modified files, check line intersection
    if not changed_lines:
        return None
    
    return _filter_affected_nodes(structure, changed_lines)


def _line_range_intersects(node_range: tuple, changed_lines: Set[int]) -> bool:
    """
    Check if a node's line range intersects with changed lines.
    
    Args:
        node_range: Tuple of (start_line, end_line) - 1-based, inclusive
        changed_lines: Set of changed line numbers
        
    Returns:
        True if any line in the range is in changed_lines
    """
    start, end = node_range
    # Check if any line in [start, end] is in changed_lines
    for line in range(start, end + 1):
        if line in changed_lines:
            return True
    return False


def _mark_all_affected(node: CodeNode) -> CodeNode:
    """
    Mark all nodes in the tree as affected.
    
    Args:
        node: Root node of the structure tree
        
    Returns:
        A new tree with all nodes marked as affected
    """
    new_children = [_mark_all_affected(child) for child in node.children]
    return CodeNode(
        name=node.name,
        node_type=node.node_type,
        line_range=node.line_range,
        children=new_children,
        is_affected=True
    )


def _filter_affected_nodes(node: CodeNode, changed_lines: Set[int]) -> Optional[CodeNode]:
    """
    Filter nodes to only include those affected by changed lines.
    
    For leaf nodes (METHOD, FUNCTION, MEMBER), they are affected if their
    line range intersects with changed lines.
    
    For container nodes (CLASS, INTERFACE, OBJECT, ENUM, FILE), they are
    affected if any of their children is affected.
    
    Args:
        node: Current node to process
        changed_lines: Set of changed line numbers
        
    Returns:
        Filtered node if affected, None otherwise
    """
    # Determine if this is a leaf node type
    is_leaf = node.node_type in (NodeType.METHOD, NodeType.FUNCTION, NodeType.MEMBER)
    
    if is_leaf:
        # Leaf node: affected if intersects with changed lines
        if _line_range_intersects(node.line_range, changed_lines):
            return CodeNode(
                name=node.name,
                node_type=node.node_type,
                line_range=node.line_range,
                children=[],  # Leaf nodes have no children
                is_affected=True
            )
        return None
    
    # Container node: process children and keep affected ones
    affected_children = []
    for child in node.children:
        affected_child = _filter_affected_nodes(child, changed_lines)
        if affected_child:
            affected_children.append(affected_child)
    
    # Container is affected if any child is affected
    if affected_children:
        return CodeNode(
            name=node.name,
            node_type=node.node_type,
            line_range=node.line_range,
            children=affected_children,
            is_affected=True
        )
    
    # No affected children - check if container itself intersects with changes
    # This handles cases where a class header line (e.g., "public class Foo {"
    # or just the class declaration) is modified
    if _line_range_intersects(node.line_range, changed_lines):
        return CodeNode(
            name=node.name,
            node_type=node.node_type,
            line_range=node.line_range,
            children=affected_children,  # May be empty
            is_affected=True
        )
    
    return None


def process_file_change(file_change: FileChange) -> tuple:
    """
    Process a file change and return affected structures for before and after.
    
    Args:
        file_change: The file change to process
        
    Returns:
        Tuple of (before_structure, after_structure) where each is the
        filtered CodeNode tree or None
    """
    from .structure_extractor import extract_structure
    
    before_structure = None
    after_structure = None
    
    # Process before version
    if file_change.source_path and file_change.old_source:
        before_full = extract_structure(file_change.old_source, file_change.source_path)
        before_structure = mark_affected_nodes(before_full, file_change, is_before=True)
    
    # Process after version
    if file_change.target_path and file_change.new_source:
        after_full = extract_structure(file_change.new_source, file_change.target_path)
        after_structure = mark_affected_nodes(after_full, file_change, is_before=False)
    
    return before_structure, after_structure
