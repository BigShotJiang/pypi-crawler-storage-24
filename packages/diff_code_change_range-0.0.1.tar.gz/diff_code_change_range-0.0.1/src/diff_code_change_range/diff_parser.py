"""Diff parser module for extracting file changes from unified diff format."""

import sys
from dataclasses import dataclass, field
from typing import List, Set, Optional
from unidiff import PatchSet


@dataclass
class FileChange:
    """Represents changes to a single file."""
    source_path: Optional[str]
    target_path: Optional[str]
    old_source: str = ""
    new_source: str = ""
    changed_old_lines: Set[int] = field(default_factory=set)
    changed_new_lines: Set[int] = field(default_factory=set)
    is_added: bool = False
    is_removed: bool = False
    is_renamed: bool = False


def parse_diff(diff_text: str) -> List[FileChange]:
    """
    Parse unified diff text and extract file changes.
    
    Args:
        diff_text: Unified diff text from `git diff --full-index -U999999`
        
    Returns:
        List of FileChange objects for .java, .kt, and .py files
    """
    if not diff_text or not diff_text.strip():
        return []
    
    try:
        patch_set = PatchSet(diff_text)
    except Exception as e:
        print(f"Warning: Failed to parse diff: {e}", file=sys.stderr)
        return []
    
    file_changes = []
    
    for patched_file in patch_set:
        file_change = _process_patched_file(patched_file)
        if file_change:
            file_changes.append(file_change)
    
    return file_changes


def _strip_prefix(path: str) -> str:
    """Strip a/ or b/ prefix from git diff paths."""
    if path.startswith('a/') or path.startswith('b/'):
        return path[2:]
    return path


def _process_patched_file(patched_file) -> Optional[FileChange]:
    """Process a single patched file and extract its changes."""
    source_path = _strip_prefix(patched_file.source_file)
    target_path = _strip_prefix(patched_file.target_file)
    
    # Handle /dev/null paths for add/remove
    if source_path == "/dev/null":
        source_path = None
    if target_path == "/dev/null":
        target_path = None
    
    # Determine the actual file path (use target for adds, source for deletes)
    file_path = target_path or source_path
    
    if not file_path:
        return None
    
    # Check if file is a .java or .kt file
    if not _is_java_or_kotlin(file_path):
        return None
    
    # Check for binary files (no hunks)
    if patched_file.is_binary_file:
        print(f"Warning: Skipping binary file: {file_path}", file=sys.stderr)
        return None
    
    # Handle added file
    if patched_file.is_added_file:
        return _process_added_file(patched_file, source_path, target_path)
    
    # Handle removed file
    if patched_file.is_removed_file:
        return _process_removed_file(patched_file, source_path, target_path)
    
    # Handle renamed file
    is_renamed = patched_file.is_rename
    
    # Handle modified file (or renamed with changes)
    return _process_modified_file(patched_file, source_path, target_path, is_renamed)


def _is_java_or_kotlin(file_path: str) -> bool:
    """Check if file path has .java, .kt, or .py extension."""
    return file_path.endswith('.java') or file_path.endswith('.kt') or file_path.endswith('.py')


def _process_added_file(patched_file, source_path: Optional[str], target_path: Optional[str]) -> FileChange:
    """Process a newly added file."""
    new_lines = []
    changed_new_lines = set()
    
    for hunk in patched_file:
        for line in hunk:
            if line.line_type == '+':
                new_lines.append(line.value.rstrip('\n'))
                changed_new_lines.add(line.target_line_no)
    
    return FileChange(
        source_path=source_path,
        target_path=target_path,
        old_source="",
        new_source='\n'.join(new_lines),
        changed_old_lines=set(),
        changed_new_lines=changed_new_lines,
        is_added=True,
        is_removed=False,
        is_renamed=False
    )


def _process_removed_file(patched_file, source_path: Optional[str], target_path: Optional[str]) -> FileChange:
    """Process a deleted file."""
    old_lines = []
    changed_old_lines = set()
    
    for hunk in patched_file:
        for line in hunk:
            if line.line_type == '-':
                old_lines.append(line.value.rstrip('\n'))
                changed_old_lines.add(line.source_line_no)
    
    return FileChange(
        source_path=source_path,
        target_path=target_path,
        old_source='\n'.join(old_lines),
        new_source="",
        changed_old_lines=changed_old_lines,
        changed_new_lines=set(),
        is_added=False,
        is_removed=True,
        is_renamed=False
    )


def _process_modified_file(patched_file, source_path: Optional[str], target_path: Optional[str], is_renamed: bool) -> FileChange:
    """Process a modified file (including renamed files with changes)."""
    # For full-context diffs (-U999999), we can reconstruct the full file
    old_lines = []
    new_lines = []
    changed_old_lines = set()
    changed_new_lines = set()
    
    for hunk in patched_file:
        for line in hunk:
            if line.line_type == ' ':
                # Context line - appears in both old and new
                line_content = line.value.rstrip('\n')
                # Add to both old and new source at appropriate positions
                if line.source_line_no:
                    # Extend old_lines to accommodate
                    while len(old_lines) < line.source_line_no - 1:
                        old_lines.append('')
                    if line.source_line_no - 1 < len(old_lines):
                        old_lines[line.source_line_no - 1] = line_content
                    else:
                        old_lines.append(line_content)
                
                if line.target_line_no:
                    while len(new_lines) < line.target_line_no - 1:
                        new_lines.append('')
                    if line.target_line_no - 1 < len(new_lines):
                        new_lines[line.target_line_no - 1] = line_content
                    else:
                        new_lines.append(line_content)
                        
            elif line.line_type == '-':
                # Deleted line - only in old
                line_content = line.value.rstrip('\n')
                if line.source_line_no:
                    while len(old_lines) < line.source_line_no - 1:
                        old_lines.append('')
                    if line.source_line_no - 1 < len(old_lines):
                        old_lines[line.source_line_no - 1] = line_content
                    else:
                        old_lines.append(line_content)
                    changed_old_lines.add(line.source_line_no)
                    
            elif line.line_type == '+':
                # Added line - only in new
                line_content = line.value.rstrip('\n')
                if line.target_line_no:
                    while len(new_lines) < line.target_line_no - 1:
                        new_lines.append('')
                    if line.target_line_no - 1 < len(new_lines):
                        new_lines[line.target_line_no - 1] = line_content
                    else:
                        new_lines.append(line_content)
                    changed_new_lines.add(line.target_line_no)
    
    return FileChange(
        source_path=source_path,
        target_path=target_path,
        old_source='\n'.join(old_lines),
        new_source='\n'.join(new_lines),
        changed_old_lines=changed_old_lines,
        changed_new_lines=changed_new_lines,
        is_added=False,
        is_removed=False,
        is_renamed=is_renamed
    )
