"""diff-code-change-range: Extract affected code structures from git diff output."""

__version__ = "0.1.0"

from .diff_parser import parse_diff, FileChange
from .structure_extractor import extract_structure, CodeNode
from .affected_marker import mark_affected_nodes
from .yaml_reporter import generate_yaml_report

__all__ = [
    "parse_diff",
    "FileChange",
    "extract_structure",
    "CodeNode",
    "mark_affected_nodes",
    "generate_yaml_report",
]
