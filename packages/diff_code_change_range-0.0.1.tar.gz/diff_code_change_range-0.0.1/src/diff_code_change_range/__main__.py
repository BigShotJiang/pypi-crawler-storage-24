"""Entry point for `python -m diff_code_change_range`."""

import sys
from .cli import main

if __name__ == '__main__':
    sys.exit(main())
