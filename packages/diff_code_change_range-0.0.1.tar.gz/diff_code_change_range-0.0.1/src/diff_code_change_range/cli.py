"""CLI entry point for diff-code-change-range."""

import argparse
import sys
from typing import Optional

from .diff_parser import parse_diff, FileChange
from .structure_extractor import extract_structure, CodeNode
from .affected_marker import mark_affected_nodes
from .yaml_reporter import generate_and_write_report


def create_parser() -> argparse.ArgumentParser:
    """Create and configure the argument parser."""
    parser = argparse.ArgumentParser(
        prog='diff-code-change-range',
        description='Extract affected code structures from git diff output for Java and Kotlin files'
    )
    
    parser.add_argument(
        'diff_file',
        nargs='?',
        help='Path to diff file (default: read from stdin)'
    )
    
    parser.add_argument(
        '-v', '--version',
        action='version',
        version='%(prog)s 0.1.0'
    )
    
    return parser


def read_diff_input(diff_file: Optional[str]) -> str:
    """
    Read diff input from file or stdin.
    
    Args:
        diff_file: Path to diff file, or None to read from stdin
        
    Returns:
        The diff text content
        
    Raises:
        FileNotFoundError: If the specified file doesn't exist
        IOError: If there's an error reading the file
    """
    if diff_file:
        try:
            with open(diff_file, 'r', encoding='utf-8') as f:
                return f.read()
        except FileNotFoundError:
            print(f"Error: File not found: {diff_file}", file=sys.stderr)
            raise
        except IOError as e:
            print(f"Error reading file: {e}", file=sys.stderr)
            raise
    else:
        return sys.stdin.read()


def process_diff(diff_text: str) -> tuple:
    """
    Process diff text and return before/after structures.
    
    Args:
        diff_text: The unified diff text
        
    Returns:
        Tuple of (before_structures, after_structures) lists
    """
    file_changes = parse_diff(diff_text)
    
    before_structures = []
    after_structures = []
    
    for file_change in file_changes:
        before, after = _process_single_file(file_change)
        if before:
            before_structures.append(before)
        if after:
            after_structures.append(after)
    
    return before_structures, after_structures


def _process_single_file(file_change: FileChange) -> tuple:
    """
    Process a single file change.
    
    Args:
        file_change: The file change to process
        
    Returns:
        Tuple of (before_structure, after_structure)
    """
    before_structure = None
    after_structure = None
    
    # Process before version
    if file_change.source_path and file_change.old_source:
        try:
            before_full = extract_structure(file_change.old_source, file_change.source_path)
            if before_full:
                before_structure = mark_affected_nodes(before_full, file_change, is_before=True)
        except Exception as e:
            print(f"Warning: Failed to process before version of {file_change.source_path}: {e}", 
                  file=sys.stderr)
    
    # Process after version
    if file_change.target_path and file_change.new_source:
        try:
            after_full = extract_structure(file_change.new_source, file_change.target_path)
            if after_full:
                after_structure = mark_affected_nodes(after_full, file_change, is_before=False)
        except Exception as e:
            print(f"Warning: Failed to process after version of {file_change.target_path}: {e}", 
                  file=sys.stderr)
    
    return before_structure, after_structure


def main(args: Optional[list] = None) -> int:
    """
    Main entry point for the CLI.
    
    Args:
        args: Command line arguments (default: sys.argv[1:])
        
    Returns:
        Exit code (0 for success, 1 for error)
    """
    parser = create_parser()
    parsed_args = parser.parse_args(args)
    
    try:
        # Read diff input
        diff_text = read_diff_input(parsed_args.diff_file)
        
        if not diff_text.strip():
            # Empty input - output empty result
            generate_and_write_report([], [])
            return 0
        
        # Process diff
        before_structures, after_structures = process_diff(diff_text)
        
        # Generate and output report
        generate_and_write_report(before_structures, after_structures)
        
        return 0
        
    except FileNotFoundError:
        return 1
    except IOError:
        return 1
    except KeyboardInterrupt:
        print("\nInterrupted", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
