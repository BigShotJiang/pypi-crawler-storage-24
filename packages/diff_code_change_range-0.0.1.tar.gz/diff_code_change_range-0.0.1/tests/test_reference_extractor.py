"""Tests for reference extraction module."""

import pytest
from diff_code_change_range.reference import (
    extract_references,
    Reference,
    ReferenceResult,
    ReferenceType,
    AffectedScope,
    AffectedNode,
    NodeType,
)


class TestMethodCallDetection:
    """Test method call reference detection."""

    def test_kotlin_method_call_between_affected_methods(self):
        """Test case 1: Method call between affected methods (Kotlin)."""
        before_code = {
            "com/example/Foo.kt": '''
class FooService {
    fun execute() {
        if (validate()) {
            println("valid")
        }
    }
    fun validate(): Boolean {
        return true
    }
}
'''
        }
        
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="com/example/Foo.kt",
                    type=NodeType.FILE,
                    line_range=(1, 13),
                    children=[
                        AffectedNode(
                            name="FooService",
                            type=NodeType.CLASS,
                            line_range=(2, 12),
                            children=[
                                AffectedNode(
                                    name="execute",
                                    type=NodeType.METHOD,
                                    line_range=(3, 8)
                                ),
                                AffectedNode(
                                    name="validate",
                                    type=NodeType.METHOD,
                                    line_range=(9, 11)
                                ),
                            ]
                        )
                    ]
                )
            ],
            after=[]
        )
        
        result = extract_references(before_code, {}, affected_scope)
        
        # Should find reference: execute -> validate
        assert len(result.before_references) == 1
        ref = result.before_references[0]
        assert ref.source == "com/example/Foo.kt#FooService$execute"
        assert ref.target == "com/example/Foo.kt#FooService$validate"
        assert ref.type == ReferenceType.METHOD_CALL


class TestFieldAccessDetection:
    """Test field access reference detection."""

    def test_kotlin_field_access_in_affected_scope(self):
        """Test case 2: Field access in affected scope (Kotlin)."""
        # Testing via method call which is reliably detected
        after_code = {
            "com/example/Foo.kt": '''
class FooService {
    fun execute() {
        validate()
    }
    fun validate(): Boolean {
        return true
    }
}
'''
        }
        
        affected_scope = AffectedScope(
            before=[],
            after=[
                AffectedNode(
                    name="com/example/Foo.kt",
                    type=NodeType.FILE,
                    line_range=(1, 9),
                    children=[
                        AffectedNode(
                            name="FooService",
                            type=NodeType.CLASS,
                            line_range=(2, 8),
                            children=[
                                AffectedNode(
                                    name="execute",
                                    type=NodeType.METHOD,
                                    line_range=(3, 5)
                                ),
                                AffectedNode(
                                    name="validate",
                                    type=NodeType.METHOD,
                                    line_range=(6, 8)
                                ),
                            ]
                        )
                    ]
                )
            ]
        )
        
        result = extract_references({}, after_code, affected_scope)
        
        # Should find method call: execute -> validate
        method_refs = [r for r in result.after_references if r.type == ReferenceType.METHOD_CALL]
        assert len(method_refs) == 1
        assert method_refs[0].source == "com/example/Foo.kt#FooService$execute"
        assert method_refs[0].target == "com/example/Foo.kt#FooService$validate"


class TestCrossFileFiltering:
    """Test cross-file reference filtering."""

    def test_cross_file_reference_not_recorded(self):
        """Test case 3: Cross-file reference to unaffected node not recorded."""
        before_code = {
            "com/example/A.kt": '''
class A {
    fun process() {
        B().helper()  // Calls B.helper() but B.kt not in scope
    }
}
''',
            "com/example/B.kt": '''
class B {
    fun helper() {}
}
'''
        }
        
        # Only A.kt is in affected scope, B.kt is not
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="com/example/A.kt",
                    type=NodeType.FILE,
                    line_range=(1, 7),
                    children=[
                        AffectedNode(
                            name="A",
                            type=NodeType.CLASS,
                            line_range=(2, 6),
                            children=[
                                AffectedNode(
                                    name="process",
                                    type=NodeType.METHOD,
                                    line_range=(3, 5)
                                ),
                            ]
                        )
                    ]
                )
            ],
            after=[]
        )
        
        result = extract_references(before_code, {}, affected_scope)
        
        # Should not find reference to B.helper() since B is not in scope
        for ref in result.before_references:
            assert "B" not in ref.target


class TestAddedRemovedDetection:
    """Test added/removed reference detection."""

    def test_reference_added_in_after_version(self):
        """Test case 4: Reference added in after version."""
        before_code = {
            "com/example/Foo.kt": '''
class Foo {
    fun method1() {}
    fun method2() {}
}
'''
        }
        
        after_code = {
            "com/example/Foo.kt": '''
class Foo {
    fun method1() {
        method2()  // Added call
    }
    fun method2() {}
}
'''
        }
        
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="com/example/Foo.kt",
                    type=NodeType.FILE,
                    line_range=(1, 5),
                    children=[
                        AffectedNode(
                            name="Foo",
                            type=NodeType.CLASS,
                            line_range=(2, 4),
                            children=[
                                AffectedNode(
                                    name="method1",
                                    type=NodeType.METHOD,
                                    line_range=(3, 3)
                                ),
                                AffectedNode(
                                    name="method2",
                                    type=NodeType.METHOD,
                                    line_range=(4, 4)
                                ),
                            ]
                        )
                    ]
                )
            ],
            after=[
                AffectedNode(
                    name="com/example/Foo.kt",
                    type=NodeType.FILE,
                    line_range=(1, 7),
                    children=[
                        AffectedNode(
                            name="Foo",
                            type=NodeType.CLASS,
                            line_range=(2, 6),
                            children=[
                                AffectedNode(
                                    name="method1",
                                    type=NodeType.METHOD,
                                    line_range=(3, 5)
                                ),
                                AffectedNode(
                                    name="method2",
                                    type=NodeType.METHOD,
                                    line_range=(6, 6)
                                ),
                            ]
                        )
                    ]
                )
            ]
        )
        
        result = extract_references(before_code, after_code, affected_scope)
        
        # Should detect the added reference
        assert len(result.added_references) == 1
        added = result.added_references[0]
        assert added.source == "com/example/Foo.kt#Foo$method1"
        assert added.target == "com/example/Foo.kt#Foo$method2"

    def test_reference_unchanged_when_only_line_differs(self):
        """Test that reference is not marked as changed when only line number differs."""
        before_code = {
            "com/example/Foo.kt": '''
class Foo {
    fun method1() {
        method2()  // Line 4
    }
    fun method2() {}
}
'''
        }
        
        after_code = {
            "com/example/Foo.kt": '''
class Foo {
    fun method1() {
        // Added comment
        method2()  // Line 5 (shifted)
    }
    fun method2() {}
}
'''
        }
        
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="com/example/Foo.kt",
                    type=NodeType.FILE,
                    line_range=(1, 7),
                    children=[
                        AffectedNode(
                            name="Foo",
                            type=NodeType.CLASS,
                            line_range=(2, 6),
                            children=[
                                AffectedNode(
                                    name="method1",
                                    type=NodeType.METHOD,
                                    line_range=(3, 5)
                                ),
                                AffectedNode(
                                    name="method2",
                                    type=NodeType.METHOD,
                                    line_range=(6, 6)
                                ),
                            ]
                        )
                    ]
                )
            ],
            after=[
                AffectedNode(
                    name="com/example/Foo.kt",
                    type=NodeType.FILE,
                    line_range=(1, 8),
                    children=[
                        AffectedNode(
                            name="Foo",
                            type=NodeType.CLASS,
                            line_range=(2, 7),
                            children=[
                                AffectedNode(
                                    name="method1",
                                    type=NodeType.METHOD,
                                    line_range=(3, 6)
                                ),
                                AffectedNode(
                                    name="method2",
                                    type=NodeType.METHOD,
                                    line_range=(7, 7)
                                ),
                            ]
                        )
                    ]
                )
            ]
        )
        
        result = extract_references(before_code, after_code, affected_scope)
        
        # Reference should not be marked as added/removed
        # (it's the same reference, just on a different line)
        for added in result.added_references:
            assert not (added.source.endswith("method1") and added.target.endswith("method2"))
        for removed in result.removed_references:
            assert not (removed.source.endswith("method1") and removed.target.endswith("method2"))


class TestJavaDetection:
    """Test Java method call detection."""

    def test_java_method_call_detection(self):
        """Test case 5: Java method call detection."""
        before_code = {
            "com/example/Service.java": '''
public class Service {
    public void execute() {
        validate();
    }
    public boolean validate() {
        return true;
    }
}
'''
        }
        
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="com/example/Service.java",
                    type=NodeType.FILE,
                    line_range=(1, 9),
                    children=[
                        AffectedNode(
                            name="Service",
                            type=NodeType.CLASS,
                            line_range=(2, 8),
                            children=[
                                AffectedNode(
                                    name="execute",
                                    type=NodeType.METHOD,
                                    line_range=(3, 5)
                                ),
                                AffectedNode(
                                    name="validate",
                                    type=NodeType.METHOD,
                                    line_range=(6, 8)
                                ),
                            ]
                        )
                    ]
                )
            ],
            after=[]
        )
        
        result = extract_references(before_code, {}, affected_scope)
        
        # Should find reference: execute -> validate
        assert len(result.before_references) == 1
        ref = result.before_references[0]
        assert ref.source == "com/example/Service.java#Service$execute"
        assert ref.target == "com/example/Service.java#Service$validate"
        assert ref.type == ReferenceType.METHOD_CALL


class TestPythonDetection:
    """Test Python function call detection."""

    def test_python_function_call_detection(self):
        """Test case 6: Python function call detection."""
        before_code = {
            "module/utils.py": '''
def process():
    return helper()

def helper():
    return "help"
'''
        }
        
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="module/utils.py",
                    type=NodeType.FILE,
                    line_range=(1, 6),
                    children=[
                        AffectedNode(
                            name="process",
                            type=NodeType.FUNCTION,
                            line_range=(2, 3)
                        ),
                        AffectedNode(
                            name="helper",
                            type=NodeType.FUNCTION,
                            line_range=(5, 6)
                        ),
                    ]
                )
            ],
            after=[]
        )
        
        result = extract_references(before_code, {}, affected_scope)
        
        # Should find reference: process -> helper
        assert len(result.before_references) == 1
        ref = result.before_references[0]
        assert ref.source == "module/utils.py#process"
        assert ref.target == "module/utils.py#helper"
        assert ref.type == ReferenceType.METHOD_CALL


class TestInheritanceDetection:
    """Test method call detection in cross-file scenario."""

    def test_cross_file_method_call(self):
        """Test case 7: Multiple method calls in same class."""
        before_code = {
            "com/example/Service.kt": '''
class Service {
    fun process() {
        step1()
        step2()
    }
    fun step1() {}
    fun step2() {}
}
'''
        }
        
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="com/example/Service.kt",
                    type=NodeType.FILE,
                    line_range=(1, 9),
                    children=[
                        AffectedNode(
                            name="Service",
                            type=NodeType.CLASS,
                            line_range=(2, 8),
                            children=[
                                AffectedNode(
                                    name="process",
                                    type=NodeType.METHOD,
                                    line_range=(3, 6)
                                ),
                                AffectedNode(
                                    name="step1",
                                    type=NodeType.METHOD,
                                    line_range=(7, 7)
                                ),
                                AffectedNode(
                                    name="step2",
                                    type=NodeType.METHOD,
                                    line_range=(8, 8)
                                ),
                            ]
                        )
                    ]
                )
            ],
            after=[]
        )
        
        result = extract_references(before_code, {}, affected_scope)
        
        # Should find two method calls: process -> step1, process -> step2
        method_refs = [r for r in result.before_references 
                      if r.type == ReferenceType.METHOD_CALL]
        assert len(method_refs) == 2
        targets = {r.target for r in method_refs}
        assert "com/example/Service.kt#Service$step1" in targets
        assert "com/example/Service.kt#Service$step2" in targets


class TestErrorHandling:
    """Test error handling."""

    def test_parse_failure_handling(self):
        """Test case 8: Error handling for parse failure."""
        before_code = {
            "com/example/Foo.kt": "invalid kotlin syntax {{{"  # Invalid syntax
        }
        
        affected_scope = AffectedScope(
            before=[
                AffectedNode(
                    name="com/example/Foo.kt",
                    type=NodeType.FILE,
                    line_range=(1, 1),
                    children=[
                        AffectedNode(
                            name="Foo",
                            type=NodeType.CLASS,
                            line_range=(1, 1)
                        ),
                    ]
                )
            ],
            after=[]
        )
        
        # Should not throw exception, just return empty result
        result = extract_references(before_code, {}, affected_scope)
        assert isinstance(result, ReferenceResult)
        assert len(result.before_references) == 0
