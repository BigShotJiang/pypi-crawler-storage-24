"""End-to-end tests for diff-code-change-range."""

import io
import os
import sys
import pytest
import yaml
import subprocess

from diff_code_change_range.cli import read_diff_input, process_diff


FIXTURES_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'fixtures')


def run_cli_with_file(filepath):
    """Helper to run CLI with a file using subprocess."""
    result = subprocess.run(
        [sys.executable, '-m', 'diff_code_change_range', filepath],
        capture_output=True,
        text=True
    )
    return result.returncode, result.stdout


class TestEndToEnd:
    """End-to-end tests covering full pipeline."""

    def test_java_added_file(self):
        """Test processing Java added file."""
        filepath = os.path.join(FIXTURES_DIR, 'java_add.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        # Before should be empty (new file)
        assert parsed["before"] == []
        # After should have the class structure
        assert len(parsed["after"]) == 1
        assert parsed["after"][0]["name"] == "src/Main.java"
        assert parsed["after"][0]["type"] == "file"

    def test_java_deleted_file(self):
        """Test processing Java deleted file."""
        filepath = os.path.join(FIXTURES_DIR, 'java_delete.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        # Before should have the deleted class
        assert len(parsed["before"]) == 1
        assert parsed["after"] == []

    def test_java_modified_file(self):
        """Test processing Java modified file."""
        filepath = os.path.join(FIXTURES_DIR, 'java_modify.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        # Should have both before and after
        assert len(parsed["before"]) == 1
        assert len(parsed["after"]) == 1

    def test_kotlin_added_file(self):
        """Test processing Kotlin added file."""
        filepath = os.path.join(FIXTURES_DIR, 'kotlin_add.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        assert parsed["before"] == []
        assert len(parsed["after"]) == 1

    def test_kotlin_top_level_function(self):
        """Test processing Kotlin with top-level functions."""
        filepath = os.path.join(FIXTURES_DIR, 'kotlin_function.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        # Should have functions as top-level children
        assert len(parsed["after"]) == 1
        children = parsed["after"][0].get("children", [])
        # Should have helper and main functions
        function_names = [c["name"] for c in children if c["type"] == "function"]
        assert "helper" in function_names or "main" in function_names

    def test_empty_diff(self):
        """Test processing empty diff."""
        filepath = os.path.join(FIXTURES_DIR, 'empty.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        assert parsed["before"] == []
        assert parsed["after"] == []

    def test_file_not_found(self):
        """Test handling of non-existent file."""
        exit_code, output = run_cli_with_file('nonexistent.diff')
        assert exit_code == 1

    def test_python_added_file(self):
        """Test processing Python added file."""
        filepath = os.path.join(FIXTURES_DIR, 'python_add.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        assert parsed["before"] == []
        assert len(parsed["after"]) == 1
        assert parsed["after"][0]["name"] == "src/main.py"
        assert parsed["after"][0]["type"] == "file"
        
        # Should have class and function children
        children = parsed["after"][0].get("children", [])
        assert len(children) == 2
        assert children[0]["name"] == "Calculator"
        assert children[0]["type"] == "class"
        assert children[1]["name"] == "main"
        assert children[1]["type"] == "function"

    def test_python_class_with_decorators(self):
        """Test processing Python class with decorated methods."""
        filepath = os.path.join(FIXTURES_DIR, 'python_class.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        assert len(parsed["after"]) == 1
        
        children = parsed["after"][0].get("children", [])
        assert len(children) == 1
        assert children[0]["name"] == "User"
        
        # Check methods
        methods = children[0].get("children", [])
        method_names = [m["name"] for m in methods if m["type"] == "method"]
        assert "__init__" in method_names
        assert "@classmethod create_guest" in method_names
        assert "async save" in method_names

    def test_python_module_variables(self):
        """Test processing Python file with module-level variables."""
        filepath = os.path.join(FIXTURES_DIR, 'python_variables.diff')
        exit_code, output = run_cli_with_file(filepath)
        
        assert exit_code == 0
        
        parsed = yaml.safe_load(output)
        assert len(parsed["after"]) == 1
        
        children = parsed["after"][0].get("children", [])
        # Should have 3 variables and 1 class
        variables = [c for c in children if c["type"] == "variable"]
        classes = [c for c in children if c["type"] == "class"]
        
        assert len(variables) == 3
        assert len(classes) == 1
        
        var_names = [v["name"] for v in variables]
        assert "DEBUG" in var_names
        assert "DATABASE_URL" in var_names
        assert "MAX_CONNECTIONS" in var_names


class TestReadDiffInput:
    """Tests for read_diff_input function."""

    def test_read_from_file(self, tmp_path):
        """Test reading diff from file."""
        diff_file = tmp_path / "test.diff"
        diff_file.write_text("diff content")
        
        result = read_diff_input(str(diff_file))
        assert result == "diff content"

    def test_read_from_stdin(self, monkeypatch):
        """Test reading diff from stdin."""
        monkeypatch.setattr('sys.stdin', io.StringIO("stdin diff"))
        
        result = read_diff_input(None)
        assert result == "stdin diff"

    def test_file_not_found_raises(self):
        """Test that FileNotFoundError is raised for missing file."""
        with pytest.raises(FileNotFoundError):
            read_diff_input("/nonexistent/path/to/file.diff")


class TestProcessDiff:
    """Tests for process_diff function."""

    def test_process_simple_diff(self):
        """Test processing a simple diff."""
        diff_text = """diff --git a/Test.java b/Test.java
new file mode 100644
index 0000000..1234567
--- /dev/null
+++ b/Test.java
@@ -0,0 +1,3 @@
+public class Test {
+    int value;
+}
"""
        before, after = process_diff(diff_text)
        
        # Before should be empty (new file)
        assert before == []
        
        # After should have the file
        assert len(after) == 1
        assert after[0].name == "Test.java"

    def test_process_empty_diff(self):
        """Test processing empty diff."""
        before, after = process_diff("")
        assert before == []
        assert after == []


class TestCLIMain:
    """Tests for CLI main function."""

    def test_version_flag(self):
        """Test --version flag."""
        result = subprocess.run(
            [sys.executable, '-m', 'diff_code_change_range', '--version'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert '0.1.0' in result.stdout

    def test_help_flag(self):
        """Test --help flag."""
        result = subprocess.run(
            [sys.executable, '-m', 'diff_code_change_range', '--help'],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0
        assert 'diff-code-change-range' in result.stdout

    def test_empty_stdin(self, monkeypatch, tmp_path):
        """Test with empty stdin."""
        empty_file = tmp_path / "empty.diff"
        empty_file.write_text("")
        
        result = subprocess.run(
            [sys.executable, '-m', 'diff_code_change_range', str(empty_file)],
            capture_output=True,
            text=True
        )
        assert result.returncode == 0


class TestOutputFormat:
    """Tests verifying YAML output format matches spec."""

    def test_output_has_before_and_after_keys(self, tmp_path):
        """Test that output has both before and after root keys."""
        diff_text = """diff --git a/Test.java b/Test.java
new file mode 100644
index 0000000..1234567
--- /dev/null
+++ b/Test.java
@@ -0,0 +1,3 @@
+public class Test {
+    void method() {}
+}
"""
        diff_file = tmp_path / "test.diff"
        diff_file.write_text(diff_text)
        
        result = subprocess.run(
            [sys.executable, '-m', 'diff_code_change_range', str(diff_file)],
            capture_output=True,
            text=True
        )
        
        parsed = yaml.safe_load(result.stdout)
        assert "before" in parsed
        assert "after" in parsed

    def test_node_has_required_fields(self, tmp_path):
        """Test that nodes have name, type, line_range fields."""
        diff_text = """diff --git a/Test.java b/Test.java
new file mode 100644
index 0000000..1234567
--- /dev/null
+++ b/Test.java
@@ -0,0 +1,3 @@
+public class Test {
+    void method() {}
+}
"""
        diff_file = tmp_path / "test.diff"
        diff_file.write_text(diff_text)
        
        result = subprocess.run(
            [sys.executable, '-m', 'diff_code_change_range', str(diff_file)],
            capture_output=True,
            text=True
        )
        
        parsed = yaml.safe_load(result.stdout)
        if parsed["after"]:
            node = parsed["after"][0]
            assert "name" in node
            assert "type" in node
            assert "line_range" in node
            assert isinstance(node["line_range"], list)
