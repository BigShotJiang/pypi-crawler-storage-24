"""Unit tests for YAML reporter module."""

import io
import pytest
import yaml

from diff_code_change_range.yaml_reporter import (
    generate_yaml_report, write_report, generate_and_write_report
)
from diff_code_change_range.structure_extractor import CodeNode, NodeType


class TestGenerateYamlReport:
    """Tests for generate_yaml_report function."""

    def test_empty_report(self):
        """Test generating report with no structures."""
        result = generate_yaml_report([], [])
        parsed = yaml.safe_load(result)
        assert parsed == {"before": [], "after": []}

    def test_only_before_structure(self):
        """Test generating report with only before structure."""
        node = CodeNode("Test.java", NodeType.FILE, (1, 10))
        result = generate_yaml_report([node], [])
        parsed = yaml.safe_load(result)
        assert len(parsed["before"]) == 1
        assert len(parsed["after"]) == 0
        assert parsed["before"][0]["name"] == "Test.java"
        assert parsed["before"][0]["type"] == "file"

    def test_only_after_structure(self):
        """Test generating report with only after structure."""
        node = CodeNode("Test.java", NodeType.FILE, (1, 10))
        result = generate_yaml_report([], [node])
        parsed = yaml.safe_load(result)
        assert len(parsed["before"]) == 0
        assert len(parsed["after"]) == 1

    def test_both_before_and_after(self):
        """Test generating report with both before and after structures."""
        before = CodeNode("Old.java", NodeType.FILE, (1, 10))
        after = CodeNode("New.java", NodeType.FILE, (1, 15))
        result = generate_yaml_report([before], [after])
        parsed = yaml.safe_load(result)
        assert len(parsed["before"]) == 1
        assert len(parsed["after"]) == 1
        assert parsed["before"][0]["name"] == "Old.java"
        assert parsed["after"][0]["name"] == "New.java"

    def test_line_range_as_array(self):
        """Test that line_range is output as [start, end] array."""
        node = CodeNode("Test", NodeType.CLASS, (5, 20))
        result = generate_yaml_report([node], [])
        parsed = yaml.safe_load(result)
        assert parsed["before"][0]["line_range"] == [5, 20]

    def test_single_line_range(self):
        """Test single line range."""
        node = CodeNode("method", NodeType.METHOD, (10, 10))
        result = generate_yaml_report([node], [])
        parsed = yaml.safe_load(result)
        assert parsed["before"][0]["line_range"] == [10, 10]

    def test_children_serialization(self):
        """Test that children are properly serialized."""
        method = CodeNode("doSomething", NodeType.METHOD, (5, 10))
        cls = CodeNode("TestClass", NodeType.CLASS, (1, 15), [method])
        result = generate_yaml_report([cls], [])
        parsed = yaml.safe_load(result)
        
        class_node = parsed["before"][0]
        assert class_node["type"] == "class"
        assert "children" in class_node
        assert len(class_node["children"]) == 1
        assert class_node["children"][0]["name"] == "doSomething"
        assert class_node["children"][0]["type"] == "method"

    def test_nested_children(self):
        """Test deeply nested children structure."""
        inner_method = CodeNode("innerMethod", NodeType.METHOD, (8, 12))
        inner_class = CodeNode("Inner", NodeType.CLASS, (5, 15), [inner_method])
        outer_class = CodeNode("Outer", NodeType.CLASS, (1, 20), [inner_class])
        
        result = generate_yaml_report([outer_class], [])
        parsed = yaml.safe_load(result)
        
        outer = parsed["before"][0]
        assert outer["name"] == "Outer"
        assert len(outer["children"]) == 1
        
        inner = outer["children"][0]
        assert inner["name"] == "Inner"
        assert len(inner["children"]) == 1

    def test_all_node_types(self):
        """Test serialization of all node types."""
        nodes = [
            CodeNode("MyClass", NodeType.CLASS, (1, 5)),
            CodeNode("MyInterface", NodeType.INTERFACE, (1, 5)),
            CodeNode("MyObject", NodeType.OBJECT, (1, 5)),
            CodeNode("MyEnum", NodeType.ENUM, (1, 5)),
            CodeNode("myFunction", NodeType.FUNCTION, (1, 5)),
            CodeNode("myMethod", NodeType.METHOD, (1, 5)),
            CodeNode("myField", NodeType.MEMBER, (1, 5)),
        ]
        
        result = generate_yaml_report(nodes, [])
        parsed = yaml.safe_load(result)
        
        types = [n["type"] for n in parsed["before"]]
        assert "class" in types
        assert "interface" in types
        assert "object" in types
        assert "enum" in types
        assert "function" in types
        assert "method" in types
        assert "member" in types

    def test_leaf_nodes_have_no_children_key(self):
        """Test that leaf nodes without children don't have children key."""
        method = CodeNode("method", NodeType.METHOD, (1, 5))  # No children
        result = generate_yaml_report([method], [])
        parsed = yaml.safe_load(result)
        
        assert "children" not in parsed["before"][0]

    def test_none_structures_filtered(self):
        """Test that None structures are filtered out."""
        node = CodeNode("Test", NodeType.CLASS, (1, 5))
        result = generate_yaml_report([node, None, node], [None, node, None])
        parsed = yaml.safe_load(result)
        
        assert len(parsed["before"]) == 2
        assert len(parsed["after"]) == 1


class TestWriteReport:
    """Tests for write_report function."""

    def test_writes_to_stdout_by_default(self, capsys):
        """Test writing to stdout by default."""
        report = "test: yaml"
        write_report(report)
        # Can't easily test stdout directly, but we can test with StringIO
        
    def test_writes_to_provided_stream(self):
        """Test writing to a provided stream."""
        stream = io.StringIO()
        report = "test: yaml\n"
        write_report(report, stream)
        assert stream.getvalue() == report


class TestGenerateAndWriteReport:
    """Tests for generate_and_write_report function."""

    def test_full_pipeline(self):
        """Test the full generate and write pipeline."""
        stream = io.StringIO()
        node = CodeNode("Test.java", NodeType.FILE, (1, 10))
        
        generate_and_write_report([node], [], stream)
        
        output = stream.getvalue()
        parsed = yaml.safe_load(output)
        assert parsed["before"][0]["name"] == "Test.java"
        assert parsed["after"] == []

    def test_valid_yaml_output(self):
        """Test that output is valid YAML."""
        stream = io.StringIO()
        method = CodeNode("doIt", NodeType.METHOD, (5, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method])
        
        generate_and_write_report([cls], [cls], stream)
        
        output = stream.getvalue()
        # Should parse without errors
        parsed = yaml.safe_load(output)
        assert "before" in parsed
        assert "after" in parsed
