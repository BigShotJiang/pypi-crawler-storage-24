"""Unit tests for structure extractor module."""

import pytest
from diff_code_change_range.structure_extractor import (
    extract_structure, CodeNode, NodeType,
    JAVA_AVAILABLE, KOTLIN_AVAILABLE, PYTHON_AVAILABLE
)


class TestExtractStructure:
    """Tests for extract_structure function."""

    def test_empty_source(self):
        """Test extracting from empty source returns None."""
        result = extract_structure("", "test.java")
        assert result is None

    def test_unsupported_file_type(self):
        """Test extracting from unsupported file type returns None."""
        result = extract_structure("some code", "test.rb")
        assert result is None

    @pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")
    def test_simple_java_class(self):
        """Test extracting simple Java class."""
        source = """
public class TestClass {
    private int value;
    
    public void method() {
        System.out.println("hello");
    }
}
"""
        result = extract_structure(source, "TestClass.java")
        assert result is not None
        assert result.name == "TestClass.java"
        assert result.node_type == NodeType.FILE
        assert len(result.children) == 1
        
        class_node = result.children[0]
        assert class_node.name == "TestClass"
        assert class_node.node_type == NodeType.CLASS
        assert len(class_node.children) == 2  # field and method

    @pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")
    def test_java_with_multiple_classes(self):
        """Test extracting Java file with multiple classes."""
        source = """
public class First {
}

class Second {
}
"""
        result = extract_structure(source, "Multi.java")
        assert result is not None
        assert len(result.children) == 2

    @pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")
    def test_java_interface(self):
        """Test extracting Java interface."""
        source = """
public interface MyInterface {
    void doSomething();
}
"""
        result = extract_structure(source, "MyInterface.java")
        assert result is not None
        assert result.children[0].node_type == NodeType.INTERFACE

    @pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")
    def test_java_enum(self):
        """Test extracting Java enum."""
        source = """
public enum Status {
    ACTIVE, INACTIVE
}
"""
        result = extract_structure(source, "Status.java")
        assert result is not None
        assert result.children[0].node_type == NodeType.ENUM

    @pytest.mark.skipif(not JAVA_AVAILABLE, reason="tree-sitter-java not available")
    def test_java_method_extraction(self):
        """Test extracting Java methods with line ranges."""
        source = """public class Test {
    public void method1() {
        int x = 1;
    }
    
    public void method2() {
        int y = 2;
    }
}"""
        result = extract_structure(source, "Test.java")
        class_node = result.children[0]
        methods = [c for c in class_node.children if c.node_type == NodeType.METHOD]
        assert len(methods) == 2
        assert methods[0].name == "method1"
        assert methods[1].name == "method2"

    @pytest.mark.skipif(not KOTLIN_AVAILABLE, reason="tree-sitter-kotlin not available")
    def test_simple_kotlin_class(self):
        """Test extracting simple Kotlin class."""
        source = """
class TestClass {
    fun method() {
        println("hello")
    }
}
"""
        result = extract_structure(source, "TestClass.kt")
        assert result is not None
        assert result.node_type == NodeType.FILE
        assert len(result.children) == 1
        
        class_node = result.children[0]
        assert class_node.node_type == NodeType.CLASS

    @pytest.mark.skipif(not KOTLIN_AVAILABLE, reason="tree-sitter-kotlin not available")
    def test_kotlin_object(self):
        """Test extracting Kotlin object."""
        source = """
object Singleton {
    fun doSomething() {}
}
"""
        result = extract_structure(source, "Singleton.kt")
        assert result is not None
        assert result.children[0].node_type == NodeType.OBJECT

    @pytest.mark.skipif(not KOTLIN_AVAILABLE, reason="tree-sitter-kotlin not available")
    def test_kotlin_top_level_function(self):
        """Test extracting Kotlin top-level function."""
        source = """
fun main() {
    println("Hello")
}
"""
        result = extract_structure(source, "Main.kt")
        assert result is not None
        func = result.children[0]
        assert func.node_type == NodeType.FUNCTION
        assert func.name == "main"

    @pytest.mark.skipif(not KOTLIN_AVAILABLE, reason="tree-sitter-kotlin not available")
    def test_kotlin_property(self):
        """Test extracting Kotlin property."""
        source = """
class Test {
    val property: String = "value"
}
"""
        result = extract_structure(source, "Test.kt")
        class_node = result.children[0]
        members = [c for c in class_node.children if c.node_type == NodeType.MEMBER]
        assert len(members) >= 1

    def test_line_range_format(self):
        """Test that line ranges are correct format (1-based)."""
        source = """class Test {
    fun method() {
        // line 3
    }
}"""
        result = extract_structure(source, "Test.kt")
        if result:
            # File should span lines 1-5
            assert result.line_range[0] == 1
            assert result.line_range[1] >= 1


class TestCodeNode:
    """Tests for CodeNode dataclass."""

    def test_node_creation(self):
        """Test creating a CodeNode."""
        node = CodeNode(
            name="TestClass",
            node_type=NodeType.CLASS,
            line_range=(1, 10),
            children=[],
            is_affected=False
        )
        assert node.name == "TestClass"
        assert node.node_type == NodeType.CLASS
        assert node.line_range == (1, 10)

    def test_node_with_children(self):
        """Test creating a CodeNode with children."""
        method = CodeNode(
            name="doSomething",
            node_type=NodeType.METHOD,
            line_range=(5, 10)
        )
        cls = CodeNode(
            name="TestClass",
            node_type=NodeType.CLASS,
            line_range=(1, 15),
            children=[method]
        )
        assert len(cls.children) == 1
        assert cls.children[0].name == "doSomething"

    def test_node_type_enum(self):
        """Test NodeType enum values."""
        assert NodeType.CLASS.value == "class"
        assert NodeType.METHOD.value == "method"
        assert NodeType.FUNCTION.value == "function"
        assert NodeType.MEMBER.value == "member"
        assert NodeType.INTERFACE.value == "interface"
        assert NodeType.ENUM.value == "enum"
        assert NodeType.OBJECT.value == "object"
        assert NodeType.FILE.value == "file"
        assert NodeType.VARIABLE.value == "variable"


# ============================================================================
# Python Extraction Tests
# ============================================================================

class TestPythonExtraction:
    """Tests for Python structure extraction."""

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_simple_class(self):
        """Test extracting simple Python class."""
        source = '''
class TestClass:
    def method(self):
        pass
'''
        result = extract_structure(source, "test.py")
        assert result is not None
        assert result.name == "test.py"
        assert result.node_type == NodeType.FILE
        assert len(result.children) == 1
        
        class_node = result.children[0]
        assert class_node.name == "TestClass"
        assert class_node.node_type == NodeType.CLASS

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_module_function(self):
        """Test extracting Python module-level function."""
        source = '''
def foo():
    pass

def bar():
    pass
'''
        result = extract_structure(source, "test.py")
        assert result is not None
        funcs = [c for c in result.children if c.node_type == NodeType.FUNCTION]
        assert len(funcs) == 2
        assert funcs[0].name == "foo"
        assert funcs[1].name == "bar"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_async_function(self):
        """Test extracting async Python function."""
        source = '''
async def fetch_data():
    pass
'''
        result = extract_structure(source, "test.py")
        assert result is not None
        funcs = [c for c in result.children if c.node_type == NodeType.FUNCTION]
        assert len(funcs) == 1
        assert funcs[0].name == "async fetch_data"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_module_variable(self):
        """Test extracting Python module-level variable."""
        source = '''
x = 5
y = 10
'''
        result = extract_structure(source, "test.py")
        assert result is not None
        vars = [c for c in result.children if c.node_type == NodeType.VARIABLE]
        assert len(vars) == 2
        assert vars[0].name == "x"
        assert vars[1].name == "y"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_method_extraction(self):
        """Test extracting Python class methods."""
        source = '''
class Test:
    def method1(self):
        pass
    
    def method2(self):
        pass
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        methods = [c for c in class_node.children if c.node_type == NodeType.METHOD]
        assert len(methods) == 2
        assert methods[0].name == "method1"
        assert methods[1].name == "method2"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_async_method(self):
        """Test extracting async Python method."""
        source = '''
class Test:
    async def run(self):
        pass
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        methods = [c for c in class_node.children if c.node_type == NodeType.METHOD]
        assert len(methods) == 1
        assert methods[0].name == "async run"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_classmethod(self):
        """Test extracting Python classmethod with decorator."""
        source = '''
class Test:
    @classmethod
    def create(cls):
        pass
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        methods = [c for c in class_node.children if c.node_type == NodeType.METHOD]
        assert len(methods) == 1
        assert methods[0].name == "@classmethod create"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_staticmethod(self):
        """Test extracting Python staticmethod with decorator."""
        source = '''
class Test:
    @staticmethod
    def helper():
        pass
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        methods = [c for c in class_node.children if c.node_type == NodeType.METHOD]
        assert len(methods) == 1
        assert methods[0].name == "@staticmethod helper"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_class_variable(self):
        """Test extracting Python class variable."""
        source = '''
class Test:
    class_var = 10
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        members = [c for c in class_node.children if c.node_type == NodeType.MEMBER]
        assert len(members) == 1
        assert members[0].name == "class_var"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_instance_variable_from_init(self):
        """Test extracting Python instance variables from __init__."""
        source = '''
class Test:
    def __init__(self):
        self.name = "test"
        self.value = 42
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        method = [c for c in class_node.children if c.node_type == NodeType.METHOD][0]
        # Instance variables should be children of the method
        instance_vars = [c for c in method.children if c.node_type == NodeType.MEMBER]
        assert len(instance_vars) == 2
        assert instance_vars[0].name == "name"
        assert instance_vars[1].name == "value"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_empty_file(self):
        """Test extracting from empty Python file."""
        source = ""
        result = extract_structure(source, "test.py")
        assert result is None

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_nested_class(self):
        """Test extracting Python nested class."""
        source = '''
class Outer:
    class Inner:
        pass
'''
        result = extract_structure(source, "test.py")
        outer = result.children[0]
        assert outer.name == "Outer"
        inner = [c for c in outer.children if c.node_type == NodeType.CLASS]
        assert len(inner) == 1
        assert inner[0].name == "Inner"

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_syntax_error(self):
        """Test handling Python file with syntax errors."""
        source = '''
class Test:
    def broken(
        # Missing closing paren and colon
        pass
'''
        # Should return None or handle gracefully
        result = extract_structure(source, "test.py")
        # The behavior may vary - either None or partial result is acceptable
        # The key is it doesn't crash

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_nested_function_skipped(self):
        """Test that nested functions inside methods are skipped."""
        source = '''
class Test:
    def outer(self):
        def inner():
            pass
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        methods = [c for c in class_node.children if c.node_type == NodeType.METHOD]
        assert len(methods) == 1
        assert methods[0].name == "outer"
        # inner function should not be extracted as a separate node
        assert not any(c.name == "inner" for c in class_node.children)

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_lambda_skipped(self):
        """Test that lambda expressions are skipped."""
        source = '''
class Test:
    def method(self):
        f = lambda x: x + 1
'''
        result = extract_structure(source, "test.py")
        class_node = result.children[0]
        methods = [c for c in class_node.children if c.node_type == NodeType.METHOD]
        assert len(methods) == 1
        # Lambda should not appear as a separate node
        assert not any(c.name == "lambda" for c in class_node.children)

    @pytest.mark.skipif(not PYTHON_AVAILABLE, reason="tree-sitter-python not available")
    def test_python_module_level_with_comments_and_imports(self):
        """Test extracting from Python file with comments and imports."""
        source = '''
# Comment
import os
from typing import List

x = 5

class Test:
    pass
'''
        result = extract_structure(source, "test.py")
        assert result is not None
        # Should have the variable and class
        assert len(result.children) == 2
        assert result.children[0].name == "x"
        assert result.children[0].node_type == NodeType.VARIABLE
        assert result.children[1].name == "Test"
        assert result.children[1].node_type == NodeType.CLASS
