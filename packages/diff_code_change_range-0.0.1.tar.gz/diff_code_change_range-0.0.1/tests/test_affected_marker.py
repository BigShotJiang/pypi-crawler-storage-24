"""Unit tests for affected marker module."""

import pytest
from diff_code_change_range.affected_marker import (
    mark_affected_nodes, _line_range_intersects, _filter_affected_nodes,
    process_file_change
)
from diff_code_change_range.structure_extractor import CodeNode, NodeType
from diff_code_change_range.diff_parser import FileChange


class TestLineRangeIntersects:
    """Tests for _line_range_intersects function."""

    def test_intersects_single_line(self):
        """Test intersection with single changed line."""
        assert _line_range_intersects((1, 5), {3}) is True

    def test_intersects_multiple_lines(self):
        """Test intersection with multiple changed lines."""
        assert _line_range_intersects((1, 5), {1, 2, 6}) is True

    def test_no_intersection_before(self):
        """Test no intersection when changed lines are before range."""
        assert _line_range_intersects((5, 10), {1, 2, 3}) is False

    def test_no_intersection_after(self):
        """Test no intersection when changed lines are after range."""
        assert _line_range_intersects((1, 5), {6, 7, 8}) is False

    def test_exact_match(self):
        """Test exact line match."""
        assert _line_range_intersects((5, 5), {5}) is True

    def test_range_covers_changes(self):
        """Test when node range fully covers changed lines."""
        assert _line_range_intersects((1, 10), {3, 5, 7}) is True


class TestMarkAffectedNodes:
    """Tests for mark_affected_nodes function."""

    def test_none_structure_returns_none(self):
        """Test that None structure returns None."""
        fc = FileChange(source_path="Test.java", target_path="Test.java")
        result = mark_affected_nodes(None, fc, is_before=True)
        assert result is None

    def test_pure_added_file_marks_all_affected(self):
        """Test pure added file marks all nodes affected."""
        fc = FileChange(
            source_path=None,
            target_path="Test.java",
            is_added=True,
            is_removed=False
        )
        method = CodeNode("method", NodeType.METHOD, (5, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method])
        
        result = mark_affected_nodes(cls, fc, is_before=False)
        assert result is not None
        assert result.is_affected is True
        assert result.children[0].is_affected is True

    def test_pure_deleted_file_marks_all_affected(self):
        """Test pure deleted file marks all nodes affected."""
        fc = FileChange(
            source_path="Test.java",
            target_path=None,
            is_added=False,
            is_removed=True
        )
        method = CodeNode("method", NodeType.METHOD, (5, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method])
        
        result = mark_affected_nodes(cls, fc, is_before=True)
        assert result is not None
        assert result.is_affected is True
        assert result.children[0].is_affected is True

    def test_modified_file_affects_leaf_node(self):
        """Test that intersecting leaf node is marked affected."""
        fc = FileChange(
            source_path="Test.java",
            target_path="Test.java",
            changed_old_lines={5, 6, 7}
        )
        method = CodeNode("method", NodeType.METHOD, (5, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method])
        
        result = mark_affected_nodes(cls, fc, is_before=True)
        assert result is not None
        assert result.is_affected is True
        assert len(result.children) == 1
        assert result.children[0].name == "method"

    def test_modified_file_removes_unaffected_leaf(self):
        """Test that non-intersecting leaf node is removed."""
        fc = FileChange(
            source_path="Test.java",
            target_path="Test.java",
            changed_old_lines={20, 21}  # Outside method range
        )
        method = CodeNode("method", NodeType.METHOD, (5, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method])
        
        result = mark_affected_nodes(cls, fc, is_before=True)
        # Class itself might still be affected if its line range intersects
        # But in this case it shouldn't be
        assert result is None

    def test_container_affected_when_child_affected(self):
        """Test container is affected when any child is affected."""
        fc = FileChange(
            source_path="Test.java",
            target_path="Test.java",
            changed_old_lines={6}  # Inside method2
        )
        method1 = CodeNode("method1", NodeType.METHOD, (5, 5))
        method2 = CodeNode("method2", NodeType.METHOD, (6, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method1, method2])
        
        result = mark_affected_nodes(cls, fc, is_before=True)
        assert result is not None
        assert result.is_affected is True
        # Only method2 should be in children
        assert len(result.children) == 1
        assert result.children[0].name == "method2"

    def test_multiple_levels_of_nesting(self):
        """Test propagation through multiple levels of nesting."""
        fc = FileChange(
            source_path="Test.java",
            target_path="Test.java",
            changed_old_lines={8}  # Inside inner method
        )
        inner_method = CodeNode("innerMethod", NodeType.METHOD, (8, 12))
        inner_class = CodeNode("Inner", NodeType.CLASS, (5, 15), [inner_method])
        outer_method = CodeNode("outerMethod", NodeType.METHOD, (20, 25))
        outer_class = CodeNode("Outer", NodeType.CLASS, (1, 30), [inner_class, outer_method])
        
        result = mark_affected_nodes(outer_class, fc, is_before=True)
        assert result is not None
        assert result.name == "Outer"
        # Should only have inner_class as affected child
        assert len(result.children) == 1
        assert result.children[0].name == "Inner"
        assert result.children[0].children[0].name == "innerMethod"

    def test_no_affected_nodes_returns_none(self):
        """Test that no affected nodes returns None."""
        fc = FileChange(
            source_path="Test.java",
            target_path="Test.java",
            changed_old_lines={100}  # Way outside all ranges
        )
        method = CodeNode("method", NodeType.METHOD, (5, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method])
        
        result = mark_affected_nodes(cls, fc, is_before=True)
        assert result is None

    def test_before_and_after_use_different_lines(self):
        """Test that before uses changed_old_lines and after uses changed_new_lines."""
        fc = FileChange(
            source_path="Test.java",
            target_path="Test.java",
            changed_old_lines={5},  # Old version had change at line 5
            changed_new_lines={20}  # New version has change at line 20
        )
        method = CodeNode("method", NodeType.METHOD, (5, 10))
        cls = CodeNode("Test", NodeType.CLASS, (1, 15), [method])
        
        # Before should match line 5
        before_result = mark_affected_nodes(cls, fc, is_before=True)
        assert before_result is not None
        
        # After uses different lines - should not match
        after_result = mark_affected_nodes(cls, fc, is_before=False)
        assert after_result is None


class TestCodeNode:
    """Additional tests for CodeNode with affected status."""

    def test_node_default_not_affected(self):
        """Test that nodes are not affected by default."""
        node = CodeNode("test", NodeType.METHOD, (1, 5))
        assert node.is_affected is False

    def test_node_can_set_affected(self):
        """Test that nodes can be marked as affected."""
        node = CodeNode("test", NodeType.METHOD, (1, 5), is_affected=True)
        assert node.is_affected is True

    def test_empty_children_list(self):
        """Test that leaf nodes have empty children by default."""
        node = CodeNode("test", NodeType.METHOD, (1, 5))
        assert node.children == []
