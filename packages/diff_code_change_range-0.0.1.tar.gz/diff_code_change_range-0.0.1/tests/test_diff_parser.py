"""Unit tests for diff parser module."""

import pytest
from diff_code_change_range.diff_parser import parse_diff, FileChange


class TestParseDiff:
    """Tests for parse_diff function."""

    def test_empty_diff(self):
        """Test parsing empty diff returns empty list."""
        result = parse_diff("")
        assert result == []

    def test_whitespace_only_diff(self):
        """Test parsing whitespace-only diff returns empty list."""
        result = parse_diff("   \n\n  ")
        assert result == []

    def test_added_java_file(self):
        """Test parsing diff with added Java file."""
        diff_text = '''diff --git a/src/Main.java b/src/Main.java
new file mode 100644
index 0000000..1234567
--- /dev/null
+++ b/src/Main.java
@@ -0,0 +1,5 @@
+public class Main {
+    public static void main(String[] args) {
+        System.out.println("Hello");
+    }
+}
'''
        result = parse_diff(diff_text)
        assert len(result) == 1
        assert result[0].source_path is None
        assert result[0].target_path == "src/Main.java"
        assert result[0].is_added is True
        assert result[0].is_removed is False
        assert "public class Main" in result[0].new_source
        assert result[0].changed_new_lines == {1, 2, 3, 4, 5}

    def test_deleted_java_file(self):
        """Test parsing diff with deleted Java file."""
        diff_text = '''diff --git a/src/Old.java b/src/Old.java
deleted file mode 100644
index 1234567..0000000
--- a/src/Old.java
+++ /dev/null
@@ -1,3 +0,0 @@
-public class Old {
-    private int value;
-}
'''
        result = parse_diff(diff_text)
        assert len(result) == 1
        assert result[0].source_path == "src/Old.java"
        assert result[0].target_path is None
        assert result[0].is_added is False
        assert result[0].is_removed is True
        assert "public class Old" in result[0].old_source
        assert result[0].changed_old_lines == {1, 2, 3}

    def test_modified_java_file(self):
        """Test parsing diff with modified Java file."""
        diff_text = '''diff --git a/src/Main.java b/src/Main.java
index abc123..def456 100644
--- a/src/Main.java
+++ b/src/Main.java
@@ -1,5 +1,5 @@
 public class Main {
     public static void main(String[] args) {
-        System.out.println("Hello");
+        System.out.println("World");
     }
 }
'''
        result = parse_diff(diff_text)
        assert len(result) == 1
        assert result[0].source_path == "src/Main.java"
        assert result[0].target_path == "src/Main.java"
        assert result[0].is_added is False
        assert result[0].is_removed is False
        # The deleted line was line 3 in old source
        assert 3 in result[0].changed_old_lines
        # The added line was line 3 in new source
        assert 3 in result[0].changed_new_lines

    def test_renamed_java_file(self):
        """Test parsing diff with renamed Java file."""
        diff_text = '''diff --git a/src/OldName.java b/src/NewName.java
similarity index 100%
rename from src/OldName.java
rename to src/NewName.java
'''
        result = parse_diff(diff_text)
        assert len(result) == 1
        assert result[0].is_renamed is True
        assert result[0].source_path == "src/OldName.java"
        assert result[0].target_path == "src/NewName.java"

    def test_skips_non_java_kt_files(self):
        """Test that non-Java/Kotlin/Python files are skipped."""
        diff_text = '''diff --git a/README.md b/README.md
index abc123..def456 100644
--- a/README.md
+++ b/README.md
@@ -1 +1 @@
-Old content
+New content
'''
        result = parse_diff(diff_text)
        assert result == []

    def test_python_file(self):
        """Test parsing diff with Python file."""
        diff_text = '''diff --git a/src/main.py b/src/main.py
new file mode 100644
index 0000000..1234567
--- /dev/null
+++ b/src/main.py
@@ -0,0 +1,3 @@
+def main():
+    print("Hello")
+
'''
        result = parse_diff(diff_text)
        assert len(result) == 1
        assert result[0].target_path == "src/main.py"
        assert "def main()" in result[0].new_source

    def test_skips_binary_files(self):
        """Test that binary files are skipped with warning."""
        diff_text = '''diff --git a/image.png b/image.png
Binary files differ
'''
        # Binary files without hunks should be skipped
        result = parse_diff(diff_text)
        # This should return empty since it's a binary file
        assert len(result) == 0 or result[0].old_source == ""

    def test_kotlin_file(self):
        """Test parsing diff with Kotlin file."""
        diff_text = '''diff --git a/src/Main.kt b/src/Main.kt
new file mode 100644
index 0000000..1234567
--- /dev/null
+++ b/src/Main.kt
@@ -0,0 +1,3 @@
+fun main() {
+    println("Hello")
+}
'''
        result = parse_diff(diff_text)
        assert len(result) == 1
        assert result[0].target_path == "src/Main.kt"
        assert "fun main()" in result[0].new_source

    def test_multiple_files(self):
        """Test parsing diff with multiple files."""
        diff_text = '''diff --git a/src/A.java b/src/A.java
index abc123..def456 100644
--- a/src/A.java
+++ b/src/A.java
@@ -1 +1 @@
-old
+new

diff --git a/src/B.java b/src/B.java
index 123abc..456def 100644
--- a/src/B.java
+++ b/src/B.java
@@ -1 +1 @@
-foo
+bar
'''
        result = parse_diff(diff_text)
        assert len(result) == 2
        assert "A.java" in result[0].source_path
        assert "B.java" in result[1].source_path


class TestFileChange:
    """Tests for FileChange dataclass."""

    def test_file_change_creation(self):
        """Test FileChange can be created with all fields."""
        fc = FileChange(
            source_path="src/Old.java",
            target_path="src/New.java",
            old_source="old code",
            new_source="new code",
            changed_old_lines={1, 2},
            changed_new_lines={3, 4},
            is_added=False,
            is_removed=False,
            is_renamed=True
        )
        assert fc.source_path == "src/Old.java"
        assert fc.target_path == "src/New.java"
        assert fc.old_source == "old code"
        assert fc.new_source == "new code"
        assert fc.changed_old_lines == {1, 2}
        assert fc.changed_new_lines == {3, 4}
        assert fc.is_renamed is True

    def test_file_change_defaults(self):
        """Test FileChange has correct defaults."""
        fc = FileChange(source_path="test.java", target_path="test.java")
        assert fc.old_source == ""
        assert fc.new_source == ""
        assert fc.changed_old_lines == set()
        assert fc.changed_new_lines == set()
        assert fc.is_added is False
        assert fc.is_removed is False
        assert fc.is_renamed is False
