"""
保险客户分析器 - 基于CoT思维链的客户价值评估
"""
import json
import logging
from datetime import datetime
from typing import Dict, Any, Optional, List

logger = logging.getLogger("insurance-analysis-mcp")


class InsuranceCustomerAnalyzer:
    """保险客户分析器，使用CoT思维链进行客户价值评估"""

    # 支持的日期格式列表
    DATE_FORMATS = [
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
    ]

    def __init__(self):
        pass

    # =========================================================
    # 公共工具方法
    # =========================================================

    @staticmethod
    def _ensure_dict(value: Any, field_name: str) -> Optional[Dict]:
        """
        安全地将参数转换为 dict 类型
        支持：已是dict / JSON字符串 / None
        """
        if value is None:
            return None
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            value = value.strip()
            if not value:
                return None
            try:
                parsed = json.loads(value)
                if isinstance(parsed, dict):
                    logger.warning(f"⚠️ {field_name} 收到 JSON 字符串，已自动转换为 dict")
                    return parsed
                raise ValueError(
                    f"{field_name} 解析后不是对象类型，实际类型: {type(parsed).__name__}"
                )
            except json.JSONDecodeError as e:
                raise ValueError(f"{field_name} 不是合法的 JSON 字符串: {e}")
        raise ValueError(
            f"{field_name} 类型不支持: 期望 dict 或 JSON字符串，实际收到 {type(value).__name__}"
        )

    @staticmethod
    def _ensure_list(value: Any, field_name: str) -> List:
        """
        安全地将参数转换为 list 类型
        支持：已是list / JSON字符串 / None / dict（单条记录自动包装）
        """
        if value is None:
            return []
        if isinstance(value, list):
            return value
        if isinstance(value, dict):
            logger.warning(f"⚠️ {field_name} 收到 dict，已自动包装为 list")
            return [value]
        if isinstance(value, str):
            value = value.strip()
            if not value:
                return []
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    logger.warning(f"⚠️ {field_name} 收到 JSON 字符串，已自动转换为 list")
                    return parsed
                if isinstance(parsed, dict):
                    logger.warning(f"⚠️ {field_name} 收到 JSON 对象字符串，已自动包装为 list")
                    return [parsed]
                raise ValueError(
                    f"{field_name} 解析后类型不支持: {type(parsed).__name__}"
                )
            except json.JSONDecodeError as e:
                raise ValueError(f"{field_name} 不是合法的 JSON 字符串: {e}")
        raise ValueError(
            f"{field_name} 类型不支持: 期望 list 或 JSON字符串，实际收到 {type(value).__name__}"
        )

    @classmethod
    def _parse_date(cls, value: Any, field_name: str = "date") -> Optional[datetime]:
        """
        安全地将各种类型的日期值解析为 datetime 对象
        支持：datetime对象 / 日期字符串 / None
        """
        if value is None:
            return None
        if isinstance(value, datetime):
            return value

        # 兼容 date 对象
        if hasattr(value, 'year') and hasattr(value, 'month') and hasattr(value, 'day'):
            try:
                return datetime(value.year, value.month, value.day)
            except Exception:
                pass

        if isinstance(value, str):
            value = value.strip()
            if not value:
                return None
            for fmt in cls.DATE_FORMATS:
                try:
                    return datetime.strptime(value, fmt)
                except ValueError:
                    continue
            logger.warning(f"⚠️ {field_name} 无法解析日期字符串: '{value}'，已忽略")
            return None

        logger.warning(f"⚠️ {field_name} 类型不支持日期解析: {type(value).__name__}，已忽略")
        return None

    # =========================================================
    # 核心分析方法
    # =========================================================

    async def analyze_customer_retention_value(
        self,
        customer_data: Dict[str, Any],
        policy_data: Optional[Any] = None,
        claim_data: Optional[Any] = None
    ) -> str:
        """
        分析客户挽回价值和续保概率

        Args:
            customer_data: 客户基本信息 {customer_id, name, level, total_premium, registration_date等}
            policy_data:   保单信息列表（支持 list / JSON字符串 / 单条dict）
            claim_data:    理赔记录列表（支持 list / JSON字符串 / 单条dict）

        Returns:
            JSON格式的分析结果
        """
        try:
            # ✅ 入口参数类型安全转换
            customer_data = self._ensure_dict(customer_data, "customer_data")
            policies: List[Dict] = self._ensure_list(policy_data, "policy_data")
            claims: List[Dict] = self._ensure_list(claim_data, "claim_data")

            # ---- Step 1：需求理解 ----
            analysis_steps = {
                "step_1_understanding": {
                    "purpose": "分析客户是否值得重点挽留",
                    "key_metrics_to_evaluate": [
                        "客户价值贡献",
                        "风险水平评估",
                        "客户粘性分析",
                        "未来潜力预测"
                    ]
                }
            }

            # ---- Step 2：数据收集与整理 ----
            # ✅ 日期统一解析
            reg_date = self._parse_date(
                customer_data.get("registration_date"), "registration_date"
            )
            registration_days = (datetime.now() - reg_date).days if reg_date else 0

            metrics = self._calculate_key_metrics(customer_data, policies, claims, reg_date)

            analysis_steps["step_2_data_collection"] = {
                "customer_info_summary": {
                    "name": customer_data.get("name"),
                    "level": customer_data.get("level", "Unknown"),
                    "total_premium": customer_data.get("total_premium", 0),
                    "registration_days": registration_days,
                },
                "policy_count": len(policies),
                "claim_count": len(claims),
                "calculated_metrics": metrics,
            }

            # ---- Step 3：多维度分析 ----
            value_assessment = self._assess_value(metrics)
            risk_assessment = self._assess_risk(metrics)
            loyalty_assessment = self._assess_loyalty(metrics)
            potential_assessment = self._assess_potential(metrics)

            analysis_steps["step_3_multi_dimension_analysis"] = {
                "value_assessment": value_assessment,
                "risk_assessment": risk_assessment,
                "loyalty_assessment": loyalty_assessment,
                "potential_assessment": potential_assessment,
            }

            # ---- Step 4：综合判断 ----
            overall_score, retention_recommendation, confidence = self._overall_judgment(
                value_assessment, risk_assessment, loyalty_assessment, potential_assessment
            )

            analysis_steps["step_4_comprehensive_judgement"] = {
                "overall_score": overall_score,
                "retention_recommendation": retention_recommendation,
                "confidence_level": confidence,
                "supporting_reasons": self._generate_supporting_reasons(
                    value_assessment, risk_assessment, loyalty_assessment, potential_assessment
                ),
                "risk_factors": self._identify_risk_factors(metrics),
            }

            # ---- Step 5：行动建议 ----
            action_suggestions = self._generate_action_suggestions(
                retention_recommendation, metrics, customer_data
            )
            analysis_steps["step_5_action_suggestions"] = action_suggestions

            # ---- 构建最终结果 ----
            result = {
                "customer_id": customer_data.get("customer_id"),
                "analysis_process": analysis_steps,
                "final_recommendation": {
                    "retention_priority": retention_recommendation,
                    "estimated_retention_probability": f"{int(overall_score * 10)}%",
                    "overall_confidence": confidence,
                    "summary_scorecard": {
                        "value_contribution": value_assessment.get("score"),
                        "risk_level": risk_assessment.get("score"),
                        "customer_loyalty": loyalty_assessment.get("score"),
                        "future_potential": potential_assessment.get("score"),
                        "composite_score": overall_score,
                    },
                },
            }

            return json.dumps(result, ensure_ascii=False, indent=2, default=str)

        except Exception as e:
            logger.error(f"analyze_customer_retention_value 发生异常: {e}", exc_info=True)
            error_result = {
                "error": str(e),
                "success": False,
                "customer_id": (
                    customer_data.get("customer_id")
                    if isinstance(customer_data, dict)
                    else "unknown"
                ),
            }
            return json.dumps(error_result, ensure_ascii=False, indent=2)

    # =========================================================
    # 指标计算
    # =========================================================

    def _calculate_key_metrics(
        self,
        customer_info: Dict,
        policies: List[Dict],
        claims: List[Dict],
        reg_date: Optional[datetime] = None,  # ✅ 已解析好的datetime，不再重复解析
    ) -> Dict[str, Any]:
        """计算关键指标"""

        total_premium = customer_info.get("total_premium", 0) or 0

        # 客户年限
        years_as_customer = 0.0
        if reg_date:
            years_as_customer = max((datetime.now() - reg_date).days / 365.25, 0.0)

        annualized_premium = total_premium / max(years_as_customer, 0.1)

        # ✅ 防御：claims 中每个元素必须是 dict
        safe_claims = [c for c in claims if isinstance(c, dict)]
        total_claim_amount = sum(c.get("claim_amount", 0) or 0 for c in safe_claims)
        claim_frequency = len(safe_claims) / max(years_as_customer, 0.1)
        claim_rate = total_claim_amount / max(total_premium, 1)

        # ✅ 防御：policies 中每个元素必须是 dict
        safe_policies = [p for p in policies if isinstance(p, dict)]
        policy_types = {p.get("policy_type", "") for p in safe_policies if p.get("policy_type")}
        policy_diversity = len(policy_types)

        # 即将到期保单（30天内）
        expiring_policies = 0
        current_date = datetime.now()
        for policy in safe_policies:
            end_date = self._parse_date(policy.get("end_date"), "policy.end_date")  # ✅ 统一日期解析
            if end_date:
                days_to_expire = (end_date.date() - current_date.date()).days
                if 0 <= days_to_expire <= 30:
                    expiring_policies += 1

        return {
            "annualized_premium": annualized_premium,
            "years_as_customer": years_as_customer,
            "total_claim_amount": total_claim_amount,
            "claim_frequency": claim_frequency,
            "claim_rate": claim_rate,
            "policy_count": len(safe_policies),
            "policy_diversity": policy_diversity,
            "expiring_policies": expiring_policies,
            "vip_status": str(customer_info.get("level", "")).lower() == "vip",  # ✅ 防止level为None
        }

    # =========================================================
    # 维度评估（逻辑不变，保持原样）
    # =========================================================

    def _assess_value(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """价值贡献评估"""
        score = 0
        factors = []

        if metrics["annualized_premium"] >= 50000:
            score += 10
            factors.append("年化保费≥5万，高价值客户")
        elif metrics["annualized_premium"] >= 20000:
            score += 8
            factors.append("年化保费≥2万，中高价值客户")
        elif metrics["annualized_premium"] >= 5000:
            score += 5
            factors.append("年化保费≥5千，中等价值客户")
        else:
            score += 2
            factors.append("年化保费较低")

        if metrics["vip_status"]:
            score += 3
            factors.append("VIP客户身份")

        if metrics["policy_count"] >= 3:
            score += 2
            factors.append(f"持有{metrics['policy_count']}份保单，交叉销售成功")

        return {
            "dimension": "价值贡献",
            "score": min(score, 10),
            "factors": factors,
            "interpretation": "高价值客户对公司的收入贡献大，是重要的利润来源",
        }

    def _assess_risk(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """风险水平评估"""
        score = 10
        factors = []

        if metrics["claim_rate"] > 0.5:
            score -= 6
            factors.append(f"理赔率{metrics['claim_rate']:.2%}过高，高风险")
        elif metrics["claim_rate"] > 0.2:
            score -= 4
            factors.append(f"理赔率{metrics['claim_rate']:.2%}偏高")
        elif metrics["claim_rate"] > 0.1:
            score -= 2
            factors.append(f"理赔率{metrics['claim_rate']:.2%}适中")
        else:
            factors.append(f"理赔率{metrics['claim_rate']:.2%}很低，低风险")

        if metrics["claim_frequency"] > 2:
            score -= 3
            factors.append(f"年均理赔{metrics['claim_frequency']:.1f}次，频率较高")
        elif metrics["claim_frequency"] > 1:
            score -= 1
            factors.append(f"年均理赔{metrics['claim_frequency']:.1f}次，频率适中")
        else:
            score += 1
            factors.append(f"年均理赔{metrics['claim_frequency']:.1f}次，频率很低")

        return {
            "dimension": "风险水平",
            "score": max(min(score, 10), 1),  # ✅ 同时限制上限和下限
            "factors": factors,
            "interpretation": "低风险客户对公司财务稳定性有利",
        }

    def _assess_loyalty(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """客户忠诚度评估"""
        score = 0
        factors = []

        if metrics["years_as_customer"] >= 5:
            score += 5
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，忠诚度很高")
        elif metrics["years_as_customer"] >= 3:
            score += 4
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，忠诚度较高")
        elif metrics["years_as_customer"] >= 1:
            score += 3
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，有一定忠诚度")
        else:
            score += 1
            factors.append(f"合作{metrics['years_as_customer']:.1f}年，新客户")

        if metrics["policy_diversity"] >= 3:
            score += 3
            factors.append(f"购买{metrics['policy_diversity']}种不同类型保单，依赖度高")
        elif metrics["policy_diversity"] >= 2:
            score += 2
            factors.append(f"购买{metrics['policy_diversity']}种不同类型保单")
        elif metrics["policy_diversity"] >= 1:
            score += 1
            factors.append(f"购买{metrics['policy_diversity']}种保单")

        if metrics["vip_status"]:
            score += 2
            factors.append("VIP客户通常流失率更低")

        return {
            "dimension": "客户忠诚度",
            "score": min(score, 10),
            "factors": factors,
            "interpretation": "忠诚客户更有可能续保和推荐他人",
        }

    def _assess_potential(self, metrics: Dict[str, Any]) -> Dict[str, Any]:
        """未来发展潜力评估"""
        score = 0
        factors = []

        if metrics["annualized_premium"] >= 50000:
            score += 4
            factors.append("当前高价值客户，增长空间大")
        elif metrics["annualized_premium"] >= 20000:
            score += 3
            factors.append("当前中高价值客户，有提升空间")
        elif metrics["annualized_premium"] >= 5000:
            score += 2
            factors.append("当前中等价值客户，可进一步挖掘")
        else:
            score += 1
            factors.append("当前价值一般，但有发展潜力")

        if metrics["policy_diversity"] >= 3:
            score += 3
            factors.append("已购买多种产品，接受新产品意愿高")
        elif metrics["policy_diversity"] >= 2:
            score += 2
            factors.append("已购买多种产品，交叉销售机会多")
        else:
            score += 1
            factors.append("有机会推广更多产品类型")

        if metrics["expiring_policies"] > 0:
            score += 3
            factors.append(f"有{metrics['expiring_policies']}份保单即将到期，续保机会明确")

        return {
            "dimension": "未来发展潜力",
            "score": min(score, 10),
            "factors": factors,
            "interpretation": "高潜力客户有望带来更多的长期价值",
        }

    # =========================================================
    # 综合判断
    # =========================================================

    def _overall_judgment(
        self,
        value_assessment: Dict,
        risk_assessment: Dict,
        loyalty_assessment: Dict,
        potential_assessment: Dict,
    ) -> tuple:
        """综合判断"""
        weights = [0.25, 0.25, 0.25, 0.25]
        scores = [
            value_assessment.get("score", 0),
            risk_assessment.get("score", 0),
            loyalty_assessment.get("score", 0),
            potential_assessment.get("score", 0),
        ]

        composite_score = sum(w * s for w, s in zip(weights, scores))

        if composite_score >= 8.0:
            recommendation = "重点挽留"
            confidence = "高"
        elif composite_score >= 6.0:
            recommendation = "建议挽留"
            confidence = "中"
        elif composite_score >= 4.0:
            recommendation = "选择性挽留"
            confidence = "中"
        else:
            recommendation = "不建议重点挽留"
            confidence = "高"

        return composite_score, recommendation, confidence

    # =========================================================
    # 辅助生成方法
    # =========================================================

    def _generate_supporting_reasons(
        self,
        value_assessment: Dict,
        risk_assessment: Dict,
        loyalty_assessment: Dict,
        potential_assessment: Dict,
    ) -> Dict[str, list]:
        """生成支持理由"""
        reasons: Dict[str, list] = {
            "positive_indicators": [],
            "negative_indicators": [],
        }

        assessments = [value_assessment, risk_assessment, loyalty_assessment, potential_assessment]

        for assessment in assessments:
            factors = assessment.get("factors", [])
            score = assessment.get("score", 0)
            if not factors:          # ✅ 防止 factors 为空导致 IndexError
                continue
            if score >= 7:
                reasons["positive_indicators"].append(factors[0])
            elif score <= 4:
                reasons["negative_indicators"].append(factors[0])

        return reasons

    def _identify_risk_factors(self, metrics: Dict[str, Any]) -> List[str]:
        """识别风险因素"""
        risks = []

        if metrics["claim_rate"] > 0.3:
            risks.append(f"理赔率过高（{metrics['claim_rate']:.2%}）")  # ✅ 附上具体数值
        if metrics["claim_frequency"] > 3:
            risks.append(f"理赔频次过高（年均{metrics['claim_frequency']:.1f}次）")
        if metrics["annualized_premium"] < 1000:
            risks.append(f"价值贡献过低（年化保费{metrics['annualized_premium']:.0f}元）")

        return risks

    def _generate_action_suggestions(
        self,
        recommendation: str,
        metrics: Dict,
        customer_info: Dict,
    ) -> Dict[str, Any]:
        """生成行动建议"""
        suggestions: Dict[str, Any] = {
            "priority_actions": [],
            "follow_up_schedule": {},
            "roi_estimate": {},
        }

        if recommendation in ["重点挽留", "建议挽留"]:

            if metrics["expiring_policies"] > 0:
                suggestions["priority_actions"].append({
                    "action": "紧急联系客户办理续保",
                    "urgency": "高",
                    "target": f"处理{metrics['expiring_policies']}份即将到期的保单",
                })

            discount_estimate = min(int(metrics["annualized_premium"] * 0.05), 2000)
            suggestions["priority_actions"].append({
                "action": "提供续保优惠政策",
                "detail": f"建议给予5%左右折扣，约{discount_estimate}元优惠",
                "expected_outcome": "提高续保可能性",
            })

            suggestions["priority_actions"].append({
                "action": "提供VIP增值服务",
                "detail": "如免费体检、专属客服等",
                "expected_outcome": "增强客户粘性",
            })

            suggestions["follow_up_schedule"] = {
                "first_contact": "1-3天内",
                "follow_up_reminder": "一周后",
                "final_attempt": "两周内完成",
            }

            # ✅ 修复：years_as_customer 可能为0，ROI计算需保护
            years = max(metrics["years_as_customer"], 1.0)
            expected_retained_premium = metrics["annualized_premium"] * years * 0.7
            cost_of_retention = discount_estimate + 1000
            estimated_roi = (
                (expected_retained_premium - cost_of_retention) / cost_of_retention
                if cost_of_retention > 0
                else 0
            )

            suggestions["roi_estimate"] = {
                "expected_retained_value": round(expected_retained_premium, 2),
                "cost_of_retention": cost_of_retention,
                "estimated_roi_ratio": f"{estimated_roi:.1f}:1",
            }

        else:
            suggestions["priority_actions"].append({
                "action": "保持基本联系",
                "detail": "定期发送公司动态和优惠信息",
                "urgency": "低",
            })
            suggestions["follow_up_schedule"] = {
                "check_in_interval": "季度一次",
            }

        if metrics["policy_diversity"] < 3:
            suggestions["priority_actions"].append({
                "action": "探索交叉销售机会",
                "detail": "推荐其他适合的产品线",
                "potential_value": "预计可增加20-30%保费",
            })

        return suggestions
