"""LowHum — macOS menu-bar application for brown noise playback."""

from __future__ import annotations

import atexit
import fcntl
import importlib.metadata
import json
import os
import shutil
import sys
import threading
import urllib.request
from pathlib import Path

import rumps
import sounddevice as sd
import tomllib

from .audio import AudioPlayer, is_builtin_speaker, list_output_devices
from .generator import (
    DATA_DIR,
    BrainwaveBand,
    NoiseColor,
    SoundMode,
    audio_file,
    binaural_audio_file,
    soundscape_file,
)
from .icons import ensure_template_icon
from .resources import app_icon_path

_APP_ICON = app_icon_path()
_CONFIG_FILE = DATA_DIR / "config.toml"
_LOCK_FILE = DATA_DIR / "lowhum.lock"
_LAUNCH_AGENTS = Path.home() / "Library" / "LaunchAgents"
_PLIST = _LAUNCH_AGENTS / "com.lowhum.app.plist"

_PLIST_TEMPLATE = """\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.lowhum.app</string>
  <key>ProgramArguments</key>
  <array>
    <string>{binary}</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
</dict>
</plist>
"""

_TIMER_PRESETS = [25, 50, 90]


def _find_binary() -> str:
    for name in ("lhm", "lowhum"):
        found = shutil.which(name)
        if found:
            return found
    return sys.argv[0]


def _load_config() -> dict:
    if not _CONFIG_FILE.exists():
        return {}
    try:
        with open(_CONFIG_FILE, "rb") as f:
            return tomllib.load(f)
    except Exception:
        return {}


def _save_config(
    device: int | None,
    color: NoiseColor,
    volume: float,
    binaural_band: BrainwaveBand | None = None,
    sound_mode: SoundMode | None = None,
    show_in_dock: bool = False,
    block_speakers: bool = False,
    timer_mins: int | None = None,
) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    lines = ["[audio]\n"]
    if device is not None:
        lines.append(f"device = {device}\n")
    lines.append(f'noise_color = "{color.value}"\n')
    lines.append(f"volume = {volume:.2f}\n")
    if binaural_band is not None:
        lines.append(f'binaural_band = "{binaural_band.value}"\n')
    if sound_mode is not None:
        lines.append(f'sound_mode = "{sound_mode.value}"\n')
    lines.append(f"block_speakers = {'true' if block_speakers else 'false'}\n")
    if timer_mins is not None:
        lines.append(f"timer_minutes = {timer_mins}\n")
    dock_val = "true" if show_in_dock else "false"
    lines.append(f"\n[ui]\nshow_in_dock = {dock_val}\n")
    _CONFIG_FILE.write_text("".join(lines))


def _login_item_active() -> bool:
    return _PLIST.exists()


def _set_login_item(enabled: bool) -> None:
    if enabled:
        _LAUNCH_AGENTS.mkdir(parents=True, exist_ok=True)
        _PLIST.write_text(_PLIST_TEMPLATE.format(binary=_find_binary()))
    else:
        _PLIST.unlink(missing_ok=True)


def _set_dock_icon() -> None:
    if not _APP_ICON.exists():
        return
    try:
        from AppKit import (  # type: ignore[import-untyped]
            NSApplication,
            NSImage,
        )

        ns_image = NSImage.alloc().initByReferencingFile_(str(_APP_ICON))
        NSApplication.sharedApplication().setApplicationIconImage_(ns_image)
    except ImportError:
        pass


def _set_activation_policy(show_in_dock: bool) -> None:
    """Toggle dock icon visibility via NSApplication activation policy.

    0 = NSApplicationActivationPolicyRegular (dock visible)
    1 = NSApplicationActivationPolicyAccessory (no dock icon)
    """
    try:
        from AppKit import NSApplication  # type: ignore[import-untyped]

        policy = 0 if show_in_dock else 1
        NSApplication.sharedApplication().setActivationPolicy_(policy)
    except ImportError:
        pass


def _check_pypi_version() -> tuple[str | None, str]:
    """Query PyPI for the latest version. Returns (new_ver, message)."""
    try:
        installed = importlib.metadata.version("lowhum")
        req = urllib.request.Request(
            "https://pypi.org/pypi/lowhum/json",
            headers={"Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read())
        latest = data["info"]["version"]
        if _version_tuple(latest) > _version_tuple(installed):
            return latest, f"Update available: {latest} (you have {installed})"
        return None, f"Up to date ({installed})"
    except Exception as exc:
        return None, f"Check failed: {exc}"


def _version_tuple(v: str) -> tuple[int, ...]:
    return tuple(int(x) for x in v.split(".") if x.isdigit())


_lock_fd = None


def _acquire_lock() -> bool:
    """Try to grab an exclusive lock. Returns False if already running."""
    global _lock_fd
    _LOCK_FILE.parent.mkdir(parents=True, exist_ok=True)
    _lock_fd = open(_LOCK_FILE, "w")  # noqa: SIM115 - must stay open
    try:
        fcntl.flock(_lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        _lock_fd.write(str(os.getpid()))
        _lock_fd.flush()
        atexit.register(_release_lock)
        return True
    except OSError:
        _lock_fd.close()
        _lock_fd = None
        return False


def _release_lock() -> None:
    global _lock_fd
    if _lock_fd is not None:
        fcntl.flock(_lock_fd, fcntl.LOCK_UN)
        _lock_fd.close()
        _lock_fd = None
        _LOCK_FILE.unlink(missing_ok=True)


_BINAURAL_LABELS: dict[BrainwaveBand, str] = {
    BrainwaveBand.THETA: "Theta (6 Hz)",
    BrainwaveBand.ALPHA: "Alpha (10 Hz)",
    BrainwaveBand.BETA: "Beta (18 Hz)",
    BrainwaveBand.GAMMA: "Gamma (40 Hz)",
}

_SOUNDMODE_LABELS: dict[SoundMode, str] = {
    SoundMode.STUDY: "Study",
    SoundMode.FLOW: "Flow",
}


class LowHumApp(rumps.App):
    def __init__(
        self,
        autoplay: bool = False,
        force_no_dock: bool = False,
    ) -> None:
        if not _acquire_lock():
            print("LowHum is already running.")
            raise SystemExit(0)

        self._autoplay = autoplay

        icon_path = str(ensure_template_icon())
        super().__init__(  # type: ignore
            "LowHum", icon=icon_path, template=True, quit_button=None
        )
        self._player = AudioPlayer()
        self._known_device_names: set[str] = set()

        cfg = _load_config()
        audio_cfg = cfg.get("audio", {})
        ui_cfg = cfg.get("ui", {})

        raw_device = audio_cfg.get("device")
        self._selected_device: int | None = (
            int(raw_device) if raw_device is not None else None
        )
        try:
            self._noise_color = NoiseColor(
                audio_cfg.get("noise_color", "brown")
            )
        except ValueError:
            self._noise_color = NoiseColor.BROWN

        raw_band = audio_cfg.get("binaural_band")
        try:
            self._binaural_band: BrainwaveBand | None = (
                BrainwaveBand(raw_band) if raw_band else None
            )
        except ValueError:
            self._binaural_band = None

        raw_mode = audio_cfg.get("sound_mode")
        try:
            self._sound_mode: SoundMode | None = (
                SoundMode(raw_mode) if raw_mode else None
            )
        except ValueError:
            self._sound_mode = None

        self._volume: float = float(audio_cfg.get("volume", 1.0))
        self._player.volume = self._volume
        self._block_speakers: bool = bool(
            audio_cfg.get("block_speakers", False)
        )
        raw_timer = audio_cfg.get("timer_minutes")
        self._timer_mins: int | None = (
            int(raw_timer) if raw_timer is not None else None
        )
        self._show_in_dock: bool = (
            False if force_no_dock else bool(ui_cfg.get("show_in_dock", False))
        )
        _set_activation_policy(self._show_in_dock)
        if self._show_in_dock:
            _set_dock_icon()

        self._play_pause_item = rumps.MenuItem(
            "Play", callback=self._on_play_pause
        )
        self._stop_item = rumps.MenuItem("Stop", callback=self._on_stop)
        self._volume_slider = rumps.SliderMenuItem(
            value=self._volume * 100,
            min_value=0,
            max_value=100,
            callback=self._on_volume_slider,
        )
        self._color_menu = rumps.MenuItem("Noise Color")
        self._soundmode_menu = rumps.MenuItem("Soundscape")
        self._binaural_menu = rumps.MenuItem("Binaural Beats")
        self._device_menu = rumps.MenuItem("Output Device")
        self._timer_menu = rumps.MenuItem("Timer")
        self._block_speakers_item = rumps.MenuItem(
            "Block Built-in Speakers", callback=self._on_toggle_block_speakers
        )
        self._dock_item = rumps.MenuItem(
            "Show in Dock", callback=self._on_toggle_dock
        )
        self._login_item = rumps.MenuItem(
            "Launch at Login", callback=self._on_toggle_login
        )
        self._update_item = rumps.MenuItem(
            "Check for Updates", callback=self._on_check_updates
        )

        self.menu = [
            self._play_pause_item,
            self._stop_item,
            None,
            self._volume_slider,
            None,
            self._color_menu,
            self._soundmode_menu,
            self._binaural_menu,
            None,
            self._device_menu,
            self._timer_menu,
            self._block_speakers_item,
            None,
            self._dock_item,
            self._login_item,
            self._update_item,
            None,
            rumps.MenuItem("Quit", callback=self._on_quit),
        ]

        self._refresh_color_menu()
        self._refresh_soundmode_menu()
        self._refresh_binaural_menu()
        self._refresh_devices()
        self._refresh_timer_menu()
        self._login_item.state = _login_item_active()
        self._dock_item.state = self._show_in_dock
        self._block_speakers_item.state = self._block_speakers

        self._device_timer = rumps.Timer(self._check_devices, 2)
        self._device_timer.start()
        self._volume_save_timer: rumps.Timer | None = None
        self._stop_timer: rumps.Timer | None = None
        self._countdown_timer: rumps.Timer | None = None
        self._remaining_secs: int = 0

        if self._autoplay:
            self._play_active()

    def _halt(self, reason: str) -> None:
        self._player.stop()
        self._play_pause_item.title = "Play"
        self._cancel_stop_timer()
        rumps.notification("LowHum", "", reason)

    def _on_volume_slider(self, sender: rumps.SliderMenuItem) -> None:
        self._volume = round(sender.value / 100, 2)
        self._player.volume = self._volume
        if self._volume_save_timer is not None:
            self._volume_save_timer.stop()
        self._volume_save_timer = rumps.Timer(lambda _: self._persist(), 0.4)
        self._volume_save_timer.start()

    def _active_audio_file(self) -> Path:
        if self._sound_mode is not None:
            return soundscape_file(self._sound_mode)
        if self._binaural_band is not None:
            return binaural_audio_file(self._binaural_band, self._noise_color)
        return audio_file(self._noise_color)

    # Noise color

    def _refresh_color_menu(self) -> None:
        for key in list(self._color_menu.keys()):
            del self._color_menu[key]
        for color in NoiseColor:
            item = rumps.MenuItem(
                color.value.capitalize(),
                callback=lambda _, c=color: self._select_color(c),
            )
            item.state = color == self._noise_color and self._sound_mode is None
            self._color_menu[color.value] = item

    def _select_color(self, color: NoiseColor) -> None:
        was_playing = self._player.playing
        if was_playing:
            self._player.stop()
            self._play_pause_item.title = "Play"
        self._noise_color = color
        self._sound_mode = None
        self._refresh_color_menu()
        self._refresh_soundmode_menu()
        self._persist()
        if was_playing:
            self._play_active()

    # Soundscapes

    def _refresh_soundmode_menu(self) -> None:
        for key in list(self._soundmode_menu.keys()):
            del self._soundmode_menu[key]
        off = rumps.MenuItem(
            "Off", callback=lambda _: self._select_soundmode(None)
        )
        off.state = self._sound_mode is None
        self._soundmode_menu["Off"] = off
        for mode, label in _SOUNDMODE_LABELS.items():
            item = rumps.MenuItem(
                label,
                callback=lambda _, m=mode: self._select_soundmode(m),
            )
            item.state = mode == self._sound_mode
            self._soundmode_menu[label] = item

    def _select_soundmode(self, mode: SoundMode | None) -> None:
        was_playing = self._player.playing
        if was_playing:
            self._player.stop()
            self._play_pause_item.title = "Play"
        self._sound_mode = mode
        self._refresh_soundmode_menu()
        self._refresh_color_menu()
        self._persist()
        if was_playing:
            self._play_active()

    # Binaural beats

    def _refresh_binaural_menu(self) -> None:
        for key in list(self._binaural_menu.keys()):
            del self._binaural_menu[key]
        off = rumps.MenuItem(
            "Off", callback=lambda _: self._select_binaural(None)
        )
        off.state = self._binaural_band is None
        self._binaural_menu["Off"] = off
        for band, label in _BINAURAL_LABELS.items():
            item = rumps.MenuItem(
                label,
                callback=lambda _, b=band: self._select_binaural(b),
            )
            item.state = band == self._binaural_band
            self._binaural_menu[label] = item

    def _select_binaural(self, band: BrainwaveBand | None) -> None:
        was_playing = self._player.playing
        if was_playing:
            self._player.stop()
            self._play_pause_item.title = "Play"
        self._binaural_band = band
        if band is not None:
            self._sound_mode = None
            self._refresh_soundmode_menu()
        self._refresh_binaural_menu()
        self._persist()
        if was_playing:
            self._play_active()

    def _play_active(self) -> None:
        if self._block_speakers and is_builtin_speaker(self._selected_device):
            rumps.notification(
                "LowHum",
                "",
                "Playback blocked; built-in speakers are disabled.",
            )
            return
        self._player.play(
            self._active_audio_file(),
            device=self._selected_device,
            loop=True,
        )
        self._play_pause_item.title = "Pause"
        self._start_stop_timer()

    # Timer

    def _refresh_timer_menu(self) -> None:
        for key in list(self._timer_menu.keys()):
            del self._timer_menu[key]
        off = rumps.MenuItem("Off", callback=lambda _: self._set_timer(None))
        off.state = self._timer_mins is None
        self._timer_menu["Off"] = off
        for mins in _TIMER_PRESETS:
            item = rumps.MenuItem(
                f"{mins} min",
                callback=lambda _, m=mins: self._set_timer(m),
            )
            item.state = self._timer_mins == mins
            self._timer_menu[f"{mins} min"] = item

    def _set_timer(self, mins: int | None) -> None:
        self._timer_mins = mins
        self._refresh_timer_menu()
        self._persist()
        self._cancel_stop_timer()
        if mins is not None and self._player.playing:
            self._start_stop_timer()

    def _start_stop_timer(self) -> None:
        self._cancel_stop_timer()
        if self._timer_mins is None:
            return
        self._remaining_secs = self._timer_mins * 60

        def tick(_: rumps.Timer) -> None:
            self._remaining_secs -= 1
            if self._remaining_secs <= 0:
                self._cancel_stop_timer()
                self._player.stop()
                self._play_pause_item.title = "Play"
                rumps.notification("LowHum", "", "Focus session complete.")

        self._countdown_timer = rumps.Timer(tick, 1)
        self._countdown_timer.start()

    def _cancel_stop_timer(self) -> None:
        if self._countdown_timer is not None:
            self._countdown_timer.stop()
            self._countdown_timer = None

    # Device management

    def _refresh_devices(self) -> None:
        devices = list_output_devices()
        self._known_device_names = {name for _, name in devices}

        for key in list(self._device_menu.keys()):
            del self._device_menu[key]

        sys_item = rumps.MenuItem(
            "System Default",
            callback=lambda _: self._select_device(None),
        )
        sys_item.state = self._selected_device is None
        self._device_menu["System Default"] = sys_item

        for idx, name in devices:
            item = rumps.MenuItem(
                name,
                callback=lambda _, d=idx: self._select_device(d),
            )
            item.state = self._selected_device == idx
            self._device_menu[name] = item

    def _select_device(self, device_id: int | None) -> None:
        was_playing = self._player.playing
        self._player.stop()
        self._play_pause_item.title = "Play"

        self._selected_device = device_id
        self._persist()
        self._refresh_devices()

        if was_playing:
            self._play_active()

    def _check_devices(self, _: rumps.Timer) -> None:
        try:
            current = {name for _, name in list_output_devices()}
        except sd.PortAudioError:
            return

        if current != self._known_device_names:
            removed = self._known_device_names - current
            if removed and (self._player.playing or self._player.paused):
                self._halt("Audio stopped; output device disconnected.")
            self._refresh_devices()

        # separate guard: catches silent default-device fallback to speakers
        # (e.g. Bluetooth dies but the device entry lingers in PortAudio)
        if (
            self._block_speakers
            and self._player.playing
            and is_builtin_speaker(self._selected_device)
        ):
            self._halt("Stopped; output fell back to built-in speakers.")

    def _on_toggle_block_speakers(self, _: rumps.MenuItem) -> None:
        self._block_speakers = not self._block_speakers
        self._block_speakers_item.state = self._block_speakers
        if self._block_speakers and self._player.playing:
            if is_builtin_speaker(self._selected_device):
                self._halt("Stopped; built-in speakers are now blocked.")
        self._persist()

    def _on_toggle_dock(self, _: rumps.MenuItem) -> None:
        self._show_in_dock = not self._show_in_dock
        self._dock_item.state = self._show_in_dock
        _set_activation_policy(self._show_in_dock)
        if self._show_in_dock:
            _set_dock_icon()
        self._persist()

    def _on_toggle_login(self, _: rumps.MenuItem) -> None:
        enabled = not _login_item_active()
        _set_login_item(enabled)
        self._login_item.state = enabled

    # Check for updates

    def _on_check_updates(self, _: rumps.MenuItem) -> None:
        def check() -> None:
            new_ver, msg = _check_pypi_version()
            if new_ver:
                rumps.notification("LowHum", "Update available", msg)
            else:
                rumps.notification("LowHum", "", msg)

        threading.Thread(target=check, daemon=True).start()

    # Playback

    def _on_play_pause(self, _: rumps.MenuItem) -> None:
        if self._player.playing:
            self._player.pause()
            self._play_pause_item.title = "Resume"
            self._cancel_stop_timer()
        elif self._player.paused:
            self._player.resume()
            self._play_pause_item.title = "Pause"
            self._start_stop_timer()
        else:
            self._play_active()

    def _on_stop(self, _: rumps.MenuItem) -> None:
        self._player.stop()
        self._play_pause_item.title = "Play"
        self._cancel_stop_timer()

    def _on_quit(self, _: rumps.MenuItem) -> None:
        self._player.stop()
        rumps.quit_application()

    def _persist(self) -> None:
        _save_config(
            self._selected_device,
            self._noise_color,
            self._volume,
            binaural_band=self._binaural_band,
            sound_mode=self._sound_mode,
            show_in_dock=self._show_in_dock,
            block_speakers=self._block_speakers,
            timer_mins=self._timer_mins,
        )
