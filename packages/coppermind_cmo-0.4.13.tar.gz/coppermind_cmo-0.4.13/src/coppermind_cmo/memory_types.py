"""Memory type taxonomy — single source of truth.

Products configure their own memory types. CMO defaults are provided.
This module is part of the Memory Layer (generic, extractable).
"""

from __future__ import annotations

import re
from typing import Any


# ---------------------------------------------------------------------------
# Default CMO memory types
# ---------------------------------------------------------------------------

DEFAULT_MEMORY_TYPES: set[str] = {
    "decision", "preference", "campaign_outcome",
    "commitment", "stakeholder", "fact", "question",
}

# Backwards compat alias — existing code imports this name.
VALID_MEMORY_TYPES = DEFAULT_MEMORY_TYPES


# ---------------------------------------------------------------------------
# Per-type decay rates for time-biased retrieval
# ---------------------------------------------------------------------------

# Formula: adjusted_similarity = similarity * max(floor, 1.0 - (age_days / 365.0 * rate))
DEFAULT_DECAY_RATES: dict[str, dict[str, float]] = {
    "decision":         {"rate": 0.3, "floor": 0.7},
    "preference":       {"rate": 0.2, "floor": 0.8},
    "stakeholder":      {"rate": 0.3, "floor": 0.7},
    "fact":             {"rate": 1.0, "floor": 0.5},
    "commitment":       {"rate": 2.0, "floor": 0.3},
    "campaign_outcome": {"rate": 0.5, "floor": 0.6},
    "question":         {"rate": 1.5, "floor": 0.4},
}

# Fallback for unknown types — same as "fact"
_DEFAULT_DECAY = {"rate": 1.0, "floor": 0.5}


def get_decay_config(
    memory_type: str,
    decay_overrides: dict[str, dict[str, float]] | None = None,
) -> tuple[float, float]:
    """Return (rate, floor) for a memory type.

    Client-level overrides take priority over defaults.
    Returns the fact default for unknown types.
    """
    if decay_overrides and memory_type in decay_overrides:
        override = decay_overrides[memory_type]
        return override.get("rate", 1.0), override.get("floor", 0.5)

    config = DEFAULT_DECAY_RATES.get(memory_type, _DEFAULT_DECAY)
    return config["rate"], config["floor"]


# ---------------------------------------------------------------------------
# Type descriptions — used to build the classification prompt dynamically
# ---------------------------------------------------------------------------

CLASSIFY_DESCRIPTIONS: dict[str, str] = {
    "decision": 'A choice that was made ("We\'re pausing LinkedIn ads")',
    "preference": 'A stated or implied preference ("Prefers casual brand voice")',
    "campaign_outcome": 'Results or metrics from a campaign ("Email open rate was 34%")',
    "commitment": 'An action item someone committed to ("Ben will send messaging by Friday")',
    "stakeholder": 'Information about a key person ("Sarah Chen is VP Marketing")',
    "fact": "Any other noteworthy fact about the client",
    "question": 'An unresolved question or open issue ("Do we need board approval for the rebrand?")',
}

# Classification examples keyed by type
_CLASSIFY_EXAMPLES: dict[str, tuple[str, str]] = {
    "decision": ("Pausing LinkedIn ads through Q2, reallocating to content marketing.", "decision"),
    "preference": ("Sarah prefers async updates via Slack.", "preference"),
    "campaign_outcome": ("Q1 email: 34% open rate, curiosity gap won.", "campaign_outcome"),
    "commitment": ("Ben will send revised messaging by Friday.", "commitment"),
    "stakeholder": ("James Park is the new CEO, started January 2026.", "stakeholder"),
    "fact": ("Series B, 45 employees, developer-first API platform.", "fact"),
}


# ---------------------------------------------------------------------------
# Prompt builders
# ---------------------------------------------------------------------------

def get_memory_types(config: Any = None) -> set[str]:
    """Return the active memory type set.

    If *config* provides a ``memory_types`` attribute, use that.
    Otherwise return the CMO defaults.
    """
    if config is not None:
        custom = getattr(config, "memory_types", None)
        if custom:
            return set(custom)
    return DEFAULT_MEMORY_TYPES


def get_classify_prompt(config: Any = None) -> str:
    """Build the classification prompt dynamically from configured types.

    Falls back to the hardcoded CMO descriptions when no config is provided.
    """
    types = get_memory_types(config)
    descriptions = CLASSIFY_DESCRIPTIONS

    lines = ["Classify this client memory into exactly one type.\n", "Types:"]
    for t in sorted(types):
        desc = descriptions.get(t, t)
        lines.append(f"- {t}: {desc}")

    lines.append("")
    lines.append("Examples:")
    for t, (memory, label) in _CLASSIFY_EXAMPLES.items():
        if t in types:
            lines.append(f'Memory: "{memory}" \u2192 {label}')

    lines.append("")
    lines.append("Return ONLY the type name, nothing else.\n")
    return "\n".join(lines)


def get_summarize_prompt() -> str:
    """Return the summarization prompt."""
    return SUMMARIZE_PROMPT


# ---------------------------------------------------------------------------
# Raw prompt constants — preserved exactly as they were in llm_client.py
# ---------------------------------------------------------------------------

# These prompts are used as fallbacks when the gateway handles classification
# and summarization server-side. The gateway endpoints /v1/classify and
# /v1/summarize use their own prompt templates. These local copies are kept
# for documentation and potential future offline mode.
CLASSIFY_PROMPT = (
    "Classify this client memory into exactly one type.\n\n"
    "Types:\n"
    '- decision: A choice that was made ("We\'re pausing LinkedIn ads")\n'
    '- preference: A stated or implied preference ("Prefers casual brand voice")\n'
    '- campaign_outcome: Results or metrics from a campaign ("Email open rate was 34%")\n'
    '- commitment: An action item someone committed to ("Ben will send messaging by Friday")\n'
    '- stakeholder: Information about a key person ("Sarah Chen is VP Marketing")\n'
    "- fact: Any other noteworthy fact about the client\n\n"
    "Examples:\n"
    'Memory: "Pausing LinkedIn ads through Q2, reallocating to content marketing." \u2192 decision\n'
    'Memory: "Sarah prefers async updates via Slack." \u2192 preference\n'
    'Memory: "Q1 email: 34% open rate, curiosity gap won." \u2192 campaign_outcome\n'
    'Memory: "Ben will send revised messaging by Friday." \u2192 commitment\n'
    'Memory: "James Park is the new CEO, started January 2026." \u2192 stakeholder\n'
    'Memory: "Series B, 45 employees, developer-first API platform." \u2192 fact\n\n'
    "Return ONLY the type name, nothing else.\n\n"
)

SUMMARIZE_PROMPT = (
    "Summarize this client memory in one sentence (max 100 chars). "
    "Preserve all proper nouns (people, company names), dollar amounts, "
    "dates, and specific identifiers exactly — never replace them with "
    "generic descriptions. "
    "Return ONLY the summary.\n\n"
)


# ---------------------------------------------------------------------------
# Sensitivity classification
# ---------------------------------------------------------------------------

SENSITIVE_PATTERNS: list[re.Pattern] = [
    re.compile(r'\$[\d,]+', re.IGNORECASE),
    re.compile(r'\bretainer\b|\bmargin\b|\bpricing\b|\bbudget\b|\brevenue\b|\bcost\b', re.IGNORECASE),
    re.compile(r'\bhiring\b|\bfiring\b|\btermination\b|\bperformance review\b|\bcompensation\b|\bsalary\b', re.IGNORECASE),
    re.compile(r'\bcompetitor\b|\bcompetitive\s+advantage\b|\bmarket\s+share\b', re.IGNORECASE),
    re.compile(r'\bcontract\b|\bSLA\b|\bterms\s+of\s+service\b|\bNDA\b', re.IGNORECASE),
    re.compile(r'\bconfidential\b|\bcmo-only\b|\bsensitive\b', re.IGNORECASE),
]


def classify_sensitivity(content: str) -> str:
    """Classify content as 'open' or 'sensitive' using keyword patterns.
    Errs on the side of caution — false positives are acceptable.
    The CMO can manually override via the sensitivity parameter.
    """
    for pattern in SENSITIVE_PATTERNS:
        if pattern.search(content):
            return "sensitive"
    return "open"
