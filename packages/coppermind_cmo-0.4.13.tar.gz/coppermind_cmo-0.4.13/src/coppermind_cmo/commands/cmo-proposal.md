# /cmo-proposal — Proposal & SOW Panel

Run a multi-expert proposal or scope-of-work review or creation session using the active client's context, relationship history, campaign results, and brand voice.

## Usage

- `/cmo-proposal write a proposal for Acme's Q3 engagement`
- `/cmo-proposal review this SOW: [paste content]`
- `/cmo-proposal pitch a content marketing retainer to Bluebell`
- `/cmo-proposal scope change for adding paid media management`

## Detect Mode

- **Build mode**: prompt contains "write", "build", "create", "draft", "pitch", or "propose"
- **Review mode**: prompt contains "review", "critique", "improve", or pasted proposal/SOW content without a build verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_brand_voice` — their positioning and messaging (to align proposal language with how the client talks about themselves)
2. `search_memory` — stakeholder profiles, MSS/Triage Call notes, pain points surfaced during Widen the Gap, 2-Year Vision statements, past decisions, Head vs. Hands assessment, Red/Yellow/Green diagnostic results
3. `get_campaign_history` — past work results (proof points), Past Campaign Snapshot data (cost per sale, revenue at 30/90/180/365 days)
4. `configure_mind` — company info, engagement history, current service tier (Engaged/Advisor/Half-Day), cadence data
5. `ensure_personal_mind()` — get the CMO's personal mind_id (creates it if needed), then `get_brand_voice(mind_id=<that mind_id>)` to load the CMO's personal voice for proposal tone. Proposals are from the CMO, not in the client's brand voice. If the personal mind has no brand voice configured, use neutral professional tone.

If no memories exist for this client, warn:
> "[Client] has minimal context stored. The panel will build a generic proposal structure, but it won't be personalized. Store some client context first — especially MSS notes and stakeholder profiles."

## Step 2: Expert Panel (5 fixed)

1. **Scope Definer** — Structures proposals using the CMOx service ladder: Half-Day Consult → Engaged (90-day sprint, 10 hrs/week, 3-month minimum) → Advisor (ongoing, quarterly planning + biweekly sprints). Every deliverable must answer: what's included, what's excluded, when it's delivered, how we measure success. Uses Delegation Filter format for deliverables: owner, due date, success criteria. Catches vague scope like "brand strategy" — demands "Positioning Protocol delivery by Day 15, Functional Marketing Systems Map by Day 30, KPI Scorecard established by Day 45."
2. **Pricing Strategist** — Anchors pricing against the full-time CMO alternative ($300K+ salary + 25% headhunter fees per hire). Uses "starting at" language, never fixed prices. Thinks in terms of the service ladder: Engaged starting at $10K/month (3-month minimum), Advisor starting at $3K/month (6-month commitment), Half-Day Consult starting at $5-7.5K. Recommends retainer over hourly — frames pricing around outcomes, not time. Checks that the proposal doesn't undersell the engagement or leave margin on the table.
3. **Risk Assessor** — Flags scope creep patterns specific to fractional CMO engagements: Engaged clients wanting Advisor-level time commitment, clients who won't provide credentials/access, missing Head vs. Hands assessment (are we providing strategy or execution or both?), dependency on client providing content/feedback on time. References the Pre-Flight Checklist mentality: what must be true before work can begin? "This assumes they'll hand over GA, AdWords, and CRM access in week 1 — what if IT drags their feet?"
4. **Relationship Lens** — References MSS/Triage Call insights from memories: What did the client say their 2-Year Vision was? What pain did the Widen the Gap exercise surface? What was their Red/Yellow/Green diagnostic? "Their CEO said failure means laying off 12 people — lead with risk mitigation, not growth." Adapts the proposal tone to what this specific client values. If no MSS data exists, flags the gap.
5. **Competitive Positioner** — Uses the Head vs. Hands distinction to differentiate: agencies provide Hands (execution), the fractional CMO provides the Head (strategy + leadership). Leverages the Functional Marketing Framework as a branded methodology differentiator. Positions the engagement against the alternatives: full-time hire ($300K+), agency retainer (Hands only, no accountability), doing nothing (the cost of inaction from Widen the Gap). Sharpens the unique value prop.

## Step 3: Execute (mode-dependent)

### Build Mode

1. **Scope Definer leads** — structures the proposal using the CMOx template sections: Assessment, Summary of Proposed Solution, deliverables with Delegation Filter clarity (owner, timeline, success criteria), what's explicitly excluded.
2. **Other experts contribute** — Pricing Strategist recommends tier and pricing with full-time CMO anchor, Risk Assessor flags assumptions and dependencies, Relationship Lens personalizes using MSS/stakeholder data, Competitive Positioner sharpens Head vs. Hands differentiation.
3. **Converge**: Merge into a single cohesive proposal. Scope Definer has veto on deliverable clarity; Relationship Lens has veto on client fit.
4. **Present**:
```
PROPOSAL PANEL — [Engagement Title] for [Client Name]

EXECUTIVE SUMMARY
[2-3 sentences: the problem (from Widen the Gap), the approach (Functional Marketing Framework), the outcome (tied to their 2-Year Vision)]

ASSESSMENT
- Company: [name, owner, service, tenure, location, team size]
- Growth Vision: [from MSS / 2-Year Vision exercise]
- Marketing Gaps: [from Red/Yellow/Green diagnostic and Head vs. Hands]
— Relationship Lens

RECOMMENDED ENGAGEMENT
- Tier: [Engaged / Advisor / Half-Day Consult]
- Duration: [90-day sprint / 6-month advisory / one-time]
- Commitment: [hours/week, meeting cadence, communication channels]

SCOPE OF WORK
| Deliverable | Description | Timeline | Success Criteria |
|-------------|-------------|----------|------------------|
| Functional Marketing Systems Map | Complete map of all funnels, automations, touchpoints | Day 30 | 100% of current marketing mapped |
| KPI Scorecard | Metrics dashboard by Pillar | Day 45 | Weekly tracking live |
| [additional items] | [what's included] | [when] | [measurable outcome] |
— Scope Definer (Delegation Filter format)

NOT INCLUDED: [explicit exclusions]

PRICING
- [Tier]: starting at $[amount]/month — [rationale] — Pricing Strategist
- Anchor: Full-time CMO alternative = $[salary] + $[headhunter fees] = $[total annual cost]
- Value: [what the client gets for a fraction of the full-time cost]

RISK REGISTER
1. [Risk] — [Mitigation] — Risk Assessor
2. ...

CLIENT-SPECIFIC POSITIONING
- [Pain from Widen the Gap and how this engagement addresses it] — Relationship Lens
- [Head vs. Hands differentiation] — Competitive Positioner

PROOF POINTS
- [Past Campaign Snapshot result that supports this proposal]
- ...

PANEL FLAGS
- Scope Definer: [scope concern]
- Risk Assessor: [key dependency or assumption to address]
```

### Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — vague scope (no Delegation Filter clarity), missing pricing anchor, unaddressed risks, no client-specific context
   - `SHOULD-FIX` — weak Head vs. Hands differentiation, missing MSS insights, pricing misalignment with tier, no explicit exclusions
   - `POLISH` — language tightening, framing improvements, proposal template alignment

2. **Converge**: Merge duplicates, sort by severity. Scope Definer has final say on deliverable clarity.

3. **Present**:
```
PROPOSAL PANEL — Review for [Client Name]

FINDINGS ([N] total)

MUST-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

SHOULD-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

POLISH
1. [Issue] — [Expert] — [Specific fix]

REVISED PROPOSAL
[Updated proposal with all fixes applied]
```

4. Ask: "Want me to adjust scope, pricing, or positioning?"

## Rules

- **Use real client context.** Reference actual MSS/Triage Call notes, stakeholder pain points from Widen the Gap, 2-Year Vision, Red/Yellow/Green diagnostic, Past Campaign Snapshots, and relationship history. Never use generic filler.
- **Service ladder alignment.** Scope Definer ensures the proposal maps to a recognized engagement tier (Engaged, Advisor, Half-Day). Custom scopes are fine but must be justified.
- **Scope clarity is non-negotiable.** Every deliverable must have Delegation Filter clarity: what's included, what's excluded, who owns it, when it's due, how we measure success. "Ongoing content support" is not a deliverable — "4 blog posts + 8 social posts per month, topics approved in advance" is.
- **Anchor against full-time.** Pricing Strategist MUST frame the fractional fee against the full-time CMO alternative ($300K+ salary + headhunter fees). This is the standard CMOx pricing frame.
- **Price for value, not hours.** Use "starting at" language. Frame around outcomes. Never lead with hourly rates.
- **Know the client.** Relationship Lens must reference actual MSS insights, stakeholder profiles, and Widen the Gap pain from memories. If none exist, flag the gap — a proposal without client context is just a template.
- **Risk honesty.** Risk Assessor must flag real risks specific to this client, not generic ones. "They've changed agencies 3 times in 2 years — the real risk is decision fatigue, not budget" is more useful than "timeline may vary."
- **Head vs. Hands.** Competitive Positioner must clearly differentiate the CMO engagement from agency work. Agencies provide Hands; the fractional CMO provides the Head. This is the core differentiator.
- **Scale depth to engagement size.** A Half-Day Consult proposal gets 1-page treatment. An Engaged 90-day sprint gets full Assessment + SOW + Risk Register.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
