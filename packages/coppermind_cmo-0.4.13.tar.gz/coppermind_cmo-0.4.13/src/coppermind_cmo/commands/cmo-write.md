# /cmo-write — Write & Review Content

When Coppermind tool responses include `_active_client`, always prefix your reply with that value in bold. Example: **[Joulica]** — Here are the SEO keywords...

Run a multi-expert content review or creation session using the active client's brand voice, memories, and campaign history.

## Usage

- `/cmo-write a LinkedIn post about our Q2 results`
- `/cmo-write review this: "We offer best-in-class solutions for modern businesses"`
- `/cmo-write an email announcing our new service offering`
- `/cmo-write improve this blog post: [paste content]`

## Detect Mode

- **Create mode**: prompt contains "write", "draft", "create", or "compose"
- **Review mode**: prompt contains "review", "critique", "improve", "fix", or pasted content without a create verb

## Step 1: Determine Voice + Load Context

**Voice selection** — decide BEFORE loading context:
- Content for the client's audience (social, blog, website, newsletter, brochure) → **client brand voice** (active mind)
- Content from the CMO to anyone (follow-up emails, proposals, SOWs, strategy memos, reports) → **CMO personal voice**
- When ambiguous, ask: "Is this content for [Client]'s audience, or from you professionally?"

**Load the correct voice:**
- **Client brand voice:** `get_brand_voice` on the active mind (the default).
- **CMO personal voice:** Call `ensure_personal_mind()` to get the personal mind's `mind_id` (creates it automatically if it doesn't exist). Then call `get_brand_voice(mind_id=<that mind_id>)`. If the personal mind has no brand voice configured, use neutral professional tone. Do NOT switch away from the active client mind.

**Load context** (run in parallel — do NOT show individual tool calls):

1. The correct `get_brand_voice` call (client or personal mind, per above)
2. `search_memory` for recent context related to the content topic (decisions, campaigns, stakeholders) — **always search the active CLIENT mind, even when using CMO personal voice.** The voice comes from the personal mind but the content context (client facts, decisions, stakeholders) must come from the client mind.
3. `get_campaign_history` — pull recent campaign data if available (always from the active client mind)

If no brand voice is configured on the active client mind, warn:
> "[Client] doesn't have brand voice set up yet. I'll proceed with a neutral professional tone, but the panel won't be able to enforce brand consistency. Run `set brand voice for [client]` to fix this."

## Step 2: Select Expert Panel

**Always include these 3 core experts:**

1. **Brand Voice Guardian** — enforces the client's exact tone, vocabulary, and positioning from `get_brand_voice`. Has veto power on tone conflicts. If no brand voice exists, flags tone inconsistencies against general B2B best practices.
2. **Audience Strategist** — evaluates who this content is FOR. Checks pain points, readability level, emotional hooks, and whether it speaks to the buyer vs. the user.
3. **Editor** — clarity, flow, grammar, conciseness. Cuts fluff. Kills jargon. Tightens every sentence.

**Auto-select 2 adaptive experts based on content type:**

| Expert | Include when |
|--------|-------------|
| **Conversion Optimizer** | emails, ads, landing pages, social posts with CTA, sales collateral |
| **Channel Expert** | always included — adapts advice to the specific platform (LinkedIn tone vs. email vs. blog vs. Twitter) |
| **Data Storyteller** | `get_campaign_history` returned metrics or data points |
| **Competitive Differentiator** | brand voice includes competitor positioning or differentiation claims |

Default to **Channel Expert + Conversion Optimizer** if unsure. Aim for 5 experts total.

## Step 3: Execute (mode-dependent)

### Create Mode

1. **Select lead writer** by content type:
   - Social posts, ads, sales emails → Conversion Optimizer leads
   - Blog posts, articles, thought leadership → Editor leads
   - Newsletters, drip campaigns → Channel Expert leads
   - Strategy docs, positioning briefs → Audience Strategist leads
   - If unsure → Editor leads

2. **Lead writes complete draft** using brand voice and client context. Reference real client details from memories — never use generic filler.

3. **Other experts critique** — each gives up to 3 specific, actionable suggestions. Not "improve the CTA" but "Change 'Learn More' to 'Get Your Free Assessment' — it's more specific and matches their lead-gen focus."

4. **Converge**: Merge non-conflicting feedback. Brand Voice Guardian has veto on any tone conflict. Apply all changes into a final version.

5. **Present**:
```
CONTENT EXPERT PANEL — [Content Type] for [Client Name]
Voice: [Client Brand Voice] or [CMO Personal Voice] or [Neutral Professional]

FINAL VERSION
[The polished content]

PANEL NOTES
- Brand Voice Guardian: [1-line summary of tone assessment]
- [Expert]: [key change made and why]
- [Expert]: [key change made and why]

Word count: [N] | Reading level: [grade] | Platform: [target]
```

### Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — factual errors, brand voice violations, unclear meaning, broken logic
   - `SHOULD-FIX` — weak CTA, wrong tone for platform, missed audience pain point
   - `POLISH` — word choice, rhythm, tightening

2. **Converge**: Merge duplicates (if two experts flag the same issue, note consensus). Sort by severity, then by number of experts who flagged it.

3. **Present**:
```
CONTENT EXPERT PANEL — Review for [Client Name]
Voice: [Client Brand Voice] or [CMO Personal Voice] or [Neutral Professional]

FINDINGS ([N] total)

MUST-FIX
1. [Issue] — [Expert(s)] — [Specific fix]
2. [Issue] — [Expert(s)] — [Specific fix]

SHOULD-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

POLISH
1. [Issue] — [Expert] — [Specific fix]

REVISED VERSION
[Full revised content with all fixes applied]
```

4. Ask: "Want me to copy the revised version, or adjust any of the changes?"

## Rules

- **Brand voice is non-negotiable.** Every output must match `get_brand_voice`. If the original content violates brand voice, that's always a MUST-FIX.
- **Use real client context.** Reference actual campaigns, decisions, stakeholder names, and recent events from memories. Never use generic filler like "our industry-leading solutions."
- **Two-voice model**: client brand voice for customer-facing content, CMO personal voice for professional deliverables (follow-ups, proposals, strategy memos). Neutral professional if neither voice exists. Voice is determined in Step 1 and shown in the output header.
- **Scale depth to content size.** A LinkedIn post gets 2-line critiques. A campaign brief gets paragraph-level analysis. Don't over-analyze a tweet.
- **Experts must be specific.** Not "improve the CTA" but "Change 'Contact Us' to 'Book a 15-Min Strategy Call' — matches their consulting positioning."
- **One convergence round only.** Content critique is subjective — multiple debate rounds produce diminishing returns. Converge once and ship.
- **Don't show the loading.** Don't display individual `search_memory` or `get_brand_voice` calls. Load context silently, then present the panel output.

## Style Learning (after content is accepted)

After the CMO saves content or expresses satisfaction ("looks good", "send it", etc.):

1. **Check opt-out:** Search the personal mind for a memory with tag `settings` containing `style_learning_enabled: false`. If found, skip style learning entirely.
2. **Dedup check:** Search the personal mind for existing memories with tag `auto_style`. Compare the observation you want to store against existing ones. If a substantially similar observation already exists, skip storing.
3. **Store 1-2 observations** about the CMO's writing patterns as preferences in the personal mind: `store_memory(content="[observation]", memory_type="preference", tags=["auto_style"])`. Use the personal mind (internal mind for this customer), not the active client mind.
4. **Degradation:** If the personal mind is unavailable (no personal mind found, DB error), silently skip style learning. Do not warn the user or interrupt the flow.

Examples of good style observations:
- "Prefers short paragraphs (2-3 sentences max)"
- "Always opens LinkedIn posts with a question"
- "Signs off proposals with 'Looking forward to the conversation'"
