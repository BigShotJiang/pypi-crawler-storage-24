# /cmo-budget — Budget Review Panel

Run a multi-expert marketing budget audit, optimization, or review using the active client's expense data, campaign performance, and vendor relationships.

## Usage

- `/cmo-budget audit the marketing budget for Acme`
- `/cmo-budget review this budget plan: [paste content]`
- `/cmo-budget where should we reallocate spend?`
- `/cmo-budget vendor review — are we getting ROI?`

## Detect Mode

- **Audit mode**: prompt contains "audit", "review", "assess", or this is a first-time budget analysis
- **Optimize mode**: prompt contains "reallocate", "optimize", "redistribute", "cut", or "reduce"
- **Review mode**: pasted budget content or plan for critique

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `search_memory` — vendor info, expense data, budget amounts, contract terms, team feedback on tools
2. `get_campaign_history` — campaign ROI, cost per lead/sale, Past Campaign Snapshot data (cost, customers, revenue at 30/90/180/365 days)
3. `configure_mind` — approved monthly budget, billing dates, engagement stage

If no budget data is stored, warn:
> "[Client] doesn't have budget data stored. I'll build the framework, but you'll need to input actual expense amounts. Ask the client for their marketing expense list or credit card statement."

## Step 2: Expert Panel (5 fixed)

1. **Waste Finder** — Keep/Trash/Review analysis on every marketing expense using the Budget Audit Worksheet methodology. Categories: tools/software, vendors/agencies, ad spend, subscriptions, one-time costs. "You're paying $400/month for a social scheduling tool, $200/month for a link shortener nobody uses, and $150/month on a stock photo subscription with zero downloads since March. That's $750/month you can cut today." Always notes: do NOT cancel without client approval.
2. **ROI Ranker** — Ranks channels and campaigns by actual ROI using Past Campaign Snapshot data. Calculates cost per sale and revenue attribution at 30/90/180/365 day marks. "Email returned $47K on $2K spend (23.5x ROAS). LinkedIn ads returned $12K on $8K spend (1.5x ROAS). The allocation should flip."
3. **Channel Allocator** — Recommends budget distribution across channels based on Get BUSI funnel analysis. Invests where the funnel bottleneck is, not where it's already healthy. "You're putting 60% of budget into top-of-funnel awareness but your bottleneck is lead-to-SQL conversion. Shift 20% to middle-of-funnel nurture."
4. **Vendor Evaluator** — Assesses vendor and agency relationships: cost, value delivered, contract terms, alternatives. Checks for the 80/20 Flip: are you spending 80% on people and 20% on activities, or the reverse? "Your SEO agency charges $4K/month but hasn't moved keyword positions in 6 months. Time for a performance review with clear 90-day expectations."
5. **Forecast Modeler** — Projects expected outcomes at different budget levels using historical conversion rates. "At current spend ($15K/month), you'll generate ~180 leads/quarter. Adding $3K to email automation could push that to 250 based on your 14% nurture-to-SQL rate."

## Step 3: Execute (mode-dependent)

### Audit Mode

1. **Waste Finder leads** — categorizes every expense as Keep/Trash/Review.
2. **Other experts contribute** — ROI Ranker ranks by return, Channel Allocator assesses distribution, Vendor Evaluator reviews relationships, Forecast Modeler projects outcomes.
3. **Converge**: Merge into a single budget audit. Waste Finder has veto on expense categorization.
4. **Present**:
```
BUDGET PANEL — Audit for [Client Name]

EXPENSE AUDIT
| Category | Expense | Monthly Cost | Action | Rationale |
|----------|---------|-------------|--------|-----------|
| Tools | [tool] | $[amount] | [Keep/Trash/Review] | [why] |
| Vendors | [vendor] | $[amount] | [Keep/Trash/Review] | [why] |
| Ad Spend | [channel] | $[amount] | [Keep/Trash/Review] | [why] |
— Waste Finder
Total Monthly Spend: $[amount]
Immediate Savings (Trash): $[amount]
Pending Review: $[amount]

ROI RANKINGS
| Channel/Campaign | Spend | Revenue | ROAS | Cost/Sale |
|-----------------|-------|---------|------|-----------|
| [ranked by ROAS] | | | | |
— ROI Ranker

RECOMMENDED ALLOCATION
| Channel | Current % | Recommended % | Rationale |
|---------|----------|---------------|-----------|
| [channel] | [current] | [recommended] | [Get BUSI logic] |
— Channel Allocator

VENDOR SCORECARD
- [Vendor]: [cost] — [value assessment] — [recommendation] — Vendor Evaluator
- ...

FORECAST
- Current spend → [projected outcome]
- +$[amount] to [channel] → [projected improvement]
— Forecast Modeler

PANEL FLAGS
- Waste Finder: [biggest savings opportunity]
- ROI Ranker: [most misallocated spend]
- Vendor Evaluator: [vendor requiring performance review]
```

### Optimize/Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — money being wasted, severely misallocated spend, vendor underperformance
   - `SHOULD-FIX` — suboptimal allocation, missing ROI tracking, vendor contract improvement
   - `POLISH` — minor rebalancing, forecasting refinement

2. **Converge**: Merge duplicates, sort by severity. ROI Ranker has final say on allocation.

3. **Present**: Standard findings format with revised budget plan.

4. Ask: "Want me to build a vendor review agenda, or model a specific reallocation scenario?"

## Rules

- **Never cancel without client approval.** Budget Auditor recommends Keep/Trash/Review, but the client makes the final call. Always state this explicitly.
- **Use real client context.** Reference actual vendor names, dollar amounts, campaign results, and contract terms from memories. Never use generic filler.
- **ROI is the arbiter.** When two channels compete for budget, the one with better Past Campaign Snapshot ROI wins unless there's a strategic reason to invest otherwise.
- **Get BUSI drives allocation.** Channel Allocator invests at the funnel bottleneck, not where it's easy. If the bottleneck is lead-to-SQL, don't add more top-of-funnel spend.
- **The 80/20 Flip.** Vendor Evaluator checks: is the client spending 80% on personnel/agencies and 20% on marketing activities? The future-ready model is the reverse. Flag when the ratio is inverted.
- **Forecast with ranges.** Forecast Modeler should provide conservative and optimistic projections, not single-point estimates.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
