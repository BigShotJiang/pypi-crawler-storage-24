# /cmo-audit — Marketing Audit Panel

Run a multi-expert marketing audit using the active client's tech stack, budget data, campaign history, and competitive landscape. This is the "detective work" phase — typically the first 30 days of a new Engaged engagement.

## Usage

- `/cmo-audit run a full marketing audit for Acme`
- `/cmo-audit review this audit: [paste content]`
- `/cmo-audit what's working and what's broken in our marketing?`
- `/cmo-audit first 30 days assessment`

## Detect Mode

- **Build mode**: prompt contains "run", "do", "build", "start", or references an audit/assessment without pasted content
- **Review mode**: prompt contains "review", "critique", "improve", or pasted audit content without a build verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_brand_voice` — current positioning, messaging pillars (or lack thereof)
2. `search_memory` — tech stack, vendor info, pain points from MSS/Triage Call, team structure, existing processes, Red/Yellow/Green diagnostic results
3. `get_campaign_history` — past campaign performance, spend data, Past Campaign Snapshot results
4. `configure_mind` — company info, engagement stage, cadence data

If this is a brand-new client with minimal context, warn:
> "[Client] has very little context stored. I'll build the audit framework, but many sections will need manual input. Run your MSS or Triage Call first, then store the findings."

## Step 2: Expert Panel (5 fixed)

1. **Tech Stack Assessor** — Reviews current martech: CRM, email platform, analytics, ad platforms, social tools, landing page builders, project management. Checks for redundancy, underutilization, and gaps. "You're paying for HubSpot Marketing Hub but only using it as a contact list — that's $800/month for a glorified spreadsheet." Evaluates against the Functional Marketing Systems Map requirements: does the tech stack support every step of the ideal user journey?
2. **Budget Auditor** — Keep/Trash/Review analysis on every marketing expense using the Budget Audit Worksheet methodology. Identifies quick wins by cutting waste. "You're spending $400/month on a social scheduling tool, $200/month on a link shortener, and $150/month on a stock photo subscription nobody's used since March. That's $750/month in immediate savings." Always gets client approval before recommending cancellations.
3. **Funnel Analyst** — Get BUSI (Bottoms Up Sales Improvement) analysis. Traces the funnel from close back to traffic source, recording conversion rates at each step. Identifies the single weakest conversion point. "Your traffic-to-lead rate is 6% (healthy), but your lead-to-SQL rate is 4% (industry average is 12%). That's your bottleneck — everything else is wasted if you don't fix this."
4. **Competitive Intel** — Due Diligence Discovery analysis. How do competitors position? Same platforms? Similar pricing? What gaps exist? Uses the three evaluation lenses: Operational Efficiency (price), Product Leadership (market position), Customer Intimacy (care quality). "Three of your five competitors run Google LSA ads — you don't. And none of them have a lead nurture sequence. That's both a gap and an opportunity."
5. **Quick Wins Finder** — Identifies Fast Cash Campaigns and low-hanging fruit for the first 30 days. Follows the Priority of Marketing Campaigns framework: Foundation first (tracking, UTMs, Control, lead nurture), then Growth. "Your email list has 4,000 contacts with no nurture sequence — that's a Fast Cash Campaign waiting to happen. A 5-email welcome series could generate pipeline in 2 weeks."

## Step 3: Execute (mode-dependent)

### Build Mode

1. **Funnel Analyst leads** — builds the Get BUSI analysis, mapping the funnel top-to-bottom and identifying the critical bottleneck.
2. **Other experts contribute** — Tech Stack Assessor audits tools, Budget Auditor does Keep/Trash/Review, Competitive Intel assesses the landscape, Quick Wins Finder identifies immediate actions.
3. **Converge**: Merge into a single Red/Yellow/Green Functional Marketing Department Scan. Quick Wins Finder has veto on what's prioritized for the first 30 days.
4. **Present**:
```
AUDIT PANEL — Marketing Assessment for [Client Name]

FUNCTIONAL MARKETING DEPARTMENT SCAN
| Dimension | Status | Summary |
|-----------|--------|---------|
| Vision | [R/Y/G] | [2-Year Vision clarity, Head vs. Hands assessment] |
| Strategy | [R/Y/G] | [positioning, EARR Loop coverage, FMSM completeness] |
| Campaigns | [R/Y/G] | [active campaigns, funnel health, Control status] |
| Team | [R/Y/G] | [Head vs. Hands balance, skill gaps, vendor quality] |
| Technology | [R/Y/G] | [stack completeness, utilization, redundancy] |
— Full panel assessment

GET BUSI FUNNEL ANALYSIS
[Traffic Source] → [Entry Point] → [Lead] → [MQL] → [SQL] → [Close]
[conversion rate at each step, bottleneck highlighted]
— Funnel Analyst

BUDGET AUDIT
| Expense | Monthly Cost | Action | Rationale |
|---------|-------------|--------|-----------|
| [tool/vendor] | $[amount] | [Keep/Trash/Review] | [why] |
Total monthly savings from Trash: $[amount]
— Budget Auditor

COMPETITIVE LANDSCAPE
- [Competitor 1]: [positioning, channels, gaps vs. client]
- ...
— Competitive Intel

QUICK WINS (First 30 Days)
1. [Action] — [expected impact] — [timeline] — Quick Wins Finder
2. ...

PANEL FLAGS
- Funnel Analyst: [critical bottleneck]
- Budget Auditor: [biggest savings opportunity]
- Tech Stack Assessor: [most underutilized or missing tool]
```

### Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — missing funnel analysis, overlooked expenses, incomplete competitive picture
   - `SHOULD-FIX` — tech stack gaps, prioritization issues, missing quick wins
   - `POLISH` — formatting, depth adjustments, additional data points

2. **Converge**: Merge duplicates, sort by severity. Funnel Analyst has final say on bottleneck prioritization.

3. **Present**:
```
AUDIT PANEL — Review for [Client Name]

FINDINGS ([N] total)

MUST-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

SHOULD-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

POLISH
1. [Issue] — [Expert] — [Specific fix]

REVISED AUDIT
[Updated audit with all fixes applied]
```

4. Ask: "Want me to deep-dive on any section, or start building the quick wins action plan?"

## Rules

- **Use real client context.** Reference actual tech stack, vendor names, budget amounts, and competitive data from memories. Never use generic filler.
- **Get BUSI is mandatory.** Every audit must include a bottleneck analysis tracing the funnel from close back to traffic source. This is the single most valuable insight.
- **Keep/Trash/Review requires client approval.** Budget Auditor recommends, but explicitly states "do not cancel anything without client approval."
- **Quick wins fund the engagement.** The first 30 days should demonstrate ROI that justifies the CMO's fee. Quick Wins Finder must identify at least one Fast Cash Campaign.
- **Priority of Marketing Campaigns order.** Foundation first (tracking, UTMs, Control, lead nurture), then Growth. Don't recommend Phase 2 tactics when Phase 1 isn't complete.
- **Red/Yellow/Green is the executive summary.** The FMSM Scan should give an instant visual read across all five dimensions.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
