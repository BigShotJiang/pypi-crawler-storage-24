# /cmo-report — Client Report Panel

Run a multi-expert client performance report review or creation session using the active client's campaign history, memories, and business cadence.

## Usage

- `/cmo-report write a March report for Acme`
- `/cmo-report review this: [paste existing report]`
- `/cmo-report monthly performance update for the leadership team`
- `/cmo-report how did we do last quarter?`

## Detect Mode

- **Build mode**: prompt contains "write", "build", "create", "draft", or references a time period without pasted content
- **Review mode**: prompt contains "review", "critique", "improve", or pasted report content without a build verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `get_campaign_history` — campaign outcomes and metrics, organized by KPI Scorecard Pillars (Acquisition, Conversion, SEO, Reputation, Presence)
2. `search_memory` for commitments (what was promised), decisions (what was decided), 90-Day Rock status, sprint goal outcomes, facts (what changed)
3. `get_brand_voice` — positioning context for framing wins/losses
4. `configure_mind` — cadence (meeting frequency, reporting cadence, current Rocks, EARR Loop phase)

If no campaign history exists, warn:
> "[Client] doesn't have campaign history yet. I'll build the report structure, but data sections will need manual input. Store some campaign results first."

## Step 2: Expert Panel (5 fixed)

1. **Executive Summarizer** — Applies the Executive Scorecard pattern: distill everything to 3-5 numbers the CEO/CMO sponsor actually cares about. Uses Red/Yellow/Green status for each top-line metric. The exec "doesn't need more than five numbers." Catches "burying the lede" and reports that overwhelm with detail before delivering the headline.
2. **Data Storyteller** — Numbers without narrative are noise. Organizes metrics by KPI Scorecard Pillars (Acquisition, Conversion, SEO, Reputation). Adds trend context from weekly scorecard data. Frames results against goals set in the 90-Day Rocks. "CPL dropped from $52 to $38 — now under the $40 Rock target for the first time this quarter."
3. **Accountability Tracker** — Cross-references 90-Day Rocks and Sprint Goals against actual delivery. "The Q1 Rock was 'Generate 200 Qualified Leads at $40 CPL' — we generated 187 at $38 CPL. Rock status: Needs Attention on volume, On Track on efficiency." Also checks commitments from sprint retrospectives and client calls. Uses `search_memory` for promises made.
4. **Trend Spotter** — Identifies patterns across the weekly KPI Scorecard data. Uses Get BUSI (Bottoms Up Sales Improvement) funnel logic to trace where conversion breaks down. "This is the third consecutive month of declining organic — worth flagging." Looks at the EARR Loop holistically: are we strong on Acquire but weak on Retain?
5. **Next-Steps Strategist** — Forward-looking recommendations anchored to the Priority of Marketing Campaigns framework. Aligns next actions to the current 90-Day Rocks. Prevents reports from being backward-only. Recommends what the next sprint should focus on based on data.

## Step 3: Execute (mode-dependent)

### Build Mode

1. **Executive Summarizer leads** — identifies the headline, the win, and the concern using Red/Yellow/Green framing against the 90-Day Rocks.
2. **Other experts contribute** — Data Storyteller frames KPI Scorecard Pillar metrics with trend context, Accountability Tracker checks Rock and Sprint Goal status from memories, Trend Spotter flags patterns using Get BUSI funnel analysis, Next-Steps Strategist proposes next sprint priorities.
3. **Converge**: Merge into a single cohesive report. Executive Summarizer has veto on what leads.
4. **Present**:
```
CLIENT REPORT PANEL — [Month/Quarter] for [Client Name]

EXECUTIVE SCORECARD
| KPI | Result | Goal | Status |
|-----|--------|------|--------|
| [metric] | [actual] | [target from Rock] | [R/Y/G] |
— Executive Summarizer (3-5 metrics max)

ROCK STATUS
- [90-Day Rock] — [On Track / Needs Attention / Off Track] — [detail]
— Accountability Tracker

PERFORMANCE BY PILLAR
Acquisition: [summary + key metrics]
Conversion: [summary + key metrics]
SEO: [summary + key metrics]
Reputation: [summary + key metrics]
— Data Storyteller

COMMITMENTS SCORECARD
- [Promise from last period] → [Delivered / In Progress / Missed] — Accountability Tracker
- ...

TRENDS & PATTERNS
- [Trend observation with EARR Loop or Get BUSI context] — Trend Spotter
- ...

NEXT SPRINT PRIORITIES
1. [Recommendation aligned to current Rock] — [rationale] — Next-Steps Strategist
2. ...

PANEL FLAGS
- [Any concerns from experts]
```

### Review Mode

1. **All experts critique independently** — each provides up to 3 findings, tagged:
   - `MUST-FIX` — missing Rock status, missed commitments, buried bad news, no Executive Scorecard
   - `SHOULD-FIX` — weak framing, missing trends, backward-only with no forward view, metrics not tied to Rocks
   - `POLISH` — data presentation, narrative tightening, Red/Yellow/Green consistency

2. **Converge**: Merge duplicates, sort by severity. Executive Summarizer has final say on what leads.

3. **Present**:
```
CLIENT REPORT PANEL — Review for [Client Name]

FINDINGS ([N] total)

MUST-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

SHOULD-FIX
1. [Issue] — [Expert(s)] — [Specific fix]

POLISH
1. [Issue] — [Expert] — [Specific fix]

REVISED REPORT
[Full revised report with all fixes applied]
```

4. Ask: "Want me to adjust the framing, or expand any section?"

## Rules

- **Accountability is non-negotiable.** Every report MUST include Rock status (On Track / Needs Attention / Off Track). If `search_memory` surfaces commitments from last period, the Accountability Tracker MUST check them. Don't skip uncomfortable truths.
- **Executive Scorecard pattern.** Lead with 3-5 top-line metrics in Red/Yellow/Green. The exec version and the team version are different depths from the same data — Executive Summarizer enforces this.
- **Organize by KPI Scorecard Pillars.** Acquisition, Conversion, SEO, Reputation, Presence. This is the standard structure. Data Storyteller enforces this.
- **Use real client context.** Reference actual campaigns, KPI Scorecard data, Rock targets, decisions, and stakeholder names from memories. Never use generic filler.
- **Forward-looking.** Every report MUST include next sprint priorities aligned to the current 90-Day Rocks. Reports that only look backward are incomplete.
- **Trends tell the story.** Trend Spotter should use Get BUSI funnel analysis and EARR Loop thinking, not just "up/down" observations. "Organic traffic dropped 15% — this correlates with the site migration in week 3, and we expect recovery as new pages index."
- **Scale depth to reporting period.** Monthly gets 1-page Executive Scorecard treatment. Quarterly gets full Pillar analysis with Rock retrospective and next-quarter Rock proposals.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
