# /cmo-kickoff — Client Kick-Off Panel

Run a multi-expert kick-off planning session to structure the first 30 days of a new engagement: agenda, timeline, credentials, deliverables, and quick wins.

## Usage

- `/cmo-kickoff plan the kick-off for Acme`
- `/cmo-kickoff review this kick-off agenda: [paste content]`
- `/cmo-kickoff first 30 days plan for the new engagement`
- `/cmo-kickoff starting a new engagement with Bluebell`

## Detect Mode

- **Plan mode**: prompt contains "plan", "build", "structure", "start", or references a new engagement without pasted content
- **Review mode**: prompt contains "review", "critique", "improve", or pasted kick-off content without a plan verb

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `search_memory` — MSS/Triage Call notes, stakeholder profiles, pain points from Widen the Gap, Red/Yellow/Green diagnostic, team structure, tech stack mentioned
2. `get_brand_voice` — any existing positioning or messaging (may be empty for new clients)
3. `configure_mind` — company info, engagement type (Engaged/Advisor/Half-Day), signed scope

If this is a brand-new client with no context, that's expected — this command is used at engagement start. Build from whatever MSS/Triage Call data exists.

## Step 2: Expert Panel (5 fixed)

1. **Onboarding Planner** — Structures the Engaged Client Kick-Off Call agenda and First 30 Days timeline using the CMOx framework. Required deliverables within 90 days: Functional Marketing Systems Map (~Day 30), Asset Audit Questionnaire, CARE Worksheet, Positioning Protocol, Priority of Marketing Campaigns, KPI Scorecard. "Week 1: credentials and asset audit. Week 2: CARE avatars and competitive research. Week 3-4: FMSM and KPI Scorecard. Everything else flows from the FMSM."
2. **Expectations Manager** — Sets clear communication and deliverable expectations. Confirms meeting cadence (weekly sprint calls, daily Slack check-ins if Engaged), reporting format (when does the client get their first Executive Scorecard?), response times, PM tool access. "Get this in writing during the kick-off call: weekly 60-min sprint calls every Tuesday, daily Slack check-ins by 10am, monthly executive report on the 1st. No ambiguity."
3. **Risk Scanner** — Identifies engagement-specific risks based on MSS/Triage Call data. Slow credential handoff? Unclear decision-making authority? Multiple stakeholders with competing priorities? Previous CMO/agency churn? "The MSS notes show 3 people have opinions on marketing direction — clarify who has final say before Day 1. If nobody is LMA for marketing decisions, this engagement will stall."
4. **Quick Wins Strategist** — Plans the Fast Cash Campaign and immediate-impact actions for the first 30 days. The CMO must demonstrate ROI early to justify the engagement fee. "They have 4,000 email contacts with no nurture sequence — launch a 5-email welcome series by Day 14. Projected pipeline: $15-25K based on their average deal size."
5. **Detective Planner** — Structures the audit/discovery phase using the Due Diligence Discovery SOP and Asset Audit Questionnaire. What data to request, what tools to access, what questions to ask in the first week. "Day 1 credential request: GA4 access, Google Ads, Meta Business Manager, CRM admin, email platform, WordPress admin, project management tool. Send the Asset Audit Questionnaire before the kick-off call."

## Step 3: Execute (mode-dependent)

### Plan Mode

1. **Onboarding Planner leads** — builds the First 30 Days timeline with deliverable milestones.
2. **Other experts contribute** — Expectations Manager drafts the communication agreement, Risk Scanner flags engagement risks, Quick Wins Strategist identifies the Fast Cash Campaign, Detective Planner structures the audit phase.
3. **Converge**: Merge into a single kick-off package. Onboarding Planner has veto on timeline; Risk Scanner has veto on go/no-go risks.
4. **Present**:
```
KICKOFF PANEL — [Client Name] Engagement Launch

KICK-OFF CALL AGENDA (60-90 min)
1. Meet and Greet (5 min) — introductions, roles
2. Restate Deliverables and Timeline (10 min) — confirm scope
3. Required Deliverables — [list with timeline]
4. Communication Expectations (10 min) — cadence, tools, response times
5. Credential Handoff (10 min) — Asset Audit Questionnaire review
6. Quick Win Preview (5 min) — Fast Cash Campaign concept
7. Next Steps and Close (10 min) — recap email within 24 hours
— Onboarding Planner

FIRST 30 DAYS TIMELINE
| Week | Focus | Deliverables | Key Actions |
|------|-------|-------------|-------------|
| 1 | Credentials & Asset Audit | Asset Audit Questionnaire, credential access | [specifics] |
| 2 | Discovery & Avatars | CARE Worksheet, competitive research | [specifics] |
| 3-4 | FMSM & KPI Scorecard | Functional Marketing Systems Map, scorecard setup | [specifics] |
— Onboarding Planner + Detective Planner

COMMUNICATION AGREEMENT
- Meeting cadence: [weekly/daily specifics]
- Communication tools: [Slack/Teams/email]
- Reporting: [format and frequency]
- Response times: [expectations]
— Expectations Manager

CREDENTIAL CHECKLIST
□ Google Analytics (GA4)
□ Google Ads
□ Meta Business Manager
□ CRM (admin access)
□ Email platform (admin access)
□ Website CMS (admin access)
□ Project management tool
□ [other based on client stack]
— Detective Planner

FAST CASH CAMPAIGN
- Opportunity: [what and why]
- Timeline: [when it can launch]
- Projected Impact: [expected outcome]
— Quick Wins Strategist

RISK REGISTER
1. [Risk] — [Mitigation] — Risk Scanner
2. ...

PANEL FLAGS
- Risk Scanner: [highest-priority risk to address before Day 1]
- Quick Wins Strategist: [earliest revenue opportunity]
```

### Review Mode

Standard findings format (MUST-FIX / SHOULD-FIX / POLISH) with revised kick-off plan.

## Rules

- **Use real client context.** Reference actual MSS/Triage Call notes, stakeholder names, pain points, and engagement terms from memories. Never use generic filler.
- **The FMSM is the cornerstone.** The Functional Marketing Systems Map must be the Day 30 deliverable. Everything else (KPI Scorecard, campaigns, team assessment) builds from it.
- **Fast Cash Campaigns are mandatory.** Every kick-off plan must include at least one quick win that generates measurable results in the first 30 days. This justifies the CMO's fee.
- **Credentials on Day 1.** Detective Planner must get the credential request out before the kick-off call. Delayed access = delayed audit = delayed results.
- **Recap email within 24 hours.** Every kick-off call ends with a commitment to send a recap email with action items (who, what, when), recording, and next meeting link.
- **Engagement type matters.** Scale the plan to the engagement: Engaged gets the full First 30 Days timeline. Half-Day Consult gets a focused prep plan. Advisor gets a lighter onboarding.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
