# /cmo-connect — Pull Data from Any MCP

Bridge data from any connected MCP into Coppermind. Claude acts as the extractor — fetches data, breaks it into memories, and stores them with the right types.

## Usage

- `/cmo-connect pull my last 3 Granola meetings into the right client minds`
- `/cmo-connect search Gmail for emails from sarah@acme.com about the rebrand`
- `/cmo-connect pull recent Slack messages from #acme-marketing`

## Steps

1. Parse what the user wants: which data source, what data, which client(s).
2. Check if the required MCP is connected (look for its tools in available tools).
   - **If not connected:** Tell them exactly how to add it. Example: "Granola isn't connected. Run `claude mcp add granola -- uvx granola-mcp-server` and restart."
   - **If connected:** Proceed.
3. Fetch the data using the source MCP's tools.
4. For each item (meeting, email, message):
   a. Determine which client mind it belongs to (match by participant names, company names, or ask the user).
   b. Switch to that client mind.
   c. Extract and store memories using the same rules as transcript ingestion:
      - Stakeholder profiles, decisions, commitments, key facts
      - Tag with the source date and source type
   d. Report progress every 10 memories.
5. Summarize: "Pulled [N] items from [source]. Stored [M] memories across [K] clients."

## Known MCP Setups

- **Granola:** `claude mcp add granola -- uvx granola-mcp-server` (no API key, reads local cache)
- **Slack:** Check for `slack_read_channel`, `slack_search_public` tools
- **Gmail:** Check for `gmail_search_messages`, `gmail_read_message` tools
- **Google Calendar:** Check for `gcal_list_events` tools

## Rate Limits
- Maximum 50 memories per invocation
- Maximum 20 source items per fetch (emails, meetings, messages)
- If the source has more, store the 50 most recent/important first and tell the user: "There's more — want me to continue?"

## Rules
- Always confirm which client mind to store into before storing. If ambiguous, ask.
- Don't store duplicate content — check if a similar memory already exists before storing.
- Meeting transcripts from Granola should be processed the same way as pasted transcripts (full extraction, not just a raw dump).
- Report what was stored at the end, not during. Keep the output clean.
