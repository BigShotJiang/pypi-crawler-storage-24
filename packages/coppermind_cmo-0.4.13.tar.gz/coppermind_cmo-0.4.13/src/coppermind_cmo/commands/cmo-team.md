# /cmo-team — Team & Hiring Panel

Run a multi-expert team assessment, hiring plan, or restructuring review using the active client's team structure, skill gaps, and organizational context.

## Usage

- `/cmo-team assess the marketing team at Acme`
- `/cmo-team should we hire or use an agency for SEO?`
- `/cmo-team head vs. hands assessment`
- `/cmo-team who should we hire next?`

## Detect Mode

- **Assess mode**: prompt contains "assess", "evaluate", "review", or references team structure without a specific hire
- **Hire mode**: prompt contains "hire", "hiring", "recruit", or references a specific role need
- **Restructure mode**: prompt contains "restructure", "reorganize", "rebuild", or references team changes

## Step 1: Load Context (parallel)

Run these simultaneously — do NOT show individual tool calls:

1. `search_memory` — team structure, vendor info, hiring decisions, performance notes, MSS/Triage Call Head vs. Hands assessment, org chart data
2. `configure_mind` — company info, team size, engagement stage, budget context

If no team data is stored, warn:
> "[Client] doesn't have team information stored. I'll build the assessment framework, but you'll need to input team roles, skills, and vendor relationships. Start with a basic org chart."

## Step 2: Expert Panel (5 fixed)

1. **Org Designer** — Assesses current team structure using the Head vs. Hands framework. Who provides strategic thinking (Head)? Who provides execution (Hands)? Where are the gaps? "You have 4 Hands (social manager, designer, copywriter, coordinator) but zero Head. That's why campaigns lack strategy — nobody's deciding WHAT to do, everyone's busy doing." Maps the team against the Functional Marketing Systems Map: does every step of the FMSM have an owner?
2. **Skill Gap Assessor** — Maps required skills against team capabilities. Identifies the Marketing Technician opportunity: one AI-augmented generalist replacing 2-3 specialists. "You need SEO, email, and analytics expertise. One Marketing Technician with AI tools covers all three at $65K instead of three specialists at $180K total." Uses the KPI Scorecard Pillars (Acquisition, Conversion, SEO, Reputation) to identify which Pillars have no owner.
3. **Delegation Coach** — Checks project management using the Delegation Filter framework: Does every project have an owner, due date, and success criteria? Is the LMA (Lead, Manage, Accountable) person clear for each initiative? "Nobody owns the email nurture project — that's why it's been 'in progress' for 3 months. Assign an LMA with a Delegation Filter: owner, due date, 5 success criteria."
4. **Vendor vs. Hire Analyst** — Should this capability be in-house, agency, or contractor? Evaluates cost/quality/speed tradeoffs. Applies the 80/20 Flip: 20-30% on personnel, 70-80% on marketing activities. "Hiring a full-time social media manager at $55K when a contractor at $2K/month gets the same output — and frees $31K/year for ad spend."
5. **Culture Fit Evaluator** — Assesses team dynamics, communication patterns, and management style. Checks if the team structure matches the communication cadence: daily standups, sprint planning, retrospectives. "Your team prefers async communication but you're running daily 30-minute standups. Switch to a Slack channel with end-of-day updates and a weekly 60-minute sync."

## Step 3: Execute (mode-dependent)

### Assess Mode

1. **Org Designer leads** — builds the Head vs. Hands assessment and maps team to FMSM.
2. **Other experts contribute** — Skill Gap Assessor identifies capability gaps, Delegation Coach checks project management, Vendor vs. Hire evaluates current vendor relationships, Culture Fit reads team dynamics.
3. **Converge**: Merge into a single team assessment. Org Designer has veto on structural recommendations.
4. **Present**:
```
TEAM PANEL — Assessment for [Client Name]

HEAD vs. HANDS
Head (Strategy): [who provides this — CMO, internal leader, nobody?]
Hands (Execution): [list of doers — employees, contractors, agencies]
Gap: [what's missing]
— Org Designer

SKILL MAP
| KPI Pillar | Required Skills | Current Owner | Gap? |
|------------|----------------|---------------|------|
| Acquisition | [skills] | [person/vendor] | [yes/no] |
| Conversion | [skills] | [person/vendor] | [yes/no] |
| SEO | [skills] | [person/vendor] | [yes/no] |
| Reputation | [skills] | [person/vendor] | [yes/no] |
— Skill Gap Assessor

PROJECT MANAGEMENT HEALTH
- [Project] — LMA: [person or "unassigned"] — Status: [on track / stuck / no owner]
— Delegation Coach

VENDOR ASSESSMENT
| Vendor/Agency | Role | Monthly Cost | Value Rating | Recommendation |
|--------------|------|-------------|--------------|----------------|
| [vendor] | [what they do] | $[cost] | [high/med/low] | [keep/replace/review] |
— Vendor vs. Hire Analyst

TEAM RECOMMENDATIONS
1. [Recommendation] — [rationale] — [Expert]
2. ...

PANEL FLAGS
- Org Designer: [structural concern]
- Skill Gap Assessor: [critical gap]
- Culture Fit: [dynamics observation]
```

### Hire Mode

Focus experts on the specific role need. Output includes: job description outline, skill requirements, hire vs. contract vs. agency recommendation, salary benchmarks, and interview focus areas.

### Restructure Mode

Focus experts on organizational changes. Output includes: proposed org chart, transition timeline, communication plan, and risk assessment.

## Rules

- **Use real client context.** Reference actual team members by name/role, vendor names, budget amounts, and project status from memories. Never use generic filler.
- **Head vs. Hands is the foundation.** Every team assessment must start with this framework. A team of all Hands with no Head is the most common problem. Org Designer enforces this.
- **Marketing Technician > specialists.** Skill Gap Assessor should always evaluate whether one AI-augmented generalist could replace 2-3 specialists. This is the CMOx future-ready model.
- **The 80/20 Flip.** Vendor vs. Hire Analyst checks: is the client spending 80% on people and 20% on activities? The future-ready model flips this. Flag when the ratio is inverted.
- **Delegation Filters for every project.** If projects are stalling, the first question is: does it have a Delegation Filter (owner, due date, success criteria)? If not, that's the fix.
- **LMA clarity.** Every project needs a Lead, Manage, Accountable person. If nobody is LMA, nobody is responsible.
- **One convergence round only.** Converge once and ship.
- **Don't show the loading.** Don't display individual tool calls. Load context silently, then present the panel output.
