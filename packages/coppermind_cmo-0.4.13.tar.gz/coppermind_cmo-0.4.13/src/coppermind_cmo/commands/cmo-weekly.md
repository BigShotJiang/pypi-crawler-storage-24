# /cmo-weekly — Weekly Review

Generate a cross-client weekly summary.

## Steps

1. Call `get_weekly_summary()` to get meetings, memories, commitments, and follow-up status for all clients this week.
2. Format the results into a scannable report:

```
WEEKLY REVIEW — [Week Start] to [Week End]

CLIENT SCOREBOARD
| Client       | Meetings | Follow-ups | New Memories | Open Items |
|-------------|----------|------------|-------------|------------|
| Acme Corp    | 2        | 2/2 sent   | 8           | 3          |
| 5 Star       | 1        | 0/1 sent   | 3           | 5          |

NEEDS ATTENTION
- [5 Star] 1 meeting follow-up still pending
- [5 Star] 5 open commitments — consider reviewing priorities
- [Acme] 3 open commitments from this quarter

HIGHLIGHTS
- 11 new memories captured across 2 clients
- 3 meetings held, 2 follow-ups sent
```

3. End with: "Want me to save this summary or drill into any client?"
4. If the user wants to save, use `save_output` to persist the summary.

## Rules
- Keep it scannable. Tables and bullets only.
- Only show clients with activity or open items.
- Sort by urgency — most open items or pending follow-ups first.
- Don't switch clients during this command — it's a cross-client view.
