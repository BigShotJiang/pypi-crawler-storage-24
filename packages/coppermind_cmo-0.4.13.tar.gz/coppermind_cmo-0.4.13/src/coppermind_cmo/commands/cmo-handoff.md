# /cmo-handoff — Client Handoff Document

Generate a comprehensive handoff document for a client engagement. This is the "deliverable mind" — when the engagement ends, the client gets this.

## Steps

1. Confirm the active client. If argument provided, switch to that client.
2. Gather everything:
   - `get_brand_voice` — full brand DNA
   - `search_memory` with `include_private: false` — broad search for decisions, commitments, stakeholders, facts, campaign outcomes (private memories are excluded from handoff deliverables)
   - `get_campaign_history` — all campaign results (private memories are automatically excluded)
   - `get_last_brief` — most recent meeting brief
   - Company info from the mind's configuration
3. Before drafting any client-facing text, call `ensure_personal_mind()` to get the CMO's personal mind_id (creates it if needed). Then call `get_brand_voice(mind_id=<that mind_id>)` to load the CMO's voice. Match the CMO's tone and style. Do NOT switch away from the active client mind.
4. Generate a structured handoff document:

```
CLIENT HANDOFF: [Client Name]
Prepared by: [CMO name] | Date: [today]
Engagement period: [first memory date] — [today]

COMPANY OVERVIEW
[From company_info: industry, location, services, key details]

BRAND DNA
Voice & Tone: [summary]
Positioning: [tagline, positioning statement]
Key Differentiators: [bulleted]
Target Audience: [description]
Content Themes: [bulleted]

KEY STAKEHOLDERS
[Name, title, role, communication style — for each]

DECISION LOG
[Chronological list of major decisions with dates and rationale]

ACTIVE COMMITMENTS
[Open action items with owners]

CAMPAIGN HISTORY & RESULTS
[Campaign summaries with outcomes]

STRATEGIC CONTEXT
[Key concerns, priorities, and unresolved questions]

RECOMMENDATIONS FOR NEXT CMO
[Based on patterns in the data — what to focus on, what to avoid, relationship dynamics]
```

5. Ask: "Want me to copy this to clipboard, or save it as a file?"

## Rules
- This is the crown jewel feature. Make it comprehensive and polished.
- Write the "Recommendations" section as genuine strategic advice, not just a data dump.
- Include dates on everything — decisions, campaigns, stakeholder additions.
- The document should be useful to someone who has NEVER met this client.
- Use the brand voice description but write the document in a professional, neutral tone — it's a handoff, not marketing copy.
- **Private memories are excluded.** Always use `include_private: false` when gathering memories. Memories marked as private (internal CMO notes, billing discussions, etc.) must never appear in the handoff deliverable.
