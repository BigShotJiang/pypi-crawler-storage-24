# /cmo-followup — Post-Meeting Follow-Up Email

When Coppermind tool responses include `_active_client`, always prefix your reply with that value in bold. Example: **[Joulica]** — Here are the SEO keywords...

Draft a follow-up email after a client meeting.

## Steps

1. Confirm the active client. If none, ask which client the meeting was with.
2. Before drafting, call `get_meeting_context` to gather recent memories, the meeting brief, and the meeting log entry. This provides all context in one call.
3. **Load CMO voice:** Call `ensure_personal_mind()` to get the CMO's personal mind_id (creates it if needed). Then call `get_brand_voice(mind_id=<that mind_id>)` to load the CMO's voice. Use the returned brand DNA (tone, greeting, signoff, structure) when drafting — NOT the client's brand voice. The CMO writes in their own voice to clients. Do NOT switch away from the active client mind.
4. If no personal mind exists or it has no brand voice configured, use a neutral professional tone — warm, concise, and direct. Do NOT use the client's brand voice for emails. Brand voice is how the client talks to their customers. This email is from the CMO to the client.
5. Draft a follow-up email that includes:
   - Brief thank-you / recap of what was discussed
   - Key decisions made (bulleted)
   - Action items with owners and deadlines (bulleted)
   - Next steps or next meeting date if known
6. Match formality to the relationship — use stakeholder profile to gauge. If the stakeholder profile says "direct communicator" or the transcript shows casual language, be casual. Otherwise default to professional.
7. After drafting and user approves, call `mark_followup_sent` with the meeting_log_id to record that follow-up was sent.
8. Present the draft and ask: "Want me to adjust anything, or copy this to your clipboard?"

## Rules
- Keep it short — 3-4 paragraphs max. CMOs send dozens of these.
- Never include internal notes or agency-specific details. This goes TO the client.
- Action items should clearly state who owns each one (including items the CMO owns).
- If the user just pasted a transcript, extract from that. Don't make them re-explain.
- Offer to copy to clipboard when done.
- If this is the first follow-up email and no CMO voice exists, mention it once: "Tip: set up your writing voice with `/cmo-voice-setup` so future emails sound like you."
