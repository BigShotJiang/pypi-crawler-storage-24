# /cmo-review — Quarterly Review

Generate a quarterly review for a client.

## Usage

- `/cmo-review` — reviews current quarter for active client
- `/cmo-review Q4 2025` — reviews a specific quarter
- "How did Q1 go for Acme?" — triggers naturally

## Steps

1. Confirm the active client and quarter. Default to current quarter from cadence.
2. Gather all memories from that quarter:
   - Decisions made (with dates)
   - Commitments — which were completed, which are still open
   - Campaign outcomes and metrics
   - Key facts and status changes
   - Stakeholder changes (new hires, departures, role changes)
3. If a sprint plan exists for that quarter, pull completion rates per initiative.
4. Generate the review:

```
QUARTERLY REVIEW: [Client Name] — [Quarter Year]

SUMMARY
[2-3 sentence executive summary of the quarter]

WINS
- [Completed initiatives, successful campaigns, goals met]

DECISIONS MADE
- [Date] [Decision and rationale]
- [Date] [Decision and rationale]

CAMPAIGNS & RESULTS
- [Campaign name]: [outcome, metrics if available]

OPEN ITEMS CARRIED FORWARD
- [Items not completed this quarter that carry into next]

SPRINT PLAN SCORECARD (if applicable)
- Initiative 1: 5/6 sprints complete ████████░░ 83%
- Initiative 2: 3/6 sprints complete █████░░░░░ 50%
- Initiative 3: CUT in Sprint 4

TEAM CHANGES
- [New hires, departures, role changes during the quarter]

LOOKING AHEAD
[Recommendations for next quarter based on what happened this quarter]
```

5. Ask: "Want me to copy this, or use it as input for next quarter's planning?"

## Rules
- Be honest. If results were poor, say so constructively. CMOs need accurate assessments, not cheerleading.
- Include specific dates and numbers wherever available.
- The "Looking Ahead" section should be genuine strategic recommendations, not generic advice.
- If there's not enough data for a full review, say so: "I only have [N] memories from Q4. The review will be thin — want to feed me more context first?"
