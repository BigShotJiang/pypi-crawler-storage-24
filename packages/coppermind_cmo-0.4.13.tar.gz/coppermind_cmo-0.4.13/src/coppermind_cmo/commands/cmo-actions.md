# /cmo-actions — Cross-Client Action Items

Show overdue and open action items across all clients.

## Steps

1. Call `list_minds` to get all client minds.
2. For each client, switch and search for commitment-type memories.
3. Build a unified action item view grouped by urgency:

```
ACTION ITEMS — All Clients

OVERDUE
- [Acme] Send revised media plan to Sarah — due 3/8 (7 days overdue)
- [5 Star] Follow up with Stephanie on LSA lead marking — due 3/11 (4 days overdue)

DUE THIS WEEK
- [Acme] Approve Q3 creative concepts — due 3/18
- [XSCAPE] Verify satellite office signage — no date, committed 3/11

OPEN (no due date)
- [5 Star] Evaluate RP1 as Lead Truffle replacement
- [5 Star] Help with van wrap design
- [XSCAPE] Review direct mail demographics with Josh before printing
- [Bluebell] Finalize Q2 content calendar

TOTAL: 8 open items across 3 clients
```

4. Ask: "Want me to focus on any of these?"

## Rules
- Process all clients in parallel.
- Sort overdue items by how late they are (most overdue first).
- Only include commitments that haven't been resolved by a later memory.
- If a commitment was clearly completed based on subsequent memories, skip it.
- Keep descriptions to one line each.
- Show the client name in brackets on every line — this is a cross-client view.
