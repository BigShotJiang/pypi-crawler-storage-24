"""Database connection pool and query helpers.

Adapted from old Coppermind lib/database.py. Simplified for CMO use case:
- Single config source (COPPERMIND_PG_* env vars via Config)
- psycopg2 ThreadedConnectionPool
"""

from __future__ import annotations

import os
import threading
from contextlib import contextmanager
from typing import Any

import psycopg2
from psycopg2.pool import PoolError, ThreadedConnectionPool

from coppermind_cmo.config import Config
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("db")


class TenantIsolationError(RuntimeError):
    """Raised when RLS isolation cannot be applied in hosted mode.

    In hosted mode (customer_id is set), queries MUST NOT proceed without
    tenant isolation. This exception prevents unscoped data access.
    """
    pass

POOL_MIN = 1
POOL_MAX = 3

_rls_degraded_warned = False  # warn once per process — suppress repeated log spam


class Database:
    """PostgreSQL connection pool wrapper."""

    def __init__(self, config: Config):
        self._config = config
        self._pool: ThreadedConnectionPool | None = None
        self._pool_lock = threading.Lock()

    def _ensure_pool(self):
        if self._pool is not None:
            return
        with self._pool_lock:
            if self._pool is None:
                ssl_kwargs = {}
                if self._config.api_key:
                    ca_path = os.path.join(
                        os.path.dirname(__file__), "supabase-ca.pem"
                    )
                    ssl_kwargs = {
                        "sslmode": "verify-ca",
                        "sslrootcert": ca_path,
                    }
                self._pool = ThreadedConnectionPool(
                    POOL_MIN, POOL_MAX,
                    host=self._config.pg_host,
                    port=self._config.pg_port,
                    dbname=self._config.pg_db,
                    user=self._config.pg_user,
                    password=self._config.pg_password,
                    connect_timeout=10,
                    options="-c statement_timeout=30000",  # 30s query timeout
                    keepalives=1,
                    keepalives_idle=30,
                    keepalives_interval=10,
                    keepalives_count=5,
                    **ssl_kwargs,
                )

    def _apply_isolation(self, conn) -> bool:
        """Apply per-transaction RLS via SET LOCAL ROLE + SET LOCAL app.customer_id.

        SET LOCAL is transaction-scoped — both settings expire on COMMIT/ROLLBACK,
        so pooled connections are never left in a contaminated state.
        No-op in self-hosted mode (customer_id is empty).
        Returns False on failure — caller (connection()) raises TenantIsolationError
        in hosted mode to fail closed. Warns once per process for diagnostics.
        """
        global _rls_degraded_warned
        customer_id = getattr(self._config, 'customer_id', '')
        if not customer_id:
            return False
        try:
            with conn.cursor() as cur:
                # SET LOCAL app.customer_id enables RLS policies that filter on
                # current_setting('app.customer_id', true). The ROLE SET is
                # skipped — Supabase pooled connections don't support SET ROLE
                # and the GUC variable alone is sufficient for RLS enforcement.
                cur.execute("SET LOCAL app.customer_id = %s", [customer_id])
            return True
        except Exception as e:
            try:
                conn.rollback()
            except Exception:
                pass
            if not _rls_degraded_warned:
                _rls_degraded_warned = True
                logger.warn(
                    "RLS isolation not applied — coppermind_app role missing or migration pending",
                    error=str(e),
                )
            return False

    @contextmanager
    def connection(self):
        """Borrow a connection from the pool. Auto-returned on exit.

        On pool or connection errors, rebuilds the pool once and retries.
        """
        for attempt in range(2):
            try:
                self._ensure_pool()
                conn = self._pool.getconn()
            except (PoolError, psycopg2.OperationalError) as e:
                if attempt == 0:
                    logger.warn(f"Pool error, rebuilding: {e}")
                    with self._pool_lock:
                        self._pool = None
                    continue
                raise
            break
        _force_close = False
        try:
            isolated = self._apply_isolation(conn)
            # Fail closed: if customer_id is set (hosted mode) but RLS could
            # not be applied, refuse to proceed — never allow unscoped queries.
            if not isolated and self._config.customer_id:
                raise TenantIsolationError(
                    "RLS isolation required but could not be applied. "
                    "Refusing to execute queries without tenant isolation."
                )
            yield conn
        except Exception:
            try:
                conn.rollback()
            except Exception:
                _force_close = True  # rollback failed — connection is dead
            raise
        finally:
            if conn.closed or _force_close:
                self._pool.putconn(conn, close=True)
            else:
                self._pool.putconn(conn)

    def fetch_all(self, sql: str, params: list[Any] | None = None) -> list[tuple]:
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                result = cur.fetchall()
            conn.commit()
            return result

    def fetch_one(self, sql: str, params: list[Any] | None = None) -> tuple | None:
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                result = cur.fetchone()
            conn.commit()
            return result

    def execute(self, sql: str, params: list[Any] | None = None):
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
            conn.commit()

    def execute_returning(self, sql: str, params: list[Any] | None = None) -> tuple | None:
        with self.connection() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                row = cur.fetchone()
            conn.commit()
            return row

    def close(self):
        if self._pool is not None:
            self._pool.closeall()
            self._pool = None
