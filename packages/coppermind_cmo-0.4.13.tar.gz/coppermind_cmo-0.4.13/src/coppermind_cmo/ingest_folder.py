"""Folder ingestion CLI for Coppermind CMO.

Recursively scans directories for .txt, .md, .docx, .pdf files and feeds
them through IngestEngine to extract structured memories for a client mind.

Usage: python -m coppermind_cmo.ingest_folder --mind "Xscape" /path/to/folder
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import sys
import time
from pathlib import Path
from typing import Any

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.ingest import IngestEngine

logger = logging.getLogger(__name__)

# Extensions we handle
SUPPORTED_EXTENSIONS = {".txt", ".md", ".docx", ".pdf"}

# Directories to skip during traversal
SKIP_DIRS = {".git", ".obsidian", "__pycache__", "node_modules"}

# Files to skip
SKIP_FILES = {".DS_Store"}

# Maximum file size for manual CLI ingestion (50 MB)
MAX_FILE_SIZE = 50 * 1024 * 1024

# Maximum file size for auto watcher ingestion (10 MB)
AUTO_MAX_FILE_SIZE = 10 * 1024 * 1024

# Minimum text length to bother processing
MIN_TEXT_LENGTH = 20


def _extract_text_plain(file_path: Path) -> str:
    """Extract text from .txt or .md files."""
    return file_path.read_text(encoding="utf-8", errors="replace")


def _extract_text_docx(file_path: Path) -> str:
    """Extract text from .docx files. Requires python-docx."""
    try:
        from docx import Document
    except ImportError:
        raise ImportError(
            "python-docx is required for .docx support. "
            'Install with: pip install "coppermind-cmo[ingest]"'
        )
    doc = Document(str(file_path))
    paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
    return "\n\n".join(paragraphs)


def _extract_text_pdf(file_path: Path) -> str:
    """Extract text from .pdf files. Requires pypdf."""
    try:
        from pypdf import PdfReader
    except ImportError:
        raise ImportError(
            "pypdf is required for .pdf support. "
            'Install with: pip install "coppermind-cmo[ingest]"'
        )
    reader = PdfReader(str(file_path))
    pages = []
    for page in reader.pages:
        text = page.extract_text()
        if text and text.strip():
            pages.append(text.strip())
    return "\n\n".join(pages)


# Dispatch by extension
_EXTRACTORS = {
    ".txt": _extract_text_plain,
    ".md": _extract_text_plain,
    ".docx": _extract_text_docx,
    ".pdf": _extract_text_pdf,
}


def safe_extract(file_path: Path) -> str | None:
    """Extract text from a file, returning None on any failure.

    Wraps the extraction functions with error handling for use by the
    folder watcher daemon where failures should not crash the process.
    """
    ext = file_path.suffix.lower()
    extractor = _EXTRACTORS.get(ext)
    if extractor is None:
        return None
    try:
        text = extractor(file_path)
        if not text or len(text.strip()) < MIN_TEXT_LENGTH:
            return None
        return text
    except Exception as e:
        logger.warning("Failed to extract text from %s: %s", file_path, e)
        return None


def _file_sha256(file_path: Path) -> str:
    """Compute SHA-256 hash of a file's contents."""
    h = hashlib.sha256()
    with open(file_path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def _is_hidden(name: str) -> bool:
    """Check if a filename is hidden (starts with dot)."""
    return name.startswith(".") or name.startswith("~$")


def collect_files(folders: list[str]) -> list[Path]:
    """Recursively collect supported files from given folders.

    Skips hidden files/dirs, SKIP_DIRS, SKIP_FILES, and files over MAX_FILE_SIZE.
    Returns sorted list of Path objects.
    """
    files: list[Path] = []
    for folder in folders:
        root = Path(folder).resolve()
        if not root.is_dir():
            logger.warning("Not a directory, skipping: %s", root)
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            # Prune hidden dirs and skip dirs (modifying in place)
            dirnames[:] = [
                d for d in dirnames
                if not _is_hidden(d) and d not in SKIP_DIRS
                and not (Path(dirpath) / d).is_symlink()
            ]
            for fname in filenames:
                if _is_hidden(fname) or fname in SKIP_FILES:
                    continue
                fpath = Path(dirpath) / fname
                try:
                    if fpath.is_symlink():
                        continue
                except OSError:
                    continue
                if fpath.suffix.lower() not in SUPPORTED_EXTENSIONS:
                    continue
                try:
                    size = fpath.stat().st_size
                except OSError:
                    continue
                if size > MAX_FILE_SIZE:
                    logger.warning(
                        "Skipping file >50MB: %s (%d bytes)", fpath, size
                    )
                    continue
                files.append(fpath)
    files.sort()
    return files


def _check_file_already_ingested(
    db: Database, mind_id: str, file_hash: str,
    ingest_type: str = "folder_ingest",
) -> bool:
    """Check if a file hash is already recorded in ingest_sources for this mind."""
    row = db.fetch_one(
        "SELECT id FROM ingest_sources "
        "WHERE mind_id = %s AND ingest_type = %s "
        "AND config->>'file_hash' = %s",
        [mind_id, ingest_type, file_hash],
    )
    return row is not None


def _record_file_hash(
    db: Database, mind_id: str, file_path: str, file_hash: str,
    ingest_type: str = "folder_ingest",
):
    """Record a file hash in ingest_sources config for dedup tracking."""
    db.execute(
        "UPDATE ingest_sources SET config = config || %s "
        "WHERE mind_id = %s AND ingest_type = %s "
        "AND config->>'source_ref' = %s",
        [json.dumps({"file_hash": file_hash}), mind_id, ingest_type, file_path],
    )


def resolve_mind(db: Database, mind_name: str) -> tuple[str, str] | None:
    """Look up a client mind by name. Returns (mind_id, name) or None."""
    row = db.fetch_one(
        "SELECT id, name FROM client_minds "
        "WHERE lower(name) = lower(%s) AND archived_at IS NULL",
        [mind_name],
    )
    if row:
        return (str(row[0]), row[1])
    return None


def main():
    """Entry point for folder ingestion CLI."""
    logging.basicConfig(
        level=logging.INFO,
        format="COPPERMIND-CMO: %(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    parser = argparse.ArgumentParser(
        description="Coppermind folder ingestion — extract memories from documents",
    )
    parser.add_argument(
        "--mind",
        required=True,
        help="Client mind name to ingest into",
    )
    parser.add_argument(
        "folders",
        nargs="+",
        help="Folders to scan for documents",
    )
    parser.add_argument(
        "--delay",
        type=float,
        default=2.0,
        help="Seconds to wait between files for rate limiting (default: 2.0)",
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Re-process files that have already been ingested",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="List files that would be processed without actually processing",
    )
    args = parser.parse_args()

    config = Config()

    # Hosted mode: provision from gateway
    if config.api_key:
        from coppermind_cmo.server import _provision_from_gateway
        _provision_from_gateway(config)

    db = Database(config)

    # Verify DB connection
    try:
        db.fetch_one("SELECT 1")
    except Exception as e:
        logger.error("Cannot connect to database: %s", e)
        raise SystemExit(1)

    # Resolve mind
    mind = resolve_mind(db, args.mind)
    if mind is None:
        logger.error(
            "No active mind found with name '%s'. "
            "Create it first with switch_client.",
            args.mind,
        )
        raise SystemExit(1)

    mind_id, mind_name = mind
    logger.info("Ingesting into mind: %s (%s)", mind_name, mind_id)

    # Collect files
    files = collect_files(args.folders)
    if not files:
        logger.info("No supported files found in: %s", ", ".join(args.folders))
        raise SystemExit(0)

    logger.info("Found %d files to process", len(files))

    if args.dry_run:
        print(f"\nCOPPERMIND-CMO: --- Dry run: {len(files)} files would be processed ---", file=sys.stderr)
        for f in files:
            print(f"COPPERMIND-CMO:   {f}", file=sys.stderr)
        raise SystemExit(0)

    # Process files
    engine = IngestEngine(
        db, config, mind,
        auto_ingest=True,
        memory_source_type="folder_ingest",
    )

    totals = {"new": 0, "updated": 0, "skipped": 0}
    errors: list[tuple[Path, str]] = []
    processed = 0
    skipped_dedup = 0

    for i, fpath in enumerate(files):
        # File-level dedup via SHA-256
        try:
            file_hash = _file_sha256(fpath)
        except OSError as e:
            errors.append((fpath, f"Cannot read file: {e}"))
            continue

        if not args.refresh and _check_file_already_ingested(db, mind_id, file_hash):
            logger.info(
                "[%d/%d] Already ingested, skipping: %s",
                i + 1, len(files), fpath,
            )
            skipped_dedup += 1
            continue

        # Extract text
        ext = fpath.suffix.lower()
        extractor = _EXTRACTORS.get(ext)
        if extractor is None:
            continue

        try:
            text = extractor(fpath)
        except ImportError as e:
            logger.error("Missing dependency: %s", e)
            errors.append((fpath, str(e)))
            continue
        except Exception as e:
            logger.warning(
                "[%d/%d] Error extracting text from %s: %s",
                i + 1, len(files), fpath, e,
            )
            errors.append((fpath, str(e)))
            continue

        if len(text.strip()) < MIN_TEXT_LENGTH:
            logger.info(
                "[%d/%d] Too short (%d chars), skipping: %s",
                i + 1, len(files), len(text.strip()), fpath,
            )
            continue

        # Process through IngestEngine
        logger.info(
            "[%d/%d] Processing: %s (%d chars)",
            i + 1, len(files), fpath, len(text),
        )
        try:
            result = engine.process_source(
                source_type="folder_ingest",
                source_ref=str(fpath),
                content=text,
                refresh=args.refresh,
            )
            totals["new"] += result["new"]
            totals["updated"] += result["updated"]
            totals["skipped"] += result["skipped"]
            processed += 1

            # Record file hash for future dedup
            _record_file_hash(db, mind_id, str(fpath), file_hash)

            logger.info(
                "[%d/%d] Done: %d new, %d updated, %d skipped",
                i + 1, len(files),
                result["new"], result["updated"], result["skipped"],
            )
        except Exception as e:
            logger.error(
                "[%d/%d] Error processing %s: %s",
                i + 1, len(files), fpath, e,
            )
            errors.append((fpath, str(e)))

        # Rate limit throttle (skip after last file)
        if i < len(files) - 1 and args.delay > 0:
            time.sleep(args.delay)

    # Summary
    print("\nCOPPERMIND-CMO: " + "=" * 60, file=sys.stderr)
    print(f"COPPERMIND-CMO: Folder ingestion complete for mind: {mind_name}", file=sys.stderr)
    print(f"COPPERMIND-CMO:   Files found:      {len(files)}", file=sys.stderr)
    print(f"COPPERMIND-CMO:   Files processed:  {processed}", file=sys.stderr)
    print(f"COPPERMIND-CMO:   Files deduped:    {skipped_dedup}", file=sys.stderr)
    print(f"COPPERMIND-CMO:   Memories new:     {totals['new']}", file=sys.stderr)
    print(f"COPPERMIND-CMO:   Memories updated: {totals['updated']}", file=sys.stderr)
    print(f"COPPERMIND-CMO:   Chunks skipped:   {totals['skipped']}", file=sys.stderr)
    if errors:
        print(f"COPPERMIND-CMO:   Errors:           {len(errors)}", file=sys.stderr)
        for epath, emsg in errors:
            print(f"COPPERMIND-CMO:     {epath}: {emsg}", file=sys.stderr)
    print("COPPERMIND-CMO: " + "=" * 60, file=sys.stderr)


if __name__ == "__main__":
    main()
