"""Shared utility functions."""

import json
import os
import tempfile
from pathlib import Path
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from coppermind_cmo.db import Database


def secure_write(path: Path, content: str) -> None:
    """Write content to *path* atomically with 0600 permissions.

    Uses write-to-tempfile + os.replace() so readers never see a partial file.
    Ensures parent dir exists and has 0700 permissions.

    Use this for any file under ~/.coppermind/ that may contain sensitive state
    (active client, background jobs, PID files, hook state, etc.).
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        os.write(fd, content.encode())
        try:
            os.fchmod(fd, 0o600)
        except (AttributeError, OSError):
            pass  # Windows fallback below
        os.close(fd)
        fd = -1
        os.replace(tmp, path)  # atomic on POSIX
    except BaseException:
        if fd >= 0:
            os.close(fd)
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    # Windows fallback: fchmod not available
    if not hasattr(os, 'fchmod'):
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass


def secure_mkdir(dir_path: Path) -> None:
    """Create directory with 0700 permissions."""
    dir_path = Path(dir_path)
    dir_path.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(dir_path, 0o700)
    except OSError:
        pass


def parse_jsonb(val) -> Any:
    """Parse jsonb value from DB — may be str, dict, or list."""
    if val is None:
        return {}
    if isinstance(val, str):
        try:
            return json.loads(val)
        except (json.JSONDecodeError, ValueError):
            return {}
    return val


def get_mind_cadence(mind_id: str, db: "Database") -> dict:
    """Fetch a mind's cadence JSONB. Returns {} if not set.

    DEPRECATED: Use MemoryStore.get_mind_cadence() directly.
    Wrapper for backward compatibility during Level 2 migration.
    """
    from coppermind_cmo.memory_store import MemoryStore
    store = MemoryStore(db, None)
    return store.get_mind_cadence(mind_id)


def rotate_log(log_path: Path, max_bytes: int = 5_000_000, max_files: int = 3, max_age_days: int = 7) -> None:
    """Rotate a log file if it exceeds max_bytes.

    Keeps up to max_files rotated copies (.log.1, .log.2, ...).
    Deletes rotated files older than max_age_days.
    """
    import time

    log_path = Path(log_path)
    if not log_path.exists():
        return

    # Age-based cleanup first
    cutoff = time.time() - (max_age_days * 86400)
    for rotated in log_path.parent.glob(f"{log_path.stem}.log.*"):
        try:
            if rotated.stat().st_mtime < cutoff:
                rotated.unlink()
        except OSError:
            pass

    # Size-based rotation
    try:
        if log_path.stat().st_size <= max_bytes:
            return
    except OSError:
        return

    # Shift existing rotated files: .log.3 → delete, .log.2 → .log.3, .log.1 → .log.2
    for i in range(max_files, 0, -1):
        src = log_path.with_suffix(f".log.{i}")
        if i == max_files:
            try:
                src.unlink(missing_ok=True)
            except OSError:
                pass
        else:
            dst = log_path.with_suffix(f".log.{i + 1}")
            try:
                if src.exists():
                    src.rename(dst)
            except OSError:
                pass

    # Rotate current log → .log.1
    try:
        log_path.rename(log_path.with_suffix(".log.1"))
    except OSError:
        pass


