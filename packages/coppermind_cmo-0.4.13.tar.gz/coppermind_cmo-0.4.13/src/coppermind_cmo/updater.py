"""Background auto-updater for Coppermind CMO.

Checks if the installed version is behind the latest from the gateway,
and silently runs `uv tool upgrade coppermind-cmo` in a daemon thread.
The update takes effect on the next server restart (next Claude session).
"""

import os
import shutil
import subprocess
import threading
from importlib.metadata import version as pkg_version
from pathlib import Path

from packaging.version import Version

from coppermind_cmo.log import ToolLogger

logger = ToolLogger("updater")

# ---------------------------------------------------------------------------
# Update state — inspectable by notification providers and the CLI
# ---------------------------------------------------------------------------
_update_state: dict = {
    "status": "idle",       # idle | checking | downloading | ready | failed
    "current_version": "",
    "latest_version": "",
    "error": "",
    "notified": False,      # True after notification returned once this session
}

_update_lock = threading.Lock()


def get_update_state() -> dict:
    """Return a snapshot of the current update state."""
    with _update_lock:
        return dict(_update_state)


# ---------------------------------------------------------------------------
# uv / pipx discovery
# ---------------------------------------------------------------------------
_COMMON_UV_PATHS = [
    Path.home() / ".local" / "bin" / "uv",
    Path.home() / ".cargo" / "bin" / "uv",
    Path("/usr/local/bin/uv"),
    Path("/opt/homebrew/bin/uv"),
]


def _find_uv() -> str | None:
    """Locate the uv binary. Check PATH first, then common install locations."""
    found = shutil.which("uv")
    if found:
        return found
    for path in _COMMON_UV_PATHS:
        if path.exists() and os.access(path, os.X_OK):
            return str(path)
    return None


def _find_pipx() -> str | None:
    """Locate pipx as a fallback installer."""
    return shutil.which("pipx")


# ---------------------------------------------------------------------------
# Background upgrade logic
# ---------------------------------------------------------------------------
def _do_upgrade(latest_version: str, upgrade_urgency: str):
    """Run in a daemon thread. Updates state throughout."""
    with _update_lock:
        _update_state["status"] = "checking"

    try:
        current = Version(pkg_version("coppermind-cmo"))
        latest = Version(latest_version)

        with _update_lock:
            _update_state["current_version"] = str(current)
            _update_state["latest_version"] = str(latest)

        if current >= latest:
            with _update_lock:
                _update_state["status"] = "idle"
            logger.info("Already up to date", current=str(current), latest=str(latest))
            return

        logger.info(
            "Update available",
            current=str(current),
            latest=str(latest),
            urgency=upgrade_urgency,
        )

        # Find an installer
        uv_path = _find_uv()
        pipx_path = _find_pipx() if not uv_path else None

        if uv_path:
            cmd = [uv_path, "tool", "upgrade", "coppermind-cmo"]
        elif pipx_path:
            cmd = [pipx_path, "upgrade", "coppermind-cmo"]
        else:
            with _update_lock:
                _update_state["status"] = "failed"
                _update_state["error"] = "Neither uv nor pipx found. Run: coppermind-update"
            logger.warn("No package installer found (uv or pipx)")
            return

        with _update_lock:
            _update_state["status"] = "downloading"

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
            env={**os.environ, "UV_NO_PROGRESS": "1"},
        )

        if result.returncode == 0:
            with _update_lock:
                _update_state["status"] = "ready"
            logger.info(
                "Update downloaded successfully",
                latest=str(latest),
                installer=cmd[0],
            )
        else:
            with _update_lock:
                _update_state["status"] = "failed"
                _update_state["error"] = result.stderr.strip()[:200] if result.stderr else "Unknown error"
            logger.warn(
                "Update failed",
                returncode=result.returncode,
                stderr=result.stderr.strip()[:200] if result.stderr else "",
            )

    except Exception as e:
        with _update_lock:
            _update_state["status"] = "failed"
            _update_state["error"] = str(e)[:200]
        logger.warn(f"Update check failed: {e}")


def check_and_update(latest_version: str, upgrade_urgency: str = "none"):
    """Spawn a daemon thread to check for and apply updates.

    Safe to call from startup — runs entirely in the background and never
    blocks the MCP server.
    """
    t = threading.Thread(
        target=_do_upgrade,
        args=(latest_version, upgrade_urgency),
        daemon=True,
        name="coppermind-updater",
    )
    t.start()


# ---------------------------------------------------------------------------
# Notification provider — returns one notification per session
# ---------------------------------------------------------------------------
def get_update_notifications() -> list[dict]:
    """Return a notification if an update was downloaded (or failed), once per session.

    Designed to be called from _attach_all_notifications or similar aggregation.
    Returns [] if no update news, or a single-item list with the notification.
    """
    with _update_lock:
        if _update_state["notified"]:
            return []

        status = _update_state["status"]

        if status == "ready":
            _update_state["notified"] = True
            return [{
                "type": "update_available",
                "message": (
                    f"Coppermind CMO {_update_state['latest_version']} has been downloaded. "
                    f"Restart Claude to use the new version."
                ),
                "current_version": _update_state["current_version"],
                "latest_version": _update_state["latest_version"],
            }]

        if status == "failed" and _update_state["error"]:
            _update_state["notified"] = True
            return [{
                "type": "update_failed",
                "message": (
                    f"Auto-update to {_update_state['latest_version']} failed: "
                    f"{_update_state['error']}. Run: coppermind-update"
                ),
            }]

    return []


def _update_notification_provider(db, customer_id: str) -> list[dict]:
    """Adapter for the background notification provider registry.

    The registry calls provider(db, customer_id) but update notifications
    don't need either parameter.
    """
    return get_update_notifications()


# Register with the notification provider system so update notifications
# surface on every tool call (not just daily_loop tools).
from coppermind_cmo.background import register_notification_provider  # noqa: E402
register_notification_provider(_update_notification_provider)
