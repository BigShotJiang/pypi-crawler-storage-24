---
name: cmo-voice-setup
description: Learn the CMO's writing voice from email samples
---

# CMO Voice Profile Setup

Help the user establish their writing voice profile so Coppermind can draft emails that sound like them.

## Steps

1. **Ask for samples:** "To learn your writing voice, paste 2-3 recent client-facing emails you've sent. These help me match your tone, style, and structure when drafting follow-ups."

2. **Analyze the emails.** Extract:
   - **tone**: 2-3 descriptors (e.g., "warm but direct", "professional with dry humor")
   - **greeting_style**: How they typically start emails (e.g., "Hi [Name],", "Hey team,")
   - **signoff_style**: How they close (e.g., "Best,", "Talk soon,", "Cheers,")
   - **sentence_style**: Short/long, paragraph length, structure preferences
   - **structure**: How they organize content (bullets vs prose, top-down vs narrative)
   - **personality**: Humor markers, directness level, warmth indicators
   - **typical_length**: Email length pattern (e.g., "2-3 short paragraphs")
   - **donts**: Things they never do (inferred from absence)

3. **Find or create the personal mind:** Call `ensure_personal_mind()` — this returns the personal mind's `mind_id`, `name`, and `slug`, creating it automatically if it doesn't exist (with the correct deterministic slug derived from the customer's account ID). Then switch to it using the **slug** (not the name, which may be "My Notes" and collide with other minds): `switch_client("<returned slug>")`.

4. **Store the voice profile:** Use `set_brand_voice` on the personal mind to store the structured voice data (tone, avoid patterns, examples). This is the same brand DNA format used by client minds, so `get_brand_voice(mind_id=...)` retrieves it consistently. Additionally, store the detailed profile as a preference memory:
   ```
   store_memory(
       content="CMO Writing Voice Profile: [structured JSON of extracted voice data]",
       memory_type="preference",
       tags=["cmo_voice", "writing_style"]
   )
   ```

5. **Show the extracted profile to the user** and ask: "Does this capture your voice? Want me to adjust anything?"

6. **Switch back to the previous client mind** (if one was active before).

7. **Confirm:** "Voice profile saved. I'll use this when drafting client emails via /cmo-followup and other output commands."

## Notes
- This is a one-time setup. Run again to update the profile.
- The voice profile is stored as an internal mind, not visible in list_minds by default.
- Commands like /cmo-followup check for this profile before drafting.
