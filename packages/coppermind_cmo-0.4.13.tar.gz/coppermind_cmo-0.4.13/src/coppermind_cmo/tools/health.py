"""Health diagnostic tools: check_health.

Provides infrastructure health checks and connector recovery guidance.
"""

from typing import Any

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("health")


# Recovery instructions for known MCP connectors
CONNECTOR_RECOVERY = {
    "google_calendar": {
        "name": "Google Calendar",
        "probe_hint": "Try listing 1 upcoming event via gcal_list_events.",
        "recovery": [
            "Open Claude Desktop Settings (Cmd+,)",
            "Go to Integrations > Google Calendar",
            "Toggle off, wait 5 seconds, toggle back on",
            "If that fails, click 'Reconnect' to re-authorize",
        ],
    },
    "google_drive": {
        "name": "Google Drive",
        "probe_hint": "Try listing root folder files.",
        "recovery": [
            "Open Claude Desktop Settings (Cmd+,)",
            "Go to Integrations > Google Drive",
            "Toggle off, wait 5 seconds, toggle back on",
            "If that fails, click 'Reconnect' to re-authorize",
        ],
    },
    "granola": {
        "name": "Granola",
        "probe_hint": "Try searching meetings via search_meetings.",
        "recovery": [
            "Check that the Granola desktop app is running",
            "Verify Granola MCP is enabled in Claude settings",
            "Restart the Granola app if needed",
        ],
    },
    "slack": {
        "name": "Slack",
        "probe_hint": "Try listing channels via slack_list_channels.",
        "recovery": [
            "Re-authorize Slack in Claude Desktop Settings > Integrations",
            "Check that the Slack workspace is accessible",
        ],
    },
    "clickup": {
        "name": "ClickUp",
        "probe_hint": "Try listing tasks via clickup_filter_tasks.",
        "recovery": [
            "Check your ClickUp API key in Claude settings",
            "Verify the ClickUp workspace is accessible",
        ],
    },
    "hubspot": {
        "name": "HubSpot",
        "probe_hint": "Try searching CRM objects.",
        "recovery": [
            "Re-authorize HubSpot in Claude Desktop Settings > Integrations",
            "Check that the HubSpot portal is accessible",
        ],
    },
    "whatsapp": {
        "name": "WhatsApp",
        "probe_hint": "Try listing chats via list_chats.",
        "recovery": [
            "Check that the WhatsApp Bridge is running",
            "Verify WhatsApp Web is connected",
        ],
    },
}


def _check_db_health(db: Database) -> dict:
    """Check database connectivity."""
    try:
        row = db.fetch_one("SELECT 1")
        if row and row[0] == 1:
            return {"status": "healthy", "message": "Database connected"}
        return {"status": "degraded", "message": "Database responded but returned unexpected result"}
    except Exception as e:
        return {"status": "disconnected", "message": f"Database unreachable: {str(e)[:100]}"}


def _check_gateway_health(config: Config) -> dict:
    """Check gateway API connectivity."""
    import urllib.request
    import urllib.error

    url = f"{config.gateway_url.rstrip('/')}/health"
    try:
        req = urllib.request.Request(url, method="GET")
        req.add_header("User-Agent", "coppermind-health-check")
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 200:
                return {"status": "healthy", "message": "Gateway connected"}
            return {"status": "degraded", "message": f"Gateway returned status {resp.status}"}
    except urllib.error.URLError as e:
        return {"status": "disconnected", "message": f"Gateway unreachable: {str(e.reason)[:100]}"}
    except Exception as e:
        return {"status": "disconnected", "message": f"Gateway error: {str(e)[:100]}"}


def _check_embedding_health(config: Config) -> dict:
    """Check embedding service connectivity."""
    import json
    import urllib.request
    import urllib.error

    url = f"{config.gateway_url.rstrip('/')}/v1/embeddings"
    try:
        data = json.dumps({"input": "health check", "model": "voyage"}).encode()
        req = urllib.request.Request(url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("User-Agent", "coppermind-health-check")
        if config.api_key:
            req.add_header("Authorization", f"Bearer {config.api_key}")
        with urllib.request.urlopen(req, timeout=5) as resp:
            if resp.status == 200:
                return {"status": "healthy", "message": "Embedding service connected"}
            return {"status": "degraded", "message": f"Embedding service returned status {resp.status}"}
    except urllib.error.URLError as e:
        return {"status": "disconnected", "message": f"Embedding service unreachable: {str(e.reason)[:100]}"}
    except Exception as e:
        return {"status": "disconnected", "message": f"Embedding service error: {str(e)[:100]}"}


def _check_health(db: Database, config: Config) -> dict[str, Any]:
    """Run health checks on Coppermind infrastructure."""
    checks = {
        "database": _check_db_health(db),
        "gateway": _check_gateway_health(config),
        "embedding": _check_embedding_health(config),
    }

    all_healthy = all(c["status"] == "healthy" for c in checks.values())
    unhealthy = {k: v for k, v in checks.items() if v["status"] != "healthy"}

    if all_healthy:
        return {
            "status": "healthy",
            "message": "All Coppermind services healthy.",
            "checks": checks,
            "connector_recovery_guide": CONNECTOR_RECOVERY,
        }

    # Build recovery instructions for unhealthy services
    recovery_steps = []
    for name, check in unhealthy.items():
        if name == "database":
            recovery_steps.append("Database issue — this usually resolves on its own. If persistent, check your COPPERMIND_API_KEY.")
        elif name == "gateway":
            recovery_steps.append("Gateway unreachable — check internet connection. If api.coppermind.app is down, it may be a service outage.")
        elif name == "embedding":
            recovery_steps.append("Embedding service issue — semantic search may be degraded. Keyword search will still work.")

    return {
        "status": "degraded" if any(c["status"] == "degraded" for c in checks.values()) else "disconnected",
        "message": f"{len(unhealthy)} service(s) need attention.",
        "checks": checks,
        "recovery_steps": recovery_steps,
        "connector_recovery_guide": CONNECTOR_RECOVERY,
    }


def register(mcp_server):
    """Register health tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, set_last_tool_call
    from coppermind_cmo.resilience import safe_tool_call

    @mcp_server.tool()
    @safe_tool_call("check_health")
    def check_health() -> dict:
        """Check Coppermind infrastructure health and get connector recovery guide.

        Checks database, gateway, and embedding service connectivity.
        Also provides recovery instructions for common MCP connector issues
        (Google Calendar, Drive, Granola, Slack, etc.).

        Use this when:
        - A beta tester reports something isn't working
        - Morning briefing encounters errors
        - After initial setup to verify everything is connected
        """
        set_last_tool_call("check_health")
        return _check_health(get_db(), get_config())
