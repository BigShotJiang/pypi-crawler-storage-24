"""Intelligence tools: prep_meeting, get_campaign_history.

Reference: docs/MCP_TOOLS.md -- prep_meeting (type-balanced retrieval, synthesis),
get_campaign_history (filtered by campaign_outcome type).
"""

import json
from datetime import datetime
from typing import Any, NamedTuple

from coppermind_cmo.config import Config
from coppermind_cmo.db import Database
from coppermind_cmo.embedding_client import get_embedding
# LLM synthesis removed -- see llm_client.py for future re-enablement
from coppermind_cmo.errors import NO_ACTIVE_MIND, tool_error
from coppermind_cmo.log import ToolLogger
from coppermind_cmo.utils import parse_jsonb, get_mind_cadence

logger = ToolLogger("intelligence")

# Default token budget for self-hosted (gemma3:12b, ~3.25 chars/token, 4000 token limit).
# Overridden by config.max_prompt_chars at runtime.
MAX_PROMPT_CHARS = 13000
RECENCY_WEIGHT = 0.6
SIMILARITY_WEIGHT = 0.4
MIN_MEMORIES_FOR_SYNTHESIS = 3
SIMILARITY_THRESHOLD = 0.3
MAX_LIMIT = 200

PERMANENT_TYPES = {"stakeholder", "preference", "fact"}
TEMPORAL_TYPES = {"decision", "commitment", "campaign_outcome", "question"}

QUARTER_WEIGHTS = {0: 1.0, 1: 0.7, 2: 0.4, 3: 0.2}  # distance -> weight
DEFAULT_QUARTER_WEIGHT = 0.1  # 4+ quarters ago
UNTAGGED_QUARTER_WEIGHT = 0.5


class MemoryRow(NamedTuple):
    """Typed representation of a memory row returned by collection functions.

    Replaces bare tuples with 7-10 positional fields so consumers can use
    named access (e.g. ``row.memory_type``) instead of magic indexes.
    Backward-compatible: positional indexing (row[3]) still works.
    """

    id: str
    content: str
    summary: str | None
    memory_type: str
    created_at: datetime | None
    tag: str  # e.g. 'type_balanced', 'fill', 'agenda', 'topic', etc.
    embedding: Any | None = None
    quarter_year: int | None = None
    quarter: int | None = None
    sprint: int | None = None
    is_completed: bool = False


def _quarter_weight(memory_year, memory_quarter, current_year, current_quarter):
    """Weight temporal memories by distance from current quarter."""
    if memory_year is None or memory_quarter is None:
        return UNTAGGED_QUARTER_WEIGHT
    distance = (current_year * 4 + current_quarter) - (memory_year * 4 + memory_quarter)
    if distance < 0:
        distance = 0  # future quarter treated as current
    return QUARTER_WEIGHTS.get(distance, DEFAULT_QUARTER_WEIGHT)


def _get_campaign_history(
    limit: int,
    offset: int,
    db: Database,
    active_mind: tuple[str, str] | None,
    access_level: str | None = None,
    caller_id: str | None = None,
) -> dict | list:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, _ = active_mind
    limit = min(max(1, limit), MAX_LIMIT)
    offset = max(0, offset)

    from coppermind_cmo.tools.memories import _has_is_private
    privacy_filter = "AND (is_private = false OR is_private IS NULL) " if _has_is_private(db) else ""

    # Viewer access: restrict to open + active campaign_outcome memories only
    access_sql = ""
    access_params: list = []
    if access_level is not None and access_level != "owner":
        access_sql = "AND sensitivity = 'open' AND status = 'active' "

    rows = db.fetch_all(
        "SELECT id, content, summary, tags, created_at "
        "FROM memories "
        "WHERE mind_id = %s AND memory_type = 'campaign_outcome' AND is_current = true "
        f"{privacy_filter}"
        f"{access_sql}"
        "ORDER BY created_at DESC LIMIT %s OFFSET %s",
        [mind_id, *access_params, limit, offset],
    )

    return [
        {
            "memory_id": str(r[0]),
            "content": r[1],
            "summary": r[2],
            "tags": r[3] if r[3] else [],
            "created_at": r[4].isoformat() if r[4] else None,
        }
        for r in rows
    ]


def _collect_type_balanced(mind_id: str, limit: int, db: Database) -> list[MemoryRow]:
    """Type-balanced retrieval per MCP_TOOLS.md prep_meeting spec.

    Returns list of MemoryRow. Tag is 'type_balanced' or 'fill'.
    """
    from coppermind_cmo.tools.memories import _has_is_private
    privacy_filter = "AND (is_private = false OR is_private IS NULL) " if _has_is_private(db) else ""

    type_balanced: list[MemoryRow] = []
    fill_memories: list[MemoryRow] = []
    seen_ids: set[str] = set()

    # Get populated types
    type_rows = db.fetch_all(
        "SELECT DISTINCT memory_type FROM memories "
        f"WHERE mind_id = %s AND is_current = true {privacy_filter}",
        [mind_id],
    )
    populated_types = [r[0] for r in type_rows]

    if not populated_types:
        return []

    # Per-type allocation: floor(limit / populated_types), can be 0
    per_type = limit // len(populated_types)

    for mem_type in populated_types:
        rows = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding "
            "FROM memories "
            f"WHERE mind_id = %s AND memory_type = %s AND is_current = true {privacy_filter}"
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, mem_type, per_type],
        )
        for r in rows:
            rid = str(r[0])
            if rid not in seen_ids:
                seen_ids.add(rid)
                type_balanced.append(MemoryRow(
                    id=rid, content=r[1], summary=r[2],
                    memory_type=r[3], created_at=r[4],
                    tag="type_balanced", embedding=r[5],
                ))

    # Fill remaining slots
    remaining = limit - len(type_balanced)
    if remaining > 0:
        fill = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding "
            "FROM memories "
            f"WHERE mind_id = %s AND is_current = true AND id != ALL(%s::uuid[]) {privacy_filter}"
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, list(seen_ids), remaining],
        )
        for r in fill:
            fill_memories.append(MemoryRow(
                id=str(r[0]), content=r[1], summary=r[2],
                memory_type=r[3], created_at=r[4],
                tag="fill", embedding=r[5],
            ))

    return type_balanced + fill_memories


def _collect_meeting_memories(
    mind_id: str,
    topics: list[str] | None,
    limit: int,
    db: Database,
    config: Config,
    access_filter_sql: str = "",
    access_filter_params: list | None = None,
) -> tuple[list[MemoryRow], bool]:
    """Smart retrieval for meeting prep: agenda items + topic search + commitments + permanent knowledge + backfill.

    Returns (list of MemoryRow, topics_degraded). Tag is 'agenda', 'topic', 'commitment', 'permanent', or 'backfill'.
    The second element is True when topic embedding failed for any topic.
    Private memories are always excluded (client-facing output).
    Access filter (access_filter_sql / access_filter_params) is appended to all WHERE clauses to enforce
    viewer visibility rules — pending memories are excluded for all non-owner callers.
    """
    if access_filter_params is None:
        access_filter_params = []

    from coppermind_cmo.tools.memories import _has_is_private
    privacy_filter = "AND (is_private = false OR is_private IS NULL) " if _has_is_private(db) else ""

    memories: list[MemoryRow] = []
    seen_ids: set[str] = set()
    topics_degraded = False

    cadence = get_mind_cadence(mind_id, db)
    current_year = cadence.get("year")
    current_quarter = cadence.get("quarter")

    def _row_to_memory(r, tag: str, is_completed: bool = False) -> MemoryRow:
        return MemoryRow(
            id=str(r[0]), content=r[1], summary=r[2],
            memory_type=r[3], created_at=r[4],
            tag=tag, embedding=r[5],
            quarter_year=r[6], quarter=r[7], sprint=r[8],
            is_completed=is_completed,
        )

    # --- Step 1: Agenda items (all memories tagged 'agenda') ---
    agenda_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        f"WHERE mind_id = %s AND is_current = true AND 'agenda' = ANY(tags) {privacy_filter}"
        f"{access_filter_sql} "
        "ORDER BY created_at DESC",
        [mind_id, *access_filter_params],
    )
    for r in agenda_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append(_row_to_memory(r, "agenda"))

    # --- Step 2: Topic-driven semantic search ---
    if topics:
        for topic_text in topics[:5]:  # max 5 topics to limit embedding calls
            topic_emb = get_embedding(topic_text, config)
            if topic_emb is None:
                topics_degraded = True
                logger.warn(
                    f"Embedding service unreachable for topic '{topic_text}' — skipping semantic topic search",
                    mind_id=mind_id,
                )
                continue
            emb_str = "[" + ",".join(str(x) for x in topic_emb) + "]"
            rows = db.fetch_all(
                "SELECT id, content, summary, memory_type, created_at, embedding, "
                "quarter_year, quarter, sprint, "
                "1 - (embedding <=> %s::vector) as similarity "
                "FROM memories "
                "WHERE mind_id = %s AND is_current = true "
                "AND embedding IS NOT NULL "
                f"AND 1 - (embedding <=> %s::vector) > %s {privacy_filter}"
                f"{access_filter_sql} "
                "ORDER BY similarity DESC LIMIT 5",
                [emb_str, mind_id, emb_str, SIMILARITY_THRESHOLD, *access_filter_params],
            )
            for r in rows:
                rid = str(r[0])
                if rid not in seen_ids:
                    seen_ids.add(rid)
                    memories.append(_row_to_memory(r, "topic"))

    # --- Step 3: Recent commitments (current + previous quarter) ---
    from coppermind_cmo.tools.memories import _has_is_completed
    has_completed_col = _has_is_completed(db)
    commitment_cols = (
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint"
        + (", is_completed " if has_completed_col else " ")
    )
    if current_year is not None and current_quarter is not None:
        prev_quarter = current_quarter - 1 if current_quarter > 1 else 4
        prev_year = current_year if current_quarter > 1 else current_year - 1
        commitment_rows = db.fetch_all(
            commitment_cols +
            "FROM memories "
            "WHERE mind_id = %s AND is_current = true "
            "AND memory_type = 'commitment' "
            f"AND ((quarter_year = %s AND quarter = %s) OR (quarter_year = %s AND quarter = %s)) {privacy_filter}"
            f"{access_filter_sql} "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id, current_year, current_quarter, prev_year, prev_quarter, *access_filter_params],
        )
    else:
        # No cadence set -- fall back to most recent commitments
        commitment_rows = db.fetch_all(
            commitment_cols +
            "FROM memories "
            f"WHERE mind_id = %s AND is_current = true AND memory_type = 'commitment' {privacy_filter}"
            f"{access_filter_sql} "
            "ORDER BY created_at DESC LIMIT 10",
            [mind_id, *access_filter_params],
        )
    for r in commitment_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            is_completed = bool(r[9]) if has_completed_col and len(r) > 9 else False
            memories.append(_row_to_memory(r, "commitment", is_completed=is_completed))

    # --- Step 3.5: Recent unresolved questions ---
    question_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true "
        f"AND memory_type = 'question' {privacy_filter}"
        f"{access_filter_sql} "
        "ORDER BY created_at DESC LIMIT 5",
        [mind_id, *access_filter_params],
    )
    for r in question_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append(_row_to_memory(r, "question"))

    # --- Step 4: Permanent knowledge (stakeholder, preference, fact) ---
    permanent_rows = db.fetch_all(
        "SELECT id, content, summary, memory_type, created_at, embedding, "
        "quarter_year, quarter, sprint "
        "FROM memories "
        "WHERE mind_id = %s AND is_current = true "
        f"AND memory_type IN ('stakeholder', 'preference', 'fact') {privacy_filter}"
        f"{access_filter_sql} "
        "ORDER BY created_at DESC LIMIT 15",
        [mind_id, *access_filter_params],
    )
    for r in permanent_rows:
        rid = str(r[0])
        if rid not in seen_ids:
            seen_ids.add(rid)
            memories.append(_row_to_memory(r, "permanent"))

    # --- Step 5: Type-balanced backfill ---
    remaining = limit - len(memories)
    if remaining > 0:
        exclude_list = list(seen_ids)
        backfill = db.fetch_all(
            "SELECT id, content, summary, memory_type, created_at, embedding, "
            "quarter_year, quarter, sprint "
            "FROM memories "
            f"WHERE mind_id = %s AND is_current = true AND id != ALL(%s::uuid[]) {privacy_filter}"
            f"{access_filter_sql} "
            "ORDER BY created_at DESC LIMIT %s",
            [mind_id, exclude_list, *access_filter_params, remaining],
        )
        for r in backfill:
            memories.append(_row_to_memory(r, "backfill"))

    # --- Step 6: Apply quarter weighting to temporal memories ---
    if current_year is not None and current_quarter is not None:
        weighted: list[tuple[float, MemoryRow]] = []
        for m in memories:
            if m.tag == "agenda":
                weight = 1.0  # agenda items always top priority
            elif m.memory_type in PERMANENT_TYPES:
                weight = 1.0  # permanent knowledge never decays
            else:
                weight = _quarter_weight(m.quarter_year, m.quarter, current_year, current_quarter)

            weighted.append((weight, m))

        # Sort: agenda first, then by weight descending, then by created_at descending
        weighted.sort(key=lambda x: (
            x[1].tag == "agenda",  # agenda items first (True > False)
            x[0],                  # weight
            x[1].created_at.timestamp() if x[1].created_at and hasattr(x[1].created_at, 'timestamp') else 0,
        ), reverse=True)

        memories = [m for _, m in weighted]

    return memories, topics_degraded


def _rerank_by_topic(
    memories: list[MemoryRow],
    topic: str,
    config: Config,
) -> tuple[list[MemoryRow], bool]:
    """Re-rank memories by blended recency + topic similarity score.

    Per spec: 0.6 * recency_score + 0.4 * cosine_similarity.
    Type-balanced memories are preserved in order; only fill slots are re-ranked.
    Uses stored embedding vectors from DB -- only calls get_embedding once for the topic.

    Returns (reranked_memories, degraded). degraded is True when embedding was unavailable.
    """
    topic_embedding = get_embedding(topic, config)
    if topic_embedding is None:
        logger.warn("Embedding service unreachable for topic re-ranking, using recency only")
        return memories, True

    # Separate type-balanced from fill
    type_balanced = [m for m in memories if m.tag == "type_balanced"]
    fill = [m for m in memories if m.tag == "fill"]

    if not fill:
        return memories, False

    # Compute recency scores for fill memories
    timestamps = []
    for m in fill:
        if m.created_at is not None and hasattr(m.created_at, 'timestamp'):
            timestamps.append(m.created_at.timestamp())
        else:
            timestamps.append(0.0)

    # timestamps is always non-empty here (fill is non-empty, checked above)
    min_ts = min(timestamps)
    max_ts = max(timestamps)
    ts_range = max_ts - min_ts if max_ts != min_ts else 1.0

    # Score and sort fill memories using stored embeddings
    scored_fill = []
    for i, m in enumerate(fill):
        recency = (timestamps[i] - min_ts) / ts_range if ts_range > 0 else 1.0

        # Use stored embedding from DB
        mem_embedding = None
        if m.embedding is not None:
            mem_embedding = json.loads(m.embedding) if isinstance(m.embedding, str) else m.embedding

        if mem_embedding is not None and topic_embedding is not None:
            dot = sum(a * b for a, b in zip(topic_embedding, mem_embedding))
            norm_a = sum(a * a for a in topic_embedding) ** 0.5
            norm_b = sum(b * b for b in mem_embedding) ** 0.5
            similarity = dot / (norm_a * norm_b) if norm_a > 0 and norm_b > 0 else 0.0
        else:
            similarity = 0.0

        blended = RECENCY_WEIGHT * recency + SIMILARITY_WEIGHT * similarity
        scored_fill.append((blended, m))

    scored_fill.sort(key=lambda x: x[0], reverse=True)
    return type_balanced + [m for _, m in scored_fill], False


def _build_structured_brief(
    memories: list[MemoryRow],
    brand_dna: dict,
    mind_name: str,
    cadence: dict | None = None,
    company_info: dict | None = None,
) -> str:
    """Build a structured brief from memories and brand DNA for Claude Code to polish."""
    lines = [f"# Meeting Brief: {mind_name}", ""]

    # Position header
    if cadence and cadence.get("type") == "eos":
        pos = f"**EOS Position:** {cadence.get('year', '?')} Q{cadence.get('quarter', '?')}"
        if cadence.get("sprint") is not None and cadence.get("sprints_per_quarter") is not None:
            pos += f", Sprint {cadence['sprint']} of {cadence['sprints_per_quarter']}"
        lines.append(pos)
        lines.append("")

    # Group memories by type, storing (summary, is_completed) tuples
    by_type: dict[str, list[tuple[str, bool]]] = {}
    for m in memories:
        summary = m.summary or (m.content[:150] if m.content else "")
        if m.memory_type not in by_type:
            by_type[m.memory_type] = []
        is_completed = getattr(m, "is_completed", False)
        by_type[m.memory_type].append((summary, is_completed))

    # Section order validated by 7-CMO beta tester survey:
    # 1. Last meeting takeaways  2. Action items
    # 3. Client priorities/concerns  4. Campaign snapshot
    # 5. Unresolved questions  6. Stakeholders  7. Key context

    # 1. Last Meeting Takeaways (decisions)
    if "decision" in by_type:
        lines.append("## Last Meeting Takeaways")
        for summary, _ in by_type["decision"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 2. Action Items (commitments — open first, then completed)
    if "commitment" in by_type:
        lines.append("## Action Items")
        items = sorted(by_type["commitment"], key=lambda x: x[1])
        for summary, is_completed in items:
            checkbox = "[x]" if is_completed else "[ ]"
            lines.append(f"- {checkbox} {summary}")
        lines.append("")

    # 3. Client Pulse (preferences = priorities and concerns)
    if "preference" in by_type:
        lines.append("## Client Pulse")
        for summary, _ in by_type["preference"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 4. Campaign Snapshot (campaign outcomes)
    if "campaign_outcome" in by_type:
        lines.append("## Campaign Snapshot")
        for summary, _ in by_type["campaign_outcome"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 5. Unresolved Questions
    if "question" in by_type:
        lines.append("## Unresolved Questions")
        for summary, _ in by_type["question"]:
            lines.append(f"- {summary}")
        lines.append("")

    # 6. Key Stakeholders from brand DNA
    stakeholders = brand_dna.get("stakeholders", [])
    if stakeholders:
        lines.append("## Key Stakeholders")
        for s in stakeholders:
            name = s.get("name", "Unknown")
            title = s.get("title", "")
            role = s.get("role", "")
            entry = f"- **{name}**"
            if title:
                entry += f", {title}"
            if role:
                entry += f" ({role})"
            lines.append(entry)
        lines.append("")

    # 7. Key Context (facts)
    if "fact" in by_type:
        lines.append("## Key Context")
        for summary, _ in by_type["fact"]:
            lines.append(f"- {summary}")
        lines.append("")

    # Stakeholder memories (different from brand DNA stakeholders)
    if "stakeholder" in by_type:
        lines.append("## Stakeholder Notes")
        for summary, _ in by_type["stakeholder"]:
            lines.append(f"- {summary}")
        lines.append("")

    if not by_type:
        lines.append("*No memories available for this client.*")
        lines.append("")

    lines.append("---")

    return "\n".join(lines)


# Adjacency threshold for context switch detection (minutes)
ADJACENCY_THRESHOLD_MINUTES = 30


def _detect_adjacent_meeting(
    mind_id: str,
    customer_id: str,
    db: Database,
    meeting_start_time: datetime | None = None,
) -> dict | None:
    """Detect if there's a meeting for a different client within 30 min before this meeting.

    Returns dict with previous meeting info, or None if no adjacent meeting found.
    """
    from coppermind_cmo.tools.daily_loop import _has_meeting_log_table

    if not _has_meeting_log_table(db):
        return None

    if meeting_start_time is None:
        row = db.fetch_one(
            "SELECT start_time FROM meeting_log "
            "WHERE mind_id = %s AND customer_id = %s "
            "AND start_time >= NOW() - INTERVAL '1 hour' "
            "ORDER BY start_time ASC LIMIT 1",
            [mind_id, customer_id],
        )
        if not row or row[0] is None:
            return None
        meeting_start_time = row[0]

    from datetime import timedelta
    window_start = meeting_start_time - timedelta(minutes=ADJACENCY_THRESHOLD_MINUTES)

    row = db.fetch_one(
        "SELECT ml.mind_id, ml.title, ml.start_time, cm.name "
        "FROM meeting_log ml "
        "JOIN client_minds cm ON ml.mind_id = cm.id "
        "WHERE ml.mind_id != %s "
        "AND ml.customer_id = %s "
        "AND ml.start_time >= %s "
        "AND ml.start_time < %s "
        "ORDER BY ml.start_time DESC LIMIT 1",
        [mind_id, customer_id, window_start, meeting_start_time],
    )

    if not row:
        return None

    return {
        "mind_id": str(row[0]),
        "title": row[1],
        "start_time": row[2],
        "name": row[3],
    }


def _build_transition_brief(
    previous_mind: dict,
    current_mind_id: str,
    current_mind_name: str,
    db: Database,
    customer_id: str,
) -> str:
    """Build a context switch transition brief between two client meetings."""
    from datetime import timedelta, timezone

    prev_name = previous_mind["name"]
    prev_mind_id = previous_mind["mind_id"]

    # 1. Last interaction with current client
    last_row = db.fetch_one(
        "SELECT MAX(start_time) FROM meeting_log "
        "WHERE mind_id = %s AND customer_id = %s AND start_time < NOW()",
        [current_mind_id, customer_id],
    )
    last_interaction = last_row[0] if last_row and last_row[0] else None

    # 2. Changes since last interaction (new memories)
    changes = []
    if last_interaction:
        change_rows = db.fetch_all(
            "SELECT memory_type, COALESCE(summary, LEFT(content, 100)) as summary, created_at "
            "FROM memories "
            "WHERE mind_id = %s AND customer_id = %s "
            "AND created_at > %s AND is_current = true "
            "ORDER BY created_at DESC LIMIT 5",
            [current_mind_id, customer_id, last_interaction],
        )
        for r in change_rows:
            changes.append({
                "type": r[0],
                "summary": r[1],
                "date": r[2].strftime("%B %d") if r[2] else "",
            })

    # 3. Brand voice for tone shift
    prev_voice_row = db.fetch_one(
        "SELECT brand_voice FROM client_minds WHERE id = %s", [prev_mind_id]
    )
    curr_voice_row = db.fetch_one(
        "SELECT brand_voice FROM client_minds WHERE id = %s", [current_mind_id]
    )
    prev_tone = ""
    curr_tone = ""
    if prev_voice_row and prev_voice_row[0]:
        pv = parse_jsonb(prev_voice_row[0])
        prev_tone = pv.get("tone", "") if isinstance(pv, dict) else ""
    if curr_voice_row and curr_voice_row[0]:
        cv = parse_jsonb(curr_voice_row[0])
        curr_tone = cv.get("tone", "") if isinstance(cv, dict) else ""

    # 4. Top open items (commitments, issues, agenda items)
    open_rows = db.fetch_all(
        "SELECT memory_type, COALESCE(summary, LEFT(content, 100)) as summary, created_at "
        "FROM memories "
        "WHERE mind_id = %s AND customer_id = %s "
        "AND is_current = true "
        "AND memory_type IN ('commitment', 'issue', 'agenda') "
        "ORDER BY CASE memory_type "
        "  WHEN 'agenda' THEN 1 WHEN 'commitment' THEN 2 WHEN 'issue' THEN 3 END, "
        "created_at DESC "
        "LIMIT 3",
        [current_mind_id, customer_id],
    )

    # 5. Build markdown
    lines = []
    lines.append(f"## Context Switch: {prev_name} \u2192 {current_mind_name}")

    if last_interaction:
        now = datetime.now(timezone.utc)
        days_ago = (now - last_interaction).days
        date_str = last_interaction.strftime("%B %d")
        if days_ago == 0:
            lines.append(f"**Last interaction:** Today ({date_str})")
        elif days_ago == 1:
            lines.append(f"**Last interaction:** Yesterday ({date_str})")
        else:
            lines.append(f"**Last interaction:** {days_ago} days ago ({date_str})")
    else:
        lines.append(f"**Last interaction:** First meeting with {current_mind_name}. See full prep below.")

    if changes:
        lines.append("**Since then:**")
        for c in changes:
            lines.append(f"- {c['summary']} ({c['type']}, {c['date']})")

    if prev_tone and curr_tone:
        lines.append(f"**Tone shift:** Switching from {prev_name}'s {prev_tone} to {current_mind_name}'s {curr_tone} style.")

    if open_rows:
        lines.append("")
        lines.append("**Top open items:**")
        for i, r in enumerate(open_rows, 1):
            age = ""
            if r[2]:
                age_days = (datetime.now(timezone.utc) - r[2]).days
                if age_days == 0:
                    age = "today"
                elif age_days == 1:
                    age = "1 day old"
                else:
                    age = f"{age_days} days old"
            lines.append(f"{i}. {r[1]} ({r[0]}, {age})")

    lines.append("")
    lines.append("---")
    lines.append("")

    return "\n".join(lines)


def _prep_meeting(
    topics: list[str] | None,
    meeting_type: str | None,
    limit: int,
    db: Database,
    config: Config,
    active_mind: tuple[str, str] | None,
    save: bool = False,
    access_filter_sql: str = "",
    access_filter_params: list | None = None,
    customer_id: str | None = None,
    meeting_start_time: str | None = None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind
    limit = min(max(1, limit), MAX_LIMIT)

    # Validate meeting_type if provided
    valid_meeting_types = {"review", "catchup", "planning", "topic"}
    if meeting_type and meeting_type not in valid_meeting_types:
        return tool_error("INVALID_INPUT", f"meeting_type must be one of: {', '.join(valid_meeting_types)}")

    # Fetch cadence and company info
    context_row = db.fetch_one(
        "SELECT name, brand_voice, brand_positioning, approved_messaging, "
        "stakeholders, content_themes, cadence, company_info "
        "FROM client_minds WHERE id = %s",
        [mind_id],
    )
    if not context_row:
        return tool_error("INTERNAL_ERROR", "Active mind not found in database")

    brand_dna = {
        "brand_voice": parse_jsonb(context_row[1]),
        "brand_positioning": parse_jsonb(context_row[2]),
        "approved_messaging": parse_jsonb(context_row[3]),
        "stakeholders": parse_jsonb(context_row[4]) if context_row[4] else [],
        "content_themes": context_row[5] if context_row[5] else [],
    }
    cadence = parse_jsonb(context_row[6]) if context_row[6] else {}
    company_info = parse_jsonb(context_row[7]) if context_row[7] else {}

    # Context switch detection
    transition_brief = None
    if customer_id and meeting_start_time:
        try:
            parsed_time = datetime.fromisoformat(meeting_start_time) if isinstance(meeting_start_time, str) else meeting_start_time
            adjacent = _detect_adjacent_meeting(mind_id, customer_id, db, parsed_time)
        except (ValueError, TypeError):
            adjacent = _detect_adjacent_meeting(mind_id, customer_id, db)
    elif customer_id:
        adjacent = _detect_adjacent_meeting(mind_id, customer_id, db)
    else:
        adjacent = None

    if adjacent:
        transition_brief = _build_transition_brief(
            adjacent, mind_id, mind_name, db, customer_id,
        )

    # Smart retrieval (replaces type-balanced for prep_meeting)
    memories, topics_degraded = _collect_meeting_memories(
        mind_id, topics, limit, db, config,
        access_filter_sql=access_filter_sql,
        access_filter_params=access_filter_params or [],
    )

    # Group memories by type for structured return
    memories_by_type: dict[str, list] = {}
    for m in memories:
        if m.memory_type not in memories_by_type:
            memories_by_type[m.memory_type] = []
        entry = {
            "summary": m.summary or (m.content[:150] if m.content else ""),
            "created_at": m.created_at.isoformat() if m.created_at else None,
        }
        if m.memory_type == "commitment":
            entry["is_completed"] = getattr(m, "is_completed", False)
        memories_by_type[m.memory_type].append(entry)

    base_response = {
        "client_name": mind_name,
        "memories_by_type": memories_by_type,
        "stakeholders": brand_dna["stakeholders"],
        "brand_voice": brand_dna["brand_voice"],
        "memory_count": len(memories),
        "cadence": cadence,
        "context_switch": transition_brief is not None,
        "transition_brief": transition_brief,
    }

    if len(memories) < MIN_MEMORIES_FOR_SYNTHESIS:
        raw_response = {
            **base_response,
            "mode": "raw",
            "reason": "insufficient_data",
            "brief_markdown": transition_brief,
            "message": f"Only {len(memories)} memories found (minimum {MIN_MEMORIES_FOR_SYNTHESIS} needed for synthesis). "
                       "Store more memories to enable meeting briefs.",
        }
        if topics_degraded:
            raw_response["degraded"] = True
            raw_response["degraded_reason"] = (
                "Embedding service unavailable — topic-based retrieval was skipped. "
                "Brief is based on recency and type-balancing only."
            )
        if save:
            raw_response["saved"] = False
        return raw_response

    # Build structured brief -- Claude Code writes the polished version
    structured_brief = _build_structured_brief(
        memories, brand_dna, mind_name, cadence=cadence, company_info=company_info,
    )

    # Prepend transition brief when context switch detected
    if transition_brief and structured_brief:
        structured_brief = transition_brief + structured_brief

    response = {
        **base_response,
        "mode": "structured",
        "reason": None,
        "brief_markdown": structured_brief,
    }

    if topics_degraded:
        response["degraded"] = True
        response["degraded_reason"] = (
            "Embedding service unavailable — topic-based retrieval was skipped. "
            "Brief is based on recency and type-balancing only."
        )

    if save:
        row = db.execute_returning(
            "INSERT INTO meeting_briefs (mind_id, brief_markdown, meeting_type, topics, memory_count) "
            "VALUES (%s, %s, %s, %s, %s) RETURNING id",
            [mind_id, structured_brief, meeting_type, topics or [], len(memories)],
        )
        if row:
            response["brief_id"] = str(row[0])
            response["saved"] = True
            logger.info("Saved meeting brief", mind_id=mind_id, brief_id=str(row[0]))
        else:
            response["saved"] = False
            logger.error("Failed to save meeting brief", mind_id=mind_id)

    return response


def _get_last_brief(
    db: Database,
    active_mind: tuple[str, str] | None,
) -> dict[str, Any]:
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    row = db.fetch_one(
        "SELECT id, brief_markdown, meeting_type, topics, memory_count, created_at "
        "FROM meeting_briefs "
        "WHERE mind_id = %s "
        "ORDER BY created_at DESC LIMIT 1",
        [mind_id],
    )

    if not row:
        return {
            "client_name": mind_name,
            "brief_markdown": None,
            "message": "No saved briefs found. Use prep_meeting with save=true to save a brief.",
        }

    result = {
        "brief_id": str(row[0]),
        "client_name": mind_name,
        "brief_markdown": row[1],
        "meeting_type": row[2],
        "topics": row[3] if row[3] else [],
        "memory_count": row[4],
        "created_at": row[5].isoformat() if row[5] else None,
    }

    if row[5] is not None:
        from datetime import timezone
        age_days = (datetime.now(timezone.utc) - row[5]).days
        if age_days > 7:
            result["age_warning"] = (
                f"This brief is {age_days} days old. "
                "Run prep_meeting with save=true for a fresh brief."
            )

    return result


# ---------------------------------------------------------------------------
# Knowledge health dimensions
# ---------------------------------------------------------------------------

_DIMENSION_SUGGESTIONS = {
    "brand_voice": "Set brand voice with set_brand_voice — include tone, values, and examples.",
    "stakeholders": "Mention key people in conversation: 'Sarah Chen is the CEO, prefers data-driven updates.'",
    "campaign_history": "Share past campaign reports or mention results: 'Q1 email campaign had 34% open rate.'",
    "meeting_history": "Meetings are logged automatically when you use prep_meeting or auto_ingest_transcript.",
    "eos_config": "Configure EOS cadence with configure_mind — set quarter, year, and sprint.",
    "content_themes": "Mention content topics: 'Our content pillars are thought leadership and product launches.'",
    "memory_depth": "Store more memories across diverse types for better recall quality.",
}


def _get_knowledge_health(
    db: Database,
    active_mind: tuple[str, str] | None,
    customer_id: str | None = None,
) -> dict[str, Any]:
    """Evaluate knowledge coverage across dimensions for the active mind."""
    if active_mind is None:
        return NO_ACTIVE_MIND()

    mind_id, mind_name = active_mind

    # 1. Brand voice dimension
    bv_row = db.fetch_one(
        "SELECT brand_voice, brand_positioning, approved_messaging, stakeholders, content_themes "
        "FROM client_minds WHERE id = %s",
        [mind_id],
    )

    brand_voice_data = parse_jsonb(bv_row[0]) if bv_row and bv_row[0] else {}
    brand_positioning = parse_jsonb(bv_row[1]) if bv_row and bv_row[1] else {}
    approved_messaging = parse_jsonb(bv_row[2]) if bv_row and bv_row[2] else {}
    stakeholders_data = parse_jsonb(bv_row[3]) if bv_row and bv_row[3] else []
    content_themes = bv_row[4] if bv_row and bv_row[4] else []

    # Score brand voice
    bv_word_count = len(json.dumps(brand_voice_data).split()) if brand_voice_data else 0
    bv_has_tone = bool(brand_voice_data.get("tone")) if isinstance(brand_voice_data, dict) else False
    bv_has_values = bool(brand_voice_data.get("values")) if isinstance(brand_voice_data, dict) else False

    if bv_word_count == 0:
        bv_status = "none"
        bv_detail = "Not configured."
    elif bv_word_count < 50:
        bv_status = "sparse"
        bv_detail = f"{bv_word_count} words. Add tone, values, and examples for better results."
    elif bv_has_tone and bv_has_values:
        bv_status = "rich"
        bv_detail = f"{bv_word_count} words with tone and values configured."
    else:
        bv_status = "adequate"
        bv_detail = f"{bv_word_count} words."

    # 2. Stakeholders dimension (from brand DNA, not NER)
    stakeholder_count = len(stakeholders_data) if isinstance(stakeholders_data, list) else 0
    if stakeholder_count == 0:
        stk_status = "none"
        stk_detail = "No stakeholders configured."
    elif stakeholder_count <= 2:
        stk_status = "sparse"
        names = ", ".join(s.get("name", "?") for s in stakeholders_data[:3])
        stk_detail = f"{stakeholder_count} found: {names}."
    elif stakeholder_count <= 4:
        stk_status = "adequate"
        names = ", ".join(s.get("name", "?") for s in stakeholders_data[:5])
        stk_detail = f"{stakeholder_count} found: {names}."
    else:
        stk_status = "rich"
        names = ", ".join(s.get("name", "?") for s in stakeholders_data[:5])
        stk_detail = f"{stakeholder_count} found: {names}."

    # 3. Memory type distribution
    type_rows = db.fetch_all(
        "SELECT memory_type, COUNT(*) FROM memories "
        "WHERE mind_id = %s AND is_current = true "
        "GROUP BY memory_type ORDER BY COUNT(*) DESC",
        [mind_id],
    )
    type_counts = {r[0]: r[1] for r in type_rows} if type_rows else {}
    total_memories = sum(type_counts.values())

    # Campaign history
    campaign_count = type_counts.get("campaign_outcome", 0)
    if campaign_count == 0:
        camp_status = "none"
        camp_detail = "No campaign outcomes tracked."
    elif campaign_count <= 2:
        camp_status = "sparse"
        camp_detail = f"{campaign_count} campaign(s) tracked."
    elif campaign_count <= 5:
        camp_status = "adequate"
        camp_detail = f"{campaign_count} campaigns tracked."
    else:
        camp_status = "rich"
        camp_detail = f"{campaign_count} campaigns with outcomes."

    # 4. Meeting history
    from coppermind_cmo.tools.daily_loop import _has_meeting_log_table
    if _has_meeting_log_table(db):
        meeting_row = db.fetch_one(
            "SELECT COUNT(*), MAX(start_time) FROM meeting_log "
            "WHERE mind_id = %s" + (" AND customer_id = %s" if customer_id else ""),
            [mind_id] + ([customer_id] if customer_id else []),
        )
        meeting_count = meeting_row[0] if meeting_row and meeting_row[0] else 0
        last_meeting = meeting_row[1] if meeting_row else None
    else:
        meeting_count = 0
        last_meeting = None

    if meeting_count == 0:
        meet_status = "none"
        meet_detail = "No meetings logged."
    elif meeting_count <= 2:
        meet_status = "sparse"
        meet_detail = f"{meeting_count} meeting(s) logged."
    elif meeting_count <= 5:
        meet_status = "adequate"
        meet_detail = f"{meeting_count} meetings logged."
    else:
        meet_status = "rich"
        last_str = last_meeting.strftime("%B %d") if last_meeting else ""
        meet_detail = f"{meeting_count} meetings, latest {last_str}."

    # 5. EOS configuration
    cadence_row = db.fetch_one(
        "SELECT cadence FROM client_minds WHERE id = %s", [mind_id],
    )
    cadence = parse_jsonb(cadence_row[0]) if cadence_row and cadence_row[0] else {}
    has_quarter = bool(cadence.get("quarter"))
    has_year = bool(cadence.get("year"))

    # Check for rocks
    try:
        rock_row = db.fetch_one(
            "SELECT COUNT(*) FROM rocks WHERE mind_id = %s", [mind_id],
        )
        rock_count = rock_row[0] if rock_row else 0
    except Exception:
        rock_count = 0

    if not has_quarter and not has_year:
        eos_status = "none"
        eos_detail = "Not configured."
    elif has_quarter and has_year and rock_count > 0:
        eos_status = "rich"
        eos_detail = f"Q{cadence['quarter']} {cadence['year']} active, {rock_count} rock(s) set."
    elif has_quarter and has_year:
        eos_status = "adequate"
        eos_detail = f"Q{cadence['quarter']} {cadence['year']} active."
    else:
        eos_status = "sparse"
        eos_detail = "Partially configured."

    # 6. Content themes
    theme_count = len(content_themes) if content_themes else 0
    if theme_count == 0:
        ct_status = "none"
        ct_detail = "No content themes configured."
    elif theme_count <= 2:
        ct_status = "sparse"
        ct_detail = f"{theme_count} theme(s): {', '.join(content_themes[:3])}."
    else:
        ct_status = "adequate" if theme_count <= 4 else "rich"
        ct_detail = f"{theme_count} themes: {', '.join(content_themes[:5])}."

    # 7. Overall memory depth
    if total_memories == 0:
        depth_status = "none"
        depth_detail = "No memories stored."
    elif total_memories < 10:
        depth_status = "sparse"
        depth_detail = f"{total_memories} memories across {len(type_counts)} types."
    elif total_memories < 50:
        depth_status = "adequate"
        depth_detail = f"{total_memories} memories across {len(type_counts)} types."
    else:
        depth_status = "rich"
        depth_detail = f"{total_memories} memories across {len(type_counts)} types."

    # Build dimensions list
    dimensions = [
        {"area": "Brand Voice", "status": bv_status, "detail": bv_detail,
         "suggestion": _DIMENSION_SUGGESTIONS["brand_voice"] if bv_status in ("none", "sparse") else None},
        {"area": "Stakeholders", "status": stk_status, "detail": stk_detail,
         "suggestion": _DIMENSION_SUGGESTIONS["stakeholders"] if stk_status in ("none", "sparse") else None},
        {"area": "Campaign History", "status": camp_status, "detail": camp_detail,
         "suggestion": _DIMENSION_SUGGESTIONS["campaign_history"] if camp_status in ("none", "sparse") else None},
        {"area": "Meeting History", "status": meet_status, "detail": meet_detail,
         "suggestion": _DIMENSION_SUGGESTIONS["meeting_history"] if meet_status in ("none", "sparse") else None},
        {"area": "EOS Configuration", "status": eos_status, "detail": eos_detail,
         "suggestion": _DIMENSION_SUGGESTIONS["eos_config"] if eos_status in ("none", "sparse") else None},
        {"area": "Content Themes", "status": ct_status, "detail": ct_detail,
         "suggestion": _DIMENSION_SUGGESTIONS["content_themes"] if ct_status in ("none", "sparse") else None},
        {"area": "Memory Depth", "status": depth_status, "detail": depth_detail,
         "suggestion": _DIMENSION_SUGGESTIONS["memory_depth"] if depth_status in ("none", "sparse") else None},
    ]

    # Count statuses
    status_counts = {"rich": 0, "adequate": 0, "sparse": 0, "none": 0}
    for d in dimensions:
        status_counts[d["status"]] = status_counts.get(d["status"], 0) + 1

    # Suggestions for gaps
    suggestions = [d["suggestion"] for d in dimensions if d.get("suggestion")]

    # Overall assessment
    if status_counts["none"] + status_counts["sparse"] == 0:
        overall = "Coppermind knows this client well."
    elif status_counts["rich"] + status_counts["adequate"] > status_counts["none"] + status_counts["sparse"]:
        overall = "Good coverage with some gaps to fill."
    else:
        overall = "Early stage — fill the gaps below to unlock better briefings."

    return {
        "client_name": mind_name,
        "overall": overall,
        "dimensions": dimensions,
        "suggestions": suggestions,
        "memory_type_distribution": type_counts,
        "total_memories": total_memories,
        "status_summary": status_counts,
    }


def register(mcp_server):
    """Register intelligence tools on the MCP server."""
    from coppermind_cmo.server import get_db, get_config, get_active_mind, set_last_tool_call, get_customer_id
    from coppermind_cmo.background import attach_notifications
    from coppermind_cmo.tools.minds import _verify_mind_access
    from coppermind_cmo.errors import ACCESS_DENIED
    from coppermind_cmo.resilience import safe_tool_call
    from coppermind_cmo.tools.access import _get_access_level

    @mcp_server.tool()
    @safe_tool_call("prep_meeting")
    def prep_meeting(
        topics: list[str] | None = None,
        meeting_type: str | None = None,
        limit: int = 50,
        save: bool = False,
        meeting_start_time: str | None = None,
    ) -> dict:
        """Retrieve structured client data for meeting prep. You write the polished brief.

        For best results, provide topics and meeting_type. If not specified,
        all client memories are returned unfiltered.

        You receive structured data (memories by type, stakeholders, brand voice, cadence).
        Write a polished, conversational brief from it.

        When back-to-back meetings with different clients are within 30 min,
        a context switch section is automatically included in the brief.

        Parameters:
        - topics: List of discussion topics (recommended for best results)
        - meeting_type: review, catchup, planning, or topic (optional)
        - limit: Maximum memories to consider, default 50 (optional)
        - save: If true, persist the brief for later retrieval via get_last_brief (default false)
        - meeting_start_time: ISO 8601 start time for context switch detection (optional)
        """
        set_last_tool_call("prep_meeting")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()

        # Resolve access level and build memory query filters
        access_level = None
        access_filter_sql = ""
        access_filter_params: list = []
        if active_mind:
            from coppermind_cmo.tools.access import _access_filters, get_viewer_allowed_types
            from coppermind_cmo.utils import parse_jsonb
            access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
            if access_level is not None:
                sharing_row = get_db().fetch_one(
                    "SELECT sharing_config FROM client_minds WHERE id = %s",
                    [active_mind[0]],
                )
                sharing_config = parse_jsonb(sharing_row[0]) if sharing_row and sharing_row[0] else None
                allowed_types = get_viewer_allowed_types(sharing_config)
                access_filter_sql, access_filter_params = _access_filters(
                    access_level, get_customer_id() or "", allowed_types
                )

        result = _prep_meeting(
            topics, meeting_type, limit, get_db(), get_config(), active_mind,
            save=save,
            access_filter_sql=access_filter_sql,
            access_filter_params=access_filter_params,
            customer_id=get_customer_id(),
            meeting_start_time=meeting_start_time,
        )
        # Strip stakeholder data for non-owners
        if isinstance(result, dict) and "error" not in result and active_mind:
            if access_level != "owner":
                result.pop("stakeholders", None)
                # Strip stakeholder sections from brief text
                brief = result.get("brief_markdown")
                if brief:
                    import re
                    result["brief_markdown"] = re.sub(
                        r'## (?:Key )?Stakeholder[^\n]*\n(?:(?!## ).)*',
                        '', brief, flags=re.DOTALL
                    ).strip()
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("get_campaign_history")
    def get_campaign_history(limit: int = 10, offset: int = 0) -> list | dict:
        """Review campaign results and learnings for the active client."""
        set_last_tool_call("get_campaign_history")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()

        # Resolve access level for viewer filtering
        ch_access_level = None
        if active_mind:
            ch_access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
            # Check if campaign_outcome is in viewer's allowed types
            if ch_access_level is not None and ch_access_level != "owner":
                from coppermind_cmo.tools.access import get_viewer_allowed_types
                from coppermind_cmo.utils import parse_jsonb
                sharing_row = get_db().fetch_one(
                    "SELECT sharing_config FROM client_minds WHERE id = %s",
                    [active_mind[0]],
                )
                sharing_config = parse_jsonb(sharing_row[0]) if sharing_row and sharing_row[0] else None
                allowed_types = get_viewer_allowed_types(sharing_config)
                # If CMO narrowed access to exclude campaign_outcome, return empty
                if allowed_types is not None and "campaign_outcome" not in allowed_types:
                    return []

        return _get_campaign_history(
            limit, offset, get_db(), active_mind,
            access_level=ch_access_level,
            caller_id=get_customer_id(),
        )

    @mcp_server.tool()
    @safe_tool_call("get_last_brief")
    def get_last_brief() -> dict:
        """Retrieve the most recently saved meeting brief for the active client."""
        set_last_tool_call("get_last_brief")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        if active_mind:
            access_level = _get_access_level(active_mind[0], get_customer_id(), get_db())
            if access_level != "owner":
                return ACCESS_DENIED("This action requires owner access.")
        result = _get_last_brief(get_db(), active_mind)
        return attach_notifications(result, customer_id=get_customer_id(), db=get_db())

    @mcp_server.tool()
    @safe_tool_call("get_knowledge_health")
    def get_knowledge_health() -> dict:
        """Show knowledge coverage health for the active client mind.

        Evaluates 7 dimensions: brand voice, stakeholders, campaign history,
        meeting history, EOS configuration, content themes, and memory depth.
        Each gets a qualitative score (none/sparse/adequate/rich) with
        actionable suggestions for gaps.

        Use this to:
        - Check if a client mind is well-configured after onboarding
        - Find gaps in knowledge coverage
        - Guide what to ingest or discuss next
        """
        set_last_tool_call("get_knowledge_health")
        active_mind = get_active_mind()
        if active_mind and not _verify_mind_access(active_mind[0], get_customer_id(), get_db()):
            return ACCESS_DENIED()
        return attach_notifications(
            _get_knowledge_health(get_db(), active_mind, customer_id=get_customer_id()),
            customer_id=get_customer_id(), db=get_db(),
        )
