"""Claude UserPromptSubmit hook for lightweight meeting auto-prep.

Checks Google Calendar directly from the hook (no visible MCP call).
Only injects context when a meeting is actually found in the next 45 min.
"""

from __future__ import annotations

import json
import os
import urllib.request
import urllib.parse
from datetime import datetime, timedelta, timezone
from pathlib import Path
import sys

AUTO_PREP_INTERVAL_MINUTES = 45
DEFAULT_STATE_PATH = Path.home() / ".coppermind" / "auto-prep-hook-state.json"
DEFAULT_SESSION_KEY = "global"
EXPLICIT_PREP_MARKERS = (
    "/cmo-autoprep",
    "prep my meeting",
    "prepare my meeting",
    "meeting brief",
)

# Google OAuth creds (same as google-workspace MCP)
_GOOGLE_CLIENT_ID = os.environ.get("GOOGLE_CLIENT_ID", "")
_GOOGLE_CLIENT_SECRET = os.environ.get("GOOGLE_CLIENT_SECRET", "")
_GOOGLE_REFRESH_TOKEN = os.environ.get("GOOGLE_REFRESH_TOKEN", "")
AUTO_PREP_CONTEXT = (
    "COPPERMIND AUTO-PREP:\n"
    "A meeting is coming up soon. Do NOT call list_events — the hook already confirmed a meeting exists.\n"
    "List client minds once and fuzzy-match the meeting info below to a mind.\n"
    "If exactly one match is confident, switch to that client and run prep_meeting(save=true).\n"
    "After saving the prep, also call log_meeting_event(title=..., start_time=..., calendar_event_id=..., mind_id=..., match_confidence='confident') to record this meeting.\n"
    "After saving the prep, show a brief one-line notice: '📋 Auto-prepped for [Client Name] — [Meeting Title] in [N] min'\n"
    "If no mind matches, say nothing. Do not output anything else.\n"
    "Do not auto-prep when the user is already explicitly asking for meeting prep."
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _load_state(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _save_state(path: Path, state: dict) -> None:
    import os
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    path.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass


def _prompt_requests_explicit_prep(prompt: str) -> bool:
    normalized = prompt.lower()
    return any(marker in normalized for marker in EXPLICIT_PREP_MARKERS)


def _recently_injected(state: dict, session_key: str, now: datetime) -> bool:
    session_state = state.get("sessions", {})
    if not isinstance(session_state, dict):
        return False
    raw_ts = session_state.get(session_key)
    if not raw_ts:
        return False
    from coppermind_cmo.parsing import parse_datetime
    last_injected = parse_datetime(raw_ts, coerce_utc=True)
    if last_injected is None:
        return False
    return now - last_injected < timedelta(minutes=AUTO_PREP_INTERVAL_MINUTES)


def _get_access_token() -> str | None:
    """Exchange refresh token for a short-lived access token."""
    if not (_GOOGLE_CLIENT_ID and _GOOGLE_CLIENT_SECRET and _GOOGLE_REFRESH_TOKEN):
        return None
    try:
        data = urllib.parse.urlencode({
            "client_id": _GOOGLE_CLIENT_ID,
            "client_secret": _GOOGLE_CLIENT_SECRET,
            "refresh_token": _GOOGLE_REFRESH_TOKEN,
            "grant_type": "refresh_token",
        }).encode()
        req = urllib.request.Request("https://oauth2.googleapis.com/token", data=data, method="POST")
        with urllib.request.urlopen(req, timeout=5) as resp:
            return json.loads(resp.read()).get("access_token")
    except Exception:
        return None


def _check_upcoming_meetings(now: datetime) -> list[dict]:
    """Check Google Calendar for meetings in the next 45 min. Returns [] on any failure."""
    token = _get_access_token()
    if not token:
        return []
    try:
        time_min = now.isoformat()
        time_max = (now + timedelta(minutes=45)).isoformat()
        params = urllib.parse.urlencode({
            "timeMin": time_min,
            "timeMax": time_max,
            "maxResults": 5,
            "singleEvents": "true",
            "orderBy": "startTime",
        })
        url = f"https://www.googleapis.com/calendar/v3/calendars/primary/events?{params}"
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
        return data.get("items", [])
    except Exception:
        return []


def build_hook_output(
    prompt: str,
    *,
    session_id: str | None = None,
    now: datetime | None = None,
    state_path: Path | None = None,
) -> dict | None:
    """Return hook JSON payload when auto-prep context should be injected."""
    now = now or _utc_now()
    state_path = state_path or DEFAULT_STATE_PATH
    session_key = session_id or DEFAULT_SESSION_KEY

    if not prompt.strip():
        return None
    if _prompt_requests_explicit_prep(prompt):
        return None

    state = _load_state(state_path)
    if _recently_injected(state, session_key, now):
        return None

    # Check calendar BEFORE injecting — no meeting = no noise
    meetings = _check_upcoming_meetings(now)
    if not meetings:
        return None

    # Build meeting info for Claude so it doesn't need to call list_events
    meeting_lines = []
    for m in meetings:
        title = m.get("summary", "Untitled")
        start = m.get("start", {}).get("dateTime", "")
        attendees = [a.get("email", "") for a in m.get("attendees", [])]
        meeting_lines.append(f"  - {title} at {start} (attendees: {', '.join(attendees) or 'none listed'})")
    meeting_info = "\n".join(meeting_lines)

    sessions = state.get("sessions", {})
    if not isinstance(sessions, dict):
        sessions = {}
    sessions[session_key] = now.isoformat()
    try:
        _save_state(state_path, {"sessions": sessions})
    except OSError:
        return None

    context = AUTO_PREP_CONTEXT + f"\n\nUpcoming meetings:\n{meeting_info}"
    return {
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": context,
        }
    }


def main() -> int:
    try:
        event = json.load(sys.stdin)
    except json.JSONDecodeError:
        return 0

    prompt = event.get("prompt", "")
    output = build_hook_output(prompt, session_id=event.get("session_id"))
    if output:
        print(json.dumps(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
