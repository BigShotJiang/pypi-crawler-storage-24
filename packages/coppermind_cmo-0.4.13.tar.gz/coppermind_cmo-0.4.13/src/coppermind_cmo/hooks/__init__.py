"""Bundled Claude hook scripts for Coppermind CMO."""
