"""Resilience utilities: error classification, retry, and tool safety.

Provides:
- classify_error(): categorize exceptions for retry/fail decisions
- resilient_call(): wrap a callable with retry and error classification
- safe_tool_call(): decorator for MCP tool handlers to catch all exceptions
"""

import time
import traceback
from functools import wraps
from typing import Any, Callable

import httpx

from coppermind_cmo.errors import tool_error
from coppermind_cmo.log import ToolLogger

logger = ToolLogger("resilience")


# ---------------------------------------------------------------------------
# Error classification
# ---------------------------------------------------------------------------

def classify_error(exc: Exception) -> str:
    """Classify an exception into a retry/fail category.

    Returns one of: transient, rate_limit, auth, input, server, unknown.
    """
    # httpx HTTP status errors
    if isinstance(exc, httpx.HTTPStatusError):
        status = exc.response.status_code
        if status == 429:
            return "rate_limit"
        if status in (401, 403):
            return "auth"
        if status in (400, 404, 422):
            return "input"
        if status in (502, 503, 504):
            return "transient"
        if status >= 500:
            return "server"
        return "unknown"

    # Connection and timeout errors are transient
    if isinstance(exc, (
        ConnectionError,
        TimeoutError,
        httpx.ConnectError,
        httpx.TimeoutException,
        httpx.RemoteProtocolError,
    )):
        return "transient"

    # OSError subclasses for network issues
    if isinstance(exc, OSError) and exc.errno in (
        111,  # Connection refused
        110,  # Connection timed out
        104,  # Connection reset by peer
    ):
        return "transient"

    # ValueError/TypeError are typically input problems
    if isinstance(exc, (ValueError, TypeError)):
        return "input"

    # KeyError is usually a programming error, not transient
    if isinstance(exc, KeyError):
        return "input"

    return "unknown"


def _is_retryable(category: str) -> bool:
    """Whether an error category should be retried."""
    return category in ("transient", "rate_limit", "server")


# ---------------------------------------------------------------------------
# Retry wrapper
# ---------------------------------------------------------------------------

def resilient_call(
    func: Callable,
    *args,
    service_name: str = "unknown",
    max_attempts: int = 3,
    backoff_base: float = 1.0,
    **kwargs,
) -> Any:
    """Call func with retry on transient failures.

    Args:
        func: The callable to invoke.
        service_name: Name for logging (e.g. "gateway", "database").
        max_attempts: Maximum number of attempts (default 3).
        backoff_base: Base delay in seconds (doubles each retry: 1s, 2s, 4s).
        *args, **kwargs: Passed through to func.

    Returns:
        The return value of func on success.

    Raises:
        The last exception if all retries are exhausted or error is non-retryable.
    """
    last_exc = None

    for attempt in range(1, max_attempts + 1):
        try:
            return func(*args, **kwargs)
        except Exception as exc:
            last_exc = exc
            category = classify_error(exc)

            if not _is_retryable(category) or attempt == max_attempts:
                logger.warn(
                    f"{service_name} call failed (attempt {attempt}/{max_attempts}, "
                    f"category={category})",
                    service=service_name,
                    attempt=attempt,
                    error_category=category,
                    error=str(exc),
                )
                raise

            # Calculate backoff
            delay = backoff_base * (2 ** (attempt - 1))

            # For rate limits, respect Retry-After header if available
            if category == "rate_limit" and isinstance(exc, httpx.HTTPStatusError):
                retry_after = exc.response.headers.get("Retry-After")
                if retry_after:
                    try:
                        delay = max(delay, float(retry_after))
                    except (ValueError, TypeError):
                        pass

            logger.info(
                f"{service_name} call failed, retrying in {delay:.1f}s "
                f"(attempt {attempt}/{max_attempts})",
                service=service_name,
                attempt=attempt,
                error_category=category,
                error=str(exc),
                backoff_seconds=delay,
            )
            time.sleep(delay)

    # Should not reach here, but just in case
    raise last_exc  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Tool-level exception safety decorator
# ---------------------------------------------------------------------------

def safe_tool_call(tool_name: str):
    """Decorator that catches all exceptions in an MCP tool handler and returns
    a structured error dict instead of crashing.

    Usage:
        @safe_tool_call("store_memory")
        def store_memory(...) -> dict:
            ...

    Any unhandled exception is logged and returned as:
        {"error": True, "code": "INTERNAL_ERROR", "message": "...user-friendly..."}
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            try:
                return func(*args, **kwargs)
            except SystemExit:
                raise  # never swallow SystemExit
            except Exception as exc:
                category = classify_error(exc)
                logger.error(
                    f"Unhandled exception in tool '{tool_name}'",
                    tool=tool_name,
                    error_category=category,
                    error_type=type(exc).__name__,
                    error=str(exc),
                    traceback=traceback.format_exc(),
                )

                # Map category to user-friendly message
                if category == "transient":
                    return tool_error(
                        "SERVICE_UNAVAILABLE",
                        f"A service is temporarily unavailable. Please try again in a moment.",
                    )
                elif category == "rate_limit":
                    return tool_error(
                        "RATE_LIMITED",
                        "Too many requests. Please wait a moment and try again.",
                    )
                elif category == "auth":
                    return tool_error(
                        "ACCESS_DENIED",
                        "Authentication failed. Check your API key or contact coppermind@volacci.com.",
                    )
                elif category == "input":
                    return tool_error(
                        "INVALID_INPUT",
                        f"Invalid input: {exc}",
                    )
                else:
                    return tool_error(
                        "INTERNAL_ERROR",
                        "An unexpected error occurred. Please try again.",
                    )
        return wrapper
    return decorator
