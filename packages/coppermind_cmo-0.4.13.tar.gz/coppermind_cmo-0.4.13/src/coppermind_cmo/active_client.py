"""Active client state file and terminal title management.

Writes ~/.coppermind/active-client.json on every switch_client call
so external tools (status lines, dashboards) can read the active state.
Also emits ANSI escape to set terminal tab title.
"""

import atexit
import json
import os
import sys
import tempfile
from datetime import datetime, timezone

_STATE_DIR = os.path.expanduser("~/.coppermind")
_STATE_FILE = os.path.join(_STATE_DIR, "active-client.json")
_cleanup_registered = False


def _format_cadence(cadence: dict) -> str:
    """Format cadence dict into a human-readable string like 'Q1 Sprint 4 of 6'."""
    if not cadence:
        return ""
    parts = []
    if cadence.get("quarter"):
        parts.append(f"Q{cadence['quarter']}")
    if cadence.get("sprint") is not None and cadence.get("sprints_per_quarter") is not None:
        parts.append(f"Sprint {cadence['sprint']} of {cadence['sprints_per_quarter']}")
    elif cadence.get("sprint") is not None:
        parts.append(f"Sprint {cadence['sprint']}")
    return " ".join(parts)


def update_active_client(
    client_name: str,
    mind_id: str,
    memory_count: int,
    cadence: dict | None = None,
    brand_color: str | None = None,
) -> None:
    """Write active client state to JSON file and update terminal title."""
    cadence_str = _format_cadence(cadence or {})

    # Write state file atomically
    state = {
        "client_name": client_name,
        "mind_id": mind_id,
        "memory_count": memory_count,
        "cadence": cadence_str,
        "updated_at": datetime.now(timezone.utc).isoformat(),
    }
    if brand_color:
        state["brand_color"] = brand_color
    try:
        os.makedirs(_STATE_DIR, exist_ok=True)
        try:
            os.chmod(_STATE_DIR, 0o700)
        except OSError:
            pass
        fd, tmp_path = tempfile.mkstemp(dir=_STATE_DIR, suffix=".tmp")
        os.fchmod(fd, 0o600)
        try:
            with os.fdopen(fd, "w") as f:
                json.dump(state, f)
            os.replace(tmp_path, _STATE_FILE)
        except Exception:
            # Clean up temp file on failure
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise
    except Exception:
        pass  # non-critical — don't crash the tool

    # Register cleanup on first write
    global _cleanup_registered
    if not _cleanup_registered:
        atexit.register(clear_active_client)
        _cleanup_registered = True

    # Set terminal tab title via ANSI escape on stderr
    title = f"Coppermind: {client_name}"
    if cadence_str:
        title += f" ({cadence_str})"
    try:
        sys.stderr.write(f"\033]0;{title}\007")
        sys.stderr.flush()
    except Exception:
        pass


def clear_active_client() -> None:
    """Remove the active client state file (called on shutdown)."""
    try:
        os.unlink(_STATE_FILE)
    except OSError:
        pass
