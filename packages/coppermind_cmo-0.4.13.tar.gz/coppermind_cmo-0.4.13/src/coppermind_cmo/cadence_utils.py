"""Cadence and sprint utilities shared across tool modules."""

from datetime import date, datetime


def get_current_sprint(cadence: dict, sprint_plan: dict | None = None) -> int | None:
    """Compute current sprint number from sprint plan dates, falling back to cadence.sprint.

    Args:
        cadence: The cadence JSONB from client_minds (has type, year, quarter, sprint, sprints_per_quarter)
        sprint_plan: Optional sprint_plan row with sprint_end_dates JSONB array of ISO date strings

    Returns:
        Current sprint number (1-based) or None if cannot be determined.
    """
    # If sprint_plan has dates, compute from current date
    if sprint_plan and sprint_plan.get("sprint_end_dates"):
        dates = sprint_plan["sprint_end_dates"]
        if isinstance(dates, list) and len(dates) > 0:
            today = date.today()
            valid_count = 0
            for i, d in enumerate(dates):
                try:
                    if isinstance(d, str):
                        end_date = datetime.strptime(d, "%Y-%m-%d").date()
                    elif isinstance(d, date):
                        end_date = d
                    else:
                        continue
                    valid_count += 1
                    # Sprint i+1 ends on this date
                    # Sprint 1 starts at beginning, ends on dates[0]
                    # Sprint N starts after dates[N-2], ends on dates[N-1]
                    if today <= end_date:
                        return i + 1
                except (ValueError, TypeError):
                    continue
            # All valid dates have passed -- return count of valid sprints
            if valid_count > 0:
                return valid_count

    # Fall back to cadence.sprint
    sprint = cadence.get("sprint")
    if sprint is not None and isinstance(sprint, int) and sprint >= 1:
        return sprint

    return None
