"""CLI entry point for `coppermind-update`.

Manual update command that beta testers can run when auto-update fails
or when they want to force an upgrade immediately.
"""

import os
import shutil
import subprocess
import sys
from pathlib import Path


def _find_uv() -> str | None:
    """Locate the uv binary."""
    found = shutil.which("uv")
    if found:
        return found
    common_paths = [
        Path.home() / ".local" / "bin" / "uv",
        Path.home() / ".cargo" / "bin" / "uv",
        Path("/usr/local/bin/uv"),
        Path("/opt/homebrew/bin/uv"),
    ]
    for path in common_paths:
        if path.exists() and os.access(path, os.X_OK):
            return str(path)
    return None


def _find_pipx() -> str | None:
    """Locate pipx as a fallback."""
    return shutil.which("pipx")


def main():
    """Run the coppermind-update command."""
    # Show current version
    try:
        from importlib.metadata import version as pkg_version
        current = pkg_version("coppermind-cmo")
    except Exception:
        current = "unknown"

    print(f"Coppermind CMO current version: {current}")
    print()

    # Find installer
    uv_path = _find_uv()
    pipx_path = _find_pipx() if not uv_path else None

    if uv_path:
        cmd = [uv_path, "tool", "upgrade", "coppermind-cmo"]
        installer_name = "uv"
    elif pipx_path:
        cmd = [pipx_path, "upgrade", "coppermind-cmo"]
        installer_name = "pipx"
    else:
        print("Error: Neither uv nor pipx found.")
        print()
        print("Install uv first:")
        print("  curl -LsSf https://astral.sh/uv/install.sh | sh")
        print()
        print("Then retry:")
        print("  coppermind-update")
        sys.exit(1)

    print(f"Upgrading with {installer_name}...")
    print(f"  {' '.join(cmd)}")
    print()

    try:
        result = subprocess.run(
            cmd,
            timeout=120,
            env={**os.environ, "UV_NO_PROGRESS": "1"},
        )
    except subprocess.TimeoutExpired:
        print("Error: Update timed out after 120 seconds.")
        sys.exit(1)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

    if result.returncode != 0:
        print()
        print("Update failed. Try manually:")
        if uv_path:
            print(f"  {uv_path} tool upgrade coppermind-cmo")
        else:
            print(f"  {pipx_path} upgrade coppermind-cmo")
        sys.exit(1)

    # Show new version
    print()
    try:
        # Re-check by running the updated package
        ver_result = subprocess.run(
            [sys.executable, "-c",
             "from importlib.metadata import version; print(version('coppermind-cmo'))"],
            capture_output=True, text=True, timeout=10,
        )
        new_version = ver_result.stdout.strip() if ver_result.returncode == 0 else "unknown"
    except Exception:
        new_version = "unknown"

    if new_version == current:
        print(f"Already up to date: {current}")
    else:
        print(f"Updated: {current} -> {new_version}")

    print()
    print("Restart Claude to use the new version.")


if __name__ == "__main__":
    main()
