"""Tests for coppermind_cmo.utils — shared utility functions."""

import os
import sys
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch
from coppermind_cmo.utils import get_mind_cadence, secure_write, rotate_log


class TestGetMindCadence:
    def test_returns_dict_when_row_is_dict(self):
        """Normal case: cadence is a parsed dict from JSONB."""
        db = MagicMock()
        db.fetch_one.return_value = ({"type": "eos", "year": 2026, "quarter": 1},)
        result = get_mind_cadence("mind-1", db)
        assert result == {"type": "eos", "year": 2026, "quarter": 1}

    def test_returns_empty_dict_when_row_is_string(self):
        """When psycopg2 returns cadence as a raw JSON string, return {} safely."""
        db = MagicMock()
        db.fetch_one.return_value = ('{"type": "eos", "year": 2026}',)
        result = get_mind_cadence("mind-1", db)
        assert result == {}

    def test_returns_empty_dict_when_row_is_none(self):
        """No row found — return {}."""
        db = MagicMock()
        db.fetch_one.return_value = None
        result = get_mind_cadence("mind-1", db)
        assert result == {}

    def test_returns_empty_dict_when_cadence_is_none(self):
        """Row exists but cadence column is NULL — return {}."""
        db = MagicMock()
        db.fetch_one.return_value = (None,)
        result = get_mind_cadence("mind-1", db)
        assert result == {}

    def test_returns_empty_dict_when_cadence_is_empty_dict(self):
        """Row exists but cadence is empty dict — falsy so returns {}."""
        db = MagicMock()
        db.fetch_one.return_value = ({},)
        result = get_mind_cadence("mind-1", db)
        assert result == {}

    def test_returns_empty_dict_when_cadence_is_list(self):
        """Unexpected type (list) — isinstance(row[0], dict) is False -> return {}."""
        db = MagicMock()
        db.fetch_one.return_value = ([1, 2, 3],)
        result = get_mind_cadence("mind-1", db)
        assert result == {}


class TestSecureWriteAtomic:
    def test_secure_write_atomic_no_temp_left(self, tmp_path):
        """Write succeeds, no .tmp files remain in the parent dir."""
        target = tmp_path / "subdir" / "state.json"
        secure_write(target, '{"key": "value"}')

        assert target.read_text() == '{"key": "value"}'
        # No temp files should remain
        tmp_files = list(tmp_path.joinpath("subdir").glob("*.tmp"))
        assert tmp_files == []

    def test_secure_write_no_partial_on_failure(self, tmp_path):
        """Mock os.replace to raise; verify original file unchanged + temp cleaned up."""
        target = tmp_path / "data.txt"
        target.write_text("original content")

        with patch("coppermind_cmo.utils.os.replace", side_effect=OSError("disk full")):
            with pytest.raises(OSError, match="disk full"):
                secure_write(target, "new content")

        # Original file should be unchanged
        assert target.read_text() == "original content"
        # No temp files should remain
        tmp_files = list(tmp_path.glob("*.tmp"))
        assert tmp_files == []

    @pytest.mark.skipif(sys.platform == "win32", reason="fchmod not available on Windows")
    def test_secure_write_permissions(self, tmp_path):
        """Verify file has 0o600 permissions (POSIX only)."""
        target = tmp_path / "secret.txt"
        secure_write(target, "sensitive data")

        mode = target.stat().st_mode & 0o777
        assert mode == 0o600


class TestRotateLog:
    def test_no_file(self, tmp_path):
        """rotate_log on non-existent file does nothing."""
        rotate_log(tmp_path / "nope.log")

    def test_small_file_no_rotation(self, tmp_path):
        """File under max_bytes is not rotated."""
        log = tmp_path / "test.log"
        log.write_text("small")
        rotate_log(log, max_bytes=100)
        assert log.exists()
        assert not (tmp_path / "test.log.1").exists()

    def test_large_file_rotated(self, tmp_path):
        """File over max_bytes is rotated to .log.1."""
        log = tmp_path / "test.log"
        log.write_text("x" * 200)
        rotate_log(log, max_bytes=100)
        assert not log.exists()
        assert (tmp_path / "test.log.1").exists()

    def test_cascading_rotation(self, tmp_path):
        """Existing .log.1 shifts to .log.2."""
        log = tmp_path / "test.log"
        log.write_text("x" * 200)
        (tmp_path / "test.log.1").write_text("old1")
        rotate_log(log, max_bytes=100)
        assert (tmp_path / "test.log.1").exists()
        assert (tmp_path / "test.log.2").read_text() == "old1"

    def test_max_files_deletes_oldest(self, tmp_path):
        """When max_files reached, oldest is deleted."""
        log = tmp_path / "test.log"
        log.write_text("x" * 200)
        (tmp_path / "test.log.1").write_text("old1")
        (tmp_path / "test.log.2").write_text("old2")
        (tmp_path / "test.log.3").write_text("old3")
        rotate_log(log, max_bytes=100, max_files=3)
        assert not (tmp_path / "test.log.4").exists()
        assert not log.exists()

    def test_age_cleanup(self, tmp_path):
        """Old rotated files are deleted by age."""
        import time
        log = tmp_path / "test.log"
        log.write_text("current")
        old = tmp_path / "test.log.1"
        old.write_text("ancient")
        # Set mtime to 30 days ago
        old_time = time.time() - (30 * 86400)
        os.utime(old, (old_time, old_time))
        rotate_log(log, max_bytes=999999, max_age_days=7)
        assert not old.exists()
        assert log.exists()  # current log untouched (under max_bytes)
