"""Tests for IngestEngine — chunking, extraction, dedup."""

import hashlib
import pytest
from unittest.mock import patch, MagicMock
import json


class TestChunkText:
    def test_short_text_single_chunk(self):
        from coppermind_cmo.ingest import chunk_text
        result = chunk_text("Hello world")
        assert result == ["Hello world"]

    def test_empty_text_returns_empty(self):
        from coppermind_cmo.ingest import chunk_text
        result = chunk_text("")
        assert result == []

    def test_whitespace_only_returns_empty(self):
        from coppermind_cmo.ingest import chunk_text
        result = chunk_text("   \n\t  ")
        assert result == []

    def test_long_text_chunks_with_overlap(self):
        from coppermind_cmo.ingest import chunk_text
        text = "A" * 5000
        chunks = chunk_text(text, chunk_size=2000, overlap=200)
        assert len(chunks) == 3
        # First chunk: 0-2000
        assert len(chunks[0]) == 2000
        # Second chunk starts at 1800 (2000 - 200 overlap)
        assert len(chunks[1]) == 2000
        # Third chunk: remainder
        assert len(chunks[2]) > 0

    def test_chunks_skip_under_min_length(self):
        from coppermind_cmo.ingest import chunk_text
        # Text that produces a trailing chunk under 10 chars
        text = "A" * 2000 + "B" * 5
        chunks = chunk_text(text, chunk_size=2000, overlap=0)
        # The 5-char trailing chunk should be skipped
        assert len(chunks) == 1
        assert len(chunks[0]) == 2000

    def test_respects_custom_chunk_size(self):
        from coppermind_cmo.ingest import chunk_text
        text = "word " * 100  # 500 chars
        chunks = chunk_text(text, chunk_size=100, overlap=20)
        assert len(chunks) > 1
        assert all(len(c) <= 100 for c in chunks)

    def test_prefers_sentence_boundaries(self):
        from coppermind_cmo.ingest import chunk_text
        # Create text with clear sentence boundaries
        sentences = [f"Sentence number {i} is here. " for i in range(30)]
        text = "".join(sentences)  # ~30 * ~27 chars = ~810 chars
        chunks = chunk_text(text, chunk_size=200, overlap=30)
        # Each chunk should end at a sentence boundary (period + space)
        for chunk in chunks[:-1]:  # last chunk may not
            assert chunk.rstrip().endswith("."), f"Chunk doesn't end at sentence: '{chunk[-30:]}'"


class TestExtractMemoriesFromChunk:
    @patch("coppermind_cmo.ingest.call_llm")
    def test_extracts_valid_memories(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Acme paused LinkedIn ads through Q2", "memory_type": "decision", "confidence": 0.9},
            {"content": "Sarah is VP of Marketing", "memory_type": "stakeholder", "confidence": 0.85},
        ])
        result = extract_memories_from_chunk("Some meeting transcript chunk", mock_config)
        assert len(result) == 2
        assert result[0]["content"] == "Acme paused LinkedIn ads through Q2"
        assert result[0]["memory_type"] == "decision"

    @patch("coppermind_cmo.ingest.call_llm")
    def test_filters_low_confidence(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Maybe something happened", "memory_type": "fact", "confidence": 0.1},
        ])
        result = extract_memories_from_chunk("chunk", mock_config)
        assert len(result) == 0

    @patch("coppermind_cmo.ingest.call_llm")
    def test_filters_short_content(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Hi", "memory_type": "fact", "confidence": 0.9},
        ])
        result = extract_memories_from_chunk("chunk", mock_config)
        assert len(result) == 0

    @patch("coppermind_cmo.ingest.call_llm")
    def test_filters_invalid_memory_type(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = json.dumps([
            {"content": "Some valid content here", "memory_type": "invalid_type", "confidence": 0.9},
        ])
        result = extract_memories_from_chunk("chunk", mock_config)
        assert len(result) == 0

    @patch("coppermind_cmo.ingest.call_llm")
    def test_returns_none_on_llm_failure(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = None
        result = extract_memories_from_chunk("chunk", mock_config)
        assert result is None

    @patch("coppermind_cmo.ingest.call_llm")
    def test_handles_malformed_json(self, mock_llm, mock_config):
        from coppermind_cmo.ingest import extract_memories_from_chunk
        mock_llm.return_value = "not valid json at all"
        result = extract_memories_from_chunk("chunk", mock_config)
        assert result == []


class TestIngestEngine:
    def _make_engine(self, mock_db, mock_config, store_fn=None):
        from coppermind_cmo.ingest import IngestEngine
        active_mind = ("mind-uuid", "Acme Corp")
        if store_fn is None:
            store_fn = MagicMock(return_value={"memory_id": "mem-uuid"})
        return IngestEngine(mock_db, mock_config, active_mind, store_fn=store_fn)

    def test_init_sets_attributes(self, mock_db, mock_config):
        engine = self._make_engine(mock_db, mock_config)
        assert engine.mind_id == "mind-uuid"
        assert engine.mind_name == "Acme Corp"

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_process_source_stores_extracted_memories(
        self, mock_extract, mock_db, mock_config,
    ):
        mock_db.fetch_one.return_value = None  # no hash match
        mock_db.execute_returning.return_value = ("source-uuid",)
        mock_extract.return_value = [
            {"content": "A decision was made", "memory_type": "decision", "confidence": 0.9},
        ]
        mock_store = MagicMock(return_value={"memory_id": "mem-uuid", "summary": "A decision"})

        engine = self._make_engine(mock_db, mock_config, store_fn=mock_store)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/path/to/session.jsonl",
            content="Short text under chunk size",
        )

        assert result["new"] + result["updated"] >= 1
        mock_store.assert_called_once()

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_skips_chunk_with_existing_hash(
        self, mock_extract, mock_db, mock_config,
    ):
        # fetch_one calls: schema check (None=no table), source lookup, hash check
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None  # force re-check
        mock_db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table → table doesn't exist
            ("source-uuid",),  # _get_or_create_source finds existing source
            ("log-uuid",),     # _check_hash finds existing hash for this mind
        ]

        engine = self._make_engine(mock_db, mock_config)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/path/to/session.jsonl",
            content="Already processed content",
        )

        assert result["skipped"] >= 1
        mock_extract.assert_not_called()

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_refresh_mode_reprocesses_existing_hash(
        self, mock_extract, mock_db, mock_config,
    ):
        # fetch_one calls: schema check (no table), source lookup
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None  # force re-check
        mock_db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table → table doesn't exist
            ("source-uuid",),  # _get_or_create_source finds existing source
        ]
        mock_extract.return_value = []

        engine = self._make_engine(mock_db, mock_config)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/path/to/session.jsonl",
            content="Previously processed content",
            refresh=True,
        )

        mock_extract.assert_called_once()


class TestSupersedeOld:
    """Finding 7: Supersede old memories on re-ingestion."""

    def _make_engine(self, mock_db, mock_config, store_fn=None, memory_source_type="folder_watch"):
        from coppermind_cmo.ingest import IngestEngine
        active_mind = ("mind-uuid", "Acme Corp")
        if store_fn is None:
            store_fn = MagicMock(return_value={"memory_id": "mem-uuid"})
        return IngestEngine(
            mock_db, mock_config, active_mind,
            store_fn=store_fn,
            memory_source_type=memory_source_type,
        )

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_supersede_old_marks_memories_not_current(
        self, mock_extract, mock_db, mock_config,
    ):
        """supersede_old=True should UPDATE old memories to is_current=false."""
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table -> no table
            ("source-uuid",),  # _get_or_create_source
            None,              # _check_hash -> not processed
        ]
        mock_extract.return_value = [{"content": "New info", "memory_type": "fact", "confidence": 0.9}]

        engine = self._make_engine(mock_db, mock_config)
        engine.process_source(
            source_type="folder_watch",
            source_ref="/path/to/file.txt",
            content="Short text here.",
            supersede_old=True,
        )

        # Check that db.execute was called with the supersede UPDATE
        execute_calls = mock_db.execute.call_args_list
        supersede_calls = [
            c for c in execute_calls
            if "is_current = false" in c[0][0] and "source_ref" in c[0][0]
        ]
        assert len(supersede_calls) == 1
        params = supersede_calls[0][0][1]
        assert params[0] == "mind-uuid"
        assert params[1] == "folder_watch"
        assert params[2] == "/path/to/file.txt"

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_supersede_old_false_does_not_touch_memories(
        self, mock_extract, mock_db, mock_config,
    ):
        """Default supersede_old=False should NOT update old memories."""
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.side_effect = [
            None,              # _has_raw_documents_table -> no table
            ("source-uuid",),  # _get_or_create_source
            None,              # _check_hash -> not processed
        ]
        mock_extract.return_value = []

        engine = self._make_engine(mock_db, mock_config)
        engine.process_source(
            source_type="folder_watch",
            source_ref="/path/to/file.txt",
            content="Short text here.",
        )

        # No supersede UPDATE should be issued
        execute_calls = mock_db.execute.call_args_list
        supersede_calls = [
            c for c in execute_calls
            if len(c[0]) > 0 and "is_current = false" in c[0][0]
        ]
        assert len(supersede_calls) == 0


class TestBuildChunkHeader:
    """Test chunk context header generation."""

    def test_transcript_header_includes_minute_estimate(self):
        from coppermind_cmo.ingest import _build_chunk_header
        header = _build_chunk_header(
            source_type="transcript",
            client_name="Acme Corp",
            chunk_num=3,
            total_chunks=10,
            chunk_start_char=2000,
        )
        assert "[Document: transcript for Acme Corp]" in header
        assert "[Chunk 3 of 10" in header
        assert "approximately minute 10 of meeting]" in header

    def test_meeting_header_includes_minute_estimate(self):
        from coppermind_cmo.ingest import _build_chunk_header
        header = _build_chunk_header(
            source_type="meeting",
            client_name="Acme Corp",
            chunk_num=1,
            total_chunks=5,
            chunk_start_char=0,
        )
        assert "approximately minute 0 of meeting]" in header

    def test_non_transcript_omits_minute(self):
        from coppermind_cmo.ingest import _build_chunk_header
        header = _build_chunk_header(
            source_type="document",
            client_name="Acme Corp",
            chunk_num=2,
            total_chunks=4,
        )
        assert "minute" not in header
        assert "[Chunk 2 of 4]" in header

    def test_first_chunk_omits_previous(self):
        from coppermind_cmo.ingest import _build_chunk_header
        header = _build_chunk_header(
            source_type="document",
            client_name="Acme Corp",
            chunk_num=1,
            total_chunks=3,
            prev_chunk_tail="some previous text",
        )
        assert "Previous chunk ended with" not in header

    def test_later_chunk_includes_previous_tail(self):
        from coppermind_cmo.ingest import _build_chunk_header
        header = _build_chunk_header(
            source_type="document",
            client_name="Acme Corp",
            chunk_num=2,
            total_chunks=3,
            prev_chunk_tail="The end of the previous chunk text.",
        )
        assert 'Previous chunk ended with: "The end of the previous chunk text."' in header

    def test_previous_tail_truncated_to_100_chars(self):
        from coppermind_cmo.ingest import _build_chunk_header
        long_tail = "x" * 200
        header = _build_chunk_header(
            source_type="document",
            client_name="Acme Corp",
            chunk_num=2,
            total_chunks=3,
            prev_chunk_tail=long_tail,
        )
        # The tail should be the last 100 chars
        assert 'x' * 100 + '"' in header
        assert 'x' * 101 not in header


class TestSplitTranscript:
    """Test transcript-aware splitting on speaker boundaries."""

    def test_splits_on_speaker_changes(self):
        from coppermind_cmo.ingest import _split_transcript
        # Build a transcript with clear speaker changes and enough text
        transcript = (
            "John Smith: " + "Word " * 120 + "\n"
            "Jane Doe: " + "Word " * 120 + "\n"
            "John Smith: " + "Word " * 120 + "\n"
        )
        result = _split_transcript(transcript, min_chunk=500, max_chunk=4000)
        assert result is not None
        assert len(result) >= 2
        # Each chunk should be within bounds
        for chunk in result:
            assert len(chunk) >= 500
            assert len(chunk) <= 4000

    def test_fallback_when_no_speaker_changes(self):
        from coppermind_cmo.ingest import _split_transcript
        text = "This is just a regular document without any speaker changes. " * 50
        result = _split_transcript(text, min_chunk=500, max_chunk=4000)
        assert result is None

    def test_fallback_when_single_speaker(self):
        from coppermind_cmo.ingest import _split_transcript
        text = "John Smith: " + "Word " * 200
        result = _split_transcript(text, min_chunk=500, max_chunk=4000)
        # Only one speaker change pattern (need at least 2)
        assert result is None

    def test_fallback_when_chunks_exceed_max(self):
        from coppermind_cmo.ingest import _split_transcript
        # Two speakers but way too much text between them
        transcript = (
            "John Smith: " + "Word " * 2000 + "\n"
            "Jane Doe: " + "Word " * 100
        )
        result = _split_transcript(transcript, min_chunk=100, max_chunk=500)
        assert result is None


class TestPerChunkFailureIsolation:
    """Test that individual chunk failures don't crash the entire ingestion."""

    def _make_engine(self, mock_db, mock_config, store_fn=None):
        from coppermind_cmo.ingest import IngestEngine
        active_mind = ("mind-uuid", "Acme Corp")
        if store_fn is None:
            store_fn = MagicMock(return_value={"memory_id": "mem-uuid"})
        return IngestEngine(mock_db, mock_config, active_mind, store_fn=store_fn)

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_continues_after_chunk_failure(self, mock_extract, mock_db, mock_config):
        """If one chunk raises an exception, subsequent chunks should still process."""
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.return_value = None
        mock_db.execute_returning.return_value = ("source-uuid",)

        # Build content large enough for multiple chunks
        chunk1_content = "First chunk content. " * 250  # ~5000 chars
        chunk2_content = "Second chunk content. " * 250
        content = chunk1_content + chunk2_content

        # First call raises, second call succeeds
        call_count = [0]
        def side_effect(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] <= 2:  # First chunk (with retry)
                raise RuntimeError("LLM exploded")
            return [{"content": "A valid memory from second chunk", "memory_type": "fact", "confidence": 0.9}]

        mock_extract.side_effect = side_effect
        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})

        engine = self._make_engine(mock_db, mock_config, store_fn=mock_store)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/test/session.jsonl",
            content=content,
        )

        assert result["chunks_failed"] >= 1
        # The second chunk should have succeeded
        assert result["new"] >= 1 or result["chunks_succeeded"] >= 1


class TestPostExtractionDedup:
    """Test within-document deduplication before storage."""

    def test_dedup_removes_near_duplicates(self):
        from coppermind_cmo.ingest import _dedup_memories
        memories = [
            {"content": "Acme Corp decided to pause LinkedIn ads through Q2", "memory_type": "decision", "confidence": 0.9},
            {"content": "Acme Corp decided to pause LinkedIn ads through Q2 period", "memory_type": "decision", "confidence": 0.85},
        ]
        result = _dedup_memories(memories, threshold=0.9)
        assert len(result) == 1

    def test_dedup_keeps_more_detailed_memory(self):
        from coppermind_cmo.ingest import _dedup_memories
        # These share high word overlap: 7 of 10 words in common = 0.7 Jaccard
        short = {"content": "Acme decided to pause LinkedIn ads through Q2", "memory_type": "decision", "confidence": 0.9}
        long = {"content": "Acme decided to pause LinkedIn ads through Q2 reallocating budget to content", "memory_type": "decision", "confidence": 0.9}
        # Put short first, long second; use a threshold that these exceed
        result = _dedup_memories([short, long], threshold=0.6)
        assert len(result) == 1
        assert result[0] == long

    def test_dedup_keeps_distinct_memories(self):
        from coppermind_cmo.ingest import _dedup_memories
        memories = [
            {"content": "Acme Corp decided to pause LinkedIn ads through Q2", "memory_type": "decision", "confidence": 0.9},
            {"content": "Sarah Johnson is the new VP of Marketing at Acme", "memory_type": "stakeholder", "confidence": 0.85},
        ]
        result = _dedup_memories(memories, threshold=0.9)
        assert len(result) == 2

    def test_dedup_single_memory_unchanged(self):
        from coppermind_cmo.ingest import _dedup_memories
        memories = [{"content": "A single memory", "memory_type": "fact", "confidence": 0.9}]
        result = _dedup_memories(memories)
        assert len(result) == 1

    def test_dedup_empty_list(self):
        from coppermind_cmo.ingest import _dedup_memories
        assert _dedup_memories([]) == []

    def _make_engine(self, mock_db, mock_config, store_fn=None):
        from coppermind_cmo.ingest import IngestEngine
        active_mind = ("mind-uuid", "Acme Corp")
        if store_fn is None:
            store_fn = MagicMock(return_value={"memory_id": "mem-uuid"})
        return IngestEngine(mock_db, mock_config, active_mind, store_fn=store_fn)

    @patch("coppermind_cmo.ingest.extract_memories_from_chunk")
    def test_process_source_deduplicates_before_storage(self, mock_extract, mock_db, mock_config):
        """Two chunks producing near-identical memories should result in one stored memory."""
        import coppermind_cmo.ingest as _ingest_mod
        _ingest_mod._has_raw_docs_table = None
        mock_db.fetch_one.return_value = None  # no hash match
        mock_db.execute_returning.return_value = ("source-uuid",)

        # Build content large enough for 2 chunks
        content = "A" * 5000

        # Both chunks return nearly identical memories
        mock_extract.return_value = [
            {"content": "Acme Corp paused LinkedIn ads through Q2 period", "memory_type": "decision", "confidence": 0.9},
        ]

        mock_store = MagicMock(return_value={"memory_id": "mem-uuid"})
        engine = self._make_engine(mock_db, mock_config, store_fn=mock_store)
        result = engine.process_source(
            source_type="claude_session",
            source_ref="/test/session.jsonl",
            content=content,
        )

        # Should have called extract for each chunk but store only once after dedup
        assert mock_extract.call_count >= 2
        assert result["dedup_removed"] >= 1
        # store_fn should be called once (the deduplicated result)
        assert mock_store.call_count == 1


class TestChunkSizeBounds:
    """Test that MIN/MAX chunk size bounds from config are enforced."""

    def test_split_transcript_respects_min_max(self):
        from coppermind_cmo.ingest import _split_transcript
        # Build transcript where speaker segments are ~300 chars each
        transcript = ""
        for i in range(10):
            name = "John Smith" if i % 2 == 0 else "Jane Doe"
            transcript += f"\n{name}: " + "Word " * 60  # ~300 chars per segment

        # With min=100, max=800, should merge segments to fit bounds
        result = _split_transcript(transcript, min_chunk=100, max_chunk=800)
        if result is not None:
            for chunk in result:
                assert len(chunk) >= 100, f"Chunk too short: {len(chunk)}"
                assert len(chunk) <= 800, f"Chunk too long: {len(chunk)}"


class TestConfigEnvVarOverrides:
    """Test that chunk config env vars are properly read."""

    def test_default_chunk_config_values(self):
        from coppermind_cmo.config import Config
        config = Config()
        assert config.chunk_overlap_chars == 200
        assert config.min_chunk_chars == 500
        assert config.max_chunk_chars == 4000

    def test_env_var_override_chunk_overlap(self, monkeypatch):
        monkeypatch.setenv("COPPERMIND_CHUNK_OVERLAP_CHARS", "300")
        from coppermind_cmo.config import Config
        config = Config()
        assert config.chunk_overlap_chars == 300

    def test_env_var_override_min_chunk(self, monkeypatch):
        monkeypatch.setenv("COPPERMIND_MIN_CHUNK_CHARS", "1000")
        from coppermind_cmo.config import Config
        config = Config()
        assert config.min_chunk_chars == 1000

    def test_env_var_override_max_chunk(self, monkeypatch):
        monkeypatch.setenv("COPPERMIND_MAX_CHUNK_CHARS", "8000")
        from coppermind_cmo.config import Config
        config = Config()
        assert config.max_chunk_chars == 8000

    def test_invalid_env_var_raises(self, monkeypatch):
        monkeypatch.setenv("COPPERMIND_CHUNK_OVERLAP_CHARS", "not_a_number")
        from coppermind_cmo.config import Config
        with pytest.raises(ValueError, match="must be an integer"):
            Config()


class TestJaccardSimilarity:
    """Test the Jaccard similarity helper."""

    def test_identical_texts(self):
        from coppermind_cmo.ingest import _jaccard_similarity
        assert _jaccard_similarity("hello world", "hello world") == 1.0

    def test_completely_different(self):
        from coppermind_cmo.ingest import _jaccard_similarity
        assert _jaccard_similarity("hello world", "foo bar baz") == 0.0

    def test_partial_overlap(self):
        from coppermind_cmo.ingest import _jaccard_similarity
        sim = _jaccard_similarity("the quick brown fox", "the slow brown dog")
        assert 0.0 < sim < 1.0

    def test_empty_text(self):
        from coppermind_cmo.ingest import _jaccard_similarity
        assert _jaccard_similarity("", "hello") == 0.0
        assert _jaccard_similarity("hello", "") == 0.0
