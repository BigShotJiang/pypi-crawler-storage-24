"""Tests for client context switch briefing feature."""

import pytest
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

from coppermind_cmo.tools.intelligence import (
    _detect_adjacent_meeting,
    _build_transition_brief,
    _prep_meeting,
    ADJACENCY_THRESHOLD_MINUTES,
)


def _make_config():
    config = MagicMock()
    config.embedding_url = None
    config.max_prompt_chars = 13000
    return config


class TestDetectAdjacentMeeting:
    """Tests for _detect_adjacent_meeting()."""

    def test_no_meeting_log_table(self):
        """Returns None when meeting_log table doesn't exist."""
        db = MagicMock()
        with patch(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table",
            return_value=False,
        ):
            result = _detect_adjacent_meeting("mind1", "cust1", db)
        assert result is None

    def test_no_adjacent_meeting(self):
        """Returns None when no meeting for a different client is nearby."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        with patch(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table",
            return_value=True,
        ):
            db.fetch_one.side_effect = [
                (now,),   # current mind's upcoming meeting
                None,     # no adjacent meeting for different mind
            ]
            result = _detect_adjacent_meeting("mind1", "cust1", db)
            assert result is None

    def test_adjacent_meeting_detected(self):
        """Detects a meeting for a different client within 30 min window."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        with patch(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table",
            return_value=True,
        ):
            db.fetch_one.return_value = (
                "other_mind", "Other Meeting",
                now - timedelta(minutes=15), "Other Client",
            )
            result = _detect_adjacent_meeting(
                "mind1", "cust1", db, meeting_start_time=now,
            )
            assert result is not None
            assert result["name"] == "Other Client"
            assert result["mind_id"] == "other_mind"

    def test_no_meeting_outside_threshold(self):
        """Meetings more than 30 min apart are not adjacent."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        with patch(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table",
            return_value=True,
        ):
            db.fetch_one.return_value = None
            result = _detect_adjacent_meeting(
                "mind1", "cust1", db, meeting_start_time=now,
            )
            assert result is None

    def test_same_mind_not_detected(self):
        """Back-to-back meetings with same client don't trigger transition."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        with patch(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table",
            return_value=True,
        ):
            # SQL uses WHERE mind_id != %s, so same-mind meetings won't match
            db.fetch_one.return_value = None
            result = _detect_adjacent_meeting(
                "mind1", "cust1", db, meeting_start_time=now,
            )
            assert result is None

    def test_with_explicit_start_time_skips_lookup(self):
        """When meeting_start_time is provided, skips the initial lookup query."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        with patch(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table",
            return_value=True,
        ):
            db.fetch_one.return_value = (
                "prev_mind", "Prev Meeting",
                now - timedelta(minutes=10), "Prev Client",
            )
            result = _detect_adjacent_meeting(
                "mind1", "cust1", db, meeting_start_time=now,
            )
            # Only one call: the adjacent meeting query (not the lookup)
            assert db.fetch_one.call_count == 1
            assert result is not None

    def test_no_upcoming_meeting_without_start_time(self):
        """Returns None when no upcoming meeting found and no start_time given."""
        db = MagicMock()

        with patch(
            "coppermind_cmo.tools.daily_loop._has_meeting_log_table",
            return_value=True,
        ):
            db.fetch_one.return_value = None
            result = _detect_adjacent_meeting("mind1", "cust1", db)
            assert result is None

    def test_threshold_constant(self):
        """Adjacency threshold is 30 minutes."""
        assert ADJACENCY_THRESHOLD_MINUTES == 30


class TestBuildTransitionBrief:
    """Tests for _build_transition_brief()."""

    def test_builds_basic_brief(self):
        """Builds a transition brief with all sections."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        db.fetch_one.side_effect = [
            (now - timedelta(days=3),),            # last interaction
            ('{"tone": "casual startup"}',),       # previous brand voice
            ('{"tone": "formal enterprise"}',),    # current brand voice
        ]
        db.fetch_all.side_effect = [
            [  # changes since last interaction
                ("decision", "Budget approved for Q2", now - timedelta(days=1)),
            ],
            [  # open items
                ("commitment", "Send follow-up proposal", now - timedelta(days=2)),
                ("agenda", "Discuss Q2 goals", now - timedelta(hours=1)),
            ],
        ]

        previous_mind = {
            "mind_id": "prev_id",
            "title": "Prev Meeting",
            "start_time": now - timedelta(minutes=15),
            "name": "Acme Corp",
        }

        result = _build_transition_brief(
            previous_mind, "curr_id", "BigCorp", db, "cust1",
        )

        assert "Context Switch: Acme Corp" in result
        assert "BigCorp" in result
        assert "3 days ago" in result
        assert "Budget approved" in result
        assert "casual startup" in result
        assert "formal enterprise" in result
        assert "Send follow-up proposal" in result

    def test_first_meeting_with_client(self):
        """Shows 'first meeting' when no previous interaction exists."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        db.fetch_one.side_effect = [
            (None,),                       # no last interaction
            ('{"tone": "casual"}',),       # prev brand voice
            ('{"tone": "formal"}',),       # curr brand voice
        ]
        db.fetch_all.side_effect = [
            [],  # no changes (no last interaction)
            [],  # no open items
        ]

        previous_mind = {
            "mind_id": "prev", "title": "T",
            "start_time": now, "name": "Prev",
        }
        result = _build_transition_brief(
            previous_mind, "curr", "NewClient", db, "cust1",
        )

        assert "First meeting with NewClient" in result

    def test_no_brand_voice_tone(self):
        """Handles missing brand voice gracefully."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        db.fetch_one.side_effect = [
            (now - timedelta(days=1),),    # last interaction
            (None,),                       # no previous brand voice
            (None,),                       # no current brand voice
        ]
        db.fetch_all.side_effect = [[], []]

        previous_mind = {
            "mind_id": "prev", "title": "T",
            "start_time": now, "name": "Prev",
        }
        result = _build_transition_brief(
            previous_mind, "curr", "Curr", db, "cust1",
        )

        assert "Context Switch: Prev" in result
        assert "Curr" in result
        assert "Tone shift" not in result

    def test_today_interaction(self):
        """Shows 'Today' for same-day last interaction."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        db.fetch_one.side_effect = [
            (now - timedelta(hours=2),),   # last interaction today
            (None,),
            (None,),
        ]
        db.fetch_all.side_effect = [[], []]

        previous_mind = {
            "mind_id": "prev", "title": "T",
            "start_time": now, "name": "Prev",
        }
        result = _build_transition_brief(
            previous_mind, "curr", "Curr", db, "cust1",
        )

        assert "Today" in result

    def test_yesterday_interaction(self):
        """Shows 'Yesterday' for one-day-ago interaction."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        db.fetch_one.side_effect = [
            (now - timedelta(days=1),),    # last interaction yesterday
            (None,),
            (None,),
        ]
        db.fetch_all.side_effect = [[], []]

        previous_mind = {
            "mind_id": "prev", "title": "T",
            "start_time": now, "name": "Prev",
        }
        result = _build_transition_brief(
            previous_mind, "curr", "Curr", db, "cust1",
        )

        assert "Yesterday" in result

    def test_open_items_ordered(self):
        """Open items show with age and type info."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        db.fetch_one.side_effect = [
            (now - timedelta(days=5),),
            (None,),
            (None,),
        ]
        db.fetch_all.side_effect = [
            [],  # no changes
            [    # open items
                ("agenda", "Discuss roadmap", now - timedelta(days=2)),
                ("commitment", "Deliver report", now),
            ],
        ]

        previous_mind = {
            "mind_id": "prev", "title": "T",
            "start_time": now, "name": "Prev",
        }
        result = _build_transition_brief(
            previous_mind, "curr", "Curr", db, "cust1",
        )

        assert "Top open items" in result
        assert "Discuss roadmap" in result
        assert "Deliver report" in result
        assert "2 days old" in result

    def test_brief_ends_with_separator(self):
        """Transition brief ends with a markdown separator."""
        db = MagicMock()
        now = datetime.now(timezone.utc)

        db.fetch_one.side_effect = [(None,), (None,), (None,)]
        db.fetch_all.side_effect = [[], []]

        previous_mind = {
            "mind_id": "prev", "title": "T",
            "start_time": now, "name": "Prev",
        }
        result = _build_transition_brief(
            previous_mind, "curr", "Curr", db, "cust1",
        )

        assert result.strip().endswith("---")


class TestPrepMeetingContextSwitch:
    """Tests that _prep_meeting integrates context switch correctly."""

    def test_accepts_new_parameters(self):
        """The function accepts customer_id and meeting_start_time without error."""
        db = MagicMock()
        config = _make_config()
        now = datetime.now(timezone.utc)

        db.fetch_one.return_value = (
            "TestClient", None, None, None, None, None, None, None,
        )

        with patch(
            "coppermind_cmo.tools.intelligence._detect_adjacent_meeting",
            return_value=None,
        ):
            with patch(
                "coppermind_cmo.tools.intelligence._collect_meeting_memories",
                return_value=([], False),
            ):
                result = _prep_meeting(
                    topics=None,
                    meeting_type="review",
                    limit=50,
                    db=db,
                    config=config,
                    active_mind=("mind1", "TestClient"),
                    customer_id="cust1",
                    meeting_start_time=now.isoformat(),
                )
                assert result.get("context_switch") is False

    def test_no_transition_without_customer_id(self):
        """When customer_id is not provided, no context switch detection."""
        db = MagicMock()
        config = _make_config()

        db.fetch_one.return_value = (
            "Client", None, None, None, None, None, None, None,
        )

        with patch(
            "coppermind_cmo.tools.intelligence._collect_meeting_memories",
            return_value=([], False),
        ):
            result = _prep_meeting(
                topics=None,
                meeting_type="review",
                limit=50,
                db=db,
                config=config,
                active_mind=("mind1", "Client"),
                # no customer_id
            )
            assert result.get("context_switch") is False
            assert result.get("transition_brief") is None

    def test_transition_brief_in_response_when_adjacent(self):
        """When adjacent meeting detected, transition_brief appears in output."""
        db = MagicMock()
        config = _make_config()
        now = datetime.now(timezone.utc)

        db.fetch_one.return_value = (
            "TestClient", None, None, None, None, None, None, None,
        )

        mock_transition = "## Context Switch: Acme -> TestClient\n---\n\n"

        with patch(
            "coppermind_cmo.tools.intelligence._detect_adjacent_meeting",
            return_value={
                "mind_id": "other",
                "title": "Other Meeting",
                "start_time": now - timedelta(minutes=10),
                "name": "Acme",
            },
        ):
            with patch(
                "coppermind_cmo.tools.intelligence._build_transition_brief",
                return_value=mock_transition,
            ):
                with patch(
                    "coppermind_cmo.tools.intelligence._collect_meeting_memories",
                    return_value=([], False),
                ):
                    result = _prep_meeting(
                        topics=None,
                        meeting_type="review",
                        limit=50,
                        db=db,
                        config=config,
                        active_mind=("mind1", "TestClient"),
                        customer_id="cust1",
                        meeting_start_time=now.isoformat(),
                    )
                    assert result["context_switch"] is True
                    assert result["transition_brief"] == mock_transition

    def test_context_switch_false_when_no_adjacent(self):
        """context_switch is False when no adjacent meeting exists."""
        db = MagicMock()
        config = _make_config()
        now = datetime.now(timezone.utc)

        db.fetch_one.return_value = (
            "TestClient", None, None, None, None, None, None, None,
        )

        with patch(
            "coppermind_cmo.tools.intelligence._detect_adjacent_meeting",
            return_value=None,
        ):
            with patch(
                "coppermind_cmo.tools.intelligence._collect_meeting_memories",
                return_value=([], False),
            ):
                result = _prep_meeting(
                    topics=None,
                    meeting_type="review",
                    limit=50,
                    db=db,
                    config=config,
                    active_mind=("mind1", "TestClient"),
                    customer_id="cust1",
                    meeting_start_time=now.isoformat(),
                )
                assert result["context_switch"] is False
                assert result["transition_brief"] is None
