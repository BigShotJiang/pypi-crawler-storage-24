"""Tests for session and interaction tracking."""

import uuid
from unittest.mock import MagicMock, patch

import coppermind_cmo.server as server_mod
from coppermind_cmo.server import get_session_id, get_last_tool_call, set_last_tool_call, SESSION_ID


class TestSessionId:
    def test_session_id_generated(self):
        """SESSION_ID is a non-empty string that looks like a UUID."""
        assert SESSION_ID
        assert isinstance(SESSION_ID, str)
        # Should be a valid UUID
        uuid.UUID(SESSION_ID)

    def test_session_id_consistent(self):
        """get_session_id() returns the same value on repeated calls."""
        first = get_session_id()
        second = get_session_id()
        assert first == second
        assert first == SESSION_ID


class TestLastToolCallTracking:
    def test_last_tool_call_tracking(self):
        """set_last_tool_call then get_last_tool_call returns the value."""
        set_last_tool_call("prep_meeting")
        assert get_last_tool_call() == "prep_meeting"

    def test_last_tool_call_updates(self):
        """Calling set_last_tool_call overwrites previous value."""
        set_last_tool_call("switch_client")
        set_last_tool_call("store_memory")
        assert get_last_tool_call() == "store_memory"

    def test_last_tool_call_initially_none(self):
        """After conftest reset, last_tool_call is None."""
        server_mod._session.last_tool_call = None
        assert get_last_tool_call() is None


def _make_config():
    config = MagicMock()
    config.embedding_provider = "local"
    config.embedding_url = "http://localhost:8400"
    config.embedding_dims = 384
    config.llm_provider = "ollama"
    config.ollama_url = "http://localhost:11434"
    config.ollama_model = "gemma3:12b"
    return config


class TestStoreMemoryTracking:
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_store_memory_sets_source_tool(self, mock_emb):
        """Verify INSERT includes source_tool='store_memory'."""
        from coppermind_cmo.tools.memories import store_memory_core as _store_memory
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        db.execute_returning.return_value = ("mem-uuid",)

        _store_memory("test content", None, [], db, config, mind, source_tool="store_memory")

        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        params = call_args[1]
        assert "source_tool" in sql
        assert "store_memory" in params

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    def test_store_memory_sets_follows_tool(self, mock_emb):
        """Set last_tool_call to 'prep_meeting', store a memory, verify follows_tool_call."""
        from coppermind_cmo.tools.memories import store_memory_core as _store_memory
        set_last_tool_call("prep_meeting")

        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        db.execute_returning.return_value = ("mem-uuid",)

        _store_memory("test content", None, [], db, config, mind, source_tool="store_memory")

        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        params = call_args[1]
        assert "follows_tool_call" in sql
        assert "prep_meeting" in params


class TestQuickNoteTracking:
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_quick_note_sets_source_tool(self, mock_emb):
        """Verify INSERT includes source_tool='quick_note'."""
        from coppermind_cmo.tools.memories import _quick_note
        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        db.execute_returning.return_value = ("note-uuid",)

        _quick_note("quick thought", db, config, mind)

        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        params = call_args[1]
        assert "source_tool" in sql
        assert "quick_note" in params

    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.5])
    def test_quick_note_sets_follows_tool(self, mock_emb):
        """Set last_tool_call to 'search_memory', call quick_note, verify follows_tool_call."""
        from coppermind_cmo.tools.memories import _quick_note
        set_last_tool_call("search_memory")

        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")
        db.execute_returning.return_value = ("note-uuid",)

        _quick_note("quick thought", db, config, mind)

        call_args = db.execute_returning.call_args[0]
        sql = call_args[0]
        params = call_args[1]
        assert "follows_tool_call" in sql
        assert "search_memory" in params


class TestGatewaySessionHeader:
    def test_llm_client_sends_session_id_header(self):
        """Gateway LLM call includes X-Session-Id header when session_id passed."""
        from coppermind_cmo.llm_client import call_gateway_llm

        config = MagicMock()
        config.llm_provider = "gateway"
        config.api_key = "test-key"
        config.gateway_url = "https://api.coppermind.app"

        mock_resp = MagicMock()
        mock_resp.json.return_value = {"text": "result"}

        sid = get_session_id()
        with patch("coppermind_cmo.gateway_http.httpx.post", return_value=mock_resp) as mock_post:
            call_gateway_llm("synthesize", {"prompt": "test"}, config, session_id=sid)

            call_kwargs = mock_post.call_args
            headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers")
            assert "X-Session-Id" in headers
            assert headers["X-Session-Id"] == sid

    def test_embedding_client_sends_session_id_header(self):
        """Gateway embedding call includes X-Session-Id header when session_id passed."""
        from coppermind_cmo.embedding_client import _get_embedding_gateway

        config = MagicMock()
        config.embedding_provider = "gateway"
        config.api_key = "test-key"
        config.gateway_url = "https://api.coppermind.app"
        config.embedding_dims = 512

        mock_resp = MagicMock()
        mock_resp.json.return_value = {"embedding": [0.1] * 512}

        sid = get_session_id()
        with patch("coppermind_cmo.gateway_http.httpx.post", return_value=mock_resp) as mock_post:
            _get_embedding_gateway("test text", config, session_id=sid)

            call_kwargs = mock_post.call_args
            headers = call_kwargs.kwargs.get("headers") or call_kwargs[1].get("headers")
            assert "X-Session-Id" in headers
            assert headers["X-Session-Id"] == sid

    def test_gateway_headers_no_server_import(self):
        """gateway_http module does not import from server.py (no circular dependency)."""
        import importlib
        import sys

        # Reload gateway_http in isolation to verify it doesn't trigger server import
        mod_name = "coppermind_cmo.gateway_http"
        saved = sys.modules.pop(mod_name, None)
        try:
            mod = importlib.import_module(mod_name)
            # Verify gateway_headers works without server
            headers = mod.gateway_headers(MagicMock(api_key="k"), session_id="test-123")
            assert headers["X-Session-Id"] == "test-123"
        finally:
            if saved is not None:
                sys.modules[mod_name] = saved


class TestReconsolidationTracking:
    @patch("coppermind_cmo.tools.memories.get_embedding", return_value=[0.1, 0.2])
    @patch("coppermind_cmo.tools.memories._find_similar_memory")
    def test_reconsolidation_sets_follows_tool(self, mock_find, mock_emb):
        """Reconsolidation UPDATE should set follows_tool_call."""
        from coppermind_cmo.tools.memories import store_memory_core as _store_memory
        set_last_tool_call("store_memory")

        db = MagicMock()
        config = _make_config()
        mind = ("mind-1", "Acme")

        mock_find.return_value = {
            "memory_id": "existing-id",
            "content": "Old content",
            "summary": "Old summary",
            "memory_type": "fact",
            "similarity": 0.75,
        }
        db.fetch_one.return_value = ({},)  # cadence

        result = _store_memory("New content", None, [], db, config, mind, skip_reconsolidation=False)
        assert result.get("reconsolidated") is True

        # Verify the UPDATE call includes follows_tool_call
        update_call = db.execute.call_args[0]
        update_sql = update_call[0]
        update_params = update_call[1]
        assert "follows_tool_call" in update_sql
        assert "store_memory" in update_params
