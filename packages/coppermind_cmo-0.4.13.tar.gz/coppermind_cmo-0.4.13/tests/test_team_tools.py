"""Tests for team management and pending review tools (tools/team.py)."""

from datetime import datetime, timezone
from unittest.mock import MagicMock, call

from coppermind_cmo.tools.team import (
    _add_team_member,
    _remove_team_member,
    _list_team,
    _list_pending,
    _promote_pending,
    _dismiss_pending,
    _rollback_pending,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_SENTINEL = object()


def _make_db(fetch_one_returns=_SENTINEL, fetch_all_returns=None, execute_returning_returns=_SENTINEL):
    db = MagicMock()
    if fetch_one_returns is not _SENTINEL:
        if isinstance(fetch_one_returns, list):
            db.fetch_one.side_effect = list(fetch_one_returns)
        else:
            db.fetch_one.return_value = fetch_one_returns
    if fetch_all_returns is not None:
        db.fetch_all.return_value = fetch_all_returns
    if execute_returning_returns is not _SENTINEL:
        if isinstance(execute_returning_returns, list):
            db.execute_returning.side_effect = execute_returning_returns
        else:
            db.execute_returning.return_value = execute_returning_returns
    return db


MIND = ("mind-uuid-1", "Acme Corp")
OWNER = "owner-customer-id"
MEMBER = "member-customer-id"


# ---------------------------------------------------------------------------
# TestAddTeamMember
# ---------------------------------------------------------------------------

class TestAddTeamMember:
    def test_add_viewer_success(self):
        db = _make_db()
        result = _add_team_member(MEMBER, "viewer", db, MIND, OWNER)
        assert result.get("error") is not True
        assert result.get("customer_id") == MEMBER
        assert result.get("access_level") == "viewer"
        db.execute.assert_called_once()

    def test_add_invalid_access_level(self):
        db = _make_db()
        result = _add_team_member(MEMBER, "admin", db, MIND, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"
        db.execute.assert_not_called()

    def test_add_self_rejected(self):
        db = _make_db()
        result = _add_team_member(OWNER, "viewer", db, MIND, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"
        assert "self" in result.get("message", "").lower() or "owner" in result.get("message", "").lower()
        db.execute.assert_not_called()

    def test_add_empty_customer_id_rejected(self):
        db = _make_db()
        result = _add_team_member("", "viewer", db, MIND, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"
        db.execute.assert_not_called()

    def test_regrant_after_revoke_uses_upsert(self):
        """UPSERT clears revoked_at — re-granting after revoke should succeed."""
        db = _make_db()
        result = _add_team_member(MEMBER, "viewer", db, MIND, OWNER)
        assert result.get("error") is not True
        # The SQL must be an UPSERT (ON CONFLICT) that resets revoked_at
        call_args = db.execute.call_args
        sql = call_args[0][0] if call_args else ""
        assert "ON CONFLICT" in sql
        assert "revoked_at" in sql

    def test_add_with_mind_name_override(self):
        """mind_name parameter is accepted without error."""
        db = _make_db()
        result = _add_team_member(MEMBER, "viewer", db, MIND, OWNER, mind_name="Acme Corp")
        assert result.get("error") is not True

    def test_no_active_mind_returns_error(self):
        db = _make_db()
        result = _add_team_member(MEMBER, "viewer", db, None, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "NO_ACTIVE_MIND"


# ---------------------------------------------------------------------------
# TestRemoveTeamMember
# ---------------------------------------------------------------------------

class TestRemoveTeamMember:
    def test_remove_success(self):
        db = _make_db(execute_returning_returns=("member-customer-id",))
        result = _remove_team_member(MEMBER, db, MIND, OWNER)
        assert result.get("error") is not True
        assert result.get("customer_id") == MEMBER

    def test_remove_nonexistent_returns_not_found(self):
        db = _make_db(execute_returning_returns=None)
        result = _remove_team_member(MEMBER, db, MIND, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "NOT_FOUND"

    def test_remove_uses_soft_delete(self):
        """Must SET revoked_at, not DELETE."""
        db = _make_db(execute_returning_returns=(MEMBER,))
        _remove_team_member(MEMBER, db, MIND, OWNER)
        call_args = db.execute_returning.call_args
        sql = call_args[0][0] if call_args else ""
        assert "revoked_at" in sql.lower()
        assert "delete" not in sql.lower()

    def test_remove_no_active_mind(self):
        db = _make_db()
        result = _remove_team_member(MEMBER, db, None, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "NO_ACTIVE_MIND"


# ---------------------------------------------------------------------------
# TestListTeam
# ---------------------------------------------------------------------------

class TestListTeam:
    def test_list_returns_active_members(self):
        ts = datetime(2025, 1, 15, 12, 0, 0, tzinfo=timezone.utc)
        db = _make_db(fetch_all_returns=[
            ("member-1", "viewer", ts),
            ("member-2", "viewer", ts),
        ])
        result = _list_team(db, MIND)
        assert isinstance(result, list)
        assert len(result) == 2
        assert result[0]["customer_id"] == "member-1"
        assert result[0]["access_level"] == "viewer"

    def test_list_excludes_revoked(self):
        """SQL must include revoked_at IS NULL filter."""
        db = _make_db(fetch_all_returns=[])
        _list_team(db, MIND)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "revoked_at IS NULL" in sql

    def test_list_excludes_owner_access_level(self):
        """SQL must exclude access_level = 'owner' rows."""
        db = _make_db(fetch_all_returns=[])
        _list_team(db, MIND)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "owner" in sql

    def test_list_no_active_mind(self):
        db = _make_db()
        result = _list_team(db, None)
        assert isinstance(result, dict)
        assert result.get("error") is True
        assert result.get("code") == "NO_ACTIVE_MIND"

    def test_list_empty_returns_list(self):
        db = _make_db(fetch_all_returns=[])
        result = _list_team(db, MIND)
        assert result == []

    def test_list_granted_at_is_iso_string(self):
        ts = datetime(2025, 3, 1, 9, 0, 0, tzinfo=timezone.utc)
        db = _make_db(fetch_all_returns=[("member-1", "viewer", ts)])
        result = _list_team(db, MIND)
        assert isinstance(result[0]["granted_at"], str)


# ---------------------------------------------------------------------------
# TestListPending
# ---------------------------------------------------------------------------

class TestListPending:
    def test_list_pending_returns_memories(self):
        ts = datetime(2025, 2, 20, 10, 0, 0, tzinfo=timezone.utc)
        db = _make_db(fetch_all_returns=[
            ("mem-uuid-1", "This is a pending memory content", "fact", "member-1", ts),
        ])
        result = _list_pending(db, MIND)
        assert isinstance(result, list)
        assert len(result) == 1
        assert result[0]["id"] == "mem-uuid-1"
        assert result[0]["memory_type"] == "fact"
        assert result[0]["created_by"] == "member-1"

    def test_list_pending_no_active_mind(self):
        db = _make_db()
        result = _list_pending(db, None)
        assert isinstance(result, dict)
        assert result.get("error") is True
        assert result.get("code") == "NO_ACTIVE_MIND"

    def test_list_pending_filters_by_status(self):
        db = _make_db(fetch_all_returns=[])
        _list_pending(db, MIND)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "status" in sql
        assert "pending" in sql

    def test_list_pending_optional_created_by_filter(self):
        db = _make_db(fetch_all_returns=[])
        _list_pending(db, MIND, created_by="member-1")
        call_args = db.fetch_all.call_args
        params = call_args[0][1] if call_args and len(call_args[0]) > 1 else call_args[1].get("params", [])
        # member-1 should be in params when created_by is provided
        assert "member-1" in list(params)

    def test_list_pending_optional_since_filter(self):
        db = _make_db(fetch_all_returns=[])
        _list_pending(db, MIND, since="2025-01-01")
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "created_at" in sql

    def test_list_pending_content_truncated_at_200(self):
        long_content = "x" * 300
        ts = datetime(2025, 2, 20, 10, 0, 0, tzinfo=timezone.utc)
        db = _make_db(fetch_all_returns=[("mem-1", long_content, "fact", "m1", ts)])
        result = _list_pending(db, MIND)
        assert len(result[0]["content"]) <= 200


# ---------------------------------------------------------------------------
# TestPromotePending
# ---------------------------------------------------------------------------

class TestPromotePending:
    def test_promote_requires_filter(self):
        db = _make_db()
        result = _promote_pending(None, None, db, MIND, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"
        db.fetch_all.assert_not_called()

    def test_promote_by_creator(self):
        db = _make_db(fetch_all_returns=[("id-1",), ("id-2",), ("id-3",)])
        result = _promote_pending("member-1", None, db, MIND, OWNER)
        assert result.get("error") is not True
        assert "promoted" in result

    def test_promote_by_since(self):
        db = _make_db(fetch_all_returns=[("id-1",), ("id-2",)])
        result = _promote_pending(None, "2025-01-01", db, MIND, OWNER)
        assert result.get("error") is not True

    def test_promote_no_active_mind(self):
        db = _make_db()
        result = _promote_pending("member-1", None, db, None, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "NO_ACTIVE_MIND"

    def test_promote_sql_sets_status_active(self):
        db = _make_db(fetch_all_returns=[("id-1",)])
        _promote_pending("member-1", None, db, MIND, OWNER)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "status" in sql.lower()
        assert "active" in sql.lower()

    def test_promote_sql_sets_promoted_by(self):
        db = _make_db(fetch_all_returns=[("id-1",)])
        _promote_pending("member-1", None, db, MIND, OWNER)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "promoted_by" in sql


# ---------------------------------------------------------------------------
# TestDismissPending
# ---------------------------------------------------------------------------

class TestDismissPending:
    def test_dismiss_requires_filter(self):
        db = _make_db()
        result = _dismiss_pending(None, None, db, MIND, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"
        db.fetch_all.assert_not_called()

    def test_dismiss_by_date(self):
        db = _make_db(fetch_all_returns=[("id-1",), ("id-2",), ("id-3",), ("id-4",)])
        result = _dismiss_pending(None, "2025-02-01", db, MIND, OWNER)
        assert result.get("error") is not True
        assert "dismissed" in result

    def test_dismiss_by_creator(self):
        db = _make_db(fetch_all_returns=[("id-1",)])
        result = _dismiss_pending("member-1", None, db, MIND, OWNER)
        assert result.get("error") is not True

    def test_dismiss_no_active_mind(self):
        db = _make_db()
        result = _dismiss_pending("member-1", None, db, None, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "NO_ACTIVE_MIND"

    def test_dismiss_sql_sets_status_dismissed(self):
        db = _make_db(fetch_all_returns=[("id-1",)])
        _dismiss_pending("member-1", None, db, MIND, OWNER)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "dismissed" in sql.lower()

    def test_dismiss_sql_sets_dismissed_by(self):
        db = _make_db(fetch_all_returns=[("id-1",)])
        _dismiss_pending("member-1", None, db, MIND, OWNER)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "dismissed_by" in sql


# ---------------------------------------------------------------------------
# TestRollbackPending
# ---------------------------------------------------------------------------

class TestRollbackPending:
    def test_rollback_requires_filter(self):
        db = _make_db()
        result = _rollback_pending(None, None, db, MIND, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"
        db.fetch_all.assert_not_called()

    def test_rollback_by_creator(self):
        db = _make_db(fetch_all_returns=[("id-1",), ("id-2",)])
        result = _rollback_pending("member-1", None, db, MIND, OWNER)
        assert result.get("error") is not True
        assert "rolled_back" in result

    def test_rollback_by_since(self):
        db = _make_db(fetch_all_returns=[("id-1",), ("id-2",), ("id-3",)])
        result = _rollback_pending(None, "2025-01-15", db, MIND, OWNER)
        assert result.get("error") is not True

    def test_rollback_no_active_mind(self):
        db = _make_db()
        result = _rollback_pending("member-1", None, db, None, OWNER)
        assert result.get("error") is True
        assert result.get("code") == "NO_ACTIVE_MIND"

    def test_rollback_targets_active_with_promoted_at(self):
        """Rollback must only affect status='active' AND promoted_at IS NOT NULL."""
        db = _make_db(fetch_all_returns=[("id-1",)])
        _rollback_pending("member-1", None, db, MIND, OWNER)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "active" in sql.lower()
        assert "promoted_at" in sql

    def test_rollback_sets_dismissed_status(self):
        db = _make_db(fetch_all_returns=[("id-1",)])
        _rollback_pending("member-1", None, db, MIND, OWNER)
        call_args = db.fetch_all.call_args
        sql = call_args[0][0] if call_args else ""
        assert "dismissed" in sql.lower()


# ---------------------------------------------------------------------------
# TestSwitchClientPendingCount
# ---------------------------------------------------------------------------

class TestSwitchClientPendingCount:
    def test_switch_client_references_pending(self):
        from coppermind_cmo.tools import minds as minds_mod
        import inspect
        source = inspect.getsource(minds_mod._switch_client)
        assert "pending" in source.lower()


# ---------------------------------------------------------------------------
# TestConfigureMindSharingConfig
# ---------------------------------------------------------------------------

class TestConfigureMindSharingConfig:
    def test_configure_mind_has_sharing_config_param(self):
        from coppermind_cmo.tools.minds import _configure_mind
        import inspect
        sig = inspect.signature(_configure_mind)
        assert "sharing_config" in sig.parameters

    def test_sharing_config_validates_unknown_keys(self):
        from coppermind_cmo.tools.minds import _configure_mind
        from unittest.mock import MagicMock
        db = MagicMock()
        db.fetch_one.return_value = ("mind-1",)  # access check
        result = _configure_mind(
            cadence=None, company_info=None, db=db,
            active_mind=("mind-1", "Test"),
            sharing_config={"bad_key": True}
        )
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"

    def test_sharing_config_validates_memory_types(self):
        from coppermind_cmo.tools.minds import _configure_mind
        from unittest.mock import MagicMock
        db = MagicMock()
        db.fetch_one.return_value = ("mind-1",)
        result = _configure_mind(
            cadence=None, company_info=None, db=db,
            active_mind=("mind-1", "Test"),
            sharing_config={"viewer_allowed_types": ["invalid_type"]}
        )
        assert result.get("error") is True
        assert result.get("code") == "INVALID_INPUT"
