"""Tests for schema migration files."""

import os
import glob


def test_meeting_briefs_migration_has_grant():
    """Migration 006 should include GRANT for coppermind user."""
    schema_dir = os.path.join(os.path.dirname(__file__), "..", "schema")
    migration_006 = os.path.join(schema_dir, "006_meeting_briefs.sql")
    with open(migration_006) as f:
        content = f.read().lower()
    assert "grant" in content
    assert "meeting_briefs" in content
    assert "coppermind" in content


def test_all_create_table_migrations_have_grants():
    """Every migration that creates a table should include a GRANT statement."""
    schema_dir = os.path.join(os.path.dirname(__file__), "..", "schema")
    for path in sorted(glob.glob(os.path.join(schema_dir, "*.sql"))):
        with open(path) as f:
            content = f.read().lower()
        if "create table" in content:
            basename = os.path.basename(path)
            # 001_initial.sql may not have GRANTs (uses owner role)
            if basename == "001_initial.sql":
                continue
            assert "grant" in content, f"{basename} creates a table but has no GRANT statement"


def test_session_tracking_010_marked_superseded():
    """schema/010 should note that 013 is canonical."""
    schema_dir = os.path.join(os.path.dirname(__file__), "..", "schema")
    path = os.path.join(schema_dir, "010_session_tracking.sql")
    with open(path) as f:
        content = f.read()
    assert "superseded" in content.lower()
    assert "013" in content


def test_session_tracking_013_is_canonical():
    """schema/013 should be the canonical session tracking migration."""
    schema_dir = os.path.join(os.path.dirname(__file__), "..", "schema")
    path = os.path.join(schema_dir, "013_session_tracking.sql")
    with open(path) as f:
        content = f.read()
    assert "canonical" in content.lower()
    # Must contain all columns from both 010 and 013
    assert "source_tool" in content
    assert "follows_tool_call" in content
    assert "session_id" in content
    assert "usage_log" in content
    assert "debug_log" in content


def test_sensitive_table_grants_have_role_guards():
    """Migrations with GRANT to authenticated/service_role must guard with IF EXISTS."""
    schema_dir = os.path.join(os.path.dirname(__file__), "..", "schema")
    guarded_files = ["009_customer_tips.sql", "011_raw_documents.sql", "012_customer_isolation.sql"]
    for filename in guarded_files:
        path = os.path.join(schema_dir, filename)
        with open(path) as f:
            content = f.read()
        content_lower = content.lower()
        assert "grant" in content_lower, f"{filename} missing GRANT"
        # Should use pg_roles check instead of bare GRANT
        assert "pg_roles" in content_lower, (
            f"{filename} has GRANT but no pg_roles guard -- should check role existence"
        )


def test_rls_migration_has_table_guards():
    """RLS migration should tolerate missing tables."""
    supabase_dir = os.path.join(os.path.dirname(__file__), "..", "supabase", "migrations")
    path = os.path.join(supabase_dir, "20260317070001_rls_policies.sql")
    with open(path) as f:
        content = f.read()
    content_lower = content.lower()
    assert "undefined_table" in content_lower, (
        "RLS migration should handle undefined_table for partial migration safety"
    )
