"""Tests for resilience module: error classification, retry wrapper, and tool safety."""

import time
from unittest.mock import patch, MagicMock, call

import httpx
import pytest

from coppermind_cmo.resilience import (
    classify_error,
    resilient_call,
    safe_tool_call,
)


# ---------------------------------------------------------------------------
# Error classification tests
# ---------------------------------------------------------------------------

class TestClassifyError:
    def test_connection_error_is_transient(self):
        assert classify_error(ConnectionError("refused")) == "transient"

    def test_timeout_error_is_transient(self):
        assert classify_error(TimeoutError("timed out")) == "transient"

    def test_httpx_connect_error_is_transient(self):
        assert classify_error(httpx.ConnectError("refused")) == "transient"

    def test_httpx_timeout_is_transient(self):
        assert classify_error(httpx.TimeoutException("timeout")) == "transient"

    def test_httpx_remote_protocol_error_is_transient(self):
        assert classify_error(httpx.RemoteProtocolError("protocol error")) == "transient"

    def test_http_502_is_transient(self):
        exc = httpx.HTTPStatusError(
            "502", request=MagicMock(), response=MagicMock(status_code=502)
        )
        assert classify_error(exc) == "transient"

    def test_http_503_is_transient(self):
        exc = httpx.HTTPStatusError(
            "503", request=MagicMock(), response=MagicMock(status_code=503)
        )
        assert classify_error(exc) == "transient"

    def test_http_504_is_transient(self):
        exc = httpx.HTTPStatusError(
            "504", request=MagicMock(), response=MagicMock(status_code=504)
        )
        assert classify_error(exc) == "transient"

    def test_http_429_is_rate_limit(self):
        exc = httpx.HTTPStatusError(
            "429", request=MagicMock(), response=MagicMock(status_code=429)
        )
        assert classify_error(exc) == "rate_limit"

    def test_http_401_is_auth(self):
        exc = httpx.HTTPStatusError(
            "401", request=MagicMock(), response=MagicMock(status_code=401)
        )
        assert classify_error(exc) == "auth"

    def test_http_403_is_auth(self):
        exc = httpx.HTTPStatusError(
            "403", request=MagicMock(), response=MagicMock(status_code=403)
        )
        assert classify_error(exc) == "auth"

    def test_http_400_is_input(self):
        exc = httpx.HTTPStatusError(
            "400", request=MagicMock(), response=MagicMock(status_code=400)
        )
        assert classify_error(exc) == "input"

    def test_http_404_is_input(self):
        exc = httpx.HTTPStatusError(
            "404", request=MagicMock(), response=MagicMock(status_code=404)
        )
        assert classify_error(exc) == "input"

    def test_http_422_is_input(self):
        exc = httpx.HTTPStatusError(
            "422", request=MagicMock(), response=MagicMock(status_code=422)
        )
        assert classify_error(exc) == "input"

    def test_http_500_is_server(self):
        exc = httpx.HTTPStatusError(
            "500", request=MagicMock(), response=MagicMock(status_code=500)
        )
        assert classify_error(exc) == "server"

    def test_value_error_is_input(self):
        assert classify_error(ValueError("bad value")) == "input"

    def test_type_error_is_input(self):
        assert classify_error(TypeError("wrong type")) == "input"

    def test_key_error_is_input(self):
        assert classify_error(KeyError("missing")) == "input"

    def test_unknown_exception_is_unknown(self):
        assert classify_error(RuntimeError("oops")) == "unknown"

    def test_generic_exception_is_unknown(self):
        assert classify_error(Exception("something")) == "unknown"


# ---------------------------------------------------------------------------
# Resilient call tests
# ---------------------------------------------------------------------------

class TestResilientCall:
    def test_success_on_first_attempt(self):
        func = MagicMock(return_value="ok")
        result = resilient_call(func, service_name="test")
        assert result == "ok"
        assert func.call_count == 1

    def test_passes_args_and_kwargs(self):
        func = MagicMock(return_value="result")
        resilient_call(func, "arg1", "arg2", service_name="test", key="val")
        func.assert_called_once_with("arg1", "arg2", key="val")

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_retries_on_transient_error(self, mock_sleep):
        func = MagicMock(side_effect=[ConnectionError("fail"), "ok"])
        result = resilient_call(func, service_name="test", backoff_base=1.0)
        assert result == "ok"
        assert func.call_count == 2
        mock_sleep.assert_called_once_with(1.0)

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_retries_with_exponential_backoff(self, mock_sleep):
        func = MagicMock(side_effect=[
            ConnectionError("fail"),
            ConnectionError("fail again"),
            "ok",
        ])
        result = resilient_call(func, service_name="test", backoff_base=1.0, max_attempts=3)
        assert result == "ok"
        assert func.call_count == 3
        # Backoff: 1s (2^0), 2s (2^1)
        mock_sleep.assert_has_calls([call(1.0), call(2.0)])

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_raises_after_max_attempts(self, mock_sleep):
        func = MagicMock(side_effect=ConnectionError("fail"))
        with pytest.raises(ConnectionError, match="fail"):
            resilient_call(func, service_name="test", max_attempts=3)
        assert func.call_count == 3

    def test_does_not_retry_auth_errors(self):
        exc = httpx.HTTPStatusError(
            "401", request=MagicMock(), response=MagicMock(status_code=401)
        )
        func = MagicMock(side_effect=exc)
        with pytest.raises(httpx.HTTPStatusError):
            resilient_call(func, service_name="test")
        assert func.call_count == 1  # no retry

    def test_does_not_retry_input_errors(self):
        func = MagicMock(side_effect=ValueError("bad input"))
        with pytest.raises(ValueError):
            resilient_call(func, service_name="test")
        assert func.call_count == 1

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_retries_rate_limit_errors(self, mock_sleep):
        exc = httpx.HTTPStatusError(
            "429", request=MagicMock(),
            response=MagicMock(status_code=429, headers={}),
        )
        func = MagicMock(side_effect=[exc, "ok"])
        result = resilient_call(func, service_name="test", backoff_base=1.0)
        assert result == "ok"
        assert func.call_count == 2

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_respects_retry_after_header(self, mock_sleep):
        exc = httpx.HTTPStatusError(
            "429", request=MagicMock(),
            response=MagicMock(status_code=429, headers={"Retry-After": "10"}),
        )
        func = MagicMock(side_effect=[exc, "ok"])
        resilient_call(func, service_name="test", backoff_base=1.0)
        # Should use max(base_delay=1.0, Retry-After=10) = 10
        mock_sleep.assert_called_once_with(10.0)

    @patch("coppermind_cmo.resilience.time.sleep")
    def test_retries_server_errors(self, mock_sleep):
        exc = httpx.HTTPStatusError(
            "500", request=MagicMock(), response=MagicMock(status_code=500)
        )
        func = MagicMock(side_effect=[exc, "ok"])
        result = resilient_call(func, service_name="test")
        assert result == "ok"
        assert func.call_count == 2

    def test_custom_max_attempts(self):
        func = MagicMock(return_value="ok")
        resilient_call(func, service_name="test", max_attempts=1)
        assert func.call_count == 1


# ---------------------------------------------------------------------------
# Safe tool call decorator tests
# ---------------------------------------------------------------------------

class TestSafeToolCall:
    def test_successful_call_passes_through(self):
        @safe_tool_call("test_tool")
        def my_tool(x):
            return {"result": x}

        assert my_tool(42) == {"result": 42}

    def test_catches_connection_error(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise ConnectionError("connection refused")

        result = my_tool()
        assert result["error"] is True
        assert result["code"] == "SERVICE_UNAVAILABLE"

    def test_catches_timeout_error(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise TimeoutError("timed out")

        result = my_tool()
        assert result["error"] is True
        assert result["code"] == "SERVICE_UNAVAILABLE"

    def test_catches_httpx_503(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise httpx.HTTPStatusError(
                "503", request=MagicMock(),
                response=MagicMock(status_code=503),
            )

        result = my_tool()
        assert result["error"] is True
        assert result["code"] == "SERVICE_UNAVAILABLE"

    def test_catches_auth_error(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise httpx.HTTPStatusError(
                "401", request=MagicMock(),
                response=MagicMock(status_code=401),
            )

        result = my_tool()
        assert result["error"] is True
        assert result["code"] == "ACCESS_DENIED"

    def test_catches_rate_limit(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise httpx.HTTPStatusError(
                "429", request=MagicMock(),
                response=MagicMock(status_code=429, headers={}),
            )

        result = my_tool()
        assert result["error"] is True
        assert result["code"] == "RATE_LIMITED"

    def test_catches_input_error(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise ValueError("bad value")

        result = my_tool()
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"
        assert "bad value" in result["message"]

    def test_catches_unknown_error(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise RuntimeError("unexpected")

        result = my_tool()
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"

    def test_does_not_catch_system_exit(self):
        @safe_tool_call("test_tool")
        def my_tool():
            raise SystemExit(1)

        with pytest.raises(SystemExit):
            my_tool()

    def test_preserves_function_name(self):
        @safe_tool_call("test_tool")
        def my_tool():
            """My docstring."""
            return {}

        assert my_tool.__name__ == "my_tool"
        assert my_tool.__doc__ == "My docstring."

    def test_passes_args_correctly(self):
        @safe_tool_call("test_tool")
        def my_tool(a, b, c=None):
            return {"sum": a + b, "c": c}

        result = my_tool(1, 2, c=3)
        assert result == {"sum": 3, "c": 3}

    @patch("coppermind_cmo.resilience.logger")
    def test_logs_error_on_failure(self, mock_logger):
        @safe_tool_call("test_tool")
        def my_tool():
            raise RuntimeError("boom")

        my_tool()
        mock_logger.error.assert_called_once()
        log_msg = mock_logger.error.call_args.args[0]
        assert "test_tool" in log_msg

    def test_all_error_responses_have_error_true(self):
        """Every error category maps to an error dict with error=True."""
        exceptions = [
            ConnectionError("transient"),
            httpx.HTTPStatusError("429", request=MagicMock(),
                                  response=MagicMock(status_code=429, headers={})),
            httpx.HTTPStatusError("401", request=MagicMock(),
                                  response=MagicMock(status_code=401)),
            ValueError("input"),
            RuntimeError("unknown"),
        ]
        for exc in exceptions:
            @safe_tool_call("test_tool")
            def my_tool():
                raise exc

            result = my_tool()
            assert result["error"] is True, f"Failed for {type(exc).__name__}"
            assert "code" in result
            assert "message" in result
