"""Tests for coppermind_cmo.cadence_utils."""

from datetime import date, timedelta
from unittest.mock import patch

from coppermind_cmo.cadence_utils import get_current_sprint


class TestGetCurrentSprint:
    """Test get_current_sprint with various inputs."""

    def test_sprint_plan_with_dates_first_sprint(self):
        """Current date before first end date returns sprint 1."""
        today = date.today()
        dates = [
            (today + timedelta(days=5)).isoformat(),
            (today + timedelta(days=19)).isoformat(),
            (today + timedelta(days=33)).isoformat(),
        ]
        cadence = {"year": 2026, "quarter": 1, "sprint": 2}
        plan = {"sprint_end_dates": dates}
        assert get_current_sprint(cadence, plan) == 1

    def test_sprint_plan_with_dates_middle_sprint(self):
        """Current date between first and second end dates returns sprint 2."""
        today = date.today()
        dates = [
            (today - timedelta(days=5)).isoformat(),
            (today + timedelta(days=10)).isoformat(),
            (today + timedelta(days=25)).isoformat(),
        ]
        cadence = {"year": 2026, "quarter": 1}
        plan = {"sprint_end_dates": dates}
        assert get_current_sprint(cadence, plan) == 2

    def test_sprint_plan_with_dates_last_sprint(self):
        """Current date between second-to-last and last end dates returns last sprint."""
        today = date.today()
        dates = [
            (today - timedelta(days=20)).isoformat(),
            (today - timedelta(days=5)).isoformat(),
            (today + timedelta(days=10)).isoformat(),
        ]
        cadence = {}
        plan = {"sprint_end_dates": dates}
        assert get_current_sprint(cadence, plan) == 3

    def test_sprint_plan_all_dates_passed(self):
        """All end dates in the past returns len(dates) (last sprint number)."""
        today = date.today()
        dates = [
            (today - timedelta(days=30)).isoformat(),
            (today - timedelta(days=15)).isoformat(),
            (today - timedelta(days=1)).isoformat(),
        ]
        cadence = {}
        plan = {"sprint_end_dates": dates}
        assert get_current_sprint(cadence, plan) == 3

    def test_exactly_on_sprint_end_date(self):
        """Current date equal to an end date should count as that sprint."""
        today = date.today()
        dates = [
            today.isoformat(),
            (today + timedelta(days=14)).isoformat(),
        ]
        cadence = {}
        plan = {"sprint_end_dates": dates}
        # today <= end_date for sprint 1, so returns 1
        assert get_current_sprint(cadence, plan) == 1

    def test_no_sprint_plan_fallback_to_cadence(self):
        """Without sprint plan, falls back to cadence.sprint."""
        cadence = {"year": 2026, "quarter": 2, "sprint": 3, "sprints_per_quarter": 6}
        assert get_current_sprint(cadence, None) == 3

    def test_no_sprint_plan_no_cadence_sprint(self):
        """Without sprint plan or cadence.sprint, returns None."""
        cadence = {"year": 2026, "quarter": 2}
        assert get_current_sprint(cadence, None) is None

    def test_empty_cadence_no_plan(self):
        """Empty cadence and no plan returns None."""
        assert get_current_sprint({}, None) is None

    def test_empty_cadence_empty_plan(self):
        """Empty cadence and empty plan returns None."""
        assert get_current_sprint({}, {}) is None

    def test_plan_with_empty_dates_list(self):
        """Plan with empty sprint_end_dates falls back to cadence."""
        cadence = {"sprint": 4}
        plan = {"sprint_end_dates": []}
        assert get_current_sprint(cadence, plan) == 4

    def test_malformed_dates_skipped(self):
        """Malformed date strings are skipped."""
        today = date.today()
        dates = [
            "not-a-date",
            (today + timedelta(days=10)).isoformat(),
        ]
        cadence = {}
        plan = {"sprint_end_dates": dates}
        # First date is malformed (skipped), second is future -> sprint 2
        assert get_current_sprint(cadence, plan) == 2

    def test_all_malformed_dates_fallback(self):
        """All malformed dates means no valid sprint from plan, falls back to cadence.sprint."""
        cadence = {"sprint": 5}
        plan = {"sprint_end_dates": ["bad", "also-bad"]}
        # No valid dates found, falls through to cadence.sprint = 5
        assert get_current_sprint(cadence, plan) == 5

    def test_mixed_valid_invalid_all_past(self):
        """When valid dates are past and invalid dates exist, return count of valid dates only."""
        cadence = {}
        plan = {"sprint_end_dates": ["2025-01-01", "bad"]}
        # Only 1 valid date (past), so should return 1, not len(dates)=2
        assert get_current_sprint(cadence, plan) == 1

    def test_cadence_sprint_zero_invalid(self):
        """cadence.sprint must be >= 1."""
        cadence = {"sprint": 0}
        assert get_current_sprint(cadence, None) is None

    def test_cadence_sprint_negative_invalid(self):
        """Negative cadence.sprint returns None."""
        cadence = {"sprint": -1}
        assert get_current_sprint(cadence, None) is None

    def test_cadence_sprint_non_int(self):
        """Non-integer cadence.sprint returns None."""
        cadence = {"sprint": "three"}
        assert get_current_sprint(cadence, None) is None

    def test_date_objects_in_plan(self):
        """Plan with date objects (not strings) works too."""
        today = date.today()
        dates = [
            today + timedelta(days=5),
            today + timedelta(days=20),
        ]
        cadence = {}
        plan = {"sprint_end_dates": dates}
        assert get_current_sprint(cadence, plan) == 1

    def test_non_list_sprint_end_dates(self):
        """Non-list sprint_end_dates falls back to cadence."""
        cadence = {"sprint": 2}
        plan = {"sprint_end_dates": "not-a-list"}
        assert get_current_sprint(cadence, plan) == 2

    def test_none_entries_in_dates_skipped(self):
        """None entries in dates list are skipped."""
        today = date.today()
        dates = [
            None,
            (today + timedelta(days=10)).isoformat(),
        ]
        cadence = {}
        plan = {"sprint_end_dates": dates}
        # None is skipped (continue), next date is future -> sprint 2
        assert get_current_sprint(cadence, plan) == 2

    def test_numeric_entries_in_dates_skipped(self):
        """Numeric entries in dates list are skipped (not str or date)."""
        today = date.today()
        dates = [
            12345,
            (today + timedelta(days=10)).isoformat(),
        ]
        cadence = {}
        plan = {"sprint_end_dates": dates}
        assert get_current_sprint(cadence, plan) == 2
