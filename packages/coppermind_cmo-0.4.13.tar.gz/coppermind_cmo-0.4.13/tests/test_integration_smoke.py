"""Smoke test: verify all tools register and the server module loads."""


def test_server_module_imports():
    """Verify server.py can be imported without side effects."""
    from coppermind_cmo import server
    assert hasattr(server, 'mcp')
    assert hasattr(server, 'main')


def test_all_tool_modules_import():
    """Verify all tool modules can be imported."""
    from coppermind_cmo.tools import minds, memories, brand, intelligence
    assert hasattr(minds, 'register')
    assert hasattr(memories, 'register')
    assert hasattr(brand, 'register')
    assert hasattr(intelligence, 'register')


def test_config_imports():
    from coppermind_cmo.config import Config
    c = Config()
    assert c.pg_host == ""  # hosted-only: populated by gateway provisioning
    assert c.llm_provider == "gateway"


def test_errors_import():
    from coppermind_cmo.errors import NO_ACTIVE_MIND, tool_error
    result = NO_ACTIVE_MIND()
    assert result["error"] is True
