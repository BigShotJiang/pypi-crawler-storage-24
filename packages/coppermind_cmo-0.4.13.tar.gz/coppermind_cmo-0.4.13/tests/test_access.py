"""Tests for access enforcement helpers in tools/access.py."""

from unittest.mock import MagicMock

from coppermind_cmo.tools.access import (
    VIEWER_DEFAULT_ALLOWED_TYPES,
    _get_access_level,
    _access_filters,
    get_viewer_allowed_types,
)


class TestGetAccessLevel:
    def _make_db(self, *return_values):
        db = MagicMock()
        db.fetch_one.side_effect = list(return_values)
        return db

    def test_owner_by_direct_ownership(self):
        db = self._make_db((1,))
        result = _get_access_level("mind-1", "customer-1", db)
        assert result == "owner"

    def test_viewer_by_access_grant(self):
        # First call (client_minds) returns None, second call (access grant) returns viewer
        db = self._make_db(None, ("viewer",))
        result = _get_access_level("mind-1", "customer-1", db)
        assert result == "viewer"

    def test_no_access_returns_none(self):
        db = self._make_db(None, None)
        result = _get_access_level("mind-1", "customer-1", db)
        assert result is None

    def test_none_customer_id_returns_none(self):
        db = MagicMock()
        result = _get_access_level("mind-1", None, db)
        assert result is None
        db.fetch_one.assert_not_called()


class TestAccessFilters:
    def test_owner_returns_status_not_pending(self):
        sql, params = _access_filters("owner", "caller-1")
        assert "status != 'pending'" in sql
        assert "memory_type" not in sql
        assert "sensitivity" not in sql

    def test_owner_params_empty(self):
        sql, params = _access_filters("owner", "caller-1")
        assert params == []

    def test_viewer_returns_memory_type_in_filter(self):
        sql, params = _access_filters("viewer", "caller-1")
        assert "memory_type IN" in sql

    def test_viewer_returns_sensitivity_open(self):
        sql, params = _access_filters("viewer", "caller-1")
        assert "sensitivity = 'open'" in sql

    def test_viewer_returns_status_filter_with_created_by(self):
        sql, params = _access_filters("viewer", "caller-1")
        assert "status = 'active'" in sql
        assert "created_by" in sql
        assert "caller-1" in params

    def test_viewer_default_allowed_types_in_params(self):
        sql, params = _access_filters("viewer", "caller-1")
        # All default allowed types should be in params
        for t in VIEWER_DEFAULT_ALLOWED_TYPES:
            assert t in params

    def test_viewer_custom_allowed_types(self):
        custom_types = ["decision", "preference"]
        sql, params = _access_filters("viewer", "caller-1", allowed_types=custom_types)
        assert "decision" in params
        assert "preference" in params
        # Default-only types should not be included if not in custom_types
        for t in VIEWER_DEFAULT_ALLOWED_TYPES:
            if t not in custom_types:
                assert t not in params



class TestGetViewerAllowedTypes:
    def test_none_sharing_config_returns_none(self):
        result = get_viewer_allowed_types(None)
        assert result is None

    def test_empty_dict_returns_none(self):
        result = get_viewer_allowed_types({})
        assert result is None

    def test_dict_with_viewer_allowed_types_returns_list(self):
        config = {"viewer_allowed_types": ["decision", "fact"]}
        result = get_viewer_allowed_types(config)
        assert result == ["decision", "fact"]

    def test_dict_without_viewer_allowed_types_returns_none(self):
        config = {"other_key": "value"}
        result = get_viewer_allowed_types(config)
        assert result is None


class TestRevokedAtFiltering:
    def test_switch_client_excludes_revoked(self):
        from coppermind_cmo.tools import minds as minds_mod
        import inspect
        source = inspect.getsource(minds_mod._switch_client)
        assert "revoked_at IS NULL" in source

    def test_list_minds_excludes_revoked(self):
        from coppermind_cmo.tools import minds as minds_mod
        import inspect
        source = inspect.getsource(minds_mod._list_minds)
        assert "revoked_at IS NULL" in source

    def test_daily_loop_cross_client_excludes_revoked(self):
        from coppermind_cmo.tools import daily_loop
        import inspect
        source = inspect.getsource(daily_loop._get_cross_client_summary)
        assert "revoked_at IS NULL" in source

    def test_daily_loop_meeting_context_excludes_revoked_twice(self):
        from coppermind_cmo.tools import daily_loop
        import inspect
        source = inspect.getsource(daily_loop._get_meeting_context)
        assert source.count("revoked_at IS NULL") >= 2

    def test_daily_loop_weekly_excludes_revoked(self):
        from coppermind_cmo.tools import daily_loop
        import inspect
        source = inspect.getsource(daily_loop._get_weekly_summary)
        assert "revoked_at IS NULL" in source

    def test_daily_loop_meeting_context_excludes_revoked(self):
        from coppermind_cmo.tools import daily_loop
        import inspect
        source = inspect.getsource(daily_loop._get_meeting_context)
        assert "revoked_at IS NULL" in source
