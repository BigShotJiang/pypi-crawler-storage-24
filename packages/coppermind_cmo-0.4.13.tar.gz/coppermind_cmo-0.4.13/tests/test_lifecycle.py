"""Tests for coppermind_cmo.lifecycle — centralized EOS state machines."""

import pytest
from coppermind_cmo.lifecycle import (
    validate_transition, get_transition_fields, InvalidTransition,
    is_now_sentinel, _NOW,
    ENTITY_AGENDA, ENTITY_ISSUE, ENTITY_ROCK, ENTITY_DELIVERABLE,
    AGENDA_TRANSITIONS, ISSUE_TRANSITIONS,
)


class TestAgendaTransitions:
    @pytest.mark.parametrize("from_s,to_s", [
        ("proposed", "scheduled"), ("proposed", "resolved"), ("proposed", "deferred"),
        ("scheduled", "discussed"), ("scheduled", "resolved"), ("scheduled", "deferred"),
        ("discussed", "resolved"), ("discussed", "deferred"), ("discussed", "scheduled"),
        ("resolved", "scheduled"),
        ("deferred", "scheduled"),
    ])
    def test_allowed(self, from_s, to_s):
        validate_transition(ENTITY_AGENDA, from_s, to_s)  # should not raise

    @pytest.mark.parametrize("from_s,to_s", [
        ("proposed", "discussed"),
        ("resolved", "resolved"), ("resolved", "deferred"),
        ("deferred", "deferred"), ("deferred", "resolved"),
    ])
    def test_rejected(self, from_s, to_s):
        with pytest.raises(InvalidTransition):
            validate_transition(ENTITY_AGENDA, from_s, to_s)


class TestIssueTransitions:
    @pytest.mark.parametrize("from_s,to_s", [
        ("identified", "discussed"), ("identified", "solved"), ("identified", "deferred"),
        ("discussed", "solved"), ("discussed", "deferred"),
        ("solved", "discussed"),
        ("deferred", "discussed"),
    ])
    def test_allowed(self, from_s, to_s):
        validate_transition(ENTITY_ISSUE, from_s, to_s)

    @pytest.mark.parametrize("from_s,to_s", [
        ("identified", "identified"),
        ("solved", "solved"), ("solved", "deferred"),
        ("deferred", "deferred"), ("deferred", "solved"),
    ])
    def test_rejected(self, from_s, to_s):
        with pytest.raises(InvalidTransition):
            validate_transition(ENTITY_ISSUE, from_s, to_s)


class TestFreeFormEntities:
    @pytest.mark.parametrize("entity", [ENTITY_ROCK, ENTITY_DELIVERABLE])
    def test_any_transition_allowed(self, entity):
        validate_transition(entity, "anything", "anything_else")


class TestAgendaFieldRules:
    def test_resolved(self):
        fields = get_transition_fields(ENTITY_AGENDA, "resolved")
        assert fields["set"] == {"resolved_at": _NOW}
        assert fields["clear"] == []

    def test_deferred(self):
        fields = get_transition_fields(ENTITY_AGENDA, "deferred")
        assert fields["set"] == {"resolved_at": _NOW}
        assert fields["clear"] == []

    def test_scheduled(self):
        fields = get_transition_fields(ENTITY_AGENDA, "scheduled")
        assert fields["set"] == {}
        assert fields["clear"] == ["resolved_at"]

    def test_discussed(self):
        fields = get_transition_fields(ENTITY_AGENDA, "discussed")
        assert fields["set"] == {}
        assert fields["clear"] == []

    def test_proposed(self):
        fields = get_transition_fields(ENTITY_AGENDA, "proposed")
        assert fields["set"] == {}
        assert "resolved_at" in fields["clear"]
        assert "meeting_date" in fields["clear"]


class TestIssueFieldRules:
    def test_solved(self):
        fields = get_transition_fields(ENTITY_ISSUE, "solved")
        assert fields["set"] == {"resolved_at": _NOW}
        assert fields["clear"] == []

    def test_deferred(self):
        fields = get_transition_fields(ENTITY_ISSUE, "deferred")
        assert fields["set"] == {}
        assert set(fields["clear"]) == {"resolved_at", "resolution", "commitment_id"}

    def test_discussed(self):
        fields = get_transition_fields(ENTITY_ISSUE, "discussed")
        assert fields["set"] == {}
        assert set(fields["clear"]) == {"resolved_at", "resolution", "commitment_id"}


class TestReturnImmutability:
    def test_mutating_result_does_not_affect_source(self):
        fields1 = get_transition_fields(ENTITY_ISSUE, "deferred")
        fields1["clear"].append("extra_field")
        fields2 = get_transition_fields(ENTITY_ISSUE, "deferred")
        assert "extra_field" not in fields2["clear"]


class TestNowSentinel:
    def test_sentinel_detected(self):
        assert is_now_sentinel(_NOW)

    def test_non_sentinel(self):
        assert not is_now_sentinel("NOW")  # string "NOW" is not the sentinel object
        assert not is_now_sentinel(None)
        assert not is_now_sentinel(42)
