"""Tests for customer data isolation (RLS + hosted-only enforcement).

All tests verify that customers can only see/modify minds they own
or have explicit access to. Hosted-only: no customer_id always means denied.

Also tests Database._apply_isolation (RLS defense-in-depth layer).
"""

from unittest.mock import MagicMock, call, patch

import pytest

import coppermind_cmo.db as db_mod
from coppermind_cmo.db import Database
from coppermind_cmo.tools.minds import (
    _switch_client, _list_minds, _verify_mind_access,
)


@pytest.fixture(autouse=True)
def reset_minds_cache(monkeypatch):
    """Reset module-level schema cache before each test."""
    monkeypatch.setattr("coppermind_cmo.tools.minds._has_internal_col", None)


@pytest.fixture
def db_with_isolation():
    """Mock DB that supports customer isolation queries."""
    return MagicMock()


class TestSwitchClientCustomerFiltering:
    def test_filters_by_customer(self, db_with_isolation):
        """Customer A creates a mind, customer B cannot see it via switch_client."""
        db = db_with_isolation
        db.fetch_one.return_value = None  # all queries return nothing
        set_mind = MagicMock()

        result = _switch_client("Acme Corp", False, db, set_mind, customer_id="customer_b")

        assert result["code"] == "MIND_NOT_FOUND"
        set_mind.assert_not_called()

        # Verify the lookup SQL included customer_id/access filtering
        calls = db.fetch_one.call_args_list
        lookup_sql = calls[-1][0][0]
        assert "customer_id" in lookup_sql or "customer_mind_access" in lookup_sql

    def test_no_customer_id_provisioning_error(self, db_with_isolation):
        """switch_client without customer_id returns PROVISIONING_ERROR."""
        db = db_with_isolation
        set_mind = MagicMock()

        result = _switch_client("Acme Corp", False, db, set_mind, customer_id=None)

        assert result["code"] == "PROVISIONING_ERROR"
        set_mind.assert_not_called()
        db.fetch_one.assert_not_called()

    def test_creates_with_customer_id(self, db_with_isolation):
        """New mind has customer_id set."""
        db = db_with_isolation
        db.fetch_one.side_effect = [
            None,  # _has_is_internal: not present
            None,  # lookup: not found
            None,  # slug check: not taken
        ]
        db.execute_returning.return_value = ("uuid-new", "Acme Corp", "acme-corp")
        set_mind = MagicMock()

        result = _switch_client("Acme Corp", True, db, set_mind, customer_id="customer_a")

        assert result["is_new"] is True
        insert_sql = db.execute_returning.call_args[0][0]
        assert "customer_id" in insert_sql
        insert_params = db.execute_returning.call_args[0][1]
        assert "customer_a" in insert_params

    def test_creates_access_mapping(self, db_with_isolation):
        """New mind has customer_mind_access row created."""
        db = db_with_isolation
        db.fetch_one.side_effect = [
            None,  # _has_is_internal: not present
            None,  # lookup: not found
            None,  # slug check: not taken
        ]
        db.execute_returning.return_value = ("uuid-new", "Acme Corp", "acme-corp")
        set_mind = MagicMock()

        _switch_client("Acme Corp", True, db, set_mind, customer_id="customer_a")

        access_calls = [c for c in db.execute.call_args_list
                        if "customer_mind_access" in str(c)]
        assert len(access_calls) >= 1
        access_sql = access_calls[0][0][0]
        assert "INSERT INTO customer_mind_access" in access_sql
        access_params = access_calls[0][0][1]
        assert access_params[0] == "customer_a"
        assert access_params[1] == "uuid-new"


class TestListMindsCustomerFiltering:
    def test_filters_by_customer(self, db_with_isolation):
        """Customer A's minds not visible to customer B."""
        db = db_with_isolation
        db.fetch_one.return_value = None  # _has_is_internal: not present
        db.fetch_all.return_value = []

        result = _list_minds(50, 0, db, customer_id="customer_b")

        assert result == []
        call_sql = db.fetch_all.call_args[0][0]
        assert "customer_id" in call_sql

    def test_shows_shared_minds(self, db_with_isolation):
        """Mind with access mapping visible to granted customer."""
        db = db_with_isolation
        from datetime import datetime
        db.fetch_one.return_value = None  # _has_is_internal: not present
        db.fetch_all.return_value = [
            ("uuid-shared", "Shared Client", "shared-client", None, 5,
             datetime(2026, 1, 1), datetime(2026, 3, 1)),
        ]

        result = _list_minds(50, 0, db, customer_id="customer_b")

        assert len(result) == 1
        assert result[0]["name"] == "Shared Client"
        call_sql = db.fetch_all.call_args[0][0]
        assert "customer_mind_access" in call_sql

    def test_no_customer_id_returns_empty(self, db_with_isolation):
        """list_minds without customer_id returns empty list without querying DB."""
        db = db_with_isolation

        result = _list_minds(50, 0, db, customer_id=None)

        assert result == []
        db.fetch_all.assert_not_called()


class TestConfigureMindAccessDenied:
    def test_access_denied(self, db_with_isolation):
        """Customer B cannot configure customer A's mind."""
        db = db_with_isolation
        db.fetch_one.side_effect = [
            None,  # ownership check: not owner
            None,  # access table check: no mapping
        ]

        result = _verify_mind_access("mind-uuid", "customer_b", db)
        assert result is False


class TestStoreMemoryAccessDenied:
    def test_access_denied(self):
        """Customer B cannot store memories on customer A's mind."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            None,  # ownership: not owner
            None,  # access mapping: no entry
        ]

        assert _verify_mind_access("mind-uuid", "customer_b", db) is False


class TestVerifyMindAccess:
    def test_owner_passes(self):
        """Owner passes verification."""
        db = MagicMock()
        db.fetch_one.return_value = (1,)

        assert _verify_mind_access("mind-uuid", "customer_a", db) is True

    def test_access_mapping_passes(self):
        """Customer with access mapping passes."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            None,  # ownership: not owner
            (1,),  # access mapping: found
        ]

        assert _verify_mind_access("mind-uuid", "customer_b", db) is True

    def test_no_access_denied(self):
        """Customer without ownership or mapping fails."""
        db = MagicMock()
        db.fetch_one.side_effect = [
            None,  # ownership: not owner
            None,  # access mapping: not found
        ]

        assert _verify_mind_access("mind-uuid", "customer_c", db) is False

    def test_no_customer_id_denied(self):
        """No customer_id (misconfigured) → denied, no DB queries made."""
        db = MagicMock()
        assert _verify_mind_access("any-mind", None, db) is False
        db.fetch_one.assert_not_called()


# ---------------------------------------------------------------------------
# TestApplyIsolation — unit tests for Database._apply_isolation
# ---------------------------------------------------------------------------

def _make_db(customer_id=""):
    """Instantiate Database without triggering pool creation."""
    db = Database.__new__(Database)
    config = MagicMock()
    config.customer_id = customer_id
    db._config = config
    return db


@pytest.fixture(autouse=True)
def reset_rls_warned():
    """Reset module-level warn flag before each test for isolation."""
    db_mod._rls_degraded_warned = False
    yield
    db_mod._rls_degraded_warned = False


class TestApplyIsolation:
    def test_no_op_when_customer_id_empty(self):
        """Empty customer_id → returns False, no SQL executed."""
        db = _make_db(customer_id="")
        conn = MagicMock()

        result = db._apply_isolation(conn)

        assert result is False
        conn.cursor.assert_not_called()

    def test_no_op_when_customer_id_none(self):
        """None customer_id → returns False, no SQL executed."""
        db = _make_db()
        db._config.customer_id = None
        conn = MagicMock()

        result = db._apply_isolation(conn)

        assert result is False
        conn.cursor.assert_not_called()

    def test_applies_customer_id_when_set(self):
        """With a real customer_id, issues SET LOCAL app.customer_id."""
        db = _make_db(customer_id="cust-abc")
        mock_cur = MagicMock()
        conn = MagicMock()
        conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cur)
        conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        result = db._apply_isolation(conn)

        assert result is True
        assert mock_cur.execute.call_count == 1
        mock_cur.execute.assert_called_once_with(
            "SET LOCAL app.customer_id = %s", ["cust-abc"]
        )

    def test_graceful_degradation_on_set_failure(self):
        """psycopg2 error on SET LOCAL → returns False, rollback called."""
        import psycopg2
        db = _make_db(customer_id="cust-abc")
        mock_cur = MagicMock()
        mock_cur.execute.side_effect = psycopg2.OperationalError("connection lost")
        conn = MagicMock()
        conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cur)
        conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        result = db._apply_isolation(conn)

        assert result is False
        conn.rollback.assert_called_once()

    def test_graceful_degradation_does_not_raise(self):
        """_apply_isolation itself never raises — it returns False on failure.

        NOTE: connection() enforces fail-closed behavior when customer_id
        is set. See TestFailClosedIsolation for those tests.
        """
        db = _make_db(customer_id="cust-abc")
        conn = MagicMock()
        conn.cursor.side_effect = RuntimeError("unexpected cursor failure")

        result = db._apply_isolation(conn)

        assert result is False

    def test_isolation_applied_in_connection_context(self):
        """_apply_isolation is called before yield inside connection()."""
        db = _make_db(customer_id="cust-xyz")
        mock_conn = MagicMock()
        mock_conn.closed = False

        call_order = []

        def fake_apply_isolation(conn):
            call_order.append("isolation")
            return True

        db._apply_isolation = fake_apply_isolation
        db._pool = MagicMock()
        db._pool.getconn.return_value = mock_conn

        with db.connection() as conn:
            call_order.append("yield")

        assert call_order == ["isolation", "yield"]

    def test_warn_logged_only_once(self):
        """Degradation warning fires at most once per process restart."""
        import psycopg2
        db = _make_db(customer_id="cust-abc")

        mock_cur = MagicMock()
        mock_cur.execute.side_effect = psycopg2.OperationalError("no role")
        conn = MagicMock()
        conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cur)
        conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        with patch.object(db_mod.logger, "warn") as mock_warn:
            db._apply_isolation(conn)
            db._apply_isolation(conn)
            db._apply_isolation(conn)

        assert mock_warn.call_count == 1


# ---------------------------------------------------------------------------
# TestFailClosedIsolation — connection() blocks queries when RLS fails
# in hosted mode (customer_id set), but allows degraded in self-hosted mode.
# ---------------------------------------------------------------------------

class TestFailClosedIsolation:
    def test_connection_raises_when_rls_fails_in_hosted_mode(self):
        """Hosted mode (customer_id set) + RLS failure = TenantIsolationError."""
        from coppermind_cmo.db import TenantIsolationError
        import psycopg2

        db = _make_db(customer_id="cust-abc")
        mock_conn = MagicMock()
        mock_conn.closed = 0

        # Make _apply_isolation fail (role missing)
        mock_cur = MagicMock()
        mock_cur.execute.side_effect = psycopg2.OperationalError("role does not exist")
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cur)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        db._pool = MagicMock()
        db._pool.getconn.return_value = mock_conn

        with pytest.raises(TenantIsolationError, match="RLS isolation required"):
            with db.connection() as conn:
                pass  # should never reach here

    def test_connection_allows_degraded_in_self_hosted_mode(self):
        """Self-hosted mode (no customer_id) + RLS not applied = proceeds fine."""
        db = _make_db(customer_id="")
        mock_conn = MagicMock()
        mock_conn.closed = 0

        db._pool = MagicMock()
        db._pool.getconn.return_value = mock_conn

        # Should not raise — no customer_id means self-hosted, degraded OK
        with db.connection() as conn:
            assert conn is mock_conn

    def test_connection_allows_none_customer_id(self):
        """None customer_id (self-hosted) = no isolation, no error."""
        db = _make_db(customer_id="")
        db._config.customer_id = None
        mock_conn = MagicMock()
        mock_conn.closed = 0

        db._pool = MagicMock()
        db._pool.getconn.return_value = mock_conn

        with db.connection() as conn:
            assert conn is mock_conn

    def test_connection_proceeds_when_rls_succeeds_in_hosted_mode(self):
        """Hosted mode + RLS applied successfully = normal operation."""
        db = _make_db(customer_id="cust-abc")
        mock_conn = MagicMock()
        mock_conn.closed = 0

        # Make _apply_isolation succeed
        mock_cur = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cur)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)

        db._pool = MagicMock()
        db._pool.getconn.return_value = mock_conn

        with db.connection() as conn:
            assert conn is mock_conn

    def test_tenant_isolation_error_is_runtime_error(self):
        """TenantIsolationError is a RuntimeError subclass for catch-all compat."""
        from coppermind_cmo.db import TenantIsolationError
        assert issubclass(TenantIsolationError, RuntimeError)


# ---------------------------------------------------------------------------
# TestRevokedAtFiltering — _verify_mind_access respects revoked_at column
# ---------------------------------------------------------------------------

class TestRevokedAtFiltering:
    def test_revoked_access_denied(self, monkeypatch):
        """When revoked_at column exists and access is revoked, _verify_mind_access returns False."""
        import coppermind_cmo.tools.minds as minds_mod

        # Override autouse fixture: simulate column exists
        minds_mod._has_revoked_at_col = True
        monkeypatch.setattr(
            "coppermind_cmo.tools.minds._has_revoked_at",
            lambda db: True,
        )

        db = MagicMock()
        # Owner check: no (not the owner)
        # Access check with revoked_at IS NULL: no match (access was revoked)
        db.fetch_one.return_value = None

        result = _verify_mind_access("mind-1", "customer-va", db)
        assert result is False

        # Verify the SQL included revoked_at IS NULL
        calls = db.fetch_one.call_args_list
        access_call = calls[-1]  # Last call is the access check
        sql = access_call[0][0]
        assert "revoked_at IS NULL" in sql

    def test_revoked_at_filter_not_applied_when_column_missing(self):
        """When revoked_at column doesn't exist, query does NOT include revoked_at filter."""
        # autouse fixture already patches _has_revoked_at to return False
        # and resets _has_revoked_at_col to None (consistent with "only caches True" invariant)

        db = MagicMock()
        # Owner check: no
        # Access check without revoked_at: returns a row (access granted)
        db.fetch_one.side_effect = [None, (1,)]

        result = _verify_mind_access("mind-1", "customer-va", db)
        assert result is True

        # Verify the SQL did NOT include revoked_at
        calls = db.fetch_one.call_args_list
        access_call = calls[-1]
        sql = access_call[0][0]
        assert "revoked_at" not in sql
