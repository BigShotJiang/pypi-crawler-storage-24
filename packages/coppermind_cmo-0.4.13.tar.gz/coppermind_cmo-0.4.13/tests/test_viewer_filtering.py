"""Tests that viewers are blocked from restricted tools."""
import pytest
from coppermind_cmo.tools.access import _get_access_level


class TestViewerBlockedTools:
    """Verify access check source code exists in blocked tool closures."""

    def _check_tool_source_has_access_check(self, module_path: str, function_name: str):
        """Helper: verify a tool's register() function contains access_level check."""
        import importlib, inspect
        mod = importlib.import_module(module_path)
        source = inspect.getsource(mod.register)
        # The access check should reference _get_access_level in the register function
        assert "_get_access_level" in source, f"{module_path}.register() missing access check"

    def test_memories_has_access_checks(self):
        self._check_tool_source_has_access_check("coppermind_cmo.tools.memories", "register")

    def test_brand_has_access_checks(self):
        self._check_tool_source_has_access_check("coppermind_cmo.tools.brand", "register")

    def test_minds_has_access_checks(self):
        self._check_tool_source_has_access_check("coppermind_cmo.tools.minds", "register")

    def test_daily_loop_has_access_checks(self):
        self._check_tool_source_has_access_check("coppermind_cmo.tools.daily_loop", "register")

    def test_intelligence_has_access_checks(self):
        self._check_tool_source_has_access_check("coppermind_cmo.tools.intelligence", "register")


class TestStakeholderStripping:
    def test_viewer_default_types_exclude_stakeholder(self):
        from coppermind_cmo.tools.access import VIEWER_DEFAULT_ALLOWED_TYPES
        assert "stakeholder" not in VIEWER_DEFAULT_ALLOWED_TYPES

    def test_search_memory_has_access_level_param(self):
        from coppermind_cmo.tools.memories import _search_memory
        import inspect
        sig = inspect.signature(_search_memory)
        assert "access_level" in sig.parameters

    def test_brand_voice_strips_stakeholders_source(self):
        import inspect
        from coppermind_cmo.tools import brand
        source = inspect.getsource(brand.register)
        assert "stakeholders" in source and "_get_access_level" in source


class TestViewerSearchFiltering:
    def test_memory_store_search_has_filter_params(self):
        from coppermind_cmo.memory_store import MemoryStore
        import inspect
        sig = inspect.signature(MemoryStore.search)
        assert "access_filter_sql" in sig.parameters

    def test_memory_store_keyword_search_has_filter_params(self):
        from coppermind_cmo.memory_store import MemoryStore
        import inspect
        sig = inspect.signature(MemoryStore.keyword_search)
        assert "access_filter_sql" in sig.parameters

    def test_search_memory_has_caller_id_param(self):
        from coppermind_cmo.tools.memories import _search_memory
        import inspect
        sig = inspect.signature(_search_memory)
        assert "caller_id" in sig.parameters

    def test_keyword_search_has_include_private(self):
        from coppermind_cmo.memory_store import MemoryStore
        import inspect
        sig = inspect.signature(MemoryStore.keyword_search)
        assert "include_private" in sig.parameters


class TestPrepMeetingFiltering:
    def test_prep_meeting_closure_has_access_check(self):
        """prep_meeting should resolve access level for memory queries."""
        import inspect
        from coppermind_cmo.tools import intelligence
        source = inspect.getsource(intelligence.register)
        assert "access_level" in source or "_access_filters" in source

    def test_prep_meeting_passes_access_filter_to_collect(self):
        """_collect_meeting_memories must accept and use access filter params."""
        import inspect
        from coppermind_cmo.tools.intelligence import _collect_meeting_memories
        sig = inspect.signature(_collect_meeting_memories)
        assert "access_filter_sql" in sig.parameters and "access_filter_params" in sig.parameters


class TestCampaignHistoryFiltering:
    def test_campaign_history_respects_access(self):
        """get_campaign_history should check access level."""
        import inspect
        from coppermind_cmo.tools import intelligence
        source = inspect.getsource(intelligence.register)
        # Should reference access level for viewer check on campaign history
        assert "_get_access_level" in source

    def test_campaign_history_core_accepts_access_level(self):
        """_get_campaign_history must accept access_level and caller_id."""
        import inspect
        from coppermind_cmo.tools.intelligence import _get_campaign_history
        sig = inspect.signature(_get_campaign_history)
        assert "access_level" in sig.parameters and "caller_id" in sig.parameters
