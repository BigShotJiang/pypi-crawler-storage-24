"""Tests for PID file management, process reaping, and watchdog mechanisms."""

import os
import select
import signal
from pathlib import Path
from unittest.mock import patch, MagicMock, call

import pytest

import coppermind_cmo.server as server_mod
from coppermind_cmo.server import (
    _reap_old_processes, _ensure_single_instance, _cleanup,
    PID_FILE, WATCHER_PID_FILE,
)

# Save real _start_watcher before conftest replaces it
_start_watcher_real = server_mod._start_watcher


@pytest.fixture
def pid_paths(tmp_path, monkeypatch):
    """Override PID/session paths to use tmp_path (isolates from real ~/.coppermind/sessions/)."""
    server_pid = tmp_path / "server.pid"
    watcher_pid = tmp_path / "watcher.pid"
    monkeypatch.setattr(server_mod, "PID_FILE", server_pid)
    monkeypatch.setattr(server_mod, "WATCHER_PID_FILE", watcher_pid)
    monkeypatch.setattr(server_mod, "_SESSIONS_DIR", tmp_path)
    return server_pid, watcher_pid


class TestPidFileCreation:
    def test_pid_file_created(self, pid_paths):
        """_ensure_single_instance writes PID file with correct PID."""
        server_pid, _ = pid_paths
        _ensure_single_instance()
        assert server_pid.exists()
        assert int(server_pid.read_text().strip()) == os.getpid()

    def test_pid_file_directory_created(self, tmp_path, monkeypatch):
        """~/.coppermind/ created if missing."""
        nested = tmp_path / "subdir" / "server.pid"
        monkeypatch.setattr(server_mod, "PID_FILE", nested)
        monkeypatch.setattr(server_mod, "WATCHER_PID_FILE", tmp_path / "subdir" / "watcher.pid")
        _ensure_single_instance()
        assert nested.parent.exists()
        assert nested.exists()


class TestPidFileCleanup:
    def test_pid_file_cleaned_on_exit(self, pid_paths):
        """_cleanup removes PID file when PID matches current process."""
        server_pid, _ = pid_paths
        server_pid.write_text(str(os.getpid()))
        _cleanup()
        assert not server_pid.exists()

    def test_cleanup_only_removes_own_pid(self, pid_paths):
        """_cleanup does NOT remove PID file if it contains a different PID."""
        server_pid, _ = pid_paths
        server_pid.write_text("99999999")  # not our PID
        _cleanup()
        assert server_pid.exists()  # should NOT be removed


class TestStalePidHandling:
    def test_stale_pid_file_handled(self, pid_paths):
        """Fake PID (dead process) in PID file — startup succeeds and overwrites."""
        server_pid, _ = pid_paths
        server_pid.write_text("99999999")  # dead PID
        _ensure_single_instance()
        assert int(server_pid.read_text().strip()) == os.getpid()


class TestReapOldProcesses:
    def test_no_process_killing(self, pid_paths):
        """_reap_old_processes no longer kills sibling processes (prevents restart loops)."""
        with patch("coppermind_cmo.server.os.kill") as mock_kill:
            _reap_old_processes()
            # Should never send SIGTERM/SIGKILL to any process
            sigterm_calls = [c for c in mock_kill.call_args_list
                            if len(c[0]) >= 2 and c[0][1] in (signal.SIGTERM, signal.SIGKILL)]
            assert len(sigterm_calls) == 0


class TestStdinWatchdog:
    def test_detects_hangup(self):
        """poll() returns POLLHUP when pipe write end closes."""
        r, w = os.pipe()
        try:
            poller = select.poll()
            poller.register(r, select.POLLHUP)
            os.close(w)
            events = poller.poll(1000)
            assert len(events) == 1
            fd, event = events[0]
            assert event & (select.POLLHUP | select.POLLIN)
        finally:
            try:
                os.close(r)
            except OSError:
                pass

    @patch("coppermind_cmo.server.os.dup")
    def test_dup_failure_handled(self, mock_dup):
        """If os.dup(0) fails, stdin watchdog logs warning and returns."""
        mock_dup.side_effect = OSError("bad fd")
        server_mod._stdin_watchdog()  # should not raise


class TestWatcherPidTracking:
    @patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "true"})
    def test_watcher_pid_file_created(self, pid_paths):
        """Watcher spawn writes watcher PID file."""
        _, watcher_pid = pid_paths
        mock_proc = MagicMock()
        mock_proc.pid = 54321

        with patch("coppermind_cmo.server.subprocess.Popen", return_value=mock_proc):
            server_mod._server.watcher_process = None
            _start_watcher_real()

        assert watcher_pid.exists()
        assert int(watcher_pid.read_text().strip()) == 54321

    def test_cleanup_removes_watcher_pid(self, pid_paths):
        """_cleanup removes watcher PID file."""
        server_pid, watcher_pid = pid_paths
        server_pid.write_text(str(os.getpid()))
        watcher_pid.write_text("54321")
        _cleanup()
        assert not watcher_pid.exists()

    @patch("coppermind_cmo.server.os.kill")
    @patch("coppermind_cmo.server.subprocess.run")
    def test_startup_reaps_dead_watcher_pid(self, mock_run, mock_kill, pid_paths):
        """Dead watcher PID file is removed during startup reap."""
        server_pid, watcher_pid = pid_paths
        watcher_pid.write_text("67890")

        # pgrep returns nothing (no stale processes)
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        # kill(67890, 0) raises — process is dead
        mock_kill.side_effect = ProcessLookupError

        _ensure_single_instance()
        assert not watcher_pid.exists()
        assert int(server_pid.read_text().strip()) == os.getpid()

    @patch("coppermind_cmo.server.os.kill")
    @patch("coppermind_cmo.server.subprocess.run")
    def test_startup_leaves_live_watcher_pid(self, mock_run, mock_kill, pid_paths):
        """Live watcher PID file is NOT removed during startup reap."""
        server_pid, watcher_pid = pid_paths
        watcher_pid.write_text("67890")

        # pgrep returns nothing
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        # kill(67890, 0) succeeds — process is alive
        mock_kill.return_value = None

        _ensure_single_instance()
        assert watcher_pid.exists()
        assert int(server_pid.read_text().strip()) == os.getpid()
