"""Tests for the release pipeline — prevents every failure we've hit.

These run as part of `pytest` which is the first gate in release.sh.
If any of these fail, the release aborts before deploying or publishing.
"""

import json
import os
import re
import subprocess
import shutil
from pathlib import Path

import pytest

PROJECT_ROOT = Path(__file__).parent.parent
GATEWAY_DIR = PROJECT_ROOT / "gateway"
CUSTOMER_KEYS_FILE = GATEWAY_DIR / "customer_keys.json"
SMOKE_TEST_SCRIPT = PROJECT_ROOT / "scripts" / "smoke-test.sh"
RELEASE_SCRIPT = PROJECT_ROOT / "scripts" / "release.sh"
SYNC_SCRIPT = GATEWAY_DIR / "sync-customer-keys.sh"
PYPROJECT = PROJECT_ROOT / "pyproject.toml"
GITIGNORE = PROJECT_ROOT / ".gitignore"


# ============================================================
# Environment prerequisites — catch missing env vars BEFORE release
# ============================================================

class TestEnvironmentPrerequisites:
    """Validates that the release environment is properly configured."""

    def test_coppermind_api_key_is_set(self):
        """COPPERMIND_API_KEY must be in the environment or shell profile for smoke tests."""
        key = os.environ.get("COPPERMIND_API_KEY", "")
        if not key:
            # Check if it's in ~/.zshrc even if not in current env
            zshrc = Path.home() / ".zshrc"
            if zshrc.exists():
                content = zshrc.read_text()
                if "COPPERMIND_API_KEY" in content:
                    pytest.skip("COPPERMIND_API_KEY is in ~/.zshrc but not in current env (restart shell)")
        assert key, (
            "COPPERMIND_API_KEY is not set anywhere. Add it to ~/.zshrc:\n"
            "  export COPPERMIND_API_KEY=cm_your_key_here"
        )

    def test_coppermind_api_key_format(self):
        """API key must match expected format."""
        key = os.environ.get("COPPERMIND_API_KEY", "")
        if not key:
            pytest.skip("COPPERMIND_API_KEY not set")
        assert key.startswith("cm_"), f"API key should start with 'cm_', got: {key[:10]}..."
        assert " " not in key, "API key contains spaces"
        assert len(key) > 20, "API key too short"


# ============================================================
# customer_keys.json — the source of truth for customer configs
# ============================================================

class TestCustomerKeysFile:
    """Validates gateway/customer_keys.json format and completeness."""

    def test_file_exists(self):
        """customer_keys.json must exist as the source of truth."""
        assert CUSTOMER_KEYS_FILE.exists(), (
            f"{CUSTOMER_KEYS_FILE} not found. This is the source of truth for "
            "CUSTOMER_KEYS. Never update the Cloudflare secret directly — "
            "edit this file and run gateway/sync-customer-keys.sh"
        )

    def test_valid_json(self):
        """Must be valid JSON."""
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)  # Will raise on invalid JSON
        assert isinstance(data, dict)

    def test_has_customers(self):
        """Must have at least one customer."""
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        assert len(data) > 0, "customer_keys.json has no customers"

    def test_all_keys_have_cm_prefix(self):
        """All API keys must start with 'cm_'."""
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        for key in data:
            assert key.startswith("cm_"), f"Key '{key}' doesn't start with 'cm_'"

    def test_all_customers_have_required_fields(self):
        """Every customer must have customer_id, active, and database_url."""
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        for key, config in data.items():
            assert "customer_id" in config, f"{key}: missing customer_id"
            assert "active" in config, f"{key}: missing active"
            assert "database_url" in config, f"{key}: missing database_url"

    def test_no_empty_database_urls(self):
        """No customer should have an empty database_url.

        This was the exact bug that broke provisioning — auth.ts no longer
        falls back to shared DATABASE_URL, so empty = 503 error.
        """
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        for key, config in data.items():
            url = config.get("database_url", "")
            assert url, f"{key} ({config.get('customer_id', '?')}): database_url is empty"

    def test_database_urls_are_pooler_connections(self):
        """database_url should use the Supabase pooler (port 6543), not direct (5432)."""
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        for key, config in data.items():
            url = config.get("database_url", "")
            if url:
                assert "6543" in url or "pooler" in url, (
                    f"{key}: database_url should use pooler (port 6543), "
                    f"not direct connection. Got: {url[:50]}..."
                )

    def test_no_duplicate_customer_ids(self):
        """Each customer_id must be unique."""
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        ids = [c["customer_id"] for c in data.values()]
        assert len(ids) == len(set(ids)), f"Duplicate customer_ids found: {ids}"

    def test_customer_ids_match_key_names(self):
        """customer_id should roughly match the name portion of the API key.

        Exact match isn't required — keys can't be regenerated after a
        name correction without breaking the tester's install. We check
        that they're close (share a common prefix) to catch totally wrong
        assignments like swapping two customers.
        """
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        for key, config in data.items():
            parts = key.split("_")
            hex_part = parts[-1]
            if len(hex_part) == 32 and all(c in "0123456789abcdef" for c in hex_part):
                name_from_key = "_".join(parts[1:-1])
                cid = config["customer_id"]
                # Check first name matches at minimum (catches swapped customers)
                key_first = name_from_key.split("_")[0]
                cid_first = cid.split("_")[0]
                assert key_first == cid_first, (
                    f"Key '{key}' first name '{key_first}' doesn't match "
                    f"customer_id first name '{cid_first}' — possible customer swap?"
                )

    def test_ben_finklea_has_full_logging(self):
        """Ben's account should have full_logging=true for debugging."""
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        ben_entries = [
            (k, v) for k, v in data.items()
            if v.get("customer_id") == "ben_finklea"
        ]
        assert ben_entries, "Ben Finklea not found in customer_keys.json"
        _, config = ben_entries[0]
        assert config.get("full_logging") is True, "Ben should have full_logging=true"

    def test_own_api_key_in_customer_keys(self):
        """The COPPERMIND_API_KEY from env must exist in customer_keys.json.

        This prevents the exact bug where we overwrote CUSTOMER_KEYS
        with partial data and our own key was missing.
        """
        key = os.environ.get("COPPERMIND_API_KEY", "")
        if not key:
            pytest.skip("COPPERMIND_API_KEY not set")
        with open(CUSTOMER_KEYS_FILE) as f:
            data = json.load(f)
        assert key in data, (
            f"Your COPPERMIND_API_KEY ({key[:20]}...) is not in customer_keys.json. "
            "This means the release smoke tests will fail on provision."
        )


# ============================================================
# customer_keys.json is gitignored — it contains secrets
# ============================================================

class TestCustomerKeysGitignored:
    """Ensures customer_keys.json never gets committed."""

    def test_customer_keys_in_gitignore(self):
        """customer_keys.json must be listed in .gitignore."""
        with open(GITIGNORE) as f:
            content = f.read()
        assert "customer_keys.json" in content, (
            "gateway/customer_keys.json is NOT in .gitignore. "
            "This file contains database passwords and API keys!"
        )

    def test_customer_keys_not_tracked_by_git(self):
        """customer_keys.json must not be tracked by git."""
        result = subprocess.run(
            ["git", "ls-files", "--error-unmatch", "gateway/customer_keys.json"],
            capture_output=True,
            text=True,
            cwd=PROJECT_ROOT,
        )
        assert result.returncode != 0, (
            "gateway/customer_keys.json is tracked by git! "
            "Run: git rm --cached gateway/customer_keys.json"
        )


# ============================================================
# Script files exist and are executable
# ============================================================

class TestScriptFiles:
    """Validates release scripts exist and are properly configured."""

    def test_release_script_exists(self):
        assert RELEASE_SCRIPT.exists()

    def test_release_script_executable(self):
        assert os.access(RELEASE_SCRIPT, os.X_OK), "release.sh is not executable"

    def test_smoke_test_script_exists(self):
        assert SMOKE_TEST_SCRIPT.exists()

    def test_smoke_test_script_executable(self):
        assert os.access(SMOKE_TEST_SCRIPT, os.X_OK), "smoke-test.sh is not executable"

    def test_sync_script_exists(self):
        assert SYNC_SCRIPT.exists()

    def test_sync_script_executable(self):
        assert os.access(SYNC_SCRIPT, os.X_OK), "sync-customer-keys.sh is not executable"

    def test_smoke_test_passes_api_key_to_mcp_server(self):
        """Smoke test must pass COPPERMIND_API_KEY to MCP server check.

        This was the exact bug — smoke test ran `python3 -m coppermind_cmo`
        without the API key, causing STARTUP FAILED.
        """
        with open(SMOKE_TEST_SCRIPT) as f:
            content = f.read()
        assert 'COPPERMIND_API_KEY="$API_KEY"' in content, (
            "smoke-test.sh doesn't pass COPPERMIND_API_KEY to MCP server check"
        )

    def test_smoke_test_handles_timeout_exit_code(self):
        """Smoke test must treat timeout (exit 124) as success for MCP server.

        The MCP server has no --help flag. It starts and blocks on stdin.
        timeout(1) returns 124 when it kills the process, which means it started OK.
        """
        with open(SMOKE_TEST_SCRIPT) as f:
            content = f.read()
        assert "124" in content, (
            "smoke-test.sh doesn't handle timeout exit code 124. "
            "MCP server blocks on stdin — timeout means it started successfully."
        )

    def test_smoke_test_does_not_use_help_flag(self):
        """Smoke test must NOT use --help with coppermind_cmo.

        coppermind_cmo doesn't have a --help flag. Using it caused the server
        to start normally (ignoring the flag) and hang until timeout.
        """
        with open(SMOKE_TEST_SCRIPT) as f:
            content = f.read()
        # Check the actual MCP server test lines, not comments
        lines = [l for l in content.split("\n") if "coppermind" in l.lower() and not l.strip().startswith("#")]
        for line in lines:
            if "timeout" in line and ("python3 -m coppermind_cmo" in line or "uvx" in line):
                assert "--help" not in line, (
                    f"smoke-test.sh still uses --help with coppermind_cmo: {line.strip()}"
                )

    def test_release_script_deploys_gateway(self):
        """release.sh must deploy the gateway before smoke tests."""
        with open(RELEASE_SCRIPT) as f:
            content = f.read()
        assert "wrangler deploy" in content, "release.sh doesn't deploy the gateway"

    def test_release_script_runs_smoke_tests_before_publish(self):
        """release.sh must run smoke tests BEFORE publishing to PyPI."""
        with open(RELEASE_SCRIPT) as f:
            content = f.read()
        smoke_pos = content.find("smoke-test.sh")
        twine_pos = content.find("twine upload")
        assert smoke_pos > 0, "release.sh doesn't run smoke tests"
        assert twine_pos > 0, "release.sh doesn't publish to PyPI"
        assert smoke_pos < twine_pos, (
            "release.sh runs smoke tests AFTER publishing. "
            "Smoke tests must run before twine upload."
        )

    def test_release_script_runs_pytest_first(self):
        """release.sh must run pytest before anything else."""
        with open(RELEASE_SCRIPT) as f:
            content = f.read()
        pytest_pos = content.find("pytest")
        deploy_pos = content.find("wrangler deploy")
        assert pytest_pos > 0, "release.sh doesn't run pytest"
        assert pytest_pos < deploy_pos, "release.sh should run pytest before gateway deploy"


# ============================================================
# Required tools are available
# ============================================================

class TestRequiredTools:
    """Validates that all tools needed for release are installed."""

    def test_python3_available(self):
        assert shutil.which("python3"), "python3 not found in PATH"

    def test_git_available(self):
        assert shutil.which("git"), "git not found in PATH"

    def test_pip3_available(self):
        assert shutil.which("pip3"), "pip3 not found in PATH"

    def test_npx_available(self):
        assert shutil.which("npx"), "npx not found in PATH"

    def test_build_module_available(self):
        result = subprocess.run(
            ["python3", "-c", "import build"],
            capture_output=True,
        )
        assert result.returncode == 0, "python3 -m build not available (pip install build)"

    def test_twine_module_available(self):
        result = subprocess.run(
            ["python3", "-c", "import twine"],
            capture_output=True,
        )
        assert result.returncode == 0, "python3 -m twine not available (pip install twine)"


# ============================================================
# Version consistency
# ============================================================

class TestVersionConsistency:
    """Validates version format in pyproject.toml."""

    def test_version_in_pyproject(self):
        """pyproject.toml must have a version field."""
        with open(PYPROJECT, "rb") as f:
            import tomllib
            data = tomllib.load(f)
        version = data["project"]["version"]
        assert version, "Version is empty in pyproject.toml"

    def test_version_format(self):
        """Version must be valid semver (with optional rc suffix)."""
        with open(PYPROJECT, "rb") as f:
            import tomllib
            data = tomllib.load(f)
        version = data["project"]["version"]
        assert re.match(r"^\d+\.\d+\.\d+(rc\d+)?$", version), (
            f"Version '{version}' doesn't match expected format X.Y.Z or X.Y.Zrc#"
        )


# ============================================================
# Gateway config
# ============================================================

class TestGatewayConfig:
    """Validates gateway configuration for deployment."""

    def test_wrangler_toml_exists(self):
        assert (GATEWAY_DIR / "wrangler.toml").exists()

    def test_wrangler_toml_has_cron(self):
        """Monitoring cron must be configured."""
        content = (GATEWAY_DIR / "wrangler.toml").read_text()
        assert "crons" in content, "wrangler.toml missing cron trigger for monitoring"

    def test_gateway_package_json_exists(self):
        assert (GATEWAY_DIR / "package.json").exists()

    def test_vitest_config_has_kv_namespace(self):
        """Test config must include RATE_LIMIT_KV for rate limiting tests."""
        content = (GATEWAY_DIR / "vitest.config.ts").read_text()
        assert "RATE_LIMIT_KV" in content, "vitest.config.ts missing RATE_LIMIT_KV namespace"
