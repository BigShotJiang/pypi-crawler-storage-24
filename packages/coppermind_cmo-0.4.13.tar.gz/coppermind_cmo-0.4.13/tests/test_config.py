"""Tests for config.py — COPPERMIND_* env var parsing and provider detection."""

import os
import pytest
from unittest.mock import patch
from coppermind_cmo.config import Config


class TestConfigDefaults:
    def test_pg_host_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_host == ""

    def test_pg_port_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_port == 5432

    def test_pg_db_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_db == ""

    def test_pg_user_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.pg_user == ""

    def test_llm_provider_always_gateway(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.llm_provider == "gateway"

    def test_embedding_provider_always_gateway(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.embedding_provider == "gateway"

    def test_embedding_dims_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.embedding_dims == 512

    def test_max_prompt_chars_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.max_prompt_chars == 40000


class TestConfigFromEnv:
    def test_reads_pg_host(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_HOST": "db.example.com"}):
            c = Config()
            assert c.pg_host == "db.example.com"

    def test_reads_pg_port(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_PORT": "5433"}):
            c = Config()
            assert c.pg_port == 5433

    def test_reads_pg_password(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_PASSWORD": "secret"}):
            c = Config()
            assert c.pg_password == "secret"

    def test_invalid_port_raises(self):
        with patch.dict(os.environ, {"COPPERMIND_PG_PORT": "not_a_number"}):
            with pytest.raises(ValueError):
                Config()


class TestPgDsnRemoved:
    def test_config_has_no_pg_dsn_property(self):
        """Fix 1.1: pg_dsn property was removed to prevent password leaks."""
        from coppermind_cmo.config import Config
        assert not hasattr(Config, 'pg_dsn')


class TestProviderDetection:
    def test_gateway_providers_always_set(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.llm_provider == "gateway"
            assert c.embedding_provider == "gateway"
            assert c.embedding_dims == 512
            assert c.max_prompt_chars == 40000

    def test_api_key_sets_gateway_providers(self):
        with patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True):
            c = Config()
            assert c.llm_provider == "gateway"
            assert c.embedding_provider == "gateway"
            assert c.embedding_dims == 512
            assert c.max_prompt_chars == 40000

    def test_gateway_url_default(self):
        with patch.dict(os.environ, {}, clear=True):
            c = Config()
            assert c.gateway_url == "https://api.coppermind.app"

    def test_gateway_url_configurable(self):
        with patch.dict(os.environ, {"COPPERMIND_GATEWAY_URL": "http://localhost:8787"}, clear=True):
            c = Config()
            assert c.gateway_url == "http://localhost:8787"


class TestDatabaseUrlParsing:
    def test_parse_database_url(self):
        """Verify _parse_database_url correctly populates config fields."""
        from coppermind_cmo.server import _parse_database_url
        from unittest.mock import MagicMock
        config = MagicMock()
        _parse_database_url(config, "postgres://myuser:mypass@db.supabase.co:6543/postgres")
        assert config.pg_host == "db.supabase.co"
        assert config.pg_port == 6543
        assert config.pg_db == "postgres"
        assert config.pg_user == "myuser"
        assert config.pg_password == "mypass"
