"""Tests for server.py — state management and startup checks."""

import hashlib
import importlib.resources
import json
import os
import sys
import pytest
from pathlib import Path
from unittest.mock import MagicMock, patch, PropertyMock
import coppermind_cmo.server as server_mod

# Save real functions before conftest replaces them with no-ops
_start_watcher_real = server_mod._start_watcher
_install_skills_real = server_mod._install_skills
_install_hooks_real = server_mod._install_hooks


class TestStateManagement:
    def setup_method(self):
        """Reset server state between tests."""
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._session.active_mind_id = None
        server_mod._session.active_mind_name = None

    def test_get_active_mind_returns_none_initially(self):
        assert server_mod.get_active_mind() is None

    def test_set_and_get_active_mind(self):
        server_mod.set_active_mind("uuid-123", "Acme")
        result = server_mod.get_active_mind()
        assert result == ("uuid-123", "Acme")

    def test_get_config_returns_same_instance(self):
        c1 = server_mod.get_config()
        c2 = server_mod.get_config()
        assert c1 is c2

    def test_get_db_returns_same_instance(self):
        with patch("coppermind_cmo.server.Database") as MockDB, \
             patch("coppermind_cmo.server._startup_checks"):
            server_mod._server.config = MagicMock()
            db1 = server_mod.get_db()
            db2 = server_mod.get_db()
            assert db1 is db2
            MockDB.assert_called_once()


class TestStartupChecksSelfHosted:
    """Startup checks for self-hosted mode (no API key)."""

    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._session.active_mind_id = None
        server_mod._session.active_mind_name = None

    @patch.dict(os.environ, {}, clear=True)
    def test_missing_pg_env_vars_exits(self):
        """Missing COPPERMIND_PG_* env vars should sys.exit(1)."""
        with pytest.raises(SystemExit) as exc:
            server_mod._startup_checks()
        assert exc.value.code == 1

    @patch.dict(os.environ, {
        "COPPERMIND_PG_HOST": "localhost",
        "COPPERMIND_PG_PORT": "5432",
        "COPPERMIND_PG_DB": "coppermind_cmo",
        "COPPERMIND_PG_USER": "coppermind",
        "COPPERMIND_PG_PASSWORD": "",
    })
    def test_empty_password_exits(self):
        with pytest.raises(SystemExit) as exc:
            server_mod._startup_checks()
        assert exc.value.code == 1

    @patch.dict(os.environ, {
        "COPPERMIND_PG_HOST": "localhost",
        "COPPERMIND_PG_PORT": "5432",
        "COPPERMIND_PG_DB": "coppermind_cmo",
        "COPPERMIND_PG_USER": "coppermind",
        "COPPERMIND_PG_PASSWORD": "secret",
    })
    @patch("coppermind_cmo.server.get_db")
    def test_pg_connection_failure_exits(self, mock_get_db):
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = Exception("connection refused")
        mock_get_db.return_value = mock_db
        with pytest.raises(SystemExit) as exc:
            server_mod._startup_checks()
        assert exc.value.code == 1

    @patch.dict(os.environ, {
        "COPPERMIND_PG_HOST": "localhost",
        "COPPERMIND_PG_PORT": "5432",
        "COPPERMIND_PG_DB": "coppermind_cmo",
        "COPPERMIND_PG_USER": "coppermind",
        "COPPERMIND_PG_PASSWORD": "secret",
    })
    @patch("coppermind_cmo.server.get_db")
    def test_pgvector_missing_exits(self, mock_get_db):
        mock_db = MagicMock()
        # First fetch_one succeeds (SELECT 1), second returns None (pgvector check)
        mock_db.fetch_one.side_effect = [(1,), None]
        mock_get_db.return_value = mock_db
        with pytest.raises(SystemExit) as exc:
            server_mod._startup_checks()
        assert exc.value.code == 1

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server._provision_from_gateway")
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_optional_services_down_continues(self, mock_get_db, mock_emb, mock_provision):
        """When embedding service is down, startup should warn but not exit."""
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = [(1,), (1,)]  # PG ok, pgvector ok
        mock_get_db.return_value = mock_db
        mock_emb.check_health.return_value = False
        # Should NOT raise SystemExit
        server_mod._startup_checks()


class TestStartupBanner:
    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._session.active_mind_id = None
        server_mod._session.active_mind_name = None

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server._provision_from_gateway")
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_startup_banner_emits_config(self, mock_get_db, mock_emb, mock_provision, capsys):
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = [(1,), (1,)]
        mock_get_db.return_value = mock_db
        mock_emb.check_health.return_value = True

        def fake_provision(config):
            config.pg_host = "db.supabase.co"
            config.pg_user = "coppermind_app"
            config.pg_password = "provisioned-secret"

        mock_provision.side_effect = fake_provision

        server_mod._startup_checks()

        stderr = capsys.readouterr().err
        banner_lines = [l for l in stderr.strip().split("\n") if "pg_host" in l]
        assert len(banner_lines) == 1
        banner = json.loads(banner_lines[0].removeprefix("COPPERMIND-CMO: "))
        assert banner["pg_host"] == "db.supabase.co"
        assert banner["pg_user"] == "coppermind_app"
        assert banner["pg_password"] == "***"


class TestPasswordNotLeaked:
    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._session.active_mind_id = None
        server_mod._session.active_mind_name = None

    @patch.dict(os.environ, {
        "COPPERMIND_PG_HOST": "localhost",
        "COPPERMIND_PG_PORT": "5432",
        "COPPERMIND_PG_DB": "coppermind_cmo",
        "COPPERMIND_PG_USER": "coppermind",
        "COPPERMIND_PG_PASSWORD": "super_secret_password_123",
    })
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_pg_failure_does_not_leak_password(self, mock_get_db, mock_emb, capsys):
        """When PostgreSQL connection fails, the error log must not contain the password."""
        mock_get_db.side_effect = Exception("connection refused")

        with pytest.raises(SystemExit):
            server_mod._startup_checks()

        stderr = capsys.readouterr().err
        assert "super_secret_password_123" not in stderr



class TestHostedModeStartup:
    """Startup checks for hosted mode (API key set)."""

    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._session.active_mind_id = None
        server_mod._session.active_mind_name = None

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server._provision_from_gateway")
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_hosted_mode_calls_provision(self, mock_get_db, mock_emb, mock_provision):
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = [(1,), (1,)]
        mock_get_db.return_value = mock_db
        mock_emb.check_health.return_value = True

        server_mod._startup_checks()
        mock_provision.assert_called_once()

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server._provision_from_gateway")
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_hosted_mode_skips_pg_env_check(self, mock_get_db, mock_emb, mock_provision):
        """In hosted mode, PG env vars are not required (comes from provisioning)."""
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = [(1,), (1,)]
        mock_get_db.return_value = mock_db
        mock_emb.check_health.return_value = True

        # Should NOT exit even though COPPERMIND_PG_* are missing
        server_mod._startup_checks()

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server.httpx")
    def test_provision_failure_exits(self, mock_httpx):
        mock_httpx.post.side_effect = Exception("gateway unreachable")
        with pytest.raises(SystemExit) as exc:
            server_mod._startup_checks()
        assert exc.value.code == 1


class TestDatabaseUrlParsing:
    def test_parse_database_url_full(self):
        config = MagicMock()
        server_mod._parse_database_url(config, "postgres://user:pass@host:5432/mydb")
        assert config.pg_host == "host"
        assert config.pg_port == 5432
        assert config.pg_db == "mydb"
        assert config.pg_user == "user"
        assert config.pg_password == "pass"

    def test_parse_pooler_url_with_dotted_username(self):
        config = MagicMock()
        server_mod._parse_database_url(
            config,
            "postgresql://coppermind_app.ezipkfvxdqzfhywkzakm:MyPass@aws-1-us-east-1.pooler.supabase.com:6543/postgres",
        )
        assert config.pg_host == "aws-1-us-east-1.pooler.supabase.com"
        assert config.pg_port == 6543
        assert config.pg_db == "postgres"
        assert config.pg_user == "coppermind_app.ezipkfvxdqzfhywkzakm"
        assert config.pg_password == "MyPass"


class TestAutoWatcher:
    """Tests for automatic session watcher subprocess management."""

    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._server.watcher_process = None

    def teardown_method(self):
        server_mod._stop_watcher()

    @patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "true"})
    @patch("coppermind_cmo.server.subprocess.Popen")
    def test_watcher_spawned_on_startup(self, mock_popen):
        """_start_watcher spawns a subprocess with the watch module."""
        mock_proc = MagicMock()
        mock_proc.pid = 12345
        mock_popen.return_value = mock_proc

        _start_watcher_real()

        mock_popen.assert_called_once()
        call_args = mock_popen.call_args[0][0]
        assert "-m" in call_args
        assert "coppermind_cmo.watch" in call_args
        assert "--interval" in call_args
        assert server_mod._server.watcher_process is mock_proc

    @patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "false"})
    @patch("coppermind_cmo.server.subprocess.Popen")
    def test_watcher_disabled_by_env(self, mock_popen):
        """COPPERMIND_WATCHER_ENABLED=false skips watcher."""
        _start_watcher_real()

        mock_popen.assert_not_called()
        assert server_mod._server.watcher_process is None

    @patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "true"})
    @patch("coppermind_cmo.server.subprocess.Popen")
    def test_watcher_crash_does_not_propagate(self, mock_popen):
        """If Popen raises, server continues without crashing."""
        mock_popen.side_effect = OSError("No such file or directory")

        _start_watcher_real()
        assert server_mod._server.watcher_process is None

    @patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "true"})
    @patch("coppermind_cmo.server.subprocess.Popen")
    def test_stop_watcher_terminates_process(self, mock_popen):
        """_stop_watcher terminates the subprocess."""
        mock_proc = MagicMock()
        mock_popen.return_value = mock_proc

        _start_watcher_real()
        server_mod._stop_watcher()

        mock_proc.terminate.assert_called_once()
        mock_proc.wait.assert_called_once_with(timeout=5)
        assert server_mod._server.watcher_process is None

    def test_stop_watcher_noop_when_not_started(self):
        """_stop_watcher is safe to call when no watcher is running."""
        server_mod._server.watcher_process = None
        server_mod._stop_watcher()  # should not raise

    @patch.dict(os.environ, {"COPPERMIND_WATCHER_ENABLED": "true"})
    @patch("coppermind_cmo.server.subprocess.Popen")
    def test_double_start_does_not_spawn_second(self, mock_popen):
        """Calling _start_watcher twice should not spawn a second process."""
        mock_proc = MagicMock()
        mock_proc.pid = 12345
        mock_popen.return_value = mock_proc

        _start_watcher_real()
        _start_watcher_real()  # second call

        mock_popen.assert_called_once()  # only one Popen call


# ---------------------------------------------------------------------------
# _install_skills coverage — bypasses conftest no-op to test real function
# ---------------------------------------------------------------------------

def _make_skills_mock(files):
    """Build a mock for importlib.resources.files that returns given skill files."""
    mock_pkg_dir = MagicMock()
    mock_pkg_dir.is_dir.return_value = True
    mock_pkg_dir.iterdir.return_value = files

    mock_files_root = MagicMock()
    mock_files_root.__truediv__ = MagicMock(return_value=mock_pkg_dir)
    return mock_files_root


class TestInstallSkillsCoverage:
    """Tests that exercise _install_skills code paths (lines 231-261)."""

    def test_install_skills_copies_new_file(self, tmp_path, monkeypatch):
        """Mock resources.files with a .md file. Mock Path.home(). Verify file written."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        skills_dir = tmp_path / ".claude" / "skills"

        mock_file = MagicMock()
        mock_file.name = "cm-test-skill.md"
        mock_file.read_text.return_value = "# Skill Content Here"

        mock_files_root = _make_skills_mock([mock_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        _install_skills_real()

        assert skills_dir.exists()
        dest = skills_dir / "cm-test-skill.md"
        assert dest.exists()
        assert dest.read_text() == "# Skill Content Here"

    def test_install_skills_skips_identical(self, tmp_path, monkeypatch):
        """Pre-create file with matching content. Verify no overwrite."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        skills_dir = tmp_path / ".claude" / "skills"
        skills_dir.mkdir(parents=True)
        content = "# Identical Content"
        dest = skills_dir / "cm-skill.md"
        dest.write_text(content)
        original_mtime = dest.stat().st_mtime

        mock_file = MagicMock()
        mock_file.name = "cm-skill.md"
        mock_file.read_text.return_value = content  # same content

        mock_files_root = _make_skills_mock([mock_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        _install_skills_real()

        # File content is the same -- the skill should have been skipped
        assert dest.read_text() == content

    def test_install_skills_updates_changed(self, tmp_path, monkeypatch):
        """Pre-create file with different content. Verify overwritten."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        skills_dir = tmp_path / ".claude" / "skills"
        skills_dir.mkdir(parents=True)
        dest = skills_dir / "cm-skill.md"
        dest.write_text("# Old Version")

        mock_file = MagicMock()
        mock_file.name = "cm-skill.md"
        mock_file.read_text.return_value = "# New Version"

        mock_files_root = _make_skills_mock([mock_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        _install_skills_real()

        assert dest.read_text() == "# New Version"

    def test_install_skills_no_skills_dir(self, tmp_path, monkeypatch):
        """Mock resources.files to return a path where is_dir()=False. No crash."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        mock_pkg_dir = MagicMock()
        mock_pkg_dir.is_dir.return_value = False

        mock_files_root = MagicMock()
        mock_files_root.__truediv__ = MagicMock(return_value=mock_pkg_dir)
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        # Should return early without crash
        _install_skills_real()

        # No skills directory created since is_dir was False
        skills_dir = tmp_path / ".claude" / "skills"
        # The mkdir call happens BEFORE the is_dir check, so it may exist
        # Key thing: no crash and no files copied
        if skills_dir.exists():
            assert list(skills_dir.iterdir()) == []

    def test_install_skills_skips_non_md_files(self, tmp_path, monkeypatch):
        """Non-.md files should be skipped."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        skills_dir = tmp_path / ".claude" / "skills"

        md_file = MagicMock()
        md_file.name = "cm-skill.md"
        md_file.read_text.return_value = "# Skill"

        txt_file = MagicMock()
        txt_file.name = "readme.txt"

        mock_files_root = _make_skills_mock([md_file, txt_file])
        monkeypatch.setattr(importlib.resources, "files", lambda pkg: mock_files_root)

        _install_skills_real()

        assert (skills_dir / "cm-skill.md").exists()
        assert not (skills_dir / "readme.txt").exists()

    def test_install_skills_exception_no_crash(self, tmp_path, monkeypatch):
        """When importlib.resources.files raises, _install_skills should not crash (lines 260-261)."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        monkeypatch.setattr(
            importlib.resources, "files",
            MagicMock(side_effect=Exception("package not found")),
        )

        # Should not raise
        _install_skills_real()


# ---------------------------------------------------------------------------
# _provision_from_gateway coverage (lines 73-101)
# ---------------------------------------------------------------------------

class TestProvisionFromGateway:
    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None

    def test_provision_from_gateway_success(self):
        """Mock httpx.post returning 200 with database_url and embedding_dims."""
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"
        config.embedding_dims = 384  # default

        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "database_url": "postgres://user:pass@db.host:5432/mydb",
            "embedding_dims": 512,
            "customer_id": "cust-123",
        }

        with patch("coppermind_cmo.server.httpx.post", return_value=mock_resp):
            server_mod._provision_from_gateway(config)

        assert config.pg_host == "db.host"
        assert config.pg_port == 5432
        assert config.pg_db == "mydb"
        assert config.pg_user == "user"
        assert config.pg_password == "pass"
        assert config.embedding_dims == 512

    def test_provision_from_gateway_parses_db_url(self):
        """Mock a full postgres:// URL. Verify all fields parsed."""
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"
        config.embedding_dims = 384

        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "database_url": "postgresql://appuser:s3cret@db.supabase.io:6543/postgres",
            "customer_id": "cust-456",
        }

        with patch("coppermind_cmo.server.httpx.post", return_value=mock_resp):
            server_mod._provision_from_gateway(config)

        assert config.pg_host == "db.supabase.io"
        assert config.pg_port == 6543
        assert config.pg_db == "postgres"
        assert config.pg_user == "appuser"
        assert config.pg_password == "s3cret"
        # embedding_dims not in response, should stay at original
        assert config.embedding_dims == 384

    def test_provision_prefers_structured_params(self):
        """When gateway returns structured db_host/port/name/user/password, use them directly."""
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"
        config.embedding_dims = 384

        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "database_url": "postgres://user:pass@db.host:5432/mydb",
            "db_host": "structured-host.example.com",
            "db_port": 6543,
            "db_name": "structured_db",
            "db_user": "structured_user",
            "db_password": "structured_pass",
            "embedding_dims": 512,
            "customer_id": "cust-structured",
        }

        with patch("coppermind_cmo.server.httpx.post", return_value=mock_resp):
            server_mod._provision_from_gateway(config)

        # Structured fields should take precedence over database_url
        assert config.pg_host == "structured-host.example.com"
        assert config.pg_port == 6543
        assert config.pg_db == "structured_db"
        assert config.pg_user == "structured_user"
        assert config.pg_password == "structured_pass"
        assert config.embedding_dims == 512
        assert config.customer_id == "cust-structured"

    def test_provision_falls_back_to_url(self):
        """When gateway returns only database_url (no structured fields), parse the URL."""
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "test-key"
        config.embedding_dims = 384

        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "database_url": "postgres://fallback_user:fallback_pass@fallback.host:5433/fallback_db",
            "customer_id": "cust-fallback",
        }

        with patch("coppermind_cmo.server.httpx.post", return_value=mock_resp):
            server_mod._provision_from_gateway(config)

        # Should have parsed the URL
        assert config.pg_host == "fallback.host"
        assert config.pg_port == 5433
        assert config.pg_db == "fallback_db"
        assert config.pg_user == "fallback_user"
        assert config.pg_password == "fallback_pass"
        assert config.customer_id == "cust-fallback"

    def test_provision_from_gateway_no_db_url(self):
        """When database_url is empty, PG fields should not change."""
        config = MagicMock()
        config.gateway_url = "https://api.coppermind.app"
        config.api_key = "key"
        config.embedding_dims = 384
        config.pg_host = "original-host"

        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "database_url": "",
            "customer_id": "cust-789",
        }

        with patch("coppermind_cmo.server.httpx.post", return_value=mock_resp):
            server_mod._provision_from_gateway(config)

        # pg_host should NOT have been set (no valid URL to parse)
        assert config.pg_host == "original-host"


# ---------------------------------------------------------------------------
# Version check coverage (lines 207-219)
# ---------------------------------------------------------------------------

class TestVersionCheckCoverage:
    """Exercise the version check code path in _startup_checks."""

    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._session.active_mind_id = None
        server_mod._session.active_mind_name = None

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server._provision_from_gateway")
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_version_check_outdated_exits(self, mock_get_db, mock_emb, mock_provision, capsys):
        """Server config with min_client_version higher than installed calls sys.exit(1)."""
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = [(1,), (1,)]
        mock_get_db.return_value = mock_db
        mock_emb.check_health.return_value = True

        from coppermind_cmo.config import ServerConfig
        outdated_config = ServerConfig(
            min_client_version="99.0.0",
            upgrade_message="Please upgrade now.",
            fetched=True,
        )

        # Override the conftest no_server_config_fetch for this test
        with patch("coppermind_cmo.server.fetch_server_config", return_value=outdated_config):
            with pytest.raises(SystemExit) as exc_info:
                server_mod._startup_checks()
            assert exc_info.value.code == 1

        stderr = capsys.readouterr().err
        assert "UPDATE REQUIRED" in stderr
        assert "coppermind-update" in stderr

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server._provision_from_gateway")
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_version_check_current_no_warning(self, mock_get_db, mock_emb, mock_provision, capsys):
        """Server config with min_client_version at or below installed has no warning."""
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = [(1,), (1,)]
        mock_get_db.return_value = mock_db
        mock_emb.check_health.return_value = True

        from coppermind_cmo.config import ServerConfig
        current_config = ServerConfig(
            min_client_version="0.0.1",
            upgrade_message="Upgrade available.",
            fetched=True,
        )

        with patch("coppermind_cmo.server.fetch_server_config", return_value=current_config):
            server_mod._startup_checks()

        stderr = capsys.readouterr().err
        warn_lines = [l for l in stderr.strip().split("\n") if "below minimum" in l]
        assert len(warn_lines) == 0

    @patch.dict(os.environ, {"COPPERMIND_API_KEY": "test-key"}, clear=True)
    @patch("coppermind_cmo.server._provision_from_gateway")
    @patch("coppermind_cmo.server.embedding_client")
    @patch("coppermind_cmo.server.get_db")
    def test_version_check_parse_failure_no_crash(self, mock_get_db, mock_emb, mock_provision):
        """When version parsing raises, should not crash (lines 218-219)."""
        mock_db = MagicMock()
        mock_db.fetch_one.side_effect = [(1,), (1,)]
        mock_get_db.return_value = mock_db
        mock_emb.check_health.return_value = True

        from coppermind_cmo.config import ServerConfig
        bad_version_config = ServerConfig(
            min_client_version="not-a-version",
            fetched=True,
        )

        with patch("coppermind_cmo.server.fetch_server_config", return_value=bad_version_config):
            # Should not crash -- exception is caught on lines 218-219
            server_mod._startup_checks()


# ---------------------------------------------------------------------------
# _stop_watcher fallback kill path (lines 326-331)
# ---------------------------------------------------------------------------

class TestStopWatcherKillFallback:
    def setup_method(self):
        server_mod._server.watcher_process = None

    def test_stop_watcher_falls_back_to_kill(self):
        """When terminate/wait raises, falls back to kill."""
        mock_proc = MagicMock()
        mock_proc.terminate.side_effect = Exception("terminate failed")
        server_mod._server.watcher_process = mock_proc

        server_mod._stop_watcher()

        mock_proc.kill.assert_called_once()
        assert server_mod._server.watcher_process is None

    def test_stop_watcher_kill_also_fails(self):
        """When both terminate and kill fail, no crash."""
        mock_proc = MagicMock()
        mock_proc.terminate.side_effect = Exception("terminate failed")
        mock_proc.kill.side_effect = Exception("kill failed")
        server_mod._server.watcher_process = mock_proc

        # Should not raise
        server_mod._stop_watcher()
        assert server_mod._server.watcher_process is None


# ---------------------------------------------------------------------------
# _register_tools coverage (lines 335-341)
# ---------------------------------------------------------------------------

class TestRegisterTools:
    def test_register_tools_imports_and_registers(self):
        """Verify _register_tools calls register on all tool modules."""
        with patch("coppermind_cmo.tools.minds.register") as mock_minds, \
             patch("coppermind_cmo.tools.memories.register") as mock_memories, \
             patch("coppermind_cmo.tools.brand.register") as mock_brand, \
             patch("coppermind_cmo.tools.intelligence.register") as mock_intel:
            server_mod._register_tools()

            mock_minds.assert_called_once_with(server_mod.mcp)
            mock_memories.assert_called_once_with(server_mod.mcp)
            mock_brand.assert_called_once_with(server_mod.mcp)
            mock_intel.assert_called_once_with(server_mod.mcp)


# ---------------------------------------------------------------------------
# _install_statusline coverage (lines 264-280)
# ---------------------------------------------------------------------------

class TestInstallStatusline:
    """Tests for _install_statusline (lines 264-280)."""

    def test_statusline_skipped_on_windows(self):
        """On win32, _install_statusline returns immediately."""
        from coppermind_cmo.server import _install_statusline
        with patch.object(server_mod, "sys", MagicMock(platform="win32")):
            _install_statusline()

    def test_statusline_skipped_if_dest_exists(self):
        """If dest already exists, skip."""
        from coppermind_cmo.server import _install_statusline
        with patch("os.path.exists", return_value=True):
            _install_statusline()

    # Lines 266-280 cover file-system operations (shutil.copy2, os.chmod)
    # that are inherently platform-dependent. The win32 and exists-already
    # branches are tested above. The copy/chmod paths require actual file
    # operations and are covered by manual testing.


class TestInstallHooks:
    def test_hook_command_uses_windows_quoting(self, tmp_path):
        script_path = tmp_path / "coppermind-auto-prep.py"
        with patch.object(server_mod, "sys", MagicMock(platform="win32", executable="C:\\Python\\python.exe")):
            command = server_mod._hook_command(script_path)

        assert "python.exe" in command
        assert str(script_path) in command

    def test_merge_hook_rejects_invalid_shapes(self):
        assert server_mod._merge_user_prompt_submit_hook({"hooks": []}, "python hook.py") is None
        assert server_mod._merge_user_prompt_submit_hook({"hooks": {"UserPromptSubmit": {}}}, "python hook.py") is None

    def test_merge_hook_skips_non_dict_entries(self):
        settings = {"hooks": {"UserPromptSubmit": ["ignore-me"]}}

        result = server_mod._merge_user_prompt_submit_hook(settings, "python hook.py")

        assert result is True
        assert settings["hooks"]["UserPromptSubmit"][-1]["hooks"][0]["command"] == "python hook.py"

    def test_install_hooks_copies_script_and_updates_settings(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        monkeypatch.setattr(server_mod.sys, "executable", "/venv/bin/python3")

        _install_hooks_real()

        hook_path = tmp_path / ".claude" / "hooks" / "coppermind-auto-prep.py"
        settings_path = tmp_path / ".claude" / "settings.json"
        marker_path = tmp_path / ".coppermind" / ".hooks-installed"
        assert hook_path.exists()
        assert "build_hook_output" in hook_path.read_text(encoding="utf-8")
        assert marker_path.exists()

        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        entry = settings["hooks"]["UserPromptSubmit"][0]["hooks"][0]
        assert entry["type"] == "command"
        assert entry["timeout"] == 5
        assert entry["statusMessage"] == "Checking upcoming meetings..."
        assert entry["command"] == "/venv/bin/python3 " + str(hook_path)

    def test_install_hooks_skips_settings_merge_when_marker_exists(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        monkeypatch.setattr(server_mod.sys, "executable", "/venv/bin/python3")

        # Create marker file — simulates a previous successful install
        marker_path = tmp_path / ".coppermind" / ".hooks-installed"
        marker_path.parent.mkdir(parents=True, exist_ok=True)
        marker_path.write_text("", encoding="utf-8")

        _install_hooks_real()

        # Hook script is still refreshed (updated on every startup)
        hook_path = tmp_path / ".claude" / "hooks" / "coppermind-auto-prep.py"
        assert hook_path.exists()

        # But settings.json was never created (merge skipped)
        settings_path = tmp_path / ".claude" / "settings.json"
        assert not settings_path.exists()

    def test_install_hooks_creates_marker_when_hook_already_in_settings(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        monkeypatch.setattr(server_mod.sys, "executable", "/venv/bin/python3")

        # Pre-populate settings with the hook already present
        hook_path = tmp_path / ".claude" / "hooks" / "coppermind-auto-prep.py"
        settings_path = tmp_path / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        hook_cmd = "/venv/bin/python3 " + str(hook_path)
        settings_path.write_text(
            json.dumps({"hooks": {"UserPromptSubmit": [{"hooks": [{"type": "command", "command": hook_cmd}]}]}}),
            encoding="utf-8",
        )

        _install_hooks_real()

        # Marker should be created even though no new merge happened
        marker_path = tmp_path / ".coppermind" / ".hooks-installed"
        assert marker_path.exists()

    def test_install_hooks_preserves_existing_settings_and_avoids_duplicates(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        monkeypatch.setattr(server_mod.sys, "executable", "/venv/bin/python3")

        hook_path = tmp_path / ".claude" / "hooks" / "coppermind-auto-prep.py"
        settings_path = tmp_path / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(
            json.dumps(
                {
                    "hooks": {
                        "SessionStart": [{"hooks": [{"type": "command", "command": "echo startup"}]}],
                        "UserPromptSubmit": [
                            {
                                "hooks": [
                                    {
                                        "type": "command",
                                        "command": "/venv/bin/python3 " + str(hook_path),
                                        "timeout": 5,
                                    }
                                ]
                            }
                        ],
                    }
                }
            ),
            encoding="utf-8",
        )

        _install_hooks_real()

        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        assert len(settings["hooks"]["SessionStart"]) == 1
        assert len(settings["hooks"]["UserPromptSubmit"]) == 1

    def test_install_hooks_skips_invalid_settings_json(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        settings_path = tmp_path / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text("{invalid json", encoding="utf-8")

        _install_hooks_real()

        assert settings_path.read_text(encoding="utf-8") == "{invalid json"

    def test_install_hooks_skips_invalid_hooks_structure(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        settings_path = tmp_path / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text(json.dumps({"hooks": []}), encoding="utf-8")

        _install_hooks_real()

        settings = json.loads(settings_path.read_text(encoding="utf-8"))
        assert settings == {"hooks": []}

    def test_install_hooks_skips_when_bundled_hook_cannot_be_loaded(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)
        monkeypatch.setattr(server_mod.resources, "files", MagicMock(side_effect=Exception("missing package")))

        _install_hooks_real()

        assert not (tmp_path / ".claude" / "settings.json").exists()

    def test_install_hooks_skips_when_hook_copy_fails(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        def fail_write(*args, **kwargs):
            raise OSError("permission denied")

        monkeypatch.setattr(Path, "write_text", fail_write)

        _install_hooks_real()

        assert not (tmp_path / ".claude" / "settings.json").exists()

    def test_install_hooks_skips_when_settings_read_fails(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        settings_path = tmp_path / ".claude" / "settings.json"
        settings_path.parent.mkdir(parents=True, exist_ok=True)
        settings_path.write_text("{}", encoding="utf-8")

        original_read_text = Path.read_text

        def selective_fail(self, *args, **kwargs):
            if self == settings_path:
                raise OSError("permission denied")
            return original_read_text(self, *args, **kwargs)

        monkeypatch.setattr(Path, "read_text", selective_fail)

        _install_hooks_real()

        assert original_read_text(settings_path, encoding="utf-8") == "{}"

    def test_install_hooks_skips_when_settings_write_fails(self, tmp_path, monkeypatch):
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        settings_path = tmp_path / ".claude" / "settings.json"
        original_write_text = Path.write_text

        def selective_fail(self, content, *args, **kwargs):
            if self == settings_path:
                raise OSError("disk full")
            return original_write_text(self, content, *args, **kwargs)

        monkeypatch.setattr(Path, "write_text", selective_fail)

        _install_hooks_real()

        assert not settings_path.exists()


# ---------------------------------------------------------------------------
# PG fetch_one returns None (empty response) — line 155
# ---------------------------------------------------------------------------

class TestPgEmptyResponse:
    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._session.active_mind_id = None
        server_mod._session.active_mind_name = None

    @patch.dict(os.environ, {
        "COPPERMIND_PG_HOST": "localhost",
        "COPPERMIND_PG_PORT": "5432",
        "COPPERMIND_PG_DB": "coppermind_cmo",
        "COPPERMIND_PG_USER": "coppermind",
        "COPPERMIND_PG_PASSWORD": "secret",
    })
    @patch("coppermind_cmo.server.get_db")
    def test_pg_select_1_returns_none_exits(self, mock_get_db):
        """SELECT 1 returning None means PG is in a bad state -- should exit."""
        mock_db = MagicMock()
        mock_db.fetch_one.return_value = None
        mock_get_db.return_value = mock_db
        with pytest.raises(SystemExit) as exc:
            server_mod._startup_checks()
        assert exc.value.code == 1


class TestWatcherLogRotation:
    """Test watcher log rotation at 5MB."""

    def test_watcher_rotates_large_log(self, tmp_path, monkeypatch):
        """Create a file >5MB, call the rotation logic, verify .log.1 was created."""
        monkeypatch.setattr("pathlib.Path.home", lambda: tmp_path)

        log_dir = tmp_path / ".coppermind"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "watcher.log"

        # Create a file larger than 5MB
        log_path.write_bytes(b"x" * (6 * 1024 * 1024))
        assert log_path.stat().st_size > 5 * 1024 * 1024

        # Run the rotation logic directly (same as in _start_watcher)
        MAX_WATCHER_LOG_BYTES = 5 * 1024 * 1024
        try:
            if log_path.exists() and log_path.stat().st_size > MAX_WATCHER_LOG_BYTES:
                log_path.rename(log_path.with_suffix(".log.1"))
        except OSError:
            pass

        # Original should be gone, rotated file should exist
        assert not log_path.exists()
        rotated = log_dir / "watcher.log.1"
        assert rotated.exists()
        assert rotated.stat().st_size > 5 * 1024 * 1024


# ---------------------------------------------------------------------------
# Regression: re-entrant lock deadlock in _ensure_initialized (GH #02d7a66)
#
# _run_startup_checks() calls get_db() which calls _ensure_initialized().
# If _ensure_initialized holds a non-reentrant Lock and the recursive call
# tries to acquire it, the thread deadlocks.  Two defenses:
#   1. Pre-lock flag check: `if _server.initializing: return`
#   2. RLock: same thread can re-acquire without blocking
# ---------------------------------------------------------------------------

class TestEnsureInitializedDeadlock:
    """Regression tests for the re-entrant lock deadlock in _ensure_initialized."""

    def setup_method(self):
        server_mod._server.config = None
        server_mod._server.db = None
        server_mod._server.initialized = False
        server_mod._server.initializing = False

    def test_recursive_get_db_does_not_deadlock(self):
        """_startup_checks calls get_db which calls _ensure_initialized.

        This must not deadlock.  The pre-lock guard (_server.initializing)
        short-circuits the recursive call before reaching the lock.
        Regression: before the fix, threading.Lock blocked the same thread.
        """
        call_count = {"startup": 0}

        def fake_startup_checks():
            call_count["startup"] += 1
            # Simulate what _run_startup_checks does: call get_db()
            server_mod.get_db()

        with patch("coppermind_cmo.server._startup_checks", side_effect=fake_startup_checks), \
             patch("coppermind_cmo.server.Database") as MockDB:
            server_mod._server.config = MagicMock()
            # Should complete without hanging (timeout would indicate deadlock)
            server_mod._ensure_initialized()

        assert server_mod._server.initialized is True
        assert server_mod._server.initializing is False
        assert call_count["startup"] == 1

    def test_initializing_flag_prevents_recursive_startup(self):
        """When _server.initializing is True, _ensure_initialized returns immediately."""
        server_mod._server.initializing = True
        # If this tried to acquire the lock and run _startup_checks, it would
        # call get_db() recursively.  With the flag guard it's a no-op.
        server_mod._ensure_initialized()
        # initialized should still be False — startup was not run
        assert server_mod._server.initialized is False

    def test_initialized_flag_prevents_rerun(self):
        """Once initialized, _ensure_initialized is a no-op."""
        server_mod._server.initialized = True
        # Should return immediately without touching the lock
        server_mod._ensure_initialized()
        assert server_mod._server.initialized is True

    def test_init_lock_is_reentrant(self):
        """init_lock must be an RLock so the same thread can acquire it twice."""
        import threading
        assert isinstance(server_mod._server.init_lock, type(threading.RLock()))

    def test_initializing_flag_reset_on_success(self):
        """After successful startup, initializing is reset to False."""
        with patch("coppermind_cmo.server._startup_checks"):
            server_mod._ensure_initialized()

        assert server_mod._server.initialized is True
        assert server_mod._server.initializing is False

    def test_initializing_flag_reset_on_failure(self):
        """If _startup_checks raises, initializing is still reset to False."""
        with patch("coppermind_cmo.server._startup_checks",
                   side_effect=RuntimeError("boom")):
            with pytest.raises(RuntimeError, match="boom"):
                server_mod._ensure_initialized()

        assert server_mod._server.initialized is False
        assert server_mod._server.initializing is False

    def test_concurrent_callers_only_run_startup_once(self):
        """Multiple threads calling _ensure_initialized should only run startup once."""
        import threading

        call_count = {"startup": 0}
        barrier = threading.Barrier(3)

        def slow_startup():
            call_count["startup"] += 1
            import time
            time.sleep(0.1)  # simulate slow startup

        with patch("coppermind_cmo.server._startup_checks", side_effect=slow_startup):
            def worker():
                barrier.wait()
                server_mod._ensure_initialized()

            threads = [threading.Thread(target=worker) for _ in range(3)]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=5)

        assert call_count["startup"] == 1
        assert server_mod._server.initialized is True
