"""Tests for the auto-updater and ServerConfig new fields."""

import subprocess
from unittest.mock import patch, MagicMock

import pytest

import coppermind_cmo.updater as updater_mod
from coppermind_cmo.updater import (
    check_and_update,
    get_update_notifications,
    get_update_state,
    _find_uv,
    _find_pipx,
    _do_upgrade,
    _update_notification_provider,
)
from coppermind_cmo.config import ServerConfig, fetch_server_config


# ---------------------------------------------------------------------------
# check_and_update: current == latest does nothing
# ---------------------------------------------------------------------------
class TestCheckAndUpdateAlreadyCurrent:
    def test_no_update_when_current_equals_latest(self):
        """When installed version matches latest, status stays idle."""
        with patch("coppermind_cmo.updater.pkg_version", return_value="0.4.5"):
            # Run synchronously via _do_upgrade (not threaded)
            _do_upgrade("0.4.5", "none")

        state = get_update_state()
        assert state["status"] == "idle"
        assert state["current_version"] == "0.4.5"
        assert state["latest_version"] == "0.4.5"


# ---------------------------------------------------------------------------
# check_and_update: current < latest sets status to "ready"
# ---------------------------------------------------------------------------
class TestCheckAndUpdateOutdated:
    def test_update_sets_ready_on_success(self):
        """When outdated and uv succeeds, status becomes 'ready'."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "Updated coppermind-cmo"
        mock_result.stderr = ""

        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.0"),
            patch("coppermind_cmo.updater._find_uv", return_value="/usr/local/bin/uv"),
            patch("coppermind_cmo.updater._find_pipx", return_value=None),
            patch("subprocess.run", return_value=mock_result) as mock_run,
        ):
            _do_upgrade("0.4.5", "recommended")

        state = get_update_state()
        assert state["status"] == "ready"
        assert state["current_version"] == "0.4.0"
        assert state["latest_version"] == "0.4.5"

        # Verify the subprocess was called with uv
        mock_run.assert_called_once()
        call_args = mock_run.call_args
        assert call_args[0][0] == ["/usr/local/bin/uv", "tool", "upgrade", "coppermind-cmo"]


# ---------------------------------------------------------------------------
# check_and_update: no uv available sets error
# ---------------------------------------------------------------------------
class TestCheckAndUpdateNoInstaller:
    def test_no_installer_sets_failed(self):
        """When neither uv nor pipx is found, status becomes 'failed'."""
        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.0"),
            patch("coppermind_cmo.updater._find_uv", return_value=None),
            patch("coppermind_cmo.updater._find_pipx", return_value=None),
        ):
            _do_upgrade("0.4.5", "none")

        state = get_update_state()
        assert state["status"] == "failed"
        assert "uv" in state["error"].lower() or "pipx" in state["error"].lower()


# ---------------------------------------------------------------------------
# check_and_update: subprocess failure sets error
# ---------------------------------------------------------------------------
class TestCheckAndUpdateSubprocessFailure:
    def test_subprocess_failure_sets_failed(self):
        """When the upgrade command fails, status becomes 'failed'."""
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "error: package not found"

        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.0"),
            patch("coppermind_cmo.updater._find_uv", return_value="/usr/local/bin/uv"),
            patch("subprocess.run", return_value=mock_result),
        ):
            _do_upgrade("0.4.5", "none")

        state = get_update_state()
        assert state["status"] == "failed"
        assert "package not found" in state["error"]


# ---------------------------------------------------------------------------
# get_update_notifications: returns notification once then empty
# ---------------------------------------------------------------------------
class TestNotificationsOnceThenEmpty:
    def test_notification_returned_once(self):
        """After update is ready, notification is returned once, then []."""
        # Simulate a successful update
        updater_mod._update_state["status"] = "ready"
        updater_mod._update_state["current_version"] = "0.4.0"
        updater_mod._update_state["latest_version"] = "0.4.5"
        updater_mod._update_state["notified"] = False

        # First call: should get a notification
        notifs = get_update_notifications()
        assert len(notifs) == 1
        assert notifs[0]["type"] == "update_available"
        assert "0.4.5" in notifs[0]["message"]
        assert notifs[0]["current_version"] == "0.4.0"
        assert notifs[0]["latest_version"] == "0.4.5"

        # Second call: should be empty (already notified)
        notifs2 = get_update_notifications()
        assert notifs2 == []


# ---------------------------------------------------------------------------
# get_update_notifications: returns empty when no update
# ---------------------------------------------------------------------------
class TestNotificationsNoUpdate:
    def test_no_notification_when_idle(self):
        """When status is idle (no update), returns []."""
        updater_mod._update_state["status"] = "idle"
        updater_mod._update_state["notified"] = False

        notifs = get_update_notifications()
        assert notifs == []

    def test_no_notification_when_checking(self):
        """While still checking, returns []."""
        updater_mod._update_state["status"] = "checking"
        updater_mod._update_state["notified"] = False

        notifs = get_update_notifications()
        assert notifs == []

    def test_no_notification_when_downloading(self):
        """While downloading, returns []."""
        updater_mod._update_state["status"] = "downloading"
        updater_mod._update_state["notified"] = False

        notifs = get_update_notifications()
        assert notifs == []


# ---------------------------------------------------------------------------
# get_update_notifications: failed state returns error notification once
# ---------------------------------------------------------------------------
class TestNotificationsFailed:
    def test_failed_notification_returned_once(self):
        """When update fails, error notification is returned once."""
        updater_mod._update_state["status"] = "failed"
        updater_mod._update_state["latest_version"] = "0.4.5"
        updater_mod._update_state["error"] = "Network timeout"
        updater_mod._update_state["notified"] = False

        notifs = get_update_notifications()
        assert len(notifs) == 1
        assert notifs[0]["type"] == "update_failed"
        assert "Network timeout" in notifs[0]["message"]
        assert "coppermind-update" in notifs[0]["message"]

        # Second call: empty
        assert get_update_notifications() == []


# ---------------------------------------------------------------------------
# ServerConfig parses new fields correctly
# ---------------------------------------------------------------------------
class TestServerConfigNewFields:
    def test_server_config_defaults(self):
        """ServerConfig has correct defaults for new fields."""
        cfg = ServerConfig()
        assert cfg.latest_version == ""
        assert cfg.upgrade_urgency == "none"
        assert cfg.changelog_url == ""
        assert cfg.fetched is False

    def test_server_config_explicit_values(self):
        """ServerConfig accepts new fields explicitly."""
        cfg = ServerConfig(
            min_client_version="0.2.0",
            latest_version="0.4.5",
            upgrade_urgency="required",
            changelog_url="https://example.com/changelog",
            fetched=True,
        )
        assert cfg.latest_version == "0.4.5"
        assert cfg.upgrade_urgency == "required"
        assert cfg.changelog_url == "https://example.com/changelog"

    def test_fetch_server_config_parses_new_fields(self):
        """fetch_server_config populates new fields from gateway response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "min_client_version": "0.2.0",
            "latest_version": "0.4.5",
            "upgrade_message": "Run: coppermind-update",
            "upgrade_urgency": "recommended",
            "changelog_url": "https://example.com/changelog",
            "prompts": {"extraction": "test prompt"},
        }

        mock_config = MagicMock()
        mock_config.gateway_url = "https://api.coppermind.dev"
        mock_config.api_key = "test-key"

        # Reset cached config
        import coppermind_cmo.config as config_mod
        config_mod._server_config = None

        with patch("httpx.get", return_value=mock_response):
            result = fetch_server_config(mock_config)

        assert result.fetched is True
        assert result.latest_version == "0.4.5"
        assert result.upgrade_urgency == "recommended"
        assert result.changelog_url == "https://example.com/changelog"
        assert result.min_client_version == "0.2.0"

    def test_fetch_server_config_handles_missing_new_fields(self):
        """fetch_server_config uses defaults when new fields are absent from response."""
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "min_client_version": "0.2.0",
            "upgrade_message": "old gateway",
            "prompts": {},
        }

        mock_config = MagicMock()
        mock_config.gateway_url = "https://api.coppermind.dev"
        mock_config.api_key = "test-key"

        import coppermind_cmo.config as config_mod
        config_mod._server_config = None

        with patch("httpx.get", return_value=mock_response):
            result = fetch_server_config(mock_config)

        assert result.fetched is True
        assert result.latest_version == ""
        assert result.upgrade_urgency == "none"
        assert result.changelog_url == ""


# ---------------------------------------------------------------------------
# check_and_update uses pipx as fallback
# ---------------------------------------------------------------------------
class TestPipxFallback:
    def test_uses_pipx_when_no_uv(self):
        """When uv is missing but pipx is available, uses pipx."""
        mock_result = MagicMock()
        mock_result.returncode = 0

        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.0"),
            patch("coppermind_cmo.updater._find_uv", return_value=None),
            patch("coppermind_cmo.updater._find_pipx", return_value="/usr/local/bin/pipx"),
            patch("subprocess.run", return_value=mock_result) as mock_run,
        ):
            _do_upgrade("0.4.5", "none")

        state = get_update_state()
        assert state["status"] == "ready"
        mock_run.assert_called_once()
        call_args = mock_run.call_args
        assert call_args[0][0] == ["/usr/local/bin/pipx", "upgrade", "coppermind-cmo"]


# ---------------------------------------------------------------------------
# check_and_update spawns a daemon thread
# ---------------------------------------------------------------------------
class TestCheckAndUpdateThread:
    def test_spawns_daemon_thread(self):
        """check_and_update spawns a daemon thread that doesn't block."""
        with (
            patch("coppermind_cmo.updater.pkg_version", return_value="0.4.5"),
            patch("coppermind_cmo.updater._find_uv", return_value=None),
        ):
            # Should not raise or block
            check_and_update("0.4.5", "none")
            # Give thread a moment to complete
            import time
            time.sleep(0.1)

        # Thread ran and found version is current
        state = get_update_state()
        assert state["status"] == "idle"


# ---------------------------------------------------------------------------
# _find_uv: fallback to common paths when not on PATH
# ---------------------------------------------------------------------------
class TestFindUvFallback:
    def test_find_uv_returns_from_path(self):
        """When uv is on PATH, returns that path."""
        with patch("shutil.which", return_value="/usr/local/bin/uv"):
            assert _find_uv() == "/usr/local/bin/uv"

    def test_find_uv_falls_back_to_common_locations(self, tmp_path):
        """When uv is not on PATH, checks common install locations."""
        fake_uv = tmp_path / "uv"
        fake_uv.write_text("#!/bin/sh\n")
        fake_uv.chmod(0o755)

        with (
            patch("shutil.which", return_value=None),
            patch("coppermind_cmo.updater._COMMON_UV_PATHS", [fake_uv]),
        ):
            assert _find_uv() == str(fake_uv)

    def test_find_uv_returns_none_when_not_found(self):
        """When uv is nowhere, returns None."""
        with (
            patch("shutil.which", return_value=None),
            patch("coppermind_cmo.updater._COMMON_UV_PATHS", []),
        ):
            assert _find_uv() is None


# ---------------------------------------------------------------------------
# _find_pipx: basic coverage
# ---------------------------------------------------------------------------
class TestFindPipx:
    def test_find_pipx_returns_path(self):
        with patch("shutil.which", return_value="/usr/local/bin/pipx"):
            assert _find_pipx() == "/usr/local/bin/pipx"

    def test_find_pipx_returns_none(self):
        with patch("shutil.which", return_value=None):
            assert _find_pipx() is None


# ---------------------------------------------------------------------------
# _do_upgrade: exception in the upgrade process
# ---------------------------------------------------------------------------
class TestDoUpgradeException:
    def test_exception_sets_failed_state(self):
        """An unexpected exception during upgrade sets status to 'failed'."""
        with (
            patch("coppermind_cmo.updater.pkg_version", side_effect=Exception("kaboom")),
        ):
            _do_upgrade("0.4.5", "none")

        state = get_update_state()
        assert state["status"] == "failed"
        assert "kaboom" in state["error"]


# ---------------------------------------------------------------------------
# _update_notification_provider: adapter for registry
# ---------------------------------------------------------------------------
class TestUpdateNotificationProvider:
    def test_adapter_delegates_to_get_update_notifications(self):
        """The adapter passes through to get_update_notifications."""
        updater_mod._update_state["status"] = "ready"
        updater_mod._update_state["current_version"] = "0.4.0"
        updater_mod._update_state["latest_version"] = "0.4.5"
        updater_mod._update_state["notified"] = False

        # Adapter takes (db, customer_id) but ignores them
        notifs = _update_notification_provider("fake_db", "fake_customer")
        assert len(notifs) == 1
        assert notifs[0]["type"] == "update_available"

    def test_adapter_returns_empty_when_no_update(self):
        updater_mod._update_state["status"] = "idle"
        updater_mod._update_state["notified"] = False

        notifs = _update_notification_provider("fake_db", "fake_customer")
        assert notifs == []
