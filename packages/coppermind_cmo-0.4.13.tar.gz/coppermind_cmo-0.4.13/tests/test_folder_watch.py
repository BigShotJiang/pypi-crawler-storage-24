"""Tests for FolderWatcher — scanning, processing, stability, status, path loading."""

import json
import os
import time
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from coppermind_cmo.folder_watch import (
    FolderWatcher,
    MAX_FILES_PER_CYCLE,
    MAX_FAILURES,
    DEFAULT_DEBOUNCE_SECONDS,
    check_path_overlap,
)


@pytest.fixture
def mock_db():
    return MagicMock()


@pytest.fixture
def mock_config():
    config = MagicMock()
    config.api_key = ""
    config.ollama_url = "http://localhost:11434"
    config.ollama_model = "gemma3:12b"
    config.llm_provider = "ollama"
    config.embedding_provider = "local"
    config.embedding_dims = 384
    config.max_prompt_chars = 13000
    return config


class TestFolderWatcherInit:
    def test_init_defaults(self, mock_db, mock_config):
        """FolderWatcher initializes with correct defaults."""
        watcher = FolderWatcher(mock_db, mock_config, customer_id="cust-1")
        assert watcher.db is mock_db
        assert watcher.config is mock_config
        assert watcher.customer_id == "cust-1"
        assert watcher._mtime_cache == {}
        assert watcher._watched == {}
        assert watcher._failure_counts == {}
        assert watcher.debounce_seconds == DEFAULT_DEBOUNCE_SECONDS

    def test_init_debounce_from_env(self, mock_db, mock_config, monkeypatch):
        """Debounce interval can be configured via env var."""
        monkeypatch.setenv("COPPERMIND_WATCH_DEBOUNCE_SECONDS", "30")
        watcher = FolderWatcher(mock_db, mock_config)
        assert watcher.debounce_seconds == 30

    def test_init_debounce_min_floor(self, mock_db, mock_config, monkeypatch):
        """Debounce interval has a minimum of 5 seconds."""
        monkeypatch.setenv("COPPERMIND_WATCH_DEBOUNCE_SECONDS", "1")
        watcher = FolderWatcher(mock_db, mock_config)
        assert watcher.debounce_seconds == 5


class TestScanOnce:
    def test_scan_once_returns_new_files(self, mock_db, mock_config, tmp_path):
        """New files in a watched directory are detected."""
        (tmp_path / "doc.txt").write_text("This is a document for ingestion.")
        (tmp_path / "notes.md").write_text("Some markdown notes here.")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {
            "mind-1": ("Acme", [str(tmp_path)]),
        }

        results = watcher.scan_once()
        paths = {str(r[2].name) for r in results}
        assert "doc.txt" in paths
        assert "notes.md" in paths

    def test_scan_once_skips_symlinks(self, mock_db, mock_config, tmp_path):
        """Symlinked files are skipped."""
        real = tmp_path / "real.txt"
        real.write_text("real content here")
        link = tmp_path / "link.txt"
        link.symlink_to(real)

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {"mind-1": ("Acme", [str(tmp_path)])}

        results = watcher.scan_once()
        names = {r[2].name for r in results}
        assert "real.txt" in names
        assert "link.txt" not in names

    def test_scan_once_skips_large_files(self, mock_db, mock_config, tmp_path):
        """Files over AUTO_MAX_FILE_SIZE are skipped."""
        big = tmp_path / "huge.txt"
        big.write_text("x" * 100)  # small, but we patch the limit

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {"mind-1": ("Acme", [str(tmp_path)])}

        with patch("coppermind_cmo.folder_watch.AUTO_MAX_FILE_SIZE", 10):
            results = watcher.scan_once()
        assert len(results) == 0

    def test_scan_once_skips_hidden_files(self, mock_db, mock_config, tmp_path):
        """Hidden files (starting with .) are skipped."""
        (tmp_path / ".hidden.txt").write_text("hidden content")
        (tmp_path / "visible.txt").write_text("visible content")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {"mind-1": ("Acme", [str(tmp_path)])}

        results = watcher.scan_once()
        names = {r[2].name for r in results}
        assert "visible.txt" in names
        assert ".hidden.txt" not in names

    def test_scan_once_skips_unchanged_files(self, mock_db, mock_config, tmp_path):
        """Files with same mtime as cached are skipped."""
        f = tmp_path / "doc.txt"
        f.write_text("content here")
        mtime = f.stat().st_mtime

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {"mind-1": ("Acme", [str(tmp_path)])}
        watcher._mtime_cache[str(f)] = mtime

        results = watcher.scan_once()
        assert len(results) == 0

    def test_scan_once_detects_modified_files(self, mock_db, mock_config, tmp_path):
        """Files with changed mtime are detected as modified."""
        f = tmp_path / "doc.txt"
        f.write_text("original content")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {"mind-1": ("Acme", [str(tmp_path)])}
        # Set cached mtime to an old value
        watcher._mtime_cache[str(f)] = 0.0

        results = watcher.scan_once()
        assert len(results) == 1
        assert results[0][2].name == "doc.txt"

    def test_scan_once_skips_poison_files(self, mock_db, mock_config, tmp_path):
        """Files with too many failures (poison) are skipped."""
        f = tmp_path / "bad.txt"
        f.write_text("bad file content")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {"mind-1": ("Acme", [str(tmp_path)])}
        watcher._failure_counts[str(f)] = MAX_FAILURES

        results = watcher.scan_once()
        assert len(results) == 0


class TestProcessFiles:
    def test_process_files_ingests_via_engine(self, mock_db, mock_config, tmp_path):
        """Files are processed through IngestEngine."""
        f = tmp_path / "doc.txt"
        f.write_text("This is a valid document for ingestion testing purposes.")

        watcher = FolderWatcher(mock_db, mock_config)
        mock_db.fetch_one.return_value = None  # not already ingested

        files = [("mind-1", "Acme", f)]
        with patch("coppermind_cmo.folder_watch.IngestEngine") as MockEngine:
            mock_engine = MagicMock()
            mock_engine.process_source.return_value = {"new": 2, "updated": 0, "skipped": 0}
            MockEngine.return_value = mock_engine
            with patch("coppermind_cmo.folder_watch._check_file_already_ingested", return_value=False):
                result = watcher.process_files(files)

        assert result["processed"] == 1
        assert result["errors"] == 0
        mock_engine.process_source.assert_called_once()
        call_kwargs = mock_engine.process_source.call_args
        assert call_kwargs[1].get("supersede_old") is False or call_kwargs[0] == ()

    def test_process_files_tracks_poison_files(self, mock_db, mock_config, tmp_path):
        """Files that fail repeatedly get marked as poison."""
        f = tmp_path / "bad.txt"
        f.write_text("This is content that will fail extraction repeatedly.")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._failure_counts[str(f)] = MAX_FAILURES - 1

        files = [("mind-1", "Acme", f)]
        with patch("coppermind_cmo.folder_watch.IngestEngine") as MockEngine:
            MockEngine.return_value.process_source.side_effect = RuntimeError("LLM down")
            with patch("coppermind_cmo.folder_watch._check_file_already_ingested", return_value=False):
                result = watcher.process_files(files)

        assert result["errors"] == 1
        assert watcher._failure_counts[str(f)] >= MAX_FAILURES

    def test_process_files_skips_already_ingested(self, mock_db, mock_config, tmp_path):
        """Files that are already ingested (same hash) are skipped."""
        f = tmp_path / "doc.txt"
        f.write_text("Already ingested document content here.")

        watcher = FolderWatcher(mock_db, mock_config)
        files = [("mind-1", "Acme", f)]

        with patch("coppermind_cmo.folder_watch._check_file_already_ingested", return_value=True):
            result = watcher.process_files(files)

        assert result["skipped"] == 1
        assert result["processed"] == 0


class TestStabilityCheck:
    def test_stability_check_two_readings(self, mock_db, mock_config, tmp_path):
        """File is stable after two size readings match across debounce interval."""
        f = tmp_path / "doc.txt"
        f.write_text("stable content")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher.debounce_seconds = 0  # instant for testing

        # First check — records size, returns False
        assert watcher.check_stability(f) is False
        assert str(f) in watcher._pending_stability

        # Second check — same size, enough time passed (debounce=0)
        assert watcher.check_stability(f) is True
        # Pending entry should be cleaned up
        assert str(f) not in watcher._pending_stability

    def test_stability_check_size_changed(self, mock_db, mock_config, tmp_path):
        """If file size changes, stability resets."""
        f = tmp_path / "doc.txt"
        f.write_text("initial content")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher.debounce_seconds = 0

        # First reading
        assert watcher.check_stability(f) is False

        # Change the file size
        f.write_text("longer content now with more text")

        # Second reading — size changed, should reset and return False
        assert watcher.check_stability(f) is False

    def test_stability_check_file_disappeared(self, mock_db, mock_config, tmp_path):
        """If file disappears during stability check, returns False."""
        f = tmp_path / "temp.txt"
        f.write_text("content")

        watcher = FolderWatcher(mock_db, mock_config)
        watcher._pending_stability[str(f)] = (100, time.time() - 100)

        # Delete the file
        f.unlink()

        assert watcher.check_stability(f) is False
        assert str(f) not in watcher._pending_stability


class TestWriteStatus:
    def test_write_status_json(self, mock_db, mock_config, tmp_path):
        """Status file is written with correct structure."""
        watcher = FolderWatcher(mock_db, mock_config)
        watcher._watched = {"mind-1": ("Acme", ["/tmp/acme"])}
        watcher._mtime_cache = {"/tmp/acme/doc.txt": 1234.0}

        status_file = tmp_path / "status.json"
        with patch("coppermind_cmo.folder_watch._STATUS_FILE", status_file):
            with patch("coppermind_cmo.folder_watch._STATUS_DIR", tmp_path):
                watcher.write_status({"files_processed": 5, "errors": 0})

        assert status_file.exists()
        data = json.loads(status_file.read_text())
        assert data["paths_watched"] == 1
        assert data["minds_watched"] == 1
        assert data["cached_files"] == 1
        assert data["last_cycle"]["files_processed"] == 5


class TestLoadWatchedPaths:
    def test_load_watched_paths_from_db(self, mock_db, mock_config):
        """Paths are loaded from client_minds table."""
        mock_db.fetch_all.return_value = [
            ("mind-1", "Acme", "/home/user/Acme", ["/home/user/Google Drive/Acme"]),
            ("mind-2", "Beta", None, None),
            ("mind-3", "Gamma", "/home/user/Gamma", []),
        ]

        watcher = FolderWatcher(mock_db, mock_config, customer_id="cust-1")
        result = watcher._load_watched_paths()

        assert "mind-1" in result
        assert result["mind-1"][0] == "Acme"
        assert len(result["mind-1"][1]) == 2
        assert "/home/user/Acme" in result["mind-1"][1]
        assert "/home/user/Google Drive/Acme" in result["mind-1"][1]

        # mind-2 has no paths, should not appear
        assert "mind-2" not in result

        # mind-3 has only local_path
        assert "mind-3" in result
        assert len(result["mind-3"][1]) == 1

    def test_load_watched_paths_empty_db(self, mock_db, mock_config):
        """Empty DB returns empty dict."""
        mock_db.fetch_all.return_value = []

        watcher = FolderWatcher(mock_db, mock_config)
        result = watcher._load_watched_paths()
        assert result == {}

    def test_load_watched_paths_excludes_coppermind_dir(self, mock_db, mock_config):
        """Coppermind output subfolder is added to excluded dirs."""
        mock_db.fetch_all.return_value = [
            ("mind-1", "Acme", "/home/user/Acme", []),
        ]
        watcher = FolderWatcher(mock_db, mock_config, customer_id="cust-1")
        watcher._load_watched_paths()
        assert "/home/user/Acme/Coppermind" in watcher._excluded_dirs


class TestCoppermindExclusion:
    """Codex P1: Coppermind output folders must not be self-ingested."""

    def test_scan_skips_coppermind_subfolder(self, mock_db, mock_config, tmp_path):
        """Files in Coppermind/ subfolders are not returned by scan_once."""
        client_dir = tmp_path / "ClientX"
        client_dir.mkdir()
        cm_dir = client_dir / "Coppermind" / "Briefs"
        cm_dir.mkdir(parents=True)

        # User-dropped file (should be found)
        user_doc = client_dir / "strategy.txt"
        user_doc.write_text("This is a user-created strategy document with enough text.")

        # save_output-generated file (should be excluded)
        output_doc = cm_dir / "2026-03-24-brief.md"
        output_doc.write_text("# Auto-generated brief from save_output tool.")

        watcher = FolderWatcher(mock_db, mock_config, customer_id="cust-1")
        watcher._watched = {"mind-1": ("ClientX", [str(client_dir)])}
        watcher._excluded_dirs = {str(client_dir / "Coppermind")}

        results = watcher.scan_once()
        found_paths = [str(p) for _, _, p in results]

        assert str(user_doc) in found_paths
        assert str(output_doc) not in found_paths


class TestPathOverlap:
    """Codex P2: Reject overlapping watch roots across minds."""

    def test_child_of_existing_rejected(self):
        """A path that is a child of an existing watched path is rejected."""
        existing = {"/Clients": ("mind-1", "Globex")}
        result = check_path_overlap("/Clients/Acme", existing)
        assert result is not None
        assert "Globex" in result

    def test_parent_of_existing_rejected(self):
        """A path that is a parent of an existing watched path is rejected."""
        existing = {"/Clients/Acme": ("mind-1", "Acme")}
        result = check_path_overlap("/Clients", existing)
        assert result is not None
        assert "Acme" in result

    def test_exact_duplicate_allowed(self):
        """Exact same path (shared folder) is allowed with a warning."""
        existing = {"/Shared/Marketing": ("mind-1", "Acme")}
        result = check_path_overlap("/Shared/Marketing", existing)
        assert result is None

    def test_disjoint_paths_allowed(self):
        """Non-overlapping paths are fine."""
        existing = {"/Clients/Acme": ("mind-1", "Acme")}
        result = check_path_overlap("/Clients/Beta", existing)
        assert result is None

    def test_exclude_own_mind(self):
        """When updating a mind's own path, its existing paths are excluded."""
        existing = {"/Clients/Acme": ("mind-1", "Acme")}
        result = check_path_overlap("/Clients/Acme/Subdir", existing, exclude_mind_id="mind-1")
        assert result is None
