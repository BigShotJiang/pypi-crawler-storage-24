"""Tests for get_brand_voice and set_brand_voice tools."""

import json
import pytest
from unittest.mock import MagicMock
from coppermind_cmo.tools.brand import _get_brand_voice, _set_brand_voice
from coppermind_cmo.utils import parse_jsonb


class TestGetBrandVoice:
    def test_requires_active_mind(self):
        db = MagicMock()
        result = _get_brand_voice(db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_returns_brand_dna(self):
        db = MagicMock()
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["casual"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({"elevator_pitch": "We do things"}),
            json.dumps([{"name": "Sarah", "title": "VP"}]),
            ["dev education", "tutorials"],
        )
        mind = ("mind-1", "Acme Corp")
        result = _get_brand_voice(db, mind)
        assert result["name"] == "Acme Corp"
        assert result["brand_voice"]["tone"] == ["casual"]
        assert result["stakeholders"][0]["name"] == "Sarah"
        assert result["content_themes"] == ["dev education", "tutorials"]

    def test_returns_defaults_when_empty(self):
        db = MagicMock()
        db.fetch_one.return_value = ("New Client", "{}", "{}", "{}", "[]", None)
        mind = ("mind-1", "New Client")
        result = _get_brand_voice(db, mind)
        assert result["brand_voice"] == {}
        assert result["stakeholders"] == []
        assert result["content_themes"] == []

    def test_mind_id_override_bypasses_active_mind(self):
        """get_brand_voice with mind_id_override reads from specified mind, not active."""
        db = MagicMock()
        db.fetch_one.return_value = (
            "Other Client",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "Finance"}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        result = _get_brand_voice(db, None, mind_id_override="override-id")
        assert result["name"] == "Other Client"
        db.fetch_one.assert_called_once()
        call_args = db.fetch_one.call_args
        assert "override-id" in call_args[0][1]


class TestSetBrandVoice:
    def test_requires_active_mind(self):
        db = MagicMock()
        result = _set_brand_voice({"brand_voice": {"tone": ["casual"]}}, db, None)
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_requires_at_least_one_field(self):
        db = MagicMock()
        result = _set_brand_voice({}, db, ("m", "n"))
        assert result["code"] == "INVALID_INPUT"

    def test_validates_brand_voice_requires_tone(self):
        db = MagicMock()
        result = _set_brand_voice(
            {"brand_voice": {"avoid": ["jargon"]}},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_validates_brand_positioning_requires_category(self):
        db = MagicMock()
        result = _set_brand_voice(
            {"brand_positioning": {"target_market": "SaaS"}},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_validates_stakeholders_max_50(self):
        db = MagicMock()
        stakeholders = [{"name": f"Person {i}"} for i in range(51)]
        result = _set_brand_voice(
            {"stakeholders": stakeholders},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_validates_stakeholder_requires_name(self):
        db = MagicMock()
        result = _set_brand_voice(
            {"stakeholders": [{"title": "VP"}]},
            db, ("m", "n"),
        )
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_updates_and_returns_previous(self):
        db = MagicMock()
        # Mock connection context manager for the cursor
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["casual", "direct"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual", "direct"]}},
            db, mind,
        )
        assert "previous" in result
        assert result["previous"]["brand_voice"]["tone"] == ["formal"]


# ---------------------------------------------------------------------------
# Additional TestGetBrandVoice cases
# ---------------------------------------------------------------------------

class TestGetBrandVoiceExtended:
    def test_returns_error_when_row_is_none(self):
        """Mock db.fetch_one to return None. Should return error with code INTERNAL_ERROR."""
        db = MagicMock()
        db.fetch_one.return_value = None
        mind = ("mind-1", "Phantom")
        result = _get_brand_voice(db, mind)
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"


# ---------------------------------------------------------------------------
# Additional TestSetBrandVoice cases
# ---------------------------------------------------------------------------

class TestSetBrandVoiceExtended:
    def _make_mind(self):
        return ("mind-1", "Acme Corp")

    def _make_current_row(self):
        """Standard current row for fetch_one side effects."""
        return (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah", "title": "VP"}]),
            ["blog"],
        )

    def _make_updated_row(self, **overrides):
        """Build an updated row, overriding specific fields."""
        defaults = {
            "name": "Acme Corp",
            "brand_voice": json.dumps({"tone": ["formal"]}),
            "brand_positioning": json.dumps({"category": "API platform"}),
            "approved_messaging": json.dumps({}),
            "stakeholders": json.dumps([{"name": "Sarah", "title": "VP"}]),
            "content_themes": ["blog"],
        }
        defaults.update(overrides)
        return (
            defaults["name"],
            defaults["brand_voice"],
            defaults["brand_positioning"],
            defaults["approved_messaging"],
            defaults["stakeholders"],
            defaults["content_themes"],
        )

    def test_content_themes_update(self):
        """Pass content_themes: ['blog', 'video']. Verify the update goes through."""
        db = MagicMock()
        mind = self._make_mind()
        # Mock connection context manager for the cursor
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = self._make_current_row()
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = self._make_updated_row(content_themes=["blog", "video"])

        result = _set_brand_voice({"content_themes": ["blog", "video"]}, db, mind)
        assert result["content_themes"] == ["blog", "video"]
        assert "error" not in result

    def test_multiple_fields_update(self):
        """Pass both brand_voice and stakeholders. Verify both are in result['previous']."""
        db = MagicMock()
        mind = self._make_mind()
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = self._make_current_row()
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = self._make_updated_row(
            brand_voice=json.dumps({"tone": ["casual"]}),
            stakeholders=json.dumps([{"name": "Bob"}]),
        )

        result = _set_brand_voice(
            {
                "brand_voice": {"tone": ["casual"]},
                "stakeholders": [{"name": "Bob"}],
            },
            db, mind,
        )
        assert "brand_voice" in result["previous"]
        assert "stakeholders" in result["previous"]

    def test_unknown_fields_filtered(self):
        """Pass {'unknown_key': 'value'}. Should return INVALID_INPUT (no valid fields)."""
        db = MagicMock()
        mind = self._make_mind()
        result = _set_brand_voice({"unknown_key": "value"}, db, mind)
        assert result["code"] == "INVALID_INPUT"

    def test_brand_voice_tone_not_list(self):
        """Pass brand_voice with tone as string instead of list. Should return INVALID_BRAND_DNA."""
        db = MagicMock()
        mind = self._make_mind()
        result = _set_brand_voice({"brand_voice": {"tone": "casual"}}, db, mind)
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_brand_positioning_category_not_string(self):
        """Pass brand_positioning with category as int. Should return INVALID_BRAND_DNA."""
        db = MagicMock()
        mind = self._make_mind()
        result = _set_brand_voice({"brand_positioning": {"category": 123}}, db, mind)
        assert result["code"] == "INVALID_BRAND_DNA"


# ---------------------------------------------------------------------------
# TestParseJsonb
# ---------------------------------------------------------------------------

class TestParseJsonb:
    def test_none_returns_empty_dict(self):
        assert parse_jsonb(None) == {}

    def test_string_is_parsed(self):
        assert parse_jsonb('{"a": 1}') == {"a": 1}

    def test_dict_passed_through(self):
        original = {"a": 1}
        result = parse_jsonb(original)
        assert result == {"a": 1}
        assert result is original  # same object, not a copy

    def test_list_passed_through(self):
        original = [1, 2]
        result = parse_jsonb(original)
        assert result == [1, 2]
        assert result is original  # same object, not a copy

    def test_invalid_json_returns_empty_dict(self):
        assert parse_jsonb("{corrupt") == {}

    def test_empty_string_returns_empty_dict(self):
        assert parse_jsonb("") == {}

    def test_bare_string_returns_string(self):
        assert parse_jsonb('"hello"') == "hello"

    def test_null_string_returns_none(self):
        assert parse_jsonb("null") is None


# ---------------------------------------------------------------------------
# TestContentThemesBounds
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Brand colors validation tests
# ---------------------------------------------------------------------------

class TestBrandColorsValidation:
    def test_set_brand_voice_accepts_valid_brand_colors(self):
        """brand_voice with valid hex brand_colors should pass validation."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        data = {
            "tone": ["casual"],
            "brand_colors": {"primary": "#FF5733", "secondary": "#33FF57", "accent": "#3357FF"},
        }
        result = _validate_brand_voice(data)
        err = result[0] if isinstance(result, tuple) else result
        assert err is None

    def test_set_brand_voice_rejects_invalid_hex_primary(self):
        """brand_voice with invalid hex for primary should fail validation."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        data = {
            "tone": ["casual"],
            "brand_colors": {"primary": "not-a-color"},
        }
        err, _ = _validate_brand_voice(data)
        assert err is not None
        assert "Invalid hex color" in err
        assert "primary" in err

    def test_set_brand_voice_rejects_invalid_hex_secondary(self):
        """brand_voice with invalid hex for secondary should fail validation."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        data = {
            "tone": ["formal"],
            "brand_colors": {"secondary": "#GGG"},
        }
        err, _ = _validate_brand_voice(data)
        assert err is not None
        assert "secondary" in err

    def test_set_brand_voice_rejects_invalid_hex_accent(self):
        """brand_voice with invalid hex for accent should fail validation."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        data = {
            "tone": ["direct"],
            "brand_colors": {"accent": "blue"},
        }
        err, _ = _validate_brand_voice(data)
        assert err is not None
        assert "accent" in err

    def test_set_brand_voice_ignores_unknown_color_keys(self):
        """Unknown color keys in brand_colors should not be validated."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        data = {
            "tone": ["casual"],
            "brand_colors": {"background": "not-valid-but-ignored"},
        }
        err, _ = _validate_brand_voice(data)
        assert err is None

    def test_set_brand_voice_empty_brand_colors_ok(self):
        """Empty brand_colors dict should pass validation."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        data = {
            "tone": ["casual"],
            "brand_colors": {},
        }
        err, _ = _validate_brand_voice(data)
        assert err is None

    def test_set_brand_voice_no_brand_colors_ok(self):
        """Missing brand_colors key should pass validation."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        data = {"tone": ["casual"]}
        err, _ = _validate_brand_voice(data)
        assert err is None


class TestContentThemesBounds:
    def test_set_brand_voice_rejects_too_many_content_themes(self, mock_db, active_mind):
        from coppermind_cmo.tools.brand import _set_brand_voice
        themes = [f"theme{i}" for i in range(21)]
        result = _set_brand_voice({"content_themes": themes}, mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_set_brand_voice_rejects_long_content_theme(self, mock_db, active_mind):
        from coppermind_cmo.tools.brand import _set_brand_voice
        themes = ["a" * 101]
        result = _set_brand_voice({"content_themes": themes}, mock_db, active_mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"


# ---------------------------------------------------------------------------
# Validation function edge cases (lines 25-47)
# ---------------------------------------------------------------------------

class TestValidationEdgeCases:
    """Exercise individual validation functions with wrong types."""

    def test_validate_brand_voice_not_dict(self):
        """Pass a string instead of dict to _validate_brand_voice."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        err, warnings = _validate_brand_voice("not a dict")
        assert err is not None
        assert "must be an object" in err

    def test_validate_brand_voice_missing_tone(self):
        """Dict without 'tone' key."""
        from coppermind_cmo.tools.brand import _validate_brand_voice
        err, warnings = _validate_brand_voice({"avoid": ["jargon"]})
        assert err is not None
        assert "tone" in err

    def test_validate_brand_positioning_not_dict(self):
        """Pass a string instead of dict."""
        from coppermind_cmo.tools.brand import _validate_brand_positioning
        err = _validate_brand_positioning("string value")
        assert err is not None
        assert "must be an object" in err

    def test_validate_brand_positioning_missing_category(self):
        """Dict without 'category' key."""
        from coppermind_cmo.tools.brand import _validate_brand_positioning
        err = _validate_brand_positioning({"target_market": "SaaS"})
        assert err is not None
        assert "category" in err

    def test_validate_stakeholders_not_list(self):
        """Pass a dict instead of list."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        err = _validate_stakeholders({"name": "Sarah"})
        assert err is not None
        assert "must be an array" in err

    def test_validate_stakeholders_missing_name(self):
        """Entry without 'name' field."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        err = _validate_stakeholders([{"title": "VP"}])
        assert err is not None
        assert "requires 'name'" in err

    def test_validate_stakeholders_too_many(self):
        """51 entries should exceed limit."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        entries = [{"name": f"Person {i}"} for i in range(51)]
        err = _validate_stakeholders(entries)
        assert err is not None
        assert "limited to 50" in err

    def test_validate_stakeholders_valid(self):
        """Valid list returns None."""
        from coppermind_cmo.tools.brand import _validate_stakeholders
        err = _validate_stakeholders([{"name": "Alice"}, {"name": "Bob"}])
        assert err is None


# ---------------------------------------------------------------------------
# set_brand_voice DB error path (lines 173-175)
# ---------------------------------------------------------------------------

class TestSetBrandVoiceDbError:
    def test_set_brand_voice_db_error(self):
        """Mock db.connection to raise. Verify tool_error returned."""
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")

        # First fetch_one for reading current values succeeds
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        # But connection() raises
        db.connection.side_effect = Exception("DB connection lost")

        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual"]}},
            db, mind,
        )
        assert result["error"] is True
        assert result["code"] == "DB_ERROR"

    def test_set_brand_voice_current_row_missing(self):
        """When cursor.fetchone returns None for current values, return INTERNAL_ERROR."""
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")
        # Mock connection context manager for the cursor
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Cursor read returns None (row missing)
        mock_cursor.fetchone.return_value = None

        result = _set_brand_voice(
            {"brand_voice": {"tone": ["casual"]}},
            db, mind,
        )
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"


# ---------------------------------------------------------------------------
# set_brand_voice via register() wrapper (lines 204, 215-226)
# ---------------------------------------------------------------------------

class TestSetBrandVoiceRegisterWrapper:
    """Exercise the register() wrapper to cover lines 215-226."""

    def test_register_wrapper_passes_non_none_fields(self):
        """Calling set_brand_voice with brand_voice + stakeholders, others None."""
        from coppermind_cmo.tools.brand import _set_brand_voice

        db = MagicMock()
        mind = ("mind-1", "Acme")

        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        # Current values read via cursor inside transaction
        mock_cursor.fetchone.return_value = ("Acme", "{}", "{}", "{}", "[]", [])
        # After update, read new values via db.fetch_one
        db.fetch_one.return_value = (
            "Acme", json.dumps({"tone": ["casual"]}), "{}", "{}", json.dumps([{"name": "Bob"}]), [],
        )

        # Build fields dict like the register wrapper does
        fields = {}
        fields["brand_voice"] = {"tone": ["casual"]}
        fields["stakeholders"] = [{"name": "Bob"}]

        result = _set_brand_voice(fields, db, mind)
        assert "error" not in result
        assert result["brand_voice"]["tone"] == ["casual"]

    def test_content_themes_not_list_returns_error(self):
        """content_themes must be a list."""
        db = MagicMock()
        mind = ("mind-1", "Acme")
        result = _set_brand_voice({"content_themes": "not-a-list"}, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"


# ---------------------------------------------------------------------------
# Brand voice wipe guard tests
# ---------------------------------------------------------------------------

class TestBrandVoiceWipeGuard:
    """Tests for the wipe detection caution on set_brand_voice."""

    def _setup_db(self, cursor_row, fetch_one_row):
        """Wire up a mock db with connection/cursor context managers."""
        db = MagicMock()
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = cursor_row
        db.fetch_one.return_value = fetch_one_row
        return db

    def test_set_brand_voice_wipe_guard_caution(self):
        """Clearing stakeholders when current has entries should produce a caution."""
        current_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah", "title": "VP"}, {"name": "Bob", "title": "CTO"}]),
            ["blog"],
        )
        updated_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([]),
            ["blog"],
        )
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"stakeholders": []}, db, mind)
        assert "caution" in result
        assert len(result["caution"]) == 1
        assert "stakeholders was cleared" in result["caution"][0]
        assert "2 entries" in result["caution"][0]

    def test_set_brand_voice_no_caution_on_normal_update(self):
        """A normal update (non-empty new value) should not produce a caution."""
        current_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah"}]),
            ["blog"],
        )
        updated_row = (
            "Acme Corp",
            json.dumps({"tone": ["casual", "direct"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([{"name": "Sarah"}]),
            ["blog"],
        )
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": {"tone": ["casual", "direct"]}}, db, mind)
        assert "caution" not in result

    def test_set_brand_voice_no_caution_when_already_empty(self):
        """Setting stakeholders=[] when already empty should not produce a caution."""
        current_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([]),
            ["blog"],
        )
        updated_row = (
            "Acme Corp",
            json.dumps({"tone": ["formal"]}),
            json.dumps({"category": "API platform"}),
            json.dumps({}),
            json.dumps([]),
            ["blog"],
        )
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"stakeholders": []}, db, mind)
        assert "caution" not in result


# ---------------------------------------------------------------------------
# Enhanced brand voice: visual_identity, anti_patterns, platform_guidance
# ---------------------------------------------------------------------------

class TestEnhancedBrandVoice:
    """Tests for visual_identity, anti_patterns, and platform_guidance."""

    def _setup_db(self, cursor_row, fetch_one_row):
        """Wire up a mock db with connection/cursor context managers."""
        db = MagicMock()
        mock_conn = MagicMock()
        mock_cursor = MagicMock()
        mock_conn.cursor.return_value.__enter__ = MagicMock(return_value=mock_cursor)
        mock_conn.cursor.return_value.__exit__ = MagicMock(return_value=False)
        db.connection.return_value.__enter__ = MagicMock(return_value=mock_conn)
        db.connection.return_value.__exit__ = MagicMock(return_value=False)
        mock_cursor.fetchone.return_value = cursor_row
        db.fetch_one.return_value = fetch_one_row
        return db

    def _base_voice(self, **overrides):
        """Build a brand_voice dict with tone + overrides."""
        voice = {"tone": ["professional", "warm"]}
        voice.update(overrides)
        return voice

    def _make_row(self, brand_voice_dict=None, **kw):
        """Build a DB row tuple."""
        bv = brand_voice_dict or {"tone": ["professional", "warm"]}
        defaults = {
            "name": "Acme Corp",
            "brand_voice": json.dumps(bv),
            "brand_positioning": json.dumps({"category": "SaaS"}),
            "approved_messaging": json.dumps({}),
            "stakeholders": json.dumps([]),
            "content_themes": [],
        }
        defaults.update(kw)
        return (
            defaults["name"],
            defaults["brand_voice"],
            defaults["brand_positioning"],
            defaults["approved_messaging"],
            defaults["stakeholders"],
            defaults["content_themes"],
        )

    # --- visual_identity ---

    def test_accepts_visual_identity_with_all_subfields(self):
        """set_brand_voice accepts visual_identity with typography, color_palette, etc."""
        voice = self._base_voice(
            visual_identity={
                "logo_usage": "Always use horizontal logo on light backgrounds",
                "photography_style": "Bright, natural lighting, diverse subjects",
                "graphic_treatments": "Rounded corners, subtle gradients",
                "typography": {
                    "headings": "Montserrat Bold",
                    "body": "Open Sans Regular",
                    "accent": "Montserrat SemiBold Italic",
                },
                "color_palette": {
                    "primary": "#2563eb",
                    "secondary": "#10b981",
                    "accent": "#f59e0b",
                    "neutral": "#6b7280",
                },
            }
        )
        current_row = self._make_row()
        updated_row = self._make_row(brand_voice_dict=voice)
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert "error" not in result
        assert result["brand_voice"]["visual_identity"]["typography"]["headings"] == "Montserrat Bold"
        assert result["brand_voice"]["visual_identity"]["color_palette"]["primary"] == "#2563eb"

    def test_rejects_invalid_hex_color(self):
        """color_palette with an invalid hex color should be rejected."""
        voice = self._base_voice(
            visual_identity={
                "color_palette": {
                    "primary": "not-a-color",
                }
            }
        )
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_BRAND_DNA"
        assert "hex color" in result["message"]

    def test_accepts_short_hex_color(self):
        """3-digit hex colors like #f00 should be valid."""
        voice = self._base_voice(
            visual_identity={
                "color_palette": {"primary": "#f00", "secondary": "#0f0"},
            }
        )
        current_row = self._make_row()
        updated_row = self._make_row(brand_voice_dict=voice)
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert "error" not in result

    # --- anti_patterns ---

    def test_accepts_anti_patterns_list(self):
        """set_brand_voice accepts anti_patterns as a list of strings."""
        voice = self._base_voice(
            anti_patterns=[
                "Never use exclamation marks",
                "Avoid corporate jargon like 'synergy'",
                "Don't start sentences with 'So,'",
            ]
        )
        current_row = self._make_row()
        updated_row = self._make_row(brand_voice_dict=voice)
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert "error" not in result
        assert result["brand_voice"]["anti_patterns"][0] == "Never use exclamation marks"

    def test_anti_patterns_over_20_produces_warning(self):
        """More than 20 anti_patterns should produce a warning, not a rejection."""
        items = [f"Don't do thing {i}" for i in range(25)]
        voice = self._base_voice(anti_patterns=items)
        current_row = self._make_row()
        updated_row = self._make_row(brand_voice_dict=voice)
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert "error" not in result  # NOT rejected
        assert "caution" in result
        assert any("25 items" in c for c in result["caution"])

    def test_anti_patterns_rejects_non_list(self):
        """anti_patterns as a string should be rejected."""
        voice = self._base_voice(anti_patterns="no jargon")
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_anti_patterns_rejects_non_string_items(self):
        """anti_patterns with non-string items should be rejected."""
        voice = self._base_voice(anti_patterns=["ok", 42])
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_BRAND_DNA"

    # --- platform_guidance ---

    def test_accepts_platform_guidance(self):
        """set_brand_voice accepts platform_guidance with platform dicts."""
        voice = self._base_voice(
            platform_guidance={
                "linkedin": {
                    "max_length": "3000 characters",
                    "hashtags": "2-3 industry hashtags",
                    "cta_style": "Soft CTA, never 'Buy now'",
                },
                "email": {
                    "subject_line": "Under 50 characters, no clickbait",
                    "greeting": "First name only",
                },
            }
        )
        current_row = self._make_row()
        updated_row = self._make_row(brand_voice_dict=voice)
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert "error" not in result
        assert result["brand_voice"]["platform_guidance"]["linkedin"]["hashtags"] == "2-3 industry hashtags"

    def test_platform_guidance_rejects_non_dict(self):
        """platform_guidance as a list should be rejected."""
        voice = self._base_voice(platform_guidance=["linkedin", "email"])
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_BRAND_DNA"

    def test_platform_guidance_rejects_non_dict_value(self):
        """platform_guidance with a string value instead of dict should be rejected."""
        voice = self._base_voice(platform_guidance={"linkedin": "short posts"})
        db = MagicMock()
        mind = ("mind-1", "Acme Corp")
        result = _set_brand_voice({"brand_voice": voice}, db, mind)
        assert result["error"] is True
        assert result["code"] == "INVALID_BRAND_DNA"

    # --- get_brand_voice surfaces new fields ---

    def test_get_brand_voice_surfaces_new_sections(self):
        """get_brand_voice should return visual_identity, anti_patterns, platform_guidance."""
        full_voice = {
            "tone": ["warm"],
            "visual_identity": {"color_palette": {"primary": "#000000"}},
            "anti_patterns": ["No jargon"],
            "platform_guidance": {"linkedin": {"max_length": "3000"}},
        }
        db = MagicMock()
        db.fetch_one.return_value = (
            "Acme Corp",
            json.dumps(full_voice),
            json.dumps({"category": "SaaS"}),
            json.dumps({}),
            json.dumps([]),
            [],
        )
        mind = ("mind-1", "Acme Corp")
        result = _get_brand_voice(db, mind)
        assert result["brand_voice"]["visual_identity"]["color_palette"]["primary"] == "#000000"
        assert result["brand_voice"]["anti_patterns"] == ["No jargon"]
        assert result["brand_voice"]["platform_guidance"]["linkedin"]["max_length"] == "3000"

    # --- deep merge verification ---

    def test_deep_merge_preserves_existing_nested_keys(self):
        """Setting visual_identity.typography should not wipe visual_identity.color_palette."""
        existing_voice = {
            "tone": ["professional"],
            "visual_identity": {
                "color_palette": {"primary": "#2563eb", "secondary": "#10b981"},
                "logo_usage": "Horizontal on light",
            },
        }
        # User sets only typography within visual_identity
        new_voice = {
            "tone": ["professional"],
            "visual_identity": {
                "typography": {"headings": "Montserrat Bold"},
            },
        }
        # After deep merge, expected result includes both color_palette and typography
        merged_voice = {
            "tone": ["professional"],
            "visual_identity": {
                "color_palette": {"primary": "#2563eb", "secondary": "#10b981"},
                "logo_usage": "Horizontal on light",
                "typography": {"headings": "Montserrat Bold"},
            },
        }

        current_row = self._make_row(brand_voice_dict=existing_voice)
        updated_row = self._make_row(brand_voice_dict=merged_voice)
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": new_voice}, db, mind)
        assert "error" not in result
        # The mock cursor.execute was called — verify the SQL payload was deep-merged
        mock_conn = db.connection.return_value.__enter__.return_value
        mock_cursor = mock_conn.cursor.return_value.__enter__.return_value
        # Find the UPDATE call for brand_voice (not history insert)
        update_calls = [
            c for c in mock_cursor.execute.call_args_list
            if len(c[0]) >= 2 and isinstance(c[0][1], list) and len(c[0][1]) == 2
            and c[0][1][1] == "mind-1"
            and isinstance(c[0][1][0], str)
            and "tone" in c[0][1][0]
        ]
        assert len(update_calls) >= 1
        written_json = json.loads(update_calls[0][0][1][0])
        # Deep merge should preserve color_palette and logo_usage
        assert "color_palette" in written_json["visual_identity"]
        assert written_json["visual_identity"]["color_palette"]["primary"] == "#2563eb"
        assert "typography" in written_json["visual_identity"]
        assert written_json["visual_identity"]["typography"]["headings"] == "Montserrat Bold"
        assert written_json["visual_identity"]["logo_usage"] == "Horizontal on light"

    def test_existing_brand_voice_fields_preserved(self):
        """Setting new sections should not wipe existing top-level brand_voice keys."""
        existing_voice = {
            "tone": ["casual"],
            "avoid": ["jargon"],
            "personality": "friendly expert",
        }
        new_voice = {
            "tone": ["casual"],
            "anti_patterns": ["No exclamation marks"],
        }
        merged_voice = {
            "tone": ["casual"],
            "avoid": ["jargon"],
            "personality": "friendly expert",
            "anti_patterns": ["No exclamation marks"],
        }

        current_row = self._make_row(brand_voice_dict=existing_voice)
        updated_row = self._make_row(brand_voice_dict=merged_voice)
        db = self._setup_db(current_row, updated_row)
        mind = ("mind-1", "Acme Corp")

        result = _set_brand_voice({"brand_voice": new_voice}, db, mind)
        assert "error" not in result
        # Verify the SQL payload preserved existing keys via deep merge
        mock_conn = db.connection.return_value.__enter__.return_value
        mock_cursor = mock_conn.cursor.return_value.__enter__.return_value
        update_calls = [
            c for c in mock_cursor.execute.call_args_list
            if len(c[0]) >= 2 and isinstance(c[0][1], list) and len(c[0][1]) == 2
            and c[0][1][1] == "mind-1"
            and isinstance(c[0][1][0], str)
            and "tone" in c[0][1][0]
        ]
        assert len(update_calls) >= 1
        written_json = json.loads(update_calls[0][0][1][0])
        assert written_json["avoid"] == ["jargon"]
        assert written_json["personality"] == "friendly expert"
        assert written_json["anti_patterns"] == ["No exclamation marks"]


# ---------------------------------------------------------------------------
# Unit tests for _deep_merge
# ---------------------------------------------------------------------------

class TestDeepMerge:
    def test_basic_merge(self):
        from coppermind_cmo.tools.brand import _deep_merge
        base = {"a": 1, "b": 2}
        overlay = {"b": 3, "c": 4}
        result = _deep_merge(base, overlay)
        assert result == {"a": 1, "b": 3, "c": 4}

    def test_nested_merge(self):
        from coppermind_cmo.tools.brand import _deep_merge
        base = {"x": {"a": 1, "b": 2}}
        overlay = {"x": {"b": 3, "c": 4}}
        result = _deep_merge(base, overlay)
        assert result == {"x": {"a": 1, "b": 3, "c": 4}}

    def test_overlay_replaces_non_dict(self):
        from coppermind_cmo.tools.brand import _deep_merge
        base = {"x": [1, 2]}
        overlay = {"x": [3, 4]}
        result = _deep_merge(base, overlay)
        assert result == {"x": [3, 4]}

    def test_does_not_mutate_base(self):
        from coppermind_cmo.tools.brand import _deep_merge
        base = {"x": {"a": 1}}
        overlay = {"x": {"b": 2}}
        result = _deep_merge(base, overlay)
        assert "b" not in base["x"]
        assert result["x"] == {"a": 1, "b": 2}


# ---------------------------------------------------------------------------
# Unit tests for _is_valid_hex_color
# ---------------------------------------------------------------------------

class TestIsValidHexColor:
    def test_valid_6_digit(self):
        from coppermind_cmo.tools.brand import _is_valid_hex_color
        assert _is_valid_hex_color("#ff0000") is True
        assert _is_valid_hex_color("#2563eb") is True
        assert _is_valid_hex_color("#FFFFFF") is True

    def test_valid_3_digit(self):
        from coppermind_cmo.tools.brand import _is_valid_hex_color
        assert _is_valid_hex_color("#f00") is True
        assert _is_valid_hex_color("#0F0") is True

    def test_invalid(self):
        from coppermind_cmo.tools.brand import _is_valid_hex_color
        assert _is_valid_hex_color("ff0000") is False  # missing #
        assert _is_valid_hex_color("#gg0000") is False  # invalid chars
        assert _is_valid_hex_color("#ff00") is False    # 4 digits
        assert _is_valid_hex_color("red") is False
        assert _is_valid_hex_color("") is False
