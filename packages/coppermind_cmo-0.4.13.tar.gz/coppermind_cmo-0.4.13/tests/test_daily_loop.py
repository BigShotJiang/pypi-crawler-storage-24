"""Tests for daily loop tools: log_meeting_event, get_cross_client_summary,
get_meeting_context, mark_followup_sent, mark_transcript_ingested,
get_weekly_summary, notifications."""

import json
import pytest
from datetime import datetime, date, timedelta, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch

import coppermind_cmo.tools.daily_loop as daily_loop_mod
from coppermind_cmo.tools.daily_loop import (
    _log_meeting_event,
    _get_cross_client_summary,
    _get_meeting_context,
    _mark_followup_sent,
    _mark_transcript_ingested,
    _get_weekly_summary,
    _has_meeting_log_table,
    _attach_all_notifications,
    get_daily_loop_notifications,
    _load_notification_state,
    _save_notification_state,
    _mark_notified,
    _already_notified,
    MAX_TITLE_CHARS,
    VALID_CONFIDENCE_VALUES,
)


def _dt(day: int, hour: int = 10) -> datetime:
    """Helper to create a timezone-aware datetime for March 2026."""
    return datetime(2026, 3, day, hour, 0, 0, tzinfo=timezone.utc)


CUSTOMER_ID = "cust-123"


@pytest.fixture(autouse=True)
def reset_meeting_log_cache(tmp_path, monkeypatch):
    """Reset the meeting_log table cache between tests."""
    daily_loop_mod._has_meeting_log = None
    daily_loop_mod._notification_state = None
    # Point notification state file to tmp path so tests don't touch real filesystem
    monkeypatch.setattr(
        daily_loop_mod, "_NOTIFICATION_STATE_FILE", tmp_path / "notification-state.json"
    )
    yield
    daily_loop_mod._has_meeting_log = None
    daily_loop_mod._notification_state = None


# ---------------------------------------------------------------------------
# _has_meeting_log_table
# ---------------------------------------------------------------------------

class TestHasMeetingLogTable:
    def test_first_call_queries_db_when_exists(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        assert _has_meeting_log_table(mock_db) is True
        mock_db.fetch_one.assert_called_once()

    def test_first_call_queries_db_when_missing(self, mock_db):
        mock_db.fetch_one.return_value = None
        assert _has_meeting_log_table(mock_db) is False
        mock_db.fetch_one.assert_called_once()

    def test_caches_true_on_second_call(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        assert _has_meeting_log_table(mock_db) is True
        assert _has_meeting_log_table(mock_db) is True
        # Should only query once because True is cached
        assert mock_db.fetch_one.call_count == 1

    def test_does_not_cache_false(self, mock_db):
        mock_db.fetch_one.return_value = None
        assert _has_meeting_log_table(mock_db) is False
        # Second call should re-query
        mock_db.fetch_one.return_value = (1,)
        assert _has_meeting_log_table(mock_db) is True

    def test_query_checks_information_schema(self, mock_db):
        mock_db.fetch_one.return_value = None
        _has_meeting_log_table(mock_db)
        call_args = mock_db.fetch_one.call_args
        assert "information_schema.tables" in call_args[0][0]
        assert "meeting_log" in call_args[0][0]


# ---------------------------------------------------------------------------
# log_meeting_event
# ---------------------------------------------------------------------------

class TestLogMeetingEvent:
    def test_create_new_meeting(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = ("meeting-uuid-1", True)
        result = _log_meeting_event(
            title="Weekly Sync",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id="mind-1",
            match_confidence="confident",
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["meeting_log_id"] == "meeting-uuid-1"
        assert result["is_new"] is True
        assert result["title"] == "Weekly Sync"
        assert result["mind_id"] == "mind-1"
        assert result["match_confidence"] == "confident"

    def test_upsert_with_calendar_event_id(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = ("meeting-uuid-2", False)
        result = _log_meeting_event(
            title="Updated Meeting",
            start_time="2026-03-21T14:00:00+00:00",
            calendar_event_id="gcal-abc123",
            end_time="2026-03-21T15:00:00+00:00",
            attendees=[{"email": "sarah@acme.com"}],
            mind_id="mind-1",
            match_confidence="confident",
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["meeting_log_id"] == "meeting-uuid-2"
        assert result["is_new"] is False
        # Check that ON CONFLICT is used in the SQL
        sql_arg = mock_db.execute_returning.call_args[0][0]
        assert "ON CONFLICT" in sql_arg

    def test_empty_title_rejected(self, mock_db):
        result = _log_meeting_event(
            title="",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_whitespace_only_title_rejected(self, mock_db):
        result = _log_meeting_event(
            title="   ",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True

    def test_long_title_rejected(self, mock_db):
        result = _log_meeting_event(
            title="x" * (MAX_TITLE_CHARS + 1),
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert "500" in result["message"]

    def test_bad_start_time_rejected(self, mock_db):
        result = _log_meeting_event(
            title="Meeting",
            start_time="not-a-date",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert "start_time" in result["message"]

    def test_naive_start_time_rejected(self, mock_db):
        """Naive datetimes (no timezone) must be rejected."""
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert "timezone" in result["message"]

    def test_naive_end_time_rejected(self, mock_db):
        """Naive end_time (no timezone) must be rejected."""
        mock_db.fetch_one.return_value = (1,)  # table exists
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time="2026-03-21T11:00:00",
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert "timezone" in result["message"]

    def test_bad_end_time_rejected(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time="not-a-date",
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert "end_time" in result["message"]

    def test_invalid_match_confidence_rejected(self, mock_db):
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence="invalid",
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert "match_confidence" in result["message"]

    def test_default_confidence_is_none(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = ("uuid-1", True)
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["match_confidence"] == "none"

    def test_no_table_returns_migration_error(self, mock_db):
        mock_db.fetch_one.return_value = None  # table does not exist
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"

    def test_failed_insert_returns_internal_error(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = None
        result = _log_meeting_event(
            title="Meeting",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["error"] is True
        assert result["code"] == "INTERNAL_ERROR"

    def test_title_stripped(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        mock_db.execute_returning.return_value = ("uuid-1", True)
        result = _log_meeting_event(
            title="  Padded Title  ",
            start_time="2026-03-21T10:00:00+00:00",
            calendar_event_id=None,
            end_time=None,
            attendees=None,
            mind_id=None,
            match_confidence=None,
            db=mock_db,
            customer_id=CUSTOMER_ID,
        )
        assert result["title"] == "Padded Title"


# ---------------------------------------------------------------------------
# get_cross_client_summary
# ---------------------------------------------------------------------------

class TestGetCrossClientSummary:
    def test_returns_summaries_for_multiple_minds(self, mock_db):
        mock_db.fetch_all.side_effect = [
            # minds
            [("mind-1", "Acme"), ("mind-2", "Bluebell")],
            # bulk memory stats (mind_id, open_commitments, recent, last_activity)
            [("mind-1", 3, 5, _dt(20)), ("mind-2", 1, 0, None)],
            # bulk today's meetings (mind_id, id, title, start_time, followup_sent)
            [("mind-1", "ml-1", "Sync", _dt(21), False)],
        ]
        mock_db.fetch_one.side_effect = [
            (1,),  # meeting_log table exists
        ]

        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert result["client_count"] == 2
        assert len(result["summaries"]) == 2
        # Sorted by urgency: Acme has 3 commitments, Bluebell has 1
        assert result["summaries"][0]["mind_name"] == "Acme"
        assert result["summaries"][0]["open_commitments"] == 3
        assert result["summaries"][0]["recent_memories"] == 5
        assert len(result["summaries"][0]["todays_meetings"]) == 1

    def test_no_minds_returns_message(self, mock_db):
        mock_db.fetch_all.return_value = []
        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert result["summaries"] == []
        assert "No active" in result["message"]

    def test_no_meeting_log_table_skips_meetings(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],  # minds
            # bulk memory stats
            [("mind-1", 2, 1, _dt(19))],
        ]
        mock_db.fetch_one.side_effect = [
            None,  # table does NOT exist
        ]

        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert result["summaries"][0]["todays_meetings"] == []

    def test_lookback_minimum_is_1(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],
            # bulk memory stats — empty (no memories)
            [],
        ]
        mock_db.fetch_one.side_effect = [
            None,  # no meeting_log table
        ]
        result = _get_cross_client_summary(0, mock_db, CUSTOMER_ID)
        assert result["lookback_hours"] == 1

    def test_last_activity_none_handled(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "NewClient")],
            # bulk memory stats — no rows for this mind (no memories at all)
            [],
        ]
        mock_db.fetch_one.side_effect = [
            None,  # no meeting_log
        ]
        result = _get_cross_client_summary(48, mock_db, CUSTOMER_ID)
        assert result["summaries"][0]["last_activity"] is None


# ---------------------------------------------------------------------------
# get_meeting_context
# ---------------------------------------------------------------------------

class TestGetMeetingContext:
    def test_with_active_mind(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = [
            ("mem-1", "Decision content", "Decision summary", "decision", _dt(21)),
        ]
        mock_db.fetch_one.side_effect = [
            ("brief-1", "# Brief", _dt(20)),  # brief query
            None,  # _has_meeting_log_table -> no table
        ]

        result = _get_meeting_context(
            meeting_log_id=None,
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["mind_id"] == "test-mind-uuid"
        assert result["memory_count"] == 1
        assert result["brief"]["brief_id"] == "brief-1"
        assert result["meeting_entry"] is None

    def test_explicit_mind_id_overrides_active(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        mock_db.fetch_one.side_effect = [
            None,  # brief query -> no brief
            None,  # _has_meeting_log_table -> no table
        ]

        result = _get_meeting_context(
            meeting_log_id=None,
            mind_id="explicit-mind",
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["mind_id"] == "explicit-mind"

    def test_no_mind_returns_error(self, mock_db):
        result = _get_meeting_context(
            meeting_log_id=None,
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=None,
        )
        assert result["error"] is True
        assert result["code"] == "NO_ACTIVE_MIND"

    def test_with_meeting_log_id(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []  # no recent memories
        mock_db.fetch_one.side_effect = [
            None,  # brief query -> no brief
            (1,),  # _has_meeting_log_table -> exists
            # meeting_log entry
            ("ml-1", "Team Sync", _dt(21, 10), _dt(21, 11),
             json.dumps([{"email": "test@acme.com"}]),
             "confident", False, False),
        ]

        result = _get_meeting_context(
            meeting_log_id="ml-1",
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["meeting_entry"]["meeting_log_id"] == "ml-1"
        assert result["meeting_entry"]["title"] == "Team Sync"
        assert result["meeting_entry"]["attendees"] == [{"email": "test@acme.com"}]

    def test_hours_ago_minimum_is_1(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        mock_db.fetch_one.side_effect = [
            None,  # brief query -> no brief
            None,  # _has_meeting_log_table -> no table
        ]
        result = _get_meeting_context(
            meeting_log_id=None,
            mind_id=None,
            hours_ago=0,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["hours_ago"] == 1

    def test_memories_query_includes_customer_id_filter(self, mock_db, active_mind):
        """The memories query must filter by customer_id to enforce tenant isolation."""
        mock_db.fetch_all.return_value = []
        mock_db.fetch_one.side_effect = [
            None,  # brief query -> no brief
            None,  # _has_meeting_log_table -> no table
        ]
        _get_meeting_context(
            meeting_log_id=None,
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        # The memories query is the first fetch_all call
        memories_query = mock_db.fetch_all.call_args_list[0]
        sql = memories_query[0][0]
        params = memories_query[0][1]
        assert "customer_id" in sql, "memories query must include customer_id subquery"
        assert CUSTOMER_ID in params, "customer_id must be in query params"

    def test_no_brief_returns_none(self, mock_db, active_mind):
        mock_db.fetch_all.return_value = []
        mock_db.fetch_one.side_effect = [
            None,  # brief query -> no brief
            None,  # _has_meeting_log_table -> no table
        ]
        result = _get_meeting_context(
            meeting_log_id=None,
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["brief"] is None

    def test_meeting_log_attendees_as_list(self, mock_db, active_mind):
        """When attendees is already a list (not a string), handle it gracefully."""
        mock_db.fetch_all.return_value = []
        mock_db.fetch_one.side_effect = [
            None,  # brief query -> no brief
            (1,),  # _has_meeting_log_table -> exists
            ("ml-1", "Sync", _dt(21), None, [{"email": "a@b.com"}], "confident", True, True),
        ]
        result = _get_meeting_context(
            meeting_log_id="ml-1",
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["meeting_entry"]["attendees"] == [{"email": "a@b.com"}]
        assert result["meeting_entry"]["transcript_ingested"] is True
        assert result["meeting_entry"]["followup_sent"] is True

    def test_meeting_log_attendees_invalid_json(self, mock_db, active_mind):
        """When attendees is a string with invalid JSON, default to empty list."""
        mock_db.fetch_all.return_value = []
        mock_db.fetch_one.side_effect = [
            None,  # brief query -> no brief
            (1,),  # _has_meeting_log_table -> exists
            ("ml-1", "Sync", _dt(21), None, "not-valid-json{{{",
             "confident", False, False),
        ]
        result = _get_meeting_context(
            meeting_log_id="ml-1",
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["meeting_entry"]["attendees"] == []

    @patch("coppermind_cmo.tools.minds._verify_mind_access", return_value=False)
    def test_access_denied_when_verify_fails(self, mock_verify, mock_db, active_mind):
        """get_meeting_context wrapper returns ACCESS_DENIED when _verify_mind_access fails.

        The register() wrapper resolves mind_id and calls _verify_mind_access
        before delegating to _get_meeting_context. This test exercises that
        same guard pattern directly.
        """
        from coppermind_cmo.errors import ACCESS_DENIED

        # Simulate what the registered wrapper does:
        resolved_mind_id = active_mind[0]
        if not mock_verify(resolved_mind_id, CUSTOMER_ID, mock_db):
            result = ACCESS_DENIED()
        else:
            result = _get_meeting_context(
                None, None, 6, mock_db, CUSTOMER_ID, active_mind,
            )

        assert result["error"] is True
        assert result["code"] == "ACCESS_DENIED"
        mock_verify.assert_called_once_with(
            "test-mind-uuid", CUSTOMER_ID, mock_db,
        )


# ---------------------------------------------------------------------------
# mark_followup_sent
# ---------------------------------------------------------------------------

class TestMarkFollowupSent:
    def test_success(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = ("ml-1",)
        result = _mark_followup_sent("ml-1", mock_db, CUSTOMER_ID)
        assert result["followup_sent"] is True
        assert result["meeting_log_id"] == "ml-1"

    def test_empty_id_rejected(self, mock_db):
        result = _mark_followup_sent("", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_whitespace_only_id_rejected(self, mock_db):
        result = _mark_followup_sent("  ", mock_db, CUSTOMER_ID)
        assert result["error"] is True

    def test_not_found(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = None
        result = _mark_followup_sent("nonexistent-id", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert result["code"] == "NOT_FOUND"

    def test_wrong_customer(self, mock_db):
        """Customer isolation: meeting belongs to different customer."""
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = None  # no match because customer_id filter
        result = _mark_followup_sent("ml-1", mock_db, "wrong-customer")
        assert result["error"] is True
        assert result["code"] == "NOT_FOUND"

    def test_no_table_returns_migration_error(self, mock_db):
        mock_db.fetch_one.return_value = None  # table doesn't exist
        result = _mark_followup_sent("ml-1", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"


# ---------------------------------------------------------------------------
# mark_transcript_ingested
# ---------------------------------------------------------------------------

class TestMarkTranscriptIngested:
    def test_mark_transcript_ingested_success(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = ("ml-1",)
        result = _mark_transcript_ingested("ml-1", mock_db, CUSTOMER_ID)
        assert result["transcript_ingested"] is True
        assert result["meeting_log_id"] == "ml-1"
        # Verify the SQL updates transcript_ingested
        sql_arg = mock_db.execute_returning.call_args[0][0]
        assert "transcript_ingested = true" in sql_arg

    def test_mark_transcript_ingested_not_found(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = None
        result = _mark_transcript_ingested("nonexistent-id", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert result["code"] == "NOT_FOUND"

    def test_mark_transcript_ingested_empty_id(self, mock_db):
        result = _mark_transcript_ingested("", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_whitespace_only_id_rejected(self, mock_db):
        result = _mark_transcript_ingested("  ", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert result["code"] == "INVALID_INPUT"

    def test_wrong_customer(self, mock_db):
        """Customer isolation: meeting belongs to different customer."""
        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.execute_returning.return_value = None  # no match because customer_id filter
        result = _mark_transcript_ingested("ml-1", mock_db, "wrong-customer")
        assert result["error"] is True
        assert result["code"] == "NOT_FOUND"

    def test_no_table_returns_migration_error(self, mock_db):
        mock_db.fetch_one.return_value = None  # table doesn't exist
        result = _mark_transcript_ingested("ml-1", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert result["code"] == "MIGRATION_REQUIRED"


# ---------------------------------------------------------------------------
# get_weekly_summary
# ---------------------------------------------------------------------------

class TestGetWeeklySummary:
    def test_default_date_range(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],  # minds
            # bulk memories by type (mind_id, memory_type, count)
            [("mind-1", "decision", 3), ("mind-1", "commitment", 2)],
            # bulk open commitments (mind_id, count)
            [("mind-1", 5)],
        ]
        mock_db.fetch_one.side_effect = [
            None,  # no meeting_log table
        ]

        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert "week_start" in result
        assert "week_end" in result
        assert result["client_count"] == 1
        assert result["summaries"][0]["mind_name"] == "Acme"
        assert result["summaries"][0]["memories_by_type"] == {"decision": 3, "commitment": 2}
        assert result["summaries"][0]["open_commitments"] == 5

    def test_explicit_date_range(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],
            [],  # no memories this week
            [],  # no commitments
        ]
        mock_db.fetch_one.side_effect = [
            None,  # no meeting_log
        ]

        result = _get_weekly_summary(
            "2026-03-16", "2026-03-20", mock_db, CUSTOMER_ID,
        )
        assert result["week_start"] == "2026-03-16"
        assert result["week_end"] == "2026-03-20"

    def test_invalid_week_start(self, mock_db):
        result = _get_weekly_summary("bad-date", None, mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert "week_start" in result["message"]

    def test_invalid_week_end(self, mock_db):
        result = _get_weekly_summary(None, "bad-date", mock_db, CUSTOMER_ID)
        assert result["error"] is True
        assert "week_end" in result["message"]

    def test_no_minds_returns_message(self, mock_db):
        mock_db.fetch_all.return_value = []
        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert result["summaries"] == []
        assert "No active" in result["message"]

    def test_with_meeting_log(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],  # minds
            # bulk meeting stats (mind_id, count, followup_sent, followup_pending)
            [("mind-1", 3, 2, 1)],
            # bulk memories by type
            [("mind-1", "decision", 2)],
            # bulk open commitments
            [("mind-1", 1)],
        ]
        mock_db.fetch_one.side_effect = [
            (1,),  # meeting_log table exists
        ]

        result = _get_weekly_summary(
            "2026-03-16", "2026-03-20", mock_db, CUSTOMER_ID,
        )
        assert result["summaries"][0]["meetings_held"] == 3
        assert result["summaries"][0]["followups_sent"] == 2
        assert result["summaries"][0]["followups_pending"] == 1

    def test_no_meeting_log_table_skips_meeting_data(self, mock_db):
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],
            [],  # no memories
            [],  # no commitments
        ]
        mock_db.fetch_one.side_effect = [
            None,  # no meeting_log table
        ]

        result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert result["summaries"][0]["meetings_held"] == 0
        assert result["summaries"][0]["followups_sent"] == 0

    def test_weekend_defaults_to_current_workweek(self, mock_db):
        """On Saturday/Sunday, default window should be Mon-Fri of the week just ended."""
        mock_db.fetch_all.side_effect = [
            [("mind-1", "Acme")],
            [],  # memories
            [],  # commitments
        ]
        mock_db.fetch_one.side_effect = [None]  # no meeting_log

        from unittest.mock import patch
        # Saturday March 28, 2026
        fake_saturday = date(2026, 3, 28)
        with patch("coppermind_cmo.tools.daily_loop.date") as mock_date:
            mock_date.today.return_value = fake_saturday
            mock_date.fromisoformat = date.fromisoformat
            result = _get_weekly_summary(None, None, mock_db, CUSTOMER_ID)
        assert result["week_start"] == "2026-03-23"  # Monday
        assert result["week_end"] == "2026-03-27"    # Friday (not April 3!)


# ---------------------------------------------------------------------------
# get_daily_loop_notifications
# ---------------------------------------------------------------------------

class TestGetDailyLoopNotifications:
    def test_no_table_returns_empty(self, mock_db):
        mock_db.fetch_one.return_value = None  # no table
        result = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        assert result == []

    def test_followup_nag(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        five_hours_ago = datetime.now(timezone.utc) - timedelta(hours=5)
        mock_db.fetch_all.side_effect = [
            # nag_rows: meetings >4h old without followup
            [("ml-1", "Old Meeting", five_hours_ago)],
            # ingest_rows
            [],
        ]

        result = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        nag = [n for n in result if n["type"] == "followup_nag"]
        assert len(nag) == 1
        assert nag[0]["meeting_log_id"] == "ml-1"
        assert "follow-up" in nag[0]["message"].lower()

    def test_ingest_suggestion(self, mock_db):
        mock_db.fetch_one.return_value = (1,)  # table exists
        two_hours_ago = datetime.now(timezone.utc) - timedelta(hours=2)
        mock_db.fetch_all.side_effect = [
            [],  # no nag_rows
            [("ml-2", "Recent Meeting", two_hours_ago)],  # ingest suggestion
        ]

        result = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        ingest = [n for n in result if n["type"] == "ingest_suggestion"]
        assert len(ingest) == 1
        assert "transcript" in ingest[0]["message"].lower()

    @patch("coppermind_cmo.tools.daily_loop.datetime")
    def test_friday_weekly_reminder(self, mock_datetime, mock_db):
        # Simulate Friday at 4pm
        friday_4pm = datetime(2026, 3, 20, 16, 0, 0, tzinfo=timezone.utc)
        mock_datetime.now.return_value = friday_4pm
        mock_datetime.side_effect = lambda *a, **kw: datetime(*a, **kw)

        mock_db.fetch_one.return_value = (1,)  # table exists
        mock_db.fetch_all.side_effect = [
            [],  # no nag
            [],  # no ingest
        ]

        result = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        weekly = [n for n in result if n["type"] == "weekly_review_reminder"]
        assert len(weekly) == 1
        assert "weekly review" in weekly[0]["message"].lower()

    def test_session_dedup_followup_nag(self, mock_db):
        """Same meeting should not trigger nag twice in same session."""
        mock_db.fetch_one.return_value = (1,)  # table exists
        five_hours_ago = datetime.now(timezone.utc) - timedelta(hours=5)
        nag_rows = [("ml-1", "Meeting", five_hours_ago)]
        mock_db.fetch_all.side_effect = [
            nag_rows,  # first call nag
            [],         # first call ingest
            nag_rows,  # second call nag
            [],         # second call ingest
        ]

        result1 = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        result2 = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        nags1 = [n for n in result1 if n["type"] == "followup_nag"]
        nags2 = [n for n in result2 if n["type"] == "followup_nag"]
        assert len(nags1) == 1
        assert len(nags2) == 0  # deduped

    def test_session_dedup_ingest_suggestion(self, mock_db):
        mock_db.fetch_one.return_value = (1,)
        two_hours_ago = datetime.now(timezone.utc) - timedelta(hours=2)
        ingest_rows = [("ml-2", "Meeting", two_hours_ago)]
        mock_db.fetch_all.side_effect = [
            [],           # call 1 nag
            ingest_rows,  # call 1 ingest
            [],           # call 2 nag
            ingest_rows,  # call 2 ingest
        ]
        r1 = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        r2 = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        assert len([n for n in r1 if n["type"] == "ingest_suggestion"]) == 1
        assert len([n for n in r2 if n["type"] == "ingest_suggestion"]) == 0

    @patch("coppermind_cmo.tools.daily_loop.datetime")
    def test_friday_dedup_by_week(self, mock_datetime, mock_db):
        """Friday reminder should only fire once per week."""
        friday_4pm = datetime(2026, 3, 20, 16, 0, 0, tzinfo=timezone.utc)
        mock_datetime.now.return_value = friday_4pm
        mock_datetime.side_effect = lambda *a, **kw: datetime(*a, **kw)

        mock_db.fetch_one.return_value = (1,)
        mock_db.fetch_all.side_effect = [
            [], [],  # first call
            [], [],  # second call
        ]

        r1 = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        r2 = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        weekly1 = [n for n in r1 if n["type"] == "weekly_review_reminder"]
        weekly2 = [n for n in r2 if n["type"] == "weekly_review_reminder"]
        assert len(weekly1) == 1
        assert len(weekly2) == 0

    def test_nag_row_with_none_start_time(self, mock_db):
        """Graceful handling when start_time is None."""
        mock_db.fetch_one.return_value = (1,)
        mock_db.fetch_all.side_effect = [
            [("ml-1", "Meeting", None)],  # nag with None start_time
            [],
        ]
        result = get_daily_loop_notifications(mock_db, CUSTOMER_ID)
        nag = [n for n in result if n["type"] == "followup_nag"]
        assert len(nag) == 1
        assert nag[0]["hours_ago"] == 0


# ---------------------------------------------------------------------------
# Notification state persistence
# ---------------------------------------------------------------------------

class TestNotificationStatePersistence:
    def test_state_persists_across_reloads(self, tmp_path, monkeypatch):
        """Notification state survives cache reset (simulates process restart)."""
        state_file = tmp_path / "notification-state.json"
        monkeypatch.setattr(daily_loop_mod, "_NOTIFICATION_STATE_FILE", state_file)
        daily_loop_mod._notification_state = None

        _mark_notified("test-key-1")
        assert _already_notified("test-key-1") is True

        # Simulate process restart: clear in-memory cache
        daily_loop_mod._notification_state = None
        assert _already_notified("test-key-1") is True
        assert state_file.exists()

    def test_seven_day_pruning(self, tmp_path, monkeypatch):
        """Entries older than 7 days are pruned on save."""
        state_file = tmp_path / "notification-state.json"
        monkeypatch.setattr(daily_loop_mod, "_NOTIFICATION_STATE_FILE", state_file)
        daily_loop_mod._notification_state = None

        # Write an old entry directly
        old_ts = (datetime.now(timezone.utc) - timedelta(days=8)).isoformat()
        recent_ts = datetime.now(timezone.utc).isoformat()
        daily_loop_mod._notification_state = {
            "old-key": old_ts,
            "recent-key": recent_ts,
        }
        _save_notification_state()

        # Reload and verify old entry was pruned
        daily_loop_mod._notification_state = None
        state = _load_notification_state()
        assert "old-key" not in state
        assert "recent-key" in state

    def test_corrupt_file_handled_gracefully(self, tmp_path, monkeypatch):
        """Corrupt JSON state file doesn't crash — starts fresh."""
        state_file = tmp_path / "notification-state.json"
        state_file.write_text("not valid json{{{")
        monkeypatch.setattr(daily_loop_mod, "_NOTIFICATION_STATE_FILE", state_file)
        daily_loop_mod._notification_state = None

        state = _load_notification_state()
        assert state == {}

    def test_missing_file_returns_empty(self, tmp_path, monkeypatch):
        """Missing state file returns empty dict."""
        state_file = tmp_path / "notification-state.json"
        monkeypatch.setattr(daily_loop_mod, "_NOTIFICATION_STATE_FILE", state_file)
        daily_loop_mod._notification_state = None

        assert not state_file.exists()
        state = _load_notification_state()
        assert state == {}

    def test_mark_and_check_round_trip(self, tmp_path, monkeypatch):
        """mark_notified + already_notified work together."""
        state_file = tmp_path / "notification-state.json"
        monkeypatch.setattr(daily_loop_mod, "_NOTIFICATION_STATE_FILE", state_file)
        daily_loop_mod._notification_state = None

        assert _already_notified("key-abc") is False
        _mark_notified("key-abc")
        assert _already_notified("key-abc") is True


# ---------------------------------------------------------------------------
# Registration smoke test
# ---------------------------------------------------------------------------
# _has_meeting_log_table exception handling (QW8)
# ---------------------------------------------------------------------------

class TestHasMeetingLogException:
    def test_exception_returns_false(self, mock_db):
        """DB exception in _has_meeting_log_table returns False gracefully."""
        mock_db.fetch_one.side_effect = Exception("connection lost")
        assert _has_meeting_log_table(mock_db) is False


# ---------------------------------------------------------------------------
# get_meeting_context graceful degradation (QW9)
# ---------------------------------------------------------------------------

class TestGetMeetingContextGracefulDegradation:
    def test_missing_meeting_briefs_table(self, mock_db, active_mind):
        """When meeting_briefs table doesn't exist, brief is None (not error)."""
        mock_db.fetch_all.return_value = []  # no recent memories
        mock_db.fetch_one.side_effect = [
            Exception("relation \"meeting_briefs\" does not exist"),  # brief query fails
            None,  # _has_meeting_log_table -> no table
        ]

        result = _get_meeting_context(
            meeting_log_id=None,
            mind_id=None,
            hours_ago=6,
            db=mock_db,
            customer_id=CUSTOMER_ID,
            active_mind=active_mind,
        )
        assert result["brief"] is None
        assert result["memory_count"] == 0
        assert "error" not in result


# ---------------------------------------------------------------------------
# _attach_all_notifications (QW1)
# ---------------------------------------------------------------------------

class TestAttachAllNotifications:
    def test_merges_daily_loop_notifications(self, mock_db):
        """Daily loop notifications are merged into tool result."""
        mock_db.fetch_one.return_value = (1,)  # table exists
        five_hours_ago = datetime.now(timezone.utc) - timedelta(hours=5)
        mock_db.fetch_all.side_effect = [
            [("ml-1", "Old Meeting", five_hours_ago)],  # nag_rows
            [],  # ingest_rows
        ]

        result = {"some_key": "value"}
        merged = _attach_all_notifications(result, mock_db, CUSTOMER_ID)
        assert "notifications" in merged
        nags = [n for n in merged["notifications"] if n["type"] == "followup_nag"]
        assert len(nags) == 1

    def test_no_notifications_when_no_table(self, mock_db):
        """No notifications added when meeting_log table is missing."""
        mock_db.fetch_one.return_value = None  # no table
        result = {"some_key": "value"}
        merged = _attach_all_notifications(result, mock_db, CUSTOMER_ID)
        assert "notifications" not in merged

    def test_exception_does_not_break_result(self, mock_db):
        """Exception in get_daily_loop_notifications doesn't break the result."""
        mock_db.fetch_one.side_effect = Exception("db down")
        result = {"some_key": "value"}
        merged = _attach_all_notifications(result, mock_db, CUSTOMER_ID)
        assert merged["some_key"] == "value"

    def test_list_result_unchanged(self, mock_db):
        """List results pass through unchanged."""
        result = [{"some": "data"}]
        merged = _attach_all_notifications(result, mock_db, CUSTOMER_ID)
        assert merged == [{"some": "data"}]


# ---------------------------------------------------------------------------
# Registration smoke test
# ---------------------------------------------------------------------------

class TestRegistration:
    def test_register_adds_tools(self):
        """Verify register() calls mcp_server.tool() for all 6 tools."""
        mock_server = MagicMock()
        mock_server.tool.return_value = lambda f: f  # decorator passthrough

        daily_loop_mod.register(mock_server)
        assert mock_server.tool.call_count == 6
