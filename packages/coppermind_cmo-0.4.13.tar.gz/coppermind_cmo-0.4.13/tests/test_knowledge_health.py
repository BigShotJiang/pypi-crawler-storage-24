"""Tests for knowledge completeness indicator."""

import pytest
from unittest.mock import MagicMock, patch
import json
from datetime import datetime, timezone

from coppermind_cmo.tools.intelligence import _get_knowledge_health


def _make_db():
    return MagicMock()


class TestGetKnowledgeHealth:
    def test_no_active_mind(self):
        result = _get_knowledge_health(MagicMock(), None)
        assert "error" in result

    def test_brand_new_mind_all_none(self):
        db = _make_db()
        # brand DNA query
        db.fetch_one.side_effect = [
            (None, None, None, None, None),  # brand DNA
            (None,),  # cadence
            (0,),     # rock count
        ]
        db.fetch_all.return_value = []  # no memories

        with patch("coppermind_cmo.tools.daily_loop._has_meeting_log_table", return_value=False):
            result = _get_knowledge_health(db, ("mind1", "NewClient"))

        assert result["client_name"] == "NewClient"
        assert result["total_memories"] == 0
        assert all(d["status"] == "none" for d in result["dimensions"])
        assert len(result["suggestions"]) == 7  # all dimensions have suggestions

    def test_rich_mind(self):
        db = _make_db()
        bv = json.dumps({"tone": "professional", "values": ["trust", "innovation"], "examples": ["x"] * 50})
        stakeholders = json.dumps([
            {"name": "Sarah"}, {"name": "Marcus"}, {"name": "Lisa"},
            {"name": "Tom"}, {"name": "Jen"}, {"name": "Dave"},
        ])

        db.fetch_one.side_effect = [
            (bv, '{"category": "B2B"}', '{"elevator_pitch": "x"}', stakeholders, ["leadership", "products", "industry"]),
            (10, datetime(2026, 3, 20, 10, 0, 0, tzinfo=timezone.utc)),  # meeting count + last meeting
            ('{"quarter": 1, "year": 2026, "sprint": 3}',),  # cadence
            (5,),  # rock count
        ]
        db.fetch_all.return_value = [
            ("decision", 10), ("fact", 20), ("commitment", 5),
            ("campaign_outcome", 8), ("preference", 3), ("stakeholder", 4),
        ]

        with patch("coppermind_cmo.tools.daily_loop._has_meeting_log_table", return_value=True):
            result = _get_knowledge_health(db, ("mind1", "RichClient"))

        assert result["total_memories"] == 50
        assert result["overall"] == "Coppermind knows this client well."
        # Most dimensions should be rich or adequate
        rich_count = sum(1 for d in result["dimensions"] if d["status"] in ("rich", "adequate"))
        assert rich_count >= 5

    def test_sparse_brand_voice(self):
        db = _make_db()
        bv = json.dumps({"tone": ""})  # set but minimal

        db.fetch_one.side_effect = [
            (bv, None, None, None, None),
            (None,),  # cadence
            (0,),     # rocks
        ]
        db.fetch_all.return_value = [("fact", 5)]

        with patch("coppermind_cmo.tools.daily_loop._has_meeting_log_table", return_value=False):
            result = _get_knowledge_health(db, ("mind1", "SparseClient"))

        bv_dim = next(d for d in result["dimensions"] if d["area"] == "Brand Voice")
        assert bv_dim["status"] in ("sparse", "adequate")

    def test_includes_suggestions_for_gaps(self):
        db = _make_db()
        db.fetch_one.side_effect = [
            (None, None, None, None, None),
            (None,),
            (0,),
        ]
        db.fetch_all.return_value = []

        with patch("coppermind_cmo.tools.daily_loop._has_meeting_log_table", return_value=False):
            result = _get_knowledge_health(db, ("mind1", "Client"))

        assert len(result["suggestions"]) > 0
        assert all(isinstance(s, str) for s in result["suggestions"])

    def test_memory_type_distribution(self):
        db = _make_db()
        db.fetch_one.side_effect = [
            (None, None, None, None, None),
            (None,),
            (0,),
        ]
        db.fetch_all.return_value = [("fact", 10), ("decision", 5)]

        with patch("coppermind_cmo.tools.daily_loop._has_meeting_log_table", return_value=False):
            result = _get_knowledge_health(db, ("mind1", "Client"))

        assert result["memory_type_distribution"]["fact"] == 10
        assert result["memory_type_distribution"]["decision"] == 5
        assert result["total_memories"] == 15

    def test_eos_with_rocks(self):
        db = _make_db()
        cadence = json.dumps({"quarter": 2, "year": 2026, "sprint": 1})
        db.fetch_one.side_effect = [
            (None, None, None, None, None),
            (cadence,),
            (3,),  # 3 rocks
        ]
        db.fetch_all.return_value = []

        with patch("coppermind_cmo.tools.daily_loop._has_meeting_log_table", return_value=False):
            result = _get_knowledge_health(db, ("mind1", "EOSClient"))

        eos_dim = next(d for d in result["dimensions"] if d["area"] == "EOS Configuration")
        assert eos_dim["status"] == "rich"
        assert "3 rock" in eos_dim["detail"]

    def test_status_summary(self):
        db = _make_db()
        db.fetch_one.side_effect = [
            (None, None, None, None, None),
            (None,),
            (0,),
        ]
        db.fetch_all.return_value = []

        with patch("coppermind_cmo.tools.daily_loop._has_meeting_log_table", return_value=False):
            result = _get_knowledge_health(db, ("mind1", "Client"))

        assert "status_summary" in result
        assert result["status_summary"]["none"] == 7
