"""Tests for the notification provider registry in background.py."""

import pytest
from unittest.mock import MagicMock, patch


def test_register_and_call_provider():
    """Registered providers are called when customer_id and db are passed."""
    from coppermind_cmo import background

    # Save and reset state
    original = background._notification_providers[:]
    background._notification_providers.clear()

    try:
        mock_provider = MagicMock(return_value=[{"type": "test", "message": "hello"}])
        background.register_notification_provider(mock_provider)

        result = {}
        background.attach_notifications(result, session_id="s1", customer_id="c1", db="fake_db")

        mock_provider.assert_called_once_with("fake_db", "c1")
        assert result["notifications"] == [{"type": "test", "message": "hello"}]
    finally:
        background._notification_providers[:] = original


def test_provider_not_called_without_customer_id():
    """Providers are skipped when customer_id is not passed (backward compat)."""
    from coppermind_cmo import background

    original = background._notification_providers[:]
    background._notification_providers.clear()

    try:
        mock_provider = MagicMock()
        background.register_notification_provider(mock_provider)

        result = {}
        background.attach_notifications(result, session_id="s1")

        mock_provider.assert_not_called()
    finally:
        background._notification_providers[:] = original


def test_provider_exception_does_not_break_result():
    """A failing provider is silently caught -- tool responses never break."""
    from coppermind_cmo import background

    original = background._notification_providers[:]
    background._notification_providers.clear()

    try:
        def bad_provider(db, customer_id):
            raise RuntimeError("boom")

        background.register_notification_provider(bad_provider)

        result = {"status": "ok"}
        returned = background.attach_notifications(result, session_id="s1", customer_id="c1", db="db")

        assert returned["status"] == "ok"
        assert "notifications" not in returned or returned["notifications"] == []
    finally:
        background._notification_providers[:] = original


def test_providers_merge_with_background_notifications():
    """Provider notifications merge with background ingestion notifications."""
    from coppermind_cmo import background

    original = background._notification_providers[:]
    background._notification_providers.clear()

    try:
        mock_provider = MagicMock(return_value=[{"type": "nag", "message": "follow up"}])
        background.register_notification_provider(mock_provider)

        # Pre-seed a background notification
        result = {"notifications": [{"type": "bg", "message": "ingestion done"}]}
        background.attach_notifications(result, session_id="s1", customer_id="c1", db="db")

        assert len(result["notifications"]) == 2
        assert result["notifications"][0]["type"] == "bg"
        assert result["notifications"][1]["type"] == "nag"
    finally:
        background._notification_providers[:] = original


def test_list_result_unchanged():
    """List results are returned unchanged (same as current behavior)."""
    from coppermind_cmo import background

    result = [{"item": 1}]
    returned = background.attach_notifications(result, session_id="s1", customer_id="c1", db="db")
    assert returned == [{"item": 1}]
