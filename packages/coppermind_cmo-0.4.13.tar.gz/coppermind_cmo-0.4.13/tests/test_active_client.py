"""Tests for active client state file and terminal title."""

import json
import os
import subprocess
import sys
from unittest.mock import patch, MagicMock

import pytest

from coppermind_cmo.active_client import (
    update_active_client, clear_active_client, _STATE_FILE, _STATE_DIR,
    _format_cadence,
)


@pytest.fixture(autouse=True)
def clean_state_file():
    """Remove state file before and after each test."""
    try:
        os.unlink(_STATE_FILE)
    except OSError:
        pass
    yield
    try:
        os.unlink(_STATE_FILE)
    except OSError:
        pass


class TestUpdateActiveClient:
    def test_writes_json_file(self):
        update_active_client("Acme Corp", "uuid-1", 23, {"quarter": 1, "sprint": 4, "sprints_per_quarter": 6})
        assert os.path.isfile(_STATE_FILE)
        with open(_STATE_FILE) as f:
            data = json.load(f)
        assert data["client_name"] == "Acme Corp"
        assert data["mind_id"] == "uuid-1"
        assert data["memory_count"] == 23
        assert "Q1" in data["cadence"]
        assert "Sprint 4 of 6" in data["cadence"]
        assert data["updated_at"] is not None

    def test_writes_without_cadence(self):
        update_active_client("Simple Client", "uuid-2", 5)
        with open(_STATE_FILE) as f:
            data = json.load(f)
        assert data["client_name"] == "Simple Client"
        assert data["cadence"] == ""

    def test_creates_directory(self):
        """~/.coppermind/ is created if it doesn't exist."""
        # Directory should already exist from prior tests or the call itself
        update_active_client("Test", "uuid-3", 0)
        assert os.path.isdir(_STATE_DIR)

    def test_atomic_write_no_partial(self):
        """After update, the file contains valid JSON (atomic write)."""
        update_active_client("First", "uuid-4", 10)
        update_active_client("Second", "uuid-5", 20)
        with open(_STATE_FILE) as f:
            data = json.load(f)
        assert data["client_name"] == "Second"

    def test_emits_terminal_title_to_stderr(self):
        """ANSI escape sequence for terminal title is written to stderr."""
        with patch("sys.stderr") as mock_stderr:
            update_active_client("Acme", "uuid-6", 5)
            written = "".join(call.args[0] for call in mock_stderr.write.call_args_list)
            assert "\033]0;" in written
            assert "Acme" in written
            assert "\007" in written

    def test_terminal_title_includes_cadence(self):
        with patch("sys.stderr") as mock_stderr:
            update_active_client("Acme", "uuid-7", 5, {"quarter": 2, "sprint": 3, "sprints_per_quarter": 6})
            written = "".join(call.args[0] for call in mock_stderr.write.call_args_list)
            assert "Q2 Sprint 3 of 6" in written


class TestUpdateActiveClientBrandColor:
    def test_writes_brand_color_to_state_file(self):
        update_active_client("Acme Corp", "uuid-color", 15, brand_color="#FF5733")
        assert os.path.isfile(_STATE_FILE)
        with open(_STATE_FILE) as f:
            data = json.load(f)
        assert data["brand_color"] == "#FF5733"

    def test_omits_brand_color_when_none(self):
        update_active_client("Acme Corp", "uuid-no-color", 10)
        with open(_STATE_FILE) as f:
            data = json.load(f)
        assert "brand_color" not in data

    def test_omits_brand_color_when_empty_string(self):
        update_active_client("Acme Corp", "uuid-empty", 10, brand_color="")
        with open(_STATE_FILE) as f:
            data = json.load(f)
        assert "brand_color" not in data


class TestClearActiveClient:
    def test_deletes_file(self):
        update_active_client("Acme", "uuid-8", 10)
        assert os.path.isfile(_STATE_FILE)
        clear_active_client()
        assert not os.path.isfile(_STATE_FILE)

    def test_noop_when_no_file(self):
        """Should not raise when file doesn't exist."""
        clear_active_client()


class TestFormatCadence:
    def test_full_cadence(self):
        assert _format_cadence({"quarter": 1, "sprint": 4, "sprints_per_quarter": 6}) == "Q1 Sprint 4 of 6"

    def test_quarter_only(self):
        assert _format_cadence({"quarter": 2}) == "Q2"

    def test_empty(self):
        assert _format_cadence({}) == ""

    def test_none(self):
        assert _format_cadence(None) == ""


class TestStatusLineScript:
    @pytest.mark.skipif(sys.platform == "win32", reason="bash not available on Windows")
    def test_outputs_client_info_when_file_exists(self):
        update_active_client("Acme Corp", "uuid-9", 11, {"quarter": 1, "sprint": 6, "sprints_per_quarter": 6})
        script = os.path.join(os.path.dirname(__file__), "..", "src", "coppermind_cmo", "statusline.sh")
        result = subprocess.run(["bash", script], capture_output=True, text=True)
        assert "Acme Corp" in result.stdout
        assert "11 memories" in result.stdout

    @pytest.mark.skipif(sys.platform == "win32", reason="bash not available on Windows")
    def test_no_output_when_file_missing(self):
        clear_active_client()
        script = os.path.join(os.path.dirname(__file__), "..", "src", "coppermind_cmo", "statusline.sh")
        result = subprocess.run(["bash", script], capture_output=True, text=True)
        assert result.stdout.strip() == ""


class TestStatusLineModule:
    """Cross-platform statusline tests using the statusline module directly."""

    def test_outputs_client_info(self):
        update_active_client("Acme Corp", "uuid-10", 23, {"quarter": 1, "sprint": 4, "sprints_per_quarter": 6})
        from coppermind_cmo.statusline import main as statusline_main
        from io import StringIO
        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            statusline_main()
        output = mock_stdout.getvalue()
        assert "Acme Corp" in output
        assert "23 memories" in output
        assert "Q1 Sprint 4 of 6" in output

    def test_no_output_when_file_missing(self):
        clear_active_client()
        from coppermind_cmo.statusline import main as statusline_main
        from io import StringIO
        with patch("sys.stdout", new_callable=StringIO) as mock_stdout:
            statusline_main()
        assert mock_stdout.getvalue().strip() == ""


class TestPlatformPaths:
    """Verify platform-safe path patterns."""

    def test_state_dir_uses_expanduser(self):
        """_STATE_DIR should use os.path.expanduser, not hardcoded ~/."""
        from coppermind_cmo.active_client import _STATE_DIR
        assert "~" not in _STATE_DIR  # should be expanded
        assert os.path.isabs(_STATE_DIR)

    def test_subprocess_uses_sys_executable_in_source(self):
        """Watcher subprocess source code should use sys.executable, not 'python3'."""
        import coppermind_cmo.server
        server_path = coppermind_cmo.server.__file__
        with open(server_path) as f:
            source = f.read()
        assert "sys.executable" in source
        assert "'python3'" not in source


# ---------------------------------------------------------------------------
# Additional coverage for active_client.py edge cases
# ---------------------------------------------------------------------------

class TestFormatCadenceSprintOnly:
    def test_sprint_only_no_quarter(self):
        """Cadence with sprint but no quarter returns 'Sprint 4'."""
        result = _format_cadence({"sprint": 4})
        assert result == "Sprint 4"

    def test_sprint_with_sprints_per_quarter_no_quarter(self):
        """Sprint + sprints_per_quarter but no quarter."""
        result = _format_cadence({"sprint": 2, "sprints_per_quarter": 6})
        assert result == "Sprint 2 of 6"


class TestAtomicWriteFailure:
    def test_atomic_write_failure_no_crash(self):
        """Mock tempfile.mkstemp to raise. Verify update_active_client doesn't crash."""
        with patch("coppermind_cmo.active_client.tempfile.mkstemp", side_effect=OSError("disk full")):
            # Should not raise -- failure is caught and suppressed
            update_active_client("Acme", "uuid-fail", 5)

    def test_fdopen_failure_cleans_up(self):
        """When os.fdopen raises, temp file should be cleaned up."""
        import tempfile as _tempfile
        # Create a real temp file so we can verify cleanup attempt
        with patch("coppermind_cmo.active_client.os.fdopen", side_effect=OSError("bad fd")):
            with patch("coppermind_cmo.active_client.os.unlink") as mock_unlink:
                # Should not crash
                update_active_client("Acme", "uuid-fd-fail", 10)


class TestAnsiEscapeFailure:
    def test_ansi_escape_write_failure_no_crash(self):
        """Mock sys.stderr.write to raise. Verify no crash."""
        mock_stderr = MagicMock()
        mock_stderr.write.side_effect = OSError("broken pipe")
        mock_stderr.flush.side_effect = OSError("broken pipe")

        with patch("sys.stderr", mock_stderr):
            # Should not raise -- ANSI escape failure is caught
            update_active_client("Acme", "uuid-ansi", 3)
