from setuptools import setup
setup(name='privaton-beacon-img-2abb232fcb30a64c-png', version='774.453.539', py_modules=['data'])
