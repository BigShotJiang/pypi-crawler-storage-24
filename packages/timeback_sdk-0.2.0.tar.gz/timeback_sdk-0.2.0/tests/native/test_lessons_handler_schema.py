"""Tests for lessons handler schema validation."""

from __future__ import annotations

import json
from unittest.mock import AsyncMock

import pytest

from timeback.server.handlers.lessons.schema import (
    parse_list_payload,
    parse_start_payload,
    parse_submit_payload,
)


def _make_request(body: dict[str, object]) -> AsyncMock:
    request = AsyncMock()
    request.json = AsyncMock(return_value=body)
    return request


def _error_body(response: object) -> dict[str, object]:
    response_body = response.body
    return json.loads(response_body.decode("utf-8"))


class TestParseStartPayload:
    @pytest.mark.asyncio
    async def test_trims_lesson_id(self) -> None:
        result = await parse_start_payload(_make_request({"lessonId": "  lesson-123  "}))

        assert result.ok is True
        assert result.payload.lesson_id == "lesson-123"


class TestParseSubmitPayload:
    @pytest.mark.asyncio
    async def test_rejects_whitespace_only_response(self) -> None:
        result = await parse_submit_payload(
            _make_request(
                {
                    "lessonId": "lesson-123",
                    "questionId": "question-456",
                    "response": "   ",
                }
            )
        )

        assert result.ok is False
        assert result.response.status_code == 400
        body = _error_body(result.response)
        assert body["error"]["message"] == "Invalid payload"


class TestParseListPayload:
    @pytest.mark.asyncio
    async def test_trims_course_code_selector(self) -> None:
        result = await parse_list_payload(_make_request({"course": {"code": "  CS-101  "}}))

        assert result.ok is True
        assert result.payload.course.code == "CS-101"
