"""User verify handler tests."""

from unittest.mock import AsyncMock, patch

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.user.verify import create_user_verify_handler
from timeback.server.test_utils.handler_helpers import (
    fixture_context,
    handler_fixtures_dir,
)
from timeback.server.types import ApiCredentials, CustomIdentityConfig
from timeback.shared.types import TimebackIdentity

mock_resolve = AsyncMock()


def _setup(fixture):
    ctx = fixture_context(fixture)
    stubs = fixture.get("stubs", {})
    email = ctx.get("email", "student@example.com")
    authenticated = ctx.get("authenticated", True)

    resolve_stub = stubs.get("resolve")
    mock_resolve.reset_mock()
    mock_resolve.side_effect = None
    if isinstance(resolve_stub, dict) and "__error" in resolve_stub:
        raw = resolve_stub["__error"]
        if isinstance(raw, dict):
            from timeback.server.lib.resolve import TimebackUserResolutionError

            mock_resolve.side_effect = TimebackUserResolutionError(
                raw.get("message", "Failed"), raw.get("code", "timeback_user_lookup_failed")
            )
        elif isinstance(raw, str):
            mock_resolve.side_effect = RuntimeError(raw)
    else:
        value = resolve_stub or {}
        user_id = (
            value.get("id", "timeback-user-1") if isinstance(value, dict) else "timeback-user-1"
        )
        mock_resolve.return_value = TimebackIdentity(id=user_id, email=email)

    async def _get_email(_request):
        return email if authenticated else None

    identity = CustomIdentityConfig(get_email=_get_email)
    handler = create_user_verify_handler(
        env=ctx.get("env", "staging"),
        api=ApiCredentials(client_id="fixture-api-id", client_secret="fixture-api-secret"),
        identity=identity,
        get_client=lambda: None,
    )

    async def _handler(request):
        with patch(
            "timeback.server.handlers.user.verify.resolve_timeback_user_by_email", new=mock_resolve
        ):
            return await handler(request)

    return {"handler": _handler, "calls": []}


test_sdk_handlers_user_verify_fixtures = make_handler_fixture_test(
    name="sdk > handlers > user > verify",
    fixtures_dir=handler_fixtures_dir("user", "verify"),
    setup=_setup,
)
