"""Fixture tests for user.get-profile namespace."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_namespace_fixture_test
from timeback.server.test_utils.namespace_helpers import create_user_get_profile_setup
from timeback.server.test_utils.namespace_stub_shapes import normalize_namespace_stubs

FIXTURES_DIR = fixtures_dir("sdk", "user/get-profile")

test_sdk_user_get_profile_fixtures = make_namespace_fixture_test(
    name="sdk > user > get-profile",
    fixtures_dir=FIXTURES_DIR,
    setup=create_user_get_profile_setup(
        stub_normalizer=lambda stubs: normalize_namespace_stubs(
            stubs, oneroster_users=True, edubridge_goals=True
        )
    ),
)
