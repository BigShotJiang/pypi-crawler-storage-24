"""Fixture tests for lessons.attempt_details namespace."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_namespace_fixture_test
from timeback.server.test_utils.namespace_helpers import create_lessons_setup

FIXTURES_DIR = fixtures_dir("sdk", "lessons/attempt-details")


test_sdk_lessons_attempt_details_fixtures = make_namespace_fixture_test(
    name="sdk > lessons > attempt-details",
    fixtures_dir=FIXTURES_DIR,
    setup=create_lessons_setup("attempt_details", include_courses=True, course_ids_env="dev"),
)
