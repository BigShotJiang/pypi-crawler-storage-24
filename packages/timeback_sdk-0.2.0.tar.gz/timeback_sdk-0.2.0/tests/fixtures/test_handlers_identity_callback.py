"""Identity callback handler tests."""

from __future__ import annotations

from contextlib import ExitStack
from typing import Any
from unittest.mock import AsyncMock, patch

from starlette.responses import JSONResponse, Response

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.identity.handler import create_identity_handlers
from timeback.server.test_utils.handler_helpers import handler_fixtures_dir
from timeback.server.types import ApiCredentials, SsoIdentityConfig
from timeback.shared.types import TimebackIdentity


def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
    stubs = fixture.get("stubs", {})
    context = fixture.get("context", {})
    callback_stub = stubs.get("handleCallback", {})

    async def _get_user(_request: Any) -> TimebackIdentity:
        return TimebackIdentity(id="timeback-user-1", email="student@example.com")

    def _on_callback_success(_ctx: Any) -> Response:
        body = callback_stub.get("body", {})
        status = int(callback_stub.get("status", 200))
        return JSONResponse(body, status_code=status)

    def _on_callback_error(_ctx: Any) -> Response:
        body = callback_stub.get("body", {"error": "callback failed"})
        status = int(callback_stub.get("status", 400))
        return JSONResponse(body, status_code=status)

    identity = SsoIdentityConfig(
        client_id="fixture-client-id",
        client_secret="fixture-client-secret",
        get_user=_get_user,
        on_callback_success=_on_callback_success,
        on_callback_error=_on_callback_error,
    )
    handlers = create_identity_handlers(
        env=context.get("env", "staging"),
        identity=identity,
        api=ApiCredentials(client_id="fixture-api-id", client_secret="fixture-api-secret"),
    )

    callback_body = callback_stub.get("body", {})
    resolved_id = "timeback-user-1"
    if isinstance(callback_body, dict):
        user = callback_body.get("user", {})
        if isinstance(user, dict) and isinstance(user.get("id"), str):
            resolved_id = user["id"]

    email = context.get("email", "student@example.com")

    async def _handler(request: Any) -> Response:
        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.get_authorization_url",
                    new=AsyncMock(return_value="https://idp.example.com/authorize"),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.exchange_code",
                    new=AsyncMock(
                        return_value={"access_token": "fixture-token", "token_type": "Bearer"}
                    ),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.get_user_info",
                    new=AsyncMock(return_value={"sub": "fixture-sub", "email": email}),
                )
            )
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.resolve_timeback_user_by_email",
                    new=AsyncMock(return_value=TimebackIdentity(id=resolved_id, email=email)),
                )
            )
            return await handlers.callback(request)

    return {"handler": _handler, "calls": []}


test_sdk_handlers_identity_callback_fixtures = make_handler_fixture_test(
    name="sdk > handlers > identity > callback",
    fixtures_dir=handler_fixtures_dir("identity", "callback"),
    setup=_setup,
)
