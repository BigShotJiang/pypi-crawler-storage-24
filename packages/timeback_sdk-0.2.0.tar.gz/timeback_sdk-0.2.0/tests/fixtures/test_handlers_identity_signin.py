"""Identity sign-in handler tests."""

from __future__ import annotations

from contextlib import ExitStack
from typing import Any
from unittest.mock import AsyncMock, patch

from starlette.responses import Response

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.identity.handler import create_identity_handlers
from timeback.server.test_utils.handler_helpers import handler_fixtures_dir
from timeback.server.types import ApiCredentials, CustomIdentityConfig, SsoIdentityConfig
from timeback.shared.types import TimebackIdentity


def _setup(fixture: dict[str, Any]) -> dict[str, Any]:
    stubs = fixture.get("stubs", {})
    context = fixture.get("context", {})
    sign_in_stub = stubs.get("handleSignIn", {})

    mode = context.get("mode")
    if mode == "custom":

        async def _get_email(_request: Any) -> str | None:
            return context.get("email", "student@example.com")

        identity = CustomIdentityConfig(get_email=_get_email)
    else:

        async def _get_user(_request: Any) -> TimebackIdentity:
            return TimebackIdentity(id="timeback-user-1", email="student@example.com")

        identity = SsoIdentityConfig(
            client_id="fixture-client-id",
            client_secret="fixture-client-secret",
            get_user=_get_user,
            on_callback_success=lambda _ctx: Response(),
        )

    handlers = create_identity_handlers(
        env=context.get("env", "staging"),
        identity=identity,
        api=ApiCredentials(client_id="fixture-api-id", client_secret="fixture-api-secret"),
    )

    async def _handler(request: Any) -> Response:
        with ExitStack() as stack:
            stack.enter_context(
                patch(
                    "timeback.server.handlers.identity.handler.OIDCClient.get_authorization_url",
                    new=AsyncMock(
                        return_value=sign_in_stub.get(
                            "location", "https://idp.example.com/authorize"
                        )
                    ),
                )
            )
            return await handlers.sign_in(request)

    return {"handler": _handler, "calls": []}


test_sdk_handlers_identity_signin_fixtures = make_handler_fixture_test(
    name="sdk > handlers > identity > signin",
    fixtures_dir=handler_fixtures_dir("identity", "signin"),
    setup=_setup,
)
