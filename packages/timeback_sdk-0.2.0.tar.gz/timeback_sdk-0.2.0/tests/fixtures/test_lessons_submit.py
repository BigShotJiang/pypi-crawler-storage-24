"""Fixture tests for lessons.submit namespace."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_namespace_fixture_test
from timeback.server.test_utils.namespace_helpers import create_lessons_setup

FIXTURES_DIR = fixtures_dir("sdk", "lessons/submit")


test_sdk_lessons_submit_fixtures = make_namespace_fixture_test(
    name="sdk > lessons > submit",
    fixtures_dir=FIXTURES_DIR,
    setup=create_lessons_setup("submit", include_courses=False),
)
