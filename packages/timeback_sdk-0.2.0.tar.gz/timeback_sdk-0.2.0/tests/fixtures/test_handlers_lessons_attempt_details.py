"""Lessons attempt-details handler tests."""

from unittest.mock import AsyncMock

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.lessons.attempt_details_handler import (
    create_lesson_attempt_details_handler,
)
from timeback.server.test_utils.handler_helpers import (
    configure_mock,
    fixture_context,
    handler_fixtures_dir,
    make_handler_config,
    patched_handler,
)

mock_attempt_details = AsyncMock()


def _setup(fixture):
    ctx = fixture_context(fixture)
    configure_mock(mock_attempt_details, fixture.get("stubs", {}).get("lessons.attemptDetails"))

    timeback_id = ctx.get("timebackId", "student-1")
    mock_lookup = AsyncMock(return_value=timeback_id)

    namespace = type("NS", (), {"attempt_details": mock_attempt_details})()

    return patched_handler(
        create_lesson_attempt_details_handler,
        make_handler_config(fixture),
        patches={
            "timeback.server.handlers.lessons.attempt_details_handler.create_lessons_namespace": namespace,
            "timeback.server.handlers.lessons.auth.lookup_timeback_id_by_email": mock_lookup,
        },
    )


test_sdk_handlers_lessons_attempt_details_fixtures = make_handler_fixture_test(
    name="sdk > handlers > lessons > attempt-details",
    fixtures_dir=handler_fixtures_dir("lessons", "attempt-details"),
    setup=_setup,
)
