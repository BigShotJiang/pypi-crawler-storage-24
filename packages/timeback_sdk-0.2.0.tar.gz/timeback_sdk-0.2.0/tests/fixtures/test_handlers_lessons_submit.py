"""Lessons submit handler tests."""

from unittest.mock import AsyncMock

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.lessons.submit_handler import create_lesson_submit_handler
from timeback.server.test_utils.handler_helpers import (
    configure_mock,
    fixture_context,
    handler_fixtures_dir,
    make_handler_config,
    patched_handler,
)

mock_submit = AsyncMock()


def _setup(fixture):
    ctx = fixture_context(fixture)
    stubs = fixture.get("stubs", {})
    stub = stubs.get("lessons.submit")

    if isinstance(stub, dict) and stub.get("__throw") == "TimebackUserResolutionError":
        from timeback.server.lib.resolve import TimebackUserResolutionError

        mock_submit.reset_mock()
        mock_submit.side_effect = TimebackUserResolutionError(
            "resolution failed", "timeback_user_ambiguous"
        )
    else:
        configure_mock(mock_submit, stub)

    timeback_id = ctx.get("timebackId", "student-1")
    mock_lookup = AsyncMock(return_value=timeback_id)

    namespace = type("NS", (), {"submit": mock_submit})()

    return patched_handler(
        create_lesson_submit_handler,
        make_handler_config(fixture),
        patches={
            "timeback.server.handlers.lessons.submit_handler.create_lessons_namespace": namespace,
            "timeback.server.handlers.lessons.auth.lookup_timeback_id_by_email": mock_lookup,
        },
    )


test_sdk_handlers_lessons_submit_fixtures = make_handler_fixture_test(
    name="sdk > handlers > lessons > submit",
    fixtures_dir=handler_fixtures_dir("lessons", "submit"),
    setup=_setup,
)
