"""Lessons start handler tests."""

from unittest.mock import AsyncMock

from test_support.fixtures import make_handler_fixture_test
from timeback.server.handlers.lessons.start_handler import create_lesson_start_handler
from timeback.server.test_utils.handler_helpers import (
    configure_mock,
    fixture_context,
    handler_fixtures_dir,
    make_handler_config,
    patched_handler,
)

mock_start = AsyncMock()


def _setup(fixture):
    ctx = fixture_context(fixture)
    configure_mock(mock_start, fixture.get("stubs", {}).get("lessons.start"))

    timeback_id = ctx.get("timebackId", "student-1")
    mock_lookup = AsyncMock(return_value=timeback_id)

    namespace = type("NS", (), {"start": mock_start})()

    return patched_handler(
        create_lesson_start_handler,
        make_handler_config(fixture),
        patches={
            "timeback.server.handlers.lessons.start_handler.create_lessons_namespace": namespace,
            "timeback.server.handlers.lessons.auth.lookup_timeback_id_by_email": mock_lookup,
        },
    )


test_sdk_handlers_lessons_start_fixtures = make_handler_fixture_test(
    name="sdk > handlers > lessons > start",
    fixtures_dir=handler_fixtures_dir("lessons", "start"),
    setup=_setup,
)
