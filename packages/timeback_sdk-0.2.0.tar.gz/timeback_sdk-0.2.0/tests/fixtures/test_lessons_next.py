"""Fixture tests for lessons.next namespace."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_namespace_fixture_test
from timeback.server.test_utils.namespace_helpers import create_lessons_setup
from timeback.server.test_utils.namespace_stub_shapes import normalize_namespace_stubs

FIXTURES_DIR = fixtures_dir("sdk", "lessons/next")

test_sdk_lessons_next_fixtures = make_namespace_fixture_test(
    name="sdk > lessons > next",
    fixtures_dir=FIXTURES_DIR,
    setup=create_lessons_setup(
        "next",
        include_courses=True,
        course_ids_env="dev",
        stub_normalizer=lambda stubs: normalize_namespace_stubs(
            stubs, powerpath_question=True, powerpath_assessment_progress=True
        ),
    ),
)
