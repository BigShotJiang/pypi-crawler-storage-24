"""Timeback SDK-specific adapter around shared recording client helpers."""

from __future__ import annotations

from typing import Any

from test_support.fixtures import RecordingClient, create_recording_client


def create_sdk_recording_client(stubs: dict[str, Any] | None = None) -> RecordingClient:
    """Create a recording client for SDK namespace fixtures.

    Keeping this adapter local to the `timeback` package draws a clear boundary:
    shared fixture infrastructure stays generic, while package-specific setup lives
    next to the package fixtures.
    """
    return create_recording_client(stubs)
