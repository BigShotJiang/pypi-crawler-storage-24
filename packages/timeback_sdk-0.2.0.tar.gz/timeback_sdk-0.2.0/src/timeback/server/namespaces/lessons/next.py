"""Lessons next operation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .helpers import parse_linear_batch, to_lesson_question

if TYPE_CHECKING:
    from .types import LessonNextInput, LessonQuestion, LessonQuestionBatch, LessonsNamespaceConfig


def create_next(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons next operation."""

    async def next_question(
        input_data: LessonNextInput,
    ) -> LessonQuestion | LessonQuestionBatch:
        assessments = config["get_client"]().powerpath.assessments

        if input_data.get("lesson_type") != "powerpath-100":
            raw_progress = await assessments.get_assessment_progress(
                {"student": input_data["student"], "lesson": input_data["lesson"]}
            )
            progress = raw_progress.model_dump(by_alias=True)
            if progress.get("lessonType") == "powerpath-100":
                raise ValueError(
                    f"Expected quiz progress but got powerpath-100 for lesson {input_data['lesson']}"
                )
            return parse_linear_batch(progress)

        response = await assessments.get_next_question(
            {"student": input_data["student"], "lesson": input_data["lesson"]}
        )

        return to_lesson_question(response.question)

    return next_question
