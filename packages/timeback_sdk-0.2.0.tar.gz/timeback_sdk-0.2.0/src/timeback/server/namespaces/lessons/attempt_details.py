"""Lessons attempt details operation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .types import LessonAttemptDetailsInput, LessonsNamespaceConfig


def create_attempt_details(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons attempt details operation."""

    async def attempt_details(input_data: LessonAttemptDetailsInput) -> dict[str, Any]:
        raw_progress = await config["get_client"]().powerpath.assessments.get_assessment_progress(
            {
                "student": input_data["student"],
                "lesson": input_data["lesson"],
                "attempt": input_data["attempt"],
            }
        )
        return raw_progress.model_dump(by_alias=True)

    return attempt_details
