"""Lessons start operation."""

from __future__ import annotations

import contextlib
from typing import TYPE_CHECKING, Any

from ...lib.logger import create_scoped_logger
from .helpers import map_progress_to_start

if TYPE_CHECKING:
    from .types import LessonsNamespaceConfig, LessonStartInput, LessonStartResult

log = create_scoped_logger("lessons.start")


def create_start(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons start operation."""

    async def start(input_data: LessonStartInput) -> LessonStartResult:
        assessments = config["get_client"]().powerpath.assessments
        lesson_id = input_data["lesson"]
        student_id = input_data["student"]

        raw_progress = await assessments.get_assessment_progress(
            {"student": student_id, "lesson": lesson_id}
        )
        progress = raw_progress.model_dump(by_alias=True)

        force_new = input_data.get("force_new", False)

        if force_new:
            if (
                progress.get("lessonType") != "powerpath-100"
                and progress.get("finalized") is not True
            ):
                with contextlib.suppress(Exception):
                    await assessments.final_student_assessment_response(
                        {"student": student_id, "lesson": lesson_id}
                    )

            try:
                await assessments.create_new_attempt({"student": student_id, "lesson": lesson_id})
                raw_progress = await assessments.get_assessment_progress(
                    {"student": student_id, "lesson": lesson_id}
                )
                progress = raw_progress.model_dump(by_alias=True)
            except Exception as error:
                log.warning(
                    "Failed to create new lesson attempt",
                    extra={"lesson_id": lesson_id, "error": str(error)},
                )
        elif (
            progress.get("lessonType") != "powerpath-100"
            and progress.get("finalized") is not True
            and len(progress.get("questions", [])) == 0
        ):
            with contextlib.suppress(Exception):
                await assessments.create_new_attempt({"student": student_id, "lesson": lesson_id})
                raw_progress = await assessments.get_assessment_progress(
                    {"student": student_id, "lesson": lesson_id}
                )
                progress = raw_progress.model_dump(by_alias=True)

        return map_progress_to_start(lesson_id, progress)

    return start
