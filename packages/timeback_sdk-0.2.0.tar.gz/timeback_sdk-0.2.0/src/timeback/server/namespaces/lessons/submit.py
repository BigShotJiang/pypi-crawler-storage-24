"""Lessons submit operation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .helpers import to_lesson_submit_result

if TYPE_CHECKING:
    from .types import LessonsNamespaceConfig, LessonSubmitInput, LessonSubmitResult


def create_submit(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons submit operation."""

    async def submit(input_data: LessonSubmitInput) -> LessonSubmitResult:
        assessments = config["get_client"]().powerpath.assessments
        result = await assessments.update_student_question_response(
            {
                "student": input_data["student"],
                "lesson": input_data["lesson"],
                "question": input_data["question"],
                "responses": {"RESPONSE": input_data["response"]},
            }
        )

        return to_lesson_submit_result(result.model_dump(by_alias=True))

    return submit
