"""Lessons namespace for server-side programmatic lesson operations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .attempt_details import create_attempt_details
from .attempts import create_attempts
from .complete import create_complete
from .list import create_list
from .next import create_next
from .start import create_start
from .submit import create_submit
from .types import (
    Lesson,
    LessonAttempt,
    LessonAttemptDetailsInput,
    LessonAttemptsInput,
    LessonCompleteInput,
    LessonCompleteResult,
    LessonListInput,
    LessonNextInput,
    LessonQuestion,
    LessonQuestionBatch,
    LessonsNamespaceConfig,
    LessonStartInput,
    LessonStartResult,
    LessonSubmitInput,
    LessonSubmitResult,
)


@dataclass
class LessonsNamespace:
    """Server-side lessons namespace for programmatic lesson operations."""

    list: Any
    start: Any
    next: Any
    submit: Any
    complete: Any
    attempts: Any
    attempt_details: Any


def create_lessons_namespace(config: LessonsNamespaceConfig) -> LessonsNamespace:
    """Create the server-side lessons namespace.

    Args:
        config: Lessons namespace configuration

    Returns:
        Lessons namespace with all operations
    """
    return LessonsNamespace(
        list=create_list(config),
        start=create_start(config),
        next=create_next(config),
        submit=create_submit(config),
        complete=create_complete(config),
        attempts=create_attempts(config),
        attempt_details=create_attempt_details(config),
    )


__all__ = [
    "Lesson",
    "LessonAttempt",
    "LessonAttemptDetailsInput",
    "LessonAttemptsInput",
    "LessonCompleteInput",
    "LessonCompleteResult",
    "LessonListInput",
    "LessonNextInput",
    "LessonQuestion",
    "LessonQuestionBatch",
    "LessonStartInput",
    "LessonStartResult",
    "LessonSubmitInput",
    "LessonSubmitResult",
    "LessonsNamespace",
    "LessonsNamespaceConfig",
    "create_lessons_namespace",
]
