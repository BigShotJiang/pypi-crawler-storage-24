"""Lessons attempts operation."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .types import LessonAttempt

if TYPE_CHECKING:
    from .types import LessonAttemptsInput, LessonsNamespaceConfig


def create_attempts(config: LessonsNamespaceConfig) -> Any:
    """Create the lessons attempts operation."""

    async def attempts(input_data: LessonAttemptsInput) -> list[LessonAttempt]:
        response = await config["get_client"]().powerpath.assessments.get_attempts(
            {"student": input_data["student"], "lesson": input_data["lesson"]}
        )
        return [
            LessonAttempt(
                attempt=a.attempt,
                score=a.score,
                started_at=a.started_at,
                completed_at=a.completed_at,
                score_status=a.score_status,
            )
            for a in response.attempts
        ]

    return attempts
