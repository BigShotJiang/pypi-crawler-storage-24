"""Lessons namespace types."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, NotRequired, TypedDict

if TYPE_CHECKING:
    from collections.abc import Callable

    from timeback_core import TimebackClient

    from ...timeback import AppConfig
    from ...types import Environment


# ─────────────────────────────────────────────────────────────────────────────
# Namespace Configuration
# ─────────────────────────────────────────────────────────────────────────────


class LessonsNamespaceConfig(TypedDict):
    """Configuration for creating lessons namespace operations."""

    env: Environment
    app_config: AppConfig
    get_client: Callable[[], TimebackClient]


# ─────────────────────────────────────────────────────────────────────────────
# Inputs
# ─────────────────────────────────────────────────────────────────────────────


class LessonListInput(TypedDict, total=False):
    """Input for lessons.list()."""

    course: dict[str, Any] | None


class LessonStartInput(TypedDict):
    """Input for lessons.start()."""

    lesson: str
    student: str
    force_new: NotRequired[bool]


class LessonNextInput(TypedDict):
    """Input for lessons.next()."""

    lesson: str
    student: str
    lesson_type: NotRequired[str]


class LessonSubmitInput(TypedDict):
    """Input for lessons.submit()."""

    lesson: str
    student: str
    question: str
    response: str


class LessonCompleteInput(TypedDict):
    """Input for lessons.complete()."""

    lesson: str
    student: str


class LessonAttemptsInput(TypedDict):
    """Input for lessons.attempts()."""

    lesson: str
    student: str


class LessonAttemptDetailsInput(TypedDict):
    """Input for lessons.attempt_details()."""

    lesson: str
    student: str
    attempt: int


# ─────────────────────────────────────────────────────────────────────────────
# Outputs
# ─────────────────────────────────────────────────────────────────────────────


class Lesson(TypedDict, total=False):
    """A lesson discovered from course component resources."""

    id: str
    name: str
    type: str
    course_id: str
    question_count: int | None
    metadata: dict[str, Any]


class LessonStartResult(TypedDict, total=False):
    """Result of starting a lesson."""

    lesson_id: str
    lesson_type: str
    attempt: int
    score: float
    question_count: int
    seen_questions: int
    finalized: bool


class LessonQuestion(TypedDict, total=False):
    """A lesson question."""

    id: str
    title: str
    difficulty: str
    content: dict[str, Any] | None
    index: int
    url: str
    human_approved: bool | None
    response: str | list[str] | None
    responses: dict[str, Any] | None
    correct: bool | None
    result: dict[str, Any] | None
    result_id: str | None
    learning_objectives: list[str] | None


class LessonQuestionBatch(TypedDict, total=False):
    """A batch of questions for linear/quiz lessons."""

    questions: list[LessonQuestion]
    answered_ids: list[str]
    score: float
    finalized: bool
    complete: bool


class LessonSubmitResult(TypedDict, total=False):
    """Result of submitting a question response."""

    correct: bool
    score: float
    complete: bool
    question_result: Any


class LessonCompleteResult(TypedDict, total=False):
    """Result of completing a lesson."""

    lesson_type: str
    attempt: int
    score: float
    total_questions: int
    correct_questions: int
    accuracy: float
    finalized: bool
    finalized_by_api: bool


class LessonAttempt(TypedDict, total=False):
    """A lesson attempt record."""

    attempt: int | None
    score: float
    finalized: bool | None
    started_at: str | None
    completed_at: str | None
    score_status: str
