"""Lessons next handler."""

from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.responses import JSONResponse, Response

from ...lib.utils import error_response
from ...namespaces.lessons import create_lessons_namespace
from .auth import resolve_lesson_student_id
from .errors import to_lesson_error_response
from .schema import parse_next_payload

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request

    from .types import LessonsHandlerConfig


def create_lesson_next_handler(
    config: LessonsHandlerConfig,
) -> Callable[[Request], Awaitable[Response]]:
    """Create the lessons next HTTP handler."""
    lessons = create_lessons_namespace(config)

    async def handler(request: Request) -> Response:
        try:
            parsed = await parse_next_payload(request)
            if not parsed.ok:
                return parsed.response

            student = await resolve_lesson_student_id(config, request)
            if not student:
                return error_response("UNAUTHORIZED", "Unauthorized", 401)

            result = await lessons.next(
                {
                    "lesson": parsed.payload.lesson_id,
                    "student": student,
                    "lesson_type": parsed.payload.lesson_type,
                }
            )
            return JSONResponse(result)
        except Exception as error:
            return to_lesson_error_response(error, "Failed to fetch next lesson question")

    return handler
