"""Lessons list handler."""

from __future__ import annotations

from typing import TYPE_CHECKING

from starlette.responses import JSONResponse, Response

from ...lib.utils import error_response
from ...namespaces.lessons import create_lessons_namespace
from .auth import has_lesson_user
from .errors import to_lesson_error_response
from .schema import parse_list_payload

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from starlette.requests import Request

    from .types import LessonsHandlerConfig


def create_lesson_list_handler(
    config: LessonsHandlerConfig,
) -> Callable[[Request], Awaitable[Response]]:
    """Create the lessons list HTTP handler."""
    lessons = create_lessons_namespace(config)

    async def handler(request: Request) -> Response:
        try:
            if not await has_lesson_user(config, request):
                return error_response("UNAUTHORIZED", "Unauthorized", 401)

            parsed = await parse_list_payload(request)
            if not parsed.ok:
                return parsed.response

            result = await lessons.list(
                {"course": parsed.payload.course} if parsed.payload.course else None
            )
            return JSONResponse({"lessons": result})
        except Exception as error:
            return to_lesson_error_response(error, "Failed to list lessons")

    return handler
