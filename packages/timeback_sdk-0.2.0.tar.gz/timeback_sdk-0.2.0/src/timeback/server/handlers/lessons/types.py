"""Lessons handler types."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypedDict

if TYPE_CHECKING:
    from collections.abc import Callable

    from timeback_core import TimebackClient

    from ...timeback import AppConfig
    from ...types import Environment, IdentityConfig


class LessonsHandlerConfig(TypedDict):
    """Configuration for lessons handlers."""

    env: Environment
    identity: IdentityConfig
    app_config: AppConfig
    get_client: Callable[[], TimebackClient]
