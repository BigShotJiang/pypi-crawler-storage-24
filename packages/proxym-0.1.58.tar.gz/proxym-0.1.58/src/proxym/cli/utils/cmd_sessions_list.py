"""Command utilities for listing items."""

from ..context import make_client, print_json_if_yaml, print_table


def cmd_list_items(args, endpoint: str, item_name: str, columns: list[str], widths: list[int], empty_message: str):
    """Generic command to list items from an API endpoint."""
    with make_client() as c:
        r = c.get(endpoint)
        data = r.json()

    items = data.get(item_name, [])
    if print_json_if_yaml(args, data):
        return

    print(f"\n  {item_name.title()} ({len(items)})\n")
    if not items:
        print(f"  {empty_message}\n")
        return

    print_table(items, columns, widths)
    print()
