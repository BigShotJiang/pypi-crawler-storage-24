"""Delete utilities for tickets and sprints."""

from proxym.dashboard.utils._delete_item import _delete_item


def delete_item(delete_func, item_id: str, not_found_msg: str):
    """Generic delete function for tickets and sprints."""
    return _delete_item(delete_func, item_id, not_found_msg)
