"""Tool registry endpoints: list, summary, get."""

from typing import Any

from fastapi import APIRouter, HTTPException, Query

from proxym.tools import ToolCategory, ToolRegistry

router = APIRouter(tags=["tools"])


@router.get("/")
async def list_tools(
    category: str | None = Query(None, description="Filter by category: ide, agent_cli, browser"),
    available_only: bool = Query(False, description="Only show tools with an available host or docker-backed instance"),
) -> dict[str, Any]:
    """List all registered tools."""
    reg = ToolRegistry.get()
    cat = ToolCategory(category) if category else None
    tools = reg.list_tools(category=cat, available_only=available_only)
    return {"tools": [t.summary() for t in tools], "count": len(tools)}


@router.get("/summary")
async def tools_summary() -> dict[str, Any]:
    """Summary of tool availability."""
    return ToolRegistry.get().summary()


# NOTE: Dynamic route MUST be registered last (after queue_router etc.).
@router.get("/{tool_name}")
async def get_tool(tool_name: str) -> dict[str, Any]:
    """Get details for a specific tool."""
    tool = ToolRegistry.get().get_tool(tool_name)
    if not tool:
        raise HTTPException(404, f"Tool '{tool_name}' not found")
    return tool.summary()
