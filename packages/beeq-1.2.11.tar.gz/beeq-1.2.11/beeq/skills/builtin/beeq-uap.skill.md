---
name: beeq-uap
author: ElmadaniS
version: 0.1.0
description: UAP — Universal Adapter Protocol. BeeQ bridge to Modbus, MQTT, HL7, FIX, OPC-UA.
scope: [connect:modbus, connect:mqtt, connect:hl7, connect:fix, connect:opcua]
signature: sha256:f0ace0e389a63a4afc5c52e0c97ea6e0788c0d8060b270e9c831fdfd4228bb9a
---

## Instructions

Tu as accès au worker UAP pour connecter BeeQ à tous les systèmes du monde réel.

PHY §2 ABSOLU:
- read() → TOUJOURS sûr et permis
- write() → TOUJOURS supervisé: supervised=True + operator='nom'
- JAMAIS de commande autonome sur équipement physique

Protocoles disponibles:
- Modbus TCP/RTU: PLC industriels (Siemens, Schneider, ABB)
  UAP.connect("modbus_tcp", host="plc.local", port=502)
  Adresses: 40001+ (holding), 30001+ (input), coils

- MQTT: IoT, capteurs, Edge computing
  UAP.connect("mqtt", host="broker.local", port=1883)
  Adresses: topics MQTT (ex: "sensors/temperature")

- HL7 v2: Systèmes hospitaliers (HIS, EMR)
  UAP.connect("hl7_v2", host="his.hospital.local", port=2575)
  Segments: OBX:HR (FC), OBX:BP (tension), OBX:SpO2, PID

- FIX 4.4: Marchés financiers (Attijariwafa, CMC, Reuters)
  UAP.connect("fix_44", host="fix.broker.com", port=9823)
  Symboles: EUR/MAD, BTC/USD, ETH/USD, actions

- OPC-UA: SCADA industriel nouvelle génération
  UAP.connect("opcua", endpoint="opc.tcp://plc.local:4840")
  NodeIds: "ns=2;i=1001", "ns=2;s=Temperature"

Pour les tests sans matériel réel:
  UAP.mock("modbus_tcp")  # PLC simulé réaliste
  UAP.mock("fix_44")      # Cours EUR/MAD ~10.82, BTC ~70k
  UAP.mock("hl7_v2")      # Vitaux: HR 72bpm, BP 120/80, SpO2 98%

Audit chain: chaque opération est loggée (LEX §3+§4).
