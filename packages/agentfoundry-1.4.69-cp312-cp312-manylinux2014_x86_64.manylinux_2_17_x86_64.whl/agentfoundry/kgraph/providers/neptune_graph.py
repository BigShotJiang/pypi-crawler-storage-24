from __future__ import annotations

import json
import logging
import random
import threading
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from agentfoundry.kgraph.base import KGraphBase
from agentfoundry.utils.agent_config import AgentConfig
from agentfoundry.utils.exceptions import ConfigurationError, InitializationError
from agentfoundry.utils.module_config import get_module_config
from agentfoundry.vectorstores.factory import VectorStoreFactory

logger = logging.getLogger(__name__)


class NeptuneGraph(KGraphBase):
    """Neptune-backed knowledge graph using openCypher plus AgentFoundry vector search."""

    def __init__(
        self,
        *,
        config: AgentConfig | None = None,
        endpoint: str | None = None,
        reader_endpoint: str | None = None,
        region: str | None = None,
        port: int = 8182,
        use_https: bool = True,
        iam_auth: bool = True,
        query_language: str = "opencypher",
        timeout: float = 10.0,
        use_ssh_tunnel: bool = False,
        ssh_host: str | None = None,
        ssh_user: str | None = None,
        ssh_key_path: str | None = None,
        ssh_key_passphrase: str | None = None,
        use_nginx_proxy: bool = False,
        nginx_proxy_host: str = "127.0.0.1",
        nginx_proxy_port: int = 8183,
        aws_access_key_id: str | None = None,
        aws_secret_access_key: str | None = None,
        aws_session_token: str | None = None,
        aws_profile: str | None = None,
    ) -> None:
        if query_language.lower() != "opencypher":
            raise ConfigurationError(f"Unsupported Neptune query language: {query_language}")

        self._config = config
        self.endpoint = endpoint
        self.reader_endpoint = reader_endpoint
        self.region = region
        self.port = int(port)
        self.use_https = bool(use_https)
        self.iam_auth = bool(iam_auth)
        self.query_language = query_language.lower()
        self.timeout = float(timeout)
        self.use_ssh_tunnel = use_ssh_tunnel
        self.ssh_host = ssh_host
        self.ssh_user = ssh_user
        self.ssh_key_path = ssh_key_path
        self.ssh_key_passphrase = ssh_key_passphrase
        self.use_nginx_proxy = use_nginx_proxy
        self.nginx_proxy_host = nginx_proxy_host
        self.nginx_proxy_port = int(nginx_proxy_port)
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.aws_session_token = aws_session_token
        self.aws_profile = aws_profile
        
        self._tunnel = None
        self._tunnel_lock = threading.Lock()
        self._local_bind_port: int = 0
        self._watchdog_active = False
        self._watchdog_thread: threading.Thread | None = None

        if not self.endpoint:
            raise ConfigurationError("Neptune endpoint not configured")

        self._boto_endpoint_url = None
        if self.use_ssh_tunnel:
            try:
                import paramiko
                if not hasattr(paramiko, 'DSSKey'):
                    paramiko.DSSKey = paramiko.RSAKey
                from sshtunnel import SSHTunnelForwarder
            except ImportError as exc:
                raise ConfigurationError("paramiko and sshtunnel are required for SSH tunneling") from exc
                
            if not self.ssh_host or not self.ssh_user or not self.ssh_key_path:
                raise ConfigurationError("SSH Host, User, and Key Path are required when use_ssh_tunnel is True")

            # Expand ~ in the key path
            import os
            expanded_key_path = os.path.expanduser(self.ssh_key_path)

            if not os.path.exists(expanded_key_path):
                raise ConfigurationError(f"SSH key file not found: {expanded_key_path}")
            logger.info("SSH key file found: %s", expanded_key_path)

            passphrase = self.ssh_key_passphrase.get_secret_value() if hasattr(self.ssh_key_passphrase, 'get_secret_value') else self.ssh_key_passphrase
            logger.info("SSH passphrase provided: %s", passphrase is not None and len(str(passphrase)) > 0)

            logger.info("Creating SSHTunnelForwarder to %s@%s -> %s:%s ...",
                         self.ssh_user, self.ssh_host, self.endpoint, self.port)

            # Suppress noisy ERROR logs from paramiko/sshtunnel when it probes
            # SSH keys that require a password (e.g. ~/.ssh/id_ed25519).
            # These are harmless — it moves on to the correct key.
            _ssh_loggers = [
                logging.getLogger(n)
                for n in ("paramiko", "paramiko.transport", "sshtunnel", "sshtunnel.SSHTunnelForwarder")
            ]
            _prev_levels = [lg.level for lg in _ssh_loggers]
            for lg in _ssh_loggers:
                lg.setLevel(logging.CRITICAL)
            try:
                self._tunnel = SSHTunnelForwarder(
                    (self.ssh_host, 22),
                    ssh_username=self.ssh_user,
                    ssh_pkey=expanded_key_path,
                    ssh_private_key_password=passphrase,
                    # Only use the explicitly configured key. Do not probe the
                    # SSH agent or default ~/.ssh key files, which can surface
                    # misleading passphrase errors for unrelated keys.
                    allow_agent=False,
                    host_pkey_directories=[],
                    remote_bind_address=(self.endpoint, self.port),
                    local_bind_address=('127.0.0.1', 0) # Bind to any available local port
                )
                logger.info("Starting SSH tunnel...")
                self._tunnel.start()
            finally:
                for lg, prev in zip(_ssh_loggers, _prev_levels):
                    lg.setLevel(prev)
            self._local_bind_port = self._tunnel.local_bind_port
            logger.info("SSH tunnel started on local port %s", self._local_bind_port)
            # Boto3 needs a custom endpoint url to hit the tunnel, but SigV4 needs the original endpoint host
            self._boto_endpoint_url = f"https://127.0.0.1:{self._local_bind_port}"
            logger.info("Established SSH Tunnel to Neptune via %s. Local port: %s",
                         self.ssh_host, self._local_bind_port)
        elif self.use_nginx_proxy:
            self._boto_endpoint_url = f"https://{self.nginx_proxy_host}:{self.nginx_proxy_port}"
            logger.info(
                "Using Nginx TCP proxy for Neptune at %s (proxies to %s:%s)",
                self._boto_endpoint_url, self.endpoint, self.port,
            )
        else:
            self._boto_endpoint_url = self._normalise_endpoint(self.endpoint)

        if self.use_ssh_tunnel:
            self._start_watchdog()

        logger.info("Building boto3 neptune client (writer)...")
        self._client = self._build_client(self.endpoint, self._boto_endpoint_url)
        logger.info("Writer client built OK")

        # If reader endpoint is not configured, fallback to standard endpoint. But if tunneling,
        # we still have to point Boto at the tunnel, and SigV4 at the reader_endpoint host.
        reader_host = self.reader_endpoint or self.endpoint
        reader_boto_url = self._boto_endpoint_url if (self.use_ssh_tunnel or self.use_nginx_proxy) else self._normalise_endpoint(reader_host)
        logger.info("Building boto3 neptune client (reader)...")
        self._reader_client = self._build_client(reader_host, reader_boto_url)
        logger.info("Reader client built OK")

        logger.info("Initializing VectorStore...")
        try:
            resolved_config = config or get_module_config() or AgentConfig.from_legacy_config()
            self.vector_store = VectorStoreFactory.get_store(config=resolved_config)
            logger.info("VectorStore initialized OK")
        except Exception as exc:
            logger.warning("NeptuneGraph: VectorStore init failed (degraded mode): %s", exc, exc_info=True)
            self.vector_store = None

        logger.info("Running health-check query: RETURN 1 AS ok ...")
        try:
            self._execute_cypher("RETURN 1 AS ok")
            logger.info("Health-check query succeeded")
        except Exception as exc:
            raise InitializationError(
                component="NeptuneGraph",
                message=f"Failed to initialize NeptuneGraph: {exc}",
                cause=exc,
            ) from exc

    def __del__(self):
        self._watchdog_active = False
        if hasattr(self, '_tunnel') and self._tunnel and self._tunnel.is_active:
            self._tunnel.stop()
            logger.info("Closed SSH Tunnel to Neptune.")

    def _reconnect_tunnel(self) -> None:
        """Stop the existing SSH tunnel and start a fresh one on the same local port."""
        import os
        from sshtunnel import SSHTunnelForwarder

        with self._tunnel_lock:
            if self._tunnel:
                try:
                    self._tunnel.stop()
                except Exception:
                    pass
                self._tunnel = None

            expanded_key_path = os.path.expanduser(self.ssh_key_path)
            passphrase = (
                self.ssh_key_passphrase.get_secret_value()
                if hasattr(self.ssh_key_passphrase, "get_secret_value")
                else self.ssh_key_passphrase
            )
            _ssh_loggers = [
                logging.getLogger(n)
                for n in ("paramiko", "paramiko.transport", "sshtunnel", "sshtunnel.SSHTunnelForwarder")
            ]
            _prev_levels = [lg.level for lg in _ssh_loggers]
            for lg in _ssh_loggers:
                lg.setLevel(logging.CRITICAL)
            try:
                tunnel = SSHTunnelForwarder(
                    (self.ssh_host, 22),
                    ssh_username=self.ssh_user,
                    ssh_pkey=expanded_key_path,
                    ssh_private_key_password=passphrase,
                    allow_agent=False,
                    host_pkey_directories=[],
                    remote_bind_address=(self.endpoint, self.port),
                    local_bind_address=("127.0.0.1", self._local_bind_port),
                )
                tunnel.start()
            finally:
                for lg, prev in zip(_ssh_loggers, _prev_levels):
                    lg.setLevel(prev)

            self._tunnel = tunnel

    def _start_watchdog(self) -> None:
        """Start a daemon thread that monitors the SSH tunnel and reconnects if it drops."""
        self._watchdog_active = True
        self._watchdog_thread = threading.Thread(
            target=self._tunnel_watchdog,
            daemon=True,
            name="neptune-tunnel-watchdog",
        )
        self._watchdog_thread.start()

    def _tunnel_watchdog(self) -> None:
        """Periodically check the SSH tunnel and reconnect if it is down."""
        CHECK_INTERVAL = 30    # seconds between health checks
        LOG_INTERVAL = 300     # seconds between repeated error logs while tunnel is down

        last_error_log = 0.0

        while self._watchdog_active:
            time.sleep(CHECK_INTERVAL)
            if not self._watchdog_active:
                break

            with self._tunnel_lock:
                tunnel_ok = bool(self._tunnel and self._tunnel.is_active)

            if tunnel_ok:
                last_error_log = 0.0
                continue

            now = time.monotonic()
            if now - last_error_log >= LOG_INTERVAL:
                logger.error(
                    "Neptune SSH tunnel is down (host=%s). Attempting to reconnect...",
                    self.ssh_host,
                )
                last_error_log = now

            try:
                self._reconnect_tunnel()
                logger.info(
                    "Neptune SSH tunnel reconnected successfully (host=%s, local_port=%s)",
                    self.ssh_host, self._local_bind_port,
                )
                last_error_log = 0.0
            except Exception as exc:
                logger.debug("Neptune SSH tunnel reconnect attempt failed: %s", exc)

    def _build_client(self, endpoint: str, endpoint_url: str):
        try:
            import boto3
            from botocore.config import Config as BotoConfig
            from botocore import UNSIGNED
            from botocore.exceptions import NoCredentialsError
        except ImportError as exc:
            raise ConfigurationError("boto3 is required for the Neptune KGraph provider") from exc

        client_kwargs: Dict[str, Any] = {"endpoint_url": endpoint_url}
        region_name = self.region or getattr(getattr(self._config, "aws", None), "region", None)
        if region_name:
            client_kwargs["region_name"] = region_name

        session_kwargs: Dict[str, Any] = {}
        if self.aws_profile:
            session_kwargs["profile_name"] = self.aws_profile
        explicit_creds: Dict[str, Any] = {}
        if self.aws_access_key_id and self.aws_secret_access_key:
            explicit_creds["aws_access_key_id"] = self.aws_access_key_id
            explicit_creds["aws_secret_access_key"] = self.aws_secret_access_key
            if self.aws_session_token:
                explicit_creds["aws_session_token"] = self.aws_session_token
        session = boto3.Session(**session_kwargs)
            
        if self.use_ssh_tunnel or self.use_nginx_proxy:
            # When tunneling or proxying via Nginx, we hit a local address, so SSL verify will fail
            # against the original cert. Disable SSL verification and inject the correct Host header
            # for AWS SigV4.
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            client_kwargs["verify"] = False
            
            # boto3 requires us to inject the correct Host header so SigV4 works against localhost
            client_config = BotoConfig(
                signature_version='s3v4', 
                proxies={}, # disable proxies just in case
            )
            client_kwargs["config"] = client_config

            def _build_signed_client() -> Any:
                return session.client("neptunedata", **client_kwargs, **explicit_creds)

            def _build_unsigned_client() -> Any:
                unsigned_kwargs = dict(client_kwargs)
                unsigned_kwargs["config"] = BotoConfig(signature_version=UNSIGNED, proxies={})
                return session.client("neptunedata", **unsigned_kwargs)

            if self.iam_auth:
                try:
                    creds = session.get_credentials()
                    if creds is None and not explicit_creds:
                        raise NoCredentialsError()
                    client = _build_signed_client()
                except NoCredentialsError:
                    logger.warning(
                        "NeptuneGraph: IAM auth requested but AWS credentials were not found; "
                        "falling back to unsigned Neptune client over SSH tunnel."
                    )
                    client = _build_unsigned_client()
            else:
                client = _build_unsigned_client()
            
            # Inject Host header dynamically using botocore events
            def inject_host_header(request, **kwargs):
                request.headers['Host'] = f"{endpoint}:{self.port}"
                
            client.meta.events.register('before-sign.neptunedata.*', inject_host_header)
            return client

        if self.iam_auth:
            return session.client("neptunedata", **client_kwargs, **explicit_creds)
        return session.client(
            "neptunedata",
            **client_kwargs,
            config=BotoConfig(signature_version=UNSIGNED),
        )

    def _normalise_endpoint(self, endpoint: str) -> str:
        if endpoint.startswith("http://") or endpoint.startswith("https://"):
            return endpoint
        scheme = "https" if self.use_https else "http"
        return f"{scheme}://{endpoint}:{self.port}"

    # Retryable error codes returned by Neptune under contention or transient failures.
    _RETRYABLE_CODES = frozenset({
        "ConcurrentModificationException",
        "ThrottlingException",
        "TooManyRequestsException",
        "ReadOnlyViolationException",
        "TimeLimitExceededException",
    })

    def _execute_cypher(
        self,
        query: str,
        parameters: Optional[Dict[str, Any]] = None,
        *,
        reader: bool = False,
        max_retries: int = 3,
    ) -> List[Dict[str, Any]]:
        params = json.dumps(parameters or {}, separators=(",", ":"))
        client = self._reader_client if reader else self._client

        last_exc: Optional[Exception] = None
        for attempt in range(max_retries + 1):
            try:
                response = client.execute_open_cypher_query(
                    openCypherQuery=query,
                    parameters=params,
                )
                results = response.get("results", [])
                return results if isinstance(results, list) else []
            except Exception as exc:
                last_exc = exc
                error_code = getattr(exc, "response", {}).get("Error", {}).get("Code", "")
                if attempt >= max_retries:
                    break
                # If using SSH tunnel and it appears dead, reconnect immediately
                if self.use_ssh_tunnel:
                    with self._tunnel_lock:
                        tunnel_ok = bool(self._tunnel and self._tunnel.is_active)
                    if not tunnel_ok:
                        logger.warning(
                            "Neptune SSH tunnel down during query (attempt %d/%d); reconnecting...",
                            attempt + 1, max_retries,
                        )
                        try:
                            self._reconnect_tunnel()
                            logger.info("Neptune SSH tunnel reconnected; retrying query.")
                        except Exception as tunnel_exc:
                            logger.warning("Neptune SSH tunnel reconnect failed: %s", tunnel_exc)
                # Exponential backoff with jitter
                backoff = min(2.0 ** attempt * 0.25, 5.0) + random.uniform(0, 0.25)
                logger.warning(
                    "Neptune query retry %d/%d after %s (%.2fs backoff): %s",
                    attempt + 1, max_retries, error_code or type(exc).__name__, backoff,
                    str(exc)[:200],
                )
                time.sleep(backoff)
        raise last_exc  # type: ignore[misc]

    @staticmethod
    def _det_id(triple: str, user_id: str, org_id: str) -> str:
        import hashlib

        h = hashlib.sha256()
        h.update(triple.encode())
        h.update(user_id.encode())
        h.update(org_id.encode())
        return h.hexdigest()

    @staticmethod
    def _coerce_result_value(value: Any) -> Any:
        if isinstance(value, dict):
            if "~id" in value:
                return value.get("~id")
            if "_value" in value:
                return value.get("_value")
            if "value" in value and len(value) == 1:
                return value["value"]
        return value

    def upsert_fact(self, subject: str, predicate: str, obj: str, metadata: Dict) -> str:
        user_id = str(metadata.get("user_id", ""))
        org_id = str(metadata.get("org_id", ""))
        triple = f"{subject}|{predicate}|{obj}"
        fact_id = self._det_id(triple, user_id, org_id)
        metadata_json = json.dumps(metadata, separators=(",", ":"))
        query = """
        MERGE (s:Entity {value: $subject})
        MERGE (o:Entity {value: $object})
        MERGE (s)-[r:REL {fact_id: $fact_id}]->(o)
        SET r.predicate = $predicate,
            r.user_id = $user_id,
            r.org_id = $org_id,
            r.created_at = $created_at,
            r.metadata_json = $metadata_json
        RETURN r.fact_id AS fact_id
        """
        self._execute_cypher(
            query,
            {
                "subject": subject,
                "object": obj,
                "fact_id": fact_id,
                "predicate": predicate,
                "user_id": user_id,
                "org_id": org_id,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "metadata_json": metadata_json,
            },
        )
        if self.vector_store is not None:
            try:
                self.vector_store.add_texts([triple], metadatas=[metadata], ids=[fact_id])
            except Exception:
                logger.debug("NeptuneGraph vector-store mirror failed", exc_info=True)
        return fact_id

    @staticmethod
    def _build_vector_filter(metadata_filters: Dict[str, str]) -> Dict[str, Any]:
        """Build filter kwargs compatible with both Milvus (expr) and other LangChain stores (filter)."""
        if not metadata_filters:
            return {}
        # Build Milvus expr string
        clauses = []
        for key, value in metadata_filters.items():
            escaped = json.dumps(value)
            clauses.append(f'metadata["{key}"] == {escaped}')
        expr = " and ".join(clauses)
        # Pass both: Milvus uses expr, FAISS/Chroma use filter
        return {"expr": expr, "filter": metadata_filters}

    def search(self, query: str, *, user_id: str, org_id: str, k: int = 5) -> List[Dict]:
        if self.vector_store is None:
            logger.warning("NeptuneGraph search skipped: vector store not available")
            return []
        filter_kwargs = self._build_vector_filter({"user_id": user_id, "org_id": org_id})
        docs = self.vector_store.similarity_search_with_score(
            query,
            k=k,
            **filter_kwargs,
        )
        results = []
        for doc, score in docs:
            subj, pred, obj = doc.page_content.split("|", 2)
            results.append({"subject": subj, "predicate": pred, "object": obj, "score": score})
        return results

    def get_neighbours(self, entity: str, depth: int = 2) -> List[Dict]:
        safe_depth = max(1, min(int(depth), 5))
        query = f"""
        MATCH p=(n:Entity {{value: $entity}})-[rels:REL*1..{safe_depth}]-(m)
        UNWIND rels AS rel
        WITH DISTINCT startNode(rel) AS s, rel, endNode(rel) AS o
        RETURN s.value AS subject, rel.predicate AS predicate, o.value AS object
        """
        rows = self._execute_cypher(query, {"entity": entity}, reader=True)
        results: List[Dict] = []
        for row in rows:
            results.append(
                {
                    "subject": self._coerce_result_value(row.get("subject")),
                    "predicate": self._coerce_result_value(row.get("predicate")),
                    "object": self._coerce_result_value(row.get("object")),
                }
            )
        return results

    def purge_expired(self, days: int = 90) -> None:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        query = """
        MATCH ()-[r:REL]->()
        WHERE r.created_at < $cutoff
        DELETE r
        """
        self._execute_cypher(query, {"cutoff": cutoff})

    def delete_context(self, *, org_id: str, graph_slice_id: str) -> int:
        needle = f'"graph_slice_id":"{graph_slice_id}"'
        query = """
        MATCH ()-[r:REL]->()
        WHERE r.org_id = $org_id AND r.metadata_json CONTAINS $needle
        WITH r, count(r) AS cnt
        DELETE r
        RETURN cnt AS deleted
        """
        rows = self._execute_cypher(query, {"org_id": org_id, "needle": needle})
        if not rows:
            return 0
        return int(self._coerce_result_value(rows[0].get("deleted")) or 0)

    # ------------------------------------------------------------------
    # Batch operations (Step 7 – MultiAgentCollaborationPlan)
    # ------------------------------------------------------------------

    def batch_upsert_facts(
        self,
        facts: List[Dict[str, Any]],
    ) -> List[str]:
        """Upsert multiple facts in a single logical batch.

        Each item in *facts* must have keys: ``subject``, ``predicate``,
        ``object``, ``metadata``.

        Returns a list of fact IDs (one per upserted fact).  Individual
        failures are logged but do not abort the batch.
        """
        ids: List[str] = []
        t0 = time.perf_counter()
        for fact in facts:
            try:
                fid = self.upsert_fact(
                    subject=fact["subject"],
                    predicate=fact["predicate"],
                    obj=fact["object"],
                    metadata=fact.get("metadata", {}),
                )
                ids.append(fid)
            except Exception as exc:
                logger.warning(
                    "batch_upsert_facts: failed for (%s, %s, %s): %s",
                    fact.get("subject", "?"),
                    fact.get("predicate", "?"),
                    fact.get("object", "?"),
                    exc,
                )
        duration = time.perf_counter() - t0
        logger.info(
            "batch_upsert_facts: %d/%d succeeded in %.2fs",
            len(ids),
            len(facts),
            duration,
        )
        return ids

    def batch_search(
        self,
        queries: List[str],
        *,
        user_id: str,
        org_id: str,
        k: int = 5,
    ) -> List[List[Dict]]:
        """Execute multiple vector-based searches in a single call.

        Returns a list of result-lists, one per query.  Avoids repeated
        filter construction and round-trip overhead.
        """
        if self.vector_store is None:
            logger.warning("batch_search skipped: vector store not available")
            return [[] for _ in queries]

        filter_kwargs = self._build_vector_filter({"user_id": user_id, "org_id": org_id})
        all_results: List[List[Dict]] = []
        t0 = time.perf_counter()
        for query in queries:
            try:
                docs = self.vector_store.similarity_search_with_score(
                    query,
                    k=k,
                    **filter_kwargs,
                )
                results = []
                for doc, score in docs:
                    parts = doc.page_content.split("|", 2)
                    if len(parts) == 3:
                        results.append({
                            "subject": parts[0],
                            "predicate": parts[1],
                            "object": parts[2],
                            "score": score,
                        })
                all_results.append(results)
            except Exception as exc:
                logger.warning("batch_search: query '%s' failed: %s", query[:40], exc)
                all_results.append([])
        duration = time.perf_counter() - t0
        logger.info(
            "batch_search: %d queries, total_hits=%d, duration=%.2fs",
            len(queries),
            sum(len(r) for r in all_results),
            duration,
        )
        return all_results

    def batch_get_neighbours(
        self,
        entities: List[str],
        depth: int = 2,
    ) -> Dict[str, List[Dict]]:
        """Retrieve neighbours for multiple entities in one call.

        Returns a dict mapping entity → list of neighbour triples.
        """
        results: Dict[str, List[Dict]] = {}
        t0 = time.perf_counter()
        for entity in entities:
            try:
                results[entity] = self.get_neighbours(entity, depth=depth)
            except Exception as exc:
                logger.warning("batch_get_neighbours: entity '%s' failed: %s", entity, exc)
                results[entity] = []
        duration = time.perf_counter() - t0
        logger.info(
            "batch_get_neighbours: %d entities, total_triples=%d, duration=%.2fs",
            len(entities),
            sum(len(v) for v in results.values()),
            duration,
        )
        return results

    def fetch_by_metadata(self, *, org_id: str, filters: Dict[str, str]) -> List[Dict]:
        filter_clauses = ["r.org_id = $org_id"]
        params: Dict[str, Any] = {"org_id": org_id}
        for idx, (key, value) in enumerate(filters.items()):
            param_name = f"fragment_{idx}"
            filter_clauses.append(f"r.metadata_json CONTAINS ${param_name}")
            params[param_name] = f'"{key}":"{value}"'
        where_clause = " AND ".join(filter_clauses)
        query = f"""
        MATCH (s:Entity)-[r:REL]->(o:Entity)
        WHERE {where_clause}
        RETURN s.value AS subject, r.predicate AS predicate, o.value AS object, r.metadata_json AS metadata
        """
        rows = self._execute_cypher(query, params, reader=True)
        results: List[Dict] = []
        for row in rows:
            metadata_raw = self._coerce_result_value(row.get("metadata"))
            try:
                metadata = json.loads(metadata_raw) if isinstance(metadata_raw, str) else {}
            except Exception:
                metadata = {}
            results.append(
                {
                    "subject": self._coerce_result_value(row.get("subject")),
                    "predicate": self._coerce_result_value(row.get("predicate")),
                    "object": self._coerce_result_value(row.get("object")),
                    "metadata": metadata,
                }
            )
        return results
