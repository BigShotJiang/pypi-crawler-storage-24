"""Tests for AgentAds middleware wrapper."""

import pytest
import httpx
import respx

from agentads_nat.middleware import monetize_output, AgentAdsMiddleware
from agentads_nat.types import AgentAdsConfig


@pytest.fixture
def config():
    return AgentAdsConfig(
        publisher_api_key="pub_test_123",
        api_url="https://api.tryagentads.com",
    )


def _mock_filled():
    return respx.post("https://api.tryagentads.com/v1/bid").mock(
        return_value=httpx.Response(
            200,
            json={
                "filled": True,
                "requestId": "req_mid",
                "ad": {
                    "format": "suffix",
                    "headline": "TestAd",
                    "description": "Great product",
                    "cta": "Buy now",
                    "click_url": "https://example.com/click",
                    "label": "Ad",
                },
            },
        )
    )


def _mock_no_fill():
    return respx.post("https://api.tryagentads.com/v1/bid").mock(
        return_value=httpx.Response(
            200,
            json={"filled": False, "requestId": "req_nf"},
        )
    )


@pytest.mark.asyncio
@respx.mock
async def test_monetize_output_with_ad(config):
    _mock_filled()
    result = await monetize_output(config, "Here is my response.", query="test")
    assert "Here is my response." in result
    assert "TestAd" in result
    assert "---" in result


@pytest.mark.asyncio
@respx.mock
async def test_monetize_output_no_fill(config):
    _mock_no_fill()
    result = await monetize_output(config, "Here is my response.", query="test")
    assert result == "Here is my response."


@pytest.mark.asyncio
async def test_monetize_output_disabled():
    config = AgentAdsConfig(publisher_api_key="pub_test", disabled=True)
    result = await monetize_output(config, "Response text.", query="test")
    assert result == "Response text."


@pytest.mark.asyncio
async def test_monetize_output_empty():
    config = AgentAdsConfig(publisher_api_key="pub_test")
    result = await monetize_output(config, "", query="test")
    assert result == ""


@pytest.mark.asyncio
@respx.mock
async def test_middleware_wrap(config):
    _mock_filled()

    async def my_agent(query: str) -> str:
        return f"Answer to: {query}"

    middleware = AgentAdsMiddleware(config)
    wrapped = middleware.wrap(my_agent)

    result = await wrapped("What is the best CRM?")
    assert "Answer to: What is the best CRM?" in result
    assert "TestAd" in result


@pytest.mark.asyncio
@respx.mock
async def test_middleware_wrap_no_fill(config):
    _mock_no_fill()

    async def my_agent(query: str) -> str:
        return "Plain answer."

    middleware = AgentAdsMiddleware(config)
    wrapped = middleware.wrap(my_agent)

    result = await wrapped("hello")
    assert result == "Plain answer."
