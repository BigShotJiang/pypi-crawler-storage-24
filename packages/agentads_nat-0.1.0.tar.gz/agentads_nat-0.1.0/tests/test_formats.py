"""Tests for ad rendering formats."""

from agentads_nat.formats import render_ad
from agentads_nat.types import AdUnit, AdFormat


def _make_ad() -> AdUnit:
    return AdUnit(
        format="suffix",
        headline="Acme CRM",
        description="The CRM built for growing teams",
        cta="Try free",
        click_url="https://api.tryagentads.com/click/abc123",
        label="Ad",
    )


def test_suffix_format():
    ad = _make_ad()
    result = render_ad(ad, AdFormat.SUFFIX)
    assert result.startswith("\n\n---\n")
    assert "*Ad - Acme CRM" in result
    assert "[Try free](https://api.tryagentads.com/click/abc123)" in result


def test_citation_format():
    ad = _make_ad()
    result = render_ad(ad, AdFormat.CITATION)
    assert result.startswith("\n\n> **Sponsored:**")
    assert "Acme CRM" in result
    assert "[Try free]" in result


def test_followup_format():
    ad = _make_ad()
    result = render_ad(ad, AdFormat.FOLLOWUP)
    assert "*Sponsored suggestion:" in result
    assert "Acme CRM" in result


def test_string_format():
    ad = _make_ad()
    result = render_ad(ad, "citation")
    assert "> **Sponsored:**" in result
