"""Tests for AgentAds bid client."""

import pytest
import httpx
import respx

from agentads_nat.client import fetch_ad
from agentads_nat.types import AgentAdsConfig


@pytest.fixture
def config():
    return AgentAdsConfig(
        publisher_api_key="pub_test_123",
        api_url="https://api.tryagentads.com",
    )


@pytest.mark.asyncio
@respx.mock
async def test_fetch_ad_filled(config):
    respx.post("https://api.tryagentads.com/v1/bid").mock(
        return_value=httpx.Response(
            200,
            json={
                "filled": True,
                "requestId": "req_abc",
                "ad": {
                    "format": "suffix",
                    "headline": "Acme CRM",
                    "description": "Built for teams",
                    "cta": "Try free",
                    "click_url": "https://api.tryagentads.com/click/abc",
                    "label": "Ad",
                },
            },
        )
    )

    result = await fetch_ad(config, query="best crm", response="Try HubSpot.")
    assert result is not None
    assert result.filled is True
    assert result.ad.headline == "Acme CRM"


@pytest.mark.asyncio
@respx.mock
async def test_fetch_ad_no_fill(config):
    respx.post("https://api.tryagentads.com/v1/bid").mock(
        return_value=httpx.Response(
            200,
            json={"filled": False, "requestId": "req_xyz"},
        )
    )

    result = await fetch_ad(config, query="hello", response="Hi there.")
    assert result is not None
    assert result.filled is False
    assert result.ad is None


@pytest.mark.asyncio
@respx.mock
async def test_fetch_ad_timeout(config):
    respx.post("https://api.tryagentads.com/v1/bid").mock(
        side_effect=httpx.ReadTimeout("timed out")
    )

    result = await fetch_ad(config, query="hello", response="Hi there.")
    assert result is None


@pytest.mark.asyncio
async def test_fetch_ad_disabled():
    config = AgentAdsConfig(
        publisher_api_key="pub_test_123",
        disabled=True,
    )
    result = await fetch_ad(config, query="test", response="test")
    assert result is None


@pytest.mark.asyncio
@respx.mock
async def test_fetch_ad_server_error(config):
    respx.post("https://api.tryagentads.com/v1/bid").mock(
        return_value=httpx.Response(500, text="Internal Server Error")
    )

    result = await fetch_ad(config, query="test", response="test")
    assert result is None


@pytest.mark.asyncio
@respx.mock
async def test_fetch_ad_truncates_long_input(config):
    long_query = "x" * 1000
    long_response = "y" * 1000

    route = respx.post("https://api.tryagentads.com/v1/bid").mock(
        return_value=httpx.Response(
            200,
            json={"filled": False, "requestId": "req_trunc"},
        )
    )

    await fetch_ad(config, query=long_query, response=long_response)

    sent_body = route.calls[0].request.content
    import json
    payload = json.loads(sent_body)
    assert len(payload["query"]) == 500
    assert len(payload["response"]) == 300
