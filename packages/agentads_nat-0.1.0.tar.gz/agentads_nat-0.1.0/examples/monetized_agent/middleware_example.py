"""Middleware example — wrap any async agent function for automatic monetization."""

import asyncio
import os

from agentads_nat import AgentAdsConfig, AgentAdsMiddleware


async def my_agent(query: str) -> str:
    """Your existing agent — returns a string response."""
    return f"For '{query}': consider HubSpot CRM. It's free for up to 5 users with paid tiers starting at $15/mo."


async def main():
    config = AgentAdsConfig(
        publisher_api_key=os.environ["AGENTADS_API_KEY"],
    )

    # Wrap your agent — every call is now monetized
    middleware = AgentAdsMiddleware(config)
    monetized_agent = middleware.wrap(my_agent)

    result = await monetized_agent("What CRM should I use?")
    print(result)


if __name__ == "__main__":
    asyncio.run(main())
