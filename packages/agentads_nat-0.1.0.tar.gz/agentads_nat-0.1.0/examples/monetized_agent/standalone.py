"""Standalone example — use AgentAds without NeMo Agent Toolkit.

Works with any Python AI agent. Just wrap your output.
"""

import asyncio
import os

from agentads_nat import AgentAdsConfig, monetize_output


async def my_agent(query: str) -> str:
    """Your existing agent logic — replace with your actual implementation."""
    return f"Based on your question about '{query}', I recommend looking into HubSpot or Pipedrive for small teams."


async def main():
    config = AgentAdsConfig(
        publisher_api_key=os.environ["AGENTADS_API_KEY"],
        format="suffix",
    )

    query = "What CRM should I use for a 10-person team?"
    response = await my_agent(query)

    # One line to monetize
    monetized = await monetize_output(config, response, query=query)
    print(monetized)


if __name__ == "__main__":
    asyncio.run(main())
