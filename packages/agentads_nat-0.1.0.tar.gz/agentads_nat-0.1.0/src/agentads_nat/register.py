"""NAT plugin registration for AgentAds.

This module is discovered by NeMo Agent Toolkit via the
`nat.plugins` entry point defined in pyproject.toml.

When NAT is not installed, this module is a no-op — the package
still works standalone via client.py and middleware.py.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

try:
    from nat.cli import register_function
    from nat.front_end.base import FunctionInfo
    from nat.registry import FunctionBaseConfig, Builder
    from pydantic import Field

    from agentads_nat.client import fetch_ad
    from agentads_nat.formats import render_ad
    from agentads_nat.types import AdFormat

    class AgentAdsNATConfig(FunctionBaseConfig, name="agentads_monetize"):
        """AgentAds monetization function for NeMo Agent Toolkit workflows."""

        publisher_api_key: str = Field(description="Publisher API key from tryagentads.com")
        format: str = Field(default="suffix", description="Ad format: suffix, citation, or followup")
        api_url: str = Field(default="https://api.tryagentads.com", description="AgentAds API URL")
        timeout_ms: int = Field(default=50, description="Bid timeout in ms (never blocks agent)")
        session_id: str | None = Field(default=None, description="Session ID for frequency capping")

    @register_function(config_type=AgentAdsNATConfig)
    async def agentads_monetize(config: AgentAdsNATConfig, builder: Builder):
        """Monetize agent output with contextual ads from AgentAds."""
        from agentads_nat.types import AgentAdsConfig

        ads_config = AgentAdsConfig(
            publisher_api_key=config.publisher_api_key,
            format=AdFormat(config.format),
            api_url=config.api_url,
            timeout_ms=config.timeout_ms,
            session_id=config.session_id,
        )

        async def monetize(text: str) -> str:
            """Append a contextual ad to agent output. Returns unchanged text on no-fill or timeout."""
            bid = await fetch_ad(ads_config, query="", response=text)
            if bid and bid.filled and bid.ad:
                return text + render_ad(bid.ad, ads_config.format)
            return text

        yield FunctionInfo.from_fn(monetize, description=monetize.__doc__)

    logger.debug("AgentAds NAT plugin registered successfully")

except ImportError:
    logger.debug("nvidia-nat not installed — AgentAds NAT plugin registration skipped")
