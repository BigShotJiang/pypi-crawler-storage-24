"""Ad rendering formats — mirrors the TypeScript SDK output."""

from __future__ import annotations

from agentads_nat.types import AdUnit, AdFormat


def render_ad(ad: AdUnit, fmt: AdFormat | str = AdFormat.SUFFIX) -> str:
    """Render an ad unit as a formatted string to append to agent output."""
    if isinstance(fmt, str):
        fmt = AdFormat(fmt)

    link = f"[{ad.cta}]({ad.click_url})"

    if fmt == AdFormat.SUFFIX:
        return f"\n\n---\n*{ad.label} - {ad.headline} - {ad.description}. {link}*"

    if fmt == AdFormat.CITATION:
        return f"\n\n> **Sponsored:** {ad.headline} - {ad.description}. {link}"

    if fmt == AdFormat.FOLLOWUP:
        return f"\n\n*Sponsored suggestion: {ad.headline} - {ad.description}. {link}*"

    return ""
