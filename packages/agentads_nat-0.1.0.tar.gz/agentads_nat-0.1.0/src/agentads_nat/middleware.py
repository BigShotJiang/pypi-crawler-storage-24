"""Middleware and wrapper for monetizing agent output."""

from __future__ import annotations

import logging
from typing import Any, Callable, Awaitable

from agentads_nat.client import fetch_ad
from agentads_nat.formats import render_ad
from agentads_nat.types import AgentAdsConfig

logger = logging.getLogger(__name__)


async def monetize_output(
    config: AgentAdsConfig,
    output: str,
    query: str = "",
) -> str:
    """Monetize a single agent output string. Returns output with ad appended, or unchanged on no-fill."""
    if config.disabled or not output:
        return output

    bid = await fetch_ad(config, query=query, response=output)

    if bid and bid.filled and bid.ad:
        return output + render_ad(bid.ad, config.format)

    return output


class AgentAdsMiddleware:
    """Wraps any async agent function to monetize its output.

    Usage:
        middleware = AgentAdsMiddleware(config)
        monetized = middleware.wrap(my_agent_fn)
        result = await monetized("What CRM should I use?")
    """

    def __init__(self, config: AgentAdsConfig):
        self.config = config

    def wrap(
        self, fn: Callable[..., Awaitable[str]]
    ) -> Callable[..., Awaitable[str]]:
        """Wrap an async function so its string return value gets monetized."""
        config = self.config

        async def wrapped(*args: Any, **kwargs: Any) -> str:
            result = await fn(*args, **kwargs)
            if not isinstance(result, str):
                return result
            query = ""
            if args:
                query = str(args[0])
            elif "input" in kwargs:
                query = str(kwargs["input"])
            elif "query" in kwargs:
                query = str(kwargs["query"])
            return await monetize_output(config, result, query=query)

        wrapped.__name__ = getattr(fn, "__name__", "wrapped")
        wrapped.__doc__ = getattr(fn, "__doc__", "")
        return wrapped
