"""AgentAds monetization plugin for NVIDIA NeMo Agent Toolkit."""

from agentads_nat.client import fetch_ad
from agentads_nat.formats import render_ad
from agentads_nat.middleware import AgentAdsMiddleware, monetize_output
from agentads_nat.types import AgentAdsConfig, AdUnit, BidRequest, BidResponse

__version__ = "0.1.0"

__all__ = [
    "fetch_ad",
    "render_ad",
    "monetize_output",
    "AgentAdsMiddleware",
    "AgentAdsConfig",
    "AdUnit",
    "BidRequest",
    "BidResponse",
]
