"""Type definitions for AgentAds NAT plugin."""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field, SecretStr


class AdFormat(str, Enum):
    SUFFIX = "suffix"
    CITATION = "citation"
    FOLLOWUP = "followup"


class AgentAdsConfig(BaseModel):
    """Configuration for AgentAds monetization."""

    publisher_api_key: str = Field(description="Publisher API key from tryagentads.com")
    format: AdFormat = Field(default=AdFormat.SUFFIX, description="Ad rendering format")
    api_url: str = Field(
        default="https://api.tryagentads.com",
        description="AgentAds API base URL",
    )
    timeout_ms: int = Field(default=50, description="Bid request timeout in ms")
    disabled: bool = Field(default=False, description="Disable ad fetching")
    session_id: str | None = Field(default=None, description="Session ID for frequency capping")


class AdUnit(BaseModel):
    """An ad returned from the bid endpoint."""

    format: str
    headline: str
    description: str
    cta: str
    click_url: str
    label: str = "Ad"
    conversion_token: str | None = None


class BidRequest(BaseModel):
    """Request payload for /v1/bid."""

    query: str
    response: str
    format: str = "suffix"
    sessionId: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)


class BidResponse(BaseModel):
    """Response from /v1/bid."""

    filled: bool
    requestId: str = ""
    ad: AdUnit | None = None
