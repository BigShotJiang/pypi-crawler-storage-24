"""HTTP client for AgentAds bid API."""

from __future__ import annotations

import hashlib
import time
import logging

import httpx

from agentads_nat.types import AgentAdsConfig, BidRequest, BidResponse

logger = logging.getLogger(__name__)

_SDK_VERSION = "agentads-nat/0.1.0"
_MAX_QUERY_LEN = 500
_MAX_RESPONSE_LEN = 300


async def fetch_ad(
    config: AgentAdsConfig,
    query: str,
    response: str,
) -> BidResponse | None:
    """Fire a bid request to AgentAds. Returns None on timeout or error."""
    if config.disabled:
        return None

    payload = BidRequest(
        query=query[:_MAX_QUERY_LEN],
        response=response[:_MAX_RESPONSE_LEN],
        format=config.format.value,
        sessionId=config.session_id,
        context={
            "timestamp": int(time.time() * 1000),
            "responseLength": len(response),
        },
    )

    timeout = httpx.Timeout(config.timeout_ms / 1000, connect=1.0)

    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                f"{config.api_url}/v1/bid",
                json=payload.model_dump(exclude_none=True),
                headers={
                    "Authorization": f"Bearer {config.publisher_api_key}",
                    "Content-Type": "application/json",
                    "X-AgentAds-SDK": _SDK_VERSION,
                },
            )
            resp.raise_for_status()
            return BidResponse.model_validate(resp.json())
    except httpx.TimeoutException:
        logger.debug("AgentAds bid request timed out (%dms)", config.timeout_ms)
        return None
    except Exception as e:
        logger.debug("AgentAds bid request failed: %s", e)
        return None
