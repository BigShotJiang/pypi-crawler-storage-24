"""Python API client for mountainfyi.com."""

__version__ = "0.1.0"
