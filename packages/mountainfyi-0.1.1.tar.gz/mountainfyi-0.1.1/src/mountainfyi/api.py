"""HTTP API client for mountainfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install mountainfyi[api]``

Usage::

    from mountainfyi.api import MountainFYI

    with MountainFYI() as api:
        items = api.list_continents()
        detail = api.get_continent("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class MountainFYI:
    """API client for the mountainfyi.com REST API.

    Provides typed access to all mountainfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://mountainfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://mountainfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_continents(self, **params: Any) -> dict[str, Any]:
        """List all continents."""
        return self._get("/api/v1/continents/", **params)

    def get_continent(self, slug: str) -> dict[str, Any]:
        """Get continent by slug."""
        return self._get(f"/api/v1/continents/" + slug + "/")

    def list_countries(self, **params: Any) -> dict[str, Any]:
        """List all countries."""
        return self._get("/api/v1/countries/", **params)

    def get_country(self, slug: str) -> dict[str, Any]:
        """Get country by slug."""
        return self._get(f"/api/v1/countries/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_mountains(self, **params: Any) -> dict[str, Any]:
        """List all mountains."""
        return self._get("/api/v1/mountains/", **params)

    def get_mountain(self, slug: str) -> dict[str, Any]:
        """Get mountain by slug."""
        return self._get(f"/api/v1/mountains/" + slug + "/")

    def list_ranges(self, **params: Any) -> dict[str, Any]:
        """List all ranges."""
        return self._get("/api/v1/ranges/", **params)

    def get_range(self, slug: str) -> dict[str, Any]:
        """Get range by slug."""
        return self._get(f"/api/v1/ranges/" + slug + "/")

    def list_regions(self, **params: Any) -> dict[str, Any]:
        """List all regions."""
        return self._get("/api/v1/regions/", **params)

    def get_region(self, slug: str) -> dict[str, Any]:
        """Get region by slug."""
        return self._get(f"/api/v1/regions/" + slug + "/")

    def list_routes(self, **params: Any) -> dict[str, Any]:
        """List all routes."""
        return self._get("/api/v1/routes/", **params)

    def get_route(self, slug: str) -> dict[str, Any]:
        """Get route by slug."""
        return self._get(f"/api/v1/routes/" + slug + "/")

    def list_seasonal_conditions(self, **params: Any) -> dict[str, Any]:
        """List all seasonal conditions."""
        return self._get("/api/v1/seasonal-conditions/", **params)

    def get_seasonal_condition(self, slug: str) -> dict[str, Any]:
        """Get seasonal condition by slug."""
        return self._get(f"/api/v1/seasonal-conditions/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> MountainFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
