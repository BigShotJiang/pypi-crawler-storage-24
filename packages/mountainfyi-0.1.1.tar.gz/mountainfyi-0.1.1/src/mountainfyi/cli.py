"""Command-line interface for mountainfyi."""

from __future__ import annotations

import json

import typer

from mountainfyi.api import MountainFYI

app = typer.Typer(help="MountainFYI — Mountains, peaks and elevation data API client.")


@app.command()
def search(query: str) -> None:
    """Search mountainfyi.com."""
    with MountainFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
