"""MCP server for mountainfyi — AI assistant tools for mountainfyi.com.

Run: uvx --from "mountainfyi[mcp]" python -m mountainfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("MountainFYI")


@mcp.tool()
def list_mountains(limit: int = 20, offset: int = 0) -> str:
    """List mountains from mountainfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from mountainfyi.api import MountainFYI

    with MountainFYI() as api:
        data = api.list_mountains(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No mountains found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_mountain(slug: str) -> str:
    """Get detailed information about a specific mountain.

    Args:
        slug: URL slug identifier for the mountain.
    """
    from mountainfyi.api import MountainFYI

    with MountainFYI() as api:
        data = api.get_mountain(slug)
        return str(data)


@mcp.tool()
def list_ranges(limit: int = 20, offset: int = 0) -> str:
    """List ranges from mountainfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from mountainfyi.api import MountainFYI

    with MountainFYI() as api:
        data = api.list_ranges(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No ranges found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_mountain(query: str) -> str:
    """Search mountainfyi.com for mountains, peaks, ranges, and climbing routes.

    Args:
        query: Search query string.
    """
    from mountainfyi.api import MountainFYI

    with MountainFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
