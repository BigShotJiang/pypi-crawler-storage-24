truncate table a
