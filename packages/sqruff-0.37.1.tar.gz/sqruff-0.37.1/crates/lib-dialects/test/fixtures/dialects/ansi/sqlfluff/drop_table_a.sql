drop table a
