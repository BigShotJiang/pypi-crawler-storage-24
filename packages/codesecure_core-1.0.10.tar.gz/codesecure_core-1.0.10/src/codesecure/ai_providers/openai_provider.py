import asyncio
from typing import List, Dict, Any, Optional

from codesecure.common.models import Finding, EnhancedFinding
from codesecure.common.logging import get_logger
from codesecure.ai_providers.base import (
    BaseAIProvider, 
    AIProviderType, 
    AIProviderStatus,
)
from codesecure.ai_providers.prompts import GenericPromptBuilder, GenericMarkdownParser
from codesecure.common.config import get_env

logger = get_logger(__name__)


class OpenAIWrapper(BaseAIProvider):
    """OpenAI Provider Implementation"""
    
    PROVIDER_TYPE = AIProviderType.OPENAI
    
    def __init__(self):
        self.prompt_builder = GenericPromptBuilder()
        self.parser = GenericMarkdownParser()
        self._api_key = get_env("CODESECURE_OPENAI_API_KEY", "")
        self._model = get_env("CODESECURE_OPENAI_MODEL", "gpt-4o")
        
    def _get_client(self):
        try:
             import openai
             return openai.AsyncOpenAI(api_key=self._api_key)
        except ImportError:
             raise RuntimeError("openai SDK not installed")
        
    def set_api_key(self, api_key: str):
        self._api_key = api_key

    def set_model(self, model: str):
        self._model = model
        
    @property
    def is_available(self) -> bool:
        try:
            import openai
            return bool(self._api_key)
        except ImportError:
            return False
            
    async def check_availability(self) -> tuple[AIProviderStatus, str]:
        try:
            import openai
        except ImportError:
            return AIProviderStatus.UNAVAILABLE, "OpenAI SDK not found (install with 'pip install openai')"
            
        if not self._api_key:
             return AIProviderStatus.UNAVAILABLE, "CODESECURE_OPENAI_API_KEY is not set"
             
        return AIProviderStatus.AVAILABLE, "Ready"

    def _classify_error(self, err_msg: str) -> str:
        err_lower = err_msg.lower()
        if any(w in err_lower for w in ["invalid_api_key", "incorrect api key", "authentication", "401", "403"]):
             return "auth"
        if any(w in err_lower for w in ["rate_limit", "quota", "too many requests", "429"]):
             return "rate_limit"
        return "other"

    async def test_connection(self) -> tuple[AIProviderStatus, str]:
        status, msg = await self.check_availability()
        if status != AIProviderStatus.AVAILABLE:
             return status, msg
             
        try:
            client = self._get_client()
            logger.info("Validating OpenAI API key with model %s...", self._model)
            await client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": "Reply with 'ok'"}],
                max_tokens=5,
            )
            return AIProviderStatus.AVAILABLE, "Ready"
        except Exception as e:
            err_type = self._classify_error(str(e))
            if err_type == "auth":
                 return AIProviderStatus.ERROR, f"OpenAI Auth Error: {e}"
            if err_type == "rate_limit":
                 return AIProviderStatus.ERROR, f"OpenAI Rate Limit Error: {e}"
            return AIProviderStatus.ERROR, f"OpenAI Connection Failed: {str(e)}"

    async def analyze_findings_batch(
        self, 
        findings: List[Finding], 
        code_contexts: Dict[str, str],
        batch_size: int = 10,
        app_context: Optional[Dict[str, Any]] = None,
        is_workspace_scan: bool = False
    ) -> List[EnhancedFinding]:
        
        if not findings:
            return []
            
        client = self._get_client()
        prompt = self.prompt_builder.build_batch_prompt(findings, app_context=app_context, is_workspace_scan=is_workspace_scan)
        
        try:
            logger.info("Sending batch of %d findings to OpenAI (%s)...", len(findings), self._model)
            
            response = await client.chat.completions.create(
                model=self._model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are CodeSecure, an expert AI security assistant. "
                                   "Analyze security findings and provide remediation in Markdown format. "
                                   "Follow the ZERO-CHATTER RULE: remediation code blocks must contain "
                                   "ONLY pure source code, no explanations."
                    },
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=4096,
            )
            
            text = response.choices[0].message.content or ""
            logger.debug("Received AI response length: %d characters", len(text))
            
            return self.parser.parse(text, findings)
            
        except Exception as e:
            err_type = self._classify_error(str(e))
            if err_type == "rate_limit":
                 raise RuntimeError(f"OpenAI Rate Limit Exceeded: {e}")
            logger.exception("OpenAI Analysis failed: %s", e)
            raise e

    def enhance_finding(self, finding: Finding, analysis: Any) -> EnhancedFinding:
        pass
        
    async def generate_stride_analysis(self, repo_path: Any, category: str) -> Dict[str, Any]:
        return {"error": "Not implemented"}

def get_openai_wrapper() -> OpenAIWrapper:
    return OpenAIWrapper()
