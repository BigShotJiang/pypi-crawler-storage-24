import asyncio
from typing import List, Dict, Any, Optional

from codesecure.common.models import Finding, EnhancedFinding
from codesecure.common.logging import get_logger
from codesecure.ai_providers.base import (
    BaseAIProvider, 
    AIProviderType, 
    AIProviderStatus,
)
from codesecure.ai_providers.prompts import GenericPromptBuilder, GenericMarkdownParser
from codesecure.common.config import get_env

logger = get_logger(__name__)


class AnthropicWrapper(BaseAIProvider):
    """Anthropic Provider Implementation"""
    
    PROVIDER_TYPE = AIProviderType.ANTHROPIC
    
    def __init__(self):
        self.prompt_builder = GenericPromptBuilder()
        self.parser = GenericMarkdownParser()
        self._api_key = get_env("CODESECURE_ANTHROPIC_API_KEY", "")
        self._model = get_env("CODESECURE_ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
        
    def _get_client(self):
        try:
             import anthropic
             return anthropic.AsyncAnthropic(api_key=self._api_key)
        except ImportError:
             raise RuntimeError("anthropic SDK not installed")

    def set_api_key(self, api_key: str):
        self._api_key = api_key

    def set_model(self, model: str):
        self._model = model
             
    @property
    def is_available(self) -> bool:
        try:
            import anthropic
            return bool(self._api_key)
        except ImportError:
            return False
            
    async def check_availability(self) -> tuple[AIProviderStatus, str]:
        try:
            import anthropic
        except ImportError:
            return AIProviderStatus.UNAVAILABLE, "Anthropic SDK not found (install with 'pip install anthropic')"
            
        if not self._api_key:
             return AIProviderStatus.UNAVAILABLE, "CODESECURE_ANTHROPIC_API_KEY is not set"
             
        return AIProviderStatus.AVAILABLE, "Ready"

    def _classify_error(self, err_msg: str, status_code: Optional[int] = None) -> str:
        err_lower = err_msg.lower()
        if status_code in (401, 403) or any(w in err_lower for w in ["invalid x-api-key", "authentication"]):
             return "auth"
        if status_code == 429 or any(w in err_lower for w in ["rate_limit", "too many requests"]):
             return "rate_limit"
        return "other"

    async def test_connection(self) -> tuple[AIProviderStatus, str]:
        status, msg = await self.check_availability()
        if status != AIProviderStatus.AVAILABLE:
             return status, msg
             
        try:
            client = self._get_client()
            logger.info("Validating Anthropic API key with model %s...", self._model)
            await client.messages.create(
                model=self._model,
                messages=[{"role": "user", "content": "Reply with 'ok'"}],
                max_tokens=5,
            )
            return AIProviderStatus.AVAILABLE, "Ready"
        except Exception as e:
            err_type = self._classify_error(str(e), getattr(e, "status_code", None))
            if err_type == "auth":
                 return AIProviderStatus.ERROR, f"Anthropic Auth Error: {e}"
            if err_type == "rate_limit":
                 return AIProviderStatus.ERROR, f"Anthropic Rate Limit Error: {e}"
            return AIProviderStatus.ERROR, f"Anthropic Connection Failed: {str(e)}"

    async def analyze_findings_batch(
        self, 
        findings: List[Finding], 
        code_contexts: Dict[str, str],
        batch_size: int = 10,
        app_context: Optional[Dict[str, Any]] = None,
        is_workspace_scan: bool = False
    ) -> List[EnhancedFinding]:
        
        if not findings:
            return []
            
        client = self._get_client()
        prompt = self.prompt_builder.build_batch_prompt(findings, app_context=app_context, is_workspace_scan=is_workspace_scan)
        
        system_prompt = (
            "You are CodeSecure, an expert AI security assistant. "
            "Analyze security findings and provide remediation in Markdown format. "
            "Follow the ZERO-CHATTER RULE: remediation code blocks must contain "
            "ONLY pure source code, no explanations."
        )
        
        try:
            logger.info("Sending batch of %d findings to Anthropic (%s)...", len(findings), self._model)
            
            response = await client.messages.create(
                model=self._model,
                system=system_prompt,
                messages=[
                    {"role": "user", "content": prompt}
                ],
                temperature=0.2,
                max_tokens=4096,
            )
            
            text = response.content[0].text if response.content else ""
            logger.debug("Received AI response length: %d characters", len(text))
            
            return self.parser.parse(text, findings)
            
        except Exception as e:
            err_type = self._classify_error(str(e), getattr(e, "status_code", None))
            if err_type == "rate_limit":
                 raise RuntimeError(f"Anthropic Rate Limit Exceeded: {e}")
            logger.exception("Anthropic Analysis failed: %s", e)
            raise e

    def enhance_finding(self, finding: Finding, analysis: Any) -> EnhancedFinding:
        pass
        
    async def generate_stride_analysis(self, repo_path: Any, category: str) -> Dict[str, Any]:
        return {"error": "Not implemented"}

def get_anthropic_wrapper() -> AnthropicWrapper:
    return AnthropicWrapper()
