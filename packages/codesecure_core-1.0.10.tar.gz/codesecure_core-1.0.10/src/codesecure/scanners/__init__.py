"""
Scanners Module for CodeSecure.

SS-001: Security scanning tool integration
SS-002: Local and container execution modes
SS-008: pip-audit integration
SS-009: pip-licenses integration
SS-014: Framework mapping
"""

from codesecure.scanners.base import (
    BaseScanner,
    Finding,
    FindingSeverity,
    ScanMode,
    ScannerResult,
)
from codesecure.scanners.engine import (
    ScannerEngine,
    ScanResult,
    get_scanner_engine,
)
from codesecure.scanners.framework_mapper import (
    FrameworkMapper,
    get_framework_mapper,
)
from codesecure.scanners.bandit import BanditScanner
from codesecure.scanners.semgrep import SemgrepScanner
from codesecure.scanners.checkov import CheckovScanner
from codesecure.scanners.detect_secrets import DetectSecretsScanner
from codesecure.scanners.npm_audit import NpmAuditScanner
from codesecure.scanners.grype import GrypeScanner
from codesecure.scanners.syft import SyftScanner
from codesecure.scanners.pip_audit import PipAuditScanner
from codesecure.scanners.pip_licenses import PipLicensesScanner

__all__ = [
    # Base classes
    "BaseScanner",
    "Finding",
    "FindingSeverity",
    "ScanMode",
    "ScannerResult",
    # Engine
    "ScannerEngine",
    "ScanResult",
    "get_scanner_engine",
    # Framework mapping
    "FrameworkMapper",
    "get_framework_mapper",
    # Scanners
    "BanditScanner",
    "SemgrepScanner",
    "CheckovScanner",
    "DetectSecretsScanner",
    "NpmAuditScanner",
    "GrypeScanner",
    "SyftScanner",
    "PipAuditScanner",
    "PipLicensesScanner",
]
