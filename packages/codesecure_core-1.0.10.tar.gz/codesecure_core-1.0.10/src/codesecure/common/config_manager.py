"""
Unified Configuration Manager for `.codesecure.yml`

This module provides the central schema and loading mechanism for configuring
scanners, AI providers, and quality gates across the CLI and extensions.
"""

from pathlib import Path
from typing import List, Optional
from pydantic import BaseModel, Field
import yaml

from codesecure.common.models import CloudProvider


class ScannersConfig(BaseModel):
    """Scanner configuration."""
    enabled: List[str] = Field(
        default=["semgrep", "bandit", "checkov", "detect-secrets", "pip-audit"],
        description="List of enabled scanners"
    )

class QualityGateConfig(BaseModel):
    """Quality gate thresholds."""
    fail_on: List[str] = Field(
        default=["critical", "high"],
        description="Severities that fail the quality gate"
    )
    max_total: int = Field(default=50, description="Maximum total allowed findings")
    new_only: bool = Field(default=False, description="Whether to fail only on new baseline findings")
    baseline: Optional[str] = Field(default=".codesecure-baseline.json", description="Path to the baseline file")
    min_score: str = Field(default="C", description="Minimum letter grade score")

class AIConfig(BaseModel):
    """AI enrichment configuration."""
    enabled: bool = Field(default=True, description="Whether AI features are enabled globally")
    provider: CloudProvider = Field(default=CloudProvider.NONE, description="Active AI Provider")
    fp_detection: bool = Field(default=True, description="Whether False Positive detection is active")
    remediation: bool = Field(default=True, description="Whether AI remediation is active")

class ReportsConfig(BaseModel):
    """Report generation configuration."""
    formats: List[str] = Field(default=["sarif", "html", "json", "markdown"], description="Report formats to generate")

class CodeSecureConfig(BaseModel):
    """Root configuration mapping to `.codesecure.yml`."""
    scanners: ScannersConfig = Field(default_factory=ScannersConfig)
    quality_gate: QualityGateConfig = Field(default_factory=QualityGateConfig)
    ai: AIConfig = Field(default_factory=AIConfig)
    reports: ReportsConfig = Field(default_factory=ReportsConfig)


def load_config(directory: Path | str) -> CodeSecureConfig:
    """
    Search for a .codesecure.yml or .codesecure.yaml recursively up from `directory`.
    If found, parse and return the CodeSecureConfig. 
    If not found, return the default code configuration.
    """
    directory = Path(directory).resolve()
    
    # Simple search upward up to 5 directories to find a config
    current_dir = directory
    for _ in range(5):
        for filename in [".codesecure.yml", ".codesecure.yaml"]:
            config_path = current_dir / filename
            if config_path.is_file():
                try:
                    with open(config_path, "r", encoding="utf-8") as f:
                        data = yaml.safe_load(f) or {}
                        return CodeSecureConfig.model_validate(data)
                except Exception as e:
                    # Log error, but fail gracefully to default for now
                    print(f"[Warning] Failed to parse {config_path}: {e}")
                    
        parent_dir = current_dir.parent
        if parent_dir == current_dir:
            break
        current_dir = parent_dir
        
    return CodeSecureConfig()
