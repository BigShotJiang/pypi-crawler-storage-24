"""
Reports Module for CodeSecure.

SS-006: Multi-format report generation
TM-008: Threat model report generation
"""

from codesecure.reports.generator import (
    BaseReportGenerator,
    ReportGenerator,
    ReportMetadata,
    get_report_generator,
)

# Import generators to register them
from codesecure.reports.json import JSONReportGenerator
from codesecure.reports.html import HTMLReportGenerator
from codesecure.reports.sarif import SARIFReportGenerator
from codesecure.reports.markdown import MarkdownReportGenerator

__all__ = [
    # Base classes
    "BaseReportGenerator",
    "ReportGenerator",
    "ReportMetadata",
    "get_report_generator",
    # Format generators
    "JSONReportGenerator",
    "HTMLReportGenerator",
    "SARIFReportGenerator",
    "MarkdownReportGenerator",
]
