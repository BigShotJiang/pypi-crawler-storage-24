# CodeSecure Core (`codesecure-core`)

The `codesecure-core` package is the programmatic orchestration brain of the CodeSecure platform. It provides the centralized, stateless logic for executing security scanners, managing asynchronous jobs, and enriching findings with AI models.

## 🎯 Module Purpose

This package encapsulates the strict business logic of the platform, adhering to a "Thin Client" architecture. It does not export command-line (CLI) applications or MCP Transport interfaces directly. Instead, it provides a stable Python API (Singletons) designed to be consumed by other packages in the CodeSecure monorepo, such as `codesecure-cli` and `codesecure-mcp`.

## 📦 Local Installation

Because `core` has no dependency on the UI/CLI layer, it can be installed natively for programmatic API usage.

```bash
cd packages/core
python -m venv .venv

# Install the core logic with basic SAST scanners
pip install -e .

# [Optional] Install AI providers (Google Gemini or Kiro CLI dependencies)
pip install -e .[google,aws]
```

## 🔌 Exported APIs & Features

The Core package exposes Manager classes via the Singleton pattern:

1. **`ScannerEngine`**: Orchestrates local/container execution for Bandit, Semgrep, Checkov, detect-secrets, npm-audit, pip-audit, etc.
   ```python
   from codesecure.scanners.engine import get_scanner_engine
   ```
2. **`JobManager`**: Async execution tracking, lock management, TTL limits, and progress percentages.
   ```python
   from codesecure.jobs.manager import get_job_manager
   ```
3. **`AIProviderManager`**: Abstracts batch prompting against Gemini and Kiro. Calculates False Positive tracking dynamically.
   ```python
   from codesecure.ai_providers.manager import get_ai_manager
   ```

## 🛠️ Integration Example

Here is how a downstream module (like the MCP server) imports and utilizes the core library programmatically:

```python
import asyncio
from pathlib import Path
from codesecure.common.models import ScanMode, CloudProvider
from codesecure.scanners.engine import get_scanner_engine

async def programmatically_scan(target_dir: str):
    scan_path = Path(target_dir).resolve()
    engine = get_scanner_engine()
    
    # Check available scanners
    available = engine.get_available_scanners(ScanMode.LOCAL)
    print(f"Scanners ready: {available}")
    
    # Run a unified scan seamlessly combining multiple tools
    result = await engine.run_scan(
        path=scan_path,
        mode=ScanMode.LOCAL,
        cloud_provider=CloudProvider.NONE
    )
    
    print(f"Total findings discovered: {len(result.findings)}")

asyncio.run(programmatically_scan("./my_project"))
```
