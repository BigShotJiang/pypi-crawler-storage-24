"""
Alliance Auth Framework
"""
