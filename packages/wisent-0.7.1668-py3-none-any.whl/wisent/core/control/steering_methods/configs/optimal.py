"""Empirically optimal parameter values from validation studies.

Reads proven results from parameters_to_validate.json.
These are optimization outputs, not defaults.
"""
import json
from pathlib import Path

_JSON_PATH = Path(__file__).parent / "parameters_to_validate.json"


def _load_optimal() -> dict:
    """Load the optimal section from parameters_to_validate.json."""
    with open(_JSON_PATH) as f:
        data = json.load(f)
    return data.get("_meta", {}).get("optimal", {})


def _load_validated() -> dict:
    """Load the validated section from parameters_to_validate.json."""
    with open(_JSON_PATH) as f:
        data = json.load(f)
    return data.get("_meta", {}).get("validated", {})


def get_optimal_extraction_strategy() -> str:
    """Return the empirically optimal extraction strategy.

    Reads from parameters_to_validate.json optimal section.
    Raises ValueError if no optimal extraction_strategy exists.
    """
    optimal = _load_optimal()
    value = optimal.get("extraction_strategy")
    if value is None:
        raise ValueError(
            "No optimal extraction_strategy in parameters_to_validate.json"
        )
    return value


def get_validated_extraction_strategies() -> list[str]:
    """Return the list of validated extraction strategies.

    These are strategies confirmed to work by empirical studies,
    though not necessarily the optimal one.
    Raises ValueError if no validated strategies exist.
    """
    validated = _load_validated()
    values = validated.get("extraction_strategy")
    if not values:
        raise ValueError(
            "No validated extraction_strategy list in parameters_to_validate.json"
        )
    return values
