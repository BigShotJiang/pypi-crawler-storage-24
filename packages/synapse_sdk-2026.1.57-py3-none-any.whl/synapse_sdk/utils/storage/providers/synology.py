"""Synology Drive storage provider."""

from __future__ import annotations

import logging
import ssl
import threading
import time
from io import BytesIO, StringIO
from pathlib import Path, PurePosixPath
from typing import Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.ssl_ import create_urllib3_context

from synapse_sdk.utils.storage.config import SynologyStorageConfig
from synapse_sdk.utils.storage.errors import (
    StorageConnectionError,
    StorageNotFoundError,
    StorageUploadError,
)

logger = logging.getLogger(__name__)


class _Http11Adapter(HTTPAdapter):
    """Disable HTTP/2 to prevent stream reset issues with Synology NAS."""

    def init_poolmanager(self, *args, **kwargs):
        try:
            from urllib3 import HttpVersion

            kwargs['disabled_svn'] = {HttpVersion.h2, HttpVersion.h3}
        except (ImportError, AttributeError):
            pass
        ctx = create_urllib3_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        ctx.set_alpn_protocols(['http/1.1'])
        kwargs['ssl_context'] = ctx
        super().init_poolmanager(*args, **kwargs)


class SynologyApiError(Exception):
    """Exception raised when a Synology Drive API call fails."""

    def __init__(self, api: str, method: str, error_code: int, error_info: Any = None):
        self.api = api
        self.method = method
        self.error_code = error_code
        self.error_info = error_info
        super().__init__(f'{api}.{method} failed: error_code={error_code}, info={error_info}')


class SynologyStorage:
    """Storage provider for Synology Drive via REST API.

    Uses Synology Drive API with ``id:<file_id>`` path format.
    On init, parses base_path (e.g. /team-folder/team_folder1) to extract
    the team folder name, then resolves it to a file_id via TeamFolders API.
    All subsequent paths are constructed as ``id:<file_id>/sub/path``.

    Args:
        config: Configuration dict with Synology Drive credentials.

    Example:
        >>> storage = SynologyStorage({
        ...     'url': 'https://nas.example.com:5001',
        ...     'username': 'admin',
        ...     'password': 'secret',
        ...     'base_path': '/team-folder/projects',
        ... })
        >>> storage.upload(Path('local.txt'), 'remote/file.txt')
        'synology://nas.example.com:5001/team-folder/projects/remote/file.txt'
    """

    def __init__(self, config: dict[str, Any]):
        validated = SynologyStorageConfig.model_validate(config)

        self._base_url = validated.url.rstrip('/')
        self._username = validated.username
        self._password = validated.password
        self._otp_code = validated.otp_code
        self._verify_ssl = validated.verify_ssl

        raw_path = '/' + validated.base_path.strip('/')
        self._base_path = raw_path  # display path (e.g. /team-folder/team_folder1)
        self._team_folder_name, self._sub_path = self._parse_base_path(raw_path)

        self._sid: str | None = None
        self._sid_lock = threading.Lock()
        self._base_folder_id: str | None = None
        self._base_folder_id_lock = threading.Lock()
        self._session = self._create_session()

    @staticmethod
    def _create_session() -> requests.Session:
        session = requests.Session()
        session.mount('https://', _Http11Adapter())
        return session

    @staticmethod
    def _parse_base_path(base_path: str) -> tuple[str, str]:
        """Parse base_path into team folder name and sub path.

        Example:
            '/team-folder/team_folder1/sub/path'
            -> ('team_folder1', 'sub/path')
        """
        parts = base_path.strip('/').split('/')
        if len(parts) >= 2 and parts[0] == 'team-folder':
            team_folder_name = parts[1]
            sub_path = '/'.join(parts[2:])
            return team_folder_name, sub_path
        raise ValueError(f'base_path must start with /team-folder/<name>: {base_path}')

    # ── Session management ────────────────────────────────

    def _login(self) -> str:
        """Log in via Synology API Auth and acquire SID."""
        params: dict[str, Any] = {
            'api': 'SYNO.API.Auth',
            'version': 6,
            'method': 'login',
            'account': self._username,
            'passwd': self._password,
            'session': 'synologyDrive',
            'format': 'sid',
        }
        if self._otp_code:
            params['otp_code'] = self._otp_code

        try:
            resp = requests.post(
                f'{self._base_url}/webapi/auth.cgi',
                data=params,
                verify=self._verify_ssl,
                timeout=15,
            )
            data = resp.json()
        except Exception as e:
            raise StorageConnectionError(
                f'Failed to connect to Synology NAS: {e}',
                details={'url': self._base_url},
            ) from e

        if not data.get('success'):
            error_code = data.get('error', {}).get('code')
            raise StorageConnectionError(
                f'Synology login failed: error_code={error_code}',
                details={'url': self._base_url, 'error_code': error_code},
            )
        return data['data']['sid']

    def _get_sid(self) -> str:
        """Return current SID, logging in if needed."""
        if self._sid is None:
            with self._sid_lock:
                if self._sid is None:
                    self._sid = self._login()
        return self._sid

    def _invalidate_sid(self) -> None:
        """Invalidate SID to force re-login on next request."""
        with self._sid_lock:
            self._sid = None

    # ── Team folder ID resolution ─────────────────────────

    def _resolve_team_folder_id(self) -> str:
        """Resolve team folder name to file_id via TeamFolders API."""
        result = self._call_api(
            'GET',
            'SYNO.SynologyDrive.TeamFolders',
            'list',
            1,
        )
        for item in result.get('data', {}).get('items', []):
            if item.get('name') == self._team_folder_name:
                return str(item['file_id'])
        raise SynologyApiError(
            'SYNO.SynologyDrive.TeamFolders',
            'list',
            -1,
            f'Team folder not found: {self._team_folder_name}',
        )

    def _get_base_folder_id(self) -> str:
        """Return cached base team folder file_id."""
        if self._base_folder_id is None:
            with self._base_folder_id_lock:
                if self._base_folder_id is None:
                    self._base_folder_id = self._resolve_team_folder_id()
        return self._base_folder_id

    # ── API call ──────────────────────────────────────────

    def _call_api(
        self,
        method: str,
        api: str,
        api_method: str,
        api_version: int,
        *,
        params: dict[str, Any] | None = None,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
        stream: bool = False,
    ) -> Any:
        """Call Synology API with automatic session retry and connection retry."""
        max_retries = 3
        for attempt in range(max_retries):
            sid = self._get_sid()
            api_params = {
                'api': api,
                'version': api_version,
                'method': api_method,
            }

            kwargs: dict[str, Any] = {
                'verify': self._verify_ssl,
                'timeout': 60,
            }

            if method == 'GET':
                kwargs['params'] = {**api_params, '_sid': sid, **(params or {})}
            else:
                # POST: _sid goes in URL query, rest in form data
                kwargs['params'] = {'_sid': sid}
                kwargs['data'] = {**api_params, **(data or {})}

            if files:
                kwargs['files'] = files
            if stream:
                kwargs['stream'] = True

            url = f'{self._base_url}/webapi/entry.cgi'
            try:
                resp = self._session.request(method, url, **kwargs)
            except requests.ConnectionError:
                if attempt < max_retries - 1:
                    logger.warning(
                        'Synology connection reset, retrying (%d/%d): %s.%s',
                        attempt + 1,
                        max_retries,
                        api,
                        api_method,
                    )
                    self._session.close()
                    self._session = self._create_session()
                    time.sleep(1)
                    continue
                raise

            if stream:
                content_type = resp.headers.get('Content-Type', '')
                if 'application/json' not in content_type:
                    resp.raise_for_status()
                    return resp

            result = resp.json()
            if result.get('success'):
                return result

            error_code = result.get('error', {}).get('code')
            # 119: SID missing or session expired
            if error_code == 119 and attempt == 0:
                self._invalidate_sid()
                continue

            raise SynologyApiError(api, api_method, error_code, result.get('error'))

    # ── Path utils ────────────────────────────────────────

    def _id_path(self, name: str = '') -> str:
        """Convert name to ``id:<base_folder_id>/sub_path/name`` format."""
        folder_id = self._get_base_folder_id()
        parts = [p for p in [self._sub_path, name.strip('/')] if p]
        suffix = '/'.join(parts)
        if suffix:
            return f'id:{folder_id}/{suffix}'
        return f'id:{folder_id}'

    def _display_path(self, name: str = '') -> str:
        """Combine base_path and name into a human-readable display path."""
        name = name.strip('/')
        if name:
            return f'{self._base_path}/{name}'
        return self._base_path

    # ── StorageProtocol implementation ────────────────────

    def upload(self, source: Path, target: str) -> str:
        """Upload a file to Synology Drive.

        Args:
            source: Local file path to upload.
            target: Target path on Synology Drive.

        Returns:
            synology:// URL of uploaded file.
        """
        source_path = Path(source) if isinstance(source, str) else source

        if not source_path.exists():
            raise StorageNotFoundError(
                f'Source file not found: {source_path}',
                details={'source': str(source_path)},
            )

        id_path = self._id_path(target)
        filename = target.rsplit('/', 1)[-1] if '/' in target else target

        try:
            with open(source_path, 'rb') as f:
                self._call_api(
                    'POST',
                    'SYNO.SynologyDrive.Files',
                    'upload',
                    2,
                    data={
                        'path': id_path,
                        'create_parents': 'true',
                        'overwrite': 'true',
                        'type': 'file',
                    },
                    files={'file': (filename, f.read())},
                )
        except SynologyApiError as e:
            raise StorageUploadError(
                f'Failed to upload to Synology Drive: {e}',
                details={'source': str(source_path), 'target': id_path},
            ) from e

        return self.get_url(target)

    def download(self, name: str) -> bytes | None:
        """Download file content as bytes.

        Args:
            name: File path relative to base_path.

        Returns:
            File content as bytes, or None on failure.
        """
        id_path = self._id_path(name)
        try:
            resp = self._call_api(
                'POST',
                'SYNO.SynologyDrive.Files',
                'download',
                2,
                data={'path': id_path},
                stream=True,
            )
            if isinstance(resp, requests.Response):
                return resp.content
            return None
        except SynologyApiError:
            logger.exception('Failed to download file: %s', id_path)
            return None

    def exists(self, target: str) -> bool:
        """Check if file exists on Synology Drive.

        Args:
            target: Path to check.

        Returns:
            True if exists, False otherwise.
        """
        id_path = self._id_path(target)
        try:
            self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            return True
        except SynologyApiError:
            return False

    def delete(self, name: str) -> None:
        """Delete a file on Synology Drive.

        Args:
            name: File path relative to base_path.
        """
        id_path = self._id_path(name)
        try:
            self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'delete',
                2,
                params={'path': id_path},
            )
        except SynologyApiError:
            logger.debug('Failed to delete %s, ignoring', id_path)

    def listdir(self, path: str = '') -> tuple[list[str], list[str]]:
        """List directory contents on Synology Drive.

        Args:
            path: Directory path relative to base_path.

        Returns:
            Tuple of (directories, files).
        """
        id_path = self._id_path(path)
        try:
            result = self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'list',
                2,
                params={
                    'path': id_path,
                    'filter_type': 'all',
                    'sort_by': 'name',
                    'sort_direction': 'asc',
                    'offset': 0,
                    'limit': 5000,
                },
            )
        except SynologyApiError:
            return [], []

        dirs: list[str] = []
        files: list[str] = []
        for item in result.get('data', {}).get('items', []):
            item_name = item.get('name', '')
            if item.get('type') in ('dir', 'folder'):
                dirs.append(item_name)
            else:
                files.append(item_name)
        return dirs, files

    def size(self, name: str) -> int:
        """Get file size on Synology Drive.

        Args:
            name: File path relative to base_path.

        Returns:
            File size in bytes, 0 on failure.
        """
        id_path = self._id_path(name)
        try:
            result = self._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            return result.get('data', {}).get('size', 0)
        except SynologyApiError:
            return 0

    def get_url(self, target: str) -> str:
        """Get synology:// URL for target.

        Args:
            target: Target path.

        Returns:
            synology:// URL string.
        """
        display = self._display_path(target)
        host = self._base_url.split('://', 1)[-1]
        return f'synology://{host}{display}'

    def get_download_url(self, target: str) -> str:
        """Get a direct download URL with current SID.

        Args:
            target: Target path.

        Returns:
            HTTP URL for downloading the file.
        """
        id_path = self._id_path(target)
        sid = self._get_sid()
        return (
            f'{self._base_url}/webapi/entry.cgi'
            f'?api=SYNO.SynologyDrive.Files&version=2&method=download'
            f'&path={id_path}&_sid={sid}'
        )

    def _upload_content(self, name: str, content: bytes) -> None:
        """Upload raw bytes to Synology Drive (no local file needed)."""
        id_path = self._id_path(name)
        filename = name.rsplit('/', 1)[-1] if '/' in name else name
        self._call_api(
            'POST',
            'SYNO.SynologyDrive.Files',
            'upload',
            2,
            data={
                'path': id_path,
                'create_parents': 'true',
                'overwrite': 'true',
                'type': 'file',
            },
            files={'file': (filename, content)},
        )

    def _create_folder(self, name: str, exist_ok: bool = False) -> None:
        """Create a folder on Synology Drive."""
        id_path = self._id_path(name)
        try:
            self._call_api(
                'POST',
                'SYNO.SynologyDrive.Files',
                'create',
                2,
                data={
                    'path': id_path,
                    'type': 'folder',
                    'create_parents': 'true',
                },
            )
        except SynologyApiError:
            if exist_ok and self.exists(name):
                return
            raise

    def get_pathlib(self, path: str) -> SynologyPath:
        """Get SynologyPath object for path.

        Args:
            path: Path relative to base_path.

        Returns:
            SynologyPath object (pathlib-like interface).
        """
        return SynologyPath(self, path)

    def get_path_file_count(self, pathlib_obj: SynologyPath) -> int:
        """Count files recursively in the given path.

        Args:
            pathlib_obj: SynologyPath object from get_pathlib().

        Returns:
            Number of files.
        """
        return pathlib_obj._count_files()

    def get_path_total_size(self, pathlib_obj: SynologyPath) -> int:
        """Calculate total size of files recursively.

        Args:
            pathlib_obj: SynologyPath object from get_pathlib().

        Returns:
            Total size in bytes.
        """
        return pathlib_obj._total_size()


class SynologyPath:
    """Pathlib-like interface for Synology Drive paths.

    Provides a subset of pathlib.Path functionality for Synology Drive resources.
    Supports directory listing and recursive file operations via the Synology API.
    """

    def __init__(self, storage: SynologyStorage, path: str):
        self._storage = storage
        self._path = path.strip('/')

    def __str__(self) -> str:
        return self._storage.get_url(self._path)

    def __repr__(self) -> str:
        return f"SynologyPath('{self}')"

    def __truediv__(self, other: str) -> SynologyPath:
        """Join paths using / operator."""
        new_path = f'{self._path}/{other}' if self._path else str(other)
        return SynologyPath(self._storage, new_path)

    @property
    def name(self) -> str:
        """Get the final component of the path."""
        return PurePosixPath(self._path).name if self._path else ''

    @property
    def stem(self) -> str:
        """Get the final component without its suffix."""
        return PurePosixPath(self._path).stem if self._path else ''

    @property
    def suffix(self) -> str:
        """Get the file extension of the final component."""
        return PurePosixPath(self._path).suffix if self._path else ''

    @property
    def parent(self) -> SynologyPath:
        """Get the parent directory."""
        parent_path = str(PurePosixPath(self._path).parent)
        if parent_path == '.':
            parent_path = ''
        return SynologyPath(self._storage, parent_path)

    def with_name(self, name: str) -> SynologyPath:
        """Return a new path with the file name changed."""
        p = PurePosixPath(self._path)
        new_path = str(p.with_name(name))
        return SynologyPath(self._storage, new_path)

    def with_suffix(self, suffix: str) -> SynologyPath:
        """Return a new path with the suffix changed."""
        p = PurePosixPath(self._path)
        new_path = str(p.with_suffix(suffix))
        return SynologyPath(self._storage, new_path)

    def exists(self) -> bool:
        """Check if this path exists."""
        return self._storage.exists(self._path)

    def is_file(self) -> bool:
        """Check if this path is a file."""
        return self._storage.exists(self._path)

    def is_dir(self) -> bool:
        """Check if this path is a directory."""
        if not self._path:
            return True
        id_path = self._storage._id_path(self._path)
        try:
            result = self._storage._call_api(
                'GET',
                'SYNO.SynologyDrive.Files',
                'get',
                2,
                params={'path': id_path},
            )
            return result.get('data', {}).get('type') in ('dir', 'folder')
        except SynologyApiError:
            return False

    def mkdir(self, parents: bool = False, exist_ok: bool = False) -> None:
        """Create a directory on Synology Drive.

        Args:
            parents: If True, create parent directories as needed (always true for Synology).
            exist_ok: If True, don't raise if directory already exists.
        """
        if not self._path:
            if exist_ok:
                return
            raise FileExistsError('Cannot mkdir on root path')
        self._storage._create_folder(self._path, exist_ok=exist_ok)

    def open(self, mode: str = 'r', encoding: str | None = None, **_kwargs: Any) -> _SynologyFileIO:
        """Open this path for reading or writing.

        Supports 'r', 'rb', 'w', 'wb' modes. Write modes buffer content
        in memory and upload to Synology Drive on close.

        Args:
            mode: File open mode ('r', 'rb', 'w', 'wb').
            encoding: Text encoding (default: utf-8 for text modes).

        Returns:
            A file-like context manager.
        """
        return _SynologyFileIO(self._storage, self._path, mode, encoding)

    def read_bytes(self) -> bytes:
        """Read file contents as bytes."""
        content = self._storage.download(self._path)
        if content is None:
            raise StorageNotFoundError(
                f'File not found: {self._path}',
                details={'path': self._path},
            )
        return content

    def read_text(self, encoding: str = 'utf-8') -> str:
        """Read file contents as text."""
        return self.read_bytes().decode(encoding)

    def stat(self) -> SynologyStat:
        """Get file statistics."""
        file_size = self._storage.size(self._path)
        return SynologyStat(st_size=file_size)

    def _count_files(self) -> int:
        """Count files recursively."""
        dirs, files = self._storage.listdir(self._path)
        count = len(files)
        for d in dirs:
            count += (self / d)._count_files()
        return count

    def _total_size(self) -> int:
        """Calculate total size recursively."""
        dirs, files = self._storage.listdir(self._path)
        total = sum(self._storage.size(f'{self._path}/{f}') for f in files)
        for d in dirs:
            total += (self / d)._total_size()
        return total


class _SynologyFileIO:
    """Buffered file-like object for Synology Drive.

    For read modes: downloads content into memory buffer on init.
    For write modes: buffers writes and uploads to Synology Drive on close.
    """

    def __init__(self, storage: SynologyStorage, path: str, mode: str = 'r', encoding: str | None = None):
        self._storage = storage
        self._path = path
        self._mode = mode
        self._encoding = encoding or 'utf-8'
        self._closed = False

        is_binary = 'b' in mode

        if 'r' in mode:
            content = storage.download(path)
            if content is None:
                raise FileNotFoundError(f'File not found on Synology Drive: {path}')
            if is_binary:
                self._buffer: BytesIO | StringIO = BytesIO(content)
            else:
                self._buffer = StringIO(content.decode(self._encoding))
        elif 'w' in mode or 'a' in mode:
            if is_binary:
                self._buffer = BytesIO()
            else:
                self._buffer = StringIO()
        else:
            raise ValueError(f'Unsupported mode: {mode}')

    def write(self, data: str | bytes) -> int:
        return self._buffer.write(data)

    def read(self, size: int = -1) -> str | bytes:
        return self._buffer.read(size)

    def readline(self) -> str | bytes:
        return self._buffer.readline()

    def readlines(self) -> list[str | bytes]:
        return self._buffer.readlines()

    def seek(self, offset: int, whence: int = 0) -> int:
        return self._buffer.seek(offset, whence)

    def tell(self) -> int:
        return self._buffer.tell()

    def flush(self) -> None:
        pass

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        if 'w' in self._mode or 'a' in self._mode:
            if isinstance(self._buffer, BytesIO):
                content = self._buffer.getvalue()
            else:
                content = self._buffer.getvalue().encode(self._encoding)
            self._storage._upload_content(self._path, content)

    def __enter__(self) -> _SynologyFileIO:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class SynologyStat:
    """Minimal stat result for Synology Drive files."""

    def __init__(self, st_size: int = 0):
        self.st_size = st_size


__all__ = ['SynologyStorage', 'SynologyPath', 'SynologyApiError']
