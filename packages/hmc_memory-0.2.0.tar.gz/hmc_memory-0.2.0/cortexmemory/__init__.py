"""Cortex Memory Python SDK."""
from cortexmemory.client import (
    CortexMemory,
    AsyncCortexMemory,
    StoreResult,
    MemoryResult,
    CompactResult,
    IndexProjectResult,
    Stats,
)

# Backward compatibility aliases
HybridMemory = CortexMemory
AsyncHybridMemory = AsyncCortexMemory

__all__ = [
    "CortexMemory",
    "AsyncCortexMemory",
    "HybridMemory",
    "AsyncHybridMemory",
    "StoreResult",
    "MemoryResult",
    "CompactResult",
    "IndexProjectResult",
    "Stats",
]
__version__ = "0.2.0"
