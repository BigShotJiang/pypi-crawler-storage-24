# Cortex Memory — Python SDK

Persistent memory for AI agents. Store, recall, and manage context across sessions.

## Install

```bash
pip install cortexmemory
```

## Quick Start

```python
from cortexmemory import HybridMemory

mem = HybridMemory(api_key="hm_sk_...", base_url="https://cortex-memory.com")

# Store
mem.store("User prefers dark mode", tags=["preferences"], priority="hot")

# Recall
for r in mem.recall("user preferences"):
    print(f"[{r.score:.0%}] {r.content}")

# Compact session
mem.compact("Session transcript...", task_context="Refactoring auth")

mem.close()
```

## Async

```python
from cortexmemory import AsyncHybridMemory

async with AsyncHybridMemory(api_key="hm_sk_...", base_url="https://cortex-memory.com") as mem:
    await mem.store("Important context", tags=["project"])
    results = await mem.recall("project context")
```

## Get an API Key

```bash
curl -X POST https://cortex-memory.com/v1/admin/provision \
  -H "Content-Type: application/json" \
  -d '{"name": "my-agent", "tos_accepted": true}'
```

## Links

- Website: https://cortex-memory.com
- MCP Server: Works with Cursor, VS Code, Claude Desktop, Windsurf
