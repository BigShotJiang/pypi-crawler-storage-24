"""Terrascout CLI — geospatial data scoping from the terminal."""

__version__ = "0.2.0"
