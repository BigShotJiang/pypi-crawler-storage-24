# SPDX-License-Identifier: BSD-2-Clause
"""
Provides a command line interface to Print the specified value of a YAML file.
"""

# Copyright (C) 2024 embedded brains GmbH & Co. KG
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
# AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
# LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
# CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
# SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
# CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
# ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

import argparse
import sys

from specitems import EmptyItemCache, Item, ItemMapper, load_data


def cliyamlquery(argv: list[str] = sys.argv) -> None:
    """ Print the specified value of a YAML file. """

    parser = argparse.ArgumentParser(description=cliyamlquery.__doc__)
    parser.add_argument("path",
                        metavar="PATH",
                        nargs=1,
                        help="the path to the value")
    parser.add_argument("file", metavar="FILE", nargs=1, help="the YAML file")
    args = parser.parse_args(argv[1:])
    item = Item(EmptyItemCache(), "/x", load_data(args.file[0]))
    print(ItemMapper(item).substitute(f"${{.:{args.path[0]}}}"))
