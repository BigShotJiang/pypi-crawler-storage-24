This module provides an API endpoint to cancel carts in Shopinvader for
Odoo.
