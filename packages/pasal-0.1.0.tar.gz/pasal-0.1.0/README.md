# pasal

Python SDK for [Pasal.id](https://pasal.id) - Indonesia's open legal data platform.

This package is a working Python client for the public [Pasal.id REST API](https://pasal.id/api).

## What is Pasal.id?

Pasal.id provides structured, searchable access to 40,000+ Indonesian government regulations. Free for everyone to read, with an API and MCP server for developers.

## Installation

```bash
pip install pasal
```

## Usage

```python
from pasal import create_client, get_law, list_laws, search

client = create_client()

results = search("upah minimum", limit=3)
laws = list_laws(type="UU", limit=5)
law = get_law("/akn/id/act/uu/2003/13")

print(results["total"])
print(laws["laws"][0]["title"])
print(len(law["articles"]))
```

## Included Methods

- `search(query, ...)` -> search Indonesian legal materials
- `list_laws(...)` -> list laws with filters and pagination
- `get_law(frbr_uri)` -> fetch a law and its article content
- `create_client(...)` -> create a reusable client instance

## Links

- Website: https://pasal.id
- API: https://pasal.id/api
- GitHub: https://github.com/pasal-id
