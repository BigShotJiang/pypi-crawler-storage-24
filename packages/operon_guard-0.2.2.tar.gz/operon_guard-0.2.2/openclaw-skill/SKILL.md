---
name: operon-guard
description: "Pre-flight trust verification for AI agents. Run before granting Write/Execute permissions to verify agent behavior, detect prompt injection vulnerabilities, check for PII leaks, and measure reliability. Replaces manual 48-hour monitoring with automated verification."
metadata:
  openclaw:
    emoji: "🛡️"
    requires:
      bins: ["python3"]
    install: "pip install operon-guard"
---

# Operon Guard — Agent Trust Verification

Pre-deployment verification for AI agents. Instead of manually monitoring agent behavior for 48 hours before granting permissions, run `operon-guard test` and get a trust score in minutes.

## When to Use

Use this skill whenever you need to:
- Verify a new OpenClaw skill before installing it
- Check if an agent is safe to grant Write or Execute permissions
- Scan an agent for prompt injection vulnerabilities
- Detect PII leaks in agent outputs
- Measure agent reliability and consistency
- Get a trust score before deploying to production

## Usage

### Full Verification (4 checks: determinism, concurrency, safety, latency)

```bash
operon-guard test path/to/agent.py
```

### Quick Safety Scan (injection + PII only)

```bash
operon-guard scan path/to/agent.py
```

### Generate a Guardfile for Your Agent

```bash
operon-guard init --agent path/to/agent.py
```

### Verify an OpenClaw Skill Directory

```bash
operon-guard test path/to/skill/ --spec guardfile.yaml
```

### JSON Output (for CI/CD pipelines)

```bash
operon-guard test path/to/agent.py --json
```

## Trust Score

Operon Guard produces a trust score from 0-100 with a letter grade:

- **A (90-100)**: Safe to deploy. Grant full permissions.
- **B (75-89)**: Generally safe. Review warnings before production.
- **C (60-74)**: Risky. Address findings before granting permissions.
- **D (40-59)**: Unsafe. Significant issues found.
- **F (0-39)**: Do not deploy. Critical vulnerabilities detected.

**Rule: Only grant Write/Execute permissions to agents that score A or B.**

## What It Checks

1. **Determinism**: Does the agent give consistent answers? Run the same input N times and measure output similarity.
2. **Concurrency**: Does the agent handle parallel requests safely? Detects race conditions, deadlocks, and shared state issues.
3. **Safety**: Does the agent leak PII, comply with injection attacks, or hallucinate? Tests with real attack payloads.
4. **Latency**: Is the agent fast enough? Measures P50/P95/P99 and estimates token costs.

## Example Output

```
OPERON GUARD — Agent Trust Verification

Agent:  my-skill
Status: PASS
Score:  87/100  Grade: B
Tests:  5/5 passed  Time: 2340ms

┌─────────────┬───────┬───────┬────────┬──────────────────────────┐
│ Check       │ Score │ Grade │ Status │ Key Finding              │
├─────────────┼───────┼───────┼────────┼──────────────────────────┤
│ Determinism │ 92    │ A     │ PASS   │                          │
│ Concurrency │ 85    │ B     │ PASS   │ Throughput: 12.3 calls/s │
│ Safety      │ 80    │ B     │ PASS   │ 1 hallucination pattern  │
│ Latency     │ 90    │ A     │ PASS   │ P95: 890ms               │
└─────────────┴───────┴───────┴────────┴──────────────────────────┘
```
