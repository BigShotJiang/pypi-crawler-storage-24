---
name: code-review
description: "Reviews code snippets for bugs, security issues, and best practices. Supports Python, JavaScript, and TypeScript."
metadata:
  openclaw:
    emoji: "🔍"
---

# Code Review Skill

Reviews code for common issues including security vulnerabilities, performance problems, and style violations.

## Usage

Paste a code snippet and the skill will analyze it for:
- Security issues (SQL injection, XSS, hardcoded secrets)
- Performance problems (N+1 queries, memory leaks)
- Style and best practice violations
- Bug detection
