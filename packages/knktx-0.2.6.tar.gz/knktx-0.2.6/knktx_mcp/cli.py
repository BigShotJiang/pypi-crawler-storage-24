"""knktx CLI — bootstrap agents with rules, workflows, skills, MCP configs, and plugins from knktx."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType

import httpx

from knktx_mcp.enforcement import render_rules, render_workflows

MARKER_START = "<!-- knktx:start -->"
MARKER_END = "<!-- knktx:end -->"

VALID_MODES = ("full", "soft")


# ---------------------------------------------------------------------------
# Agent registry
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class AgentDef:
    """Immutable definition for a supported agent CLI."""

    key: str  # internal identifier, matches API agent param and --agent flag
    display_name: str
    binary: str  # CLI binary name for shutil.which()
    config_dir: str  # e.g. ".claude" — relative to ~ or cwd
    instructions_file: str  # e.g. "CLAUDE.md"
    skills_dir: str  # relative to config_dir
    project_skills_dir: str | None  # override for project scope (None = use config_dir/skills_dir)
    project_instructions_dir: str | None  # override for project instructions (None = use config_dir)
    install_hint: str  # e.g. "npm install -g @anthropic-ai/claude-code"


AGENT_REGISTRY: tuple[AgentDef, ...] = (
    AgentDef(
        key="claude",
        display_name="Claude Code",
        binary="claude",
        config_dir=".claude",
        instructions_file="CLAUDE.md",
        skills_dir="skills",
        project_skills_dir=None,
        project_instructions_dir=None,
        install_hint="npm install -g @anthropic-ai/claude-code",
    ),
    AgentDef(
        key="gemini",
        display_name="Gemini CLI",
        binary="gemini",
        config_dir=".gemini",
        instructions_file="GEMINI.md",
        skills_dir="skills",
        project_skills_dir=None,
        project_instructions_dir=None,
        install_hint="npm install -g @google/gemini-cli",
    ),
    AgentDef(
        key="codex",
        display_name="Codex CLI",
        binary="codex",
        config_dir=".codex",
        instructions_file="AGENTS.md",
        skills_dir="skills",
        project_skills_dir=".agents/skills",
        project_instructions_dir="",
        install_hint="npm install -g @openai/codex",
    ),
)

AGENT_BY_KEY: MappingProxyType[str, AgentDef] = MappingProxyType(
    {a.key: a for a in AGENT_REGISTRY}
)


def detect_agents() -> list[AgentDef]:
    """Return agents whose CLI binary is found on PATH."""
    return [a for a in AGENT_REGISTRY if shutil.which(a.binary)]


DEFAULT_API_URL = "https://app.knktx.dev/api/v1"

_SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]*$")
_MCP_NAME_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_-]*$")

_COLORS = {
    "red": "\x1b[31m",
    "green": "\x1b[32m",
    "yellow": "\x1b[33m",
    "cyan": "\x1b[36m",
    "bold": "\x1b[1m",
    "dim": "\x1b[2m",
    "reset": "\x1b[0m",
}


def _c(text: str, *styles: str) -> str:
    """Wrap text in ANSI color codes. Respects NO_COLOR env var."""
    if os.environ.get("NO_COLOR") or not sys.stdout.isatty():
        return text
    codes = "".join(_COLORS.get(s, "") for s in styles)
    return f"{codes}{text}{_COLORS['reset']}" if codes else text


# ---------------------------------------------------------------------------
# Interactive prompts
# ---------------------------------------------------------------------------


def _prompt(message: str, default: str = "") -> str:
    """Prompt for input with optional default. Handles Ctrl-C/EOF."""
    suffix = f" [{default}]" if default else ""
    try:
        value = input(f"{message}{suffix}: ").strip()
        return value or default
    except (EOFError, KeyboardInterrupt):
        print("\nAborted.", file=sys.stderr)
        sys.exit(1)


def _pick(message: str, options: list[str], default: int = 0) -> int:
    """Interactive arrow-key picker. Returns the selected index.

    Falls back to numbered input if the terminal doesn't support raw mode.
    """
    try:
        import termios
        import tty
    except ImportError:
        return _pick_fallback(message, options, default)

    try:
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
    except (termios.error, AttributeError):
        return _pick_fallback(message, options, default)

    selected = default
    try:
        print(message)
        tty.setraw(fd)
        _pick_render(options, selected, first=True)

        while True:
            ch = sys.stdin.read(1)
            if ch == "\x1b":  # escape sequence
                seq = sys.stdin.read(2)
                if seq == "[A":  # up
                    selected = (selected - 1) % len(options)
                elif seq == "[B":  # down
                    selected = (selected + 1) % len(options)
                _pick_render(options, selected)
            elif ch in ("\r", "\n"):  # enter
                break
            elif ch == "\x03":  # Ctrl-C
                raise KeyboardInterrupt
    except (EOFError, KeyboardInterrupt):
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)
        print("\nAborted.", file=sys.stderr)
        sys.exit(1)
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    # Clear the menu and print the selection
    sys.stdout.write(f"\x1b[{len(options)}A\x1b[J")
    sys.stdout.write(f"{message} {options[selected]}\n")
    sys.stdout.flush()
    return selected


def _pick_render(options: list[str], selected: int, *, first: bool = False) -> None:
    """Render the picker options (raw mode — write directly)."""
    # Move cursor to start of options (skip on first render — lines don't exist yet)
    if not first:
        sys.stdout.write(f"\x1b[{len(options)}A")
    for i, opt in enumerate(options):
        marker = "›" if i == selected else " "
        highlight = f"\x1b[1;36m{opt}\x1b[0m" if i == selected else opt
        sys.stdout.write(f"\r\x1b[K  {marker} {highlight}\n")
    sys.stdout.flush()


def _pick_fallback(message: str, options: list[str], default: int) -> int:
    """Numbered fallback when terminal doesn't support raw mode."""
    print(message)
    for i, opt in enumerate(options):
        marker = "*" if i == default else " "
        print(f"  {marker} {i + 1}. {opt}")
    raw = _prompt("Select", str(default + 1))
    if raw.isdigit():
        idx = int(raw) - 1
        if 0 <= idx < len(options):
            return idx
    return default


def _confirm(message: str, default_yes: bool = True) -> bool:
    """Ask a yes/no question. Returns True for yes."""
    hint = "Y/n" if default_yes else "y/N"
    try:
        answer = input(f"{message} [{hint}]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nAborted.", file=sys.stderr)
        sys.exit(1)
    if not answer:
        return default_yes
    return answer in ("y", "yes")


def _read_existing_config() -> dict | None:
    """Read existing knktx MCP config from Claude Code settings (~/.claude.json).

    This is a Claude-only fallback for API key recovery. Other agents' config
    formats are not yet supported — returns None for non-Claude agents.
    """
    config_path = Path.home() / ".claude.json"
    try:
        if not config_path.exists():
            return None
        data = json.loads(config_path.read_text(encoding="utf-8"))
        return data.get("mcpServers", {}).get("knktx")
    except (json.JSONDecodeError, OSError):
        return None


def _resolve_api_key(args: argparse.Namespace) -> tuple[str, str]:
    """Resolve API key from flag → env var → existing config → interactive prompt.

    Returns (key, source) where source is "flag", "env", "config", or "prompt".
    """
    if args.key:
        return args.key, "flag"
    from_env = os.environ.get("KNKTX_API_KEY", "")
    if from_env:
        return from_env, "env"
    existing = _read_existing_config()
    if existing:
        key = existing.get("env", {}).get("KNKTX_API_KEY", "")
        if key:
            return key, "config"
    key = _prompt("Enter your knktx API key")
    if not key:
        print(_c("Error: API key is required.", "red"), file=sys.stderr)
        sys.exit(1)
    return key, "prompt"


def _resolve_agent(args: argparse.Namespace) -> AgentDef:
    """Resolve agent from flag → detection → interactive picker. Returns AgentDef."""
    detected = set(a.key for a in detect_agents())

    if args.agent is not None:
        # Explicit --agent flag: validate against registry
        agent = AGENT_BY_KEY.get(args.agent)
        if agent is None:
            known = ", ".join(a.key for a in AGENT_REGISTRY)
            print(f"Error: Unknown agent '{args.agent}'. Supported: {known}", file=sys.stderr)
            sys.exit(1)
        return agent

    if args.yes:
        auto = [a for a in AGENT_REGISTRY if a.key in detected]
        if len(auto) == 1:
            return auto[0]
        print("Error: --agent is required with -y when multiple agents are available.", file=sys.stderr)
        sys.exit(1)

    # Show all registered agents; mark ones not found on PATH
    labels = []
    for a in AGENT_REGISTRY:
        label = a.display_name
        if a.key not in detected:
            label += " (not on PATH)"
        labels.append(label)

    idx = _pick("Agent?", labels)
    return AGENT_REGISTRY[idx]


def _resolve_mode(args: argparse.Namespace, api_mode: str | None) -> str:
    """Resolve mode from flag → API setting → interactive picker → default."""
    if args.mode:
        return args.mode
    if api_mode:
        return api_mode
    if args.yes:
        return "full"
    idx = _pick("Injection mode?", list(VALID_MODES))
    return VALID_MODES[idx]


def _resolve_project(args: argparse.Namespace) -> bool:
    """Determine whether to use project scope from flag or interactive picker."""
    if args.project:
        return True
    if args.yes:
        return False
    idx = _pick("Scope?", ["global", "project"])
    return idx == 1


def _connect(api_url: str, api_key: str, key_source: str) -> tuple[httpx.Client, str, list[dict]]:
    """Create an authenticated API client and verify connectivity.

    On 401 with a config-sourced key, prompts for a new key and retries once.
    Returns (client, api_key, settings_rules) — the key may differ from input on retry.
    The settings_rules are fetched during the connectivity probe to avoid a redundant call.
    """
    for attempt in range(2):
        client = httpx.Client(
            base_url=api_url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )
        try:
            # Connectivity probe — also fetches settings rules to avoid a redundant call
            settings_rules = _fetch_settings_rules(client)
            return client, api_key, settings_rules
        except httpx.HTTPStatusError as e:
            client.close()
            if e.response.status_code == 401 and attempt == 0 and key_source == "config":
                print(_c("  Existing API key is invalid or revoked.", "yellow"))
                api_key = _prompt("Enter a new API key")
                if not api_key:
                    print(_c("Error: API key is required.", "red"), file=sys.stderr)
                    sys.exit(1)
                key_source = "prompt"
                continue
            if e.response.status_code == 401:
                print(_c("Error: Invalid API key.", "red"), file=sys.stderr)
            else:
                print(_c(f"Error: API returned {e.response.status_code}.", "red"), file=sys.stderr)
            sys.exit(1)
        except httpx.RequestError as e:
            client.close()
            print(_c(f"Error: Could not reach API at {api_url}: {e}", "red"), file=sys.stderr)
            sys.exit(1)
    # Unreachable, but satisfies type checker
    sys.exit(1)


def _resolve_api_url() -> str:
    from_env = os.environ.get("KNKTX_API_URL", "")
    if from_env:
        return from_env.rstrip("/")
    existing = _read_existing_config()
    if existing:
        url = existing.get("env", {}).get("KNKTX_API_URL", "")
        if url:
            return url.rstrip("/")
    return DEFAULT_API_URL


# ---------------------------------------------------------------------------
# API helpers
# ---------------------------------------------------------------------------


def _api_get(client: httpx.Client, path: str, **params: object) -> list[dict]:
    """GET a JSON list from the API with proper error handling."""
    resp = client.get(path, params=params if params else None)
    resp.raise_for_status()
    data = resp.json()
    if not isinstance(data, list):
        raise ValueError(f"Expected list from {path}, got {type(data).__name__}")
    return data


def _fetch_rules(client: httpx.Client, agent: str | None = None) -> list[dict]:
    params: dict[str, object] = {"enabled": True}
    if agent is not None:
        params["agent"] = agent
    return _api_get(client, "/rules", **params)


def _fetch_settings_rules(client: httpx.Client) -> list[dict]:
    return _api_get(client, "/rules", source="settings")


def _read_injection_mode(settings_rules: list[dict]) -> str | None:
    """Read injection_mode from settings rules. Returns None if not configured or invalid."""
    for rule in settings_rules:
        config = rule.get("config", {})
        if config.get("setting_group") == "injection_mode":
            mode = config.get("mode")
            if mode in VALID_MODES:
                return mode
            print(f"Warning: ignoring unknown injection mode '{mode}' from API.", file=sys.stderr)
            return None
    return None


def _fetch_workflows(client: httpx.Client, agent: str | None = None) -> list[dict]:
    params: dict[str, object] = {}
    if agent is not None:
        params["agent"] = agent
    return _api_get(client, "/workflows", **params)


def _fetch_enabled(client: httpx.Client, path: str, agent: str | None = None) -> list[dict]:
    """Fetch items from the API and filter to enabled-only (client-side).

    The API does not support an ``enabled`` query param for skills, MCP configs,
    or plugins, so we filter after fetching.  Items without an ``enabled`` field
    default to True (backwards-compatible).
    """
    params: dict[str, object] = {}
    if agent is not None:
        params["agent"] = agent
    items = _api_get(client, path, **params)
    return [i for i in items if i.get("enabled", True)]


# ---------------------------------------------------------------------------
# Rendering and injection
# ---------------------------------------------------------------------------


def _sanitize_markers(text: str) -> str:
    """Strip knktx markers from rendered content to prevent marker injection."""
    return text.replace(MARKER_START, "").replace(MARKER_END, "")


def _render_section(rules: list[dict], workflows: list[dict], *, mode: str = "full", agent: str | None = None) -> str:
    """Render the full knktx rules/workflows section with markers."""
    parts: list[str] = [MARKER_START]

    rules_md = _sanitize_markers(render_rules(rules))

    if mode == "full":
        workflows_md = _sanitize_markers(render_workflows(workflows, agent=agent))

        if rules_md:
            parts.append(rules_md)
        if workflows_md:
            if rules_md:
                parts.append("")
            parts.append(workflows_md)

        if not rules_md and not workflows_md:
            parts.append("No rules or workflows configured.")
    else:
        # Soft mode: rules + workflow catalog inline, agent fetches full steps via MCP on demand
        if rules_md:
            parts.append(rules_md)

        if workflows:
            parts.append("")
            parts.append("# Workflows")
            parts.append("")
            parts.append(
                "Before starting any task, match it against the workflows below. "
                "Call `get_workflow(workflow_id)` from the knktx MCP server "
                "to retrieve the full steps for the matching workflow and follow it step-by-step."
            )
            parts.append("")
            for wf in workflows:
                name = _sanitize_markers(wf.get("name", "(unnamed)"))
                wf_id = wf.get("id", "")
                desc = _sanitize_markers(wf.get("description", ""))
                suffix = f" — {desc}" if desc else ""
                parts.append(f"- **{name}** (`{wf_id}`){suffix}")
        elif not rules_md:
            parts.append("No rules or workflows configured.")

    parts.append(MARKER_END)
    return "\n".join(parts)


def _inject_section(target: Path, section: str) -> None:
    """Inject or replace the knktx section in an agent's instructions file."""
    try:
        if target.exists():
            content = target.read_text(encoding="utf-8")
            start_idx = content.find(MARKER_START)
            end_idx = content.find(MARKER_END)

            if start_idx != -1 and end_idx != -1 and end_idx > start_idx:
                # Replace existing section
                end_idx += len(MARKER_END)
                new_content = content[:start_idx] + section + content[end_idx:]
            elif start_idx != -1 or end_idx != -1:
                # Orphaned marker — warn and replace entire file section
                print(f"Warning: Found orphaned knktx marker in {target.name}. Replacing.", file=sys.stderr)
                # Remove any orphaned markers before appending fresh section
                cleaned = content.replace(MARKER_START, "").replace(MARKER_END, "")
                new_content = cleaned.rstrip() + "\n\n" + section + "\n"
            else:
                # No markers — append to end
                new_content = content.rstrip() + "\n\n" + section + "\n"
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            new_content = section + "\n"

        target.write_text(new_content, encoding="utf-8")
    except PermissionError:
        print(f"Error: Permission denied writing to {target}.", file=sys.stderr)
        sys.exit(1)
    except OSError as e:
        print(f"Error: Could not write to {target}: {e}", file=sys.stderr)
        sys.exit(1)


# ---------------------------------------------------------------------------
# Skills installation
# ---------------------------------------------------------------------------


def _sanitize_yaml_value(value: str) -> str:
    """Strip newlines and escape double quotes for safe YAML interpolation."""
    return value.replace("\n", " ").replace("\r", "").replace('"', '\\"')


def _build_skill_md(skill: dict) -> str:
    """Build a SKILL.md file from a skill dict (frontmatter + body content)."""
    lines: list[str] = ["---"]

    name = _sanitize_yaml_value(skill.get("slug", skill.get("name", "unnamed")))
    lines.append(f"name: {name}")

    desc = skill.get("description")
    if desc:
        lines.append(f'description: "{_sanitize_yaml_value(desc)}"')

    if skill.get("user_invocable"):
        lines.append("user-invocable: true")

    allowed = skill.get("allowed_tools")
    if allowed is not None:
        if allowed:
            tools_str = ", ".join(_sanitize_yaml_value(str(t)) for t in allowed)
            lines.append(f"allowed-tools: [{tools_str}]")
        else:
            lines.append("allowed-tools: []")

    lines.append("---")
    lines.append("")

    body = skill.get("content", "")
    if body:
        lines.append(body)

    return "\n".join(lines)


def _skills_base(agent: AgentDef, project: bool) -> Path:
    """Return the base directory for skill files."""
    if project and agent.project_skills_dir:
        return Path.cwd() / agent.project_skills_dir
    return _agent_dir(agent, project) / agent.skills_dir


def _install_skills(agent: AgentDef, skills: list[dict], *, project: bool) -> int:
    """Write SKILL.md files to disk. Returns count of installed skills."""
    base = _skills_base(agent, project)

    count = 0
    skipped = 0
    for skill in skills:
        slug = skill.get("slug")
        if not slug:
            name = skill.get("name", "<unknown>")
            print(f"Warning: Skipping skill with no slug: {name}", file=sys.stderr)
            skipped += 1
            continue
        if not _SLUG_RE.match(slug):
            print(f"Warning: Skipping skill with invalid slug: {slug!r}", file=sys.stderr)
            skipped += 1
            continue
        skill_dir = base / slug
        try:
            skill_dir.mkdir(parents=True, exist_ok=True)
            skill_file = skill_dir / "SKILL.md"
            content = _build_skill_md(skill)
            skill_file.write_text(content, encoding="utf-8")
            count += 1
        except PermissionError:
            print(f"Error: Permission denied writing skill '{slug}' to {skill_dir}.", file=sys.stderr)
            skipped += 1
        except OSError as e:
            print(f"Error: Could not write skill '{slug}' to {skill_dir}: {e}", file=sys.stderr)
            skipped += 1

    return count


class _AgentNotFoundError(Exception):
    """Raised when the agent's CLI binary is not found."""


_ENV_KEY_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _build_mcp_cmd(agent: AgentDef, name: str, config: dict) -> list[str]:
    """Build the agent-specific CLI command to install an MCP server config.

    - Claude: ``claude mcp add-json <name> '<json>' --scope user``
      Claude receives the full JSON blob — no ``command`` validation needed.
    - Gemini: ``gemini mcp add <name> <cmd> [args...] -s user [-e K=V ...]``
    - Codex: ``codex mcp add <name> -- <cmd> [args...] [--env K=V ...]``
    """
    if agent.key == "claude":
        # Claude uses add-json with the raw config blob — no decomposition needed
        return [agent.binary, "mcp", "add-json", name, json.dumps(config), "--scope", "user"]

    command = config.get("command") or ""
    args = config.get("args") or []
    env = config.get("env") or {}

    if not command:
        raise ValueError(f"MCP config '{name}' missing 'command' field")
    if not isinstance(args, list):
        raise ValueError(f"MCP config '{name}' has invalid 'args' (expected list)")
    if not isinstance(env, dict):
        raise ValueError(f"MCP config '{name}' has invalid 'env' (expected dict)")

    # Validate env keys to prevent malformed -e KEY=VALUE strings
    for k in env:
        if not _ENV_KEY_RE.match(str(k)):
            raise ValueError(f"MCP config '{name}' has invalid env key: {k!r}")

    if agent.key == "gemini":
        cmd = [agent.binary, "mcp", "add", name, command, *args, "-s", "user"]
        for k, v in env.items():
            cmd.extend(["-e", f"{k}={v}"])
        return cmd

    if agent.key == "codex":
        cmd = [agent.binary, "mcp", "add", name]
        for k, v in env.items():
            cmd.extend(["--env", f"{k}={v}"])
        cmd.extend(["--", command, *args])
        return cmd

    raise ValueError(f"Unknown agent key: {agent.key}")


def _build_mcp_remove_cmd(agent: AgentDef, name: str) -> list[str]:
    """Build the agent-specific CLI command to remove an MCP server config."""
    if agent.key == "claude":
        return [agent.binary, "mcp", "remove", name, "-s", "user"]
    if agent.key == "gemini":
        return [agent.binary, "mcp", "remove", name, "-s", "user"]
    if agent.key == "codex":
        return [agent.binary, "mcp", "remove", name]
    return [agent.binary, "mcp", "remove", name]


def _remove_mcp_config(agent: AgentDef, name: str) -> None:
    """Remove an existing MCP config if present. No-op if it doesn't exist."""
    try:
        subprocess.run(
            _build_mcp_remove_cmd(agent, name),
            capture_output=True, text=True, timeout=30,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass


def _install_mcp_config(agent: AgentDef, name: str, config: dict) -> bool:
    """Install a single MCP server config via the agent's native CLI.

    Removes any existing config with the same name first to avoid "already exists"
    errors on re-init.

    Raises :class:`_AgentNotFoundError` when the agent binary is missing
    so callers can bail out of loops instead of repeating the same warning.
    """
    if not _MCP_NAME_RE.match(name):
        print(f"Warning: Refusing MCP config with invalid name: {name!r}", file=sys.stderr)
        return False

    try:
        cmd = _build_mcp_cmd(agent, name, config)
    except ValueError as e:
        print(f"Warning: {e}", file=sys.stderr)
        return False

    _remove_mcp_config(agent, name)

    try:
        subprocess.run(cmd, check=True, capture_output=True, text=True, timeout=60)
        return True
    except FileNotFoundError:
        raise _AgentNotFoundError(f"'{agent.binary}' CLI not found")
    except subprocess.CalledProcessError as e:
        detail = e.stderr.strip() or "(no output)"
        print(f"Warning: Failed to install MCP config '{name}' (exit code {e.returncode}): {detail}", file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print(f"Warning: MCP config '{name}' installation timed out after 60s.", file=sys.stderr)
        return False


def _install_mcp_configs(agent: AgentDef, configs: list[dict]) -> tuple[int, int]:
    """Install MCP server configs. Returns (success_count, total_attempted)."""
    count = 0
    attempted = 0
    for cfg in configs:
        name = cfg.get("name", "(unnamed)")
        if name == "knktx":
            print(f"  > Skipped: {name} (reserved, managed by CLI)", file=sys.stderr)
            continue
        config = cfg.get("config")
        if not config or not isinstance(config, dict):
            print(f"Warning: Skipping MCP config '{name}' — no valid config.", file=sys.stderr)
            continue
        if not _MCP_NAME_RE.match(name):
            print(f"Warning: Skipping MCP config with invalid name: {name!r}", file=sys.stderr)
            continue

        attempted += 1
        try:
            if _install_mcp_config(agent, name, config):
                count += 1
                print(f"  > Installed: {name}")
        except _AgentNotFoundError:
            print(f"Warning: '{agent.binary}' CLI not found — cannot install MCP configs.", file=sys.stderr)
            break

    return count, attempted


def _execute_plugin(name: str, content: str) -> bool:
    """Execute a plugin's content as a shell script.

    WARNING: *content* comes from the knktx API and runs with the user's shell
    privileges.  Callers must ensure user consent before invocation.

    On Windows, uses PowerShell instead of cmd.exe to support ``#`` comments in plugin scripts.
    """
    if sys.platform == "win32":
        cmd: str | list[str] = ["powershell", "-NoProfile", "-Command", content]
        use_shell = False
    else:
        cmd = content
        use_shell = True
    try:
        subprocess.run(
            cmd,
            shell=use_shell,
            check=True,
            capture_output=True,
            text=True,
            timeout=300,
        )
        return True
    except subprocess.CalledProcessError as e:
        detail = e.stderr.strip() if e.stderr else ""
        msg = f"Warning: Plugin '{name}' failed (exit code {e.returncode})."
        if detail:
            msg += f" {detail}"
        print(msg, file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        print(f"Warning: Plugin '{name}' timed out after 300s.", file=sys.stderr)
        return False


def _execute_plugins(plugins: list[dict], *, auto: bool = False) -> tuple[int, int]:
    """Execute plugin scripts, optionally without per-plugin confirmation.

    When *auto* is False (default), each plugin's content is displayed and the
    user must confirm before execution.  When *auto* is True, all plugins run
    without individual prompts.

    Returns (success_count, attempted_count).
    """
    count = 0
    attempted = 0
    for plugin in plugins:
        name = plugin.get("name", "(unnamed)")
        content = plugin.get("content", "").strip()
        if not content:
            print(f"Warning: Skipping plugin '{name}' — no content.", file=sys.stderr)
            continue

        if auto:
            print(f"  Executing: {name}")
        else:
            print(f"\n  Plugin: {name}")
            print("  Commands:")
            for line in content.splitlines():
                print(f"    {line}")
            print()
            if not _confirm(f"  Execute plugin '{name}'?", default_yes=False):
                print(f"  > Skipped: {name}")
                continue

        attempted += 1
        if _execute_plugin(name, content):
            count += 1
            print(f"  > Executed: {name}")
        else:
            print(f"  > Failed: {name}")

    return count, attempted


def _patch_claude_json_mcp(api_url: str, api_key: str) -> None:
    """Directly patch the knktx entry in ~/.claude.json if it exists with a stale key.

    ``claude mcp add-json --scope user`` may write to ~/.claude/settings.json on
    newer Claude Code versions, leaving a stale entry in ~/.claude.json that takes
    precedence.  This belt-and-suspenders patch ensures the key is correct everywhere.
    """
    config_path = Path.home() / ".claude.json"
    try:
        if not config_path.exists():
            return
        data = json.loads(config_path.read_text(encoding="utf-8"))
        servers = data.get("mcpServers")
        if not isinstance(servers, dict):
            return
        knktx = servers.get("knktx")
        if not isinstance(knktx, dict):
            return
        env = knktx.get("env")
        if not isinstance(env, dict):
            return
        if env.get("KNKTX_API_KEY") == api_key and env.get("KNKTX_API_URL") == api_url:
            return  # Already correct
        env["KNKTX_API_KEY"] = api_key
        env["KNKTX_API_URL"] = api_url
        config_path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    except (json.JSONDecodeError, OSError, PermissionError):
        pass  # Best-effort — the CLI command is the primary mechanism


def _configure_mcp(agent: AgentDef, api_url: str, api_key: str) -> bool:
    """Configure the knktx MCP server via the agent's native CLI."""
    mcp_config = {
        "type": "stdio",
        "command": "uvx",
        "args": ["--from", "knktx", "knktx-mcp"],
        "env": {
            "KNKTX_API_URL": api_url,
            "KNKTX_API_KEY": api_key,
        },
    }
    try:
        ok = _install_mcp_config(agent, "knktx", mcp_config)
    except _AgentNotFoundError:
        print(f"Warning: '{agent.binary}' CLI not found — skipping MCP server configuration.", file=sys.stderr)
        if agent.install_hint:
            print(f"Install {agent.display_name}: {agent.install_hint}", file=sys.stderr)
        return False

    # Belt-and-suspenders: patch ~/.claude.json directly if it has a stale entry
    if agent.key == "claude":
        _patch_claude_json_mcp(api_url, api_key)

    return ok


def _agent_dir(agent: AgentDef, project: bool) -> Path:
    """Return the agent's config directory for the given scope."""
    if project:
        return Path.cwd() / agent.config_dir
    return Path.home() / agent.config_dir


def _resolve_target(agent: AgentDef, project: bool) -> Path:
    """Determine which instructions file to write to (e.g. CLAUDE.md, GEMINI.md, AGENTS.md)."""
    if project and agent.project_instructions_dir is not None:
        return Path.cwd() / agent.project_instructions_dir / agent.instructions_file
    return _agent_dir(agent, project) / agent.instructions_file


_BANNER = """\
\x1b[36m
  ██╗  ██╗███╗   ██╗██╗  ██╗████████╗██╗  ██╗
  ██║ ██╔╝████╗  ██║██║ ██╔╝╚══██╔══╝╚██╗██╔╝
  █████╔╝ ██╔██╗ ██║█████╔╝    ██║    ╚███╔╝
  ██╔═██╗ ██║╚██╗██║██╔═██╗    ██║    ██╔██╗
  ██║  ██╗██║ ╚████║██║  ██╗   ██║   ██╔╝ ██╗
  ╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝
\x1b[0m\x1b[2m  One source of truth for all your agents\x1b[0m
"""


def _section(title: str) -> str:
    return f"\n{_c('──', 'dim')} {_c(title, 'cyan', 'bold')} {_c('──', 'dim')}"


def cmd_update(args: argparse.Namespace) -> None:
    """Re-inject rules and workflows into the agent's instructions file. Also reconfigures MCP if the key changed."""
    print(_BANNER)

    api_key, key_source = _resolve_api_key(args)
    api_url = _resolve_api_url()

    client, api_key, settings_rules = _connect(api_url, api_key, key_source)
    try:
        print(_c("  Connected", "green"))

        agent = _resolve_agent(args)
        api_mode = _read_injection_mode(settings_rules)
        mode = _resolve_mode(args, api_mode)
        project = _resolve_project(args)

        rules = _fetch_rules(client, agent=agent.key)
        workflows = _fetch_workflows(client, agent=agent.key)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            print(_c("Error: Invalid API key.", "red"), file=sys.stderr)
        else:
            print(_c(f"Error: API returned {e.response.status_code}.", "red"), file=sys.stderr)
        sys.exit(1)
    except httpx.RequestError as e:
        print(_c(f"Error: Could not reach API at {api_url}: {e}", "red"), file=sys.stderr)
        sys.exit(1)
    except (ValueError, json.JSONDecodeError) as e:
        print(_c(f"Error: API returned an invalid response: {e}", "red"), file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()

    agent_label = f' for {_c(agent.display_name, "bold")}'
    scope = "project" if project else "global"
    wf_suffix = "inline" if mode == "full" else "on-demand via MCP"
    print(_section("Rules & Workflows"))
    print(f"  Found {_c(str(len(rules)), 'bold')} rules, {_c(str(len(workflows)), 'bold')} workflows{agent_label}")
    print(f"  Mode: {_c(mode, 'bold')} ({wf_suffix}) · Scope: {_c(scope, 'bold')}")

    section = _render_section(rules, workflows, mode=mode, agent=agent.key)
    target = _resolve_target(agent, project)
    _inject_section(target, section)

    print(_c(f"  ✓ Injected into {target}", "green"))

    # Reconfigure MCP server so the config always has the current key
    mcp_ok = _configure_mcp(agent, api_url, api_key)
    if mcp_ok:
        print(_c("  ✓ MCP server config updated", "green"))

    print(f"\n{_c('✓', 'green')} {_c('Done!', 'green', 'bold')} {_c(str(len(rules)), 'bold')} rules, {_c(str(len(workflows)), 'bold')} workflows injected.")


def cmd_init(args: argparse.Namespace) -> None:
    """Run the full init — rules, workflows, skills, MCP server, configs, plugins."""
    print(_BANNER)

    api_key, key_source = _resolve_api_key(args)
    api_url = _resolve_api_url()

    client, api_key, settings_rules = _connect(api_url, api_key, key_source)
    try:
        print(_c("  Connected", "green"))

        # Resolve interactive options (flags skip their prompts)
        agent = _resolve_agent(args)
        api_mode = _read_injection_mode(settings_rules)
        mode = _resolve_mode(args, api_mode)
        project = _resolve_project(args)

        agent_label = f' for {_c(agent.display_name, "bold")}'

        # Fetch entities
        rules = _fetch_rules(client, agent=agent.key)
        workflows = _fetch_workflows(client, agent=agent.key)
        skills = _fetch_enabled(client, "/skills", agent=agent.key)
        mcp_configs = _fetch_enabled(client, "/mcp-configs", agent=agent.key)
        plugins = _fetch_enabled(client, "/plugins", agent=agent.key)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            print(_c("Error: Invalid API key.", "red"), file=sys.stderr)
        else:
            print(_c(f"Error: API returned {e.response.status_code}.", "red"), file=sys.stderr)
        sys.exit(1)
    except httpx.RequestError as e:
        print(_c(f"Error: Could not reach API at {api_url}: {e}", "red"), file=sys.stderr)
        sys.exit(1)
    except (ValueError, json.JSONDecodeError) as e:
        print(_c(f"Error: API returned an invalid response: {e}", "red"), file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()

    print(_section("Rules & Workflows"))
    scope = "project" if project else "global"
    wf_suffix = "inline" if mode == "full" else "on-demand via MCP"
    print(f"  Found {_c(str(len(rules)), 'bold')} rules, {_c(str(len(workflows)), 'bold')} workflows{agent_label}")
    print(f"  Mode: {_c(mode, 'bold')} ({wf_suffix}) · Scope: {_c(scope, 'bold')}")

    section = _render_section(rules, workflows, mode=mode, agent=agent.key)
    target = _resolve_target(agent, project)
    _inject_section(target, section)

    print(_c(f"  ✓ Injected into {target}", "green"))

    print(_section("Skills"))
    skills_installed = 0
    if skills:
        print(f"  Found {_c(str(len(skills)), 'bold')} skills:")
        for s in skills:
            name = s.get("name", "(unnamed)")
            desc = s.get("description", "")
            slug = s.get("slug", "")
            invocable = f" {_c(f'/{slug}', 'cyan')}" if s.get("user_invocable") and slug else ""
            line = f"    {name}{invocable}"
            if desc:
                line += f" {_c(f'— {desc}', 'dim')}"
            print(line)

        should_install = args.yes or _confirm("  Install skills?", default_yes=True)
        if should_install:
            skills_installed = _install_skills(agent, skills, project=project)
            skill_base = _skills_base(agent, project)
            print(_c(f"  ✓ Installed {skills_installed} skills to {skill_base}/", "green"))
        else:
            print(_c("  → Skipped", "yellow"))
    else:
        print(_c("  No skills found.", "dim"))

    # ---- knktx MCP Server ----
    print(_section("knktx MCP Server"))
    mcp_ok = _configure_mcp(agent, api_url, api_key)
    if mcp_ok:
        print(_c("  ✓ MCP server configured (scope: user)", "green"))
    else:
        print(_c("  → Skipped (see warnings above)", "yellow"))

    # ---- User MCP Configs ----
    mcp_configs_installed = 0
    mcp_configs_attempted = 0
    print(_section("MCP Configs"))
    if mcp_configs:
        print(f"  Found {_c(str(len(mcp_configs)), 'bold')} MCP configs:")
        for c in mcp_configs:
            name = c.get("name", "(unnamed)")
            desc = c.get("description", "")
            line = f"    {name}"
            if desc:
                line += f" {_c(f'— {desc}', 'dim')}"
            print(line)

        should_install_mcp = args.yes or _confirm("  Install MCP configs?", default_yes=True)
        if should_install_mcp:
            mcp_configs_installed, mcp_configs_attempted = _install_mcp_configs(agent, mcp_configs)
            failed = mcp_configs_attempted - mcp_configs_installed
            if failed:
                print(_c(f"  ✓ Installed {mcp_configs_installed}/{mcp_configs_attempted} MCP configs ", "green") + _c(f"({failed} failed)", "yellow"))
            else:
                print(_c(f"  ✓ Installed {mcp_configs_installed} MCP configs", "green"))
        else:
            print(_c("  → Skipped", "yellow"))
    else:
        print(_c("  No MCP configs found.", "dim"))

    # ---- Plugins ----
    plugins_executed = 0
    plugins_attempted = 0
    print(_section("Plugins"))
    if plugins:
        print(f"  Found {_c(str(len(plugins)), 'bold')} plugins:")
        for p in plugins:
            name = p.get("name", "(unnamed)")
            desc = p.get("description", "")
            line = f"    {name}"
            if desc:
                line += f" {_c(f'— {desc}', 'dim')}"
            print(line)

        auto_plugins = args.yes and args.plugins
        if auto_plugins:
            plugins_executed, plugins_attempted = _execute_plugins(plugins, auto=True)
        else:
            should_run = _confirm("  Review and run plugins?", default_yes=False)
            if should_run:
                plugins_executed, plugins_attempted = _execute_plugins(plugins)
            else:
                print(_c("  → Skipped", "yellow"))
    else:
        print(_c("  No plugins found.", "dim"))

    # ---- Summary ----
    parts = [f"{_c(str(len(rules)), 'bold')} rules", f"{_c(str(len(workflows)), 'bold')} workflows"]
    if skills_installed:
        parts.append(f"{_c(str(skills_installed), 'bold')} skills")
    if mcp_configs_attempted:
        failed = mcp_configs_attempted - mcp_configs_installed
        if failed:
            parts.append(f"{_c(str(mcp_configs_installed), 'bold')}/{mcp_configs_attempted} MCP configs")
        else:
            parts.append(f"{_c(str(mcp_configs_installed), 'bold')} MCP configs")
    if plugins_attempted:
        failed = plugins_attempted - plugins_executed
        if failed:
            parts.append(f"{_c(str(plugins_executed), 'bold')}/{plugins_attempted} plugins executed")
        else:
            parts.append(f"{_c(str(plugins_executed), 'bold')} plugins executed")
    print(f"\n{_c('✓', 'green')} {_c('Done!', 'green', 'bold')} {', '.join(parts)} applied.")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="knktx",
        description="Bootstrap agents with knktx rules, workflows, skills, MCP configs, and plugins.",
    )
    try:
        from importlib.metadata import version as _pkg_version
        _ver = _pkg_version("knktx")
    except Exception:
        _ver = "unknown"
    parser.add_argument("--version", action="version", version=f"%(prog)s {_ver}")
    sub = parser.add_subparsers(dest="command")

    # Shared arguments for init and update
    def _add_common_args(p: argparse.ArgumentParser) -> None:
        p.add_argument(
            "--key",
            help="API key (prefer KNKTX_API_KEY env var to avoid shell history exposure)",
        )
        p.add_argument("--project", action="store_true", help="Write to project-level config instead of global")
        p.add_argument(
            "--mode",
            choices=list(VALID_MODES),
            default=None,
            help="full = all rules+workflows inline; soft = rules inline, workflows via MCP (default: from settings, or full)",
        )
        p.add_argument(
            "--agent",
            default=None,
            type=str.lower,
            help="Filter entities to this agent (e.g. claude, gemini, codex)",
        )
        p.add_argument(
            "-y", "--yes",
            action="store_true",
            help="Auto-accept prompts for skills, MCP configs, scope, mode, and agent (plugins still require --plugins)",
        )
        p.add_argument(
            "--plugins",
            action="store_true",
            help="With -y, also auto-execute plugins (requires explicit opt-in due to shell execution)",
        )

    init_parser = sub.add_parser("init", help="Full setup — rules, workflows, skills, MCP server, configs, plugins")
    _add_common_args(init_parser)

    update_parser = sub.add_parser("update", help="Re-inject rules and workflows (no MCP, skills, or plugins)")
    _add_common_args(update_parser)

    args = parser.parse_args()

    if args.command == "init":
        cmd_init(args)
    elif args.command == "update":
        cmd_update(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
