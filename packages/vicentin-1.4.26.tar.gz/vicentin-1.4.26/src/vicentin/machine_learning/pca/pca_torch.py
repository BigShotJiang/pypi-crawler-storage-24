from typing import Optional

import torch

from vicentin.kernels import Kernel, LinearKernel


def PCA(
    X: torch.Tensor | Kernel,
    n_components: Optional[int] = None,
    var: Optional[float] = None,
):
    if isinstance(X, Kernel):
        kernel = X
    else:
        kernel = LinearKernel(X).center()

    trace_K = kernel.trace()
    max_k = kernel.N - 1

    if n_components is None:
        if var is None:
            current_k = max_k
        else:
            current_k = 5
    else:
        current_k = n_components

    def matmat(v):
        return kernel @ v

    q = None

    while True:
        current_k = min(current_k, max_k)

        if q is None or q.shape[1] != current_k:
            q = torch.randn(
                (kernel.N, current_k),
                device=kernel.X.device,
                dtype=kernel.X.dtype,
            )

        eigenvalues, eigenvectors = torch.lobpcg(A=matmat, k=current_k, X=q)

        idx = torch.argsort(eigenvalues, descending=True)
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        if var is not None:
            cum_var_ratio = torch.cumsum(eigenvalues, dim=0) / trace_K

            mask = cum_var_ratio <= var
            n_to_keep = torch.sum(mask).item() + 1
            n_to_keep = min(int(n_to_keep), current_k)

            if cum_var_ratio[n_to_keep - 1] >= var or current_k >= max_k:
                eigenvalues = eigenvalues[:n_to_keep]
                eigenvectors = eigenvectors[:, :n_to_keep]
                break
            else:
                q = torch.randn(
                    (kernel.N, current_k * 2),
                    device=kernel.X.device,
                    dtype=kernel.X.dtype,
                )
                q[:, :current_k] = eigenvectors

                current_k = min(current_k * 2, max_k)

    eigenvectors = eigenvectors / torch.sqrt(
        torch.clamp(eigenvalues, min=1e-12)
    )

    return eigenvalues, eigenvectors
