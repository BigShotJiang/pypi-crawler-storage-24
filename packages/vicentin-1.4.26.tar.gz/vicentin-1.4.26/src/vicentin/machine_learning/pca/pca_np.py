from typing import Optional

import numpy as np
from scipy.sparse.linalg import LinearOperator, eigsh

from vicentin.kernels import Kernel, LinearKernel


def PCA(
    X: np.ndarray | Kernel,
    n_components: Optional[int] = None,
    var: Optional[float] = None,
):
    if isinstance(X, Kernel):
        kernel = X
    else:
        kernel = LinearKernel(X).center()

    trace_K = kernel.trace()
    max_k = kernel.N - 1

    if n_components is None:
        if var is None:
            current_k = max_k
        else:
            current_k = 5
    else:
        current_k = n_components

    v0 = None

    matvec = lambda v: (kernel @ v).reshape(-1)
    K_op = LinearOperator(shape=kernel.shape, matvec=matvec, dtype=np.float64)

    while True:
        current_k = min(current_k, max_k)

        eigenvalues, eigenvectors = eigsh(K_op, k=current_k, which="LM", v0=v0)

        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]

        if var is not None:
            cum_var_ratio = np.cumsum(eigenvalues) / trace_K

            mask = cum_var_ratio <= var
            n_to_keep = np.sum(mask) + 1

            n_to_keep = min(n_to_keep, current_k)

            if cum_var_ratio[n_to_keep - 1] >= var or current_k >= max_k:
                eigenvalues = eigenvalues[:n_to_keep]
                eigenvectors = eigenvectors[:, :n_to_keep]
                break
            else:
                v0 = eigenvectors[:, 0]
                current_k = min(current_k * 2, max_k)

    eigenvectors = eigenvectors / np.sqrt(np.maximum(eigenvalues, 1e-12))

    return eigenvalues, eigenvectors
