from typing import Any, Optional
from abc import ABC, abstractmethod


from vicentin.utils import Dispatcher

disp_kernel_backend = Dispatcher()
disp_eye = Dispatcher()


try:
    from .kernel_np import KernelBackendNumpy
    import numpy as np

    disp_kernel_backend.register("numpy", KernelBackendNumpy)
    disp_eye.register("numpy", lambda n, x: np.eye(n, dtype=x.dtype))
except ImportError:
    pass

try:
    from .kernel_torch import KernelBackendTorch
    import torch

    disp_kernel_backend.register("torch", KernelBackendTorch)
    disp_eye.register(
        "torch", lambda n, x: torch.eye(n, device=x.device, dtype=x.dtype)
    )
except ImportError:
    pass


class Kernel(ABC):
    def __init__(
        self,
        X: Optional[Any] = None,
        alpha: float = 1e-6,
        backend: Optional[str] = None,
        **kwargs,
    ) -> None:
        super().__init__()

        disp_kernel_backend.detect_backend(X, backend)
        X = disp_kernel_backend.cast_values(X)

        self.backend = disp_kernel_backend(self._compute, X, **kwargs)
        self.alpha = alpha

        self.X = self.backend.X
        self.N = self.backend.N

    def center(self):
        return CenteredKernel(self)

    @abstractmethod
    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        pass

    def __setattr__(self, name: str, value: Any) -> None:
        if (
            type(value).__name__ == "Parameter"
            and "torch" in type(value).__module__
        ):
            if hasattr(self, "backend") and hasattr(
                self.backend, "register_parameter"
            ):
                self.backend.register_parameter(name, value)

        super().__setattr__(name, value)

    def apply(self, X: Any, v: Any) -> Any:
        return self.backend.apply_v(X, v)

    def trace(self) -> float:
        """
        Efficiently computes the trace of the kernel matrix by evaluating
        block-diagonal chunks. Avoids O(N^2) memory and compute overhead.
        """
        return self.backend.trace() + self.N * self.alpha

    @property
    def T(self):
        return self

    def __getitem__(self, key) -> Any:
        return self.backend[key]

    def __matmul__(self, v) -> Any:
        return self.backend @ v

    def __call__(self, x: Any, y: Optional[Any] = None) -> Any:
        K_xy = self.backend(x, y)

        if y is None or x.shape == y.shape:
            n = K_xy.shape[0]
            disp_eye.detect_backend(K_xy)

            K_xy = K_xy + self.alpha * disp_eye(n, K_xy)

        return K_xy

    def __add__(self, other):
        if isinstance(other, Kernel):
            return SumKernel(self, other)
        elif isinstance(other, (int, float)):
            return SumKernel(self, ConstantKernel(self.backend.X, other))

        return SumKernel(self, MatrixKernel(self.backend.X, other))

    def __radd__(self, other):
        return self.__add__(other)

    def __mul__(self, other):
        if isinstance(other, Kernel):
            return ProductKernel(self, other)

        return ScaledKernel(self, other)

    def __pow__(self, exponent):
        return PowerKernel(self, exponent)

    def __rmul__(self, other):
        return self.__mul__(other)

    def __truediv__(self, other):
        if isinstance(other, (int, float)):
            return ScaledKernel(self, float(1 / other))

        return NotImplemented

    @property
    def shape(self):
        return (self.N, self.N)


class SumKernel(Kernel):
    def __init__(self, k1: Kernel, k2: Kernel, **kwargs):
        self.k1 = k1
        self.k2 = k2

        super().__init__(k1.X, **kwargs)

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.k1(x, y) + self.k2(x, y)


class ConstantKernel(Kernel):
    def __init__(self, X: Any, c: float, **kwargs):
        super().__init__(X, **kwargs)
        self.c = float(c)

        self.disp_full = Dispatcher()

        try:
            import numpy as np

            self.disp_full.register("numpy", np.full)
        except ImportError:
            pass

        try:
            import torch

            self.disp_full.register("torch", torch.full)
        except ImportError:
            pass

    def _compute(self, x: Any, y: Optional[Any] = None):
        self.disp_full.detect_backend(x)

        if y is None:
            n = x.shape[0] if getattr(x, "ndim", 0) > 0 else 1
            return self.disp_full(n, self.c)

        return self.c


class ProductKernel(Kernel):
    def __init__(self, k1: Kernel, k2: Kernel, **kwargs):
        super().__init__(k1.X, **kwargs)

        self.k1 = k1
        self.k2 = k2

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.k1(x, y) * self.k2(x, y)


class ScaledKernel(Kernel):
    def __init__(self, K: Kernel, c: float, **kwargs):
        super().__init__(K.X, **kwargs)

        self.K = K
        self.c = c

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.c * self.K(x, y)


class PowerKernel(Kernel):
    def __init__(self, K: Kernel, d: float, **kwargs):
        super().__init__(K.X, **kwargs)

        self.K = K
        self.d = d

    def _compute(self, x: Any, y: Optional[Any] = None):
        return self.K(x, y) ** self.d


class CenteredKernel(Kernel):
    def __init__(self, K: Kernel, **kwargs):
        super().__init__(K.X, **kwargs)

        self.K = K

        self.row_means = None
        self.mean = None

    def _compute_training_statistics(self):
        n = self.N

        if "torch" in str(type(self.X)):
            import torch

            ones = torch.ones((n, 1), device=self.X.device, dtype=self.X.dtype)
        else:
            import numpy as np

            ones = np.ones((n, 1))

        sum_rows = self.K @ ones
        self.row_means = sum_rows.squeeze() / n
        self.mean = self.row_means.mean()

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        if self.row_means is None or self.mean is None:
            self._compute_training_statistics()

        K_xy = self.K(x, y)

        K_xX = self.K(x, self.X)
        x_means = K_xX.mean(axis=1)

        if getattr(x_means, "ndim", 0) > 0:
            x_means = x_means[:, None]

        if y is None and self.row_means is not None:
            y_means = self.row_means[None, :]
        else:
            K_Xy = self.K(self.X, y)
            y_means = K_Xy.mean(axis=0)

            if getattr(y_means, "ndim", 0) > 0:
                y_means = y_means[None, :]

        return K_xy - x_means - y_means + self.mean

    def trace(self) -> float:
        if self.mean is None:
            self._compute_training_statistics()

        return self.K.trace() - (self.N * self.mean)


class MatrixKernel(Kernel):
    def __init__(self, X: Any, M: Any, **kwargs):
        super().__init__(X, **kwargs)
        self.M = M
        self.disp_idx = Dispatcher()

        try:
            import numpy as np

            self.disp_idx.register(
                "numpy", lambda x: np.where(np.all(self.X == x, axis=1))[0]
            )
        except ModuleNotFoundError:
            pass

        try:
            import torch

            self.disp_idx.register(
                "torch", lambda x: torch.where(torch.all(self.X == x, dim=1))[0]
            )
        except ModuleNotFoundError:
            pass

    def _compute(self, x: Any, y: Optional[Any] = None) -> Any:
        self.disp_idx.detect_backend(x)

        i = self.disp_idx(x)

        if y is None:
            return self.M[i]

        j = self.disp_idx(y)

        return self.M[i, j]
