"""Data types returned by the Bank of Bots API."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Agent:
    id: str
    name: str
    operator_id: str
    status: str
    budget: int
    created_at: str
    updated_at: str


@dataclass
class APIKeyRecord:
    id: str
    key_prefix: str
    role: str
    scopes: list[str] = field(default_factory=list)
    name: str = ""
    agent_id: str = ""
    operator_id: str = ""
    created_at: str = ""
    last_used_at: str = ""
    revoked_at: str = ""


@dataclass
class AgentCreditResponse:
    """Deprecated: corresponds to the removed /agents/{id}/credit endpoint.
    Use the BOB Score response from get_score() instead."""
    agent_id: str
    score: int
    tier: str
    reason: str
    base_spend_limit: int = 0
    effective_spend_limit: int = 0
    base_rate_limit: int = 0
    effective_rate_limit: int = 0
    tier_multiplier: float = 1.0
    credit_tier_enabled: bool = False
    snapshot_at: str = ""


@dataclass
class AgentNodeBinding:
    id: str
    agent_id: str
    wallet_id: str
    rail: str
    node_pubkey: str
    status: str = "verified"
    verified_at: str = ""
    created_at: str = ""
    updated_at: str = ""


@dataclass
class CreditEvent:
    id: str
    agent_id: str
    event_type: str
    score_delta: int
    amount: int = 0
    currency: str = ""
    rail: str = ""
    status: str = ""
    reason: str = ""
    metadata: str = "{}"
    created_at: str = ""


@dataclass
class InboxEvent:
    id: str
    agent_id: str
    event_type: str
    amount: int
    currency: str
    rail: str
    status: str
    payment_address_id: str = ""
    payment_id: str = ""
    payment_intent_id: str = ""
    sender_agent_id: str = ""
    metadata: str = "{}"
    created_at: str = ""


@dataclass
class DirectoryEntry:
    handle: str
    score: int
    tier: str
    tier_color: str


@dataclass
class PublicAgentMessage:
    id: str
    sender_agent_id: str
    recipient_agent_id: str
    body: str
    created_at: str
    sender_handle: str = ""
    recipient_handle: str = ""
    proof_import_id: str = ""


@dataclass
class PaymentIntent:
    id: str
    agent_id: str
    destination_type: str
    destination_ref: str
    amount: int
    currency: str
    status: str
    operator_id: str = ""
    execution_mode: str = "auto"
    pinned_rail: str = ""
    pinned_wallet_id: str = ""
    priority: str = "balanced"
    max_fee: int = 0
    latest_settlement_by: str = ""
    selected_quote_id: str = ""
    metadata: str = "{}"
    created_at: str = ""
    updated_at: str = ""


@dataclass
class PaymentIntentProof:
    id: str
    intent_id: str
    proof_type: str
    proof_ref: str
    verification_status: str
    rail: str = ""
    verification_reason: str = ""
    metadata: str = "{}"
    created_at: str = ""
    verified_at: str = ""
    credit: "ProofCreditOutcome | None" = None


@dataclass
class PaymentProofOwnershipChallenge:
    id: str
    challenge_type: str
    agent_id: str
    rail: str
    nonce: str
    message: str
    expires_at: str
    wallet_id: str = ""
    intent_id: str = ""
    proof_type: str = ""
    proof_ref: str = ""
    bound_node_pubkey: str = ""
    used_at: str = ""
    created_at: str = ""


@dataclass
class ProofCreditOutcome:
    awarded: bool
    delta: int
    tier: str = ""
    score: int = 0
    reason: str = ""
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class HistoricalPaymentProofImport:
    id: str
    agent_id: str
    proof_type: str
    proof_ref: str
    rail: str
    currency: str
    amount: int
    direction: str
    verification_status: str
    confidence_tier: str
    confidence_score: int
    sender_address: str = ""
    recipient_address: str = ""
    occurred_at: str = ""
    counterparty_ref: str = ""
    sender_address: str = ""
    recipient_address: str = ""
    verification_reason: str = ""
    metadata: str = "{}"
    created_at: str = ""
    verified_at: str = ""
    credit: ProofCreditOutcome | None = None


@dataclass
class AgentWallet:
    id: str
    agent_id: str
    operator_id: str
    rail: str
    address: str
    status: str
    key_fingerprint: str = ""
    created_at: str = ""
    revoked_at: str = ""


@dataclass
class CurrencyBalance:
    currency: str
    total_inbound: int
    total_outbound: int
    net: int


@dataclass
class CurrencyLimit:
    currency: str
    proven_balance: int
    credit_limit: int
    tier_multiplier: float
    age_factor: float


@dataclass
class CreditLimitResponse:
    limits: list["CurrencyLimit"]
    score: int
    tier: str
    agent_age_days: int


@dataclass
class CompatibilityResult:
    compatible: bool
    api_version: str
    min_cli_version: str
    sdk_version: str


@dataclass
class WebhookSubscriber:
    id: str
    operator_id: str
    url: str
    agent_id: str = ""
    events: list[str] = field(default_factory=list)
    secret: str = ""
    active: bool = True
    failure_count: int = 0
    created_at: str = ""
