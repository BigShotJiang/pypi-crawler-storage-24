"""Internal API endpoint constant library (deprecated operations).

 _______                        __ _______ __        __ __
|   _   .----.-----.--.--.--.--|  |   _   |  |_.----|__|  |--.-----.
|.  1___|   _|  _  |  |  |  |  _  |   1___|   _|   _|  |    <|  -__|
|.  |___|__| |_____|________|_____|____   |____|__| |__|__|__|_____|
|:  1   |                         |:  1   |
|::.. . |   CROWDSTRIKE FALCON    |::.. . |    FalconPy
`-------'                         `-------'

OAuth2 API - Customer SDK

This is free and unencumbered software released into the public domain.

Anyone is free to copy, modify, publish, use, compile, sell, or
distribute this software, either in source code form or as a compiled
binary, for any purpose, commercial or non-commercial, and by any
means.

In jurisdictions that recognize copyright laws, the author or authors
of this software dedicate any and all copyright interest in the
software to the public domain. We make this dedication for the benefit
of the public at large and to the detriment of our heirs and
successors. We intend this dedication to be an overt act of
relinquishment in perpetuity of all present and future rights to this
software under copyright law.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY CLAIM, DAMAGES OR
OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
OTHER DEALINGS IN THE SOFTWARE.

For more information, please refer to <https://unlicense.org>
"""
# pylint: disable=C0302

_data_protection_configuration_endpoints = [
  [
    "entities.classification.get.v2",
    "GET",
    "/data-protection/entities/classifications/v2",
    "Gets the classifications that match the provided ids",
    "data_protection_configuration",
    [
      {
        "maxItems": 100,
        "minItems": 1,
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "IDs of the classifications to get",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.classification.post.v2",
    "POST",
    "/data-protection/entities/classifications/v2",
    "Create classifications",
    "data_protection_configuration",
    [
      {
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.classification.patch.v2",
    "PATCH",
    "/data-protection/entities/classifications/v2",
    "Update classifications",
    "data_protection_configuration",
    [
      {
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.classification.delete.v2",
    "DELETE",
    "/data-protection/entities/classifications/v2",
    "Deletes classifications that match the provided ids",
    "data_protection_configuration",
    [
      {
        "maxItems": 100,
        "minItems": 1,
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "IDs of the classifications to delete",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.cloud-application.get",
    "GET",
    "/data-protection/entities/cloud-applications/v1",
    "Get a particular cloud-application",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The cloud application id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.cloud-application.create",
    "POST",
    "/data-protection/entities/cloud-applications/v1",
    "Persist the given cloud application for the provided entity instance",
    "data_protection_configuration",
    [
      {
        "description": "The cloud-application definition to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.cloud-application.patch",
    "PATCH",
    "/data-protection/entities/cloud-applications/v1",
    "Update a cloud application",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The cloud app id to update.",
        "name": "id",
        "in": "query",
        "required": True
      },
      {
        "description": "The new cloud-application definition",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.cloud-application.delete",
    "DELETE",
    "/data-protection/entities/cloud-applications/v1",
    "Delete cloud application",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The id of the cloud application to delete.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.content-pattern.get",
    "GET",
    "/data-protection/entities/content-patterns/v1",
    "Get a particular content-pattern(s)",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The content-pattern id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.content-pattern.create",
    "POST",
    "/data-protection/entities/content-patterns/v1",
    "Persist the given content pattern for the provided entity instance",
    "data_protection_configuration",
    [
      {
        "description": "Definition of content-pattern to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.content-pattern.patch",
    "PATCH",
    "/data-protection/entities/content-patterns/v1",
    "Update a content pattern",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The id of the content pattern to patch.",
        "name": "id",
        "in": "query",
        "required": True
      },
      {
        "description": "Definition of content-pattern to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.content-pattern.delete",
    "DELETE",
    "/data-protection/entities/content-patterns/v1",
    "Delete content pattern",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The id(s) of the content pattern to delete.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.policy.precedence.post.v1",
    "POST",
    "/data-protection/entities/data-protection-precedence/v1",
    "Update Policy Precedence",
    "data_protection_configuration",
    [
      {
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.enterprise-account.get",
    "GET",
    "/data-protection/entities/enterprise-accounts/v1",
    "Get a particular enterprise-account(s)",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The enterprise-account id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.enterprise-account.create",
    "POST",
    "/data-protection/entities/enterprise-accounts/v1",
    "Persist the given enterprise account for the provided entity instance",
    "data_protection_configuration",
    [
      {
        "description": "Definition of enterprise-account to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.enterprise-account.patch",
    "PATCH",
    "/data-protection/entities/enterprise-accounts/v1",
    "Update a enterprise account",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The id of the enterprise account to update.",
        "name": "id",
        "in": "query",
        "required": True
      },
      {
        "description": "Definition of enterprise-account to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.enterprise-account.delete",
    "DELETE",
    "/data-protection/entities/enterprise-accounts/v1",
    "Delete enterprise account",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The id of the enterprise account to delete.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.file-type.get",
    "GET",
    "/data-protection/entities/file-types/v1",
    "Get a particular file-type",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The file-type id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.sensitivity-label.get-v2",
    "GET",
    "/data-protection/entities/labels/v2",
    "Get sensitivity label matching the IDs (V2)",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The sensitivity label entity id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.sensitivity-label.create-v2",
    "POST",
    "/data-protection/entities/labels/v2",
    "Create new sensitivity label (V2)",
    "data_protection_configuration",
    [
      {
        "description": "Definition of sensitivity label to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.sensitivity-label.delete-v2",
    "DELETE",
    "/data-protection/entities/labels/v2",
    "Delete sensitivity labels matching the IDs (V2)",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The sensitivity label entity id(s) to delete.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application-group.get",
    "GET",
    "/data-protection/entities/local-application-groups/v1",
    "Get particular local application groups",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The local application group id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application-group.create",
    "POST",
    "/data-protection/entities/local-application-groups/v1",
    "Persist the given local application group for the provided entity instance",
    "data_protection_configuration",
    [
      {
        "description": "The local-application group definition to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application-group.patch",
    "PATCH",
    "/data-protection/entities/local-application-groups/v1",
    "Update a local application group",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The local app id to update.",
        "name": "id",
        "in": "query",
        "required": True
      },
      {
        "description": "The new local-application group definition",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application-group.delete",
    "DELETE",
    "/data-protection/entities/local-application-groups/v1",
    "Soft Delete local application. The application won't be visible anymore, but will still be in the database",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The id of the local application group to delete.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application.get",
    "GET",
    "/data-protection/entities/local-applications/v1",
    "Get a particular local application",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The local application id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application.create",
    "POST",
    "/data-protection/entities/local-applications/v1",
    "Persist the given local application for the provided entity instance",
    "data_protection_configuration",
    [
      {
        "description": "The local-application definition to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application.patch",
    "PATCH",
    "/data-protection/entities/local-applications/v1",
    "Update a local application",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The local app id to update.",
        "name": "id",
        "in": "query",
        "required": True
      },
      {
        "description": "The new local-application definition",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.local-application.delete",
    "DELETE",
    "/data-protection/entities/local-applications/v1",
    "Soft Delete local application. The application wont be visible anymore, but will still be in the database",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The id of the local application to delete.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.policy.get.v2",
    "GET",
    "/data-protection/entities/policies/v2",
    "Gets policies that match the provided ids",
    "data_protection_configuration",
    [
      {
        "maxItems": 100,
        "minItems": 1,
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "IDs of the policies to get",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.policy.post.v2",
    "POST",
    "/data-protection/entities/policies/v2",
    "Create policies",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "platform name of the policies to update, either 'win' or 'mac'",
        "name": "platform_name",
        "in": "query",
        "required": True
      },
      {
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.policy.patch.v2",
    "PATCH",
    "/data-protection/entities/policies/v2",
    "Update policies",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "platform name of the policies to update, either 'win' or 'mac'",
        "name": "platform_name",
        "in": "query",
        "required": True
      },
      {
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.policy.delete.v2",
    "DELETE",
    "/data-protection/entities/policies/v2",
    "Deletes policies that match the provided ids",
    "data_protection_configuration",
    [
      {
        "maxItems": 100,
        "minItems": 1,
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "IDs of the policies to delete",
        "name": "ids",
        "in": "query",
        "required": True
      },
      {
        "type": "string",
        "description": "platform name of the policies to update, either 'win' or 'mac'",
        "name": "platform_name",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.web-location.get-v2",
    "GET",
    "/data-protection/entities/web-locations/v2",
    "Get web-location entities matching the provided ID(s)",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "multi",
        "description": "The web-location entity id(s) to get.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "entities.web-location.create-v2",
    "POST",
    "/data-protection/entities/web-locations/v2",
    "Persist the given web-locations",
    "data_protection_configuration",
    [
      {
        "description": "Definition of web-locations to create",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.web-location.patch-v2",
    "PATCH",
    "/data-protection/entities/web-locations/v2",
    "Update a web-location",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The web-location entity id to update.",
        "name": "id",
        "in": "query",
        "required": True
      },
      {
        "description": "Definition of updated web-location",
        "name": "body",
        "in": "body",
        "required": True
      }
    ]
  ],
  [
    "entities.web-location.delete-v2",
    "DELETE",
    "/data-protection/entities/web-locations/v2",
    "Delete web-location",
    "data_protection_configuration",
    [
      {
        "type": "array",
        "items": {
          "type": "string"
        },
        "collectionFormat": "csv",
        "description": "The ids of the web-location to delete.",
        "name": "ids",
        "in": "query",
        "required": True
      }
    ]
  ],
  [
    "queries.classification.get.v2",
    "GET",
    "/data-protection/queries/classifications/v2",
    "Search for classifications that match the provided criteria",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "Filter results by specific attributes , allowed attributes are [name created_at "
        "modified_at properties.content_patterns properties.content_patterns_operator properties.file_types "
        "properties.sensitivity_labels created_by modified_by properties.evidence_duplication_enabled "
        "properties.protection_mode properties.web_sources]",
        "name": "filter",
        "in": "query"
      },
      {
        "maximum": 10000,
        "minimum": 0,
        "type": "integer",
        "description": "The offset to start retrieving records from",
        "name": "offset",
        "in": "query"
      },
      {
        "maximum": 500,
        "minimum": 0,
        "type": "integer",
        "default": 100,
        "description": "The maximum records to return",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The property to sort by, allowed fields are :[name created_at modified_at]",
        "name": "sort",
        "in": "query"
      }
    ]
  ],
  [
    "queries.cloud-application.get-v2",
    "GET",
    "/data-protection/queries/cloud-applications/v2",
    "Get all cloud-application IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "Optional filter for searching cloud applications. Allowed filters are 'name' (string), "
        " 'type' (array of strings representing the tier, accepted values are: integrated, predefined, custom), "
        "'deleted' (boolean), supports_network_inspection (boolean) and 'application_group_id' (string)",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The sort instructions to order by on. Allowed values are 'name' (string), 'type' "
        "(array of strings representing the tier, accepted values are: integrated, predefined, custom), 'deleted' "
        "(boolean) and 'application_group_id' (string)",
        "name": "sort",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ],
  [
    "queries.content-pattern.get-v2",
    "GET",
    "/data-protection/queries/content-patterns/v2",
    "Get all content-pattern IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The filter to use when finding content patterns. Allowed filters are 'name', 'type', "
        "'category', 'region', 'example', 'created_at', 'updated_at' and 'deleted'",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The sort instructions to order by on. Allowed values are 'name', 'type', 'category', "
        "'region', 'created_at', 'updated_at', 'example' and 'deleted'",
        "name": "sort",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ],
  [
    "queries.enterprise-account.get-v2",
    "GET",
    "/data-protection/queries/enterprise-accounts/v2",
    "Get all enterprise-account IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The filter to use when finding enterprise accounts. Allowed filters are 'name', "
        "'application_group_id', 'deleted', 'created_at' and 'updated_at'",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The sort instructions to order by on. Allowed values are 'name', "
        "'application_group_id', 'deleted', 'created_at' and 'updated_at'",
        "name": "sort",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ],
  [
    "queries.file-type.get-v2",
    "GET",
    "/data-protection/queries/file-types/v2",
    "Get all file-type IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The filter to use when finding file types. Allowed filter is 'name', 'created_at' and 'updated_at'",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The sort instructions to order by on. Allowed values are 'name', 'created_at' and 'updated_at'",
        "name": "sort",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ],
  [
    "queries.sensitivity-label.get-v2",
    "GET",
    "/data-protection/queries/labels/v2",
    "Get all sensitivity label IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The filter to use when finding sensitivity labels. The only allowed filters are "
        "'name', 'display_name', 'external_id' and 'deleted'",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The sort instructions to order by on. Allowed values are 'name', 'display_name', "
        "'deleted', 'created_at' and 'updated_at'",
        "name": "sort",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ],
  [
    "queries.local-application-group.get",
    "GET",
    "/data-protection/queries/local-application-groups/v1",
    "Get all local application group IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "Optional filter for searching local application group. Allowed filters are 'name' "
        "(string), is_deleted (boolean), platform (string), 'created_at' and 'updated_at'",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ],
  [
    "queries.local-application.get",
    "GET",
    "/data-protection/queries/local-applications/v1",
    "Get all local-application IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "Optional filter for searching local applications. Allowed filters are 'name' (string), "
        "is_deleted (boolean), 'created_at' and 'updated_at'",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ],
  [
    "queries.policy.get.v2",
    "GET",
    "/data-protection/queries/policies/v2",
    "Search for policies that match the provided criteria",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "platform name of the policies to search, either 'win' or 'mac'",
        "name": "platform_name",
        "in": "query",
        "required": True
      },
      {
        "type": "string",
        "description": "Filter results by specific attributes , allowed attributes are [name "
        "properties.enable_content_inspection properties.be_exclude_domains properties.be_upload_timeout_response "
        "properties.be_paste_clipboard_max_size properties.evidence_storage_max_size precedence created_at modified_at "
        "properties.similarity_threshold properties.enable_clipboard_inspection properties.evidence_encrypted_enabled "
        "properties.enable_network_inspection properties.besplash_message_source properties.min_confidence_level "
        "properties.unsupported_browsers_action properties.similarity_detection properties.classifications "
        "properties.besplash_enabled properties.be_paste_timeout_response properties.be_paste_clipboard_min_size_unit "
        "properties.be_paste_clipboard_over_size_behaviour_block properties.browsers_without_active_extension "
        "description is_enabled created_by properties.max_file_size_to_inspect_unit properties.block_all_data_access "
        "properties.be_paste_timeout_duration_milliseconds properties.be_paste_clipboard_min_size is_default "
        "modified_by properties.enable_context_inspection properties.inspection_depth "
        "properties.evidence_download_enabled properties.besplash_custom_message "
        "properties.be_upload_timeout_duration_seconds properties.enable_end_user_notifications_unsupported_browser "
        "properties.custom_allow_notification properties.custom_block_notification "
        "properties.be_paste_clipboard_max_size_unit properties.evidence_storage_free_disk_perc "
        "properties.max_file_size_to_inspect properties.allow_notifications properties.block_notifications "
        "properties.evidence_duplication_enabled_default properties.network_inspection_files_exceeding_size_limit]",
        "name": "filter",
        "in": "query"
      },
      {
        "maximum": 10000,
        "minimum": 0,
        "type": "integer",
        "description": "The offset to start retrieving records from",
        "name": "offset",
        "in": "query"
      },
      {
        "maximum": 500,
        "minimum": 0,
        "type": "integer",
        "default": 100,
        "description": "The maximum records to return",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The property to sort by, allowed fields are :[modified_at name precedence created_at]",
        "name": "sort",
        "in": "query"
      }
    ]
  ],
  [
    "queries.web-location.get-v2",
    "GET",
    "/data-protection/queries/web-locations/v2",
    "Get web-location IDs matching the query with filter",
    "data_protection_configuration",
    [
      {
        "type": "string",
        "description": "The filter to use when finding web locations. Allowed filters are 'name', 'type', "
        "'deleted', 'application_id', 'provider_location_id' and 'enterprise_account_id'",
        "name": "filter",
        "in": "query"
      },
      {
        "type": "string",
        "description": "The type of entity to query. Allowed values are 'predefined' and 'custom'",
        "name": "type",
        "in": "query"
      },
      {
        "type": "integer",
        "default": 100,
        "description": "The number of items to return in this response (default: 100, max: 500). Use with the "
        "offset parameter to manage pagination of results.",
        "name": "limit",
        "in": "query"
      },
      {
        "type": "integer",
        "description": "The offset to start retrieving records from. Use with the limit parameter to manage "
        "pagination of results.",
        "name": "offset",
        "in": "query"
      }
    ]
  ]
]
