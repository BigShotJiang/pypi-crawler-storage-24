"""
Error message unit tests for Basic rules:
RequiredRule, ProhibitedRule, NullableRule, FilledRule, PresentRule, MissingRule, ProhibitsRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestBasicRuleMessages(unittest.TestCase):

    # =============================================
    # RequiredRule
    # =============================================
    def test_required_message_on_empty_string(self):
        errors = get_error({'f': ''}, {'f': ['required']})
        self.assertEqual(len(errors), 1)
        self.assertIn('f field is required', errors[0])

    def test_required_message_on_missing_field(self):
        errors = get_error({}, {'f': ['required']})
        self.assertEqual(len(errors), 1)
        self.assertIn('required', errors[0].lower())

    def test_required_message_contains_field_name(self):
        v = Validator({'username': ''}, {'username': ['required']})
        v.validate()
        # Field name placeholder ':attribute' should be replaced with 'username'
        self.assertIn('username', v.errors['username'][0])

    def test_required_no_error_on_valid(self):
        errors = get_error({'f': 'value'}, {'f': ['required']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # ProhibitedRule
    # =============================================
    def test_prohibited_message_on_non_empty(self):
        errors = get_error({'f': 'some_value'}, {'f': ['prohibited']})
        self.assertEqual(len(errors), 1)
        self.assertIn('empty', errors[0].lower())

    def test_prohibited_no_error_on_empty(self):
        errors = get_error({'f': ''}, {'f': ['prohibited']})
        self.assertEqual(len(errors), 0)

    def test_prohibited_no_error_on_none(self):
        errors = get_error({'f': None}, {'f': ['prohibited']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # FilledRule
    # =============================================
    def test_filled_message_on_empty_string(self):
        errors = get_error({'f': ''}, {'f': ['filled']})
        self.assertEqual(len(errors), 1)
        self.assertIn('value', errors[0].lower())

    def test_filled_no_error_on_filled(self):
        errors = get_error({'f': 'hello'}, {'f': ['filled']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # PresentRule
    # =============================================
    def test_present_message_on_missing_field(self):
        errors = get_error({}, {'f': ['present']})
        self.assertEqual(len(errors), 1)
        self.assertIn('present', errors[0].lower())

    def test_present_no_error_on_present(self):
        errors = get_error({'f': None}, {'f': ['present']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # MissingRule
    # =============================================
    def test_missing_message_on_non_null(self):
        errors = get_error({'f': 'value'}, {'f': ['missing']})
        self.assertEqual(len(errors), 1)
        self.assertIn('missing', errors[0].lower())

    def test_missing_no_error_on_none(self):
        errors = get_error({'f': None}, {'f': ['missing']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # ProhibitsRule
    # =============================================
    def test_prohibits_message_when_other_field_present(self):
        v = Validator({'f': 'val', 'g': 'other'}, {'f': ['prohibits:g']})
        v.validate()
        errors = v.errors.get('f', [])
        self.assertEqual(len(errors), 1)
        self.assertIn('present', errors[0].lower())

    def test_prohibits_no_error_when_other_absent(self):
        v = Validator({'f': 'val'}, {'f': ['prohibits:g']})
        self.assertTrue(v.validate())

    # =============================================
    # Custom field name in messages
    # =============================================
    def test_custom_attribute_replaces_field_name(self):
        # Custom attribute name should appear with its original casing in the error message
        v = Validator({'email_address': ''}, {'email_address': ['required']}, custom_attributes={'email_address': 'Email Pengguna'})
        v.validate()
        # 'Email Pengguna' should be preserved (not lowercased to 'email pengguna')
        self.assertIn('Email Pengguna', v.errors['email_address'][0])

    def test_custom_attribute_replaces_field_name_indonesian(self):
        v = Validator({'nama_depan': ''}, {'nama_depan': ['required']}, custom_attributes={'nama_depan': 'Nama Depan'})
        v.validate()
        self.assertIn('Nama Depan', v.errors['nama_depan'][0])

    def test_auto_generated_name_when_no_custom_attr(self):
        # Without custom attributes, underscores → spaces, first word capitalized
        v = Validator({'user_name': ''}, {'user_name': ['required']})
        v.validate()
        self.assertIn('user name', v.errors['user_name'][0].lower())

    def test_custom_attribute_in_other_field_prohibits(self):
        # :others in prohibits should use custom attribute names for referenced fields
        v = Validator({'a': 'val', 'b': 'val'}, {'a': ['prohibits:b']}, custom_attributes={'a': 'Field A', 'b': 'Field B'})
        v.validate()
        errors = v.errors.get('a', [])
        self.assertEqual(len(errors), 1)
        self.assertIn('Field A', errors[0])   # :attribute
        self.assertIn('Field B', errors[0])   # :others

    # =============================================
    # Custom messages override
    # =============================================
    def test_custom_message_overrides_default(self):
        v = Validator(
            {'f': ''},
            {'f': ['required']},
            messages={'f.required': 'Custom: f is absolutely required!'}
        )
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Custom: f is absolutely required!')


if __name__ == '__main__':
    unittest.main()
