"""
Error message unit tests for String rules:
StringRule, AlphaRule, AlphaDashRule, AlphaNumRule, UppercaseRule, LowercaseRule,
AsciiRule, StartsWithRule, DoesntStartWithRule, EndsWithRule, DoesntEndWithRule,
ConfirmedRule, RegexRule, NotRegexRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestStringRuleMessages(unittest.TestCase):

    # =============================================
    # StringRule
    # =============================================
    def test_string_message_on_integer(self):
        errors = get_error({'f': 123}, {'f': ['string']})
        self.assertEqual(len(errors), 1)
        self.assertIn('string', errors[0].lower())

    def test_string_no_error_on_string(self):
        errors = get_error({'f': 'hello'}, {'f': ['string']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AlphaRule
    # =============================================
    def test_alpha_message_on_digits(self):
        errors = get_error({'f': 'abc1'}, {'f': ['alpha']})
        self.assertEqual(len(errors), 1)
        # Actual message: 'The f may only contain letters.'
        self.assertIn('letters', errors[0].lower())

    def test_alpha_no_error_on_letters_only(self):
        errors = get_error({'f': 'onlyletters'}, {'f': ['alpha']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AlphaDashRule
    # =============================================
    def test_alpha_dash_message_on_invalid(self):
        errors = get_error({'f': 'has space'}, {'f': ['alpha_dash']})
        self.assertEqual(len(errors), 1)
        self.assertIn('letters', errors[0].lower())

    def test_alpha_dash_no_error_on_valid(self):
        errors = get_error({'f': 'valid-value_123'}, {'f': ['alpha_dash']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AlphaNumRule
    # =============================================
    def test_alpha_num_message_on_symbols(self):
        errors = get_error({'f': 'abc!!'}, {'f': ['alpha_num']})
        self.assertEqual(len(errors), 1)
        self.assertIn('letters', errors[0].lower())

    def test_alpha_num_no_error_on_valid(self):
        errors = get_error({'f': 'abc123'}, {'f': ['alpha_num']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # UppercaseRule
    # =============================================
    def test_uppercase_message_on_lower(self):
        errors = get_error({'f': 'hello'}, {'f': ['uppercase']})
        self.assertEqual(len(errors), 1)
        self.assertIn('uppercase', errors[0].lower())

    def test_uppercase_no_error_on_upper(self):
        errors = get_error({'f': 'HELLO'}, {'f': ['uppercase']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # LowercaseRule
    # =============================================
    def test_lowercase_message_on_upper(self):
        errors = get_error({'f': 'HELLO'}, {'f': ['lowercase']})
        self.assertEqual(len(errors), 1)
        self.assertIn('lowercase', errors[0].lower())

    def test_lowercase_no_error_on_lower(self):
        errors = get_error({'f': 'hello'}, {'f': ['lowercase']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AsciiRule
    # =============================================
    def test_ascii_message_on_non_ascii(self):
        errors = get_error({'f': 'héllo'}, {'f': ['ascii']})
        self.assertEqual(len(errors), 1)
        self.assertIn('ascii', errors[0].lower())

    def test_ascii_no_error_on_ascii(self):
        errors = get_error({'f': 'hello'}, {'f': ['ascii']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # StartsWithRule
    # =============================================
    def test_starts_with_message_on_wrong_start(self):
        errors = get_error({'f': 'world'}, {'f': ['starts_with:hello']})
        self.assertEqual(len(errors), 1)
        self.assertIn('hello', errors[0])

    def test_starts_with_no_error_on_correct_start(self):
        errors = get_error({'f': 'hello world'}, {'f': ['starts_with:hello']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DoesntStartWithRule
    # =============================================
    def test_doesnt_start_with_message_on_wrong(self):
        errors = get_error({'f': 'hello world'}, {'f': ['doesnt_start_with:hello']})
        self.assertEqual(len(errors), 1)

    def test_doesnt_start_with_no_error_on_valid(self):
        errors = get_error({'f': 'world hello'}, {'f': ['doesnt_start_with:hello']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # EndsWithRule
    # =============================================
    def test_ends_with_message_on_wrong_end(self):
        errors = get_error({'f': 'hello'}, {'f': ['ends_with:world']})
        self.assertEqual(len(errors), 1)
        self.assertIn('world', errors[0])

    def test_ends_with_no_error_on_correct_end(self):
        errors = get_error({'f': 'hello world'}, {'f': ['ends_with:world']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DoesntEndWithRule
    # =============================================
    def test_doesnt_end_with_message_on_wrong(self):
        errors = get_error({'f': 'hello world'}, {'f': ['doesnt_end_with:world']})
        self.assertEqual(len(errors), 1)

    def test_doesnt_end_with_no_error_on_valid(self):
        errors = get_error({'f': 'hello there'}, {'f': ['doesnt_end_with:world']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # ConfirmedRule
    # =============================================
    def test_confirmed_message_on_mismatch(self):
        data = {'f': 'abc', 'f_confirmation': 'xyz'}
        errors = get_error(data, {'f': ['confirmed']})
        self.assertEqual(len(errors), 1)
        self.assertIn('confirm', errors[0].lower())

    def test_confirmed_no_error_on_match(self):
        data = {'f': 'abc', 'f_confirmation': 'abc'}
        errors = get_error(data, {'f': ['confirmed']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # RegexRule
    # =============================================
    def test_regex_message_on_no_match(self):
        errors = get_error({'f': 'abc'}, {'f': ['regex:^[0-9]+$']})
        self.assertEqual(len(errors), 1)
        self.assertIn('format', errors[0].lower())

    def test_regex_no_error_on_match(self):
        errors = get_error({'f': '12345'}, {'f': ['regex:^[0-9]+$']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # NotRegexRule
    # =============================================
    def test_not_regex_message_on_match(self):
        errors = get_error({'f': '123'}, {'f': ['not_regex:^[0-9]+$']})
        self.assertEqual(len(errors), 1)

    def test_not_regex_no_error_on_no_match(self):
        errors = get_error({'f': 'abc'}, {'f': ['not_regex:^[0-9]+$']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # Custom messages
    # =============================================
    def test_custom_message_for_string_rule(self):
        v = Validator({'f': 123}, {'f': ['string']}, messages={'f.string': 'Must be a string!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Must be a string!')

    def test_custom_message_for_alpha_rule(self):
        v = Validator({'f': 'abc1'}, {'f': ['alpha']}, messages={'f.alpha': 'Letters only!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Letters only!')


if __name__ == '__main__':
    unittest.main()
