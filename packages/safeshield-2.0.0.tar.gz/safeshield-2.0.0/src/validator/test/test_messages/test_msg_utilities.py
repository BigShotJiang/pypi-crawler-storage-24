"""
Error message unit tests for Utilities rules (conditional rules):
RequiredIfRule, RequiredUnlessRule, RequiredWithRule, RequiredWithoutRule,
ProhibitedIfRule, ProhibitedUnlessRule, PresentIfRule, PresentUnlessRule,
MissingIfRule, MissingUnlessRule, ExcludeIfRule, ExcludeUnlessRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestUtilitiesRuleMessages(unittest.TestCase):

    # =============================================
    # RequiredIfRule
    # =============================================
    def test_required_if_message_when_condition_met(self):
        # f is required when status=active
        data = {'f': '', 'status': 'active'}
        errors = get_error(data, {'f': ['required_if:status,active']})
        self.assertEqual(len(errors), 1)
        self.assertIn('required', errors[0].lower())

    def test_required_if_no_error_when_condition_not_met(self):
        data = {'f': '', 'status': 'inactive'}
        errors = get_error(data, {'f': ['required_if:status,active']})
        self.assertEqual(len(errors), 0)

    def test_required_if_no_error_when_filled(self):
        data = {'f': 'value', 'status': 'active'}
        errors = get_error(data, {'f': ['required_if:status,active']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # RequiredUnlessRule
    # =============================================
    def test_required_unless_message_when_condition_not_met(self):
        # f is required unless status=active
        data = {'f': '', 'status': 'inactive'}
        errors = get_error(data, {'f': ['required_unless:status,active']})
        self.assertEqual(len(errors), 1)
        self.assertIn('required', errors[0].lower())

    def test_required_unless_no_error_when_condition_met(self):
        data = {'f': '', 'status': 'active'}
        errors = get_error(data, {'f': ['required_unless:status,active']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # RequiredWithRule
    # =============================================
    def test_required_with_message_when_other_present(self):
        data = {'f': '', 'other': 'present'}
        errors = get_error(data, {'f': ['required_with:other']})
        self.assertEqual(len(errors), 1)
        self.assertIn('required', errors[0].lower())

    def test_required_with_no_error_when_other_absent(self):
        data = {'f': ''}
        errors = get_error(data, {'f': ['required_with:other']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # RequiredWithoutRule
    # =============================================
    def test_required_without_message_when_other_absent(self):
        data = {'f': ''}
        errors = get_error(data, {'f': ['required_without:other']})
        self.assertEqual(len(errors), 1)
        self.assertIn('required', errors[0].lower())

    def test_required_without_no_error_when_other_present(self):
        data = {'f': '', 'other': 'yes'}
        errors = get_error(data, {'f': ['required_without:other']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # ProhibitedIfRule
    # =============================================
    def test_prohibited_if_message_when_condition_met(self):
        data = {'f': 'some_value', 'status': 'active'}
        errors = get_error(data, {'f': ['prohibited_if:status,active']})
        self.assertEqual(len(errors), 1)
        # Actual message from ProhibitedRule: 'The f field is must be empty.'
        self.assertIn('empty', errors[0].lower())

    def test_prohibited_if_no_error_when_condition_not_met(self):
        data = {'f': 'some_value', 'status': 'inactive'}
        errors = get_error(data, {'f': ['prohibited_if:status,active']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # ProhibitedUnlessRule
    # =============================================
    def test_prohibited_unless_message_when_condition_not_met(self):
        data = {'f': 'some_value', 'status': 'inactive'}
        errors = get_error(data, {'f': ['prohibited_unless:status,active']})
        self.assertEqual(len(errors), 1)
        # Actual message from ProhibitedRule: 'The f field is must be empty.'
        self.assertIn('empty', errors[0].lower())

    def test_prohibited_unless_no_error_when_condition_met(self):
        data = {'f': 'some_value', 'status': 'active'}
        errors = get_error(data, {'f': ['prohibited_unless:status,active']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # PresentIfRule
    # =============================================
    def test_present_if_message_when_condition_met(self):
        # f must be present when status=active
        data = {'status': 'active'}  # f is missing
        errors = get_error(data, {'f': ['present_if:status,active']})
        self.assertEqual(len(errors), 1)
        self.assertIn('present', errors[0].lower())

    def test_present_if_no_error_when_condition_not_met(self):
        data = {'status': 'inactive'}  # f is missing but condition not met
        errors = get_error(data, {'f': ['present_if:status,active']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # MissingIfRule
    # =============================================
    def test_missing_if_message_when_condition_met(self):
        # f must be missing when status=active
        data = {'f': 'value', 'status': 'active'}
        errors = get_error(data, {'f': ['missing_if:status,active']})
        self.assertEqual(len(errors), 1)
        self.assertIn('missing', errors[0].lower())

    def test_missing_if_no_error_when_condition_not_met(self):
        data = {'f': 'value', 'status': 'inactive'}
        errors = get_error(data, {'f': ['missing_if:status,active']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # ExcludeIfRule (no error message, but sets _field_to_exclude)
    # =============================================
    def test_exclude_if_no_error_when_condition_met(self):
        data = {'f': 'value', 'status': 'active'}
        v = Validator(data, {'f': ['exclude_if:status,active']})
        self.assertTrue(v.validate())
        self.assertIn('f', v._field_to_exclude)

    def test_exclude_if_field_in_exclude_list(self):
        data = {'f': 'value', 'status': 'active'}
        v = Validator(data, {'f': ['exclude_if:status,active']})
        v.validate()
        self.assertIn('f', v._field_to_exclude)

    # =============================================
    # ExcludeUnlessRule
    # =============================================
    def test_exclude_unless_field_excluded_when_condition_not_met(self):
        data = {'f': 'value', 'status': 'inactive'}
        v = Validator(data, {'f': ['exclude_unless:status,active']})
        v.validate()
        self.assertIn('f', v._field_to_exclude)

    def test_exclude_unless_field_not_excluded_when_condition_met(self):
        data = {'f': 'value', 'status': 'active'}
        v = Validator(data, {'f': ['exclude_unless:status,active']})
        v.validate()
        self.assertNotIn('f', v._field_to_exclude)

    # =============================================
    # Custom messages for utilities rules
    # =============================================
    def test_custom_required_if_message(self):
        v = Validator(
            {'f': '', 'status': 'active'},
            {'f': ['required_if:status,active']},
            messages={'f.required_if': 'f is needed when status is active!'}
        )
        v.validate()
        self.assertEqual(v.errors['f'][0], 'f is needed when status is active!')

    def test_custom_prohibited_if_message(self):
        v = Validator(
            {'f': 'val', 'status': 'active'},
            {'f': ['prohibited_if:status,active']},
            messages={'f.prohibited_if': 'f must not be present!'}
        )
        v.validate()
        self.assertEqual(v.errors['f'][0], 'f must not be present!')


if __name__ == '__main__':
    unittest.main()
