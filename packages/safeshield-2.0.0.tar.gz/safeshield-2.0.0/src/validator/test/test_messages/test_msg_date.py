"""
Error message unit tests for Date rules:
DateRule, AfterRule, AfterOrEqualRule, BeforeRule, BeforeOrEqualRule,
DateEqualsRule, DateFormatRule, TimeZoneRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestDateRuleMessages(unittest.TestCase):

    # =============================================
    # DateRule
    # =============================================
    def test_date_message_on_invalid(self):
        errors = get_error({'f': 'not-a-date'}, {'f': ['date']})
        self.assertEqual(len(errors), 1)
        self.assertIn('date', errors[0].lower())

    def test_date_no_error_on_iso_format(self):
        errors = get_error({'f': '2024-01-15'}, {'f': ['date']})
        self.assertEqual(len(errors), 0)

    def test_date_no_error_on_slash_format(self):
        errors = get_error({'f': '2024/01/15'}, {'f': ['date']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AfterRule
    # =============================================
    def test_after_message_on_same_date(self):
        errors = get_error({'f': '2024-01-01'}, {'f': ['after:2024-01-01']})
        self.assertEqual(len(errors), 1)
        self.assertIn('after', errors[0].lower())
        self.assertIn('2024-01-01', errors[0])

    def test_after_message_on_earlier_date(self):
        errors = get_error({'f': '2023-01-01'}, {'f': ['after:2024-01-01']})
        self.assertEqual(len(errors), 1)

    def test_after_no_error_on_later_date(self):
        errors = get_error({'f': '2025-01-01'}, {'f': ['after:2024-01-01']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AfterOrEqualRule
    # =============================================
    def test_after_or_equal_message_on_earlier(self):
        errors = get_error({'f': '2023-01-01'}, {'f': ['after_or_equal:2024-01-01']})
        self.assertEqual(len(errors), 1)
        self.assertIn('2024-01-01', errors[0])

    def test_after_or_equal_no_error_on_same(self):
        errors = get_error({'f': '2024-01-01'}, {'f': ['after_or_equal:2024-01-01']})
        self.assertEqual(len(errors), 0)

    def test_after_or_equal_no_error_on_later(self):
        errors = get_error({'f': '2025-01-01'}, {'f': ['after_or_equal:2024-01-01']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # BeforeRule
    # =============================================
    def test_before_message_on_same_date(self):
        errors = get_error({'f': '2024-01-01'}, {'f': ['before:2024-01-01']})
        self.assertEqual(len(errors), 1)
        self.assertIn('before', errors[0].lower())

    def test_before_message_on_later_date(self):
        errors = get_error({'f': '2025-01-01'}, {'f': ['before:2024-01-01']})
        self.assertEqual(len(errors), 1)

    def test_before_no_error_on_earlier_date(self):
        errors = get_error({'f': '2023-01-01'}, {'f': ['before:2024-01-01']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # BeforeOrEqualRule
    # =============================================
    def test_before_or_equal_message_on_later(self):
        errors = get_error({'f': '2025-01-01'}, {'f': ['before_or_equal:2024-01-01']})
        self.assertEqual(len(errors), 1)

    def test_before_or_equal_no_error_on_same(self):
        errors = get_error({'f': '2024-01-01'}, {'f': ['before_or_equal:2024-01-01']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DateEqualsRule
    # =============================================
    def test_date_equals_message_on_different(self):
        errors = get_error({'f': '2023-01-01'}, {'f': ['date_equals:2024-01-01']})
        self.assertEqual(len(errors), 1)
        self.assertIn('2024-01-01', errors[0])

    def test_date_equals_no_error_on_same(self):
        errors = get_error({'f': '2024-01-01'}, {'f': ['date_equals:2024-01-01']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DateFormatRule
    # =============================================
    def test_date_format_message_on_wrong_format(self):
        errors = get_error({'f': '2024-01-15'}, {'f': ['date_format:%d/%m/%Y']})
        self.assertEqual(len(errors), 1)
        self.assertIn('%d/%m/%Y', errors[0])

    def test_date_format_no_error_on_correct_format(self):
        errors = get_error({'f': '15/01/2024'}, {'f': ['date_format:%d/%m/%Y']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # Custom messages for date rules
    # =============================================
    def test_custom_date_message(self):
        v = Validator({'f': 'not-a-date'}, {'f': ['date']}, messages={'f.date': 'Invalid date format!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Invalid date format!')

    def test_custom_after_message(self):
        v = Validator(
            {'f': '2020-01-01'},
            {'f': ['after:2024-01-01']},
            messages={'f.after': 'Date must be later than 2024!'}
        )
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Date must be later than 2024!')


if __name__ == '__main__':
    unittest.main()
