"""
Error message unit tests for Comparison rules:
MinRule, MaxRule, BetweenRule, GreaterThanRule, GreaterThanOrEqualRule,
LessThanRule, LessThanOrEqualRule, SizeRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestComparisonRuleMessages(unittest.TestCase):

    # =============================================
    # MinRule
    # =============================================
    def test_min_message_on_short_string(self):
        errors = get_error({'f': 'hi'}, {'f': ['min:5']})
        self.assertEqual(len(errors), 1)
        self.assertIn('at least', errors[0].lower())
        self.assertIn('5', errors[0])

    def test_min_message_on_small_number(self):
        errors = get_error({'f': 3}, {'f': ['min:10']})
        self.assertEqual(len(errors), 1)
        self.assertIn('10', errors[0])

    def test_min_no_error_on_valid(self):
        errors = get_error({'f': 'valid_value'}, {'f': ['min:3']})
        self.assertEqual(len(errors), 0)

    def test_min_message_contains_field_name(self):
        v = Validator({'username': 'ab'}, {'username': ['min:5']})
        v.validate()
        self.assertIn('username', v.errors['username'][0])

    # =============================================
    # MaxRule
    # =============================================
    def test_max_message_on_long_string(self):
        errors = get_error({'f': 'toolongvalue'}, {'f': ['max:5']})
        self.assertEqual(len(errors), 1)
        self.assertIn('5', errors[0])

    def test_max_message_on_large_number(self):
        errors = get_error({'f': 200}, {'f': ['max:100']})
        self.assertEqual(len(errors), 1)
        self.assertIn('100', errors[0])

    def test_max_no_error_on_valid(self):
        errors = get_error({'f': 50}, {'f': ['max:100']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # BetweenRule
    # =============================================
    def test_between_message_on_out_of_range(self):
        errors = get_error({'f': 5}, {'f': ['between:10,20']})
        self.assertEqual(len(errors), 1)
        self.assertIn('10', errors[0])
        self.assertIn('20', errors[0])

    def test_between_no_error_on_in_range(self):
        errors = get_error({'f': 15}, {'f': ['between:10,20']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # GreaterThanRule (gt)
    # =============================================
    def test_gt_message_on_equal(self):
        errors = get_error({'f': 5}, {'f': ['gt:5']})
        self.assertEqual(len(errors), 1)
        self.assertIn('greater', errors[0].lower())
        self.assertIn('5', errors[0])

    def test_gt_message_on_less(self):
        errors = get_error({'f': 3}, {'f': ['gt:5']})
        self.assertEqual(len(errors), 1)

    def test_gt_no_error_on_greater(self):
        errors = get_error({'f': 10}, {'f': ['gt:5']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # GreaterThanOrEqualRule (gte)
    # =============================================
    def test_gte_message_on_less(self):
        errors = get_error({'f': 3}, {'f': ['gte:5']})
        self.assertEqual(len(errors), 1)
        self.assertIn('5', errors[0])

    def test_gte_no_error_on_equal(self):
        errors = get_error({'f': 5}, {'f': ['gte:5']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # LessThanRule (lt)
    # =============================================
    def test_lt_message_on_equal(self):
        errors = get_error({'f': 5}, {'f': ['lt:5']})
        self.assertEqual(len(errors), 1)
        self.assertIn('less', errors[0].lower())

    def test_lt_no_error_on_less(self):
        errors = get_error({'f': 3}, {'f': ['lt:5']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # LessThanOrEqualRule (lte)
    # =============================================
    def test_lte_message_on_greater(self):
        errors = get_error({'f': 10}, {'f': ['lte:5']})
        self.assertEqual(len(errors), 1)
        self.assertIn('5', errors[0])

    def test_lte_no_error_on_equal(self):
        errors = get_error({'f': 5}, {'f': ['lte:5']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # Custom messages for comparison rules
    # =============================================
    def test_custom_min_message(self):
        v = Validator({'f': 'ab'}, {'f': ['min:5']}, messages={'f.min': 'Too short!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Too short!')

    def test_custom_max_message(self):
        v = Validator({'f': 'toolong'}, {'f': ['max:3']}, messages={'f.max': 'Too long!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Too long!')


if __name__ == '__main__':
    unittest.main()
