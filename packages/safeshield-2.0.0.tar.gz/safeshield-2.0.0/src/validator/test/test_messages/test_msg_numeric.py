"""
Error message unit tests for Numeric rules:
NumericRule, IntegerRule, DigitsRule, DigitsBetweenRule, DecimalRule,
GreaterThanRule (numeric), LessThanRule (numeric), MaxDigitsRule, MinDigitsRule, MultipleOfRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestNumericRuleMessages(unittest.TestCase):

    # =============================================
    # NumericRule
    # =============================================
    def test_numeric_message_on_non_numeric(self):
        errors = get_error({'f': 'abc'}, {'f': ['numeric']})
        self.assertEqual(len(errors), 1)
        # Actual message: 'The f must be a number.'
        self.assertIn('number', errors[0].lower())

    def test_numeric_no_error_on_int(self):
        errors = get_error({'f': 42}, {'f': ['numeric']})
        self.assertEqual(len(errors), 0)

    def test_numeric_no_error_on_numeric_string(self):
        errors = get_error({'f': '3.14'}, {'f': ['numeric']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # IntegerRule
    # =============================================
    def test_integer_message_on_float(self):
        errors = get_error({'f': '1.5'}, {'f': ['integer']})
        self.assertEqual(len(errors), 1)
        self.assertIn('integer', errors[0].lower())

    def test_integer_no_error_on_int(self):
        errors = get_error({'f': 5}, {'f': ['integer']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DigitsRule
    # =============================================
    def test_digits_message_on_wrong_length(self):
        errors = get_error({'f': '123'}, {'f': ['digits:5']})
        self.assertEqual(len(errors), 1)
        self.assertIn('5', errors[0])

    def test_digits_no_error_on_correct_length(self):
        errors = get_error({'f': '12345'}, {'f': ['digits:5']})
        self.assertEqual(len(errors), 0)

    def test_digits_message_on_non_numeric(self):
        errors = get_error({'f': 'abcde'}, {'f': ['digits:5']})
        self.assertEqual(len(errors), 1)

    # =============================================
    # DigitsBetweenRule
    # =============================================
    def test_digits_between_message_on_too_few(self):
        errors = get_error({'f': '12'}, {'f': ['digits_between:4,6']})
        self.assertEqual(len(errors), 1)
        self.assertIn('4', errors[0])
        self.assertIn('6', errors[0])

    def test_digits_between_no_error_on_in_range(self):
        errors = get_error({'f': '12345'}, {'f': ['digits_between:4,6']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DecimalRule
    # =============================================
    def test_decimal_message_on_non_decimal(self):
        errors = get_error({'f': 'notadecimal'}, {'f': ['decimal']})
        self.assertEqual(len(errors), 1)
        self.assertIn('decimal', errors[0].lower())

    def test_decimal_no_error_on_float(self):
        errors = get_error({'f': '3.14'}, {'f': ['decimal']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # MaxDigitsRule
    # =============================================
    def test_max_digits_message_on_too_many(self):
        errors = get_error({'f': '123456'}, {'f': ['max_digits:4']})
        self.assertEqual(len(errors), 1)
        self.assertIn('4', errors[0])

    def test_max_digits_no_error_on_within_limit(self):
        errors = get_error({'f': '123'}, {'f': ['max_digits:4']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # MinDigitsRule
    # =============================================
    def test_min_digits_message_on_too_few(self):
        errors = get_error({'f': '12'}, {'f': ['min_digits:4']})
        self.assertEqual(len(errors), 1)
        self.assertIn('4', errors[0])

    def test_min_digits_no_error_on_within_limit(self):
        errors = get_error({'f': '12345'}, {'f': ['min_digits:4']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # MultipleOfRule
    # =============================================
    def test_multiple_of_message_on_non_multiple(self):
        errors = get_error({'f': 7}, {'f': ['multiple_of:3']})
        self.assertEqual(len(errors), 1)
        self.assertIn('3', errors[0])

    def test_multiple_of_no_error_on_multiple(self):
        errors = get_error({'f': 9}, {'f': ['multiple_of:3']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # Custom messages for numeric rules
    # =============================================
    def test_custom_numeric_message(self):
        v = Validator({'f': 'abc'}, {'f': ['numeric']}, messages={'f.numeric': 'Only numbers allowed!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Only numbers allowed!')

    def test_custom_integer_message(self):
        v = Validator({'f': '1.5'}, {'f': ['integer']}, messages={'f.integer': 'Must be a whole number!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Must be a whole number!')


if __name__ == '__main__':
    unittest.main()
