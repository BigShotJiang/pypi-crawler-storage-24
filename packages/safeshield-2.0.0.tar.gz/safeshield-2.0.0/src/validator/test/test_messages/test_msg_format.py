"""
Error message unit tests for Format rules:
EmailRule, UrlRule, JsonRule, UuidRule, UlidRule, IpRule, HexRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestFormatRuleMessages(unittest.TestCase):

    # =============================================
    # EmailRule
    # =============================================
    def test_email_message_on_invalid(self):
        errors = get_error({'f': 'not-an-email'}, {'f': ['email']})
        self.assertEqual(len(errors), 1)
        self.assertIn('email', errors[0].lower())

    def test_email_no_error_on_valid(self):
        errors = get_error({'f': 'user@example.com'}, {'f': ['email']})
        self.assertEqual(len(errors), 0)

    def test_email_message_contains_field_name(self):
        v = Validator({'contact_email': 'bad'}, {'contact_email': ['email']})
        v.validate()
        # Validator converts underscores to spaces: 'contact_email' → 'contact email'
        self.assertIn('contact email', v.errors['contact_email'][0].lower())

    # =============================================
    # UrlRule
    # =============================================
    def test_url_message_on_invalid(self):
        errors = get_error({'f': 'not-a-url'}, {'f': ['url']})
        self.assertEqual(len(errors), 1)
        self.assertIn('url', errors[0].lower())

    def test_url_no_error_on_valid_http(self):
        errors = get_error({'f': 'https://www.example.com'}, {'f': ['url']})
        self.assertEqual(len(errors), 0)

    def test_url_no_error_on_url_with_query(self):
        errors = get_error({'f': 'https://example.com/path?q=1&page=2'}, {'f': ['url']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # JsonRule
    # =============================================
    def test_json_message_on_invalid(self):
        errors = get_error({'f': 'not-json'}, {'f': ['json']})
        self.assertEqual(len(errors), 1)
        self.assertIn('json', errors[0].lower())

    def test_json_no_error_on_valid_object(self):
        errors = get_error({'f': '{"key": "value"}'}, {'f': ['json']})
        self.assertEqual(len(errors), 0)

    def test_json_no_error_on_valid_array(self):
        errors = get_error({'f': '[1,2,3]'}, {'f': ['json']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # UuidRule
    # =============================================
    def test_uuid_message_on_invalid(self):
        errors = get_error({'f': 'not-a-uuid'}, {'f': ['uuid']})
        self.assertEqual(len(errors), 1)
        self.assertIn('uuid', errors[0].lower())

    def test_uuid_no_error_on_valid(self):
        errors = get_error({'f': '550e8400-e29b-41d4-a716-446655440000'}, {'f': ['uuid']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # UlidRule
    # =============================================
    def test_ulid_message_on_invalid(self):
        errors = get_error({'f': 'not-ulid'}, {'f': ['ulid']})
        self.assertEqual(len(errors), 1)
        self.assertIn('ulid', errors[0].lower())

    def test_ulid_no_error_on_valid(self):
        errors = get_error({'f': '01ARZ3NDEKTSV4RRFFQ69G5FAV'}, {'f': ['ulid']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # IpRule
    # =============================================
    def test_ip_message_on_invalid(self):
        errors = get_error({'f': '999.999.999.999'}, {'f': ['ip']})
        self.assertEqual(len(errors), 1)
        self.assertIn('ip', errors[0].lower())

    def test_ip_no_error_on_valid_ipv4(self):
        errors = get_error({'f': '192.168.1.1'}, {'f': ['ip']})
        self.assertEqual(len(errors), 0)

    def test_ip_no_error_on_valid_ipv6(self):
        errors = get_error({'f': '2001:db8::1'}, {'f': ['ip']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # HexRule
    # =============================================
    def test_hex_message_on_invalid(self):
        errors = get_error({'f': 'not-hex-GZX'}, {'f': ['hex']})
        self.assertEqual(len(errors), 1)
        self.assertIn('hex', errors[0].lower())

    def test_hex_no_error_on_valid(self):
        errors = get_error({'f': '#ff00aa'}, {'f': ['hex']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # Custom messages for format rules
    # =============================================
    def test_custom_email_message(self):
        v = Validator({'f': 'bad'}, {'f': ['email']}, messages={'f.email': 'Enter a valid email address!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Enter a valid email address!')

    def test_custom_url_message(self):
        v = Validator({'f': 'bad'}, {'f': ['url']}, messages={'f.url': 'Enter a valid URL!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Enter a valid URL!')


if __name__ == '__main__':
    unittest.main()
