"""
Error message unit tests for Boolean rules:
BooleanRule, AcceptedRule, DeclinedRule, AcceptedIfRule, DeclinedIfRule
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f'):
    v = Validator(data, rules)
    v.validate()
    return v.errors.get(field, [])


class TestBooleanRuleMessages(unittest.TestCase):

    # =============================================
    # BooleanRule
    # =============================================
    def test_boolean_message_on_invalid(self):
        errors = get_error({'f': 'maybe'}, {'f': ['boolean']})
        self.assertEqual(len(errors), 1)
        self.assertIn('true', errors[0].lower())

    def test_boolean_no_error_on_true(self):
        errors = get_error({'f': True}, {'f': ['boolean']})
        self.assertEqual(len(errors), 0)

    def test_boolean_no_error_on_false(self):
        errors = get_error({'f': False}, {'f': ['boolean']})
        self.assertEqual(len(errors), 0)

    def test_boolean_no_error_on_1(self):
        errors = get_error({'f': 1}, {'f': ['boolean']})
        self.assertEqual(len(errors), 0)

    def test_boolean_no_error_on_0(self):
        errors = get_error({'f': 0}, {'f': ['boolean']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AcceptedRule
    # =============================================
    def test_accepted_message_on_false(self):
        errors = get_error({'f': 'no'}, {'f': ['accepted']})
        self.assertEqual(len(errors), 1)
        self.assertIn('accepted', errors[0].lower())

    def test_accepted_no_error_on_yes(self):
        errors = get_error({'f': 'yes'}, {'f': ['accepted']})
        self.assertEqual(len(errors), 0)

    def test_accepted_no_error_on_true(self):
        errors = get_error({'f': True}, {'f': ['accepted']})
        self.assertEqual(len(errors), 0)

    def test_accepted_no_error_on_1(self):
        errors = get_error({'f': 1}, {'f': ['accepted']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DeclinedRule
    # =============================================
    def test_declined_message_on_accepted(self):
        errors = get_error({'f': 'yes'}, {'f': ['declined']})
        self.assertEqual(len(errors), 1)
        self.assertIn('declined', errors[0].lower())

    def test_declined_no_error_on_no(self):
        errors = get_error({'f': 'no'}, {'f': ['declined']})
        self.assertEqual(len(errors), 0)

    def test_declined_no_error_on_false(self):
        errors = get_error({'f': False}, {'f': ['declined']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # AcceptedIfRule
    # =============================================
    def test_accepted_if_message_when_condition_met(self):
        # accepted_if:status,active → f must be accepted when status=active
        data = {'f': 'no', 'status': 'active'}
        errors = get_error(data, {'f': ['accepted_if:status,active']})
        self.assertEqual(len(errors), 1)
        self.assertIn('accepted', errors[0].lower())

    def test_accepted_if_no_error_when_condition_not_met(self):
        data = {'f': 'no', 'status': 'inactive'}
        errors = get_error(data, {'f': ['accepted_if:status,active']})
        self.assertEqual(len(errors), 0)

    def test_accepted_if_no_error_when_condition_met_and_accepted(self):
        data = {'f': 'yes', 'status': 'active'}
        errors = get_error(data, {'f': ['accepted_if:status,active']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # DeclinedIfRule
    # =============================================
    def test_declined_if_message_when_condition_met(self):
        data = {'f': 'yes', 'status': 'inactive'}
        errors = get_error(data, {'f': ['declined_if:status,inactive']})
        self.assertEqual(len(errors), 1)
        self.assertIn('declined', errors[0].lower())

    def test_declined_if_no_error_when_condition_not_met(self):
        data = {'f': 'yes', 'status': 'active'}
        errors = get_error(data, {'f': ['declined_if:status,inactive']})
        self.assertEqual(len(errors), 0)

    def test_declined_if_no_error_when_condition_met_and_declined(self):
        data = {'f': 'no', 'status': 'inactive'}
        errors = get_error(data, {'f': ['declined_if:status,inactive']})
        self.assertEqual(len(errors), 0)

    # =============================================
    # Custom messages for boolean rules
    # =============================================
    def test_custom_boolean_message(self):
        v = Validator({'f': 'maybe'}, {'f': ['boolean']}, messages={'f.boolean': 'Must be true or false!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'Must be true or false!')

    def test_custom_accepted_message(self):
        v = Validator({'f': 'no'}, {'f': ['accepted']}, messages={'f.accepted': 'You must accept!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'You must accept!')

    def test_custom_declined_message(self):
        v = Validator({'f': 'yes'}, {'f': ['declined']}, messages={'f.declined': 'You must decline!'})
        v.validate()
        self.assertEqual(v.errors['f'][0], 'You must decline!')


if __name__ == '__main__':
    unittest.main()
