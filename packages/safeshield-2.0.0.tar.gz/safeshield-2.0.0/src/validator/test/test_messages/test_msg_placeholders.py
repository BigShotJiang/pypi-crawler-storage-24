"""
Unit tests for error message placeholders:
- :input  — displays the actual input value that failed validation
- :other  — displays the name of a referenced single field (e.g. same:g, required_if:status,active)
- :others — displays the names of multiple referenced fields (e.g. required_with:a,b)

For every test we verify that:
1. The placeholder is correctly replaced (not left as ':input', ':other', ':others')
2. The replacement contains the expected content (value or field name)
3. Custom attributes are respected for :other/:others
"""
import unittest
from validator.core import Validator


def get_error(data, rules, field='f', custom_attributes=None):
    v = Validator(data, rules, custom_attributes=custom_attributes or {})
    v.validate()
    return v.errors.get(field, [])


# ===========================================================================
# :INPUT PLACEHOLDER TESTS
# ===========================================================================

class TestInputPlaceholder(unittest.TestCase):
    """
    :input is replaced by the actual value that failed validation.
    It must not appear literally in the message.
    """

    # --- comparison rules ---
    def test_min_input_not_in_message_as_literal(self):
        errors = get_error({'f': 2}, {'f': ['min:5']})
        self.assertEqual(len(errors), 1)
        self.assertNotIn(':input', errors[0])

    def test_max_message_does_not_contain_literal_input(self):
        errors = get_error({'f': 999}, {'f': ['max:100']})
        self.assertNotIn(':input', errors[0])

    def test_between_message_no_literal_input(self):
        errors = get_error({'f': 50}, {'f': ['between:10,20']})
        self.assertNotIn(':input', errors[0])

    def test_gt_message_no_literal_input(self):
        errors = get_error({'f': 1}, {'f': ['gt:5']})
        self.assertNotIn(':input', errors[0])

    def test_gte_message_no_literal_input(self):
        errors = get_error({'f': 1}, {'f': ['gte:5']})
        self.assertNotIn(':input', errors[0])

    def test_lt_message_no_literal_input(self):
        errors = get_error({'f': 100}, {'f': ['lt:5']})
        self.assertNotIn(':input', errors[0])

    def test_lte_message_no_literal_input(self):
        errors = get_error({'f': 100}, {'f': ['lte:5']})
        self.assertNotIn(':input', errors[0])

    def test_same_message_no_literal_input(self):
        errors = get_error({'f': 'abc', 'g': 'xyz'}, {'f': ['same:g']})
        self.assertNotIn(':input', errors[0])

    def test_different_message_no_literal_input(self):
        errors = get_error({'f': 'abc', 'g': 'abc'}, {'f': ['different:g']})
        self.assertNotIn(':input', errors[0])

    # --- string rules ---
    def test_starts_with_no_literal_input(self):
        errors = get_error({'f': 'world'}, {'f': ['starts_with:hello']})
        self.assertNotIn(':input', errors[0])

    def test_ends_with_no_literal_input(self):
        errors = get_error({'f': 'hello'}, {'f': ['ends_with:world']})
        self.assertNotIn(':input', errors[0])

    def test_doesnt_start_with_no_literal_input(self):
        errors = get_error({'f': 'hello world'}, {'f': ['doesnt_start_with:hello']})
        self.assertNotIn(':input', errors[0])

    def test_doesnt_end_with_no_literal_input(self):
        errors = get_error({'f': 'hello world'}, {'f': ['doesnt_end_with:world']})
        self.assertNotIn(':input', errors[0])

    # --- numeric rules ---
    def test_digits_no_literal_input(self):
        errors = get_error({'f': '12'}, {'f': ['digits:5']})
        self.assertNotIn(':input', errors[0])

    def test_multiple_of_no_literal_input(self):
        errors = get_error({'f': 7}, {'f': ['multiple_of:3']})
        self.assertNotIn(':input', errors[0])

    # --- utilities rules ---
    def test_required_if_no_literal_input(self):
        errors = get_error({'f': '', 'status': 'active'}, {'f': ['required_if:status,active']})
        self.assertNotIn(':input', errors[0])

    def test_prohibited_if_no_literal_input(self):
        errors = get_error({'f': 'val', 'status': 'active'}, {'f': ['prohibited_if:status,active']})
        self.assertNotIn(':input', errors[0])


# ===========================================================================
# :OTHER PLACEHOLDER TESTS (single referenced field)
# ===========================================================================

class TestOtherPlaceholder(unittest.TestCase):
    """
    :other is replaced by the display name of a single referenced field.
    It should be auto-generated from the field name OR use the custom_attribute.
    """

    # --- same rule ---
    def test_same_other_replaced_with_field_name(self):
        errors = get_error({'f': 'abc', 'confirm_field': 'xyz'}, {'f': ['same:confirm_field']})
        self.assertEqual(len(errors), 1)
        # :other should become 'confirm field' (auto-generated) or similar
        self.assertNotIn(':other', errors[0])
        self.assertIn('confirm', errors[0].lower())

    def test_same_other_replaced_with_custom_attribute(self):
        errors = get_error(
            {'f': 'abc', 'confirm_field': 'xyz'},
            {'f': ['same:confirm_field']},
            custom_attributes={'confirm_field': 'Konfirmasi Password'}
        )
        self.assertNotIn(':other', errors[0])
        self.assertIn('Konfirmasi Password', errors[0])

    def test_same_no_error_on_match(self):
        errors = get_error({'f': 'abc', 'g': 'abc'}, {'f': ['same:g']})
        self.assertEqual(len(errors), 0)

    # --- different rule ---
    def test_different_other_replaced_with_field_name(self):
        errors = get_error({'f': 'abc', 'compare_field': 'abc'}, {'f': ['different:compare_field']})
        self.assertNotIn(':other', errors[0])
        self.assertIn('compare', errors[0].lower())

    def test_different_other_replaced_with_custom_attribute(self):
        errors = get_error(
            {'f': 'abc', 'old_password': 'abc'},
            {'f': ['different:old_password']},
            custom_attributes={'old_password': 'Password Lama'}
        )
        self.assertNotIn(':other', errors[0])
        self.assertIn('Password Lama', errors[0])

    def test_different_no_error_on_different(self):
        errors = get_error({'f': 'new_value', 'g': 'old_value'}, {'f': ['different:g']})
        self.assertEqual(len(errors), 0)

    # --- required_if :other ---
    def test_required_if_message_does_not_contain_literal_other(self):
        errors = get_error({'f': '', 'role': 'admin'}, {'f': ['required_if:role,admin']})
        self.assertNotIn(':other', errors[0])

    def test_required_if_custom_other_attr(self):
        v = Validator(
            {'f': '', 'role': 'admin'},
            {'f': ['required_if:role,admin']},
            custom_attributes={'role': 'Peran Pengguna'}
        )
        v.validate()
        errors = v.errors.get('f', [])
        self.assertNotIn(':other', errors[0])

    # --- accepted_if :other ---
    def test_accepted_if_no_literal_other(self):
        errors = get_error({'f': 'no', 'status': 'active'}, {'f': ['accepted_if:status,active']})
        self.assertNotIn(':other', errors[0])

    def test_accepted_if_custom_other(self):
        v = Validator(
            {'f': 'no', 'account_status': 'active'},
            {'f': ['accepted_if:account_status,active']},
            custom_attributes={'account_status': 'Status Akun'}
        )
        v.validate()
        errors = v.errors.get('f', [])
        self.assertNotIn(':other', errors[0])

    # --- declined_if :other ---
    def test_declined_if_no_literal_other(self):
        errors = get_error({'f': 'yes', 'status': 'inactive'}, {'f': ['declined_if:status,inactive']})
        self.assertNotIn(':other', errors[0])


# ===========================================================================
# :OTHERS PLACEHOLDER TESTS (multiple referenced fields)
# ===========================================================================

class TestOthersPlaceholder(unittest.TestCase):
    """
    :others is replaced by a comma-joined list of display names for multiple referenced fields.
    Uses custom_attributes if provided.
    """

    # --- prohibits :others ---
    def test_prohibits_others_replaced(self):
        errors = get_error({'f': 'val', 'g': 'val'}, {'f': ['prohibits:g']})
        self.assertNotIn(':others', errors[0])
        self.assertIn('g', errors[0].lower())  # auto-generated name

    def test_prohibits_others_multiple_fields(self):
        v = Validator({'f': 'val', 'a': 'val', 'b': 'val'}, {'f': ['prohibits:a,b']})
        v.validate()
        errors = v.errors.get('f', [])
        self.assertNotIn(':others', errors[0])
        # both field names should appear
        self.assertIn('a', errors[0].lower())
        self.assertIn('b', errors[0].lower())

    def test_prohibits_others_custom_attributes(self):
        v = Validator(
            {'f': 'val', 'secret': 'val'},
            {'f': ['prohibits:secret']},
            custom_attributes={'f': 'Token', 'secret': 'Data Rahasia'}
        )
        v.validate()
        errors = v.errors.get('f', [])
        self.assertNotIn(':others', errors[0])
        self.assertIn('Token', errors[0])           # :attribute
        self.assertIn('Data Rahasia', errors[0])    # :others

    def test_prohibits_no_error_when_other_absent(self):
        errors = get_error({'f': 'val'}, {'f': ['prohibits:g']})
        self.assertEqual(len(errors), 0)

    # --- required_with :others ---
    def test_required_with_others_replaced(self):
        errors = get_error({'f': '', 'companion': 'val'}, {'f': ['required_with:companion']})
        self.assertNotIn(':others', errors[0])

    def test_required_with_others_custom_attributes(self):
        v = Validator(
            {'f': '', 'companion_field': 'val'},
            {'f': ['required_with:companion_field']},
            custom_attributes={'companion_field': 'Field Pendamping'}
        )
        v.validate()
        errors = v.errors.get('f', [])
        self.assertNotIn(':others', errors[0])

    # --- required_without :others ---
    def test_required_without_others_replaced(self):
        errors = get_error({'f': ''}, {'f': ['required_without:backup']})
        self.assertNotIn(':others', errors[0])

    # --- present_with :others ---
    def test_present_with_others_no_literal(self):
        # present_with: f must be present when 'other_field' is present
        v = Validator({'other_field': 'val'}, {'f': ['present_with:other_field']})
        v.validate()
        errors = v.errors.get('f', [])
        if errors:  # only check if there's an error
            self.assertNotIn(':others', errors[0])

    # --- missing_with :others ---
    def test_missing_with_others_no_literal(self):
        v = Validator({'f': 'val', 'conflicting': 'val'}, {'f': ['missing_with:conflicting']})
        v.validate()
        errors = v.errors.get('f', [])
        if errors:
            self.assertNotIn(':others', errors[0])


# ===========================================================================
# :VALUES PLACEHOLDER TESTS (comma-separated parameter values)
# ===========================================================================

class TestValuesPlaceholder(unittest.TestCase):
    """
    :values is replaced by a comma-joined list of rule parameters.
    Used in rules like in, not_in, starts_with, ends_with, where multiple allowed/forbidden values exist.
    """

    def test_in_values_replaced(self):
        # InRule title-cases values and uses "must be in : :values"
        errors = get_error({'f': 'invalid'}, {'f': ['in:admin,user,guest']})
        self.assertEqual(len(errors), 1)
        self.assertNotIn(':values', errors[0])
        # Note the title-casing and the colon/space in default message
        self.assertIn('Admin, User, Guest', errors[0])

    def test_not_in_values_replaced(self):
        # NotInRule title-cases values and uses "must be not in : :values"
        errors = get_error({'f': 'admin'}, {'f': ['not_in:admin,root']})
        self.assertNotIn(':values', errors[0])
        self.assertIn('Admin, Root', errors[0])

    def test_starts_with_values_replaced(self):
        errors = get_error({'f': 'hello'}, {'f': ['starts_with:foo,bar']})
        self.assertNotIn(':values', errors[0])
        self.assertIn('foo, bar', errors[0])

    def test_ends_with_values_replaced(self):
        errors = get_error({'f': 'hello'}, {'f': ['ends_with:foo,bar']})
        self.assertNotIn(':values', errors[0])
        self.assertIn('foo, bar', errors[0])

    def test_required_if_values_replaced_custom_message(self):
        # By default, RequiredIfRule doesn't use :values in its message.
        # We use a custom message to verify the placeholder is correctly substituted.
        custom_msg = "Field :attribute is required when :other matches :values. You sent :input."
        v = Validator(
            {'f': '', 'status': 'val1'},
            {'f': ['required_if:status,val1,val2']},
            messages={'f.required_if': custom_msg}
        )
        v.validate()
        errors = v.errors.get('f', [])
        self.assertEqual(len(errors), 1)
        msg = errors[0]
        self.assertNotIn(':attribute', msg)
        self.assertNotIn(':other', msg)
        self.assertNotIn(':values', msg)
        self.assertNotIn(':input', msg)
        self.assertIn('f', msg)
        self.assertIn('status', msg.lower())
        self.assertIn('val1, val2', msg)
        self.assertTrue(msg.endswith('You sent .'))


# ===========================================================================
# COMBINED: :attribute + :other + :input + :values in a single message
# ===========================================================================

class TestCombinedPlaceholders(unittest.TestCase):
    """
    Tests that verify all placeholders are correctly replaced together,
    especially when using custom_attributes.
    """

    def test_same_rule_all_placeholders_replaced(self):
        # same rule: "The :attribute and :other must match."
        v = Validator(
            {'password': 'newpass', 'password_confirmation': 'different'},
            {'password': ['same:password_confirmation']},
            custom_attributes={
                'password': 'Kata Sandi Baru',
                'password_confirmation': 'Konfirmasi Kata Sandi'
            }
        )
        v.validate()
        errors = v.errors.get('password', [])
        self.assertEqual(len(errors), 1)
        msg = errors[0]
        self.assertNotIn(':attribute', msg)
        self.assertNotIn(':other', msg)
        self.assertNotIn(':input', msg)
        self.assertIn('Kata Sandi Baru', msg)
        self.assertIn('Konfirmasi Kata Sandi', msg)

    def test_prohibits_rule_all_placeholders_replaced(self):
        # prohibits: "When :attribute is present, :others must be empty or absent."
        v = Validator(
            {'api_token': 'abc', 'session_id': 'xyz'},
            {'api_token': ['prohibits:session_id']},
            custom_attributes={
                'api_token': 'API Token',
                'session_id': 'Session ID'
            }
        )
        v.validate()
        errors = v.errors.get('api_token', [])
        msg = errors[0]
        self.assertNotIn(':attribute', msg)
        self.assertNotIn(':others', msg)
        self.assertIn('API Token', msg)
        self.assertIn('Session ID', msg)

    def test_all_placeholders_combined_custom_message(self):
        """
        Verify that :attribute, :other, :others, :input, and :values 
        can all be used together in a custom message.
        """
        custom_msg = "Attr :attribute with input :input failed. Other: :other. Values: :values."
        v = Validator(
            {'f': 'invalid', 'status': 'active'},
            {'f': ['in:a,b,c']},
            messages={'f.in': custom_msg},
            custom_attributes={'f': 'MyField'}
        )
        # Add a dummy 'other' manually since 'in' doesn't naturally have ':other' but 
        # the replacement logic handles dictionaries. However, 'in' replacements() 
        # doesn't include :other. 
        # Let's use 'required_if' instead which has both :other and :values.
        
        full_custom_msg = "[:attribute] - value '[:input]' invalid. Checked against '[:other]' values: [:values]"
        v = Validator(
            {'f': '', 'status': 'admin'},
            {'f': ['required_if:status,admin,root']},
            messages={'f.required_if': full_custom_msg},
            custom_attributes={'f': 'User Data', 'status': 'User Role'}
        )
        v.validate()
        errors = v.errors.get('f', [])
        msg = errors[0]
        
        # Since custom_attributes are provided, we expect the exact custom names
        self.assertIn('[User Data]', msg)
        self.assertIn("'[]'", msg) # empty string input
        self.assertIn('[User Role]', msg)
        self.assertIn('[admin, root]', msg)
        
        # Ensure no raw placeholders remain
        self.assertNotIn(':attribute', msg)
        self.assertNotIn(':input', msg)
        self.assertNotIn(':other', msg)
        self.assertNotIn(':values', msg)

    def test_no_unreplaced_placeholders_in_any_message(self):
        """
        Run multiple validators and ensure no message ever has an unreplaced placeholder.
        """
        test_cases = [
            ({'f': 2}, {'f': ['min:10']}),
            ({'f': 200}, {'f': ['max:10']}),
            ({'f': 'abc', 'g': 'xyz'}, {'f': ['same:g']}),
            ({'f': 'abc', 'g': 'abc'}, {'f': ['different:g']}),
            ({'f': '', 's': 'act'}, {'f': ['required_if:s,act']}),
            ({'f': 'v', 'g': 'v'}, {'f': ['prohibits:g']}),
            ({'f': 'v', 's': 'act'}, {'f': ['prohibited_if:s,act']}),
            ({'f': 'no', 's': 'act'}, {'f': ['accepted_if:s,act']}),
        ]
        for data, rules in test_cases:
            v = Validator(data, rules)
            v.validate()
            for field, msgs in v.errors.items():
                for msg in msgs:
                    self.assertNotIn(':attribute', msg, f"Unreplaced :attribute in: {msg}")
                    self.assertNotIn(':other', msg, f"Unreplaced :other in: {msg}")
                    self.assertNotIn(':others', msg, f"Unreplaced :others in: {msg}")
                    self.assertNotIn(':input', msg, f"Unreplaced :input in: {msg}")
                    self.assertNotIn(':values', msg, f"Unreplaced :values in: {msg}")


if __name__ == '__main__':
    unittest.main()
