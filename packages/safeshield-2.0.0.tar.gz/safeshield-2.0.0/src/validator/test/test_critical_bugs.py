import unittest
from collections.abc import Sequence, Mapping
from validator.rules.base import Rule
import validator.rules.numeric # Ensure rules are registered
import validator.rules.base # Ensure rules are registered

class TestCriticalBugs(unittest.TestCase):
    """
    Test suite specifically designed to catch structural, architectural, 
    and critical memory/namespace pollution bugs.
    """

    def test_no_abcmeta_pollution(self):
        """
        CRITICAL: Previously, base.py had a bug where validation rules 
        were attached to cls.__class__ inside __init_subclass__.
        Since Rule inherits from ABC, cls.__class__ is ABCMeta.
        This inadvertently attached methods like .numeric(), .required() 
        to EVERY class in Python that uses ABC.
        
        This test ensures global ABCMeta pollution never happens again.
        """
        # Ensure standard library ABC classes are completely free of rule methods
        self.assertFalse(hasattr(Sequence, 'numeric'), 
                         "CRITICAL BUG: Rule methods polluted ABCMeta and standard library classes!")
        self.assertFalse(hasattr(Mapping, 'required'), 
                         "CRITICAL BUG: Rule methods polluted ABCMeta and standard library classes!")
                         
        # Ensure the Rule class itself successfully receives the auto-generated factory methods
        self.assertTrue(hasattr(Rule, 'numeric'), 
                        "Rule base class should have the auto-generated factory methods")

    def test_pascal_to_snake_is_callable(self):
        """
        pascal_to_snake must be defined as a staticmethod so it can be 
        called safely during class creation without requiring an instance.
        """
        result = Rule.pascal_to_snake('MyCustomRule')
        self.assertEqual(result, 'my_custom')
        
        # Test special cases functionality
        self.assertEqual(Rule.pascal_to_snake('UUIDRule'), 'uuid')
        self.assertEqual(Rule.pascal_to_snake('IPRule'), 'ip')

if __name__ == '__main__':
    unittest.main()
