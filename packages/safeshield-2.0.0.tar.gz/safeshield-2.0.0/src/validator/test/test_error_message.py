import unittest
from validator.core.validator import Validator
from validator.rules.base import Rule

class TestErrorMessage(unittest.TestCase):
    def setUp(self):
        self.data = {
            'my_name': 'John',
            'MyName': 15,
            'is_active': 'invalid'
        }

    def test_attribute_capitalization_at_start(self):
        # Test case: :attribute at the beginning of the sentence
        rules = {'my_name': ['min:10']}
        
        # Test default message (usually "The :attribute must be at least :min.")
        # But we'll test it through a custom message to be explicit
        messages = {'my_name.min': ':attribute must be at least :min characters.'}
        validator = Validator(self.data, rules, messages=messages)
        self.assertFalse(validator.validate())
        
        errors = validator.errors
        self.assertIn('my_name', errors)
        self.assertEqual(errors['my_name'][0], 'My name must be at least 10 characters.')

    def test_attribute_capitalization_in_middle(self):
        # Test case: :attribute in the middle of the sentence
        rules = {'my_name': ['min:10']}
        
        messages = {'my_name.min': 'please enter a valid :attribute with a minimum of :min characters.'}
        validator = Validator(self.data, rules, messages=messages)
        self.assertFalse(validator.validate())
        
        errors = validator.errors
        self.assertEqual(errors['my_name'][0], 'please enter a valid my name with a minimum of 10 characters.')

    def test_attribute_capitalization_for_pascal_case_field(self):
        # MyName should be parsed as 'umur saya' and then capitalized
        rules = {'MyName': ['min:20']}
        
        # The base.py _get_display_name converts 'MyName' to 'Umur Saya' normally, 
        # then our error handler will lowercase it to 'umur saya', and capitalize first letter if at start
        messages = {'MyName.min': ':attribute cannot be less than :min.'}
        validator = Validator(self.data, rules, messages=messages)
        self.assertFalse(validator.validate())
        
        errors = validator.errors
        self.assertEqual(errors['MyName'][0], 'Myname cannot be less than 20.')
        
    def test_other_placeholders(self):
        # Testing :value, :input, :min, :max
        rules = {
            'MyName': ['between:20,30'],
            'is_active': ['boolean']
        }
        
        messages = {
            'MyName.between': ':attribute must be between :min and :max.',
            'is_active.boolean': 'The input :input for :attribute is not valid. Must be a boolean.'
        }
        validator = Validator(self.data, rules, messages=messages)
        self.assertFalse(validator.validate())
        
        errors = validator.errors
        self.assertEqual(errors['MyName'][0], 'Myname must be between 20 and 30.')
        self.assertEqual(errors['is_active'][0], 'The input invalid for is active is not valid. Must be a boolean.')


if __name__ == '__main__':
    unittest.main()
