import unittest
from validator.core import Validator

class TestArrayRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            # ArrayRule test data
            'tags': ['python', 'js', 'go'],
            'tuple_tags': ('a', 'b'),
            'set_tags': {'x', 'y'},
            'not_an_array': 'string_value',
            'dict_data': {'key1': 'val1', 'key2': 'val2'},
            
            # DistinctRule test data
            'unique_list': [1, 2, 3, 4],
            'duplicate_list': [1, 2, 2, 4],
            'unique_str_list': ['Apple', 'Banana', 'Cherry'],
            'case_duplicate_list': ['Apple', 'apple', 'Banana'],
            
            # InArrayRule test data
            'target_list': ['apple', 'banana', 'cherry'],
            'value_in': 'banana',
            'value_not_in': 'orange',
            'num_target': [1, 2, 3],
            'num_in': 2,
            'num_not_in': 4,
            
            # InArrayKeysRule test data
            'user_settings': {
                'theme': 'dark',
                'notifications': True,
                'language': 'en'
            },
            'empty_dict': {},
            'not_a_dict': ['theme', 'notifications']
        }

    # 1. ArrayRule Tests
    def test_array_rule_no_params(self):
        # Valid arrays
        self.assertTrue(Validator(self.data, {'tags': ['array']}).validate())
        self.assertTrue(Validator(self.data, {'tuple_tags': ['array']}).validate())
        self.assertTrue(Validator(self.data, {'set_tags': ['array']}).validate())
        
        # Invalid arrays
        self.assertFalse(Validator(self.data, {'not_an_array': ['array']}).validate())
        self.assertFalse(Validator(self.data, {'dict_data': ['array']}).validate())

    def test_array_rule_with_params(self):
        # When params are provided, it checks if the value is a dictionary containing those keys
        # Valid: Dictionary contains all required keys
        self.assertTrue(Validator(self.data, {'dict_data': ['array:key1,key2']}).validate())
        
        # Invalid: Dictionary missing a key
        self.assertFalse(Validator(self.data, {'dict_data': ['array:key1,key3']}).validate())
        
        # Invalid: Not a dictionary
        self.assertFalse(Validator(self.data, {'tags': ['array:0,1']}).validate())

    # 2. DistinctRule Tests
    def test_distinct_rule_strict(self):
        # Valid distinct list
        self.assertTrue(Validator(self.data, {'unique_list': ['distinct']}).validate())
        
        # Invalid: Contains duplicates
        self.assertFalse(Validator(self.data, {'duplicate_list': ['distinct']}).validate())
        
        # Case differentiation (strict mode) - 'Apple' and 'apple' are distinct
        self.assertTrue(Validator(self.data, {'case_duplicate_list': ['distinct']}).validate())

        # Invalid: Not an array-like object
        self.assertFalse(Validator(self.data, {'not_an_array': ['distinct']}).validate())

    def test_distinct_rule_ignore_case(self):
        # Valid distinct strings
        self.assertTrue(Validator(self.data, {'unique_str_list': ['distinct:ignore_case']}).validate())
        
        # Invalid: 'Apple' and 'apple' are considered duplicates
        self.assertFalse(Validator(self.data, {'case_duplicate_list': ['distinct:ignore_case']}).validate())

    # 3. InArrayRule Tests
    def test_in_array_rule(self):
        # Valid: Value exists in the target array field
        self.assertTrue(Validator(self.data, {'value_in': ['in_array:target_list']}).validate())
        
        # Invalid: Value does not exist in target array field
        self.assertFalse(Validator(self.data, {'value_not_in': ['in_array:target_list']}).validate())
        
        # Valid: Number exists in target array
        self.assertTrue(Validator(self.data, {'num_in': ['in_array:num_target']}).validate())
        
        # Invalid: Number does not exist
        self.assertFalse(Validator(self.data, {'num_not_in': ['in_array:num_target']}).validate())
        
        # Invalid: Target field does not exist (returns False because default is [])
        self.assertFalse(Validator(self.data, {'value_in': ['in_array:missing_field']}).validate())

    # 4. InArrayKeysRule Tests
    def test_in_array_keys_rule(self):
        # Valid: Contains at least one of the specified keys
        self.assertTrue(Validator(self.data, {'user_settings': ['in_array_keys:theme,layout']}).validate())
        
        # Valid: Contains all of the specified keys
        self.assertTrue(Validator(self.data, {'user_settings': ['in_array_keys:theme,notifications']}).validate())
        
        # Invalid: Contains none of the specified keys
        self.assertFalse(Validator(self.data, {'user_settings': ['in_array_keys:font,layout']}).validate())
        
        # Invalid: Empty dictionary
        self.assertFalse(Validator(self.data, {'empty_dict': ['in_array_keys:theme']}).validate())
        
        # Invalid: Not a dictionary
        self.assertFalse(Validator(self.data, {'not_a_dict': ['in_array_keys:0,1']}).validate())

if __name__ == '__main__':
    unittest.main()