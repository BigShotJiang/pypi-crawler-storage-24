import unittest
from unittest.mock import MagicMock
from validator.core import Validator
from validator.rules.comparison import EnumRule

class DummyFile:
    def __init__(self, size):
        self.size = size
        self.content_length = size

class DummyFileLike:
    def __init__(self, size):
        self._size = size
        self._pos = 0
        
    def seek(self, pos, whence=0):
        if whence == 2:
            self._pos = self._size
        else:
            self._pos = pos
            
    def tell(self):
        return self._pos
        
    def read(self):
        return b""

class TestComparisonRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            # Min / Max / Between / Size Data
            'num_value': 100,
            'float_value': 5.5,
            'str_value': 'hello world', # len 11
            'num_str_value': '100',
            'list_value': [1, 2, 3, 4, 5], # len 5
            'dummy_file': DummyFile(1024),
            'dummy_file_like': DummyFileLike(2048),
            
            # Same / Different Data
            'password': 'secret123',
            'password_confirm': 'secret123',
            'old_password': 'oldpassword',
            
            # In / NotIn / Contains Data
            'role': 'admin',
            'status_code': 404,
            'tags_list': ['python', 'js', 'go'],
            'settings_dict': {'theme': 'dark', 'notifications': True},
        }

    # 1. MinRule Tests
    def test_min_rule(self):
        # Numeric (100 >= 50, 100 >= 100)
        self.assertTrue(Validator(self.data, {'num_value': ['min:50']}).validate())
        self.assertTrue(Validator(self.data, {'num_value': ['min:100']}).validate())
        self.assertFalse(Validator(self.data, {'num_value': ['min:200']}).validate())
        
        # String length (11 >= 5)
        self.assertTrue(Validator(self.data, {'str_value': ['min:5']}).validate())
        self.assertFalse(Validator(self.data, {'str_value': ['min:20']}).validate())
        
        # List length (5 >= 2)
        self.assertTrue(Validator(self.data, {'list_value': ['min:2']}).validate())
        self.assertFalse(Validator(self.data, {'list_value': ['min:10']}).validate())
        
        # Invalid config
        self.assertFalse(Validator(self.data, {'num_value': ['min:abc']}).validate())

    # 2. MaxRule Tests
    def test_max_rule(self):
        # File object
        self.assertTrue(Validator(self.data, {'dummy_file': ['max:2048']}).validate())
        self.assertFalse(Validator(self.data, {'dummy_file': ['max:500']}).validate())
        
        # File-like object
        self.assertTrue(Validator(self.data, {'dummy_file_like': ['max:3000']}).validate())
        self.assertFalse(Validator(self.data, {'dummy_file_like': ['max:1000']}).validate())
        
        # Numeric
        self.assertTrue(Validator(self.data, {'num_value': ['max:200']}).validate())
        self.assertTrue(Validator(self.data, {'num_value': ['max:100']}).validate())
        self.assertFalse(Validator(self.data, {'num_value': ['max:50']}).validate())
        
        # String Length (always length, not numeric value)
        # num_str_value = '100' → len=3, max:50 → 3 <= 50 → passes
        self.assertTrue(Validator(self.data, {'num_str_value': ['max:200']}).validate())
        self.assertTrue(Validator(self.data, {'num_str_value': ['max:50']}).validate())   # len('100')=3 < 50 → pass
        self.assertFalse(Validator(self.data, {'num_str_value': ['max:2']}).validate())   # len('100')=3 > 2 → fail
        # str_value = 'hello world' len 11
        self.assertTrue(Validator(self.data, {'str_value': ['max:20']}).validate())
        self.assertFalse(Validator(self.data, {'str_value': ['max:5']}).validate())

    # 3. BetweenRule Tests
    def test_between_rule(self):
        # File object
        self.assertTrue(Validator(self.data, {'dummy_file': ['between:500,2048']}).validate())
        self.assertFalse(Validator(self.data, {'dummy_file': ['between:2000,5000']}).validate())
        
        # Numeric
        self.assertTrue(Validator(self.data, {'num_value': ['between:50,150']}).validate())
        self.assertFalse(Validator(self.data, {'num_value': ['between:1,50']}).validate())
        
        # String evaluate as numeric vs length
        self.assertTrue(Validator(self.data, {'num_str_value': ['between:50,150']}).validate()) # 100 within 50-150
        self.assertTrue(Validator(self.data, {'str_value': ['between:5,20']}).validate()) # length 11
        self.assertFalse(Validator(self.data, {'str_value': ['between:1,5']}).validate())
        
        # List length
        self.assertTrue(Validator(self.data, {'list_value': ['between:1,10']}).validate())

    # 4. SizeRule Tests
    def test_size_rule(self):
        # File object
        self.assertTrue(Validator(self.data, {'dummy_file': ['size:1024']}).validate())
        self.assertFalse(Validator(self.data, {'dummy_file': ['size:500']}).validate())
        
        # Numeric
        self.assertTrue(Validator(self.data, {'num_value': ['size:100']}).validate())
        self.assertFalse(Validator(self.data, {'num_value': ['size:50']}).validate())
        
        # String length
        self.assertTrue(Validator(self.data, {'str_value': ['size:11']}).validate())
        self.assertFalse(Validator(self.data, {'str_value': ['size:5']}).validate())
        
        # List length
        self.assertTrue(Validator(self.data, {'list_value': ['size:5']}).validate())
        
        # String numeric
        self.assertTrue(Validator(self.data, {'num_str_value': ['size:100']}).validate())

    # 5. Unique & Exists DB Rule Tests (Mocked)
    # def test_database_rules(self):
    #     mock_db = MagicMock()
    #     mock_db.is_unique.return_value = True
    #     mock_db.exists.return_value = False
        
    #     # Unique
    #     rules_unique = {'str_value': ['unique:users,username']}
    #     v1 = Validator(self.data, rules_unique)
    #     v1.db_manager = mock_db
    #     self.assertTrue(v1.validate())
    #     mock_db.is_unique.assert_called_with('users', 'username', 'hello world', None)
        
    #     # Unique with Ignore ID
    #     rules_unique_ignore = {'str_value': ['unique:users,username,ignore:num_value']}
    #     v2 = Validator(self.data, rules_unique_ignore)
    #     v2.db_manager = mock_db
    #     self.assertTrue(v2.validate())
    #     mock_db.is_unique.assert_called_with('users', 'username', 'hello world', 100)
        
    #     # Exists
    #     rules_exists = {'str_value': ['exists:users,username']}
    #     v3 = Validator(self.data, rules_exists)
    #     v3.db_manager = mock_db
    #     self.assertFalse(v3.validate())
    #     mock_db.exists.assert_called_with('users', 'username', 'hello world')

    # 6. Same & Different Rules
    def test_same_and_different_rules(self):
        # Same
        self.assertTrue(Validator(self.data, {'password': ['same:password_confirm']}).validate())
        self.assertFalse(Validator(self.data, {'password': ['same:old_password']}).validate())
        self.assertFalse(Validator(self.data, {'password': ['same:missing_field']}).validate())
        
        # Different
        self.assertTrue(Validator(self.data, {'password': ['different:old_password']}).validate())
        self.assertFalse(Validator(self.data, {'password': ['different:password_confirm']}).validate())

    # 7. In & NotIn Rules
    def test_in_and_not_in_rules(self):
        # In Rule
        self.assertTrue(Validator(self.data, {'role': ['in:admin,user,manager']}).validate())
        self.assertFalse(Validator(self.data, {'role': ['in:superadmin,guest']}).validate())
        
        # Numeric In
        self.assertTrue(Validator(self.data, {'status_code': ['in:200,404,500']}).validate())
        
        # Not In Rule
        self.assertTrue(Validator(self.data, {'role': ['not_in:guest,banned']}).validate())
        self.assertFalse(Validator(self.data, {'role': ['not_in:admin']}).validate())

    # 8. EnumRule Tests
    def test_enum_rule(self):
        # Basic validate
        v1 = Validator(self.data, {'role': [EnumRule('admin', 'user')]})
        self.assertTrue(v1.validate())
        
        v2 = Validator(self.data, {'role': [EnumRule('guest', 'superadmin')]})
        self.assertFalse(v2.validate())
        
        # exclude()
        v3 = Validator(self.data, {'role': [EnumRule('admin', 'user', 'guest').exclude('guest')]})
        self.assertTrue(v3.validate())
        
        v4 = Validator(self.data, {'role': [EnumRule('guest', 'user').exclude('guest')]})
        self.assertFalse(v4.validate())
        
        # only()
        v5 = Validator(self.data, {'role': [EnumRule('admin', 'user', 'guest').only('admin', 'user')]})
        self.assertTrue(v5.validate())
        
        v6 = Validator(self.data, {'role': [EnumRule('admin', 'user', 'guest').only('guest')]})
        self.assertFalse(v6.validate())

    # 9. Contains Rule Tests
    def test_contains_rule(self):
        # String contains
        self.assertTrue(Validator(self.data, {'str_value': ['contains:world']}).validate())
        self.assertFalse(Validator(self.data, {'str_value': ['contains:mars']}).validate())
        
        # Numeric contains (e.g. 5.5 contains 5)
        self.assertTrue(Validator(self.data, {'float_value': ['contains:5']}).validate())
        
        # List/Tuple/Set contains
        self.assertTrue(Validator(self.data, {'list_value': ['contains:3']}).validate())
        self.assertTrue(Validator(self.data, {'tags_list': ['contains:js']}).validate())
        
        # Dictionary contains key
        self.assertTrue(Validator(self.data, {'settings_dict': ['contains:theme']}).validate())
        self.assertFalse(Validator(self.data, {'settings_dict': ['contains:missing']}).validate())

if __name__ == '__main__':
    unittest.main()