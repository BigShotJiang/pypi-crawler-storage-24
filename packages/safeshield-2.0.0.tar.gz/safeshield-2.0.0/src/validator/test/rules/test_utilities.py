import unittest
from validator.core.validator import Validator

class TestUtilitiesRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            'username': 'john_doe',
            'email': 'john@example.com',
            'role': 'admin',
            'status': 'active',
            'accepted_field': 'yes',
            'declined_field': 'no',
            'none_val': None,
            'empty_str': '',
        }
        # A data dict lacking certain keys for "missing" / "without" variants
        self.sparse_data = {
            'username': 'jane_doe',
            'role': 'guest',
        }
        # A dict for RequiredArrayKeys tests
        self.dict_val = {'name': 'Alice', 'age': 30, 'email': 'a@b.com'}

    # =============================================
    # RequiredIfRule
    # =============================================
    def test_required_if_rule(self):
        # Condition met (role == admin), email must be present — it is
        self.assertTrue(Validator(self.data, {'email': ['required_if:role,admin']}).validate())

        # Condition met but field is empty — fails
        self.assertFalse(Validator(self.data, {'empty_str': ['required_if:role,admin']}).validate())

        # Condition NOT met (role != guest), email not required
        self.assertTrue(Validator(self.data, {'email': ['required_if:role,guest']}).validate())

        # Closure: condition always true
        v = Validator(self.data, {'email': ['required_if:role,admin']})
        self.assertTrue(v.validate())

    # =============================================
    # RequiredUnlessRule
    # =============================================
    def test_required_unless_rule(self):
        # Unless role == admin (it IS admin), email NOT required
        self.assertTrue(Validator(self.data, {'email': ['required_unless:role,admin']}).validate())

        # Unless role == guest (it is NOT guest), email IS required — it's present
        self.assertTrue(Validator(self.data, {'email': ['required_unless:role,guest']}).validate())

        # Unless role == guest, empty_str IS required — it's empty, fails
        self.assertFalse(Validator(self.data, {'empty_str': ['required_unless:role,guest']}).validate())

    # =============================================
    # RequiredWithRule
    # =============================================
    def test_required_with_rule(self):
        # email is present, so username is required — username is present
        self.assertTrue(Validator(self.data, {'username': ['required_with:email']}).validate())

        # email is present, so empty_str is required — empty_str is empty, fails
        self.assertFalse(Validator(self.data, {'empty_str': ['required_with:email']}).validate())

        # missing_key is not in data, condition not triggered
        self.assertTrue(Validator(self.data, {'empty_str': ['required_with:missing_key']}).validate())

    # =============================================
    # RequiredWithAllRule
    # =============================================
    def test_required_with_all_rule(self):
        # Both username and email are present → empty_str is required but empty → FAIL
        self.assertFalse(Validator(self.data, {'empty_str': ['required_with_all:username,email']}).validate())

        # email present but missing_key absent → not all present → doesn't trigger
        self.assertTrue(Validator(self.data, {'empty_str': ['required_with_all:email,missing_key']}).validate())

    # =============================================
    # RequiredWithoutRule
    # =============================================
    def test_required_without_rule(self):
        # missing_key is absent, so username IS required — it is present
        self.assertTrue(Validator(self.data, {'username': ['required_without:missing_key']}).validate())

        # missing_key is absent, so empty_str IS required — it's empty, fails
        self.assertFalse(Validator(self.data, {'empty_str': ['required_without:missing_key']}).validate())

        # email is present, so condition not triggered
        self.assertTrue(Validator(self.data, {'empty_str': ['required_without:email']}).validate())

    # =============================================
    # RequiredWithoutAllRule
    # =============================================
    def test_required_without_all_rule(self):
        # Both missing_key1 and missing_key2 are absent → required → fails if empty_str
        self.assertFalse(Validator(self.data, {'empty_str': ['required_without_all:missing1,missing2']}).validate())

        # email exists, so not all absent → doesn't trigger
        self.assertTrue(Validator(self.data, {'empty_str': ['required_without_all:email,missing_key']}).validate())

    # =============================================
    # RequiredIfAcceptedRule
    # =============================================
    def test_required_if_accepted_rule(self):
        # accepted_field == 'yes', so email IS required — email is present
        self.assertTrue(Validator(self.data, {'email': ['required_if_accepted:accepted_field']}).validate())

        # accepted_field == 'yes', so empty_str IS required — fails
        self.assertFalse(Validator(self.data, {'empty_str': ['required_if_accepted:accepted_field']}).validate())

        # declined_field == 'no', no requirement
        self.assertTrue(Validator(self.data, {'empty_str': ['required_if_accepted:declined_field']}).validate())

    # =============================================
    # RequiredIfDeclinedRule
    # =============================================
    def test_required_if_declined_rule(self):
        # declined_field == 'no', so email IS required — email is present
        self.assertTrue(Validator(self.data, {'email': ['required_if_declined:declined_field']}).validate())

        # declined_field == 'no', so empty_str IS required — fails
        self.assertFalse(Validator(self.data, {'empty_str': ['required_if_declined:declined_field']}).validate())

        # accepted_field == 'yes', no requirement
        self.assertTrue(Validator(self.data, {'empty_str': ['required_if_declined:accepted_field']}).validate())

    # =============================================
    # RequiredArrayKeysRule
    # =============================================
    def test_required_array_keys_rule(self):
        data = {'profile': self.dict_val}
        self.assertTrue(Validator(data, {'profile': ['required_array_keys:name,age,email']}).validate())
        self.assertFalse(Validator(data, {'profile': ['required_array_keys:name,age,phone']}).validate())
        self.assertFalse(Validator({'profile': 'not-a-dict'}, {'profile': ['required_array_keys:name']}).validate())

    # =============================================
    # ProhibitedIfRule
    # =============================================
    def test_prohibited_if_rule(self):
        # Condition met (role == admin), email must NOT be present → it IS present → FAIL
        self.assertFalse(Validator(self.data, {'email': ['prohibited_if:role,admin']}).validate())

        # Condition met, but empty_str — empty counts as ok
        self.assertTrue(Validator(self.data, {'empty_str': ['prohibited_if:role,admin']}).validate())

        # Condition NOT met (role != guest)
        self.assertTrue(Validator(self.data, {'email': ['prohibited_if:role,guest']}).validate())

    # =============================================
    # ProhibitedUnlessRule
    # =============================================
    def test_prohibited_unless_rule(self):
        # Unless role == admin (it IS admin), email is allowed
        self.assertTrue(Validator(self.data, {'email': ['prohibited_unless:role,admin']}).validate())

        # Unless role == admin, email is allowed here
        self.assertTrue(Validator(self.data, {'email': ['prohibited_unless:role,admin']}).validate())

        # Unless role == superuser (it is NOT), email must NOT be present → FAIL
        self.assertFalse(Validator(self.data, {'email': ['prohibited_unless:role,superuser']}).validate())

    # =============================================
    # ProhibitedIfAcceptedRule
    # =============================================
    def test_prohibited_if_accepted_rule(self):
        # accepted_field == 'yes', so email must NOT be present → FAIL
        self.assertFalse(Validator(self.data, {'email': ['prohibited_if_accepted:accepted_field']}).validate())

        # declined_field == 'no' (not accepted), so email can be present
        self.assertTrue(Validator(self.data, {'email': ['prohibited_if_accepted:declined_field']}).validate())

    # =============================================
    # ProhibitedIfDeclinedRule
    # =============================================
    def test_prohibited_if_declined_rule(self):
        # declined_field == 'no', so email must NOT be present → FAIL
        self.assertFalse(Validator(self.data, {'email': ['prohibited_if_declined:declined_field']}).validate())

        # accepted_field == 'yes' (not declined), so email can be present
        self.assertTrue(Validator(self.data, {'email': ['prohibited_if_declined:accepted_field']}).validate())

    # =============================================
    # PresentIfRule
    # =============================================
    def test_present_if_rule(self):
        # Condition met (role == admin), email must be PRESENT — it is
        self.assertTrue(Validator(self.data, {'email': ['present_if:role,admin']}).validate())

        # Condition met, missing_key not in data → should FAIL because it must be present
        self.assertFalse(Validator(self.data, {'missing_key': ['present_if:role,admin']}).validate())

        # Condition not met
        self.assertTrue(Validator(self.data, {'missing_key': ['present_if:role,guest']}).validate())

    # =============================================
    # PresentUnlessRule
    # =============================================
    def test_present_unless_rule(self):
        # Unless role == admin (it IS admin), field not required to be present
        self.assertTrue(Validator(self.data, {'missing_key': ['present_unless:role,admin']}).validate())

        # Unless role == guest (it is NOT guest), field MUST be present
        self.assertTrue(Validator(self.data, {'email': ['present_unless:role,guest']}).validate())
        self.assertFalse(Validator(self.data, {'missing_key': ['present_unless:role,guest']}).validate())

    # =============================================
    # PresentWithRule
    # =============================================
    def test_present_with_rule(self):
        # email is present in data, so username must also be present → it is
        self.assertTrue(Validator(self.data, {'username': ['present_with:email']}).validate())

        # email is present, so missing_key must be present → FAIL
        self.assertFalse(Validator(self.data, {'missing_key': ['present_with:email']}).validate())

        # missing_key_2 is not in data → get_field_value(missing_key_2, None) returns None
        # PresentWithRule checks: any(param is not None) → None is None → False → NOT triggered → OK
        self.assertTrue(Validator(self.data, {'missing_key': ['present_with:missing_key_2']}).validate())

    # =============================================
    # MissingIfRule
    # =============================================
    def test_missing_if_rule(self):
        # Condition met (role == admin): email must be MISSING — but it IS present → FAIL
        self.assertFalse(Validator(self.data, {'email': ['missing_if:role,admin']}).validate())

        # Condition met: none_val must be missing — none_val is None → OK (treated as missing)
        self.assertTrue(Validator(self.data, {'none_val': ['missing_if:role,admin']}).validate())

        # Condition not met
        self.assertTrue(Validator(self.data, {'email': ['missing_if:role,guest']}).validate())

    # =============================================
    # MissingUnlessRule
    # =============================================
    def test_missing_unless_rule(self):
        # Unless role == admin (it IS admin), email not required to be missing
        self.assertTrue(Validator(self.data, {'email': ['missing_unless:role,admin']}).validate())

        # Unless role == guest (it is NOT guest): email MUST be missing → FAIL
        self.assertFalse(Validator(self.data, {'email': ['missing_unless:role,guest']}).validate())

    # =============================================
    # MissingWithRule
    # =============================================
    def test_missing_with_rule(self):
        # email is present → email itself must be missing → FAIL
        self.assertFalse(Validator(self.data, {'email': ['missing_with:username']}).validate())

        # none_val is None → treated as missing → OK
        self.assertTrue(Validator(self.data, {'none_val': ['missing_with:username']}).validate())

        # missing_key absent: get_field_value now returns None → is not None is False → MissingWith NOT triggered
        self.assertTrue(Validator(self.data, {'email': ['missing_with:missing_key']}).validate())

    # =============================================
    # MissingWithAllRule
    # =============================================
    def test_missing_with_all_rule(self):
        # username AND email both present → trigger fires → email must be MISSING → FAIL
        self.assertFalse(Validator(self.data, {'email': ['missing_with_all:username,email']}).validate())

        # missing_key absent: get_field_value now returns None → is not None is False for missing_key
        # all(is not None) → False → MissingWithAll NOT triggered → email can be present
        self.assertTrue(Validator(self.data, {'email': ['missing_with_all:username,missing_key']}).validate())

    # =============================================
    # ExcludeIfRule
    # =============================================
    def test_exclude_if_rule(self):
        # Condition met: role == admin → email excluded from output
        v = Validator(self.data, {'email': ['exclude_if:role,admin']})
        self.assertTrue(v.validate())
        self.assertIn('email', v._field_to_exclude)

        # Condition NOT met: role != guest → email NOT excluded
        v2 = Validator(self.data, {'email': ['exclude_if:role,guest']})
        self.assertTrue(v2.validate())
        self.assertNotIn('email', v2._field_to_exclude)

    # =============================================
    # ExcludeUnlessRule
    # =============================================
    def test_exclude_unless_rule(self):
        # Unless role == admin (it IS admin) → email NOT excluded
        v = Validator(self.data, {'email': ['exclude_unless:role,admin']})
        self.assertTrue(v.validate())
        self.assertNotIn('email', v._field_to_exclude)

        # Unless role == superuser (it is NOT) → email EXCLUDED
        v2 = Validator(self.data, {'email': ['exclude_unless:role,superuser']})
        self.assertTrue(v2.validate())
        self.assertIn('email', v2._field_to_exclude)

    # =============================================
    # ExcludeWithRule
    # =============================================
    def test_exclude_with_rule(self):
        # username is present and non-empty → email is excluded
        v = Validator(self.data, {'email': ['exclude_with:username']})
        self.assertTrue(v.validate())
        self.assertIn('email', v._field_to_exclude)

        # missing_key absent: get_field_value returns None → is_empty(None) is True → ExcludeWith NOT triggered
        v2 = Validator(self.data, {'email': ['exclude_with:missing_key']})
        self.assertTrue(v2.validate())
        self.assertNotIn('email', v2._field_to_exclude)

    # =============================================
    # ExcludeWithoutRule
    # =============================================
    def test_exclude_without_rule(self):
        # missing_key absent: get_field_value returns None → is_empty(None) is True → ExcludeWithout TRIGGERS
        v = Validator(self.data, {'email': ['exclude_without:missing_key']})
        self.assertTrue(v.validate())
        self.assertIn('email', v._field_to_exclude)

        # username present → get_field_value returns 'john_doe' → is_empty('john_doe') is False → NOT triggered
        v2 = Validator(self.data, {'email': ['exclude_without:username']})
        self.assertTrue(v2.validate())
        self.assertNotIn('email', v2._field_to_exclude)

        # empty_str: get_field_value returns '' → is_empty('') is True → ExcludeWithout TRIGGERS
        v3 = Validator(self.data, {'email': ['exclude_without:empty_str']})
        self.assertTrue(v3.validate())
        self.assertIn('email', v3._field_to_exclude)


if __name__ == '__main__':
    unittest.main()