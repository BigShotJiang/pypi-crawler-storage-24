import unittest
from validator.core import Validator
from unittest.mock import MagicMock

class TestConditionalRules(unittest.TestCase):
    def setUp(self):
        self.base_data = {
            'username': 'john_doe',
            'email': 'john@example.com',
            'age': 25,
            'status': 'active',
            'is_verified': True,
            'account_type': 'premium',
            'country': 'US',
            'password': 'secret123',
            'password_confirmation': 'secret123',
            'first_name': 'John',
            'last_name': 'Doe'
        }
        
        # Mock database manager
        self.db_manager = MagicMock()
        self.db_manager.is_unique.return_value = True
        self.db_manager.exists.return_value = True

    def test_required_if_rule(self):
        # Test when condition is met and field is present
        data = self.base_data.copy()
        data['phone'] = '1234567890'
        rules = {'phone': ['required_if:account_type,premium']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when condition is met but field is missing
        rules = {'phone': ['required_if:account_type,premium']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('phone', validator.errors)

        # Test when condition is not met
        data = self.base_data.copy()
        data['account_type'] = 'free'
        rules = {'phone': ['required_if:account_type,premium']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test multiple conditions (OR logic)
        rules = {'phone': ['required_if:account_type,premium,status,inactive']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('phone', validator.errors)

    # def test_required_all_if_rule(self):
    #     # Test when all conditions are met and field is present
    #     data = self.base_data.copy()
    #     data['credit_card'] = '4111111111111111'
    #     rules = {'credit_card': ['required_all_if:account_type,premium,status,active']}
    #     validator = Validator(data, rules)
    #     self.assertTrue(validator.validate())
    #     self.assertEqual(validator.errors, {})

    #     # Test when all conditions are met but field is missing
    #     rules = {'credit_card': ['required_all_if:account_type,premium,status,active']}
    #     validator = Validator(self.base_data, rules)
    #     self.assertFalse(validator.validate())
    #     self.assertIn('credit_card', validator.errors)

    #     # Test when not all conditions are met
    #     data = self.base_data.copy()
    #     data['status'] = 'pending'
    #     rules = {'credit_card': ['required_all_if:account_type,premium,status,active']}
    #     validator = Validator(data, rules)
    #     self.assertTrue(validator.validate())
    #     self.assertEqual(validator.errors, {})

    def test_required_unless_rule(self):
        # Test when unless condition is not met and field is present
        data = self.base_data.copy()
        data['backup_email'] = 'backup@example.com'
        rules = {'backup_email': ['required_unless:account_type,free']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when unless condition is not met but field is missing
        rules = {'backup_email': ['required_unless:account_type,free']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('backup_email', validator.errors)

        # Test when unless condition is met
        data = self.base_data.copy()
        data['account_type'] = 'free'
        rules = {'backup_email': ['required_unless:account_type,free']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

    def test_required_with_rule(self):
        # Test when related field is present and field is present
        data = self.base_data.copy()
        data['last_name'] = 'Doe'
        rules = {'last_name': ['required_with:first_name']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when related field is present but field is missing
        rules = {'name': ['required_with:username']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('name', validator.errors)

        # Test when related field is not present
        rules = {'last_name': ['required_with:nonexistent_field']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test with multiple fields (OR logic)
        rules = {'last_name': ['required_with:first_name,nonexistent_field']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())

    def test_required_with_all_rule(self):
        # Test when all related fields are present and field is present
        data = self.base_data.copy()
        data['billing_address'] = '123 Main St'
        rules = {'billing_address': ['required_with_all:account_type,status']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when all related fields are present but field is missing
        rules = {'billing_address': ['required_with_all:account_type,status']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('billing_address', validator.errors)

        # Test when not all related fields are present
        rules = {'billing_address': ['required_with_all:account_type,nonexistent_field']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

    def test_required_without_rule(self):
        # Test when related field is not present and field is present
        data = {'email': 'test@example.com', 'recovery_email': 'backup@example.com'}
        rules = {'recovery_email': ['required_without:phone']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when related field is not present but field is missing
        rules = {'recovery_email': ['required_without:phone']}
        validator = Validator({'email': 'test@example.com'}, rules)
        self.assertFalse(validator.validate())
        self.assertIn('recovery_email', validator.errors)

        # Test when related field is present
        data = {'email': 'test@example.com', 'phone': '1234567890'}
        rules = {'recovery_email': ['required_without:phone']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test with multiple fields (OR logic)
        rules = {'recovery_email': ['required_without:phone,backup_phone']}
        validator = Validator({'email': 'test@example.com'}, rules)
        self.assertFalse(validator.validate())

    def test_required_without_all_rule(self):
        # Test when none of the related fields are present and field is present
        data = {'email': 'test@example.com', 'recovery_email': 'backup@example.com'}
        rules = {'recovery_email': ['required_without_all:phone,backup_phone']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when none of the related fields are present but field is missing
        rules = {'recovery_email': ['required_without_all:phone,backup_phone']}
        validator = Validator({'email': 'test@example.com'}, rules)
        self.assertFalse(validator.validate())
        self.assertIn('recovery_email', validator.errors)

        # Test when some related fields are present
        data = {'email': 'test@example.com', 'phone': '1234567890'}
        rules = {'recovery_email': ['required_without_all:phone,backup_phone']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

    def test_prohibited_if_rule(self):
        # Test when condition is met and field is not present
        rules = {'trial_code': ['prohibited_if:account_type,premium']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when condition is met but field is present
        data = self.base_data.copy()
        data['trial_code'] = 'FREE123'
        rules = {'trial_code': ['prohibited_if:account_type,premium']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('trial_code', validator.errors)

        # Test when condition is not met
        data = self.base_data.copy()
        data['account_type'] = 'free'
        data['trial_code'] = 'FREE123'
        rules = {'trial_code': ['prohibited_if:account_type,premium']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

    def test_prohibited_unless_rule(self):
        # Test when unless condition is met and field is not present
        rules = {'admin_code': ['prohibited_unless:account_type,admin']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when unless condition is met but field is present
        data = self.base_data.copy()
        data['admin_code'] = 'ADMIN123'
        rules = {'admin_code': ['prohibited_unless:account_type,admin']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('admin_code', validator.errors)

        # Test when unless condition is not met
        data = self.base_data.copy()
        data['account_type'] = 'admin'
        data['admin_code'] = 'ADMIN123'
        rules = {'admin_code': ['prohibited_unless:account_type,admin']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

    def test_confirmed_rule(self):
        # Test when confirmation matches
        rules = {'password': ['confirmed']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when confirmation doesn't match
        data = self.base_data.copy()
        data['password_confirmation'] = 'different'
        rules = {'password': ['confirmed']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('password', validator.errors)

    def test_same_rule(self):
        # Test when fields match
        data = self.base_data.copy()
        data['repeat_password'] = 'secret123'
        rules = {'repeat_password': ['same:password']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when fields don't match
        data = self.base_data.copy()
        data['repeat_password'] = 'different'
        rules = {'repeat_password': ['same:password']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('repeat_password', validator.errors)

    def test_different_rule(self):
        # Test when fields are different
        data = self.base_data.copy()
        data['new_password'] = 'newsecret123'
        rules = {'new_password': ['different:password']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test when fields are the same
        data = self.base_data.copy()
        data['new_password'] = 'secret123'
        rules = {'new_password': ['different:password']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('new_password', validator.errors)

    def test_accepted_rule(self):
        # Test accepted values
        for value in ['yes', 'on', '1', 'true', True, 1]:
            data = {'terms': value}
            rules = {'terms': ['accepted']}
            validator = Validator(data, rules)
            self.assertTrue(validator.validate())
            self.assertEqual(validator.errors, {})

        # Test rejected values
        for value in ['no', 'off', '0', 'false', False, 0, None]:
            data = {'terms': value}
            rules = {'terms': ['accepted']}
            validator = Validator(data, rules)
            self.assertFalse(validator.validate())
            self.assertIn('terms', validator.errors)

    def test_declined_rule(self):
        # Test declined values
        for value in ['no', 'off', '0', 'false', False, 0]:
            data = {'newsletter': value}
            rules = {'newsletter': ['declined']}
            validator = Validator(data, rules)
            self.assertTrue(validator.validate())
            self.assertEqual(validator.errors, {})

        # Test accepted values
        for value in ['yes', 'on', '1', 'true', True, 1]:
            data = {'newsletter': value}
            rules = {'newsletter': ['declined']}
            validator = Validator(data, rules)
            self.assertFalse(validator.validate())
            self.assertIn('newsletter', validator.errors)

    def test_bail_rule(self):
        # Test that validation stops after first failure when bail is used
        rules = {
            'username': ['bail', 'required', 'min:10'],
            'email': ['required', 'email']
        }
        validator = Validator({'email': 'invalid'}, rules)
        self.assertFalse(validator.validate())
        self.assertIn('username', validator.errors)
        self.assertNotIn('email', validator.errors)  # Should stop before email validation

    def test_complex_conditional_rules(self):
        # Test combination of multiple conditional rules
        data = {
            'account_type': 'premium',
            'credit_card': '4111111111111111',
            'free_trial': '',
            'country': 'US',
            'tax_id': ''
        }
        
        rules = {
            'credit_card': [
                # 'required_if:account_type,premium',
                'prohibited_if:account_type,free'
            ],
            'free_trial': [
                # 'prohibited_if:account_type,premium',
                'required_if:account_type,free'
            ],
            'tax_id': [
                'required_unless:country,US',
            ]
        }
        
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual({}, validator.errors)

if __name__ == '__main__':
    unittest.main()