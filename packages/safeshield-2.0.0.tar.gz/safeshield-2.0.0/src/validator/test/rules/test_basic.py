import unittest
from validator.core.validator import Validator
from validator.rules.basic import WhenRule

class TestBasicRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            'username': 'john_doe',
            'email': 'john@example.com',
            'age': 25,
            'empty_str': '',
            'none_val': None,
            'role': 'admin',
            'status': 'active',
            'profile_id': 123
        }

    # 1. AnyOfRule
    def test_any_of_rule(self):
        # Meets first condition
        self.assertTrue(Validator(self.data, {'username': ['any_of:numeric|min:10,string|min:4']}).validate())
        
        # Meets second condition
        self.assertTrue(Validator(self.data, {'age': ['any_of:string,numeric|min:20']}).validate())
        
        # Fails all conditions
        self.assertFalse(Validator(self.data, {'username': ['any_of:numeric,string|min:20']}).validate())

    # 2. WhenRule
    def test_when_rule(self):
        # Native object instantiation for WhenRule (passing directly through rule logic)
        v = Validator(self.data, {
            'email': [WhenRule({
                'role': {
                    'admin': ['required', 'string'],
                    '*': ['nullable']
                }
            })]
        })
        self.assertTrue(v.validate())
        # The prepared rules list for 'email' should now have Received 'required' and 'string'
        new_rules = [r.rule_name for r in v.prepared_rules['email']]
        self.assertIn('required', new_rules)
        self.assertIn('string', new_rules)
        
        # Test wildcard path
        v2 = Validator(self.data, {
            'email': [WhenRule({
                'status': {
                    'inactive': ['nullable'],
                    '*': ['required']
                }
            })]
        })
        self.assertTrue(v2.validate())
        self.assertIn('required', [r.rule_name for r in v2.prepared_rules['email']])

    # 3. BailRule
    def test_bail_rule(self):
        # Should stop on first failure rather than accumulating errors
        v = Validator(self.data, {'age': ['bail', 'string', 'min:100']})
        self.assertFalse(v.validate())
        self.assertEqual(len(v.errors['age']), 1) # Only "string" error, didn't evaluate "min:100"
        
        # Without bail, should get multiple errors
        v2 = Validator(self.data, {'age': ['string', 'min:100']})
        self.assertFalse(v2.validate())
        self.assertGreater(len(v2.errors['age']), 1)

    # 4. RequiredRule
    def test_required_rule(self):
        self.assertTrue(Validator(self.data, {'username': ['required']}).validate())
        self.assertFalse(Validator(self.data, {'empty_str': ['required']}).validate())
        self.assertFalse(Validator(self.data, {'none_val': ['required']}).validate())
        self.assertFalse(Validator({'key': 'val'}, {'missing_key': ['required']}).validate())

    # 5. ProhibitedRule
    def test_prohibited_rule(self):
        self.assertTrue(Validator(self.data, {'empty_str': ['prohibited']}).validate())
        self.assertTrue(Validator(self.data, {'none_val': ['prohibited']}).validate())
        self.assertFalse(Validator(self.data, {'username': ['prohibited']}).validate())

    # 6. NullableRule
    def test_nullable_rule(self):
        # Nullable logic is primarily handled by the Validator core short-circuiting,
        # but the rule itself evaluates to True
        self.assertTrue(Validator(self.data, {'none_val': ['nullable']}).validate())
        self.assertTrue(Validator(self.data, {'username': ['nullable']}).validate())

    # 7. FilledRule
    def test_filled_rule(self):
        self.assertTrue(Validator(self.data, {'username': ['filled']}).validate())
        self.assertFalse(Validator(self.data, {'empty_str': ['filled']}).validate())
        self.assertFalse(Validator(self.data, {'none_val': ['filled']}).validate())

    # 8. PresentRule
    def test_present_rule(self):
        self.assertTrue(Validator(self.data, {'empty_str': ['present']}).validate())
        self.assertTrue(Validator(self.data, {'none_val': ['present']}).validate())
        self.assertFalse(Validator({'key': 'val'}, {'missing_key': ['present']}).validate())

    # 9. MissingRule
    def test_missing_rule(self):
        # In this implementation, MissingRule evaluates "is None" instead of "not in dict"
        self.assertTrue(Validator(self.data, {'none_val': ['missing']}).validate())
        # An actually missing field gets defaulted to None during lookup in Validator logic
        self.assertTrue(Validator({'key': 'val'}, {'missing_key': ['missing']}).validate())
        self.assertFalse(Validator(self.data, {'username': ['missing']}).validate())

    # 10. ProhibitsRule
    def test_prohibits_rule(self):
        # When 'username' is present, 'empty_str' and 'missing_val' must be empty or missing from original dict
        # In Python context, 'missing_val' is not in data dict, so it passes
        self.assertTrue(Validator({'username': 'a'}, {'username': ['prohibits:missing_val']}).validate())
        
        # When 'username' is present, 'email' is present -> Fails
        self.assertFalse(Validator(self.data, {'username': ['prohibits:email']}).validate())
        
        # When target is not provided (None/Empty), allows anything
        self.assertTrue(Validator({'none_val': '', 'email':'a'}, {'none_val': ['prohibits:email']}).validate())

    # 11. SometimesRule
    def test_sometimes_rule(self):
        # Should record the field in _field_to_exclude when value is None
        v = Validator(self.data, {'none_val': ['sometimes', 'string']})
        # Note: the Validator core short-circuits if Sometimes is None, preventing 'string' from checking
        self.assertTrue(v.validate())
        
        # When value is present, should execute the rest of the rules normally
        v2 = Validator(self.data, {'age': ['sometimes', 'string']})
        self.assertFalse(v2.validate()) # Fails 'string' rule

    # 12. ExcludeRule
    def test_exclude_rule(self):
        v = Validator(self.data, {'username': ['exclude']})
        # The rule itself always returns True
        self.assertTrue(v.validate())
        # Validator logic appends it to _field_to_exclude
        self.assertIn('username', v._field_to_exclude)

if __name__ == '__main__':
    unittest.main()
