import unittest
from validator.core import Validator
from unittest.mock import MagicMock
from datetime import datetime, timedelta

class TestTypeValidationRules(unittest.TestCase):
    def setUp(self):
        self.base_data = {
            'age': 25,
            'price': 19.99,
            'quantity': '100',
            'is_active': True,
            'is_admin': 'true',
            'tags': ['python', 'testing'],
            'user_data': {'name': 'John', 'age': 30},
            'birth_date': '1990-05-15',
            'due_date': '15/05/2023',
            'meeting_date': '2023.05.20',
            'start_date': '05-20-2023'
        }
        
        # Mock database manager
        self.db_manager = MagicMock()
        self.db_manager.is_unique.return_value = True
        self.db_manager.exists.return_value = True

    def test_numeric_rule(self):
        # Test valid integer
        rules = {'age': ['numeric']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid float
        rules = {'price': ['numeric']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid numeric string
        rules = {'quantity': ['numeric']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test invalid non-numeric
        data = self.base_data.copy()
        data['age'] = 'twenty-five'
        validator = Validator(data, {'age': ['numeric']})
        self.assertFalse(validator.validate())
        self.assertIn('age', validator.errors)

    def test_integer_rule(self):
        # Test valid integer
        rules = {'age': ['integer']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid integer string
        rules = {'quantity': ['integer']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test invalid float
        data = self.base_data.copy()
        data['age'] = 25.5
        validator = Validator(data, {'age': ['integer']})
        self.assertFalse(validator.validate())
        
        # Test invalid float string
        data['age'] = '25.5'
        validator = Validator(data, {'age': ['integer']})
        self.assertFalse(validator.validate())

    def test_boolean_rule(self):
        # Test valid boolean True
        rules = {'is_active': ['boolean']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid boolean False
        data = self.base_data.copy()
        data['is_active'] = False
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid boolean string
        rules = {'is_admin': ['boolean']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test invalid boolean
        data['is_admin'] = 'enabled'
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())

    def test_array_rule(self):
        # Test valid list
        rules = {'tags': ['array']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid tuple
        data = self.base_data.copy()
        data['tags'] = ('python', 'testing')
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid set
        data['tags'] = {'python', 'testing'}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        
        # Test invalid non-array
        data['tags'] = 'not an array'
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        
        # Test array with required keys (dictionary validation)
        rules = {'user_data': ['array:name,age']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test missing required key
        rules = {'user_data': ['array:name,age,email']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('user_data', validator.errors)

    def test_date_rule(self):
        # Test valid ISO date
        rules = {'birth_date': ['date']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid slash date
        rules = {'due_date': ['date']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid dot date
        rules = {'meeting_date': ['date']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test valid dash date
        rules = {'start_date': ['date']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        data = self.base_data.copy()
        data['birth_date'] = '15 May 1990'
        validator = Validator(data, {'birth_date': ['date']})
        self.assertTrue(validator.validate())
        
        # Test non-string date
        data['birth_date'] = datetime.now()
        validator = Validator(data, {'birth_date': ['date']})
        self.assertFalse(validator.validate())

    def test_date_equals_rule(self):
        # Test equal dates (ISO format)
        rules = {'birth_date': ['date_equals:1990-05-15']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test equal dates (different formats)
        rules = {'due_date': ['date_equals:2023/05/15']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        
        # Test not equal dates
        rules = {'meeting_date': ['date_equals:2023-05-21']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        
        # Test invalid date format
        rules = {'start_date': ['date_equals:May 20 2023']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())

if __name__ == '__main__':
    unittest.main()