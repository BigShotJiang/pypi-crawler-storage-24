import unittest
import json
import uuid
from validator.core.validator import Validator
from validator.rules.format import (
    EmailRule, UrlRule, JsonRule, UuidRule, UlidRule, IpRule, HexRule
)

class TestFormatRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            # Email Cases
            'email_valid': 'test@example.com',
            'email_invalid': 'test@example',
            'email_dots': 'test..name@example.com',
            'email_leading_dot': '.test@example.com',
            'email_trailing_dot': 'test@example.com.',
            'email_real_dns': 'test@gmail.com', # Assuming google has MX
            'email_fake_dns': 'test@thisisafakedomainthathopfullydoesnotexist123.com',
            'email_spoof': 't\u0435st@example.com', # Cyrillic 'e' spoof
            
            # URL Cases
            'url_http': 'http://example.com',
            'url_https': 'https://www.example.co.uk/path?q=1',
            'url_no_proto': 'example.com',
            'url_invalid': 'not_a_url',
            
            # JSON Cases
            'json_valid_obj': '{"key": "value"}',
            'json_valid_arr': '[1, 2, 3]',
            'json_invalid': '{key: "value"}', # Unquoted keys
            'json_empty': '',
            
            # UUID Cases
            'uuid_valid': str(uuid.uuid4()),
            'uuid_invalid_chars': 'z' * 36,
            'uuid_invalid_length': '12345678-1234-5678-1234-56781234567',
            
            # ULID Cases (26 chars [0-9A-HJKMNP-TV-Z])
            'ulid_valid': '01ARZ3NDEKTSV4RRFFQ69G5FAV',
            'ulid_lowercase': '01arz3ndektsv4rrffq69g5fav', # Rule checks uppercase or fails?
            'ulid_invalid_char': '01ARZ3NDEKTSV4RRFFQ69G5FAU', # 'U' is invalid in ULID
            'ulid_invalid_len': '01ARZ3NDEKTSV4RRFFQ69G5FA',
            
            # IP Cases
            'ip_v4': '192.168.1.1',
            'ip_v6': '2001:0db8:85a3:0000:0000:8a2e:0370:7334',
            'ip_invalid_v4': '256.256.256.256',
            'ip_invalid_str': 'not_an_ip',
            
            # Hex Cases
            'hex_#6': '#FF00AA',
            'hex_6': 'ff00aa',
            'hex_#3': '#F0A',
            'hex_3': 'f0a',
            'hex_invalid_chars': '#GG0000',
            'hex_invalid_len': '#1234',
            
            'non_string': 12345,
        }

    # 1. EmailRule
    def test_email_rule(self):
        # Default (rfc)
        self.assertTrue(Validator(self.data, {'email_valid': ['email']}).validate())
        self.assertFalse(Validator(self.data, {'email_invalid': ['email']}).validate())
        
        # Strict
        self.assertTrue(Validator(self.data, {'email_valid': ['email:strict']}).validate())
        self.assertFalse(Validator(self.data, {'email_dots': ['email:strict']}).validate())
        self.assertFalse(Validator(self.data, {'email_leading_dot': ['email:strict']}).validate())
        
        # DNS
        # DNS test might be flaky depending on environment, but google.com should always resolve
        self.assertTrue(Validator(self.data, {'email_real_dns': ['email:dns']}).validate())
        self.assertFalse(Validator(self.data, {'email_fake_dns': ['email:dns']}).validate())
        
        # Spoof
        self.assertTrue(Validator(self.data, {'email_valid': ['email:spoof']}).validate())
        self.assertFalse(Validator(self.data, {'email_spoof': ['email:spoof']}).validate())
        
        def test_email_filter(self):
            self.assertTrue(Validator(self.data, {'email_valid': ['email:filter']}).validate())

    # 2. UrlRule
    def test_url_rule(self):
        self.assertTrue(Validator(self.data, {'url_http': ['url']}).validate())
        self.assertTrue(Validator(self.data, {'url_https': ['url']}).validate())
        self.assertTrue(Validator(self.data, {'url_no_proto': ['url']}).validate())
        
        self.assertFalse(Validator(self.data, {'url_invalid': ['url']}).validate())
        self.assertFalse(Validator(self.data, {'non_string': ['url']}).validate())

    # 3. JsonRule
    def test_json_rule(self):
        self.assertTrue(Validator(self.data, {'json_valid_obj': ['json']}).validate())
        self.assertTrue(Validator(self.data, {'json_valid_arr': ['json']}).validate())
        
        self.assertFalse(Validator(self.data, {'json_invalid': ['json']}).validate())
        self.assertFalse(Validator(self.data, {'json_empty': ['json']}).validate())
        self.assertFalse(Validator(self.data, {'non_string': ['json']}).validate())

    # 4. UuidRule
    def test_uuid_rule(self):
        self.assertTrue(Validator(self.data, {'uuid_valid': ['uuid']}).validate())
        
        self.assertFalse(Validator(self.data, {'uuid_invalid_chars': ['uuid']}).validate())
        self.assertFalse(Validator(self.data, {'uuid_invalid_length': ['uuid']}).validate())
        self.assertFalse(Validator(self.data, {'non_string': ['uuid']}).validate())

    # 5. UlidRule
    def test_ulid_rule(self):
        self.assertTrue(Validator(self.data, {'ulid_valid': ['ulid']}).validate())
        
        # The current regex is uppercase only
        self.assertFalse(Validator(self.data, {'ulid_lowercase': ['ulid']}).validate())
        self.assertFalse(Validator(self.data, {'ulid_invalid_char': ['ulid']}).validate())
        self.assertFalse(Validator(self.data, {'ulid_invalid_len': ['ulid']}).validate())
        self.assertFalse(Validator(self.data, {'non_string': ['ulid']}).validate())

    # 6. IpRule
    def test_ip_rule(self):
        self.assertTrue(Validator(self.data, {'ip_v4': ['ip']}).validate())
        self.assertTrue(Validator(self.data, {'ip_v6': ['ip']}).validate())
        
        self.assertFalse(Validator(self.data, {'ip_invalid_v4': ['ip']}).validate())
        self.assertFalse(Validator(self.data, {'ip_invalid_str': ['ip']}).validate())
        self.assertFalse(Validator(self.data, {'non_string': ['ip']}).validate())

    # 7. HexRule
    def test_hex_rule(self):
        self.assertTrue(Validator(self.data, {'hex_#6': ['hex']}).validate())
        self.assertTrue(Validator(self.data, {'hex_6': ['hex']}).validate())
        self.assertTrue(Validator(self.data, {'hex_#3': ['hex']}).validate())
        self.assertTrue(Validator(self.data, {'hex_3': ['hex']}).validate())
        
        self.assertFalse(Validator(self.data, {'hex_invalid_chars': ['hex']}).validate())
        self.assertFalse(Validator(self.data, {'hex_invalid_len': ['hex']}).validate())
        self.assertFalse(Validator(self.data, {'non_string': ['hex']}).validate())

if __name__ == '__main__':
    unittest.main()