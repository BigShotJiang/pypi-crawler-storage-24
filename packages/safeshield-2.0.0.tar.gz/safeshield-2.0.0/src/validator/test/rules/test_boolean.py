import unittest
from validator.core.validator import Validator
from validator.rules.boolean import (
    BooleanRule, AcceptedRule, DeclinedRule,
    AcceptedIfRule, AcceptedUnlessRule,
    DeclinedIfRule, DeclinedUnlessRule
)

class TestBooleanRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            'bool_true': True,
            'bool_false': False,
            'str_true': 'true',
            'str_false': 'false',
            'str_1': '1',
            'str_0': '0',
            'int_1': 1,
            'int_0': 0,
            'str_yes': 'yes',
            'str_no': 'no',
            'str_on': 'on',
            'str_off': 'off',
            'str_invalid': 'invalid',
            'int_invalid': 2,
            
            'is_admin': 'yes',
            'is_guest': 'no',
            'role': 'admin',
        }

    # 1. BooleanRule
    def test_boolean_rule(self):
        # Valid true values
        self.assertTrue(Validator(self.data, {'bool_true': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_true': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_1': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_yes': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_on': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'int_1': ['boolean']}).validate())
        
        # Valid false values
        self.assertTrue(Validator(self.data, {'bool_false': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_false': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_0': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_no': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'str_off': ['boolean']}).validate())
        self.assertTrue(Validator(self.data, {'int_0': ['boolean']}).validate())
        
        # Invalid values
        self.assertFalse(Validator(self.data, {'str_invalid': ['boolean']}).validate())
        self.assertFalse(Validator(self.data, {'int_invalid': ['boolean']}).validate())

    # 2. AcceptedRule
    def test_accepted_rule(self):
        self.assertTrue(Validator(self.data, {'bool_true': ['accepted']}).validate())
        self.assertTrue(Validator(self.data, {'str_yes': ['accepted']}).validate())
        self.assertTrue(Validator(self.data, {'str_on': ['accepted']}).validate())
        self.assertTrue(Validator(self.data, {'str_1': ['accepted']}).validate())
        self.assertTrue(Validator(self.data, {'str_true': ['accepted']}).validate())
        self.assertTrue(Validator(self.data, {'int_1': ['accepted']}).validate())
        
        # Fails on false or invalid
        self.assertFalse(Validator(self.data, {'bool_false': ['accepted']}).validate())
        self.assertFalse(Validator(self.data, {'str_no': ['accepted']}).validate())
        self.assertFalse(Validator(self.data, {'str_invalid': ['accepted']}).validate())

    # 3. DeclinedRule
    def test_declined_rule(self):
        self.assertTrue(Validator(self.data, {'bool_false': ['declined']}).validate())
        self.assertTrue(Validator(self.data, {'str_no': ['declined']}).validate())
        self.assertTrue(Validator(self.data, {'str_off': ['declined']}).validate())
        self.assertTrue(Validator(self.data, {'str_0': ['declined']}).validate())
        self.assertTrue(Validator(self.data, {'str_false': ['declined']}).validate())
        self.assertTrue(Validator(self.data, {'int_0': ['declined']}).validate())
        
        # Fails on true or invalid
        self.assertFalse(Validator(self.data, {'bool_true': ['declined']}).validate())
        self.assertFalse(Validator(self.data, {'str_yes': ['declined']}).validate())
        self.assertFalse(Validator(self.data, {'str_invalid': ['declined']}).validate())

    # 4. AcceptedIfRule
    def test_accepted_if_rule(self):
        # Condition met (role == admin), must be accepted
        self.assertTrue(Validator(self.data, {'str_yes': ['accepted_if:role,admin']}).validate())
        self.assertFalse(Validator(self.data, {'str_no': ['accepted_if:role,admin']}).validate())
        
        # Condition not met (role == user), no need to be accepted
        self.assertTrue(Validator(self.data, {'str_no': ['accepted_if:role,user']}).validate())
        
        # Native object tests for callable and bool
        rule_callable_true = AcceptedIfRule(lambda data: True)
        rule_callable_true._validator = Validator(self.data)
        self.assertTrue(rule_callable_true.validate('str_yes', 'yes', [lambda data: True]))
        self.assertFalse(rule_callable_true.validate('str_no', 'no', [lambda data: True]))
        
        rule_callable_false = AcceptedIfRule(lambda data: False)
        rule_callable_false._validator = Validator(self.data)
        self.assertTrue(rule_callable_false.validate('str_no', 'no', [lambda data: False]))

        rule_bool_true = AcceptedIfRule(True)
        rule_bool_true._validator = Validator(self.data)
        self.assertTrue(rule_bool_true.validate('str_yes', 'yes', [True]))
        self.assertFalse(rule_bool_true.validate('str_no', 'no', [True]))

    # 5. AcceptedUnlessRule
    def test_accepted_unless_rule(self):
        # Unless role == admin (not equal to user, so MUST be accepted)
        self.assertTrue(Validator(self.data, {'str_yes': ['accepted_unless:role,user']}).validate())
        self.assertFalse(Validator(self.data, {'str_no': ['accepted_unless:role,user']}).validate())
        
        # Unless role == admin (equal to admin, so DOES NOT NEED to be accepted)
        self.assertTrue(Validator(self.data, {'str_no': ['accepted_unless:role,admin']}).validate())

    # 6. DeclinedIfRule
    def test_declined_if_rule(self):
        # Condition met (role == admin), must be declined
        self.assertTrue(Validator(self.data, {'str_no': ['declined_if:role,admin']}).validate())
        self.assertFalse(Validator(self.data, {'str_yes': ['declined_if:role,admin']}).validate())
        
        # Condition not met (role == user), no need to be declined
        self.assertTrue(Validator(self.data, {'str_yes': ['declined_if:role,user']}).validate())
        
        # Native object tests for callable and bool
        rule_callable_true = DeclinedIfRule(lambda data: True)
        rule_callable_true._validator = Validator(self.data)
        self.assertTrue(rule_callable_true.validate('str_no', 'no', [lambda data: True]))
        self.assertFalse(rule_callable_true.validate('str_yes', 'yes', [lambda data: True]))
        
        rule_callable_false = DeclinedIfRule(lambda data: False)
        rule_callable_false._validator = Validator(self.data)
        self.assertTrue(rule_callable_false.validate('str_yes', 'yes', [lambda data: False]))

        rule_bool_true = DeclinedIfRule(True)
        rule_bool_true._validator = Validator(self.data)
        self.assertTrue(rule_bool_true.validate('str_no', 'no', [True]))
        self.assertFalse(rule_bool_true.validate('str_yes', 'yes', [True]))

    # 7. DeclinedUnlessRule
    def test_declined_unless_rule(self):
        # Unless role == user (not equal to user, so MUST be declined)
        self.assertTrue(Validator(self.data, {'str_no': ['declined_unless:role,user']}).validate())
        self.assertFalse(Validator(self.data, {'str_yes': ['declined_unless:role,user']}).validate())
        
        # Unless role == admin (equal to admin, so DOES NOT NEED to be declined)
        self.assertTrue(Validator(self.data, {'str_yes': ['declined_unless:role,admin']}).validate())

if __name__ == '__main__':
    unittest.main()
