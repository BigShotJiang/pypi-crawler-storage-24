import unittest
from validator.core.validator import Validator
from validator.rules.string import (
    StringRule, AlphaRule, AlphaDashRule, AlphaNumRule,
    UppercaseRule, LowercaseRule, AsciiRule,
    StartsWithRule, DoesntStartWithRule,
    EndsWithRule, DoesntEndWithRule,
    ConfirmedRule, RegexRule, NotRegexRule
)

class TestStringRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            # Base types
            'string_val': 'hello world',
            'int_val': 123,
            
            # Alpha
            'alpha_val': 'HelloWorld',
            'alpha_invalid': 'Hello World 123!',
            
            # AlphaDash
            'alphadash_val': 'Hello-World_123',
            'alphadash_invalid': 'Hello@World',
            
            # AlphaNum
            'alphanum_val': 'HelloWorld123',
            'alphanum_invalid': 'HelloWorld 123!',
            
            # Cases
            'upper_val': 'HELLO WORLD',
            'lower_val': 'hello world',
            'mixed_val': 'Hello World',
            
            # ASCII
            'ascii_val': 'hello world 123!',
            'non_ascii_val': 'héllo wörld',
            
            # Prefix/Suffix
            'prefix_suffix_val': 'prefix-content-suffix',
            'single_char': 'a',
            
            # Confirmation
            'password': 'mysecretpassword123',
            'password_confirmation': 'mysecretpassword123',
            'password_wrong_confirmation': 'differentpassword',
            
            # Regex
            'regex_match': 'ABC-123',
            'regex_no_match': 'ab-1234',
            'regex_invalid_pattern': '***',
        }

    # 1. StringRule
    def test_string_rule(self):
        self.assertTrue(Validator(self.data, {'string_val': ['string']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['string']}).validate())

    # 2. AlphaRule
    def test_alpha_rule(self):
        self.assertTrue(Validator(self.data, {'alpha_val': ['alpha']}).validate())
        
        self.assertFalse(Validator(self.data, {'alpha_invalid': ['alpha']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['alpha']}).validate())

    # 3. AlphaDashRule
    def test_alpha_dash_rule(self):
        self.assertTrue(Validator(self.data, {'alphadash_val': ['alpha_dash']}).validate())
        
        self.assertFalse(Validator(self.data, {'alphadash_invalid': ['alpha_dash']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['alpha_dash']}).validate())

    # 4. AlphaNumRule
    def test_alpha_num_rule(self):
        self.assertTrue(Validator(self.data, {'alphanum_val': ['alpha_num']}).validate())
        self.assertTrue(Validator(self.data, {'alpha_val': ['alpha_num']}).validate())
        
        self.assertFalse(Validator(self.data, {'alphanum_invalid': ['alpha_num']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['alpha_num']}).validate())

    # 5. UppercaseRule
    def test_uppercase_rule(self):
        self.assertTrue(Validator(self.data, {'upper_val': ['uppercase']}).validate())
        
        self.assertFalse(Validator(self.data, {'lower_val': ['uppercase']}).validate())
        self.assertFalse(Validator(self.data, {'mixed_val': ['uppercase']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['uppercase']}).validate())

    # 6. LowercaseRule
    def test_lowercase_rule(self):
        self.assertTrue(Validator(self.data, {'lower_val': ['lowercase']}).validate())
        
        self.assertFalse(Validator(self.data, {'upper_val': ['lowercase']}).validate())
        self.assertFalse(Validator(self.data, {'mixed_val': ['lowercase']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['lowercase']}).validate())

    # 7. AsciiRule
    def test_ascii_rule(self):
        self.assertTrue(Validator(self.data, {'ascii_val': ['ascii']}).validate())
        
        self.assertFalse(Validator(self.data, {'non_ascii_val': ['ascii']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['ascii']}).validate())

    # 8. StartsWithRule
    def test_starts_with_rule(self):
        self.assertTrue(Validator(self.data, {'prefix_suffix_val': ['starts_with:prefix,pre,pro']}).validate())
        self.assertTrue(Validator(self.data, {'prefix_suffix_val': ['starts_with:prefix-']}).validate())
        
        self.assertFalse(Validator(self.data, {'prefix_suffix_val': ['starts_with:suffix']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['starts_with:12']}).validate())

    # 9. DoesntStartWithRule
    def test_doesnt_start_with_rule(self):
        self.assertTrue(Validator(self.data, {'prefix_suffix_val': ['doesnt_start_with:suffix,content']}).validate())
        
        self.assertFalse(Validator(self.data, {'prefix_suffix_val': ['doesnt_start_with:prefix,content']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['doesnt_start_with:prefix']}).validate())

    # 10. EndsWithRule
    def test_ends_with_rule(self):
        self.assertTrue(Validator(self.data, {'prefix_suffix_val': ['ends_with:suffix,-suffix,x']}).validate())
        
        self.assertFalse(Validator(self.data, {'prefix_suffix_val': ['ends_with:prefix,content']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['ends_with:12']}).validate())

    # 11. DoesntEndWithRule
    def test_doesnt_end_with_rule(self):
        self.assertTrue(Validator(self.data, {'prefix_suffix_val': ['doesnt_end_with:prefix,content']}).validate())
        
        self.assertFalse(Validator(self.data, {'prefix_suffix_val': ['doesnt_end_with:suffix,content']}).validate())
        self.assertFalse(Validator(self.data, {'prefix_suffix_val': ['doesnt_end_with:suffix']}).validate()) # Direct check
        self.assertFalse(Validator(self.data, {'int_val': ['doesnt_end_with:suffix']}).validate()) # Not string
        
        # Test empty params
        t = DoesntEndWithRule()
        t._validator = Validator(self.data)
        self.assertFalse(t.validate('prefix_suffix_val', 'prefix_suffix_val', []))

    # 12. ConfirmedRule
    def test_confirmed_rule(self):
        self.assertTrue(Validator(self.data, {'password': ['confirmed']}).validate())
        
        self.assertFalse(Validator(self.data, {'password_wrong_confirmation': ['confirmed']}).validate())
        self.assertFalse(Validator(self.data, {'mixed_val': ['confirmed']}).validate()) # Missing confirmation field

    # 13. RegexRule
    def test_regex_rule(self):
        self.assertTrue(Validator(self.data, {'regex_match': ['regex:^[A-Z]{3}-[0-9]{3}$']}).validate())
        
        # Fails regex requirement
        self.assertFalse(Validator(self.data, {'regex_no_match': ['regex:^[A-Z]{3}-[0-9]{3}$']}).validate())
        self.assertFalse(Validator(self.data, {'int_val': ['regex:^[A-Z]{3}-[0-9]{3}$']}).validate()) # Not string
        
        # Internal rule checks invalid regex handling. Should catch re.error and return False.
        self.assertFalse(Validator(self.data, {'regex_match': ['regex:[']}).validate())

    # 14. NotRegexRule
    def test_not_regex_rule(self):
        # We don't want it to match ^[A-Z]{3}-[0-9]{3}$
        self.assertTrue(Validator(self.data, {'regex_no_match': ['not_regex:^[A-Z]{3}-[0-9]{3}$']}).validate())
        
        # It DOES match, so this should fail the "not_regex" check
        self.assertFalse(Validator(self.data, {'regex_match': ['not_regex:^[A-Z]{3}-[0-9]{3}$']}).validate())
        
        # Fallback behaviour on invalid regex handles properly (returns True since it strictly fails to match)
        self.assertTrue(Validator(self.data, {'regex_match': ['not_regex:[']}).validate())

if __name__ == '__main__':
    unittest.main()