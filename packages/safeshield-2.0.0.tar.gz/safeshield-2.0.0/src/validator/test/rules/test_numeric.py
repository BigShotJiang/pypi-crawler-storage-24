import unittest
from validator.core.validator import Validator

class TestNumericRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            # Numeric
            'int_val': 42,
            'float_val': 3.14,
            'str_int': '123',
            'str_float': '3.14',
            'str_invalid': 'abc',
            'bool_val': True,
            'list_val': [1, 2],
            'negative': -5,
            'str_negative': '-5',

            # Digits
            'digits_4': '1234',
            'digits_5': '12345',
            'digits_3': '123',
            'str_with_dot': '12.34',
            'empty_str': '',

            # Comparisons
            'ten': 10,
            'five': 5,
            'ten_float': 10.0,
            'str_ten': '10',

            # MultipleOf
            'twelve': 12,
            'seven': 7,

            # Decimal
            'decimal_str': '1234.56',
            'decimal_neg': '-0.001',
        }

    # 1. NumericRule
    def test_numeric_rule(self):
        self.assertTrue(Validator(self.data, {'int_val': ['numeric']}).validate())
        self.assertTrue(Validator(self.data, {'float_val': ['numeric']}).validate())
        self.assertTrue(Validator(self.data, {'str_int': ['numeric']}).validate())
        self.assertTrue(Validator(self.data, {'str_float': ['numeric']}).validate())

        self.assertFalse(Validator(self.data, {'str_invalid': ['numeric']}).validate())
        self.assertFalse(Validator(self.data, {'list_val': ['numeric']}).validate())
        self.assertFalse(Validator(self.data, {'str_negative': ['numeric']}).validate())  # '-5' has no '.', isdigit() fails

    # 2. IntegerRule
    def test_integer_rule(self):
        self.assertTrue(Validator(self.data, {'int_val': ['integer']}).validate())
        self.assertTrue(Validator(self.data, {'str_int': ['integer']}).validate())

        self.assertFalse(Validator(self.data, {'float_val': ['integer']}).validate())
        self.assertFalse(Validator(self.data, {'str_float': ['integer']}).validate())
        self.assertFalse(Validator(self.data, {'str_invalid': ['integer']}).validate())

    # 3. DigitsRule
    def test_digits_rule(self):
        self.assertTrue(Validator(self.data, {'digits_4': ['digits:4']}).validate())

        # Wrong length
        self.assertFalse(Validator(self.data, {'digits_4': ['digits:5']}).validate())
        self.assertFalse(Validator(self.data, {'digits_3': ['digits:4']}).validate())
        # Has a dot
        self.assertFalse(Validator(self.data, {'str_float': ['digits:4']}).validate())
        # Empty string
        self.assertFalse(Validator(self.data, {'empty_str': ['digits:0']}).validate())

    # 4. DigitsBetweenRule
    def test_digits_between_rule(self):
        self.assertTrue(Validator(self.data, {'digits_4': ['digits_between:3,5']}).validate())
        self.assertTrue(Validator(self.data, {'digits_3': ['digits_between:3,5']}).validate())
        self.assertTrue(Validator(self.data, {'digits_5': ['digits_between:3,5']}).validate())

        # Out of range
        self.assertFalse(Validator(self.data, {'digits_3': ['digits_between:4,5']}).validate())
        self.assertFalse(Validator(self.data, {'digits_5': ['digits_between:2,4']}).validate())
        # Non-digit
        self.assertFalse(Validator(self.data, {'str_float': ['digits_between:1,6']}).validate())

    # 5. DecimalRule
    def test_decimal_rule(self):
        self.assertTrue(Validator(self.data, {'decimal_str': ['decimal']}).validate())
        self.assertTrue(Validator(self.data, {'decimal_neg': ['decimal']}).validate())
        self.assertTrue(Validator(self.data, {'int_val': ['decimal']}).validate())
        self.assertTrue(Validator(self.data, {'float_val': ['decimal']}).validate())

        self.assertFalse(Validator(self.data, {'str_invalid': ['decimal']}).validate())
        self.assertFalse(Validator(self.data, {'list_val': ['decimal']}).validate())

    # 6. GreaterThanRule (gt)
    def test_gt_rule(self):
        self.assertTrue(Validator(self.data, {'ten': ['gt:5']}).validate())
        self.assertTrue(Validator(self.data, {'ten_float': ['gt:9.99']}).validate())
        self.assertTrue(Validator(self.data, {'str_ten': ['gt:9']}).validate())

        self.assertFalse(Validator(self.data, {'five': ['gt:10']}).validate())
        self.assertFalse(Validator(self.data, {'ten': ['gt:10']}).validate())  # Equal, not greater
        self.assertFalse(Validator(self.data, {'str_invalid': ['gt:5']}).validate())

    # 7. GreaterThanOrEqualRule (gte)
    def test_gte_rule(self):
        self.assertTrue(Validator(self.data, {'ten': ['gte:10']}).validate())  # Equal
        self.assertTrue(Validator(self.data, {'ten': ['gte:5']}).validate())

        self.assertFalse(Validator(self.data, {'five': ['gte:10']}).validate())
        self.assertFalse(Validator(self.data, {'str_invalid': ['gte:5']}).validate())

    # 8. LessThanRule (lt)
    def test_lt_rule(self):
        self.assertTrue(Validator(self.data, {'five': ['lt:10']}).validate())
        self.assertTrue(Validator(self.data, {'negative': ['lt:0']}).validate())

        self.assertFalse(Validator(self.data, {'ten': ['lt:5']}).validate())
        self.assertFalse(Validator(self.data, {'ten': ['lt:10']}).validate())  # Equal, not less
        self.assertFalse(Validator(self.data, {'str_invalid': ['lt:5']}).validate())

    # 9. LessThanOrEqualRule (lte)
    def test_lte_rule(self):
        self.assertTrue(Validator(self.data, {'ten': ['lte:10']}).validate())  # Equal
        self.assertTrue(Validator(self.data, {'five': ['lte:10']}).validate())

        self.assertFalse(Validator(self.data, {'ten': ['lte:5']}).validate())
        self.assertFalse(Validator(self.data, {'str_invalid': ['lte:5']}).validate())

    # 10. MaxDigitsRule
    def test_max_digits_rule(self):
        self.assertTrue(Validator(self.data, {'digits_4': ['max_digits:4']}).validate())
        self.assertTrue(Validator(self.data, {'digits_4': ['max_digits:6']}).validate())
        self.assertTrue(Validator(self.data, {'decimal_str': ['max_digits:6']}).validate())  # 1234.56 -> 123456 = 6 digits

        self.assertFalse(Validator(self.data, {'digits_5': ['max_digits:4']}).validate())
        self.assertFalse(Validator(self.data, {'str_invalid': ['max_digits:5']}).validate())

    # 11. MinDigitsRule
    def test_min_digits_rule(self):
        self.assertTrue(Validator(self.data, {'digits_4': ['min_digits:4']}).validate())
        self.assertTrue(Validator(self.data, {'digits_5': ['min_digits:4']}).validate())

        self.assertFalse(Validator(self.data, {'digits_3': ['min_digits:4']}).validate())
        self.assertFalse(Validator(self.data, {'str_invalid': ['min_digits:1']}).validate())

    # 12. MultipleOfRule
    def test_multiple_of_rule(self):
        self.assertTrue(Validator(self.data, {'twelve': ['multiple_of:3']}).validate())
        self.assertTrue(Validator(self.data, {'twelve': ['multiple_of:4']}).validate())
        self.assertTrue(Validator(self.data, {'twelve': ['multiple_of:6']}).validate())
        self.assertTrue(Validator(self.data, {'int_val': ['multiple_of:2']}).validate())  # 42 is even

        # Not a multiple
        self.assertFalse(Validator(self.data, {'seven': ['multiple_of:3']}).validate())
        # Multiple of zero (should return False)
        self.assertFalse(Validator(self.data, {'twelve': ['multiple_of:0']}).validate())
        # Non-numeric value
        self.assertFalse(Validator(self.data, {'str_invalid': ['multiple_of:3']}).validate())

if __name__ == '__main__':
    unittest.main()
