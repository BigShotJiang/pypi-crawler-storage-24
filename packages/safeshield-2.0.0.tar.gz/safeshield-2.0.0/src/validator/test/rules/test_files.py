import unittest
from validator.core import Validator
from unittest.mock import MagicMock, patch
from io import BytesIO
from werkzeug.datastructures import FileStorage

class TestFileValidationRules(unittest.TestCase):
    def setUp(self):
        # Setup base data with file examples
        self.base_data = {
            'document': FileStorage(
                filename='test.pdf',
                content_type='application/pdf',
                stream=BytesIO(b'PDF content')
            ),
            'image': FileStorage(
                filename='avatar.jpg',
                content_type='image/jpeg',
                stream=BytesIO(b'\xFF\xD8\xFF\xE0\x00\x10JFIF')  # JPEG header
            ),
            'small_file': FileStorage(
                filename='small.txt',
                content_type='text/plain',
                stream=BytesIO(b'small content'),
                content_length=1024
            ),
            'large_file': FileStorage(
                filename='large.bin',
                content_type='application/octet-stream',
                stream=BytesIO(b'0' * (5 * 1024 * 1024)),  # 5MB
                content_length=5 * 1024 * 1024
            ),
            'text_file': FileStorage(
                filename='notes.txt',
                content_type='text/plain',
                stream=BytesIO(b'text content')
            ),
            'dimension_image': FileStorage(
                filename='photo.jpg',
                content_type='image/jpeg',
                stream=BytesIO(b'\xFF\xD8\xFF\xE0\x00\x10JFIF')  # Mock JPEG
            )
        }
        
        # Mock database manager
        self.db_manager = MagicMock()
        self.db_manager.is_unique.return_value = True
        self.db_manager.exists.return_value = True

    def test_file_rule(self):
        # Test valid file
        rules = {'document': ['file']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test invalid file (non-file input)
        data = {'document': 'not_a_file'}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('document', validator.errors)

        # Test invalid data URI
        data = {'document': 'data:image/png;base64,iVBORw0KGgoAAA'}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        
        # Test bytes / direct binary
        data = {'document': b'Some valid file content bytes'}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())

        # Test empty bytes (should fail)
        data = {'document': b''}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())

    def test_image_rule(self):
        # Test valid image
        rules = {'image': ['image']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test invalid image (PDF file)
        rules = {'document': ['image']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('document', validator.errors)

        # Test image with only valid extension but no MIME (fails gracefully because no content_type)
        data = {'image_ext': FileStorage(filename='test.webp', stream=BytesIO(b''))}
        validator = Validator(data, {'image_ext': ['image']})
        self.assertFalse(validator.validate())

        # Test image with content_type and stream
        data = {'image_ext': FileStorage(filename='test.webp', content_type='image/webp', stream=BytesIO(b''))}
        validator = Validator(data, {'image_ext': ['image']})
        self.assertTrue(validator.validate())

    def test_extensions_rule(self):
        # Test valid extension
        rules = {'document': ['extensions:pdf,docx']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test invalid extension
        rules = {'image': ['extensions:png,gif']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('image', validator.errors)

    def test_mime_types_rule(self):
        # Test valid MIME type
        rules = {'document': ['mime_types:application/pdf,text/plain']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test invalid MIME type
        rules = {'image': ['mime_types:image/png,image/gif']}
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('image', validator.errors)

    def test_max_rule(self):
        # Test file within size limit
        rules = {'small_file': ['max:2048']}  # 2KB limit
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test file exceeding size limit
        rules = {'large_file': ['max:1048576']}  # 1MB limit
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('large_file', validator.errors)

    def test_between_rule(self):
        # Test file within size range
        rules = {'small_file': ['between:512,2048']}  # 0.5KB-2KB
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test file outside size range
        rules = {'large_file': ['between:1024,1048576']}  # 1KB-1MB
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('large_file', validator.errors)

    @patch('PIL.Image.open')
    def test_dimensions_rule(self, mock_image):
        # Mock image dimensions to be Exactly 800x600
        mock_img = MagicMock()
        mock_img.size = (800, 600)
        mock_image.return_value = mock_img

        # Isolate the data to avoid testing other unused files
        data = {'dimension_image': self.base_data['dimension_image']}
        
        # 1. Test Exact Legacy Format (800x600)
        rules = {'dimension_image': ['dimensions:800x600']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        
        # 2. Test Invalid Exact Legacy Format (1024x768)
        rules = {'dimension_image': ['dimensions:1024x768']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('dimension_image', validator.errors)

        # 3. Test Key-Value Exact Options (width=800, height=600)
        rules = {'dimension_image': ['dimensions:width=800,height=600']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())

        # 4. Test Key-Value Minimum Options Valid (min_width=640, min_height=480)
        rules = {'dimension_image': ['dimensions:min_width=640,min_height=480']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())

        # 5. Test Key-Value Minimum Options Invalid (min_width=1000)
        rules = {'dimension_image': ['dimensions:min_width=1000']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())

        # 6. Test Key-Value Maximum Options Valid (max_width=1024, max_height=768)
        rules = {'dimension_image': ['dimensions:max_width=1024,max_height=768']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())

        # 7. Test Key-Value Maximum Options Invalid (max_height=500)
        rules = {'dimension_image': ['dimensions:max_height=500']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())

        # 8. Test Ratio formatting (4/3 -> 800/600 = 1.33 = 4/3)
        rules = {'dimension_image': ['dimensions:ratio=4/3']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        
        # 9. Test Invalid Ratio formatting (16/9)
        rules = {'dimension_image': ['dimensions:ratio=16/9']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())

        # 10. Test Logic Error: min_width > max_width (Validation should fail gracefully)
        rules = {'dimension_image': ['dimensions:min_width=1000,max_width=500']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        
        # 11. Test Logic Error: min_height > max_height
        rules = {'dimension_image': ['dimensions:min_height=800,max_height=400']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        
        # 12. Test Logic Error: Cannot specify exact width with min_width/max_width
        rules = {'dimension_image': ['dimensions:width=800,min_width=600']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        
        # 13. Test Logic Error: Cannot specify exact height with min_height/max_height
        rules = {'dimension_image': ['dimensions:height=600,max_height=800']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())

        # 14. Test combined parameters valid (min_width=600, max_width=1000, ratio=4/3)
        rules = {'dimension_image': ['dimensions:min_width=600,max_width=1000,ratio=4/3']}
        validator = Validator(data, rules)
        self.assertTrue(validator.validate())
        
        # 15. Test Non-image or broken file mock (will return False)
        mock_image.return_value = None
        validator = Validator(data, {'dimension_image': ['dimensions:800x600']})
        self.assertFalse(validator.validate())
        
    def test_size_rule(self):
        # Test exact file size match
        rules = {'small_file': ['size:1024']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test incorrect file size
        rules = {'large_file': ['size:1048576']}  # Expecting 1MB
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('large_file', validator.errors)

    def test_complex_file_rules(self):
        # Test combination of file rules
        rules = {
            'image': [
                'required',
                # 'file',
                'image',
                'extensions:jpg,jpeg',
                # 'mime_types:image/jpeg',
                'max:5242880',  # 5MB
                'dimensions:min:100x100,max:4000x4000'
            ]
        }
        
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('image', validator.errors)
        
    def test_mime_type_by_extension_rule(self):
        """Test MIME type validation by file extension"""
        # Test valid extensions
        rules = {'document': ['mimes:application/pdf']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())
        self.assertEqual(validator.errors, {})

        # Test invalid extension
        rules = {'image': ['mimes:image/png']}  # JPG not in allowed
        validator = Validator(self.base_data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('image', validator.errors)

        # Test with multiple allowed types
        rules = {'text_file': ['mimes:text/plain,application/pdf']}
        validator = Validator(self.base_data, rules)
        self.assertTrue(validator.validate())

        # Test with non-file input
        data = {'document': 'not_a_file'}
        rules = {'document': ['mimes:text/plain,application/pdf']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('document', validator.errors)

        # Test with missing file
        data = {'missing_file': None}
        rules = {'missing_file': ['mimes:text/plain,application/pdf']}
        validator = Validator(data, rules)
        self.assertFalse(validator.validate())
        self.assertIn('missing_file', validator.errors)

        # Test case sensitivity
        uppercase_data = {
            'document': FileStorage(
                filename='test.PDF',  # Uppercase extension
                content_type='application/pdf',
                stream=BytesIO(b'PDF content')
            )
        }
        rules = {'document': ['mimes:application/pdf']}
        validator = Validator(uppercase_data, rules)
        self.assertTrue(validator.validate())

if __name__ == '__main__':
    unittest.main()