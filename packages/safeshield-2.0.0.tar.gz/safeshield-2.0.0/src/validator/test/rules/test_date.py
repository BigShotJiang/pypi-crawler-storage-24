import unittest
from datetime import datetime
from validator.core.validator import Validator

class TestDateRules(unittest.TestCase):
    def setUp(self):
        self.data = {
            'valid_date1': '2023-01-01',
            'valid_date2': '01/15/2023',
            'valid_datetime': datetime(2023, 1, 1),
            'invalid_date': 'not-a-date',
            'int_date': 20230101,
            
            'start_date': '2023-05-01',
            'end_date': '2023-05-31',
            'same_start_date': '2023-05-01',
            
            'format_date': '2023/12/31',
            'format_time': '14:30:00',
            
            'valid_tz': 'Asia/Jakarta',
            'invalid_tz': 'Invalid/Timezone',
        }

    # 1. DateRule
    def test_date_rule(self):
        self.assertTrue(Validator(self.data, {'valid_date1': ['date']}).validate())
        self.assertTrue(Validator(self.data, {'valid_date2': ['date']}).validate())
        
        # Fails on invalid strings
        self.assertFalse(Validator(self.data, {'invalid_date': ['date']}).validate())
        # Fails on non-strings (integer)
        self.assertFalse(Validator(self.data, {'int_date': ['date']}).validate())

    # 2. DateEqualsRule
    def test_date_equals_rule(self):
        # Direct date string comparison
        self.assertTrue(Validator(self.data, {'valid_date1': ['date_equals:2023-01-01']}).validate())
        
        # Cross-field comparison
        self.assertTrue(Validator(self.data, {'start_date': ['date_equals:same_start_date']}).validate())
        
        # Datetime object comparison
        self.assertTrue(Validator(self.data, {'valid_datetime': ['date_equals:2023-01-01']}).validate())
        
        # Fails on unequal
        self.assertFalse(Validator(self.data, {'start_date': ['date_equals:end_date']}).validate())
        # Fails on invalid formats
        self.assertFalse(Validator(self.data, {'invalid_date': ['date_equals:2023-01-01']}).validate())

    # 3. AfterRule
    def test_after_rule(self):
        self.assertTrue(Validator(self.data, {'end_date': ['after:start_date']}).validate())
        self.assertTrue(Validator(self.data, {'end_date': ['after:2023-05-15']}).validate())
        
        # Fails if equal or before
        self.assertFalse(Validator(self.data, {'start_date': ['after:end_date']}).validate())
        self.assertFalse(Validator(self.data, {'start_date': ['after:same_start_date']}).validate())
        
        # Fails on invalid input
        self.assertFalse(Validator(self.data, {'invalid_date': ['after:2023-05-01']}).validate())

    # 4. AfterOrEqualRule
    def test_after_or_equal_rule(self):
        self.assertTrue(Validator(self.data, {'end_date': ['after_or_equal:start_date']}).validate())
        self.assertTrue(Validator(self.data, {'start_date': ['after_or_equal:same_start_date']}).validate())
        
        self.assertFalse(Validator(self.data, {'start_date': ['after_or_equal:end_date']}).validate())

    # 5. BeforeRule
    def test_before_rule(self):
        self.assertTrue(Validator(self.data, {'start_date': ['before:end_date']}).validate())
        self.assertTrue(Validator(self.data, {'start_date': ['before:2023-05-15']}).validate())
        
        # Fails if equal or after
        self.assertFalse(Validator(self.data, {'end_date': ['before:start_date']}).validate())
        self.assertFalse(Validator(self.data, {'start_date': ['before:same_start_date']}).validate())

    # 6. BeforeOrEqualRule
    def test_before_or_equal_rule(self):
        self.assertTrue(Validator(self.data, {'start_date': ['before_or_equal:end_date']}).validate())
        self.assertTrue(Validator(self.data, {'start_date': ['before_or_equal:same_start_date']}).validate())
        
        self.assertFalse(Validator(self.data, {'end_date': ['before_or_equal:start_date']}).validate())

    # 7. DateFormatRule
    def test_date_format_rule(self):
        self.assertTrue(Validator(self.data, {'format_date': ['date_format:%Y/%m/%d']}).validate())
        self.assertTrue(Validator(self.data, {'format_time': ['date_format:%H:%M:%S']}).validate())
        
        # Fails on incorrect format
        self.assertFalse(Validator(self.data, {'format_date': ['date_format:%Y-%m-%d']}).validate())
        self.assertFalse(Validator(self.data, {'valid_date1': ['date_format:%d-%m-%Y']}).validate())

    # 8. TimezoneRule
    def test_timezone_rule(self):
        self.assertTrue(Validator(self.data, {'valid_tz': ['timezone']}).validate())
        
        self.assertFalse(Validator(self.data, {'invalid_tz': ['timezone']}).validate())
        self.assertFalse(Validator(self.data, {'valid_date1': ['timezone']}).validate())

if __name__ == '__main__':
    unittest.main()