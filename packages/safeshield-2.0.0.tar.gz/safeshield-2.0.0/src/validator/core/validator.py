from typing import Optional, Dict, Any, List, Tuple, Union
from validator.exceptions import ValidationException, RuleNotFoundException
from validator.factory import RuleFactory
# from validator.database import DatabaseManager, DatabaseAutoDetector
from validator.rules import Rule
from validator.services.rule_conflict import RuleConflictChecker
from validator.services.rule_error_handler import RuleErrorHandler
from validator.services.rule_preparer import RulePreparer
import warnings
from collections.abc import Mapping

class Validator:
    """Main validation class with proper abstractions"""
    PRIORITY_RULES = {
        'bail',
        'when',
        'sometimes', 
        'dynamic', 
        'nullable',
        'exclude', 
        'exclude_unless', 
        'exclude_if', 
        'exclude_with', 
        'exclude_without', 
        'required', 
        'required_if', 
        'required_unless',
        'required_with', 
        'required_without'
    }

    def __init__(
        self,
        data: Optional[Dict[str, Any]] = None,
        rules: Optional[Dict[str, Union[
            str, 
            List[Union[
                str, 
                Rule, 
                Tuple[str, Union[
                    str, 
                    Union[
                        Tuple[str], 
                        List[str]
                    ], 
                    Union[
                        Tuple[str], 
                        List[str]
                    ]
                ]]
            ]],
            Tuple[Union[
                str, 
                Rule, 
                Tuple[str, Union[
                    str, 
                    Union[
                        Tuple[str], 
                        List[str]
                    ], 
                    Union[
                        Tuple[str], 
                        List[str]
                    ]
                ]]
            ]]
        ]]] = None,
        messages: Optional[Dict[str, str]] = None,
        custom_attributes: Optional[Dict[str, str]] = None,
        db_config: Optional[Dict[str, Any]] = None,
        # rule_preparer: Optional[RulePreparer] = None,
        # error_handler: Optional[RuleErrorHandler] = None
    ):
        self.data = data or {}
        self._raw_rules = rules or {}
        self.prepared_rules = None
        self._stop_on_first_failure = False
        self._field_to_exclude = []
        
        
        # Initialize dependencies
        self.rule_preparer = RulePreparer(RuleFactory())
        self.error_handler = RuleErrorHandler(messages, custom_attributes)
        self.custom_attributes = custom_attributes or {}
    
        self.prepared_rules = self.rule_preparer.prepare(self._raw_rules)
        
        # Database configuration
        # self.db_config = db_config or DatabaseAutoDetector.detect()
        # if not self.db_config:
        #     warnings.warn(
        #         "No database config detected. exists/unique validations will be skipped!",
        #         RuntimeWarning
        #     )
        # self.db_manager = DatabaseManager(self.db_config) if self.db_config else None

    def validate(self) -> bool:
        """Validate the data against the rules"""
        self.error_handler.errors.clear()
        self._nullable_fields = set()  # track fields that are nullable + None
        validated = self._validate_rules(self.prepared_rules, priority_only=True)
        
        # First pass: priority rules
        if self.error_handler.has_errors and self._stop_on_first_failure:
            return False
        
        # Second pass: remaining rules
        self._validate_rules(self.prepared_rules, priority_only=False)
        
        if self.error_handler.has_errors:
            return False
        
        return True

    def _validate_rules(self, prepared_rules: Dict[str, List[Rule]], priority_only: bool):
        validated = []
        nullable_fields = getattr(self, '_nullable_fields', set())
        
        for field_pattern, rules in prepared_rules.items():
            concrete_paths = self._resolve_wildcard_paths(field_pattern) if '*' in field_pattern else [field_pattern]
            
            # Bug fix: For wildcard patterns, also resolve paths where nested keys are absent
            if '*' in field_pattern:
                concrete_paths = self._resolve_wildcard_paths_including_absent(field_pattern, concrete_paths)
            
            for actual_path in concrete_paths:
                self._current_actual_path = actual_path
                raw_values = self._get_nested_value(actual_path)
                field_exists = self._field_exists_in_data(actual_path)
                
                # Bug fix: nullable short-circuit — if field is in nullable_fields, skip non-priority rules
                if not priority_only and actual_path in nullable_fields:
                    continue
                
                # Handle empty array case for wildcard
                is_wildcard = '*' in field_pattern
                is_empty_array = isinstance(raw_values, list) and len(raw_values) == 0
                
                # Special case: wildcard path with empty array
                if is_wildcard and is_empty_array:
                    values_to_validate = []
                elif not is_wildcard and not is_empty_array:
                    values_to_validate = [raw_values]
                else:
                    values_to_validate = [None] if not field_exists else (
                        [raw_values] if not isinstance(raw_values, list) else raw_values
                    )
                    
                for rule in rules:
                    if priority_only == (rule.rule_name in self.PRIORITY_RULES):
                        rule.set_field_exists(field_exists)
                        
                        # Bug fix: register nullable fields when value is None
                        if priority_only and rule.rule_name == 'nullable':
                            if raw_values is None:
                                nullable_fields.add(actual_path)
                                continue  # nullable itself always passes
                        
                        # Skip validation for empty array with wildcard unless it's a required rule
                        if is_wildcard and is_empty_array and rule.rule_name != 'required':
                            continue
                            
                        for value in values_to_validate:
                            if field_pattern not in self._field_to_exclude:
                                validated.append(self._apply_rule(field_pattern, value, rule))
                                
                        if self._stop_on_first_failure and self.error_handler.has_errors:
                            if actual_path in self.error_handler.errors:
                                break
                
        self._nullable_fields = nullable_fields
        return all(valid for valid in validated)
    
    def _resolve_wildcard_paths(self, pattern: str) -> List[str]:
        parts = pattern.split('.')
        
        def _resolve(data: Any, current_path: str, remaining_parts: List[str]) -> List[str]:
            if not remaining_parts:
                return [current_path] if current_path else []
            
            part = remaining_parts[0]
            next_parts = remaining_parts[1:]
            
            if part == '*':
                results = []
                # Special case: wildcard at the end of path
                if not next_parts:
                    if isinstance(data, (list, tuple)):
                        for i in range(len(data)):
                            new_path = f"{current_path}.{i}" if current_path else str(i)
                            results.append(new_path)
                    elif isinstance(data, dict):
                        for key in data.keys():
                            new_path = f"{current_path}.{key}" if current_path else key
                            results.append(new_path)
                    else:
                        # If not a collection, return current path
                        if current_path:
                            results.append(current_path)
                    return results
                
                # Wildcard in the middle of path (as before)
                if isinstance(data, (list, tuple)):
                    for i, item in enumerate(data):
                        new_path = f"{current_path}.{i}" if current_path else str(i)
                        results.extend(_resolve(item, new_path, next_parts))
                elif isinstance(data, dict):
                    for key, value in data.items():
                        new_path = f"{current_path}.{key}" if current_path else key
                        results.extend(_resolve(value, new_path, next_parts))
                return results
            
            # Handle regular path (as before)
            next_data = None
            if isinstance(data, dict) and part in data:
                next_data = data[part]
            elif isinstance(data, (list, tuple)) and part.isdigit():
                index = int(part)
                if 0 <= index < len(data):
                    next_data = data[index]
            
            if next_data is not None:
                new_path = f"{current_path}.{part}" if current_path else part
                return _resolve(next_data, new_path, next_parts)
            
            return []
    
        return _resolve(self.data, '', parts)
    
    def _resolve_wildcard_paths_including_absent(self, pattern: str, existing_paths: List[str]) -> List[str]:
        """
        Extends wildcard path resolution to also include paths where the final key is
        absent from the item. This ensures 'required' fires even for missing nested keys.
        For example: 'users.*.age' with data [{'name': 'Alice'}, {'name': 'Bob', 'age': 25}]
        should yield ['users.0.age', 'users.1.age'] even though users.0.age doesn't exist.
        """
        parts = pattern.split('.')
        
        # Find the position of wildcards and resolve the parent collection
        # to enumerate all items, then append the remaining non-wildcard suffix
        def _get_parent_items(data: Any, remaining_parts: List[str]) -> List[tuple]:
            """Returns list of (parent_data, base_path, remaining_suffix) tuples"""
            if not remaining_parts:
                return []
            part = remaining_parts[0]
            next_parts = remaining_parts[1:]
            
            if part == '*':
                results = []
                if isinstance(data, (list, tuple)):
                    for i, item in enumerate(data):
                        suffix = '.'.join(next_parts)
                        results.append((item, str(i), next_parts))
                elif isinstance(data, dict):
                    for key, val in data.items():
                        results.append((val, key, next_parts))
                return results
            else:
                # Navigate into the part
                next_data = None
                if isinstance(data, dict) and part in data:
                    next_data = data[part]
                elif isinstance(data, (list, tuple)) and part.isdigit():
                    idx = int(part)
                    if 0 <= idx < len(data):
                        next_data = data[idx]
                if next_data is not None:
                    sub = _get_parent_items(next_data, next_parts)
                    return [(item, f"{part}.{base}", suf) for item, base, suf in sub]
                return []
        
        # Find where the last '*' is in the pattern, then generate all combinations
        star_idx = None
        for i, p in enumerate(parts):
            if p == '*':
                star_idx = i
        
        if star_idx is None:
            return existing_paths
        
        # Get the prefix (before and including the wildcard expansion parent)
        prefix_parts = parts[:star_idx]  # e.g. ['users']
        suffix_parts = parts[star_idx + 1:]  # e.g. ['age']
        
        # Navigate to the parent collection
        parent_data = self.data
        prefix_path = ''
        for p in prefix_parts:
            if isinstance(parent_data, dict) and p in parent_data:
                parent_data = parent_data[p]
                prefix_path = f"{prefix_path}.{p}" if prefix_path else p
            else:
                return existing_paths  # Can't resolve prefix, fall back
        
        new_paths = set(existing_paths)
        
        # For each item in the parent collection, generate the full path
        if isinstance(parent_data, (list, tuple)):
            for i in range(len(parent_data)):
                item_base = f"{prefix_path}.{i}" if prefix_path else str(i)
                if suffix_parts:
                    full_path = f"{item_base}.{'.'.join(suffix_parts)}"
                else:
                    full_path = item_base
                new_paths.add(full_path)
        
        return list(new_paths)

    
    def _field_exists_in_data(self, field_path: str) -> bool:
        parts = field_path.split('.')
        
        def _check(data: Any, remaining_parts: List[str]) -> bool:
            if not remaining_parts:
                return True
                
            part = remaining_parts[0]
            next_parts = remaining_parts[1:]
            
            if part == '*':
                if isinstance(data, (list, tuple)):
                    return any(_check(item, next_parts) for item in data)
                elif isinstance(data, dict):
                    return any(_check(value, next_parts) for value in data.values())
                return False
            
            if isinstance(data, dict) and part in data:
                return _check(data[part], next_parts)
            elif isinstance(data, (list, tuple)) and part.isdigit():
                index = int(part)
                return 0 <= index < len(data) and _check(data[index], next_parts)
            
            return False
        
        return _check(self.data, parts)
    
    def _apply_rule(self, field: str, value: Any, rule: Rule) -> bool:
        rule.set_validator(self)
            
        display_field = getattr(self, '_current_actual_path', field)
        rule._require_parameter_count(getattr(rule, '_count_parameter', 0), getattr(rule, 'params', []), rule)
            
        if not rule.validate(field, value, getattr(rule, 'params', [])):
            msg = rule.message(display_field, getattr(rule, 'params', []))
            self.error_handler.add_error(display_field, rule, getattr(rule, 'params', []), msg, value)
            
            return False
        else:
            return True

    def _get_nested_value(self, path: str) -> Any:
        parts = path.split('.')
        
        def _get(data: Any, remaining_parts: List[str]) -> Any:
            if not remaining_parts:
                return data
                
            part = remaining_parts[0]
            next_parts = remaining_parts[1:]
            
            if part == '*':
                if isinstance(data, (list, tuple)):
                    return [_get(item, next_parts) for item in data]
                elif isinstance(data, dict):
                    return [_get(value, next_parts) for value in data.values()]
                return None
            
            if isinstance(data, dict) and part in data:
                return _get(data[part], next_parts)
            elif isinstance(data, (list, tuple)) and part.isdigit():
                index = int(part)
                if 0 <= index < len(data):
                    return _get(data[index], next_parts)
            
            return None
        
        result = _get(self.data, parts)
        
        # Flatten only one level for wildcard results
        if isinstance(result, list):
            flat_result = []
            for item in result:
                if isinstance(item, list):
                    flat_result.extend(item)
                elif item is not None:
                    flat_result.append(item)
            return flat_result if flat_result else None
        
        return result
    
    def add_rule(self, field: str, rules: Union[str, List[Union[str, Rule]], Rule]):
        """Add new rules to a field"""
        new_rules = self.rule_preparer._convert_to_rules(rules)
        existing_rules = self.rule_preparer._convert_to_rules(self._raw_rules.get(field, []))
        combined_rules = existing_rules + new_rules
        
        RuleConflictChecker.check_conflicts(combined_rules)
        self._raw_rules[field] = self.rule_preparer._deduplicate_rules(field, combined_rules)

    def set_stop_on_first_failure(self, value: bool) -> None:
        """Set whether to stop validation after first failure"""
        self._stop_on_first_failure = value

    @property
    def errors(self) -> Dict[str, List[str]]:
        """Get current validation errors"""
        return self.error_handler.errors
    
    @property
    def has_errors(self) -> bool:
        """Check if there are any validation errors"""
        return self.error_handler.has_errors