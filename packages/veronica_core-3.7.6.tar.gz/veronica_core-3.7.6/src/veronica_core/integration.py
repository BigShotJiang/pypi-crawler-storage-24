"""VERONICA Integration Helper - Bridge between state machine and existing code.

This module provides a drop-in replacement for global variables
(veronica_fail_counts, veronica_cooldowns) with state machine persistence.
"""
# nogil-audited: 2026-03-08
# Findings:
#   - VeronicaIntegration._atexit_registered (class-level bool) and
#     _live_instances (WeakSet) were read/written without a lock, creating
#     a TOCTOU race under nogil: two threads could both observe
#     _atexit_registered=False and register atexit twice.
#     Fixed: added _class_lock (threading.Lock) guarding both fields.
#   - _op_lock already serialises record_fail() and _maybe_auto_save().
#   - get_veronica_integration() uses double-checked locking with
#     _singleton_lock -- correct under both GIL and nogil.
#   - No other shared mutable state found without locking.

from __future__ import annotations
from typing import Dict, Optional
import logging
import threading
import time
import atexit
import weakref

from veronica_core.state import VeronicaStateMachine, VeronicaState
from veronica_core.exit import VeronicaExit
from veronica_core.backends import PersistenceBackend
from veronica_core.guards import VeronicaGuard, PermissiveGuard
from veronica_core.clients import LLMClient, NullClient
from veronica_core.shield.budget_window import BudgetWindowHook
from veronica_core.shield.config import ShieldConfig
from veronica_core.shield.input_compression import InputCompressionHook
from veronica_core.shield.pipeline import ShieldPipeline
from veronica_core.shield.safe_mode import SafeModeHook
from veronica_core.shield.token_budget import TokenBudgetHook

logger = logging.getLogger(__name__)


class VeronicaIntegration:
    """Integration helper for VERONICA state machine.

    Provides backward-compatible interface to replace global variables
    while adding persistence and graceful exit.
    """

    _atexit_registered: bool = False
    _live_instances: weakref.WeakSet["VeronicaIntegration"] = weakref.WeakSet()
    # nogil: guards _atexit_registered and _live_instances against concurrent
    # __init__ calls from multiple threads.
    _class_lock: threading.Lock = threading.Lock()

    def __init__(
        self,
        cooldown_fails: int = 3,
        cooldown_seconds: int = 600,
        auto_save_interval: int = 100,  # Save every N operations
        backend: Optional[PersistenceBackend] = None,
        guard: Optional[VeronicaGuard] = None,
        client: Optional[LLMClient] = None,
        shield: Optional[ShieldConfig] = None,
    ):
        """Initialize integration layer.

        Args:
            cooldown_fails: Number of consecutive fails to trigger cooldown
            cooldown_seconds: Cooldown duration in seconds
            auto_save_interval: Save state every N operations (0 = manual only)
            backend: Persistence backend (default: JSONBackend at data/state/veronica_state.json)
            guard: Validation guard (default: PermissiveGuard)
            client: LLM client (optional, default: NullClient - no LLM features)
            shield: Shield configuration (optional, default: None - no shield)
        """
        # Set up backend
        if backend is None:
            from veronica_core.backends import JSONBackend

            self.backend: Optional[PersistenceBackend] = JSONBackend(
                "data/state/veronica_state.json"
            )
        else:
            self.backend = backend

        # Set up guard
        self.guard = guard or PermissiveGuard()

        # Set up LLM client (optional)
        self.client: LLMClient = client or NullClient()

        # Shield configuration (opt-in)
        self.shield: Optional[ShieldConfig] = shield

        # Shield pipeline (created when config present)
        if shield is not None:
            safe_hook = SafeModeHook(enabled=True) if shield.safe_mode.enabled else None
            # safe_mode takes priority: when enabled it HALTs everything,
            # so there is no point also running BudgetWindowHook.
            if safe_hook is not None:
                pre_dispatch_hook = safe_hook
            elif shield.token_budget.enabled:
                pre_dispatch_hook = TokenBudgetHook(
                    max_output_tokens=shield.token_budget.max_output_tokens,
                    max_total_tokens=shield.token_budget.max_total_tokens,
                    degrade_threshold=shield.token_budget.degrade_threshold,
                )
            elif shield.budget_window.enabled:
                pre_dispatch_hook = BudgetWindowHook(
                    max_calls=shield.budget_window.max_calls,
                    window_seconds=shield.budget_window.window_seconds,
                    degrade_threshold=shield.budget_window.degrade_threshold,
                )
            else:
                pre_dispatch_hook = None
            self._shield_pipeline: Optional[ShieldPipeline] = ShieldPipeline(
                pre_dispatch=pre_dispatch_hook,
                retry=safe_hook,
            )
            # InputCompressionHook is NOT a pre-dispatch hook.
            # It requires the actual prompt text, so callers invoke
            # check_input() directly.  We store the instance here for
            # convenient access via the integration object.
            if shield.input_compression.enabled:
                self._input_compression_hook: Optional[InputCompressionHook] = (
                    InputCompressionHook(
                        compression_threshold_tokens=shield.input_compression.compression_threshold_tokens,
                        halt_threshold_tokens=shield.input_compression.halt_threshold_tokens,
                        fallback_to_original=shield.input_compression.fallback_to_original,
                    )
                )
            else:
                self._input_compression_hook = None
        else:
            self._shield_pipeline = None
            self._input_compression_hook = None

        # Load state
        state_data = self.backend.load()

        loaded_from_disk = False
        if state_data:
            try:
                self.state = VeronicaStateMachine.from_dict(state_data)
                loaded_from_disk = True
            except Exception as exc:
                logger.warning(
                    "[VERONICA_INTEGRATION] Failed to deserialize state, starting fresh"
                )
                logger.debug("[VERONICA_INTEGRATION] Deserialize error: %s", exc)
                self.state = None
        else:
            self.state = None

        if self.state is None:
            # Fresh start
            logger.info("[VERONICA_INTEGRATION] Creating fresh state")
            self.state = VeronicaStateMachine(
                cooldown_fails=cooldown_fails,
                cooldown_seconds=cooldown_seconds,
            )
        else:
            logger.info(
                f"[VERONICA_INTEGRATION] Loaded existing state: "
                f"{len(self.state.cooldowns)} active cooldowns, "
                f"{len(self.state.fail_counts)} fail counters"
            )

        # Transition to SCREENING (only if fresh start or not in critical state)
        if not loaded_from_disk:
            # Fresh start - always transition to SCREENING
            self.state.transition(VeronicaState.SCREENING, "Bot startup")
        else:
            # Loaded existing state - preserve critical states
            if self.state.current_state not in (
                VeronicaState.SAFE_MODE,
                VeronicaState.ERROR,
            ):
                self.state.transition(VeronicaState.SCREENING, "Bot startup resumed")
            else:
                logger.warning(
                    f"[VERONICA_INTEGRATION] Preserving critical state: {self.state.current_state.value}"
                )

        # Register exit handler (pass PersistenceBackend if available, else None for default)
        self.exit_handler = VeronicaExit(self.state, self.backend)

        # Track all instances for atexit save.
        # nogil: guard both _live_instances and _atexit_registered under
        # _class_lock to prevent two threads from both seeing
        # _atexit_registered=False and registering atexit twice.
        with VeronicaIntegration._class_lock:
            VeronicaIntegration._live_instances.add(self)
            if not VeronicaIntegration._atexit_registered:
                atexit.register(VeronicaIntegration._save_all_instances)
                VeronicaIntegration._atexit_registered = True

        # Auto-save tracking
        self.auto_save_interval = auto_save_interval
        self.operation_count = 0
        self._op_lock = threading.Lock()

        logger.info(
            f"[VERONICA_INTEGRATION] Initialized: "
            f"cooldown_fails={self.state.cooldown_fails}, "
            f"cooldown_seconds={self.state.cooldown_seconds}, "
            f"auto_save_interval={auto_save_interval}"
        )

    def is_in_cooldown(self, pair: str) -> bool:
        """Check if pair is in cooldown.

        Args:
            pair: Trading pair (e.g., 'btc_jpy')

        Returns:
            True if pair is in cooldown
        """
        return self.state.is_in_cooldown(pair)

    def record_fail(self, pair: str, context: Optional[Dict] = None) -> bool:
        """Record sanity_fail for pair.

        Args:
            pair: Trading pair (or entity identifier)
            context: Optional context for guard validation

        Returns:
            True if cooldown was activated

        Thread-safety: state mutation (record_fail + guard cooldown) is executed
        inside a single _op_lock acquisition to prevent TOCTOU races where two
        concurrent callers could both observe fail_count < threshold, both call
        set_cooldown, and potentially double-activate or skip activation.
        _maybe_auto_save() is called outside the lock because it has its own
        internal lock and does not need to be atomic with the state mutation.
        """
        with self._op_lock:
            activated = self.state.record_fail(pair)

            # Check guard for early cooldown activation.
            # Use `is not None` instead of truthiness: an empty dict {} is a
            # valid context payload and must not skip the guard check.
            if self.guard and context is not None:
                if self.guard.should_cooldown(pair, context):
                    logger.info(
                        f"[VERONICA_INTEGRATION] Guard triggered cooldown for {pair}"
                    )
                    self.state.set_cooldown(
                        pair, time.time() + self.state.cooldown_seconds
                    )
                    self.guard.on_cooldown_activated(pair, context)
                    activated = True

        # _maybe_auto_save has its own lock; call outside _op_lock to avoid
        # potential deadlock if save() ever acquires _op_lock in the future.
        self._maybe_auto_save()
        return activated

    def record_pass(self, pair: str) -> None:
        """Record sanity_pass for pair (resets fail counter).

        Args:
            pair: Trading pair
        """
        self.state.record_pass(pair)
        self._maybe_auto_save()

    def cleanup_expired(self) -> None:
        """Cleanup expired cooldowns (call periodically)."""
        expired = self.state.cleanup_expired()
        if expired:
            self._maybe_auto_save()

    def get_stats(self) -> Dict:
        """Get current state statistics."""
        return self.state.get_stats()

    def get_fail_count(self, pair: str) -> int:
        """Get current fail count for pair (for logging/debugging)."""
        # Access fail_counts through the state machine's lock to avoid a
        # read/write race with concurrent record_fail/record_pass mutations.
        with self.state._lock:
            return self.state.fail_counts.get(pair, 0)

    def get_cooldown_remaining(self, pair: str) -> Optional[float]:
        """Get remaining cooldown seconds for pair.

        Returns:
            Remaining seconds (>= 0.0), or None if not in cooldown.
            Uses is_in_cooldown() which handles expiry cleanup, so an expired
            cooldown correctly returns None rather than 0.0.
        """
        if not self.state.is_in_cooldown(pair):
            return None
        with self.state._lock:
            expiry = self.state.cooldowns.get(pair)
            if expiry is None:
                return None
            return max(0.0, expiry - time.time())

    @classmethod
    def _save_all_instances(cls) -> None:
        """Atexit handler: save all live instances with backends."""
        # nogil: snapshot _live_instances under _class_lock to avoid iterating
        # a WeakSet that another thread may be modifying concurrently.
        with cls._class_lock:
            instances = list(cls._live_instances)
        for instance in instances:
            try:
                instance.save()
            except Exception:
                logger.debug("atexit save failed for %r", instance, exc_info=True)

    def save(self) -> bool:
        """Manually save state.

        Returns:
            True on success
        """
        state_data = self.state.to_dict()

        # Validate via guard
        if self.guard and not self.guard.validate_state(state_data):
            logger.warning(
                "[VERONICA_INTEGRATION] State validation failed, aborting save"
            )
            return False

        return self.backend.save(state_data)

    def _maybe_auto_save(self) -> None:
        """Auto-save if interval reached."""
        if self.auto_save_interval <= 0:
            return  # Auto-save disabled

        with self._op_lock:
            self.operation_count += 1
            should_save = self.operation_count >= self.auto_save_interval
            if should_save:
                self.operation_count = 0

        if should_save:
            logger.debug("[VERONICA_INTEGRATION] Auto-save triggered")
            self.save()  # Use save() method (includes guard validation)


# Global singleton instance (initialized in run_multi_pair_trading.py)
_veronica_integration: Optional[VeronicaIntegration] = None
_singleton_lock = threading.Lock()


def get_veronica_integration(
    cooldown_fails: int = 3,
    cooldown_seconds: int = 600,
    auto_save_interval: int = 100,
) -> VeronicaIntegration:
    """Get or create global VeronicaIntegration instance.

    Thread-safe: double-checked locking prevents duplicate initialization.

    Args:
        cooldown_fails: Number of consecutive fails to trigger cooldown
        cooldown_seconds: Cooldown duration in seconds
        auto_save_interval: Save state every N operations

    Returns:
        Global VeronicaIntegration instance
    """
    global _veronica_integration
    if _veronica_integration is None:
        with _singleton_lock:
            if _veronica_integration is None:
                _veronica_integration = VeronicaIntegration(
                    cooldown_fails=cooldown_fails,
                    cooldown_seconds=cooldown_seconds,
                    auto_save_interval=auto_save_interval,
                )
    else:
        # Singleton already exists -- check for parameter drift and warn the caller
        # so they know their config was silently ignored.
        existing = _veronica_integration
        existing_cf = existing.state.cooldown_fails
        existing_cs = existing.state.cooldown_seconds
        existing_asi = existing.auto_save_interval
        if (
            cooldown_fails != existing_cf
            or cooldown_seconds != existing_cs
            or auto_save_interval != existing_asi
        ):
            logger.warning(
                "[VERONICA_INTEGRATION] get_veronica_integration() called with different "
                "parameters than the existing singleton -- ignoring new parameters. "
                "Existing: cooldown_fails=%d, cooldown_seconds=%d, auto_save_interval=%d. "
                "Requested: cooldown_fails=%d, cooldown_seconds=%d, auto_save_interval=%d.",
                existing_cf,
                existing_cs,
                existing_asi,
                cooldown_fails,
                cooldown_seconds,
                auto_save_interval,
            )
    return _veronica_integration
