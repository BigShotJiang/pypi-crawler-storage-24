import json
from pathlib import Path
from typing import Any, Dict, List, Optional

import requests

from worldjen._config import _config


def _headers() -> Dict[str, str]:
    api_key = _config.api_key
    if not api_key:
        raise RuntimeError(
            "worldjen.config(api_key=...) or WORLDJEN_API_KEY must be set"
        )
    return {
        "X-API-Key": api_key,
        "Content-Type": "application/json",
    }


def _raise_for_response(response: requests.Response, context: str) -> None:
    if not response.ok:
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text
        raise RuntimeError(f"{context}: {detail}")


def create_run(
    name: str,
    dimensions: List[str],
    run_instructions: Optional[Dict[str, Any]] = None,
    model_id: Optional[str] = None,
) -> str:
    url = f"{_config.api_url}/api/v1/runs"
    payload: Dict[str, Any] = {
        "name": name,
        "dimensions": dimensions,
    }
    if run_instructions is not None:
        payload["run_instructions"] = _json_sanitize(run_instructions)
    if model_id is not None:
        payload["model_id"] = model_id
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Create run failed")
    data = response.json()
    run_id = data.get("run_id") or data.get("id") or data.get("_id")
    if not run_id:
        raise RuntimeError("Create run: response missing run id")
    return str(run_id)


def update_run_status(
    run_id: str,
    status: str,
    error_message: Optional[str] = None,
) -> None:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    payload: Dict[str, Any] = {"status": status}
    if error_message is not None:
        payload["errorMessage"] = error_message
    response = requests.patch(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Update run status failed")


def get_run(run_id: str) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runs/{run_id}"
    response = requests.get(url, headers=_headers(), timeout=_config.timeout)
    _raise_for_response(response, "Get run failed")
    return response.json()


def append_run_logs(run_id: str, logs: str) -> None:
    url = f"{_config.api_url}/api/v1/runner/runs/{run_id}/logs"
    response = requests.post(
        url, json={"logs": logs}, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Append run logs failed")


def get_upload_url(run_id: str, file_name: str, content_type: str = "video/mp4") -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/runs/videos/upload-url"
    payload: Dict[str, Any] = {"runId": run_id, "fileName": file_name, "contentType": content_type}
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Get upload URL failed")
    return response.json()


def upload_to_presigned(
    upload_url: str,
    file_path: Any,
    content_type: str = "video/mp4",
) -> None:
    path = Path(file_path) if not isinstance(file_path, Path) else file_path
    with open(path, "rb") as f:
        body = f.read()
    response = requests.put(
        upload_url,
        data=body,
        headers={"Content-Type": content_type},
        timeout=_config.timeout,
    )
    if not response.ok:
        raise RuntimeError(f"Upload to presigned URL failed: {response.status_code} {response.text}")


def confirm_upload(
    run_id: str,
    video_id: str,
    file_name: str,
    s3_key: str,
    prompt: Optional[str] = None,
    dimension_ids: Optional[List[str]] = None,
    source: str = "sdk",
) -> Dict[str, Any]:
    url = f"{_config.api_url}/api/v1/runner/runs/videos/confirm-upload"
    payload: Dict[str, Any] = {
        "runId": run_id,
        "videoId": video_id,
        "fileName": file_name,
        "s3Key": s3_key,
        "source": source,
    }
    if prompt is not None:
        payload["prompt"] = prompt
    if dimension_ids is not None:
        payload["dimensionIds"] = dimension_ids
    response = requests.post(
        url, json=payload, headers=_headers(), timeout=_config.timeout
    )
    _raise_for_response(response, "Confirm upload failed")
    return response.json()


def _json_sanitize(obj: Any) -> Any:
    """Return a JSON-serializable copy of obj; non-serializable values are dropped."""
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, dict):
        out: Dict[str, Any] = {}
        for k, v in obj.items():
            if not isinstance(k, str):
                continue
            try:
                out[k] = _json_sanitize(v)
            except (TypeError, ValueError):
                continue
        return out
    if isinstance(obj, (list, tuple)):
        out_list: List[Any] = []
        for v in obj:
            try:
                out_list.append(_json_sanitize(v))
            except (TypeError, ValueError):
                continue
        return out_list
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        raise TypeError(f"{type(obj).__name__} is not JSON serializable")

