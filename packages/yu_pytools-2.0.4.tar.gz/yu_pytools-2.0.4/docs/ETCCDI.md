# ETCCDI 操作文档

本文档介绍 `yu-pytools` 中 `ETCCDI` 模块的输入要求、主要函数、典型调用方式与常见问题。

## 1. 模块说明

`ETCCDI` 用于计算极端降水指数，包含三类指标：

1. 基础降水指数（如 `PRCPTOT`、`RX1DAY`、`CDD`）
2. 固定阈值指数（如 `R10_p`、`R20_d`、`R50_i`）
3. 百分位阈值指数（如 `R95_p`、`R99_d`、`R90_i`）

## 2. 安装

```bash
pip install yu-pytools
```

## 3. 输入数据要求

输入必须是 `xarray.DataArray`，并满足：

1. 包含 `time` 维度
2. 变量名属于以下之一：`pr`、`pre`、`precipitation`、`rain`、`prec`、`tp`
3. 时间序列应为逐日数据（函数内部会尝试自动转换时间格式）
4. 数据单位建议为 `mm/day`

常见维度形状示例：`(time, lat, lon)`。

## 4. 快速开始

```python
import xarray as xr
from yu_pytools.ETCCDI import PRCPTOT, R95_p

# 读取逐日降水数据
pr = xr.open_dataset("pr_daily.nc")["pr"]

# 计算年总降水量
prcptot = PRCPTOT(pr)

# 计算 R95p，总量指标，使用默认基准期 (1961, 1990)
r95p = R95_p(pr)
```

## 5. 百分位指标与基准期参数

百分位指标支持手动设置基准期参数：`baseline_years=(start_year, end_year)`。

```python
from yu_pytools.ETCCDI import R95_p, R99_d, R90_i

# 使用 1981-2010 作为基准期
r95p_8110 = R95_p(pr, baseline_years=(1981, 2010))
r99d_8110 = R99_d(pr, baseline_years=(1981, 2010))
r90i_8110 = R90_i(pr, baseline_years=(1981, 2010))
```

说明：

1. `baseline_years` 必须是长度为 2 的元组或列表，例如 `(1961, 1990)`
2. 必须满足 `start_year <= end_year`
3. 如果你传入 `baseline_pr`，仍会按 `baseline_years` 在 `baseline_pr` 内筛选

## 6. 主要函数清单

### 6.1 基础降水指数

1. `PRCPTOT(pr)`：逐年年总降水量
2. `R1mm_d(pr)`：逐年湿日数（>= 1mm）
3. `SDII(pr)`：逐年简单降水强度
4. `RX1DAY(pr)`：逐年最大日降水量
5. `RX5DAY(pr)`：逐年最大 5 日累计降水量
6. `CDD(pr)`：逐年最大连续干日数（< 1mm）
7. `CWD(pr)`：逐年最大连续湿日数（>= 1mm）

### 6.2 固定阈值指数

1. `R10_p(pr)`、`R20_p(pr)`、`R25_p(pr)`、`R50_p(pr)`：逐年阈值降水总量
2. `R10_d(pr)`、`R20_d(pr)`、`R25_d(pr)`、`R50_d(pr)`：逐年阈值降水日数
3. `R10_i(pr)`、`R20_i(pr)`、`R25_i(pr)`、`R50_i(pr)`：逐年阈值降水强度

### 6.3 百分位阈值指数

1. `R95_p(pr, baseline_pr=None, baseline_years=(1961, 1990))`
2. `R95_d(pr, baseline_pr=None, baseline_years=(1961, 1990))`
3. `R95_i(pr, baseline_pr=None, baseline_years=(1961, 1990))`
4. `R99_p(pr, baseline_pr=None, baseline_years=(1961, 1990))`
5. `R99_d(pr, baseline_pr=None, baseline_years=(1961, 1990))`
6. `R99_i(pr, baseline_pr=None, baseline_years=(1961, 1990))`
7. `R90_p(pr, baseline_pr=None, baseline_years=(1961, 1990))`
8. `R90_d(pr, baseline_pr=None, baseline_years=(1961, 1990))`
9. `R90_i(pr, baseline_pr=None, baseline_years=(1961, 1990))`

## 7. 典型工作流示例

```python
import xarray as xr
from yu_pytools.ETCCDI import (
    PRCPTOT, RX5DAY, CDD,
    R10_d, R20_p,
    R95_p, R95_d
)

pr = xr.open_dataset("pr_daily.nc")["pr"]

# 基础指数
prcptot = PRCPTOT(pr)
rx5day = RX5DAY(pr)
cdd = CDD(pr)

# 固定阈值指数
r10d = R10_d(pr)
r20p = R20_p(pr)

# 百分位指数（使用自定义基准期）
r95p = R95_p(pr, baseline_years=(1981, 2010))
r95d = R95_d(pr, baseline_years=(1981, 2010))

# 保存结果
prcptot.to_netcdf("PRCPTOT.nc")
rx5day.to_netcdf("RX5DAY.nc")
r95p.to_netcdf("R95P.nc")
```

## 8. 常见问题

### 8.1 报错：输入数据必须包含 `time` 维度

请确认输入的是 `DataArray`，且维度包含 `time`。

### 8.2 报错：无效的降水变量名

请将变量名改为支持名称之一，或者在读取后重命名：

```python
pr = ds["your_var"].rename("pr")
```

### 8.3 报错：未找到某基准期年的数据

请检查数据覆盖年份，确保 `baseline_years` 在数据年份范围内。

### 8.4 结果全是 NaN

可能原因：

1. 基准期湿日（>=1mm）样本不足
2. 输入数据本身缺测严重
3. 阈值条件过高

## 9. 输出说明

多数函数返回 `xarray.DataArray`，通常包含 `year` 维度及空间维（如 `lat`、`lon`），并带有部分属性（`attrs`）。

建议将输出保存为 NetCDF 以便后续分析与绘图。
