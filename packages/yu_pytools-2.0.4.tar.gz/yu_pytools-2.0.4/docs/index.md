# yu-pytools 文档

## 模块文档

1. [ETCCDI 操作文档](ETCCDI.md)
2. [CSM 操作文档](CSM.md)
3. [PRV 操作文档](PRV.md)

## 说明

1. `ETCCDI.md`：极端降水指数的输入要求、函数说明与示例。
2. `CSM.md`：空间平均计算（含 shp 范围裁剪）的参数说明与示例。
3. `PRV.md`：降水变异系数（CV）计算的函数说明与示例。
