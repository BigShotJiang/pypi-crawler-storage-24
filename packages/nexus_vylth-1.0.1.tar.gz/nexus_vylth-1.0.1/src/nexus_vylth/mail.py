"""Nexus Mail API client."""

from __future__ import annotations

import requests
from dataclasses import dataclass
from .exceptions import NexusMailError

DEFAULT_BASE_URL = "https://mail.vylth.com/api"


@dataclass
class SendResult:
    """Result of a send operation."""
    message: str
    from_address: str
    to: str


class NexusMail:
    """Send emails via the Nexus Mail API.

    Usage::

        from nexus_vylth import NexusMail

        mail = NexusMail("nm_your_key_here")
        mail.send(to="user@example.com", subject="Hello", body_text="Hi!")
    """

    def __init__(self, api_key: str, *, base_url: str = DEFAULT_BASE_URL, timeout: int = 30):
        if not api_key.startswith("nm_"):
            raise NexusMailError("API key must start with 'nm_'")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        })

    def send(
        self,
        to: str,
        subject: str,
        body_text: str | None = None,
        body_html: str | None = None,
    ) -> SendResult:
        """Send a single email.

        Args:
            to: Recipient email address.
            subject: Email subject line.
            body_text: Plain text body (at least one of text/html required).
            body_html: HTML body (at least one of text/html required).

        Returns:
            SendResult with message, from_address, and to fields.

        Raises:
            NexusMailError: If the API returns an error.
        """
        if not to or not subject:
            raise NexusMailError("'to' and 'subject' are required")
        if not body_text and not body_html:
            raise NexusMailError("At least one of 'body_text' or 'body_html' is required")

        payload: dict = {"to": to, "subject": subject}
        if body_text:
            payload["body_text"] = body_text
        if body_html:
            payload["body_html"] = body_html

        resp = self._session.post(f"{self._base_url}/send", json=payload, timeout=self._timeout)
        data = resp.json()

        if not resp.ok:
            raise NexusMailError(data.get("error", "Unknown error"), status_code=resp.status_code)

        return SendResult(
            message=data.get("message", ""),
            from_address=data.get("from", ""),
            to=data.get("to", to),
        )

    def send_batch(
        self,
        recipients: list[str],
        subject: str,
        body_text: str | None = None,
        body_html: str | None = None,
    ) -> list[SendResult | NexusMailError]:
        """Send the same email to multiple recipients.

        Args:
            recipients: List of email addresses.
            subject: Email subject line.
            body_text: Plain text body.
            body_html: HTML body.

        Returns:
            List of SendResult (success) or NexusMailError (failure) per recipient.
        """
        results: list[SendResult | NexusMailError] = []
        for addr in recipients:
            try:
                result = self.send(to=addr, subject=subject, body_text=body_text, body_html=body_html)
                results.append(result)
            except NexusMailError as e:
                results.append(e)
        return results
