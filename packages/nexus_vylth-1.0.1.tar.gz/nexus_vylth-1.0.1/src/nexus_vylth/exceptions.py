"""Nexus SDK exceptions."""


class NexusError(Exception):
    """Base exception for all Nexus SDK errors."""
    pass


class NexusAuthError(NexusError):
    """Raised when token verification fails."""
    pass


class NexusMailError(NexusError):
    """Raised when a mail API call fails."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code
