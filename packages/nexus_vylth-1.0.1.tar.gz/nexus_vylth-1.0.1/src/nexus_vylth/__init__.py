"""Nexus SDK for Python — auth verification and mail API for VYLTH services."""

from .mail import NexusMail
from .auth import NexusAuth, NexusClaims
from .exceptions import NexusError, NexusAuthError, NexusMailError

__version__ = "1.0.0"
__all__ = ["NexusMail", "NexusAuth", "NexusClaims", "NexusError", "NexusAuthError", "NexusMailError"]
