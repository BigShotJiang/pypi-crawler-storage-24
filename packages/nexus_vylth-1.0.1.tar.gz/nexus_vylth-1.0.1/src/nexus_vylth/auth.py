"""Nexus Auth — JWT verification using JWKS."""

from __future__ import annotations

import time
import threading
import requests
from dataclasses import dataclass, field
from .exceptions import NexusAuthError

try:
    from jwt import PyJWKClient, decode as jwt_decode, ExpiredSignatureError, InvalidTokenError
    _HAS_PYJWT = True
except ImportError:
    _HAS_PYJWT = False

DEFAULT_ISSUER = "https://auth.vylth.com"
JWKS_PATH = "/.well-known/jwks.json"


@dataclass
class NexusClaims:
    """Parsed JWT claims from a Nexus access token."""
    sub: str
    email: str
    username: str
    first_name: str
    last_name: str
    avatar: str
    global_role: str
    email_verified: bool
    affiliate_code: str
    app_roles: dict[str, str] = field(default_factory=dict)
    two_factor_verified: bool = False
    exp: int = 0
    iat: int = 0
    raw: dict = field(default_factory=dict)

    def has_role(self, role: str) -> bool:
        """Check if user has at least the given global role."""
        hierarchy = ["citizen", "pioneer", "navigator", "commander", "executor"]
        try:
            user_level = hierarchy.index(self.global_role)
            required_level = hierarchy.index(role)
            return user_level >= required_level
        except ValueError:
            return False

    def has_app_role(self, app_slug: str, role: str) -> bool:
        """Check if user has at least the given role for a specific app."""
        hierarchy = ["citizen", "pioneer", "navigator", "commander", "executor"]
        user_role = self.app_roles.get(app_slug, self.global_role)
        try:
            return hierarchy.index(user_role) >= hierarchy.index(role)
        except ValueError:
            return False


class NexusAuth:
    """Verify Nexus JWT access tokens using JWKS.

    Usage::

        from nexus_vylth import NexusAuth

        auth = NexusAuth()
        claims = auth.verify(token)
        print(claims.email, claims.global_role)

    FastAPI dependency::

        from nexus_vylth import NexusAuth

        auth = NexusAuth()

        @app.get("/protected")
        async def protected(claims = Depends(auth.fastapi_dependency())):
            return {"user": claims.email}
    """

    def __init__(self, issuer: str = DEFAULT_ISSUER, *, audience: str | None = None, cache_ttl: int = 300):
        if not _HAS_PYJWT:
            raise NexusAuthError(
                "PyJWT with cryptography is required for auth. "
                "Install with: pip install 'nexus-vylth[auth]'"
            )
        self._issuer = issuer.rstrip("/")
        self._audience = audience
        self._jwks_url = f"{self._issuer}{JWKS_PATH}"
        self._jwks_client = PyJWKClient(self._jwks_url, cache_keys=True, lifespan=cache_ttl)
        self._cache_ttl = cache_ttl

    def verify(self, token: str) -> NexusClaims:
        """Verify a JWT access token and return parsed claims.

        Args:
            token: The raw JWT string (without 'Bearer ' prefix).

        Returns:
            NexusClaims with all token fields.

        Raises:
            NexusAuthError: If the token is invalid, expired, or verification fails.
        """
        try:
            signing_key = self._jwks_client.get_signing_key_from_jwt(token)

            options = {"verify_aud": False}
            if self._audience:
                options["verify_aud"] = True

            payload = jwt_decode(
                token,
                signing_key.key,
                algorithms=["RS256"],
                audience=self._audience if self._audience else None,
                options=options,
            )

            return NexusClaims(
                sub=payload.get("sub", ""),
                email=payload.get("email", ""),
                username=payload.get("username", ""),
                first_name=payload.get("first_name", ""),
                last_name=payload.get("last_name", ""),
                avatar=payload.get("avatar", ""),
                global_role=payload.get("global_role", "citizen"),
                email_verified=payload.get("email_verified", False),
                affiliate_code=payload.get("affiliate_code", ""),
                app_roles=payload.get("app_roles", {}),
                two_factor_verified=payload.get("two_factor_verified", False),
                exp=payload.get("exp", 0),
                iat=payload.get("iat", 0),
                raw=payload,
            )

        except ExpiredSignatureError:
            raise NexusAuthError("Token has expired")
        except InvalidTokenError as e:
            raise NexusAuthError(f"Invalid token: {e}")
        except Exception as e:
            raise NexusAuthError(f"Token verification failed: {e}")

    def fastapi_dependency(self, required_role: str | None = None):
        """Create a FastAPI dependency for token verification.

        Args:
            required_role: Minimum global role required (e.g., 'pioneer').

        Returns:
            An async function suitable for use with FastAPI's Depends().

        Example::

            auth = NexusAuth()

            @app.get("/admin")
            async def admin(claims = Depends(auth.fastapi_dependency("commander"))):
                return {"admin": claims.username}
        """
        auth = self

        async def _dependency(authorization: str = None):
            if not authorization:
                # Try to get from header
                from fastapi import Request, HTTPException
                raise HTTPException(status_code=401, detail="Missing authorization header")

            token = authorization
            if token.startswith("Bearer "):
                token = token[7:]

            try:
                claims = auth.verify(token)
            except NexusAuthError as e:
                from fastapi import HTTPException
                raise HTTPException(status_code=401, detail=str(e))

            if required_role and not claims.has_role(required_role):
                from fastapi import HTTPException
                raise HTTPException(status_code=403, detail=f"Requires role: {required_role}")

            return claims

        # Use FastAPI's Header injection if available
        try:
            from fastapi import Header, HTTPException

            async def _fastapi_dep(authorization: str = Header(None)):
                if not authorization:
                    raise HTTPException(status_code=401, detail="Missing authorization header")

                token = authorization
                if token.startswith("Bearer "):
                    token = token[7:]

                try:
                    claims = auth.verify(token)
                except NexusAuthError as e:
                    raise HTTPException(status_code=401, detail=str(e))

                if required_role and not claims.has_role(required_role):
                    raise HTTPException(status_code=403, detail=f"Requires role: {required_role}")

                return claims

            return _fastapi_dep

        except ImportError:
            return _dependency

    def flask_decorator(self, required_role: str | None = None):
        """Create a Flask route decorator for token verification.

        Example::

            auth = NexusAuth()

            @app.route("/protected")
            @auth.flask_decorator("pioneer")
            def protected():
                from flask import g
                return {"user": g.nexus_claims.email}
        """
        auth = self

        def decorator(f):
            from functools import wraps

            @wraps(f)
            def wrapper(*args, **kwargs):
                from flask import request, g, jsonify

                auth_header = request.headers.get("Authorization", "")
                if not auth_header.startswith("Bearer "):
                    return jsonify({"error": "Missing or invalid authorization header"}), 401

                token = auth_header[7:]

                try:
                    claims = auth.verify(token)
                except NexusAuthError as e:
                    return jsonify({"error": str(e)}), 401

                if required_role and not claims.has_role(required_role):
                    return jsonify({"error": f"Requires role: {required_role}"}), 403

                g.nexus_claims = claims
                return f(*args, **kwargs)

            return wrapper

        return decorator
