"""
Module to load CSV files to postgres tables.
Event Types: Build Created, Build Failed, Deployed, and related pipeline events.

Supports CSV files produced by:
  extract_jenkins.py, extract_github_actions.py, extract_gitlab_actions.py,
  extract_azuredevops_pipelines.py, extract_bitbucket_pipelines.py, extract_octopus.py

Command: python '<source code file name>' -p <product name> --data-source <data_source>
         -d <directory name>  |  -f <file name>
"""

import argparse
import copy
import csv
import json
import os
import re
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Set

from psycopg2.extras import execute_values

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import DatabaseConnection
sys.path.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'common'))
from utils import Utils
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger('load_build_and_deployment_event')

from reader import CsvEventReader
from loader import Loader
from parser import Parser

# Required columns for build and deployment CSV files produced by all extract_*.py scripts
BUILD_REQUIRED_COLUMNS = {'timestamp_utc', 'event', 'repo', 'source_branch', 'workflow_name', 'build_number', 'comment', 'actor', 'build_id'}
DEPLOYMENT_REQUIRED_COLUMNS = {'timestamp_utc', 'event', 'build_name', 'repo', 'source_branch', 'comment', 'environment', 'is_major_release', 'release_version', 'build_id'}


def detect_file_type(file_path, data_source):
    """
    Detect if a CSV file contains build events or deployment events,
    based on filename prefix first, then column inspection as fallback.

    :param file_path: Path to CSV file
    :param data_source: Data source name (e.g. 'jenkins', 'github_actions')
    :return: 'build' or 'deployment'
    """
    filename = os.path.basename(file_path).lower()

    if f'{data_source}_build' in filename:
        return 'build'
    elif f'{data_source}_deployment' in filename:
        return 'deployment'

    # Fallback: inspect columns
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            columns = set(reader.fieldnames or [])
            if BUILD_REQUIRED_COLUMNS.issubset(columns):
                return 'build'
            elif DEPLOYMENT_REQUIRED_COLUMNS.issubset(columns):
                return 'deployment'
    except Exception:
        pass

    # Default to build format
    return 'build'


def main():
    parser = argparse.ArgumentParser(description="Load Build and Deployment Events from CSV to database.")
    parser.add_argument('-p', '--product', type=str, required=True, help='Product name')
    parser.add_argument('--data-source', type=str, required=True,
                        help='Data source name matching the CSV filename prefix '
                             '(e.g. jenkins, github_actions, gitlab_actions, '
                             'azuredevops_pipelines, bitbucket_pipelines, octopus)')
    parser.add_argument('-f', '--file', type=str, help='Single CSV file path')
    parser.add_argument('-d', '--directory', type=str, help='Directory containing CSV files')
    args = parser.parse_args()

    file = args.file
    directory = args.directory
    data_source = args.data_source.lower()

    if not (args.file or args.directory):
        print("Error: Either -f/--file or -d/--directory must be specified")
        return 1
    if args.file and args.directory:
        print("Error: Cannot specify both -f/--file and -d/--directory")
        return 1

    product = args.product

    try:
        db = DatabaseConnection()
        with db.product_scope(product) as conn:

            reader = CsvEventReader()
            loader = DBLoader(conn)
            regex_configuration = loader.get_regex_configuration(product)

            # Read Build Stage Pattern and stage→environment mapping from database
            build_event_pattern = None
            deploy_event_mapping = None

            try:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT config_value
                        FROM data_source_config
                        WHERE data_source = 'integration_and_build'
                        AND config_item = 'Build Stage Pattern'
                    """)
                    result = cursor.fetchone()
                    if result and result[0]:
                        build_event_pattern = result[0].strip() or None

                    cursor.execute("""
                        SELECT stage_name, environment
                        FROM environment_mapping
                        WHERE stage_name IS NOT NULL AND job_name IS NULL
                    """)
                    result = cursor.fetchall()
                    if result:
                        deploy_event_mapping = {}
                        for record in result:
                            stage_name = record[0]
                            environment = record[1]
                            if stage_name and environment:
                                deploy_event_mapping[stage_name] = environment
                        if not deploy_event_mapping:
                            deploy_event_mapping = None
                    else:
                        deploy_event_mapping = None
            except Exception as e:
                logging.warning(f"Failed to read build stage pattern or environment mapping: {e}")
                build_event_pattern = None
                deploy_event_mapping = None

            if file:
                if not os.path.exists(file):
                    logging.error(f"Error: File not found: {file}")
                    return 1
                my_dir = Path(file)
                if my_dir.is_dir():
                    logging.error("The path you provided is a directory")
                    return 1

                file_type = detect_file_type(file, data_source)
                event_parser = EventParser(regex_configuration, file_type, build_event_pattern, deploy_event_mapping)
                required_columns = BUILD_REQUIRED_COLUMNS if file_type == 'build' else DEPLOYMENT_REQUIRED_COLUMNS

                processor_obj = Processor(reader, event_parser, loader, data_source,
                                          encoding="utf-8", required_columns=required_columns)
                processor_obj.process_single_file(file)

            elif directory:
                logging.info(f"Processing Directory {directory}")
                if not os.path.exists(directory):
                    print(f"Error: Directory not found: {directory}")
                    return 1
                my_dir = Path(directory)
                if my_dir.is_dir():
                    event_parser = EventParser(regex_configuration, 'new_format', build_event_pattern, deploy_event_mapping)
                    processor_obj = Processor(reader, event_parser, loader, data_source,
                                              encoding="utf-8", required_columns=None)
                    processor_obj.process_directory(directory)
                else:
                    logging.error("The path you provided is not a file but a directory")
                    return 1
            else:
                logging.error("Please provide file/directory to load")

    except Exception as e:
        print(f"Error: {str(e)}")
        return 1

    return 0


class Event:
    """
    Domain model representing a build or deployment event.
    """

    def __init__(
            self,
            timestamp_utc: datetime,
            build_id: str,
            repo: str,
            branch_name: str,
            commit_sha: str,
            environment: str,
            comment: str,
            event_type: str,
            release_version: str,
            is_major_release: bool,
            job_name: str,
            actor: str = None
    ):
        self.timestamp_utc = timestamp_utc
        self.build_id = build_id
        self.repo = repo
        self.branch_name = branch_name
        self.commit_sha = commit_sha
        self.environment = environment
        self.comment = comment
        self.event_type = event_type
        self.release_version = release_version
        self.is_major_release = is_major_release
        self.job_name = job_name
        self.actor = actor


class EventParser(Parser):
    """
    Parses raw event data into Event objects using injected configuration.
    Supports the CSV formats produced by all extract_*.py scripts.
    """

    def __init__(self, regex_configuration, file_type='build', build_event_pattern=None, deploy_event_mapping=None):
        super().__init__()
        self.file_type = file_type  # 'build', 'deployment', or 'new_format'
        self.release_version_branch_pattern = ''
        self.is_major_release_exact_version_pattern = ''
        self.build_event_regex = None
        self.deploy_event_mapping = deploy_event_mapping

        if regex_configuration:
            release_version_branch_pattern = regex_configuration.get("release_version_pattern")
            if release_version_branch_pattern:
                release_version_branch_pattern = release_version_branch_pattern.replace("\\\\", "\\")
            if release_version_branch_pattern:
                self.release_version_branch_pattern = re.compile(release_version_branch_pattern, re.IGNORECASE)

            is_major_release_exact_version_pattern = regex_configuration.get("is_major_release_pattern")
            if is_major_release_exact_version_pattern:
                is_major_release_exact_version_pattern = is_major_release_exact_version_pattern.replace("\\\\", "\\")
            if is_major_release_exact_version_pattern:
                self.is_major_release_exact_version_pattern = re.compile(is_major_release_exact_version_pattern,
                                                                         re.IGNORECASE)

        if build_event_pattern:
            try:
                build_event_pattern = build_event_pattern.replace("\\\\", "\\")
                self.build_event_regex = re.compile(build_event_pattern, re.IGNORECASE)
                logging.info(f"Loaded build event regex pattern: {build_event_pattern}")
            except re.error as e:
                logging.warning(f"Invalid build event regex pattern: {build_event_pattern}, error: {e}")

    def parse(self, rows):
        """
        Parse rows and return (build_events, deploy_events) lists of Event objects.
        """
        if self.file_type == 'build':
            return self._parse_build_format(rows)
        elif self.file_type == 'deployment':
            return self._parse_deployment_format(rows)
        elif self.file_type == 'new_format':
            # For directory processing: detect format from first row's columns
            if rows:
                first_row = rows[0]
                if BUILD_REQUIRED_COLUMNS.issubset(first_row.keys()):
                    return self._parse_build_format(rows)
                elif DEPLOYMENT_REQUIRED_COLUMNS.issubset(first_row.keys()):
                    return self._parse_deployment_format(rows)
            return [], []
        else:
            return self._parse_build_format(rows)

    def _parse_build_format(self, rows):
        """Parse build event CSV files produced by any extract_*.py script."""
        build_events = []
        deploy_events = []
        # Track (repo, workflow_name, build_number) combinations that have already matched
        build_created_repo_workflow_build_numbers = set()

        for row in rows:
            try:
                timestamp_utc = row.get("timestamp_utc")
                if isinstance(timestamp_utc, str):
                    timestamp_utc = Utils.convert_to_utc(timestamp_utc)
                elif timestamp_utc is None:
                    continue

                repo = row.get("repo", "").lower()
                if repo:
                    repo = repo.removesuffix('-releasemanagement').removesuffix('_releasemanagement')

                branch = row.get("source_branch", "")
                clean_branch = branch.split('origin/')[-1] if 'origin/' in branch else branch

                release_version = self.extract_release_version(clean_branch)
                csv_release_version = row.get("release_version", "")
                if csv_release_version:
                    release_version = csv_release_version
                is_major_release = self.extract_is_major_release(release_version)
                if "is_major_release" in row:
                    try:
                        csv_is_major = row.get("is_major_release", "").lower()
                        if csv_is_major in ('true', '1', 'yes'):
                            is_major_release = True
                        elif csv_is_major in ('false', '0', 'no', ''):
                            is_major_release = False
                    except Exception:
                        pass

                event = Event(
                    timestamp_utc=timestamp_utc,
                    build_id=row.get("build_number", ""),   # build_number → build_id in Event
                    repo=repo,
                    branch_name=clean_branch,
                    commit_sha=row.get("build_id", ""),     # build_id in CSV is the commit SHA
                    comment=row.get("comment", ""),
                    event_type=row.get("event", "Build Created"),
                    environment="",
                    release_version=release_version,
                    is_major_release=is_major_release,
                    job_name=row.get("workflow_name", ""),
                    actor=row.get("actor") or None
                )

                event_type = row.get("event", "Build Created")

                # If a Build Stage Pattern is configured, skip pre-existing "Build Created"
                # events from the CSV and re-derive them from matching stage names below.
                if self.build_event_regex and event_type == "Build Created":
                    pass
                else:
                    build_events.append(event)

                    # Derive a "Build Created" event from stage names matching the pattern
                    if self.build_event_regex and event_type != "Build Created":
                        stage_name = row.get("event", "")
                        if stage_name and self.build_event_regex.search(stage_name):
                            build_number = row.get("build_number", "")
                            workflow_name = row.get("workflow_name", "")
                            repo_workflow_build_key = (repo, workflow_name, build_number)
                            if repo_workflow_build_key not in build_created_repo_workflow_build_numbers:
                                build_created_event = copy.deepcopy(event)
                                build_created_event.event_type = "Build Created"
                                build_events.append(build_created_event)
                                build_created_repo_workflow_build_numbers.add(repo_workflow_build_key)

                # Derive deployment events from stage→environment mapping
                if self.deploy_event_mapping:
                    stage_name = row.get("event", "")
                    if stage_name:
                        stage_is_successful = False
                        try:
                            comment = row.get("comment", "")
                            if comment:
                                comment_data = json.loads(comment)
                                stage_status = comment_data.get("status", "").upper()
                                stage_is_successful = stage_status in ("SUCCESS", "SUCCESSFUL", "PASSED")
                        except (json.JSONDecodeError, AttributeError, TypeError):
                            pass

                        if stage_is_successful:
                            stage_name_lower = stage_name.lower()
                            for key, environment in self.deploy_event_mapping.items():
                                if key.lower() == stage_name_lower:
                                    deploy_event = copy.deepcopy(event)
                                    deploy_event.event_type = "Deployed"
                                    deploy_event.environment = environment
                                    deploy_events.append(deploy_event)
                                    break

            except Exception as ex:
                logging.warning(f"Issue in parsing build row, {row}, {ex}")

        return build_events, deploy_events

    def _parse_deployment_format(self, rows):
        """Parse deployment event CSV files produced by any extract_*.py script."""
        build_events = []
        deploy_events = []

        for row in rows:
            try:
                timestamp_utc = row.get("timestamp_utc")
                if isinstance(timestamp_utc, str):
                    timestamp_utc = Utils.convert_to_utc(timestamp_utc)
                elif timestamp_utc is None:
                    continue

                repo = row.get("repo", "").lower()
                if repo:
                    repo = repo.removesuffix('-releasemanagement').removesuffix('_releasemanagement')

                branch = row.get("source_branch", "")
                clean_branch = branch.split('origin/')[-1] if 'origin/' in branch else branch

                release_version = self.extract_release_version(clean_branch)
                csv_release_version = row.get("release_version", "")
                if csv_release_version:
                    release_version = csv_release_version
                is_major_release = self.extract_is_major_release(release_version)
                if "is_major_release" in row:
                    try:
                        csv_is_major = row.get("is_major_release", "").lower()
                        if csv_is_major in ('true', '1', 'yes'):
                            is_major_release = True
                        elif csv_is_major in ('false', '0', 'no', ''):
                            is_major_release = False
                    except Exception:
                        pass

                event = Event(
                    timestamp_utc=timestamp_utc,
                    build_id=row.get("build_name", ""),     # build_name → build_id in Event
                    repo=repo,
                    branch_name=clean_branch,
                    commit_sha=row.get("build_id", ""),     # build_id in CSV is the commit SHA
                    comment=row.get("comment", ""),
                    event_type=row.get("event", "Build Deployed"),
                    environment=row.get("environment", "production"),
                    release_version=release_version,
                    is_major_release=is_major_release,
                    job_name=""
                )

                deploy_events.append(event)

            except Exception as ex:
                logging.warning(f"Issue in parsing deployment row, {row}, {ex}")

        return build_events, deploy_events

    def add_deployment(self, deploy_events, event):
        """Add a deep-copied Deployed event to the list."""
        event_copy = copy.deepcopy(event)
        event_copy.event_type = "Deployed"
        deploy_events.append(event_copy)

    def extract_is_major_release(self, release_version):
        """Return True if release_version matches the is_major_release pattern."""
        if not release_version:
            return False
        return bool(
            re.match(self.is_major_release_exact_version_pattern, release_version)
        ) if release_version else False

    def extract_release_version(self, clean_branch):
        """Extract release_version by matching release_version_branch_pattern against branch name."""
        if not clean_branch:
            return ''
        if self.release_version_branch_pattern:
            release_version = re.sub(r'-', '.', match.group(0)) if (
                match := re.search(self.release_version_branch_pattern, clean_branch)) else None
            return release_version
        return ''


class DBLoader(Loader):
    """
    Persists Event objects to the database.
    """

    def __init__(self, connection):
        super().__init__(connection)
        self.connection = connection
        self.env_mapping = self.get_job_environment_mapping_from_db()

    def save(self, build_events: List[Event], deploy_events: List[Event]):
        """
        Save build and deployment events to the database.

        :param build_events: List of build Event objects
        :param deploy_events: List of deployment Event objects
        :return: (build_count, deploy_count)
        """
        build_count = 0
        deploy_count = 0
        problematic_rows = []

        if build_events:
            build_query = """
                    INSERT INTO build_event (
                        timestamp_utc, event, repo, source_branch, build_id, build_number,
                        comment, actor, workflow_name
                    ) VALUES %s
                    ON CONFLICT ON CONSTRAINT build_event_hash_unique DO NOTHING
                """
            with self.connection.cursor() as cur:
                for i in range(0, len(build_events), 1000):
                    batch = build_events[i:i + 1000]
                    values = []
                    for event in batch:
                        try:
                            repo = event.repo.lower()
                            build_number = event.build_id   # build_number in new-format CSV
                            build_id = event.commit_sha     # commit SHA
                            actor = event.actor or None

                            value = (
                                event.timestamp_utc.strftime('%Y-%m-%d %H:%M:%S') if isinstance(event.timestamp_utc, datetime) else str(event.timestamp_utc),
                                event.event_type,
                                repo,
                                event.branch_name,
                                build_id,
                                build_number,
                                event.comment,
                                actor,
                                event.job_name
                            )
                            values.append(value)
                        except Exception as e:
                            problematic_rows.append(('build', i + batch.index(event), event, str(e)))
                            continue

                    if values:
                        execute_values(cur, build_query, values)
                        build_count += len(values)
                        print(f"\rInserted {build_count}/{len(build_events)} build events", end="")
            print()

        if deploy_events:
            deploy_query = """
                    INSERT INTO deployment_event (
                        timestamp_utc, repo, source_branch, build_name, build_id,
                        environment, comment, event, release_version, is_major_release
                    ) VALUES %s
                    ON CONFLICT ON CONSTRAINT deployment_event_hash_unique DO NOTHING
                """
            with self.connection.cursor() as cur:
                for i in range(0, len(deploy_events), 1000):
                    batch = deploy_events[i:i + 1000]
                    values = []
                    for event in batch:
                        try:
                            repo = event.repo.lower()
                            environment = self.get_environment_by_job_name(event)
                            build_name = event.build_id     # build_name in new-format CSV
                            build_id = event.commit_sha     # commit SHA

                            value = (
                                event.timestamp_utc.strftime('%Y-%m-%d %H:%M:%S') if isinstance(event.timestamp_utc, datetime) else str(event.timestamp_utc),
                                repo,
                                event.branch_name,
                                build_name,
                                build_id,
                                environment,
                                event.comment,
                                event.event_type,
                                event.release_version,
                                event.is_major_release
                            )
                            values.append(value)
                        except Exception as e:
                            problematic_rows.append(('deploy', i + batch.index(event), event, str(e)))
                            continue

                    if values:
                        execute_values(cur, deploy_query, values)
                        deploy_count += len(values)
                        print(f"\rInserted {deploy_count}/{len(deploy_events)} deployment events", end="")
            print()

        if problematic_rows:
            print("\nProblematic rows encountered:")
            for event_type, row_num, row, error in problematic_rows:
                print(f"{event_type.capitalize()} Event - Row {row_num}: {error}")
                print(f"Data: {row}")

        return build_count, deploy_count

    def get_environment_by_job_name(self, event):
        """Return environment from env_mapping, falling back to event.environment."""
        if not event.environment or event.environment == "":
            return self.env_mapping.get(event.job_name, '') if self.env_mapping else ''
        return event.environment

    def get_job_environment_mapping_from_db(self):
        """
        Load environment mapping keyed by job_name
        (rows where job_name IS NOT NULL AND stage_name IS NULL).
        """
        mapping = {}
        with self.connection.cursor() as cur:
            cur.execute("""
                SELECT job_name, environment
                FROM environment_mapping
                WHERE job_name IS NOT NULL AND stage_name IS NULL
            """)
            result = cur.fetchall()
            if result:
                for record in result:
                    job_name = record[0]
                    environment = record[1]
                    if job_name:
                        mapping[job_name] = environment
        return mapping


class Processor:
    """
    Coordinates reading, parsing, and saving of events.
    """

    def __init__(
            self,
            reader: CsvEventReader,
            parser: EventParser,
            loader: DBLoader,
            data_source: str,
            encoding: str,
            required_columns: Set[str]
    ):
        self.reader = reader
        self.loader = loader
        self.parser = parser
        self.data_source = data_source
        self.encoding = encoding
        self.required_columns = required_columns

    def process_single_file(self, file_path):
        """
        Process a single CSV file.

        :param file_path: File path
        :return: number of inserted records
        """
        raw = self.reader.read(file_path, logger, self.required_columns, encoding=self.encoding)
        build_events, deploy_events = self.parser.parse(raw)
        build_count, deploy_count = self.loader.save(build_events, deploy_events)
        logging.info(f"Inserted {build_count} builds, {deploy_count} deploys from {file_path}")
        return build_count + deploy_count

    def process_directory(self, directory) -> int:
        """
        Process all CSV files in a directory that match the data_source prefix.

        :param directory: Directory path
        :return: Total number of records inserted
        """
        build_pattern = f"{self.data_source}_build_*"
        deploy_pattern = f"{self.data_source}_deployment_*"

        build_files = self.reader.list_files(directory, build_pattern)
        deploy_files = self.reader.list_files(directory, deploy_pattern)
        files = build_files + deploy_files

        if not files:
            logging.info("No CSV files matching '%s' patterns found in %s", self.data_source, directory)
            return 0

        logging.info("Found %d CSV files: %d build, %d deployment",
                     len(files), len(build_files), len(deploy_files))

        all_build_events = []
        all_deploy_events = []

        for idx, file_path in enumerate(files, start=1):
            logging.info("Reading file %d/%d: %s", idx, len(files), file_path)

            file_type = detect_file_type(file_path, self.data_source)
            required_cols = BUILD_REQUIRED_COLUMNS if file_type == 'build' else DEPLOYMENT_REQUIRED_COLUMNS
            self.parser.file_type = file_type

            raw = self.reader.read(file_path, logger, required_cols, encoding=self.encoding)
            build_events, deploy_events = self.parser.parse(raw)
            all_build_events.extend(build_events)
            all_deploy_events.extend(deploy_events)

        if not all_build_events and not all_deploy_events:
            logging.info("No events to process after reading all files.")
            return 0

        def normalize_timestamp(ts):
            if ts is None:
                raise ValueError("timestamp_utc is None")
            if ts.tzinfo is not None:
                ts = ts.astimezone(timezone.utc).replace(tzinfo=None)
            return ts

        try:
            for e in all_build_events:
                e.timestamp_utc = normalize_timestamp(e.timestamp_utc)
            for e in all_deploy_events:
                e.timestamp_utc = normalize_timestamp(e.timestamp_utc)
            all_build_events.sort(key=lambda e: e.timestamp_utc)
            all_deploy_events.sort(key=lambda e: e.timestamp_utc)
        except Exception as ex:
            logging.error("Failed to sort events by timestamp_utc: %s", ex)
            for e in all_build_events + all_deploy_events:
                try:
                    normalize_timestamp(e.timestamp_utc)
                except Exception as inner_ex:
                    logging.error("Bad timestamp in event: %s, error: %s", e, inner_ex)
            return 0

        logging.info("Got %d builds and %d deploys", len(all_build_events), len(all_deploy_events))

        build_count, deploy_count = self.loader.save(all_build_events, all_deploy_events)
        total = build_count + deploy_count
        logging.info("Inserted %d builds and %d deploys from merged files", build_count, deploy_count)
        logging.info("Total events inserted: %d", total)
        return total


if __name__ == "__main__":
    main()
