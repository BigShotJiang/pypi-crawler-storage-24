"""
Album Policy Resolver

This module provides logic for resolving which user groups and members should have access to an album, based on album name keyword matching, configured selection rules, and user group definitions.

Responsibility:
        - Centralizes all logic for album permission assignment and synchronization.
        - Ensures configuration is the source of truth for album permissions.
        - Supports dry-run (detection & logging) and full synchronization modes.
        - Prevents orphaned or stale permissions by enforcing config-driven membership.
        - Should be the only place in the codebase that determines album access policy.

Synchronization Policy (IMPORTANT):
        - Phase 1: Detection & logging only (no API calls)
        - Phase 2: Complete synchronization - only configured members will have access
                * Members in config but not in album → ADDED
                * Members in album but not in config → REMOVED
                * This prevents accidental orphaned permissions when configuration changes

Admin users (system operators) should not appear in member lists to avoid accidental removal.
"""

import re
from typing import TYPE_CHECKING, Dict, List, Optional

import attrs

from immich_autotag.api.logging_proxy.types import AlbumUserRole
from immich_autotag.config.models import AlbumSelectionRule, UserGroup

if TYPE_CHECKING:
    from immich_autotag.albums.album.album_response_wrapper import AlbumResponseWrapper


@attrs.define(auto_attribs=True, slots=True)
class ResolvedAlbumPolicy:
    """
    Result of resolving an album's permission policy.

    Attributes:
        album_name: Name of the album being resolved.
        album_id: Unique identifier for the album.
        matched_rules: List of rule names that matched this album.
        groups: List of group names that should have access.
        members: List of member emails/user IDs that should have access.
        access_level: Permission level (typed).
        has_match: True if any rule matched, False otherwise.

    Responsibility:
        - Encapsulates the result of permission resolution for a single album.
        - Used as the source of truth for permission synchronization and reporting.
        - Provides a string representation for logging and debugging.
    """

    album: "AlbumResponseWrapper" = attrs.field()
    # album_name and album_id removed; use album.get_album_name() and album.get_album_uuid() instead
    matched_rules: list[str] = attrs.field(validator=attrs.validators.instance_of(list))
    groups: list[str] = attrs.field(validator=attrs.validators.instance_of(list))
    members: list[str] = attrs.field(validator=attrs.validators.instance_of(list))
    access_level: AlbumUserRole = attrs.field(
        validator=attrs.validators.instance_of(AlbumUserRole)
    )
    has_match: bool = attrs.field(init=False)

    def __attrs_post_init__(self):
        self.has_match = len(self.matched_rules) > 0

    def __str__(self) -> str:
        album_name = self.album.get_album_name()
        if not self.has_match:
            return f"Album '{album_name}': NO MATCH"
        return (
            f"Album '{album_name}': "
            f"Matched rules={self.matched_rules}, "
            f"Groups={self.groups}, "
            f"Members={self.members}, "
            f"Access={self.access_level.value}"
        )


def _split_album_name_to_words(album_name: str) -> List[str]:
    """
    Split album name by common separators into words.
    Separators: space, hyphen, underscore, dot
    Returns list of words (lowercase for matching)
    """
    # Replace separators with spaces, then split
    name_normalized = re.sub(r"[-_\.\s]+", " ", album_name)
    words = name_normalized.split()
    return [w.lower() for w in words]


def _match_keyword_in_album(album_name: str, keyword: str) -> bool:
    """
    Check if keyword appears in album name.
    Uses case-insensitive word matching (not substring).

    Example:
        album_name="2024-Familia-Vacation"
        keyword="familia"
        → Split to ["2024", "familia", "vacation"]
        → Match "familia" (case-insensitive)
        → True

        album_name="Family-Photo-Album"
        keyword="familia"
        → Split to ["family", "photo", "album"]
        → No match
        → False
    """
    words = _split_album_name_to_words(album_name)
    keyword_lower = keyword.lower()
    return keyword_lower in words


def resolve_album_policy(
    album: "AlbumResponseWrapper",
    user_groups: Dict[str, UserGroup],
    selection_rules: List[AlbumSelectionRule],
) -> "ResolvedAlbumPolicy":
    """
    Resolve album permission policy based on config rules and user groups.

    This function determines which members (from configured groups) should have access
    to a given album based on keyword matching. The result is used for:

    - Phase 1: Reporting what permissions would be applied (dry-run)
    - Phase 2: Synchronizing actual permissions - ONLY members in resolved_policy.members
      will have access. Members not in this list will be removed to maintain sync.

    Args:
        album_name: Album name to match against rules
        album_id: Album ID
        user_groups: Dict mapping group name → UserGroup object
        selection_rules: List of AlbumSelectionRule to match

    Returns:
        ResolvedAlbumPolicy with resolved members (source of truth for Phase 2 sync)

    Example:
        Config has: grupo="familia" with ["abuelo@ex.com", "madre@ex.com"]
        Album is: "2024-Familia-Vacation"
        Result: ResolvedAlbumPolicy with members=["abuelo@ex.com", "madre@ex.com"]

        If later config removes "abuelo@ex.com", Phase 2 will automatically remove
        that user's access on next run (complete synchronization).
    """
    matched_rules_names: List[str] = []
    all_groups: List[str] = []
    all_members: List[str] = []
    access_level = AlbumUserRole.VIEWER

    album_name = album.get_album_name()
    # album_id = str(album.get_album_uuid())  # removed unused variable

    # Iterate rules and accumulate all matches
    for rule in selection_rules:
        if _match_keyword_in_album(album_name, rule.keyword):
            matched_rules_names.append(rule.name)
            all_groups.extend(rule.groups)
            # Map config strings to AlbumUserRole
            role_map = {
                "view": AlbumUserRole.VIEWER,
                "edit": AlbumUserRole.EDITOR,
                "editor": AlbumUserRole.EDITOR,
            }
            access_level = role_map.get(rule.access.lower(), AlbumUserRole.VIEWER)

    # Resolve members from groups
    all_groups_unique = list(set(all_groups))  # Remove duplicates
    for group_name in all_groups_unique:
        if group_name in user_groups:
            group = user_groups[group_name]
            all_members.extend(group.members)

    # Remove duplicate members
    all_members_unique = list(set(all_members))

    return ResolvedAlbumPolicy(
        album=album,
        matched_rules=matched_rules_names,
        groups=all_groups_unique,
        members=all_members_unique,
        access_level=access_level,
    )


def build_user_groups_dict(
    user_groups: Optional[List[UserGroup]],
) -> Dict[str, UserGroup]:
    """
    Build a dict mapping group name → UserGroup for fast lookup.
    """
    if not user_groups:
        return {}
    return {group.name: group for group in user_groups}
