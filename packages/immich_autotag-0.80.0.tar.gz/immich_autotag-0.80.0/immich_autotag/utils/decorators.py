"""
decorators.py

Conditional decorators that respect configuration settings.
Used to enable/disable expensive runtime checks like type checking.
"""

from typing import Any, Callable, TypeVar

# Type variable for decorator
F = TypeVar("F", bound=Callable[..., Any])


def conditional_typechecked(func: F) -> F:
    """
    Wrapper around @typechecked that respects config.performance.enable_type_checking.

    When disabled (default in production), this is a no-op decorator that passes
    through the original function unchanged, providing massive performance improvements
    (~47K seconds saved).

    When enabled (for development), uses the real @typechecked from typeguard.

    Usage:
        @conditional_typechecked
        def my_function(x: int) -> str:
            return str(x)

    Performance impact (disabled):
        - Zero overhead: decorator is applied at import time, function is called
          directly
        - Estimated savings: ~23,110 seconds per full run (11% improvement)

    Performance impact (enabled):
        - 3.96 billion type checks performed across application
        - ~23,110 seconds cumulative time (11% of total execution)
    """
    try:
        # Try to get config to check if type checking is enabled
        from immich_autotag.config.manager import ConfigManager
        from immich_autotag.config.models import PerformanceConfig, UserConfig

        config_manager: ConfigManager = ConfigManager.get_instance()
        config: UserConfig = config_manager.get_config()
        enable_type_checking: bool = True
        # config is never None
        performance: PerformanceConfig | None = config.performance
        # performance is never None
        if performance is not None:
            enable_type_checking = performance.enable_type_checking

        if enable_type_checking:
            # Use real typechecked from typeguard
            from typeguard import typechecked as real_typechecked

            return real_typechecked(func)
        else:
            # No-op: return function unchanged
            return func

    except Exception:
        # Fallback: if config not available, don't apply any checking
        # This prevents import errors if this is called during initialization
        return func
