"""tibet-ledger CLI — delegates to tibet-jawbreaker."""

from tibet_jawbreaker.cli import main

if __name__ == "__main__":
    main()
