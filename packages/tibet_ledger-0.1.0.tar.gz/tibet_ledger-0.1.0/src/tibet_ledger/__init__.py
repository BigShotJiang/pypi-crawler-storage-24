"""
tibet-ledger — alias for tibet-jawbreaker.

Provenance-first crypto transactions — every transfer has intent,
every wallet has identity.

Install either package — they're the same thing:
    pip install tibet-ledger
    pip install tibet-jawbreaker
"""

from tibet_jawbreaker import (
    __version__,
    Ledger,
    NotaryAttestation,
    WalletAddress,
    JawbreakerWallet,
    WalletRegistry,
    TransactionType,
    LegitimacyLevel,
    JawbreakerTransaction,
    TransactionEngine,
)

__all__ = [
    "__version__",
    "Ledger",
    "NotaryAttestation",
    "WalletAddress",
    "JawbreakerWallet",
    "WalletRegistry",
    "TransactionType",
    "LegitimacyLevel",
    "JawbreakerTransaction",
    "TransactionEngine",
]
