# tibet-ledger

**Provenance-first crypto transactions — every transfer has intent, every wallet has identity.**

This is an alias for [`tibet-jawbreaker`](https://pypi.org/project/tibet-jawbreaker/). Install either one — they're the same thing.

```bash
pip install tibet-ledger
# or
pip install tibet-jawbreaker
```

## Quick Start

```bash
# Full demo: legit vs suspicious transactions
tibet-ledger demo
```

## Python API

```python
from tibet_ledger import Ledger, LegitimacyLevel

ledger = Ledger()
jasper = ledger.register_wallet("jis:jasper", verified=True)

# Transfer WITH intent = legitimate
tx = ledger.transfer(
    from_jis="jis:jasper",
    to_jis="jis:humotica",
    amount=5.0,
    currency="ETH",
    intent="Payment for Q1 development",
)
print(tx.legitimacy)  # LegitimacyLevel.LEGITIMATE

# Transfer WITHOUT intent = suspicious
tx2 = ledger.transfer(
    from_jis="jis:anon:someone",
    to_jis="jis:anon:other",
    amount=50.0,
    currency="ETH",
)
print(tx2.legitimacy)  # LegitimacyLevel.SUSPICIOUS
```

## Features

- Legitimacy scoring (intent, identity, context)
- Wash trading & round-trip detection
- Blind mining flagging
- Notary attestation
- Wallet trust leaderboard
- Full TIBET audit trail

## License

MIT — Humotica AI Lab 2025-2026
