# RunPod Management

A Python client for the RunPod Cloud REST API.

## Features

- Full pod lifecycle management (create, list, get, update, delete)
- Pod control operations (start, stop, restart)
- Container registry authentication management (CRUD)
- Account information: balance, spend, and quota via GraphQL API
- Type-safe Pydantic models for all requests and responses
- Configuration via environment variables or programmatic setup
- Comprehensive error handling

## Installation

```bash
pip install -e .
```

## Quick Start

1. Set your API key:

```bash
export RUNPOD_API_KEY=your_api_key_here
```

2. Use the clients:

```python
from evolvishub_runpod_management import AccountInfoClient, PodClient, ContainerRegistryAuthClient, PodCreateInput

# Account information
with AccountInfoClient.initialize() as client:
    balance = client.get_balance()
    print(f"Credit balance: ${balance.credit_balance}")
    print(f"Current spend/hr: ${balance.current_spend_per_hr}")
```

```python
from evolvishub_runpod_management import PodClient, ContainerRegistryAuthClient, PodCreateInput

# Pod management
with PodClient.initialize() as client:
    # Create a pod
    pod = client.create_pod(PodCreateInput(
        image_name="runpod/pytorch:2.0.0-py3.10-cuda11.8.0-devel",
        name="my-pod",
        gpu_type_ids=["NVIDIA RTX A4000"],
        container_disk_in_gb=50,
    ))
    print(f"Created: {pod.id}")

    # List all pods
    for p in client.list_pods():
        print(f"{p.id}: {p.name} - {p.desired_status}")

    # Stop the pod
    client.stop_pod(pod.id)

# Container registry auth management
from evolvishub_runpod_management import ContainerRegistryAuthCreateInput

with ContainerRegistryAuthClient.initialize() as client:
    # Create credentials
    auth = client.create(ContainerRegistryAuthCreateInput(
        name="my-docker-hub",
        username="myuser",
        password="mypassword",
    ))
    print(f"Created auth: {auth.id}")

    # List all credentials
    for a in client.list():
        print(f"{a.id}: {a.name}")
```

## Documentation

See [docs/usage.md](docs/usage.md) for full API reference and examples.

## Development

```bash
# Install with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Lint
ruff check evolvishub_runpod_management/ tests/
```

## License

MIT
