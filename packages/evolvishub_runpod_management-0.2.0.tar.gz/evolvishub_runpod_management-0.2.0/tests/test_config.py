"""Tests for configuration management."""

import os
from pathlib import Path
from unittest.mock import patch

import pytest

from evolvishub_runpod_management.config import RunPodConfig


class TestRunPodConfig:
    """Tests for RunPodConfig class."""

    def test_create_config_directly(self):
        """Create config with direct parameters."""
        config = RunPodConfig(
            api_key="test_key",
            base_url="https://custom.api.com",
            request_timeout=60.0,
        )
        assert config.api_key == "test_key"
        assert config.base_url == "https://custom.api.com"
        assert config.request_timeout == 60.0

    def test_default_values(self):
        """Config uses defaults for optional fields."""
        config = RunPodConfig(api_key="key123")
        assert config.base_url == "https://rest.runpod.io/v1"
        assert config.request_timeout == 30.0

    def test_load_from_env_variables(self):
        """Load config from environment variables."""
        env = {
            "RUNPOD_API_KEY": "env_api_key",
            "RUNPOD_BASE_URL": "https://env.api.com",
            "RUNPOD_TIMEOUT": "45",
        }
        with patch.dict(os.environ, env, clear=False):
            config = RunPodConfig.load(env_file="nonexistent.env")

        assert config.api_key == "env_api_key"
        assert config.base_url == "https://env.api.com"
        assert config.request_timeout == 45.0

    def test_load_parameter_overrides_env(self):
        """Explicit parameters override environment."""
        env = {"RUNPOD_API_KEY": "env_key", "RUNPOD_TIMEOUT": "100"}
        with patch.dict(os.environ, env, clear=False):
            config = RunPodConfig.load(
                api_key="param_key",
                request_timeout=15.0,
                env_file="nonexistent.env",
            )

        assert config.api_key == "param_key"
        assert config.request_timeout == 15.0

    def test_load_missing_api_key_raises(self):
        """Missing API key raises ValueError."""
        with patch.dict(os.environ, {}, clear=True):
            with pytest.raises(ValueError, match="API key is required"):
                RunPodConfig.load(env_file="nonexistent.env")

    def test_load_from_env_file(self, tmp_path: Path):
        """Load config from .env file."""
        env_file = tmp_path / ".env"
        env_file.write_text(
            "RUNPOD_API_KEY=file_api_key\n"
            "RUNPOD_BASE_URL=https://file.api.com\n"
            "RUNPOD_TIMEOUT=25\n"
        )

        # Clear any existing env vars
        with patch.dict(os.environ, {}, clear=True):
            config = RunPodConfig.load(env_file=env_file)

        assert config.api_key == "file_api_key"
        assert config.base_url == "https://file.api.com"
        assert config.request_timeout == 25.0

    def test_load_defaults_when_not_specified(self):
        """Uses defaults when values not in env or params."""
        env = {"RUNPOD_API_KEY": "key_only"}
        with patch.dict(os.environ, env, clear=True):
            config = RunPodConfig.load(env_file="nonexistent.env")

        assert config.api_key == "key_only"
        assert config.base_url == "https://rest.runpod.io/v1"
        assert config.request_timeout == 30.0

    def test_load_accepts_path_object(self, tmp_path: Path):
        """Load accepts Path object for env_file."""
        env_file = tmp_path / "custom.env"
        env_file.write_text("RUNPOD_API_KEY=path_key\n")

        with patch.dict(os.environ, {}, clear=True):
            config = RunPodConfig.load(env_file=env_file)

        assert config.api_key == "path_key"
