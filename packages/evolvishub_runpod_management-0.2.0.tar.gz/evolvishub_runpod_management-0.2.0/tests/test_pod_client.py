"""Tests for PodClient."""

import pytest
from pytest_httpx import HTTPXMock

from evolvishub_runpod_management.clients import PodClient
from evolvishub_runpod_management.config import RunPodConfig
from evolvishub_runpod_management.exceptions import (
    RunPodAuthenticationError,
    RunPodConnectionError,
    RunPodNotFoundError,
    RunPodValidationError,
)
from evolvishub_runpod_management.models.pods import PodCreateInput, PodListFilters, PodUpdateInput


class TestPodClientInit:
    """Tests for client initialization."""

    def test_create_with_config(self, config: RunPodConfig):
        """Create client with config object."""
        client = PodClient(config)
        assert client._config == config

    def test_initialize_factory(self, mock_api_key: str):
        """Initialize using factory method."""
        client = PodClient.initialize(
            api_key=mock_api_key,
            base_url="https://custom.api.com",
            request_timeout=60.0,
        )
        assert client._config.api_key == mock_api_key
        assert client._config.base_url == "https://custom.api.com"

    def test_context_manager(self, config: RunPodConfig):
        """Client works as context manager."""
        with PodClient(config) as client:
            assert isinstance(client, PodClient)


class TestCreatePod:
    """Tests for create_pod method."""

    def test_create_pod_success(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
        sample_pod_response: dict,
    ):
        """Successfully create a pod."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/pods",
            json=sample_pod_response,
        )

        params = PodCreateInput(
            image_name="runpod/pytorch:2.0.0-py3.10-cuda11.8.0-devel",
            name="test-pod",
            gpu_type_ids=["NVIDIA RTX A4000"],
            container_disk_in_gb=50,
        )
        pod = pod_client.create_pod(params)

        assert pod.id == "pod123"
        assert pod.name == "test-pod"
        assert pod.gpu is not None
        assert pod.gpu.id == "NVIDIA RTX A4000"

    def test_create_pod_sends_correct_body(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
        sample_pod_response: dict,
    ):
        """Verify request body has camelCase keys."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/pods",
            json=sample_pod_response,
        )

        params = PodCreateInput(
            image_name="test-image",
            gpu_type_ids=["A4000"],
            container_disk_in_gb=100,
        )
        pod_client.create_pod(params)

        request = httpx_mock.get_request()
        import json

        body = json.loads(request.content)
        assert "imageName" in body
        assert "gpuTypeIds" in body
        assert "containerDiskInGb" in body


class TestListPods:
    """Tests for list_pods method."""

    def test_list_pods_no_filters(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
        sample_pod_list_response: list,
    ):
        """List all pods without filters."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/pods",
            json=sample_pod_list_response,
        )

        pods = pod_client.list_pods()

        assert len(pods) == 2
        assert pods[0].id == "pod123"
        assert pods[1].id == "pod456"

    def test_list_pods_with_filters(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
        sample_pod_list_response: list,
    ):
        """List pods with filters applied."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/pods?desiredStatus=RUNNING&includeMachine=true",
            json=[sample_pod_list_response[0]],
        )

        filters = PodListFilters(
            desired_status="RUNNING",
            include_machine=True,
        )
        pods = pod_client.list_pods(filters)

        assert len(pods) == 1
        assert pods[0].desired_status == "RUNNING"

    def test_list_pods_empty_response(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """Handle empty pod list."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/pods",
            json=[],
        )

        pods = pod_client.list_pods()
        assert pods == []


class TestGetPod:
    """Tests for get_pod method."""

    def test_get_pod_success(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
        sample_pod_response: dict,
    ):
        """Get pod by ID."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/pods/pod123",
            json=sample_pod_response,
        )

        pod = pod_client.get_pod("pod123")

        assert pod.id == "pod123"
        assert pod.name == "test-pod"

    def test_get_pod_with_includes(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
        sample_pod_response: dict,
    ):
        """Get pod with include flags."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/pods/pod123?includeMachine=true&includeTemplate=true",
            json=sample_pod_response,
        )

        pod = pod_client.get_pod("pod123", include_machine=True, include_template=True)
        assert pod.id == "pod123"

    def test_get_pod_not_found(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """404 raises RunPodNotFoundError."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/pods/nonexistent",
            status_code=404,
        )

        with pytest.raises(RunPodNotFoundError):
            pod_client.get_pod("nonexistent")


class TestUpdatePod:
    """Tests for update_pod method."""

    def test_update_pod_success(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
        sample_pod_response: dict,
    ):
        """Update pod configuration."""
        updated_response = {**sample_pod_response, "name": "updated-name"}
        httpx_mock.add_response(
            method="PATCH",
            url="https://rest.runpod.io/v1/pods/pod123",
            json=updated_response,
        )

        params = PodUpdateInput(name="updated-name")
        pod = pod_client.update_pod("pod123", params)

        assert pod.name == "updated-name"


class TestDeletePod:
    """Tests for delete_pod method."""

    def test_delete_pod_success(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """Delete pod successfully."""
        httpx_mock.add_response(
            method="DELETE",
            url="https://rest.runpod.io/v1/pods/pod123",
            status_code=204,
        )

        pod_client.delete_pod("pod123")  # Should not raise


class TestPodLifecycle:
    """Tests for start/stop/restart methods."""

    def test_start_pod(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """Start a stopped pod."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/pods/pod123/start",
            status_code=200,
            json={},
        )

        pod_client.start_pod("pod123")  # Should not raise

    def test_stop_pod(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """Stop a running pod."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/pods/pod123/stop",
            status_code=200,
            json={},
        )

        pod_client.stop_pod("pod123")  # Should not raise

    def test_restart_pod(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """Restart a pod."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/pods/pod123/restart",
            status_code=200,
            json={},
        )

        pod_client.restart_pod("pod123")  # Should not raise


class TestErrorHandling:
    """Tests for error handling."""

    def test_authentication_error(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """401 raises RunPodAuthenticationError."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/pods",
            status_code=401,
            json={"error": "Invalid API key"},
        )

        with pytest.raises(RunPodAuthenticationError):
            pod_client.list_pods()

    def test_validation_error(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """400 raises RunPodValidationError."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/pods",
            status_code=400,
            json={"error": "Invalid image name"},
        )

        with pytest.raises(RunPodValidationError, match="Invalid image name"):
            params = PodCreateInput(image_name="invalid")
            pod_client.create_pod(params)

    def test_connection_error(
        self,
        pod_client: PodClient,
        httpx_mock: HTTPXMock,
    ):
        """Network errors raise RunPodConnectionError."""
        import httpx

        httpx_mock.add_exception(httpx.ConnectError("Connection refused"))

        with pytest.raises(RunPodConnectionError):
            pod_client.list_pods()
