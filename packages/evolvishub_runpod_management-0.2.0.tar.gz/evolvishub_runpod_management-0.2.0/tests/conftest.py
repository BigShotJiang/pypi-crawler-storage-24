"""Shared test fixtures for RunPod client tests."""

import pytest

from evolvishub_runpod_management.clients import AccountInfoClient, ContainerRegistryAuthClient, PodClient
from evolvishub_runpod_management.config import RunPodConfig


@pytest.fixture
def mock_api_key() -> str:
    """Test API key."""
    return "test_api_key_12345"


@pytest.fixture
def config(mock_api_key: str) -> RunPodConfig:
    """Test configuration."""
    return RunPodConfig(
        api_key=mock_api_key,
        base_url="https://rest.runpod.io/v1",
        request_timeout=30.0,
    )


@pytest.fixture
def pod_client(config: RunPodConfig) -> PodClient:
    """Test pod client instance."""
    return PodClient(config)


@pytest.fixture
def container_reg_auth_client(config: RunPodConfig) -> ContainerRegistryAuthClient:
    """Test container registry auth client instance."""
    return ContainerRegistryAuthClient(config)


@pytest.fixture
def account_client(config: RunPodConfig) -> AccountInfoClient:
    """Test account info client instance."""
    return AccountInfoClient(config)


@pytest.fixture
def sample_account_balance_response() -> dict:
    """Sample GraphQL myself response payload."""
    return {
        "data": {
            "myself": {
                "id": "user_abc123",
                "currentSpendPerHr": 0.44,
                "machineQuota": 10,
                "referralEarned": 5.0,
                "signedTermsOfService": True,
                "clientBalance": 42.75,
            }
        }
    }


# Backward compatibility alias
@pytest.fixture
def client(pod_client: PodClient) -> PodClient:
    """Test client instance (backward compatibility)."""
    return pod_client


@pytest.fixture
def sample_pod_response() -> dict:
    """Sample pod API response."""
    return {
        "id": "pod123",
        "name": "test-pod",
        "image": "runpod/pytorch:2.0.0-py3.10-cuda11.8.0-devel",
        "desiredStatus": "RUNNING",
        "costPerHr": 0.44,
        "adjustedCostPerHr": 0.44,
        "containerDiskInGb": 50,
        "volumeInGb": 20,
        "volumeMountPath": "/workspace",
        "vcpuCount": 8,
        "memoryInGb": 32.0,
        "publicIp": "123.45.67.89",
        "ports": ["8888/http", "22/tcp"],
        "portMappings": {"8888": 18888, "22": 10022},
        "interruptible": False,
        "locked": False,
        "env": {"JUPYTER_PASSWORD": "secret"},
        "gpu": {
            "id": "NVIDIA RTX A4000",
            "count": 1,
            "gpuUtilizationPercent": 45.2,
            "memoryUtilizationPercent": 30.5,
        },
        "machineId": "machine456",
        "lastStartedAt": "2024-01-15T10:30:00Z",
        "lastStatusChange": "2024-01-15T10:30:00Z",
        "dataCenterId": "US-OR-1",
        "cloudType": "SECURE",
        "computeType": "GPU",
        "createdAt": "2024-01-15T10:00:00Z",
        "gpuCount": 1,
    }


@pytest.fixture
def sample_pod_list_response(sample_pod_response: dict) -> list[dict]:
    """Sample pod list API response."""
    return [
        sample_pod_response,
        {
            "id": "pod456",
            "name": "another-pod",
            "image": "runpod/stable-diffusion:v1",
            "desiredStatus": "EXITED",
            "costPerHr": 0.89,
            "containerDiskInGb": 100,
            "volumeInGb": 50,
            "vcpuCount": 16,
            "memoryInGb": 64.0,
            "interruptible": True,
            "gpu": {
                "id": "NVIDIA RTX A5000",
                "count": 2,
            },
            "computeType": "GPU",
        },
    ]


@pytest.fixture
def sample_container_reg_auth_response() -> dict:
    """Sample container registry auth API response."""
    return {
        "id": "auth123",
        "name": "my-docker-hub",
    }


@pytest.fixture
def sample_container_reg_auth_list_response() -> list[dict]:
    """Sample container registry auth list API response."""
    return [
        {"id": "auth123", "name": "my-docker-hub"},
        {"id": "auth456", "name": "my-gcr"},
    ]
