"""Tests for AccountInfoClient."""

import pytest
from pytest_httpx import HTTPXMock

from evolvishub_runpod_management.clients import AccountInfoClient
from evolvishub_runpod_management.config import RunPodConfig
from evolvishub_runpod_management.exceptions import (
    RunPodAuthenticationError,
    RunPodConnectionError,
    RunPodError,
)
from evolvishub_runpod_management.models.account import AccountBalance

GRAPHQL_URL = "https://api.runpod.io/graphql"


class TestAccountInfoClientInit:
    """Tests for client initialisation."""

    def test_create_with_config(self, config: RunPodConfig):
        """Create client directly from config."""
        client = AccountInfoClient(config)
        assert client._config == config

    def test_initialize_factory(self, mock_api_key: str):
        """Initialize using the inherited factory method."""
        client = AccountInfoClient.initialize(
            api_key=mock_api_key,
            base_url="https://rest.runpod.io/v1",
        )
        assert client._config.api_key == mock_api_key

    def test_context_manager(self, config: RunPodConfig):
        """Client supports context manager protocol."""
        with AccountInfoClient(config) as client:
            assert isinstance(client, AccountInfoClient)

    def test_graphql_url_constant(self):
        """GRAPHQL_URL points to the RunPod GraphQL endpoint."""
        assert AccountInfoClient.GRAPHQL_URL == "https://api.runpod.io/graphql"


class TestGetBalance:
    """Tests for get_balance()."""

    def test_get_balance_success(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
        sample_account_balance_response: dict,
    ):
        """Successfully parse a full balance response."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            json=sample_account_balance_response,
        )

        balance = account_client.get_balance()

        assert isinstance(balance, AccountBalance)
        assert balance.id == "user_abc123"
        assert balance.credit_balance == 42.75
        assert balance.current_spend_per_hr == 0.44
        assert balance.machine_quota == 10
        assert balance.referral_earned == 5.0
        assert balance.signed_terms_of_service is True

    def test_get_balance_sends_graphql_query(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
        sample_account_balance_response: dict,
    ):
        """Request body must contain a GraphQL query string."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            json=sample_account_balance_response,
        )

        account_client.get_balance()

        import json
        request = httpx_mock.get_request()
        body = json.loads(request.content)
        assert "query" in body
        assert "myself" in body["query"]

    def test_get_balance_partial_fields(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
    ):
        """Missing optional fields default to None."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            json={"data": {"myself": {"id": "user_xyz"}}},
        )

        balance = account_client.get_balance()

        assert balance.id == "user_xyz"
        assert balance.credit_balance is None
        assert balance.current_spend_per_hr is None

    def test_get_balance_graphql_errors(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
    ):
        """GraphQL-level errors raise RunPodError."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            json={"errors": [{"message": "Unauthorized"}]},
        )

        with pytest.raises(RunPodError, match="GraphQL errors"):
            account_client.get_balance()

    def test_get_balance_authentication_error(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
    ):
        """HTTP 401 raises RunPodAuthenticationError."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            status_code=401,
        )

        with pytest.raises(RunPodAuthenticationError):
            account_client.get_balance()

    def test_get_balance_http_error(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
    ):
        """Non-401 HTTP errors raise RunPodError."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            status_code=500,
            json={"error": "Internal server error"},
        )

        with pytest.raises(RunPodError):
            account_client.get_balance()

    def test_get_balance_connection_error(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
    ):
        """Network errors raise RunPodConnectionError."""
        import httpx

        httpx_mock.add_exception(httpx.ConnectError("Connection refused"))

        with pytest.raises(RunPodConnectionError):
            account_client.get_balance()

    def test_get_balance_timeout(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
    ):
        """Timeout raises RunPodConnectionError."""
        import httpx

        httpx_mock.add_exception(httpx.TimeoutException("timed out"))

        with pytest.raises(RunPodConnectionError):
            account_client.get_balance()


class TestGetCreditBalance:
    """Tests for get_credit_balance()."""

    def test_get_credit_balance_success(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
        sample_account_balance_response: dict,
    ):
        """Returns credit balance as a float."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            json=sample_account_balance_response,
        )

        credit = account_client.get_credit_balance()

        assert credit == 42.75
        assert isinstance(credit, float)

    def test_get_credit_balance_defaults_to_zero(
        self,
        account_client: AccountInfoClient,
        httpx_mock: HTTPXMock,
    ):
        """Returns 0.0 when creditBalance is absent."""
        httpx_mock.add_response(
            method="POST",
            url=GRAPHQL_URL,
            json={"data": {"myself": {"id": "user_xyz"}}},
        )

        credit = account_client.get_credit_balance()

        assert credit == 0.0


class TestAccountBalanceModel:
    """Tests for AccountBalance pydantic model."""

    def test_camel_case_alias_parsing(self):
        """Model validates camelCase keys from the API."""
        data = {
            "id": "u1",
            "currentSpendPerHr": 1.23,
            "machineQuota": 5,
            "referralEarned": 10.0,
            "signedTermsOfService": True,
            "clientBalance": 99.99,
        }

        balance = AccountBalance.model_validate(data)

        assert balance.current_spend_per_hr == 1.23
        assert balance.machine_quota == 5
        assert balance.referral_earned == 10.0
        assert balance.signed_terms_of_service is True
        assert balance.credit_balance == 99.99

    def test_snake_case_construction(self):
        """Model can also be constructed with snake_case via populate_by_name."""
        balance = AccountBalance(
            id="u2",
            credit_balance=50.0,
            current_spend_per_hr=0.5,
        )

        assert balance.credit_balance == 50.0
        assert balance.current_spend_per_hr == 0.5

    def test_all_fields_optional_except_none(self):
        """All fields are optional — empty dict yields all-None model."""
        balance = AccountBalance.model_validate({})

        assert balance.id is None
        assert balance.credit_balance is None
        assert balance.current_spend_per_hr is None
        assert balance.machine_quota is None
        assert balance.referral_earned is None
        assert balance.signed_terms_of_service is None
