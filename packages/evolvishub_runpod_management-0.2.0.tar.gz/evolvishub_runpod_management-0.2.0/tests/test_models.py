"""Tests for Pydantic models."""

import pytest

from evolvishub_runpod_management.models.container_reg_auth import (
    ContainerRegistryAuth,
    ContainerRegistryAuthCreateInput,
)
from evolvishub_runpod_management.models.pods import GpuInfo, Pod, PodCreateInput, PodListFilters, PodUpdateInput


class TestGpuInfo:
    """Tests for GpuInfo model."""

    def test_parse_full_gpu_info(self):
        """Parse complete GPU info."""
        data = {
            "id": "NVIDIA RTX A4000",
            "count": 2,
            "gpuUtilizationPercent": 75.5,
            "memoryUtilizationPercent": 50.0,
        }
        gpu = GpuInfo.model_validate(data)
        assert gpu.id == "NVIDIA RTX A4000"
        assert gpu.count == 2
        assert gpu.gpu_utilization_percent == 75.5
        assert gpu.memory_utilization_percent == 50.0

    def test_parse_minimal_gpu_info(self):
        """Parse GPU info with only ID."""
        gpu = GpuInfo.model_validate({"id": "NVIDIA A100"})
        assert gpu.id == "NVIDIA A100"
        assert gpu.count is None


class TestPod:
    """Tests for Pod response model."""

    def test_parse_full_pod_response(self, sample_pod_response: dict):
        """Parse complete pod API response."""
        pod = Pod.model_validate(sample_pod_response)

        assert pod.id == "pod123"
        assert pod.name == "test-pod"
        assert pod.image == "runpod/pytorch:2.0.0-py3.10-cuda11.8.0-devel"
        assert pod.desired_status == "RUNNING"
        assert pod.cost_per_hr == 0.44
        assert pod.container_disk_in_gb == 50
        assert pod.volume_in_gb == 20
        assert pod.volume_mount_path == "/workspace"
        assert pod.vcpu_count == 8
        assert pod.memory_in_gb == 32.0
        assert pod.public_ip == "123.45.67.89"
        assert pod.ports == ["8888/http", "22/tcp"]
        assert pod.interruptible is False
        assert pod.locked is False
        assert pod.env == {"JUPYTER_PASSWORD": "secret"}
        assert pod.gpu is not None
        assert pod.gpu.id == "NVIDIA RTX A4000"
        assert pod.gpu.count == 1
        assert pod.machine_id == "machine456"
        assert pod.data_center_id == "US-OR-1"
        assert pod.cloud_type == "SECURE"
        assert pod.compute_type == "GPU"

    def test_parse_minimal_pod_response(self):
        """Parse minimal pod response with only required fields."""
        pod = Pod.model_validate({"id": "pod789"})
        assert pod.id == "pod789"
        assert pod.name is None
        assert pod.gpu is None


class TestPodCreateInput:
    """Tests for PodCreateInput model."""

    def test_minimal_create_input(self):
        """Create input with only required field."""
        params = PodCreateInput(image_name="runpod/pytorch:latest")
        assert params.image_name == "runpod/pytorch:latest"
        assert params.gpu_count >= 1

    def test_full_create_input(self):
        """Create input with all fields."""
        params = PodCreateInput(
            image_name="runpod/pytorch:2.0",
            name="my-pod",
            gpu_type_ids=["NVIDIA RTX A4000", "NVIDIA RTX A5000"],
            gpu_count=2,
            container_disk_in_gb=100,
            volume_in_gb=50,
            volume_mount_path="/data",
            ports=["8888/http", "22/tcp"],
            env={"KEY": "value"},
            interruptible=True,
            cloud_type="SECURE",
        )
        assert params.name == "my-pod"
        assert params.gpu_count == 2
        assert params.interruptible is True

    def test_to_api_dict(self):
        """Convert to API dictionary with camelCase."""
        params = PodCreateInput(
            image_name="test-image",
            gpu_type_ids=["A4000"],
            container_disk_in_gb=50,
            volume_mount_path="/workspace",
        )
        api_dict = params.to_api_dict()

        assert api_dict["imageName"] == "test-image"
        assert api_dict["gpuTypeIds"] == ["A4000"]
        assert api_dict["containerDiskInGb"] == 50
        assert api_dict["volumeMountPath"] == "/workspace"
        assert "interruptible" not in api_dict  # None values excluded

    def test_create_input_alias_assignment(self):
        """Can assign using either snake_case or camelCase."""
        # Using snake_case (preferred in Python)
        params1 = PodCreateInput(image_name="img1", gpu_type_ids=["A4000"])
        assert params1.gpu_type_ids == ["A4000"]

        # Using alias (camelCase from API)
        params2 = PodCreateInput.model_validate({
            "imageName": "img2",
            "gpuTypeIds": ["A5000"],
        })
        assert params2.gpu_type_ids == ["A5000"]


class TestPodUpdateInput:
    """Tests for PodUpdateInput model."""

    def test_update_single_field(self):
        """Update with single field."""
        params = PodUpdateInput(name="new-name")
        api_dict = params.to_api_dict()
        assert api_dict == {"name": "new-name"}

    def test_update_multiple_fields(self):
        """Update with multiple fields."""
        params = PodUpdateInput(
            name="updated-pod",
            container_disk_in_gb=200,
            env={"NEW_VAR": "value"},
            locked=True,
        )
        api_dict = params.to_api_dict()

        assert api_dict["name"] == "updated-pod"
        assert api_dict["containerDiskInGb"] == 200
        assert api_dict["env"] == {"NEW_VAR": "value"}
        assert api_dict["locked"] is True


class TestPodListFilters:
    """Tests for PodListFilters model."""

    def test_empty_filters(self):
        """Empty filters produce minimal query params."""
        filters = PodListFilters()
        params = filters.to_query_params()
        assert params == {}

    def test_single_filter(self):
        """Single filter value."""
        filters = PodListFilters(desired_status="RUNNING")
        params = filters.to_query_params()
        assert params == {"desiredStatus": "RUNNING"}

    def test_list_filter(self):
        """List values joined with commas."""
        filters = PodListFilters(gpu_type_id=["A4000", "A5000"])
        params = filters.to_query_params()
        assert params == {"gpuTypeId": "A4000,A5000"}

    def test_include_flags(self):
        """Include flags only added when True."""
        filters = PodListFilters(
            include_machine=True,
            include_network_volume=False,
            include_template=True,
        )
        params = filters.to_query_params()

        assert params["includeMachine"] == "true"
        assert params["includeTemplate"] == "true"
        assert "includeNetworkVolume" not in params
        assert "includeSavingsPlans" not in params

    def test_combined_filters(self):
        """Multiple filter types combined."""
        filters = PodListFilters(
            compute_type="GPU",
            desired_status="RUNNING",
            data_center_id=["US-OR-1", "US-TX-1"],
            include_machine=True,
        )
        params = filters.to_query_params()

        assert params["computeType"] == "GPU"
        assert params["desiredStatus"] == "RUNNING"
        assert params["dataCenterId"] == "US-OR-1,US-TX-1"
        assert params["includeMachine"] == "true"


class TestContainerRegistryAuth:
    """Tests for ContainerRegistryAuth response model."""

    def test_parse_response(self, sample_container_reg_auth_response: dict):
        """Parse container registry auth API response."""
        auth = ContainerRegistryAuth.model_validate(sample_container_reg_auth_response)
        assert auth.id == "auth123"
        assert auth.name == "my-docker-hub"


class TestContainerRegistryAuthCreateInput:
    """Tests for ContainerRegistryAuthCreateInput model."""

    def test_create_input(self):
        """Create input with all required fields."""
        params = ContainerRegistryAuthCreateInput(
            name="my-registry",
            username="user123",
            password="secret456",
        )
        assert params.name == "my-registry"
        assert params.username == "user123"
        assert params.password == "secret456"

    def test_to_api_dict(self):
        """Convert to API dictionary."""
        params = ContainerRegistryAuthCreateInput(
            name="dockerhub",
            username="myuser",
            password="mypass",
        )
        api_dict = params.to_api_dict()

        assert api_dict == {
            "name": "dockerhub",
            "username": "myuser",
            "password": "mypass",
        }
