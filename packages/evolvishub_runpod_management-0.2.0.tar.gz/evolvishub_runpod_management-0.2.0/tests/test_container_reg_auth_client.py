"""Tests for ContainerRegistryAuthClient."""

import pytest
from pytest_httpx import HTTPXMock

from evolvishub_runpod_management.clients import ContainerRegistryAuthClient
from evolvishub_runpod_management.config import RunPodConfig
from evolvishub_runpod_management.exceptions import (
    RunPodAuthenticationError,
    RunPodNotFoundError,
    RunPodValidationError,
)
from evolvishub_runpod_management.models.container_reg_auth import ContainerRegistryAuthCreateInput


class TestContainerRegistryAuthClientInit:
    """Tests for client initialization."""

    def test_create_with_config(self, config: RunPodConfig):
        """Create client with config object."""
        client = ContainerRegistryAuthClient(config)
        assert client._config == config

    def test_initialize_factory(self, mock_api_key: str):
        """Initialize using factory method."""
        client = ContainerRegistryAuthClient.initialize(
            api_key=mock_api_key,
            base_url="https://custom.api.com",
            request_timeout=60.0,
        )
        assert client._config.api_key == mock_api_key
        assert client._config.base_url == "https://custom.api.com"

    def test_context_manager(self, config: RunPodConfig):
        """Client works as context manager."""
        with ContainerRegistryAuthClient(config) as client:
            assert isinstance(client, ContainerRegistryAuthClient)


class TestCreate:
    """Tests for create method."""

    def test_create_success(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
        sample_container_reg_auth_response: dict,
    ):
        """Successfully create a container registry auth."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/containerregistryauth",
            json=sample_container_reg_auth_response,
        )

        params = ContainerRegistryAuthCreateInput(
            name="my-docker-hub",
            username="myuser",
            password="mypassword",
        )
        auth = container_reg_auth_client.create(params)

        assert auth.id == "auth123"
        assert auth.name == "my-docker-hub"

    def test_create_sends_correct_body(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
        sample_container_reg_auth_response: dict,
    ):
        """Verify request body has correct keys."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/containerregistryauth",
            json=sample_container_reg_auth_response,
        )

        params = ContainerRegistryAuthCreateInput(
            name="test-registry",
            username="user",
            password="pass",
        )
        container_reg_auth_client.create(params)

        request = httpx_mock.get_request()
        import json

        body = json.loads(request.content)
        assert body["name"] == "test-registry"
        assert body["username"] == "user"
        assert body["password"] == "pass"

    def test_create_validation_error(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
    ):
        """400 raises RunPodValidationError."""
        httpx_mock.add_response(
            method="POST",
            url="https://rest.runpod.io/v1/containerregistryauth",
            status_code=400,
            json={"error": "Name already exists"},
        )

        params = ContainerRegistryAuthCreateInput(
            name="duplicate",
            username="user",
            password="pass",
        )
        with pytest.raises(RunPodValidationError, match="Name already exists"):
            container_reg_auth_client.create(params)


class TestList:
    """Tests for list method."""

    def test_list_success(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
        sample_container_reg_auth_list_response: list,
    ):
        """List all container registry auths."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/containerregistryauth",
            json=sample_container_reg_auth_list_response,
        )

        auths = container_reg_auth_client.list()

        assert len(auths) == 2
        assert auths[0].id == "auth123"
        assert auths[0].name == "my-docker-hub"
        assert auths[1].id == "auth456"
        assert auths[1].name == "my-gcr"

    def test_list_empty(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
    ):
        """Handle empty list response."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/containerregistryauth",
            json=[],
        )

        auths = container_reg_auth_client.list()
        assert auths == []


class TestGet:
    """Tests for get method."""

    def test_get_success(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
        sample_container_reg_auth_response: dict,
    ):
        """Get container registry auth by ID."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/containerregistryauth/auth123",
            json=sample_container_reg_auth_response,
        )

        auth = container_reg_auth_client.get("auth123")

        assert auth.id == "auth123"
        assert auth.name == "my-docker-hub"

    def test_get_not_found(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
    ):
        """404 raises RunPodNotFoundError."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/containerregistryauth/nonexistent",
            status_code=404,
        )

        with pytest.raises(RunPodNotFoundError):
            container_reg_auth_client.get("nonexistent")


class TestDelete:
    """Tests for delete method."""

    def test_delete_success(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
    ):
        """Delete container registry auth successfully."""
        httpx_mock.add_response(
            method="DELETE",
            url="https://rest.runpod.io/v1/containerregistryauth/auth123",
            status_code=204,
        )

        container_reg_auth_client.delete("auth123")  # Should not raise

    def test_delete_not_found(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
    ):
        """404 raises RunPodNotFoundError."""
        httpx_mock.add_response(
            method="DELETE",
            url="https://rest.runpod.io/v1/containerregistryauth/nonexistent",
            status_code=404,
        )

        with pytest.raises(RunPodNotFoundError):
            container_reg_auth_client.delete("nonexistent")


class TestErrorHandling:
    """Tests for error handling."""

    def test_authentication_error(
        self,
        container_reg_auth_client: ContainerRegistryAuthClient,
        httpx_mock: HTTPXMock,
    ):
        """401 raises RunPodAuthenticationError."""
        httpx_mock.add_response(
            method="GET",
            url="https://rest.runpod.io/v1/containerregistryauth",
            status_code=401,
            json={"error": "Invalid API key"},
        )

        with pytest.raises(RunPodAuthenticationError):
            container_reg_auth_client.list()
