# RunPod Management Client - Usage Guide

## Installation

```bash
# From source
pip install -e .

# With development dependencies
pip install -e ".[dev]"
```

## Configuration

### Environment Variables

Create a `.env` file in your project root:

```bash
cp docs/.env.example .env
```

Edit `.env` and add your API key:

```
RUNPOD_API_KEY=your_api_key_here
```

### Programmatic Configuration

```python
from evolvishub_runpod_management import AccountInfoClient, PodClient, ContainerRegistryAuthClient

# Load from .env file (recommended)
account_client = AccountInfoClient.initialize()
pod_client = PodClient.initialize()
auth_client = ContainerRegistryAuthClient.initialize()

# Or provide credentials directly
pod_client = PodClient.initialize(
    api_key="your_api_key",
    base_url="https://rest.runpod.io/v1",  # optional
    request_timeout=60.0,  # optional, seconds
)

# Or use config object
from evolvishub_runpod_management import RunPodConfig

config = RunPodConfig(
    api_key="your_api_key",
    base_url="https://rest.runpod.io/v1",
    request_timeout=30.0,
)
pod_client = PodClient(config)
auth_client = ContainerRegistryAuthClient(config)
```

## Quick Start

### Account Information

```python
from evolvishub_runpod_management import AccountInfoClient

with AccountInfoClient.initialize() as client:
    # Full balance object
    balance = client.get_balance()
    print(f"Credit balance: ${balance.credit_balance}")
    print(f"Current spend/hr: ${balance.current_spend_per_hr}")

    # Convenience helper — credit balance as a plain float
    credit = client.get_credit_balance()
    print(f"${credit:.2f} remaining")
```

### Pod Management

```python
from evolvishub_runpod_management import PodClient, PodCreateInput

# Initialize client
with PodClient.initialize() as client:
    # Create a GPU pod
    pod = client.create_pod(PodCreateInput(
        image_name="runpod/pytorch:2.0.0-py3.10-cuda11.8.0-devel",
        name="my-training-pod",
        gpu_type_ids=["NVIDIA RTX A4000", "NVIDIA RTX A5000"],
        gpu_count=1,
        container_disk_in_gb=50,
        volume_in_gb=20,
        ports=["8888/http", "22/tcp"],
        env={"JUPYTER_PASSWORD": "secret123"},
    ))

    print(f"Created pod: {pod.id}")
    print(f"Status: {pod.desired_status}")
    print(f"Cost: ${pod.cost_per_hr}/hr")
```

### Container Registry Auth Management

```python
from evolvishub_runpod_management import ContainerRegistryAuthClient, ContainerRegistryAuthCreateInput

with ContainerRegistryAuthClient.initialize() as client:
    # Create credentials for private registry
    auth = client.create(ContainerRegistryAuthCreateInput(
        name="my-docker-hub",
        username="myuser",
        password="mypassword",
    ))
    print(f"Created: {auth.id}")

    # List all credentials
    for a in client.list():
        print(f"{a.id}: {a.name}")
```

---

## Account Info Client API Reference

> Uses the RunPod GraphQL API (`https://api.runpod.io/graphql`).

### Get Balance

```python
from evolvishub_runpod_management import AccountInfoClient

with AccountInfoClient.initialize() as client:
    balance = client.get_balance()
    print(balance.id)                    # Account ID
    print(balance.credit_balance)        # float | None - USD credit remaining
    print(balance.current_spend_per_hr)  # float | None - active spend rate
    print(balance.machine_quota)         # int   | None - max concurrent machines
    print(balance.referral_earned)       # float | None - referral credit earned
    print(balance.signed_terms_of_service)  # bool | None
```

### Get Credit Balance

```python
credit: float = client.get_credit_balance()
print(f"${credit:.2f} remaining")
```

---

## Pod Client API Reference

### Create Pod

```python
from evolvishub_runpod_management import PodCreateInput

params = PodCreateInput(
    # Required
    image_name="runpod/pytorch:2.0.0-py3.10-cuda11.8.0-devel",

    # Hardware (GPU)
    gpu_type_ids=["NVIDIA RTX A4000"],  # Priority order
    gpu_count=1,
    min_vcpu_per_gpu=2,
    min_ram_per_gpu=8,

    # Hardware (CPU) - use instead of GPU fields for CPU pods
    # compute_type="CPU",
    # cpu_flavor_ids=["cpu3c"],
    # vcpu_count=4,

    # Storage
    container_disk_in_gb=50,
    volume_in_gb=20,
    volume_mount_path="/workspace",
    # network_volume_id="vol_xxx",  # Attach existing volume

    # Networking
    ports=["8888/http", "22/tcp"],
    # global_networking=True,
    # support_public_ip=True,

    # Location
    cloud_type="SECURE",  # or "COMMUNITY"
    # data_center_ids=["US-OR-1"],
    # country_codes=["US"],

    # Container
    name="my-pod",
    # docker_entrypoint=["/bin/bash"],
    # docker_start_cmd=["-c", "sleep infinity"],
    env={"KEY": "value"},
    # template_id="tpl_xxx",
    # container_registry_auth_id="auth_xxx",  # For private images

    # Behavior
    interruptible=False,  # Spot pricing
    locked=False,  # Prevent stop/reset
)

pod = client.create_pod(params)
```

### List Pods

```python
from evolvishub_runpod_management import PodListFilters

# List all pods
pods = client.list_pods()

# List with filters
pods = client.list_pods(PodListFilters(
    compute_type="GPU",
    desired_status="RUNNING",
    gpu_type_id=["NVIDIA RTX A4000"],
    data_center_id=["US-OR-1", "US-TX-1"],
    name="my-pod",
    include_machine=True,
    include_network_volume=True,
))

for pod in pods:
    print(f"{pod.id}: {pod.name} - {pod.desired_status}")
```

### Get Pod

```python
# Basic fetch
pod = client.get_pod("pod_xxx")

# With additional details
pod = client.get_pod(
    "pod_xxx",
    include_machine=True,
    include_network_volume=True,
    include_savings_plans=True,
    include_template=True,
)

print(f"Pod: {pod.name}")
print(f"Image: {pod.image}")
print(f"GPU: {pod.gpu.id if pod.gpu else 'N/A'}")
print(f"IP: {pod.public_ip}")
```

### Update Pod

```python
from evolvishub_runpod_management import PodUpdateInput

pod = client.update_pod("pod_xxx", PodUpdateInput(
    name="new-name",
    container_disk_in_gb=100,
    env={"NEW_VAR": "value"},
    locked=True,
))
```

### Delete Pod

```python
client.delete_pod("pod_xxx")
```

### Pod Lifecycle

```python
# Stop a running pod (preserves data)
client.stop_pod("pod_xxx")

# Start a stopped pod
client.start_pod("pod_xxx")

# Restart a pod
client.restart_pod("pod_xxx")
```

---

## Container Registry Auth Client API Reference

### Create Container Registry Auth

```python
from evolvishub_runpod_management import ContainerRegistryAuthCreateInput

params = ContainerRegistryAuthCreateInput(
    name="my-docker-hub",      # Unique name for this credential
    username="myuser",          # Registry username
    password="mypassword",      # Registry password or token
)

auth = client.create(params)
print(f"Created: {auth.id}, {auth.name}")
```

### List Container Registry Auths

```python
auths = client.list()

for auth in auths:
    print(f"{auth.id}: {auth.name}")
```

### Get Container Registry Auth

```python
auth = client.get("auth_xxx")
print(f"ID: {auth.id}, Name: {auth.name}")
```

### Delete Container Registry Auth

```python
client.delete("auth_xxx")
```

---

## Error Handling

```python
from evolvishub_runpod_management import (
    PodClient,
    RunPodError,
    RunPodAuthenticationError,
    RunPodValidationError,
    RunPodNotFoundError,
    RunPodConnectionError,
)

try:
    pod = client.get_pod("invalid_id")
except RunPodNotFoundError:
    print("Pod not found")
except RunPodAuthenticationError:
    print("Invalid API key")
except RunPodValidationError as e:
    print(f"Invalid request: {e.message}")
except RunPodConnectionError as e:
    print(f"Network error: {e.message}")
except RunPodError as e:
    print(f"API error ({e.status_code}): {e.message}")
```

---

## Data Models

### AccountBalance

```python
balance.id                       # str | None - Account identifier
balance.credit_balance           # float | None - USD credit remaining
balance.current_spend_per_hr     # float | None - Active hourly spend rate
balance.machine_quota            # int | None - Max concurrent machines allowed
balance.referral_earned          # float | None - Referral credit earned
balance.signed_terms_of_service  # bool | None - ToS acceptance status
```

### Pod Response

All pod API methods return `Pod` objects with these fields:

```python
pod.id                    # str - Pod identifier
pod.name                  # str | None - Pod name
pod.image                 # str | None - Docker image
pod.desired_status        # str | None - RUNNING, EXITED, TERMINATED
pod.cost_per_hr           # float | None - Hourly cost
pod.container_disk_in_gb  # int | None - Container disk size
pod.volume_in_gb          # int | None - Persistent volume size
pod.volume_mount_path     # str | None - Mount path
pod.vcpu_count            # int | None - vCPU count
pod.memory_in_gb          # float | None - RAM in GB
pod.public_ip             # str | None - Public IP address
pod.ports                 # list[str] | None - Exposed ports
pod.port_mappings         # dict | None - Port mappings
pod.interruptible         # bool | None - Spot pricing
pod.locked                # bool | None - Locked status
pod.env                   # dict | None - Environment variables
pod.gpu                   # GpuInfo | None - GPU details
pod.machine_id            # str | None - Machine identifier
pod.data_center_id        # str | None - Data center
pod.cloud_type            # str | None - SECURE or COMMUNITY
pod.compute_type          # str | None - GPU or CPU
pod.created_at            # str | None - Creation timestamp
```

### GpuInfo

```python
pod.gpu.id                        # str | None - GPU model
pod.gpu.count                     # int | None - Number of GPUs
pod.gpu.gpu_utilization_percent   # float | None - GPU usage %
pod.gpu.memory_utilization_percent # float | None - VRAM usage %
```

### ContainerRegistryAuth Response

```python
auth.id    # str - Unique identifier
auth.name  # str - User-defined name
```

---

## Context Manager

All clients support context manager protocol for automatic cleanup:

```python
with AccountInfoClient.initialize() as client:
    balance = client.get_balance()
    # Connection closed automatically

with PodClient.initialize() as client:
    pods = client.list_pods()
    # Connection closed automatically

with ContainerRegistryAuthClient.initialize() as client:
    auths = client.list()
    # Connection closed automatically
```

Or manually close:

```python
client = PodClient.initialize()
try:
    pods = client.list_pods()
finally:
    client.close()
```

---

## Backward Compatibility

`RunPodClient` is available as an alias for `PodClient`:

```python
from evolvishub_runpod_management import RunPodClient  # Same as PodClient

with RunPodClient.initialize() as client:
    pods = client.list_pods()
```
