"""Configuration management for RunPod client."""

import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field


class RunPodConfig(BaseModel):
    """Configuration for RunPod API client."""

    api_key: str = Field(description="RunPod API key")
    base_url: str = Field(
        default="https://rest.runpod.io/v1",
        description="RunPod API base URL",
    )
    request_timeout: float = Field(
        default=30.0,
        description="HTTP request timeout in seconds",
    )

    @classmethod
    def load(
        cls,
        api_key: str | None = None,
        base_url: str | None = None,
        request_timeout: float | None = None,
        env_file: str | Path = ".env",
    ) -> "RunPodConfig":
        """
        Load configuration from .env file with optional overrides.

        Priority (highest to lowest):
        1. Explicit parameters
        2. Environment variables
        3. .env file values
        4. Defaults

        Args:
            api_key: RunPod API key (overrides env)
            base_url: API base URL (overrides env)
            request_timeout: Request timeout in seconds (overrides env)
            env_file: Path to .env file

        Returns:
            RunPodConfig instance

        Raises:
            ValueError: If api_key is not provided and not in environment
        """
        env_path = Path(env_file) if isinstance(env_file, str) else env_file
        if env_path.exists():
            load_dotenv(env_path)

        resolved_api_key = api_key or os.getenv("RUNPOD_API_KEY")
        if not resolved_api_key:
            raise ValueError(
                "API key is required. Provide api_key parameter or set RUNPOD_API_KEY "
                "environment variable."
            )

        resolved_base_url = base_url or os.getenv(
            "RUNPOD_BASE_URL", "https://rest.runpod.io/v1"
        )

        resolved_timeout = request_timeout
        if resolved_timeout is None:
            timeout_str = os.getenv("RUNPOD_TIMEOUT")
            resolved_timeout = float(timeout_str) if timeout_str else 30.0

        return cls(
            api_key=resolved_api_key,
            base_url=resolved_base_url,
            request_timeout=resolved_timeout,
        )
