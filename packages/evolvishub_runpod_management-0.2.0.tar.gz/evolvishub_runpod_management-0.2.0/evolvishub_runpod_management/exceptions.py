"""Custom exception hierarchy for RunPod API errors."""


class RunPodError(Exception):
    """Base exception for all RunPod errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


class RunPodConnectionError(RunPodError):
    """Network/HTTP connection failure."""

    def __init__(self, message: str = "Failed to connect to RunPod API"):
        super().__init__(message)


class RunPodAuthenticationError(RunPodError):
    """401 Unauthorized - invalid API key."""

    def __init__(self, message: str = "Invalid or missing API key"):
        super().__init__(message, status_code=401)


class RunPodValidationError(RunPodError):
    """400 Bad Request - invalid input."""

    def __init__(self, message: str = "Invalid request parameters"):
        super().__init__(message, status_code=400)


class RunPodNotFoundError(RunPodError):
    """404 Not Found - pod doesn't exist."""

    def __init__(self, message: str = "Resource not found"):
        super().__init__(message, status_code=404)
