"""RunPod Management - Python client for RunPod Cloud REST API."""

from evolvishub_runpod_management.__version__ import __version__
from evolvishub_runpod_management.clients import AccountInfoClient, BaseClient, ContainerRegistryAuthClient, PodClient
from evolvishub_runpod_management.config import RunPodConfig
from evolvishub_runpod_management.exceptions import (
    RunPodAuthenticationError,
    RunPodConnectionError,
    RunPodError,
    RunPodNotFoundError,
    RunPodValidationError,
)
from evolvishub_runpod_management.models import (
    AccountBalance,
    ContainerRegistryAuth,
    ContainerRegistryAuthCreateInput,
    GpuInfo,
    Pod,
    PodCreateInput,
    PodListFilters,
    PodUpdateInput,
)

# Backward compatibility alias
RunPodClient = PodClient

__all__ = [
    "__version__",
    # Clients
    "BaseClient",
    "AccountInfoClient",
    "PodClient",
    "ContainerRegistryAuthClient",
    "RunPodClient",  # Backward compatibility
    # Config
    "RunPodConfig",
    # Exceptions
    "RunPodError",
    "RunPodConnectionError",
    "RunPodAuthenticationError",
    "RunPodValidationError",
    "RunPodNotFoundError",
    # Account models
    "AccountBalance",
    # Pod models
    "GpuInfo",
    "Pod",
    "PodCreateInput",
    "PodUpdateInput",
    "PodListFilters",
    # Container registry auth models
    "ContainerRegistryAuth",
    "ContainerRegistryAuthCreateInput",
]
