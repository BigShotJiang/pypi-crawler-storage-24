"""Container registry auth response model."""

from pydantic import BaseModel, ConfigDict


class ContainerRegistryAuth(BaseModel):
    """Container registry authentication response model."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
