"""Container registry auth create input model."""

from pydantic import BaseModel, ConfigDict, Field


class ContainerRegistryAuthCreateInput(BaseModel):
    """Parameters for POST /containerregistryauth - create a new container registry auth."""

    model_config = ConfigDict(populate_by_name=True)

    name: str = Field(description="A user-defined name for a container registry authentication. The name must be unique.")
    username: str
    password: str

    def to_api_dict(self) -> dict:
        """Convert to API-compatible dictionary."""
        return self.model_dump(exclude_none=True)
