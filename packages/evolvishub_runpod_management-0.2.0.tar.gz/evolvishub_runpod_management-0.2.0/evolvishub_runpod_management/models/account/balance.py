"""Account balance response model."""

from pydantic import BaseModel, ConfigDict, Field


class AccountBalance(BaseModel):
    """Account balance and usage information returned by the GraphQL API."""

    model_config = ConfigDict(populate_by_name=True)

    id: str | None = None
    current_spend_per_hr: float | None = Field(None, alias="currentSpendPerHr")
    machine_quota: int | None = Field(None, alias="machineQuota")
    referral_earned: float | None = Field(None, alias="referralEarned")
    signed_terms_of_service: bool | None = Field(None, alias="signedTermsOfService")
    credit_balance: float | None = Field(None, alias="clientBalance")
