"""Pod management client."""

from typing import Any

from evolvishub_runpod_management.clients.base import BaseClient
from evolvishub_runpod_management.models.pods import Pod, PodCreateInput, PodListFilters, PodUpdateInput


class PodClient(BaseClient):
    """REST client for RunPod pod lifecycle management."""

    def create_pod(self, params: PodCreateInput) -> Pod:
        """
        Create a new pod.

        Args:
            params: Pod creation parameters

        Returns:
            Created Pod instance
        """
        data = self._request("POST", "/pods", json=params.to_api_dict())
        return Pod.model_validate(data)

    def list_pods(self, filters: PodListFilters | None = None) -> list[Pod]:
        """
        List all pods with optional filters.

        Args:
            filters: Optional filtering and include parameters

        Returns:
            List of Pod instances
        """
        params = filters.to_query_params() if filters else None
        data = self._request("GET", "/pods", params=params)

        if not data:
            return []

        pods_data = data if isinstance(data, list) else data.get("pods", [])
        return [Pod.model_validate(pod) for pod in pods_data]

    def get_pod(
        self,
        pod_id: str,
        include_machine: bool = False,
        include_network_volume: bool = False,
        include_savings_plans: bool = False,
        include_template: bool = False,
    ) -> Pod:
        """
        Get a single pod by ID.

        Args:
            pod_id: The pod identifier
            include_machine: Include machine details in response
            include_network_volume: Include network volume details
            include_savings_plans: Include savings plan details
            include_template: Include template details

        Returns:
            Pod instance
        """
        params: dict[str, Any] = {}
        if include_machine:
            params["includeMachine"] = "true"
        if include_network_volume:
            params["includeNetworkVolume"] = "true"
        if include_savings_plans:
            params["includeSavingsPlans"] = "true"
        if include_template:
            params["includeTemplate"] = "true"

        data = self._request("GET", f"/pods/{pod_id}", params=params or None)
        return Pod.model_validate(data)

    def update_pod(self, pod_id: str, params: PodUpdateInput) -> Pod:
        """
        Update pod configuration.

        Args:
            pod_id: The pod identifier
            params: Fields to update

        Returns:
            Updated Pod instance
        """
        data = self._request("PATCH", f"/pods/{pod_id}", json=params.to_api_dict())
        return Pod.model_validate(data)

    def delete_pod(self, pod_id: str) -> None:
        """
        Permanently delete a pod.

        Args:
            pod_id: The pod identifier
        """
        self._request("DELETE", f"/pods/{pod_id}")

    def start_pod(self, pod_id: str) -> None:
        """
        Start or resume a stopped pod.

        Args:
            pod_id: The pod identifier
        """
        self._request("POST", f"/pods/{pod_id}/start")

    def stop_pod(self, pod_id: str) -> None:
        """
        Stop a running pod.

        Args:
            pod_id: The pod identifier
        """
        self._request("POST", f"/pods/{pod_id}/stop")

    def restart_pod(self, pod_id: str) -> None:
        """
        Restart a pod.

        Args:
            pod_id: The pod identifier
        """
        self._request("POST", f"/pods/{pod_id}/restart")
