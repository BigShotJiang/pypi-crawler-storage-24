"""Container registry authentication management client."""

from evolvishub_runpod_management.clients.base import BaseClient
from evolvishub_runpod_management.models.container_reg_auth import (
    ContainerRegistryAuth,
    ContainerRegistryAuthCreateInput,
)


class ContainerRegistryAuthClient(BaseClient):
    """REST client for container registry authentication management."""

    def create(self, params: ContainerRegistryAuthCreateInput) -> ContainerRegistryAuth:
        """
        Create a new container registry authentication.

        Args:
            params: Container registry auth creation parameters (name, username, password)

        Returns:
            Created ContainerRegistryAuth instance
        """
        data = self._request(
            "POST", "/containerregistryauth", json=params.to_api_dict()
        )
        return ContainerRegistryAuth.model_validate(data)

    def list(self) -> list[ContainerRegistryAuth]:
        """
        List all container registry authentications.

        Returns:
            List of ContainerRegistryAuth instances
        """
        data = self._request("GET", "/containerregistryauth")

        if not data:
            return []

        return [ContainerRegistryAuth.model_validate(auth) for auth in data]

    def get(self, auth_id: str) -> ContainerRegistryAuth:
        """
        Get a container registry authentication by ID.

        Args:
            auth_id: The container registry auth identifier

        Returns:
            ContainerRegistryAuth instance
        """
        data = self._request("GET", f"/containerregistryauth/{auth_id}")
        return ContainerRegistryAuth.model_validate(data)

    def delete(self, auth_id: str) -> None:
        """
        Delete a container registry authentication.

        Args:
            auth_id: The container registry auth identifier
        """
        self._request("DELETE", f"/containerregistryauth/{auth_id}")
