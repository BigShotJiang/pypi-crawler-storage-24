"""Account information client (GraphQL)."""

import httpx

from evolvishub_runpod_management.clients.base import BaseClient
from evolvishub_runpod_management.exceptions import (
    RunPodAuthenticationError,
    RunPodConnectionError,
    RunPodError,
)
from evolvishub_runpod_management.models.account import AccountBalance

_BALANCE_QUERY = """
query {
    myself {
        id
        currentSpendPerHr
        machineQuota
        referralEarned
        signedTermsOfService
        clientBalance
    }
}
"""


class AccountInfoClient(BaseClient):
    """GraphQL client for RunPod account information."""

    GRAPHQL_URL = "https://api.runpod.io/graphql"

    def _graphql_request(self, query: str) -> dict:
        """
        Execute a GraphQL query against the RunPod GraphQL API.

        Args:
            query: GraphQL query string

        Returns:
            The ``data`` field of the GraphQL response as a dictionary

        Raises:
            RunPodAuthenticationError: 401 response
            RunPodConnectionError: Network errors
            RunPodError: GraphQL-level errors or other API errors
        """
        try:
            response = self._client.post(
                self.GRAPHQL_URL,
                json={"query": query},
            )
        except httpx.ConnectError as e:
            raise RunPodConnectionError(f"Failed to connect to RunPod GraphQL API: {e}") from e
        except httpx.TimeoutException as e:
            raise RunPodConnectionError(f"Request timed out: {e}") from e
        except httpx.RequestError as e:
            raise RunPodConnectionError(f"Request failed: {e}") from e

        if response.status_code == 401:
            raise RunPodAuthenticationError("Invalid or missing API key")

        if response.status_code >= 400:
            error_detail = self._extract_error_message(response)
            raise RunPodError(
                f"API error ({response.status_code}): {error_detail}",
                status_code=response.status_code,
            )

        data = response.json()

        if "errors" in data:
            raise RunPodError(f"GraphQL errors: {data['errors']}")

        return data.get("data", {})

    def get_balance(self) -> AccountBalance:
        """
        Get full account balance and usage information.

        Returns:
            AccountBalance instance with id, credit_balance, current_spend_per_hr,
            machine_quota, referral_earned, and signed_terms_of_service fields.

        Raises:
            RunPodAuthenticationError: Invalid or missing API key
            RunPodConnectionError: Network errors
            RunPodError: GraphQL or API errors
        """
        data = self._graphql_request(_BALANCE_QUERY)
        return AccountBalance.model_validate(data.get("myself", {}))

    def get_credit_balance(self) -> float:
        """
        Get the current credit balance as a float.

        Returns:
            Credit balance in USD

        Raises:
            RunPodAuthenticationError: Invalid or missing API key
            RunPodConnectionError: Network errors
            RunPodError: GraphQL or API errors
        """
        balance = self.get_balance()
        return balance.credit_balance or 0.0
