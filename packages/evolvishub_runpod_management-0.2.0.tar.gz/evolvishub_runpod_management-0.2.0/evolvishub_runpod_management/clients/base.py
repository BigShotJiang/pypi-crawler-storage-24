"""Base client with shared HTTP logic."""

import httpx

from evolvishub_runpod_management.config import RunPodConfig
from evolvishub_runpod_management.exceptions import (
    RunPodAuthenticationError,
    RunPodConnectionError,
    RunPodError,
    RunPodNotFoundError,
    RunPodValidationError,
)


class BaseClient:
    """Base REST client with shared HTTP functionality."""

    def __init__(self, config: RunPodConfig):
        """
        Initialize the client with configuration.

        Args:
            config: RunPodConfig instance with API credentials
        """
        self._config = config
        self._client = httpx.Client(
            base_url=config.base_url,
            headers={
                "Authorization": f"Bearer {config.api_key}",
                "Content-Type": "application/json",
            },
            timeout=config.request_timeout,
        )

    @classmethod
    def initialize(
        cls,
        api_key: str | None = None,
        base_url: str | None = None,
        request_timeout: float | None = None,
        env_file: str = ".env",
    ) -> "BaseClient":
        """
        Factory method that loads config from .env and/or parameters.

        Args:
            api_key: RunPod API key (overrides env)
            base_url: API base URL (overrides env)
            request_timeout: Request timeout in seconds (overrides env)
            env_file: Path to .env file

        Returns:
            Configured client instance
        """
        config = RunPodConfig.load(
            api_key=api_key,
            base_url=base_url,
            request_timeout=request_timeout,
            env_file=env_file,
        )
        return cls(config)

    def _request(
        self,
        method: str,
        path: str,
        json: dict | None = None,
        params: dict | None = None,
    ) -> dict | None:
        """
        Execute HTTP request with auth and error handling.

        Args:
            method: HTTP method (GET, POST, PATCH, DELETE)
            path: API endpoint path
            json: Request body as dictionary
            params: Query parameters

        Returns:
            Response JSON as dictionary, or None for empty responses

        Raises:
            RunPodAuthenticationError: 401 response
            RunPodValidationError: 400 response
            RunPodNotFoundError: 404 response
            RunPodConnectionError: Network errors
            RunPodError: Other API errors
        """
        try:
            response = self._client.request(
                method=method,
                url=path,
                json=json,
                params=params,
            )
        except httpx.ConnectError as e:
            raise RunPodConnectionError(f"Failed to connect to RunPod API: {e}") from e
        except httpx.TimeoutException as e:
            raise RunPodConnectionError(f"Request timed out: {e}") from e
        except httpx.RequestError as e:
            raise RunPodConnectionError(f"Request failed: {e}") from e

        if response.status_code == 401:
            raise RunPodAuthenticationError("Invalid or missing API key")

        if response.status_code == 400:
            error_detail = self._extract_error_message(response)
            raise RunPodValidationError(f"Invalid request: {error_detail}")

        if response.status_code == 404:
            raise RunPodNotFoundError("Resource not found")

        if response.status_code >= 400:
            error_detail = self._extract_error_message(response)
            raise RunPodError(
                f"API error ({response.status_code}): {error_detail}",
                status_code=response.status_code,
            )

        if response.status_code == 204 or not response.content:
            return None

        return response.json()

    def _extract_error_message(self, response: httpx.Response) -> str:
        """Extract error message from API response."""
        try:
            data = response.json()
            if isinstance(data, dict):
                return data.get("error", data.get("message", str(data)))
            return str(data)
        except Exception:
            return response.text or f"HTTP {response.status_code}"

    def close(self) -> None:
        """Close HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> "BaseClient":
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - closes connection."""
        self.close()
