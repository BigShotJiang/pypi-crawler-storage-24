import json
import urllib.error
from io import BytesIO
from unittest.mock import patch, MagicMock

import pytest

from finnear import (
    Finnear,
    FinnearError,
    AuthenticationError,
    ValidationError,
    ApiError,
    EventPayload,
)


class TestConstructor:
    def test_raises_if_api_key_is_empty(self) -> None:
        with pytest.raises(FinnearError, match="api_key is required"):
            Finnear(api_key="")

    def test_raises_if_api_key_missing_prefix(self) -> None:
        with pytest.raises(FinnearError, match='api_key must start with "pk_"'):
            Finnear(api_key="invalid-key")

    def test_creates_client_with_valid_config(self) -> None:
        client = Finnear(api_key="pk_test-key")
        assert isinstance(client, Finnear)


class TestTrack:
    CLIENT = Finnear(api_key="pk_test-key")
    PAYLOAD = EventPayload(channel="signup", title="New user signed up")

    @patch("finnear.client.urllib.request.urlopen")
    def test_sends_event_and_returns_event_id(self, mock_urlopen: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({"eventId": "evt_123"}).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        result = self.CLIENT.track(self.PAYLOAD)

        assert result.event_id == "evt_123"
        call_args = mock_urlopen.call_args[0][0]
        assert call_args.full_url == "https://finnear.com/webhook/ingest"
        assert call_args.get_header("Authorization") == "Bearer pk_test-key"
        assert call_args.get_header("Content-type") == "application/json"
        assert json.loads(call_args.data) == {
            "channel": "signup",
            "title": "New user signed up",
        }

    @patch("finnear.client.urllib.request.urlopen")
    def test_sends_optional_fields(self, mock_urlopen: MagicMock) -> None:
        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({"eventId": "evt_456"}).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        mock_urlopen.return_value = mock_resp

        payload = EventPayload(
            channel="signup",
            title="New user signed up",
            description="user@example.com",
            emoji="🙋",
            user_id="user_123",
            metadata={"plan": "pro"},
        )
        self.CLIENT.track(payload)

        call_args = mock_urlopen.call_args[0][0]
        body = json.loads(call_args.data)
        assert body == {
            "channel": "signup",
            "title": "New user signed up",
            "description": "user@example.com",
            "emoji": "🙋",
            "userId": "user_123",
            "metadata": {"plan": "pro"},
        }

    @patch("finnear.client.urllib.request.urlopen")
    def test_raises_authentication_error_on_401(self, mock_urlopen: MagicMock) -> None:
        error_body = json.dumps({"error": "Invalid API key"}).encode()
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="", code=401, msg="Unauthorized", hdrs=None, fp=BytesIO(error_body)  # type: ignore[arg-type]
        )

        with pytest.raises(AuthenticationError, match="Invalid API key"):
            self.CLIENT.track(self.PAYLOAD)

    @patch("finnear.client.urllib.request.urlopen")
    def test_raises_validation_error_on_400(self, mock_urlopen: MagicMock) -> None:
        error_body = json.dumps({"error": "Missing required field"}).encode()
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="", code=400, msg="Bad Request", hdrs=None, fp=BytesIO(error_body)  # type: ignore[arg-type]
        )

        with pytest.raises(ValidationError, match="Missing required field"):
            self.CLIENT.track(self.PAYLOAD)

    @patch("finnear.client.urllib.request.urlopen")
    def test_raises_api_error_on_other_http_errors(self, mock_urlopen: MagicMock) -> None:
        error_body = json.dumps({"error": "Server error"}).encode()
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="", code=500, msg="Internal Server Error", hdrs=None, fp=BytesIO(error_body)  # type: ignore[arg-type]
        )

        with pytest.raises(ApiError) as exc_info:
            self.CLIENT.track(self.PAYLOAD)
        assert exc_info.value.status == 500

    @patch("finnear.client.urllib.request.urlopen")
    def test_handles_non_json_error_responses(self, mock_urlopen: MagicMock) -> None:
        mock_urlopen.side_effect = urllib.error.HTTPError(
            url="", code=502, msg="Bad Gateway", hdrs=None, fp=BytesIO(b"not json")  # type: ignore[arg-type]
        )

        with pytest.raises(ApiError, match="Bad Gateway"):
            self.CLIENT.track(self.PAYLOAD)

