#!/usr/bin/env bash
set -euo pipefail

# Finnear Python SDK - Build & Publish Script
# Usage:
#   ./scripts/publish.sh [patch|minor|major]  (default: patch)

SDK_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$SDK_DIR"

# Ensure build dependencies are installed
for pkg in build twine pytest; do
  if ! python3 -m pip show "$pkg" &>/dev/null; then
    echo "📥 Installing missing dependency: $pkg"
    python3 -m pip install "$pkg" --quiet
  fi
done

BUMP_TYPE="${1:-patch}"

if [[ "$BUMP_TYPE" != "patch" && "$BUMP_TYPE" != "minor" && "$BUMP_TYPE" != "major" ]]; then
  echo "❌ Invalid bump type: $BUMP_TYPE"
  echo "Usage: ./scripts/publish.sh [patch|minor|major]"
  exit 1
fi

# Read current version from pyproject.toml
CURRENT_VERSION=$(python3 -c "
import re
with open('pyproject.toml') as f:
    match = re.search(r'version\s*=\s*\"(.+?)\"', f.read())
    print(match.group(1))
")

echo "🐍 Finnear Python SDK"
echo "   Current version: $CURRENT_VERSION"
echo "   Bump type: $BUMP_TYPE"
echo ""

# Bump version
IFS='.' read -r MAJOR MINOR PATCH <<< "$CURRENT_VERSION"
case "$BUMP_TYPE" in
  major) MAJOR=$((MAJOR + 1)); MINOR=0; PATCH=0 ;;
  minor) MINOR=$((MINOR + 1)); PATCH=0 ;;
  patch) PATCH=$((PATCH + 1)) ;;
esac
NEW_VERSION="$MAJOR.$MINOR.$PATCH"

# Step 1: Run tests
echo "🧪 Running tests..."
python3 -m pytest tests/ -v
echo ""

# Step 2: Update version in pyproject.toml
sed -i '' "s/version = \"$CURRENT_VERSION\"/version = \"$NEW_VERSION\"/" pyproject.toml
echo "📌 Version bumped: $CURRENT_VERSION → $NEW_VERSION"
echo ""

# Step 3: Clean previous builds
rm -rf dist/ build/ src/*.egg-info

# Step 4: Build
echo "🔨 Building..."
python3 -m build
echo ""

# Step 5: Confirm before publishing
echo "🚀 Ready to publish finnear==$NEW_VERSION to PyPI"
read -p "   Continue? (y/N) " -n 1 -r
echo ""

if [[ ! $REPLY =~ ^[Yy]$ ]]; then
  echo "❌ Aborted. Version was bumped to $NEW_VERSION in pyproject.toml — revert if needed."
  exit 1
fi

# Step 6: Publish
python3 -m twine upload dist/*
echo ""
echo "✅ Published finnear==$NEW_VERSION to PyPI"
echo ""
echo "Next steps:"
echo "  1. Commit: git add sdks/python/pyproject.toml && git commit -m 'chore(sdk): release python sdk v$NEW_VERSION'"
echo "  2. Tag:    git tag python-v$NEW_VERSION"
echo "  3. Push:   git push && git push --tags"
