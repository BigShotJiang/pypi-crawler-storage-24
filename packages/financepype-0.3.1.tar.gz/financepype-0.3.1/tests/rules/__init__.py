"""Tests for trading rules."""
