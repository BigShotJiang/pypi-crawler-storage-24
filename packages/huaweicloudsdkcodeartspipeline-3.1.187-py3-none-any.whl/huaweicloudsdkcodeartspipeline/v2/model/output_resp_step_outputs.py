# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class OutputRespStepOutputs:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'step_run_id': 'str',
        'output_result': 'list[OutputRespOutputResult]'
    }

    attribute_map = {
        'step_run_id': 'step_run_id',
        'output_result': 'output_result'
    }

    def __init__(self, step_run_id=None, output_result=None):
        r"""OutputRespStepOutputs

        The model defined in huaweicloud sdk

        :param step_run_id: **参数解释**： 步骤ID。 **取值范围**： 32位字符，由数字和字母组成。 
        :type step_run_id: str
        :param output_result: **参数解释**： 步骤输出。 **取值范围**： 不涉及。 
        :type output_result: list[:class:`huaweicloudsdkcodeartspipeline.v2.OutputRespOutputResult`]
        """
        
        

        self._step_run_id = None
        self._output_result = None
        self.discriminator = None

        if step_run_id is not None:
            self.step_run_id = step_run_id
        if output_result is not None:
            self.output_result = output_result

    @property
    def step_run_id(self):
        r"""Gets the step_run_id of this OutputRespStepOutputs.

        **参数解释**： 步骤ID。 **取值范围**： 32位字符，由数字和字母组成。 

        :return: The step_run_id of this OutputRespStepOutputs.
        :rtype: str
        """
        return self._step_run_id

    @step_run_id.setter
    def step_run_id(self, step_run_id):
        r"""Sets the step_run_id of this OutputRespStepOutputs.

        **参数解释**： 步骤ID。 **取值范围**： 32位字符，由数字和字母组成。 

        :param step_run_id: The step_run_id of this OutputRespStepOutputs.
        :type step_run_id: str
        """
        self._step_run_id = step_run_id

    @property
    def output_result(self):
        r"""Gets the output_result of this OutputRespStepOutputs.

        **参数解释**： 步骤输出。 **取值范围**： 不涉及。 

        :return: The output_result of this OutputRespStepOutputs.
        :rtype: list[:class:`huaweicloudsdkcodeartspipeline.v2.OutputRespOutputResult`]
        """
        return self._output_result

    @output_result.setter
    def output_result(self, output_result):
        r"""Sets the output_result of this OutputRespStepOutputs.

        **参数解释**： 步骤输出。 **取值范围**： 不涉及。 

        :param output_result: The output_result of this OutputRespStepOutputs.
        :type output_result: list[:class:`huaweicloudsdkcodeartspipeline.v2.OutputRespOutputResult`]
        """
        self._output_result = output_result

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, OutputRespStepOutputs):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
