# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateRuleInstance:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'is_valid': 'bool'
    }

    attribute_map = {
        'id': 'id',
        'is_valid': 'is_valid'
    }

    def __init__(self, id=None, is_valid=None):
        r"""UpdateRuleInstance

        The model defined in huaweicloud sdk

        :param id: **参数解释**： 规则ID，规则的唯一标识，通过[分页获取规则列表](ListRule.xml)接口获取，data.id即为规则ID。 **约束限制**： 不涉及。 **取值范围**： 32位字符，由数字和字母组成。 **默认取值**： 不涉及。 
        :type id: str
        :param is_valid: **参数解释**： 规则启用状态。 **约束限制**： 不涉及。 **取值范围**： - true：启用。 - false：不启用。 **默认取值**： 不涉及。 
        :type is_valid: bool
        """
        
        

        self._id = None
        self._is_valid = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if is_valid is not None:
            self.is_valid = is_valid

    @property
    def id(self):
        r"""Gets the id of this UpdateRuleInstance.

        **参数解释**： 规则ID，规则的唯一标识，通过[分页获取规则列表](ListRule.xml)接口获取，data.id即为规则ID。 **约束限制**： 不涉及。 **取值范围**： 32位字符，由数字和字母组成。 **默认取值**： 不涉及。 

        :return: The id of this UpdateRuleInstance.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this UpdateRuleInstance.

        **参数解释**： 规则ID，规则的唯一标识，通过[分页获取规则列表](ListRule.xml)接口获取，data.id即为规则ID。 **约束限制**： 不涉及。 **取值范围**： 32位字符，由数字和字母组成。 **默认取值**： 不涉及。 

        :param id: The id of this UpdateRuleInstance.
        :type id: str
        """
        self._id = id

    @property
    def is_valid(self):
        r"""Gets the is_valid of this UpdateRuleInstance.

        **参数解释**： 规则启用状态。 **约束限制**： 不涉及。 **取值范围**： - true：启用。 - false：不启用。 **默认取值**： 不涉及。 

        :return: The is_valid of this UpdateRuleInstance.
        :rtype: bool
        """
        return self._is_valid

    @is_valid.setter
    def is_valid(self, is_valid):
        r"""Sets the is_valid of this UpdateRuleInstance.

        **参数解释**： 规则启用状态。 **约束限制**： 不涉及。 **取值范围**： - true：启用。 - false：不启用。 **默认取值**： 不涉及。 

        :param is_valid: The is_valid of this UpdateRuleInstance.
        :type is_valid: bool
        """
        self._is_valid = is_valid

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateRuleInstance):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
