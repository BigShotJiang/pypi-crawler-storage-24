# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListPipelinesPageLatestRunStageStatusList:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'name': 'str',
        'sequence': 'int',
        'status': 'str',
        'start_time': 'str',
        'end_time': 'str',
        'id': 'str'
    }

    attribute_map = {
        'name': 'name',
        'sequence': 'sequence',
        'status': 'status',
        'start_time': 'start_time',
        'end_time': 'end_time',
        'id': 'id'
    }

    def __init__(self, name=None, sequence=None, status=None, start_time=None, end_time=None, id=None):
        r"""ListPipelinesPageLatestRunStageStatusList

        The model defined in huaweicloud sdk

        :param name: **参数解释**： 阶段名称。 **取值范围**： 仅支持输入中文、大小写英文字母、数字、&#39;-&#39;、&#39;_&#39;、&#39;,&#39;、&#39;;&#39;、&#39;:&#39;、&#39;.&#39;、&#39;/&#39;、&#39;(&#39;、&#39;)&#39;、&#39;（&#39;、&#39;）&#39;及空格，其中空格不可在名称开头或结尾使用，且长度为[1,128]个字符。 
        :type name: str
        :param sequence: **参数解释**： 阶段序列号，0代表第一个流水线阶段。 **取值范围**： 大于等于零。 
        :type sequence: int
        :param status: **参数解释**： 流水线阶段状态。 **取值范围**： - INIT：初始化。 - QUEUED：排队。 - RUNNING：运行中。 - CANCELED：取消。 - COMPLETED：已完成。 - FAILED：失败。 - SKIPPED：跳过。 - IGNORED：忽略。 - PAUSED：暂停。 - SUSPEND：挂起。 - ASYNC_RUNNING：异步运行。 - ASYNC_FAILED：异步失败。 - UNSELECTED：未选择。 - REDISPATCH：重新调度。 
        :type status: str
        :param start_time: **参数解释**： 阶段开始时间。 **取值范围**： 不涉及。 
        :type start_time: str
        :param end_time: **参数解释**： 阶段结束时间。 **取值范围**： 不涉及。 
        :type end_time: str
        :param id: **参数解释**： 阶段ID。 **取值范围**： 不涉及。 
        :type id: str
        """
        
        

        self._name = None
        self._sequence = None
        self._status = None
        self._start_time = None
        self._end_time = None
        self._id = None
        self.discriminator = None

        if name is not None:
            self.name = name
        if sequence is not None:
            self.sequence = sequence
        if status is not None:
            self.status = status
        if start_time is not None:
            self.start_time = start_time
        if end_time is not None:
            self.end_time = end_time
        if id is not None:
            self.id = id

    @property
    def name(self):
        r"""Gets the name of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段名称。 **取值范围**： 仅支持输入中文、大小写英文字母、数字、'-'、'_'、','、';'、':'、'.'、'/'、'('、')'、'（'、'）'及空格，其中空格不可在名称开头或结尾使用，且长度为[1,128]个字符。 

        :return: The name of this ListPipelinesPageLatestRunStageStatusList.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段名称。 **取值范围**： 仅支持输入中文、大小写英文字母、数字、'-'、'_'、','、';'、':'、'.'、'/'、'('、')'、'（'、'）'及空格，其中空格不可在名称开头或结尾使用，且长度为[1,128]个字符。 

        :param name: The name of this ListPipelinesPageLatestRunStageStatusList.
        :type name: str
        """
        self._name = name

    @property
    def sequence(self):
        r"""Gets the sequence of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段序列号，0代表第一个流水线阶段。 **取值范围**： 大于等于零。 

        :return: The sequence of this ListPipelinesPageLatestRunStageStatusList.
        :rtype: int
        """
        return self._sequence

    @sequence.setter
    def sequence(self, sequence):
        r"""Sets the sequence of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段序列号，0代表第一个流水线阶段。 **取值范围**： 大于等于零。 

        :param sequence: The sequence of this ListPipelinesPageLatestRunStageStatusList.
        :type sequence: int
        """
        self._sequence = sequence

    @property
    def status(self):
        r"""Gets the status of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 流水线阶段状态。 **取值范围**： - INIT：初始化。 - QUEUED：排队。 - RUNNING：运行中。 - CANCELED：取消。 - COMPLETED：已完成。 - FAILED：失败。 - SKIPPED：跳过。 - IGNORED：忽略。 - PAUSED：暂停。 - SUSPEND：挂起。 - ASYNC_RUNNING：异步运行。 - ASYNC_FAILED：异步失败。 - UNSELECTED：未选择。 - REDISPATCH：重新调度。 

        :return: The status of this ListPipelinesPageLatestRunStageStatusList.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 流水线阶段状态。 **取值范围**： - INIT：初始化。 - QUEUED：排队。 - RUNNING：运行中。 - CANCELED：取消。 - COMPLETED：已完成。 - FAILED：失败。 - SKIPPED：跳过。 - IGNORED：忽略。 - PAUSED：暂停。 - SUSPEND：挂起。 - ASYNC_RUNNING：异步运行。 - ASYNC_FAILED：异步失败。 - UNSELECTED：未选择。 - REDISPATCH：重新调度。 

        :param status: The status of this ListPipelinesPageLatestRunStageStatusList.
        :type status: str
        """
        self._status = status

    @property
    def start_time(self):
        r"""Gets the start_time of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段开始时间。 **取值范围**： 不涉及。 

        :return: The start_time of this ListPipelinesPageLatestRunStageStatusList.
        :rtype: str
        """
        return self._start_time

    @start_time.setter
    def start_time(self, start_time):
        r"""Sets the start_time of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段开始时间。 **取值范围**： 不涉及。 

        :param start_time: The start_time of this ListPipelinesPageLatestRunStageStatusList.
        :type start_time: str
        """
        self._start_time = start_time

    @property
    def end_time(self):
        r"""Gets the end_time of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段结束时间。 **取值范围**： 不涉及。 

        :return: The end_time of this ListPipelinesPageLatestRunStageStatusList.
        :rtype: str
        """
        return self._end_time

    @end_time.setter
    def end_time(self, end_time):
        r"""Sets the end_time of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段结束时间。 **取值范围**： 不涉及。 

        :param end_time: The end_time of this ListPipelinesPageLatestRunStageStatusList.
        :type end_time: str
        """
        self._end_time = end_time

    @property
    def id(self):
        r"""Gets the id of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段ID。 **取值范围**： 不涉及。 

        :return: The id of this ListPipelinesPageLatestRunStageStatusList.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this ListPipelinesPageLatestRunStageStatusList.

        **参数解释**： 阶段ID。 **取值范围**： 不涉及。 

        :param id: The id of this ListPipelinesPageLatestRunStageStatusList.
        :type id: str
        """
        self._id = id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListPipelinesPageLatestRunStageStatusList):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
