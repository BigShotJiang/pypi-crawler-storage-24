# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateRuleResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'status': 'bool',
        'rule_id': 'str'
    }

    attribute_map = {
        'status': 'status',
        'rule_id': 'rule_id'
    }

    def __init__(self, status=None, rule_id=None):
        r"""CreateRuleResponse

        The model defined in huaweicloud sdk

        :param status: **参数解释**： 创建状态。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 
        :type status: bool
        :param rule_id: **参数解释**： 规则ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 
        :type rule_id: str
        """
        
        super().__init__()

        self._status = None
        self._rule_id = None
        self.discriminator = None

        if status is not None:
            self.status = status
        if rule_id is not None:
            self.rule_id = rule_id

    @property
    def status(self):
        r"""Gets the status of this CreateRuleResponse.

        **参数解释**： 创建状态。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :return: The status of this CreateRuleResponse.
        :rtype: bool
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this CreateRuleResponse.

        **参数解释**： 创建状态。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :param status: The status of this CreateRuleResponse.
        :type status: bool
        """
        self._status = status

    @property
    def rule_id(self):
        r"""Gets the rule_id of this CreateRuleResponse.

        **参数解释**： 规则ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :return: The rule_id of this CreateRuleResponse.
        :rtype: str
        """
        return self._rule_id

    @rule_id.setter
    def rule_id(self, rule_id):
        r"""Sets the rule_id of this CreateRuleResponse.

        **参数解释**： 规则ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :param rule_id: The rule_id of this CreateRuleResponse.
        :type rule_id: str
        """
        self._rule_id = rule_id

    def to_dict(self):
        import warnings
        warnings.warn("CreateRuleResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateRuleResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
