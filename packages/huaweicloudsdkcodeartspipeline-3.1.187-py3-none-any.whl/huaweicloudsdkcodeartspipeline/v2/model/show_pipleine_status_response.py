# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowPipleineStatusResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'pipeline_id': 'str',
        'pipeline_name': 'str',
        'executor': 'str',
        'build_id': 'str',
        'start_time': 'str',
        'end_time': 'str',
        'parameters': 'list[PipelineParameter]',
        'states': 'list[PipelineStateStatus]',
        'elapsed_time': 'str',
        'status': 'str',
        'outcome': 'str',
        'detail_url': 'str'
    }

    attribute_map = {
        'pipeline_id': 'pipeline_id',
        'pipeline_name': 'pipeline_name',
        'executor': 'executor',
        'build_id': 'build_id',
        'start_time': 'start_time',
        'end_time': 'end_time',
        'parameters': 'parameters',
        'states': 'states',
        'elapsed_time': 'elapsed_time',
        'status': 'status',
        'outcome': 'outcome',
        'detail_url': 'detail_url'
    }

    def __init__(self, pipeline_id=None, pipeline_name=None, executor=None, build_id=None, start_time=None, end_time=None, parameters=None, states=None, elapsed_time=None, status=None, outcome=None, detail_url=None):
        r"""ShowPipleineStatusResponse

        The model defined in huaweicloud sdk

        :param pipeline_id: 流水线ID
        :type pipeline_id: str
        :param pipeline_name: 流水线名称
        :type pipeline_name: str
        :param executor: 执行人
        :type executor: str
        :param build_id: 流水线执行ID
        :type build_id: str
        :param start_time: 开始执行时间
        :type start_time: str
        :param end_time: 结束执行时间
        :type end_time: str
        :param parameters: 流水线参数
        :type parameters: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineParameter`]
        :param states: 流水线执行情况
        :type states: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineStateStatus`]
        :param elapsed_time: 执行耗时
        :type elapsed_time: str
        :param status: 流水线运行状态。取值及含义：waiting：等待；running：执行中；verifying：待审核；suspending：挂起；completed：完成。
        :type status: str
        :param outcome: 流水线执行结果。取值及含义：success：成功；error：失败；aborted：终止
        :type outcome: str
        :param detail_url: 流水线详情页地址
        :type detail_url: str
        """
        
        super().__init__()

        self._pipeline_id = None
        self._pipeline_name = None
        self._executor = None
        self._build_id = None
        self._start_time = None
        self._end_time = None
        self._parameters = None
        self._states = None
        self._elapsed_time = None
        self._status = None
        self._outcome = None
        self._detail_url = None
        self.discriminator = None

        if pipeline_id is not None:
            self.pipeline_id = pipeline_id
        if pipeline_name is not None:
            self.pipeline_name = pipeline_name
        if executor is not None:
            self.executor = executor
        if build_id is not None:
            self.build_id = build_id
        if start_time is not None:
            self.start_time = start_time
        if end_time is not None:
            self.end_time = end_time
        if parameters is not None:
            self.parameters = parameters
        if states is not None:
            self.states = states
        if elapsed_time is not None:
            self.elapsed_time = elapsed_time
        if status is not None:
            self.status = status
        if outcome is not None:
            self.outcome = outcome
        if detail_url is not None:
            self.detail_url = detail_url

    @property
    def pipeline_id(self):
        r"""Gets the pipeline_id of this ShowPipleineStatusResponse.

        流水线ID

        :return: The pipeline_id of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._pipeline_id

    @pipeline_id.setter
    def pipeline_id(self, pipeline_id):
        r"""Sets the pipeline_id of this ShowPipleineStatusResponse.

        流水线ID

        :param pipeline_id: The pipeline_id of this ShowPipleineStatusResponse.
        :type pipeline_id: str
        """
        self._pipeline_id = pipeline_id

    @property
    def pipeline_name(self):
        r"""Gets the pipeline_name of this ShowPipleineStatusResponse.

        流水线名称

        :return: The pipeline_name of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._pipeline_name

    @pipeline_name.setter
    def pipeline_name(self, pipeline_name):
        r"""Sets the pipeline_name of this ShowPipleineStatusResponse.

        流水线名称

        :param pipeline_name: The pipeline_name of this ShowPipleineStatusResponse.
        :type pipeline_name: str
        """
        self._pipeline_name = pipeline_name

    @property
    def executor(self):
        r"""Gets the executor of this ShowPipleineStatusResponse.

        执行人

        :return: The executor of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._executor

    @executor.setter
    def executor(self, executor):
        r"""Sets the executor of this ShowPipleineStatusResponse.

        执行人

        :param executor: The executor of this ShowPipleineStatusResponse.
        :type executor: str
        """
        self._executor = executor

    @property
    def build_id(self):
        r"""Gets the build_id of this ShowPipleineStatusResponse.

        流水线执行ID

        :return: The build_id of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._build_id

    @build_id.setter
    def build_id(self, build_id):
        r"""Sets the build_id of this ShowPipleineStatusResponse.

        流水线执行ID

        :param build_id: The build_id of this ShowPipleineStatusResponse.
        :type build_id: str
        """
        self._build_id = build_id

    @property
    def start_time(self):
        r"""Gets the start_time of this ShowPipleineStatusResponse.

        开始执行时间

        :return: The start_time of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._start_time

    @start_time.setter
    def start_time(self, start_time):
        r"""Sets the start_time of this ShowPipleineStatusResponse.

        开始执行时间

        :param start_time: The start_time of this ShowPipleineStatusResponse.
        :type start_time: str
        """
        self._start_time = start_time

    @property
    def end_time(self):
        r"""Gets the end_time of this ShowPipleineStatusResponse.

        结束执行时间

        :return: The end_time of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._end_time

    @end_time.setter
    def end_time(self, end_time):
        r"""Sets the end_time of this ShowPipleineStatusResponse.

        结束执行时间

        :param end_time: The end_time of this ShowPipleineStatusResponse.
        :type end_time: str
        """
        self._end_time = end_time

    @property
    def parameters(self):
        r"""Gets the parameters of this ShowPipleineStatusResponse.

        流水线参数

        :return: The parameters of this ShowPipleineStatusResponse.
        :rtype: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineParameter`]
        """
        return self._parameters

    @parameters.setter
    def parameters(self, parameters):
        r"""Sets the parameters of this ShowPipleineStatusResponse.

        流水线参数

        :param parameters: The parameters of this ShowPipleineStatusResponse.
        :type parameters: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineParameter`]
        """
        self._parameters = parameters

    @property
    def states(self):
        r"""Gets the states of this ShowPipleineStatusResponse.

        流水线执行情况

        :return: The states of this ShowPipleineStatusResponse.
        :rtype: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineStateStatus`]
        """
        return self._states

    @states.setter
    def states(self, states):
        r"""Sets the states of this ShowPipleineStatusResponse.

        流水线执行情况

        :param states: The states of this ShowPipleineStatusResponse.
        :type states: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineStateStatus`]
        """
        self._states = states

    @property
    def elapsed_time(self):
        r"""Gets the elapsed_time of this ShowPipleineStatusResponse.

        执行耗时

        :return: The elapsed_time of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._elapsed_time

    @elapsed_time.setter
    def elapsed_time(self, elapsed_time):
        r"""Sets the elapsed_time of this ShowPipleineStatusResponse.

        执行耗时

        :param elapsed_time: The elapsed_time of this ShowPipleineStatusResponse.
        :type elapsed_time: str
        """
        self._elapsed_time = elapsed_time

    @property
    def status(self):
        r"""Gets the status of this ShowPipleineStatusResponse.

        流水线运行状态。取值及含义：waiting：等待；running：执行中；verifying：待审核；suspending：挂起；completed：完成。

        :return: The status of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this ShowPipleineStatusResponse.

        流水线运行状态。取值及含义：waiting：等待；running：执行中；verifying：待审核；suspending：挂起；completed：完成。

        :param status: The status of this ShowPipleineStatusResponse.
        :type status: str
        """
        self._status = status

    @property
    def outcome(self):
        r"""Gets the outcome of this ShowPipleineStatusResponse.

        流水线执行结果。取值及含义：success：成功；error：失败；aborted：终止

        :return: The outcome of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._outcome

    @outcome.setter
    def outcome(self, outcome):
        r"""Sets the outcome of this ShowPipleineStatusResponse.

        流水线执行结果。取值及含义：success：成功；error：失败；aborted：终止

        :param outcome: The outcome of this ShowPipleineStatusResponse.
        :type outcome: str
        """
        self._outcome = outcome

    @property
    def detail_url(self):
        r"""Gets the detail_url of this ShowPipleineStatusResponse.

        流水线详情页地址

        :return: The detail_url of this ShowPipleineStatusResponse.
        :rtype: str
        """
        return self._detail_url

    @detail_url.setter
    def detail_url(self, detail_url):
        r"""Sets the detail_url of this ShowPipleineStatusResponse.

        流水线详情页地址

        :param detail_url: The detail_url of this ShowPipleineStatusResponse.
        :type detail_url: str
        """
        self._detail_url = detail_url

    def to_dict(self):
        import warnings
        warnings.warn("ShowPipleineStatusResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowPipleineStatusResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
