# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DeletePipelineGroupResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'success': 'bool'
    }

    attribute_map = {
        'success': 'success'
    }

    def __init__(self, success=None):
        r"""DeletePipelineGroupResponse

        The model defined in huaweicloud sdk

        :param success: **参数解释**： 操作是否成功。 **取值范围**： - true：操作成功。 - false：操作失败。 
        :type success: bool
        """
        
        super().__init__()

        self._success = None
        self.discriminator = None

        if success is not None:
            self.success = success

    @property
    def success(self):
        r"""Gets the success of this DeletePipelineGroupResponse.

        **参数解释**： 操作是否成功。 **取值范围**： - true：操作成功。 - false：操作失败。 

        :return: The success of this DeletePipelineGroupResponse.
        :rtype: bool
        """
        return self._success

    @success.setter
    def success(self, success):
        r"""Sets the success of this DeletePipelineGroupResponse.

        **参数解释**： 操作是否成功。 **取值范围**： - true：操作成功。 - false：操作失败。 

        :param success: The success of this DeletePipelineGroupResponse.
        :type success: bool
        """
        self._success = success

    def to_dict(self):
        import warnings
        warnings.warn("DeletePipelineGroupResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeletePipelineGroupResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
