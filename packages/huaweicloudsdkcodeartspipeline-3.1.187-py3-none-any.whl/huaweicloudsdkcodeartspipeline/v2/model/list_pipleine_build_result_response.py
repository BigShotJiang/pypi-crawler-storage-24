# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListPipleineBuildResultResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'offset': 'int',
        'limit': 'int',
        'total': 'int',
        'build_results': 'list[PipelineBuildResult]'
    }

    attribute_map = {
        'offset': 'offset',
        'limit': 'limit',
        'total': 'total',
        'build_results': 'build_results'
    }

    def __init__(self, offset=None, limit=None, total=None, build_results=None):
        r"""ListPipleineBuildResultResponse

        The model defined in huaweicloud sdk

        :param offset: **参数解释**： 偏移量，表示从此偏移量开始查询。 **取值范围**： offset大于等于0。 
        :type offset: int
        :param limit: **参数解释**： 每次查询的条目数量。 **取值范围**： 大于等于0。 
        :type limit: int
        :param total: **参数解释**： 总条目数量。 **取值范围**： 不涉及。 
        :type total: int
        :param build_results: **参数解释**： 执行状况数据列表。 **取值范围**： 不涉及。 
        :type build_results: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineBuildResult`]
        """
        
        super().__init__()

        self._offset = None
        self._limit = None
        self._total = None
        self._build_results = None
        self.discriminator = None

        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        if total is not None:
            self.total = total
        if build_results is not None:
            self.build_results = build_results

    @property
    def offset(self):
        r"""Gets the offset of this ListPipleineBuildResultResponse.

        **参数解释**： 偏移量，表示从此偏移量开始查询。 **取值范围**： offset大于等于0。 

        :return: The offset of this ListPipleineBuildResultResponse.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListPipleineBuildResultResponse.

        **参数解释**： 偏移量，表示从此偏移量开始查询。 **取值范围**： offset大于等于0。 

        :param offset: The offset of this ListPipleineBuildResultResponse.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListPipleineBuildResultResponse.

        **参数解释**： 每次查询的条目数量。 **取值范围**： 大于等于0。 

        :return: The limit of this ListPipleineBuildResultResponse.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListPipleineBuildResultResponse.

        **参数解释**： 每次查询的条目数量。 **取值范围**： 大于等于0。 

        :param limit: The limit of this ListPipleineBuildResultResponse.
        :type limit: int
        """
        self._limit = limit

    @property
    def total(self):
        r"""Gets the total of this ListPipleineBuildResultResponse.

        **参数解释**： 总条目数量。 **取值范围**： 不涉及。 

        :return: The total of this ListPipleineBuildResultResponse.
        :rtype: int
        """
        return self._total

    @total.setter
    def total(self, total):
        r"""Sets the total of this ListPipleineBuildResultResponse.

        **参数解释**： 总条目数量。 **取值范围**： 不涉及。 

        :param total: The total of this ListPipleineBuildResultResponse.
        :type total: int
        """
        self._total = total

    @property
    def build_results(self):
        r"""Gets the build_results of this ListPipleineBuildResultResponse.

        **参数解释**： 执行状况数据列表。 **取值范围**： 不涉及。 

        :return: The build_results of this ListPipleineBuildResultResponse.
        :rtype: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineBuildResult`]
        """
        return self._build_results

    @build_results.setter
    def build_results(self, build_results):
        r"""Sets the build_results of this ListPipleineBuildResultResponse.

        **参数解释**： 执行状况数据列表。 **取值范围**： 不涉及。 

        :param build_results: The build_results of this ListPipleineBuildResultResponse.
        :type build_results: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineBuildResult`]
        """
        self._build_results = build_results

    def to_dict(self):
        import warnings
        warnings.warn("ListPipleineBuildResultResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListPipleineBuildResultResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
