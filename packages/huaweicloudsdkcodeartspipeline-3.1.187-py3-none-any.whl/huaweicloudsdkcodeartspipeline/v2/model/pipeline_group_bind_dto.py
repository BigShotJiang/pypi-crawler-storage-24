# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class PipelineGroupBindDTO:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'group_id': 'str',
        'pipelines': 'list[PipelineGroupBindDTOPipelines]'
    }

    attribute_map = {
        'group_id': 'group_id',
        'pipelines': 'pipelines'
    }

    def __init__(self, group_id=None, pipelines=None):
        r"""PipelineGroupBindDTO

        The model defined in huaweicloud sdk

        :param group_id: **参数解释**： 分组ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 
        :type group_id: str
        :param pipelines: **参数解释**： 流水线集合。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 
        :type pipelines: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineGroupBindDTOPipelines`]
        """
        
        

        self._group_id = None
        self._pipelines = None
        self.discriminator = None

        self.group_id = group_id
        self.pipelines = pipelines

    @property
    def group_id(self):
        r"""Gets the group_id of this PipelineGroupBindDTO.

        **参数解释**： 分组ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :return: The group_id of this PipelineGroupBindDTO.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this PipelineGroupBindDTO.

        **参数解释**： 分组ID。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :param group_id: The group_id of this PipelineGroupBindDTO.
        :type group_id: str
        """
        self._group_id = group_id

    @property
    def pipelines(self):
        r"""Gets the pipelines of this PipelineGroupBindDTO.

        **参数解释**： 流水线集合。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :return: The pipelines of this PipelineGroupBindDTO.
        :rtype: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineGroupBindDTOPipelines`]
        """
        return self._pipelines

    @pipelines.setter
    def pipelines(self, pipelines):
        r"""Sets the pipelines of this PipelineGroupBindDTO.

        **参数解释**： 流水线集合。 **约束限制**： 不涉及。 **取值范围**： 不涉及。 **默认取值**： 不涉及。 

        :param pipelines: The pipelines of this PipelineGroupBindDTO.
        :type pipelines: list[:class:`huaweicloudsdkcodeartspipeline.v2.PipelineGroupBindDTOPipelines`]
        """
        self._pipelines = pipelines

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PipelineGroupBindDTO):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
