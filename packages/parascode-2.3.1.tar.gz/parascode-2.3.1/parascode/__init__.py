
"""
ParasCode - Complete Python Utility Toolkit
Author: Paras Chourasiya
GitHub: https://github.com/Aptpy
"""

from .__version__ import __version__
from .parascode import (
    ParasCode, pc, cprint, random_string, random_number,
    random_user_agent, get_client, link, expire, clear,
    banner, clear_screen, print_colored, colored,
    render, say, show_fonts, show_colors, show_backgrounds,
    Instagram, Twitter, Tiktok, Facebook, Spotify,
    Email, UserAgent, Curl, Proxy,
    get_country_info, GetMid, coockie, r
)

__all__ = [
    "__version__", "ParasCode", "pc", "cprint", "random_string",
    "random_number", "random_user_agent", "get_client", "link",
    "expire", "clear", "banner", "clear_screen", "print_colored",
    "colored", "render", "say", "show_fonts", "show_colors",
    "show_backgrounds", "Instagram", "Twitter", "Tiktok", "Facebook",
    "Spotify", "Email", "UserAgent", "Curl", "Proxy",
    "get_country_info", "GetMid", "coockie", "r"
]