#!/usr/bin/env python3
"""
ParasCode Command Line Interface
"""

import argparse
import sys
from . import (
    __version__, pc, say, render, show_fonts,
    show_colors, show_backgrounds, Instagram, Twitter
)

def main():
    parser = argparse.ArgumentParser(
        description="ParasCode - Python Utility Toolkit",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  parascode "Hello World" --font block --colors red,blue
  parascode "Python" --font 3d --gradient red,yellow,green
  parascode --instagram cristiano
  parascode --twitter elonmusk
  parascode --list-fonts
        """
    )
    
    parser.add_argument("text", nargs="?", help="Text to render with cFonts")
    parser.add_argument("-f", "--font", default="block", help="Font name (default: block)")
    parser.add_argument("-c", "--colors", help="Colors (comma separated)")
    parser.add_argument("-g", "--gradient", help="Gradient colors (comma separated)")
    parser.add_argument("-a", "--align", default="left", choices=["left", "center", "right"], help="Text alignment")
    parser.add_argument("-b", "--background", help="Background color")
    
    parser.add_argument("--instagram", metavar="USERNAME", help="Get Instagram user info")
    parser.add_argument("--twitter", metavar="USERNAME", help="Get Twitter user info")
    parser.add_argument("--check-email", metavar="EMAIL", help="Check if email exists on Instagram")
    
    parser.add_argument("--list-fonts", action="store_true", help="List all available fonts")
    parser.add_argument("--list-colors", action="store_true", help="List all available colors")
    parser.add_argument("--list-backgrounds", action="store_true", help="List all background colors")
    parser.add_argument("-v", "--version", action="store_true", help="Show version")
    
    args = parser.parse_args()
    
    if args.version:
        print(f"ParasCode v{__version__}")
        return
    
    if args.list_fonts:
        show_fonts()
        return
    
    if args.list_colors:
        show_colors()
        return
    
    if args.list_backgrounds:
        show_backgrounds()
        return
    
    if args.instagram:
        info = Instagram.information(args.instagram)
        if info:
            print(f"\n📱 Instagram: @{args.instagram}")
            print(f"👤 Name: {info.get('name', 'N/A')}")
            print(f"👥 Followers: {info.get('followers', 'N/A')}")
            print(f"📝 Posts: {info.get('post', 'N/A')}")
            print(f"✅ Verified: {info.get('is_verified', False)}")
            print(f"🔒 Private: {info.get('is_private', False)}")
            print(f"📅 Joined: {info.get('date', 'N/A')}")
        else:
            print(f"❌ User @{args.instagram} not found")
        return
    
    if args.twitter:
        info = Twitter.information(args.twitter)
        if info:
            print(f"\n🐦 Twitter: @{args.twitter}")
            print(f"👤 Name: {info.get('name', 'N/A')}")
            print(f"👥 Followers: {info.get('followers', 'N/A')}")
            print(f"📝 Bio: {info.get('bio', 'N/A')}")
            print(f"📍 Location: {info.get('location', 'N/A')}")
            print(f"✅ Verified: {info.get('verified', False)}")
        else:
            print(f"❌ User @{args.twitter} not found")
        return
    
    if args.check_email:
        result = Instagram.CheckEmail(args.check_email)
        if result:
            print(f"✅ Email {args.check_email} is registered on Instagram")
        else:
            print(f"❌ Email {args.check_email} is NOT registered on Instagram")
        return
    
    if args.text:
        colors = args.colors.split(",") if args.colors else None
        gradient = args.gradient.split(",") if args.gradient else None
        
        say(
            args.text,
            font=args.font,
            colors=colors,
            gradient=gradient,
            align=args.align,
            background=args.background or "transparent"
        )
    else:
        parser.print_help()

if __name__ == "__main__":
    main()