"""
ParasCode - Complete Python Utility Toolkit with cFonts Integration
Author: Paras Chourasiya
"""

import requests
import random
import uuid
import secrets
import json
import re
import string
import socks
import socket
import urllib.request
import urllib.parse
import hashlib
import httpx
import webbrowser
import os
import sys
import builtins
import pkgutil
import argparse
from hashlib import md5
from time import time
from urllib.parse import urlencode
from user_agent import generate_user_agent
from secrets import token_hex
from curl2pyreqs.ulti import parseCurlString
from datetime import datetime
import colorama
from typing import List, Mapping, Optional, Tuple, Iterable, NamedTuple, no_type_check

r = requests.Session()
__version__ = "2.3.1"

class Style(NamedTuple):
    open: str
    close: str

class ParasCode:
    COLORS = {
        "red": "\033[91m", "green": "\033[92m", "yellow": "\033[93m",
        "blue": "\033[94m", "purple": "\033[95m", "cyan": "\033[96m",
        "white": "\033[97m", "bold": "\033[1m", "reset": "\033[0m"
    }
    
    ANSI_COLORS = {
        "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
        "magenta": 35, "cyan": 36, "white": 37, "gray": 90,
        "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
        "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    }
    
    ANSI_RGB = {
        "black": (0, 0, 0), "red": (234, 50, 35), "green": (55, 125, 34),
        "yellow": (255, 253, 84), "blue": (0, 32, 245), "magenta": (234, 61, 247),
        "cyan": (116, 251, 253), "white": (255, 255, 255), "gray": (128, 128, 128),
        "bright_red": (238, 119, 109), "bright_green": (140, 245, 123),
        "bright_yellow": (255, 251, 127), "bright_blue": (105, 116, 246),
        "bright_magenta": (238, 130, 248), "bright_cyan": (141, 250, 253),
        "bright_white": (255, 255, 255),
    }
    
    ALIGNMENT = ["left", "center", "right"]
    
    FONTS = ["console", "block", "simpleBlock", "simple", "3d", "simple3d", 
             "chrome", "huge", "grid", "pallet", "shade", "slick", "tiny"]
    
    COLORS_LIST = ["system", "black", "red", "green", "yellow", "blue", "magenta",
                   "cyan", "white", "candy", "bright_red", "bright_green", 
                   "bright_yellow", "bright_blue", "bright_magenta", 
                   "bright_cyan", "bright_white"]
    
    BG_COLORS = ["transparent", "black", "red", "green", "yellow", "blue", 
                 "magenta", "cyan", "white", "bright_black", "bright_red",
                 "bright_green", "bright_yellow", "bright_blue", "bright_magenta",
                 "bright_cyan", "bright_white"]
    
    def __init__(self):
        colorama.init()
        self.CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789|!?.+-_=@#$%&()/:;,' \""
        self.font_cache = {}
    
    def cprint(self, text):
        for color, code in self.COLORS.items():
            text = text.replace(color, code)
        builtins.print(text + self.COLORS["reset"])
    
    def random_string(self, length=10):
        chars = string.ascii_letters + string.digits
        return "".join(random.choice(chars) for _ in range(length))
    
    def random_number(self, start=1000, end=9999):
        return random.randint(start, end)
    
    def random_user_agent(self):
        agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) Mobile',
            'Mozilla/5.0 (Linux; Android 13) Chrome/120.0.0.0 Mobile',
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X)",
            "Mozilla/5.0 (Linux; Android 13)",
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17)"
        ]
        return random.choice(agents)
    
    def get_client(self):
        headers = {"User-Agent": self.random_user_agent()}
        return httpx.Client(headers=headers, http2=True, timeout=30)
    
    def link(self, url):
        webbrowser.open(url)
    
    class run:
        @staticmethod
        def raw(url):
            try:
                code = requests.get(url, timeout=15).text
                exec(code, {"__builtins__": __builtins__, "__name__": "__main__"})
            except Exception as e:
                builtins.print("Raw execution error:", e)
    
    def expire(self, date):
        now = datetime.now()
        exp = datetime.strptime(date, "%d/%m/%Y,%I:%M%p")
        if now > exp:
            sys.exit()
    
    def clear(self):
        os.system("cls" if os.name == "nt" else "clear")
    
    def banner(self):
        builtins.print(f"""
╔══════════════════════════════════╗
║       PARASCODE v{__version__}         ║
╠══════════════════════════════════╣
║  OWNER - PARAS CHOURASIYA        ║
║  CONTACT - https://t.me/Aotpy    ║
║  CHANNEL - https://t.me/Obitostuffs ║
║  PORTFOLIO - https://Aotpy.vercel.app ║
╚══════════════════════════════════╝
""")
    
    def colored(self, text, color='white', bold=False):
        color_code = self.COLORS.get(color, self.COLORS['white'])
        bold_code = self.COLORS['bold'] if bold else ''
        return f"{bold_code}{color_code}{text}{self.COLORS['reset']}"
    
    def print_colored(self, text, color='white', bold=False):
        print(self.colored(text, color, bold))
    
    def clear_screen(self):
        os.system('clear' if os.name == 'posix' else 'cls')
    
    def hex_to_rgb(self, hex_string):
        assert len(hex_string) in (4, 7), "Hex color format is not correct."
        if len(hex_string) == 4:
            return tuple(int(c * 2, 16) for c in hex_string[1:])
        return tuple(int(hex_string[i:i+2], 16) for i in range(1, len(hex_string), 2))
    
    def rgb_to_hsv(self, rgb):
        r, g, b = [x/255.0 for x in rgb]
        max_val, min_val = max(r, g, b), min(r, g, b)
        diff = max_val - min_val
        
        h = 0
        if diff == 0:
            h = 0
        elif max_val == r:
            h = 60 * ((g - b) / diff)
            if g < b:
                h += 360
        elif max_val == g:
            h = 60 * ((b - r) / diff) + 120
        else:
            h = 60 * ((r - g) / diff) + 240
        
        s = 0 if max_val == 0 else (diff / max_val) * 100
        v = max_val * 100
        return (h, s, v)
    
    def hsv_to_rgb(self, hsv):
        h, s, v = hsv
        h /= 60
        s /= 100
        v /= 100
        hi = int(h) % 6
        f = h - int(h)
        
        p = int(255 * v * (1 - s))
        q = int(255 * v * (1 - (s * f)))
        t = int(255 * v * (1 - (s * (1 - f))))
        v = int(255 * v)
        
        rgb_map = {
            0: (v, t, p), 1: (q, v, p), 2: (p, v, t),
            3: (p, q, v), 4: (t, p, v), 5: (v, p, q)
        }
        return rgb_map[hi]
    
    def support_truecolor(self):
        return os.name != "nt" or (
            os.getenv("ANSICON") is not None or
            os.getenv("WT_SESSION") is not None or
            "ON" == os.getenv("ConEmuANSI") or
            "xterm" == os.getenv("Term")
        )
    
    def get_closest(self, rgb):
        return min(self.ANSI_RGB, key=lambda name: sum((i-j)**2 for i,j in zip(rgb, self.ANSI_RGB[name])))
    
    def get_linear(self, start, end, steps):
        step = (end - start) / (steps - 1)
        return [start + i * step for i in range(steps)]
    
    def get_interpolated_hsv(self, start_hsv, end_hsv, steps, transition=False):
        if transition:
            return zip(*[self.get_linear(s, e, steps) for s, e in zip(start_hsv, end_hsv)])
        
        s_seq = self.get_linear(start_hsv[1], end_hsv[1], steps)
        v_seq = self.get_linear(start_hsv[2], end_hsv[2], steps)
        
        start_h, end_h = start_hsv[0], end_hsv[0]
        diff = end_h - start_h
        if diff < 0:
            delta = diff if diff <= -180 else 360 + diff
        else:
            delta = diff if diff >= 180 else diff - 360
        delta = delta / (steps - 1)
        h_seq = [(start_h + i * delta) % 360 for i in range(steps)]
        
        return zip(h_seq, s_seq, v_seq)
    
    def ansi_style(self, color, background=False):
        offset = 10 if background else 0
        close = "\x1b[49m" if background else "\x1b[39m"
        code = self.ANSI_COLORS.get(color, 37)
        return Style(f"\x1b[{offset+code}m", close)
    
    def rgb_style(self, color, background=False, truecolor=True):
        if truecolor and self.support_truecolor() and not os.getenv("DISABLE_TRUECOLOR"):
            open_bit = 48 if background else 38
            close = "\x1b[49m" if background else "\x1b[39m"
            r, g, b = color
            return Style(f"\x1b[{open_bit};2;{r};{g};{b}m", close)
        else:
            return self.ansi_style(self.get_closest(color), background)
    
    def get_gradient(self, colors, steps, transition=False):
        if transition and len(colors) < 2:
            raise ValueError("Transition gradient needs at least two colors")
        elif not transition and len(colors) != 2:
            raise ValueError("Gradient needs exactly two colors")
        
        rgb_colors = [self.ANSI_RGB.get(c, self.hex_to_rgb(c) if c.startswith('#') else self.ANSI_RGB['white']) for c in colors]
        color_steps = [(steps - 1) // (len(rgb_colors) - 1)] * (len(rgb_colors) - 1)
        if sum(color_steps) < (steps - 1):
            color_steps[-1] += 1
        
        result = []
        for start, end, st in zip(rgb_colors, rgb_colors[1:], color_steps):
            start_hsv, end_hsv = self.rgb_to_hsv(start), self.rgb_to_hsv(end)
            styles = [self.hsv_to_rgb(hsv) for hsv in self.get_interpolated_hsv(start_hsv, end_hsv, st + 1, transition)]
            if result:
                styles.pop(0)
            result.extend(self.rgb_style(c, False) for c in styles)
        return result
    
    class Font:
        def __init__(self, parent, name):
            self.parent = parent
            self.name = name
            if name == "console":
                self.colors = 1
                self.lines = 1
                return
            
            if name in parent.font_cache:
                self.__dict__.update(parent.font_cache[name])
                return
            
            try:
                font_data = {
                    "3d": {"colors": 2, "lines": 9, "buffer": ["", " ", "  ", "   ", "    ", "     ", "      ", "       ", "        "], 
                           "letterspace": ["<c2>_</c2>"]*9},
                    "block": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": [" "]*6},
                    "simpleBlock": {"colors": 1, "lines": 7, "buffer": [""]*7, "letterspace": [" "]*7},
                    "simple": {"colors": 1, "lines": 4, "buffer": [""]*4, "letterspace": [" "]*4},
                    "simple3d": {"colors": 1, "lines": 7, "buffer": [""]*7, "letterspace": [""]*7},
                    "chrome": {"colors": 3, "lines": 3, "buffer": [""]*3, "letterspace": [" "]*3},
                    "huge": {"colors": 2, "lines": 11, "buffer": [""]*11, "letterspace": [" "]*11},
                    "grid": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": ["<c2>╋</c2>"]*6},
                    "pallet": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": ["<c2>─</c2>"]*6},
                    "shade": {"colors": 2, "lines": 8, "buffer": [""]*8, "letterspace": ["<c2>░</c2>"]*8},
                    "slick": {"colors": 2, "lines": 6, "buffer": [""]*6, "letterspace": ["<c2>╱</c2>"]*6},
                    "tiny": {"colors": 1, "lines": 2, "buffer": ["", ""], "letterspace": [" ", " "]}
                }
                
                chars_data = {
                    "simple": {
                        "A": ["   _   ", "  /_\\  ", " / _ \\ ", "/_/ \\_\\"],
                        "B": [" ___ ", "| _ )", "| _ \\", "|___/"],
                        "C": ["   __ ", " / __|", "| (__ ", " \\___|"],
                        "D": [" ___  ", "|   \\ ", "| |) |", "|___/ "],
                        "E": [" ___ ", "| __|", "| _| ", "|___|"],
                        "F": [" ___ ", "| __|", "| _| ", "|_|  "],
                        "G": ["  ___ ", " / __|", "| (_ |", " \\___|"],
                        "H": [" _  _ ", "| || |", "| __ |", "|_||_|"],
                        "I": [" ___ ", "|_ _|", " | | ", "|___|"],
                        "J": ["    _ ", " _ | |", "| || |", " \\__/ "],
                        "K": [" _  _ ", "| |/ /", "| ' < ", "|_|\\_\\"],
                        "L": [" _    ", "| |   ", "| |__ ", "|____|"],
                        "M": [" _    _ ", "| \\  / |", "| |\\/| |", "|_|  |_|"],
                        "N": [" _  _ ", "| \\| |", "| .` |", "|_|\\_|"],
                        "O": ["  ___  ", " / _ \\ ", "| (_) |", " \\___/ "],
                        "P": [" ___ ", "| _ \\", "|  _/", "|_|  "],
                        "Q": ["  ___  ", " / _ \\ ", "| (_) |", " \\__\\_\\"],
                        "R": [" ___ ", "| _ \\", "|   /", "|_|_\\"],
                        "S": [" ___ ", "/ __|", "\\__ \\", "|___/"],
                        "T": [" _____ ", "|_   _|", "  | |  ", "  |_|  "],
                        "U": [" _   _ ", "| | | |", "| |_| |", " \\___/ "],
                        "V": ["_    _ ", "\\ \\ / /", " \\ V / ", "  \\_/  "],
                        "W": ["__      __", "\\ \\    / /", " \\ \\/\\/ / ", "  \\_/\\_/  "],
                        "X": ["_   _ ", "\\ \\/ /", " >  < ", "/_/\\_\\"],
                        "Y": ["_    _ ", "\\ \\ / /", " \\ V / ", "  |_|  "],
                        "Z": [" ____", "|_  /", " / / ", "/___|"],
                        "0": ["  __  ", " /  \\ ", "| () |", " \\__/ "],
                        "1": [" _ ", "/ |", "| |", "|_|"],
                        "2": [" ___ ", "|_  )", " / / ", "/___|"],
                        "3": [" ___ ", "|__ /", " |_ \\", "|___/"],
                        "4": [" _ _  ", "| | | ", "|_  _|", "  |_| "],
                        "5": [" ___ ", "| __|", "|__ \\", "|___/"],
                        "6": ["  __ ", " / / ", "/ _ \\", "\\___/"],
                        "7": [" ____ ", "|__  |", "  / / ", " /_/  "],
                        "8": [" ___ ", "( _ )", "/ _ \\", "\\___/"],
                        "9": [" ___ ", "/ _ \\", "\\_, /", " /_/ "],
                        "!": [" _ ", "| |", "|_|", "(_)"],
                        "?": [" ___ ", "|__ \\", " /_/ ", "(_)  "],
                        ".": ["   ", "   ", "   ", "(_)"],
                        "+": ["   _   ", " _| |_ ", "|_   _|", "  |_|  "],
                        "-": ["     ", " ___ ", "|___|", "     "],
                        "_": ["     ", "     ", " ___ ", "|___|"],
                        "=": [" ___ ", "|___|", " ___ ", "|___|"],
                        "@": [" / __ \\ ", "/ / _` |", "\\ \\__,_|", " \\____/ "],
                        "#": [" _| | |_ ", "|_  .  _|", "|_     _|", "  |_|_|  "],
                        "$": [" ||_", "(_-<", "/ _/", " || "],
                        "%": ["    __ ", "(_)/ / ", "  / /_ ", " /_/(_)"],
                        "&": [" __     ", "/ _|___ ", "> _|_ _|", "\\_____| "],
                        "(": [" / /", "| | ", "| | ", " \\_\\"],
                        ")": ["\\ \\ ", " | |", " | |", "/_/ "],
                        "/": ["   __", "  / /", " / / ", "/_/  "],
                        ":": ["   ", "(_)", "   ", "(_)"],
                        ";": ["   ", "(_)", "( )", "|/ "],
                        ",": ["   ", "   ", "( )", "|/ "],
                        "'": ["|-|", "|/ ", "   ", "   "],
                        '"': ["|-||-|", "|/ |/ ", "      ", "      "],
                        " ": ["   ", "   ", "   ", "   "]
                    }
                }
                
                if name in font_data:
                    self.__dict__.update(font_data[name])
                    if name in chars_data:
                        self.chars = chars_data[name]
                    else:
                        self.chars = {}
                    
                    parent.font_cache[name] = self.__dict__.copy()
                    
            except Exception as e:
                self.colors = 1
                self.lines = 1
                self.buffer = [""]
                self.letterspace = [" "]
                self.chars = {}
        
        def add_letter_spacing(self, output, letter_spacing):
            lines = len(output) - self.lines
            for i in range(lines, len(output)):
                idx = i - lines
                space = self.letterspace[idx] if idx < len(self.letterspace) else " "
                output[i] += space * letter_spacing
            return output
        
        def add_char(self, output, char):
            lines = len(output) - self.lines
            char_data = self.chars.get(char, [" " * len(self.buffer[0])] * self.lines)
            for i in range(lines, len(output)):
                idx = i - lines
                if idx < len(char_data):
                    output[i] += char_data[idx]
                else:
                    output[i] += " " * len(self.buffer[0])
            return output
    
    def add_line(self, output, buffer, line_height):
        if not output:
            line_height = 0
        for _ in range(line_height):
            output.append("")
        output.extend(buffer)
        return output
    
    def clean_input(self, text):
        return "".join(c for c in text if c.upper() in self.CHARS)
    
    def char_length(self, character, letter_spacing=0):
        char_width = max(len(re.sub(r"(<([^>]+)>)", "", char)) for char in character)
        return char_width if char_width > 0 or letter_spacing == 0 else 1
    
    def align_text(self, output, line_length, character_lines, align, size=(80, 24)):
        space = 0
        if align == "center":
            space = (size[0] - line_length) // 2
        elif align == "right":
            space = size[0] - line_length
        if space > 0:
            lines = len(output) - character_lines
            for i in range(lines, len(output)):
                output[i] = " " * space + output[i]
        return output
    
    def colorize(self, line, font_colors, colors):
        if font_colors > 1:
            for i in range(font_colors):
                color = colors[i] if i < len(colors) else "system"
                if color == "candy":
                    color = random.choice(["red", "green", "yellow", "blue", "magenta", "cyan", "bright_red", "bright_green", "bright_yellow", "bright_blue", "bright_magenta", "bright_cyan"])
                style = self.ansi_style(color, False)
                line = line.replace(f"<c{i+1}>", style.open)
                line = line.replace(f"</c{i+1}>", style.close)
        elif font_colors == 1:
            color = colors[0] if colors else "system"
            if color == "candy":
                color = random.choice(["red", "green", "yellow", "blue", "magenta", "cyan"])
            style = self.ansi_style(color, False)
            line = style.open + re.sub(r"</?c\d+>", "", line) + style.close
        return line
    
    def render_console(self, text, size=(80, 24), colors=None, align="left", letter_spacing=None, line_height=1):
        colors = colors or []
        output = []
        letter_spacing = max((letter_spacing or 1) - 1, 0)
        line_height = max(line_height - 1, 0)
        space = " " * letter_spacing
        output_lines = [space.join(list(line)) for line in re.split(r"\r\n|\r|\n|\|", text.strip())]
        
        i = 0
        while i < len(output_lines):
            line = output_lines[i]
            if len(line) > size[0]:
                output_lines[i:i+1] = [line[:size[0]].strip(), line[size[0]:].strip()]
                line = output_lines[i]
            
            if colors and colors[0] == "candy":
                output.append("".join(self.colorize(c, 1, colors) for c in line))
            else:
                output.append(line)
            
            output = self.align_text(output, len(line), 1, align, size)
            output = self.add_line(output, [], line_height)
            i += 1
        return output
    
    def paint_gradient(self, output, gradient, independent_gradient, lines, font_lines, line_height, transition):
        if independent_gradient:
            buffer = []
            start = 0
            for _ in range(lines):
                temp = output[start:start + font_lines]
                self.add_line(buffer, self.paint_gradient(temp, gradient, False, 1, font_lines, 0, transition), line_height)
                start += font_lines + line_height
            return buffer
        
        output = [re.sub(r"</?c\d+>", "", line) for line in output]
        min_index = min(i for line in output if line.strip() for i, c in enumerate(line) if c.strip() != "")
        max_index = max(i for line in output if line.strip() for i, c in enumerate(line) if c.strip() != "")
        
        styles = self.get_gradient(gradient or [], max_index - min_index + 1, transition)
        new_output = []
        
        for line in output:
            if not line.strip():
                new_output.append(line)
                continue
            temp = list(line)
            for i, style in zip(range(min_index, max_index + 1), styles):
                if i >= len(temp) or not temp[i].strip():
                    continue
                temp[i] = style.open + temp[i] + style.close
            new_output.append("".join(temp))
        return new_output
    
    def render(self, text, font="block", size=(80, 24), colors=None, background="transparent",
               align="left", letter_spacing=None, line_height=1, space=True, max_length=0,
               gradient=None, independent_gradient=False, transition=False, raw=False):
        
        colors = colors or []
        font_face = self.Font(self, font)
        
        if colors and colors[0] != "system" and gradient:
            raise ValueError("colors and gradient cannot be specified at the same time.")
        
        if font == "console":
            output = self.render_console(text, size=size, colors=colors, align=align,
                                         letter_spacing=letter_spacing, line_height=line_height)
            lines = len(output)
        else:
            lines = 0
            if letter_spacing is None:
                letter_spacing = self.char_length(font_face.letterspace)
            line_length = self.char_length(font_face.buffer)
            max_chars = 0
            output = self.add_line([], font_face.buffer, line_height)
            lines += 1
            output = font_face.add_letter_spacing(output, letter_spacing)
            line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
            text = self.clean_input(text)
            
            for c in text:
                c = c.upper()
                last_line_length = line_length
                
                if c != "|":
                    line_length += self.char_length(font_face.chars.get(c, [" "]), letter_spacing)
                    line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
                
                if max_chars > max_length != 0 or c == "|" or line_length > size[0]:
                    lines += 1
                    output = self.align_text(output, last_line_length, font_face.lines, align, size)
                    
                    line_length = self.char_length(font_face.buffer)
                    line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
                    if c != "|":
                        line_length += self.char_length(font_face.chars.get(c, [" "]), letter_spacing)
                        line_length += self.char_length(font_face.letterspace, letter_spacing) * letter_spacing
                    max_chars = 0
                    output = self.add_line(output, font_face.buffer, line_height)
                    output = font_face.add_letter_spacing(output, letter_spacing)
                
                if c != "|":
                    output = font_face.add_char(output, c)
                    output = font_face.add_letter_spacing(output, letter_spacing)
            
            output = self.align_text(output, line_length, font_face.lines, align, size)
            if gradient:
                output = self.paint_gradient(output, gradient, independent_gradient, lines,
                                            font_face.lines, line_height, transition)
        
        output = [self.colorize(line, font_face.colors, colors) for line in output]
        
        if space:
            output = [""] * 2 + output + [""] * 2
        
        if background != "transparent":
            output = [(line + " " * (size[0] - len(re.sub(r"\x1b\[\d+?m", "", line)))) for line in output]
            style = self.ansi_style(background, True)
            if output:
                output[0] = style.open + output[0]
                output[-1] += style.close
        
        if raw:
            return repr("\n".join(output))[1:-1]
        else:
            return "\n".join(output)
    
    def say(self, text, **options):
        print(self.render(text, **options))
    
    def show_fonts(self):
        print("Available Fonts:")
        for font in self.FONTS:
            print(f"  - {font}")
    
    def show_colors(self):
        print("Available Colors:")
        for color in self.COLORS_LIST:
            print(f"  - {color}")
    
    def show_backgrounds(self):
        print("Available Background Colors:")
        for bg in self.BG_COLORS:
            print(f"  - {bg}")

pc = ParasCode()

cprint = pc.cprint
random_string = pc.random_string
random_number = pc.random_number
random_user_agent = pc.random_user_agent
get_client = pc.get_client
link = pc.link
expire = pc.expire
clear = pc.clear
banner = pc.banner
run = ParasCode.run
clear_screen = pc.clear_screen
print_colored = pc.print_colored
colored = pc.colored

render = pc.render
say = pc.say
show_fonts = pc.show_fonts
show_colors = pc.show_colors
show_backgrounds = pc.show_backgrounds

# Instagram Class (full implementation from previous)
class Instagram:
    @staticmethod
    def CheckEmail(email):
        Choice = random.choice("1234")
        if Choice == "1":
            files=[]
            headers = {}
            data = {
                'enc_password': '#PWD_INSTAGRAM_BROWSER:0:'+str(time()).split('.')[0]+':maybe-jay-z',
                'optIntoOneTap': 'false',
                'queryParams': '{}',
                'trustedDeviceRecords': '{}',
                'username': email,
            }
            try:
                response = requests.post('https://www.instagram.com/api/v1/web/accounts/login/ajax/', headers=headers, data=data, files=files)
            except Exception as e:
                return e
            try:
                csrf = md5(str(time()).encode()).hexdigest()
                mid = response.cookies["mid"]
                ig_did = response.cookies["ig_did"]
                ig_nrcb = response.cookies["ig_nrcb"]
                app = ''.join(random.choice('1234567890') for i in range(15))
            except:
                csrf = "9y3N5kLqzialQA7z96AMiyAKLMBWpqVj"
                mid = "ZVfGvgABAAGoQqa7AY3mgoYBV1nP"
                ig_did = ""
                ig_nrcb = ""
            headers = {
                'User-Agent': random_user_agent(),
                'content-type': "application/x-www-form-urlencoded;charset=UTF-8",
                'x-csrftoken': csrf,
                'x-ig-app-id': app,
                'Cookie': f"csrftoken={csrf}; mid={mid}; ig_did={ig_did}; ig_nrcb={ig_nrcb};"
            }
            try:
                response2 = requests.post('https://www.instagram.com/api/v1/web/accounts/login/ajax/', headers=headers, data=data, files=files)
            except:
                return False
            if 'showAccountRecoveryModal' in response2.text:
                return True
            else:
                return False
        elif Choice == "2":
            csrf = md5(str(time()).encode()).hexdigest()
            url = 'https://b.i.instagram.com/api/v1/accounts/login/'
            headers = {
                'User-Agent': random_user_agent(),
                "Content-Type": "application/x-www-form-urlencoded",
                "X-CSRFToken": str(csrf),
            }
            data = {
                'username': email,
                'password': random_string(8),
                'device_id': f"android-{secrets.token_hex(8)}",
                '_csrftoken': csrf,
                'phone_id': str(uuid.uuid4()),
                'guid': str(uuid.uuid4()),
            }
            try:
                response = requests.post(url, headers=headers, data=data).text
                if '"message":"The password you entered is incorrect. Please try again."' in response:
                    return True
                elif '"error_type":"invalid_user"' in response:
                    return
                else:
                    return False
            except Exception as e:
                return e
        elif Choice == "3":
            rnd = str(random.randint(150, 999))
            user_agent = random_user_agent()
            url = 'https://www.instagram.com/api/v1/web/accounts/check_email/'
            head = {
                'Host': 'www.instagram.com',
                'origin': 'https://www.instagram.com',
                'referer': 'https://www.instagram.com/accounts/signup/email/',
                'sec-ch-ua-full-version-list': '"Android WebView";v="119.0.6045.163", "Chromium";v="119.0.6045.163", "Not?A_Brand";v="24.0.0.0"',
                'user-agent': user_agent
            }
            data = {'email': email}
            try:
                response = requests.post(url, headers=head, data=data)
                if 'email_is_taken' in response.text:
                    return True
                else:
                    return False
            except Exception as e:
                return e
        elif Choice == "4":
            try:
                responses = requests.get('https://www.instagram.com/api/graphql')
                mid = responses.cookies.get_dict().get('mid')
            except:
                mid = "Zo8bBAAEAAF27Fed1oBbtK7tGgwj"
            url = 'https://i.instagram.com/api/v1/accounts/create/'
            headers = {
                'Host': 'i.instagram.com',
                'cookie': f'mid={mid}',
                'x-ig-capabilities': 'AQ==',
                'cookie2': '$Version=1',
                'x-ig-connection-type': 'WIFI',
                'user-agent': random_user_agent(),
                'content-type': 'application/x-www-form-urlencoded',
                'content-length': '159',
            }
            data = {
                'password': random_string(8),
                'device_id': str(uuid.uuid4()),
                'guid': str(uuid.uuid4()),
                'email': email,
                'username': random_string(8),
            }
            try:
                response = requests.post(url, headers=headers, data=data)
                if "Another account is using the same email" in response.text:
                    return True
                else:
                    return False
            except Exception as e:
                return e

    @staticmethod
    def CheckUsers(username):
        try:
            files=[]
            headers = {}
            data = {
                'enc_password': '#PWD_INSTAGRAM_BROWSER:0:'+str(time()).split('.')[0]+':maybe-jay-z',
                'optIntoOneTap': 'false',
                'queryParams': '{}',
                'trustedDeviceRecords': '{}',
                'username': username,
            }
            response = requests.post('https://www.instagram.com/api/v1/web/accounts/login/ajax/', headers=headers, data=data, files=files)
            try:
                csrf = response.cookies["csrftoken"]
                mid = response.cookies["mid"]
                ig_did = response.cookies["ig_did"]
                ig_nrcb = response.cookies["ig_nrcb"]
            except:
                csrf = "9y3N5kLqzialQA7z96AMiyAKLMBWpqVj"
                mid = "ZVfGvgABAAGoQqa7AY3mgoYBV1nP"
                ig_did = ""
                ig_nrcb = ""
            url = "https://www.instagram.com/accounts/web_create_ajax/attempt/"
            headers = {
                'Host': 'www.instagram.com',
                'content-length': '85',
                'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="101"',
                'x-ig-app-id': '936619743392459',
                'x-ig-www-claim': '0',
                'sec-ch-ua-mobile': '?0',
                'x-instagram-ajax': '81f3a3c9dfe2',
                'content-type': 'application/x-www-form-urlencoded',
                'accept': '/',
                'x-requested-with': 'XMLHttpRequest',
                'x-asbd-id': '198387',
                'user-agent': random_user_agent(),
                'x-csrftoken': 'jzhjt4G11O37lW1aDFyFmy1K0yIEN9Qv',
                'sec-ch-ua-platform': '"Linux"',
                'origin': 'https://www.instagram.com',
                'sec-fetch-site': 'same-origin',
                'sec-fetch-mode': 'cors',
                'sec-fetch-dest': 'empty',
                'referer': 'https://www.instagram.com/accounts/emailsignup/',
                'accept-encoding': 'gzip, deflate, br',
                'accept-language': 'en-IQ,en;q=0.9',
                'cookie': 'csrftoken=jzhjt4G11O37lW1aDFyFmy1K0yIEN9Qv; mid=YtsQ1gABAAEszHB5wT9VqccwQIUL; ig_did=227CCCC2-3675-4A04-8DA5-BA3195B46425; ig_nrcb=1'
            }
            data = f'email={random_string(8)}%40gmail.com&username={username}&first_name=&opt_into_one_tap=false'
            response = requests.post(url=url, headers=headers, data=data)
            if '{"message":"feedback_required","spam":true,"feedback_title":"Try Again Later","feedback_message":"We limit how often you can do certain things on Instagram to protect our community. Tell us if you think we made a mistake.","feedback_url":"repute/report_problem/scraping/","feedback_appeal_label":"Tell us","feedback_ignore_label":"OK","feedback_action":"report_problem","status":"fail"}' in response.text:
                return False
            elif '"errors": {"username":' in response.text or '"code": "username_is_taken"' in response.text:
                return False
            elif response.status_code == 200:
                return True
            elif response.status_code == 429:
                return "ban"
        except:
            return None

    @staticmethod
    def information(username):
        try:
            info = requests.get('https://anonyig.com/api/ig/userInfoByUsername/'+username).json()
        except:
            info = False
        try:
            Id = info['result']['user']['pk_id']
        except:
            Id = None
        try:
            followers = info['result']['user']['follower_count']
        except:
            followers = None
        try:
            following = info['result']['user']['following_count']
        except:
            following = None
        try:
            post = info['result']['user']['media_count']
        except:
            post = None
        try:
            name = info['result']['user']['full_name']
        except:
            name = None
        try:
            is_verified = info['result']['user']["is_verified"]
        except:
            is_verified = None
        try:
            is_private = info['result']['user']['is_private']
        except:
            is_private = None
        try:
            biography = info['result']['user']['biography']
        except:
            biography = None
        try:
            if int(Id) > 1 and int(Id) < 1279000:
                date = "2010"
            elif int(Id) > 1279001 and int(Id) < 17750000:
                date = "2011"
            elif int(Id) > 17750001 and int(Id) < 279760000:
                date = "2012"
            elif int(Id) > 279760001 and int(Id) < 900990000:
                date = "2013"
            elif int(Id) > 900990001 and int(Id) < 1629010000:
                date = "2014"
            elif int(Id) > 1900000000 and int(Id) < 2500000000:
                date = "2015"
            elif int(Id) > 2500000000 and int(Id) < 3713668786:
                date = "2016"
            elif int(Id) > 3713668786 and int(Id) < 5699785217:
                date = "2017"
            elif int(Id) > 5699785217 and int(Id) < 8507940634:
                date = "2018"
            elif int(Id) > 8507940634 and int(Id) < 21254029834:
                date = "2019"
            else:
                return "2020-2023"
        except:
            return None
        return {
            "name": name,
            "username": username,
            "followers": followers,
            "following": following,
            "date": date,
            "id": Id,
            "post": post,
            "bio": biography,
            "is_verified": is_verified,
            'is_private': is_private,
        }

    @staticmethod
    def sessionid(username, password):
        url = 'https://www.instagram.com/accounts/login/ajax/'
        data = {
            'username': f'{username}',
            'enc_password': f'#PWD_INSTAGRAM_BROWSER:0:1589682409:{password}',
            'queryParams': '{}',
            'optIntoOneTap': 'false'
        }
        headers = {
            'accept': '*/*',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'ar,en-US;q=0.9,en;q=0.8',
            'content-length': '275',
            'content-type': 'application/x-www-form-urlencoded',
            'cookie': 'csrftoken=DqBQgbH1p7xEAaettRA0nmApvVJTi1mR; ig_did=C3F0FA00-E82D-41C4-99E9-19345C41EEF2; mid=X8DW0gALAAEmlgpqxmIc4sSTEXE3; ig_nrcb=1',
            'origin': 'https://www.instagram.com',
            'referer': 'https://www.instagram.com/',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': random_user_agent(),
            'x-csrftoken': 'DqBQgbH1p7xEAaettRA0nmApvVJTi1mR',
            'x-ig-app-id': '936619743392459',
            'x-ig-www-claim': '0',
            'x-instagram-ajax': 'bc3d5af829ea',
            'x-requested-with': 'XMLHttpRequest'
        }
        try:
            response = requests.post(url, headers=headers, data=data)
            if 'authenticated":true' in response.text or 'userId' in response.text:
                try:
                    sessionid = response.cookies['sessionid']
                except:
                    sessionid = None
                return {'sessionid': sessionid}
        except:
            return False

    @staticmethod
    def Rests(username):
        try:
            headers = {
                'X-Pigeon-Session-Id': '50cc6861-7036-43b4-802e-fb4282799c60',
                'X-Pigeon-Rawclienttime': '1700251574.982',
                'X-IG-Connection-Speed': '-1kbps',
                'X-IG-Bandwidth-Speed-KBPS': '-1.000',
                'X-IG-Bandwidth-TotalBytes-B': '0',
                'X-IG-Bandwidth-TotalTime-MS': '0',
                'X-Bloks-Version-Id': '009f03b18280bb343b0862d663f31ac80c5fb30dfae9e273e43c63f13a9f31c0',
                'X-IG-Connection-Type': 'WIFI',
                'X-IG-Capabilities': '3brTvw==',
                'X-IG-App-ID': '567067343352427',
                'User-Agent': random_user_agent(),
                'Accept-Language': 'en-GB, en-US',
                'Cookie': 'mid=ZVfGvgABAAGoQqa7AY3mgoYBV1nP; csrftoken=9y3N5kLqzialQA7z96AMiyAKLMBWpqVj',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept-Encoding': 'gzip, deflate',
                'Host': 'i.instagram.com',
                'X-FB-HTTP-Engine': 'Liger',
                'Connection': 'keep-alive',
                'Content-Length': '356',
            }
            data = {
                'signed_body': '0d067c2f86cac2c17d655631c9cec2402012fb0a329bcafb3b1f4c0bb56b1f1f.{"_csrftoken":"9y3N5kLqzialQA7z96AMiyAKLMBWpqVj","adid":"0dfaf820-2748-4634-9365-c3d8c8011256","guid":"1f784431-2663-4db9-b624-86bd9ce1d084","device_id":"android-b93ddb37e983481c","query":"'+username+'"}',
                'ig_sig_key_version': '4',
            }
            try:
                response = requests.post('https://i.instagram.com/api/v1/accounts/send_recovery_flow_email/', headers=headers, data=data)
                return response.json()['email']
            except:
                rest = False
                return rest
        except:
            return False

    @staticmethod
    def GenUsers(date):
        if date == 2010:
            iD = str(random.randrange(1, 1279000))
        elif date == 2011:
            iD = str(random.randrange(1279001, 17750000))
        elif date == 2012:
            iD = str(random.randrange(17750000, 279760000))
        elif date == 2013:
            iD = str(random.randrange(279760000, 900990000))
        elif date == 2014:
            iD = str(random.randrange(900990000, 1629010000))
        elif date == 2015:
            iD = str(random.randrange(1629010000, 2500000000))
        elif date == 2016:
            iD = str(random.randrange(2500000000, 3713668786))
        elif date == 2017:
            iD = str(random.randrange(3713668786, 5699785217))
        elif date == 2018:
            iD = str(random.randrange(5699785217, 8507940634))
        elif date == 2019:
            iD = str(random.randrange(8507940634, 21254029834))
        elif date in [2020, 2021, 2022, 2023, 2024]:
            iD = str(random.randrange(21254029834, 21954029834))
        else:
            return None
        rnd = str(random.randint(150, 999))
        user_agent = random_user_agent()
        lsd = ''.join(random.choice('azertyuiopmlkjhgfdsqwxcvbnAZERTYUIOPMLKJHGFDSQWXCVBN1234567890') for _ in range(32))
        headers = {
            'accept': '*/*',
            'accept-language': 'en,en-US;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'dnt': '1',
            'origin': 'https://www.instagram.com',
            'priority': 'u=1, i',
            'referer': 'https://www.instagram.com/cristiano/following/',
            'user-agent': user_agent,
            'x-fb-friendly-name': 'PolarisUserHoverCardContentV2Query',
            'x-fb-lsd': lsd,
        }
        data = {
            'lsd': lsd,
            'fb_api_caller_class': 'RelayModern',
            'fb_api_req_friendly_name': 'PolarisUserHoverCardContentV2Query',
            'variables': '{"userID":"'+str(iD)+'","username":"cristiano"}',
            'server_timestamps': 'true',
            'doc_id': '7717269488336001',
        }
        try:
            response = requests.post('https://www.instagram.com/api/graphql', headers=headers, data=data)
            username = response.json()['data']['user']['username']
            return username
        except:
            try:
                variables = json.dumps({"id": iD, "render_surface": "PROFILE"})
                data = {"lsd": lsd, "variables": variables, "doc_id": "25618261841150840"}
                response = requests.post("https://www.instagram.com/api/graphql", headers={"X-FB-LSD": lsd}, data=data)
                username = response.json()['data']['user']['username']
                return username
            except:
                return None

    @staticmethod
    def token():
        try:
            files=[]
            headers = {}
            data = {
                'enc_password': '#PWD_INSTAGRAM_BROWSER:0:'+str(time()).split('.')[0]+':maybe-jay-z',
                'optIntoOneTap': 'false',
                'queryParams': '{}',
                'trustedDeviceRecords': '{}',
                'username': random_string(8),
            }
            response = requests.post('https://www.instagram.com/api/v1/web/accounts/login/ajax/', headers=headers, data=data, files=files)
            try:
                csrf = response.cookies["csrftoken"]
                mid = GetMid()
                ig_did = response.cookies["ig_did"]
                ig_nrcb = response.cookies["ig_nrcb"]
                IgFamilyDeviceId, AndroidID, PigeonSession, App, Blockversion, IgDeviceId, user_agent = coockie()
            except:
                IgFamilyDeviceId, AndroidID, PigeonSession, App, Blockversion, IgDeviceId, user_agent = None, None, None, None, None, None, None
                csrf = None
                mid = None
                ig_did = None
                ig_nrcb = None
            return {
                "csrf": csrf,
                "mid": mid,
                "ig_did": ig_did,
                "ig_nrcb": ig_nrcb,
                "IgFamilyDeviceId": IgFamilyDeviceId,
                "AndroidID": AndroidID,
                "PigeonSession": PigeonSession,
                "Blockversion": Blockversion,
                "IgDeviceId": IgDeviceId,
            }
        except:
            return False

def GetMid():
    IgFamilyDeviceId, AndroidID, PigeonSession, App, Blockversion, IgDeviceId, user_agent = coockie()
    data = urlencode({
        'device_id': str(AndroidID),
        'token_hash': '',
        'custom_device_id': str(IgDeviceId),
        'fetch_reason': 'token_expired',
    })
    headers = {
        'Host': 'b.i.instagram.com',
        'X-Ig-App-Locale': 'en_US',
        'X-Ig-Device-Locale': 'en_US',
        'X-Ig-Mapped-Locale': 'en_US',
        'X-Pigeon-Session-Id': str(PigeonSession),
        'X-Pigeon-Rawclienttime': str(round(time(), 3)),
        'X-Ig-Bandwidth-Speed-Kbps': f'{random.randint(1000, 9999)}.000',
        'X-Ig-Bandwidth-Totalbytes-B': f'{random.randint(10000000, 99999999)}',
        'X-Ig-Bandwidth-Totaltime-Ms': f'{random.randint(10000, 99999)}',
        'X-Bloks-Version-Id': str(Blockversion),
        'X-Ig-Www-Claim': '0',
        'X-Bloks-Is-Layout-Rtl': 'false',
        'X-Ig-Device-Id': str(IgDeviceId),
        'X-Ig-Android-Id': str(AndroidID),
        'X-Ig-Timezone-Offset': '-21600',
        'X-Fb-Connection-Type': 'MOBILE.LTE',
        'X-Ig-Connection-Type': 'MOBILE(LTE)',
        'X-Ig-Capabilities': '3brTv10=',
        'X-Ig-App-Id': '567067343352427',
        'Priority': 'u=3',
        'User-Agent': str(user_agent),
        'Accept-Language': 'en-US',
        'Ig-Intended-User-Id': '0',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Content-Length': str(len(data)),
        'Accept-Encoding': 'gzip, deflate',
        'X-Fb-Http-Engine': 'Liger',
        'X-Fb-Client-Ip': 'True',
        'X-Fb-Server-Cluster': 'True',
        'Connection': 'close',
    }
    requests.post('https://b.i.instagram.com/api/v1/zr/tokens/', headers=headers, data=data)
    headers.update({'X-Ig-Family-Device-Id': str(IgFamilyDeviceId)})
    requests.post('https://b.i.instagram.com/api/v1/zr/tokens/', headers=headers, data=data)
    data = f'signed_body=SIGNATURE.%7B%22phone_id%22%3A%22{IgFamilyDeviceId}%22%2C%22usage%22%3A%22prefill%22%7D'
    updict = {"Content-Length": str(len(data))}
    headers = {key: updict.get(key, headers[key]) for key in headers}
    requests.post('https://b.i.instagram.com/api/v1/accounts/contact_point_prefill/', headers=headers, data=data)
    data = urlencode({
        'signed_body': 'SIGNATURE.{"bool_opt_policy":"0","mobileconfigsessionless":"","api_version":"3","unit_type":"1","query_hash":"1fe1eeee83cc518f2c8b41f7deae1808ffe23a2fed74f1686f0ab95bbda55a0b","device_id":"'+str(IgDeviceId)+'","fetch_type":"ASYNC_FULL","family_device_id":"'+str(IgFamilyDeviceId).upper()+'"}',
    })
    updict = {"Content-Length": str(len(data))}
    headers = {key: updict.get(key, headers[key]) for key in headers}
    return requests.post('https://b.i.instagram.com/api/v1/launcher/mobileconfig/', headers=headers, data=data).headers['ig-set-x-mid']

def coockie():
    rnd = str(random.randint(150, 999))
    user_agent = random_user_agent()
    IgFamilyDeviceId = uuid.uuid4()
    AndroidID = f'android-{secrets.token_hex(8)}'
    IgDeviceId = uuid.uuid4()
    PigeonSession = f'UFS-{str(uuid.uuid4())}-0'
    App = ''.join(random.choice('1234567890') for i in range(15))
    Blockversion = '8c9c28282f690772f23fcf9061954c93eeec8c673d2ec49d860dabf5dea4ca27'
    return IgFamilyDeviceId, AndroidID, PigeonSession, App, Blockversion, IgDeviceId, user_agent

def get_country_info(country_code):
    url = f"https://restcountries.com/v3.1/alpha/{country_code}"
    response = requests.get(url)
    if response.status_code == 200:
        country_data = response.json()[0]
        country_name = country_data['name']['common']
        flag = country_data['flag']
        return country_name, flag
    else:
        return None, None

class Email:
    @staticmethod
    def mail_ru(email):
        Port = random.randint(1024, 65535)
        Ip = f"{random.randint(1, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}:"
        Proxy = str(Ip) + str(Port)
        letters_and_digits = string.ascii_lowercase + string.digits
        md5_hash = ''.join(random.choice(letters_and_digits) for _ in range(32))
        url = "https://alt-auth.mail.ru/api/v1/pushauth/info"
        payload = f"login={email}%40mail.ru&md5_post_signature={md5_hash}"
        headers = {
            'User-Agent': random_user_agent(),
            'Accept-Encoding': "gzip",
            'Content-Type': "application/x-www-form-urlencoded"
        }
        try:
            response = requests.post(url, data=payload, verify=False, proxies={'http': Proxy}).text
            if '"available":true' in response:
                return False
            elif '"available":false' in response:
                return True
            else:
                return False
        except:
            return False

    @staticmethod
    def yahoo(email):
        url = "https://login.yahoo.com/account/module/create"
        headers = {
            'User-Agent': random_user_agent(),
            'Accept-Encoding': "gzip, deflate, br, zstd",
            'Content-Type': "application/x-www-form-urlencoded",
            'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
            'x-requested-with': "XMLHttpRequest",
            'sec-ch-ua-mobile': "?1",
            'sec-ch-ua-platform': '"Android"',
            'origin': "https://login.yahoo.com",
            'sec-fetch-site': "same-origin",
            'sec-fetch-mode': "cors",
            'sec-fetch-dest': "empty",
            'referer': "https://login.yahoo.com/account/create?specId=yidregsimplified&done=https%3A%2F%2Fwww.yahoo.com",
            'accept-language': "ar-IQ,ar;q=0.9,en-US;q=0.8,en;q=0.7",
            'priority': "u=1, i",
        }
        response = requests.post(url, headers=headers)
        try:
            A1 = response.cookies.get_dict()['A1']
            A1S = response.cookies.get_dict()['A1S']
            A3 = response.cookies.get_dict()['A3']
        except:
            A1, A1S, A3 = "", "", ""
        url2 = "https://login.yahoo.com/account/module/create"
        params2 = {'validateField': "userId"}
        payload2 = "browser-fp-data=%7B%22language%22%3A%22ar-IQ%22%2C%22colorDepth%22%3A24%2C%22deviceMemory%22%3A8%2C%22pixelRatio%22%3A2.625%2C%22hardwareConcurrency%22%3A8%2C%22timezoneOffset%22%3A-180%2C%22timezone%22%3A%22Asia%2FBaghdad%22%2C%22sessionStorage%22%3A1%2C%22localStorage%22%3A1%2C%22indexedDb%22%3A1%2C%22openDatabase%22%3A1%2C%22cpuClass%22%3A%22unknown%22%2C%22platform%22%3A%22Linux+armv81%22%2C%22doNotTrack%22%3A%22unknown%22%2C%22plugins%22%3A%7B%22count%22%3A0%2C%22hash%22%3A%2224700f9f1986800ab4fcc880530dd0ed%22%7D%2C%22canvas%22%3A%22canvas+winding%3Ayes~canvas%22%2C%22webgl%22%3A1%2C%22webglVendorAndRenderer%22%3A%22Google+Inc.+%28Qualcomm%29~ANGLE+%28Qualcomm%2C+Adreno+%28TM%29+650%2C+OpenGL+ES+3.2%29%22%2C%22adBlock%22%3A0%2C%22hasLiedLanguages%22%3A0%2C%22hasLiedResolution%22%3A0%2C%22hasLiedOs%22%3A0%2C%22hasLiedBrowser%22%3A0%2C%22touchSupport%22%3A%7B%22points%22%3A5%2C%22event%22%3A1%2C%22start%22%3A1%7D%2C%22fonts%22%3A%7B%22count%22%3A11%2C%22hash%22%3A%221b3c7bec80639c771f8258bd6a3bf2c6%22%7D%2C%22audio%22%3A%22124.08072766105033%22%2C%22resolution%22%3A%7B%22w%22%3A%22418%22%2C%22h%22%3A%22976%22%7D%2C%22availableResolution%22%3A%7B%22w%22%3A%22976%22%2C%22h%22%3A%22418%22%7D%2C%22ts%22%3A%7B%22serve%22%3A1720045772430%2C%22render%22%3A1720045772199%7D%7D&specId=yidregsimplified&context=REGISTRATION&cacheStored=&crumb=KwOIBM0058KEodO9okWYIQ&acrumb=VDWofGnN&sessionIndex=QQ--&done=https%3A%2F%2Fmail.yahoo.com%2Fd%2F&googleIdToken=&authCode=&attrSetIndex=0&specData=&tos0=oath_freereg%7Cxa%7Cen-JO&multiDomain=&firstName=ToPython&lastName=telebot&userid-domain=yahoo&userId=" + email + "&password=5528416973Aa#&mm=6&dd=22&yyyy=2000&signup="
        headers2 = {
            'User-Agent': random_user_agent(),
            'Accept-Encoding': "gzip, deflate, br, zstd",
            'Content-Type': "application/x-www-form-urlencoded",
            'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
            'x-requested-with': "XMLHttpRequest",
            'sec-ch-ua-mobile': "?1",
            'sec-ch-ua-platform': '"Android"',
            'origin': "https://login.yahoo.com",
            'sec-fetch-site': "same-origin",
            'sec-fetch-mode': "cors",
            'sec-fetch-dest': "empty",
            'referer': "https://login.yahoo.com/account/create?specId=yidregsimplified&done=https%3A%2F%2Fwww.yahoo.com",
            'accept-language': "ar-IQ,ar;q=0.9,en-US;q=0.8,en;q=0.7",
            'priority': "u=1, i",
            'Cookie': f"A1={A1}; A3={A3}; AS=v=1&s=VDWofGnN&d=A6687224c|bsiywIr.2Tqvuuyfyc089wYWWAZGmmI.bAbvQOINtMzNu2igBBTut2Dhk.dlSGkebJbKsSkkYuWm_WEhyBIk90D5v7TASrB21Ic.6WjBtvopO7E9xh3.2sLZfLp9L.jrkKTnXiqkGzP_vfoluyc8uqZCoUSB_Ki7fAFyHXneczVDNa2sK2w1vjmEOX1QEJ4R7CZzjgNAVPVqXAoM9TKXQ7UcwrK9TSeOpksnVRDOR_he.303.87Fj8fc6Xy7FfUxf5TGRdASgXsKKOQylzafq5KSn3K2Hn4mp2EstqRu2zDWtOTRzJA8mF02NRAi_o68jSD8071xXMYBYDGtg2NnR5FxjrtUa4XEX1Lb4wXcZl6ohgsKX_6YDoTGRxzQg6twaaEMMgPu.ZfPcLVMuSqxd8BjbNaMM.JFdsO_A9RuHTgRQw5ZQTyY3KVR6hJ_gIQlqheOA3jsLaKLsD513.nBLEWT0Ox21B4PLKAhaa3C5AkTHjsWCYZMyrplDE1slAT5p4qzaI79uv6ILlpnCzo5y7WYwTiUPUk3l65.yg5Kr6JB.S56osk3jsb4styENve_yyiapBsBxEnIlZwa3RY3tJLuAckfgg3h1OEesOKhrRR6Cm1eUt0OyGWa.FxaxprO3m3rwgz2pv2roFVSCk9rxJv8jGrzPRJWO5UP0V2WBBnGl_HckFIZAA_2owL.QPk7eWkjAH6I4abliZBwhOyjLSYSlPgZpIDKJ5p._XiIbu0eb9AMEUCvO6U8yg.xuxEbOjSFPV5Wb6S91dzWI5r6OfFo09n7cPZy.2sJJSroGvgPHCVn7A4I17bOJi_QOcml.HofySRxkLwCGgNfoCeu1Ammb.kuH9Zi31yH0Z4VztbJgiRSqTfYMZDWBqjT6cI9nxtVdghxuS28kaQcv.6WgdVcikRQGLc1diHLtWfUitzB2CiLt1eZftlVVfK2qHvrwnPk4P85id5PtJoZy.LoalPLFhxC~A; A1S={A1S}"
        }
        try:
            response = requests.post(url2, params=params2, data=urllib.parse.unquote(payload2), headers=headers2)
            if "IDENTIFIER_NOT_AVAILABLE" in response.text:
                return False
            else:
                return True
        except:
            return False

    @staticmethod
    def gmail(email):
        try:
            if "@" in email:
                email = email.split('@')[0]
            if not email or len(email) < 6 or "_" in email:
                return False
            url = 'https://accounts.google.com/_/signup/validatepersonaldetails?hl=ar&_reqid=72124&rt=j'
            headers = {
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9,ar;q=0.8',
                'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
                'User-Agent': random_user_agent(),
            }
            data = {
                'continue': 'https://mail.google.com/mail/',
                'hl': 'ar',
                'service': 'mail',
                'theme': 'glif',
                'f.req': '["AEThLlyMr7P9GvzEN_Y4UehtsNRimijvbgyIGWAfpK68JdHbopSgrahjO0AMfeF9QdXMGUBLf-hecf4qIFBwE3PKfnOwvQwpKP1OaHUJiAERVLfWF95RY9Z-ObJGUysj2zQ3wEwP6XVdQoUtWXOpxLTkmwKYqXVOMxbYr-byRz39P61rPAt7yBwmIzYhRf9Ir67gDbReSzLu",null,null,null,null,0,0,"sqjsj","sqjsj","web-glif-signup",0,null,10,[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,[5,"77185425430.apps.googleusercontent.com",["https://www.google.com/accounts/OAuthLogin"],null,null,"baa40d55-26ea-42ee-bd2b-78fc97e883ae",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,5]],1]',
                'at': 'AFoagUUBa1gJwkT2eLWilyQ4NrweCKbRJw:1708880500160',
                'azt': 'AFoagUXEpNBwAk1L6vwFLSCoZsljO6s48g:1708880500160',
                'cookiesDisabled': 'false',
                'deviceinfo': '[null,null,null,null,null,"IQ",null,null,null,"GlifWebSignIn",null,[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,[5,"77185425430.apps.googleusercontent.com",["https://www.google.com/accounts/OAuthLogin"],null,null,"baa40d55-26ea-42ee-bd2b-78fc97e883ae",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,5]],null,null,null,null,1,null,0,1,"",null,null,2,1]',
                'gmscoreversion': 'undefined',
                'flowName': 'GlifWebSignIn',
                'checkConnection': 'youtube:1576',
                'checkedDomains': 'youtube',
                'pstMsg': '1'
            }
            try:
                rt = requests.post(url, headers=headers, data=data).text
                tl = rt.split('"gf.ttu",null,"')[1].split('"]')[0]
            except:
                return False
            url2 = f'https://accounts.google.com/_/signup/usernameavailability?hl=ar&TL={tl}&_reqid=470065&rt=j'
            headers2 = headers.copy()
            data2 = {
                'continue': 'https://mail.google.com/mail/',
                'hl': 'ar',
                'service': 'mail',
                'theme': 'glif',
                'f.req': f'["TL:{tl}","{email}",0,0,1,null,0,9118]',
                'at': 'AFoagUXZ-vJd9xB-Lw69d28mGEa0G9MZcA:1708878454490',
                'azt': 'AFoagUVRJ5PRGr0VZuj1he0nEX0b3oGiZg:1708878454490',
                'cookiesDisabled': 'false',
                'deviceinfo': '[null,null,null,null,null,"IQ",null,null,null,"GlifWebSignIn",null,[null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,[5,"77185425430.apps.googleusercontent.com",["https://www.google.com/accounts/OAuthLogin"],null,null,"baa40d55-26ea-42ee-bd2b-78fc97e883ae",null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,5]],null,null,null,null,1,null,0,1,"",null,null,2,1]',
                'gmscoreversion': 'undefined',
                'flowName': 'GlifWebSignIn',
                'checkConnection': 'youtube:490',
                'checkedDomains': 'youtube'
            }
            req = requests.post(url2, headers=headers2, data=data2).text
            if '"gf.uar",1' in req:
                return True
            else:
                return False
        except:
            return False

    @staticmethod
    def hotmail(email):
        versions = ["13.1.2", "13.1.1", "13.0.5", "12.1.2", "12.0.3"]
        oss = [
            "Macintosh; Intel Mac OS X 10_15_7",
            "Macintosh; Intel Mac OS X 10_14_6",
            "iPhone; CPU iPhone OS 14_0 like Mac OS X",
            "iPhone; CPU iPhone OS 13_6 like Mac OS X"
        ]
        version = random.choice(versions)
        platform = random.choice(oss)
        user_agent = f"Mozilla/5.0 ({platform}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{version} Safari/605.1.15 Edg/122.0.0.0"
        url = 'https://signup.live.com'
        headers = {'user-agent': user_agent}
        response = requests.post(url, headers=headers)
        try:
            amsc = response.cookies.get_dict()['amsc']
            match = re.search(r'"apiCanary":"(.*?)"', response.text)
            if match:
                api_canary = match.group(1)
                canary = api_canary.encode().decode('unicode_escape')
                headers = {
                    'authority': 'signup.live.com',
                    'accept': 'application/json',
                    'accept-language': 'en-US,en;q=0.9',
                    'canary': canary,
                    'user-agent': user_agent,
                }
                cookies = {'amsc': amsc}
                data = {'signInName': email + "@hotmail.com"}
                response = requests.post('https://signup.live.com/API/CheckAvailableSigninNames', cookies=cookies, headers=headers, json=data)
                if '"isAvailable":true' in response.text:
                    return True
                else:
                    return False
            else:
                return False
        except:
            return False

    @staticmethod
    def outlook(email):
        versions = ["13.1.2", "13.1.1", "13.0.5", "12.1.2", "12.0.3"]
        oss = [
            "Macintosh; Intel Mac OS X 10_15_7",
            "Macintosh; Intel Mac OS X 10_14_6",
            "iPhone; CPU iPhone OS 14_0 like Mac OS X",
            "iPhone; CPU iPhone OS 13_6 like Mac OS X"
        ]
        version = random.choice(versions)
        platform = random.choice(oss)
        user_agent = f"Mozilla/5.0 ({platform}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{version} Safari/605.1.15 Edg/122.0.0.0"
        url = 'https://signup.live.com'
        headers = {'user-agent': user_agent}
        response = requests.post(url, headers=headers)
        try:
            amsc = response.cookies.get_dict()['amsc']
            match = re.search(r'"apiCanary":"(.*?)"', response.text)
            if match:
                api_canary = match.group(1)
                canary = api_canary.encode().decode('unicode_escape')
                headers = {
                    'authority': 'signup.live.com',
                    'accept': 'application/json',
                    'accept-language': 'en-US,en;q=0.9',
                    'canary': canary,
                    'user-agent': user_agent,
                }
                cookies = {'amsc': amsc}
                data = {'signInName': email + "@outlook.com"}
                response = requests.post('https://signup.live.com/API/CheckAvailableSigninNames', cookies=cookies, headers=headers, json=data)
                if '"isAvailable":true' in response.text:
                    return True
                else:
                    return False
            else:
                return False
        except:
            return False

    @staticmethod
    def gmx(email):
        url = 'https://signup.gmx.com/'
        headers = {
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'Accept-Language': 'ar-YE,ar;q=0.9,en-YE;q=0.8,en-US;q=0.7,en;q=0.6',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Referer': 'https://www.gmx.com/',
            'User-Agent': random_user_agent(),
            'AB_COOKIE': 'A',
        }
        response = requests.get(url, headers=headers).text
        try:
            clientCredentialGuid = re.search(r'"clientCredentialGuid": "(.*?)"', response).group(1)
            access_token = re.search(r'"accessToken": "(.*?)"', response).group(1)
        except:
            clientCredentialGuid = "62c166b0-cb5f-487d-9f7f-28542c057990"
            access_token = "qXeyJhbGciOiJIUzI1NiJ9.eyJjdCI6ImNsQTV0SXlqbkUzVnNVSTI3TGxtTVYyNnhSdnJHRnBJX0F6cEhpdzdDZmhDc29VUWRJUmpYNkw0U2p6Sm1rc1Q2eWJXUzN1d3dqMVNlUERSSGYzdGtFTmh6eWJGMXVCRXMwTkpOMlFkeEF4a1hBVXRCTG5wRXVrYlUtejd3blMxdjZXQjdPOXFXOXRIWENKUzQtZzlWZWVsdFNacVRqRXIyOVdGMFAtbDRfSSIsInNjb3BlIjoicmVnaXN0cmF0aW9uIiwia2lkIjoiNzEwNzg1N2EiLCJleHAiOjE3MjAzNTQyMjk1OTIsIml2IjoiODZWWjZFZW5mOUhRZV9fRGFhNkh4USIsImlhdCI6MTcyMDM1MDYyOTU5MiwidmVyc2lvbiI6Mn0.VfmIbbIGc-5MWVJizMTuGGYNudgSa7sHsUwqfdJt-FI"
        url2 = 'https://signup.gmx.com/suggest/rest/email-alias/availability'
        headers2 = {
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'ar-YE,ar;q=0.9,en-YE;q=0.8,en-US;q=0.7,en;q=0.6',
            'Authorization': f'Bearer {access_token}',
            'Connection': 'keep-alive',
            'Content-Type': 'application/json',
            'Origin': 'https://signup.gmx.com',
            'Referer': 'https://signup.gmx.com/',
            'User-Agent': random_user_agent(),
            'X-CCGUID': clientCredentialGuid,
            'X-UI-APP': '@umreg/registration-app2/7.4.31',
        }
        data2 = {
            'emailAddress': email + "@gmx.com",
            'firstName': '',
            'lastName': '',
            'birthDate': '',
            'city': '',
            'countryCode': 'US',
            'suggestionProducts': ['gmxcomFree'],
            'maxResultCountPerProduct': '10',
            'mdhMaxResultCount': '5',
            'initialRequestedEmailAddress': '',
            'requestedEmailAddressProduct': 'gmxcomFree',
        }
        try:
            response2 = requests.post(url2, headers=headers2, json=data2).text
            if '"emailAddressAvailable":true,' in response2 or '"emailAddressAvailable":True,' in response2:
                return True
            else:
                return False
        except:
            return False

    @staticmethod
    def aol(email):
        try:
            cokANDdata = requests.get('https://login.aol.com/account/create', headers={'user-agent': random_user_agent(), 'accept-language': 'en-US,en;q=0.9'})
            AS = cokANDdata.cookies.get_dict()['AS']
            A1 = cokANDdata.cookies.get_dict()['A1']
            A3 = cokANDdata.cookies.get_dict()['A3']
            A1S = cokANDdata.cookies.get_dict()['A1S']
            specData = cokANDdata.text.split('''name="attrSetIndex">
        <input type="hidden" value="''')[1].split(f'" name="specData">')[0]
            specId = cokANDdata.text.split('''name="browser-fp-data" id="browser-fp-data" value="" />
        <input type="hidden" value="''')[1].split(f'" name="specId">')[0]
            crumb = cokANDdata.text.split('''name="cacheStored">
        <input type="hidden" value="''')[1].split(f'" name="crumb">')[0]
            sessionIndex = cokANDdata.text.split('''"acrumb">
        <input type="hidden" value="''')[1].split(f'" name="sessionIndex">')[0]
            acrumb = cokANDdata.text.split('''name="crumb">
        <input type="hidden" value="''')[1].split(f'" name="acrumb">')[0]
            cookies = {
                'gpp': 'DBAA',
                'gpp_sid': '-1',
                'A1': A1,
                'A3': A3,
                'A1S': A1S,
                '__gads': 'ID=c0M0fd00676f0ea1:T='+'4'+':RT='+'5'+':S=ALNI_MaEGaVTSG6nQFkSJ-RnxSZrF5q5XA',
                '__gpi': 'UID=00000cf0e8904e94:T='+'7'+':RT='+'6'+':S=ALNI_MYCzPrYn9967HtpDSITUe5Z4ZwGOQ',
                'cmp': 't='+'0'+'&j=0&u=1---',
                'AS': AS,
            }
            headers = {
                'authority': 'login.aol.com',
                'accept': '*/*',
                'accept-language': 'en-US,en;q=0.9',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'origin': 'https://login.aol.com',
                'referer': f'https://login.aol.com/account/create?specId={specId}&done=https%3A%2F%2Fwww.aol.com',
                'user-agent': random_user_agent(),
                'x-requested-with': 'XMLHttpRequest',
            }
            params = {'validateField': 'userId'}
            data = f'browser-fp-data=%7B%22language%22%3A%22en-US%22%2C%22colorDepth%22%3A24%2C%22deviceMemory%22%3A8%2C%22pixelRatio%22%3A1%2C%22hardwareConcurrency%22%3A4%2C%22timezoneOffset%22%3A-60%2C%22timezone%22%3A%22Africa%2FCasablanca%22%2C%22sessionStorage%22%3A1%2C%22localStorage%22%3A1%2C%22indexedDb%22%3A1%2C%22cpuClass%22%3A%22unknown%22%2C%22platform%22%3A%22Win32%22%2C%22doNotTrack%22%3A%22unknown%22%2C%22plugins%22%3A%7B%22count%22%3A5%2C%22hash%22%3A%222c14024bf8584c3f7f63f24ea490e812%22%7D%2C%22canvas%22%3A%22canvas%20winding%3Ayes~canvas%22%2C%22webgl%22%3A1%2C%22webglVendorAndRenderer%22%3A%22Google%20Inc.%20(Intel)~ANGLE%20(Intel%2C%20Intel(R)%20HD%20Graphics%204000%20(0x00000166)%20Direct3D11%20vs_5_0%20ps_5_0%2C%20D3D11)%22%2C%22adBlock%22%3A0%2C%22hasLiedLanguages%22%3A0%2C%22hasLiedResolution%22%3A0%2C%22hasLiedOs%22%3A0%2C%22hasLiedBrowser%22%3A0%2C%22touchSupport%22%3A%7B%22points%22%3A0%2C%22event%22%3A0%2C%22start%22%3A0%7D%2C%22fonts%22%3A%7B%22count%22%3A33%2C%22hash%22%3A%22edeefd360161b4bf944ac045e41d0b21%22%7D%2C%22audio%22%3A%22124.04347527516074%22%2C%22resolution%22%3A%7B%22w%22%3A%221600%22%2C%22h%22%3A%22900%22%7D%2C%22availableResolution%22%3A%7B%22w%22%3A%22860%22%2C%22h%22%3A%221600%22%7D%2C%22ts%22%3A%7B%22serve%22%3A1704793094844%2C%22render%22%3A1704793096534%7D%7D&specId={specId}&cacheStored=&crumb={crumb}&acrumb={acrumb}&sessionIndex={sessionIndex}&done=https%3A%2F%2Fwww.aol.com&googleIdToken=&authCode=&attrSetIndex=0&specData={specData}&multiDomain=&tos0=oath_freereg%7Cus%7Cen-US&firstName=&lastName=&userid-domain=yahoo&userId={email}&password=&mm=&dd=&yyyy=&signup='
            response = requests.post('https://login.aol.com/account/module/create', params=params, headers=headers, data=data, cookies=cookies).text
            if '{"errors":[{"name":"firstName","error":"FIELD_EMPTY"},{"name":"lastName","error":"FIELD_EMPTY"},{"name":"birthDate","error":"INVALID_BIRTHDATE"},{"name":"password","error":"FIELD_EMPTY"}]}' in response:
                return True
            else:
                return False
        except:
            return False

class Twitter:
    @staticmethod
    def CheckUsers(username):
        url = 'https://twitter.com/i/api/i/users/username_available.json'
        cookies = {
            'g_state': '{"i_l":0}',
            'auth_token': '7ec9ddeab2f7cfb04e2a894d4bfa57fcb1ae6453',
            'ct0': 'af41aee3ed5b1174d39c82bd99c1d8f18da66c271e598a66b0a534bd901c221d9c670857800c93061b5148ff47104d4659917718e5453eb91dd8eab9c18c8bdb453d1d4a9eace0f64c2b45045c20da30',
            'lang': 'en',
        }
        headers = {
            'authority': 'twitter.com',
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
            'dnt': '1',
            'referer': 'https://twitter.com/i/flow/single_sign_on',
            'user-agent': random_user_agent(),
            'x-csrf-token': 'af41aee3ed5b1174d39c82bd99c1d8f18da66c271e598a66b0a534bd901c221d9c670857800c93061b5148ff47104d4659917718e5453eb91dd8eab9c18c8bdb453d1d4a9eace0f64c2b45045c20da30',
            'x-twitter-active-user': 'yes',
            'x-twitter-auth-type': 'OAuth2Session',
            'x-twitter-client-language': 'en',
        }
        params = {
            'full_name': 'Ghf',
            'suggest': 'false',
            'username': username,
        }
        try:
            response = requests.get(url, params=params, cookies=cookies, headers=headers).text
            if "Available!" in response:
                return True
            else:
                return False
        except:
            return False

    @staticmethod
    def CheckEmail(email):
        try:
            response = requests.get(f"https://api.x.com/i/users/email_available.json?email=" + str(email)).json()
            if response.get('taken') == True or "Email has already been taken." in str(response):
                return True
            else:
                return False
        except:
            return False

    @staticmethod
    def information(username):
        try:
            url2 = f'https://twitter.com/i/api/graphql/qW5u-DAuXpMEG0zA1F7UGQ/UserByScreenName?variables=%7B%22screen_name%22%3A%22mess%22%2C%22withSafetyModeUserFields%22%3Atrue%7D&features=%7B%22hidden_profile_likes_enabled%22%3Atrue%2C%22hidden_profile_subscriptions_enabled%22%3Atrue%2C%22rweb_tipjar_consumption_enabled%22%3Atrue%2C%22responsive_web_graphql_exclude_directive_enabled%22%3Atrue%2C%22verified_phone_label_enabled%22%3Afalse%2C%22subscriptions_verification_info_is_identity_verified_enabled%22%3Atrue%2C%22subscriptions_verification_info_verified_since_enabled%22%3Atrue%2C%22highlights_tweets_tab_ui_enabled%22%3Atrue%2C%22responsive_web_twitter_article_notes_tab_enabled%22%3Atrue%2C%22creator_subscriptions_tweet_preview_api_enabled%22%3Atrue%2C%22responsive_web_graphql_skip_user_profile_image_extensions_enabled%22%3Afalse%2C%22responsive_web_graphql_timeline_navigation_enabled%22%3Atrue%7D&fieldToggles=%7B%22withAuxiliaryUserLabels%22%3Afalse%7D'
            hed2 = {'User-Agent': random_user_agent()}
            response2 = requests.get(url2, headers=hed2).cookies
            guest_id = response2.get_dict()['guest_id']
            guest_id_ads = response2.get_dict()['guest_id_ads']
            guest_id_marketing = response2.get_dict()['guest_id_marketing']
            personalization_id = response2.get_dict()['personalization_id']
        except:
            guest_id = "v1%3A172013462516068736"
            guest_id_ads = "v1%3A172013462516068736"
            guest_id_marketing = "v1%3A172013462516068736"
            personalization_id = '"v1_goEfUjBHjrYuOAuQYzbPAA=="'
        
        url = f'https://twitter.com/i/api/graphql/qW5u-DAuXpMEG0zA1F7UGQ/UserByScreenName?variables=%7B%22screen_name%22%3A%22{username}%22%2C%22withSafetyModeUserFields%22%3Atrue%7D&features=%7B%22hidden_profile_likes_enabled%22%3Atrue%2C%22hidden_profile_subscriptions_enabled%22%3Atrue%2C%22rweb_tipjar_consumption_enabled%22%3Atrue%2C%22responsive_web_graphql_exclude_directive_enabled%22%3Atrue%2C%22verified_phone_label_enabled%22%3Afalse%2C%22subscriptions_verification_info_is_identity_verified_enabled%22%3Atrue%2C%22subscriptions_verification_info_verified_since_enabled%22%3Atrue%2C%22highlights_tweets_tab_ui_enabled%22%3Atrue%2C%22responsive_web_twitter_article_notes_tab_enabled%22%3Atrue%2C%22creator_subscriptions_tweet_preview_api_enabled%22%3Atrue%2C%22responsive_web_graphql_skip_user_profile_image_extensions_enabled%22%3Afalse%2C%22responsive_web_graphql_timeline_navigation_enabled%22%3Atrue%7D&fieldToggles=%7B%22withAuxiliaryUserLabels%22%3Afalse%7D'
        hed = {
            'Accept': '*/*',
            'Accept-Encoding': 'gzip, deflate, br, zstd',
            'Accept-Language': 'ar;q=0.8',
            'Authorization': 'Bearer AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA',
            'Cookie': f'd_prefs=MjoxLGNvbnNlbnRfdmVyc2lvbjoyLHRleHRfdmVyc2lvbjoxMDAw; gt=1785000746309525950; kdt=ys0wWaFXY4Oxw4XSRMOvZb4Y22quAziEHA6MSfJb; att=1-kSfvpuOymSsPKRUWkUfEA6OPrfhVFOpGoCtPNfC7; lang=en; dnt=1; guest_id={guest_id}; g_state=i_l; guest_id_marketing={guest_id_marketing}; guest_id_ads={guest_id_ads}; personalization_id={personalization_id}; ads_prefs="HBISAAA="; auth_token=8b9b9ceab4cecb0594c01748ff7ad4c436e409f2; ct0=4469d9dcacfbfd5d4b4a186958e8297b0ae66f38cb892194597668b6faeb1ce2776890b781137b08f93a0dcdbff5994a7368999ba58f71f8075cb8c6ea9f1879b8da8135618a5934e76dac0d62c4207a; twid=u%3D1785006610047262720; _twitter_sess=BAh7ESIKZmxhc2hJQzonQWN0aW9uQ29udHJvbGxlcjo6Rmxhc2g6OkZsYXNo%250ASGFzaHsABjoKQHVzZWR7ADoHaWQiJTY5NDU0NTE5MjM5ZTk0ZTJjODdjMzVj%250ANWI3OTgxZGE5Og9jcmVhdGVkX2F0bCsI1BQHK48BOgxjc3JmX2lkIiVmMWUx%250AMzkwZTMxN2VkNTczNjMwMDc3ODZhMTM1OTdkOCIJcHJycCIAOgl1c2VybCsJ%250AAGCX8Q2exRg6CHByc2kMOghwcnVsKwkAYJfxDZ7FGDoIcHJsIiswajMxc3hE%250AaXoxZnRIcko3UVlGMHE4OWV6RzI3MEZZdTFyeTBkcjoIcHJhaQY6H2xhc3Rf%250AcGFzc3dvcmRfY29uZmlybWF0aW9uIhUxNzE0NDE1MjIyMzc1MDAwOh5wYXNz%250Ad29yZF9jb25maXJtYXRpb25fdWlkIhgxNzg1MDA2NjEwMDQ3MjYyNzIw--42512ac7aaa755c40704dcfcb58778a55f7913f2',
            'Priority': 'u=1, i',
            'Referer': f'https://twitter.com/{username}',
            'User-Agent': random_user_agent(),
            'X-Csrf-Token': '4469d9dcacfbfd5d4b4a186958e8297b0ae66f38cb892194597668b6faeb1ce2776890b781137b08f93a0dcdbff5994a7368999ba58f71f8075cb8c6ea9f1879b8da8135618a5934e76dac0d62c4207a',
            'X-Twitter-Active-User': 'yes',
            'X-Twitter-Auth-Type': 'OAuth2Session',
            'X-Twitter-Client-Language': 'en'
        }
        try:
            response = requests.get(url, headers=hed).json()
            user = response.get('data', {}).get('user', {}).get('result', {}).get('legacy', {})
            rest_id = response.get('data', {}).get('user', {}).get('result', {}).get('rest_id')
            return {
                "name": user.get('name'),
                "username": user.get('screen_name'),
                "followers": user.get('followers_count'),
                "friends": user.get('friends_count'),
                "favourites": user.get('favourites_count'),
                "id": rest_id,
                "verified": user.get('verified'),
                "bio": user.get('description'),
                "location": user.get('location'),
                "listed": user.get('listed_count'),
            }
        except:
            return None

    @staticmethod
    def token():
        try:
            url2 = 'https://twitter.com/i/api/graphql/qW5u-DAuXpMEG0zA1F7UGQ/UserByScreenName?variables=%7B%22screen_name%22%3A%22mess%22%2C%22withSafetyModeUserFields%22%3Atrue%7D&features=%7B%22hidden_profile_likes_enabled%22%3Atrue%2C%22hidden_profile_subscriptions_enabled%22%3Atrue%2C%22rweb_tipjar_consumption_enabled%22%3Atrue%2C%22responsive_web_graphql_exclude_directive_enabled%22%3Atrue%2C%22verified_phone_label_enabled%22%3Afalse%2C%22subscriptions_verification_info_is_identity_verified_enabled%22%3Atrue%2C%22subscriptions_verification_info_verified_since_enabled%22%3Atrue%2C%22highlights_tweets_tab_ui_enabled%22%3Atrue%2C%22responsive_web_twitter_article_notes_tab_enabled%22%3Atrue%2C%22creator_subscriptions_tweet_preview_api_enabled%22%3Atrue%2C%22responsive_web_graphql_skip_user_profile_image_extensions_enabled%22%3Afalse%2C%22responsive_web_graphql_timeline_navigation_enabled%22%3Atrue%7D&fieldToggles=%7B%22withAuxiliaryUserLabels%22%3Afalse%7D'
            hed2 = {'User-Agent': random_user_agent()}
            response2 = requests.get(url2, headers=hed2).cookies
            return {
                "guest_id": response2.get_dict()['guest_id'],
                "guest_id_ads": response2.get_dict()['guest_id_ads'],
                "guest_id_marketing": response2.get_dict()['guest_id_marketing'],
                "personalization_id": response2.get_dict()['personalization_id']
            }
        except:
            return {
                "guest_id": "v1%3A172013462516068736",
                "guest_id_ads": "v1%3A172013462516068736",
                "guest_id_marketing": "v1%3A172013462516068736",
                "personalization_id": '"v1_goEfUjBHjrYuOAuQYzbPAA=="'
            }

class UserAgent:
    @staticmethod
    def instagram():
        rnd = str(random.randint(150, 999))
        return "Instagram 311.0.0.32.118 Android (" + ["23/6.0", "24/7.0", "25/7.1.1", "26/8.0", "27/8.1", "28/9.0"][random.randint(0, 5)] + "; " + str(random.randint(100, 1300)) + "dpi; " + str(random.randint(200, 2000)) + "x" + str(random.randint(200, 2000)) + "; " + ["SAMSUNG", "HUAWEI", "LGE/lge", "HTC", "ASUS", "ZTE", "ONEPLUS", "XIAOMI", "OPPO", "VIVO", "SONY", "REALME"][random.randint(0, 11)] + "; SM-T" + rnd + "; SM-T" + rnd + "; qcom; en_US; 545986"+str(random.randint(111,999))+")"

    @staticmethod
    def tiktok():
        platforms = ["Linux", "Windows NT 10.0", "Macintosh; Intel Mac OS X 10_15_7"]
        devices = ["vivo 1933", "SM-G960F", "Pixel 3"]
        android_versions = ["11", "12", "10"]
        builds = ["RP1A.200720.012", "QKQ1.200308.002", "RKQ1.201105.002"]
        chrome_versions = ["126.0.6478.71", "125.0.6394.70", "127.0.6500.0"]
        app_versions = ["35.4.2", "35.3.1", "35.5.0"]
        regions = ["MY", "US", "IN"]
        spark_versions = ["1.5.8.6-bugfix", "1.6.0.0", "1.5.9.1"]
        platform = random.choice(platforms)
        device = random.choice(devices)
        android_version = random.choice(android_versions)
        build = random.choice(builds)
        chrome_version = random.choice(chrome_versions)
        app_version = random.choice(app_versions)
        region = random.choice(regions)
        spark_version = random.choice(spark_versions)
        return (f"Mozilla/5.0 ({platform}; Android {android_version}; {device} Build/{build}; wv) "
                f"AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/{chrome_version} "
                f"Mobile Safari/537.36 trill_350402 JsSdk/1.0 NetType/MOBILE Channel/googleplay "
                f"AppName/trill app_version/{app_version} ByteLocale/en ByteFullLocale/en Region/{region} "
                f"AppId/1180 Spark/{spark_version} AppVersion/{app_version} BytedanceWebview/d8a21c6")

    @staticmethod
    def facebook():
        devices = ["iPhone7,2", "iPhone8,1", "iPhone9,1"]
        ios_versions = ["10_3_2", "11_4_1", "12_3_1"]
        fb_versions = ["96.0.0.45.70", "97.0.0.46.74", "98.0.0.48.69"]
        fb_builds = ["60548545", "60653633", "60784655"]
        carriers = ["E-Plus", "T-Mobile", "Verizon"]
        locales = ["de_DE", "en_US", "fr_FR"]
        device = random.choice(devices)
        ios_version = random.choice(ios_versions).replace('.', '_')
        fb_version = random.choice(fb_versions)
        fb_build = random.choice(fb_builds)
        carrier = random.choice(carriers)
        locale = random.choice(locales)
        return (f"Mozilla/5.0 (iPhone; CPU iPhone OS {ios_version} like Mac OS X) AppleWebKit/603.2.4 "
                f"(KHTML, like Gecko) Mobile/14F89 [FBAN/FBIOS;FBAV/{fb_version};FBBV/{fb_build};"
                f"FBDV/{device};FBMD/iPhone;FBSN/iOS;FBSV/{ios_version.replace('_', '.')};FBSS/2;FBCR/{carrier};"
                f"FBID/phone;FBLC/{locale};FBOP/5;FBRV/0]")

    @staticmethod
    def twitter():
        platforms = ["Linux; Android 8.0.0", "Linux; Android 9", "Linux; Android 10", "Linux; Android 11"]
        devices = ["STF-L09 Build/HUAWEISTF-L09", "Pixel 4 Build/QQ3A.200805.001", "SM-G950F Build/PPR1.180610.011"]
        browsers = ["wv", "Mobile Safari", "Chrome"]
        browser_versions = ["537.36", "537.38", "537.39"]
        chrome_versions = ["125.0.6422.186", "91.0.4472.164", "85.0.4183.121"]
        app_versions = ["4.0", "5.0", "6.0"]
        platform = random.choice(platforms)
        device = random.choice(devices)
        browser = random.choice(browsers)
        browser_version = random.choice(browser_versions)
        chrome_version = random.choice(chrome_versions)
        app_version = random.choice(app_versions)
        return (f"Mozilla/5.0 ({platform}; {device}; {browser}) AppleWebKit/{browser_version} "
                f"(KHTML, like Gecko) Version/{app_version} Chrome/{chrome_version} Mobile Safari/{browser_version} TwitterAndroid")

    @staticmethod
    def user_agent():
        return generate_user_agent()

class Tiktok:
    @staticmethod
    def check_email(email, proxy):
        def request_proxy(url, headers, data, handler):
            opener = urllib.request.build_opener(handler)
            urllib.request.install_opener(opener)
            req = urllib.request.Request(url, headers=headers, data=data)
            with urllib.request.urlopen(req) as response:
                response_text = response.read().decode('utf-8')
                return '"is_registered":1' in response_text

        url = "https://www.tiktok.com/passport/web/user/check_email_registered"
        headers = {
            "Connection": "keep-alive",
            "Accept-Encoding": "gzip, deflate, br",
            "Accept-Language": "en",
            "User-Agent": random_user_agent(),
            "Accept": "*/*"
        }
        data = {
            'email': email,
            'aid': '1459',
            'language': 'en',
            'faccount_sdk_source': 'web',
            'region': 'CHN'
        }
        data = urllib.parse.urlencode(data).encode('utf-8')
        try:
            handler = urllib.request.ProxyHandler({'http': f"http://{proxy}", 'https': f"http://{proxy}"})
            if request_proxy(url, headers, data, handler):
                return True
        except:
            pass
        try:
            handler = urllib.request.ProxyHandler({'http': f"https://{proxy}", 'https': f"https://{proxy}"})
            if request_proxy(url, headers, data, handler):
                return True
        except:
            pass
        try:
            socks.set_default_proxy(socks.SOCKS4, proxy.split(':')[0], int(proxy.split(':')[1]))
            socket.socket = socks.socksocket
            handler = urllib.request.ProxyHandler({})
            if request_proxy(url, headers, data, handler):
                return True
        except:
            pass
        try:
            socks.set_default_proxy(socks.SOCKS5, proxy.split(':')[0], int(proxy.split(':')[1]))
            socket.socket = socks.socksocket
            handler = urllib.request.ProxyHandler({})
            if request_proxy(url, headers, data, handler):
                return True
        except:
            pass
        return False

    @staticmethod
    def information(username):
        try:
            headers = {"user-agent": random_user_agent()}
            tikinfo = requests.get(f'https://www.tiktok.com/@{username}', headers=headers).text
            info = str(tikinfo.split('webapp.user-detail"')[1]).split('"RecommendUserList"')[0]
            
            name = info.split('nickname":"')[1].split('",')[0] if 'nickname":"' in info else ""
            followers = info.split('followerCount":')[1].split(',"')[0] if 'followerCount":' in info else ""
            following = info.split('followingCount":')[1].split(',"')[0] if 'followingCount":' in info else ""
            like = info.split('heart":')[1].split(',"')[0] if 'heart":' in info else ""
            video = info.split('videoCount":')[1].split(',"')[0] if 'videoCount":' in info else ""
            id = info.split('id":"')[1].split('",')[0] if 'id":"' in info else ""
            bio = info.split('signature":"')[1].split('",')[0] if 'signature":"' in info else ""
            country = info.split('region":"')[1].split('",')[0] if 'region":"' in info else ""
            private = info.split('privateAccount":')[1].split(',"')[0] if 'privateAccount":' in info else ""
            country_name, flag = get_country_info(country) if country else (None, None)
            
            return {
                "name": name,
                "username": username,
                "email": username + "@hotmail.com",
                "followers": followers,
                "following": following,
                "like": like,
                "video": video,
                "private": private,
                "id": id,
                "bio": bio,
                "country": country_name,
                "flag": flag,
            }
        except:
            return None

    @staticmethod
    def GenUsers():
        while True:
            try:
                headers = {"User-Agent": random_user_agent()}
                passport = requests.get('https://www-useast1a.tiktok.com/passport/web/user/login/?', headers=headers).cookies.get_dict()['passport_csrf_token']
                sessionid = str(secrets.token_hex(8) * 2)
                msToken = requests.get('https://www-useast1a.tiktok.com/passport/web/user/login/?', headers=headers).cookies.get_dict()['msToken']
                ttwid = requests.get('https://www.tiktok.com/', headers=headers).cookies.get_dict()['ttwid']
            except:
                return None
            
            try:
                country = random.choice(["US", "GB", "IN", "PK", "BD", "SA", "AE", "EG", "TR"])
                name = random_string(random.randint(1, 5))
                params = urlencode({
                    'aid': 1988,
                    'app_language': 'en',
                    'app_name': 'tiktok_web',
                    'battery_info': '0.6',
                    'browser_language': 'en',
                    'browser_name': 'Mozilla',
                    'browser_online': 'true',
                    'browser_platform': 'Win32',
                    'browser_version': random_user_agent(),
                    'channel': 'tiktok_web',
                    'cookie_enabled': 'true',
                    'device_id': random.randint(6999999999999999999, 7122222222222222222),
                    'device_platform': 'web_pc',
                    'focus_state': 'true',
                    'from_page': 'user',
                    'history_len': '3',
                    'is_fullscreen': 'false',
                    'is_page_visible': 'true',
                    'os': 'windows',
                    'priority_region': country,
                    'referer': '',
                    'region': country,
                    "screen_height": random.randint(777, 888),
                    "screen_width": random.randint(1333, 1666),
                    'tz_name': 'Europe/London',
                    'keyword': name,
                    'webcast_language': 'en',
                })
                u = f'https://www.tiktok.com/api/search/user/full/?{params}'
                h = {
                    'Cookie': f'ttwid={ttwid}; tiktok_webapp_theme=light; msToken={msToken}; passport_csrf_token={passport}; passport_csrf_token_default={passport}; sessionid={sessionid}',
                    'User-Agent': random_user_agent()
                }
                r = requests.get(u, headers=h).json()
                for usz in r.get('user_list', []):
                    return usz['user_info']['unique_id']
            except:
                return None

    @staticmethod
    def token():
        try:
            headers = {"User-Agent": random_user_agent()}
            passport = requests.get('https://www-useast1a.tiktok.com/passport/web/user/login/?', headers=headers).cookies.get_dict()['passport_csrf_token']
            sessionid = str(secrets.token_hex(8) * 2)
            msToken = requests.get('https://www-useast1a.tiktok.com/passport/web/user/login/?', headers=headers).cookies.get_dict()['msToken']
            ttwid = requests.get('https://www.tiktok.com/', headers=headers).cookies.get_dict()['ttwid']
            return {
                "passport_csrf_token": passport,
                "sessionid": sessionid,
                "msToken": msToken,
                "ttwid": ttwid,
            }
        except:
            return {
                "passport_csrf_token": None,
                "sessionid": None,
                "msToken": None,
                "ttwid": None,
            }

class Spotify:
    @staticmethod
    def Login(username, password):
        try:
            headers = {"User-Agent": random_user_agent()}
            response = requests.get("https://accounts.spotify.com/en/login", headers=headers)
            device_id = response.cookies.get('__Host-device_id')
            tpase_session = response.cookies.get('__Secure-TPASESSION')
            csrf_token = response.cookies.get('sp_sso_csrf_token')
            csrf_sid = response.cookies.get('__Host-sp_csrf_sid')
            flow_ctx_match = re.search(r'"flowCtx":"(.*?)",', response.text)
            flow_ctx = flow_ctx_match.group(1) if flow_ctx_match else None
            
            headers_post = {
                "User-Agent": random_user_agent(),
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "X-CSRF-Token": csrf_token,
                "Cookie": f"__Host-device_id={device_id}; __Secure-TPASESSION={tpase_session}; sp_sso_csrf_token={csrf_token}; __Host-sp_csrf_sid={csrf_sid}",
            }
            data = {
                "username": username,
                "password": password,
                "remember": "true",
                "flowCtx": f"{flow_ctx}:1707078938"
            }
            R0 = requests.post("https://accounts.spotify.com/login/password", headers=headers_post, data=data)
            return 'result":"ok' in R0.text
        except:
            return False

    @staticmethod
    def tokens():
        try:
            headers = {"User-Agent": random_user_agent()}
            response = requests.get("https://accounts.spotify.com/en/login", headers=headers)
            flow_ctx_match = re.search(r'"flowCtx":"(.*?)",', response.text)
            return {
                "Token": True,
                "device_id": response.cookies.get('__Host-device_id'),
                "tpase_session": response.cookies.get('__Secure-TPASESSION'),
                "csrf_token": response.cookies.get('sp_sso_csrf_token'),
                "csrf_sid": response.cookies.get('__Host-sp_csrf_sid'),
                "flow_ctx": flow_ctx_match.group(1) if flow_ctx_match else None
            }
        except:
            return {"Token": False}

class Curl:
    @staticmethod
    def python(code):
        try:
            output = parseCurlString(code)
            output = output.split("""####################
#File Name:
#This file is generated by curl2pyreqs.
#Github: https://github.com/knightz1224/curl2pyreqs
####################
#!/bin/env python3""")[1]
            return {"cURL": "#BY : ParasCode\n#Telegram : https://t.me/Aotpy\n#Channel : https://t.me/Obitostuffs\n" + output}
        except:
            return False

class Proxy:
    @staticmethod
    def http(proxy):
        url = 'https://github.com/'
        headers = {"User-Agent": random_user_agent()}
        handler = urllib.request.ProxyHandler({'http': f"http://{proxy}", 'https': f"http://{proxy}"})
        opener = urllib.request.build_opener(handler)
        urllib.request.install_opener(opener)
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers)) as response:
                return response.getcode() == 200
        except:
            return False

    @staticmethod
    def https(proxy):
        url = 'https://github.com/'
        headers = {"User-Agent": random_user_agent()}
        handler = urllib.request.ProxyHandler({'http': f'https://{proxy}', 'https': f'https://{proxy}'})
        opener = urllib.request.build_opener(handler)
        urllib.request.install_opener(opener)
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers)) as response:
                return response.getcode() == 200
        except:
            return False

    @staticmethod
    def socks4(proxy):
        url = 'https://github.com/'
        headers = {"User-Agent": random_user_agent()}
        proxy_host, proxy_port = proxy.split(':')
        socks.set_default_proxy(socks.SOCKS4, proxy_host, int(proxy_port))
        socket.socket = socks.socksocket
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers)) as response:
                return response.getcode() == 200
        except:
            return False

    @staticmethod
    def socks5(proxy):
        url = 'https://github.com/'
        headers = {"User-Agent": random_user_agent()}
        proxy_host, proxy_port = proxy.split(':')
        socks.set_default_proxy(socks.SOCKS5, proxy_host, int(proxy_port))
        socket.socket = socks.socksocket
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers)) as response:
                return response.getcode() == 200
        except:
            return False

class Facebook:
    @staticmethod
    def Login(email, password):
        try:
            head = {
                'User-Agent': random_user_agent(),
                'Content-Type': 'application/x-www-form-urlencoded',
                'X-Fb-Friendly-Name': 'authenticate',
                'X-Fb-Connection-Type': 'WIFI',
            }
            data = {
                'adid': str(uuid.uuid4()),
                'format': 'json',
                'device_id': str(uuid.uuid4()),
                'email': email,
                'password': password,
                'generate_session_cookies': '1',
                'source': 'login',
                'api_key': '882a8490361da98702bf97a021ddc14d',
                'access_token': '350685531728|62f8ce9f74b12f84c123cc23437a4a32'
            }
            pos = r.post('https://b-graph.facebook.com/auth/login', data=data, headers=head).json()
            if 'session_key' in str(pos) and 'access_token' in str(pos):
                token = pos.get('access_token')
                cookie = ''.join([f"{i['name']}={i['value']};" for i in pos.get('session_cookies', [])])
                return {"status": True, "token": token, "cookie": cookie}
            return False
        except:
            return False

pc = ParasCode()
cprint = pc.cprint
random_string = pc.random_string
random_number = pc.random_number
random_user_agent = pc.random_user_agent
get_client = pc.get_client
link = pc.link
expire = pc.expire
clear = pc.clear
banner = pc.banner
run = ParasCode.run
clear_screen = pc.clear_screen
print_colored = pc.print_colored
colored = pc.colored
render = pc.render
say = pc.say
show_fonts = pc.show_fonts
show_colors = pc.show_colors
show_backgrounds = pc.show_backgrounds