#!/usr/bin/env bash
set -euo pipefail

usage() {
  echo "Usage: $0 <version>"
  echo "  e.g. $0 0.3.0"
  exit 1
}

[[ $# -ne 1 ]] && usage

VERSION="$1"

# Validate semver-like format
if [[ ! "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "Error: version must be in X.Y.Z format (got: $VERSION)"
  exit 1
fi

ROOT="$(git rev-parse --show-toplevel)"
VERSION_PY="$ROOT/src/dyfinance/_version.py"
PYPROJECT="$ROOT/pyproject.toml"

# Update _version.py
sed -i "s/^__version__ = \".*\"/__version__ = \"$VERSION\"/" "$VERSION_PY"

# Update pyproject.toml (only the project version line)
sed -i "s/^version = \".*\"/version = \"$VERSION\"/" "$PYPROJECT"

echo "Bumped version to $VERSION"
echo "  $VERSION_PY"
echo "  $PYPROJECT"
