"""Tests for transparent delegation and fallback to yfinance."""

import pytest


class TestModuleLevelFallback:
    def test_module_has_ticker(self):
        import dyfinance

        assert hasattr(dyfinance, "Ticker")

    def test_module_has_tickers(self):
        import dyfinance

        assert hasattr(dyfinance, "Tickers")

    def test_module_has_download(self):
        import dyfinance

        assert hasattr(dyfinance, "download")

    def test_module_has_version(self):
        import dyfinance

        assert hasattr(dyfinance, "__version__")
        assert isinstance(dyfinance.__version__, str)

    def test_module_fallback_search(self):
        """Search class should be accessible via __getattr__ fallback."""
        import dyfinance
        import yfinance

        assert dyfinance.Search is yfinance.Search

    def test_module_fallback_equity_query(self):
        import dyfinance
        import yfinance

        assert dyfinance.EquityQuery is yfinance.EquityQuery

    def test_module_fallback_enable_debug_mode(self):
        import dyfinance

        assert callable(dyfinance.enable_debug_mode)

    def test_module_fallback_nonexistent_raises(self):
        import dyfinance

        with pytest.raises(AttributeError, match="no attribute"):
            _ = dyfinance.this_does_not_exist_at_all

    def test_all_yfinance_all_accessible(self):
        """Every name in yfinance.__all__ should be accessible through dyfinance."""
        import dyfinance
        import yfinance

        for name in yfinance.__all__:
            assert hasattr(dyfinance, name), f"dyfinance missing yfinance.__all__ member: {name}"


class TestTickerProxy:
    def test_ticker_repr(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert "dyfinance" in repr(t)
        assert "AAPL" in repr(t)

    def test_ticker_has_history_method(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "history")
        assert callable(t.history)

    def test_ticker_delegates_ticker_property(self):
        """The .ticker property should be delegated to yfinance Ticker."""
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert t.ticker == "AAPL"

    def test_ticker_delegates_info(self):
        """info attribute should be accessible (lazy, no network call at access time)."""
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "info")

    def test_ticker_delegates_dividends(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "dividends")

    def test_ticker_delegates_splits(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "splits")

    def test_ticker_delegates_actions_attr(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "actions")

    def test_ticker_delegates_income_stmt(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "income_stmt")

    def test_ticker_delegates_balance_sheet(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "balance_sheet")

    def test_ticker_delegates_cash_flow(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "cash_flow")

    def test_ticker_delegates_options(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "options")

    def test_ticker_delegates_option_chain(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "option_chain")
        assert callable(t.option_chain)

    def test_ticker_delegates_recommendations(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "recommendations")

    def test_ticker_delegates_calendar(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "calendar")

    def test_ticker_delegates_fast_info(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "fast_info")

    def test_ticker_delegates_news(self):
        import dyfinance

        t = dyfinance.Ticker("AAPL")
        assert hasattr(t, "news")


class TestTickersProxy:
    def test_tickers_repr(self):
        import dyfinance

        t = dyfinance.Tickers("AAPL MSFT")
        assert "dyfinance" in repr(t)

    def test_tickers_symbols(self):
        import dyfinance

        t = dyfinance.Tickers("AAPL MSFT")
        assert set(t.symbols) == {"AAPL", "MSFT"}

    def test_tickers_has_individual_tickers(self):
        import dyfinance

        t = dyfinance.Tickers("AAPL MSFT")
        assert "AAPL" in t.tickers
        assert "MSFT" in t.tickers
        # Individual tickers should be dyfinance.Ticker instances
        from dyfinance._ticker import Ticker

        assert isinstance(t.tickers["AAPL"], Ticker)

    def test_tickers_has_history_method(self):
        import dyfinance

        t = dyfinance.Tickers("AAPL MSFT")
        assert hasattr(t, "history")
        assert callable(t.history)

    def test_tickers_has_download_method(self):
        import dyfinance

        t = dyfinance.Tickers("AAPL MSFT")
        assert hasattr(t, "download")
        assert callable(t.download)
