"""Shared test constants and factory functions."""

import pandas as pd

# Fixed date range used across all tests for consistency
FIXED_START = "2024-06-03"
FIXED_END = "2024-06-30"


def make_raw_df(start: str = FIXED_START, n: int = 5) -> pd.DataFrame:
    """Create a raw (unadjusted, actions=True) yfinance-style DataFrame."""
    dates = pd.date_range(start, periods=n, freq="B", tz="America/New_York")
    return pd.DataFrame(
        {
            "Open": [180.0 + i for i in range(n)],
            "High": [182.0 + i for i in range(n)],
            "Low": [179.0 + i for i in range(n)],
            "Close": [181.0 + i for i in range(n)],
            "Adj Close": [181.0 + i for i in range(n)],
            "Volume": [50000000 + i * 100000 for i in range(n)],
            "Dividends": [0.0] * n,
            "Stock Splits": [0.0] * n,
        },
        index=dates,
    )
