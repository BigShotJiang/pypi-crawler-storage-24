"""Shared column name constants."""

from __future__ import annotations

ADJ_CLOSE = "Adj Close"
PRICE_COLUMNS = ("Open", "High", "Low", "Close")
PRICE_COLUMNS_WITH_ADJ = ("Open", "High", "Low", "Close", "Adj Close")
ACTION_COLUMNS = ("Dividends", "Stock Splits", "Capital Gains")

# Intervals eligible for caching (daily and above)
CACHEABLE_INTERVALS = frozenset({"1d", "5d", "1wk", "1mo", "3mo"})
