"""dyfinance - Drop-in yfinance wrapper with DuckDB OHLCV caching."""

from __future__ import annotations

from typing import Any

from dyfinance._download import download
from dyfinance._ticker import Ticker
from dyfinance._tickers import Tickers
from dyfinance._version import __version__

__all__ = [
    "__version__",
    "Ticker",
    "Tickers",
    "download",
]


def __getattr__(name: str) -> Any:
    """Transparent fallback to yfinance for anything we don't override."""
    import yfinance

    try:
        return getattr(yfinance, name)
    except AttributeError:
        raise AttributeError(f"module 'dyfinance' has no attribute {name!r}") from None
