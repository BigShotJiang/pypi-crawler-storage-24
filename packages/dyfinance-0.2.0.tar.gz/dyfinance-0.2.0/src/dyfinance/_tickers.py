"""Tickers proxy class with DuckDB caching."""

from __future__ import annotations

from datetime import datetime
from typing import Any

import pandas as pd
import yfinance

from dyfinance._download import download
from dyfinance._ticker import Ticker


class Tickers:
    """Drop-in replacement for yfinance.Tickers with DuckDB caching."""

    def __init__(self, tickers: str | list[str], session: Any = None) -> None:
        if isinstance(tickers, str):
            tickers = tickers.replace(",", " ").split()
        self.symbols = [t.upper() for t in tickers]
        self.tickers = {t: Ticker(t, session=session) for t in self.symbols}
        self._yf_tickers = yfinance.Tickers(" ".join(self.symbols), session=session)

    def __repr__(self) -> str:
        return f"dyfinance.Tickers object <{','.join(self.symbols)}>"

    def __getattr__(self, name: str) -> Any:
        return getattr(self._yf_tickers, name)

    def history(
        self,
        period: str | None = None,
        interval: str = "1d",
        start: str | datetime | None = None,
        end: str | datetime | None = None,
        prepost: bool = False,
        actions: bool = True,
        auto_adjust: bool = True,
        repair: bool = False,
        threads: bool | int = True,
        group_by: str = "column",
        progress: bool = True,
        timeout: float = 10,
        **kwargs: Any,
    ) -> pd.DataFrame | None:
        return self.download(
            period=period, interval=interval, start=start, end=end,
            prepost=prepost, actions=actions, auto_adjust=auto_adjust,
            repair=repair, threads=threads, group_by=group_by,
            progress=progress, timeout=timeout, **kwargs,
        )

    def download(
        self,
        period: str | None = None,
        interval: str = "1d",
        start: str | datetime | None = None,
        end: str | datetime | None = None,
        prepost: bool = False,
        actions: bool = True,
        auto_adjust: bool = True,
        repair: bool = False,
        threads: bool | int = True,
        group_by: str = "column",
        progress: bool = True,
        timeout: float = 10,
        **kwargs: Any,
    ) -> pd.DataFrame | None:
        return download(
            self.symbols, start=start, end=end, actions=actions,
            auto_adjust=auto_adjust, repair=repair, period=period,
            interval=interval, prepost=prepost, group_by=group_by,
            threads=threads, progress=progress, timeout=timeout,
            **kwargs,
        )
