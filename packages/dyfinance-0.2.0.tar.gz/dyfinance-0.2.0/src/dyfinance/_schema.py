"""DuckDB table definitions for OHLCV cache."""

SCHEMA_VERSION = 1

CREATE_OHLCV_TABLE = """
CREATE TABLE IF NOT EXISTS ohlcv (
    ticker       VARCHAR NOT NULL,
    interval     VARCHAR NOT NULL,
    ts           TIMESTAMPTZ NOT NULL,
    open         DOUBLE,
    high         DOUBLE,
    low          DOUBLE,
    close        DOUBLE,
    adj_close    DOUBLE,
    volume       BIGINT,
    dividends    DOUBLE DEFAULT 0.0,
    stock_splits DOUBLE DEFAULT 0.0,
    capital_gains DOUBLE DEFAULT 0.0,
    PRIMARY KEY (ticker, interval, ts)
);
"""

CREATE_CACHE_META_TABLE = """
CREATE TABLE IF NOT EXISTS cache_meta (
    ticker      VARCHAR NOT NULL,
    interval    VARCHAR NOT NULL,
    cached_from TIMESTAMPTZ NOT NULL,
    cached_to   TIMESTAMPTZ NOT NULL,
    fetched_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    PRIMARY KEY (ticker, interval)
);
"""

CREATE_SCHEMA_VERSION_TABLE = """
CREATE TABLE IF NOT EXISTS schema_version (
    version    INTEGER NOT NULL,
    applied_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
"""
