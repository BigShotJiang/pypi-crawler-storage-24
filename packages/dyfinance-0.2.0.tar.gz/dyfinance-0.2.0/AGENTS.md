# AGENTS.md

## Project Overview

dyfinance is a drop-in replacement for yfinance with DuckDB OHLCV caching.
`import dyfinance as yf` must behave identically to `import yfinance as yf`.

## Key Docs

- [docs/SPEC.md](docs/SPEC.md) - Full specification
- [docs/yfinance-compatibility.md](docs/yfinance-compatibility.md) - yfinance compatibility policy

## Protected Test Files (DO NOT MODIFY)

The following test files verify yfinance I/O and option compatibility.
**Do not delete, modify, or weaken existing test cases.** Adding new tests is fine.

- `tests/test_ticker_history.py` - Ticker.history() all options
- `tests/test_download.py` - download() all options
- `tests/test_compat.py` - dyfinance vs yfinance output comparison
- `tests/test_proxy.py` - Module fallback and attribute delegation

## Commands

```bash
make test        # Run offline tests
make test-live   # Run live yfinance comparison tests
make lint        # ruff check
make typecheck   # mypy check
make clean       # Remove __pycache__, .pyc, etc.
```
