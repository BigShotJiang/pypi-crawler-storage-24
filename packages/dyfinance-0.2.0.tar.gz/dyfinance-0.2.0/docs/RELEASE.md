# Release Procedure

## 前提

| 項目 | 状態 |
|------|------|
| PyPI Trusted Publisher | `pypi` environment で設定済み |
| TestPyPI Trusted Publisher | `testpypi` environment で設定済み |
| GitHub Actions workflow | `.github/workflows/publish.yml` |

publish workflow は **Trusted Publisher (OIDC)** を使用しており、API トークンは不要。
GitHub Environment の設定で Trusted Publisher が PyPI / TestPyPI 両方に登録されている必要がある。

## バージョン管理

バージョンは以下の **2箇所** で管理されている。リリース前に両方を更新すること。

1. `pyproject.toml` — `version = "X.Y.Z"`
2. `src/dyfinance/_version.py` — `__version__ = "X.Y.Z"`

## リリース手順

### 1. main ブランチを最新にする

```bash
git switch main
git pull origin main
```

### 2. CI が通っていることを確認

```bash
make lint
make typecheck
make test
```

GitHub Actions の CI (Python 3.10–3.13) もすべて green であること。

### 3. バージョンを更新

```bash
# 例: 0.1.0 → 0.2.0
vim pyproject.toml               # version = "0.2.0"
vim src/dyfinance/_version.py     # __version__ = "0.2.0"
```

### 4. コミット & タグ作成

```bash
git add pyproject.toml src/dyfinance/_version.py
git commit -m "Release v0.2.0"
git tag v0.2.0
```

### 5. プッシュ

```bash
git push origin main
git push origin v0.2.0
```

`v*` タグの push をトリガーに、publish workflow が自動で実行される。

### 6. workflow の確認

workflow は以下の順序で実行される:

1. **test-pypi** ジョブ — TestPyPI にアップロード → pip install で検証
2. **pypi** ジョブ — test-pypi 成功後、PyPI にアップロード

GitHub Actions の [Actions タブ](../../actions) で進捗を確認する。

### 7. リリース後の確認

```bash
# PyPI からインストール
pip install dyfinance==0.2.0
python -c "import dyfinance; print(dyfinance.__version__)"
```

## 手動で TestPyPI にアップロードする場合

ローカルから手動でテストしたい場合:

```bash
pip install build twine

python -m build

# TestPyPI にアップロード (API トークンが必要)
twine upload --repository testpypi dist/*

# TestPyPI からインストールして確認
pip install --index-url https://test.pypi.org/simple/ \
            --extra-index-url https://pypi.org/simple/ \
            dyfinance==0.2.0
```

`--extra-index-url https://pypi.org/simple/` は依存パッケージ (yfinance, duckdb 等) を
通常の PyPI から取得するために必要。

## GitHub Environment の設定

Trusted Publisher を使うため、GitHub リポジトリに以下の Environment が必要:

### `pypi` environment

PyPI → Publishing → Add a new publisher:
- Owner: `<GitHub org or user>`
- Repository: `dyfinance`
- Workflow: `publish.yml`
- Environment: `pypi`

### `testpypi` environment

TestPyPI → Publishing → Add a new publisher:
- Owner: `<GitHub org or user>`
- Repository: `dyfinance`
- Workflow: `publish.yml`
- Environment: `testpypi`

## トラブルシューティング

### TestPyPI で "version already exists" エラー

TestPyPI / PyPI は同一バージョンの再アップロードを許可しない。
バージョン番号を上げるか、`X.Y.Z.devN` サフィックスを使う。

### Trusted Publisher の認証エラー

- GitHub Environment 名が workflow の `environment:` と一致しているか確認
- PyPI / TestPyPI 側の Publisher 設定で workflow ファイル名が正しいか確認
- `id-token: write` パーミッションが workflow に設定されているか確認

### TestPyPI でインストール検証が失敗する

TestPyPI のインデックス反映に数秒かかる場合がある。
workflow には 15 秒の wait を入れているが、それでも失敗する場合は手動で再実行する。
