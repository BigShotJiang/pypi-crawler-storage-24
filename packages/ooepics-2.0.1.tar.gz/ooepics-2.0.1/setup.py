from setuptools import setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(name              = "ooepics",
      version           = "2.0.1",
      maintainer        = "Zheqiao Geng",
      maintainer_email  = "zheqiao.geng@psi.ch",
      author            = "Zheqiao Geng",
      author_email      = "zheqiao.geng@psi.ch",
      description       = "Python framework for soft IOC.",
      long_description  = long_description,
      long_description_content_type = "text/markdown",
      url               = "https://github.com/aaqiao/ooEpicsPy",
      license           = "BSD 3-Clause",
      packages          = ['ooepics'],
      zip_safe          = False)

